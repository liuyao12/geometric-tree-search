"""Build two millimetre-scale wave shells and their fitted GLB assembly.

Requires numpy, shapely and trimesh. Run with Python 3. The input coordinates
are the normalized GCTS-I loops, with the first vertex as phase origin.
"""
from io import BytesIO
from pathlib import Path
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
from shapely.geometry import Point, Polygon
import trimesh

OUT = Path(__file__).resolve().parent
PITCH = 24.0
THICKNESS = 1.6
DIVISIONS = 16
ROOT3 = np.sqrt(3)
LOOPS = {
    'hat': [(0,0),(1,0),(1,1),(3,0),(4,1),(3,2),(3,3),(1,4),(0,6),(-1,6),(-1,5),(-1,4),(0,3),(-1,2)],
    'turtle': [(0,0),(-1,2),(-3,3),(-3,4),(-4,5),(-5,4),(-4,2),(-5,2),(-5,1),(-3,0),(-2,-2),(-1,-2),(0,-3),(1,-2)],
}
COLORS = ['E5D9BE', '225A9D', 'BA483C', 'D0DCCE']
NAMES = ['Hat porcelain', 'Ascending', 'Descending', 'Turtle porcelain']
# Vectors are ordered d0, d1, d2; each has unit Euclidean length.
DIRECTIONS = np.array([[1,0],[-.5,ROOT3/2],[-.5,-ROOT3/2]])


def stripe_coordinates(xy):
    x, y = np.asarray(xy).T
    return (-2*x-y)/3, (-x-2*y)/3


def physical_xy(xy):
    a, b = stripe_coordinates(xy)
    return PITCH * np.column_stack((a-b/2, ROOT3*b/2))


def wave(a, b):
    """Return mid-height and Cartesian gradient in physical units."""
    angles = np.pi * np.asarray([a, b, a-b])
    s, c = np.sin(angles), np.cos(angles)
    s3, c3 = np.sin(3*angles), np.cos(3*angles)
    p = s.prod(axis=0)
    w = 64/27*p*p
    side = s3.sum(axis=0)
    wa = (128*np.pi/27)*p*s[1]*(c[0]*s[2]+s[0]*c[2])
    wb = (128*np.pi/27)*p*s[0]*(c[1]*s[2]-s[1]*c[2])
    h = PITCH/(2*np.pi)*(s.sum(axis=0)+w*side/6)
    ha = .5*(c[0]+c[2]) + wa*side/(12*np.pi) + w*(c3[0]+c3[2])/4
    hb = .5*(c[1]-c[2]) + wb*side/(12*np.pi) + w*(c3[1]-c3[2])/4
    return h, np.column_stack((ha, (ha+2*hb)/ROOT3))


def marking(x, y):
    if (x-y) % 3:
        return (0,0,0)
    a, b = (-2*x-y)//3, (-x-2*y)//3
    return {(0,0):(1,0,-1), (1,1):(0,-1,1), (1,0):(-1,1,0), (0,1):(0,0,0)}[a%2,b%2]


def unit_mesh(loop):
    """Barycentrically split A2 triangles. All boundary rays lie on these edges."""
    P = Polygon(loop)
    lo, hi = np.min(loop,axis=0), np.max(loop,axis=0)
    patches = []
    for i in range(lo[0]-1, hi[0]+1):
        for j in range(lo[1]-1, hi[1]+1):
            for corners in [[(i,j),(i+1,j),(i,j+1)],[(i+1,j+1),(i,j+1),(i+1,j)]]:
                v = 6*np.array(corners)
                center = v.sum(axis=0)//3
                for k in range(3):
                    left, right = v[k], v[(k+1)%3]
                    mid = (left+right)//2
                    for tri in [[left,mid,center],[mid,right,center]]:
                        if P.contains(Point(np.mean(tri,axis=0)/6)):
                            patches.append(tri)
    assert abs(len(patches)/12-P.area)<1e-10
    n = DIVISIONS
    ij = [(i,j) for i in range(n+1) for j in range(n+1-i)]
    ids = {pair:k for k,pair in enumerate(ij)}
    faces = []
    for i,j in ij:
        if i+j<n:
            faces.append([ids[i,j],ids[i+1,j],ids[i,j+1]])
        if i+j<n-1:
            faces.append([ids[i+1,j],ids[i+1,j+1],ids[i,j+1]])
    uv = np.array(ij)
    lattice = np.concatenate([n*a+uv[:,0:1]*(b-a)+uv[:,1:2]*(c-a) for a,b,c in patches])
    points, inverse = np.unique(lattice,axis=0,return_inverse=True)
    faces = inverse.reshape(len(patches),len(ij))[:,np.array(faces)].reshape(-1,3)
    return points/(6*n), faces


def core_sites(loop):
    P = Polygon(loop)
    lo, hi = np.min(loop,axis=0), np.max(loop,axis=0)
    return np.array([(x,y) for x in range(lo[0],hi[0]+1) for y in range(lo[1],hi[1]+1)
                     if P.covers(Point(x,y))])


def verify_wave(sites):
    a,b = stripe_coordinates(sites)
    marks = np.array([marking(*p) for p in sites])
    _,grad = wave(a,b)
    assert np.max(np.abs(grad@DIRECTIONS.T-marks))<1e-12
    for c,(da,db) in enumerate(((1,0),(0,1),(-1,-1))):
        eps=1e-6
        hi=wave(a+da*eps,b+db*eps)[0]
        lo=wave(a-da*eps,b-db*eps)[0]
        assert np.max(np.abs((hi-lo)/(2*PITCH*eps)-marks[:,c]))<2e-9
        mask = marks[:,c]!=0
        for t in np.linspace(-1,1,33):
            section = wave(a[mask]+t*da,b[mask]+t*db)[0]
            assert np.allclose(section,PITCH/np.pi*marks[mask,c]*np.sin(np.pi*t),atol=1e-12)


def ink(places, centers, neutral):
    """Material only. Both skins retain exactly the same underlying relief."""
    result = np.full(len(centers),neutral,dtype=int)
    nearest = np.full(len(centers),np.inf)
    for q, origin in zip(places,physical_xy(places)):
        delta = centers-origin
        for direction, sign in zip(DIRECTIONS,marking(*q)):
            if not sign:
                continue
            along = delta@direction
            perp = delta[:,0]*direction[1]-delta[:,1]*direction[0]
            dist = perp**2
            use = (np.abs(along)<=PITCH/2) & (dist<(PITCH*.033)**2) & ((dist<nearest) | ((dist==nearest)&(sign>0)))
            result[use] = 1 if sign>0 else 2
            nearest[use] = dist[use]
    return result


def build_tile(name, phase=1):
    loop = LOOPS[name]
    q, f = unit_mesh(loop)
    xy = physical_xy(q)
    h, slope = wave(*stripe_coordinates(q))
    h, slope = phase*h, phase*slope
    mid = np.column_stack((xy,h))
    normals = np.column_stack((-slope,np.ones(len(h))))
    normals /= np.linalg.norm(normals,axis=1)[:,None]
    n = len(q)
    vertices = np.vstack((mid+THICKNESS/2*normals, mid-THICKNESS/2*normals))
    edges = np.concatenate([f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]])
    _,indices,counts = np.unique(np.sort(edges,axis=1),axis=0,return_index=True,return_counts=True)
    a,b = edges[indices[counts==1]].T
    # Adjacent tiles traverse an edge in opposite directions. Split each
    # nonplanar wall quad about its centroid so that both meshes use exactly
    # the same four triangles, including when the height phase reverses.
    quads=np.column_stack((a,a+n,b+n,b))
    centers=2*n+np.arange(len(quads))
    vertices=np.vstack((vertices,vertices[quads].mean(axis=1)))
    walls=np.vstack([np.column_stack((quads[:,i],quads[:,(i+1)%4],centers)) for i in range(4)])
    faces = np.vstack((f,f[:,::-1]+n,walls))
    sites = core_sites(loop)
    verify_wave(sites)
    neutral = 0 if name=='hat' else 3
    # Sample half-step ink strokes from both sides of the outline. At an edge
    # the two parts then paint complementary portions of the very same stripe.
    lo,hi=sites.min(axis=0)-2,sites.max(axis=0)+2
    collar=[(x,y) for x in range(lo[0],hi[0]+1) for y in range(lo[1],hi[1]+1)]
    upper=ink(collar,xy[f].mean(axis=1),neutral)
    # A face-down placement reflects the planar decoration. The GCTS signed
    # action reverses the two colors under that reflection.
    lower=np.where(upper==1,2,np.where(upper==2,1,upper))
    materials = np.r_[upper,lower,np.full(len(walls),neutral)]
    mesh = trimesh.Trimesh(vertices,faces,process=False)
    assert mesh.is_watertight and mesh.is_winding_consistent and mesh.euler_number==2 and mesh.volume>0
    assert np.min(mesh.area_faces)>1e-8
    successor=dict(zip(a,b))
    ring=[a[0]]
    while len(ring)<len(a):
        ring.append(successor[ring[-1]])
    assert len(set(ring))==len(a) and successor[ring[-1]]==ring[0]
    for skin in [vertices[:n],vertices[n:2*n]]:
        ab, ac = (skin[f[:,i]]-skin[f[:,0]] for i in [1,2])
        assert np.min(ab[:,0]*ac[:,1]-ab[:,1]*ac[:,0])>0
        assert Polygon(skin[ring,:2]).is_valid
    assert np.max(np.abs(np.linalg.norm(vertices[:n]-vertices[n:2*n],axis=1)-THICKNESS))<1e-12
    return dict(name=name,phase=phase,vertices=vertices,faces=faces,mat=materials,n=n,f=f,xy=q,normal=normals,
                wall=walls,boundary=np.unique(np.r_[a,b]))


def make_3mf(tile):
    name = tile['name']
    suffix = '-opposite-phase' if tile['phase']==-1 else ''
    v = tile['vertices'].copy()
    v[:,2] -= v[:,2].min()
    ns = 'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
    buf = BytesIO()
    def write(s):
        buf.write(s.encode())
    write(f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xml:lang="en-US" xmlns="{ns}"><resources><basematerials id="1">')
    for label,rgb in zip(NAMES,COLORS):
        write(f'<base name="{label}" displaycolor="#{rgb}FF"/>')
    write(f'</basematerials><object id="2" name="{name.title()} wave{suffix}" type="model" pid="1" pindex="0"><mesh><vertices>')
    for x,y,z in v:
        write(f'<vertex x="{x:.6f}" y="{y:.6f}" z="{z:.6f}"/>')
    write('</vertices><triangles>')
    for (a,b,c),m in zip(tile['faces'],tile['mat']):
        write(f'<triangle v1="{a}" v2="{b}" v3="{c}" pid="1" p1="{m}"/>')
    write('</triangles></mesh></object></resources><build><item objectid="2"/></build></model>')
    path = OUT/f'{name}-wave{suffix}.3mf'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/></Types>')
        archive.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
        archive.writestr('3D/3dmodel.model',buf.getvalue())
    with zipfile.ZipFile(path) as archive:
        tree = ET.fromstring(archive.read('3D/3dmodel.model'))
        assert len(tree.findall('.//{*}triangle'))==len(tile['faces'])
        assert len(tree.findall('.//{*}vertex'))==len(v)


def fitted_pose(q):
    # Certified mixed edge contact: cyclic permutation [2,0,1] and translation (-4,5,-1).
    x,y = np.asarray(q).T
    return np.column_stack((-x-y-4,x+5))


def assembled(tiles):
    basis = np.array([[0,0],[1,0],[0,1]])
    raw, target = physical_xy(basis), physical_xy(fitted_pose(basis))
    rotation = np.linalg.solve(raw[1:],target[1:]-target[0])
    assert np.allclose(rotation.T@rotation,np.eye(2)) and np.isclose(np.linalg.det(rotation),1)
    result = []
    for tile in tiles:
        t = dict(tile)
        t['vertices'] = t['vertices'].copy()
        t['normal'] = t['normal'].copy()
        if t['name']=='turtle':
            t['vertices'][:,:2] = t['vertices'][:,:2]@rotation+target[0]
            t['normal'][:,:2] = t['normal'][:,:2]@rotation
            global_h,global_g = wave(*stripe_coordinates(fitted_pose(t['xy'])))
            local_h,local_g = wave(*stripe_coordinates(t['xy']))
            assert np.allclose(local_h,global_h) and np.allclose(local_g@rotation,global_g)
        result.append(t)
    # Every common midsurface boundary sample must weld on both offset skins.
    left,right=result
    def seam_map(t):
        n=t['n']
        return {tuple(np.round((t['vertices'][i]+t['vertices'][i+n])[:2]/2,6)):t['vertices'][[i,i+n]]
                for i in t['boundary']}
    a,b=seam_map(left),seam_map(right)
    seam=a.keys()&b.keys()
    assert len(seam)>DIVISIONS and max(np.max(np.abs(a[k]-b[k])) for k in seam)<1e-10
    return result


def glb(tiles):
    scene = trimesh.Scene()
    for tile in tiles:
        name = tile['name'].title()
        n = len(tile['f'])
        for part, faceids in [('upper',np.arange(n)),('lower',np.arange(n,2*n)),('edge',np.arange(2*n,len(tile['faces'])))]:
            for color in np.unique(tile['mat'][faceids]):
                ids = faceids[tile['mat'][faceids]==color]
                faces = tile['faces'][ids]
                verts, inv=np.unique(faces,return_inverse=True)
                pos=tile['vertices'][verts]
                # glTF uses metres and a Y-up frame.
                to_y_up = lambda a: np.column_stack((a[:,0],a[:,2],-a[:,1]))
                mesh=trimesh.Trimesh(to_y_up(pos)*.001,inv.reshape(-1,3),process=False)
                if part!='edge':
                    mesh.vertex_normals=to_y_up(tile['normal'][verts%tile['n']])*(1 if part=='upper' else -1)
                else:
                    # Angle averaging is unnecessary on the straight ruled wall.
                    area_normals=np.cross(mesh.triangles[:,1]-mesh.triangles[:,0],mesh.triangles[:,2]-mesh.triangles[:,0])
                    summed=np.zeros_like(mesh.vertices)
                    for index in mesh.faces.T:
                        np.add.at(summed,index,area_normals)
                    mesh.vertex_normals=summed/np.linalg.norm(summed,axis=1)[:,None]
                srgb = np.frombuffer(bytes.fromhex(COLORS[color]),np.uint8)/255
                linear=np.where(srgb<=.04045,srgb/12.92,((srgb+.055)/1.055)**2.4)
                mat=trimesh.visual.material.PBRMaterial(name=NAMES[color],baseColorFactor=np.r_[linear,1],metallicFactor=0.,roughnessFactor=.72)
                mesh.visual=trimesh.visual.TextureVisuals(material=mat)
                scene.add_geometry(mesh,node_name=f'{name} {part} {color}',parent_node_name=name)
        scene.graph.update(frame_from=scene.graph.base_frame,frame_to=name,matrix=np.eye(4))
    path=OUT/'fitted-hat-and-turtle.glb'
    scene.export(path,include_normals=True)
    reloaded=trimesh.load_scene(path)
    assert sum(len(m.faces) for m in reloaded.geometry.values())==sum(len(t['faces']) for t in tiles)


if __name__=='__main__':
    tiles=[build_tile(name) for name in LOOPS]
    for tile in tiles:
        make_3mf(tile)
        make_3mf(build_tile(tile['name'],-1))
        print(tile['name'],len(tile['vertices']),'vertices;',len(tile['faces']),'triangles')
    glb(assembled(tiles))
