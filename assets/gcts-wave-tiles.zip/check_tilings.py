"""Exact local-to-global checks. Supply the project's lifted patch.json to replay
the pure-Turtle substitution witnesses for the constant-color wildcard test.
"""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations, permutations, product
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
geometry=HERE/'geometry.json'
if not geometry.exists():
    geometry=HERE.parent/'mixed-hat-turtle-marking/geometry.json'
data=json.loads(geometry.read_text())
group=list(product((1,-1),permutations(range(3))))
identity=(0,0,0)


def image(i,p):
    sign,perm=group[i]
    q=(*p,-sum(p))
    return sign*q[perm[0]],sign*q[perm[1]]


def parity(perm):
    return (-1)**sum(a>b for a,b in combinations(perm,2))


def sign_of_wave(i,dx,dy):
    # Three Fourier arguments in units of pi, multiplied by three to keep
    # axial translations integral. At a legal contact the offsets are integers.
    def args(a,b):
        x,y=image(i,(-2*a+b,a-2*b))
        x+=dx
        y+=dy
        return -2*x-y,-x-2*y,-x+y
    o,u,v=args(0,0),args(1,0),args(0,1)
    signs=[]
    terms=[]
    basis=((3,0),(0,3),(3,-3))
    for j in range(3):
        assert o[j]%3==0
        d=u[j]-o[j],v[j]-o[j]
        s=1 if d in basis else -1
        terms.append(basis.index(tuple(s*k for k in d)))
        signs.append(s*(-1 if (o[j]//3)%2 else 1))
    assert sorted(terms)==[0,1,2] and len(set(signs))==1
    # S1 and S3 get this sign. The squared sine product W is invariant.
    assert signs[0]==group[i][0]*parity(group[i][1])
    return signs[0]


shapes={}
constant={}
for name in ('hat','turtle'):
    core=data['shapes'][name][0]
    for i,(_,perm) in enumerate(group):
        shapes[name,i]={image(i,(x,y)):w for x,y,w in core['points']}
        if name=='turtle':
            constant[i]={(image(i,m['point'][:2]),perm.index(m['component'])):parity(perm)*m['value']
                         for m in data['marks']['turtle']}


def verify(names,rotations):
    # Translate each candidate until one occupied site covers the origin.
    candidates=[]
    for n,i in product(names,rotations):
        for (x,y),w in shapes[n,i].items():
            occupied={(u-x,v-y):d for (u,v),d in shapes[n,i].items()}
            candidates.append((n,i,x,y,w,occupied))
    demands=defaultdict(set)
    stars=0
    for seed in (c for c in candidates if c[1]==0):
        n,i,x,y,w,occ=seed

        def visit(start,remain,sums,others):
            nonlocal stars
            if remain==0:
                stars+=1
                for n2,j,u,v,_,_ in others:
                    sign_of_wave(j,x-u,y-v)
                    if names==('turtle',):
                        for c in range(3):
                            if ((x,y),c) not in constant[0] and ((u,v),c) in constant[j]:
                                demands[x,y,c].add(constant[j][(u,v),c])
                return
            for index in range(start,len(candidates)):
                other=candidates[index]
                *_,weight,occupied=other
                if other is seed or weight>remain: continue
                if any(sums.get(p,0)+v>12 for p,v in occupied.items()): continue
                combined=Counter(sums);combined.update(occupied)
                visit(index+1,remain-weight,combined,[*others,other])
        visit(0,12-w,occ,[])
    return stars,dict(demands)


def signature(points):
    x,y=map(min,zip(*points))
    return tuple(sorted((u-x,v-y) for u,v in points)),x,y


def replay_turtles(patch):
    # Exchange the two edge lengths in the authors' lifted H metatile.
    g=json.loads(patch.read_text())
    verts=[(2*p+q+r,-p+q+s) for p,q,r,s in g['vertices']]
    loop=[p[:2] for p in data['shapes']['turtle'][0]['loop']]
    catalog={}
    for i in range(12):
        key,x,y=signature([image(i,p) for p in loop])
        catalog[key]=i,x,y
    poses=[];board={};capacity=Counter()
    for ids in g['tiles']:
        key,x,y=signature([verts[j] for j in ids])
        i,a,b=catalog[key];dx,dy=x-a,y-b;poses.append((i,dx,dy))
        for (u,v),w in shapes['turtle',i].items():capacity[u+dx,v+dy]+=w
        for ((u,v),c),value in constant[i].items():
            assert board.setdefault((u+dx,v+dy,c),value)==value
    assert max(capacity.values())==12 and len(poses)==7921
    demands=defaultdict(set)
    for x,y in shapes['turtle',0]:
        for c in range(3):
            if ((x,y),c) in constant[0]:continue
            for i,dx,dy in poses:
                u,v=image(i,(x,y));perm=group[i][1]
                val=board.get((u+dx,v+dy,perm.index(c)))
                if val is not None:demands[x,y,c].add(parity(perm)*val)
    return dict(demands)


def check_wall():
    # sin/pi Fourier convention: use the rational coefficients of i*sin.
    # The six sine factors in W contribute i^6=-1. F is i times the entire
    # dimensionless height, so all the resulting coefficients are rational.
    def sine(k):
        return {k:Fraction(1,2),tuple(-j for j in k):Fraction(-1,2)}
    def times(f,g):
        h=Counter()
        for (x,y),u in f.items():
            for (a,b),v in g.items():h[x+a,y+b]+=u*v
        return h
    terms=[(1,0),(0,1),(1,-1)]
    p={(0,0):1}
    for k in terms:p=times(p,sine(k))
    square=times(p,p)
    coeff=Counter()
    for a,b in terms:
        coeff.update(sine((a,b)))
        for k,v in times(square,sine((3*a,3*b))).items():coeff[k]-=Fraction(64,162)*v
    weighted=sum(abs(v)*(m*m+Fraction((m+2*n)**2,3)) for (m,n),v in coeff.items())
    assert weighted==Fraction(1516,81)
    # ||Hessian h|| <= pi*weighted/(2*24 mm); use pi < 22/7.
    assert Fraction(8,10)*Fraction(22,7)*weighted/48 < 1


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--patch',type=Path)
    options=parser.parse_args()
    check_wall()
    rotations=[i for i,(_,p) in enumerate(group) if parity(p)==1]
    constants=None
    for names,allowed,count in [(('turtle',),range(12),200),(('hat',),range(12),196),(('hat','turtle'),rotations,376)]:
        got,demands=verify(names,allowed)
        assert got==count
        print(names,got,'complete rooted stars with exact whole-plane wave agreement up to orientation phase')
        if names==('turtle',):constants=demands
    if options.patch:
        assert replay_turtles(options.patch)==constants
        print('Turtle constant-rule demands in a substitution tiling:',sorted(constants.items()))
