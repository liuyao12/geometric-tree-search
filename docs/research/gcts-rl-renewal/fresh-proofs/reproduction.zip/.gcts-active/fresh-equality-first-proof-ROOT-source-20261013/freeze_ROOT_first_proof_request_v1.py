"""ROOT SOURCE review/runtime request metadata only; no scientific project calls."""
import copy
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'.gcts-active/fresh-equality-first-proof-runner-source-v2-20261013'
PEER=ROOT/'.gcts-active/hilbert-incidence-priority-review-20261013'
DEST=ROOT/'.gcts-active/fresh-equality-first-proof-progress-20261013'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def verify_tree(value):
    if isinstance(value,dict):
        if set(value)=={'path','sha256','bytes'}:
            actual=pin(value['path']);assert actual['sha256']==value['sha256'] and actual['bytes']==value['bytes'],value['path']
        else:
            for child in value.values():verify_tree(child)
    elif isinstance(value,list):
        for child in value:verify_tree(child)

def read(path):return json.loads(Path(path).read_bytes())

def save(name,value):
    path=HERE/name
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    return pin(path)

def main():
    assert not DEST.exists()
    handoff_pin=pin(SOURCE/'handoff-v2.json')
    assert handoff_pin['sha256']=='75deb14664416f7aa0ce325f3710f83eef97b573acdfd6b94fcdc67c0ac06c02'
    handoff=read(handoff_pin['path']);verify_tree(handoff)
    findings_pin=pin(PEER/'fresh-first-proof-runner-source-findings-v2.json')
    assert findings_pin['sha256']=='639ed93f160b08de86f6bc22ffa0e86109356a1519362d772787cdaa4e01fbf5'
    findings=read(findings_pin['path']);verify_tree(findings)
    assert findings['source_review_passed'] is True and findings['scientific_calls']==0
    contract=read(handoff['metadata_contract']['path']);verify_tree(contract)
    assessment='ROOT read the complete metadata constructor, the current worker search/guard/endpoint/serialization path, and owner/terminal admission boundaries. Independently reviewed whole predecessor and exact normalized successor source deltas bind the remaining lifecycle/accounting algorithms. Exact current observer5/DFSv11/helper3 and actual45-control gate, whole17-source roles, six consumer sources, complete original indexed hypotheses, empty inventory, full fallback and unchanged128/20/2000 plus cold180/175/170/512MiB are prospective. No q, model, Graph, proof, native prover or learned policy is instantiated by this review/request constructor.'
    reviews={}
    for role in ('metadata','worker','owner','helper'):
        peer_path=PEER/('fresh-first-proof-'+role+'-source-review-v2.json')
        current=read(peer_path);verify_tree(current)
        assert current['source_only'] is True and current['source_review_passed'] is True and current['scientific_calls']==0
        value=copy.deepcopy(current)
        value.update(reviewer_identity='/root',independent_SOURCE_review=pin(peer_path),
            ROOT_assessment=assessment,ROOT_review_provenance=pin(__file__),scientific_acceptance=False)
        reviews[role]=save('ROOT-'+role+'-SOURCE-review-v1.json',value)
    observer_pin=pin(PEER/'fresh-first-proof-observer-source-review-v4.json')
    assert observer_pin['sha256']=='20aea1834b2b868436d831218af6f5de26da6128e00a001590649ca2588b44b4'
    observer=read(observer_pin['path']);verify_tree(observer)
    assert observer['source']==contract['sources']['proof_observer'] and observer['source_review_passed'] is True
    parent_platform_path=ROOT/'.gcts-active/hilbert-deterministic-incidence-three-lane-progress-v2-20261013/base/platform-review-v1.json'
    platform=read(parent_platform_path);verify_tree(platform)
    platform.update(worker=contract['sources']['worker'],owner=contract['owner'],
        ROOT_worker_source_review=reviews['worker'],ROOT_owner_source_review=reviews['owner'],
        current_independent_source_findings=findings_pin,
        ROOT_source_review_provenance=pin(__file__),prior_platform_review=pin(parent_platform_path),
        scope='ROOT Source-reviewed no-child cold first-proof leaf and trusted observer/wait4/closed52 owner postlude on pinned darwin3.9.6. Current exact worker/owner/terminal pin-only/narrow guard successor independently reviewed. Prospective32MiB reserve, not actual admission, an OS hard cap or whole-host completeness. Actual full caller/owner/worker bounds must pass after each once-only lane.')
    platform_pin=save('ROOT-platform-SOURCE-review-v1.json',platform)
    request=dict(schema='ROOT-fresh-equality-first-proof-metadata-request-v1',
        ROOT_authorized_metadata_construction=True,ROOT_authorized_four_once_lanes=True,
        ROOT_source_review=reviews['metadata'],
        independent_source_review=pin(PEER/'fresh-first-proof-metadata-source-review-v2.json'),
        static_disposition=contract['actual_static_disposition'],worker_review=reviews['worker'],
        owner_review=reviews['owner'],helper_review=reviews['helper'],observer_review=observer_pin,
        consumer_ROOT_review=reviews['worker'],
        consumer_peer_review=pin(PEER/'fresh-first-proof-worker-source-review-v2.json'),
        ROOT_observer_control_disposition=contract['actual_observer_control_disposition'],
        runtime=platform['runtime'],platform_review=platform_pin,fresh_destination=str(DEST))
    assert len(request)==16
    request_pin=save('ROOT-first-proof-metadata-request-v1.json',request)
    save('ROOT-review-and-request-construction-v1.json',dict(schema='ROOT-first-proof-source-review-and-request-construction-v1',
        scientific_calls=0,handoff=handoff_pin,independent_findings=findings_pin,reviews=reviews,
        platform=platform_pin,request=request_pin,q_or_model_created=False,proof_searches=0,
        source_only=True,scope=assessment))
    print(json.dumps(dict(request=request_pin,source_reviews=len(reviews),scientific_calls=0,q_or_model_created=False)))

if __name__=='__main__':main()
