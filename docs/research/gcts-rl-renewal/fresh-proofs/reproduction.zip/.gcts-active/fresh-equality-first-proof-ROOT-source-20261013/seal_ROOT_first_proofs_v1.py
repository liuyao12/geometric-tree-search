"""ROOT saved actual proof/resource metadata seal; no semantic replay or search."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/fresh-equality-first-proof-progress-20261013'
PEER=ROOT/'.gcts-active/hilbert-incidence-priority-review-20261013'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    actual=pin(record['path']);assert actual['sha256']==record['sha256'] and actual['bytes']==record['bytes']
    return Path(actual['path'])

def read(path):
    path=Path(path);raw=path.read_bytes()
    if path.name.endswith('.gz'):raw=gzip.decompress(raw)
    return json.loads(raw)

def main():
    construction_path=PROGRESS/'ROOT-construction-v1.json'
    construction=read(construction_path)
    assert pin(construction_path)['sha256']=='dc252cfb7e1260a94cb7f04dd3f2f2986a3e4aa8fc287951d315274dcd3558ed'
    review_path=PEER/'fresh-first-proof-four-lane-actual-saved-findings-v1.json'
    assert pin(review_path)['sha256']=='d7f316cbde8ef46544e8fc074f9cd01076788bfa0b007816a40d9c14f4c2f281'
    review=read(review_path)
    assert review['scientific_calls']==0 and review['whole_saved_reconciliation_passed'] is True
    assert review['concrete_mismatches']==[]
    expected=['actual_selected','completed_source_proposal','completed_source_proposal',None]
    trials=[]
    for position,lane in enumerate(construction['lanes']):
        directory=Path(lane['owner_plan']['path']).parent
        resource_path=directory/'ROOT-resource-disposition-v1.json';resource=read(resource_path)
        assert resource['resource_accepted'] is True and resource['owner_plan']==lane['owner_plan']
        for key in ('owner_plan','actual_terminal','owner_terminal','post_write','worker_receipt','result','qualified_context'):check(resource[key])
        result_path=check(resource['result']);result=read(result_path)
        q_path=check(resource['qualified_context']);q=read(q_path);header=read(check(q['catalog']))
        assert q['instance_id']==lane['selector'] and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True
        assert len(q)==11 and header['bodies']==header['complete_cluster_inventory']==[]
        assert result['root_restored'] is True and result['training_updates']==0
        assert result['commits']==[] and result['rng_draws']==[] and result['registered_whole_descriptor_count']==0
        certificate=None
        if expected[position] is not None:
            assert resource['checked_logical_target_candidate'] is True and resource['logical_origin_kind']==expected[position]
            certificate_path=check(resource['logical_certificate']);certificate=read(certificate_path)
            proof=certificate['checked_patch'];patch=proof['patch']
            assert proof['original_Gamma_target_sequent_accepted'] is True and proof['primary_endpoint_eligible'] is True
            assert proof['prospective_current_point_union_accepted'] is True and proof['origin_kind']==expected[position]
            assert patch['conclusion']==header['target'] and patch['exact_original_ordered_gamma']==header['context']['ordered_local_premises']
            assert patch['consumed_original_occurrence_indices']==[0,1,2]
            assert patch['kernel_result']['original_ground_sequent_accepted'] is True
            assert patch['kernel_result']['rows']==len(patch['commands'])==len(patch['primitive_keys'])==9
            assert [x['rule'] for x in patch['commands']].count('assumption')==3
            assert [x['rule'] for x in patch['commands']].count('eq_subst')==2
            assert [x['rule'] for x in patch['commands']].count('mp')==4
            assert result['trace_complete'] is True and result['logical_target_proof_accepted'] is True
            assert result['status']=='first_checked_original_Gamma_target_proof'
            assert result['actual_selected_target_proof_accepted'] is (expected[position]=='actual_selected')
            assert all(proof[k] is False for k in ('full24_board_accepted','native_accepted','full_trajectory_accepted','inventory_admitted','new_RL_training','universal_compiler_accepted'))
        else:
            assert resource['checked_logical_target_candidate'] is False and resource['logical_certificate'] is None
            assert result['status']=='unknown_trace_budget' and result['trace_complete'] is False
            assert result['first_checked_proof'] is None and result['logical_target_proof_accepted'] is False
            assert len(result['events'])==2000 and result['attempts']==90
        trials.append(dict(selector=lane['selector'],lane=lane['lane'],mode=lane['mode'],
            status=result['status'],ROOT_checked_logical_derivation_accepted=expected[position] is not None,
            origin_kind=expected[position],resource_disposition=pin(resource_path),result=resource['result'],
            logical_certificate=resource['logical_certificate'],qualified_context=resource['qualified_context'],
            exact_original_Gamma=header['context']['ordered_local_premises'],exact_target=header['target'],
            placements=result['attempts'],events=len(result['events']),trace_complete=result['trace_complete'],
            search_seconds=result['search_seconds_including_certificate_and_return_preparation'],
            caller_seconds_with_margin=resource['caller_seconds_with_margin'],owned_postwrite_seconds=resource['owner_postwrite_seconds'],
            conservative_peak_bytes=resource['conservative_owned_peak_bytes'],
            candidate_advice_construction=result['candidate_advice']['construction'],
            full24_board_accepted=False,native_accepted=False,independent_full_trajectory_accepted=False,
            new_RL_training=False,performance_comparison_accepted=False))
    value=dict(schema='ROOT-fresh-geometry-first-checked-proofs-disposition-v1',author_identity='/root',
        ROOT_final_accepted=True,scientific_calls_in_this_metadata_seal=0,
        actual_once_only_trials=4,restarts=0,complete_resources_accepted=4,
        checked_logical_derivations=3,distinct_original_hypothesis_sequents=2,
        selected_derivations=1,completed_unselected_source_proposals=2,preserved_UNKNOWN_trials=1,
        trials=trials,construction=pin(construction_path),independent_saved_audit=pin(review_path),
        source_only_readiness_is_not_mathematical_authority=True,
        mathematical_authority='Actual timed independent GroundChecker and literal point/current-union checks in the exact source-sealed observer; whole cold owned/caller resource closure for each trial. Saved evidence independently reconciled, without rerunning semantics.',
        proof_input_sequences_supplied=False,all_inventories_empty=True,preregistered_endpoint_unchanged=True,
        genuine_Hilbert_incidence_axiom_use_in_found_derivations=False,
        full24_board_accepted=False,native_accepted=False,independent_full_trajectory_accepted=False,
        learned_marking=False,new_RL_training=False,performance_comparison_accepted=False,
        universal_compiler_accepted=False,whole_plane_tiling_accepted=False,research_program_complete=False,
        provenance=pin(__file__),
        assessment='Two elementary equality-transport statements now have three automatically generated checked derivations, from selected point-tile ancestry or a current-compatible source-generated proposal. One canonical trial remains UNKNOWN at the2000-event trace ceiling. The adviser is conventional target-blind minimum-tree-cost AND-witness search, not RL; its proposals are not selected placements. These results establish this finite proof-search capability without supplied proof routes, not superiority, whole-board tilings, full Hilbert geometry, a universal tile set or the full research objective.')
    destination=HERE/'ROOT-actual-first-checked-geometry-proofs-v1.json'
    with destination.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps(dict(disposition=pin(destination),actual_trials=4,checked_derivations=3,distinct_sequents=2,UNKNOWN=1,scientific_calls_in_seal=0)))

if __name__=='__main__':main()
