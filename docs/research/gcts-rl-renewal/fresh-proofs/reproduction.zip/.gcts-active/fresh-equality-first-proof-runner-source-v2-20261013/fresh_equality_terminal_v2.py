"""SOURCE ONLY saved-terminal record adapter; no owner/worker/science dispatch.

Future ROOT metadata invocation only after the actual tool is terminal. It
rehashes closed artifacts and checks recorded exact scalar clocks/accounting.
It imports no project code, does not replay a search/checker, and issues no
universal OS/runtime/trajectory/RNG/performance qualification. Its own metadata
cost is additional and must be reported separately from the scientific phase.
"""
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import struct
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
LIMITS={'whole_seconds':180,'supervisor_seconds':175,'child_seconds':170,'peak_bytes':536870912}
SEARCH={'attempts':128,'seconds':20,'event_ceiling':2000}
RESERVE=33554432
FRAME=struct.Struct('!8sBBHQQddd')
MAX_JSON=64*1024*1024
# Filled by the source-only metadata freezer, never obtained from a runtime job.
WORKER = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runner-source-v2-20261013/fresh_equality_worker_v2.py', 'sha256': '14bfc7f89d8830cb278760cf2dbf8821316bb628aea891b589d59d1ae78b01e2', 'bytes': 58190}
OWNER = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runner-source-v2-20261013/fresh_equality_owner_v2.py', 'sha256': '1ce34ba1030481b1b05136e778172a49e15895ca5aa69ddddf8a085942dd810b', 'bytes': 46618}
WORKER_CONTRACT = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runner-source-v2-20261013/leaf-source-contract-v2.json', 'sha256': '60a5453212a72ee9c74164de7cc21079ad1a46518e9a6de7de731c096e948903', 'bytes': 15653}
HELPER = {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}
RECIPIENT_IDS = ('fresh-inc-point-chain-w', 'fresh-inc-reversed-line-chain')
DECLARATION_PROFILE = 'hilbert-first-checked-equality-cohort-static-v1'


EXPECTED_SOURCES = {'candidate_advice': {'bytes': 27264, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-incidence-priority-source-20261013/incidence_priority_witness_advice_v2.py', 'sha256': '3a86adba8982c406ae4a2ad3349b8ae962e52498dee38ee3ee26719b22468053'}, 'certificate': {'bytes': 64540, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/fresh_equality_context_and_final24_certificate_v3.py', 'sha256': '5d03d088c2d1b7f90e98fb7e28819ab0643b74f6786953c6107d4d2535c2377b'}, 'compact_decoder': {'bytes': 14720, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-compiler-source-20261012/compact_catalog_decoder_v1.py', 'sha256': '46e3b26a688d64665303238d7d8f3f9b54345cc98e17d903403ca1b62b9b0293'}, 'compact_graph': {'bytes': 42946, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/reversible-classification-row-mask-source-20261013/compact_point_graph_reversible_v4.py', 'sha256': 'c7af8a415670dd54a3177fda823a0c3fb0bbcc582e59125a974ea19de06748e6'}, 'dynamic_graph_adapter': {'bytes': 35568, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-batched-membership-source-20261013/compact_dynamic_graph_batched_v7.py', 'sha256': '4ff74a120327ed7e75ff844038e1c75650530c4434a2054b3c956264ea279423'}, 'dynamic_lifecycle_adapter': {'bytes': 29230, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-dynamic-source-20261012/compact_cluster_lifecycle_v2.py', 'sha256': '677c48c7aebfecf0c83c8daa8bf8e873d0be1e415906afa6687f0b9652e33719'}, 'features31': {'bytes': 12386, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-rl-small-source-20261012/family_graph_features_v1.py', 'sha256': '644e4cd195f98c1ca3f97c3fcba84dfdbc18765454512435702951cc6169a14b'}, 'logical_oracle': {'bytes': 24588, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-next-independent-oracles-source-20261013/hilbert_fresh_catalog_oracle_v2.py', 'sha256': '3b6aee8d9b0c1668f2ccf4e0d3b5e7e87dc9e0dd6579e55308e74c3992d6b3cc'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'point_core': {'bytes': 31300, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hilbert-primitive-executor-20261011/hilbert_primitive_graph_v2.py', 'sha256': 'e415664386b93cf9bbfeba92d6c35f40ca4cb25eb239de093134133b22c8adbd'}, 'policy_math': {'bytes': 11607, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/family-proposal-learning-20261012/family_policy_math_v2.py', 'sha256': '61b772b45ed4523ba4c14ae4519cd9dae53c21d4dc1b1681689011707831c294'}, 'proof_observer': {'bytes': 29654, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/first_checked_proof_observer_v5.py', 'sha256': 'b1a43eb13af0a15b8d4a9e89a0f9a586f444b0db3a23452e27ff9ace60e4bced'}, 'streamed_dfs': {'bytes': 42024, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runtime-source-20261013/compact_first_checked_proof_dfs_v11.py', 'sha256': 'a2cf1bb6d3ede1695d08f7c0d6f709bd5e9a6bc493ff06f1febe2fd4650269e4'}, 'streamed_overlay': {'bytes': 18033, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runner-source-20261013/fresh_observer_overlay_v1.py', 'sha256': '3ebe4e96ddce79e4e2e2bfa4bd845a26a1fe27ab1784842adbc526f6a0443065'}, 'streamed_proposal': {'bytes': 25358, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/cluster-transfer-compact-streamed-consumers-source-20261012/compact_cluster_proposal_v2.py', 'sha256': '1d094e7f51c7607cc121a48e0bc55f4daf2cc7801701eea34a2bb552f1505b38'}, 'transport': {'bytes': 13756, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/curriculum-compact-wrapper-source-20261012/compact_static_transport_v1.py', 'sha256': '65a0b598966ae4dffdda1b770eb2d4d5b64af1bcaf6aead4281a224a4123def3'}, 'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/fresh-equality-first-proof-runner-source-v2-20261013/fresh_equality_worker_v2.py', 'sha256': '14bfc7f89d8830cb278760cf2dbf8821316bb628aea891b589d59d1ae78b01e2', 'bytes': 58190}}

def need(value,label):
    if not value:raise ValueError(label)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def same(a,b,label):
    need(canonical(a)==canonical(b),label)


def fields(pairs):
    value={}
    for k,v in pairs:need(k not in value,'duplicate JSON field');value[k]=v
    return value


def parse(raw):
    return json.loads(raw,object_pairs_hook=fields,
        parse_constant=lambda name:(_ for _ in ()).throw(ValueError('nonfinite JSON '+name)))


def path_for(name):
    need(type(name) is str and str(Path(name))==name and '..' not in Path(name).parts,'exact lexical pin path')
    p=Path(name);return p if p.is_absolute() else ROOT/p


def pin(path,declared=None):
    path=Path(path);h=hashlib.sha256();count=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(65536),b''):h.update(block);count+=len(block)
    return {'path':str(path) if declared is None else declared,'sha256':h.hexdigest(),'bytes':count}


def verify(record):
    need(type(record) is dict and set(record)=={'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes']>=0,'strict closed raw pin')
    p=path_for(record['path']);same(pin(p,record['path']),record,'exact complete raw bytes');return p


def read(record):
    p=verify(record)
    with p.open('rb') as stream:raw=stream.read(MAX_JSON+1);need(stream.read(1)==b'','whole input no unread tail')
    need(len(raw)<=MAX_JSON and len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],
         'whole bounded same raw bytes')
    if p.name.endswith('.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
            raw=stream.read(MAX_JSON+1);need(len(raw)<=MAX_JSON and stream.read(1)==b'','whole bounded decoded metadata')
    value=parse(raw);verify(record);return value


def finite(value,label):
    need(type(value) in (int,float) and math.isfinite(value) and value>=0,label);return value


def integer(value,label):
    need(type(value) is int and value>=0,label);return value


def reconcile(owner_plan_pin,actual_terminal_pin):
    began=time.perf_counter();p=read(owner_plan_pin);actual=read(actual_terminal_pin)
    need(p['schema']=='ROOT-compact-fresh-equality-first-proof-owner-plan-v1'
         and type(p['selector']) is str and p['selector'] in RECIPIENT_IDS
         and p['mode'] in ('base', 'seed_forward') and p['phase']=='primitive-discovery',
         'exact frozen deterministic pair owner plan')
    same(p['owner_source'],OWNER,'same person-reviewed new owner source')
    same(p['limits'],LIMITS,'same complete owned budget');same(p['search_limits'],SEARCH,'same128/20/2000')
    need(p['reserve_bytes']==RESERVE,'same prospective32MiB reserve')
    for record in p['closure']:verify(record)
    leaf=read(p['worker_plan']);same(leaf['sources']['worker'],WORKER,'same reviewed frozen standalone leaf')
    verify(p['worker_activation']);q=read(p['qualified_context'])
    contract=read(WORKER_CONTRACT);abi=contract['prospective_ABIs']
    same(contract['sources'],{'worker':WORKER,'certificate':HELPER,'proof_observer':EXPECTED_SOURCES['proof_observer'],
         'streamed_overlay':EXPECTED_SOURCES['streamed_overlay']},'exact current SOURCE worker/helper pair')
    need(set(leaf)==set(abi['worker_plan_exact_fields']) and leaf['schema']==abi['worker_plan_schema']
         and leaf['selector']==p['selector'] and leaf['mode']==p['mode']
         and set(q)==set(abi['qualification_exact_fields'])
         and q['schema']==abi['qualification_schema'] and q['instance_id']==p['selector']
         and q['declaration_profile']==DECLARATION_PROFILE
         and q['status']=='accepted_complete_catalog_and_initial_point_model'
         and q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
         'same exact current actually admitted Hilbert source/context ABI')
    outer=read(p['outer_terminal_contract']);platform=read(p['platform_review'])
    need(verify(outer['record_adapter']).resolve()==Path(__file__).resolve(),
         'actual separately reviewed saved-terminal adapter source')
    need(actual['schema']=='ROOT-primitive-discovery-actual-tool-terminal-v1'
         and actual['terminal'] is True and actual['actual_invocations']==1
         and actual['external_wait4_claim'] is False,'trusted actual one-time tool terminal, no invented external wait4')
    same(actual['owner_plan'],owner_plan_pin,'actual exact owner plan')
    same(actual['prospective_contract'],p['outer_terminal_contract'],'same frozen prospective tool boundary')
    same(actual['literal_command'],outer['literal_owner_command'],'exact predeclared owner invocation')
    tool=actual['actual_tool']
    need(tool['exit_code']==0 and tool.get('session_id') is None,'terminal success with no live tool session')
    start=integer(actual['start_ms'],'actual start millisecond clock');end=integer(actual['terminal_observed_ms'],'actual terminal observation clock')
    need(end>=start,'nonnegative enclosing caller clock')
    bound=(end-start)/1000+1
    same(actual['enclosing_seconds_with_margin'],bound,'actual exact Date interval plus fixed1s margin')
    need(bound<=180 and finite(tool['wall_time_seconds'],'actual terminal wall')<=bound,'whole caller/terminal bound unchanged180s')
    directory=Path(p['owner_output_directory'])
    terminal_path=directory/'ROOT-terminal-v1.json';post_path=directory/'post-write-observation-v1.json'
    terminal_pin=pin(terminal_path);post_pin=pin(post_path)
    r=read(terminal_pin);post=read(post_pin)
    need(r['schema']=='ROOT-compact-fresh-equality-first-proof-owner-terminal-v1'
         and r['resource_gate_accepted'] is True and r['status']=='resource_candidate_pending_actual_ROOT_terminal'
         and r['error'] is None and r['cancelled'] is False and r['cleanup_errors']==[]
         and r['worker_returncode']==0 and r['worker_terminal_and_reaped'] is True
         and r['owned_leftovers']==[] and r['complete_post_closure_unchanged'] is True
         and r['all_observers_terminal_and_reaped'] is True,'complete successful closed owner candidate')
    same(r['plan'],owner_plan_pin,'exact candidate owner plan');same(r['owner'],OWNER,'exact candidate owner')
    same(r['worker_plan'],p['worker_plan'],'same actual leaf plan');same(r['worker_activation'],p['worker_activation'],'same activation')
    same(r['qualified_context'],p['qualified_context'],'same qualified original full context')
    same(r['limits'],LIMITS,'same actual resource limits')
    need(r['prospective_postlude_reserve_bytes']==RESERVE and r['write_reserve_seconds']==2,'same reserved serialization/postlude')
    need(post['schema']=='ROOT-primitive-discovery-post-write-v1' and post['resource_gate_accepted'] is True
         and post['actual_caller_terminal_required'] is True and post['postlude_reserve_bytes']==RESERVE,
         'complete post-write resource candidate, still caller dependent')
    same(post['terminal'],terminal_pin,'postwrite exact normalized terminal')
    need(verify(post['provisional']).read_bytes()==verify(terminal_pin).read_bytes(),'normalized hardlink bytes exactly provisional')
    same(post['limits'],LIMITS,'same postwrite caps')
    final=parse(tool['output'].strip())
    same(final,{'schema':'ROOT-primitive-discovery-owner-final-print-v1','resource_gate_accepted':True,
        'cancelled_at_final_print':False,'owner_elapsed_seconds':post['owner_elapsed_seconds'],
        'conservative_peak_bytes':post['conservative_peak_bytes'],'terminal':str(terminal_path)},
        'actual tool stdout authenticates final noncancelled print, not link alone')
    ledger=read(r['ownership_ledger'])
    need(ledger['source_trusted_host_filter'] is True and ledger['independent_whole_host_audit'] is False
         and ledger['leftovers']=={},'same conditional owned-filter scope')
    worker_pid=integer(r['worker_pid'],'owned workerPID');need(worker_pid>0,'positive owned PID')
    owner_pid=integer(r['owner_pid'],'actual ownerPID');need(owner_pid>0 and owner_pid!=worker_pid,'distinct positive owner identity')
    same(ledger['worker_pid'],worker_pid,'same actual ledger child')
    same(ledger['owner_pid'],owner_pid,'same actual ledger owner')
    births=ledger['retained_births']
    need(type(births) is dict and set(births)=={str(worker_pid)}
         and type(births[str(worker_pid)]) is str and births[str(worker_pid)],'retained direct-child birth only')
    observations=ledger['observers'];samples=ledger['samples']
    need(type(observations) is list and type(samples) is list and len(observations)==r['observer_count']
         and len(samples)==r['sample_count'] and 1<=len(observations)<=10000 and 1<=len(samples)<=10000,
         'whole observer/sample records, no accepted prefix')
    observer_peak=0;sample_peak=0;previous_elapsed=-1
    for i,x in enumerate(observations):
        need(x['index']==i and x['terminal_and_reaped'] is True and x['timed_out'] is False and x['returncode']==0,
             'every directly reaped observer successful')
        raw=finite(x['wait4_raw']['ru_maxrss'],'raw separate trusted-PS kernel peak')
        need(integer(x['kernel_peak_bytes'],'observerbytepeak')==int(raw),'Darwin rawbyte observer conversion')
        observer_peak=max(observer_peak,x['kernel_peak_bytes'])
        finite(x['elapsed_seconds'],'own observer duration')
    for i,x in enumerate(samples):
        need(x['index']==i and finite(x['owner_elapsed_seconds'],'sample ownerlocalclock')>=previous_elapsed,'complete monotone owner samples')
        previous_elapsed=x['owner_elapsed_seconds'];rows=x['owned_rows']
        need(set(rows)=={str(worker_pid)} and set(rows[str(worker_pid)])=={'ppid','pgid','rss_bytes','birth'}
             and rows[str(worker_pid)]['pgid']==worker_pid and rows[str(worker_pid)]['ppid']==owner_pid
             and rows[str(worker_pid)]['birth']==births[str(worker_pid)],
             'same fresh single-leaf ownedgroup topology')
        rss=sum(integer(row['rss_bytes'],'sample rawRSSbytes') for row in rows.values())
        observer_index=integer(x['observer_index'],'sample exact completed observer index')
        need(observer_index<len(observations)
             and x['observer_peak_bytes']==max(o['kernel_peak_bytes'] for o in observations[:observer_index+1])
             and rss==x['owned_rss_bytes'],'exact whole ownedRSS and sequential observer prefixmaximum')
        combined=integer(x['ROOT_peak_bytes'],'ownSELFSample')+rss+integer(x['observer_peak_bytes'],'observermax')
        need(combined==x['combined_bytes'],'independently reconstructed full sampled memory')
        sample_peak=max(sample_peak,combined)
    worker_peak=integer(r['worker_kernel_peak_bytes'],'whole reaped workerkernelpeak')
    raw_worker=finite(ledger['worker_wait4_raw']['ru_maxrss'],'raw direct worker kernelpeak')
    need(worker_peak==int(raw_worker)==ledger['worker_kernel_peak_bytes'],'exact Darwin worker peak, not rolled globalCHILDREN')
    same(observer_peak,r['observer_peak_bytes'],'all direct PS max, not sum or worker doublecount')
    conservative=max(integer(r['ROOT_peak_bytes'],'ownerpeak')+worker_peak+observer_peak,sample_peak)
    need(conservative==r['conservative_peak_bytes'],'reconstruct entire conservative separate scope')
    post_self=finite(post['post_write_ROOT_SELF_raw']['ru_maxrss'],'actual saved post-write ownSELF peak')
    need(post['post_write_ROOT_peak_bytes']==int(post_self)
         and post['conservative_peak_bytes']==max(conservative,int(post_self)+worker_peak+observer_peak),
         'independently reconstructed actual post-write rawSELF memory bound')
    finite(r['child_lifetime_seconds'],'actual owner Popen-to-wait4 duration')
    finite(r['owner_elapsed_before_receipt_seconds'],'actual local owner duration before receipt')
    finite(post['owner_elapsed_seconds'],'actual local owner postwrite duration')
    need(r['child_lifetime_seconds']<=LIMITS['child_seconds'] and r['owner_elapsed_before_receipt_seconds']+2<=175
         and r['owner_elapsed_before_receipt_seconds']<=post['owner_elapsed_seconds']<=175
         and post['owner_elapsed_seconds']<=bound and post['conservative_peak_bytes']>=conservative
         and post['conservative_peak_bytes']+RESERVE<=LIMITS['peak_bytes'],
         'same whole cold/supervisor/leafduration/postwrite memory/caller gates')
    raw=verify(r['worker_stdout']).read_bytes();need(len(raw)==52,'whole raw worker frame')
    magic,role,code,reserved,pid,rss,elapsed,start_clock,closed_clock=FRAME.unpack(raw)
    need(magic==b'GCTSCMP1' and role==1 and code==0 and reserved==0 and pid==worker_pid
         and all(math.isfinite(x) and x>=0 for x in (elapsed,start_clock,closed_clock))
         and closed_clock>=start_clock and abs((closed_clock-start_clock)-elapsed)<=0.000001
         and elapsed<=r['child_lifetime_seconds']+0.000001 and rss<=worker_peak,
         'independent frame decode/local subtraction/duration nesting; no clockorigin subtraction')
    same(r['worker_closed_SELF'],{'role':1,'exit_code':0,'pid':pid,'SELF_ru_maxrss_raw':rss,
        'elapsed_seconds':elapsed,'entry_monotone_clock':start_clock,'last_closed_monotone_clock':closed_clock,
        'terminal_frame':r['worker_stdout'],'clock_scope':'process_local_no_cross_process_absolute_comparison'},
        'exact full frame snapshot')
    w=read(r['worker_receipt']);verify(r['worker_stderr'])
    need(w['schema']==abi['receipt_schema'] and w['stage_completed'] is True
         and w['stage']=='primitive-discovery' and w['mode']==p['mode'] and w['selector']==p['selector']
         and w['full_resource_accepted'] is False and w['independent_full_trajectory_accepted'] is False
         and w['new_RL_training'] is False and w['RNG_draws']==0 and w['native_queries']==0
         and w['training_updates']==0 and w['proof_bonus_awarded'] is False,'whole exact narrow automatic leaf scope')
    same(w['plan'],p['worker_plan'],'same receipt plan');same(w['activation'],p['worker_activation'],'same exact activation')
    same(w['qualification'],p['qualified_context'],'same original static authority')
    same(w['worker'],WORKER,'same immutable reviewed new leaf')
    header=read(q['catalog']);dimensions=header['dimensions']
    need(type(dimensions) is dict and set(dimensions)=={'logical_rows','formula_count',
         'primitive_license_count','non_assumption_witness_count','source_body_count'}
         and all(type(v) is int for v in dimensions.values())
         and dimensions['logical_rows']==24 and dimensions['formula_count']>0
         and dimensions['primitive_license_count']>=3
         and dimensions['non_assumption_witness_count']==dimensions['primitive_license_count']-3
         and dimensions['source_body_count']==0,'whole actual selected census, empty inventory')
    same(w['qualified_dimensions'],dimensions,'complete actual current selected primitive grammar')
    same(w['complete_inventory_binding'],leaf['expected_inventory_binding'],'same complete empty inventory')
    same(w['consumer_binding'],leaf['consumer_binding'],'same full paired consumer closure')
    allowed={record['path']:record for record in leaf['sources'].values()}
    need(type(w['executed_project_source_ledger']) is list,'complete saved executable-source ledger')
    for origin in w['executed_project_source_ledger']:
        need(set(origin)=={'module_name','source_pin'} and type(origin['module_name']) is str
             and allowed.get(origin['source_pin']['path'])==origin['source_pin'],
             'only exact disclosed executable roles, including observer')
        verify(origin['source_pin'])
    root=Path(leaf['output_directory']);need(verify(w['result'])==root/'result-v1.json.gz','complete unchanged rawsearch result pin')
    positive=w['search_status']=='finite_exact_point_tiling'
    certificate=None
    if positive:
        need(w['trace_complete'] is True and w['final_certificate_checked'] is True,'complete positive actually checked certificate')
        certificate=read(w['certificate'])
        need(verify(w['certificate'])==root/'certificate-v1.json'
             and certificate['schema']=='independent-compact24-primitive-advice-pair-final-certificate-v1'
             and certificate['expected_mode']==p['mode'] and certificate['actual_mode']==p['mode']
             and certificate['status']=='accepted_independent_final_primitive_certificate'
             and certificate['instance_id']==p['selector']
             and certificate['complete_required_rows']==24 and certificate['selected_primitive_placements']==24
             and all(certificate[k] is True for k in ('original_ground_sequent_accepted','whole_t_and_remote_m_accepted',
                'all_selected_placement_identities_checked','all_selected_recipes_independently_symbolically_checked')),
             'actual unchanged independent finalhelper output, not newly checking logic in metadata adapter')
        same(certificate['qualification_pin'],p['qualified_context'],'same checked original theory/Gamma/target epoch')
        same(certificate['result_pin'],w['result'],'same whole automatic search output')
    elif w['search_status']=='first_checked_original_Gamma_target_proof':
        need(w['trace_complete'] is True and w['first_proof_checked'] is True
             and w['certificate'] is None and w['final_certificate_checked'] is False
             and w['first_proof_origin_kind'] in ('actual_selected','completed_source_proposal'),
             'timed logical proof stop is separate from positive fullboard tiling')
        need(verify(w['first_proof_certificate'])==root/'first-proof-certificate-v1.json'
             and not (root/'certificate-v1.json').exists(),'exact separate logical saved certificate')
        logical=read(w['first_proof_certificate']);patch=logical['checked_patch']
        need(logical['schema']=='fresh-equality-first-proof-saved-certificate-v1'
             and logical['metadata_binding_only_after_timed_check'] is True
             and logical['original_Gamma_target_sequent_accepted'] is True
             and patch['schema']=='first-checked-original-Gamma-target-primitive-patch-v1'
             and patch['original_Gamma_target_sequent_accepted'] is True
             and patch['primary_endpoint_eligible'] is True
             and patch['prospective_current_point_union_accepted'] is True
             and all(logical[k] is False and patch[k] is False for k in
                ('full24_board_accepted','native_accepted','full_trajectory_accepted')),
             'saved metadata preserves the timed mathematical check and all nonclaims')
        same(logical['qualification_pin'],p['qualified_context'],'logical certificate original qualification')
        same(logical['result_pin'],w['result'],'logical certificate whole saved tape')
        same(logical['observer_source'],EXPECTED_SOURCES['proof_observer'],'logical certificate timed observer source')
        same(logical['observer_review'],leaf['observer_review'],'logical certificate reviewed observer')
        same(logical['origin_kind'],w['first_proof_origin_kind'],'same actual selected versus proposed origin')
        same(patch['origin_kind'],logical['origin_kind'],'same inner and outer origin')
        same(logical['checked_patch_sha256'],hashlib.sha256(canonical(patch).encode('utf8')).hexdigest(),
             'entire checked patch binding, not a projected proof word')
        same(patch['patch']['exact_original_ordered_gamma'],header['context']['ordered_local_premises'],
             'every original Gamma occurrence retained')
        same(patch['patch']['conclusion'],header['target'],'exact fresh target')
        need(logical['actual_selected_target_accepted'] is (logical['origin_kind']=='actual_selected')
             and logical['completed_source_proposal_target_accepted'] is (logical['origin_kind']=='completed_source_proposal')
             and patch['actual_selected_target_accepted'] is logical['actual_selected_target_accepted'],
             'proposed certificate never counts as actually selected proof')
    else:
        need(w['search_status'] in ('unknown_search_budget','unknown_trace_budget','unknown_infrastructure_failure','exhausted_finite_marked_subtree')
             and w['certificate'] is None and w['final_certificate_checked'] is False
             and not (root/'certificate-v1.json').exists(),'UNKNOWN/exhausted result has no proof/certificate/bonus')
    if w['search_status']!='first_checked_original_Gamma_target_proof':
        need(w['first_proof_checked'] is False and w['first_proof_certificate'] is None
             and w['first_proof_origin_kind'] is None and not (root/'first-proof-certificate-v1.json').exists(),
             'nonlogical terminal has no accepted firstproof prefix')
    # All rechecks are metadata-only, additional after the completed scientific
    # phase. Never reinterpret a failed owner/caller gate or trim a raw result.
    for record in p['closure']:verify(record)
    for record in (owner_plan_pin,actual_terminal_pin,terminal_pin,post_pin,r['worker_receipt'],w['result'],r['ownership_ledger']):verify(record)
    if positive:verify(w['certificate'])
    if w['first_proof_checked']:verify(w['first_proof_certificate'])
    return {'schema':'ROOT-primitive-advice-pair-resource-and-final-certificate-disposition-v1',
        'status':'accepted_conditional_owned_primitive_discovery','resource_accepted':True,
        'automatic_primitive_final_certificate_accepted':positive,
        'checked_logical_target_candidate':w['first_proof_checked'],
        'logical_origin_kind':w['first_proof_origin_kind'],
        'logical_certificate':w['first_proof_certificate'],
        'actual_selected_logical_target_candidate':w['first_proof_origin_kind']=='actual_selected',
        'completed_source_proposal_target_candidate':w['first_proof_origin_kind']=='completed_source_proposal',
        'search_status':w['search_status'],'mode':p['mode'],
        'owner_plan':owner_plan_pin,'actual_terminal':actual_terminal_pin,'owner_terminal':terminal_pin,
        'post_write':post_pin,'worker_receipt':r['worker_receipt'],'result':w['result'],'certificate':w['certificate'],
        'qualified_context':p['qualified_context'],'owned_limits':LIMITS,'search_limits':SEARCH,
        'caller_seconds_with_margin':bound,'owner_postwrite_seconds':post['owner_elapsed_seconds'],
        'conservative_owned_peak_bytes':post['conservative_peak_bytes'],'prospective_reserve_bytes':RESERVE,
        'additional_metadata_reconciliation_seconds_before_disposition_write':time.perf_counter()-began,
        'source_trusted_owned_topology':True,'external_wait4_claim':False,'OS_hard_cap_claim':False,
        'whole_host_cap_claim':False,'independent_full_trajectory_accepted':False,'RNG_credit_update_accepted':False,
        'performance_comparison_accepted':False,'new_RL_training':False,'proof_bonus_awarded':False,
        'native_accepted':False,'all_five_qualification':False,'universal_compiler_accepted':False,
        'scope':'Conditional single owned fresh first-proof/fullboard/UNKNOWN scope. Timed observer mathematical proof patches retain explicit actual-selected or completed-source-proposal origin; a checked logical patch is not a completed24-row board. The separate finalcertificate kernel checks any real fullboard. This metadata adapter binds saved outputs without replaying search/logic. No fulltrajectory/RNG/learning/performance authority is issued. Metadata write/import/exit costs additional.'}


def main():
    need(len(sys.argv)==4,'saved ownerplan pin file, saved trusted actualterminal pin file, fresh disposition path')
    ownerplan_path=Path(sys.argv[1]);terminal_path=Path(sys.argv[2]);output=Path(sys.argv[3])
    need(output.is_absolute() and ROOT in output.parents and not output.exists(),'exclusive fresh metadata-only disposition')
    value=reconcile(pin(ownerplan_path),pin(terminal_path))
    with output.open('x') as stream:json.dump(value,stream,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False);stream.write('\n')


if __name__=='__main__':main()
