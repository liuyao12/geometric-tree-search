"""SOURCE ROOT-only fresh first-proof metadata constructor; no scientific imports.

No record is produced at import. A later explicit ROOT request and genuine
accepted static/control/review receipts are mandatory. Named JSON sites only;
historical pin values remain raw leaves. Emits no library or proof authority.
"""
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
AUTHOR='/root/arithmetic_induction'
MAX_METADATA=64*1048576
MAX_CLOSURE=4096
SEARCH=dict(attempts=128,seconds=20,event_ceiling=2000)
OWNED=dict(whole_seconds=180,supervisor_seconds=175,child_seconds=170,peak_bytes=536870912)
RECIPIENT_IDS=('fresh-inc-point-chain-w','fresh-inc-reversed-line-chain')
PROFILE='hilbert-first-checked-equality-cohort-static-v1'
VARIANTS=(('canonical','base'),('generic-incidence-ordering','seed_forward'))
def need(value,why):
    if not value:raise ValueError(why)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
def same(a,b,why):need(canonical(a)==canonical(b),why)

def path_for(name):
    need(type(name) is str and name and str(Path(name))==name and '..' not in Path(name).parts,'literal path, no traversal')
    p=Path(name);p=p if p.is_absolute() else ROOT/p
    if str(p)=='/Library/Developer/CommandLineTools/usr/bin/python3':
        target=Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3.9')
        need(p.is_symlink() and p.resolve()==target and p.samefile(target),'only historical same-file CLT alias')
        need(hashlib.sha256(p.read_bytes()).hexdigest()=='bdea59019a38eb6600cc9e71e984a97fedadc406448431281e7657030f54987e','unchanged exact alias bytes')
        return target
    need(p==p.resolve() and p.is_file() and not p.is_symlink(),'canonical existing regular raw file')
    return p

def pin(path,spelling=None):
    p=path_for(str(path));before=p.stat();h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b);n+=len(b)
    after=p.stat()
    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==
         (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'whole stable raw bytes')
    return dict(path=spelling or str(p),sha256=h.hexdigest(),bytes=n)

def verify(record):
    need(type(record) is dict and set(record)=={'path','sha256','bytes'} and type(record['bytes']) is int and record['bytes']>=0 and
         type(record['sha256']) is str and len(record['sha256'])==64 and all(x in '0123456789abcdef' for x in record['sha256']),
         'exact typed complete pin')
    p=path_for(record['path']);same(pin(p,record['path']),record,'entire raw pin')
    return p
def normal(record):return dict(record,path=str(verify(record)))

def pairs(items):
    d={}
    for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
    return d
def read(record):
    p=verify(record)
    with p.open('rb') as f:
        raw=f.read(MAX_METADATA+1);need(len(raw)<=MAX_METADATA and f.read(1)==b'','whole bounded JSON metadata')
    need(len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],'same parsed raw bytes')
    if p.name.endswith('.json.gz'):
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as f:
            raw=f.read(MAX_METADATA+1);need(len(raw)<=MAX_METADATA and f.read(1)==b'','whole bounded decoded named metadata')
    v=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
    verify(record);return v
def write(path,v):
    with path.open('xb') as f:f.write((json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n').encode())
    return pin(path)

def add(closure,v):
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:
            p=normal(v);need(p['path'] not in closure or closure[p['path']]==p,'one canonical raw identity per path')
            closure[p['path']]=p;need(len(closure)<=MAX_CLOSURE,'complete bounded closure; no trimming')
        else:
            for x in v.values():add(closure,x)
    elif type(v) is list:
        for x in v:add(closure,x)


def add_lexical(closure,v):
    """Preserve exact pin spelling; canonical counterpart is additive only.

    This recursively collects raw pin values from already named metadata, never
    decodes discovered filenames. Inputs.verify's lexical keys remain present.
    The finite manifest/global closure continues to use canonical add().
    """
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:
            verify(v)
            for p in (dict(v),normal(v)):
                need(p['path'] not in closure or closure[p['path']]==p,
                     'same lexical spelling has consistent complete raw identity')
                closure[p['path']]=p
                need(len(closure)<=MAX_CLOSURE,'complete lexical closure bound; no trimming')
        else:
            for x in v.values():add_lexical(closure,x)
    elif type(v) is list:
        for x in v:add_lexical(closure,x)

class NamedMetadata:
    """Explicit named read sites, never recursively decode discovered filenames."""
    def __init__(self,closure):self.closure=closure;self.lexical={};self.values={};self.roles=[]
    def named(self,role,record):
        add_lexical(self.lexical,record)
        p=normal(record);add(self.closure,p)
        if p['path'] not in self.values:
            self.values[p['path']]=read(p);add(self.closure,self.values[p['path']])
            add_lexical(self.lexical,self.values[p['path']])
        self.roles.append(dict(role=role,pin=p));return self.values[p['path']]

def static_context(n,q,roots,label):
    add_lexical(n.lexical,q);add(n.closure,q)
    header=n.named(label+'/catalog',q['catalog'])
    n.named('literal-static-profile',roots['profile'])
    for role,p in roots['upstream_reviews'].items():n.named('literal-upstream/'+role,p)
    for which in ('producer','independent'):
        phase=q[which]
        plan=n.named(label+'/'+which+'/plan',phase['plan'])
        for role in ('receipt','evidence'):n.named(label+'/'+which+'/'+role,phase[role])
        review=n.named(label+'/'+which+'/source-review',plan['source_review'])
        same(normal(review['static_profile_plan']),normal(roots['profile']),'exact named static reader profile')
        same(review['upstream_reviews'],roots['upstream_reviews'],'literal upstream source review roots')
        decision=n.named(label+'/'+which+'/ROOT-decision',phase['ROOT_decision'])
        need(decision['ROOT_final_accepted'] is True and decision['mismatches']==[] and
             len(decision['predicates'])==14 and all(x is True for x in decision['predicates'].values()),'accepted actual complete static resource chain')
        n.named(label+'/'+which+'/whole-owner-plan',decision['plan'])
        if which=='producer':
            terminal=n.named(label+'/'+which+'/owner-terminal',decision['owner'])
            n.named(label+'/'+which+'/owned-ledger',terminal['ownership_ledger'])
    return q,header

def review(n,record,source,scope,author,*,record_adapter=None):
    v=n.named('review/'+scope,record)
    need(v['source_only'] is True and v.get('source_ready',v.get('source_review_passed')) is True and
         v.get('all_checks_passed',True) is True and type(v['scientific_calls']) is int and v['scientific_calls']==0 and
         v.get('scientific_acceptance',False) is False,'explicit SOURCE-only positive review')
    need(v['author_identity']==author and type(v['reviewer_identity']) is str and v['reviewer_identity']!=author,
         'distinct SOURCE reviewer')
    if scope=='primitive-advice-pair-owner':
        same(normal(v['owner']),normal(source),'same exact reviewed owner source')
        need(type(record_adapter) is dict,'exact current owner terminal adapter review binding')
        same(normal(v['record_adapter']),normal(record_adapter),'same exact reviewed terminal adapter')
    else:
        need(record_adapter is None,'non-owner review has no borrowed terminal adapter')
        same(normal(v['source']),normal(source),'same exact reviewed source')
    if 'scope' in v:need(v['scope']==scope,'exact source-review scope')
    return v


def full_graph_binding(header,q,model_epoch,sources):
    """Literal scalar metadata projection of the unchanged dynamic graph G5.

    No graph, catalogue codec, licence or model is instantiated here. The cold
    worker independently reconstructs it and demands exact equality.
    """
    need(header['height']==24 and header['orientation']=='identity'
         and header['bodies']==header['complete_cluster_inventory']==[],'full24 and empty inventory')
    dimensions=header['dimensions']
    need(set(dimensions)=={'logical_rows','formula_count','primitive_license_count',
        'non_assumption_witness_count','source_body_count'} and all(type(x) is int for x in dimensions.values())
        and dimensions['logical_rows']==24 and dimensions['source_body_count']==0
        and dimensions['formula_count']>0 and dimensions['primitive_license_count']>=3
        and dimensions['non_assumption_witness_count']==dimensions['primitive_license_count']-3,
        'actual complete fresh census, never borrowed historical counts')
    boundary=header['boundary']
    need(boundary['required']==[[0,r] for r in range(24)]
        and boundary['root_generations']==[[0,r,0] for r in range(24)]
        and boundary['fixed_exterior_m']==[[1,r,-1] for r in range(-23,0)]
        and boundary['fixed_target_m']==[[1,23,header['target_code']]],'unchanged complete physical boundary')
    need(len(header['assumption_recipe_indices'])==len(header['context']['ordered_local_premises'])==3,
         'three exact occurrence-bound original Gamma roots')
    seeds=[[index,row,[]] for row,index in enumerate(header['assumption_recipe_indices'])]
    same(header['context_id'],digest(header['context']),'same exact original context digest')
    same(header['authority']['epoch'],digest({k:v for k,v in header['authority'].items() if k!='epoch'}),
         'same original authority metadata epoch')
    same(normal(q['catalog']),q['catalog'],'current canonical catalogue pin')
    g=dict(schema='sealed-compact-dynamic-graph-binding-v2',model_epoch=model_epoch,
      context_id=header['context_id'],formula_registry_sha256=header['formula_registry_sha256'],
      authority_epoch=header['authority']['epoch'],catalog_header_pin=q['catalog'],
      catalog_identity_sha256=digest(dict(header=q['catalog'],streams=header['streams'],codec=header['codec'])),
      complete_catalog_stream_pins=header['streams'],
      boundary_sha256=digest(dict(height=24,roots=[0]*24,
        fixed_marks=sorted(boundary['fixed_exterior_m']+boundary['fixed_target_m']),initial_selected=seeds)),
      source_bindings_sha256=digest(header['source_bindings']),
      runtime_source_bindings=[dict(role=r,**sources[r]) for r in sorted(
        ('point_core','compact_graph','compact_decoder','dynamic_graph_adapter','dynamic_lifecycle_adapter'))],
      marking_version='injective-formula-ordered-mp-offset-v1',orientation='identity',
      primitive_identity_relation='exact_original_complete_recipe_preimages_and_index_order',
      native_accepted=False,engine_authority_activated=False)
    return g,seeds

REQUEST_FIELDS={'schema','ROOT_authorized_metadata_construction','ROOT_authorized_four_once_lanes',
 'ROOT_source_review','independent_source_review','static_disposition','worker_review','owner_review',
 'helper_review','observer_review','consumer_ROOT_review','consumer_peer_review',
 'ROOT_observer_control_disposition','runtime','platform_review','fresh_destination'}
SCHEDULE=((RECIPIENT_IDS[0],'canonical','base'),(RECIPIENT_IDS[0],'generic-incidence-ordering','seed_forward'),
          (RECIPIENT_IDS[1],'generic-incidence-ordering','seed_forward'),(RECIPIENT_IDS[1],'canonical','base'))

def build(request_path):
    started=time.perf_counter();request_pin=pin(Path(request_path).resolve());r=read(request_pin)
    need(type(r) is dict and set(r)==REQUEST_FIELDS
         and r['schema']=='ROOT-fresh-equality-first-proof-metadata-request-v1'
         and r['ROOT_authorized_metadata_construction'] is True
         and r['ROOT_authorized_four_once_lanes'] is True,
         'explicit ROOT-only metadata/four prospective once-lane request, never scientific dispatch')
    self_pin=pin(__file__);contract_pin=pin(HERE/'metadata-source-contract-v1.json');contract=read(contract_pin)
    same(contract['adapter'],self_pin,'exact source-reviewed metadata constructor')
    dest=Path(r['fresh_destination'])
    need(dest.is_absolute() and dest==dest.resolve() and ROOT in dest.parents
         and dest.parts[len(ROOT.parts)]=='.gcts-active'
         and dest.name.startswith('fresh-equality-first-proof-progress-') and not dest.exists(),
         'exclusive fresh first-proof destination, no prior trial overwrite/restart')
    closure={};add(closure,[request_pin,r,contract_pin,contract,self_pin]);n=NamedMetadata(closure)
    add_lexical(n.lexical,[request_pin,r,contract_pin,contract,self_pin])
    review(n,r['ROOT_source_review'],self_pin,'fresh-equality-first-proof-metadata',AUTHOR)
    review(n,r['independent_source_review'],self_pin,'fresh-equality-first-proof-metadata',AUTHOR)
    runner=n.named('current-first-proof-leaf-contract',contract['runner_contract']);sources=runner['source_map']
    same(sources,contract['sources'],'same whole exact executable role map')
    need('proof_observer' in sources and not any(k in sources for k in
        ('advice_capsule','advice_static_reader','advice_candidates')),'empty-library first-proof sources only')
    review(n,r['worker_review'],sources['worker'],'primitive-advice-pair-worker',AUTHOR)
    review(n,r['owner_review'],contract['owner'],'primitive-advice-pair-owner',AUTHOR,
           record_adapter=contract['terminal'])
    review(n,r['helper_review'],sources['certificate'],'final-primitive-advice-pair-certificate-helper',
           '/root/hilbert_ordering_diagnosis')
    review(n,r['observer_review'],sources['proof_observer'],'first-checked-proof-observer',
           '/root/hilbert_ordering_diagnosis')
    for role in ('consumer_ROOT_review','consumer_peer_review'):
        review(n,r[role],sources['worker'],'primitive-advice-pair-worker',AUTHOR)
    same(normal(r['ROOT_observer_control_disposition']),contract['actual_observer_control_disposition'],
         'exact independently resource-closed current actual generic control gate')
    control=n.named('actual-generic-observer-conformance-ROOT',r['ROOT_observer_control_disposition'])
    need(control['schema']=='ROOT-first-checked-proof-observer-conformance-disposition-v1'
         and control['ROOT_final_accepted'] is True and control['all_controls_passed'] is True
         and control['scope']=='synthetic-observer-semantics-only'
         and control['fresh_target_proof_discovered'] is False,
         'actual bounded observer conformance is required, never SOURCE readiness or target proof')
    same(control['sources'],contract['observer_control_sources'],'exact currently reviewed observer control sources')
    n.named('actual-observer-control-worker-result',control['result'])
    same(normal(r['static_disposition']),contract['actual_static_disposition'],
         'literal current ROOT independently reconciled complete static acceptance')
    static=n.named('actual-complete-fresh-static-ROOT',r['static_disposition'])
    need(static['schema']=='ROOT-accepted-fresh-geometry-complete-static-contexts-v1'
         and static['all_four_complete_static_stages_accepted'] is True
         and static['case_ids']==list(RECIPIENT_IDS) and static['proof_searches']==0
         and static['checked_proof_certificates']==0,
         'two actual complete preparation+audit chains, no borrowed proof/search result')
    endpoint=n.named('ROOT-frozen-primary-endpoint',contract['endpoint_preregistration'])
    need(endpoint['schema']=='ROOT-fresh-equality-first-checked-proof-endpoint-preregistration-v1'
         and endpoint['case_ids']==list(RECIPIENT_IDS) and endpoint['inventory']==[]
         and endpoint['proposed_is_selected'] is False and endpoint['logical_proof_is_full24_board'] is False,
         'explicit fresh primary endpoint and selected/proposed/fullboard scope')
    runtime=r['runtime'];add_lexical(n.lexical,runtime)
    need(runtime['executable']=='/Library/Developer/CommandLineTools/usr/bin/python3'
         and runtime['python_version']==[3,9,6] and runtime['platform']=='darwin'
         and runtime['observer']['path']=='/bin/ps','unchanged pinned runtime/observer')
    contexts={}
    for case in RECIPIENT_IDS:
        entry=next(c for c in static['cases'] if c['id']==case)
        resources={x['stage']:x for x in entry['resources']}
        need(entry['static_qualification_accepted'] is True and set(resources)=={'preparation','replay'}
             and all(x['all14_resource_predicates'] is True for x in resources.values()),
             'exact accepted current per-case static/resource facts')
        q0=dict(schema='ROOT-qualified-compact-proof-context-v1',
          status='accepted_complete_catalog_and_initial_point_model',declaration_profile=PROFILE,instance_id=case,
          declaration_inputs=dict(fixture=runner['exact_fixture']),catalog=entry['producer']['catalog'],
          producer={**{k:entry['producer'][k] for k in ('plan','receipt','evidence')},
                    'ROOT_decision':resources['preparation']['ROOT_decision']},
          independent={**entry['independent'],'ROOT_decision':resources['replay']['ROOT_decision']},
          sources=runner['static_sources'],expected_consumer_source_binding=None,
          all_complete_catalog_licenses_and_initial24domains_accepted=True)
        q0,header=static_context(n,q0,contract['static_reader_metadata_roots'],case)
        need(q0['instance_id']==case and q0['declaration_profile']==PROFILE
             and q0['status']=='accepted_complete_catalog_and_initial_point_model'
             and q0['all_complete_catalog_licenses_and_initial24domains_accepted'] is True,
             'actual complete fresh case/profile licence and initial domain admission')
        same(q0['sources'],runner['static_sources'],'all current fresh static source roles')
        same(q0['declaration_inputs'],dict(fixture=runner['exact_fixture']),'whole exact fresh fixture')
        pr=n.named(case+'/producer-complete-receipt',q0['producer']['receipt'])
        g,seeds=full_graph_binding(header,q0,pr['model_epoch'],sources)
        consumer=dict(schema='ROOT-whole-streamed-consumer-source-binding-v1',graph_binding_sha256=digest(g),
          source_records=[dict(role=role,**sources[role]) for role in
            ('streamed_overlay','streamed_dfs','streamed_proposal','features31','policy_math','proof_observer')],
          ROOT_source_review_pin=normal(r['consumer_ROOT_review']),
          independent_source_review_pin=normal(r['consumer_peer_review']))
        q=copy.deepcopy(q0);q['expected_consumer_source_binding']=consumer
        same({k:v for k,v in q.items() if k!='expected_consumer_source_binding'},
             {k:v for k,v in q0.items() if k!='expected_consumer_source_binding'},
             'only exact reviewed consumer binding changes; static math/point admission preserved')
        contexts[case]=dict(original=q0,original_pin=r['static_disposition'],q=q,header=header,
                            graph=g,seeds=seeds,consumer=consumer)
    platform_base=n.named('current-owned-platform-source-review',r['platform_review'])
    need(platform_base['schema']=='ROOT-primitive-discovery-known-topology-platform-review-v1'
         and platform_base['source_only'] is True and platform_base['known_leaf_scope_reviewed'] is True
         and platform_base['closed52_postlude_scope_reviewed'] is True
         and platform_base['reserve_is_prospective_conditional'] is True,
         'current explicit known topology/postlude source review, never actual resource acceptance')
    same(normal(platform_base['worker']),sources['worker'],'platform exact fresh worker')
    same(normal(platform_base['owner']),contract['owner'],'platform exact fresh owner')
    for record in closure.values():verify(record)
    dest.mkdir();rows=[]
    for case in RECIPIENT_IDS:
        folder=dest/case;folder.mkdir();ctx=contexts[case]
        qpin=write(folder/'qualified-context-v1.json',ctx['q']);ctx['qpin']=qpin
        add_lexical(n.lexical,[qpin,ctx['q']]);add(closure,[qpin,ctx['q']])
    for case,lane,mode in SCHEDULE:
        ctx=contexts[case];folder=dest/case/lane;folder.mkdir();qpin=ctx['qpin'];g=ctx['graph'];consumer=ctx['consumer']
        pp=write(folder/'platform-review-v1.json',platform_base);add_lexical(n.lexical,[pp,platform_base])
        lp=folder/'worker-plan-v1.json';ap=folder/'worker-activation-v1.json';op=folder/'owner-plan-v1.json'
        outer=dict(schema='ROOT-primitive-discovery-prospective-terminal-contract-v1',selector=case,mode=mode,
          once_only=True,cold_inclusive=True,caller_limit_seconds=180,owned_limits=OWNED,
          worker=sources['worker'],owner_source=contract['owner'],record_adapter=contract['terminal'],
          clock_scope='One functions.exec lifetime with immediate same-handle polls; terminal Date.now before model resumption, plus one-second margin.',
          literal_worker_argv=[runtime['executable'],'-B',sources['worker']['path'],str(lp),str(ap)],
          literal_owner_command=[runtime['executable'],'-B',contract['owner']['path'],str(op)])
        outerpin=write(folder/'prospective-terminal-contract-v1.json',outer)
        body=[qpin,*[sources[k] for k in sorted(sources)]]
        epoch=digest(dict(graph=g,sources=body,bodies=[],version='whole-compact-cluster-lifecycle-v2'))
        inventory=dict(schema='ROOT-whole-compact-search-inventory-binding-v1',model_epoch=g['model_epoch'],
          catalog_identity_sha256=g['catalog_identity_sha256'],runtime_authority_sha256=digest(g),
          original_body_authority_epoch=epoch,whole_group_authority_epoch=epoch,
          original_source_body_inventory_sha256=digest([]),complete_descriptor_registry_sha256=digest([]),
          registered_whole_descriptor_count=0,qualified_dimensions=ctx['header']['dimensions'])
        leaf=dict(schema=runner['prospective_ABIs']['worker_plan_schema'],
          status='frozen_inputs_pending_separate_ROOT_activation',selector=case,phase='primitive-discovery',mode=mode,
          qualification=qpin,expected_inventory_binding=inventory,consumer_binding=consumer,sources=sources,
          runtime=runtime,resource_contract=dict(postlude_reserve_bytes=33554432,platform_review=pp,
            owner_source=contract['owner'],outer_terminal_contract=outerpin,caller_limit_seconds=180),
          source_review=normal(r['worker_review']),helper_review=normal(r['helper_review']),
          observer_review=normal(r['observer_review']),closure=[],output_directory=str(folder/'worker-output-v1'),
          ROOT_owned_once_only=True,owned_limits=OWNED,search_limits=SEARCH,body_source_bindings=dict(records=body))
        need(set(leaf)==set(runner['prospective_ABIs']['worker_plan_exact_fields']) and len(leaf)==20,
             'literal20-field empty-library leaf, no proof word/MF/route field')
        local=dict(closure);add_lexical(local,list(n.lexical.values()));add_lexical(local,[outerpin,outer,leaf])
        leaf['closure']=[local[k] for k in sorted(local)];leafpin=write(lp,leaf);add_lexical(local,leafpin)
        activation=dict(schema=runner['prospective_ABIs']['activation_schema'],authorized=True,plan=leafpin,
          qualification=qpin,source_review=leaf['source_review'],helper_review=leaf['helper_review'],
          observer_review=leaf['observer_review'],selector=case,mode=mode,phase='primitive-discovery',
          owned_limits=OWNED,search_limits=SEARCH,expected_inventory_binding_sha256=digest(inventory),
          consumer_binding_sha256=digest(consumer),no_supplied_proof_route=True,new_training=False,all_five_qualification=False)
        actpin=write(ap,activation);add_lexical(local,[actpin,activation])
        owner=dict(schema=contract['owner_schema'],status='frozen_once_only_pending_ROOT_owned_invocation',
          selector=case,mode=mode,phase='primitive-discovery',owner_source=contract['owner'],
          owner_review=normal(r['owner_review']),worker_plan=leafpin,worker_activation=actpin,qualified_context=qpin,
          outer_terminal_contract=outerpin,platform_review=pp,runtime=runtime,limits=OWNED,search_limits=SEARCH,
          reserve_bytes=33554432,closure=[],owner_output_directory=str(folder/'owner-output-v1'))
        need(len(owner)==18,'unchanged18-field scientific search owner, never generic10-field replay owner')
        add_lexical(local,owner);owner['closure']=[local[k] for k in sorted(local)];ownerpin=write(op,owner)
        rows.append(dict(selector=case,lane=lane,mode=mode,worker_plan=leafpin,worker_activation=actpin,
                         owner_plan=ownerpin,literal_owner_command=outer['literal_owner_command'],
                         logical_origin_not_predetermined=True,full24_board_accepted=False))
    for record in list(closure.values())+list(n.lexical.values()):verify(record)
    return write(dest/'ROOT-construction-v1.json',dict(schema='ROOT-fresh-equality-first-proof-metadata-construction-v1',
      adapter=self_pin,contract=contract_pin,request=request_pin,source_only_metadata_execution=True,
      project_imports=0,scientific_calls=0,target_searches=0,native_queries=0,new_RL_training=False,
      exact_preregistered_schedule=[list(row) for row in SCHEDULE],lanes=rows,
      qualified_contexts={case:contexts[case]['qpin'] for case in RECIPIENT_IDS},named_decoded_roots=n.roles,
      all_lemma_inventories_empty=True,no_mined_admission_created=True,
      original_static_disposition=r['static_disposition'],actual_observer_controls_ROOT=r['ROOT_observer_control_disposition'],
      metadata_seconds_before_report_write=time.perf_counter()-started,
      actual_logical_proof_or_fullboard_or_trajectory_accepted=False,
      scope='ROOT metadata binds current static/observer source admission only. Timed mathematical proof acceptance, selected/proposed origin, whole-board tiling and whole resources remain distinct subsequent gates.'))

if __name__=='__main__':
    need(len(sys.argv)==2,'one explicit ROOT metadata request, no proof/route arguments')
    print(json.dumps(build(sys.argv[1]),sort_keys=True),flush=True)
