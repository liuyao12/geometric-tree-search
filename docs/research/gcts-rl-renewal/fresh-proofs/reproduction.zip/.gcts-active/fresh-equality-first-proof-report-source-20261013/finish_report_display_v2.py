"""Additive publication display repair; scientific files and reader data unchanged."""
import copy
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PUBLIC=Path('docs/research/gcts-rl-renewal/fresh-proofs')
PUB=Path('/private/tmp/gcts-family-router-publish-20261010')

def pin(path):
    raw=Path(path).read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def write(path,raw):
    with Path(path).open('xb') as stream:stream.write(raw)

def main():
    parent_path=HERE/'ROOT-notebook155-task-file-manifest-v1.json'
    parent=json.loads(parent_path.read_bytes())
    for record in parent['files']:
        current=pin(PUB/record['path']);assert current['bytes']==record['bytes'] and current['sha256']==record['sha256']
    old=HERE/'public-report-v1';new=HERE/'public-report-display-v2';new.mkdir()
    viewer=ROOT/PUBLIC/'viewer.js';write(new/'viewer.js',viewer.read_bytes())
    manifest=json.loads((old/'source-archive-manifest.json').read_bytes())
    members=copy.deepcopy(manifest['members'])
    viewer_name=str(PUBLIC/'viewer.js');seen=False
    with zipfile.ZipFile(old/'reproduction.zip') as before,zipfile.ZipFile(new/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as after:
        for name in before.namelist():
            raw=viewer.read_bytes() if name==viewer_name else before.read(name)
            after.writestr(name,raw)
            if name==viewer_name:
                for record in members:
                    if record['archive_path']==name:record['source']=pin(viewer);seen=True
        source_name=str(Path(__file__).relative_to(ROOT));after.write(__file__,source_name)
        members.append(dict(archive_path=source_name,source=pin(__file__)))
    assert seen
    manifest.update(schema='ROOT-notebook155-source-archive-manifest-v2',members=members,
        archive=pin(new/'reproduction.zip'),prior_manifest=pin(old/'source-archive-manifest.json'),
        display_repair='LaTeX separator whitespace terminates the control word before a following symbol; measurement units moved into LaTeX. No formula AST, tile geometry, proof, trial, budget or raw evidence changed.')
    write(new/'source-archive-manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
    with zipfile.ZipFile(new/'reproduction.zip') as package:
        assert len(package.namelist())==len(members)+1
        for item in members:
            raw=package.read(item['archive_path']);assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
    final=copy.deepcopy(parent);final.update(schema='ROOT-notebook155-task-file-manifest-v2',
        prior_manifest=pin(parent_path),archive_project_members=len(members),display_repair_only=True)
    for name in ('viewer.js','reproduction.zip','source-archive-manifest.json'):
        source=new/name;record=pin(source)
        (PUB/PUBLIC/name).write_bytes(source.read_bytes())
        if name!='viewer.js':(ROOT/PUBLIC/name).write_bytes(source.read_bytes())
        for row in final['files']:
            if row['path']==str(PUBLIC/name):row.update(sha256=record['sha256'],bytes=record['bytes'])
    write(HERE/'ROOT-notebook155-task-file-manifest-v2.json',(json.dumps(final,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps(dict(scientific_calls=0,task_files=len(final['files']),archive_members=len(members),all_raw_evidence_unchanged=True)))

if __name__=='__main__':main()
