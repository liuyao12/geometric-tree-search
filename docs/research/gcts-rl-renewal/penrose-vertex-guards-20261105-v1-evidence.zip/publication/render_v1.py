"""Audit saved certificates and render the exact Penrose vertex report."""

from collections import Counter
import gzip
import hashlib
import json
from math import atan2, cos, pi, sin
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
STEM="penrose-vertex-guards-20261105-v1"
LABEL={"unmarked":"Unmarked","guarded":"Guarded"}


def pin(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def load(name):
    return json.loads((ROOT/name).read_bytes())


def compressed(name):
    with gzip.open(ROOT/name,"rt") as stream:
        return json.load(stream)


def audit():
    learn=load("data/learning-summary-v1.json")
    result=load("data/region-summary-v1.json")
    fixture=load("data/region-qualification-v1.json")
    assert learn["status"]=="CHECKED_EXACT_CONTACT_COHORT"
    assert result["status"]=="CHECKED_FIXED_VERTEX_COHORT" and fixture["status"]=="PASS"
    for obj in (learn,result,load("protocol-v1.json"),load("region-protocol-v1.json")):
        for name,p in obj.get("files",obj.get("pins",{})).items():
            assert pin(ROOT/name)==p,name
    contacts=compressed("data/contact-certificates-v1.json.gz")
    counts={s:dict(Counter(r["status"] for r in contacts if r["stratum"]==s)) for s in ("shared","nearby")}
    assert counts==learn["counts"] and len(contacts)==learn["requests"]
    assert len(load("data/rules-v1.json"))==learn["oriented_pair_footprints"]
    assert next(r for r in contacts if r["status"]=="NEGATIVE")==learn["sample_negative"]
    assert all(x["independent"]["status"]=="VERIFIED" for x in fixture["records"])
    assert [x["raw"]["status"] for x in fixture["records"]]==["POSITIVE"]*2+["NEGATIVE"]*2
    raw=compressed("data/region-traces-v1.json.gz")
    cases=load("input/region-cases-v1.json")
    assert cases==result["cases"] and len(cases)==8
    schedule=[(c["id"],m) for i,c in enumerate(cases)
              for m in (("unmarked","guarded") if i%2==0 else ("guarded","unmarked"))]
    assert [(r["case"],r["method"]) for r in raw]==schedule
    for row,entry in zip(result["rows"],raw,strict=True):
        r=entry["raw"]
        assert row==dict(case=entry["case"],method=entry["method"],admitted=entry["admitted"],
                         raw_status=r["status"],stats=r["stats"],search_seconds=r["seconds"],
                         stop=r["stop"],assurance=entry["independent"])
        assert row["admitted"]==(r["status"] if entry["independent"]["status"]=="VERIFIED" else "UNKNOWN")
    shared=next(r for r in contacts if r["stratum"]=="shared" and r["status"]=="POSITIVE")
    return learn,result,fixture,raw,shared


def embed(p):
    return (sum(a*cos(2*j*pi/5) for j,a in enumerate(p)),
            -sum(a*sin(2*j*pi/5) for j,a in enumerate(p)))


def geometry(layers, dots, label):
    coords=[embed(p) for tiles,_,_ in layers for tile in tiles for p in tile]+[embed(p) for p in dots]
    xs,ys=zip(*coords)
    box=f'{min(xs)-.2:.4f} {min(ys)-.2:.4f} {max(xs)-min(xs)+.4:.4f} {max(ys)-min(ys)+.4:.4f}'
    svg=[f'<svg viewBox="{box}" role="img" aria-label="{label}">']
    for tiles,fill,stroke in layers:
        for tile in tiles:
            ps=[embed(p) for p in tile]
            x,y=(sum(t[j] for t in ps)/4 for j in (0,1))
            ordered=sorted(ps,key=lambda a:atan2(a[1]-y,a[0]-x))
            vertices=" ".join(f"{a:.5f},{b:.5f}" for a,b in ordered)
            svg.append(f'<polygon points="{vertices}" fill="{fill}" fill-opacity=".65" stroke="{stroke}" stroke-width=".018"></polygon>')
    for x,y in map(embed,dots):
        svg.append(f'<circle cx="{x:.5f}" cy="{y:.5f}" r=".037" fill="#b32364"></circle>')
    return "".join(svg)+"</svg>"


def table(head,rows):
    return ('<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{x}</th>' for x in head)
            +'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)
            +'</tbody></table></div>')


def sectors(sample):
    occupied=sample["initial_mask"]
    legal=0
    for _,mask in sample["domain"]:
        legal |= mask
    circles=[]
    for i in range(10):
        a,b=i*pi/5,(i+1)*pi/5
        x,y,u,v=cos(a),-sin(a),cos(b),-sin(b)
        color="#25775c" if occupied>>i&1 else "#e0aa52" if legal>>i&1 else "#b35380"
        circles.append(f'<path d="M0 0 L{x:.5f} {y:.5f} A1 1 0 0 0 {u:.5f} {v:.5f} Z" '
                       f'fill="{color}" stroke="#fffdfa" stroke-width=".018"></path>')
    return '<svg viewBox="-1.1 -1.1 2.2 2.2" role="img" aria-label="Sector coverage of the negative certificate">'+''.join(circles)+'</svg>'


def render(learn,result,fixture,raw,shared):
    a,b=fixture["seeds"]
    positive=fixture["records"][0]["raw"]["witness"]
    zero=[0,0,0,0]
    colors=("#b6dbcd","#25775c","#efd6a4","#a96617","#dce1f2","#61729c")
    g,gs,o,os,f,fs=colors
    sample=learn["sample_negative"]
    assert [sample["root"],sample["other"]]==[a,b]
    figures=(
        ("A shared vertex can be filled",geometry([(shared["witness"],f,fs),([shared["root"]],g,gs),([shared["other"]],o,os)],[zero],"Checked shared-vertex completion"),
         "Green and ochre are the original pair. Blue rhombs complete the queried vertex."),
        ("A nearby blocker prevents closure",geometry([([a],g,gs),([b],o,os)],[zero],"Checked nearby obstruction"),
         "The ochre blocker has no corner at the magenta point."),
        ("Sectors in the negative certificate",sectors(sample),
         "Green is already occupied. Ochre is covered by at least one legal candidate. Violet sectors have no candidate."),
        ("A different target admits the pair",geometry([(positive[2:],f,fs),([a],g,gs),([b],o,os)],[fixture["fillable_point"]],"Checked witness at a different point"),
         "The magenta target moves to a corner of the blocker. The same two seeds can remain in the solution."),
    )
    panels=''.join(f'<figure><figcaption>{title}</figcaption>{svg}<p>{text}</p></figure>' for title,svg,text in figures)
    contacts=[]
    for name in ("shared","nearby"):
        c=learn["counts"][name]
        contacts.append([name.capitalize(),c.get("ILLEGAL",0),c.get("POSITIVE",0),c.get("NEGATIVE",0)])
    rows=[]
    summary=[]
    for method in LABEL:
        samples=[r for r in result["rows"] if r["method"]==method]
        status=Counter(r["admitted"] for r in samples)
        summary.append([LABEL[method],status["POSITIVE"],status["NEGATIVE"],status["UNKNOWN"],
                        sum(r["stats"]["visits"] for r in samples),
                        f'{sum(r["search_seconds"] for r in samples):.3f}'])
    for c in result["cases"]:
        vals=[]
        for method in LABEL:
            row=next(r for r in result["rows"] if r["case"]==c["id"] and r["method"]==method)
            vals.extend([row["admitted"].capitalize(),row["stats"]["visits"],f'{row["search_seconds"]:.3f}'])
        rows.append([c["id"],c["family"].capitalize(),len(c["points"]),*vals])
    exemplar=next(r for r in raw if r["case"]=="P04" and r["method"]=="guarded")
    assert exemplar["admitted"]=="POSITIVE"
    pts=next(c["points"] for c in result["cases"] if c["id"]=="P04")
    patch=geometry([(exemplar["raw"]["witness"][1:],f,fs),(exemplar["raw"]["witness"][:1],g,gs)],
                   pts,"Independently checked P04 slit-region witness")
    return HEAD+f'''
<section id="contacts"><h2>What a vertex can certify</h2>
{table(("Second tile","Illegal contact","Vertex fillable","Vertex impossible"),contacts)}
<p>The shared-vertex result has a direct explanation. The two seed sectors are disjoint.
Each remaining elementary sector can take the acute corner of a thin rhomb. Their interiors are
disjoint and adjacent sectors meet along full unit edges. A nearby tile outside the star can block
these completions.</p>
<p>The independent checker tested every row using cyclotomic multiplication and subset
dynamic programming. The {learn["negative"]} negative rows give
{learn["oriented_pair_footprints"]} distinct rotated pair-and-point entries. The guard activates
an entry when its translated obstruction point belongs to the required region.</p>
<div class="figures">{panels}</div></section>
<section id="regions"><h2>Eight fixed vertex targets</h2>
{table(("Method","Checked positive","Checked negative","Unresolved","Recorded visits","Search seconds"),summary)}
{table(("Case","Shape","Points","Unmarked outcome","Visits","Seconds","Guarded outcome","Visits","Seconds"),rows)}
<p>Both methods used the same exact pair legality, primitive candidate order and caps of 1,000
visits or four search seconds. Each run started with cold geometry caches. The measured
search includes guard lookups. Shared rule preparation took {result["rule_setup_seconds"]:.3f}
seconds. Visit limits remain unresolved. All checked positives and exhausted negatives passed a
separate verifier.</p>
<figure>{patch}<figcaption>P04, the checked guarded witness for the 46-point slit. Magenta dots mark
the prescribed vertices. The unmarked run reached 1,000 visits on this target.</figcaption></figure>
</section>
'''+END


HEAD=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Exact vertex guards for unmarked Penrose rhombs</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#16362e;--line:#cbd9cc;--paper:#f5f3e8}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1120px;padding:24px;margin:auto}header{padding:28px 0;max-width:830px}a{color:#166653}
h1{font:clamp(2rem,5vw,3.8rem)/1.08 Georgia,serif;margin:.5em 0}h2{font:1.7rem/1.15 Georgia,serif;margin:0 0 .55em}
section{background:#fffdfa;border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:18px}
.eyebrow{text-transform:uppercase;letter-spacing:.12em;font-size:.78rem}
.scroll{overflow-x:auto;margin:8px 0}table{border-collapse:collapse;width:100%;font-size:.88rem}
td,th{text-align:left;vertical-align:top;padding:7px;border-bottom:1px solid var(--line)}
.figures{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:10px}
figure{margin:8px 0;padding:10px;background:#edf5ee;border-radius:8px}
figcaption{font-weight:650}figure p{font-size:.88rem;margin:.5em 0}svg{display:block;width:100%;height:230px}
</style></head><body><main>
<header><p class="eyebrow">GCTS research · exact cyclotomic coordinates</p>
<h1>Vertex guards for unmarked Penrose rhombs</h1>
<p>Learn pair exclusions from failed vertex completions, then apply them on finite targets that
require the obstruction point. Both thin and thick rhombs start with their geometry only.
The solver receives no arrows, Ammann bars, or acceptance window.</p>
<p><a href="#contacts">Contact certificates</a> · <a href="#regions">Region comparison</a> ·
<a href="#evidence">Reproduce the experiment</a></p></header>
'''


END=r'''<section id="scope"><h2>Exact model and scope</h2>
<p>Each point is an integer tuple in the basis \((1,\zeta_5,\zeta_5^2,\zeta_5^3)\)
of \(\mathbb Z[\zeta_5]\). The ten rays are powers of \(-\zeta_5^3\).
For a ray \(u\), the signed projection of a point \(v\) is represented by
\(\operatorname{Im}(\bar u v)/\sin(\pi/5)\), a value in \(\mathbb Z[\varphi]\).
Order comparisons use integer signs and squares. The diagrams use floating-point projection.</p>
<p>A region here is a prescribed finite set of saturated corner sites. The outside is free,
and all rhombs must meet edge-to-edge where they touch. A completed witness covers the
neighborhood of every target vertex. Classical matching rules, plane existence, and
substitution are separate questions.</p>
</section>
<section id="evidence"><h2>Experiment records</h2>
<p><a href="penrose-vertex-guards-20261105-v1-evidence.zip">Full evidence archive</a> ·
<a href="penrose-vertex-guards-20261105-v1-manifest.json">Archive manifest</a> ·
<a href="penrose-vertex-guards-20261105-v1-results.json">Audited results</a> ·
<a href="turtle/guarded-regions-20261105-v1.html">Earlier Turtle region comparison</a></p>
</section></main></body></html>
'''


def main():
    learn,result,fixture,raw,shared=audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(render(learn,result,fixture,raw,shared))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(dict(status="PASS_SAVED_EVIDENCE_AUDIT",learning=learn,regions=result,qualification=fixture),
                  f,sort_keys=True,separators=(",",":"))
        f.write("\n")


if __name__=="__main__":
    main()
