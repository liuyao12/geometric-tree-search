"""Compare unmarked and footprint-guarded fixed vertex targets."""

from collections import defaultdict
from functools import lru_cache
import gzip
from itertools import combinations
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
from learn_v1 import ROOT, pin, read, save, verify
import model_v1 as model
import check_v1 as independent


def frozen_rules():
    result=read("data/learning-summary-v1.json")
    assert result["status"]=="CHECKED_EXACT_CONTACT_COHORT"
    assert all(pin(ROOT/k)==v for k,v in result["files"].items())
    with gzip.open(ROOT/"data/contact-certificates-v1.json.gz","rt") as stream:
        rows=json.load(stream)
    rules=set()
    donors=[]
    for row in rows:
        if row["status"]!="NEGATIVE":
            continue
        a,b=(tuple(map(tuple,row[k])) for k in ("root","other"))
        donors.append((a,b))
        for ray in independent.RAYS:
            left,right=sorted(tuple(sorted(independent.multiply(ray,p) for p in t)) for t in (a,b))
            origin=left[0]
            rules.add((tuple(independent.minus(p,origin) for p in left),
                       tuple(independent.minus(p,origin) for p in right),
                       independent.minus(independent.ORIGIN,origin)))
    assert len(donors)==result["negative"]
    stored={(tuple(map(tuple,a)),tuple(map(tuple,b)),tuple(p)) for a,b,p in read("data/rules-v1.json")}
    assert stored==rules
    return donors,stored


@lru_cache(maxsize=50000)
def relative_shape(tile):
    return tuple(model.sub(p,tile[0]) for p in tile)


def index(rules):
    groups=defaultdict(list)
    for a,b,p in sorted(rules):
        groups[a,tuple(model.sub(v,b[0]) for v in b),b[0]].append(p)
    return groups


def compiled_block(groups,target,a,b):
    a,b=sorted((a,b))
    offsets=groups.get((relative_shape(a),relative_shape(b),model.sub(b[0],a[0])),())
    return any(model.add(p,a[0]) in target for p in offsets)


def direct_block(rule_set,target,a,b):
    a,b=sorted((a,b))
    anchor=a[0]
    x=tuple(independent.minus(p,anchor) for p in a)
    y=tuple(independent.minus(p,anchor) for p in b)
    return any((x,y,independent.minus(p,anchor)) in rule_set for p in target)


def author_cases():
    cases=[]
    for name,width,r in (("grid",2,1),("grid",2,2),("slit",1,2),("slit",2,3),
                         ("islands",1,2),("islands",2,3),("shifted",2,1),("shifted",1,2)):
        u,v=model.DIRECTIONS[0],model.DIRECTIONS[width]
        root=model.rhomb(model.ZERO,0,width)
        def grid(i,j):
            return tuple(i*a+j*b for a,b in zip(u,v))
        points={grid(i,j) for i in range(-r,r+1) for j in range(-r,r+1)
                if (name!="slit" or i!=0 or j in (-r,r))
                and (name!="islands" or abs(i)>1 or j==0)} | set(root)
        if name=="shifted":
            points.add(model.add(grid(r,1),model.DIRECTIONS[(width+3)%10]))
        cases.append(dict(id=f"P{len(cases)+1:02d}",family=name,width=width,scale=r,
                          points=sorted(points),seeds=[root]))
    return cases


def search(target,seeds,groups,limits):
    started=time.perf_counter()
    model.clear_geometry()
    relative_shape.cache_clear()
    target=frozenset(target)
    stats=dict(visits=0,branches=0,guard_removed=0,contact_checks=0,best_filled=0)
    solved=None
    hit=None
    footprints=groups is not None
    anchors={p:tuple(sorted(model.incident(p))) for p in target}
    prefix=list(seeds)
    totals=defaultdict(int)
    assert all(model.legal_contact(a,b) for a,b in combinations(seeds,2))
    for t in seeds:
        for p in t:
            totals[p] |= model.incident(p)[t]

    def visit():
        nonlocal solved,hit
        if stats["visits"]>=limits["visits"] or time.perf_counter()-started>=limits["seconds"]:
            hit="visits" if stats["visits"]>=limits["visits"] else "seconds"
            return {"status":"UNKNOWN","reason":hit}
        stats["visits"]+=1
        if len(prefix)==len(seeds) and footprints and any(compiled_block(groups,target,a,b) for a,b in combinations(seeds,2)):
            return {"status":"NEGATIVE","kind":"seed-cut"}
        open_points=sorted(p for p in target if totals[p]!=model.FULL)
        stats["best_filled"]=max(stats["best_filled"],len(target)-len(open_points))
        if not open_points:
            solved=tuple(prefix)
            return {"status":"POSITIVE","kind":"complete"}
        legality={}
        options=[]
        for p in open_points:
            domain=[]
            for t in anchors[p]:
                if t not in legality:
                    stats["contact_checks"]+=1
                    compatible=all(model.legal_contact(t,a) for a in prefix)
                    if compatible and footprints and any(compiled_block(groups,target,a,t) for a in prefix):
                        stats["guard_removed"]+=1
                        compatible=False
                    legality[t]=compatible
                if legality[t]:
                    domain.append(t)
            if not domain:
                return {"status":"NEGATIVE","kind":"dead","point":p}
            options.append((len(domain),p,domain))
        count,p,domain=min(options,key=lambda a:(a[0],a[1]))
        stats["branches"]+=int(count>1)
        children=[]
        for t in domain:
            prefix.append(t)
            trail=[]
            for q in t:
                trail.append((q,totals[q]))
                mask=model.incident(q)[t]
                assert not totals[q]&mask
                totals[q] |= mask
            result=visit()
            children.append([t,result])
            for q,before in trail:
                totals[q]=before
            prefix.pop()
            if result["status"]!="NEGATIVE":
                break
        return dict(status=result["status"],kind="branch",point=p,domain=domain,children=children)

    tree=visit()
    return dict(status=tree["status"],tree=tree,stats=stats,witness=solved,stop=hit,
                seconds=time.perf_counter()-started)


def assure(target,seeds,rules,raw,limits):
    start=time.perf_counter()
    R=frozenset(target)
    if raw["status"]=="UNKNOWN":
        assert raw["stop"] in ("seconds","visits")
        return dict(status="UNKNOWN",seconds=time.perf_counter()-start)
    if raw["status"]=="POSITIVE":
        placed=raw["witness"]
        assert placed[:len(seeds)]==tuple(seeds) and len(set(placed))==len(placed)
        assert all(independent.contact(a,b) and (not rules or not direct_block(rules,R,a,b))
                   for a,b in combinations(placed,2))
        assert all(sum(independent.corners(p).get(t,0).bit_count() for t in placed)==10 for p in R)
        return dict(status="VERIFIED",scope="EXACT_FINITE_WITNESS",seconds=time.perf_counter()-start)
    nodes=0

    @lru_cache(maxsize=150000)
    def allowed(a,b):
        return independent.contact(a,b) and (not rules or not direct_block(rules,R,a,b))

    def replay(prefix,node):
        nonlocal nodes
        nodes+=1
        if time.perf_counter()-start>=limits["assurance_seconds"]:
            raise TimeoutError
        assert node["status"]=="NEGATIVE"
        if node["kind"]=="seed-cut":
            assert tuple(prefix)==tuple(seeds) and rules and any(direct_block(rules,R,a,b) for a,b in combinations(prefix,2))
            return
        if node["kind"]=="dead":
            p=node["point"]
            assert p in R and sum(independent.corners(p).get(t,0).bit_count() for t in prefix)<10
            assert not any(all(allowed(*sorted((a,c))) for a in prefix) for c in independent.corners(p))
            return
        assert node["kind"]=="branch"
        p=node["point"]
        assert p in R and sum(independent.corners(p).get(t,0).bit_count() for t in prefix)<10
        domain=sorted(c for c in independent.corners(p) if all(allowed(*sorted((a,c))) for a in prefix))
        assert domain==node["domain"]==[c for c,_ in node["children"]] and domain
        for c,child in node["children"]:
            replay(prefix+[c],child)

    try:
        replay(list(seeds),raw["tree"])
    except TimeoutError:
        return dict(status="UNKNOWN",scope="ASSURANCE_WALL",nodes=nodes,seconds=time.perf_counter()-start)
    return dict(status="VERIFIED",scope="EXHAUSTED_FINITE_TREE",nodes=nodes,seconds=time.perf_counter()-start)


def qualification(donors,rules,groups,limits):
    for a,b in donors:
        for p in b:
            translated=[tuple(sorted(model.sub(q,p) for q in t)) for t in (b,a)]
            local=model.complete(*translated)
            if local["status"]=="POSITIVE" and not direct_block(rules,{p},a,b):
                assert compiled_block(groups,{model.ZERO},a,b) and not compiled_block(groups,{p},a,b)
                records=[]
                for R,want in (([p],"POSITIVE"),([model.ZERO],"NEGATIVE")):
                    for name,guard,check in (("unmarked",None,set()),("guarded",groups,rules)):
                        raw=search(R,[a,b],guard,limits)
                        receipt=assure(R,[a,b],check,raw,limits)
                        assert raw["status"]==want and receipt["status"]=="VERIFIED"
                        records.append(dict(target=R,method=name,raw=raw,independent=receipt))
                return dict(status="PASS",seeds=[a,b],fillable_point=p,obstruction=model.ZERO,records=records)
    raise AssertionError("A boundary qualification witness is required")


def main():
    protocol=read("region-protocol-v1.json")
    assert protocol["schema"]=="Penrose-guarded-vertex-regions-frozen-v1"
    verify(protocol)
    limits=protocol["limits"]
    cases=author_cases()
    assert json.loads(json.dumps(cases))==read("input/region-cases-v1.json")
    started=time.perf_counter()
    donors,rules=frozen_rules()
    groups=index(rules)
    preparation=time.perf_counter()-started
    fixtures=qualification(donors,rules,groups,limits)
    save("data/region-qualification-v1.json",fixtures)
    print(json.dumps(dict(stage="QUALIFICATION",status="PASS",cases=len(fixtures["records"]))),flush=True)
    records=[]
    for i,case in enumerate(cases):
        arms=[("unmarked",None,set()),("guarded",groups,rules)]
        for name,guard,check in (arms if i%2==0 else arms[::-1]):
            raw=search(case["points"],case["seeds"],guard,limits)
            receipt=assure(case["points"],case["seeds"],check,raw,limits)
            row=dict(case=case["id"],method=name,raw=raw,independent=receipt,
                     admitted=raw["status"] if receipt["status"]=="VERIFIED" else "UNKNOWN")
            records.append(row)
            print(json.dumps(dict(case=case["id"],method=name,status=row["admitted"],
                     seconds=raw["seconds"],**raw["stats"])),flush=True)
    with (ROOT/"data/region-traces-v1.json.gz").open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",filename="",mtime=0) as out:
            out.write((json.dumps(records,sort_keys=True,separators=(",",":"))+"\n").encode())
    verify(protocol)
    summary=[dict(case=r["case"],method=r["method"],admitted=r["admitted"],
                  raw_status=r["raw"]["status"],stats=r["raw"]["stats"],
                  search_seconds=r["raw"]["seconds"],stop=r["raw"]["stop"],
                  assurance=r["independent"]) for r in records]
    save("data/region-summary-v1.json",dict(status="CHECKED_FIXED_VERTEX_COHORT",cases=cases,rows=summary,
        rule_setup_seconds=preparation,files={n:pin(ROOT/n) for n in (
            "region-protocol-v1.json","data/region-qualification-v1.json","data/region-traces-v1.json.gz")}))


if __name__=="__main__":
    main()
