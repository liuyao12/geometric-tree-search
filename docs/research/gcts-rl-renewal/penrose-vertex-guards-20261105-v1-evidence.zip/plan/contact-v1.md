# Unmarked Penrose rhomb vertex certificates

Use unit thin and thick rhombs with edge directions given by powers of
\(\rho=-\zeta_5^3\). Store coordinates in the integer basis
\((1,\zeta_5,\zeta_5^2,\zeta_5^3)\). Legal contacts have empty intersection,
one common vertex, or one entire common side. The model receives shapes and
corner angles, with no Ammann bars, arrows, windows, or target tiling.

Fix the queried vertex at the origin. For each width from one through four
sectors, fix its first seed ray at direction zero. The shared stratum places a
second tile incident to the origin. The nearby stratum places a second tile
with a corner one unit step away and no corner at the origin. Deduplicate exact
vertices within each stratum and classify every distinct requested pair.

After exact geometry rejects illegal seed pairs, complete the queried vertex.
There are exactly forty rhombs incident to a point. A legal candidate occupies
a contiguous mask of sectors and is individually compatible with both seeds.
Disjoint sector masks guarantee that incident convex rhombs have disjoint
interiors. Adjacent sectors share a full unit side, so no further constraint
among incident candidates is required. A first-empty-sector recursion checks
all possibilities up to ten occupied sectors. Its negative rows supply
one-point saturation certificates.

The independent checker constructs corners from unordered direction pairs,
calculates projections through cyclotomic multiplication and conjugation, and
uses an iterative subset dynamic program. Check all row labels and positive
witnesses. Compile the exact negative pairs and queried point under all ten
rotations. A later search may apply the pair rule when it requires that
translated point to be filled. This is an unmarked edge-to-edge rhomb model.
The results concern a one-vertex relaxation and can rule out an extension;
successful rows give only a finite local witness.
