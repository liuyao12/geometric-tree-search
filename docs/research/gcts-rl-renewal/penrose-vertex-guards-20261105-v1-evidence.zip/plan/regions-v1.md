# Fixed exact vertex targets

Compare a common unmarked rhomb solver with the same solver plus the 78
checked donor rules. A rule can reject a geometrically legal pair only if
its translated obstruction point belongs to the required region. Compose
all ten rotations and compare the compiled rule set with an independent
cyclotomic multiplication construction. Target vertices are authored by
integer combinations of two edge directions with optional slits, islands
or a shifted point. They are distinct from the one-point donor cases. No
authoring tiling, window or known marking goes into the search.

Qualify a real pair from the donor catalogue on two single-point targets.
The pair must admit a checked positive witness at one queried point and a
checked negative at its obstruction point, in both search methods.

Eight literal targets, one identity seed each, two methods in alternating
order, and one run per method. Fixed per-run caps are four search seconds
or 1,000 visited states. Independent exhausted-tree replay has an eight
second cooperative limit. Search timing includes cold geometry caches,
domain construction and guarded candidate filtering. Shared compilation
and independent assurance have separate timings. Compare checked outcomes
and measured visits and time. A timed prefix remains unresolved.

The finite target requires full corner saturation at its declared points
and edge-to-edge pair legality everywhere. A polygon boundary is outside
the scope of these targets. Both rhomb types and all unit directions are
allowed. The trial measures exact failure transfer and practical search
costs in this unmarked model.
