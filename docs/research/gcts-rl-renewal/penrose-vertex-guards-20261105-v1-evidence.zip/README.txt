Exact Penrose vertex guards

Open report/penrose-vertex-guards-20261105-v1.html for the figures and
results. The two frozen protocols bind source, runtime, limits and inputs.
The full contact rows, region traces, independent receipts, and frozen
region declarations are included.

In a separate extracted copy, preserve the original data. Create an empty
data directory and run these commands with the pinned Python:

    python -I -S -B source/learn_v1.py
    python -I -S -B source/region_v1.py

The region protocol pins the exact saved learning summary, which contains
observed timing fields. To replay the published region experiment, restore
the archived learning summary, rule table and contact certificates before
running its driver. A newly timed learning run needs its own reviewed
region protocol. Timing cutoffs can vary.

The fixed-region target is a finite set of required vertex sites. It uses
both unmarked unit rhomb types and exact edge-to-edge contact. It supplies
no matching labels or preferred tiling.
