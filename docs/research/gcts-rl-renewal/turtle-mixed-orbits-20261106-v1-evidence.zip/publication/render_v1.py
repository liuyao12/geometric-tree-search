"""Draw the recovered Turtle production, interfaces, and strip stencil."""
from fractions import Fraction
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import Geometry
from cluster_v1 import Model, load
from collar_audit_v1 import freeze

STEM="turtle-mixed-orbits-20261106-v1"
def euclidean(p):
    x,y=p
    return x+y/2,sqrt(3)*y/2


class Diagram:
    def __init__(self,points,width=600,height=400,disk=None):
        x,y=map(list,zip(*(euclidean(p) for p in points)))
        if disk:
            center,radius=disk
            a,b=euclidean(center)
            x.extend((a-radius,a+radius))
            y.extend((b-radius,b+radius))
        self.w,self.h=width,height
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2
        self.scale=min((width-34)/(max(x)-min(x)),(height-34)/(max(y)-min(y)))

    def at(self,p):
        x,y=euclidean(p)
        u,v=self.center
        return self.w/2+(x-u)*self.scale,self.h/2-(y-v)*self.scale

    def poly(self,shape,cls,fill):
        points=" ".join(f"{a:.3f},{b:.3f}" for a,b in map(self.at,shape))
        return f'<polygon class="{cls}" points="{points}" fill="{fill}"/>'

    def lines(self,edges,cls):
        parts=[]
        for edge in sorted(edges):
            (x,y),(u,v)=map(self.at,edge)
            parts.append(f"M{x:.3f},{y:.3f}L{u:.3f},{v:.3f}")
        return f'<path class="{cls}" d="{"".join(parts)}"/>'

    def circle(self,center,radius,cls,*,pixels=False):
        x,y=self.at(center)
        r=radius if pixels else radius*self.scale
        return f'<circle class="{cls}" cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}"/>'

    def svg(self,title,content):
        return f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{escape(title)}">{content}</svg>'


A=("#98d0c3","#b4dbcf","#82bfb4")
B=("#f6d498","#eabf7a","#f1d8ab")
RECIPE=("#aad5c8","#b6cfe8","#c5daa6","#e3c2d6","#d1c4ee","#f3d598","#e8b58a")


def diagram(geom,pieces,title,width=640,height=420,seams=False):
    model=geom.model
    patch=tuple(sorted(t for part,_ in pieces for t in part))
    d=Diagram([p for t in patch for p in model.poly(t)],width,height)
    parts=[]
    boundaries=[]
    for part,color in pieces:
        parts.extend(d.poly(model.poly(t),"tile",color) for t in part)
        boundaries.append(geom.boundary(part))
    if seams:
        inner={(a,b) for j,border in enumerate(boundaries) for a,b in border
               if any((b,a) in other for other in boundaries[j+1:])}
        parts.append(d.lines(inner,"contact"))
    parts.append(d.lines(geom.boundary(patch),"macro-outline"))
    return d.svg(title,"".join(parts))


def collision_view(geom,example):
    first,second=example["pieces"]
    p,q=example["collision"]
    model=geom.model
    d=Diagram([xy for t in (*first,*second) for xy in model.poly(t)],600,340)
    content=[d.poly(model.poly(t),"tile blocker" if t==p else "tile","#8fbed6" if t==p else "#d9e7e9")
             for t in first]
    content.extend(d.poly(model.poly(t),"ghost" if t==q else "tile", "#f1ce87" if t==q else "#f4e2c8")
                   for t in second)
    content.append(d.circle(tuple(v/example["scale"] for v in example["sample"]),4.5,"collision",pixels=True))
    svg=d.svg("A rejected two-orbit placement with a certified overlap point","".join(content))
    return f'''<figure class="specimen">{svg}<figcaption>A different allowed contact proposes these two child placements. The highlighted tiles share the occupied point shown in red. That relative displacement can be excluded wherever the same oriented tile pair appears.</figcaption></figure>'''


def math(x):
    return r"\("+x+r"\)"


def row(n,layers,scores,minimum):
    layer=layers[str(n)]
    scored=scores[str(n)]
    fraction=Fraction(layer["best"]**2,3*(n+6))
    ratio=str(fraction.numerator) if fraction.denominator==1 else rf"\frac{{{fraction.numerator}}}{{{fraction.denominator}}}"
    columns=[layer["families"],3*(n+6),layer["best"],layer["totals"]["disjoint"],
             scored["counts"]["boundary_checks"]]
    markup="".join(f'<td class="nowrap">{v:,}</td>' for v in columns)+f'<td>{math(ratio)}</td>'
    css=' class="winner-row"' if n==minimum else ''
    return f'<tr{css}><th scope="row">{n}</th>{markup}</tr>'


def figure(svg,label):
    return f'<figure>{svg}<figcaption>{label}</figcaption></figure>'


def main():
    g=Geometry(Model(load("input/exact-point-model-v1.json")))
    deck=freeze(load("input/recovered-bank-v1.json"))
    analysis=freeze(load("data/closures-v1.json"))
    score=load("data/port-score-v1.json")
    production=freeze(load("data/production-v1.json"))
    audit=freeze(load("data/audit-v1.json"))
    minimum=production["selected_size"]
    chosen=production["parents"][0]["pieces"]
    colors=(*A,*B)
    result=diagram(g,list(zip(chosen,colors,strict=True)),"The recovered 72-tile triangle with child seams",700,465,True)
    parent=figure(result,"Recovered parent · 72 Turtles in six children")
    same_size=[r for r in deck["entries"] if len(r["patch"])==minimum]
    first=same_size[0]
    assert same_size[1]["id"]==production["family"]
    before=next(x for x in analysis["entries"] if x["id"]==first["id"])["representative"]
    comparison=figure(diagram(g,list(zip(before["pieces"],colors,strict=True)),
                               "Best parent from the individually shorter motif",600,340,True),
                      f'First motif by itself · best parent has {before["perimeter"]} exposed segments')
    comparison+=figure(diagram(g,list(zip(chosen,colors,strict=True)),
                                "Parent from the winning motif",600,340,True),
                       f'Second motif by itself · best parent has {production["perimeter"]} exposed segments')
    children=(*production["motif_pairs"],*production["strips"])
    ingredients=figure(diagram(g,list(zip(production["seed_pairs"],A,strict=True)),
                               "Six-tile seed split into three doublets",450,300),
                       "Six-tile seed · three doublets")
    ingredients+=figure(diagram(g,list(zip(children,RECIPE,strict=True)),
                                "Selected motif split into five doublets and two strips",450,300),
                        "Eighteen-tile motif · five doublets and two strips")
    word=production["alphabet"]["word"]
    path=production["alphabet"]["path"]
    ingredients+=figure(diagram(g,[((t,),A[0] if k==0 else B[0]) for t,k in zip(path,word,strict=True)],
                                "Four-tile strip with two letter orientations",450,300),
                        "Strip stencil · word "+math("".join(map(str,word))))
    template=(ROOT/"publication/notebook-v1.html").read_text()
    layers=audit["layers"]
    replacements=dict(STEM=STEM,PARENT=parent,COMPARISON=comparison,INGREDIENTS=ingredients,
                      COLLISION=collision_view(g,audit["collision_example"]),
                      TABLE="".join(row(n,layers,score["layers"],minimum) for n in sorted(map(int,layers))),
                      ALL_DIRECT=f'{sum(r["totals"]["disjoint"] for r in layers.values()):,}',
                      ALL_RANKED=f'{sum(r["counts"]["boundary_checks"] for r in score["layers"].values()):,}')
    for k,v in replacements.items():
        template=template.replace("%%"+k+"%%",v)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
