# Replay the mixed Turtle orbit search

Use Python 3.12 and its standard library. In an extracted copy, preserve
the supplied evidence and keep the comparison file outside the input
directory until the search and production extraction finish.

    mv data archived-data
    mkdir data
    mv input/comparison-v1.json comparison-held-back.json
    python3.12 -I -S -B source/mixed_orbits_v1.py
    python3.12 -I -S -B source/port_score_v1.py
    python3.12 -I -S -B source/production_v1.py
    mv comparison-held-back.json input/comparison-v1.json
    python3.12 -I -S -B source/orbit_audit_v1.py
    python3.12 -I -S -B publication/render_v1.py

The first two scripts enumerate the same contact candidates. One
checks every disjoint boundary. The other uses the exact interface
score to skip dominated boundary checks. The production script
extracts child and strip recipes from the selected placements.
The audit verifies the full relative displacement tables with
exact polygon geometry, compares all minima and ties, verifies one
representative per motif and all selected winners, and checks the
recovered strip stencil. The final comparison uses the held-back
reference coordinates.

The input bank is the compact six-tile seed from
`data/collars-v1.json` and the shared six-removal motif candidates
from `data/motifs-v1.json` in the preceding Turtle shape-only archive.
The current input numbers the candidates in that inventory's sorted
order and copies their exact tile placements and edge counts.

Use `publication/replay-v1.json` to compare deterministic results.
For the browser check, set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for
custom installations and run `node publication/check_v1.cjs`.
