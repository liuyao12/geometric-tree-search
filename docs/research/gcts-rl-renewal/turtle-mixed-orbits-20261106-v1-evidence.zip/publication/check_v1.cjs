const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-mixed-orbits-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 17);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator(".hero-production polygon.tile").count(), 72);
    assert.equal(await page.locator(".hero-production path.contact").count(), 1);
    assert.equal(await page.locator("#production .gallery svg").count(), 2);
    assert.equal(await page.locator("#ports .collision").count(), 1);
    assert.equal(await page.locator("#strips svg").count(), 3);
    assert.equal(await page.locator("#selection tbody tr").count(), 10);
    const winner = await page.locator("#selection .winner-row").innerText();
    assert(winner.includes("949,461") && winner.includes("63") && winner.includes("156"));
    if (!process.argv[2]) {
      await page.locator(".hero-production").screenshot({ path: path.join(__dirname, "parent-v1.png") });
      await page.locator("#strips .triple-grid").screenshot({ path: path.join(__dirname, "strip-v1.png") });
      await page.locator("#ports .specimen").screenshot({ path: path.join(__dirname, "collision-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_MIXED_TURTLE_PRODUCTION_READER", parentTiles: 72, comparisonPanels: 2,
      productionPanels: 3, sizeClasses: 10, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
