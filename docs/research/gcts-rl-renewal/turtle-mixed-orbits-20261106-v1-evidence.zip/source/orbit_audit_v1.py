"""Audit complete displacement marks, ranked boundary certificates, and productions."""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from cluster_v1 import Model, load, mat
from collar_audit_v1 import Audit, exposed, freeze, trial_shifts
from golden_geometry_v1 import area2, strip
from mixed_orbits_v1 import Join, add, oriented_variants, sub


def verify_displacements(audit,join):
    model=audit.model
    root=model.polygons[0]
    exact={}
    probes=0
    for h,poly in model.polygons.items():
        bad=set()
        for x,y in trial_shifts(root,poly):
            if audit.relative_overlap(0,h,x,y):
                bad.add((x,y))
            probes+=1
        exact[h]=bad
    for g,m in model.groups.items():
        inverse,=(i for i in model.groups if model.compose[i,g]==0)
        assert all(x*x+x*y+y*y==u*u+u*v+v*v for x,y in ((1,0),(0,1),(1,1)) for u,v in (mat(m,(x,y)),))
        for h in model.groups:
            expected={mat(m,d) for d in exact[model.compose[inverse,h]]}
            assert expected==join.collisions.base[g,h]
    return dict(root_polygon_tests=probes,relative_orientation_tables=len(join.collisions.base),
                distinct_root_collisions=sum(map(len,exact.values())))


def exact_ring(edges):
    next_node=dict(edges)
    assert next_node and len(next_node)==len(edges)
    assert set(next_node)==set(next_node.values())
    start=min(next_node)
    cur=next_node.pop(start)
    path=[start]
    while cur!=start:
        path.append(cur)
        cur=next_node.pop(cur)
    assert not next_node
    return tuple(path)


def verify_union(audit,patch,pieces,expected):
    g=audit.geom
    assert tuple(sorted(t for part in pieces for t in part))==patch
    assert len(set(patch))==len(patch)
    assert all(not audit.overlap(a,b) for a,b in combinations(patch,2))
    boundary=exposed(audit.model.poly(t) for t in patch)
    ring=exact_ring(boundary)
    assert len(boundary)==expected and area2(ring)==len(patch)*area2(audit.model.polygons[0])
    borders=[exposed(audit.model.poly(t) for t in p) for p in pieces]
    pairs={}
    for i,a in enumerate(borders):
        inverse={(v,u) for u,v in a}
        for j,b in enumerate(borders):
            if j>i:
                pairs[i,j]=len(inverse&b)
    active={0}
    while True:
        old=len(active)
        for (a,b),n in pairs.items():
            if n and (a in active or b in active):
                active.update((a,b))
        if len(active)==old:
            break
    assert len(active)==len(pieces)
    if len(pieces)==6 and len(pieces[0])==6:
        aa=pairs[0,1]
        bb=pairs[3,4]
        cross=[pairs[i,3] for i in range(3)]
        assert {pairs[0,1],pairs[0,2],pairs[1,2]}=={aa}
        assert {pairs[3,4],pairs[3,5],pairs[4,5]}=={bb}
        assert all(sorted(pairs[i,j] for i in range(3))==sorted(cross) for j in (4,5))
        assert len(boundary)==3*(len(borders[0])+len(borders[3]))-6*(aa+bb+sum(cross))
    return tuple((i,j,n) for (i,j),n in sorted(pairs.items()) if n)


def reference_match(geom,production,parents):
    ref=freeze(load("input/comparison-v1.json"))
    comparisons={"P0":production["doublet"],"T1":production["seed"],"P1":production["motif"]}
    assert all(geom.normalize(p)==geom.normalize(ref[k]) for k,p in comparisons.items())
    target=geom.normalize(ref["T2"])
    assert all(geom.normalize(p["patch"])==target for p in parents)
    assert geom.normalize(production["alphabet"]["path"])==geom.normalize(strip("0010"))
    return dict(doublet="P0",threefold_seed="T1",halfturn_motif="P1",parent="T2",strip_word="0010")


def verify_chain(audit,production):
    g=audit.geom
    seed=production["seed"]
    motif=production["motif"]
    strips=production["strips"]
    for shape,pieces in ((seed,production["seed_pairs"]),(motif,(*production["motif_pairs"],*strips))):
        verify_union(audit,shape,pieces,len(exposed(audit.model.poly(t) for t in shape)))
    for pair in (*production["seed_pairs"],*production["motif_pairs"]):
        assert g.normalize(pair)==production["doublet"]
    spec=production["alphabet"]
    stride=spec["stride"]
    letters=spec["letters"]
    canonical=tuple((g,x+i*stride[0],y+i*stride[1])
                    for i,k in enumerate(spec["word"]) for g,x,y in (letters[k],))
    assert canonical==spec["path"]
    assert all(audit.geom.normalize(p)==audit.geom.normalize(canonical) for p in strips)
    result=0
    for table in spec["pairs"]:
        a,b=(letters[table[k]] for k in ("left","right"))
        bound=table["checked_through"]
        first=audit.model.poly(a)
        second=audit.model.poly(b)
        d=next(i for i,x in enumerate(stride) if x)
        sign=1 if stride[d]>0 else -1
        assert max(sign*p[d] for p in first)<min(sign*p[d] for p in second)+(bound+1)*abs(stride[d])
        for row in table["checks"]:
            n=row["gap"]
            v=(b[0],b[1]+n*stride[0],b[2]+n*stride[1])
            overlap=audit.overlap(a,v)
            edges=exposed([audit.model.poly(v)])
            shared=sum((q,p) in edges for p,q in exposed([first]))
            assert (overlap,shared)==(row["overlap"],row["shared"])
            assert not overlap and (shared>0 if n==1 else shared==0)
            result+=1
    return result


def overlap_sample(audit,join,motif,parent):
    index,s,u=parent["address"]
    b=oriented_variants(audit.geom,motif)[index]
    b1=audit.geom.moved(b,join.turn)
    no_ab=join.collisions.blocked(join.anchor,b)
    ab=audit.geom.poses(join.anchor,b)-no_ab
    bb=audit.geom.poses(b,b1)-join.collisions.blocked(b,b1)
    options={sub(s,t) for t in ab if t!=s}|join.contacts_aa|{sub(sub(add(s,d),mat(join.matrix,s)),join.offset)
                                                             for d in bb}
    candidates=sorted(options-{u},key=lambda x:(sum(abs(a-b) for a,b in zip(u,x)),x))
    for wrong in candidates:
        _,pieces=join.patch(b,s,wrong)
        for i,a in enumerate(pieces):
            for j,right in enumerate(pieces[i+1:],i+1):
                for p in a:
                    for q in right:
                        if not audit.overlap(p,q):
                            continue
                        point=min(audit.geom.atoms(p)&audit.geom.atoms(q))
                        return dict(address=(index,s,wrong),valid_address=parent["address"],pieces=(a,right),
                                    collision=(p,q),sample=point,indices=(i,j),scale=audit.model.scale)
    raise AssertionError("No collision in the neighboring proposals")


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    audit=Audit(model)
    g=audit.geom
    raw=freeze(load("input/recovered-bank-v1.json"))
    result=freeze(load("data/closures-v1.json"))
    scored=freeze(load("data/port-score-v1.json"))
    made=freeze(load("data/production-v1.json"))
    join=Join(g,raw["seed"])
    assert result["turn"]==join.turn and result["origin"]==join.offset
    physical=verify_displacements(audit,join)
    layers={}
    checked=0
    for a,b in zip(raw["entries"],result["entries"],strict=True):
        motif=a["patch"]
        size=len(motif)
        assert (a["id"],size,a["perimeter"])==(b["id"],b["size"],b["perimeter"])
        assert b["variants"]==tuple(oriented_variants(g,motif))
        stage=layers.setdefault(size,dict(totals=Counter(),best=None,winners=[],families=0))
        stage["families"]+=1
        counts=b["counts"]
        stage["totals"].update(counts)
        assert counts.get("contact_assemblies",0)==sum(counts.get(k,0) for k in (
            "disjoint","anchor_collision","mate_collision","other_cross_collision"))
        assert counts.get("disjoint",0)==counts.get("multiple_boundary_loops",0)+counts.get("closed",0)
        placements=b["placements"]
        assert len(set(placements))==len(placements)==counts.get("closed",0)
        if not placements:
            assert b["representative"] is None
            continue
        p,i,s,u=min(placements)
        first=b["representative"]
        assert (first["patch"],first["pieces"])==join.patch(b["variants"][i],s,u)
        verify_union(audit,first["patch"],first["pieces"],p)
        checked+=1
        if stage["best"] is None or p<stage["best"]:
            stage["best"]=p
            stage["winners"]=[]
        if p==stage["best"]:
            stage["winners"].extend((a["id"],j,x,y) for q,j,x,y in placements if p==q)
    ranks=[]
    for size,stage in layers.items():
        score=scored["layers"][str(size)]
        assert score["best"]==stage["best"] and tuple(stage["winners"])==score["winners"]
        for k in ("contact_assemblies","disjoint"):
            assert score["counts"][k]==stage["totals"][k]
        assert score["counts"]["boundary_checks"]<=stage["totals"]["disjoint"]
        if stage["best"] is not None:
            ranks.append((Fraction(stage["best"]**2,3*(len(join.anchor)+size)),size))
    assert tuple(dict(size=n,value=(q.numerator,q.denominator)) for q,n in sorted(ranks))==scored["normalized_scores"]
    parent=made["parents"]
    assert made["family"] in {a["id"] for a in raw["entries"]}
    links=[]
    for row in parent:
        contact=verify_union(audit,row["patch"],row["pieces"],made["perimeter"])
        links.append(contact)
        assert sum(n>0 for i,j,n in contact if i==0 and j>=3)==1
    exemplar=overlap_sample(audit,join,made["motif"],parent[0])
    strips=verify_chain(audit,made)
    names=reference_match(g,made,parent)
    save("data/audit-v1.json",dict(status="AUDITED_MIXED_TURTLE_ORBITS_AND_LOCAL_PRODUCTIONS",
        displacement=physical,representatives=checked,checked_strips=strips,layers=layers,
        winning_contact_graph=links[0],collision_example=exemplar,reference=names))


if __name__=="__main__":
    main()
