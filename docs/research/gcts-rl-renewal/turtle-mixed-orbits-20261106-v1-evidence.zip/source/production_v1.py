"""Promote the selected assembly and infer smaller recipes from its raw placements."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from cluster_v1 import Model, load
from collar_audit_v1 import occurrences
from mixed_orbits_v1 import Join, add, freeze, oriented_variants, shift, sub
from port_score_v1 import interface


def components(geom,patch):
    graph={t:set() for t in patch}
    for a in patch:
        edge=geom.boundary((a,))
        for b in patch:
            if a<b and any((y,x) in geom.boundary((b,)) for x,y in edge):
                graph[a].add(b)
                graph[b].add(a)
    remain=set(patch)
    result=[]
    while remain:
        root=min(remain)
        waiting=[root]
        found={root}
        while waiting:
            node=waiting.pop()
            added=graph[node]-found
            waiting.extend(sorted(added))
            found|=added
        remain-=found
        result.append((found,graph))
    return result


def chain_paths(geom,patch):
    chains=[]
    for tiles,graph in components(geom,patch):
        endpoints=sorted(t for t in tiles if len(graph[t])==1)
        assert len(endpoints)==2 and all(len(graph[t])<=2 for t in tiles)
        path=[endpoints[0]]
        previous=None
        while path[-1]!=endpoints[1]:
            choices=graph[path[-1]]-{previous}
            next_tile,=choices
            previous=path[-1]
            path.append(next_tile)
        assert len(path)==len(tiles)
        chains.append(tuple(path))
    return chains


def normalize_word(geom,path):
    versions=[]
    for g in geom.model.groups:
        for seq in (path,path[::-1]):
            transformed=tuple(geom.model.action(g,t) for t in seq)
            x,y=transformed[0][1:]
            versions.append(shift(transformed,(-x,-y)))
    return min(versions)


def geometry_alphabet(join,paths):
    canonical={normalize_word(join.geom,p) for p in paths}
    path,=canonical
    a,b=next((x,y) for x,y in zip(path,path[1:]) if x[0]==y[0])
    stride=sub(b[1:],a[1:])
    groups={}
    for i,(g,x,y) in enumerate(path):
        offset=x-i*stride[0],y-i*stride[1]
        assert groups.setdefault(g,offset)==offset
    alphabet=tuple((g,*offset) for g,offset in sorted(groups.items()))
    word=tuple(next(j for j,t in enumerate(alphabet) if t[0]==g) for g,_,_ in path)
    d=next(j for j,x in enumerate(stride) if x)
    sign=1 if stride[d]>0 else -1
    pairs=[]
    for i,p in enumerate(alphabet):
        for j,q in enumerate(alphabet):
            poly_a=join.geom.model.poly(p)
            poly_b=join.geom.model.poly(q)
            upper=max(sign*v[d] for v in poly_a)
            lower=min(sign*v[d] for v in poly_b)
            length=max(1,(upper-lower)//abs(stride[d]))
            contacts=[]
            for k in range(1,length+1):
                z=add(q[1:],(k*stride[0],k*stride[1]))
                o=sub(z,p[1:])
                overlaps=o in join.collisions.base[p[0],q[0]]
                seam=interface(join.geom.boundary((p,)),join.geom.boundary((q,)))[
                    k*stride[0],k*stride[1]]
                contacts.append(dict(gap=k,overlap=overlaps,shared=seam))
            pairs.append(dict(left=i,right=j,checked_through=length,checks=contacts))
    return dict(path=path,stride=stride,letters=alphabet,word=word,pairs=pairs)


def main():
    deck=load("input/recovered-bank-v1.json")
    result=load("data/port-score-v1.json")
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    seed=freeze(deck["seed"])
    join=Join(geom,seed)
    size=result["normalized_scores"][0]["size"]
    winner=result["layers"][str(size)]
    bank={r["id"]:freeze(r["patch"]) for r in deck["entries"]}
    families={row[0] for row in winner["winners"]}
    family,=families
    b=bank[family]
    candidates=[]
    for _,i,s,u in winner["winners"]:
        variants=oriented_variants(geom,b)
        out,pieces=join.patch(variants[i],tuple(s),tuple(u))
        candidates.append(dict(address=(i,s,u),patch=out,pieces=pieces,key=geom.normalize(out)))
    only,={r["key"] for r in candidates}
    assert only
    smallest,=(p for p in bank.values() if len(p)==2)
    doublets=occurrences(geom,smallest,b)
    covered=set().union(*map(set,doublets))
    assert len(covered)==2*len(doublets)
    residue=set(b)-covered
    paths=chain_paths(geom,sorted(residue))
    alphabet=geometry_alphabet(join,paths)
    seed_pairs=occurrences(geom,smallest,seed)
    assert len(set().union(*map(set,seed_pairs)))==2*len(seed_pairs)==len(seed)
    save("data/production-v1.json",dict(status="RECOVERED_FINITE_CLUSTER_PRODUCTIONS",
         family=family,selected_size=size,score=result["normalized_scores"][0]["value"],
         perimeter=winner["best"],anchors=len(winner["winners"]),seed=seed,seed_pairs=seed_pairs,
         doublet=smallest,motif=b,motif_pairs=doublets,strips=paths,alphabet=alphabet,parents=candidates))


if __name__=="__main__":
    main()
