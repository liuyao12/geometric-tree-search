"""Independent raw/AST review record authoring only; no reviewed source call."""
from pathlib import Path
import ast
import hashlib
import json
import symtable
import builtins

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SUBJECT=ROOT/'.gcts-active/arithmetic-Q-rank-certificate-source-20261014'
REVIEWER='/root/hilbert_ordering_diagnosis'
AUTHOR='/root/hilbert_advice_controls'

records={}; references=[]
def snapshot(path,expected=None):
    path=Path(path); path=path if path.is_absolute() else ROOT/path
    path=path.resolve(); raw=path.read_bytes()
    record=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    if expected is not None:
        fixed=dict(expected,path=str(Path(expected['path']).resolve()))
        if record!=fixed:raise ValueError('raw mismatch: '+str(path))
        references.append(fixed)
    if str(path) in records and records[str(path)][0]!=record:
        raise ValueError('changed raw snapshot')
    records[str(path)]=(record,raw)
    return record,raw

def document(path,expected=None):
    record,raw=snapshot(path,expected)
    return record,json.loads(raw)

def walk_raw(value):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            snapshot(value['path'],value);return
        for child in value.values():walk_raw(child)
    elif type(value) is list:
        for child in value:walk_raw(child)

def save(name,value):
    path=HERE/name
    if path.exists():raise FileExistsError('frozen record already exists')
    path.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return snapshot(path)[0]

handoff_pin,handoff=document(SUBJECT/'handoff-v1.json')
assert handoff_pin['sha256']=='6fbd80f787ea30bc1d9586c01139bb32e06f4c0e7c21329eea7f1ff535333dd7' and handoff_pin['bytes']==6779
source_pin,source_raw=snapshot(handoff['source']['path'],handoff['source'])
contract_pin,contract=document(handoff['source_contract']['path'],handoff['source_contract'])
api_pin,api=document(handoff['API']['path'],handoff['API'])
static_pin,author_static=document(handoff['static_checks']['path'],handoff['static_checks'])
for value in (handoff,contract,api,author_static):walk_raw(value)
read_documents={}
for name in ('proposal_handoff','proposal_contract','proposal_integration','proposal_memo','proposal_controls','proposal_anchor','distinct_conceptual_review'):
    record=handoff['inputs'][name]
    pin,value=document(record['path'],record)
    read_documents[name]=dict(pin=pin,value=value)
# Referenced conceptual evidence is read as metadata only, not replayed authority.
review=read_documents['distinct_conceptual_review']['value']
conceptual={key:value for key,value in review.items() if key not in ('checks','verified_raw_records','raw_pin_references')}
source_text=source_raw.decode('utf8'); tree=ast.parse(source_text,str(source_pin['path']))
compile(tree,source_pin['path'],'exec')
locations={node.name:dict(line=node.lineno,end_line=node.end_lineno) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
method_locations={node.name+'.'+child.name:dict(line=child.lineno,end_line=child.end_lineno)
    for node in tree.body if isinstance(node,ast.ClassDef)
    for child in node.body if isinstance(child,ast.FunctionDef)}
imports=[alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names]
imports += [node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]
assert set(imports)<={'hashlib','json','math','time','types'}
assert not [node for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
            and node.func.id in ('eval','exec','__import__','open')]
assert not [node for node in tree.body if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call)]
names=set(locations)|{'__name__','__file__','__package__'}
names|={alias.asname or alias.name.split('.')[0] for node in tree.body if isinstance(node,ast.Import) for alias in node.names}
names|={target.id for node in tree.body if isinstance(node,ast.Assign) for target in node.targets if isinstance(target,ast.Name)}
unknown=[]
def inspect_symbols(table):
    for name in table.get_identifiers():
        item=table.lookup(name)
        if item.is_global() and item.is_referenced() and name not in names and name not in vars(builtins):
            unknown.append([table.get_name(),name])
    for child in table.get_children():inspect_symbols(child)
inspect_symbols(symtable.symtable(source_text,source_pin['path'],'exec'))
assert not unknown
assert handoff['author_identity']==AUTHOR and contract['author_identity']==AUTHOR
assert contract['source']==source_pin and handoff['scientific_calls']==0 and contract['scientific_calls']==0

checks=[
 {'check':'whole_source_636_lines_contract_API_and_declared_design_read','passed':True,'detail':'Whole raw source inspected; no module import or definitions invoked.'},
 {'check':'all_current_handoff_declared_raw_refs_authentic','passed':True,'detail':'SHA/length from stable whole raw buffers; no ancestor decoding or rank calculation.'},
 {'check':'Source_AST_compile_only_and_no_unresolved_globals','passed':True,'detail':unknown},
 {'check':'stdlib_only_no_graph_checker_search_or_file_loading_in_module','passed':True,'detail':imports},
 {'check':'whole_ordered_interfaces_and_formula_table_retained','passed':True,'detail':'normalise_q_catalogue preserves every formula/recipe and source_preimage; ordinal/ID/code validation with complete hashes. Semantic licensing/completeness still caller +independent auditor gates.'},
 {'check':'all_original_Gamma_occurrences','passed':True,'detail':'Occurrence index/code/formula arrays are one per ordered Gamma entry, including repeats. Formula rank sharing does not erase occurrence records or imply consumption.'},
 {'check':'synchronous_AND_saturation_no_cycle_or_target_bootstrap','passed':True,'detail':'previous=frozenset(settled) per round; every ordered port must be in previous; zero ports +Gamma only roots; all interfaces scanned through H-1. No target/root/backcone parameter.'},
 {'check':'complete_inequality_coverage','passed':True,'detail':'Every root must have integer label0; every interface inequality includes every ordered input rank and saturated max. Exact minimum heights still require independent full-round reconstruction.'},
 {'check':'integer_type_and_range_gates','passed':True,'detail':'height/codes/ordinals/labels/port/ref and mark coordinates use exact int, reject bool; row/reference bounds are strict prior. Generic H/input sizes have no independent fixed catalogue cap in this callable; real cold caps +current-Q H24 remain mandatory.'},
 {'check':'literal_formula_and_all_ordered_port_profiles','passed':True,'detail':'Contiguous assigned-one prefixes use channels5..H+4; zero rank empty; every output/read interface profile emitted; port multiplicity retained.'},
 {'check':'fixed_assigned_zero_boundary_and_translation','passed':True,'detail':'Boundary is every [4+k,row,0] with row<k<=H; vertical translation only, values/channels fixed. Duplicate equal rank marks become one function value, not extra t.'},
 {'check':'base_mark_channel_disjointness_and_t_unchanged','passed':True,'detail':'New channels disjoint declared original channels; placement emits added m only, t_added=[], current/fixed union and legality flagsfalse.'},
 {'check':'model_context_library_source_runtime_hash_bindings','passed':True,'detail':'Inventory SHA includes complete bindings; rank epoch binds labels/roots/all edges/algorithm; literal marking epoch binds all profiles/fixed points. Raw pin syntax and caller base epoch are not authentication or standalone mathematical authority.'},
 {'check':'producer_recheck_not_independent_certificate_audit','passed':True,'detail':'Emitter checks roots/inequalities/hash but does not independently reconstruct complete rounds or raw origin inventory. A weaker all-interface-valid table is a safe bound conditional on complete correct inventory, not exact minimality.'},
 {'check':'final_hash_and_record_before_deadline_boundary','passed':True,'detail':'finish_candidate hashes and canonically serializes whole record, then calls final check; prior cost field explicitly excludes final hash/guard work. Callback/clock authority blocker below remains.'},
 {'check':'own_validator_and_clock_authority_across_delegation','passed':False,'detail':'Boundary.check trusts current global unchanged_function and Boundary.clock dynamically resolves time.perf_counter. Neither is directly anchored against mutation before/after delegated callback.'},
 {'check':'no_pruning_runtime_word_or_partial_endpoint_admission','passed':True,'detail':'All products remain unadmitted; graph/factors/dependency/refcount/rollback implementation absent; complete-word bound and broader first-checked current-union endpoint equivalence separate.'},
 {'check':'master_scheduler_fallback_and_extended_support_gaps_disclosed','passed':True,'detail':'Future graph must compare literal marks, update every new output/remote-read dependency, retain all24 domains, dead→forced→earliest-generation, exact shared identity and rollback. Old graph affected_rows does not cover new channels.'},
 {'check':'no_performance_or_RL_fit_claim','passed':True,'detail':'Prospective20/60/90/512 caps and complete costs remain unmeasured; no rank/point profile, marked search, proof, RL or speedup run.'}
]
blocker={
 'id':'RANK-SOURCE-GUARD-1','severity':'Source readiness blocker; candidate guard contract, not actual mathematical failure',
 'source':source_pin,'locations':{'Boundary':method_locations['Boundary.check'],'clock':method_locations['Boundary.clock'],
                              'unchanged_function':locations['unchanged_function']},
 'mechanism':'During the first delegated source_guard invocation, an ordinary callback can replace its own __code__ and the module global unchanged_function with no-op code. The immediately subsequent verification uses the changed validator; later Boundary.check calls can then invoke the changed callback without rejecting it. time.perf_counter can separately be rebound by the delegate and Boundary.clock trusts the current attribute.',
 'why_concrete':'The contract expressly promises original callback/function/code/default/closure and real absolute deadline checks before and after every boundary. Current code has captured callback state but no independently anchored own verification or clock endpoint at those delegation boundaries. No function was executed to demonstrate this path.',
 'narrow_repair':'Preservev1. In an additive successor capture original validator/rejection/clock callable identity+code/default/closure as applicable before first delegation. Use direct if/raise identity/code rejection before and after every delegate and before final return, checking original time.perf_counter endpoint; do not rely on a mutable verification helper to authenticate itself. Retain future cold caller module/MRO/effective endpoint guards and full independent certificate audit.',
 'scope_limits':'This does not invalidate a recorded rank/marked result: none exists. Producer products already deny pruning/math/proof authority; the defect is unexecuted guard conformance and readiness.'}
limits=[
 'Source review does not reconstruct any ranks or evaluate any interface/point example. All labels/profile effects remain uncomputed.',
 'Full original inventory/semantic licence qualification, raw buffer/canonical origin/caller base-model epoch authentication and independent rank/round/literal audit are still separate pending gates.',
 'Generic positive finite height is allowed; no promise of current fixed-budget fit follows. Current Q normalization enforces24, while actual complete catalogue and owned caps must be independently admitted.',
 'No graph integration exists for new threshold supports. Old factors/dependencies/rollback cannot inherit conformance; complete literal domain and rollback controls remain required.',
 'Conditional bound preserves completed strict-prior words and dependency-complete ancestral patches. Larger pending/current-union first-proof observer endpoints may be rejected for unrelated unfinished readers; no equivalence is established.',
 'Existing earlier conceptual review author also authors the rank producer. It supports the distinct arithmetic design only; this review is the genuinely separate implementation Source assessment.',
 'Current Q producer-only stage and historical memory/Source failures remain unchanged; no profile/q/activation/pruning/library/proof claim is upgraded.'
]
# Final rehash of every whole inspected target before freezing findings.
for path,(record,raw) in list(records.items()):
    current=Path(path).read_bytes()
    if current!=raw:raise ValueError('changed subject/evidence before freeze')
findings={'schema':'rank-certificate-producer-literal-emitter-Source-findings-v1','author_identity':AUTHOR,
 'reviewer_identity':REVIEWER,'source_only':True,'scientific_calls':0,'rank_computations':0,
 'Source_module_imports':0,'semantic_or_control_tests_executed':0,'graph_search_replay_RL_calls':0,
 'subject_handoff':handoff_pin,'source':source_pin,'source_contract':contract_pin,'API':api_pin,
 'author_static_metadata':static_pin,'read_documents':{k:v['pin'] for k,v in read_documents.items()},
 'function_locations':locations,'method_locations':method_locations,'checks':checks,'blockers':[blocker],
 'source_review_passed':False,'source_ready':False,'all_checks_passed':False,
 'algorithm_and_literal_arithmetic_source_assessment':'No separate concrete saturation/inequality/literal arithmetic flaw found in whole read; guard boundary repair remains required.',
 'limitations':limits,'raw_reference_count':len(references),'unique_raw_targets':len(records),'pin_mismatch_count':0,
 'verified_raw_records':[record for record,_ in records.values()],
 'pruning_admitted':False,'mathematical_acceptance':False,'runtime_admission':False,'proof_accepted':False,
 'decision':'Negative current Source readiness due to RANK-SOURCE-GUARD-1. Exact frozen v1 retained; no activation or repair performed by reviewer.'}
findings_pin=save('rank-producer-emitter-Source-findings-v1.json',findings)
typed={'schema':'rank-certificate-producer-literal-emitter-Source-review-v1',
 'scope':'full-inventory-synchronous-saturated-rank-producer-and-literal-emitter-Source',
 'author_identity':AUTHOR,'reviewer_identity':REVIEWER,'source':source_pin,'source_contract':contract_pin,
 'source_only':True,'source_review_passed':False,'source_ready':False,'all_checks_passed':False,
 'scientific_calls':0,'rank_computations':0,'mathematical_acceptance':False,'pruning_admitted':False,
 'findings':findings_pin,'concrete_blocker':'RANK-SOURCE-GUARD-1','budget_fit':'UNMEASURED'}
typed_pin=save('rank-producer-emitter-typed-Source-review-v1.json',typed)
handoff={'schema':'rank-producer-emitter-independent-Source-review-handoff-v1','source_only':True,
 'reviewer_identity':REVIEWER,'author_identity':AUTHOR,'subject':handoff_pin,'source':source_pin,
 'findings':findings_pin,'typed_review':typed_pin,'Source_review_passed':False,'science_calls':0,
 'blocker':'Original validation helper/clock endpoint not anchored across source_guard delegation.',
 'next':'Author preserves v1 and supplies a narrow additive guard repair; reviewer inspects delta without execution. All independent certificate/literal/graph/partial-endpoint/owned activation gates remain pending.'}
hand=save('handoff-v1.json',handoff)
print(json.dumps({'findings':findings_pin,'typed':typed_pin,'handoff':hand,'checks':len(checks),
 'refs':len(references),'raw_targets':len(records)-3,'rank_computations':0,'Source_review_passed':False},sort_keys=True))
