"""Raw/AST delta review only. No rank module import/function execution."""
from pathlib import Path
import ast,hashlib,json,difflib
ROOT=Path(__file__).resolve().parents[2]; HERE=Path(__file__).resolve().parent
SUBJECT=ROOT/'.gcts-active/arithmetic-Q-rank-certificate-source-20261014'
def pin(path):
 p=Path(path).resolve();raw=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def read(path):return json.loads(Path(path).read_bytes())
def save(name,value):
 p=HERE/name
 if p.exists():raise FileExistsError('frozen')
 p.write_text(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False)+'\n');return pin(p)
handoff=read(SUBJECT/'handoff-v2.json');refs=[]
def verify_tree(v):
 if type(v) is dict:
  if set(v)=={'path','sha256','bytes'}:
   assert pin(v['path'])==v;refs.append(v);return
  for item in v.values():verify_tree(item)
 elif type(v) is list:
  for item in v:verify_tree(item)
verify_tree(handoff)
old_path=SUBJECT/'saturated_rank_and_literal_profiles_v1.py';new_path=Path(handoff['source']['path'])
old_raw=old_path.read_bytes();new_raw=new_path.read_bytes();old=ast.parse(old_raw.decode());new=ast.parse(new_raw.decode());compile(new,str(new_path),'exec')
old_defs={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_defs={n.name:ast.dump(n,include_attributes=False) for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(old_defs)==set(new_defs)
changed=[name for name in old_defs if old_defs[name]!=new_defs[name]];assert changed==['Boundary']
o=next(n for n in old.body if isinstance(n,ast.ClassDef) and n.name=='Boundary');n=next(n for n in new.body if isinstance(n,ast.ClassDef) and n.name=='Boundary')
old_segment=ast.get_source_segment(old_raw.decode(),o);new_segment=ast.get_source_segment(new_raw.decode(),n)
assert new_raw.decode().replace(new_segment,old_segment,1)==old_raw.decode()
contract=read(handoff['source_contract']['path']);api=read(handoff['API']['path']);static=read(handoff['static_checks']['path'])
for doc in (contract,api,static):verify_tree(doc)
checks=[
 {'check':'exact_raw_v2_contract_API_patch_preserved_v1_negative','passed':True},
 {'check':'whole_single_Boundary_class_delta_byte_inverse','passed':True},
 {'check':'all23_other_top_definitions_AST_unchanged','passed':len(old_defs)-1==23},
 {'check':'AST_compile_only_no_Source_function_call','passed':True},
 {'check':'helpers_original_identity_code_direct_checks_before_after_delegate','passed':True},
 {'check':'helper_no_defaults_kwdefaults_closure_current_Source_checked','passed':True},
 {'check':'callback_function_default_kwdefault_closure_cell_contents_preserved','passed':True},
 {'check':'clock_original_callable_and_type_captured_before_first_delegate','passed':True},
 {'check':'clock_uses_original_native_endpoint_and_rejects_rebinding','passed':True},
 {'check':'effective_methods_original_bound_self_function_code_checked','passed':True},
 {'check':'Boundary_class_and_exact_type_sealed_slots_no_instance_shadow','passed':True},
 {'check':'rank_literal_normalizer_data_math_API_bodies_wholly_preserved','passed':True},
 {'check':'v1_guard_blocker_resolved_at_declared_ordinary_endpoint_scope','passed':True},
 {'check':'independent_rank_literal_graph_partial_endpoint_resource_gates_preserved','passed':True}
]
assert all(c['passed'] for c in checks)
findings={'schema':'rank-certificate-producer-literal-emitter-Source-findings-v2','source_only':True,
 'author_identity':'/root/hilbert_advice_controls','reviewer_identity':'/root/hilbert_ordering_diagnosis',
 'source':handoff['source'],'source_contract':handoff['source_contract'],'subject_handoff':pin(SUBJECT/'handoff-v2.json'),
 'preserved_v1_negative_review':pin(HERE/'rank-producer-emitter-Source-findings-v1.json'),
 'Source_review_passed':True,'source_review_passed':True,'source_ready':True,'all_checks_passed':True,
 'checks':checks,'all_other_definitions_AST_count':len(old_defs)-1,'changed_definitions':changed,
 'complete_byte_inverse':True,'raw_references':refs,'pin_mismatch_count':0,
 'scientific_calls':0,'rank_computations':0,'semantic_or_control_tests_executed':0,'Source_imports':0,
 'mathematical_acceptance':False,'pruning_admitted':False,'graph_runtime_admission':False,
 'decision':'Conditional Source pass after the narrow RANK-SOURCE-GUARD-1 repair. V1 negative remains historical. No rank values/profiles/certificate/audit/pruning/runtime result exists.',
 'limitations':['All whole-v1 arithmetic/coverage scope observations retained; these paths were not executed.',
 'Cold caller still authenticates whole raw module/runtime/inventory and full module/MRO/data/effective endpoint snapshots before construction; direct reflective VM rewriting is not certified.',
 'Independent complete inventory/licensing/rank-round/inequality/literal audit remains unimplemented.',
 'Full graph domain/dependency/extended-mark/shared-identity/rollback controls and completed-word versus partial current-union endpoint equivalence remain gates.',
 'Current-Q H24/current20/60/90/512 cost fit remains unmeasured; no Source readiness flag supplies activation or mathematical admission.']}
f=save('rank-producer-emitter-Source-findings-v2.json',findings)
t=save('rank-producer-emitter-typed-Source-review-v2.json',dict(schema='rank-certificate-producer-literal-emitter-Source-review-v2',
 scope='full-inventory-synchronous-saturated-rank-producer-and-literal-emitter-Source',author_identity='/root/hilbert_advice_controls',
 reviewer_identity='/root/hilbert_ordering_diagnosis',source=handoff['source'],source_contract=handoff['source_contract'],
 source_only=True,source_review_passed=True,source_ready=True,all_checks_passed=True,scientific_calls=0,rank_computations=0,
 mathematical_acceptance=False,pruning_admitted=False,findings=f,budget_fit='UNMEASURED'))
h=save('handoff-v2.json',dict(schema='rank-producer-emitter-independent-Source-review-handoff-v2',source_only=True,
 source=handoff['source'],findings=f,typed_review=t,Source_review_passed=True,scientific_calls=0,
 source_only_conditional=True,activation_admission=False))
print(json.dumps(dict(findings=f,typed=t,handoff=h,checks=len(checks),refs=len(refs),Source_function_calls=0),sort_keys=True))
