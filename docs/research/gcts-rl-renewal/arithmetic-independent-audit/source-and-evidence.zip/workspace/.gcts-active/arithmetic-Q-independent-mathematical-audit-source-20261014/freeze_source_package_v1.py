"""Stdlib raw/AST metadata freezer only; no import or call of audited source."""
from pathlib import Path
import ast
import hashlib
import json
import symtable
import builtins

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = '/root/hilbert_ordering_diagnosis'

def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def read(path):
    return json.loads(Path(path).read_bytes())

def save(name, value):
    path = HERE / name
    if path.exists():
        raise FileExistsError('frozen additive output already exists: ' + str(path))
    path.write_text(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    return pin(path)

module = HERE / 'independent_Q_semantics_v1.py'
raw = module.read_bytes(); tree = ast.parse(raw.decode('utf8'), str(module)); compile(tree, str(module), 'exec')
parent = ROOT / '.gcts-active/arithmetic-open-generalize-implementation-source-20261014'
progress = ROOT / '.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'
output = progress / 'worker-output-v1'
worker_plan = read(progress / 'worker-plan-v1.json')
producer_sources = worker_plan['sources']
for role, record in producer_sources.items():
    assert pin(record['path']) == record
source = pin(module)
declaration = pin(parent / 'Q-declaration-v1.json')
prototype_contract = pin(parent / 'source-contract-v1.json')
actual_inputs = {
    'declaration': declaration,
    'producer_preparation': pin(output / 'Q-preparation-provisional-v1.json'),
    'initial_state': pin(output / 'Q-initial-state-witness-v2.json'),
    'initial_oracle_domains': pin(output / 'Q-initial-oracle-domains-v2.json'),
    'producer_receipt': pin(output / 'Q-controls-result-v1.json'),
    'producer_evidence': pin(output / 'Q-controls-evidence-v1.json'),
    'producer_worker_plan': pin(progress / 'worker-plan-v1.json'),
    'producer_ROOT_final_decision': pin(progress / 'preparation-ROOT-final-decision-v1.json'),
    'producer_ROOT_reconciled_disposition': pin(progress / 'ROOT-actual-Q-streamed-controls-reconciled-disposition-v2.json')}
prior_reviews = {
    'producer_saved_metadata': pin(ROOT / '.gcts-active/arithmetic-Q-streamed-controls-saved-independent-20261014/findings-v1.json'),
    'producer_current_Source': pin(ROOT / '.gcts-active/arithmetic-Q-streamed-controls-independent-20261014/source-findings-v2.json')
}
# Source syntax/symbol checks only. None of the new source definitions executes.
imports = [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
imports += [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
assert set(imports) <= {'hashlib', 'itertools', 'json', 'math', 'pathlib', 'time', 'types'}
assert not [node for node in tree.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)]
assert not [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
            and node.func.id in {'eval', 'exec', '__import__'}]
locations = {node.name: {'line': node.lineno, 'end_line': node.end_lineno}
             for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert {'Semantics', 'audit_saved_profile', 'check_primitive_word', 'reconstruct_grammar',
        'independent_domain', 'literal_points', 'check_point_state', 'compare_owned_chunks'} <= set(locations)
module_names = set(locations) | {'Path'}
module_names |= {alias.asname or alias.name.split('.')[0] for node in tree.body if isinstance(node, ast.Import) for alias in node.names}
module_names |= {target.id for node in tree.body if isinstance(node, ast.Assign) for target in node.targets if isinstance(target, ast.Name)}
unknown = []
def inspect_symbols(table):
    for name in table.get_identifiers():
        entry = table.lookup(name)
        if entry.is_global() and entry.is_referenced() and name not in module_names and name not in vars(builtins):
            unknown.append([table.get_name(), name])
    for child in table.get_children():
        inspect_symbols(child)
inspect_symbols(symtable.symtable(raw.decode('utf8'), str(module), 'exec'))
assert unknown == []
assert b'11147' not in raw and b'16200' not in raw

owned_abi = {
    'status': 'prospective; no cold worker, actual plan, admission or invocation emitted',
    'callable_api': 'audit_saved_profile(*, declaration, preparation, expected_source_bindings, source_guard, deadline, initial_state_record, initial_oracle_record)',
    'word_checker_api': 'check_primitive_word(*, theory, parameters, original_Gamma, commands, target, source_guard, deadline, maximum_visits=5000000)',
    'reference_generic_owner': pin(progress / 'run_owned_bridge_v2.py'),
    'reference_generic_closer': pin(progress / 'close_stage_decision_v1.py'),
    'generic_owner_field_count': 10,
    'generic_owner_schema': 'ROOT-guard-native-owned-plan-v1',
    'prospective_leaf_field_count': 11,
    'prospective_leaf_fields': ['schema', 'stage', 'activation', 'outdir', 'sources', 'inputs', 'source_review', 'limits',
                                'allowed_runtime', 'source_cache_gate', 'raw_closure'],
    'prospective_leaf_schema': 'ROOT-independent-complete-Q-audit-worker-plan-v1',
    'prospective_source_roles': ['worker', 'independent_auditor', 'master'],
    'raw_executed_roles': ['worker', 'independent_auditor'],
    'raw_only_producer_roles': sorted(producer_sources),
    'clock_and_caps': {'one_shared_inner_seconds': 20, 'cold_worker_seconds': 55, 'cold_worker_bytes': 500 * 1024 * 1024,
        'whole_owned_seconds': 60, 'whole_owned_bytes': 512 * 1024 * 1024, 'owner_finish_reserve_seconds': 2,
        'owner_finish_reserve_bytes': 8 * 1024 * 1024, 'genuine_caller_seconds': 90, 'caller_finish_reserve_seconds': 1},
    'clock_scope': 'One deadline starts before raw input loading/decoding and covers all syntax, closure, primitive semantics, domains, exact EOF serialization comparisons, result preparation and final callback/clock checks. Receipt/whole output publication remains inside cold/owner scopes. No reset per phase.',
    'failure': 'On timeout, visit/depth/fresh/memory cap, raw identity, syntax, semantic or full-domain failure: whole UNKNOWN/no completed audit certificate/no accepted prefix. Partial diagnostics are not mathematical admission.',
    'ROOT_only_authorities': ['activation', 'genuine caller timing', 'owner resource disposition', 'mathematical catalogue admission', 'q/consumer integration'],
    'missing_executable_prerequisite': 'A peer-reviewed narrow cold raw loader/receipt worker; this contract is not that worker and cannot be dispatched by itself.'}

contract = {
    'schema': 'independent-Q-mathematical-auditor-Source-contract-v1', 'author_identity': AUTHOR,
    'source_only': True, 'scientific_calls': 0, 'actual_activation': False, 'actual_mathematical_acceptance': False,
    'sources': {'independent_auditor': source, 'master': producer_sources['master']},
    'producer_provenance_raw_only': producer_sources, 'declaration': declaration, 'frozen_rule_specification': prototype_contract,
    'actual_saved_inputs': actual_inputs, 'prior_evidence_raw_only': prior_reviews,
    'independence': {'author_differs_from_producer': True, 'producer_author': '/root/arithmetic_induction',
        'producer_QChecker_calls': 0, 'producer_prepare_calls': 0, 'producer_Graph_calls': 0,
        'algorithm': 'Separately authored interned nominal-AST rule validation, monotone bounded structural term closure, complete raw recipe-key reconstruction and direct point-factor relation. Producer algorithms are read as specification, never invoked as authority.',
        'shared_specification': 'Exact declared six rules/finite language/fresh-name spelling/point encoding are necessarily shared. This is not a second mathematical axiom system or formal proof of the Python verifier.'},
    'named_reader_contract': {
        'parse_once': ['declaration', 'producer_preparation', 'producer_receipt', 'producer_evidence', 'producer_worker_plan',
                       'producer_ROOT_final_decision', 'producer_ROOT_reconciled_disposition'],
        'byte_compare_without_second_model_parse': ['initial_state', 'initial_oracle_domains'],
        'source_or_resource_closure_raw_only': 'Every explicit closed raw pin from actual consumed producer worker/owner plans, source maps and named review/runtime records; authenticate all, decode only actual named metadata read sites.',
        'arbitrary_ancestor_JSON_decoding': False,
        'no_proof_word_or_prior_target_route_input': True,
        'canonical_ABS_internal_pins_and_ROOT_relative_generic_owner_spellings': 'Normalize equivalent repository spellings once to canonical raw identity; no general symlink authorization or source execution from raw ancestry.'},
    'cold_boundary_requirements': [
        'One authenticated stable whole raw buffer is both hashed and parsed; never pin one buffer and parse a second.',
        'Require genuine resource-closed original producer receipt/disposition and exact output pins, but do not inherit a mathematical acceptance flag from those controls.',
        'Execute only exact new worker/auditor raw bytes. All seven original producer modules remain raw provenance; source cache guards must forbid their import/calls.',
        'Anchor own rejection/hash/load/serialization validators before loading the auditor; directly reject their code/default/closure changes before delegation.',
        'Anchor complete auditor module constants/class/MRO/effective instance methods plus the original supplied callback function/code/default/closure/shim at every outer and final boundary.',
        'Snapshot exact parsed input data; reject mutation before/after returned certificate publication. No caller target/proof flag substitutes for semantic checking.',
        'Whole result/evidence/receipt files are raw pinned and closed only after a complete success; ROOT resource admission remains separate.'
    ],
    'owned_ABI': owned_abi,
    'current_scope': {'calibration': 'Exact closed right-one target with empty original Gamma and declared parameter n; target seeds formula syntax only.',
        'bounded_formula_and_recipe_completeness': 'Entire fixed finite grammar, not FOL or PA completeness.',
        'all24_initial_point_domains': 'Every canonical factor, ordered reference mask, unequal shared-row exclusion, count and EOF witness; no favorable rows or placement shortlist.',
        'point_decision': 'Global dead, forced, then earliest generation; candidate count breaks generation ties. This audits the saved initial relation, not a search trajectory.',
        'proof_checker': 'Arbitrary complete six-rule primitive words under a disclosed 20000-row/5000000-visit/64-depth/32-fresh ceiling. No proof is authored or input here.',
        'universal_generalization': 'Unary source plus full original Gamma free-variable side condition, including unused/repeated occurrences.',
        'not_admitted': ['induction', 'reflexivity or added tautology rule', 'full_PA', 'native checker', 'universal compiler',
                         'full24 proof', 'full search trajectory', 'RL', 'external prover', 'library or runtime admission']},
    'Source_review_ABI': {'schema': 'independent-Q-mathematical-auditor-Source-review-v1',
        'scope': 'complete-finite-Q-catalogue-primitive-domain-and-word-checker-Source',
        'author_identity': AUTHOR, 'reviewer_identity': 'genuine reviewer must differ from author',
        'sources': {'independent_auditor': source, 'master': producer_sources['master']},
        'source_contract': 'exact current contract raw pin', 'required_flags': ['source_only', 'all_checks_passed', 'source_review_passed'],
        'scientific_calls': 0, 'mathematical_acceptance': False},
    'remaining_gates': ['Distinct-author whole Source/math/guard review', 'Narrow cold worker/owned receipt Source implementation and review',
        'Pre-registered unrelated negative/boundary controls', 'Actual complete bounded catalogue/primitive/domain audit with ROOT custody',
        'Actual arbitrary-word checker controls and future proof-source/observer/certificate integration before first-proof search'],
    'budget_feasibility': 'UNMEASURED. Interned nodes and streamed witness comparisons reduce duplicate structures; no claim the full independent audit fits the unchanged caps.'
}
contract_pin = save('source-contract-v1.json', contract)

design = {
    'schema': 'independent-Q-mathematical-auditor-design-v1', 'source_only': True, 'scientific_calls': 0,
    'declaration': declaration, 'auditor': source,
    'observations_only': {'producer_formulas': 11147, 'producer_recipes': 16200, 'producer_complete_controls': 36,
        'producer_serializer_fixtures': 6, 'producer_mathematical_catalogue_admission': False,
        'warning': 'These saved values are not expected counts, grammar filters or acceptance shortcuts in the auditor.'},
    'exact_closure_stages': [
        'Least structural term closure through the declared node bound; retain all parameter-scoped target/axiom subterms afterward.',
        'Register all parameter-scoped subformulas of the target and original named axioms; only the named axioms become zero-port axiom recipes.',
        'Two simultaneous universal snapshots. Every snapshot universal is paired with every complete operand; capture-avoiding UI implication is zero-port, not its consequent.',
        'First unused literal hole; identity/unary-function hole contexts; both equality sides against every operand; every ordered operand pair, with duplicates removed only by exact raw recipe identity.',
        'Unary generalization for every resulting equality atom, with the complete original Gamma side condition.',
        'Ordered binary MP for every resulting implication; no target backcone, role sort, learned trim, extra round or supplied proof route.',
        'Canonical injective formula codes, full recipe preimages/source/authority/context/marking hashes and exact original boundary/model epoch.',
        'Independent full literal point relation for every required row, plus whole byte/SHA/length/EOF correspondence to the original initial state and oracle files.'
    ],
    'soundness_obligations': [
        'Axiom/assumption conclusions are exactly original occurrences; no implicit new assumptions.',
        'UI implication is valid under free substitution because conflicting binders are renamed to the first unused declared fresh spelling.',
        'Atomic equality transport is a zero-port logical implication; two ordered MP reads are needed to apply it.',
        'MP reads actual strictly prior formula rows; UG has one actual prior source and its variable is free in no original Gamma premise.',
        'Induction on word row validates any checked complete word; terminal equality to the original closed target yields only that original sequent.',
        'Factor masks enumerate every strict-prior reference satisfying current assigned marks; unequal input codes remove precisely equal-row collisions. Integer t sums and compatible m assignments are checked separately.'
    ],
    'bounded_completeness_argument': 'Each language stage is specified as a finite full product or snapshot. The independent expected registry and raw recipe-key set must equal the entire saved canonical arrays, element by element; every saved recipe is additionally checked by the separate rule kernel. No count-only acceptance. Cartesian domain factors represent every key while avoiding a giant placement-list materialization.',
    'literal_point_encoding': {'support': r'\(t(0,r)=1\) for one selected primitive row; shared exact placement identity counted once.',
        'formula': r'\(m(1,r)=c_{\mathrm{out}}\) and \(m(1,s_j)=c_j\).',
        'ordered_port': r'\(m(2+j,r)=s_j-r\), with \(0\leq s_j<r\).',
        'zero': 'An assigned marking value zero is not an absent marking.',
        'scope': 'Translation-only point-row encoding; partial compatible patches are not full board or trajectory proofs.'},
    'preserved_history': 'Original memory UNKNOWN, unactivated V6 negative Source finding, V7 controls/resources and saved-only reconciliation remain immutable. This new Source does not upgrade any of those mathematical flags.',
    'proof_search_prerequisites': 'After genuine audit and checker controls, a new explicit Q consumer/observer/certificate binding must use this checker. Existing ground Hilbert observer/runtime does not gain quantifier/UG authority automatically.'
}
design_pin = save('design-v1.json', design)
negative = {'schema': 'independent-Q-audit-prospective-controls-v1', 'source_only': True, 'activated': False,
    'scientific_calls': 0, 'no_original_target_proof_word': True,
    'controls': [
        'Delete one formula or recipe, add an extra recipe, reorder canonical code entries, or duplicate an identity: full closure fails, regardless of unchanged headline counts.',
        'Use captured universal instantiation, wrong fresh suffix, shadowed binder substitution, foreign free parameter or fresh suffix overflow.',
        'Generalize a source while an unused or repeated original Gamma occurrence contains the variable free; reject Boolean/self/future references and a hidden assumption in empty Gamma.',
        'Swap ordered MP ports, use a wrong implication, fabricate an induction/reflexivity/opaque rule or add fields to a primitive witness.',
        'Alter any formula code, source ledger, recipe preimage, local-context hash, authority epoch, target fixed mark or model epoch.',
        'Conflicting shared source row, duplicate physical support, repeated compatible ports, assigned zero versus absent marking, wrong remote port offset, or missing raw EOF suffix.',
        'Delay final metadata/byte comparison past the deadline; change original callback/code/default/closure contents or own validator; no completed certificate or prefix.',
        'Unrelated tiny complete six-rule words and raw syntax cases may be authored for mechanics only after preregistration; they must not become supplied routes for the original target.'
    ], 'what_not_established': ['actual feasibility', 'production search conformance', 'a discovered target proof', 'induction/PA/native authority', 'RL gain']}
negative_pin = save('prospective-controls-v1.json', negative)
static = {'schema': 'independent-Q-auditor-author-static-evidence-v1', 'author_identity': AUTHOR,
    'source': source, 'source_only': True, 'project_or_semantic_calls': 0, 'scientific_calls': 0,
    'AST_parsed_and_compile_only': True, 'audited_source_imported': False,
    'imports': imports, 'stdlib_only': True, 'top_level_definition_locations': locations,
    'unresolved_global_names': unknown, 'no_top_level_function_calls': True, 'no_dynamic_eval_or_project_import': True,
    'no_observed_count_literals_in_executable_source': True,
    'author_static_evidence_is_not_peer_review_or_mathematical_acceptance': True,
    'producer_sources_all_raw_pins_verified': producer_sources}
static_pin = save('author-static-evidence-v1.json', static)
handoff = {'schema': 'independent-Q-auditor-Source-handoff-v1', 'author_identity': AUTHOR,
    'source_only': True, 'scientific_calls': 0, 'actual_activation': False,
    'source': source, 'source_contract': contract_pin, 'design': design_pin, 'prospective_controls': negative_pin,
    'author_static_evidence': static_pin, 'producer_provenance_raw_only': producer_sources,
    'actual_saved_input_pins': actual_inputs,
    'callable_API': owned_abi['callable_api'], 'word_checker_API': owned_abi['word_checker_api'],
    'next_ROOT_step': 'Assign a distinct whole Source reviewer, then author/review a narrow cold raw loader/owned receipt wrapper under the exact contract. Only ROOT creates actual plans, activates the complete audit and issues resource/mathematical custody.',
    'review_and_activation_gaps': contract['remaining_gates'], 'budget_fit': 'unmeasured',
    'all_mathematical_runtime_admission_flags_currently_false': True}
handoff_pin = save('handoff-v1.json', handoff)
print(json.dumps({'source': source, 'handoff': handoff_pin, 'contract': contract_pin, 'design': design_pin,
                  'project_or_semantic_calls': 0}, sort_keys=True))
