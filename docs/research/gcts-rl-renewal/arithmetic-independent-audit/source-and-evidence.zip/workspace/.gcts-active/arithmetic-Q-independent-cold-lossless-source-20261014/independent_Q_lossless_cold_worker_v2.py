"""Unactivated independent complete-Q cold audit worker proposal.

ROOT alone authors actual plans, activates once and issues caller/resource/math
custody. The only executed project module is the frozen independent auditor.
All seven producer roles are RAW provenance, never compiled or invoked.
One shared20 starts before loading/decoding; whole55/500MiB worker fits inside
flat60/512MiB owner with finishing reserves, genuine90s caller separately.
"""
import hashlib
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
SCHEMA='ROOT-independent-complete-Q-audit-worker-plan-v1'
SCOPE='independent-complete-finite-Q-catalogue-primitive-initial-domains-no-search'
COMMAND='ROOT-independent-complete-Q-mathematical-audit'
AUTHOR='/root/hilbert_ordering_diagnosis'
LIMITS=dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)
MAX_METADATA=64*1048576
RECEIPT='Q-independent-audit-result-v1.json'
SOURCE_ROLES={'worker','independent_auditor','master'}
AUDITOR={'bytes': 46514, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/independent_Q_semantics_v1.py', 'sha256': '1717c716842886935c838a825b9c088810935acf101943e15eba6c5af7aec1c3'}
MASTER={'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}
PRODUCER_SOURCES={'catalogue': {'bytes': 10187, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-open-generalize-implementation-source-20261014/arithmetic_q_catalog_v1.py', 'sha256': '2db11af0d7206afd4e1c10b53b97c16f98064c14fd1e57a9a2ca34c0a602348a'}, 'controls': {'bytes': 19742, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-source-20261014/arithmetic_Q_streamed_controls_v3.py', 'sha256': '4e28fadd9c76ba6664e485fa2c5aa97beaa08639986b6d56aae50395b006e638'}, 'kernel': {'bytes': 10323, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-open-generalize-implementation-source-20261014/arithmetic_q_kernel_v1.py', 'sha256': '43bcd76ab1c672c5241f792cf898059a9f0157ace8f15b9684c7e48663db55a9'}, 'master': {'bytes': 21657, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'}, 'payload': {'bytes': 5435, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-source-20261014/q_preparation_owned_graph_v3.py', 'sha256': 'ee2088bf60709f6c0c5a78297841bd0684674369fa9d3c08119b96a59caa88ad'}, 'point_graph': {'bytes': 28531, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-open-generalize-implementation-source-20261014/arithmetic_q_point_graph_v1.py', 'sha256': '8d22ea390c675349fc9c90057cd152a4d0e75024bb365d70116cef0656597567'}, 'worker': {'bytes': 37266, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-source-20261014/arithmetic_Q_streamed_controls_worker_v7.py', 'sha256': '75d5d80701a0815d78e182a5cb7eb99412bff5b48a5b936a8850b625743de48d'}}
FROZEN_INPUTS={'declaration': {'bytes': 2683, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-open-generalize-implementation-source-20261014/Q-declaration-v1.json', 'sha256': 'e28e914fc01100fd75c12f1b271ec6ead107f211b4c91060d98c95e524d46fcc'}, 'initial_oracle_domains': {'bytes': 8295473, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-output-v1/Q-initial-oracle-domains-v2.json', 'sha256': '03c42ca0083d5e40363d5237d69af56df4ebe3b3ae7d88fa3720fae3390d6969'}, 'initial_state': {'bytes': 8296118, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-output-v1/Q-initial-state-witness-v2.json', 'sha256': 'c7e8cfd099b1b80ae170b6c35591d68d56f37aecb38f1bcf7b567d2e019acbb9'}, 'producer_ROOT_final_decision': {'bytes': 2810, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/preparation-ROOT-final-decision-v1.json', 'sha256': 'ba68f21a9a8bcc32402d6057d6bfff1b443a8c95207ade185fef194a9406fd49'}, 'producer_ROOT_reconciled_disposition': {'bytes': 8797, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/ROOT-actual-Q-streamed-controls-reconciled-disposition-v2.json', 'sha256': 'e52a47fe3ffa562a81d2084150eacec11c11be87e96def01ee728afaa4bd88ef'}, 'producer_evidence': {'bytes': 11000, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-output-v1/Q-controls-evidence-v1.json', 'sha256': '1c4069230b761d905046810f012f9d5ab6f4bf814674bdb90d3cb0ceaf8f6bb7'}, 'producer_preparation': {'bytes': 38376960, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-output-v1/Q-preparation-provisional-v1.json', 'sha256': '0321a462025357d188793bd45a44670adc20776e9ba30574049d77a8b5935d3a'}, 'producer_receipt': {'bytes': 5595, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-output-v1/Q-controls-result-v1.json', 'sha256': 'a6cc241c7c5408951979981f5de6c8e2d0d6be38cdbfe0fe16a365fa3085ede4'}, 'producer_worker_plan': {'bytes': 16547, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-streamed-controls-progress-20261014/worker-plan-v1.json', 'sha256': 'f44b778167aeefbcb561d60279f4ece55552639f6e58d6f31a53cd778aeba4d9'}, 'auditor_contract': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/source-contract-v1.json', 'sha256': 'de26586799af2c8143fe744590dc2d76789836735342a8d6b582583d3b870e51', 'bytes': 16116}, 'auditor_handoff': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014/handoff-v1.json', 'sha256': '6ceb31b4b5a34e61f9d8fa8e7fefa1f28f3031383b040c391c1f9a904f35396d', 'bytes': 7895}}
INPUT_ROLES=set(FROZEN_INPUTS)

def need(value, label):
    if not value:
        raise ValueError(label)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def pin(path):
    path = Path(path)
    need(path.is_absolute() and str(path.resolve()) == str(path) and not path.is_symlink(), 'canonical ABS pin')
    h = hashlib.sha256(); count = 0; before = path.stat()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(65536), b''):
            h.update(raw); count += len(raw)
    after = path.stat()
    need((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size) ==
         (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size), 'whole stable raw bytes')
    return dict(path=str(path), sha256=h.hexdigest(), bytes=count)

def verify(record):
    need(type(record) is dict and set(record) == {'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes'] >= 0
         and type(record['sha256']) is str and len(record['sha256']) == 64
         and all(c in '0123456789abcdef' for c in record['sha256'])
         and pin(record['path']) == record, 'typed canonical full pin')
    return record

def parse(raw):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            need(name not in result, 'duplicate JSON field'); result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))

def read(record, maximum=MAX_METADATA):
    verify(record)
    with Path(record['path']).open('rb') as stream:
        raw = stream.read(maximum+1)
        need(len(raw) <= maximum and stream.read(1) == b'', 'whole bounded raw buffer, no prefix')
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'parse the authenticated same raw buffer')
    value = parse(raw); verify(record); return value

def load(record, name):
    verify(record); raw = Path(record['path']).read_bytes()
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'same exact raw source execution buffer')
    spec = importlib.util.spec_from_file_location(name, record['path'])
    need(spec is not None, 'source metadata spec')
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    exec(compile(raw, record['path'], 'exec'), module.__dict__)
    need(str(Path(module.__file__).resolve()) == record['path'], 'bound raw source origin, no bytecode loader')
    return module

def normalize(record):
    path = Path(record['path']); actual = path if path.is_absolute() else ROOT/path
    return dict(record, path=str(actual))

def value_state(value):
    """Detect ordinary namespace/default mutation without accepting origin claims."""
    if value is None or type(value) in (str, int, bool, float, list, dict, tuple):
        try: return canonical(value)
        except (TypeError, ValueError): pass
    return None

def executable_state(module, *, class_roots=()):
    state = []; namespaces = []; mros = []; seen_classes = set()
    def keys(owner):
        return tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE')
    def add(owner, name, value):
        if isinstance(value, (staticmethod, classmethod)): value = value.__func__
        code = value.__code__ if inspect.isfunction(value) else None
        defaults = (value_state(value.__defaults__), value_state(value.__kwdefaults__)) if code else None
        closure = tuple((cell.cell_contents, value_state(cell.cell_contents))
                        for cell in (value.__closure__ or ())) if code else None
        state.append((owner, name, value, code, defaults, closure, value_state(value)))
        if isinstance(value, property):
            # The descriptor object can stay unchanged while its getter code mutates.
            for accessor in ('fget', 'fset', 'fdel'):
                add(value, accessor, getattr(value, accessor))
    def record_class(value):
        # Generated methods may dispatch through super() or a captured base_type.
        # Preserve every actual MRO class/method, not just that class object's ID.
        for parent in value.__mro__:
            if parent is object or parent in seen_classes: continue
            seen_classes.add(parent); mros.append((parent, parent.__mro__))
            namespaces.append((parent, keys(parent)))
            for field, child in vars(parent).items():
                if field not in ('__dict__', '__weakref__'): add(parent, field, child)
    namespaces.append((module, keys(module)))
    for name, value in vars(module).items():
        if name.startswith('__') or name == '_NEXT_CAPSULE': continue
        add(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            record_class(value)
    for value in class_roots:
        need(isinstance(value, type), 'actual generated endpoint class')
        record_class(value)
    return namespaces, state, mros

def unchanged_executable(state):
    namespaces, records, mros = state
    for owner, original_mro in mros:
        need(owner.__mro__ == original_mro and all(a is b for a, b in zip(owner.__mro__, original_mro)),
             'compiled generated endpoint inheritance changed')
    for owner, names in namespaces:
        need(tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE') == names,
             'compiled namespace gained or lost bindings')
    for owner, name, original, code, defaults, closure, data in records:
        actual = getattr(owner, name) if isinstance(owner, property) else vars(owner).get(name)
        if isinstance(actual, (staticmethod, classmethod)): actual = actual.__func__
        need(actual is original, 'compiled namespace/function identity changed')
        if code is not None:
            need(actual.__code__ is code and
                 (value_state(actual.__defaults__), value_state(actual.__kwdefaults__)) == defaults,
                 'compiled executable/defaults changed; co_filename is insufficient')
            current = actual.__closure__ or ()
            need(len(current) == len(closure) and all(cell.cell_contents is old and value_state(cell.cell_contents) == text
                 for cell, (old, text) in zip(current, closure)), 'compiled source closure changed')
        if data is not None: need(value_state(actual) == data, 'compiled source constant changed')

def json_blockable(value):
    # A C-json block is a bounded existing subtree: at most512 scalar/container
    # visits,32768 total string characters and4096 bits per integer. This test
    # retains references only; oversized containers are streamed recursively.
    stack=[value];visits=0;characters=0
    while stack:
        child=stack.pop();visits+=1
        if visits>512:return False
        if type(child) is str:
            characters+=len(child)
            if characters>32768:return False
        elif type(child) is int:
            if child.bit_length()>4096:return False
        elif child is None or type(child) in (bool,float):pass
        elif type(child) is dict:
            if len(child)>512:return False
            for name,item in child.items():
                if type(name) is not str:return False
                stack.append(name);stack.append(item)
                if len(stack)>512:return False
        elif type(child) in (list,tuple):
            if len(child)>512:return False
            stack.extend(child)
            if len(stack)>512:return False
        else:return False
    return True

def json_chunks(value):
    # Full canonical JSON: C blocks only for bounded existing subtrees. No full
    # model/state copy, JSON string or UTF-8 buffer is constructed here.
    if json_blockable(value):
        yield canonical(value)
    elif type(value) is dict:
        yield '{'
        for index,name in enumerate(sorted(value)):
            need(type(name) is str,'literal JSON object keys')
            if index:yield ','
            yield canonical(name)+':'
            yield from json_chunks(value[name])
        yield '}'
    elif type(value) in (list,tuple):
        yield '['
        for start in range(0,len(value),32):
            block=value[start:start+32]
            if start:yield ','
            if json_blockable(block):yield canonical(block)[1:-1]
            else:
                for offset,item in enumerate(block):
                    if offset:yield ','
                    yield from json_chunks(item)
        yield ']'
    else:yield canonical(value)


def syntax_array(value):
    # Storage recognizer only: no signature, capture, rule or grammar decision.
    # Unknown/malformed shapes are retained unchanged for the independent audit.
    if type(value) is not list or not value or type(value[0]) is not str:
        return False
    lengths={'var':2,'fun':3,'bot':1,'eq':3,'pred':3,'all':3,'not':2,'imp':3,'and':3,'or':3}
    return value[0] in lengths and len(value)==lengths[value[0]]


def syntax_atom_key(value):
    # Python False==0 and 0.0==-0.0 must never merge different JSON values/types.
    if value is None:return ('null',)
    if type(value) is bool:return ('bool',value)
    if type(value) is int:return ('int',value)
    if type(value) is float:
        if not math.isfinite(value):return None
        return ('float',value.hex())
    if type(value) is str:return ('str',value)
    return None


def share_syntax_value(value, memo, identities):
    """Value-preserving sharing inside a recognized literal syntax tree only.

    Keys retain every typed scalar and every ordered list child. Returned wire
    nodes remain actual lists, never tuples/codes/alpha-equivalence classes.
    Dictionaries or unexpected objects are not interned. Record/occurrence,
    port arrays, recipe and model identities remain separate containers.
    """
    def tree(node):
        if type(node) is not list:
            key=syntax_atom_key(node)
            return node,key
        old=identities.get(id(node))
        if old is not None and old[0] is node:
            return node,old[1]
        children=[];keys=[]
        for child in node:
            shared,key=tree(child)
            if key is None:
                return node,None
            children.append(shared);keys.append(key)
        key=('list',tuple(keys))
        if key in memo:
            return memo[key],key
        node[:]=children
        memo[key]=node;identities[id(node)]=(node,key)
        return node,key
    if type(value) is not list:
        # Dictionary children already passed through object_pairs_hook. No
        # dictionary record is coalesced, including duplicate Gamma occurrences.
        return value
    if syntax_array(value):
        shared,_=tree(value)
        return shared
    # Root arrays of syntax (registry/Gamma/ports) preserve their original length
    # and order. Pure scalar metadata/factor arrays have no syntax to share.
    for index,child in enumerate(value):
        if type(child) is list:
            value[index]=share_syntax_value(child,memo,identities)
    return value


def parse_shared_syntax(text):
    """Exactly one complete stdlib JSON parse; duplicate-field rules unchanged."""
    need(type(text) is str,'one already authenticated lossless UTF-8 text buffer')
    memo={};identities={}
    def unique(pairs):
        result={}
        for name,value in pairs:
            need(name not in result,'duplicate JSON field')
            result[name]=share_syntax_value(value,memo,identities)
        return result
    result=json.loads(text,object_pairs_hook=unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))
    # Caches belong to this parse only. They do not become persistent authority,
    # runtime input, a second decoded model or a source-level theorem inventory.
    memo.clear();identities.clear()
    return result


def read_lossless_preparation(record, maximum=MAX_METADATA):
    """Authenticate raw bytes, decode losslessly, release bytes BEFORE JSON.

    The decoded text is the exact authenticated buffer's UTF-8 content. No
    pathname reread becomes parse authority. Syntax sharing changes allocation
    only, and full canonical value seals still bracket the actual audit.
    """
    verify(record)
    with Path(record['path']).open('rb') as stream:
        raw=stream.read(maximum+1)
        need(len(raw)<=maximum and stream.read(1)==b'','whole bounded raw input, no prefix')
    need(len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],
         'one exact authenticated raw preparation buffer')
    # Same byte-to-text rule as stdlib json.loads(bytes), including its lossless
    # surrogate handling; the fixed producer witness is UTF-8.
    text=raw.decode(json.detect_encoding(raw),'surrogatepass')
    del raw
    value=parse_shared_syntax(text)
    del text
    verify(record)
    return value


def function_state(fn):
    need(inspect.isfunction(fn), 'actual Python function endpoint')
    return (fn, fn.__code__, id(fn.__defaults__), tuple(id(v) for v in fn.__defaults__ or ()),
        id(fn.__kwdefaults__), tuple((k,id(v)) for k,v in sorted((fn.__kwdefaults__ or {}).items())),
        tuple((id(cell),id(cell.cell_contents)) for cell in fn.__closure__ or ()))


def source_cache_guard(sources, modules, anchors):
    # RAW producer ledger is deliberately excluded from this executable map.
    expected={p['path']:p for p in sources.values() if p['path'].endswith('.py')}
    seen=[]
    for name,module in list(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if type(file) is not str:
            continue
        lexical=Path(file)
        if not lexical.is_absolute():
            lexical=ROOT/lexical
        if not str(lexical).startswith(str(ROOT)+os.sep):
            continue
        path=str(lexical.resolve())
        need(path in expected and not path.endswith(('.pyc','.pyo')), 'only worker/auditor local execution, no producer/cache import')
        need(name==__name__ or any(module is value for value in modules.values()), 'exact raw-loaded module object')
        verify(expected[path]); seen.append(expected[path])
    need(all(modules[role] is anchors[role] and sys.modules.get(modules[role].__name__) is modules[role]
        for role in modules), 'original compiled module namespaces')
    return sorted({p['path']:p for p in seen}.values(),key=lambda p:p['path'])


def value_digest(value, tick):
    # Whole canonical data seal, no second preparation parse or full JSON copy.
    h=hashlib.sha256(); since_boundary=0
    tick()
    for chunk in json_chunks(value):
        raw=chunk.encode('utf8')
        need(len(raw)<=4*1048576, 'bounded canonical data-seal chunk')
        h.update(raw); since_boundary+=len(raw)
        if since_boundary>=65536:
            tick(); since_boundary=0
    tick(); return h.hexdigest()


def authenticate_named(value, closure):
    # Walk raw pins in an already named parsed input only. Never decode ancestors.
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            record=normalize(value); verify(record)
            need(closure.get(record['path'])==record, 'every named-reader raw pin explicitly closed')
            return
        for child in value.values():
            authenticate_named(child,closure)
    elif type(value) is list:
        for child in value:
            authenticate_named(child,closure)


def preflight(plan_path, owner_path):
    plan_pin,owner_pin=pin(plan_path),pin(owner_path)
    plan,owner=read(plan_pin,2*1048576),read(owner_pin,2*1048576)
    fields={'schema','stage','activation','outdir','sources','inputs','source_review','limits',
            'allowed_runtime','source_cache_gate','raw_closure'}
    need(type(plan) is dict and set(plan)==fields and plan['schema']==SCHEMA and plan['stage']=='preparation'
         and canonical(plan['limits'])==canonical(LIMITS), 'exact frozen11-field independent audit leaf')
    need(canonical(plan['activation'])==canonical(dict(schema='ROOT-independent-Q-owned-audit-activation-v1',author_identity='/root',
        ROOT_owned_once_only=True,scope=SCOPE,source_review_not_mathematical_admission=True,
        target_searches=0,native_queries=0,RL_updates=0)), 'explicit ROOT-owned once-only non-search audit activation')
    need(set(plan['sources'])==SOURCE_ROLES and plan['sources']['independent_auditor']==AUDITOR
         and plan['sources']['master']==MASTER and plan['sources']['worker']==pin(Path(__file__).resolve()),
         'exact new executed/raw Source map')
    need(plan['inputs']==FROZEN_INPUTS, 'only exact named existing input metadata/witnesses, no proof word')
    need(plan['source_cache_gate']==dict(executed_roles=['worker','independent_auditor'],
        raw_only_producer_sources=PRODUCER_SOURCES,allow_project_bytecode=False,
        compile_producer_sources=False,execute_producer_sources=False), 'explicit producer-nonexecution cache gate')
    need(plan_path.parent==owner_path.parent, 'one flat generic owner namespace')
    output=Path(plan['outdir'])
    need(output.is_absolute() and output==output.resolve() and output.parent==plan_path.parent and not output.exists(),
         'fresh immutable output namespace, no retry/reuse')
    closure={}
    for record in plan['raw_closure']:
        verify(record); need(record['path'] not in closure,'unique canonical raw closure')
        closure[record['path']]=record
    need(list(closure)==sorted(closure),'canonical sorted complete worker closure')
    reviews=plan['source_review']
    need(type(reviews) is dict and set(reviews)=={'ROOT','worker_independent','auditor_independent'}, 'actual current typed Source review slots')
    direct=[*plan['sources'].values(),*plan['inputs'].values(),*PRODUCER_SOURCES.values(),*reviews.values()]
    for record in direct:
        verify(record); need(closure.get(record['path'])==record, 'all direct raw sources/inputs/reviews closed')
    runtime=plan['allowed_runtime']
    need(type(runtime) is dict and set(runtime)=={'binary','resource_extension','python_version','platform'}
         and runtime['python_version']==[3,9,6] and runtime['platform']=='darwin'
         and list(sys.version_info[:3])==[3,9,6] and sys.platform=='darwin', 'original frozen CLT runtime semantics')
    for role in ('binary','resource_extension'):
        verify(runtime[role]); need(closure.get(runtime[role]['path'])==runtime[role], 'runtime fully raw closed')
    need(str(Path(sys.executable).resolve())==runtime['binary']['path']
         and str(Path(resource.__file__).resolve())==runtime['resource_extension']['path'], 'actual binary/resource extension')
    argv=[runtime['binary']['path'],'-B',plan['sources']['worker']['path'],COMMAND,str(plan_path),str(owner_path)]
    need(set(owner)=={'schema','stage','runtime_binary','worker','argv','worker_receipt','limits','closure','ROOT_source_review','scope'}
         and owner['schema']=='ROOT-guard-native-owned-plan-v1' and owner['stage']=='preparation'
         and owner['limits']==LIMITS and owner['scope']==SCOPE and owner['argv']==argv,
         'strict unchanged generic10-field plan and literal six argv')
    need(normalize(owner['runtime_binary'])==runtime['binary'] and normalize(owner['ROOT_source_review'])==reviews['ROOT']
         and reviews['ROOT']['path']==str(plan_path.parent/'ROOT-source-review-v1.json'), 'generic local genuine ROOT Source review/runtime')
    need((ROOT/owner['worker']).resolve()==Path(plan['sources']['worker']['path'])
         and (ROOT/owner['worker_receipt']).resolve()==output/RECEIPT, 'literal worker/final receipt')
    owner_closure={}
    for raw in owner['closure']:
        record=normalize(raw); verify(record)
        need(record['path'] not in owner_closure,'unique owner closure')
        owner_closure[record['path']]=record
    for record in closure.values():
        need(owner_closure.get(record['path'])==record,'complete worker closure in owner closure')
    need(owner_closure.get(plan_pin['path'])==plan_pin,'owner closes exact leaf plan')
    # Reviews are exact bound Source evidence. No unresolved slots are invented.
    for role in ('ROOT','worker_independent','auditor_independent'):
        review=read(reviews[role]); authenticate_named(review,closure)
        need(review.get('source_only') is True and review.get('source_review_passed') is True
             and review.get('all_checks_passed') is True and review.get('scientific_calls')==0
             and review.get('author_identity')==AUTHOR and review.get('reviewer_identity')!=AUTHOR,
             'genuine distinct-author current Source assessment only')
        if role=='auditor_independent':
            need(review.get('schema')=='independent-Q-mathematical-auditor-Source-review-v1'
                 and review.get('scope')=='complete-finite-Q-catalogue-primitive-domain-and-word-checker-Source'
                 and review.get('sources')=={'independent_auditor':AUDITOR,'master':MASTER}
                 and review.get('source_contract')==FROZEN_INPUTS['auditor_contract'], 'exact frozen auditor typed prerequisite')
        else:
            need(review.get('scope')=='independent-Q-cold-audit-worker-Source'
                 and review.get('sources')==plan['sources'], 'exact new worker Source map/scope')
    return plan,owner,output,plan_pin,owner_pin,closure,owner_closure


def validate_producer(documents, closure):
    receipt=documents['producer_receipt']; evidence=documents['producer_evidence']
    decision=documents['producer_ROOT_final_decision']; seal=documents['producer_ROOT_reconciled_disposition']
    producer_plan=documents['producer_worker_plan']
    need(receipt['schema']=='cold-Q-preparation-controls-receipt-v1' and receipt['stage']=='preparation'
         and receipt['stage_completed'] is True and receipt['all_direct_children_terminal_and_reaped'] is True,
         'whole original producer receipt complete')
    need(receipt['prepared']==FROZEN_INPUTS['producer_preparation'] and receipt['evidence']==FROZEN_INPUTS['producer_evidence']
         and receipt['worker_plan']==FROZEN_INPUTS['producer_worker_plan'], 'actual original result/evidence/source plan coupling')
    need(decision['schema']=='ROOT-fresh-catalog-stage-final-decision-v1'
         and decision['status']=='accepted_complete_owned_stage' and decision['ROOT_final_accepted'] is True
         and len(decision['predicates'])==14 and all(v is True for v in decision['predicates'].values())
         and normalize(decision['worker'])==FROZEN_INPUTS['producer_receipt'], 'genuine original ROOT14 resource closure')
    need(seal['schema']=='ROOT-Q-actual-complete-producer-controls-reconciled-disposition-v2'
         and seal['author_identity']=='/root' and seal['ROOT_complete_scoped_controls_accepted'] is True
         and normalize(seal['resource_qualification'])==FROZEN_INPUTS['producer_ROOT_final_decision']
         and normalize(seal['preparation'])==FROZEN_INPUTS['producer_preparation']
         and normalize(seal['worker_receipt'])==FROZEN_INPUTS['producer_receipt'], 'literal original reconciled ROOT custody')
    need(seal['catalogue_mathematically_admitted'] is False and seal['target_proofs_accepted'] is False
         and seal['target_searches']==0 and seal['native_accepted'] is False and seal['RL_training_runs']==0,
         'producer controls are not mathematical proof/catalogue authority')
    need(producer_plan['sources']==PRODUCER_SOURCES and producer_plan['limits']==LIMITS
         and evidence['sources']==PRODUCER_SOURCES and evidence['worker_plan']==FROZEN_INPUTS['producer_worker_plan']
         and evidence['prepared']==FROZEN_INPUTS['producer_preparation'], 'same exact full producer seven-role ledger')
    for name in ('independent_mathematical_catalogue_admission','universal_theorem_discovered','scientific_search_activation'):
        need(receipt[name] is False and evidence[name] is False,'original stronger acceptance remains false')
    owner_pin=normalize(receipt['owner_plan'])
    need(owner_pin==normalize(decision['plan']) and closure.get(owner_pin['path'])==owner_pin,'named actual producer owner plan')
    owner=read(owner_pin); authenticate_named(owner,closure)
    need(owner['schema']=='ROOT-guard-native-owned-plan-v1' and owner['stage']=='preparation'
         and owner['limits']==LIMITS,'original resource plan, no change of limits')
    need(normalize(owner['runtime_binary'])==producer_plan['runtime']['binary'], 'same original producer runtime')
    for raw in producer_plan['closure']+owner['closure']:
        record=normalize(raw); verify(record)
        need(closure.get(record['path'])==record,'every explicit original worker/owner raw closure retained')
    return owner_pin


def main():
    original_clock=time.perf_counter; original_usage=resource.getrusage
    began=original_clock()
    need(len(sys.argv)==4 and sys.argv[1]==COMMAND,'one literal independent cold audit invocation')
    plan_path,owner_path=(Path(p) for p in sys.argv[2:])
    need(all(p.is_absolute() and p==p.resolve() for p in (plan_path,owner_path)),'canonical actual leaf/owner plans')
    own=sys.modules[__name__]
    # Anchor own validators before loading any project Source, including helpers
    # that the nested rejecting clocks and invoking shim would otherwise trust.
    validator_names=('need','canonical','pin','verify','parse','read','load','normalize','value_state',
        'executable_state','unchanged_executable','json_blockable','json_chunks','syntax_array','syntax_atom_key',
        'share_syntax_value','parse_shared_syntax','read_lossless_preparation','function_state',
        'source_cache_guard','value_digest','authenticate_named','preflight','validate_producer')
    validator_functions={name:globals()[name] for name in validator_names}
    validator_codes={name:fn.__code__ for name,fn in validator_functions.items()}
    original_state=function_state; original_state_code=function_state.__code__
    own_state=executable_state(own)
    # Seal the stdlib parser/decoder/scanner and canonical encoder hooks too.
    # Their native implementation remains part of the exact declared runtime;
    # project Source may not replace their Python functions/classes/bindings.
    parser_states=tuple(executable_state(module)
        for module in (json,json.decoder,json.scanner,json.encoder))
    def own_check():
        if time.perf_counter is not original_clock or resource.getrusage is not original_usage:
            raise ValueError('original clock/resource endpoints changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original own function-state validator changed')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('original own loader/rejection/serialization validator changed')
        unchanged_executable(own_state)
        for state in parser_states:
            unchanged_executable(state)
    own_check_fn=own_check; own_check_anchor=function_state(own_check_fn)
    inner_began=time.perf_counter(); deadline=inner_began+20
    def whole_tick():
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original own function-state validator changed before limits')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before whole limit delegation')
        if function_state(own_check_fn)!=own_check_anchor:
            raise ValueError('original own invoking validator changed')
        own_check_fn()
        need(time.perf_counter()-began<55 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<500*1048576,
             'whole55/500 with fixed inherited60/512 owner finish reserves')
    whole_tick_fn=whole_tick; whole_tick_anchor=function_state(whole_tick_fn)
    def tick(inner=False):
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original own function-state validator changed before limit callback')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before limit callback')
        if function_state(whole_tick_fn)!=whole_tick_anchor:
            raise ValueError('whole rejecting callback code/default/closure changed')
        whole_tick_fn()
        if inner and time.perf_counter()>=deadline:
            raise TimeoutError('complete independent audit exceeds one shared20; no accepted prefix')
    tick_fn=tick; tick_anchor=function_state(tick_fn)
    # Both metadata preflight and Source/input loading/decoding are charged to
    # the same20 deadline; no later phase restarts that clock.
    tick_fn()
    plan,owner,output,plan_pin,owner_pin,closure,owner_closure=preflight(plan_path,owner_path)
    tick_fn(); output.mkdir()
    artifacts=[]; partial_paths=[]; serialization=[]; receipt_path=None; module=None
    modules={}; module_anchors={}; module_states=[]; entry=None; entry_anchor=None
    def source_guard():
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own validator changed before Source guard')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('own validator changed before Source guard')
        if function_state(tick_fn)!=tick_anchor:
            raise ValueError('original clock/delegation callback changed')
        tick_fn()
        for state in module_states:
            unchanged_executable(state)
        source_cache_guard(plan['sources'],modules,module_anchors)
        if entry is not None:
            need(module.audit_saved_profile is entry and function_state(entry)==entry_anchor
                 and entry.__globals__ is module.__dict__,'original effective auditor callable/code/globals')
    source_guard_fn=source_guard; source_guard_code=source_guard_fn.__code__; source_guard_anchor=function_state(source_guard_fn)
    def invoke_guard():
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own validator changed before delegated guard')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('own validator changed before delegated guard')
        if function_state(source_guard_fn)!=source_guard_anchor:
            raise ValueError('original Source callback code/default/closure authority changed')
        source_guard_fn()
        if function_state(source_guard_fn)!=source_guard_anchor:
            raise ValueError('Source callback changed during delegation')
    invoke_fn=invoke_guard; invoke_code=invoke_fn.__code__; invoke_anchor=function_state(invoke_fn)
    def boundary(inner=False):
        # Direct outer check protects the shim itself, not only the callback it invokes.
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own validator changed before outer boundary')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('own validators changed before outer boundary')
        if function_state(invoke_fn)!=invoke_anchor or function_state(tick_fn)!=tick_anchor:
            raise ValueError('original outer shim/clock/default/cell authority changed')
        invoke_fn(); tick_fn(inner)
    boundary_fn=boundary; boundary_code=boundary_fn.__code__; boundary_anchor=function_state(boundary_fn)
    def checked_boundary(inner=False):
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('own validator changed before checked boundary')
        if any(globals()[name] is not fn or fn.__code__ is not validator_codes[name]
               for name,fn in validator_functions.items()):
            raise ValueError('own validators changed before checked boundary')
        if function_state(boundary_fn)!=boundary_anchor:
            raise ValueError('original outer boundary executable authority changed')
        boundary_fn(inner)
    checked_fn=checked_boundary; checked_code=checked_fn.__code__; checked_anchor=function_state(checked_fn)
    def save(name,value,*,inner):
        need(type(name) is str and Path(name).name==name and name.endswith('.json'),'owned output basename')
        before=time.perf_counter(); path=output/name; partial_paths.append(str(path)); count=0; largest=0
        with path.open('xb') as stream:
            for chunk in json_chunks(value):
                if function_state is not original_state or function_state.__code__ is not original_state_code:
                    raise ValueError('own writer state validator changed')
                if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key]
                       for key,fn in validator_functions.items()):
                    raise ValueError('own writer validators changed')
                if function_state(checked_fn)!=checked_anchor:
                    raise ValueError('original checked writer boundary changed')
                if function_state is not original_state or function_state.__code__ is not original_state_code:
                    raise ValueError('original function-state predicate changed before delegation')
                if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
                    raise ValueError('original own predicate changed before delegation')
                if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
                    raise ValueError('original effective checked boundary changed')
                checked_fn(inner)
                raw=chunk.encode('utf8'); count+=len(raw); largest=max(largest,len(raw))
                need(len(raw)<=4*1048576 and count<=MAX_METADATA,'bounded full output stream, no prefix certification')
                need(stream.write(raw)==len(raw),'whole encoded stream block written')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state predicate changed after writer')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own validators changed after writer')
        if function_state(checked_fn)!=checked_anchor:
            raise ValueError('original postwrite boundary changed')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(inner)
        record=pin(path); artifacts.append(record); partial_paths.remove(str(path))
        serialization.append(dict(file=record,bytes=count,maximum_block_bytes=largest,
            inclusive_encoding_write_seconds=time.perf_counter()-before,inside_shared20=inner))
        return record
    save_fn=save; save_code=save_fn.__code__; save_anchor=function_state(save_fn)
    try:
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        # Parse precisely named small documents. The two witness files remain
        # whole byte streams; the large preparation is decoded exactly once.
        documents={role:read(record) for role,record in plan['inputs'].items()
                   if role not in ('initial_state','initial_oracle_domains','producer_preparation')}
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        for document in documents.values():
            authenticate_named(document,closure)
        validate_producer(documents,closure)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original state predicate changed after producer validation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own validators changed after producer validation')
        if function_state(checked_fn)!=checked_anchor:
            raise ValueError('original checked boundary changed after producer validation')
        checked_fn(True)
        contract=documents['auditor_contract']
        need(contract['schema']=='independent-Q-mathematical-auditor-Source-contract-v1'
             and contract['sources']=={'independent_auditor':AUDITOR,'master':MASTER}
             and contract['producer_provenance_raw_only']==PRODUCER_SOURCES
             and contract['declaration']==FROZEN_INPUTS['declaration'],'exact frozen auditor/read-site specification')
        preparation=read_lossless_preparation(plan['inputs']['producer_preparation'])
        # No root-count/proof/outcome-specific selection and no producer call.
        input_values={'declaration':documents['declaration'],'preparation':preparation,
                      'producer_sources':PRODUCER_SOURCES}
        seals={name:value_digest(value,lambda:checked_fn(True)) for name,value in input_values.items()}
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        module=load(AUDITOR,'independent_complete_Q_auditor_v1')
        modules['independent_auditor']=module; module_anchors['independent_auditor']=module
        module_states.append(executable_state(module))
        entry=module.audit_saved_profile; entry_anchor=function_state(entry)
        need(entry.__code__.co_filename==AUDITOR['path'],'actual independent auditor raw entry origin')
        # Sole setup transition: exact raw module, entry and entry-state cells
        # have now been filled. All callback code is unchanged; their final
        # defaults/cell identities are sealed before any semantic auditor call.
        if (source_guard_fn.__code__ is not source_guard_code or invoke_fn.__code__ is not invoke_code
                or boundary_fn.__code__ is not boundary_code or checked_fn.__code__ is not checked_code
                or save_fn.__code__ is not save_code):
            raise ValueError('original callback code changed during raw module setup')
        source_guard_anchor=function_state(source_guard_fn)
        invoke_anchor=function_state(invoke_fn)
        boundary_anchor=function_state(boundary_fn)
        checked_anchor=function_state(checked_fn)
        save_anchor=function_state(save_fn)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        certificate=entry(declaration=documents['declaration'],preparation=preparation,
            expected_source_bindings=PRODUCER_SOURCES,source_guard=invoke_fn,deadline=deadline,
            initial_state_record=plan['inputs']['initial_state'],initial_oracle_record=plan['inputs']['initial_oracle_domains'])
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        need(certificate['schema']=='independent-complete-Q-catalogue-point-audit-v1'
             and certificate['completed'] is True
             and certificate['all_catalogue_primitive_and_initial_domains_accepted'] is True
             and certificate['source_bindings']==PRODUCER_SOURCES,'entire actual independent audit return, no prefix')
        for flag in ('ROOT_admission_issued','ROOT_resource_accepted','target_proof_discovered','native_accepted',
                     'full24_accepted','full_trajectory_accepted','full_PA_accepted','induction_accepted','FOL_complete'):
            need(certificate[flag] is False,'narrow mathematical audit only, no stronger acceptance')
        for name,value in input_values.items():
            need(value_digest(value,lambda:checked_fn(True))==seals[name],'entire original decoded inputs unchanged')
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        if function_state(save_fn)!=save_anchor:
            raise ValueError('original owned writer code/default/closure changed')
        certificate_pin=save_fn('Q-independent-audit-certificate-provisional-v1.json',certificate,inner=True)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        inner_seconds=time.perf_counter()-inner_began
        # Final Source/result serialization check is part of20. All subsequent
        # evidence/receipt/exit work is still charged to55/500 and owned60/512.
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn(True)
        evidence=dict(schema='cold-independent-Q-audit-evidence-v1',sources=plan['sources'],
            raw_only_producer_sources=PRODUCER_SOURCES,inputs=plan['inputs'],worker_plan=plan_pin,owner_plan=owner_pin,
            certificate=certificate_pin,decoded_preparation_count=1,producer_project_calls=0,
            independent_module_raw_loaded=True,executed_raw_project_source_ledger=source_cache_guard(plan['sources'],modules,module_anchors),
            complete_initial_state_and_oracle_EOF_comparisons=True,
            original_decoded_input_sha256=seals,inner_seconds_before_final_guard=inner_seconds,
            serialization_records_before_evidence=list(serialization),ROOT_admission_issued=False,
            ROOT_resource_accepted=False,target_searches=0,target_proofs=0,native_queries=0,RL_updates=0,
            full24_accepted=False,full_trajectory_accepted=False,induction_accepted=False,full_PA_accepted=False)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn()
        if function_state(save_fn)!=save_anchor:
            raise ValueError('original evidence writer changed')
        evidence_pin=save_fn('Q-independent-audit-evidence-v1.json',evidence,inner=False)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn()
        receipt_path=output/RECEIPT
        receipt=dict(schema='cold-independent-Q-audit-receipt-v1',stage='preparation',stage_completed=True,
            status='completed_independent_finite_Q_audit_pending_ROOT',scientific_stage='complete_Q_catalogue_primitive_initial_domains',
            worker_plan=plan_pin,owner_plan=owner_pin,certificate=certificate_pin,evidence=evidence_pin,
            all_direct_children_terminal_and_reaped=True,direct_children_peak_sum_bytes=0,
            independent_audit_completed=True,ROOT_mathematical_admission_issued=False,resource_acceptance_issued=False,
            target_searches=0,target_proofs=0,native_queries=0,RL_updates=0,
            native_accepted=False,full24_accepted=False,full_trajectory_accepted=False,full_PA_accepted=False,
            worker_elapsed_before_receipt_seconds=time.perf_counter()-began,
            worker_SELF_peak_before_receipt_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            output_closure_before_receipt=list(artifacts),serialization_records_before_receipt=list(serialization))
        if function_state(save_fn)!=save_anchor:
            raise ValueError('original receipt writer changed')
        receipt_pin=save_fn(RECEIPT,receipt,inner=False)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn()
        post=dict(schema='cold-independent-Q-audit-postwrite-observation-v1',receipt=receipt_pin,
            certificate=certificate_pin,evidence=evidence_pin,elapsed_seconds_after_receipt_write=time.perf_counter()-began,
            peak_SELF_bytes_after_receipt_write=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Includes completed receipt bytes; owner postwrite scope separately includes this record and final print.',
            resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False)
        if function_state(save_fn)!=save_anchor:
            raise ValueError('original postwrite writer changed')
        post_pin=save_fn('Q-independent-audit-postwrite-observation-v1.json',post,inner=False)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn()
        print(canonical(dict(stage_completed=True,receipt=receipt_pin,postwrite=post_pin,
            worker_elapsed_after_writes_seconds=time.perf_counter()-began,
            worker_SELF_peak_after_writes_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            target_searches=0,resource_acceptance_issued=False,ROOT_mathematical_admission_issued=False)),flush=True)
        if function_state is not original_state or function_state.__code__ is not original_state_code:
            raise ValueError('original function-state predicate changed before delegation')
        if any(globals()[key] is not fn or fn.__code__ is not validator_codes[key] for key,fn in validator_functions.items()):
            raise ValueError('original own predicate changed before delegation')
        if checked_fn is not checked_boundary or checked_fn.__code__ is not checked_code or function_state(checked_fn)!=checked_anchor:
            raise ValueError('original effective checked boundary changed')
        checked_fn()
    except BaseException as exc:
        # Any later guard/print/whole-cap failure withdraws the success latch.
        # Earlier files remain provisional and cannot be admitted as a prefix.
        if receipt_path is not None and receipt_path.exists():
            withdrawn=output/'Q-independent-audit-result-withdrawn-v1.json'
            receipt_path.rename(withdrawn)
            artifacts=[pin(withdrawn) if record['path']==str(receipt_path) else record for record in artifacts]
        failure=dict(schema='cold-independent-Q-audit-failure-v1',stage='preparation',stage_completed=False,
            status='UNKNOWN_incomplete_independent_Q_audit',error=dict(type=type(exc).__name__,message=str(exc)[:512]),
            worker_plan=plan_pin,owner_plan=owner_pin,provisional_artifacts=artifacts,partial_paths=partial_paths,
            accepted_prefix=False,ROOT_mathematical_admission_issued=False,resource_acceptance_issued=False,
            target_searches=0,target_proofs=0,native_queries=0,RL_updates=0)
        raw=(canonical(failure)+'\n').encode('utf8')
        if len(raw)<=1048576:
            with (output/'failure-v1.json').open('xb') as stream:
                stream.write(raw)
        raise


if __name__=='__main__':
    main()
