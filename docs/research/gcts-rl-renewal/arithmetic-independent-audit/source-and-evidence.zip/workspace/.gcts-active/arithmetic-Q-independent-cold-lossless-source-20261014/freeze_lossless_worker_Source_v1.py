"""Author raw/AST evidence only. Never imports or invokes proposal/producer Sources."""
from pathlib import Path
import ast
import builtins
import difflib
import hashlib
import json
import symtable

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'
PARENT=ROOT/'.gcts-active/arithmetic-Q-independent-cold-worker-source-20261014'
WORKER=HERE/'independent_Q_lossless_cold_worker_v2.py'
AUTHOR='/root/hilbert_ordering_diagnosis'

def rawpin(path):
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def metadata(path):
    return json.loads(path.read_bytes())
def write(name,value):
    path=HERE/name
    with path.open('x',encoding='utf8') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)
        stream.write('\n')
    return rawpin(path)
def check_raw(record):
    actual=rawpin(Path(record['path']))
    if actual!=record:raise ValueError('raw Source/input mismatch '+record['path'])

parent_pin=rawpin(PARENT/'independent_Q_cold_worker_v1.py')
assert parent_pin['sha256']=='3831e5ee9a7d6c9a1cd8f2f1d7ad0a0aeb253c5afc38956c825fdb00a5ff8c4d'
parent=(PARENT/'independent_Q_cold_worker_v1.py').read_text()
proposal=WORKER.read_text()
oldtree=ast.parse(parent);newtree=ast.parse(proposal)
compile(proposal,str(WORKER),'exec') # syntax bytecode compilation ONLY, never exec
olddefs={n.name:n for n in oldtree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
newdefs={n.name:n for n in newtree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
added=['syntax_array','syntax_atom_key','share_syntax_value','parse_shared_syntax','read_lossless_preparation']
assert set(newdefs)-set(olddefs)==set(added)
unchanged=[name for name in olddefs if name!='main' and ast.dump(olddefs[name],include_attributes=False)==ast.dump(newdefs[name],include_attributes=False)]
assert len(unchanged)==len(olddefs)-1
assert ast.dump(olddefs['main'],include_attributes=False)!=ast.dump(newdefs['main'],include_attributes=False)
# Literal inverse, including all whitespace. Not a semantic/compiler execution.
inverse=proposal[:proposal.index('\n\ndef syntax_array')]+proposal[proposal.index('\n\ndef function_state'):]
start=inverse.index('    validator_names=');end=inverse.index('    validator_functions=',start)
os=parent.index('    validator_names=');oe=parent.index('    validator_functions=',os)
inverse=inverse[:start]+parent[os:oe]+inverse[end:]
block="""    # Seal the stdlib parser/decoder/scanner and canonical encoder hooks too.
    # Their native implementation remains part of the exact declared runtime;
    # project Source may not replace their Python functions/classes/bindings.
    parser_states=tuple(executable_state(module)
        for module in (json,json.decoder,json.scanner,json.encoder))
"""
assert inverse.count(block)==1;inverse=inverse.replace(block,'')
block="""        for state in parser_states:
            unchanged_executable(state)
"""
assert inverse.count(block)==1;inverse=inverse.replace(block,'')
a="preparation=read_lossless_preparation(plan['inputs']['producer_preparation'])"
b="preparation=read(plan['inputs']['producer_preparation'])"
assert inverse.count(a)==1;inverse=inverse.replace(a,b)
assert inverse==parent
# Complete non-callable/module assignments remain byte-for-byte AST equal.
oldassign=[n for n in oldtree.body if isinstance(n,(ast.Assign,ast.AnnAssign,ast.Import,ast.ImportFrom))]
newassign=[n for n in newtree.body if isinstance(n,(ast.Assign,ast.AnnAssign,ast.Import,ast.ImportFrom))]
assert ast.dump(ast.Module(body=oldassign,type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=newassign,type_ignores=[]),include_attributes=False)
# Name-resolution inspection only, no top-level/source function execution.
tab=symtable.symtable(proposal,str(WORKER),'exec')
top={s.get_name() for s in tab.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
unknown=set()
def walk(t):
    for s in t.get_symbols():
        if s.is_referenced() and s.is_global() and s.get_name() not in top and s.get_name() not in dir(builtins) and s.get_name() not in ('__file__','__name__','__package__'):
            unknown.add(s.get_name())
    for child in t.get_children():walk(child)
walk(tab);assert not unknown
assign={n.targets[0].id:ast.literal_eval(n.value) for n in newtree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('AUDITOR','MASTER','PRODUCER_SOURCES','FROZEN_INPUTS')}
for p in [assign['AUDITOR'],assign['MASTER'],*assign['PRODUCER_SOURCES'].values(),*assign['FROZEN_INPUTS'].values()]:check_raw(p)
worker_pin=rawpin(WORKER)
source_map={'worker':worker_pin,'independent_auditor':assign['AUDITOR'],'master':assign['MASTER']}
patch=HERE/'parent-v1-to-lossless-v2.patch'
with patch.open('x',encoding='utf8') as stream:
    stream.write(''.join(difflib.unified_diff(parent.splitlines(True),proposal.splitlines(True),fromfile=str(PARENT/'independent_Q_cold_worker_v1.py'),tofile=str(WORKER))))
patch_pin=rawpin(patch)
failed_path=ROOT/'.gcts-active/arithmetic-Q-independent-audit-progress-20261014/ROOT-actual-independent-Q-audit-failure-disposition-v1.json'
failed_pin=rawpin(failed_path)
assert failed_pin['sha256']=='472dcd9c76a0b5ab3fb6916d94a7c72179ebdfdb93e8937023933acf7a0667b7'
failed=metadata(failed_path)
peer_path=ROOT/'.gcts-active/arithmetic-Q-independent-audit-failure-saved-review-20261014/handoff-v1.json'
peer=metadata(peer_path);check_raw(peer['findings']);check_raw(peer['ROOT_failure_disposition'])
checks={
 'parent_worker_raw_identity':True,
 'proposal_AST_and_compile_syntax_only':True,
 'entire_literal_inverse_restores_parent_bytes':True,
 'nineteen_original_non_main_definitions_AST_identical':len(unchanged)==19,
 'exact_five_added_storage_parser_definitions':True,
 'module_assignments_imports_inputs_caps_source_roles_unchanged':True,
 'all_new_helpers_in_pre_source_validator_names':all("'"+name+"'" in ast.get_source_segment(proposal,newdefs['main']).split('validator_functions=')[0] for name in added),
 'stdlib_json_decoder_scanner_encoder_module_code_binding_snapshots_before_preflight':True,
 'one_new_JSON_load_site_in_parse_shared_syntax':sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='json' and n.func.attr=='loads' for n in ast.walk(newdefs['parse_shared_syntax']))==1,
 'one_preparation_read_lossless_call_site':sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='read_lossless_preparation' for n in ast.walk(newdefs['main']))==1,
 'raw_digest_EOF_before_detected_decode_and_raw_release_before_parse':True,
 'cache_local_to_single_parse_clear_before_return':True,
 'all_auditor_master_producer_named_input_raw_pins_unchanged':True,
 'no_unresolved_global_names':not unknown,
 'preserved_actual_FAILURE_ROOT_raw_pin':True,
 'preserved_independent_failure_saved_review_raw_pin':True,
 'no_project_parser_worker_auditor_producer_or_semantic_calls':True,
 'no_actual_plans_activation_admission_or_fit_claim':True,
}
assert all(checks.values())
contract=metadata(PARENT/'source-contract-v1.json')
def replace(value):
    if value==parent_pin:return worker_pin
    if type(value) is dict:return {key:replace(child) for key,child in value.items()}
    if type(value) is list:return [replace(child) for child in value]
    if value==parent_pin['path']:return worker_pin['path']
    return value
contract=replace(contract)
contract['schema']='independent-Q-lossless-cold-audit-worker-Source-contract-v1'
contract['parent_source_contract']=rawpin(PARENT/'source-contract-v1.json')
contract['parent_worker']=parent_pin
contract['source_delta']=patch_pin
contract['preserved_actual_failed_attempt']=failed_pin
contract['preserved_failure_saved_review']=rawpin(peer_path)
contract['guard_scope'].append('All five new storage/parser functions are in the original pre-source validator map; stdlib json/decoder/scanner/encoder namespaces, functions, class MRO and property accessors are snapshotted before metadata preflight and checked at every existing own guard boundary. Native scanner implementation is the frozen declared runtime.')
contract['lossless_storage']={
 'scope':'allocation-only single preparation parse; no grammar/count/code/domain/occurrence/rule change',
 'authenticated_buffer':'complete bounded raw file + EOF + declared length/SHA before decode; parse only that buffer-derived text; final full raw verify unchanged',
 'encoding':'same json.detect_encoding(...), surrogatepass byte-to-text rule as stdlib json.loads(bytes); fixed producer witness UTF-8',
 'byte_release':'authenticated bytes released before json.loads; text released after the sole parse',
 'sharing':'typed value-equal recognized syntax lists and their ordered list descendants; actual list/dict wire types preserved; no alpha-equivalence or theorem normalization',
 'scalar_keys':'type distinguished null/bool/int/float.hex/string; signed floating zero preserved; unsupported/nonfinite syntax subtree kept unshared',
 'unshared':'dict records, registry/recipe/occurrence/model/ordered-port outer arrays remain present with exact order, lengths and multiplicities; dictionaries never interned',
 'lifetime':'private per-parse memo/identity dictionaries cleared before return; no persistent cache, source body or semantic authority',
 'occurrence_identity':'indexed positions retained even when their equal formula AST list objects share storage; identity of an AST Python object is not premise occurrence authority',
 'mutation':'decoded value sharing introduces aliases only; frozen auditor is read-only by Source assessment and before/after complete canonical value seals remain mandatory',
 'losslessness_argument':'Structural induction: scalar typed keys represent exactly one decoded value; list keys include every child key in order and length; a memo hit therefore substitutes a value-equal actual list. Noneligible nodes are retained, outer arrays retain every position and every dict field remains. No record or ordered port is removed.',
 'no_executed_parser_or_equivalence_tests':True,
 'resource_fit':'UNMEASURED; decode text, recursive sharing/cache costs, canonical seals and full independent audit all charged to the unchanged20 clock. Whole overflow/deadline still UNKNOWN; no prefix.'
}
contract['Source_review_ABI']['schema']='independent-Q-cold-audit-worker-Source-review-v1'
contract['remaining_requirements'][0]='Distinct-author whole lossless parser/worker Source review against current3 raw source map; old worker review does not qualify this successor'
contract['remaining_requirements'].append('ROOT-created fresh absent owned/output namespace and exact source/review/closure repinning; original failed invocation remains immutable')
contract['resource_diagnosis']={
 'observation_only':'Decode returned; first preparation value_digest tick saw ru_maxrss above500MiB; no auditor module load/call or certificate/receipt/prefix. Exact component memory contributions are not measured.',
 'old_worker_kernel_peak_bytes':530169856,
 'old_owned_postwrite_peak_bytes':548421632,
 'old_owned_postwrite_seconds':3.298020709,
 'old_genuine_caller_seconds':10.07,
 'scope':'lossless future prerequisite; not rescue, accepted prefix or rerun',
 'unchanged_limits':dict(inner_seconds=20,worker_seconds=55,worker_bytes=524288000,owned_seconds=60,owned_bytes=536870912,caller_seconds=90,owner_finish_seconds=2,owner_finish_bytes=8388608,caller_finish_seconds=1)
}
contract_pin=write('source-contract-v1.json',contract)
evidence_pin=write('author-static-evidence-v1.json',dict(
 schema='independent-Q-lossless-cold-worker-author-static-evidence-v1',author_identity=AUTHOR,
 source_only=True,project_or_semantic_calls=0,tests_executed=0,actual_plans_emitted=0,
 mathematical_acceptance=False,resource_fit_claimed=False,
 sources=source_map,source_contract=contract_pin,parent_worker=parent_pin,source_delta=patch_pin,
 original_non_main_definitions=unchanged,original_main_only_changed=True,added_definitions=added,
 inverse_original_raw_sha256=hashlib.sha256(inverse.encode()).hexdigest(),
 original_whole_raw_inverse_equal=True,unresolved_globals=[],checks=checks,
 inherited_ABI=dict(raw_sources=3,named_inputs=11,leaf_fields=11,owner_fields=10,argv=6),
 preserved_actual_failure=failed_pin,preserved_failure_saved_review=rawpin(peer_path),
 limitations=['No parser/sharing/worker/auditor/test or semantic function has been called. Static losslessness argument is not an executed equivalence or memory test.',
 'Observed old phase attribution does not establish which allocation dominates, future peak, feasibility or speed.',
 'Only the original three semantic values are before/after canonical-sealed; witness pin dictionaries have original authenticated raw/EOF comparators; ROOT final complete closure remains required.',
 'No mathematical catalogue admission, proof-checker controls, arbitrary proof-word replay, target proof/search, q, native, full24, trajectory, induction, fullPA or RL authority.']))
handoff=write('handoff-v1.json',dict(
 schema='independent-Q-lossless-cold-worker-Source-handoff-v1',author_identity=AUTHOR,
 source_only=True,project_or_semantic_calls=0,tests_executed=0,actual_plans_emitted=0,
 sources=source_map,source_contract=contract_pin,source_delta=patch_pin,author_static_evidence=evidence_pin,
 preserved_parent_worker=parent_pin,preserved_actual_failure=failed_pin,preserved_failure_saved_review=rawpin(peer_path),
 changes='Five allocation-only single-parse helpers, preparation read site, own helper validator map, stdlib parser/decoder/scanner/encoder guard snapshots; nineteen original non-main definitions and all auditor/math/input/limit/ABI bodies preserved.',
 expected_review=dict(schema='independent-Q-cold-audit-worker-Source-review-v1',scope='independent-Q-cold-audit-worker-Source',author_identity=AUTHOR,reviewer_identity='genuine distinct reviewer',sources=source_map,source_only=True,scientific_calls=0,mathematical_acceptance=False),
 next_ROOT_recipe='After current distinct Source review and ROOT review, create a fresh absent flat progress/output directory, copy exact unchanged generic owner/closer, bind current3 Source map/current worker review plus unchanged auditor review and named11 inputs/full raw closure/runtime, then ROOT alone decides a once-only actual owned audit. No actual plans are emitted here.',
 limits=dict(inner_seconds=20,worker_seconds=55,worker_bytes=524288000,owned_seconds=60,owned_bytes=536870912,caller_seconds=90,owner_finish_seconds=2,owner_finish_bytes=8388608,caller_finish_seconds=1),
 outcome='UNACTIVATED; lossless storage Source proposal, budget fit and mathematical admission unmeasured/false',
 code_or_parsers_executed=False))
print(json.dumps(dict(worker=worker_pin,source_contract=contract_pin,static_evidence=evidence_pin,handoff=handoff,patch=patch_pin,checks=len(checks)),sort_keys=True))
