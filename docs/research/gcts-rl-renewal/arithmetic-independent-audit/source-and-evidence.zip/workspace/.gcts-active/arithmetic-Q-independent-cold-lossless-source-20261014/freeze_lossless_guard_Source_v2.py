"""Raw bytes/AST author evidence only; no proposal/helper/parser invocation."""
from pathlib import Path
import ast,builtins,difflib,hashlib,json,symtable
ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'
REVIEW=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-review-source-20261014'
AUTHOR='/root/hilbert_ordering_diagnosis'
def pin(path):
 raw=path.read_bytes();return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
def read(path):return json.loads(path.read_bytes())
def check(p):assert pin(Path(p['path']))==p,p['path']
def write(name,value):
 p=HERE/name
 with p.open('x',encoding='utf8') as f:json.dump(value,f,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False);f.write('\n')
 return pin(p)
a_path=HERE/'independent_Q_lossless_cold_worker_v2.py';b_path=HERE/'independent_Q_lossless_cold_worker_v3.py'
a_pin=pin(a_path);assert a_pin['sha256']=='75e3a188833e72a1bcdc2a084449f34b2c38f3b46838fc1d0a483f6ff77d251a'
a=a_path.read_text();b=b_path.read_text();ta=ast.parse(a);tb=ast.parse(b);compile(b,str(b_path),'exec')
anchor="""    # Mixed native/Python defaults cannot be sealed by JSON text: that text
    # becomes None. Preserve exact functions, every default entry and closure
    # cell/content identity through the original function-state validator.
    parser_function_anchors=[]
    for _,records,_ in parser_states:
        for owner,name,fn,code,_,_,_ in records:
            if code is None:
                continue
            descriptor=getattr(owner,name) if isinstance(owner,property) else vars(owner).get(name)
            effective=getattr(owner,name)
            if isinstance(descriptor,classmethod):
                binding=('class',effective.__self__,effective.__func__)
            else:
                binding=('direct',effective)
            parser_function_anchors.append((owner,name,descriptor,fn,original_state(fn),binding))
    parser_function_anchors=tuple(parser_function_anchors)
"""
boundary="""        for owner,name,descriptor,fn,anchor,binding in parser_function_anchors:
            current=getattr(owner,name) if isinstance(owner,property) else vars(owner).get(name)
            if current is not descriptor or original_state(fn)!=anchor:
                raise ValueError('original parser function/default/closure authority changed')
            effective=getattr(owner,name)
            if binding[0]=='class':
                if (getattr(effective,'__self__',None) is not binding[1]
                        or getattr(effective,'__func__',None) is not binding[2]):
                    raise ValueError('original effective parser class-method binding changed')
            elif effective is not binding[1]:
                raise ValueError('original effective parser function/accessor binding changed')
"""
assert b.count(anchor)==1 and b.count(boundary)==2
inverse=b.replace(anchor,'').replace(boundary,'');assert inverse==a
olddefs={n.name:n for n in ta.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
newdefs={n.name:n for n in tb.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert set(olddefs)==set(newdefs)
unchanged=[n for n in olddefs if n!='main' and ast.dump(olddefs[n],include_attributes=False)==ast.dump(newdefs[n],include_attributes=False)]
assert len(unchanged)==24
assert ast.dump(ast.Module(body=[n for n in ta.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=[n for n in tb.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef))],type_ignores=[]),include_attributes=False)
main=newdefs['main'];own_check=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='own_check')
loops=[n for n in own_check.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='parser_function_anchors']
assert len(loops)==2 and ast.dump(loops[0],include_attributes=False)==ast.dump(loops[1],include_attributes=False)
first=own_check.body.index(loops[0]);last=own_check.body.index(loops[1])
assert all(n.lineno<loops[0].lineno for n in own_check.body[:first] if isinstance(n,ast.If))
assert any(isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='unchanged_executable' for n in own_check.body[first+1:last])
tab=symtable.symtable(b,str(b_path),'exec');top={s.get_name() for s in tab.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()};unknown=set()
def walk(t):
 for s in t.get_symbols():
  if s.is_referenced() and s.is_global() and s.get_name() not in top and s.get_name() not in dir(builtins) and s.get_name() not in ('__file__','__name__','__package__'):unknown.add(s.get_name())
 for c in t.get_children():walk(c)
walk(tab);assert not unknown
v2contract=read(HERE/'source-contract-v1.json');negative=read(REVIEW/'handoff-v1.json')
assert negative['source_review_passed'] is False and negative['all_checks_passed'] is False and negative['worker']==a_pin
for p in [negative['findings'],negative['typed_Source_review'],negative['worker'],negative['source_contract']]:check(p)
for p in [v2contract['sources']['independent_auditor'],v2contract['sources']['master'],*v2contract['raw_only_producer_sources'].values(),*v2contract['named_inputs'].values()]:check(p)
b_pin=pin(b_path)
def replace(value):
 if value==a_pin:return b_pin
 if type(value) is dict:return {k:replace(v) for k,v in value.items()}
 if type(value) is list:return [replace(v) for v in value]
 if value==a_pin['path']:return b_pin['path']
 return value
contract=replace(v2contract)
patch=HERE/'lossless-v2-to-v3-default-guard-only.patch'
with patch.open('x',encoding='utf8') as f:f.write(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(a_path),tofile=str(b_path))))
patch_pin=pin(patch)
contract['parent_source_contract']=pin(HERE/'source-contract-v1.json')
contract['guard_only_parent_worker']=a_pin
contract['initial_storage_delta']=v2contract['source_delta']
contract['source_delta']=patch_pin
contract['preserved_negative_v2_Source_review']=pin(REVIEW/'handoff-v1.json')
contract['preserved_negative_v2_typed_review']=negative['typed_Source_review']
contract['contract_schema_unchanged']='independent-Q-lossless-cold-audit-worker-Source-contract-v1'
contract['guard_scope'].append('Before and after delegated executable snapshots, every actual parser/decoder/scanner/encoder Python function, class/MRO method and property accessor has exact original function_state identity/code/default-container/default-entry/kwdefault-entry/closure-cell+content anchors, plus original descriptor/effective direct or class-method binding. Direct original own validator checks precede delegation. Mixed callable/native defaults never rely on JSON None for authority.')
contract['lossless_storage']['parser_default_guard']='All storage/parser algorithms unchanged from v2. Only main gains explicit immutable per-Python-function anchors and two identical pre/post guard loops. Native scanner bindings remain raw-runtime identities guarded by inherited module snapshots; no new executable Source role.'
contract['remaining_requirements'][0]='Current distinct-author narrow guard Source review plus whole inherited v2 scope against new3 map; v2 negative remains preserved/unactivated'
cp=write('source-contract-v2.json',contract)
checks={
 'v2_source_raw_identity_preserved':True,'v2_contract_negative_peer_evidence_preserved':True,
 'AST_and_compile_syntax_only':True,'entire_raw_inverse_restores_v2':True,
 'all_twentyfour_non_main_definitions_AST_equal':True,'module_constants_imports_inputs_limits_AST_equal':True,
 'only_main_changed_no_new_API_or_helper':True,'one_anchor_construction_before_own_check_and_preflight':True,
 'all_Python_function_code_records_in_actual_four_parser_snapshots_anchored':True,
 'mixed_callable_defaults_are_identity_anchored_not_None_sealed':True,
 'function_state_original_object_code_default_kwdefault_closure_entries_unchanged':True,
 'descriptors_direct_functions_class_methods_property_accessors_effective_bindings_checked':True,
 'two_guard_loops_AST_identical':True,'original_own_validator_direct_prechecks_precede_new_delegation':True,
 'pre_and_post_loops_bracket_inherited_own_parser_executable_checks':True,
 'shared_parse_decode_cache_allocation_logic_unchanged':True,
 'unchanged_auditor_master_producer7_named11_full_domain_data_raw_pins':True,
 'leaf11_owner10_argv6_review_schema_scopes_caps_unchanged':True,
 'contract_schema_matches_ROOT_current_constructor':contract['schema']=='independent-Q-lossless-cold-audit-worker-Source-contract-v1',
 'no_unresolved_globals':not unknown,'no_parser_Source_project_test_semantic_or_mutation_calls':True,
 'no_actual_plans_or_activation_admission_fit_claim':True,
}
assert all(checks.values())
ep=write('author-static-evidence-v2.json',dict(schema='independent-Q-lossless-default-guard-author-static-evidence-v2',author_identity=AUTHOR,source_only=True,
 source_contract=cp,sources=contract['sources'],parent_worker=a_pin,parent_source_contract=pin(HERE/'source-contract-v1.json'),source_delta=patch_pin,
 preserved_negative_peer_handoff=pin(REVIEW/'handoff-v1.json'),preserved_negative_peer_findings=negative['findings'],
 all_author_static_checks_passed=True,checks=checks,unchanged_non_main_definitions=unchanged,
 literal_inverse_restores_v2=True,inverse_sha256=hashlib.sha256(inverse.encode()).hexdigest(),unresolved_globals=[],
 project_or_semantic_calls=0,parser_calls=0,tests_executed=0,actual_plans_emitted=0,
 mathematical_acceptance=False,resource_acceptance=False,resource_fit_claimed=False,
 scope='Author raw/AST evidence only; not peer review, executed default-mutation control, parser equivalence test or actual audit.'))
hp=write('handoff-v2.json',dict(schema='independent-Q-lossless-cold-worker-Source-handoff-v1',author_identity=AUTHOR,source_only=True,
 sources=contract['sources'],source_contract=cp,source_delta=patch_pin,author_static_evidence=ep,
 preserved_storage_v2_handoff=pin(HERE/'handoff-v1.json'),preserved_negative_v2_peer_handoff=pin(REVIEW/'handoff-v1.json'),
 preserved_actual_failure=contract['preserved_actual_failed_attempt'],unchanged_frozen_auditor=contract['sources']['independent_auditor'],
 changes='Main-only original function/default-entry/kwdefault-entry/closure anchors of actual Python parser/encoder hooks plus descriptor/effective binding checks before and after delegated snapshots; all24 non-main definitions and storage/math/input/cap/ABI values identical.',
 contract_schema='independent-Q-lossless-cold-audit-worker-Source-contract-v1',leaf_schema='ROOT-independent-complete-Q-audit-worker-plan-v1',
 expected_review=dict(schema='independent-Q-cold-audit-worker-Source-review-v1',scope='independent-Q-cold-audit-worker-Source',author_identity=AUTHOR,reviewer_identity='genuine distinct reviewer',sources=contract['sources'],source_only=True,scientific_calls=0,mathematical_acceptance=False),
 project_or_semantic_calls=0,parser_calls=0,tests_executed=0,actual_plans_emitted=0,
 limits=contract['resource_diagnosis']['unchanged_limits'],
 next_ROOT_recipe='Use the current ROOT constructor only after exact current peer/ROOT Source gates; request binds source-contract-v2.json with unchanged contract-v1 schema, new worker_v3 pin, genuine new worker review, unchanged auditor/named11/producer7/runtime/owner/closer and full closure. ROOT alone creates absent fresh plans/output and decides once-only activation. No actual plan is emitted here.',
 outcome='UNACTIVATED; no resource fit, mathematical admission, certificate, target proof/search, native/induction/fullPA/full24/trajectory/RL claim'))
print(json.dumps(dict(worker=b_pin,source_contract=cp,static_evidence=ep,patch=patch_pin,handoff=hp,checks=len(checks)),sort_keys=True))
