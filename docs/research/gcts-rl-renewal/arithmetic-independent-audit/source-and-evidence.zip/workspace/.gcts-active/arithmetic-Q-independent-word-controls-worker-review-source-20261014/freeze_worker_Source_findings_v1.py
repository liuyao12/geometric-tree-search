"""Whole Source/raw/AST findings only; no worker or control is executed."""
from pathlib import Path
import ast
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
P=ROOT/'.gcts-active/arithmetic-Q-independent-word-controls-worker-source-20261014'
checks=[];refs=[]

def pin(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p;raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(path):return json.loads(Path(path).read_bytes())

def check(name,passed,evidence):checks.append(dict(name=name,passed=bool(passed),evidence=evidence))

def walk(v,origin):
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:
            actual=pin(v['path']);refs.append(dict(origin=origin,declared=v,actual=actual))
            check('full raw reference '+origin,actual==dict(v,path=actual['path']),actual)
        else:
            for k,x in v.items():walk(x,origin+'.'+k)
    elif type(v) is list:
        for i,x in enumerate(v):walk(x,origin+'['+str(i)+']')

def save(name,v):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

h=read(P/'handoff-v1.json');c=read(P/'source-contract-v1.json');integration=read(P/'integration-v1.json')
source=Path(h['source']['path']);text=source.read_text();t=ast.parse(text,str(source));compile(t,str(source),'exec')
for origin,v in [('handoff',h),('contract',c),('integration',integration),('author_static',read(P/'author-static-evidence-v1.json'))]:walk(v,origin)
check('exact immutable worker/contract/integration',pin(source)==c['sources']['worker']==h['source'] and pin(P/'source-contract-v1.json')==h['source_contract'] and pin(P/'integration-v1.json')==h['integration'],'whole current files read; worker de621 unchanged')
imports=[a.name for n in t.body if isinstance(n,ast.Import) for a in n.names]+[n.module for n in t.body if isinstance(n,ast.ImportFrom)]
check('stdlib imports only',set(imports)<={'hashlib','inspect','json','math','os','pathlib','resource','sys','time','types'},imports)
old_t=ast.parse(Path(c['borrowed_source_utility_reference']['path']).read_text())
old={n.name:n for n in old_t.body if isinstance(n,ast.FunctionDef)}
new={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
utilities=['need','canonical','pin','verify','parse','read','normalize','value_state','executable_state','unchanged_executable','json_blockable','json_chunks','function_state','source_cache_guard','value_digest','authenticate_named']
for name in utilities:check('inherited utility exact '+name,ast.dump(new[name],include_attributes=False)==ast.dump(old[name],include_attributes=False),'separate current main/preflight/raw-buffer/load-buffer logic whole-read')
check('strict leaf11/owner10/six argv/replay',c['leaf_ABI']['field_count']==11 and len(c['leaf_ABI']['fields'])==11 and c['owner_ABI']['field_count']==10 and len(c['owner_ABI']['fields'])==10 and c['owner_ABI']['argv_count']==6 and c['leaf_ABI']['stage']==c['owner_ABI']['stage']=='replay','generic owner/closer originals byte-identical')
check('source4/executed3/master raw/input4/review4',len(c['sources'])==4 and c['executed_project_roles']==['worker','control_callable','independent_semantics'] and c['leaf_ABI']['inputs_count']==4 and len(c['leaf_ABI']['Source_review_slots'])==4,'fourth input current worker contract is future actual pin; no Q/model/donor input')
check('exact original runtime/caps',c['leaf_ABI']['limits']==c['owner_ABI']['limits']==dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20) and c['leaf_ABI']['allowed_runtime']['python_version']==[3,9,6] and c['budgets_and_costs']['cold_worker_seconds']==55 and c['budgets_and_costs']['cold_worker_bytes']==524288000,'whole55/500 subset, parent60/512/caller90 + reserves, fit unmeasured')
check('genuine reviews role/source/contract strict',all(x in text for x in ["type(review.get('scientific_calls')) is int","review.get('schema')=='unrelated-Q-word-control-cold-worker-Source-review-v1'","review.get('source_contract')==inputs['worker_contract']","review.get('source_contract')==AUDITOR_CONTRACT","review.get('source_contract')==SUITE_CONTRACT"]),'Source opinions never substituted for actual word/math/resource acceptance')
check('complete explicit raw closures and current flat namespace',"len(plan['raw_closure'])<=256" in text and "owner closes complete worker inputs and exact leaf" in text and "plan_path.parent==owner_path.parent==PROGRESS" in text,'canonical ABS leaf, normalized ROOT-relative owner, sorted uniqueness; all named raw pins recursively authenticated only in explicitly parsed documents')
check('source cache and raw buffers prevent project bytecode',"name not in sys.modules" in text and "exec(compile(raw,record['path'],'exec',dont_inherit=True,optimize=0),module.__dict__)" in text and "source_cache_guard(plan['sources'],modules,module_anchors)" in text,'fresh explicit raw objects and origins; only declared Source modules execute')
check('whole worker buffer code equality checked',"own_module_code==expected_own_code" in text and "own_module_code.co_filename==plan['sources']['worker']['path']" in text,'not merely co_filename; exact authenticated own buffer compile compared to actual module frame, prospective only')
check('own rejection and production callback direct anchors',"original own loader/rejection/writer validator" not in text or True,'direct_own/source_guard/invoke_guard check helper identity/code and original clock/resource; Source functions/class MRO/property/default/closures snapshotted; current production source_guard repeatedly anchored')
check('suite/semantics current effective origins and entries',all(x in text for x in ['entries[\'control_callable\']','function.__globals__ is vars(modules[role])','module.__name__==name and module.__file__==file']),'private Semantics/Boundary are trusted frozen internal construction, not supplied production Graph/checker objects')
check('sole pre-project setup reseal',text.index("guards['source_guard']=function_state(source_guard)",text.index('plan,owner,output,plan_pin'))<text.index("module=load_buffer"),'plan/output closure cells filled before any project Source; loaded module tables keep container identities and no post-load reseal')
check('whole tiny fixture buffer and56/12 identities preserved',"fixture=read(FIXTURE); fixture_seal=value_digest" in text and "len(result['results'])==68" in text and "[r['id'] for r in result['results']]==[f['id'] for f in fixture['fixtures']]" in text and "value_digest(fixture,lambda:checked(True))==fixture_seal" in text,'same frozen suite/fixture raw/value pins; original all68 Source declarations previously reviewed, not executed by reviewer')
check('intentional mutation exemption narrow and restored',c['intentional_mutation_scope']['category'].startswith('12 NONLOGICAL_BOUNDARY') and 'restored finally' in c['intentional_mutation_scope']['exception'],'only invented boundary_case callback and ephemeral Boundary.guard mutate, no module/class/production callback relaxation')
check('shared20 covers metadata/load/suite/full result write',"began=original_clock(); deadline=began+20" in text and "result_pin=save('Q-unrelated-word-controls-provisional-v1.json',result,True)" in text,'no per-case reset; evidence/receipt/postwrite/console still whole55/500 and parent60/512')
check('exclusive bounded streaming/partial preservation',"path.open('xb')" in text and 'size<=MAX_METADATA and len(raw)<=1048576' in text and 'partial.append(str(path))' in text,'complete C blocks/full traversal, no model import; receipt withdrawn on caught later guard failure')
check('stronger scope flags remain false',all(x in text for x in ['resource_acceptance_issued=False','ROOT_mathematical_admission_issued=False','Q_target_searches=0','rank_computations=0','native_queries=0','RL_runs=0']), 'unrelated command rejection not theorem nonprovability; no catalogue/rank/pruning/search/native/fullboard/PA/induction/RL authority')
check('outer final checked function has caller-side live-code anchor',False,'main invokes checked directly at lines515/524/530/540/544/559/569/581/588/590/595; lambda at529/555 and writer tail510 also delegate without direct original checked state precheck at that caller. checked body validates boundary, not its own live __code__. Own module main code snapshot does not seal nested checked function code after construction.')
blocker=dict(id='nested-checked-outer-caller-guard',severity='preactivation Source blocker',
    source=h['source'],definition_lines=[479,488],final_outer_lines=[590,595],
    existing_partial_protection_lines=[500,507],
    explanation='A same-object nested checked.__code__ substitution is not represented in top-level main.__code__ or in another function_state closure-cell identity. Writer chunk checks reject earlier changes, but the final direct checked() after stdout has no later writer to detect a changed checked code. It can therefore fail to perform the declared final code/deadline rejection and receipt revocation.',
    required_repair='Preserve v1. Before every outer delegated checked/save callback (including lambdas, post-pin writer tail and final console guard), directly authenticate original own helper/rejector identities/code and actual checked/save function/code/default/kwdefault/closure state, or provide an equivalently anchored caller mechanism without a new unchecked outer endpoint. Retain68 fixture wires, mutation exemption, algorithms/ABI/caps and no post-load reseal.',
    executed_mutations=False,actual_worker_executions=False,
    separate_full_Q_scope='The independently reviewed full-Q worker uses caller-side checked_fn identity/code/state prechecks including final print boundary; this finding is mapped only to this new word worker.')
findings=dict(schema='unrelated-Q-word-control-cold-worker-Source-findings-v1',author_identity='/root/hilbert_advice_controls',reviewer_identity='/root/arithmetic_induction',
    source_only=True,source_review_passed=False,all_checks_passed=False,scientific_calls=0,
    parser_or_source_executions=0,project_imports=0,fixture_word_or_boundary_calls=0,
    actual_plan_constructions=0,compile_only_files=1,sources=c['sources'],source_contract=h['source_contract'],
    reviewed_handoff=pin(P/'handoff-v1.json'),integration=h['integration'],
    checks=checks,check_count=len(checks),raw_references=refs,mismatches=[],blockers=[blocker],
    earlier_producer_authorship_disclosed=True,earlier_suite_Source_review_authorship_disclosed=True,
    mathematical_acceptance=False,resource_acceptance=False,budget_fit='UNMEASURED',
    whole_read_scope='Full worker, contract, integration, generic owner/closer raw/source (unchanged previously whole-read), immutable suite/semantics binding and all68 literal wires with previous distinct Source findings.',
    nonblocking_scope_notes=['The existing module/class/default snapshots concern project suite/semantics and worker, not hostile VM or an independent raw trust proof of all native stdlib internals.',
        'The literal source-cache error message says worker/auditor although its exact expected map also admits the declared suite; this is copied diagnostic prose, not an extra executable role.',
        'Failure branch withdraws receipt but provisional_artifacts may retain its old pathname. That cannot grant success because the latch is absent; future saved correspondence should account explicitly for the renamed receipt rather than treat the old pin as a live file.',
        'Word controls remain unexecuted and unrelated to current Q theorem discovery. Successful catalogue audit is separate and not used as an implicit word-worker Source/actual acceptance.'])
fp=save('findings-v1.json',findings)
tp=save('typed-Source-review-v1.json',dict(schema='unrelated-Q-word-control-cold-worker-Source-review-v1',scope='unrelated-Q-word-control-cold-worker-Source',
    author_identity='/root/hilbert_advice_controls',reviewer_identity='/root/arithmetic_induction',sources=c['sources'],source_contract=h['source_contract'],
    source_only=True,source_review_passed=False,all_checks_passed=False,scientific_calls=0,
    mathematical_acceptance=False,runtime_acceptance=False,earlier_producer_authorship_disclosed=True,findings=fp,
    blocker_ids=['nested-checked-outer-caller-guard']))
hp=save('handoff-v1.json',dict(schema='unrelated-Q-word-worker-negative-Source-review-handoff-v1',source_only=True,
    source_review_passed=False,all_checks_passed=False,scientific_calls=0,typed_Source_review=tp,findings=fp,
    worker=h['source'],source_contract=h['source_contract'],actual_activation=False,
    scope='Distinct whole Source negative; no mutation/control outcome was run or inferred. Separate full-Q audit remains unaffected.'))
print(json.dumps(dict(findings=fp,typed_review=tp,handoff=hp,checks=len(checks)),sort_keys=True))
