"""Unexecuted SOURCE: full-inventory rank candidates and literal m profiles.

This module neither mutates a graph nor grants pruning authority. A cold caller
must authenticate all executed raw buffers, the complete decoded inventory and
runtime, and its own guard before calling these APIs. A separate complete rank
auditor and literal/graph conformance are required before any marked search.
The preservation argument concerns completed strict-prior proof words; a partial
observer endpoint needs a separate equivalence argument.
"""
import hashlib
import json
import math
import time
import types

VERSION = "full-inventory-saturated-rank-literal-producer-v1"
INVENTORY_SCHEMA = "complete-formula-ordered-interface-rank-input-v1"
CERTIFICATE_SCHEMA = "unadmitted-complete-saturated-rank-candidate-v1"
PROFILE_SCHEMA = "unadmitted-literal-threshold-profile-candidate-v1"
Q_SCHEMA = "arithmetic-empty-Gamma-unary-generalize-finite-catalog-v1"
Q_MARKING = "injective-formula-ordered-primitive-offset-Q-v1"
CHANNEL_BASE = 4


class RankBudgetExceeded(TimeoutError):
    """No partial labels, interface receipts or literal profiles are returned."""

    def __init__(self, phase):
        super().__init__("complete rank/profile work unresolved: " + phase)
        self.diagnostic = {"completed": False, "phase": phase,
                           "partial_result_returned": False}


def require(ok, label):
    if not ok:
        raise ValueError(label)


def integer(value, label, minimum=None, maximum=None):
    require(type(value) is int, label + ": exact int, not bool")
    require(minimum is None or value >= minimum, label + ": below minimum")
    require(maximum is None or value <= maximum, label + ": above maximum")
    return value


def plain_json(value):
    """Reject user-defined containers, nonstring keys and nonfinite floats."""
    kind = type(value)
    if value is None or kind in (str, bool, int):
        return
    if kind is float:
        require(math.isfinite(value), "finite JSON float")
        return
    if kind is list:
        for child in value:
            plain_json(child)
        return
    require(kind is dict, "plain JSON containers only")
    for key, child in value.items():
        require(type(key) is str, "string JSON object key")
        plain_json(child)


def canonical(value):
    plain_json(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def same_json(left, right):
    """Type-sensitive data equality: assigned integer zero is not False."""
    return canonical(left) == canonical(right)


def sha_string(value, label):
    require(type(value) is str and len(value) == 64
            and all(c in "0123456789abcdef" for c in value), label)
    return value


def raw_pin(pin, label):
    require(type(pin) is dict and set(pin) == {"path", "sha256", "bytes"}, label)
    require(type(pin["path"]) is str and pin["path"].startswith("/")
            and "\x00" not in pin["path"], label + ": absolute raw path")
    sha_string(pin["sha256"], label + ": raw SHA256")
    integer(pin["bytes"], label + ": raw byte length", 0)
    # These are references, not authentication by pathname/hash claims. The
    # cold caller must one-read verify the buffers and close declared origins.


def function_anchor(function):
    require(type(function) is types.FunctionType, "Python source guard required")
    defaults = function.__defaults__
    kwdefaults = function.__kwdefaults__
    closure = function.__closure__ or ()
    return (function, function.__code__, defaults,
            tuple(id(v) for v in (defaults or ())), kwdefaults,
            tuple(sorted((k, id(v)) for k, v in (kwdefaults or {}).items())),
            tuple((cell, id(cell.cell_contents)) for cell in closure))


def unchanged_function(anchor):
    function, code, defaults, default_ids, kwdefaults, keyword_ids, closure = anchor
    require(type(function) is types.FunctionType and function.__code__ is code
            and function.__defaults__ is defaults
            and tuple(id(v) for v in (function.__defaults__ or ())) == default_ids
            and function.__kwdefaults__ is kwdefaults
            and tuple(sorted((k, id(v)) for k, v in
                             (function.__kwdefaults__ or {}).items())) == keyword_ids
            and len(function.__closure__ or ()) == len(closure)
            and all(a is b and id(b.cell_contents) == ident
                    for (a, ident), b in zip(closure, function.__closure__ or ())),
            "source guard function/code/default/closure binding changed")


class Boundary:
    """Deadline around delegated guards; final hash/record work is inside it."""

    __slots__ = ("deadline", "anchor", "started", "guard_calls", "_boundary_type",
                 "_helper_anchors", "_method_anchors", "_clock_endpoint", "_clock_type",
                 "_validator", "_sealed")

    def __setattr__(self, name, value):
        if getattr(self, "_sealed", False):
            raise ValueError("sealed original Boundary authority")
        object.__setattr__(self, name, value)

    def __init__(self, deadline, source_guard):
        require(type(deadline) in (int, float) and math.isfinite(deadline),
                "finite absolute perf_counter deadline")
        self._sealed = False
        self.deadline = deadline
        # Capture own validators and the native clock BEFORE any delegation.
        # These Python validators/methods have no defaults or closure in the
        # authenticated Source; direct tests below do not trust them to verify
        # their own identities/code. The caller still seals the whole module.
        self._boundary_type = type(self)
        self._helper_anchors = tuple((name, globals()[name], globals()[name].__code__)
            for name in ("require", "function_anchor", "unchanged_function"))
        self._method_anchors = tuple((name, self._boundary_type.__dict__[name],
                                     self._boundary_type.__dict__[name].__code__)
                                    for name in ("__setattr__", "__init__", "clock", "check"))
        self._clock_endpoint = time.perf_counter
        self._clock_type = type(self._clock_endpoint)
        self._validator = unchanged_function
        self.anchor = function_anchor(source_guard)
        self.started = self._clock_endpoint()
        self.guard_calls = 0
        self._sealed = True
        self.check("entry")

    def clock(self, phase):
        if time.perf_counter is not self._clock_endpoint or type(time.perf_counter) is not self._clock_type:
            raise ValueError("original perf_counter endpoint changed")
        if self._clock_endpoint() >= self.deadline:
            raise RankBudgetExceeded(phase)

    def check(self, phase):
        # Direct checks precede current helper, effective method and clock use.
        if Boundary is not self._boundary_type or type(self) is not self._boundary_type:
            raise ValueError("original Boundary class changed")
        for name, function, code in self._helper_anchors:
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError("original validator identity/code changed")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("original validator defaults/closure changed")
        for name, function, code in self._method_anchors:
            effective = getattr(self, name)
            if self._boundary_type.__dict__.get(name) is not function or function.__code__ is not code:
                raise ValueError("original Boundary method identity/code changed")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("original Boundary method defaults/closure changed")
            if type(effective) is not types.MethodType or effective.__self__ is not self or effective.__func__ is not function:
                raise ValueError("Boundary effective method shadow changed")
        self.clock(phase)
        self._validator(self.anchor)
        self.anchor[0]()
        object.__setattr__(self, "guard_calls", self.guard_calls + 1)
        # The callback cannot replace a validator/clock and authenticate itself.
        if Boundary is not self._boundary_type or type(self) is not self._boundary_type:
            raise ValueError("Boundary class changed during callback")
        for name, function, code in self._helper_anchors:
            if globals().get(name) is not function or function.__code__ is not code:
                raise ValueError("validator changed during callback")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("validator defaults/closure changed during callback")
        for name, function, code in self._method_anchors:
            effective = getattr(self, name)
            if self._boundary_type.__dict__.get(name) is not function or function.__code__ is not code:
                raise ValueError("Boundary method changed during callback")
            if function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None:
                raise ValueError("Boundary method defaults/closure changed during callback")
            if type(effective) is not types.MethodType or effective.__self__ is not self or effective.__func__ is not function:
                raise ValueError("Boundary method shadow changed during callback")
        if time.perf_counter is not self._clock_endpoint or type(time.perf_counter) is not self._clock_type:
            raise ValueError("perf_counter endpoint changed during callback")
        self._validator(self.anchor)
        self.clock(phase)


def owned_json(value, boundary, phase):
    """Private plain-data snapshot; never execute a supplied object hook."""
    boundary.check(phase + ":before")
    text = canonical(value)
    result = json.loads(text)
    boundary.check(phase + ":after")
    return result


def library_binding(binding):
    fields = {"epoch", "record_pin", "mode", "new_inference_edges",
              "primitive_inventory_sha256"}
    require(type(binding) is dict and set(binding) == fields, "exact library binding")
    sha_string(binding["epoch"], "library epoch")
    raw_pin(binding["record_pin"], "complete library/empty inventory record")
    require(binding["mode"] in ("empty", "advice-only-expanded-primitives")
            and binding["new_inference_edges"] is False,
            "new rules/contexts/body blocks require a new complete inventory adapter")
    sha_string(binding["primitive_inventory_sha256"], "primitive inventory binding")


def binding_fields(binding):
    fields = {"base_model_epoch", "raw_model_source", "model_locator",
              "full_model_canonical_sha256", "model_schema", "marking_version",
              "formula_registry_sha256", "ordered_interfaces_sha256",
              "context_occurrence_sha256", "source_bindings", "runtime_binding",
              "producer_source", "library_binding", "base_marking_channels"}
    require(type(binding) is dict and set(binding) == fields, "exact full model binding")
    for name in ("base_model_epoch", "full_model_canonical_sha256",
                 "formula_registry_sha256", "ordered_interfaces_sha256",
                 "context_occurrence_sha256"):
        sha_string(binding[name], name)
    raw_pin(binding["raw_model_source"], "original whole raw model/container source")
    raw_pin(binding["producer_source"], "executed producer Source reference")
    require(type(binding["model_locator"]) is list
            and all(type(x) is str and x for x in binding["model_locator"]),
            "explicit decoded model locator, empty for standalone model")
    require(type(binding["model_schema"]) is str and binding["model_schema"]
            and type(binding["marking_version"]) is str and binding["marking_version"],
            "original model/schema marking identity")
    sources = binding["source_bindings"]
    require(type(sources) is dict and sources, "complete original Source binding map")
    for role, pin in sources.items():
        require(type(role) is str and role, "source role")
        raw_pin(pin, "original source role: " + role)
    runtime = binding["runtime_binding"]
    require(type(runtime) is dict and set(runtime) ==
            {"executable", "observer", "platform", "posix_ext", "python_version", "resource_ext"},
            "whole current cold caller runtime record")
    for role in ("executable", "observer", "posix_ext", "resource_ext"):
        raw_pin(runtime[role], "runtime origin: " + role)
    require(type(runtime["platform"]) is str and runtime["platform"]
            and type(runtime["python_version"]) is str and runtime["python_version"],
            "declared runtime platform/version")
    channels = binding["base_marking_channels"]
    require(type(channels) is list and len(set(channels)) == len(channels),
            "all original marking channels, no duplicates")
    for channel in channels:
        integer(channel, "base channel", 0)
    library_binding(binding["library_binding"])


def validate_inventory(inventory, boundary):
    fields = {"schema", "height", "formula_table", "interfaces", "context", "binding"}
    require(type(inventory) is dict and set(inventory) == fields
            and inventory["schema"] == INVENTORY_SCHEMA, "exact complete inventory wire")
    height = integer(inventory["height"], "height", 1)
    formulas = inventory["formula_table"]
    require(type(formulas) is list and formulas, "whole injective formula table")
    codes = {}
    for code, formula in enumerate(formulas):
        boundary.clock("formula table validation")
        require(type(formula) is list and formula and type(formula[0]) is str,
                "formula AST, not a fabricated rank label")
        key = canonical(formula)
        require(key not in codes, "injective formula IDs")
        codes[key] = code
    context = inventory["context"]
    require(type(context) is dict and set(context) ==
            {"theory", "parameters", "side_conditions", "original_gamma",
             "original_occurrences"}, "complete theory/parameter/context wire")
    require(type(context["theory"]) is dict and type(context["side_conditions"]) is dict,
            "explicit theory and side conditions; semantic qualification is separate")
    parameters = context["parameters"]
    require(type(parameters) is list and all(type(v) is str and v for v in parameters)
            and len(set(parameters)) == len(parameters), "distinct literal parameters")
    gamma = context["original_gamma"]
    occurrences = context["original_occurrences"]
    require(type(gamma) is list and type(occurrences) is list
            and len(gamma) == len(occurrences), "all ordered original Gamma occurrences")
    for index, (formula, occurrence) in enumerate(zip(gamma, occurrences)):
        boundary.clock("context occurrence validation")
        require(type(occurrence) is dict and set(occurrence) ==
                {"occurrence_index", "formula_code", "formula"}, "exact occurrence record")
        require(integer(occurrence["occurrence_index"], "occurrence index", 0) == index,
                "original Gamma occurrence order")
        code = integer(occurrence["formula_code"], "Gamma formula code", 0, len(formulas) - 1)
        require(same_json(formulas[code], formula) and same_json(formula, occurrence["formula"]),
                "Gamma formula identity; repeated equal occurrences remain separate")
    interfaces = inventory["interfaces"]
    require(type(interfaces) is list, "whole ordered interface list")
    identities = set()
    for ordinal, interface in enumerate(interfaces):
        boundary.clock("complete interface validation")
        require(type(interface) is dict and set(interface) ==
                {"ordinal", "recipe_id", "output_code", "ordered_input_codes", "source_preimage"},
                "exact ordered interface record")
        require(integer(interface["ordinal"], "interface ordinal", 0) == ordinal,
                "all interface ordinals in unchanged order")
        name = interface["recipe_id"]
        require(type(name) is str and name and name not in identities, "unique recipe identity")
        identities.add(name)
        integer(interface["output_code"], "output code", 0, len(formulas) - 1)
        require(type(interface["ordered_input_codes"]) is list, "ordered port array")
        for code in interface["ordered_input_codes"]:
            integer(code, "input formula code", 0, len(formulas) - 1)
        require(type(interface["source_preimage"]) is dict, "whole primitive interface preimage")
    binding_fields(inventory["binding"])
    binding = inventory["binding"]
    require(digest(formulas) == binding["formula_registry_sha256"], "full formula binding")
    require(digest(interfaces) == binding["ordered_interfaces_sha256"], "full interface binding")
    require(digest(context) == binding["context_occurrence_sha256"], "full occurrence/context binding")
    require(binding["library_binding"]["primitive_inventory_sha256"] == digest(interfaces),
            "advice library cannot supply an unbound new inference edge")
    boundary.check("complete inventory validated")
    return height


def normalise_q_catalogue(model, *, raw_model_source, model_locator,
                         base_model_epoch, runtime_binding, producer_source,
                         library_record_pin, library_epoch, library_mode,
                         source_guard, deadline):
    """Future raw-schema adapter; retains every original formula and recipe.

    The model source may be a pinned container at locator ['catalogue']. This
    routine does not read files, licence rules, qualify Q, or reconstruct a graph.
    The caller must authenticate that whole container and exact extracted model.
    """
    boundary = Boundary(deadline, source_guard)
    model = owned_json(model, boundary, "complete Q model snapshot")
    require(model.get("schema") == Q_SCHEMA, "only the current raw Q catalogue schema")
    height = integer(model["height"], "Q height", 24, 24)
    declaration = model["declaration"]
    require(declaration["height"] == height and type(declaration["height"]) is int,
            "original declared height")
    gamma = declaration["ordered_Gamma"]
    require(same_json(model["context"], {"theory": declaration["theory"],
                                       "ordered_local_premises": gamma}), "unchanged original context")
    formulas = model["formula_codes"]
    require(type(formulas) is list, "whole original formula registry")
    codes = {canonical(formula): index for index, formula in enumerate(formulas)}
    require(len(codes) == len(formulas) and digest(formulas) == model["formula_registry_sha256"],
            "original injective formula registry")
    authority = model["authority"]
    require(digest({k: v for k, v in authority.items() if k != "epoch"}) == authority["epoch"]
            and authority["recipient_theory_sha256"] == digest(declaration["theory"])
            and authority["declaration_sha256"] == digest(declaration), "original authority preimage")
    interfaces = []
    require(type(model["recipes"]) is list, "whole original recipe array")
    for ordinal, recipe in enumerate(model["recipes"]):
        boundary.clock("Q complete recipe normalization")
        require(type(recipe) is dict and set(recipe) ==
                {"id", "primitive_witness", "ordered_premise_formulas", "identity_preimage"},
                "whole original primitive recipe")
        witness = recipe["primitive_witness"]
        inputs = recipe["ordered_premise_formulas"]
        require(type(witness) is dict and type(inputs) is list and len(inputs) <= 2,
                "current Q zero/unary/binary interface schema")
        preimage = {"recipe": {"primitive_witness": witness, "ordered_premise_formulas": inputs},
                    "primitive_authority_epoch": authority["epoch"],
                    "recipient_theory_sha256": authority["recipient_theory_sha256"],
                    "marking_version": Q_MARKING,
                    "formula_registry_sha256": model["formula_registry_sha256"],
                    "local_context_id": digest(model["context"])}
        require(same_json(recipe["identity_preimage"], preimage)
                and recipe["id"] == "primitive-recipe-" + digest(preimage), "exact original recipe preimage")
        try:
            output = codes[canonical(witness["formula"])]
            ports = [codes[canonical(formula)] for formula in inputs]
        except KeyError as error:
            raise ValueError("original interface formula outside complete registry") from error
        interfaces.append({"ordinal": ordinal, "recipe_id": recipe["id"], "output_code": output,
                           "ordered_input_codes": ports, "source_preimage": recipe})
    context = {"theory": declaration["theory"], "parameters": declaration["parameters"],
               "side_conditions": {"declaration": declaration,
                                   "authority": authority, "original_boundary": model["boundary"]},
               "original_gamma": gamma, "original_occurrences": []}
    for index, formula in enumerate(gamma):
        require(canonical(formula) in codes, "original Gamma inside complete registry")
        context["original_occurrences"].append({"occurrence_index": index,
            "formula_code": codes[canonical(formula)], "formula": formula})
    interface_sha = digest(interfaces)
    binding = {"base_model_epoch": base_model_epoch, "raw_model_source": raw_model_source,
        "model_locator": model_locator, "full_model_canonical_sha256": digest(model),
        "model_schema": model["schema"], "marking_version": Q_MARKING,
        "formula_registry_sha256": model["formula_registry_sha256"],
        "ordered_interfaces_sha256": interface_sha, "context_occurrence_sha256": digest(context),
        "source_bindings": authority["source_bindings"], "runtime_binding": runtime_binding,
        "producer_source": producer_source, "base_marking_channels": [1, 2, 3],
        "library_binding": {"epoch": library_epoch, "record_pin": library_record_pin,
            "mode": library_mode, "new_inference_edges": False,
            "primitive_inventory_sha256": interface_sha}}
    inventory = owned_json({"schema": INVENTORY_SCHEMA, "height": height, "formula_table": formulas,
        "interfaces": interfaces, "context": context, "binding": binding}, boundary, "normalized full wire")
    validate_inventory(inventory, boundary)
    canonical(inventory)
    boundary.check("normalization final buffer/record")
    return inventory


def inequality_receipts(inventory, labels, boundary):
    height = inventory["height"]
    require(type(labels) is list and len(labels) == len(inventory["formula_table"]),
            "complete label table, no missing/unresolved placeholders")
    for label in labels:
        integer(label, "saturated label", 0, height)
    roots = {"zero_port_interfaces": [], "original_gamma_occurrences": []}
    for occurrence in inventory["context"]["original_occurrences"]:
        code = occurrence["formula_code"]
        require(labels[code] == 0, "every original Gamma occurrence is rank zero")
        roots["original_gamma_occurrences"].append(dict(occurrence, rank=0))
    edges = []
    for interface in inventory["interfaces"]:
        boundary.clock("all interface inequality receipts")
        ports = interface["ordered_input_codes"]
        incoming = [labels[code] for code in ports]
        if ports:
            rhs = min(height, 1 + max(incoming))
        else:
            rhs = 0
            roots["zero_port_interfaces"].append({"ordinal": interface["ordinal"],
                "recipe_id": interface["recipe_id"], "output_code": interface["output_code"], "rank": 0})
        outgoing = labels[interface["output_code"]]
        require(outgoing <= rhs, "complete root/edge rank inequality")
        edges.append({"ordinal": interface["ordinal"], "recipe_id": interface["recipe_id"],
            "output_code": interface["output_code"], "ordered_input_codes": ports,
            "output_rank": outgoing, "ordered_input_ranks": incoming, "rhs": rhs, "passes": True})
    return roots, edges


def finish_candidate(record, boundary):
    """Hash/serialize the whole pending record, then a final deadline guard."""
    record["cost"] = {"inclusive_seconds_before_final_hash_and_guard":
                      time.perf_counter() - boundary.started,
                      "guard_calls_before_final_guard": boundary.guard_calls,
                      "cost_unit": "seconds, inclusive; no independently completed checker calls"}
    record["candidate_sha256"] = digest(record)
    canonical(record)
    boundary.check("final candidate hash/record boundary")
    return record


def produce_rank_certificate(inventory, *, source_guard, deadline):
    """Synchronous whole-inventory saturation; no target-root or backcone API."""
    boundary = Boundary(deadline, source_guard)
    inventory = owned_json(inventory, boundary, "rank input snapshot")
    height = validate_inventory(inventory, boundary)
    labels = [height] * len(inventory["formula_table"])
    root_codes = {o["formula_code"] for o in inventory["context"]["original_occurrences"]}
    root_codes.update(e["output_code"] for e in inventory["interfaces"]
                      if not e["ordered_input_codes"])
    for code in root_codes:
        labels[code] = 0
    settled = set(root_codes)
    rounds = [{"depth": 0, "new_formula_codes": sorted(root_codes), "witness_interfaces": []}]
    for depth in range(1, height):
        previous = frozenset(settled)
        witnesses = {}
        for interface in inventory["interfaces"]:
            boundary.clock("full synchronous saturation round")
            output = interface["output_code"]
            if output not in previous and all(code in previous for code in interface["ordered_input_codes"]):
                witnesses.setdefault(output, interface["ordinal"])
        newly = sorted(witnesses)
        for code in newly:
            labels[code] = depth
        settled.update(newly)
        rounds.append({"depth": depth, "new_formula_codes": newly,
                       "witness_interfaces": [[code, witnesses[code]] for code in newly]})
        boundary.check("complete synchronous round")
    roots, edges = inequality_receipts(inventory, labels, boundary)
    rank_epoch = digest({"inventory_sha256": digest(inventory), "height": height, "labels": labels,
                         "algorithm": VERSION, "roots": roots, "interfaces": edges})
    record = {"schema": CERTIFICATE_SCHEMA, "producer_version": VERSION,
        "completed": True, "inventory_sha256": digest(inventory), "binding": inventory["binding"],
        "rank_table_epoch": rank_epoch,
        "height": height, "formula_count": len(labels), "interface_count": len(edges),
        "labels": labels, "roots": roots, "complete_round_witnesses": rounds,
        "all_interface_inequalities": edges, "rank_H_meaning": "unreached before H, not logical nonprovability",
        "independent_rank_audit_accepted": False, "pruning_admitted": False,
        "partial_observer_equivalence_accepted": False, "proof_accepted": False,
        "graph_mutated": False, "partial_result_returned": False}
    return finish_candidate(record, boundary)


def candidate_integrity(candidate, schema):
    require(type(candidate) is dict and candidate.get("schema") == schema
            and candidate.get("completed") is True, "whole completed candidate of declared schema")
    expected = sha_string(candidate.get("candidate_sha256"), "whole candidate SHA256")
    require(digest({k: v for k, v in candidate.items() if k != "candidate_sha256"}) == expected,
            "whole candidate integrity, not mathematical or ROOT authority")
    require(candidate.get("pruning_admitted") is False
            and candidate.get("graph_mutated") is False, "unadmitted immutable producer product")


def validate_literal_profile(profile, boundary):
    """Whole emitter wire shape, including assigned zeros and absent rank zero.

    This is a producer-side consistency check, not the independent literal
    auditor. It does not reconstruct the full rank rounds or grant authority.
    """
    candidate_integrity(profile, PROFILE_SCHEMA)
    height = integer(profile["height"], "literal profile height", 1)
    require(type(profile["channel_base"]) is int and profile["channel_base"] == CHANNEL_BASE,
            "declared literal channel base")
    binding_fields(profile["binding"])
    sha_string(profile["inventory_sha256"], "profile full inventory identity")
    sha_string(profile["rank_candidate_sha256"], "profile whole rank candidate identity")
    channels = list(range(CHANNEL_BASE + 1, CHANNEL_BASE + height + 1))
    require(profile["reserved_channels"] == channels
            and all(type(channel) is int for channel in profile["reserved_channels"])
            and not set(channels).intersection(profile["binding"]["base_marking_channels"]),
            "all new channels reserved and disjoint")
    formulas = profile["formula_profiles"]
    require(type(formulas) is list and formulas, "all formula profiles including empty ones")
    for code, formula in enumerate(formulas):
        boundary.clock("whole literal formula profile validation")
        require(type(formula) is dict and set(formula) == {"formula_code", "marks_at_origin"}
                and integer(formula["formula_code"], "profile formula code", 0) == code,
                "complete original formula profile order")
        marks = formula["marks_at_origin"]
        require(type(marks) is list and len(marks) <= height, "bounded literal prefix profile")
        for k, item in enumerate(marks, 1):
            require(type(item) is list and len(item) == 3
                    and all(type(value) is int for value in item)
                    and item == [CHANNEL_BASE + k, 0, 1], "exact contiguous assigned-one profile")
    recipes = profile["recipe_profiles"]
    require(type(recipes) is list, "whole recipe profiles")
    ids = set()
    for ordinal, recipe in enumerate(recipes):
        boundary.clock("whole literal ordered recipe profile validation")
        require(type(recipe) is dict and set(recipe) ==
                {"ordinal", "recipe_id", "output_code", "output_marks_at_origin", "ordered_read_profiles"}
                and integer(recipe["ordinal"], "profile recipe ordinal", 0) == ordinal,
                "complete recipe profile order")
        name = recipe["recipe_id"]
        require(type(name) is str and name and name not in ids, "profile recipe identity")
        ids.add(name)
        output = integer(recipe["output_code"], "profile output code", 0, len(formulas) - 1)
        require(same_json(recipe["output_marks_at_origin"], formulas[output]["marks_at_origin"]),
                "output profile exactly the original formula profile")
        require(type(recipe["ordered_read_profiles"]) is list, "all ordered read profiles")
        for port, read in enumerate(recipe["ordered_read_profiles"]):
            require(type(read) is dict and set(read) ==
                    {"port_index", "formula_code", "relative_y", "marks_at_reference_origin"}
                    and integer(read["port_index"], "literal port index", 0) == port,
                    "ordered read port and multiplicity")
            code = integer(read["formula_code"], "literal input code", 0, len(formulas) - 1)
            require(read["relative_y"] == "reference_row - output_row"
                    and same_json(read["marks_at_reference_origin"], formulas[code]["marks_at_origin"]),
                    "read profile exactly the referenced formula profile")
    expected_fixed = []
    for row in range(height):
        boundary.clock("whole assigned-zero boundary validation")
        expected_fixed.extend([CHANNEL_BASE + k, row, 0] for k in range(row + 1, height + 1))
    require(profile["fixed_boundary_marks"] == expected_fixed
            and all(type(item) is list and all(type(value) is int for value in item)
                    for item in profile["fixed_boundary_marks"]), "complete literal assigned-zero boundary")
    require(profile["base_t_and_base_m_modified"] is False
            and profile["rank_zero_profile"] == "absent, never an assigned zero"
            and profile["transform"] == "vertical integer translation only; channels and values fixed",
            "base point data and translation semantics")
    sha_string(profile["rank_table_epoch"], "profile rank table epoch")
    require(profile["marking_epoch"] == digest({
        "inventory_sha256": profile["inventory_sha256"], "rank_table_epoch": profile["rank_table_epoch"],
        "channel_base": CHANNEL_BASE, "height": height, "formula_profiles": formulas,
        "recipe_profiles": recipes, "fixed_boundary_marks": expected_fixed,
        "transform": profile["transform"]}), "complete semantic threshold marking epoch")
    boundary.check("whole literal profile validated")
    return height


def compile_literal_threshold_profiles(inventory, certificate, *, source_guard, deadline):
    """Emit all formula/ordered-interface profiles and the complete fixed zeros."""
    boundary = Boundary(deadline, source_guard)
    inventory = owned_json(inventory, boundary, "literal inventory snapshot")
    certificate = owned_json(certificate, boundary, "whole rank candidate snapshot")
    height = validate_inventory(inventory, boundary)
    candidate_integrity(certificate, CERTIFICATE_SCHEMA)
    require(certificate["inventory_sha256"] == digest(inventory)
            and same_json(certificate["binding"], inventory["binding"])
            and integer(certificate["height"], "certificate height", 1) == height,
            "same complete context/model/library/Source rank binding")
    labels = certificate["labels"]
    roots, edges = inequality_receipts(inventory, labels, boundary)
    require(same_json(certificate["roots"], roots) and same_json(certificate["all_interface_inequalities"], edges)
            and integer(certificate["formula_count"], "certificate formula count", 1) == len(labels)
            and integer(certificate["interface_count"], "certificate interface count", 0) == len(edges),
            "complete exact root/interface receipts")
    require(certificate["rank_table_epoch"] == digest({"inventory_sha256": digest(inventory),
        "height": height, "labels": labels, "algorithm": VERSION, "roots": roots, "interfaces": edges}),
        "full rank table epoch; minimality still needs independent round reconstruction")
    channels = list(range(CHANNEL_BASE + 1, CHANNEL_BASE + height + 1))
    require(not set(channels).intersection(inventory["binding"]["base_marking_channels"]),
            "new m channels reserved independently of all original channels")
    formula_profiles = []
    for code, label in enumerate(labels):
        boundary.clock("all formula threshold profiles")
        formula_profiles.append({"formula_code": code,
            "marks_at_origin": [[CHANNEL_BASE + k, 0, 1] for k in range(1, label + 1)]})
    recipe_profiles = []
    for interface in inventory["interfaces"]:
        boundary.clock("all output and ordered read profiles")
        recipe_profiles.append({"ordinal": interface["ordinal"], "recipe_id": interface["recipe_id"],
            "output_code": interface["output_code"],
            "output_marks_at_origin": formula_profiles[interface["output_code"]]["marks_at_origin"],
            "ordered_read_profiles": [{"port_index": port, "formula_code": code,
                "relative_y": "reference_row - output_row",
                "marks_at_reference_origin": formula_profiles[code]["marks_at_origin"]}
                for port, code in enumerate(interface["ordered_input_codes"])]})
    fixed = []
    for row in range(height):
        boundary.clock("complete fixed threshold boundary")
        fixed.extend([CHANNEL_BASE + k, row, 0] for k in range(row + 1, height + 1))
    transform = "vertical integer translation only; channels and values fixed"
    marking_epoch = digest({"inventory_sha256": digest(inventory),
        "rank_table_epoch": certificate["rank_table_epoch"], "channel_base": CHANNEL_BASE, "height": height,
        "formula_profiles": formula_profiles, "recipe_profiles": recipe_profiles,
        "fixed_boundary_marks": fixed, "transform": transform})
    record = {"schema": PROFILE_SCHEMA, "producer_version": VERSION, "completed": True,
        "inventory_sha256": digest(inventory), "binding": inventory["binding"], "height": height,
        "rank_candidate_sha256": certificate["candidate_sha256"], "channel_base": CHANNEL_BASE,
        "rank_table_epoch": certificate["rank_table_epoch"], "marking_epoch": marking_epoch,
        "reserved_channels": channels, "formula_profiles": formula_profiles,
        "recipe_profiles": recipe_profiles, "fixed_boundary_marks": fixed,
        "transform": transform,
        "rank_zero_profile": "absent, never an assigned zero",
        "base_t_and_base_m_modified": False, "independent_literal_audit_accepted": False,
        "pruning_admitted": False, "partial_observer_equivalence_accepted": False,
        "proof_accepted": False, "graph_mutated": False, "partial_result_returned": False}
    return finish_candidate(record, boundary)


def placement_rank_marks(profile, *, recipe_ordinal, row, ordered_refs, source_guard, deadline):
    """Prospective literal point emitter, not a rank-row legality shortcut.

    It preserves port order and repeated references; equal point assignments
    within this placement are a function. Shared placement identity/refcounts
    across distinct selected placements belong to the future graph integration.
    """
    boundary = Boundary(deadline, source_guard)
    profile = owned_json(profile, boundary, "whole literal profile snapshot")
    height = validate_literal_profile(profile, boundary)
    row = integer(row, "output row", 0, height - 1)
    ordinal = integer(recipe_ordinal, "recipe ordinal", 0, len(profile["recipe_profiles"]) - 1)
    recipe = profile["recipe_profiles"][ordinal]
    require(type(recipe["ordinal"]) is int and recipe["ordinal"] == ordinal, "profile ordinal binding")
    require(type(ordered_refs) in (tuple, list) and len(ordered_refs) == len(recipe["ordered_read_profiles"]),
            "all ordered references, no port collapse")
    refs = [integer(ref, "strict-prior reference", 0, row - 1) for ref in ordered_refs]
    marks = {}

    def add(items, y):
        for item in items:
            boundary.clock("literal placement support")
            require(type(item) is list and len(item) == 3, "literal mark triple")
            x = integer(item[0], "reserved threshold channel", CHANNEL_BASE + 1, CHANNEL_BASE + height)
            require(type(item[1]) is int and item[1] == 0 and type(item[2]) is int and item[2] == 1,
                    "literal prototype threshold one, no zero/absence substitution")
            point = (x, y)
            require(point not in marks or marks[point] == 1, "equal marking union")
            marks[point] = 1

    add(recipe["output_marks_at_origin"], row)
    ports = []
    for index, (ref, read) in enumerate(zip(refs, recipe["ordered_read_profiles"])):
        require(type(read["port_index"]) is int and read["port_index"] == index
                and read["relative_y"] == "reference_row - output_row", "unchanged ordered read port")
        add(read["marks_at_reference_origin"], ref)
        ports.append({"port_index": index, "formula_code": read["formula_code"],
                      "reference_row": ref, "relative_y": ref - row})
    record = {"schema": "unadmitted-threshold-placement-point-data-v1", "completed": True,
        "profile_sha256": profile["candidate_sha256"], "inventory_sha256": profile["inventory_sha256"],
        "marking_epoch": profile["marking_epoch"],
        "binding": profile["binding"], "placement_identity": [recipe["recipe_id"], row, refs],
        "recipe_ordinal": ordinal, "ordered_port_bindings": ports,
        "m": [[x, y, value] for (x, y), value in sorted(marks.items())],
        "t_added": [], "base_t_and_base_m_modified": False,
        "current_or_fixed_union_checked": False, "legal_candidate_accepted": False,
        "pruning_admitted": False, "proof_accepted": False,
        "graph_mutated": False, "partial_result_returned": False}
    return finish_candidate(record, boundary)
