"""Literal JSON/hash/AST Source review only; no fixtures/checkers are invoked."""
from pathlib import Path
import ast
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACKET=ROOT/'.gcts-active/arithmetic-Q-independent-word-controls-source-20261014'
AUTHOR='/root/hilbert_advice_controls'
REVIEWER='/root/arithmetic_induction'
checks=[];refs=[]

def pin(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p
    h=hashlib.sha256();size=0;before=p.stat()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b);size+=len(b)
    after=p.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)

def read(path):return json.loads(Path(path).read_bytes())

def check(name,ok,evidence):
    checks.append(dict(name=name,passed=bool(ok),evidence=evidence))
    if not ok:raise AssertionError(name)

def walk(value,origin):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            actual=pin(value['path']);refs.append(dict(origin=origin,declared=value,actual=actual))
            check('exact whole raw reference '+origin,actual==dict(value,path=actual['path']),actual)
        else:
            for k,v in value.items():walk(v,origin+'.'+k)
    elif type(value) is list:
        for i,v in enumerate(value):walk(v,origin+'['+str(i)+']')

def save(name,value):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

handoff=read(PACKET/'handoff-v1.json');contract=read(PACKET/'source-contract-v1.json')
integration=read(PACKET/'integration-v1.json');author_static=read(PACKET/'author-static-evidence-v1.json')
source=Path(handoff['source']['path']);raw=source.read_bytes();text=raw.decode()
tree=ast.parse(text,str(source));compile(tree,str(source),'exec')
semantics=Path(contract['sources']['independent_semantics']['path'])
semantics_text=semantics.read_text();semantics_tree=ast.parse(semantics_text,str(semantics))
fixtures=read(PACKET/'complete-fixtures-v1.json')
fixture_value=json.dumps(fixtures,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
check('exact current callable Source',pin(source)==handoff['source']==contract['sources']['control_callable'],handoff['source'])
check('contract/integration/author evidence exact bindings',pin(PACKET/'source-contract-v1.json')==handoff['source_contract'] and pin(PACKET/'integration-v1.json')==handoff['integration'] and pin(PACKET/'author-static-evidence-v1.json')==handoff['author_static_evidence'],'whole files read, author checks are not independent runtime evidence')
for origin,value in [('handoff',handoff),('contract',contract),('integration',integration),('author_static',author_static)]:walk(value,origin)
constants={}
for n in tree.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
        try:constants[n.targets[0].id]=ast.literal_eval(n.value)
        except (ValueError,TypeError):pass
check('exact semantics/fixture raw and value pins',constants['SEMANTICS_SOURCE']==contract['sources']['independent_semantics']==pin(semantics) and constants['FIXTURE_SOURCE']==handoff['complete_fixtures']==pin(PACKET/'complete-fixtures-v1.json') and hashlib.sha256(fixture_value.encode()).hexdigest()==constants['FIXTURE_VALUE_SHA256']==contract['complete_fixture_value_sha256'],'fixture values merely hashed as JSON, not semantically evaluated')
imports=[a.name for n in tree.body if isinstance(n,ast.Import) for a in n.names]
check('stdlib-only callable imports',set(imports)=={'hashlib','json','math','time','types'},imports)
check('no loader/producer/graph/solver execution path',not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in {'exec','eval','compile','__import__'} for n in ast.walk(tree)) and 'PointGraph' not in text and 'reconstruct_grammar(' not in text,'future injected semantics must be raw-authenticated by separate reviewed cold caller')
records=fixtures['fixtures']
check('complete literal68 unique records and56/12 split',len(records)==68 and len({f['id'] for f in records})==68 and sum(f['api']=='check_primitive_word' for f in records)==56 and sum(f['api']=='Boundary' for f in records)==12 and contract['fixture_count']==68 and contract['word_fixture_count']==56 and contract['nonlogical_boundary_fixture_count']==12,'these are Source corpus counts, not measured checks')
check('whole literal corpus unexecuted scope',fixtures['source_only'] is True and fixtures['tests_executed']==0 and fixtures['scientific_calls']==0 and fixtures['no_Q_target_route'] is True and fixtures['no_donor_words'] is True,'unrelated manual controls, no search/discovered Q theorem')
literal_messages={n.value for n in ast.walk(semantics_tree) if isinstance(n,ast.Constant) and type(n.value) is str}
fixture_summary=[]
for index,f in enumerate(records):
    expected=f['expected'];wire=f['wire']
    check('complete declared fixture record '+f['id'],set(f)=={'api','category','description','expected','id','wire'} and set(expected)=={'status','exception','message_contains','consumed_original_occurrence_indices','essential_rows','ordered_prior_rows'},dict(index=index,id=f['id'],api=f['api'],expected=expected))
    if f['api']=='check_primitive_word':
        check('whole literal word wire '+f['id'],set(wire)=={'theory','parameters','original_Gamma','commands','target'} and type(wire['commands']) is list and type(wire['original_Gamma']) is list and type(wire['parameters']) is list,'all input ASTs remain declared raw data, including intentional malformed negatives')
        if expected['status']=='accept':
            check('positive whole-row expectation '+f['id'],len(expected['ordered_prior_rows'])==len(wire['commands']) and type(expected['essential_rows']) is list and type(expected['consumed_original_occurrence_indices']) is list and expected['exception'] is None,'full static expectation fields inspected against the separately reviewed primitive rule bodies; no check executed')
        else:
            check('negative declared mechanism exists '+f['id'],expected['exception']=='ValueError' and any(expected['message_contains'] in m for m in literal_messages),'specific original Source rejection label; trigger/result remains untested')
    else:
        check('Boundary explicitly NONLOGICAL '+f['id'],f['category']=='NONLOGICAL_BOUNDARY' and type(wire.get('operation')) is str,'synthetic callbacks/ephemeral Boundary only; not a theorem, graph or scheduling fixture')
    fixture_summary.append(dict(index=index,id=f['id'],category=f['category'],api=f['api'],expected_status=expected['status'],expected_exception=expected['exception'],declared_rule_sequence=[c.get('rule') for c in wire.get('commands',[])],actual_executions=0))

flow=[
('complete corpus mandatory',"sha(fixture_document) == FIXTURE_VALUE_SHA256" in text and 'for literal_fixture in fixtures["fixtures"]:' in text,'no ID subset, sampled prefix or lazy omitted suffix accepted'),
('actual injected module/entry API limited', 'type(module) is types.ModuleType' in text and 'checker.__globals__ is vars(semantics_module)' in text,'this does not authenticate raw origin; external cold caller must seal whole actual module and code'),
('own seven rejecting/helper endpoints direct anchored', 'for name, function, code in self._helpers:' in text and 'function.__defaults__ is not None or function.__kwdefaults__ is not None or function.__closure__ is not None' in text,'direct checks before validators/callback plus repeated checks after callback'),
('original real clock and shared absolute deadline', 'time.perf_counter is not self.clock' in text and 'self.clock() >= self.deadline' in text and 'deadline=deadline, maximum_visits=5000000' in text,'no fixture/phase reset; own timeout escapes full suite completion'),
('caller callback full function/default/closure authority', 'self.anchor = self._state_fn(source_guard)' in text and 'self._state_fn(self.guard) != self.anchor' in text,'before and after delegation; effective Gate/control methods themselves require future caller Source guard'),
('whole semantics module constants/class/MRO/property sealed', 'self.module_anchor = self._module_fn(module)' in text and 'for owner in value.__mro__:' in text and 'fn in (item.fget, item.fset, item.fdel)' in text,'ordinary Python module/class/method/default/closure/data observations; native origins and effective instances remain external guard scope'),
('per-fixture and original whole data nonmutation', 'canonical(fixture) == preimage' in text and 'canonical(fixture_document) == original_document_text' in text,'uses complete private JSON copies; no donated expected trace or producer function used'),
('positive records complete original occurrences/rows/ports', 'len(rows) == len(wire["commands"])' in text and 'consumed_original_occurrence_indices' in text and 'ordered_prior_rows' in text and 'record["commands_sha256"] == sha(wire["commands"])' in text,'literal corpus has exact expectation length; every current positive row, essential closure and consumed occurrence expectation inspected statically'),
('synthetic callback mutations restored in finally', 'finally:' in text and 'callback.__code__, callback.__defaults__, callback.__kwdefaults__ = original_code, original_defaults, original_kwdefaults' in text and 'cell.cell_contents = value' in text,'only invented callback/ephemeral Boundary mutates, never semantics class or actual theorem data'),
('exact expected negative message/class and no prefix', 'error_type == expected["exception"]' in text and 'need(result is None, "rejected control has no certificate/prefix")' in text,'unexpected TypeError/system errors/real deadline stop suite; no catch-all converted to accepted negative'),
('actual invocation tape and nested-cost labels honest', 'entry = {"call_index": len(call_tape)' in text and 'entry["seconds"] = time.perf_counter() - start' in text and 'actual_started_calls' in text,'future measured starts/returns/explicit exceptions only, no logical-count inference; inclusive nested durations not whole phase'),
('final hashes/serialization prep before final gate', 'record["result_value_sha256"] = sha(record)\n    canonical(record)\n    gate.check()\n    return record' in text,'no full-success result escapes a late final clock/guard; actual owner postwrite receipt still separate'),
('no stronger authority granted', all(x in text for x in ['"Q_target_proof_discovered": False','"catalogue_admitted": False','"pruning_admitted": False','"native_accepted": False','"ROOT_resource_accepted": False','"RL_runs": 0']),'no first-proof, catalogue, point-board, PA/induction, native, rank or RL acceptance'),
('prospective cap and loader gates unchanged',contract['prospective_original_envelope']['one_shared_inner_seconds']==20 and contract['prospective_original_envelope']['whole_owned_seconds']==60 and contract['prospective_original_envelope']['whole_owned_bytes']==536870912 and contract['prospective_original_envelope']['genuine_caller_seconds']==90,'Source callable only, no real cold worker/plan/admission and no fit guarantee')
]
for name,ok,evidence in flow:check(name,ok,evidence)
findings=dict(schema='unrelated-six-rule-word-boundary-controls-Source-findings-v1',author_identity=AUTHOR,reviewer_identity=REVIEWER,
    source_only=True,source_review_passed=True,all_checks_passed=True,scientific_calls=0,
    project_imports=0,fixture_executions=0,word_checker_calls=0,boundary_calls=0,
    actual_plan_constructions=0,mathematical_acceptance=False,resource_acceptance=False,
    sources=contract['sources'],inputs=contract['inputs'],source_contract=handoff['source_contract'],
    reviewed_handoff=pin(PACKET/'handoff-v1.json'),integration=handoff['integration'],
    compile_only_files=1,checks=checks,check_count=len(checks),raw_references=refs,
    complete_fixture_record_summary=fixture_summary,declared_corpus_counts=dict(total=68,words=56,nonlogical=12),
    disposition='conditional Source-ready; no concrete scoped blocker found',blockers=[],mismatches=[],
    earlier_Q_producer_authorship_disclosed=True,
    independence_scope='Reviewer authored earlier Q producer and reviewed the diagnosis-authored independent semantics. The controls callable/literal corpus author is distinct controls agent. Static expectation reasoning is not an independent actual semantic run or a target theorem discovery.',
    whole_read_scope=['Full callable, contract, integration, handoff, author static record, all68 literal wires/outcome declarations, relevant six-rule/Boundary Source bodies and previous independent semantics Source review.'],
    qualifications=['The declared positive/rejection outcomes are untested. Static reasoning found their current Source triggers and complete occurrence/ordered-row fields coherent; no semantic callable has been evaluated.',
        'These tests calibrate a sequent-relative generic six-rule checker on small unrelated predicates/constants; they neither reconstruct nor admit the Q grammar or prove the Q target.',
        'Capture-safe literal fresh naming, shadowing, full-unused Gamma freshness, duplicate occurrences, ordered MP and atomic equality scope are explicit. The named allP positive calibration already occurs as an axiom in that invented fixture; it is not proof search evidence.',
        'The12 Boundary cases are callback/clock/visit type controls only. They make no complete PointGraph/scheduler/rollback, first-proof endpoint or actual production-instance coverage claim.',
        'Gate seals ordinary code/default/closure/module/MRO/property states and caller callback. A separate cold worker must raw-authenticate exact buffers, reject pyc/local imports, seal the control module/Gate/effective endpoints/native runtime and caller shim before/after calls and publication.',
        'The fixtures have exact pinned positive expectation lengths. check_word_record relies on that full immutable corpus fingerprint; it is not a general arbitrary external expected-record parser.',
        'Canonical whole fixture copies and module/data snapshots are finite but actual20/60/512/caller90 cost is unmeasured. Partial failures/late clocks must remain UNKNOWN, never completed control acceptance.',
        'No current cold worker or actual owner plan is supplied by this Source packet; root-owned construction, independent cold review, actual once-only tests/resource closure and saved reconciliation remain open.'])
fp=save('findings-v1.json',findings)
tp=save('typed-Source-review-v1.json',dict(schema='unrelated-six-rule-word-boundary-controls-Source-review-v1',
    scope='complete-unrelated-six-rule-word-and-nonlogical-Boundary-controls-Source',
    author_identity=AUTHOR,reviewer_identity=REVIEWER,sources=contract['sources'],inputs=contract['inputs'],
    source_contract=handoff['source_contract'],source_only=True,source_review_passed=True,
    all_checks_passed=True,scientific_calls=0,mathematical_acceptance=False,resource_acceptance=False,
    fixtures_executed=0,actual_worker_available=False,earlier_Q_producer_authorship_disclosed=True,findings=fp))
hp=save('handoff-v1.json',dict(schema='unrelated-word-controls-review-handoff-v1',source_only=True,
    all_checks_passed=True,scientific_calls=0,reviewer_identity=REVIEWER,reviewed_author_identity=AUTHOR,
    typed_Source_review=tp,findings=fp,check_count=len(checks),blockers=[],mismatches=[],
    fixture_executions=0,word_checks=0,actual_activation=False,budget_fit='UNMEASURED',
    next='ROOT may author a reviewed cold worker and literal once-only stage; no actual fixture outcome, Q admission or resource acceptance follows from Source pass.'))
ip=save('integration-v1.json',dict(schema='private-Source-review-integration-v1',source_only=True,
    files=[pin(__file__),fp,tp,hp],scientific_calls=0,actual_fixture_results_created=False))
print(json.dumps(dict(findings=fp,typed_review=tp,handoff=hp,integration=ip,checks=len(checks),scientific_calls=0),sort_keys=True))
