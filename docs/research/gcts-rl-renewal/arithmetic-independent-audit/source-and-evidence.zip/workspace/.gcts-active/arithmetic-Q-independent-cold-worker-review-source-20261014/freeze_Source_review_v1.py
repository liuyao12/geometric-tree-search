"""Reviewer-owned raw/JSON/AST metadata only; no reviewed Source is executed."""
from pathlib import Path
import ast
import builtins
import hashlib
import json
import symtable

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = '/root/hilbert_ordering_diagnosis'
REVIEWER = '/root/arithmetic_induction'
PACKET = ROOT / '.gcts-active/arithmetic-Q-independent-cold-worker-source-20261014'
checks = []
references = []


def check(name, condition, evidence):
    checks.append(dict(name=name, passed=bool(condition), evidence=evidence))
    if not condition:
        raise AssertionError(name)


def pin(path):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    before = path.stat()
    h = hashlib.sha256()
    count = 0
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(65536), b''):
            h.update(raw)
            count += len(raw)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return dict(path=str(path), sha256=h.hexdigest(), bytes=count)


def read(path):
    return json.loads(Path(path).read_bytes())


def walk_pins(value, origin):
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            references.append(dict(origin=origin, declared=value, canonical=pin(value['path'])))
            record = references[-1]
            expected = dict(value, path=record['canonical']['path'])
            check('whole named raw pin ' + origin, record['canonical'] == expected,
                  record['canonical'])
            p = Path(record['canonical']['path'])
            check('current raw reference is canonical nonsymlink ' + origin,
                  str(p.resolve()) == str(p) and not p.is_symlink(), str(p))
        else:
            for key, child in value.items():
                walk_pins(child, origin + '.' + key)
    elif type(value) is list:
        for index, child in enumerate(value):
            walk_pins(child, origin + '[' + str(index) + ']')


def save(name, value):
    path = HERE / name
    with path.open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                                allow_nan=False) + '\n')
    return pin(path)


handoff = read(PACKET / 'handoff-v1.json')
contract = read(PACKET / 'source-contract-v1.json')
static = read(PACKET / 'author-static-evidence-v1.json')
source = Path(handoff['worker']['path'])
raw = source.read_bytes()
tree = ast.parse(raw.decode(), str(source))
compile(tree, str(source), 'exec')  # syntax only; the code object is never executed
auditor_source = Path(handoff['frozen_auditor']['path'])
auditor_raw = auditor_source.read_bytes()
auditor_tree = ast.parse(auditor_raw.decode(), str(auditor_source))
compile(auditor_tree, str(auditor_source), 'exec')
constants = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        try:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
        except (ValueError, TypeError):
            pass
sources = contract['sources']
check('exact immutable worker binding', pin(source) == handoff['worker'] == sources['worker'], handoff['worker'])
check('immutable auditor binding unchanged', pin(auditor_source) == constants['AUDITOR'] == sources['independent_auditor'], sources['independent_auditor'])
check('master binding and whole read', sources['master'] == constants['MASTER'] == pin(ROOT / 'docs/basic-tiling-algorithm.md'), sources['master'])
check('whole packet contract binding', pin(PACKET / 'source-contract-v1.json') == handoff['source_contract'], handoff['source_contract'])
check('whole author integration binding', pin(PACKET / 'author-static-evidence-v1.json') == handoff['author_static_evidence'], handoff['author_static_evidence'])
check('contract literal Source and named input maps', sources == handoff['sources'] and contract['named_inputs'] == constants['FROZEN_INPUTS'] and contract['raw_only_producer_sources'] == constants['PRODUCER_SOURCES'], 'Source3/input11/producer7 exact')
check('strict Source3 and execution2 roles', set(sources) == constants['SOURCE_ROLES'] == {'worker', 'independent_auditor', 'master'} and contract['executed_project_roles'] == ['worker', 'independent_auditor'], 'master and all producer roles are raw-only')
check('strict named input11', len(constants['FROZEN_INPUTS']) == 11, sorted(constants['FROZEN_INPUTS']))
walk_pins(handoff, 'handoff')
walk_pins(contract, 'contract')
walk_pins(static, 'author_static_evidence')

# Parse only small named metadata. Never decode preparation or state/domain files.
raw_only = {'producer_preparation', 'initial_state', 'initial_oracle_domains'}
documents = {role: read(record['path']) for role, record in contract['named_inputs'].items()
             if role not in raw_only}
owner_record = documents['producer_receipt']['owner_plan']
owner_path = Path(owner_record['path'])
if not owner_path.is_absolute():
    owner_path = ROOT / owner_path
documents['producer_owner_plan'] = read(owner_path)
for role, document in documents.items():
    walk_pins(document, role)
review = read(contract['genuine_existing_auditor_Source_review']['path'])
check('genuine prior distinct auditor Source review', review['source_review_passed'] is True and review['source_only'] is True and review['all_checks_passed'] is True and review['scientific_calls'] == 0 and review['author_identity'] == AUTHOR and review['reviewer_identity'] == REVIEWER and review['mathematical_acceptance'] is False, contract['genuine_existing_auditor_Source_review'])
check('prior auditor review exact two-role scope', review['sources'] == {'independent_auditor': sources['independent_auditor'], 'master': sources['master']} and review['source_contract'] == contract['named_inputs']['auditor_contract'], 'frozen semantic module review retained; worker is separately authored')
receipt = documents['producer_receipt']
decision = documents['producer_ROOT_final_decision']
seal = documents['producer_ROOT_reconciled_disposition']
evidence = documents['producer_evidence']
producer_plan = documents['producer_worker_plan']
limits = dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)
check('saved producer complete scoped receipt', receipt['stage_completed'] is True and receipt['all_direct_children_terminal_and_reaped'] is True and receipt['prepared'] == constants['FROZEN_INPUTS']['producer_preparation'] and receipt['evidence'] == constants['FROZEN_INPUTS']['producer_evidence'] and receipt['worker_plan'] == constants['FROZEN_INPUTS']['producer_worker_plan'], 'saved metadata only, no producer semantics replay')
check('saved producer ROOT14 resource gates', decision['ROOT_final_accepted'] is True and len(decision['predicates']) == 14 and all(v is True for v in decision['predicates'].values()), constants['FROZEN_INPUTS']['producer_ROOT_final_decision'])
check('saved producer stronger authority false', seal['catalogue_mathematically_admitted'] is False and seal['target_proofs_accepted'] is False and seal['native_accepted'] is False and seal['target_searches'] == 0 and seal['RL_training_runs'] == 0 and all(receipt[k] is False and evidence[k] is False for k in ['independent_mathematical_catalogue_admission', 'universal_theorem_discovered', 'scientific_search_activation']), 'accepted producer controls are not independent mathematical admission')
check('saved producer seven-role epoch and fixed limits', producer_plan['sources'] == constants['PRODUCER_SOURCES'] == evidence['sources'] and producer_plan['limits'] == limits == documents['producer_owner_plan']['limits'], 'whole unchanged current producer raw ledger')

definitions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
parent_path = Path(static['borrowed_source']['path'])
parent_tree = ast.parse(parent_path.read_text(), str(parent_path))
old = {n.name: n for n in parent_tree.body if isinstance(n, ast.FunctionDef)}
utilities = ['need', 'canonical', 'pin', 'verify', 'parse', 'read', 'load', 'normalize', 'value_state',
             'executable_state', 'unchanged_executable', 'json_blockable', 'json_chunks']
for name in utilities:
    check('inherited utility AST exact ' + name, ast.dump(definitions[name], include_attributes=False) == ast.dump(old[name], include_attributes=False), 'unchanged actual v7 producer utility, independently inspected here')
imports = [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
imports += [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
check('stdlib imports only', set(imports) <= {'hashlib', 'importlib.util', 'inspect', 'json', 'math', 'os', 'pathlib', 'resource', 'sys', 'time'}, imports)
loads = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'load']
check('sole raw auditor load', len(loads) == 1 and isinstance(loads[0].args[0], ast.Name) and loads[0].args[0].id == 'AUDITOR', dict(line=loads[0].lineno, project_loads=1))
reads = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'read']
preparation_reads = [n for n in reads if 'producer_preparation' in ast.dump(n)]
check('one preparation parse site', len(preparation_reads) == 1, dict(line=preparation_reads[0].lineno, actual_parse_runs_by_reviewer=0))
check('no saved observed catalogue counts as acceptance constants', b'11147' not in raw and b'16200' not in raw, 'counts must be independently reconstructed at future actual runtime')
names = {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
names |= {a.asname or a.name.split('.')[0] for n in tree.body if isinstance(n, ast.Import) for a in n.names}
names |= {a.asname or a.name for n in tree.body if isinstance(n, ast.ImportFrom) for a in n.names}
names |= {t.id for n in tree.body if isinstance(n, ast.Assign) for t in n.targets if isinstance(t, ast.Name)}
names |= {'__name__', '__file__', '__package__'}
unresolved = []
def symbols(table):
    for name in table.get_identifiers():
        item = table.lookup(name)
        if item.is_global() and item.is_referenced() and name not in names and name not in vars(builtins):
            unresolved.append([table.get_name(), name])
    for child in table.get_children():
        symbols(child)
symbols(symtable.symtable(raw.decode(), str(source), 'exec'))
check('no unresolved referenced global identifiers', unresolved == [], unresolved)

# These are Source flow checks, not executed mutation/semantic controls.
flow = [
('leaf11/owner10/argv6 exact contracts', contract['prospective_leaf_ABI']['field_count'] == 11 and len(contract['prospective_leaf_ABI']['fields']) == 11 and contract['owned_ABI']['field_count'] == 10 and len(contract['owned_ABI']['fields']) == 10 and contract['owned_ABI']['argv_count'] == 6, 'preflight lines268-339; exact fields, original3.9.6/darwin runtime, literal worker/receipt and reviewed flat owner'),
('explicit non-search ROOT activation and no arbitrary input', "plan['inputs']==FROZEN_INPUTS" in raw.decode() and "ROOT_owned_once_only=True" in raw.decode(), 'exact input11 and original literal Source ledgers; no success seed or theorem word'),
('canonical stable raw input pins and same authenticated decode buffer', all(x in raw.decode() for x in ["'whole stable raw bytes'", "'parse the authenticated same raw buffer'", "'duplicate JSON field'", "'nonfinite JSON '"]), 'pin/read/parse guard complete raw length/hash/stability and duplicate/nonfinite rejection'),
('complete named raw closure retained', all(x in raw.decode() for x in ['authenticate_named(document,closure)', "producer_plan['closure']+owner['closure']", "'every explicit original worker/owner raw closure retained'"]), 'walk only named metadata; no arbitrary ancestor JSON inflation'),
('raw same-buffer source execution without bytecode', "exec(compile(raw, record['path'], 'exec'), module.__dict__)" in raw.decode() and "'only worker/auditor local execution, no producer/cache import'" in raw.decode(), 'no loader.exec_module call, exact sys.modules objects; module cache gate excludes producer sources'),
('own direct reject predicates and clock/resource anchors', all(x in raw.decode() for x in ['original_clock=time.perf_counter; original_usage=resource.getrusage', "'original own loader/rejection/serialization validator changed'", 'own_check_anchor=function_state(own_check_fn)']), 'own function/code validators checked directly before delegated validators; module/default/constants snapshots then compare'),
('whole nested rejecting predicate anchored', 'whole_tick_anchor=function_state(whole_tick_fn)' in raw.decode() and "'whole rejecting callback code/default/closure changed'" in raw.decode(), 'tick checks whole predicate function/code/default/cell authority before invoking; own_check similarly anchored'),
('shared clock and limits callback anchored', 'tick_anchor=function_state(tick_fn)' in raw.decode() and 'deadline=inner_began+20' in raw.decode(), 'no later deadline reset; inner begins before metadata preflight; outer whole55/500 includes postlude inside unchanged owned60/512'),
('outer shim and Source callback anchored before delegation', all(x in raw.decode() for x in ['source_guard_anchor=function_state(source_guard_fn)', 'invoke_anchor=function_state(invoke_fn)', 'boundary_anchor=function_state(boundary_fn)', 'checked_anchor=function_state(checked_fn)', "'Source callback changed during delegation'"]), 'full function/code/default/kwdefault/closure-cell+contents identities at each outer entry'),
('whole auditor class/MRO/property code and actual entry sealed', 'module_states.append(executable_state(module))' in raw.decode() and 'entry=module.audit_saved_profile; entry_anchor=function_state(entry)' in raw.decode() and "entry.__globals__ is module.__dict__" in raw.decode(), 'internally constructed Semantics/Boundary are not caller-injected mutable graph endpoints; no actual instance fixture claimed'),
('sole prescribed setup reseal before first semantic call', raw.decode().count('source_guard_anchor=function_state(source_guard_fn)') == 2 and raw.decode().count('module=load(AUDITOR,') == 1, 'initial seal plus one reseal after exact module/entry setup; callback codes checked unchanged; no subsequent reseal'),
('complete semantic input value seals bracket call', "input_values={'declaration':documents['declaration'],'preparation':preparation," in raw.decode() and "need(value_digest(value,lambda:checked_fn(True))==seals[name]" in raw.decode(), 'exact three semantic values declaration/preparation/PRODUCER_SOURCES sealed; raw witness pin dictionaries separately authenticated and consumed read-only by frozen comparator'),
('unchanged independent all24 domains and whole witness EOF', all(x in auditor_raw.decode() for x in ["source.read(1) == b''", "size == record['bytes'] and h.hexdigest() == record['sha256']", 'for row in range(height):', "require_initial=True"]), 'current immutable auditor binding, no local proxy/row/census trim; mathematical logic already separately Source reviewed'),
('no late semantic prefix receipt', all(x in raw.decode() for x in ["'entire actual independent audit return, no prefix'", 'certificate_pin=save_fn(', "checked_fn(True)", "receipt_path.rename(withdrawn)"]), 'shared20 check after audit/input seals/certificate stream and final guard; error withdraws completed latch'),
('whole streamed writer and bounded retained outputs', "path.open('xb')" in raw.decode() and 'len(raw)<=4*1048576 and count<=MAX_METADATA' in raw.decode(), 'bounded C-subtrees and recursive full canonical traversal; exclusive files, full pin and records; partial streams retained'),
('postwrite receipts and final print guarded', all(x in raw.decode() for x in ['Q-independent-audit-postwrite-observation-v1.json', 'elapsed_seconds_after_receipt_write', 'worker_elapsed_after_writes_seconds', 'flush=True']), 'worker postwrite observations not enclosing acceptance; later evidence/receipt/postrecord/stdout charged to whole guard; ROOT owner/closer/caller close complete lifetime'),
('failure retention and false stronger scope flags', all(x in raw.decode() for x in ['accepted_prefix=False', 'ROOT_mathematical_admission_issued=False', 'resource_acceptance_issued=False', 'target_searches=0', 'native_queries=0', 'RL_updates=0']), 'no success latch from late prefix; late/nonzero/owner kill requires UNKNOWN; failure serialization itself remains actual outer lifecycle work'),
('generic owner/closer explicit immutable pins', contract['owned_ABI']['owner']['sha256'] == '2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656' and contract['owned_ABI']['closer']['sha256'] == '9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf', 'whole parent owner/closer read: same-PID wait4/reap/current birth identities; sampled+kernel accounting and2s/8MiB reserve, caller90+1 actual terminal separate'),
('Source-only package and unmeasured fit retained', handoff['actual_plans_or_activation'] is False and contract['actual_worker_activation'] is False and contract['source_only'] is True and handoff['budget_fit'] == 'UNMEASURED', 'no actual constructor/plan/activation/controls/semantics or independent formula-count reconstruction performed')
]
for name, passed, evidence_text in flow:
    check(name, passed, evidence_text)

findings = dict(
    schema='independent-Q-cold-audit-worker-whole-Source-findings-v1',
    author_identity=AUTHOR, reviewer_identity=REVIEWER,
    source_only=True, source_review_passed=True, all_checks_passed=True,
    scientific_calls=0, mathematical_acceptance=False, resource_acceptance=False,
    actual_audit_worker_runs=0, actual_auditor_callable_runs=0, actual_plan_constructions=0,
    actual_catalogue_or_domain_reconstructions=0, project_imports=0,
    compile_only_files=2, sources=sources, source_contract=handoff['source_contract'],
    handoff=pin(PACKET/'handoff-v1.json'), author_static_evidence=handoff['author_static_evidence'],
    prior_auditor_Source_review=contract['genuine_existing_auditor_Source_review'],
    earlier_producer_authorship_disclosed=True,
    independence_scope='Reviewer authored the earlier Q producer/kernel/catalogue/graph/payload/control Source. This is a distinct-author review of diagnosis-authored cold worker and immutable independent auditor; it is not an independent runtime semantic replay or a new review of the reviewer-authored producer.',
    disposition='conditional_Source_ready; no concrete scoped blocker found',
    blockers=[], mismatches=[], checks=checks, check_count=len(checks), raw_references=references,
    raw_reference_occurrences=len(references), distinct_raw_paths=len({r['canonical']['path'] for r in references}),
    inherited_utility_ASTs=utilities,
    complete_read_files=[pin(source),pin(auditor_source),handoff['source_contract'],pin(PACKET/'handoff-v1.json'),handoff['author_static_evidence'],pin(PACKET/'freeze_worker_Source_v1.py'),sources['master'],contract['owned_ABI']['owner'],contract['owned_ABI']['closer']],
    scope_qualifications=[
        'Static guards are ordinary Python endpoint/code/default/closure checks, not protection against arbitrary interpreter or trusted stdlib replacement.',
        'The immutable full-data seals cover declaration, complete parsed preparation and producer source-binding values. Other plan/metadata dictionaries and witness pins are raw-authenticated; the frozen comparator consumes witness records read-only. No claim that every local dictionary is immutable is made.',
        'Semantics and Boundary instances are auditor-private, not injected producer/graph objects. Class/MRO/property/method Source and callback authority are sealed; this review does not execute instance-mutation controls.',
        'One preparation parse still retains the complete parsed payload while independent interned grammar and factors are built. Canonical input sealing and scalar witness encoding may be expensive;20s/512MiB fit is unmeasured, and overrun yields UNKNOWN.',
        'Worker inner starts before metadata preflight/loading; Python startup/import and own initial snapshot remain in the owned whole lifecycle. The inner field precedes the last guard and is not an enclosing time or a separate additive cost.',
        'Output pins recorded inside serialization describe completed files. Final receipt/postwrite/stdout and cleanup are not fully covered by a worker pre-receipt sample; the unchanged generic owner, closer and genuine ROOT terminal/caller observation are mandatory.',
        'The existing producer all14 gates are saved resource/controls prerequisites only. Independent finite mathematical catalogue admission, arbitrary-word negative controls, first-proof/observer integration, native/full-board/trajectory/induction/full-PA/RL claims remain separate.'
    ],
    remaining_ROOT_gates=[
        'Genuine current ROOT Source review, exact worker-independent and auditor-independent raw reviews; canonical complete leaf/owner/runtime closure in absent flat namespace.',
        'ROOT-owned single bounded actual audit; no stale or reused receipt or prefix acceptance.',
        'Actual full witness EOF/census/code/input guards plus enclosing same-handle terminal/reaping, unchanged full closure and all14 resource/caller predicates.',
        'Independent saved correspondence and narrowly scoped ROOT mathematical admission before any proof/consumer/search integration.'
    ])
findings_pin = save('independent-Q-cold-worker-Source-findings-v1.json', findings)
typed = dict(schema='independent-Q-cold-audit-worker-Source-review-v1',
    scope='independent-Q-cold-audit-worker-Source', author_identity=AUTHOR, reviewer_identity=REVIEWER,
    sources=sources, source_contract=handoff['source_contract'], source_only=True,
    source_review_passed=True, all_checks_passed=True, scientific_calls=0,
    mathematical_acceptance=False, resource_acceptance=False, actual_worker_activation=False,
    earlier_producer_authorship_disclosed=True,
    independence_scope=findings['independence_scope'], findings=findings_pin,
    conditional_scope='Whole cold Source only; future actual20/60/512MiB/caller90 fit, complete audit and ROOT admission not inferred.')
typed_pin = save('independent-Q-cold-worker-typed-Source-review-v1.json', typed)
handoff_pin = save('handoff-v1.json', dict(
    schema='independent-Q-cold-worker-review-handoff-v1', source_only=True,
    source_review_passed=True, all_checks_passed=True, scientific_calls=0,
    author_identity=REVIEWER, reviewed_author_identity=AUTHOR,
    reviewed_worker=sources['worker'], source_contract=handoff['source_contract'],
    typed_Source_review=typed_pin, findings=findings_pin,
    check_count=len(checks), raw_reference_occurrences=len(references),
    distinct_raw_paths=findings['distinct_raw_paths'], mismatches=[], blockers=[],
    actual_worker_activation=False, mathematical_acceptance=False, resource_acceptance=False,
    earlier_producer_authorship_disclosed=True, budget_fit='UNMEASURED',
    next='ROOT alone may construct reviewed current metadata and activate once; actual full audit/owned/caller acceptance remains mandatory.'))
integration_pin = save('integration-v1.json', dict(
    schema='private-Source-review-integration-v1', source_only=True, files=[
        pin(__file__),findings_pin,typed_pin,handoff_pin],
    project_or_semantic_calls=0, actual_scientific_results_created=False))
print(json.dumps(dict(typed_review=typed_pin,findings=findings_pin,handoff=handoff_pin,
    integration=integration_pin,checks=len(checks),raw_references=len(references),
    distinct_paths=findings['distinct_raw_paths'],source_or_semantic_calls=0),sort_keys=True))
