"""Raw/JSON/AST/compile-only Source review. Never imports the auditor."""
import ast
import builtins
import hashlib
import json
from pathlib import Path
import symtable
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
AUTHOR=ROOT/'.gcts-active/arithmetic-Q-independent-mathematical-audit-source-20261014'

def pin(path):
    p=Path(path).resolve();h=hashlib.sha256();size=0
    with p.open('rb') as stream:
        for raw in iter(lambda:stream.read(65536),b''):h.update(raw);size+=len(raw)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)

def save(name,value):
    with (HERE/name).open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    return pin(HERE/name)

def refs(value):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:yield value
        for child in value.values():yield from refs(child)
    elif type(value) is list:
        for child in value:yield from refs(child)

def main():
    began=time.perf_counter();checks=[];raw_refs=[]
    def check(ok,label):
        checks.append(dict(name=label,passed=bool(ok)))
        if not ok:raise ValueError(label)
    handoff=json.loads((AUTHOR/'handoff-v1.json').read_text())
    contract=json.loads((AUTHOR/'source-contract-v1.json').read_text())
    design=json.loads((AUTHOR/'design-v1.json').read_text())
    prospective=json.loads((AUTHOR/'prospective-controls-v1.json').read_text())
    source_path=Path(handoff['source']['path']);source=source_path.read_text();tree=ast.parse(source)
    code=compile(source,str(source_path),'exec');code=None
    check(pin(source_path)==handoff['source']==contract['sources']['independent_auditor'],'current whole auditor bytes bound')
    check(handoff['source_contract']==pin(AUTHOR/'source-contract-v1.json'),'current whole Source contract raw binding')
    for doc in (handoff,contract,design,prospective):
        for record in refs(doc):
            check(pin(record['path'])==record,'complete raw named reference '+record['path']);raw_refs.append(record)
    # No actual preparation or catalogue JSON is decoded; all scientific input
    # references above are raw hashed leaves only.
    declarations={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign)
        and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in
        ('VERSION','PRODUCER_PROFILE','MARKING','DECLARATION_RAW_SHA256','DECLARATION_VALUE_SHA256','GRAMMAR','LIMITS','FROZEN_PRODUCER_BINDINGS','RULE_FIELDS')}
    declaration=json.loads((ROOT/'.gcts-active/arithmetic-open-generalize-implementation-source-20261014/Q-declaration-v1.json').read_text())
    declaration_digest=hashlib.sha256(json.dumps(declaration,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
    check(declarations['DECLARATION_RAW_SHA256']==handoff['actual_saved_input_pins']['declaration']['sha256']
        and declarations['DECLARATION_VALUE_SHA256']==declaration_digest,'raw/value exact declaration bindings; no grammar execution')
    check(declarations['GRAMMAR']==declaration['grammar'] and declarations['LIMITS']==declaration['limits'],
          'entire declared restricted grammar/ceilings literal exact')
    check(declarations['FROZEN_PRODUCER_BINDINGS']==contract['producer_provenance_raw_only'],
          'exact current seven raw-only producer roles')
    imports=set()
    for n in tree.body:
        if isinstance(n,ast.Import):imports.update(a.name.split('.')[0] for a in n.names)
        if isinstance(n,ast.ImportFrom):imports.add(n.module)
    check(imports=={'hashlib','itertools','json','math','pathlib','time','types'},'standalone imports only declared stdlib')
    check(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('exec','eval','compile','__import__') for n in ast.walk(tree)),
          'no project loader/evaluation/dynamic Source execution in module')
    symbols=symtable.symtable(source,str(source_path),'exec')
    defined={s.get_name() for s in symbols.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
    unknown=set()
    def symbol_check(table):
        for s in table.get_symbols():
            if s.is_referenced() and s.is_global() and s.get_name() not in defined and s.get_name() not in vars(builtins):unknown.add(s.get_name())
        for child in table.get_children():symbol_check(child)
    symbol_check(symbols);check(not unknown,'AST/symbol binding no unresolved globals '+repr(sorted(unknown)))
    classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
    definitions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
    check(set(declarations['RULE_FIELDS'])=={'axiom','assumption','instantiate','eq_subst','mp','generalize'},'exact six rules, no opaque/induction/reflexivity addition')
    check("type(value) is int" in source and "type(raw) is list" in source and "type(parameters) is list" in source,
          'raw integer versus Boolean, list versus internal tuple and symbol/parameter shape guards')
    check("len(value.encode('utf8')) <= 64" in source and 'depth > 64' in source and 'range(32)' in source,
          'disclosed literal symbol/depth/fresh ceilings')
    check('self.pool.setdefault(value, value)' in source and "return self.node(('fun'" in source,
          'interned immutable nominal ASTs; raw arrays are parsed, not treated as licence claims')
    check("self.free(node[2]) - {node[1]}" in source and "self.all_names(node[2]) | {node[1]}" in source,
          'free versus all binder names and nested shadowing distinguished')
    check('binder == variable or variable not in self.free(body)' in source and 'body = self.substitute(body, binder' in source,
          'capture-safe substitution stops bound occurrences and alpha-renames only conflicting literal binders')
    check("self.all_names(body) | self.term_names(replacement) | {variable, binder}" in source,
          'fresh spelling excludes all free/bound names/replacement variables before substitution')
    check("self.forbidden = frozenset().union(*(self.free(node) for node in self.gamma))" in source,
          'whole original Gamma, including unused/repeated occurrences, controls UG')
    check("0 <= index < len(prior)" in source and "variable not in self.forbidden" in source,
          'strict-prior genuine unary generalization without hidden premises')
    check("self.axioms.get(symbol(raw['name'])) == out" in source and 'self.gamma[index] == out' in source,
          'exact original closed axiom/indexed assumption conclusions')
    check("('imp', universal, self.substitute" in source and "template[0] in ('eq', 'pred')" in source,
          'UI and atomic equality substitution are zero-port implication licences, not their consequent')
    check("implication == ('imp', antecedent, out)" in source,'ordered MP requires exact prior antecedent/implication')
    check("set(raw) == {'rule', 'formula'} | RULE_FIELDS[rule]" in source,
          'whole primitive field sets; no unused native authority fields')
    check("expected_arity = 2 if rule == 'mp' else 1 if rule == 'generalize' else 0" in source,
          'complete zero/unary/ordered-binary recipe interface checking')
    check("if len(commands) > 20000" in source and "need(prior[-1] == goal" in source and "need(not k.free(goal)" in source,
          'arbitrary nonempty whole word under disclosed ceiling, exact closed final target')
    check("pending.extend(rows[row]['ordered_prior_rows'])" in source and "consumed.add(commands[row]['index'])" in source,
          'arbitrary-word strict ancestry and original occurrence consumption provenance')
    check("for _ in range(GRAMMAR['term_node_bound'])" in source and 'itertools.product(snapshot, repeat=arity)' in source,
          'independent complete bounded structural term closure, not producer layer function')
    check('operands.add(term)' in source and 'k.term_names(term) <= k.parameter_set' in source,
          'all parameter-scoped target/axiom subterms appended; target remains syntax only')
    check("universals = sorted((f for f in basis if f[0] == 'all'), key=canonical)" in source
        and "range(GRAMMAR['instantiation_rounds'])" in source,'two full simultaneous UI snapshots')
    check("used.update(k.all_names(formula))" in source and "while 'hole' + str(suffix) in used" in source,
          'unused literal hole chosen across full seed syntax, no target proof selection')
    check('itertools.product(contexts, values)' in source and 'itertools.product(values, repeat=2)' in source,
          'all hole/operand orientations and ordered substitution pairs')
    check("atoms = sorted((f for f in basis if f[0] == 'eq'), key=canonical)" in source
        and "implications = sorted((f for f in basis if f[0] == 'imp'), key=canonical)" in source,
          'all resulting atomic UG interfaces then all implication MP interfaces')
    check('return sorted(basis, key=canonical), sorted(raw_recipes), census' in source,
          'full canonical expected registry and recipe universe rather than count-only admission')
    check('for expected, raw in zip(formulas, saved_formulas)' in source and 'canonical(raw) == expected' in source,
          'every saved formula/code and raw recipe element compared in exact order')
    check('k.recipe(record[\'primitive_witness\'], record[\'ordered_premise_formulas\'])' in source,
          'separately check every reconstructed recipe with independent semantics')
    check("record['id'] == 'primitive-recipe-' + digest(preimage)" in source
        and 'canonical(catalogue[\'authority\']) == canonical(authority)' in source,
          'complete recipe/context/theory/source/marking preimages and authority epochs')
    check("canonical(catalogue['census']) == canonical(census)" in source,
          'derived census checked; no observed actual count is an acceptance constant')
    check('11147' not in source and '16200' not in source and '2670' not in source,'no favorable counts/observed-step indices in scientific implementation')
    check("'required': [[0, row] for row in range(24)]" in source and "range(-23, 0)" in source,
          'all24 required/root obligations, original target and exterior sentinels exactly bound')
    check("point not in assignments or assignments[point] == code" in source and "assignments[2 + port, row] = ref - row" in source,
          'literal unit support/ordered offsets/shared same-source point conflicts')
    check("if (1, ref) in marks and marks[1, ref] != code" in source
        and "if different:" in source and "count -= bin(left & right).count('1')" in source,
          'complete relation masks including assigned-zero, repeated compatible and unequal shared rows')
    check('for index, (out, inputs) in enumerate(primitives)' in source and 'for row in range(height)' in source,
          'every primitive and all24 domains independently re-enumerated in factors')
    check("values == sorted(set(values))" in source and "all(k[1] == row for k in values)" in source,
          'canonical complete branch-local exclusions and multiplicity')
    check("len(keys) == len(set(keys))" in source and "totals[row] <= 1" in source
        and "canonical(state['marks']) == canonical(expected_marks)" in source,
          'physical union unique constituents/support/marks/refcounts including explicit zero')
    check('recovered == sorted(keys)' in source and "generation == 1 + state['roots'][key[1]]" in source,
          'all selected generation metadata under exact root-zero/unit-output profile')
    check("if dead:" in source and "elif forced:" in source and "state['roots'][row], domain_counts[row], row" in source,
          'global dead then forced then root-generation count ties, not per-row shortcut')
    check("source.read(len(encoded)) == encoded" in source and "source.read(1) == b''" in source
        and "h.hexdigest() == record['sha256']" in source,'full owned witness bytes/SHA/length/EOF and stable file identity')
    check("parts, characters = [], 0" in source and 'characters >= 16384' in source,
          'witness serializer coalesces chunks; threshold is not falsely treated as universal single-token cap')
    check('callback_state is not self._callback_state' in source and 'need is not self._need' in source
        and 'time.perf_counter is not self._clock' in source,'direct local rejection/callback/clock identity+code anchors')
    check(source.count('canonical(result); b.check()')==4,'both whole APIs guard complete result preparation before return twice')
    check(contract['owned_ABI']['missing_executable_prerequisite'].startswith('A peer-reviewed narrow cold raw loader'),
          'cold worker/receipt not falsely implemented or ready')
    check(contract['owned_ABI']['clock_and_caps']['one_shared_inner_seconds']==20
        and contract['owned_ABI']['clock_and_caps']['whole_owned_bytes']==536870912,
          'shared inner/owned cap limits retained prospectively; no resource fit claimed')
    check(contract['actual_mathematical_acceptance'] is False and handoff['actual_activation'] is False,
          'Source authoring does not upgrade mathematical/runtime custody')
    checks_count=len(checks)
    findings=save('independent-Q-auditor-Source-findings-v1.json',dict(schema='independent-Q-auditor-whole-Source-findings-v1',
        author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',
        source_only=True,source_review_passed=True,all_checks_passed=True,mismatches=[],required_Source_repairs=[],
        scientific_calls=0,project_imports=0,project_function_calls=0,semantic_rule_or_word_calls=0,
        grammar_or_domain_reconstruction_runs=0,formula_counts_computed=False,actual_plans_generated=False,
        compiler_kernel_Graph_search_native_RL_calls=0,compile_only_files=1,actual_runtime_admission=False,
        mathematical_acceptance=False,budget_fit='UNMEASURED',sources=contract['sources'],
        source_contract=pin(AUTHOR/'source-contract-v1.json'),author_handoff=pin(AUTHOR/'handoff-v1.json'),
        checks=checks,checks_count=checks_count,raw_pin_occurrences=raw_refs,
        disclosure='Reviewer authored the earlier producer kernel/catalogue/graph/controls. This is a distinct-author Source review of the separately authored new auditor, not an actual independent semantic replay or proof of the Python implementation.',
        reasoning=[
            'The six primitives are sound relative to the explicitly supplied original theory/context and their declared parameter scope. UI/equality are implication licences; UG uses all original undischarged hypotheses and no hidden positive premise.',
            'The monotone node-bounded term construction reaches every allowed structural term; full parameter-scoped seed subterms, simultaneous UI rounds, both hole-template sides/all operand pairs, all atom UG and all implication MP stages match the declared finite language without producer invocation.',
            'Elementwise expected arrays, independent recipe semantics and full identity preimages prevent a headline count from substituting for completeness. Tuple internals normalize to exact JSON-array values and do not merge alpha-distinct formulas.',
            'Initial full factors represent every strict-prior key; masks preserve absent/assigned-zero semantics and remove unequal shared source assignments exactly. All row-domain fields and external sentinels are covered.',
            'The arbitrary-word checker checks every command, all strict references and the exact closed last conclusion, then records actual ancestry and original occurrence consumption; it does not create a word.',
            'Current point-state checking uses the fixed root-zero/unit-output model, not a generic tiling/growth/trajectory verifier. Initial acceptance is separate from logical proof/native/fullboard/current-union acceptance.'
        ],integration_requirements=[
            'Future ROOT cold worker must hash and parse the same stable bounded raw buffer once, authenticate all exact named raw metadata and producer resource closures, and execute only the new auditor/worker; producer roles stay raw-only.',
            'Loader/rejection/hash/callback/shim functions, module constants/classes/MRO and all exposed effective instance endpoints require their actual anchored guards before/after calls and publication. This Source review is not that missing worker.',
            'Guard full parsed input values before/after checking and receipt serialization; the callable returns raw input provenance by reference and assumes the explicitly documented immutable caller/input boundary.',
            'Arbitrary-word semantics are sequent-relative; Q proof integration must bind exact original theory/Gamma/parameters/target to current qualified context, rather than treating any supplied closed-axiom theory as the Q profile.',
            'Run preregistered unrelated negative/side-condition/word/EOF/mutation controls and complete actual audit within one unchanged inner/owned/caller envelope. No late prefix or partial count may be accepted.',
            'Retained preparation plus independent registry/recipe sets/caches and standard scalar iterencode may exceed time/memory; practical fit remains a separate measured gate with no rescue or hidden phase reset.',
            'No separate author integration manifest exists in this package; the exact Source-contract/handoff maps provide current raw integration binding. Future executable loader/actual plans remain absent and unreviewed.'
        ],scope_flags_preserved_false=['FOL_complete','full_PA_accepted','induction_accepted','universal_compiler_accepted','native_accepted',
            'full24_accepted','full_trajectory_accepted','target_proof_discovered','ROOT_admission_issued','ROOT_resource_accepted'],
        metadata_seconds_before_write=time.perf_counter()-began))
    typed=save('independent-Q-typed-Source-review-v1.json',dict(schema=contract['Source_review_ABI']['schema'],
        scope=contract['Source_review_ABI']['scope'],author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',
        source_only=True,all_checks_passed=True,source_review_passed=True,scientific_calls=0,mathematical_acceptance=False,
        source_contract=pin(AUTHOR/'source-contract-v1.json'),sources=contract['sources'],findings=findings,
        producer_authorship_disclosed='/root/arithmetic_induction',budget_fit='UNMEASURED',
        conditional='Source-only pass. Cold worker/owned receipt/negative controls/actual complete audit and integration must be qualified separately.'))
    integration=save('integration-v1.json',dict(schema='task-only-Source-review-integration-v1',source_only=True,scientific_calls=0,
        private_only=True,files=[pin(HERE/'freeze_independent_auditor_Source_review_v1.py'),findings,typed]))
    handoff_pin=save('handoff-v1.json',dict(schema='independent-Q-auditor-review-handoff-v1',source_only=True,scientific_calls=0,
        source_review_passed=True,all_checks_passed=True,mathematical_acceptance=False,review=typed,findings=findings,
        integration=integration,sources=contract['sources'],author_identity='/root/hilbert_ordering_diagnosis',
        reviewer_identity='/root/arithmetic_induction',actual_activation=False))
    print(json.dumps(dict(handoff=handoff_pin,typed_review=typed,findings=findings,checks=checks_count,
        raw_pin_occurrences=len(raw_refs),compile_only_files=1,scientific_calls=0,metadata_seconds=time.perf_counter()-began)))

if __name__=='__main__':main()
