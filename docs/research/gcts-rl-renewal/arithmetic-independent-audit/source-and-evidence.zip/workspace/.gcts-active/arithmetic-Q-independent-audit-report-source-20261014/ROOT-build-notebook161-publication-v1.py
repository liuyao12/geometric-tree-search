"""Saved-record presentation/package builder; no mathematical project imports."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
PUB = Path('/private/tmp/gcts-family-router-publish-20261010')
SOURCE = Path(__file__).resolve().parent
ROUTE = Path('docs/research/gcts-rl-renewal/arithmetic-independent-audit')
OUT = PUB / ROUTE


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    assert len(raw) < 2 * 1048576
    return json.loads(raw)


def pin(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            size += len(block)
            h.update(block)
    return dict(path=str(path), sha256=h.hexdigest(), bytes=size)


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    return pin(path)


def link(path, label, local_name):
    record = pin(path)
    shutil.copyfile(path, OUT / local_name)
    return dict(label=label, href=local_name, sha256=record['sha256'], bytes=record['bytes'], source_path=record['path'])


def collect(value, records):
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            path = Path(value['path'])
            if not path.is_absolute():
                path = ROOT / path
            actual = pin(path)
            assert actual['sha256'] == value['sha256'] and actual['bytes'] == value['bytes']
            records[actual['path']] = actual
        else:
            for child in value.values():
                collect(child, records)
    elif type(value) is list:
        for child in value:
            collect(child, records)


def main(successor_disposition_path):
    assert not OUT.exists() and not (ROOT / ROUTE).exists()
    OUT.mkdir()
    for src, dest in (('reader-v2.html', 'reader.html'), ('reader.css', 'reader.css'), ('viewer-v2.js', 'viewer-v2.js')):
        shutil.copyfile(SOURCE / src, OUT / dest)
    original = ROOT / '.gcts-active/arithmetic-Q-independent-audit-progress-20261014/ROOT-actual-independent-Q-audit-failure-disposition-v1.json'
    paths = [original, Path(successor_disposition_path).resolve()]
    attempts = []
    evidence = []
    closure = {}
    for index, path in enumerate(paths):
        d = read(path)
        assert d['author_identity'] == '/root' and d['actual_invocations'] == 1
        assert d['limits']['owned_peak_bytes'] == 536870912
        prefix = 'attempt-' + str(index + 1)
        raw_links = [link(path, 'Complete ROOT saved disposition', prefix + '-disposition.json')]
        decision_path = Path(d['resource_qualification']['path'])
        decision = read(decision_path)
        assert decision['schema'] == 'ROOT-fresh-catalog-stage-final-decision-v1' and len(decision['predicates']) == 14
        raw_links.append(link(decision_path, 'Complete resource decision and predicates', prefix + '-resource.json'))
        for role, label in (('actual_caller', 'Genuine caller tool observations'), ('owner_terminal', 'Owned terminal observation'),
                            ('owner_postwrite', 'Owned postwrite costs'), ('worker_stderr', 'Worker diagnostic traceback'),
                            ('worker_plan', 'Actual worker plan and complete raw closure'), ('owner_plan', 'Actual owner plan')):
            raw_links.append(link(Path(d[role]['path']), label, prefix + '-' + role + ('.txt' if role == 'worker_stderr' else '.json')))
        if d.get('worker_failure'):
            raw_links.append(link(Path(d['worker_failure']['path']), 'Complete worker failure record', prefix + '-failure.json'))
        for role, label in (('worker_receipt', 'Complete independent worker receipt'), ('worker_evidence', 'Complete independent audit evidence'),
                            ('worker_postwrite', 'Worker postwrite observation'), ('worker_Source_review', 'Distinct current worker Source review'),
                            ('metadata_Source_review', 'Metadata compatibility Source review'), ('saved_record_review', 'Independent saved-record review')):
            if d.get(role):
                raw_links.append(link(Path(d[role]['path']), label, prefix + '-' + role + '.json'))
        certificate = None
        if d.get('audit_certificate'):
            cert_path = Path(d['audit_certificate']['path'])
            certificate = read(cert_path)
            raw_links.append(link(cert_path, 'Complete provisional audit certificate', prefix + '-certificate.json'))
        assert index == 0 or type(d.get('phase_trace')) is list
        if index == 0:
            phase_trace = [
                dict(phase='raw_input', status_text='Completed for the preparation', evidence_note='Source-mapped traceback reached the following complete value-seal call; the preceding authenticated read returned.'),
                dict(phase='parse', status_text='Returned before rejection', evidence_note='This is a control-flow inference from the exact saved traceback and worker Source, not a timed parser milestone.'),
                dict(phase='input_seal', status_text='Rejected at the first value_digest tick', evidence_href=prefix+'-worker_stderr.txt'),
                *[dict(phase=p, status_text='Not reached') for p in ('auditor','domains','eof','certificate')]
            ]
        else:
            phase_trace = d['phase_trace']
        attempts.append(dict(id=prefix, label='Original parse' if index == 0 else 'Lossless shared syntax',
            chart_label='Original' if index == 0 else 'Shared syntax', status_text=d['scope'], disposition=d,
            resource_decision=decision, audit_certificate=certificate, phase_trace=phase_trace, raw_closure_links=raw_links))
        collect(d, closure)
        for role in ('worker_plan','owner_plan'):
            collect(read(d[role]['path']), closure)
        for file in path.parent.rglob('*'):
            if file.is_file() and not file.is_symlink() and '__pycache__' not in file.parts:
                record = pin(file)
                closure[record['path']] = record

    # Explicit task Source/review directories only; no general workspace scan.
    directories = [
        'arithmetic-Q-independent-cold-worker-source-20261014',
        'arithmetic-Q-independent-cold-worker-review-source-20261014',
        'arithmetic-Q-independent-cold-lossless-source-20261014',
        'arithmetic-Q-independent-mathematical-audit-source-20261014',
        'arithmetic-Q-independent-mathematical-audit-review-source-20261014',
        'arithmetic-Q-independent-audit-ROOT-source-20261014',
        'arithmetic-Q-independent-audit-failure-saved-review-20261014',
        'arithmetic-Q-independent-word-controls-source-20261014',
        'arithmetic-Q-independent-word-controls-review-source-20261014',
        'arithmetic-Q-independent-word-controls-worker-source-20261014',
        'arithmetic-Q-independent-word-controls-worker-review-source-20261014',
        'arithmetic-Q-rank-certificate-source-20261014',
        'arithmetic-Q-rank-certificate-review-source-20261014'
    ]
    # Root supplies frozen successor peer/constructor/saved-review paths from its disposition.
    for role in ('worker_Source_review','metadata_Source_review','saved_record_review'):
        if attempts[1]['disposition'].get(role):
            path = Path(attempts[1]['disposition'][role]['path'])
            directories.append(str(path.parent.relative_to(ROOT / '.gcts-active')))
    for dirname in directories:
        folder = ROOT / '.gcts-active' / dirname
        assert folder.is_dir()
        for file in folder.rglob('*'):
            if file.is_file() and not file.is_symlink() and '__pycache__' not in file.parts:
                record = pin(file)
                closure[record['path']] = record
    for name in ('handoff-v2.json', 'Source-manifest-v2.json', 'source-schema-v2.json', 'ROOT-build-notebook161-publication-v1.py'):
        file = SOURCE / name
        closure[str(file.resolve())] = pin(file)
    scopes = [
        dict(id='independent_audit', status_text=attempts[1]['disposition']['scope'],
             scope_text='A completed finite audit and resource admission are prerequisites for the next proof search. An incomplete attempt supplies no accepted prefix.', evidence_href='attempt-2-disposition.json'),
        dict(id='calibration', status_text='Notebook 160 retains the completed producer calibration.',
             scope_text='All producer controls and resource qualification are distinct from independent mathematical admission or discovery of the arithmetic target.', evidence_href='../arithmetic-open-controls/reader.html#attempts'),
        dict(id='word_controls', status_text='Sixty-eight fixture declarations have Source review. The proposed runner was rejected for a final nested-guard gap and remains unexecuted.',
             scope_text='Fifty-six primitive words and twelve explicit nonlogical boundary controls use unrelated tiny theories. Authored fixtures are not discovered theorems; the runner needs a separate repair and review.'),
        dict(id='rank_proposal', status_text='The repaired rank-marking Source has conditional review; no ranks or pruning have been activated.',
             scope_text='The initial guard flaw is retained. Full finite rank certification, point-channel integration, rollback and equal-cost comparison remain necessary.')
    ]
    packet = dict(schema='Notebook161-saved-arithmetic-audit-display-packet-v1', presentation_only=True,
        lead='Parallel Source work produces a lossless storage successor, independent reviews and unrelated logical controls. This notebook records the actual independent audit attempts.',
        status_text=attempts[1]['disposition']['scope'], formula_latex=r'\forall n\,\bigl(n+S(0)=S(n)\bigr)',
        attempts=attempts, scopes=scopes, evidence_links=[])
    archive_path = OUT / 'source-and-evidence.zip'
    archived, external = [], []
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name in sorted(closure):
            record = closure[name]
            file = Path(name)
            assert pin(file) == record
            if ROOT not in file.parents:
                external.append(record)
                continue
            arcname = 'workspace/' + str(file.relative_to(ROOT))
            archive.write(file, arcname)
            archived.append(dict(record, archive_path=arcname))
        archive.writestr('README.txt', 'Notebook 161 task-owned saved evidence. Mathematical Source, actual plans, all raw closure members inside the workspace, reviews and failed attempts are retained. Exact host runtime paths/SHA/lengths are references in the archive manifest; binaries are not redistributed. No target proof or RL benefit is asserted.\n')
    manifest = write(OUT/'archive-manifest.json', dict(schema='Notebook161-task-archive-manifest-v1', archived=archived, external_runtime_references=external, archive=pin(archive_path)))
    packet['evidence_links'] = [dict(label='Complete task Source and saved raw closure ZIP', href='source-and-evidence.zip', **{k:v for k,v in pin(archive_path).items() if k!='path'}),
                                dict(label='Exact archive member manifest', href='archive-manifest.json', sha256=manifest['sha256'], bytes=manifest['bytes'])]
    write(OUT/'display-packet-v1.json', packet)
    html_path = OUT/'reader.html'
    html = html_path.read_text()
    html = html.replace('<p id="statement" hidden></p>', '<p class="small">Arithmetic target under investigation; this audit does not establish its proof.</p><p id="statement" hidden></p>')
    html = html.replace('<footer>Pending Source scaffold. ROOT owns actual result attachment, saved correspondence, browser verification and publication.</footer>',
        '<section id="parallel"><h2>Parallel responsibilities</h2><p>Three agents prepare independent checking, arithmetic integration and unrelated controls. The coordinator owns actual invocation, costs, final reconciliation and publication. Authors do not issue acceptance for their own artifacts.</p><p><a href="../index.html#parallel-research">Return to the research program</a></p></section><footer>Saved-record presentation. Search for the target, native checking, induction and learned cluster evaluation remain separate research steps.</footer>')
    html_path.write_text(html)
    js_path = OUT/'viewer-v2.js'
    js = js_path.read_text()
    marker = '      const render = async () => {'
    assert js.count(marker) == 1
    js_path.write_text(js.replace(marker, '      select.value = String(data.attempts.length - 1);\n'+marker, 1).replace('"Certificate publication"', '"Saved audit certificate"'))
    css_path = OUT/'reader.css'
    css_path.write_text(css_path.read_text().replace('min-width:320px;height:auto', 'min-width:640px;height:auto'))
    shutil.copytree(OUT, ROOT/ROUTE)
    files = [str(p.relative_to(PUB)) for p in sorted(OUT.rglob('*')) if p.is_file()]
    metadata = dict(schema='ROOT-Notebook161-publication-preparation-v1', presentation_only=True, publication=False,
                    archive_members=len(archived)+1, external_runtime_references=len(external), files=files,
                    input_dispositions=[pin(p) for p in paths], output_packet=pin(OUT/'display-packet-v1.json'))
    print(json.dumps(metadata))


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])
