"""ROOT pure stdlib named metadata construction; no project or science imports."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'
GENERIC=ROOT/'.gcts-active/equality-receptor-family-controls-progress-v2-20261014'

def pin(p,relative=False):
    p=Path(p);p=p if p.is_absolute() else ROOT/p
    assert p==p.resolve() and p.is_file() and not p.is_symlink()
    before=p.stat();raw=p.read_bytes();after=p.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
    name=str(p.relative_to(ROOT)) if relative and ROOT in p.parents else str(p)
    return dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(p):return json.loads(Path(p).read_bytes())
def write(p,value):
    with p.open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
    return pin(p)
def collect(closure,value):
    if type(value) is dict:
        if set(value)=={'path','sha256','bytes'}:
            actual=pin(value['path']);assert actual['sha256']==value['sha256'] and actual['bytes']==value['bytes']
            assert actual['path'] not in closure or closure[actual['path']]==actual
            closure[actual['path']]=actual
        else:
            for v in value.values():collect(closure,v)
    elif type(value) is list:
        for v in value:collect(closure,v)

def main(peer_path,contract_path):
    peer_path=Path(peer_path).resolve();contract_path=Path(contract_path).resolve();peer=read(peer_path);contract=read(contract_path)
    sources=contract['sources'];inputs=contract['inputs'];limits=contract['limits'];runtime0=contract['runtime']
    assert peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
    assert peer['author_identity']=='/root/arithmetic_induction' and peer['reviewer_identity']!='/root/arithmetic_induction'
    assert peer['sources']==sources and not DEST.exists()
    runtime=dict(binary=runtime0['executable'],resource_extension=runtime0['resource_ext'],python_version=[3,9,6],platform='darwin')
    closure={}
    # Only these explicit metadata read sites are decoded. Descendant pin values
    # are raw leaves, never recursively interpreted as additional authority.
    named=[(contract_path,contract),(peer_path,peer)]
    named += [(Path(p['path']),read(p['path'])) for p in inputs.values()]
    for p,value in named:collect(closure,[pin(p),value])
    collect(closure,[sources,inputs,runtime,runtime0,pin(__file__)])
    DEST.mkdir()
    for name in ('run_owned_bridge_v2.py','close_stage_decision_v1.py'):shutil.copyfile(GENERIC/name,DEST/name)
    owner_source=pin(DEST/'run_owned_bridge_v2.py');closer_source=pin(DEST/'close_stage_decision_v1.py')
    review=dict(schema='ROOT-Q-streamed-controls-current-source-review-v1',author_identity='/root/arithmetic_induction',reviewer_identity='/root',source_only=True,source_review_passed=True,scientific_calls=0,scientific_acceptance=False,sources=sources,inputs=inputs,independent_review=pin(peer_path),owner=owner_source,closer=closer_source,runtime=runtime0,scope='Q-complete-preparation-and-finite-controls-no-search-no-admission',whole_current_worker_and_controls_read=True,checks=['Exact empty original Gamma and unchanged right-one declaration/grammar.', 'Cold five-module raw buffers, callback/shim/effective method guards, bounded complete streaming and complete canonical raw closure.', 'Full-context generalization includes unused/duplicate free-variable hypotheses; capture-safe substitution controls.', 'Independent algorithm reconstructs every initial24 parametric domain one row at a time; full production and oracle witnesses are raw-pinned, true unary footprint preserved, and canonical-step rollback compares complete streamed bytes.', 'Dead/forced/generation/zero/sole-key-exclusion fixtures are specialized and nonlogical.', 'Shared20s imports/preparation/control/final guards and complete60s owned/90s caller/512MiB closure; provisional/withdrawn files earn no partial acceptance.'],scope_limits=['Source-only distinct-review admission to actual finite controls.', 'No target proof word, theorem search, induction, full PA, native query, RL or mathematical catalogue admission.'])
    review_pin=write(DEST/'ROOT-source-review-v1.json',review)
    collect(closure,[review,review_pin,owner_source,closer_source])
    worker_path=DEST/'worker-plan-v1.json';owner_path=DEST/'preparation-plan-v1.json';output=DEST/'worker-output-v1'
    leaf=dict(schema='ROOT-Q-open-empty-Gamma-controls-worker-plan-v1',ROOT_owned_once_only=True,scope=review['scope'],sources=sources,inputs=inputs,runtime=runtime,reviews=dict(ROOT=review_pin,independent=pin(peer_path)),closure=[closure[k] for k in sorted(closure)],limits=limits,owner_plan_path=str(owner_path),output_directory=str(output))
    assert len(leaf)==11
    leaf_pin=write(worker_path,leaf);collect(closure,leaf_pin)
    def lexical(record):return pin(record['path'],relative=True)
    argv=[runtime['binary']['path'],'-B',sources['worker']['path'],'ROOT-Q-open-empty-Gamma-preparation-controls',str(worker_path),str(owner_path)]
    owner=dict(schema='ROOT-guard-native-owned-plan-v1',stage='preparation',runtime_binary=lexical(runtime['binary']),worker=str(Path(sources['worker']['path']).relative_to(ROOT)),argv=argv,worker_receipt=str((output/'Q-controls-result-v1.json').relative_to(ROOT)),limits=limits,closure=[lexical(closure[k]) for k in sorted(closure)],ROOT_source_review=lexical(review_pin),scope=review['scope'])
    assert len(owner)==10 and len(argv)==6
    owner_pin=write(owner_path,owner)
    for record in closure.values():assert pin(record['path'])==record
    result=dict(schema='ROOT-Q-streamed-controls-metadata-construction-v1',source_only_metadata_execution=True,project_imports=0,scientific_calls=0,source_inventory=sources,worker_plan=leaf_pin,owner_plan=owner_pin,peer_review=pin(peer_path),owner_source=owner_source,closer_source=closer_source,named_metadata_roots=[pin(p) for p,v in named],raw_closure_count=len(closure),literal_owner_command=[runtime['binary']['path'],'-B',owner_source['path'],owner_pin['path']],actual_execution_accepted=False,mathematical_catalogue_admitted=False,target_proof_accepted=False)
    print(json.dumps(write(DEST/'ROOT-construction-v1.json',result)),flush=True)

if __name__=='__main__':
    assert len(sys.argv)==3
    main(sys.argv[1],sys.argv[2])
