"""Saved raw metadata only. No project/source/semantic callable is executed."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/arithmetic-Q-independent-audit-progress-20261014'
checks=[]
raw_refs=[]

def pin(path):
    path=Path(path)
    if not path.is_absolute():path=ROOT/path
    h=hashlib.sha256();size=0;before=path.stat()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b);size+=len(b)
    after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    return dict(path=str(path),sha256=h.hexdigest(),bytes=size)

def read(path):return json.loads(Path(path).read_bytes())

def check(name,ok,evidence):
    checks.append(dict(name=name,passed=bool(ok),evidence=evidence))
    if not ok:raise AssertionError(name)

def verify(record,origin):
    actual=pin(record['path'])
    check('whole raw bytes '+origin,actual==dict(record,path=actual['path']),actual)
    raw_refs.append(dict(origin=origin,declared=record,actual=actual))
    return actual

def save(name,value):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

seal_path=PROGRESS/'ROOT-actual-independent-Q-audit-failure-disposition-v1.json'
seal=read(seal_path)
check('exact ROOT failure disposition',pin(seal_path)['sha256']=='472dcd9c76a0b5ab3fb6916d94a7c72179ebdfdb93e8937023933acf7a0667b7' and pin(seal_path)['bytes']==3895,pin(seal_path))
leaf=read(PROGRESS/'worker-plan-v1.json');owner_plan=read(PROGRESS/'preparation-plan-v1.json')
construction=read(PROGRESS/'ROOT-construction-v1.json');validation=read(PROGRESS/'ROOT-actual-saved-plan-validation-v1.json')
caller=read(PROGRESS/'preparation-actual-tool-observations-v1.json')
owner=read(PROGRESS/'preparation-owner-v1/provisional-terminal-v1.json')
post=read(PROGRESS/'preparation-owner-v1/post-write-observation-v1.json')
decision=read(PROGRESS/'preparation-ROOT-final-decision-v1.json')
failure=read(PROGRESS/'worker-output-v1/failure-v1.json')
launch=read(PROGRESS/'preparation-owner-v1/launch-v1.json')
stderr=(PROGRESS/'preparation-owner-v1/stderr-v1.txt').read_text()
ledger_record=verify(owner['ownership_ledger'],'owner complete gzip ledger')
ledger=json.loads(gzip.decompress(Path(ledger_record['path']).read_bytes()))
for role in ['resource_qualification','actual_caller','owner_terminal','owner_postwrite','worker_failure','worker_stderr','worker_plan','owner_plan']:
    verify(seal[role],'ROOT disposition '+role)
leaf_closure={r['path']:verify(r,'leaf closure '+r['path']) for r in leaf['raw_closure']}
owner_closure={pin(r['path'])['path']:verify(r,'owner closure '+r['path']) for r in owner_plan['closure']}
check('exact75 leaf and76 owner closures',len(leaf_closure)==len(leaf['raw_closure'])==75 and len(owner_closure)==len(owner_plan['closure'])==76 and validation['worker_closure_count']==75 and validation['owner_closure_count']==76 and construction['raw_closure_count']==76,dict(leaf=75,owner=76))
check('owner covers every leaf record plus exact leaf pin',all(owner_closure[k]==v for k,v in leaf_closure.items()) and owner_closure[str(PROGRESS/'worker-plan-v1.json')]==pin(PROGRESS/'worker-plan-v1.json'), 'canonical leaf versus ROOT-relative generic owner spellings')
check('strict11 leaf10 owner6 argv',len(leaf)==11 and len(owner_plan)==10 and len(owner_plan['argv'])==6 and validation['leaf_fields']==11 and validation['owner_fields']==10 and validation['argv_count']==6,'saved actual plans, no plan construction by reviewer')
check('three Source roles/two executable roles/input11',set(leaf['sources'])=={'worker','independent_auditor','master'} and leaf['source_cache_gate']['executed_roles']==['worker','independent_auditor'] and len(leaf['inputs'])==11,'executed-role permission is not evidence the auditor executed')
limits=dict(whole_seconds=60,control_seconds=20,caller_seconds=90,peak_bytes=536870912)
check('original budgets and runtime untouched',leaf['limits']==owner_plan['limits']==post['limits']==decision['limits']==limits and leaf['allowed_runtime']['python_version']==[3,9,6] and leaf['allowed_runtime']['platform']=='darwin',limits)
check('byte-identical generic owner/closer',pin(PROGRESS/'run_owned_bridge_v2.py')['sha256']=='2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656' and pin(PROGRESS/'close_stage_decision_v1.py')['sha256']=='9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf',dict(owner=pin(PROGRESS/'run_owned_bridge_v2.py'),closer=pin(PROGRESS/'close_stage_decision_v1.py')))
check('one literal actual launch',launch['argv']==owner_plan['argv'] and launch['status']=='one_frozen_attempt' and seal['actual_invocations']==1 and len(caller['observations'])==1 and caller['terminal']==caller['observations'][-1],launch)
check('same-isolate caller clock saved identity',caller['clock_scope']=='Date.now request-to-observed-terminal in the same awaited isolate; no elapsed clocks summed.' and caller['launch']['session_id']==20379 and caller['terminal']['exit_code']==0 and (caller['terminal_observed_ms']-caller['started_ms'])/1000==caller['genuine_caller_elapsed_seconds']==decision['caller_elapsed_seconds']==seal['genuine_caller_seconds']==10.07,'Root tool evidence, not an independent re-observation of the original process')
check('caller bound passes without rescuing owned memory',10.07+caller['caller_finish_reserve_seconds']<=90 and caller['caller_finish_reserve_seconds']==decision['caller_finish_reserve_seconds']==1 and decision['predicates']['caller_clock_bound'] is True,'nested owner clock is not added to caller')
printed=json.loads(caller['terminal']['output'].strip().splitlines()[-1])
check('terminal output matches saved postwrite failure',printed['resource_gate_accepted'] is False and printed['terminal'] is None and printed['elapsed_seconds']==post['elapsed_seconds']==seal['owned_postwrite_seconds']==3.298020709 and printed['peak_bytes']==post['peak_bytes']==seal['observed_owned_postwrite_peak_bytes']==548421632,'owner tool exits0 but reports UNKNOWN resource gate')
check('worker memory reserve and owner cap both exceeded',owner['worker_kernel_peak_bytes']==ledger['kernel_worker_peak_bytes']==seal['worker_kernel_peak_bytes']==530169856 and owner['worker_kernel_peak_bytes']>500*1048576 and post['peak_bytes']>536870912 and owner['error']==dict(type='ValueError',message='sampled owner/observer/owned-worker memory'),'no memory-fit or resource acceptance inferred')
samples=ledger['samples']
check('all26 ownership samples retained',len(samples)==owner['sampled_observations']==26 and all(samples[i]['seconds']<=samples[i+1]['seconds'] for i in range(len(samples)-1)),'complete saved small gzip ledger, no host process query by reviewer')
check('every sample sum and birth identity reconcile',all(s['owned_rss_bytes']==sum(r['rss_bytes'] for r in s['owned_rows'].values()) and s['combined_bytes']==s['ROOT_peak_bytes']+s['owned_rss_bytes']+s['observer_peak_bytes'] and set(s['owned_rows'])=={'3187'} and s['owned_rows']['3187']['pgid']==3187 and s['owned_rows']['3187']['ppid']==3185 and s['owned_rows']['3187']['birth']==ledger['final_retained_births']['3187'] for s in samples),'one recorded task-owned worker identity throughout all samples')
check('conservative kernel+sample peak consistent',owner['peak_bytes']==max([owner['ROOT_peak_bytes']+owner['worker_kernel_peak_bytes']+owner['direct_children_peak_sum_bytes']+owner['observer_peak_bytes']]+[s['combined_bytes'] for s in samples]) and owner['max_sampled_owned_rss_bytes']==max(s['owned_rss_bytes'] for s in samples),'sampled memory is supplemental to kernel peaks, not a strict OS cap')
check('postwrite peak and clock increase preserved',post['peak_bytes']>=owner['peak_bytes'] and post['elapsed_seconds']>=owner['elapsed_before_write_seconds'] and post['provisional']['sha256']==pin(PROGRESS/'preparation-owner-v1/provisional-terminal-v1.json')['sha256'],'no earlier sample relabelled accepted')
check('TERM worker terminal and reaped/no leftovers',owner['worker_returncode']==seal['worker_returncode']==-15 and owner['all_direct_children_terminal_and_reaped'] is True and owner['owned_leftovers']==seal['owned_leftovers']==[] and ledger['leftovers']=={} and owner['cleanup_errors']==[] and owner['cancelled'] is False,'saved owner wait4/resource custody only; reviewer issues no new resource authority')
check('failure occurred at first preparation input seal',all(s in stderr for s in ['line 565, in main','seals={name:value_digest(value,lambda:checked_fn(True))','line 244, in value_digest','tick()','line 416, in whole_tick','ValueError: whole55/500']) and failure['error']==dict(type='ValueError',message='whole55/500 with fixed inherited60/512 owner finish reserves'),'Source bound trace after preparation read, before line573 raw auditor load and line597 call; allocation attribution is not measured')
worker_source=Path(leaf['sources']['worker']['path']).read_text()
check('frozen Source load follows failing seal site',worker_source.index('seals={name:value_digest')<worker_source.index("module=load(AUDITOR,")<worker_source.index('certificate=entry('),'no project function called to infer this Source ordering')
check('no certificate/receipt/prefix and only failure artifact',sorted(p.name for p in (PROGRESS/'worker-output-v1').iterdir())==['failure-v1.json'] and failure['stage_completed'] is False and failure['accepted_prefix'] is False and failure['provisional_artifacts']==[] and failure['partial_paths']==[] and owner['worker_receipt'] is None and decision['worker'] is None,'absence checked at saved current output namespace')
check('no accepted terminal hardlink',not (PROGRESS/'preparation-owner-v1/ROOT-terminal-v1.json').exists() and post['terminal'] is None and post['resource_gate_accepted'] is False and owner['resource_gate_accepted'] is False and decision['ROOT_final_accepted'] is False,'UNKNOWN remains terminal despite caller0 exit')
expected_false={'owner_terminal_link_present','owner_gate','post_write_gate','final_print_gate','stage_identity','worker_complete','all_worker_direct_children_closed','post_write_exact_terminal'}
check('all14 closer predicates truthful',len(decision['predicates'])==14 and {k for k,v in decision['predicates'].items() if v is False}==expected_false and decision['mismatches']==[],'successful custody predicates separated from failed completion/resource predicates')
check('Root failure seal every stronger scope false',all(seal[k] is False for k in ['ROOT_complete_independent_audit_accepted','mathematical_catalogue_admitted','accepted_prefix','target_proofs_accepted','native_accepted','full24_accepted','full_PA_accepted','induction_accepted']) and seal['audit_certificates']==0 and seal['target_searches']==0 and seal['RL_training_runs']==0 and all(failure[k] is False for k in ['ROOT_mathematical_admission_issued','resource_acceptance_issued','accepted_prefix']), 'independent auditor module/call never reached in saved frozen Source path')

whole_files=[pin(PROGRESS/n) for n in ['ROOT-actual-independent-Q-audit-failure-disposition-v1.json','worker-plan-v1.json','preparation-plan-v1.json','ROOT-construction-v1.json','ROOT-actual-saved-plan-validation-v1.json','preparation-actual-tool-observations-v1.json','preparation-ROOT-final-decision-v1.json','preparation-owner-v1/launch-v1.json','preparation-owner-v1/provisional-terminal-v1.json','preparation-owner-v1/post-write-observation-v1.json','preparation-owner-v1/stdout-v1.txt','preparation-owner-v1/stderr-v1.txt','preparation-owner-v1/owned-ownership-ledger-v1.json.gz','worker-output-v1/failure-v1.json']]
findings=dict(schema='independent-Q-first-audit-failure-saved-findings-v1',reviewer_identity='/root/arithmetic_induction',
    source_only=True,saved_metadata_only=True,all_checks_passed=True,mismatches=[],scientific_calls=0,project_imports=0,
    semantic_replays=0,large_preparation_or_witness_parses=0,actual_plan_or_scientific_executions=0,
    mathematical_acceptance=False,resource_acceptance=False,accepted_prefix=False,
    classification='saved failed audit reconciled; complete independent audit remains UNKNOWN',
    ROOT_failure_disposition=pin(seal_path),complete_saved_files=whole_files,raw_closure_refs=raw_refs,
    raw_closure_counts=dict(worker=75,owner=76),checks=checks,check_count=len(checks),
    exact_costs=dict(genuine_saved_caller_seconds=10.07,caller_finish_reserve_seconds=1,
        owned_postwrite_seconds=3.298020709,worker_kernel_peak_bytes=530169856,
        owned_postwrite_peak_bytes=548421632,owned_cap_bytes=536870912,
        owned_peak_overshoot_bytes=548421632-536870912,
        worker_reserve_ceiling_bytes=524288000,worker_reserve_overshoot_bytes=530169856-524288000,
        scopes='Nested clocks are inclusive and not added. Caller provenance is Root same-awaited-isolate record, not independent process re-observation.'),
    terminal=dict(worker_returncode=-15,worker_pid=3187,owner_pid=3185,reaped=True,owned_leftovers=[],
        worker_failure_type='ValueError',worker_failure_message=failure['error']['message'],
        auditor_loaded_or_called_in_saved_frozen_path=False,certificate_count=0,receipt_count=0),
    earlier_producer_and_worker_review_authorship_disclosed=True,
    independence_scope='Earlier Q producer author and Source reviewer now reconciles saved bytes/custody only. No new mathematical, semantic or resource authority, and no independent observer/whole-host completeness claim.',
    qualifications=['Trace places the failure at the first seal boundary after the complete preparation parse. It does not independently measure which allocation caused peak memory.',
        'Owner memory rejection, worker own reserve rejection, TERM/reap, caller clock success and absence of receipts are distinct facts; caller0 and closed processes do not rescue the failed resource/completion gate.',
        'No canonical catalogue count or formula/model reconstruction was performed. Original grammar/all rows remain bound raw inputs; independent completeness/admission/proof/native/fullboard/induction/PA/RL stays open.',
        'Original failed attempt and all complete Source/plan/result bytes remain untouched; future repair needs separate Source review and ROOT dispatch.'])
findings_pin=save('findings-v1.json',findings)
handoff_pin=save('handoff-v1.json',dict(schema='independent-Q-failure-saved-review-handoff-v1',saved_metadata_only=True,
    all_checks_passed=True,mismatches=[],scientific_calls=0,reviewer_identity='/root/arithmetic_induction',
    ROOT_failure_disposition=pin(seal_path),findings=findings_pin,checks=len(checks),
    mathematical_acceptance=False,resource_acceptance=False,complete_independent_audit_accepted=False,
    caller_seconds=10.07,owned_postwrite_seconds=3.298020709,owned_peak_bytes=548421632,
    outcome='UNKNOWN retained; no receipt/certificate/accepted prefix; worker terminal/reaped and no leftovers.'))
integration_pin=save('integration-v1.json',dict(schema='private-saved-review-integration-v1',saved_metadata_only=True,
    files=[pin(__file__),findings_pin,handoff_pin],scientific_calls=0,resource_or_math_authority=False))
print(json.dumps(dict(findings=findings_pin,handoff=handoff_pin,integration=integration_pin,checks=len(checks),scientific_calls=0),sort_keys=True))
