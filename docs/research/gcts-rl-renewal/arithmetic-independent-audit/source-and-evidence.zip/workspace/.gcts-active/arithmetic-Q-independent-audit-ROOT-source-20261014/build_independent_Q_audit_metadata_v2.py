"""ROOT named metadata constructor. No project/scientific imports or calls."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / '.gcts-active/arithmetic-Q-independent-audit-shared-wire-progress-20261014'
AUTHOR = '/root/hilbert_ordering_diagnosis'
SCOPE = 'independent-complete-finite-Q-catalogue-primitive-initial-domains-no-search'


def pin(path, relative=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    assert path == path.resolve() and path.is_file() and not path.is_symlink()
    before = path.stat()
    h, length = hashlib.sha256(), 0
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(65536), b''):
            h.update(block)
            length += len(block)
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    name = str(path.relative_to(ROOT)) if relative and ROOT in path.parents else str(path)
    return dict(path=name, sha256=h.hexdigest(), bytes=length)


def read(path):
    path = Path(path)
    record = pin(path)
    raw = path.read_bytes()
    assert len(raw) <= 2 * 1048576 and len(raw) == record['bytes']
    assert hashlib.sha256(raw).hexdigest() == record['sha256']
    def unique(pairs):
        result = {}
        for name, value in pairs:
            assert name not in result
            result[name] = value
        return result
    result = json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    assert pin(path) == record
    return result


def write(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write('\n')
    return pin(path)


def collect(closure, value):
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            actual = pin(value['path'])
            assert actual['sha256'] == value['sha256'] and actual['bytes'] == value['bytes']
            assert actual['path'] not in closure or closure[actual['path']] == actual
            closure[actual['path']] = actual
        else:
            for child in value.values():
                collect(closure, child)
    elif type(value) is list:
        for child in value:
            collect(closure, child)


def main(peer_path, contract_path):
    peer_path, contract_path = Path(peer_path).resolve(), Path(contract_path).resolve()
    peer, contract = read(peer_path), read(contract_path)
    assert contract['schema'] == 'independent-Q-cold-audit-worker-Source-contract-v1'
    sources, inputs = contract['sources'], contract['named_inputs']
    abi, owned = contract['prospective_leaf_ABI'], contract['owned_ABI']
    limits = abi['limits']
    assert set(sources) == {'worker', 'independent_auditor', 'master'} and len(inputs) == 11
    assert limits == dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)
    assert abi['scope'] == SCOPE and abi['field_count'] == 11 and owned['field_count'] == 10
    assert peer['schema'] == 'independent-Q-cold-audit-worker-Source-review-v1'
    assert peer['source_only'] is True and peer['source_review_passed'] is True
    assert peer['all_checks_passed'] is True and type(peer['scientific_calls']) is int and peer['scientific_calls'] == 0
    assert peer['author_identity'] == AUTHOR and peer['reviewer_identity'] != AUTHOR
    assert peer['scope'] == 'independent-Q-cold-audit-worker-Source' and peer['sources'] == sources
    assert peer['source_contract'] == pin(contract_path) and not DEST.exists()
    auditor_peer_pin = contract['genuine_existing_auditor_Source_review']
    auditor_peer = read(auditor_peer_pin['path'])
    assert pin(auditor_peer_pin['path']) == auditor_peer_pin
    assert auditor_peer['source_only'] is True and auditor_peer['source_review_passed'] is True
    assert auditor_peer['all_checks_passed'] is True and auditor_peer['scientific_calls'] == 0
    assert auditor_peer['author_identity'] == AUTHOR and auditor_peer['reviewer_identity'] != AUTHOR
    assert auditor_peer['sources'] == {k: sources[k] for k in ('independent_auditor', 'master')}
    closure = {}
    named = [(contract_path, contract), (peer_path, peer), (Path(auditor_peer_pin['path']), auditor_peer)]
    # Only the explicitly consumed small metadata roots are decoded. Preparation
    # and complete state/oracle witnesses remain raw leaves in this constructor.
    raw_roles = {'producer_preparation', 'initial_state', 'initial_oracle_domains'}
    documents = {}
    for role, record in inputs.items():
        assert pin(record['path']) == record
        if role not in raw_roles:
            value = read(record['path'])
            documents[role] = value
            named.append((Path(record['path']), value))
    producer_owner_pin = documents['producer_receipt']['owner_plan']
    producer_owner_path = Path(producer_owner_pin['path'])
    if not producer_owner_path.is_absolute():
        producer_owner_path = ROOT / producer_owner_path
    producer_owner = read(producer_owner_path)
    named.append((producer_owner_path, producer_owner))
    runtime = documents['producer_worker_plan']['runtime']
    assert set(runtime) == {'binary', 'resource_extension', 'python_version', 'platform'}
    assert runtime['python_version'] == [3, 9, 6] and runtime['platform'] == 'darwin'
    assert documents['producer_worker_plan']['sources'] == contract['raw_only_producer_sources']
    for path, value in named:
        collect(closure, [pin(path), value])
    collect(closure, [sources, inputs, runtime, pin(__file__)])
    DEST.mkdir()
    copied = {}
    for role, name in (('owner', 'run_owned_bridge_v2.py'), ('closer', 'close_stage_decision_v1.py')):
        original = owned[role]
        assert pin(original['path']) == original
        shutil.copyfile(original['path'], DEST / name)
        copied[role] = pin(DEST / name)
        assert copied[role]['sha256'] == original['sha256'] and copied[role]['bytes'] == original['bytes']
    root_review = dict(schema='independent-Q-cold-audit-worker-Source-review-v1',
        author_identity=AUTHOR, reviewer_identity='/root', source_only=True,
        source_review_passed=True, all_checks_passed=True, scientific_calls=0,
        mathematical_acceptance=False, source_contract=pin(contract_path),
        sources=sources, inputs=inputs, scope='independent-Q-cold-audit-worker-Source',
        independent_review=pin(peer_path), auditor_independent_review=auditor_peer_pin,
        metadata_constructor=pin(__file__), owner=copied['owner'], closer=copied['closer'],
        whole_current_worker_auditor_master_and_contract_read=True,
        checks=['Current complete worker, independent auditor and master read; exact Source pins and distinct typed reviews.',
            'Strict 11-field leaf, 10-field generic owner, six argv and exact unchanged runtime/caps.',
            'Only independent worker/auditor execute; all seven producer roles remain raw provenance.',
            'One preparation parse in the future worker; whole registry/primitive/24-domain and byte/SHA/EOF comparisons.',
            'Original callbacks/helper/code/clock/MRO/default/closure are fixed; full declaration, preparation and producer-source value seals bracket the audit.',
            'Shared 20 starts before metadata preflight; evidence/receipt/final guards remain in owned/caller bounds.'],
        scope_limits=['Source-only metadata and future one complete audit, never mathematical or resource acceptance.',
            'No theorem route, target search, word-control acceptance, rank computation, native/full-board/trajectory/PA/induction/RL claim.'])
    root_review_pin = write(DEST / 'ROOT-source-review-v1.json', root_review)
    collect(closure, [root_review, root_review_pin, copied])
    leaf_path, owner_path = DEST / 'worker-plan-v1.json', DEST / 'preparation-plan-v1.json'
    output = DEST / 'worker-output-v1'
    leaf = dict(schema=abi['schema'], stage='preparation', activation=abi['activation'],
        outdir=str(output), sources=sources, inputs=inputs,
        source_review=dict(ROOT=root_review_pin, worker_independent=pin(peer_path), auditor_independent=auditor_peer_pin),
        limits=limits, allowed_runtime=runtime, source_cache_gate=abi['cache_gate'],
        raw_closure=[closure[k] for k in sorted(closure)])
    assert set(leaf) == set(abi['fields']) and len(leaf) == 11
    leaf_pin = write(leaf_path, leaf)
    collect(closure, leaf_pin)
    def lexical(record):
        return pin(record['path'], relative=True)
    argv = [runtime['binary']['path'], '-B', sources['worker']['path'],
        'ROOT-independent-complete-Q-mathematical-audit', str(leaf_path), str(owner_path)]
    owner = dict(schema=owned['schema'], stage='preparation', runtime_binary=lexical(runtime['binary']),
        worker=str(Path(sources['worker']['path']).relative_to(ROOT)), argv=argv,
        worker_receipt=str((output / owned['receipt']).relative_to(ROOT)), limits=limits,
        closure=[lexical(closure[k]) for k in sorted(closure)], ROOT_source_review=lexical(root_review_pin), scope=SCOPE)
    assert set(owner) == set(owned['fields']) and len(owner) == 10 and len(argv) == 6
    owner_pin = write(owner_path, owner)
    for record in closure.values():
        assert pin(record['path']) == record
    result = dict(schema='ROOT-independent-Q-audit-metadata-construction-v1',
        metadata_execution_only=True, project_imports=0, scientific_calls=0,
        worker_plan=leaf_pin, owner_plan=owner_pin, source_contract=pin(contract_path),
        peer_review=pin(peer_path), auditor_peer_review=auditor_peer_pin,
        owner_source=copied['owner'], closer_source=copied['closer'],
        named_metadata_roots=[pin(p) for p, value in named], raw_closure_count=len(closure),
        literal_owner_command=[runtime['binary']['path'], '-B', copied['owner']['path'], owner_pin['path']],
        actual_execution_accepted=False, mathematical_catalogue_admitted=False, target_proof_accepted=False)
    print(json.dumps(write(DEST / 'ROOT-construction-v1.json', result)), flush=True)


if __name__ == '__main__':
    assert len(sys.argv) == 3
    main(sys.argv[1], sys.argv[2])
