"""Only raw JSON/hash/AST author metadata; never imports or runs worker/auditor."""
from pathlib import Path
import ast
import hashlib
import json
import symtable
import builtins

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
AUTHOR='/root/hilbert_ordering_diagnosis'

def pin(path):
    path=Path(path).resolve(); raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(path):
    return json.loads(Path(path).read_bytes())

def save(name,value):
    path=HERE/name
    if path.exists():raise FileExistsError('frozen Source metadata exists')
    path.write_text(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(path)

worker=HERE/'independent_Q_cold_worker_v1.py'
raw=worker.read_bytes(); tree=ast.parse(raw.decode(),str(worker)); compile(tree,str(worker),'exec')
constants={}
for node in tree.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try:constants[node.targets[0].id]=ast.literal_eval(node.value)
        except (ValueError,TypeError):pass
sources={'worker':pin(worker),'independent_auditor':constants['AUDITOR'],'master':constants['MASTER']}
for record in [*sources.values(),*constants['PRODUCER_SOURCES'].values(),*constants['FROZEN_INPUTS'].values()]:
    assert pin(record['path'])==record
parent=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-source-20261014/arithmetic_Q_streamed_controls_worker_v7.py'
parent_raw=parent.read_bytes(); parent_tree=ast.parse(parent_raw.decode())
def ast_defs(value):
    return {node.name:ast.dump(node,include_attributes=False) for node in value.body if isinstance(node,ast.FunctionDef)}
old,new=ast_defs(parent_tree),ast_defs(tree)
borrowed=['need','canonical','pin','verify','parse','read','load','normalize','value_state',
          'executable_state','unchanged_executable','json_blockable','json_chunks']
assert all(old[name]==new[name] for name in borrowed)
imports=[alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names]
imports += [node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]
assert set(imports)<={'hashlib','importlib.util','inspect','json','math','os','pathlib','resource','sys','time'}
assert len([n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='load'])==1
assert b'11147' not in raw and b'16200' not in raw
names={node.name for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
names|={'__name__','__file__','__package__'}
names|={a.asname or a.name.split('.')[0] for node in tree.body if isinstance(node,ast.Import) for a in node.names}
names|={a.asname or a.name for node in tree.body if isinstance(node,ast.ImportFrom) for a in node.names}
names|={target.id for node in tree.body if isinstance(node,ast.Assign) for target in node.targets if isinstance(target,ast.Name)}
unknown=[]
def scan(table):
    for name in table.get_identifiers():
        entry=table.lookup(name)
        if entry.is_global() and entry.is_referenced() and name not in names and name not in vars(builtins):
            unknown.append([table.get_name(),name])
    for child in table.get_children():scan(child)
scan(symtable.symtable(raw.decode(),str(worker),'exec'))
assert not unknown
locations={node.name:dict(line=node.lineno,end_line=node.end_lineno) for node in tree.body if isinstance(node,ast.FunctionDef)}
reference=ROOT/'.gcts-active/arithmetic-Q-streamed-controls-progress-20261014'
auditor_review=pin(ROOT/'.gcts-active/arithmetic-Q-independent-mathematical-audit-review-source-20261014/independent-Q-typed-Source-review-v1.json')
reviewed=read(auditor_review['path'])
assert reviewed['sources']=={'independent_auditor':sources['independent_auditor'],'master':sources['master']}
assert reviewed['scientific_calls']==0 and reviewed['mathematical_acceptance'] is False

contract={
    'schema':'independent-Q-cold-audit-worker-Source-contract-v1','author_identity':AUTHOR,
    'source_only':True,'project_or_semantic_calls':0,'actual_worker_activation':False,
    'sources':sources,'executed_project_roles':['worker','independent_auditor'],
    'raw_only_producer_sources':constants['PRODUCER_SOURCES'],'named_inputs':constants['FROZEN_INPUTS'],
    'frozen_auditor_unchanged':True,'genuine_existing_auditor_Source_review':auditor_review,
    'prospective_leaf_ABI':{
        'schema':constants['SCHEMA'],'field_count':11,
        'fields':['schema','stage','activation','outdir','sources','inputs','source_review','limits',
                  'allowed_runtime','source_cache_gate','raw_closure'],
        'stage':'preparation','scope':constants['SCOPE'],'sources_count':3,'named_inputs_count':11,
        'activation':{'schema':'ROOT-independent-Q-owned-audit-activation-v1','author_identity':'/root',
            'ROOT_owned_once_only':True,'scope':constants['SCOPE'],'source_review_not_mathematical_admission':True,
            'target_searches':0,'native_queries':0,'RL_updates':0},
        'cache_gate':{'executed_roles':['worker','independent_auditor'],
            'raw_only_producer_sources':constants['PRODUCER_SOURCES'],'allow_project_bytecode':False,
            'compile_producer_sources':False,'execute_producer_sources':False},
        'limits':{'whole_seconds':60,'peak_bytes':536870912,'caller_seconds':90,'control_seconds':20},
        'runtime':'Exact original canonical binary +resource extension +Python3.9.6/darwin records; whole raw closure.',
        'source_review_slots':['ROOT','worker_independent','auditor_independent'],
        'worker_review_scope':'independent-Q-cold-audit-worker-Source',
        'auditor_review_scope':'complete-finite-Q-catalogue-primitive-domain-and-word-checker-Source',
        'ROOT_review_path':'fresh namespace/ROOT-source-review-v1.json; genuine Source-only exact current three-role map.'},
    'owned_ABI':{
        'owner':pin(reference/'run_owned_bridge_v2.py'),'closer':pin(reference/'close_stage_decision_v1.py'),
        'copy_constraint':'ROOT copies both byte-identically into one new flat owned progress namespace; their HERE-based paths require it.',
        'schema':'ROOT-guard-native-owned-plan-v1','stage':'preparation','field_count':10,
        'fields':['schema','stage','runtime_binary','worker','argv','worker_receipt','limits','closure','ROOT_source_review','scope'],
        'argv_count':6,
        'worker_argv':['<exact canonical binary>','-B',sources['worker']['path'],constants['COMMAND'],
                       '<canonicalABS worker-plan-v1.json>','<canonicalABS preparation-plan-v1.json>'],
        'receipt':constants['RECEIPT'],
        'owner_spellings':'Repository records are ROOT-relative; binary/observer outside ROOT are absolute. Worker normalizes only equivalent repository spellings to canonical ABS.',
        'owner_seconds':60,'owner_bytes':536870912,'owner_finish_seconds':2,'owner_finish_bytes':8388608,
        'worker_seconds':55,'worker_bytes':524288000,'caller_seconds':90,'caller_finish_seconds':1,
        'no_actual_leaf_or_owner_plan_emitted':True},
    'shared_clock':{
        'seconds':20,'starts':'Before metadata preflight and Source/input loading or decoding; no per-phase reset.',
        'includes':['complete raw input authentication','one preparation JSON parse','before/after complete canonical data seals',
            'exact raw compile +code/object/cache guards','independent tuple semantic construction','full formula/primitive closure audit',
            'all24 initial domain comparisons','whole state/oracle byte+SHA+EOF streams','complete certificate encoding/write and final check'],
        'later_bounded_work':'Evidence, success receipt, postwrite record, stdout and final guard remain inside55/500 and owner60/512; genuine caller90 is ROOT-only.',
        'measured_inner_field':'inner_seconds_before_final_guard; do not present as whole worker or caller time.'},
    'named_reader_roots':{
        'parse_once_inputs':['declaration','producer_receipt','producer_evidence','producer_worker_plan',
            'producer_ROOT_final_decision','producer_ROOT_reconciled_disposition','auditor_contract','auditor_handoff','producer_preparation'],
        'raw_byte_stream_inputs':['initial_state','initial_oracle_domains'],
        'additional_named_metadata':['exact producer owner plan from authenticated receipt/ROOT decision','three exact Source reviews','actual new leaf/owner plans'],
        'raw_closed_only':'All pins inside those named documents and every explicit original worker/owner closure member; no arbitrary ancestor JSON decoding.',
        'preparation_parse_count':1,'producer_sources_compiled_or_called':0,
        'no_prior_proof_word_or_target_route':True},
    'guard_scope':[
        'Own loaders/rejection/hash/serializer and immutable clock/resource callable endpoints are anchored before any project Source.',
        'Raw auditor buffer is exactly the authenticated execution buffer; no bytecode loader, transitive producer execution or unchecked local module.',
        'Whole auditor module constants/functions/classes/MRO/property code and effective audit entry object/code/globals remain fixed.',
        'Exactly one Source module setup fills module/entry cells; nested callback code is checked and final defaults/closure identities are re-sealed before the first semantic call. No later reseal.',
        'Passed invoking guard plus outer shim/clock/writer callbacks carry original function/code/default/cell-content identity checks, with direct own predicate rejection before delegation.',
        'Internally owned Semantics/Boundary objects are created solely by the frozen auditor constructor; no producer class, supplied checker or graph object is injected. Full Source class/MRO methods are guarded; private fields are not a production graph boundary.',
        'Complete canonical parsed-input hash seals bracket audit; full preparation decoded once. These are input integrity checks, not semantic acceptance from hashing.'
    ],
    'outputs':[
        'Q-independent-audit-certificate-provisional-v1.json',
        'Q-independent-audit-evidence-v1.json',
        'Q-independent-audit-result-v1.json',
        'Q-independent-audit-postwrite-observation-v1.json'],
    'success_scopes':{
        'worker':'Completed independently checked finite catalogue/primitive/initial-domain comparison, pending genuine ROOT admission/resource reconciliation.',
        'never_implied':['a target proof','arbitrary-word checker controls or first-proof integration','FOL completeness','induction/full_PA',
            'full24 tiling','native acceptance','full trajectory','RL','external prover or comparative performance'],
        'ROOT_only':['actual activation','genuine caller clock','owner resource qualification','mathematical catalogue admission','future q/consumer qualification']},
    'failure':'Any inner/whole deadline, memory, raw/code/object/input/EOF/semantic/serialization/final-print guard failure leaves UNKNOWN with no success receipt; a later receipt is renamed withdrawn. Every earlier certificate is provisional and no prefix is admitted.',
    'remaining_requirements':['Distinct-author whole cold worker Source review','Genuine ROOT source review/current closure+runtime metadata construction',
        'Pre-registered negative/boundary controls where ROOT requires them','Actual once-only bounded full audit and resource+saved correspondence reconciliation',
        'Fresh mathematical admission and proof-checker/observer integration before any first-proof search'],
    'budget_fit':'UNMEASURED; no execution or resource fit/admission claim.',
    'Source_review_ABI':{
        'schema':'independent-Q-cold-audit-worker-Source-review-v1','scope':'independent-Q-cold-audit-worker-Source',
        'author_identity':AUTHOR,'reviewer_identity':'genuine reviewer differs from author',
        'sources':sources,'source_only':True,'source_review_passed':'only after genuine review',
        'all_checks_passed':'only after genuine review','scientific_calls':0,'mathematical_acceptance':False}
}
contract_pin=save('source-contract-v1.json',contract)
static={'schema':'independent-Q-cold-worker-author-static-evidence-v1','source_only':True,
    'author_identity':AUTHOR,'worker':sources['worker'],'frozen_auditor':sources['independent_auditor'],
    'auditor_unchanged':True,'Source_or_semantic_execution':0,'AST_parse_and_compile_only':True,
    'unresolved_globals':unknown,'imports':imports,'stdlib_imports_only':True,'function_locations':locations,
    'inherited_13_utility_ASTs_identical':borrowed,'borrowed_source':pin(parent),
    'exact_one_raw_load_call_in_Source':'AUDITOR only','producer_modules_remain_unloaded':True,
    'no_observed_formula_or_recipe_count_literals':True,'named_input_raw_pins_verified':constants['FROZEN_INPUTS'],
    'author_evidence_is_not_independent_Source_review_or_mathematical_admission':True}
static_pin=save('author-static-evidence-v1.json',static)
handoff={'schema':'independent-Q-cold-worker-Source-handoff-v1','author_identity':AUTHOR,'source_only':True,
    'worker':sources['worker'],'source_contract':contract_pin,'author_static_evidence':static_pin,
    'frozen_auditor':sources['independent_auditor'],'sources':sources,
    'genuine_auditor_Source_review':auditor_review,'Source_or_semantic_calls':0,'actual_plans_or_activation':False,
    'API':contract['owned_ABI']['worker_argv'],'leaf_fields':11,'owner_fields':10,'sources_count':3,
    'named_inputs_count':11,'raw_executed_project_roles':2,'shared_seconds':20,'owned_seconds':60,
    'owned_bytes':536870912,'caller_seconds':90,'budget_fit':'UNMEASURED',
    'next_ROOT_step':'Assign distinct Source reviewer; author actual typed reviews/closure/runtime +absent flat namespace plans only after pass; copy unchanged generic owner/closer; ROOT performs genuine owned invocation and saved/resource reconciliation. No mathematical admission follows from this handoff.'}
handoff_pin=save('handoff-v1.json',handoff)
print(json.dumps({'worker':sources['worker'],'contract':contract_pin,'handoff':handoff_pin,
    'AST_compile_only':True,'Source_or_semantic_calls':0},sort_keys=True))
