"""Independent saved metadata/raw-byte custody audit. No project-source execution."""
from pathlib import Path
import json, gzip, hashlib, math
ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
BASE = ROOT / '.gcts-active/arithmetic-Q-independent-audit-shared-wire-progress-20261014'
HERE = Path(__file__).resolve().parent
checks = []
raw_targets = {}
raw_references = 0
named_documents = []

def check(label, value, detail=None):
    checks.append({'check': label, 'passed': bool(value), 'detail': detail})

def path(value):
    p = Path(value)
    return p if p.is_absolute() else ROOT / p

def pin(p):
    p = path(p)
    before = p.stat()
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    after = p.stat()
    check('raw file stable: ' + str(p), (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns))
    return {'path': str(p), 'bytes': after.st_size, 'sha256': h.hexdigest()}

def verify(record, origin):
    global raw_references
    raw_references += 1
    p = path(record['path'])
    key = str(p)
    if key not in raw_targets:
        raw_targets[key] = pin(p)
    actual = raw_targets[key]
    check('raw binding ' + origin, type(record.get('bytes')) is int and record['bytes'] == actual['bytes'] and record.get('sha256') == actual['sha256'], {'declared': record, 'actual': actual})
    return actual

def references(value, origin):
    if isinstance(value, dict):
        if {'path', 'sha256', 'bytes'} <= set(value):
            verify(value, origin)
        else:
            for k, v in value.items():
                references(v, origin + '/' + k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            references(v, origin + '/' + str(i))

def read(p):
    p = path(p)
    actual = pin(p)
    raw_targets[str(p)] = actual
    check('named metadata is small: ' + str(p), actual['bytes'] <= 200000)
    d = json.loads(p.read_bytes())
    named_documents.append(actual)
    references(d, str(p))
    return d

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()

names = {
 'disposition': 'ROOT-actual-independent-Q-shared-wire-audit-provisional-disposition-v1.json',
 'worker_plan': 'worker-plan-v1.json', 'owner_plan': 'preparation-plan-v1.json',
 'construction': 'ROOT-construction-v1.json', 'plan_validation': 'ROOT-actual-saved-plan-validation-v1.json',
 'root_review': 'ROOT-source-review-v1.json', 'resource': 'preparation-ROOT-final-decision-v1.json',
 'caller': 'preparation-actual-tool-observations-v1.json', 'launch': 'preparation-owner-v1/launch-v1.json',
 'terminal': 'preparation-owner-v1/ROOT-terminal-v1.json', 'provisional': 'preparation-owner-v1/provisional-terminal-v1.json',
 'owner_post': 'preparation-owner-v1/post-write-observation-v1.json',
 'certificate': 'worker-output-v1/Q-independent-audit-certificate-provisional-v1.json',
 'evidence': 'worker-output-v1/Q-independent-audit-evidence-v1.json',
 'receipt': 'worker-output-v1/Q-independent-audit-result-v1.json',
 'worker_post': 'worker-output-v1/Q-independent-audit-postwrite-observation-v1.json',
}
docs = {k: read(BASE / n) for k, n in names.items()}
w = docs['worker_plan']; o = docs['owner_plan']; c = docs['certificate']; e = docs['evidence']; r = docs['receipt']
t = docs['terminal']; post = docs['owner_post']; rd = docs['resource']; caller = docs['caller']; disp = docs['disposition']
limits = {'caller_seconds':90,'control_seconds':20,'peak_bytes':536870912,'whole_seconds':60}
check('exact worker eleven fields', set(w) == {'activation','allowed_runtime','inputs','limits','outdir','raw_closure','schema','source_cache_gate','source_review','sources','stage'})
check('exact owner ten fields', set(o) == {'ROOT_source_review','argv','closure','limits','runtime_binary','schema','scope','stage','worker','worker_receipt'})
check('all unchanged original limits', all(d['limits'] == limits for d in [w,o,post,rd,docs['launch'],docs['plan_validation']]))
check('exact source role set three', set(w['sources']) == {'worker','independent_auditor','master'})
check('exact named inputs eleven', len(w['inputs']) == 11)
check('whole worker and owner raw closures 84/85', len(w['raw_closure']) == 84 and len(o['closure']) == 85)
wc = {str(path(p['path'])): (p['bytes'],p['sha256']) for p in w['raw_closure']}
oc = {str(path(p['path'])): (p['bytes'],p['sha256']) for p in o['closure']}
check('whole raw closures no duplicate normalized paths', len(wc)==84 and len(oc)==85)
check('owner closure is whole worker closure plus worker plan', all(oc.get(k)==v for k,v in wc.items()) and set(oc)-set(wc)=={str(BASE/'worker-plan-v1.json')})
check('sources, named inputs, reviews and runtimes present in worker closure', all(str(path(p['path'])) in wc and wc[str(path(p['path']))] == (p['bytes'],p['sha256']) for p in list(w['sources'].values())+list(w['inputs'].values())+list(w['source_review'].values())+[w['allowed_runtime']['binary'],w['allowed_runtime']['resource_extension']]))
check('six exact child argv', o['argv'] == [w['allowed_runtime']['binary']['path'],'-B',w['sources']['worker']['path'],'ROOT-independent-complete-Q-mathematical-audit',str(BASE/'worker-plan-v1.json'),str(BASE/'preparation-plan-v1.json')])
check('launch binds unchanged args and original limits', docs['launch']['argv']==o['argv'] and docs['launch']['status']=='one_frozen_attempt')
check('runtime four-field admitted dictionary', set(w['allowed_runtime']) == {'binary','resource_extension','python_version','platform'} and w['allowed_runtime']['python_version']==[3,9,6] and w['allowed_runtime']['platform']=='darwin')
check('worker plan source/cache gate present', isinstance(w['source_cache_gate'],dict) and bool(w['source_cache_gate']))
check('source3 and inputs11 agree in evidence', e['sources']==w['sources'] and e['inputs']==w['inputs'])
check('exact executed raw source ledger worker+auditor', e['executed_raw_project_source_ledger']==[w['sources']['worker'],w['sources']['independent_auditor']])
check('producer seven-source map raw only matches certificate', len(e['raw_only_producer_sources'])==7 and e['raw_only_producer_sources']==c['source_bindings'])
check('producer project calls zero', e['producer_project_calls']==0 and e['independent_module_raw_loaded'] is True)
check('source map input seal', hashlib.sha256(canonical(e['raw_only_producer_sources'])).hexdigest()==e['original_decoded_input_sha256']['producer_sources'])
for role in ['ROOT','worker_independent','auditor_independent']:
    review = read(w['source_review'][role]['path'])
    check('Source review was source-only with no scientific calls: '+role, review.get('source_only') is True and review.get('scientific_calls')==0)
    check('Source review distinct author and reviewer: '+role, review.get('author_identity') != review.get('reviewer_identity'))
    check('Source review records passed: '+role, review.get('source_review_passed',review.get('all_checks_passed')) is True)
    if role!='auditor_independent': check('current worker Source map exact: '+role, review['sources']==w['sources'])
declaration = read(w['inputs']['declaration']['path'])
check('declaration canonical seal matches evidence and certificate', hashlib.sha256(canonical(declaration)).hexdigest()==c['declaration_sha256']==e['original_decoded_input_sha256']['declaration'])
check('preparation whole raw input seal', e['original_decoded_input_sha256']['preparation']==w['inputs']['producer_preparation']['sha256'])
check('one complete parse and both initial EOF comparisons recorded', e['decoded_preparation_count']==1 and e['complete_initial_state_and_oracle_EOF_comparisons'] is True)
check('complete certificate and grammar acceptance recorded only', c['completed'] is True and c['all_catalogue_primitive_and_initial_domains_accepted'] is True and c['bounded_grammar_complete'] is True)
check('empty original Gamma exactly retained', c['original_Gamma']==[])
check('primitive rule census complete six rules', c['primitive_rule_counts']=={'assumption':0,'axiom':2,'eq_subst':5324,'generalize':414,'instantiate':154,'mp':10306})
check('all16200 primitive checks and recipe census', c['actual_primitive_semantic_checks']==16200 and c['census']['recipes']==16200 and sum(c['primitive_rule_counts'].values())==16200)
check('all11147 formula count and complete arity census', c['census']['formulas']==11147 and c['census']['arity_counts']=={'0':5480,'1':414,'2':10306})
prior = read(ROOT/'.gcts-active/arithmetic-Q-streamed-controls-saved-independent-20261014/findings-v1.json')
check('independent certificate census matches earlier producer saved census', c['census']==prior['recorded_census'])
initial = next(v for v in prior['row_census'] if v['phase']=='initial')
pd = c['initial_point_domains']
check('all24 row counts preserve earlier complete stored initial rows', [x['row'] for x in initial['rows']]==list(range(24)) and pd['domain_counts']==[x['count'] for x in initial['rows']])
check('all24 stored hashes have exact digest shape', len(pd['domain_sha256_by_row'])==24 and all(type(v) is str and len(v)==64 and all(ch in '0123456789abcdef' for ch in v) for v in pd['domain_sha256_by_row']))
check('complete domain cardinalities sum36734657', pd['all_rows']==24 and sum(pd['domain_counts'])==pd['complete_candidate_count']==36734657)
check('earlier oracle whole raw pin identical', initial['full_array_sha256']==w['inputs']['initial_oracle_domains']['sha256'])
# Lexical-only raw-byte hashing of all complete top-level oracle row objects.
# No JSON decoding of oracle/preparation/state; no factor enumeration or semantics.
raw = path(w['inputs']['initial_oracle_domains']['path']).read_bytes()
check('raw oracle complete outer array endpoints', raw[:1]==b'[' and raw[-1:]==b']')
row_bytes=[]; depth=0; quoted=False; escaped=False; start=None; nonnegative=True
for i,ch in enumerate(raw):
    if quoted:
        if escaped: escaped=False
        elif ch==92: escaped=True
        elif ch==34: quoted=False
        continue
    if ch==34: quoted=True; continue
    if ch in (91,123):
        depth+=1
        if depth==2:
            check('top-level raw row begins as object '+str(len(row_bytes)),ch==123)
            start=i
    elif ch in (93,125):
        if depth==2:
            check('top-level raw row closes as object '+str(len(row_bytes)),ch==125 and start is not None)
            row_bytes.append(raw[start:i+1]);start=None
        depth-=1
        nonnegative = nonnegative and depth>=0
check('raw oracle complete lexical EOF with exactly24 objects', depth==0 and nonnegative and not quoted and start is None and len(row_bytes)==24)
raw_row_hashes=[hashlib.sha256(v).hexdigest() for v in row_bytes]
for i,(actual,expected) in enumerate(zip(raw_row_hashes,pd['domain_sha256_by_row'])):
    check('whole raw oracle row SHA matches certificate row '+str(i),actual==expected)
check('point decision unchanged stored branch row23/count23/gen0', pd['point_decision']=={'count':23,'generation':0,'kind':'branch','row':23})
check('no selected primitive keys or proof in initial-domain certificate', pd['selected_physical_keys']==0 and pd['exact_saved_point_union_accepted'] is True and all(pd[k] is False for k in ['logical_proof_accepted','full24_accepted','full_trajectory_accepted']))
check('receipt complete but pending ROOT mathematical authority', r['stage_completed'] is True and r['independent_audit_completed'] is True and r['status']=='completed_independent_finite_Q_audit_pending_ROOT' and r['ROOT_mathematical_admission_issued'] is False)
check('certificate/evidence/receipt exact links', r['certificate']==e['certificate'] and r['output_closure_before_receipt']==[r['certificate'],r['evidence']] and docs['worker_post']['certificate']==r['certificate'] and docs['worker_post']['evidence']==r['evidence'])
check('certificate serialization charged inside shared20', e['serialization_records_before_evidence'][0]['inside_shared20'] is True and e['serialization_records_before_evidence'][0]['bytes']==5789)
check('evidence and receipt postwrite separated from20 and inside enclosing budget', r['serialization_records_before_receipt'][1]['inside_shared20'] is False and r['serialization_records_before_receipt'][1]['bytes']==8501 and 0<=e['inner_seconds_before_final_guard']<20 and 0<=r['worker_elapsed_before_receipt_seconds']<=docs['worker_post']['elapsed_seconds_after_receipt_write']<post['elapsed_seconds']<60)
check('resource accepted exactly fourteen predicates', rd['ROOT_final_accepted'] is True and len(rd['predicates'])==14 and all(v is True for v in rd['predicates'].values()) and rd['mismatches']==[])
check('same-isolate caller direct Date.now difference', caller['clock']=='Date.now' and type(caller['started_ms']) is int and type(caller['terminal_observed_ms']) is int and (caller['terminal_observed_ms']-caller['started_ms'])/1000==rd['caller_elapsed_seconds']==disp['genuine_caller_seconds']==20.074)
check('caller terminal0 and all launch/polls same session', caller['terminal']['exit_code']==0 and caller['terminal']==caller['polls'][-1] and len(caller['polls'])==4 and all(p.get('session_id')==caller['launch']['session_id'] for p in caller['polls'][:-1]))
console = json.loads(caller['terminal']['output'])
check('final console exactly terminal and postwrite', console['stage']=='preparation' and console['resource_gate_accepted'] is True and console['cancelled_at_final_print'] is False and console['elapsed_seconds']==post['elapsed_seconds'] and console['peak_bytes']==post['peak_bytes'] and path(console['terminal'])==BASE/'preparation-owner-v1/ROOT-terminal-v1.json' and path(console['worker_receipt'])==BASE/'worker-output-v1/Q-independent-audit-result-v1.json')
check('original caller+finish reserve fits90', rd['caller_finish_reserve_seconds']==disp['caller_finish_reserve_seconds']==1 and rd['caller_elapsed_seconds']+1<90)
check('terminal and provisional byte-identical', (BASE/names['terminal']).read_bytes()==(BASE/names['provisional']).read_bytes())
check('whole owner postwrite clock and peak reconcile disposition', post['elapsed_seconds']==disp['owned_postwrite_seconds']==16.856909916 and post['peak_bytes']==t['peak_bytes']==disp['observed_owned_postwrite_peak_bytes']==336347136)
check('owner finish reserves inside original60/512', t['elapsed_before_write_seconds']+t['write_reserve_seconds']<60 and t['peak_bytes']+t['memory_write_reserve_bytes']<536870912 and t['write_reserve_seconds']==2 and t['memory_write_reserve_bytes']==8388608)
check('peak additive complete declared components', t['peak_bytes']==t['ROOT_peak_bytes']+t['worker_kernel_peak_bytes']+t['observer_peak_bytes']+t['direct_children_peak_sum_bytes'])
check('worker kernel peak exact across receipt/postwrite/owner', r['worker_SELF_peak_before_receipt_bytes']==docs['worker_post']['peak_SELF_bytes_after_receipt_write']==t['worker_kernel_peak_bytes']==disp['worker_kernel_peak_bytes']==317980672)
check('terminal completion no cancellation/error/cleanup or leftovers', t['worker_returncode']==0 and t['cancelled'] is False and t['error'] is None and t['cleanup_errors']==[] and t['owned_leftovers']==[] and t['all_direct_children_terminal_and_reaped'] is True and r['all_direct_children_terminal_and_reaped'] is True and r['direct_children_peak_sum_bytes']==0)
ledger_raw = path(t['ownership_ledger']['path']).read_bytes()
ledger = json.loads(gzip.decompress(ledger_raw))
check('whole saved ledger small and complete133 samples', len(gzip.decompress(ledger_raw))<200000 and len(ledger['samples'])==t['sampled_observations']==disp['sampled_observations']==133)
last=-1; all_pids=set(); maxrss=0
for i,s in enumerate(ledger['samples']):
    rows=s['owned_rows']; keys=set(rows);all_pids.update(keys)
    check('ledger monotone whole clock '+str(i), type(s['seconds']) in (int,float) and math.isfinite(s['seconds']) and last<=s['seconds']<=post['elapsed_seconds']);last=s['seconds']
    check('ledger complete owned sum '+str(i), sum(v['rss_bytes'] for v in rows.values())==s['owned_rss_bytes'])
    check('ledger combined owner+observer+owned '+str(i), s['combined_bytes']==s['ROOT_peak_bytes']+s['observer_peak_bytes']+s['owned_rss_bytes'] and s['combined_bytes']<=t['peak_bytes'])
    for pid,v in rows.items():
        check('birth-bound worker row '+str(i)+'/'+pid, pid=='7144' and v['ppid']==7142 and v['pgid']==7144 and v['birth']==ledger['final_retained_births'].get(pid) and type(v['rss_bytes']) is int and v['rss_bytes']>=0)
    maxrss=max(maxrss,s['owned_rss_bytes'])
check('complete133 retained birth census and no leftovers', all_pids==set(ledger['final_retained_births'])=={'7144'} and ledger['leftovers']=={} and ledger['kernel_worker_peak_bytes']==t['worker_kernel_peak_bytes'])
check('exact largest sampled RSS and conservative kernel peak', maxrss==t['max_sampled_owned_rss_bytes']==317751296 and maxrss<=t['worker_kernel_peak_bytes'])
check('stderr empty', (BASE/'preparation-owner-v1/stderr-v1.txt').read_bytes()==b'')
for label,d in [('certificate',c),('evidence',e),('receipt',r)]:
    for k in ['native_accepted','full24_accepted','full_PA_accepted','full_trajectory_accepted']:
        if k in d: check('no stronger acceptance '+label+'/'+k,d[k] is False)
    for k in ['RL_updates','target_searches','target_proofs','native_queries']:
        if k in d: check('zero nonscoped work '+label+'/'+k,type(d[k]) is int and d[k]==0)
check('certificate no induction/universal compiler/target discovery', all(c[k] is False for k in ['induction_accepted','universal_compiler_accepted','target_proof_discovered']) and c['searches']==0)
check('Root provisional does not grant mathematical admission or proof', disp['ROOT_complete_independent_audit_accepted'] is False and disp['mathematical_catalogue_admitted'] is False and disp['accepted_prefix'] is False and disp['audit_certificates']==1 and disp['actual_invocations']==1 and disp['target_searches']==0 and all(disp[k] is False for k in ['target_proofs_accepted','native_accepted','full24_accepted','full_PA_accepted','induction_accepted']))
fail = read(ROOT/'.gcts-active/arithmetic-Q-independent-audit-progress-20261014/ROOT-actual-independent-Q-audit-failure-disposition-v1.json')
negative = read(ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-review-source-20261014/findings-v1.json')
check('previous failed actual and negative Source remain explicit', fail['target_proofs_accepted'] is False and negative['source_review_passed'] is False)
# Rehash complete custody after all saved reads; no acceptance by cached first hash.
for key,first in list(raw_targets.items()):
    final=pin(key)
    check('whole raw closure final unchanged: '+key,first==final)
findings={
 'schema':'independent-complete-Q-shared-wire-actual-saved-custody-findings-v1',
 'reviewer_identity':'/root/hilbert_advice_controls','review_type':'saved-metadata-and-whole-raw-custody-only',
 'independent_of_actual_worker_auditor_and_ROOT_projection':True,
 'source_only_saved_metadata':True,'scientific_calls':0,'project_imports':0,'project_functions':0,
 'semantic_replays':0,'kernel_calls':0,'graph_calls':0,'rank_computations':0,'large_payload_JSON_decodes':0,
 'all_scoped_saved_checks_passed':all(x['passed'] for x in checks),'check_count':len(checks),
 'failed_checks':[x for x in checks if not x['passed']], 'checks':checks,
 'raw_reference_count':raw_references,'unique_raw_target_count':len(raw_targets),
 'worker_raw_closure_count':84,'owner_raw_closure_count':85,
 'whole_named_decoded_documents':named_documents,'complete_raw_targets':list(raw_targets.values()),
 'actual_census':c['census'],'actual_primitive_rule_counts':c['primitive_rule_counts'],
 'complete24_domains':{'counts':pd['domain_counts'],'complete_candidate_count':pd['complete_candidate_count'],'raw_object_sha256_by_row':raw_row_hashes,'point_decision':pd['point_decision'],'raw_lexical_object_hash_only':True},
 'resource_reconciliation':{'ROOT14':rd['predicates'],'caller_seconds':20.074,'caller_finish_reserve_seconds':1,'owned_postwrite_seconds':post['elapsed_seconds'],'owned_peak_bytes':t['peak_bytes'],'worker_kernel_peak_bytes':t['worker_kernel_peak_bytes'],'complete_retained_samples':133,'owned_PID_births':ledger['final_retained_births'],'terminal_exit':0,'no_owned_leftovers':True},
 'current_certificate':pin(BASE/names['certificate']),'Root_provisional_disposition':pin(BASE/names['disposition']),
 'mathematical_acceptance_issued':False,'ROOT_inventory_admitted':False,'target_proof_accepted':False,
 'full_PA_accepted':False,'induction_accepted':False,'full24_accepted':False,'native_accepted':False,'RL_accepted':False,
 'limitations':[
  'This distinct-author saved record audit authenticates custody, stored census/row hashes and resource linkages; it does not rerun independent mathematical licensing, kernel or point checking.',
  'All original large preparation/state/oracle payloads were authenticated as complete raw bytes. Oracle row SHA correspondence used a full lexical top-level object scan, with no JSON/factor/semantic decoding.',
  'Earlier producer saved census report was authored by this reviewer and is explicitly historical corroboration, not the distinct mathematical audit or a fresh semantic replay.',
  'Recorded133 owned-row samples and terminal wait4/peak claims remain conditional on the already reviewed pinned supervisor, runtime and ownership filter; no live PS, whole-host observer or hard OS limit is claimed.',
  'Certificate mathematical flags are recorded producer/auditor outcomes. Final Root catalogue mathematical admission remains separate; no theorem, full PA, induction, native proof, whole-board, full trajectory, rank elimination or RL claim is granted.',
  'Prior failed audit and prior Source-v2 negative records remain immutable and do not become accepted prefixes.'
 ]}
out=HERE/'findings-v1.json';out.write_bytes(json.dumps(findings,indent=2,ensure_ascii=False).encode()+b'\n')
handoff={'schema':'independent-Q-shared-wire-saved-custody-handoff-v1','author_identity':'/root/hilbert_advice_controls','findings':pin(out),'all_scoped_saved_checks_passed':findings['all_scoped_saved_checks_passed'],'scientific_calls':0,'mathematical_acceptance_issued':False,'scope':'Whole saved metadata/raw custody reconciliation only; actual Root admission separate.','check_count':len(checks),'raw_target_count':len(raw_targets)}
hp=HERE/'handoff-v1.json';hp.write_bytes(json.dumps(handoff,indent=2).encode()+b'\n')
print(json.dumps({'findings':pin(out),'handoff':pin(hp),'checks':len(checks),'raw_targets':len(raw_targets),'raw_references':raw_references,'failed':findings['failed_checks']},sort_keys=True))
