"""Negative Source review metadata only; no parser/module/project call."""
from pathlib import Path
import ast
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
P=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'
checks=[];refs=[]

def pin(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b);size+=len(b)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)

def read(path):return json.loads(Path(path).read_bytes())

def check(name,passed,evidence):checks.append(dict(name=name,passed=bool(passed),evidence=evidence))

def walk(v,origin):
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:
            actual=pin(v['path']);refs.append(dict(origin=origin,declared=v,actual=actual))
            check('whole raw pin '+origin,actual==dict(v,path=actual['path']),actual)
        else:
            for k,x in v.items():walk(x,origin+'.'+k)
    elif type(v) is list:
        for i,x in enumerate(v):walk(x,origin+'['+str(i)+']')

def save(name,v):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

h=read(P/'handoff-v1.json');c=read(P/'source-contract-v1.json')
raw=Path(c['sources']['worker']['path']).read_bytes();text=raw.decode()
parent_raw=Path(c['parent_worker']['path']).read_bytes();parent_text=parent_raw.decode()
t=ast.parse(text);old_t=ast.parse(parent_text);compile(t,c['sources']['worker']['path'],'exec')
new={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
old={n.name:n for n in old_t.body if isinstance(n,ast.FunctionDef)}
for origin,value in [('handoff',h),('contract',c),('author_static',read(P/'author-static-evidence-v1.json'))]:walk(value,origin)
check('19 old nonmain definitions AST unchanged',all(ast.dump(new[k],include_attributes=False)==ast.dump(v,include_attributes=False) for k,v in old.items() if k!='main'),'full original worker flow retained; previously whole-reviewed parent')
added={'syntax_array','syntax_atom_key','share_syntax_value','parse_shared_syntax','read_lossless_preparation'}
check('exact five allocation-only helpers',set(new)-set(old)==added,sorted(added))
check('auditor and all named original mathematical input bindings unchanged',c['named_inputs']==read(c['parent_source_contract']['path'])['named_inputs'] and c['raw_only_producer_sources']==read(c['parent_source_contract']['path'])['raw_only_producer_sources'],'no grammar/palette/theory/row/semantic Source change')
check('full byte-safe raw parse rule source',all(x in text for x in ["raw.decode(json.detect_encoding(raw),'surrogatepass')",'del raw\n    value=parse_shared_syntax(text)','memo.clear();identities.clear()']), 'one authenticated raw buffer, ordinary stdlib encoding rule; perparse cache released')
check('typed scalar keys preserve bool/int/float sign/string/null',all(x in text for x in ["('bool',value)","('int',value)","('float',value.hex())","('str',value)","('null',)"]), 'Source losslessness reasoning, not executed value comparison')
check('ordered lists retain wire type and every position',"key=('list',tuple(keys))" in text and 'node[:]=children' in text and 'for index,child in enumerate(value):' in text,'key contains complete ordered child keys; memo substitutes an equal actual list, not tuple or normalized formula')
check('dictionaries/occurrence arrays no coalescing or dedup',"if type(value) is not list:" in text and 'return value' in text and "result[name]=share_syntax_value(value,memo,identities)" in text,'all dictionary fields and outer array positions remain; premise identity is index, not AST object identity')
check('duplicate/nonfinite parsing retained',"need(name not in result,'duplicate JSON field')" in text and "ValueError('nonfinite JSON '+token)" in text,'same raw JSON policy; no permissive regex parser')
check('new helpers direct own validator map',all("'"+name+"'" in text[text.index('validator_names='):text.index('validator_functions=')] for name in added),'original direct need/function_state/helper code checks occur before delegation')
check('complete ABI/caps/output/current seals preserved',c['prospective_leaf_ABI']==dict(read(c['parent_source_contract']['path'])['prospective_leaf_ABI']) and c['owned_ABI']['field_count']==10 and c['owned_ABI']['argv_count']==6 and c['owned_ABI']['owner_bytes']==536870912 and c['shared_clock']['seconds']==20,'leaf11/owner10/argv6/source3/input11; only worker path/versioned contract metadata differ')
check('whole sharing values remain read-only in pinned scientific consumer',True,'Independent auditor whole Source previously inspected: raw ASTs are read then converted to interned tuples; witness commands are dict-copied before numeric prior refs; no raw AST mutation or raw AST identity premise authority. Original declarations/payload/source values still before/after canonical sealed. No proof, state or domain computation executed.')
json_root=Path('/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/lib/python3.9/json')
encoder=(json_root/'encoder.py').read_text();decoder=(json_root/'decoder.py').read_text()
check('actual CLT encoder native-callable defaults exist','_intstr=int.__repr__' in encoder and 'isinstance=isinstance' in encoder and 'yield _intstr(value)' in encoder,pin(json_root/'encoder.py'))
check('actual CLT decoder bound-method defaults exist','memo=None, _w=WHITESPACE.match, _ws=WHITESPACE_STR' in decoder and 'def JSONArray(s_and_end, scan_once, _w=WHITESPACE.match' in decoder,pin(json_root/'decoder.py'))
check('new parser snapshots must seal mixed callable defaults',False,'executable_state.add stores defaults=(value_state(__defaults__),value_state(__kwdefaults__)); value_state attempts JSON canonical serialization and returns None on unsupported callable/default data. Both original mixed default tuple and altered mixed tuple therefore produce None. Same function/code with replaced default callable is not rejected by these parser snapshots. No mutation/test was executed.')
blocker=dict(id='stdlib-mixed-default-anchor',severity='preactivation Source blocker',
    worker_lines=[109,110,147,149,504,516],affected_endpoints=[
        dict(endpoint='json.encoder._make_iterencode',raw_Source=pin(json_root/'encoder.py'),Source_lines=[259,272,394],default_example='_intstr=int.__repr__'),
        dict(endpoint='json.decoder.JSONObject',raw_Source=pin(json_root/'decoder.py'),Source_lines=[136,137],default_example='_w=WHITESPACE.match'),
        dict(endpoint='json.decoder.JSONArray',raw_Source=pin(json_root/'decoder.py'),Source_lines=[217,218],default_example='_w=WHITESPACE.match')],
    explanation='Mixed function/native-method default tuples cannot be represented by value_state JSON and are summarized as None. Replacing __defaults__ on the same function with another callable leaves identity/code unchanged and can also summarize as None. The newly promised parser-hook default guard consequently lacks that identity check.',
    required_repair='Preserve this v2 Source and add direct original full function_state/default-entry/kwdefault-entry/closure anchors for all actual Python parser/encoder hooks (including class/MRO/property methods as applicable), checked after original own rejection/state-helper checks. Do not change grammar, parser value semantics, ABI, caps or old receipts.',
    executed_mutation=False,observed_mutation_or_scientific_outcome=False)
findings=dict(schema='independent-Q-lossless-cold-worker-Source-findings-v1',author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',
    source_only=True,source_review_passed=False,all_checks_passed=False,scientific_calls=0,
    parser_executions=0,project_imports=0,auditor_calls=0,actual_plan_constructions=0,
    compile_only_files=1,sources=c['sources'],source_contract=h['source_contract'],reviewed_handoff=pin(P/'handoff-v1.json'),
    checks=checks,check_count=len(checks),raw_references=refs,mismatches=[],blockers=[blocker],
    earlier_producer_authorship_disclosed=True,mathematical_acceptance=False,resource_acceptance=False,
    preserved_parent_review=pin(ROOT/'.gcts-active/arithmetic-Q-independent-cold-worker-review-source-20261014/independent-Q-cold-worker-typed-Source-review-v1.json'),
    preserved_failure=h['preserved_actual_failure'],preserved_failure_saved_review=h['preserved_failure_saved_review'],
    scope_notes=['Storage value-equality argument is coherent in the immutable/read-only consumer scope; no executed equivalence test, parse, actual census or fit is claimed.',
        'Recognizing tag/arity is an allocation recognizer, not semantic syntax/grammar licensing. Equal list values retain actual list type and complete order; malformed values remain for semantic rejection even if equal descendants can share allocation.',
        'Declared three semantic input seals are not full immutable plan dictionaries. All witness raw pins and EOF/final closure remain mandatory.',
        'Old failure was before auditor load, with actual530169856 worker kernel and548421632 owned postwrite bytes. It stays UNKNOWN and is not rescued by this Source proposal.'])
fp=save('findings-v1.json',findings)
tp=save('typed-Source-review-v1.json',dict(schema='independent-Q-cold-audit-worker-Source-review-v1',scope='independent-Q-cold-audit-worker-Source',
    author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',sources=c['sources'],source_contract=h['source_contract'],
    source_only=True,source_review_passed=False,all_checks_passed=False,scientific_calls=0,
    mathematical_acceptance=False,resource_acceptance=False,earlier_producer_authorship_disclosed=True,findings=fp,blocker_ids=['stdlib-mixed-default-anchor']))
hp=save('handoff-v1.json',dict(schema='independent-Q-lossless-worker-negative-review-handoff-v1',source_only=True,
    source_review_passed=False,all_checks_passed=False,scientific_calls=0,typed_Source_review=tp,findings=fp,
    worker=c['sources']['worker'],source_contract=h['source_contract'],required_repair=blocker['required_repair'],
    actual_mutations_or_scientific_calls=0,mathematical_acceptance=False,resource_acceptance=False))
print(json.dumps(dict(findings=fp,typed_review=tp,handoff=hp,checks=len(checks),scientific_calls=0),sort_keys=True))
