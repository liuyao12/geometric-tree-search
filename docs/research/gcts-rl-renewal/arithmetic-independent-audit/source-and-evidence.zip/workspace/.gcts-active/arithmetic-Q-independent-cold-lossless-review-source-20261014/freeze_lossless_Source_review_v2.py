"""Additive narrow default-guard review; raw/AST only, never parser execution."""
from pathlib import Path
import ast
import copy
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
P=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'
checks=[];refs=[]

def pin(path):
    p=Path(path);p=p if p.is_absolute() else ROOT/p;raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(path):return json.loads(Path(path).read_bytes())

def check(name,passed,evidence):
    checks.append(dict(name=name,passed=bool(passed),evidence=evidence))
    if not passed:raise AssertionError(name)

def walk(v,origin):
    if type(v) is dict:
        if set(v)=={'path','sha256','bytes'}:
            a=pin(v['path']);refs.append(dict(origin=origin,declared=v,actual=a))
            check('current full raw pin '+origin,a==dict(v,path=a['path']),a)
        else:
            for k,x in v.items():walk(x,origin+'.'+k)
    elif type(v) is list:
        for i,x in enumerate(v):walk(x,origin+'['+str(i)+']')

def save(name,v):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

h=read(P/'handoff-v2.json');c=read(P/'source-contract-v2.json');old_c=read(P/'source-contract-v1.json')
parent=P/'independent_Q_lossless_cold_worker_v2.py';current=P/'independent_Q_lossless_cold_worker_v3.py'
old_t=ast.parse(parent.read_text());t=ast.parse(current.read_text());compile(t,str(current),'exec')
old={n.name:n for n in old_t.body if isinstance(n,ast.FunctionDef)}
new={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
check('exact selected Source and contract',pin(current)==h['sources']['worker']==c['sources']['worker'] and pin(P/'source-contract-v2.json')==h['source_contract'],h['sources']['worker'])
check('all24 nonmain definitions and5 storage algorithms exact',len(new)==len(old)==25 and all(ast.dump(new[k],include_attributes=False)==ast.dump(v,include_attributes=False) for k,v in old.items() if k!='main'),'no parser/serializer/math/input/ABI/clock algorithm change')
for origin,v in [('handoff',h),('contract',c),('author_static',read(P/'author-static-evidence-v2.json'))]:walk(v,origin)
main=copy.deepcopy(new['main']);prior=old['main']
before=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='own_check')
loops=[n for n in before.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='parser_function_anchors']
check('two pre/post guard loops AST identical',len(loops)==2 and ast.dump(loops[0],include_attributes=False)==ast.dump(loops[1],include_attributes=False),'first occurs before inherited executable checks, second after them')
before.body=[n for n in before.body if n not in loops]
main.body=[n for n in main.body if not (
    isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='parser_function_anchors' for x in n.targets)) and not (
    isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='parser_states')]
check('complete main AST inverse restores v2',ast.dump(main,include_attributes=False)==ast.dump(prior,include_attributes=False),'only anchor initialization and two own_check loops introduced')
text=current.read_text()
check('all code-bearing actual parser records anchored','for _,records,_ in parser_states:' in text and 'if code is None:' in text and 'original_state(fn),binding' in text,'four JSON module snapshots; functions/class-MRO/property-accessor records collected; native code-free objects remain inherited identity/runtime scope')
check('full original defaults and closure state uses immutable original helper','original_state(fn)!=anchor' in text and 'id(fn.__defaults__)' in text and 'id(fn.__kwdefaults__)' in text and 'id(cell.cell_contents)' in text,'mixed callable defaults do not use JSON None as authority')
check('descriptor and effective binding guard exact',all(x in text for x in ["current is not descriptor", "binding=('class',effective.__self__,effective.__func__)", "binding=('direct',effective)","getattr(effective,'__func__',None) is not binding[2]",'effective is not binding[1]']), 'classmethod fresh bound-method objects compared by stable self/function; direct static/module/accessor functions by exact effective object')
body=new['main'];own=next(n for n in body.body if isinstance(n,ast.FunctionDef) and n.name=='own_check')
loop_lines=[n.lineno for n in own.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='parser_function_anchors']
check('original own validator direct rejects precede anchors',loop_lines[0]>next(n.lineno for n in own.body if isinstance(n,ast.If) and 'validator_functions' in ast.dump(n)), 'original function_state identity/code and every own rejection/helper identity/code checked before original_state(fn) delegation')
check('same current contract schema and gates',c['schema']==old_c['schema']=='independent-Q-lossless-cold-audit-worker-Source-contract-v1' and c['prospective_leaf_ABI']==old_c['prospective_leaf_ABI'] and c['named_inputs']==old_c['named_inputs'] and c['raw_only_producer_sources']==old_c['raw_only_producer_sources'],'exact11leaf10owner6argv/source3/input11/master/auditor/producer7/limits retained')
check('all inherited owner ABI except exact worker argv pointer unchanged',dict(c['owned_ABI'],worker_argv=old_c['owned_ABI']['worker_argv'])==old_c['owned_ABI'],'new worker pin/path only; same generic owner/closer,20/55/60/512/caller90 scopes')
check('old negative and actual failure retained',c['preserved_negative_v2_Source_review']==pin(HERE/'handoff-v1.json') and c['preserved_actual_failed_attempt']==old_c['preserved_actual_failed_attempt'],'v2 remains negative/unactivated; original actual memory failure never relabelled')
parent_findings=read(HERE/'findings-v1.json')
retained=[x for x in parent_findings['checks'] if x['passed']]
check('whole inherited positive Source findings retained',len(retained)==len(parent_findings['checks'])-1 and parent_findings['blockers'][0]['id']=='stdlib-mixed-default-anchor','only explicitly repaired blocker disposed; no inherited guard requirement silently omitted')
findings=dict(schema='independent-Q-lossless-cold-worker-Source-findings-v2',author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',
    source_only=True,source_review_passed=True,all_checks_passed=True,scientific_calls=0,parser_executions=0,
    mutation_executions=0,project_imports=0,auditor_calls=0,actual_plan_constructions=0,compile_only_files=1,
    sources=c['sources'],source_contract=h['source_contract'],current_handoff=pin(P/'handoff-v2.json'),
    checks=checks,check_count=len(checks),retained_whole_parent_checks=retained,raw_references=refs,
    preserved_negative_findings=pin(HERE/'findings-v1.json'),preserved_negative_typed_review=pin(HERE/'typed-Source-review-v1.json'),
    blocker_disposition=dict(id='stdlib-mixed-default-anchor',resolved_by_Source='Full original default-container/default-entry/kwdefault-entry/closure anchors and descriptor/effective function bindings bracket delegated snapshots.',executed_mutation_or_parser_test=False),
    blockers=[],mismatches=[],mathematical_acceptance=False,resource_acceptance=False,budget_fit='UNMEASURED',
    earlier_producer_authorship_disclosed=True,
    conditional_scope='Current whole Source with narrow repaired guards only. No parser equivalence control, catalogue/domain/semantic reconstruction, actual20/512 fit or authority is inferred. The original whole input seals and raw witness EOF/closure remain mandatory.',
    descriptor_scope='Ordinary Python functions/classmethods/staticmethods/properties and mixed callable defaults, plus inherited native/runtime identity assumptions. No hostile interpreter or arbitrary VM protection claimed.')
fp=save('findings-v2.json',findings)
tp=save('typed-Source-review-v2.json',dict(schema='independent-Q-cold-audit-worker-Source-review-v1',scope='independent-Q-cold-audit-worker-Source',
    author_identity='/root/hilbert_ordering_diagnosis',reviewer_identity='/root/arithmetic_induction',sources=c['sources'],source_contract=h['source_contract'],
    source_only=True,source_review_passed=True,all_checks_passed=True,scientific_calls=0,
    mathematical_acceptance=False,resource_acceptance=False,earlier_producer_authorship_disclosed=True,findings=fp,
    conditional_scope=findings['conditional_scope']))
hp=save('handoff-v2.json',dict(schema='independent-Q-lossless-current-worker-review-handoff-v2',source_only=True,
    source_review_passed=True,all_checks_passed=True,scientific_calls=0,typed_Source_review=tp,findings=fp,
    source_contract=h['source_contract'],worker=c['sources']['worker'],old_negative_handoff=pin(HERE/'handoff-v1.json'),
    actual_plans_or_activation=False,mathematical_acceptance=False,resource_acceptance=False,budget_fit='UNMEASURED'))
print(json.dumps(dict(findings=fp,typed_review=tp,handoff=hp,checks=len(checks),retained_parent_checks=len(retained)),sort_keys=True))
