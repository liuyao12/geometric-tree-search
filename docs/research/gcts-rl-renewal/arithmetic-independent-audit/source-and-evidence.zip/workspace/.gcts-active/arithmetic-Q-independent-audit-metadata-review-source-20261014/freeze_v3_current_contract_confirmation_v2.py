"""Record-only successor: ROOT already created destination; no project calls."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
P=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'
W=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-review-source-20261014'
HELPER=ROOT/'.gcts-active/arithmetic-Q-independent-audit-ROOT-source-20261014/build_independent_Q_audit_metadata_v3.py'

def pin(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(p):return json.loads(Path(p).read_bytes())

def save(name,v):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

failure=save('current-contract-confirmation-authoring-failure-v1.json',dict(
    schema='Source-review-metadata-authoring-failure-v1',author_identity='/root/arithmetic_induction',
    source_only=True,scientific_calls=0,constructor_executions=0,actual_plans_created=0,
    failed_script=pin(HERE/'freeze_v3_current_contract_confirmation_v1.py'),
    failed_condition='Fresh destination still absent: false after ROOT independently constructed the namespace.',
    saved_confirmation_written=False,current_schema_role_abi_and_cap_comparisons=True,
    producer_worker_or_parser_failure=False,
    scope='Own metadata-authoring assertion only; source verdict, worker bytes and scientific results unchanged.'))
old=read(P/'source-contract-v1.json');current=read(P/'source-contract-v2.json')
peer=read(W/'typed-Source-review-v2.json');helper_text=HELPER.read_text()
checks=[
    dict(name='current wrapper contract schema is exact v3 expected',passed=current['schema']==old['schema']=='independent-Q-lossless-cold-audit-worker-Source-contract-v1' and "assert contract['schema'] == '"+current['schema']+"'" in helper_text),
    dict(name='current Sources3/input11/leaf11/owner10/sixargv unchanged',passed=len(current['sources'])==3 and len(current['named_inputs'])==11 and current['prospective_leaf_ABI']==old['prospective_leaf_ABI'] and current['owned_ABI']['field_count']==10 and current['owned_ABI']['argv_count']==6),
    dict(name='original named inputs and producer raw roles exact',passed=current['named_inputs']==old['named_inputs'] and current['raw_only_producer_sources']==old['raw_only_producer_sources']),
    dict(name='owner/closer/output anchors and all caps retained',passed=dict(current['owned_ABI'],worker_argv=old['owned_ABI']['worker_argv'])==old['owned_ABI']),
    dict(name='actual current peer pin Source map and contract agree',passed=peer['sources']==current['sources'] and peer['source_contract']==pin(P/'source-contract-v2.json') and peer['source_only'] is True and peer['source_review_passed'] is True and peer['all_checks_passed'] is True and peer['scientific_calls']==0),
    dict(name='current author/reviewer identities genuine distinct',passed=peer['author_identity']=='/root/hilbert_ordering_diagnosis' and peer['reviewer_identity']=='/root/arithmetic_induction'),
    dict(name='current clock and execution/success scopes exact',passed=current['shared_clock']==old['shared_clock'] and current['executed_project_roles']==old['executed_project_roles'] and current['success_scopes']==old['success_scopes']),
    dict(name='constructor actual Source remains frozen87df',passed=pin(HELPER)['sha256']=='87df9dd6022f6846518f659a444d6b2ffbe430221b3ee77e67621158f74068c3'),
    dict(name='constructor peer gates bind exact current contract and Source',passed="peer['source_contract'] == pin(contract_path)" in helper_text and "peer['scope'] == 'independent-Q-cold-audit-worker-Source' and peer['sources'] == sources" in helper_text)
]
assert all(c['passed'] for c in checks)
record=save('metadata-constructor-v3-current-contract-confirmation-v2.json',dict(
    schema='independent-Q-constructor-v3-current-contract-applicability-confirmation-v2',
    source_only=True,all_checks_passed=True,source_review_passed=True,scientific_calls=0,
    reviewer_identity='/root/arithmetic_induction',constructor_author_identity='/root',
    constructor=pin(HELPER),current_contract=pin(P/'source-contract-v2.json'),
    current_worker=current['sources']['worker'],current_typed_worker_review=pin(W/'typed-Source-review-v2.json'),
    preserved_constructor_review=pin(HERE/'metadata-constructor-v3-typed-Source-review-v1.json'),
    preserved_constructor_findings=pin(HERE/'metadata-constructor-v3-applicability-findings-v1.json'),
    preserved_authoring_failure=failure,checks=checks,mismatches=[],constructor_executions=0,
    actual_plan_constructions_by_reviewer=0,actual_worker_activations_by_reviewer=0,
    destination_exists_at_confirmation=(ROOT/'.gcts-active/arithmetic-Q-independent-audit-shared-wire-progress-20261014').exists(),
    destination_scope='Prior constructor Source review recorded then-absent destination. ROOT subsequently created it; this is current Source/interface applicability, not a new preactivation/absence or actual saved-plan review.',
    mathematical_acceptance=False,resource_acceptance=False,
    scope='Exact current v3 worker/default-guard contract matches the previously reviewed v3 stdlib metadata constructor. No constructor, worker, parser or science was run by this reviewer.'))
print(json.dumps(record,sort_keys=True))
