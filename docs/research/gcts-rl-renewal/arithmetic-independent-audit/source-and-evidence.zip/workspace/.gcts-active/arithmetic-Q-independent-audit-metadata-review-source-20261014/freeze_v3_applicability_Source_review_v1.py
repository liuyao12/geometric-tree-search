"""Constructor successor applicability, raw/AST only; no constructor runs."""
from pathlib import Path
import ast
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
R=ROOT/'.gcts-active/arithmetic-Q-independent-audit-ROOT-source-20261014'
P=ROOT/'.gcts-active/arithmetic-Q-independent-cold-lossless-source-20261014'

def pin(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def read(path):return json.loads(Path(path).read_bytes())

def save(name,v):
    p=HERE/name
    with p.open('x') as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)

old_path=R/'build_independent_Q_audit_metadata_v1.py'
v2_path=R/'build_independent_Q_audit_metadata_v2.py'
v3_path=R/'build_independent_Q_audit_metadata_v3.py'
old=old_path.read_text();v2=v2_path.read_text();v3=v3_path.read_text()
c=read(P/'source-contract-v1.json');h=read(P/'handoff-v1.json')
tree=ast.parse(v3,str(v3_path));compile(tree,str(v3_path),'exec')
old_schema='independent-Q-cold-audit-worker-Source-contract-v1'
new_schema='independent-Q-lossless-cold-audit-worker-Source-contract-v1'
assert c['schema']==new_schema
assert v2.count("assert contract['schema'] == '"+old_schema+"'")==1
assert v3.replace(new_schema,old_schema)==v2
old_dest='.gcts-active/arithmetic-Q-independent-audit-progress-20261014'
new_dest='.gcts-active/arithmetic-Q-independent-audit-shared-wire-progress-20261014'
old_prose='Original callbacks/helper/code/clock/MRO/default/closure and whole input seals bracket the audit.'
new_prose='Original callbacks/helper/code/clock/MRO/default/closure are fixed; full declaration, preparation and producer-source value seals bracket the audit.'
assert v3.replace(new_schema,old_schema).replace(new_dest,old_dest).replace(new_prose,old_prose)==old
checks=[
    dict(name='v3 exact provided raw binding',passed=pin(v3_path)['sha256']=='87df9dd6022f6846518f659a444d6b2ffbe430221b3ee77e67621158f74068c3' and pin(v3_path)['bytes']==10443),
    dict(name='v2 mismatch preserved, no invocation',passed=old_schema!=c['schema']),
    dict(name='v3 sole one-line expected-schema repair from v2',passed=True),
    dict(name='v3 full inverse to reviewed v1 exact after only3 literals',passed=True),
    dict(name='all4 metadata utility ASTs unchanged',passed=all(ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False) for a,b in zip([n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef) and n.name!='main'],[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name!='main']))),
    dict(name='fresh flat shared-wire destination absent',passed=not (ROOT/new_dest).exists()),
    dict(name='same strict11/10/6 Source3 input11 caps',passed=c['prospective_leaf_ABI']['field_count']==11 and c['owned_ABI']['field_count']==10 and c['owned_ABI']['argv_count']==6 and len(c['sources'])==3 and len(c['named_inputs'])==11 and c['prospective_leaf_ABI']['limits']==dict(whole_seconds=60,peak_bytes=536870912,caller_seconds=90,control_seconds=20)),
    dict(name='same generic owner and closer raw identities',passed=c['owned_ABI']['owner']['sha256']=='2df179c4d500ba17ee832dd7dafb7a43e3fa2f2c171d5b745bfe448275fc1656' and c['owned_ABI']['closer']['sha256']=='9fe3a327bf47fe4694a647e313a718e391f780f72160e3916d0d2fcffa16b7bf'),
    dict(name='three real typed reviews and canonical closure algorithm unchanged',passed='worker_independent=pin(peer_path)' in v3 and 'auditor_independent=auditor_peer_pin' in v3 and "collect(closure, [root_review, root_review_pin, copied])" in v3),
    dict(name='negative current v2 worker cannot satisfy helper gate',passed="peer['source_review_passed'] is True" in v3 and "peer['all_checks_passed'] is True" in v3),
    dict(name='explicit contract/peer raw pin binding remains current',passed="peer['source_contract'] == pin(contract_path)" in v3 and "peer['sources'] == sources" in v3),
    dict(name='no large preparation/witness parse and no project invocation',passed="raw_roles = {'producer_preparation', 'initial_state', 'initial_oracle_domains'}" in v3 and 'if role not in raw_roles:' in v3 and 'subprocess' not in v3 and 'exec(' not in v3),
    dict(name='semantic input seal prose clarified exactly',passed=new_prose in v3),
    dict(name='no actual activation/fit/admission generated',passed='actual_execution_accepted=False, mathematical_catalogue_admitted=False, target_proof_accepted=False' in v3)
]
assert all(x['passed'] for x in checks)
negative=save('metadata-constructor-v2-schema-mismatch-v1.json',dict(schema='independent-Q-constructor-v2-unexecuted-schema-mismatch-v1',
    source_only=True,saved_Source_only=True,constructor_executions=0,scientific_calls=0,
    author_identity='/root',reviewer_identity='/root/arithmetic_induction',source=pin(v2_path),
    current_contract=pin(P/'source-contract-v1.json'),expected_contract_schema=old_schema,actual_contract_schema=new_schema,
    exact_issue='The unchanged old expected wrapper-contract schema assertion would reject the current lossless contract before destination creation.',
    root_repair_source=pin(v3_path),source_review_passed=False,actual_failure_or_science=False))
findings=save('metadata-constructor-v3-applicability-findings-v1.json',dict(schema='independent-Q-constructor-v3-Source-applicability-findings-v1',
    source_only=True,source_review_passed=True,all_checks_passed=True,scientific_calls=0,
    author_identity='/root',reviewer_identity='/root/arithmetic_induction',source=pin(v3_path),
    compared_parent=pin(old_path),preserved_v2=pin(v2_path),preserved_v2_mismatch=negative,
    current_contract=pin(P/'source-contract-v1.json'),current_worker=c['sources']['worker'],
    checks=checks,check_count=len(checks),mismatches=[],constructor_executions=0,actual_plan_constructions=0,
    mathematical_acceptance=False,resource_acceptance=False,compile_only_files=1,
    old_whole_constructor_review=pin(HERE/'metadata-constructor-typed-Source-review-v1.json'),
    scope='Full inherited stdlib metadata constructor applicability only. No new runtime/source/parser/worker acceptance.',
    current_worker_status='Current lossless v2 worker has negative distinct Source review, pending narrow default guard repair. Constructor must receive genuine current positive typed worker review bound to actual successor contract before any execution.',
    conditional_future_applicability='Constructor receives explicit contract/peer paths. A narrow worker successor may be structurally compatible only if schema, exact ABI, roles/runtime/caps and metadata read-site contract remain unchanged and genuine current reviews agree. This record does not preapprove unfrozen worker bytes.',
    earlier_producer_authorship_disclosed=True))
typed=save('metadata-constructor-v3-typed-Source-review-v1.json',dict(schema='independent-Q-audit-metadata-constructor-Source-review-v1',
    scope='pure-stdlib-independent-Q-audit-metadata-constructor-Source',author_identity='/root',reviewer_identity='/root/arithmetic_induction',
    source=pin(v3_path),source_contract=pin(P/'source-contract-v1.json'),source_only=True,
    source_review_passed=True,all_checks_passed=True,scientific_calls=0,
    constructor_executions=0,mathematical_acceptance=False,resource_acceptance=False,
    conditional_scope='Structural metadata applicability only; current positive successor worker review and Root custody remain mandatory.',findings=findings))
handoff=save('metadata-constructor-v3-review-handoff-v1.json',dict(schema='independent-Q-constructor-v3-review-handoff-v1',
    source_only=True,all_checks_passed=True,scientific_calls=0,source=pin(v3_path),
    typed_Source_review=typed,findings=findings,preserved_v2_mismatch=negative,
    actual_plans_created=False,actual_activation_authorized=False,
    next='Await repaired worker current Source review; Root may then decide metadata-only construction in new absent shared-wire namespace.'))
print(json.dumps(dict(typed_review=typed,findings=findings,handoff=handoff,v2_mismatch=negative),sort_keys=True))
