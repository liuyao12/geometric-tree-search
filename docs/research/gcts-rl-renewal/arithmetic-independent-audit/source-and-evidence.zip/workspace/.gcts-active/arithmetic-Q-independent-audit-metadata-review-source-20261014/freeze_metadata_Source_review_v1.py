"""Static constructor review freezer; never executes constructor/project Source."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
HELPER = ROOT / '.gcts-active/arithmetic-Q-independent-audit-ROOT-source-20261014/build_independent_Q_audit_metadata_v1.py'
PACKET = ROOT / '.gcts-active/arithmetic-Q-independent-cold-worker-source-20261014'
PEER = ROOT / '.gcts-active/arithmetic-Q-independent-cold-worker-review-source-20261014/independent-Q-cold-worker-typed-Source-review-v1.json'
CHECKS = []
REFS = []


def pin(path):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    before = p.stat()
    h = hashlib.sha256()
    size = 0
    with p.open('rb') as f:
        for raw in iter(lambda: f.read(65536), b''):
            h.update(raw)
            size += len(raw)
    after = p.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return dict(path=str(p), sha256=h.hexdigest(), bytes=size)


def read(path):
    return json.loads(Path(path).read_bytes())


def check(name, ok, evidence):
    CHECKS.append(dict(name=name, passed=bool(ok), evidence=evidence))
    if not ok:
        raise AssertionError(name)


def raw_refs(value, origin):
    if type(value) is dict:
        if set(value) == {'path', 'sha256', 'bytes'}:
            actual = pin(value['path'])
            REFS.append(dict(origin=origin, declared=value, actual=actual))
            check('exact current raw reference ' + origin, actual == dict(value, path=actual['path']), actual)
            p = Path(actual['path'])
            check('current nonsymlink canonical raw route ' + origin, p == p.resolve() and not p.is_symlink(), str(p))
        else:
            for k, v in value.items():
                raw_refs(v, origin + '.' + k)
    elif type(value) is list:
        for i, v in enumerate(value):
            raw_refs(v, origin + '[' + str(i) + ']')


def save(name, value):
    path = HERE / name
    with path.open('x') as f:
        f.write(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    return pin(path)


raw = HELPER.read_bytes()
text = raw.decode()
tree = ast.parse(text, str(HELPER))
compile(tree, str(HELPER), 'exec')  # syntax only, no import/exec
contract = read(PACKET / 'source-contract-v1.json')
worker_peer = read(PEER)
auditor_peer_record = contract['genuine_existing_auditor_Source_review']
auditor_peer = read(auditor_peer_record['path'])
sources = contract['sources']
inputs = contract['named_inputs']
raw_roles = {'producer_preparation', 'initial_state', 'initial_oracle_domains'}
documents = {role: read(record['path']) for role, record in inputs.items() if role not in raw_roles}
old_owner_ref = documents['producer_receipt']['owner_plan']
old_owner_path = Path(old_owner_ref['path'])
if not old_owner_path.is_absolute():
    old_owner_path = ROOT / old_owner_path
documents['producer_owner_plan'] = read(old_owner_path)
imports = [a.name for node in tree.body if isinstance(node, ast.Import) for a in node.names]
imports += [node.module for node in tree.body if isinstance(node, ast.ImportFrom)]
check('exact helper Source binding', pin(HELPER)['sha256'] == '30b001606ef7b15cfb7791a2a3a0cd89cb8b9007f0a7e8288ff09f3a64084631' and pin(HELPER)['bytes'] == 10371, pin(HELPER))
check('stdlib-only imports', set(imports) == {'hashlib', 'json', 'shutil', 'sys', 'pathlib'}, imports)
check('exact five metadata functions', [n.name for n in tree.body if isinstance(n, ast.FunctionDef)] == ['pin', 'read', 'write', 'collect', 'main'], 'whole Source read, no project loader')
check('no scientific/source loader or subprocess call', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in {'exec', 'eval', 'compile', '__import__'} for n in ast.walk(tree)) and all(x not in text for x in ['subprocess', 'spec_from_file_location', 'GroundChecker', 'PointGraph', 'audit_saved_profile(']), 'only raw hashing/small named JSON/copy/metadata output functions')
check('explicit reviewed constructor request paths', isinstance(next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main'), ast.FunctionDef) and 'main(sys.argv[1], sys.argv[2])' in text, 'Root passes genuine current worker typed peer and worker contract; constructor invocation not performed here')
check('current Sources3 and inputs11', set(sources) == {'worker', 'independent_auditor', 'master'} and len(inputs) == 11, sources)
check('current worker typed review genuine exact scope', worker_peer['source_review_passed'] is True and worker_peer['source_only'] is True and worker_peer['scientific_calls'] == 0 and worker_peer['author_identity'] == '/root/hilbert_ordering_diagnosis' and worker_peer['reviewer_identity'] == '/root/arithmetic_induction' and worker_peer['sources'] == sources and worker_peer['source_contract'] == pin(PACKET/'source-contract-v1.json'), pin(PEER))
check('current auditor typed review genuine exact roles', auditor_peer['source_review_passed'] is True and auditor_peer['source_only'] is True and auditor_peer['scientific_calls'] == 0 and auditor_peer['sources'] == {k:sources[k] for k in ['independent_auditor','master']} and pin(auditor_peer_record['path']) == auditor_peer_record, auditor_peer_record)
for origin, value in [('current_contract', contract), ('worker_typed_peer', worker_peer), ('auditor_typed_peer', auditor_peer), *documents.items()]:
    raw_refs(value, origin)

limits = dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)
check('caps and exact leaf/owner/argv declaration', contract['prospective_leaf_ABI']['limits'] == limits and contract['prospective_leaf_ABI']['field_count'] == 11 and contract['owned_ABI']['field_count'] == 10 and contract['owned_ABI']['argv_count'] == 6, 'no resource reset/expansion; all helper literals agree')
check('current original producer Sources and runtime', documents['producer_worker_plan']['sources'] == contract['raw_only_producer_sources'] and set(documents['producer_worker_plan']['runtime']) == {'binary','resource_extension','python_version','platform'} and documents['producer_worker_plan']['runtime']['python_version'] == [3,9,6] and documents['producer_worker_plan']['runtime']['platform'] == 'darwin', documents['producer_worker_plan']['runtime'])
check('fresh flat exclusive destination currently absent', not (ROOT/'.gcts-active/arithmetic-Q-independent-audit-progress-20261014').exists() and 'assert peer[\'source_contract\'] == pin(contract_path) and not DEST.exists()' in text and 'DEST.mkdir()' in text and "path.open('x')" in text, 'no real plans or output namespace created by reviewer')
check('no large preparation/witness JSON parse', "raw_roles = {'producer_preparation', 'initial_state', 'initial_oracle_domains'}" in text and 'if role not in raw_roles:' in text and 'len(raw) <= 2 * 1048576' in text, 'these three payloads only streamed through raw pin; all named decoded metadata bounded2MiB')
check('same-buffer raw JSON metadata authentication', 'hashlib.sha256(raw).hexdigest() == record[\'sha256\']' in text and 'assert pin(path) == record' in text and 'assert name not in result' in text and 'parse_constant=' in text, 'no duplicate/nonfinite fields, stable same-buffer named metadata only')
check('named original owner pin is subsequently reconciled', 'producer_owner_pin = documents[\'producer_receipt\'][\'owner_plan\']' in text and 'named.append((producer_owner_path, producer_owner))' in text and 'collect(closure, [pin(path), value])' in text, 'declared producer receipt owner hash/bytes checked by collect; original owner whole explicit closure also decoded as named metadata')
check('complete canonical raw leaf collection with both original closures', 'actual = pin(value[\'path\'])' in text and 'closure[actual[\'path\']] = actual' in text and 'collect(closure, [sources, inputs, runtime, pin(__file__)])' in text and all(k in documents['producer_worker_plan'] for k in ['closure','sources','inputs']) and 'closure' in documents['producer_owner_plan'], 'collect traverses all raw pin leaves in exactly named roots, including full original worker/owner closure arrays; no arbitrary ancestor recursion')
check('canonical path de-dup preserves raw identity', "assert actual['path'] not in closure or closure[actual['path']] == actual" in text, 'same canonical file/hash/length only; current raw pin routes all canonical after ROOT-relative expansion')
check('byte-identical pinned owner and closer copies', 'shutil.copyfile(original[\'path\'], DEST / name)' in text and 'copied[role][\'sha256\'] == original[\'sha256\']' in text and 'copied[role][\'bytes\'] == original[\'bytes\']' in text, contract['owned_ABI'])
check('copied owner/closer and actual ROOT typed review closed', 'collect(closure, [root_review, root_review_pin, copied])' in text, 'both copied raw files and local genuine ROOT record included before leaf frozen')
check('Root review construction correct author/reviewer/scope', "reviewer_identity='/root', source_only=True" in text and "author_identity=AUTHOR" in text and "scope='independent-Q-cold-audit-worker-Source'" in text and "mathematical_acceptance=False" in text, 'Root-authored opinion requires Root actually whole-read code; constructor itself only hashes it and does not create mathematical authority')
check('three review slots and strict current maps', 'source_review=dict(ROOT=root_review_pin, worker_independent=pin(peer_path), auditor_independent=auditor_peer_pin)' in text and 'peer[\'scope\'] == \'independent-Q-cold-audit-worker-Source\' and peer[\'sources\'] == sources' in text, 'distinct author source review rows, same genuine arithmetic reviewer may be used for worker and prior auditor; no claim of two independent replay teams')
check('exact leaf11 fields and sorted closure', 'raw_closure=[closure[k] for k in sorted(closure)]' in text and 'assert set(leaf) == set(abi[\'fields\']) and len(leaf) == 11' in text, 'current reviewed contract supplies exact field names and cache/activation maps; executable worker independently rechecks its literals')
check('leaf final pin included in owner closure', 'collect(closure, leaf_pin)' in text, 'no circular owner-plan pin in leaf; owner closes leaf and full Source/input/runtime/review closure')
check('exact lexical generic-owner spelling', "return pin(record['path'], relative=True)" in text and "str(Path(sources['worker']['path']).relative_to(ROOT))" in text and "str((output / owned['receipt']).relative_to(ROOT))" in text, 'generic owner pin() uses ROOT-relative repository records; outside binary/resource remains absolute; leaf canonical ABS')
check('exact six argv/current command/receipt', "'ROOT-independent-complete-Q-mathematical-audit', str(leaf_path), str(owner_path)" in text and "DEST / 'worker-plan-v1.json', DEST / 'preparation-plan-v1.json'" in text and contract['owned_ABI']['receipt'] == 'Q-independent-audit-result-v1.json', 'flat anchoring matches HERE.parents[1] and worker same-parent preflight')
check('exact generic-owner10 fields and final unchanged closure', 'assert set(owner) == set(owned[\'fields\']) and len(owner) == 10 and len(argv) == 6' in text and 'for record in closure.values():\n        assert pin(record[\'path\']) == record' in text, 'no functional/scientific subprocess; metadata output raw pins checked after plan writes')
check('Root construction receipt false acceptance flags', 'actual_execution_accepted=False, mathematical_catalogue_admitted=False, target_proof_accepted=False' in text and 'metadata_execution_only=True, project_imports=0, scientific_calls=0' in text, 'metadata construction is not worker invocation, resource fit, admission or proof')

findings = dict(schema='independent-Q-audit-metadata-constructor-Source-findings-v1',
    author_identity='/root', reviewer_identity='/root/arithmetic_induction',
    scope='pure-stdlib-independent-Q-audit-metadata-constructor-Source',
    source_only=True, source_review_passed=True, all_checks_passed=True, scientific_calls=0,
    project_imports=0, constructor_executions=0, actual_plan_constructions=0,
    audited_Source_executions=0, mathematical_acceptance=False, resource_acceptance=False,
    source=pin(HELPER), source_contract=pin(PACKET/'source-contract-v1.json'),
    worker=sources['worker'], independent_auditor=sources['independent_auditor'],
    current_worker_Source_review=pin(PEER), current_auditor_Source_review=auditor_peer_record,
    complete_named_original_metadata_roots={role: inputs[role] for role in inputs if role not in raw_roles},
    original_owner_metadata=pin(old_owner_path), immutable_generic_owner=contract['owned_ABI']['owner'], immutable_generic_closer=contract['owned_ABI']['closer'],
    check_count=len(CHECKS), checks=CHECKS, raw_references=REFS,
    raw_reference_occurrences=len(REFS), distinct_raw_paths=len({r['actual']['path'] for r in REFS}),
    compile_only_files=1, whole_helper_read=True, mismatches=[], blockers=[], required_Source_repairs=[],
    earlier_producer_authorship_disclosed=True,
    independence_scope='Reviewer authored the earlier Q producer and reviewed the distinct-authored cold worker/auditor. This is a distinct-author static review of the Root metadata helper; no actual catalogue/domain/semantic/resource replay or math authority is issued.',
    scope_notes=[
        'Root-generated whole-read and positive Source review fields record Root opinion; the stdlib constructor does not itself semantically evaluate code or demonstrate those human inspections. Root must genuinely perform and own that review.',
        'The Root review prose about whole input seals refers to declaration/preparation/PRODUCER_SOURCES only. Plan/other metadata and witness pin dictionaries are authenticated raw prerequisites; the read-only comparator and final closure/reconciliation remain mandatory.',
        'The helper is applicable to the exact current contract and typed reviews inspected. It intentionally takes explicit contract/peer paths; subsequent profile/source changes require a genuine fresh review rather than inferred applicability.',
        'Every named raw reference in current inputs/contract/reviews and original producer worker/owner metadata matches. Raw leaf ancestors are hashed, not decoded; neither38MiB preparation nor8MiB witness files were parsed by this review or by constructor Source.',
        'No destination, actual leaf/owner plan, ROOT activation or scientific result was generated by the reviewer. The future constructor uses absent directory, exclusive JSON files and byte-identical owner/closer copies; partial metadata failure must be preserved, never converted into scientific success.',
        'Runtime fit is unmeasured. Full copied owner/closer, exact actual Source/input closure and same-handle terminal/caller observation are separate prerequisites for the once-only future audit.'
    ])
findings_pin = save('metadata-constructor-Source-findings-v1.json', findings)
typed_pin = save('metadata-constructor-typed-Source-review-v1.json', dict(
    schema='independent-Q-audit-metadata-constructor-Source-review-v1',
    scope=findings['scope'], author_identity='/root', reviewer_identity='/root/arithmetic_induction',
    source=pin(HELPER), source_contract=findings['source_contract'], worker=sources['worker'],
    independent_auditor=sources['independent_auditor'], source_only=True,
    source_review_passed=True, all_checks_passed=True, scientific_calls=0,
    constructor_executions=0, mathematical_acceptance=False, resource_acceptance=False,
    earlier_producer_authorship_disclosed=True, findings=findings_pin))
handoff_pin = save('handoff-v1.json', dict(
    schema='independent-Q-audit-metadata-constructor-review-handoff-v1', source_only=True,
    source_review_passed=True, all_checks_passed=True, scientific_calls=0,
    reviewed_author_identity='/root', reviewer_identity='/root/arithmetic_induction',
    source=pin(HELPER), typed_Source_review=typed_pin, findings=findings_pin,
    checks=len(CHECKS), raw_reference_occurrences=len(REFS), distinct_raw_paths=findings['distinct_raw_paths'],
    blockers=[], mismatches=[], constructor_executions=0, actual_plan_constructions=0,
    next='Root alone may construct fresh current plans; actual worker audit/resource admission remains a separate once-only stage.'))
integration_pin = save('integration-v1.json', dict(schema='private-Source-review-integration-v1',
    source_only=True, files=[pin(__file__),findings_pin,typed_pin,handoff_pin],
    project_or_semantic_calls=0, actual_plans_created=False))
print(json.dumps(dict(findings=findings_pin,typed_review=typed_pin,handoff=handoff_pin,
    integration=integration_pin,checks=len(CHECKS),raw_references=len(REFS),
    distinct_paths=findings['distinct_raw_paths'],constructor_executions=0),sort_keys=True))
