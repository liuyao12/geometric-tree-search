# Replay the Wang group benchmark

Run from the extracted archive root with CPython 3.12. The fetch step verifies the official TPTP v9.3.1 text against the archived SHA-256 pins. The checker requires Python assertions.

~~~sh
python3.12 -I -S -B external/source/fetch_tptp_v1.py
python3.12 -I -S -B external/source/group_markings_v1.py --check
python3.12 -I -S -B external/source/group_markings_v1.py
~~~

The first check replays the retained certificates against the original source. The search command retrains the marking bank from eligible donors, reruns all five search arms, and rewrites the evidence files. Search timings vary across hosts. The empty-bank preflight is retained as a separate data file.

Install `z3-solver==4.15.4.0` in a separate vendor directory and run the conventional control. The 10-second Z3 timeout can depend on the machine.

~~~sh
python3.12 -I -S -B external/source/group_markings_v1.py --z3 /path/to/vendor
python3.12 -I -S -B external/source/render_group_markings_v1.py
python3.12 -I -S -B external/source/package_group_markings_v1.py
~~~
