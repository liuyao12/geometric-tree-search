"""Pin the group cohort before evaluating any of the search variants."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / "source"))
from tptp_cnf_v1 import CNF, problem_text
from tptp_pilot_v1 import PROBLEMS, write

TRAINING = ("GRP003-2", "GRP004-2", "GRP005-1", "GRP006-1")
HELD_OUT = ("GRP007-1", "GRP008-1", "GRP010-1", "GRP012-2", "GRP013-1", "GRP014-1")


def main(raw):
    manifest = json.loads((HERE / "data/sources-v1.json").read_text())
    root = HERE / "input"
    axiom = "Axioms/GRP005-0.ax"
    additions = {f"{name}.p": f"Problems/GRP/{name}.p" for name in TRAINING + HELD_OUT}
    additions[axiom] = axiom
    for filename, url_path in additions.items():
        text = problem_text((raw / (Path(filename).stem + ".html")).read_text())
        if filename.endswith(".p"):
            assert "Status   : Unsatisfiable" in text, filename
        (root / filename).write_text(text)
        manifest[filename] = dict(sha256=sha256(text.encode()).hexdigest(),
            url=f"https://seetptp.tptp.org/file/TPTPWorld/TPTP/{url_path}")
    cases = {}
    for name in PROBLEMS + TRAINING + HELD_OUT:
        parser = CNF(root)
        parser.source(name + ".p")
        cases[name] = dict(clauses=len(parser.rows), sources=sorted(parser.files))
    write("sources-v1.json", manifest)
    write("cohort-v1.json", dict(
        training=TRAINING, held_out=HELD_OUT, development=PROBLEMS, cases=cases,
        rule="TPTP v9.3.1 GRP003 through GRP014 inclusive, official CNF unsatisfiable, "
             "one version per number (-2 if present, otherwise -1), exclude pilot GRP009; "
             "GRP011 absent; lowest four numbers train, remaining six held out."
    ))
    print("Pinned", len(manifest), "files and parsed", len(cases), "cases.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw", type=Path)
    main(parser.parse_args().raw)
