"""Build the group benchmark notebook from checked evidence."""
from html import escape
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / "publication"), str(ROOT / "source"), str(HERE / "source")]
from boundary_kernel_v1 import build
from group_markings_v1 import ARMS, read
from proof_views_v1 import clause, explanation, expression, formula, frame_window, math, symbol, tile_svg

STEM = "wang-group-search-controls-20261106-v1"
NAMES = dict(support="Goal support", subsumption="Subsumption", rigid="Rigid guard",
             learned="Learned marks", **{"rigid-learned": "Rigid and learned"})


def table(headers, rows):
    head = "".join(f'<th scope="col">{h}</th>' for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def marked_tree(term, marks, path=()):
    name = term if isinstance(term, str) else term[0]
    children = "" if isinstance(term, str) or len(term) == 1 else (
        "<ul>" + "".join(marked_tree(t, marks, (*path, i)) for i, t in enumerate(term[1:])) + "</ul>")
    return f'<li><span class="term {marks.get(path, "")}">{math(symbol(name))}</span>{children}</li>'


def mark_view(example):
    tag, *args = example["mark"]
    if tag == "rigid":
        path, = args
        marks = [{tuple(path): "clash"}, {tuple(path): "clash"}]
        caption = "The red symbols occupy the same address. Distinct rigid symbols cannot unify."
    else:
        side, p, q, tail = args
        marks = [{tuple(p): "alias", tuple(q): "alias"},
                 {tuple(p + tail): "clash", tuple(q + tail): "clash"}]
        if side:
            marks.reverse()
        caption = "The blue marks identify one repeated variable. The red symbols conflict in its two proposed images."
    trees = "".join(f'<div><strong>{label}</strong><ul>{marked_tree(t, m)}</ul></div>'
                    for label, t, m in zip(("Equation side", "Candidate subterm"),
                                           example["terms"], marks, strict=True))
    return f'<div class="witness"><div class="grid">{trees}</div><p>{caption}</p></div>'


def subsumption_view(sample):
    bindings = r",\quad ".join(symbol(v) + r"\mapsto " + expression(t)
                                for v, t in sample["bindings"].items())
    return table(("Earlier clause", "Substitution", "Substituted literals", "Discarded candidate"), [
        (math(clause(sample["pattern"])), math(bindings or r"\varnothing"),
         math(clause(sample["instance"])), math(clause(sample["candidate"])))])


def proof_table(lines, original=None, evidence=None):
    if original:
        premises = [r["label"] for r in original if r["role"] != "negated_conjecture"]
        denied = [r["label"] for r in original if r["role"] == "negated_conjecture"]

    def reading(line):
        if original and line["rule"] == "G" and line["source"].startswith("formula"):
            f, c = line["source"].split("-")
            i = int(f.removeprefix("formula")) - 1
            j = int(c.removeprefix("clause")) - 1
            line = {**line, "source": premises[i] if i < len(premises) else denied[j]}
        return explanation(line)

    rows = []
    for i, line in enumerate(lines, 1):
        row = (i, reading(line), math(clause(line["clause"])))
        if evidence:
            key = evidence["calls"][i - 1]["fragment"]
            record = evidence["records"][key]
            code = escape(record["prefix"] + "\n" + record["word"])
            row += (f"<details><summary>Tile record</summary><code>{code}</code></details>",)
        rows.append(row)
    return table(("Line", "Reading", "Formula", "Evidence") if evidence else
                 ("Line", "Reading", "Formula"), rows)


def tile_view(bundle):
    machine = build().compile()
    assert machine.digest() == bundle["machine_sha256"]
    key = bundle["calls"][-1]["fragment"]
    trace = bundle["traces"][key]
    frame = dict(prefix=trace["prefix"], word=trace["word"], padding=0, trace=trace["fragment"])
    time = trace["steps"] - 5
    window, first = frame_window(machine, frame, time, trace["head"])
    palette, squares = {}, []
    for j, row in enumerate(window):
        for i, tile in enumerate(row):
            n = palette.setdefault(tile, len(palette))
            squares.append(f'<use href="#wang-{n}" x="{36*i}" y="{36*j}"/>')
    defs = "".join(tile_svg(t, n) for t, n in palette.items())
    return (f'<figure><svg viewBox="0 0 324 180" role="img" aria-label="Five rows of fixed Wang squares">'
            f'<defs>{defs}</defs>{"".join(squares)}</svg><figcaption>Verifier transitions '
            f'{time+1:,} to {time+5:,}, tape columns {first:,} to {first+8:,}, '
            'for the empty clause in GRP008-1.</figcaption></figure>')


def result_cells(row):
    marks = row["counts"]
    status = {"PROVED": "Checked proof", "BOUNDED": "At a cap",
              "SATURATED_WITHOUT_REFUTATION": "Search exhausted"}[row["status"]]
    return (f'<strong>{status}</strong><br>{marks.get("offers", 0):,} offers<br>'
            f'{row["seconds"]:.3f} s')


def main():
    cohort, results, bank = (read(p) for p in ("cohort-v1.json", "group-mark-results-v1.json", "group-mark-bank-v1.json"))
    z3 = {r["id"]: r["status"] for r in read("group-z3-v1.json")}
    z3_proofs = sum(status == "unsat" for status in z3.values())
    manifest = read("sources-v1.json")
    indexed = {(r["id"], r["arm"]): r for r in results}
    assert len(indexed) == len(results) == (len(cohort["development"]) + len(cohort["held_out"])) * len(ARMS)
    counts = {a: sum(indexed[n, a]["status"] == "PROVED" for n in cohort["held_out"]) for a in ARMS}
    key = "GRP008-1"
    control, winner = indexed[key, "support"], indexed[key, "subsumption"]
    held = [r for r in results if r["id"] in cohort["held_out"]]
    learned = [r for r in held if r["arm"] == "learned"]
    learned_hits = sum(r["counts"].get("learned_skips", 0) for r in learned)
    rigid_only_hits = sum(r["counts"].get("rigid_skips", 0) for r in held if r["arm"] == "rigid")
    alias_hits = sum(r["counts"].get("learned_skips", 0) for r in held if r["arm"] == "rigid-learned")
    train_examples = [m for d in bank["donors"] for m in d["observations"] if m["mark"] in bank["marks"]]
    example = next((e for r in learned for e in r["examples"]), max(train_examples, key=lambda m: m["count"]))

    def comparison(group):
        rows = []
        for name in cohort[group]:
            url = manifest[name + ".p"]["url"]
            name_link = f'<a href="{escape(url, quote=True)}">{name}</a>'
            rows.append((name_link, *(result_cells(indexed[name, a]) for a in ARMS),
                         z3.get(name, "Prior pilot")))
        return table(("Problem", *(NAMES[a] for a in ARMS), "Z3"), rows)

    proofs = []
    for name in cohort["held_out"]:
        proved = next((a for a in ARMS if indexed[name, a]["status"] == "PROVED"), None)
        if not proved:
            continue
        direct = read(f"{name}-{proved}-direct-v1.json")
        evidence = read(f"{name}-{proved}-logical-v1.json")
        proof = evidence["proof"]["lines"]
        assert not proof[-1]["clause"]
        goal = (r"\mathrm{q}(\mathrm{identity})" if name == key else formula(direct["source"]["goal"]))
        main_open = " open" if name == key else ""
        explanation_text = ("<p>The group axioms and the three clauses constraining "
                            + math(r"\mathrm{q}") + " imply that the identity satisfies "
                            + math(r"\mathrm{q}") + ".</p>") if name == key else ""
        proofs.append(f'<article id="proof-{name}"><h3>{name} · {NAMES[proved]}</h3>'
                      f'<p>Goal {math(goal)}</p>{explanation_text}'
                      f'<details{main_open}><summary>Direct derivation · {len(direct["lines"])} lines</summary>'
                      f'{proof_table(direct["lines"], direct["clauses"])}</details>'
                      f'<details><summary>Checked Wang records · {len(proof)} lines</summary>'
                      f'{proof_table(proof, evidence=evidence)}</details></article>')
    baseline_offers, winning_offers = (r["counts"]["offers"] for r in (control, winner))
    bars = "".join(f'<div><strong>{name}</strong><meter aria-label="{name} inference offers" '
                   f'max="{baseline_offers}" value="{count}">{count:,}</meter> {count:,}</div>'
                   for name, count in (("Goal support", baseline_offers), ("Subsumption", winning_offers)))
    count_cards = "".join(f'<div><strong>{NAMES[a]}</strong>{counts[a]} of {len(cohort["held_out"])} checked</div>'
                          for a in ARMS)
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", "Wang proof search on held-out group problems")
    html = f"""{head}<body><main>
<header><p class="kicker">GCTS research notebook · 6 November 2026 UTC</p>
<h1>Wang proof search on held-out group problems</h1>
<p>Forward subsumption produced {counts['subsumption']} checked proofs across six TPTP problems. The goal-support baseline produced {counts['support']}. Address markings were tested separately with the same proof checker.</p>
<nav><a href="#results">Results</a><a href="#subsumption">Subsumption witness</a><a href="#marks">Markings</a><a href="#proofs">Proofs</a><a href="#tiles">Wang squares</a><a href="#replay">Replay</a></nav></header>
<section id="results"><h2>Compare the searches</h2>
<div class="flows">{count_cards}</div>
<p>The six held-out problems were selected by their TPTP group numbers before evaluation. The four planned training problems yielded zero native rewrite pairs. The donor pool was extended to the earlier five pilot problems, which were already development cases. The held-out set stayed fixed.</p>
<p>Each native run uses goal support, a cap of 120,000 admitted inference offers, 30,000 stored clauses and 600,000 raw indexed rewrite pairs that pass the goal-support filter. A counter can include the attempt that reaches its cap. Times cover one search run per arm and exclude proof verification. Z3 4.15.4 refuted {z3_proofs} of {len(z3)} inputs under its ten-second timeout.</p>
{comparison("held_out")}
<details><summary>Earlier pilot problems used for development</summary>{comparison("development")}</details>
<p><a href="https://tptp-manual.tptp.org/home">TPTP Problem Library manual</a></p></section>
<section id="subsumption"><h2>Why the search could discard a clause</h2>
<p>If the instantiated literals of an earlier clause are a subset of a candidate's literals, the earlier clause entails the candidate. The search indexes earlier clauses by a signed predicate and a rigid term address. It tests up to 48 donors of at most two literals per candidate. A goal-supported candidate requires a goal-supported donor. The matcher checks every deletion's substitution, sorts and literal inclusion.</p>
<div class="witness">{bars}</div>
<p>On GRP008-1, goal support reached {control['node_count']:,} stored clauses. Forward subsumption discarded {winner['counts']['forward_subsumed']:,} candidates, stored {winner['node_count']:,} clauses and found a proof.</p>
{subsumption_view(winner["subsumption_example"])}
<p>Forward subsumption is an established search method. This comparison measures what it contributes inside the Wang proof pipeline. <a href="https://pure.mpg.de/view/item_1330651">Bachmair and Ganzinger, Resolution Theorem Proving</a></p></section>
<section id="marks"><h2>What the learned markings skip</h2>
<p>The donor failures identify reusable term addresses. Up to twelve markings are retained in frequency order. The rigid control recursively checks matching addresses for conflicting symbols. The combined arm uses that check followed by learned repeated-variable markings. These checks take place before charging an admitted rewrite offer.</p>
{mark_view(example)}
<p>On the six held-out cases, the learned arm skipped {learned_hits:,} rewrites and the rigid control skipped {rigid_only_hits:,}. The combined arm skipped {alias_hits:,} additional pairs with learned repeated-variable markings after the rigid check. A separately scoped unifier also confirmed one recorded failed pair for every mark observed in each run.</p>
</section>
<section id="proofs"><h2>Read the machine-discovered proofs</h2>
<p>The direct clauses are rendered line by line. The checked record view expands each used premise into the source-bound Wang format, with the decoded clause and its raw boundary record.</p>
{"".join(proofs)}</section>
<section id="tiles"><h2>Inspect the Wang squares</h2>
<div class="grid">{tile_view(read("GRP008-1-subsumption-wang-v1.json"))}
<p>The square orientations are fixed. Colors encode exact edge labels, and an outlined square carries the verifier head. The five-row window shows the final proof record. The full witness compresses {winner["full_wang"]["implied_steps"]:,} verifier transitions across its record calls. The archive also includes the compact record proof, which the logical checker verifies directly.</p></div></section>
<section id="replay"><h2>Reproduce the result</h2>
<p><a href="{STEM}-evidence.zip">Evidence and replay scripts</a> · <a href="{STEM}-results.json">Machine-readable results</a> · <a href="{STEM}-manifest.json">File hashes</a></p>
<p>The archive pins the upstream TPTP inputs and includes solver inputs, proof certificates and receipts. Follow <code>external/REPLAY.md</code> to rerun search and verification.</p>
</section></main></body></html>"""
    (ROOT / "report" / (STEM + ".html")).write_text(html)
    summary = dict(cohort=cohort, held_out_proofs=counts, results=results, z3=z3, bank=bank)
    (ROOT / "report" / (STEM + "-results.json")).write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
