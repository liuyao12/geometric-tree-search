"""Archive the checked group results, certificates and replay sources."""
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[2]
STEM = "wang-group-search-controls-20261106-v1"


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    read = lambda name: json.loads((ROOT / "external/data" / name).read_text())
    study = read("group-mark-results-v1.json")
    data = ["cohort-v1.json", "sources-v1.json", "group-empty-bank-preflight-v1.json",
            "group-mark-results-v1.json", "group-mark-bank-v1.json", "group-z3-v1.json",
            "group-z3-inputs-v1.json"]
    for row in study:
        if row["status"] == "PROVED":
            label = f"{row['id']}-{row['arm']}"
            data.extend(f"{label}-{suffix}-v1.json" for suffix in ("direct", "logical"))
            if "full_wang" in row:
                data.append(f"{label}-wang-v1.json")
    driver_names = ("fetch_tptp_v1", "tptp_cnf_v1", "tptp_pilot_v1", "tptp_transport_v1",
                    "freeze_group_cohort_v1", "subsumption_v1", "group_markings_v1",
                    "render_group_markings_v1", "package_group_markings_v1")
    scripts = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "source").glob("*.py"))
    paths = [*scripts, *(f"external/source/{name}.py" for name in driver_names),
             *(f"external/data/{name}" for name in data), "external/REPLAY.md",
             "publication/group-notebook-head-v1.html", "publication/proof_views_v1.py",
             f"report/{STEM}.html", f"report/{STEM}-results.json"]
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in paths:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            assert not re.search(rb"(?:github_pat_|ghp_)[A-Za-z0-9_]{25,}", raw), name
            manifest[name] = pin(raw)
            entry = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            entry.external_attr = 0o100644 << 16
            bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    files = [archive, ROOT / f"report/{STEM}.html", ROOT / f"report/{STEM}-results.json"]
    value = dict(schema="WANG-GROUP-CONTROLS-MANIFEST-v1", archive_entries=manifest,
                 assets={p.name: pin(p.read_bytes()) for p in files})
    (ROOT / f"report/{STEM}-manifest.json").write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
