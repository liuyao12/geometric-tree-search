"""Render source formulas, checked proof lines and actual Wang windows."""
from html import escape
from pathlib import Path
from statistics import median
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(ROOT/"publication"))
from boundary_kernel_v1 import build
from proof_views_v1 import clause, explanation, formula, frame_window, math, tile_svg


def read(path):
    return json.loads((ROOT/path).read_text())


def label(name):
    names={"hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
           "hilbert-incidence-transfer":"Hilbert incidence transfer"}
    return names.get(name,name.replace("peano","Peano",1).replace("-"," "))


def table(headers,rows):
    heads="".join(f'<th scope="col">{h}</th>' for h in headers)
    body="".join("<tr>"+"".join(f"<td>{cell}</td>" for cell in row)+"</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{heads}</tr></thead><tbody>{body}</tbody></table></div>'


def status(value):
    return value.replace("_"," ").lower()


def proof_view(row, bundle, full):
    source=row["source"]
    name=row["id"]
    hypotheses="<ol>"+"".join(f"<li>{math(formula(x))}</li>" for x in source["premises"])+"</ol>"
    lines=[]
    for i,(line,call) in enumerate(zip(bundle["proof"]["lines"],bundle["calls"],strict=True),1):
        record=bundle["records"][call["fragment"]]
        data=escape(record["prefix"]+"\n"+record["word"])
        show=(f'<button type="button" data-case="{name}" data-line="{i}">See tiles</button>' if full else "")
        detail=f'{show}<details><summary>Boundary record</summary><code>{data}</code></details>'
        lines.append((i,explanation(line),math(clause(line["clause"])),detail))
    return (f'<details class="proof" id="{name}"><summary>{label(name)} · {len(lines)} lines</summary>'
            f'<p>Goal {math(formula(source["goal"]))}</p><details><summary>Original premises</summary>'
            f'{hypotheses}</details>{table(("Line","Reading","Clause","Evidence"),lines)}</details>')


def windows(bundle,machine,palette):
    assert bundle["machine_sha256"]==machine.digest()
    result=[]
    for call in bundle["calls"]:
        trace=bundle["traces"][call["fragment"]]
        frame=dict(prefix=trace["prefix"],word=trace["word"],padding=0,trace=trace["fragment"])
        time=trace["steps"]-5
        active,first=frame_window(machine,frame,time,trace["head"])
        tiles=[palette.setdefault(t,len(palette)) for row in active for t in row]
        result.append((tiles,f"Actual Wang rows {time+1:,}–{time+5:,}, columns {first:,}–{first+8:,}."))
    return result


def main():
    suite=read("data/equality-experiment-v1.json")["cases"]
    z3={r["id"]:r for r in read("data/z3-control-v1.json")["cases"]}
    timing=read("data/equality-timing-v1.json")["measurements"]
    summary, times, proofs, models = [], [], [], []
    palette, tiles = {}, {}
    machine=build().compile()
    for row in suite:
        name=row["id"]
        stats=row["on_demand"]["counts"]
        summary.append((label(name),stats.get("terms","—"),stats.get("checked_groundings","—"),
             status(row["on_demand"]["status"]),status(row["eager"]["status"]),status(row["eager_generous"]["status"]),
             z3[name]["source"]["status"],stats.get("proof_records","—")))
        times.append((label(name),*(f'{median(timing[name][key])/1e6:.2f}' if key in timing[name] else "—"
            for key in ("on_demand","z3_source","compact_check"))))
        if "receipt" not in row:
            model=escape(json.dumps(row["countermodel"],indent=2))
            models.append(f'<details><summary>{label(name)} finite model</summary><pre><code>{model}</code></pre></details>')
            continue
        bundle=read(f"data/{name}-logical-v1.json")
        full="full_wang" in row
        if full:
            tiles[name]=windows(read(f"data/{name}-wang-v1.json"),machine,palette)
        proofs.append(proof_view(row,bundle,full))
    unseen=read("input/peano-add-six-unseen-v1.json")
    proofs.append(proof_view(dict(source=unseen,id=unseen["id"]),read("data/peano-add-six-cli-v1.json"),False))
    fields=dict(SUMMARY=table(("Request","Terms","Ordinary groundings tried","On demand",
                       "Eager","Larger eager","Z3 original","Checked lines"),summary),
           TIMING=table(("Request","On-demand ms","Z3 original ms","Compact check ms"),times),
           PROOFS="".join(proofs), MODELS="".join(models),
           TILE_DEFS="".join(tile_svg(t,n) for t,n in palette.items()),
           TILE_CASES="".join(f'<option value="{name}">{label(name)}</option>' for name in tiles),
           TILE_DATA=json.dumps(tiles,separators=(",",":")))
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for name,value in fields.items():
        html=html.replace(f"%%{name}%%",value)
    assert "%%" not in html
    (ROOT/"report/wang-equality-closure-20261106-v1.html").write_text(html)


if __name__=="__main__":
    main()
