const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

async function main() {
  const {chromium} = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"]});
  try {
    const page = await browser.newPage({viewport: {width: 1120, height: 900}});
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-equality-closure-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil:"commit"});
    if (process.argv[2]) assert.equal(response.status(), 200);
    assert.equal(await page.locator("#comparison tbody tr").count(), 30);
    assert.equal(await page.locator("#comparison details").count(), 3);
    assert.equal(await page.locator("#proof .proof").count(), 13);
    await page.locator("#hilbert-incidence-transfer>summary").click();
    await page.waitForSelector("#hilbert-incidence-transfer mjx-container");
    assert.equal(await page.locator("#hilbert-incidence-transfer tbody tr:visible").count(), 86);
    await page.locator('button[data-case="hilbert-incidence-transfer"][data-line="1"]').click();
    assert.equal(await page.locator("#selection").textContent(), "Proof line 1");
    assert.equal(await page.locator("#tile-view svg use").count(), 45);
    await page.locator("#case").selectOption("peano-add-successors-4");
    assert.equal(await page.locator("#selection").textContent(), "Proof line 66");
    assert.equal(await page.locator("#tile-view svg use title").count(), 45);
    assert.equal(await page.locator("#replay a").count(), 4);
    if (!process.argv[2]) await page.locator("#tiles").screenshot({path:path.join(__dirname,"equality-wang-view-v1.png")});
    await page.setViewportSize({width:390,height:844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const result = {status:"CHECKED_EQUALITY_READER", proofs:13, fullWitnesses:3,
      countermodels:3, wangSquares:45, mathTypeset:true, mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(result,null,2)+"\n");
    console.log(JSON.stringify(result));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode=1; });
