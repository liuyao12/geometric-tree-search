"""Rebuild the checked proofs and notebook in an empty directory."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
STEM="wang-equality-closure-20261106-v1"
STAGES=("source/equality_experiment_v1.py","source/equality_audit_v1.py",
        "source/equality_cli_audit_v1.py","publication/render_v1.py")
FULL=("peano-nonzero-3","hilbert-incidence-transfer","peano-add-successors-4")
LOGICAL=tuple(f"peano-{mode}-{n}" for mode in ("congruence","cancel") for n in (2,4,7))+(
    "peano-nonzero-3","hilbert-incidence-uniqueness","hilbert-incidence-transfer",
    *(f"peano-add-successors-{n}" for n in (2,4,7)))
OUTPUTS=tuple(f"data/{n}-logical-v1.json" for n in LOGICAL)+tuple(f"data/{n}-wang-v1.json" for n in FULL)+(
    "data/equality-experiment-v1.json","data/equality-audit-v1.json",
    "input/peano-add-six-unseen-v1.json","input/hilbert-control-cli-v1.json",
    "data/peano-add-six-cli-v1.json","data/equality-cli-audit-v1.json",
    f"report/{STEM}.html")


def inputs():
    sources=sorted(str(p.relative_to(ROOT)) for d in ("source","publication") for p in (ROOT/d).glob("*.py"))
    return (*sources,"publication/notebook-v1.html","input/archived-cases-v1.json",
            "data/z3-control-v1.json","data/z3-inputs-v1.json","data/equality-timing-v1.json")


def main():
    retained=inputs()
    hashes={}
    with TemporaryDirectory() as temporary:
        clean=Path(temporary)
        for path in (*retained,*OUTPUTS):
            (clean/path).parent.mkdir(parents=True,exist_ok=True)
        for path in retained:
            shutil.copyfile(ROOT/path,clean/path)
        for stage in STAGES:
            subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=clean,check=True)
        for path in OUTPUTS:
            expected,actual=(ROOT/path).read_bytes(),(clean/path).read_bytes()
            assert actual==expected,path
            hashes[path]=sha256(actual).hexdigest()
    receipt=dict(status="CHECKED_CLEAN_REPLAY",sha256=hashes)
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print("Matched",len(hashes),"outputs byte for byte.")


if __name__=="__main__":
    main()
