"""Render typed premise joins, the searched bridge and every inventory proof."""
from html import escape
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from conditional_families_v1 import clause_put
from copy_ports_v1 import freeze
from copy_views_v1 import case
from proof_views_v1 import clause, expression, formula, math, tile_svg

NAME = "wang-hilbert-receptors-20261106-v1"
TITLE = "Join several hypotheses and grow a geometry inventory"
LABEL = {"baseline":"Original search", "requests":"Propagation and premise requests",
         "incidence":"Requests and incidence family", "inventory":"Two-family inventory",
         "inventory-learned-47":"Inventory and frozen learned schedule",
         "incidence-only":"Incidence family alone", "propagation-only":"Compiled propagation alone"}


def read(name):
    path = ROOT / name
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes())


def case_label(name):
    parts=name.split('-')
    if name.startswith('incidence-chain-'):
        return f'Incidence chain, {parts[2]} links, {parts[4]} irrelevant facts'
    if name.startswith('order-chain-'):
        return f'Betweenness chain, {parts[2]} links' + (', reversed endpoints' if parts[4]=='1' else '')
    if name.startswith('mixed-line-and-order-'):
        return f'Mixed incidence/order, {parts[-1]} order links'
    return 'Development: betweenness on a chosen line'


def pretty(f):
    counters = {"Point":0, "Line":0}
    names = {"Point":("?p","?q","?r"), "Line":(("ell",),("m",))}
    env = {}
    def visit(t):
        if isinstance(t,str):
            if t not in env:
                sort=f["variables"][t]
                env[t]=names[sort][counters[sort]]
                counters[sort]+=1
        else:
            for c in t[1:]: visit(c)
    for port in f["ports"]: visit(port[0][1])
    return env


def inventory_html(bank):
    out=[]
    for f in bank:
        env=pretty(f)
        inputs="".join('<li>'+math(clause(clause_put(p,env)))+'</li>' for p in f["ports"])
        title="Incidence uniqueness" if f["id"]=="incidence-uniqueness" else "Betweenness on a chosen line"
        output=math(clause(clause_put(f["out"],env)))
        out.append(f'<article class="family"><h3>{title}</h3><div class="port"><strong>All premise receptors</strong>'
                   f'<ul>{inputs}</ul></div><div class="compose">{len(f["recipe"])-len(f["ports"])} primitive '
                   f'grounding or resolution records in the recipe</div><div class="out formula">'
                   f'<strong>Output receptor</strong>{output}</div></article>')
    return "".join(out)


def attachments(row, families, arm="inventory"):
    run=freeze(row["runs"][arm])
    proof=run["proof"]
    entries=[]
    def line_for(value):
        return next(i for i,r in enumerate(proof,1) if set(r["clause"])==set(value))
    for use in run["attachments"]:
        if use["family"] not in families: continue
        family=families[use["family"]]
        ports=[]
        for port in family["ports"]:
            value=clause_put(port,use["bindings"])
            at=line_for(value)
            ports.append(f'<li><div class="formula">{math(clause(value))}</div>'
                         f'<button class="jump" data-line="{at}">Premise at line {at}</button></li>')
        at=line_for(use["clause"])
        entries.append(f'<article class="attachment"><h4>{escape(family["id"])}</h4>'
                       f'<ul class="ports">{"".join(ports)}</ul><div class="out formula">'
                       f'{math(clause(use["clause"]))}</div><button class="jump" data-line="{at}">'
                       f'Read output at line {at}</button></article>')
    return '<details class="attachments" open><summary>Learned families used by this proof</summary>'+"".join(entries)+'</details>'


def main():
    data=read("data/hilbert-join-study-v1.json")
    native=read("data/hilbert-join-diagrams-v1.json.gz")
    held=[r for r in data["rows"] if r["split"]=="held-out" and not r["countermodel"]]
    summary=[]
    for a in data["arms"]:
        runs=[r["runs"][a] for r in held]
        values=[sum(r["status"]=="PROVED" for r in runs)]
        values.extend(sum(r["counts"].get(k,0) for r in runs) for k in
                      ("resolutions","join_probes","premise_requests","cluster_steps"))
        summary.append(f'<tr><th>{LABEL[a]}</th>'+"".join(f'<td>{v:,}</td>' for v in values)+'</tr>')
    development=data["rows"][0]
    bridge=[]
    for a in ("baseline","incidence-only","propagation-only","requests","incidence"):
        r=development["runs"][a]
        status="Proved" if r["status"]=="PROVED" else "Open at "+r["stop"].replace("_"," ")+" limit"
        bridge.append(f'<tr><th>{LABEL[a]}</th><td>{status}</td><td>{r["counts"]["resolutions"]:,}</td></tr>')
    families={f["id"]:f for f in data["inventory"]}
    types,views,options,details,verification={ },[],[],[],[]
    for row in [development,*held]:
        name=row["original"]["id"]
        arm="incidence" if row is development else "inventory"
        result=row["runs"][arm]
        expanded=native["proofs"][native["calls"][name+"/"+arm]]
        view=case(dict(row,proof=expanded["proof"],diagram=expanded["diagram"]),native["bank"],types)
        view=view.replace('<div class="line-slot">',attachments(row,families,arm)+'<div class="line-slot">')
        views.append(view)
        options.append(f'<option value="{name}"{" selected" if name=="mixed-line-and-order-1" else ""}>{case_label(name)}</option>')
        if row is development: continue
        cells=[]
        for a in ("baseline","requests","incidence","inventory"):
            r=row["runs"][a]
            label=f'{r["counts"]["resolutions"]:,}' if r["status"]=="PROVED" else 'Open'
            title='Proved' if r["status"]=="PROVED" else 'Limit: '+r["stop"]
            cells.append(f'<td title="{title}">{label}</td>')
        details.append(f'<tr><th title="{name}">{case_label(name)}</th>'+"".join(cells)+f'<td>{len(result["proof"])}</td></tr>')
        rc=expanded["receipt"]
        verification.append(f'<tr><th title="{name}">{case_label(name)}</th><td>{rc["steps_without_reuse"]:,}</td>'
                            f'<td>{rc["marks"]:,}</td><td>{rc["glyph_equalities"]:,}</td></tr>')
    flat=sum(r["flat"]["counts"].get("join_probes",0) for r in held)
    indexed=sum(r["runs"]["inventory"]["counts"].get("join_probes",0) for r in held)
    lookups=sum(r["runs"]["inventory"]["counts"].get("argument_lookups",0) for r in held)
    values=dict(title=TITLE,stem=NAME,families=inventory_html(data["inventory"]),bridge="".join(bridge),
                summary="".join(summary),cases="".join(views),options="".join(options),details="".join(details),
                verification="".join(verification),flat=f'{flat:,}',indexed=f'{indexed:,}',lookups=f'{lookups:,}',
                runs=str(native["successful_runs"]),distinct=str(native["distinct_proofs"]),
                inventory=data["inventory_sha256"],script=(ROOT/"publication/reader_v1.js").read_text(),
                palette='<svg class="palette" width="0" height="0" aria-hidden="true"><defs>'
                        +"".join(tile_svg(t,i) for t,i in types.items())+'</defs></svg>')
    head=(ROOT/"publication/group-notebook-head-v1.html").read_text().replace("Lifted equality search for Wang proofs",TITLE)
    head=head.replace('</style>',(ROOT/"publication/style-v1.css").read_text()+'\n</style>')
    body=(ROOT/"publication/hilbert-body-v1.html").read_text()
    for k,v in values.items(): body=body.replace('%%'+k.upper()+'%%',v)
    assert '%%' not in body
    (ROOT/"report"/(NAME+'.html')).write_text(head+body)


if __name__=="__main__":
    main()
