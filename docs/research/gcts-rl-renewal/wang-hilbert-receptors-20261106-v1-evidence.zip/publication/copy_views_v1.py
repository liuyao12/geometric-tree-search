"""Decode copied clauses and display actual Wang squares in a proof reader."""
from html import escape
from copy_ports_v1 import fingerprint, freeze
from herbrand_v1 import signature
from proof_views_v1 import clause, explanation, formula, math, tile_svg
from study_v1 import guarded

EXAMPLE = "mixed-line-and-order-1"

def glyphs(diagram, port):
    x, y = port["origin"]
    if y == 0:
        text = diagram["source"]
    else:
        strip, = (s for s in diagram["strips"] if s["origin"][1] == y)
        text = strip["prefix"] + strip["word"] + "$"
    start = (x - 1) // port["stride"]
    return text[start:start + port["glyphs"]]


def ribbon(diagram, marking, layer):
    source, target = (marking[k] for k in ("source", "target"))
    text = glyphs(diagram, source)
    assert text == glyphs(diagram, target)
    preview = text[:16]
    width = max(160, 16 * len(preview))
    shapes = []
    for i, char in enumerate(preview):
        x = 16 * i
        shapes.append(f'<path d="M{x+8} 20 L{x+8} 40" class="copy-line"/>')
        for y in (1, 41):
            shapes.append(f'<rect x="{x}" y="{y}" width="16" height="19" class="glyph"/>'
                          f'<text x="{x+8}" y="{y+14}" text-anchor="middle">{escape(char)}</text>')
    origin = source["origin"]
    dest = target["origin"]
    title = (f'Copy {len(text)} symbols from column {origin[0]} on row {origin[1]} '
             f'to column {dest[0]} on row {dest[1]}, with stride {source["stride"]}.')
    return (f'<div class="ribbon {layer}"><svg viewBox="0 0 {width} 62" role="img" aria-label="{title}">'
            f'<title>{title}</title>{"".join(shapes)}</svg>'
            f'<p>{len(text)} equal symbols, including the terminating delimiter. '
            f'Preview shows {len(preview)}.</p><details><summary>Read the complete copied text</summary>'
            f'<pre><code>{escape(text)}</code></pre></details></div>')


def tiles(receipt, types):
    point = receipt["checkpoints"][-1]
    out = []
    for i, tile in enumerate(freeze(point["row"])):
        j = types.setdefault(tile, len(types))
        out.append(f'<use href="#wang-{j}" x="{i*36}"/>')
    return (f'<figure><svg viewBox="0 0 324 36" role="img" aria-label="Nine actual local Wang squares">'
            f'{"".join(out)}</svg><figcaption>Local verifier row {point["step"] + 1:,}. '
            f'Hover over a square for its exact edge labels.</figcaption></figure>')


def case(row, bank, types):
    diagram = row["diagram"]
    original, proof = row["original"], row["proof"]
    functions, _, schemata = signature(row["normal"])
    sources, _ = guarded(schemata, functions, row["normal"]["sorts"])
    mark_at = 0
    lines = []
    for i, (line, strip) in enumerate(zip(proof, diagram["strips"], strict=True), 1):
        copies = []
        for parent in strip["parents"]:
            layer, identity = parent
            if layer == "source":
                label = "Source clause " + diagram["schema_ids"][identity]
                value = sources[diagram["schema_ids"][identity]]["clause"]
                style = "source-copy"
                heading = escape(label)
            else:
                label = f"Earlier proof line {identity + 1}"
                value = proof[identity]["clause"]
                style = "parent-copy"
                heading = f'<button class="jump" data-line="{identity+1}">{label}</button>'
            marking = diagram["marks"][mark_at]
            mark_at += 1
            copies.append(f'<div class="copied"><h4>{heading}</h4><div class="formula">{math(clause(value))}</div>'
                          + ribbon(diagram, marking, style) + "</div>")
        local = bank[fingerprint(strip)]
        key = original["id"]
        lines.append(f'<template class="line-template" data-line="{i}"><article class="line"><h3>Line {i} of {len(proof)}</h3>'
                     f'<div class="formula">{math(clause(line["clause"]))}</div><p>{explanation(line)}</p>'
                     f'<div class="grid">{"".join(copies)}</div>'
                     f'<details class="native"><summary>Inspect this inference’s Wang squares</summary>'
                     f'<p>The local rectangle stops at the fixed verification checkpoint after {strip["records"]} '
                     f'records and {local["steps"]:,} tape steps.</p>{tiles(local, types)}'
                     f'<pre><code>{escape(strip["prefix"])}\n{escape(strip["word"])}</code></pre></details></article></template>')
    assert mark_at == len(diagram["marks"])
    sources_html = "".join(f'<li>{math(formula(p))}</li>' for p in original["premises"])
    hidden = "" if original["id"] == EXAMPLE else " hidden"
    return (f'<div class="case" data-case="{original["id"]}" data-lines="{len(proof)}"{hidden}>'
            f'<details class="hypotheses"><summary>Read the hypotheses and conclusion</summary>'
            f'<ul class="formula">{sources_html}</ul><p class="formula">{math(formula(original["goal"]))}</p>'
            f'</details><div class="line-slot"></div>{"".join(lines)}</div>')


