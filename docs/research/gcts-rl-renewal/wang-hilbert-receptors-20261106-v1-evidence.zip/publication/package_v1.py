"""Package deterministic search evidence, proof receipts and the reader."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
NAME = "wang-hilbert-receptors-20261106-v1"
README = """Hilbert proof families with several typed premise receptors

Use Python 3.12 with assertions enabled, from the archive root:

  python3 -I -S -B source/hilbert_join_study_v1.py
  python3 -I -S -B source/hilbert_join_controls_v1.py
  python3 -I -S -B source/hilbert_join_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command extracts the incidence family from the prior donor,
repeats the bridge search, freezes the new two-family inventory, and
runs all transfer cases and finite countermodels. The second rejects
six damaged recipes. The third replays all distinct successful marked
Wang proofs. The final command regenerates the visual reader.
The learned unit scheduler is frozen from the earlier donor experiment.
It is not retrained here. The manifest gives file hashes.
"""


def contents():
    for d in ("source", "wang/source", "wang/external/source"):
        yield from (ROOT / d).glob("*.py")
    yield from (ROOT / "input").glob("*")
    yield ROOT / "data/hilbert-join-diagrams-v1.json.gz"
    yield ROOT / "data/hilbert-join-study-v1.json"
    yield ROOT / "data/hilbert-join-controls-v1.json"
    for n in ("render_v1.py", "proof_views_v1.py", "copy_views_v1.py", "group-notebook-head-v1.html",
              "hilbert-body-v1.html", "reader_v1.js", "style-v1.css", "check_browser_v1.cjs", "package_v1.py"):
        yield ROOT / "publication" / n
    yield ROOT / "report" / (NAME+".html")


def write(zipfile, name, data):
    item = ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
    item.external_attr = 0o100644 << 16
    zipfile.writestr(item, data, ZIP_DEFLATED, 6)


def main():
    target = ROOT / "report" / (NAME+"-evidence.zip")
    manifest = {}
    with ZipFile(target, "w") as archive:
        for path in sorted(contents()):
            name = path.relative_to(ROOT).as_posix()
            body = path.read_bytes()
            write(archive, name, body)
            manifest[name] = sha256(body).hexdigest()
        write(archive, "README.txt", README.encode())
        manifest["README.txt"] = sha256(README.encode()).hexdigest()
        write(archive, "MANIFEST.json", (json.dumps(manifest, sort_keys=True)+"\n").encode())
    print(target.name, target.stat().st_size, sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
