"""Join several signed, typed premise receptors before expanding a proof family."""
from collections import defaultdict, deque

from conditional_families_v1 import clause_put, schema_key, variables
from copy_ports_v1 import freeze
from fair_search_v1 import bind
from herbrand_v1 import inspect_term
from persistent_equality_v1 import Enhanced
from study_v1 import substitute


class MultiSearch(Enhanced):
    def __init__(self, normal, goal, limits, bank, weights=(), indexed=True, demand=False):
        self.bank = freeze(bank)
        self.queue, self.queued = deque(), set()
        self.by_literal = defaultdict(list)
        self.by_argument = defaultdict(list)
        self.applied, self.attachments = set(), []
        self.indexed = indexed
        self.use_demand = demand
        self.needs, self.requested = deque(), set()
        super().__init__(normal, goal, "learned" if weights else "fifo", limits, 47 if weights else 0,
                         weights, True, True)
        schemas = {schema_key(s): s["id"] for s in self.schemas.values()}
        self.sources = {f["id"]: {k: schemas.get(schema_key(v)) for k, v in f["sources"].items()} for f in self.bank}
        self.bank = [f for f in self.bank if all(self.sources[f["id"]].values())]
        self.heads = defaultdict(list)
        for source in self.schemas.values():
            if source["id"].startswith("formula"):
                for sign, atom in source["clause"]:
                    self.heads[sign, atom[0]].append((source, atom))

    def observe(self, i):
        super().observe(i)
        clause = self.rows[i][0]
        if len(clause) == 1 and i not in self.queued:
            self.queued.add(i)
            self.queue.append(i)
            (sign, atom), = clause
            self.by_literal[sign, atom[0]].append(i)
            for j, arg in enumerate(atom[1:], 1):
                self.by_argument[sign, atom[0], j, arg].append(i)

    def candidates(self, literal, env):
        sign, atom = literal
        values = self.by_literal[sign, atom[0]]
        self.work["join_queries"] += 1
        if self.indexed:
            choices = []
            for j, arg in enumerate(atom[1:], 1):
                if variables(arg) <= env.keys():
                    value = substitute(arg, env)
                    choices.append(self.by_argument[sign, atom[0], j, value])
                    self.work["argument_lookups"] += 1
            if choices:
                values = min(choices, key=len)
        return tuple(values)

    def joins(self, family, remaining, env, parents):
        if not remaining:
            yield env, parents
            return
        slot = min(remaining, key=lambda j: (len(variables(family["ports"][j][0][1]) - env.keys()), j))
        sign, pattern = family["ports"][slot][0]
        matched = False
        for i in self.candidates((sign, pattern), env):
            self.charge("join_probes")
            (actual_sign, atom), = self.rows[i][0]
            assert actual_sign == sign
            bound = env.copy()
            if bind(pattern, atom, bound):
                matched = True
                yield from self.joins(family, remaining - {slot}, bound, {**parents, slot: i})
        if not matched and self.use_demand and variables(pattern) <= env.keys():
            self.request(sign, substitute(pattern, env))

    def request(self, sign, atom):
        key = sign, atom
        if key not in self.requested and key not in self.unit_ids:
            self.charge("premise_requests")
            self.requested.add(key)
            self.needs.append(key)

    def demand_pass(self):
        if not self.use_demand:
            return
        for _ in range(64):
            if not self.needs:
                return
            sign, atom = self.needs.popleft()
            if (sign, atom) in self.unit_ids:
                continue
            for schema, pattern in self.heads[sign, atom[0]]:
                self.charge("premise_probes")
                env = {}
                if not bind(pattern, atom, env) or set(env) != set(schema["variables"]):
                    continue
                from study_v1 import grounded
                clause = tuple(grounded(schema, env))
                others = [lit for lit in clause if lit != (sign, atom)]
                if any(lit in self.unit_ids for lit in others):
                    continue
                i = self.instance(schema["id"], env, "premise")
                self.with_units(i)
                for s, a in others:
                    self.request(not s, a)
                if () in self.index:
                    return

    def expand(self, family, env, parents):
        assert set(env) == set(family["variables"])
        if any(inspect_term(t, {}, self.functions) != family["variables"][v] for v, t in env.items()):
            self.work["typed_rejections"] += 1
            return
        output = clause_put(family["out"], env)
        if output in self.index:
            return
        self.charge("cluster_applications")
        mapping = {}
        for k, record in enumerate(family["recipe"]):
            expected = clause_put(record["clause"], env)
            if record["rule"] == "P":
                j = parents[record["port"]]
            else:
                self.charge("cluster_steps")
                if record["rule"] == "G":
                    bindings = {v: substitute(t, env) for v, t in record["bindings"].items()}
                    name = self.sources[family["id"]][record["source"]]
                    token = name, tuple(sorted(bindings.items()))
                    j = self.index.get(expected) if token in self.seen_instances else self.instance(name, bindings, "cluster")
                else:
                    a, b = (mapping[record[v]] for v in ("left", "right"))
                    pivot = substitute(record["pivot"], env)
                    ca, cb = (set(self.rows[x][0]) for x in (a, b))
                    if (True, pivot) not in ca or (False, pivot) not in cb:
                        self.work["cluster_collision_rejections"] += 1
                        return
                    j = self.resolve(a, b, pivot)
            if j is None or self.rows[j][0] != expected:
                self.work["cluster_collision_rejections"] += 1
                return
            mapping[k] = j
        root = mapping[len(family["recipe"]) - 1]
        self.attachments.append(dict(family=family["id"], bindings=env.copy(), parents=parents.copy(), output=root, clause=output))
        self.with_units(root)

    def family_pass(self):
        for _ in range(64):
            if not self.queue:
                return
            i = self.queue.popleft()
            (sign, atom), = self.rows[i][0]
            for f in self.bank:
                for slot, ((port_sign, pattern),) in enumerate(f["ports"]):
                    if (sign, atom[0]) != (port_sign, pattern[0]):
                        continue
                    self.charge("join_probes")
                    env = {}
                    if not bind(pattern, atom, env):
                        continue
                    for bound, parents in self.joins(f, set(range(len(f["ports"]))) - {slot}, env, {slot: i}):
                        key = f["id"], tuple(sorted(bound.items())), tuple(sorted(parents.items()))
                        if key not in self.applied:
                            self.applied.add(key)
                            self.expand(f, bound, parents)
                        if () in self.index:
                            return

    def focused(self):
        self.family_pass()
        if () not in self.index:
            self.demand_pass()
        if self.use_demand and () not in self.index:
            self.family_pass()
        if () not in self.index:
            super().focused()

    def run(self):
        out = super().run()
        needed = set()
        if out["proof"]:
            pending = [self.index[()]]
            while pending:
                i = pending.pop()
                if i not in needed:
                    needed.add(i)
                    r = self.rows[i][1]
                    if r[0] == "R":
                        pending.extend(r[1:3])
        out["attachments"] = [a for a in self.attachments if a["output"] in needed]
        out["available_families"] = [f["id"] for f in self.bank]
        return out
