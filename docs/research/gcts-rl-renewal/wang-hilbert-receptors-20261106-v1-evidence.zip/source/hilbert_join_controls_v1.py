"""Check signed ports, sort declarations and source-context availability."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from copy_ports_v1 import freeze
from herbrand_v1 import signature
from multi_families_v1 import validate


def main():
    if not __debug__:
        raise RuntimeError("Checking requires assertions")
    data = freeze(json.loads((ROOT / "data/hilbert-join-study-v1.json").read_text()))
    family = data["inventory"][0]
    functions, predicates, _ = signature(data["rows"][0]["normal"])
    rejected = []
    def reject(label, mutate):
        bad = deepcopy(family)
        mutate(bad)
        try:
            validate(bad, functions, predicates)
        except (AssertionError, KeyError, IndexError):
            rejected.append(label)
        else:
            raise AssertionError("Accepted " + label)
    reject("wrong point sort", lambda f: f["variables"].update({"?m0":"Line"}))
    reject("omitted premise port", lambda f: f.update(ports=f["ports"][1:]))
    reject("changed distinctness sign", lambda f: f.update(ports=(((True,f["ports"][0][0][1]),),*f["ports"][1:])))
    reject("unanchored schema", lambda f: next(r for r in f["recipe"] if r["rule"]=="G").update(source="invented"))
    reject("cyclic parent", lambda f: next(r for r in f["recipe"] if r["rule"]=="R").update(left=999))
    reject("changed output", lambda f: f.update(out=((True,("=Line",("ell",),("ell",))),)))
    missing = next(r for r in data["rows"] if r["original"]["id"]=="missing-uniqueness-axiom")
    ids = {f["id"] for f in data["inventory"]}
    assert not (ids & set(missing["runs"]["inventory"]["available_families"]))
    assert len(data["models"])==4
    assert all(all(m["premise_truth"]) and not m["conclusion_truth"] for m in data["models"].values())
    body = json.dumps(dict(rejected=rejected, absent_axiom_families=0, countermodels=4),sort_keys=True)+"\n"
    path = ROOT / "data/hilbert-join-controls-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text()==body
    print("Rejected",len(rejected),"damaged recipes; checked four countermodels and missing source context")


if __name__ == "__main__":
    main()
