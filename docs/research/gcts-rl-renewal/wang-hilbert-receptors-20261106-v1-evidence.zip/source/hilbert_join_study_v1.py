"""Search a bridge lemma, freeze two typed families, then evaluate the declared transfer grid."""
import json
from hashlib import sha256
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from equality_study_v1 import LIMITS as PRIOR_LIMITS
from hilbert_join_cases_v1 import cases
from induction_cases_v1 import hilbert
from multi_families_v1 import mine, propagation_families
from multi_search_v1 import MultiSearch

LIMITS = {**PRIOR_LIMITS, "join_probes": 200000, "cluster_applications": 2000, "cluster_steps": 16000,
          "premise_requests": 10000, "premise_probes": 200000}
ARMS = ("baseline", "requests", "incidence", "inventory", "inventory-learned-47")


def execute(original, bank, weights=(), demand=False, indexed=True):
    normal, translation = compile_case(original)
    check(original, normal, translation)
    basis = propagation_families(normal) if demand else []
    engine = MultiSearch(normal, original["goal"], LIMITS, [*bank, *basis], weights, indexed, demand)
    result = engine.run()
    assert all(result["counts"].get(k, 0) <= v for k, v in LIMITS.items())
    return result, normal, translation


def study():
    donors = json.loads((ROOT / "input/donor-proofs-v1.json").read_text())
    donor = next(r for r in donors["rows"] if r["original"]["id"] == "two-points-determine-a-line")
    incidence = mine(donor["original"], donor["normal"], donor["runs"]["both"]["proof"], "incidence-uniqueness")
    original = hilbert()
    bridge = {}
    bridge_normal, _ = compile_case(original)
    basis = propagation_families(bridge_normal)
    for label, bank, demand in (("baseline",[],False), ("incidence-only",[incidence],False),
                               ("propagation-only",basis,False), ("requests",[],True), ("incidence",[incidence],True)):
        result, normal, translation = execute(original, bank, demand=demand)
        bridge[label] = result
    assert bridge["incidence"]["status"] == "PROVED"
    assert any(a["family"] == incidence["id"] for a in bridge["incidence"]["attachments"])
    order = mine(original, normal, bridge["incidence"]["proof"], "betweenness-on-line")
    learned = [incidence, order]
    frozen = sha256(json.dumps(learned,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    rows = [dict(split="development", original=original, normal=normal, translation=translation,
                 runs=bridge, countermodel=False)]
    models = {}
    # All held-out cases and limits are fixed in source before their first run.
    for original, model in cases():
        if model:
            p, g = holds(original, model)
            assert all(p) and not g, original["id"]
            models[original["id"]] = dict(domains=model["domains"], functions={k:list(v.items()) for k,v in model["functions"].items()},
                                          predicates={k:sorted(v) for k,v in model["predicates"].items()},
                                          premise_truth=p, conclusion_truth=g)
        runs = {}
        for arm in ARMS:
            bank = [] if arm in ("baseline","requests") else learned[:1] if arm == "incidence" else learned
            weights = donors["frozen_models"]["47"]["weights"] if arm.endswith("47") else ()
            result, normal, translation = execute(original, bank, weights, arm != "baseline")
            runs[arm] = result
            assert model is None or result["status"] == "BOUNDED", (original["id"],arm)
        flat, _, _ = execute(original, learned, demand=True, indexed=False)
        routed = runs["inventory"]
        if flat["status"] == "PROVED":
            assert routed["status"] == "PROVED"
            assert all(flat.get(k) == routed.get(k) for k in ("proof","attachments","constructor_example"))
        if flat["status"] == routed["status"] and flat.get("stop") == routed.get("stop"):
            ignored = {"join_probes","argument_lookups"}
            assert {k:v for k,v in flat["counts"].items() if k not in ignored} == {k:v for k,v in routed["counts"].items() if k not in ignored}
        elif flat["status"] == "BOUNDED":
            assert flat["stop"] == "join_probes"
        rows.append(dict(split="held-out", original=original, normal=normal, translation=translation,
                         runs=runs, flat=flat, countermodel=model is not None))
        print(original["id"], {a:(r["status"],r["counts"].get("resolutions",0),r.get("stop")) for a,r in runs.items()},flush=True)
    return dict(limits=LIMITS, arms=ARMS, inventory=learned, inventory_sha256=frozen, rows=rows, models=models,
                donor=dict(id=donor["original"]["id"], proof=donor["runs"]["both"]["proof"], normal=donor["normal"]))


def main():
    if not __debug__:
        raise RuntimeError("Replay requires assertions")
    result = study()
    path = ROOT / "data/hilbert-join-study-v1.json"
    body = json.dumps(result,sort_keys=True,separators=(",",":")) + "\n"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print("Verified frozen inventory",result["inventory_sha256"],flush=True)


if __name__ == "__main__":
    main()
