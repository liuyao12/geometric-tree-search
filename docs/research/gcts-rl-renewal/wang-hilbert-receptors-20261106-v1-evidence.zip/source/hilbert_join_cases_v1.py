"""Typed incidence and order transfer cases, with explicit finite countermodels."""
from itertools import product
from induction_cases_v1 import hilbert


def atom(name, *args):
    return ["atom", name, *args]


def point(name):
    return [name]


def base(name, order=True):
    h = hilbert()
    return dict(id=name, sorts=h["sorts"], equality=True, functions={}, predicates=h["predicates"],
                premises=h["premises"][:2 if order else 1], goal=None)


def add(source, name, sort):
    source["functions"][name] = [[], sort]
    return point(name)


def uniqueness(k, decoys):
    source = base(f'incidence-chain-{k}-decoys-{decoys}', False)
    lines = [add(source, f"line{i}", "Line") for i in range(k + 1)]
    for j in range(k):
        p, q = (add(source, f"point{j}_{x}", "Point") for x in "ab")
        source["premises"].append(["not", atom("=Point", p, q)])
        source["premises"].extend(atom("I", t, l) for t in (p, q) for l in lines[j:j+2])
    for j in range(decoys):
        p = add(source, f"unused{j}", "Point")
        l = add(source, f"unused_line{j}", "Line")
        source["premises"].append(atom("I", p, l))
    source["goal"] = atom("=Line", lines[0], lines[-1])
    return source


def order_chain(k, reversed_ends=False):
    source = base(f'order-chain-{k}-reverse-{int(reversed_ends)}')
    pts = [add(source, f"p{i}", "Point") for i in range(2*k + 1)]
    line = add(source, "target_line", "Line")
    source["premises"].extend(atom("I", pts[i], line) for i in range(0, 2*k+1, 2))
    for j in range(k):
        a, b, c = pts[max(0,2*j-1)], pts[2*j+1], pts[2*j+2]
        source["premises"].append(atom("B", *( (c,b,a) if reversed_ends else (a,b,c))))
    source["goal"] = atom("I", pts[2*k-1], line)
    return source


def mixed(k):
    source = order_chain(k)
    source["id"] = f"mixed-line-and-order-{k}"
    line = point("target_line")
    other = add(source, "other_line", "Line")
    a, b = (add(source, "anchor_" + s, "Point") for s in "ab")
    source["premises"].append(["not", atom("=Point", a, b)])
    source["premises"].extend(atom("I", p, l) for p in (a,b) for l in (line,other))
    source["goal"] = atom("I", point(f"p{2*k-1}"), other)
    return source


def countermodel(source, values, incidence, between=()):
    return dict(domains={"Point": (0,1,2), "Line": (0,1)},
                functions={name: {(): value} for name, value in values.items()},
                predicates={"I": set(incidence), "B": set(between)})


def cases():
    for k, decoys in product((1,2,3), (0,3)):
        yield uniqueness(k, decoys), None
    for k, reverse in product((1,2,3), (False,True)):
        yield order_chain(k, reverse), None
    for k in (1,2):
        yield mixed(k), None
    s = uniqueness(1,0)
    s["id"] = "missing-distinct-points"
    s["premises"] = [p for p in s["premises"] if p[0] != "not"]
    vals = dict(point0_a=0, point0_b=0, line0=0, line1=1)
    yield s, countermodel(s, vals, [(0,0),(0,1)])
    s = uniqueness(1,0)
    s["id"] = "incompatible-second-point"
    wrong = add(s,"wrong_point","Point")
    s["premises"][-1] = atom("I", wrong, point("line1"))
    vals = dict(point0_a=0, point0_b=1, wrong_point=2, line0=0, line1=1)
    yield s, countermodel(s, vals, [(0,0),(1,0),(0,1),(2,1)])
    s = order_chain(1)
    s["id"] = "missing-endpoint-incidence"
    s["premises"] = [p for p in s["premises"] if p != atom("I",point("p2"),point("target_line"))]
    vals = dict(p0=0,p1=1,p2=2,target_line=0)
    yield s, countermodel(s, vals, [(0,0),(0,1),(1,1),(2,1)], [(0,1,2)])
    s = order_chain(1)
    s["id"] = "missing-uniqueness-axiom"
    s["premises"] = s["premises"][1:]
    yield s, countermodel(s, vals, [(0,0),(2,0),(0,1),(1,1),(2,1)], [(0,1,2)])
