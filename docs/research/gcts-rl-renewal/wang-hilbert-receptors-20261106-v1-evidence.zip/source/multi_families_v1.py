"""Erase generated sort guards, then extract a typed proof with several premise ports."""
from conditional_families_v1 import ancestors, clause_put, names, schema_key, variables
from copy_ports_v1 import freeze
from fair_search_v1 import ordered
from herbrand_v1 import inspect_term, signature
from study_v1 import grounded


def erase_guards(original, normal, proof):
    functions, predicates, schemas = signature(normal)
    source = {s["id"]: s for s in schemas}
    out, mapping = [], {}
    for i, old in enumerate(freeze(proof)):
        clause = ordered((s, a) for s, a in old["clause"] if not a[0].startswith("$type:"))
        if old["rule"] == "G":
            if old["source"] not in source:
                assert old["source"].startswith("$type-function:") and not clause
                mapping[i] = None
                continue
            assert clause == ordered(grounded(source[old["source"]], old["bindings"]))
            record = dict(rule="G", source=old["source"], bindings=old["bindings"], clause=clause)
        elif old["pivot"][0].startswith("$type:"):
            parents = {mapping[old[k]] for k in ("left", "right")} - {None}
            assert len(parents) <= 1
            mapping[i] = next(iter(parents), None)
            assert mapping[i] is None and not clause or mapping[i] is not None and out[mapping[i]]["clause"] == clause
            continue
        else:
            a, b = (mapping[old[k]] for k in ("left", "right"))
            assert a is not None and b is not None
            ca, cb = (set(out[j]["clause"]) for j in (a, b))
            p = old["pivot"]
            assert (True, p) in ca and (False, p) in cb
            assert clause == ordered((ca - {(True, p)}) | (cb - {(False, p)}))
            record = dict(rule="R", left=a, right=b, pivot=p, clause=clause)
        mapping[i] = len(out)
        out.append(record)
    assert not out[-1]["clause"]
    return out


def validate(family, functions, predicates):
    values, seen = [], set()
    for record in family["recipe"]:
        clause = ordered(record["clause"])
        for _, a in clause:
            assert tuple(inspect_term(t, family["variables"], functions) for t in a[1:]) == tuple(predicates[a[0]])
        if record["rule"] == "P":
            j = record["port"]
            assert 0 <= j < len(family["ports"]) and j not in seen
            seen.add(j)
            assert clause == ordered(family["ports"][j])
        elif record["rule"] == "G":
            source = family["sources"][record["source"]]
            assert set(record["bindings"]) == set(source["variables"])
            assert all(inspect_term(t, family["variables"], functions) == source["variables"][v]
                       for v, t in record["bindings"].items())
            assert clause == ordered(grounded(source, record["bindings"]))
        else:
            assert record["rule"] == "R"
            assert 0 <= record["left"] < len(values) and 0 <= record["right"] < len(values)
            a, b = (set(values[record[k]]) for k in ("left", "right"))
            p = record["pivot"]
            assert (True, p) in a and (False, p) in b
            assert clause == ordered((a - {(True, p)}) | (b - {(False, p)}))
        values.append(clause)
    assert seen == set(range(len(family["ports"])))
    assert values[-1] == ordered(family["out"]) and len(family["out"]) == 1
    bound = set().union(*(variables(a) for port in family["ports"] for _, a in port))
    assert set(family["variables"]) == bound
    assert variables(family["out"][0][1]) <= bound


def discharge(raw, goal):
    """Derive the positive atomic goal using a resolution proof without its denial."""
    out, mapping = [], {}
    for i, old in enumerate(raw):
        if (False, goal) in old["clause"]:
            mapping[i] = None
            continue
        record = None
        if old["rule"] == "G":
            record = old.copy()
        elif old["pivot"] == goal:
            # The positive parent is already a subclause of this resolvent plus goal.
            mapping[i] = mapping[old["left"]]
        else:
            a, b = (mapping[old[k]] for k in ("left", "right"))
            assert a is not None and b is not None
            ca, cb = (set(out[j]["clause"]) for j in (a, b))
            pivot = old["pivot"]
            if (True, pivot) not in ca:
                mapping[i] = a
            elif (False, pivot) not in cb:
                mapping[i] = b
            else:
                record = dict(rule="R", left=a, right=b, pivot=pivot,
                              clause=ordered((ca - {(True, pivot)}) | (cb - {(False, pivot)})))
        if record is not None:
            mapping[i] = len(out)
            out.append(record)
        assert mapping[i] is not None
        assert set(out[mapping[i]]["clause"]) <= set(old["clause"]) | {(True, goal)}
    root = mapping[len(raw) - 1]
    assert out[root]["clause"] == ((True, goal),)
    return out, root


def mine(original, normal, proof, family_id):
    raw = erase_guards(original, normal, proof)
    original_raw_count = len(raw)
    assert original["goal"][0] == "atom"
    raw, root = discharge(raw, freeze(original["goal"][1:]))
    functions, predicates, schemata = signature(normal)
    sources = {s["id"]: s for s in schemata}
    needed = ancestors(raw, root)
    rigid = set()
    def formula_names(f):
        if f[0] == "atom":
            return set().union(*(names(t) for t in freeze(f[2:])))
        return set().union(*(formula_names(c) for c in f[1:] if isinstance(c, list)))
    for f in original["premises"]:
        if f[0] in ("all", "exists"):
            rigid |= formula_names(f)
    occurring = set().union(*(names(a) for i in needed for _, a in raw[i]["clause"]))
    flexible = sorted(n for n, (args, _) in original["functions"].items() if not args and n not in rigid and n in occurring)
    abstract = {n: f"?m{i}" for i, n in enumerate(flexible)}
    def lift(t):
        if isinstance(t, str):
            return t
        if t[0] in abstract:
            assert len(t) == 1
            return abstract[t[0]]
        return (t[0], *(lift(c) for c in t[1:]))
    recipe, ports, used, mapping = [], [], {}, {}
    denied = "formula" + str(len(original["premises"]) + 1) + "-root"
    for i in needed:
        old = raw[i]
        record = dict(rule=old["rule"], clause=ordered((s, lift(a)) for s, a in old["clause"]))
        if old["rule"] == "G":
            assert old["source"] != denied, "The proposed positive lemma depends on the denied conclusion"
            source = sources[old["source"]]
            if any(names(a) & abstract.keys() for _, a in source["clause"]):
                assert not source["variables"] and len(record["clause"]) == 1
                record.update(rule="P", port=len(ports))
                ports.append(record["clause"])
            else:
                used[source["id"]] = source
                record.update(source=source["id"], bindings={v: lift(t) for v, t in old["bindings"].items()})
        else:
            record.update(left=mapping[old["left"]], right=mapping[old["right"]], pivot=lift(old["pivot"]))
        mapping[i] = len(recipe)
        recipe.append(record)
    family = dict(id=family_id, donor=original["id"], variables={v: functions[n][1] for n, v in abstract.items()},
                  donor_bindings={v: (n,) for n, v in abstract.items()}, ports=ports, out=recipe[-1]["clause"],
                  sources=used, recipe=recipe, donor_records=len(proof), raw_records=original_raw_count)
    validate(family, functions, predicates)
    return family


def propagation_families(normal):
    """Compile exact unit-propagation recipes from formula schemas, without donor mining."""
    functions, predicates, schemas = signature(normal)
    bank = []
    for source in schemas:
        if not source["id"].startswith("formula") or len(source["clause"]) < 2:
            continue
        for chosen, target in enumerate(source["clause"]):
            ports = [((not sign, atom),) for k, (sign, atom) in enumerate(source["clause"]) if k != chosen]
            bound = set().union(*(variables(a) for port in ports for _, a in port))
            if bound != set(source["variables"]):
                continue
            recipe = [dict(rule="P", port=i, clause=p) for i, p in enumerate(ports)]
            current = len(recipe)
            clause = set(source["clause"])
            recipe.append(dict(rule="G", source=source["id"], bindings={v: v for v in source["variables"]},
                               clause=ordered(clause)))
            for i, ((sign, atom),) in enumerate(ports):
                clause.remove((not sign, atom))
                a, b = (i, current) if sign else (current, i)
                recipe.append(dict(rule="R", left=a, right=b, pivot=atom, clause=ordered(clause)))
                current = len(recipe) - 1
            family = dict(id='propagate:' + source["id"] + ':' + str(chosen), donor=None,
                          variables=source["variables"], ports=ports, out=(target,),
                          sources={source["id"]: source}, recipe=recipe)
            validate(family, functions, predicates)
            bank.append(family)
    return bank
