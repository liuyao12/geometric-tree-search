Hilbert proof families with several typed premise receptors

Use Python 3.12 with assertions enabled, from the archive root:

  python3 -I -S -B source/hilbert_join_study_v1.py
  python3 -I -S -B source/hilbert_join_controls_v1.py
  python3 -I -S -B source/hilbert_join_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command extracts the incidence family from the prior donor,
repeats the bridge search, freezes the new two-family inventory, and
runs all transfer cases and finite countermodels. The second rejects
six damaged recipes. The third replays all distinct successful marked
Wang proofs. The final command regenerates the visual reader.
The learned unit scheduler is frozen from the earlier donor experiment.
It is not retrained here. The manifest gives file hashes.
