"""Compare reusable periodic markings with unmarked finite boundary search."""
from collections import Counter
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import frozen, neighbors, patch_ring, penrose_pair
from cluster_v1 import mat
from discover_directions_v1 import signature
from geometry_v1 import Penrose, Turtle, add, area, check_rings, mul, pairs, sub
from penrose_signed_fill_v1 import check_signed_fill, sorted_word_fill
from periodic_marks_v1 import (PeriodicMarks, check_integer_lift, check_mark,
                               edge_row, edge_term, integer_value)

FRAMES = (((1, 0), (0, 1)), ((1, -2), (1, 0)), ((1, -2), (1, 1)))
DONORS = ((0, 4, 5, 2, 3), (1, 4, 5, 3, 2), (2, 4, 5, 2, 5))
SIZES = ((8, 10), (9, 20), (10, 12), (11, 20), (12, 15), (15, 16))
FIELDS = ((2, 3), (3, 2), (2, 5), (3, 3))
LIMIT = 240


def read(path):
    return json.loads((ROOT / path).read_text())


def target(g, frame, n, m, offset):
    a, b = (mul(size, axis) for size, axis in zip((n, m), FRAMES[frame], strict=True))
    ring = tuple(add(p, offset) for p in (g.zero, a, add(a, b), b))
    return Region(g, (ring,))


def reflected(m):
    return m[0][0] * m[1][1] - m[0][1] * m[1][0] < 0


class MarkLibrary:
    def __init__(self, g, alphabet, donors):
        self.g = g
        self.donors = {}
        self.forms = []
        seen = set()
        for i, mark in enumerate(donors, 1):
            period = mark["period"]
            weights = {(p, d): w for p, d, w in mark["weights"]}
            check_integer_lift(alphabet, period, weights)
            self.donors[i] = period, weights
            residues = tuple(product(range(period), repeat=len(g.zero)))
            axes = sorted({edge_term(a, b, period)[0][1] for tile in alphabet for a, b in tile})
            for turn, transform in g.model.groups.items():
                for offset in residues:
                    terms = []
                    for pos, direction in product(residues, axes):
                        a = add(mat(transform, pos), offset)
                        b = add(a, mat(transform, direction))
                        key, sign = edge_term(b, a, period) if reflected(transform) else edge_term(a, b, period)
                        value = sign * weights.get(key, 0)
                        if value:
                            terms.append((pos, direction, value))
                    form = period, tuple(terms)
                    if form not in seen:
                        seen.add(form)
                        self.forms.append((i, turn, offset, *form))

    def find(self, edges):
        rows = {k: edge_row(edges, k, self.g.zero) for k in {p for p, _ in self.donors.values()}}
        return self.find_rows(rows)

    def find_rows(self, rows):
        for donor, turn, offset, period, terms in self.forms:
            row = rows[period]
            value = sum(row[p, d] * w for p, d, w in terms)
            if value:
                return dict(donor=donor, turn=turn, offset=offset, value=value)
        return None

    def verify(self, edges, proof):
        period, weights = self.donors[proof["donor"]]
        transform = self.g.model.groups[proof["turn"]]
        posed = tuple((mat(transform, a), mat(transform, b)) for a, b in edges)
        if reflected(transform):
            posed = tuple((b, a) for a, b in posed)
        assert integer_value(posed, weights, period, proof["offset"]) == proof["value"] != 0


def compressed_row(segments, period):
    row = Counter()
    for a, direction, count in segments:
        cycles, remainder = divmod(count, period)
        for phase in range(period):
            multiplicity = cycles + (phase < remainder)
            if multiplicity:
                start = add(a, mul(phase, direction))
                key, sign = edge_term(start, add(start, direction), period)
                row[key] += sign * multiplicity
    return row


def preflight(g, library, rings):
    check_rings(g, rings)
    segments = tuple((a, *g.primitive_segment(a, b)) for ring in rings for a, b in pairs(ring))
    twice_area = sum(area(ring, g.cross)[0] for ring in rings)
    counts = g.counts((twice_area,))
    if counts is None:
        return dict(reason="EXACT_AREA")
    if any(compressed_row(segments, 1).values()):
        return dict(reason="DIRECTION", counts=counts)
    rows = {k: compressed_row(segments, k) for k in {p for p, _ in library.donors.values()}}
    proof = library.find_rows(rows)
    if proof:
        # Re-evaluate in the donor frame, with the same finite phase expansion.
        transform = g.model.groups[proof["turn"]]
        period, weights = library.donors[proof["donor"]]
        positioned = []
        for a, direction, count in segments:
            start = add(mat(transform, a), proof["offset"])
            ray = mat(transform, direction)
            if reflected(transform):
                start, ray = add(start, mul(count, ray)), mul(-1, ray)
            positioned.append((start, ray, count))
        donor_row = compressed_row(positioned, period)
        assert sum(donor_row[key] * value for key, value in weights.items()) == proof["value"]
    return dict(reason="PERIODIC" if proof else "PASS", counts=counts, mark=proof,
                boundary_edges=sum(count for _, _, count in segments), boundary_segments=len(segments))


def solve_fixed(g, library, inv, rings, case):
    screening = preflight(g, library, rings)
    if screening["reason"] != "PASS":
        return dict(status="NEGATIVE", screen=screening)
    result = solve(Region(g, rings), inv, case, order="single", limit=LIMIT)
    return dict(**result, screen=screening)


def measure(g, inv, alphabet, marks, library, region, case):
    assert region.counts is not None and not any(signature(region.edges).values())
    proof = library.find(region.edges)
    if proof:
        library.verify(region.edges, proof)
    screen = preflight(g, library, region.rings)
    assert screen["mark"] == proof and screen["counts"] == region.counts
    fresh = next((c for model in marks.values() if (c := model.find(region.edges))), None)
    if fresh:
        check_mark(alphabet, region.edges, fresh)
    baseline = solve(region, inv, case, order="single", limit=LIMIT)
    assert baseline["status"] != "POSITIVE" or not (proof or fresh)
    if baseline["status"] == "POSITIVE":
        g.verify(region.rings, baseline["patch"])
    print("Turtle", case, baseline["status"], baseline["counts"].get("nodes", 0),
          "reuse", bool(proof), "fresh", bool(fresh), flush=True)
    return dict(case=case, ring=region.rings[0], counts=region.counts, reused=proof,
                fresh=fresh, baseline=baseline)


def perturbed_regions(g, ring, count):
    edits = []
    for i, b in enumerate(ring):
        a, c = ring[i - 1], ring[(i + 1) % len(ring)]
        d = sub(add(a, c), b)
        change = g.cross(sub(b, a), sub(c, b))[0]
        if change and d not in ring:
            edits.append((i, d, change))
    choices = []
    for (i, d, x), (j, e, y) in combinations(edits, 2):
        if x + y != 0 or d == e or j - i in (1, len(ring) - 1):
            continue
        choices.append((i, d, j, e))
    choices.sort(key=lambda change: sha256(repr(change).encode()).digest())
    selected = []
    for i, d, j, e in choices:
        new = list(ring)
        new[i], new[j] = d, e
        try:
            region = Region(g, (tuple(new),))
        except (AssertionError, ValueError):
            continue
        selected.append(((i, j), region))
        if len(selected) == count:
            return selected
    raise AssertionError("Insufficient valid geometric perturbations")


def turtle_study():
    g = Turtle(read("input/exact-point-model-v1.json"))
    inv = Inventory(g)
    alphabet = tuple(g.boundary(t) for t in g.bases)
    marks = {key: PeriodicMarks(alphabet, *key) for key in FIELDS}
    donors = []
    for frame, n, m, period, prime in DONORS:
        donor = target(g, frame, n, m, g.zero)
        assert donor.counts is not None and not any(signature(donor.edges).values())
        mark = marks[period, prime].find(donor.edges)
        assert mark
        check_mark(alphabet, donor.edges, mark)
        donors.append(dict(frame=frame, n=n, m=m, ring=donor.rings[0], mark=mark))

    library = MarkLibrary(g, alphabet, [r["mark"] for r in donors])
    assert library.donors[1] == library.donors[3]
    for i, donor in enumerate(donors, 1):
        period, weights = library.donors[i]
        edges = Region(g, (donor["ring"],)).edges
        donor["integer_value"] = integer_value(edges, weights, period, g.zero)
        assert donor["integer_value"]
    rows = []
    for frame in range(len(FRAMES)):
        for index, (n, m) in enumerate(SIZES):
            offset = (7 + index, -6 - frame)
            region = target(g, frame, n, m, offset)
            value = measure(g, inv, alphabet, marks, library, region, f"frame-{frame + 1}-{n}x{m}")
            rows.append(dict(frame=frame, n=n, m=m, **value))

    positives = []
    perturbations = []
    for size, row in zip((6, 18, 24), read("input/turtle-control-patches-v1.json"), strict=True):
        patch = frozen(row["patch"])
        if len(patch) > size:
            patch = neighbors(g, patch, size)
        for turn, shift in ((0, (0, 0)), (5, (-5, 7))):
            placed = tuple(g.shift(g.turn(t, turn), shift) for t in patch)
            rings = patch_ring(g, placed)
            assert rings
            g.verify(rings, placed)
            region = Region(g, rings)
            assert not any(signature(region.edges).values())
            assert not library.find(region.edges)
            assert preflight(g, library, rings)["reason"] == "PASS"
            assert all(m.find(region.edges) is None for m in marks.values())
            positives.append(dict(origin=row["id"], turn=turn, rings=rings, patch=placed))
            if turn or len(rings) != 1:
                continue
            for index, (edits, mutated) in enumerate(perturbed_regions(g, rings[0], 6), 1):
                assert mutated.counts == region.counts
                case = f"{row['id']}-edit-{index}"
                value = measure(g, inv, alphabet, marks, library, mutated, case)
                perturbations.append(dict(origin=row["id"], edits=edits, **value))
    assert len(perturbations) == 18
    first = positives[0]
    positive_result = solve_fixed(g, library, inv, first["rings"], "positive-fallback")
    assert positive_result["status"] == "POSITIVE"
    g.verify(first["rings"], positive_result["patch"])
    width = 10**100 + 1
    big_ring = ((0, 0), (width, 0), (width, 20), (0, 20))
    big = solve_fixed(g, library, inv, (big_ring,), "compressed-large")
    assert big["status"] == "NEGATIVE" and big["screen"]["reason"] == "PERIODIC"
    assert big["screen"]["boundary_edges"] == 2 * (width + 20)
    return dict(donors=donors, receivers=rows, positives=positives, perturbations=perturbations, node_limit=LIMIT,
                compiled_forms=len(library.forms), distinct_donors=2,
                large_case=dict(rings=(big_ring,), result=big), positive_fallback=positive_result,
                fields=[dict(period=p, prime=q, columns=len(m.keys), rank=len(m.heads))
                        for (p, q), m in marks.items()])


def penrose_study():
    g = Penrose()
    inv = Inventory(g)
    bad, port, _, _ = penrose_pair(g, inv)
    region = Region(g, bad)
    placements = []
    for (tile,) in inv.at(port):
        guard = region.exterior(tile)
        assert guard
        region.certify(tile, guard, frozenset())
        placements.append(dict(tile=tile, guard=guard))
    assert placements and not any(signature(region.edges).values())
    path = tuple(pairs(bad[0]))
    fill = sorted_word_fill(g, path)
    check_signed_fill(g, path, fill)
    assert min(w for _, w in fill) < 0
    tampered = ((fill[0][0], -fill[0][1]), *fill[1:])
    try:
        check_signed_fill(g, path, tampered)
    except AssertionError:
        pass
    else:
        raise AssertionError("The signed fill checker accepted a changed coefficient")
    return dict(rings=bad, counts=region.counts, port=port, rejected_placements=placements,
                signed_fill=fill, changed_coefficient="REJECTED")


def main():
    data = dict(status="CHECKED_PERIODIC_BOUNDARY_PILOT", turtle=turtle_study(), penrose=penrose_study())
    output = json.dumps(data, sort_keys=True, separators=(",", ":")) + "\n"
    (ROOT / "data/periodic-experiment-v1.json").write_text(output)


if __name__ == "__main__":
    main()
