"""Bind an induction proof to each checked signed-edge obstruction."""
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Region
from cases_v1 import frozen
from discover_directions_v1 import verify
from geometry_v1 import Penrose,Turtle
from periodic_experiment_v1 import MarkLibrary, preflight


def read(path):
    return json.loads((ROOT/path).read_text())


def holds(node,scope):
    op,*items=node
    if op=="all":
        v,_,body=items
        return all(holds(body,scope|{v:x}) for x in (0,1))
    if op=="atom":
        name,a,b=items
        assert name=="=Nat"
        def term(t):
            if isinstance(t,str):
                return scope[t]
            head,*args=t
            if head=="zero":
                return 0
            assert head in ("S","F") and len(args)==1
            return term(args[0])
        return term(a)==term(b)
    a,b=map(lambda x:holds(x,scope),items)
    return a and b if op=="and" else not a or b


def main():
    wang=ROOT/"wang"
    result=subprocess.run([sys.executable,"-I","-S","-B","source/logical_records_cli_v1.py",
        "verify","input/flux-induction-v1.json","data/flux-induction-logical-v1.json"],
        cwd=wang,check=True,text=True,capture_output=True)
    receipt=json.loads(result.stdout)
    statement=read("wang/input/flux-induction-v1.json")
    facts=statement["premises"]
    assert all(holds(p,{}) for p in facts[:2])
    assert not holds(facts[2],{}) and not holds(statement["goal"],{})
    candidates={}
    p=Penrose()
    t=Turtle(read("input/exact-point-model-v1.json"))
    for row in read("data/boundary-invariant-v1.json")["negatives"]:
        candidates["penrose-"+row["case"]]=(p,frozen(row["region"]))
    for row in read("data/joint-directions-v1.json")["turtle"]["negatives"]:
        candidates["turtle-"+row["case"]]=(t,frozen(row["ring"]))
    used=[]
    for trial in read("data/discovered-direction-marks-v1.json")["cases"]:
        g,r=candidates[trial["case"]]
        verify([g.boundary(b) for b in g.bases],Region(g,(r,)).edges,frozen_dict(trial["certificate"]))
        used.append(trial["case"])
    results=read("data/periodic-experiment-v1.json")["turtle"]
    library=MarkLibrary(t,[t.boundary(b) for b in t.bases],
                        [frozen_dict(r["mark"]) for r in results["donors"]])
    periodic=[]
    for row in (*results["receivers"],*results["perturbations"]):
        if row["reused"]:
            proof=frozen_dict(row["reused"])
            edges=Region(t,(frozen(row["ring"]),)).edges
            library.verify(edges,proof)
            periodic.append(row["case"])
    large=results["large_case"]
    expected=large["result"]["screen"]
    screen=preflight(t,library,frozen(large["rings"]))
    assert json.dumps(screen,sort_keys=True)==json.dumps(expected,sort_keys=True)
    assert expected["reason"]=="PERIODIC"
    periodic.append("compressed-large")
    value=dict(status="CHECKED_FLUX_LEMMA_BINDINGS",receipt=receipt,cases=used,periodic=periodic,
               induction_free_control=dict(domain=[0,1],successor=[0,1],F=[0,1],
                                           premises_hold=True,goal_holds=False))
    (ROOT/"data/flux-bindings-v1.json").write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")
    print(len(used),"boundary certificates share",receipt,flush=True)


def frozen_dict(item):
    return {k:frozen(v) for k,v in item.items()}


if __name__=="__main__":
    main()
