"""Infer and independently check signed-edge weights from an exact palette."""
from collections import Counter
from fractions import Fraction
from functools import reduce
from itertools import combinations
from math import gcd,lcm
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Region
from cases_v1 import frozen
from geometry_v1 import Penrose,Turtle,add,mul,pairs,sub
from cluster_v1 import mat


def signature(edges):
    result=Counter()
    for a,b in edges:
        d=sub(b,a)
        r=mul(-1,d)
        result[max(d,r)]+=1 if d>r else -1
    return result


def basis_kernel(matrix,width):
    rows=[list(map(Fraction,r)) for r in matrix if any(r)]
    heads=[]
    for col in range(width):
        r=next((i for i in range(len(heads),len(rows)) if rows[i][col]),None)
        if r is None:
            continue
        pivot=len(heads)
        rows[r],rows[pivot]=rows[pivot],rows[r]
        divisor=rows[pivot][col]
        rows[pivot]=[v/divisor for v in rows[pivot]]
        for i,row in enumerate(rows):
            if i!=pivot and row[col]:
                rows[i]=[v-row[col]*w for v,w in zip(row,rows[pivot],strict=True)]
        heads.append(col)
    result=[]
    for col in range(width):
        if col in heads:
            continue
        values=[Fraction(0)]*width
        values[col]=1
        for i,head in enumerate(heads):
            values[head]=-rows[i][col]
        scale=lcm(*(v.denominator for v in values))
        vector=tuple(int(scale*v) for v in values)
        divisor=reduce(gcd,vector)
        result.append(tuple(v//divisor for v in vector))
    return result


def dot(a,b):
    return sum(x*y for x,y in zip(a,b,strict=True))


def verify(alphabet,target,certificate):
    table=certificate["weights"]
    weights={tuple(axis):v for axis,v in table}
    assert len(weights)==len(table)
    def value(edges):
        return sum(weights.get(sub(b,a),0)-weights.get(sub(a,b),0) for a,b in edges)
    assert all(value(p)==0 for p in alphabet)
    assert value(target)==certificate["target"]!=0


def available_forms(alphabet):
    rows=[signature(p) for p in alphabet]
    axes=tuple(sorted(set().union(*(set(r) for r in rows))))
    matrix=[[row[a] for a in axes] for row in rows]
    return axes,basis_kernel(matrix,len(axes))


def discover(alphabet,target,compiled=None):
    axes,forms=available_forms(alphabet) if compiled is None else compiled
    counts=signature(target)
    vector=[counts[a] for a in axes]
    cuts=[w for w in forms if dot(w,vector)]
    if not cuts:
        return None
    chosen=min(cuts,key=lambda w:(sum(v!=0 for v in w),sum(map(abs,w)),w))
    result=dict(weights=[(a,v) for a,v in zip(axes,chosen,strict=True) if v],target=dot(chosen,vector),
                kernel_dimension=len(forms),alphabet_size=len(alphabet))
    verify(alphabet,target,result)
    return result


def source(path):
    return json.loads((ROOT/path).read_text())


def triangle_cover(n):
    for x in range(n):
        for y in range(n-x):
            yield ((x,y),(x+1,y),(x,y+1))
            if x+y+1<n:
                yield ((x+1,y),(x+1,y+1),(x,y+1))


def main():
    g=Penrose()
    alphabet=[g.boundary(t) for t in g.bases]
    cases=[]
    for row in source("data/boundary-invariant-v1.json")["negatives"]:
        edges=Region(g,(frozen(row["region"]),)).edges
        cut=discover(alphabet,edges)
        assert cut
        cases.append(dict(case="penrose-"+row["case"],area_pass=row["area_accepts"],certificate=cut))
    turtle=Turtle(source("input/exact-point-model-v1.json"))
    alphabet=[turtle.boundary(t) for t in turtle.bases]
    for row in source("data/joint-directions-v1.json")["turtle"]["negatives"]:
        edges=Region(turtle,(frozen(row["ring"]),)).edges
        cut=discover(alphabet,edges)
        assert cut
        cases.append(dict(case="turtle-"+row["case"],area_pass=True,certificate=cut))
    triangle=((0,0),(1,0),(0,1))
    expanded=list(alphabet)
    for matrix in turtle.model.groups.values():
        p=tuple(mat(matrix,v) for v in triangle)
        if turtle.sign(turtle.cross(sub(p[1],p[0]),sub(p[2],p[0])))<0:
            p=p[::-1]
        expanded.append(tuple(pairs(p)))
    large=Region(turtle,(((0,0),(20,0),(0,20)),))
    assert discover(expanded,large.edges) is None
    cover=list(triangle_cover(20))
    assert len(cover)==400
    counts=Counter(e for p in cover for e in pairs(p))
    exterior={e for e,n in counts.items() if n>counts[e[::-1]]}
    assert exterior==large.edges
    assert all(signature(p) for p in expanded[-12:])
    result=dict(status="CHECKED_INFERRED_DIRECTION_MARKS",cases=cases,
                changed_alphabet=dict(triangles=len(cover),turtle_certificate="WITHHELD",
                                      verified_edges=len(exterior)))
    (ROOT/"data/discovered-direction-marks-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print("verified sparse marks",len(cases),"and a 400-triangle control",flush=True)


if __name__=="__main__":
    main()
