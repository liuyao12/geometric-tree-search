"""Check directed edge-count obstructions on both exact lattice models."""
import json
from collections import Counter
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_invariant_v1 import lift
from boundary_search_v1 import Inventory,Region,solve
from cases_v1 import frozen,patch_ring
from check_v1 import contact
from geometry_v1 import Penrose,Turtle,add,area,chain,mul,pairs,sub
from model_v1 import rotate


def read(name):
    return json.loads((ROOT/name).read_text())


def direction_signature(edges):
    counts=Counter()
    for a,b in edges:
        d=sub(b,a)
        opposite=mul(-1,d)
        counts[max(d,opposite)]+=1 if d>opposite else -1
    return tuple(sorted((axis,n) for axis,n in counts.items() if n))


def turtle_controls():
    g=Turtle(read("input/exact-point-model-v1.json"))
    assert all(not direction_signature(g.boundary(t)) for t in g.bases)
    inv=Inventory(g)
    cases=(
       ("clipped",((0,0),(9,0),(9,8),(7,9),(0,9))),
       ("triangle",((0,0),(20,0),(0,20))),
       ("wide-clipped",((0,0),(11,0),(11,10),(9,11),(0,11))),
    )
    negatives=[]
    for name,ring in cases:
        r=Region(g,(ring,))
        signature=direction_signature(r.edges)
        assert r.counts is not None and signature
        raw=solve(r,inv,name,limit=700)
        assert raw["status"]!="POSITIVE"
        negatives.append(dict(case=name,area_counts=r.counts,edge_signature=signature,baseline=raw,ring=ring))
    seed=(0,0,0)
    found=[]
    for e in sorted(g.boundary(seed)):
        for t, in inv.at(e[::-1]):
            if t==seed or not g.sites(t).isdisjoint(g.sites(seed)):
                continue
            patch=tuple(sorted((seed,t)))
            if patch in found:
                continue
            region=patch_ring(g,patch)
            if region is None:
                continue
            g.verify(region,patch)
            assert not direction_signature(Region(g,region).edges)
            found.append(patch)
            if len(found)==6:
                return dict(negatives=negatives,positives=found)
    raise AssertionError("Expected six positive doublets")


def paired_penrose():
    study=read("data/boundary-invariant-v1.json")
    row=next(r for r in study["negatives"] if r["case"]=="convex-2")
    g=Penrose()
    ring=frozen(row["region"])
    frame=frozen(row["frame"]["tiles"])
    offset=(30,0,0,0)
    other_ring=tuple(add(rotate(v,1),offset) for v in ring)
    other_frame=tuple(g.shift(g.turn(t,1),offset) for t in frame)
    assert all(contact(t,u) for t in frame for u in other_frame)
    lifted=[]
    masses=[]
    for r,p in ((ring,frame),(other_ring,other_frame)):
        rgn=Region(g,(r,))
        assert all((b,a) in chain(g,p) for a,b in rgn.edges)
        assert all(g.wind(r,tuple(map(sum,zip(*t))),4)==0 and
                   all(not g.intrudes(a,b,t) for a,b in pairs(r)) for t in p)
        lifted.append(lift(rgn.edges))
        masses.append(area(r,g.cross))
    assert lifted==[(2,)*5,(-2,)*5]
    assert add(*lifted)==(0,)*5 and g.counts(add(*masses)) is not None
    return dict(pockets=(ring,other_ring),frames=(frame,other_frame),lift=lifted,mass=masses,
                pooled_lift=add(*lifted),pooled_area_counts=g.counts(add(*masses)))


def main():
    value=dict(status="CHECKED_LOCAL_DIRECTION_PILOT",turtle=turtle_controls(),penrose=paired_penrose())
    (ROOT/"data/joint-directions-v1.json").write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")
    print("Turtle",[(r["case"],r["area_counts"],r["baseline"]["status"]) for r in value["turtle"]["negatives"]],
          "Penrose pooled lifts",value["penrose"]["lift"],value["penrose"]["pooled_area_counts"],flush=True)


if __name__=="__main__":
    main()
