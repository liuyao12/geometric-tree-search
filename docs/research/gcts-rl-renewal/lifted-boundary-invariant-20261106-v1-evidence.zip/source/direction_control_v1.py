"""Test directional cuts on the previous fixed and movable control cohort."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory,Region
from cases_v1 import frozen
from cavity_experiment_v1 import load_cases,run
from clipping_v1 import Core
from geometry_v1 import Penrose,pairs
from movable_direction_v1 import DirectionBank
from open_cover_v1 import verify as verify_cover


def main():
    g=Penrose()
    inv=Inventory(g)
    bank=DirectionBank(g)
    expected={r["id"]:r["arms"]["learned"]["status"] for r in
              json.loads((ROOT/"input/cavity-comparison-v1.json").read_text())["results"]}
    output=[]
    for case in load_cases():
        value=run(g,inv,case,bank)
        status=value["status"]
        assert status==expected[case["id"]] or expected[case["id"]]=="BOUNDED"
        if status=="POSITIVE":
            patch=frozen(value["patch"])
            assert patch[:len(case["seed"])]==case["seed"]
            if case["mode"]=="fixed":
                g.verify(case["envelope"],patch)
            else:
                region=Region(g,case["envelope"])
                core=Core(region,case["core"])
                verify_cover(core,case["seed"][0],patch,value["areas"],value["boundary"],case["cap"])
        if case["kind"]=="optional":
            assert status=="POSITIVE" and not value["counts"].get("edge_balance_cuts",0)
        output.append(dict(case=case["id"],status=status,nodes=value["counts"].get("nodes",0)))
    assert len(output)==27
    for proof in bank.events:
        assert proof["certificate"]["target"]
    result=dict(status="CHECKED_DIRECTIONAL_CONTROL_COHORT",cases=output,cuts=len(bank.events))
    (ROOT/"data/direction-control-v1.json").write_text(json.dumps(result,sort_keys=True)+"\n")
    print("controls",len(output),"cuts",len(bank.events),"covers",sum(r["status"]=="POSITIVE" for r in output),flush=True)


if __name__=="__main__":
    main()
