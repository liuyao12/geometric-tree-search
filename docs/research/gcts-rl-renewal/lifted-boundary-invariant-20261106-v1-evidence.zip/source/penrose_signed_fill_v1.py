"""Witness the algebraic limit of additive Penrose edge obstructions."""
from collections import Counter

from geometry_v1 import add, mul, sub


def axis(step):
    return max(step, mul(-1, step))


def oriented(edges, weight, chain):
    for a, b in edges:
        edge, sign = ((a, b), 1) if a < b else ((b, a), -1)
        chain[edge] += weight * sign


def sorted_word_fill(g, path):
    """Commute unit steps, recording the signed rhomb of each exchange."""
    alphabet = {tuple(sorted(sub(v, min(t)) for v in t)) for t in g.bases}
    steps = [sub(b, a) for a, b in path]
    assert path[-1][1] == path[0][0] and all(b == c for (_, b), (c, _) in zip(path, path[1:]))
    assert all(sum((v == d) - (v == mul(-1, d)) for v in steps) == 0
               for d in {axis(v) for v in steps})
    points = [path[0][0], *(b for _, b in path)]
    weights = Counter()
    for i in range(1, len(steps)):
        j = i
        while j > 0 and axis(steps[j]) < axis(steps[j-1]):
            a, b, c = points[j-1:j+2]
            u, v = steps[j-1:j+1]
            d = add(a, v)
            t = tuple(sorted((a, b, c, d)))
            assert tuple(sub(p, t[0]) for p in t) in alphabet
            sign = g.sign(g.cross(u, v))
            assert sign
            weights[t] += sign
            steps[j-1:j+1] = v, u
            points[j] = d
            j -= 1
    remaining = Counter()
    oriented(zip(points, points[1:]), 1, remaining)
    assert not any(remaining.values())
    return tuple((t, w) for t, w in sorted(weights.items()) if w)


def check_signed_fill(g, path, witness):
    alphabet = {tuple(sorted(sub(v, min(t)) for v in t)) for t in g.bases}
    assert len({t for t, _ in witness}) == len(witness)
    target, assembled = Counter(), Counter()
    oriented(path, 1, target)
    for t, w in witness:
        assert type(w) is int and w != 0
        assert tuple(sub(p, min(t)) for p in t) in alphabet
        oriented(g.boundary(t), w, assembled)
    assert target == assembled
