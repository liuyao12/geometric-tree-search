"""Compare exact Penrose area and oriented edge invariants."""
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import patch_ring,rhomb_grid
from check_v1 import contact
from geometry_v1 import Penrose,add,area,chain,mul,pairs,sub
from model_v1 import DIRECTIONS,ZERO,incident

RAYS={DIRECTIONS[(2*j+5*k)%10]:(j,1-2*k) for j in range(5) for k in range(2)}


def lift(edges):
    counts=[0]*5
    for a,b in edges:
        j,sign=RAYS[sub(b,a)]
        counts[j]+=sign
    return tuple(counts)


def polygon(order,scale):
    points=[ZERO]
    for i in order:
        points.append(add(points[-1],mul(scale,DIRECTIONS[i])))
    assert points.pop()==ZERO
    return tuple(points)


def frame(g,ring):
    edges=tuple(e for a,b in pairs(ring) for e in g.atomize(a,b))
    domains=[tuple(t for t in incident(a) if (b,a) in g.boundary(t)) for a,b in edges]
    work=0
    def visit(path,remaining):
        nonlocal work
        work+=1
        if not remaining:
            return path
        i,available=min(remaining,key=lambda row:(len(row[1]),row[0]))
        for t in available:
            updated=[(j,tuple(u for u in domain if u!=t and contact(t,u))) for j,domain in remaining if j!=i]
            if all(options for _,options in updated):
                found=visit((*path,t),updated)
                if found is not None:
                    return found
        return None
    out=visit((),list(enumerate(domains)))
    assert out is not None
    assert all(contact(a,b) for a,b in combinations(out,2))
    boundary=chain(g,out)
    assert all((b,a) in boundary for a,b in edges)
    assert all(g.wind(ring,tuple(map(sum,zip(*t))),4)==0 and
               all(not g.intrudes(a,b,t) for a,b in pairs(ring)) for t in out)
    return out,work


def main():
    g=Penrose()
    inv=Inventory(g)
    assert {lift(g.boundary(t)) for t in g.bases}=={(0,0,0,0,0)}
    rows=[]
    for label,order in (("convex",(0,2,4,6,8)),("concave",(0,2,4,8,6))):
        for scale in range(1,9):
            ring=polygon(order,scale)
            region=Region(g,(ring,))
            coeff=area(ring,g.cross)
            counts=lift(region.edges)
            assert counts==(scale,)*5
            raw=solve(region,inv,f"{label}-{scale}",limit=700)
            assert raw["status"]!="POSITIVE"
            witness=None
            if scale in (2,4):
                support,work=frame(g,ring)
                witness=dict(tiles=support,nodes=work)
            rows.append(dict(case=f"{label}-{scale}",area=coeff,area_accepts=region.counts is not None,
                             lift=counts,baseline=raw,region=ring,frame=witness))
    positives=[]
    for width in (1,2):
        for n in (2,4,6):
            tiles=rhomb_grid(n,2,width)
            rings=patch_ring(g,tiles)
            g.verify(rings,tiles)
            assert not any(lift(Region(g,rings).edges))
            positives.append(dict(width=width,tiles=len(tiles)))
    report=dict(status="CHECKED_PENROSE_BOUNDARY_LIFT",negatives=rows,positives=positives)
    (ROOT/"data/boundary-invariant-v1.json").write_text(json.dumps(report,sort_keys=True,separators=(",",":"))+"\n")
    print("area-pass/lift-cut",sum(r["area_accepts"] for r in rows),"among",len(rows),
          "compatible frames",sum(bool(r["frame"]) for r in rows),flush=True)


if __name__=="__main__":
    main()
