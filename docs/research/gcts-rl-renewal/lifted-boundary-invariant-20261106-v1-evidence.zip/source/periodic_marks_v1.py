"""Infer periodic edge weights from unmarked tile boundaries."""
from collections import Counter
from itertools import product

from geometry_v1 import add, mul, sub


def edge_term(a, b, period):
    ray = sub(b, a)
    reverse = mul(-1, ray)
    anchor, axis, sign = (a, ray, 1) if ray > reverse else (b, reverse, -1)
    return (tuple(x % period for x in anchor), axis), sign


def edge_row(edges, period, offset):
    row = Counter()
    for a, b in edges:
        key, sign = edge_term(add(a, offset), add(b, offset), period)
        row[key] += sign
    return row


class PeriodicMarks:
    def __init__(self, alphabet, period, prime):
        self.alphabet = tuple(alphabet)
        self.period = period
        self.prime = prime
        dimension = len(self.alphabet[0][0][0])
        self.residues = tuple(product(range(period), repeat=dimension))
        axes = sorted({edge_term(a, b, period)[0][1]
                       for tile in self.alphabet for a, b in tile})
        self.keys = tuple(product(self.residues, axes))
        self.pivots = {}
        for tile in self.alphabet:
            for offset in self.residues:
                row = self.reduce(self.vector(tile, offset))
                if any(row):
                    head = next(i for i, x in enumerate(row) if x)
                    inverse = pow(row[head], -1, prime)
                    self.pivots[head] = [x * inverse % prime for x in row]
        self.heads = tuple(sorted(self.pivots))

    def vector(self, edges, offset):
        row = edge_row(edges, self.period, offset)
        return [row[key] % self.prime for key in self.keys]

    def reduce(self, row):
        for head in sorted(self.pivots):
            x = row[head]
            if x:
                row = [(v - x * w) % self.prime for v, w in zip(row, self.pivots[head], strict=True)]
        return row

    def find(self, edges):
        zero = self.residues[0]
        reduced = self.reduce(self.vector(edges, zero))
        if not any(reduced):
            return None
        free = next(i for i, v in enumerate(reduced) if v)
        weights = [0] * len(self.keys)
        weights[free] = 1
        for head in reversed(self.heads):
            weights[head] = -sum(a * b for a, b in zip(self.pivots[head], weights, strict=True)) % self.prime
        return dict(period=self.period, prime=self.prime, target=reduced[free],
                    weights=[(*key, w) for key, w in zip(self.keys, weights, strict=True) if w])


def check_mark(alphabet, target, certificate):
    """Evaluate the proposed field directly, without matrix reduction."""
    period, prime = certificate["period"], certificate["prime"]
    assert type(period) is int and 2 <= period <= 5 and prime in (2, 3, 5)
    dimension = len(alphabet[0][0][0])
    weights = {}
    for pos, axis, weight in certificate["weights"]:
        pos, axis = tuple(pos), tuple(axis)
        assert len(pos) == dimension == len(axis) and all(0 <= x < period for x in pos)
        assert axis > mul(-1, axis) and (pos, axis) not in weights and 0 < weight < prime
        weights[pos, axis] = weight

    for offset in product(range(period), repeat=dimension):
        for tile in alphabet:
            assert evaluate(tile, weights, period, prime, offset) == 0
    assert evaluate(target, weights, period, prime, (0,) * dimension) == certificate["target"] != 0


def evaluate(edges, weights, period, prime, offset):
    return integer_value(edges, weights, period, offset) % prime


def integer_value(edges, weights, period, offset):
    total = 0
    for a, b in edges:
        key, sign = edge_term(add(a, offset), add(b, offset), period)
        total += sign * weights.get(key, 0)
    return total


def check_integer_lift(alphabet, period, weights):
    dimension = len(alphabet[0][0][0])
    for offset in product(range(period), repeat=dimension):
        for tile in alphabet:
            assert integer_value(tile, weights, period, offset) == 0
