"""Test signed-edge marks inside the required core of a movable cover."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory,Region
from cases_v1 import frozen
from cavity_cases_v1 import belt,expanded,hull,location,move,move_cycle
from cavity_marks_v1 import CavityBank,required
from cavity_pilot_v1 import residual_faces
from check_v1 import contact
from clipping_v1 import Core
from discover_directions_v1 import available_forms,discover,verify
from geometry_v1 import Penrose,area,chain,check_rings,pairs
from open_cover_v1 import solve


class DirectionBank:
    def __init__(self,g):
        self.alphabet=[g.boundary(t) for t in g.bases]
        self.compiled=available_forms(self.alphabet)
        self.events=[]

    def cut(self,region,core,frontier,path,case,stats):
        stats["edge_balance_scans"]+=1
        g=region.g
        for ring in residual_faces(frozenset((b,a) for a,b in frontier)):
            if len(ring)<3 or len(ring)!=len(set(ring)) or g.sign(area(ring,g.cross))<=0:
                continue
            certificate=discover(self.alphabet,tuple(pairs(ring)),self.compiled)
            if not certificate or not required(region,core,ring):
                continue
            check_rings(g,(ring,))
            assert all((b,a) in frontier for a,b in pairs(ring))
            stats["edge_balance_cuts"]+=1
            self.events.append(dict(case=case,ring=ring,certificate=certificate,path=path))
            return True
        return False


def main():
    g=Penrose()
    inv=Inventory(g)
    source=json.loads((ROOT/"data/boundary-invariant-v1.json").read_text())
    cases=[]
    for record in source["negatives"]:
        if record["frame"] is None:
            continue
        old_ring=frozen(record["region"])
        old_patch=frozen(record["frame"]["tiles"])
        for turn in (0,3):
            side=int(record["case"][-1])
            envelope,_=belt(g,13,(1,2)*7)
            delta=location(g,envelope,old_patch,turn)
            patch=move(g,old_patch,turn,delta)
            ring=move_cycle(old_ring,turn,delta)
            assert all(contact(a,b) for a,b in combinations(patch,2))
            case=record["case"]+f"-{turn}"
            checks=[]
            for mode,bank in (("baseline",None),("area",CavityBank()),("directions",DirectionBank(g))):
                region=Region(g,envelope)
                core=Core(region,(expanded(hull(g,ring)),))
                assert g.counts(area(ring,g.cross)) is not None
                result=solve(core,inv,patch[0],case,cap=len(patch)+24,node_limit=600,
                            initial=patch[1:],cavities=bank,order="single")
                assert result["status"]!="POSITIVE"
                item=dict(mode=mode,outcome=result["status"],counts=result["counts"])
                if mode=="directions":
                    proof,=bank.events
                    assert required(region,core,proof["ring"])
                    verify(bank.alphabet,tuple(pairs(proof["ring"])),proof["certificate"])
                    assert result["counts"]["nodes"]==1
                    item["proof"]=proof
                checks.append(item)
            cases.append(dict(id=case,arms=checks))
    assert len(cases)==8
    data=dict(status="CHECKED_REQUIRED_BOUNDARY_LIFT",cases=cases)
    (ROOT/"data/movable-direction-v1.json").write_text(json.dumps(data,sort_keys=True,separators=(",",":"))+"\n")
    print([(r["id"],[(a["mode"],a["outcome"],a["counts"]["nodes"]) for a in r["arms"]]) for r in cases],flush=True)


if __name__=="__main__":
    main()
