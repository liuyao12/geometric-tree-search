"""Package task-owned geometry and proof evidence with content hashes."""
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, RESULTS, ROOT, STEM, inputs, pin


def read(path):
    return json.loads((ROOT / path).read_text())


def save(path, obj):
    (ROOT / path).write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")


def main():
    replay = read("publication/replay-v1.json")
    assert set(replay["outputs"]) == set(OUTPUTS)
    assert all(pin((ROOT / p).read_bytes()) == h for p, h in replay["outputs"].items())
    browser = read("publication/browser-v1.json")
    results = f"report/{STEM}-results.json"
    save(results, dict(schema="LIFTED-BOUNDARY-INVARIANT-RESULTS-v1", replay=replay, browser=browser,
                       **{name.replace("-", "_"): read(f"data/{name}-v1.json") for name in RESULTS}))
    paths = (*inputs(), *OUTPUTS, results, "publication/REPLAY.md", "publication/replay_v1.py",
             "publication/package_v1.py", "publication/check_v1.cjs", "publication/browser-v1.json",
             "publication/replay-v1.json", "publication/signed-chain-v1.png",
             "publication/turtle-edits-v1.png", "data/periodic-run.stdout.log")
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for path in paths:
            raw = (ROOT / path).read_bytes()
            assert path not in manifest
            if not path.endswith(".png"):
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), path
            manifest[path] = pin(raw)
            info = ZipInfo(path, (2026, 11, 6, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    assets = [archive, ROOT / results, ROOT / f"report/{STEM}.html"]
    save(f"report/{STEM}-manifest.json",
         dict(schema="LIFTED-BOUNDARY-INVARIANT-MANIFEST-v1", archive_entries=manifest,
              assets={path.name: pin(path.read_bytes()) for path in assets}))
    print("Packaged", len(manifest), "public evidence files.")


if __name__ == "__main__":
    main()
