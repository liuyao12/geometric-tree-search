"""Render the local direction-invariant evidence and induction proof."""
import json
from math import cos,pi,sin,sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(Path(__file__).resolve().parent))
# The proof rendering helpers load the Wang source in a separate namespace.
sys.path.append(str(ROOT/"wang/source"))
from boundary_search_v1 import Region
from cases_v1 import frozen
from discover_directions_v1 import triangle_cover
from geometry_v1 import Penrose,Turtle
from proof_views_v1 import clause,explanation,formula,math

STEM="lifted-boundary-invariant-20261106-v1"

def read(name):
    return json.loads((ROOT/name).read_text())


def svg(paths,project,label):
    converted=[(tuple(map(project,points)),kind) for points,kind in paths]
    x,y=zip(*(p for shape,_ in converted for p in shape))
    x0,y0,x1,y1=min(x),min(y),max(x),max(y)
    pad=.06*max(x1-x0,y1-y0)
    box=f"{x0-pad} {y0-pad} {x1-x0+2*pad} {y1-y0+2*pad}"
    shapes=[]
    for points,kind in converted:
        v=" ".join(f"{a:.5f},{b:.5f}" for a,b in points)
        element="polyline" if len(points)==2 else "polygon"
        shapes.append(f'<{element} class="{kind}" points="{v}"/>')
    return f'<figure><svg role="img" aria-label="{label}" class="frame" viewBox="{box}">{"".join(shapes)}</svg><figcaption>{label}</figcaption></figure>'


def table(headers,rows):
    h="".join(f"<th>{x}</th>" for x in headers)
    body="".join("<tr>"+"".join(f"<td>{x}</td>" for x in r)+"</tr>" for r in rows)
    return f'<div class="table"><table><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table></div>'


def project_penrose(p):
    return (sum(x*cos(2*pi*i/5) for i,x in enumerate(p)),
            -sum(x*sin(2*pi*i/5) for i,x in enumerate(p)))


def project_turtle(p):
    return p[0]+p[1]/2,-sqrt(3)*p[1]/2


def turtle_view(data):
    g=Turtle(read("input/exact-point-model-v1.json"))
    cohort=(("Parallelograms",data["receivers"]),("Paired boundary edits",data["perturbations"]))
    rows=[]
    for name,cases in cohort:
        library=sum(bool(r["reused"]) for r in cases)
        fresh=sum(bool(r["fresh"]) for r in cases)
        work=sum(r["baseline"]["counts"].get("placement_checks",0) for r in cases if r["reused"])
        rows.append((name,len(cases),library,fresh,f"{work:,}"))
    counts=table(("Cohort","Requests","Reused weight cut","Fresh field cut","Baseline checks at reused cuts"),rows)
    cases=[r for _,batch in cohort for r in batch]
    detail=table(("Request","Expected tile count from area","Reused weight","Fresh field","Baseline nodes"),[
        (r["case"],r["counts"][0], "Cut" if r["reused"] else "Pass", "Cut" if r["fresh"] else "Pass",
         r["baseline"]["counts"]["nodes"]) for r in cases])
    example=max((r for r in data["perturbations"] if r["reused"]),
                key=lambda r:r["baseline"]["counts"]["nodes"])
    original=next(r for r in data["positives"] if r["origin"]==example["origin"] and r["turn"]==0)
    good=Region(g,frozen(original["rings"]))
    bad=Region(g,(frozen(example["ring"]),))
    layer=[(g.poly(frozen(t)),"facet-tile") for t in original["patch"]]
    picture=svg(layer+[(e,"old-edge") for e in sorted(good.edges-bad.edges)]
                +[(e,"new-edge") for e in sorted(bad.edges-good.edges)], project_turtle,
                "A cover from the hierarchy with two boundary corners edited")
    note=("<p>The orange segments show two changes to a known cover. Each edit swaps two consecutive boundary steps. "
          "The edits have opposite signed area changes, and all signed direction totals stay the same. "
          "The marked request still fails the periodic check.</p>")
    scope=("<p>All six original covers passed the periodic screen. The edited cases were selected by a fixed "
           "ordering of valid geometric edits, before applying the marks or the search.</p>")
    return (f'<div class="scope"><div>{note}{picture}</div><div>{counts}{scope}</div></div>'
            f'<details><summary>All 36 requests</summary>{detail}</details>')


def penrose_view(data):
    g=Penrose()
    ring=frozen(data["rings"])[0]
    port=frozen(data["port"])
    fill=frozen(data["signed_fill"])
    outline=svg([(ring,"facet-pocket"),(port,"failed-port")],project_penrose,
                "Area-compatible boundary with an uncovered receptor")
    layers=[(g.poly(t),"facet-tile" if w>0 else "negative-rhomb") for t,w in fill]
    decomposition=svg([*layers,(ring,"target-outline")],project_penrose,
                      "Signed chain with three positive rhombs and one negative rhomb")
    return f'<div class="panels">{outline}{decomposition}</div>'


def main():
    g=Penrose()
    source=read("data/joint-directions-v1.json")["penrose"]
    left=[]
    for p in source["frames"]:
        left.extend((g.poly(frozen(t)),"facet-tile") for t in p)
    left.extend((r,"facet-pocket") for r in source["pockets"])
    pview=svg(left,project_penrose,"Two sealed Penrose pockets")
    tview=svg([(t,"triangle-unit") for t in triangle_cover(20)],
              project_turtle,"Turtle target filled with the added triangles")
    geometry=f'<div class="panels">{pview}{tview}</div>'
    moves=read("data/movable-direction-v1.json")["cases"]
    search=table(("Query","Baseline visits","Area visits","Direction visits"),
                 [(m["id"],*(a["counts"]["nodes"] for a in m["arms"])) for m in moves])
    source=read("wang/input/flux-induction-v1.json")
    bundle=read("wang/data/flux-induction-logical-v1.json")
    assumptions="".join(f"<li>{math(formula(p))}</li>" for p in source["premises"])
    proof=f'<details><summary>Original hypotheses</summary><ul>{assumptions}</ul></details>'
    proof+=f'<p>Goal {math(formula(source["goal"]))}</p>'
    proof+=table(("Line","Reading","Formula"),[(i,explanation(line),math(clause(line["clause"])))
                   for i,line in enumerate(bundle["proof"]["lines"],1)])
    html=(ROOT/"publication/notebook-v1.html").read_text()
    study=read("data/periodic-experiment-v1.json")
    bindings=read("data/flux-bindings-v1.json")
    fields=dict(GEOMETRY=geometry,SEARCH=search,PROOF=proof,
                TURTLE=turtle_view(study["turtle"]),PENROSE=penrose_view(study["penrose"]),
                PERIODIC_TOTAL=len(bindings["periodic"])-1, DIRECTION_BINDINGS=len(bindings["cases"]),
                PERIODIC_BINDINGS=len(bindings["periodic"]))
    for k,v in fields.items():
        html=html.replace(f"%%{k}%%",str(v))
    assert "%%" not in html
    (ROOT/f"report/{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
