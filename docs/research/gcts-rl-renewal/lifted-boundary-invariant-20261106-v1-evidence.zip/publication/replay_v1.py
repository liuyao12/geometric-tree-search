"""Rebuild all retained exact results in a clean directory."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "lifted-boundary-invariant-20261106-v1"
GEOMETRY = ("boundary_invariant", "joint_directions", "discover_directions", "movable_direction",
            "direction_control", "periodic_experiment", "bind_flux")
STAGES = tuple((f"source/{name}_v1.py", ".") for name in GEOMETRY[:6]) + (
    ("source/flux_statement_v1.py", "wang"),
    ("source/flux_induction_v1.py", "wang"),
    ("source/bind_flux_v1.py", "."),
    ("publication/render_v1.py", "."),
)
RESULTS = ("boundary-invariant", "joint-directions", "discovered-direction-marks",
           "movable-direction", "direction-control", "periodic-experiment", "flux-bindings")
OUTPUTS = tuple(f"data/{name}-v1.json" for name in RESULTS) + (
    "wang/input/flux-induction-v1.json",
    "wang/data/flux-induction-v1.json",
    "wang/data/flux-induction-wang-v1.json",
    "wang/data/flux-induction-logical-v1.json",
    f"report/{STEM}.html",
)


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def closure(roots, search):
    queue = [ROOT / p for p in roots]
    lookup = {p.stem: p for d in search for p in (ROOT / d).glob("*.py")}
    selected = set()
    while queue:
        path = queue.pop()
        if path in selected:
            continue
        selected.add(path)
        for entry in ast.walk(ast.parse(path.read_text())):
            if isinstance(entry, ast.Import):
                queue.extend(lookup[n.name] for n in entry.names if n.name in lookup)
            elif isinstance(entry, ast.ImportFrom) and entry.module in lookup:
                queue.append(lookup[entry.module])
    return {str(p.relative_to(ROOT)) for p in selected}


def inputs():
    local = closure((stage for stage, cwd in STAGES if cwd == "."), ("source", "publication"))
    wang = closure(("wang/" + stage for stage, cwd in STAGES if cwd == "wang"),
                   ("wang/source",))
    wang |= closure(("wang/source/logical_records_cli_v1.py",), ("wang/source",))
    immutable = {str(p.relative_to(ROOT)) for p in (ROOT / "input").glob("*.json")}
    return sorted(local | wang | immutable | {"publication/notebook-v1.html"})


def main():
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for path in (*inputs(), *OUTPUTS):
            (clean / path).parent.mkdir(parents=True, exist_ok=True)
        for path in inputs():
            shutil.copyfile(ROOT / path, clean / path)
        for stage, cwd in STAGES:
            subprocess.run([sys.executable, "-I", "-S", "-B", stage], cwd=clean / cwd, check=True)
        receipt = {}
        for path in OUTPUTS:
            actual = (clean / path).read_bytes()
            assert actual == (ROOT / path).read_bytes(), path
            receipt[path] = pin(actual)
    receipt = dict(status="MATCHED_CLEAN_REPLAY", python=list(sys.version_info[:3]),
                   outputs=receipt, stages=STAGES)
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print("Matched", len(OUTPUTS), "generated artifacts byte for byte.", flush=True)


if __name__ == "__main__":
    main()
