# Replaying the boundary-invariant notebook

Use CPython 3.12. The exact geometry, search, and certificate code uses the standard library. Run from the extracted archive root.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The replay builds a clean tree from the retained sources and inputs. It compares every generated geometry result, search record, Wang witness, compact proof and HTML notebook byte for byte with the archived outputs.

To check only the shared induction proof from its original first-order formula, enter `wang` and run these commands.

```sh
python3.12 -I -S -B source/shared_wang_v1.py verify input/flux-induction-v1.json data/flux-induction-wang-v1.json
python3.12 -I -S -B source/logical_records_cli_v1.py verify input/flux-induction-v1.json data/flux-induction-logical-v1.json
```

The Turtle control placements are the retained small patches from the earlier Turtle hierarchy. The exact Turtle point model and the previous Penrose cavity cohort are retained as inputs. The new Turtle receivers are generated in `source/periodic_experiment_v1.py`. The signed Penrose chain is checked directly against its boundary and the unmarked rhomb palette.

The HTML uses MathJax for formulas. The mathematical and geometric checkers run offline.
