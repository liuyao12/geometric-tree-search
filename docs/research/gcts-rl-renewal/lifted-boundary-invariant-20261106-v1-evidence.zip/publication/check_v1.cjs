const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

async function main() {
  const {chromium} = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"]});
  try {
    const page = await browser.newPage({viewport: {width: 1180, height: 920}});
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/lifted-boundary-invariant-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit", timeout: 60000});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForSelector("#invariant mjx-container", {timeout: 60000});
    assert.equal(await page.locator("figure").count(), 5);
    assert.equal(await page.locator("#proof tbody tr").count(), 25);
    assert.equal(await page.locator("#search tbody tr").count(), 8);
    assert.equal(await page.locator("#penrose .negative-rhomb").count(), 1);
    assert.equal(await page.locator("#penrose .failed-port").count(), 1);
    await page.locator("#turtle details summary").click();
    assert.equal(await page.locator("#turtle details tbody tr:visible").count(), 36);
    if (!process.argv[2]) {
      await page.locator("#penrose .panels").screenshot({path: path.join(__dirname, "signed-chain-v1.png")});
      await page.locator("#turtle figure").screenshot({path: path.join(__dirname, "turtle-edits-v1.png")});
    }
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const result = {status: "CHECKED_INVARIANT_NOTEBOOK", diagrams: 5, turtleReceivers: 36,
      movableRequests: 8, proofLines: 25, mathTypeset: true, mobileNoOverflow: true};
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(result, null, 2) + "\n");
    console.log(JSON.stringify(result));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
