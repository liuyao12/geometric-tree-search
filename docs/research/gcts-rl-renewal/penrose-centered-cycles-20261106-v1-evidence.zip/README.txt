An exact fivefold Penrose plane tiling

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/center_v1.py
  python3 -I -S -B publication/render_v1.py

The first command rechecks the arrow subdivisions and exhausts the centered
sector covers, verifying center transitions for each recovered encoding.
It checks the exact nesting, the seed disk and the period-contraction
identity. Add --build to regenerate its output. The second command regenerates
the notebook. MathJax typesets its formulas.
The manifest gives SHA-256 for each included input and result.
