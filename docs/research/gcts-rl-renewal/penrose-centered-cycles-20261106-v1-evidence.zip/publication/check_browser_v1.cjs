const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/penrose-centered-cycles-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#proof mjx-container").first().waitFor();
      assert.equal(await page.locator("#search .state").count(), 6);
      assert.equal(await page.locator("#search .state.recurrent").count(), 4);
      assert.equal(await page.locator("#patch-view polygon.tri").count(), 550);
      assert.equal(await page.locator("#patch-view polygon.rhomb").count(), 260);
      await page.locator("#stage").selectOption("2");
      assert.equal(await page.locator("#patch-view polygon.tri").count(), 80);
      assert.equal(await page.locator("#patch-view polygon.seed").count(), 10);
      await page.locator("#half-edges").uncheck();
      assert.equal(await page.locator("#patch-view.hide-edges").count(), 1);
      await page.locator("#stage").selectOption("0");
      assert.equal(await page.locator("#patch-view polygon.rhomb").count(), 5);
      assert.equal(await page.locator("#growth tbody tr").count(), 6);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      await page.locator("#search").screenshot({ path: "publication/center-" + width + ".png" });
      await page.locator("#stage").selectOption("4");
      await page.locator("#patch-view").screenshot({ path: "publication/patch-" + width + ".png" });
      console.log("Verified", width, "px, center diagrams, aligned patch selector and proof equations.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
