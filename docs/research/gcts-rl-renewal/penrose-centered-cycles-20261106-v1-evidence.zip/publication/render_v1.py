"""Render the exact center-cycle proof and aligned finite Penrose patches."""
from html import escape
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from center_v1 import ZERO, edges, frozen, real, tile_vertices, turn


NAME = "penrose-centered-cycles-20261106-v1"
TITLE = "An exact fivefold Penrose plane tiling"
ZETA = complex(math.cos(2*math.pi/5), math.sin(2*math.pi/5))
POWERS = tuple(ZETA**k for k in range(4))


def point(z):
    p = sum(a*b for a, b in zip(z, POWERS, strict=True))
    return p.real, -p.imag


def coords(poly):
    return " ".join(f"{x:.4f},{y:.4f}" for x, y in poly)


def polygon(vertices, css, *, order=False):
    raw = [point(v) for v in vertices]
    if order:
        cx, cy = (sum(c)/len(raw) for c in zip(*raw, strict=True))
        raw.sort(key=lambda p: math.atan2(p[1]-cy, p[0]-cx))
    return f'<polygon class="{css}" points="{coords(raw)}"/>'


def scene(cells, label, rhombs=(), seed=(), arrows=None):
    all_points = [point(v) for p in cells for v in tile_vertices(p)]
    x, y = map(tuple, zip(*all_points, strict=True))
    pad = (max(max(x)-min(x), max(y)-min(y))) * .065
    frame = min(x)-pad, min(y)-pad, max(x)-min(x)+2*pad, max(y)-min(y)+2*pad
    triangles = "".join(polygon(tile_vertices(p), f"tri t{p[0]}") for p in cells)
    pairs = "".join(polygon(r, f"rhomb t{k}", order=True) for k, r in rhombs)
    base = "".join(polygon(tile_vertices(p), "seed") for p in seed)
    radial = []
    if arrows:
        for (a, b), lines in edges(cells, arrows).items():
            if ZERO not in (a, b):
                continue
            signed = lines[0][0]
            if signed < 0:
                a, b = b, a
            x, y = point(a)
            u, v = point(b)
            vx, vy = u-x, v-y
            for f in ((.50,) if abs(signed) == 1 else (.45, .58) if abs(signed) == 2 else (.36, .50, .64)):
                at = (x+f*vx, y+f*vy)
                w = math.hypot(vx, vy)
                dx, dy = vx/w*.065, vy/w*.065
                wings = [(at[0]-dx-dy*.65, at[1]-dy+dx*.65), at,
                         (at[0]-dx+dy*.65, at[1]-dy-dx*.65)]
                radial.append(f'<polyline class="arrow a{abs(signed)}" points="{coords(wings)}"/>')
    view = " ".join(f"{c:.5f}" for c in frame)
    return (f'<svg role="img" aria-label="{escape(label)}" viewBox="{view}">{triangles}{pairs}'
            f'{base}{"".join(radial)}<circle class="origin" cx="0" cy="0" r=".035"/></svg>')


def main():
    data = frozen(json.loads((ROOT/"data/center-v1.json").read_text()))
    source = frozen(json.loads((ROOT/"reference/standard-proof-v1.json").read_text()))
    system = data["systems"][data["standard"]]
    all_six = all(len(s["states"]) == 6 and len(s["cycles"]) == 1 and len(s["cycles"][0]) == 4
                  and s["corrected"] == ((2, 1),) for s in data["systems"])
    assert all_six
    cycle = system["cycles"][0]
    states = []
    for i, (star, j) in enumerate(zip(system["states"], system["map"], strict=True), 1):
        active = " recurrent" if i-1 in cycle else ""
        drawing = scene(star, f"Central state {i}", arrows=source["marks"])
        states.append(f'<figure class="state{active}">{drawing}<figcaption>State {i} leads to state {j+1}.</figcaption></figure>')
    stage_views = []
    for row in data["stages"]:
        if row["level"] not in (0, 2, 4):
            continue
        level, adjust = row["level"], row["alignment"]
        cells = tuple(turn(p, adjust) for p in row["cells"])
        rhombs = tuple((k, tuple(real.rotate(z, adjust) for z in r)) for k, r in row["rhombs"])
        caption = f'{len(cells)} triangles and {len(rhombs)} complete rhombs.'
        if adjust:
            caption += r" This stage is aligned by rotating it clockwise through \(36^\circ\)."
        figure = scene(cells, f"Aligned centered Penrose patch after {level} inflations", rhombs, data["seed"])
        stage_views.append(f'<template id="stage-{level}"><figure>{figure}<figcaption>{caption}</figcaption></figure></template>')
    growth = "".join(f'<tr><th scope="row">{r["level"]}</th><td>{r["total"]:,}</td><td>{r["center"]:,}</td>'
                     f'<td>{r["checked_child_candidates"]:,}</td></tr>' for r in data["growth"])
    fields = {
        "title": TITLE, "states": "".join(states), "stage_views": "".join(stage_views), "growth": growth,
        "cycle": r"\to ".join("S_{"+str(i+1)+"}" for i in (*cycle, cycle[0])),
        "systems": str(len(data["systems"])), "stem": NAME,
        "geometric": str(data["geometric_stars"]), "orbits": str(data["orbits"]),
        "reject_radial": str(system["rejected"]["unpaired radial edge"]),
        "reject_arrows": str(system["rejected"]["radial arrows disagree"]),
    }
    head = (ROOT/"publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    body = (ROOT/"publication/center-body-v1.html").read_text()
    for key, value in fields.items():
        body = body.replace("%%"+key.upper()+"%%", value)
    assert "%%" not in body
    (ROOT/"report"/(NAME+".html")).write_text(head+body)


if __name__ == "__main__":
    main()
