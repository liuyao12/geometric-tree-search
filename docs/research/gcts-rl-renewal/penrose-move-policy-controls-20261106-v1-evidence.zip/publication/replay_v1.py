"""Rebuild the move-order benchmark, audit, and visual reader in isolation."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
STEM="penrose-move-policy-controls-20261106-v1"
STAGES=("source/controlled_cases_v1.py","source/controlled_search_v1.py","source/controlled_audit_v1.py",
        "source/dominance_v1.py","publication/render_v1.py")
OUTPUTS=("input/controlled-cases-v1.json","input/heldback-witnesses-v1.json",
         "data/controlled-search-v1.json","data/controlled-audit-v1.json",
         "data/dominance-diagnostic-v1.json",f"report/{STEM}.html")
SOURCES=("boundary_search","cases","cavity_marks","cavity_pilot","check","clipping","cluster","controlled_audit",
         "controlled_cases","controlled_search","controlled_timing","dominance","geometry","model",
         "move_policy","policy_cases","triangle_geometry")
INPUTS=tuple(f"source/{name}_v1.py" for name in SOURCES)+tuple(f"input/{name}-v1.json" for name in
    ("excluded-boards","frozen-policy","hierarchy-windows","policy-training","protocol"))+(
    "publication/render_v1.py","publication/notebook-v1.html")
TIMING="data/controlled-timing-v1.json"


def pin(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())


def run(root,stage):
    subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=root,check=True)


def main():
    with TemporaryDirectory() as scratch:
        holder=Path(scratch)
        clean=holder/"run"
        clean.mkdir()
        for d in ("source","input","data","publication","report"):
            (clean/d).mkdir()
        for name in INPUTS:
            shutil.copyfile(ROOT/name,clean/name)
        run(clean,STAGES[0])
        witnesses=clean/"input/heldback-witnesses-v1.json"
        hidden=witnesses.rename(holder/"heldback.json")
        assert not witnesses.exists()
        run(clean,STAGES[1])
        hidden.rename(witnesses)
        run(clean,STAGES[2])
        run(clean,STAGES[3])
        shutil.copyfile(ROOT/TIMING,clean/TIMING)
        run(clean,STAGES[4])
        outputs={}
        for name in OUTPUTS:
            raw=(clean/name).read_bytes()
            assert raw==(ROOT/name).read_bytes(),name
            outputs[name]=pin(raw)
    info=dict(status="MATCHED_CLEAN_REPLAY",python=list(sys.version_info[:3]),outputs=outputs,
              heldback_absent_during_search=True,timing_input=pin((ROOT/TIMING).read_bytes()),stages=STAGES)
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(info,sort_keys=True,indent=2)+"\n")
    print("Matched",len(outputs),"deterministic artifacts byte for byte.",flush=True)


if __name__=="__main__":
    main()
