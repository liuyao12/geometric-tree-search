const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const {pathToFileURL} = require("node:url");

async function main() {
  const {chromium} = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({executablePath:process.env.GCTS_CHROME,
    args:["--disable-breakpad","--disable-background-networking"]});
  try {
    const page = await browser.newPage({viewport:{width:1180,height:900}});
    const errors=[];
    page.on("pageerror",error=>errors.push(error.message));
    const local=pathToFileURL(path.join(__dirname,"../report/penrose-move-policy-controls-20261106-v1.html")).href;
    const response=await page.goto(process.argv[2] || local,{waitUntil:"commit",timeout:60000});
    if (process.argv[2]) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelector("#protocol mjx-container"),null,{timeout:60000});
    assert.equal(await page.locator("#results details tbody tr").count(),120);
    assert.equal(await page.locator("#dominance tbody tr").count(),3);
    const one=page.locator(".player").first();
    const two=page.locator(".player").last();
    assert.equal(await one.locator(".current path").count(),2);
    assert.equal(await two.locator(".current path").count(),1);
    if (!process.argv[2]) await page.locator(".players").screenshot({path:path.join(__dirname,"moves-v1.png")});
    const range=one.locator("input");
    await range.evaluate((input)=>{
      input.value="0";
      input.dispatchEvent(new Event("input",{bubbles:true}));
    });
    assert.equal(await one.locator("output").innerText(),"Initial seed");
    assert.equal(await one.locator(".future[data-step='1']").count(),1);
    const max=await range.getAttribute("max");
    await range.evaluate((input,value)=>{
      input.value=value;
      input.dispatchEvent(new Event("input",{bubbles:true}));
    },max);
    assert.equal(await one.locator(".future").count(),0);
    await page.locator("#results details summary").click();
    assert(await page.locator("#results details tbody tr").last().isVisible());
    await page.setViewportSize({width:390,height:844});
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(),0);
    assert.deepEqual(errors,[]);
    const receipt={status:"CHECKED_MOVE_POLICY_READER",requests:120,players:2,
      doubletHighlight:true,stepReplay:true,mathTypeset:true,mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2]?"browser-live-v1.json":"browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}
main().catch(error=>{console.error(error);process.exitCode=1;});
