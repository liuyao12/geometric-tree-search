"""Render controlled move-policy results and interactive exact move traces."""
from html import escape
import json
from math import cos, pi, sin
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cases_v1 import frozen
from geometry_v1 import Penrose

STEM="penrose-move-policy-controls-20261106-v1"
LABELS={"unit":"Unit-first with doublets","unit_uncached":"Unit-first without cache",
        "unit_only":"Units only","seam":"Seam-first with doublets","static":"Static hybrid",
        "random":"Random hybrid","learned":"Learned hybrid"}


def read(name):
    return json.loads((ROOT/name).read_text())


def table(headers,rows,classes=None):
    headings="".join(f"<th>{h}</th>" for h in headers)
    body=[]
    for i,(first,*rest) in enumerate(rows):
        cls=classes.get(i,"") if classes else ""
        body.append(f'<tr class="{cls}"><th scope="row">{first}</th>'+
                    "".join(f"<td>{x}</td>" for x in rest)+"</tr>")
    return f'<div class="table"><table><thead><tr>{headings}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def xy(p):
    return (sum(v*cos(2*pi*k/5) for k,v in enumerate(p)),
            -sum(v*sin(2*pi*k/5) for k,v in enumerate(p)))


def path(points):
    return "M"+"L".join(f"{x:.6f},{y:.6f}" for x,y in map(xy,points))+"Z"


def player(g,row,arm,title,start):
    rings=frozen(row["rings"])
    xx,yy=zip(*(xy(p) for ring in rings for p in ring))
    x,y=min(xx),min(yy)
    w,h=max(xx)-x,max(yy)-y
    pad=.08*max(w,h)
    view=f"{x-pad:.6f} {y-pad:.6f} {w+2*pad:.6f} {h+2*pad:.6f}"
    seed=frozen(row["seed"])
    groups=[seed]+[frozen(r["patch"]) for r in arm["moves"]]
    shapes=['<path class="target" d="'+" ".join(path(r) for r in rings)+'"/>']
    for i,group in enumerate(groups):
        css="unit seed-tile" if not i else "unit"
        shapes.append(f'<g data-step="{i}"'+(' class="future"' if i>start else '')+">"+
                      "".join(f'<path class="{css}" d="{path(g.poly(t))}"/>' for t in group)+"</g>")
    return (f'<div class="player"><h3>{title}</h3><svg viewBox="{view}" role="img" '
            f'aria-label="{title} on the same Penrose region">{"".join(shapes)}</svg>'
            f'<label>Search move <input type="range" min="0" max="{len(groups)-1}" value="{start}"></label>'
            f'<output aria-live="polite"></output><p class="small">{arm["counts"]["placement_checks"]:,} placement checks in this run.</p></div>')


def main():
    data=read("data/controlled-search-v1.json")
    diagnostic=read("data/dominance-diagnostic-v1.json")
    timing=read("data/controlled-timing-v1.json")
    inputs={r["id"]:r for r in read("input/controlled-cases-v1.json")}
    ordered=("unit_only","unit","unit_uncached","seam","static","random","learned")
    whole=data["totals"]["all"]
    totals=[]
    for a in ordered:
        m=whole[a]
        counts=m["outcomes"]
        totals.append((LABELS[a],*(counts.get(k,0) for k in ("POSITIVE","NEGATIVE","BOUNDED")),
                       f'{m["nodes"]:,}',f'{m["checks"]:,}',f'{m["cache_hits"]:,}'))
    totals_table=table(("Arm","Tiled","Impossible","Bounded","Nodes","Placement checks","Cache hits"),
                       totals,{0:"best"})
    names=("unit_only","unit","seam","static","random")
    paired=[]
    for a in names:
        m=data["paired"]["all"][a]
        paired.append((LABELS[a],m["common"],*(f"{x:,}" for x in m["work"]),m["less"],m["equal"],m["more"]))
    pair_table=table(("Compared with","Common resolved","Learned checks","Control checks",
                       "Learned fewer","Equal","Learned more"),paired)
    timing_table=table(("Arm","Median seconds"),[(LABELS[a],f'{timing["median_totals"][a]/1e9:.2f}')
                      for a in ordered if a in timing["median_totals"]])
    timing_table+='<p class="small">Median of three complete runs in separate processes. Inventory construction and certificate audit are outside the timed requests.</p>'
    cases=[]
    for row in data["results"]:
        cases.append((escape(row["id"]),*(f'{row["arms"][a]["status"].title()} · {row["arms"][a]["counts"].get("nodes",0):,}'
                                            for a in ("unit_only","unit","static","learned"))))
    case_table=table(("Request","Units only · nodes","Unit-first · nodes","Static · nodes","Learned · nodes"),cases)
    g=Penrose()
    selected=[]
    for r in data["results"]:
        a,b=r["arms"]["learned"],r["arms"]["static"]
        if a["status"]!="POSITIVE" or len(a["phases"])!=1 or a["moves"]==b.get("moves"):
            continue
        action=next((i for i,m in enumerate(a["moves"],1) if len(m["patch"])==2),None)
        if action is not None:
            selected.append((r["cohort"]!="hierarchy",len(a["moves"]),r["id"],r,action))
    _,_,_,row,action=min(selected)
    left=player(g,inputs[row["id"]],row["arms"]["learned"],"Learned hybrid",action)
    right=player(g,inputs[row["id"]],row["arms"]["unit_only"],"Units only",min(action,len(row["arms"]["unit_only"]["moves"])))
    examples=f'<p class="small">Case <code>{escape(row["id"])}</code></p><div class="players">{left}{right}</div>'
    d=[]
    for arm in ("unit","static","learned"):
        v=diagnostic["totals"][arm]
        d.append((LABELS[arm],v["outcomes"].get("BOUNDED",0),f'{v["checks"]:,}',f'{v["skipped_doublets"]:,}'))
    dominance=table(("Arm with unit exclusion","Bounded","Placement checks","Doublets skipped"),d)
    html=(ROOT/"publication/notebook-v1.html").read_text()
    fields=dict(TOTALS=totals_table,PAIRS=pair_table,TIMING=timing_table,CASES=case_table,EXAMPLES=examples,
                DOMINANCE=dominance,SAMPLES=str(len(diagnostic["sampled_cuts"])),STEM=STEM)
    for key,val in fields.items():
        html=html.replace(f"%%{key}%%",val)
    assert "%%" not in html
    (ROOT/"report"/f"{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
