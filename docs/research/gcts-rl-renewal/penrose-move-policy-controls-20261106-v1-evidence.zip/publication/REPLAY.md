# Replay the controlled Penrose move-order study

Use Python 3.10 or newer with assertions enabled. The reference run used Python 3.12 and the standard library.

```sh
python3 -I -S -B publication/replay_v1.py
```

The replay authors 120 requests from the saved protocol and exact hierarchy windows. It runs seven search arms with the known tilings outside the search workspace. It then verifies the generated cases, replays donor training, checks all successful move traces, and independently exhausts impossible alternate seeds. The additional diagnostic skips doublets that contain an already exhausted unit placement and independently checks representative examples.

The recorded timing file is a rendering input so the deterministic outputs can be compared byte for byte. To measure local times again, run:

```sh
python3 -I -S -B source/controlled_timing_v1.py
```

Use Playwright and Chromium with `node publication/check_v1.cjs` to check the reader. The HTML player shows the actual move sequence from each selected witness.
