"""Package the validated report and complete reproducible search evidence."""
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0,str(Path(__file__).resolve().parent))
from replay_v1 import INPUTS, OUTPUTS, ROOT, STEM, TIMING, pin


def read(name):
    return json.loads((ROOT/name).read_text())


def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,sort_keys=True,indent=2)+"\n")


def main():
    report=ROOT/"report"
    replay=read("publication/replay-v1.json")
    assert set(replay["outputs"])==set(OUTPUTS)
    for path,value in replay["outputs"].items():
        assert pin((ROOT/path).read_bytes())==value
    assert pin((ROOT/TIMING).read_bytes())==replay["timing_input"]
    result=read("data/controlled-search-v1.json")
    diagnostic=read("data/dominance-diagnostic-v1.json")
    summary=f"report/{STEM}-results.json"
    write(summary,dict(schema="PENROSE-MOVE-POLICY-CONTROLS-v1",protocol=read("input/protocol-v1.json"),
        totals=result["totals"],paired=result["paired"],timing=read(TIMING),replay=replay,
        audit=read("data/controlled-audit-v1.json"),reader=read("publication/browser-v1.json"),
        diagnostic=diagnostic["totals"],sampled_cuts=diagnostic["sampled_cuts"]))
    paths=[ROOT/p for p in (*INPUTS,*OUTPUTS,TIMING,summary)]
    paths.extend(sorted((ROOT/"data").glob("*.log")))
    paths.extend(ROOT/"publication"/p for p in ("REPLAY.md","replay_v1.py","replay-v1.json","browser-v1.json",
                 "package_v1.py","check_v1.cjs","moves-v1.png"))
    archive=report/f"{STEM}-evidence.zip"
    pins={}
    with ZipFile(archive,"w") as bundle:
        for path in paths:
            name,raw=str(path.relative_to(ROOT)),path.read_bytes()
            if path.suffix!=".png":
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)",raw),name
            assert name not in pins
            pins[name]=pin(raw)
            item=ZipInfo(name,(2026,11,6,0,0,0))
            item.external_attr=0o100644<<16
            bundle.writestr(item,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p:pin(bundle.read(p)) for p in bundle.namelist()}==pins
    assets={p.name:pin(p.read_bytes()) for p in (report/f"{STEM}.html",ROOT/summary,archive)}
    write(f"report/{STEM}-manifest.json",dict(schema="PENROSE-MOVE-POLICY-MANIFEST-v1",
                                            assets=assets,archive_entries=pins))
    print(json.dumps(dict(assets=assets,entries=len(pins)),indent=2))


if __name__=="__main__":
    main()
