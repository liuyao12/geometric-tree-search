"""Test the effect of skipping doublets dominated by exhausted unit branches."""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from itertools import combinations
from check_v1 import contact
from controlled_audit_v1 import independent_negative,outline,replace,target,verify
from controlled_cases_v1 import read,write
from controlled_search_v1 import Study,load_rows,summarize

ARMS=("unit","static","learned")


def main():
    study=Study()
    baseline={r["id"]:r for r in read("data/controlled-search-v1.json")["results"]}
    results=[]
    cuts={}
    for row in load_rows():
        old=baseline[row["id"]]["arms"]
        arms={}
        for arm in ARMS:
            key=(row["cohort"],arm)
            sample=[] if key not in cuts else None
            result=study.run(row,arm,dominance=True,skip_sample=sample)
            if sample:
                proof,=sample
                path,edge,unit,macro=(proof[k] for k in ("path","edge","unit","macro"))
                g=study.g
                assert path[:len(row["seed"])]==row["seed"]
                assert unit in macro and edge in g.boundary(unit)
                assert edge in replace(target(g,row["rings"]),outline(g,path))
                assert all(contact(a,b) for a,b in combinations((*path,unit),2))
                receipt=independent_negative(g,dict(**{k:v for k,v in row.items() if k!="seed"},seed=(*path,unit)))
                assert receipt["status"]=="EXHAUSTED_INDEPENDENT_UNITS"
                cuts[key]=dict(case=row["id"],arm=arm,certificate=proof,receipt=receipt)
            if result["status"]=="POSITIVE":
                verify(study.g,row,result["patch"],result["moves"])
            assert result["status"]==old["unit_only"]["status"] or result["status"]=="BOUNDED"
            assert result["status"]==old[arm]["status"] or old[arm]["status"]=="BOUNDED"
            assert result["counts"].get("nodes",0)<=old[arm]["counts"].get("nodes",0)
            arms[arm]=result
        results.append(dict(id=row["id"],cohort=row["cohort"],arms=arms))
    totals=summarize(results,ARMS)
    for arm in ARMS:
        totals[arm]["skipped_doublets"]=sum(r["arms"][arm]["counts"].get("dominated_macros",0) for r in results)
    write("data/dominance-diagnostic-v1.json",dict(status="POST_HOC_DOUBLETS_DIAGNOSTIC",totals=totals,
          results=results,sampled_cuts=list(cuts.values())))
    for arm,value in totals.items():
        print(arm,value,flush=True)


if __name__=="__main__":
    main()
