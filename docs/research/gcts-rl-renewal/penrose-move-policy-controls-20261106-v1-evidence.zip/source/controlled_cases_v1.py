"""Author evaluation regions without running or consulting any search arm."""
from itertools import combinations
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region
from cases_v1 import frozen, patch_ring
from check_v1 import contact, star
from geometry_v1 import Penrose, chain, pairs, sub
from policy_cases_v1 import grow, normalize


def read(name):
    return json.loads((ROOT/name).read_text())


def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n")


def board_key(g,edges):
    return min(normalize(g,edges),normalize(g,tuple((star(b),star(a)) for a,b in edges)))


def localize(g,tiles):
    root=min(p for t in tiles for p in t)
    return tuple(sorted(g.shift(t,tuple(-x for x in root)) for t in tiles))


def pick_hierarchy(g,rng,tiles):
    owner={e:t for t in tiles for e in g.boundary(t)}
    neighbors={t:{owner[e[::-1]] for e in g.boundary(t) if e[::-1] in owner} for t in tiles}
    seen=set()
    large=[]
    for root in sorted(tiles):
        if root in seen:
            continue
        queue=[root]
        group={root}
        for t in queue:
            following=sorted(neighbors[t]-group)
            queue.extend(following)
            group.update(following)
        seen.update(group)
        if len(group)>=12:
            large.append(tuple(queue))
    assert large
    group=rng.choice(large)
    path=(rng.choice(group),)
    n=rng.randint(12,min(34,len(group)))
    while len(path)<n:
        options=sorted(set.union(*(neighbors[t] for t in path))-set(path))
        rng.shuffle(options)
        for t in options:
            if patch_ring(g,(*path,t)) is not None:
                path=(*path,t)
                break
        else:
            return None
    patch=localize(g,path)
    rings=patch_ring(g,patch)
    assert rings is not None
    return dict(rings=rings,seed=(rng.choice(patch),),witness=patch)


def different_seed(g,inv,rng,row):
    region=Region(g,row["rings"])
    witness=set(row["witness"])
    choices=sorted({tile for e in region.edges for tile, in inv.at(e)
                    if tile not in witness and region.exterior(tile) is None
                    and all(a>=b for a,b in zip(region.counts,g.mass(tile),strict=True))})
    if not choices:
        return None
    return (rng.choice(choices),)


def main():
    protocol=read("input/protocol-v1.json")
    rng=Random(protocol["author_seed"])
    g=Penrose()
    inv=Inventory(g)
    seen={board_key(g,Region(g,frozen(r)).edges) for r in read("input/excluded-boards-v1.json")}
    rows=[]
    proofs={}
    def accept(row,case,cohort,family):
        board=Region(g,row["rings"])
        key=board_key(g,board.edges)
        if key in seen:
            return False
        seen.add(key)
        assert row["seed"][0] in row["witness"]
        g.verify(row["rings"],row["witness"])
        rows.append(dict(id=case,cohort=cohort,family=family,rings=row["rings"],seed=row["seed"]))
        proofs[case]=row["witness"]
        return True

    for family in ("dense","ragged","alternating"):
        n=0
        switched=0
        for _ in range(600):
            row=grow(g,inv,rng,rng.randint(18,36),family)
            if row is None:
                continue
            case=f"generated-{family}-{n:02}"
            if not accept(row,case,"generated",family):
                continue
            n+=1
            if switched<protocol["alternate_seed_per_generated_family"]:
                new_seed=different_seed(g,inv,rng,row)
                if new_seed:
                    rows.append(dict(id=f"alternate-{family}-{switched:02}",cohort="alternate",family=family,
                                     parent=case,rings=row["rings"],seed=new_seed))
                    switched+=1
            if n==protocol["per_generated_family"]:
                break
        assert n==protocol["per_generated_family"]
        assert switched==protocol["alternate_seed_per_generated_family"],(family,switched)
    for record in read("input/hierarchy-windows-v1.json")["windows"]:
        tiles=tuple(sorted(tuple(sorted(frozen(t))) for t in record["tiles"]))
        assert len(set(tiles))==len(tiles)
        assert all(contact(a,b) for a,b in combinations(tiles,2))
        n=0
        for _ in range(600):
            row=pick_hierarchy(g,rng,tiles)
            if row is None:
                continue
            case=f'hierarchy-{record["id"]}-{n:02}'
            if accept(row,case,"hierarchy",record["id"]):
                n+=1
            if n==protocol["per_hierarchy_source"]:
                break
        assert n==protocol["per_hierarchy_source"]
    assert len(rows)==120 and len(proofs)==96
    write("input/controlled-cases-v1.json",rows)
    write("input/heldback-witnesses-v1.json",proofs)
    print("authored",len(rows),"queries over",len(proofs),"distinct fixed regions",flush=True)


if __name__=="__main__":
    main()
