"""Author disjoint Penrose patch families for move-order learning."""
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory
from cases_v1 import patch_ring
from check_v1 import contact
from geometry_v1 import Penrose, chain, sub
from model_v1 import ZERO, rhomb, rotate


def normalize(g,edges):
    options=[]
    for k in range(10):
        turned=tuple((rotate(a,k),rotate(b,k)) for a,b in edges)
        root=min(p for e in turned for p in e)
        options.append(tuple(sorted((sub(a,root),sub(b,root)) for a,b in turned)))
    return min(options)


def grow(g,inv,rng,n,family):
    initial=rhomb(ZERO,0,rng.randrange(1,3))
    patch=(initial,)
    while len(patch)<n:
        frontier=chain(g,patch)
        options={t for e in frontier for t, in inv.at(e[::-1])
                 if t not in patch and all(contact(t,p) for p in patch)}
        if not options:
            return None
        # Both growth families use a different seam prior during authoring.
        rank=[]
        for tile in sorted(options):
            sealed=sum(e[::-1] in frontier for e in g.boundary(tile))
            weight=1 if family=="dense" else -1 if family=="ragged" else (1 if len(patch)%4<2 else -1)
            priority=weight*sealed+rng.random()*2
            rank.append((priority,tile))
        for _,tile in sorted(rank,reverse=True):
            larger=(*patch,tile)
            ring=patch_ring(g,larger)
            if ring is not None:
                patch=larger
                break
        else:
            return None
    rings=patch_ring(g,patch)
    assert rings
    seed=patch[rng.randrange(n)]
    return dict(rings=rings,seed=(seed,),witness=patch)


def main():
    g=Penrose()
    inv=Inventory(g)
    rng=Random(3866217)
    seen=set()
    rows=[]
    for family in ("dense","ragged"):
        for split,count,sizes in (("train",30,range(6,13)),("test",25,range(14,23))):
            made=0
            while made<count:
                row=grow(g,inv,rng,rng.choice(sizes),family)
                if row is None:
                    continue
                key=normalize(g,chain(g,row["witness"]))
                if key in seen:
                    continue
                seen.add(key)
                rows.append(dict(id=f"{family}-{split}-{made:02}",family=family,split=split,**row))
                made+=1
    out=dict(status="AUTHORED_DISJOINT_EXACT_REGIONS",cases=rows)
    (ROOT/"input/move-policy-cases-v1.json").write_text(json.dumps(out,sort_keys=True,separators=(",",":"))+"\n")
    print(len(rows),"exact witnessed regions",flush=True)


if __name__=="__main__":
    main()
