"""Measure paired end-to-end solve time in separate interpreter processes."""
from pathlib import Path
import json
from statistics import median
import subprocess
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from controlled_cases_v1 import read,write
from controlled_search_v1 import Study,load_rows

ARMS=("unit_only","unit","static","learned")
REPEATS=3


def sample(arm):
    study=Study()
    rows=load_rows()
    result={}
    for row in rows:
        start=perf_counter_ns()
        proof=study.run(row,arm)
        result[row["id"]]=(proof["status"],perf_counter_ns()-start)
    print(json.dumps(result),flush=True)


def main():
    expected={r["id"]:r for r in read("data/controlled-search-v1.json")["results"]}
    raw={arm:[] for arm in ARMS}
    for i in range(REPEATS):
        for arm in ARMS[i:]+ARMS[:i]:
            process=subprocess.run([sys.executable,"-I","-S","-B",str(Path(__file__).resolve()),arm],
                cwd=ROOT,text=True,capture_output=True,check=True)
            sample_=json.loads(process.stdout)
            assert {k:v[0] for k,v in sample_.items()}=={k:r["arms"][arm]["status"] for k,r in expected.items()}
            raw[arm].append({k:v[1] for k,v in sample_.items()})
    sums={arm:int(median(sum(row.values()) for row in vals)) for arm,vals in raw.items()}
    write("data/controlled-timing-v1.json",dict(status="MEASURED_LOCAL_WALL_TIME",unit="nanoseconds",
        repeats=REPEATS,median_totals=sums,samples=raw))
    print(json.dumps(sums,sort_keys=True),flush=True)


if __name__=="__main__":
    if len(sys.argv)>1:
        sample(sys.argv[1])
    else:
        main()
