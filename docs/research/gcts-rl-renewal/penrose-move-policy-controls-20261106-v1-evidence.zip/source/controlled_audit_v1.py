"""Verify move traces and independently exhaust negative boards with unit rhombs."""
from collections import Counter
from fractions import Fraction
from functools import cmp_to_key, lru_cache
from itertools import combinations, pairwise
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory
from cases_v1 import frozen
from check_v1 import contact, corners
from clipping_v1 import divide, padd, product, psub, side, sign, twice
from controlled_cases_v1 import board_key,read,write
from controlled_search_v1 import load_rows
from geometry_v1 import Penrose, add, pairs, sub
from move_policy_v1 import Policy,library,run

ZERO,ONE=(0,0),(1,0)


@lru_cache(maxsize=120000)
def point(p):
    a,b,c,d=p
    return ((2*a-b)*Fraction(1,2),(b-c-d)*Fraction(1,2)),(c-d,b)


def compare(x,y):
    return sign(sub(x,y))


def crosses(a,b,poly):
    # Check the open intervals between exact line-crossing parameters.
    cuts={ZERO,ONE}
    for p,q in pairs(poly):
        first,last=side(p,q,a),side(p,q,b)
        diff=sub(last,first)
        if sign(diff):
            t=divide(tuple(-x for x in first),diff)
            if sign(t)>0 and compare(t,ONE)<0:
                cuts.add(t)
    for t,u in pairwise(sorted(cuts,key=cmp_to_key(compare))):
        mid=tuple(v/2 for v in add(t,u))
        x=padd(a,product(psub(b,a),mid))
        if all(sign(side(p,q,x))>0 for p,q in pairs(poly)):
            return True
    return False


def target(g,rings):
    return frozenset(e for r in rings for a,b in pairs(r) for e in g.atomize(a,b))


def replace(edges,addition):
    output=set(edges)
    for a,b in addition:
        if (a,b) in output:
            output.remove((a,b))
        else:
            assert (b,a) not in output
            output.add((b,a))
    return frozenset(output)


def outline(g,patch):
    edges=set()
    for tile in patch:
        assert tile in corners(tile[0])
        for a,b in pairs(g.poly(tile)):
            if (b,a) in edges:
                edges.remove((b,a))
            else:
                assert (a,b) not in edges
                edges.add((a,b))
    return frozenset(edges)


def verify(g,row,patch,moves=None):
    patch=frozen(patch)
    assert patch[:len(row["seed"])]==row["seed"] and len(set(patch))==len(patch)
    assert all(contact(a,b) for a,b in combinations(patch,2))
    edges=target(g,row["rings"])
    assert outline(g,patch)==edges
    if moves is not None:
        path=row["seed"]
        remainder=replace(edges,outline(g,path))
        for action in moves:
            change=frozen(action["patch"])
            edge=frozen(action["edge"])
            outer=outline(g,change)
            assert edge in remainder and edge in outer
            if len(change)==2:
                a,b=change
                assert any((q,p) in g.boundary(b) for p,q in g.boundary(a))
            path=(*path,*change)
            remainder=replace(remainder,outer)
        assert path==patch and not remainder
    return len(patch)


def independent_negative(g,row,cap=20000):
    rings=row["rings"]
    edges=target(g,rings)
    lines=tuple((point(a),point(b)) for r in rings for a,b in pairs(r))
    stats=Counter()
    closed=set()

    @lru_cache(maxsize=None)
    def inside(tile):
        center=tuple(map(sum,zip(*tile)))
        values=[g.wind(r,center,4) for r in rings]
        if None in values or sum(values)!=1:
            return False
        shape=tuple(point(p) for p in g.poly(tile))
        return all(not crosses(a,b,shape) for a,b in lines)

    @lru_cache(maxsize=None)
    def at(edge):
        a,b=edge
        return tuple(sorted(t for t in corners(a) if b in t and edge in pairs(g.poly(t)) and inside(t)))

    def visit(remainder,occupied):
        if stats["nodes"]>=cap:
            raise TimeoutError
        stats["nodes"]+=1
        if not remainder:
            return True
        if occupied in closed:
            stats["cache_hits"]+=1
            return False
        choices=None
        for e in sorted(remainder):
            allowed=[]
            for tile in at(e):
                stats["contact_checks"]+=1
                if tile not in occupied and all(contact(tile,u) for u in occupied):
                    allowed.append(tile)
            if choices is None or len(allowed)<len(choices):
                choices=allowed
            if not choices:
                break
        for tile in choices:
            if visit(replace(remainder,g.boundary(tile)),occupied|{tile}):
                return True
        closed.add(occupied)
        return False

    assert all(inside(t) for t in row["seed"])
    try:
        answer=visit(replace(edges,outline(g,row["seed"])),frozenset(row["seed"]))
    except TimeoutError:
        return dict(status="AUDIT_BOUND",counts=dict(stats))
    return dict(status="COUNTEREXAMPLE" if answer else "EXHAUSTED_INDEPENDENT_UNITS",counts=dict(stats))


def replay_training(g):
    source=read("input/frozen-policy-v1.json")
    donors=[{k:frozen(v) for k,v in r.items()} for r in read("input/policy-training-v1.json")]
    assert len(donors)==source["training_cases"]
    macros=library(g,Inventory(g),donors)
    assert macros==list(frozen(source["macro_bank"]))
    inv=Inventory(g,macros)
    policy=Policy()
    for _ in range(4):
        order=donors[:]
        policy.random.shuffle(order)
        for row in order:
            run(g,inv,row,policy=policy)
    assert policy.updates==source["updates"]
    assert {tuple(k):v for k,v in source["policy"]}==dict(policy.observations)
    return dict(donors=len(donors),feedback=policy.updates,weights=len(policy.observations))


def main():
    g=Penrose()
    rows={r["id"]:r for r in load_rows()}
    evidence=read("data/controlled-search-v1.json")
    targets={k:target(g,r["rings"]) for k,r in rows.items()}
    heldback=read("input/heldback-witnesses-v1.json")
    seen={board_key(g,target(g,frozen(r))) for r in read("input/excluded-boards-v1.json")}
    for key,witness in heldback.items():
        assert key in rows and rows[key]["cohort"]!="alternate"
        key_shape=board_key(g,targets[key])
        assert key_shape not in seen
        seen.add(key_shape)
        prepared=frozen(witness)
        seed=rows[key]["seed"]
        verify(g,rows[key],(*seed,*(t for t in prepared if t not in seed)))
    checked=Counter()
    negatives={}
    for raw in evidence["results"]:
        row=rows[raw["id"]]
        if row["cohort"]=="alternate":
            parent=rows[row["parent"]]
            assert targets[row["id"]]==targets[parent["id"]]
            assert all(t not in frozen(heldback[parent["id"]]) for t in row["seed"])
        statuses=set()
        for name,result in raw["arms"].items():
            states=result["phases"]
            assert sum(s["counts"].get("nodes",0) for s in states)==result["counts"].get("nodes",0)<=1200
            assert all(s["status"]=="BOUNDED" for s in states[:-1])
            if result["status"]=="POSITIVE":
                verify(g,row,result["patch"],result["moves"])
                checked["solution_traces"]+=1
            statuses.add(result["status"])
        if "NEGATIVE" in statuses:
            assert statuses<={"NEGATIVE","BOUNDED"}
            receipt=independent_negative(g,row)
            assert receipt["status"]!="COUNTEREXAMPLE",row["id"]
            negatives[row["id"]]=receipt
            checked[receipt["status"]]+=1
    training=replay_training(g)
    write("data/controlled-audit-v1.json",dict(status="CHECKED_MOVE_POLICY_CONTROLS",audit=dict(checked),
            negative_audits=negatives,training=training))
    print(dict(checked),training,flush=True)


if __name__=="__main__":
    main()
