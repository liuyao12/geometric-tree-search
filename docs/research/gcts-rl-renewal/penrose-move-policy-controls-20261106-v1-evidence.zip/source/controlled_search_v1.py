"""Compare frozen move ranking with matched geometric and cache controls."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import frozen
from cavity_marks_v1 import CavityBank
from controlled_cases_v1 import read, write
from geometry_v1 import Penrose
from move_policy_v1 import Policy


class RandomOrder:
    def __init__(self,seed):
        self.rng=Random(seed)

    def rank(self,region,edges,edge,remaining,proposals,inventory):
        values=[(p,None) for p in proposals]
        self.rng.shuffle(values)
        return values


def load_rows():
    return [{k:frozen(v) for k,v in row.items()} for row in read("input/controlled-cases-v1.json")]


class Study:
    def __init__(self):
        self.g=Penrose()
        self.protocol=read("input/protocol-v1.json")
        saved=read("input/frozen-policy-v1.json")
        assert saved["ratio"]=="1" and self.protocol["macro_offer_cap"]==5
        macros=frozen(saved["macro_bank"])
        assert all(len(p)==2 for p in macros)
        self.units=Inventory(self.g)
        self.inventory=Inventory(self.g,macros)
        self.policy=Policy()
        self.policy.training=False
        self.policy.observations.update((tuple(k),v) for k,v in saved["policy"])

    def stage(self,row,inv,order,policy,limit,dead,dominance=False,skip_sample=None):
        result=solve(Region(self.g,row["rings"]),inv,row["id"],order=order,limit=limit,
                     seed=row["seed"],cavities=CavityBank(learn=False),policy=policy,dead=dead,
                     dominance=dominance,skip_sample=skip_sample)
        assert result["counts"].get("nodes",0)<=limit
        return result

    def run(self,row,name,dominance=False,skip_sample=None):
        budget=self.protocol["node_budget"]
        inventory=self.units if name=="unit_only" else self.inventory
        cache=None if name=="unit_uncached" else set()
        phases=[]
        if name in ("static","learned","random"):
            short=sum(Region(self.g,row["rings"]).counts)
            mode=None
            if name=="learned":
                mode=self.policy
            elif name=="random":
                digest=sha256(row["id"].encode()).digest()
                mode=RandomOrder(self.protocol["random_seed"]+int.from_bytes(digest[:8],"big"))
            attempt=self.stage(row,inventory,"large",mode,short,cache,dominance,skip_sample)
            phases.append(attempt)
            budget-=attempt["counts"].get("nodes",0)
        if not phases or phases[-1]["status"]=="BOUNDED":
            phases.append(self.stage(row,inventory,"seal" if name=="seam" else "single",None,budget,cache,
                                     dominance,skip_sample))
        counts=Counter()
        for phase in phases:
            counts.update(phase["counts"])
        assert counts["nodes"]<=self.protocol["node_budget"]
        last=phases[-1]
        return dict(status=last["status"],counts=dict(counts),phases=[
                    dict(status=p["status"],counts=p["counts"]) for p in phases],
                    **{key:last[key] for key in ("patch","moves","reason") if key in last})


def summarize(rows,arms):
    out={}
    for name in arms:
        results=[r["arms"][name] for r in rows]
        out[name]=dict(outcomes=dict(Counter(r["status"] for r in results)),
                       nodes=sum(r["counts"].get("nodes",0) for r in results),
                       checks=sum(r["counts"].get("placement_checks",0) for r in results),
                       cache_hits=sum(r["counts"].get("closed_state_hits",0) for r in results),
                       fallbacks=sum(len(r["phases"])>1 for r in results),
                       ranked=sum(r["counts"].get("ranked_nodes",0) for r in results),
                       reordered=sum(r["counts"].get("first_choice_changed",0) for r in results))
    return out


def paired(rows,left,right):
    common=[r for r in rows if all(r["arms"][a]["status"]!="BOUNDED" for a in (left,right))]
    assert all(r["arms"][left]["status"]==r["arms"][right]["status"] for r in common)
    checks=[tuple(r["arms"][a]["counts"].get("placement_checks",0) for a in (left,right)) for r in common]
    return dict(common=len(common),work=[sum(p[i] for p in checks) for i in (0,1)],
                less=sum(a<b for a,b in checks),equal=sum(a==b for a,b in checks),
                more=sum(a>b for a,b in checks))


def main():
    rows=load_rows()
    study=Study()
    names=study.protocol["arms"]
    checked=[]
    for row in rows:
        arms={name:study.run(row,name) for name in names}
        statuses={a["status"] for a in arms.values()}-{"BOUNDED"}
        assert len(statuses)<=1
        if row["cohort"]!="alternate":
            assert "NEGATIVE" not in statuses
        checked.append(dict(id=row["id"],cohort=row["cohort"],family=row["family"],arms=arms))
        print(row["id"],[(name,a["status"],a["counts"].get("nodes",0)) for name,a in arms.items()],flush=True)
    assert study.policy.updates==0
    groups={"all":checked}
    for key in ("generated","alternate","hierarchy"):
        groups[key]=[r for r in checked if r["cohort"]==key]
    totals={k:summarize(v,names) for k,v in groups.items()}
    comparisons={k:{a:paired(v,"learned",a) for a in names if a!="learned"} for k,v in groups.items()}
    write("data/controlled-search-v1.json",dict(status="RAN_FROZEN_MOVE_POLICY_CONTROLS",
          results=checked,totals=totals,paired=comparisons))
    print(json.dumps(totals["all"],sort_keys=True),flush=True)


if __name__=="__main__":
    main()
