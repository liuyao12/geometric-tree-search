"""Directed boundary search and transferable no-placement markings."""
from collections import Counter, defaultdict
from itertools import combinations
from hashlib import sha256
import json

from geometry_v1 import add, area, chain, check_rings, lattice_sites, mul, pairs, sub
import check_v1 as independent
import model_v1 as penrose


class Region:
    def __init__(self, geometry, rings):
        self.g, self.rings = geometry,rings
        check_rings(geometry,rings)
        self.lines = tuple(e for ring in rings for e in pairs(ring))
        self.edges = frozenset(e for a,b in self.lines for e in geometry.atomize(a,b))
        totals = tuple(map(sum,zip(*(area(r,geometry.cross) for r in rings))))
        self.counts = geometry.counts(totals)
        self.sites = lattice_sites(geometry,rings) if geometry.kind=="turtle" else None
        if self.sites is not None:
            s=geometry.model.scale
            assert sum(geometry.model.residues[x%s,y%s] for x,y in self.sites)==totals[0]
        self.containment = {}
        self.insides = {}

    def inside(self,p,den):
        k=(p,den)
        if k not in self.insides:
            values=[self.g.wind(r,p,den) for r in self.rings]
            self.insides[k] = None not in values and sum(values)==1
        return self.insides[k]

    def exterior(self,t):
        if t not in self.containment:
            if self.sites is not None:
                diff=self.g.sites(t)-self.sites
                witness=("site",min(diff)) if diff else None
            else:
                p=tuple(map(sum,zip(*t)))
                if not self.inside(p,4):
                    witness=("center",p)
                else:
                    witness=next((("line",a,b) for a,b in self.lines if self.g.intrudes(a,b,t)),None)
            self.containment[t]=witness
        return self.containment[t]

    def block(self,t,occupied):
        witness=self.exterior(t)
        if witness is not None:
            return witness
        if self.sites is not None:
            overlap=self.g.sites(t)&occupied
            return ("site",min(overlap)) if overlap else None
        return next((("tile",other) for other in sorted(occupied)
                     if not penrose.legal_contact(t,other)),None)

    def relocate(self,guard,offset):
        kind,*q=guard
        if kind=="site":
            return kind,add(q[0],mul(self.g.model.scale,offset))
        if kind=="center":
            return kind,add(q[0],mul(4,offset))
        if kind=="line":
            return kind,*(add(p,offset) for p in q)
        assert kind=="tile"
        return kind,self.g.shift(q[0],offset)

    def blocked(self,guard,occupied):
        kind,*q=guard
        if kind=="site":
            return q[0] not in self.sites or q[0] in occupied
        if kind=="center":
            return not self.inside(q[0],4)
        if kind=="line":
            return tuple(q) in self.lines
        assert kind=="tile"
        return q[0] in occupied

    def certify(self,t,guard,occupied):
        kind,*q=guard
        if kind=="site":
            assert q[0] in self.g.sites(t)
        elif kind=="center":
            assert q[0]==tuple(map(sum,zip(*t)))
        elif kind=="line":
            assert self.g.intrudes(*q,t)
        else:
            assert kind=="tile" and not independent.contact(t,q[0])
        assert self.blocked(guard,occupied)

    def extend(self,occupied,patch):
        if self.sites is not None:
            return occupied.union(*(self.g.sites(t) for t in patch))
        return occupied.union(patch)


def remove(edges,boundary):
    ans=set(edges)
    for a,b in boundary:
        if (a,b) in ans:
            ans.remove((a,b))
        else:
            assert (b,a) not in ans
            ans.add((b,a))
    return frozenset(ans)


class Inventory:
    def __init__(self,geometry,learned=()):
        self.g=geometry
        self.units=self.index((t,) for t in geometry.bases)
        normalized=set()
        for patch in learned:
            for g in geometry.turns:
                turned=[geometry.turn(t,g) for t in patch]
                anchor=min(p for t in turned for p in geometry.poly(t))
                normalized.add(tuple(sorted(geometry.shift(t,mul(-1,anchor)) for t in turned)))
        self.macros=self.index(sorted(normalized))
        self.macro_boundary={patch:chain(self.g,patch) for group in self.macros.values() for patch in group}
        self.macro_receptors={}
        for ray,templates in self.macros.items():
            by_edge=defaultdict(list)
            for patch in templates:
                for e in self.macro_boundary[patch]:
                    if e!=(geometry.zero,ray):
                        by_edge[e].append(patch)
            self.macro_receptors[ray]=dict(by_edge)
        self.cluster_poses=len(normalized)

    def index(self,patches):
        groups=defaultdict(set)
        for patch in patches:
            for a,b in chain(self.g,patch):
                local=tuple(sorted(self.g.shift(t,mul(-1,a)) for t in patch))
                groups[sub(b,a)].add(local)
        return {d:tuple(sorted(rows)) for d,rows in groups.items()}

    def at(self,edge):
        a,b=edge
        return tuple(tuple(self.g.shift(t,a) for t in row)
                     for row in self.units.get(sub(b,a),()))

    def direction_count(self,edge):
        return len(self.units.get(sub(edge[1],edge[0]),()))

    def offers(self,edge,frontier):
        anchor,other=edge
        index=self.macro_receptors.get(sub(other,anchor))
        if not index:
            return
        counts=Counter()
        for a,b in frontier:
            counts.update(index.get((sub(a,anchor),sub(b,anchor)),()))
        for local,extra in counts.items():
            yield tuple(self.g.shift(t,anchor) for t in local),local,extra+1

    def placed_boundary(self,local,anchor):
        return frozenset((add(a,anchor),add(b,anchor)) for a,b in self.macro_boundary[local])


class Bank:
    def __init__(self):
        self.rules=defaultdict(dict)
        self.donors={}
        self.hits=[]

    def learn(self,region,edge,guards,placements,occupied,case,path):
        a,b=edge
        assert len(guards)==len(placements)
        for (t,),w in zip(placements,guards,strict=True):
            region.certify(t,w,occupied)
        key=sub(b,a)
        local=tuple(region.relocate(w,mul(-1,a)) for w in guards)
        if local not in self.rules[key]:
            digest=sha256(json.dumps([key,local],separators=(",",":")).encode()).hexdigest()
            self.rules[key][local]=digest
            self.donors[digest]=dict(case=case,edge=edge,local=local,placed=path)

    def find(self,region,edge,occupied,case,path,stats):
        a,b=edge
        for local,digest in self.rules.get(sub(b,a),{}).items():
            stats["mark_trials"]+=1
            if all(region.blocked(region.relocate(w,a),occupied) for w in local):
                self.hits.append(dict(donor=digest,case=case,edge=edge,placed=path))
                stats["mark_hits"]+=1
                if self.donors[digest]["case"]!=case:
                    stats["boundary_transfer"]+=1
                return True
        return False


def solve(region,inv,case,bank=None,order="large",limit=2000,inspect=6,*,seed=(),cavities=None,first_port=None,
          policy=None,dead=None,dominance=False,skip_sample=None):
    counts=Counter()
    actions=[]
    if region.counts is None:
        return dict(status="NEGATIVE",reason="EXACT_AREA",counts={})
    g=region.g
    initial_edges=region.edges
    initial_occupied=frozenset()
    initial_remaining=region.counts
    for tile in seed:
        assert region.block(tile,initial_occupied) is None
        initial_edges=remove(initial_edges,g.boundary(tile))
        initial_occupied=region.extend(initial_occupied,(tile,))
        initial_remaining=sub(initial_remaining,g.mass(tile))
    if any(v<0 for v in initial_remaining):
        return dict(status="NEGATIVE",reason="SEED_AREA",counts={})

    def test(t,occupied):
        counts["placement_checks"]+=1
        return region.block(t,occupied)

    def visit(edges,occupied,path,remaining):
        if counts["nodes"]>=limit:
            raise TimeoutError
        counts["nodes"]+=1
        if dead is None:
            return expand(edges,occupied,path,remaining)
        key=edges,occupied,remaining
        if key in dead:
            counts["closed_state_hits"]+=1
            return None
        result=expand(edges,occupied,path,remaining)
        if result is None:
            dead.add(key)
        return result

    def expand(edges,occupied,path,remaining):
        if not edges:
            assert not any(remaining)
            return path,tuple(actions)
        if cavities is not None:
            frontier=(region.edges-edges)|frozenset((b,a) for a,b in edges-region.edges)
            if cavities.cut(region,None,frontier,path,case,counts):
                return None
        port=first_port if len(path)==len(seed) else None
        assert port is None or port in edges
        ranked=sorted(edges,key=lambda e:(e!=port,bool(seed and e in region.edges),inv.direction_count(e),e))
        if bank is not None and any(bank.find(region,e,occupied,case,path,counts) for e in ranked
                                    if sub(e[1],e[0]) in bank.rules):
            return None
        roots=ranked[:inspect]
        best=None
        for edge in roots:
            places=inv.at(edge)
            blocks=[test(t,occupied) for (t,) in places]
            if all(w is not None for w in blocks):
                if bank is not None:
                    bank.learn(region,edge,blocks,places,occupied,case,path)
                return None
            moves=[p for p,w in zip(places,blocks,strict=True) if w is None]
            if best is None or len(moves)<len(best[1]):
                best=(edge,moves)
            if len(moves)==1:
                break
        edge,moves=best
        def priority(item):
            patch,_,sealed=item
            if order=="large":
                return -len(patch),-sealed,patch
            if order=="seal":
                return -sealed,-len(patch),patch
            assert order=="single"
            return len(patch),-sealed,patch
        def options():
            singles=[(patch,boundary,len(boundary&edges))
                     for patch in moves for boundary in (chain(g,patch),)]
            offered=list(inv.offers(edge,edges))
            counts["cluster_offers"]+=len(offered)
            admitted=sorted(offered,key=lambda p:(-p[2],-len(p[0]),p[0]))[:5]
            return sorted(singles+admitted,key=priority)
        proposals=options()
        if len(proposals)>1:
            counts["ambiguous_nodes"]+=1
        tagged=[(proposal,None) for proposal in proposals]
        if policy is not None and len(proposals)>1:
            tagged=policy.rank(region,edges,edge,remaining,proposals,inv)
            counts["ranked_nodes"]+=1
            counts["first_choice_changed"]+=tagged[0][0]!=proposals[0]
        excluded_units=set()
        for (patch,contour,_),observation in tagged:
            if dominance and len(patch)>1 and any(t in excluded_units for t in patch):
                counts["dominated_macros"]+=1
                if skip_sample is not None and not skip_sample:
                    skip_sample.append(dict(path=path,edge=edge,unit=min(excluded_units&set(patch)),macro=patch))
                continue
            left=tuple(n-sum(g.mass(t)[i] for t in patch) for i,n in enumerate(remaining))
            if any(n<0 for n in left):
                continue
            if len(patch)>1 and any(test(t,occupied) is not None for t in patch):
                if observation is not None:
                    policy.feedback(observation,False,0)
                continue
            boundary=inv.placed_boundary(contour,edge[0]) if len(patch)>1 else contour
            counts["branches"]+=1
            if len(patch)>1:
                counts["cluster_branches"]+=1
            actions.append(dict(edge=edge,patch=patch))
            before=counts["nodes"]
            out=visit(remove(edges,boundary),region.extend(occupied,patch),(*path,*patch),left)
            if observation is not None:
                policy.feedback(observation,out is not None,counts["nodes"]-before)
            if out is not None:
                return out
            if dominance and len(patch)==1:
                excluded_units.add(patch[0])
            actions.pop()
        return None

    try:
        result=visit(initial_edges,initial_occupied,seed,initial_remaining)
    except TimeoutError:
        return dict(status="BOUNDED",reason="NODE_LIMIT",counts=dict(counts))
    counts["unique_containment_tests"]=len(region.containment)
    if result is None:
        return dict(status="NEGATIVE",reason="EXHAUSTED",counts=dict(counts))
    patch,moves=result
    assert len(set(patch))==len(patch) and chain(g,patch)==region.edges
    return dict(status="POSITIVE",counts=dict(counts),patch=patch,moves=moves)
