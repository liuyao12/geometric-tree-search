"""Learn Penrose unit and macro move rankings from exact search rollouts."""
from collections import Counter, defaultdict
from itertools import combinations
import json
from math import log1p
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import frozen
from cavity_marks_v1 import CavityBank
from geometry_v1 import Penrose, chain
from policy_cases_v1 import normalize

LIMIT=1200


def run(g,inv,row,order="large",policy=None,limit=LIMIT,dead=None):
    region=Region(g,row["rings"])
    result=solve(region,inv,row["id"],order=order,limit=limit,seed=row["seed"],
                 cavities=CavityBank(learn=False),policy=policy,dead=dead)
    if result["status"]=="POSITIVE":
        assert result["patch"][:len(row["seed"])]==row["seed"]
        g.verify(row["rings"],result["patch"])
    return result


def library(g,inv,rows):
    counts=Counter()
    options={}
    for row in rows:
        result=run(g,inv,row)
        assert result["status"]=="POSITIVE"
        for a,b in combinations(result["patch"],2):
            first,second=g.boundary(a),g.boundary(b)
            if any(e[::-1] in first for e in second):
                pair=tuple(sorted((a,b)))
                key=normalize(g,chain(g,pair))
                counts[key]+=1
                options.setdefault(key,pair)
    return [options[key] for key,_ in sorted(counts.items(),key=lambda r:(-r[1],r[0]))[:10]]


class Policy:
    def __init__(self):
        self.random=Random(945671)
        self.observations=defaultdict(lambda:[0.0,0])
        self.training=True
        self.decisions=0
        self.updates=0

    def rank(self,region,edges,edge,remaining,proposals,inventory):
        self.decisions+=1
        entries=[]
        for index,proposal in enumerate(proposals):
            patch,local,matches=proposal
            boundary=inventory.placed_boundary(local,edge[0]) if len(patch)>1 else local
            thin=sum(region.g.mass(t)[0] for t in patch)
            target_contacts=len(boundary&edges&region.edges)
            core_contacts=len(boundary&edges)-target_contacts
            features=(len(patch),matches,thin)
            context=(*features,target_contacts,core_contacts,int(sum(remaining)>8))
            base=self.observations.get(features,(0,0))
            specific=self.observations.get(context,(0,0))
            score=(base[0]+3*specific[0])/(3+base[1]+3*specific[1])
            entries.append((-score,index,proposal,(features,context)))
        entries.sort()
        if self.training and self.random.random()<.24:
            i=self.random.randrange(len(entries))
            entries.insert(0,entries.pop(i))
        return [(entry[2],entry[3]) for entry in entries]

    def feedback(self,observation,success,work):
        if not self.training:
            return
        self.updates+=1
        reward=(4.0 if success else -2.0)-0.35*log1p(work)
        for key in observation:
            values=self.observations[key]
            values[0]+=reward
            values[1]+=1


def main():
    raw=json.loads((ROOT/"input/move-policy-cases-v1.json").read_text())
    rows=[{k:frozen(v) for k,v in r.items()} for r in raw["cases"]]
    train=[r for r in rows if r["split"]=="train"]
    test=[r for r in rows if r["split"]=="test"]
    g=Penrose()
    inv=Inventory(g)
    macros=library(g,inv,train)
    inv=Inventory(g,macros)
    policy=Policy()
    for _ in range(4):
        order=train[:]
        policy.random.shuffle(order)
        for row in order:
            run(g,inv,row,policy=policy)
    assert policy.updates
    policy.training=False
    updates=policy.updates
    observed=[]
    print("trained",len(train),len(macros),updates,flush=True)
    for row in test:
        runs={order:run(g,inv,row,order=order) for order in ("large","seal","single")}
        runs["learned"]=run(g,inv,row,policy=policy)
        observed.append(dict(id=row["id"],family=row["family"],arms=runs))
    assert policy.updates==updates
    totals={}
    for name in observed[0]["arms"]:
        vals=[r["arms"][name] for r in observed]
        totals[name]=dict(solved=sum(r["status"]=="POSITIVE" for r in vals),
                          nodes=sum(r["counts"]["nodes"] for r in vals),
                          placement_checks=sum(r["counts"]["placement_checks"] for r in vals),
                          ambiguous_nodes=sum(r["counts"].get("ambiguous_nodes",0) for r in vals))
    out=dict(status="RAN_MOVE_POLICY_PILOT",training_cases=len(train),evaluation_cases=len(test),
             updates=updates,macro_bank=macros,policy=[(key,value) for key,value in sorted(policy.observations.items())],
             totals=totals,results=observed)
    (ROOT/"data/move-policy-v1.json").write_text(json.dumps(out,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(totals,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
