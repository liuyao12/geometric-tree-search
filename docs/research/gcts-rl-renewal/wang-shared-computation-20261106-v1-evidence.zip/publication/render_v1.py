"""Render the shared-palette experiment and the decoded proof reader."""
from html import escape
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from proof_views_v1 import clause, explanation, expression, formula, load_frame, math, window_svg
from boundary_kernel_v1 import build
from lifted_experiment_v1 import ROOT, load
from native_marked_v1 import records

STEM="wang-shared-computation-20261106-v1"
OUTCOMES={"PROVED":"Checked proof","CLOSED":"Repeated state","BOUNDED":"Configuration bound",
          "DEPTH_BOUND":"Depth bound"}
FIRST_ORDER={"three-equivalences":"Three equivalences", "three-applications":"Three applications",
             "five-applications":"Five applications", "independent-predicates":"Independent predicates"}


def table(heads,rows):
    headings="".join(f"<th>{h}</th>" for h in heads)
    return f'<div class="table"><table><thead><tr>{headings}</tr></thead><tbody>{table_body(rows)}</tbody></table></div>'


def proof_view(key,name,proof,words,context=""):
    rows=[]
    for i,(line,(code,note)) in enumerate(zip(proof["lines"],words,strict=True),1):
        text=(f"<details><summary>Tile record</summary><code>{escape(code)}</code></details>"
              +f'<span class="small">{note}</span>')
        rows.append((i,math(clause(line["clause"])),explanation(line),text))
    body=table(("Line","Decoded formula","Derivation","Wang record"),rows)
    return (f'<details class="proof-lines" id="proof-{key}"><summary>{escape(name)} · {len(rows)} lines</summary>'
            f"{context}{body}</details>")


def computation_view(row,evidence):
    program=row["case"]["program"]
    command_rows=[(i,escape(" ".join(str(v) for v in op))) for i,op in enumerate(program)]
    context=table(("Address","Instruction"),command_rows) if command_rows else "<p>The program is empty.</p>"
    context+=f'<p>Initial configuration {math(expression(row["configurations"][0]))} after address normalization.</p>'
    words=[(code,f"Commit row {step+1:,}") for code,(step,_) in
           zip(records(evidence["word"][:-1]),evidence["commits"],strict=True)]
    return proof_view(row["id"],row["id"]+" · "+row["case"]["name"],row["proof"],words,context)


def logic_view(row,receipt,bank):
    original=row["original"]
    context='<ul class="formula-list">'+ "".join(
        "<li>Premise "+math(formula(p))+"</li>" for p in original["premises"])
    context+="<li>Conclusion "+math(formula(original["goal"]))+"</li></ul>"
    words=[(bank[c["fragment"]]["word"],
            f'{bank[c["fragment"]]["steps"]:,} patch transitions') for c in receipt["calls"]]
    return proof_view(original["id"],FIRST_ORDER[original["id"]],row["proof"],words,context)


def main():
    results=load("data/cm2-search-v1.json")["results"]
    audit=load("data/cm2-audit-v1.json")
    fair=load("data/fair-ground-v1.json")["results"]
    fair_audit=load("data/fair-ground-audit-v1.json")
    machine=build().compile()
    assert machine.digest()==audit["machine_sha256"]==fair_audit["machine_sha256"]
    bank=load_frame("data/fair-ground-fragments-v1.json.gz")
    computes,ground,proofs=[],[],[]
    for row,item in zip(results,audit["results"],strict=True):
        case_id=row["id"]
        assert case_id==item["id"]
        proof=row["proof"]
        link=f'<a href="#proof-{case_id}">{case_id}</a>' if proof else case_id
        computes.append((link+" "+escape(row["case"]["name"]),OUTCOMES[row["status"]],
                         len(row["configurations"]),len(row["compiled"]["clauses"]),
                         len(proof["lines"]) if proof else "—",
                         f'{item["receipt"]["steps"]:,}' if proof else "—"))
        if proof:
            evidence=load_frame(item["frame"])
            proofs.append(computation_view(row,evidence))
        if case_id=="C02":
            svg,caption=window_svg(machine,evidence,evidence["commits"][-1])
            frame=f"<figure>{svg}<figcaption>{caption} At the final resolution commit.</figcaption></figure>"
            states=table(("Proof line","Derived configuration"),
                         [(2*i+1,math(expression(x))) for i,x in enumerate(row["configurations"])])
    receipts={r["id"]:r for r in fair_audit["receipts"]}
    for row in fair:
        id_=row["original"]["id"]
        proof=row["proof"]
        last=row["attempts"][-1]
        ground.append((FIRST_ORDER[id_],last["depth"],last["ground_instances"],
                       OUTCOMES[row["status"]],len(proof["lines"]) if proof else "—"))
        if proof:
            proofs.append(logic_view(row,receipts[id_],bank))
    parts=dict(STEM=STEM,DIGEST=machine.digest(),COMPUTATIONS=table_body(computes),
               GROUND=table_body(ground),FRAME=frame,C02STATES=states,PROOFS="\n".join(proofs),
               ARGUMENT=(ROOT/"publication/argument-v1.html").read_text())
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for k,v in parts.items():
        html=html.replace(f"%%{k}%%",v)
    assert "%%" not in html
    (ROOT/"report").mkdir(exist_ok=True)
    (ROOT/"report"/f"{STEM}.html").write_text(html)


def table_body(rows):
    return "".join('<tr>'+f'<th scope="row">{a}</th>'+"".join(f"<td>{x}</td>" for x in rest)+"</tr>"
                   for a,*rest in rows)


if __name__=="__main__":
    main()
