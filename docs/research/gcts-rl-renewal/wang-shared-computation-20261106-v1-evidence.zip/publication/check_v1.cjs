const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1180, height: 920 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-shared-computation-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit", timeout: 60000});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelector("#fairness mjx-container") &&
      document.querySelectorAll(".wang-cell").length === 45, null, {timeout: 60000});
    assert.equal(await page.locator("#computations tbody").first().locator("tr").count(), 7);
    assert.equal(await page.locator("#grounding tbody tr").count(), 4);
    assert.equal(await page.locator("#reader details.proof-lines").count(), 8);
    assert.equal(await page.locator("#reader summary", {hasText: "Tile record"}).count(), 116);
    await page.locator('#computations a[href="#proof-C02"]').click();
    const cm2 = page.locator("#proof-C02");
    assert.equal(await cm2.getAttribute("open"), "");
    await cm2.locator("tbody").last().locator("details summary").last().click();
    assert.match(await cm2.locator("td details code").last().innerText(), /^R110:/);
    const fol = page.locator("#proof-five-applications");
    await fol.locator("summary").first().click();
    assert.equal(await fol.locator("tbody tr").count(), 25);
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    if (!process.argv[2]) {
      await page.setViewportSize({width: 1180, height: 920});
      await page.locator("#computations .dual").screenshot({path: path.join(__dirname, "tile-view-v1.png")});
    }
    const receipt = {status: "CHECKED_SHARED_WANG_READER", computations: 7, firstOrderTrials: 4,
      certificates: 8, decodedProofLines: 116, wangSquares: 45, mobileNoOverflow: true, mathTypeset: true};
    fs.writeFileSync(path.join(__dirname,process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}
main().catch(error => {console.error(error); process.exitCode = 1;});
