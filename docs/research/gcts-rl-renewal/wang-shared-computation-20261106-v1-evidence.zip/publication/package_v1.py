"""Pin the public notebook and its complete replay evidence."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT=Path(__file__).resolve().parents[1]
STEM="wang-shared-computation-20261106-v1"
STAGES=("cm2_horn","cm2_horn_audit","fair_ground","fair_ground_audit","shared_wang_audit")
OUTPUTS=tuple(str(p.relative_to(ROOT)) for p in sorted((ROOT/"data").glob("*-v1.json*")))+(
    f"report/{STEM}.html",)


def pin(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())


def load(path):
    return json.loads((ROOT/path).read_text())


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")


def dependencies():
    local={p.stem:p for d in ("source","publication") for p in (ROOT/d).glob("*.py")}
    todo=[local[x+"_v1"] for x in (*STAGES,"shared_wang","render","package","replay")]
    seen=set()
    while todo:
        path=todo.pop()
        if path in seen:
            continue
        seen.add(path)
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.Import):
                todo.extend(local[n.name] for n in node.names if n.name in local)
            elif isinstance(node,ast.ImportFrom) and node.module in local:
                todo.append(local[node.module])
    return sorted(seen)


def main():
    report=ROOT/"report"
    replay=load("publication/replay-v1.json")
    assert set(replay["outputs"])==set(OUTPUTS)
    for path,expected in replay["outputs"].items():
        assert pin((ROOT/path).read_bytes())==expected
    cm2=load("data/cm2-audit-v1.json")
    fair=load("data/fair-ground-audit-v1.json")
    cli=load("data/cli-audit-v1.json")
    summary=f"report/{STEM}-results.json"
    save(summary,dict(schema="SHARED-WANG-COMPUTATION-RESULTS-v1",cm2=cm2,fair=fair,cli=cli,
                      policy_source=load("input/tactic-policy-v1.json"),replay=replay,
                      reader=load("publication/browser-v1.json")))
    paths=dependencies()+sorted((ROOT/"input").glob("*-v1.json"))+[ROOT/n for n in (*OUTPUTS,summary)]
    paths.extend(sorted((ROOT/"data").glob("*.log")))
    paths.extend(ROOT/"publication"/p for p in ("REPLAY.md","replay-v1.json","browser-v1.json",
                  "notebook-v1.html","argument-v1.html","check_v1.cjs","tile-view-v1.png"))
    archive=report/f"{STEM}-evidence.zip"
    pins={}
    with ZipFile(archive,"w") as bundle:
        for path in paths:
            name,raw=str(path.relative_to(ROOT)),path.read_bytes()
            if path.suffix not in (".gz",".png"):
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)",raw),name
            assert name not in pins
            pins[name]=pin(raw)
            item=ZipInfo(name,(2026,11,6,0,0,0))
            item.external_attr=0o100644<<16
            bundle.writestr(item,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p:pin(bundle.read(p)) for p in bundle.namelist()}==pins
    assets={p.name:pin(p.read_bytes()) for p in (report/f"{STEM}.html",ROOT/summary,archive)}
    save(f"report/{STEM}-manifest.json",dict(schema="SHARED-WANG-COMPUTATION-MANIFEST-v1",
                                           assets=assets,archive_entries=pins))
    print(json.dumps(dict(assets=assets,entries=len(pins)),indent=2))


if __name__=="__main__":
    main()
