# Replay the shared Wang computation and proof study

Run from the extracted archive root with Python 3.10 or newer. The recorded replay used Python 3.12. Leave assertions enabled. The programs use only the Python standard library.

```sh
python3 -I -S -B source/cm2_horn_v1.py
python3 -I -S -B source/cm2_horn_audit_v1.py
python3 -I -S -B source/fair_ground_v1.py
python3 -I -S -B source/fair_ground_audit_v1.py
python3 -I -S -B source/shared_wang_audit_v1.py
python3 -I -S -B publication/render_v1.py
```

The five computation certificates use full fixed program boundaries. The frame archives contain sweeps and active tape events. The independent sparse checker checks local tile membership, edge consistency, and the accept cap. The first-order experiments use linked patches, with source binding, sorts, and graph linkage checked separately.

```sh
python3 -I -S -B source/shared_wang_v1.py prove fol input/example-fol-v1.json fol-proof.json --limit 5
python3 -I -S -B source/shared_wang_v1.py verify input/example-fol-v1.json fol-proof.json
python3 -I -S -B source/shared_wang_v1.py prove cm2 input/example-cm2-v1.json cm2-proof.json --limit 24
python3 -I -S -B source/shared_wang_v1.py verify input/example-cm2-v1.json cm2-proof.json
```

First-order JSON uses a finite sort list and typed function and predicate signatures. Formula constructors are `atom`, `not`, `and`, `or`, `implies`, `iff`, `all`, and `exists`. A quantified formula lists the variable, its sort, and its body. A variable is a string starting with `?`. A function term lists its symbol and then its argument terms. A constant is a function term with no arguments. The example also shows premise and conclusion fields. Set `equality` to true for logical equality and use predicate names formed by prefixing the sort with `=`.

The two-counter program lists `["inc", counter]` or `["dec", counter, jump_address]` per instruction. Counters are indexed by zero and one. Program addresses start at zero. The initial configuration lists the address and two natural-number counter values. Decrement jumps to its address after subtracting one from a positive counter. A zero counter leaves both counters unchanged and execution advances to the next instruction. An address beyond the program halts.

Use `--guided` to run the frozen tactic schedule before the first-order fallback. The five-application input has ground depth five. The separate countermodel audit checks the independent-predicates input. Verification receives both the original input and the saved proof. The reader browser audit can be rerun using `node publication/check_v1.cjs` with Playwright and Chromium.
