"""Replay the experiments from source and compare every generated artifact."""
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0,str(Path(__file__).resolve().parent))
from package_v1 import OUTPUTS, ROOT, STAGES, dependencies, pin, save


def main():
    with TemporaryDirectory() as scratch:
        clean=Path(scratch)
        for folder in ("data","input","publication","report","source"):
            (clean/folder).mkdir()
        inputs=sorted((ROOT/"input").glob("*-v1.json"))
        templates=[ROOT/"publication"/name for name in ("notebook-v1.html","argument-v1.html")]
        for path in (*dependencies(),*inputs,*templates):
            shutil.copyfile(path,clean/path.relative_to(ROOT))
        stages=[f"source/{s}_v1.py" for s in STAGES]+["publication/render_v1.py"]
        for stage in stages:
            subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=clean,check=True)
        outputs={}
        for path in OUTPUTS:
            regenerated=(clean/path).read_bytes()
            assert regenerated==(ROOT/path).read_bytes(),path
            outputs[path]=pin(regenerated)
        assert len(outputs)==14
    save("publication/replay-v1.json",dict(status="MATCHED_CLEAN_REPLAY",python=list(sys.version_info[:3]),
                                         stages=stages,outputs=outputs))
    print(f"Matched {len(outputs)} clean-replay artifacts.",flush=True)


if __name__=="__main__":
    main()
