"""Search first-order entailments and elaborate witnesses for the tape verifier."""
from copy import deepcopy
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from boundary_kernel_v1 import build
import front_v1
import herbrand_v1 as fol
import resolution_v1 as prop
from sparse_frame_v1 import execute, verify

CASES = {"exists-map": 1, "incidence-existence": 1,
         "peano-nonzero-successor": 2, "hilbert-incidence-uniqueness": 1,
         "quantifier-swap-control": 1, "counter-halt": 1}
LIMITS = {"clauses": 10000, "seconds": 15}
CAP = 20_000_000_000


def substitute(t, env):
    return env[t] if isinstance(t, str) else (t[0], *(substitute(x, env) for x in t[1:]))


def grounded(schema, env):
    return [(positive, substitute(a, env)) for positive, a in schema["clause"]]


def type_literal(sort, term, positive):
    return positive, (f"$type:{sort}", term)


def guarded(schemas, functions, sorts):
    if len(sorts) == 1:
        return {row["id"]: row for row in schemas}, {}
    rows = {}
    for row in schemas:
        guards = tuple(type_literal(sort, v, False) for v, sort in sorted(row["variables"].items()))
        rows[row["id"]] = {**row, "clause": (*guards, *row["clause"])}
    function_ids = {}
    for i, (name, (inputs, result)) in enumerate(sorted(functions.items())):
        vars_ = tuple(f"?input{j}" for j in range(len(inputs)))
        schema_id = f"$type-function:{i}"
        function_ids[name] = schema_id
        guards = tuple(type_literal(sort, v, False) for v, sort in zip(vars_, inputs, strict=True))
        assert schema_id not in rows
        rows[schema_id] = dict(id=schema_id, variables=dict(zip(vars_, inputs, strict=True)),
                               clause=(*guards, type_literal(result, (name, *vars_), True)))
    return rows, function_ids


class Certificate:
    def __init__(self, sources, functions, predicates, sorts, type_ids):
        self.sources = sources
        self.functions = functions
        self.type_ids = type_ids
        self.ids = {name: i for i, name in enumerate(sources)}
        names = set(functions) | set(predicates)
        if type_ids:
            names.update(f"$type:{s}" for s in sorts)
        self.symbols = {name: bin(i)[2:] for i, name in enumerate(sorted(names))}
        self.lines = []
        self.type_lemmas = {}

    def token(self, value, vars_):
        if isinstance(value, str):
            return "%" + vars_[value] + ","
        name, *args = value
        return "(" + self.symbols[name] + "." + "".join(self.token(t, vars_) for t in args) + ")"

    def literals(self, values, vars_):
        return "".join(("+" if sign else "-") + self.token(atom, vars_) for sign, atom in values)

    def variable_names(self, row):
        return {v: bin(i)[2:] for i, v in enumerate(sorted(row["variables"]))}

    def prefix(self):
        rows = (f"C{i:b}:" + self.literals(row["clause"], self.variable_names(row)) + ";"
                for i, row in enumerate(self.sources.values()))
        return ">" + "".join(rows) + "#"

    def words(self, rows=None):
        if rows is None:
            rows = self.lines
        records = []
        for i, line in enumerate(rows):
            if line["rule"] == "G":
                schema = self.sources[line["source"]]
                var = self.variable_names(schema)
                subst = line["bindings"]
                binds = "".join("=" + var[v] + ":" + self.token(subst[v], {}) for v in sorted(subst))
                head = f"G{i:b}:{self.ids[line['source']]:b}:" + binds
            else:
                head = f"R{i:b}:{line['left']:b}:{line['right']:b}:" + self.token(line["pivot"], {})
            records.append(head + "/" + self.literals(line["clause"], {}) + ";")
        return "".join(records) + "!"

    def instance(self, name, bindings):
        schema = self.sources[name]
        assert set(bindings) == set(schema["variables"])
        assert all(fol.inspect_term(t, {}, self.functions) == schema["variables"][v]
                   for v, t in bindings.items())
        self.lines.append(dict(rule="G", source=name, bindings=bindings, clause=grounded(schema, bindings)))
        return len(self.lines)-1

    def resolve(self, left, right, pivot):
        a, b = (set(self.lines[i]["clause"]) for i in (left, right))
        assert (True, pivot) in a and (False, pivot) in b
        result = sorted((a - {(True, pivot)}) | (b - {(False, pivot)}), key=repr)
        self.lines.append(dict(rule="R", left=left, right=right, pivot=pivot, clause=result))
        return len(self.lines)-1

    def type_proof(self, term):
        if term not in self.type_lemmas:
            fn, *args = term
            schema_id = self.type_ids[fn]
            self.type_lemmas[term] = self.unguard(schema_id, {f"?input{i}": t for i, t in enumerate(args)})
        return self.type_lemmas[term]

    def unguard(self, schema_id, bindings):
        current = self.instance(schema_id, bindings)
        if self.type_ids:
            for var, term in sorted(bindings.items()):
                sort = self.sources[schema_id]["variables"][var]
                _, type_atom = type_literal(sort, term, True)
                current = self.resolve(self.type_proof(term), current, type_atom)
        return current


def search(normal, depth):
    functions, predicates, schemas = fol.signature(normal)
    source, type_ids = guarded(schemas, functions, normal["sorts"])
    builder = Certificate(source, functions, predicates, normal["sorts"], type_ids)
    outcomes = []
    for d in range(depth+1):
        terms = fol.ground_terms(normal, functions, d, 64)
        assert terms is not None
        atoms, instances = fol.instances(schemas, terms, d, 3000)
        assert atoms is not None
        raw = [prop.literals(row) for row in instances]
        marked = prop.Search(raw, LIMITS, "MARKED")
        plain = prop.Search(raw, LIMITS, "PLAIN")
        a, b = marked.given(), plain.given()
        assert a != "BOUNDED" and b in (a, "BOUNDED")
        verified_marks = prop.verify_marks(marked)
        outcomes.append(dict(depth=d, outcome=a, ground_instances=len(instances),
                             marked=dict(marked.counts), plain=dict(plain.counts),
                             plain_outcome=b, verified_marks=verified_marks))
        if a == "UNSAT":
            rows = marked.proof()
            prop.verify_resolution(raw, rows)
            used, names, premises, resolutions = fol.reduce_proof(raw, rows)
            lookup = {v: k for k, v in atoms.items()}
            decoded_atoms = [lookup[i] for i in names]
            origins = [list(instances.values())[i] for i in used]
            fol.verify_instances(schemas, origins, premises, decoded_atoms, functions)
            prop.verify_resolution(premises, resolutions)
            ids = [builder.unguard(o["schema"], o["substitution"]) for o in origins]
            for row in resolutions:
                ids.append(builder.resolve(ids[row["left"]], ids[row["right"]], decoded_atoms[row["pivot"]-1]))
            assert not builder.lines[-1]["clause"]
            break
    return builder, outcomes


def write_gzip(path, value):
    raw = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
    with path.open("wb") as f:
        with gzip.GzipFile(filename="", fileobj=f, mode="wb", mtime=0) as z:
            z.write(raw)


def inspect_negative(machine, builder, original):
    controls = {}
    for tag, change in (
        ("wrong-pivot-sign", lambda rows: rows[-1].update(left=original[-1]["right"], right=original[-1]["left"])),
        ("forward-reference", lambda rows: rows[-1].update(left=len(original)-1)),
        ("nonempty-conclusion", lambda rows: rows[-1]["clause"].append((True, rows[-1]["pivot"]))),
        ("omitted-clause-literal", lambda rows: rows[0]["clause"].pop()),
    ):
        changed = deepcopy(original)
        change(changed)
        trial = execute(machine, builder.prefix(), builder.words(changed), 0, CAP)
        assert trial["status"] == "REJECT", tag
        controls[tag] = trial["steps"]
    text = builder.words()
    if "=" in text:
        idx = text.index("(", text.index("="))
        trial = execute(machine, builder.prefix(), text[:idx]+")"+text[idx+1:], 0, CAP)
        assert trial["status"] == "REJECT"
        controls["malformed-substitution-term"] = trial["steps"]
    return controls


def counter_example():
    """A CM2 program reaching the out-of-program halt label."""
    program = [("inc", 0), ("dec", 0, 3), ("inc", 1)]
    halt = len(program)
    names = [f"At{i}" for i in range(halt+1)]
    zero, x, y = ["zero"], "?x", "?y"

    def at(i, args):
        return ["atom", names[min(i, halt)], *args]

    def rule(hypothesis, conclusion, variables):
        formula = ["implies", hypothesis, conclusion]
        for var in reversed(variables):
            formula = ["all", var, "Nat", formula]
        return formula

    premises = [at(0, (zero, zero))]
    for i, (operation, counter, *args) in enumerate(program):
        both = [x, y]
        changed = both[:]
        changed[counter] = ["S", both[counter]]
        if operation == "inc":
            premises.append(rule(at(i, both), at(i+1, changed), both))
        else:
            premises.append(rule(at(i, changed), at(args[0], both), both))
            unchanged = both[:]
            unchanged[counter] = zero
            premises.append(rule(at(i, unchanged), at(i+1, unchanged), [both[1-counter]]))
    goal = ["atom", "Halt"]
    premises.append(rule(at(halt, (x, y)), goal, [x, y]))
    return dict(id="counter-halt", sorts=["Nat"], functions={"zero": [[], "Nat"], "S": [["Nat"], "Nat"]},
                predicates={**dict.fromkeys(names, ["Nat", "Nat"]), "Halt": []},
                equality=False, premises=premises, goal=goal, program=program)


def main():
    machine = build().compile()
    rows = []
    inputs = prop.load("input/cases-v1.json") + prop.load("input/new-cases-v1.json") + [counter_example()]
    for case in inputs:
        name = case["id"]
        if name not in CASES:
            continue
        normal, skolem = front_v1.clausify(case, 1024)
        builder, search_rows = search(normal, CASES[name])
        result = dict(id=name, source=case, layers=search_rows, skolem=skolem,
                      source_clauses=list(builder.sources.values()))
        if not builder.lines:
            assert name == "quantifier-swap-control"
            rows.append({**result, "status": "NO_REFUTATION_IN_TESTED_LAYERS"})
            continue
        prefix, word = builder.prefix(), builder.words()
        trial = execute(machine, prefix, word, 2, CAP)
        assert trial["status"] == "ACCEPT", (name, trial)
        assert len(trial["commits"]) == len(builder.lines)
        trace = trial.pop("trace")
        receipt = verify(machine, prefix, word, 2, trace, CAP)
        assert receipt["steps"] == trial["steps"]
        controls = inspect_negative(machine, builder, builder.lines)
        altered = trace[:]
        k = next(i for i, e in enumerate(altered) if len(e)==2)
        altered[k] = [altered[k][0], -altered[k][1]]
        try:
            verify(machine, prefix, word, 2, altered, CAP)
        except ValueError:
            controls["reversed-physical-sweep"] = True
        else:
            raise AssertionError("Corrupted tile evidence was accepted")
        name_out = name+"-frame-v1.json.gz"
        write_gzip(ROOT/"data"/name_out, dict(prefix=prefix, word=word, padding=2,
                                            trace=trace, machine_sha256=machine.digest()))
        result.update(status="PROVED", lines=builder.lines, machine=trial, tile_receipt=receipt,
                      controls=controls, evidence=name_out, code_names=builder.symbols)
        rows.append(result)
        print(json.dumps(dict(id=name, proof_lines=len(builder.lines), **receipt)), flush=True)
    output = dict(status="CHECKED_BOUNDARY_ONLY_FIRST_ORDER_REFUTATIONS", machine_sha256=machine.digest(),
                  machine_states=len(machine.names), alphabet_size=len(machine.alphabet),
                  transitions=len(machine.rules), rows=rows)
    (ROOT/"data"/"results-v1.json").write_text(json.dumps(output, sort_keys=True, separators=(",", ":"))+"\n")


if __name__ == "__main__":
    main()
