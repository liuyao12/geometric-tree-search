"""Specialize a found first-order DAG to exact ground Wang certificate rows."""
from collections import Counter

import herbrand_v1 as fol
from study_v1 import Certificate, guarded
from lifted_prover_v1 import subst


def compile_proof(prover,dag):
    sources,guards=guarded(prover.sources,prover.functions,prover.normal["sorts"])
    builder=Certificate(sources,prover.functions,prover.predicates,prover.normal["sorts"],guards)
    defaults={}
    for name,(args,sort) in sorted(prover.functions.items()):
        if not args:
            defaults.setdefault(sort,(name,))
    cache={}
    events=[]
    count=Counter()

    def elaborate(i,env):
        entry=i,tuple(sorted(env.items()))
        if entry in cache:
            count["reused_ground_occurrences"]+=1
            return cache[entry]
        node=dag[i]
        assert set(env)==set(node["types"])
        for v,t in env.items():
            assert fol.inspect_term(t,{},prover.functions)==node["types"][v]
        complete={**{v:defaults[sort] for v,sort in node["dead"].items()},**env}
        maps=[{v:subst(t,complete) for v,t in m.items()} for m in node["maps"]]
        target={(p,subst(a,env)) for p,a in node["clause"]}
        kind=node["kind"]
        if kind=="source":
            bindings,=maps
            result=builder.unguard(node["schema"],bindings)
            event="instance"
            assert set(builder.lines[result]["clause"])==target
        else:
            parents=[elaborate(j,b) for j,b in zip(node["parents"],maps,strict=True)]
            if kind=="factor":
                result,=parents
                event="factor_collapsed"
            else:
                left,right=parents
                pivot=subst(node["pivot"],complete)
                if (True,pivot) not in builder.lines[left]["clause"]:
                    result,event=left,"stronger_left"
                elif (False,pivot) not in builder.lines[right]["clause"]:
                    result,event=right,"stronger_right"
                else:
                    result=builder.resolve(left,right,pivot)
                    event="resolve"
        assert set(builder.lines[result]["clause"])<=target
        cache[entry]=result
        count[event]+=1
        events.append(dict(node=i,instance=env,line=result,event=event))
        return result

    final=elaborate(len(dag)-1,{})
    assert not builder.lines[final]["clause"]
    # Ground specialization can collapse a lifted inference to an earlier line.
    # Keep only its ground dependencies and end the tape at that line.
    used=set()
    def visit(i):
        if i not in used:
            used.add(i)
            row=builder.lines[i]
            if row["rule"]=="R":
                visit(row["left"])
                visit(row["right"])
    visit(final)
    new={i:j for j,i in enumerate(sorted(used))}
    kept=[]
    for i in sorted(used):
        row=builder.lines[i]
        if row["rule"]=="R":
            row={**row,"left":new[row["left"]],"right":new[row["right"]]}
        kept.append(row)
    for event in events:
        event["line"]=new.get(event["line"])
    builder.lines=kept
    return builder,events,count
