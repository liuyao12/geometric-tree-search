"""Certify bounded-grounding exclusions by addresses in clause term trees."""
from itertools import product
from math import prod

from herbrand_v1 import depth
from resolution_v1 import mask
from study_v1 import grounded


def addresses(schema):
    todo=[((i,j),value) for i,(_,atom) in enumerate(schema["clause"])
          for j,value in enumerate(atom[1:])]
    variables={}
    fixed=None
    while todo:
        path,value=todo.pop()
        if isinstance(value,str):
            if value not in variables or len(path)>len(variables[value]):
                variables[value]=path
        elif len(value)==1:
            if fixed is None or len(path)>len(fixed):
                fixed=path
        else:
            todo.extend(((*path,j),t) for j,t in enumerate(value[1:]))
    assert variables.keys()==schema["variables"].keys()
    return dict(variables=variables,fixed=fixed)


def verify(schema,marks):
    def at(path):
        assert len(path)>=2 and all(type(k) is int and k>=0 for k in path)
        i,j,*rest=path
        value=schema["clause"][i][1][j+1]
        for k in rest:
            assert not isinstance(value,str)
            value=value[k+1]
        return value

    bounds=marks["variables"]
    assert bounds.keys()==schema["variables"].keys()
    assert all(at(path)==v for v,path in bounds.items())
    fixed=marks["fixed"]
    if fixed is not None:
        value=at(fixed)
        assert not isinstance(value,str) and len(value)==1

    def scan(value,level):
        if isinstance(value,str):
            assert len(bounds[value])-2>=level
        elif len(value)==1:
            assert fixed is not None and len(fixed)-2>=level
        else:
            for child in value[1:]:
                scan(child,level+1)

    for _,atom in schema["clause"]:
        for term in atom[1:]:
            scan(term,0)


def instances(clauses,terms,depth_limit,instance_cap,candidate_cap=20000):
    atoms={}
    found={}
    small={}
    for sort,values in terms.items():
        for d in range(-1,depth_limit+1):
            small[sort,d]=tuple(v for v in values if depth(v)<=d)
    stats=dict(cartesian_candidates=0,admissible_candidates=0,checked_groundings=0,certified_schemas=len(clauses))
    available=[]
    for source in clauses:
        mark=addresses(source)
        verify(source,mark)
        variables=tuple(sorted(source["variables"]))
        stats["cartesian_candidates"]+=prod(len(terms[source["variables"][v]]) for v in variables)
        fixed=mark["fixed"]
        if fixed is not None and len(fixed)-2>depth_limit:
            continue
        domains=tuple(small[source["variables"][v],max(-1,depth_limit-len(mark["variables"][v])+2)]
                      for v in variables)
        stats["admissible_candidates"]+=prod(map(len,domains))
        available.append((source,variables,domains))
    for source,variables,domains in available:
        for values in product(*domains):
            if stats["checked_groundings"]>=candidate_cap:
                return None,None,dict(**stats,status="GROUND_WORK_BOUND")
            stats["checked_groundings"]+=1
            substitution=dict(zip(variables,values,strict=True))
            signed=set()
            for sign,atom in grounded(source,substitution):
                index=atoms.setdefault(atom,len(atoms)+1)
                signed.add(index if sign else -index)
            if any(-v in signed for v in signed):
                continue
            found.setdefault(mask(signed),dict(schema=source["id"],substitution=substitution))
            if len(found)>instance_cap:
                return None,None,dict(**stats,status="INSTANCE_BOUND")
    return atoms,found,stats
