"""Read-only source/artifact reconciliation; does not import any experiment."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
NATIVE = ROOT / '.gcts-active/hierarchical-native-20261011'
GEOMETRY = ROOT / '.gcts-active/hilbert-aggregate-design-20261011'
DIAGNOSTIC = ROOT / '.gcts-active/external-cluster-effect-diagnostic-20261011'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def gz(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def main():
    plan = read(NATIVE/'plan.json')
    audit_plan = read(NATIVE/'audit-plan.json')
    assert sha(NATIVE/'plan.json') == '8d5c39253eb1b1823f43daf4d5bc3446e55a2878fc78e2fad930a0e7bb1bb42f'
    assert sha(NATIVE/'audit-plan.json') == '5245588f8b3819ecd63211300cdecc1c3ececc64a86fb725816edaee4114afc4'
    bound = {}
    for p in (plan, audit_plan):
        for path, expected in {**p['source_sha256'], **p['input_sha256']}.items():
            assert sha(ROOT/path) == expected, path
            assert bound.get(path, expected) == expected
            bound[path] = expected
    for key in ('request_sha256','input_bytes_sha256','micro_sha256','program_sha256','micro_code_bytes_sha256','ceilings'):
        assert plan[key] == audit_plan[key]
    production = read(NATIVE/'summary.json')
    lifetime = read(NATIVE/'produce-lifetime.json')
    native = gz(NATIVE/'native.json.gz')
    frame = gz(ROOT/plan['frame'])
    output = gzip.decompress((NATIVE/'output.bin.gz').read_bytes())
    assert production['status'] == 'whole_native_query_complete_pending_independent_replay'
    assert production['native_status'] == native['result']['status'] == 'accepted'
    assert production['request_sha256'] == native['request_sha256'] == frame['request_sha256'] == plan['request_sha256']
    assert native['input_sha256'] == plan['input_bytes_sha256'] == frame['input_sha256']
    assert production['output_bytes'] == native['output_bytes'] == len(output) == 4433656
    assert production['output_sha256'] == native['output_sha256'] == hashlib.sha256(output).hexdigest()
    assert production['micro_steps'] == native['result']['micro_steps'] == 45509715629
    assert production['physical_steps'] == native['result']['physical_steps'] == 2878848866564846
    assert production['micro_fnv64'] == native['result']['micro_fnv64']
    assert production['plan_sha256'] == lifetime['plan_sha256'] == sha(NATIVE/'plan.json')
    assert lifetime['worker_receipt_sha256'] == sha(NATIVE/'summary.json')
    assert lifetime['status'] == 'passed_complete_worker_lifetime_resource_gate'
    assert lifetime['remaining_owned_pids'] == [] and lifetime['worker_terminal_and_reaped'] is True
    assert lifetime['worker_exit_code'] == 0 and lifetime['observer_error'] is None and lifetime['watchdog_violation'] is None
    assert lifetime['conservative_total_peak_bytes'] == sum(lifetime[k] for k in ('kernel_supervisor_peak_bytes','kernel_sampler_peak_before_worker_reaping_bytes','kernel_worker_peak_bytes','kernel_waited_worker_children_peak_bytes'))
    assert lifetime['sampled_total_peak_bytes'] == max(x['rss_bytes'] for x in lifetime['samples'])
    assert max(lifetime['conservative_total_peak_bytes'],lifetime['sampled_total_peak_bytes']) <= plan['ceilings']['rss_bytes']
    assert lifetime['worker_lifetime_seconds_including_imports_and_final_receipt_write'] < plan['ceilings']['phase_seconds']
    assert production['micro_steps'] < plan['ceilings']['micro_steps'] and production['out_of_frame_bands'] == []
    assert frame['old_heap_cells'] == 262144 and frame['new_heap_cells'] == 266240
    assert frame['original_initial']['words'] == frame['proposed_initial']['words'] and frame['original_initial']['heads'] == frame['proposed_initial']['heads']
    original = gz(ROOT/'.gcts-active/proof-program-matched-boundaries-20261011/short-identifiers/observation.json.gz')
    assert original['request_sha256'] == plan['request_sha256'] and original['stored_commands'] == 185
    assert len(original['request']['proof']) == 13 and len(original['request']['blocks']) == 9
    geo = read(GEOMETRY/'example-v1.json')
    design = read(GEOMETRY/'design-v1.json')
    for row in read(GEOMETRY/'manifest-v1.json')['files']:
        assert sha(ROOT/row['path']) == row['sha256'] and (ROOT/row['path']).stat().st_size == row['bytes']
    assert geo['status'] == 'authored_static_geometry_design_witness_not_discovered_theorem'
    assert len(geo['primitive_placements']) == 24 and len(geo['clusters']) == 2
    first, second = [set(x['constituent_ids']) for x in geo['clusters']]
    assert len(first) == len(second) == 13 and len(first&second) == 5 and len(first|second) == 21
    assert geo['composition']['shared_rows'] == [3,4,5,6,7]
    assert len(geo['context']['theory']['axioms']) == 1 and not geo['context']['theory']['schemas']
    diag = read(DIAGNOSTIC/'receipt.json')
    assert sha(DIAGNOSTIC/'receipt.json') == '1447f95f61e94a567dd080056761327ac9249efa2c39c9eab45832a9afdc9c9d'
    counts = diag['per_fixed_run']
    assert counts['new_valid_eligible_hints'] == 527 and counts['fresh_changed_alternative_order'] == 0
    assert counts['fresh_pools_with_different_first_same_feature_vector_as_winner'] == 474
    assert counts['inherited_eligible_at_forced'] == 11 and counts['waiting_hint_blocks_new_proposal_at_branch'] == 93
    for filename, expected in diag['diagnostic_files_sha256'].items():
        assert sha(DIAGNOSTIC/filename) == expected
    draft = (NATIVE/'prepare_report.py').read_text()
    assert "assert accepted, 'Success presentation requires native acceptance, complete replay and both lifetime gates.'" in draft
    assert "audit['status']=='passed_complete_whole_native_replay'" in draft
    assert "all(x['status']=='passed_complete_worker_lifetime_resource_gate' for x in [plife,alife])" in draft
    for phrase in ('previously found by ordinary forward search', 'with no new GCTS/RL proof-discovery claim',
                   'no independent aggregate audit yet', 'no OS hard limit claimed',
                   'These continuation counts are separate', 'No RL gain follows from this diagnosis'):
        assert phrase in draft, phrase
    consumed = [NATIVE/n for n in ('plan.json','audit-plan.json','summary.json','native.json.gz','output.bin.gz','produce-lifetime.json','budget-calibration.json','prepare_report.py')]
    consumed += [GEOMETRY/n for n in ('manifest-v1.json','design-v1.json','example-v1.json')]
    consumed += [DIAGNOSTIC/'receipt.json']
    pins = {str(p.relative_to(ROOT)):sha(p) for p in consumed}
    receipt = dict(schema='read-only-hierarchical-preintegration-review-v1', status='passed_source_producer_and_draft_scope_review_pending_replay',
                   reviewer_source_sha256=sha(Path(__file__)), immutable_artifact_sha256=pins,
                   independently_compared_frozen_source_and_input_sha256=bound,
                   binding_count=len(bound), producer_source_pins=len(plan['source_sha256']), producer_input_pins=len(plan['input_sha256']),
                   audit_source_pins=len(audit_plan['source_sha256']), audit_input_pins=len(audit_plan['input_sha256']),
                   findings=[],
                   checked=dict(request_sha256=plan['request_sha256'], input_bytes_sha256=plan['input_bytes_sha256'], output_bytes_sha256=production['output_sha256'],
                                output_bytes=4433656, micro_steps=45509715629, physical_steps=2878848866564846, root_commands=13, local_blocks=9, stored_commands=185,
                                original_heap_cells=262144, accepted_heap_cells=266240, producer_lifetime_seconds=328.323592,
                                conservative_kernel_total_bytes=420413440, sampled_total_bytes=424017920, producer_reaped=True,
                                diagnostic_fresh_eligible=527, diagnostic_tied_alternatives=474, diagnostic_changed_orders=0, diagnostic_later_forced_eligible=11,
                                geometry_inference_cluster_sizes=[13,13], geometry_shared=5, geometry_union=21, geometry_seeds=3),
                   scope_assessment=['Producer record is accepted and byte-bound; independently replayed acceptance remains pending in this review.',
                                     'Draft refuses success rendering until accepted native status, complete replay and both full lifetime gates are present.',
                                     'Original fixed-heap and GCTS search unknowns are preserved; proof discovery is attributed to prior ordinary forward search.',
                                     'Moved heap and resource ceilings are separately declared. Timing includes worker startup, compilation and final worker receipt writes; observer final write excluded.',
                                     'Both kernel-peak sum and larger sampled aggregate RSS are preserved. Memory is an observed/watchdog gate, not an OS hard limit.',
                                     'Diagnostic fresh eligible and inherited forced continuation counts remain distinct; no new policy action, training or gain is asserted.',
                                     'Geometry remains an authored static source-level construction with independent aggregate audit, full graph/compiler/native correspondence and execution still open.'],
                   limitations=['Read-only artifact/source reconciliation; no experiment, native interpreter, solver, model, producer or auditor was executed.',
                                'No process status or live audit stdout was polled. Final replay receipts and rendered publication manifest require a later review.',
                                'Geometry counts and source/report attribution were reconciled; full derivation, expansion, aggregate legality and source/compiler/executor correspondence were not independently audited here.'],
                   audit_at_review_snapshot={'audit_json_exists':(NATIVE/'audit.json').exists(),'audit_lifetime_json_exists':(NATIVE/'audit-lifetime.json').exists()},
                   new_target_searches=0, new_native_queries=0, new_auditor_executions=0)
    (HERE/'preintegration.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(status=receipt['status'],receipt_sha256=sha(HERE/'preintegration.json'),binding_count=len(bound))),flush=True)


if __name__ == '__main__':
    main()
