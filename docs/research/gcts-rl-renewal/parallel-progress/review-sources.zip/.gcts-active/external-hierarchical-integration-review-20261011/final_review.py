"""Read-only final artifact review; no interpreter/search/auditor execution."""
import gzip
import hashlib
import json
import re
import subprocess
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
N = ROOT / '.gcts-active/hierarchical-native-20261011'
PUB = Path('/private/tmp/gcts-family-router-publish-20261010')
D = ROOT / 'docs/research/gcts-rl-renewal'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def gz(path):
    return json.loads(gzip.decompress(path.read_bytes()))


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids, self.links, self.text, self.pre, self.articles = set(), [], [], [], []
        self.capture, self.current = None, []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids
            self.ids.add(attrs['id'])
        if tag in ('a','script','link','img'):
            self.links.extend(attrs[key] for key in ('href','src') if key in attrs)
        if tag == 'article':
            self.articles.append(attrs)
        if tag == 'pre':
            self.capture, self.current = 'pre', []

    def handle_endtag(self, tag):
        if tag == 'pre':
            self.pre.append(''.join(self.current))
            self.capture = None

    def handle_data(self, data):
        self.text.append(data)
        if self.capture:
            self.current.append(data)


def parsed(path):
    page = Page()
    page.feed(path.read_text())
    return page


def main():
    manifest = read(N/'task-files-v3.json')
    assert sha(N/'task-files-v3.json') == 'bc9d336385650b284b873db145b3ec1beb919f58e5c75b1df96e41b9c1534b8c'
    assert sha(N/'task-files-v2.json') == '12bce043c1069e250a5099779bc6972b10c956b5a74701d6cb99ad02659831b2'
    assert sha(N/'task-files.json') == '86c2c22a7f5061563f0bef1417c7b4d37f7aa560d74bc51521c79f6e848568f9'
    assert len(manifest['files']) == 47 and manifest['total_bytes'] == 22774207
    file_pins = {row['path']:row['sha256'] for row in manifest['files']}
    assert len(file_pins) == len(manifest['files'])
    assert sum(row['bytes'] for row in manifest['files']) == manifest['total_bytes']
    for row in manifest['files']:
        root, clone = ROOT/row['path'], PUB/row['path']
        assert root.read_bytes() == clone.read_bytes(), row['path']
        assert sha(root) == row['sha256'] and root.stat().st_size == row['bytes'], row['path']
    base = subprocess.check_output(['git','rev-parse','HEAD'],cwd=PUB,text=True).strip()
    remote = subprocess.check_output(['git','rev-parse','origin/main'],cwd=PUB,text=True).strip()
    assert base == remote == manifest['previous_commit'] == '7b594d6090d769ea52f0538adfa5a594c553f096'
    changes = subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=PUB,text=True).splitlines()
    assert {row[3:] for row in changes} == set(file_pins)
    prior = read(HERE/'preintegration.json')
    for path, expected in prior['independently_compared_frozen_source_and_input_sha256'].items():
        assert sha(ROOT/path) == expected, path
    producer, audit = read(N/'summary.json'), read(N/'audit.json')
    plife, alife = read(N/'produce-lifetime.json'), read(N/'audit-lifetime.json')
    plan, aplan = read(N/'plan.json'), read(N/'audit-plan.json')
    native = gz(N/'native.json.gz')
    assert audit['status'] == 'passed_complete_whole_native_replay'
    assert audit['native_status'] == producer['native_status'] == native['result']['status'] == 'accepted'
    assert audit['native_replays'] == 1 and producer['native_queries'] == 1
    for key in ('micro_steps','physical_steps','micro_fnv64','output_sha256','request_sha256'):
        assert audit[key] == producer[key]
    assert audit['micro_steps'] == 45509715629 and audit['all_input_output_bytes_matched'] is True
    assert audit['final_state'] == native['result']['state'] == 0 and audit['out_of_frame_bands'] == []
    output = gzip.decompress((N/'output.bin.gz').read_bytes())
    assert output == (N/'producer-work/output.bin').read_bytes() == (N/'audit-work/output.bin').read_bytes()
    assert len(output) == 4433656 and hashlib.sha256(output).hexdigest() == audit['output_sha256']
    assert (N/'audit-work/input.bin').read_bytes() == (N/'producer-work/input.bin').read_bytes() == gzip.decompress((ROOT/plan['input']).read_bytes())
    assert (N/'audit-work/code.bin').read_bytes() == (N/'producer-work/code.bin').read_bytes()
    assert audit['program_sha256'] == aplan['program_sha256'] == plan['program_sha256']
    assert audit['micro_sha256'] == aplan['micro_sha256'] == plan['micro_sha256']
    for life, worker, frozen in ((plife,producer,N/'plan.json'),(alife,audit,N/'audit-plan.json')):
        assert life['status'] == 'passed_complete_worker_lifetime_resource_gate'
        assert life['plan_sha256'] == sha(frozen)
        inner = N/('summary.json' if life['mode']=='produce' else 'audit.json')
        assert life['worker_receipt_sha256'] == sha(inner)
        assert life['worker_exit_code'] == 0 and life['worker_terminal_and_reaped'] is True
        assert life['remaining_owned_pids'] == [] and life['observer_cleaned_orphan_pids'] == []
        assert life['observer_error'] is None and life['watchdog_violation'] is None and not life['forced_verified_pid_kill']
        assert life['conservative_total_peak_bytes'] == sum(life[k] for k in ('kernel_supervisor_peak_bytes','kernel_sampler_peak_before_worker_reaping_bytes','kernel_worker_peak_bytes','kernel_waited_worker_children_peak_bytes'))
        assert life['sampled_total_peak_bytes'] == max(row['rss_bytes'] for row in life['samples'])
        assert max(life['sampled_total_peak_bytes'],life['conservative_total_peak_bytes']) < 536870912
        assert life['worker_lifetime_seconds_including_imports_and_final_receipt_write'] < 600
    assert alife['worker_lifetime_seconds_including_imports_and_final_receipt_write'] == 317.563897333
    assert alife['conservative_total_peak_bytes'] == 334348288
    assert audit['target_searches'] == producer['target_searches'] == audit['gcts_target_proof_discoveries'] == audit['rl_training'] == 0
    assert audit['discovery'] == producer['discovery'] == 'previous_ordinary_forward_search'
    assert plan['ceilings'] == aplan['ceilings'] == {'phase_seconds':600,'rss_bytes':536870912,'micro_steps':50000000000}
    diag = read(D/'parallel-progress/diagnostic/receipt.json')
    assert sha(D/'parallel-progress/diagnostic/receipt.json') == '1447f95f61e94a567dd080056761327ac9249efa2c39c9eab45832a9afdc9c9d'
    assert diag['per_fixed_run']['new_valid_eligible_hints'] == 527
    assert diag['per_fixed_run']['fresh_pools_with_different_first_same_feature_vector_as_winner'] == 474
    assert diag['per_fixed_run']['fresh_changed_alternative_order'] == 0
    assert diag['per_fixed_run']['inherited_eligible_at_forced'] == 11
    geo = read(D/'parallel-progress/geometry/example-v1.json')
    main_path, reader_path = D/'index.html', D/'parallel-progress/reader.html'
    mainpage, reader = parsed(main_path), parsed(reader_path)
    displayed_rows = [json.loads(row) for row in reader.pre]
    assert displayed_rows == geo['primitive_placements']
    assert len(displayed_rows) == 24
    expected_colors = {'seed':3,'first':8,'shared':5,'second':8}
    actual_colors = {key:sum(key in a.get('class','').split() for a in reader.articles) for key in expected_colors}
    assert actual_colors == expected_colors
    assert {a['id'] for a in reader.articles} == {'proof-row-'+str(i) for i in range(24)}
    first, second = [set(x['constituent_ids']) for x in geo['clusters']]
    assert len(first) == len(second) == 13 and len(first&second) == 5 and len(first|second) == 21
    assert geo['status'] == 'authored_static_geometry_design_witness_not_discovered_theorem'
    text = ' '.join(reader.text)
    for phrase in ('previously found by ordinary forward search','with no new GCTS/RL proof-discovery claim',
                   'no independent aggregate audit yet','no OS hard limit claimed',
                   'These continuation counts are separate','No RL gain follows from this diagnosis',
                   'The original','not a predicted future success rate','Compilation, startup',
                   'observer’s final receipt write is excluded','not a bound'):
        assert phrase in text, phrase
    for numeral in ('527','474','0','93','620','11','266240','262144','328.324','317.564','45509715629','4433656','24','21'):
        assert numeral in text
    assert 'authored aggregate design still needs independent checking' in ' '.join(mainpage.text)
    assert r"inlineMath:[['\\(','\\)']]" in reader_path.read_text()
    assert r'\begin{gathered}' in reader_path.read_text()
    expected_reserved = {(D/'parallel-progress/integration-review.json').resolve(),(D/'parallel-progress/task-files.json').resolve()}
    reserved, checked_links = set(), []
    for page_path, page in ((main_path,mainpage),(reader_path,reader)):
        for href in page.links:
            url = urlsplit(href)
            if url.scheme or url.netloc:
                continue
            target = (page_path.parent/unquote(url.path)).resolve() if url.path else page_path
            if target.is_dir():
                target /= 'index.html'
            if target in expected_reserved:
                reserved.add(target)
                continue
            assert target.exists(), (page_path,href)
            if url.fragment and target.suffix == '.html':
                assert unquote(url.fragment) in parsed(target).ids, (page_path,href)
            checked_links.append({'page':str(page_path.relative_to(ROOT)),'href':href})
    assert reserved == expected_reserved
    receipt = dict(schema='read-only-hierarchical-final-integration-review-v1',status='passed_final_source_artifact_and_report_reconciliation',
                   manifest_sha256=sha(N/'task-files-v3.json'), prior_manifest_sha256=sha(N/'task-files.json'), revised_card_manifest_sha256=sha(N/'task-files-v2.json'),
                   mainreader_sha256=sha(main_path),newreader_sha256=sha(reader_path),
                   reviewer_script_sha256=sha(Path(__file__)),preintegration_receipt_sha256=sha(HERE/'preintegration.json'),
                   manifest_files=47,manifest_bytes=22774207,clone_base_commit=base,all_manifest_root_and_clone_bytes_match=True,isolated_clone_changes_exactly_manifest=True,
                   scoped_file_sha256=file_pins,findings=[],
                   native=dict(request_sha256=plan['request_sha256'],input_sha256=plan['input_bytes_sha256'],output_sha256=audit['output_sha256'],
                               producer_plan_sha256=sha(N/'plan.json'),audit_plan_sha256=sha(N/'audit-plan.json'),audit_receipt_sha256=sha(N/'audit.json'),
                               producer_lifetime_sha256=sha(N/'produce-lifetime.json'),audit_lifetime_sha256=sha(N/'audit-lifetime.json'),
                               native_queries=1,independent_replays=1,micro_steps=45509715629,output_bytes=4433656,all_stored_actual_output_bytes_compared=True,
                               physical_steps=2878848866564846,heap_cells=266240,old_heap_cells=262144,root_commands=13,local_blocks=9,stored_commands=185,
                               producer_worker_lifetime_seconds=plife['worker_lifetime_seconds_including_imports_and_final_receipt_write'],
                               audit_worker_lifetime_seconds=alife['worker_lifetime_seconds_including_imports_and_final_receipt_write'],
                               producer_conservative_kernel_bytes=plife['conservative_total_peak_bytes'],producer_sampled_bytes=plife['sampled_total_peak_bytes'],
                               audit_conservative_kernel_bytes=alife['conservative_total_peak_bytes'],audit_sampled_bytes=alife['sampled_total_peak_bytes'],
                               both_owner_lifetime_receipts_passed_and_terminal_reaped=True,ceilings=plan['ceilings'],discovery='prior ordinary forward search'),
                   policy=dict(fresh_valid_eligible_per_run=527,feature_identical_tied_alternative_decisions=474,changed_branch_orders=0,later_eligible_forced_continuations=11,
                               fixed_search_unknowns_preserved=True,no_new_stochastic_rollout_or_training=True),
                   geometry=dict(exact_exported_primitive_row_records_match_frozen_example=True,rows=24,cluster_sizes=[13,13],shared=5,distinct_inference_union=21,seeds=3,
                                 displayed_owner_color_counts=actual_colors,independent_aggregate_audit_still_open=True,authored_example_not_discovery=True,native_compiler_execution_correspondence_still_open=True),
                   scope_checks=['All 160 prior frozen source/input bindings remain exact; no native checker or parser source change.',
                                 'Replay receipt agrees with producer on status, request, full output, microsteps, physical steps and trace digest. Actual stored producer/replay input, microtable and final output bytes are equal.',
                                 'Both worker lifecycle resource gates pass. Compilation/startup/final worker writes are charged; observer final write excluded. No OS hard memory enforcement claimed.',
                                 'Prospective 50-billion/600-second/512-MiB ceilings and eight-sample extrapolation limits remain disclosed. Previous heap and search unknowns remain intact.',
                                 'Discovery remains attributed to ordinary search; native checking is not proof-search competitiveness, a GCTS discovery or an RL gain.',
                                 'Diagnostic fresh actions and later forced continuations stay distinct. Positive mass at saved alternatives is not a future success prediction.',
                                 'All 24 displayed primitive row JSON records match frozen geometry; 13/13/5/21 counts and colors agree. Source-level design is not promoted to independent aggregate/native acceptance.',
                                 'Two long card sequents are gathered into multiple LaTeX lines as a presentation-only change. No scientific artifacts changed.'],
                   local_link_checks=len(checked_links),reserved_destinations=[str(p.relative_to(ROOT)) for p in sorted(reserved)],
                   publication_conditions=['Root must copy final.json to integration-review.json and immutable task-files-v3.json to the reserved task-files.json destination, then regenerate its scoped final manifest.',
                                           'Root still performs complete public archive/source-binding reconciliation, browser QA and live publication verification. This receipt does not claim those steps.'],
                   operations={'new_native_queries':0,'searches':0,'solver_calls':0,'engine_or_producer_or_auditor_executions':0,'process_polling':0,'original_or_publication_file_mutations':0})
    (HERE/'final.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ('status','manifest_sha256','mainreader_sha256','newreader_sha256','manifest_files','manifest_bytes','local_link_checks')}))
    print('receipt_sha256',sha(HERE/'final.json'))


if __name__ == '__main__':
    main()
