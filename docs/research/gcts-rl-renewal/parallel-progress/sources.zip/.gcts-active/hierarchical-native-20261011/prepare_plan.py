import gzip,hashlib,json
from pathlib import Path
R=Path.cwd();O=R/'.gcts-active/hierarchical-native-20261011';P=R/'.gcts-active/proof-program-matched-boundaries-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((P/'movable-encoding/plan.json').read_text())
measure_path=R/'.gcts-active/commutativity-receptors-20261011/native-pilot/native.json.gz'
metrics_path=R/'.gcts-active/commutativity-receptors-20261011/capacity-full/partial-audit/all94-metrics.json.gz'
metrics={v['definition_name']:v for v in json.loads(gzip.decompress(metrics_path.read_bytes()))}
rows=[]
for v in json.loads(gzip.decompress(measure_path.read_bytes())):
 t=metrics[v['definition_name']]['tree_steps'];n=v['result']['micro_steps'];rows.append(dict(definition_name=v['definition_name'],stratum=v['stratum'],tree_steps=t,micro_steps=n,subprocess_seconds=v['seconds'],micro_per_tree=n/t))
ratios=[v['micro_per_tree'] for v in rows]
cal=dict(status='prospective_budget_calibration_before_new_native_execution',candidate_tree_steps=7974306,prior_measurements=rows,nominal_micro_range=[7974306*min(ratios),7974306*max(ratios)],limitation='Eight earlier local certificates only. Ratios are an extrapolation, not a bound or confidence interval; whole hierarchy may have different costs. No result-dependent retry.',chosen_limit=50000000000,chosen_worker_lifetime_seconds=600,chosen_rss_bytes=536870912,source_sha256={str(p.relative_to(R)):sha(p) for p in [measure_path,metrics_path]})
(O/'budget-calibration.json').write_text(json.dumps(cal,indent=2)+'\n')
sources=dict(old['source_sha256'])
for n in ['native_certificate_transport.py','native_certificate_stage.py','hierarchical_certificate_native.py','hierarchical_certificate_native_audit.py','boundary_oracle.cpp','audit_tape_micro.cpp']:
 p=R/'research/gcts-rl-renewal'/n;sources[str(p.relative_to(R))]=sha(p)
inputs=dict(old['input_sha256'])
for p in [P/'movable-encoding/plan.json',P/'movable-encoding/audit-plan.json',P/'movable-encoding/audit.json',P/'movable-encoding/frame.json.gz',P/'movable-encoding/input.bin.gz',P/'representation-review.json',O/'budget-calibration.json',measure_path,metrics_path]:inputs[str(p.relative_to(R))]=sha(p)
for name,pin in {**sources,**inputs}.items():assert sha(R/name)==pin,name
plan=dict(transport_artifact_dir='.gcts-active/hierarchical-native-20261011',status='prospective_draft_pending_independent_source_review',source_sha256=sources,input_sha256=inputs,byte_audit=str((P/'movable-encoding/audit.json').relative_to(R)),independent_review=str((P/'representation-review.json').relative_to(R)),microcode='docs/research/gcts-rl-renewal/proof-boundary-microcode-001.json.gz',boundary='docs/research/gcts-rl-renewal/proof-boundary-001.json',frame=str((P/'movable-encoding/frame.json.gz').relative_to(R)),input=str((P/'movable-encoding/input.bin.gz').relative_to(R)),interpreter='research/gcts-rl-renewal/boundary_oracle.cpp',worker='research/gcts-rl-renewal/hierarchical_certificate_native.py',request_sha256='ffc08505435a7a87c62927b8a1934bf14b988d3f72242bfbc5eb413e363ac3dd',input_bytes_sha256='f770d76f8939d8d0a103726318ef98ca01fba7772e4f013eb6dd04ccb519efb9',micro_sha256='2f9e430b0b7034ed615d81c3e9b3978dc47ba4136686227a9b86df5779b203ac',program_sha256='877c47879b027b08f02d3923d1e6dd9ccaf9a12e354567109f1aaa640a8fb673',micro_code_bytes_sha256='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed',ready_line='READY 92457 88986 0 1 2',ceilings={'phase_seconds':600,'rss_bytes':536870912,'micro_steps':50000000000},native_queries=1,max_independent_replays=1,target_searches=0,geometry='Previously audited movable heap 266240; prior fixed 262144 unknown retained.',discovery='Previous ordinary forward search, not GCTS or RL.',scope='One fresh native query and one separate whole replay. No retries, callback checker, preaccepted theorem or parser shortcut. Full worker lifecycle gates include startup, compilation and final receipt write; observer final receipt write excluded.')
(O/'plan-draft.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'sources':len(sources),'inputs':len(inputs),'nominal_micro_range':cal['nominal_micro_range'],'draft_sha256':sha(O/'plan-draft.json')}))
