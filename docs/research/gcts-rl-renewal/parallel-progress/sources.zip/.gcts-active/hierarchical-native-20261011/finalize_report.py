"""Add narrow reviews and complete transport/cost evidence to the new reader."""
import hashlib,json,shutil,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;D=R/'docs/research/gcts-rl-renewal/parallel-progress';P=Path('/private/tmp/gcts-family-router-publish-20261010');G=R/'.gcts-active/hilbert-aggregate-design-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((O/'publication-files.json').read_text());paths={r['path'] for r in m['files']}
for name in ['root-report-review-v2.json','prepare_report-reviewed-v2.snapshot']:
 src=G/name;dst=D/'geometry'/name;assert not dst.exists();shutil.copyfile(src,dst);paths.add(str(dst.relative_to(R)))
review=json.loads((G/'root-report-review-v2.json').read_text());assert sha(O/'prepare_report.py')==review['draft_source']['sha256']
for src in sorted(O.glob('*')):
 if src.is_file() and (src.name.startswith(('subprocess-','produce-worker-','audit-worker-')) or src.name in ['produce-owner.json','audit-owner.json','observer-ownership-fixture.json']):
  dst=D/'native'/src.name;assert not dst.exists();shutil.copyfile(src,dst);paths.add(str(dst.relative_to(R)))
reader=D/'reader.html';s=reader.read_text();marker='<p><a href="../certificate-hierarchy/reader.html#reader">'
assert s.count(marker)==1
s=s.replace(marker,r'<p>The observed \(45509715629\) microsteps exceed the calibration’s nominal \(19.857\)–\(33.296\) billion range; the frozen \(50\)-billion-step limit still covers them. This illustrates why the extrapolation was not treated as a bound. Native checking alone does not establish a practical or competitive proof-search system.</p>'+marker)
s=s.replace('<a href="geometry/design-v1.json">Complete design and proof obligations</a>', '<a href="geometry/root-report-review-v2.json">Narrow independent geometry presentation review</a> · <a href="geometry/design-v1.json">Complete design and proof obligations</a>')
s=s.replace('<a href="sources.zip">Exact new source and input closure</a>', '<a href="integration-review.json">Independent integration review</a> · <a href="task-files.json">Frozen reviewed task manifest</a> · <a href="sources.zip">Exact new source and input closure</a>')
s=s.replace('grid-template-columns:repeat(3,1fr);gap:12px','grid-template-columns:repeat(3,minmax(0,1fr));gap:12px').replace('.figure div{padding:22px','.figure div{min-width:0;overflow:auto;padding:22px')
reader.write_text(s)
# All reviewed source snapshots remain reproducible; finalization is a separate
# presentation-only script and does not alter the source reviewed by geometry.
with zipfile.ZipFile(D/'sources.zip','a',zipfile.ZIP_DEFLATED) as z:
 assert str((O/'finalize_report.py').relative_to(R)) not in z.namelist();z.write(O/'finalize_report.py',str((O/'finalize_report.py').relative_to(R)))
for n in paths:
 dst=P/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,dst)
rows=[{'path':n,'sha256':sha(R/n),'bytes':(R/n).stat().st_size} for n in sorted(paths)]
m.update(files=rows,total_bytes=sum(r['bytes'] for r in rows));(O/'task-files.json').write_text(json.dumps(m,indent=2)+'\n');(O/'publication-files.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'status':'frozen_for_independent_integration_review','files':len(rows),'bytes':m['total_bytes'],'task_manifest_sha256':sha(O/'task-files.json')}))
