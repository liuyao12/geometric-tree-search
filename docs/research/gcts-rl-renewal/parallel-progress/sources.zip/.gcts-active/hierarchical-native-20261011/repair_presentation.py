"""Split the unchanged guarded sequents across two visual lines."""
import hashlib,json,shutil,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent;D=R/'docs/research/gcts-rl-renewal/parallel-progress';P=Path('/private/tmp/gcts-family-router-publish-20261010')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=D/'reader.html';s=p.read_text();old_sha=sha(p)
for guard,first,last in [(r'H(P,Q,\ell,m)',r'\ell','m'),('H(P,Q,m,n)','m','n')]:
 old=r'\('+guard+r',\ \operatorname{Incident}(R,'+first+r')\vdash\operatorname{Incident}(R,'+last+r')\)'
 new=r'\(\begin{gathered}'+guard+r'\\\operatorname{Incident}(R,'+first+r')\vdash\operatorname{Incident}(R,'+last+r')\end{gathered}\)'
 assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s)
with zipfile.ZipFile(D/'sources.zip','a',zipfile.ZIP_DEFLATED) as z:z.write(O/'repair_presentation.py',str((O/'repair_presentation.py').relative_to(R)))
m=json.loads((O/'task-files.json').read_text())
for row in m['files']:
 source=R/row['path'];row.update(sha256=sha(source),bytes=source.stat().st_size);shutil.copyfile(source,P/row['path'])
m['total_bytes']=sum(r['bytes'] for r in m['files']);m['presentation_revision']='Only two guarded sequents split across visual lines after browser QA; exact formula tokens and science are unchanged.'
(O/'task-files-v2.json').write_text(json.dumps(m,indent=2)+'\n');(O/'publication-files.json').write_text(json.dumps(m,indent=2)+'\n')
(O/'presentation-repair.json').write_text(json.dumps({'old_reader_sha256':old_sha,'new_reader_sha256':sha(p),'native_queries':0,'target_searches':0,'changes':'Two MathJax gathered formulas replace horizontal card scrolling; every hypothesis and conclusion preserved.'},indent=2)+'\n')
print(json.dumps({'files':len(m['files']),'bytes':m['total_bytes'],'manifest_v2_sha256':sha(O/'task-files-v2.json')}))
