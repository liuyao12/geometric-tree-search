import concurrent.futures, hashlib, json, subprocess, time
from pathlib import Path

OUT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/hierarchical-native-20261011')
publication = json.loads((OUT / 'publication.json').read_text())
prior = json.loads((OUT.parent / 'proof-program-matched-boundaries-20261011/publication.json').read_text())
paths = sorted(set(publication['task_paths']) | (set(publication['expected_live_sha256']) - set(prior['expected_live_sha256'])))
for name, expected in prior['expected_live_sha256'].items():
    if name not in paths:
        assert publication['expected_live_sha256'][name] == expected, ('changed prior artifact', name)
start = time.perf_counter()
results = []

def check(name):
    url = 'https://liuyao12.github.io/geometric-tree-search/' + name + '?publication=' + publication['commit']
    result = subprocess.run(['/usr/bin/curl','--fail','--silent','--show-error','--location','--connect-timeout','10','--max-time','90','--retry','1','--retry-delay','1','--header','Cache-Control: no-cache',url],capture_output=True)
    if result.returncode:
        return dict(path=name,passed=False,curl_exit=result.returncode,error=result.stderr.decode('utf-8','replace')[:700])
    data = result.stdout
    digest = hashlib.sha256(data).hexdigest()
    return dict(path=name,sha256=digest,bytes=len(data),passed=digest==publication['expected_live_sha256'][name] and len(data)==publication['expected_live_bytes'][name])

def save(final=False):
    failed = [r for r in results if not r['passed']]
    value = dict(status=('passed' if not failed else 'failed') if final else 'running',commit=publication['commit'],files=len(results),expected_files=len(paths),bytes=sum(r.get('bytes',0) for r in results),seconds=time.perf_counter()-start,failed=failed,results=results,retained_prior_immutable_files=len(set(publication['expected_live_sha256'])-set(paths)),method='TLS-validated HTTPS exact hashes and byte counts for every task artifact and newly exposed dependency; four workers; unchanged files retain the prior exact-live receipt.')
    temporary = OUT / 'live-hash-checks.json.tmp'
    temporary.write_text(json.dumps(value,indent=2)+'\n')
    temporary.replace(OUT / 'live-hash-checks.json')
    return value

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(check,name) for name in paths]
    for future in concurrent.futures.as_completed(futures):
        row = future.result()
        results.append(row)
        if not row['passed']:
            print(json.dumps(row),flush=True)
        if len(results)%20 == 0:
            value = save()
            print(json.dumps(dict(checked=len(results),expected=len(paths),failed=len(value['failed']))),flush=True)
value = save(True)
print(json.dumps({k:value[k] for k in ['status','files','expected_files','bytes','seconds','failed']}),flush=True)
assert not value['failed']
