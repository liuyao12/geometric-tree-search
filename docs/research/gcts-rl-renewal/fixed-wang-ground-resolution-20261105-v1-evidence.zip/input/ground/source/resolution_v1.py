"""Automatic propositional refutations checked by the fixed Wang palette."""

from collections import Counter
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import fixed_palette_v1 as wang
import ribbon_checker_v3 as independent_wang


def load(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name,data):
    with (ROOT/name).open("x") as f:
        json.dump(data,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def compressed(name,value):
    with (ROOT/name).open("xb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",mtime=0) as stream:
            stream.write(json.dumps(value,sort_keys=True,separators=(",",":")).encode())


def bits(mask):
    while mask:
        b=mask&-mask
        yield b
        mask ^= b


def combine(op,a,b):
    if op=="and":
        return a and b
    if op=="or":
        return a or b
    if op=="implies":
        return not a or b
    assert op=="iff"
    return a==b


def encode(formula):
    index={}
    clauses=[]
    def variable(ast):
        key=json.dumps(ast,separators=(",",":"))
        if key in index:
            return index[key]
        if isinstance(ast,str):
            index[key]=len(index)
            return index[key]
        op,left,right=ast
        a,b=variable(left),variable(right)
        w=len(index)
        index[key]=w
        for x,y in product((False,True),repeat=2):
            clause=[(-1 if x else 1)*(a+1),(-1 if y else 1)*(b+1),
                    (1 if combine(op,x,y) else -1)*(w+1)]
            if not any(-p in clause for p in clause):
                clauses.append(clause)
        return w
    root=variable(formula)
    clauses.append([-root-1])
    return len(index),clauses


def problem(case):
    if case["kind"]=="formula":
        return encode(case["formula"])
    if case["kind"]=="pigeonhole":
        p,h=case["pigeons"],case["holes"]
        clauses=[[i*h+j+1 for j in range(h)] for i in range(p)]
        clauses += [[-(i*h+k+1),-(j*h+k+1)] for i in range(p) for j in range(i+1,p) for k in range(h)]
        return p*h,clauses
    if case["kind"]=="cycle":
        n=case["n"]
        pairs=[(i+1,(i+1)%n+1) for i in range(n)]
        return n,[[a,b] for a,b in pairs]+[[-a,-b] for a,b in pairs]
    assert case["kind"]=="explicit"
    return case["n"],case["clauses"]


def mask(row):
    a=b=0
    for p in row:
        if p>0:
            a|=1<<(p-1)
        else:
            b|=1<<(-p-1)
    return a,b


def literals(pair):
    a,b=pair
    return [p.bit_length() for p in bits(a)]+[-p.bit_length() for p in bits(b)]


def resolution(a,b,p):
    assert a[0]&p and b[1]&p
    return (a[0]^p)|b[0],a[1]|(b[1]^p)


class Search:
    def __init__(self,problem,limits,mode):
        self.clauses=list(dict.fromkeys(mask(c) for c in problem))
        assert all(not a&b for a,b in self.clauses)
        self.premises=len(self.clauses)
        self.index={c:i for i,c in enumerate(self.clauses)}
        self.dependencies={}
        self.marks=[]
        self.counts=Counter()
        self.started=time.process_time()
        self.limits=limits
        self.mode=mode

    def budget(self):
        return (len(self.clauses)<self.limits["clauses"]
                and time.process_time()-self.started<self.limits["seconds"])

    def derive(self,i,j,p):
        self.counts["pivots"]+=1
        result=resolution(self.clauses[i],self.clauses[j],p)
        a,b=result
        if a&b:
            self.counts["tautologies"]+=1
            return None
        if result in self.index:
            self.counts["duplicates"]+=1
            return self.index[result]
        if self.mode=="MARKED":
            for k,(x,y) in enumerate(self.clauses):
                if x&a==x and y&b==y:
                    self.counts["subsumptions"]+=1
                    self.marks.append(("subsumption",i,j,p.bit_length(),k))
                    return None
        index=len(self.clauses)
        self.index[result]=index
        self.clauses.append(result)
        self.dependencies[index]=(i,j,p.bit_length())
        return index

    def pair(self,i,j):
        a,b=self.clauses[i],self.clauses[j]
        forward,reverse=a[0]&b[1],b[0]&a[1]
        if self.mode=="MARKED" and (forward|reverse).bit_count()>1:
            self.counts["tautological_pairs"]+=1
            self.counts["skipped_pivots"]+=(forward|reverse).bit_count()
            self.marks.append(("pair",i,j,literals((forward,reverse))))
            return
        for p in bits(forward):
            self.derive(i,j,p)
        for p in bits(reverse):
            self.derive(j,i,p)

    def given(self):
        processed=[]
        pending=set(range(self.premises))
        while pending and self.budget() and (0,0) not in self.index:
            i=min(pending,key=lambda j:(sum(x.bit_count() for x in self.clauses[j]),j))
            pending.remove(i)
            self.counts["selected"]+=1
            start=len(self.clauses)
            for j in processed:
                self.pair(i,j)
                if not self.budget() or (0,0) in self.index:
                    break
            pending.update(range(start,len(self.clauses)))
            processed.append(i)
        return "UNSAT" if (0,0) in self.index else "SAT" if not pending else "BOUNDED"

    def eliminate(self,n):
        active=set(range(self.premises))
        remaining=set(range(n))
        while remaining and self.budget() and (0,0) not in self.index:
            choices=[]
            for v in remaining:
                p=1<<v
                plus=[i for i in sorted(active) if self.clauses[i][0]&p]
                minus=[i for i in sorted(active) if self.clauses[i][1]&p]
                choices.append((len(plus)*len(minus),v,plus,minus))
            _,v,plus,minus=min(choices)
            remaining.remove(v)
            self.counts["selected"]+=1
            next_active=active-set(plus)-set(minus)
            for i,j in product(plus,minus):
                k=self.derive(i,j,1<<v)
                if k is not None:
                    next_active.add(k)
                if not self.budget() or (0,0) in self.index:
                    break
            active=next_active
        return "UNSAT" if (0,0) in self.index else "SAT" if not remaining and self.budget() else "BOUNDED"

    def proof(self):
        used=set()
        def visit(i):
            if i not in self.dependencies or i in used:
                return
            used.add(i)
            a,b,_=self.dependencies[i]
            visit(a)
            visit(b)
        visit(self.index[0,0])
        names={i:i for i in range(self.premises)}
        rows=[]
        for i in sorted(used):
            a,b,p=self.dependencies[i]
            rows.append(dict(left=names[a],right=names[b],pivot=p,clause=literals(self.clauses[i])))
            names[i]=self.premises+len(rows)-1
        assert rows and not rows[-1]["clause"]
        return rows


def verify_resolution(premises,proof):
    known=[set(c) for c in premises]
    for row in proof:
        l,r,p=row["left"],row["right"],row["pivot"]
        assert 0<=l<len(known) and 0<=r<len(known) and p>0
        left,right=known[l],known[r]
        assert p in left and -p in right
        clause=(left-{p})|(right-{-p})
        assert clause==set(row["clause"]) and all(-q not in clause for q in clause)
        known.append(clause)
    assert not known[-1]


def verify_marks(search):
    clauses=[set(literals(c)) for c in search.clauses]
    for kind,i,j,p,*rest in search.marks:
        left,right=clauses[i],clauses[j]
        if kind=="pair":
            assert len({abs(q) for q in left if -q in right})>=2
            assert set(map(abs,p))=={abs(q) for q in left if -q in right}
        else:
            k,=rest
            assert kind=="subsumption" and p in left and -p in right
            assert clauses[k] <= (left-{p})|(right-{-p})
    return len(search.marks)


def circuit(n,premises,proof):
    inputs=[dict(name="zero",value=0),dict(name="one",value=1)]
    fields=[]
    bits_in=[0,1]
    pivot_width=max(1,(n-1).bit_length())
    for row in proof:
        ref_width=max(1,(len(premises)+len(fields)-1).bit_length())
        values=(row["left"],row["right"],row["pivot"]-1,*mask(row["clause"]))
        widths=(ref_width,ref_width,pivot_width,n,n)
        cols=[]
        for label,value,width in zip(("left","right","pivot","positive","negative"),values,widths,strict=True):
            refs=list(range(len(inputs),len(inputs)+width))
            inputs.extend(dict(name=f"line{len(fields)}:{label}:{k}",value=None) for k in range(width))
            bits_in.extend((value>>k)&1 for k in range(width))
            cols.append(refs)
        fields.append(cols)
    b=wang.Builder(inputs)
    clauses=[tuple(b.const_word(x,n) for x in mask(c)) for c in premises]
    checks=[]
    for left,right,pivot,cp,cn in fields:
        def selected(ref):
            possibilities=[b.word_eq(ref,b.const_word(i,len(ref))) for i in range(len(clauses))]
            checks.append(b.any(possibilities))
            return [[b.any(b.AND(w,c[sign][k]) for w,c in zip(possibilities,clauses,strict=True))
                     for k in range(n)] for sign in (0,1)]
        lp,ln=selected(left)
        rp,rn=selected(right)
        at=[b.word_eq(pivot,b.const_word(k,len(pivot))) for k in range(n)]
        checks.append(b.any(b.all((at[k],lp[k],rn[k])) for k in range(n)))
        for k in range(n):
            checks.extend((b.EQ(cp[k],b.OR(b.AND(lp[k],b.NOT(at[k])),rp[k])),
                           b.EQ(cn[k],b.OR(ln[k],b.AND(rn[k],b.NOT(at[k])))),
                           b.NOT(b.AND(cp[k],cn[k]))))
        clauses.append((cp,cn))
    checks.extend(b.NOT(x) for row in clauses[-1] for x in row)
    return b.finish(b.all(checks)),bits_in,fields


def sat_control(n,premises):
    for values in product((False,True),repeat=n):
        if all(any(values[abs(lit)-1]==(lit>0) for lit in clause) for clause in premises):
            return list(map(int,values))
    raise AssertionError("Declared satisfiable control has no model")


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    cases=load("input/cases-v1.json")
    rows=[]
    palette=wang.palette()
    for case in cases:
        n,initial=problem(case)
        results={}
        for mode in protocol["modes"]:
            s=Search(initial,protocol["limits"],mode)
            status=s.eliminate(n) if mode=="ELIMINATE" else s.given()
            assert status=="BOUNDED" or status==case["expected"]
            premises=[literals(c) for c in s.clauses[:s.premises]]
            proof=s.proof() if status=="UNSAT" else None
            if proof:
                verify_resolution(premises,proof)
            model=sat_control(n,premises) if status=="SAT" else None
            marks=verify_marks(s)
            results[mode]=dict(status=status,proof=proof,model=model,marks=marks,
                               counts=dict(s.counts),clauses=len(s.clauses),
                               seconds=time.process_time()-s.started)
            if mode=="MARKED":
                results[mode]["sample_markings"]=s.marks[:50]
                results[mode]["clause_inventory"]=[literals(c) for c in s.clauses]
        proof=results["MARKED"]["proof"]
        physical=None
        if case["physical"]:
            assert proof
            c,inputs,fields=circuit(n,premises,proof)
            gates=len(c["gates"])
            physical=dict(status="COMPILE_LIMIT",gates=gates,lines=len(proof))
            if gates<=protocol["gate_limit"]:
                cert=wang.certificate(c,inputs,palette)
                checked=independent_wang.verify(c,cert,palette)
                assert checked["status"]=="VERIFIED"
                literal=independent_wang.verify_literal(c,cert,palette)
                assert literal["status"] in ("VERIFIED","UNKNOWN")
                corrupt=inputs[:]
                corrupt[fields[-1][3][0]]^=1
                assert wang.evaluate(c,corrupt)[1]==0
                name=f"data/{case['id']}-wang-v1.json.gz"
                compressed(name,dict(circuit=c,certificate=cert))
                physical=dict(status="VERIFIED",gates=gates,lines=len(proof),checked=checked,literal=literal,
                              corrupted_final_clause="REJECTED",artifact=dict(path=name,**pin(ROOT/name)))
                del cert
            del c
        rows.append(dict(case=case,n=n,premises=premises,methods=results,physical=physical))
        print(json.dumps(dict(case=case["id"],methods={k:v["status"] for k,v in results.items()},
                              physical=physical["status"] if physical else None,
                              gates=physical["gates"] if physical else None)),flush=True)
    save("data/results-v1.json",rows)
    report=dict(status="CHECKED_RESOLUTION_IN_FIXED_WANG_PALETTE",cases=len(rows),
                palette_sha256=wang.digest(palette),physical=dict(Counter(r["physical"]["status"] for r in rows if r["physical"])),
                literal=sum(r["physical"] is not None and r["physical"].get("literal",{}).get("status")=="VERIFIED" for r in rows),
                methods={mode:dict(outcomes=dict(Counter(r["methods"][mode]["status"] for r in rows)),
                    pivots=sum(r["methods"][mode]["counts"].get("pivots",0) for r in rows),
                    learned_marks=sum(r["methods"][mode]["marks"] for r in rows)) for mode in protocol["modes"]},
                scope="Propositional clauses, automatically searched and independently verified. The circuit leaves each derived clause, pivot and reference unpinned. Compiled gates and instance dimensions are part of the problem data.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
