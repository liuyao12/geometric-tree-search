"""First-order ground-instance search feeding the unchanged Wang palette."""

from collections import Counter
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import resolution_v1 as prop


def frozen(x):
    return tuple(frozen(y) for y in x) if isinstance(x,list) else x


def depth(term):
    return 1+max(map(depth,term[1:]),default=-1)


def inspect_term(term,variables,functions):
    if isinstance(term,str):
        return variables[term]
    args,sort=functions[term[0]]
    assert tuple(inspect_term(x,variables,functions) for x in term[1:])==tuple(args)
    return sort


def equality_axioms(sorts,functions,predicates):
    clauses=[]
    def relation(sort,*values):
        return ("="+sort,*values)
    def row(name,env,*lits):
        clauses.append(dict(id=name,variables=env,clause=lits))
    for s in sorts:
        x,y,z="?x","?y","?z"
        row("reflexive-"+s,{x:s},(True,relation(s,x,x)))
        row("symmetric-"+s,{x:s,y:s},(False,relation(s,x,y)),(True,relation(s,y,x)))
        row("transitive-"+s,{x:s,y:s,z:s},(False,relation(s,x,y)),(False,relation(s,y,z)),(True,relation(s,x,z)))
    for tag,typ in (("function",functions),("predicate",predicates)):
        for name,spec in typ.items():
            args=spec[0] if tag=="function" else spec
            if not args or name.startswith("="):
                continue
            left=tuple(f"?l{i}" for i in range(len(args)))
            right=tuple(f"?r{i}" for i in range(len(args)))
            env=dict(zip((*left,*right),(*args,*args),strict=True))
            eqs=[(False,relation(s,a,b)) for s,a,b in zip(args,left,right,strict=True)]
            a,b=(name,*left),(name,*right)
            if tag=="function":
                row("congruence-"+name,env,*eqs,(True,relation(spec[1],a,b)))
            else:
                row("substitution-"+name,env,*eqs,(False,a),(True,b))
    return clauses


def signature(case):
    funcs=case["functions"]
    preds=case["predicates"].copy()
    clauses=[dict(id=r["id"],variables=r["variables"],
                  clause=tuple((p,frozen(a)) for p,a in r["clause"])) for r in case["clauses"]]
    if case["equality"]:
        preds.update({"="+s:[s,s] for s in case["sorts"]})
        clauses+=equality_axioms(case["sorts"],funcs,preds)
    clauses.append(dict(id="denied-goal",variables={},clause=((False,frozen(case["goal"])),)))
    assert len({r["id"] for r in clauses})==len(clauses)
    for r in clauses:
        for _,atom in r["clause"]:
            assert tuple(inspect_term(t,r["variables"],funcs) for t in atom[1:])==tuple(preds[atom[0]])
    return funcs,preds,clauses


def ground_terms(case,functions,bound,limit):
    known={s:set() for s in case["sorts"]}
    for i in range(bound+1):
        new={s:v.copy() for s,v in known.items()}
        for name,(args,out) in functions.items():
            for values in product(*(known[s] for s in args)):
                new[out].add((name,*values))
                if len(new[out])>limit:
                    return None
        known=new
    assert all(known.values())
    return {s:sorted(v) for s,v in known.items()}


def instances(clauses,terms,bound,limit):
    atoms={}
    found={}
    def replace(term,subst):
        if isinstance(term,str):
            return subst[term]
        return (term[0],*(replace(p,subst) for p in term[1:]))
    for source in clauses:
        variables=sorted(source["variables"])
        for values in product(*(terms[source["variables"][v]] for v in variables)):
            subst=dict(zip(variables,values,strict=True))
            grounded=[(sign,(p[0],*(replace(t,subst) for t in p[1:])))
                      for sign,p in source["clause"]]
            if any(depth(t)>bound for _,p in grounded for t in p[1:]):
                continue
            clause=set()
            for sign,p in grounded:
                index=atoms.setdefault(p,len(atoms)+1)
                clause.add(index if sign else -index)
            if any(-v in clause for v in clause):
                continue
            key=prop.mask(clause)
            found.setdefault(key,dict(schema=source["id"],substitution=subst))
            if len(found)>limit:
                return None,None
    return atoms,found


def reduce_proof(premises,rows):
    m=len(premises)
    used=sorted({r[k] for r in rows for k in ("left","right") if r[k]<m})
    named={k:i for i,k in enumerate(used)}
    names=sorted({abs(x) for i in used for x in premises[i]})
    atoms={k:i+1 for i,k in enumerate(names)}
    def literal(x):
        return atoms[abs(x)]*(1 if x>0 else -1)
    trimmed=[]
    for i,r in enumerate(rows):
        trimmed.append(dict(left=named[r["left"]],right=named[r["right"]],pivot=atoms[r["pivot"]],
                            clause=[literal(t) for t in r["clause"]]))
        named[m+i]=len(used)+i
    return used,names,[[literal(t) for t in premises[i]] for i in used],trimmed


def verify_instances(schemas,origins,premises,atoms,functions):
    by_name={r["id"]:r for r in schemas}
    for origin,row in zip(origins,premises,strict=True):
        source=by_name[origin["schema"]]
        env=origin["substitution"]
        assert set(env)==set(source["variables"])
        assert all(inspect_term(term,{},functions)==source["variables"][v] for v,term in env.items())
        def ground(term):
            return (term[0],*map(ground,term[1:])) if isinstance(term,tuple) else env[term]
        reference={(sign,(head,*map(ground,terms))) for sign,(head,*terms) in source["clause"]}
        decoded={(v>0,atoms[abs(v)-1]) for v in row}
        assert reference==decoded


def solve(case,protocol,palette):
    functions,_,schemas=signature(case)
    records=[]
    for bound in range(protocol["depth"]+1):
        terms=ground_terms(case,functions,bound,protocol["max_terms"])
        if terms is None:
            records.append(dict(depth=bound,status="TERM_LIMIT"))
            break
        atoms,all_clauses=instances(schemas,terms,bound,protocol["max_ground"])
        if atoms is None:
            records.append(dict(depth=bound,status="INSTANCE_LIMIT"))
            break
        initial=[prop.literals(row) for row in all_clauses]
        record=dict(depth=bound,terms=sum(map(len,terms.values())),clauses=len(initial),atoms=len(atoms))
        if not initial:
            records.append(dict(**record,status="EMPTY_LAYER"))
            continue
        search=prop.Search(initial,protocol["limits"],"ELIMINATE")
        status=search.eliminate(len(atoms))
        records.append(dict(**record,status=status,counts=dict(search.counts)))
        if status!="UNSAT":
            continue
        proof=search.proof()
        prop.verify_resolution(initial,proof)
        used,names,premises,trim=reduce_proof(initial,proof)
        atoms_by_id={i:k for k,i in atoms.items()}
        decoded=[atoms_by_id[i] for i in names]
        originals=list(all_clauses.values())
        origins=[originals[i] for i in used]
        verify_instances(schemas,origins,premises,decoded,functions)
        prop.verify_resolution(premises,trim)
        c,inputs,_=prop.circuit(len(names),premises,trim)
        assert len(c["gates"])<=protocol["gate_limit"]
        cert=prop.wang.certificate(c,inputs,palette)
        physical=prop.independent_wang.verify(c,cert,palette)
        assert physical["status"]=="VERIFIED"
        name=f"data/{case['id']}-wang-v1.json.gz"
        prop.compressed(name,dict(circuit=c,certificate=cert))
        return dict(id=case["id"],status="PROVED",layers=records,depth=bound,atoms=decoded,
                    premise_sources=origins,premises=premises,proof=trim,
                    physical=physical,gates=len(c["gates"]),artifact=dict(path=name,**prop.pin(ROOT/name)))
    return dict(id=case["id"],status="UNRESOLVED",layers=records)


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    cases=prop.load("input/cases-v1.json")
    palette=prop.wang.palette()
    results=[]
    for case in cases:
        result=solve(case,protocol,palette)
        assert result["status"]==case["expected"]
        results.append(result)
        print(json.dumps(dict(case=case["id"],status=result["status"],depth=result.get("depth"),
                              lines=len(result.get("proof",[])),gates=result.get("gates"))),flush=True)
    prop.save("data/results-v1.json",results)
    summary=dict(status="CHECKED_FIRST_ORDER_GROUND_PROOFS_IN_FIXED_WANG_PALETTE",
                 counts=dict(Counter(r["status"] for r in results)),palette_sha256=prop.wang.digest(palette),
                 verified_instances=sum(len(r.get("premises",[])) for r in results),
                 scope="Many-sorted universally closed clauses with ground goals and explicit equality axioms. A separate checker validates every used ground instance. Wang checks the ground resolution; general formula clausification and an in-grid ground-instance checker are separate.")
    prop.save("data/summary-v1.json",summary)
    print(json.dumps(summary,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
