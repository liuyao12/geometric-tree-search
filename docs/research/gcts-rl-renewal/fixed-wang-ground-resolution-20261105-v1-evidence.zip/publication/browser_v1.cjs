const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");
const {pathToFileURL}=require("node:url");
const {chromium}=require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main() {
  const browser=await chromium.launch({
    executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless:true,args:["--disable-breakpad","--disable-background-networking"],
  });
  try {
    const page=await browser.newPage({viewport:{width:1260,height:880}});
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const local=pathToFileURL(path.join(__dirname,"..","report","fixed-wang-ground-resolution-20261105-v1.html"));
    const response=await page.goto(process.argv[2]||local.href,{waitUntil:"load"});
    if(process.argv[2]) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===65);
    const evidence=await page.evaluate(()=>{
      const data=JSON.parse(document.getElementById("proof-data").textContent);
      const menu=document.getElementById("case-menu");
      let lines=0, tiles=0;
      for(let i=0;i<menu.options.length;i++) {
        menu.value=String(i);
        menu.dispatchEvent(new Event("change"));
        const article=document.querySelector("article[data-theorem='"+i+"']");
        if(article.hidden) throw new Error("Selected theorem hidden");
        for(const button of article.querySelectorAll("[data-line]")) {
          button.click();
          if(button.getAttribute("aria-pressed")!=="true") throw new Error("Missing selected proof line");
          const expected=Object.values(data[i][Number(button.dataset.line)]).flat();
          const actual=Array.from(document.querySelectorAll(".square"));
          if(actual.length!==expected.length||actual.some((x,j)=>Number(x.textContent)!==expected[j].id)) {
            throw new Error("Actual Wang strip does not match decoded tiles");
          }
          tiles+=actual.length;
          lines++;
        }
      }
      return {cases:menu.options.length,lines,tiles,math:document.querySelectorAll("mjx-container").length};
    });
    assert.deepEqual(errors,[]);
    assert.equal(evidence.cases,4);
    assert.equal(evidence.lines,32);
    await page.selectOption("#case-menu","0");
    await page.locator("article[data-theorem='0'] button").last().click();
    if(!process.argv[2]) await page.locator("#reader").screenshot({path:path.join(__dirname,"browser-v1.png")});
    await page.setViewportSize({width:390,height:844});
    const mobile=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert.equal(mobile,true);
    const result={status:"CHECKED_WANG_LINE_READER",...evidence,mobile_no_overflow:mobile};
    const name=process.argv[2]?"live-browser-v1.json":"browser-v1.json";
    fs.writeFileSync(path.join(__dirname,name),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
