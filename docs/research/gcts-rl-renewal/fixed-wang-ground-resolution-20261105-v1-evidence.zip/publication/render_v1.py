"""Render checked first-order proof lines and literal Wang tile excerpts."""

import gzip
import hashlib
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
STEM="fixed-wang-ground-resolution-20261105-v1"
OLD="fixed-wang-two-counter-20261105-v1.html"

LABELS={
    "one-plus-one":("One plus one",r"\operatorname{Add}(S(0),S(0),S(S(0)))",
                    "The hypotheses define the zero and successor steps of the addition relation."),
    "successor-congruence":("Successor preserves equality twice",r"a=b\ \Longrightarrow\ S(S(a))=S(S(b))",
                            "The hypotheses contain one equality. Congruence is generated from the declared successor symbol."),
    "hilbert-line-uniqueness":("Hilbert line uniqueness",r"L=M",
                               "The hypotheses say that distinct points lie on both lines. The only geometry used is the symbolic incidence uniqueness axiom."),
    "quantified-dilemma":("Quantified dilemma",r"R(w(c))",
                         "At each input one of two cases holds. Either case implies the result at its image under the declared function."),
}


def read(p):
    return json.loads(p.read_bytes())


def pin(p):
    b=p.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def unpack(p):
    with gzip.open(p,"rt") as f:
        return json.load(f)


def audit():
    root=ROOT/"input"
    summaries={}
    for name in ("propositional","ground","in-grid"):
        part=root/name
        protocol=read(part/"protocol-v1.json")
        assert all(pin(part/n)==h for n,h in protocol["pins"].items())
        assert not (part/"data/execution.stderr.log").read_bytes()
        summaries[name]=read(part/"data/summary-v1.json")
    assert len({r["palette_sha256"] for r in summaries.values()})==1
    assert summaries["propositional"]["physical"]=={"VERIFIED":7}
    assert summaries["ground"]["counts"]=={"PROVED":4,"UNRESOLVED":1}
    assert summaries["in-grid"]["checked"]==4 and summaries["in-grid"]["mutation_rejections"]==36
    sys.path.insert(0,str(root/"in-grid/source"))
    import fixed_palette_v1 as wang
    import ribbon_checker_v3 as independent
    results=[]
    ground={r["id"]:r for r in read(root/"ground/data/results-v1.json") if r["status"]=="PROVED"}
    palette=wang.palette()
    for entry in read(root/"in-grid/data/results-v1.json"):
        ref=entry["artifact"]
        path=root/"in-grid"/ref["path"]
        assert pin(path)=={k:ref[k] for k in ("bytes","sha256")}
        artifact=unpack(path)
        circuit,certificate=artifact["circuit"],artifact["certificate"]
        check=independent.verify(circuit,certificate,palette)
        assert check==entry["checked"]
        assert all(i["value"] is None for i in circuit["inputs"][2:])
        logical=ground[entry["id"]]
        total=len(logical["premises"])+len(logical["proof"])
        excerpts=[]
        for k in range(total):
            m=len(logical["premises"])
            role=f"premise{k}" if k<m else f"line{k-m}"
            segments={}
            previous=None
            for x,column in enumerate(circuit["inputs"]):
                parts=column["name"].split(":")
                if parts[0]!=role:
                    continue
                tile=palette["tiles"][wang.tile_at(circuit,certificate,x,0)]
                assert tile["N"][1]==certificate["input_bits"][x]
                if previous:
                    assert previous["x"]+1==x and previous["E"]==tile["W"]
                previous=dict(x=x,**tile)
                segments.setdefault(parts[1],[]).append(previous)
            assert segments
            excerpts.append(segments)
        results.append(dict(id=entry["id"],logical=logical,tiles=excerpts,receipt=entry))
    assert set(LABELS)=={r["id"] for r in results}
    return dict(status="CHECKED_WANG_GROUND_PROOF_READER",summary=summaries,cases=results)


def term(t):
    name={"zero":"0","s":"S"}.get(t[0],t[0])
    if not t[1:]:
        return name
    return name+r"\left("+", ".join(map(term,t[1:]))+r"\right)"


def atom(t):
    p,args=t[0],t[1:]
    if p.startswith("="):
        return f"{term(args[0])}={term(args[1])}"
    head=rf"\operatorname{{{p}}}"
    return head+r"\left("+", ".join(map(term,args))+r"\right)"


def clause(ids,atoms):
    if not ids:
        return r"\bot"
    values=[]
    for i in ids:
        p=atom(atoms[abs(i)-1])
        if i<0:
            p=(p.replace("=",r"\ne",1) if atoms[abs(i)-1][0].startswith("=") else r"\neg "+p)
        values.append(p)
    return r"\,\lor\, ".join(values)


def lines(case):
    proof=case["logical"]
    atoms=proof["atoms"]
    rows=[]
    for i,(row,origin) in enumerate(zip(proof["premises"],proof["premise_sources"],strict=True),1):
        name=escape(origin["schema"].replace("-"," "))
        env=", ".join(rf"\({escape(v.lstrip('?'))}\mapsto {term(t)}\)"
                      for v,t in sorted(origin["substitution"].items()))
        action="Take the denied goal." if origin["schema"]=="denied-goal" else (
            f"Instantiate <em>{name}</em> with {env}." if env else f"Take <em>{name}</em>.")
        rows.append((i,clause(row,atoms),action))
    for i,row in enumerate(proof["proof"],len(rows)+1):
        pivot=atom(atoms[row["pivot"]-1])
        action=rf"Resolve lines {row['left']+1} and {row['right']+1} on \({pivot}\)."
        rows.append((i,clause(row["clause"],atoms),action))
    return rows


def table(head,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{x}</th>' for x in head)+(
        '</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{v}</td>' for v in r)+'</tr>' for r in rows)+
        '</tbody></table></div>')


VIEWER=r"""
const cases=JSON.parse(document.getElementById("proof-data").textContent);
const menu=document.getElementById("case-menu");
const active=document.getElementById("tile-strip");
const count=document.getElementById("strip-title");
const labels={schema:"Schema",positive:"Positive literals",negative:"Negative literals",
              left:"Left parent",right:"Right parent",pivot:"Pivot"};
function bitColor(n) {return n?"#a65b23":"#28728c";}
function line(which,n) {
  for (const button of document.querySelectorAll("[data-line]")) {
    button.setAttribute("aria-pressed",String(button.dataset.case===String(which)&&
                                      button.dataset.line===String(n)));
  }
  count.textContent="Proof line "+String(n+1)+" · actual squares from the top Wang row";
  active.replaceChildren();
  for (const [field,tiles] of Object.entries(cases[which][n])) {
    const group=document.createElement("div");
    group.className="segment "+(field.startsWith("term")?"term":field);
    const title=document.createElement("div");
    title.className="segment-title";
    title.textContent=labels[field]||(field.startsWith("term")?"Term "+String(Number(field.slice(4))+1):field);
    group.append(title);
    const strip=document.createElement("div");
    strip.className="squares";
    for (const t of tiles) {
      const square=document.createElement("span");
      square.className="square";
      square.style.borderTopColor=bitColor(t.N[1]);
      square.style.borderBottomColor=bitColor(t.S[1]);
      square.style.borderLeftColor=bitColor(t.W);
      square.style.borderRightColor=bitColor(t.E);
      square.textContent=String(t.id);
      square.title="Column "+t.x+" · N "+t.N.join(" ")+" · E "+t.E+" · S "+t.S.join(" ")+" · W "+t.W;
      square.setAttribute("aria-label",square.title);
      strip.append(square);
    }
    group.append(strip);
    active.append(group);
  }
}
function choose() {
  const value=Number(menu.value);
  for (const part of document.querySelectorAll("[data-theorem]")) {
    part.hidden=Number(part.dataset.theorem)!==value;
  }
  line(value,0);
}
for (const button of document.querySelectorAll("[data-line]")) {
  button.addEventListener("click",()=>line(Number(button.dataset.case),Number(button.dataset.line)));
}
menu.addEventListener("change",choose);
choose();
"""


def render(data):
    methods=data["summary"]["propositional"]["methods"]
    comparison=table(("Method","Refuted","Models checked","Bounded","Resolution pivots checked"),
        [(name,methods[k]["outcomes"].get("UNSAT",0),methods[k]["outcomes"].get("SAT",0),
          methods[k]["outcomes"].get("BOUNDED",0),f'{methods[k]["pivots"]:,}')
         for k,name in (("GIVEN","Given clause"),("MARKED","Given clause with markings"),
                        ("ELIMINATE","Minimum-product variable elimination"))])
    options=[]
    articles=[]
    for i,c in enumerate(data["cases"]):
        name,goal,description=LABELS[c["id"]]
        options.append(f'<option value="{i}">{name}</option>')
        proof_rows=[]
        for n,f,s in lines(c):
            button=f'<button data-case="{i}" data-line="{n-1}" aria-pressed="false">Show line {n}</button>'
            proof_rows.append((n,rf"\({f}\)",s,button))
        grid=table(("Line","Clause","Reading","Wang squares"),proof_rows)
        a=c["receipt"]
        articles.append(rf"""<article data-theorem="{i}"><h3>{name}</h3>
<p><strong>Goal</strong> \({goal}\). {description}</p>
<p>{a["premises"]} instantiated premise rows, {len(c["logical"]["proof"])} resolution rows and {a["gates"]:,} verified gate rows.</p>
{grid}</article>""")
    payload=json.dumps([c["tiles"] for c in data["cases"]],separators=(",",":")).replace("<","\\u003c")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>First-order proof lines in a fixed Wang palette</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{{font-family:system-ui,sans-serif;color:#193642;background:#eaf0f2}}body{{margin:0}}
main{{max-width:68rem;margin:auto;padding:2.4rem clamp(1rem,4vw,2.6rem) 4rem;background:white}}
h1,h2{{line-height:1.17}}h1{{font-size:clamp(2.25rem,6vw,3.55rem);letter-spacing:-.042em;margin:.35em 0}}
h2{{margin-top:2rem}}p,li{{line-height:1.55}}nav{{display:flex;flex-wrap:wrap;gap:1rem;margin:1.2rem 0 1.8rem}}
a{{color:#075c78}}.meta{{color:#516875}}.scroll{{overflow:auto}}
table{{border-collapse:collapse;width:100%;text-align:left}}td,th{{padding:.55rem;border-bottom:1px solid #d1e0e1}}
th{{background:#eef4f4}}td:nth-child(2){{white-space:nowrap}}button,select{{font:inherit;padding:.35rem .5rem}}
button{{white-space:nowrap}}button[aria-pressed=true]{{background:#cdece7;border-color:#47796f}}
.strip{{display:flex;align-items:flex-start;gap:.65rem;overflow:auto;padding:.55rem;background:#f1f6f7}}
.segment-title{{font-size:.8rem;font-weight:650;padding:.2rem .3rem;background:#d9e9ec;white-space:nowrap}}
.segment.term .segment-title,.segment.pivot .segment-title{{background:#f5e5cf}}
.segment.positive .segment-title{{background:#d5ece6}}.segment.negative .segment-title{{background:#e6e0f1}}
.squares{{display:flex}}.square{{display:grid;place-items:center;width:2rem;height:2rem;box-sizing:border-box;
  border:3px solid;font:600 .78rem ui-monospace,monospace;background:white;flex:none}}
</style></head><body><main><p class="meta">Geometric tree search · Wang proof search · November 5, 2026</p>
<h1>First-order proof lines in a fixed Wang palette</h1>
<p>Four clausal first-order proofs were found automatically and checked in the same 100-square palette. The rectangle checks both the grounding of each premise and the resolution steps that derive a contradiction.</p>
<nav aria-label="Sections"><a href="#reader">Read the proofs</a><a href="#kernel">What the squares check</a><a href="#comparison">Search comparison</a><a href="#evidence">Evidence</a></nav>
<section id="reader"><h2>Read a proof line by line</h2>
<label for="case-menu">Theorem</label> <select id="case-menu">{"".join(options)}</select>
<h3 id="strip-title"></h3><div class="strip" id="tile-strip" role="region" aria-label="Wang proof witness tile strip" tabindex="0"></div>
<p>The numbered squares are from the top row of the verified rectangle. Blue and amber edges carry bit values zero and one. The full vertical edge also carries a gate selector. Field labels group the witness columns for reading. Select a line below to see its corresponding strip.</p>
{"".join(articles)}
</section>
<section id="kernel"><h2>What the square grid checks</h2>
<p>A premise selects a clausal schema and a typed substitution. The circuit requires each schema literal to produce a ground atom, then checks every bit of the resulting clause. Each derived row selects two earlier clauses and a pivot. The final clause must be empty. The four rectangles rejected 36 changes to individual premise bits.</p>
<p>The palette is fixed and tiles only by translation. The finite term bound, typed atom catalogue and interior gate selectors are fixed instance data. The schema choices, substitution choices, proof references and clause bits are free certificate fields. Compressed ribbons check the full rectangle through repeated transport rules. The excerpt above shows the input columns for one logical line. Its checking gates can span many physical rows.</p>
<p>The ground search enumerates finite term layers. Exhausting one layer without a refutation leaves the first-order problem open. This experiment starts with clauses. It leaves a general formula-to-clause front end and the unbounded search implementation open.</p>
</section>
<section id="comparison"><h2>Propositional search comparison</h2>
<p>In a separate 13-case cohort, a pair marking rules out all its pivots when two complementary atoms remain available. A subsumption marking skips a candidate clause when an existing clause already implies it. The checker replayed every marking explanation.</p>
{comparison}
<p>The marked given-clause method checked fewer pivots than its unmarked counterpart on this cohort. Conventional variable elimination completed two additional cases. Seven of the automatically found propositional proofs also passed physical ribbon checks. The first run stopped at its compile ceiling. The revised run retained the original logs and used a larger declared ceiling with separate certificate outputs.</p>
</section>
<section id="evidence"><h2>Evidence</h2><ul>
<li><a href="{STEM}-results.json">Proof lines, tile excerpts and verification receipts</a></li>
<li><a href="{STEM}-evidence.zip">Full sources, frozen inputs, search logs and Wang certificates</a></li>
<li><a href="{STEM}-manifest.json">Archive file hashes</a></li>
<li><a href="{OLD}">Earlier fixed Wang computational verifier</a></li>
</ul></section></main>
<script id="proof-data" type="application/json">{payload}</script><script>{VIEWER}</script></body></html>"""


def main():
    data=audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(render(data))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(data,f,sort_keys=True,separators=(",",":"))
        f.write("\n")
    print(json.dumps(dict(status=data["status"],cases=len(data["cases"]),
                          lines=sum(len(r["tiles"]) for r in data["cases"]))),flush=True)


if __name__=="__main__":
    main()
