"""Prospective cluster-REINFORCE study with exact point-region witnesses.

All scientific records are per-run files; the final index retains their hashes.
No full-cohort compressed checkpoint rewrite and no earlier target proof input.
"""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT.parent/'gcts-turtle-corona-20261103-v1'
LANES=('UNMARKED_LEX','MARKED_LEX','MARKED_BASE_HEURISTIC','MARKED_CLUSTER_HEURISTIC','MARKED_CLUSTER_RANDOM','MARKED_CLUSTER_RL')
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(v):return hashlib.sha256(wire(v)).hexdigest()
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wire(v))
def load(p):
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def blob(relative,v):
    p=ROOT/relative;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=1,mtime=0) as f:f.write(wire(v))
    return dict(run_file=relative,run_pin=pin(p))
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def hexagon(r):return {(x,y) for x in range(-r,r+1) for y in range(-r,r+1) if max(abs(x),abs(y),abs(x+y))<=r}
def cases(model):
    seed=next(o['points'] for o in model['orientations'] if o['id']==0);support={(x,y) for x,y,u in seed}
    center=((min(x for x,y in support)+max(x for x,y in support))//2,(min(y for x,y in support)+max(y for x,y in support))//2)
    def case(cid,label,points,offset=(0,0)):
        target={(x+center[0]+offset[0],y+center[1]+offset[1]) for x,y in points};core=target|support
        return dict(id=cid,label=label,center=list(center),offset=list(offset),target=[list(p) for p in sorted(target)],core=[list(p) for p in sorted(core)],core_sha256=digest([list(p) for p in sorted(core)]),seeds=[[0,0,0]])
    train=[case('T00','hexagonal point mask radius2',hexagon(2)),case('T01','hexagonal point mask radius3',hexagon(3)),case('T02','short rectangular point mask',{(x,y) for x in range(-2,3) for y in range(-1,3)}),case('T03','notched point mask',{p for p in hexagon(3) if not(p[0]>0 and p[1]>0)}),case('T04','three axial obligation arms',{p for p in hexagon(3) if p[0]==0 or p[1]==0 or sum(p)==0}),case('T05','overlapping small point masks',hexagon(2)|{(x+2,y) for x,y in hexagon(2)}),case('T06','short obligation strip',{(x,y) for x in range(-3,4) for y in range(-1,2)}),case('T07','diagonal cut point mask',{p for p in hexagon(3) if p[1]<=p[0]+1})]
    test=[case('H00','hexagonal point mask radius4',hexagon(4)),case('H01','hexagonal point mask radius5',hexagon(5)),case('H02','hexagonal point mask radius6',hexagon(6)),case('H03','shifted hexagonal point mask',hexagon(4),(1,-1)),case('H04','shifted larger point mask',hexagon(5),(-1,0)),case('H05','wide obligation rectangle',{(x,y) for x in range(-4,5) for y in range(-2,3)}),case('H06','tall obligation rectangle',{(x,y) for x in range(-2,3) for y in range(-4,5)}),case('H07','larger notched point mask',{p for p in hexagon(5) if not(p[0]>=2 and p[1]>=0)}),case('H08','annular obligation mask with unconstrained interior',hexagon(5)-hexagon(1),(2,-1)),case('H09','two overlapping medium point masks',{(x-3,y) for x,y in hexagon(3)}|{(x+3,y) for x,y in hexagon(3)}),case('H10','zigzag obligation band',{(x,y) for x,y in hexagon(6) if abs(y-x//2)<=1}),case('H11','off-center point mask',hexagon(4),(2,1))]
    assert len({c['core_sha256'] for c in test})==12
    assert not ({c['core_sha256'] for c in train}&{c['core_sha256'] for c in test})
    return train,test

def freeze():
    preparation_started=time.perf_counter();ref=ROOT/'reference';ref.mkdir(parents=True,exist_ok=True)
    for old,new in [('data/results-v1.json.gz','parent-results-v1.json.gz'),('reference/input-point-model-v1.json','original-point-data-v1.json'),('data/qualification-fixtures-v1.json','parent-qualification-fixtures-v1.json'),('publication/live-complete-v1.json','parent-live-complete-v1.json')]:shutil.copyfile(PARENT/old,ref/new)
    p=load(ref/'parent-results-v1.json.gz');train,test=cases(p['model']);save(ROOT/'data/unmarked-model-v1.json',p['model']);save(ROOT/'data/marked-model-v1.json',p['marked_model']);save(ROOT/'data/cases-v1.json',dict(training=train,heldout=test))
    jobs=[]
    for repeat in range(2):
        for i,c in enumerate(test):
            shift=(i+repeat)%len(LANES)
            for lane in LANES[shift:]+LANES[:shift]:jobs.append(dict(index=len(jobs),case_id=c['id'],lane=lane,repeat=repeat,seed=2026110300+repeat*10000+i*101+LANES.index(lane)))
    save(ROOT/'data/evaluation-jobs-v1.json',jobs)
    paths=sorted([p for d in ('source','reference') for p in (ROOT/d).rglob('*') if p.is_file()])+sorted((ROOT/'data').glob('*.json'))
    protocol=dict(schema='Turtle-cluster-RL-prospective-protocol-v1',pins={str(p.relative_to(ROOT)):pin(p) for p in paths},train_case_ids=[c['id'] for c in train],heldout_case_ids=[c['id'] for c in test],train_episodes=48,train_limit=dict(nodes=200,seconds=1.5,depth=64,cache=16000),test_limit=dict(nodes=300,seconds=3.0,depth=96,cache=16000),training_wall_limit=240,evaluation_wall_limit=1200,lanes=list(LANES),evaluation_jobs=len(jobs),repeats=2,proposal_cap=48,max_templates=32,learning_rate=0.03,initial_policy_weights='all zero',learning='Stochastic linear-softmax REINFORCE from verified episode reward; evaluate deterministic argmax with bank/weights frozen before any heldout search',reward='2*verified_success - verified_negative + verified_core_units/core_total_units - 0.10*min(search_seconds,limit)/limit - 0.02*visits/node_limit',training_order='Episode e uses training case e modulo8; deterministic distinct episode RNGseed',region_semantics='Every listed core point, including untouched zeros, is an explicit generation0 obligation; all seed support included. New positive support activates too. Exterior unconstrained by target geometry; every exposed frontier must be viable at finite checkpoint. No continuous polygon-region coverage claim.',clusters='Eight prior automatically found checked marked-corona expansions; add normalized length8..12 windows stride4 from independently positive training patches, max32templates. Each proposal validates aggregate t/m plus parent interface; only current branch anchor is ordered first, with all base candidates retained. No macro or sequence execution.',comparisons='Five marked lanes solve one fixed learned restricted model; unmarked lexical lane is a separate baseline, not a claim that learned marks preserve all unmarked solutions.',assurance='Every training best viable snapshot and every positive patch independently checked; every actual main search tree checked; every bank template and all12images audited; first/last selected cluster proposals perrun audited. Unknown/checker resource stops do not become negative.',costs='Full training/preparation/validation/recording/evaluation costs timed. Parent200.096s marking/corona acquisition is reused, not rerun or hidden; no complete cold speedup claim from search-only timings.',recording='Per-run immutable gzip records compressionlevel1; compact final index with byte/hash references. All raw search returns retained before assurance.',input_preparation_seconds=time.perf_counter()-preparation_started)
    save(ROOT/'data/protocol-frozen-v1.json',protocol);print(json.dumps(dict(status='FROZEN',pins=len(paths),train_core_sizes=[len(c['core']) for c in train],heldout_core_sizes=[len(c['core']) for c in test],jobs=len(jobs))),flush=True)

def check_sources(protocol):
    for name,p in protocol['pins'].items():assert pin(ROOT/name)==p,name
def metrics(model,placements,core):
    fields={o['id']:o['points'] for o in model['orientations']};totals={}
    for g,dx,dy in placements:
        for x,y,u in fields[g]:totals[x+dx,y+dy]=totals.get((x+dx,y+dy),0)+u
    return sum(min(model['capacity'],totals.get(tuple(p),0)) for p in core)
def assure(V,C,model,result,policy,bank,groups):
    started=time.perf_counter();tree=V.check_tree(model,result)
    assert tree['status']!='REJECTED',tree
    patch=V.check_patch(model,result['placements'],result['core']) if result['status']=='POSITIVE' else None
    best=V.check_snapshot(model,result['final_snapshot']) if result.get('best_prefix_viable') else None
    if best is not None:assert best['status']=='VERIFIED' and not best['dead_points'],best
    for s in result.get('audit_snapshots',[]):assert V.check_snapshot(model,s)['status']=='VERIFIED'
    cluster_checks=[]
    if policy is not None:
        events=policy['chosen_cluster_events'];chosen=[e for e in (events['first'],events['last']) if e is not None]
        if len(chosen)==2 and chosen[0]==chosen[1]:chosen.pop()
        for e in chosen:
            template=next(t for t in bank.templates if t['id']==e['cluster_id'])
            a=C.check_proposal(model,e['parent_snapshot'],e['expansion'],e['anchor']);b=C.check_transform(model,groups,template['placements'],e['action_gid'],e['translation'],e['expansion'])
            assert a['status']==b['status']=='VERIFIED',(a,b);cluster_checks.append(dict(proposal=a,transform=b))
    status=result['status']
    if status=='POSITIVE' and (patch is None or patch['status']!='VERIFIED'):status='UNKNOWN'
    if status=='NEGATIVE' and tree['status']!='VERIFIED':status='UNKNOWN'
    return dict(status=status,tree=tree,patch=patch,best=best,cluster_checks=cluster_checks,seconds=time.perf_counter()-started)

def qualify(E,V,C,P,model,groups,donors,bank):
    started=time.perf_counter();records=[]
    for fixture in load(ROOT/'reference/parent-qualification-fixtures-v1.json'):
        kw={k:fixture[k] for k in ('node_limit','depth_limit','seconds') if k in fixture};kw.setdefault('seconds',30)
        r=E.search(fixture['model'],fixture['seeds'],fixture['core'],grow=fixture['grow'],audit=True,**kw);assert r['status']==fixture['expected']
        t=V.check_tree(fixture['model'],r);assert t['status']=='VERIFIED'
        checks=[V.check_snapshot(fixture['model'],s) for s in r['audit_snapshots']];assert all(x['status']=='VERIFIED' for x in checks)
        records.append(dict(name=fixture['name'],search=r,tree=t,snapshots=checks))
    tiny=dict(capacity=12,orientations=[dict(id=0,points=[[0,0,6],[1,0,6]])])
    r=E.search(tiny,[],[[0,0]],cache_limit=2,audit=True,seconds=30);assert r['status']=='UNKNOWN' and 'cache' in r['budget_hits'];assert V.check_tree(tiny,r)['status']=='VERIFIED';records.append(dict(name='mid-trial-cache-rollback',search=r))
    r=E.search(tiny,[],[[0,0],[100,0]],cache_limit=1,seconds=30);assert r['status']=='UNKNOWN' and r['final_snapshot'] is None;assert V.check_tree(tiny,r)['status']=='VERIFIED';records.append(dict(name='initial-cache-no-reward',search=r))
    # A branch-local capacity reject must get fresh m-dependencies in a sibling.
    lazy=dict(capacity=12,orientations=[dict(id=i,points=p) for i,p in enumerate([[[0,0,4]],[[0,0,4],[1,0,4],[2,0,12]],[[0,0,4],[1,0,4]],[[1,0,4],[2,0,4]],[[3,0,12]]])],marking_orientations=[dict(id=3,points=[[100,100,'far',1]]),dict(id=4,points=[[100,100,'far',0]])],allowed_placements=[[i,0,0] for i in range(5)])
    e=E.Engine(lazy,[[0,0,0]],[[0,0],[3,0]]);before=e.logical_digest();mark=len(e.trail);snapshots=[e.snapshot()]
    e.place((1,0,0));assert (3,0,0) in e.tcache and (3,0,0) not in e.cache;snapshots.append(e.snapshot());e.rollback(mark)
    assert (3,0,0) not in e.reg and e.logical_digest()==before
    e.place((2,0,0));assert (3,0,0) in e.valid and (3,0,0) in e.cache;snapshots.append(e.snapshot());e.place((4,0,0));assert (3,0,0) not in e.valid;snapshots.append(e.snapshot());e.rollback(mark);assert e.logical_digest()==before
    checks=[V.check_snapshot(lazy,s) for s in snapshots];assert all(c['status']=='VERIFIED' for c in checks);records.append(dict(name='lazy-capacity-sibling-mark-dependency',snapshots=snapshots,checks=checks))
    region=load(ROOT/'data/cases-v1.json')['training'][1];e=E.Engine(model,region['seeds'],region['core']);s=e.snapshot();receipt=V.check_snapshot(model,s);assert receipt['status']=='VERIFIED';records.append(dict(name='untouched-region-roots-complete-graph',snapshot=s,check=receipt))
    # A saved successful branch path supplies a shared-placement proposal fixture.
    source=donors[0]['search'];engine=E.Engine(model,source['seeds'],source['core']);sequence=source['placements'][len(source['seeds']):]
    while engine.decision()['kind']=='forced':
        candidate=sequence.pop(0);assert candidate in engine.decision()['candidates'];engine.place(candidate)
    assert engine.decision()['kind']=='branch';anchor=sequence[0];assert anchor in engine.decision()['candidates']
    snapshot=engine.snapshot();whole=source['placements'];receipt=C.check_proposal(model,snapshot,whole,anchor);assert receipt['status']=='VERIFIED' and receipt['shared_selected_placements_counted_once']
    corrupted=whole+[anchor];assert C.check_proposal(model,snapshot,corrupted,anchor)['status']=='REJECTED'
    qbank=P.Bank(model,groups,max_templates=32);verified=V.check_patch(model,whole,source['core']);assert verified['status']=='VERIFIED'
    qbank.add_from_positive([anchor]+[p for p in whole if p!=anchor],dict(source='qualification shared branch fixture only'),verified)
    before=engine.logical_digest();packet=P.propose(engine,engine.decision()['candidates'],qbank,48);assert before==engine.logical_digest()
    assert any(a['kind']=='cluster' for a in packet['actions'])
    checks=[]
    for action in packet['actions']:
        c=C.check_proposal(model,snapshot,action['primitive_expansion'],action['anchor']);assert c['status']=='VERIFIED';checks.append(c)
    controller=P.Controller(qbank,'MARKED_CLUSTER_HEURISTIC',seed=44);order=controller(engine,engine.decision()['candidates']);assert sorted(order)==sorted(tuple(c) for c in engine.decision()['candidates']) and before==engine.logical_digest();assert controller.snapshot()['chosen_cluster_events']['seen']>0
    records.append(dict(name='joint-proposals-and-complete-fallback',shared_proposal=receipt,valid_actions=len(checks),checks=checks,controller=controller.snapshot()))
    hook_model=dict(capacity=12,orientations=[dict(id=i,points=[[0,0,12]]) for i in range(2)],allowed_placements=[[i,0,0] for i in range(2)])
    rejected=[]
    for label,callback in [('omitted-candidate',lambda e,c:c[:1]),('duplicated-candidate',lambda e,c:[c[0],c[0]])]:
        try:E.search(hook_model,[],[[0,0]],order=callback,audit=True,seconds=30)
        except AssertionError:rejected.append(label)
        else:raise AssertionError('Malformed ordering callback was accepted')
    def mutation(e,c):e.gen[0,0]=9;return c
    try:E.search(hook_model,[],[[0,0]],order=mutation,audit=True,seconds=30)
    except AssertionError:rejected.append('logical-state-mutation')
    else:raise AssertionError('Mutating ordering callback was accepted')
    forced=dict(hook_model,allowed_placements=[[0,0,0]]);calls=[]
    r=E.search(forced,[],[[0,0]],order=lambda e,c:(calls.append(1) or c),audit=True,seconds=30);assert r['status']=='POSITIVE' and not calls;records.append(dict(name='callback-contract',rejected=rejected,forced_hook_calls=len(calls)))
    save(ROOT/'data/qualification-v1.json',dict(status='PASS',records=records,seconds=time.perf_counter()-started));return dict(status='PASS',records=len(records),seconds=time.perf_counter()-started)

def run():
    started=time.perf_counter();protocol=load(ROOT/'data/protocol-frozen-v1.json');check_sources(protocol)
    E=module('point_engine_v2',ROOT/'source/point_engine_v2.py');P=module('cluster_policy',ROOT/'source/cluster_policy_v1.py');V=module('point_checker_v2',ROOT/'reference/independent_checker_v2.py');C=module('cluster_checker',ROOT/'reference/cluster-checker-v1.py')
    data=load(ROOT/'reference/parent-results-v1.json.gz');original=load(ROOT/'reference/original-point-data-v1.json');groups=original['groups'];marked=load(ROOT/'data/marked-model-v1.json');unmarked=load(ROOT/'data/unmarked-model-v1.json');cohort=load(ROOT/'data/cases-v1.json');bank=P.Bank(marked,groups,max_templates=32)
    preparation=time.perf_counter();admissions=[]
    for row in data['marked_followup']:
        proof=V.check_patch(marked,row['search']['placements'],row['search']['core']);assert proof['status']=='VERIFIED'
        admissions.append(bank.add_from_positive(row['search']['placements'],dict(source='parent marked followup',pair_index=row['index']),proof))
    save(ROOT/'data/initial-bank-v1.json',bank.snapshot());prep_seconds=time.perf_counter()-preparation;q=qualify(E,V,C,P,marked,groups,data['marked_followup'],bank);print(json.dumps(dict(phase='QUALIFICATION',**q,initial_bank=len(bank.templates))),flush=True)
    controller=P.Controller(bank,'MARKED_CLUSTER_RL',training=True,seed=20261103,learning_rate=protocol['learning_rate']);training=[];training_started=time.perf_counter()
    for episode in range(protocol['train_episodes']):
        case=cohort['training'][episode%len(cohort['training'])]
        if time.perf_counter()-training_started>=protocol['training_wall_limit']:
            training.append(dict(episode=episode,case_id=case['id'],status='UNKNOWN',reason='NOT_RUN_TRAINING_WALL_LIMIT',run_file=None));continue
        controller.start_episode(seed=20261103+episode*1987);limits=protocol['train_limit']
        search=E.search(marked,case['seeds'],case['core'],node_limit=limits['nodes'],seconds=limits['seconds'],depth_limit=limits['depth'],cache_limit=limits['cache'],order=controller)
        raw=blob('data/raw/train-%03d-search.json.gz'%episode,search);before=controller.snapshot();a=assure(V,C,marked,search,before,bank,groups)
        units=metrics(marked,search['placements'],case['core']) if search.get('best_prefix_viable') and a['best']['status']=='VERIFIED' else 0
        if search.get('best_prefix_viable'):assert units==search['best_core_units']
        success=int(a['status']=='POSITIVE');negative=int(a['status']=='NEGATIVE');total=marked['capacity']*len(case['core']);reward=2*success-negative+units/total-0.10*min(search['seconds'],limits['seconds'])/limits['seconds']-0.02*search['stats']['visits']/limits['nodes']
        reward_check=dict(status='VERIFIED',success=success,negative=negative,progress_units=units,core_total_units=total,search_seconds=search['seconds'],seconds_limit=limits['seconds'],visits=search['stats']['visits'],node_limit=limits['nodes'],scope='Credit only independently verified viable graph/positive patch; no viable snapshot receives zero progress credit.')
        update=controller.finish_episode(reward);policy=controller.snapshot();addition=None
        if success:addition=bank.add_from_positive(search['placements'],dict(source='verified training episode',episode=episode,case_id=case['id']),a['patch'],windows=True)
        record=dict(episode=episode,case_id=case['id'],lane='MARKED_CLUSTER_RL',status=a['status'],search=search,policy=policy,update=update,reward=reward,reward_check=reward_check,assurance=a,bank_admission=addition,raw=raw)
        ref=blob('data/training/train-%03d.json.gz'%episode,record);training.append(dict(episode=episode,case_id=case['id'],status=a['status'],reward=reward,search_seconds=search['seconds'],**ref));print(json.dumps(dict(phase='TRAIN',episode=episode,case=case['id'],status=a['status'],reward=reward,nodes=search['stats']['visits'],clusters=policy['telemetry']['chosen_cluster_actions'],bank=len(bank.templates))),flush=True)
    training_seconds=time.perf_counter()-training_started;frozen_bank=bank.freeze();frozen_policy=controller.freeze();save(ROOT/'data/frozen-bank-v1.json',frozen_bank);save(ROOT/'data/frozen-policy-v1.json',frozen_policy)
    bank_checks=[]
    for template in bank.templates:
        base=C.check_cluster(marked,template['placements']);assert base['status']=='VERIFIED' and base['positive_support_connected'];images=[]
        for g in range(12):
            expansion=[list(p) for p in bank.anchor(template,[g,0,0])];check=C.check_transform(marked,groups,template['placements'],g,[0,0],expansion);assert check['status']=='VERIFIED';images.append(check)
        bank_checks.append(dict(cluster_id=template['id'],base=base,images=images))
    save(ROOT/'data/bank-checks-v1.json',dict(status='VERIFIED',templates=bank_checks));evaluation=[];evaluation_started=time.perf_counter();by_id={c['id']:c for c in cohort['heldout']}
    for job in load(ROOT/'data/evaluation-jobs-v1.json'):
        if time.perf_counter()-evaluation_started>=protocol['evaluation_wall_limit']:
            evaluation.append(dict(**job,status='UNKNOWN',reason='NOT_RUN_EVALUATION_WALL_LIMIT',run_file=None));continue
        case=by_id[job['case_id']];lane=job['lane'];model=unmarked if lane=='UNMARKED_LEX' else marked;policy=None;order=None;limits=protocol['test_limit']
        if lane not in ('UNMARKED_LEX','MARKED_LEX'):order=P.Controller(bank,lane,seed=job['seed'],weights=frozen_policy['weights'])
        search=E.search(model,case['seeds'],case['core'],node_limit=limits['nodes'],seconds=limits['seconds'],depth_limit=limits['depth'],cache_limit=limits['cache'],order=order)
        raw=blob('data/raw/eval-%03d-search.json.gz'%job['index'],search)
        if order is not None:policy=order.snapshot();assert policy['weights']==frozen_policy['weights'] and not policy['updates'] and not policy['training']
        a=assure(V,C,model,search,policy,bank,groups);record=dict(**job,status=a['status'],search=search,policy=policy,assurance=a,raw=raw)
        ref=blob('data/evaluation/eval-%03d.json.gz'%job['index'],record);evaluation.append(dict(**job,status=a['status'],search_seconds=search['seconds'],**ref));assert bank.snapshot()['bank_sha256']==frozen_bank['bank_sha256']
        print(json.dumps(dict(phase='EVAL',**job,status=a['status'],nodes=search['stats']['visits'],seconds=search['seconds'],clusters=policy['telemetry']['chosen_cluster_actions'] if policy else 0)),flush=True)
    check_sources(protocol);counts={lane:{s:sum(row['lane']==lane and row['status']==s for row in evaluation) for s in ('POSITIVE','NEGATIVE','UNKNOWN')} for lane in LANES}
    result=dict(schema='Turtle-cluster-RL-region-study-v1',status='COMPLETE_SCHEDULE',protocol=protocol,models=dict(unmarked=unmarked,marked=marked),groups=groups,cases=cohort,training=training,evaluation=evaluation,frozen_bank=frozen_bank,frozen_policy=frozen_policy,initial_admissions=admissions,qualification=q,counts=counts,costs=dict(total_seconds=time.perf_counter()-started,initial_bank_seconds=prep_seconds,training_seconds=training_seconds,evaluation_seconds=time.perf_counter()-evaluation_started,parent_acquisition_seconds=data['total_seconds'],parent_acquisition_reused=True),peak_ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rss_units='bytes on macOS',scope='Finite point-obligation masks with free exterior and viable exposed frontier; learned marked restriction. Cluster proposals order one current primitive anchor only. No macro execution, substitution or plane-tiling proof.')
    blob('data/results-v1.json.gz',result);save(ROOT/'data/completion-v1.json',dict(status='COMPLETE',counts=counts,training_completed=sum(bool(x.get('run_file')) for x in training),bank=len(bank.templates),total_seconds=result['costs']['total_seconds'],peak_ru_maxrss=result['peak_ru_maxrss']));print(json.dumps(load(ROOT/'data/completion-v1.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='run':run()
    else:raise SystemExit('freeze | run')
