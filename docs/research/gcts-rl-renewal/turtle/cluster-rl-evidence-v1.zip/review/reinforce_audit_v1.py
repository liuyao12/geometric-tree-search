"""Independent saved-data REINFORCE arithmetic audit; no science imports.

Only stdlib file/JSON/math operations are used. This audits the saved policy
trace and update arithmetic, not geometric feature truth, host randomness,
proof validity, or an acceleration claim. No engine or policy code is imported.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import math

VERSION = 'Turtle-independent-saved-REINFORCE-audit-v1'
TOLERANCE = 1e-11
FEATURES = ['bias', 'core_gain_fraction', 'new_tile_fraction',
            'shared_tile_fraction', 'frontier_completion_fraction',
            'negative_new_exposure_fraction', 'mark_interface_agreement_fraction',
            'negative_mean_distance_fraction']


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256((wire(value)+'\n').encode()).hexdigest()


def number(value):
    need(type(value) in (int, float) and math.isfinite(value), 'NONFINITE_OR_NONTYPED_NUMBER')
    return float(value)


def close(a, b, reason):
    a, b = number(a), number(b)
    need(abs(a-b) <= TOLERANCE*max(1.0, abs(a), abs(b)), reason)


def vector(values, dimension, reason):
    need(type(values) is list and len(values) == dimension, reason+'_DIMENSION')
    return [number(v) for v in values]


def same_vector(a, b, reason):
    need(len(a) == len(b), reason+'_DIMENSION')
    for x, y in zip(a, b):
        close(x, y, reason)


def integer(value, reason):
    need(type(value) is int, reason)
    return value


def placement(value):
    need(type(value) is list and len(value) == 3 and all(type(x) is int for x in value),
         'PLACEMENT_FORMAT')
    return tuple(value)


def branch_decisions(search):
    pending, choices = [search['certificate']], []
    while pending:
        node = pending.pop()
        if node.get('decision', {}).get('kind') == 'branch':
            choices.append(node['decision'])
        pending.extend(child['tree'] for child in reversed(node.get('children', [])))
    return choices


def trace(policy, weights, bank, search, *, training):
    """Reconstruct complete action tables and score gradients from saved choices."""
    cap = integer(bank['max_templates'], 'BANK_CAPACITY')
    need(cap == 32, 'EXPECTED_32_CLUSTER_FEATURES')
    dimension = len(FEATURES)+cap
    need(policy['feature_names'] == FEATURES+['cluster_id_%02d' % i for i in range(cap)],
         'FEATURE_NAMES')
    need(policy['training'] is training, 'POLICY_TRAINING_FLAG')
    weights = vector(weights, dimension, 'TRACE_WEIGHTS')
    templates = {item['index']: item for item in bank['templates']}
    need(len(templates) == len(bank['templates']), 'DUPLICATE_BANK_INDEX')
    decisions = policy['decisions']
    need(type(decisions) is list, 'DECISIONS_LIST')
    branches = branch_decisions(search)
    if policy['lane'] not in ('UNMARKED_LEX', 'MARKED_LEX'):
        need(len(decisions) == len(branches) == search['stats']['branches'],
             'MISSING_DECISIONS_FROM_FAILED_OR_OTHER_SUBTREES')
    gradients, cluster_indices = [], []
    action_count, trace_hash = 0, hashlib.sha256()
    for choice_index, decision in enumerate(decisions):
        table = decision['action_feature_table']
        need(type(table) is list and len(table) == decision['action_count'] and table,
             'COMPLETE_ACTION_TABLE_SIZE')
        actions, keys = [], []
        base_anchors = set()
        for row in table:
            need(type(row) is dict and set(row) == {'kind', 'anchor', 'cluster_index', 'continuous'},
                 'ACTION_TABLE_ROW')
            kind, anchor, index = row['kind'], placement(row['anchor']), row['cluster_index']
            need(kind in ('base', 'cluster'), 'ACTION_KIND')
            if kind == 'base':
                need(index is None and anchor not in base_anchors, 'BASE_ACTION_INDEX_OR_DUPLICATE')
                base_anchors.add(anchor)
            else:
                need(type(index) is int and 0 <= index < cap and index in templates, 'CLUSTER_INDEX')
            continuous = vector(row['continuous'], len(FEATURES), 'CONTINUOUS_FEATURES')
            close(continuous[0], 1.0, 'BIAS_FEATURE')
            feature = continuous+[float(index == i) for i in range(cap)]
            key = kind, anchor, index
            need(key not in keys, 'DUPLICATE_ACTION_IDENTITY')
            keys.append(key)
            actions.append(feature)
        need(integer(decision['base_action_count'], 'BASE_ACTION_COUNT') == len(base_anchors),
             'COMPLETE_BASE_ACTION_COUNT')
        need(all(key[1] in base_anchors for key in keys), 'CLUSTER_ANCHOR_WITHOUT_BASE_FALLBACK')
        need(decision['branch_point'] == branches[choice_index]['point'] and base_anchors ==
             {placement(p) for p in branches[choice_index]['candidates']}, 'TRACE_BRANCH_DOMAIN_BINDING')
        chosen = decision['chosen_action']
        need(chosen['cluster_index'] is None or type(chosen['cluster_index']) is int,
             'CHOSEN_CLUSTER_INDEX_TYPE')
        chosen_key = chosen['kind'], placement(chosen['anchor']), chosen['cluster_index']
        need(chosen_key in keys, 'CHOSEN_ACTION_NOT_IN_TABLE')
        selected = keys.index(chosen_key)
        feature = vector(chosen['features'], dimension, 'CHOSEN_FEATURES')
        same_vector(feature, actions[selected], 'CHOSEN_FEATURE_TABLE_MISMATCH')
        if chosen['kind'] == 'cluster':
            need(chosen['cluster_id'] == templates[chosen['cluster_index']]['id'], 'CHOSEN_CLUSTER_ID')
            cluster_indices.append(choice_index)
        else:
            need(chosen['cluster_id'] is None, 'BASE_CLUSTER_ID')
        logits = [sum(w*x for w, x in zip(weights, row)) for row in actions]
        peak = max(logits)
        masses = [math.exp(logit-peak) for logit in logits]
        probabilities = [mass/sum(masses) for mass in masses]
        saved_probabilities = vector(decision['model_softmax_probabilities'], len(actions), 'SOFTMAX')
        need(all(0.0 < p <= 1.0 for p in saved_probabilities), 'MODEL_PROBABILITY_RANGE')
        same_vector(saved_probabilities, probabilities, 'MODEL_SOFTMAX_MISMATCH')
        close(sum(saved_probabilities), 1.0, 'MODEL_SOFTMAX_NORMALIZATION')
        close(decision['model_softmax_probability'], probabilities[selected], 'CHOSEN_MODEL_PROBABILITY')
        lane = policy['lane']
        if training:
            need(lane == 'MARKED_CLUSTER_RL' and decision['policy'] == 'stochastic linear-softmax',
                 'TRAINING_BEHAVIOR_POLICY')
            behavior = probabilities[selected]
            expected = [sum(p*row[j] for p, row in zip(probabilities, actions)) for j in range(dimension)]
            gradients.append([x-mean for x, mean in zip(feature, expected)])
        elif lane == 'MARKED_CLUSTER_RL':
            need(selected == min(range(len(actions)), key=lambda i: (-logits[i], i)),
                 'FROZEN_RL_NOT_ARGMAX')
            behavior = 1.0
        elif lane == 'MARKED_CLUSTER_RANDOM':
            behavior = 1.0/len(actions)
        else:
            behavior = 1.0
        close(decision['behavior_probability'], behavior, 'BEHAVIOR_PROBABILITY')
        close(decision['behavior_log_probability'], math.log(behavior), 'BEHAVIOR_LOG_PROBABILITY')
        action_count += len(actions)
        trace_hash.update((wire([choice_index, selected, probabilities, actions])+'\n').encode())
    telemetry = policy['telemetry']
    need(integer(telemetry['branch_choices'], 'BRANCH_CHOICES') == len(decisions), 'MISSING_CHOICE_RECORDS')
    need(integer(telemetry['chosen_cluster_actions'], 'CHOSEN_CLUSTER_ACTIONS') == len(cluster_indices),
         'CHOSEN_CLUSTER_ACTION_COUNT')
    events = policy['chosen_cluster_events']
    need(integer(events['seen'], 'CLUSTER_EVENTS_SEEN') == len(cluster_indices), 'CLUSTER_EVENT_COUNT')
    if cluster_indices:
        for which, index in [('first', cluster_indices[0]), ('last', cluster_indices[-1])]:
            event, choice = events[which], decisions[index]
            need(type(event) is dict and event['choice_index'] == index, 'CLUSTER_EVENT_INDEX')
            need(event['anchor'] == choice['chosen_action']['anchor'] and
                 event['cluster_id'] == choice['chosen_action']['cluster_id'], 'CLUSTER_EVENT_IDENTITY')
            same_vector(event['features'], choice['chosen_action']['features'], 'CLUSTER_EVENT_FEATURES')
            close(event['behavior_probability'], choice['behavior_probability'], 'CLUSTER_EVENT_PROBABILITY')
            close(event['behavior_log_probability'], choice['behavior_log_probability'], 'CLUSTER_EVENT_LOG')
    else:
        need(events['first'] is None and events['last'] is None, 'SPURIOUS_CLUSTER_EVENT')
    gradient = [sum(row[j] for row in gradients)/max(1, len(gradients)) for j in range(dimension)]
    return {'gradient': gradient, 'stochastic_choices': len(gradients),
            'decisions': len(decisions), 'actions': action_count, 'cluster_choices': len(cluster_indices),
            'trace_sha256': trace_hash.hexdigest()}


def reward_audit(episode, model, case, limits):
    search, check, assurance = episode['search'], episode['reward_check'], episode['assurance']
    need(check['status'] == 'VERIFIED', 'REWARD_CHECK_NOT_VERIFIED')
    need(episode['status'] == assurance['status'], 'ASSURED_EPISODE_STATUS')
    need(search['core'] == case['core'], 'REWARD_CASE_CORE')
    cap = integer(model['capacity'], 'REWARD_CAPACITY')
    fields = {integer(row['id'], 'REWARD_ORIENTATION_ID'): row['points'] for row in model['orientations']}
    total = cap*len(search['core'])
    need(total > 0, 'EMPTY_REWARD_CORE')
    need(integer(search['core_total_units'], 'SEARCH_CORE_TOTAL_UNITS') == total,
         'SEARCH_CORE_TOTAL_UNITS')
    success = int(episode['status'] == 'POSITIVE')
    negative = int(episode['status'] == 'NEGATIVE' and assurance['tree']['status'] == 'VERIFIED')
    if negative:
        need(assurance['tree']['outcome'] == 'NEGATIVE', 'NEGATIVE_REWARD_TREE_OUTCOME')
    if success:
        need(search['status'] == 'POSITIVE' and assurance['patch']['status'] == 'VERIFIED',
             'UNCERTIFIED_SUCCESS_REWARD')
    units = 0
    need(type(search['best_prefix_viable']) is bool, 'BEST_PREFIX_VIABILITY_TYPE')
    if search['best_prefix_viable']:
        need(assurance['best']['status'] == 'VERIFIED' and assurance['best']['dead_points'] == [],
             'UNVERIFIED_PARTIAL_PROGRESS')
        snapshot = search['final_snapshot']
        need(search['placements'] == [row['placement'] for row in snapshot['placements']],
             'REWARD_PLACEMENTS_NOT_VERIFIED_SNAPSHOT')
        need(snapshot['core'] == case['core'], 'REWARD_SNAPSHOT_CORE')
        totals, seen = {}, set()
        for row in search['placements']:
            p = placement(row)
            need(p not in seen, 'REWARD_DUPLICATE_PLACEMENT')
            seen.add(p)
            g, dx, dy = p
            need(g in fields, 'REWARD_UNKNOWN_ORIENTATION')
            for x, y, value in fields[g]:
                need(all(type(v) is int for v in (x, y, value)) and 0 < value <= cap,
                     'REWARD_T_POINT')
                q = x+dx, y+dy
                totals[q] = totals.get(q, 0)+value
        units = sum(min(cap, totals.get(tuple(q), 0)) for q in case['core'])
        need(search['best_core_units'] == units, 'SAVED_BEST_PROGRESS_UNITS')
    else:
        need(assurance['best'] is None, 'NONVIABLE_PREFIX_HAS_VERIFIED_BEST_RECEIPT')
    if success:
        need(units == total, 'SUCCESS_WITHOUT_FULL_CORE_PROGRESS')
    need(integer(check['success'], 'SUCCESS_BIT') == success and
         integer(check['negative'], 'NEGATIVE_BIT') == negative and
         integer(check['progress_units'], 'PROGRESS_UNITS') == units and
         integer(check['core_total_units'], 'CORE_TOTAL_UNITS') == total, 'REWARD_COMPONENTS')
    seconds, limit = number(search['seconds']), number(limits['seconds'])
    visits, nodes = integer(search['stats']['visits'], 'VISITS'), integer(limits['nodes'], 'NODE_LIMIT')
    need(seconds >= 0 and limit > 0 and visits >= 0 and nodes > 0, 'REWARD_COST_RANGE')
    close(check['search_seconds'], seconds, 'REWARD_SEARCH_SECONDS')
    close(check['seconds_limit'], limit, 'REWARD_TIME_LIMIT')
    need(integer(check['visits'], 'REWARD_VISITS') == visits and
         integer(check['node_limit'], 'REWARD_NODE_LIMIT') == nodes, 'REWARD_NODE_COMPONENTS')
    close(search['limits']['seconds'], limit, 'SEARCH_TIME_LIMIT')
    need(search['limits']['nodes'] == nodes, 'SEARCH_NODE_LIMIT')
    time_cost = 0.10*min(seconds, limit)/limit
    node_cost = 0.02*visits/nodes
    expected = 2*success-negative+units/total-time_cost-node_cost
    close(episode['reward'], expected, 'INDEPENDENT_REWARD_FORMULA')
    return {'success': success, 'negative': negative, 'progress_units': units, 'core_total_units': total,
            'progress_fraction': units/total, 'time_cost': time_cost, 'node_cost': node_cost,
            'reward_recomputed': expected}


def training_updates(result, load_run):
    bank = result['frozen_bank']
    need(bank['frozen'] is True, 'BANK_NOT_FROZEN')
    need(bank['bank_sha256'] == digest({'model_sha256': bank['model_sha256'], 'templates': bank['templates']}),
         'BANK_FINGERPRINT')
    dimension = 8+integer(bank['max_templates'], 'BANK_CAPACITY')
    need([item['index'] for item in bank['templates']] == list(range(len(bank['templates']))),
         'FROZEN_BANK_INDEX_SEQUENCE')
    initial = result['initial_admissions']
    need(type(initial) is list and initial, 'INITIAL_BANK_ADMISSIONS')
    bank_size = integer(initial[-1]['bank_size'], 'INITIAL_BANK_SIZE')
    admissions = list(initial)
    cases = {case['id']: case for case in result['cases']['training']}
    old, baseline, history, summaries = None, 0.0, [], []
    total_choices, total_clusters, changes = 0, 0, 0
    skipped, previous_episode = [], -1
    for ref in result['training']:
        episode = load_run('training', ref)
        if episode is None:
            skipped.append(ref)
            continue
        index = len(history)
        update, policy = episode['update'], episode['policy']
        need(type(episode['episode']) is int and episode['episode'] > previous_episode,
             'TRAINING_EPISODE_ORDER')
        previous_episode = episode['episode']
        need(update['episode'] == index and policy['episodes'] == index+1, 'UPDATE_EPISODE_ORDER')
        need(policy['episode_finished'] is True, 'EPISODE_NOT_FINISHED')
        before = vector(update['weights_before'], dimension, 'WEIGHTS_BEFORE')
        if old is None:
            old = [0.0]*dimension
        same_vector(before, old, 'TRAINING_WEIGHT_CHAIN')
        close(update['baseline_before'], baseline, 'BASELINE_CHAIN')
        reward = number(episode['reward'])
        close(update['reward'], reward, 'UPDATE_REWARD')
        advantage = reward-baseline
        close(update['advantage'], advantage, 'UPDATE_ADVANTAGE')
        learning_rate = number(update['learning_rate'])
        need(learning_rate > 0, 'LEARNING_RATE_POSITIVE')
        close(learning_rate, result['protocol']['learning_rate'], 'FROZEN_LEARNING_RATE')
        close(policy['learning_rate'], learning_rate, 'POLICY_LEARNING_RATE')
        need(policy['proposal_cap'] == result['protocol']['proposal_cap'], 'TRAINING_PROPOSAL_CAP')
        available = dict(bank, templates=bank['templates'][:bank_size])
        need(policy['bank_sha256'] == digest({'model_sha256': bank['model_sha256'],
             'templates': available['templates']}), 'TRAINING_BANK_HISTORY_BINDING')
        inspected = trace(policy, before, available, episode['search'], training=True)
        same_vector(update['gradient'], inspected['gradient'], 'EPISODE_GRADIENT_ALL_CHOICES')
        need(type(update['stochastic_choices']) is int and
             update['stochastic_choices'] == inspected['stochastic_choices'] == inspected['decisions'],
             'STOCHASTIC_CHOICE_CENSUS')
        after = [max(-8.0, min(8.0, w+learning_rate*advantage*g)) for w, g in zip(before, inspected['gradient'])]
        same_vector(update['weights_after'], after, 'CLIPPED_REINFORCE_UPDATE')
        same_vector(policy['weights'], after, 'POLICY_AFTER_UPDATE_WEIGHTS')
        need(policy['weights_sha256'] == digest(policy['weights']), 'POLICY_WEIGHT_FINGERPRINT')
        changed = after != before
        need(update['updated'] is changed, 'UPDATED_FLAG')
        changes += changed
        baseline = 0.9*baseline+0.1*reward
        close(policy['baseline'], baseline, 'RUNNING_BASELINE_UPDATE')
        history.append(update)
        need(wire(policy['updates']) == wire(history), 'MISSING_OR_EXTRA_TRAINING_UPDATE_HISTORY')
        reward_details = reward_audit(episode, result['models']['marked'], cases[episode['case_id']],
                                     result['protocol']['train_limit'])
        addition = episode['bank_admission']
        if addition is not None:
            need(episode['status'] == 'POSITIVE', 'NONPOSITIVE_BANK_ADMISSION')
            size = integer(addition['bank_size'], 'POST_EPISODE_BANK_SIZE')
            need(bank_size <= size <= len(bank['templates']) and addition['added'] ==
                 [item['id'] for item in bank['templates'][bank_size:size]], 'BANK_ADDITION_SEQUENCE')
            for item in bank['templates'][bank_size:size]:
                need(item['origin']['source'] == 'verified training episode' and
                     item['origin']['episode'] == episode['episode'] and
                     item['origin']['case_id'] == episode['case_id'], 'TRAINING_BANK_PROVENANCE')
            bank_size = size
            admissions.append(addition)
        else:
            need(episode['status'] != 'POSITIVE', 'POSITIVE_MISSING_BANK_ADMISSION_RECORD')
        total_choices += inspected['decisions']
        total_clusters += inspected['cluster_choices']
        summaries.append({'episode': index, 'case_id': episode['case_id'], 'reward': reward,
                          'advantage': advantage, 'updated': changed, 'reward_audit': reward_details,
                          **inspected})
        old = after
    need(bool(history), 'NO_COMPLETED_TRAINING_EPISODES')
    frozen = result['frozen_policy']
    need(frozen['training'] is False and frozen['episodes'] == len(history), 'FROZEN_POLICY_EPISODES')
    same_vector(frozen['weights'], old, 'FROZEN_POLICY_WEIGHTS')
    close(frozen['baseline'], baseline, 'FROZEN_POLICY_BASELINE')
    need(wire(frozen['updates']) == wire(history), 'FROZEN_POLICY_UPDATE_HISTORY')
    need(frozen['weights_sha256'] == digest(frozen['weights']), 'FROZEN_WEIGHT_FINGERPRINT')
    need(frozen['bank_sha256'] == bank['bank_sha256'], 'FROZEN_POLICY_BANK_BINDING')
    need(bank_size == len(bank['templates']) and wire(admissions) == wire(bank['admissions']),
         'FROZEN_BANK_TRAINING_ONLY_ADMISSIONS')
    need(changes > 0 and any(abs(v) > TOLERANCE for v in old), 'NO_OBSERVED_WEIGHT_CHANGE')
    return {'summaries': summaries, 'updates': history, 'weights': old, 'baseline': baseline,
            'changed_episodes': changes, 'decisions': total_choices, 'cluster_choices': total_clusters,
            'completed_episodes': len(history), 'unrun_positions': skipped}


def audit(result, train_ids, heldout_ids, load_run):
    """Cohort IDs must come from the frozen protocol, never inferred from results."""
    need(type(train_ids) is list and type(heldout_ids) is list and
         all(type(s) is str for s in train_ids+heldout_ids), 'PROTOCOL_CASE_IDS')
    need(len(train_ids) == len(set(train_ids)) and len(heldout_ids) == len(set(heldout_ids)) and
         not (set(train_ids) & set(heldout_ids)), 'TRAIN_HELDOUT_OVERLAP_OR_DUPLICATES')
    need(all(row['case_id'] in train_ids for row in result['training']), 'HELDOUT_TRAINING_UPDATE')
    need(all(row['case_id'] in heldout_ids for row in result['evaluation']), 'EVALUATION_OUTSIDE_HELDOUT')
    need([case['id'] for case in result['cases']['training']] == train_ids and
         [case['id'] for case in result['cases']['heldout']] == heldout_ids, 'FROZEN_CASE_ID_LISTS')
    train_cores = {digest(case['core']) for case in result['cases']['training']}
    heldout_cores = {digest(case['core']) for case in result['cases']['heldout']}
    need(not (train_cores & heldout_cores) and len(heldout_cores) == len(heldout_ids),
         'FROZEN_TARGET_CORE_OVERLAP')
    need(len(result['training']) == result['protocol']['train_episodes'], 'PLANNED_TRAINING_CENSUS')
    for index, ref in enumerate(result['training']):
        need(type(ref['episode']) is int and ref['episode'] == index and
             ref['case_id'] == train_ids[index % len(train_ids)], 'PLANNED_TRAINING_ORDER')
    updates = training_updates(result, load_run)
    evaluation, seen, unrun, completed = [], set(), [], 0
    eval_cluster_choices, eval_rl_cluster_choices, eval_rl_cases = 0, 0, 0
    bank, frozen = result['frozen_bank'], result['frozen_policy']
    for ref in result['evaluation']:
        key = ref['case_id'], ref['lane'], ref['repeat']
        need(key not in seen, 'DUPLICATE_EVALUATION_POSITION')
        seen.add(key)
        row = load_run('evaluation', ref)
        if row is None:
            unrun.append(ref)
            continue
        completed += 1
        policy = row['policy']
        if policy is None:
            need(row['lane'] in ('UNMARKED_LEX', 'MARKED_LEX'), 'MISSING_NONLEXICAL_POLICY')
            continue
        need(policy['training'] is False and policy['lane'] == row['lane'], 'EVAL_POLICY_TRAINING_OR_LANE')
        need(policy['proposal_cap'] == result['protocol']['proposal_cap'], 'EVALUATION_PROPOSAL_CAP')
        need(policy['updates'] == [] and policy['episodes'] == 0, 'HELDOUT_UPDATE_OCCURRED')
        need(policy['episode_finished'] is False, 'HELDOUT_FINISH_EPISODE_OCCURRED')
        close(policy['baseline'], 0.0, 'HELDOUT_BASELINE_ADAPTATION')
        need(policy['bank_sha256'] == bank['bank_sha256'], 'EVAL_BANK_CHANGED')
        need(policy['weights_sha256'] == digest(policy['weights']), 'EVAL_WEIGHT_FINGERPRINT')
        same_vector(policy['weights'], updates['weights'], 'NONLEXICAL_EVAL_WEIGHTS_CHANGED')
        if row['lane'] == 'MARKED_CLUSTER_RL':
            same_vector(policy['weights'], updates['weights'], 'FROZEN_RL_EVAL_WEIGHTS_CHANGED')
            need(policy['weights_sha256'] == frozen['weights_sha256'], 'FROZEN_RL_EVAL_WEIGHT_HASH_CHANGED')
            eval_rl_cases += 1
        inspected = trace(policy, policy['weights'], bank, row['search'], training=False)
        eval_cluster_choices += inspected['cluster_choices']
        if row['lane'] == 'MARKED_CLUSTER_RL':
            eval_rl_cluster_choices += inspected['cluster_choices']
        evaluation.append({'case_id': row['case_id'], 'lane': row['lane'], 'repeat': row['repeat'], **inspected})
    expected_positions = {(case_id, lane, repeat) for case_id in heldout_ids
                          for lane in result['protocol']['lanes']
                          for repeat in range(result['protocol']['repeats'])}
    need(seen == expected_positions and len(seen) == result['protocol']['evaluation_jobs'],
         'PLANNED_EVALUATION_COVERAGE')
    warnings = []
    if eval_rl_cases == 0:
        warnings.append('No completed frozen-RL evaluation exists; no held-out RL behavior is established.')
    if updates['cluster_choices'] == 0:
        warnings.append('No actual training cluster choice was recorded; no observed training on cluster actions is claimed.')
    if eval_cluster_choices == 0:
        warnings.append('No actual evaluation cluster choice was recorded; no deployed cluster-action usage is claimed.')
    if eval_rl_cases > 0 and eval_rl_cluster_choices == 0:
        warnings.append('Frozen RL made zero cluster selections; observed evaluation cluster usage, if any, belongs to other lanes.')
    return {'schema': VERSION, 'status': 'VERIFIED', 'tolerance': TOLERANCE,
            'tolerance_rule': 'absolute error <= tolerance * max(1,abs(expected),abs(actual))',
            'cohort': {'train_ids': train_ids, 'heldout_ids': heldout_ids, 'disjoint': True,
                       'planned_training_episodes': len(result['training']),
                       'completed_training_episodes': updates['completed_episodes'],
                       'evaluation_positions': len(seen), 'completed_evaluation_positions': completed,
                       'unrun_evaluation_positions': unrun},
            'training': updates, 'evaluation': evaluation,
            'observed': {'weights_changed': True, 'training_cluster_choices': updates['cluster_choices'],
                         'evaluation_cluster_choices': eval_cluster_choices,
                         'evaluation_rl_cluster_choices': eval_rl_cluster_choices,
                         'frozen_rl_evaluations': eval_rl_cases},
            'warnings': warnings,
            'scope': 'Saved-action softmax, score gradient over all retained branch subtrees, clipped update, independently summed verified-prefix progress reward, running baseline, cohort split and frozen-evaluation arithmetic only. No engine/policy imports, proof checking, RNG replay, all-candidate geometric feature audit or speedup claim.'}


def pointer(document, path):
    value = document
    need(type(path) is str and path.startswith('/'), 'JSON_POINTER')
    for component in path[1:].split('/'):
        value = value[component.replace('~1', '/').replace('~0', '~')]
    return value


def read_json(path):
    data = path.read_bytes()
    raw = gzip.decompress(data) if path.suffix == '.gz' else data
    return json.loads(raw), {'path': str(path.resolve()), 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest(), 'raw_bytes': len(raw),
                            'raw_sha256': hashlib.sha256(raw).hexdigest()}


def run_loader(root, readbacks):
    def load(kind, ref):
        if ref.get('run_file') is None:
            need(ref.get('update') is None, 'UNRUN_POSITION_HAS_UPDATE')
            need(type(ref['status']) is str and (ref['status'].startswith('UNKNOWN_NOT_RUN_') or
                 ref['status'] == 'UNKNOWN' and type(ref.get('reason')) is str and ref['reason'].startswith('NOT_RUN_')),
                 'UNRUN_POSITION_STATUS')
            return None
        relative = Path(ref['run_file'])
        need(not relative.is_absolute(), 'ABSOLUTE_RUN_REFERENCE')
        path = (root/relative).resolve()
        need(path.is_relative_to(root.resolve()), 'RUN_REFERENCE_OUTSIDE_MILESTONE')
        row, actual_pin = read_json(path)
        expected = ref['run_pin']
        need(actual_pin['bytes'] == expected['bytes'] and actual_pin['sha256'] == expected['sha256'],
             'RUN_FILE_FULL_STORED_PIN')
        for key in ('raw_bytes', 'raw_sha256'):
            if key in expected:
                need(actual_pin[key] == expected[key], 'RUN_FILE_FULL_RAW_PIN')
        for key in ('case_id', 'episode', 'lane', 'repeat', 'job_index', 'index'):
            if key in ref and key in row:
                need(type(ref[key]) is type(row[key]) and ref[key] == row[key], 'RUN_IDENTITY:'+key)
        if 'status' in row:
            need(row['status'] == row['assurance']['status'], 'NATIVE_RUN_ASSURED_STATUS')
        else:
            row['status'] = row['search']['status']
        need(ref['status'] == row['status'], 'INDEX_RUN_STATUS')
        if 'reward' in ref:
            close(ref['reward'], row['reward'], 'INDEX_RUN_REWARD')
        if 'search_seconds' in ref:
            close(ref['search_seconds'], row['search']['seconds'], 'INDEX_RUN_SEARCH_SECONDS')
        rawref = row['raw']
        rawpath = (root/Path(rawref['run_file'])).resolve()
        need(rawpath.is_relative_to(root.resolve()), 'RAW_SEARCH_REFERENCE_OUTSIDE_MILESTONE')
        rawsearch, rawpin = read_json(rawpath)
        need(rawpin['bytes'] == rawref['run_pin']['bytes'] and
             rawpin['sha256'] == rawref['run_pin']['sha256'], 'RAW_SEARCH_FULL_STORED_PIN')
        need(wire(rawsearch) == wire(row['search']), 'RAW_SEARCH_FULL_CONTENT_JOIN')
        readbacks.append({'kind': kind, 'case_id': ref['case_id'], **actual_pin})
        readbacks.append({'kind': kind+'_raw_search', 'case_id': ref['case_id'], **rawpin})
        return row
    return load


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', type=Path, required=True)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--train-pointer', required=True)
    parser.add_argument('--heldout-pointer', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    result, result_pin = read_json(args.result)
    protocol, protocol_pin = read_json(args.protocol)
    need(wire(result['protocol']) == wire(protocol), 'INDEX_FROZEN_PROTOCOL_COPY')
    source_pins = {}
    for name in ('source/cluster_policy_v1.py', 'source/point_engine_v2.py', 'source/experiment_v1.py'):
        data = (args.root/name).read_bytes()
        actual = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        need(protocol['pins'][name] == actual, 'FROZEN_SOURCE_PIN:'+name)
        source_pins[name] = actual
    for key, value in [('data/marked-model-v1.json', result['models']['marked']),
                       ('data/unmarked-model-v1.json', result['models']['unmarked']),
                       ('data/cases-v1.json', result['cases'])]:
        encoded = (wire(value)+'\n').encode()
        need(protocol['pins'][key] == {'bytes': len(encoded), 'sha256': hashlib.sha256(encoded).hexdigest()},
             'FROZEN_EMBEDDED_CARRIER:'+key)
    readbacks = []
    receipt = audit(result, pointer(protocol, args.train_pointer), pointer(protocol, args.heldout_pointer),
                    run_loader(args.root, readbacks))
    for name, expected in source_pins.items():
        data = (args.root/name).read_bytes()
        need(expected == {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
             'SOURCE_CHANGED_DURING_AUDIT:'+name)
    source = Path(__file__).read_bytes()
    receipt['inputs'] = {'result': result_pin, 'protocol': protocol_pin,
                         'train_pointer': args.train_pointer, 'heldout_pointer': args.heldout_pointer}
    receipt['utility_source'] = {'bytes': len(source), 'sha256': hashlib.sha256(source).hexdigest()}
    receipt['dereferenced_runs'] = readbacks
    receipt['source_pins_before_after_equal'] = source_pins
    args.output.write_text(json.dumps(receipt, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(wire({'status': receipt['status'], 'observed': receipt['observed'], 'warnings': receipt['warnings'],
                'output': str(args.output.resolve())}), flush=True)


if __name__ == '__main__':
    main()
