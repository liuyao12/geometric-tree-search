"""Posthoc retained-context diagnostic; no engine/policy/search execution.

Plan and Source precede diagnostic computation. Only the exactly pinned sibling
independent point checker is imported. Results concern retained first/last
selected cluster contexts, not every proposal trial or a causal comparison.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'Turtle-retained-receptor-context-diagnostic-v1'
CHECKER_SHA256 = 'f05e1315fe3af0b902fc87aa28992a7f0685fc65f2dcab02b7e9fa50e6b180bd'


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((wire(value)+'\n').encode()).hexdigest()


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read_json(path):
    stored = path.read_bytes()
    raw = gzip.decompress(stored) if path.suffix == '.gz' else stored
    return json.loads(raw), {'bytes': len(stored), 'sha256': hashlib.sha256(stored).hexdigest(),
                            'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}


def placement(row):
    need(type(row) is list and len(row) == 3 and all(type(x) is int for x in row),
         'MALFORMED_PLACEMENT')
    return tuple(row)


def point(row):
    need(type(row) is list and len(row) == 2 and all(type(x) is int for x in row), 'MALFORMED_POINT')
    return tuple(row)


def totals(fields, placements):
    result = {}
    for gid, dx, dy in placements:
        need(gid in fields, 'UNKNOWN_ORIENTATION')
        for x, y, units in fields[gid]:
            q = x+dx, y+dy
            result[q] = result.get(q, 0)+units
    return result


def load_run(root, reference):
    relative = Path(reference['run_file'])
    need(not relative.is_absolute(), 'ABSOLUTE_RUN_FILE')
    path = (root/relative).resolve()
    need(path.is_relative_to(root.resolve()), 'RUN_FILE_OUTSIDE_MILESTONE')
    run, actual = read_json(path)
    expected = reference['run_pin']
    need(actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256'],
         'RUN_FILE_FULL_STORED_PIN')
    for key in ('raw_bytes', 'raw_sha256'):
        if key in expected:
            need(actual[key] == expected[key], 'RUN_FILE_FULL_RAW_PIN')
    for key in ('case_id', 'episode', 'lane', 'repeat', 'index'):
        if key in reference and key in run:
            need(type(reference[key]) is type(run[key]) and reference[key] == run[key], 'RUN_IDENTITY')
    need(run['status'] == reference['status'] == run['assurance']['status'], 'RUN_STATUS_JOIN')
    return run, {'run_file': str(relative), **actual}


def retained_events(policy):
    events = policy['chosen_cluster_events']
    selected = [i for i, d in enumerate(policy['decisions']) if d['chosen_action']['kind'] == 'cluster']
    need(type(events['seen']) is int and events['seen'] == len(selected), 'SELECTED_EVENT_CENSUS')
    if not selected:
        need(events['first'] is None and events['last'] is None, 'EMPTY_EVENT_ENDPOINTS')
        return []
    result = []
    for role, expected in [('first', selected[0]), ('last', selected[-1])]:
        event = events[role]
        need(type(event) is dict and type(event['choice_index']) is int and
             event['choice_index'] == expected, 'ENDPOINT_CHOICE_INDEX')
        choice = policy['decisions'][expected]['chosen_action']
        need(event['anchor'] == choice['anchor'] and event['cluster_id'] == choice['cluster_id'] and
             event['expansion'] == choice['primitive_expansion'], 'ENDPOINT_CHOSEN_ACTION_JOIN')
        if result and result[0]['event']['choice_index'] == expected:
            need(wire(result[0]['event']) == wire(event), 'DIFFERENT_DUPLICATE_ENDPOINT')
            result[0]['roles'].append(role)
        else:
            result.append({'roles': [role], 'event': event})
    return result


def context(checker, model, fields, run, saved):
    event, roles = saved['event'], saved['roles']
    snapshot = event['parent_snapshot']
    parent = [placement(row['placement']) for row in snapshot['placements']]
    expansion = [placement(row) for row in event['expansion']]
    need(len(parent) == len(set(parent)) and len(expansion) == len(set(expansion)),
         'DUPLICATE_PLACEMENT_IN_CONTEXT')
    need(snapshot.get('grow', True) is True, 'NON_GROWTH_CONTEXT')
    core = snapshot['core']
    need(core == run['search']['core'], 'PARENT_CORE_NOT_FULL_RUN_CORE')
    core_points = [point(q) for q in core]
    need(len(core_points) == len(set(core_points)), 'DUPLICATE_CORE_POINT')
    selected = set(parent)
    new = [p for p in expansion if p not in selected]
    union = parent+new
    need(new and placement(event['anchor']) in new, 'MISSING_NEW_ANCHOR')
    parent_totals = totals(fields, parent)
    union_totals = totals(fields, union)
    # Essential: the ENTIRE parent core is passed, including untouched zeros.
    receipt = checker.check_patch(model, [list(p) for p in union], core, grow=True)
    issues = []
    if receipt['status'] == 'UNKNOWN':
        classification = 'UNKNOWN_CHECKER_RESOURCE'
        consistent, viable, core_filled = None, None, None
    elif receipt.get('consistent') is True:
        consistent = True
        need(type(receipt['dead_points']) is list and type(receipt['core_filled']) is bool,
             'CHECKER_FINITE_PATCH_RECEIPT')
        viable = receipt['dead_points'] == []
        core_filled = receipt['core_filled']
        classification = 'CONSISTENT_VIABLE_FRONTIER' if viable else 'CONSISTENT_DEAD_FRONTIER'
        need(receipt['status'] == ('VERIFIED' if viable and core_filled else 'REJECTED'),
             'CHECKER_CLASSIFICATION_JOIN')
    else:
        classification = 'UNEXPECTED_BASE_LEGALITY_REJECTION'
        consistent, viable, core_filled = False, None, None
        issues.append('Prior proposal assurance passed, but union t/m/inventory consistency was not independently reproduced.')
    final = run['search']['placements']
    final_set = {placement(p) for p in final}
    need(len(final_set) == len(final), 'DUPLICATE_FINAL_PLACEMENT')
    final_verified = (run['status'] == 'POSITIVE' and
                      (run['assurance'].get('patch') or {}).get('status') == 'VERIFIED')
    membership = {'status': 'NO_FINAL_VERIFIED_POSITIVE_PATCH'}
    if final_verified:
        present = [p for p in new if p in final_set]
        membership = {'status': 'AVAILABLE', 'new_member_count': len(new),
                      'new_members_in_final_patch': len(present),
                      'new_member_fraction': {'numerator': len(present), 'denominator': len(new)},
                      'present_new_members': [list(p) for p in present],
                      'absent_new_members': [list(p) for p in new if p not in final_set],
                      'parent_member_count': len(parent),
                      'parent_members_in_final_patch': len(selected & final_set),
                      'parent_prefix_contained_in_final_patch': selected <= final_set}
    return {'retained_roles': roles, 'choice_index': event['choice_index'],
            'cluster_id': event['cluster_id'], 'anchor': event['anchor'],
            'parent_placement_count': len(parent), 'cluster_member_count': len(expansion),
            'shared_selected_counted_once': len(set(expansion) & selected),
            'new_member_count': len(new), 'union_placement_count': len(union),
            'core_points': len(core_points), 'core_sha256': sha(core),
            'parent_untouched_zero_core_points': sum(parent_totals.get(q, 0) == 0 for q in core_points),
            'union_untouched_zero_core_points': sum(union_totals.get(q, 0) == 0 for q in core_points),
            'classification': classification, 'consistent': consistent,
            'full_frontier_viable': viable, 'core_filled': core_filled,
            'dead_points': receipt.get('dead_points'), 'checker_receipt': receipt,
            'final_verified_patch_membership': membership, 'study_issues': issues,
            'context_sha256': sha({'parent_snapshot': snapshot, 'expansion': event['expansion']})}


def summarize(records):
    result = {'retained_contexts': len(records), 'consistent_viable': 0, 'consistent_dead': 0,
              'unknown_checker_resource': 0, 'unexpected_base_rejection': 0,
              'core_filled_known': 0, 'membership_available': 0,
              'new_members_context_sum': 0, 'new_members_in_final_patch_context_sum': 0,
              'parent_prefix_contained_in_final_patch': 0}
    mapping = {'CONSISTENT_VIABLE_FRONTIER': 'consistent_viable',
               'CONSISTENT_DEAD_FRONTIER': 'consistent_dead',
               'UNKNOWN_CHECKER_RESOURCE': 'unknown_checker_resource',
               'UNEXPECTED_BASE_LEGALITY_REJECTION': 'unexpected_base_rejection'}
    for record in records:
        result[mapping[record['classification']]] += 1
        result['core_filled_known'] += record['core_filled'] is True
        membership = record['final_verified_patch_membership']
        if membership['status'] == 'AVAILABLE':
            result['membership_available'] += 1
            result['new_members_context_sum'] += membership['new_member_count']
            result['new_members_in_final_patch_context_sum'] += membership['new_members_in_final_patch']
            result['parent_prefix_contained_in_final_patch'] += membership['parent_prefix_contained_in_final_patch']
    denominator = result['new_members_context_sum']
    result['pooled_member_fraction'] = None if denominator == 0 else {
        'numerator': result['new_members_in_final_patch_context_sum'], 'denominator': denominator}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=ROOT/'review/receptor-context-audit-v1.json')
    args = parser.parse_args()
    root = args.root.resolve()
    need(not args.output.exists(), 'EXCLUSIVE_DIAGNOSTIC_OUTPUT_ALREADY_EXISTS')
    plan_path = root/'review/receptor-context-plan-v1.json'
    plan, plan_pin = read_json(plan_path)
    need(plan['version'] == VERSION and plan['utility_source'] == pin(Path(__file__)), 'FROZEN_PLAN_SOURCE_PIN')
    index_path = root/'data/results-v1.json.gz'
    index, index_pin = read_json(index_path)
    protocol = index['protocol']
    need(index['status'] == 'COMPLETE_SCHEDULE', 'INCOMPLETE_MAIN_STUDY_INDEX')
    guards = {name: expected for name, expected in protocol['pins'].items()
              if name.endswith('.py') and name.startswith(('source/', 'reference/'))}
    for name, expected in guards.items():
        need(pin(root/name) == expected, 'FROZEN_SOURCE_PIN:'+name)
    checker_path = root/'reference/independent_checker_v2.py'
    need(pin(checker_path)['sha256'] == CHECKER_SHA256, 'APPROVED_CHECKER_SOURCE_PIN')
    spec = importlib.util.spec_from_file_location('independent_point_checker_for_receptor_context', checker_path)
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    model = index['models']['marked']
    need(sha(model) == protocol['pins']['data/marked-model-v1.json']['sha256'], 'FROZEN_MARKED_MODEL_COPY')
    fields = {row['id']: row['points'] for row in model['orientations']}
    records, readbacks, unrun, run_counts = [], [], [], {}
    for phase in ('training', 'evaluation'):
        for reference in index[phase]:
            lane = reference.get('lane', 'MARKED_CLUSTER_RL')
            key = phase, lane
            run_counts[key] = run_counts.get(key, 0)+1
            if reference.get('run_file') is None:
                unrun.append({'phase': phase, **reference})
                continue
            run, actual_pin = load_run(root, reference)
            readbacks.append({'phase': phase, **actual_pin})
            policy = run['policy']
            if policy is None:
                continue
            need(policy['lane'] == lane, 'POLICY_LANE_JOIN')
            for saved in retained_events(policy):
                record = context(checker, model, fields, run, saved)
                record.update(phase=phase, lane=lane, case_id=run['case_id'],
                              episode=run.get('episode'), repeat=run.get('repeat'),
                              run_file=reference['run_file'])
                records.append(record)
    summaries = [{'phase': phase, 'lane': lane, 'indexed_runs': run_counts[phase, lane],
                  **summarize([r for r in records if r['phase'] == phase and r['lane'] == lane])}
                 for phase, lane in sorted(run_counts)]
    for name, expected in guards.items():
        need(pin(root/name) == expected, 'FROZEN_SOURCE_CHANGED_DURING_DIAGNOSTIC:'+name)
    need(pin(index_path) == {k: index_pin[k] for k in ('bytes', 'sha256')}, 'INDEX_CHANGED_DURING_DIAGNOSTIC')
    overall = summarize(records)
    result = {'version': VERSION, 'status': 'COMPLETE', 'posthoc': True,
              'plan': {'path': str(plan_path), **plan_pin}, 'utility_source': pin(Path(__file__)),
              'index': {'path': str(index_path), **index_pin}, 'model_sha256': sha(model),
              'scientific_helper': {'path': 'reference/independent_checker_v2.py', 'sha256': CHECKER_SHA256},
              'frozen_source_pins_before_after_equal': guards, 'run_readbacks': readbacks,
              'unrun_positions': unrun, 'overall': overall, 'by_phase_lane': summaries,
              'unexpected_study_issue': overall['unexpected_base_rejection'] > 0,
              'contexts': records,
              'scope': 'Independent posthoc observation of unique retained first/last selected cluster contexts. All parent core obligations, including untouched zeros, were included. Shared selected identities counted once. Compatible means exact t/m/inventory compatibility; viable additionally means no dead point anywhere on the complete active frontier. Final-patch membership is observational: the parent context may itself later be backtracked. No causal inference, all-proposal coverage, policy/model/search rerun, training/evaluation change or infinite-extension conclusion.'}
    with args.output.open('x') as output:
        output.write(json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(wire({'status': result['status'], 'overall': overall,
                'unexpected_study_issue': result['unexpected_study_issue'],
                'output': str(args.output.resolve()), 'output_pin': pin(args.output)}), flush=True)


if __name__ == '__main__':
    main()
