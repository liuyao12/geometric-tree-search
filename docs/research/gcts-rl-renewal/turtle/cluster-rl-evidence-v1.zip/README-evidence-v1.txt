Exact Turtle cluster-RL finite point-target study, 2026-11-03.

Actual native execution:48training episodes,12heldout target masks x6lanes
x2repeats=144evaluation positions. Every training and evaluation search found
an independently verified positive finite core-full/viable-frontier patch.
All192actual search trees and patches were checked independently. No unknown
or unrun position is hidden. Qualification has18records; the connected bank
grew8to32templates and all384saved decorated group images were checked.

The REINFORCE policy really updated weights:143training cluster selections,
88frozen evaluation RL selections. Allbase alternatives remain present. A
jointly point/mark-compatible connected cluster only orders its current anchor
first; no atomic macro, retained plan or executed multi-move sequence is claimed.
RL was slower here:8.168s/636states vs marked lexical5.073s/342states, across
the same24evaluation positions. Allmethods solved every heldout target.
Marked lanes share a learned finite restriction; unmarked lexical solves a
different inventory, so those cross-inventory differences do not prove pruning
redundancy. No practical arbitrary-region or whole-plane result is claimed.

Independent review/reinforce-audit-v1.json reproduces actual choices, feature
assembly, probabilities, score gradients, rewards and48weight/baseline updates,
frozen evaluation and bank custody; it does not replay all RNG draws or prove
every continuous feature's geometric interpretation. Independent point checks
establish patch/tree validity separately.

The receptor-context diagnostic is explicitly POSTHOC. Its Source and plan were
fixed before diagnostic computation, after the main outcomes were already known.
It includes every parent core obligation, including untouched zeros. Of234unique
retained first/last selected cluster contexts,219whole unions are consistent and
frontier-viable;15are consistent but dead;0unexpected base rejection or unknown.
For heldout RL alone,42of48are viable and6dead. This subset does not cover all
proposal trials and does not establish the cause of RL's negative result.

Native total123.048s includes bank admission, training,evaluation, qualification,
bank checks and recording. Prior marking/corona acquisition200.096s is reused,
outside current time; frozen input preparation0.138s is separate. Posthoc review,
rendering and publication are outside native total. Peak681541632B wholeprocess,
not per-method. No full cold-cost improvement is claimed.

Reproduction: Python3.12stdlib, fresh evidence copy; do not overwrite originals.
Verify data/protocol-frozen-v1.json pins before source/experiment_v1.py run.
The freeze step obtains prior-phase input data from sibling runs; exact copied
inputs are retained under reference/. The pinned runtime path/hash and native
exit0 are in review/execution-completion-v1.json. Independent checkers do not
import the Root engine or policy. report/build_report_v1.py is a passive reader.

The full task-owned evidence including local paths is approved for publication
at the existing GitHub Pages destination. Unrelated checkout changes and retired
materials work are excluded. package/ and publication/ are excluded from this
cut to prevent recursion; deployment receipts stay in the completed local run.
The overall Turtle/Penrose/universal proof-search program remains ACTIVE.
