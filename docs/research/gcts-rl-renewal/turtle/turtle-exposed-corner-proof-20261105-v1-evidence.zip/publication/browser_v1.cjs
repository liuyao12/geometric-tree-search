const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { chromium } = require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

const root = path.resolve(__dirname, "..");
const report = path.join(root, "report", "turtle-exposed-corner-proof-20261105-v1.html");

async function main() {
  const browser = await chromium.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: true,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 880 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    await page.goto(pathToFileURL(report).href, { waitUntil: "load" });
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 8);
    const evidence = await page.evaluate(() => {
      const data = JSON.parse(document.getElementById("certificate-data").textContent);
      const menu = document.getElementById("cone-menu");
      const step = document.getElementById("step-menu");
      const svg = document.getElementById("cone-view");
      let nodes = 0;
      for (let i = 0; i < menu.options.length; i++) {
        menu.value = String(i);
        menu.dispatchEvent(new Event("change"));
        if (step.options.length !== data.proofs[i].nodes) throw new Error("wrong proof node count");
        for (let j = 0; j < step.options.length; j++) {
          step.value = String(j);
          step.dispatchEvent(new Event("change"));
          if (svg.querySelectorAll("line").length !== 12) throw new Error("sector rays missing");
          if (!svg.querySelector('circle[fill="#bc2649"]')) throw new Error("query missing");
          nodes++;
        }
      }
      return {
        cones: menu.options.length, nodes,
        math: document.querySelectorAll("mjx-container").length,
      };
    });
    assert.deepEqual(errors, []);
    assert.equal(evidence.cones, 192);
    assert.equal(evidence.nodes, 264);
    const index = await page.evaluate(() =>
      JSON.parse(document.getElementById("certificate-data").textContent).proofs.findIndex(p => p.mask === 3585));
    assert.notEqual(index, -1);
    await page.selectOption("#cone-menu", String(index));
    await page.selectOption("#step-menu", "1");
    await page.locator("#reader").screenshot({ path: path.join(__dirname, "browser-view-v1.png") });
    await page.setViewportSize({ width: 390, height: 844 });
    const fits = await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
    assert.equal(fits, true);
    const result = { status: "CHECKED_INTERACTIVE_CONE_READER", ...evidence, mobile_no_overflow: fits };
    fs.writeFileSync(path.join(__dirname, "browser-v1.json"), JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
    process.stdout.write(JSON.stringify(result) + "\n");
  } finally {
    await browser.close();
  }
}

main().catch(err => { console.error(err); process.exitCode = 1; });
