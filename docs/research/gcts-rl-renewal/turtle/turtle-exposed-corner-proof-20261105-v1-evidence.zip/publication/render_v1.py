"""Publish the exact Turtle corner obstruction with a small certificate reader."""

from collections import Counter
from html import escape
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STEM = "turtle-exposed-corner-proof-20261105-v1"
OLD = "turtle-three-cluster-screen-20261105-v1.html"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    content = path.read_bytes()
    return dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest())


def read_lines(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def tree_size(tree):
    assert tree["status"]=="NEGATIVE"
    return 1+sum(tree_size(t) for _,t in tree["children"])


def audit():
    base = ROOT/"input"
    for section in ("extreme","cones"):
        root = base/section
        protocol = read(root/"protocol-v1.json")
        assert all(pin(root/name)==p for name,p in protocol["pins"].items())
        assert not (root/"data/execution.stderr.log").read_bytes()
    assert read(base/"carrier-check-v1.json")["status"]=="VERIFIED"
    previous = read(base/"three-screen-results-v1.json")
    assert previous["finite_negatives"]==20169 and previous["shapes"]==2241
    cones = read(base/"cones/data/summary-v1.json")
    assert cones["cone_proofs"]=={"NEGATIVE":172,"UNKNOWN":1}
    for ratio,already,new in [(36,114,2127),(48,1499,742)]:
        rows = read_lines(base/f"cones/data/ratio-{ratio}-cone-v1.jsonl")
        prior = read_lines(base/f"cones/input/ratio-{ratio}-tail-v1.jsonl")
        assert len(prior)==2241 and len(rows)==new
        assert {r["type"] for r in rows}=={r["type"] for r in prior if not r["winner"]}
        assert all(r["winner"] and not r["winner"]["gaps"] and r["winner"]["cut"]>=r["first"]
                   for r in rows)
        assert cones["families"][str(ratio)]["counts"]==dict(
            earlier_complete=already,entered=new,new_complete=new)
    ext = read(base/"extreme/data/summary-v1.json")
    rows = read(base/"extreme/data/extreme-proofs-v1.json")
    expected = {sum(1<<((start+j)%12) for j in range(5) if mask&(1<<j))
                for start in range(12) for mask in range(1,32)}
    assert len(rows)==len(expected)==ext["cases"]==192 and not ext["unknown"]
    assert {r["signature"] for r in rows}==expected
    for row in rows:
        assert row["checked"]["status"]=="VERIFIED"
        assert tree_size(row["raw"]["tree"])==row["raw"]["nodes"]==row["checked"]["nodes"]
        assert row["signature"].bit_count()==row["occupied_sectors"]
    assert ext["counts"]=={"NEGATIVE":192,"SEARCHED":168,"REUSED":24}
    model = read(base/"extreme/input/exact-point-model-v1.json")
    bundle = dict(rays=ext["rays"],scale=model["scale"],polygon=model["polygon"],
                  matrices=[g["matrix"] for g in model["groups"]],
                  proofs=[dict(mask=r["signature"],sectors=r["occupied_sectors"],
                               nodes=r["checked"]["nodes"],tree=r["raw"]["tree"]) for r in rows])
    by_size = Counter(row["occupied_sectors"] for row in rows)
    result = dict(status="CHECKED_ALL_STRICT_EXTREME_CONES",certified=192,
                  classification_by_sector_count=dict(sorted(by_size.items())),
                  checked_tree_nodes=sum(r["checked"]["nodes"] for r in rows),
                  max_tree_nodes=max(r["checked"]["nodes"] for r in rows),
                  prior_three_tile_finite_cases=20169,
                  three_tile_all_multipliers={"integer_ray":2241,"thirty_degree_ray":2241},
                  scope="Exact partitions by Turtle copies under lattice translations and allowed point actions. Closed finite libraries refined by one common expansive lattice-preserving similarity.")
    return result,bundle


VIEWER = r"""
const data=JSON.parse(document.getElementById("certificate-data").textContent);
const menu=document.getElementById("cone-menu");
const step=document.getElementById("step-menu");
const svg=document.getElementById("cone-view");
const summary=document.getElementById("cone-summary");
const label=document.getElementById("step-summary");
const namespace="http://www.w3.org/2000/svg";
let states=[];
const draw=p=>[p[0]+p[1]/2,-p[1]*Math.sqrt(3)/2];
const scaled=p=>p.map(t=>t/data.scale);
const coords=p=>p.map(t=>t.toFixed(3)).join(",");
function element(name,attrs) {
  const node=document.createElementNS(namespace,name);
  for (const [key,value] of Object.entries(attrs)) node.setAttribute(key,value);
  svg.append(node);
}
function option(select,value,text) {
  const item=document.createElement("option");
  item.value=value;
  item.textContent=text;
  select.append(item);
}
function placement([group,x,y]) {
  const [[a,b],[c,d]]=data.matrices[group];
  return data.polygon.map(([u,v])=>draw([a*u+b*v+x,c*u+d*v+y]));
}
function ray(r,distance) {
  const p=draw(r);
  const size=Math.hypot(...p);
  return p.map(t=>distance*t/size);
}
function paint() {
  const proof=data.proofs[Number(menu.value)];
  const {node,ancestors}=states[Number(step.value)];
  const q=draw(scaled(node.point));
  const blockers=(node.mark?.stencil||[]).map(([x,y])=>draw(scaled([node.point[0]+x,node.point[1]+y])));
  const tiles=ancestors.map(placement);
  const points=[q,...blockers,...tiles.flat()];
  const far=Math.max(4,...points.map(p=>Math.hypot(...p)))+1.4;
  svg.setAttribute("viewBox",[-far,-far,2*far,2*far].join(" "));
  svg.replaceChildren();
  for (let i=0;i<data.rays.length;i++) {
    const a=ray(data.rays[i],far*1.6),b=ray(data.rays[(i+1)%12],far*1.6);
    if (proof.mask&(1<<i)) element("polygon",{points:"0,0 "+coords(a)+" "+coords(b),fill:"#cce9e1"});
    element("line",{x1:0,y1:0,x2:a[0],y2:a[1],stroke:"#98a7af","stroke-width":far*.006});
  }
  for (const tile of tiles) element("polygon",{points:tile.map(coords).join(" "),
    fill:"#efb55b",stroke:"#6d4e20","stroke-width":far*.015});
  for (const p of blockers) element("circle",{cx:p[0],cy:p[1],r:far*.022,fill:"#7142a8"});
  element("circle",{cx:0,cy:0,r:far*.018,fill:"#142d3a"});
  element("circle",{cx:q[0],cy:q[1],r:far*.026,fill:"#bc2649",stroke:"white","stroke-width":far*.008});
  const count=node.children.length;
  label.textContent=count ? count+" legal placements at the red query. Each leads to a checked child."
                          : "No legal placement covers the red query in this state.";
}
function select() {
  const proof=data.proofs[Number(menu.value)];
  states=[];
  step.replaceChildren();
  function visit(node,ancestors,path) {
    option(step,states.length,path+" · "+node.children.length+" legal placements");
    states.push({node,ancestors});
    node.children.forEach(([tile,child],i)=>visit(child,[...ancestors,tile],path+"."+String(i+1)));
  }
  visit(proof.tree,[],"Root");
  summary.textContent=proof.sectors+" occupied sectors · "+proof.nodes+" checked tree nodes";
  paint();
}
data.proofs.forEach((proof,i)=>option(menu,i,"Cone "+proof.mask+" · "+proof.sectors+" sectors"));
menu.value=String(data.proofs.findIndex(p=>p.mask===3585));
menu.addEventListener("change",select);
step.addEventListener("change",paint);
select();
"""


def render(result,bundle):
    payload = json.dumps(bundle,separators=(",",":")).replace("<","\\u003c")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Why a finite exact Turtle substitution cannot close</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{{font-family:system-ui,sans-serif;color:#18333d;background:#eaf0f2}}body{{margin:0}}
main{{max-width:64rem;margin:auto;padding:2.5rem clamp(1rem,4vw,2.8rem) 4rem;background:white}}
h1,h2{{line-height:1.17}}h1{{font-size:clamp(2.3rem,6vw,3.65rem);letter-spacing:-.04em;margin:.35em 0}}
h2{{margin-top:2rem}}p,li{{line-height:1.56}}nav{{display:flex;flex-wrap:wrap;gap:1rem;margin:1.2rem 0 2rem}}
a{{color:#075a77}}.meta{{color:#536873}}.theorem{{padding:.9rem 1.1rem;background:#e1f1eb;border-left:.35rem solid #217765}}
.viewer{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1.2rem;align-items:center}}
svg{{display:block;width:100%;height:21rem;border:1px solid #bfd2d6;border-radius:.5rem;background:#f3f7f9}}
label{{display:block;margin-top:.75rem;font-weight:650}}select{{display:block;max-width:100%;padding:.45rem}}
ol{{padding-left:1.4rem}}ol li{{margin-bottom:.8rem}}.count{{font-variant-numeric:tabular-nums}}
</style></head><body><main>
<p class="meta">Geometric tree search · Turtle experiments · November 5, 2026</p>
<h1>Why a finite exact Turtle substitution cannot close</h1>
<p class="theorem"><strong>Theorem for the lattice model.</strong> There is no closed substitution of finite Turtle clusters in which one common expansive similarity maps the lattice into itself and each inflated cluster is partitioned exactly into translated and allowed rotated or reflected copies from the library.</p>
<nav aria-label="Sections"><a href="#proof">Proof</a><a href="#reader">Cone certificates</a><a href="#three">Three-tile result</a><a href="#evidence">Evidence</a></nav>
<section id="proof"><h2>From the exposed corner to the obstruction</h2>
<ol>
<li><strong>Choose one exposed vertex.</strong> A generic linear functional reaches its maximum at one vertex \(v\) of the finite cluster. The nearby region lies in a wedge strictly narrower than \(180^\circ\). Its boundary rays belong to the six unoriented edge directions of the primitive Turtle. These directions divide the plane into twelve sectors of \(30^\circ\). The local region occupies a nonempty subset of at most five consecutive sectors. We include disconnected subsets.</li>
<li><strong>Check the finite list.</strong> The search covered all 192 possible subsets. The independent verifier rebuilds the legal alignments from absolute atom positions and uses signs of the six edge normals to check membership in the cone. At each node every legal placement covering the queried cell must occur as a child. Leaves have an empty domain. The checker never consults the search markings.</li>
<li><strong>Transfer a cone proof to a large cluster.</strong> The tree refers to finitely many samples, including every sample that could occur in an alignment of one of its queries. Translate these samples with \(kv\) for positive integer \(k\). Relative to an edge of the scaled cluster, the line value is affine in \(k\) in the translated coordinates. For lines through \(v\) the sign is already fixed. Every other line eventually has the sign of its nonzero slope. The finite samples then agree with the cone on which the proof was checked. Lattice translation preserves their residues and the list of possible alignments.</li>
<li><strong>Apply the proposed rule repeatedly.</strong> Any compatible similarity has angular part in multiples of \(30^\circ\), since an exposed straight edge of the inflated cluster must match a primitive edge direction. Such a similarity normalizes the allowed point actions, so the cluster rule can be iterated. An orientation-preserving similarity has a positive integral scalar power after twelve steps. An orientation-reversing similarity has one after two. Iteration would therefore give exact tilings at unbounded integral multipliers of every cluster. Step 3 excludes those tilings.</li>
</ol>
<p>The argument applies to exact boundaries that are scaled copies of a fixed shape. The Turtle can tile the plane. The literature constructs combinatorial hierarchies, where large patches can have different geometric boundaries from the smaller shapes they represent. Those constructions and finite-region tilings with a movable boundary fall outside the theorem. <a href="https://arxiv.org/abs/2303.10798">Smith, Myers, Kaplan and Goodman-Strauss</a> · <a href="https://arxiv.org/abs/2403.01911">Socolar</a></p></section>
<section id="reader"><h2>Inspect a cone certificate</h2>
<div class="viewer"><svg id="cone-view" viewBox="-1 -1 2 2" role="img" aria-label="Cone, proof query, selected ancestor tiles and stencil"></svg>
<div><label for="cone-menu">Angular occupancy</label><select id="cone-menu"></select>
<label for="step-menu">Proof node</label><select id="step-menu"></select>
<p class="count" id="cone-summary"></p><p id="step-summary" aria-live="polite"></p>
<p>Green marks the target sectors. The black point is the cone vertex and the red point is the current query. Orange tiles are ancestor placements. Purple points show unavailable cells from a search marking when one was recorded.</p></div></div>
<p>The certificates contain {result["checked_tree_nodes"]:,} checked tree nodes in total. The search found 168 cone proofs for this inventory and reused 24 from the three-tile study.</p></section>
<section id="three"><h2>Every multiplier for the three-tile bank</h2>
<p>The earlier finite screen covered 2,241 shapes at all eligible area ratios through \(48\). The two allowed similarity rays have area ratios \(k^2\) and \(3k^2\). Replaying saved proofs already covered every larger multiplier for 114 shapes on the first ray and 1,499 on the second.</p>
<p>The vertex search closed the remaining 2,127 and 742 cases. For each such shape, a cone proof was transferred to a concrete multiplier bound and checked on the full scaled polygon. The same proof also replayed at every integer multiplier between that bound and the finite screen. Thus all 2,241 three-tile shapes fail at every lattice-preserving similarity with area ratio greater than \(1\).</p></section>
<section id="evidence"><h2>Evidence</h2><ul>
<li><a href="{STEM}-results.json">Machine-readable summary</a></li>
<li><a href="{STEM}-evidence.zip">Full sources, exact certificate trees, protocols and logs</a></li>
<li><a href="{STEM}-manifest.json">Archive file hashes</a></li>
<li><a href="{OLD}">Three-tile finite screen and marking costs</a></li>
</ul></section></main>
<script id="certificate-data" type="application/json">{payload}</script>
<script>{VIEWER}</script></body></html>"""


def main():
    result,bundle = audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as out:
        out.write(render(result,bundle))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as out:
        json.dump(result,out,indent=2,sort_keys=True)
        out.write("\n")
    print(json.dumps(result),flush=True)


if __name__=="__main__":
    main()
