# Turtle markings on fixed regions

The base problem requires integer saturation at every point of a fixed region
\(R\), with capacity legality everywhere. The exterior has free saturation
and tiles may cross the boundary. All three methods use this same finite
point model, with one identity seed and no exterior growth obligations.

The cohort has four scales in each of three mask families. The generator
consults earlier target point sets only for duplicate rejection under
translations and all twelve orientation actions. It uses no solver outputs,
labels or tiling witnesses. Twelve literal targets and the balanced cyclic
method order are frozen before evaluation.

- Unmarked search uses the original occupancy constraints.
- Sparse search enables the 212 exclusions from the learned three-channel
  subfield when the transformed certificate footprint is contained in \(R\).
- Indexed search applies the same condition to all 263 certified exclusions.

A footprint from either root direction suffices. The solver uses candidate
conflict counts, records every logical delta on its ordinary rollback trail
and invalidates existing candidate incidences when a cut becomes active. It
uses the same primitive scheduler and candidate order in all methods.

Independently replay all 263 donor trees on the unmarked model before using
the footprints. Qualify the region guard on a two-placement finite inventory,
using exhaustive subset enumeration both inside and outside the footprint.
Test invalidation and exact rollback. For held-out positives, check the
complete unmarked witness. For exhausted negatives, rebuild the graph and
reroot each candidate pair independently at each recorded node. Each missing
or bounded result remains unresolved.

Per method limits are 4 search seconds, 1,200 visits, depth 96, and 32,000
cached positive-support fields. Independent negative assurance has a separate
8-second cooperative wall limit and the inherited checker limits. Search
timing includes initialization and candidate updates. Method timing also
includes guard setup. Report shared donor replay and per-result assurance
separately. Timed prefixes can explore different numbers of nodes. Compare
elapsed times for checked outcomes separately from timeouts. Each case has
one observed run per method.

This compares pruning on finite point obligations with free exterior.
Substitution, plane existence, and new RL training are separate questions.
