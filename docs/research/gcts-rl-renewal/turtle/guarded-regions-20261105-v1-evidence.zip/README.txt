Turtle certificate guards on fixed point regions

Open report/guarded-regions-20261105-v1.html. The three frozen protocols bind
all model, source, target and runtime bytes. Original outputs are in data,
stress/data and resume/data. The last two directories retain the interrupted
process and its seven previously unstarted jobs separately.

To reproduce, preserve the archive. In a separate extracted copy, create
empty data directories for each process and use the pinned Python with
the flags -I -S -B to run source/experiment_v1.py in the archive root,
then stress/source/experiment_v1.py and resume/source/experiment_v1.py
as separate processes. Each script resolves its inputs relative to itself.
The region declarations are already frozen in each input directory.

Recorded wall times and the exact point at which a timed run stops depend on
execution. The original stress driver can stop if the inherited engine omits
a cutoff reason. The resume protocol preserves the seven pending positions
from the archived run and qualifies the logging fix with a two-node fixture.
It never retries the unresolved S07 unmarked position.

The report renderer audits the archived run and expects its exact recorded
attempt structure. Full raw witnesses, bounded prefixes, qualification
records and logs are present. The manifest binds the physical archive files.
