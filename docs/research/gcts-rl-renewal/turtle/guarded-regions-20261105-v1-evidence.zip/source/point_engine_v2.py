"""Exact point engine v2: lazy marks, branch-only ordering, viable progress.

Derived from the frozen corona point_engine_v1.py; no geometry predicates.
Positive rows/t-dependencies are cached first. Extended marks/m-dependencies
are materialized only after capacity succeeds in ordinary legality checking.
Every currently valid registration therefore has its complete marking domain.
Immutable caches/dependency supersets may survive undo, filtered by reg/valid;
every logical registration, incidence, value and generation delta still trails.

All finite core points are explicit generation-zero obligations at activation.
A tile meeting an untouched core point gets generation one by the existing-point
formula, even when disconnected from selected tiles. No new disconnected root
is introduced during search; adding a new root would be a separate activation.

The order callback is a logical-state read-only permutation at BRANCH nodes only.
It may score validated clusters but executes no macro or retained continuation.
Audit mode checks logical immutability; private immutable caches may grow.
"""
import hashlib
import json
import time

ABSENT=object()
class CacheLimit(Exception):
    """Cooperative immutable t-field entry guard; not an OS memory limit."""

def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(v):return hashlib.sha256(wire(v).encode()).hexdigest()

class Engine:
    def __init__(self,model,seeds,core,*,grow=True,cache_limit=16000,conflicts=None):
        self.model=model;self.capacity=model['capacity'];self.grow=grow
        assert conflicts is None or not grow
        self.conflicts=conflicts
        self.cut_counts={}
        assert type(cache_limit) is int and cache_limit>=0
        self.cache_limit=cache_limit
        self.orient={o['id']:tuple(tuple(v) for v in o['points']) for o in model['orientations']}
        self.morient={o['id']:tuple((x,y,wire(ch),wire(v)) for x,y,ch,v in o['points']) for o in model.get('marking_orientations',[])}
        assert type(self.capacity) is int and self.capacity>0
        for rows in self.orient.values():
            assert rows and len({(x,y) for x,y,u in rows})==len(rows)
            assert all(type(x) is int and type(y) is int and type(u) is int and 0<u<=self.capacity for x,y,u in rows)
        assert len(self.orient)==len(model['orientations'])
        for rows in self.morient.values():
            assert len({(x,y,ch) for x,y,ch,v in rows})==len(rows)
            assert all(type(x) is int and type(y) is int for x,y,ch,v in rows)
        self.allowed=None if 'allowed_placements' not in model else frozenset(tuple(c) for c in model['allowed_placements'])
        self.core=frozenset(tuple(p) for p in core);self.seed_count=len(seeds)
        self.T={};self.M={};self.gen={p:0 for p in self.core};self.selected={}
        self.reg=set();self.valid=set();self.domains={};self.inc={};self.units={};self.trail=[]
        self.tcache={};self.cache={};self.tdeps={};self.mdeps={};self.aligncache={}
        self.stats=dict(visits=0,attempts=0,accepted=0,forced=0,branches=0,backtracks=0,registrations=0,capacity_removed=0,mark_removed=0,inventory_removed=0,cut_removed=0,max_frontier=0,max_candidates=0,max_edges=0)
        for key in seeds:
            key=tuple(key);assert key not in self.selected
            assert self.legal(key);field,marks=self.materialize(key)
            self.selected[key]=0
            for x,y,u in field:self.T[x,y]=self.T.get((x,y),0)+u;self.gen[x,y]=0
            for x,y,ch,v in marks:
                k=x,y,ch;old=self.M.get(k);assert old is None or old[0]==v
                self.M[k]=(v,1+(old[1] if old else 0))
            self.install_cuts(key)
        q=set(self.core)|(set(self.T) if grow else set())
        for p in sorted(q):
            if self.T.get(p,0)<self.capacity:self.activate(p)
        self.trail.clear();self.peaks()

    def tfield(self,key):
        if key not in self.tcache:
            if len(self.tcache)>=self.cache_limit:raise CacheLimit('immutable t-field entry limit')
            g,dx,dy=key;assert g in self.orient
            field=tuple((x+dx,y+dy,u) for x,y,u in self.orient[g])
            self.tcache[key]=field
            for x,y,u in field:self.tdeps.setdefault((x,y),set()).add(key)
        return self.tcache[key]
    def materialize(self,key):
        """Explicit full-field request; reason() calls it only after T passes.

        cache contains complete (t,m) pairs only. Raw capacity-illegal candidates
        can exist solely in tcache; policy diagnostics should use tfield for them.
        """
        if key not in self.cache:
            g,dx,dy=key;field=self.tfield(key)
            marks=tuple((x+dx,y+dy,ch,v) for x,y,ch,v in self.morient.get(g,()))
            self.cache[key]=(field,marks)
            for x,y,ch,v in marks:self.mdeps.setdefault((x,y,ch),set()).add(key)
        return self.cache[key]

    def reason(self,key):
        if self.allowed is not None and key not in self.allowed:return 'inventory'
        if key in self.selected:return 'inventory'
        field=self.tfield(key)
        if any(self.T.get((x,y),0)+u>self.capacity for x,y,u in field):return 'capacity'
        if self.cut_counts.get(key,0):return 'cut'
        _,marks=self.materialize(key)
        if any((x,y,ch) in self.M and self.M[x,y,ch][0]!=v for x,y,ch,v in marks):return 'mark'
        return None
    def legal(self,key):return self.reason(key) is None
    def put(self,m,k,v):
        old=m.get(k,ABSENT)
        if old is not ABSENT and old==v:return
        self.trail.append(('map',m,k,old));m[k]=v
    def delete(self,m,k):
        self.trail.append(('map',m,k,m[k]));del m[k]
    def add(self,s,v):
        if v not in s:self.trail.append(('set',s,v,False));s.add(v)
    def remove(self,s,v):
        if v in s:self.trail.append(('set',s,v,True));s.remove(v)
    def install_cuts(self,key):
        if self.conflicts is None:return ()
        blocked=self.conflicts(key)
        for neighbor in blocked:
            self.put(self.cut_counts,neighbor,self.cut_counts.get(neighbor,0)+1)
        return blocked
    def rollback(self,mark):
        while len(self.trail)>mark:
            kind,obj,key,old=self.trail.pop()
            if kind=='map':
                if old is ABSENT:obj.pop(key,None)
                else:obj[key]=old
            elif old:obj.add(key)
            else:obj.remove(key)

    def alignments(self,p):
        if p not in self.aligncache:
            ids={(g,p[0]-x,p[1]-y) for g,rows in self.orient.items() for x,y,u in rows}
            if self.allowed is not None:ids.intersection_update(self.allowed)
            self.aligncache[p]=tuple(sorted(ids))
        return self.aligncache[p]
    def edge(self,p,c):
        self.add(self.domains[p],c);self.add(self.inc[c],p)
        if (p,c) not in self.units:self.put(self.units,(p,c),next(u for x,y,u in self.cache[c][0] if (x,y)==p))
    def register(self,c):
        if c in self.reg:return
        self.tfield(c);self.add(self.reg,c);self.put(self.inc,c,set());self.stats['registrations']+=1
        reason=self.reason(c)
        if reason:
            self.stats[reason+'_removed']+=1;return
        self.add(self.valid,c)
        for x,y,u in self.cache[c][0]:
            if (x,y) in self.domains:self.edge((x,y),c)
    def activate(self,p):
        assert p not in self.domains and self.T.get(p,0)<self.capacity
        self.put(self.domains,p,set())
        for c in self.alignments(p):
            self.register(c)
            if c in self.valid:self.edge(p,c)
    def close(self,p):
        for c in tuple(self.domains[p]):self.remove(self.inc[c],p);self.delete(self.units,(p,c))
        self.delete(self.domains,p)
    def peaks(self):
        self.stats['max_frontier']=max(self.stats['max_frontier'],len(self.domains))
        self.stats['max_candidates']=max(self.stats['max_candidates'],sum(bool(v) for c,v in self.inc.items() if c in self.valid))
        self.stats['max_edges']=max(self.stats['max_edges'],sum(len(v) for v in self.domains.values()))
    def place(self,c):
        c=tuple(c);self.stats['attempts']+=1;assert self.legal(c)
        field,marks=self.materialize(c)
        touching=[self.gen[x,y] for x,y,u in field if (x,y) in self.gen]
        assert touching,'Only connected nonseed moves are implemented'
        generation=1+min(touching);self.put(self.selected,c,generation)
        affected={c}
        affected.update(self.install_cuts(c))
        for x,y,u in field:
            p=x,y;self.put(self.T,p,self.T.get(p,0)+u)
            self.put(self.gen,p,min(self.gen.get(p,generation),generation))
            affected.update(self.tdeps.get(p,()))
        for x,y,ch,v in marks:
            p=x,y,ch;old=self.M.get(p);assert old is None or old[0]==v
            self.put(self.M,p,(v,1+(old[1] if old else 0)));affected.update(self.mdeps.get(p,()))
        for x,y,u in field:
            if (x,y) in self.domains and self.T[x,y]==self.capacity:self.close((x,y))
        for key in affected & self.reg & self.valid:
            reason=self.reason(key)
            if reason:
                self.remove(self.valid,key);self.stats[reason+'_removed']+=1
                for p in tuple(self.inc[key]):self.remove(self.domains[p],key);self.remove(self.inc[key],p);self.delete(self.units,(p,key))
        if self.grow:
            for x,y,u in field:
                if self.T[x,y]<self.capacity and (x,y) not in self.domains:self.activate((x,y))
        self.stats['accepted']+=1;self.peaks()

    def decision(self):
        key=lambda p:(self.gen[p],len(self.domains[p]),*p)
        dead=[p for p,v in self.domains.items() if not v]
        if dead:p=min(dead,key=key);kind='dead'
        elif all(self.T.get(p,0)==self.capacity for p in self.core):return dict(kind='success',point=None,candidates=[])
        else:
            forced=[p for p,v in self.domains.items() if len(v)==1]
            p=min(forced if forced else self.domains,key=key);kind='forced' if forced else 'branch'
        return dict(kind=kind,point=list(p),candidates=[list(c) for c in sorted(self.domains[p])])
    def snapshot(self):
        return dict(placements=[dict(placement=list(c),generation=g) for c,g in self.selected.items()],seed_count=self.seed_count,point_generations=[[*p,g] for p,g in sorted(self.gen.items())],core=[list(p) for p in sorted(self.core)],domains=[dict(point=list(p),candidates=[list(c) for c in sorted(v)]) for p,v in sorted(self.domains.items())],edge_units=[[*p,*c,u] for (p,c),u in sorted(self.units.items())],decision=self.decision(),grow=self.grow)
    def logical_digest(self):
        return sha(dict(snapshot=self.snapshot(),totals=[[*p,u] for p,u in sorted(self.T.items())],marks=[[*p,v,n] for p,(v,n) in sorted(self.M.items())],registered=sorted(self.reg),valid=sorted(self.valid),incidence=[[list(c),sorted(v)] for c,v in sorted(self.inc.items())],cut_counts=sorted(self.cut_counts.items())))

def search(model,seeds,core,*,node_limit=5000,seconds=10,depth_limit=128,grow=True,audit=False,order=None,cache_limit=16000,conflicts=None):
    start=time.perf_counter();engine=Engine.__new__(Engine)
    try:engine.__init__(model,seeds,core,grow=grow,cache_limit=cache_limit,conflicts=conflicts)
    except CacheLimit:
        # The construction graph is incomplete: expose no snapshot/reward.
        # Keeping the allocated object lets these counters describe actual work.
        return dict(status='UNKNOWN',criterion='CORE_COMPLETE_WITH_VIABLE_FRONTIER',seeds=[list(c) for c in seeds],core=[list(p) for p in sorted(engine.core)],placements=[list(c) for c in engine.selected],final_snapshot=None,best_core_units=None,core_total_units=engine.capacity*len(engine.core),best_prefix_viable=False,cache_counts=dict(t_fields=len(engine.tcache),full_mark_fields=len(engine.cache)),certificate=dict(outcome='UNKNOWN',limit='cache'),audit_snapshots=[],rollback_checks=[],budget_hits=['cache'],stats=engine.stats,seconds=time.perf_counter()-start,limits=dict(nodes=node_limit,seconds=seconds,depth=depth_limit,cache=cache_limit),grow=grow)
    events=[];rollbacks=[];fallback=engine.snapshot();best=None;best_core_units=None;budget_hits=[]
    core_total_units=engine.capacity*len(engine.core)
    def consider():
        nonlocal best,best_core_units
        # Called only after complete graph construction/update. Cutoff-prefix
        # progress may be retained, but no budget leaf becomes a positive label.
        if engine.decision()['kind']=='dead':return
        units=sum(engine.T.get(p,0) for p in engine.core)
        if best is None or units>best_core_units:
            best=engine.snapshot();best_core_units=units
    consider()
    def visit(depth):
        nonlocal best,best_core_units
        if engine.stats['visits']>=node_limit or time.perf_counter()-start>=seconds or depth>depth_limit:
            reason='nodes' if engine.stats['visits']>=node_limit else 'seconds' if time.perf_counter()-start>=seconds else 'depth'
            budget_hits.append(reason);return dict(outcome='UNKNOWN',limit=reason)
        engine.stats['visits']+=1;d=engine.decision()
        if audit:events.append(engine.snapshot())
        tree=dict(decision=d,outcome=None,children=[])
        if d['kind']=='dead':tree['outcome']='NEGATIVE';return tree
        if d['kind']=='success':
            tree['outcome']='POSITIVE';best=engine.snapshot();best_core_units=core_total_units;return tree
        candidates=[tuple(c) for c in d['candidates']]
        if order is not None and d['kind']=='branch':
            before_order=engine.logical_digest() if audit else None
            try:candidates=[tuple(c) for c in order(engine,candidates)]
            except CacheLimit:
                if audit:assert engine.logical_digest()==before_order,'Order callback changed logical state'
                budget_hits.append('cache');return dict(outcome='UNKNOWN',limit='cache')
            assert all(len(c)==3 and all(type(v) is int for v in c) for c in candidates)
            assert set(candidates)=={tuple(c) for c in d['candidates']} and len(candidates)==len(d['candidates'])
            if audit:assert engine.logical_digest()==before_order,'Order callback changed logical state'
        engine.stats['forced' if d['kind']=='forced' else 'branches']+=1
        unknown=False
        for c in candidates:
            mark=len(engine.trail);before=engine.logical_digest() if audit else None
            restored=False
            try:engine.place(c);consider();child=visit(depth+1)
            except CacheLimit:
                engine.rollback(mark);restored=True
                budget_hits.append('cache');child=dict(outcome='UNKNOWN',limit='cache')
            tree['children'].append(dict(move=list(c),tree=child))
            if child['outcome']=='POSITIVE':tree['outcome']='POSITIVE';return tree
            if not restored:engine.rollback(mark)
            engine.stats['backtracks']+=1
            if audit:
                after=engine.logical_digest();assert before==after
                rollbacks.append(dict(before=before,restored=after))
            unknown|=child['outcome']=='UNKNOWN'
            if engine.stats['visits']>=node_limit or time.perf_counter()-start>=seconds:
                if len(tree['children'])<len(candidates):unknown=True
                break
        tree['outcome']='UNKNOWN' if unknown else 'NEGATIVE';return tree
    certificate=visit(0);outcome=certificate['outcome']
    viable=best is not None
    if not viable:best=fallback
    return dict(status=outcome,criterion='CORE_COMPLETE_WITH_VIABLE_FRONTIER',seeds=[list(c) for c in seeds],core=[list(p) for p in sorted(set(tuple(p) for p in core))],placements=[r['placement'] for r in best['placements']],final_snapshot=best,best_core_units=best_core_units,core_total_units=core_total_units,best_prefix_viable=viable,cache_counts=dict(t_fields=len(engine.tcache),full_mark_fields=len(engine.cache)),certificate=certificate,audit_snapshots=events,rollback_checks=rollbacks,budget_hits=budget_hits,stats=engine.stats,seconds=time.perf_counter()-start,limits=dict(nodes=node_limit,seconds=seconds,depth=depth_limit,cache=cache_limit),grow=grow)
