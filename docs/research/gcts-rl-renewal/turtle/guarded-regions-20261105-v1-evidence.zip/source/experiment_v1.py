"""Qualify the guard and measure one frozen finite-region cohort."""

from collections import Counter
import gzip
from itertools import combinations
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import independent_checker_v1 as independent
import point_engine_v2 as engine
from check_region_v1 import check_negative
from guard_v1 import RegionGuard, guarded_pair
from sparse_verify_v1 import replay_certificates
from synthesize_v1 import Action, pin, point_rows, read, require, write


def frozen():
    protocol = read("protocol-v1.json")
    require(protocol["schema"] == "Turtle-guarded-regions-frozen-v1"
            and protocol["runtime"] == pin(Path(sys.executable)), "frozen schema and runtime")
    for name, expected in protocol["pins"].items():
        require(pin(ROOT/name) == expected, name)
    return protocol


def load_proofs(model, action):
    start = time.perf_counter()
    verified = read("input/verification-v1.json")
    require(verified["status"] == "VERIFIED_BOTH_FIELDS_AND_ALL_USED_NEGATIVE_TREES", "parent verification")
    path = "input/certificate-footprints-v1.json"
    require(verified["pins"]["data/certificate-footprints-v1.json"] == pin(ROOT/path), "parent footprint bytes")
    footprints = read(path)
    with gzip.open(ROOT/"input/results-v1.json.gz", "rt") as stream:
        prior = json.load(stream)
    require(model == prior["model"] and not model["marking_orientations"], "same unmarked model")
    rows = {tuple(r["attachment"]): r for r in prior["rows"]}
    negatives = {k for k, r in rows.items() if r["status"] == "NEGATIVE"}
    require(len(rows) == 304 and len(negatives) == 263, "complete prior labels")
    require(json.loads(json.dumps(replay_certificates(model, negatives, rows))) == footprints,
            "current independent proof replay and exact footprint extraction")
    indexed = {tuple(r["pair"]): tuple(map(tuple, r["footprint"])) for r in footprints}
    sparse = {tuple(p): indexed[tuple(p)] for p in verified["sparse_rooted_negatives"]}
    require(len(sparse) == 212 and len(indexed) == 263, "field sizes")
    for field in (sparse, indexed):
        require(all(points and action.swap(p) in field for p, points in field.items()),
                "symmetric nonempty certified footprint map")
    return {"unmarked": {}, "sparse": sparse, "indexed": indexed}, time.perf_counter()-start


def material(points, placement):
    g, dx, dy = placement
    return {(x+dx, y+dy): units for (x, y), units in points[g].items()}


def brute_positive(points, capacity, inventory, seeds, region):
    remaining = [p for p in inventory if p not in seeds]
    for size in range(len(remaining)+1):
        for subset in combinations(remaining, size):
            totals = Counter()
            for p in (*seeds, *subset):
                totals.update(material(points, p))
            if all(v <= capacity for v in totals.values()) and all(totals[p] == capacity for p in region):
                return True
    return False


def search_and_check(model, target, seeds, action, field, limits, *, audit=False):
    start = time.perf_counter()
    guard = RegionGuard(action, field, target, model.get("allowed_placements")) if field else None
    raw = engine.search(model, seeds, target, node_limit=limits["node_limit"],
                        seconds=limits["search_seconds"], depth_limit=limits["depth_limit"],
                        cache_limit=limits["cache_limit"], grow=False, audit=audit, conflicts=guard)
    elapsed = time.perf_counter()-start
    checked_at = time.perf_counter()
    if raw["status"] == "POSITIVE":
        require(raw["placements"][:len(seeds)] == seeds, "positive witness begins with exact seeds")
        receipt = independent.check_patch(model, raw["placements"], target, grow=False)
        require(receipt["status"] == "VERIFIED", "independently checked positive witness")
        if field:
            for a, b in combinations(map(tuple, raw["placements"]), 2):
                require(not guarded_pair(action, field, set(map(tuple, target)), a, b),
                        "positive witness and guard disagree")
    elif raw["status"] == "NEGATIVE":
        receipt = check_negative(model, raw, action, field, limits)
    else:
        require(raw["status"] == "UNKNOWN" and raw["budget_hits"], "bounded prefix")
        receipt = dict(status="UNKNOWN", reason="BOUNDED_PREFIX")
    assurance = time.perf_counter()-checked_at
    return raw, receipt, dict(method_seconds=elapsed, assurance_seconds=assurance,
                              guard=None if guard is None else guard.metrics())


def qualify(model, action, fields, limits):
    points = point_rows(model)
    capacity = model["capacity"]
    a = (0, 0, 0)
    first = material(points, a)
    field = fields["sparse"]
    chosen = None
    for b, footprint in sorted(field.items()):
        second = material(points, b)
        for p, weight in sorted(second.items()):
            if (first.get(p, 0)+weight == capacity
                    and not guarded_pair(action, field, {p}, a, b)):
                chosen = b, p, footprint
                break
        if chosen:
            break
    require(chosen is not None, "boundary fixture exists")
    b, p, footprint = chosen
    inventory = [a, b]
    fixture = {**model, "allowed_placements": [list(c) for c in inventory]}
    tiny, guarded = {p}, {p, *footprint}
    require(not guarded_pair(action, field, tiny, a, b)
            and guarded_pair(action, field, guarded, a, b), "boundary scope")
    checks = []
    for case, region in (("outside-footprint", tiny), ("inside-footprint", guarded)):
        target = [list(q) for q in sorted(region)]
        expected = brute_positive(points, capacity, inventory, [a], region)
        require(expected == (case == "outside-footprint"), "brute fixture distinguishes the region guard")
        for name, f in fields.items():
            raw, receipt, timing = search_and_check(fixture, target, [list(a)], action, f, limits, audit=True)
            require(raw["status"] == ("POSITIVE" if expected else "NEGATIVE")
                    and receipt["status"] == "VERIFIED", "brute qualification parity")
            checks.append(dict(case=case, method=name, raw=raw, receipt=receipt, timing=timing))
    region = guarded | {next(iter(sorted(first)))}
    guard = RegionGuard(action, field, region, inventory)
    graph = engine.Engine(fixture, [], sorted(region), grow=False, conflicts=guard)
    require(a in graph.valid and b in graph.valid and b in guard(a), "invalidation fixture")
    before = graph.logical_digest()
    mark = len(graph.trail)
    graph.place(a)
    require(b not in graph.valid and graph.reason(b) == "cut"
            and all(b not in domain for domain in graph.domains.values()), "cut invalidates all incidences")
    graph.rollback(mark)
    require(graph.logical_digest() == before and b in graph.valid and not graph.cut_counts,
            "exact rollback of guard, graph and selection")
    return dict(status="PASS", inventory=inventory, boundary_point=p, certificate_footprint=footprint,
                rollback=True, checks=checks)


def save_raw(name, result):
    path = ROOT/name
    with path.open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0) as compressed:
            compressed.write((json.dumps(result, sort_keys=True, separators=(",", ":"))+"\n").encode())
    return {"path": name, **pin(path)}


def main():
    protocol = frozen()
    limits = protocol["limits"]
    model = read("input/point-model-v1.json")
    action = Action(read("input/input-point-model-v1.json")["groups"])
    fields, loading_seconds = load_proofs(model, action)
    print(json.dumps(dict(phase="PROOF_ADMISSION", independent_replays=263, seconds=loading_seconds)), flush=True)
    qualification = qualify(model, action, fields, limits)
    write("data/qualification-v1.json", qualification)
    print(json.dumps(dict(phase="QUALIFICATION", status="PASS", checks=len(qualification["checks"]))), flush=True)
    (ROOT/"data/raw").mkdir()
    cases = read("input/cases-v1.json")
    require(len(cases) == 12, "frozen cohort size")
    records = []
    started = time.perf_counter()
    for case in cases:
        for name in case["method_order"]:
            raw, receipt, timing = search_and_check(model, case["target"], case["seeds"], action,
                                                     fields[name], limits)
            target = f'data/raw/{case["id"]}-{name}.json.gz'
            proof = save_raw(target, dict(raw=raw, independent=receipt, timings=timing))
            row = dict(id=case["id"], method=name, raw_status=raw["status"],
                       admitted=raw["status"] if receipt["status"] == "VERIFIED" else "UNKNOWN",
                       stats=raw["stats"], search_seconds=raw["seconds"], timing=timing,
                       budget_hits=raw["budget_hits"], independent=receipt, raw=proof,
                       filled_units=raw["best_core_units"], total_units=raw["core_total_units"])
            records.append(row)
            print(json.dumps({k:row[k] for k in ("id","method","admitted","search_seconds","budget_hits")}
                             | {"visits":row["stats"]["visits"],"guard_removals":row["stats"]["cut_removed"]}),
                  flush=True)
    require(len(records) == 36, "complete recorded schedule")
    frozen()
    write("data/results-v1.json", dict(status="COMPLETE_COHORT", cases=cases, records=records,
        proof_admission_seconds=loading_seconds, cohort_seconds=time.perf_counter()-started,
        protocol=pin(ROOT/"protocol-v1.json"), qualification=pin(ROOT/"data/qualification-v1.json")))


if __name__ == "__main__":
    main()
