"""Frozen-region conflict edges from verified negative pair footprints."""

import time


class RegionGuard:
    def __init__(self, action, footprints, target, inventory=None):
        start = time.perf_counter()
        self.target = frozenset(map(tuple, target))
        self.inventory = None if inventory is None else frozenset(map(tuple, inventory))
        self.rows = {}
        self.cache = {}
        self.calls = self.misses = 0
        self.compute_seconds = 0.0
        for h in sorted(action.rows):
            entries = []
            for pair, footprint in sorted(footprints.items()):
                g, dx, dy = pair
                other = action.compose[h, g]
                offset = action.move(h, (dx, dy))
                reverse = footprints[action.swap(pair)]
                first_points = tuple(action.move(h, p) for p in footprint)
                second_points = tuple((u+offset[0], v+offset[1])
                                      for u, v in (action.move(other, p) for p in reverse))
                entries.append((other, *offset, first_points, second_points))
            self.rows[h] = entries
        self.setup_seconds = time.perf_counter() - start

    def __call__(self, placement):
        self.calls += 1
        if placement in self.cache:
            return self.cache[placement]
        started = time.perf_counter()
        self.misses += 1
        h, x, y = placement
        cuts = set()
        for g, dx, dy, first, second in self.rows[h]:
            candidate = g, x+dx, y+dy
            if self.inventory is not None and candidate not in self.inventory:
                continue
            if (all((x+u, y+v) in self.target for u, v in first)
                    or all((x+u, y+v) in self.target for u, v in second)):
                cuts.add(candidate)
        self.cache[placement] = frozenset(cuts)
        self.compute_seconds += time.perf_counter() - started
        return self.cache[placement]

    def metrics(self):
        return dict(setup_seconds=self.setup_seconds, compute_seconds=self.compute_seconds,
                    calls=self.calls, distinct_anchors=self.misses)


def guarded_pair(action, footprints, target, a, b):
    """Independent reverse lookup for one proposed pair in certificate replay."""
    for first, second in ((a, b), (b, a)):
        h, x, y = first
        g, u, v = second
        inv = action.inverse[h]
        relative = (action.compose[inv, g], *action.move(inv, (u-x, v-y)))
        footprint = footprints.get(relative)
        if footprint and all((x+i, y+j) in target for i, j in (action.move(h, p) for p in footprint)):
            return True
    return False
