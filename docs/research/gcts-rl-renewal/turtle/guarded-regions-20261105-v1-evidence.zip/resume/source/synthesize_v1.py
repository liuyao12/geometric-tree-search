"""Build two fields from saved unmarked negative trees."""

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(name):
    return json.loads((ROOT / name).read_bytes())


def write(name, value):
    with (ROOT / name).open("x") as stream:
        json.dump(value, stream, separators=(",", ":"), sort_keys=True)
        stream.write("\n")


def verify_freeze():
    protocol = read("protocol-v1.json")
    require(protocol["schema"] == "Turtle-sparse-marking-frozen-v1", "protocol")
    require(protocol["runtime"] == pin(Path(sys.executable)), "runtime")
    for name, expected in protocol["pins"].items():
        require(pin(ROOT / name) == expected, name)
    return protocol


def apply(matrix, point):
    return tuple(sum(a * b for a, b in zip(row, point)) for row in matrix)


class Action:
    def __init__(self, rows):
        self.rows = {r["id"]: r for r in rows}
        self.matrices = {i: tuple(map(tuple, r["matrix"])) for i, r in self.rows.items()}
        by_matrix = {a: i for i, a in self.matrices.items()}
        require(set(self.rows) == set(range(12)) and len(by_matrix) == len(rows) == 12,
                "12 unique actions")
        require(self.matrices[0] == ((1, 0), (0, 1)), "identity")
        self.compose = {}
        self.inverse = {}
        for i, a in self.matrices.items():
            require(abs(a[0][0]*a[1][1] - a[0][1]*a[1][0]) == 1, "unimodular")
            for j, b in self.matrices.items():
                product = tuple(tuple(sum(x*y for x, y in zip(r, c)) for c in zip(*b)) for r in a)
                k = by_matrix[product]
                self.compose[i, j] = k
                if k == 0:
                    self.inverse[i] = j
        require(len(self.inverse) == 12, "inverses")

    def move(self, orientation, point):
        return apply(self.matrices[orientation], point)

    def swap(self, pair):
        g, dx, dy = pair
        inv = self.inverse[g]
        x, y = self.move(inv, (-dx, -dy))
        return inv, x, y


def group_marks(action, prototype):
    oriented = {}
    for i, row in sorted(action.rows.items()):
        p = row["permutation"]
        sign = (-1)**sum(a > b for k, a in enumerate(p) for b in p[k+1:])
        oriented[i] = {(*action.move(i, (x, y)), p.index(ch)): (k, sign * value)
                       for k, (x, y, ch, value) in enumerate(prototype)}
        require(len(oriented[i]) == len(prototype), "unique components")
    return oriented


def witnesses(oriented):
    conflicts = defaultdict(set)
    for g, marks in sorted(oriented.items()):
        for (x, y, ch), (first, value) in oriented[0].items():
            for (a, b, other), (second, other_value) in marks.items():
                if ch == other and value != other_value and (g, x-a, y-b) != (0, 0, 0):
                    conflicts[g, x-a, y-b].add(tuple(sorted((first, second))))
    return conflicts


def point_rows(model):
    return {r["id"]: {(x, y): units for x, y, units in r["points"]}
            for r in model["orientations"]}


def overcapacity(points, capacity, pair):
    g, dx, dy = pair
    return any(points[0].get((x+dx, y+dy), 0) + units > capacity
               for (x, y), units in points[g].items())


def bit_indices(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length()-1
        mask ^= low


def compress(negatives, prohibited, caps):
    loops = {a for a, b in prohibited if a == b}
    objectives = [defaultdict(int) for _ in range(caps["prototype_size"])]
    seeds = set()
    for index, (_, evidence) in enumerate(sorted(negatives.items())):
        for a, b in evidence:
            if a in loops or b in loops or (a, b) in prohibited:
                continue
            objectives[a][b] |= 1 << index
            objectives[b][a] |= 1 << index
            seeds.add((a, b))
    require(bool(seeds), "nonempty admissible witnesses")
    vertices = {i for i, edges in enumerate(objectives) if edges}
    universe = sum(1 << i for i in vertices)
    links = {i: sum(1 << j for j in vertices if j != i and tuple(sorted((i, j))) not in prohibited)
             for i in vertices}

    def gain(vertex, chosen):
        result = objectives[vertex].get(vertex, 0)
        for previous in bit_indices(chosen):
            result |= objectives[vertex].get(previous, 0)
        return result

    best, best_score = 0, -1

    def record(chosen, covered):
        nonlocal best, best_score
        score = covered.bit_count()
        if score > best_score:
            best, best_score = chosen, score

    started = time.perf_counter()
    for a, b in sorted(seeds):
        chosen = (1 << a) | (1 << b)
        covered = gain(a, 0) | gain(b, 1 << a)
        candidates = links[a] & links[b]
        while candidates:
            vertex = max(bit_indices(candidates),
                         key=lambda i: ((gain(i, chosen) & ~covered).bit_count(),
                                        (links[i] & candidates).bit_count(), -i))
            covered |= gain(vertex, chosen)
            chosen |= 1 << vertex
            candidates &= links[vertex]
        record(chosen, covered)
    greedy_seconds = time.perf_counter() - started
    greedy_score = best_score
    count = 0
    maximal_sets = 0
    stopped = None
    started = time.perf_counter()

    def visit(chosen, candidates, seen, covered):
        nonlocal count, stopped, maximal_sets
        if count >= caps["enumeration_nodes"] or time.perf_counter() - started >= caps["enumeration_seconds"]:
            stopped = ("node_limit" if count >= caps["enumeration_nodes"] else "wall_limit")
            return
        count += 1
        if not (candidates | seen):
            record(chosen, covered)
            maximal_sets += 1
            return
        pivot = max(bit_indices(candidates | seen),
                    key=lambda i: ((links[i] & candidates).bit_count(), -i))
        for i in bit_indices(candidates & ~links[pivot]):
            visit(chosen | (1 << i), candidates & links[i], seen & links[i], covered | gain(i, chosen))
            if stopped:
                return
            candidates ^= 1 << i
            seen |= 1 << i

    visit(0, universe, 0, 0)
    return set(bit_indices(best)), dict(score=best_score, greedy_score=greedy_score,
        greedy_seconds=greedy_seconds, seconds=time.perf_counter()-started,
        nodes=count, maximal_sets=maximal_sets, stop=stopped, exhaustive=stopped is None,
        eligible_components=len(vertices), eligible_witnesses=len(seeds),
        prohibited_pairs=len(prohibited), prohibited_loops=len(loops))


def marked_model(model, oriented_rows):
    return {**model, "marking_orientations": [dict(id=i, points=sorted(rows))
                                            for i, rows in sorted(oriented_rows.items())]}


def orbit_layer(action, negative_pairs):
    require(all(action.swap(action.swap(k)) == k and action.swap(k) in negative_pairs
                for k in negative_pairs), "verified label closure under swap")
    representatives = sorted({min(k, action.swap(k)) for k in negative_pairs})
    rows = defaultdict(list)
    for index, (g, dx, dy) in enumerate(representatives):
        inv = action.inverse[g]
        for h in sorted(action.rows):
            k = action.compose[h, inv]
            x, y = action.move(k, (-dx, -dy))
            rows[h].extend([[0, 0, 12 * index + h, 0], [x, y, 12 * index + k, 1]])
    return rows, representatives


def main():
    protocol = verify_freeze()
    model = read("input/point-model-v1.json")
    learned = read("input/corona-learned-marking-v1.json")
    marked = read("input/corona-marked-point-model-v1.json")
    original = read("input/input-point-model-v1.json")
    labels = {tuple(r["attachment"]): r["status"] for r in learned["classifications"]}
    catalogue = read("input/contact-catalogue-v1.json")
    coverage = read("input/turtle-mark-coverage-v1.json")
    require(len(labels) == len(catalogue) == 304 and set(labels) == set(map(tuple, catalogue)),
            "complete joined catalogue")
    require(marked["orientations"] == model["orientations"] and marked["capacity"] == model["capacity"]
            and not model["marking_orientations"] and "allowed_placements" not in model, "unmarked base")
    action = Action(original["groups"])
    points = point_rows(model)
    for g, support in points.items():
        require(support == {action.move(g, p): weight for p, weight in points[0].items()},
                "point capacities respect the action")
    prototype = [r for r in learned["prototype_points"] if type(r[3]) is int]
    require(len(prototype) == protocol["caps"]["prototype_size"], "prototype size")
    oriented = group_marks(action, prototype)
    full = {i: [[*p, value] for p, (_, value) in rows.items()] for i, rows in oriented.items()}
    require(marked_model(model, full) == marked, "exact learned marking reconstruction")
    all_conflicts = witnesses(oriented)
    viable = {k: w for k, w in all_conflicts.items() if not overcapacity(points, model["capacity"], k)}
    uncovered = {k: w for k, w in viable.items() if k not in labels}
    negatives = {k: w for k, w in viable.items() if labels.get(k) == "NEGATIVE"}
    require(len(viable) == len(uncovered)+len(negatives) and
            sorted(uncovered) == list(map(tuple, coverage["uncovered_mark_only"])),
            "rooted audit parity")
    prohibited = set().union(*uncovered.values())
    retained, metrics = compress(negatives, prohibited, protocol["caps"])
    sparse = {i: [[*p, v] for p, (j, v) in rows.items() if j in retained]
              for i, rows in oriented.items()}
    negative_pairs = {k for k, value in labels.items() if value == "NEGATIVE"}
    indexed, representatives = orbit_layer(action, negative_pairs)
    write("data/sparse-model-v1.json", marked_model(model, sparse))
    write("data/indexed-model-v1.json", marked_model(model, indexed))
    write("data/synthesis-v1.json", dict(status="SYNTHESIZED", sparse=metrics,
        selected_components=sorted(retained), selected_prototype_rows=[prototype[i] for i in sorted(retained)],
        indexed_representatives=representatives, full_mark_conflicts=len(all_conflicts),
        full_known_negative_conflicts=len(negatives), full_uncovered_conflicts=len(uncovered)))
    verify_freeze()
    print(json.dumps(dict(status="SYNTHESIZED", sparse=metrics, orbits=len(representatives))), flush=True)


if __name__ == "__main__":
    main()
