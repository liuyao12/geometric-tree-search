"""Replay every indexed exclusion and independently audit exported conflicts."""

from collections import defaultdict
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from synthesize_v1 import Action, overcapacity, pin, point_rows, read, require, verify_freeze, write


def shifts(first, second, same_orientation):
    left = defaultdict(dict)
    right = defaultdict(dict)
    for x, y, channel, value in first:
        require((x, y) not in left[channel], "duplicate left assignment")
        left[channel][x, y] = value
    for x, y, channel, value in second:
        require((x, y) not in right[channel], "duplicate right assignment")
        right[channel][x, y] = value
    conflicts = set()
    for ch in left.keys() & right.keys():
        left_map, right_map = left[ch], right[ch]
        for dx, dy in {(x-a, y-b) for x, y in left_map for a, b in right_map}:
            if same_orientation and (dx, dy) == (0, 0):
                continue
            shifted = {(x+dx, y+dy): value for (x, y), value in right_map.items()}
            if any(left_map[k] != shifted[k] for k in left_map.keys() & shifted.keys()):
                conflicts.add((dx, dy))
    return conflicts


def audit_model(action, base, exported, full_action=True):
    require({k: v for k, v in exported.items() if k != "marking_orientations"}
            == {k: v for k, v in base.items() if k != "marking_orientations"}, "point model binding")
    marked = {r["id"]: r["points"] for r in exported["marking_orientations"]}
    require(set(marked) == set(action.rows) and len(marked) == len(exported["marking_orientations"]),
            "mark orientations")
    by_first = {}
    for h in marked if full_action else [0]:
        inv = action.inverse[h]
        by_first[h] = {(action.compose[inv, g], *action.move(inv, shift))
                       for g, b in marked.items() for shift in shifts(marked[h], b, h == g)}
    rooted = by_first[0]
    require(all(s == rooted for s in by_first.values()), "effective conflict equivariance")
    points = point_rows(base)
    live = {k for k in rooted if not overcapacity(points, base["capacity"], k)}
    return rooted, live, dict(conflicts=len(rooted), capacity_compatible=len(live),
        already_overcapacity=len(rooted-live), channels=len({r[2] for rows in marked.values() for r in rows}),
        assignments_per_orientation={g: len(rows) for g, rows in marked.items()},
        spatial_points_in_prototype=len({tuple(r[:2]) for r in marked[0]}),
        verified_orientation_pairs=len(by_first)*len(marked))


def digest(value):
    return hashlib.sha256((json.dumps(value, sort_keys=True, separators=(",", ":"))+"\n").encode()).hexdigest()


def certificate_footprint(tree):
    pending = [tree]
    queries = set()
    while pending:
        item = pending.pop()
        decision = item["decision"]
        require(item["outcome"] == "NEGATIVE" and decision["kind"] in {"branch", "forced", "dead"},
                "fully resolved negative certificate")
        require(type(decision["point"]) is list and len(decision["point"]) == 2, "point footprint")
        queries.add(tuple(decision["point"]))
        pending.extend(edge["tree"] for edge in item["children"])
    return sorted(queries)


def replay_certificates(base, required, records):
    spec = importlib.util.spec_from_file_location("frozen_independent_checker", ROOT/"source/independent_checker_v1.py")
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    footprints = []
    for pair in sorted(required):
        r = records[pair]
        search = r["search"]
        require(r["status"] == search["status"] == "NEGATIVE" and
                search["seeds"] == [[0, 0, 0], list(pair)] and search["grow"] is True, "negative seed binding")
        verified = checker.check_tree(base, search)
        require(verified == r["tree_check"] and verified["status"] == "VERIFIED"
                and verified["outcome"] == "NEGATIVE", "independent negative tree replay")
        footprint = certificate_footprint(search["certificate"])
        footprints.append(dict(pair=pair, raw_certificate_sha256=digest(search),
                               footprint=footprint, seed_support_contains_footprint=
                               set(footprint) <= set(map(tuple, search["core"])), replay=verified))
    return footprints


def main():
    verify_freeze()
    started = time.perf_counter()
    base = read("input/point-model-v1.json")
    original = read("input/input-point-model-v1.json")
    require(base["capacity"] == 12 and base["marking_orientations"] == []
            and "allowed_placements" not in base, "unrestricted unmarked point model")
    points = point_rows(base)
    require(points[0] == {(x, y): v for x, y, v in original["original_field"]},
            "angular field of Turtle")
    action = Action(original["groups"])
    for g, rows in points.items():
        require(rows == {action.move(g, p): v for p, v in points[0].items()}, "oriented t-field")
    with gzip.open(ROOT/"input/results-v1.json.gz", "rt") as stream:
        prior = json.load(stream)
    catalogue = read("input/contact-catalogue-v1.json")
    require(prior["catalogue"] == catalogue and prior["model"] == base
            and [r["attachment"] for r in prior["rows"]] == catalogue, "saved proof model and order")
    saved = {tuple(r["attachment"]): r for r in prior["rows"]}
    negatives = {k for k, v in saved.items() if v["status"] == "NEGATIVE"}
    positives = {k for k, v in saved.items() if v["status"] == "POSITIVE"}
    require(len(saved) == 304 and len(negatives) == 263 and len(positives) == 41, "label coverage")

    full = read("input/corona-marked-point-model-v1.json")
    sparse = read("data/sparse-model-v1.json")
    indexed = read("data/indexed-model-v1.json")
    synthesis = read("data/synthesis-v1.json")
    _, full_live, full_stats = audit_model(action, base, full, full_action=False)
    _, sparse_live, sparse_stats = audit_model(action, base, sparse)
    indexed_all, indexed_live, indexed_stats = audit_model(action, base, indexed)
    unknown = full_live - negatives - positives
    coverage = read("input/turtle-mark-coverage-v1.json")
    require(sorted(unknown) == list(map(tuple, coverage["uncovered_mark_only"]))
            and not (full_live & positives) and len(full_live & negatives) == 236, "published coverage parity")
    require(sparse_live <= full_live & negatives and len(sparse_live) == synthesis["sparse"]["score"],
            "only previously certified live sparse conflicts")
    require(indexed_all == indexed_live == negatives, "indexed exclusions exactly the negative catalogue")
    require(all(set(map(tuple, s["points"])) <= set(map(tuple, f["points"]))
                for s, f in zip(sparse["marking_orientations"], full["marking_orientations"])), "deletion only")
    footprints = replay_certificates(base, indexed_live | sparse_live, saved)
    write("data/certificate-footprints-v1.json", footprints)
    for stats, pairs in [(full_stats, full_live), (sparse_stats, sparse_live), (indexed_stats, indexed_live)]:
        stats.update(negative=len(pairs & negatives), positive=len(pairs & positives),
                     uncovered=len(pairs - negatives - positives))
    example = max((r for r in footprints if tuple(r["pair"]) in sparse_live),
                  key=lambda r: (len(r["footprint"]), r["pair"]))
    result = dict(status="VERIFIED_BOTH_FIELDS_AND_ALL_USED_NEGATIVE_TREES",
        models=dict(full=full_stats, sparse=sparse_stats, indexed=indexed_stats),
        indexed_orbits=len(synthesis["indexed_representatives"]),
        independent_negative_replays=len(footprints), sample_sparse_certificate=example,
        certificates_querying_outside_seed_support=sum(not r["seed_support_contains_footprint"] for r in footprints),
        footprint_max=max(len(r["footprint"]) for r in footprints),
        footprint_nodes=sum(r["replay"]["counts"]["certificate_nodes"] for r in footprints),
        sparse_rooted_negatives=sorted(sparse_live), seconds=time.perf_counter()-started,
        pins={n: pin(ROOT/n) for n in ["data/sparse-model-v1.json", "data/indexed-model-v1.json",
              "data/synthesis-v1.json", "data/certificate-footprints-v1.json", "protocol-v1.json"]},
        scope="Conditional redundancy under point saturation. No assertion of existence, search speed or substitution.")
    verify_freeze()
    write("data/verification-v1.json", result)
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
