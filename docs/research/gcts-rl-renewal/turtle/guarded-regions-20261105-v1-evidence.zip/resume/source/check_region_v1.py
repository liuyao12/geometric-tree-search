"""Independent reconstruction of guarded negative search trees."""

from functools import lru_cache
import time

import independent_checker_v1 as independent
from guard_v1 import guarded_pair
from synthesize_v1 import require


def check_negative(model, result, action, footprints, limits):
    target = set(map(tuple, result["core"]))
    verifier = independent._Verifier(model)
    seeds = result["seeds"]
    require(result["status"] == "NEGATIVE" and result["grow"] is False, "negative finite result")
    started = time.perf_counter()
    nodes, dead_leaves = 0, 0

    @lru_cache(maxsize=400_000)
    def blocked(first, second):
        return guarded_pair(action, footprints, target, first, second)

    def visit(node, prefix, generations, depth):
        nonlocal nodes, dead_leaves
        if time.perf_counter()-started >= limits["assurance_seconds"]:
            raise independent.Resource("REGION_ASSURANCE_WALL_LIMIT")
        nodes += 1
        require(nodes <= limits["node_limit"] and depth <= limits["depth_limit"], "recorded search limits")
        require(node["outcome"] == "NEGATIVE", "negative tree has a fully resolved child")
        state = verifier.state(prefix, target, generations, len(seeds))
        selected = sorted(state["selected"])
        require(not any(blocked(a, b) for i, a in enumerate(selected) for b in selected[i+1:]),
                "tree prefix violates a guarded exclusion")
        domains = verifier.graph(state, target, False)
        valid = {}
        for q, domain in domains.items():
            retained = []
            for c in domain:
                if c not in valid:
                    valid[c] = not footprints or not any(blocked(*sorted((s, c))) for s in selected)
                if valid[c]:
                    retained.append(c)
            domains[q] = retained
        filled = not domains
        decision = independent._decision(state, domains, target, filled)
        independent._check_decision(verifier, node["decision"], decision)
        require(set(node) == {"decision", "outcome", "children"}, "exact node fields")
        children = node["children"]
        if decision["kind"] == "dead":
            require(not children, "negative leaf has no children")
            dead_leaves += 1
            return
        require(decision["kind"] in {"branch", "forced"}, "negative tree reached a success")
        require([child["move"] for child in children] == decision["candidates"],
                "negative tree omits, repeats or reorders a legal candidate")
        for child in children:
            move = verifier.placement(child["move"])
            generation = 1+min(state["generations"][q] for q, _ in verifier.t_rows(move)
                               if q in state["generations"])
            visit(child["tree"], prefix+[list(move)], generations+[generation], depth+1)

    try:
        visit(result["certificate"], seeds, [0]*len(seeds), 0)
        status, reason = "VERIFIED", "EXHAUSTED_CHECKED_FINITE_TREE"
    except independent.Resource as error:
        status, reason = "UNKNOWN", str(error)
    return dict(status=status, reason=reason, nodes=nodes, dead_leaves=dead_leaves,
                independent_work=verifier.work, seconds=time.perf_counter()-started)
