"""Generate fresh fixed obligation sets before any solver outcome."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from synthesize_v1 import Action, point_rows, read, require, write


FAMILIES = ("notched-hexagon", "slit-strip", "offset-islands")
SCALES = (12, 15, 18)
MODES = ("unmarked", "sparse", "indexed")


def hexagon(radius, dx=0, dy=0):
    return {(dx+x, dy+y) for x in range(-radius, radius+1)
            for y in range(-radius, radius+1) if max(abs(x), abs(y), abs(x+y)) <= radius}


def mask(family, scale):
    if family == "notched-hexagon":
        return {p for p in hexagon(scale, -2, 1)
                if not (p[0] >= 0 and p[1] >= 2 and (p[0]+2)*2+p[1]-1 >= scale)}
    if family == "slit-strip":
        return {(x, y) for x in range(-scale-4, scale+1)
                for y in range(-2, 3+scale//3)
                if not (y == 1 and -scale+1 <= x <= scale-2)}
    return (hexagon(scale//2+1, -scale-2, 2)
            | hexagon(scale//3+1, scale//2+1, -2)
            | {(-2, 1), (-1, 1), (0, 1)})


def canonical(points, action):
    images = []
    for g in sorted(action.rows):
        image = sorted(action.move(g, p) for p in points)
        ox, oy = image[0]
        images.append(tuple((x-ox, y-oy) for x, y in image))
    return min(images)


def main():
    model = read("input/point-model-v1.json")
    action = Action(read("input/input-point-model-v1.json")["groups"])
    points = point_rows(model)
    root = set(points[0])
    seen = {canonical(root, action)}
    for name in ("prior-receptor", "prior-cluster"):
        previous = read(f"input/{name}-cases-v1.json")
        for split in previous.values():
            for row in split:
                for key in ("target", "core"):
                    seen.add(canonical(set(map(tuple, row[key])), action))
    for g, dx, dy in read("input/contact-catalogue-v1.json"):
        seen.add(canonical(root | {(x+dx, y+dy) for x, y in points[g]}, action))
    for row in read("input/first-cohort-cases-v1.json"):
        seen.add(canonical(set(map(tuple, row["target"])), action))
    cases = []
    for family in FAMILIES:
        for scale in SCALES:
            target = mask(family, scale) | root
            key = canonical(target, action)
            require(key not in seen and len(target) <= 1050, "fresh bounded obligation set")
            seen.add(key)
            i = len(cases)
            offset = (i+2) % len(MODES)
            cases.append(dict(id=f"S{i+1:02d}", family=family, scale=scale,
                              seeds=[[0, 0, 0]], target=sorted(target),
                              method_order=MODES[offset:] + MODES[:offset]))
    write("input/cases-v1.json", cases)
    print([(c["id"], c["family"], c["scale"], len(c["target"])) for c in cases], flush=True)


if __name__ == "__main__":
    main()
