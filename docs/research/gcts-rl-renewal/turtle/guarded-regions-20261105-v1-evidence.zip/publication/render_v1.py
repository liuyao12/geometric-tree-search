"""Audit the saved cohorts and render their finite-region comparison."""

from collections import Counter
import gzip
import hashlib
import json
from math import sqrt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STEM = "guarded-regions-20261105-v1"
MODES = ("unmarked", "sparse", "indexed")
LABEL = {"unmarked": "Unmarked", "sparse": "Sparse", "indexed": "Indexed"}
FAMILY = {"notched-hexagon": "Notched hexagon", "slit-strip": "Slit strip", "offset-islands": "Offset islands"}


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def write(path, payload):
    with path.open("xb") as stream:
        stream.write(payload)


def audit(folder, expected, *, recovery=None, positions=None, status="COMPLETE_COHORT"):
    protocol = read(folder/"protocol-v1.json")
    for name, ref in protocol["pins"].items():
        assert pin(folder/name) == ref, name
    result = recovery if recovery is not None else read(folder/"data/results-v1.json")
    assert result["status"] == status and result["protocol"] == pin(folder/"protocol-v1.json")
    cases = read(folder/"input/cases-v1.json")
    assert result["cases"] == cases and len(cases) == expected
    qualification = folder/"data/qualification-v1.json"
    q = read(qualification)
    assert result["qualification"] == pin(qualification) and q["status"] == "PASS" and q["rollback"]
    assert len(q["checks"]) == 6 and all(c["receipt"]["status"] == "VERIFIED" for c in q["checks"])
    schedule = [[c["id"], m] for c in cases for m in c["method_order"]]
    assert [[r["id"], r["method"]] for r in result["records"]] == (positions or schedule)
    visits = {}
    for row in result["records"]:
        case = next(c for c in cases if c["id"] == row["id"])
        ref = row["raw"]
        assert ref["path"] == f'data/raw/{row["id"]}-{row["method"]}.json.gz'
        path = folder/ref["path"]
        assert pin(path) == {k: ref[k] for k in ("bytes", "sha256")}
        with gzip.open(path, "rt") as stream:
            record = json.load(stream)
        raw = record["raw"]
        assert raw["seeds"] == case["seeds"] and raw["core"] == case["target"] and raw["grow"] is False
        expected_limits = protocol["limits"]
        assert raw["limits"] == dict(nodes=expected_limits["node_limit"], seconds=expected_limits["search_seconds"],
                                     depth=expected_limits["depth_limit"], cache=expected_limits["cache_limit"])
        assert raw["stats"] == row["stats"] and raw["status"] == row["raw_status"]
        assert raw["budget_hits"] == row["budget_hits"] and raw["seconds"] == row["search_seconds"]
        assert raw["best_core_units"] == row["filled_units"] and raw["core_total_units"] == row["total_units"]
        assert record["independent"] == row["independent"] and record["timings"] == row["timing"]
        assert row["admitted"] == (raw["status"] if row["independent"]["status"] == "VERIFIED" else "UNKNOWN")
        assert raw["status"] != "POSITIVE" or row["admitted"] == "POSITIVE"
        visits.setdefault(row["id"], set()).add(row["admitted"])
    assert all(not {"POSITIVE", "NEGATIVE"} <= kinds for kinds in visits.values())
    return result


def recovered_prefix():
    folder = ROOT/"stress"
    resume = ROOT/"resume"
    failure = read(resume/"input/stress-first-attempt-v1.json")
    assert failure["status"] == "TERMINAL_DRIVER_ERROR" and failure["native_exit"] == 1
    for kind in ("stdout", "stderr"):
        assert (folder/f"data/experiment.{kind}.log").read_bytes() == (resume/f"input/stress-first.{kind}.log").read_bytes()
    log = [json.loads(s) for s in (folder/"data/experiment.stdout.log").read_text().splitlines()]
    assert log[0]["phase"] == "PROOF_ADMISSION" and log[1]["status"] == "PASS"
    records = []
    for trace, (case, method) in zip(log[2:], failure["completed"], strict=True):
        name = f"{case}-{method}.json.gz"
        path = folder/"data/raw"/name
        ref = pin(path)
        assert ref == failure["completed_raw_pins"][name]
        with gzip.open(path, "rt") as stream:
            saved = json.load(stream)
        raw, receipt = saved["raw"], saved["independent"]
        row = dict(id=case, method=method, raw_status=raw["status"],
                   admitted=raw["status"] if receipt["status"] == "VERIFIED" else "UNKNOWN",
                   stats=raw["stats"], search_seconds=raw["seconds"], timing=saved["timings"],
                   budget_hits=raw["budget_hits"], independent=receipt,
                   raw={"path": f"data/raw/{name}", **ref},
                   filled_units=raw["best_core_units"], total_units=raw["core_total_units"])
        assert trace == {k:row[k] for k in ("id","method","admitted","search_seconds","budget_hits")} | {
            "visits":row["stats"]["visits"],"guard_removals":row["stats"]["cut_removed"]}
        records.append(row)
    prefix = dict(status="RECOVERED_COMPLETED_PREFIX", cases=read(folder/"input/cases-v1.json"),
                  records=records, proof_admission_seconds=log[0]["seconds"],
                  protocol=pin(folder/"protocol-v1.json"), qualification=pin(folder/"data/qualification-v1.json"))
    prefix = audit(folder, 9, recovery=prefix, positions=failure["completed"], status=prefix["status"])
    suffix = audit(resume, 9, positions=failure["remaining"], status="COMPLETE_SUFFIX")
    q = read(resume/"data/qualification-v1.json")
    assert q["cutoff_fixture"]["status"] == "UNKNOWN" and q["cutoff_fixture"]["budget_hits"] == ["nodes"]
    assert prefix["cases"] == suffix["cases"]
    for cohort, source in ((prefix, "stress"), (suffix, "resume")):
        for row in cohort["records"]:
            row["raw"]["path"] = source+"/"+row["raw"]["path"]
    case, method = failure["failed"]
    unavailable = dict(id=case, method=method, admitted="UNKNOWN", raw_status=None,
        stats=dict(visits=None, branches=None, cut_removed=None),
        timing=dict(method_seconds=None, assurance_seconds=None, guard=None),
        budget_hits=[], independent=dict(status="UNKNOWN", reason="DRIVER_STOPPED_BEFORE_TRACE_SAVE"),
        raw=None, filled_units=None, total_units=None, search_seconds=None)
    all_rows = prefix["records"]+[unavailable]+suffix["records"]
    assert [[r["id"], r["method"]] for r in all_rows] == [[c["id"],m] for c in prefix["cases"] for m in c["method_order"]]
    for c in prefix["cases"]:
        assert not {"POSITIVE","NEGATIVE"} <= {r["admitted"] for r in all_rows if r["id"] == c["id"]}
    return dict(status="COMPLETE_SCHEDULE_WITH_ONE_MISSING_TRACE", cases=prefix["cases"], records=all_rows,
        proof_admission_seconds=prefix["proof_admission_seconds"]+suffix["proof_admission_seconds"],
        first_protocol=prefix["protocol"], suffix_protocol=suffix["protocol"], failed_attempt=failure,
        shared_replays=[prefix["proof_admission_seconds"],suffix["proof_admission_seconds"]])


def stats(cohort):
    rows = cohort["records"]
    ids = [c["id"] for c in cohort["cases"]]
    common = {i for i in ids if all(r["admitted"] == "POSITIVE" for r in rows if r["id"] == i)}
    metrics = {}
    for method in MODES:
        jobs = [r for r in rows if r["method"] == method]
        metrics[method] = dict(outcomes=dict(Counter(r["admitted"] for r in jobs)),
            measured=sum(r["raw"] is not None for r in jobs),
            visits=sum(r["stats"]["visits"] or 0 for r in jobs),
            paired_visits=sum(r["stats"]["visits"] for r in jobs if r["id"] in common),
            method_seconds=sum(r["timing"]["method_seconds"] or 0 for r in jobs),
            paired_seconds=sum(r["timing"]["method_seconds"] for r in jobs if r["id"] in common),
            assurance_seconds=sum(r["timing"]["assurance_seconds"] or 0 for r in jobs),
            setup_seconds=sum(r["timing"]["guard"]["setup_seconds"] for r in jobs if r["timing"]["guard"]),
            guard_compute_seconds=sum(r["timing"]["guard"]["compute_seconds"] for r in jobs if r["timing"]["guard"]),
            cut_removals=sum(r["stats"]["cut_removed"] or 0 for r in jobs))
    return dict(common_positive=sorted(common), methods=metrics)


def grid(case, root):
    def point(q):
        x, y = q
        return x+y/2, -y*sqrt(3)/2
    coords = [point(q) for q in case["target"]]
    xs, ys = zip(*coords)
    frame = f'{min(xs)-1:.2f} {min(ys)-1:.2f} {max(xs)-min(xs)+2:.2f} {max(ys)-min(ys)+2:.2f}'
    outline = " ".join(f'{x:.3f},{y:.3f}' for x, y in map(point, root))
    markers = ''.join(f'<circle cx="{x:.3f}" cy="{y:.3f}" r=".18"></circle>' for x, y in coords)
    return (f'<svg viewBox="{frame}" role="img" aria-label="{FAMILY[case["family"]]} required points">'
            f'<g fill="#527b70">{markers}</g><polygon points="{outline}" fill="#e5ab66" '
            'fill-opacity=".4" stroke="#9b5819" stroke-width=".15"></polygon></svg>')


def summary_table(cohort):
    s = cohort["summary"]
    rows = []
    for method in MODES:
        r = s["methods"][method]
        values = [r["outcomes"].get("POSITIVE", 0), r["outcomes"].get("NEGATIVE", 0),
                  r["outcomes"].get("UNKNOWN", 0), r["measured"], r["visits"], r["paired_visits"],
                  f'{r["method_seconds"]:.3f}', f'{r["paired_seconds"]:.3f}',
                  f'{r["assurance_seconds"]:.3f}', r["cut_removals"]]
        rows.append(f'<tr><th scope="row">{LABEL[method]}</th>'
                    + ''.join(f'<td>{v}</td>' for v in values) + '</tr>')
    headers = ("Method", "Checked positive", "Checked negative", "Unresolved", "Measured runs", "Recorded visits",
               "Paired visits", "Recorded method s", "Paired method s", "Assurance s", "Cut removals")
    return table(headers, rows)


def table(headers, rows):
    heading = ''.join(f'<th scope="col">{h}</th>' for h in headers)
    return '<div class="scroll"><table><thead><tr>'+heading+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'


def case_section(case, jobs, root):
    maximum = max(r["timing"]["method_seconds"] or 0 for r in jobs)
    rows, bars = [], []
    for method in MODES:
        r = next(x for x in jobs if x["method"] == method)
        timing = r["timing"]
        guard = timing["guard"] or {}
        units = '—' if r["filled_units"] is None else f'{100*r["filled_units"]/r["total_units"]:.1f}%'
        outcome = r["admitted"].capitalize()
        if r["raw"] is None:
            rows.append(f'<tr><th scope="row">{LABEL[method]}</th><td>Unresolved · trace unavailable</td>'
                        + '<td>—</td>'*7 + '</tr>')
            continue
        if r["budget_hits"]:
            outcome += ' · ' + ', '.join(sorted(set(r["budget_hits"])))
        elif r["admitted"] == "UNKNOWN":
            outcome += ' · assurance limit'
        values = [outcome, r["stats"]["visits"], r["stats"]["branches"],
                  f'{timing["method_seconds"]:.3f}', f'{guard.get("setup_seconds",0):.3f}',
                  f'{guard.get("compute_seconds",0):.3f}', f'{timing["assurance_seconds"]:.3f}', units]
        rows.append(f'<tr><th scope="row">{LABEL[method]}</th>'
                    + ''.join(f'<td>{v}</td>' for v in values) + '</tr>')
        pct = 100*timing["method_seconds"]/maximum
        bars.append(f'<div class="bar-row"><span>{LABEL[method]}</span><div class="track">'
                    f'<div class="bar {method}" style="width:{pct:.4f}%"></div></div>'
                    f'<strong>{timing["method_seconds"]:.3f} s</strong></div>')
    title = f'{case["id"]} · {FAMILY[case["family"]]} · scale {case["scale"]} · {len(case["target"])} points'
    headers = ("Method", "Outcome", "Visits", "Branches", "Method s", "Guard setup s",
               "Guard lookup s", "Assurance s", "Best target fill")
    return (f'<details><summary>{title}</summary><div class="case">'
            f'<figure>{grid(case, root)}<figcaption>Required points and seed tile</figcaption></figure>'
            '<div class="bars" aria-label="Whole method times">' + ''.join(bars) + '</div></div>'
            + table(headers, rows) + '</details>')


def cohort_section(cohort, root):
    shared = cohort["summary"]["common_positive"]
    note = ""
    if "failed_attempt" in cohort:
        note = ('<p>The unmarked run on S07 stopped the driver when its cutoff record omitted the reason. '
                'It remains unresolved with no saved trace or timing. The seven previously unstarted '
                'jobs ran after a logging fix and a new cutoff qualification. Recorded totals omit '
                'the missing measurement. The two larger-cohort processes each replayed the donor trees.</p>')
    return (f'<section><h2>{cohort["title"]}</h2>'
            f'<p>Paired totals cover the {len(shared)} targets with a checked positive witness in every method. '
            f'Donor proof replay took {cohort["proof_admission_seconds"]:.3f} seconds for this cohort.</p>'
            + note + summary_table(cohort)
            + ''.join(case_section(c, [r for r in cohort["records"] if r["id"] == c["id"]], root)
                      for c in cohort["cases"]) + '</section>')


def render(cohorts, original):
    return HEAD + ''.join(cohort_section(c, original["polygon"]) for c in cohorts) + END


HEAD = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Certified Turtle pruning on fixed regions</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#173a32;--line:#cadbd0;--mint:#eff6ef}
*{box-sizing:border-box}body{margin:0;background:#f6f3e9;color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1160px;margin:auto;padding:24px}header{padding:30px 0;max-width:890px}
h1{font:clamp(2rem,5vw,3.7rem)/1.08 Georgia,serif;margin:.45em 0}h2{font:1.7rem/1.15 Georgia,serif;margin:0 0 .55em}
section{background:#fffefa;border:1px solid var(--line);border-radius:12px;padding:18px;margin:0 0 18px}
.eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.12em}a{color:#176b59}
.scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:.88rem}td,th{text-align:left;padding:7px;border-bottom:1px solid var(--line)}
details{padding:.6em 0;border-top:1px solid var(--line)}summary{cursor:pointer;font-weight:650}
.case{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr));gap:10px;align-items:center}
figure{margin:8px 0;background:var(--mint);padding:8px;border-radius:8px}figcaption{font-size:.84rem}
svg{display:block;width:100%;height:200px}.bars{background:var(--mint);border-radius:8px;padding:10px}
.bar-row{display:grid;grid-template-columns:78px 1fr 76px;align-items:center;gap:8px;font-size:.84rem;padding:3px 0}
.track,.bar{height:12px;border-radius:3px}.track{background:#dce7df}
.unmarked{background:#986437}.sparse{background:#23755d}.indexed{background:#6552a1}
</style></head><body><main>
<header><p class="eyebrow">GCTS research · Turtle on \(A_2\)</p>
<h1>Certified Turtle pruning on fixed regions</h1>
<p>Three methods saturate the same prescribed lattice points. Unmarked search uses only
point capacity. The sparse and indexed methods also use the earlier negative certificates
when their entire footprint lies inside the target.</p>
<p>The exterior has free saturation and tiles may cross the target boundary.
Open any region to inspect its points, seed and per-method measurements.</p>
<p><a href="#method">Measurement details</a> · <a href="#evidence">Evidence archive</a></p></header>
'''


END = f'''<section id="method"><h2>What the comparison measures</h2>
<p>Each method had the same primitive scheduler and limits of four search seconds,
1,200 visits, depth 96 and 32,000 cached occupancy fields. Method time includes guard
setup, initialization and search. Assurance and shared replay of the donor certificates
are reported separately. Cut removals count search events and may recur after rollback.</p>
<p>The six qualification runs matched exhaustive subset enumeration on the same two
placements. The guard retains the second placement when its certificate queries a point
outside the target. It rejects the pair when the entire footprint is required. A separate
fixture checked that an installed cut removes every affected candidate incidence and
that rollback restores the graph exactly.</p>
<p>The first cohort had one run per method per region. The larger cohort was frozen
after the first, with the same search limits. Unknown jobs give bounded search prefixes.
The evidence here concerns finite point obligations and certificate pruning.</p>
</section>
<section id="evidence"><h2>Experiment records</h2>
<p><a href="{STEM}-evidence.zip">Full evidence archive</a> ·
<a href="{STEM}-manifest.json">Archive manifest</a> ·
<a href="{STEM}-results.json">Audited cohort data</a> ·
<a href="certified-sparse-marking-20261105-v1.html#reader">Marking layers and example footprint</a></p>
</section></main></body></html>
'''


def main():
    first = audit(ROOT, 12)
    stress = recovered_prefix()
    result = [dict(title=title, summary=stats(data), **data)
              for title, data in (("Initial 12 regions", first), ("Nine larger regions", stress))]
    original = read(ROOT/"input/input-point-model-v1.json")
    write(ROOT/"report"/(STEM+".html"), render(result, original).encode())
    write(ROOT/"report"/(STEM+"-results.json"), (json.dumps(result, sort_keys=True)+"\n").encode())
    print(json.dumps([dict(title=r["title"], **r["summary"]) for r in result]), flush=True)


if __name__ == "__main__":
    main()
