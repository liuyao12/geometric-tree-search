# Larger fixed point regions

After all three methods checked positive on the initial twelve targets, this
follow-up tests the same algorithms at larger scales. It generates nine new
obligation sets at scales 12, 15 and 18 using the same three shape families,
the same identity seed, and a balanced cyclic execution order. Duplicate
rejection includes the initial twelve targets. All original time, visit,
depth, cache, and independent assurance limits apply. The fixed point model,
guarded pair rules and independent checker are unchanged.

Only the generator's scales, labels, maximum point count and duplicate
references, and the driver's expected cohort sizes differ. The initial cohort
is retained separately. These follow-up targets were chosen by scale before
any follow-up outcomes were observed.
