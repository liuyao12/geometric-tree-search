Certified Turtle failure markings

Open report/certified-sparse-marking-20261105-v1.html for the experiment.
The input directory contains the previous unmarked result archive and model.
The frozen protocol records the source, input, runtime and search limits.

To reproduce with the pinned Python, extract into a fresh working directory.
Preserve the archived results, and clear the five generated JSON files from
the data directory in a separate copy before running these commands there:

    python -I -S -B source/synthesize_v1.py
    python -I -S -B source/verify_v1.py

The scripts create output files exclusively and verify the frozen pins.
Run the renderer from that copy after moving its old HTML out of report:

    python -I -S -B publication/render_v1.py

Timings are observed rather than deterministic. The scientific scripts do
not use network access. The archive manifest provides the exact original
contents, including the source review and independent verification receipt.
