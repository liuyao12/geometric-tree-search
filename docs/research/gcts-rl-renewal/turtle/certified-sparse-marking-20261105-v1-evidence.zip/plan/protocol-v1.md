# Turtle markings backed by finite certificates

The prior unmarked search produced 263 negative and 41 positive rooted corona
results. The learned marking excluded 236 negatives and 1,060 capacity-compatible
pairs outside the catalogue. This study uses only the saved unmarked search
certificates and the previously learned field.

1. Reconstruct the exact orientation action and the learned marking. Enumerate
   all rooted conflicts by alignment of unequal values in the same channel.
2. Maximize the number of known-negative conflicts retained by deleting
   components from the learned three-channel field. An uncovered conflict
   contributes a forbidden pair of component indices, including a loop when
   the two endpoints are the same prototype component. Seed the search with
   greedy extensions of every admissible negative witness and enumerate maximal
   compatible sets by pivoting. Stop at 150,000 recursive states or 35 seconds
   in that enumeration. Report a feasible lower bound if enumeration stops.
3. Build a second field from the negative certificates directly. Identify a
   rooted pair with its swapped and rerooted pair. Give each class twelve
   channels permuted by the left action of the orientation group. Store two
   values per oriented tile per class. With representative \\( (g,d) \\),
   orientation \\(h\\) puts zero at the origin on channel \\(h\\) and one
   at \\(-hg^{-1}d\\) on channel \\(hg^{-1}\\). Equal tags and unequal
   values then force the original pair or its swap.
4. Verify both exported fields by a separate alignment implementation. Replay
   every used negative with the frozen independent checker, binding the
   original unmarked model and two seeds. Require exact conflict coverage,
   valid action and absence of all positive or uncertified conflicts.

For a checked negative tree, the footprint is the set of all queried points,
including dead leaves. Suppose a capacity-legal completion contains the two
seeds and saturates the footprint. From any prefix in the completion, an
unsaturated queried point has some unused contributing placement from the
completion. The verifier enumerates that placement in the legal domain.
Following such a child through the finite tree contradicts reaching a dead
leaf. The same argument applies after any allowed orientation and translation.
Full saturation therefore makes all checked pair exclusions redundant. For a
finite target, the certificate applies when the transformed footprint must be
saturated. Pair rejection has no such implication for an arbitrary partial
patch or an arbitrary boundary target.

The experiment compares representational size and exclusion coverage. It
does not run a new tiling search, measure pruning speed or establish a plane
tiling or substitution. Exported fields are separated from unconditional
finite-target use.
