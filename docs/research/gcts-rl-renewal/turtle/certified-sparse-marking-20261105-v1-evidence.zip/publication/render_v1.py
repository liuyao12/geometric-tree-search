"""Render the audited Turtle marking comparison and one certificate footprint."""

import hashlib
import json
from math import sqrt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STEM = "certified-sparse-marking-20261105-v1"


def read(name):
    return json.loads((ROOT / name).read_bytes())


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def svg_markings(polygon, markings):
    colors = ("#176754", "#8f4e13", "#773983")
    grouped = {}
    for x, y, ch, value in markings:
        grouped.setdefault((x, y), []).append((ch, value))
    overlays = []
    for (x, y), values in sorted(grouped.items()):
        cx, cy = project((x, y))
        for index, (channel, value) in enumerate(sorted(values)):
            px = cx + 8 * (index - (len(values)-1)/2)
            color = colors[channel]
            overlays.append(f'<circle cx="{px:.1f}" cy="{cy:.1f}" r="3.6" '
                            f'fill="{color if value else "white"}" stroke="{color}" stroke-width="1.5">'
                            f'<title>Channel {channel}, value {value}</title></circle>')
    grid = ''.join(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="1.05" fill="#bed1c7"></circle>'
                   for a in range(-7, 4) for b in range(-5, 10)
                   for x, y in [project((a, b))])
    return ('<svg viewBox="-175 -160 330 275" role="img" aria-label="Sparse Turtle marking">'
            + grid + outline(polygon, '#dbece3', '#215945') + ''.join(overlays) + '</svg>')


def project(point):
    x, y = point
    return 18 * (x + y / 2), -9 * sqrt(3) * y


def outline(polygon, fill, stroke):
    vertices = ' '.join(f'{x:.2f},{y:.2f}' for x, y in map(project, polygon))
    return f'<polygon points="{vertices}" fill="{fill}" fill-opacity=".68" stroke="{stroke}" stroke-width="1.6"></polygon>'


def svg_footprint(original, example):
    polygon = original["polygon"]
    g, dx, dy = example["pair"]
    matrix = next(row["matrix"] for row in original["groups"] if row["id"] == g)
    (a, b), (c, d) = matrix
    other = [(a*x+b*y+dx, c*x+d*y+dy) for x, y in polygon]
    points = [project(p) for p in polygon+other+example["footprint"]]
    xs, ys = zip(*points)
    bounds = min(xs)-16, min(ys)-16, max(xs)-min(xs)+32, max(ys)-min(ys)+32
    view = ' '.join(f'{v:.2f}' for v in bounds)
    rings = ''.join(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3.7" '
                    'fill="#fffefa" stroke="#5d2478" stroke-width="2"></circle>'
                    for x, y in map(project, example["footprint"]))
    return (f'<svg viewBox="{view}" role="img" aria-label="Two Turtle seeds and queried points">'
            + outline(polygon, '#bce1cc', '#215945') + outline(other, '#f6d3a9', '#995423') + rings + '</svg>')


def chart(models):
    out = []
    for name, display in (("full", "Original learned"), ("sparse", "Sparse"), ("indexed", "Indexed")):
        model = models[name]
        out.append(f'<div class="bar-row"><span>{display}</span><div class="track">'
                   f'<div class="bar" style="width:{100*model["negative"]/263:.3f}%"></div></div>'
                   f'<strong>{model["negative"]}</strong></div>')
    return '<div class="bars" aria-label="Certified negative pairs excluded">' + ''.join(out) + '</div>'


def render(synthesis, check, original):
    models = check["models"]
    example = check["sample_sparse_certificate"]
    rows = []
    for name, label in (("full", "Original learned"), ("sparse", "Sparse"), ("indexed", "Indexed")):
        m = models[name]
        values = [m["assignments_per_orientation"]["0"], m["channels"], m["negative"],
                  m["uncovered"], m["already_overcapacity"]]
        rows.append('<tr><th scope="row">' + label + '</th>' +
                    ''.join(f'<td>{value:,}</td>' for value in values) + '</tr>')
    g, dx, dy = example["pair"]
    nodes = example["replay"]["counts"]["certificate_nodes"]
    footprint_math = r",\,".join(f"({x},{y})" for x, y in example["footprint"])
    sparse = synthesis["sparse"]
    if sparse["exhaustive"]:
        optimum = (f'The search exhausted {sparse["maximal_sets"]:,} maximal compatible sets. '
                   'The result is optimal among deletion-only subsets of the original assignments '
                   'under the no-uncovered-conflict constraint.')
    else:
        optimum = 'The search reached its limit. The reported coverage is a feasible lower bound.'
    return HEAD + fr'''
<header>
<p class="kicker">GCTS research · Turtle on \(A_2\)</p>
<h1>Certified Turtle failure markings</h1>
<p>A compact learned field retains {models["sparse"]["negative"]} negative pair exclusions.
A certificate-indexed field captures all {check["independent_negative_replays"]} checked negatives.
Both agree with the original capacity problem wherever their certificate footprints must be filled.</p>
<p><a href="#reader">Marking and proof footprint</a> · <a href="#argument">Why it is safe</a>
 · <a href="#evidence">Reproduce the experiment</a></p>
</header>
<section><h2>Coverage and representation size</h2>
<p>Bars count rooted capacity-compatible pairs excluded by the field and backed by a negative certificate.
The catalogue contains 263 such negatives. Each rooted pair fixes the first tile at the origin.</p>
{chart(models)}
<div class="table-wrap"><table><thead><tr><th scope="col">Field</th>
<th scope="col">Assignments per orientation</th><th scope="col">Channels across all orientations</th>
<th scope="col">Certified exclusions</th><th scope="col">Uncovered conflicts</th>
<th scope="col">Already overcapacity</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<p>{optimum} A conflict outside the certificate catalogue forbids keeping its two
prototype components together. A conflict between a component and its own transformed copy
forbids keeping that component at all.</p>
<p>The indexed field groups the negatives into {check["indexed_orbits"]} classes under swapping
and rerooting. Each class receives its own channels, which the orientation group permutes.
Each orientation carries two assigned values per class. The checker exhaustively compared
all {models["indexed"]["verified_orientation_pairs"]} ordered orientation pairs for each new field,
and independently replayed {check["footprint_nodes"]} nodes across the negative certificates.</p>
</section>
<section id="reader"><h2>Read a marking and one of its certificates</h2>
<div class="figures">
<figure><figcaption>Sparse three-channel prototype</figcaption>
{svg_markings(original["polygon"], synthesis["selected_prototype_rows"])}
<p class="legend"><span class="c0">Channel 0</span> <span class="c1">Channel 1</span>
<span class="c2">Channel 2</span>. Hollow dots carry an assigned zero.
Hover over a dot for its value.</p></figure>
<figure><figcaption>Certificate footprint for \(({g},{dx},{dy})\)</figcaption>
{svg_footprint(original, example)}
<p class="legend">Green and ochre outline the two seed tiles. The violet rings are
the {len(example["footprint"])} queried points in the {nodes}-node negative tree.
The triple gives the second orientation and its lattice translation.</p></figure>
</div>
<details><summary>Read the exact queried points</summary>
<p>\({footprint_math}\)</p>
<p>The archive includes the full original search tree, its independent replay, and the footprint index.</p>
</details>
</section>
<section id="argument"><h2>Why a certified conflict is safe to prune</h2>
<p>Let \(F\) be the set of points queried by a verified negative tree, including its dead leaves.
Suppose a capacity-legal placement set contains the two seeds and saturates every point of \(F\).
At any nonterminal node reached using placements from that set, its queried point is still
unsaturated. Some unused placement from the set contributes to the point and fits the current
prefix. The verifier checks that the tree includes a child for every such legal placement.
Following one of these children at each step reaches a dead leaf, where the same argument
would give a legal placement. This is a contradiction.</p>
<p>Every full unmarked point tiling saturates all queried points. For a geometric tiling with
the allowed Turtle placements, the angular contributions around each lattice point fill one
turn, so the same saturation condition holds. The proof gives a necessary constraint on
any such plane tiling. Existence and substitution remain open.</p>
<p>For a finite target, apply an exclusion only when its translated and oriented footprint lies
in the required saturated region. Across the 263 certificates, {check["certificates_querying_outside_seed_support"]}
query a point outside their seeds' combined support. Even a point inside that support
may lie outside a specified finite target. The exported fields therefore carry a
saturation precondition. This experiment measures coverage and size. Search speed
and RL effects require separate runs.</p>
</section>
<section id="evidence"><h2>Experiment records</h2>
<p>Download the source, inputs, proof trees, exported models, run logs and verification receipts.
The manifest gives the hash of every archived file.</p>
<p><a href="{STEM}-evidence.zip">Full evidence archive</a> ·
<a href="{STEM}-manifest.json">Archive manifest</a> ·
<a href="{STEM}-results.json">Verification summary</a> ·
<a href="corona-search-v1.html#reader">Earlier unmarked corona search</a></p>
</section></main></body></html>
'''


HEAD = r'''<!doctype html>
<html lang="en">
<head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Certified Turtle failure markings</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#193830;--line:#cbd9ce;--mint:#eef6ef}
*{box-sizing:border-box}body{margin:0;background:#f6f4eb;color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1100px;padding:24px;margin:auto}header{padding:26px 0;max-width:820px}
h1{font:clamp(2.2rem,5vw,4rem)/1.08 Georgia,serif;margin:.4em 0}h2{font:1.8rem/1.15 Georgia,serif;margin:0 0 .5em}
a{color:#146052}.kicker{text-transform:uppercase;letter-spacing:.11em;font-size:.78rem}
section{background:#fffefa;border:1px solid var(--line);border-radius:12px;padding:20px;margin-bottom:18px}
.table-wrap,details{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}
td,th{text-align:left;padding:8px;border-bottom:1px solid var(--line);vertical-align:top}
.bars{max-width:640px;background:var(--mint);border-radius:8px;padding:12px}
.bar-row{display:grid;grid-template-columns:108px 1fr 40px;align-items:center;gap:8px;font-size:.86rem;padding:3px 0}
.track,.bar{height:12px;border-radius:4px}.track{background:#d3e3d8}.bar{background:#267861}
.figures{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,310px),1fr));gap:14px}
figure{margin:0;background:var(--mint);padding:12px;border-radius:8px}
figcaption,summary{font-weight:650}summary{cursor:pointer}svg{display:block;width:100%;height:250px}
.legend{font-size:.88rem}.legend span{font-weight:650;margin-right:7px}.c0{color:#176754}.c1{color:#8f4e13}.c2{color:#773983}
details{margin-top:12px}
</style></head><body><main>'''


def main():
    check = read("data/verification-v1.json")
    if check["status"] != "VERIFIED_BOTH_FIELDS_AND_ALL_USED_NEGATIVE_TREES":
        raise ValueError("Expected verified results")
    for name, expected in check["pins"].items():
        if pin(ROOT / name) != expected:
            raise ValueError(name)
    synthesis = read("data/synthesis-v1.json")
    original = read("input/input-point-model-v1.json")
    with (ROOT / "report" / (STEM+".html")).open("x") as output:
        output.write(render(synthesis, check, original))


if __name__ == "__main__":
    main()
