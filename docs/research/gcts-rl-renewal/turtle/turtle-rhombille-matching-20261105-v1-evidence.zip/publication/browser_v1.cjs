const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");
const {pathToFileURL}=require("node:url");
const {chromium}=require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main(){
  const browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless:true,args:["--disable-breakpad","--disable-background-networking"]});
  try{
    const page=await browser.newPage({viewport:{width:1240,height:900}});
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const live=Boolean(process.argv[2]);
    const local=pathToFileURL(path.join(__dirname,"..","report","turtle-rhombille-matching-20261105-v1.html"));
    const response=await page.goto(process.argv[2]||local.href,{waitUntil:"load"});
    if(live) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===8);
    const stats=await page.evaluate(()=>{
      const data=JSON.parse(document.querySelector("#view-data").textContent);
      const [canvas,radius,mode]=["patch-view","radius","mode"].map(id=>document.getElementById(id));
      let states=0,largest=0;
      for(const option of radius.options){
        radius.value=option.value;
        for(const v of ["turtle","rhombs"]){
          mode.value=v;
          mode.dispatchEvent(new Event("change"));
          const n=data.patches[radius.value].turtles;
          if(Number(canvas.dataset.shapes)!==n*(v==="rhombs"?4:1)||radius.disabled)
            throw Error("Geometry or control mismatch");
          const pixels=canvas.getContext("2d").getImageData(0,0,canvas.width,canvas.height).data;
          if(!pixels.some((x,i)=>i%4===3 && x>0)) throw Error("Blank canvas");
          largest=Math.max(largest,n);
          states++;
        }
      }
      mode.value="graph";
      mode.dispatchEvent(new Event("change"));
      if(Number(canvas.dataset.shapes)!==198 || !radius.disabled) throw Error("Matching graph mismatch");
      states++;
      mode.value="turtle";radius.value="25";mode.dispatchEvent(new Event("change"));
      return {states,largest,math:document.querySelectorAll("mjx-container").length,
        math_errors:document.querySelectorAll("mjx-merror").length};
    });
    assert.deepEqual(errors,[]);
    assert.deepEqual(stats,{states:9,largest:18224,math:8,math_errors:0});
    if(!live){
      await page.locator("#construction figure").screenshot({path:path.join(__dirname,"browser-v1.png")});
      await page.locator("#bridge .gallery").screenshot({path:path.join(__dirname,"bridge-browser-v1.png")});
    }
    await page.setViewportSize({width:390,height:844});
    const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert(fits);
    const result={status:"CHECKED_INTERACTIVE_RHOMBILLE_READER",...stats,mobile_no_overflow:fits};
    fs.writeFileSync(path.join(__dirname,live?"live-browser-v1.json":"browser-v1.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  }finally{
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
