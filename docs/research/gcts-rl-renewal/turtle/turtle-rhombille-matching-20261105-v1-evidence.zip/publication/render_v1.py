"""Render exact geometry and finite construction results for the public notebook."""

from fractions import Fraction
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from finite_construct_v1 import graph, orient
from line_words_v1 import project
from phase_owner_v1 import OwnerGeometry
from rhombille_v1 import Bridge, load, pin, prepare

STEM="turtle-rhombille-matching-20261105-v1"
OLD="turtle-threefold-clusters-20261105-v1.html"
INK="#263b34"
RED="#c77c56"
HEX="#83b8a5"
PURPLE="#8662a5"


def read(name):
    return load(name)


def write(name,text):
    with (ROOT/"report"/name).open("x") as f:
        f.write(text)


def xy(p):
    x,y=p
    return round(x+y/2,3),round(-sqrt(3)*y/2,3)


def polygon(ring, fill, stroke=INK, width=.04):
    points=" ".join(",".join(map(str,xy(p))) for p in ring)
    return f'<polygon points="{points}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"></polygon>'


def box(polys,pad=.45):
    ps=[xy(p) for poly in polys for p in poly]
    xs,ys=zip(*ps)
    return " ".join(str(round(p,3)) for p in (min(xs)-pad,min(ys)-pad,max(xs)-min(xs)+2*pad,max(ys)-min(ys)+2*pad))


def bridge_figure(bridge):
    base=bridge.base
    outline=bridge.model.polygons[0]
    allp=[outline,*base["rings"]]
    left=polygon(outline,"#ead3a1")
    right="".join(polygon(r, RED if r==base["red_rhomb"] else HEX) for r in base["rings"])
    for (a,b),label in base["colors"].items():
        x,y=xy(a)
        u,v=xy(b)
        right+=f'<line x1="{x}" y1="{y}" x2="{u}" y2="{v}" stroke="{RED if label=="red" else INK}" stroke-width=".12" stroke-linecap="round"></line>'
    return "".join(
        f'<figure><svg viewBox="{box(allp)}" role="img" aria-label="{title}">{body}</svg><figcaption>{title}</figcaption></figure>'
        for title,body in (("Original Turtle polygon",left),("Three hexagon rhombs and one red attachment",right)))


def third_figure(bridge, closure):
    figures=[]
    for i,(seed,arms) in enumerate(closure["types"],1):
        colored=[]
        for label,parts in [seed,*arms]:
            for part in parts:
                for t in part:
                    colored.append((bridge.model.poly(tuple(t)), PURPLE if label=="single triple" else HEX))
        figures.append(f'<figure><svg viewBox="{box([p for p,_ in colored])}" role="img" aria-label="Attachment shape {i}">'
                       +"".join(polygon(p,c,width=.11) for p,c in colored)+f'</svg><figcaption>Attachment shape {i}</figcaption></figure>')
    return "".join(figures)


def canvas_data(geometry,construct):
    bridge=geometry.bridge
    items={}
    for row in construct["runs"]:
        n=row["radius"]
        p=read(f"data/constructed-{n}-v1.json")
        items[str(n)]=dict(poses=p["placement"],turtles=row["turtles"],target=row["covered_rhombs"])
    n=10
    vertices,edges,incident=graph(geometry,n,list(map(Fraction,("1/5","1/5","-2/5"))))
    matches,roots=orient(vertices,edges,incident,n)
    coords={v:project(geometry.anchor,v) for v in vertices}
    oriented=[(coords[next(p for p in edges[e] if p!=child)],coords[child]) for child,e in sorted(matches.items())]
    return dict(patches=items, groups=bridge.model.groups, signs=geometry.signs,
                outline=bridge.model.polygons[0], rhombs=bridge.base["rings"], red=bridge.base["red_rhomb"],
                graph=dict(edges=oriented,roots=[coords[p] for p in roots]))


STYLE="""
*{box-sizing:border-box} body{margin:0;background:#f5f5ef;color:#203832;font-family:system-ui,-apple-system,sans-serif;line-height:1.55}
main{max-width:1100px;margin:auto;padding:2rem clamp(1rem,4vw,3.5rem) 4rem}
header{padding:1.5rem 0 1rem;border-bottom:1px solid #b9cbc1} h1,h2,h3{font-family:Georgia,serif;line-height:1.08}
h1{font-size:clamp(2.4rem,7vw,4.6rem);max-width:17ch;margin:.18em 0} h2{font-size:clamp(1.7rem,4vw,2.55rem)}
.eyebrow{font-weight:750;letter-spacing:.09em;text-transform:uppercase;font-size:.78rem} p{max-width:78ch}
a{color:#18584b} nav ul{display:flex;flex-wrap:wrap;list-style:none;padding:0;gap:.55rem 1.4rem} section{margin-top:2.55rem}
.frame{background:#fffefa;border:1px solid #c7d3ca;border-radius:1rem;padding:clamp(.65rem,2vw,1.15rem)}
.gallery{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem} figure{margin:0} figcaption{font-size:.91rem;padding-top:.55rem}
svg{width:100%;height:clamp(140px,24vw,270px);background:#f7f8f1;border-radius:.45rem} canvas{display:block;width:100%;height:auto;
background:#f9faf4;border-radius:.55rem} .controls{display:flex;flex-wrap:wrap;gap:.65rem 1.25rem;margin:0 0 1rem}
.controls label{display:grid;gap:.2rem;font-size:.88rem;font-weight:650} select{color:inherit;background:#fff;border:1px solid #91a49a;
border-radius:.35rem;font:inherit;padding:.4rem;max-width:100%}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;
font-variant-numeric:tabular-nums}th,td{padding:.62rem .75rem;border-bottom:1px solid #c7d3ca;text-align:left}thead th{background:#e3eee5}
.callout{border-left:4px solid #2b7a68;background:#e5efe7;padding:.25rem 1rem} code{font-size:.87em;overflow-wrap:anywhere}
pre{padding:.8rem;background:#eaf0e8;overflow:auto;border-radius:.35rem} pre code{overflow-wrap:normal}
@media(max-width:540px){main{padding-top:.8rem}.gallery{gap:.55rem}th,td{font-size:.86rem;padding:.45rem}.controls label{flex:1 1 40%}}
"""


JS=r"""
const data=JSON.parse(document.getElementById("view-data").textContent);
const canvas=document.getElementById("patch-view");
const ctx=canvas.getContext("2d");
const radius=document.getElementById("radius"), mode=document.getElementById("mode");
const notice=document.getElementById("drawing-status");
const projection=([x,y])=>[x+y/2,-Math.sqrt(3)*y/2];
function vertex([g,x,y],[u,v]){
  const [[a,b],[c,d]]=data.groups[g];
  return projection([x+a*u+b*v,y+c*u+d*v]);
}
function transform(polys){
  let left=Infinity,right=-Infinity,top=Infinity,bottom=-Infinity;
  for(const shape of polys) for(const [x,y] of shape){
    left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);
  }
  const scale=Math.min((canvas.width-40)/(right-left),(canvas.height-40)/(bottom-top));
  ctx.resetTransform();
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.translate(canvas.width/2,canvas.height/2);
  ctx.scale(scale,scale);
  ctx.translate(-(left+right)/2,-(top+bottom)/2);
  return scale;
}
function drawPolygon(points,fill,width){
  ctx.beginPath();ctx.moveTo(...points[0]);
  points.slice(1).forEach(p=>ctx.lineTo(...p));
  ctx.closePath();ctx.fillStyle=fill;ctx.fill();
  if(width>0){ctx.strokeStyle="#344e43";ctx.lineWidth=width;ctx.stroke();}
}
function render(){
  const selected=data.patches[radius.value];
  if(mode.value==="graph"){
    radius.disabled=true;
    const links=data.graph.edges.map(e=>e.map(projection));
    const roots=data.graph.roots.map(projection);
    const scale=transform([...links,roots]);
    ctx.strokeStyle="#529782";ctx.lineWidth=1.5/scale;ctx.fillStyle="#2b5f50";
    for(const [a,b] of links){
      ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke();
      ctx.beginPath();ctx.arc(...b,2/scale,0,2*Math.PI);ctx.fill();
    }
    ctx.fillStyle="#ba633e";
    for(const root of roots){ctx.beginPath();ctx.arc(...root,4.5/scale,0,2*Math.PI);ctx.fill();}
    notice.textContent=`Matching forest at radius 10 with ${links.length} red attachments and ${roots.length} boundary roots (orange).`;
    canvas.dataset.shapes=links.length;
    return;
  }
  radius.disabled=false;
  const outlines=selected.poses.map(p=>data.outline.map(q=>vertex(p,q)));
  const scale=transform(outlines);
  const width=scale>1?.65/scale:.32/scale;
  if(mode.value==="turtle"){
    outlines.forEach((poly,i)=>drawPolygon(poly,data.signs[selected.poses[i][0]]<0?"#c77c56":"#b2d1bb",width));
    canvas.dataset.shapes=outlines.length;
  }else{
    for(const pose of selected.poses)
      for(const ring of data.rhombs)
        drawPolygon(ring.map(q=>vertex(pose,q)),JSON.stringify(ring)===JSON.stringify(data.red)?"#c77c56":"#83b8a5",width);
    canvas.dataset.shapes=4*outlines.length;
  }
  notice.textContent=`${selected.turtles.toLocaleString()} Turtles covering a target of ${selected.target.toLocaleString()} whole rhombs. The construction extends into a guard around the target.`;
}
radius.addEventListener("change",render);mode.addEventListener("change",render);render();
"""


def table(rows,headers):
    head="".join(f"<th>{escape(s)}</th>" for s in headers)
    body="".join("<tr>"+"".join(f"<td>{escape(str(s))}</td>" for s in r)+"</tr>" for r in rows)
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def render(summary,data,bridge,closure):
    construct=summary["construct"]
    stats=table([[r["radius"],r["target_radius"],f'{r["turtles"]:,}',f'{r["covered_rhombs"]:,}',r["tree_roots"],f'{r["seconds"]:.3f}']
                 for r in construct["runs"]],
                ["Search radius","Target radius","Turtle placements","Covered rhombs","Boundary roots","Seconds"])
    comparison=[]
    for key in ("original","deeper"):
        s=summary["line"]["banks"][key]
        good=sum(n for _,state,n in s["colors"] if state=="matched")
        missing=sum(n for _,state,n in s["colors"] if state=="unresolved")
        comparison.append(["Depth eight" if key=="original" else "Depth ten",s["line_words"],f"{good:,}",missing,
                           s["gaps"]["3"],s["gaps"]["4"]])
    lines=table(comparison,["Patch bank","Words","Rhomb colors matched","Unresolved","Gaps of 3","Gaps of 4"])
    synth=table([[r["radius"],r["variables"],r["demands"],r["status"]] for r in summary["attachment"]],
                ["Word radius","Choice variables","Hexagon demands","Result"])
    payload=json.dumps(data,separators=(",",":"),ensure_ascii=True).replace("<",r"\u003c")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Constructing large Turtle regions through Rhombille matching</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · Turtle · November 2026</p>
<h1>Constructing large Turtle regions through Rhombille matching</h1>
<p>From exact \(A_2\) coordinates, recover a marked rhomb grid, assign its red rhombs to hexagons and turn those matches back into ordinary Turtle placements. The largest checked run uses <strong>18,224 Turtles</strong> and covers <strong>83,799 whole target rhombs</strong>.</p>
<nav aria-label="On this page"><ul><li><a href="#construction">Explore the construction</a></li><li><a href="#bridge">Exact bridge</a></li><li><a href="#phase">Words and phases</a></li><li><a href="#matching">Matching proof obligations</a></li><li><a href="#clusters">Third-layer clusters</a></li><li><a href="#evidence">Evidence</a></li></ul></nav></header>
<section id="construction"><h2>Build from the boundary</h2>
<p>Choose a finite window and switch between literal polygons and their four-rhomb footprints. In the matching view, each orange boundary root supplies an orientation for its tree. Each of the other hexagons receives exactly one red rhomb from its parent edge.</p>
<figure class="frame"><div class="controls">
<label>Search radius<select id="radius"><option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option></select></label>
<label>Geometry<select id="mode"><option value="turtle">Turtle polygons</option><option value="rhombs">Rhombille footprints</option><option value="graph">Matching forest at radius 10</option></select></label>
</div><canvas id="patch-view" width="1000" height="640" role="img" aria-label="Exact finite Turtle construction with selectable geometry"></canvas>
<figcaption id="drawing-status" aria-live="polite"></figcaption></figure>
{stats}
<p>Radii bound the three integer cube coordinates. The target uses a four-unit guard inside the search window. Every placement is assembled from 20 exact triangular wedges, and the checker verifies both disjointness and coverage of all four wedges in every target rhomb. Timings are single wall-clock runs on this machine and include the geometry check.</p></section>
<section id="bridge"><h2>Recover the marks from the polygon</h2>
<div class="frame gallery">{bridge_figure(bridge)}</div>
<p>James Smith's dual Turtle suggests looking for four congruent rhombs with two inward boundary edges. Seven vertices of the original polygon share one parity class. Completing their straight boundary at the only missing corner gives one four-rhomb footprint under these constraints. Testing its 28 edge colorings recovers one that reconstructs the exact Turtle polygon. <a href="https://arxiv.org/html/2403.01911v1#S2">Turtles, Hats and Spectres</a></p>
<p>Every occupied rhomb retains at least three of its four wedges, so two Turtles claiming the same rhomb would overlap. Every boundary wedge faces a unique neighboring rhomb. Opposite colors on an occupied seam put the wedge in the right tile. Around a hole the four neighbors contribute its four wedges.</p>
<p>All 114 neighbor roles in the necessary shell inventory preserve the grid phase. Across 25 exact patches, the bridge checks 7,978 Turtle placements, 31,912 occupied rhombs and 14,898 occupied seams. Every checked seam between distinct Turtles has opposite colors.</p></section>
<section id="phase"><h2>Decode three line words</h2>
<p>Use the two adjacent cube layers with coordinate sums \(-2\) and \(-1\). A Turtle's hexagon writes the same bit on each of the three coordinate lines through its center. Its handedness gives the bit. A rhomb sees the two coordinates shared by its adjacent cubes. Equal bits give a hexagon rhomb. The order of unequal bits distinguishes a red rhomb from a hole, with the order reversed under reflection.</p>
{lines}
<p>These 75 finite line words have gaps of length 3 or 4 between consecutive ones. Among primitive two-letter substitutions with images of length at most two, the Fibonacci rule \(S\mapsto L,\;L\mapsto LS\) and its reversal each fit 37 of the 60 original gap words and 11 of the 15 deeper words. The original words collectively fail to admit one common mechanical slope. Their color agreement survives this test failure.</p>
<h3>An exact model for generating new patches</h3>
<p>Use the Fibonacci candidate's slope \(\alpha=(5-\sqrt{{5}})/10\) and letters \(b_i(n)=\lfloor(n+1)\alpha+\beta_i\rfloor-\lfloor n\alpha+\beta_i\rfloor\). The intercepts are nonintegral rationals with sum zero. A cube's integer band is \(k=\sum_i\{{n_i\alpha+\beta_i\}}-\alpha\sum_i n_i\), where braces denote fractional part.</p>
<p>Select every all-one cube center. Select an all-zero center in the lower layer only in band 2, or in the upper layer only in band 1. The checker enumerates all 288 local phase cases using exact arithmetic in \(\mathbb{{Q}}(\sqrt{{5}})\). It verifies unique hexagon ownership, opposite colors across seams and two possible hexagon owners for each red rhomb. Selecting every uniform center gave ownership failures.</p></section>
<section id="matching"><h2>Where the plane proof stops</h2>
<p>The red-rhomb graph has one vertex per selected hexagon and one edge per red rhomb. The tested finite windows produce trees that reach their boundary. Orient each tree away from a boundary root to choose the attachment at every other vertex. The guard excludes those unmatched roots from the coverage target.</p>
{synth}
<p>The table tests one attachment choice for each finite phase signature. All six bounded rules are inconsistent. The tree procedure uses the full connected component and bypasses those bounded signatures.</p>
<div class="callout"><p><strong>Remaining global step.</strong> To obtain a plane tiling from this particular coloring, it would suffice to prove that every connected component of the infinite red-rhomb graph is an infinite tree or has exactly one cycle. Orient a tree away from a chosen end, or a unicyclic component away from its consistently oriented cycle. The four finite checks do not establish that graph property.</p></div></section>
<section id="clusters"><h2>What happened to the third layer?</h2>
<div class="frame gallery">{third_figure(bridge,closure)}</div>
<p>The earlier grouping approach yields two exact patterns that join a triple of single tiles to three four-tile cores. They transfer across both patch banks and give 27 checked contractions. A finite shell certificate excludes their only geometry-compatible shared-core case. The new rhomb route gives a separate way to construct large regions while the cluster approach still needs a recursive boundary rule. <a href="{OLD}">Earlier threefold-cluster notebook</a></p></section>
<section id="evidence"><h2>Replay the results</h2>
<p>The archive contains the exact placements, matching checks, finite phase cases and source. The rhomb footprint and inward-edge count came from the published dual construction. The geometric edge search, gap-rule screen, phase selection and finite tree construction are recorded separately.</p>
<ul><li><a href="{STEM}-results.json">Machine-readable summary</a></li><li><a href="{STEM}-evidence.zip">Full evidence archive</a></li><li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li></ul>
<pre><code>python3.12 -I -S -B source/rhombille_v1.py
python3.12 -I -S -B source/line_words_v1.py
python3.12 -I -S -B source/mechanical_v1.py
python3.12 -I -S -B source/phase_owner_v1.py
python3.12 -I -S -B source/attachment_solver_v1.py
python3.12 -I -S -B source/matching_graph_v1.py
python3.12 -I -S -B source/finite_construct_v1.py</code></pre>
<p>The protocols pin the exact Python executable used for this run. The archive already includes its output files.</p></section></main>
<script id="view-data" type="application/json">{payload}</script><script>{JS}</script></body></html>
"""


def main():
    summary=dict(status="CHECKED_RHOMBILLE_MATCHING_REPORT",bridge=read("data/bridge-summary-v1.json"),
                 line=read("data/line-summary-v1.json"),phase=read("data/phase-owner-v1.json"),
                 attachment=[r["summary"] for r in read("data/attachment-v1.json")["runs"]],
                 graph=[r["summary"] for r in read("data/matching-graph-v1.json")["rows"]],
                 construct=read("data/construct-summary-v1.json"),
                 clusters=read("input/third-atlas-summary-v1.json"))
    assert summary["construct"]["runs"][-1]["turtles"]==18224
    assert summary["phase"]["trials"][0]["failures"]=={}
    assert all(r["status"]=="UNSAT" for r in summary["attachment"])
    engine,_=prepare()
    bridge=Bridge(engine)
    geometry=OwnerGeometry(bridge)
    data=canvas_data(geometry,summary["construct"])
    write(STEM+".html",render(summary,data,bridge,read("input/core-arm-closure-v1.json")))
    write(STEM+"-results.json",json.dumps(summary,indent=2,sort_keys=True)+"\n")


if __name__=="__main__":
    main()
