"""Probe the sole surviving second-layer collision at larger shell depths."""

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from extend_v1 import Collar, Study, decode, load, pin, prepare, save


def main():
    protocol = load("conflict-protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/n) == value for n, value in protocol["pins"].items())
    results = load("data/extension-results-v1.json")
    engine, _ = prepare()
    active = set(load("input/closure-results-v1.json")["rounds"][-1]["active"])
    rule = next(r for r in results if r["rule"] == 1)
    (case,) = [c for r in rule["kinds"] if r["kind"] == "pair" for c in r["cases"]
              if "/" in c["case"] and c["checks"][-1]["status"] == "LOCAL_WITNESS"]
    study = Study(engine, active, 0, (6, 0, 0))
    shapes = decode(case["poses"])
    checks = []
    for depth in protocol["depths"]:
        collar = Collar(study, "pair", shapes, depth)
        result = collar.run(protocol["node_limit"])
        if result["status"] == "LOCAL_WITNESS":
            collar.verify_witness(result["witness"])
            assigned = dict(result["witness"])
            _, patch, _ = collar.state(assigned)
            assert all(study.neighbors(p)&patch == engine.links(j, p).keys()
                       for p, j in assigned.items())
            result.update(assigned=len(assigned), tiles=len(patch), placement_set=sorted(patch))
        elif result["status"] == "EXCLUDED":
            collar.verify(result["tree"], {})
        checks.append(dict(depth=depth, **result))
        print(json.dumps({k: v for k, v in checks[-1].items()
                          if k not in ("witness", "placement_set", "tree")}), flush=True)
        if result["status"] != "LOCAL_WITNESS":
            break
    save("data/conflict-v1.json", dict(rule=1, kind="pair", case=case["case"],
                                      poses=shapes, checks=checks))


if __name__ == "__main__":
    main()
