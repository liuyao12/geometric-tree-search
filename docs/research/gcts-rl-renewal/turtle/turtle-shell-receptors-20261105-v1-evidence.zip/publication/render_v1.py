"""Audit the Turtle shell campaign and render its finite growth reader."""

import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
STEM="turtle-shell-receptors-20261105-v1"
OLD="turtle-exposed-corner-proof-20261105-v1.html"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def audit():
    base=ROOT/"input"
    names=("cuts","learning","first","second","grammar","actions","compound","closure")
    data={}
    for name in names:
        root=base/name
        protocol=read(root/"protocol-v1.json")
        assert all(pin(root/p)==ref for p,ref in protocol["pins"].items())
        assert not (root/"data/execution.stderr.log").read_bytes()
        data[name]=read(root/"data/summary-v1.json")
    assert data["first"]["shells"]==242
    assert data["first"]["extension_screen"]["NO_GAP"]==50
    assert data["second"]["counts"]["POSITIVE"]==37
    assert len(data["grammar"]["retained"])==25
    assert data["grammar"]["interface_candidates"]=={"NEGATIVE":70,"POSITIVE":222}
    assert data["actions"]["updates"]==42
    assert set(data["compound"]["arms"])=={"FROZEN_RL","HEURISTIC","RANDOM"}
    assert len(data["closure"]["retained"])==20
    assert data["closure"]["complete_local_collars"]==66
    assert data["cuts"]["cuts"]==192 and data["cuts"]["false_cuts"]==0
    sys.path.insert(0,str(base/"closure/source"))
    from actions_v1 import prepare
    from compound_v1 import graph, polarity, quotient
    engine,_=prepare()
    signs,special,checked=polarity(engine)
    assert checked==222 and special==data["compound"]["special"]
    closure=read(base/"closure/data/results-v1.json")
    assert len(closure["deep_replays"])==18
    assert all(r["checked"]["status"]=="VERIFIED" for r in closure["deep_replays"])
    assert sum(r["checked"]["nodes"] for r in closure["deep_replays"])==1064
    final=closure["rounds"][-1]
    assert final["active"]==data["closure"]["retained"] and not final["removed"]
    assert all(r["checked"]["status"]=="VERIFIED" for r in final["records"])
    row=next(r for r in final["records"] if r["root"]==special)
    check=engine.verify_positive(special,8,[(tuple(p),j) for p,j in row["raw"]["witness"]])
    assert json.loads(json.dumps(check))==row["checked"]
    witness={tuple(p):j for p,j in row["raw"]["witness"]}
    primitives=list(map(tuple,check["placement_set"]))
    adjacent,levels=graph(engine,set(primitives))
    keys={p:i for i,p in enumerate(primitives)}
    roles=engine.grammar.roles[special]
    compounds=[quotient(engine,witness,adjacent,levels,8,special,role)["pairs"] for role in roles]
    tiles=[dict(poly=engine.model.poly(p),level=levels[p],assigned=p in witness,
                special=witness.get(p)==special,centre=p==(0,0,0)) for p in primitives]
    gallery=dict(tiles=tiles,pairs=[[(keys[a],keys[b]) for a,b in options] for options in compounds])
    return dict(status="CHECKED_TURTLE_SHELL_PROGRESS_REPORT",**data,viewer_tiles=len(tiles)),gallery


def table(head,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{h}</th>' for h in head)+(
        '</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{v}</td>' for v in row)+'</tr>' for row in rows)+
        '</tbody></table></div>')


VIEWER=r"""
const data=JSON.parse(document.getElementById("patch-data").textContent);
const graph=document.getElementById("patch-view");
const depth=document.getElementById("depth");
const role=document.getElementById("role");
const ns="http://www.w3.org/2000/svg";
const draw=([x,y])=>[x+y/2,-y*Math.sqrt(3)/2];
const points=data.tiles.map(tile=>tile.poly.map(draw));
function svg(tag,attrs) {
  const item=document.createElementNS(ns,tag);
  Object.entries(attrs).forEach(([key,value])=>item.setAttribute(key,value));
  graph.append(item);
}
function middle(poly) {
  return [0,1].map(i=>poly.reduce((s,p)=>s+p[i],0)/poly.length);
}
function render() {
  graph.replaceChildren();
  const shown=Number(depth.value),selected=Number(role.value);
  const visible=data.tiles.map(t=>t.level<=shown+1);
  const bounds=points.filter((_,i)=>visible[i]).flat();
  const xs=bounds.map(p=>p[0]),ys=bounds.map(p=>p[1]);
  const pad=3;
  graph.setAttribute("viewBox",[Math.min(...xs)-pad,Math.min(...ys)-pad,
    Math.max(...xs)-Math.min(...xs)+2*pad,Math.max(...ys)-Math.min(...ys)+2*pad].join(" "));
  const colours=["#65b5a2","#82c9bf","#acd9cf","#b7d9e6","#c6deed","#d1e2f3","#d7ddf0","#ddd7ee","#e2d3ed"];
  for (const [i,t] of data.tiles.entries()) {
    if (!visible[i]) continue;
    const halo=t.level>shown;
    const fill=halo?"#eef2f3":t.special?"#e9ad73":colours[t.level];
    svg("polygon",{points:points[i].map(p=>p.join(",")).join(" "),fill,
      stroke:t.centre?"#352171":"#4c6870","stroke-width":t.centre?".5":".13"});
  }
  let pairs=0;
  for (const [a,b] of data.pairs[selected]||[]) {
    if (data.tiles[a].level>shown || !visible[b]) continue;
    const [x1,y1]=middle(points[a]),[x2,y2]=middle(points[b]);
    svg("line",{x1,y1,x2,y2,stroke:"#744127","stroke-width":".36","stroke-linecap":"round"});
    pairs++;
  }
  document.getElementById("patch-count").textContent=
    visible.filter(Boolean).length+" displayed tiles, "+pairs+" visible pair assignments";
}
depth.addEventListener("change",render);
role.addEventListener("change",render);
render();
"""


def render(data,gallery):
    shallow=data["actions"]["methods"]
    deep=data["compound"]["arms"]
    methods=[]
    for label,mode in [("Exact heuristic","HEURISTIC"),("Seeded random order","RANDOM"),("Frozen learned order","FROZEN_RL")]:
        a,b=shallow[mode],deep[mode]
        methods.append((label,a["status"]["POSITIVE"],f'{a["visits"]:,}',b["status"]["POSITIVE"],
                        f'{b["visits"]:,}',f'{b["seconds"]:.2f}'))
    performance=table(("Action ordering","Shallow witnesses","Shallow visits","Deeper witnesses","Deeper visits","Deeper wall seconds"),methods)
    degrees=data["closure"]["exact_degree_distributions"]
    compounds=table(("Partner role","Degree 4","Degree 5","Degree 6","Degree 7"),
                    [(i+1,*(r.get(str(d),0) for d in (4,5,6,7))) for i,r in enumerate(degrees)])
    payload=json.dumps(gallery,separators=(",",":")).replace("<","\\u003c")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Turtle shell receptors and whole-shell search</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{{font-family:system-ui,sans-serif;color:#163440;background:#eaf0f2}}body{{margin:0}}
main{{max-width:65rem;margin:auto;padding:2.4rem clamp(1rem,4vw,2.65rem) 4rem;background:white}}
h1,h2{{line-height:1.17}}h1{{font-size:clamp(2.3rem,6vw,3.6rem);letter-spacing:-.04em;margin:.35em 0}}
h2{{margin-top:2.15rem}}p,li{{line-height:1.55}}nav{{display:flex;gap:1rem;flex-wrap:wrap;margin:1.3rem 0 1.9rem}}
a{{color:#075d79}}.meta{{color:#536873}}.scroll{{overflow:auto}}table{{border-collapse:collapse;width:100%;text-align:left}}
td,th{{padding:.6rem;border-bottom:1px solid #d0dfe0}}th{{background:#edf3f3}}
.flow{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,8rem),1fr));gap:.7rem;padding:0;list-style:none}}
.flow li{{padding:.65rem;background:#e4f2ef;border-radius:.4rem}}.flow strong{{display:block;font-size:1.4rem}}
.viewer{{display:grid;grid-template-columns:minmax(0,3fr) minmax(min(100%,12rem),1fr);gap:1rem;align-items:center}}
svg{{width:100%;height:clamp(16rem,57vw,30rem);display:block;background:#f3f7f8;border:1px solid #c0d4d8;border-radius:.4rem}}
select{{padding:.45rem;max-width:100%;display:block;margin:.28rem 0 .8rem}}
@media(max-width:45rem){{.viewer{{grid-template-columns:1fr}}}}
</style></head><body><main>
<p class="meta">Geometric tree search · Turtle experiments · November 5, 2026</p>
<h1>Turtle shell receptors and whole-shell search</h1>
<p>Starting from exact primitive contacts, the search learned a small inventory of clusters and used them as actions. Finite contradictions reduce the possible first shells to 20. The remaining inventory admits checked patches through eight contact steps.</p>
<nav aria-label="Sections"><a href="#inventory">Shell inventory</a><a href="#growth">Patch reader</a><a href="#pairing">Pairing</a><a href="#learning">Search comparison</a><a href="#bounds">Movable boundary</a><a href="#evidence">Evidence</a></nav>
<section id="inventory"><h2>What must fit at a receptor</h2>
<p>A first shell contains a central Turtle and every tile that shares a positive-length edge segment with it. A receptor is one particular neighboring placement in the central tile's frame. Its domain consists of shell types that can be placed there while remaining consistent with the other surrounding shells.</p>
<ul class="flow"><li><strong>242</strong> exact first shells</li><li><strong>50</strong> all exposed segments individually supported</li>
<li><strong>37</strong> a simultaneous second ring exists</li><li><strong>25</strong> joint shell assignment survives iteration</li>
<li><strong>20</strong> survive the deeper finite check</li></ul>
<p>The earlier finite-patch campaign supplied 10 recurrent shell shapes from distinct training regions. A separate exact catalogue exhausts the full perimeter using 82 legal rooted edge contacts. Of the 50 shells with an individually supported boundary, 13 have no simultaneous second ring. Checking whole shells at adjacent receptors removes 12 more types. An independent replay of 18 deeper failed searches verifies five further exclusions. Each removal is necessary for any plane tiling in the lattice model because every tile would need a compatible surrounding shell.</p>
<p>The joint collar test verified 222 directed receptor choices on the 25-type inventory. A larger action adds all members of a neighboring shell in one step. Identical primitive placements are shared. Distinct placements must be disjoint. The positive checker rebuilds the contact graph from the complete rooted catalogue and verifies that every tile within the requested contact distance has its entire first shell.</p></section>
<section id="growth"><h2>Inspect a checked growth patch</h2>
<div class="viewer"><svg id="patch-view" role="img" aria-label="Turtle patch with exact contact layers and optional compound pairings" viewBox="-1 -1 2 2"></svg><div>
<label for="depth">Contact distance</label><select id="depth"><option>0</option><option>1</option><option>2</option><option>4</option><option>6</option><option selected>8</option></select>
<label for="role">Pairing overlay</label><select id="role"><option value="-1">Hide pairing</option><option value="0">Role 1</option><option value="1">Role 2</option><option value="2" selected>Role 3</option><option value="3">Role 4</option></select>
<p id="patch-count" aria-live="polite"></p><p>Shading follows contact distance. The pale outer ring supplies neighbors to the last displayed layer. Orange marks a tile of the special shell type. A brown segment links the members of a compound.</p></div></div>
<p>Each view crops the same independently checked patch. In this model a larger cluster can add tiles through its receptors and change its boundary at each layer.</p></section>
<section id="pairing"><h2>Four rules for forming two-tile compounds</h2>
<p>One shell has four opposite-hand neighbors. Each other shell has at most one. For all 222 admitted directed receptor choices, the determinant of the relative point action agrees with the product of the two shell types' handedness labels. Therefore the product of a tile's absolute handedness and its shell label is constant on every connected component of a compatible tiling.</p>
<p>Choose any one of the special shell's four roles. A special tile can pair with the neighbor at that role, and no ordinary tile can be chosen twice because its shell contains at most one opposite-hand neighbor. The checker exhausted all 66 joint local collars in the reduced inventory. The table counts the number of distinct positive-length neighbors of the resulting compound at the central tile. A contact of length zero contributes no edge.</p>
{compounds}
<p>Roles 3 and 4 reduce the observed degrees to five and six across the exact local inventory. These are finite interface constraints. The constructive step still needed is a replacement rule that preserves the compatible interfaces at the next level.</p></section>
<section id="learning"><h2>Does learning improve search?</h2>
<p>Training updated a six-feature policy on 16 shell roots. The nine other roots supplied no updates. All methods used the same frontier rule, geometry and bounds. They differed only in the order in which they tried whole-shell actions. Shallow depths were three and four. The deeper test used six and eight.</p>
{performance}
<p>Each arm had 18 tasks at each depth pair. On the deeper tasks, the other four cases per arm exhausted their search. The independent checker replayed their trees, along with the other negative root cases. The learned order used fewer visits on this sample, while the exact heuristic had the shorter wall time. These are single paired runs.</p></section>
<section id="bounds"><h2>Moving a boundary can disable a cut</h2>
<p>Each of the 192 corner contradictions gives a finite required set \(Q\) and excluded set \(E\). A movable envelope is impossible if its mandatory region contains \(Q\) and its permitted region avoids \(E\). The checker uses those two sets and the exact branch list. It needs no description of the rest of the boundary.</p>
<p>The cuts rejected 24 of 24 new convex envelopes at margin zero and again at the first positive margin. They rejected eight at the second margin. The 128 tileable control patches triggered zero cuts. Margins are measured in the integer primitive-normal sample coordinates. A missed cut leaves the case open.</p></section>
<section id="evidence"><h2>Evidence</h2><ul>
<li><a href="{STEM}-results.json">Machine-readable results</a></li>
<li><a href="{STEM}-evidence.zip">Full sources, inputs, logs and checked witnesses</a></li>
<li><a href="{STEM}-manifest.json">Archive file hashes</a></li>
<li><a href="{OLD}">Exposed-corner proof and certificates</a></li>
</ul></section></main>
<script id="patch-data" type="application/json">{payload}</script>
<script>{VIEWER}</script></body></html>"""


def main():
    data,gallery=audit()
    with (ROOT/"report"/(STEM+".html")).open("x") as stream:
        stream.write(render(data,gallery))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as stream:
        json.dump(data,stream,indent=2,sort_keys=True)
        stream.write("\n")
    print(json.dumps(dict(status=data["status"],tiles=data["viewer_tiles"]),sort_keys=True))


if __name__=="__main__":
    main()
