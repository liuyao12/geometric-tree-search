const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { chromium } = require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main() {
  const browser = await chromium.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: true,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1260, height: 900 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname,"..","report","turtle-shell-receptors-20261105-v1.html"));
    const url = process.argv[2] || local.href;
    const response = await page.goto(url, { waitUntil: "load" });
    if (process.argv[2]) assert.equal(response.status(),200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length === 4);
    const evidence = await page.evaluate(() => {
      const data = JSON.parse(document.getElementById("patch-data").textContent);
      const depth = document.getElementById("depth");
      const role = document.getElementById("role");
      const svg = document.getElementById("patch-view");
      let states=0;
      for (const d of depth.options) {
        depth.value=d.value;
        depth.dispatchEvent(new Event("change"));
        for (const r of role.options) {
          role.value=r.value;
          role.dispatchEvent(new Event("change"));
          const expected=data.tiles.filter(t=>t.level<=Number(d.value)+1).length;
          const links=(data.pairs[Number(r.value)]||[]).filter(([a,b])=>
              data.tiles[a].level<=Number(d.value)&&data.tiles[b].level<=Number(d.value)+1).length;
          if (svg.querySelectorAll("polygon").length!==expected) throw new Error("Wrong displayed ring size");
          if (svg.querySelectorAll("line").length!==links) throw new Error("Wrong overlay size");
          states++;
        }
      }
      return { states,tiles:data.tiles.length,math:document.querySelectorAll("mjx-container").length };
    });
    assert.deepEqual(errors, []);
    assert.equal(evidence.states,30);
    assert.equal(evidence.tiles,271);
    await page.selectOption("#depth","8");
    await page.selectOption("#role","2");
    if (!process.argv[2]) {
      await page.locator("#growth").screenshot({path:path.join(__dirname,"browser-v1.png")});
    }
    await page.setViewportSize({ width:390, height:844 });
    const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert.equal(fits,true);
    const result={status:"CHECKED_INTERACTIVE_SHELL_READER", ...evidence, mobile_no_overflow:fits};
    const name=process.argv[2]?"live-browser-v1.json":"browser-v1.json";
    fs.writeFileSync(path.join(__dirname,name),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
