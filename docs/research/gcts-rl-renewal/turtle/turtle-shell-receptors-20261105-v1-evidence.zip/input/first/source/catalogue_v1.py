"""Enumerate all geometric first shells and screen their exposed receptors."""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, edges, load, pin, save, shared_edge
from shell_v1 import boundary, collinear, cover_intervals, extract, unpack


def rooted_contacts(model, catalog):
    assert catalog["status"]=="COMPLETE" and catalog["catalogue"]["complete"]
    assert catalog["counts"]["occupancy_mismatches"]==0
    root=model.poly((0,0,0))
    return sorted((r["group"],*r["translation"]) for r in catalog["pairs"]
                  if not r["geometry_overlap"] and shared_edge(root,model.poly((r["group"],*r["translation"]))))


def interval_masks(root,polygons):
    masks = [0]*len(polygons)
    count = 0
    for a,b in edges(root):
        axis = 0 if a[0]!=b[0] else 1
        start,end = sorted((a[axis],b[axis]))
        endpoints = {start,end}
        records=[]
        for i,poly in enumerate(polygons):
            for c,d in edges(poly):
                if collinear(a,b,c) and collinear(a,b,d):
                    x,y=sorted((c[axis],d[axis]))
                    lo,hi=max(start,x),min(end,y)
                    if lo<hi:
                        records.append((i,lo,hi))
                        endpoints.update((lo,hi))
        points=sorted(endpoints)
        for x,y in zip(points,points[1:]):
            for i,lo,hi in records:
                if lo<=x<y<=hi:
                    masks[i] |= 1<<count
            count+=1
    assert all(masks)
    return masks,count


def enumerate_shells(masks, conflicts, width, limits, shortest):
    by_cell = [tuple(i for i,m in enumerate(masks) if (m>>q)&1) for q in range(width)]
    results=set()
    visits=0
    start=time.perf_counter()

    def visit(missing,selected,blocked):
        nonlocal visits
        if visits>=limits["visits"] or time.perf_counter()-start>=limits["seconds"]:
            return False
        visits+=1
        if not missing:
            key=tuple(sorted(selected))
            assert key not in results
            results.add(key)
            return True
        if shortest:
            choices=min(([i for i in by_cell[q] if not (blocked>>i)&1]
                         for q in range(width) if (missing>>q)&1),key=len)
        else:
            q=(missing&-missing).bit_length()-1
            choices=[i for i in by_cell[q] if not (blocked>>i)&1]
        for i in choices:
            assert masks[i]&missing==masks[i]
            if not visit(missing^masks[i],(*selected,i),blocked|conflicts[i]):
                return False
        return True

    complete=visit((1<<width)-1,(),0)
    return results,dict(status="EXHAUSTED" if complete else "BOUNDED",
                        visits=visits,shells=len(results),seconds=time.perf_counter()-start)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    source=load("input/exact-point-model-v1.json")
    model=Model(source)
    catalog=unpack(ROOT/"input/contact-catalogue-v1.json.gz")
    assert catalog["model"]==source
    contacts=rooted_contacts(model,catalog)
    assert len(contacts)==len(set(contacts))==82
    root=(0,0,0)
    root_support=set(model.support(root))
    supports=[set(model.support(p)) for p in contacts]
    assert all(s.isdisjoint(root_support) for s in supports)
    masks,width=interval_masks(model.poly(root),[model.poly(p) for p in contacts])
    conflicts=[]
    for mask,support in zip(masks,supports,strict=True):
        conflicts.append(sum(1<<j for j,(m,s) in enumerate(zip(masks,supports,strict=True))
                             if m&mask or s&support))
    found,first=enumerate_shells(masks,conflicts,width,protocol["limits"],True)
    check,second=enumerate_shells(masks,conflicts,width,protocol["limits"],False)
    assert first["status"]==second["status"]=="EXHAUSTED" and found==check
    shapes={tuple(sorted((root,*(contacts[j] for j in row)))) for row in found}
    corpus=load("input/shell-records-v1.json")
    observed=Counter(tuple(map(tuple,c["tag"])) for phase in corpus.values() for run in phase for c in run["clusters"])
    assert observed.keys()<=shapes
    @lru_cache(maxsize=12000)
    def support(p):
        return frozenset(model.support(p))
    @lru_cache(maxsize=12000)
    def polygon(p):
        return model.poly(p)
    items=[]
    counts=Counter()
    for shape in sorted(shapes):
        placements=[root,*(p for p in shape if p!=root)]
        exposed=boundary([polygon(p) for p in placements])
        assert extract(model,placements)[0]["tag"]==shape
        occupied=set().union(*(support(p) for p in placements))
        candidates=set()
        for g,x,y in placements:
            for variant in contacts:
                h,a,b=model.action(g,variant)
                new=(h,x+a,y+b)
                if support(new).isdisjoint(occupied):
                    candidates.add(new)
        exterior_edges=[(i,a,b) for i,p in enumerate(sorted(candidates)) for a,b in edges(polygon(p))]
        dead=None
        for edge in exposed:
            axis,missing,_=cover_intervals(edge,exterior_edges)
            if missing:
                dead=dict(edge=edge,axis=axis,missing=missing[0])
                break
        status="BLOCKED" if dead else "NO_GAP"
        counts[status]+=1
        if observed[shape]:
            counts[f"observed_{status}"]+=1
        items.append(dict(shape=shape,observations=observed[shape],neighbors=len(shape)-1,
                          outer_segments=exposed,eligible_new_contacts=len(candidates),status=status,gap=dead))
    save("data/catalogue-v1.json",items)
    result=dict(status="CHECKED_EXACT_FIRST_SHELL_CATALOGUE",contacts=len(contacts),edge_atoms=width,
                shells=len(shapes),by_neighbors=dict(Counter(len(x)-1 for x in shapes)),
                distinct_observed=len(observed),extension_screen=dict(counts),methods=[first,second],
                scope="Complete first shells in the lattice model. A boundary gap forbids further surrounding. No-gap status imposes only individual support and does not prove any simultaneous extension.")
    save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
