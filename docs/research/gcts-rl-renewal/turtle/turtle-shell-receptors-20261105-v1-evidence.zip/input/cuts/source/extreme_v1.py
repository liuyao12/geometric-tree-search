"""Exhaust and independently verify all possible strict extreme cone signatures."""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import load, pin, save
from cone_v1 import Sectors, search
from tail_v1 import Replay, dot
from wide_v1 import Carrier


def signatures():
    return sorted({sum(1<<((start+j)%12) for j in range(5) if (mask>>j)&1)
                   for start in range(12) for mask in range(1,32)})


class IndependentVerifier:
    def __init__(self, engine, probes):
        self.scale = engine.scale
        self.normals = sorted(engine.model.normals)
        self.orientation = engine.model.atoms
        self.bits = {self.vector(p):1<<i for i,p in enumerate(probes)}
        assert len(self.bits)==12

    def vector(self,p):
        signs = tuple(dot(n,p) for n in self.normals)
        assert all(signs),p
        return tuple(c>0 for c in signs)

    @lru_cache(maxsize=80000)
    def bit(self,p):
        return self.bits[self.vector(p)]

    def verify(self, signature, tree):
        s = self.scale
        count = 0

        def check(node, filled):
            nonlocal count
            count += 1
            q = tuple(node["point"])
            assert node["status"]=="NEGATIVE" and q not in filled and self.bit(q)&signature
            x,y = q
            children = {tuple(p):child for p,child in node["children"]}
            assert len(children)==len(node["children"])
            matched = set()
            domain = 0
            for g,points in self.orientation.items():
                for a,b in points:
                    u,v = x-a,y-b
                    if u%s or v%s:
                        continue
                    domain += 1
                    if any((c+u,d+v) in filled or not self.bit((c+u,d+v))&signature
                           for c,d in points):
                        continue
                    key = g,u//s,v//s
                    assert key in children and key not in matched
                    matched.add(key)
                    check(children[key],filled|{(c+u,d+v) for c,d in points})
            assert domain==240 and matched==children.keys()

        check(tree,frozenset())
        return count


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    model = load("input/exact-point-model-v1.json")
    engine = Carrier(model,load("input/patterns-v1.json"))
    sectors = Sectors(Replay(model),protocol["radius"])
    checker = IndependentVerifier(engine,sectors.probes)
    candidates = signatures()
    assert len(candidates)==192
    for q in sectors.queries:
        assert checker.bit(q)==sectors.sector(q)
    prior = load("input/cone-proofs-v1.json")
    counts = Counter()
    details = []
    begun = time.perf_counter()
    for i,signature in enumerate(candidates,1):
        old = prior.get(str(signature))
        if old and old["status"]=="NEGATIVE":
            raw,origin = old,"REUSED"
        else:
            raw,origin = search(sectors,engine,signature,protocol["limits"]),"SEARCHED"
        checked = None
        if raw["status"]=="NEGATIVE":
            nodes = checker.verify(signature,raw["tree"])
            assert nodes==raw["nodes"]
            checked = dict(status="VERIFIED",nodes=nodes)
        counts.update((raw["status"],origin))
        details.append(dict(signature=signature,occupied_sectors=signature.bit_count(),
                            origin=origin,raw=raw,checked=checked))
        if i%32==0:
            print(json.dumps(dict(cases=i,**counts)),flush=True)
    save("data/extreme-proofs-v1.json",details)
    save("data/summary-v1.json",dict(status="CHECKED_STRICT_EXTREME_CONE_INVENTORY",
         counts=dict(counts),cases=len(candidates),rays=[a for a,b in sectors.wedges],
         unknown=[d["signature"] for d in details if d["checked"] is None],
         seconds=time.perf_counter()-begun,
         scope="Every nonempty subset of up to five consecutive sectors. The verifier uses the normal signs and every absolute Turtle alignment, without reading search markings."))
    print(json.dumps(dict(cases=len(candidates),done=True,**counts)),flush=True)


if __name__ == "__main__":
    main()
