"""Convert verified cone proof trees into transferable movable-boundary cuts."""

from collections import Counter, defaultdict
from functools import lru_cache
import hashlib
import json
from math import gcd
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, edges, load, pin, save
from cone_v1 import norm
from extreme_v1 import IndependentVerifier


class Geometry:
    def __init__(self,source):
        self.model = Model(source)
        self.scale = self.model.scale
        self.oriented = self.model.atoms
        self.cache = lru_cache(maxsize=32)(self.alignments)

    def alignments(self,q):
        x,y = q
        s = self.scale
        result = []
        for g,points in self.oriented.items():
            for a,b in points:
                u,v = x-a,y-b
                if u%s or v%s:
                    continue
                result.append(((g,u//s,v//s),frozenset((c+u,d+v) for c,d in points)))
        assert len(result)==240
        return result


def compile_cut(geometry, member, tree):
    obligations = set()
    conflicts = defaultdict(int)
    width = 0

    def visit(node,filled):
        nonlocal width
        q = tuple(node["point"])
        assert member(q) and q not in filled
        obligations.add(q)
        children = {tuple(key):child for key,child in node["children"]}
        for key,support in geometry.cache(q):
            if support & filled:
                assert key not in children
                continue
            if key in children:
                assert all(map(member,support))
                visit(children.pop(key),filled|support)
                continue
            outside = [p for p in support if not member(p)]
            assert outside
            bit = 1<<width
            width += 1
            for p in outside:
                conflicts[p] |= bit
        assert not children

    visit(tree,set())
    uncovered = (1<<width)-1
    excluded = []
    while uncovered:
        p = max(conflicts,key=lambda p:((conflicts[p]&uncovered).bit_count(),-norm(p),-p[0],-p[1]))
        assert conflicts[p]&uncovered
        excluded.append(p)
        uncovered &= ~conflicts[p]
    all_bits = (1<<width)-1
    for p in list(excluded):
        union = 0
        for other in excluded:
            if other!=p:
                union |= conflicts[other]
        if union==all_bits:
            excluded.remove(p)
    return dict(required=sorted(obligations),excluded=sorted(excluded),forbidden_alignments=width)


def verify_cut(geometry, tree, required, excluded):
    checked = 0
    assert required.isdisjoint(excluded)

    def visit(node,filled):
        nonlocal checked
        q = tuple(node["point"])
        assert node["status"]=="NEGATIVE" and q in required and q not in filled
        checked += 1
        children = {tuple(key):child for key,child in node["children"]}
        for key,support in geometry.alignments(q):
            if support.isdisjoint(filled) and support.isdisjoint(excluded):
                assert key in children
                visit(children.pop(key),filled|support)
        assert not children

    visit(tree,set())
    return checked


def translated(sites,x,y):
    return ((a+x,b+y) for a,b in sites)


def hit(cut, required, allowed, vertex, scale):
    x,y = vertex
    dx,dy = scale*x,scale*y
    return (all(required(q) for q in translated(cut["required"],dx,dy))
            and not any(allowed(p) for p in translated(cut["excluded"],dx,dy)))


def envelope(poly,scale,margin):
    inward = []
    for (a,b),(c,d) in edges(poly):
        x,y = b-d,c-a
        g = gcd(x,y)
        x,y = x//g,y//g
        inward.append((x,y,scale*(x*a+y*b)))
    def required(q):
        x,y = q
        return all(a*x+b*y-c>margin for a,b,c in inward)
    def allowed(q):
        x,y = q
        return all(a*x+b*y-c>=-margin for a,b,c in inward)
    return required,allowed


def polygon(family,n):
    if family=="equilateral":
        return [(0,0),(n,0),(0,n)]
    if family=="rhombus":
        return [(0,0),(n,0),(n,n),(0,n)]
    assert family=="right"
    return [(0,0),(2*n,0),(n,n)]


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    source = load("input/exact-point-model-v1.json")
    geometry = Geometry(source)
    summary = load("input/extreme-summary-v1.json")
    rays = summary["rays"]
    probes = [(a+c,b+d) for (a,b),(c,d) in zip(rays,rays[1:]+rays[:1])]
    checker = IndependentVerifier(geometry,probes)
    rows = load("input/extreme-proofs-v1.json")
    cuts = []
    for row in rows:
        signature = row["signature"]
        raw = row["raw"]
        assert row["checked"]["status"]=="VERIFIED"
        cut = compile_cut(geometry,lambda q:bool(checker.bit(q)&signature),raw["tree"])
        nodes = verify_cut(geometry,raw["tree"],set(cut["required"]),set(cut["excluded"]))
        assert nodes==row["checked"]["nodes"]
        cut.update(signature=signature,checked_nodes=nodes)
        cuts.append(cut)
    assert len(cuts)==192
    cuts.sort(key=lambda cut:(len(cut["excluded"])+len(cut["required"]),cut["signature"]))
    negative = []
    ratios = Counter()
    for family in protocol["families"]:
        for size in protocol["sizes"]:
            poly = polygon(family,size)
            for margin in protocol["margins"]:
                required,allowed = envelope(poly,geometry.scale,margin)
                first = next(((v,c["signature"]) for v in poly for c in cuts
                              if hit(c,required,allowed,v,geometry.scale)),None)
                if first:
                    ratios[margin] += 1
                negative.append(dict(family=family,size=size,margin=margin,cut=first))
    controls = []
    bank = load("input/three-bank-v1.json")["bank"]
    selection = sorted(range(len(bank)),key=lambda i:hashlib.sha256(f"corner-positive-v1:{i}".encode()).digest())
    for i in selection[:protocol["positive_count"]]:
        support = set().union(*(geometry.model.support(p) for p in bank[i]))
        assert len(support)==720
        vertices = {q for p in bank[i] for q in geometry.model.poly(p)}
        assert not any(hit(c,support.__contains__,support.__contains__,v,geometry.scale)
                       for v in vertices for c in cuts)
        controls.append(dict(type=i,witness=bank[i],anchors=len(vertices),false_cuts=0))
    save("data/cuts-v1.json",cuts)
    save("data/controls-v1.json",dict(envelopes=negative,known_tileable=controls))
    result = dict(status="CHECKED_TRANSFERABLE_REQUIRED_AND_EXCLUDED_CORNER_CUTS",
         cuts=len(cuts),checked_nodes=sum(c["checked_nodes"] for c in cuts),
         required_sizes=dict(Counter(len(c["required"]) for c in cuts)),
         excluded_sizes=dict(Counter(len(c["excluded"]) for c in cuts)),
         envelope_cases=len(negative),certified_infeasible_by_margin=dict(ratios),
         cases_per_margin=len(protocol["families"])*len(protocol["sizes"]),
         positives=len(controls),false_cuts=0,
         scope="A required atom must be tiled, and an excluded atom may not be tiled. Any envelope satisfying a cut is impossible. A missing cut remains unresolved. Margins are integers in the primitive-normal sample coordinate, not Euclidean distances.")
    save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
