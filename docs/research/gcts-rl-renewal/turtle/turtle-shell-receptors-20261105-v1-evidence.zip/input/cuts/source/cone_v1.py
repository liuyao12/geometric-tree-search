"""Learn and replay finite obstructions on exact Turtle boundary cones."""

from collections import Counter
from functools import cmp_to_key, lru_cache
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import bounds, edges, inside, load, mat, pin, save
from stencil_v1 import residue
from tail_v1 import Replay, dot, nodes, threshold
from turtle_points_v1 import primitive
from wide_v1 import Carrier


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def half(v):
    x,y = v
    return int(y<0 or (y==0 and x<0))


def angular(a,b):
    return half(a)-half(b) or cross(b,a)


def norm(p):
    x,y = p
    return x*x+x*y+y*y


class Sectors:
    def __init__(self, replay, radius):
        self.replay = replay
        self.scale = replay.model.scale
        normals = replay.model.normals
        signed = {(sign*b,-sign*a) for a,b in normals for sign in (-1,1)}
        rays = sorted(signed, key=cmp_to_key(angular))
        self.wedges = list(zip(rays, rays[1:]+rays[:1]))
        assert len(rays) == 12 and all(cross(a,b)>0 for a,b in self.wedges)
        self.probes = [(a+c,b+d) for (a,b),(c,d) in self.wedges]
        self.epsilon_den = 1+max(abs(dot(p,n)) for p in self.probes for n in normals)
        s = self.scale
        # The axial coordinate bound exceeds the radius in any direction.
        cells = [(s*x+u,s*y+v) for x in range(-2*radius,2*radius+1)
                 for y in range(-2*radius,2*radius+1) for u,v in replay.model.residues]
        self.queries = sorted((q for q in cells if norm(q)<=(radius*s)**2),
                              key=lambda q:(norm(q),q))

    @lru_cache(maxsize=200000)
    def sector(self, point):
        for i,(a,b) in enumerate(self.wedges):
            if cross(a,point)>0 and cross(point,b)>0:
                return 1<<i
        raise ValueError(f"Sample lies on an angular boundary: {point}")

    def family(self, matrix):
        e = self.epsilon_den
        model = self.replay.model
        polygons = {g:tuple(mat(matrix,p) for p in model.poly((g,0,0))) for g in model.groups}
        rings = {g:edges(tuple((e*x,e*y) for x,y in p)) for g,p in polygons.items()}
        boxes = {g:bounds(p) for g,p in polygons.items()}

        @lru_cache(maxsize=12000)
        def component(g,x,y):
            a,b,c,d = boxes[g]
            if not (a<=x<=b and c<=y<=d):
                return 0
            return sum(1<<i for i,(u,v) in enumerate(self.probes)
                       if inside((e*x+u,e*y+v),rings[g]))

        def shapes(pieces):
            placements = [(g,*mat(matrix,(x,y))) for g,x,y in pieces]
            polys = [tuple((a+x,b+y) for a,b in polygons[g]) for g,x,y in placements]
            vertices = set(p for poly in polys for p in poly)
            signatures = {}
            for x,y in vertices:
                occupied = 0
                for g,u,v in placements:
                    occupied |= component(g,x-u,y-v)
                assert occupied
                signatures[x,y] = occupied
            return polys,signatures

        return shapes


def search(sectors, engine, signature, limits):
    s = sectors.scale
    points = [q for q in sectors.queries if sectors.sector(q)&signature]
    if not points:
        return dict(status="UNKNOWN",nodes=0)
    begun = time.perf_counter()
    visits = 0

    @lru_cache(maxsize=20000)
    def allowed(q):
        return bool(sectors.sector(q)&signature)

    @lru_cache(maxsize=128)
    def unoccupied_domain(q):
        x,y = q
        available = {}
        for g,a,b,offsets in engine.alignments[residue(q,s)]:
            if all(allowed((x+u,y+v)) for u,v in offsets):
                k = g,(x-a)//s,(y-b)//s
                available[k] = frozenset((x+u,y+v) for u,v in offsets)
        return available

    def visit(filled, depth):
        nonlocal visits
        if visits>=limits["visits"] or time.perf_counter()-begun>=limits["seconds"]:
            return None
        visits += 1
        prefix = [q for q in points if q not in filled]
        for q in (prefix if depth==0 else prefix[:limits["marks_child"]]):
            x,y = q
            for stencil,origin in engine.bank[residue(q,s)]:
                if all((x+u,y+v) in filled or not allowed((x+u,y+v)) for u,v in stencil):
                    return dict(status="NEGATIVE",point=q,children=[],
                                mark=dict(point=q,stencil=stencil,origin=origin))
        options = []
        for q in prefix[:limits["exact_queries"]]:
            legal = {k:a for k,a in unoccupied_domain(q).items() if a.isdisjoint(filled)}
            if not legal:
                return dict(status="NEGATIVE",point=q,children=[])
            options.append((len(legal),q,legal))
        if depth == limits["depth"]:
            return None
        for _,q,legal in sorted(options)[:limits["alternative_pivots"]]:
            children = []
            for k,a in sorted(legal.items()):
                child = visit(filled|a,depth+1)
                if child is None:
                    break
                children.append((k,child))
            if len(children) == len(legal):
                return dict(status="NEGATIVE",point=q,children=children)
        return None

    tree = visit(frozenset(),0)
    return dict(status="NEGATIVE" if tree else "UNKNOWN",tree=tree,visits=visits,
                nodes=sum(1 for _ in nodes(tree)) if tree else 0)


def footprint(replay, tree):
    s = replay.model.scale
    extents = {}
    points = [tuple(node["point"]) for node in nodes(tree)]
    for normal in replay.model.normals:
        lows,highs = [],[]
        for q in points:
            low,high = replay.extrema[residue(q,s)][normal]
            offset = dot(normal,q)
            lows.append(low+offset)
            highs.append(high+offset)
        extents[normal] = min(lows),max(highs)
    return extents


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    model = load("input/exact-point-model-v1.json")
    replay = Replay(model)
    engine = Carrier(model,load("input/patterns-v1.json"))
    sectors = Sectors(replay,protocol["radius"])
    library = load("input/three-bank-v1.json")["bank"]
    assert len(library)==2241

    @lru_cache(maxsize=4096)
    def cone(signature):
        raw = search(sectors,engine,signature,protocol["limits"])
        return raw,footprint(replay,raw["tree"]) if raw["status"]=="NEGATIVE" else None

    summary = {}
    proofs = {}
    for spec in protocol["families"]:
        ratio = spec["ratio"]
        shape = sectors.family(spec["base"])
        counts,thresholds = Counter(),Counter()
        begun = time.perf_counter()
        with (ROOT/f"input/ratio-{ratio}-tail-v1.jsonl").open() as before, (
                ROOT/f"data/ratio-{ratio}-cone-v1.jsonl").open("x",buffering=1) as out:
            for i,line in enumerate(before):
                prior = json.loads(line)
                assert prior["type"]==i
                first = prior["first"]
                if prior["winner"] and not prior["unresolved_bridge"]:
                    counts["earlier_complete"] += 1
                    continue
                counts["entered"] += 1
                polys,signatures = shape(library[i])
                lines = set()
                for poly in polys:
                    for (a,b),(c,d) in edges(poly):
                        normal = primitive(d-b,a-c)
                        lines.add((normal,dot(normal,(a,b))))
                candidates = []
                for anchor,sig in sorted(signatures.items()):
                    raw,extents = cone(sig)
                    proofs[sig] = raw
                    if raw["status"]=="NEGATIVE":
                        cut = max(first,threshold(anchor,extents,lines,replay.model.scale))
                        candidates.append((cut,raw["nodes"],anchor,sig))
                trials = []
                winner = None
                for cut,size,anchor,sig in sorted(candidates)[:protocol["anchor_trials"]]:
                    tree = proofs[sig]["tree"]
                    assert replay.verify_at(polys,tree,anchor,0,cut)
                    gaps = [k for k in range(first,cut) if not replay.verify_at(polys,tree,anchor,0,k)]
                    attempt = dict(cut=cut,anchor=anchor,signature=sig,nodes=size,gaps=gaps)
                    trials.append(attempt)
                    if not gaps:
                        winner = attempt
                        counts["new_complete"] += 1
                        thresholds[cut] += 1
                        break
                if winner is None:
                    counts["still_open"] += 1
                out.write(json.dumps(dict(type=i,first=first,winner=winner,trials=trials,
                                          signatures=sorted(set(signatures.values()))),
                                     sort_keys=True,separators=(",",":"))+"\n")
                if (i+1)%512==0:
                    print(json.dumps(dict(ratio=ratio,cases=i+1,**counts)),flush=True)
        assert counts["earlier_complete"]+counts["new_complete"]+counts["still_open"]==2241
        summary[ratio] = dict(counts=dict(counts),thresholds=dict(thresholds),
                              seconds=time.perf_counter()-begun)
        print(json.dumps(dict(ratio=ratio,**summary[ratio])),flush=True)
    save("data/cone-proofs-v1.json",proofs)
    save("data/summary-v1.json",dict(status="CHECKED_EXACT_BOUNDARY_CONE_TRANSFER",
         cone_proofs=dict(Counter(p["status"] for p in proofs.values())),families=summary,
         scope="Bounded local certificate discovery on exact angular sectors, followed by exact polygon replay and a uniform multiplier bound. Open cases may have other proof templates."))


if __name__ == "__main__":
    main()
