"""Prospective point masks, without search, labels, policy or tiling witnesses."""
import hashlib
import json
from pathlib import Path

NAMESPACE='gcts-turtle-receptors-v1'
SPEC=dict(namespace=NAMESPACE,training_scales=[4,5],heldout_scales=[6,8,10],
          families=['bent_walk','cut_annulus','unequal_lobes'],max_points=512,
          duplicate_attempts=32,duplicates='Exact target OR seed-unioned core, modulo translation and every supplied point action; old and new splits included.')
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(v):return hashlib.sha256(wire(v)).hexdigest()
def hexagon(r):return {(x,y) for x in range(-r,r+1) for y in range(-r,r+1) if max(abs(x),abs(y),abs(x+y))<=r}
def shifted(points,dx,dy):return {(x+dx,y+dy) for x,y in points}
def canonical(points,groups):
    points={tuple(p) for p in points};assert points
    images=[]
    for g in groups:
        a=g['matrix'];image=sorted((a[0][0]*x+a[0][1]*y,a[1][0]*x+a[1][1]*y) for x,y in points)
        ox,oy=image[0];images.append(tuple((x-ox,y-oy) for x,y in image))
    return min(images)
def mask(split,family,scale,attempt):
    counter=0
    def draw(n):
        nonlocal counter
        raw=wire([NAMESPACE,split,family,scale,attempt,counter]);counter+=1
        return int.from_bytes(hashlib.sha256(raw).digest(),'big')%n
    s=scale;parity=draw(2);width=1+draw(2)
    if family=='bent_walk':
        x,y=-s,-s//3;points=set();first=s//2+draw(2);second=s+1+draw(2)
        for i in range(2*s+2):
            points |= shifted(hexagon(width),x,y)
            dx,dy=(1,0) if i<first else ((0,1) if parity else (1,-1)) if i<second else (1,0)
            x+=dx;y+=dy
        description=dict(width=width,first_bend=first,second_bend=second,parity=parity)
    elif family=='cut_annulus':
        inner=max(1,s//3);cut=1+draw(3)
        points={p for p in hexagon(s)-hexagon(inner) if not(p[0]>=cut and p[1]>=0 and p[0]+p[1]>=s-1)}
        # Asymmetry is generated without consulting any search outcome.
        notch=-s//2+draw(s+1)
        points={p for p in points if not(p[0]==notch and p[1]<-inner and (p[0]-p[1])%3==parity)}
        points=shifted(points,s//3,-s//4)
        description=dict(inner_radius=inner,cut=cut,notch=notch,parity=parity)
    elif family=='unequal_lobes':
        left=max(2,s//3+1);right=max(1,s//4+1);bridge=draw(2)
        points=shifted(hexagon(left),-s,0)|shifted(hexagon(right),s//2,1+parity)
        for x in range(-s,s//2+1):points |= shifted(hexagon(bridge),x,(x+s)*(1+parity)//max(1,s+s//2))
        description=dict(left_radius=left,right_radius=right,bridge_width=bridge,parity=parity)
    else:raise ValueError('Unknown predeclared mask family')
    assert 0<len(points)<=SPEC['max_points']
    return points,description
def generate(model,groups,old_cases):
    support={(x,y) for x,y,u in next(o['points'] for o in model['orientations'] if o['id']==0)}
    center=((min(x for x,y in support)+max(x for x,y in support))//2,(min(y for x,y in support)+max(y for x,y in support))//2)
    seen=set()
    for split in old_cases.values():
        for c in split:
            seen.add(canonical(c['target'],groups));seen.add(canonical(c['core'],groups))
    result=dict(training=[],heldout=[]);rejections=[]
    for split,scales in [('training',SPEC['training_scales']),('heldout',SPEC['heldout_scales'])]:
        for family in SPEC['families']:
            for scale in scales:
                for attempt in range(SPEC['duplicate_attempts']):
                    raw,description=mask(split,family,scale,attempt)
                    target=shifted(raw,*center);core=target|support
                    ct,cc=canonical(target,groups),canonical(core,groups)
                    if ct in seen or cc in seen:
                        rejections.append(dict(split=split,family=family,scale=scale,attempt=attempt,reason='PRELABEL_DIHEDRAL_TRANSLATION_DUPLICATE'));continue
                    seen.update((ct,cc));idx=len(result[split]);cid=('T' if split=='training' else 'H')+'%02d'%idx
                    result[split].append(dict(id=cid,label=family+' scale'+str(scale),family=family,scale=scale,attempt=attempt,parameters=description,center=list(center),seeds=[[0,0,0]],target=[list(p) for p in sorted(target)],core=[list(p) for p in sorted(core)],core_sha256=digest([list(p) for p in sorted(core)])))
                    break
                else:raise RuntimeError('PRELABEL_GENERATOR_DUPLICATE_ATTEMPTS_EXHAUSTED')
    return dict(spec=SPEC,cases=result,prelabel_rejections=rejections,scope='Finite required point masks with free exterior; no forbidden interior area, no search-selected targets or tiling input.')
