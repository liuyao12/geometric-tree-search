"""Copy approved reused inputs and generate masks without scientific search."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT.parent/'gcts-turtle-cluster-rl-20261103-v1'
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wire(v))
def main():
    assert not (ROOT/'data/cases-v1.json').exists(),'Preserve existing cohort'
    copies=[('data/marked-model-v1.json','data/marked-model-v1.json'),('data/frozen-bank-v1.json','data/reused-bank-v1.json'),('reference/original-point-data-v1.json','reference/original-point-data-v1.json'),('data/cases-v1.json','reference/examined-cases-v1.json'),('reference/parent-qualification-fixtures-v1.json','reference/point-qualification-fixtures-v1.json'),('publication/live-complete-v1.json','reference/parent-live-complete-v1.json')]
    receipts=[]
    for old,new in copies:
        target=ROOT/new;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
        shutil.copyfile(PARENT/old,target);assert pin(target)==pin(PARENT/old)
        receipts.append(dict(source=str(PARENT/old),copy=new,**pin(target)))
    master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
    shutil.copyfile(master,ROOT/'reference/basic-tiling-algorithm.md')
    generator=ROOT/'source/cohort_v1.py'
    save(ROOT/'data/generator-source-before-generation-v1.json',dict(status='FROZEN_BEFORE_GENERATION',generator_source=pin(generator),inputs=receipts))
    spec=importlib.util.spec_from_file_location('point_cohort_generator',generator);G=importlib.util.module_from_spec(spec);spec.loader.exec_module(G)
    model=json.loads((ROOT/'data/marked-model-v1.json').read_text());groups=json.loads((ROOT/'reference/original-point-data-v1.json').read_text())['groups'];old=json.loads((ROOT/'reference/examined-cases-v1.json').read_text())
    result=G.generate(model,groups,old);assert pin(generator)==json.loads((ROOT/'data/generator-source-before-generation-v1.json').read_text())['generator_source']
    save(ROOT/'data/cases-v1.json',result['cases']);save(ROOT/'data/cohort-generation-v1.json',result)
    print(json.dumps(dict(status='PREPARED_WITHOUT_SEARCH',training=[len(c['core']) for c in result['cases']['training']],heldout=[len(c['core']) for c in result['cases']['heldout']],duplicate_rejections=len(result['prelabel_rejections']))))
if __name__=='__main__':main()
