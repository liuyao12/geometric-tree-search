"""Retained Turtle family preferences with exact hypothetical frontier checks.

Source-only until prospective qualification. The pinned reference supplies the
previous exact field/group helpers, 40D features and episodic optimizer; it is
not an engine or checker. No search, geometry or independent verifier imported.
"""
import hashlib
import importlib.util
import math
from pathlib import Path
import time


_REUSE_SHA = 'ee4bf42aaf704562d1286aaec159e0f2cd6ec699b2bc74e61cc5345b26d5a3ad'
_REUSE_PATH = Path(__file__).resolve().parents[1] / 'reference/reused-cluster-policy-v1.py'
if hashlib.sha256(_REUSE_PATH.read_bytes()).hexdigest() != _REUSE_SHA:
    raise ValueError('Pinned reused policy Source differs.')
_spec = importlib.util.spec_from_file_location('turtle_reused_policy_v1', _REUSE_PATH)
R = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(R)
wire, digest, require, placement = R.wire, R.digest, R.require, R.placement
LANES = ('MARKED_LEX', 'HEAD_H', 'CONT_H', 'HEAD_V_H', 'CONT_V_H',
         'CONT_V_RANDOM', 'CONT_V_ZERO', 'CONT_V_RL')


def detached(value):
    return R.json.loads(wire(value))


def parent_context(engine):
    return dict(placements=[dict(placement=list(c), generation=g) for c, g in engine.selected.items()],
                decision=engine.decision(), core=[list(p) for p in sorted(engine.core)],
                seed_count=engine.seed_count, grow=engine.grow)


class FrozenBank(R.Bank):
    """Read-only use of a prior bank, with every constituent as a family port."""
    def __init__(self, model, groups, frozen):
        require(frozen.get('frozen') is True and frozen['max_templates'] == 32,
                'A frozen 32-slot bank is required for the existing 40D feature map.')
        super().__init__(model, groups, max_templates=32)
        require(frozen['model_sha256'] == self.model_sha256, 'Frozen bank/model binding differs.')
        require(frozen['bank_sha256'] == digest(dict(model_sha256=self.model_sha256,
                                                   templates=frozen['templates'])), 'Frozen bank hash differs.')
        self.templates = detached(frozen['templates'])
        require(len(self.templates) <= 32 and len({t['id'] for t in self.templates}) == len(self.templates),
                'Frozen template IDs/capacity differ.')
        self.frozen = True
        self.frozen_record = detached(frozen)
        self.families = []
        for i, template in enumerate(self.templates):
            require(template['index'] == i and template['model_sha256'] == self.model_sha256,
                    'Template index/model binding differs.')
            expansion = [placement(p) for p in template['placements']]
            require(self.validate(expansion, {}, {}, set())['valid'] and self.connected(expansion),
                    'Frozen template is not an exact compatible connected cluster.')
            for j, port in enumerate(expansion):
                normalized = self.normalize([port] + [p for k, p in enumerate(expansion) if k != j])
                self.families.append(dict(id=template['id'] + '-port-%02d' % j,
                    template_id=template['id'], index=i, port_index=j,
                    placements=[list(p) for p in normalized]))
        self.family_sha256 = digest(self.families)

    def add_from_positive(self, *args, **kwargs):
        raise ValueError('This experiment uses a fixed prior bank; admission is disabled.')

    def snapshot(self):
        return detached(self.frozen_record)


class _InterfaceStop(Exception):
    pass


def check_interface(engine, expansion, bank, materialization_cap=50000, deadline=None):
    """Complete hypothetical union graph, entirely transient and point-based.

    A resource stop is UNKNOWN even if a partial traversal noticed a dead point.
    No production engine materialization/dependency/registration state is used
    or modified. Hypothetical generations are deliberately not invented.
    """
    started = time.perf_counter()
    require(type(materialization_cap) is int and materialization_cap >= 0, 'Nonnegative interface cap required.')
    require(engine.model == bank.model, 'Interface/model binding differs.')
    context = parent_context(engine)
    expansion = [placement(p) for p in expansion]
    require(len(expansion) == len(set(expansion)), 'Hypothetical expansion repeats a placement.')
    union = set(engine.selected) | set(expansion)
    result = dict(schema='Turtle-hypothetical-interface-v1', status='INTERFACE_UNKNOWN', complete=False,
        model_sha256=bank.model_sha256, parent_context=context, parent_sha256=digest(context),
        expansion_sha256=digest([list(c) for c in sorted(expansion)]),
        union_sha256=digest([list(c) for c in sorted(union)]),
        materialization_cap=materialization_cap, materializations=0, domain_sha256=None,
        graph_sha256=None, dead_points=[], reason=None)
    if deadline is None:
        deadline = getattr(engine, 'deadline', None)

    def cooperate():
        if deadline is not None and time.perf_counter() >= deadline:
            raise _InterfaceStop('DEADLINE')

    try:
        cooperate()
        check = bank.validate(expansion, engine.T, engine.M, set(engine.selected), engine.allowed)
        if not check['valid']:
            result.update(status='JOINT_INVALID', reason=check['reason'])
            return result
        totals = dict(engine.T)
        for point, units in check['additions'].items():
            totals[point] = totals.get(point, 0) + units
        marks = {key: value[0] for key, value in engine.M.items()}
        marks.update(check['marks'])
        required = set(engine.core)
        if engine.grow:
            required.update(totals)
        frontier = sorted(p for p in required if totals.get(p, 0) < bank.capacity)
        validity, domains, edges = {}, [], []
        for px, py in frontier:
            cooperate()
            alignments = {(g, px - x, py - y) for g, field in bank.t.items() for x, y in field}
            if engine.allowed is not None:
                alignments.intersection_update(engine.allowed)
            domain = []
            for candidate in sorted(alignments):
                cooperate()
                if candidate not in validity:
                    if candidate in union:
                        validity[candidate] = False
                    else:
                        if result['materializations'] >= materialization_cap:
                            raise _InterfaceStop('MATERIALIZATION_CAP')
                        result['materializations'] += 1
                        g, dx, dy = candidate
                        legal = all(totals.get((x + dx, y + dy), 0) + units <= bank.capacity
                                    for (x, y), units in bank.t[g].items())
                        if legal:
                            for (x, y, channel), value in bank.m.get(g, {}).items():
                                key = x + dx, y + dy, channel
                                if key in marks and marks[key] != value:
                                    legal = False
                                    break
                        validity[candidate] = legal
                if validity[candidate]:
                    domain.append(list(candidate))
                    g, dx, dy = candidate
                    edges.append([px, py, g, dx, dy, bank.t[g][px - dx, py - dy]])
            domains.append(dict(point=[px, py], candidates=domain))
        cooperate()
        dead = [row['point'] for row in domains if not row['candidates']]
        result.update(status='VERIFIED_DEAD' if dead else 'VERIFIED_VIABLE', complete=True,
            domains=domains, edge_units=edges, dead_points=dead,
            domain_sha256=digest(domains), graph_sha256=digest(dict(domains=domains, edge_units=edges)),
            frontier_points=len(domains), candidate_nodes=len({tuple(c) for row in domains for c in row['candidates']}),
            incidences=len(edges), union_placements=len(union),
            required_points=len(required), mark_assignments=len(marks),
            reason='COMPLETE_DEAD_FRONTIER' if dead else 'COMPLETE_VIABLE_FRONTIER')
    except _InterfaceStop as error:
        result.update(status='INTERFACE_UNKNOWN', complete=False, reason=str(error))
    finally:
        result['seconds'] = time.perf_counter() - started
    return result


def compact_interface(receipt):
    return {key: value for key, value in receipt.items() if key not in ('domains', 'edge_units', 'parent_context')}


def _base_actions(engine, candidates, bank, point):
    actions = []
    for candidate in candidates:
        check = bank.validate([candidate], engine.T, engine.M, set(engine.selected), engine.allowed)
        require(check['valid'], 'Complete live branch domain contains an invalid base candidate.')
        actions.append(R.action_record(engine, bank, candidate, check, point))
    return actions


def propose(engine, candidates, bank, *, filtered=False, deadline=None):
    """48 cheap trials; the first two distinct cheap-valid offers, no replenishment."""
    started = time.perf_counter()
    context = parent_context(engine)
    candidates = sorted(placement(c) for c in candidates)
    require(context['decision']['kind'] == 'branch' and
            candidates == sorted(placement(c) for c in context['decision']['candidates']),
            'Family anchors must be the complete current branch domain.')
    point = tuple(context['decision']['point'])
    actions = _base_actions(engine, candidates, bank, point)
    state_sha = digest(dict(parent=context, model_sha256=bank.model_sha256, family_sha256=bank.family_sha256))
    total = len(bank.families) * len(candidates)
    offset = int(state_sha[:16], 16) % total if total else 0
    stride = 1 + int(state_sha[16:32], 16) % total if total else 1
    while total and math.gcd(stride, total) != 1:
        stride = stride % total + 1
    trials, offered, seen = [], [], set()
    for i in range(min(48, total)):
        if deadline is not None and time.perf_counter() >= deadline:
            break
        cycle_index = (offset + i * stride) % total
        fi, ci = divmod(cycle_index, len(candidates))
        family, anchor = bank.families[fi], candidates[ci]
        expansion = bank.anchor(family, anchor)
        check = bank.validate(expansion, engine.T, engine.M, set(engine.selected), engine.allowed)
        reason = check['reason']
        if check['valid'] and len(check['new']) < 2:
            reason = 'FEWER_THAN_TWO_NEW_PRIMITIVES'
        signature = tuple(sorted(expansion))
        if check['valid'] and reason is None and signature in seen:
            reason = 'DUPLICATE_EXPANSION'
        if check['valid'] and reason is None:
            seen.add(signature)
            if len(offered) >= 2:
                reason = 'OFFER_CAP'
            else:
                action = R.action_record(engine, bank, anchor, check, point, family)
                action.update(family_id=family['id'], template_id=family['template_id'],
                              port_index=family['port_index'])
                offered.append(action)
        trials.append(dict(trial=i, cycle_index=cycle_index, family_id=family['id'],
                           anchor=list(anchor), offered=reason is None, reject_reason=reason))
    receipts = []
    for action in offered:
        if filtered:
            receipt = check_interface(engine, action['primitive_expansion'], bank, deadline=deadline)
            receipts.append(dict(phase='offer', family_id=action['family_id'],
                                 expansion=action['primitive_expansion'], receipt=receipt))
            action['interface'] = compact_interface(receipt)
            if receipt['status'] != 'VERIFIED_VIABLE':
                continue
        actions.append(action)
    return dict(actions=actions, trials=trials, receipts=receipts, state_sha256=state_sha,
                context=context, cheap_offers=len(offered), cycle_offset=offset, cycle_stride=stride,
                possible_family_anchor_pairs=total, seconds=time.perf_counter() - started)


class Controller(R.Controller):
    def __init__(self, model, groups, frozen_bank, lane, *, seed=0, training=False,
                 weights=None, learning_rate=0.03):
        require(lane in LANES and (not training or lane == 'CONT_V_RL'), 'Invalid lane/training mode.')
        self.public_lane = lane
        self.continuation = lane.startswith('CONT_')
        self.filtered = '_V_' in lane
        self.explicit_deadline = None
        bank = FrozenBank(model, groups, frozen_bank)
        old_lane = ('MARKED_CLUSTER_RL' if lane in ('CONT_V_RL', 'CONT_V_ZERO') else
                    'MARKED_CLUSTER_RANDOM' if lane == 'CONT_V_RANDOM' else
                    'MARKED_LEX' if lane == 'MARKED_LEX' else 'MARKED_CLUSTER_HEURISTIC')
        if lane == 'CONT_V_ZERO':
            require(weights is None or all(v == 0 for v in weights), 'Zero control requires zero weights.')
            weights = [0.0] * 40
        super().__init__(bank, old_lane, seed=seed, training=training, weights=weights,
                         learning_rate=learning_rate, proposal_cap=48)
        self.lane = lane

    def start_episode(self, seed=None):
        super().start_episode(seed)
        self.active_plan, self.pending_action = None, None
        self.plan_nonce, self.events, self.interface_samples = 0, [], {}
        self.plan_examples = {}
        self.interface_records = []
        self._last_order_snapshot, self._last_order_index = None, None
        self.telemetry.update(adoptions=0, successor_choices=0, forced_fulfillments=0,
            branch_member_fulfillments=0, completions=0, abandonments=0, suspensions=0,
            restores=0, interface_calls=0, interface_viable=0, interface_dead=0,
            interface_unknown=0, interface_seconds=0.0)

    def set_deadline(self, deadline):
        require(deadline is None or type(deadline) in (int, float) and math.isfinite(deadline),
                'Absolute perf_counter deadline required.')
        self.explicit_deadline = deadline

    def checkpoint(self):
        return detached(dict(active_plan=self.active_plan, pending_action=self.pending_action))

    def restore(self, saved):
        require(set(saved) == {'active_plan', 'pending_action'}, 'Logical checkpoint keys differ.')
        before = self.checkpoint()
        self.active_plan, self.pending_action = detached(saved['active_plan']), detached(saved['pending_action'])
        self.telemetry['restores'] += 1
        self.events.append(dict(event_type='restore', ordinal=len(self.events),
                                checkpoint_before=before, checkpoint_after=self.checkpoint()))

    def _record_interface(self, engine, phase, expansion, receipt, family_id):
        compact = compact_interface(receipt)
        self.interface_records.append(dict(phase=phase, family_id=family_id,
                                          expansion=detached(expansion), receipt=compact))
        self.telemetry['interface_calls'] += 1
        suffix = {'VERIFIED_VIABLE': 'viable', 'VERIFIED_DEAD': 'dead'}.get(receipt['status'], 'unknown')
        self.telemetry['interface_' + suffix] += 1
        self.telemetry['interface_seconds'] += receipt['seconds']
        key = phase + '/' + receipt['status']
        sample = dict(phase=phase, family_id=family_id, expansion=detached(expansion),
                      parent_snapshot=engine.snapshot(), receipt=detached(receipt))
        if key not in self.interface_samples:
            self.interface_samples[key] = dict(first=sample, last=sample, seen=1)
        else:
            self.interface_samples[key]['last'] = sample
            self.interface_samples[key]['seen'] += 1

    def _abandon(self, reason):
        before = self.checkpoint()
        self.active_plan = None
        self.telemetry['abandonments'] += 1
        self.events.append(dict(event_type='abandon', ordinal=len(self.events), reason=reason,
                                checkpoint_before=before, checkpoint_after=self.checkpoint()))

    def __call__(self, engine, candidates):
        started = time.perf_counter()
        checkpoint_at_call = self.checkpoint()
        require(not self.episode_finished and engine.model == self.bank.model, 'Episode/model binding differs.')
        decision = engine.decision()
        candidates = sorted(placement(c) for c in candidates)
        require(decision['kind'] == 'branch' and len(candidates) == len(set(candidates)) and
                candidates == sorted(placement(c) for c in decision['candidates']), 'Complete BRANCH domain required.')
        self.telemetry['calls'] += 1
        self.pending_action = None
        if self.public_lane == 'MARKED_LEX':
            self.telemetry['controller_seconds'] += time.perf_counter() - started
            return candidates
        context = parent_context(engine)
        point = tuple(decision['point'])
        deadline = getattr(engine, 'deadline', self.explicit_deadline)
        if deadline is None:
            deadline = self.explicit_deadline
        actions = _base_actions(engine, candidates, self.bank, point)
        trials, receipts, cycle = [], [], {}
        plan_phase = 'fresh'
        if self.active_plan is not None:
            plan_phase = 'retained'
            plan = self.active_plan
            plan['pending'] = [list(c) for c in sorted(set(map(placement, plan['expansion'])) - set(engine.selected))]
            if not plan['pending']:
                self.active_plan = None
                self.telemetry['completions'] += 1
            else:
                check = self.bank.validate(plan['expansion'], engine.T, engine.M,
                                           set(engine.selected), engine.allowed)
                if not check['valid']:
                    self._abandon(check['reason'])
                else:
                    eligible = [c for c in candidates if list(c) in plan['pending']]
                    if not eligible:
                        self.telemetry['suspensions'] += 1
                    else:
                        allowed = True
                        if self.filtered:
                            receipt = check_interface(engine, plan['expansion'], self.bank, deadline=deadline)
                            receipts.append(dict(phase='retained', family_id=plan['family_id'],
                                                 expansion=plan['expansion'], receipt=receipt))
                            allowed = receipt['status'] == 'VERIFIED_VIABLE'
                            if receipt['status'] == 'VERIFIED_DEAD':
                                self._abandon('COMPLETE_UNION_DEAD_FRONTIER')
                            elif not allowed:
                                self.telemetry['suspensions'] += 1
                        if allowed:
                            template = dict(id=plan['family_id'], index=plan['template_index'])
                            for candidate in eligible:
                                action = R.action_record(engine, self.bank, candidate, check, point, template)
                                action.update(kind='continuation', family_id=plan['family_id'],
                                    template_id=plan['template_id'], port_index=plan['port_index'], plan_id=plan['id'])
                                actions.append(action)
        if plan_phase == 'fresh' or self.active_plan is None and not receipts:
            packet = propose(engine, candidates, self.bank, filtered=self.filtered, deadline=deadline)
            actions, trials = packet['actions'], packet['trials']
            receipts.extend(packet['receipts'])
            cycle = {k: packet[k] for k in ('cheap_offers', 'cycle_offset', 'cycle_stride', 'possible_family_anchor_pairs')}
        for item in receipts:
            self._record_interface(engine, item['phase'], item['expansion'], item['receipt'], item['family_id'])
        pool_seconds = time.perf_counter() - started
        self.telemetry['proposal_seconds'] += pool_seconds
        logits = [sum(w * x for w, x in zip(self._weights, a['features'])) for a in actions]
        peak = max(logits)
        masses = [math.exp(value - peak) for value in logits]
        probabilities = [mass / sum(masses) for mass in masses]
        if self.public_lane == 'CONT_V_RL' and self.training:
            draw, cumulative, chosen = self.rng.random(), 0.0, len(actions) - 1
            for i, probability in enumerate(probabilities):
                cumulative += probability
                if draw < cumulative:
                    chosen = i
                    break
            expected = [sum(p * a['features'][j] for p, a in zip(probabilities, actions)) for j in range(40)]
            self.gradients.append([x - mean for x, mean in zip(actions[chosen]['features'], expected)])
            behavior_probability = probabilities[chosen]
        elif self.public_lane == 'CONT_V_RANDOM':
            chosen = self.rng.randrange(len(actions))
            behavior_probability = 1.0 / len(actions)
        elif self.public_lane in ('CONT_V_RL', 'CONT_V_ZERO'):
            chosen = min(range(len(actions)), key=lambda i: (-logits[i], i))
            behavior_probability = 1.0
        else:
            chosen = min(range(len(actions)), key=lambda i: (-actions[i]['heuristic_score'],
                         0 if actions[i]['kind'] == 'continuation' else 1, i))
            behavior_probability = 1.0
        action = actions[chosen]
        choice_index = len(self.decisions)
        kind = 'successor' if action['kind'] == 'continuation' else 'adopt' if action['kind'] == 'cluster' else 'base'
        self._last_order_snapshot = engine.snapshot() if kind != 'base' else None
        self._last_order_index = choice_index
        checkpoint_before_order = self.checkpoint()
        self.pending_action = dict(choice_index=choice_index, kind=kind, anchor=action['anchor'],
                                   parent_sha256=digest(context))
        if kind != 'base':
            self.pending_action.update(family_id=action['family_id'], template_id=action['template_id'],
                template_index=action['cluster_index'], port_index=action['port_index'],
                expansion=action['primitive_expansion'], plan_id=action.get('plan_id'))
        self.decisions.append(dict(state_sha256=digest(context), parent_context=context,
            branch_point=decision['point'], trials=trials, tested=len(trials), cycle=cycle,
            base_action_count=len(candidates), action_count=len(actions), chosen_index=chosen,
            chosen_action=detached(action), behavior_probability=behavior_probability,
            behavior_log_probability=math.log(behavior_probability), model_softmax_probability=probabilities[chosen],
            action_feature_table=[dict(kind=a['kind'], anchor=a['anchor'], cluster_index=a['cluster_index'],
                                      continuous=a['features'][:8]) for a in actions],
            model_softmax_probabilities=probabilities, weights=list(self._weights),
            policy='stochastic linear-softmax' if self.training else self.public_lane,
            proposal_seconds=pool_seconds,
            plan_phase=plan_phase, checkpoint_after=self.checkpoint()))
        self.events.append(dict(event_type='order', ordinal=len(self.events), choice_index=choice_index,
            checkpoint_at_call=checkpoint_at_call, checkpoint_before=checkpoint_before_order,
            checkpoint_after=self.checkpoint()))
        self.telemetry['branch_choices'] += 1
        self.telemetry['trials'] += len(trials)
        self.telemetry['valid_cluster_actions'] += sum(a['kind'] != 'base' for a in actions)
        self.telemetry['chosen_cluster_actions'] += action['kind'] != 'base'
        anchor = tuple(action['anchor'])
        ordered = [anchor] + [c for c in candidates if c != anchor]
        require(set(ordered) == set(candidates) and len(ordered) == len(candidates), 'Base fallback set changed.')
        self.telemetry['controller_seconds'] += time.perf_counter() - started
        return ordered

    def after_place(self, engine, move, kind):
        started = time.perf_counter()
        move = placement(move)
        require(kind in ('branch', 'forced'), 'Unknown actual placement decision kind.')
        before = self.checkpoint()
        parent = detached(engine.control_before)
        require(parent['decision']['kind'] == kind and list(move) in parent['decision']['candidates'],
                'Actual move does not match true parent decision.')
        previous = {placement(row['placement']) for row in parent['placements']}
        require(move not in previous and set(engine.selected) == previous | {move},
                'after_place must follow exactly one new primitive placement.')
        pending, self.pending_action = self.pending_action, None
        taken = bool(kind == 'branch' and pending is not None and move == placement(pending['anchor']))
        transition, completed, abandonment = 'ordinary', False, None
        if taken and pending['kind'] == 'adopt' and self.continuation:
            require(self.active_plan is None, 'Cannot replace an active retained plan.')
            self.plan_nonce += 1
            self.active_plan = dict(id='plan-%06d' % self.plan_nonce,
                family_id=pending['family_id'], template_id=pending['template_id'],
                template_index=pending['template_index'], port_index=pending['port_index'],
                anchor=pending['anchor'], expansion=pending['expansion'], pending=[])
            transition = 'adoption'
            self.telemetry['adoptions'] += 1
        elif self.active_plan is not None and list(move) in self.active_plan['pending']:
            if kind == 'forced':
                transition = 'forced_fulfillment'
                self.telemetry['forced_fulfillments'] += 1
            elif taken and pending['kind'] == 'successor' and pending['plan_id'] == self.active_plan['id']:
                transition = 'successor'
                self.telemetry['successor_choices'] += 1
            else:
                transition = 'branch_member_fulfillment'
                self.telemetry['branch_member_fulfillments'] += 1
        if self.active_plan is not None:
            plan = self.active_plan
            plan['pending'] = [list(c) for c in sorted(set(map(placement, plan['expansion'])) - set(engine.selected))]
            if not plan['pending']:
                completed, self.active_plan = True, None
                self.telemetry['completions'] += 1
            else:
                check = self.bank.validate(plan['expansion'], engine.T, engine.M,
                                           set(engine.selected), engine.allowed)
                if not check['valid']:
                    abandonment, self.active_plan = check['reason'], None
                    self.telemetry['abandonments'] += 1
        event = dict(event_type='after_place', ordinal=len(self.events), kind=kind, move=list(move),
            lane=self.public_lane, continuation_enabled=self.continuation, filtered=self.filtered,
            parent=parent, checkpoint_before=before, checkpoint_after=self.checkpoint(),
            preference_taken=taken, transition=transition, completed=completed, abandonment=abandonment)
        self.events.append(event)
        if transition in ('adoption', 'successor'):
            require(self._last_order_index == pending['choice_index'], 'Missing true branch order context.')
            sample = dict(event=detached(event), parent_snapshot=detached(self._last_order_snapshot),
                          after_snapshot=engine.snapshot())
            if self.cluster_events['first'] is None:
                self.cluster_events['first'] = sample
            self.cluster_events['last'] = sample
            self.cluster_events['seen'] += 1
            if transition not in self.plan_examples:
                self.plan_examples[transition] = dict(first=sample, last=sample, seen=1)
            else:
                self.plan_examples[transition]['last'] = sample
                self.plan_examples[transition]['seen'] += 1
        self.telemetry['controller_seconds'] += time.perf_counter() - started

    def snapshot(self):
        result = super().snapshot()
        result.update(schema='Turtle-retained-receptor-controller-v1', lane=self.public_lane,
            checkpoint=self.checkpoint(), events=detached(self.events),
            plan_examples=detached(self.plan_examples),
            interface_records=detached(self.interface_records), interface_samples=detached(self.interface_samples),
            families=detached(self.bank.families), family_sha256=self.bank.family_sha256,
            reused_policy_source_sha256=_REUSE_SHA,
            scope='Retained branch-domain member preferences with complete base fallback; exact transient union interfaces. No atomic macro, new marking, bank admission, geometry predicate or plane claim.')
        return result
