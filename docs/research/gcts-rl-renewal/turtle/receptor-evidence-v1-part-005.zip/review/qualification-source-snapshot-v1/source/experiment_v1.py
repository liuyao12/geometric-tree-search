"""Prospective fixed-bank receptor/continuation study; immutable raw evidence."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
LANES=('MARKED_LEX','HEAD_H','CONT_H','HEAD_V_H','CONT_V_H','CONT_V_RANDOM','CONT_V_ZERO','CONT_V_RL')
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(v):return hashlib.sha256(wire(v)).hexdigest()
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wire(v))
def blob(relative,v):
    p=ROOT/relative;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=1,mtime=0) as f:f.write(wire(v))
    return dict(run_file=relative,run_pin=pin(p))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def check_sources(protocol):
    for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name
def freeze():
    assert not (ROOT/'data/protocol-frozen-v1.json').exists(),'Preserve frozen protocol'
    for name in ('source/point_engine_v3.py','source/continuation_policy_v1.py','reference/continuation_checker_v1.py'):
        assert (ROOT/name).exists(),name
    qualification=load(ROOT/'data/qualification-v1.json');assert qualification['status']=='PASS'
    for name,expected in qualification['source_pins'].items():assert pin(ROOT/name)==expected,name
    cases=load(ROOT/'data/cases-v1.json');assert len(cases['training'])==6 and len(cases['heldout'])==9
    jobs=[]
    for repeat in range(2):
        for i,c in enumerate(cases['heldout']):
            shift=(i+repeat)%len(LANES)
            for lane in LANES[shift:]+LANES[:shift]:jobs.append(dict(index=len(jobs),case_id=c['id'],lane=lane,repeat=repeat,seed=2026110301+repeat*10000+i*101+LANES.index(lane)))
    save(ROOT/'data/evaluation-jobs-v1.json',jobs)
    paths=sorted(p for d in ('source','reference','plan') for p in (ROOT/d).rglob('*') if p.is_file())+sorted((ROOT/'data').glob('*.json'))
    protocol=dict(schema='Turtle-receptor-continuation-protocol-v1',pins={str(p.relative_to(ROOT)):pin(p) for p in paths},lanes=list(LANES),train_case_ids=[c['id'] for c in cases['training']],heldout_case_ids=[c['id'] for c in cases['heldout']],train_episodes=24,train_limit=dict(nodes=200,seconds=2.0,depth=64,cache=64000),test_limit=dict(nodes=400,seconds=4.0,depth=96,cache=64000),training_wall_limit=240,evaluation_wall_limit=1200,process_wall_limit=1800,process_rss_guard_bytes=1600000000,evaluation_jobs=144,repeats=2,initial_weights='all zero',learning_rate=0.03,reward='2*verified_success - verified_negative + verified_core_units/core_total_units - .10*min(search_seconds,limit)/limit - .02*visits/node_limit',training_order='Case episode modulo6; seed2026110301+1987*episode',clusters='Fixed prior32-template bank, all constituent ports, no new admission; at most48cheaptrials and2cheapvalid offers before interface outcomes. Complete transient interface cap50000materializations; unknown refuses only a cluster preference. Retained plans prefer legal members at reference selected branch and keep all base fallback.',scope='Learned restricted marked point model. Finite point-core checkpoints with all untouched zeros activated and free exterior; all exposed frontier must be viable. No fixed impermeable region, plane extension or redundant-marking claim.',comparison='Four heuristic lanes factor retention/interface filtering. RL/random/zero share filtered continuation architecture. All primary methods solve same marked model, targets, base candidate universe, scheduler and caps.',assurance='Every actual native tree independently reconstructed, positive patch/best viable snapshot checked; all actual compact policy events and main controller rollback receipts audited; every retained full interface sample independently compared, all transformed family ports checked. Sampled interfaces are not every interface trial.',costs='Search includes inline proposals, full-frontier filtering, control checkpoints and primitive event recording. Per-run policy/family setup is separate and must be included for method costs; assurance is separate. Training, recording and reused acquisition are not hidden. Posthoc review/report/publication are outside native total.')
    save(ROOT/'data/protocol-frozen-v1.json',protocol);print(json.dumps(dict(status='FROZEN',pins=len(paths),jobs=len(jobs),training=24)),flush=True)

def fixture_bank(P,C,model):
    proof=C.check_cluster(model,[[0,0,0],[1,0,0]]);assert proof['status']=='VERIFIED'
    model_sha=digest(model);t=dict(id='cluster-00',index=0,placements=[[0,0,0],[1,0,0]],port=[0,0,0],origin=dict(source='abstract qualification fixture only'),window=dict(start=0,length=2),verification=proof,model_sha256=model_sha,positive_support_connected=True)
    return dict(schema='Turtle-validated-cluster-bank-v1',model_sha256=model_sha,frozen=True,max_templates=32,templates=[t],admissions=[],admission_seconds=0.0,bank_sha256=digest(dict(model_sha256=model_sha,templates=[t])))

def qualify(E,P,V,C,N,model,groups,bank):
    started=time.perf_counter();records=[]
    class Probe:
        def __init__(self,error=None):self.state={'path':[]};self.events=[];self.error=error;self.calls=0
        def __call__(self,e,c):return c
        def checkpoint(self):return self.state
        def restore(self,s):self.state=s
        def after_place(self,e,c,kind):
            self.calls+=1;self.state['path'].append(list(c));self.events.append(dict(move=list(c),kind=kind,parent=e.control_before))
            if self.error is not None and self.calls==1:raise self.error('deliberate qualification resource interruption')
    for fixture_index,f in enumerate(load(ROOT/'reference/point-qualification-fixtures-v1.json')):
        probe=Probe();kw={k:f[k] for k in ('node_limit','depth_limit','seconds') if k in f};kw.setdefault('seconds',30)
        r=E.search(f['model'],f['seeds'],f['core'],grow=f['grow'],order=probe,control=probe,audit=True,**kw)
        blob('data/qualification-raw/point-%02d.json.gz'%fixture_index,r)
        assert r['status']==f['expected'];t=V.check_tree(f['model'],r);assert t['status']=='VERIFIED'
        checks=[V.check_snapshot(f['model'],s) for s in r['audit_snapshots']];assert all(x['status']=='VERIFIED' for x in checks)
        assert all(x['equal'] and x['before']==x['restored'] for x in r['control_rollback_checks'])
        records.append(dict(name=f['name'],search=r,tree=t,snapshots=checks,observer_events=probe.events))
    full=dict(capacity=12,orientations=[dict(id=i,points=[[0,0,12]]) for i in range(2)],allowed_placements=[[i,0,0] for i in range(2)])
    for error in (E.CacheLimit,TimeoutError):
        p=Probe(error);r=E.search(full,[],[[0,0]],order=p,control=p,audit=True,seconds=30)
        blob('data/qualification-raw/controller-'+error.__name__+'.json.gz',r)
        assert r['status']=='POSITIVE' and len(r['control_rollback_checks'])==1 and V.check_tree(full,r)['status']=='VERIFIED'
        assert p.state['path']==[[1,0,0]]
        records.append(dict(name='partial-controller-'+error.__name__+'-restores-before-sibling',search=r,events=p.events))
    class BadRestore(Probe):
        def restore(self,s):self.state={'path':[['wrong']]}
    p=BadRestore(E.CacheLimit)
    try:E.search(full,[],[[0,0]],order=p,control=p,audit=False,seconds=30)
    except AssertionError:records.append(dict(name='nonrestoring-controller-refused',status='EXPECTED_REJECTION'))
    else:raise AssertionError('Wrong controller restoration accepted')
    class Mutator(Probe):
        def after_place(self,e,c,kind):e.gen[0,0]=99
    try:E.search(full,[],[[0,0]],order=Mutator(),control=Mutator(),audit=True,seconds=30)
    except AssertionError:records.append(dict(name='engine-mutating-after-place-refused',status='EXPECTED_REJECTION'))
    else:raise AssertionError('Mutating lifecycle callback accepted')
    tiny=dict(capacity=12,orientations=[dict(id=i,points=[[0,0,6]]) for i in range(12)],allowed_placements=[[i,0,0] for i in range(12)])
    tb=fixture_bank(P,C,tiny)
    for lane in ('HEAD_H','CONT_H','HEAD_V_H','CONT_V_H'):
        p=P.Controller(tiny,groups,tb,lane,seed=19)
        r=E.search(tiny,[],[[0,0]],order=p,control=p,audit=True,seconds=30);s=p.snapshot();assert r['status']=='POSITIVE'
        blob('data/qualification-raw/'+lane+'.json.gz',dict(search=r,policy=s))
        audit=N.check_policy(tiny,r,s);assert audit['status']=='VERIFIED',audit
        if lane.startswith('CONT_'):assert s['telemetry']['adoptions']>=1 and s['telemetry']['successor_choices']>=1
        else:assert s['telemetry']['adoptions']==0 and s['telemetry']['successor_choices']==0
        records.append(dict(name='actual-continuation-'+lane,search=r,policy=s,assurance=audit))
        if lane=='CONT_V_H':
            mutant=json.loads(wire(s));event=next(e for e in mutant['events'] if e.get('transition')=='successor');index=event['checkpoint_before']['pending_action']['choice_index'];decision=mutant['decisions'][index]
            # Keep each individual step internally compatible while inventing a
            # different retained identity between adoption and the successor.
            decision['checkpoint_after']['active_plan']['id']='plan-999999';decision['checkpoint_after']['pending_action']['plan_id']='plan-999999';decision['chosen_action']['plan_id']='plan-999999'
            event['checkpoint_before']=json.loads(wire(decision['checkpoint_after']))
            order_event=next(e for e in mutant['events'] if e['event_type']=='order' and e['choice_index']==index)
            for field in ('checkpoint_at_call','checkpoint_before','checkpoint_after'):
                if order_event[field]['active_plan'] is not None:order_event[field]['active_plan']['id']='plan-999999'
                if order_event[field]['pending_action'] is not None:order_event[field]['pending_action']['plan_id']='plan-999999'
            for role in ('first','last'):mutant['plan_examples']['successor'][role]['event']=json.loads(wire(event))
            rejected=N.check_policy(tiny,r,mutant);assert rejected['status']=='REJECTED',rejected
            records.append(dict(name='phantom-compatible-retained-plan-refused',mutated_policy=mutant,assurance=rejected))
    fb=P.FrozenBank(tiny,groups,tb)
    e=E.Engine(tiny,[],[[0,0],[100,0]]);parent=e.snapshot();claim=P.check_interface(e,[[0,0,0],[1,0,0]],fb)
    audit=N.check_interface(tiny,parent,[[0,0,0],[1,0,0]],claim);assert claim['status']=='VERIFIED_DEAD' and audit['status']=='VERIFIED',audit
    records.append(dict(name='hypothetical-union-untouched-remote-dead',claim=claim,assurance=audit))
    mutant=json.loads(wire(claim));mutant['domain_sha256']='0'*64;rejected=N.check_interface(tiny,parent,[[0,0,0],[1,0,0]],mutant);assert rejected['status']=='REJECTED';records.append(dict(name='false-interface-domain-hash-refused',assurance=rejected))
    e=E.Engine(tiny,[],[[0,0]]);claim=P.check_interface(e,[[0,0,0]],fb,materialization_cap=0)
    audit=N.check_interface(tiny,e.snapshot(),[[0,0,0]],claim);assert claim['status']=='INTERFACE_UNKNOWN' and audit['status']=='UNKNOWN',audit
    records.append(dict(name='interface-incomplete-not-negative',claim=claim,assurance=audit))
    marked=json.loads(wire(tiny));marked['marking_orientations']=[dict(id=0,points=[[100,100,'far',0]]),dict(id=1,points=[[100,100,'far',1]])]
    # A bank helper carries the model's exact fields; this intentionally invalid
    # proposed pair is NOT admitted as a template.
    mb=P.R.Bank(marked,groups,max_templates=32);e=E.Engine(marked,[],[[0,0]]);claim=P.check_interface(e,[[0,0,0],[1,0,0]],mb)
    audit=N.check_interface(marked,e.snapshot(),[[0,0,0],[1,0,0]],claim);assert claim['status']=='JOINT_INVALID' and audit['status']=='VERIFIED',audit
    records.append(dict(name='remote-assigned-zero-conflict',claim=claim,assurance=audit))
    # Real model qualification is confined to the examined prior cohort.
    old=load(ROOT/'reference/examined-cases-v1.json')['training'][0];e=E.Engine(model,old['seeds'],old['core'],cache_limit=64000)
    audit=V.check_snapshot(model,e.snapshot());assert audit['status']=='VERIFIED';records.append(dict(name='real-model-complete-zero-root-graph',snapshot=e.snapshot(),assurance=audit))
    b=P.FrozenBank(model,groups,bank);family_checks=[]
    for family in b.families:
        template=b.templates[family['index']];port=template['placements'][family['port_index']];inv=b.inverse[port[0]];matrix=b.groups[inv]
        dx=-(matrix[0][0]*port[1]+matrix[0][1]*port[2]);dy=-(matrix[1][0]*port[1]+matrix[1][1]*port[2])
        norm=C.check_transform(model,groups,template['placements'],inv,[dx,dy],family['placements'],normalized=False);assert norm['status']=='VERIFIED',norm
        images=[]
        for g in range(12):
            image=[list(c) for c in b.anchor(family,[g,0,0])];check=C.check_transform(model,groups,family['placements'],g,[0,0],image);assert check['status']=='VERIFIED',check
            images.append(check)
        ref=blob('data/family-checks/'+family['id']+'.json.gz',dict(family=family,normalization=norm,images=images));family_checks.append(dict(family_id=family['id'],**ref))
        if len(family_checks)%32==0 or len(family_checks)==len(b.families):print(json.dumps(dict(phase='FAMILY_QUALIFICATION',checked=len(family_checks),total=len(b.families),images=12*len(family_checks))),flush=True)
    bank_summary=dict(status='VERIFIED',families=len(b.families),images=12*len(b.families),family_sha256=b.family_sha256,checks=family_checks)
    save(ROOT/'data/bank-checks-v1.json',bank_summary)
    ref=blob('data/qualification-records-v1.json.gz',records);summary=dict(status='PASS',records=len(records),seconds=time.perf_counter()-started,bank_checks=bank_summary,**ref)
    save(ROOT/'data/qualification-v1.json',summary);return summary

def assure(V,N,model,result,policy):
    started=time.perf_counter();pa=N.check_policy(model,result,policy) if policy is not None else None
    assert pa is None or pa['status']!='REJECTED',pa
    tree=pa['tree'] if pa is not None and 'tree' in pa else V.check_tree(model,result);assert tree['status']!='REJECTED',tree
    patch=V.check_patch(model,result['placements'],result['core']) if result['status']=='POSITIVE' else None
    best=V.check_snapshot(model,result['final_snapshot']) if result.get('best_prefix_viable') else None
    if best is not None:assert best['status']=='VERIFIED' and not best['dead_points'],best
    interfaces=[]
    if policy is not None:
        for key,pair in policy['interface_samples'].items():
            samples=[pair['first']]
            if wire(pair['first'])!=wire(pair['last']):samples.append(pair['last'])
            for sample in samples:
                receipt=N.check_interface(model,sample['parent_snapshot'],sample['expansion'],sample['receipt']);assert receipt['status']!='REJECTED',receipt
                interfaces.append(dict(sample_key=key,assurance=receipt))
    status=result['status']
    if status=='POSITIVE' and (patch is None or patch['status']!='VERIFIED'):status='UNKNOWN'
    if status=='NEGATIVE' and tree['status']!='VERIFIED':status='UNKNOWN'
    conformance=dict(tree_reconstructed=tree['status']=='VERIFIED',policy_events_verified=pa is None or pa['status']=='VERIFIED',interface_sample_counts={s:sum(x['assurance']['status']==s for x in interfaces) for s in ('VERIFIED','UNKNOWN','REJECTED')})
    return dict(status=status,tree=tree,patch=patch,best=best,policy=pa,interfaces=interfaces,conformance=conformance,seconds=time.perf_counter()-started,scope='Positive status is independently checked patch existence. Tree, policy and interface assurance statuses are separate; UNKNOWN assurance is not a conformance pass.')
def progress(model,result,assurance):
    if not result.get('best_prefix_viable') or assurance['best']['status']!='VERIFIED':return 0
    fields={o['id']:o['points'] for o in model['orientations']};totals={}
    for g,dx,dy in result['placements']:
        for x,y,u in fields[g]:totals[x+dx,y+dy]=totals.get((x+dx,y+dy),0)+u
    units=sum(totals.get(tuple(p),0) for p in result['core']);assert units==result['best_core_units'];return units
def scientific_modules():
    E=module('turtle_point_engine_v3',ROOT/'source/point_engine_v3.py');P=module('turtle_continuations',ROOT/'source/continuation_policy_v1.py')
    V=module('point_checker_v2',ROOT/'reference/independent_checker_v2.py');C=module('cluster_checker',ROOT/'reference/cluster-checker-v1.py');N=module('continuation_checker',ROOT/'reference/continuation_checker_v1.py')
    return E,P,V,C,N
def qualification_only():
    started=time.perf_counter();paths=sorted(p for d in ('source','reference') for p in (ROOT/d).rglob('*') if p.is_file())+[ROOT/'data'/name for name in ('marked-model-v1.json','reused-bank-v1.json','cases-v1.json')];pins={str(p.relative_to(ROOT)):pin(p) for p in paths}
    save(ROOT/'review/qualification-source-before-v1.json',dict(status='FROZEN_BEFORE_QUALIFICATION',pins=pins))
    snapshot=ROOT/'review/qualification-source-snapshot-v1';assert not snapshot.exists(),'Preserve qualification attempt'
    for path in paths:
        target=snapshot/path.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target);assert pin(target)==pin(path)
    E,P,V,C,N=scientific_modules();model=load(ROOT/'data/marked-model-v1.json');bank=load(ROOT/'data/reused-bank-v1.json');groups=load(ROOT/'reference/original-point-data-v1.json')['groups']
    q=qualify(E,P,V,C,N,model,groups,bank)
    for name,expected in pins.items():assert pin(ROOT/name)==expected,name
    q.update(source_pins=pins,qualification_execution_seconds=time.perf_counter()-started);save(ROOT/'data/qualification-v1.json',q)
    print(json.dumps(dict(phase='QUALIFICATION',status=q['status'],records=q['records'],families=q['bank_checks']['families'],images=q['bank_checks']['images'],seconds=q['qualification_execution_seconds'])),flush=True)
def run():
    started=time.perf_counter();protocol=load(ROOT/'data/protocol-frozen-v1.json');check_sources(protocol);E,P,V,C,N=scientific_modules()
    model=load(ROOT/'data/marked-model-v1.json');bank=load(ROOT/'data/reused-bank-v1.json');groups=load(ROOT/'reference/original-point-data-v1.json')['groups'];cases=load(ROOT/'data/cases-v1.json')
    q=load(ROOT/'data/qualification-v1.json');assert q['status']=='PASS'
    setup=time.perf_counter();controller=P.Controller(model,groups,bank,'CONT_V_RL',training=True,seed=2026110301,learning_rate=protocol['learning_rate']);training_setup=time.perf_counter()-setup
    training=[];training_started=time.perf_counter();previous_weights=[0.0]*40;previous_baseline=0.0
    for episode in range(protocol['train_episodes']):
        case=cases['training'][episode%len(cases['training'])]
        if time.perf_counter()-training_started>=protocol['training_wall_limit']:
            training.append(dict(episode=episode,case_id=case['id'],status='UNKNOWN',reason='NOT_RUN_TRAINING_WALL_LIMIT',run_file=None));continue
        controller.start_episode(seed=2026110301+1987*episode);limits=protocol['train_limit']
        assert controller.snapshot()['weights']==previous_weights and controller.baseline==previous_baseline
        r=E.search(model,case['seeds'],case['core'],node_limit=limits['nodes'],seconds=limits['seconds'],depth_limit=limits['depth'],cache_limit=limits['cache'],order=controller,control=controller)
        raw=blob('data/raw/train-%03d-search.json.gz'%episode,r);a=assure(V,N,model,r,controller.snapshot());units=progress(model,r,a);total=model['capacity']*len(case['core'])
        reward=2*int(a['status']=='POSITIVE')-int(a['status']=='NEGATIVE')+units/total-.10*min(r['seconds'],limits['seconds'])/limits['seconds']-.02*r['stats']['visits']/limits['nodes']
        reward_check=dict(status='VERIFIED',success=int(a['status']=='POSITIVE'),negative=int(a['status']=='NEGATIVE'),progress_units=units,core_total_units=total,search_seconds=r['seconds'],seconds_limit=limits['seconds'],visits=r['stats']['visits'],node_limit=limits['nodes'])
        update=controller.finish_episode(reward);policy=controller.snapshot();learning=N.check_learning(policy,reward);assert learning['status']=='VERIFIED',learning
        assert update['weights_before']==previous_weights and update['baseline_before']==previous_baseline
        previous_weights=update['weights_after'];previous_baseline=.9*previous_baseline+.1*reward
        assert policy['weights']==previous_weights and policy['baseline']==previous_baseline
        assert policy['family_sha256']==q['bank_checks']['family_sha256']
        row=dict(episode=episode,case_id=case['id'],lane='CONT_V_RL',status=a['status'],search=r,policy=policy,assurance=a,raw=raw,reward=reward,reward_check=reward_check,update=update,learning_check=learning,setup_seconds=training_setup if episode==0 else 0.0)
        ref=blob('data/training/train-%03d.json.gz'%episode,row);training.append(dict(episode=episode,case_id=case['id'],status=a['status'],search_seconds=r['seconds'],reward=reward,**ref));print(json.dumps(dict(phase='TRAIN',episode=episode,status=a['status'],nodes=r['stats']['visits'],adoptions=policy['telemetry']['adoptions'],successors=policy['telemetry']['successor_choices'],seconds=r['seconds'])),flush=True)
    training_seconds=time.perf_counter()-training_started;frozen_policy=controller.freeze();save(ROOT/'data/frozen-policy-v1.json',frozen_policy);save(ROOT/'data/frozen-bank-v1.json',bank)
    evaluation=[];evaluation_started=time.perf_counter();by_id={c['id']:c for c in cases['heldout']}
    for job in load(ROOT/'data/evaluation-jobs-v1.json'):
        if time.perf_counter()-evaluation_started>=protocol['evaluation_wall_limit']:
            evaluation.append(dict(**job,status='UNKNOWN',reason='NOT_RUN_EVALUATION_WALL_LIMIT',run_file=None));continue
        case=by_id[job['case_id']];lane=job['lane'];limits=protocol['test_limit'];setup=time.perf_counter();control=None
        if lane!='MARKED_LEX':control=P.Controller(model,groups,bank,lane,seed=job['seed'],weights=None if lane=='CONT_V_ZERO' else frozen_policy['weights'])
        setup_seconds=time.perf_counter()-setup
        r=E.search(model,case['seeds'],case['core'],node_limit=limits['nodes'],seconds=limits['seconds'],depth_limit=limits['depth'],cache_limit=limits['cache'],order=control,control=control)
        raw=blob('data/raw/eval-%03d-search.json.gz'%job['index'],r);policy=control.snapshot() if control is not None else None
        if policy is not None:
            assert not policy['training'] and not policy['updates']
            assert policy['weights']==([0.0]*40 if lane=='CONT_V_ZERO' else frozen_policy['weights'])
            assert policy['family_sha256']==q['bank_checks']['family_sha256']
        a=assure(V,N,model,r,policy);learning=N.check_learning(policy) if policy is not None else None
        if learning is not None:assert learning['status']=='VERIFIED',learning
        row=dict(**job,status=a['status'],search=r,policy=policy,assurance=a,learning_check=learning,raw=raw,setup_seconds=setup_seconds,method_seconds=setup_seconds+r['seconds'])
        ref=blob('data/evaluation/eval-%03d.json.gz'%job['index'],row);evaluation.append(dict(**job,status=a['status'],setup_seconds=setup_seconds,search_seconds=r['seconds'],**ref))
        print(json.dumps(dict(phase='EVAL',**job,status=a['status'],nodes=r['stats']['visits'],seconds=r['seconds'],setup_seconds=setup_seconds,adoptions=policy['telemetry']['adoptions'] if policy else 0,successors=policy['telemetry']['successor_choices'] if policy else 0)),flush=True)
    check_sources(protocol);counts={lane:{s:sum(row['lane']==lane and row['status']==s for row in evaluation) for s in ('POSITIVE','NEGATIVE','UNKNOWN')} for lane in LANES}
    parent=load(ROOT/'reference/parent-live-complete-v1.json')
    result=dict(schema='Turtle-receptor-continuation-study-v1',status='COMPLETE_SCHEDULE',protocol=protocol,models=dict(marked=model),groups=groups,cases=cases,training=training,evaluation=evaluation,frozen_bank=bank,frozen_policy=frozen_policy,qualification=q,counts=counts,costs=dict(total_seconds=time.perf_counter()-started,qualification_execution_seconds=q['qualification_execution_seconds'],training_setup_seconds=training_setup,training_seconds=training_seconds,evaluation_seconds=time.perf_counter()-evaluation_started,reused_prior_study_seconds=parent['costs']['total_seconds'],reused_corona_acquisition_seconds=parent['costs']['parent_acquisition_seconds'],input_preparation_seconds=None,reuse_scope='Prior full study includes evaluation and is provenance, not minimal acquisition cost or a measured cold run. Current qualification is a separate measured process; input preparation was not separately timed.'),peak_ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rss_units='bytes on macOS',scope=protocol['scope'])
    blob('data/results-v1.json.gz',result);save(ROOT/'data/completion-v1.json',dict(status='COMPLETE',counts=counts,training_completed=sum(bool(x.get('run_file')) for x in training),evaluation_completed=sum(bool(x.get('run_file')) for x in evaluation),total_seconds=result['costs']['total_seconds'],peak_ru_maxrss=result['peak_ru_maxrss']));print(json.dumps(load(ROOT/'data/completion-v1.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='qualify':qualification_only()
    elif sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='run':run()
    else:raise SystemExit('qualify | freeze | run')
