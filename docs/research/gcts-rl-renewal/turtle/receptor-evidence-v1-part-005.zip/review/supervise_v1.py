"""Bounded task-owned subprocess observer; preserve logs and every terminal exit."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
def main():
    mode=sys.argv[1];assert mode in ('qualify','run')
    prefix='qualification' if mode=='qualify' else 'execution'
    out=ROOT/(prefix+'-v1.log');err=ROOT/(prefix+'-v1.stderr');receipt=ROOT/'review'/(prefix+'-observer-v1.json')
    assert not out.exists() and not err.exists() and not receipt.exists(),'Preserve prior execution'
    runtime=Path(sys.executable).resolve();raw=runtime.read_bytes();start=time.perf_counter();peak=0;reason=None;offset=0;rss_samples=0;rss_failures=0
    with out.open('xb') as log,err.open('xb') as stderr:
        child=subprocess.Popen([str(runtime),'-u','-I','-S','-B',str(ROOT/'source/experiment_v1.py'),mode],cwd=ROOT,stdout=log,stderr=stderr,start_new_session=True)
        print(json.dumps(dict(observer='STARTED',mode=mode,pid=child.pid,runtime=str(runtime))),flush=True)
        while child.poll() is None:
            try:
                rss=subprocess.run(['ps','-o','rss=','-p',str(child.pid)],capture_output=True,text=True,timeout=5)
                if rss.returncode==0 and rss.stdout.strip():peak=max(peak,int(rss.stdout.strip())*1024);rss_samples+=1
            except (OSError,subprocess.TimeoutExpired) as error:
                rss_failures+=1
                if rss_failures==1:print(json.dumps(dict(observer='RSS_OBSERVATION_UNAVAILABLE_CHILD_NOT_RESTARTED',error=str(error))),flush=True)
            if peak>1600000000:reason='EXTERNAL_RSS_GUARD'
            if time.perf_counter()-start>1800:reason='EXTERNAL_WALL_GUARD'
            if reason:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:reason=None
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
                break
            with out.open('rb') as read:
                read.seek(offset);new=read.read();offset=read.tell()
            if new:sys.stdout.buffer.write(new);sys.stdout.flush()
            time.sleep(2)
        code=child.wait()
    with out.open('rb') as read:read.seek(offset);new=read.read()
    if new:sys.stdout.buffer.write(new);sys.stdout.flush()
    result=dict(status='TERMINAL',mode=mode,pid=child.pid,native_exit=code,external_stop_reason=reason,elapsed_seconds=time.perf_counter()-start,observed_peak_rss_bytes=peak,rss_samples=rss_samples,rss_observation_failures=rss_failures,runtime=dict(path=str(runtime),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),version=sys.version),logs=dict(stdout=str(out),stderr=str(err)),scope='Observer uses current child poll and sampled RSS. An observation failure does not stop or restart the child. A guard termination is incomplete evidence/UNKNOWN, never exhausted failure. Native ru_maxrss remains the whole-process memory measurement when completed.')
    receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);raise SystemExit(0 if code==0 and reason is None else 1)
if __name__=='__main__':main()
