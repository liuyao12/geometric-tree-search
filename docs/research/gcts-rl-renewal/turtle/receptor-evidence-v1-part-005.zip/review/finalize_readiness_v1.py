"""Record Root's observed UI checks and join existing audit pins; no science."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def pin(name):
    raw = (ROOT / name).read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def save(name, value):
    path = ROOT / name
    assert not path.exists(), name
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

audit_name = 'review/results-independent-review-v1.json'
audit = json.loads((ROOT / audit_name).read_text())
assert audit['status'] == 'PASS_SAVED_DATA_FINAL_REVIEW'
assert audit['coverage']['training'] == 24
assert audit['coverage']['evaluation'] == 144
assert audit['coverage']['raw_only_policy_missing_indices'] == [40]
for name in ('data/protocol-frozen-v1.json', 'recovery/protocol-frozen-v1.json'):
    protocol = json.loads((ROOT / name).read_text())
    for source, expected in protocol['pins'].items():
        assert pin(source) == expected, source

save('review/local-ui-v1.json', dict(
    status='PASS', method='Root observed existing IAB tab 12 through cua_repl',
    url='http://127.0.0.1:8876/receptor-continuation-v1.html#reader',
    observations=dict(evaluation_options_per_lane=18, training_options=24,
        family_ports=279, visible_family='cluster-31-port-07',
        visible_family_members=8, visible_actual_event=189,
        visible_actual_family='cluster-08-port-01', pending_members=5,
        actual_event_on_checked_returned_path=True,
        marked_view_polygons=17, marked_view_circles=688,
        mathjax_errors=0, horizontal_overflow=False, console_errors=[],
        raw_only_eval_040_unavailability_explicit=True),
    screenshot=dict(path='review/local-reader-v1.png', **pin('review/local-reader-v1.png')),
    source=dict(path='report/receptor-continuation-v1.html', **pin('report/receptor-continuation-v1.html'))))
save('review/publication-readiness-v1.json', dict(
    status='PASS', audit=dict(path=audit_name, **pin(audit_name)),
    original_and_recovery_pins_unchanged=True,
    native_search_rerun=False,
    qualification_exit_observation_limitation_preserved=True,
    raw_only_policy_missing_indices=[40],
    permission='User explicitly approved full evidence archive, including source snapshots, certificates, logs and local file paths, to the existing public GitHub Pages site.',
    scope='Completed retained-continuation study only; research goal remains active.'))
print(json.dumps(dict(status='PASS', audit=audit['status'], source_pins='UNCHANGED')))
