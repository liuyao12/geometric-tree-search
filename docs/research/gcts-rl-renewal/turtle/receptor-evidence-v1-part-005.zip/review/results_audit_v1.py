"""Independent final saved-data audit; no scientific Source imports or replay.

Checks file custody, frozen inputs, complete job binding, receipt coverage,
training arithmetic, counters and directly recorded costs. It reads existing
independent receipts; it never calls a search, point checker or policy helper.
"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math
import time

ROOT = Path(__file__).resolve().parents[1]
VERSION = 'Turtle-receptors-final-saved-data-audit-v1'
TRANSITIONS = ('adoption', 'successor', 'forced_fulfillment', 'branch_member_fulfillment', 'ordinary')


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def sha(value):
    return hashlib.sha256((wire(value)+'\n').encode()).hexdigest()


def close(a, b, reason):
    need(type(a) in (int, float) and type(b) in (int, float) and math.isfinite(a) and math.isfinite(b), reason)
    need(abs(a-b) <= 1e-10*max(1, abs(a), abs(b)), reason)


def same_vectors(a, b, reason):
    need(type(a) is list and type(b) is list and len(a) == len(b), reason)
    for x, y in zip(a, b):
        close(x, y, reason)


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


class Reader:
    def __init__(self):
        self.pins = {}

    def read(self, relative, expected=None):
        path = (ROOT/relative).resolve()
        need(path.is_relative_to(ROOT), 'INPUT_OUTSIDE_RUN')
        data = path.read_bytes()
        actual = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        if expected is not None:
            need(actual == expected, 'FULL_STORED_PIN:'+str(relative))
        raw = gzip.decompress(data) if path.suffix == '.gz' else data
        details = dict(actual, raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest())
        name = str(path.relative_to(ROOT))
        if name in self.pins:
            need(self.pins[name] == details, 'INPUT_CHANGED_BETWEEN_READS:'+name)
        self.pins[name] = details
        return json.loads(raw)

    def ref(self, reference):
        return self.read(reference['run_file'], reference['run_pin'])


def certificate_counts(tree):
    pending, counts = [tree], Counter()
    while pending:
        node = pending.pop()
        counts['certificate_nodes'] += 1
        if 'decision' in node:
            counts['graph_nodes'] += 1
            kind = node['decision']['kind']
            counts[{'branch': 'branch_nodes', 'forced': 'forced_nodes',
                    'dead': 'dead_leaves', 'success': 'positive_leaves'}[kind]] += 1
        else:
            need(node['outcome'] == 'UNKNOWN', 'NONDECISION_NOT_UNKNOWN')
            counts['budget_unknown_leaves'] += 1
        for child in node.get('children', []):
            counts['child_edges'] += 1
            counts['nonpositive_child_edges'] += child['tree']['outcome'] != 'POSITIVE'
            pending.append(child['tree'])
    return counts


def returned_transitions(search, events):
    snapshot = search['final_snapshot']
    if snapshot is None:
        return Counter(), 0
    returned = snapshot['placements']
    counts, matched = Counter(), 0
    for event in events:
        if event['event_type'] != 'after_place':
            continue
        parent = event['parent']['placements']
        n = len(parent)
        if n < len(returned) and parent == returned[:n] and event['move'] == returned[n]['placement']:
            counts[event['transition']] += 1
            matched += 1
    need(matched == len(returned)-snapshot['seed_count'], 'RETURNED_PATH_ACTUAL_EVENT_COVERAGE')
    return counts, matched


def reward_metadata(row, model, limits):
    search, check, assurance = row['search'], row['reward_check'], row['assurance']
    need(check['status'] == 'VERIFIED', 'REWARD_RECEIPT')
    cap, total = model['capacity'], model['capacity']*len(search['core'])
    units = 0
    if search['best_prefix_viable']:
        need(assurance['best']['status'] == 'VERIFIED', 'PROGRESS_NOT_VERIFIED')
        fields = {o['id']: o['points'] for o in model['orientations']}
        totals = {}
        for g, dx, dy in search['placements']:
            for x, y, u in fields[g]:
                p = x+dx, y+dy
                totals[p] = totals.get(p, 0)+u
        units = sum(min(cap, totals.get(tuple(p), 0)) for p in search['core'])
        need(units == search['best_core_units'], 'PROGRESS_UNITS')
    success = int(row['status'] == 'POSITIVE')
    negative = int(row['status'] == 'NEGATIVE' and assurance['tree']['status'] == 'VERIFIED')
    need(check['success'] == success and check['negative'] == negative and
         check['progress_units'] == units and check['core_total_units'] == total, 'REWARD_METADATA')
    close(check['search_seconds'], search['seconds'], 'REWARD_SEARCH_TIME')
    close(check['seconds_limit'], limits['seconds'], 'REWARD_TIME_LIMIT')
    need(check['visits'] == search['stats']['visits'] and check['node_limit'] == limits['nodes'], 'REWARD_NODE_METADATA')
    reward = 2*success-negative+units/total-.10*min(search['seconds'], limits['seconds'])/limits['seconds']-.02*search['stats']['visits']/limits['nodes']
    close(row['reward'], reward, 'REWARD_FORMULA')
    return {'success': success, 'negative': negative, 'progress_units': units, 'total_units': total,
            'reward': reward}


def metric():
    return {'runs': 0, 'outcomes': Counter(), 'search_seconds': 0.0,
            'known_setup_seconds': 0.0, 'setup_missing': 0, 'assurance_seconds': 0.0,
            'stats_sum': Counter(), 'stats_max': {}, 'actual_transitions': Counter(),
            'returned_path_transitions': Counter(), 'trajectory_metadata_missing': 0,
            'returned_path_metadata_missing': 0, 'chosen_nonbase_actions': 0,
            'actual_preferred_cluster_anchors': 0, 'actual_preferred_successor_members': 0,
            'interface_calls': 0, 'interface_viable': 0, 'interface_dead': 0,
            'interface_unknown': 0, 'interface_seconds_nested': 0.0,
            'controller_rollbacks_native': 0, 'primitive_rollbacks_native': 0,
            'order_rollbacks_native': 0, 'controller_seconds_nested': 0.0}


def main():
    started, reader = time.monotonic(), Reader()
    output = ROOT/'review/results-independent-review-v1.json'
    need(not output.exists(), 'EXCLUSIVE_FINAL_REVIEW_EXISTS')
    index = reader.read('data/results-v1.json.gz')
    original = reader.read('data/protocol-frozen-v1.json')
    recovery = reader.read('recovery/protocol-frozen-v1.json')
    need(index['status'] == 'COMPLETE_SCHEDULE_WITH_RECOVERY' and wire(index['protocol']) == wire(original), 'FINAL_INDEX_PROTOCOL')
    need(len(original['pins']) == 24 and len(recovery['pins']) == 8, 'PROTOCOL_PIN_CENSUS')
    for protocol in (original, recovery):
        for name, expected in protocol['pins'].items():
            need(pin(ROOT/name) == expected, 'IMMUTABLE_PROTOCOL_PIN:'+name)
    need(pin(ROOT/'data/protocol-frozen-v1.json') == recovery['original_protocol'], 'RECOVERY_ORIGINAL_PROTOCOL')
    model = reader.read('data/marked-model-v1.json', original['pins']['data/marked-model-v1.json'])
    cases = reader.read('data/cases-v1.json', original['pins']['data/cases-v1.json'])
    jobs = reader.read('data/evaluation-jobs-v1.json', original['pins']['data/evaluation-jobs-v1.json'])
    bank = reader.read('data/frozen-bank-v1.json', recovery['pins']['data/frozen-bank-v1.json'])
    frozen = reader.read('data/frozen-policy-v1.json', recovery['pins']['data/frozen-policy-v1.json'])
    need(wire(model) == wire(index['models']['marked']) and wire(cases) == wire(index['cases']) and
         wire(bank) == wire(index['frozen_bank']) and wire(frozen) == wire(index['frozen_policy']), 'EMBEDDED_FROZEN_CARRIERS')
    need(pin(ROOT/'data/frozen-bank-v1.json') == original['pins']['data/reused-bank-v1.json'], 'BANK_UNCHANGED_FROM_PRIOR')
    need(bank['frozen'] is True and bank['bank_sha256'] == sha({'model_sha256': bank['model_sha256'], 'templates': bank['templates']}), 'FROZEN_BANK_BINDING')
    need(frozen['bank_sha256'] == bank['bank_sha256'] and frozen['weights_sha256'] == sha(frozen['weights']), 'FROZEN_POLICY_BINDING')
    need([c['id'] for c in cases['training']] == original['train_case_ids'] and
         [c['id'] for c in cases['heldout']] == original['heldout_case_ids'], 'CASE_IDS')
    need(not(set(original['train_case_ids']) & set(original['heldout_case_ids'])), 'TRAIN_HELDOUT_IDS')
    need(not({sha(c['core']) for c in cases['training']} & {sha(c['core']) for c in cases['heldout']}), 'EXACT_CORE_SPLIT')
    need(len(index['training']) == 24 and len(index['evaluation']) == len(jobs) == 144, 'COMPLETE_SCHEDULE_CENSUS')
    expected_positions = {(c['id'], lane, repeat) for c in cases['heldout']
                          for lane in original['lanes'] for repeat in range(2)}
    need({(j['case_id'],j['lane'],j['repeat']) for j in jobs} == expected_positions and len(expected_positions) == 144, 'FACTORIAL_COVERAGE')
    case_by_id = {c['id']: c for group in cases.values() for c in group}
    metrics, outcomes, receipts, rows = {}, {}, Counter(), []
    all_native_rollbacks, raw_missing, context_count = 0, [], 0
    history, baseline, prior_weights = [], 0.0, [0.0]*40
    train_rewards, original_records = [], {}
    for phase in ('training', 'evaluation'):
        for position, reference in enumerate(index[phase]):
            need(reference.get('run_file') is not None, 'UNRUN_POSITION_UNEXPECTED')
            row = reader.ref(reference)
            case = case_by_id[reference['case_id']]
            if phase == 'training':
                need(reference['episode'] == row['episode'] == position and case['id'] == original['train_case_ids'][position%6], 'TRAINING_ORDER')
                limits = original['train_limit']
                original_records[reference['run_file']] = reference['run_pin']
            else:
                job = jobs[position]
                for key in ('index','case_id','lane','repeat','seed'):
                    need(type(row[key]) is type(job[key]) and row[key] == reference[key] == job[key], 'PRESCHEDULED_JOB:'+key)
                limits = original['test_limit']
                if position < 40:
                    original_records[reference['run_file']] = reference['run_pin']
            lane, search, assurance = row['lane'], row['search'], row['assurance']
            need(row['case_id'] == reference['case_id'] and row['status'] == reference['status'] == assurance['status'], 'COMPACT_RUN_BINDING')
            need(search['seeds'] == case['seeds'] and search['core'] == case['core'] and search['limits'] == limits and
                 search['grow'] is True and search['criterion'] == 'CORE_COMPLETE_WITH_VIABLE_FRONTIER', 'SEARCH_PROBLEM_BINDING')
            close(reference['search_seconds'], search['seconds'], 'COMPACT_SEARCH_COST')
            raw = reader.ref(row['raw'])
            need(wire(raw) == wire(search), 'RAW_SEARCH_FULL_CONTENT_JOIN')
            if 'context_before_assurance' in row:
                context = reader.ref(row['context_before_assurance'])
                need(phase == 'evaluation' and position >= 41 and context['job'] == jobs[position] and
                     wire(context['policy']) == wire(row['policy']) and context['raw'] == row['raw'] and
                     context['setup_seconds'] == row['setup_seconds'], 'PREASSURANCE_PERSISTED_CONTEXT')
                context_count += 1
            metric_key = phase+'/'+lane
            aggregate = metrics.setdefault(metric_key, metric())
            aggregate['runs'] += 1
            aggregate['outcomes'][row['status']] += 1
            aggregate['search_seconds'] += search['seconds']
            aggregate['assurance_seconds'] += assurance['seconds']
            if row['setup_seconds'] is None:
                aggregate['setup_missing'] += 1
            else:
                aggregate['known_setup_seconds'] += row['setup_seconds']
                if phase == 'evaluation':
                    close(row['method_seconds'], row['setup_seconds']+search['seconds'], 'METHOD_COST')
                    close(reference['setup_seconds'], row['setup_seconds'], 'COMPACT_SETUP_COST')
            for key, value in search['stats'].items():
                if key.startswith('max_'):
                    aggregate['stats_max'][key] = max(aggregate['stats_max'].get(key, 0), value)
                else:
                    aggregate['stats_sum'][key] += value
            tree = assurance['tree']
            need(tree['status'] != 'REJECTED', 'REJECTED_TREE_IN_COMPLETED_STUDY')
            receipts[phase+'/tree/'+tree['status']] += 1
            raw_counts = certificate_counts(search['certificate'])
            need(raw_counts['nonpositive_child_edges'] == search['stats']['backtracks'], 'NATIVE_BACKTRACK_CENSUS')
            if tree['status'] == 'VERIFIED':
                need(tree['outcome'] == search['status'], 'TREE_OUTCOME_RECEIPT')
                for key in ('certificate_nodes','graph_nodes','branch_nodes','forced_nodes','dead_leaves','positive_leaves','budget_unknown_leaves','child_edges'):
                    need(tree['counts'][key] == raw_counts[key], 'TREE_RECEIPT_COUNT:'+key)
            for kind in ('patch','best'):
                receipt = assurance[kind]
                if receipt is not None:
                    need(receipt['status'] != 'REJECTED', 'REJECTED_'+kind.upper())
                    receipts[phase+'/'+kind+'/'+receipt['status']] += 1
            if row['status'] == 'POSITIVE':
                need(search['status'] == 'POSITIVE' and assurance['patch']['status'] == 'VERIFIED', 'POSITIVE_PATCH_ASSURANCE')
            if search['best_prefix_viable']:
                need(assurance['best']['status'] == 'VERIFIED' and assurance['best']['dead_points'] == [], 'BEST_VIABLE_ASSURANCE')
            for item in assurance['interfaces']:
                need(item['assurance']['status'] != 'REJECTED', 'REJECTED_INTERFACE_ASSURANCE')
                receipts[phase+'/interface/'+item['assurance']['status']] += 1
            cr = search.get('control_rollback_checks', [])
            for item in cr:
                need(item['equal'] is True and wire(item['before']) == wire(item['restored']), 'RAW_CONTROLLER_ROLLBACK_EQUALITY')
                need((item['engine_before'] is None and item['engine_restored'] is None) or
                     item['engine_before'] == item['engine_restored'], 'RECORDED_ENGINE_GUARD_EQUALITY')
            primitive = sum(item['kind'] != 'order' for item in cr)
            aggregate['controller_rollbacks_native'] += len(cr)
            aggregate['primitive_rollbacks_native'] += primitive
            aggregate['order_rollbacks_native'] += len(cr)-primitive
            all_native_rollbacks += len(cr)
            policy = row['policy']
            returned = Counter()
            if row.get('policy_missing'):
                need(phase == 'evaluation' and position == 40 and policy is None and row['setup_seconds'] is None and
                     row['method_seconds'] is None and assurance['policy']['status'] == 'UNKNOWN' and
                     row['learning_check']['status'] == 'UNKNOWN', 'RAW40_MISSING_NOT_PRESERVED')
                equal_receipts = assurance['controller_checkpoint_equality_only']
                need(len(equal_receipts) == len(cr) and all(x['status'] == 'VERIFIED' for x in equal_receipts), 'RAW40_EQUALITY_RECEIPT_COVERAGE')
                need(primitive == search['stats']['backtracks'], 'RAW40_NATIVE_ROLLBACK_CENSUS')
                raw_missing.append(position)
                aggregate['trajectory_metadata_missing'] += 1
                aggregate['returned_path_metadata_missing'] += 1
                receipts[phase+'/policy/UNKNOWN_MISSING_METADATA'] += 1
                receipts[phase+'/learning/UNKNOWN_MISSING_METADATA'] += 1
            elif policy is None:
                need(lane == 'MARKED_LEX' and row['learning_check'] is None and not cr, 'NO_CONTROLLER_BASELINE')
                receipts[phase+'/policy/NOT_APPLICABLE_BASELINE'] += 1
                receipts[phase+'/learning/NOT_APPLICABLE_BASELINE'] += 1
            else:
                pa, learning = assurance['policy'], row['learning_check']
                need(pa['status'] != 'REJECTED' and learning['status'] != 'REJECTED', 'REJECTED_POLICY_OR_LEARNER')
                receipts[phase+'/policy/'+pa['status']] += 1
                receipts[phase+'/learning/'+learning['status']] += 1
                need(policy['bank_sha256'] == bank['bank_sha256'] and policy['family_sha256'] == frozen['family_sha256'], 'BANK_OR_FAMILY_CHANGED')
                need(policy['weights_sha256'] == sha(policy['weights']), 'POLICY_WEIGHT_HASH')
                events = policy['events']
                actual = Counter(e['transition'] for e in events if e['event_type'] == 'after_place')
                need(sum(actual.values()) == search['stats']['accepted'], 'ACTUAL_COMPLETED_PRIMITIVE_CENSUS')
                need(primitive == search['stats']['backtracks'], 'NATIVE_CONTROLLER_ROLLBACK_CENSUS')
                if pa['status'] == 'VERIFIED':
                    need(wire(pa['tree']) == wire(tree) and pa['events_checked'] == len(events) and
                         pa['actual_after_place_events'] == sum(actual.values()) and
                         pa['rollback_receipts_checked'] == len(cr) and pa['controller_state_chain']['status'] == 'VERIFIED', 'POLICY_RECEIPT_COVERAGE')
                    need(all(pa['transitions'][key] == actual[key] for key in TRANSITIONS), 'TRANSITION_RECEIPT_COUNTS')
                returned, returned_count = returned_transitions(search, events)
                aggregate['actual_transitions'].update(actual)
                aggregate['returned_path_transitions'].update(returned)
                telemetry = policy['telemetry']
                aggregate['chosen_nonbase_actions'] += telemetry['chosen_cluster_actions']
                for e in events:
                    if e['event_type'] == 'after_place' and e['preference_taken']:
                        pending = e['checkpoint_before']['pending_action']
                        aggregate['actual_preferred_cluster_anchors'] += pending is not None and pending['kind'] == 'adopt'
                        aggregate['actual_preferred_successor_members'] += pending is not None and pending['kind'] == 'successor'
                for key in ('interface_calls','interface_viable','interface_dead','interface_unknown'):
                    aggregate[key] += telemetry[key]
                aggregate['interface_seconds_nested'] += telemetry['interface_seconds']
                aggregate['controller_seconds_nested'] += telemetry['controller_seconds']
                need(telemetry['restores'] == len(cr), 'POLICY_RESTORE_TELEMETRY')
                if phase == 'training':
                    need(policy['training'] is True and policy['episodes'] == position+1 and
                         policy['episode_seed'] == 2026110301+1987*position, 'TRAINING_POLICY_BINDING')
                    update = row['update']
                    need(update['episode'] == position and policy['updates'] == history+[update], 'TRAINING_HISTORY')
                    same_vectors(update['weights_before'], prior_weights, 'TRAINING_WEIGHT_CHAIN')
                    close(update['baseline_before'], baseline, 'TRAINING_BASELINE_CHAIN')
                    reward = reward_metadata(row, model, limits)
                    close(update['reward'], row['reward'], 'UPDATE_REWARD')
                    close(update['advantage'], row['reward']-baseline, 'UPDATE_ADVANTAGE')
                    close(update['learning_rate'], .03, 'LEARNING_RATE')
                    same_vectors(update['gradient'], learning['mean_gradient'], 'CHECKED_GRADIENT_JOIN')
                    after = [max(-8, min(8, w+.03*update['advantage']*g)) for w,g in zip(prior_weights, update['gradient'])]
                    same_vectors(update['weights_after'], after, 'CLIPPED_UPDATE')
                    same_vectors(policy['weights'], after, 'POSTUPDATE_WEIGHTS')
                    baseline = .9*baseline+.1*row['reward']
                    close(policy['baseline'], baseline, 'RUNNING_BASELINE')
                    prior_weights, history = list(policy['weights']), history+[update]
                    train_rewards.append(dict(episode=position,case_id=case['id'],**reward))
                else:
                    need(policy['training'] is False and policy['updates'] == [] and policy['episodes'] == 0 and
                         policy['seed'] == jobs[position]['seed'], 'FROZEN_EVAL_POLICY')
                    need(policy['weights'] == ([0.0]*40 if lane == 'CONT_V_ZERO' else frozen['weights']), 'FROZEN_EVAL_WEIGHTS')
            if phase == 'evaluation':
                outcomes.setdefault(case['id'], {}).setdefault(str(row['repeat']), {})[lane] = row['status']
            rows.append({'phase':phase,'position':position,'case_id':case['id'],'lane':lane,'status':row['status'],
                         'search_seconds':search['seconds'],'setup_seconds':row['setup_seconds'],
                         'method_seconds':row.get('method_seconds'),'tree_status':tree['status'],
                         'policy_status':None if assurance.get('policy') is None else assurance['policy']['status'],
                         'learning_status':None if row.get('learning_check') is None else row['learning_check']['status'],
                         'returned_path_transitions':dict(returned),'policy_missing':row.get('policy_missing',False)})
    need(raw_missing == [40] and context_count == 103, 'RECOVERY_COVERAGE')
    same_vectors(frozen['weights'], prior_weights, 'FINAL_FROZEN_WEIGHTS')
    close(frozen['baseline'], baseline, 'FINAL_FROZEN_BASELINE')
    need(frozen['training'] is False and frozen['episodes'] == 24 and frozen['updates'] == history, 'FROZEN_TRAINING_HISTORY')
    regression = reader.read('review/assurance-projection-regression-v1.json', recovery['pins']['review/assurance-projection-regression-v1.json'])
    need(regression['status'] == 'PASS_RETAINED_PREFIX_PROJECTION_REGRESSION' and regression['relations'] == {'IDENTICAL_VERIFIED_RECEIPT':123}, 'PROJECTION_REGRESSION_RECEIPT')
    for record in regression['records']:
        before = record['record']
        need(original_records[before['relative_path']] == {k:before[k] for k in ('bytes','sha256')}, 'ORIGINAL_COMPLETED_JOB_CHANGED_OR_REEXECUTED')
    need(len(original_records) == 64, 'ORIGINAL_PREFIX_CUSTODY_CENSUS')
    q = reader.read('data/qualification-v1.json', original['pins']['data/qualification-v1.json'])
    need(wire(q) == wire(index['qualification']) and q['status'] == 'PASS' and q['records'] == 26, 'QUALIFICATION_COVERAGE')
    qrecords = reader.ref(q)
    need(len(qrecords) == 26, 'QUALIFICATION_RECORD_REF')
    family_ids, images = [], 0
    for ref in q['bank_checks']['checks']:
        checked = reader.ref(ref)
        need(checked['family']['id'] == ref['family_id'] and checked['normalization']['status'] == 'VERIFIED', 'FAMILY_NORMALIZATION_RECEIPT')
        need([x['action'] for x in checked['images']] == list(range(12)) and
             all(x['status'] == 'VERIFIED' for x in checked['images']), 'ALL_FAMILY_IMAGES_RECEIPTS')
        images += len(checked['images'])
        family_ids.append(ref['family_id'])
    need(len(family_ids) == len(set(family_ids)) == 279 and images == 3348, 'FAMILY_PORT_IMAGE_CENSUS')
    for aggregate in metrics.values():
        aggregate['method_seconds_known_components'] = aggregate['search_seconds']+aggregate['known_setup_seconds']
        aggregate['method_cost_complete'] = aggregate['setup_missing'] == 0
        aggregate['method_cost_scope'] = 'complete setup+search' if aggregate['method_cost_complete'] else 'lower bound: raw40 setup unavailable'
    counts = {lane:{s:metrics['evaluation/'+lane]['outcomes'][s] for s in ('POSITIVE','NEGATIVE','UNKNOWN')}
              for lane in original['lanes']}
    need(counts == index['counts'], 'FINAL_METHOD_OUTCOME_COUNTS')
    completion = reader.read('data/completion-v1.json')
    need(completion['training_completed'] == 24 and completion['evaluation_completed'] == 144 and
         completion['counts'] == counts, 'COMPLETION_RECEIPT')
    old_observer = reader.read('review/execution-observer-v1.json', recovery['pins']['review/execution-observer-v1.json'])
    new_observer = reader.read('review/execution-resume-observer-v1.json')
    need(old_observer['native_exit'] == 1 and new_observer['native_exit'] == 0 and
         new_observer['external_stop_reason'] is None, 'ACTUAL_NATIVE_EXIT_CUSTODY')
    observed_main = old_observer['elapsed_seconds']+new_observer['elapsed_seconds']
    close(index['costs']['original_attempt_seconds'], old_observer['elapsed_seconds'], 'ORIGINAL_COST_CHARGE')
    close(index['costs']['total_seconds'], old_observer['elapsed_seconds']+index['costs']['resume_seconds'], 'PRESERIALIZATION_COST_TIMER')
    train_components = sum(row['search_seconds']+(row['setup_seconds'] or 0) for row in rows if row['phase']=='training')+sum(m['assurance_seconds'] for k,m in metrics.items() if k.startswith('training/'))
    eval_components = sum(row['search_seconds']+(row['setup_seconds'] or 0) for row in rows if row['phase']=='evaluation')+sum(m['assurance_seconds'] for k,m in metrics.items() if k.startswith('evaluation/'))
    close(index['costs']['training_component_seconds'], train_components, 'TRAIN_COMPONENT_SUBTOTAL')
    close(index['costs']['evaluation_component_seconds'], eval_components, 'EVAL_COMPONENT_SUBTOTAL')
    for protocol in (original, recovery):
        for name, expected in protocol['pins'].items():
            need(pin(ROOT/name) == expected, 'PIN_CHANGED_DURING_FINAL_READ:'+name)
    for name, actual in reader.pins.items():
        need(pin(ROOT/name) == {k:actual[k] for k in ('bytes','sha256')}, 'RAW_OR_RECORD_CHANGED_DURING_FINAL_READ:'+name)
    result = {'schema':VERSION,'status':'PASS_SAVED_DATA_FINAL_REVIEW','source':pin(Path(__file__)),
              'inputs':reader.pins,'original_protocol_pins_verified':24,'recovery_protocol_pins_verified':8,
              'coverage':{'training':24,'evaluation':144,'heldout_cases':9,'repeats':2,'lanes':8,
                          'preassurance_contexts_resumed':context_count,'original_completed_prefix_unchanged':64,
                          'raw_only_policy_missing_indices':raw_missing,'qualification_records':26,
                          'family_ports':279,'family_images':3348},
              'counts':counts,'per_case_outcomes':outcomes,'metrics':metrics,'rows':rows,
              'receipt_coverage':dict(receipts),'native_controller_rollback_receipts':all_native_rollbacks,
              'training_reward_and_update_metadata':train_rewards,
              'frozen_weights_sha256':frozen['weights_sha256'],'frozen_bank_sha256':bank['bank_sha256'],
              'costs':{'original_attempt_observer_seconds':old_observer['elapsed_seconds'],
                       'resume_observer_seconds':new_observer['elapsed_seconds'],
                       'authoritative_observed_main_attempts_seconds':observed_main,
                       'stored_preserialization_main_timer_seconds':index['costs']['total_seconds'],
                       'unmeasured_by_preserialization_timer_seconds':observed_main-index['costs']['total_seconds'],
                       'separate_projection_regression_seconds':regression['seconds'],
                       'separate_qualification_function_seconds':q['qualification_execution_seconds'],
                       'training_component_subtotal_seconds':train_components,
                       'evaluation_component_subtotal_seconds':eval_components,
                       'raw40_setup_seconds':None,'original_phase_timers':None,
                       'scope':'Main process observer durations include final serialization. Projection regression occurred separately before resume. Qualification is a separately measured function with earlier launcher exit-observation limitation. Component and nested inline timings are not disjoint phase totals or a cold acquisition cost.'},
              'limitations':['Raw40 has a checked positive tree/patch and exact native rollback equality receipts, but no policy, actual transition labels, learning record or setup duration. It is excluded from actual/returned-path transition aggregates.',
                             'UNKNOWN search and interface/resource receipts remain unresolved. Saved receipt coverage is audited without executing their algorithms again.',
                             'Returned-path transitions concern the saved best viable snapshot for UNKNOWN runs, and the checked final patch for positives; they are not all attempted trajectory transitions.',
                             'No superiority, causal policy gain, unrestricted unmarked tiling, impermeable-region or plane-extension claim.'],
              'seconds':time.monotonic()-started,
              'scope':'Independent stdlib-only saved-data hashes, associations, arithmetic, counters and assurance coverage. No scientific Source imports, search/learning/checker replay, or original-file mutation.'}
    with output.open('x') as f:
        f.write(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n')
    print(wire({'status':result['status'],'counts':counts,'coverage':result['coverage'],
                'receipt_coverage':result['receipt_coverage'],'native_controller_rollbacks':all_native_rollbacks,
                'output_pin':pin(output),'seconds':result['seconds']}),flush=True)


if __name__ == '__main__':
    main()
