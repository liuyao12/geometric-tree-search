"""Restore only declared byte-identical public copies; verify every original."""
import hashlib,json,shutil
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
def safe(name):
    p=PurePosixPath(name)
    assert name and not p.is_absolute() and p.as_posix()==name and '..' not in p.parts and '\\' not in name
    target=ROOT/name;assert ROOT in target.resolve().parents
    return target
def pin(path):
    h=hashlib.sha256();n=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return n,h.hexdigest()
def main():
    m=json.loads((ROOT/'ARCHIVE-file-manifest-v1.json').read_text());restored=0
    for e in m['files']:
        source=safe(e['stored_path']);assert pin(source)==(e['bytes'],e['sha256'])
        target=safe(e['path'])
        if source!=target:
            if target.exists():assert pin(target)==(e['bytes'],e['sha256']),'Refusing to overwrite different bytes'
            else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);restored+=1
    for e in m['files']:assert pin(safe(e['path']))==(e['bytes'],e['sha256'])
    print(json.dumps(dict(status='ALL_ORIGINAL_PATHS_VERIFIED',original_files=len(m['files']),restored_public_copies=restored)))
if __name__=='__main__':main()
