"""Independent exact point-graph verifier; stdlib only, no search/engine imports.

Coordinates and t-units are native integers. Mark values are typed native JSON;
missing marks are unconstrained, whereas every supplied value (including 0,
False and null) is assigned. No geometric test participates in base legality.
"""
import hashlib
import json

VERSION = 'Turtle-independent-point-graph-checker-v2'
MAX_ORIENTATIONS = 256
MAX_SUPPORT = 4096
MAX_PLACEMENTS = 4096
MAX_POINTS = 100000
MAX_CANDIDATES = 1000000
MAX_WORK = 100000000
MAX_JSON_NODES = 5000000
MAX_CERTIFICATE_NODES = 200000
MAX_CERTIFICATE_DEPTH = 256


class Invalid(Exception):
    pass


class Resource(Exception):
    pass


def _need(condition, reason):
    if not condition:
        raise Invalid(reason)


def _integer(value):
    return type(value) is int and value.bit_length() <= 128


def _json(value, depth=0, meter=None):
    if meter is None:
        meter = [0]
    meter[0] += 1
    if meter[0] > MAX_JSON_NODES or depth > 64:
        raise Resource('JSON_RESOURCE_LIMIT')
    if value is None or type(value) in (bool, int):
        if type(value) is int and value.bit_length() > 128:
            raise Resource('INTEGER_BITS_LIMIT')
    elif type(value) is str:
        if len(value) > 1000000:
            raise Resource('STRING_LIMIT')
    elif type(value) is list:
        for item in value:
            _json(item, depth+1, meter)
    elif type(value) is dict:
        _need(all(type(k) is str for k in value), 'JSON_OBJECT_KEY')
        for item in value.values():
            _json(item, depth+1, meter)
    else:
        raise Invalid('NON_NATIVE_OR_INEXACT_JSON')


def _wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _point(value):
    _need(type(value) is list and len(value) == 2 and all(_integer(x) for x in value),
          'POINT_FORMAT')
    return tuple(value)


def _placement(value):
    _need(type(value) is list and len(value) == 3 and all(_integer(x) for x in value),
          'PLACEMENT_FORMAT')
    return tuple(value)


def _core(value):
    if value is None:
        return None
    _need(type(value) is list, 'CORE_FORMAT')
    if len(value) > MAX_POINTS:
        raise Resource('CORE_POINT_LIMIT')
    points = [_point(p) for p in value]
    _need(len(points) == len(set(points)), 'DUPLICATE_CORE_POINT')
    return set(points)


class _Verifier:
    def __init__(self, model):
        _json(model)
        _need(type(model) is dict and set(model) <= {
            'capacity', 'orientations', 'marking_orientations', 'allowed_placements'} and
            {'capacity', 'orientations'} <= set(model), 'MODEL_FIELDS')
        self.capacity = model['capacity']
        _need(_integer(self.capacity) and 0 < self.capacity <= 1000000, 'CAPACITY')
        rows = model['orientations']
        _need(type(rows) is list and rows, 'ORIENTATIONS')
        if len(rows) > MAX_ORIENTATIONS:
            raise Resource('ORIENTATION_LIMIT')
        self.orientations, self.marks = {}, {}
        for row in rows:
            _need(type(row) is dict and set(row) == {'id', 'points'} and _integer(row['id']),
                  'ORIENTATION_FORMAT')
            oid = row['id']
            _need(oid not in self.orientations, 'DUPLICATE_ORIENTATION_ID')
            points = row['points']
            _need(type(points) is list and points, 'EMPTY_T_SUPPORT')
            if len(points) > MAX_SUPPORT:
                raise Resource('SUPPORT_LIMIT')
            support = {}
            for p in points:
                _need(type(p) is list and len(p) == 3 and all(_integer(x) for x in p),
                      'T_POINT_FORMAT')
                x, y, units = p
                _need(0 < units <= self.capacity and (x, y) not in support, 'T_VALUE_OR_DUPLICATE')
                support[x, y] = units
            self.orientations[oid] = support
            self.marks[oid] = {}
        mrows = model.get('marking_orientations', [])
        _need(type(mrows) is list, 'MARKING_ORIENTATIONS')
        seen = set()
        for row in mrows:
            _need(type(row) is dict and set(row) == {'id', 'points'} and _integer(row['id']) and
                  row['id'] in self.orientations and row['id'] not in seen, 'MARK_ORIENTATION')
            seen.add(row['id'])
            _need(type(row['points']) is list, 'MARK_SUPPORT')
            if len(row['points']) > MAX_SUPPORT:
                raise Resource('MARK_SUPPORT_LIMIT')
            for p in row['points']:
                _need(type(p) is list and len(p) == 4 and all(_integer(x) for x in p[:2]) and
                      (type(p[2]) is str or _integer(p[2])), 'MARK_POINT_FORMAT')
                x, y, channel, value = p
                key = x, y, _wire(channel)
                _need(key not in self.marks[row['id']], 'DUPLICATE_MARK_POINT_CHANNEL')
                self.marks[row['id']][key] = _wire(value)
        self.allowed = None
        if 'allowed_placements' in model:
            _need(type(model['allowed_placements']) is list, 'ALLOWED_PLACEMENTS')
            if len(model['allowed_placements']) > MAX_CANDIDATES:
                raise Resource('ALLOWED_PLACEMENT_LIMIT')
            allowed = [self.placement(p) for p in model['allowed_placements']]
            _need(len(allowed) == len(set(allowed)), 'DUPLICATE_ALLOWED_PLACEMENT')
            self.allowed = set(allowed)
        self.work = 0

    def tick(self, units=1):
        self.work += units
        if self.work > MAX_WORK:
            raise Resource('WORK_LIMIT')

    def placement(self, value):
        p = _placement(value)
        _need(p[0] in self.orientations, 'UNKNOWN_ORIENTATION')
        return p

    def t_rows(self, placement):
        oid, dx, dy = placement
        for (x, y), units in self.orientations[oid].items():
            yield (x+dx, y+dy), units

    def m_rows(self, placement):
        oid, dx, dy = placement
        for (x, y, channel), value in self.marks[oid].items():
            yield (x+dx, y+dy, channel), value

    def state(self, placements, core, generations=None, seed_count=None):
        _need(type(placements) is list, 'PLACEMENTS')
        if len(placements) > MAX_PLACEMENTS:
            raise Resource('PLACEMENT_LIMIT')
        selected, totals, marks = set(), {}, {}
        point_gens = {p: 0 for p in core or ()}
        if generations is not None:
            _need(_integer(seed_count) and 0 <= seed_count <= len(placements), 'SEED_COUNT')
            _need(len(generations) == len(placements), 'GENERATION_COUNT')
        canonical = []
        for index, row in enumerate(placements):
            p = self.placement(row)
            _need(p not in selected and (self.allowed is None or p in self.allowed),
                  'SELECTED_DUPLICATE_OR_OUTSIDE_INVENTORY')
            trows = list(self.t_rows(p))
            generation = 0
            if generations is not None:
                generation = generations[index]
                _need(_integer(generation) and generation >= 0, 'TILE_GENERATION')
                if index < seed_count:
                    _need(generation == 0, 'SEED_GENERATION')
                else:
                    incident = [point_gens[q] for q, _ in trows if q in point_gens]
                    _need(bool(incident), 'UNDECLARED_DISCONNECTED_ROOT')
                    _need(generation == 1+min(incident), 'TILE_GENERATION_RECURRENCE')
            for q, units in trows:
                self.tick()
                totals[q] = totals.get(q, 0)+units
                _need(totals[q] <= self.capacity, 'SELECTED_T_OVER_CAPACITY')
                point_gens[q] = min(point_gens.get(q, generation), generation)
            for q, value in self.m_rows(p):
                self.tick()
                _need(q not in marks or marks[q] == value, 'SELECTED_MARK_CONFLICT')
                marks[q] = value
            selected.add(p)
            canonical.append(p)
        if len(totals.keys() | point_gens.keys()) > MAX_POINTS:
            raise Resource('EXPOSED_POINT_LIMIT')
        return {'selected': selected, 'placements': canonical, 'totals': totals,
                'marks': marks, 'generations': point_gens}

    def legal(self, placement, state):
        if placement in state['selected'] or (self.allowed is not None and placement not in self.allowed):
            return False
        for q, units in self.t_rows(placement):
            self.tick()
            if state['totals'].get(q, 0)+units > self.capacity:
                return False
        for q, value in self.m_rows(placement):
            self.tick()
            if q in state['marks'] and state['marks'][q] != value:
                return False
        return True

    def graph(self, state, core, grow):
        _need(type(grow) is bool, 'GROW_BOOL')
        _need(grow or core is not None, 'FINITE_TARGET_REQUIRES_CORE')
        active = set(core or ())
        if grow:
            active.update(state['totals'])
        frontier = sorted(q for q in active if state['totals'].get(q, 0) < self.capacity)
        if len(frontier) > MAX_POINTS:
            raise Resource('FRONTIER_LIMIT')
        domains, validity = {}, {}
        for qx, qy in frontier:
            domain = set()
            for oid, support in self.orientations.items():
                for sx, sy in support:
                    self.tick()
                    p = oid, qx-sx, qy-sy
                    if p not in validity:
                        if len(validity) >= MAX_CANDIDATES:
                            raise Resource('CANDIDATE_LIMIT')
                        validity[p] = self.legal(p, state)
                    if validity[p]:
                        domain.add(p)
            domains[qx, qy] = sorted(domain)
        return domains


def _summary(verifier, state, domains, core, grow):
    dead = sorted(q for q, candidates in domains.items() if not candidates)
    unique = set(c for candidates in domains.values() for c in candidates)
    filled = core is None or all(state['totals'].get(q, 0) == verifier.capacity for q in core)
    rows = [{'point': list(q), 'candidates': [list(c) for c in domains[q]]} for q in sorted(domains)]
    gens = [[x, y, g] for (x, y), g in sorted(state['generations'].items())]
    graph_wire = _wire({'domains': rows, 'point_generations': gens,
                        'edge_units': _edges(verifier, domains)})+'\n'
    return {'placements': len(state['selected']), 'positive_points': len(state['totals']),
            'mark_assignments': len(state['marks']), 'frontier_points': len(domains),
            'candidate_nodes': len(unique), 'incidences': sum(map(len, domains.values())),
            'core_points': None if core is None else len(core), 'core_filled': filled,
            'grow': grow, 'dead_points': [list(q) for q in dead], 'work': verifier.work,
            'graph_sha256': hashlib.sha256(graph_wire.encode()).hexdigest()}


def _edges(verifier, domains):
    return [[qx, qy, oid, dx, dy, verifier.orientations[oid][qx-dx, qy-dy]]
            for (qx, qy), candidates in sorted(domains.items())
            for oid, dx, dy in candidates]


def _decision(state, domains, target, filled):
    priority = lambda q: (state['generations'][q], len(domains[q]), q[0], q[1])
    dead = [q for q in domains if not domains[q]]
    forced = [q for q in domains if len(domains[q]) == 1]
    if dead:
        kind, point = 'dead', min(dead, key=priority)
    elif target is not None and filled:
        kind, point = 'success', None
    elif forced:
        kind, point = 'forced', min(forced, key=priority)
    elif domains:
        kind, point = 'branch', min(domains, key=priority)
    else:
        kind, point = 'success', None
    return {'kind': kind, 'point': None if point is None else list(point),
            'candidates': [] if point is None else [list(c) for c in domains[point]]}


def _check_decision(verifier, supplied, expected):
    _need(type(supplied) is dict and set(supplied) == {'kind', 'point', 'candidates'}, 'DECISION_FIELDS')
    _need(supplied['kind'] == expected['kind'], 'SCHEDULER_PRIORITY')
    if supplied['point'] is not None:
        _point(supplied['point'])
    _need(supplied['point'] == expected['point'], 'SCHEDULER_POINT_TIEBREAK')
    _need(type(supplied['candidates']) is list, 'DECISION_CANDIDATES')
    candidates = [verifier.placement(p) for p in supplied['candidates']]
    _need(len(candidates) == len(set(candidates)) and
          sorted(candidates) == [tuple(c) for c in expected['candidates']], 'DECISION_FULL_DOMAIN')


def _receipt(operation, call):
    try:
        result = call()
        return dict(version=VERSION, operation=operation, **result)
    except Invalid as error:
        return {'version': VERSION, 'operation': operation, 'status': 'REJECTED', 'reason': str(error)}
    except Resource as error:
        return {'version': VERSION, 'operation': operation, 'status': 'UNKNOWN', 'reason': str(error)}
    except (KeyError, IndexError, TypeError, ValueError, RecursionError) as error:
        return {'version': VERSION, 'operation': operation, 'status': 'REJECTED',
                'reason': 'MALFORMED_INPUT:'+type(error).__name__}


def check_patch(model, placements, core=None, *, grow=True):
    """Verify a corona (explicit core) or viable finite growth patch (core=None).

    VERIFIED requires legal distinct placements, all explicit core points filled,
    and no degree-zero active frontier point. It asserts no infinite extension.
    grow=False activates only the explicit core, while checking global legality.
    """
    def run():
        _json(placements)
        _json(core)
        verifier = _Verifier(model)
        target = _core(core)
        state = verifier.state(placements, target)
        domains = verifier.graph(state, target, grow)
        summary = _summary(verifier, state, domains, target, grow)
        status = 'VERIFIED' if not summary['dead_points'] and summary['core_filled'] else 'REJECTED'
        reason = ('VIABLE_FINITE_PATCH' if target is None else 'CORE_FILLED_WITH_VIABLE_FRONTIER')
        if summary['dead_points']:
            reason = 'GLOBAL_DEAD_FRONTIER'
        elif not summary['core_filled']:
            reason = 'CORE_NOT_FILLED'
        return dict(status=status, reason=reason, consistent=True, **summary)
    return _receipt('check_patch', run)


def check_snapshot(model, snapshot, *, grow=True):
    """Reconstruct every candidate/domain and independently validate scheduling.

    Initial seed_count placements must have generation zero. Subsequent tiles
    must contact an already exposed positive point or an explicit core root.
    Point generations cover ALL positive support plus core, even in finite mode.
    Ties use (generation, degree, x, y) for dead, forced and branch choices.
    """
    def run():
        _json(snapshot)
        _need(type(snapshot) is dict and set(snapshot) <= {
            'placements', 'seed_count', 'point_generations', 'core', 'domains', 'edge_units', 'decision', 'grow'}
            and {'placements', 'seed_count', 'point_generations', 'core', 'domains', 'edge_units', 'decision'} <= set(snapshot),
            'SNAPSHOT_FIELDS')
        mode = snapshot.get('grow', grow)
        target = _core(snapshot['core'])
        verifier = _Verifier(model)
        _need(type(snapshot['placements']) is list, 'SNAPSHOT_PLACEMENTS')
        rows, generations = [], []
        for row in snapshot['placements']:
            _need(type(row) is dict and set(row) == {'placement', 'generation'}, 'SNAPSHOT_PLACEMENT_ROW')
            rows.append(row['placement'])
            generations.append(row['generation'])
        state = verifier.state(rows, target, generations, snapshot['seed_count'])
        supplied_gens = {}
        _need(type(snapshot['point_generations']) is list, 'POINT_GENERATIONS')
        for row in snapshot['point_generations']:
            _need(type(row) is list and len(row) == 3 and all(_integer(x) for x in row) and row[2] >= 0,
                  'POINT_GENERATION_ROW')
            _need(tuple(row[:2]) not in supplied_gens, 'DUPLICATE_POINT_GENERATION')
            supplied_gens[tuple(row[:2])] = row[2]
        _need(supplied_gens == state['generations'], 'POINT_GENERATION_RECONSTRUCTION')
        domains = verifier.graph(state, target, mode)
        supplied_domains = {}
        _need(type(snapshot['domains']) is list, 'DOMAINS')
        for row in snapshot['domains']:
            _need(type(row) is dict and set(row) == {'point', 'candidates'}, 'DOMAIN_ROW')
            q = _point(row['point'])
            _need(q not in supplied_domains and type(row['candidates']) is list, 'DUPLICATE_DOMAIN')
            candidates = [verifier.placement(p) for p in row['candidates']]
            _need(len(candidates) == len(set(candidates)), 'DUPLICATE_DOMAIN_CANDIDATE')
            supplied_domains[q] = sorted(candidates)
        _need(supplied_domains == domains, 'COMPLETE_FRONTIER_CANDIDATE_GRAPH')
        _need(type(snapshot['edge_units']) is list, 'EDGE_UNITS')
        for row in snapshot['edge_units']:
            _need(type(row) is list and len(row) == 6 and all(_integer(x) for x in row),
                  'EDGE_UNITS_ROW')
        _need(sorted(snapshot['edge_units']) == _edges(verifier, domains), 'EXACT_EDGE_CONTRIBUTIONS')
        summary = _summary(verifier, state, domains, target, mode)
        expected = _decision(state, domains, target, summary['core_filled'])
        _check_decision(verifier, snapshot['decision'], expected)
        return dict(status='VERIFIED', reason='EXACT_GRAPH_GENERATIONS_AND_SCHEDULER',
                    expected_decision=expected, **summary)
    return _receipt('check_snapshot', run)


def check_rollback(before, restored):
    """Typed JSON equality of every supplied snapshot field, including list order.

    Does not certify that the fields are complete; independently check both
    snapshots with check_snapshot to establish point-graph validity as well.
    """
    def run():
        _json(before)
        _json(restored)
        a, b = _wire(before), _wire(restored)
        _need(a == b, 'ROLLBACK_STATE_CHANGED')
        return {'status': 'VERIFIED', 'reason': 'EXACT_TYPED_JSON_ROLLBACK_EQUALITY',
                'snapshot_sha256': hashlib.sha256((a+'\n').encode()).hexdigest()}
    return _receipt('check_rollback', run)


def _tree_json(value):
    """Iterative preflight avoids the shallow ordinary-snapshot JSON depth cap."""
    pending, nodes = [(value, 0)], 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        if nodes > MAX_JSON_NODES or depth > 4*MAX_CERTIFICATE_DEPTH+16:
            raise Resource('CERTIFICATE_JSON_LIMIT')
        if item is None or type(item) in (bool, int, str):
            if type(item) is int and item.bit_length() > 128:
                raise Resource('INTEGER_BITS_LIMIT')
            if type(item) is str and len(item) > 1000000:
                raise Resource('STRING_LIMIT')
        elif type(item) is list:
            pending.extend((v, depth+1) for v in item)
        elif type(item) is dict:
            _need(all(type(k) is str for k in item), 'JSON_OBJECT_KEY')
            pending.extend((v, depth+1) for v in item.values())
        else:
            raise Invalid('NON_NATIVE_OR_INEXACT_JSON')


def check_tree(model, result):
    """Validate a finite search certificate through independently replayed states.

    Every real node reconstructs its entire point graph and scheduler decision.
    A negative internal node must cover its exact legal decision domain, once
    each, with negative children. Positive nodes require a positive descendant;
    missing or budget-limited children never support a negative conclusion.
    Ancillary execution statistics/logs are not scientific premises of this API.
    """
    def run():
        _need(type(result) is dict and {'seeds', 'core', 'certificate', 'grow'} <= set(result),
              'RESULT_FIELDS')
        carrier = {k: result[k] for k in ('seeds', 'core', 'certificate', 'grow')}
        if 'status' in result:
            carrier['status'] = result['status']
        _tree_json(carrier)
        verifier = _Verifier(model)
        target = _core(result['core'])
        grow = result['grow']
        _need(type(grow) is bool, 'GROW_BOOL')
        _need(type(result['seeds']) is list, 'SEEDS')
        seeds = [list(verifier.placement(p)) for p in result['seeds']]
        verifier.state(seeds, target, [0]*len(seeds), len(seeds))
        counts = dict(certificate_nodes=0, graph_nodes=0, positive_leaves=0,
                      dead_leaves=0, budget_unknown_leaves=0, branch_nodes=0,
                      forced_nodes=0, positive_nodes=0, negative_nodes=0,
                      unknown_nodes=0, child_edges=0, max_depth=0)
        graph_digest = hashlib.sha256()
        witness_matches = [False]
        expected_witness = None
        if 'placements' in result and result.get('status') == 'POSITIVE':
            _json(result['placements'])
            _need(type(result['placements']) is list and len(result['placements']) <= MAX_PLACEMENTS,
                  'RESULT_POSITIVE_WITNESS')
            expected_witness = [list(verifier.placement(p)) for p in result['placements']]

        def visit(node, prefix, generations, depth):
            counts['certificate_nodes'] += 1
            counts['max_depth'] = max(counts['max_depth'], depth)
            if counts['certificate_nodes'] > MAX_CERTIFICATE_NODES or depth > MAX_CERTIFICATE_DEPTH:
                raise Resource('CERTIFICATE_NODE_OR_DEPTH_LIMIT')
            _need(type(node) is dict and node.get('outcome') in ('POSITIVE', 'NEGATIVE', 'UNKNOWN'),
                  'CERTIFICATE_NODE_OUTCOME')
            if 'decision' not in node:
                _need(set(node) == {'outcome', 'limit'} and node['outcome'] == 'UNKNOWN' and
                      node['limit'] in ('nodes', 'seconds', 'depth', 'cache'), 'BUDGET_LEAF_FORMAT')
                counts['budget_unknown_leaves'] += 1
                counts['unknown_nodes'] += 1
                return 'UNKNOWN'
            _need(set(node) <= {'decision', 'outcome', 'children', 'graph_sha256'} and
                  {'decision', 'outcome', 'children'} <= set(node) and type(node['children']) is list,
                  'CERTIFICATE_NODE_FIELDS')
            state = verifier.state(prefix, target, generations, len(seeds))
            domains = verifier.graph(state, target, grow)
            summary = _summary(verifier, state, domains, target, grow)
            decision = _decision(state, domains, target, summary['core_filled'])
            _check_decision(verifier, node['decision'], decision)
            if 'graph_sha256' in node:
                _need(node['graph_sha256'] == summary['graph_sha256'], 'CERTIFICATE_GRAPH_HASH')
            counts['graph_nodes'] += 1
            graph_digest.update((_wire([depth, prefix, summary['graph_sha256']])+'\n').encode())
            children = node['children']
            kind = decision['kind']
            if kind in ('dead', 'success'):
                derived = 'NEGATIVE' if kind == 'dead' else 'POSITIVE'
                _need(not children and node['outcome'] == derived, 'TERMINAL_OUTCOME_OR_CHILDREN')
                counts['dead_leaves' if kind == 'dead' else 'positive_leaves'] += 1
                counts['negative_nodes' if kind == 'dead' else 'positive_nodes'] += 1
                if kind == 'success' and (expected_witness is None or prefix == expected_witness):
                    witness_matches[0] = True
                return derived
            counts['forced_nodes' if kind == 'forced' else 'branch_nodes'] += 1
            allowed = {tuple(p) for p in decision['candidates']}
            seen, outcomes = set(), []
            for child in children:
                _need(type(child) is dict and set(child) == {'move', 'tree'}, 'CHILD_FIELDS')
                move = verifier.placement(child['move'])
                _need(move in allowed and move not in seen, 'CHILD_OUTSIDE_DOMAIN_OR_DUPLICATE')
                seen.add(move)
                incident = [state['generations'][q] for q, _ in verifier.t_rows(move)
                            if q in state['generations']]
                _need(bool(incident), 'CHILD_DISCONNECTED_MOVE')
                generation = 1+min(incident)
                counts['child_edges'] += 1
                outcomes.append(visit(child['tree'], prefix+[list(move)],
                                      generations+[generation], depth+1))
            if 'POSITIVE' in outcomes:
                derived = 'POSITIVE'
            elif seen == allowed and all(value == 'NEGATIVE' for value in outcomes):
                derived = 'NEGATIVE'
            else:
                derived = 'UNKNOWN'
            _need(node['outcome'] == derived, 'INTERNAL_OUTCOME_NOT_JUSTIFIED')
            counts[derived.lower()+'_nodes'] += 1
            return derived

        outcome = visit(result['certificate'], seeds, [0]*len(seeds), 0)
        if 'status' in result:
            _need(result['status'] == outcome, 'RESULT_STATUS_CERTIFICATE_OUTCOME')
        if outcome == 'POSITIVE' and expected_witness is not None:
            _need(witness_matches[0], 'RESULT_WITNESS_NOT_CERTIFIED_POSITIVE_PATH')
        return {'status': 'VERIFIED', 'reason': 'INDEPENDENT_COMPLETE_FINITE_SEARCH_CERTIFICATE',
                'outcome': outcome, 'counts': counts, 'seed_count': len(seeds),
                'core_points': None if target is None else len(target), 'grow': grow,
                'work': verifier.work, 'ordered_node_graph_digest_sha256': graph_digest.hexdigest(),
                'positive_result_witness_bound': expected_witness is not None,
                'scope': 'Finite search certificate only; UNKNOWN remains unresolved. No engine execution, geometry, known tiling, plane-extension or redundant-marking claim.'}
    return _receipt('check_tree', run)
