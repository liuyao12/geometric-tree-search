"""Independent receptor-interface, actual-transition and learner assurances.

Only the exact pinned independent point checker may be imported lazily. No
Root engine, policy, proposer, search or geometric code is imported. Interface
viability is not a scheduler-realizability or infinite-extension assertion.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math

VERSION = 'Turtle-independent-receptor-continuation-checker-v1'
POINT_SHA256 = 'f05e1315fe3af0b902fc87aa28992a7f0685fc65f2dcab02b7e9fa50e6b180bd'
TOLERANCE = 1e-11
_POINT = None


class Invalid(ValueError):
    pass


class Resource(ValueError):
    pass


def _need(condition, reason):
    if not condition:
        raise Invalid(reason)


def _wire(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _sha(value):
    return hashlib.sha256((_wire(value)+'\n').encode('ascii')).hexdigest()


def _same(a, b):
    return _wire(a) == _wire(b)


def _native(value):
    """Exact JSON, allowing finite heuristic floats but no opaque objects/cycles."""
    stack, active, count = [(value, 0, False)], set(), 0
    while stack:
        item, depth, leaving = stack.pop()
        if leaving:
            active.remove(id(item))
            continue
        count += 1
        if count > 5000000 or depth > 128:
            raise Resource('JSON_RESOURCE_BOUND')
        kind = type(item)
        if kind in (str, int, bool) or item is None:
            if kind is int:
                _need(item.bit_length() <= 256, 'INTEGER_BITS')
            if kind is str:
                _need(len(item) <= 1000000, 'STRING_LENGTH')
        elif kind is float:
            _need(math.isfinite(item), 'NONFINITE_HEURISTIC_NUMBER')
        else:
            _need(kind in (dict, list) and id(item) not in active, 'NATIVE_JSON_TYPE_OR_CYCLE')
            active.add(id(item))
            stack.append((item, depth, True))
            if kind is dict:
                _need(all(type(k) is str for k in item), 'JSON_KEYS')
                stack.extend((v, depth+1, False) for v in item.values())
            else:
                stack.extend((v, depth+1, False) for v in item)


def _point_checker():
    global _POINT
    path = Path(__file__).resolve().with_name('independent_checker_v2.py')
    _need(hashlib.sha256(path.read_bytes()).hexdigest() == POINT_SHA256,
          'PINNED_INDEPENDENT_POINT_CHECKER_SOURCE')
    if _POINT is None:
        spec = importlib.util.spec_from_file_location('independent_points_for_continuations', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _POINT = module
    return _POINT


def _run(operation, function, *, point_dependency=True):
    point = None
    try:
        if point_dependency:
            point = _point_checker()
        return dict(version=VERSION, operation=operation, **function(point))
    except Exception as error:
        if isinstance(error, Resource) or (point is not None and isinstance(error, point.Resource)):
            return dict(version=VERSION, operation=operation, status='UNKNOWN', reason=str(error))
        if isinstance(error, (ValueError, TypeError, KeyError, IndexError, RecursionError)):
            return dict(version=VERSION, operation=operation, status='REJECTED', reason=str(error))
        raise


def _triples(point, verifier, rows):
    _need(type(rows) is list, 'PLACEMENT_LIST')
    result = [verifier.placement(row) for row in rows]
    _need(len(result) == len(set(result)), 'DUPLICATE_PLACEMENT_IDENTITY')
    return result


def _parent(point, model, supplied, core=None, seed_count=None, verified_decision=None):
    """Reconstruct a full true parent graph from compact or complete evidence."""
    _native(supplied)
    _need(type(supplied) is dict and {'placements', 'decision'} <= set(supplied), 'PARENT_FIELDS')
    if core is None:
        _need('core' in supplied, 'EXPLICIT_GLOBAL_CORE_REQUIRED')
        core = supplied['core']
    elif 'core' in supplied:
        _need(_same(core, supplied['core']), 'PARENT_CORE_BINDING')
    if seed_count is None:
        _need('seed_count' in supplied, 'EXPLICIT_SEED_COUNT_REQUIRED')
        seed_count = supplied['seed_count']
    elif 'seed_count' in supplied:
        _need(type(supplied['seed_count']) is int and supplied['seed_count'] == seed_count,
              'PARENT_SEED_COUNT_BINDING')
    _need(supplied.get('grow', True) is True, 'FULL_GROWTH_FRONTIER_REQUIRED')
    target = point._core(core)
    _need(target is not None, 'EXPLICIT_FULL_CORE_REQUIRED')
    verifier = point._Verifier(model)
    _need(type(supplied['placements']) is list, 'PARENT_PLACEMENT_ROWS')
    placements, generations = [], []
    for row in supplied['placements']:
        _need(type(row) is dict and set(row) == {'placement', 'generation'}, 'PARENT_PLACEMENT_ROW')
        placements.append(row['placement'])
        generations.append(row['generation'])
    state = verifier.state(placements, target, generations, seed_count)
    if verified_decision is None:
        domains = verifier.graph(state, target, True)
        summary = point._summary(verifier, state, domains, target, True)
        decision = point._decision(state, domains, target, summary['core_filled'])
    else:
        # Only check_policy supplies this after independently verifying the full
        # certificate and joining the exact chronological parent prefix.
        domains, summary, decision = None, None, verified_decision
    point._check_decision(verifier, supplied['decision'], decision)
    if 'domains' in supplied or 'edge_units' in supplied or 'point_generations' in supplied:
        receipt = point.check_snapshot(model, supplied)
        _need(receipt['status'] == 'VERIFIED', 'FULL_PARENT_SNAPSHOT_NOT_VERIFIED')
    context = {'placements': supplied['placements'], 'decision': decision,
               'core': [list(q) for q in sorted(target)], 'seed_count': seed_count, 'grow': True}
    return verifier, state, domains, summary, context


def _domain_rows(domains):
    return [{'point': list(q), 'candidates': [list(c) for c in candidates]}
            for q, candidates in sorted(domains.items())]


def check_interface(model, parent_snapshot, expansion, claimed):
    """Check a production whole-union interface claim, retaining all core zeros.

    parent_snapshot is either a full V2 snapshot or the exact production compact
    context with placements/generations, decision, core, seed_count and grow.
    Shared parent/expansion IDs count once. No hypothetical generations enter
    the production graph hash: it binds domains plus weighted edge units only.
    """
    def run(point):
        _native(claimed)
        verifier, parent, _, _, context = _parent(point, model, parent_snapshot)
        cluster = _triples(point, verifier, expansion)
        _need(bool(cluster), 'EMPTY_CLUSTER_EXPANSION')
        shared = set(cluster) & parent['selected']
        added = [p for p in cluster if p not in parent['selected']]
        union = list(parent['placements'])+added
        bindings = {'schema': 'Turtle-hypothetical-interface-v1', 'model_sha256': _sha(model),
                    'parent_context': context, 'parent_sha256': _sha(context),
                    'expansion_sha256': _sha([list(p) for p in sorted(cluster)]),
                    'union_sha256': _sha([list(p) for p in sorted(union)])}
        for key, expected in bindings.items():
            if key == 'parent_context' and key not in claimed:
                continue
            _need(key in claimed and _same(claimed[key], expected), 'INTERFACE_CONTEXT_BINDING:'+key)
        status = claimed['status']
        _need(status in ('VERIFIED_VIABLE', 'VERIFIED_DEAD', 'INTERFACE_UNKNOWN', 'JOINT_INVALID'), 'INTERFACE_STATUS')
        if status == 'INTERFACE_UNKNOWN':
            _need(claimed['complete'] is False and claimed['graph_sha256'] is None and
                  claimed['domain_sha256'] is None, 'UNKNOWN_INTERFACE_NOT_COMPLETE')
            return {'status': 'UNKNOWN', 'reason': 'PRODUCTION_INTERFACE_UNRESOLVED',
                    'binding': bindings, 'scope': 'No viable/dead certificate or budget-exhaustion replay is asserted.'}
        if status == 'JOINT_INVALID':
            _need(claimed['complete'] is False and claimed['graph_sha256'] is None and
                  claimed['domain_sha256'] is None, 'INVALID_UNION_NOT_COMPLETE')
            patch = point.check_patch(model, [list(p) for p in union], context['core'], grow=True)
            if patch['status'] == 'UNKNOWN':
                return {'status': 'UNKNOWN', 'reason': 'INDEPENDENT_INVALID_UNION_RESOURCE_LIMIT',
                        'patch_receipt': patch}
            _need(patch['status'] == 'REJECTED' and patch.get('consistent') is not True,
                  'FALSE_JOINT_INVALID_CLASSIFICATION')
            return {'status': 'VERIFIED', 'reason': 'INDEPENDENT_UNION_BASE_REJECTION',
                    'interface_status': 'JOINT_INVALID', 'patch_receipt': patch, 'binding': bindings}
        _need(claimed['complete'] is True, 'RESOLVED_INTERFACE_INCOMPLETE')
        core = context['core']
        patch = point.check_patch(model, [list(p) for p in union], core, grow=True)
        if patch['status'] == 'UNKNOWN':
            return {'status': 'UNKNOWN', 'reason': 'INDEPENDENT_INTERFACE_RESOURCE_LIMIT',
                    'patch_receipt': patch, 'binding': bindings}
        _need(patch.get('consistent') is True, 'UNION_BASE_CAPACITY_MARK_OR_INVENTORY_REJECTION')
        # check_patch's CORE_NOT_FILLED is compatible with a viable frontier.
        viable = patch['dead_points'] == []
        expected_status = 'VERIFIED_VIABLE' if viable else 'VERIFIED_DEAD'
        _need(status == expected_status, 'WHOLE_UNION_FRONTIER_CLASSIFICATION')
        target = point._core(core)
        union_state = verifier.state([list(p) for p in union], target)
        domains = verifier.graph(union_state, target, True)
        rows, edges = _domain_rows(domains), point._edges(verifier, domains)
        graph = {'domains': rows, 'edge_units': edges}
        counts = {'frontier_points': len(domains),
                  'candidate_nodes': len({c for candidates in domains.values() for c in candidates}),
                  'incidences': len(edges), 'union_placements': len(union),
                  'required_points': len(target | union_state['totals'].keys()),
                  'mark_assignments': len(union_state['marks'])}
        for key, expected in counts.items():
            _need(type(claimed[key]) is int and claimed[key] == expected, 'INTERFACE_COUNT:'+key)
        _need(type(claimed['materialization_cap']) is int and claimed['materialization_cap'] >= 0 and
              type(claimed['materializations']) is int and
              0 <= claimed['materializations'] <= claimed['materialization_cap'], 'INTERFACE_COST_COUNTER')
        _need(type(claimed['seconds']) in (int, float) and math.isfinite(claimed['seconds']) and
              claimed['seconds'] >= 0, 'INTERFACE_SECONDS')
        _need(claimed['domain_sha256'] == _sha(rows), 'EXACT_DOMAIN_HASH')
        _need(claimed['graph_sha256'] == _sha(graph), 'EXACT_WEIGHTED_GRAPH_HASH')
        _need(_same(claimed['dead_points'], patch['dead_points']), 'COMPLETE_DEAD_POINT_LIST')
        if 'domains' in claimed:
            _need(_same(claimed['domains'], rows), 'COMPLETE_DOMAIN_ROWS')
        if 'edge_units' in claimed:
            _need(_same(claimed['edge_units'], edges), 'COMPLETE_EDGE_CONTRIBUTIONS')
        return {'status': 'VERIFIED', 'reason': 'INDEPENDENT_WHOLE_UNION_FRONTIER_INTERFACE',
                'interface_status': expected_status, 'full_frontier_viable': viable,
                'core_filled': patch['core_filled'], 'shared_selected_counted_once': len(shared),
                'new_placements': len(added), 'binding': bindings,
                'domain_sha256': _sha(rows), 'graph_sha256': _sha(graph),
                'counts': counts, 'patch_receipt': patch, 'work': verifier.work+patch['work'],
                'scope': 'Exact hypothetical whole-union capacity/marks/frontier only; not a multi-move scheduler execution or proof of extension.'}
    return _run('check_interface', run)


def _checkpoint(value):
    _native(value)
    _need(type(value) is dict and set(value) == {'active_plan', 'pending_action'}, 'CHECKPOINT_FIELDS')
    _need(value['active_plan'] is None or type(value['active_plan']) is dict, 'ACTIVE_PLAN_TYPE')
    _need(value['pending_action'] is None or type(value['pending_action']) is dict, 'PENDING_ACTION_TYPE')
    return value


def _plan(point, verifier, plan, selected):
    if plan is None:
        return None
    _need(set(plan) == {'id', 'family_id', 'template_id', 'template_index', 'port_index',
                        'anchor', 'expansion', 'pending'}, 'ACTIVE_PLAN_FIELDS')
    for key in ('id', 'family_id', 'template_id'):
        _need(type(plan[key]) is str and bool(plan[key]), 'PLAN_ID_TYPE')
    _need(type(plan['template_index']) is int and 0 <= plan['template_index'] < 32 and
          type(plan['port_index']) is int and plan['port_index'] >= 0, 'PLAN_INDEX_TYPE')
    expansion = _triples(point, verifier, plan['expansion'])
    _need(expansion and plan['port_index'] < len(expansion), 'PLAN_EXPANSION_OR_PORT_INDEX')
    anchor = verifier.placement(plan['anchor'])
    _need(anchor in expansion and anchor in selected, 'ACTIVE_ANCHOR_NOT_ADOPTED')
    pending = _triples(point, verifier, plan['pending'])
    expected = sorted(set(expansion)-selected)
    _need(pending == expected and bool(expected), 'EXACT_ACTIVE_PENDING_MEMBERSHIP')
    return {'expansion': expansion, 'pending': pending, 'members': len(expansion),
            'fulfilled': len(set(expansion) & selected), 'shared_selected': len(set(expansion) & selected)}


def _compatible_union(point, verifier, parent_rows, expansion, target):
    selected = {tuple(p) for p in parent_rows}
    union = parent_rows+[list(p) for p in expansion if p not in selected]
    try:
        verifier.state(union, target)
        return True
    except point.Invalid:
        return False


def _transition(model, core, seed_count, event, verified_decision=None):
    """Independently check one actual primitive after_place and plan transition.

    The engine's compact control_before is replayed with the caller's fixed full
    core and seed count. Metadata IDs bind retained records, not a bank-membership
    theorem; the frozen bank and every multiport action need separate admission.
    """
    def run(point):
        _native(event)
        _need(event['event_type'] == 'after_place' and type(event['ordinal']) is int and
              event['ordinal'] >= 0, 'AFTER_PLACE_EVENT')
        lanes = ('MARKED_LEX', 'HEAD_H', 'CONT_H', 'HEAD_V_H', 'CONT_V_H',
                 'CONT_V_RANDOM', 'CONT_V_ZERO', 'CONT_V_RL')
        lane = event['lane']
        _need(lane in lanes and type(event['continuation_enabled']) is bool and
              event['continuation_enabled'] == lane.startswith('CONT_') and
              type(event['filtered']) is bool and event['filtered'] == ('_V_' in lane),
              'LANE_CONTEXT_BINDING')
        verifier, parent, domains, _, context = _parent(point, model, event['parent'], core, seed_count,
                                                      verified_decision=verified_decision)
        decision = context['decision']
        kind = event['kind']
        _need(kind in ('branch', 'forced') and kind == decision['kind'], 'ACTUAL_SCHEDULER_KIND')
        move = verifier.placement(event['move'])
        _need(list(move) in decision['candidates'] and move not in parent['selected'],
              'ACTUAL_MOVE_NOT_NEW_TRUE_DOMAIN_MEMBER')
        if kind == 'forced':
            _need(len(decision['candidates']) == 1, 'FORCED_FULFILLMENT_NOT_SINGLETON')
        before, after = _checkpoint(event['checkpoint_before']), _checkpoint(event['checkpoint_after'])
        _need(after['pending_action'] is None, 'ACTUAL_MOVE_MUST_CONSUME_PENDING_ACTION')
        plan = before['active_plan']
        plan_view = _plan(point, verifier, plan, parent['selected'])
        if not event['continuation_enabled']:
            _need(plan is None, 'HEAD_LANE_HAS_RETAINED_PLAN')
        target = point._core(core)
        parent_rows = [list(p) for p in parent['placements']]
        if plan_view is not None:
            _need(_compatible_union(point, verifier, parent_rows, plan_view['expansion'], target),
                  'PREEXISTING_PLAN_NOT_COMPATIBLE_WITH_PARENT')
        pending = before['pending_action']
        if pending is not None:
            required = {'choice_index', 'kind', 'anchor', 'parent_sha256'}
            _need(required <= set(pending) and type(pending['choice_index']) is int and
                  pending['choice_index'] >= 0 and pending['kind'] in ('adopt', 'successor', 'base'),
                  'PENDING_ACTION_FIELDS')
            _need(kind == 'branch' and pending['parent_sha256'] == _sha(context), 'PENDING_TRUE_PARENT_BINDING')
            anchor = verifier.placement(pending['anchor'])
            _need(list(anchor) in decision['candidates'], 'PENDING_ANCHOR_OUTSIDE_TRUE_BRANCH_DOMAIN')
            if pending['kind'] != 'base':
                extra = {'family_id', 'template_id', 'template_index', 'port_index', 'expansion', 'plan_id'}
                _need(set(pending) == required | extra, 'PENDING_CLUSTER_FIELDS')
                expansion = _triples(point, verifier, pending['expansion'])
                _need(all(type(pending[field]) is str and bool(pending[field])
                          for field in ('family_id', 'template_id')) and
                      type(pending['template_index']) is int and 0 <= pending['template_index'] < 32 and
                      type(pending['port_index']) is int and 0 <= pending['port_index'] < len(expansion),
                      'PENDING_FAMILY_TYPES')
                _need(anchor in expansion and _compatible_union(point, verifier, parent_rows, expansion, target),
                      'PENDING_CLUSTER_NOT_COMPATIBLE')
                if pending['kind'] == 'adopt':
                    _need(plan is None and pending['plan_id'] is None, 'NEW_ADOPTION_WITH_EXISTING_PLAN')
                if pending['kind'] == 'successor':
                    _need(plan is not None and pending['plan_id'] == plan['id'] and
                          anchor in plan_view['pending'], 'SUCCESSOR_NOT_ACTIVE_PENDING_MEMBER')
                    for field in ('family_id', 'template_id', 'template_index', 'port_index', 'expansion'):
                        _need(_same(pending[field], plan[field]), 'SUCCESSOR_PLAN_IDENTITY:'+field)
            else:
                _need(set(pending) == required, 'BASE_PENDING_FIELDS')
        taken = bool(kind == 'branch' and pending is not None and
                     move == verifier.placement(pending['anchor']))
        _need(type(event['preference_taken']) is bool and event['preference_taken'] is taken,
              'PREFERENCE_TAKEN_FLAG')
        transition = 'ordinary'
        working = plan
        if taken and pending['kind'] == 'adopt' and event['continuation_enabled']:
            _need(plan is None, 'ADOPTION_REPLACES_ACTIVE_PLAN')
            transition = 'adoption'
            working = {field: pending[field] for field in
                       ('family_id', 'template_id', 'template_index', 'port_index', 'anchor', 'expansion')}
        elif plan is not None and move in plan_view['pending']:
            transition = ('forced_fulfillment' if kind == 'forced' else
                          'successor' if taken and pending['kind'] == 'successor' and
                          pending['plan_id'] == plan['id'] else 'branch_member_fulfillment')
        _need(event['transition'] == transition, 'ACTUAL_PLAN_TRANSITION')
        selected_after = parent['selected'] | {move}
        incident = [parent['generations'][q] for q, _ in verifier.t_rows(move) if q in parent['generations']]
        _need(bool(incident), 'DISCONNECTED_ACTUAL_MOVE')
        generation = 1+min(incident)
        rows_after = parent_rows+[list(move)]
        verifier.state(rows_after, target,
                       [row['generation'] for row in context['placements']]+[generation], seed_count)
        completed, abandoned = False, False
        if working is not None:
            expansion = _triples(point, verifier, working['expansion'])
            remaining = sorted(set(expansion)-selected_after)
            completed = not remaining
            if not completed:
                abandoned = not _compatible_union(point, verifier, rows_after, expansion, target)
        _need(type(event['completed']) is bool and event['completed'] is completed, 'COMPLETION_FLAG')
        if abandoned:
            _need(type(event['abandonment']) is str and bool(event['abandonment']), 'MISSING_INCOMPATIBILITY_ABANDONMENT')
        else:
            _need(event['abandonment'] is None, 'SPURIOUS_AFTER_PLACE_ABANDONMENT')
        final_plan = after['active_plan']
        if working is None or completed or abandoned:
            _need(final_plan is None, 'COMPLETED_ABANDONED_OR_ABSENT_PLAN_RETAINED')
            final_view = None
        else:
            _need(final_plan is not None, 'LIVE_PLAN_DISAPPEARED_AFTER_ACTUAL_MOVE')
            final_view = _plan(point, verifier, final_plan, selected_after)
            for field in ('family_id', 'template_id', 'template_index', 'port_index', 'anchor', 'expansion'):
                _need(_same(final_plan[field], working[field]), 'RETAINED_PLAN_CHANGED:'+field)
            if plan is not None:
                _need(final_plan['id'] == plan['id'], 'RETAINED_PLAN_ID_CHANGED')
            else:
                _need(final_plan['id'].startswith('plan-'), 'NEW_PLAN_ID')
        return {'status': 'VERIFIED', 'reason': 'TRUE_SCHEDULER_MOVE_AND_PLAN_TRANSITION',
                'move': list(move), 'generation': generation, 'transition': transition,
                'completed': completed, 'abandoned': abandoned, 'preference_taken': taken,
                'plan_before': _public_plan(plan_view), 'plan_after': _public_plan(final_view),
                'parent_sha256': _sha(context), 'checkpoint_before_sha256': _sha(before),
                'checkpoint_after_sha256': _sha(after), 'work': verifier.work,
                'scope': 'One legal primitive at the true global scheduler decision, plus exact retained membership. Frozen-family provenance, full search tree and logical outcome are separately checked.'}
    return run


def _public_plan(view):
    if view is None:
        return None
    return {'members': view['members'], 'fulfilled': view['fulfilled'],
            'pending_count': len(view['pending']), 'shared_selected': view['shared_selected']}


def check_transition(model, core, seed_count, event):
    return _run('check_transition', _transition(model, core, seed_count, event))


def check_controller_rollback(receipt):
    """Check saved/restored controller equality; current-child before is different.

    Engine digests are compared only when present. Null digests explicitly mean
    the expensive engine-side read-only guard was not measured for that receipt.
    """
    def run(_):
        _native(receipt)
        before, restored = _checkpoint(receipt['before']), _checkpoint(receipt['restored'])
        _need(receipt['kind'] in ('forced', 'branch', 'order') and receipt['equal'] is True,
              'ROLLBACK_KIND_OR_EQUAL_FLAG')
        _need(_same(before, restored), 'CONTROLLER_ROLLBACK_NOT_EXACT')
        a, b = receipt['engine_before'], receipt['engine_restored']
        _need((a is None and b is None) or (type(a) is str and a == b and len(a) == 64 and
              all(c in '0123456789abcdef' for c in a)), 'ROLLBACK_ENGINE_GUARD')
        _need(type(receipt['reason']) is str, 'ROLLBACK_REASON')
        if receipt['move'] is not None:
            _need(type(receipt['move']) is list and len(receipt['move']) == 3 and
                  all(type(x) is int for x in receipt['move']), 'ROLLBACK_MOVE')
        return {'status': 'VERIFIED', 'reason': 'EXACT_SAVED_CONTROLLER_CHECKPOINT_RESTORED',
                'checkpoint_sha256': _sha(before), 'engine_guard_recorded': a is not None,
                'scope': 'Equality of supplied saved/restored logical controller state. Associate receipt with the actual engine rollback separately.'}
    return _run('check_controller_rollback', run, point_dependency=False)


def _number(value):
    _need(type(value) in (int, float) and math.isfinite(value), 'FINITE_HEURISTIC_NUMBER')
    return float(value)


def _close(a, b, reason):
    a, b = _number(a), _number(b)
    _need(abs(a-b) <= TOLERANCE*max(1.0, abs(a), abs(b)), reason)


def _vector(value, width, reason):
    _need(type(value) is list and len(value) == width, reason+'_WIDTH')
    return [_number(v) for v in value]


def _vectors_equal(a, b, reason):
    _need(len(a) == len(b), reason+'_WIDTH')
    for x, y in zip(a, b):
        _close(x, y, reason)


def check_learning(policy, reward=None):
    """Pure 40D saved-number audit; no point-checker or policy import.

    The supplied reward must have separate point/outcome/cost assurance. Every
    recorded choice contributes, including failed-subtree and interrupted-order
    choices. Continuous feature meanings and RNG draws are not independently
    proved here. Frozen evaluation must have no finish/update history.
    """
    def run(_):
        _native(policy)
        _need(policy['schema'] == 'Turtle-retained-receptor-controller-v1', 'LEARNING_SCHEMA')
        _need(type(policy['training']) is bool, 'LEARNING_TRAINING_FLAG')
        training = policy['training']
        _need(type(policy['feature_names']) is list and len(policy['feature_names']) == 40 and
              all(type(name) is str for name in policy['feature_names']), 'DECLARED_40D_FEATURE_NAMES')
        _close(policy['learning_rate'], 0.03, 'POLICY_DECLARED_LEARNING_RATE')
        _need((reward is not None) is training, 'INDEPENDENT_REWARD_TRAINING_MODE')
        lane = policy['lane']
        if training:
            _need(lane == 'CONT_V_RL' and policy['updates'], 'TRAINING_LANE_OR_UPDATE')
            weights = _vector(policy['updates'][-1]['weights_before'], 40, 'EPISODE_WEIGHTS')
        else:
            _need(policy['updates'] == [] and type(policy['episodes']) is int and policy['episodes'] == 0,
                  'FROZEN_EVALUATION_UPDATED')
            _need(policy['episode_finished'] is False, 'FROZEN_EVALUATION_FINISHED_EPISODE')
            weights = _vector(policy['weights'], 40, 'FROZEN_WEIGHTS')
        _need(all(abs(w) <= 8 for w in weights), 'WEIGHT_RANGE')
        if lane == 'CONT_V_ZERO':
            _need(all(w == 0 for w in weights), 'ZERO_CONTROL_WEIGHTS')
        decisions = policy['decisions']
        _need(type(decisions) is list, 'LEARNING_DECISIONS')
        gradients, chosen_clusters, action_total = [], 0, 0
        digest = hashlib.sha256()
        for ordinal, decision in enumerate(decisions):
            _vectors_equal(_vector(decision['weights'], 40, 'DECISION_WEIGHTS'), weights,
                           'WITHIN_EPISODE_WEIGHTS_CHANGED')
            context = decision['parent_context']
            _need(context['decision']['kind'] == 'branch' and
                  decision['state_sha256'] == _sha(context), 'LEARNING_PARENT_CONTEXT')
            legal = {tuple(row) for row in context['decision']['candidates']}
            table = decision['action_feature_table']
            _need(type(table) is list and table and type(decision['action_count']) is int and
                  len(table) == decision['action_count'], 'ACTION_TABLE_CENSUS')
            actions, bases = [], []
            for row in table:
                _need(type(row) is dict and set(row) == {'kind', 'anchor', 'cluster_index', 'continuous'},
                      'FEATURE_TABLE_FIELDS')
                _need(row['kind'] in ('base', 'cluster', 'continuation'), 'FEATURE_ACTION_KIND')
                anchor = row['anchor']
                _need(type(anchor) is list and len(anchor) == 3 and all(type(v) is int for v in anchor),
                      'FEATURE_ACTION_ANCHOR')
                _need(tuple(anchor) in legal, 'ACTION_OUTSIDE_FULL_BASE_DOMAIN')
                index = row['cluster_index']
                if row['kind'] == 'base':
                    _need(index is None, 'BASE_FEATURE_INDEX')
                    bases.append(tuple(anchor))
                else:
                    _need(type(index) is int and 0 <= index < 32, 'CLUSTER_FEATURE_INDEX')
                continuous = _vector(row['continuous'], 8, 'CONTINUOUS_FEATURES')
                actions.append(continuous+[float(index == j) for j in range(32)])
            _need(len(bases) == len(set(bases)) and set(bases) == legal and
                  type(decision['base_action_count']) is int and decision['base_action_count'] == len(bases),
                  'COMPLETE_BASE_FALLBACK_CENSUS')
            selected = decision['chosen_index']
            _need(type(selected) is int and 0 <= selected < len(actions), 'CHOSEN_ACTION_INDEX')
            chosen, selected_row = decision['chosen_action'], table[selected]
            for field in ('kind', 'anchor', 'cluster_index'):
                _need(_same(chosen[field], selected_row[field]), 'CHOSEN_INDEX_IDENTITY:'+field)
            feature = _vector(chosen['features'], 40, 'CHOSEN_FEATURES')
            _vectors_equal(feature, actions[selected], 'CHOSEN_FEATURE_RECONSTRUCTION')
            logits = [sum(w*x for w, x in zip(weights, vector)) for vector in actions]
            masses = [math.exp(logit-max(logits)) for logit in logits]
            probabilities = [mass/sum(masses) for mass in masses]
            _vectors_equal(_vector(decision['model_softmax_probabilities'], len(actions), 'SOFTMAX'),
                           probabilities, 'MODEL_SOFTMAX')
            _need(all(0 <= p <= 1 for p in decision['model_softmax_probabilities']), 'MODEL_PROBABILITY_RANGE')
            if 'logits' in decision:
                _vectors_equal(decision['logits'], logits, 'MODEL_LOGITS')
            _close(decision['model_softmax_probability'], probabilities[selected], 'CHOSEN_SOFTMAX')
            if training:
                behavior = probabilities[selected]
                expected = [sum(p*vector[j] for p, vector in zip(probabilities, actions)) for j in range(40)]
                gradients.append([x-y for x, y in zip(feature, expected)])
            elif lane == 'CONT_V_RANDOM':
                behavior = 1.0/len(actions)
            else:
                behavior = 1.0
                if lane in ('CONT_V_RL', 'CONT_V_ZERO'):
                    _need(selected == min(range(len(actions)), key=lambda j: (-logits[j], j)),
                          'FROZEN_ARGMAX_SELECTION')
            _close(decision['behavior_probability'], behavior, 'BEHAVIOR_PROBABILITY')
            _close(decision['behavior_log_probability'], math.log(behavior), 'BEHAVIOR_LOG_PROBABILITY')
            chosen_clusters += chosen['kind'] != 'base'
            action_total += len(actions)
            digest.update((_wire([ordinal, selected, probabilities, actions])+'\n').encode('ascii'))
        _need(policy['telemetry']['branch_choices'] == len(decisions) and
              policy['telemetry']['chosen_cluster_actions'] == chosen_clusters, 'CHOICE_TELEMETRY_CENSUS')
        mean_gradient = [sum(g[j] for g in gradients)/max(1, len(gradients)) for j in range(40)]
        changed = False
        if training:
            update = policy['updates'][-1]
            _close(update['reward'], reward, 'INDEPENDENT_REWARD_BINDING')
            _need(type(update['stochastic_choices']) is int and update['stochastic_choices'] == len(decisions),
                  'ALL_RECORDED_CHOICES_IN_GRADIENT')
            _vectors_equal(update['gradient'], mean_gradient, 'MEAN_SCORE_GRADIENT')
            old_weights, baseline = [0.0]*40, 0.0
            for index, item in enumerate(policy['updates']):
                _need(type(item['episode']) is int and item['episode'] == index, 'UPDATE_EPISODE_SEQUENCE')
                _vectors_equal(_vector(item['weights_before'], 40, 'HISTORY_WEIGHTS'), old_weights,
                               'UPDATE_WEIGHT_CHAIN')
                _close(item['baseline_before'], baseline, 'UPDATE_BASELINE_CHAIN')
                advantage = _number(item['reward'])-baseline
                _close(item['advantage'], advantage, 'REWARD_MINUS_BASELINE')
                _close(item['learning_rate'], 0.03, 'DECLARED_LEARNING_RATE')
                gradient = _vector(item['gradient'], 40, 'HISTORY_GRADIENT')
                after = [max(-8.0, min(8.0, w+0.03*advantage*g)) for w, g in zip(old_weights, gradient)]
                _vectors_equal(item['weights_after'], after, 'CLIPPED_REINFORCE_UPDATE')
                _need(type(item['updated']) is bool and item['updated'] == (item['weights_after'] != item['weights_before']),
                      'UPDATE_CHANGED_FLAG')
                old_weights = list(item['weights_after'])
                baseline = 0.9*baseline+0.1*_number(item['reward'])
            _vectors_equal(policy['weights'], old_weights, 'SNAPSHOT_POSTUPDATE_WEIGHTS')
            _close(policy['baseline'], baseline, 'RUNNING_BASELINE')
            _need(policy['episodes'] == len(policy['updates']) and policy['episode_finished'] is True,
                  'COMPLETED_TRAINING_EPISODE')
            changed = update['updated']
        else:
            _close(policy['baseline'], 0.0, 'FROZEN_BASELINE_CHANGED')
        _need(policy['weights_sha256'] == _sha(policy['weights']), 'POLICY_WEIGHT_HASH')
        return {'status': 'VERIFIED', 'reason': 'INDEPENDENT_40D_REINFORCE_ARITHMETIC',
                'training': training, 'decisions': len(decisions), 'actions': action_total,
                'stochastic_choices': len(gradients), 'chosen_nonbase_actions': chosen_clusters,
                'current_update_changed_weights': changed, 'mean_gradient': mean_gradient,
                'trace_sha256': digest.hexdigest(), 'tolerance': TOLERANCE,
                'scope': 'Current episode score gradient and supplied independent reward; stored historical update arithmetic and frozen inference. No continuous-feature semantics, RNG draw replay, proof validity or acceleration claim.'}
    return _run('check_learning', run, point_dependency=False)


def _outline(point, model, search):
    """Index a separately VERIFIED certificate without rerunning its graph search."""
    verifier = point._Verifier(model)
    target, count = point._core(search['core']), [0]
    seed_count = len(search['seeds'])
    roots = [{'placement': row, 'generation': 0} for row in search['seeds']]
    nodes, edges, rollbacks = {}, {}, []

    def visit(node, prefix):
        count[0] += 1
        if count[0] > point.MAX_CERTIFICATE_NODES:
            raise Resource('POLICY_CERTIFICATE_NODE_LIMIT')
        key = _sha(prefix)
        _need(key not in nodes, 'REPEATED_CHRONOLOGICAL_CERTIFICATE_PREFIX')
        nodes[key] = {'node': node, 'placements': prefix}
        if 'decision' not in node:
            return
        state = verifier.state([r['placement'] for r in prefix], target,
                               [r['generation'] for r in prefix], seed_count)
        decision = node['decision']
        for child in node['children']:
            move = verifier.placement(child['move'])
            edge_key = _sha([prefix, list(move), decision['kind']])
            _need(edge_key not in edges, 'DUPLICATE_CERTIFICATE_EDGE')
            incident = [state['generations'][q] for q, _ in verifier.t_rows(move) if q in state['generations']]
            _need(incident, 'CERTIFICATE_CHILD_CONTACT')
            edges[edge_key] = {'decision': decision, 'child': child['tree'], 'prefix': prefix,
                               'move': list(move), 'kind': decision['kind']}
            next_prefix = prefix+[{'placement': list(move), 'generation': 1+min(incident)}]
            visit(child['tree'], next_prefix)
            if child['tree']['outcome'] != 'POSITIVE':
                rollbacks.append({'move': list(move), 'kind': decision['kind'], 'edge_key': edge_key})
    visit(search['certificate'], roots)
    return nodes, edges, rollbacks, verifier.work


def _chosen_pending(decision, index):
    """The pending declaration is determined by the actual recorded action."""
    action = decision['chosen_action']
    _need(action['kind'] in ('base', 'cluster', 'continuation'), 'ORDER_CHOSEN_ACTION_KIND')
    kind = {'base': 'base', 'cluster': 'adopt', 'continuation': 'successor'}[action['kind']]
    expected = {'choice_index': index, 'kind': kind, 'anchor': action['anchor'],
                'parent_sha256': _sha(decision['parent_context'])}
    if kind != 'base':
        expected.update(family_id=action['family_id'], template_id=action['template_id'],
                        template_index=action['cluster_index'], port_index=action['port_index'],
                        expansion=action['primitive_expansion'], plan_id=action.get('plan_id'))
    return expected


def _controller_chain(policy, search, edges, expected_rollbacks):
    """Replay logical plan state from its declared empty origin, chronologically.

    Order may add only the exact chosen pending action. A compatible plan cannot
    appear between independent steps: it must arise from a checked adoption or
    a restore of that specific trial/order's previously observed saved state.
    """
    logical = {'active_plan': None, 'pending_action': None}
    decisions, receipts = policy['decisions'], search.get('control_rollback_checks', [])
    order_cursor, restore_cursor, primitive_cursor = 0, 0, 0
    order_starts, trial_checkpoints = {}, {}
    abandoned_order_start = None
    orders, restores, afters, abandonments = 0, 0, 0, 0
    for event in policy['events']:
        before, after = _checkpoint(event['checkpoint_before']), _checkpoint(event['checkpoint_after'])
        _need(_same(before, logical), 'CHRONOLOGICAL_CONTROLLER_CHECKPOINT_BEFORE')
        kind = event['event_type']
        if kind == 'order':
            index = event['choice_index']
            _need(type(index) is int and index == order_cursor and index < len(decisions),
                  'CHRONOLOGICAL_ORDER_CHOICE_INDEX')
            decision = decisions[index]
            _need(before['pending_action'] is None, 'ORDER_OVERWRITES_UNCONSUMED_PENDING_ACTION')
            _need(_same(after['active_plan'], before['active_plan']), 'ORDER_INVENTS_OR_REPLACES_ACTIVE_PLAN')
            _need(_same(after['pending_action'], _chosen_pending(decision, index)),
                  'PENDING_ACTION_NOT_EXACT_RECORDED_CHOICE')
            _need(_same(after, decision['checkpoint_after']), 'ORDER_DECISION_CHECKPOINT_JOIN')
            start = abandoned_order_start if abandoned_order_start is not None else before
            _need('checkpoint_at_call' in event and _same(event['checkpoint_at_call'], start),
                  'EXACT_ORDER_CALL_CHECKPOINT')
            order_starts[index] = start
            abandoned_order_start = None
            order_cursor += 1
            orders += 1
        elif kind == 'after_place':
            _need(abandoned_order_start is None, 'ACTUAL_MOVE_WITHOUT_DECLARED_POSTABANDON_ORDER')
            key = _sha([event['parent']['placements'], event['move'], event['kind']])
            _need(key in edges and key not in trial_checkpoints, 'CHRONOLOGICAL_ACTUAL_TRIAL')
            trial_checkpoints[key] = before
            afters += 1
        elif kind == 'abandon':
            _need(abandoned_order_start is None, 'MULTIPLE_UNCLOSED_ORDER_ABANDONMENTS')
            _need(before['pending_action'] is None, 'ABANDON_DROPS_UNCONSUMED_PENDING_ACTION')
            abandoned_order_start = before
            abandonments += 1
        elif kind == 'restore':
            _need(restore_cursor < len(receipts), 'RESTORE_WITHOUT_INDEXED_ENGINE_RECEIPT')
            receipt = receipts[restore_cursor]
            _need(_same(after, receipt['restored']) and _same(after, receipt['before']),
                  'CHRONOLOGICAL_RESTORE_EXACT_SAVED_CHECKPOINT')
            if receipt['kind'] == 'order':
                pending = before['pending_action']
                if pending is not None:
                    index = pending['choice_index']
                    _need(type(index) is int and index in order_starts and
                          _same(receipt['before'], order_starts[index]), 'INTERRUPTED_ORDER_SAVED_ORIGIN')
                else:
                    _need(policy['lane'] == 'MARKED_LEX' and _same(receipt['before'], before),
                          'UNDECLARED_ORDER_RESTORE_ORIGIN')
                abandoned_order_start = None
            else:
                _need(primitive_cursor < len(expected_rollbacks), 'EXTRA_PRIMITIVE_RESTORE')
                trial = expected_rollbacks[primitive_cursor]
                _need(_same(receipt['move'], trial['move']) and receipt['kind'] == trial['kind'],
                      'RESTORE_EXACT_FAILED_TRIAL_ASSOCIATION')
                key = trial['edge_key']
                if key in trial_checkpoints:
                    saved = trial_checkpoints[key]
                else:
                    child = edges[key]['child']
                    _need(set(child) == {'outcome', 'limit'} and child['outcome'] == 'UNKNOWN' and
                          child['limit'] == 'cache', 'MISSING_SAVED_COMPLETED_TRIAL_ORIGIN')
                    # Partial materialization did not invoke after_place: the
                    # controller has not changed since this trial's checkpoint.
                    saved = before
                _need(_same(receipt['before'], saved), 'RESTORE_DID_NOT_RETURN_TO_ACTUAL_TRIAL_CHECKPOINT')
                primitive_cursor += 1
            restore_cursor += 1
            restores += 1
        else:
            raise Invalid('UNSUPPORTED_CHAIN_EVENT')
        logical = after
    _need(order_cursor == len(decisions), 'MISSING_EXPLICIT_ORDER_EVENT')
    _need(restore_cursor == len(receipts) and primitive_cursor == len(expected_rollbacks),
          'CHRONOLOGICAL_RESTORE_COMPLETE_CENSUS')
    _need(abandoned_order_start is None, 'UNCLOSED_ORDER_ABANDONMENT')
    # A final declared order may legitimately remain pending when the engine
    # stops before its first primitive. Its origin has still been replayed.
    _need(_same(policy['checkpoint'], logical), 'FINAL_CONTROLLER_CHECKPOINT_CHAIN')
    return {'initial_checkpoint': {'active_plan': None, 'pending_action': None},
            'final_checkpoint_sha256': _sha(logical), 'order_events': orders,
            'actual_after_place_events': afters, 'restore_events': restores,
            'explicit_abandon_events': abandonments,
            'final_pending_action': logical['pending_action'] is not None,
            'status': 'VERIFIED'}


def check_policy(model, search, policy):
    """Verify tree once, join actual events to it, and check all controller undo.

    Replay the controller from empty state through every explicit order, actual
    move, abandonment and exact saved-state restore. Pending actions are bound
    to the corresponding chosen action, so compatible phantom plans cannot be
    introduced between separately valid transitions.

    Raw certificate edges interrupted during Engine.place may lack after_place
    only when they end in an explicit UNKNOWN/cache leaf. Such an edge is not
    reported as an actual completed primitive placement. No Root code imported.
    """
    def run(point):
        tree = point.check_tree(model, search)
        if tree['status'] != 'VERIFIED':
            return {'status': tree['status'], 'reason': 'NATIVE_TREE_NOT_INDEPENDENTLY_VERIFIED', 'tree': tree}
        if policy is None:
            _need(not search.get('control_rollback_checks'), 'MISSING_CONTROLLER_WITH_ROLLBACK_RECORDS')
            return {'status': 'VERIFIED', 'reason': 'NO_CONTROLLER_BASELINE', 'tree': tree,
                    'events_checked': 0, 'rollback_receipts_checked': 0}
        _native(policy)
        _need(policy['schema'] == 'Turtle-retained-receptor-controller-v1', 'POLICY_SCHEMA')
        _need(search['grow'] is True, 'POLICY_FULL_GROWTH_REQUIRED')
        core, seed_count = search['core'], len(search['seeds'])
        nodes, edges, expected_rollbacks, work = _outline(point, model, search)
        decisions_by_prefix, interrupted_orders = {}, 0
        for decision in policy['decisions']:
            context = decision['parent_context']
            _need(_same(context['core'], core) and type(context['seed_count']) is int and
                  context['seed_count'] == seed_count and context['grow'] is True,
                  'POLICY_FIXED_PROBLEM_CONTEXT')
            key = _sha(context['placements'])
            _need(key in nodes and key not in decisions_by_prefix, 'ORDER_CONTEXT_NOT_UNIQUE_CERTIFICATE_PREFIX')
            node = nodes[key]['node']
            known = node.get('decision')
            if known is None:
                _need(node['outcome'] == 'UNKNOWN' and node['limit'] in ('seconds', 'cache'),
                      'UNJUSTIFIED_INTERRUPTED_ORDER_CONTEXT')
                _, _, _, _, rebuilt = _parent(point, model, context)
                _need(rebuilt['decision']['kind'] == 'branch', 'INTERRUPTED_ORDER_NOT_TRUE_BRANCH')
                interrupted_orders += 1
            else:
                _need(known['kind'] == 'branch', 'ORDER_OUTSIDE_BRANCH')
                _parent(point, model, context, verified_decision=known)
            _need(decision['state_sha256'] == _sha(context) and
                  decision['branch_point'] == context['decision']['point'], 'ORDER_CONTEXT_HASH')
            legal = {tuple(p) for p in context['decision']['candidates']}
            base = [tuple(row['anchor']) for row in decision['action_feature_table'] if row['kind'] == 'base']
            _need(len(base) == len(set(base)) and set(base) == legal, 'FULL_PRIMITIVE_FALLBACK')
            chosen = decision['chosen_action']['anchor']
            _need(tuple(chosen) in legal, 'ORDER_PREFERENCE_OUTSIDE_TRUE_DOMAIN')
            order = [chosen]+[list(p) for p in sorted(legal) if list(p) != chosen]
            actual = [child['move'] for child in node.get('children', [])]
            _need(_same(actual, order[:len(actual)]), 'ACTUAL_CHILDREN_NOT_PREFERENCE_PLUS_COMPLETE_FALLBACK')
            decisions_by_prefix[key] = decision
        for key, item in nodes.items():
            decision = item['node'].get('decision')
            if decision and decision['kind'] == 'branch':
                if policy['lane'] == 'MARKED_LEX':
                    actual = [child['move'] for child in item['node']['children']]
                    _need(_same(actual, sorted(decision['candidates'])[:len(actual)]), 'LEXICAL_BASE_ORDER')
                else:
                    _need(key in decisions_by_prefix, 'MISSING_BRANCH_ORDER_RECORD')
        events = policy['events']
        _need(type(events) is list and len(events) <= 200000, 'POLICY_EVENT_BOUND')
        seen_edges, after_events, restore_events, actual_generations = set(), [], [], {}
        transitions = {kind: 0 for kind in ('adoption', 'successor', 'forced_fulfillment',
                                           'branch_member_fulfillment', 'ordinary')}
        for ordinal, event in enumerate(events):
            _need(type(event['ordinal']) is int and event['ordinal'] == ordinal, 'EVENT_ORDINAL_SEQUENCE')
            kind = event['event_type']
            if kind == 'after_place':
                key = _sha([event['parent']['placements'], event['move'], event['kind']])
                _need(key in edges and key not in seen_edges, 'ACTUAL_EVENT_NOT_UNIQUE_CERTIFICATE_EDGE')
                seen_edges.add(key)
                edge = edges[key]
                _need(_same(event['parent']['decision'], edge['decision']), 'EVENT_TRUE_PARENT_DECISION')
                checked = _transition(model, core, seed_count, event,
                                      verified_decision=edge['decision'])(point)
                _need(checked['status'] == 'VERIFIED', 'ACTUAL_TRANSITION_NOT_VERIFIED')
                work += checked['work']
                actual_generations[ordinal] = checked['generation']
                transitions[checked['transition']] += 1
                after_events.append(event)
            elif kind == 'restore':
                _checkpoint(event['checkpoint_before'])
                _checkpoint(event['checkpoint_after'])
                restore_events.append(event)
            elif kind == 'abandon':
                before, after = _checkpoint(event['checkpoint_before']), _checkpoint(event['checkpoint_after'])
                _need(before['active_plan'] is not None and after['active_plan'] is None and
                      _same(before['pending_action'], after['pending_action']) and
                      type(event['reason']) is str, 'EXPLICIT_PLAN_ABANDONMENT')
            elif kind == 'order':
                _checkpoint(event['checkpoint_before'])
                _checkpoint(event['checkpoint_after'])
                _need(type(event['choice_index']) is int, 'ORDER_EVENT_CHOICE_INDEX')
            else:
                raise Invalid('UNSUPPORTED_POLICY_EVENT')
        cache_partial = 0
        for key, edge in edges.items():
            if key not in seen_edges:
                child = edge['child']
                _need(set(child) == {'outcome', 'limit'} and child['outcome'] == 'UNKNOWN' and
                      child['limit'] == 'cache', 'MISSING_COMPLETED_AFTER_PLACE_EVENT')
                cache_partial += 1
        receipts = search.get('control_rollback_checks', [])
        _need(type(receipts) is list and len(receipts) == len(restore_events), 'RESTORE_RECEIPT_EVENT_CENSUS')
        primitive, order_receipts, guarded = [], 0, 0
        for receipt, event in zip(receipts, restore_events):
            checked = check_controller_rollback(receipt)
            _need(checked['status'] == 'VERIFIED', 'EXACT_CONTROLLER_RESTORE_NOT_VERIFIED')
            _need(_same(event['checkpoint_after'], receipt['restored']), 'RESTORE_EVENT_SAVED_CHECKPOINT_JOIN')
            guarded += checked['engine_guard_recorded']
            if receipt['kind'] == 'order':
                _need(receipt['move'] is None, 'ORDER_RESTORE_HAS_MOVE')
                order_receipts += 1
            else:
                primitive.append({'move': receipt['move'], 'kind': receipt['kind']})
        _need(_same(primitive, [{k: v for k, v in item.items() if k != 'edge_key'}
                                for item in expected_rollbacks]), 'FAILED_CHILD_RESTORE_COMPLETE_CENSUS')
        if policy['lane'] != 'MARKED_LEX':
            _need(order_receipts == interrupted_orders, 'INTERRUPTED_ORDER_RESTORE_CENSUS')
        examples = 0
        for transition, saved in policy.get('plan_examples', {}).items():
            _need(transition in ('adoption', 'successor'), 'PLAN_EXAMPLE_TRANSITION')
            actual = [event for event in after_events if event['transition'] == transition]
            _need(type(saved['seen']) is int and saved['seen'] == len(actual) and actual,
                  'PLAN_EXAMPLE_CENSUS')
            for role, event in [('first', actual[0]), ('last', actual[-1])]:
                sample = saved[role]
                _need(_same(sample['event'], event) and
                      _same(sample['parent_snapshot']['placements'], event['parent']['placements']),
                      'RETAINED_PLAN_EXAMPLE_JOIN')
                expected_after = event['parent']['placements']+[
                    {'placement': event['move'], 'generation': actual_generations[event['ordinal']]}]
                _need(_same(sample['after_snapshot']['placements'], expected_after), 'EXAMPLE_SINGLE_PRIMITIVE_EXPANSION')
                examples += 1
        for transition in ('adoption', 'successor'):
            _need((transition in policy.get('plan_examples', {})) == (transitions[transition] > 0),
                  'MISSING_PLAN_EXAMPLES')
        _need(policy['telemetry']['adoptions'] == transitions['adoption'] and
              policy['telemetry']['successor_choices'] == transitions['successor'] and
              policy['telemetry']['forced_fulfillments'] == transitions['forced_fulfillment'] and
              policy['telemetry']['branch_member_fulfillments'] == transitions['branch_member_fulfillment'],
              'ACTUAL_TRANSITION_TELEMETRY')
        interface_groups = {}
        interface_seconds = 0.0
        for item in policy['interface_records']:
            receipt = item['receipt']
            key = item['phase']+'/'+receipt['status']
            interface_groups.setdefault(key, []).append(item)
            interface_seconds += _number(receipt['seconds'])
        _need(policy['telemetry']['interface_calls'] == len(policy['interface_records']), 'INTERFACE_CALL_CENSUS')
        _close(policy['telemetry']['interface_seconds'], interface_seconds, 'INTERFACE_COST_CENSUS')
        _need(set(policy['interface_samples']) == set(interface_groups), 'INTERFACE_SAMPLE_GROUP_CENSUS')
        for key, items in interface_groups.items():
            samples = policy['interface_samples'][key]
            _need(type(samples['seen']) is int and samples['seen'] == len(items), 'INTERFACE_ENDPOINT_CENSUS')
            for role, item in [('first', items[0]), ('last', items[-1])]:
                sample = samples[role]
                compact = {k: v for k, v in sample['receipt'].items()
                           if k not in ('domains', 'edge_units', 'parent_context')}
                _need(_same(compact, item['receipt']) and _same(sample['expansion'], item['expansion']) and
                      sample['family_id'] == item['family_id'], 'INTERFACE_RETAINED_ENDPOINT_JOIN')
        chain = _controller_chain(policy, search, edges, expected_rollbacks)
        return {'status': 'VERIFIED', 'reason': 'INDEPENDENT_TREE_POLICY_AND_CONTROLLER_RESTORE_JOIN',
                'tree': tree, 'events_checked': len(events), 'actual_after_place_events': len(after_events),
                'transitions': transitions, 'branch_orders_checked': len(decisions_by_prefix),
                'interrupted_orders': interrupted_orders, 'partial_cache_trials_without_after_event': cache_partial,
                'rollback_receipts_checked': len(receipts), 'expensive_engine_guards_recorded': guarded,
                'retained_plan_examples_linked': examples, 'replay_work': work,
                'interface_records_counted': len(policy['interface_records']),
                'interface_endpoint_groups_linked': len(interface_groups),
                'controller_state_chain': chain,
                'scope': 'Complete supplied native tree checked once; all actual primitive/controller events and saved/restored checkpoints joined. Selected full interface samples and learner arithmetic are separate APIs. Example point-graph tables and bank provenance are not silently certified by membership links.'}
    return _run('check_policy', run)
