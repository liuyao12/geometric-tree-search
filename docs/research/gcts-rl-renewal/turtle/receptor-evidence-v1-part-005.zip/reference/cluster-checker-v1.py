"""Independent proposed-cluster checks; no engine, policy, geometry or search.

The sole scientific dependency is the sibling independent_checker_v2.py, loaded
lazily after an exact Source hash check. Cluster legality is not a certificate
that its constituents may be executed as a scheduler-bypassing macro.
"""
import hashlib
import importlib.util
import json
from pathlib import Path

VERSION = 'Turtle-independent-cluster-checker-v1'
POINT_CHECKER_SHA256 = 'f05e1315fe3af0b902fc87aa28992a7f0685fc65f2dcab02b7e9fa50e6b180bd'
MAX_CLUSTER_PLACEMENTS = 64
_POINT_CHECKER = None


class DependencyError(Exception):
    pass


def _checker():
    global _POINT_CHECKER
    path = Path(__file__).resolve().with_name('independent_checker_v2.py')
    if hashlib.sha256(path.read_bytes()).hexdigest() != POINT_CHECKER_SHA256:
        raise DependencyError('INDEPENDENT_POINT_CHECKER_SOURCE_CHANGED')
    if _POINT_CHECKER is None:
        spec = importlib.util.spec_from_file_location('independent_point_dependency_v2', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _POINT_CHECKER = module
    return _POINT_CHECKER


def _wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _sha(value):
    return hashlib.sha256((_wire(value)+'\n').encode()).hexdigest()


def _need(condition, reason):
    if not condition:
        raise ValueError(reason)


def _guard(operation, function):
    point = None
    try:
        point = _checker()
        return dict(version=VERSION, operation=operation, **function(point))
    except DependencyError as error:
        return dict(version=VERSION, operation=operation, status='UNKNOWN', reason=str(error))
    except Exception as error:
        if point is not None and isinstance(error, point.Resource):
            return dict(version=VERSION, operation=operation, status='UNKNOWN', reason=str(error))
        if (point is not None and isinstance(error, point.Invalid)) or isinstance(
                error, (ValueError, TypeError, KeyError, IndexError, RecursionError)):
            return dict(version=VERSION, operation=operation, status='REJECTED', reason=str(error))
        raise


def _placements(point, verifier, rows):
    point._json(rows)
    _need(type(rows) is list and rows, 'EMPTY_OR_MALFORMED_CLUSTER')
    if len(rows) > MAX_CLUSTER_PLACEMENTS:
        raise point.Resource('CLUSTER_PLACEMENT_LIMIT')
    out = [verifier.placement(row) for row in rows]
    _need(len(out) == len(set(out)), 'DUPLICATE_CLUSTER_PLACEMENT')
    return out


def _aggregate(state):
    t = [[x, y, units] for (x, y), units in sorted(state['totals'].items())]
    m = [[x, y, json.loads(channel), json.loads(value)]
         for (x, y, channel), value in sorted(state['marks'].items())]
    return {'t': t, 'm': m, 'positive_points': len(t), 'assigned_mark_components': len(m),
            'sum_t_units': sum(row[2] for row in t), 'sha256': _sha({'t': t, 'm': m})}


def _contact_components(verifier, placements):
    """Exact positive-t support contact graph, independent of Root bank mining."""
    adjacency = [set() for _ in placements]
    owners = {}
    for index, placement in enumerate(placements):
        for q, _ in verifier.t_rows(placement):
            verifier.tick()
            for other in owners.get(q, ()):
                adjacency[index].add(other)
                adjacency[other].add(index)
            owners.setdefault(q, set()).add(index)
    unseen, components = set(range(len(placements))), []
    while unseen:
        first = min(unseen)
        pending, component = [first], set()
        while pending:
            index = pending.pop()
            if index in component:
                continue
            component.add(index)
            pending.extend(adjacency[index]-component)
        unseen.difference_update(component)
        components.append(component)
    return components


def check_cluster(model, cluster):
    """Check all distinct constituents together, without a viability assertion."""
    def run(point):
        verifier = point._Verifier(model)
        rows = _placements(point, verifier, cluster)
        state = verifier.state([list(p) for p in rows], None)
        components = _contact_components(verifier, rows)
        return {'status': 'VERIFIED', 'reason': 'INTERNALLY_LEGAL_DISTINCT_BASE_CLUSTER',
                'placements': [list(p) for p in rows], 'aggregate': _aggregate(state),
                'positive_support_connected': len(components) == 1,
                'component_count': len(components), 'component_sizes': [len(c) for c in components],
                'model_sha256': _sha(model), 'work': verifier.work,
                'scope': 'Internal capacity/inventory/mark agreement only; no frontier viability, macro execution or infinite-extension claim.'}
    return _guard('check_cluster', run)


def check_proposal(model, parent_snapshot, proposed_cluster, anchor, core=None):
    """Verify a legal proposed cluster and a new anchor in the exact branch domain.

    The parent is a complete generation-bearing snapshot, not a triple-only
    patch. Shared parent/cluster placement identities contribute exactly once.
    Only the anchor is proposed for ordering; no future constituent is executed.
    """
    def run(point):
        parent_receipt = point.check_snapshot(model, parent_snapshot)
        if parent_receipt['status'] != 'VERIFIED':
            return {'status': parent_receipt['status'], 'reason': 'PARENT_SNAPSHOT_NOT_VERIFIED',
                    'parent_receipt': parent_receipt}
        decision = parent_receipt['expected_decision']
        _need(decision['kind'] == 'branch', 'PROPOSAL_OUTSIDE_GENUINE_BRANCH_DECISION')
        target = point._core(parent_snapshot['core'])
        if core is not None:
            point._json(core)
            _need(point._core(core) == target, 'PROPOSAL_CORE_DIFFERS_FROM_PARENT')
        verifier = point._Verifier(model)
        parent_rows = [row['placement'] for row in parent_snapshot['placements']]
        parent_generations = [row['generation'] for row in parent_snapshot['placements']]
        parent = verifier.state(parent_rows, target, parent_generations, parent_snapshot['seed_count'])
        cluster = _placements(point, verifier, proposed_cluster)
        point._json(anchor)
        selected_anchor = verifier.placement(anchor)
        anchor_domain = {tuple(p) for p in decision['candidates']}
        _need(selected_anchor in anchor_domain, 'ANCHOR_OUTSIDE_EXACT_SELECTED_BRANCH_DOMAIN')
        _need(selected_anchor in cluster and selected_anchor not in parent['selected'],
              'ANCHOR_MISSING_OR_ALREADY_SELECTED')
        shared = set(cluster) & parent['selected']
        new = [p for p in cluster if p not in parent['selected']]
        _need(bool(new), 'NO_NEW_CLUSTER_PLACEMENT')
        cluster_state = verifier.state([list(p) for p in cluster], None)
        new_state = verifier.state([list(p) for p in new], None)
        union_rows = parent_rows+[list(p) for p in new]
        union = verifier.state(union_rows, target)
        common_marks = parent['marks'].keys() & new_state['marks'].keys()
        pt, nt = parent['totals'], new_state['totals']
        frontier = {tuple(row['point']) for row in parent_snapshot['domains']}
        touched = frontier & nt.keys()
        filled = [q for q in touched if union['totals'][q] == verifier.capacity]
        interface = {
            'positive_support_contact_points': len(pt.keys() & nt.keys()),
            'parent_frontier_points_touched': len(touched),
            'parent_frontier_points_filled_if_whole_cluster_were_added': len(filled),
            'overlapping_assigned_mark_components': len(common_marks),
            'mark_contacts_outside_parent_positive_support': sum((x, y) not in pt for x, y, _ in common_marks),
            'mark_contacts_outside_new_cluster_positive_support': sum((x, y) not in nt for x, y, _ in common_marks),
        }
        cluster_aggregate = _aggregate(cluster_state)
        new_aggregate = _aggregate(new_state)
        union_aggregate = _aggregate(union)
        binding = {'model_sha256': _sha(model), 'parent_snapshot_sha256': _sha(parent_snapshot),
                   'cluster': [list(p) for p in sorted(cluster)], 'anchor': list(selected_anchor),
                   'union_aggregate_sha256': union_aggregate['sha256']}
        return {'status': 'VERIFIED', 'reason': 'LEGAL_CLUSTER_WITH_NEW_EXACT_BRANCH_ANCHOR',
                'anchor': list(selected_anchor), 'branch_point': decision['point'],
                'parent_graph_sha256': parent_receipt['graph_sha256'],
                'new_placements': [list(p) for p in new],
                'shared_selected_placements_counted_once': [list(p) for p in sorted(shared)],
                'cluster_aggregate': cluster_aggregate, 'new_aggregate_contributions': new_aggregate,
                'union_aggregate_sha256': union_aggregate['sha256'], 'interface': interface,
                'proposal_fingerprint_sha256': _sha(binding), 'binding': binding,
                'work': verifier.work+parent_receipt['work'],
                'scope': 'Cluster compatibility and branch-anchor ordering only. Does not certify whole-cluster scheduler execution or constrain complete base fallback.'}
    return _guard('check_proposal', run)


def _matrix(point, matrix):
    _need(type(matrix) is list and len(matrix) == 2 and all(
        type(row) is list and len(row) == 2 and all(point._integer(v) for v in row)
        for row in matrix), 'GROUP_MATRIX_FORMAT')
    result = tuple(tuple(row) for row in matrix)
    _need(abs(result[0][0]*result[1][1]-result[0][1]*result[1][0]) == 1,
          'GROUP_MATRIX_NOT_UNIMODULAR')
    return result


def _act(matrix, xy):
    return (matrix[0][0]*xy[0]+matrix[0][1]*xy[1],
            matrix[1][0]*xy[0]+matrix[1][1]*xy[1])


def _multiply(a, b):
    return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)) for i in range(2))


def check_transform(model, groups, prototype, action, translation, concrete, *, normalized=True):
    """Check exact matrix action on every constituent and its concrete legality.

    groups is the frozen list of {id,matrix,...} from the input point model.
    The prototype's first placement is port0; normalized=True requires [0,0,0].
    Marked images are checked directly in the supplied orientation-mark model;
    no unprovided component-equivariance theorem is assumed.
    """
    def run(point):
        verifier = point._Verifier(model)
        point._json(groups)
        point._json(action)
        point._json(translation)
        _need(type(normalized) is bool, 'NORMALIZED_BOOL')
        _need(type(groups) is list and len(groups) <= point.MAX_ORIENTATIONS, 'GROUPS')
        matrices, inverse = {}, {}
        for row in groups:
            _need(type(row) is dict and {'id', 'matrix'} <= set(row) and point._integer(row['id']),
                  'GROUP_ROW')
            oid, matrix = row['id'], _matrix(point, row['matrix'])
            _need(oid not in matrices and matrix not in inverse, 'DUPLICATE_GROUP_ID_OR_MATRIX')
            matrices[oid], inverse[matrix] = matrix, oid
        _need(set(matrices) == set(verifier.orientations) and matrices.get(0) == ((1, 0), (0, 1)),
              'GROUP_ORIENTATION_IDS_OR_PORT0_IDENTITY')
        base = verifier.orientations[0]
        for oid, matrix in matrices.items():
            image = {_act(matrix, p): units for p, units in base.items()}
            _need(image == verifier.orientations[oid], 'GROUP_ACTION_NOT_EXACT_T_ORIENTATION')
            for other in matrices.values():
                _need(_multiply(matrix, other) in inverse, 'GROUP_NOT_CLOSED')
        _need(point._integer(action) and action in matrices, 'UNKNOWN_GROUP_ACTION')
        delta = point._point(translation)
        source = _placements(point, verifier, prototype)
        target = _placements(point, verifier, concrete)
        if normalized:
            _need(source[0] == (0, 0, 0), 'PROTOTYPE_PORT0_NOT_NORMALIZED')
        moved = []
        for oid, dx, dy in source:
            new_id = inverse[_multiply(matrices[action], matrices[oid])]
            x, y = _act(matrices[action], (dx, dy))
            moved.append((new_id, x+delta[0], y+delta[1]))
        _need(set(target) == set(moved), 'CONCRETE_CLUSTER_NOT_EXACT_GROUP_IMAGE')
        original = verifier.state([list(p) for p in source], None)
        actual = verifier.state([list(p) for p in target], None)
        _need((action, delta[0], delta[1]) in target if normalized else True, 'CONCRETE_PORT0_MISSING')
        return {'status': 'VERIFIED', 'reason': 'EXACT_GROUP_IMAGE_AND_CONCRETE_BASE_LEGALITY',
                'action': action, 'translation': list(delta), 'normalized_port0': normalized,
                'expected_placements': [list(p) for p in moved],
                'port0_image': list(moved[0]), 'prototype_aggregate_sha256': _aggregate(original)['sha256'],
                'concrete_aggregate': _aggregate(actual), 'model_sha256': _sha(model),
                'group_data_sha256': _sha(groups), 'work': verifier.work,
                'scope': 'Exact integer placement action and direct t/m validation of both clusters. No assumed marking-component equivariance or executed macro.'}
    return _guard('check_transform', run)
