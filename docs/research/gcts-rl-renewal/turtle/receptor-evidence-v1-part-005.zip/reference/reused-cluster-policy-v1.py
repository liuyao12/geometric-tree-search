"""Exact jointly valid Turtle cluster proposals and memoryless branch policies.

No search/geometry/checker is imported. Callers admit only independently checked
positive patches to the bank and supply independently verified episode rewards.
Clusters order one primitive anchor; every base candidate remains a fallback.
"""
import hashlib
import json
import math
import random
import time


LANES = ('UNMARKED_LEX', 'MARKED_LEX', 'MARKED_BASE_HEURISTIC',
         'MARKED_CLUSTER_HEURISTIC', 'MARKED_CLUSTER_RANDOM', 'MARKED_CLUSTER_RL')
FEATURE_NAMES = ('bias', 'core_gain_fraction', 'new_tile_fraction',
                 'shared_tile_fraction', 'frontier_completion_fraction',
                 'negative_new_exposure_fraction', 'mark_interface_agreement_fraction',
                 'negative_mean_distance_fraction')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256((wire(value) + '\n').encode()).hexdigest()


def integer(value):
    require(type(value) is int, 'Exact integer required, not bool or float.')
    return value


def placement(value):
    require(type(value) in (list, tuple) and len(value) == 3, 'Placement triple required.')
    return tuple(integer(v) for v in value)


def multiply(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2))
                       for j in range(2)) for i in range(2))


def move(matrix, x, y):
    return matrix[0][0] * x + matrix[0][1] * y, matrix[1][0] * x + matrix[1][1] * y


class Bank:
    """A bounded proposal inventory, never a restriction on base candidates."""
    def __init__(self, model, reference_groups, max_templates=32):
        require(type(max_templates) is int and 1 <= max_templates <= 32, 'Bank cap must be 1..32.')
        self.model = json.loads(wire(model))
        self.model_sha256 = digest(model)
        self.capacity = integer(model['capacity'])
        require(self.capacity > 0, 'Positive point capacity required.')
        rows = reference_groups['groups'] if type(reference_groups) is dict else reference_groups
        self.groups = {}
        by_matrix = {}
        for row in rows:
            gid = integer(row['id'])
            matrix = tuple(tuple(integer(v) for v in r) for r in row['matrix'])
            require(len(matrix) == 2 and all(len(r) == 2 for r in matrix), 'Axial 2x2 matrices required.')
            require(gid not in self.groups and matrix not in by_matrix, 'Duplicate group ID/matrix.')
            self.groups[gid] = matrix
            by_matrix[matrix] = gid
        require(set(self.groups) == set(range(12)) and self.groups[0] == ((1, 0), (0, 1)),
                'Complete twelve-element group with identity0 required.')
        self.product = {}
        for g, matrix in self.groups.items():
            for h, other in self.groups.items():
                product = multiply(matrix, other)
                require(product in by_matrix, 'Group matrices are not closed.')
                self.product[g, h] = by_matrix[product]
        self.inverse = {g: next(h for h in self.groups
                               if self.product[g, h] == self.product[h, g] == 0) for g in self.groups}
        self.t, self.m = {}, {}
        for row in model['orientations']:
            gid = integer(row['id'])
            require(gid not in self.t, 'Duplicate t orientation.')
            field = {}
            for x, y, u in row['points']:
                x, y, u = integer(x), integer(y), integer(u)
                require((x, y) not in field and 0 < u <= self.capacity, 'Invalid positive t component.')
                field[x, y] = u
            require(bool(field), 'Empty base tile.')
            self.t[gid] = field
        require(set(self.t) == set(self.groups), 'Point inventory/group IDs differ.')
        for row in model.get('marking_orientations', []):
            gid = integer(row['id'])
            require(gid in self.t and gid not in self.m, 'Invalid/duplicate marking orientation.')
            field = {}
            for x, y, channel, value in row['points']:
                x, y = integer(x), integer(y)
                require(value != '*', 'Individual absence must be omitted from exported markings.')
                key = x, y, wire(channel)
                require(key not in field, 'Duplicate typed mark component.')
                field[key] = wire(value)
            self.m[gid] = field
        self.max_templates = max_templates
        self.templates, self.keys = [], {}
        self.frozen = False
        self.admissions = []
        self.admission_seconds = 0.0

    def normalize(self, placements):
        placements = [placement(p) for p in placements]
        require(placements and len(set(placements)) == len(placements), 'Nonempty distinct primitive expansion required.')
        g0, x0, y0 = placements[0]
        require(all(g in self.groups for g, x, y in placements), 'Unknown orientation in cluster.')
        inverse = self.inverse[g0]
        matrix = self.groups[inverse]
        normalized = []
        for g, x, y in placements:
            a, b = move(matrix, x - x0, y - y0)
            normalized.append((self.product[inverse, g], a, b))
        require(normalized[0] == (0, 0, 0), 'Port normalization failed.')
        return [normalized[0]] + sorted(normalized[1:])

    def anchor(self, template, candidate):
        g, x, y = placement(candidate)
        matrix = self.groups[g]
        expansion = []
        for h, a, b in template['placements']:
            dx, dy = move(matrix, a, b)
            expansion.append((self.product[g, h], x + dx, y + dy))
        return expansion

    def connected(self, placements):
        """Constituent graph adjacency is shared positive t-support, exactly."""
        placements = [placement(p) for p in placements]
        if not placements:
            return False
        parent = list(range(len(placements)))

        def root(i):
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        owners = {}
        for i, (g, dx, dy) in enumerate(placements):
            require(g in self.t, 'Unknown orientation in connectivity check.')
            for x, y in self.t[g]:
                point = x + dx, y + dy
                if point in owners:
                    parent[root(i)] = root(owners[point])
                else:
                    owners[point] = i
        return len({root(i) for i in range(len(placements))}) == 1

    def validate(self, expansion, T, M, selected, allowed=None):
        """Exact aggregate check; shared selected placements contribute only once.

        M has the engine's exact JSON-encoded channel/value keys and reference
        counts. No engine fields, dependency indexes or caches are modified.
        """
        expansion = [placement(p) for p in expansion]
        if len(expansion) != len(set(expansion)):
            return dict(valid=False, reason='DUPLICATE_PRIMITIVE')
        if any(g not in self.t for g, x, y in expansion):
            return dict(valid=False, reason='UNKNOWN_ORIENTATION')
        shared = [p for p in expansion if p in selected]
        new = [p for p in expansion if p not in selected]
        if allowed is not None and any(p not in allowed for p in new):
            return dict(valid=False, reason='INVENTORY')
        additions, marks, interface = {}, {}, set()
        for g, dx, dy in new:
            for (x, y), units in self.t[g].items():
                key = x + dx, y + dy
                additions[key] = additions.get(key, 0) + units
                if T.get(key, 0) + additions[key] > self.capacity:
                    return dict(valid=False, reason='JOINT_CAPACITY')
            for (x, y, channel), value in self.m.get(g, {}).items():
                key = x + dx, y + dy, channel
                if key in marks and marks[key] != value:
                    return dict(valid=False, reason='INTERNAL_MARK_DISAGREEMENT')
                if key in M:
                    if M[key][0] != value:
                        return dict(valid=False, reason='STATE_MARK_DISAGREEMENT')
                    interface.add(key)
                marks[key] = value
        return dict(valid=True, reason=None, expansion=expansion, new=new, shared=shared,
                    additions=additions, marks=marks, interface_agreements=len(interface))

    def add_from_positive(self, placements, origin, verification, *, windows=False):
        """Admit a caller-certified positive patch; never reads a target proof.

        windows=False keeps the exact full patch (initial followups). Training
        windows=True tries lengths8..12 at starts0,4,8,..., up to max_templates.
        The checked patch's supplied placement order defines the windows.
        """
        started = time.perf_counter()
        require(not self.frozen, 'Cannot add to a frozen bank.')
        require(type(verification) is dict and verification.get('status') == 'VERIFIED',
                'Independent positive-patch verification receipt required.')
        placements = [placement(p) for p in placements]
        require(len(set(placements)) == len(placements), 'Certified patch repeats a placement.')
        full = self.validate(placements, {}, {}, set())
        require(full['valid'], 'Supplied positive patch fails exact point/mark compatibility.')
        pieces = [(0, len(placements), placements)] if not windows else [
            (start, length, placements[start:start + length])
            for start in range(0, len(placements), 4) for length in range(8, 13)
            if start + length <= len(placements)]
        added, duplicates, too_small, capped, disconnected = [], 0, 0, 0, 0
        for start, length, piece in pieces:
            if len(piece) < 2:
                too_small += 1
                continue
            if not self.connected(piece):
                disconnected += 1
                continue
            normalized = self.normalize(piece)
            require(self.connected(normalized), 'Point-group normalization changed cluster connectivity.')
            key = tuple(normalized)
            if key in self.keys:
                duplicates += 1
                continue
            if len(self.templates) >= self.max_templates:
                capped += 1
                continue
            check = self.validate(normalized, {}, {}, set())
            require(check['valid'], 'Normalized cluster does not preserve exact decorated legality.')
            index = len(self.templates)
            record = dict(id='cluster-%02d' % index, index=index,
                placements=[list(p) for p in normalized], port=[0, 0, 0],
                origin=json.loads(wire(origin)), window=dict(start=start, length=length),
                verification=json.loads(wire(verification)), model_sha256=self.model_sha256,
                positive_support_connected=True,
                admission='independently checked positive patch plus exact aggregate t/m check')
            self.keys[key] = index
            self.templates.append(record)
            added.append(record['id'])
        elapsed = time.perf_counter() - started
        self.admission_seconds += elapsed
        receipt = dict(added=added, duplicate_windows=duplicates, too_small=too_small,
            disconnected_windows=disconnected,
            capacity_refused_windows=capped, bank_size=len(self.templates), windows=windows,
            origin=json.loads(wire(origin)), seconds=elapsed)
        self.admissions.append(receipt)
        return receipt

    def freeze(self):
        self.frozen = True
        return self.snapshot()

    def snapshot(self):
        return dict(schema='Turtle-validated-cluster-bank-v1', model_sha256=self.model_sha256,
            frozen=self.frozen, max_templates=self.max_templates,
            templates=json.loads(wire(self.templates)), admissions=json.loads(wire(self.admissions)),
            admission_seconds=self.admission_seconds,
            connectivity_rule='Every admitted full patch/window has a connected constituent graph; adjacency means sharing a positive t-support point. Proposal-inventory restriction only.',
            bank_sha256=digest(dict(model_sha256=self.model_sha256, templates=self.templates)),
            scope='Proposal inventory only; no base placement is removed when a template is missing or refused.')


def features(engine, validation, decision_point, template_index, max_templates):
    additions = validation['additions']
    cap = engine.capacity
    core_gain = sum(min(cap - engine.T.get(p, 0), additions.get(p, 0)) for p in engine.core)
    completed = sum(engine.T.get(p, 0) + additions.get(p, 0) == cap for p in engine.domains)
    exposed = sum(p not in engine.T and units < cap for p, units in additions.items())
    new_count, shared_count = len(validation['new']), len(validation['shared'])
    px, py = decision_point
    distances = [max(abs(x - px), abs(y - py), abs((x - px) + (y - py)))
                 for g, x, y in validation['new']]
    distance = sum(distances) / max(1, len(distances))
    values = [1.0, core_gain / (cap * max(1, len(engine.core))),
        new_count / (1 + new_count), shared_count / max(1, new_count + shared_count),
        completed / max(1, len(engine.domains)), -exposed / (1 + exposed),
        validation['interface_agreements'] / max(1, len(validation['marks'])),
        -distance / (1 + distance)]
    values += [float(template_index == i) for i in range(max_templates)]
    return values, dict(core_gain_units=core_gain, new_count=new_count, shared_count=shared_count,
        frontier_completed=completed, new_exposed_points=exposed,
        mark_interface_agreements=validation['interface_agreements'], mean_distance=distance)


def action_record(engine, bank, candidate, validation, point, template=None):
    vector, facts = features(engine, validation, point,
                             template['index'] if template is not None else -1, bank.max_templates)
    heuristic = facts['core_gain_units'] / bank.capacity + 0.2 * facts['frontier_completed']
    heuristic += 0.05 * facts['new_count'] - 0.005 * facts['new_exposed_points']
    return dict(kind='cluster' if template is not None else 'base', anchor=list(candidate),
        cluster_id=template['id'] if template is not None else None,
        cluster_index=template['index'] if template is not None else None,
        primitive_expansion=[list(p) for p in validation['expansion']],
        new_placements=[list(p) for p in validation['new']],
        shared_placements=[list(p) for p in validation['shared']],
        features=vector, facts=facts, heuristic_score=heuristic)


def propose(engine, candidates, bank, cap=48):
    """Same bounded, deterministic, jointly validated pool for all cluster lanes."""
    started = time.perf_counter()
    require(type(cap) is int and 0 <= cap <= 48, 'Proposal trial cap must be 0..48.')
    require(engine.model == bank.model, 'Cluster proposal model differs from bank model.')
    decision = engine.decision()
    require(decision['kind'] == 'branch', 'Cluster proposals are only defined at a branch.')
    candidates = sorted(placement(c) for c in candidates)
    require(len(candidates) == len(set(candidates))
            and candidates == sorted(placement(c) for c in decision['candidates']),
            'Proposal anchors must be the complete selected branch domain.')
    point = tuple(decision['point'])
    selected = set(engine.selected)
    allowed = engine.allowed
    state = dict(model_sha256=bank.model_sha256, core=sorted(engine.core), grow=engine.grow,
                 selected=sorted(selected), point=point, candidates=candidates)
    state_sha = digest(state)
    actions, trials = [], []
    for candidate in candidates:
        check = bank.validate([candidate], engine.T, engine.M, selected, allowed)
        require(check['valid'], 'A complete branch-domain base candidate fails exact validation.')
        actions.append(action_record(engine, bank, candidate, check, point))
    total = len(bank.templates) * len(candidates)
    offset = int(state_sha[:16], 16) % total if total else 0
    stride = 1 + int(state_sha[16:32], 16) % total if total else 1
    while total and math.gcd(stride, total) != 1:
        stride = stride % total + 1
    seen = set()
    for i in range(min(cap, total)):
        index = (offset + i * stride) % total
        template_index, candidate_index = divmod(index, len(candidates))
        template, anchor = bank.templates[template_index], candidates[candidate_index]
        expansion = bank.anchor(template, anchor)
        check = bank.validate(expansion, engine.T, engine.M, selected, allowed)
        reason = check['reason']
        if check['valid'] and len(check['new']) < 2:
            reason = 'FEWER_THAN_TWO_NEW_PRIMITIVES'
        signature = tuple(sorted(expansion))
        if check['valid'] and reason is None and signature in seen:
            reason = 'DUPLICATE_EXPANSION'
        trial = dict(trial=i, cycle_index=index, cluster_id=template['id'], anchor=list(anchor),
                     valid=check['valid'] and reason is None, reject_reason=reason)
        if trial['valid']:
            seen.add(signature)
            action = action_record(engine, bank, anchor, check, point, template)
            actions.append(action)
            trial.update(features=action['features'], facts=action['facts'],
                         action_index=len(actions) - 1)
        trials.append(trial)
    return dict(state_sha256=state_sha, branch_point=list(point), actions=actions,
        trials=trials, tested=len(trials), possible_cluster_anchor_pairs=total,
        cycle_offset=offset, cycle_stride=stride, proposal_cap=cap,
        proposal_seconds=time.perf_counter() - started,
        all_base_actions_retained=len(candidates),
        scope='Jointly valid proposals order only their primitive anchor; no atomic or sequence execution.')


class Controller:
    """Memoryless branch ordering, with optional episodic linear-softmax learning."""
    def __init__(self, bank, lane, *, seed=0, training=False, learning_rate=0.03,
                 proposal_cap=48, weights=None):
        require(lane in LANES, 'Unknown policy lane.')
        require(not training or lane == 'MARKED_CLUSTER_RL', 'Only the RL lane trains.')
        require(type(seed) is int, 'Integer stochastic seed required.')
        require(math.isfinite(learning_rate) and learning_rate > 0, 'Positive finite learning rate required.')
        require(type(proposal_cap) is int and 0 <= proposal_cap <= 48, 'Proposal cap must be 0..48.')
        self.bank, self.lane, self.training = bank, lane, bool(training)
        self.seed, self.rng = seed, random.Random(seed)
        self.learning_rate, self.proposal_cap = float(learning_rate), proposal_cap
        dimension = len(FEATURE_NAMES) + bank.max_templates
        self._weights = [0.0] * dimension if weights is None else list(weights)
        require(len(self._weights) == dimension and all(type(v) in (int, float) and math.isfinite(v)
                and abs(v) <= 8 for v in self._weights), 'Weights must be finite, bounded and have the declared dimension.')
        self._weights = [float(v) for v in self._weights]
        self.baseline, self.episodes = 0.0, 0
        self.updates = []
        self.start_episode()

    def start_episode(self, seed=None):
        """Clear per-episode data while keeping weights/baseline/bank unchanged."""
        if seed is not None:
            require(type(seed) is int, 'Integer per-episode stochastic seed required.')
            self.rng = random.Random(seed)
        self.episode_seed = seed
        self.rng_state_before_sha256 = digest(self.rng.getstate())
        self.episode_finished = False
        self.decisions, self.gradients = [], []
        self.cluster_events = dict(first=None, last=None, seen=0)
        self.telemetry = dict(calls=0, branch_choices=0, forced_bypasses=0, trials=0,
            valid_cluster_actions=0, chosen_cluster_actions=0, proposal_seconds=0.0, controller_seconds=0.0)

    def begin_episode(self, seed=None):
        return self.start_episode(seed)

    def __call__(self, engine, candidates):
        started = time.perf_counter()
        require(not self.episode_finished, 'Call start_episode before another search episode.')
        candidates = sorted(placement(c) for c in candidates)
        require(len(candidates) == len(set(candidates)), 'Repeated base candidate.')
        decision = engine.decision()
        self.telemetry['calls'] += 1
        require(candidates == sorted(placement(c) for c in decision['candidates']),
                'Ordering hook must receive the complete decision domain.')
        if decision['kind'] != 'branch':
            require(decision['kind'] == 'forced', 'Order hook called outside a move decision.')
            self.telemetry['forced_bypasses'] += 1
            self.telemetry['controller_seconds'] += time.perf_counter() - started
            return candidates
        if self.lane in ('UNMARKED_LEX', 'MARKED_LEX'):
            self.telemetry['controller_seconds'] += time.perf_counter() - started
            return candidates
        require(engine.model == self.bank.model, 'Marked policy/model binding differs.')
        cluster_lane = self.lane in ('MARKED_CLUSTER_HEURISTIC', 'MARKED_CLUSTER_RANDOM', 'MARKED_CLUSTER_RL')
        packet = propose(engine, candidates, self.bank, self.proposal_cap if cluster_lane else 0)
        actions = packet['actions']
        probabilities, model_probabilities = None, None
        logits = [sum(w * x for w, x in zip(self._weights, a['features'])) for a in actions]
        peak = max(logits)
        masses = [math.exp(value - peak) for value in logits]
        total = sum(masses)
        model_probabilities = [value / total for value in masses]
        if self.lane == 'MARKED_CLUSTER_RL':
            if self.training:
                draw, cumulative, chosen = self.rng.random(), 0.0, len(actions) - 1
                for i, probability in enumerate(model_probabilities):
                    cumulative += probability
                    if draw < cumulative:
                        chosen = i
                        break
                probabilities = model_probabilities
                expectation = [sum(p * a['features'][j] for p, a in zip(model_probabilities, actions))
                               for j in range(len(self._weights))]
                self.gradients.append([x - mean for x, mean in zip(actions[chosen]['features'], expectation)])
            else:
                chosen = min(range(len(actions)), key=lambda i: (-logits[i], i))
        elif self.lane == 'MARKED_CLUSTER_RANDOM':
            chosen = self.rng.randrange(len(actions))
            probabilities = [1.0 / len(actions)] * len(actions)
        else:
            chosen = min(range(len(actions)), key=lambda i: (-actions[i]['heuristic_score'], i))
        action = actions[chosen]
        behavior_probability = probabilities[chosen] if probabilities is not None else 1.0
        log_probability = math.log(behavior_probability)
        self.telemetry['branch_choices'] += 1
        self.telemetry['trials'] += packet['tested']
        self.telemetry['valid_cluster_actions'] += sum(a['kind'] == 'cluster' for a in actions)
        self.telemetry['chosen_cluster_actions'] += action['kind'] == 'cluster'
        self.telemetry['proposal_seconds'] += packet['proposal_seconds']
        self.decisions.append(dict(state_sha256=packet['state_sha256'], branch_point=packet['branch_point'],
            trials=packet['trials'], tested=packet['tested'],
            possible_cluster_anchor_pairs=packet['possible_cluster_anchor_pairs'],
            cycle_offset=packet['cycle_offset'], cycle_stride=packet['cycle_stride'],
            base_action_count=len(candidates), action_count=len(actions),
            chosen_action=json.loads(wire(action)), behavior_probability=behavior_probability,
            behavior_log_probability=log_probability, model_softmax_probability=model_probabilities[chosen],
            action_feature_table=[dict(kind=a['kind'], anchor=a['anchor'], cluster_index=a['cluster_index'],
                                       continuous=a['features'][:len(FEATURE_NAMES)]) for a in actions],
            model_softmax_probabilities=model_probabilities,
            policy='stochastic linear-softmax' if self.training else self.lane,
            proposal_seconds=packet['proposal_seconds'],
            ordering_effect='Only chosen anchor first; every other base candidate remains lexical fallback.'))
        if action['kind'] == 'cluster':
            event = dict(choice_index=len(self.decisions) - 1, parent_snapshot=engine.snapshot(),
                anchor=list(action['anchor']), expansion=json.loads(wire(action['primitive_expansion'])),
                cluster_id=action['cluster_id'], action_gid=action['anchor'][0],
                translation=list(action['anchor'][1:]), new_placements=json.loads(wire(action['new_placements'])),
                shared_placements=json.loads(wire(action['shared_placements'])),
                features=list(action['features']), behavior_probability=behavior_probability,
                behavior_log_probability=log_probability)
            if self.cluster_events['first'] is None:
                self.cluster_events['first'] = event
            self.cluster_events['last'] = event
            self.cluster_events['seen'] += 1
        anchor = tuple(action['anchor'])
        ordered = [anchor] + [c for c in candidates if c != anchor]
        require(set(ordered) == set(candidates) and len(ordered) == len(candidates),
                'Policy changed the complete base candidate set.')
        self.telemetry['controller_seconds'] += time.perf_counter() - started
        return ordered

    def finish_episode(self, reward):
        """REINFORCE update from a caller's independently verified episode reward.

        Uses reward minus the pre-episode running baseline; averages the sum of
        score-function gradients by the number of branch choices; projects each
        resulting weight to [-8,8]. No proof labels or target paths enter here.
        """
        require(not self.episode_finished, 'Episode reward has already been consumed.')
        require(type(reward) in (int, float) and math.isfinite(reward), 'Finite episode reward required.')
        old = list(self._weights)
        advantage = float(reward) - self.baseline
        gradient = [sum(row[j] for row in self.gradients) / max(1, len(self.gradients))
                    for j in range(len(old))]
        if self.training:
            self._weights = [max(-8.0, min(8.0, w + self.learning_rate * advantage * g))
                             for w, g in zip(old, gradient)]
        update = dict(episode=self.episodes, reward=float(reward), baseline_before=self.baseline,
            advantage=advantage, stochastic_choices=len(self.gradients),
            gradient=gradient, learning_rate=self.learning_rate, weights_before=old,
            weights_after=list(self._weights), updated=self.training and self._weights != old,
            reward_scope='Caller supplies independently verified terminal outcome/cost reward; no target proof supervision.')
        self.baseline = 0.9 * self.baseline + 0.1 * float(reward)
        self.episodes += 1
        self.updates.append(update)
        self.gradients = []
        self.episode_finished = True
        return json.loads(wire(update))

    def freeze(self):
        self.training = False
        self.gradients = []
        return self.snapshot()

    def snapshot(self):
        return dict(schema='Turtle-cluster-REINFORCE-controller-v1', lane=self.lane,
            training=self.training, seed=self.seed, episodes=self.episodes,
            episode_seed=self.episode_seed, rng_state_before_sha256=self.rng_state_before_sha256,
            episode_finished=self.episode_finished,
            feature_names=list(FEATURE_NAMES) + ['cluster_id_%02d' % i for i in range(self.bank.max_templates)],
            weights=list(self._weights), weights_sha256=digest(self._weights), baseline=self.baseline,
            learning_rate=self.learning_rate, proposal_cap=self.proposal_cap,
            bank_sha256=self.bank.snapshot()['bank_sha256'],
            telemetry=dict(self.telemetry), decisions=json.loads(wire(self.decisions)),
            chosen_cluster_events=json.loads(wire(self.cluster_events)),
            updates=json.loads(wire(self.updates)),
            scope='Memoryless branch-anchor policy. No macro, sequence execution, learned pruning, hidden geometry or substitution input. All complete base actions remain available.')
