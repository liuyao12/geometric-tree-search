"""Read-only assurance-projection regression; Source-only until Root approval.

Replays only pinned independent checkers, never engine/policy/search code.
The 24 training and first 40 complete evaluation files are the fixed subjects.
Record40's unavailable policy is not reconstructed. Its original exit/resource
failure and separately retained raw search are recorded explicitly.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import time

ROOT = Path(__file__).resolve().parents[2]
VERSION = 'Turtle-assurance-projection-regression-v1'
N_SHA256 = 'df5778636606806717f4675358fd93b818d02c16f8572d1986580fb2174462cb'
V_SHA256 = 'f05e1315fe3af0b902fc87aa28992a7f0685fc65f2dcab02b7e9fa50e6b180bd'
PROJECTION_SHA256 = 'e23236c8202cbf4b081dfef6d729feb6826ed48f171fb814c5989d0436e21be9'


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read_json(path):
    stored = path.read_bytes()
    raw = gzip.decompress(stored) if path.suffix == '.gz' else stored
    return json.loads(raw), {'path': str(path.resolve()), 'bytes': len(stored),
                            'sha256': hashlib.sha256(stored).hexdigest(),
                            'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}


def module(name, path, expected):
    need(pin(path)['sha256'] == expected, 'PINNED_SOURCE:'+str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def retained_values(original, projected):
    """Independent exact subset/path audit; no projection helper is trusted.

    Every retained array keeps its complete length/order. Scalar Python types
    and floating-point hexadecimal values must be identical at the same path.
    Omissions are object keys, never selected decisions/events/update rows.
    """
    pending = [(original, projected, [])]
    counts = dict(objects=0, arrays=0, integers=0, floats=0, booleans=0, strings=0, nulls=0)
    numeric_hash = hashlib.sha256()
    while pending:
        a, b, path = pending.pop()
        need(type(a) is type(b), 'PROJECTION_CHANGED_JSON_TYPE:'+wire(path))
        kind = type(b)
        if kind is dict:
            need(set(b) <= set(a), 'PROJECTION_INVENTED_FIELD:'+wire(path))
            counts['objects'] += 1
            pending.extend((a[key], b[key], path+[key]) for key in b)
        elif kind is list:
            need(len(a) == len(b), 'PROJECTION_DROPPED_OR_INSERTED_ARRAY_MEMBER:'+wire(path))
            counts['arrays'] += 1
            pending.extend((x, y, path+[i]) for i, (x, y) in enumerate(zip(a, b)))
        elif kind is float:
            need(math.isfinite(a) and a.hex() == b.hex(), 'PROJECTION_CHANGED_FLOAT:'+wire(path))
            counts['floats'] += 1
            numeric_hash.update((wire([path, 'float', a.hex()])+'\n').encode('ascii'))
        elif kind is int:
            need(a == b, 'PROJECTION_CHANGED_INTEGER:'+wire(path))
            counts['integers'] += 1
            numeric_hash.update((wire([path, 'int', a])+'\n').encode('ascii'))
        elif kind is bool:
            need(a is b, 'PROJECTION_CHANGED_BOOLEAN:'+wire(path))
            counts['booleans'] += 1
        elif kind is str:
            need(a == b, 'PROJECTION_CHANGED_STRING:'+wire(path))
            counts['strings'] += 1
        else:
            need(a is None and b is None, 'NON_NATIVE_JSON')
            counts['nulls'] += 1
    return {'status': 'EXACT', 'retained_counts': counts,
            'retained_numeric_paths_sha256': numeric_hash.hexdigest()}


def explicit_retention(original, pv, lv):
    need(len(pv['decisions']) == len(lv['decisions']) == len(original['decisions']), 'DECISION_CENSUS')
    for key in ('events', 'checkpoint', 'telemetry', 'interface_records'):
        need(wire(pv[key]) == wire(original[key]), 'POLICY_FULL_FIELD_RETENTION:'+key)
    for key in ('updates', 'feature_names', 'weights', 'baseline', 'learning_rate', 'telemetry'):
        need(wire(lv[key]) == wire(original[key]), 'LEARNING_FULL_FIELD_RETENTION:'+key)
    for full, policy, learning in zip(original['decisions'], pv['decisions'], lv['decisions']):
        for key in ('parent_context', 'chosen_action', 'action_feature_table', 'state_sha256'):
            need(wire(policy[key]) == wire(full[key]) == wire(learning[key]), 'ACTION_FIELD_RETENTION:'+key)
        need(wire(policy['checkpoint_after']) == wire(full['checkpoint_after']), 'ORDER_CHECKPOINT_RETENTION')
        for key in ('weights', 'model_softmax_probabilities', 'model_softmax_probability',
                    'behavior_probability', 'behavior_log_probability', 'chosen_index',
                    'action_count', 'base_action_count'):
            need(wire(learning[key]) == wire(full[key]), 'ACTUAL_LEARNING_NUMBER_RETENTION:'+key)
    return {'all_events_and_decisions_retained': True, 'all_update_rows_retained': True,
            'all_actual_action_feature_weight_probability_gradient_reward_baseline_values_retained': True,
            'scope': 'All assurance read-set numeric values and complete decision/event/update arrays. Unused copied graph coordinates may be omitted intentionally.'}


def compare_receipts(full, projected):
    if full['status'] == 'VERIFIED':
        need(projected['status'] == 'VERIFIED' and wire(full) == wire(projected),
             'ORIGINAL_VERIFIED_RECEIPT_CHANGED_BY_PROJECTION')
        return 'IDENTICAL_VERIFIED_RECEIPT'
    if full['status'] == 'UNKNOWN' and full.get('reason') == 'JSON_RESOURCE_BOUND':
        need(projected['status'] in ('VERIFIED', 'UNKNOWN'), 'PROJECTED_REQUIRED_FIELDS_REJECTED')
        return 'ORIGINAL_JSON_RESOURCE_REFUSAL_RETAINED'
    need(wire(full) == wire(projected), 'UNEXPECTED_NONRESOURCE_VERDICT_CHANGE')
    return 'IDENTICAL_OTHER_RECEIPT'


def replay_pair(function, original, projected):
    start = time.perf_counter()
    full = function(original)
    full_seconds = time.perf_counter()-start
    start = time.perf_counter()
    view = function(projected)
    view_seconds = time.perf_counter()-start
    return {'full': full, 'projected': view, 'relation': compare_receipts(full, view),
            'full_checker_seconds': full_seconds, 'projected_checker_seconds': view_seconds}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=ROOT/'recovery/review/projection-regression-v1.json')
    args = parser.parse_args()
    root = args.root.resolve()
    need(not args.output.exists(), 'EXCLUSIVE_REGRESSION_OUTPUT_EXISTS')
    started = time.perf_counter()
    protocol, protocol_pin = read_json(root/'data/protocol-frozen-v1.json')
    guards = {name: expected for name, expected in protocol['pins'].items()
              if name.endswith('.py') and name.startswith(('source/', 'reference/'))}
    for name, expected in guards.items():
        need(pin(root/name) == expected, 'ORIGINAL_FROZEN_SOURCE:'+name)
    need(pin(root/'reference/independent_checker_v2.py')['sha256'] == V_SHA256, 'PINNED_V2')
    projection_path = root/'recovery/source/assurance_projection_v1.py'
    projection = module('independent_assurance_projection_for_regression', projection_path, PROJECTION_SHA256)
    N = module('unchanged_continuation_checker_for_projection_regression',
               root/'reference/continuation_checker_v1.py', N_SHA256)
    need(projection.CHECKER_SHA256 == N_SHA256, 'PROJECTION_READSET_VERSION_BINDING')
    model, model_pin = read_json(root/'data/marked-model-v1.json')
    need({k: model_pin[k] for k in ('bytes', 'sha256')} == protocol['pins']['data/marked-model-v1.json'],
         'FROZEN_MARKED_MODEL')
    records, relations, readbacks = [], {}, []
    for phase, count, prefix in [('training', 24, 'train'), ('evaluation', 40, 'eval')]:
        for index in range(count):
            relative = 'data/%s/%s-%03d.json.gz' % (phase, prefix, index)
            row, file_pin = read_json(root/relative)
            need(row['episode' if phase == 'training' else 'index'] == index, 'FIXED_PREFIX_RECORD_IDENTITY')
            raw_ref = row['raw']
            raw_path = (root/raw_ref['run_file']).resolve()
            need(raw_path.is_relative_to(root), 'RAW_REFERENCE_OUTSIDE_RUN')
            raw_search, raw_pin = read_json(raw_path)
            need({k: raw_pin[k] for k in ('bytes', 'sha256')} == raw_ref['run_pin'], 'ORIGINAL_RAW_SEARCH_PIN')
            need(wire(raw_search) == wire(row['search']), 'RAW_SEARCH_FULL_CONTENT_JOIN')
            policy = row['policy']
            pv, lv = projection.policy_view(policy), projection.learning_view(policy)
            retention = None
            if policy is not None:
                retention = {'policy_view': retained_values(policy, pv),
                             'learning_view': retained_values(policy, lv),
                             'explicit_actual_number_census': explicit_retention(policy, pv, lv)}
            else:
                need(pv is None and lv is None, 'NO_CONTROLLER_BASELINE_CHANGED')
            policy_comparison = replay_pair(lambda p: N.check_policy(model, row['search'], p), policy, pv)
            learning_comparison = None
            if policy is not None:
                reward = row['reward'] if phase == 'training' else None
                learning_comparison = replay_pair(lambda p: N.check_learning(p, reward), policy, lv)
            for comparison in [policy_comparison, learning_comparison]:
                if comparison is not None:
                    relation = comparison['relation']
                    relations[relation] = relations.get(relation, 0)+1
            readbacks.extend([file_pin, raw_pin])
            records.append({'phase': phase, 'index': index, 'case_id': row['case_id'], 'lane': row['lane'],
                            'record': {'relative_path': relative, **file_pin}, 'raw_search': raw_pin,
                            'retention': retention, 'policy_comparison': policy_comparison,
                            'learning_comparison': learning_comparison,
                            'saved_original_policy_receipt': row['assurance'].get('policy'),
                            'saved_original_learning_receipt': row.get('learning_check')})
            print(wire({'phase': phase, 'index': index, 'policy': policy_comparison['relation'],
                        'learning': None if learning_comparison is None else learning_comparison['relation']}), flush=True)
    observer, observer_pin = read_json(root/'review/execution-observer-v1.json')
    need(observer['status'] == 'TERMINAL' and observer['native_exit'] == 1, 'ORIGINAL_NATIVE_EXIT_NOT_RETAINED')
    stderr_path = Path(observer['logs']['stderr']).resolve()
    need(stderr_path.is_relative_to(root), 'STDERR_OUTSIDE_RUN')
    stderr = stderr_path.read_bytes()
    need(b'JSON_RESOURCE_BOUND' in stderr and b'UNKNOWN' in stderr, 'ORIGINAL_RESOURCE_FAILURE_LOG')
    unavailable = root/'data/evaluation/eval-040.json.gz'
    need(not unavailable.exists(), 'RECORD40_POLICY_AVAILABILITY_CHANGED_REVIEW_REQUIRED')
    raw40_path = root/'data/raw/eval-040-search.json.gz'
    raw40_pin = pin(raw40_path)
    for name, expected in guards.items():
        need(pin(root/name) == expected, 'ORIGINAL_SOURCE_CHANGED_DURING_REGRESSION:'+name)
    need(pin(projection_path)['sha256'] == PROJECTION_SHA256, 'PROJECTION_SOURCE_CHANGED')
    for actual in readbacks:
        need(pin(Path(actual['path'])) == {k: actual[k] for k in ('bytes', 'sha256')},
             'ORIGINAL_RECORD_CHANGED_DURING_ASSURANCE')
    source = pin(Path(__file__))
    result = {'schema': VERSION, 'status': 'PASS_RETAINED_PREFIX_PROJECTION_REGRESSION',
              'source': source, 'projection_source': pin(projection_path),
              'checker_sources': {'N_sha256': N_SHA256, 'V_sha256': V_SHA256},
              'protocol': protocol_pin, 'marked_model': model_pin,
              'frozen_source_pins_before_after_equal': guards,
              'training_records': 24, 'evaluation_records': 40, 'relations': relations,
              'records': records, 'seconds': time.perf_counter()-started,
              'original_operator_failure': {'native_exit': 1, 'observer': observer_pin,
                  'stderr': {'path': str(stderr_path), 'bytes': len(stderr),
                             'sha256': hashlib.sha256(stderr).hexdigest()},
                  'reported_checker_status': 'UNKNOWN', 'reported_checker_reason': 'JSON_RESOURCE_BOUND',
                  'failed_evaluation_index': 40, 'full_policy_record_available': False,
                  'raw_search': {'path': str(raw40_path), **raw40_pin},
                  'raw40_policy_projection_replayed': False,
                  'scope': 'Original failure remains recorded. Missing policy/setup telemetry is not fabricated. Raw40 outcome requires its separate independent proof assurance.'},
              'scope': 'Postrun independent checker replay of the fixed 24+40 saved records. No engine, policy, training or native search rerun; no original Source/record modification. Exact verified receipts must match. Original JSON resource refusals remain explicit; removing unused envelope data does not change required proof or learner values. Full original interface samples remain separately checked.'}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as output:
        output.write(json.dumps(result, sort_keys=True, indent=2, allow_nan=False)+'\n')
    print(wire({'status': result['status'], 'relations': relations, 'output': str(args.output),
                'output_pin': pin(args.output)}), flush=True)


if __name__ == '__main__':
    main()
