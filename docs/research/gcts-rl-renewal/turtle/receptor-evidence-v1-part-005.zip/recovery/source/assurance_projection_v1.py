"""Read-set projections for the immutable df5778 continuation checker.

Pure native-JSON data transformation. No engine, policy, checker, search or
scientific module import. No field is recomputed, normalized or synthesized.
Every retained value is detached and type-preserved. Original full samples
remain the inputs to the separate check_interface API.

policy_view(policy): exact fields read by N.check_policy and its policy helpers.
learning_view(policy): exact fields read by N.check_learning, retaining complete
update records, action tables, weights, probabilities, features and contexts.
Both return None for the no-controller baseline. Missing required fields raise
ProjectionError; callers must not replace that refusal with invented values.
"""
import math

VERSION = 'Turtle-assurance-readset-projection-v1'
CHECKER_SHA256 = 'df5778636606806717f4675358fd93b818d02c16f8572d1986580fb2174462cb'

POLICY_TOP = ('schema', 'lane', 'decisions', 'events', 'telemetry',
              'interface_records', 'interface_samples', 'checkpoint')
POLICY_DECISION = ('parent_context', 'state_sha256', 'branch_point',
                   'action_feature_table', 'chosen_action', 'checkpoint_after')
LEARNING_TOP = ('schema', 'training', 'feature_names', 'learning_rate', 'lane',
                'updates', 'episodes', 'episode_finished', 'weights', 'baseline',
                'decisions', 'telemetry', 'weights_sha256')
LEARNING_DECISION = ('weights', 'parent_context', 'state_sha256',
                     'action_feature_table', 'action_count', 'base_action_count',
                     'chosen_index', 'chosen_action', 'model_softmax_probabilities',
                     'model_softmax_probability', 'behavior_probability',
                     'behavior_log_probability')
INTERFACE_UNUSED = frozenset(('domains', 'edge_units', 'parent_context'))


class ProjectionError(ValueError):
    pass


def _need(condition, reason):
    if not condition:
        raise ProjectionError(reason)


def _clone(value, active=None):
    """Copy exact built-in JSON values without a numeric conversion/round trip."""
    if active is None:
        active = set()
    kind = type(value)
    if value is None or kind in (str, int, bool):
        return value
    if kind is float:
        _need(math.isfinite(value), 'NONFINITE_JSON_FLOAT')
        return value
    _need(kind in (list, dict) and id(value) not in active, 'NON_NATIVE_JSON_OR_CYCLE')
    active.add(id(value))
    try:
        if kind is list:
            return [_clone(item, active) for item in value]
        _need(all(type(key) is str for key in value), 'NON_STRING_JSON_KEY')
        return {key: _clone(item, active) for key, item in value.items()}
    finally:
        active.remove(id(value))


def _pick(value, keys):
    _need(type(value) is dict, 'EXPECTED_JSON_OBJECT')
    _need(all(key in value for key in keys), 'MISSING_REQUIRED_ASSURANCE_FIELD')
    return {key: _clone(value[key]) for key in keys}


def _interface_sample(sample):
    # N.check_policy removes these same three keys before comparing against its
    # compact interface record. Full graph checking uses the original sample.
    result = _pick(sample, ('expansion', 'family_id'))
    receipt = sample['receipt']
    _need(type(receipt) is dict, 'INTERFACE_RECEIPT_OBJECT')
    result['receipt'] = {key: _clone(value) for key, value in receipt.items()
                         if key not in INTERFACE_UNUSED}
    return result


def _interface_samples(groups):
    _need(type(groups) is dict, 'INTERFACE_SAMPLE_GROUPS')
    result = {}
    for key, group in groups.items():
        _need(type(key) is str, 'INTERFACE_GROUP_KEY')
        result[key] = {'seen': _clone(group['seen']),
                       'first': _interface_sample(group['first']),
                       'last': _interface_sample(group['last'])}
    return result


def _plan_sample(sample):
    # N links exact events and chronological membership, not the copied full
    # point graphs in these display/example snapshots. The native tree and
    # direct full interface assurances retain their independent original inputs.
    result = _pick(sample, ('event',))
    result['parent_snapshot'] = _pick(sample['parent_snapshot'], ('placements',))
    result['after_snapshot'] = _pick(sample['after_snapshot'], ('placements',))
    return result


def _plan_examples(groups):
    _need(type(groups) is dict, 'PLAN_EXAMPLE_GROUPS')
    result = {}
    for key, group in groups.items():
        _need(type(key) is str, 'PLAN_EXAMPLE_KEY')
        result[key] = {'seen': _clone(group['seen']),
                       'first': _plan_sample(group['first']),
                       'last': _plan_sample(group['last'])}
    return result


def policy_view(policy):
    """Detached exact N.check_policy read set; preserves every event/order."""
    if policy is None:
        return None
    _need(type(policy) is dict, 'POLICY_OBJECT')
    # Select before cloning: never traverse unused full graph/family payloads.
    ordinary = [key for key in POLICY_TOP if key not in ('decisions', 'interface_samples')]
    result = _pick(policy, ordinary)
    _need(type(policy['decisions']) is list, 'DECISION_ARRAY')
    result['decisions'] = [_pick(row, POLICY_DECISION) for row in policy['decisions']]
    result['interface_samples'] = _interface_samples(policy['interface_samples'])
    if 'plan_examples' in policy:
        result['plan_examples'] = _plan_examples(policy['plan_examples'])
    return result


def learning_view(policy):
    """Detached N.check_learning read set; all actual learning numbers unchanged.

    Full chosen_action and update records are retained, including their unused
    scalar metadata. Every decision and update remains in original order.
    Full parent_context must stay intact because its complete content is hashed.
    """
    if policy is None:
        return None
    _need(type(policy) is dict, 'POLICY_OBJECT')
    result = _pick(policy, [key for key in LEARNING_TOP if key != 'decisions'])
    _need(type(policy['decisions']) is list, 'DECISION_ARRAY')
    result['decisions'] = []
    for row in policy['decisions']:
        selected = _pick(row, LEARNING_DECISION)
        if 'logits' in row:
            selected['logits'] = _clone(row['logits'])
        result['decisions'].append(selected)
    return result
