"""Resume only unsearched prescheduled jobs after an assurance-size refusal.

The original frozen experiment, engine, controller, checker, cohort, bank,
weights, per-job limits and seeds remain byte-exact. No prior search is rerun.
One native search has only its raw result; missing policy/setup stays missing.
"""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):
    b=p.read_bytes();return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wire(v))
def bind_search(result,case,limits):
    assert result['core']==case['core'] and result['seeds']==case['seeds']
    assert result['limits']==limits and result['grow'] is True
    assert result['criterion']=='CORE_COMPLETE_WITH_VIABLE_FRONTIER'
def freeze():
    assert not (ROOT/'recovery/protocol-frozen-v1.json').exists()
    original=load(ROOT/'data/protocol-frozen-v1.json')
    for name,expected in original['pins'].items():assert pin(ROOT/name)==expected,name
    observer=load(ROOT/'review/execution-observer-v1.json');assert observer['native_exit']==1 and observer['external_stop_reason'] is None
    assert len(list((ROOT/'data/training').glob('*.json.gz')))==24
    assert len(list((ROOT/'data/evaluation').glob('*.json.gz')))==40
    assert (ROOT/'data/raw/eval-040-search.json.gz').is_file() and not (ROOT/'data/evaluation/eval-040.json.gz').exists()
    assert load(ROOT/'data/frozen-bank-v1.json')==load(ROOT/'data/reused-bank-v1.json')
    assert load(ROOT/'data/frozen-policy-v1.json')['weights']==load(ROOT/'data/training/train-023.json.gz')['policy']['weights']
    regression=load(ROOT/'review/assurance-projection-regression-v1.json')
    assert regression['status']=='PASS_RETAINED_PREFIX_PROJECTION_REGRESSION'
    assert regression['training_records']==24 and regression['evaluation_records']==40
    assert regression['relations']=={'IDENTICAL_VERIFIED_RECEIPT':123}
    paths=sorted((ROOT/'recovery/source').glob('*.py'))+[ROOT/'review/supervise_resume_v1.py',ROOT/'data/frozen-policy-v1.json',ROOT/'data/frozen-bank-v1.json',ROOT/'review/assurance-projection-regression-v1.json',ROOT/'review/execution-observer-v1.json']
    protocol=dict(schema='Turtle-assurance-recovery-protocol-v1',original_protocol=pin(ROOT/'data/protocol-frozen-v1.json'),pins={str(p.relative_to(ROOT)):pin(p) for p in paths},original_native_exit=1,original_attempt_seconds=observer['elapsed_seconds'],completed_training=24,completed_evaluation_indices=list(range(40)),raw_only_evaluation_index=40,resume_job_indices=list(range(41,144)),remaining_evaluation_wall=max(0,original['evaluation_wall_limit']-observer['elapsed_seconds']),resume_process_wall_limit=max(1,original['process_wall_limit']-observer['elapsed_seconds']),change='Only assurance input projection and persistence/admission pipeline. All frozen search/learning Sources, inputs, policy weights and prescheduled jobs unchanged.',raw_only='Recover exact search/tree/patch/progress. Policy, actual event counts and constructor/setup cost were not persisted and must remain unavailable. No target or search is repeated.',costs='Charge original attempted-process elapsed time, resume elapsed time and separate projection-regression assurance. Conservatively charge the entire prior process against the remaining evaluation wall budget. Original phase timers are unavailable; known component subtotals do not replace them.')
    save(ROOT/'recovery/protocol-frozen-v1.json',protocol);print(json.dumps(dict(status='RECOVERY_FROZEN',resume_jobs=103,raw_only=40,pins=len(paths))),flush=True)
def verify(protocol,original):
    assert pin(ROOT/'data/protocol-frozen-v1.json')==protocol['original_protocol']
    for name,expected in original['pins'].items():assert pin(ROOT/name)==expected,name
    for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name
def assure(V,N,A,model,result,policy):
    started=time.perf_counter();pa=N.check_policy(model,result,A.policy_view(policy))
    assert pa['status']!='REJECTED',pa
    tree=pa['tree'] if 'tree' in pa else V.check_tree(model,result);assert tree['status']!='REJECTED',tree
    patch=V.check_patch(model,result['placements'],result['core']) if result['status']=='POSITIVE' else None
    best=V.check_snapshot(model,result['final_snapshot']) if result.get('best_prefix_viable') else None
    if best is not None:assert best['status']=='VERIFIED' and not best['dead_points'],best
    interfaces=[]
    for key,pair in policy['interface_samples'].items():
        samples=[pair['first']]
        if wire(pair['first'])!=wire(pair['last']):samples.append(pair['last'])
        for sample in samples:
            receipt=N.check_interface(model,sample['parent_snapshot'],sample['expansion'],sample['receipt']);assert receipt['status']!='REJECTED',receipt
            interfaces.append(dict(sample_key=key,assurance=receipt))
    status=result['status']
    if status=='POSITIVE' and (patch is None or patch['status']!='VERIFIED'):status='UNKNOWN'
    if status=='NEGATIVE' and tree['status']!='VERIFIED':status='UNKNOWN'
    return dict(status=status,tree=tree,patch=patch,best=best,policy=pa,interfaces=interfaces,conformance=dict(tree_reconstructed=tree['status']=='VERIFIED',policy_events_verified=pa['status']=='VERIFIED',interface_sample_counts={s:sum(x['assurance']['status']==s for x in interfaces) for s in ('VERIFIED','UNKNOWN','REJECTED')}),seconds=time.perf_counter()-started,scope='Original independent kernels on their required semantic input fields. Full original policy and full interface samples are retained separately; checker resource refusals remain UNKNOWN.')
def reference(D,path,record):
    return dict(run_file=path,run_pin=D.pin(ROOT/path))
def run():
    started=time.perf_counter();original=load(ROOT/'data/protocol-frozen-v1.json');protocol=load(ROOT/'recovery/protocol-frozen-v1.json');verify(protocol,original)
    D=module('frozen_original_driver',ROOT/'source/experiment_v1.py');E,P,V,C,N=D.scientific_modules();A=module('assurance_projection',ROOT/'recovery/source/assurance_projection_v1.py')
    model=load(ROOT/'data/marked-model-v1.json');bank=load(ROOT/'data/frozen-bank-v1.json');frozen=load(ROOT/'data/frozen-policy-v1.json');cases=load(ROOT/'data/cases-v1.json');groups=load(ROOT/'reference/original-point-data-v1.json')['groups'];jobs=load(ROOT/'data/evaluation-jobs-v1.json');q=load(ROOT/'data/qualification-v1.json')
    by_id={c['id']:c for c in cases['heldout']};training=[]
    for episode in range(24):
        path='data/training/train-%03d.json.gz'%episode;record=load(ROOT/path)
        training.append(dict(episode=episode,case_id=record['case_id'],status=record['status'],search_seconds=record['search']['seconds'],reward=record['reward'],**reference(D,path,record)))
    evaluation=[]
    for index in range(40):
        path='data/evaluation/eval-%03d.json.gz'%index;record=load(ROOT/path);job=jobs[index]
        for key,value in job.items():assert record[key]==value
        bind_search(record['search'],by_id[job['case_id']],original['test_limit'])
        evaluation.append(dict(**job,status=record['status'],setup_seconds=record['setup_seconds'],search_seconds=record['search']['seconds'],**reference(D,path,record)))
    # Raw native output was written before the failed assurance operation.
    job=jobs[40];rawpath='data/raw/eval-040-search.json.gz';r=load(ROOT/rawpath);bind_search(r,by_id[job['case_id']],original['test_limit']);t=time.perf_counter();tree=V.check_tree(model,r);patch=V.check_patch(model,r['placements'],r['core']) if r['status']=='POSITIVE' else None;best=V.check_snapshot(model,r['final_snapshot']) if r.get('best_prefix_viable') else None
    assert tree['status']=='VERIFIED' and patch is not None and patch['status']=='VERIFIED' and best['status']=='VERIFIED'
    rollback=[N.check_controller_rollback(x) for x in r['control_rollback_checks']];assert all(x['status']=='VERIFIED' for x in rollback)
    unavailable=dict(status='UNKNOWN',reason='POLICY_METADATA_NOT_PERSISTED_BEFORE_ASSURANCE_ABORT')
    a=dict(status='POSITIVE',tree=tree,patch=patch,best=best,policy=unavailable,interfaces=[],controller_checkpoint_equality_only=rollback,conformance=dict(tree_reconstructed=True,policy_events_verified=False,interface_sample_counts=dict(VERIFIED=0,UNKNOWN=0,REJECTED=0)),seconds=time.perf_counter()-t,scope='Independent exact raw search/tree/patch recovery; policy transitions/learner behavior cannot be reconstructed from the missing record.')
    record=dict(**job,status='POSITIVE',reason='RECOVERED_RAW_ONLY_POLICY_METADATA_UNAVAILABLE',search=r,policy=None,policy_missing=True,assurance=a,learning_check=unavailable,raw=dict(run_file=rawpath,run_pin=pin(ROOT/rawpath)),setup_seconds=None,method_seconds=None,recovered_raw_only=True)
    ref=D.blob('data/evaluation/eval-040.json.gz',record);evaluation.append(dict(**job,status='POSITIVE',reason=record['reason'],setup_seconds=None,search_seconds=r['seconds'],policy_missing=True,**ref));print(json.dumps(dict(phase='RECOVERED_RAW',index=40,status='POSITIVE',policy='UNAVAILABLE',setup_seconds=None)),flush=True)
    resumed_at=time.perf_counter();by_id={c['id']:c for c in cases['heldout']}
    for job in jobs[41:]:
        if time.perf_counter()-resumed_at>=protocol['remaining_evaluation_wall']:
            evaluation.append(dict(**job,status='UNKNOWN',reason='NOT_RUN_REMAINING_EVALUATION_WALL_LIMIT',run_file=None));continue
        case=by_id[job['case_id']];lane=job['lane'];limits=original['test_limit'];setup=time.perf_counter();control=None
        if lane!='MARKED_LEX':control=P.Controller(model,groups,bank,lane,seed=job['seed'],weights=None if lane=='CONT_V_ZERO' else frozen['weights'])
        setup_seconds=time.perf_counter()-setup
        r=E.search(model,case['seeds'],case['core'],node_limit=limits['nodes'],seconds=limits['seconds'],depth_limit=limits['depth'],cache_limit=limits['cache'],order=control,control=control)
        raw=D.blob('data/raw/eval-%03d-search.json.gz'%job['index'],r);policy=control.snapshot() if control is not None else None
        bind_search(r,case,limits)
        # Persist the complete controller before any assurance call can refuse.
        context=D.blob('data/raw/eval-%03d-context.json.gz'%job['index'],dict(job=job,raw=raw,policy=policy,setup_seconds=setup_seconds))
        if policy is not None:
            assert not policy['training'] and not policy['updates'] and policy['family_sha256']==q['bank_checks']['family_sha256']
            assert policy['weights']==([0.0]*40 if lane=='CONT_V_ZERO' else frozen['weights'])
            a=assure(V,N,A,model,r,policy);learning=N.check_learning(A.learning_view(policy));assert learning['status']!='REJECTED',learning
        else:a=D.assure(V,N,model,r,None);learning=None
        record=dict(**job,status=a['status'],search=r,policy=policy,policy_missing=False,assurance=a,learning_check=learning,raw=raw,context_before_assurance=context,setup_seconds=setup_seconds,method_seconds=setup_seconds+r['seconds'])
        ref=D.blob('data/evaluation/eval-%03d.json.gz'%job['index'],record);evaluation.append(dict(**job,status=a['status'],setup_seconds=setup_seconds,search_seconds=r['seconds'],**ref))
        print(json.dumps(dict(phase='EVAL_RESUMED',**job,status=a['status'],nodes=r['stats']['visits'],seconds=r['seconds'],adoptions=policy['telemetry']['adoptions'] if policy else 0,successors=policy['telemetry']['successor_choices'] if policy else 0,policy_assurance=a['policy']['status'] if a['policy'] else None,learning_assurance=learning['status'] if learning else None)),flush=True)
    verify(protocol,original);counts={lane:{s:sum(row['lane']==lane and row['status']==s for row in evaluation) for s in ('POSITIVE','NEGATIVE','UNKNOWN')} for lane in D.LANES}
    parent=load(ROOT/'reference/parent-live-complete-v1.json');regression=load(ROOT/'review/assurance-projection-regression-v1.json')
    train_components=sum(load(ROOT/row['run_file'])['search']['seconds']+load(ROOT/row['run_file'])['assurance']['seconds']+load(ROOT/row['run_file'])['setup_seconds'] for row in training)
    eval_components=0.0
    for row in evaluation:
        if row.get('run_file'):
            data=load(ROOT/row['run_file']);eval_components+=data['search']['seconds']+data['assurance']['seconds']+(data['setup_seconds'] or 0.0)
    resume_seconds=time.perf_counter()-started
    costs=dict(total_seconds=protocol['original_attempt_seconds']+resume_seconds,original_attempt_seconds=protocol['original_attempt_seconds'],resume_seconds=resume_seconds,qualification_execution_seconds=q['qualification_execution_seconds'],assurance_projection_regression_seconds=regression['seconds'],training_setup_seconds=load(ROOT/training[0]['run_file'])['setup_seconds'],training_seconds=None,evaluation_seconds=None,training_component_seconds=train_components,evaluation_component_seconds=eval_components,reused_prior_study_seconds=parent['costs']['total_seconds'],reused_corona_acquisition_seconds=parent['costs']['parent_acquisition_seconds'],input_preparation_seconds=None,reuse_scope='Observed original failed-attempt and resume durations are both charged. Missing original phase timers/setup40 are unavailable; component subtotals are incomplete nested observations, not phase totals or a cold cost.')
    costs['resume_timer_scope']='Through component aggregation, before final serialization. Final subprocess observer duration is authoritative for the complete resumed process and will be reported separately.'
    recovery=dict(protocol=protocol,native_original_exit=1,original_abort='Independent learning checker JSON_RESOURCE_BOUND; driver asserted VERIFIED instead of preserving UNKNOWN.',raw_only_index=40,unavailable=['policy/actual transition metadata at index40','constructor/setup cost at index40','original full training/evaluation phase timers'],unchanged='Original frozen engine/controller/checker/model/cohort/bank/weights/seeds and per-job search limits.',completed_jobs_reexecuted=False,remaining_prescheduled_indices=list(range(41,144)))
    result=dict(schema='Turtle-receptor-continuation-study-v1',status='COMPLETE_SCHEDULE_WITH_RECOVERY',protocol=original,recovery=recovery,models=dict(marked=model),groups=groups,cases=cases,training=training,evaluation=evaluation,frozen_bank=bank,frozen_policy=frozen,qualification=q,counts=counts,costs=costs,peak_ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rss_units='bytes on macOS; resumed process only, original attempt observer peak retained separately',scope=original['scope'])
    D.blob('data/results-v1.json.gz',result);save(ROOT/'data/completion-v1.json',dict(status='COMPLETE_WITH_RECOVERY',counts=counts,training_completed=24,evaluation_completed=sum(bool(x.get('run_file')) for x in evaluation),raw_only_index=40,total_seconds=costs['total_seconds'],resumed_peak_ru_maxrss=result['peak_ru_maxrss']));print(json.dumps(load(ROOT/'data/completion-v1.json')),flush=True)
if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='run':run()
    else:raise SystemExit('freeze | run')
