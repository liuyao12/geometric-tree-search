# Turtle receptor continuations: prospective first-stage design

Status: design only. No model execution, implementation, new cohort, validation result or performance gain is asserted here. The preceding cluster study remains unchanged. The governing contract is [the GCTS master reference](/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md), read before this design.

The examined cohort is development evidence: every method solved all twelve old targets, so it establishes no solve-rate advantage. Its anchor-only RL policy was slower than marked lexical search. The later whole-cluster frontier audit motivates testing continuation and interface checks; it does not establish that either will improve search. Do not reuse those targets as untouched evaluation.

## 1. Fixed problem and bounded scope

Reuse the exact marked Turtle point model and the final frozen, checked cluster bank from `gcts-turtle-cluster-rl-20261103-v1`, pinned by byte/hash before implementation qualification. Keep that bank fixed throughout this first stage; do not acquire new templates from the new training or evaluation runs. Record the original corona/mark acquisition and bank-training costs as reused observations, separately from newly measured preparation, training, search, interface validation and assurance. Do not describe the sum of reused observations as a measured cold run.

All primary lanes solve the same learned restricted marked problem. Markings are hypotheses, not proved redundant constraints on the unmarked Turtle. An unmarked run may be retained as a separate descriptive control, outside the primary causal comparison.

Use integer point capacity \(12\), exact assigned markings and the already verified decorated twelve-element action. A target is a finite set of required lattice points \(R\), with root tile fixed at the identity and all root support included. Activate every point of \(R\) at generation zero and every subsequently exposed positive-support point. Success means all core obligations are full and the entire exposed frontier is viable. The exterior is free. A hole in \(R\) is an unconstrained obligation hole; it is not forbidden tile area. This is not exact fixed-boundary polygon-region packing or whole-plane coverage.

First-stage bounds: six new training masks, twenty-four episodes, one prospectively fixed RL seed; nine new held-out masks, eight lanes, two blocked repetitions, hence at most 144 evaluation jobs. Training caps: two seconds, 200 visited states, depth 64 per episode. Evaluation caps: four seconds, 400 visited states, depth 96 per job. Use the same 64,000 immutable-materialization cap and identical explicit core/frontier semantics in every lane. Search time includes proposal, recording and validation work performed during that search. Fix schedule and aggregate stop limits before execution; unrun or cutoff jobs are unknown. One training seed gives only exploratory learning evidence, not a variance estimate.

## 2. Receptor families and a retained plan

A bank template remains a finite set of distinct primitive placements with an inspectable expansion. Treat each constituent as a possible port. Normalize that port to identity using its exact inverse group action; anchor it to a candidate in the current selected branch domain. These are transformed instances of existing clusters, not new strategy input. All cluster lanes share this same multiport family pool, exact identities and deterministic enumeration. Declare a connected positive-support graph and the full typed marking action for every instance.

A live instance stores its family/port, world transform, exact constituent set \(C\), and current state intersection. Its fulfilled members are \(C\cap S\); pending members are \(C\setminus S\). Its receptor includes exact point deficits, assigned typed mark values and the complete current frontier incidence relevant to its tentative union. Mark-only dependencies may lie outside both the frontier and the tile's positive support. The prior bank's sorted expansions are not historical execution sequences: derive the next eligible member from the live scheduler rather than inventing a witness order.

At most one retained instance is active. Once its anchor is actually placed, retain its pending members as preferences. On a later branch, prefer a pending member only if it is a legal incident candidate at the point selected by the reference scheduler. Choose deterministically among eligible pending members, or let the declared policy choose within that eligible set. If none is eligible, take the ordinary complete base fallback and suspend the instance. Do not move to another point or generation to advance it. Forced moves may fulfill a member without a policy decision. A newly incompatible instance is abandoned, without excluding any base candidate. Complete or abandon the instance before proposing a replacement; no nested plans in this stage.

Actual successive constituent placements must be recorded. Choosing an anchor or retaining a plan is not executing its expansion. A plan never commits search to eventually placing every constituent.

## 3. Exact whole-frontier interface test

First perform the existing cheap aggregate inventory, capacity and mark agreement check against the current state, counting shared selected placements once. For a tentative union \(U=S\cup C\), form its exact totals and compatible marks and activate the required set

\[
Q_U=Q_S\cup\bigcup_{c\in C\setminus S}\operatorname{supp}(t_c).
\]

For every \(p\in Q_U\) whose total is below capacity, enumerate **all** allowed positive-support alignments and test their legality against the entire tentative union, including distant mark-only conflicts. The full candidate/frontier graph must have no degree-zero point. Use complete base candidates, never the cluster pool, to establish viability. New support pockets and distant old frontier points are included. The tentative union's generations need not be invented: this test establishes only absence of a current dead frontier, not scheduler-realizability or infinite extendibility. Do not recursively propagate hypothetical forced moves in this first stage.

Keep the proposal budget small: at most 48 deterministic cheap family/anchor trials and at most two distinct cheap-valid cluster instances offered at a branch, selected before any expensive interface outcome. Filtered lanes check those same instances without replacement. Each full test has a prospectively fixed 50,000 distinct candidate-materialization budget. A test cutoff is `INTERFACE_UNKNOWN`, so the proposal is unavailable as a cluster preference; no base candidate is removed. Log complete/failed/unknown separately. Filter-off lanes retain exactly the same pre-filter instances and cheap checks.

Revalidate an active plan before using a successor preference after any intervening actual changes. Cheap conflicts may abandon it immediately; filtered lanes additionally require a current complete frontier check. This can be expensive and its full cost is charged. A viable aggregate can still be unhelpful or unrealizable through the scheduler; measure both rather than treating viability as a completion certificate.

## 4. Scheduling, preemption and rollback

Every actual primitive placement returns to: global degree-zero test; the declared finite core-full/viable-frontier checkpoint; global forced propagation; then earliest-generation branch-point selection, with degree used only within a generation. These decisions preempt all retained preferences. In particular, a forced move elsewhere cannot wait for the planned cluster, and a newly dead actual frontier kills the branch immediately. The finite checkpoint does not certify infinite extension.

Trail the active-instance identity, adopted/pending membership and any suspension/abandonment along with the engine's complete ordinary trail. Restore them exactly when trying a sibling branch. Candidate failure exclusions remain parent-context scoped. Snapshot the plan at each choice point; an engine rollback must restore the corresponding plan fingerprint. Immutable interface caches, if introduced at all, require keys binding the complete logical state, required-point set, inventory and model/mark versions; do not reuse a verdict merely by template ID. No model or bank updates occur during evaluation. Optimizer/RNG histories are not validity state, but all actual policy choices remain auditable.

All base candidates remain lexical fallback alternatives at every selected branch point. Refusing, abandoning or exhausting a cluster never proves a base move impossible. A retained preference is not an atomic macro transaction.

## 5. Matched lanes and learning

| Lane | Retained successors | Complete union interface filter | Choice rule |
| --- | --- | --- | --- |
| `MARKED_LEX` | No | No | Base lexical |
| `HEAD_H` | No | No | Cluster aggregate heuristic, anchor only |
| `CONT_H` | Yes | No | Same heuristic |
| `HEAD_V_H` | No | Yes | Same heuristic, anchor only |
| `CONT_V_H` | Yes | Yes | Same heuristic |
| `CONT_V_RANDOM` | Yes | Yes | Uniform valid action pool |
| `CONT_V_ZERO` | Yes | Yes | Frozen zero-weight architecture, declared lexical ties |
| `CONT_V_RL` | Yes | Yes | Trained linear softmax; frozen deterministic evaluation |

The four heuristic lanes form the continuation/interface factorial comparison. The last three controls separate the trained policy from random choice, initialization/ties and the hand-designed heuristic on the same continuation/filter machinery. Every cluster pool also includes every base candidate as an exploration/fallback action. Common generation scheduling, model, bank, target, caps, proposal cycle and feature version are fixed across matched lanes.

Start RL weights from zero, not the examined policy. Use stochastic episodic REINFORCE with recorded action features/probabilities and a pre-episode baseline. Credit only independently checked core progress or completion; charge measured search/interface cost. Freeze the reward formula and feature normalization before training. A possible reward is \(2I_{\mathrm{verified\ success}}+u/u_{\mathrm{core}}-0.1\min(\tau/\tau_{\max},1)-0.02n/n_{\max}\), with progress \(u\) admitted only from an independently checked viable snapshot. Preserve gradients from choices on failed subtrees. Freeze weights before inspecting any new held-out outcome.

For validation-cost diagnosis, time the full interface routine separately on saved identical contexts, outside scientific search totals and labeled as passive assurance. Do not subtract this diagnostic time from measured filtered search or infer an executable speedup from a hypothetical free filter. A later shadow-filter lane may be justified, but is not required to expand this bounded first stage.

## 6. Fresh masks and pre-search freeze

Create new masks from a deterministic hash-counter stream under the namespace `gcts-turtle-receptors-v1`, using split and case ID in every draw. Freeze literal arrays and hashes before any search, classification, template tuning or reward inspection. Use three point-mask families: variable-width axial walks with asymmetric bends; annular masks with deterministic asymmetric obligation cuts; unequal two-lobe masks joined by narrow obligation bridges. Their construction uses lattice points only and no solved tiling or target proof.

For training, use two masks per family at declared scales four and five. For held-out evaluation, use three per family at scales six, eight and ten. Freeze the exact family generators, sizes/widths, seeds, origin convention and maximum point count before generation; do not label a larger mask “hard” in advance. A generator resource failure is explicit, not replaced after inspecting solver performance. The wider scales may expose limitations; they may also remain easy or become unknown under the prescribed caps.

Before labels exist, reject exact mask or core duplicates under translation and all twelve point actions against both splits of the examined cohort, the new training split, and other new held-out cases. This conservative combinatorial check is not a claim of disjoint proof cores or statistical independence. Reserve the old cohort for regression/qualification only. Do not select held-out cases using runtime, success or failure. If feasibility qualification requires changing generators, features or caps, issue a new prospective version and freeze a different untouched held-out set before running it.

## 7. Qualification and decision gate

Before the main schedule, independently qualify small fixtures for: a distant mark-only disagreement; a new pocket with no candidate; whole-union deadness outside the apparent attachment; forced-move preemption; an earlier-generation point with no pending member; shared selected placements counted once; full reflection/channel actions; abandoned plans leaving all base fallbacks; and exact engine-plus-plan rollback. Compare every tentative-union frontier domain with independent exhaustive point re-enumeration. Tiny restricted placement universes should agree with exhaustive solution enumeration. A qualification failure blocks the experiment rather than becoming a negative target result.

Record per job: checked status, core units, primitive placements, visits, branches, forced moves, backtracks, candidate eliminations, graph peaks, total search time, proposal/interface calls and cost, refused/unknown interfaces, plan suspensions/abandonments and actual successor choices. Distinguish requested constituents, observed placements and members in the final checked certificate. Save first/last retained-plan contexts plus all compact choice traces and exact raw certificates; independently audit complete frontier interfaces on these saved contexts. Record preparation, reused acquisition, RL training and assurance separately.

Primary assessment is paired verified outcomes and directly measured end-to-end search cost on the same marked tasks. If every lane again solves every target, report no solve-rate advantage and compare paired cost without claiming increased reach. Fewer states with greater validation time is not a speedup. Unknowns remain unknown; exhausted failure concerns only this marked finite-obligation problem. Continue beyond this bounded stage only after the conformance checks and costed results justify it. No substitution, plane-tiling, proof-universality or new empirical gain follows from this design.
