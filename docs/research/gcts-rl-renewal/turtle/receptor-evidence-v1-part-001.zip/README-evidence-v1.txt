Turtle receptor/continuation evidence, 2026-11-03.

This is a recovered schedule, not a clean uninterrupted run. Original execution
exited at a policy-assurance JSON resource bound. Earlier searches were retained;
the remaining schedule resumed with the same scientific algorithms, frozen
weights, seeds and resource caps. One raw-only evaluation has no persisted policy
trace or setup/method timer. Those fields remain unavailable, never zero-filled.
The readable report and exact result index explain outcomes, costs and recovery.

All scientific Sources, inputs, native records, proof certificates, controller
events, qualification details, family images, recovery code/logs and review files
at the archive cut are physically retained. package/ and publication/ are omitted
to avoid recursion; later deployment receipts are not part of this archive cut.
The full task-owned evidence, including local paths, is approved for publication
at the existing GitHub Pages destination. No retired materials lane is included.

Download EVERY receptor-evidence-v1-part-NNN.zip and the external evidence
manifest. Each ZIP is independently valid and at most forty-four MiB. Extract all
volumes into ONE empty directory. Their identical ARCHIVE-file-manifest-v1.json
can be overwritten by the identical copy from the next volume. The external
manifest supplies every volume byte count and SHA256 and the internal inventory
identity. It lists every original relative path, exact byte count and SHA256.

Only byte-identical public report copies explicitly listed by
report/receptor-public-manifest-v1.json are stored as aliases. Canonical science
data/Sources are already physical files. Run:

    python3 restore-public-copies-v1.py

The helper verifies canonical bytes, refuses to overwrite different files,
restores the omitted public copies by copying their canonical files, and verifies
EVERY original path. It does no scientific computation. Once restored, serve the
directory with python3 -m http.server and open report/receptor-continuation-v1.html
to use its local record/download links. Browser floats are illustrations only.

These are finite marked point-core checkpoints with free exterior and viable
frontier. Continuations are scheduler-respecting primitive preferences, not an
atomic macro. The marking remains a learned restriction. No whole-plane tiling,
substitution rule, arbitrary-region practicality or cold speedup is established.
