const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");
const {pathToFileURL}=require("node:url");
const {chromium}=require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main(){
  const browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless:true,args:["--disable-breakpad","--disable-background-networking"]});
  try{
    const page=await browser.newPage({viewport:{width:1240,height:900}});
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const live=Boolean(process.argv[2]);
    const local=pathToFileURL(path.join(__dirname,"..","report","turtle-plane-renormalization-20261105-v1.html"));
    const response=await page.goto(process.argv[2]||local.href,{waitUntil:"load"});
    if(live) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===58);
    const stats=await page.evaluate(()=>{
      const sections=[...document.querySelectorAll("#substitution details")];
      sections.forEach(el=>el.querySelector("summary").click());
      if(!sections.every(el=>el.open)) throw Error("Certificate disclosures failed");
      return {disclosures:sections.length, math:document.querySelectorAll("mjx-container").length,
        math_errors:document.querySelectorAll("mjx-merror").length};
    });
    assert.deepEqual(errors,[]);
    assert.deepEqual(stats,{disclosures:2,math:58,math_errors:0});
    if(!live) await page.locator("#substitution figure").screenshot({path:path.join(__dirname,"browser-v1.png")});
    await page.setViewportSize({width:390,height:844});
    const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert(fits);
    const result={status:"CHECKED_TURTLE_PLANE_READER",...stats,mobile_no_overflow:fits};
    fs.writeFileSync(path.join(__dirname,live?"live-browser-v1.json":"browser-v1.json"),
      JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  }finally{
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
