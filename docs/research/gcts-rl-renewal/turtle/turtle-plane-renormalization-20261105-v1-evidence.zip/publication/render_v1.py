"""Render the proof and its finite certificates."""

import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from rhombille_v1 import load, pin

STEM="turtle-plane-renormalization-20261105-v1"
OLD="turtle-rhombille-matching-20261105-v1.html"


def diagram():
    def segment(a,b,color="#54786b"):
        return f'<line x1="{a[0]}" y1="{a[1]}" x2="{b[0]}" y2="{b[1]}" stroke="{color}" stroke-width="2.3"></line>'
    def node(p,color,r=5):
        return f'<circle cx="{p[0]}" cy="{p[1]}" r="{r}" fill="{color}"></circle>'
    light="#86a99b"
    dark="#2b6c5a"
    orange="#bc744e"
    old1=[(32,53),(71,53),(110,53),(149,53)]
    old2=[(40,150),(117,120),(117,179)]
    star=(86,150)
    old3=[(32,242),(71,242),(110,242)]
    new1=[(273,53),(365,53)]
    new2=[(268,150),(374,120),(374,179)]
    star2=(331,150)
    def path(points):
        return "".join(segment(a,b) for a,b in zip(points,points[1:]))
    raw=path(old1)+path(old3)+path(new1)
    raw+="".join(segment(p,star) for p in old2)+"".join(segment(p,star2) for p in new2)
    raw+="".join(node(p,dark if i in (0,3) else light) for i,p in enumerate(old1))
    raw+="".join(node(p,dark) for p in old2+new1+new2)
    raw+="".join(node(p,dark if i==0 else light) for i,p in enumerate(old3))
    raw+=node(star,orange,5.8)+node(star2,orange,5.8)+node((273,242),dark)
    for y in (53,150,242):
        raw+=f'<path d="M 188 {y} h 39 m -8 -6 l 8 6 -8 6" fill="none" stroke="#685e57" stroke-width="1.9"></path>'
    return f'<svg viewBox="0 0 410 268" role="img" aria-label="Graph contraction keeps opposite paths and three-arm junctions and removes dangling leaves">{raw}</svg>'


STYLE="""
*{box-sizing:border-box}body{margin:0;background:#f6f6ef;color:#233831;line-height:1.58;font-family:system-ui,-apple-system,sans-serif}
main{max-width:960px;margin:auto;padding:2rem clamp(1rem,5vw,3.5rem) 4rem}header{padding:1.4rem 0 1rem;border-bottom:1px solid #bdd0c3}
h1,h2,h3{font-family:Georgia,serif;line-height:1.1}h1{font-size:clamp(2.45rem,7vw,4.45rem);max-width:16ch;margin:.25em 0}
h2{font-size:clamp(1.65rem,4vw,2.55rem)}p{max-width:78ch}section{margin-top:2.45rem}a{color:#195c4c}
.eyebrow{font-size:.78rem;font-weight:750;letter-spacing:.09em;text-transform:uppercase}
nav ul{display:flex;flex-wrap:wrap;gap:.55rem 1.3rem;list-style:none;padding:0}
.callout{border-left:4px solid #377e69;padding:.3rem 1rem;background:#e2eee5}
.frame{border:1px solid #c4d3c8;border-radius:.8rem;padding:1rem;background:#fffefa;margin:0}
svg{display:block;width:100%;max-height:330px;background:#f8faf4;border-radius:.45rem}
figcaption{margin-top:.55rem;font-size:.91rem}.mathbox{overflow:auto}table{border-collapse:collapse;width:100%}
th,td{padding:.55rem .7rem;text-align:left;border-bottom:1px solid #c4d3c8}thead th{background:#e4eee6}
pre{overflow:auto;background:#e9f0e8;padding:.8rem;border-radius:.35rem}details{border:1px solid #c4d3c8;border-radius:.45rem;padding:.55rem .8rem;margin:.55rem 0}
summary{cursor:pointer;font-weight:700} .scroll{overflow:auto} code{font-size:.87em}
@media(max-width:520px){main{padding-top:.7rem}th,td{padding:.42rem;font-size:.87rem}}
"""


def render(summary):
    renorm=summary["renormalization"]
    audit=summary["audit"]
    details=""
    for row in renorm:
        totals={}
        for c in row["certificates"]:
            k=(len(c["links"]),len(c["stars"]),c["dangling"])
            totals[k]=totals.get(k,0)+1
        body="".join("<tr>"+"".join(f"<td>{n}</td>" for n in (*k,v))+"</tr>" for k,v in sorted(totals.items()))
        details+=rf'<details><summary>Layer \({row["layer"]}\)</summary><div class="scroll"><table><thead><tr><th>Opposite links</th><th>Three-arm junctions</th><th>Dangling branches</th><th>Exact phase regions</th></tr></thead><tbody>{body}</tbody></table></div></details>'
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>A plane Turtle tiling from a self-similar matching graph</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · Turtle · November 2026</p>
<h1>A plane Turtle tiling from a self-similar matching graph</h1>
<p>Exact Rhombille colors reduce Turtle placement to matching red rhombs with hexagons. A checked graph contraction reproduces the matching graph at a coarser scale. This gives a computer-assisted proof that the generated coloring lifts to a tiling of the entire plane by Turtle polygons on \(A_2\).</p>
<nav aria-label="On this page"><ul><li><a href="#coloring">Coloring</a></li><li><a href="#coarse">Coarse graph</a></li><li><a href="#substitution">Graph substitution</a></li><li><a href="#plane">Plane proof</a></li><li><a href="#evidence">Evidence</a></li></ul></nav></header>
<section id="coloring"><h2>Color the grid and expose the matching problem</h2>
<p>Work in the two cube layers with coordinate sums \(-2\) and \(-1\). Project \((n_0,n_1,n_2)\) onto \(2(n_0-n_1,n_1-n_2)\), up to the fixed grid translation. Adjacent cubes differ in one coordinate and determine one rhomb. Use \(\alpha=(5-\sqrt{{5}})/10\) and \((\beta_0,\beta_1,\beta_2)=(1/5,1/5,-2/5)\).</p>
<div class="mathbox">\[
b_i(n)=\lfloor (n+1)\alpha+\beta_i\rfloor-\lfloor n\alpha+\beta_i\rfloor,
\qquad k=-\sum_i\lfloor n_i\alpha+\beta_i\rfloor .
\]</div>
<p>A rhomb reads the two unchanged coordinates in cyclic order. Equal bits give a hexagon rhomb, while the two unequal orders give a red rhomb or a hole. Select every all-one center. An all-zero center is selected in the lower layer in band \(k=2\) or in the upper layer in band \(k=1\). Nonintegral rational intercepts avoid phase endpoints.</p>
<p>In 288 exact phase cases, every hexagon rhomb has one selected owner, edges have complementary colors across seams, and each red rhomb has two possible hexagon owners. Draw one edge for the red rhomb between those owners. The desired assignment orients every edge toward one endpoint and gives every vertex exactly one incoming edge. <a href="{OLD}#phase">See the finite construction and the phase checks</a>.</p></section>
<section id="coarse"><h2>Contract the majority hexagons</h2>
<p>The exact phase checker exhausts the connected groups of all-zero hexagons. Each group is a tree of three or four vertices and has one, two or three distinct all-one neighbors. Contract each group. Discard the one-arm subtrees and suppress the two-arm junctions. The resulting graph preserves cycles and finite components, since all removed parts are trees of bounded size attached to retained vertices.</p>
<p>Index each all-one center by its three crossing numbers \(q_i=\lfloor n_i\alpha+\beta_i\rfloor+1\). Their sum is zero. Conversely each integer triple \(q\) of sum zero gives one all-one center via \(n_i=\lfloor(q_i-\beta_i)/\alpha\rfloor\), in one of the two cube layers.</p>
<p>Set \(\lambda=(\sqrt{{5}}-1)/2\), \(\delta=1-\lambda=\lambda^2\), and \(\gamma_i=-\beta_i/\alpha\). The fractional parts \(f_i=\{{\lambda q_i+\gamma_i\}}\) sum to \(m\in\{{1,2\}}\). Use simplex coordinates \(u_i=f_i\) when \(m=1\) and \(u_i=1-f_i\) when \(m=2\). They are positive and sum to one.</p>
<ol><li><strong>Opposite-layer links.</strong> Use cyclic pairs \((i,j)\in\{{(0,2),(2,1),(1,0)\}}\). In the lower layer connect to \(q+e_i-e_j\) when \(u_i&lt;\lambda\) and \(u_j&lt;\delta\). In the upper layer the step is reversed, with the same inequalities. Across the edge subtract each old coordinate from its corresponding constant. The constants are \(\lambda,\delta,1\) for \(i,j\) and the remaining axis, respectively.</li>
<li><strong>Same-layer junctions.</strong> If \(u_i>\lambda\), the site is a corner of a three-arm junction. Its other two corners are obtained by transferring the large coordinate \(\lambda\) to either other axis. In index coordinates the steps are \(e_i-e_j\) in the lower layer and their negatives in the upper layer.</li></ol>
<p>The extracted coarse graph agrees with these formulas in all {summary["coarse"]["states"]} exact all-one phase cases. This defines the same graph for any intercept triple of sum zero with each entry outside \(\mathbb{{Z}}[\lambda]\).</p></section>
<section id="substitution"><h2>The graph reproduces itself</h2>
<figure class="frame">{diagram()}<figcaption>Read from top to bottom. A bounded path becomes an opposite-layer link, a three-arm junction keeps its three connections, and a dangling branch is removed. Green endpoints represent the retained junctions after contraction.</figcaption></figure>
<h3>Index the new vertices</h3>
<p>Contract the three corners of each same-layer junction to a vertex. Write its residual coordinates as \(z=u-\lambda e_i\) at corner \(i\). They are independent of the corner and sum to \(\delta\). All three corners also have the same integer vector \(r_i=\lfloor\lambda q_i+\gamma_i\rfloor\). The new index and intercept are</p>
<div class="mathbox">\[
q'_i=\left\lfloor\frac{{r_i-\gamma_i}}{{\lambda}}\right\rfloor-r_i+1,
\qquad \gamma'_i=\frac{{\gamma_i}}{{\delta}} .
\]</div>
<p>For the inverse, start with any \(q'\) of sum zero and set \(r_i=\lfloor(q'_i+\gamma_i/\lambda)/\lambda\rfloor\). Its three entries sum to \(-1\) or \(-2\). Let \(h_i=\{{(r_i-\gamma_i)/\lambda\}}\). Inverting the crossing number gives \(h_i=1-\lambda\{{\lambda q'_i+\gamma'_i\}}\), so \(h_i>\delta\). The preimage interval for each old coordinate has length \(1/\lambda=1+\lambda\) and starts at fractional part \(h_i\). Thus it contains two integers. The sum of their three minima is \(\sum_i r_i\), by the formula for \(q'_i\). Exactly three choices of a triple give sum zero, forming the three old corners.</p>
<p>At a lower junction \(h_i=\delta+z_i/\lambda\), and at an upper junction \(h_i=1-z_i/\lambda\). Comparing with the inverse formula preserves the layer and gives \(u'_i=z_i/\delta\). The intercepts stay generic because \(\delta\) is a unit of \(\mathbb{{Z}}[\lambda]\).</p>
<h3>Verify all attachments</h3>
<p>Every noncorner vertex has one, two or three opposite links according to the number of its coordinates below \(\delta\). A vertex with three links meets three corners. A vertex with two links meets a corner on one side and a noncorner on the other. A vertex with one link meets a two-link vertex. These facts follow from the coordinate reflection. They imply that every component meets a junction and that the paths to be checked have bounded length.</p>
<p>From each old junction, trace its three arms. Suppress a path between two junctions, retain the three-way meeting at a three-link vertex, or delete the dangling path. Compare the resulting attachments in the new index coordinates with the formulas above at \(u'=z/\delta\). The verifier splits the simplex whenever an exact affine threshold or floor can change the outcome. It covers ten feasible open regions per layer and checks the comparison in every region. A separate pass refines the coordinate intervals and verifies coverage. All breakpoints lie in \(\mathbb{{Z}}[\lambda]\), so generic phases avoid the omitted boundaries.</p>
{details}
</section>
<section id="plane"><h2>Descend, then lift to Turtle polygons</h2>
<div class="callout"><p><strong>Finite components and cycles cannot survive.</strong> Every finite component would map to a finite component with fewer minority vertices. Every cycle must use a junction, since the graph on noncorners has maximum degree one. Passing through a junction uses at least two old minority vertices and becomes one new vertex. Contracting the junction trees and suppressing the paths preserves a cycle and strictly reduces its minority vertex count. Iterating the same rule contradicts either finite count.</p></div>
<p>The red-rhomb graph therefore consists of infinite trees. Each locally finite tree has an infinite ray. Choose an end in every component and orient edges away from it. Every hexagon receives exactly one red rhomb. For every eligible black hexagon edge there is exactly one Turtle orientation attaching the red rhomb there. The audit checks all {audit["template_attachments"]} local orientation cases. Replacing straight seams by the checked 20-wedge Turtle shapes covers each Rhombille cell exactly, including holes, and yields the plane tiling.</p>
<p>The substitution here is on the matching graph. It supplies a smaller index graph and an inverse expansion of links and junctions. The construction uses the published dual geometry and the Fibonacci slope as hypotheses, and verifies the phase selection and renormalization separately. The proof applies to this generated family. The finite patch search and bounded attachment-rule failures are recorded in the preceding notebook. <a href="https://arxiv.org/abs/2403.01911">James Smith's Turtle constructions</a>.</p></section>
<section id="evidence"><h2>Replay the certificate</h2>
<ul><li><a href="{STEM}-results.json">Machine-readable proof checkpoints</a></li><li><a href="{STEM}-evidence.zip">Source and full certificate archive</a></li><li><a href="{STEM}-manifest.json">Archive manifest</a></li></ul>
<pre><code>python3.12 -I -S -B source/coarse_components_v1.py
python3.12 -I -S -B source/coarse_rule_v1.py
python3.12 -I -S -B source/renormalize_v1.py
python3.12 -I -S -B source/plane_audit_v1.py</code></pre>
<p>The four protocols record the exact interpreter and input hashes. Each script writes a new result, so use a fresh output directory when replaying archived evidence.</p></section></main></body></html>
"""


def main():
    summary=dict(status="CHECKED_TURTLE_PLANE_RENORMALIZATION_REPORT",
                 phase=load("input/phase-owner-v1.json"),
                 components=load("data/summary-v1.json"),
                 coarse=load("data/coarse-rule-summary-v1.json"),
                 renormalization=load("data/renormalize-v1.json")["layers"],
                 audit=load("data/plane-audit-v1.json"))
    assert all(r["status"]=="VERIFIED" and r["chambers"]==10 for r in summary["renormalization"])
    assert summary["phase"]["trials"][0]["failures"]=={}
    page=render(summary)
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(page)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(summary,f,indent=2,sort_keys=True)


if __name__=="__main__":
    main()
