"""Independently audit the phase partition, the index map and the tile lift."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from finite_construct_v1 import wedge_catalogue
from mechanical_v1 import Q
from phase_owner_v1 import OwnerGeometry
from renormalize_v1 import (D, L, ONE, Chamber, actual, predicted, inv, mul)
from rhombille_v1 import Bridge, edge, edges, load, pin, prepare, save


def q(wire):
    return Q(*(Fraction(x) for x in wire))


def boxes(certificate):
    cells=[]
    for r in certificate["certificates"]:
        box=tuple(tuple(map(q,p)) for p in r["box"])
        assert all(Q()<=a<b<=D for a,b in box)
        ch=Chamber(box)
        match=actual(ch,certificate["layer"])
        assert match==predicted(ch,certificate["layer"])
        assert json.loads(json.dumps([sorted(match[0]),sorted(match[1]),match[2]])) == [
            r["links"],r["stars"],r["dangling"]]
        cells.append(box)
    # Refine each coordinate using the union of every reported boundary.
    # Each feasible open microcell must lie in exactly one certificate box.
    coords=[sorted({Q(),D,*[x for box in cells for x in box[i]]}) for i in range(3)]
    audited=0
    for fine in product(*(list(zip(a,a[1:])) for a in coords)):
        if sum((a for a,_ in fine),Q())>=D or sum((b for _,b in fine),Q())<=D:
            continue
        owners=[box for box in cells if all(a<=x<y<=b for (a,b),(x,y) in zip(box,fine,strict=True))]
        assert len(owners)==1
        audited+=1
    return audited


def lattice(gamma, limit):
    checked=Counter()
    for i in range(-limit,limit+1):
        for j in range(-limit,limit+1):
            coarse=i,j,-i-j
            # Invert q' to the common integer floor vector of the old corners.
            kappa=[mul(g,inv(L)) for g in gamma]
            r=tuple(mul(Q(v)+g,inv(L)).floor() for v,g in zip(coarse,kappa,strict=True))
            assert sum(r) in (-2,-1)
            layer=sum(r)
            c=[]
            for v,g in zip(r,gamma,strict=True):
                lo=mul(Q(v)-g,inv(L))
                hi=lo+inv(L)
                a,b=lo.floor()+1,hi.floor()
                assert b==a+1 and Q(a)>lo and Q(b)<hi
                c.append((a,b))
            old=[p for p in product(*c) if sum(p)==0]
            assert len(old)==3
            expected=[(L*v+mul(g,inv(D))).residue() for v,g in zip(coarse,gamma,strict=True)]
            assert sum(expected,Q())==Q(-layer)
            desired=tuple(mul(ONE-x if layer==-2 else x,D) for x in expected)
            for p in old:
                f=tuple((L*v+g).residue() for v,g in zip(p,gamma,strict=True))
                u=tuple(ONE-x if layer==-2 else x for x in f)
                k,=[a for a,x in enumerate(u) if x>L]
                residual=tuple(x-L if a==k else x for a,x in enumerate(u))
                assert residual==desired
                back=tuple(mul(Q(v)-g,inv(L)).floor()-v+1 for v,g in zip(r,gamma,strict=True))
                assert back==coarse
                checked[layer]+=1
    return dict(checked)


def lifting(geometry):
    bridge=geometry.bridge
    checked=0
    for layer in (-2,-1):
        site=0,0,layer
        from line_words_v1 import project
        x,y=project(geometry.anchor,site)
        for bit in (0,1):
            black={s for s,c in geometry.palette(site,bit).items() if c=="black"}
            seen=set()
            for g,sign in sorted(geometry.signs.items()):
                if sign!=(1 if bit==0 else -1):
                    continue
                u,v=bridge.point((g,0,0),bridge.base["center"])
                pose=g,x-u,y-v
                if bridge.phase(pose)!=bridge.phase((0,0,0)):
                    continue
                _,_,rhomb=bridge.pose(pose)
                cell,=[i for i,r in enumerate(geometry.rings) if frozenset(r)==rhomb]
                seam,=[s for s in black if cell in geometry.rim[s]]
                assert seam not in seen
                seen.add(seam)
            assert seen==black and len(seen)==3
            checked+=len(seen)
    assert len(wedge_catalogue(bridge))==20
    return checked


def main():
    protocol=load("plane-audit-protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    cert=load("data/renormalize-v1.json")
    assert all(r["status"]=="VERIFIED" for r in cert["layers"])
    refinements={r["layer"]:boxes(r) for r in cert["layers"]}
    beta=list(map(Fraction,protocol["intercepts"]))
    gamma=[(Q(3)+L)*(-b) for b in beta]
    checks=[]
    for _ in range(protocol["rescalings"]+1):
        assert sum(gamma,Q())==Q()
        assert all((g.a+2*g.b/Fraction(5))%1 or (g.b/Fraction(5))%1 for g in gamma)
        checks.append(lattice(gamma,protocol["index_radius"]))
        gamma=[mul(g,inv(D)) for g in gamma]
    engine,_=prepare()
    templates=lifting(OwnerGeometry(Bridge(engine)))
    result=dict(status="CHECKED_PLANE_PROOF_CERTIFICATE_AUDIT",partition_refinement=refinements,
                index_checks=checks,template_attachments=templates)
    save("data/plane-audit-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
