"""Prove local contraction of majority components in the phase matching graph."""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from attachment_solver_v1 import floor_change
from phase_owner_v1 import OwnerGeometry, patterns
from rhombille_v1 import Bridge, load, pin, prepare, save


def add(a,b):
    return tuple(x+y for x,y in zip(a,b,strict=True))


def sub(a,b):
    return tuple(x-y for x,y in zip(a,b,strict=True))


class Window:
    def __init__(self, geometry, base, word, wide, band):
        self.geometry=geometry
        self.base=base
        self.word=word
        self.wide=wide
        self.band=band

    def floors(self, site):
        return tuple(floor_change(self.word,self.wide,i,d)
                     for i,d in enumerate(sub(site,self.base)))

    def label(self, site):
        local=sub(site,self.base)
        assert max(map(abs,local))<=self.wide
        digits=tuple(self.word[i][d+self.wide] for i,d in enumerate(local))
        band=self.band-sum(self.floors(site))
        layer=sum(site)
        if digits==(1,1,1):
            assert band==3
            return 1
        if digits==(0,0,0) and (layer,band) in {(-2,2),(-1,1)}:
            return 0
        return None

    @lru_cache(maxsize=2048)
    def adjacent(self, site):
        geometry=self.geometry
        ref=(0,0,sum(site))
        delta=sub(site,ref)
        words=[]
        r=3
        for i,d in enumerate(sub(site,self.base)):
            assert -self.wide<=d-r<=d+r<=self.wide
            a=self.wide+d
            words.append(self.word[i][a-r:a+r+1])
        band=self.band-sum(self.floors(site))
        state,selected=geometry.context(ref,tuple(words),r,band)
        assert selected(ref) and self.label(site) in (0,1)
        results=[]
        for rid in geometry.hex_options(ref,state):
            targets=geometry.red_choices(rid,state)
            assert len(targets)==2
            neighbor,=set(targets)-{ref}
            axis,ends,_=geometry.endpoints[rid]
            start,=[p for p in ends if sum(p)==-2]
            results.append((add(neighbor,delta),(*add(start,delta),axis)))
        return tuple(results)

    def majority(self, maximum):
        assert self.label(self.base)==0
        seen={self.base}
        queue=[self.base]
        red=set()
        branches=[]
        for site in queue:
            for neighbor,e in self.adjacent(site):
                kind=self.label(neighbor)
                if kind==0:
                    red.add(e)
                    if neighbor not in seen:
                        seen.add(neighbor)
                        queue.append(neighbor)
                        assert len(queue)<=maximum
                else:
                    assert kind==1
                    branches.append((neighbor,e))
        assert len(red)==len(queue)-1
        assert len(branches)==len({p for p,_ in branches})
        return queue,branches


def canonical(window,branches):
    sites=sorted((window.floors(p),sum(p)) for p,_ in branches)
    assert sites and len({sum(q) for q,_ in sites})==1
    base=sites[0][0]
    return tuple((sub(q,base),layer) for q,layer in sites)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    wide=protocol["radius"]
    rows=[]
    labels=Counter()
    states=Counter()
    for layer in (-2,-1):
        base=(0,0,layer)
        for pattern,band in patterns(layer,wide):
            window=Window(geometry,base,pattern,wide,band)
            label=window.label(base)
            states[layer,label]+=1
            if label==1:
                assert len(window.adjacent(base))==3
            if label!=0:
                continue
            comp,branches=window.majority(protocol["majority_cap"])
            signature=len(comp),canonical(window,branches)
            labels[signature]+=1
            rows.append(dict(layer=layer,band=band,pattern=pattern,majority=sorted(comp),
                             minority=sorted(branches),signature=signature))
    assert len(labels)==7
    report=dict(status="CHECKED_MAJORITY_COMPONENT_CONTRACTION",
                radius=wide, states=[(p,n) for p,n in sorted(states.items(),key=str)],
                component_types=[(p,n) for p,n in sorted(labels.items())],
                scope="Exact local phase cases for the generated model. All majority components are trees of three or four hexagons, each meeting one to three distinct minority hexagons. Contraction preserves cycles and infinite components.")
    save("data/results-v1.json",rows)
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
