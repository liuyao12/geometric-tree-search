"""Verify the minority matching graph is reproduced by a smaller index lattice."""

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from coarse_components_v1 import add, sub
from mechanical_v1 import Q
from rhombille_v1 import load, pin, save


ONE=Q(1)
L=Q(2,-5)     # (sqrt(5)-1)/2
D=ONE-L       # L**2
ORIGIN=(0,0,0)
CYCLIC=((0,2),(2,1),(1,0))


def mul(a,b):
    return Q(a.a*b.a-a.b*b.b*Fraction(1,5), a.a*b.b+a.b*b.a+a.b*b.b)


def inv(a):
    conjugate=Q(a.a+a.b,-a.b)
    n=mul(a,conjugate)
    assert n.b==0 and n.a
    return conjugate*Fraction(1,n.a)


class Split(Exception):
    def __init__(self,i,cut):
        self.i=i
        self.cut=cut


@dataclass(frozen=True)
class X:
    axis:int
    scale:Q
    shift:Q=Q()

    def plus(self,c):
        return X(self.axis,self.scale,self.shift+c)

    def reflect(self,c):
        return X(self.axis,self.scale*-1,c-self.shift)

    def times(self,q):
        return X(self.axis,mul(self.scale,q),mul(self.shift,q))

    def eval(self,x):
        return mul(self.scale,x)+self.shift


class Chamber:
    def __init__(self,domains):
        self.domains=domains

    def lt(self,x,y):
        a,b=self.domains[x.axis]
        low,high=sorted((x.eval(a),x.eval(b)))
        if high<=y:
            return True
        if low>=y:
            return False
        cut=mul(y-x.shift,inv(x.scale))
        assert a<cut<b
        raise Split(x.axis,cut)

    def floor(self,x):
        a,b=self.domains[x.axis]
        mid=(a+b)*Fraction(1,2)
        k=x.eval(mid).floor()
        if self.lt(x,Q(k)):
            raise AssertionError("midpoint floor below candidate")
        if not self.lt(x,Q(k+1)):
            raise AssertionError("midpoint floor above candidate")
        return k


@dataclass(frozen=True)
class Site:
    q:tuple
    layer:int
    u:tuple


def direction(i,j,sign):
    return tuple(sign if k==i else -sign if k==j else 0 for k in range(3))


def opposite(site,c):
    sign=1 if site.layer==-2 else -1
    for i,j in CYCLIC:
        if c.lt(site.u[i],L) and c.lt(site.u[j],D):
            weights=tuple(L if a==i else D if a==j else ONE for a in range(3))
            yield Site(add(site.q,direction(i,j,sign)),-3-site.layer,
                       tuple(u.reflect(v) for u,v in zip(site.u,weights,strict=True)))


def corner(site,c):
    eligible=[i for i,x in enumerate(site.u) if not c.lt(x,L)]
    assert len(eligible)<=1
    return eligible[0] if eligible else None


def triangle(site,i):
    sign=1 if site.layer==-2 else -1
    for j in range(3):
        if j==i:
            yield site
        else:
            u=tuple(x.plus(L*(-1 if k==i else 1 if k==j else 0)) for k,x in enumerate(site.u))
            yield Site(add(site.q,direction(i,j,sign)),site.layer,u)


def remaining(links,prior):
    assert len({x.q for x in links})==len(links)
    assert prior.q in {x.q for x in links}
    return [x for x in links if x.q!=prior.q]


def actual(chamber,layer):
    z=tuple(X(i,ONE) for i in range(3))
    initial=Site(ORIGIN,layer,tuple(x.plus(L) if i==0 else x for i,x in enumerate(z)))
    f=tuple(x.reflect(ONE) if layer==-2 else x for x in initial.u)
    f_lo=tuple(x.times(inv(L)).plus(D) if layer==-2 else x.times(inv(L)).reflect(ONE)
               for x in z)

    def index(target):
        assert corner(target,chamber) is not None
        r=tuple(chamber.floor(x.plus(L*d)) for x,d in zip(f,target.q,strict=True))
        idx=tuple(chamber.floor(x.plus(L*d)) for x,d in zip(f_lo,r,strict=True))
        assert sum(idx)==0
        return idx

    links,stars,dangling=set(),set(),0
    for a in triangle(initial,0):
        assert index(a)==ORIGIN
        b,=opposite(a,chamber)
        assert corner(b,chamber) is None
        step=list(opposite(b,chamber))
        if len(step)==3:
            vertices=tuple(sorted(index(p) for p in step))
            assert len(set(vertices))==3 and ORIGIN in vertices
            stars.add(vertices)
        elif len(step)==2:
            v,=remaining(step,a)
            assert corner(v,chamber) is None
            jump=list(opposite(v,chamber))
            if len(jump)==1:
                assert jump[0].q==b.q
                dangling+=1
            else:
                assert len(jump)==2
                w,=remaining(jump,b)
                assert w.layer!=layer
                q=index(w)
                assert q!=ORIGIN and q not in links
                links.add(q)
        else:
            raise AssertionError("unclassified first noncorner")
    assert len(stars)+len(links)+dangling==3
    return links,stars,dangling


def predicted(chamber,layer):
    z=tuple(X(i,ONE) for i in range(3))
    sign=1 if layer==-2 else -1
    long=mul(D,L)
    short=mul(D,D)
    links={direction(i,j,sign) for i,j in CYCLIC
           if chamber.lt(z[i],long) and chamber.lt(z[j],short)}
    corners=[i for i,x in enumerate(z) if not chamber.lt(x,long)]
    assert len(corners)<=1
    stars=set()
    if corners:
        i,=corners
        stars.add(tuple(sorted((ORIGIN,*(direction(i,j,sign) for j in range(3) if j!=i)))))
    return links,stars,3-len(links)-len(stars)


def wire(domains):
    return [(a.wire(),b.wire()) for a,b in domains]


def enumerate_chambers(layer):
    open_boxes=[((Q(),D),)*3]
    rejected=0
    certificates=[]
    while open_boxes:
        domains=open_boxes.pop()
        if not sum((a for a,_ in domains),Q())<D<sum((b for _,b in domains),Q()):
            rejected+=1
            continue
        chamber=Chamber(domains)
        try:
            result=actual(chamber,layer)
            expect=predicted(chamber,layer)
            if result!=expect:
                return dict(status="COUNTEREXAMPLE", layer=layer, box=wire(domains),
                            actual=(sorted(result[0]),sorted(result[1]),result[2]),
                            predicted=(sorted(expect[0]),sorted(expect[1]),expect[2]))
        except Split as s:
            a,b=domains[s.i]
            open_boxes.extend(domains[:s.i]+((x,y),)+domains[s.i+1:] for x,y in ((a,s.cut),(s.cut,b)))
            continue
        certificates.append(dict(box=wire(domains),links=sorted(result[0]),stars=sorted(result[1]),dangling=result[2]))
    return dict(status="VERIFIED",layer=layer,chambers=len(certificates),
                discarded_empty_boxes=rejected,certificates=certificates)


def main():
    protocol=load("renormalize-protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    assert mul(L,L)==D
    result=[enumerate_chambers(layer) for layer in (-2,-1)]
    save("data/renormalize-v1.json",dict(status="CHECKED_RENORMALIZATION",layers=result))
    for row in result:
        print(json.dumps({k:v for k,v in row.items() if k!="certificates"},sort_keys=True),flush=True)


if __name__=="__main__":
    main()
