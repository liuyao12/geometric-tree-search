"""Recover the reduced matching graph on the lattice of minority markers."""

from collections import Counter
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from coarse_components_v1 import Window, add, sub
from phase_owner_v1 import OwnerGeometry, patterns
from rhombille_v1 import Bridge, load, pin, prepare, save


CYCLIC=((1,0,-1),(0,-1,1),(-1,1,0))


def coarse_stars(window):
    base=window.base
    assert window.label(base)==1
    visited=set()
    results=[]
    dangling=0
    for p,_ in window.adjacent(base):
        assert window.label(p)==0 and p not in visited
        component=[p]
        visited.add(p)
        spokes=[]
        for v in component:
            for w,e in window.adjacent(v):
                if window.label(w)==1:
                    spokes.append(w)
                elif w not in visited:
                    assert window.label(w)==0
                    visited.add(w)
                    component.append(w)
                    assert len(component)<=4
        assert len(set(spokes))==len(spokes) and base in spokes
        if len(spokes)==1:
            assert len(component)==3
            dangling+=1
        else:
            assert len(component)==4 and len(spokes) in (2,3)
            results.append(tuple(sorted(window.floors(q) for q in spokes)))
    assert len(set(results))==len(results)
    return set(results),dangling


def marker_moves(window):
    radius=window.wide
    steps={}
    for i,word in enumerate(window.word):
        for sign in (-1,1):
            offset=next(sign*j for j in range(1,5) if word[radius+sign*j])
            assert abs(offset) in (3,4)
            steps[i,sign]=offset
    return steps


def predicted(window):
    layer=sum(window.base)
    steps=marker_moves(window)
    result=set()
    start=(0,0,0)

    def locate(index):
        diff=tuple(steps[i,d] if d else 0 for i,d in enumerate(index))
        p=add(window.base,diff)
        assert window.label(p)==1 and window.floors(p)==index
        return p

    for d in CYCLIC:
        q=d if layer==-2 else tuple(-x for x in d)
        if sum(locate(q))!=layer:
            result.add(tuple(sorted((start,q))))
    ori=1 if layer==-2 else -1
    for shared in range(3):
        others=[i for i in range(3) if i!=shared]
        q,r=(tuple(ori if i==shared else -ori if i==other else 0 for i in range(3))
             for other in others)
        if (sum(locate(q))==sum(locate(r))==layer and abs(steps[shared,ori])==3):
            result.add(tuple(sorted((start,q,r))))
    return result


def main():
    protocol=load("coarse-rule-protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    engine,_=prepare()
    geometry=OwnerGeometry(Bridge(engine))
    radius=protocol["radius"]
    counts=Counter()
    rows=[]
    for layer in (-2,-1):
        for p,band in patterns(layer,radius):
            window=Window(geometry,(0,0,layer),p,radius,band)
            if window.label(window.base)!=1:
                continue
            actual,dangling=coarse_stars(window)
            candidate=predicted(window)
            assert actual==candidate,(layer,actual,candidate)
            counts[len(actual),dangling]+=1
            rows.append(dict(layer=layer,band=band,pattern=p,attachments=sorted(actual),dangling=dangling))
    report=dict(status="CHECKED_EXACT_COARSE_TRIANGULAR_GRAPH",radius=radius,
        states=len(rows),stencils=[(p,n) for p,n in sorted(counts.items())],
        rule="Opposite layers join along three cyclic directions. Same-layer triangular junctions occupy the specified orientation when the common coordinate takes a short marker step. One-arm subtrees are omitted.")
    save("data/coarse-rule-results-v1.json",rows)
    save("data/coarse-rule-summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
