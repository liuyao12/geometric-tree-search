Fresh exact Turtle corona search and marking synthesis,2026-11-03.
The304complete rooted contact catalogue is generated from all positive-support
alignments of the exact original28-point Turtle, with empty markings. The prior
geometry qualification is data-only provenance. No old scientific JavaScript,
known matching assignments or tiling/substitution witness is imported.

The incremental point engine has shared candidate incidence, exact contribution
units, globaldead/finitecheckpoint/forced/generation-first decisions and a full
logical trail. Immutable candidate caches are not logical rollback state. The
finite checkpoint fills every fixed-pair support point and leaves all exposed
frontier domains viable; it is not infinite extension or propagation closure.
Node,time,depth and cohort stops remainUNKNOWN. Independent replay reconstructs
every actual certificate node and requires all legal children for a negative.

Actual outcomes:41checked coronas,263exhausted negatives,0unresolved. Fresh rank3
signed equality synthesis uses every resolved label, no holdout. Halo1 has56
prototype points,168assigned components,83assigned zeros and0individual absent
entries. It accepts41/41positives and rejects236/263negatives;8prospective marked
followups find checked coronas. These markings are finite learned restrictions,
not proved redundant constraints. No RL, substitution, practical-region speed
claim, fair untouched-point activation or plane-tiling proof is supplied.

Python3.12stdlib reproduction: use a FRESH copy; preserve this evidence. The
driver's freeze command copies prior-phase inputs from its sibling directory;
those exact copies are retained under reference/ in this archive. Use source/
experiment_v1.py run only after retaining/verifying data/protocol-frozen-v1.json
and its pinned model/catalogue/fixtures. Run writes outputs; do not overwrite
this evidence copy. Runtime path/hash, native exit and source custody are in
review/execution-completion-v1.json. The independent decorated-action audit has
its own review/ utility and receipt. The report builder is passive.

Native total200.096s includes all checks, recording and unseparated overhead.
Unmarked search14.066s, main assurance16.243s and marking updates0.632s are
component measurements, not complete method totals. Marked assurance and some
other stages were not separately timed. No total-cost advantage is claimed.

Full task-owned Sources,data,certificates,logs and local paths are public with
explicit approval at the existing GitHub Pages destination. Unrelated checkout
changes and retired materials research are excluded. The archive cut excludes
package/ and publication/ to prevent recursion; later deployment receipts are
preserved in the completed local run.
