"""Independent saved-data decorated-action audit; never imports study Sources.

This checks frozen finite fields and records, not corona proof trees or geometry.
Run only after the actual study has finished and execution is authorized.
"""
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time


SCHEMA = 'Turtle-decorated-action-independent-audit-v1'
TRANSFORM = {
    'point': 'signed A2 coordinate permutation, using the supplied exact axial matrix',
    'channel': 'source c moves to inverse_permutation[c]; world j reads prototype permutation[j]',
    'scalar': 'multiply by permutation parity only; no common-sign factor',
    'missing': 'unconstrained; individual * entries are omitted from assigned markings',
    'zero': 'assigned scalar value, never absent'
}
STEPS = ((1, -1), (1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1))


class AuditViolation(Exception):
    pass


def require(condition, message):
    if not condition:
        raise AuditViolation(message)


def integer(value):
    require(type(value) is int, 'An exact integer field contains a noninteger/bool.')
    return value


def wire(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'),
                       ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def load(path, pins, key):
    raw = path.read_bytes()
    pins[key] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def matrix_product(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2))
                       for j in range(2)) for i in range(2))


def apply_point(matrix, x, y):
    return (matrix[0][0] * x + matrix[0][1] * y,
            matrix[1][0] * x + matrix[1][1] * y)


def groups_from_reference(model):
    groups, matrices, descriptors = {}, {}, set()
    for row in model['groups']:
        gid, sign = integer(row['id']), integer(row['sign'])
        perm = tuple(integer(v) for v in row['permutation'])
        require(len(perm) == 3 and set(perm) == {0, 1, 2} and sign in (-1, 1),
                'Reference signed permutation is malformed.')
        # Axial coordinates mean the sum-zero triple (x,y,-x-y).
        triple_basis = ((1, 0), (0, 1), (-1, -1))
        matrix = tuple(tuple(sign * v for v in triple_basis[perm[j]]) for j in range(2))
        supplied = tuple(tuple(integer(v) for v in r) for r in row['matrix'])
        require(matrix == supplied, 'Reference matrix is not its stated signed permutation.')
        require(matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0] in (-1, 1),
                'Reference point matrix is not unimodular.')
        # Recover the destination channel for each source by solving perm[j]=c.
        channel = tuple(next(j for j in range(3) if perm[j] == c) for c in range(3))
        inversions = sum(perm[i] > perm[j] for i in range(3) for j in range(i + 1, 3))
        parity = (-1) ** inversions
        require(gid not in groups and matrix not in matrices and (sign, perm) not in descriptors,
                'Reference has duplicate group IDs, matrices or signed permutations.')
        groups[gid] = dict(matrix=matrix, channel=channel, parity=parity,
                           permutation=perm, common_sign=sign)
        matrices[matrix] = gid
        descriptors.add((sign, perm))
    require(set(groups) == set(range(12)) and len(descriptors) == 12,
            'The complete twelve signed coordinate actions are required.')
    require(groups[0]['matrix'] == ((1, 0), (0, 1)) and groups[0]['channel'] == (0, 1, 2)
            and groups[0]['parity'] == 1, 'Root orientation 0 is not the decorated identity.')
    products = {}
    for g, ag in groups.items():
        for h, ah in groups.items():
            product = matrix_product(ag['matrix'], ah['matrix'])
            require(product in matrices, 'Point matrices are not composition-closed.')
            k = matrices[product]
            require(tuple(ag['channel'][ah['channel'][c]] for c in range(3)) == groups[k]['channel'],
                    'Channel action fails the point-group composition law.')
            require(ag['parity'] * ah['parity'] == groups[k]['parity'],
                    'Scalar parity fails the point-group composition law.')
            products[g, h] = k
    require(all(any(products[g, h] == products[h, g] == 0 for h in groups) for g in groups),
            'Some group element lacks an inverse.')
    return groups, products


def t_field(rows):
    field = {}
    for row in rows:
        require(type(row) is list and len(row) == 3, 't-field rows must be exact triples.')
        x, y, value = [integer(v) for v in row]
        require((x, y) not in field and 0 < value <= 12, 'Invalid/duplicate positive t component.')
        field[x, y] = value
    return field


def m_field(rows, allow_absence):
    assigned, seen, absent = {}, set(), 0
    for row in rows:
        require(type(row) is list and len(row) == 4, 'm-field rows must have four typed components.')
        x, y, channel = [integer(v) for v in row[:3]]
        require(0 <= channel < 3 and (x, y, channel) not in seen,
                'An m component is duplicated or has an invalid typed channel.')
        seen.add((x, y, channel))
        value = row[3]
        if type(value) is str and value == '*':
            require(allow_absence, 'Absent entries must be omitted from exported orientations.')
            absent += 1
        else:
            assigned[x, y, channel] = integer(value)  # zero stays assigned
    return assigned, seen, absent


def orient_t(field, action):
    result = {}
    for (x, y), value in field.items():
        point = apply_point(action['matrix'], x, y)
        require(point not in result, 'Point transform is not injective on actual t support.')
        result[point] = value
    return result


def orient_m(field, action):
    result = {}
    for (x, y, channel), value in field.items():
        a, b = apply_point(action['matrix'], x, y)
        key = a, b, action['channel'][channel]
        require(key not in result, 'Decorated transform is not injective on actual m support.')
        result[key] = action['parity'] * value
    return result


def orientation_fields(model, key, marks=False):
    fields = {}
    for orientation in model[key]:
        gid = integer(orientation['id'])
        require(gid not in fields, 'Duplicate exported orientation ID.')
        fields[gid] = m_field(orientation['points'], False)[0] if marks else t_field(orientation['points'])
    require(set(fields) == set(range(12)), 'Exported orientation IDs are not exactly 0 through 11.')
    return fields


def attachment(row, groups):
    require(type(row) in (list, tuple) and len(row) == 3, 'Attachment triple required.')
    key = tuple(integer(v) for v in row)
    require(key[0] in groups, 'Attachment orientation is outside the frozen group.')
    return key


def capacity_legal(root, other, dx, dy):
    return all(root.get((x + dx, y + dy), 0) + value <= 12
               for (x, y), value in other.items())


def mark_pair(root, other, dx, dy):
    overlaps, conflicts = 0, 0
    for (x, y, channel), value in other.items():
        key = x + dx, y + dy, channel
        if key in root:
            overlaps += 1
            conflicts += root[key] != value
    return conflicts == 0, overlaps, conflicts


def audit(run_root, report):
    pins = report['inputs']
    result = load(run_root / 'data/results-v1.json.gz', pins, 'data/results-v1.json.gz')
    original = load(run_root / 'reference/input-point-model-v1.json', pins,
                    'reference/input-point-model-v1.json')
    frozen_catalogue = load(run_root / 'data/contact-catalogue-v1.json', pins,
                            'data/contact-catalogue-v1.json')
    frozen_model = load(run_root / 'data/point-model-v1.json', pins, 'data/point-model-v1.json')
    protocol = load(run_root / 'data/protocol-frozen-v1.json', pins, 'data/protocol-frozen-v1.json')
    report['stage'] = 'input provenance'
    require(result['schema'] == 'Turtle-fresh-corona-and-marking-v1'
            and result['status'] == 'COMPLETE_COHORT', 'Actual result is not a completed corona cohort.')
    require(result['protocol'] == protocol and result['model'] == frozen_model,
            'Result data do not match the frozen protocol/model.')
    for name in ('reference/input-point-model-v1.json', 'data/contact-catalogue-v1.json',
                 'data/point-model-v1.json'):
        require(protocol['source_pins'][name] == pins[name], 'A frozen input byte/hash pin differs: ' + name)
    require(original['initial_markings'] == [], 'Original input was not unmarked.')
    require(result['model']['capacity'] == 12 and result['model']['marking_orientations'] == [],
            'Unmarked model capacity/mark inventory differs.')
    groups, products = groups_from_reference(original)
    report['stage'] = 'prototype and exported fields'
    prototype_t = t_field(original['original_field'])
    require(len(prototype_t) == 28, 'This frozen Turtle prototype must have 28 angular points.')
    learned, marked = result['learned_marking'], result['marked_model']
    require(learned['source_model_sha256'] == digest(original), 'Learned model does not bind original data.')
    require(learned['transform'] == TRANSFORM, 'Declared decorated action differs from the audited action.')
    fingerprint = digest(dict(source_model_sha256=learned['source_model_sha256'],
                              selected_halo=learned['selected_halo'],
                              prototype_points=learned['prototype_points'], transform=TRANSFORM))
    require(fingerprint == learned['marking_sha256'], 'Final marking fingerprint differs.')
    require(learned['absence_token'] == '*' and learned['missing_is_unconstrained'] is True
            and learned['zero_is_assigned'] is True, 'Absence/zero semantics are not explicit.')
    proto_m, all_components, absent = m_field(learned['prototype_points'], True)
    halo = integer(learned['selected_halo'])
    require(halo in (1, 2, 3), 'Final halo is outside the frozen alternatives.')
    support = set(prototype_t)
    for _ in range(halo):
        support |= {(x + dx, y + dy) for x, y in support for dx, dy in STEPS}
    require(all_components == {(x, y, c) for x, y in support for c in range(3)},
            'Prototype typed domains differ from the selected expanded halo.')
    expected_t = {g: orient_t(prototype_t, action) for g, action in groups.items()}
    expected_m = {g: orient_m(proto_m, action) for g, action in groups.items()}
    unmarked_t = orientation_fields(result['model'], 'orientations')
    marked_t = orientation_fields(marked, 'orientations')
    actual_m = orientation_fields(marked, 'marking_orientations', marks=True)
    require(marked['capacity'] == 12 and marked_t == unmarked_t == expected_t,
            'Saved t fields are not the exact twelve original point transforms.')
    require({k: v for k, v in marked.items() if k != 'marking_orientations'}
            == {k: v for k, v in result['model'].items() if k != 'marking_orientations'},
            'Marked export changed non-marking model fields.')
    require(actual_m == expected_m, 'Exported markings differ from independent typed/parity transforms.')
    report['fields'] = dict(orientations=12, prototype_t_points=len(prototype_t), halo=halo,
        prototype_domain_components=len(all_components), prototype_assigned_components=len(proto_m),
        prototype_absent_components=absent, prototype_assigned_zero_components=sum(v == 0 for v in proto_m.values()),
        exported_assigned_components=sum(len(v) for v in actual_m.values()),
        exported_assigned_zero_components=sum(v == 0 for f in actual_m.values() for v in f.values()),
        absent_omitted_not_coerced_to_zero=True, zero_retained_as_assigned=True,
        marking_sha256=fingerprint)
    report['stage'] = 'all decorated group products'
    composition_rows = []
    for (g, h), k in sorted(products.items()):
        require(orient_t(unmarked_t[h], groups[g]) == unmarked_t[k]
                and orient_t(marked_t[h], groups[g]) == marked_t[k],
                'Actual exported t fields fail a group product.')
        require(orient_m(actual_m[h], groups[g]) == actual_m[k],
                'Actual exported decorated m fields fail a group product.')
        composition_rows.append([g, h, k])
    report['group_action'] = dict(products_checked=len(composition_rows),
        convention='Row [g,h,k] means g after h; M_k=M_g M_h.', products=composition_rows,
        point_and_t_action_verified=True, typed_channel_action_verified=True,
        permutation_parity_action_verified=True, no_common_sign_scalar_factor=True,
        t_component_comparisons=2 * 144 * len(prototype_t),
        m_component_comparisons=144 * len(proto_m))
    report['stage'] = 'complete rooted contact catalogue'
    catalogue = [attachment(row, groups) for row in frozen_catalogue]
    require(len(catalogue) == 304 and len(set(catalogue)) == 304 and catalogue == sorted(catalogue),
            'Frozen catalogue is not the sorted distinct 304 attachments.')
    require(result['catalogue'] == frozen_catalogue, 'Final result catalogue differs from frozen data.')
    rebuilt = set()
    for g, other in expected_t.items():
        for x, y in other:
            for px, py in prototype_t:
                candidate = (g, px - x, py - y)
                if candidate != (0, 0, 0) and capacity_legal(prototype_t, other, candidate[1], candidate[2]):
                    rebuilt.add(candidate)
    require(rebuilt == set(catalogue), 'Independent full t-support alignment enumeration differs.')
    report['catalogue'] = dict(size=len(catalogue), reconstructed_from_all_t_support_alignments=True,
        identical_root_excluded=True, sha256=digest([list(c) for c in catalogue]))
    report['stage'] = 'all pair marking agreements and label scores'
    rows = {}
    for row in result['rows']:
        key = attachment(row['attachment'], groups)
        require(key not in rows and row['status'] in ('POSITIVE', 'NEGATIVE', 'UNKNOWN'),
                'Repeated pair or invalid classification in actual rows.')
        rows[key] = row
    require(set(rows) == set(catalogue), 'Final classifications do not cover exactly the catalogue.')
    labels = {}
    for row in learned['classifications']:
        key = attachment(row['attachment'], groups)
        require(key not in labels, 'Learned classification list repeats a pair.')
        labels[key] = row['status']
    require(labels == {key: row['status'] for key, row in rows.items()},
            'Learner labels differ from actual certified classifications.')
    require(learned['expected_catalogue_size'] == 304, 'Learner activation catalogue size differs.')
    replay = result['independent_pair_replay']
    require(replay['status'] == 'VERIFIED' and replay['catalogue_complete'] is True
            and replay['catalogue_sha256'] == report['catalogue']['sha256']
            and replay['marking_sha256'] == fingerprint, 'Independent replay is not bound to final data.')
    replay_rows = {}
    for row in replay['pairs']:
        key = attachment(row['attachment'], groups)
        require(key not in replay_rows and type(row['compatible']) is bool, 'Replay pair results malformed.')
        require(row['receipt']['status'] == ('VERIFIED' if row['compatible'] else 'REJECTED'),
                'Replay boolean and its saved receipt status differ.')
        replay_rows[key] = row
    require(set(replay_rows) == set(catalogue), 'Replay does not cover exactly all 304 pairs.')
    counts = dict(positive_total=0, positive_correct=0, negative_total=0,
                  negative_correct=0, unknown_total=0, total_correct=0)
    pair_results = []
    for key in catalogue:
        g, dx, dy = key
        require(capacity_legal(prototype_t, expected_t[g], dx, dy), 'Catalogue pair violates t capacity.')
        compatible, overlaps, conflicts = mark_pair(proto_m, expected_m[g], dx, dy)
        require(compatible == replay_rows[key]['compatible'], 'Independent literal m replay differs.')
        status = labels[key]
        if status == 'POSITIVE':
            counts['positive_total'] += 1
            counts['positive_correct'] += compatible
            require(compatible, 'A positive corona label violates an imposed marking equality.')
        elif status == 'NEGATIVE':
            counts['negative_total'] += 1
            counts['negative_correct'] += not compatible
        else:
            counts['unknown_total'] += 1
        pair_results.append(dict(attachment=list(key), status=status, compatible=compatible,
                                 coincident_assigned_components=overlaps, disagreements=conflicts))
    counts['total_correct'] = counts['positive_correct'] + counts['negative_correct']
    for name, value in counts.items():
        require(learned['score'][name] == value, 'Final marking score differs: ' + name)
    require(learned['score']['halo'] == halo, 'Score belongs to another selected halo.')
    gate = result['activation_gate']
    require(gate['marking_sha256'] == fingerprint
            and gate['catalogue_sha256'] == report['catalogue']['sha256']
            and gate['catalogue_size'] == 304, 'Activation gate is not bound to final finite model.')
    for name in ('positive_total', 'positive_correct', 'negative_total', 'negative_correct'):
        require(gate[name] == counts[name], 'Activation gate score differs: ' + name)
    reasons = []
    if counts['unknown_total']:
        reasons.append('UNRESOLVED_CLASSIFICATIONS')
    if counts['positive_correct'] != counts['positive_total']:
        reasons.append('NOT_ALL_POSITIVES_ACCEPTED')
    if counts['negative_total'] and 2 * counts['negative_correct'] <= counts['negative_total']:
        reasons.append('NOT_STRICT_MAJORITY_NEGATIVES_REJECTED')
    require(type(gate['ready']) is bool and gate['ready'] == (not reasons)
            and gate['reasons'] == reasons
            and gate['status'] == ('NOT_READY' if reasons else 'PASS_ACTIVATION_GATE'),
            'Activation gate decision/reasons do not match independently recomputed scores.')
    report['pair_replay'] = dict(pairs_checked=304, counts=counts, pairs=pair_results,
        all_positive_equalities_satisfied=True, unknowns_excluded_from_positive_and_negative_scores=True,
        literal_point_and_typed_channel_matching=True, replay_booleans_and_receipts_agree=True)
    report['activation_gate'] = dict(ready=gate['ready'], status=gate['status'], reasons=reasons,
                                     independently_recomputed=True)
    report['status'] = 'VERIFIED'
    report['stage'] = 'complete'
    report['scope'] = ('Independent stdlib-only audit of the frozen finite decorated action, exact t/mark exports, '
        'complete rooted contact alignment catalogue and saved classification/gate consistency. '
        'No engine, learner or checker imported; no search, geometry, corona-tree replay, new labels, '
        'global redundancy, infinite growth or plane-tiling claim. Absence and zero claims concern the '
        'literal export convention; observed counts are reported separately. This is assurance time, '
        'not scientific search or learning time.')


def main():
    run_root = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).resolve().parents[1]
    if len(sys.argv) > 2:
        raise SystemExit('Usage: python3 review/decorated_action_audit_v1.py [run_root]')
    started = time.perf_counter()
    source = Path(__file__).read_bytes()
    report = dict(schema=SCHEMA, status='UNKNOWN', stage='starting', inputs={},
                  source=dict(bytes=len(source), sha256=hashlib.sha256(source).hexdigest()))
    try:
        audit(run_root, report)
    except AuditViolation as error:
        report.update(status='REJECTED', error=str(error))
    except Exception as error:
        report.update(status='UNKNOWN', error_type=type(error).__name__, error=str(error))
    report['passive_assurance_seconds'] = time.perf_counter() - started
    target = run_root / 'review/decorated-action-audit-v1.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as handle:
        handle.write(wire(report))
    print(json.dumps(dict(status=report['status'], stage=report['stage'], output=str(target),
                          seconds=report['passive_assurance_seconds'])), flush=True)
    return 0 if report['status'] == 'VERIFIED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
