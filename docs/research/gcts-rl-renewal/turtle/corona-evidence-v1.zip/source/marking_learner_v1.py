"""Fresh rank-three Turtle marking synthesis from resolved unmarked labels.

Positive pairs impose signed equalities; negative pairs only test separation.
No known marking, old JavaScript, tiling witness, search or scientific module
is imported. Dense provisional models retain explicit '*' absence semantics.
"""
import hashlib
import json

VERSION = 'TURTLE-INCREMENTAL-SIGNED-UF-MARKINGS-v1'
STEPS = ((1, -1), (1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1))
ABSENT = '*'
TRANSFORM = {
    'point': 'signed A2 coordinate permutation, using the supplied exact axial matrix',
    'channel': 'source c moves to inverse_permutation[c]; world j reads prototype permutation[j]',
    'scalar': 'multiply by permutation parity only; no common-sign factor',
    'missing': 'unconstrained; individual * entries are omitted from assigned markings',
    'zero': 'assigned scalar value, never absent'
}


def _need(condition, message):
    if not condition:
        raise ValueError(message)


def _int(value):
    _need(type(value) is int, 'Native integer required, not bool/float.')
    return value


def digest(value):
    wire = json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False) + '\n'
    return hashlib.sha256(wire.encode('ascii')).hexdigest()


def _attachment(value, groups):
    _need(type(value) in (list, tuple) and len(value) == 3, 'Attachment is [group,dx,dy].')
    result = tuple(_int(x) for x in value)
    _need(result[0] in groups, 'Attachment group is outside the frozen model.')
    return result


def _groups(model):
    result, descriptors = {}, set()
    for row in model['groups']:
        gid, sign = _int(row['id']), _int(row['sign'])
        p = tuple(_int(v) for v in row['permutation'])
        _need(len(p) == 3 and set(p) == {0, 1, 2} and sign in (-1, 1), 'Invalid signed permutation.')
        _need(gid not in result and (sign, p) not in descriptors, 'Duplicate group descriptor.')
        descriptors.add((sign, p))
        ex, ey = (1, 0, -1), (0, 1, -1)
        expected = ((sign * ex[p[0]], sign * ey[p[0]]),
                    (sign * ex[p[1]], sign * ey[p[1]]))
        matrix = tuple(tuple(_int(v) for v in r) for r in row['matrix'])
        _need(matrix == expected, 'Matrix does not represent the stated A2 point action.')
        inverse = tuple(p.index(i) for i in range(3))
        parity = -1 if sum(p[i] > p[j] for i in range(3) for j in range(i + 1, 3)) % 2 else 1
        result[gid] = dict(matrix=matrix, permutation=p, inverse=inverse, parity=parity, sign=sign)
    _need(len(result) == 12 and set(result) == set(range(12)), 'Complete twelve-element group required.')
    _need(result[0]['matrix'] == ((1, 0), (0, 1)) and result[0]['permutation'] == (0, 1, 2),
          'Fixed rooted group0 must be the identity.')
    return result


def _move(point, group, dx=0, dy=0):
    x, y = point
    a, b = group['matrix']
    return a[0] * x + a[1] * y + dx, b[0] * x + b[1] * y + dy


def _marking_sha(snapshot):
    return digest(dict(source_model_sha256=snapshot['source_model_sha256'],
                       selected_halo=snapshot['selected_halo'],
                       prototype_points=snapshot['prototype_points'], transform=TRANSFORM))


class SignedUF:
    """value[i] = sign[i] * value[parent[i]]; odd signed cycles force zero."""
    def __init__(self, size):
        _need(type(size) is int and size >= 0, 'Nonnegative UF size required.')
        self.parent = list(range(size))
        self.sign = [1] * size
        self.size = [1] * size
        self.zero = [False] * size
        self.equality_calls = 0
        self.odd_cycle_zero_events = 0

    def find(self, index):
        parent = self.parent[index]
        if parent == index:
            return index, 1
        root, sign = self.find(parent)
        self.sign[index] *= sign
        self.parent[index] = root
        return root, self.sign[index]

    def equal(self, a, b, relation=1):
        """Impose value[a] = relation * value[b]."""
        _need(type(relation) is int and relation in (-1, 1), 'Signed relation required.')
        _need(type(a) is int and type(b) is int and 0 <= a < len(self.parent) and 0 <= b < len(self.parent),
              'UF indices outside range.')
        self.equality_calls += 1
        ra, sa = self.find(a)
        rb, sb = self.find(b)
        if ra == rb:
            if sa != relation * sb and not self.zero[ra]:
                self.zero[ra] = True
                self.odd_cycle_zero_events += 1
            return
        link = relation * sb * sa
        if self.size[ra] < self.size[rb]:
            self.parent[ra], self.sign[ra] = rb, link
            self.size[rb] += self.size[ra]
            self.zero[rb] = self.zero[ra] or self.zero[rb]
        else:
            self.parent[rb], self.sign[rb] = ra, link
            self.size[ra] += self.size[rb]
            self.zero[ra] = self.zero[ra] or self.zero[rb]

    def values(self):
        # Give each nonzero class a distinct absolute integer, anchored positive
        # at its least variable index. This makes names independent of UF roots.
        found = [self.find(i) for i in range(len(self.parent))]
        anchors = {}
        for i, (root, sign) in enumerate(found):
            if root not in anchors:
                anchors[root] = (i, sign)
        base = {root: 0 if self.zero[root] else sign * (i + 1)
                for root, (i, sign) in anchors.items()}
        return [sign * base[root] for root, sign in found]


class _Halo:
    def __init__(self, original, radius, groups):
        support, frontier = set(original), set(original)
        for _ in range(radius):
            layer = {(x + dx, y + dy) for x, y in frontier for dx, dy in STEPS} - support
            support.update(layer)
            frontier = layer
        self.radius, self.groups = radius, groups
        self.points = sorted(support)
        self.point_index = {p: i for i, p in enumerate(self.points)}
        self.uf = SignedUF(3 * len(self.points))
        self.pair_cache = {}

    def overlaps(self, attachment):
        if attachment not in self.pair_cache:
            gid, dx, dy = attachment
            group, pairs = self.groups[gid], []
            for j, q in enumerate(self.points):
                p = _move(q, group, dx, dy)
                if p not in self.point_index:
                    continue
                for world_channel in range(3):
                    a = 3 * self.point_index[p] + world_channel
                    # Source channel moves to inverse[source]; invert that map
                    # to read the source variable for this world channel.
                    b = 3 * j + group['permutation'][world_channel]
                    pairs.append((a, b, group['parity']))
            self.pair_cache[attachment] = tuple(pairs)
        return self.pair_cache[attachment]

    def positive(self, attachment):
        for a, b, sign in self.overlaps(attachment):
            self.uf.equal(a, b, sign)

    def compatible(self, attachment, values):
        return all(values[a] == sign * values[b] for a, b, sign in self.overlaps(attachment))

    def rows(self, values):
        return [[x, y, c, values[3 * i + c]] for i, (x, y) in enumerate(self.points) for c in range(3)]

    def score(self, labels, values):
        positives = negatives = positive_correct = negative_correct = unknowns = 0
        for attachment, status in labels.items():
            if status == 'UNKNOWN':
                unknowns += 1
                continue
            agreement = self.compatible(attachment, values)
            if status == 'POSITIVE':
                positives += 1
                positive_correct += agreement
            else:
                negatives += 1
                negative_correct += not agreement
        roots = {self.uf.find(i)[0] for i in range(len(values))}
        return dict(halo=self.radius, support_points=len(self.points),
            assigned_components=len(values), absent_components=0,
            zero_components=sum(v == 0 for v in values), signed_classes=len(roots),
            zero_classes=sum(self.uf.zero[r] for r in roots),
            positive_total=positives, positive_correct=positive_correct,
            negative_total=negatives, negative_correct=negative_correct,
            unknown_total=unknowns, total_correct=positive_correct + negative_correct,
            equalities=self.uf.equality_calls, odd_cycle_zero_events=self.uf.odd_cycle_zero_events)


class Trainer:
    """Incremental no-holdout synthesis; snapshots never install themselves."""
    def __init__(self, model, expected_catalogue_size=304):
        _need(type(model) is dict and model.get('initial_markings') == [], 'Fresh unmarked input required.')
        _need(type(expected_catalogue_size) is int and expected_catalogue_size > 0, 'Positive expected catalogue size required.')
        self.source_hash = digest(model)
        self.groups = _groups(model)
        _need(model['polygon'][0] == [0, 0], 'Prototype first vertex must be normalized to zero.')
        original = set()
        for row in model['original_field']:
            _need(type(row) is list and len(row) == 3, 'Original point field triples required.')
            x, y, units = [_int(v) for v in row]
            _need(0 < units <= 12 and (x, y) not in original, 'Distinct positive original point support required.')
            original.add((x, y))
        _need(bool(original), 'Original support is empty.')
        self.original_count = len(original)
        self.expected_catalogue_size = expected_catalogue_size
        self.halos = [_Halo(original, h, self.groups) for h in (1, 2, 3)]
        self.labels, self.calls, self.history = {}, 0, []

    def add(self, attachment, status):
        """Add POSITIVE/NEGATIVE/UNKNOWN. Only positive labels add equalities.

        UNKNOWN may later resolve. Resolved labels cannot change or revert;
        scientific corrections require a fresh Trainer and explicit replay.
        """
        key = _attachment(attachment, self.groups)
        _need(type(status) is str and status in ('POSITIVE', 'NEGATIVE', 'UNKNOWN'), 'Explicit corona label required.')
        old = self.labels.get(key)
        _need(old is None or old == 'UNKNOWN' or old == status, 'A resolved label changed; replay a fresh learner.')
        if old != status:
            if status == 'POSITIVE':
                for halo in self.halos:
                    halo.positive(key)
            self.labels[key] = status
        self.calls += 1
        self.history.append(dict(call=self.calls, attachment=list(key), previous=old, status=status))
        return self.summary()

    def _states(self):
        states = []
        for halo in self.halos:
            values = halo.uf.values()
            states.append((halo, values, halo.score(self.labels, values)))
        best = min(states, key=lambda state: (-state[2]['total_correct'], state[0].radius))
        return states, best

    def summary(self):
        states, best = self._states()
        return dict(schema='Turtle-signed-UF-progress-v1', received_calls=self.calls,
            classified_pairs=len(self.labels), resolved_pairs=sum(s != 'UNKNOWN' for s in self.labels.values()),
            selected_halo=best[0].radius, selection='Maximum total correct resolved labels, then smaller halo.',
            halos=[s[2] for s in states], activation='NOT_ACTIVATED_INDEPENDENT_REPLAY_REQUIRED')

    def snapshot(self):
        states, best = self._states()
        selected, values, score = best
        result = dict(schema='Turtle-signed-UF-marking-model-v1', version=VERSION,
            source_model_sha256=self.source_hash, received_calls=self.calls,
            expected_catalogue_size=self.expected_catalogue_size,
            root_attachment=[0, 0, 0], original_support_points=self.original_count,
            selected_halo=selected.radius, prototype_points=selected.rows(values),
            absence_token=ABSENT, missing_is_unconstrained=True, zero_is_assigned=True,
            transform=dict(TRANSFORM), selection='Maximum correct resolved labels; smaller halo breaks ties.',
            score=score, halos=[s[2] for s in states],
            candidates=[dict(halo=h.radius, prototype_points=h.rows(v), score=s) for h, v, s in states],
            classifications=[dict(attachment=list(k), status=s) for k, s in sorted(self.labels.items())],
            label_history=[dict(h, attachment=list(h['attachment'])) for h in self.history],
            activation='NOT_ACTIVATED_INDEPENDENT_REPLAY_REQUIRED',
            scope='Finite learned restriction fitted to resolved unmarked corona labels. No holdout, known marking, global redundancy, arbitrary extension or plane-tiling claim. Provisional values may change until frozen.')
        result['marking_sha256'] = _marking_sha(result)
        return result

    def activation_gate(self, catalogue, replay=None):
        """Bookkeeping gate; trusts only an externally independent replay receipt.

        replay={status:'VERIFIED',catalogue_complete:true,catalogue_sha256:...,
        marking_sha256:...,pairs:[{attachment:[g,dx,dy],compatible:bool},...]}
        The caller separately certifies that catalogue is the complete unmarked
        contact universe; mere cardinality304 is never a completeness proof.
        """
        keys = [_attachment(a, self.groups) for a in catalogue]
        canonical = sorted(keys)
        catalogue_hash = digest([list(k) for k in canonical])
        snapshot = self.snapshot()
        failures = []
        if len(keys) != self.expected_catalogue_size or len(set(keys)) != len(keys):
            failures.append('CATALOGUE_SIZE_OR_DUPLICATES')
        if set(keys) != set(self.labels):
            failures.append('LABELS_DO_NOT_EQUAL_DECLARED_CATALOGUE')
        if any(s == 'UNKNOWN' for s in self.labels.values()):
            failures.append('UNRESOLVED_CLASSIFICATIONS')
        bound = (type(replay) is dict and replay.get('status') == 'VERIFIED'
                 and replay.get('catalogue_complete') is True
                 and replay.get('catalogue_sha256') == catalogue_hash
                 and replay.get('marking_sha256') == snapshot['marking_sha256'])
        actual = {}
        if not bound:
            failures.append('INDEPENDENT_REPLAY_MISSING_OR_NOT_BOUND')
        else:
            for row in replay.get('pairs', []):
                k = _attachment(row['attachment'], self.groups)
                _need(type(row['compatible']) is bool and k not in actual, 'Independent replay needs unique boolean pair results.')
                actual[k] = row['compatible']
            if set(actual) != set(keys):
                failures.append('INDEPENDENT_REPLAY_INCOMPLETE')
        positive_total = sum(s == 'POSITIVE' for s in self.labels.values())
        negative_total = sum(s == 'NEGATIVE' for s in self.labels.values())
        positive_correct = sum(s == 'POSITIVE' and actual.get(k) is True for k, s in self.labels.items())
        negative_correct = sum(s == 'NEGATIVE' and actual.get(k) is False for k, s in self.labels.items())
        if positive_correct != positive_total:
            failures.append('NOT_ALL_POSITIVES_ACCEPTED')
        if negative_total and 2 * negative_correct <= negative_total:
            failures.append('NOT_STRICT_MAJORITY_NEGATIVES_REJECTED')
        halo = next(h for h in self.halos if h.radius == snapshot['selected_halo'])
        values = halo.uf.values()
        if any(k in actual and actual[k] != halo.compatible(k, values) for k in self.labels):
            failures.append('INTERNAL_AND_INDEPENDENT_REPLAY_DISAGREE')
        return dict(schema='Turtle-marking-activation-gate-v1', ready=not failures,
            status='PASS_ACTIVATION_GATE' if not failures else 'NOT_READY', reasons=failures,
            marking_sha256=snapshot['marking_sha256'], catalogue_sha256=catalogue_hash,
            catalogue_size=len(keys), positive_total=positive_total, positive_correct=positive_correct,
            negative_total=negative_total, negative_correct=negative_correct,
            scope='No model is installed here. Passing is a finite classification/replay gate, not a proof of redundant pruning, infinite growth or plane tiling.')


def marking_orientations(snapshot, model):
    """Export assigned rows only, as [{id,points:[[x,y,channel,value],...]}].

    Individual '*' is absent and is omitted. Assigned zero remains a literal
    value. Prototype rows retain '*' explicitly for future sparse models.
    """
    _need(snapshot['source_model_sha256'] == digest(model), 'Marking/model binding differs.')
    _need(snapshot.get('transform') == TRANSFORM, 'Marking transform declaration differs.')
    _need(snapshot.get('marking_sha256') == _marking_sha(snapshot), 'Marking fingerprint differs.')
    groups = _groups(model)
    rows, seen = [], set()
    for row in snapshot['prototype_points']:
        _need(type(row) is list and len(row) == 4, 'Prototype component row required.')
        x, y, channel = [_int(v) for v in row[:3]]
        value = row[3]
        _need(0 <= channel < 3 and (x, y, channel) not in seen, 'Unique rank-three component required.')
        _need(type(value) is int or type(value) is str and value == ABSENT, 'Scalar int or individual absence required.')
        seen.add((x, y, channel))
        if value != ABSENT:
            rows.append((x, y, channel, value))
    result = []
    for gid, group in sorted(groups.items()):
        oriented = []
        for x, y, source_channel, value in rows:
            a, b = _move((x, y), group)
            oriented.append([a, b, group['inverse'][source_channel], group['parity'] * value])
        oriented.sort()
        result.append(dict(id=gid, points=oriented))
    return result
