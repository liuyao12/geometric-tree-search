"""Prospective exact unmarked Turtle corona study; data-only parent reuse."""
import gzip
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import resource
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
PARENT=ROOT.parent/'gcts-turtle-reentry-20261103-v1'
def wire(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def pin(p):
    b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(wire(v))
def load(p):return json.loads(p.read_text())
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def material(model,c):
    o=next(o for o in model['orientations'] if o['id']==c[0]);return [(x+c[1],y+c[2],u) for x,y,u in o['points']]
def core(model,placements):return sorted({(x,y) for c in placements for x,y,u in material(model,c)})
def synthetic(rows,marks=None):
    m=dict(capacity=12,orientations=[dict(id=i,points=r) for i,r in enumerate(rows)],allowed_placements=[[i,0,0] for i in range(len(rows))])
    if marks:m['marking_orientations']=[dict(id=i,points=r) for i,r in marks.items()]
    return m

def fixtures():
    rows=[]
    def add(name,m,seeds,target,status,grow=True,**kw):rows.append(dict(name=name,model=m,seeds=seeds,core=target,expected=status,grow=grow,**kw))
    m=synthetic([[[0,0,12]]]);add('dead-before-forced',m,[],[[0,0],[1,0]],'NEGATIVE')
    m=synthetic([[[0,0,6],[1,0,6]],[[0,0,6],[1,0,6]]]);add('shared-fractional',m,[[0,0,0]],[[0,0],[1,0]],'POSITIVE')
    m=synthetic([[[0,0,4]],[[0,0,4]]]);add('singleton-residual',m,[[0,0,0]],[[0,0]],'NEGATIVE')
    m=synthetic([[[0,0,12],[10,0,6]]]);add('zero-root-new-support-dead',m,[],[[0,0]],'NEGATIVE');add('finite-target-control',m,[],[[0,0]],'POSITIVE',False)
    m=synthetic([[[0,0,12],[1,0,6]],[[1,0,6]]]);add('checkpoint-before-forced',m,[[0,0,0]],[[0,0]],'POSITIVE')
    m=synthetic([[[0,0,12],[1,0,6]]]);add('dead-before-checkpoint',m,[[0,0,0]],[[0,0]],'NEGATIVE')
    m=synthetic([[[0,0,4]],[[0,0,4]],[[0,0,4]]]);add('node-cutoff',m,[[0,0,0]],[[0,0]],'UNKNOWN',False,node_limit=1);add('depth-cutoff',m,[[0,0,0]],[[0,0]],'UNKNOWN',False,depth_limit=0);add('time-cutoff',m,[[0,0,0]],[[0,0]],'UNKNOWN',False,seconds=0)
    m=synthetic([[[0,0,4]],[[0,0,4]],[[0,0,8]],[[0,0,4]]]);add('unknown-child-later-positive',m,[[0,0,0]],[[0,0]],'POSITIVE',False,depth_limit=1)
    m=synthetic([[[0,0,6],[1,0,6]],[[0,0,6],[1,0,6]],[[2,0,12]],[[0,0,6],[1,0,6]],[[3,0,12]]],{1:[[100,100,'far',1]],2:[[100,100,'far',0]],4:[[100,100,'far',0]]})
    add('mark-only-dependency-and-reference-count',m,[[0,0,0]],[[0,0],[1,0],[2,0],[3,0]],'POSITIVE',False)
    return rows

def freeze():
    started=time.perf_counter();ref=ROOT/'reference';ref.mkdir(parents=True,exist_ok=True)
    for old,new in [('data/exact-point-model-v1.json','input-point-model-v1.json'),('data/results-v1.json.gz','input-pair-qualification-v1.json.gz'),('publication/live-complete-v1.json','parent-live-complete-v1.json')]:shutil.copyfile(PARENT/old,ref/new)
    parent=load(ref/'input-point-model-v1.json');orient=[]
    for g in parent['groups']:
        a,b=g['matrix'][0];c,d=g['matrix'][1]
        orient.append(dict(id=g['id'],points=sorted([[a*x+b*y,c*x+d*y,u] for x,y,u in parent['original_field']])))
    model=dict(capacity=12,orientations=orient,marking_orientations=[])
    root={(x,y):u for x,y,u in material(model,[0,0,0])};pairs=set()
    for o in orient:
        for x,y,u in o['points']:
            for px,py in root:
                c=o['id'],px-x,py-y
                if c==(0,0,0):continue
                if all(root.get((qx,qy),0)+v<=12 for qx,qy,v in material(model,c)):pairs.add(c)
    pairs=sorted(pairs);assert len(pairs)==304
    with gzip.open(ref/'input-pair-qualification-v1.json.gz','rt') as f:old=json.load(f)
    expected=sorted(tuple([p['group'],*p['translation']]) for p in old['pairs'] if p['original_capacity_legal'] and p['common_original_support']>0)
    assert pairs==expected
    save(ROOT/'data/point-model-v1.json',model);save(ROOT/'data/contact-catalogue-v1.json',[list(p) for p in pairs]);save(ROOT/'data/qualification-fixtures-v1.json',fixtures())
    paths=sorted([p for d in ('source','reference') for p in (ROOT/d).rglob('*') if p.is_file()])+[ROOT/'data'/n for n in ('point-model-v1.json','contact-catalogue-v1.json','qualification-fixtures-v1.json')]
    protocol=dict(schema='Turtle-unmarked-corona-protocol-v1',source_pins={str(p.relative_to(ROOT)):pin(p) for p in paths},pairs=len(pairs),node_limit=1000,seconds_per_case=3,depth_limit=128,cohort_seconds_limit=900,order='lexicographic full candidate identity after reference point scheduler',core='union fixed pair positive t-support',activation='all seed and new positive support; no fair untouched-plane claim',stopping='global dead first; corefull+allfrontierviable checkpoint; globalforced; earliestgeneration/degree/coordinate branch',negative='complete finite search certificate with no unresolved child; all cutoff kinds UNKNOWN',audit_indices=[0,151,303],marking='fresh signed equalities after every independently certified label; every resolved pair used, no holdout; no known marking input; strict fullcatalogue activation gate',marked_followup='only after gate, first eight independently positive pairs by frozen catalogue order; same search limits/core/scheduler; restricted learned model only',RL='No RL training or macro execution in this milestone; discovered corona clusters retained for later use',preparation_seconds=time.perf_counter()-started)
    save(ROOT/'data/protocol-frozen-v1.json',protocol);print(json.dumps(dict(status='FROZEN',pairs=len(pairs),pins=len(paths),preparation_seconds=protocol['preparation_seconds'])),flush=True)

def qualification(E,V,L):
    output=[]
    def check(model,e,label):
        snapshot=e.snapshot();receipt=V.check_snapshot(model,snapshot);assert receipt['status']=='VERIFIED',(label,receipt)
        output.append(dict(name=label,snapshot=snapshot,check=receipt));return snapshot
    for f in load(ROOT/'data/qualification-fixtures-v1.json'):
        kwargs={k:f[k] for k in ('node_limit','depth_limit','seconds') if k in f}
        kwargs.setdefault('seconds',30)
        r=E.search(f['model'],f['seeds'],f['core'],grow=f['grow'],audit=True,**kwargs)
        assert r['status']==f['expected'],(f['name'],r['status'])
        receipt=V.check_tree(f['model'],r);assert receipt['status']=='VERIFIED',(f['name'],receipt)
        for s in r['audit_snapshots']:assert V.check_snapshot(f['model'],s)['status']=='VERIFIED'
        assert all(p['before']==p['restored'] for p in r['rollback_checks'])
        brute=None
        if not f['grow'] and f['name'] not in ('node-cutoff','depth-cutoff','time-cutoff'):
            allowed=[p for p in f['model']['allowed_placements'] if p not in f['seeds']];solutions=[]
            for mask in range(1<<len(allowed)):
                p=f['seeds']+[c for i,c in enumerate(allowed) if mask>>i&1]
                if V.check_patch(f['model'],p,f['core'],grow=False)['status']=='VERIFIED':solutions.append(p)
            brute=dict(subsets=1<<len(allowed),solutions=len(solutions));assert bool(solutions)==(r['status']=='POSITIVE')
        output.append(dict(name=f['name'],search=r,tree_check=receipt,independent_exhaustive=brute))
    # Actual legal incremental states, not fabricated generation metadata.
    for late_fillers in (1,2):
        m=synthetic([[[0,0,6],[10,0,6]],[[10,0,6],[20,0,6]]]+[[[20,0,6]]]*late_fillers+[[[0,0,6]]]*3)
        e=E.Engine(m,[[0,0,0]],[[0,0]]);check(m,e,'priority-seed');e.place((1,0,0));s=check(m,e,'late-forced' if late_fillers==1 else 'generation-before-degree')
        assert s['decision']['kind']==('forced' if late_fillers==1 else 'branch')
        assert s['decision']['point']==([20,0] if late_fillers==1 else [0,0])
    m=dict(capacity=12,orientations=[dict(id=0,points=[[0,0,1],[1,0,1]]),dict(id=1,points=[[0,0,1],[5,0,1]]),dict(id=2,points=[[0,0,1]])],allowed_placements=[[2,0,0]]+[[0,i,0] for i in range(5)]+[[1,0,0]])
    e=E.Engine(m,[[2,0,0]],[[0,0]])
    for i in range(5):e.place((0,i,0));check(m,e,'legal-generation-chain-'+str(i))
    assert e.gen[5,0]==5;before=check(m,e,'before-generation-lowering');digest=e.logical_digest();mark=len(e.trail);e.place((1,0,0));assert e.gen[5,0]==1;check(m,e,'after-generation-lowering');e.rollback(mark);assert e.gen[5,0]==5 and e.logical_digest()==digest
    after=check(m,e,'restored-generation-five');assert V.check_rollback(before,after)['status']=='VERIFIED'
    # Distant mark-only invalidation, shared edges, compatible reference counts, exact undo.
    f=next(f for f in fixtures() if f['name']=='mark-only-dependency-and-reference-count');m=f['model'];e=E.Engine(m,f['seeds'],f['core'],grow=False)
    before=check(m,e,'before-distant-mark');digest=e.logical_digest();mark=len(e.trail);assert (1,0,0) in e.domains[0,0] and (1,0,0) in e.domains[1,0]
    e.place((2,0,0));assert (1,0,0) not in e.domains[0,0] and (1,0,0) not in e.domains[1,0];check(m,e,'after-distant-zero-mark');e.place((4,0,0));assert list(e.M.values())[0][1]==2;check(m,e,'mark-reference-two');e.rollback(mark);assert not e.M and e.logical_digest()==digest;after=check(m,e,'restored-no-mark');assert V.check_rollback(before,after)['status']=='VERIFIED'
    # Corruptions must be rejected by the independent checker.
    corrupt=json.loads(wire(before));corrupt['edge_units'][0][-1]+=1;assert V.check_snapshot(m,corrupt)['status']=='REJECTED'
    links=[(i,j,s) for i in range(3) for j in range(i+1,3) for s in (-1,1)]
    for mask in range(1<<len(links)):
        relations=[r for i,r in enumerate(links) if mask>>i&1];uf=L.SignedUF(3)
        for a,b,s in relations:uf.equal(a,b,s)
        values=uf.values();solutions=[v for v in itertools.product((-1,0,1),repeat=3) if all(v[a]==s*v[b] for a,b,s in relations)]
        assert all(values[a]==s*values[b] for a,b,s in relations)
        assert all((values[i]==0)==all(v[i]==0 for v in solutions) for i in range(3))
    save(ROOT/'data/engine-qualification-v1.json',dict(status='PASS',records=output,wrong_edge_units_rejected=True,signed_UF_exhaustive_constraint_systems=64,assignments_examined=1728));return dict(status='PASS',records=len(output),signed_UF_systems=64)

def run():
    protocol=load(ROOT/'data/protocol-frozen-v1.json')
    for path,p in protocol['source_pins'].items():assert pin(ROOT/path)==p,path
    E=module('exact_point_engine',ROOT/'source/point_engine_v1.py');V=module('independent_point_checker',ROOT/'reference/independent_checker_v1.py');L=module('fresh_marking_learner',ROOT/'source/marking_learner_v1.py')
    start=time.perf_counter();q=qualification(E,V,L);print(json.dumps(dict(phase='QUALIFICATION',**q)),flush=True)
    model=load(ROOT/'data/point-model-v1.json');catalogue=load(ROOT/'data/contact-catalogue-v1.json');original=load(ROOT/'reference/input-point-model-v1.json');trainer=L.Trainer(original)
    rows=[];history=[];cohort=time.perf_counter()
    for i,attachment in enumerate(catalogue):
        seeds=[[0,0,0],attachment];target=[list(p) for p in core(model,seeds)]
        if time.perf_counter()-cohort>protocol['cohort_seconds_limit']:
            rows.append(dict(index=i,attachment=attachment,status='UNKNOWN',reason='COHORT_LIMIT_NOT_RUN'));history.append(trainer.add(attachment,'UNKNOWN'));continue
        r=E.search(model,seeds,target,node_limit=protocol['node_limit'],seconds=protocol['seconds_per_case'],depth_limit=protocol['depth_limit'],audit=i in protocol['audit_indices'])
        raw_path=ROOT/('data/raw/case-%03d.json.gz'%i);raw_path.parent.mkdir(parents=True,exist_ok=True)
        with gzip.open(raw_path,'wb') as f:f.write(wire(r))
        assurance=time.perf_counter();tree=V.check_tree(model,r)
        for snapshot in r['audit_snapshots']:assert V.check_snapshot(model,snapshot)['status']=='VERIFIED'
        patch=V.check_patch(model,r['placements'],target) if r['status']=='POSITIVE' else None
        certified=r['status'] if tree['status']=='VERIFIED' and (patch is None or patch['status']=='VERIFIED') else 'UNKNOWN'
        row=dict(index=i,attachment=attachment,status=certified,search=r,tree_check=tree,patch_check=patch,assurance_seconds=time.perf_counter()-assurance);rows.append(row)
        t=time.perf_counter();update=trainer.add(attachment,certified);view=trainer.snapshot()
        history.append(dict(index=i,seconds=time.perf_counter()-t,update=update,selected_snapshot={k:view[k] for k in ('selected_halo','marking_sha256','prototype_points','score')}))
        print(json.dumps(dict(index=i,pair=attachment,status=certified,raw=r['status'],nodes=r['stats']['visits'],tiles=len(r['placements']),search_seconds=r['seconds'],assurance_seconds=row['assurance_seconds'])),flush=True)
        with gzip.open(ROOT/'data/checkpoint-v1.json.gz','wb') as f:f.write(wire(dict(rows=rows,history=history)))
    learned=trainer.snapshot();export=L.marking_orientations(learned,original);marked={**model,'marking_orientations':export}
    replay=[]
    for attachment in catalogue:
        receipt=V.check_patch(marked,[[0,0,0],attachment],[],grow=False)
        assert receipt['status'] in ('VERIFIED','REJECTED')
        replay.append(dict(attachment=attachment,compatible=receipt['status']=='VERIFIED',receipt=receipt))
    replay_packet=dict(status='VERIFIED',catalogue_complete=True,catalogue_sha256=L.digest(sorted(catalogue)),marking_sha256=learned['marking_sha256'],pairs=replay)
    gate=trainer.activation_gate(catalogue,replay_packet);follow=[]
    if gate.get('ready',False):
        for row in [r for r in rows if r['status']=='POSITIVE'][:8]:
            seeds=[[0,0,0],row['attachment']];target=row['search']['core'];r=E.search(marked,seeds,target,node_limit=protocol['node_limit'],seconds=protocol['seconds_per_case'],depth_limit=protocol['depth_limit'])
            raw_path=ROOT/('data/raw/marked-case-%03d.json.gz'%row['index'])
            with gzip.open(raw_path,'wb') as f:f.write(wire(r))
            receipt=V.check_tree(marked,r);patch=V.check_patch(marked,r['placements'],target) if r['status']=='POSITIVE' else None
            follow.append(dict(index=row['index'],search=r,tree_check=receipt,patch_check=patch));assert receipt['status']=='VERIFIED' and (patch is None or patch['status']=='VERIFIED')
    for path,p in protocol['source_pins'].items():assert pin(ROOT/path)==p,path
    result=dict(schema='Turtle-fresh-corona-and-marking-v1',status='COMPLETE_COHORT',protocol=protocol,model=model,catalogue=catalogue,rows=rows,learning_history=history,learned_marking=learned,marked_model=marked,independent_pair_replay=replay_packet,activation_gate=gate,marked_followup=follow,qualification=q,total_seconds=time.perf_counter()-start,cohort_seconds=time.perf_counter()-cohort,peak_ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,rss_units='bytes on macOS',scope='Unmarked finite one-corona classifications and learned finite marking restriction. No RL, plane tiling or substitution result.')
    with gzip.open(ROOT/'data/results-v1.json.gz','wb') as f:f.write(wire(result))
    save(ROOT/'data/completion-v1.json',dict(status='COMPLETE',counts={s:sum(r['status']==s for r in rows) for s in ('POSITIVE','NEGATIVE','UNKNOWN')},gate=gate,total_seconds=result['total_seconds'],peak_ru_maxrss=result['peak_ru_maxrss']))
    print(json.dumps(load(ROOT/'data/completion-v1.json')),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='run':run()
    else:raise SystemExit('freeze | run')
