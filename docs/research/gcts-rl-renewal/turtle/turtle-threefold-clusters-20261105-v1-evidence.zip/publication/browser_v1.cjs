const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { chromium } = require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main() {
  const browser = await chromium.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: true,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({viewport:{width:1260,height:900}});
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const live=Boolean(process.argv[2]);
    const local=pathToFileURL(path.join(__dirname,"..","report","turtle-threefold-clusters-20261105-v1.html"));
    const response=await page.goto(process.argv[2] || local.href,{waitUntil:"load"});
    if (live) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===2);
    const test=await page.evaluate(()=>{
      const data=JSON.parse(document.querySelector("#figure-data").textContent);
      const view=document.querySelector("#patch-view");
      const [patch,rule,layer]=["patch","rule","layer"].map(id=>document.getElementById(id));
      const controls=[patch,rule,layer];
      const original=controls.map(control=>control.value);
      let states=0;
      for (const p of patch.options) {
        for (const r of rule.options) {
          for (const l of layer.options) {
            [patch.value,rule.value,layer.value]=[p.value,r.value,l.value];
            layer.dispatchEvent(new Event("change"));
            const source=data.patches[p.value];
            const expected=l.value==="2"?source.rules[r.value].groups.length:0;
            if (view.querySelectorAll("polygon").length!==source.polygons.length ||
                view.querySelectorAll("circle").length!==expected ||
                view.querySelectorAll("line").length!==3*expected)
              throw new Error("Wrong geometry or markings for "+[p.value,r.value,l.value]);
            states++;
          }
        }
      }
      controls.forEach((control,i)=>{control.value=original[i];});
      layer.dispatchEvent(new Event("change"));
      const conflict=document.querySelector("#collision-view");
      return {states, math:document.querySelectorAll("mjx-container").length,
        conflict_tiles:conflict.querySelectorAll("polygon").length,
        shared:conflict.querySelectorAll('polygon[fill="#703b82"]').length,
        conflict_marks:conflict.querySelectorAll("circle").length,
        initial_core:data.patches[patch.value].rules[rule.value].counts.core};
    });
    assert.deepEqual(errors,[]);
    assert.deepEqual(test,{states:36,math:2,conflict_tiles:118,shared:2,conflict_marks:2,initial_core:1});
    if (!live) {
      await page.locator("#viewer").screenshot({path:path.join(__dirname,"browser-v1.png")});
      await page.locator("#collision-view").screenshot({path:path.join(__dirname,"collision-browser-v1.png")});
    }
    await page.setViewportSize({width:390,height:844});
    const fits=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert(fits);
    const result={status:"CHECKED_INTERACTIVE_THREEFOLD_READER", ...test, mobile_no_overflow:fits};
    fs.writeFileSync(path.join(__dirname,live?"live-browser-v1.json":"browser-v1.json"),
      JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
