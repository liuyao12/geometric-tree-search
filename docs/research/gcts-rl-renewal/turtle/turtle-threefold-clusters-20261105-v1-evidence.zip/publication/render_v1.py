"""Render the checked second-scale Turtle study and its interactive reader."""

from collections import Counter
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
from cluster_v1 import Model, pin

STEM = "turtle-threefold-clusters-20261105-v1"
OLD = "turtle-shell-receptors-20261105-v1.html"


def read(name):
    return json.loads((ROOT/name).read_bytes())


def write(name, data):
    with (ROOT/"report"/name).open("x") as stream:
        stream.write(data)


def project(x, y):
    return round(x+y/2, 3), round(-sqrt(3)*y/2, 3)


def diagrams(model, results, closure, holdout, conflict):
    bank = {str(r["root"]): r for r in closure}
    fresh = {str(r["root"]): r for r in holdout}
    cases = [("original-123", "Original patch 123", bank["123"])]
    cases.extend((f"deep-{k}", f"Depth-ten patch {k}", r) for k, r in fresh.items())
    images = {}
    for key, name, patch in cases:
        tiles = patch["checked"]["placement_set"]
        positions = {tuple(p): i for i, p in enumerate(tiles)}
        layer_data = {}
        for rule in results:
            zone = rule["original"] if key.startswith("original") else rule["holdout"]
            record, = [r for r in zone if r["root"] == patch["root"]]
            parts = {tuple(p): (kind, [positions[tuple(q)] for q in shapes])
                     for p, kind, shapes in record["parts"]}
            colors = [None]*len(tiles)
            for kind, component in parts.values():
                for i in component:
                    assert colors[i] is None
                    colors[i] = kind
            groups = []
            for motif in record["motifs"]:
                kind = motif["kind"]
                groups.append(dict(kind=kind, components=[parts[tuple(p)][1] for p in motif["family"]]))
            layer_data[rule["omitted"]] = dict(colors=colors, groups=groups,
                                              counts=dict(Counter(m["kind"] for m in groups)))
        images[key] = dict(label=name, polygons=polys(model, tiles), rules=layer_data)
    local = conflict["checks"][0]["placement_set"]
    index = {tuple(p): i for i, p in enumerate(local)}
    source = next(r for r in results if r["omitted"] == 1)
    catalogue = next(c for c in source["certificates"] if c["kind"] == "pair")
    ids = map(int, conflict["case"].split("/"))
    motifs = [[[index[tuple(p)] for p in part] for part in catalogue["motifs"][i]["motif"]] for i in ids]
    assert len(set(sum(motifs[0], [])) & set(sum(motifs[1], []))) == 2
    return dict(patches=images, conflict=dict(polygons=polys(model, local), motifs=motifs))


def polys(model, tiles):
    return [[project(x, y) for x, y in model.poly(tuple(p))] for p in tiles]


STYLE = """
*{box-sizing:border-box} body{margin:0;background:#f4f5ef;color:#172d29;
font-family:system-ui,-apple-system,sans-serif;line-height:1.55}
main{max-width:1040px;margin:auto;padding:2rem clamp(1rem,4vw,3.4rem) 4rem}
header{padding:1.8rem 0 1rem;border-bottom:1px solid #bccdc3} h1,h2{font-family:Georgia,serif;
line-height:1.1} h1{font-size:clamp(2.35rem,7vw,4.35rem);max-width:16ch;margin:.2em 0}
h2{font-size:clamp(1.65rem,4vw,2.4rem)} p{max-width:74ch} a{color:#1b5547}
.eyebrow{font-size:.79rem;font-weight:750;letter-spacing:.11em;text-transform:uppercase}
nav ul,.legend{list-style:none;padding:0;display:flex;gap:.6rem 1.2rem;flex-wrap:wrap}
section{margin-top:2.55rem} .frame{background:#fffefa;border:1px solid #c6d4c9;
border-radius:.85rem;padding:1rem} figure{margin:0} svg{display:block;width:100%;
height:auto;max-height:550px;background:#fafbf7;border-radius:.55rem}
.controls{display:flex;gap:.6rem 1.25rem;flex-wrap:wrap;margin-bottom:1rem}
.controls label{display:grid;gap:.2rem;font-size:.88rem;font-weight:650} select{color:inherit;
background:white;border:1px solid #829d90;border-radius:.35rem;padding:.42rem;font:inherit;max-width:100%}
figcaption{font-size:.92rem;margin-top:.65rem} .legend{margin-bottom:0} .swatch{display:inline-block;
width:.8rem;height:.8rem;border-radius:.2rem;vertical-align:baseline;margin-right:.25rem}
.scroll{overflow:auto} table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
th,td{padding:.6rem .7rem;border-bottom:1px solid #c6d4c9;text-align:left}
thead th{background:#e2ebe3} .callout{border-left:4px solid #2a6e60;padding:.4rem 1rem;background:#e4efe7}
code{font-size:.88em;overflow-wrap:anywhere} .links li{margin:.35rem 0}
@media(max-width:520px){main{padding-top:.75rem}.controls label{flex:1 1 42%}.frame{padding:.65rem}
th,td{padding:.4rem;font-size:.86rem}}
"""


SCRIPT = r"""
const source = JSON.parse(document.getElementById("figure-data").textContent);
const patch = document.getElementById("patch");
const rule = document.getElementById("rule");
const layer = document.getElementById("layer");
const view = document.getElementById("patch-view");
const detail = document.getElementById("patch-status");
const muted = {core:"#afd0c4", pair:"#efca95", single:"#d7c8e6"};
const strong = {core:"#28786a", pair:"#ac531c", single:"#7847a0"};
function shape(svg,tag,attrs) {
  const el=document.createElementNS("http://www.w3.org/2000/svg",tag);
  for (const [k,v] of Object.entries(attrs)) el.setAttribute(k,v);
  svg.append(el);
}
function average(points) {
  return [0,1].map(axis=>points.reduce((s,p)=>s+p[axis],0)/points.length);
}
function draw(svg,polygons,fill) {
  svg.replaceChildren();
  const points=polygons.flat();
  const lo=[0,1].map(i=>Math.min(...points.map(p=>p[i])));
  const hi=[0,1].map(i=>Math.max(...points.map(p=>p[i])));
  svg.setAttribute("viewBox",[lo[0]-3,lo[1]-3,hi[0]-lo[0]+6,hi[1]-lo[1]+6].join(" "));
  polygons.forEach((poly,i)=>shape(svg,"polygon",{points:poly.map(p=>p.join(",")).join(" "),
    fill:fill(i),stroke:"#445f56","stroke-width":".13","stroke-linejoin":"round"}));
}
function mark(svg,polygons,components,color) {
  const centers=components.map(group=>average(group.map(i=>average(polygons[i]))));
  const [x,y]=average(centers);
  for (const [a,b] of centers)
    shape(svg,"line",{x1:x,y1:y,x2:a,y2:b,stroke:color,"stroke-width":".49","stroke-linecap":"round"});
  shape(svg,"circle",{cx:x,cy:y,r:".65",fill:"white",stroke:color,"stroke-width":".29"});
}
function render() {
  const image=source.patches[patch.value];
  const markData=image.rules[rule.value];
  const highlights=new Map();
  if (layer.value==="2")
    markData.groups.forEach(g=>g.components.flat().forEach(i=>highlights.set(i,g.kind)));
  draw(view,image.polygons,i=>strong[highlights.get(i)] ||
    (layer.value!=="0" && muted[markData.colors[i]]) || "#e6ebe5");
  if (layer.value==="2")
    markData.groups.forEach(g=>mark(view,image.polygons,g.components,"#fffdf1"));
  const counts=["core","pair","single"].map(k=>`${markData.counts[k] || 0} ${k}`).join(", ");
  detail.textContent=`${image.polygons.length} Turtle placements. Threefold groups in the guarded interior: ${counts}.`;
}
for (const control of [patch,rule,layer]) control.addEventListener("change",render);
render();
const conflict=source.conflict;
const collisionView=document.getElementById("collision-view");
const [left,right]=conflict.motifs.map(g=>new Set(g.flat()));
draw(collisionView,conflict.polygons,i=>left.has(i) ? right.has(i) ? "#703b82" : "#cf793e" :
  right.has(i) ? "#3b9286" : "#edf0ea");
conflict.motifs.forEach(g=>mark(collisionView,conflict.polygons,g,"#fffcf4"));
"""


def render(summary, data):
    rule_rows = []
    shape_rows = []
    for rule in summary["study"]["rules"]:
        for bank in ("original", "holdout"):
            m = rule[bank]
            cells = [rule["omitted"], "Depth eight" if bank == "original" else "Depth ten",
                     m["patches"], *[m["motifs"].get(k, 0) for k in ("core", "pair", "single")]]
            rule_rows.append("<tr>"+"".join(f"<td>{n}</td>" for n in cells)+"</tr>")
        sizes = [k["observed_shapes"] for k in rule["local"]]
        shape_rows.append("<tr>"+"".join(f"<td>{n}</td>" for n in (rule["omitted"], *sizes))+"</tr>")
    patch_options = "".join(f'<option value="{key}"{" selected" if key=="deep-61" else ""}>'
                            f'{escape(p["label"])}</option>' for key,p in data["patches"].items())
    json_data = json.dumps(data, separators=(",", ":"), ensure_ascii=True).replace("<", r"\u003c")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Threefold clusters in the Turtle tiling</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · Turtle · November 2026</p>
<h1>Threefold clusters in the Turtle tiling</h1>
<p>Cluster three first-layer pieces when they touch pairwise and a single turn of \(120^\circ\) cycles their exact placements. For each of two grouping rules, this defines a second partition in every whole-plane Turtle tiling on \(A_2\) admitted by the necessary shell inventory. Leftover first-layer pieces keep their own boundaries.</p>
<nav aria-label="On this page"><ul><li><a href="#viewer">Explore the patch</a></li><li><a href="#observations">Counts and types</a></li><li><a href="#proof">Why the groups are disjoint</a></li><li><a href="#evidence">Evidence</a></li></ul></nav>
</header>
<section id="viewer"><h2>From tiles to clusters to triples</h2>
<p>Start with the newly searched patch that contains three mutually touching four-tile cores. Choose a layer to see the same placements as Turtle tiles, first-layer pieces, or second-layer triples. The muted fringe stays outside the two-ring guard.</p>
<figure class="frame"><div class="controls">
<label>Checked patch<select id="patch">{patch_options}</select></label>
<label>First-layer rule<select id="rule"><option value="1">Omit role 1</option><option value="2">Omit role 2</option></select></label>
<label>Visible layer<select id="layer"><option value="0">Turtle tiles</option><option value="1">First-layer pieces</option><option value="2" selected>Second-layer triples</option></select></label>
</div><svg id="patch-view" role="img" aria-label="Turtle placements colored by cluster type"></svg>
<figcaption><span id="patch-status" aria-live="polite"></span>
<ul class="legend"><li><span class="swatch" style="background:#28786a"></span>Core</li>
<li><span class="swatch" style="background:#ac531c"></span>Pair</li>
<li><span class="swatch" style="background:#7847a0"></span>Single</li></ul>
Dark fills and white spokes identify pieces joined at the second layer.</figcaption></figure></section>
<section id="observations"><h2>Which groups recur?</h2>
<p>Both rules start by joining an opposite-handed Turtle to three of its four neighbors. The omitted neighbor distinguishes the two rules. The same reciprocal half-turn rule forms pairs of available ordinary tiles. Remaining ordinary tiles stay single.</p>
<div class="scroll"><table><thead><tr><th>Omitted role</th><th>Search bank</th><th>Patches</th><th>Core triples</th><th>Pair triples</th><th>Single triples</th></tr></thead><tbody>{''.join(rule_rows)}</tbody></table></div>
<p>These are occurrence counts across patches, so repeated views of a local configuration can contribute more than once. The deeper bank uses different branch ordering and five roots from the same necessary shell inventory. Its one core triple adds a shape absent from the original bank.</p>
<p>After the local exclusions, the upper bounds on the number of shapes agree with the observed counts below. A shape includes the subdivision into its three component pieces and is classified up to a lattice isometry.</p>
<div class="scroll"><table><thead><tr><th>Omitted role</th><th>Core shapes</th><th>Pair shapes</th><th>Single shapes</th></tr></thead><tbody>{''.join(shape_rows)}</tbody></table></div>
</section>
<section id="proof"><h2>Why two triples cannot share a piece</h2>
<ol><li>Fix one piece in its lattice frame. Any threefold group containing it is determined by one of the two order-three rotations and the translation that places the next copy in edge contact. The third copy is forced. Exact supports check overlap and the last contact.</li>
<li>Compare every rooted candidate with the necessary Turtle shell inventory. The shell checker requires all prescribed contacts to occur, excludes overlap, enforces adjacent shell compatibility, and checks that each required pair or single is outside all first-layer cores. A wider collar excludes the extra single shape and the possible three-core shape for rule 2.</li>
<li>Two different triples sharing a piece appear together in the same rooted list. Nine candidate pairs survive the individual shell screen. Four are excluded by support overlap and four by incompatible immediate shells. The remaining pair is excluded after assigning four further shell layers around its prescribed pieces. Its finite failure tree has 49 nodes and replays against the full branch domains.</li></ol>
<div class="callout"><p><strong>Conditional partition.</strong> In a whole-plane Turtle tiling, every finite collar required by the tiling exists. The exclusions therefore imply that the threefold groups can all be contracted at once. The surviving shapes describe the available triple types. A repeatable substitution still requires a rule for their next-scale neighborhoods and a construction of arbitrarily large compatible regions.</p></div>
<figure class="frame"><svg id="collision-view" role="img" aria-label="Two pair triples sharing the purple pair in a checked 118-tile patch"></svg>
<figcaption>Both triples occur together in a checked 118-tile local patch with three additional shell layers. The orange and teal arms meet at the shared purple pair. Extending the required shell assignments by one more layer gives the contradiction.</figcaption></figure>
</section>
<section id="evidence"><h2>Replay and context</h2>
<p>The archive includes exact tile placements, shell assignments, rooted motif catalogues, branch certificates and a manifest. The first report attempt completed the search and hit a recursion limit when writing nested JSON. The published replay stores the execution trees as flat node arrays.</p>
<ul class="links"><li><a href="{STEM}-results.json">Machine-readable result</a></li><li><a href="{STEM}-evidence.zip">Full evidence archive</a></li><li><a href="{STEM}-manifest.json">Archive manifest with SHA-256 checksums</a></li><li><a href="{OLD}">Earlier shell inventory and learned ordering</a></li></ul>
<p>The experiments here use the exact Turtle geometry and the computed shell inventory. The rhombic substitution and independent plane construction in James Smith's paper give external comparison points. <a href="https://arxiv.org/abs/2403.01911">Turtles, Hats and Spectres</a></p>
</section></main>
<script id="figure-data" type="application/json">{json_data}</script>
<script>{SCRIPT}</script></body></html>
"""


def main():
    summary = dict(status="CHECKED_TURTLE_THREEFOLD_REPORT", study=read("data/summary-v1.json"),
                   extended=read("data/extension-summary-v1.json"), first_layer_atlas=read("input/atlas-summary-v1.json"))
    closure = read("input/closure-results-v1.json")["rounds"][-1]["records"]
    conflict = read("data/conflict-v1.json")
    summary["conflict"] = {k:v for k,v in conflict.items() if k!="checks"}
    summary["conflict"]["checks"] = [{k:v for k,v in r.items() if k not in ("witness", "tree", "placement_set")}
                                      for r in conflict["checks"]]
    assert [r["status"] for r in conflict["checks"]] == ["LOCAL_WITNESS", "EXCLUDED"]
    assert [r["depth"] for r in conflict["checks"]] == [3, 4]
    assert conflict["checks"][0]["tiles"] == 118 and conflict["checks"][1]["visits"] == 49
    data = diagrams(Model(read("input/exact-point-model-v1.json")), read("data/results-v1.json"),
                    closure, read("data/holdout-v1.json"), conflict)
    write(STEM+".html", render(summary, data))
    write(STEM+"-results.json", json.dumps(summary, indent=2, sort_keys=True)+"\n")


if __name__ == "__main__":
    main()
