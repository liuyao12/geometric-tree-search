"""Passive renderer for saved Turtle qualification JSON; no science imports.

Never imports the geometry, carrier, point author or experiment. Floats in the
browser are display coordinates only. Exact payload integers become strings
in the embedded viewer so labels cannot lose precision through JSON Number.
"""
import argparse
import gzip
import hashlib
import html
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def pin(path):
    digest=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):
            digest.update(block)
    return dict(bytes=path.stat().st_size,sha256=digest.hexdigest())


def strings(value):
    if type(value) is int:return str(value)
    if type(value) is list:return [strings(v) for v in value]
    if type(value) is dict:return {k:strings(v) for k,v in value.items()}
    return value


def matrices(pairs):
    result={name:{'legal_disjoint':0,'legal_overlap':0,'illegal_disjoint':0,'illegal_overlap':0}
            for name in ('original','occupancy','combined')}
    for row in pairs:
        for name in result:
            legal=row[name+'_capacity_legal'];overlap=row['geometry_overlap']
            if type(legal) is not bool or type(overlap) is not bool:raise ValueError('Nonboolean result')
            key=('legal' if legal else 'illegal')+('_overlap' if overlap else '_disjoint')
            result[name][key]+=1
    return result


STYLE = '''
:root{color-scheme:light;--ink:#172c39;--muted:#536b78;--line:#d8e2e7;--teal:#087f8c;--amber:#c77819;--purple:#7b4bac}*{box-sizing:border-box}body{margin:0;background:#f4f7f8;color:var(--ink);font:17px/1.65 system-ui,sans-serif}main{max-width:1190px;margin:auto;padding:34px 25px 70px}h1{font-size:clamp(30px,4.1vw,49px);line-height:1.14;letter-spacing:-.035em;max-width:1000px}h2{font-size:26px;margin:34px 0 14px}p{margin:12px 0}.eyebrow{font-size:13px;font-weight:750;text-transform:uppercase;letter-spacing:.12em;color:var(--teal)}.lede{font-size:20px;max-width:960px}.card{border:1px solid var(--line);border-radius:13px;background:white;padding:19px 23px;margin:20px 0}.callout{border-left:5px solid var(--teal)}.warning{border-left:5px solid #bb7723}.muted,figcaption,.small{font-size:14px;color:var(--muted)}a{color:#006a83}code{font-size:.9em;background:#eaf0f3;padding:2px 5px;border-radius:4px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat strong{font-size:25px;display:block}.stat span{font-size:13px;color:var(--muted)}.scroll{overflow:auto}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:12px 14px;border-bottom:1px solid var(--line)}th{font-size:14px;background:#eaf2f4}.bad{color:#9b2c36;font-weight:750}.controls{display:flex;flex-wrap:wrap;align-items:center;gap:12px}label{font-size:14px}select,button{font:inherit;font-size:14px;border:1px solid #b8cbd3;background:white;border-radius:7px;padding:8px;max-width:100%}button{cursor:pointer}select.pair{flex:1;min-width:250px}.viz{display:block;width:100%;height:auto;border:1px solid var(--line);border-radius:10px;background:#fff}.legend{display:flex;gap:18px;flex-wrap:wrap;font-size:14px;margin:12px 0}.key:before{content:'';display:inline-block;width:12px;height:12px;border-radius:3px;background:var(--color);margin-right:6px}.split{display:grid;grid-template-columns:1.35fr 1fr;gap:20px}.downloads{display:flex;flex-wrap:wrap;gap:12px}.downloads a{display:inline-block;border:1px solid #b8cbd3;padding:8px 12px;border-radius:8px;text-decoration:none;background:white}details{margin:20px 0}summary{cursor:pointer;font-weight:650}.point-info{min-height:56px;padding:10px 0}.badge{font-size:13px;display:inline-block;padding:3px 8px;border-radius:20px;background:#eaf3f4;margin-right:7px}footer{font-size:14px;color:var(--muted);border-top:1px solid var(--line);margin-top:34px;padding-top:18px}mjx-container[display="true"]{overflow-x:auto;overflow-y:hidden;padding:3px 0}svg text{font:11px system-ui,sans-serif;paint-order:stroke;stroke:white;stroke-width:3px;stroke-linejoin:round;fill:#233d49}@media(max-width:800px){main{padding:24px 15px}.stats{grid-template-columns:repeat(2,1fr)}.split{grid-template-columns:1fr}.card{padding:15px}td,th{padding:9px}.controls select{width:100%}}
'''

TEMPLATE = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Turtle: exact point qualification</title><style>__STYLE__</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<div class="eyebrow">GCTS research notebook · Turtle re-entry</div><p class="small"><a href="../conditional-inventory/failure-markings-v1.html">Previous: certified failure markings in proofs</a></p><h1>__HEADLINE__</h1><p class="lede">__LEDE__</p>
<div class="stats">__STATS__</div><div class="card callout">__SCOPE__</div>
<h2>Every pair in the declared envelope</h2><p>Rows below compare point capacity with polygon-interior overlap. Boundary contact alone is legal. Every checked pair was sent to independent exact triangle/SAT and vertical-slab geometry implementations; the saved positive witnesses were independently checked for strict interiority.</p><div class="card scroll">__MATRICES__</div>
<p class="small">__CATALOGUE__ Geometry qualified the authored data; it is not an extra legality predicate inside the point solver. No tiling search was run here.</p>
<h2 id="reader">Inspect a concrete pair</h2><div class="card"><div class="controls"><label>Class <select id="class"></select></label><label>Group <select id="group"></select></label><select id="pair" class="pair" aria-label="Pair"></select><button id="prev">Previous</button><button id="next">Next</button></div><div class="controls small" style="margin-top:10px"><label><input id="points" type="checkbox" checked> Old weighted points</label><label><input id="ids" type="checkbox"> Point IDs</label><label><input id="witnesses" type="checkbox" checked> Exact witness overlays</label><label><input id="newpoint" type="checkbox" checked> Refined excess sample</label></div>
<div class="legend"><span class="key" style="--color:#087f8c">Root Turtle</span><span class="key" style="--color:#d58a21">Second Turtle</span><span class="key" style="--color:#9258ba">Triangle intersection fragment</span><span class="key" style="--color:#237947">Slab interior witness</span><span class="key" style="--color:#c53e76">Refined excess sample</span></div><svg id="pair-svg" class="viz" viewBox="0 0 1000 620" role="img" aria-label="Two exact Turtle placements"></svg><figcaption>Coordinates are drawn by \(X=x+y/2,\ Y=\sqrt{3}y/2\). Floating-point arithmetic is used only for this illustration. The purple region is the full intersection of one witness triangle pair, not the full overlap of two nonconvex polygons.</figcaption><div id="pair-math"></div><div id="point-info" class="point-info small">Select an old point to inspect its exact coordinate and weight.</div></div>
<section class="card callout" id="packing-theorem"><h2>From the finite catalogue to every finite packing</h2><p>This is a human metatheorem supported by exact computation and independent review, rather than a proof-assistant derivation. For any finite set of distinct placements of this prototype under the declared group and integer translations, the original angular field satisfies</p>\[
\forall p\in\mathbb Z^2,\quad \sum_{Q\in\mathcal P}t_Q(p)\le1
\quad\Longleftrightarrow\quad
\forall Q\ne R\in\mathcal P,\quad\operatorname{int}Q\cap\operatorname{int}R=\varnothing.
\]<p>In the forward direction, nonnegative weights make every pair capacity-legal. Normalize either tile to the root using the verified lattice group; the complete catalogue, together with separated bounding boxes outside its envelope, then excludes polygon overlap.</p><p>In the reverse direction, each angular weight counts the occupied local sectors of angle \(\pi/6\). Interior-disjoint polygons cannot occupy the same local open sector, so the total is at most twelve sectors at every lattice point. This argument uses actual sector disjointness: pairwise weighted capacity alone would not justify the aggregate inequality.</p><p>The independent carrier checker verifies the prototype's sector density, including every zero-valued lattice point in its bounding box; the signed-coordinate group preserves the sector grid. This proves packing faithfulness under the stated assumptions. It does not establish plane coverage or existence of a tiling. <a href="point-qualification-packing-review-v1.json">Read the complete proof review</a>.</p></section>
<h2>The optional periodic carrier</h2><div class="split"><div class="card"><svg id="cells-svg" class="viz" viewBox="0 0 760 550" role="img" aria-label="All arrangement cells and their sample points in one unit square"></svg><figcaption>All saved cells and canonical samples in one axial unit square; the drawing is a rhombus. Sample IDs are display identifiers.</figcaption></div><div class="card"><p>__CELL_INFO__</p><p>The complete carrier is the union of integer translates of these phases, not every point on the displayed fine grid:</p>\[
\Lambda=\bigcup_i(q_i+\mathbb Z^2)\subseteq S^{-1}\mathbb Z^2.
\]<label>Sample <select id="phase"></select></label><div id="phase-math"></div><p class="small">The selected pair's group determines the displayed saved phase permutation and integer shift. These are certified data, not a browser recomputation.</p></div></div>
<details open><summary>Why this carrier detects all positive-area overlaps, conditionally</summary><div class="card"><p>Let the primitive integer normals be \(\mathcal N\), and use every integer line \(n\cdot x=k\). Every allowed polygon edge must lie on one of those lines. The coordinate-grid normals and their full group orbit are included, so clipping to the unit square does not create an artificial noninvariant subdivision.</p>\[
\mathcal A=\{x:n\cdot x=k,\ n\in\mathcal N,\ k\in\mathbb Z\}.
\]<p>Interior membership is constant on every open two-dimensional arrangement cell. A nonempty overlap of two polygon interiors contains an open cell, so its canonical sample is occupied by both tiles. Conversely, a shared occupied sample is itself an interior-overlap witness. Thus binary sample capacity detects pairwise interior overlap for the complete carrier under these hypotheses.</p><p>The normal action is contragredient, \(n\mapsto nR^{-1}\). Integer intercept phases are preserved by integer translations and the verified integer group. Each sample is the arithmetic mean of the cell's distinct canonical extreme vertices; affine maps preserve that mean. The saved phase action checks its image as \(Rq_i=q_j+z\). The independent carrier receipt also checks the complete support, cells, angular units and phase compositions.</p><p>In the combined field, old angular points retain their exact sector weights and occupied cell samples contribute \(12\), with common capacity \(12\) and no markings. This is a new point representation when it excludes an old legal overlap. It is not a proved redundant constraint in the old sampled model.</p></div></details>
<details><summary>Completeness of the relative-pair catalogue and its limits</summary><div class="card"><p>Verified group closure, inverses and integer unimodularity let one placement be moved to the identity root without changing the allowed relative system. For each second orientation, the inclusive integer ranges are</p>\[
\min_xP-\max_x(RP)\le d_x\le\max_xP-\min_x(RP),
\]\[
\min_yP-\max_y(RP)\le d_y\le\max_yP-\min_y(RP).
\]<p>Outside these ranges the closed axial bounding boxes are separated, hence the polygon interiors are disjoint. The authored supports are bounded by their polygons, so separated boxes also share no occupied support. Inside the envelope, all pairs are included, including contacts sharing no old sample; root-identical placements and equivalent placements are explicitly counted as exclusions/deduplications.</p><p>__COMPLETE_TEXT__ The carrier argument assumes the stated integer translation lattice and allowed group. New orientations, nonlattice translations or boundary phases need requalification. An arbitrary fixed or movable region boundary may cut cells and needs its own exact boundary authoring.</p></div></details>
<div class="card warning"><strong>What this establishes.</strong> This qualifies geometry versus point capacity and checks a point-carrier construction. Markings remain empty. It supplies no learned matching rule, RL result, substitution rule, practical region-tiling benchmark, fair untouched-point growth proof or tiling of the plane.</div>
<h2>Provenance and algorithm contract</h2><div class="card"><p>The polygon and literal vertex weights were transcribed from byte-pinned public snapshots of <a href="https://github.com/liuyao12/geometric-tree-search/blob/main/GCTS-I.html">GCTS-I.html</a> and <a href="https://github.com/liuyao12/geometric-tree-search/blob/main/assets/a2-tiling-engine.js">the A2 engine</a>. The local historical files were unavailable as hydrated data and were not opened; equivalence to locally modified files is not claimed. The old scientific JavaScript and its known matching rules were not imported or executed.</p><p>The frozen native model uses exact integer/rational arithmetic and empty markings. Capacity is the point-value rule from <a href="../../../basic-tiling-algorithm.md">the shared algorithm contract</a>; polygon tests are independent verification. This study has no search frontier, scheduler or rollback implementation to certify. The existing finite-boundary engine's extra geometric controls and the infinite-growth fair-activation obligation remain separate work.</p><p>The protocol and source pins were frozen before scientific execution. A pre-execution interface correction converted authored tuples to JSON arrays before the independent carrier checker; the earlier freeze is retained. It changed neither the catalogue, resource limits nor scientific inputs. The full archive preserves both freezes, raw oracle certificates, independent catalogue audit, source snapshots and execution logs.</p><p>The next Turtle experiment should use the lighter angular field, fresh unmarked corona labels, complete global frontier bookkeeping and exact rollback. This report does not supply those labels or a preferred tiling strategy.</p></div>
<h2>Exact data and evidence</h2><div class="downloads"><a href="exact-point-model-v1.json">Exact point model</a><a href="point-qualification-results-summary-v1.json">Results summary</a><a href="point-qualification-results-v1.json.gz">Full raw results</a><a href="point-qualification-evidence-v1.html">Evidence index</a></div><p class="small">__RUNTIME__ Full rows, exact rational witnesses, source pins and the declared catalogue are retained in the downloadable data.</p><footer>The viewer is a passive projection of saved results. It imports no search, geometric oracle or point-authoring implementation. Exact coordinates are available even when screen rendering rounds.</footer>
<script id="viewer-data" type="application/json">__DATA__</script><script>
const D=JSON.parse(document.getElementById('viewer-data').textContent),M=D.model,P=D.pairs,G=M.groups,NS='http://www.w3.org/2000/svg';let visible=[],current=0;
const $=id=>document.getElementById(id),N=x=>Number(x),B=x=>BigInt(x),rat=x=>N(x[0])/N(x[1]),rp=p=>p.map(rat),texRat=x=>x[1]==='1'?x[0]:'\\frac{'+x[0]+'}{'+x[1]+'}',texPoint=p=>'('+p.map(texRat).join(',')+')';
function typeset(node){if(window.MathJax&&MathJax.typesetPromise){MathJax.typesetClear([node]);MathJax.typesetPromise([node]);}}
function el(tag,attrs={},parent){let n=document.createElementNS(NS,tag);for(let[k,v]of Object.entries(attrs))n.setAttribute(k,String(v));if(parent)parent.appendChild(n);return n;}
function screen(points,w,h,pad=40){let v=points.map(p=>[N(p[0])+N(p[1])/2,Math.sqrt(3)*N(p[1])/2]),xs=v.map(p=>p[0]),ys=v.map(p=>p[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),s=Math.min((w-2*pad)/Math.max(x1-x0,.1),(h-2*pad)/Math.max(y1-y0,.1)),ox=(w-s*(x1-x0))/2,oy=(h-s*(y1-y0))/2;return p=>[ox+(N(p[0])+N(p[1])/2-x0)*s,h-oy-(Math.sqrt(3)*N(p[1])/2-y0)*s];}
function polygon(svg,pts,map,attrs){return el('polygon',{points:pts.map(p=>map(p).join(',')).join(' '),...attrs},svg);}
function transform(p,g,t){let x=B(p[0]),y=B(p[1]),a=g.matrix;return[(B(a[0][0])*x+B(a[0][1])*y+B(t[0])).toString(),(B(a[1][0])*x+B(a[1][1])*y+B(t[1])).toString()];}
function classify(p){if(p.geometry_overlap&&p.original_capacity_legal)return'old-legal-overlap';if(!p.geometry_overlap&&!p.original_capacity_legal)return'old-illegal-disjoint';if(p.geometry_overlap)return'overlap';return N(p.common_original_support)>0?'disjoint-shared':'disjoint-no-shared';}
const classes=[['all','All checked pairs'],['old-legal-overlap','Old legal / geometric overlap'],['old-illegal-disjoint','Old rejected / geometrically disjoint'],['overlap','Overlap excluded by old field'],['disjoint-shared','Disjoint interiors / shared old points'],['disjoint-no-shared','Disjoint interiors / no shared old points']];
for(let[k,title]of classes){let count=P.filter(p=>k==='all'||classify(p)===k).length;if(count)$('class').add(new Option(title+' ('+count+')',k));}
$('group').add(new Option('All groups','all'));for(let g of G)$('group').add(new Option('g'+g.id,g.id));
$('class').value=P.some(p=>classify(p)==='old-legal-overlap')?'old-legal-overlap':P.some(p=>classify(p)==='disjoint-shared')?'disjoint-shared':'all';
function fill(){visible=P.map((p,i)=>({p,i})).filter(x=>($('class').value==='all'||classify(x.p)===$('class').value)&&($('group').value==='all'||x.p.group===$('group').value));if($('class').value==='disjoint-shared')visible.sort((a,b)=>N(b.p.common_original_support)-N(a.p.common_original_support)||a.i-b.i);$('pair').replaceChildren();for(let x of visible)$('pair').add(new Option('#'+x.i+' · g'+x.p.group+' · shift ('+x.p.translation.join(',')+')',x.i));if(visible.length){current=visible[0].i;$('pair').value=current;draw();}else{$('pair-svg').replaceChildren();$('pair-math').textContent='No pair in this filter.';}}
function inspect(id,x,y,u,total){$('point-info').textContent='\\('+id+':\\quad p=('+x+','+y+'),\\quad t(p)=\\frac{'+u+'}{12},\\quad T(p)=\\frac{'+total+'}{12}.\\)';typeset($('point-info'));}
function draw(){let p=P[current],g=G.find(v=>v.id===p.group),t=p.translation,root=M.polygon,second=root.map(v=>transform(v,g,t)),svg=$('pair-svg');svg.replaceChildren();let map=screen([...root,...second],1000,620,45);let ax=[...root,...second].map(v=>v.map(N)),xmin=Math.floor(Math.min(...ax.map(v=>v[0])))-1,xmax=Math.ceil(Math.max(...ax.map(v=>v[0])))+1,ymin=Math.floor(Math.min(...ax.map(v=>v[1])))-1,ymax=Math.ceil(Math.max(...ax.map(v=>v[1])))+1;
for(let x=xmin;x<=xmax;x++){let a=map([x,ymin]),b=map([x,ymax]);el('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#eaf0f3'},svg);}for(let y=ymin;y<=ymax;y++){let a=map([xmin,y]),b=map([xmax,y]);el('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:'#eaf0f3'},svg);}
polygon(svg,root,map,{fill:'#087f8c','fill-opacity':.15,stroke:'#087f8c','stroke-width':2.8});polygon(svg,second,map,{fill:'#d58a21','fill-opacity':.16,stroke:'#bd7410','stroke-width':2.8});
if($('witnesses').checked&&p.triangle){polygon(svg,p.triangle.intersection.map(rp),map,{fill:'#9258ba','fill-opacity':.38,stroke:'#754195','stroke-width':1.5});}if($('witnesses').checked&&p.slab){let q=map(rp(p.slab));el('circle',{cx:q[0],cy:q[1],r:5,fill:'#237947',stroke:'white','stroke-width':1.5},svg);}
let A=M.original_field.map(v=>[v[0],v[1],v[2]]),C=A.map(v=>[...transform(v,g,t),v[2]]),sums=new Map();for(let v of [...A,...C]){let key=v[0]+','+v[1];sums.set(key,(sums.get(key)||0n)+B(v[2]));}
if($('points').checked)for(let [which,rows,color]of [['A',A,'#087f8c'],['B',C,'#bd7410']])rows.forEach((v,i)=>{let q=map(v),n=el('circle',{cx:q[0],cy:q[1],r:2.3+N(v[2])/4,fill:color,'fill-opacity':.78,stroke:'white','stroke-width':.8},svg);n.style.cursor='pointer';n.onclick=()=>inspect('\\mathrm{'+which+'}_{'+i+'}',v[0],v[1],v[2],sums.get(v[0]+','+v[1]).toString());if($('ids').checked){let z=el('text',{x:q[0]+6,y:q[1]-6},svg);z.textContent=which+i;}});
let extra='';if(p.first_occupancy_excess.length){let e=p.first_occupancy_excess[0],q=[N(e[0])/N(M.scale),N(e[1])/N(M.scale)];extra='\\[q=(\\frac{'+e[0]+'}{'+M.scale+'},\\frac{'+e[1]+'}{'+M.scale+'}),\\qquad 12T(q)='+e[2]+'>12.\\]';if($('newpoint').checked){let z=map(q);el('circle',{cx:z[0],cy:z[1],r:7,fill:'#c53e76',stroke:'white','stroke-width':2},svg);}}
let matrix='\\begin{pmatrix}'+g.matrix[0].join('&')+'\\\\'+g.matrix[1].join('&')+'\\end{pmatrix}';$('pair-math').innerHTML='<p><span class="badge">Geometry: '+(p.geometry_overlap?'positive overlap':'disjoint interiors')+'</span><span class="badge">Old: '+(p.original_capacity_legal?'capacity legal':'capacity conflict')+'</span><span class="badge">Combined: '+(p.combined_capacity_legal?'legal':'conflict')+'</span></p><div>\\[g_{'+g.id+'}:R='+matrix+',\\quad \\tau=('+t.join(',')+'),\\quad \\epsilon='+g.sign+',\\quad \\pi=('+g.permutation.join(',')+').\\]</div>'+extra+(p.triangle?'<p class="small">Triangle fragment doubled axial area: \\('+texRat(p.triangle.area2)+'\\). This is not the total polygon-overlap area.</p>':'');typeset($('pair-math'));phase();}
$('class').onchange=fill;$('group').onchange=fill;$('pair').onchange=()=>{current=N($('pair').value);draw();};for(let id of ['points','ids','witnesses','newpoint'])$(id).onchange=draw;for(let [id,step]of [['prev',-1],['next',1]])$(id).onclick=()=>{if(!visible.length)return;let i=visible.findIndex(x=>x.i===current);current=visible[(i+step+visible.length)%visible.length].i;$('pair').value=current;draw();};
function cells(){let svg=$('cells-svg');svg.replaceChildren();let corners=[[0,0],[1,0],[1,1],[0,1]],map=screen(corners,760,550,45);M.cells.forEach((cell,i)=>{let pts=cell.vertices.map(rp);polygon(svg,pts,map,{fill:'hsl('+((i*47)%360)+' 42% 87%)',stroke:'#718d9a','stroke-width':.85});let p=map(rp(cell.sample));let n=el('circle',{cx:p[0],cy:p[1],r:2.7,fill:'#9b3656'},svg);n.style.cursor='pointer';n.onclick=()=>{$('phase').value=i;phase();};if(M.cells.length<=80){let z=el('text',{x:p[0]+4,y:p[1]-3},svg);z.textContent='c'+i;}});for(let i=0;i<M.cells.length;i++)$('phase').add(new Option('Cell '+i,i));}
function phase(){if(!P.length)return;let i=N($('phase').value||0),p=P[current],a=M.sample_actions.find(a=>a.group===p.group),j=a.sample_permutation[i],z=a.integer_shifts[i],sample=M.cells[i].sample,r=M.orbit_residues[i];$('phase-math').textContent='\\[q_{'+i+'}='+texPoint(sample)+',\\quad Sq_{'+i+'}=('+r.join(',')+').\\]\\[R_{'+p.group+'}q_{'+i+'}=q_{'+j+'}+('+z.join(',')+').\\]';typeset($('phase-math'));}
$('phase').onchange=phase;cells();fill();
</script></main></body></html>'''


def build(result_path, outdir):
    if not result_path.is_file():raise SystemExit('Finished saved results required; no placeholder report is generated.')
    with gzip.open(result_path,'rt') as f:result=json.load(f)
    if result.get('schema')!='Turtle-exact-point-qualification-v1':raise ValueError('Unexpected results schema')
    pairs=result['pairs'];model=result['model'];matrix=matrices(pairs);complete=result['status']=='COMPLETE' and result['catalogue']['complete'] is True
    old_false=matrix['original']['legal_overlap'];old_reject=matrix['original']['illegal_disjoint']
    for p in pairs:
        if p['slab']['status']!='VERIFIED' or p['slab']['overlap'] is not p['geometry_overlap'] or p['triangle']['overlap'] is not p['geometry_overlap']:raise ValueError('Saved oracle agreement is incomplete')
    summary=dict(schema='Turtle-exact-point-qualification-public-summary-v1',status=result['status'],reason=result.get('reason'),catalogue=result['catalogue'],counts=result['counts'],matrices=matrix,geometry_agreement_pairs=len(pairs),carrier_check=result['carrier_check'],group_check=result['group_check'],model=dict(groups=len(model['groups']),cells=len(model['cells']),sample_phases=len(model['orbit_residues']),scale=model['scale'],normal_families=model['normal_families'],original_support=len(model['original_field']),occupancy_support=len(model['occupancy_field']),combined_support=len(model['combined_field']),marking_assignments=len(model['initial_markings'])),seconds=result['seconds'],peak_ru_maxrss_native=result['peak_ru_maxrss_native'],rss_units=result['environment']['rss_units'],source_result=pin(result_path),scope=result['scope'])
    if complete and old_false:
        headline='The old point field admits geometric overlap'
        lede=f'The complete declared catalogue contains \\({old_false}\\) pairs whose old point capacity is legal while the Turtle interiors overlap. The independently checked refined carrier is assessed separately below.'
        scope='This is a representation finding. Adding the refined occupancy samples changes the old point model; markings remain empty. It is not a learned matching rule.'
    elif complete and not old_false and not old_reject:
        headline='No old-field mismatch in the complete pair catalogue'
        lede='The saved exhaustive relative-pair qualification found agreement between old point capacity and exact geometry throughout the declared bounding-box envelope. The analytical outside-envelope argument and transformation assumptions remain explicit.'
        scope='This exact reauthoring of the published angular footprint qualifies the original, lighter point model under the declared prototype, group and integer translations. Keep that model for the next tiling search; the periodic cell carrier is an optional general construction. The existing floating-point JavaScript engine was not executed in this qualification. This is not a plane-tiling witness or a result of marking learning.'
    elif not complete:
        headline='The exact pair qualification is incomplete'
        lede='The resource-bounded run retained the checked prefix below. Its declared envelope was not exhausted; no complete pair-equivalence claim follows.'
        scope='Partial data is shown without converting a resource limit into a negative or complete certificate.'
    else:
        headline='Point capacity and geometry disagree'
        lede='The saved matrices retain both directions of disagreement. Read the exact rows and witnesses before drawing a representation conclusion.'
        scope='The result concerns the declared finite models and transformations only.'
    def esc(x):return html.escape(str(x))
    cards=[(len(pairs),'checked relative pairs'),(len(model['groups']),'group elements'),(len(model['cells']),'unit-cell phases'),(old_false,'old legal overlaps')]
    stats=''.join('<div class="card stat"><strong>\\('+str(n)+'\\)</strong><span>'+label+'</span></div>' for n,label in cards)
    rows=''
    for name,label in [('original','Old angular field'),('occupancy','Refined occupancy only'),('combined','Combined angular + occupancy')]:
        m=matrix[name];rows+='<tr><td>'+label+'</td>'+''.join('<td'+(' class="bad"' if k in ('legal_overlap','illegal_disjoint') and m[k] else '')+'>\\('+str(m[k])+'\\)</td>' for k in ('legal_disjoint','legal_overlap','illegal_disjoint','illegal_overlap'))+'</tr>'
    table='<table><thead><tr><th>Point model</th><th>Legal / disjoint</th><th>Legal / overlap</th><th>Conflict / disjoint</th><th>Conflict / overlap</th></tr></thead><tbody>'+rows+'</tbody></table>'
    c=result['catalogue'];cat=f'Raw positions: \\({c["raw_positions"]}\\); deduplicated equivalents: \\({c["duplicates"]}\\); root-identical exclusions: \\({c["root_identical_excluded"]}\\). Pairs with no common old support point: \\({result["counts"]["no_common_original_points"]}\\).'
    normals='\\{'+','.join('('+str(a)+','+str(b)+')' for a,b in model['normal_families'])+'\\}'
    cellinfo=f'Positive support counts: \\({len(model["original_field"])}\\) old angular, \\({len(model["occupancy_field"])}\\) occupancy, and \\({len(model["combined_field"])}\\) combined. Independent carrier receipt: <code>{esc(result["carrier_check"]["status"])}</code>. All \\({len(model["cells"])}\\) cells/samples are displayed. Common integer scale \\(S={model["scale"]}\\). Primitive normal families: \\({normals}\\).'
    projected=[]
    for i,p in enumerate(pairs):
        projected.append({**{k:p[k] for k in ('group','translation','geometry_overlap','original_capacity_legal','occupancy_capacity_legal','combined_capacity_legal','common_original_support','first_original_excess','first_occupancy_excess')},'triangle':p['triangle']['witness'] if p['triangle']['overlap'] else None,'slab':p['slab']['witness'] if p['slab']['overlap'] else None})
    payload=dict(model={k:model[k] for k in ('polygon','groups','original_field','cells','scale','orbit_residues','sample_actions')},pairs=projected)
    data=json.dumps(strings(payload),ensure_ascii=True,separators=(',',':')).replace('<','\\u003c')
    runtime=f'Recorded scientific run time: \\({result["seconds"]:.3f}\\) seconds; peak native RSS: <code>{esc(result["peak_ru_maxrss_native"])}</code> ({esc(result["environment"]["rss_units"])}).'
    values={'STYLE':STYLE,'HEADLINE':esc(headline),'LEDE':lede,'STATS':stats,'SCOPE':scope,'MATRICES':table,'CATALOGUE':cat,'CELL_INFO':cellinfo,'COMPLETE_TEXT':'The saved run exhausted this declared catalogue.' if complete else 'The saved run did not exhaust this declared catalogue.','RUNTIME':runtime,'DATA':data}
    page=TEMPLATE
    for key,value in values.items():page=page.replace('__'+key+'__',value)
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'point-qualification-v1.html').write_text(page)
    (outdir/'results-summary-v1.json').write_bytes(wire(summary));(outdir/'point-qualification-results-summary-v1.json').write_bytes(wire(summary))
    assets=[(result_path,'point-qualification-results-v1.json.gz'),(ROOT/'data/exact-point-model-v1.json','exact-point-model-v1.json'),(ROOT/'data/protocol-frozen-v1.json','point-qualification-protocol-v1.json'),(ROOT/'data/carrier-check-v1.json','point-qualification-carrier-check-v1.json'),(ROOT/'qualification-v1.json','point-qualification-oracle-fixtures-v1.json'),(ROOT/'reference/packing-equivalence-review-v1.json','point-qualification-packing-review-v1.json'),(ROOT/'review/catalogue-independent-audit-v1.json','point-qualification-independent-audit-v1.json')]
    for source,name in assets:
        if not source.is_file():raise ValueError('Missing evidence '+str(source))
        if source.resolve()!=(outdir/name).resolve():shutil.copyfile(source,outdir/name)
    evidence=[]
    for name in ['point-qualification-results-summary-v1.json']+[name for _,name in assets]:
        p=outdir/name;v=pin(p);evidence.append('<tr><td><a href="'+esc(name)+'">'+esc(name)+'</a></td><td>'+str(v['bytes'])+'</td><td><code>'+v['sha256']+'</code></td></tr>')
    sources=''.join('<tr><td><code>'+esc(name)+'</code></td><td>'+str(p['bytes'])+'</td><td><code>'+p['sha256']+'</code></td></tr>' for name,p in sorted(result['protocol']['pins'].items()))
    evidence_page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Turtle qualification evidence</title><style>'+STYLE+'</style></head><body><main><h1>Turtle qualification evidence</h1><p><a href="point-qualification-v1.html">Readable report</a>. These files are saved native data and passive projections; source pins identify the executed modules and read-only input snapshots. A larger source archive may be linked by the publication wrapper.</p><div class="card scroll"><table><tr><th>Download</th><th>Bytes</th><th>SHA256</th></tr>'+''.join(evidence)+'</table></div><h2>Frozen source and input pins</h2><div class="card scroll"><table><tr><th>Path</th><th>Bytes</th><th>SHA256</th></tr>'+sources+'</table></div></main></body></html>'
    (outdir/'point-qualification-evidence-v1.html').write_text(evidence_page)
    print(json.dumps(dict(report=str(outdir/'point-qualification-v1.html'),summary=str(outdir/'results-summary-v1.json'),status=result['status'],checked_pairs=len(pairs),matrices=matrix),sort_keys=True))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,default=ROOT/'data/results-v1.json.gz');parser.add_argument('--outdir',type=Path,default=ROOT/'report');args=parser.parse_args();build(args.input,args.outdir)
