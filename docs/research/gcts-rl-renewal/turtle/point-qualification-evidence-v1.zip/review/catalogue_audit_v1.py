"""Saved-data audit only. Imports solely the explicitly approved slab checker.

No tile author, native experiment, triangle oracle, carrier checker, or search
module is imported or executed. All point arithmetic below is independently
written integer arithmetic over saved data; negative slab certificate replay
and positive winding checks are explicitly authorized checker replays.
"""
from pathlib import Path
from fractions import Fraction
from itertools import permutations
import gzip
import hashlib
import importlib.util
import json
import time

RUN = Path(__file__).resolve().parents[1]
VERSION = 'Turtle-independent-saved-catalogue-audit-v1'
SLAB_SHA = '1ec3cb1afc481226e1d665dccb45958b4957194bf4bd96e1ddedbb9ba829ed08'


def need(value, reason):
    if not value:
        raise AssertionError(reason)


def pin(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def wire(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def integer(value):
    return type(value) is int


def transform(point, matrix, tx=0, ty=0):
    x, y = point
    return (matrix[0][0]*x+matrix[0][1]*y+tx,
            matrix[1][0]*x+matrix[1][1]*y+ty)


def field(rows):
    out = {}
    for row in rows:
        need(type(row) is list and len(row) == 3 and all(map(integer, row)), 'FIELD_ROW')
        x, y, w = row
        need(0 < w <= 12 and (x, y) not in out, 'FIELD_WEIGHT_OR_DUPLICATE')
        out[x, y] = w
    return out


def capacity(root, matrix, tx, ty):
    moved = {transform(p, matrix, tx, ty): w for p, w in root.items()}
    need(len(moved) == len(root), 'NONINJECTIVE_TRANSFORM')
    excess = {p: w+moved.get(p, 0) for p, w in root.items() if w+moved.get(p, 0) > 12}
    return excess, len(root.keys() & moved.keys())


def rational(pair):
    need(type(pair) is list and len(pair) == 2 and all(map(integer, pair)) and pair[1] > 0,
         'BAD_RATIONAL')
    return Fraction(*pair)


def main():
    started = time.monotonic()
    protocol_path = RUN/'data/protocol-frozen-v1.json'
    protocol = json.loads(protocol_path.read_bytes())
    sources = {}
    for rel, expected in protocol['pins'].items():
        sources[rel] = pin(RUN/rel)
        need(sources[rel] == expected, 'SOURCE_PIN:'+rel)
    slab_path = RUN/'reference/slab_geometry_checker_v1.py'
    need(pin(slab_path)['sha256'] == SLAB_SHA, 'APPROVED_SLAB_SOURCE_PIN')
    spec = importlib.util.spec_from_file_location('approved_slab_for_saved_audit', slab_path)
    slab = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(slab)

    input_names = ['data/results-v1.json.gz', 'data/protocol-frozen-v1.json',
                   'data/exact-point-model-v1.json', 'data/carrier-check-v1.json',
                   'qualification-v1.json', 'execution-v1.log', 'execution-v1.stderr']
    inputs = {rel: pin(RUN/rel) for rel in input_names}
    raw = gzip.decompress((RUN/'data/results-v1.json.gz').read_bytes())
    result = json.loads(raw)
    model = json.loads((RUN/'data/exact-point-model-v1.json').read_bytes())
    carrier = json.loads((RUN/'data/carrier-check-v1.json').read_bytes())
    qual = json.loads((RUN/'qualification-v1.json').read_bytes())
    need(result['status'] == 'COMPLETE' and result['reason'] is None, 'RESULT_NOT_COMPLETE')
    need(wire(result['model']) == wire(model), 'MODEL_COPY')
    need(wire(result['protocol']) == wire(protocol), 'PROTOCOL_COPY')
    need(wire(result['carrier_check']) == wire(carrier) and carrier['status'] == 'VERIFIED',
         'CARRIER_RECEIPT_COPY')
    need(protocol['initial_markings'] == model['initial_markings'] == [], 'NOT_UNMARKED')
    need(model['scale'] == 18 and integer(model['scale']), 'SCALE')
    need(qual['status'] == 'PASS', 'QUALIFICATION_STATUS')
    qualification = []
    for item in qual['fixtures']:
        if type(item['expected']) is bool:
            need(item['slab']['status'] == 'VERIFIED' and
                 item['slab']['overlap'] is item['expected'] and
                 item['triangle']['overlap'] is item['expected'], 'QUALIFICATION_GEOMETRY')
        else:
            need(item['expected'] == item['slab']['status'] == 'REJECTED', 'QUALIFICATION_REJECTION')
        qualification.append({'name': item['name'], 'expected': item['expected'], 'status': 'AGREES'})

    poly = model['polygon']
    need(len(poly) == 14 and all(type(p) is list and len(p) == 2 and all(map(integer, p))
                               for p in poly), 'POLYGON')
    raw3 = protocol['polygon3']
    need(poly == [[p[0]-raw3[0][0], p[1]-raw3[0][1]] for p in raw3], 'POLYGON_NORMALIZATION')
    root_set = {tuple(p) for p in poly}
    bbox = lambda ps: (min(p[0] for p in ps), max(p[0] for p in ps),
                       min(p[1] for p in ps), max(p[1] for p in ps))
    ax, bx, ay, by = bbox(poly)
    groups = model['groups']
    need(len(groups) == 12 and [g['id'] for g in groups] == list(range(12)), 'GROUP_IDS')
    allowed = {(sign, perm) for sign in (1, -1) for perm in permutations(range(3))}
    found, expected, excluded, boxes = set(), set(), [], []
    coeffs = [(1, 0), (0, 1), (-1, -1)]
    for group in groups:
        sign, perm, matrix = group['sign'], tuple(group['permutation']), group['matrix']
        need(integer(sign) and all(map(integer, perm)) and (sign, perm) in allowed,
             'GROUP_SIGNED_PERMUTATION')
        found.add((sign, perm))
        derived = [[sign*v for v in coeffs[perm[i]]] for i in range(2)]
        need(matrix == derived, 'GROUP_MATRIX')
        need(abs(matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0]) == 1, 'GROUP_DETERMINANT')
        moved = [transform(p, matrix) for p in poly]
        cx, dx, cy, dy = bbox(moved)
        txlo, txhi, tylo, tyhi = ax-dx, bx-cx, ay-dy, by-cy
        boxes.append({'group': group['id'], 'tx': [txlo, txhi], 'ty': [tylo, tyhi],
                      'raw_tuples': (txhi-txlo+1)*(tyhi-tylo+1)})
        for tx in range(txlo, txhi+1):
            for ty in range(tylo, tyhi+1):
                key = group['id'], tx, ty
                if {(p[0]+tx, p[1]+ty) for p in moved} == root_set:
                    excluded.append(key)
                else:
                    need(key not in expected, 'EXPECTED_DUPLICATE')
                    expected.add(key)
    need(found == allowed, 'MISSING_GROUP')
    need(sum(b['raw_tuples'] for b in boxes) == 2444 and excluded == [(0, 0, 0)],
         'CATALOGUE_RAW_OR_IDENTICAL_COUNT')
    pairs = result['pairs']
    actual = []
    for item in pairs:
        need(integer(item['group']) and type(item['translation']) is list and
             len(item['translation']) == 2 and all(map(integer, item['translation'])), 'PAIR_KEY')
        actual.append((item['group'], *item['translation']))
    need(len(actual) == len(set(actual)) == len(expected) == 2443 and set(actual) == expected,
         'EXACT_CATALOGUE_COVERAGE')
    need(result['catalogue'] == {'checked_pairs': 2443, 'complete': True, 'duplicates': 0,
                                'raw_positions': 2444, 'root_identical_excluded': 1}, 'CATALOGUE_RECEIPT')

    fields = {name: field(model[name+'_field']) for name in ['original', 'occupancy', 'combined']}
    need([len(fields[n]) for n in ['original', 'occupancy', 'combined']] == [28, 240, 268],
         'FIELD_COUNTS')
    scaled_original = {(18*x, 18*y): w for (x, y), w in fields['original'].items()}
    need(not (scaled_original.keys() & fields['occupancy'].keys()), 'SUPPORT_INTERSECTION')
    need(fields['combined'] == dict(scaled_original, **{}) | fields['occupancy'], 'COMBINED_FIELD')
    counts = {'overlap': 0, 'disjoint': 0, 'no_common_original_points': 0,
              'original_legal_overlap': 0, 'original_illegal_disjoint': 0,
              'occupancy_mismatches': 0, 'combined_mismatches': 0}
    witness_digest = hashlib.sha256()
    negative_digest = hashlib.sha256()
    negative_slabs, capacity_checks, winding_checks = 0, 0, 0
    for item, key in zip(pairs, actual):
        gid, tx, ty = key
        matrix = groups[gid]['matrix']
        moved = [list(transform(p, matrix, tx, ty)) for p in poly]
        positive = item['geometry_overlap']
        need(type(positive) is bool, 'GEOMETRY_BOOL')
        counts['overlap' if positive else 'disjoint'] += 1
        need(item['triangle']['overlap'] is positive and item['slab']['overlap'] is positive and
             item['slab']['status'] == 'VERIFIED', 'ORACLE_AGREEMENT')
        for name, root in fields.items():
            scale = 1 if name == 'original' else 18
            excess, common = capacity(root, matrix, scale*tx, scale*ty)
            legal = not excess
            need(type(item[name+'_capacity_legal']) is bool and item[name+'_capacity_legal'] is legal,
                 'CAPACITY_LEGAL:'+name)
            need(integer(item[name+'_excess_count']) and item[name+'_excess_count'] == len(excess),
                 'CAPACITY_EXCESS_COUNT:'+name)
            first = item['first_'+name+'_excess']
            need(len(first) == min(1, len(excess)), 'EXCESS_WITNESS_COUNT')
            for x, y, w in first:
                need(all(map(integer, [x, y, w])) and excess.get((x, y)) == w, 'EXCESS_WITNESS')
            need(positive is (not legal), 'POINT_GEOMETRY_MISMATCH:'+name)
            if name == 'original':
                need(item['common_original_support'] == common and integer(item['common_original_support']),
                     'COMMON_ORIGINAL_SUPPORT')
                counts['no_common_original_points'] += common == 0
            capacity_checks += 1
        if positive:
            sw = item['slab']['witness']
            need(item['slab']['witness_strictly_inside_both'] is True, 'SAVED_WITNESS_FLAG')
            need(slab.point_inside_strict(sw, poly) and slab.point_inside_strict(sw, moved),
                 'SLAB_WITNESS_NOT_STRICT')
            witness = item['triangle']['witness']
            vertices = [tuple(rational(c) for c in p) for p in witness['intersection']]
            need(len(vertices) >= 3 and all(len(p) == 2 for p in vertices), 'TRIANGLE_WITNESS_POLYGON')
            area2 = abs(sum(a[0]*b[1]-a[1]*b[0] for a, b in zip(vertices, vertices[1:]+vertices[:1])))
            need(area2 > 0 and area2 == rational(witness['area2']), 'TRIANGLE_WITNESS_AREA')
            centroid = tuple(sum(p[i] for p in vertices)/len(vertices) for i in (0, 1))
            need(slab.point_inside_strict(centroid, poly) and slab.point_inside_strict(centroid, moved),
                 'TRIANGLE_CENTROID_NOT_STRICT')
            winding_checks += 4
            witness_digest.update((wire([key, sw, [[c.numerator, c.denominator] for c in centroid]])+'\n').encode())
        else:
            saved = item['slab']
            need(item['triangle']['witness'] is None and saved['witness'] is None, 'NEGATIVE_WITNESS')
            critical = [rational(x) for x in saved['critical_x']]
            need(critical == sorted(set(critical)) and saved['critical_x_count'] == len(critical),
                 'CRITICAL_X_METADATA')
            need(saved['certificate'] == 'ALL_EXACT_OPEN_VERTICAL_SLABS_DISJOINT' and
                 saved['slabs_checked'] == saved['slabs_total'] == len(saved['slabs']) == len(critical)-1,
                 'COMPLETE_NEGATIVE_SLABS')
            for i, row in enumerate(saved['slabs']):
                need([rational(c) for c in row['x_bounds']] == critical[i:i+2] and
                     rational(row['sample_x']) == (critical[i]+critical[i+1])/2 and
                     row['strict_intersection_y'] is None, 'NEGATIVE_SLAB_ROW')
            replay = slab.overlap(poly, moved)
            need(wire(replay) == wire(saved), 'NEGATIVE_FULL_CERTIFICATE_REPLAY')
            negative_slabs += len(saved['slabs'])
            negative_digest.update((wire([key, saved])+'\n').encode())
    need(counts == result['counts'] == {'overlap': 1047, 'disjoint': 1396,
         'no_common_original_points': 1092, 'original_legal_overlap': 0,
         'original_illegal_disjoint': 0, 'occupancy_mismatches': 0, 'combined_mismatches': 0},
         'RECOMPUTED_COUNTS')
    events = [json.loads(line) for line in (RUN/'execution-v1.log').read_text().splitlines() if line]
    final = events[-1]
    need(final['kind'] == 'COMPLETE' and final['catalogue'] == result['catalogue'] and
         final['counts'] == result['counts'] and final['seconds'] == result['seconds'], 'COMPLETION_LOG')
    need((RUN/'execution-v1.stderr').stat().st_size == 0, 'NONEMPTY_STDERR')
    need(all(pin(RUN/p) == v for p, v in sources.items()), 'SOURCE_CHANGED_DURING_AUDIT')
    need(all(pin(RUN/p) == v for p, v in inputs.items()), 'INPUT_CHANGED_DURING_AUDIT')
    receipt = {
        'schema': VERSION, 'status': 'VERIFIED', 'utility_source': pin(Path(__file__)),
        'inputs': inputs, 'source_pins_before_after_equal': sources,
        'decompressed_results': {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
        'completion': {'saved_status': result['status'], 'complete_log_agrees': True,
                       'stderr_empty': True, 'native_seconds_saved': result['seconds'],
                       'native_peak_rss_bytes_saved': result['peak_ru_maxrss_native'],
                       'host_exit': 'Parent reported native exit 0; independently checked saved completion and empty stderr.'},
        'coverage': {'groups': 12, 'raw_bbox_tuples': 2444, 'excluded_exact_root': excluded,
                     'expected_pairs': len(expected), 'saved_unique_pairs': len(actual),
                     'missing': 0, 'extra': 0, 'duplicates': 0, 'boxes_inclusive': boxes,
                     'tuple_set_sha256': hashlib.sha256(wire(sorted(expected)).encode()).hexdigest()},
        'point_checks': {'capacity': 12, 'scale': 18, 'field_supports': [28, 240, 268],
                         'independent_integer_capacity_checks': capacity_checks,
                         'all_first_excess_witnesses_checked': True, 'initial_markings': [],
                         'counts': counts},
        'geometry_checks': {'positive_pairs': counts['overlap'], 'strict_winding_checks': winding_checks,
                            'triangle_witness_area_and_vertex_centroid_checked': counts['overlap'],
                            'slab_positive_witnesses_checked': counts['overlap'],
                            'positive_witness_digest_sha256': witness_digest.hexdigest(),
                            'negative_full_slab_replays': counts['disjoint'],
                            'negative_slab_rows_checked': negative_slabs,
                            'negative_exact_saved_certificate_digest_sha256': negative_digest.hexdigest(),
                            'negative_saved_and_replayed_certificate_equality': True,
                            'only_imported_scientific_helper': 'reference/slab_geometry_checker_v1.py'},
        'existing_carrier_receipt': {'status': carrier['status'], 'reexecuted': False},
        'qualification_saved_records': qualification,
        'scope': 'Independent saved-data coverage/capacity audit, approved winding checks, and full negative slab checker replay. No tile-author, native experiment, triangle oracle, carrier checker, search or marking learner execution. Finite pair catalogue only; no region tiling, substitution or whole-plane conclusion.',
        'seconds': time.monotonic()-started,
    }
    output = RUN/'review/catalogue-independent-audit-v1.json'
    output.write_text(json.dumps(receipt, sort_keys=True, indent=2)+'\n')
    print(wire({'status': receipt['status'], 'output': str(output), 'output_pin': pin(output),
                'source_pin': receipt['utility_source'], 'counts': counts,
                'capacity_checks': capacity_checks, 'winding_checks': winding_checks,
                'negative_full_replays': counts['disjoint'], 'seconds': receipt['seconds']}), flush=True)


if __name__ == '__main__':
    main()
