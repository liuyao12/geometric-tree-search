"""Independent exact vertical-slab polygon-interior overlap oracle.

Inert Source; no existing geometry/search helpers are imported. Coordinates
are integer axial coordinates; an invertible drawing shear does not change
intersection topology. Fraction arithmetic is used for every constructed point.
"""
from fractions import Fraction
import hashlib
import json

VERSION = 'TURTLE-INDEPENDENT-VERTICAL-SLAB-v1'
MAX_VERTICES, MAX_COORD_BITS, MAX_WORK = 256, 256, 2000000


class GeometryInputError(ValueError):
    pass


class GeometryResourceLimit(GeometryInputError):
    pass


def _need(condition, reason):
    if not condition:
        raise GeometryInputError(reason)


class _Meter:
    def __init__(self):
        self.work = 0

    def tick(self, amount=1):
        self.work += amount
        if self.work > MAX_WORK:
            raise GeometryResourceLimit('EXACT_GEOMETRY_WORK_BOUND')


def _cross(u, v):
    return u[0]*v[1]-u[1]*v[0]


def _difference(a, b):
    return a[0]-b[0], a[1]-b[1]


def _orientation(a, b, p):
    return _cross(_difference(b,a),_difference(p,a))


def _on_segment(a, b, p):
    return (_orientation(a,b,p)==0 and min(a[0],b[0])<=p[0]<=max(a[0],b[0])
            and min(a[1],b[1])<=p[1]<=max(a[1],b[1]))


def _segments_meet(a, b, c, d):
    first, second = _orientation(a,b,c), _orientation(a,b,d)
    third, fourth = _orientation(c,d,a), _orientation(c,d,b)
    if first*second < 0 and third*fourth < 0:
        return True
    return ((first==0 and _on_segment(a,b,c)) or (second==0 and _on_segment(a,b,d))
            or (third==0 and _on_segment(c,d,a)) or (fourth==0 and _on_segment(c,d,b)))


def _polygon(value, meter):
    _need(type(value) in (list,tuple), 'POLYGON_VERTEX_SEQUENCE')
    if len(value)>MAX_VERTICES+1:
        raise GeometryResourceLimit('POLYGON_VERTEX_BOUND')
    points=[]
    for point in value:
        meter.tick()
        _need(type(point) in (list,tuple) and len(point)==2
              and all(type(x) is int for x in point), 'NATIVE_INTEGER_AXIAL_VERTEX')
        if any(x.bit_length()>MAX_COORD_BITS for x in point):
            raise GeometryResourceLimit('POLYGON_COORDINATE_BITS_BOUND')
        points.append((point[0],point[1]))
    if len(points)>1 and points[-1]==points[0]:
        points.pop()
    _need(len(points)>=3, 'POLYGON_AT_LEAST_THREE_VERTICES')
    if len(points)>MAX_VERTICES:
        raise GeometryResourceLimit('POLYGON_VERTEX_BOUND')
    _need(len(set(points))==len(points), 'DUPLICATE_POLYGON_VERTEX')
    edges=list(zip(points,points[1:]+points[:1]))
    area2=sum(_cross(a,b) for a,b in edges)
    _need(area2!=0, 'DEGENERATE_ZERO_AREA_POLYGON')
    for i,(a,b) in enumerate(edges):
        for j in range(i+1,len(edges)):
            meter.tick(); c,d=edges[j]
            adjacent=(j==i+1 or (i==0 and j==len(edges)-1))
            if adjacent:
                shared=b if j==i+1 else a
                left=a if j==i+1 else b
                right=d if j==i+1 else c
                u,v=_difference(left,shared),_difference(right,shared)
                # Forward collinear vertices are allowed; retracing an edge is not.
                _need(not (_cross(u,v)==0 and u[0]*v[0]+u[1]*v[1]>0), 'ADJACENT_BOUNDARY_RETRACING')
            else:
                _need(not _segments_meet(a,b,c,d), 'NON_SIMPLE_POLYGON_BOUNDARY')
    return points,edges,area2


def _rational(value):
    if type(value) is int:
        result=Fraction(value)
    elif type(value) is Fraction:
        result=value
    else:
        _need(type(value) in (list,tuple) and len(value)==2
              and all(type(x) is int for x in value) and value[1]!=0, 'EXACT_RATIONAL_COORDINATE')
        result=Fraction(value[0],value[1])
    if result.numerator.bit_length()>4096 or result.denominator.bit_length()>4096:
        raise GeometryResourceLimit('WITNESS_RATIONAL_BITS_BOUND')
    return result


def _winding_inside(point, edges, meter):
    """Strict winding-number test, independent of vertical-slab intervals."""
    winding=0
    for a,b in edges:
        meter.tick()
        if _on_segment(a,b,point):
            return False
        turn=_orientation(a,b,point)
        if a[1]<=point[1]<b[1] and turn>0:
            winding+=1
        elif b[1]<=point[1]<a[1] and turn<0:
            winding-=1
    return winding!=0


def point_inside_strict(point, polygon):
    """Return bool; point accepts ints, Fractions or [numerator,denominator].

    Invalid input/resource excess raises GeometryInputError or its resource
    subclass; an invalid polygon is never reported as an outside-point proof.
    """
    meter=_Meter(); _,edges,_=_polygon(polygon,meter)
    _need(type(point) in (list,tuple) and len(point)==2, 'POINT_COORDINATE_PAIR')
    exact=(_rational(point[0]),_rational(point[1]))
    return _winding_inside(exact,edges,meter)


def _intersection_x(a, b, c, d):
    r,s=_difference(b,a),_difference(d,c)
    determinant=_cross(r,s)
    if determinant==0:
        # Collinear overlap endpoints already occur among polygon vertex x's.
        return None
    delta=_difference(c,a)
    t=Fraction(_cross(delta,s),determinant)
    u=Fraction(_cross(delta,r),determinant)
    if 0<=t<=1 and 0<=u<=1:
        return Fraction(a[0])+t*r[0]
    return None


def _intervals(edges, x, meter):
    crossings=[]
    for a,b in edges:
        meter.tick()
        # Slab sample x is never a vertex x; vertical edges are thus excluded.
        if min(a[0],b[0])<x<max(a[0],b[0]):
            crossings.append(Fraction(a[1])+(x-a[0])*Fraction(b[1]-a[1],b[0]-a[0]))
    crossings.sort()
    _need(len(crossings)%2==0, 'SLAB_EVEN_ODD_INVARIANT')
    result=[]
    for i in range(0,len(crossings),2):
        _need(crossings[i]<crossings[i+1], 'SLAB_POSITIVE_INTERVAL_INVARIANT')
        result.append((crossings[i],crossings[i+1]))
    return result


def _pair(value):
    value=Fraction(value)
    return [value.numerator,value.denominator]


def _encoded_intervals(intervals):
    return [[_pair(low),_pair(high)] for low,high in intervals]


def _fingerprint(points):
    data=(json.dumps(points,separators=(',',':'))+'\n').encode('ascii')
    return hashlib.sha256(data).hexdigest()


def overlap(polyA, polyB):
    """Return an exact interior-overlap witness or a full disjoint-slab record.

    Touching boundaries have no positive-area overlap. Simple polygon interiors
    are open, so a shared strict interior point is equivalent to positive-area
    intersection. Failure to check an input/budget returns overlap=None.
    """
    meter=_Meter()
    try:
        a,ae,area_a=_polygon(polyA,meter)
        b,be,area_b=_polygon(polyB,meter)
        critical={Fraction(point[0]) for point in a+b}
        intersections=0
        for edge_a in ae:
            for edge_b in be:
                meter.tick()
                x=_intersection_x(*edge_a,*edge_b)
                if x is not None:
                    critical.add(x);intersections+=1
        ordered=sorted(critical);slabs=[]
        common={'version':VERSION,'polygon_a_sha256':_fingerprint(a),
                'polygon_b_sha256':_fingerprint(b),'vertex_counts':[len(a),len(b)],
                'signed_double_areas':[area_a,area_b],
                'critical_x':[_pair(x) for x in ordered],
                'critical_x_count':len(ordered),'slabs_total':max(0,len(ordered)-1),
                'closed_segment_nonparallel_intersections':intersections}
        for left,right in zip(ordered,ordered[1:]):
            meter.tick();x=(left+right)/2
            ia,ib=_intervals(ae,x,meter),_intervals(be,x,meter)
            row={'x_bounds':[_pair(left),_pair(right)],'sample_x':_pair(x),
                 'a_intervals':_encoded_intervals(ia),'b_intervals':_encoded_intervals(ib)}
            # Endpoint order cannot change in an open slab: its events are all
            # vertex x's and every closed cross-polygon segment intersection x.
            i=j=0
            while i<len(ia) and j<len(ib):
                meter.tick();low=max(ia[i][0],ib[j][0]);high=min(ia[i][1],ib[j][1])
                if low<high:
                    witness=(x,(low+high)/2)
                    _need(_winding_inside(witness,ae,meter) and _winding_inside(witness,be,meter), 'INDEPENDENT_WINDING_WITNESS_INVARIANT')
                    row['strict_intersection_y']=[_pair(low),_pair(high)];slabs.append(row)
                    return dict(common,status='VERIFIED',overlap=True,witness=[_pair(witness[0]),_pair(witness[1])],
                        witness_strictly_inside_both=True,slabs_checked=len(slabs),slabs=slabs,
                        work=meter.work,certificate='EXACT_RATIONAL_STRICT_INTERIOR_WITNESS',
                        scope='Exact polygon-interior test only; no tiling/search/marking or point-model faithfulness conclusion.')
                if ia[i][1]<=ib[j][1]:i+=1
                else:j+=1
            row['strict_intersection_y']=None;slabs.append(row)
        return dict(common,status='VERIFIED',overlap=False,witness=None,
                    slabs_checked=len(slabs),slabs=slabs,work=meter.work,
                    certificate='ALL_EXACT_OPEN_VERTICAL_SLABS_DISJOINT',
                    scope='Complete critical-slab certificate of zero interior intersection; boundary contact is permitted. No tiling/search or point-model faithfulness conclusion.')
    except GeometryResourceLimit as error:
        return {'status':'UNKNOWN','overlap':None,'witness':None,'reason':str(error),'version':VERSION,'work':meter.work}
    except GeometryInputError as error:
        return {'status':'REJECTED','overlap':None,'witness':None,'reason':str(error),'version':VERSION,'work':meter.work}
