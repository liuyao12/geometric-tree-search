"""Independent exact periodic-cell/angle carrier checker. Inert on import.

Only the separately approved triangle SAT and slab winding Sources execute
when verify is explicitly called. The point author/search code is not imported.
"""
from fractions import Fraction
from itertools import permutations
from math import gcd, lcm
from pathlib import Path
import importlib.util

VERSION = 'TURTLE-INDEPENDENT-CELL-CARRIER-CHECKER-v1'
MAX_WORK = 10000000
MAX_CELLS = 4096
MAX_VERTICES = 256
MAX_FIELD = 200000
MAX_BITS = 512
RAYS_UV = ((1, 0), (3, 1), (1, 1), (0, 1), (-1, 1), (-3, 1),
           (-1, 0), (-3, -1), (-1, -1), (0, -1), (1, -1), (3, -1))
FIELDS = {'polygon', 'groups', 'original_field', 'normal_families', 'cells',
          'scale', 'orbit_residues', 'sample_actions', 'occupancy_field',
          'combined_field', 'initial_markings'}


class InputError(ValueError):
    pass


class ResourceLimit(Exception):
    pass


def need(ok, reason):
    if not ok:
        raise InputError(reason)


class Meter:
    def __init__(self):
        self.work = 0

    def tick(self, n=1):
        self.work += n
        if self.work > MAX_WORK:
            raise ResourceLimit('CARRIER_WORK_BOUND')


def integer(x):
    need(type(x) is int, 'NATIVE_INTEGER_REQUIRED')
    if x.bit_length() > MAX_BITS:
        raise ResourceLimit('INTEGER_BITS_BOUND')
    return x


def sequence(x, cap, reason):
    need(type(x) is list, reason)
    if len(x) > cap:
        raise ResourceLimit(reason + '_BOUND')
    return x


def fields(x, names):
    need(type(x) is dict and set(x) == set(names), 'EXACT_FIELDS_REQUIRED')


def rational(x):
    need(type(x) is list and len(x) == 2, 'CANONICAL_RATIONAL_PAIR')
    n, d = integer(x[0]), integer(x[1])
    need(d > 0, 'POSITIVE_DENOMINATOR')
    value = Fraction(n, d)
    need(value.numerator == n and value.denominator == d, 'REDUCED_RATIONAL_REQUIRED')
    return value


def point(x, encoded=False):
    need(type(x) is list and len(x) == 2, 'POINT_PAIR')
    parse = rational if encoded else integer
    return parse(x[0]), parse(x[1])


def cross(u, v):
    return u[0] * v[1] - u[1] * v[0]


def sub(a, b):
    return a[0] - b[0], a[1] - b[1]


def orient(a, b, c):
    return cross(sub(b, a), sub(c, a))


def edge_list(p):
    return list(zip(p, p[1:] + p[:1]))


def double_area(p):
    return sum(cross(a, b) for a, b in edge_list(p))


def primitive(a, b):
    a, b = Fraction(a), Fraction(b)
    scale = lcm(a.denominator, b.denominator)
    x, y = int(a * scale), int(b * scale)
    divisor = gcd(abs(x), abs(y))
    need(divisor != 0, 'NONZERO_NORMAL_REQUIRED')
    x, y = x // divisor, y // divisor
    return (-x, -y) if x < 0 or x == 0 and y < 0 else (x, y)


def apply(m, p):
    return m[0][0] * p[0] + m[0][1] * p[1], m[1][0] * p[0] + m[1][1] * p[1]


def product(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(2)) for j in range(2)) for i in range(2))


def normal_image(n, m):
    a, b = m[0]; c, d = m[1]; determinant = a * d - b * c
    return primitive(Fraction(n[0] * d - n[1] * c, determinant),
                     Fraction(-n[0] * b + n[1] * a, determinant))


def helpers():
    root = Path(__file__).resolve().parents[1]
    loaded = []
    for name, path in [('_carrier_approved_triangle', root / 'source/triangle_geometry_v1.py'),
                       ('_carrier_approved_slab', root / 'reference/slab_geometry_checker_v1.py')]:
        spec = importlib.util.spec_from_file_location(name, path)
        need(spec is not None and spec.loader is not None, 'APPROVED_HELPER_SOURCE_MISSING')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        loaded.append(module)
    return loaded


def sparse_field(rows, meter):
    result, order = {}, []
    for row in sequence(rows, MAX_FIELD, 'FIELD_ROWS'):
        meter.tick()
        need(type(row) is list and len(row) == 3, 'FIELD_TRIPLE')
        x, y, units = [integer(v) for v in row]
        need(1 <= units <= 12 and (x, y) not in result, 'POSITIVE_UNIQUE_FIELD_SUPPORT')
        result[x, y] = units
        order.append((x, y))
    need(order == sorted(order), 'CANONICAL_FIELD_ORDER')
    return result


def inside(p, poly, slab, meter):
    # The approved independent oracle validates its polygon on every call.
    meter.tick(1 + len(poly) ** 2)
    return slab.point_inside_strict(p, poly)


def _verify(model, meter):
    fields(model, FIELDS)
    need(model['initial_markings'] == [] and type(model['initial_markings']) is list, 'NO_INITIAL_MARKINGS')
    polygon = [point(p) for p in sequence(model['polygon'], MAX_VERTICES, 'POLYGON_VERTICES')]
    need(len(polygon) >= 3 and len(set(polygon)) == len(polygon), 'DISTINCT_POLYGON_VERTICES')
    poly = [list(p) for p in polygon]
    triangle, slab = helpers()
    inside((Fraction(0), Fraction(0)), poly, slab, meter)  # Also validates the entire simple boundary.
    edges = edge_list(polygon)
    groups, signatures = {}, set()
    all_pairs = {(s, p) for s in (-1, 1) for p in permutations(range(3))}
    for g in sequence(model['groups'], 12, 'GROUP_ROWS'):
        fields(g, ('id', 'permutation', 'sign', 'matrix'))
        gid, sign = integer(g['id']), integer(g['sign'])
        perm = tuple(integer(v) for v in sequence(g['permutation'], 3, 'PERMUTATION'))
        need((sign, perm) in all_pairs and gid not in groups and 0 <= gid < 12, 'D6_GROUP_DESCRIPTOR')
        need((sign, perm) not in signatures, 'DUPLICATE_GROUP_DESCRIPTOR')
        signatures.add((sign, perm))
        ex, ey = (1, 0, -1), (0, 1, -1)
        expected = ((sign * ex[perm[0]], sign * ey[perm[0]]),
                    (sign * ex[perm[1]], sign * ey[perm[1]]))
        rows = sequence(g['matrix'], 2, 'MATRIX_ROWS')
        matrix = tuple(tuple(integer(v) for v in sequence(row, 2, 'MATRIX_COLUMNS')) for row in rows)
        need(matrix == expected, 'SIGNED_A2_PERMUTATION_MATRIX')
        need(abs(matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]) == 1, 'UNIMODULAR_GROUP')
        metric = ((2, 1), (1, 2))
        transpose = tuple(zip(*matrix))
        need(product(product(transpose, metric), matrix) == metric, 'A2_METRIC_PRESERVATION')
        groups[gid] = matrix
    need(signatures == all_pairs and len(set(groups.values())) == 12, 'COMPLETE_TWELVE_GROUP_ELEMENTS')
    matrix_ids = {m: i for i, m in groups.items()}
    for a in groups.values():
        for b in groups.values():
            meter.tick()
            need(product(a, b) in matrix_ids, 'GROUP_CLOSURE')
    base_normals = {(1, 0), (0, 1)}
    for a, b in edges:
        delta = sub(b, a)
        base_normals.add(primitive(delta[1], -delta[0]))
    required = {normal_image(n, m) for n in base_normals for m in groups.values()}
    normals = [point(n) for n in sequence(model['normal_families'], 128, 'NORMAL_FAMILIES')]
    need(normals == sorted(required), 'EXACT_EDGE_AND_GRID_NORMAL_ORBITS')
    for n in normals:
        need(primitive(*n) == n, 'PRIMITIVE_CANONICAL_NORMAL')
        for m in groups.values():
            meter.tick()
            need(normal_image(n, m) in required, 'CONTRAGREDIENT_NORMAL_CLOSURE')

    cells, samples, cell_areas, fans = [], [], [], []
    for row in sequence(model['cells'], MAX_CELLS, 'CELL_ROWS'):
        fields(row, ('vertices', 'sample', 'area2'))
        vertices = [point(p, True) for p in sequence(row['vertices'], 64, 'CELL_VERTICES')]
        need(len(vertices) >= 3 and len(set(vertices)) == len(vertices), 'DISTINCT_CELL_VERTICES')
        need(vertices[0] == min(vertices), 'CANONICAL_FIRST_CELL_VERTEX')
        need(all(0 <= x <= 1 and 0 <= y <= 1 for x, y in vertices), 'CELL_IN_FUNDAMENTAL_SQUARE')
        area = double_area(vertices)
        need(area > 0 and rational(row['area2']) == area, 'EXACT_POSITIVE_CCW_AREA')
        for i, p in enumerate(vertices):
            meter.tick()
            need(orient(vertices[i - 1], p, vertices[(i + 1) % len(vertices)]) > 0, 'STRICT_CELL_CORNERS')
        # Strict left-half-plane tests for ALL vertices exclude self-crossing
        # stars which a local-turn test alone could accidentally admit.
        for i, (a, b) in enumerate(edge_list(vertices)):
            for j, v in enumerate(vertices):
                meter.tick()
                if j not in (i, (i + 1) % len(vertices)):
                    need(orient(a, b, v) > 0, 'GLOBAL_STRICT_CONVEX_CELL')
            n = primitive(b[1] - a[1], a[0] - b[0])
            need(n in required and (n[0] * a[0] + n[1] * a[1]).denominator == 1,
                 'CELL_FACET_ON_DECLARED_INTEGER_ARRANGEMENT')
        sample = point(row['sample'], True)
        mean = tuple(sum(v[k] for v in vertices) / len(vertices) for k in (0, 1))
        need(sample == mean and 0 < sample[0] < 1 and 0 < sample[1] < 1, 'EXACT_VERTEX_MEAN')
        need(all(orient(a, b, sample) > 0 for a, b in edge_list(vertices)), 'STRICT_SAMPLE_INTERIOR')
        for a, b in normals:
            meter.tick(len(vertices))
            value = a * sample[0] + b * sample[1]
            need(value.denominator != 1, 'SAMPLE_OFF_ALL_ARRANGEMENT_LINES')
            lo = value.numerator // value.denominator
            need(all(lo <= a * x + b * y <= lo + 1 for x, y in vertices), 'CELL_WITHIN_ONE_NORMAL_STRIP')
        cells.append(vertices); samples.append(sample); cell_areas.append(area)
        fans.append([(vertices[0], vertices[i], vertices[i + 1]) for i in range(1, len(vertices) - 1)])
    need(bool(cells) and len(set(samples)) == len(samples), 'NONEMPTY_DISTINCT_CELL_SAMPLES')
    need(sum(cell_areas) == 2, 'EXACT_UNIT_SQUARE_AREA_SUM')
    sat_calls = 0
    for i, a in enumerate(cells):
        for j in range(i):
            b = cells[j]
            meter.tick()
            if any(max(p[k] for p in a) <= min(p[k] for p in b)
                   or max(p[k] for p in b) <= min(p[k] for p in a) for k in (0, 1)):
                continue  # Bounding boxes only reject impossible positive overlap.
            for ta in fans[i]:
                for tb in fans[j]:
                    meter.tick(100); sat_calls += 1
                    need(not triangle.positive_overlap(ta, tb), 'CELL_INTERIORS_OVERLAP')

    scale = integer(model['scale'])
    need(scale > 0, 'POSITIVE_SCALE')
    required_scale = 1
    for sample in samples:
        for value in sample:
            required_scale = lcm(required_scale, value.denominator)
            if required_scale.bit_length() > MAX_BITS:
                raise ResourceLimit('SAMPLE_SCALE_BITS_BOUND')
    need(scale == required_scale, 'CANONICAL_COMMON_SAMPLE_DENOMINATOR')
    residues = [point(p) for p in sequence(model['orbit_residues'], MAX_CELLS, 'ORBIT_RESIDUES')]
    expected_residues = [(int(x * scale), int(y * scale)) for x, y in samples]
    need(residues == expected_residues and len(set(residues)) == len(residues), 'EXACT_SAMPLE_RESIDUE_ORDER')
    phase = {s: i for i, s in enumerate(samples)}
    actions = {}
    for a in sequence(model['sample_actions'], 12, 'SAMPLE_ACTION_ROWS'):
        fields(a, ('group', 'sample_permutation', 'integer_shifts'))
        gid = integer(a['group'])
        need(gid in groups and gid not in actions, 'UNIQUE_GROUP_SAMPLE_ACTION')
        perm = [integer(v) for v in sequence(a['sample_permutation'], MAX_CELLS, 'SAMPLE_PERMUTATION')]
        shifts = [point(p) for p in sequence(a['integer_shifts'], MAX_CELLS, 'SAMPLE_SHIFTS')]
        need(len(perm) == len(shifts) == len(samples) and set(perm) == set(range(len(samples))), 'SAMPLE_ACTION_BIJECTION')
        for i, sample in enumerate(samples):
            meter.tick(len(cells[i]) + 1)
            image = apply(groups[gid], sample)
            shift = tuple(v.numerator // v.denominator for v in image)
            reduced = sub(image, shift)
            need(reduced in phase and perm[i] == phase[reduced] and shifts[i] == shift, 'EXACT_SAMPLE_PHASE_AND_SHIFT')
            vertices = {sub(apply(groups[gid], v), shift) for v in cells[i]}
            need(vertices == set(cells[perm[i]]), 'EXACT_GLOBAL_CELL_ACTION')
        actions[gid] = (perm, shifts)
    need(set(actions) == set(groups), 'ALL_TWELVE_SAMPLE_ACTIONS')
    for g, mg in groups.items():
        for h, mh in groups.items():
            combined = matrix_ids[product(mg, mh)]
            pg, sg = actions[g]; ph, sh = actions[h]; pc, sc = actions[combined]
            for i in range(len(samples)):
                meter.tick()
                delta = apply(mg, sh[i])
                need(pc[i] == pg[ph[i]] and sc[i] == (delta[0] + sg[ph[i]][0], delta[1] + sg[ph[i]][1]),
                     'SAMPLE_ACTION_COMPOSITION')

    low = tuple(min(p[k] for p in polygon) for k in (0, 1))
    high = tuple(max(p[k] for p in polygon) for k in (0, 1))
    box = (high[0] - low[0] + 1) * (high[1] - low[1] + 1)
    if box > MAX_FIELD or box * len(samples) > MAX_FIELD:
        raise ResourceLimit('SUPPORT_ENUMERATION_BOUND')
    occupancy = {}
    for x in range(low[0], high[0]):
        for y in range(low[1], high[1]):
            for sample in samples:
                p = (sample[0] + x, sample[1] + y)
                if inside(p, poly, slab, meter):
                    sx, sy = p[0] * scale, p[1] * scale
                    need(sx.denominator == sy.denominator == 1, 'SCALED_OCCUPANCY_INTEGER')
                    occupancy[int(sx), int(sy)] = 12
    need(sparse_field(model['occupancy_field'], meter) == occupancy, 'COMPLETE_ROOT_OCCUPANCY_SUPPORT')

    boundary_rays = [(u - v, 2 * v) for u, v in RAYS_UV]
    sector_rays = [(a[0] + b[0] - a[1] - b[1], 2 * (a[1] + b[1]))
                   for a, b in zip(RAYS_UV, RAYS_UV[1:] + RAYS_UV[:1])]
    for a, b in edges:
        delta = sub(b, a)
        need(any(cross(delta, r) == 0 for r in boundary_rays), 'EDGE_ALIGNED_WITH_TWELVE_SECTOR_BOUNDARIES')
        need(all(cross(d, delta) != 0 for d in sector_rays), 'SECTOR_WITNESS_TRANSVERSE_TO_ALL_EDGES')
    angular = {}
    for x in range(low[0], high[0] + 1):
        for y in range(low[1], high[1] + 1):
            p, units = (x, y), 0
            for direction in sector_rays:
                hits = []
                for a, b in edges:
                    meter.tick()
                    edge, offset = sub(b, a), sub(a, p)
                    det = cross(direction, edge)
                    t = Fraction(cross(offset, edge), det)
                    u = Fraction(cross(offset, direction), det)
                    if t > 0 and 0 <= u <= 1:
                        hits.append(t)
                epsilon = min(hits) / 2 if hits else Fraction(1)
                q = p[0] + epsilon * direction[0], p[1] + epsilon * direction[1]
                units += int(inside(q, poly, slab, meter))
            if units:
                angular[p] = units
    need(sparse_field(model['original_field'], meter) == angular, 'EXACT_INDEPENDENT_TWELVE_SECTOR_ANGULAR_FIELD')
    scaled_angular = {(x * scale, y * scale): u for (x, y), u in angular.items()}
    need(not set(scaled_angular).intersection(occupancy), 'ANGLE_AND_CELL_POINT_DOMAINS_DISJOINT')
    need(sparse_field(model['combined_field'], meter) == {**scaled_angular, **occupancy}, 'EXACT_COMBINED_CAPACITY_TWELVE_FIELD')
    return dict(status='VERIFIED', reason='EXACT_FINITE_PERIODIC_CELL_AND_ANGULAR_CERTIFICATE',
        groups=len(groups), normals=len(normals), cells=len(cells), triangle_SAT_calls=sat_calls,
        scale=scale, occupancy_points=len(occupancy), angular_points=len(angular),
        combined_points=len(occupancy) + len(angular), lattice_bbox_points=box,
        rational_phase_actions_and_compositions=True, all_cell_interiors_disjoint=True,
        angular_method='Twelve off-edge sector rays, epsilon before first positive segment hit, independent winding.',
        support_scope='Every listed support checked, including zero complement outside the complete finite bbox.',
        global_scope='Conditional periodic integer-translation/D6 carrier argument under the documented polygon-boundary arrangement hypotheses. Not a plane tiling, substitution, marking learner or growth result.')


def verify(model):
    meter = Meter()
    try:
        result = _verify(model, meter)
    except (ResourceLimit, RecursionError, MemoryError) as error:
        result = dict(status='UNKNOWN', reason=str(error) or type(error).__name__)
    except Exception as error:
        # The approved slab oracle has its own explicitly named resource class.
        status = 'UNKNOWN' if type(error).__name__ == 'GeometryResourceLimit' else 'REJECTED'
        result = dict(status=status, reason=str(error), error_type=type(error).__name__)
    result.update(schema='Turtle-independent-carrier-check-receipt-v1', version=VERSION, work=meter.work)
    return result
