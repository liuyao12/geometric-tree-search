"""Frozen exact pair qualification; no previous search/marking imports."""
import gzip
import hashlib
import json
from pathlib import Path
import platform
import resource
import sys
import time
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference'))
import turtle_points_v1 as points
import triangle_geometry_v1 as triangle
import slab_geometry_checker_v1 as slab
from carrier_checker_v1 import verify as verify_carrier

def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(wire(x)).hexdigest()
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);raw=wire(value)
    if path.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
    with path.open('xb') as f:f.write(raw)
def emit(kind,**kw):print(wire(dict(kind=kind,**kw)).decode().strip(),flush=True)
def pins():
    files=[p for dirname in ('source','reference') for p in (ROOT/dirname).glob('*.py')]
    files+=[ROOT/'reference/turtle-reentry-status-v1.json']
    files+=list((ROOT/'reference/public-snapshot').glob('*'))
    return {str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files) if p.is_file()}

def freeze():
    original=json.loads((ROOT/'reference/turtle-reentry-status-v1.json').read_text())['point_model']
    value=dict(schema='Turtle-pair-qualification-protocol-v1',polygon3=original['turtle_loop'],literal_vertex_units=original['vertex_units'],initial_markings=[],
        transformation='All six A2 coordinate permutations and common sign plus full integer A2 translations. Root fixed to identity by this verified group action.',
        catalogue='All inclusive integer relative translations with intersecting closed axial bounding boxes, every group element. Distinct polygon/point placements deduplicated; root-identical placement excluded. Disjoint boxes are analytically safe outside this finite envelope.',
        geometry='Independent exact ear-triangulation/triangle-SAT/rational-clipping and vertical-slab interval geometry. Every positive witness independently winding-checked; touches alone legal.',
        models='Reauthor the original angular/A2 point field exactly. Independently verify a new periodic boundary-arrangement occupancy carrier and its combination with angular points. All use capacity12 and empty markings. Geometry is a qualification/authoring oracle, never hidden base-search legality.',
        new_model_scope='New problem-defining point model if old pair capacity admits polygon overlap. Not a learned m rule, old-model redundant constraint or plane/substitution discovery. All model outcomes retained regardless of mismatch.',
        resource_limits=dict(max_pairs=20000,wall_seconds=600),pins=pins())
    write(ROOT/'data/protocol-frozen-v1.json',value);emit('FROZEN',sha256=sha(value))

def validate_witness(result,a,b):
    if not result['overlap']:return
    if isinstance(result['witness'],dict):
        ring=result['witness']['intersection'];p=tuple(sum(F(v[i][0],v[i][1]) for v in ring)/len(ring) for i in range(2))
    else:p=tuple(F(n,d) for n,d in result['witness'])
    assert points.inside(p,a) and points.inside(p,b)
    assert slab.point_inside_strict(p,a) and slab.point_inside_strict(p,b)

def qualify():
    square=[(0,0),(2,0),(2,2),(0,2)]
    L=[(0,0),(3,0),(3,1),(1,1),(1,3),(0,3)]
    cases=[('identical',square,square,True),('edge-touch',square,points.moved(square,(2,0)),False),
        ('vertex-touch',square,points.moved(square,(2,2)),False),('disjoint',square,points.moved(square,(3,0)),False),
        ('parallel-strip',square,points.moved(square,(1,0)),True),('clockwise',list(reversed(square)),square,True),
        ('collinear-entry',[(0,0),(1,0),(2,0),(2,2),(0,2)],square,True),
        ('concave-hole',L,[(2,2),(3,2),(3,3),(2,3)],False),
        ('containment',[(0,0),(4,0),(4,4),(0,4)],[(1,1),(2,1),(2,2),(1,2)],True),
        ('crossing-strips',[(0,1),(4,1),(4,2),(0,2)],[(1,0),(2,0),(2,4),(1,4)],True)]
    records=[]
    for name,a,b,expected in cases:
        t=triangle.polygon_overlap(a,b);s=slab.overlap(a,b)
        assert s['status']=='VERIFIED' and s['overlap']==t['overlap']==expected,(name,t,s)
        validate_witness(t,a,b);validate_witness(s,a,b);records.append(dict(name=name,expected=expected,triangle=t,slab=s))
    for name,a in [('self-crossing',[(0,0),(2,2),(0,2),(2,0)]),('degenerate',[(0,0),(1,0),(2,0)])]:
        try:triangle.triangulate(a)
        except ValueError:pass
        else:raise AssertionError('Malformed boundary admitted')
        s=slab.overlap(a,square);assert s['status']=='REJECTED' and s['overlap'] is None
        records.append(dict(name=name,expected='REJECTED',slab=s))
    write(ROOT/'qualification-v1.json',dict(status='PASS',fixtures=records));emit('QUALIFIED',fixtures=len(records))

def construct(protocol):
    p3=protocol['polygon3'];origin=p3[0];poly=[(p[0]-origin[0],p[1]-origin[1]) for p in p3]
    assert all(sum(p)==0 for p in p3)
    triangle.validate_polygon(poly)
    assert points.vertex_units(poly)==protocol['literal_vertex_units']
    gs=points.groups();gc=points.group_checks(gs);a=points.arrangement(poly,gs)
    model=dict(polygon=poly,groups=gs,original_field=points.field_rows(points.angular_field(poly)),
        normal_families=a['normals'],cells=[dict(vertices=points.encode_poly(cell),sample=points.encode_point(sample),area2=[F(points.area2(list(cell))).numerator,F(points.area2(list(cell))).denominator]) for cell,sample in zip(a['cells'],a['samples'])],
        scale=a['scale'],orbit_residues=a['residues'],sample_actions=a['group_actions'],
        occupancy_field=points.field_rows(a['occupancy']),combined_field=points.field_rows(a['combined']),initial_markings=[])
    # The certificate API is native JSON; tuples used during authoring become
    # arrays before the independent checker sees the model.
    model=json.loads(wire(model))
    checked=verify_carrier(model);assert checked['status']=='VERIFIED',checked
    write(ROOT/'data/exact-point-model-v1.json',model);write(ROOT/'data/carrier-check-v1.json',checked)
    return poly,gs,a,model,gc,checked

def execute():
    protocol=json.loads((ROOT/'data/protocol-frozen-v1.json').read_text());assert protocol['pins']==pins(),'Source changed after freeze'
    start=time.perf_counter();qualify();poly,gs,arr,model,group_check,carrier_check=construct(protocol)
    scale=arr['scale'];root_original=points.angular_field(poly);root_triangles=triangle.triangulate(poly)
    root_key=points.canonical_polygon(poly);seen=set();pairs=[];raw_positions=0;duplicates=0;root_excluded=0
    stats=dict(original_legal_overlap=0,original_illegal_disjoint=0,occupancy_mismatches=0,combined_mismatches=0,
               overlap=0,disjoint=0,no_common_original_points=0)
    complete=True;reason=None
    for g in gs:
        oriented=points.transform_poly(poly,g['matrix']);original={points.transform(p,g['matrix']):u for p,u in root_original.items()}
        assert original==points.angular_field(oriented)
        occupied={points.transform(p,g['matrix']):u for p,u in arr['occupancy'].items()}
        combined={points.transform(p,g['matrix']):u for p,u in arr['combined'].items()}
        triangles=triangle.triangulate(oriented)
        xr=range(min(p[0] for p in poly)-max(p[0] for p in oriented),max(p[0] for p in poly)-min(p[0] for p in oriented)+1)
        yr=range(min(p[1] for p in poly)-max(p[1] for p in oriented),max(p[1] for p in poly)-min(p[1] for p in oriented)+1)
        for dx in xr:
            for dy in yr:
                raw_positions+=1;shift=dx,dy;second=points.moved(oriented,shift);key=points.canonical_polygon(second)
                if key==root_key:root_excluded+=1;continue
                if key in seen:duplicates+=1;continue
                seen.add(key)
                if len(pairs)>=protocol['resource_limits']['max_pairs'] or time.perf_counter()-start>protocol['resource_limits']['wall_seconds']:
                    complete=False;reason='RESOURCE_LIMIT';break
                moved_triangles=[points.moved(list(t),shift) for t in triangles]
                t=triangle.triangulations_overlap(root_triangles,moved_triangles);s=slab.overlap(poly,second)
                assert s['status']=='VERIFIED' and t['overlap']==s['overlap'],(g,shift,t,s)
                validate_witness(t,poly,second);validate_witness(s,poly,second)
                old_bad=points.excess(root_original,original,shift)
                occ_bad=points.excess(arr['occupancy'],occupied,shift,scale)
                full_bad=points.excess(arr['combined'],combined,shift,scale)
                common=len(set(root_original).intersection((x+dx,y+dy) for x,y in original))
                overlap=t['overlap'];old_legal=not old_bad
                stats['overlap' if overlap else 'disjoint']+=1
                stats['original_legal_overlap']+=overlap and old_legal
                stats['original_illegal_disjoint']+=not overlap and not old_legal
                stats['occupancy_mismatches']+=bool(occ_bad)!=overlap
                stats['combined_mismatches']+=bool(full_bad)!=overlap
                stats['no_common_original_points']+=common==0
                pairs.append(dict(group=g['id'],translation=list(shift),geometry_overlap=overlap,
                    original_capacity_legal=old_legal,occupancy_capacity_legal=not occ_bad,combined_capacity_legal=not full_bad,
                    common_original_support=common,original_excess_count=len(old_bad),first_original_excess=old_bad[:1],
                    occupancy_excess_count=len(occ_bad),first_occupancy_excess=occ_bad[:1],
                    combined_excess_count=len(full_bad),first_combined_excess=full_bad[:1],triangle=t,slab=s))
                if len(pairs)%100==0:emit('PAIRS',checked=len(pairs),original_false_accepts=stats['original_legal_overlap'],seconds=time.perf_counter()-start)
            if not complete:break
        if not complete:break
    assert stats['occupancy_mismatches']==stats['combined_mismatches']==0
    assert stats['original_illegal_disjoint']==0
    assert protocol['pins']==pins()
    result=dict(schema='Turtle-exact-point-qualification-v1',status='COMPLETE' if complete else 'UNKNOWN',reason=reason,
        protocol=protocol,model=model,group_check=group_check,carrier_check=carrier_check,pairs=pairs,counts=stats,
        catalogue=dict(checked_pairs=len(pairs),raw_positions=raw_positions,duplicates=duplicates,root_identical_excluded=root_excluded,complete=complete),
        seconds=time.perf_counter()-start,peak_ru_maxrss_native=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        environment=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),rss_units='bytes' if sys.platform=='darwin' else 'platform-native'),
        scope='Exact finite relative-pair qualification and independently checked carrier construction. No tiling search, marking learning, RL, substitution discovery or plane-tiling witness executed.')
    write(ROOT/'data/results-v1.json.gz',result);emit('COMPLETE' if complete else 'UNKNOWN',counts=stats,catalogue=result['catalogue'],seconds=result['seconds'])

if __name__=='__main__':
    if sys.argv[1:]==['freeze']:freeze()
    elif sys.argv[1:]==['run']:execute()
    else:raise SystemExit('Choose freeze or run')
