Exact Turtle point/geometry qualification, 2026-11-03.
This experiment independently reauthors the published Turtle prototype using
exact integer/rational arithmetic and empty markings. It exhausts all relative
integer translations with meeting closed axial bounding boxes for all twelve
signed-coordinate actions. No shared-support prefilter is used. The coincident
root placement is excluded once; all 2443 distinct pairs are retained.

Both geometry oracles agree with the original28-point angular field on every
pair. A separate periodic arrangement carrier has240occupied sample points and
268combined support points; it is independent corroboration and is not needed
to replace the original model. Independent saved-data auditing reconstructs the
catalogue, recalculates all fields, verifies positive witnesses and replays
negative slab certificates. Consult its exact receipt for assurance scope.
The static packing metatheorem uses angular-sector disjointness for aggregate
capacity, not an invalid inference from pairwise weighted capacity alone.

There is no tiling search, matching-rule learning, RL run, substitution discovery,
fair plane-growth certificate or proof that the Turtle tiles the plane here.
The historical JavaScript scientific code was never imported or executed.
Public GitHub snapshots were byte/Git-blob pinned; unread local dataless modified
Sources are not claimed equivalent. Known marking arrays in the archival public
HTML were not imported as experimental data.

Reproduction: use a FRESH copy, preserve this evidence copy, and remove generated
data/, logs, package/ and publication/ outputs. Python3.12 standard library only.
Add source/ to sys.path and execute source/experiment_v1.py with argument freeze,
then argument run. The pinned original runtime path/hash and exact source pins
are in the frozen protocol and native result. The report renderer is passive.
The earlier freeze differs only by the pre-execution tuple-to-JSON interface
conversion before calling the independent carrier checker.

All task-owned Sources, snapshots, certificates, logs and local paths are public
with the user's explicit approval at the existing GitHub Pages destination.
No unrelated checkout changes or retired materials research are included.
This archive cut excludes package/ and publication/ to prevent recursion;
later deployment/verification receipts remain in the local completed run.
