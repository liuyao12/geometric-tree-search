"""Compare a marking test at each exact query against the same unmarked search."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load, pin, save
from early_v1 import early_scan, reach
from screen_v1 import measured, region
from stencil_v1 import blocked, carrier, residue


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / n) == v for n, v in protocol["pins"].items())
    source = load("input/exact-point-model-v1.json")
    model = Model(source)
    _, unordered = carrier(source)
    templates = {r: tuple(tuple(sorted(s, key=reach)) for s in items)
                 for r, items in unordered.items()}
    bank = defaultdict(list)
    for row in load("input/patterns-v1.json"):
        r = tuple(row["residue"])
        pattern = tuple(map(tuple, row["points"]))
        assert all(set(pattern) & support for support in unordered[r])
        bank[r].append((pattern, row["origin"]))
    library = [tuple(map(tuple, p)) for p in load("input/three-bank-v1.json")["bank"]]
    seen = set()
    for line in (ROOT / "input/early-cases-v1.jsonl").read_text().splitlines():
        row = json.loads(line)
        seen.add((row["ratio"], row["type"]))
    summaries = {}
    index = 0
    with (ROOT / "data/cases-v1.jsonl").open("x", buffering=1) as output:
        for spec in protocol["scales"]:
            ratio = spec["ratio"]
            prior_path = ROOT / f"input/ratio-{ratio:02d}-v1.jsonl"
            prior = {row["type"]: row for row in map(json.loads, prior_path.read_text().splitlines())}
            ids = [i for i in range(len(library)) if (ratio, i) not in seen]
            ids = sorted(ids, key=lambda i: hashlib.sha256(
                f"Turtle-interleaved-root-v1:{ratio}:{i}".encode()).digest())[:spec["sample"]]
            assert len(ids) == spec["sample"]
            counts = Counter()
            for i in ids:
                pieces = library[i]
                target = region(model, pieces, spec["matrix"], ratio)
                if index % 2 == 0:
                    direct, direct_ns = measured(early_scan, target, templates, model.scale)
                    marked, marked_ns = measured(early_scan, target, templates, model.scale, bank)
                else:
                    marked, marked_ns = measured(early_scan, target, templates, model.scale, bank)
                    direct, direct_ns = measured(early_scan, target, templates, model.scale)
                q = direct["point"]
                assert q == marked["point"] and direct["queries"] == marked["queries"]
                certificate = marked.get("certificate")
                if certificate:
                    stencil = set(certificate["stencil"])
                    assert certificate["point"] == q
                    assert all(blocked(q, p, target, set()) for p in stencil)
                    assert all(stencil & support for support in unordered[residue(q, model.scale)])
                    assert direct["alignments"] - marked["alignments"] == 240
                else:
                    assert direct == marked
                if ratio == 1:
                    support = [set(model.support(p)) for p in pieces]
                    assert set().union(*support) == target
                    assert sum(map(len, support)) == len(target)
                    assert q is None
                else:
                    assert (q is not None) == (prior[i]["empty"] > 0)
                counts.update(["cases", "root_empty" if q is not None else "root_full",
                               "certified_hit" if certificate else "no_hit",
                               "interleaved_faster" if marked_ns < direct_ns else "interleaved_not_faster"])
                counts["exact_early_ns"] += direct_ns
                counts["interleaved_ns"] += marked_ns
                row = dict(type=i, ratio=ratio, direct=direct, marked=marked,
                           exact_early_ns=direct_ns, interleaved_ns=marked_ns, early_first=index % 2 == 0)
                if ratio == 1:
                    row["witness"] = pieces
                output.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
                index += 1
            summaries[ratio] = dict(counts)
            print(json.dumps(dict(ratio=ratio, **counts), sort_keys=True), flush=True)
    save("data/summary-v1.json", dict(status="CHECKED_INTERLEAVED_STENCIL_CONTROL", scales=summaries,
         scope="Frozen disjoint follow-up subset. Every checked positive control has an identity partition. Both methods use the same query and legal-alignment order. Single-process CPU for the root kernel."))


if __name__ == "__main__":
    main()
