"""Exact cover of the two surviving Turtle inflation carriers."""

from functools import lru_cache
from fractions import Fraction
import gzip
import hashlib
from itertools import combinations
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def load(path):
    return json.loads((ROOT/path).read_bytes())


def pin(path):
    b=path.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def bits(mask):
    while mask:
        bit=mask & -mask
        yield bit.bit_length()-1
        mask^=bit


def solve(supports,count,limits):
    started=time.perf_counter()
    users=[0]*count
    masks=[]
    for c,sites in enumerate(supports):
        masks.append(sum(1<<i for i in sites))
        for i in sites:
            users[i]|=1<<c
    conflicts=[]
    for sites in supports:
        mask=0
        for i in sites:
            mask|=users[i]
        conflicts.append(mask)
    visits=0
    maximum=0
    witness=None
    stack=[]

    def visit(missing,available):
        nonlocal visits,maximum,witness
        if visits>=limits["visits"] or time.perf_counter()-started>=limits["seconds"]:
            return {"status":"UNKNOWN"}
        visits+=1
        maximum=max(maximum,len(stack))
        if missing==0:
            witness=tuple(stack)
            return {"status":"POSITIVE"}
        chosen=None
        degree=len(supports)+1
        for i in bits(missing):
            possible=users[i]&available
            count=possible.bit_count()
            if count==0:
                return {"status":"NEGATIVE","atom":i,"children":[]}
            if count<degree:
                degree=count
                chosen=i,possible
        assert chosen is not None
        i,possible=chosen
        children=[]
        for c in bits(possible):
            stack.append(c)
            child=visit(missing^masks[c],available&~conflicts[c])
            stack.pop()
            children.append([c,child])
            if child["status"]!="NEGATIVE":
                return dict(status=child["status"],atom=i,children=children)
        return dict(status="NEGATIVE",atom=i,children=children)
    tree=visit((1<<count)-1,(1<<len(supports))-1)
    return dict(status=tree["status"],witness=witness,tree=tree,visits=visits,
                max_selected=maximum,seconds=time.perf_counter()-started)


def matrix_move(matrix,p):
    a,b=matrix
    x,y=p
    return a[0]*x+a[1]*y,b[0]*x+b[1]*y


def qualify():
    limit=dict(visits=200,seconds=1)
    for supports,n,out in [([(0,1),(2,3)],4,"POSITIVE"),
                           ([(0,1),(1,2)],3,"NEGATIVE"),
                           ([(0,),(1,)],3,"NEGATIVE")]:
        assert solve(supports,n,limit)["status"]==out


def verify(row,model,raw,oriented,limit):
    started=time.perf_counter()
    points=[tuple(q) for q in row["target"]]
    target=set(points)
    placements=[tuple(q) for q in row["placements"]]
    scale=model["scale"]
    if raw["status"]=="UNKNOWN":
        return dict(status="UNKNOWN",reason="BOUNDED_SEARCH")
    if raw["status"]=="POSITIVE":
        import triangle_geometry_v1 as exact
        polygon=[tuple(p) for p in row["polygon"]]
        target_tri=exact.triangulate(polygon)
        actual=[]
        for c in raw["witness"]:
            g,dx,dy=placements[c]
            base=oriented[g][0]
            tile=[(x+dx,y+dy) for x,y in base]
            tri=exact.triangulate(tile)
            inside=Fraction(0)
            for a in tri:
                for b in target_tri:
                    piece=exact._clip(a,b)
                    if len(piece)>=3:
                        inside+=abs(exact._signed_area2(piece))
            assert inside==exact.area2(tile)
            actual.append((tile,tri))
        assert len(actual)==row["ratio"]
        for (_,a),(_,b) in combinations(actual,2):
            assert not any(exact.positive_overlap(x,y) for x in a for y in b)
        assert sum(exact.area2(t) for t,_ in actual)==exact.area2(polygon)
        return dict(status="VERIFIED",scope="EXACT_POLYGON_PARTITION",
                    placements=[placements[c] for c in raw["witness"]],seconds=time.perf_counter()-started)
    nodes=0

    @lru_cache(maxsize=16000)
    def domains(point):
        x,y=point
        result={}
        for g,(_,sites) in oriented.items():
            for a,b in sites:
                dx,dy=x-a,y-b
                if dx%scale or dy%scale:
                    continue
                cover=frozenset((u+dx,v+dy) for u,v in sites)
                if cover<=target:
                    key=g,dx//scale,dy//scale
                    assert key not in result
                    result[key]=cover
        return result

    def replay(node,covered):
        nonlocal nodes
        nodes+=1
        if time.perf_counter()-started>=limit:
            raise TimeoutError
        assert node["status"]=="NEGATIVE"
        point=points[node["atom"]]
        assert point not in covered
        legal={key:sites for key,sites in domains(point).items() if not covered&sites}
        children={placements[c]:child for c,child in node["children"]}
        assert len(children)==len(node["children"]) and set(children)==set(legal)
        for key in sorted(legal):
            replay(children[key],covered|legal[key])
    try:
        replay(raw["tree"],frozenset())
    except TimeoutError:
        return dict(status="UNKNOWN",reason="ASSURANCE_WALL",nodes=nodes,seconds=time.perf_counter()-started)
    return dict(status="VERIFIED",scope="EXHAUSTED_ALL_COVERING_ALIGNMENTS",nodes=nodes,seconds=time.perf_counter()-started)


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/p)==v for p,v in protocol["pins"].items())
    qualify()
    sys.path.insert(0,str(ROOT/"source"))
    model=load("input/exact-point-model-v1.json")
    screening=load("input/contained-coverage-v1.json")
    assert screening["protocol"]==pin(ROOT/"input/coverage-protocol-v1.json")
    poly=[tuple(p) for p in model["polygon"]]
    scale=model["scale"]
    samples=[(x,y) for x,y,u in model["occupancy_field"]]
    oriented={g["id"]:([matrix_move(g["matrix"],p) for p in poly],
                       [matrix_move(g["matrix"],p) for p in samples]) for g in model["groups"]}
    records=[]
    for row in screening["rows"]:
        if row["ratio"] not in protocol["ratios"]:
            continue
        assert row["uncovered"]==[]
        target={tuple(q):i for i,q in enumerate(row["target"])}
        supports=[]
        for g,dx,dy in row["placements"]:
            ids=tuple(target[x+scale*dx,y+scale*dy] for x,y in oriented[g][1])
            assert len(set(ids))==len(samples)
            supports.append(ids)
        raw=solve(supports,len(target),protocol["limits"])
        checked=verify(row,model,raw,oriented,protocol["limits"]["assurance_seconds"])
        result=dict(ratio=row["ratio"],raw=raw,independent=checked)
        records.append(result)
        print(json.dumps(dict(ratio=row["ratio"],status=raw["status"],visits=raw["visits"],
            max_selected=raw["max_selected"],seconds=raw["seconds"],verification=checked)),flush=True)
    assert len(records)==len(protocol["ratios"])
    with (ROOT/"data/exact-cover-results-v1.json.gz").open("xb") as raw:
        with gzip.GzipFile(filename="",fileobj=raw,mode="wb",mtime=0) as stream:
            stream.write((json.dumps(records,sort_keys=True,separators=(",",":"))+"\n").encode())


if __name__=="__main__":
    main()
