"""Replay full exact cover for the sole three-tile root survivor."""

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, Verifier, load, mat, pin, primitives, save
import cover_v1
from screen_v1 import region
import triangle_geometry_v1 as exact


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / name) == value for name, value in protocol["pins"].items())
    cover_v1.qualify()
    rows = [json.loads(line) for line in (ROOT / "input/ratio-04-v1.jsonl").open()]
    (survivor,) = [row for row in rows if row["empty"] == 0]
    i, ratio = survivor["type"], survivor["ratio"]
    assert (i, ratio) == (protocol["type"], protocol["ratio"])
    model = Model(load("input/exact-point-model-v1.json"))
    pieces = load("input/three-bank-v1.json")["bank"][i]
    matrix = protocol["matrix"]
    sites = region(model, pieces, matrix, ratio)
    points = sorted(sites)
    index = {point: j for j, point in enumerate(points)}
    keys = sorted(primitives(model, sites))
    assert len(keys) == survivor["placements"]
    supports = [tuple(index[q] for q in model.support(p)) for p in keys]
    limits = protocol["limits"]
    raw = cover_v1.solve(supports, len(points), limits)
    if raw["status"] == "NEGATIVE":
        verifier = Verifier(model, [], {}, exact)
        checked = verifier.negative(sites, points, keys, raw["tree"], "primitive", (),
                                    limits["assurance_seconds"])
    elif raw["status"] == "POSITIVE":
        chosen = [keys[j] for j in raw["witness"]]
        polys = [tuple(mat(matrix, q) for q in model.poly(p)) for p in pieces]
        area = sum(abs(exact.area2(p)) for p in polys)
        verifier = Verifier(model, [], {}, exact)
        # The verifier's expected primitive count is twice its ratio argument.
        primitive_count = len(pieces) * ratio
        assert primitive_count % 2 == 0
        checked = verifier.positive(polys, area, primitive_count // 2, chosen, "primitive")
    else:
        checked = dict(status="UNKNOWN", reason="SEARCH_LIMIT")
    admitted = raw["status"] if checked["status"] == "VERIFIED" else "UNKNOWN"
    result = dict(type=i, ratio=ratio, pieces=pieces, matrix=matrix, target=points,
                  keys=keys, raw=raw, checked=checked, admitted=admitted)
    save("data/result-v1.json", result)
    print(json.dumps(dict(type=i, ratio=ratio, admitted=admitted, raw=raw, checked=checked)), flush=True)


if __name__ == "__main__":
    main()
