"""Frozen comparison of root obstruction searches on new three-Turtle shapes."""

from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, bounds, edges, inside, load, mat, pin, primitives, save
from stencil_v1 import blocked, carrier, residue, scan
import turtle_points_v1 as reference


def region(model, pieces, matrix, ratio):
    sites = set()
    scale = model.scale
    for placement in pieces:
        poly = tuple(mat(matrix, q) for q in model.poly(placement))
        ring = edges(tuple((x * scale, y * scale) for x, y in poly))
        assert all(reference.primitive(d-b, a-c) in model.normals
                   for (a, b), (c, d) in edges(poly))
        left, right, bottom, top = bounds(poly)
        part = {(x*scale+u, y*scale+v) for x in range(left, right)
                for y in range(bottom, top) for u, v in model.residues
                if inside((x*scale+u, y*scale+v), ring)}
        assert sum((model.residues[residue(q, scale)] for q in part), Fraction()) == abs(reference.area2(poly))
        assert len(part) == 240 * ratio and not sites & part
        sites.update(part)
    return sites


def exact_scan(model, sites):
    candidates = primitives(model, sites)
    covered = set().union(*(model.support(p) for p in candidates))
    assert covered <= sites
    return sites - covered, candidates


def measured(function, *args):
    start = time.process_time_ns()
    value = function(*args)
    return value, time.process_time_ns() - start


def compare(model, bank, templates, sites, cap, marked_first):
    scale = model.scale
    if marked_first:
        marked, marked_ns = measured(scan, sites, set(), bank, scale, cap)
        direct, exact_ns = measured(exact_scan, model, sites)
    else:
        direct, exact_ns = measured(exact_scan, model, sites)
        marked, marked_ns = measured(scan, sites, set(), bank, scale, cap)
    missing, candidates = direct
    hit = marked["status"] == "HIT"
    if hit:
        q = marked["point"]
        pattern = set(marked["stencil"])
        assert q in missing
        assert all(blocked(q, p, sites, set()) for p in pattern)
        assert all(pattern & support for support in templates[residue(q, scale)])
    elif missing:
        q = min(missing)
        assert all(any(blocked(q, p, sites, set()) for p in support)
                   for support in templates[residue(q, scale)])
    else:
        q = None
    return dict(empty=len(missing), point=q, marked=marked, placements=len(candidates),
                order="marked-first" if marked_first else "exact-first",
                exact_ns=exact_ns, marked_scan_ns=marked_ns,
                hybrid_ns=marked_ns + (0 if hit else exact_ns)), candidates


def main():
    protocol = load("protocol-v1.json")
    assert pin(Path(sys.executable)) == protocol["runtime"]
    assert all(pin(ROOT / name) == value for name, value in protocol["pins"].items())
    source = load("input/exact-point-model-v1.json")
    model = Model(source)
    _, templates = carrier(source)
    bank = defaultdict(list)
    for row in load("input/patterns-v1.json"):
        r = tuple(row["residue"])
        pattern = tuple(map(tuple, row["points"]))
        assert all(set(pattern) & support for support in templates[r])
        bank[r].append((pattern, row["origin"]))
    assert set(bank) == set(templates) and sum(map(len, bank.values())) == 168
    library = [tuple(map(tuple, p)) for p in load("input/three-bank-v1.json")["bank"]]
    assert len(library) == 2241
    controls = set(sorted(range(len(library)), key=lambda i: hashlib.sha256(
        f"Turtle-three-control-v1:{i}".encode()).digest())[:protocol["controls"]])
    scales = [*protocol["scales"], {"ratio": 1, "matrix": [[1, 0], [0, 1]]}]
    summaries = {}
    index = 0
    for spec in scales:
        ratio = spec["ratio"]
        counts = Counter()
        with (ROOT / f"data/ratio-{ratio:02d}-v1.jsonl").open("x", buffering=1) as output:
            for i, pieces in enumerate(library):
                if ratio == 1 and i not in controls:
                    continue
                sites = region(model, pieces, spec["matrix"], ratio)
                row, candidates = compare(model, bank, templates, sites, protocol["scan_cap"], index % 2 == 0)
                if ratio == 1:
                    assert not row["empty"] and set(pieces) <= candidates
                    assert set().union(*(model.support(p) for p in pieces)) == sites
                    row["witness"] = pieces
                status = row["marked"]["status"]
                counts.update(["cases", "empty_root" if row["empty"] else "full_root", status])
                for name in ("exact_ns", "marked_scan_ns", "hybrid_ns"):
                    counts[name] += row[name]
                row.update(type=i, ratio=ratio)
                output.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
                index += 1
                if counts["cases"] % 256 == 0:
                    print(json.dumps(dict(ratio=ratio, **counts), sort_keys=True), flush=True)
        assert counts["cases"] == (len(controls) if ratio == 1 else len(library))
        summaries[ratio] = dict(counts)
        print(json.dumps(dict(ratio=ratio, done=True, **counts), sort_keys=True), flush=True)
    save("data/summary-v1.json", dict(status="CHECKED_PROSPECTIVE_ROOT_TRANSFER", scales=summaries,
         scope="Exact root tests only. Empty roots prove impossibility. Full roots of inflated shapes do not establish tileability. Controls have explicit partitions. Paired single-process CPU measurements exclude target construction and certificate replay."))


if __name__ == "__main__":
    main()
