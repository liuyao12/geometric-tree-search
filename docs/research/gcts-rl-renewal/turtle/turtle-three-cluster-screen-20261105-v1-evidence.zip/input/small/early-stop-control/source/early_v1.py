"""Add an exact early-exit baseline to the completed stencil comparison."""

from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load, pin, save
from screen_v1 import measured, region
from stencil_v1 import carrier, residue, scan


def early_scan(target, templates, scale):
    covered = set()
    queries = alignments = 0
    for x, y in sorted(target):
        q = (x, y)
        if q in covered:
            continue
        queries += 1
        for template in templates[residue(q, scale)]:
            alignments += 1
            if all((x + u, y + v) in target for u, v in template):
                covered.update((x + u, y + v) for u, v in template)
                break
        else:
            return dict(point=q, queries=queries, alignments=alignments)
    return dict(point=None, queries=queries, alignments=alignments)


def reach(offset):
    x, y = offset
    return (-(x*x + x*y + y*y), x, y)


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / n) == v for n, v in protocol["pins"].items())
    source = load("input/exact-point-model-v1.json")
    model = Model(source)
    _, unordered = carrier(source)
    templates = {r: tuple(tuple(sorted(s, key=reach)) for s in items)
                 for r, items in unordered.items()}
    bank = defaultdict(list)
    for row in load("input/patterns-v1.json"):
        r = tuple(row["residue"])
        pattern = tuple(map(tuple, row["points"]))
        assert all(set(pattern) & support for support in unordered[r])
        bank[r].append((pattern, row["origin"]))
    library = [tuple(map(tuple, p)) for p in load("input/three-bank-v1.json")["bank"]]
    summaries = {}
    index = 0
    with (ROOT / "data/cases-v1.jsonl").open("x", buffering=1) as output:
        for spec in protocol["scales"]:
            ratio = spec["ratio"]
            path = ROOT / f"input/ratio-{ratio:02d}-v1.jsonl"
            cases = [json.loads(line) for line in path.read_text().splitlines()]
            selected = sorted(cases, key=lambda r: hashlib.sha256(
                f"Turtle-early-root-v1:{ratio}:{r['type']}".encode()).digest())[:spec["sample"]]
            counts = Counter()
            for old in selected:
                i = old["type"]
                target = region(model, library[i], spec["matrix"], ratio)
                if index % 2 == 0:
                    direct, direct_ns = measured(early_scan, target, templates, model.scale)
                    marked, marked_ns = measured(scan, target, set(), bank, model.scale, protocol["scan_cap"])
                else:
                    marked, marked_ns = measured(scan, target, set(), bank, model.scale, protocol["scan_cap"])
                    direct, direct_ns = measured(early_scan, target, templates, model.scale)
                negative = direct["point"] is not None
                assert negative == (old["empty"] > 0)
                hit = marked["status"] == "HIT"
                assert json.loads(json.dumps(marked)) == old["marked"]
                assert not hit or negative
                hybrid_ns = marked_ns + (0 if hit else direct_ns)
                row = dict(type=i, ratio=ratio, direct=direct, marked=marked, exact_early_ns=direct_ns,
                           marked_scan_ns=marked_ns, hybrid_early_ns=hybrid_ns, early_first=index % 2 == 0)
                counts.update(["cases", "root_empty" if negative else "root_full", marked["status"]])
                for field in ("exact_early_ns", "marked_scan_ns", "hybrid_early_ns"):
                    counts[field] += row[field]
                output.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
                index += 1
            summaries[ratio] = dict(counts)
            print(json.dumps(dict(ratio=ratio, **counts), sort_keys=True), flush=True)
    save("data/summary-v1.json", dict(status="CHECKED_EXACT_EARLY_STOP_CONTROL", scales=summaries,
         scope="Follow-up on a frozen hash subsample of the already checked root benchmark. Times are paired single-process CPU measurements for the root kernel only."))


if __name__ == "__main__":
    main()
