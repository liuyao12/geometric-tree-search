"""Search exact closed substitution families from a complete two-tile bank."""

from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def load(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    b=path.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def save(name,value):
    with (ROOT/name).open("x") as f:
        json.dump(value,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def mat(m,p):
    a,b=m
    x,y=p
    return a[0]*x+a[1]*y,b[0]*x+b[1]*y


def add(p,q):
    return p[0]+q[0],p[1]+q[1]


def translated(points,dx,dy):
    return tuple((x+dx,y+dy) for x,y in points)


def bounds(points):
    x,y=zip(*points)
    return min(x),max(x),min(y),max(y)


def edges(p):
    return tuple(zip(p,p[1:]+p[:1]))


def shared_edge(a,b):
    for p,q in edges(a):
        u,v=q[0]-p[0],q[1]-p[1]
        k=0 if u else 1
        for r,s in edges(b):
            if any(u*(y-p[1])!=v*(x-p[0]) for x,y in (r,s)):
                continue
            low=max(min(p[k],q[k]),min(r[k],s[k]))
            high=min(max(p[k],q[k]),max(r[k],s[k]))
            if low<high:
                return True
    return False


def inside(q,ring):
    x,y=q
    parity=0
    for (a,b),(c,d) in ring:
        if (b<=y<d and (c-a)*(y-b)>(x-a)*(d-b)
                or d<=y<b and (c-a)*(y-b)<(x-a)*(d-b)):
            parity^=1
    return bool(parity)


class Model:
    def __init__(self,source):
        self.scale=source["scale"]
        self.groups={r["id"]:r["matrix"] for r in source["groups"]}
        assert self.groups[0]==[[1,0],[0,1]]
        ids={tuple(map(tuple,m)):i for i,m in self.groups.items()}
        self.compose={}
        for i,a in self.groups.items():
            for j,b in self.groups.items():
                product=tuple(tuple(sum(a[r][k]*b[k][c] for k in range(2))
                                    for c in range(2)) for r in range(2))
                self.compose[i,j]=ids[product]
        shape=[tuple(v) for v in source["polygon"]]
        atoms=[(x,y) for x,y,u in source["occupancy_field"]]
        self.polygons={g:tuple(mat(m,p) for p in shape) for g,m in self.groups.items()}
        self.atoms={g:tuple(sorted(mat(m,p) for p in atoms)) for g,m in self.groups.items()}
        self.residues={tuple(q):Fraction(*c["area2"]) for q,c in
                       zip(source["orbit_residues"],source["cells"],strict=True)}
        self.normals={tuple(q) for q in source["normal_families"]}
        assert len(atoms)==240 and self.scale==18

    def action(self,g,p):
        h,x,y=p
        a,b=mat(self.groups[g],(x,y))
        return self.compose[g,h],a,b

    def poly(self,p):
        g,x,y=p
        return translated(self.polygons[g],x,y)

    def support(self,p):
        g,x,y=p
        return translated(self.atoms[g],x*self.scale,y*self.scale)

    def macro_support(self,pieces):
        support={q for p in pieces for q in self.support(p)}
        assert len(support)==480
        return tuple(sorted(support))

    def normalize(self,pieces):
        keys=[]
        for g in sorted(self.groups):
            turned=[self.action(g,p) for p in pieces]
            x,y=min(v for p in turned for v in self.poly(p))
            normalized=tuple(sorted((h,a-x,b-y) for h,a,b in turned))
            keys.append((self.macro_support(normalized),normalized))
        return min(keys)

    def target(self,pieces,matrix,ratio,ref):
        s=self.scale
        polygons=[tuple(mat(matrix,p) for p in self.poly(q)) for q in pieces]
        target=set()
        total_area=0
        for poly in polygons:
            ring=edges(tuple((x*s,y*s) for x,y in poly))
            assert all(ref.primitive(d-b,a-c) in self.normals for (a,b),(c,d) in edges(poly))
            a,b,c,d=bounds(poly)
            sites={(x*s+u,y*s+v) for x in range(a,b) for y in range(c,d)
                   for u,v in self.residues if inside((x*s+u,y*s+v),ring)}
            area=abs(ref.area2(list(poly)))
            assert sum(self.residues[x%s,y%s] for x,y in sites)==area
            assert not target&sites
            target.update(sites)
            total_area+=area
        assert len(target)==480*ratio
        return polygons,target,total_area


def build_bank(model,catalogue):
    assert catalogue["status"]=="COMPLETE" and catalogue["catalogue"]["complete"]
    assert catalogue["counts"]["occupancy_mismatches"]==0
    root=(0,0,0)
    shapes={}
    count=0
    for row in catalogue["pairs"]:
        second=(row["group"],*row["translation"])
        if row["geometry_overlap"] or not shared_edge(model.poly(root),model.poly(second)):
            continue
        count+=1
        assert not set(model.support(root)).intersection(model.support(second))
        key,pieces=model.normalize((root,second))
        if key not in shapes or pieces<shapes[key]:
            shapes[key]=pieces
    return count,[shapes[k] for k in sorted(shapes)]


def primitives(model,target):
    xmin,xmax,ymin,ymax=bounds(target)
    s=model.scale
    found={}
    for g,sites in sorted(model.atoms.items()):
        a,b,c,d=bounds(sites)
        for x in range((xmin-a+s-1)//s,(xmax-b)//s+1):
            for y in range((ymin-c+s-1)//s,(ymax-d)//s+1):
                dx,dy=x*s,y*s
                if all((u+dx,v+dy) in target for u,v in sites):
                    found[g,x,y]=frozenset(translated(sites,dx,dy))
    return found


def variants(model,bank):
    return {(i,g):tuple(model.action(g,p) for p in pieces)
            for i,pieces in enumerate(bank) for g in sorted(model.groups)}


def macros(primitive,forms):
    found={}
    by_group={}
    for g,x,y in primitive:
        by_group.setdefault(g,[]).append((x,y))
    for (i,g),(a,b) in forms.items():
        u,p,q=a
        v,r,s=b
        for x,y in by_group.get(u,()):
            dx,dy=x-p,y-q
            second=(v,r+dx,s+dy)
            if second in primitive:
                key=i,g,dx,dy
                found[key]=primitive[u,x,y]|primitive[second]
                assert len(found[key])==480
    return found


class Verifier:
    def __init__(self,model,bank,forms,exact):
        self.model=model
        self.exact=exact
        self.bank=bank
        self.forms=forms
        self.primitive={(g,):sites for g,sites in model.atoms.items()}
        self.macro={k:model.macro_support(p) for k,p in forms.items()}

    @lru_cache(maxsize=32)
    def index(self,kind,active):
        source=self.primitive if kind=="primitive" else self.macro
        groups={}
        s=self.model.scale
        for key,sites in source.items():
            if kind=="cluster" and key[0] not in active:
                continue
            for x,y in sites:
                groups.setdefault((x%s,y%s),[]).append((key,x,y,sites))
        return groups

    def negative(self,target,points,keys,tree,kind,active,seconds):
        start=time.perf_counter()
        groups=self.index(kind,active)
        scale=self.model.scale
        nodes=0

        @lru_cache(maxsize=4000)
        def incident(q):
            x,y=q
            result={}
            for label,a,b,sites in groups.get((x%scale,y%scale),()):
                dx,dy=x-a,y-b
                if all((u+dx,v+dy) in target for u,v in sites):
                    key=(*label,dx//scale,dy//scale)
                    assert key not in result
                    result[key]=frozenset(translated(sites,dx,dy))
            return result

        def visit(node,filled):
            nonlocal nodes
            if time.perf_counter()-start>=seconds:
                raise TimeoutError
            nodes+=1
            assert node["status"]=="NEGATIVE"
            q=points[node["atom"]]
            assert q not in filled
            legal={c:s for c,s in incident(q).items() if not s&filled}
            children={keys[c]:child for c,child in node["children"]}
            assert len(children)==len(node["children"]) and set(children)==set(legal)
            for c in sorted(legal):
                visit(children[c],filled|legal[c])
        try:
            visit(tree,frozenset())
        except TimeoutError:
            return dict(status="UNKNOWN",reason="CHECK_LIMIT",nodes=nodes)
        return dict(status="VERIFIED",nodes=nodes,seconds=time.perf_counter()-start,
                    scope="EXHAUSTED_INDEPENDENT_ATOM_ALIGNMENT_DOMAINS")

    def positive(self,polygons,area,ratio,chosen,kind):
        exact=self.exact
        carrier=[tri for poly in polygons for tri in exact.triangulate(poly)]
        if kind=="cluster":
            placements=[(h,x+dx,y+dy) for i,g,dx,dy in chosen
                        for h,x,y in self.forms[i,g]]
            assert len(chosen)==ratio
        else:
            placements=chosen
        assert len(placements)==len(set(placements))==2*ratio
        clips=[]
        total=0
        for p in placements:
            poly=self.model.poly(p)
            tris=exact.triangulate(poly)
            total+=exact.area2(poly)
            contained=Fraction(0)
            for a in tris:
                for b in carrier:
                    piece=exact._clip(a,b)
                    if len(piece)>=3:
                        contained+=abs(exact._signed_area2(piece))
            assert contained==exact.area2(poly)
            clips.append(tris)
        assert total==area
        for a,b in combinations(clips,2):
            assert not any(exact.positive_overlap(u,v) for u in a for v in b)
        return dict(status="VERIFIED",scope="RATIONAL_POLYGON_PARTITION",
                    primitive_placements=placements)


def attempt(kind,problem,inventory,checker,engine,active,limits):
    keys=sorted(inventory)
    target=problem["target"]
    points=sorted(target)
    index={p:i for i,p in enumerate(points)}
    matrix=[tuple(index[p] for p in sorted(inventory[c])) for c in keys]
    raw=engine.solve(matrix,len(points),limits)
    verification={"status":"UNKNOWN","reason":"SEARCH_LIMIT"}
    witness=None
    if raw["status"]=="NEGATIVE":
        verification=checker.negative(target,points,keys,raw["tree"],kind,active,limits["assurance_seconds"])
    elif raw["status"]=="POSITIVE":
        witness=[keys[c] for c in raw["witness"]]
        verification=checker.positive(problem["polygons"],problem["area"],problem["ratio"],witness,kind)
    return dict(admitted=raw["status"] if verification["status"]=="VERIFIED" else "UNKNOWN",
                raw=raw,verification=verification,witness=witness,keys=keys)


def one_scale(model,bank,forms,checker,ref,engine,spec,limits):
    ratio=spec["ratio"]
    problems=[]
    primitive_records=[]
    active=set(range(len(bank)))
    for i,pieces in enumerate(bank):
        polys,target,area=model.target(pieces,spec["matrix"],ratio,ref)
        primitive=primitives(model,target)
        problem=dict(ratio=ratio,polygons=polys,target=target,area=area)
        rec=attempt("primitive",problem,primitive,checker,engine,(),limits)
        primitive_records.append(dict(type=i,**rec))
        possible={} if rec["admitted"]=="NEGATIVE" else macros(primitive,forms)
        problems.append((problem,possible))
        if rec["admitted"]=="NEGATIVE":
            active.remove(i)
    rounds=[]
    witnesses={}
    for step in range(limits["max_rounds"]):
        if not active:
            break
        active_key=tuple(sorted(active))
        records=[]
        witnesses={}
        doomed=set()
        for i in active_key:
            problem,possible=problems[i]
            inventory={k:v for k,v in possible.items() if k[0] in active}
            rec=attempt("cluster",problem,inventory,checker,engine,active_key,limits)
            if rec["admitted"]=="NEGATIVE":
                doomed.add(i)
            if rec["admitted"]=="POSITIVE":
                witnesses[i]=rec["witness"]
            records.append(dict(type=i,**rec))
        rounds.append(dict(round=step,active=active_key,removed=sorted(doomed),records=records))
        active-=doomed
        if not doomed:
            break
    # A set of explicit witnesses yields a closed family once every referenced
    # constituent has a witness inside that same family.
    closed=set(witnesses)&active
    while True:
        reduced={i for i in closed if all(p[0] in closed for p in witnesses[i])}
        if reduced==closed:
            break
        closed=reduced
    return dict(ratio=ratio,matrix=spec["matrix"],primitive=primitive_records,rounds=rounds,
                remaining=sorted(active),closed={i:witnesses[i] for i in sorted(closed)},
                problem_geometry=[dict(type=i,polygons=p["polygons"],target=sorted(p["target"]),area=p["area"])
                                  for i,(p,_) in enumerate(problems)])


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/p)==v for p,v in protocol["pins"].items())
    sys.path.insert(0,str(ROOT/"source"))
    import cover_v1 as engine
    import triangle_geometry_v1 as exact
    import turtle_points_v1 as ref
    engine.qualify()
    source=load("input/exact-point-model-v1.json")
    with gzip.open(ROOT/"input/contact-catalogue-v1.json.gz","rt") as f:
        catalogue=json.load(f)
    assert catalogue["model"]==source and load("input/carrier-check-v1.json")["status"]=="VERIFIED"
    model=Model(source)
    count,bank=build_bank(model,catalogue)
    assert count==82 and bank
    forms=variants(model,bank)
    checker=Verifier(model,bank,forms,exact)
    print(json.dumps(dict(stage="BANK",rooted=count,types=len(bank))),flush=True)
    results=[]
    for spec in protocol["scales"]:
        row=one_scale(model,bank,forms,checker,ref,engine,spec,protocol["limits"])
        results.append(row)
        print(json.dumps(dict(ratio=row["ratio"],primitive=[r["admitted"] for r in row["primitive"]],
            rounds=[dict(active=len(r["active"]),removed=len(r["removed"])) for r in row["rounds"]],
            remaining=len(row["remaining"]),closed=len(row["closed"]))),flush=True)
    with (ROOT/"data/results-v1.json.gz").open("xb") as raw:
        with gzip.GzipFile(filename="",fileobj=raw,mode="wb",mtime=0) as stream:
            stream.write((json.dumps(dict(status="CHECKED_CLUSTER_SCREEN",rooted=count,bank=bank,
                scales=results,protocol=pin(ROOT/"protocol-v1.json")),sort_keys=True,separators=(",",":"))+"\n").encode())


if __name__=="__main__":
    main()
