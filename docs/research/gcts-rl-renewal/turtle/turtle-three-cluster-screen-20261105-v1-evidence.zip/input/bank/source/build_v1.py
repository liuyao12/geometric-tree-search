"""Enumerate the exact edge-connected three-Turtle shape bank."""

from functools import lru_cache
import gzip
import json
from pathlib import Path
from struct import pack
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, build_bank, load, mat, pin, save, shared_edge, translated


def main():
    frozen=load("protocol-v1.json")
    assert frozen["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in frozen["pins"].items())
    start=time.perf_counter()
    source=load("input/exact-point-model-v1.json")
    with gzip.open(ROOT/"input/contact-catalogue-v1.json.gz","rt") as f:
        old=json.load(f)
    assert old["model"]==source
    model=Model(source)
    count,bank=build_bank(model,old)
    with gzip.open(ROOT/"input/two-bank-v1.json.gz","rt") as f:
        recorded=json.load(f)
    assert json.loads(json.dumps(bank))==recorded["bank"] and count==82
    root=(0,0,0)
    rooted=[]
    for row in old["pairs"]:
        p=(row["group"],*row["translation"])
        if not row["geometry_overlap"] and shared_edge(model.poly(root),model.poly(p)):
            rooted.append(p)
    assert len(rooted)==len(set(rooted))==82
    @lru_cache(maxsize=8000)
    def support(p):
        return frozenset(model.support(p))
    @lru_cache(maxsize=8000)
    def min_vertex(p):
        return min(model.poly(p))

    def oriented_layout(pieces,g):
        rotated=tuple(model.action(g,p) for p in pieces)
        x,y=min(min_vertex(p) for p in rotated)
        return tuple(sorted((h,a-x,b-y) for h,a,b in rotated))

    def shape_key(pieces):
        keys=[]
        for g in sorted(model.groups):
            rotated=oriented_layout(pieces,g)
            points=sorted(q for p in rotated for q in support(p))
            assert len(points)==720
            # Coordinates are stored exactly as signed 16-bit integers.
            key=pack(">"+str(2*len(points))+"h",*(c for q in points for c in q))
            keys.append((key,rotated))
        return min(keys)

    unique={}
    decompositions=set()
    tried=disjoint=0
    for pieces in bank:
        occupied=set().union(*(support(p) for p in pieces))
        assert len(occupied)==480
        for g,x,y in pieces:
            for variant in rooted:
                h,u,v=model.action(g,variant)
                q=(h,u+x,v+y)
                tried+=1
                if support(q)&occupied:
                    continue
                disjoint+=1
                triple=(*pieces,q)
                base=min(oriented_layout(triple,h) for h in model.groups)
                if base not in decompositions:
                    decompositions.add(base)
                    key,layout=shape_key(base)
                    if key not in unique or layout<unique[key]:
                        unique[key]=layout
    library=[unique[key] for key in sorted(unique)]
    for a,b,c in library:
        parts=[model.poly(p) for p in (a,b,c)]
        assert len(set().union(*(support(p) for p in (a,b,c))))==720
        assert sum(shared_edge(parts[i],parts[j]) for i,j in ((0,1),(0,2),(1,2)))>=2
    result=dict(status="CHECKED_EXACT_THREE_TILE_BANK",rooted=count,two_types=len(bank),
                extensions=tried,disjoint_extensions=disjoint,
                primitive_layout_orbits=len(decompositions),shapes=len(library),bank=library,
                seconds=time.perf_counter()-start,
                scope="Edge-connected triples from the complete relative-contact catalogue. Exact geometric shape deduplication under translation and the twelve point actions. No inflation outcome.")
    save("data/three-bank-v1.json",result)
    print(json.dumps({k:v for k,v in result.items() if k!="bank"}),flush=True)


if __name__=="__main__":
    main()
