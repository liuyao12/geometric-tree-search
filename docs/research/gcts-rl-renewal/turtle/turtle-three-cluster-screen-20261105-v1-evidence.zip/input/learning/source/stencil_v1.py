"""Learn exact blocked-atom stencils from saved exhausted Turtle domains."""

from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def read(path):
    return json.loads((ROOT/path).read_bytes())


def unpack(path):
    with gzip.open(ROOT/path,"rt") as f:
        return json.load(f)


def pin(path):
    b=path.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def save(path,value):
    with (ROOT/path).open("x") as f:
        json.dump(value,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def transform(m,p):
    x,y=p
    return m[0][0]*x+m[0][1]*y,m[1][0]*x+m[1][1]*y


def plus(p,q):
    return p[0]+q[0],p[1]+q[1]


def residue(p,scale):
    return p[0]%scale,p[1]%scale


def carrier(model):
    s=model["scale"]
    points=[(x,y) for x,y,u in model["occupancy_field"]]
    oriented={g["id"]:tuple(transform(g["matrix"],p) for p in points) for g in model["groups"]}
    templates=defaultdict(list)
    for sites in oriented.values():
        for x,y in sites:
            r=residue((x,y),s)
            templates[r].append(frozenset((a-x,b-y) for a,b in sites))
    assert len(templates)==12 and all(len(t)==240 for t in templates.values())
    return oriented,templates


def corpus():
    earlier=unpack("input/small-results-v1.json.gz")
    wide=unpack("input/wide-summary-v1.json.gz")
    assert earlier["bank"]==wide["bank"] and len(earlier["bank"])==49
    yield from earlier["scales"]
    for ref in wide["scales"]:
        a=ref["artifact"]
        n="input/"+Path(a["path"]).name
        assert pin(ROOT/n)=={k:a[k] for k in ("bytes","sha256")}
        row=unpack(n)
        assert row["ratio"]==ref["ratio"]
        yield row


def states(row,oriented,scale):
    for g,result in zip(row["problem_geometry"],row["primitive"],strict=True):
        assert g["type"]==result["type"] and result["admitted"]=="NEGATIVE"
        tree=result["raw"]["tree"]
        filled=set()
        if tree["children"]:
            (index,tree),=tree["children"]
            kind,x,y=result["keys"][index]
            filled={plus(p,(x*scale,y*scale)) for p in oriented[kind]}
            assert result["verification"]["nodes"]==2
        else:
            assert result["verification"]["nodes"]==1
        assert tree["status"]=="NEGATIVE" and tree["children"]==[]
        q=tuple(g["target"][tree["atom"]])
        target=set(map(tuple,g["target"]))
        assert q in target and q not in filled and filled<=target
        yield (row["ratio"],g["type"]),q,target,filled


def blocked(q,relative,target,filled):
    site=plus(q,relative)
    return site not in target or site in filled


def greedy(q,target,filled,templates):
    masks=defaultdict(int)
    for j,support in enumerate(templates):
        hits=[p for p in support if blocked(q,p,target,filled)]
        assert hits
        for p in hits:
            masks[p]|=1<<j
    missing=(1<<len(templates))-1
    result=set()
    while missing:
        candidate=max(masks,key=lambda p:((masks[p]&missing).bit_count(),
                         -(p[0]*p[0]+p[0]*p[1]+p[1]*p[1]),-p[0],-p[1]))
        assert masks[candidate]&missing
        result.add(candidate)
        missing &= ~masks[candidate]
    for p in sorted(result):
        shorter=result-{p}
        if all(shorter&sites for sites in templates):
            result=shorter
    assert result and all(result&sites for sites in templates)
    assert all(blocked(q,p,target,filled) for p in result)
    return tuple(sorted(result))


def certify(seed,groups,templates,scale):
    expanded=defaultdict(dict)
    for r,stencil,origin in seed:
        for M in groups:
            kind=residue(transform(M,r),scale)
            turned=tuple(sorted(transform(M,p) for p in stencil))
            if turned not in expanded[kind]:
                mask=set(turned)
                assert all(mask&sites for sites in templates[kind])
                expanded[kind][turned]=origin
    retained={}
    for r,patterns in expanded.items():
        minimal=[]
        for shape in sorted(patterns,key=lambda t:(len(t),t)):
            if not any(p<=set(shape) for p,_ in minimal):
                minimal.append((set(shape),patterns[shape]))
        retained[r]=[(tuple(sorted(p)),origin) for p,origin in minimal]
    return retained,sum(map(len,expanded.values()))


def split(protocol,key):
    ratio,type_id=key
    seen_shape=(int.from_bytes(hashlib.sha256(str(type_id).encode()).digest(),"big")%3)!=0
    old_scale=ratio in protocol["learn_ratios"]
    return "learn" if old_scale and seen_shape else (
        "held_shape" if old_scale else "held_scale" if seen_shape else "held_both")


def match(q,target,filled,bank,scale):
    for stencil,origin in bank[residue(q,scale)]:
        if all(blocked(q,p,target,filled) for p in stencil):
            return dict(origin=origin,point=q,stencil=stencil)
    return None


def scan(target,filled,bank,scale,cap):
    visits=0
    for q in sorted(target-filled):
        for stencil,origin in bank[residue(q,scale)]:
            if visits>=cap:
                return dict(status="BOUNDED",tests=visits)
            visits+=1
            if all(blocked(q,p,target,filled) for p in stencil):
                return dict(status="HIT",tests=visits,origin=origin,point=q,stencil=stencil)
    return dict(status="EXHAUSTED",tests=visits)


def main():
    protocol=read("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/n)==v for n,v in protocol["pins"].items())
    started=time.perf_counter()
    model=read("input/exact-point-model-v1.json")
    scale=model["scale"]
    oriented,templates=carrier(model)
    seed=[]
    for row in corpus():
        if row["ratio"] not in protocol["learn_ratios"]:
            continue
        for key,q,target,filled in states(row,oriented,scale):
            if split(protocol,key)=="learn":
                r=residue(q,scale)
                mask=greedy(q,target,filled,templates[r])
                seed.append((r,mask,dict(case=key,point=q)))
    bank,expanded=certify(seed,[g["matrix"] for g in model["groups"]],templates,scale)
    assert set(bank)==set(templates)
    counts=defaultdict(Counter)
    evaluations=[]
    for row in corpus():
        for key,q,target,filled in states(row,oriented,scale):
            fold=split(protocol,key)
            if fold=="learn":
                continue
            leaf=match(q,target,filled,bank,scale)
            root=scan(target,set(),bank,scale,protocol["max_tests"])
            after=scan(target,filled,bank,scale,protocol["max_tests"]) if filled else None
            assert not filled or root["status"]!="HIT", "root is completely covered in the two-node cases"
            counts[fold].update(["cases","leaf_hit" if leaf else "leaf_miss","root_"+root["status"]])
            if after:
                counts[fold].update(["after_"+after["status"]])
            evaluations.append(dict(case=key,split=fold,recorded_leaf=leaf,root_scan=root,
                                    after_forced_scan=after))
        print(json.dumps(dict(ratio=row["ratio"],evaluations=len(evaluations))),flush=True)
    assert len(seed)+len(evaluations)==441
    patterns=[dict(residue=r,points=p,origin=o) for r,items in sorted(bank.items()) for p,o in items]
    save("data/patterns-v1.json",patterns)
    save("data/evaluation-v1.json",evaluations)
    report=dict(status="CHECKED_RETROSPECTIVE_GEOMETRIC_STENCIL_TRANSFER",
        training=len(seed),pattern_sizes=dict(Counter(len(x["points"]) for x in patterns)),
        expanded=expanded,patterns=len(patterns),evaluation={k:dict(v) for k,v in counts.items()},
        seconds=time.perf_counter()-started,
        scope="Retrospective split of saved negative experiments. Leaf matching uses a supplied dead point. Root scanning uses no saved query or move. Post-forced scanning receives the independently verified forced placement. No new whole-cover search or speed comparison.")
    save("data/summary-v1.json",report)
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
