"""Lift finite Turtle cover contradictions along exact similarity rays."""

from collections import Counter
from functools import lru_cache
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, edges, inside, load, mat, pin, save
from stencil_v1 import carrier, residue
from turtle_points_v1 import primitive


def dot(a, b):
    return a[0]*b[0] + a[1]*b[1]


def minus(a, b):
    return a[0]-b[0], a[1]-b[1]


def nodes(tree):
    yield tree
    for _, child in tree["children"]:
        yield from nodes(child)


def threshold(anchor, footprint, lines, scale):
    # For relative point p, a supporting line evaluates to
    # k*scale*(dot(normal, anchor)-constant) + dot(normal, p).
    cut = 1
    for normal, constant in lines:
        slope = scale*(dot(normal, anchor)-constant)
        low, high = footprint[normal]
        if slope > 0:
            cut = max(cut, (-low)//slope + 1)
        elif slope < 0:
            cut = max(cut, high//(-slope) + 1)
    return cut


class Replay:
    def __init__(self, model_source):
        self.model = Model(model_source)
        self.oriented, self.alignments = carrier(model_source)
        self.extrema = {}
        for r, supports in self.alignments.items():
            points = set().union(*supports)
            self.extrema[r] = {}
            for normal in self.model.normals:
                values = [dot(normal, p) for p in points]
                self.extrema[r][normal] = min(values), max(values)

    def anchor_choices(self, polys, tree, seed, limit):
        s = self.model.scale
        vertices = set(p for poly in polys for p in poly)
        lines = set()
        for poly in polys:
            for (a,b),(c,d) in edges(poly):
                normal = primitive(d-b,a-c)
                assert normal in self.model.normals
                lines.add((normal, dot(normal, (a,b))))
        points = [tuple(node["point"]) for node in nodes(tree)]
        choices = []
        for anchor in vertices:
            x,y = anchor
            base = seed*s*x, seed*s*y
            relative = [minus(q, base) for q in points]
            footprint = {}
            for normal in self.model.normals:
                starts, ends = [], []
                for q in relative:
                    low, high = self.extrema[residue(q, s)][normal]
                    offset = dot(normal, q)
                    starts.append(low + offset)
                    ends.append(high + offset)
                footprint[normal] = min(starts), max(ends)
            k = threshold(anchor, footprint, lines, s)
            distance = max(abs(a)+abs(b) for a,b in relative)
            choices.append((k, distance, anchor))
        return sorted(choices)[:limit]

    def verify_at(self, polys, tree, anchor, seed, k):
        s = self.model.scale
        x, y = anchor
        dx, dy = (k-seed)*x, (k-seed)*y
        rings = [edges(tuple((s*k*a, s*k*b) for a,b in poly)) for poly in polys]
        boxes = [tuple((min(p[i] for p in poly)*s*k, max(p[i] for p in poly)*s*k)
                       for i in (0,1)) for poly in polys]

        @lru_cache(maxsize=8192)
        def member(p):
            a,b = p
            return any(x0<a<x1 and y0<b<y1 and inside(p, ring)
                       for ((x0,x1),(y0,y1)),ring in zip(boxes,rings,strict=True))

        def visit(node, filled):
            assert node["status"] == "NEGATIVE"
            a,b = node["point"]
            q = a+s*dx,b+s*dy
            if q in filled or not member(q):
                return False
            if "mark" in node:
                mark = node["mark"]
                mask = set(map(tuple,mark["stencil"]))
                assert mark["point"] == node["point"] and not node["children"]
                assert all(mask & template for template in self.alignments[residue(q,s)])
                # If the old marking no longer applies, the same pivot may
                # still have an empty domain by direct enumeration below.
                if all((q[0]+u,q[1]+v) in filled or not member((q[0]+u,q[1]+v))
                       for u,v in mask):
                    return True
            choices = {(g,x+dx,y+dy):child for (g,x,y),child in node["children"]}
            assert len(choices) == len(node["children"])
            seen = set()
            tested = 0
            for g, points in self.oriented.items():
                for a,b in points:
                    u,v = q[0]-a,q[1]-b
                    if u%s or v%s:
                        continue
                    tested += 1
                    if any((x+u,y+v) in filled or not member((x+u,y+v)) for x,y in points):
                        continue
                    key = g,u//s,v//s
                    if key not in choices or key in seen:
                        return False
                    seen.add(key)
                    if not visit(choices[key],filled | {(x+u,y+v) for x,y in points}):
                        return False
            assert tested == 240
            return seen == choices.keys()

        return visit(tree, set())


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / name) == value for name, value in protocol["pins"].items())
    replay = Replay(load("input/exact-point-model-v1.json"))
    pieces = load("input/three-bank-v1.json")["bank"]
    results = []
    for spec in protocol["families"]:
        k0 = spec["seed"]
        ratio = spec["ratio"]
        matrix = spec["base"]
        first = k0+1
        counts = Counter()
        starts = Counter()
        begun = time.perf_counter()
        with (ROOT / f"input/ratio-{ratio}-v1.jsonl").open() as rows, (
                ROOT / f"data/ratio-{ratio}-tail-v1.jsonl").open("x",buffering=1) as out:
            for i,line in enumerate(rows):
                old = json.loads(line)
                assert old["type"] == i and old["ratio"] == ratio
                assert old["raw"]["status"] == "NEGATIVE" and old["checked"]["status"] == "VERIFIED"
                tree = old["raw"]["tree"]
                polys = [tuple(mat(matrix,p) for p in replay.model.poly(tile)) for tile in pieces[i]]
                choices = replay.anchor_choices(polys,tree,k0,protocol["anchor_trials"])
                checked = []
                winner = None
                for bound, distance, anchor in choices:
                    assert replay.verify_at(polys,tree,anchor,k0,k0)
                    cut = max(first,bound)
                    holds = replay.verify_at(polys,tree,anchor,k0,cut)
                    checked.append(dict(anchor=anchor, uniform_bound=bound, checked_at=cut, tail=holds))
                    if holds:
                        winner = cut,anchor
                        break
                gaps = []
                if winner:
                    cut,anchor = winner
                    for k in range(first,cut):
                        if not replay.verify_at(polys,tree,anchor,k0,k):
                            gaps.append(k)
                    counts["tail"] += 1
                    counts["gap_cases"] += len(gaps)
                    counts["fully_contiguous"] += not gaps
                    starts[cut] += 1
                else:
                    counts["unresolved_tail"] += 1
                out.write(json.dumps(dict(type=i, first=first, trials=checked, winner=winner,
                                          unresolved_bridge=gaps),sort_keys=True,separators=(",",":"))+"\n")
                if i%512 == 511:
                    print(json.dumps(dict(ratio=ratio,cases=i+1,**counts)),flush=True)
        assert i+1 == len(pieces) == 2241
        results.append(dict(ratio=ratio, counts=dict(counts), thresholds=dict(starts),
                            seconds=time.perf_counter()-begun))
        print(json.dumps(results[-1]),flush=True)
    save("data/summary-v1.json",dict(status="CHECKED_PARAMETERIZED_TURTLE_PROOF_REPLAY",families=results,
         scope="Same finite contradiction template translated with one vertex. A verified tail covers every integer multiplier at or above its uniform bound. A failed template remains unresolved."))


if __name__ == "__main__":
    main()
