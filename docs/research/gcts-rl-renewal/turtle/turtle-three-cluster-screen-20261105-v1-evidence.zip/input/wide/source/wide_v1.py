"""Exact, lazy finite-cover search on the three-Turtle inflation bank."""

from collections import Counter, defaultdict
from functools import lru_cache
import itertools
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load, mat, pin, save, translated
from screen_v1 import region
from stencil_v1 import blocked, carrier, match, residue


def reach(offset):
    x, y = offset
    return (-(x*x + x*y + y*y), x, y)


class Carrier:
    def __init__(self, source, pattern_rows):
        self.model = Model(source)
        self.scale = self.model.scale
        self.oriented, masks = carrier(source)
        self.alignments = defaultdict(list)
        for g, points in sorted(self.oriented.items()):
            for x, y in points:
                relative = tuple(sorted(((a-x, b-y) for a, b in points), key=reach))
                self.alignments[residue((x, y), self.scale)].append((g, x, y, relative))
        for r, items in self.alignments.items():
            assert tuple(frozenset(t[3]) for t in items) == tuple(masks[r])
        self.bank = defaultdict(list)
        for row in pattern_rows:
            r = tuple(row["residue"])
            pattern = tuple(map(tuple, row["points"]))
            assert all(set(pattern) & support for support in masks[r])
            self.bank[r].append((pattern, row["origin"]))
        assert len(self.bank) == 12 and sum(map(len, self.bank.values())) == 168

    def templates(self, spec):
        return {g: region(self.model, [(g, 0, 0)], spec["matrix"], spec["ratio"])
                for g in self.oriented}

    def target(self, pieces, spec, templates):
        sites = set()
        for g, x, y in pieces:
            u, v = mat(spec["matrix"], (x, y))
            sites.update(translated(templates[g], u*self.scale, v*self.scale))
        assert len(sites) == len(pieces) * 240 * spec["ratio"]
        return sites

    def solve(self, target, limits):
        points = sorted(target)
        started = time.perf_counter()
        nodes = mark_hits = domain_checks = 0
        witness = None
        stack = []

        @lru_cache(maxsize=limits["cache_points"])
        def root_domain(q):
            x, y = q
            choices = {}
            for g, a, b, offsets in self.alignments[residue(q, self.scale)]:
                if all((x+u, y+v) in target for u, v in offsets):
                    key = g, (x-a)//self.scale, (y-b)//self.scale
                    choices[key] = frozenset((x+u, y+v) for u, v in offsets)
            return choices

        def visit(filled):
            nonlocal nodes, mark_hits, domain_checks, witness
            if nodes >= limits["nodes"] or time.perf_counter()-started > limits["seconds"]:
                return dict(status="UNKNOWN")
            nodes += 1
            if len(filled) == len(target):
                witness = tuple(stack)
                return dict(status="POSITIVE")
            prefix = list(itertools.islice((q for q in points if q not in filled), limits["prefix"]))
            for q in prefix:
                mark = match(q, target, filled, self.bank, self.scale)
                if mark:
                    mark_hits += 1
                    return dict(status="NEGATIVE", point=q, children=[], mark=mark)
            best = None
            for q in prefix[:limits["domain_prefix"]]:
                domain_checks += 1
                current = {k: sites for k, sites in root_domain(q).items() if sites.isdisjoint(filled)}
                if best is None or len(current) < len(best[1]):
                    best = q, current
                if len(current) <= 1:
                    break
            q, choices = best
            children = []
            for key, sites in sorted(choices.items()):
                stack.append(key)
                child = visit(filled | sites)
                stack.pop()
                children.append((key, child))
                if child["status"] != "NEGATIVE":
                    return dict(status=child["status"], point=q, children=children)
            return dict(status="NEGATIVE", point=q, children=children)

        tree = visit(frozenset())
        return dict(status=tree["status"], tree=tree, witness=witness, nodes=nodes,
                    mark_hits=mark_hits, domain_checks=domain_checks, seconds=time.perf_counter()-started)

    def verify(self, target, raw):
        if raw["status"] == "UNKNOWN":
            return dict(status="BOUNDED")
        if raw["status"] == "POSITIVE":
            occupied = set()
            for p in raw["witness"]:
                sites = set(self.model.support(p))
                assert len(sites) == 240 and not occupied & sites
                occupied.update(sites)
            assert occupied == target
            return dict(status="VERIFIED", scope="EXACT_CARRIER_PARTITION")

        s = self.scale
        nodes = 0

        def visit(node, filled):
            nonlocal nodes
            nodes += 1
            assert node["status"] == "NEGATIVE"
            q = node["point"]
            assert q in target and q not in filled
            x, y = q
            children = dict(node["children"])
            assert len(children) == len(node["children"])
            replayed = set()
            candidates = 0
            if "mark" in node:
                mark = node["mark"]
                assert mark["point"] == q and not children
                assert all(blocked(q, delta, target, filled) for delta in mark["stencil"])
            for g, points in self.oriented.items():
                for a, b in points:
                    dx, dy = x-a, y-b
                    if dx % s or dy % s:
                        continue
                    candidates += 1
                    if any((u+dx, v+dy) not in target or (u+dx, v+dy) in filled
                           for u, v in points):
                        continue
                    key = g, dx//s, dy//s
                    assert key in children and key not in replayed
                    replayed.add(key)
                    visit(children[key], filled | frozenset(translated(points, dx, dy)))
            assert candidates == 240 and replayed == set(children)

        visit(raw["tree"], frozenset())
        assert nodes == raw["nodes"]
        return dict(status="VERIFIED", scope="EXHAUSTED_INDEPENDENT_ABSOLUTE_ALIGNMENTS", nodes=nodes)


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / name) == value for name, value in protocol["pins"].items())
    assert load("input/carrier-check-v1.json")["status"] == "VERIFIED"
    bank = load("input/three-bank-v1.json")
    assert bank["shapes"] == len(bank["bank"]) == 2241
    source = load("input/exact-point-model-v1.json")
    engine = Carrier(source, load("input/patterns-v1.json"))
    limits = protocol["limits"]
    scales = protocol["scales"]
    assert scales == load("input/previous-wide-protocol-v1.json")["scales"]
    identity = set(engine.model.support((0, 0, 0)))
    raw = engine.solve(identity, limits)
    assert raw["status"] == "POSITIVE" and engine.verify(identity, raw)["status"] == "VERIFIED"
    known = load("input/result-v1.json")
    assert known["admitted"] == "NEGATIVE" and known["checked"]["nodes"] == 2
    qspec = {key: known[key] for key in ("matrix", "ratio")}
    qualification = engine.target(known["pieces"], qspec, engine.templates(qspec))
    assert sorted(qualification) == list(map(tuple, known["target"]))
    raw = engine.solve(qualification, limits)
    assert raw["status"] == "NEGATIVE" and engine.verify(qualification, raw)["status"] == "VERIFIED"
    print(json.dumps(dict(stage="QUALIFIED", survivor_nodes=raw["nodes"])), flush=True)

    summaries = {}
    for spec in scales:
        ratio = spec["ratio"]
        templates = engine.templates(spec)
        counts = Counter()
        begun = time.perf_counter()
        with (ROOT / f"data/ratio-{ratio:02d}-v1.jsonl").open("x", buffering=1) as output:
            for i, pieces in enumerate(bank["bank"]):
                target = engine.target(pieces, spec, templates)
                if i % protocol["geometry_replay_stride"] == 0:
                    assert target == region(engine.model, pieces, spec["matrix"], ratio)
                    counts["geometry_replays"] += 1
                raw = engine.solve(target, limits)
                checked = engine.verify(target, raw)
                assert (checked["status"] == "VERIFIED") == (raw["status"] != "UNKNOWN")
                row = dict(type=i, ratio=ratio, raw=raw, checked=checked)
                output.write(json.dumps(row, separators=(",", ":"), sort_keys=True) + "\n")
                counts[raw["status"]] += 1
                counts["nodes"] += raw["nodes"]
                counts["mark_hits"] += raw["mark_hits"]
                counts["domain_checks"] += raw["domain_checks"]
                if raw["status"] == "NEGATIVE":
                    counts[f"negative_nodes_{raw['nodes']}"] += 1
                if i % 512 == 511 or raw["status"] == "POSITIVE":
                    print(json.dumps(dict(ratio=ratio, cases=i+1, **counts)), flush=True)
        assert sum(counts[s] for s in ("POSITIVE", "NEGATIVE", "UNKNOWN")) == len(bank["bank"])
        summaries[ratio] = dict(counts)
        print(json.dumps(dict(ratio=ratio, done=True, wall=time.perf_counter()-begun, **counts)), flush=True)
    save("data/summary-v1.json", dict(status="CHECKED_WIDE_THREE_TILE_PRIMITIVE_SCREEN", scales=summaries,
         scope="All 2241 exact edge-connected three-Turtle supports at seven named larger scales. Primitive covers only. Negative proofs independently replayed. No inference from bounded outcomes."))


if __name__ == "__main__":
    main()
