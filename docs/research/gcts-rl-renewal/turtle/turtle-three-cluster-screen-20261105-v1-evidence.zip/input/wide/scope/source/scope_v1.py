"""Audit the boundary-direction reduction for arbitrary finite Turtle unions."""

from collections import Counter
from math import gcd
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    return json.loads((ROOT / name).read_bytes())


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def direction(x, y):
    divisor = gcd(x, y)
    x, y = x//divisor, y//divisor
    return (x, y) if (x, y) > (0, 0) else (-x, -y)


def move(matrix, p):
    a, b = matrix
    x, y = p
    return a[0]*x+a[1]*y, b[0]*x+b[1]*y


def product(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)] for i in range(2)]


def det(m):
    return m[0][0]*m[1][1]-m[0][1]*m[1][0]


def main():
    protocol = load("protocol-v1.json")
    assert protocol["runtime"] == pin(Path(sys.executable))
    assert all(pin(ROOT / n) == v for n, v in protocol["pins"].items())
    model = load("input/exact-point-model-v1.json")
    cap = protocol["cap"]
    earlier = load("input/matrix-scope-audit-v1.json")
    assert cap == earlier["ratio_cap"] == 48
    allowed = {direction(-b, a) for a, b in model["normal_families"]}
    rotations = [g["matrix"] for g in model["groups"] if det(g["matrix"]) == 1]
    assert len(rotations) == 6
    rotation = [[0,-1], [1,1]]
    current = [[1,0], [0,1]]
    for _ in range(6):
        assert current in rotations
        current = product(current, rotation)
    assert current == [[1,0], [0,1]]
    rays = {(1,0), (1,1)}
    assert {direction(*move(r, p)) for r in rotations for p in rays} == allowed
    assert len(allowed) == 6
    poly = model["polygon"]
    actual = {direction(c-a, d-b) for (a,b),(c,d) in zip(poly,poly[1:]+poly[:1])}
    assert {direction(*move(r, p)) for r in rotations for p in actual} == allowed
    reps = [s for name in ("small", "wide")
            for s in load(f"input/previous-{name}-protocol-v1.json")["scales"]]
    assert len(reps) == 9
    by_ratio = Counter()
    exclusions = []
    bound = protocol["coordinate_bound"]
    assert 3*(bound+1)**2 > 4*cap
    for a in range(-bound, bound+1):
        for b in range(-bound, bound+1):
            n = a*a+a*b+b*b
            if not 1 < n <= cap:
                continue
            matrix = [[a,-b], [b,a+b]]
            matches = sorted(direction(*move(matrix, q)) for q in allowed)
            if set(matches).isdisjoint(allowed):
                exclusions.append(dict(ratio=n, matrix=matrix, image=matches))
            else:
                assert set(matches) == allowed
                r, = [s for s in reps if s["ratio"] == n]
                assert any(product(g, r["matrix"]) == matrix for g in rotations)
                by_ratio[n] += 1
    assert [(r["ratio"],r["matrix"]) for r in exclusions] == [
        (r["ratio"],r["matrix"]) for r in earlier["excluded"]]
    assert len(exclusions) == 108
    assert by_ratio == {r["ratio"]:6 for r in reps}
    result = dict(status="CHECKED_GLOBAL_EDGE_DIRECTION_REDUCTION", directions=sorted(allowed),
                  scale_orbit_representatives=reps, excluded=exclusions, ratio_cap=cap,
                  preserving_matrices=sum(by_ratio.values()), total=sum(by_ratio.values())+len(exclusions),
                  scope="All integral similarities up to ratio 48. Excluded matrices send every permitted edge direction outside the permitted family, independent of which directions are exposed on a finite macro-tile.")
    with (ROOT / "data/scope-v1.json").open("x") as out:
        json.dump(result, out, sort_keys=True, separators=(",", ":"))
        out.write("\n")
    print(json.dumps({k:v for k,v in result.items() if k!="excluded"}), flush=True)


if __name__ == "__main__":
    main()
