"""Audit saved Turtle results and render the three-tile inflation reader."""

from collections import Counter
import hashlib
from html import escape
import json
from math import sqrt
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
STEM = "turtle-three-cluster-screen-20261105-v1"
OLD = "turtle-inflation-screen-20261105-v1.html"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def freeze(root):
    p = read(root / "protocol-v1.json")
    assert all(pin(root / name) == value for name,value in p["pins"].items())
    return p


def lines(path):
    with path.open() as stream:
        yield from map(json.loads, stream)


def receipt(root, path):
    result = read(root / path)
    assert all(pin(root / name) == value for name,value in result["files"].items())
    return result


def node_count(node):
    assert node["status"] == "NEGATIVE"
    return 1 + sum(node_count(child) for _,child in node["children"])


def matrix(m,p):
    x,y = p
    a,b = m
    return a[0]*x+a[1]*y,b[0]*x+b[1]*y


def polygon(model,p):
    g,x,y = p
    m = model["groups"][g]["matrix"]
    return [(u+x,v+y) for u,v in map(lambda q: matrix(m,q), model["polygon"])]


def audit():
    root = ROOT / "input"
    for part in ("bank","learning","small","small/survivor","small/early-stop-control",
                 "small/interleaved-control","wide","wide/tail","wide/scope"):
        freeze(root / part)
    bank = read(root/"bank/data/three-bank-v1.json")
    assert bank == read(root/"wide/input/three-bank-v1.json") == read(root/"small/input/three-bank-v1.json")
    assert bank["shapes"] == len(bank["bank"]) == 2241
    small = receipt(root/"small","data/closure-receipt-v1.json")
    survivor = read(root/"small/survivor/data/result-v1.json")
    assert small["all_inflated_negatives"] == 4482 and survivor["admitted"] == "NEGATIVE"
    assert survivor["checked"]["nodes"] == 2
    learned = read(root/"learning/data/summary-v1.json")
    assert learned["patterns"] == len(read(root/"wide/input/patterns-v1.json")) == 168
    assert pin(root/"learning/data/patterns-v1.json") == pin(root/"wide/input/patterns-v1.json")
    early = receipt(root/"small/early-stop-control","data/closure-v1.json")["comparison"]
    interleaved = receipt(root/"small/interleaved-control","data/closure-v1.json")["comparison"]
    wide = read(root/"wide/data/summary-v1.json")["scales"]
    scope = read(root/"wide/scope/data/scope-v1.json")
    assert (scope["total"], scope["preserving_matrices"], len(scope["excluded"])) == (162,54,108)
    families = read(root/"wide/tail/data/summary-v1.json")["families"]
    examples = {}
    for spec in scope["scale_orbit_representatives"]:
        ratio = spec["ratio"]
        if ratio < 9:
            rows = list(lines(root/f"small/data/ratio-{ratio:02d}-v1.jsonl"))
            assert len(rows) == 2241 and all(row["type"] == i and row["ratio"] == ratio
                                             for i,row in enumerate(rows))
            full = [r["type"] for r in rows if not r["empty"]]
            assert full == ([survivor["type"]] if ratio == 4 else [])
            continue
        counts = Counter()
        for i,row in enumerate(lines(root/f"wide/data/ratio-{ratio:02d}-v1.jsonl")):
            assert row["type"] == i and row["ratio"] == ratio
            raw = row["raw"]
            assert row["checked"]["status"] == "VERIFIED" and raw["status"] == "NEGATIVE"
            size = node_count(raw["tree"])
            assert size == row["checked"]["nodes"] == raw["nodes"] and 1 <= size <= 3
            counts.update(("NEGATIVE",f"negative_nodes_{size}"))
            counts["nodes"] += size
            counts["mark_hits"] += raw["mark_hits"]
            counts["domain_checks"] += raw["domain_checks"]
            if ratio == 9 and i == 0:
                examples["root"] = dict(case=i,spec=spec,tree=raw["tree"])
            if ratio == 48 and size == 2 and "forced" not in examples:
                examples["forced"] = dict(case=i,spec=spec,tree=raw["tree"])
        expected = {k:v for k,v in wide[str(ratio)].items() if k != "geometry_replays"}
        assert counts == expected and counts["NEGATIVE"] == 2241
    for family in families:
        ratio = family["ratio"]
        counts,starts = Counter(),Counter()
        assert pin(root/f"wide/data/ratio-{ratio:02d}-v1.jsonl") == pin(root/f"wide/tail/input/ratio-{ratio}-v1.jsonl")
        for i,row in enumerate(lines(root/f"wide/tail/data/ratio-{ratio}-tail-v1.jsonl")):
            assert row["type"] == i
            if row["winner"]:
                cut,anchor = row["winner"]
                last = row["trials"][-1]
                assert last["tail"] and anchor == last["anchor"] and cut == last["checked_at"]
                assert cut == max(row["first"],last["uniform_bound"])
                assert not row["unresolved_bridge"]
                counts["tail"] += 1
                counts["fully_contiguous"] += 1
                counts["gap_cases"] += 0
                starts[str(cut)] += 1
            else:
                assert not any(t["tail"] for t in row["trials"])
                counts["unresolved_tail"] += 1
        assert counts == family["counts"] and starts == family["thresholds"]
        assert counts["tail"]+counts["unresolved_tail"] == 2241
    assert set(examples) == {"root","forced"}
    data = dict(status="CHECKED_THREE_TILE_INFLATION_REPORT", shapes=2241, finite_cases=20169,
                finite_negatives=20169, scale_cap=48, matrices=scope["total"],
                matrices_excluded_by_edge_directions=len(scope["excluded"]),
                learned_patterns=learned["patterns"], roots=small["inflated"],
                wide=wide, tails=families, early=early, interleaved=interleaved, examples=examples)
    return data, bank["bank"], read(root/"wide/input/exact-point-model-v1.json")


def drawing(model, shapes, example, label):
    transform = example["spec"]["matrix"]
    tiles = [[matrix(transform,q) for q in polygon(model,p)] for p in shapes[example["case"]]]
    root = example["tree"]
    scale = model["scale"]
    node = root
    forced = None
    if root["children"]:
        ((key,node),) = root["children"]
        forced = polygon(model,key)
    origin = tuple(a/scale for a in node["point"])
    start = tuple(a/scale for a in root["point"])
    marks = [(origin[0]+x/scale,origin[1]+y/scale)
             for x,y in node.get("mark",{}).get("stencil",[])]
    def screen(p):
        x,y = p
        return x+y/2,-y*sqrt(3)/2
    bounds = [screen(p) for p in (origin,start,*marks,*list(forced or ()))]
    xs,ys = zip(*bounds)
    pad = 2.2
    view = f"{min(xs)-pad:.3f} {min(ys)-pad:.3f} {max(xs)-min(xs)+2*pad:.3f} {max(ys)-min(ys)+2*pad:.3f}"
    def shape(poly,color,stroke):
        points = " ".join(f"{x:.3f},{y:.3f}" for x,y in map(screen,poly))
        return f'<polygon points="{points}" fill="{color}" stroke="{stroke}" stroke-width=".13"></polygon>'
    def dot(p,color,size):
        x,y = screen(p)
        return f'<circle cx="{x:.3f}" cy="{y:.3f}" r="{size}" fill="{color}" stroke="white" stroke-width=".07"></circle>'
    parts = [shape(t,color,"#426165") for t,color in zip(tiles,("#c4e7e3","#d9e8f9","#e7dcf4"),strict=True)]
    if forced:
        parts += [shape(forced,"#ffd287","#8c580d"),dot(start,"#a65c0a",.2)]
    parts += [dot(p,"#6b4bbb",.17) for p in marks]
    parts += [dot(origin,"#bd2841",.26)]
    svg = f'<svg viewBox="{view}" role="img" aria-label="{escape(label)}">'+''.join(parts)+'</svg>'
    ElementTree.fromstring(svg)
    return svg


def table(headers, rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{h}</th>' for h in headers)+(
        '</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{v}</td>' for v in row)+'</tr>' for row in rows)+
        '</tbody></table></div>')


def render(data, shapes, model):
    rows = [[3,"2,241","0","0"],[4,"2,240","1","0"]]
    for ratio,entry in data["wide"].items():
        rows.append([int(ratio),*(f'{entry.get(f"negative_nodes_{i}",0):,}' for i in (1,2,3))])
    rows.sort()
    finite = table(("Area ratio","One-node certificates","Two-node certificates","Three-node certificates"),
                   [(rf"\({r[0]}\)",*r[1:]) for r in rows])
    tail = table(("Similarity ray","First untested multiplier before this step",
                  "Shapes excluded at every later multiplier","Shapes still open at some later multiplier"),
                 [(r"\(k^2\)",7,"114","2,127"),(r"\(3k^2\)",5,"1,499","742")])
    cohorts = ("inflations","tileable_controls","mixed")
    def percentages(method, field):
        return [rf"\({(data[method][group][field]-1)*100:+.1f}\%\)" for group in cohorts]
    methods = table(("Root-check method","Inflated targets","Known tileable controls","Mixed sample"),
                    [("Whole marking pass, then early-exit exact",*percentages("early","hybrid_vs_exact")),
                     ("Mark only the current exact query",*percentages("interleaved","interleaved_vs_exact"))])
    root = drawing(model,shapes,data["examples"]["root"],"A dead required cell and its blocked stencil near the target boundary")
    forced = drawing(model,shapes,data["examples"]["forced"],"A forced tile leaves a later required cell with no legal alignment")
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Three-Turtle inflations and transferable markings</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{{font-family:system-ui,sans-serif;color:#17313d;background:#edf2f3}}body{{margin:0}}
main{{max-width:66rem;margin:auto;padding:2.3rem clamp(1rem,4vw,2.7rem) 4rem;background:#fff}}
h1,h2{{line-height:1.18}}h1{{font-size:clamp(2.2rem,6vw,3.6rem);letter-spacing:-.042em;margin:.35em 0}}
h2{{margin-top:2.1rem}}p,li{{line-height:1.57}}a{{color:#0a5c76}}.meta{{color:#47616b}}
nav{{display:flex;flex-wrap:wrap;gap:1rem;margin:1.2rem 0 2rem}}.scroll{{overflow:auto}}
table{{border-collapse:collapse;width:100%;text-align:left}}th,td{{padding:.6rem;border-bottom:1px solid #d4e1e2}}
th{{background:#e9f1f1}}tbody tr:nth-child(even){{background:#f6f8f8}}
.figures{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1.1rem}}
figure{{margin:0;padding:.8rem;border:1px solid #c4d8da;border-radius:.55rem}}
svg{{width:100%;height:14rem;background:#f6f8fa;border-radius:.35rem}}figcaption{{margin-top:.5rem}}
.metrics{{background:#e4f2ef;padding:1rem 1.2rem;border-left:.35rem solid #168271}}
</style></head>
<body><main><p class="meta">Geometric tree search · Turtle experiments · November 5, 2026</p>
<h1>Three-Turtle inflations and transferable markings</h1>
<p class="metrics">Every one of the 2,241 edge-connected three-Turtle shapes fails the primitive-cover test at every lattice-preserving similarity of area ratio greater than \(1\) and at most \(48\). The search checked 20,169 shape and scale pairs after symmetry reduction.</p>
<nav aria-label="Sections"><a href="#finite">Finite certificates</a><a href="#scale">Larger multipliers</a><a href="#markings">Marking costs</a><a href="#evidence">Evidence</a></nav>
<section id="finite"><h2>Finite certificates</h2>
<p>The three-tile bank enumerates every way to extend an edge-connected pair by a third Turtle, then identifies identical supports under translations and the twelve lattice point actions. A legal connection shares a segment of positive length. Of the 8,036 candidate extensions, 5,454 have disjoint interiors. They reduce to 2,241 distinct supports.</p>
<p>Each negative tree queries one required cell per node. Every legal alignment at that cell must appear as a child. A leaf has no legal alignment. The checker can replay the complete tree by absolute alignment enumeration without reading the learned bank. A partition into larger tiles from this library would also partition into primitives, so the primitive contradictions rule out a closed substitution within this bank at these scales.</p>
{finite}
<div class="figures"><figure>{root}<figcaption>At ratio \(9\), the red required cell has no legal alignment. The purple cells are outside the target and their relative positions hit every possible alignment.</figcaption></figure>
<figure>{forced}<figcaption>At ratio \(48\), the orange placement is forced at the orange cell. The red required cell then has no legal alignment. The two views are cropped around the proof.</figcaption></figure></div>
<p>All outer boundary directions of a finite Turtle cluster come from primitive edges. An integral similarity of the triangular lattice is multiplication by \(a+b\omega\), up to an allowed global reflection, where \(\omega=\exp(i\pi/3)\). The 108 excluded matrices send every legal edge direction outside the permitted family. The remaining 54 matrices reduce to the nine scales above. The two possible rays, up to allowed rotations, have area ratios \(k^2\) and \(3k^2\).</p></section>
<section id="scale"><h2>Reusing one proof at arbitrarily large multipliers</h2>
<p>The finite proof can sometimes move with a cluster vertex. In sample coordinates, write a tested point as \(k s v+p\), where \(v\) is the anchor vertex in the base shape and \(s=18\). The side of each scaled supporting line with normal \(n\) and base constant \(b\) is given by \(k s(n\cdot v-b)+n\cdot p\). Bounds on the second term give an exact multiplier beyond which the side stays constant for every atom the proof might inspect. The verifier then checks the translated proof at that multiplier and separately checks any intervening multipliers.</p>
{tail}
<p>The two rows describe different similarity rays. Some saved contradictions move with a vertex and retain every legal branch. Other saved trees fail to transfer by this procedure. For those shapes the result beyond the finite screen remains open. The current search gives neither a substitution witness nor a plane-tiling conclusion.</p></section>
<section id="markings"><h2>When the learned markings save time</h2>
<p>The bank contains 168 patterns learned from earlier two-tile failures. Each pattern records three to five unavailable cells whose relative offsets intersect all 240 primitive alignments of a queried cell. An exact check can independently reproduce the rejected domain.</p>
<p>On the 4,482 smaller inflations, full bounding-box enumeration used 27.6 times the root-check CPU of a whole-grid marking pass with exact fallback. That enumeration constructs every contained placement. An early-exit baseline stops as soon as it finds one dead cell and reuses the covered sites of every legal placement it discovers.</p>
{methods}
<p>The whole-pass comparison against early exit used 256 inflations and 96 controls. The current-query comparison used a separate set of 512 inflations and 192 controls. Values are changes in paired aggregate CPU for the root check relative to exact early exit. Geometry authoring and certificate replay are outside the timed stage. The two protocols used different cohorts and establish no end-to-end search speedup.</p></section>
<section id="evidence"><h2>Evidence</h2><ul>
<li><a href="{STEM}-results.json">Machine-readable results</a></li>
<li><a href="{STEM}-evidence.zip">Full source, frozen inputs, raw proof trees and logs</a></li>
<li><a href="{STEM}-manifest.json">Byte lengths and SHA-256 hashes</a></li>
<li><a href="{OLD}">Earlier one- and two-Turtle inflation reader</a></li>
</ul></section></main></body></html>"""


def main():
    data,bank,model = audit()
    report = render(data,bank,model)
    with (ROOT/"report"/(STEM+".html")).open("x") as out:
        out.write(report)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as out:
        json.dump(data,out,indent=2,sort_keys=True)
        out.write("\n")
    print(json.dumps(dict(status=data["status"],finite_cases=data["finite_cases"],
                          tails=[r["counts"] for r in data["tails"]])))


if __name__ == "__main__":
    main()
