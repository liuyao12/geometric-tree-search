"""Exact contained-placement coverage for small Turtle inflations."""

from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    b=path.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def save(name,value):
    with (ROOT/name).open("x") as stream:
        json.dump(value,stream,separators=(",",":"),sort_keys=True)
        stream.write("\n")


def move(matrix,p):
    (a,b),(c,d)=matrix
    x,y=p
    return a*x+b*y,c*x+d*y


def bbox(poly):
    x,y=zip(*poly)
    return min(x),max(x),min(y),max(y)


def inside(point,polygon):
    x,y=point
    winding=0
    for (a,b),(c,d) in zip(polygon,polygon[1:]+polygon[:1]):
        side=(c-a)*(y-b)-(d-b)*(x-a)
        if b<=y<d and side>0:
            winding+=1
        if d<=y<b and side<0:
            winding-=1
    return winding!=0


def screen(matrix,model,occupied,oriented,ref):
    started=time.perf_counter()
    scale=model["scale"]
    prototype=list(map(tuple,model["polygon"]))
    polygon=[move(matrix,p) for p in prototype]
    scaled=[(x*scale,y*scale) for x,y in polygon]
    x0,x1,y0,y1=bbox(polygon)
    normals=set(map(tuple,model["normal_families"]))
    assert all(ref.primitive(d-b,a-c) in normals for (a,b),(c,d) in ref.edges(polygon))
    weights={tuple(q):Fraction(*cell["area2"]) for q,cell in zip(model["orbit_residues"],model["cells"],strict=True)}
    assert len(weights)==12
    target={(x*scale+u,y*scale+v) for x in range(x0,x1) for y in range(y0,y1)
            for u,v in weights if inside((x*scale+u,y*scale+v),scaled)}
    target_area=abs(ref.area2(polygon))
    ratio=target_area//abs(ref.area2(prototype))
    assert sum(weights[x%scale,y%scale] for x,y in target)==target_area
    assert target_area==ratio*abs(ref.area2(prototype))
    placements=[]
    union=set()
    tested=0
    for g,p,sites in oriented:
        a,b,c,d=bbox(p)
        for x in range(x0-a,x1-b+1):
            for y in range(y0-c,y1-d+1):
                tested+=1
                dx,dy=x*scale,y*scale
                if all((u+dx,v+dy) in target for u,v in sites):
                    placements.append((g,x,y))
                    union.update((u+dx,v+dy) for u,v in sites)
    uncovered=sorted(target-union)
    proof=None
    if uncovered:
        qx,qy=uncovered[0]
        assert ref.inside((Fraction(qx,scale),Fraction(qy,scale)),polygon)
        exhaustive=[]
        # Any placement covering this open atom has this sample after translation.
        for g,p,sites in oriented:
            for a,b in sites:
                dx,dy=qx-a,qy-b
                if dx%scale or dy%scale:
                    continue
                witness=next((u+dx,v+dy) for u,v in sites if (u+dx,v+dy) not in target)
                assert not ref.inside(tuple(Fraction(t,scale) for t in witness),polygon)
                exhaustive.append(dict(placement=(g,dx//scale,dy//scale),outside=witness))
        assert len({tuple(r["placement"]) for r in exhaustive})==len(exhaustive)
        proof=dict(atom=uncovered[0],covering_alignments=exhaustive)
    return dict(matrix=matrix,ratio=ratio,polygon=polygon,target=sorted(target),
        placements=placements,tested=tested,uncovered=uncovered,empty_atom_certificate=proof,
        seconds=time.perf_counter()-started)


def main():
    protocol=read("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/p)==v for p,v in protocol["pins"].items())
    sys.path.insert(0,str(ROOT/"source"))
    import turtle_points_v1 as ref
    model=read("input/exact-point-model-v1.json")
    assert read("input/carrier-check-v1.json")["status"]=="VERIFIED"
    original=list(map(tuple,model["polygon"]))
    g=model["groups"]
    scale=model["scale"]
    occupied={(x,y) for x,y,u in model["occupancy_field"] if u==12}
    assert len(occupied)==240 and scale==18
    orientation=[]
    for row in g:
        M=row["matrix"]
        p=[move(M,v) for v in original]
        q=sorted({move(M,v) for v in occupied})
        assert len(q)==240
        orientation.append((row["id"],p,q))
    reports=[]
    for matrix in protocol["matrices"]:
        row=screen(matrix,model,occupied,orientation,ref)
        reports.append(row)
        print(json.dumps(dict(ratio=row["ratio"],target=len(row["target"]),tested=row["tested"],
              contained=len(row["placements"]),uncovered=len(row["uncovered"]),
              certificate_alignments=len(row["empty_atom_certificate"]["covering_alignments"])
              if row["empty_atom_certificate"] else None,seconds=row["seconds"])),flush=True)
    save("data/contained-coverage-v1.json",dict(status="EXACT_SMALL_INFLATION_COVERAGE_SCREEN",
         scale=scale,rows=reports,protocol=pin(ROOT/"protocol-v1.json"),
         scope="Monotype Turtle inflations of the listed exact matrices. An empty target atom certifies finite impossibility. Covered support alone leaves exact cover unresolved."))


if __name__=="__main__":
    main()
