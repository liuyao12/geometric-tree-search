"""Audit exact Turtle substitution screens and render a visual report."""

from collections import Counter
from fractions import Fraction
import gzip
import hashlib
from math import sqrt
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
STEM="turtle-inflation-screen-20261105-v1"


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    raw=path.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def uncompress(path):
    with gzip.open(path,"rt") as stream:
        return json.load(stream)


def check_frozen(folder):
    r=read(folder/"protocol-v1.json")
    for name,expected in r["pins"].items():
        assert pin(folder/name)==expected,name
    return r


def move(matrix,p):
    a,b=matrix
    x,y=p
    return a[0]*x+a[1]*y,b[0]*x+b[1]*y


def translate(points,dx,dy):
    return tuple((x+dx,y+dy) for x,y in points)


def tree_size(node):
    return 1+sum(tree_size(child) for _,child in node.get("children",[]))


def monotype(model):
    proto=check_frozen(ROOT)
    check_frozen(ROOT/"cover")
    screening=read(ROOT/"data/contained-coverage-v1.json")
    assert screening["status"]=="EXACT_SMALL_INFLATION_COVERAGE_SCREEN"
    assert screening["protocol"]==pin(ROOT/"protocol-v1.json")
    assert screening==read(ROOT/"cover/input/contained-coverage-v1.json")
    assert [r["matrix"] for r in screening["rows"]]==proto["matrices"]
    matrices=read(ROOT/"data/matrix-scope-audit-v1.json")
    assert matrices["status"]=="PASS_MATRIX_ORBITS_AND_EDGE_EXCLUSIONS"
    assert matrices["ratio_cap"]==48 and len(matrices["excluded"])==108
    ratios=[r["ratio"] for r in screening["rows"]]
    assert sorted(map(int,matrices["orbit_sizes"]))==ratios and set(matrices["orbit_sizes"].values())=={6}
    sys.path.insert(0,str(ROOT/"source"))
    import turtle_points_v1 as ref
    actual_edges=list(ref.edges(model["polygon"]))
    normals=set(map(tuple,model["normal_families"]))
    for r in matrices["excluded"]:
        a,b=actual_edges[r["edge"]]
        u,v=move(r["matrix"],(b[0]-a[0],b[1]-a[1]))
        assert ref.primitive(v,-u) not in normals
    cover={r["ratio"]:r for r in uncompress(ROOT/"cover/data/exact-cover-results-v1.json.gz")}
    shapes={g["id"]:tuple(move(g["matrix"],(x,y)) for x,y,u in model["occupancy_field"])
            for g in model["groups"]}
    scale=model["scale"]
    rows=[]
    examples=[]
    for r in screening["rows"]:
        ratio=r["ratio"]
        target=set(map(tuple,r["target"]))
        assert len(target)==240*ratio
        def aligned(point):
            x,y=point
            for g,pts in shapes.items():
                for a,b in pts:
                    dx,dy=x-a,y-b
                    if dx%scale==0 and dy%scale==0:
                        yield (g,dx//scale,dy//scale),set(translate(pts,dx,dy))
        proof=r["empty_atom_certificate"]
        if proof:
            q=tuple(proof["atom"])
            assert q in target and list(q) in r["uncovered"]
            assert ref.inside(tuple(Fraction(a,scale) for a in q),r["polygon"])
            trials={tuple(a["placement"]):tuple(a["outside"]) for a in proof["covering_alignments"]}
            exact=dict(aligned(q))
            assert len(exact)==len(trials)==240 and set(exact)==set(trials)
            for key,out in trials.items():
                assert out in exact[key] and out not in target
                assert not ref.inside(tuple(Fraction(a,scale) for a in out),r["polygon"])
            nodes=1
            if ratio==3:
                examples.append(dict(ratio=ratio,polygon=r["polygon"],dead=q,forced=None,start=None))
        else:
            z=cover[ratio]
            assert z["raw"]["status"]=="NEGATIVE" and z["independent"]["status"]=="VERIFIED"
            def replay(node,filled):
                q=tuple(r["target"][node["atom"]])
                assert q not in filled and node["status"]=="NEGATIVE"
                admissible={key:pts for key,pts in aligned(q) if pts<=target and not pts&filled}
                children={tuple(r["placements"][i]):child for i,child in node["children"]}
                assert set(children)==set(admissible) and len(children)==len(node["children"])
                for k,c in children.items():
                    replay(c,filled|admissible[k])
            tree=z["raw"]["tree"]
            replay(tree,set())
            nodes=tree_size(tree)
            assert nodes==z["independent"]["nodes"]==2
            i,child=tree["children"][0]
            examples.append(dict(ratio=ratio,polygon=r["polygon"],dead=r["target"][child["atom"]],
                                 start=r["target"][tree["atom"]],forced=r["placements"][i]))
        rows.append(dict(ratio=ratio,tested=r["tested"],contained=len(r["placements"]),
                         empty=len(r["uncovered"]),nodes=nodes))
    return rows,examples,matrices


def clusters():
    folder=ROOT/"clusters"
    check_frozen(folder)
    small=uncompress(folder/"data/results-v1.json.gz")
    assert small["protocol"]==pin(folder/"protocol-v1.json")
    folder=ROOT/"wide"
    wide_protocol=check_frozen(folder)
    wide=uncompress(folder/"data/results-v1.json.gz")
    assert wide["protocol"]==pin(folder/"protocol-v1.json")
    assert small["status"]==wide["status"]=="CHECKED_CLUSTER_SCREEN"
    assert small["rooted"]==wide["rooted"]==82 and small["bank"]==wide["bank"]
    bank=small["bank"]
    assert len(bank)==49
    def detailed():
        yield from small["scales"]
        for item in wide["scales"]:
            r=item["artifact"]
            path=folder/r["path"]
            assert pin(path)=={k:r[k] for k in ("bytes","sha256")}
            d=uncompress(path)
            assert d["ratio"]==item["ratio"] and len(d["closed"])==item["closed"]
            assert dict(Counter(x["admitted"] for x in d["primitive"]))==item["primitive"]
            yield d
    assert [s["ratio"] for s in wide_protocol["scales"]]==[r["ratio"] for r in wide["scales"]]
    summaries=[]
    for row in detailed():
        ratio=row["ratio"]
        assert [d["type"] for d in row["problem_geometry"]]==list(range(len(bank)))
        assert all(len(d["target"])==480*ratio for d in row["problem_geometry"])
        assert [d["type"] for d in row["primitive"]]==list(range(len(bank)))
        def validate(item,kind):
            status=item["admitted"]
            assert status==(item["raw"]["status"] if item["verification"]["status"]=="VERIFIED" else "UNKNOWN")
            if status=="NEGATIVE":
                assert item["verification"]["nodes"]==tree_size(item["raw"]["tree"])
            if status=="POSITIVE":
                expected=ratio if kind=="cluster" else 2*ratio
                assert len(item["witness"])==expected
                assert len(item["verification"]["primitive_placements"])==2*ratio
        for item in row["primitive"]:
            validate(item,"primitive")
        count=Counter(r["admitted"] for r in row["primitive"])
        active={r["type"] for r in row["primitive"] if r["admitted"]!="NEGATIVE"}
        last={}
        for rnd in row["rounds"]:
            assert rnd["active"]==sorted(active)
            last={r["type"]:r for r in rnd["records"]}
            assert set(last)==active and len(last)==len(rnd["records"])
            for item in last.values():
                validate(item,"cluster")
            dead={i for i,r in last.items() if r["admitted"]=="NEGATIVE"}
            assert rnd["removed"]==sorted(dead)
            active-=dead
        assert sorted(active)==row["remaining"]
        closed={int(i):w for i,w in row["closed"].items()}
        assert set(closed)<=active
        for i,witness in closed.items():
            assert last[i]["admitted"]=="POSITIVE" and last[i]["witness"]==witness
            assert all(p[0] in closed for p in witness)
        summaries.append(dict(ratio=ratio,primitive=dict(count),
            primitive_nodes=sum(r["raw"]["visits"] for r in row["primitive"]),
            empty_leaf=sum(r["admitted"]=="NEGATIVE" and r["verification"]["nodes"]==1
                           for r in row["primitive"]),
            rounds=len(row["rounds"]),remaining=len(active),closed=len(closed)))
    assert [r["ratio"] for r in summaries]==[3,4,9,12,16,25,27,36,48]
    return bank,summaries


def polygon(model,placement):
    g,x,y=placement
    matrix=model["groups"][g]["matrix"]
    return translate([move(matrix,p) for p in model["polygon"]],x,y)


def svg(layers,points,label):
    def xy(p):
        x,y=p
        return x+y/2,-y*sqrt(3)/2
    positions=[xy(p) for tile,_,_ in layers for p in tile]+[xy(p) for p,_ in points]
    xs,ys=zip(*positions)
    view=f'{min(xs)-.55:.4f} {min(ys)-.55:.4f} {max(xs)-min(xs)+1.1:.4f} {max(ys)-min(ys)+1.1:.4f}'
    parts=[]
    for poly,color,stroke in layers:
        vertices=' '.join(f'{x:.5f},{y:.5f}' for x,y in map(xy,poly))
        parts.append(f'<polygon points="{vertices}" fill="{color}" fill-opacity=".75" '
                     f'stroke="{stroke}" stroke-width=".10"></polygon>')
    for p,color in points:
        x,y=xy(p)
        parts.append(f'<circle cx="{x:.5f}" cy="{y:.5f}" r=".32" fill="{color}" stroke="white" stroke-width=".07"></circle>')
    return f'<svg viewBox="{view}" role="img" aria-label="{label}">'+''.join(parts)+'</svg>'


def table(headers,rows):
    return ('<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{x}</th>' for x in headers)
            +'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{x}</td>' for x in row)+'</tr>' for row in rows)
            +'</tbody></table></div>')


def render(model,mono,examples,bank,cluster):
    mono_rows=[[r[k] for k in ("ratio","tested","contained","empty","nodes")] for r in mono]
    cluster_rows=[]
    for r in cluster:
        p=r["primitive"]
        cluster_rows.append([r["ratio"],p.get("POSITIVE",0),p.get("NEGATIVE",0),p.get("UNKNOWN",0),
            r["empty_leaf"],r["rounds"],r["remaining"],r["closed"]])
    scale=model["scale"]
    figures=[]
    for e in examples:
        outlines=[(e["polygon"],"#edf2e9","#2d5547")]
        points=[(tuple(v/scale for v in e["dead"]),"#ab315e")]
        if e["forced"]:
            outlines.append((polygon(model,e["forced"]),"#efbd70","#9a5e14"))
            points.append((tuple(v/scale for v in e["start"]),"#277865"))
        graphic=svg(outlines,points,f'Area ratio {e["ratio"]} obstruction')
        text=("The magenta cell has no contained cover." if not e["forced"] else
              "The green cell forces the ochre tile. The magenta cell then has no disjoint cover.")
        figures.append(f'<figure><figcaption>Area ratio {e["ratio"]}</figcaption>{graphic}<p>{text}</p></figure>')
    tiles=[]
    for i,(a,b) in enumerate(bank):
        graphic=svg([(polygon(model,a),"#b6dbc8","#266351"),(polygon(model,b),"#efd5a0","#a76626")],
                    [],f'Two-tile cluster {i}')
        tiles.append(f'<figure><figcaption>Type {i}</figcaption>{graphic}</figure>')
    tested=len(bank)*len(cluster)
    neg=sum(r["primitive"].get("NEGATIVE",0) for r in cluster)
    return HEAD+fr'''
<section id="single"><h2>Single-Turtle inflations</h2>
<p>The screen considers lattice-preserving similarities with area ratio greater than one
and at most 48. A target boundary edge must run in a primitive edge direction. The
integer-matrix audit excluded 108 orientation-preserving matrices by that condition.
The 54 remaining matrices reduce by rotation to the nine rows below. Reflection can
be absorbed into an allowed action.</p>
{table(("Area ratio","Candidate shifts tested","Contained placements","Initially empty cells","Negative tree nodes"),mono_rows)}
<div class="figures">{''.join(figures)}</div>
<p>The exact rational cell arrangement samples the open cells cut out by all allowed
boundary lines. Every legal placement covering a sampled point occupies its whole open
cell. In seven cases one required cell has no contained primitive placement. In the
other two, an independently replayed forced placement creates an empty cell.</p>
</section>
<section id="clusters"><h2>Two-tile clusters as candidate macrotypes</h2>
<p>From the complete contact catalogue, 82 rooted placements share a positive-length
boundary segment and have disjoint interiors. Exact translation and orientation
normalization gives {len(bank)} cluster shapes. The screen checked {tested} inflated
targets and proved {neg} impossible to partition into primitives.</p>
{table(("Area ratio","Primitive positive","Primitive negative","Unresolved","One-node negatives",
        "Cluster rounds","Remaining types","Checked closed family"),cluster_rows)}
<p>A cluster cover would also give a primitive cover. A type with a checked primitive
failure can therefore be removed before cluster search. Any surviving type must have
its own checked partition into members of one common closed family.</p>
<details><summary>Inspect all {len(bank)} cluster shapes</summary><div class="bank">{''.join(tiles)}</div></details>
</section>
<section id="scope"><h2>Finite certificate scope</h2>
<p>The sampled atom carrier is periodic on \(A_2\). Its boundary directions are multiples
of \(30^\circ\). After a global rotation, an admissible lattice similarity is an integer
multiple of \(1\) or \(1+\omega\), with \(\omega=\exp(i\pi/3)\). Their area ratios are
\(k^2\) and \(3k^2\). The two-cluster screen uses these same nine representatives and
the declared edge-connected pair library.</p>
<p>These certificates rule out particular finite substitutions. A plane construction
would require a recursive family of exact partitions and a separate argument that its
iterates cover arbitrarily large regions. Larger clusters and other inflation scales
remain open.</p>
</section>
'''+END


HEAD=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Turtle inflation certificates</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{color-scheme:light;--ink:#18372f;--rule:#cbd9ce;--paper:#f6f4e9}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}
main{max-width:1160px;margin:auto;padding:24px}header{max-width:850px;padding:26px 0}
h1{font:clamp(2.2rem,5vw,4rem)/1.07 Georgia,serif;margin:.5em 0}h2{font:1.75rem/1.15 Georgia,serif;margin:0 0 .55em}
a{color:#16654f}.eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.12em}
section{background:#fffdfa;border:1px solid var(--rule);border-radius:12px;padding:18px;margin-bottom:18px}
.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:.88rem}
td,th{text-align:left;vertical-align:top;padding:8px;border-bottom:1px solid var(--rule)}
.figures,.bank{display:grid;gap:12px;margin:12px 0}.figures{grid-template-columns:repeat(auto-fit,minmax(min(100%,265px),1fr))}
.bank{grid-template-columns:repeat(auto-fit,minmax(126px,1fr))}
figure{margin:0;background:#eef5ee;border-radius:8px;padding:9px}figcaption,summary{font-weight:650}
figure p{font-size:.88rem;margin:.4em 0}summary{cursor:pointer}svg{width:100%;height:200px;display:block}.bank svg{height:105px}
</style></head><body><main>
<header><p class="eyebrow">GCTS research · exact Turtle geometry</p>
<h1>Turtle inflation certificates</h1>
<p>An exact search tests whether enlarged Turtle shapes can be partitioned into the original
tile. The same test applies to a library of edge-connected pairs before attempting recursive
cluster substitutions.</p>
<p><a href="#single">Single shapes</a> · <a href="#clusters">Cluster library</a> ·
<a href="#evidence">Evidence archive</a></p></header>
'''


END=f'''<section id="evidence"><h2>Experiment records</h2>
<p>The archive includes every frozen protocol, complete primitive and cluster records,
independent replay receipts, the cell model and the exact candidate keys.</p>
<p><a href="{STEM}-evidence.zip">Full evidence archive</a> ·
<a href="{STEM}-manifest.json">Archive manifest</a> ·
<a href="{STEM}-results.json">Audited results</a> ·
<a href="guarded-regions-20261105-v1.html">Earlier Turtle region comparison</a></p>
</section></main></body></html>
'''


def main():
    model=read(ROOT/"input/exact-point-model-v1.json")
    mono,examples,scope=monotype(model)
    bank,cluster=clusters()
    assert [x["ratio"] for x in mono]==[x["ratio"] for x in cluster]
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(render(model,mono,examples,bank,cluster))
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(dict(status="PASS_SAVED_TURTLE_INFLATION_AUDIT",monotype=mono,
            examples=examples,scope=scope,bank=bank,cluster=cluster),f,sort_keys=True,separators=(",",":"))
        f.write("\n")


if __name__=="__main__":
    main()
