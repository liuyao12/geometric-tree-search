# Exact two-Turtle cluster substitution search

Use the complete saved catalogue of primitive relative placements. Select
pairs with disjoint interiors and a shared boundary segment of positive
length. Group their exact atom supports by lattice translation and the
twelve allowed point actions. Retain one two-piece realization per type.

For each type, inflate the union of its two polygons at the two smallest
admissible area ratios. Generate every contained primitive placement.
Run a bounded exact-cover search, checking positives by rational clipping,
nonoverlap and equality of area. Check negative trees by regenerating
every legal alignment at their queried atoms.

Build each contained cluster placement from its two constituent primitive
placements. A target that cannot be partitioned into primitives cannot
have a cluster partition. Remove each such type. Then attempt cluster
covers using the current library. Eliminate only types whose cluster
covers are independently exhausted. Repeat with the smaller library.
An unknown result never eliminates a type.

A finite closed family requires an independently checked partition of each
inflated member, with every child drawn from the same family. A positive
primitive partition leaves that condition open. The first search is
bounded to ratios three and four, two-tile types and the declared limits.
No known substitution or markings enter the search.
