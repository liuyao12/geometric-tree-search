Exact Turtle inflation and cluster screens

Open report/turtle-inflation-screen-20261105-v1.html. The report audits the
saved single-shape certificates and two-tile library. All exact inputs,
programs, limits, candidate keys, trees and independent receipts are included.

In a separate extracted copy, preserve the original data. The four drivers
resolve their inputs relative to their own directory. After creating an empty
data directory for the driver being reproduced, run the pinned Python:

    python -I -S -B source/preflight_v1.py
    python -I -S -B cover/source/cover_v1.py
    python -I -S -B clusters/source/cluster_v1.py
    python -I -S -B wide/source/cluster_v1.py

Each driver has its own protocol-v1.json. The cover and wide drivers include
the exact saved earlier outputs as pinned inputs. The matrix scope audit is
plan/scope_audit_v1.py. The report renderer audits the archived observations
and writes new outputs exclusively. Timings can vary between runs.
