# Substitution search over clusters

The nine single-shape representatives are excluded within the checked scope.
The next search should use the same exact atom carrier with a small library
of connected multi-tile patches. Qualify each library member against actual
geometry and canonicalize its shape under the allowed actions. A patch from
an angular-point run needs its own occupancy or polygon check.

An inflated cluster is the union of its inflated constituent polygons.
The constituent boundaries still lie in the periodic line arrangement for
the chosen lattice similarities, so their union can be represented by the
exact target cell set, including holes if present. Treat whole cluster
placements as candidates with inherited exact support. Keep primitive
completion and cluster completion as separate search outcomes. A primitive
completion by itself provides no recursive rule for the cluster inventory.

Start with two-tile edge-connected clusters and the smallest two similarity
ratios. Use the existing exact geometric contact catalogue as a source of
possible patches, with no known substitution or marked template input.
Retain exhaustive scope and cutoffs. A complete substitution certificate
needs an exact partition of every inflated macrotype by admitted macrotypes
of one finite closed inventory, with its expansion action and all
placements checked. Test a simple exact-cover control before learning a
ranking or receptor preference.

An exact closed family can yield growing patches by iteration when the
similarity conjugates the allowed orientation group and preserves integer
translations. A macrotype with nonempty interior then contains expanding
disks under iteration. A locally finite limit of these translated patches
provides a plane tiling. The compactness argument is a separate obligation
after a finite family is found and checked.
