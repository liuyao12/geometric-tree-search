# Scope of the small Turtle inflation screen

The primitive Turtle and its allowed point actions are those of the saved,
independently checked rational cell carrier. Let the lattice basis be
\((1,\omega)\) with \(\omega=\exp(i\pi/3)\). An orientation-preserving
similarity that maps the lattice into itself is multiplication by a
lattice element. A reflection can be absorbed by a global allowed action.

For a finite exact partition, a straight edge of the outer target polygon
must have a primitive edge direction. Its interior points lie on the
boundaries of finitely many tiles, and a nonparallel straight edge can
meet the outer edge in at most one point. All primitive edge directions
are multiples of \(30^\circ\). The original Turtle edge directions are
also in that family, so the rotation of the similarity must lie in the
same family. Modulo allowed global \(60^\circ\) rotations, its ray is
either \(1\) or \(1+\omega\). Integral lattice elements on those rays are
positive integer multiples of the stated generator. Thus the possible
area ratios are \(k^2\) and \(3k^2\).

The nine frozen matrices are the representatives with ratio greater than
one and at most \(48\). Each of seven matrices has an empty target atom.
For the chosen empty atom, every alignment of a primitive atom sample at
that point has a recorded sample outside the target. The two survivors
have independent two-node exact-cover contradictions. Their first query
has one contained placement and their next query has no disjoint
placement. These are finite certificates for the listed monotype
inflations. They do not establish the absence of cluster substitutions
or the nonexistence of a plane tiling.

Before publication, check the edge-direction argument against the literal
carrier and replay the full retained certificate data in the report
builder. Preserve both the coverage and exact-cover protocols.
