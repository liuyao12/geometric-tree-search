"""Check the finite matrix reduction against literal Turtle edge directions."""

from math import gcd
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((ROOT/name).read_bytes())


def normal(x,y):
    a,b=y,-x
    d=gcd(abs(a),abs(b))
    a,b=a//d,b//d
    return (-a,-b) if a<0 or a==0 and b<0 else (a,b)


def product(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)] for i in range(2)]


def det(m):
    return m[0][0]*m[1][1]-m[0][1]*m[1][0]


def main():
    protocol=read("protocol-v1.json")
    for name,expected in protocol["pins"].items():
        raw=(ROOT/name).read_bytes()
        assert expected==dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    model=read("input/exact-point-model-v1.json")
    poly=model["polygon"]
    edges=[(c-a,d-b) for (a,b),(c,d) in zip(poly,poly[1:]+poly[:1])]
    possible=set(map(tuple,model["normal_families"]))
    rotations=[g["matrix"] for g in model["groups"] if det(g["matrix"])==1]
    assert len(rotations)==6
    reps=protocol["matrices"]
    finite={}
    excluded=[]
    for a in range(-8,9):
        for b in range(-8,9):
            n=a*a+a*b+b*b
            if not 1<n<=48:
                continue
            m=[[a,-b],[b,a+b]]
            bad=next((i for i,(x,y) in enumerate(edges)
                      if normal(a*x-b*y,b*x+(a+b)*y) not in possible),None)
            if bad is not None:
                excluded.append(dict(matrix=m,edge=bad,ratio=n))
            else:
                matches=[r for r in reps if det(r)==n and any(product(g,r)==m for g in rotations)]
                assert len(matches)==1
                finite.setdefault(n,[]).append(m)
    assert set(finite)=={det(r) for r in reps} and all(len(v)==6 for v in finite.values())
    result=dict(status="PASS_MATRIX_ORBITS_AND_EDGE_EXCLUSIONS",ratio_cap=48,
                orbit_sizes={n:len(v) for n,v in finite.items()},excluded=excluded)
    with (ROOT/"data/matrix-scope-audit-v1.json").open("x") as f:
        json.dump(result,f,sort_keys=True);f.write("\n")
    print(len(excluded),sorted(finite),sum(map(len,finite.values())))


if __name__=="__main__":
    main()
