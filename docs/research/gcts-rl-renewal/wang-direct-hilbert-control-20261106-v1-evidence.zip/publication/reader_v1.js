async function bootProofReader(){
 const proof=document.getElementById('proof-select'),method=document.getElementById('proof-method');
 const line=document.getElementById('line-select'),host=document.getElementById('reader-host');
 const previous=document.getElementById('previous'),next=document.getElementById('next');
 let data,pending=Promise.resolve();
 function typeset(nodes){
  pending=pending.then(async()=>{await window.MathJax?.startup?.promise;await window.MathJax?.typesetPromise?.(nodes);});
  return pending;
 }
 function current(){return data[proof.value][method.value];}
 async function showLine(doMath=true){
  const page=host.querySelector('.case');if(!page)return;
  const template=[...page.querySelectorAll('.line-template')].find(n=>n.dataset.line===line.value);
  const slot=page.querySelector('.line-slot');
  window.MathJax?.typesetClear?.([slot]);slot.replaceChildren(template.content.cloneNode(true));
  previous.disabled=Number(line.value)<=1;next.disabled=Number(line.value)>=Number(page.dataset.lines);
  if(doMath)await typeset([slot]);
 }
 async function showProof(){
  window.MathJax?.typesetClear?.([host]);line.replaceChildren();
  const item=current();
  document.getElementById('reader-work').textContent=item.status==='PROVED'
   ? `${item.resolutions.toLocaleString()} search resolution attempts; ${item.logical_lines} logical records before transport or elaboration; ${item.lines} Wang proof records; ${item.steps.toLocaleString()} local tape steps before reuse.`
   : `Open at the ${item.stop.replaceAll('_',' ')} limit after ${item.resolutions.toLocaleString()} resolution attempts.`;
  if(item.status!=='PROVED'){
   host.textContent='This run returned no proof within its limits.';
   line.disabled=true;previous.disabled=true;next.disabled=true;return;
  }
  host.innerHTML=item.html;
  const page=host.querySelector('.case');page.hidden=false;
  for(let i=1;i<=item.lines;i++)line.add(new Option(String(i),String(i)));
  line.disabled=false;line.value=String(item.lines);
  await showLine(false);await typeset([host]);
 }
 try{
  const packed=document.getElementById('packed-reader').textContent.trim();
  const bytes=Uint8Array.from(atob(packed),c=>c.charCodeAt(0));
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  data=JSON.parse(await new Response(stream).text());
  proof.addEventListener('change',()=>showProof());method.addEventListener('change',()=>showProof());
  line.addEventListener('change',()=>showLine());
  previous.addEventListener('click',()=>{line.value=String(Number(line.value)-1);showLine();});
  next.addEventListener('click',()=>{line.value=String(Number(line.value)+1);showLine();});
  host.addEventListener('click',event=>{const jump=event.target.closest('button.jump');if(jump){line.value=jump.dataset.line;showLine();}});
  await showProof();host.dataset.ready='true';
 }catch(error){host.textContent='The packed proof reader could not open. The full replay archive contains all proofs.';throw error;}
}
document.addEventListener('DOMContentLoaded',bootProofReader);
