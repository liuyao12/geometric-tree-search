"""Package deterministic search evidence, proof receipts and the reader."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
NAME = "wang-direct-hilbert-control-20261106-v1"
README = """Direct-clause control for the exact symbolic Hilbert suite

Use Python 3.12 with assertions enabled, from the archive root:

  python3 -I -S -B source/stream_controls_v1.py
  python3 -I -S -B source/direct_study_v1.py
  python3 -I -S -B source/encoding_structure_v1.py
  python3 -I -S -B source/direct_controls_v1.py
  python3 -I -S -B source/syntax_controls_v1.py
  python3 -I -S -B source/direct_wang_v1.py
  python3 -I -S -B publication/render_v1.py

These commands check enumeration order, repeat all exact-source searches,
reproduce the earlier controls, transport every direct proof, reject damaged
transports, replay every distinct marked Wang proof, and regenerate the reader.
The native command supports --sample to check only the 695-record transported
three-link order proof against its archived receipt. Full native verification
was performed on every successful result; clean-extraction validation repeats
all searches and the largest transported sample. The proof reader stores its
views in an inline gzip payload and opens one proof at a time.
The manifest gives SHA-256 hashes for every included file.
"""


def contents():
    for d in ("source", "wang/source", "wang/external/source"):
        yield from (ROOT / d).glob("*.py")
    yield from (ROOT / "input").glob("*")
    yield ROOT / "data/direct-diagrams-v1.json.gz"
    yield ROOT / "data/direct-study-v1.json"
    yield ROOT / "data/direct-controls-v1.json"
    yield ROOT / "data/stream-controls-v1.json"
    yield ROOT / "data/encoding-structure-v1.json"
    yield ROOT / "data/syntax-controls-v1.json.gz"
    for n in ("render_v1.py", "proof_views_v1.py", "copy_views_v1.py", "group-notebook-head-v1.html",
              "direct-body-v1.html", "reader_v1.js", "style-v1.css", "check_browser_v1.cjs", "package_v1.py", "replay_archive_v1.py"):
        yield ROOT / "publication" / n
    yield ROOT / "report" / (NAME+".html")


def write(zipfile, name, data):
    item = ZipInfo(name, date_time=(2026, 11, 6, 0, 0, 0))
    item.external_attr = 0o100644 << 16
    zipfile.writestr(item, data, ZIP_DEFLATED, 6)


def main():
    target = ROOT / "report" / (NAME+"-evidence.zip")
    manifest = {}
    with ZipFile(target, "w") as archive:
        for path in sorted(contents()):
            name = path.relative_to(ROOT).as_posix()
            body = path.read_bytes()
            write(archive, name, body)
            manifest[name] = sha256(body).hexdigest()
        write(archive, "README.txt", README.encode())
        manifest["README.txt"] = sha256(README.encode()).hexdigest()
        write(archive, "MANIFEST.json", (json.dumps(manifest, sort_keys=True)+"\n").encode())
    print(target.name, target.stat().st_size, sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
