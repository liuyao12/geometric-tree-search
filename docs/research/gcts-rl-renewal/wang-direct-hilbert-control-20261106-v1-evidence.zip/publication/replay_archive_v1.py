"""Verify a clean archive extraction, repeat search, and check the largest transported sample."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[1]
NAME='wang-direct-hilbert-control-20261106-v1'


def main():
    archive=ROOT/'report'/(NAME+'-evidence.zip')
    with TemporaryDirectory(prefix='gcts-direct-replay-') as temp:
        target=Path(temp)
        with ZipFile(archive) as z:
            manifest=json.loads(z.read('MANIFEST.json'))
            assert set(z.namelist())==set(manifest)|{'MANIFEST.json'}
            for name,digest in manifest.items():
                path=Path(name)
                assert not path.is_absolute() and '..' not in path.parts
                assert sha256(z.read(name)).hexdigest()==digest
            z.extractall(target)
        tasks=[['source/stream_controls_v1.py'],['source/direct_study_v1.py'],
               ['source/encoding_structure_v1.py'],['source/direct_controls_v1.py'],['source/syntax_controls_v1.py'],['source/direct_wang_v1.py','--sample'],
               ['publication/render_v1.py']]
        with (ROOT/'publication/clean-replay-v1.log').open('w') as log:
            for task in tasks:
                print('Replay',' '.join(task),flush=True)
                subprocess.run([sys.executable,'-I','-S','-B',*task],cwd=target,stdout=log,stderr=subprocess.STDOUT,check=True)
        for name,digest in manifest.items():assert sha256((target/name).read_bytes()).hexdigest()==digest,name
        print('Clean extraction verified',len(manifest),'file hashes, exact searches, transport controls and the 695-record native sample')


if __name__=='__main__':main()
