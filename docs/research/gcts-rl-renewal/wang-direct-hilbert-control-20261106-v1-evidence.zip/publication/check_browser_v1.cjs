const assert=require('node:assert/strict');
const fs=require('node:fs');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.GCTS_PLAYWRIGHT);
async function main(){
 const browser=await chromium.launch({executablePath:process.env.GCTS_CHROME,headless:true,args:['--no-sandbox']});
 const data=JSON.parse(fs.readFileSync('data/direct-study-v1.json','utf8'));
 const get=(name,method)=>data.rows.find(r=>r.original.id===name).runs[method];
 try{
  for(const width of [390,1280]){
   const page=await browser.newPage({viewport:{width,height:900}}),errors=[];
   page.on('pageerror',e=>errors.push(e.message));
   if(process.env.GCTS_MATHJAX)await page.route('https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js',r=>r.fulfill({path:process.env.GCTS_MATHJAX,contentType:'application/javascript'}));
   await page.goto(pathToFileURL(process.cwd()+'/report/wang-direct-hilbert-control-20261106-v1.html').href,{waitUntil:'load',timeout:60000});
   await page.locator('#reader-host[data-ready=true]').waitFor({timeout:60000});
   const active=page.locator('#reader-host .case');
   assert.equal(await page.locator('#proof-select option').count(),15);
   assert.equal(await page.locator('#proof-method option').count(),5);
   assert.equal(await page.locator('#totals tbody tr').count(),6);
   assert.equal(await page.locator('#details tbody tr').count(),14);
   assert.equal(await page.locator('.case').count(),1);
   assert.equal(await page.locator('#line-select').inputValue(),String(get('mixed-line-and-order-1','direct-inventory').proof.length));
   await active.locator('.direct-trace summary').click();
   const target=await active.locator('.direct-trace button.jump').first().getAttribute('data-line');
   await active.locator('.direct-trace button.jump').first().click();
   assert.equal(await page.locator('#line-select').inputValue(),target);
   await active.locator('.line-slot mjx-container').first().waitFor();
   await active.getByText('Inspect this inference’s Wang squares').click();
   assert.equal(await active.locator('.native svg use').count(),9);
   assert.ok(await active.locator('.native svg use').first().evaluate(n=>n.getBBox().width>=36));
   await page.selectOption('#proof-method','definition');
   assert.equal(await page.locator('#line-select').isDisabled(),true);
   assert.match(await page.locator('#reader-host').textContent(),/no proof/);
   await page.selectOption('#proof-method','definition-inventory');
   await active.locator('.line-slot mjx-container').first().waitFor();
   assert.equal(await page.locator('#line-select').inputValue(),'210');
   assert.equal(await active.locator('.direct-trace').count(),0);
   await page.selectOption('#proof-select','order-chain-3-reverse-0');
   await page.selectOption('#proof-method','direct-inventory');
   await active.locator('.line-slot mjx-container').first().waitFor();
   assert.equal(await page.locator('#line-select').inputValue(),'632');
   assert.match(await active.locator('.line-slot .formula').first().textContent(),/⊥/);
   await page.selectOption('#proof-select','between-on-the-line');
   await active.locator('.line-slot mjx-container').first().waitFor();
   assert.equal(await page.locator('#line-select').inputValue(),'214');
   assert.equal(await page.locator('mjx-merror').count(),0);
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),width);
   assert.deepEqual(errors,[]);
   await page.locator('#comparison').scrollIntoViewIfNeeded();
   if(process.env.GCTS_SCREENSHOT)await page.screenshot({path:process.env.GCTS_SCREENSHOT.replace('{width}',width)});
   console.log('Verified',width,'px, compressed reader, five methods, direct-to-Wang links and checked squares.');
   await page.close();
  }
 }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1});
