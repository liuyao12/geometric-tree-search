"""Compare clause encodings and pack independently checked proof readers on demand."""
import base64
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ('publication','source','wang/source')]
from conditional_families_v1 import clause_put
from copy_ports_v1 import freeze
from copy_views_v1 import case
from direct_transport_v1 import Routes
from multi_families_v1 import erase_guards
from proof_views_v1 import clause,expression,math,tile_svg

NAME='wang-direct-hilbert-control-20261106-v1'
TITLE='Control for the clause encoding before crediting the inventory'
LABEL={'definition':'Definitions, original search','definition-inventory':'Definitions and mined inventory',
       'direct':'Direct clauses, original search','direct-propagation':'Direct clauses and propagation',
       'direct-requests':'Direct clauses, propagation and requests','direct-inventory':'Direct clauses and the same lemma interfaces'}
METHODS=('definition-inventory','direct-propagation','direct-inventory','direct','definition')


def read(name):
    p=ROOT/name
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())


def label(name):
    p=name.split('-')
    if name.startswith('incidence-chain-'):return f'Incidence chain, {p[2]} links, {p[4]} irrelevant facts'
    if name.startswith('order-chain-'):return f'Betweenness chain, {p[2]} links'+(', reversed endpoints' if p[4]=='1' else '')
    if name.startswith('mixed-line-and-order-'):return f'Mixed incidence/order, {p[-1]} links'
    return 'Development: betweenness on a chosen line'


def direct_clauses(row,adapter):
    values=[]
    for schema in row['direct']['clauses']:
        value=clause([(s,adapter.term(a)) for s,a in freeze(schema['clause'])])
        variables=schema['variables']
        if variables:value=r'\forall '+','.join(expression(v)+r'{:}\mathrm{'+s+'}' for v,s in sorted(variables.items()))+r'\;'+value
        values.append('<li class="formula">'+math(value)+'</li>')
    return '<details class="direct-clauses"><summary>Read the direct clauses used for search</summary><ol>'+''.join(values)+'</ol></details>'


def trace_view(result,adapter):
    if 'transport' not in result:return ''
    rows=[]
    for step in freeze(result['transport']):
        if step['host_line'] is None:continue
        rec=step['record']
        value=clause([(s,adapter.term(a)) for s,a in rec['clause']])
        at=step['host_line']+1
        rows.append('<li><div class="formula">'+math(value)+f'</div><button class="jump" data-line="{at}">Inspect its translated output at Wang proof line {at}</button></li>')
    return '<details class="direct-trace"><summary>Read the logical direct proof and follow its translation</summary><ol>'+''.join(rows)+'</ol></details>'


def attachments(row,result,bank,adapter):
    proof=freeze(result['proof'])
    family={f['id']:f for f in freeze(bank)}
    entries=[]
    for use in freeze(result['attachments']):
        if use['family'] not in family:continue
        f=family[use['family']]
        values=[]
        for port in f['ports']:
            grounded=clause_put(port,use['bindings'])
            decoded=tuple((s,adapter.term(a)) for s,a in grounded)
            at=next(i for i,p in enumerate(proof,1) if set(p['clause'])==set(decoded))
            values.append('<li><div class="formula">'+math(clause(decoded))+f'</div><button class="jump" data-line="{at}">Premise at line {at}</button></li>')
        decoded=tuple((s,adapter.term(a)) for s,a in use['clause'])
        at=next(i for i,p in enumerate(proof,1) if set(p['clause'])==set(decoded))
        entries.append(f'<article class="attachment"><h4>{escape(f["id"])}</h4><ul class="ports">'+''.join(values)+
                       '</ul><div class="out formula">'+math(clause(decoded))+f'</div><button class="jump" data-line="{at}">Read output at line {at}</button></article>')
    return '<details class="attachments"><summary>Inspect mined-family attachments</summary>'+''.join(entries)+'</details>' if entries else ''


def main():
    data=read('data/direct-study-v1.json')
    prior=read('input/prior-study-v1.json')
    native=read('data/direct-diagrams-v1.json.gz')
    held=[r for r in data['rows'] if r['split']=='held-out' and not r['countermodel']]
    summary=[]
    for arm in data['arms']:
        runs=[r['runs'][arm] for r in held]
        values=[sum(r['status']=='PROVED' for r in runs)]
        values.extend(sum(r['counts'].get(k,0) for r in runs) for k in ('resolutions','join_probes','instances','cluster_steps'))
        summary.append(f'<tr><th>{LABEL[arm]}</th>'+''.join(f'<td>{v:,}</td>' for v in values)+'</tr>')
    rows=[data['rows'][0],*held]
    types,payload,options,detail={},{},[],[]
    for row in rows:
        name=row['original']['id']
        adapter=Routes(row['original'],row['direct'],row['normal'],row['translation'])
        variants={}
        for arm in METHODS:
            result=row['runs'][arm]
            if result['status']!='PROVED':
                variants[arm]=dict(status=result['status'],stop=result['stop'],resolutions=result['counts']['resolutions'])
                continue
            checked=native['proofs'][native['calls'][name+'/'+arm]]
            assert freeze(result['proof'])==freeze(checked['proof'])
            html=case(dict(row,proof=checked['proof'],diagram=checked['diagram']),native['bank'],types)
            bank=data['direct_inventory'] if arm.startswith('direct') else prior['inventory']
            extra=attachments(row,result,bank,adapter)
            if arm.startswith('direct'):extra=direct_clauses(row,adapter)+trace_view(result,adapter)+extra
            html=html.replace('<div class="line-slot">',extra+'<div class="line-slot">')
            variants[arm]=dict(status='PROVED',html=html,lines=len(result['proof']),resolutions=result['counts']['resolutions'],
                               logical_lines=len(result['transport']) if 'transport' in result else len(erase_guards(row['original'],row['normal'],result['proof'])),steps=checked['receipt']['steps_without_reuse'])
        payload[name]=variants
        options.append(f'<option value="{name}"{" selected" if name=="mixed-line-and-order-1" else ""}>{label(name)}</option>')
        if row['split']!='held-out':continue
        values=[]
        for arm in ('definition-inventory','direct','direct-propagation','direct-inventory'):
            r=row['runs'][arm]
            values.append(f'<td>{r["counts"]["resolutions"]:,}</td>' if r['status']=='PROVED' else f'<td title="{r["stop"]}">Open</td>')
        for arm in ('definition-inventory','direct-inventory'):values.append(f'<td>{len(row["runs"][arm]["proof"] or [])}</td>')
        detail.append(f'<tr><th title="{name}">{label(name)}</th>'+''.join(values)+'</tr>')
    packed=base64.b64encode(gzip.compress(json.dumps(payload,separators=(',',':')).encode(),mtime=0)).decode()
    training=[]
    for t in data['training']:
        r=t['runs']['training']
        training.append(f'<tr><th>{escape(t["original"]["id"])}</th><td>{r["counts"]["resolutions"]:,}</td><td>{len(r["direct_proof"])}</td><td>{len(r["proof"])}</td></tr>')
    values=dict(title=TITLE,stem=NAME,summary=''.join(summary),details=''.join(detail),training=''.join(training),
        options=''.join(options),methods=''.join(f'<option value="{m}"{" selected" if m=="direct-inventory" else ""}>{LABEL[m]}</option>' for m in METHODS),
        packed=packed,runs=str(native['successful_runs']),distinct=str(native['distinct_proofs']),
        palette='<svg class="palette" width="0" height="0" aria-hidden="true"><defs>'+''.join(tile_svg(t,i) for t,i in types.items())+'</defs></svg>',
        script=(ROOT/'publication/reader_v1.js').read_text())
    head=(ROOT/'publication/group-notebook-head-v1.html').read_text().replace('Lifted equality search for Wang proofs',TITLE)
    head=head.replace('</style>',(ROOT/'publication/style-v1.css').read_text()+'\n</style>')
    body=(ROOT/'publication/direct-body-v1.html').read_text()
    for k,v in values.items():body=body.replace('%%'+k.upper()+'%%',v)
    assert '%%' not in body
    (ROOT/'report'/(NAME+'.html')).write_text(head+body)
    print('Packed',len(payload),'cases with five reader methods')


if __name__=='__main__':main()
