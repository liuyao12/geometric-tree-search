"""Compare productive instances and layer boundaries with the original size stream."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ('source','wang/source')]
from fair_search_v1 import stream
from legacy_stream_v1 import stream as original


def layers(generator,n):
    output=[]
    for _ in range(n):
        values=[]
        while (item:=next(generator)) is not None:values.append(item)
        output.append(values)
    return output


def main():
    if not __debug__:raise RuntimeError('Checking requires assertions')
    signatures=[(('U',),{'a':((),'U'),'b':((),'U'),'f':(('U','U'),'U')},
                 [{'id':'one','variables':{'?x':'U'}},{'id':'pair','variables':{'?x':'U','?y':'U'}}],7),
                (('Point','Line'),{'a':((),'Point'),'b':((),'Point'),'l':((),'Line'),'w':(('Point','Point','Point'),'Line')},
                 [{'id':'six','variables':{f'?v{i}':'Point' for i in range(6)}},
                  {'id':'typed','variables':{'?p':'Point','?l':'Line'}}],12),
                (('Point','Line'),{'a':((),'Point'),'l':((),'Line'),'f':(('Line',),'Point'),'g':(('Point',),'Line')},
                 [{'id':'typed','variables':{'?p':'Point','?l':'Line'}}],10)]
    counts=[]
    for sorts,functions,schemas,n in signatures:
        expected=layers(original(sorts,functions,schemas),n)
        actual=layers(stream(sorts,functions,schemas),n)
        assert actual==expected
        counts.append([len(x) for x in actual])
    sorts,functions,schemas,_=signatures[1]
    tail=layers(stream(sorts,functions,schemas),400)
    assert all(not row for row in tail[6:])
    body=json.dumps(dict(prefix_instance_counts=counts,finite_layers_checked=400),sort_keys=True)+'\n'
    path=ROOT/'data/stream-controls-v1.json'
    if '--build' in sys.argv:path.write_text(body)
    else:assert path.read_text()==body
    print('Verified exact old instance order on three signatures and 400 finite-universe layers')


if __name__=='__main__':main()
