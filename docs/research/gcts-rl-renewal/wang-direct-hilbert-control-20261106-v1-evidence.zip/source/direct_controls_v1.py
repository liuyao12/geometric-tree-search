"""Reject mismatched source clauses, witness dependencies and proof steps during transport."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ('source','wang/source','wang/external/source')]
from direct_transport_v1 import transport


def main():
    if not __debug__:raise RuntimeError('Checking requires assertions')
    data=json.loads((ROOT/'data/direct-study-v1.json').read_text())
    row=data['rows'][0]
    rejected=[]
    def reject(label,mutate):
        p,n,proof=(deepcopy(x) for x in (row['original'],row['direct'],row['runs']['direct-propagation']['direct_proof']))
        mutate(p,n,proof)
        try:transport(p,n,proof)
        except (AssertionError,KeyError,IndexError):rejected.append(label)
        else:raise AssertionError('Accepted '+label)
    def clause_sign(p,n,proof):n['clauses'][0]['clause'][0][0]=not n['clauses'][0]['clause'][0][0]
    def source(p,n,proof):next(r for r in proof if r['rule']=='G' and r['source'].startswith('formula2-')).update(source='formula1-clause1')
    def witness_type(p,n,proof):n['functions']['witness0'][1]='Point'
    def witness_arguments(p,n,proof):
        def visit(t):
            if not isinstance(t,list):return False
            if t and t[0]=='witness0':
                t[1],t[2]=t[2],t[1]
                return True
            return any(visit(c) for c in t[1:])
        assert any(visit(a) for schema in n['clauses'] for _,a in schema['clause'])
    def goal(p,n,proof):p['goal']=['atom','I',['a'],['ell']]
    def cycle(p,n,proof):next(r for r in proof if r['rule']=='R' and not r['pivot'][0].startswith('$type:')).update(left=99999)
    for label,change in (('changed direct clause sign',clause_sign),('wrong source clause',source),
                         ('wrong witness sort',witness_type),('reordered witness arguments',witness_arguments),
                         ('different source goal',goal),('invalid proof parent',cycle)):
        reject(label,change)
    assert len(data['models'])==4
    assert all(all(m['premise_truth']) and not m['conclusion_truth'] for m in data['models'].values())
    body=json.dumps(dict(rejected=rejected,countermodels=4),sort_keys=True)+'\n'
    path=ROOT/'data/direct-controls-v1.json'
    if '--build' in sys.argv:path.write_text(body)
    else:assert path.read_text()==body
    print('Rejected six damaged transports; four finite countermodels retained')


if __name__=='__main__':main()
