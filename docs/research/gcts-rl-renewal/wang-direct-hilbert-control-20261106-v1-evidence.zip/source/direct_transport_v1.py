"""Expand typed direct-CNF proofs into the independently checked definition boundary."""
from itertools import product

from copy_ports_v1 import freeze
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_closure_v1 import trim
from fair_search_v1 import ordered
from herbrand_v1 import signature
from multi_families_v1 import erase_guards
from study_v1 import Certificate, guarded


def key(path):
    return "_".join(map(str,path))


def free(node):
    def term(t):
        return {t} if isinstance(t,str) else set().union(*(term(x) for x in t[1:]))
    op,*args=node
    if op=="atom":return set().union(*(term(t) for t in args[1:]))
    if op in ("all","exists"):return free(args[2])-{args[0]}
    return set().union(*(free(a) for a in args))


class Routes:
    """Independently recover each CNF branch and its exact source unfolding."""
    def __init__(self, original, direct, normal, translation):
        self.original,self.direct,self.normal=original,direct,normal
        self.definitions={tuple(d["path"]):d for d in translation["definitions"]}
        self.info,self.functions,self.host_variables={}, {}, {}
        self.v,self.w=0,0
        self.plans={}
        for i,formula in enumerate([*original["premises"],original["goal"]]):
            parsed=self.parse(freeze(formula),(i,),i<len(original["premises"]),{},())
            rows=self.cnf(parsed)
            for j,(clause,choices) in enumerate(rows,1):
                name=f'formula{i+1}-clause{j}'
                self.plans[name]=dict(formula=formula,sign=i<len(original["premises"]),path=(i,),clause=clause,choices=choices)
        _,_,schemas=signature(direct)
        supplied={s["id"]:s for s in schemas if s["id"].startswith("formula")}
        assert set(supplied)==set(self.plans)
        for name,p in self.plans.items():assert ordered(supplied[name]["clause"])==p["clause"],name

    def parse(self,node,path,sign,scope,universals):
        op,*args=node
        if op=="atom":
            def term(t):
                return scope[t][0] if isinstance(t,str) else (t[0],*(term(a) for a in t[1:]))
            return "literal",sign,(args[0],*(term(t) for t in args[1:]))
        if op=="not":return self.parse(args[0],(*path,0),not sign,scope,universals)
        if op in ("all","exists"):
            name,sort,body=args
            host="?v"+key(path)
            # This checked fast path requires the nonvacuous quantifiers used by the suite.
            assert name in free(body), "Vacuous quantifier is outside this transport fragment"
            params=tuple(sorted(scope[n][1] for n in free(node)))
            self.info[path]=dict(kind=op,sign=sign,host=host,params=params,sort=sort)
            if (op=="all")==sign:
                direct=f'?v{self.v}';self.v+=1
                self.host_variables[direct]=(host,sort)
                value=direct
                universals=(*universals,(direct,sort,host))
            else:
                while f'witness{self.w}' in self.original["functions"]:self.w+=1
                direct=f'witness{self.w}';self.w+=1
                d=self.definitions[path]
                assert d["witness"] is not None
                all_hosts=tuple(h for _,_,h in universals)
                assert set(params)==set(all_hosts), "Nonbijective Skolem dependencies are outside this transport fragment"
                perm=tuple(all_hosts.index(h) for h in params)
                self.functions[direct]=(d["witness"],perm)
                assert direct in self.direct["functions"]
                assert tuple(self.normal["functions"][d["witness"]][0])==tuple(self.direct["functions"][direct][0][i] for i in perm)
                value=(direct,*(v for v,_,_ in universals))
            return self.parse(body,(*path,0),sign,{**scope,name:(value,host)},universals)
        assert op in ("and","or","implies"), "Unsupported connective in direct transport"
        params=tuple(sorted(scope[n][1] for n in free(node)))
        self.info[path]=dict(kind=op,sign=sign,params=params)
        conjunction=(op=="and" and sign) or (op in ("or","implies") and not sign)
        left_sign=not sign if op=="implies" else sign
        a=self.parse(args[0],(*path,0),left_sign,scope,universals)
        b=self.parse(args[1],(*path,1),sign,scope,universals)
        return "and" if conjunction else "or",path,a,b

    def cnf(self,node):
        if node[0]=="literal":return [(ordered(((node[1],node[2]),)),{})]
        op,path,a,b=node
        left,right=self.cnf(a),self.cnf(b)
        if op=="and":
            rows=[(c,{**choices,path:0}) for c,choices in left]+[(c,{**choices,path:1}) for c,choices in right]
        else:
            rows=[(ordered((*c,*d)),{**x,**y}) for (c,x),(d,y) in product(left,right)]
        seen,out=set(),[]
        for c,choices in rows:
            if c in seen or any((not s,a) in c for s,a in c):continue
            seen.add(c);out.append((c,choices))
        return out

    def term(self,t):
        if isinstance(t,str):return t
        name,*args=t
        children=tuple(self.term(a) for a in args)
        if name in self.functions:
            target,perm=self.functions[name]
            return target,*(children[i] for i in perm)
        assert name in self.normal["functions"] or name in self.normal["predicates"] or name.startswith('=')
        return name,*children


def transport(original,direct,proof,include_trace=False):
    normal,translation=compile_case(original)
    check(original,normal,translation)
    routes=Routes(original,direct,normal,translation)
    raw=erase_guards(original,direct,proof)
    functions,predicates,schemas=signature(normal)
    sources,guards=guarded(schemas,functions,normal["sorts"])
    builder=Certificate(sources,functions,predicates,normal["sorts"],guards)
    mapping=[]
    defaults={s:next((n,) for n,(args,out) in sorted(functions.items()) if not args and out==s) for s in normal["sorts"]}

    def source_instance(record):
        name=record["source"]
        if name not in routes.plans:
            bindings={v:routes.term(t) for v,t in record["bindings"].items()}
            if name.startswith('congruence-') and name[len('congruence-'):] in routes.functions:
                target,perm=routes.functions[name[len('congruence-'):]]
                name='congruence-'+target
                bindings={f'?{side}{j}':routes.term(record["bindings"][f'?{side}{i}']) for side in ('l','r') for j,i in enumerate(perm)}
            return builder.unguard(name,bindings)
        plan=routes.plans[name]
        env={h:routes.term(record["bindings"][v]) if v in record["bindings"] else defaults[s]
             for v,(h,s) in routes.host_variables.items()}
        family=f'formula{plan["path"][0]+1}-'

        def unfold(line,node,path,sign,values):
            op,*args=node
            if op=='atom':return line
            if op=='not':return unfold(line,args[0],(*path,0),not sign,values)
            info=routes.info[path]
            top=(routes.definitions[path]["name"],*(values[v] for v in info["params"]))
            assert (sign,top) in builder.lines[line]["clause"]
            if op in ('all','exists'):
                universal=(op=='all')==sign
                host=info["host"]
                if universal:
                    value=values[host]
                else:
                    value=(routes.definitions[path]["witness"],*(values[v] for v in info["params"]))
                values={**values,host:value}
                rule=1 if universal else 2
                children=[(args[2],(*path,0),sign)]
            else:
                conjunction=(op=='and' and sign) or (op in ('or','implies') and not sign)
                child_signs=(not sign if op=='implies' else sign,sign)
                if conjunction:
                    chosen=plan["choices"][path]
                    rule=chosen+1
                    children=[(args[chosen],(*path,chosen),child_signs[chosen])]
                else:
                    rule=3
                    children=[(args[j],(*path,j),child_signs[j]) for j in (0,1)]
            schema=family+'node-'+key(path)+'-'+str(rule)
            instance=builder.unguard(schema,{v:values[v] for v in sources[schema]["variables"]})
            current=builder.resolve(line,instance,top) if sign else builder.resolve(instance,line,top)
            for child,site,polarity in children:current=unfold(current,child,site,polarity,values)
            return current

        line=builder.unguard(family+'root',{})
        return unfold(line,freeze(plan["formula"]),plan["path"],plan["sign"],env)

    for record in raw:
        expected=ordered((s,routes.term(a)) for s,a in record["clause"])
        if record["rule"]=='G':
            i=source_instance(record)
        else:
            i=builder.resolve(mapping[record["left"]],mapping[record["right"]],routes.term(record["pivot"]))
        assert set(builder.lines[i]["clause"])==set(expected), record
        mapping.append(i)
    assert not builder.lines[mapping[-1]]["clause"]
    output=trim(builder.lines,mapping[-1])
    if include_trace:
        needed=set()
        todo=[mapping[-1]]
        while todo:
            i=todo.pop()
            if i not in needed:
                needed.add(i)
                row=builder.lines[i]
                if row["rule"]=='R':todo.extend((row["left"],row["right"]))
        remap={old:i for i,old in enumerate(sorted(needed))}
        trace=[dict(record=record,host_line=remap.get(j)) for record,j in zip(raw,mapping,strict=True)]
        return normal,translation,output,trace
    return normal,translation,output
