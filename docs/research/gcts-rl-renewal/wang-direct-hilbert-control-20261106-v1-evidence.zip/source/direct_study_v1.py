"""Compare exact source statements under two encodings and transport every direct proof."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ('source','wang/source','wang/external/source')]
from definition_check_v1 import check
from copy_ports_v1 import freeze
from definitions_v1 import compile_case
from direct_clauses_v1 import clausify
from direct_transport_v1 import transport
from equality_cases_v1 import holds
from hilbert_join_cases_v1 import cases
from induction_cases_v1 import hilbert
from multi_families_v1 import mine, propagation_families
from multi_search_v1 import MultiSearch
from fair_study_v1 import cases as donor_cases

ARMS=('definition','definition-inventory','direct','direct-propagation','direct-requests','direct-inventory')


def train_direct(prior,limits):
    incidence=next(p for p,m in donor_cases() if p['id']==prior['donor']['id'])
    normal,_=compile_case(incidence)
    assert freeze(normal)==freeze(prior['donor']['normal'])
    bank,training=[],[]
    for source,reference in zip((incidence,hilbert()),prior['inventory'],strict=True):
        direct,skolem=clausify(source,1024)
        engine=MultiSearch(direct,source['goal'],limits,propagation_families(direct))
        result=engine.run()
        assert result['status']=='PROVED'
        family=mine(source,direct,result['proof'],reference['id'])
        assert family['variables']==reference['variables']
        assert freeze(family['out'])==freeze(reference['out'])
        assert {freeze(p) for p in family['ports']}=={freeze(p) for p in reference['ports']}
        normal,translation,expanded,trace=transport(source,direct,result['proof'],True)
        result.update(direct_proof=result['proof'],proof=expanded,transport=trace)
        training.append(dict(original=source,normal=normal,translation=translation,direct=direct,skolem=skolem,runs={'training':result}))
        bank.append(family)
    return bank,training


def study():
    prior=json.loads((ROOT/'input/prior-study-v1.json').read_text())
    limits=prior['limits']
    learned,training=train_direct(prior,limits)
    sources=[(hilbert(),None),*cases()]
    rows=[]
    for (source,model),earlier in zip(sources,prior['rows'],strict=True):
        assert source==earlier['original']
        if model:
            p,g=holds(source,model)
            assert all(p) and not g
        normal,translation=compile_case(source)
        check(source,normal,translation)
        assert freeze(normal)==freeze(earlier['normal']) and freeze(translation)==freeze(earlier['translation'])
        direct,skolem=clausify(source,1024)
        runs={}
        for arm in ARMS:
            use_direct=arm.startswith('direct')
            n=direct if use_direct else normal
            family_bank=[]
            if arm=='definition-inventory':
                family_bank=prior['inventory'][:1] if earlier['split']=='development' else prior['inventory']
            if arm=='direct-inventory':
                family_bank=learned[:1] if earlier['split']=='development' else learned
            use_basis=arm in ('definition-inventory','direct-propagation','direct-requests','direct-inventory')
            basis=propagation_families(n) if use_basis else []
            demand=arm in ('definition-inventory','direct-requests')
            engine=MultiSearch(n,source['goal'],limits,[*family_bank,*basis],demand=demand)
            result=engine.run()
            assert all(result['counts'].get(k,0)<=v for k,v in limits.items())
            assert not model or result['status']=='BOUNDED'
            if arm in ('definition','definition-inventory'):
                expected=earlier['runs']['baseline' if arm=='definition' else 'incidence' if earlier['split']=='development' else 'inventory']
                assert json.dumps(result,sort_keys=True,separators=(',',':'))==json.dumps(expected,sort_keys=True,separators=(',',':')),(source['id'],arm)
            if use_direct and result['proof']:
                original_proof=result['proof']
                checked_normal,checked_translation,expanded,trace=transport(source,direct,original_proof,True)
                assert checked_normal==normal and checked_translation==translation
                result.update(proof=expanded,direct_proof=original_proof,transport=trace)
            runs[arm]=result
        rows.append(dict(original=source,normal=normal,translation=translation,direct=direct,skolem=skolem,
                         countermodel=bool(model),split=earlier['split'],runs=runs))
        print(source['id'],{a:(r['status'],r['counts']['resolutions'],len(r['proof'] or [])) for a,r in runs.items()},flush=True)
    return dict(limits=limits,arms=ARMS,rows=rows,models=prior['models'],inventory_sha256=prior['inventory_sha256'],
                direct_inventory=learned,training=training)


def main():
    if not __debug__:raise RuntimeError('Replay requires assertions')
    out=study()
    body=json.dumps(out,sort_keys=True,separators=(',',':'))+'\n'
    path=ROOT/'data/direct-study-v1.json'
    if '--build' in sys.argv:path.write_text(body)
    else:assert path.read_text()==body
    print('Verified exact statements, reproduced prior controls, and transported every returned direct proof',flush=True)


if __name__=='__main__':main()
