"""Check the transport's Boolean and quantifier polarities with small native proofs."""
import gzip
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ('source','wang/source')]
from boundary_kernel_v1 import build
from connected_wire_v1 import audit,compact
from copy_check_v1 import TileBank,verify
from copy_ports_v1 import attach_marks,compile_diagram,encoded
from direct_clauses_v1 import clausify
from direct_transport_v1 import transport
from herbrand_v1 import signature
from multi_search_v1 import MultiSearch
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded


def cases():
    def a(p,t=('a',)):return ['atom',p,list(t) if not isinstance(t,str) else t]
    p,q,r=(a(n) for n in 'PQR')
    yield 'or-elimination',[['or',p,q],['implies',p,r],['implies',q,r]],r
    yield 'negative-or',[['not',['or',p,q]]],['not',p]
    yield 'negative-implication',[['not',['implies',p,q]]],p
    yield 'negative-and',[['not',['and',p,q]],p],['not',q]
    for op in ('all','exists'):
        statement=[op,'?x','U',a('P','?x')]
        yield op+'-both-polarities',[statement],statement


def run():
    limits=json.loads((ROOT/'data/direct-study-v1.json').read_text())['limits']
    machine=build().compile()
    assert machine.digest()==PUBLISHED_MACHINE
    bank=TileBank(machine)
    rows=[]
    for name,premises,goal in cases():
        original=dict(id=name,sorts=['U'],functions={'a':[[],'U']},predicates={p:['U'] for p in 'PQR'},
                      equality=False,premises=premises,goal=goal)
        direct,_=clausify(original,1024)
        result=MultiSearch(direct,goal,limits,[]).run()
        assert result['status']=='PROVED'
        normal,translation,proof=transport(original,direct,result['proof'])
        functions,_,schemas=signature(normal)
        sources,_=guarded(schemas,functions,normal['sorts'])
        wire=compact(sources,proof)
        assert audit(wire,sources,proof)==len(proof)
        diagram=compile_diagram(wire)
        local=[bank.get(s)[0] for s in diagram['strips']]
        attach_marks(diagram,local,len(machine.marks)+1)
        receipt=verify(diagram,sources,bank)
        rows.append(dict(original=original,normal=normal,translation=translation,proof=proof,diagram=diagram,receipt=receipt))
        print('Verified language test',name,len(proof),'records',flush=True)
    return dict(rows=rows,bank=bank.receipts,palette=PUBLISHED_MACHINE)


def main():
    if not __debug__:raise RuntimeError('Checking requires assertions')
    data=encoded(run())
    path=ROOT/'data/syntax-controls-v1.json.gz'
    if '--build' in sys.argv:path.write_bytes(gzip.compress(data,mtime=0))
    else:assert gzip.decompress(path.read_bytes())==data


if __name__=='__main__':main()
