"""Expand every distinct returned proof and replay its marked Wang diagram."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source")]
from boundary_kernel_v1 import build
from connected_wire_v1 import audit, compact
from copy_check_v1 import TileBank, verify
from copy_ports_v1 import attach_marks, compile_diagram, encoded, fingerprint, freeze
from definition_check_v1 import check
from herbrand_v1 import signature
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded


def replay(selected=None):
    data = json.loads((ROOT / "data/direct-study-v1.json").read_text())
    machine = build().compile()
    assert machine.digest() == PUBLISHED_MACHINE
    bank = TileBank(machine)
    proofs, calls = {}, {}
    for row in [*data["training"], *data["rows"]]:
        if selected and row["original"]["id"] != selected.split('/')[0]:
            continue
        normal = row["normal"]
        check(row["original"], normal, row["translation"])
        functions, _, schemata = signature(normal)
        sources, _ = guarded(schemata, functions, normal["sorts"])
        for arm, result in row["runs"].items():
            if selected and row["original"]["id"] + '/' + arm != selected:
                continue
            if result["status"] != "PROVED":
                continue
            key = sha256(encoded((row["original"], result["proof"]))).hexdigest()
            calls[row["original"]["id"] + "/" + arm] = key
            if key in proofs:
                continue
            proof = freeze(result["proof"])
            wire = compact(sources, proof)
            assert audit(wire, sources, proof) == len(proof)
            diagram = compile_diagram(wire)
            local = [bank.get(s)[0] for s in diagram["strips"]]
            attach_marks(diagram, local, len(machine.marks) + 1)
            receipt = verify(diagram, sources, bank)
            proofs[key] = dict(source=row["original"]["id"], diagram=diagram, proof=proof, receipt=receipt)
            print("Replayed", len(proofs), row["original"]["id"], arm, len(proof), flush=True)
    return dict(palette=PUBLISHED_MACHINE, proofs=proofs, calls=calls, bank=bank.receipts,
                successful_runs=len(calls), distinct_proofs=len(proofs))


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    selected = 'order-chain-3-reverse-0/direct-propagation' if '--sample' in sys.argv else None
    data = replay(selected)
    raw = encoded(data)
    file = ROOT / "data/direct-diagrams-v1.json.gz"
    if selected:
        expected = json.loads(gzip.decompress(file.read_bytes()))
        assert data['successful_runs'] == data['distinct_proofs'] == 1
        key = data['calls'][selected]
        assert key == expected['calls'][selected]
        assert freeze(data['proofs'][key]) == freeze(expected['proofs'][key])
        assert all(freeze(value) == freeze(expected['bank'][name]) for name,value in data['bank'].items())
    elif "--build" in sys.argv:
        file.write_bytes(gzip.compress(raw, mtime=0))
    else:
        assert gzip.decompress(file.read_bytes()) == raw
    print("Verified", data["successful_runs"], "runs with", data["distinct_proofs"], "distinct expanded proofs")


if __name__ == "__main__":
    main()
