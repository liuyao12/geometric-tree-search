"""Measure clause counts and finite typed ground-term universes in the exact controls."""
import json
from math import prod
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]


def analyze(case):
    functions=case['functions']
    counts={}
    pending=set(case['sorts'])
    while pending:
        ready=sorted(s for s in pending if all(all(t in counts for t in args)
                      for args,out in functions.values() if out==s))
        if not ready:break
        for s in ready:
            counts[s]=sum(prod(counts[t] for t in args) for args,out in functions.values() if out==s)
            pending.remove(s)
    recursive=[name for name,(args,out) in functions.items() if args==[out] and
               any(not ins and result==out for ins,result in functions.values())]
    return dict(formula_clauses=len(case['clauses']),nonconstant_functions=sum(bool(a) for a,s in functions.values()),
                finite_ground_terms=counts if not pending else None,unary_nesting_function=min(recursive) if recursive else None)


def main():
    data=json.loads((ROOT/'data/direct-study-v1.json').read_text())
    rows=[]
    for row in data['rows']:
        a,b=(analyze(row[k]) for k in ('normal','direct'))
        assert b['finite_ground_terms'] is not None
        assert a['unary_nesting_function'] is not None
        rows.append(dict(id=row['original']['id'],definition=a,direct=b))
    assert rows[0]['definition']['formula_clauses']==49 and rows[0]['direct']['formula_clauses']==9
    assert rows[0]['direct']['finite_ground_terms']=={'Point':3,'Line':28}
    body=json.dumps(dict(rows=rows),sort_keys=True,separators=(',',':'))+'\n'
    path=ROOT/'data/encoding-structure-v1.json'
    if '--build' in sys.argv:path.write_text(body)
    else:assert path.read_text()==body
    print('Verified finite direct term signatures and recursive definition term signatures on all 19 inputs')


if __name__=='__main__':main()
