"""Persistent, fair ground resolution with a checked term-demand lane."""
from collections import Counter, defaultdict, deque
from itertools import count, islice, product
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ("source","wang/source")]
from herbrand_v1 import inspect_term, signature
from study_v1 import Certificate, grounded, guarded


GUIDED_TERM_DEPTH=24


def compositions(total,length):
    if not length:
        if total==0:
            yield ()
        return
    for first in range(1,total-length+2):
        for rest in compositions(total-first,length-1):
            yield (first,*rest)


def stream(sorts,functions,schemata):
    """Yield each nonground schema substitution once by total argument size."""
    by_size={s:defaultdict(tuple) for s in sorts}
    for weight in count(1):
        layer=defaultdict(list)
        for name,(inputs,output) in sorted(functions.items()):
            for sizes in supported_sizes(weight-1,inputs,by_size):
                for children in product(*(by_size[s][n] for s,n in zip(inputs,sizes,strict=True))):
                    layer[output].append((name,*children))
        for s in sorts:
            by_size[s][weight]=tuple(layer[s])
        for row in schemata:
            variables=tuple(sorted(row["variables"]))
            if not variables:
                continue
            for sizes in supported_sizes(weight,tuple(row["variables"][v] for v in variables),by_size):
                parts=(by_size[row["variables"][v]][n] for v,n in zip(variables,sizes,strict=True))
                for values in product(*parts):
                    yield row["id"],dict(zip(variables,values,strict=True))
        # A finite signature without growing terms can have empty layers forever.
        yield None


def supported_sizes(total,sorts,known):
    """Preserve composition order while skipping sizes whose term layers are empty."""
    if not sorts:
        if total==0:
            yield ()
        return
    for first in sorted(n for n,values in known[sorts[0]].items() if values and n<=total):
        for rest in supported_sizes(total-first,sorts[1:],known):
            yield (first,*rest)


def ordered(literals):
    return tuple(sorted(set(literals),key=repr))


def terms(t):
    yield t
    for child in t[1:]:
        yield from terms(child)


def guidance_terms(atom):
    values=tuple(atom[1:])
    pending=[(value,0) for value in values]
    while pending:
        term,depth=pending.pop()
        if depth>GUIDED_TERM_DEPTH:
            return None
        pending.extend((child,depth+1) for child in term[1:])
    return values


def bind(pattern,term,env):
    if isinstance(pattern,str):
        return env.setdefault(pattern,term)==term
    return (pattern[0]==term[0] and len(pattern)==len(term) and
            all(bind(a,b,env) for a,b in zip(pattern[1:],term[1:],strict=True)))


class Search:
    def __init__(self,normal,guided):
        self.normal=normal
        self.functions,self.predicates,schemas=signature(normal)
        self.schemas={s["id"]:s for s in schemas}
        self.guide=guided
        self.stream=stream(normal["sorts"],self.functions,schemas)
        self.rows=[]
        self.index={}
        self.agenda=deque()
        self.seen_instances=set()
        self.processed=defaultdict(list)
        self.admitted=defaultdict(list)
        self.unit_ids={}
        self.pending_units=deque()
        self.pending_terms=deque()
        self.seen_terms=set()
        self.seen_by_sort=defaultdict(list)
        self.one_var=defaultdict(list)
        self.triggers=defaultdict(list)
        self.work=Counter()
        for s in schemas:
            if s["variables"]:
                for sign,atom in s["clause"]:
                    self.triggers[not sign,atom[0]].append((s,atom))
            if len(s["variables"])==1:
                (v,sort),=s["variables"].items()
                self.one_var[sort].append((s["id"],v))
            if not s["variables"]:
                self.instance(s["id"],{},"seed")

    def add(self,clause,reason):
        if any((not s,a) in clause for s,a in clause):
            return None
        if clause in self.index:
            return self.index[clause]
        i=len(self.rows)
        self.rows.append((clause,reason))
        self.index[clause]=i
        self.agenda.append(i)
        for literal in clause:
            self.admitted[literal].append(i)
        if self.guide and len(clause)==1:
            (literal,)=clause
            self.unit_ids[literal]=i
            values=guidance_terms(literal[1])
            if values is None:
                self.work["guide_depth_skips"]+=1
                return i
            self.pending_units.append(i)
            for value in values:
                for term in terms(value):
                    if term not in self.seen_terms:
                        self.seen_terms.add(term)
                        self.seen_by_sort[inspect_term(term,{},self.functions)].append(term)
                        self.pending_terms.append(term)
        return i

    def instance(self,name,env,lane):
        token=name,tuple(sorted(env.items()))
        if token in self.seen_instances:
            return None
        self.seen_instances.add(token)
        self.work[lane+"_instances"]+=1
        return self.add(ordered(grounded(self.schemas[name],env)),("G",name,env))

    def resolve(self,i,j,atom):
        a,b=(set(self.rows[k][0]) for k in (i,j))
        if (True,atom) not in a:
            i,j=j,i
            a,b=b,a
        assert (True,atom) in a and (False,atom) in b
        self.work["resolutions"]+=1
        return self.add(ordered((a-{(True,atom)})|(b-{(False,atom)})),("R",i,j,atom))

    def fifo(self):
        if not self.agenda:
            return
        i=self.agenda.popleft()
        self.work["fifo_clauses"]+=1
        clause=self.rows[i][0]
        for sign,atom in clause:
            for j in self.processed[not sign,atom]:
                self.resolve(i,j,atom)
                if () in self.index:
                    return
        for literal in clause:
            self.processed[literal].append(i)

    def with_units(self,i):
        if i is None:
            return
        for sign,atom in self.rows[i][0]:
            j=self.unit_ids.get((not sign,atom))
            if j is not None:
                self.resolve(i,j,atom)

    def focused(self):
        if self.pending_terms:
            t=self.pending_terms.popleft()
            s=inspect_term(t,{},self.functions)
            self.work["demand_terms"]+=1
            for name,v in self.one_var[s]:
                self.with_units(self.instance(name,{v:t},"demand"))
                if () in self.index:
                    return
        for _ in range(3):
            if not self.pending_units:
                break
            self.focus_unit(self.next_unit())
            if () in self.index:
                return

    def next_unit(self):
        return self.pending_units.popleft()

    def unit_matches(self,i):
        ((sign,atom),)=self.rows[i][0]
        for schema,pattern in self.triggers[sign,atom[0]]:
            env={}
            if bind(pattern,atom,env):
                missing=tuple(v for v in schema["variables"] if v not in env)
                yield schema,env,missing

    def focus_unit(self,i):
        ((sign,atom),)=self.rows[i][0]
        for schema,env,missing in self.unit_matches(i):
            choices=[]
            for v in missing:
                candidates=self.seen_by_sort[schema["variables"][v]]
                choices.append(tuple(dict.fromkeys(candidates[:3]+candidates[-3:])))
            for values in islice(product(*choices),16):
                actual={**env,**dict(zip(missing,values,strict=True))}
                self.with_units(self.instance(schema["id"],actual,"trigger"))
                if () in self.index:
                    return
        for j in tuple(self.admitted[not sign,atom]):
            self.resolve(i,j,atom)
            if () in self.index:
                return

    def search(self,limit=None):
        while () not in self.index:
            if limit is not None and self.work["rounds"]>=limit:
                return dict(status="BOUNDED",counts=dict(self.work),proof=None)
            self.work["rounds"]+=1
            item=next(self.stream)
            if item is not None:
                self.instance(*item,"fair")
            else:
                self.work["completed_layers"]+=1
            self.fifo()
            if self.guide and () not in self.index:
                self.focused()
        return dict(status="PROVED",counts=dict(self.work),proof=self.elaborate())

    def elaborate(self):
        # Build guards and ground records only for ancestors of the contradiction.
        raw,type_ids=guarded(list(self.schemas.values()),self.functions,self.normal["sorts"])
        cert=Certificate(raw,self.functions,self.predicates,self.normal["sorts"],type_ids)
        needed=set()
        pending=[self.index[()]]
        while pending:
            i=pending.pop()
            if i not in needed:
                needed.add(i)
                rec=self.rows[i][1]
                if rec[0]=="R":
                    pending.extend(rec[1:3])
        mapping={}
        for i in sorted(needed):
            clause,(op,*record)=self.rows[i]
            if op=="G":
                mapping[i]=cert.unguard(*record)
            else:
                a,b,pivot=record
                mapping[i]=cert.resolve(mapping[a],mapping[b],pivot)
            assert set(cert.lines[mapping[i]]["clause"])==set(clause)
        assert not cert.lines[-1]["clause"]
        return cert.lines
