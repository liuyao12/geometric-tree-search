Direct-clause control for the exact symbolic Hilbert suite

Use Python 3.12 with assertions enabled, from the archive root:

  python3 -I -S -B source/stream_controls_v1.py
  python3 -I -S -B source/direct_study_v1.py
  python3 -I -S -B source/encoding_structure_v1.py
  python3 -I -S -B source/direct_controls_v1.py
  python3 -I -S -B source/syntax_controls_v1.py
  python3 -I -S -B source/direct_wang_v1.py
  python3 -I -S -B publication/render_v1.py

These commands check enumeration order, repeat all exact-source searches,
reproduce the earlier controls, transport every direct proof, reject damaged
transports, replay every distinct marked Wang proof, and regenerate the reader.
The native command supports --sample to check only the 695-record transported
three-link order proof against its archived receipt. Full native verification
was performed on every successful result; clean-extraction validation repeats
all searches and the largest transported sample. The proof reader stores its
views in an inline gzip payload and opens one proof at a time.
The manifest gives SHA-256 hashes for every included file.
