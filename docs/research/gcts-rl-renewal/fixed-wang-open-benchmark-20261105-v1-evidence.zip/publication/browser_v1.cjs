const assert=require("node:assert/strict");
const fs=require("node:fs");
const path=require("node:path");
const {pathToFileURL}=require("node:url");
const {chromium}=require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main(){
  const browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless:true,args:["--disable-breakpad","--disable-background-networking"]});
  try{
    const page=await browser.newPage({viewport:{width:1250,height:900}});
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const live=Boolean(process.argv[2]);
    const local=pathToFileURL(path.join(__dirname,"..","report","fixed-wang-open-benchmark-20261105-v1.html"));
    const response=await page.goto(process.argv[2]||local.href,{waitUntil:"load"});
    if(live) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===69);
    const stats=await page.evaluate(()=>{
      const menu=document.querySelector("#case-menu");
      const panels=[...document.querySelectorAll(".proof[id^=case-]")];
      let lines=0;
      for(const choice of menu.options){
        menu.value=choice.value;
        menu.dispatchEvent(new Event("change"));
        const shown=panels.filter(p=>!p.hidden);
        if(shown.length!==1||shown[0].id!=="case-"+choice.value) throw Error("Wrong statement");
        for(const detail of shown[0].querySelectorAll("tbody details")){
          detail.querySelector("summary").click();
          if(!detail.open||detail.querySelectorAll("svg.tile").length!==7) throw Error("Missing checked squares");
          detail.querySelector("summary").click();
        }
        lines+=shown[0].querySelectorAll("tbody>tr").length;
      }
      menu.value="peano-nonzero-successor";menu.dispatchEvent(new Event("change"));
      document.querySelector("#case-peano-nonzero-successor tbody summary").click();
      return {cases:panels.length,lines,math:document.querySelectorAll("mjx-container").length,
        math_errors:document.querySelectorAll("mjx-merror").length};
    });
    assert.deepEqual(errors,[]);
    assert.deepEqual(stats,{cases:3,lines:31,math:69,math_errors:0});
    if(!live) await page.locator("#case-peano-nonzero-successor").screenshot({path:path.join(__dirname,"browser-v1.png")});
    await page.setViewportSize({width:390,height:844});
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));
    const result={status:"CHECKED_OPEN_WANG_BENCHMARK_READER",...stats,mobile_no_overflow:true};
    fs.writeFileSync(path.join(__dirname,live?"live-browser-v1.json":"browser-v1.json"),
      JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
