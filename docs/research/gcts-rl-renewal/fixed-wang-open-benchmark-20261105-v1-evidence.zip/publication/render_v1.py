"""Render the open Wang benchmark, marked columns, and verified proofs."""

import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"publication"))
from proof_presentation import STYLE, TITLES, atom, clause, formula, math, strip, term, wang
from resolution_v1 import load, pin

STEM="fixed-wang-open-benchmark-20261105-v1"
OLD="fixed-wang-quantified-origins-20261105-v1.html"
METHODS={
    "static":"Boundary cuts, fixed order",
    "activity":"Boundary cuts, conflict activity",
    "learned":"Boundary cuts, frozen RL",
    "cadical195":"CaDiCaL",
    "glucose4":"Glucose",
    "cadical195-seeded":"CaDiCaL with imported cuts",
}
PROOF_MODES={**METHODS,"block-marked":"marked clause-block search","cadical195-serial":"CaDiCaL in the serial window"}


def short(name):
    return TITLES.get(name,{
        "quantifier-swap-control":"Quantifier order control",
        "forged-source-clause":"Forged-source control",
        "tptp-tutorial-capital":"TPTP tutorial · Capital",
        "tptp-tutorial-family":"TPTP tutorial · Family",
        "tptp-tutorial-family-mutation":"TPTP tutorial · Mutated family",
    }.get(name,name))


def read_rectangle(name,mode):
    sub="fast" if mode in ("activity","learned","cadical195") else ""
    key="cadical195-serial" if mode=="cadical195-serial" else mode
    with gzip.open(ROOT/"data"/sub/f"{name}-{key}-wang-v1.json.gz","rt") as f:
        r=json.load(f)
    return r["circuit"],r["certificate"]


def table(head,rows):
    h="".join(f'<th scope="col">{escape(n)}</th>' for n in head)
    body="".join("<tr>"+"".join(f"<td>{escape(str(v))}</td>" for v in r)+"</tr>" for r in rows)
    return f'<div class="scroll"><table><thead><tr>{h}</tr></thead><tbody>{body}</tbody></table></div>'


def proof_panel(result,original,mode):
    name=result["id"]
    found=next(r for r in result["results"] if r["mode"]==mode)
    proof=found["proof"]
    c,cert=read_rectangle(name,mode)
    palette=wang.palette()
    lines=[]
    for i,(premise,src) in enumerate(zip(proof["premises"],proof["origins"],strict=True)):
        substitutions=", ".join(math(term(v)+r"\mapsto "+term(q)) for v,q in sorted(src["substitution"].items()))
        explain=f'Source <code>{escape(src["schema"])}</code>'
        if substitutions:
            explain+=" with "+substitutions
        lines.append((premise,explain+".",f"premise{i}:positive"))
    for j,r in enumerate(proof["proof"]):
        text=f'Resolve lines {r["left"]+1} and {r["right"]+1} on '+math(atom(proof["atoms"][r["pivot"]-1]))+"."
        lines.append((r["clause"],text,f"line{j}:"))
    body=[]
    for i,(row,description,field) in enumerate(lines,1):
        square_strip=strip(c,cert,field,palette)
        body.append(f'<tr><th scope="row">{i}</th><td>{math(clause(row,proof["atoms"]))}</td>'
                    f'<td>{description}<details><summary>Show associated Wang squares</summary>{square_strip}</details></td></tr>')
    given="".join(f'<li><div class="scroll">{math(formula(p))}</div></li>' for p in original["premises"])
    return f"""<article class="proof" id="case-{name}">
<h3>{escape(short(name))}</h3>
<p>Found with {escape(PROOF_MODES[mode])}. The source formulas, open rectangle and serial row shape were supplied to the search.</p>
<details><summary>Read the input premises</summary><ol>{given}</ol></details>
<p><strong>Conclusion</strong></p><div class="scroll">{math(formula(original["goal"]))}</div>
<div class="scroll"><table><thead><tr><th>Line</th><th>Clause</th><th>Reading and squares</th></tr></thead><tbody>{''.join(body)}</tbody></table></div>
</article>"""


def marking(row):
    mode=next(r for r in row["results"] if r["mode"]=="activity")
    c,_=read_rectangle(row["id"],"activity")
    n=len(c["inputs"])
    cut=min((v for v in mode["cuts"] if len(v)>=2),
            key=lambda a:(len(a),min(map(abs,a))-max(map(abs,a))))
    selected={abs(x):x>0 for x in cut}
    pos=lambda i: 28+704*(i-1)/max(1,n-1)
    bars=[]
    for i,input in enumerate(c["inputs"],1):
        label=input["name"]
        color="#b5cabe" if label.startswith(("source","binder")) else "#abc7dc"
        bars.append(f'<line x1="{pos(i):.3f}" y1="55" x2="{pos(i):.3f}" y2="73" stroke="{color}" stroke-width="2"></line>')
    highlights=[]
    names=[]
    for i,bit in sorted(selected.items()):
        x=pos(i)
        color="#814ba2" if bit else "#bd683b"
        highlights.append(f'<circle cx="{x:.3f}" cy="64" r="5.4" fill="{color}" stroke="#fff" stroke-width="1.4"></circle>')
        label=c["inputs"][i-1]["name"]
        names.append([i,label,0 if bit else 1])
    xmin=pos(min(selected))
    xmax=pos(max(selected))
    svg=(f'<svg class="cut" viewBox="0 0 760 105" role="img" aria-label="Highlighted columns involved in a verified Peano conflict">'
         f'<path d="M{xmin:.3f} 45 v-10 H{xmax:.3f} v10" stroke="#6c6482" fill="none" stroke-width="1.8"></path>'
         +"".join(bars+highlights)+"</svg>")
    return svg+table(["Column","Proof field","Value in the rejected combination"],names),names


def matrix(records):
    def cell(r):
        if not r:
            return "—"
        return ("Found" if r["status"]=="SAT" else "Exhausted" if r["status"]=="UNSAT" else "Bounded")+f' · {r["counts"].get("decisions",0):,}'
    rows=[]
    for case in records:
        r={v["mode"]:v for v in case["results"]}
        rows.append([short(case["id"]),case["gates"],*(cell(r.get(m)) for m in METHODS)])
    return table(["Statement","NAND gates",*METHODS.values()],rows)


def render(summary,panels,diagram,matrix_html):
    window=summary["windows"]
    window_rows=[[short(r["id"]),r["attempts"],r["depth"],r["premises"],r["resolutions"]]
                 for r in window]
    transfer_rows=[[r["id"].rsplit("-",1)[1],r["cold"],r["mapped"],r["shuffled"],r["accepted"]]
                   for r in summary["transfer"]]
    hilbert=next(r for r in summary["cases"] if r["id"]=="hilbert-incidence-uniqueness")
    custom=[m for m in hilbert["methods"] if m["status"]=="SAT" and m["mode"] in ("static","activity","learned")]
    hilbert_words=("The boundary-cut search found a checked proof with "
                   +METHODS[custom[0]["mode"]].lower()+".") if custom else (
                   "All three boundary-cut policies hit a limit on the larger Hilbert rectangle.")
    counts=summary["totals"]
    options="".join(f'<option value="{name}">{escape(short(name))}</option>' for name,_ in panels)
    evidence_note=(f"The shared window schedule found {sum(r['depth']!='—' for r in window)} proofs. "
                   "The quantifier-order control had no accepting rectangle in its tested windows.")
    serial_rows=[]
    for row in summary["serial"]:
        def label(r):
            return "Found" if r["status"]=="SAT" else "Exhausted" if r["status"]=="UNSAT" else "Bounded"
        sat={r["mode"]:r for r in row["sat"]}
        blocks={r["mode"]:r for r in row["blocks"]}
        plain=blocks["block-plain"]
        marked=blocks["block-marked"]
        serial_rows.append([short(row["id"]),label(sat["cadical195"]),label(sat["glucose4"]),
                            f'{label(plain)} · {plain["counts"].get("nodes",0):,}',
                            f'{label(marked)} · {marked["counts"].get("nodes",0):,}',marked["marks"]])
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Finding proofs in open Wang rectangles</title><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.cut{{display:block;width:100%;background:#f8f7f2;border:1px solid #ced9d1;border-radius:.5rem}}
#comparison table{{min-width:990px}}.metrics{{font-variant-numeric:tabular-nums}}
pre{{white-space:pre-wrap;overflow:auto;background:#e5eee6;padding:.7rem}}</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · Open Wang rectangles · November 2026</p>
<h1>Finding proofs in open Wang rectangles</h1>
<p>The same 100 square types check clause origins, typed instantiation and resolution. The proof fields are open at the start. A search fills them, and an independent checker checks the completed rectangle.</p>
<nav aria-label="On this page"><a href="#reader">Proof lines</a><a href="#cuts">Marked columns</a><a href="#comparison">Search controls</a><a href="#serial">Serial proof search</a><a href="#windows">Open window schedule</a><a href="#evidence">Evidence</a></nav></header>
<section id="reader"><h2>Read the found proofs</h2>
<p>Each clause is translated into a formula. Expanding a line reveals squares from a machine row reading its proof fields. Ports keep their orientation, and the square placements use translation.</p>
<p><label>Statement <select id="case-menu">{options}</select></label></p>{''.join(html for _,html in panels)}
</section>
<section id="cuts"><h2>Mark a failed combination of columns</h2>
<p>A conflict traces through the gates to the boundary decisions responsible for it. The highlighted values are an independently replayed Peano example. No accepting completion can use all these values together. A later search can jump back to the last level needed to apply this cut.</p>
<div class="proof">{diagram}</div>
<p>The independent checker applies the opposite of the cut and verifies that unit propagation leads to contradiction. Earlier cuts enter that checker in the order in which they were certified. The search also tests activity-based ordering and a policy trained on synthetic quantified implication chains.</p></section>
<section id="comparison"><h2>Compare the same open problem</h2>
<p>Each row uses one circuit and the same open proof fields. The benchmark window sizes come from prior proof runs. The SAT controls work directly on the same NAND constraints, with a conflict budget. The custom boundary arms have time, decision and cut budgets. Decisions count boundary bits for the custom arms and can include internal gates for the SAT controls.</p>
{matrix_html}
<p>{hilbert_words} In this bank, the conflict-activity arm found {counts["activity"].get("SAT",0)} proofs and the frozen RL arm found {counts["learned"].get("SAT",0)}. CaDiCaL found {counts["cadical195"].get("SAT",0)}. The seeded arm receives cuts discovered by a separate run, so its figures exclude the cost of that discovery.</p>
<p>The benchmark includes two published TPTP tutorial problems and a mutation of the family problem. Their formulas were transcribed into the same typed input format. <a href="https://tptp.org/UserDocs/TPTPWorldTutorial/LogicFOF.html">TPTP first-order tutorial</a></p>
<p>CaDiCaL and Glucose run through PySAT. All accepting assignments are checked as ground derivations and as Wang rectangles. <a href="https://pysathq.github.io/docs/api/solvers.html">PySAT solver interface</a></p></section>
<section id="serial"><h2>Group the proof into clause-sized moves</h2>
<p>A serial window requires each row to resolve the current clause with a fresh premise slot. The clauses, instantiations, pivot and order of the two parents remain open. This tests a restricted proof family. Its accepted proofs also pass the original rectangle checker.</p>
{table(["Statement","Serial CaDiCaL","Serial Glucose","Plain blocks","Marked blocks","Checked marks"],serial_rows)}
<p>The block solver offers every admitted ground clause as a move. It records a failed state by its current clause and the number of inference slots left. Each inference can remove at most one literal from the current clause. A literal with no opposite in the admission inventory can never be removed. The verifier also re-enumerates the successors of exhausted states.</p>
<p>On the Hilbert case, the marked block search found the proof in 1,351 nodes. Plain blocks reached the 120,000-node limit with the same moves and ordering. Both SAT controls found proofs after the serial restriction was added. A block node, a boundary-bit decision and a SAT decision measure different work.</p></section>
<section id="windows"><h2>Search without a supplied proof size</h2>
<p>{evidence_note} Every statement in that run received the same schedule over ground depth, premise slots and inference rows.</p>
{table(["Statement","Windows tried","Ground depth","Premise slots","Inference rows"],window_rows)}
<p>The earlier Peano comparison held the rectangle fixed. Using certified cuts as propagation rules reduced the search from 1,024 nodes to 131. Transferring rechecked cuts by boundary field name saved a few nodes on two successor variants. The shuffled mapping serves as a control.</p>
{table(["Successor count","Cold nodes","Mapped-cut nodes","Shuffled-cut nodes","Mapped cuts admitted"],transfer_rows)}
</section>
<section id="evidence"><h2>Replay the experiments</h2>
<ul><li><a href="{STEM}-results.json">Benchmark and reader summary</a></li><li><a href="{STEM}-evidence.zip">Source, cuts, checked rectangles and prior runs</a></li><li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li><li><a href="{OLD}">How source clauses enter the grid</a></li></ul>
<p>The protocol pins the compiled PySAT extension used for the conventional controls. Its two packages can be installed in a temporary directory. The source compiler uses canonical variable order for this release. The C++ checker caches root-level propagation while replaying cuts.</p>
<pre><code>python3.12 -m pip install --target /tmp/wang-pysat python-sat==1.9.dev21 six==1.17.0
clang++ -O3 -std=c++17 -Wall -Wextra source/replay_fast_v1.cpp -o /tmp/gcts-wang-rup-20261105-v1
python3.12 -I -S -B source/benchmark_fast_v1.py /tmp/wang-pysat /tmp/gcts-wang-rup-20261105-v1
python3.12 -I -S -B source/serial_v1.py /tmp/wang-pysat
python3.12 -I -S -B source/serial_blocks_v1.py</code></pre>
</section></main><script>
const menu=document.getElementById("case-menu");
function choose(){{for(const panel of document.querySelectorAll(".proof[id^=case-]"))panel.hidden=panel.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""


def main():
    checked=load("data/fast/results-v1.json")
    originals={r["id"]:r for r in load("input/cases-v1.json")+load("input/new-cases-v1.json")
              +load("input/tutorial-cases-v1.json")["cases"]}
    bank={r["id"]:r for r in checked["cases"]}
    serial=load("data/serial-v1.json")
    serial_by={r["id"]:r for r in serial}
    blocks={r["id"]:r for r in load("data/blocks-v1.json")}
    panels=[]
    for name in ("hilbert-incidence-uniqueness","peano-nonzero-successor","tptp-tutorial-family"):
        row=blocks.get(name)
        if row and any(r["mode"]=="block-marked" and r["status"]=="SAT" for r in row["results"]):
            panels.append((name,proof_panel(row,originals[name],"block-marked")))
        elif name in serial_by:
            row=serial_by[name]
            accepted=[r for r in row["results"] if r["mode"]=="cadical195" and r["status"]=="SAT"]
            if accepted:
                serial_row={**row,"results":[{**accepted[0],"mode":"cadical195-serial"}]}
                panels.append((name,proof_panel(serial_row,originals[name],"cadical195-serial")))
    mark,names=marking(bank["peano-nonzero-successor"])
    windows=[]
    for r in load("prior/window-search-v1.json"):
        spec=r["found"]["spec"] if r["found"] else {k:"—" for k in ("depth","premises","resolutions")}
        windows.append(dict(id=r["id"],attempts=len(r["attempts"]),**spec))
    transfer=[]
    for r in load("prior/transfer-v1.json"):
        modes={v["mode"]:v for v in r["methods"]}
        transfer.append(dict(id=r["id"],accepted=modes["mapped"]["import_counts"]["accepted"],
                             **{k:v["stats"]["nodes"] for k,v in modes.items()}))
    result=dict(status="CHECKED_OPEN_WANG_BENCHMARK_REPORT",totals=checked["summary"],
                palette_sha256=checked["palette_sha256"],weights=checked["weights"],windows=windows,
                transfer=transfer,displayed_cut=names,readers=[n for n,_ in panels],
                serial=[dict(id=r["id"],sat=[{k:v for k,v in m.items() if k not in ("cuts","proof")}
                                            for m in r["results"]],
                             blocks=[{k:v for k,v in m.items() if k not in ("failures","proof")}
                                     for m in blocks[r["id"]]["results"]]) for r in serial],
                cases=[dict(id=r["id"],gates=r["gates"],spec=r["spec"],methods=[
                    {k:v for k,v in m.items() if k not in ("cuts","proof")} for m in r["results"]]) for r in checked["cases"]])
    page=render(result,panels,mark,matrix(checked["cases"]))
    with (ROOT/"report"/(STEM+".html")).open("x") as f:f.write(page)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:json.dump(result,f,indent=2,sort_keys=True)


if __name__=="__main__":
    main()
