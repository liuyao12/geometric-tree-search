// Independent reverse unit propagation with a cached root assignment.
#include <cstdlib>
#include <iostream>
#include <vector>

using Clause = std::vector<int>;
using Assignment = std::vector<signed char>;

static int index(int lit) { return 2 * std::abs(lit) + (lit < 0); }

static int value(const Assignment& assignment, int lit) {
    return assignment.at(std::abs(lit)) * (lit < 0 ? -1 : 1);
}

static bool put(Assignment& assignment, std::vector<int>& pending, int lit) {
    if (value(assignment, lit) < 0) return false;
    if (!value(assignment, lit)) {
        assignment.at(std::abs(lit)) = lit < 0 ? -1 : 1;
        pending.push_back(lit);
    }
    return true;
}

class Replay {
public:
    explicit Replay(int vars) : watches(2 * vars + 2), root(vars + 1) {}

    void index_clause(const Clause& clause) {
        for (int lit : clause) watches.at(index(lit)).push_back(clauses.size());
        clauses.push_back(clause);
    }

    void initialize() {
        std::vector<int> pending;
        for (const auto& row : clauses) {
            if (row.empty() || (row.size() == 1 && !put(root, pending, row.front()))) {
                inconsistent = true;
                return;
            }
        }
        inconsistent = !propagate(root, pending);
    }

    bool refute(const Clause& cut) const {
        if (inconsistent) return true;
        Assignment copy = root;
        std::vector<int> pending;
        for (int lit : cut)
            if (!put(copy, pending, -lit)) return true;
        return !propagate(copy, pending);
    }

    void add_checked(const Clause& cut) {
        index_clause(cut);
        if (inconsistent) return;
        std::vector<int> pending;
        inconsistent = !inspect(cut, root, pending) || !propagate(root, pending);
    }

private:
    static bool inspect(const Clause& row, Assignment& assignment, std::vector<int>& pending) {
        int open = 0;
        for (int lit : row) {
            const int v = value(assignment, lit);
            if (v > 0) return true;
            if (v == 0) {
                if (open) return true;
                open = lit;
            }
        }
        return open && put(assignment, pending, open);
    }

    bool propagate(Assignment& assignment, std::vector<int>& pending) const {
        for (size_t i = 0; i < pending.size(); ++i) {
            const int l = pending[i];
            for (size_t j : watches.at(index(-l)))
                if (!inspect(clauses[j], assignment, pending)) return false;
        }
        return true;
    }

    std::vector<Clause> clauses;
    std::vector<std::vector<size_t>> watches;
    Assignment root;
    bool inconsistent = false;
};

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int vars, base, cuts;
    if (!(std::cin >> vars >> base >> cuts) || vars < 1 || base < 0 || cuts < 0) return 2;
    Replay checker(vars);
    for (int i = 0; i < base + cuts; ++i) {
        int len;
        if (!(std::cin >> len) || len < 0 || len > vars) return 2;
        Clause row(len);
        for (int& l : row)
            if (!(std::cin >> l) || l < -vars || l > vars || l == 0) return 2;
        if (i < base) {
            checker.index_clause(row);
            continue;
        }
        if (i == base) checker.initialize();
        if (!checker.refute(row)) {
            std::cerr << "Cut " << i - base << " failed replay\n";
            return 1;
        }
        checker.add_checked(row);
    }
    std::cout << cuts << '\n';
}
