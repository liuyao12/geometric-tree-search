"""Find serial Wang proofs with clause-sized moves and exact failure marks."""

from collections import Counter
from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from benchmark_v1 import compile_case, decode, prop


def catalog(prefix):
    result={}
    atom_ids={a:i for i,a in enumerate(prefix.atoms)}
    for s in prefix.schemas:
        order=sorted(s["variables"])
        domains=[prefix.types[s["variables"][v]] for v in order]
        for ids in product(*domains):
            env={v:prefix.terms[i] for v,i in zip(order,ids,strict=True)}
            def ground(t):
                return env[t] if isinstance(t,str) else (t[0],*map(ground,t[1:]))
            try:
                lits=[(1 if sign else -1)*(atom_ids[(a[0],*map(ground,a[1:]))]+1)
                      for sign,a in s["clause"]]
            except KeyError:
                continue
            row=prop.mask(lits)
            result.setdefault(row,dict(schema=s["id"],substitution=env))
    return result


class SerialSearch:
    def __init__(self,admitted,limits,marked):
        self.admitted=admitted
        self.rows=sorted(admitted,key=lambda c:((c[0]|c[1]).bit_count(),c))
        self.failed={}
        self.marked=marked
        self.limits=limits
        self.started=time.monotonic()
        self.counts=Counter()
        self.pos=0
        self.neg=0
        for a,b in admitted:
            self.pos|=a
            self.neg|=b
        self.cache={}

    def options(self,c):
        if c not in self.cache:
            result={}
            for a in self.rows:
                for left,right,side in ((c,a,0),(a,c,1)):
                    for bit in prop.bits(left[0]&right[1]):
                        r=prop.resolution(left,right,bit)
                        if not r[0]&r[1]:
                            result.setdefault(r,(a,side,bit.bit_length()))
            self.cache[c]=sorted(result.items(),key=lambda r:((r[0][0]|r[0][1]).bit_count(),r[0]))
        return self.cache[c]

    def obstruction(self,c,remaining):
        return "literal-capacity" if (c[0]|c[1]).bit_count()>remaining else (
               "missing-opposite" if c[0]&~self.neg or c[1]&~self.pos else None)

    def visit(self,c,remaining):
        if self.counts["nodes"]>=self.limits["nodes"] or time.monotonic()-self.started>=self.limits["seconds"]:
            return "BOUNDED",None
        self.counts["nodes"]+=1
        if not remaining and c==(0,0):
            return "SAT",[]
        key=(c,remaining)
        if self.marked and key in self.failed:
            self.counts["hits"]+=1
            return "UNSAT",None
        reason=self.obstruction(c,remaining) if self.marked else None
        if reason is None and remaining:
            for nxt,op in self.options(c):
                status,trail=self.visit(nxt,remaining-1)
                if status=="SAT":
                    return "SAT",[(nxt,op),*trail]
                if status=="BOUNDED":
                    return status,None
        if self.marked:
            self.failed[key]=reason or ("exhausted" if remaining else "terminal")
        return "UNSAT",None

    def run(self,depth):
        for first in self.rows:
            status,trail=self.visit(first,depth)
            if status!="UNSAT":
                return status,(first,trail) if trail is not None else None
        return "UNSAT",None

    def verify_failures(self):
        # Enumerate successors a second way, using literal sets and deleting
        # the two pivot occurrences explicitly.
        bank=[set(prop.literals(c)) for c in self.rows]
        for (c,k),reason in sorted(self.failed.items(),key=lambda x:x[0][1]):
            s=set(prop.literals(c))
            if reason=="literal-capacity":
                assert len(s)>k
            elif reason=="missing-opposite":
                assert any(all(-l not in q for q in bank) for l in s)
            elif reason=="terminal":
                assert k==0 and s
            else:
                assert reason=="exhausted" and k>0
                for premise in bank:
                    for l in s:
                        if -l not in premise:
                            continue
                        new=(s-{l})|(premise-{-l})
                        if all(-v not in new for v in new):
                            assert (prop.mask(new),k-1) in self.failed
        return len(self.failed)


def witness(trail,admitted,premise_count):
    first,steps=trail
    premises=[first]+[op[0] for _,op in steps]
    origins=[admitted[x] for x in premises]
    proof=[]
    for i,(nxt,(_,side,pivot)) in enumerate(steps):
        a,b=(0 if i==0 else premise_count+i-1),i+1
        left,right=(a,b) if side==0 else (b,a)
        proof.append(dict(left=left,right=right,pivot=pivot,clause=prop.literals(nxt)))
    return origins,[prop.literals(r) for r in premises],proof


def bits_for(c,prefix,origins,premises,proof):
    from origin_v1 import OriginPrefix
    original=prefix.original
    prefix.origins=origins
    prefix.premises=premises
    prefix.rows=[]
    other,bits,_=prop.circuit(len(prefix.atoms),premises,proof,prefix=OriginPrefix(prefix,original))
    assert c==other
    return bits


def main():
    protocol=prop.load("blocks-protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/n)==v for n,v in protocol["pins"].items())
    full=prop.load("protocol-v1.json")
    problems={r["id"]:r for r in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json")
              +prop.load("input/tutorial-cases-v1.json")["cases"]}
    from origin_v1 import Source
    palette=prop.wang.palette()
    output=[]
    for spec in protocol["cases"]:
        name=spec["id"]
        c,_,prefix,fields,functions=compile_case(problems[name],spec,full)
        origin=Source(problems[name])
        origin.clauses(full["cnf_limit"])
        prefix.original=origin
        admitted=catalog(prefix)
        results=[]
        for mode in ("block-plain","block-marked"):
            search=SerialSearch(admitted,protocol["limits"],mode=="block-marked")
            status,trail=search.run(spec["resolutions"])
            elapsed=time.monotonic()-search.started
            marks=search.verify_failures()
            row=dict(mode=mode,status=status,seconds=elapsed,counts=dict(search.counts),
                     marks=marks,failures=[(k,v) for k,v in sorted(search.failed.items())])
            if status=="SAT":
                args=witness(trail,admitted,spec["premises"])
                bits=bits_for(c,prefix,*args)
                row["proof"]=decode(bits,prefix,fields,functions)
                rect=prop.wang.certificate(c,bits,palette)
                row["rectangle"]=prop.independent_wang.verify(c,rect,palette)
                assert row["rectangle"]["status"]=="VERIFIED"
                if mode=="block-marked":
                    prop.compressed(f"data/{name}-{mode}-wang-v1.json.gz",dict(circuit=c,certificate=rect))
            results.append(row)
        output.append(dict(id=name,spec=spec,circuit_sha256=prop.wang.digest(c),
                           admitted=len(admitted),gates=len(c["gates"]),results=results))
        print(json.dumps(dict(id=name,admitted=len(admitted),
          modes={r["mode"]:(r["status"],r["counts"],r["marks"],round(r["seconds"],4)) for r in results}),
          sort_keys=True),flush=True)
    prop.save("data/blocks-v1.json",output)


if __name__=="__main__":
    main()
