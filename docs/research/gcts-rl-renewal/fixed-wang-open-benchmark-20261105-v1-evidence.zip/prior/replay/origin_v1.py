"""Signed source syntax, clause origins, and fixed-palette checking."""

from collections import Counter
from copy import deepcopy
from itertools import product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import herbrand_v1 as fol
import resolution_v1 as prop
from in_grid_v1 import lift


class Source:
    def __init__(self, problem):
        self.problem=problem
        self.functions=dict(problem["functions"])
        self.predicates=dict(problem["predicates"])
        self.sorts=tuple(problem["sorts"])
        assert self.sorts and len(set(self.sorts))==len(self.sorts)
        assert type(problem["equality"]) is bool
        assert not any(n.startswith("=") for n in self.predicates)
        for args,out in self.functions.values():
            assert set(args)<=set(self.sorts)
            assert out in self.sorts
        assert all(set(args)<=set(self.sorts) for args in self.predicates.values())
        if problem["equality"]:
            self.predicates.update({"="+s:[s,s] for s in self.sorts})
        self.nodes=[]
        self.binders=[]
        self.routes={}
        self.roots=[self.parse(p,True,()) for p in problem["premises"]]
        self.roots.append(self.parse(problem["goal"],False,()))

    def node(self,*value):
        self.nodes.append(value)
        return len(self.nodes)-1

    def term(self,t,scope,sort):
        if isinstance(t,str):
            _,declared,value,_=next(b for b in reversed(scope) if b[0]==t)
            assert declared==sort
            return value
        name,*args=t
        expected,out=self.functions[name]
        assert out==sort
        return (name,*(self.term(x,scope,s) for x,s in zip(args,expected,strict=True)))

    def parse(self,formula,sign,scope):
        op,*args=formula
        if op=="atom":
            p,*terms=args
            head=(p,*(self.term(t,scope,s) for t,s in zip(terms,self.predicates[p],strict=True)))
            return self.node("literal",(sign,head))
        if op=="not":
            q,=args
            return self.parse(q,not sign,scope)
        if op in ("all","exists"):
            name,s,body=args
            assert name.startswith("?") and s in self.sorts
            universal=(op=="all")==sign
            index=len(self.binders)
            dependencies=tuple(i for _,_,v,i in scope if isinstance(v,str)) if not universal else ()
            if universal:
                term=f"?v{index}"
            else:
                symbol=f"sk{index}"
                while symbol in self.functions or symbol in self.predicates:
                    symbol+="_"
                by_id={i:(s0,t) for _,s0,t,i in scope}
                self.functions[symbol]=([by_id[i][0] for i in dependencies],s)
                term=(symbol,*(by_id[i][1] for i in dependencies))
            self.binders.append(dict(binder=index,name=name,sort=s,universal=universal,
                                     dependencies=dependencies,term=term,source=op,polarity=sign))
            return self.node("binder",index,self.parse(body,sign,(*scope,(name,s,term,index))))
        left,right=args
        def binary(kind,a,b):
            return self.node(kind,self.parse(a[0],a[1],scope),self.parse(b[0],b[1],scope))
        if op in ("and","or","implies"):
            conjunction=(op=="and")==sign if op!="implies" else not sign
            return binary("choice" if conjunction else "union",(left,sign if op!="implies" else not sign),(right,sign))
        assert op=="iff"
        inner="union" if sign else "choice"
        a=binary(inner,(left,False),(right,True))
        b=binary(inner,(right,False),(left,True))
        return self.node("choice" if sign else "union",a,b)

    def clauses(self,limit):
        def cnf(i):
            op,a,*rest=self.nodes[i]
            if op=="literal":
                return {frozenset([a]):{}}
            b,=rest
            if op=="binder":
                return cnf(b)
            left,right=cnf(a),cnf(b)
            if op=="choice":
                result={row:bits|{i:0} for row,bits in left.items()}
                for row,bits in right.items():
                    result.setdefault(row,bits|{i:1})
            else:
                assert op=="union" and len(left)*len(right)<=limit
                result={}
                for (r,x),(s,y) in product(left.items(),right.items()):
                    assert not x.keys()&y.keys()
                    together=r|s
                    if not any((not p,a) in together for p,a in together):
                        result.setdefault(together,x|y)
            assert len(result)<=limit
            return result
        records=[]
        for n,root in enumerate(self.roots):
            for j,(row,route) in enumerate(cnf(root).items()):
                name=f"source{n+1}-clause{j+1}"
                self.routes[name]=(n,route)
                used={}
                def variables(term,sort):
                    if isinstance(term,str):
                        assert used.setdefault(term,sort)==sort
                    else:
                        args,out=self.functions[term[0]]
                        assert out==sort
                        for t,s in zip(term[1:],args,strict=True):
                            variables(t,s)
                for _,(p,*terms) in row:
                    for t,s in zip(terms,self.predicates[p],strict=True):
                        variables(t,s)
                records.append(dict(id=name,variables=used,clause=sorted(row,key=repr)))
        for i,s in enumerate(self.sorts):
            if not any(not args and out==s for args,out in self.functions.values()):
                a=f"inhabitant{i}"
                while a in self.functions:
                    a+="_"
                self.functions[a]=([],s)
        result=dict(id=self.problem["id"],sorts=self.sorts,functions=self.functions,
                    predicates=self.problem["predicates"],equality=self.problem["equality"],
                    clauses=records,goal=None)
        fol.signature(result)
        return result


class OriginPrefix:
    def __init__(self,prefix,source):
        self.prefix=prefix
        self.source=source
        self.fields={}
        self.replays=[]
        self.binder_checks=[]
        self.choice_ids=[i for i,node in enumerate(source.nodes) if node[0]=="choice"]
        alphabet={node[1] for node in source.nodes if node[0]=="literal"}
        alphabet.update(lit for s in prefix.schemas if s["id"] in source.routes for lit in s["clause"])
        self.alphabet=sorted(alphabet,key=repr)

    def inputs(self,fields,values):
        self.prefix.inputs(fields,values)
        def field(name,value):
            index=len(fields)
            assert name not in self.fields and value in (0,1)
            self.fields[name]=index
            fields.append(dict(name=name,value=None))
            values.append(int(value))
            return index
        for binder in self.source.binders:
            i=binder["binder"]
            expected=[("universal",binder["universal"])]
            expected.extend((f"sort{n}",s==binder["sort"]) for n,s in enumerate(self.source.sorts))
            expected.extend((f"uses{j}",j in binder["dependencies"]) for j in range(len(self.source.binders)))
            self.binder_checks.extend((field(f"binder{i}:{k}",v),int(v)) for k,v in expected)
        for schema in self.prefix.schemas:
            name=schema["id"]
            if name not in self.source.routes:
                assert self.source.problem["equality"] and not name.startswith("source")
                continue
            actual,route=self.source.routes[name]
            tag=[field(f"{name}:formula{i}",i==actual) for i in range(len(self.source.roots))]
            branch={i:field(f"{name}:choose{i}",route.get(i,0)) for i in self.choice_ids}
            claims=[field(f"{name}:literal{i}",lit in schema["clause"]) for i,lit in enumerate(self.alphabet)]
            self.replays.append((tag,branch,claims,set(schema["clause"])))

    def compile(self,b):
        rows,checks=self.prefix.compile(b)
        checks.extend(b.EQ(ref,val) for ref,val in self.binder_checks)
        for tag,branch,claims,want in self.replays:
            checks.append(b.any(tag))
            checks.extend(b.NOT(b.AND(a,c)) for j,a in enumerate(tag) for c in tag[j+1:])
            def select(i):
                op,a,*rest=self.source.nodes[i]
                if op=="literal":
                    return {a:1}
                q,=rest
                if op=="binder":
                    return select(q)
                left,right=select(a),select(q)
                bits={}
                for k in sorted(left.keys()|right.keys(),key=repr):
                    x,y=left.get(k,0),right.get(k,0)
                    bits[k]=b.mux(branch[i],x,y) if op=="choice" else b.OR(x,y)
                return bits
            roots=[select(p) for p in self.source.roots]
            for lit,ref in zip(self.alphabet,claims,strict=True):
                produced=b.any(b.AND(j,r.get(lit,0)) for j,r in zip(tag,roots,strict=True))
                checks.extend((b.EQ(ref,produced),b.EQ(ref,int(lit in want))))
        return rows,checks


def rejecting_rectangle(circuit,bits,palette):
    gates,out=prop.wang.evaluate(circuit,bits)
    assert out==0
    rect=prop.wang.certificate({**circuit,"output":1},bits,palette)
    assert rect["gate_bits"]==gates
    rect["circuit_sha256"]=prop.wang.digest(circuit)
    check=prop.independent_wang.verify(circuit,rect,palette)
    assert check["status"]=="REJECTED" and check["reason"]=="BOTTOM_OUTPUT_ONE_BOUNDARY",check
    return check


def quantify(original,protocol,palette,forgery=False):
    source=Source(original)
    case=source.clauses(protocol["cnf_limit"])
    if forgery:
        assert len(case["clauses"])==2
        case=deepcopy(case)
        fake=case["clauses"][1]
        (sign,(pred,*terms)),=fake["clause"]
        assert not sign and pred=="Q"
        fake["clause"]=[(sign,("P",*terms))]
    raw=fol.solve(case,protocol,palette)
    row=dict(original=original,compiled=case,binders=source.binders,outcome=raw,
             syntax_nodes=len(source.nodes),forgery=forgery)
    if raw["status"]!="PROVED":
        assert not forgery
        return row
    prefix,premises,proof=lift(raw,case,protocol["max_terms"])
    extended=OriginPrefix(prefix,source)
    circuit,bits,fields=prop.circuit(len(prefix.atoms),premises,proof,prefix=extended)
    assert len(circuit["gates"])<=protocol["gate_limit"]
    if forgery:
        # The earlier physical resolution certificate from fol.solve is valid
        # relative to its fabricated clause. The source-aware grid rejects it.
        row["rejection"]=rejecting_rectangle(circuit,bits,palette)
        return row
    cert=prop.wang.certificate(circuit,bits,palette)
    checked=prop.independent_wang.verify(circuit,cert,palette)
    assert checked["status"]=="VERIFIED",checked
    prop.compressed(f"data/{case['id']}-source-wang-v1.json.gz",dict(circuit=circuit,certificate=cert))
    attacked=Counter()
    for name,i in extended.fields.items():
        bit=list(bits)
        bit[i]^=1
        if prop.wang.evaluate(circuit,bit)[1]:
            attacked["inactive_or_equivalent"]+=1
        else:
            attacked["rejected"]+=1
    bad=next((i for n,i in extended.fields.items() if ":uses" in n and bits[i]),None)
    if bad is not None:
        attack=list(bits)
        attack[bad]=0
        row["dependency_attack"]=rejecting_rectangle(circuit,attack,palette)
    row.update(rectangle=checked, gates=len(circuit["gates"]),source_inputs=extended.fields,
               origin_routes=source.routes,mutations=dict(attacked))
    return row


def main():
    protocol=prop.load("protocol-v1.json")
    assert protocol["runtime"]==prop.pin(Path(sys.executable))
    assert all(prop.pin(ROOT/name)==v for name,v in protocol["pins"].items())
    palette=prop.wang.palette()
    rows=[]
    for original in prop.load("input/cases-v1.json")+prop.load("input/new-cases-v1.json"):
        row=quantify(original,protocol,palette)
        rows.append(row)
        print(json.dumps(dict(id=original["id"],status=row["outcome"]["status"],
                              binders=len(row["binders"]),gates=row.get("gates"),
                              mutations=row.get("mutations")),sort_keys=True),flush=True)
    forged=quantify(prop.load("input/forgery-v1.json"),protocol,palette,forgery=True)
    assert forged["outcome"]["physical"]["status"]=="VERIFIED"
    prop.save("data/results-v1.json",dict(cases=rows,forgery=forged))
    result=dict(status="CHECKED_WANG_SOURCE_CLAUSE_ORIGINS",
                palette_tiles=len(palette["tiles"]),palette_sha256=prop.wang.digest(palette),
                outcomes=dict(Counter(r["outcome"]["status"] for r in rows)),
                proved=[r["original"]["id"] for r in rows if "rectangle" in r],
                forgery=forged["rejection"])
    prop.save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
