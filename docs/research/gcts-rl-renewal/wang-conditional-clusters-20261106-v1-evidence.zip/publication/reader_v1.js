(() => {
  const proof = document.getElementById("proof-select");
  const line = document.getElementById("line-select");
  const previous = document.getElementById("previous");
  const next = document.getElementById("next");
  function active() {
    return [...document.querySelectorAll(".case")].find(node => node.dataset.case === proof.value);
  }
  function showLine() {
    const page = active();
    const template = [...page.querySelectorAll(".line-template")].find(node => node.dataset.line === line.value);
    const slot = page.querySelector(".line-slot");
    window.MathJax?.typesetClear?.([slot]);
    slot.replaceChildren(template.content.cloneNode(true));
    window.MathJax?.typesetPromise?.([slot]);
    previous.disabled = Number(line.value) <= 1;
    next.disabled = Number(line.value) >= Number(page.dataset.lines);
  }
  function showProof() {
    const page = active();
    for (const other of document.querySelectorAll(".case")) other.hidden = other !== page;
    line.replaceChildren();
    for (let i = 1; i <= Number(page.dataset.lines); i++) {
      const option = document.createElement("option");
      option.value = String(i);
      option.textContent = String(i);
      line.append(option);
    }
    line.value = page.dataset.lines;
    showLine();
  }
  proof.addEventListener("change", showProof);
  line.addEventListener("change", showLine);
  previous.addEventListener("click", () => { line.value = String(Number(line.value) - 1); showLine(); });
  next.addEventListener("click", () => { line.value = String(Number(line.value) + 1); showLine(); });
  document.addEventListener("click", event => {
    const jump = event.target.closest("button.jump");
    if (jump) { line.value = jump.dataset.line; showLine(); }
  });
  showProof();
})();
