const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({executablePath:process.env.GCTS_CHROME,headless:true,args:["--no-sandbox"]});
  try {
    for (const width of [390,1280]) {
      const page = await browser.newPage({viewport:{width,height:900}});
      const errors=[];
      page.on("pageerror",error=>errors.push(error.message));
      if(process.env.GCTS_MATHJAX) await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
        route=>route.fulfill({path:process.env.GCTS_MATHJAX,contentType:"application/javascript"}));
      await page.goto(pathToFileURL(process.cwd()+"/report/wang-conditional-clusters-20261106-v1.html").href,{waitUntil:"load",timeout:60000});
      const active=page.locator(".case:visible");
      await active.locator(".line-slot mjx-container").first().waitFor();
      assert.equal(await page.locator(".family").count(),6);
      assert.equal(await page.locator("#proof-select option").count(),12);
      assert.equal(await page.locator("#totals tbody tr").count(),5);
      assert.equal(await page.locator("#details tbody tr").count(),12);
      assert.equal(await page.locator("#line-select").inputValue(),"72");
      assert.equal(await active.locator(".attachments li").count(),1);
      await active.locator(".attachments .jump").click();
      assert.equal(await page.locator("#line-select").inputValue(),"71");
      await active.locator(".line-slot mjx-container").first().waitFor();
      await active.getByText("Inspect this inference’s Wang squares").click();
      assert.equal(await active.locator(".native svg use").count(),9);
      assert.ok(await active.locator(".native svg use").first().evaluate(n=>n.getBBox().width>=36));
      const target=await active.locator(".line-slot button.jump").first().getAttribute("data-line");
      await active.locator(".line-slot button.jump").first().click();
      assert.equal(await page.locator("#line-select").inputValue(),target);
      await page.selectOption("#proof-select","zero-8-compound");
      assert.equal(await page.locator("#line-select").inputValue(),"62");
      await active.locator(".line-slot mjx-container").first().waitFor();
      assert.equal(await active.locator(".attachments li").count(),5);
      await page.selectOption("#line-select","1");
      await active.locator(".line-slot mjx-container").first().waitFor();
      assert.equal(await active.locator(".source-copy").count(),1);
      assert.equal(await page.locator("mjx-merror").count(),0);
      assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),width);
      assert.deepEqual(errors,[]);
      await page.locator("#inventory").scrollIntoViewIfNeeded();
      if(process.env.GCTS_SCREENSHOT) await page.screenshot({path:process.env.GCTS_SCREENSHOT.replace("{width}",width)});
      console.log("Verified",width,"px, six families, twelve proofs, attachment links, copy colors and Wang squares.");
      await page.close();
    }
  } finally {await browser.close();}
}
main().catch(error=>{console.error(error);process.exitCode=1;});
