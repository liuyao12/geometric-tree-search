"""Show conditional lemma families, searched attachments and their checked tile rows."""
from html import escape
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from conditional_families_v1 import clause_put
from copy_ports_v1 import freeze
from copy_views_v1 import case
from proof_views_v1 import clause, expression, math, tile_svg

NAME = "wang-conditional-clusters-20261106-v1"
TITLE = "Let a proof family attach to a new hypothesis"
LABEL = {"no-inventory": "No inventory", "fixed-clusters": "Literal donor clusters",
         "seed-families": "Two seed families", "hierarchy": "Six families over three levels",
         "hierarchy-learned-47": "Hierarchy and frozen learned schedule"}


def read(name):
    path = ROOT / name
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes())


def variable_names(family):
    found = {}
    def visit(t):
        if isinstance(t, str):
            if t not in found:
                found[t] = ("?x", "?y", "?z")[len(found)]
        else:
            for c in t[1:]:
                visit(c)
    visit(family["port"][0][1])
    return found


def families(bank):
    cards = []
    for f in bank:
        rename = variable_names(f)
        port, out = (math(clause(clause_put(f[k], rename))) for k in ("port", "out"))
        label = "Zero-left" if f["donor"].startswith("zero") else "Successor-left"
        children = "Two checked subfamilies of span " + str(f["span"] // 2) if f["children"] else "Extracted from the searched induction step"
        cards.append(f'<article class="family level-{f["level"]}"><h3>{label} · span {f["span"]}</h3>'
                     f'<div class="port formula"><strong>Hypothesis receptor</strong>{port}</div>'
                     f'<div class="compose">{escape(children)}</div>'
                     f'<div class="out formula"><strong>Output receptor</strong>{out}</div>'
                     f'<p>{len(f["recipe"])-1} grounding or resolution records before reuse. '
                     f'Level {f["level"]}.</p></article>')
    return "".join(cards)


def summary(rows, arms):
    pos = [r for r in rows if not r["countermodel"]]
    output = []
    for a in arms:
        runs = [r["runs"][a] for r in pos]
        values = [sum(x["status"] == "PROVED" for x in runs)]
        values.extend(sum(x["counts"].get(k, 0) for x in runs) for k in
                      ("resolutions", "instances", "function_probes", "cluster_steps", "cluster_probes"))
        output.append(f'<tr><th scope="row">{LABEL[a]}</th>' + "".join(f'<td>{v:,}</td>' for v in values) + '</tr>')
    return "".join(output)


def uses(row, family_by_id):
    run = row["runs"]["hierarchy"]
    proof = freeze(run["proof"])
    entries = []
    for use in freeze(run["cluster_uses"]):
        family = family_by_id[use["family"]]
        rename = variable_names(family)
        where = next(i for i, rec in enumerate(proof, 1) if set(rec["clause"]) == set(use["clause"]))
        bindings = ", ".join(math(expression(rename[v]) + r"\mapsto " + expression(t))
                             for v, t in use["bindings"].items())
        entries.append(f'<li>Span {use["span"]}, {bindings}. '
                       f'<button class="jump" data-line="{where}">Read output at line {where}</button></li>')
    return '<details class="attachments" open><summary>Cluster attachments contributing to this proof</summary><ul>' + "".join(entries) + '</ul></details>'


def main():
    data, native = read("data/family-study-v1.json"), read("data/family-diagrams-v1.json.gz")
    bank = {f["id"]: f for f in data["inventory"]}
    pos = [r for r in data["rows"] if not r["countermodel"]]
    types, views, options, detail, verification = {}, [], [], [], []
    for row in pos:
        name = row["original"]["id"]
        expanded = native["proofs"][native["calls"][name + "/hierarchy"]]
        value = dict(row, proof=expanded["proof"], diagram=expanded["diagram"])
        view = case(value, native["bank"], types)
        view = view.replace('<div class="line-slot">', uses(row, bank) + '<div class="line-slot">')
        views.append(view)
        options.append(f'<option value="{name}"{" selected" if name=="successor-4-compound" else ""}>{name}</option>')
        runs = row["runs"]
        values = [runs[a]["counts"]["resolutions"] for a in ("no-inventory", "seed-families", "hierarchy")]
        values += [len(runs[a]["proof"]) for a in ("no-inventory", "hierarchy")]
        detail.append(f'<tr><th scope="row">{name}</th>' + "".join(f'<td>{n:,}</td>' for n in values) + '</tr>')
        receipt = expanded["receipt"]
        verification.append(f'<tr><th scope="row">{name}</th><td>{receipt["steps_without_reuse"]:,}</td>'
                            f'<td>{receipt["marks"]:,}</td><td>{receipt["glyph_equalities"]:,}</td></tr>')
    flat = sum(r["flat_counts"].get("cluster_probes", 0) for r in pos)
    routed = sum(r["runs"]["hierarchy"]["counts"].get("cluster_probes", 0) for r in pos)
    lookups = sum(r["runs"]["hierarchy"]["counts"].get("receptor_probes", 0) for r in pos)
    nodes = sum(r["runs"]["hierarchy"]["counts"].get("receptor_nodes", 0) for r in pos)
    values = dict(title=TITLE, stem=NAME, families=families(data["inventory"]),
        summary=summary(data["rows"], data["arms"]), details="".join(detail), verification="".join(verification),
        cases="".join(views), options="".join(options), flat=f'{flat:,}', routed=f'{routed:,}',
        lookups=f'{lookups:,}', nodes=f'{nodes:,}', runs=str(native["successful_runs"]),
        distinct=str(native["distinct_proofs"]), inventory=data["inventory_sha256"],
        palette='<svg class="palette" width="0" height="0" aria-hidden="true"><defs>'
                + "".join(tile_svg(t, i) for t, i in types.items()) + '</defs></svg>',
        script=(ROOT / "publication/reader_v1.js").read_text())
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace('</style>', (ROOT / "publication/style-v1.css").read_text() + '\n</style>')
    body = (ROOT / "publication/family-body-v1.html").read_text()
    for key, value in values.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
