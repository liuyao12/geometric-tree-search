"""Freeze donor-only families before evaluating larger, newly instantiated obligations."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from conditional_families_v1 import inventory, transform, validate
from copy_ports_v1 import encoded, freeze
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from equality_study_v1 import LIMITS as PRIOR_LIMITS
from family_cases_v1 import cases
from family_search_v1 import FamilySearch
from herbrand_v1 import signature

LIMITS = {**PRIOR_LIMITS, "cluster_probes": 26000, "cluster_applications": 2000, "cluster_steps": 16000}
ARMS = ("no-inventory", "fixed-clusters", "seed-families", "hierarchy", "hierarchy-learned-47")


def build_inventory():
    donors = json.loads((ROOT / "input/donor-proofs-v1.json").read_text())
    bank, digest = inventory(donors)
    return donors, bank, digest


def study():
    donors, bank, digest = build_inventory()
    # The grid and all budgets above are fixed before any held-out run is inspected.
    fixed = []
    for f in bank[:2]:
        literal = transform(f, f["donor_bindings"])
        literal["variables"] = {}
        fixed.append(literal)
    banks = {"no-inventory": [], "fixed-clusters": fixed, "seed-families": bank[:2],
             "hierarchy": bank, "hierarchy-learned-47": bank}
    rows = []
    for original, model in cases():
        if model:
            premises, goal = holds(original, model)
            assert all(premises) and not goal, original["id"]
        normal, translation = compile_case(original)
        check(original, normal, translation)
        runs = {}
        for arm in ARMS:
            weights = donors["frozen_models"]["47"]["weights"] if arm.endswith("47") else ()
            engine = FamilySearch(normal, original["goal"], LIMITS, banks[arm], weights)
            runs[arm] = engine.run()
            assert not model or runs[arm]["status"] == "BOUNDED"
            assert all(runs[arm]["counts"].get(k, 0) <= v for k, v in LIMITS.items())
        flat = FamilySearch(normal, original["goal"], LIMITS, bank, route=False).run()
        routed = runs["hierarchy"]
        assert all(flat.get(k) == routed.get(k) for k in ("status", "stop", "proof", "cluster_uses", "constructor_example"))
        ignored = {"cluster_probes", "receptor_probes", "receptor_nodes"}
        assert {k: v for k, v in flat["counts"].items() if k not in ignored} == {
            k: v for k, v in routed["counts"].items() if k not in ignored}
        rows.append(dict(original=original, normal=normal, translation=translation,
                         countermodel=bool(model), runs=runs, flat_counts=flat["counts"]))
        print(original["id"], {a: (r["status"], r["counts"].get("resolutions", 0), r.get("stop"))
                              for a, r in runs.items()}, flush=True)
    return dict(inventory=bank, inventory_sha256=digest, limits=LIMITS, arms=ARMS, rows=rows,
                donor_ids=[f["donor"] for f in bank[:2]])


def main():
    if not __debug__:
        raise RuntimeError("Replay requires assertions")
    out = study()
    body = json.dumps(out, sort_keys=True, separators=(",", ":")) + "\n"
    path = ROOT / "data/family-study-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print("Verified frozen inventory", out["inventory_sha256"], flush=True)


if __name__ == "__main__":
    main()
