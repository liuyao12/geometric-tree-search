"""A declared transfer grid for two conditional arithmetic lemma families."""
from itertools import product

from induction_cases_v1 import ARITHMETIC, RECURSION, eq, plus, successor

DEPTHS = (2, 4, 8)


def iterate(term, n):
    for _ in range(n):
        term = successor(term)
    return term


def case(family, n, compound, wrong=False):
    c, d = ["c"], ["d"]
    x, y = (plus(c, d), plus(successor(d), c)) if compound else (c, d)
    if family == "zero":
        hypothesis = eq(plus(["zero"], x), x)
        t = iterate(x, n)
        goal = eq(plus(["zero"], t), successor(t) if wrong else t)
    else:
        hypothesis = eq(plus(successor(x), y), successor(plus(x, y)))
        t = iterate(y, n)
        rhs = successor(plus(x, t))
        goal = eq(plus(successor(x), t), successor(rhs) if wrong else rhs)
    return dict(id=f'{family}-{n}-{"compound" if compound else "constant"}' + ("-wrong" if wrong else ""),
                sorts=["Nat"], equality=True, functions={**ARITHMETIC, "c": [[], "Nat"], "d": [[], "Nat"]},
                predicates={}, premises=[*RECURSION, hypothesis], goal=goal)


def modulo(source):
    values = (0, 1, 2)
    return dict(domains={"Nat": values}, predicates={},
                functions={"zero": {(): 0}, "c": {(): 1}, "d": {(): 2},
                           "S": {(a,): (a + 1) % 3 for a in values},
                           "plus": {(a, b): (a + b) % 3 for a, b in product(values, repeat=2)}})


def cases():
    for family, n, compound in product(("zero", "successor"), DEPTHS, (False, True)):
        yield case(family, n, compound), None
    for family, compound in product(("zero", "successor"), (False, True)):
        source = case(family, 2, compound, True)
        yield source, modulo(source)
    source = case("zero", 2, False)
    missing = dict(source, id="missing-recursion", premises=[source["premises"][0], source["premises"][-1]])
    vals = (0, 1)
    yield missing, dict(domains={"Nat": vals}, predicates={}, functions={
        "zero": {(): 0}, "c": {(): 0}, "d": {(): 1}, "S": {(a,): 1 for a in vals},
        "plus": {(a, b): a for a, b in product(vals, repeat=2)}})
    missing = dict(source, id="missing-hypothesis", premises=source["premises"][:2])
    yield missing, dict(domains={"Nat": vals}, predicates={}, functions={
        "zero": {(): 0}, "c": {(): 1}, "d": {(): 0}, "S": {(a,): a for a in vals},
        "plus": {(a, b): a for a, b in product(vals, repeat=2)}})
