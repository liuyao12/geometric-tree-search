"""Reject broken recipes and verify that unavailable contexts cannot install a family."""
from copy import deepcopy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from conditional_families_v1 import validate
from copy_ports_v1 import freeze
from family_search_v1 import FamilySearch
from family_study_v1 import build_inventory, LIMITS
from herbrand_v1 import signature
from family_cases_v1 import cases
from equality_cases_v1 import holds


def main():
    donors, bank, _ = build_inventory()
    row = next(r for r in donors["rows"] if r["original"]["id"] == bank[0]["donor"])
    functions, predicates, _ = signature(row["normal"])
    rejected = []
    def reject(name, change):
        changed = deepcopy(bank[0])
        change(changed)
        try:
            validate(changed, functions, predicates)
        except (AssertionError, KeyError, IndexError):
            rejected.append(name)
        else:
            raise AssertionError("Accepted " + name)
    reject("self-dependent resolution", lambda f: next(r for r in f["recipe"] if r["rule"] == "R").update(left=999))
    reject("wrong pivot", lambda f: next(r for r in f["recipe"] if r["rule"] == "R").update(pivot=("=Nat", ("zero",), ("zero",))))
    reject("unanchored schema", lambda f: next(r for r in f["recipe"] if r["rule"] == "G").update(source="invented-source"))
    reject("missing premise receptor", lambda f: f.update(port=((True, ("=Nat", ("zero",), ("zero",))),)))
    reject("changed output", lambda f: f.update(out=((True, ("=Nat", ("zero",), ("zero",))),)))
    data = json.loads((ROOT / "data/family-study-v1.json").read_text())
    missing = next(r for r in data["rows"] if r["original"]["id"] == "missing-recursion")
    engine = FamilySearch(missing["normal"], missing["original"]["goal"], LIMITS, bank)
    assert not engine.bank
    missing = next(r for r in data["rows"] if r["original"]["id"] == "missing-hypothesis")
    assert all(not run["cluster_uses"] for run in missing["runs"].values())
    models = {}
    for original, model in cases():
        if model:
            p, g = holds(original, model)
            assert all(p) and not g
            models[original["id"]] = dict(domains=model["domains"],
                functions={k: list(v.items()) for k, v in model["functions"].items()},
                premise_truth=p, conclusion_truth=g)
    body = json.dumps(dict(rejected=rejected, models=models), sort_keys=True, separators=(",", ":")) + "\n"
    path = ROOT / "data/control-models-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print("Rejected", len(rejected), "broken recipes; checked absent recursion and absent hypothesis")


if __name__ == "__main__":
    main()
