"""Extract conditional proof families and compose their matching interfaces."""
from copy import deepcopy
from hashlib import sha256
import json

from copy_ports_v1 import freeze
from fair_search_v1 import ordered, bind
from herbrand_v1 import inspect_term, signature
from study_v1 import grounded, substitute


def variables(t):
    return {t} if isinstance(t, str) else set().union(*(variables(c) for c in t[1:]))


def names(t):
    if isinstance(t, str):
        return set()
    return {t[0]} | set().union(*(names(c) for c in t[1:]))


def schema_key(s):
    return json.dumps([s["variables"], s["clause"]], sort_keys=True, separators=(",", ":"))


def ancestors(proof, root):
    seen, todo = set(), [root]
    while todo:
        i = todo.pop()
        if i not in seen:
            seen.add(i)
            if proof[i]["rule"] == "R":
                todo.extend((proof[i]["left"], proof[i]["right"]))
    return sorted(seen)


def clause_put(clause, env):
    return ordered((s, substitute(a, env)) for s, a in clause)


def size(t):
    return 1 if isinstance(t, str) else 1 + sum(size(c) for c in t[1:])


def validate(family, functions, predicates):
    """Check the symbolic G/R recipe with its explicitly declared premise ports."""
    values = []
    for line in family["recipe"]:
        clause = ordered(line["clause"])
        for _, atom in clause:
            assert tuple(inspect_term(t, family["variables"], functions) for t in atom[1:]) == tuple(predicates[atom[0]])
        op = line["rule"]
        if op == "P":
            assert clause == ordered(family["port"])
        elif op == "G":
            source = family["sources"][line["source"]]
            assert set(line["bindings"]) == set(source["variables"])
            for v, t in line["bindings"].items():
                assert inspect_term(t, family["variables"], functions) == source["variables"][v]
            assert clause == ordered(grounded(source, line["bindings"]))
        else:
            assert op == "R" and 0 <= line["left"] < len(values) and 0 <= line["right"] < len(values)
            a, b = (set(values[line[k]]) for k in ("left", "right"))
            pivot = line["pivot"]
            assert (True, pivot) in a and (False, pivot) in b
            assert clause == ordered((a - {(True, pivot)}) | (b - {(False, pivot)}))
        values.append(clause)
    assert values[-1] == ordered(family["out"])
    assert sum(r["rule"] == "P" for r in family["recipe"]) == 1
    assert len(family["port"]) == len(family["out"]) == 1
    assert family["port"][0][0] and family["out"][0][0]
    assert variables(family["out"][0][1]) <= variables(family["port"][0][1])


def mine(row):
    """Remove the final refutation and expose ground parameter assumptions as ports."""
    proof = freeze(row["runs"]["both"]["proof"])
    functions, predicates, schemata = signature(row["normal"])
    sources = {s["id"]: s for s in schemata}
    last = proof[-1]
    assert last["rule"] == "R" and not last["clause"]
    candidates = [i for i in (last["left"], last["right"])
                  if len(proof[i]["clause"]) == 1 and proof[i]["clause"][0][0]]
    assert len(candidates) == 1
    root, = candidates
    rigid = set()
    def visit_formula(f):
        if f[0] == "atom":
            return set().union(*(names(t) for t in freeze(f[2:])))
        return set().union(*(visit_formula(c) for c in f[1:] if isinstance(c, list)))
    for f in row["original"]["premises"]:
        if f[0] in ("all", "exists"):
            rigid |= visit_formula(f)
    flexible = sorted(n for n, (args, _) in row["original"]["functions"].items() if not args and n not in rigid)
    abstract = {n: f"?m{i}" for i, n in enumerate(flexible)}
    def lift(t):
        if isinstance(t, str):
            return t
        if t[0] in abstract:
            assert len(t) == 1
            return abstract[t[0]]
        return (t[0], *(lift(c) for c in t[1:]))
    recipe, used, mapping, ports = [], {}, {}, []
    for i in ancestors(proof, root):
        old = proof[i]
        line = {"rule": old["rule"], "clause": ordered((s, lift(a)) for s, a in old["clause"])}
        if old["rule"] == "G":
            source = sources[old["source"]]
            if any(names(a) & abstract.keys() for _, a in source["clause"]):
                assert not source["variables"] and len(line["clause"]) == 1 and line["clause"][0][0]
                line["rule"] = "P"
                ports.append(line["clause"])
            else:
                used[source["id"]] = source
                line.update(source=source["id"], bindings={v: lift(t) for v, t in old["bindings"].items()})
        else:
            line.update(left=mapping[old["left"]], right=mapping[old["right"]], pivot=lift(old["pivot"]))
        mapping[i] = len(recipe)
        recipe.append(line)
    assert len(ports) == 1
    family = dict(id=row["original"]["id"] + "-family", donor=row["original"]["id"],
                  variables={v: functions[n][1] for n, v in abstract.items()},
                  donor_bindings={v: (n,) for n, v in abstract.items()}, sources=used,
                  port=ports[0], out=recipe[-1]["clause"], recipe=recipe, span=1, level=0, children=[])
    validate(family, functions, predicates)
    return family


class Unifier:
    def __init__(self):
        self.env = {}

    def expand(self, t):
        if isinstance(t, str):
            return self.expand(self.env[t]) if t in self.env else t
        return (t[0], *(self.expand(c) for c in t[1:]))

    def join(self, a, b):
        a, b = self.expand(a), self.expand(b)
        if a == b:
            return
        if not isinstance(a, str) and isinstance(b, str):
            a, b = b, a
        if isinstance(a, str):
            if a in variables(b):
                raise ValueError("occurs check")
            self.env[a] = b
            return
        if a[0] != b[0] or len(a) != len(b):
            raise ValueError("different constructors")
        for x, y in zip(a[1:], b[1:], strict=True):
            self.join(x, y)


def transform(family, env):
    out = deepcopy(family)
    out["port"], out["out"] = (clause_put(family[k], env) for k in ("port", "out"))
    for line in out["recipe"]:
        line["clause"] = clause_put(line["clause"], env)
        if line["rule"] == "G":
            line["bindings"] = {v: substitute(t, env) for v, t in line["bindings"].items()}
        if line["rule"] == "R":
            line["pivot"] = substitute(line["pivot"], env)
    return out


def compose(first, second):
    """Unify the output of one family with the next family's input receptor."""
    left_env = {v: f"?a{i}" for i, v in enumerate(first["variables"])}
    right_env = {v: f"?b{i}" for i, v in enumerate(second["variables"])}
    a, b = transform(first, left_env), transform(second, right_env)
    u = Unifier()
    u.join(a["out"][0][1], b["port"][0][1])
    free = sorted(set().union(*(variables(u.expand(v)) for v in (*left_env.values(), *right_env.values()))))
    canonical = {v: f"?m{i}" for i, v in enumerate(free)}
    env = {v: substitute(u.expand(v), canonical) for v in (*left_env.values(), *right_env.values())}
    a, b = transform(a, env), transform(b, env)
    assert a["out"] == b["port"]
    recipe, mapping = deepcopy(a["recipe"]), {}
    for i, old in enumerate(b["recipe"]):
        if old["rule"] == "P":
            mapping[i] = len(a["recipe"]) - 1
            continue
        line = deepcopy(old)
        if line["rule"] == "R":
            line["left"], line["right"] = (mapping[line[k]] for k in ("left", "right"))
        mapping[i] = len(recipe)
        recipe.append(line)
    sorts = {**{left_env[v]: s for v, s in first["variables"].items()},
             **{right_env[v]: s for v, s in second["variables"].items()}}
    used_vars = set().union(*(variables(t) for _, t in a["port"]))
    result = dict(id=first["donor"] + f'-span-{first["span"] + second["span"]}',
                  donor=first["donor"], variables={canonical[v]: sorts[v] for v in free if canonical[v] in used_vars},
                  donor_bindings={}, sources={**a["sources"], **b["sources"]}, port=a["port"], out=b["out"],
                  recipe=recipe, span=first["span"] + second["span"], level=max(first["level"], second["level"]) + 1,
                  children=[dict(id=first["id"], bindings={v: env[x] for v, x in left_env.items()}),
                            dict(id=second["id"], bindings={v: env[x] for v, x in right_env.items()})])
    return result


def inventory(donors):
    selected = [r for r in donors["rows"] if r["original"]["id"] in ("zero-left-step", "successor-left-step")]
    assert len(selected) == 2
    bank = [mine(row) for row in selected]
    for _ in range(2):
        layer = bank[-2:]
        for family, row in zip(layer, selected, strict=True):
            combined = compose(family, family)
            functions, predicates, _ = signature(row["normal"])
            validate(combined, functions, predicates)
            bank.append(combined)
    digest = sha256(json.dumps(bank, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return bank, digest
