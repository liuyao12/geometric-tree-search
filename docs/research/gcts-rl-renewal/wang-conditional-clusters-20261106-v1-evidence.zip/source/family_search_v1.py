"""Attach frozen proof families, expanding every use into primitive G/R records."""
from collections import deque

from conditional_families_v1 import clause_put, schema_key, size
from copy_ports_v1 import freeze
from fair_search_v1 import bind, ordered
from herbrand_v1 import inspect_term
from persistent_equality_v1 import Enhanced


def at(term, path):
    for i in path:
        if isinstance(term, str) or i >= len(term):
            return None
        term = term[i]
    return None if isinstance(term, str) else term[0]


def positions(term, path=()):
    if isinstance(term, str):
        return set()
    return {path} | set().union(*(positions(c, (*path, i)) for i, c in enumerate(term[1:], 1)))


class FamilySearch(Enhanced):
    def __init__(self, normal, goal, limits, bank, weights=(), route=True):
        self.bank = sorted(freeze(bank), key=lambda f: (-f["span"], f["id"]))
        self.port_queue, self.port_queued = deque(), set()
        self.cluster_uses, self.applied = [], set()
        self.route = route
        self.output_limit = sum(size(freeze(t)) for t in goal[2:])
        super().__init__(normal, goal, "learned" if weights else "fifo", limits, 47 if weights else 0,
                         weights, True, True)
        schemas = {schema_key(s): s["id"] for s in self.schemas.values()}
        self.sources = {f["id"]: {name: schemas.get(schema_key(s)) for name, s in f["sources"].items()}
                        for f in self.bank}
        self.bank = [f for f in self.bank if all(self.sources[f["id"]].values())]
        paths = set().union(*(positions(f["port"][0][1]) for f in self.bank))
        self.receptor_path = min(paths, key=lambda p: (
            max(sum(at(f["port"][0][1], p) in (key, None) for f in self.bank)
                for key in {at(f["port"][0][1], p) for f in self.bank}), len(p), p)) if paths else ()
        heads = {at(f["port"][0][1], self.receptor_path) for f in self.bank}
        self.receptors = {head: [f for f in self.bank if at(f["port"][0][1], self.receptor_path) in (head, None)]
                          for head in heads}
        self.wildcards = [f for f in self.bank if at(f["port"][0][1], self.receptor_path) is None]

    def observe(self, i):
        super().observe(i)
        clause = self.rows[i][0]
        if len(clause) == 1 and clause[0][0] and i not in self.port_queued:
            self.port_queued.add(i)
            self.port_queue.append(i)

    def attach(self, family, i, env):
        output = clause_put(family["out"], env)
        if output in self.index or sum(size(t) for t in output[0][1][1:]) > self.output_limit:
            return
        self.charge("cluster_applications")
        mapping = {}
        for k, record in enumerate(family["recipe"]):
            expected = clause_put(record["clause"], env)
            if record["rule"] == "P":
                j = i
            else:
                self.charge("cluster_steps")
                if record["rule"] == "G":
                    from study_v1 import substitute
                    bindings = {v: substitute(t, env) for v, t in record["bindings"].items()}
                    name = self.sources[family["id"]][record["source"]]
                    token = name, tuple(sorted(bindings.items()))
                    if token in self.seen_instances:
                        j = self.index.get(expected)
                    else:
                        j = self.instance(name, bindings, "cluster")
                else:
                    from study_v1 import substitute
                    a, b = (mapping[record[v]] for v in ("left", "right"))
                    pivot = substitute(record["pivot"], env)
                    ca, cb = (set(self.rows[x][0]) for x in (a, b))
                    if (True, pivot) not in ca or (False, pivot) not in cb:
                        self.work["cluster_collision_rejections"] += 1
                        return
                    j = self.resolve(a, b, pivot)
            if j is None or self.rows[j][0] != expected:
                self.work["cluster_collision_rejections"] += 1
                return
            mapping[k] = j
        root = mapping[len(family["recipe"]) - 1]
        self.cluster_uses.append(dict(family=family["id"], span=family["span"], bindings=env.copy(),
                                      input=i, output=root, clause=output))
        self.with_units(root)

    def family_pass(self):
        for _ in range(8):
            if not self.port_queue:
                return
            i = self.port_queue.popleft()
            (_, atom), = self.rows[i][0]
            candidates = self.bank
            if self.route:
                self.work["receptor_probes"] += 1
                self.work["receptor_nodes"] += len(self.receptor_path) + 1
                candidates = self.receptors.get(at(atom, self.receptor_path), self.wildcards)
            for f in candidates:
                pattern = f["port"][0][1]
                self.charge("cluster_probes")
                env = {}
                if not bind(pattern, atom, env):
                    continue
                assert set(env) == set(f["variables"])
                if any(inspect_term(t, {}, self.functions) != f["variables"][v] for v, t in env.items()):
                    continue
                key = f["id"], i
                if key not in self.applied:
                    self.applied.add(key)
                    self.attach(f, i, env)
                if () in self.index:
                    return

    def focused(self):
        self.family_pass()
        if () not in self.index:
            super().focused()

    def run(self):
        result = super().run()
        used = set()
        if result["proof"]:
            todo = [self.index[()]]
            while todo:
                i = todo.pop()
                if i not in used:
                    used.add(i)
                    rec = self.rows[i][1]
                    if rec[0] == "R":
                        todo.extend(rec[1:3])
        result["cluster_uses"] = [u for u in self.cluster_uses if u["output"] in used]
        return result
