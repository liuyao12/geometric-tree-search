Conditional proof families with checked premise ports

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/family_study_v1.py
  python3 -I -S -B source/family_controls_v1.py
  python3 -I -S -B source/family_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The commands repeat search, reject broken recipes and evaluate finite
countermodels, replay every marked Wang proof, and regenerate the reader.
The inventory is computed solely from the exact donor snapshot. The three
levels use two specified symbolic composition rounds. The learned scheduler
is frozen from the earlier donor experiment and is not retrained here.
The manifest gives SHA-256 for every included input and result.
