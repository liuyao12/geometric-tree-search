const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { chromium } = require("/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright");

async function main() {
  const browser = await chromium.launch({
    executablePath: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    headless: true,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport:{width:1260,height:900} });
    const errors=[];
    page.on("pageerror",e=>errors.push(e.message));
    const local=pathToFileURL(path.join(__dirname,"..","report","penrose-discovered-substitution-20261105-v1.html"));
    const response=await page.goto(process.argv[2]||local.href,{waitUntil:"load"});
    if(process.argv[2]) assert.equal(response.status(),200);
    await page.waitForFunction(()=>document.querySelectorAll("mjx-container").length===41);
    const evidence=await page.evaluate(()=>({
      diagrams:document.querySelectorAll("svg[role=img]").length,
      nest_polygons:document.querySelectorAll(".nest svg polygon").length,
      math:document.querySelectorAll("mjx-container").length,
      arrow_heads:document.querySelectorAll(".gallery polyline").length,
    }));
    assert.equal(evidence.diagrams,3);
    assert.equal(evidence.nest_polygons,48);
    assert.ok(evidence.arrow_heads>20);
    assert.deepEqual(errors,[]);
    if(!process.argv[2]) {
      await page.locator("#rules").screenshot({path:path.join(__dirname,"browser-rules-v1.png")});
      await page.locator("#plane figure").screenshot({path:path.join(__dirname,"browser-nest-v1.png")});
    }
    await page.setViewportSize({width:390,height:844});
    const mobile=await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth);
    assert.equal(mobile,true);
    const result={status:"CHECKED_PENROSE_READER",...evidence,mobile_no_overflow:mobile};
    const name=process.argv[2]?"live-browser-v1.json":"browser-v1.json";
    fs.writeFileSync(path.join(__dirname,name),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
    process.stdout.write(JSON.stringify(result)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
