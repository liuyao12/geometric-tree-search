"""Render the recovered Penrose rules and their exact nesting certificate."""

from collections import Counter
import cmath
import hashlib
from html import escape
import json
from pathlib import Path
import sys
from xml.etree import ElementTree

ROOT=Path(__file__).resolve().parents[1]
STEM="penrose-discovered-substitution-20261105-v1"
OLD="penrose-vertex-guards-20261105-v1.html"
ZETA=cmath.exp(2j*cmath.pi/5)


def read(p):
    return json.loads(p.read_bytes())


def pin(p):
    b=p.read_bytes()
    return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def audit():
    stages=ROOT/"input"
    for name in ("discovery","standard"):
        root=stages/name
        protocol=read(root/"protocol-v1.json")
        assert all(pin(root/n)==v for n,v in protocol["pins"].items())
        assert not (root/"data/execution.stderr.log").read_bytes()
    discovery=read(stages/"discovery/data/summary-v1.json")
    source=read(stages/"discovery/data/results-v1.json")
    assert source==read(stages/"standard/input/discovery-results-v1.json")
    assert len(source["systems"])==len(source["nested"])==32
    assert [len(rows) for rows in source["partitions"]]==[2,3]
    proof=read(stages/"standard/data/proof-v1.json")
    result=read(stages/"standard/data/summary-v1.json")
    ref=read(stages/"standard/input/standard-figure-v1.json")
    assert proof["status"]==result["status"]=="VERIFIED_STANDARD_P3_SUBSTITUTION"
    assert proof["marks"]==ref["signed_edge_arrows"] and proof["rules"]==source["systems"][proof["system"]]["rules"]
    assert len(proof["boundary_receptors"])==4
    assert proof["nest"]["depth"]==4 and len(proof["nest"]["triangles"])==34
    assert Counter(x["kind"] for x in proof["nest"]["matched_rhombs"])=={0:5,1:8}
    return dict(status="CHECKED_PUBLISHED_PENROSE_SUBSTITUTION",discovery=discovery,
                standard=result,source=ref,proof=proof)


def draw_coord(q):
    w=sum(a*ZETA**k for k,a in enumerate(q))
    return w.real,-w.imag


def vertices(poly):
    return " ".join(f"{x:.5f},{y:.5f}" for x,y in map(draw_coord,poly))


def polygon(poly,fill,stroke,width,opacity=1):
    return (f'<polygon points="{vertices(poly)}" fill="{fill}" stroke="{stroke}" '
            f'stroke-width="{width}" fill-opacity="{opacity}"></polygon>')


def arrow(a,b,count,width):
    x,y=draw_coord(a)
    u,v=draw_coord(b)
    dx,dy=u-x,v-y
    length=(dx*dx+dy*dy)**.5
    dx,dy=dx/length,dy/length
    middle=(x+u)/2,(y+v)/2
    size=width*2.3
    color={1:"#385590",2:"#9a4d15",3:"#317264"}[count]
    heads=[]
    for i in range(count):
        t=(i-(count-1)/2)*size*.88
        p,q=middle[0]+dx*t,middle[1]+dy*t
        head=[(p-size*dx+size*.6*dy,q-size*dy-size*.6*dx),(p,q),
              (p-size*dx-size*.6*dy,q-size*dy+size*.6*dx)]
        heads.append(f'<polyline points="'+ " ".join(f"{a:.5f},{b:.5f}" for a,b in head) +
                     f'" stroke="{color}" stroke-width="{width/2}" fill="none"></polyline>')
    return "".join(heads)


def panel(parent,parts,label):
    xy=[draw_coord(p) for p in parent]
    xs,ys=zip(*xy)
    pad=max(max(xs)-min(xs),max(ys)-min(ys))*.08
    view=f"{min(xs)-pad:.5f} {min(ys)-pad:.5f} {max(xs)-min(xs)+2*pad:.5f} {max(ys)-min(ys)+2*pad:.5f}"
    body=f'<svg viewBox="{view}" role="img" aria-label="{escape(label)}">'+parts+"</svg>"
    ElementTree.fromstring(body)
    return body


def visuals(proof):
    sys.path.insert(0,str(ROOT/"input/standard/source"))
    from standard_v1 import PROTOS, place, scaled
    marks=proof["marks"]
    rules=[]
    for k,cells in enumerate(proof["rules"]):
        parent=tuple(scaled(p,1) for p in PROTOS[k])
        parts=[]
        emitted=set()
        for c in cells:
            poly=place(c)
            parts.append(polygon(poly,("#8bcdbd","#f0c490")[c[0]],"#3c5660",.012))
        for c in cells:
            poly=place(c)
            for a,b,m in zip(poly,poly[1:]+poly[:1],marks[c[0]],strict=True):
                if m<0:
                    a,b=b,a
                key=(a,b,abs(m))
                if key not in emitted:
                    emitted.add(key)
                    parts.append(arrow(a,b,abs(m),.023))
        rules.append(panel(parent,"".join(parts),f"Exact subdivision for marked triangle {k+1}"))
    nest=proof["nest"]
    triangles=[place(c) for c in nest["triangles"]]
    paired={i for r in nest["matched_rhombs"] for i in r["triangles"]}
    parts=[]
    for i,c in enumerate(nest["triangles"]):
        parts.append(polygon(triangles[i],("#8bcdbd","#f0c490")[c[0]],
                             "#3c5660" if i in paired else "#9ba9a8",.017,.91 if i in paired else .35))
    for r in nest["matched_rhombs"]:
        i,j=r["triangles"]
        a,b=triangles[i],triangles[j]
        border=(a[0],a[1],b[0],a[2])
        parts.append(polygon(border,"none","#345661",.032))
    parts.append(polygon(place(nest["seed"]),"#db5b76","#7e1236",.038,.93))
    return *rules,panel(nest["parent"],"".join(parts),"Level four patch with the strictly interior marked seed highlighted")


def expr(coords):
    terms=[]
    for k,value in enumerate(coords):
        if not value:
            continue
        letter="" if k==0 else (r"\zeta" if k==1 else rf"\zeta^{{{k}}}")
        count="" if abs(value)==1 and letter else str(abs(value))
        terms.append(("+" if value>0 else "-",count+letter))
    return ("".join(("" if i==0 and s=="+" else s)+piece for i,(s,piece) in enumerate(terms))) or "0"


def table(head,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th scope="col">{h}</th>' for h in head)+(
        '</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{v}</td>' for v in row)+'</tr>' for row in rows)+
        '</tbody></table></div>')


def render(data):
    proof=data["proof"]
    first,second,nest=visuals(proof)
    rows=[]
    for i,rules in enumerate(proof["rules"]):
        for kind,turn,mirror,t in rules:
            rows.append((r"\("+"AB"[i]+r"\)",r"\("+"AB"[kind]+r"\)",
                         rf"\(\rho^{{{turn}}}"+(r"\bar z" if mirror else "z")+rf" + ({expr(t)})\)"))
    placements=table(("Inflated parent","Child shape","Child placement map"),rows)
    source=escape(data["source"]["doi"],quote=True)
    return rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Discovering the Penrose substitution in exact coordinates</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
:root{{font-family:system-ui,sans-serif;color:#17333d;background:#ebf0f2}}body{{margin:0}}
main{{max-width:64rem;margin:auto;padding:2.4rem clamp(1rem,4vw,2.7rem) 4rem;background:white}}
h1,h2{{line-height:1.17}}h1{{font-size:clamp(2.3rem,6vw,3.6rem);letter-spacing:-.042em;margin:.35em 0}}
h2{{margin-top:2.1rem}}p,li{{line-height:1.55}}a{{color:#075b78}}.meta{{color:#4c6570}}
nav{{display:flex;gap:1rem;flex-wrap:wrap;margin:1.3rem 0 1.9rem}}.scroll{{overflow:auto}}
table{{border-collapse:collapse;width:100%;text-align:left}}th,td{{padding:.6rem;border-bottom:1px solid #d0dfe0}}
th{{background:#edf3f3}}.gallery{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,19rem),1fr));gap:1.1rem}}
figure{{margin:0;padding:.72rem;border:1px solid #bfd4d7;border-radius:.5rem}}figcaption{{margin-top:.45rem}}
svg{{width:100%;height:15.8rem;display:block;background:#f3f7f8;border-radius:.35rem}}.nest svg{{height:clamp(17rem,58vw,28rem)}}
.lead{{background:#e2f2eb;padding:.9rem 1.1rem;border-left:.35rem solid #227f6f}}
</style></head><body><main>
<p class="meta">Geometric tree search · Penrose experiments · November 5, 2026</p>
<h1>Discovering the Penrose substitution in exact coordinates</h1>
<p class="lead">The search recovered a subdivision of each unmarked half-rhomb. It then found compatible edge markings. One solution agrees with the standard arrowed Penrose rhombs and has a checked seed that can be nested to tile the whole plane.</p>
<nav aria-label="Sections"><a href="#discovery">Discovery</a><a href="#rules">Exact rules</a><a href="#plane">Plane construction</a><a href="#evidence">Evidence</a></nav>
<section id="discovery"><h2>Search from two shapes and a multiplier</h2>
<p>Let \(\zeta=\exp(2\pi i/5)\), \(\rho=-\zeta^3\), and \(\varphi=-\zeta^2-\zeta^3\). The vertices are recorded as four integer coefficients in \(\mathbb Z[\zeta]\). The two input shapes have vertices \(A=(0,1,\rho)\) and \(B=(0,1,\rho^3)\). They are the halves of the thin and thick rhombs. The search received their geometry and the proposed multiplier \(\varphi\).</p>
<p>Candidate placements align a triangle vertex with a parent vertex or a vertex of an already placed child. Exact containment, disjointness and area equality found two geometric partitions for \(A\) and three for \(B\). The marking stage tried signed one- and two-arrow labels for unit edges and directed diagonal labels. It found 32 systems in this candidate space. The original arrows were checked afterward against de Bruijn's diagram. <a href="{source}">De Bruijn, Figure 2 on printed page 204</a></p>
</section>
<section id="rules"><h2>Two rules with four boundary prescriptions</h2>
<div class="gallery"><figure>{first}<figcaption>The acute half \(A\) subdivides into one \(A\) and one \(B\).</figcaption></figure>
<figure>{second}<figcaption>The obtuse half \(B\) subdivides into one \(A\) and two \(B\) triangles.</figcaption></figure></div>
<p>Green, blue and amber arrows mark diagonals, single-arrow unit edges and double-arrow unit edges respectively. In the drawing, a matching internal edge is drawn once. The table gives the maps from each canonical child into its inflated parent.</p>
{placements}
<p>The verifier independently aligns every parent boundary in the direction of its arrow. Edges of the same length and arrow type then have exactly the same child endpoints and arrow marks. Each of the four boundary prescriptions therefore composes across the corresponding seam at every subdivision.</p></section>
<section id="plane"><h2>A seed that grows to cover the plane</h2>
<figure class="nest">{nest}<figcaption>The fourth subdivision contains 34 triangles. The highlighted triangle is a strictly interior copy of the same marked type as the outer parent. The darker outlines show the 13 rhombs whose diagonals are already paired inside this finite patch.</figcaption></figure>
<p>Let \(Q\) be the canonical marked \(A\) triangle. The highlighted copy is \(f(Q)\), where \(f(z)=\rho^8z+2+\zeta-\zeta^2-2\zeta^3\). Use the expansive similarity \(S=f^{{-1}}\circ(\varphi^4\,\cdot)\) to bring that copy back to \(Q\). Then \(Q\subset\operatorname{{int}}S(Q)\), and the transported patch on \(S(Q)\) contains the original marked tile.</p>
<p>Apply the same four-step refinement to the expanded tiles at each stage. Deterministic refinement and the verified seam prescriptions preserve the preceding patch. The fixed point of \(S\) lies inside \(Q\), so the nested supports contain disks with radii increasing by the factor \(\varphi^4\). They cover the plane. In the limit every diagonal has a matching mate. Joining each pair gives the two standard Penrose rhombs with matching unit-edge arrows.</p></section>
<section id="evidence"><h2>Evidence</h2><ul>
<li><a href="{STEM}-results.json">Exact placements, boundary maps and nested seed</a></li>
<li><a href="{STEM}-evidence.zip">Full sources, frozen inputs, independent verification and logs</a></li>
<li><a href="{STEM}-manifest.json">Archive file hashes</a></li>
<li><a href="{OLD}">Earlier Penrose vertex guards</a></li>
</ul></section></main></body></html>"""


def main():
    data=audit()
    html=render(data)
    with (ROOT/"report"/(STEM+".html")).open("x") as f:
        f.write(html)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as f:
        json.dump(data,f,indent=2,sort_keys=True)
        f.write("\n")
    print(json.dumps(dict(status=data["status"],triangles=data["standard"]["nested_triangles"])),flush=True)


if __name__=="__main__":
    main()
