"""Independently replay convex-corner refutations using polygon predicates."""
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import mat
from convex_search_v1 import RAYS
from geometry_v1 import Turtle, pairs
from triangle_geometry_v1 import polygon_overlap


def det(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def frozen(value):
    if isinstance(value, list):
        return tuple(map(frozen, value))
    if isinstance(value, dict):
        return {k: frozen(v) for k, v in value.items()}
    return value


def read(name):
    return frozen(json.loads((ROOT/name).read_text()))


def interval(g, start, width):
    u, v = RAYS[start], RAYS[(start+width) % 12]
    return lambda t: all(det((0,0),u,p) >= 0 and det((0,0),p,v) >= 0 for p in g.poly(t))


def orbit_partition(g):
    # Map the interval by its two ray endpoints. For reflected poses reverse them.
    orbit = {}
    domain = {(s,w) for s in range(12) for w in range(1,6)}
    for s, w in sorted(domain):
        keys = set()
        for matrix in g.model.groups.values():
            a, b = (mat(matrix,RAYS[i]) for i in (s,(s+w) % 12))
            if det((0,0),a,b) < 0:
                a,b = b,a
            i,j = RAYS.index(a),RAYS.index(b)
            keys.add((i,(j-i)%12))
        assert keys <= domain and (s,w) in keys
        orbit[s,w] = min(keys)
    actual_rays = {tuple(b[i]-a[i] for i in (0,1)) for t in g.bases for a,b in g.boundary(t)}
    assert actual_rays == set(RAYS)
    return orbit


def roots(g, contained):
    rows = set()
    for base in g.bases:
        for x,y in g.poly(base):
            tile = g.shift(base,(-x,-y))
            if contained(tile):
                rows.add(tile)
    return rows


def verify_node(g, q, patch, contained):
    """Return all geometrically legal next placements for this exact hull obligation."""
    s = g.model.scale
    assert all((a*q[0]+b*q[1]) % s for a,b in g.model.normals)
    polys = tuple(g.poly(t) for t in patch)
    assert all(g.wind(p,q,s) == 0 for p in polys)
    vertices = {(s*x,s*y) for poly in polys for x,y in poly}
    witness = None
    for a,b,c in combinations(sorted(vertices),3):
        turn = det(a,b,c)
        if turn and all(det(u,v,q)*turn >= 0 for u,v in ((a,b),(b,c),(c,a))):
            witness = (a,b,c)
            break
    assert witness
    allowed = set()
    tested = 0
    for base in g.bases:
        px,py = zip(*g.poly(base),strict=True)
        bounds = ((-((s*max(a)-p)//s), (p-s*min(a))//s)
                  for p,a in zip(q,(px,py),strict=True))
        (u,v),(r,t) = bounds
        for x in range(u,v+1):
            for y in range(r,t+1):
                tile = g.shift(base,(x,y))
                if not contained(tile):
                    continue
                tested += 1
                p = g.poly(tile)
                if g.wind(p,q,s) == 1 and all(not polygon_overlap(p,other)["overlap"] for other in polys):
                    allowed.add(tile)
    return allowed,witness,tested


def check(g, cases):
    orbit = orbit_partition(g)
    assert {(row["start"],row["width"]) for row in cases} == set(orbit.values())
    frames = []
    for row in cases:
        start,width = row["start"],row["width"]
        contained = interval(g,start,width)
        offered = {r["tile"] for r in row["roots"]}
        assert len(offered) == len(row["roots"]) and offered == roots(g,contained)
        checked = []

        def verify(patch, proof):
            q = proof["q"]
            assert contained(patch[-1])
            options,witness,tested = verify_node(g,q,patch,contained)
            children = dict(proof["children"])
            assert len(children) == len(proof["children"]) and children.keys() == options
            checked.append(dict(patch=patch,q=q,hull_triangle=witness,children=sorted(options),tested=tested))
            for t in sorted(options):
                verify((*patch,t),children[t])

        for r in row["roots"]:
            assert r["proof"] is not None
            verify((r["tile"],),r["proof"])
        frames.append(dict(start=start,width=width,root_count=len(offered),checked=checked))
    return dict(wedges=len(orbit),orbits=len(frames),nodes=sum(len(f["checked"]) for f in frames),
                roots=sum(f["root_count"] for f in frames), frames=frames)


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    g = Turtle(json.loads((ROOT/"input/exact-point-model-v1.json").read_text()))
    cases = read("data/search-v1.json")
    proof = check(g,cases)
    raw = json.dumps(proof, sort_keys=True,separators=(",",":"))+"\n"
    path = ROOT/"data/convex-audit-v1.json"
    if "--build" in sys.argv:
        path.write_text(raw)
    else:
        assert path.read_text() == raw
    print({k:v for k,v in proof.items() if k != "frames"})


if __name__ == "__main__":
    main()
