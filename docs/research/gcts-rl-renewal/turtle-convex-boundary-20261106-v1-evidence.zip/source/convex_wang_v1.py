"""Compile the checked convex-corner domains into the fixed Wang proof palette."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/d) for d in ("source","wang/source","wang/external/source")]
from convex_audit_v1 import Turtle, check, read
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate


DATA=ROOT/"wang/data"


def selected(tile):
    return ("tile_"+"_".join(str(v).replace("-","m") for v in tile),)


def compile_case(frame):
    rows = {step["patch"]: step for step in frame["checked"]}
    roots = sorted(p[0] for p in rows if len(p)==1)
    assert len(roots)==frame["root_count"]
    sources = {}
    for patch, row in rows.items():
        clause = tuple((False, selected(t)) for t in patch) + tuple((True, selected(t)) for t in row["children"])
        name = "hull-"+str(len(sources)+1)
        sources[name] = dict(id=name,variables={},clause=clause,geometry=row)
    lookup = dict(zip(rows,sources,strict=True))
    sources["corner-domain"] = dict(id="corner-domain", variables={},
                                    clause=tuple((True,selected(t)) for t in roots))
    predicates = {a[0]: () for r in sources.values() for _,a in r["clause"]}
    cert=Certificate(sources,{},predicates,("U",),{})

    def close(patch):
        row = cert.instance(lookup[patch],{})
        for t in rows[patch]["children"]:
            row=cert.resolve(row,close((*patch,t)),selected(t))
        assert set(cert.lines[row]["clause"])=={(False,selected(t)) for t in patch}
        return row

    conclusion=cert.instance("corner-domain",{})
    for t in roots:
        conclusion=cert.resolve(conclusion,close((t,)),selected(t))
    assert not cert.lines[conclusion]["clause"] and conclusion==len(cert.lines)-1
    return sources,frozen(cert.lines)


def prepare(data):
    wires,bundles={},[]
    for frame in data["frames"]:
        sources, proof = compile_case(frame)
        calls=[]
        for i,row in enumerate(proof):
            names,prefix,word=fragment(proof,i,sources,{})
            parsed=decoder.read(prefix,word+"!",require_empty=False)
            match(proof,i,sources,names,parsed,prefix)
            key=fingerprint(prefix,records(word))
            wire=wires.setdefault(key,dict(prefix=prefix,word=word,example=(frame["start"],frame["width"],i+1),
                                           uses=0,rule=row["rule"]))
            assert (prefix,word)==(wire["prefix"],wire["word"])
            wire["uses"]+=1
            calls.append(key)
        bundles.append(dict(start=frame["start"],width=frame["width"],sources=sources,proof=proof,calls=calls))
    return wires,bundles


def main():
    if not __debug__:
        raise RuntimeError("Wang replay requires assertions")
    g=Turtle(json.loads((ROOT/"input/exact-point-model-v1.json").read_text()))
    audited=check(g,read("data/search-v1.json"))
    assert frozen(audited)==read("data/convex-audit-v1.json")
    wires,bundles=prepare(audited)
    build="--build" in sys.argv
    bank_path=DATA/"convex-bank-v1.json.gz"
    bank=build_bank(wires) if build else json.loads(gzip.decompress(bank_path.read_bytes()))
    out=dict(wedges=len(bundles),records=sum(len(r["proof"]) for r in bundles),**verify_bank(wires,bank))
    for path,value,compressed in ((bank_path,bank,True),(DATA/"convex-proof-v1.json",bundles,False),
                                  (DATA/"convex-receipt-v1.json",out,False)):
        body=encoded(value)+b"\n"
        if build:
            path.write_bytes(gzip.compress(body,mtime=0) if compressed else body)
        else:
            raw=path.read_bytes()
            assert (gzip.decompress(raw) if compressed else raw)==body
    print(json.dumps(out,sort_keys=True))


if __name__=="__main__":
    main()
