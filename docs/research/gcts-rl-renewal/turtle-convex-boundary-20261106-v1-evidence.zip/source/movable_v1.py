"""Extract independently checked inner and outer movable boundaries from the Turtle atlas."""
import json
from itertools import combinations
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from convex_audit_v1 import det, read
from geometry_v1 import Turtle, pairs
from window_v1 import Hierarchy, Audit, audit_window, rectangle, squared_norm


def calculate():
    model = json.loads((ROOT/"input/exact-point-model-v1.json").read_text())
    g = Turtle(model)
    rule = read("input/coordinate-v1.json")["rule"]
    alphabet = read("input/recovered-production-v1.json")["alphabet"]
    assert read("input/bridge-v1.json")["status"] == "CHECKED_COEFFICIENTWISE_GOLDEN_HEX_CONJUGACY"
    assert read("input/plane-replay-v1.json")["nested_odd_levels"]
    atlas = Hierarchy(g.model, rule, alphabet)
    audit = Audit(g.model)
    base = g.poly((0,0,0))
    distance, pair = max((squared_norm((a[0]-b[0],a[1]-b[1])), (a,b)) for a,b in combinations(base,2))
    records = []
    for name, ring in (
        ("area-compatible parallelogram", rectangle(-4,-5,8,10)),
        ("larger requested window", rectangle(-16,-12,32,24)),
        ("distant requested window", rectangle(10**6,-10**6,32,24)),
    ):
        outer, receipt = atlas.query(ring)
        deeper, _ = atlas.query(ring, receipt["level"]+2)
        assert outer == deeper
        checked = audit_window(audit, ring, outer)
        inner = tuple(t for t in outer if all(det(a,b,p)>=0 for a,b in pairs(ring) for p in g.poly(t)))
        inside_area = len(inner)*g.tile_area
        assert checked["window_double_area"] >= inside_area
        assert checked["excess_double_area"] > 0
        records.append(dict(name=name, ring=ring, outer=outer, inner=inner, query=receipt, **checked,
                            inner_deficit_double_area=checked["window_double_area"]-inside_area))
    return dict(diameter_squared=distance, pair=pair, windows=records)


def main():
    if not __debug__:
        raise RuntimeError("Window replay requires assertions")
    rows=calculate()
    body=json.dumps(rows,sort_keys=True,separators=(",",":"))+"\n"
    path=ROOT/"data/movable-v1.json"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text()==body
    print("Diameter squared",rows["diameter_squared"])
    for r in rows["windows"]:
        print(r["name"],len(r["inner"]),len(r["outer"]),r["query"]["root_tiles"],r["query"]["counts"]["visited"])


if __name__=="__main__":
    main()
