"""Search for finite obstructions to convex Turtle regions on the A2 lattice."""
from collections import Counter, defaultdict
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import mat
from geometry_v1 import Turtle, pairs


RAYS = ((1,0),(1,1),(0,1),(-1,2),(-1,1),(-2,1),
        (-1,0),(-1,-1),(0,-1),(1,-2),(1,-1),(2,-1))
ZERO = (0, 0)


def cross(a, b):
    return a[0]*b[1]-a[1]*b[0]


def sub(a, b):
    return a[0]-b[0], a[1]-b[1]


def hull(vertices):
    order = sorted(set(vertices))
    if len(order) < 3:
        return tuple(order)

    def side(points):
        out = []
        for p in points:
            while len(out) > 1 and cross(sub(out[-1], out[-2]), sub(p, out[-1])) <= 0:
                out.pop()
            out.append(p)
        return out[:-1]

    return tuple(side(order)+side(reversed(order)))


def wedge_turn(start, width, matrix):
    u, v = RAYS[start], RAYS[(start+width) % 12]
    a, b = mat(matrix, u), mat(matrix, v)
    if cross(a, b) < 0:
        a, b = b, a
    i, j = RAYS.index(a), RAYS.index(b)
    return i, (j-i) % 12


def wedges(g):
    return sorted({min(wedge_turn(start, width, matrix) for matrix in g.model.groups.values())
                   for start in range(12) for width in range(1, 6)})


class Search:
    def __init__(self, g, start, width, budget=250, depth=7, probes=36):
        self.g = g
        self.u, self.v = RAYS[start], RAYS[(start+width) % 12]
        self.scale = g.model.scale
        self.budget, self.depth, self.probes = budget, depth, probes
        self.stats = Counter()
        self.atoms = defaultdict(list)
        self.first = {}
        self.second = {}
        for k in g.turns:
            vertices = g.poly((k, 0, 0))
            self.first[k] = min(cross(self.u, p) for p in vertices)
            self.second[k] = min(cross(p, self.v) for p in vertices)
            for a, b in g.model.atoms[k]:
                self.atoms[a % self.scale, b % self.scale].append((k,a,b))

    def contains(self, tile):
        k, x, y = tile
        return (cross(self.u, (x,y)) + self.first[k] >= 0 and
                cross((x,y), self.v) + self.second[k] >= 0)

    def roots(self):
        result = set()
        for k in self.g.turns:
            for a, b in self.g.poly((k, 0, 0)):
                tile = (k, -a, -b)
                if self.contains(tile):
                    result.add(tile)
        return sorted(result)

    @lru_cache(maxsize=16000)
    def offers(self, q):
        a, b = q
        scale = self.scale
        alignments = self.atoms[a % scale, b % scale]
        assert len(alignments) == 240
        return tuple(t for k, x, y in alignments
                     if self.contains(t := (k, (a-x)//scale, (b-y)//scale)))

    def queries(self, patch, occupied):
        outer = hull(p for t in patch for p in self.g.poly(t))
        x, y = zip(*outer, strict=True)
        s = self.scale
        fence = [((s*a[0], s*a[1]), sub(b, a)) for a,b in pairs(outer)]
        probes = []
        for i, j in product(range(min(x), max(x)), range(min(y), max(y))):
            for a, b in self.g.model.residues:
                q = (s*i+a, s*j+b)
                if q not in occupied and all(cross(d, sub(q, p)) > 0 for p,d in fence):
                    probes.append(q)
        return sorted(probes, key=lambda p: (p[0]**2+p[0]*p[1]+p[1]**2,p))

    def visit(self, patch, occupied, depth):
        self.stats["nodes"] += 1
        if self.stats["nodes"] > self.budget:
            return None
        probes = self.queries(patch, occupied)
        if not probes:
            self.stats["closed_hull"] += 1
            return None
        best = None
        for q in probes[:self.probes]:
            self.stats["probes"] += 1
            moves = tuple(t for t in self.offers(q) if occupied.isdisjoint(self.g.sites(t)))
            if not moves:
                return dict(q=q, children=[])
            if best is None or len(moves) < len(best[1]):
                best = q, moves
        if depth >= self.depth:
            return None
        q, moves = best
        children = []
        for tile in moves:
            child = self.visit((*patch, tile), occupied | self.g.sites(tile), depth+1)
            if child is None:
                return None
            children.append((tile, child))
        return dict(q=q, children=children)

    def run(self):
        rows = []
        for t in self.roots():
            self.stats = Counter()
            proof = self.visit((t,), self.g.sites(t), 0)
            rows.append(dict(tile=t, proof=proof, work=dict(self.stats)))
        return rows


def main():
    g = Turtle(json.loads((ROOT / "input/exact-point-model-v1.json").read_text()))
    rows = []
    for start, width in wedges(g):
        a = Search(g, start, width)
        result = a.run()
        a.offers.cache_clear()
        print(start,width,len(result),sum(r["proof"] is not None for r in result),
              sum(r["work"].get("nodes",0) for r in result), flush=True)
        rows.append(dict(start=start,width=width,roots=result))
    data = json.dumps(rows, sort_keys=True,separators=(",",":"))+"\n"
    path = ROOT / "data/search-v1.json"
    if "--build" in sys.argv:
        path.write_text(data)
    else:
        assert path.read_text()==data


if __name__ == "__main__":
    main()
