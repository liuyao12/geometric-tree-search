The turtle needs a nonconvex boundary

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/convex_search_v1.py
  python3 -I -S -B source/convex_audit_v1.py
  python3 -I -S -B source/convex_wang_v1.py
  python3 -I -S -B source/movable_v1.py
  python3 -I -S -B publication/render_v1.py

These commands repeat the hull search, independently check the polygon
domains, replay the Wang certificates, and audit the movable covers using
the included coordinate rule. Add --build to a source command to regenerate
its data. The last command regenerates the HTML notebook.
The manifest gives SHA-256 for each included input and result.
