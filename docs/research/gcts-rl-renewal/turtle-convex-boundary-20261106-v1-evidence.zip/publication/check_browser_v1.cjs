const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/turtle-convex-boundary-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#movable mjx-container").first().waitFor();
      assert.equal(await page.locator("#fixed .probe").count(), 2);
      assert.equal(await page.locator("#fixed tbody tr").count(), 7);
      assert.equal(await page.locator("#window-view .outer").count(), 10);
      await page.locator("#request").selectOption("2");
      assert.equal(await page.locator("#window-view .inner").count(), 22);
      assert.equal(await page.locator("#window-view .outer").count(), 31);
      await page.locator("#inner-only").check();
      assert.equal(await page.locator("#window-view .outer:visible").count(), 0);
      assert.equal(await page.locator("#wang use").count(), 45);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      await page.locator("#inner-only").uncheck();
      await page.locator("#window-view").screenshot({ path: "publication/boundary-" + width + ".png" });
      console.log("Verified", width, "px, hull examples, movable covers and Wang squares.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
