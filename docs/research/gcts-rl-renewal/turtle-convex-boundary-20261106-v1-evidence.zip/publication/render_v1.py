"""Render the fixed-boundary obstruction, movable covers and Wang replay."""
import gzip
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/p) for p in ("publication","source","wang/source")]
from boundary_kernel_v1 import build
from convex_audit_v1 import Turtle, read
from convex_search_v1 import RAYS, hull
from proof_views_v1 import frame_window, tile_svg

NAME="turtle-convex-boundary-20261106-v1"
TITLE="The turtle needs a nonconvex boundary"


def points(poly):
    return " ".join(f"{x+y/2:.4f},{-sqrt(3)*y/2:.4f}" for x,y in poly)


def svg(polys,label,marked=None):
    vertices=[(x+y/2,-sqrt(3)*y/2) for _,p in polys for x,y in p]
    a,b=zip(*vertices,strict=True)
    span=max(max(a)-min(a),max(b)-min(b))
    pad=max(1,span*.05)
    box=(min(a)-pad,min(b)-pad,max(a)-min(a)+2*pad,max(b)-min(b)+2*pad)
    layers="".join(f'<polygon class="{kind}" points="{points(poly)}"/>' for kind,poly in polys)
    if marked is not None:
        x,y=marked
        layers+=f'<circle class="probe" cx="{x+y/2:.4f}" cy="{-sqrt(3)*y/2:.4f}" r=".16"/>'
    return (f'<svg role="img" aria-label="{escape(label)}" viewBox="{" ".join(map(str,box))}">'
            f'{layers}</svg>')


def tile_window():
    proof=json.loads((ROOT/"wang/data/convex-proof-v1.json").read_text())
    bank=json.loads(gzip.decompress((ROOT/"wang/data/convex-bank-v1.json.gz").read_bytes()))
    machine=build().compile()
    assert machine.digest()==bank["machine"]
    chosen=next(r for r in proof if r["start"]==0 and r["width"]==5)
    assert not chosen["proof"][-1]["clause"]
    e=bank["traces"][chosen["calls"][-1]]
    end=e["steps"]
    trace=dict(prefix=e["prefix"],word=e["word"],padding=0,trace=e["fragment"])
    rows,col=frame_window(machine,trace,end-5,e["head"])
    seen,uses={},[]
    for y,row in enumerate(rows):
        for x,t in enumerate(row):
            i=seen.setdefault(t,len(seen))
            uses.append(f'<use href="#wang-{i}" x="{36*x}" y="{36*y}"/>')
    defs="".join(tile_svg(t,i) for t,i in seen.items())
    return (f'<figure><svg role="img" aria-label="45 Wang squares from the last resolution" viewBox="0 0 324 180">'
            f'<defs>{defs}</defs>{"".join(uses)}</svg><figcaption>Verifier rows {end-4:,} to {end:,}, '
            f'tape columns {col:,} to {col+8:,}. Point to a square for its exact edge labels.</figcaption></figure>')


def main():
    g=Turtle(json.loads((ROOT/"input/exact-point-model-v1.json").read_text()))
    audit=read("data/convex-audit-v1.json")
    stage=read("data/movable-v1.json")
    steps=[r for f in audit["frames"] for r in f["checked"] if r["children"] or len(r["patch"])>1]
    assert len(steps)==2
    diagrams=[]
    for i,r in enumerate(steps):
        polys=[("placed" if j==0 else "forced",g.poly(t)) for j,t in enumerate(r["patch"])]
        shell=hull(p for _,poly in polys for p in poly)
        polys.append(("hull",shell))
        q=tuple(x/g.model.scale for x in r["q"])
        caption=("The hull forces the red point. Exactly one tile can cover it."
                 if i==0 else "That tile forces a second red point. Every possible covering tile is blocked.")
        diagrams.append(f'<figure>{svg(polys,caption,q)}<figcaption>{caption}</figcaption></figure>')
    frames="".join(f'<tr><th scope="row">\\({f["start"]*30}^\\circ\\)</th><td>\\({f["width"]*30}^\\circ\\)</td>'
                   f'<td>{f["root_count"]}</td><td>{len(f["checked"])}</td></tr>' for f in audit["frames"])
    samples,options,stats=[],[],[]
    for i,r in enumerate(stage["windows"]):
        x,y=r["ring"][0]
        relative=lambda p: tuple((a-x,b-y) for a,b in p)
        inside=set(r["inner"])
        polys=[("inner" if t in inside else "outer",relative(g.poly(t))) for t in r["outer"]]
        polys.append(("request",relative(r["ring"])))
        label=r["name"].capitalize()
        options.append(f'<option value="{i}">{escape(label)}</option>')
        samples.append(f'<template id="window-{i}"><figure>{svg(polys,label)}'
                       f'<figcaption>{len(r["inner"])} interior tiles and {len(r["outer"])} tiles in the outer cover.</figcaption>'
                       f'</figure></template>')
        stats.append(f'<tr><th scope="row">{escape(label)}</th><td>{len(r["outer"])}</td>'
                     f'<td>{r["query"]["root_tiles"]:,}</td><td>{r["query"]["counts"]["visited"]:,}</td></tr>')
    vals=dict(title=TITLE,stem=NAME,frames=frames,diagrams="".join(diagrams),options="".join(options),
              windows="".join(samples),stats="".join(stats),squares=tile_window())
    head=(ROOT/"publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs",TITLE)
    body=(ROOT/"publication/convex-body-v1.html").read_text()
    for k,v in vals.items():
        body=body.replace("%%"+k.upper()+"%%",v)
    assert "%%" not in body
    (ROOT/"report"/(NAME+".html")).write_text(head+body)


if __name__=="__main__":
    main()
