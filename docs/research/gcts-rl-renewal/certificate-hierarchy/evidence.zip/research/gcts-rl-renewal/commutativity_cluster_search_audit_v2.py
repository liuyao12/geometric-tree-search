"""Versioned read-only interning consumer for the same frozen full graph traces."""
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from commutativity_cluster_audit import tree, families, model_binding, need, same

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


from commutativity_cluster_intern import load

def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'search-audit-plan.json').read_text())
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h, 'independent whole-tree freeze ' + p)
    gate = json.loads((OUT / 'preflight-audit.json').read_text())
    need(gate['status'] == 'passed_complete_graph_family_and_focused_conformance_preflight', 'full independent preflight')
    execution = json.loads((OUT / 'execution-freeze.json').read_text())
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    declared = families(catalog)
    result = dict(status='checking_complete_four_graph_traces', observations=[], target_native_queries=0)
    initial = None
    for observed in execution['observations']:
        need(time.perf_counter() - began < 300, 'unknown_independent_tree_audit_time_budget')
        model = load(OUT / (observed['id'] + '-model.json.gz'))
        raw = load(OUT / (observed['id'] + '-search.json.gz'))
        need(model['case'] == raw['case'] and raw['observation'] == observed, 'exact order-balanced observation')
        model_binding(raw['case'], catalog, model['model'])
        if initial is None:
            initial = (model['model']['placements'], model['model']['roots'], model['model']['initial_marks'])
        else:
            need(same(initial, (model['model']['placements'], model['model']['roots'], model['model']['initial_marks'])), 'identical complete language/boundary in every fresh model')
        metric = tree(raw['case'], model['model'], raw['search'], declared)
        result['observations'].append(dict(id=observed['id'], **metric))
        result['seconds'] = time.perf_counter() - began
        (OUT / 'search-audit.json').write_text(json.dumps(result, indent=2) + '\n')
        print('INDEPENDENT GRAPH TRACE ' + json.dumps(result['observations'][-1]), flush=True)
    result.update(status='passed_complete_four_search_graph_and_proposal_traces',
                  seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Every independently rebuilt placement, full graph census/decision, exact fixed proposal pool/work/features/choice, hint continuation, complete fallback, rollback and decoded word. No whole native target acceptance or RL claim.')
    (OUT / 'search-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
