"""Read-only JSON decoder interning repeated integer placement-key arrays.

Only list-to-tuple representation and object sharing change. Mathematical JSON
values, order, source/target formulas and the original compressed bytes persist.
No producer source or trace is rewritten.
"""
import gzip
import json


def load(path):
    keys = {}
    points = {}

    def key(value):
        if not isinstance(value, list) or len(value) != 4 or any(type(x) is not int for x in value):
            raise ValueError('explicit integer placement key')
        t = tuple(value)
        return keys.setdefault(t, t)

    def point(value):
        if value is None:
            return None
        if not isinstance(value, list) or len(value) != 2 or any(type(x) is not int for x in value):
            raise ValueError('explicit integer point')
        t = tuple(value)
        return points.setdefault(t, t)

    def object_hook(value):
        if 'key' in value and isinstance(value['key'], list):
            value['key'] = key(value['key'])
        for name in ('keys', 'members', 'pending', 'eligible', 'illegal', 'chosen', 'placements', 'alternatives'):
            if name in value and isinstance(value[name], list):
                value[name] = [key(v) for v in value[name]]
        if 'point' in value:
            value['point'] = point(value['point'])
        return value

    with gzip.open(path, 'rt') as source:
        return json.load(source, object_hook=object_hook)
