"""Independent full fixed point and deterministic ordinary word reconstruction."""
import collections
import copy
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from audit_certificate_boundary import pin
from audit_semantic_proofs import whole_replay

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'forward-audit-plan.json').read_text())
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h, 'ordinary audit freeze ' + p)
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    producer = load(OUT / 'forward.json.gz')
    ids = {pin(f): i for i, f in enumerate(catalog['basis'])}
    edges = [dict(rule=i, inputs=[ids[pin(p)] for p in r['premises']], output=ids[pin(r['conclusion'])]) for i, r in enumerate(catalog['rules'])]
    witness, layers, scans = {}, [], 0
    while True:
        additions = {}
        for edge in edges:
            scans += 1
            if edge['output'] not in witness and all(source in witness for source in edge['inputs']):
                additions.setdefault(edge['output'], edge['rule'])
        if not additions:
            break
        layers.append(sorted(additions))
        for f, rule in additions.items():
            witness[f] = dict(rule=rule, rank=len(layers) - 1)
    expected = dict(edges=edges, layers=layers, witnesses=[witness.get(i) for i in range(len(catalog['basis']))],
                    edge_scans=scans, fixed_point_reachable=len(witness), rounds=len(layers))
    need(expected == producer['closure'], 'all hyperedges and complete least fixed point')
    goal = ids[pin(json.loads((OUT / 'plan.json').read_text())['case']['target'])]
    rows, selected, sources = [], [], {}

    def derive(f):
        if f in sources:
            return sources[f]
        need(f in witness, 'reachable ordinary source')
        i = witness[f]['rule']
        inference = catalog['rules'][i]
        refs = [derive(ids[pin(p)]) for p in inference['premises']]
        command = copy.deepcopy(inference['command'])
        if command['rule'] == 'block':
            command['inputs'] = refs
        elif command['rule'] == 'generalize':
            need(len(refs) == 1, 'generic unary generalization')
            command['source'] = refs[0]
        else:
            need(not refs, 'primitive zero-input root')
        index = len(rows)
        sources[f] = index
        rows.append(command)
        selected.append(dict(row=index, formula=f, rule=i, sources=refs))
        return index

    if goal in witness:
        derive(goal)
        need(rows == producer['proof'] and selected == producer['selected_witnesses'], 'entire automatically reconstructed ordered word')
        need(all(source < q['row'] for q in selected for source in q['sources']), 'strict-prior word')
        request = producer['original_request']
        need(request['proof'] == rows and request['theory'] == catalog['spec']['theory'] and request['target'] == catalog['spec']['target'], 'unchanged original theory/target')
        definitions = {d['name']: d for d in catalog['definitions']}
        wanted = {c['name'] for c in rows if c['rule'] == 'block'}
        pending = list(wanted)
        while pending:
            for c in definitions[pending.pop()]['proof']:
                if c['rule'] == 'block' and c['name'] not in wanted:
                    pending.append(c['name'])
                    wanted.add(c['name'])
        need(request['blocks'] == [d for d in catalog['definitions'] if d['name'] in wanted], 'exact generic transitive definition closure')
        need(whole_replay(request)['status'] == 'accepted', 'independent host whole certificate cross-check only')
    else:
        need(producer['proof'] is None and producer['original_request'] is None, 'no proof for unreached goal')
    need(producer['same_12_row_boundary_fits'] == (goal in witness and len(rows) <= 12), 'actual comparison boundary')
    result = dict(status='passed_full_ordinary_closure_and_word_reconstruction', reachable_formulas=len(witness),
                  rounds=len(layers), edge_scans=scans, word_length=None if goal not in witness else len(rows),
                  same_12_row_boundary_fits=goal in witness and len(rows) <= 12,
                  native_target_queries=0, seconds=time.perf_counter() - began,
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Independent full admitted hyperedge fixed point, deterministic witnesses and complete ordered ordinary DAG/word, original theory/target and transitive used definitions. Host replay is a cross-check only; native whole checking remains pending. Not GCTS/RL discovery.')
    if result['seconds'] > 60 or result['peak_rss_bytes'] > 536870912:
        result['status'] = 'unknown_ordinary_audit_resource_budget'
    (OUT / 'forward-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
