"""Freshly bound reuse of individually resolved exact-value components.

The combined historical comparison remains time-unknown. This new receipt only
reconciles its already complete, separately bounded components; no historical
outcome or cost is changed and no original trace is rewritten.
"""
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from commutativity_cluster_intern_v3 import load

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'


def need(value, message):
    if not value:
        raise ValueError(message)


def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'decoder-reconciliation-plan.json').read_text())
    for path, expected in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, 'fresh exact historical-component pin ' + path)
    combined = json.loads((OUT / 'decoder-receipt-v3.json').read_text())
    need(combined['status'] == 'unknown_decoder_correspondence_resource_budget' and combined['seconds'] > 300, 'historical combined wall unknown remains unchanged')
    components = [json.loads((OUT / ('decoder-v3-' + mode + '.json')).read_text()) for mode in ('original-intern', 'stream-intern')]
    need(components == combined['observations'], 'exact original component checkpoints')
    for mode, component in zip(('original-intern', 'stream-intern'), components):
        need(component['mode'] == mode and component['status'] == 'resolved_exact_full_value_digest', 'individual resolved component')
        need(component['seconds'] <= 180 and component['peak_rss_bytes'] <= 536870912 and component['wall_overshoot_seconds'] == component['memory_overshoot_bytes'] == 0, 'unchanged individual resource gate')
    need(components[0]['canonical_sha256'] == components[1]['canonical_sha256'] == plan['canonical_sha256'], 'whole first trace complete canonical JSON value')
    need(components[0]['canonical_bytes'] == components[1]['canonical_bytes'] == 115950444, 'whole first trace complete canonical byte count')
    need(all(combined[name] for name in ('complete_first_trace_equal', 'fixture_equal', 'chunk_quoted_string_equal', 'reserved_prefix_rejected')), 'every earlier decoder fixture resolved')
    fixture = OUT / 'preflight-fixtures.json.gz'
    canonical = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
    need(canonical(load(fixture)) == canonical(json.loads(gzip.decompress(fixture.read_bytes()))), 'fresh complete small fixture value equality')
    earlier = json.loads((OUT / 'search-audit.json').read_text())
    need(earlier['status'] == 'unknown_complete_tree_audit_resource_budget', 'failed original memory gate preserved')
    result = dict(status='passed_fresh_exact_historical_component_reconciliation',
                  canonical_sha256=plan['canonical_sha256'], canonical_bytes=115950444,
                  components=components, historical_combined_status=combined['status'],
                  historical_combined_seconds=combined['seconds'], historical_combined_wall_overshoot_seconds=combined['seconds'] - 300,
                  earlier_failed_full_audit_seconds=earlier['seconds'], earlier_failed_full_audit_peak_rss_bytes=earlier['peak_rss_bytes'],
                  original_four_trace_bytes_unchanged=True, native_target_queries=0, target_searches=0,
                  seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Fresh hash binding and correspondence of two individually complete historical whole-value components. Combined time-unknown is preserved and fully charged; this receipt is a new reuse gate, not a passing historical batch or a full graph audit. Unchanged full v5 four-tree audit remains mandatory.')
    if result['seconds'] > 60 or result['peak_rss_bytes'] > 536870912:
        result['status'] = 'unknown_decoder_reconciliation_resource_budget'
    (OUT / 'decoder-reconciliation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
