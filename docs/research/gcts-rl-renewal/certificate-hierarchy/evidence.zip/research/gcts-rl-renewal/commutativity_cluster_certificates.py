"""Checkpoint first candidate per algorithm and generic whole compaction only."""
import copy
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from induction_receptors_closure import expand
from induction_receptors_compaction import formula_dag
from audit_semantic_proofs import whole_replay
from audit_certificate_boundary import pin

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def main():
    began = time.perf_counter()
    freeze = json.loads((OUT / 'certificate-plan.json').read_text())
    for p, h in {**freeze['source_sha256'], **freeze['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('whole transformation freeze ' + p)
    plan = json.loads((OUT / 'plan.json').read_text())
    case = plan['case']
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    definitions = {d['name']: d for d in catalog['definitions']}
    observed = json.loads((OUT / 'execution-freeze.json').read_text())['observations']
    audited = json.loads((OUT / 'search-audit-v5.json').read_text())
    if audited['status'] != 'passed_complete_four_search_graph_and_proposal_traces':
        raise ValueError('complete independent four-tree gate')
    authority = {item['id']: item for item in audited['observations']}
    selected = {}
    for observation in observed:
        summary = json.loads((OUT / (observation['id'] + '-summary.json')).read_text())
        status = authority[observation['id']]['status']
        if status != summary['status']:
            raise ValueError('audited whole-tree/summary status correspondence')
        if status != 'finite_marked_proof_region':
            if summary['proof_rows'] is not None or summary['word_sha256'] is not None:
                raise ValueError('independently audited no-proof trace')
            continue
        from commutativity_cluster_intern_v3 import load as trace
        raw = trace(OUT / (observation['id'] + '-search.json.gz'))
        lane = 'base' if observation['mode'] == 'base' else 'fixed-cluster'
        if raw['search']['proof'] is not None and lane not in selected:
            selected[lane] = dict(source=observation['id'], proof=raw['search']['proof'])
    ordinary = load(OUT / 'forward.json.gz')
    if ordinary['proof'] is not None:
        selected['ordinary-forward'] = dict(source='forward', proof=ordinary['proof'])
    requests = []
    for lane, candidate in selected.items():
        stage = time.perf_counter()
        wanted = {c['name'] for c in candidate['proof'] if c['rule'] == 'block'}
        pending = list(wanted)
        while pending:
            for command in definitions[pending.pop()]['proof']:
                if command['rule'] == 'block' and command['name'] not in wanted:
                    wanted.add(command['name'])
                    pending.append(command['name'])
        original = dict(protocol='gcts-fol-1', theory=copy.deepcopy(case['theory']),
                        blocks=[copy.deepcopy(d) for d in catalog['definitions'] if d['name'] in wanted],
                        proof=copy.deepcopy(candidate['proof']), target=copy.deepcopy(case['target']))
        full = expand(original)
        compact = copy.deepcopy(original)
        compact.update(blocks=[], proof=formula_dag(full))
        if whole_replay(original)['status'] != 'accepted' or whole_replay(compact)['status'] != 'accepted':
            raise ValueError('whole host replay cross-check')
        requests.append(dict(lane=lane, source=candidate['source'], original_request=original,
                             original_request_sha256=pin(original), expanded_proof=full,
                             compact_request=compact, compact_request_sha256=pin(compact),
                             original_rows=len(original['proof']), expanded_commands=len(full),
                             compact_commands=len(compact['proof']), seconds=time.perf_counter() - stage))
    value = dict(status='complete_generic_whole_compaction_pending_independent_audit', candidates=requests,
                 native_target_queries=0, seconds=time.perf_counter() - began,
                 peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                 scope='First automatically found candidate per base/fixed/ordinary lane, no supplied target derivation. Generic dependency slicing/expansion/context-safe DAG sharing, unchanged theory/target; host replay cross-check only. Native whole proof and capacity gates remain pending.')
    with gzip.open(OUT / 'certificates.json.gz', 'wt') as f:
        json.dump(value, f, separators=(',', ':'))
    print(json.dumps(dict(status=value['status'], candidates=[{k: c[k] for k in ('lane', 'source', 'original_rows', 'expanded_commands', 'compact_commands')} for c in requests], seconds=value['seconds'])), flush=True)


if __name__ == '__main__':
    main()
