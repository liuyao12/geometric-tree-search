"""Versioned read-only interning consumer for the same frozen full graph traces."""
import gc
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from commutativity_cluster_audit import tree, families, model_binding, need, same

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


from commutativity_cluster_intern_v3 import load

def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'search-audit-plan-v5.json').read_text())
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h, 'independent whole-tree freeze ' + p)
    gate = json.loads((OUT / 'preflight-audit.json').read_text())
    need(gate['status'] == 'passed_complete_graph_family_and_focused_conformance_preflight', 'full independent preflight')
    execution = json.loads((OUT / 'execution-freeze.json').read_text())
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    declared = families(catalog)
    result = dict(status='checking_complete_four_graph_traces', observations=[], target_native_queries=0)
    def within_budget():
        elapsed = time.perf_counter() - began
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if elapsed <= 300 and peak <= 536870912:
            return True
        result.update(status='unknown_complete_tree_audit_resource_budget', seconds=elapsed,
                      peak_rss_bytes=peak, wall_overshoot_seconds=max(0, elapsed - 300),
                      memory_overshoot_bytes=max(0, peak - 536870912),
                      scope='Full completed observations preserved; no full four-tree audit or target proof authority from an incomplete resource-limited audit.')
        (OUT / 'search-audit-v5.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
        return False

    initial = None
    for observed in execution['observations']:
        if not within_budget():
            return
        model = load(OUT / (observed['id'] + '-model.json.gz'))
        raw = load(OUT / (observed['id'] + '-search.json.gz'))
        need(model['case'] == raw['case'] and raw['observation'] == observed, 'exact order-balanced observation')
        model_binding(raw['case'], catalog, model['model'])
        if initial is None:
            initial = hashlib.sha256(json.dumps((model['model']['placements'], model['model']['roots'], model['model']['initial_marks']), sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        else:
            need(initial == hashlib.sha256(json.dumps((model['model']['placements'], model['model']['roots'], model['model']['initial_marks']), sort_keys=True, separators=(',', ':')).encode()).hexdigest(), 'identical completely reconstructed language/boundary in every fresh model')
        if not within_budget():
            return
        metric = tree(raw['case'], model['model'], raw['search'], declared)
        result['observations'].append(dict(id=observed['id'], **metric))
        result['seconds'] = time.perf_counter() - began
        (OUT / 'search-audit-v5.json').write_text(json.dumps(result, indent=2) + '\n')
        print('INDEPENDENT GRAPH TRACE ' + json.dumps(result['observations'][-1]), flush=True)
        del model, raw
        gc.collect()
        if not within_budget():
            return
    result.update(status='passed_complete_four_search_graph_and_proposal_traces',
                  seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Every independently rebuilt placement, full graph census/decision, exact fixed proposal pool/work/features/choice, hint continuation, complete fallback, rollback and decoded word. No whole native target acceptance or RL claim.')
    (OUT / 'search-audit-v5.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
