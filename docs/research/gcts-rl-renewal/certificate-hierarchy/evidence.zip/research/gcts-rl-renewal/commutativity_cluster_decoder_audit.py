"""Bounded exact whole JSON-value correspondence for audit-only interning."""
import argparse
import gzip
import hashlib
import json
import resource
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'


def digest(value):
    h, buffered, size, total = hashlib.sha256(), [], 0, 0
    for part in json.JSONEncoder(sort_keys=True, separators=(',', ':'), ensure_ascii=False).iterencode(value):
        buffered.append(part)
        size += len(part)
        if size >= 65536:
            raw = ''.join(buffered).encode()
            h.update(raw)
            total += len(raw)
            buffered, size = [], 0
    raw = ''.join(buffered).encode()
    h.update(raw)
    return h.hexdigest(), total + len(raw)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('original-intern', 'stream-intern'))
    args = parser.parse_args()
    plan = json.loads((OUT / 'decoder-plan-v3.json').read_text())
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('frozen decoder-value correspondence ' + p)
    if args.mode:
        began = time.perf_counter()
        if args.mode == 'original-intern':
            from commutativity_cluster_intern_v2 import load
        else:
            from commutativity_cluster_intern_v3 import load
        value = load(OUT / 'base-r1-search.json.gz')
        h, length = digest(value)
        elapsed = time.perf_counter() - began
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        result = dict(mode=args.mode, canonical_sha256=h, canonical_bytes=length, seconds=elapsed,
                      peak_rss_bytes=peak, wall_overshoot_seconds=max(0, elapsed - 180),
                      memory_overshoot_bytes=max(0, peak - 536870912))
        result['status'] = 'resolved_exact_full_value_digest' if not result['wall_overshoot_seconds'] and not result['memory_overshoot_bytes'] else 'unknown_decoder_value_resource_budget'
        (OUT / ('decoder-v3-' + args.mode + '.json')).write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)
        return
    began = time.perf_counter()
    results = []
    for mode in ('original-intern', 'stream-intern'):
        if time.perf_counter() - began >= 300:
            raise ValueError('unknown_decoder_correspondence_batch_time_budget')
        subprocess.run([sys.executable, str(Path(__file__)), '--mode', mode], check=True)
        result = json.loads((OUT / ('decoder-v3-' + mode + '.json')).read_text())
        results.append(result)
        if result['status'] != 'resolved_exact_full_value_digest':
            break
    complete = len(results) == 2 and all(x['status'] == 'resolved_exact_full_value_digest' for x in results)
    equal = complete and results[0]['canonical_sha256'] == results[1]['canonical_sha256'] and results[0]['canonical_bytes'] == results[1]['canonical_bytes']
    from commutativity_cluster_intern_v3 import load
    fixture = OUT / 'preflight-fixtures.json.gz'
    value = load(fixture)
    literal = json.loads(gzip.decompress(fixture.read_bytes()))
    fixture_equal = digest(value) == digest(literal)
    # Quoted numeric text and escaped quote/chunk boundary fixtures must stay
    # unchanged; the reserved prefix collision must fail closed.
    text = dict(text='A' * 65532 + '\\"[1,2,3,4]', key=[1, 2, 3, 4], nested=[[5, 6, 7, 8], 'literal[9,10,11,12]'])
    with tempfile.NamedTemporaryFile(suffix='.gz', dir=OUT) as f:
        f.write(gzip.compress(json.dumps(text).encode())); f.flush()
        chunk_equal = digest(load(Path(f.name))) == digest(text)
        f.seek(0); f.truncate(); f.write(gzip.compress(json.dumps(dict(text='#0')).encode())); f.flush()
        try:
            load(Path(f.name))
        except ValueError:
            reserved_rejected = True
        else:
            reserved_rejected = False
    result = dict(status='passed_complete_full_json_value_correspondence_and_stream_decoder_fixtures' if equal and fixture_equal and chunk_equal and reserved_rejected else 'unknown_or_failed_stream_decoder_value_correspondence',
                  observations=results, complete_first_trace_equal=equal, fixture_equal=fixture_equal,
                  chunk_quoted_string_equal=chunk_equal, reserved_prefix_rejected=reserved_rejected,
                  seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  native_queries=0, target_searches=0,
                  scope='Complete canonical JSON-value SHA and byte-count correspondence on the original first 5001-node trace, primitive fixture, quoted/chunk-boundary strings and fail-closed prefix. Producer files and all original trace bytes remain unchanged; full graph correctness still needs fresh same-bound audit.')
    if result['seconds'] > 300 or result['peak_rss_bytes'] > 536870912:
        result['status'] = 'unknown_decoder_correspondence_resource_budget'
    (OUT / 'decoder-receipt-v3.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
