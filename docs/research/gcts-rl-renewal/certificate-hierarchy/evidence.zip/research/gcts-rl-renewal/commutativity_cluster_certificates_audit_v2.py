"""Independent candidate selection, full expansion and context-safe DAG sharing."""
import copy
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from induction_receptors_compaction_audit import expanded, shared
from audit_semantic_proofs import whole_replay
from audit_certificate_boundary import pin

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    began = time.perf_counter()
    freeze = json.loads((OUT / 'certificate-audit-plan-v2.json').read_text())
    for p, h in {**freeze['source_sha256'], **freeze['input_sha256']}.items():
        need(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h, 'independent whole-compaction freeze ' + p)
    plan = json.loads((OUT / 'plan.json').read_text())
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    observed = json.loads((OUT / 'execution-freeze.json').read_text())['observations']
    gate = json.loads((OUT / 'search-audit-v5.json').read_text())
    need(gate['status'] == 'passed_complete_four_search_graph_and_proposal_traces', 'complete independent four-tree gate')
    authority = {item['id']: item for item in gate['observations']}
    selected = {}
    # Import the read-only interning decoder, never producer search/policy.
    from commutativity_cluster_intern_v3 import load as trace
    for item in observed:
        summary = json.loads((OUT / (item['id'] + '-summary.json')).read_text())
        status = authority[item['id']]['status']
        need(status == summary['status'], 'audited whole-tree/summary status correspondence')
        if status != 'finite_marked_proof_region':
            need(summary['proof_rows'] is None and summary['word_sha256'] is None, 'independently audited no-proof trace')
            continue
        record = trace(OUT / (item['id'] + '-search.json.gz'))
        lane = 'base' if item['mode'] == 'base' else 'fixed-cluster'
        if record['search']['proof'] is not None and lane not in selected:
            selected[lane] = dict(source=item['id'], proof=record['search']['proof'])
        del record
    ordinary = load(OUT / 'forward.json.gz')
    if ordinary['proof'] is not None:
        selected['ordinary-forward'] = dict(source='forward', proof=ordinary['proof'])
    producer = load(OUT / 'certificates.json.gz')
    need([c['lane'] for c in producer['candidates']] == list(selected), 'exact first candidate per algorithm, no outcome-based proof choice')
    definitions = {d['name']: d for d in catalog['definitions']}
    results = []
    for candidate in producer['candidates']:
        chosen = selected[candidate['lane']]
        names = {c['name'] for c in chosen['proof'] if c['rule'] == 'block'}
        pending = list(names)
        while pending:
            for c in definitions[pending.pop()]['proof']:
                if c['rule'] == 'block' and c['name'] not in names:
                    names.add(c['name'])
                    pending.append(c['name'])
        original = dict(protocol='gcts-fol-1', theory=copy.deepcopy(plan['case']['theory']),
                        blocks=[copy.deepcopy(d) for d in catalog['definitions'] if d['name'] in names],
                        proof=chosen['proof'], target=copy.deepcopy(plan['case']['target']))
        need(original == candidate['original_request'] and chosen['source'] == candidate['source'], 'entire exact algorithm-produced request')
        full = expanded(original)
        primitive = dict(original, blocks=[], proof=shared(full))
        need(full == candidate['expanded_proof'] and primitive == candidate['compact_request'], 'all independently reconstructed generic transformation commands')
        need(pin(original) == candidate['original_request_sha256'] and pin(primitive) == candidate['compact_request_sha256'], 'whole request binding')
        need(whole_replay(original)['status'] == whole_replay(primitive)['status'] == 'accepted', 'independent host whole replay only')
        results.append(dict(lane=candidate['lane'], source=candidate['source'],
                            original_rows=len(original['proof']), expanded_commands=len(full), compact_commands=len(primitive['proof']),
                            original_request_sha256=pin(original), compact_request_sha256=pin(primitive),
                            exact_original_theory_and_target=True))
    result = dict(status='passed_independent_automatic_candidate_selection_and_generic_whole_compaction',
                  candidates=results, native_target_queries=0, seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Whole automatically selected first candidate per algorithm, transitive definition slicing, independent expansion/sharing, original theory/target and host cross-check. Not native whole proof acceptance; capacity/checker gates remain.')
    if result['seconds'] > 180 or result['peak_rss_bytes'] > 536870912:
        result['status'] = 'unknown_whole_compaction_audit_resource_budget'
    (OUT / 'certificate-audit-v2.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
