"""Post-GCTS ordinary full-hyperedge proof extraction, separately credited.

Only the unchanged generic synchronous closure/DAG reconstruction is reused.
No chosen induction variable or target proof path is supplied.
"""
import copy
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from left_successor_forward import closure, word

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def main():
    began = time.perf_counter()
    frozen = json.loads((OUT / 'forward-plan.json').read_text())
    for p, h in {**frozen['source_sha256'], **frozen['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('exact ordinary forward freeze ' + p)
    if json.loads((OUT / 'search-audit-v5.json').read_text())['status'] != 'passed_complete_four_search_graph_and_proposal_traces':
        raise ValueError('all four GCTS traces independently frozen before ordinary witness')
    plan = json.loads((OUT / 'plan.json').read_text())
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    registry = load(PARENT / 'native-complete/registry.json.gz')
    if {d['name']: d for d in catalog['definitions']} != {d['name']: d['definition'] for d in registry['definitions']}:
        raise ValueError('same full native-admitted grammar')
    closed = closure(catalog)
    proof, selected = word(catalog, closed, plan['case']['target'])
    request = None
    if proof is not None:
        wanted = {c['name'] for c in proof if c['rule'] == 'block'}
        definitions = {d['name']: d for d in catalog['definitions']}
        pending = list(wanted)
        while pending:
            for command in definitions[pending.pop()]['proof']:
                if command['rule'] == 'block' and command['name'] not in wanted:
                    wanted.add(command['name'])
                    pending.append(command['name'])
        request = dict(protocol='gcts-fol-1', theory=copy.deepcopy(plan['case']['theory']),
                       blocks=[copy.deepcopy(d) for d in catalog['definitions'] if d['name'] in wanted],
                       proof=proof, target=copy.deepcopy(plan['case']['target']))
    raw = dict(status='complete_ordinary_extraction_pending_independent_audit',
               closure=closed, proof=proof, selected_witnesses=selected, original_request=request,
               comparison_rows=12, word_length=None if proof is None else len(proof),
               same_12_row_boundary_fits=proof is not None and len(proof) <= 12,
               native_target_queries=0, algorithm='ordinary synchronous full-hyperedge forward chaining',
               seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               scope='Automatically extracted ordinary witness, not a GCTS/RL discovery or a whole native certificate. Every edge is scanned before generic query DAG reconstruction.')
    if raw['seconds'] > 60 or raw['peak_rss_bytes'] > 536870912:
        raw['status'] = 'unknown_ordinary_extraction_resource_budget'
    with gzip.open(OUT / 'forward.json.gz', 'wt') as f:
        json.dump(raw, f, separators=(',', ':'))
    metric = {k: v for k, v in raw.items() if k not in ('closure', 'proof', 'selected_witnesses', 'original_request')}
    (OUT / 'forward-summary.json').write_text(json.dumps(metric, indent=2) + '\n')
    print(json.dumps(metric), flush=True)


if __name__ == '__main__':
    main()
