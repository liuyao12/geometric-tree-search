"""Complete model/family preflight and isolated point-conformance fixtures."""
import copy
import gzip
import hashlib
import json
import resource
import time
from pathlib import Path
from commutativity_cluster_points import Model
from commutativity_cluster_guidance import row_requirements, vector, Join
from commutativity_cluster_search import search
from commutativity_catalog import motif_families
from commutativity_points import row_keys, aggregate
from induction_receptors_points import Model as PrimitiveFixtureModel
from certificate_boundary_search import canonical
from native_receptor_points import fingerprint
from turtle import Graph

ROOT = Path(__file__).resolve().parents[2]
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def save(path, value):
    with gzip.open(path, 'wt') as f:
        json.dump(value, f, separators=(',', ':'))


def frozen(plan):
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('frozen source/input ' + p)


def main():
    began = time.perf_counter()
    activation = json.loads((OUT / 'activation.json').read_text())
    frozen(activation)
    plan = json.loads((OUT / 'plan.json').read_text())
    c = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    reg_path = PARENT / 'native-complete/registry.json.gz'
    registry = load(reg_path)
    audit = json.loads((PARENT / 'native-complete/registry-audit.json').read_text())
    spec = copy.deepcopy(plan['case'])
    spec.update(length=12)
    model = Model(spec, c, registry, audit, reg_path.read_bytes())
    state = model.initial()
    graph = Graph(model, state)
    record = model.record()
    save(OUT / 'preflight-model.json.gz', dict(case=spec, model=record))
    families = motif_families(c)
    instances = []
    for family_id, family in enumerate(families):
        for row in range(12):
            if not any(x['rule'] == family['rewrite_rule'] for x in model.domains[row]):
                continue
            for lemma_row in range(row):
                for source in range(row):
                    if source == lemma_row:
                        continue
                    keys = row_keys(model, lemma_row, family['root_rule'], []) + row_keys(model, row, family['rewrite_rule'], [source, lemma_row])
                    actual = aggregate(model, keys)
                    if actual is None:
                        raise ValueError('declared consistent family failed exact aggregate')
                    instances.append(dict(family=family_id, row=row, lemma_row=lemma_row,
                                          source=source, aggregate=actual))
    save(OUT / 'preflight-families.json.gz', dict(families=families, instances=instances))
    fixtures = []
    for rule in sorted(model.promoted_rules):
        keys = row_keys(model, 0, rule, [])
        child = state.copy()
        cg = graph.copy()
        for key in keys:
            if not child.legal(model.placement(key)):
                raise ValueError('zero-input theorem fixture')
            cg.update(model, child, child.place(model.placement(key)))
        if row_requirements(model, child.selected, 0) != []:
            raise ValueError('zero-input block row must be justified without sources')
        fixtures.append(dict(kind='zero-input-transferred-block', rule=rule, keys=keys,
                             modes=[model.metadata[key].get('mode') for key in keys[2:]],
                             state_sha256=fingerprint(child), restored_parent=fingerprint(state) == fingerprint(model.initial()) and graph.fingerprint() == Graph(model, state).fingerprint()))
    roots = [(i, r) for i, r in enumerate(model.rules) if not r['premises']]
    candidates = [(i, r, source) for i, r in enumerate(model.rules) if r['command']['rule'] == 'generalize'
                  for source, root in roots if root['conclusion'] == r['premises'][0]]
    if not candidates:
        raise ValueError('generic native generalization fixture missing')
    rule, inference, source_rule = candidates[0]
    keys = row_keys(model, 0, source_rule, []) + row_keys(model, 1, rule, [0])
    child = state.copy()
    cg = graph.copy()
    for key in keys:
        cg.update(model, child, child.place(model.placement(key)))
    refs = row_requirements(model, child.selected, 1)
    if refs != [(0, inference['premises'][0])] or model.rule_modes[rule] == 0:
        raise ValueError('generalization input mode')
    wrong = [k for k in keys if not (k[0] == 1 and k[1] == 2)] + [(1, 2, 0, 0)]
    if row_requirements(model, wrong, 1) is not None:
        raise ValueError('incorrect no-input generalization admitted')
    fixtures.append(dict(kind='unary-primitive-generalization', rule=rule,
                         source_rule=source_rule, keys=keys, required_sources=refs,
                         wrong_zero_mode_rejected=True))
    # Separate synthetic primitive point region. Its proof target is not the
    # commutativity query and no whole/native theorem claim is made from it.
    z = ['fun', 'zero', []]
    s = ['fun', 'succ', [z]]
    f = ['eq', z, z]
    g = ['eq', s, s]
    q = ['all', 'fixture', f]
    rules = [dict(premises=[], conclusion=x, command=dict(rule='refl', formula=x)) for x in (f, g)]
    rules += [dict(premises=[f], conclusion=q, command=dict(rule='generalize', formula=q, variable='fixture'))]
    fixture_catalog = dict(basis=[f, g, q], rules=rules, definitions=[])
    fixture_spec = dict(theory=spec['theory'], target=q, length=3)
    fixture_model = PrimitiveFixtureModel(fixture_spec, fixture_catalog, dict(status='native_accepted'))
    fixture_model.promoted_rules = set()
    fixture_model.compiled = dict(rules=[dict(r, description=dict(operation='fixture')) for r in rules])
    fixture_record = fixture_model.record()
    tests = []
    for mode, attempts in (('base', 100), ('fixed', 100), ('base', 0), ('fixed', 0)):
        result = search(fixture_model, mode=mode, attempts=attempts, seconds=5)
        tests.append(dict(mode=mode, attempts=attempts, search=result))
        if not result['root_restored']:
            raise ValueError('fixture rollback')
        if attempts == 0 and result['status'] != 'unknown_search_budget':
            raise ValueError('complete fallback budget fixture')
    save(OUT / 'preflight-fixtures.json.gz', dict(real_partial_fixtures=fixtures,
                                                primitive_fixture=dict(case=fixture_spec, catalog=fixture_catalog, model=fixture_record, tests=tests)))
    if len(model.cache) != 17158 or len(instances) != 13860 or len(families) != 42:
        raise ValueError('complete predeclared counts')
    active = {canonical(x) for r in c['rules'] for x in r['premises'] + [r['conclusion']]}
    summary = dict(status='complete_preflight_pending_independent_audit',
                   placements=len(model.cache), families=len(families), family_instances=len(instances),
                   active_output_premise_formulas=len(active), preserved_formula_id_catalog_entries=len(c['basis']),
                   initial_graph_sha256=graph.fingerprint(), roots=48, initial_decision=graph.decision(state),
                   target_searches=0, native_target_queries=0, seconds=time.perf_counter() - began,
                   peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                   scope='Complete exact native-registry-bound graph/family preflight and isolated primitive fixtures only. Real target partial fixtures do not search or supply a target proof sequence.')
    (OUT / 'preflight-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
