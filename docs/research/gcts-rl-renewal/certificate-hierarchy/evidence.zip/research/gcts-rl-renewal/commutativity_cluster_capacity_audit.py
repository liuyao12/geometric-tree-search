"""Independent complete whole-request instruction, heap and byte replay."""
import copy
import gzip
import hashlib
import json
import resource
import signal
import time
from pathlib import Path
import audit_tree_kernel as T
from audit_certificate_boundary import initial_for, pin
from audit_proof_boundary import expected_constructor, PINNED_MICRO, PINNED_PROGRAM
from commutativity_capacity_stream_audit import encode, layout

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / 'docs/research/gcts-rl-renewal'
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'


def load(path):
    with gzip.open(path, 'rt') as source:
        return json.load(source)


def need(value, message):
    if not value:
        raise ValueError(message)


def alarm(*args):
    raise TimeoutError('unknown_whole_capacity_audit_time_budget')


def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'capacity-audit-plan.json').read_text())
    result = dict(status='checking_complete_whole_capacity_and_encoding', observations=[], native_target_queries=0)
    signal.signal(signal.SIGALRM, alarm)
    try:
        for path, expected in {**plan['source_sha256'], **plan['input_sha256']}.items():
            need(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, 'whole capacity audit freeze ' + path)
        need(json.loads((OUT / 'certificate-audit-v2.json').read_text())['status'] == 'passed_independent_automatic_candidate_selection_and_generic_whole_compaction', 'whole independent transformation gate')
        candidates = load(OUT / 'certificates.json.gz')['candidates']
        selected, seen = [], set()
        for candidate in candidates:
            h = pin(candidate['compact_request'])
            if h not in seen:
                seen.add(h)
                selected.append(candidate)
        producer = json.loads((OUT / 'capacity-summary.json').read_text())
        need(len(producer['observations']) == len(selected) <= 3, 'every distinct predeclared first-lane candidate accounted')
        micro = load(DOC / 'proof-boundary-microcode-001.json.gz')
        boundary = json.loads((DOC / 'proof-boundary-001.json').read_text())
        need(pin(micro) == PINNED_MICRO and pin(boundary['program']) == PINNED_PROGRAM, 'unchanged parser checker and palette')
        T.static_program(boundary['program'])
        for index, candidate in enumerate(selected):
            stage = time.perf_counter()
            signal.setitimer(signal.ITIMER_REAL, 180)
            obs = load(OUT / ('whole-capacity-%03d.json.gz' % index))
            request = candidate['compact_request']
            need(obs['index'] == index and obs['lane'] == candidate['lane'] and obs['request'] == request and obs['request_sha256'] == pin(request), 'whole candidate and input identity')
            initial = initial_for(micro, boundary['cases'][0]['initial'], request)
            nodes, root = expected_constructor(micro, initial, request)
            need(obs['original_initial'] == initial and obs['constructor_nodes'] == nodes and obs['constructor_root'] == root, 'complete true parser constructor')
            if 'tree_result' not in obs:
                result['observations'].append(dict(index=index, lane=candidate['lane'], request_sha256=pin(request),
                                                  producer_status=obs['status'], native_eligible=False,
                                                  status='unknown_no_complete_tree_checkpoint',
                                                  scope='Exact request/parser constructor is bound; incomplete producer instruction replay cannot authorize native execution.'))
                signal.setitimer(signal.ITIMER_REAL, 0)
                continue
            retained, validate = [], T.validate_heap

            def retain(values):
                validate(values)
                retained.append(values)

            T.validate_heap = retain
            try:
                replay = T.replay(boundary['program'], dict(nodes=nodes, node=root), 20000000, 1000000, keep=0)
            finally:
                T.validate_heap = validate
            need(len(retained) == 1, 'full independent final heap')
            need(replay == {k: v for k, v in obs['tree_result'].items() if k != 'seconds'}, 'every whole instruction and profile')
            need([list(n) for n in retained[0]] == obs['final_tree_nodes'], 'every final heap pair')
            required = 2 + sum((i + 257).bit_length() + max(1, a.bit_length()) + max(1, b.bit_length()) + 3 for i, (a, b) in enumerate(retained[0]))
            need(required == obs['required_heap_capacity'], 'complete canonical heap width')
            eligible = replay['status'] == 'accepted' and required <= 262144
            if eligible:
                enlarged = copy.deepcopy(initial)
                enlarged['capacities'][micro['heap']] = 262144
                need(obs['proposed_initial'] == enlarged and obs['original_layout'] == layout(initial) and obs['proposed_layout'] == layout(enlarged), 'every exact word head capacity and physical boundary')
                need(obs['physical_origin'] == 0 and obs['native_start_state'] == micro['start'] == 88986, 'true origin and parser start')
                raw = encode(enlarged, micro['raw'])
                file = OUT / ('whole-input-%03d.bin.gz' % index)
                need(raw == gzip.decompress(file.read_bytes()) and hashlib.sha256(raw).hexdigest() == obs['input_sha256'] and len(raw) == obs['input_bytes'], 'every independently encoded native input byte')
                need(hashlib.sha256(file.read_bytes()).hexdigest() == obs['encoded_file_sha256'], 'exact encoded source file')
            elapsed = time.perf_counter() - stage
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            within = elapsed <= 180 and peak <= 536870912
            producer_resolved = obs['status'] == 'complete_whole_capacity_and_encoding_pending_independent_audit'
            item = dict(index=index, lane=candidate['lane'], request_sha256=pin(request), tree_status=replay['status'], tree_steps=replay['steps'],
                        required_heap_capacity=required, fixed_heap_capacity=262144, all_tree_and_heap_values_matched=True,
                        encoding_byte_matched=eligible, producer_status=obs['status'], seconds=elapsed, peak_rss_bytes=peak,
                        wall_overshoot_seconds=max(0, elapsed - 180), memory_overshoot_bytes=max(0, peak - 536870912),
                        native_eligible=eligible and within and producer_resolved)
            result['observations'].append(item)
            (OUT / 'capacity-audit.json').write_text(json.dumps(result, indent=2) + '\n')
            print('INDEPENDENT WHOLE CAPACITY ' + json.dumps(item), flush=True)
            signal.setitimer(signal.ITIMER_REAL, 0)
            if not within:
                result['status'] = 'unknown_whole_capacity_audit_resource_budget'
                break
            del obs, initial, nodes, retained
            __import__('gc').collect()
        if len(result['observations']) == len(selected) and all(item['native_eligible'] for item in result['observations']):
            result['status'] = 'passed_complete_whole_capacity_and_encoding_replay'
        elif result['status'] == 'checking_complete_whole_capacity_and_encoding':
            result['status'] = 'passed_complete_whole_capacity_replay_with_native_unknowns'
    except (MemoryError, TimeoutError) as exc:
        result.update(status=str(exc), failure_type=type(exc).__name__)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        result.update(seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                      scope='Complete independently interpreted original automatically produced compact whole requests, exact heap widths and typed-array bytes at unchanged fixed workspace. Any original or audit resource/heap/instruction unknown remains native-ineligible. No native target proof claim.')
        (OUT / 'capacity-audit.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
