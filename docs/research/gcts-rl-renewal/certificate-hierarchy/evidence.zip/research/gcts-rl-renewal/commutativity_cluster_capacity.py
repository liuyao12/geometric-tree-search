"""Exact automatically produced whole-request capacity/stream preflight."""
import copy
import gzip
import hashlib
import json
import resource
import signal
import time
from pathlib import Path
from tree_machine import Heap, run
from audit_proof_boundary import expected_constructor, PINNED_MICRO, PINNED_PROGRAM
from audit_certificate_boundary import initial_for, pin
from commutativity_capacity_stream import write_stream, layout

ROOT = Path(__file__).resolve().parents[2]
DOC = ROOT / 'docs/research/gcts-rl-renewal'
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def save(path, value):
    with gzip.open(path, 'wt') as f:
        json.dump(value, f, separators=(',', ':'))


def alarm(*args):
    raise TimeoutError('unknown_whole_capacity_time_budget')


def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'capacity-plan.json').read_text())
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('whole capacity freeze ' + p)
    if json.loads((OUT / 'certificate-audit-v2.json').read_text())['status'] != 'passed_independent_automatic_candidate_selection_and_generic_whole_compaction':
        raise ValueError('complete independent whole transformation gate')
    micro = load(DOC / 'proof-boundary-microcode-001.json.gz')
    boundary = json.loads((DOC / 'proof-boundary-001.json').read_text())
    if pin(micro) != PINNED_MICRO or pin(boundary['program']) != PINNED_PROGRAM:
        raise ValueError('unchanged checker/parser/palette')
    signal.signal(signal.SIGALRM, alarm)
    seen, observations = set(), []
    for candidate in load(OUT / 'certificates.json.gz')['candidates']:
        request = candidate['compact_request']
        h = pin(request)
        if h in seen:
            continue
        seen.add(h)
        j = len(observations)
        start = time.perf_counter()
        signal.setitimer(signal.ITIMER_REAL, 180)
        original = initial_for(micro, boundary['cases'][0]['initial'], request)
        nodes, root = expected_constructor(micro, original, request)
        heap = Heap(nodes, limit=1000000)
        obs = dict(index=j, lane=candidate['lane'], request=request, request_sha256=h,
                   constructor_nodes=nodes, constructor_root=root, original_initial=original,
                   native_queries=0)
        try:
            result = run(boundary['program'], heap, root, limit=20000000, keep=0)
            required = 2 + sum((i + 257).bit_length() + max(1, a.bit_length()) + max(1, b.bit_length()) + 3 for i, (a, b) in enumerate(heap.nodes))
            obs.update(tree_result=result, final_tree_nodes=heap.nodes,
                       required_heap_capacity=required, requirement_is_complete=result['status'] == 'accepted')
            if result['status'] != 'accepted':
                obs['status'] = 'unknown_whole_tree_instruction_budget'
            elif required > 262144:
                obs['status'] = 'unknown_whole_native_heap_boundary'
            else:
                initial = copy.deepcopy(original)
                initial['capacities'][micro['heap']] = 262144
                encoded = write_stream(initial, micro['raw'], OUT / ('whole-input-%03d.bin.gz' % j))
                obs.update(status='complete_whole_capacity_and_encoding_pending_independent_audit',
                           proposed_initial=initial, original_layout=layout(original), proposed_layout=layout(initial),
                           physical_origin=0, native_start_state=88986, **encoded)
        except (TimeoutError, MemoryError) as exc:
            obs.update(status=str(exc), failure_type=type(exc).__name__, final_tree_nodes=heap.nodes,
                       requirement_is_complete=False)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            obs.update(seconds=time.perf_counter() - start, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            obs['wall_overshoot_seconds'] = max(0, obs['seconds'] - 180)
            obs['memory_overshoot_bytes'] = max(0, obs['peak_rss_bytes'] - 536870912)
            if obs['wall_overshoot_seconds'] or obs['memory_overshoot_bytes']:
                obs['status'] = 'unknown_whole_capacity_resource_budget'
            save(OUT / ('whole-capacity-%03d.json.gz' % j), obs)
            observations.append({k: v for k, v in obs.items() if k not in ('request', 'constructor_nodes', 'original_initial', 'final_tree_nodes', 'proposed_initial', 'original_layout', 'proposed_layout')})
            print('WHOLE CAPACITY CHECKPOINT ' + json.dumps(observations[-1]), flush=True)
    summary = dict(status='complete_whole_capacity_observations_pending_independent_audit', observations=observations,
                   native_target_queries=0, seconds=time.perf_counter() - began,
                   scope='Automatically produced compact whole requests only; unchanged checker and fixed 262144 heap. Every resource/heap/instruction unknown preserved. No native target acceptance.')
    (OUT / 'capacity-summary.json').write_text(json.dumps(summary, indent=2) + '\n')


if __name__ == '__main__':
    main()
