"""Order-balanced bounded searches, with model and word/tree checkpoints.

Every observation gets a fresh process/model. Whole checking is a later gate.
"""
import argparse
import copy
import gc
import gzip
import hashlib
import json
import resource
import subprocess
import sys
import time
from pathlib import Path
from commutativity_cluster_points import Model
from commutativity_cluster_search import search

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def save(path, value):
    with gzip.open(path, 'wt') as f:
        json.dump(value, f, separators=(',', ':'))


def freeze(plan):
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('exact execution freeze ' + p)


def worker(observation):
    began = time.perf_counter()
    frozen = json.loads((OUT / 'execution-freeze.json').read_text())
    freeze(frozen)
    plan = json.loads((OUT / 'plan.json').read_text())
    observed = next(x for x in frozen['observations'] if x['id'] == observation)
    gate = json.loads((OUT / 'preflight-audit.json').read_text())
    if gate['status'] != 'passed_complete_graph_family_and_focused_conformance_preflight':
        raise ValueError('independent complete preflight gate')
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    reg_path = PARENT / 'native-complete/registry.json.gz'
    spec = copy.deepcopy(plan['case'])
    spec.update(id=observation, length=12)
    stage = time.perf_counter()
    model = Model(spec, catalog, load(reg_path), json.loads((PARENT / 'native-complete/registry-audit.json').read_text()), reg_path.read_bytes())
    record = model.record()
    setup = time.perf_counter() - stage
    stage = time.perf_counter()
    save(OUT / (observation + '-model.json.gz'), dict(case=spec, model=record))
    model_checkpoint = time.perf_counter() - stage
    del record
    gc.collect()
    result = search(model, mode=observed['mode'], seed=observed['rep'],
                    attempts=5000, seconds=60, proposal_limit=24, proposal_checks=2048,
                    rss_bytes=536870912)
    stage = time.perf_counter()
    save(OUT / (observation + '-search.json.gz'), dict(case=spec, observation=observed,
                                                   search=result, native_target_queries=0))
    checkpoint = time.perf_counter() - stage
    metric = dict(id=observation, mode=observed['mode'], rep=observed['rep'],
                  status=result['status'], proof_rows=None if result['proof'] is None else len(result['proof']),
                  metrics=result['metrics'], search_seconds=result['seconds'],
                  model_setup_seconds=setup, model_checkpoint_seconds=model_checkpoint,
                  search_checkpoint_seconds=checkpoint, total_worker_seconds=time.perf_counter() - began,
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  native_target_queries=0, whole_certificate_status='not_yet_checked',
                  word_sha256=None if result['proof'] is None else hashlib.sha256(json.dumps(result['proof'], sort_keys=True, separators=(',', ':')).encode()).hexdigest())
    (OUT / (observation + '-summary.json')).write_text(json.dumps(metric, indent=2) + '\n')
    print('SEARCH CHECKPOINT ' + json.dumps(metric), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--observation')
    args = parser.parse_args()
    if args.observation:
        worker(args.observation)
        return
    began = time.perf_counter()
    plan = json.loads((OUT / 'execution-freeze.json').read_text())
    freeze(plan)
    summary = dict(status='running_order_balanced_bounded_searches', observations=[],
                   native_target_queries=0, ordinary_forward_extractions=0)
    for observed in plan['observations']:
        subprocess.run([sys.executable, str(Path(__file__)), '--observation', observed['id']], check=True)
        summary['observations'].append(json.loads((OUT / (observed['id'] + '-summary.json')).read_text()))
        summary['seconds'] = time.perf_counter() - began
        (OUT / 'search-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    summary.update(status='complete_four_search_checkpoints_pending_independent_tree_audit', seconds=time.perf_counter() - began)
    (OUT / 'search-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)


if __name__ == '__main__':
    main()
