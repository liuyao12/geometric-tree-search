"""Exact spatial addresses and hereditary exclusions in the recovered Penrose atlas."""
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from math import gcd
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/"source"))
import check_v1 as ring
import model_v1 as plane
from standard_v1 import PROTOS, PHI

ZERO, ONE = plane.ZERO, plane.ONE
UNIT = plane.DIRECTIONS[1]
BASIS = tuple(tuple(int(i == j) for i in range(4)) for j in range(4))


def load(path):
    return json.loads((ROOT/path).read_text())


def freeze(item):
    return tuple(map(freeze,item)) if isinstance(item,list) else item


def times(k,p):
    return tuple(k*x for x in p)


def edges(poly):
    return zip(poly,poly[1:]+poly[:1])


def transform(turn,mirror,p):
    return plane.rotate(ring.star(p) if mirror else p,turn)


def cross(a,b,p):
    return ring.imaginary_normal(ring.minus(b,a),ring.minus(p,a))


def side(a,b,p):
    return ring.order(cross(a,b,p),(0,0))


def oriented(poly):
    direction=side(*poly[:3])
    assert direction
    return poly if direction>0 else poly[::-1]


def direction(d):
    g=gcd(*d)
    assert g
    normal=tuple(x//g for x in d)
    return normal if next(x for x in normal if x)>0 else times(-1,normal)


AXES=tuple(direction(a) for a in plane.DIRECTIONS[:5])


@lru_cache(maxsize=128)
def canonical_axis(d):
    normal=direction(d)
    return next((a for a in AXES if ring.imaginary_normal(a,normal)==(0,0)),normal)


@lru_cache(maxsize=40)
def macro_axes(kind,turn,mirror):
    poly=tuple(transform(turn,mirror,p) for p in PROTOS[kind])
    return tuple(dict.fromkeys(canonical_axis(ring.minus(b,a)) for a,b in edges(poly)))


@lru_cache(maxsize=256)
def linear(d):
    return tuple(ring.imaginary_normal(d,v) for v in BASIS)


def project(d,p):
    (a,b),(c,e),(f,g),(h,i)=linear(d)
    w,x,y,z=p
    return a*w+c*x+f*y+h*z,b*w+e*x+g*y+i*z


def limits(d,poly):
    vals=tuple(project(d,p) for p in poly)
    return min(vals,key=plane.ORDER),max(vals,key=plane.ORDER)


def scale_pair(n,p):
    return n*p[0],n*p[1]


@dataclass(frozen=True)
class Cell:
    kind: int
    turn: int
    mirror: bool
    base: tuple

    def map(self,p):
        return ring.plus(self.base,transform(self.turn,self.mirror,p))


class Atlas:
    def __init__(self):
        self.proof=load("input/standard-proof-v1.json")
        self.rules=tuple(tuple(Cell(*freeze(c)) for c in rules) for rules in self.proof["rules"])
        self.marks=self.proof["marks"]
        nest=self.proof["nest"]
        self.seed=Cell(*freeze(nest["seed"]))
        self.period=nest["depth"]
        self.powers=[ONE]
        self.roots=[Cell(nest["kind"],0,False,ZERO)]

    def power(self,h):
        while h>=len(self.powers):
            self.powers.append(ring.multiply(PHI,self.powers[-1]))
        return self.powers[h]

    def polygon(self,cell,h):
        return tuple(cell.map(ring.multiply(self.power(h),q)) for q in PROTOS[cell.kind])

    def children(self,cell,h):
        assert h>0
        scale=self.power(h-1)
        return tuple(Cell(c.kind,(cell.turn+(-c.turn if cell.mirror else c.turn))%10,
                          cell.mirror!=c.mirror,cell.map(ring.multiply(scale,c.base)))
                     for c in self.rules[cell.kind])

    def root(self,n):
        s=self.seed
        scale=self.power(self.period)
        turn=s.turn if s.mirror else -s.turn
        while n>=len(self.roots):
            prior=self.roots[-1]
            offset=ring.minus(ring.multiply(scale,prior.base),s.base)
            self.roots.append(Cell(prior.kind,(turn+(-prior.turn if s.mirror else prior.turn))%10,
                                   prior.mirror!=s.mirror,transform(turn,s.mirror,offset)))
        return self.roots[n],n*self.period

    def enclose(self,window):
        for n in range(65):
            root,h=self.root(n)
            parent=oriented(self.polygon(root,h))
            if all(side(times(window.den,a),times(window.den,b),p)>0
                   for a,b in edges(parent) for poly in window.parts for p in poly):
                return n,root,h
        raise ValueError("Window is outside the allowed 64 nesting rounds")

    def rhomb(self,cell):
        p,a,b=self.polygon(cell,0)
        mate=ring.minus(ring.plus(a,b),p)
        poly=oriented((p,a,mate,b))
        i=poly.index(min(poly))
        poly=poly[i:]+poly[:i]
        marks=self.marks[cell.kind]
        arrows=[]
        for x,y,mark in ((p,a,marks[0]),(b,p,marks[2]),(mate,a,marks[0]),(b,mate,marks[2])):
            arrows.append((x,y,mark) if x<y else (y,x,-mark))
        return dict(kind=cell.kind,vertices=poly,arrows=sorted(arrows))


class Window:
    def __init__(self,spec):
        self.den=spec["den"]
        assert type(self.den) is int and self.den>0
        self.parts=freeze(spec["parts"])
        assert self.parts and all(len(p)>=3 for p in self.parts)
        assert all(len(p)==4 and all(type(x) is int for x in p) for poly in self.parts for p in poly)
        for poly in self.parts:
            assert len(set(poly))==len(poly)
            assert all(side(a,b,p)>0 for a,b in edges(poly) for p in poly if p not in (a,b))
        self.axes=tuple(tuple(dict.fromkeys(canonical_axis(ring.minus(b,a)) for a,b in edges(p))) for p in self.parts)
        self.support={}
        self.shape_group="grid" if all(set(d)<=set(AXES) for d in self.axes) else "slanted"

    def separated(self,d,poly_index,node_limits):
        key=(d,poly_index)
        if key not in self.support:
            self.support[key]=limits(d,self.parts[poly_index])
        lo,hi=self.support[key]
        left,right=node_limits[d]
        return (ring.order(scale_pair(self.den,right),lo)<=0
                or ring.order(hi,scale_pair(self.den,left))<=0)


def area_population(atlas,kind,h):
    counts=[1,1]
    for _ in range(h):
        counts=[sum(counts[c.kind] for c in r) for r in atlas.rules]
    return counts[kind]


def query(atlas,spec,order="macro",bank=(),*,trace=True,learn=False):
    w=Window(spec)
    n,root,h=atlas.enclose(w)
    hits,skips,rhombs=[],[],{}
    visits,counts,learned=Counter(),Counter(),Counter()
    rejected_marks=Counter()

    def search(cell,level,address):
        visits[level]+=1
        poly=atlas.polygon(cell,level)
        local={}
        witnesses=[]
        macro=macro_axes(cell.kind,cell.turn,cell.mirror)
        for j,receiver in enumerate(w.axes):
            if order=="matched":
                candidates=(*(d for d in bank if d in receiver),*receiver,*macro)
            elif order=="receiver":
                candidates=(*receiver,*macro)
            elif order=="bank":
                candidates=(*bank,*macro,*receiver)
            else:
                candidates=(*macro,*receiver)
            for d in dict.fromkeys(candidates):
                counts["supports"]+=1
                if d not in local:
                    local[d]=limits(d,poly)
                    counts["node_projections"]+=1
                if w.separated(d,j,local):
                    witnesses.append(d)
                    if learn and d in receiver and d not in AXES:
                        learned[d]+=1
                    break
            else:
                break
        if len(witnesses)==len(w.parts):
            if trace:
                skips.append((address,witnesses))
            for d in witnesses:
                if order in ("bank","matched") and d in bank:
                    rejected_marks[d]+=1
            counts["skipped"]+=1
        elif level:
            for i,c in enumerate(atlas.children(cell,level)):
                search(c,level-1,address+str(i))
        else:
            hits.append(address)
            tile=atlas.rhomb(cell)
            key=tuple(sorted(tile["vertices"]))
            if key in rhombs:
                assert tile["arrows"]==rhombs[key]["arrows"]
            rhombs[key]=tile

    search(root,h,"")
    counts["visited"]=sum(visits.values())
    counts["hits"]=len(hits)
    counts["window_projections"]=len(w.support)
    counts["retained"]=len(rhombs)
    exposed={}
    for tile in rhombs.values():
        for a,b in edges(tile["vertices"]):
            edge=tuple(sorted((a,b)))
            if edge in exposed:
                assert exposed.pop(edge)==(b,a)
            else:
                exposed[edge]=(a,b)
    return dict(rounds=n,level=h,flat_leaves=area_population(atlas,root.kind,h),
                counts=counts,by_level=sorted(visits.items()),hits=hits,skips=skips,
                marks=[(d,k) for d,k in sorted(learned.items())],
                reused=[(d,k) for d,k in sorted(rejected_marks.items())],
                rhombs=[rhombs[p] for p in sorted(rhombs)],boundary=sorted(exposed.values()))
