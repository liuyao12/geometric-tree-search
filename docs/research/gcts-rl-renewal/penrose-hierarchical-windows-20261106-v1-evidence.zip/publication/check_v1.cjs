const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/penrose-hierarchical-windows-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 6);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("article[data-case]").count(), 8);
    assert.equal(await page.locator("#results tbody tr").count(), 8);
    assert.equal(await page.locator("svg.patch").count(), 9);
    const visible = page.locator("article[data-case]:visible");
    assert.equal(await visible.locator(".tile").count(), 67);
    assert.equal(await visible.locator(".arrow-path:visible").count(), 0);
    await page.locator("#show-arrows").check();
    assert(await visible.locator(".arrow-path:visible").count() > 0);
    await page.locator("#show-arrows").uncheck();
    if (!process.argv[2]) {
      await visible.screenshot({ path: path.join(__dirname, "hole-v1.png") });
      await page.locator("svg.exclusion").screenshot({ path: path.join(__dirname, "witness-v1.png") });
    }
    await page.locator("#case-select").selectOption("remote-billion");
    assert.equal(await visible.locator(".tile").count(), 17);
    assert.equal(await visible.locator(".boundary-path").count(), 22);
    assert(await visible.locator(".boundary-layer").isVisible());

    await page.locator("#show-boundary").uncheck();
    assert.equal(await visible.locator(".boundary-path:visible").count(), 0);
    await page.locator("#case-select").selectOption("split-remote");
    assert.equal(await visible.locator("svg.patch").count(), 2);
    assert.equal(await visible.locator(".tile").count(), 42);
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_INTERACTIVE_PENROSE_WINDOWS", cases: 8, patchPanels: 9,
      arrowAndBoundaryToggles: true, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
