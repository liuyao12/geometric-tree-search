# Replay the exact Penrose hierarchy queries

Use Python 3.12 and its standard library. In an extracted copy, preserve
the supplied evidence and run these commands from the archive root.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/window_cases_v1.py
    python3.12 -I -S -B source/window_experiment_v1.py
    python3.12 -I -S -B source/window_audit_v1.py

The first script regenerates the training and evaluation windows. The
experiment learns the direction inventory and ordering from separate
training sets and compares the four fixed orders plus the frozen policy.
The audit independently reconstructs the marked subdivision and nesting
from the supplied proof, checks the pruning directions and whole-rhomb
mates, computes coverage by exact clipping, and checks the exposed edges.
The audit can also run directly on the included evidence.

Compare deterministic scientific outputs with `publication/replay-v1.json`.
To reproduce the published HTML byte for byte, copy
`archived-data/timing-v1.json` back into `data` and run
`python3.12 -I -S -B publication/render_v1.py`. To measure local wall
time instead, run `python3.12 -I -S -B source/window_timing_v1.py`
before rendering.

For the interactive browser check, use Node, Playwright, Chromium and
MathJax. Set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom installations
and run `node publication/check_v1.cjs`.
