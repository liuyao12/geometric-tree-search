"""Render audited Penrose windows and their exact hierarchy witness."""
from functools import cmp_to_key
from html import escape
from math import cos, hypot, pi, sin
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from window_model_v1 import AXES, Atlas, cross, edges, freeze, limits, load, project, ring, times
from window_audit_v1 import ordered_field, clip
from window_experiment_v1 import cost, ACTIONS

STEM="penrose-hierarchical-windows-20261106-v1"
NAMES={
    "seed-half":"Exact half-rhomb",
    "local-grid":"Small grid window",
    "local-bend":"Bent window",
    "hole":"Window with a hole",
    "local-large":"Larger local window",
    "remote-million":"Million-unit offset",
    "remote-billion":"Billion-unit offset",
    "split-remote":"Distant components",
}


def embedding(p):
    return (sum(x*cos(2*pi*j/5) for j,x in enumerate(p)),
            sum(x*sin(2*pi*j/5) for j,x in enumerate(p)))


class Panel:
    def __init__(self,anchor,den,points,width=640,height=390):
        self.den=den
        self.anchor=anchor
        self.width,self.height=width,height
        raw=[self.reduced(p,n) for p,n in points]
        x,y=zip(*raw)
        self.scale=min((width-38)/(max(x)-min(x)),(height-38)/(max(y)-min(y)))
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2

    def reduced(self,p,n):
        return tuple(a/(self.den*n) for a in embedding(ring.minus(times(self.den,p),times(n,self.anchor))))

    def screen(self,p,n):
        x,y=self.reduced(p,n)
        u,v=self.center
        return self.width/2+(x-u)*self.scale,self.height/2-(y-v)*self.scale

    def paths(self,kind,polygons,close):
        return "".join(self.path(kind,[self.screen(p,n) for p,n in points],close) for points in polygons)

    def path(self,kind,coords,close=False):
        d="M"+"L".join(f"{x:.3f},{y:.3f}" for x,y in coords)+("Z" if close else "")
        return f'<path class="{kind}" d="{d}"/>'

    def svg(self,kind,title,content):
        return f'<svg class="{kind}" viewBox="0 0 {self.width} {self.height}" role="img" aria-label="{escape(title)}">{content}</svg>'


def edge_arrow(panel,a,b,mark):
    if mark<0:
        a,b=b,a
    x,y=panel.screen(a,1)
    u,v=panel.screen(b,1)
    dx,dy=u-x,v-y
    size=hypot(dx,dy)
    ux,uy=dx/size,dy/size
    w=min(4.8,size*.15)
    out=[]
    for s in ((.5,) if abs(mark)==1 else (.44,.56)):
        p,q=x+dx*s,y+dy*s
        backx,backy=p-w*ux,q-w*uy
        out.append(panel.path("arrow-path",[(backx+w*.55*uy,backy-w*.55*ux),(p,q),
                                            (backx-w*.55*uy,backy+w*.55*ux)]))
    return "".join(out)


def core_boundary(parts):
    vertices={p for part in parts for p in part}
    exposed=set()
    for part in parts:
        for a,b in edges(part):
            axis=next(d for d in AXES if project(d,a)!=project(d,b))
            reverse=ring.order(project(axis,a),project(axis,b))>0
            key=cmp_to_key(ring.order)
            low,high=sorted((project(axis,a),project(axis,b)),key=key)
            cuts=[p for p in vertices if cross(a,b,p)==(0,0)
                  and ring.order(low,project(axis,p))<=0 and ring.order(project(axis,p),high)<=0]
            cuts.sort(key=lambda p:key(project(axis,p)),reverse=reverse)
            for u,v in zip(cuts,cuts[1:]):
                if (v,u) in exposed:
                    exposed.remove((v,u))
                else:
                    exposed.add((u,v))
    return sorted(exposed)


def frame(spec,result,part_index=None):
    den=spec["den"]
    parts=spec["parts"]
    label=NAMES[spec["id"]]
    if part_index is not None:
        parts=(parts[part_index],)
        label+=f" component {part_index+1}"
    tiles=result["rhombs"]
    if part_index is not None:
        target=ordered_field(parts[0],den)
        tiles=[t for t in tiles if clip.intersection(ordered_field(t["vertices"]),target)!=(0,0)]
    boundary=set(result["boundary"])
    available={pair for t in tiles for pair in edges(t["vertices"])}
    boundary=sorted(boundary&available)
    bounds=[(p,den) for part in parts for p in part]+[(p,1) for t in tiles for p in t["vertices"]]
    panel=Panel(parts[0][0],den,bounds)
    content=['<g class="tiles">']
    for t in tiles:
        cls="tile thin" if t["kind"]==0 else "tile thick"
        content.append(panel.paths(cls,[[(p,1) for p in t["vertices"]]],True))
    content.append('</g><g class="boundary-layer">')
    content.append(panel.paths("boundary-path",[[(a,1),(b,1)] for a,b in boundary],False))
    content.append('</g><g class="window-layer">')
    content.append(panel.paths("window-path",[[(a,den),(b,den)] for a,b in core_boundary(parts)],False))
    content.append('</g><g class="arrow-layer">')
    for a,b,m in sorted({record for tile in tiles for record in tile["arrows"]}):
        content.append(edge_arrow(panel,a,b,m))
    content.append("</g>")
    return panel.svg("patch",label,"".join(content))


def window_panel(spec,case,checked,initial):
    name=spec["id"]
    r=freeze_case(case["certificate"])
    portions=(0,1) if name=="split-remote" else (None,)
    pictures=[]
    for i in portions:
        caption=f"Component {i+1}" if i is not None else spec["description"]
        pictures.append(f'<figure>{frame(spec,r,i)}<figcaption>{escape(caption)}</figcaption></figure>')
    pictures="".join(pictures)
    if len(portions)>1:
        pictures=f'<div class="gallery">{pictures}</div>'
    hidden="" if initial else " hidden"
    return f'''<article data-case="{name}"{hidden}>
<h3>{NAMES[name]}</h3>{pictures}
<p class="measurements">{r["counts"]["retained"]:,} rhombs · {checked["boundary_edges"]:,} exposed sides · {r["counts"]["visited"]:,} hierarchy nodes</p>
</article>'''


def freeze_case(item):
    if isinstance(item,dict):
        return {k:freeze_case(v) for k,v in item.items()}
    if isinstance(item,list):
        return tuple(map(freeze_case,item))
    return item


def actual_witness(spec,row):
    atlas=Atlas()
    record=row["certificate"]
    root,h=atlas.root(record["rounds"])
    den=spec["den"]
    part=spec["parts"][0]
    anchor=part[0]
    center_num=tuple(sum(p[k]-anchor[k] for p in part) for k in range(4))
    target=tuple(x/len(part) for x in embedding(center_num))
    candidates=[]
    for path,(d,) in freeze(record["skips"]):
        level=h-len(path)
        if level not in (2,3):
            continue
        node=root
        for i,c in enumerate(path):
            node=atlas.children(node,h-i)[int(c)]
        poly=atlas.polygon(node,level)
        center=tuple(sum(embedding(ring.minus(times(den,p),anchor))[i] for p in poly)/3
                     for i in range(2))
        candidates.append((hypot(center[0]-target[0],center[1]-target[1]),path,poly,d))
    _,address,poly,d=min(candidates)
    panel=Panel(anchor,den,[(p,den) for p in part]+[(p,1) for p in poly],640,315)
    low,high=limits(d,poly)
    a,_=limits(d,part)
    high_side=ring.order((high[0]*den,high[1]*den),a)<=0
    pivot=next(p for p in poly if project(d,p)==(high if high_side else low))
    x,y=panel.screen(pivot,1)
    u,v=embedding(d)
    length=hypot(u,v)
    vx,vy=u/length,-v/length
    support=panel.path("support-line",[(x-800*vx,y-800*vy),(x+800*vx,y+800*vy)])
    core=panel.paths("window-path",[[(p,den) for p in part]],True)
    cluster=panel.paths("cluster-path",[[(p,1) for p in poly]],True)
    title=f"Separating line for cluster at address {address}"
    return panel.svg("exclusion",title,'<style>.cluster-path{fill:#ead092;stroke:#885b03;stroke-width:1.6px}.support-line{stroke:#885b03;stroke-width:1.2px}</style>'+cluster+support+core)


def row(label,values):
    cells="".join(f'<td class="nowrap">{escape(v)}</td>' for v in values)
    return f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>'


def main():
    cases=load("input/cases-v1.json")
    study=load("data/results-v1.json")
    audit=load("data/audit-v1.json")
    timing=load("data/timing-v1.json")
    table,policy,options,gallery=[],[],[],[]
    witness=None
    for spec,case,checked,measured in zip(cases["holdout"],study["cases"],audit["cases"],timing["cases"],strict=True):
        assert spec["id"]==case["id"]==checked["id"]==measured["id"]
        name=spec["id"]
        title=NAMES[name]
        r=case["certificate"]
        counts=r["counts"]
        table.append(row(title,[f"{x:,}" for x in (r["level"],r["flat_leaves"],counts["visited"],
                                                     counts["skipped"],counts["retained"])]
                         +[f'{measured["median_microseconds"]/1000:.2f}']))
        policy.append(row(title,[f'{cost(case["comparison"][a]):,}' for a in ACTIONS]+[f'{cost(r):,}']))
        initial=name=="hole"
        options.append(f'<option value="{name}"{" selected" if initial else ""}>{title}</option>')
        gallery.append(window_panel(freeze_case(spec),case,checked,initial))
        if name=="local-grid":
            witness=actual_witness(freeze_case(spec),case)
        if name=="remote-billion":
            population=f'{r["flat_leaves"]:,}'
    aggregate=[sum(cost(c["comparison"][a]) for c in study["cases"]) for a in ACTIONS]
    policy.append(row("All windows",[f"{x:,}" for x in aggregate]+
                      [f'{sum(cost(c["certificate"]) for c in study["cases"]):,}']))
    template=(ROOT/"publication/notebook-v1.html").read_text()
    replacements=dict(STEM=STEM,REMOTE_FLAT=population,OPTIONS="".join(options),GALLERY="\n".join(gallery),
                      WITNESS=witness,TABLE="".join(table),POLICY="".join(policy),
                      BANK=str(len(study["bank"])),DONORS=str(len(study["donors"])),TRAIN=str(len(study["episodes"])))
    for key,value in replacements.items():
        template=template.replace("%%"+key+"%%",value)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
