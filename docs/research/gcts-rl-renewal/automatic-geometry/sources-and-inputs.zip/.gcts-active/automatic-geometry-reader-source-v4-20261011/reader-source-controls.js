'use strict';
// Synthetic display-only controls. No original observations/models or scientific APIs.
const assert = require('assert');
globalThis.GCTS_GEOMETRY_READER_NO_AUTOSTART = true;
require('./viewer.js');
const api = globalThis.GCTSGeometryReader;
const v = ['var', 'A'], p = ['pred', 'P', [v]], q = ['pred', 'Q', [v]], zero = ['bot'];
const formulas = [p, ['eq', ['fun', 'c', []], v], ['not', p], ['all', 'A', p], ['and', p, p], ['imp', p, zero], zero];
for (const f of formulas) { assert.strictEqual(typeof api.formulaLatex(f), 'string'); assert.strictEqual(typeof api.formulaEnglish(f), 'string'); }
assert(api.formulaLatex(['pred', 'R', [['fun', 'f', [v]]]]).includes('operatorname{f}'));
const englishControls = [
  [api.formulaEnglish(p), String.raw`\(\operatorname{P}\)`, String.raw`\(\mathit{A}\)`],
  [api.formulaEnglish(['eq', ['fun', 'c', []], v]), String.raw`\(\operatorname{c}\)`],
  [api.formulaEnglish(['pred', 'R', [['fun', 'f', [v]]]]), String.raw`\(\operatorname{f}\)`],
  [api.formulaEnglish(['all', 'x', p]), String.raw`\(\mathit{x}\)`],
  [api.formulaEnglish(['pred', 'P_\\{}$', [['var', 'A_\\{}$']]]), String.raw`\(\operatorname{P\_\backslash{}\{\}\$}\)`, String.raw`\(\mathit{A\_\backslash{}\{\}\$}\)`],
  [api.ruleEnglish({rule: 'generalize', variable: 'x_'}, [0], {}), String.raw`\(\mathit{x\_}\)`],
  [api.ruleEnglish({rule: 'axiom', name: 'A_$'}, [], {}), String.raw`\(\text{A\_\$}\)`],
  [api.ruleEnglish({rule: 'block', name: 'lemma_$'}, [0], {}), String.raw`\(\text{lemma\_\$}\)`],
  [api.ruleEnglish({rule: 'unknown_$'}, [], {}), String.raw`\(\text{unknown\_\$}\)`]
];
for (const [english, ...expected] of englishControls) for (const fragment of expected) assert(english.includes(fragment), english);
let rejected = 0;
for (const f of [['or', p, p], ['exists', 'A', p], ['var', 'A'], ['pred', 'P', 'bad'], ['eq', ['fun', 'x'], v]]) { assert.throws(() => api.formulaLatex(f)); rejected++; }
assert.strictEqual(api.accepted({}, {}), false);
assert.strictEqual(api.accepted({}, {independent_certificate_accepted: 'true'}), false);
assert.strictEqual(api.accepted({}, {independent_certificate_accepted: true}), true);
assert.strictEqual(api.certificateRows({}, {point_certificate: null}), null);
const recipes = [
  {id: 'synthetic-display-only-r0', primitive_witness: {rule: 'assumption', index: 0, formula: p}, ordered_premise_formulas: []},
  {id: 'synthetic-display-only-r1', primitive_witness: {rule: 'fixture_nonlogical', formula: q}, ordered_premise_formulas: [p, p]}
];
const data = {formula_codes: [p, q], recipes, hypotheses: [p], target: q, observations: []};
function placement(index, row, refs) {
  const recipe = recipes[index], formulaCode = index === 0 ? 0 : 1;
  const values = new Map([['1,0', [1, 0, formulaCode]]]);
  refs.forEach((ref, i) => { values.set('1,' + (ref - row), [1, ref - row, 0]); values.set((2 + i) + ',0', [2 + i, 0, ref - row]); });
  const rt = [[0, 0, 1]], rm = Array.from(values.values()).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const t = rt.map(e => [e[0], e[1] + row, e[2]]), m = rm.map(e => [e[0], e[1] + row, e[2]]);
  const command = {...recipe.primitive_witness, ...(refs.length ? {ordered_refs: refs} : {})};
  return {id: 'synthetic-display-only-' + row, key: [index, row, refs], command, t, m,
    identity_preimage: {prototype_preimage: {recipe_id: recipe.id, primitive_witness: recipe.primitive_witness,
      ordered_premise_formulas: recipe.ordered_premise_formulas, relative_ordered_input_offsets: refs.map(ref => ref - row),
      orientation: 'identity', t: rt, m: rm}, transform: [0, row], ordered_input_rows: refs, primitive_command: command, t, m}};
}
const certificate = {point_certificate: {placements: [placement(1, 2, [0, 1]), placement(0, 1, []), placement(0, 0, [])]}};
assert.deepStrictEqual(api.certificateRows(data, certificate).map(row => row.row), [0, 1, 2]);
for (const mutation of [
  c => { c.point_certificate.placements[0].identity_preimage.prototype_preimage.orientation = 'rotate'; },
  c => { c.point_certificate.placements[0].identity_preimage.prototype_preimage.relative_ordered_input_offsets = [1, -1]; },
  c => { c.point_certificate.placements[0].m.find(e => e[0] === 2)[2] = 0; },
  c => { c.point_certificate.placements[0].m.find(e => e[0] === 1 && e[1] === 0)[2] = 1; },
  c => { c.point_certificate.placements[0].key[0] = 0; },
  c => { c.point_certificate.placements[0].identity_preimage.ordered_input_rows = [0, 2]; }
]) { const c = JSON.parse(JSON.stringify(certificate)); mutation(c); assert.throws(() => api.certificateRows(data, c)); rejected++; }
function state(keys) {
  const totals = Array(24).fill(0), marks = new Map();
  // Synthetic exterior boundary assignments follow the source schema; no formula decoding.
  for (let row = -23; row < 0; row++) marks.set('1,' + row, [1, row, -1, 1]);
  marks.set('1,23', [1, 23, 1, 1]);
  keys.forEach(key => {
    const [index, row, refs] = key; totals[row] = 1;
    const place = placement(index, row, refs);
    place.m.forEach(e => { const id = e[0] + ',' + e[1]; if (marks.has(id)) { assert.strictEqual(marks.get(id)[2], e[2]); marks.get(id)[3]++; } else marks.set(id, [...e, 1]); });
  });
  return {full_semantic_sha256: 'synthetic-display-only-no-scientific-hash', projection: {graph: {totals, marks: Array.from(marks.values()), order: keys,
    selected_generations: [], roots: Array(24).fill(0), excluded: Array.from({length: 24}, () => []), domains: []}, hint_states: []}};
}
// Later output is selected first; row22 is still pending. Numeric sources are prior, not necessarily placed.
const laterFirst = state([[1, 23, [18, 22]], [0, 18, []]]);
const snap = api.snapshotRows(data, laterFirst);
assert.deepStrictEqual(snap.rows.map(e => e.row), [18, 23]);
assert.strictEqual(snap.rows[1].insertion, 0);
assert.strictEqual(snap.rows[1].refs[0].selected, true);
assert.strictEqual(snap.rows[1].refs[1].selected, false);
assert.strictEqual(snap.rows[1].refs[1].occupied, false);
assert.strictEqual(snap.rows[1].refs[1].offset, -1);
assert.strictEqual(snap.rows[0].outputCode, 0); // Assigned zero is not missing.
assert.strictEqual(snap.marks.length, laterFirst.projection.graph.marks.length);
assert.strictEqual(snap.marks.filter(mark => mark[0] === 1 && mark[1] < 0 && mark[2] === -1).length, 23);
const tripleState = JSON.parse(JSON.stringify(laterFirst)); tripleState.projection.graph.totals = tripleState.projection.graph.totals.map((value, row) => [0, row, value]);
assert.deepStrictEqual(api.snapshotRows(data, tripleState).rows.map(e => e.row), [18, 23]);
for (const mutation of [
  s => { s.projection.graph.order[0][2] = [18, 23]; },
  s => { s.projection.graph.order[0][0] = 999; },
  s => { s.projection.graph.marks.find(e => e[0] === 3)[2] = -2; },
  s => { s.projection.graph.marks.find(e => e[0] === 1 && e[1] === 23)[2] = 0; },
  s => { s.projection.graph.marks.find(e => e[0] === 1 && e[1] === 22)[2] = 1; },
  s => { s.projection.graph.totals[23] = 0; },
  s => { s.projection.graph.marks.push([...s.projection.graph.marks[0]]); },
  s => { s.projection.graph.order.push(...Array.from({length: 23}, () => [0, 0, []])); },
  s => { s.projection.graph.order.push([0, 18, []]); },
  s => { s.projection.graph.marks.find(mark => mark[0] === 1 && mark[1] === -1)[2] = 0; },
  s => { s.projection.graph.marks.find(mark => mark[0] === 1 && mark[1] === -1)[2] = -2; },
  s => { s.projection.graph.marks.find(mark => mark[0] === 1 && mark[1] === 23)[2] = -1; }
]) { const s = JSON.parse(JSON.stringify(laterFirst)); mutation(s); assert.throws(() => api.snapshotRows(data, s)); rejected++; }
const empty = state([]), one = state([[0, 18, []]]);
const observation = {id: 'synthetic-only', mode: 'display-fixture', status: 'unknown_search_budget', attempts: 3, seconds: {search: 0}, point_certificate: null, decoded_certificate: null,
  initial_state: empty, events: [{kind: 'fixture', state: one}, {kind: 'fixture', state: laterFirst}, {kind: 'fixture', state: laterFirst}], terminal_state: empty};
assert.strictEqual(api.deepestSelection(observation), '1');
assert.strictEqual(api.deepestSelection({initial_state: laterFirst, events: [{state: laterFirst}]}), 'initial');
assert.strictEqual(api.deepestSelection({events: []}), '');
// Minimal native-DOM-shaped test double: verifies display text and unchanged selector, not browser layout or MathJax.
class Element {
  constructor(tag) { this.tagName = tag.toUpperCase(); this.children = []; this.value = ''; this.checked = true; this.hidden = false; this.dataset = {}; this.textContent = ''; this.className = ''; }
  append(...children) { this.children.push(...children); if (this.tagName === 'SELECT' && this.value === '' && children.length) this.value = children[0].value; }
  replaceChildren(...children) { this.children = []; if (this.tagName === 'SELECT') this.value = ''; this.append(...children); }
  setAttribute(key, value) { this[key] = value; }
  get options() { return this.children; }
}
const ids = {}; ['observation', 'trace-event', 'proof-view', 'trace-view', 'formula-layer', 'reference-layer', 'reader'].forEach(id => ids[id] = new Element(id === 'observation' || id === 'trace-event' ? 'select' : 'div'));
globalThis.document = {createElement: tag => new Element(tag), getElementById: id => ids[id] || null, head: new Element('head')};
const text = element => element.textContent + element.children.map(text).join('\n');
const count = (element, cls) => (element.className === cls ? 1 : 0) + element.children.reduce((sum, child) => sum + count(child, cls), 0);
(async () => {
  let sentinelDecodes = 0;
  const guardedCodes = new Proxy(data.formula_codes, {get(target, property, receiver) {
    if (property === '-1') { sentinelDecodes++; throw new Error('Exterior sentinel must never be decoded as a formula'); }
    return Reflect.get(target, property, receiver);
  }});
  await api.mount({...data, formula_codes: guardedCodes, observations: [observation]});
  assert.strictEqual(ids['trace-event'].value, '1');
  assert.strictEqual(count(ids['trace-view'], 'gcts-literal-square'), 2);
  assert.strictEqual(count(ids['proof-view'], 'gcts-literal-square'), 0);
  assert(text(ids['trace-view']).includes('pending source receptor (not selected)'));
  assert(text(ids['trace-view']).includes('not a proof or certificate'));
  assert(text(ids['trace-view']).includes('All assigned snapshot marking points'));
  assert.strictEqual(text(ids['trace-view']).split('Exterior boundary exclusion sentinel').length - 1, 23);
  assert(text(ids['trace-view']).includes('\\operatorname{refcount}'));
  assert(text(ids['proof-view']).includes('No point certificate'));
  ids['trace-event'].value = '0'; await ids['trace-event'].onchange();
  assert.strictEqual(count(ids['trace-view'], 'gcts-literal-square'), 1);
  ids['formula-layer'].checked = false; await ids['formula-layer'].onchange();
  assert.strictEqual(ids['trace-event'].value, '0');
  ids['reference-layer'].checked = false; await ids['reference-layer'].onchange();
  assert.strictEqual(ids['trace-event'].value, '0');
  assert.strictEqual(text(ids['trace-view']).split('Exterior boundary exclusion sentinel').length - 1, 23);
  assert(text(ids['trace-view']).includes('\\operatorname{refcount}'));
  assert.strictEqual(sentinelDecodes, 0);
  console.log(JSON.stringify({status: 'passed_bounded_display_only_v4_controls', formula_examples: formulas.length, ast_tags_covered: 9,
    malformed_or_metadata_mutants_rejected: rejected, zero_assignment_preserved: true, pending_unselected_prior_source_preserved: true,
    insertion_and_numeric_order_distinguished: true, all_snapshot_marks_retained: true, deepest_first_tie: true, layer_toggles_keep_selected_event: true,
    exact_core_certificate_semantics_fixture: true, english_latex_controls: englishControls.length, english_identifiers_escaped: true, exterior_sentinels_preserved: 23, exterior_invalid_variants_rejected: 3, sentinel_formula_decodes: sentinelDecodes, synthetic_dom_only: true, actual_results_loaded: 0, scientific_imports: 0, searches: 0, training: 0, native_queries: 0, replays: 0}));
})().catch(error => { console.error(error.stack); process.exitCode = 1; });
