'use strict';
// Bounded display-only fixtures; no original result/model and no scientific API.
const assert = require('assert');
require('./viewer.js');
const api = globalThis.GCTSGeometryReader;
const v = ['var', 'A'];
const c = ['fun', 'c', []];
const p = ['pred', 'P', [v]];
const formulas = [p, ['eq', c, v], ['not', p], ['all', 'A', p], ['and', p, p], ['imp', p, ['bot']], ['bot']];
for (const f of formulas) {
  assert.strictEqual(typeof api.formulaLatex(f), 'string');
  assert.strictEqual(typeof api.formulaEnglish(f), 'string');
}
assert(api.formulaLatex(['pred', 'R', [['fun', 'f', [v]]]]).includes('operatorname{f}'));
assert(api.formulaLatex(['all', 'x', ['bot']]).includes('forall'));
assert(api.formulaEnglish(['imp', p, ['bot']]).startsWith('If '));
let rejected = 0;
for (const f of [['or', p, p], ['exists', 'A', p], ['var', 'A'], ['pred', 'P', 'bad'], ['eq', ['fun', 'x'], v]]) {
  assert.throws(() => api.formulaLatex(f)); rejected++;
}
assert(api.formulaLatex(['pred', 'P_\\{}', []]).includes('backslash'));
assert.strictEqual(api.accepted({}, {}), false);
assert.strictEqual(api.accepted({}, {independent_certificate_accepted: 'true'}), false);
assert.strictEqual(api.accepted({}, {independent_certificate_accepted: true}), true);
assert.strictEqual(api.certificateRows({}, {point_certificate: null}), null);
const recipes = [
  {id: 'display-only-r0', primitive_witness: {fixture: 'no scientific acceptance'}, ordered_premise_formulas: []},
  {id: 'display-only-r1', primitive_witness: {fixture: 'no scientific acceptance'}, ordered_premise_formulas: [p]}
];
function placement(index, row, refs) {
  const recipe = recipes[index];
  const relativeT = [[0, 0, 1]], relativeM = [[1, 0, 0], ...refs.map((ref, i) => [2 + i, ref - row, 0])];
  const t = relativeT.map(q => [q[0], q[1] + row, q[2]]), m = relativeM.map(q => [q[0], q[1] + row, q[2]]);
  const command = {rule: 'block', name: recipe.id, formula: p, inputs: refs};
  return {id: 'display-only-' + row, key: [index, row, refs], command, t, m,
    identity_preimage: {prototype_preimage: {recipe_id: recipe.id, primitive_witness: recipe.primitive_witness,
      ordered_premise_formulas: recipe.ordered_premise_formulas, relative_ordered_input_offsets: refs.map(ref => ref - row),
      orientation: 'identity', t: relativeT, m: relativeM}, transform: [0, row], ordered_input_rows: refs,
      primitive_command: command, t, m}};
}
const data = {formula_codes: [p], recipes, target: p};
const observation = {point_certificate: {placements: [placement(1, 1, [0]), placement(0, 0, [])]}};
assert.deepStrictEqual(api.certificateRows(data, observation).map(row => row.row), [0, 1]);
const mutate = fn => { const copy = JSON.parse(JSON.stringify(observation)); fn(copy); assert.throws(() => api.certificateRows(data, copy)); rejected++; };
mutate(o => { o.point_certificate.placements[0].identity_preimage.prototype_preimage.orientation = 'rotate'; });
mutate(o => { o.point_certificate.placements[0].identity_preimage.prototype_preimage.relative_ordered_input_offsets = [1]; });
mutate(o => { o.point_certificate.placements[0].m[0][2] = 99; });
mutate(o => { o.point_certificate.placements[0].key[0] = 0; });
mutate(o => { o.point_certificate.placements[0].identity_preimage.ordered_input_rows = [1]; });
mutate(o => { o.point_certificate.placements[0].identity_preimage.prototype_preimage.primitive_witness = {}; });
console.log(JSON.stringify({status: 'passed_bounded_display_only_source_controls', formula_tag_examples: formulas.length,
  malformed_or_metadata_mutants_rejected: rejected, acceptance_default_pending: true,
  original_results_loaded: 0, scientific_imports: 0, searches: 0, training_episodes: 0, native_queries: 0, replays: 0}));
