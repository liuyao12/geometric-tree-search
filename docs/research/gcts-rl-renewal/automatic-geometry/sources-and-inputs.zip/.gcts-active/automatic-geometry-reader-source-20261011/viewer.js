(function (global) {
  'use strict';

  const IDs = ['observation', 'trace-event', 'proof-view', 'trace-view', 'formula-layer', 'reference-layer', 'reader'];
  const same = (a, b) => canonical(a) === canonical(b);
  function canonical(value) {
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
    return JSON.stringify(value);
  }
  function need(condition, message) { if (!condition) throw new Error(message); }
  function integer(value, label) { need(Number.isSafeInteger(value), label + ' must be an exact safe integer'); return value; }
  function escapeTex(value) {
    need(typeof value === 'string', 'Mathematical identifier must be a string');
    return value.replace(/[\\{}_$&#%~^]/g, ch => ({'\\': '\\backslash{}', '{': '\\{', '}': '\\}', '_': '\\_', '$': '\\$', '&': '\\&', '#': '\\#', '%': '\\%', '~': '\\textasciitilde{}', '^': '\\textasciicircum{}'})[ch]);
  }
  function shape(ast, length, tag) { need(Array.isArray(ast) && ast.length === length && ast[0] === tag, 'Malformed ' + tag + ' AST'); }
  function termLatex(ast) {
    need(Array.isArray(ast) && ast.length, 'Term AST required');
    if (ast[0] === 'var') { shape(ast, 2, 'var'); return '\\mathit{' + escapeTex(ast[1]) + '}'; }
    if (ast[0] === 'fun') {
      shape(ast, 3, 'fun'); need(Array.isArray(ast[2]), 'Function arguments must be an AST array');
      const name = '\\operatorname{' + escapeTex(ast[1]) + '}';
      return name + (ast[2].length ? '\\left(' + ast[2].map(termLatex).join(',') + '\\right)' : '');
    }
    throw new Error('Unknown term AST tag ' + String(ast[0]));
  }
  function formulaLatex(ast) {
    need(Array.isArray(ast) && ast.length, 'Formula AST required');
    const tag = ast[0];
    if (tag === 'pred') {
      shape(ast, 3, tag); need(Array.isArray(ast[2]), 'Predicate arguments must be an AST array');
      return '\\operatorname{' + escapeTex(ast[1]) + '}' + (ast[2].length ? '\\left(' + ast[2].map(termLatex).join(',') + '\\right)' : '');
    }
    if (tag === 'eq') { shape(ast, 3, tag); return termLatex(ast[1]) + '=' + termLatex(ast[2]); }
    if (tag === 'not') { shape(ast, 2, tag); return '\\neg\\left(' + formulaLatex(ast[1]) + '\\right)'; }
    if (tag === 'all') { shape(ast, 3, tag); return '\\forall ' + '\\mathit{' + escapeTex(ast[1]) + '}\\;\\left(' + formulaLatex(ast[2]) + '\\right)'; }
    if (tag === 'and' || tag === 'imp') {
      shape(ast, 3, tag);
      return '\\left(' + formulaLatex(ast[1]) + (tag === 'and' ? '\\land ' : '\\Rightarrow ') + formulaLatex(ast[2]) + '\\right)';
    }
    if (tag === 'bot') { shape(ast, 1, tag); return '\\bot'; }
    throw new Error('Unknown formula AST tag ' + String(tag));
  }
  function termEnglish(ast) {
    termLatex(ast); // Same fail-closed grammar, no ad-hoc word interpretation.
    if (ast[0] === 'var') return 'the object ' + ast[1];
    return ast[2].length ? 'the value of ' + ast[1] + ' on ' + ast[2].map(termEnglish).join(', ') : 'the constant ' + ast[1];
  }
  function formulaEnglish(ast) {
    formulaLatex(ast);
    switch (ast[0]) {
      case 'pred': return 'The predicate ' + ast[1] + ' holds' + (ast[2].length ? ' for ' + ast[2].map(termEnglish).join(', ') : '');
      case 'eq': return termEnglish(ast[1]) + ' equals ' + termEnglish(ast[2]);
      case 'not': return 'It is not the case that (' + formulaEnglish(ast[1]) + ')';
      case 'all': return 'For every choice of object ' + ast[1] + ', ' + formulaEnglish(ast[2]);
      case 'and': return '(' + formulaEnglish(ast[1]) + ') and (' + formulaEnglish(ast[2]) + ')';
      case 'imp': return 'If ' + formulaEnglish(ast[1]) + ', then ' + formulaEnglish(ast[2]);
      case 'bot': return 'A contradiction';
      default: throw new Error('Unknown formula AST tag');
    }
  }
  function pointTriples(values, label) {
    need(Array.isArray(values), label + ' array required');
    const seen = new Set();
    for (const point of values) {
      need(Array.isArray(point) && point.length === 3, label + ' requires exact [x,y,value] triples');
      integer(point[0], label + ' x'); integer(point[1], label + ' y');
      need(typeof point[2] === 'number' && Number.isFinite(point[2]), label + ' finite value required');
      const key = point[0] + ',' + point[1]; need(!seen.has(key), 'Duplicate ' + label + ' point ' + key); seen.add(key);
    }
  }
  function certificateRows(data, observation) {
    if (observation.point_certificate == null) return null;
    const placements = observation.point_certificate.placements;
    need(Array.isArray(placements) && placements.length > 0, 'Nonempty certificate placements array required');
    const rows = placements.map(p => ({placement: p, row: integer(p.key && p.key[1], 'Placement row')})).sort((a, b) => a.row - b.row);
    const rowMap = new Map();
    for (const entry of rows) {
      const p = entry.placement, row = entry.row, pre = p.identity_preimage, proto = pre && pre.prototype_preimage;
      need(row >= 0 && !rowMap.has(row), 'Repeated or negative proof row');
      need(Array.isArray(p.key) && p.key.length === 3 && Array.isArray(p.key[2]), 'Exact recipe/row/source key required');
      const recipeIndex = integer(p.key[0], 'Recipe index'), recipe = data.recipes[recipeIndex];
      need(recipe && proto && pre, 'Recipe and full decorated provenance required');
      need(recipe.primitive_witness !== undefined && Array.isArray(recipe.ordered_premise_formulas), 'Complete recipe witness and ordered premises required');
      need(recipe.id === proto.recipe_id && same(recipe.primitive_witness, proto.primitive_witness)
        && same(recipe.ordered_premise_formulas, proto.ordered_premise_formulas), 'Recipe prototype correspondence');
      need(proto.orientation === 'identity' && same(pre.transform, [0, row]), 'Translation-only identity orientation required');
      need(same(p.key[2], pre.ordered_input_rows), 'Ordered input rows disagree with key');
      need(same(p.command, pre.primitive_command) && same(p.t, pre.t) && same(p.m, pre.m), 'Absolute command/t/m provenance disagreement');
      need(Array.isArray(pre.ordered_input_rows) && pre.ordered_input_rows.length === recipe.ordered_premise_formulas.length,
        'Every ordered premise requires its saved source row');
      const refs = pre.ordered_input_rows;
      refs.forEach(ref => { integer(ref, 'Strict-prior source row'); need(ref >= 0 && ref < row, 'Input must strictly precede current row'); });
      need(same(proto.relative_ordered_input_offsets, refs.map(ref => ref - row)), 'Relative ordered negative offsets disagree');
      pointTriples(p.t, 't'); pointTriples(p.m, 'm');
      need(Array.isArray(proto.t) && Array.isArray(proto.m)
        && same(p.t, proto.t.map(q => [q[0], q[1] + row, q[2]]))
        && same(p.m, proto.m.map(q => [q[0], q[1] + row, q[2]])), 'Exact translated t/m supports required');
      const output = p.m.filter(q => q[0] === 1 && q[1] === row);
      need(output.length === 1, 'Exactly one output marking at (1,row) required');
      const code = integer(output[0][2], 'Output formula code');
      need(code >= 0 && code < data.formula_codes.length && same(data.formula_codes[code], p.command.formula), 'Output formula-code/command mismatch');
      formulaLatex(p.command.formula);
      refs.forEach((ref, index) => {
        need(rowMap.has(ref) && same(rowMap.get(ref).placement.command.formula, recipe.ordered_premise_formulas[index]), 'Ordered premise disagrees with prior output');
        const marks = p.m.filter(q => q[0] === 2 + index && q[1] === ref);
        need(marks.length === 1 && Number.isSafeInteger(marks[0][2])
          && same(data.formula_codes[marks[0][2]], recipe.ordered_premise_formulas[index]), 'Extended source marking does not encode its ordered premise');
      });
      entry.recipe = recipe; entry.refs = refs; entry.offsets = proto.relative_ordered_input_offsets; entry.outputCode = code;
      rowMap.set(row, entry);
    }
    rows.forEach((entry, index) => need(entry.row === index, 'Complete certificate rows must start at zero without gaps'));
    need(same(rows[rows.length - 1].placement.command.formula, data.target), 'Last displayed output must equal the root target');
    return rows;
  }
  function ruleEnglish(command, refs, recipe) {
    const cited = refs.map(n => 'row ' + (n + 1)).join(', ');
    const rule = command.rule;
    if (rule === 'axiom') return 'Use the declared hypothesis or axiom' + (command.name === undefined ? '.' : ' ' + String(command.name) + '.');
    if (rule === 'refl') return 'Assert reflexive equality by the saved reflexivity rule.';
    if (rule === 'mp') return 'Apply modus ponens using ' + cited + ': the antecedent and the implication yield this conclusion.';
    if (rule === 'generalize') return 'Universally generalize ' + cited + ' over ' + String(command.variable) + '; freshness and assumption conditions belong to the independent checker.';
    if (rule === 'block') return 'Apply the declared recipe ' + String(command.name) + (refs.length ? ' to ' + cited + ' in that order.' : ', with no input rows.');
    if (rule === 'tautology') return 'Use the saved propositional tautology command.';
    return 'Use the saved primitive rule ' + String(rule) + (refs.length ? ' with ' + cited + ' in the displayed order.' : ', with no prior input rows.') + ' Its exact command is shown below.';
  }
  function accepted(data, observation) {
    return observation.independent_certificate_accepted === true;
  }
  function node(tag, content, className) {
    const n = document.createElement(tag); if (content !== undefined) n.textContent = String(content);
    if (className) n.className = className; return n;
  }
  function math(parent, latex, display) { parent.append(node('span', (display ? '\\[' : '\\(') + latex + (display ? '\\]' : '\\)'), 'gcts-math')); }
  function code(parent, value) { parent.append(node('pre', JSON.stringify(value, null, 2), 'gcts-exact-json')); }
  function paragraph(parent, value, cls) { const n = node('p', value, cls); parent.append(n); return n; }
  function tile(entry, formulaLayer, referenceLayer) {
    const p = entry.placement, wrap = node('div', undefined, 'gcts-tile-panel');
    const square = node('div', undefined, 'gcts-literal-square');
    square.setAttribute('aria-label', 'Translation-only tile at proof row ' + (entry.row + 1));
    paragraph(square, 'Square tile ' + (entry.row + 1), 'gcts-tile-title');
    const occupancy = node('div', undefined, 'gcts-occupancy');
    math(occupancy, 't: ' + p.t.map(q => '(' + q[0] + ',' + q[1] + ')\\mapsto ' + q[2]).join(',\\;'));
    square.append(occupancy);
    const output = node('div', undefined, 'gcts-output-layer');
    paragraph(output, 'Blue output marking'); math(output, 'm(1,' + entry.row + ')=' + entry.outputCode);
    output.hidden = !formulaLayer; square.append(output);
    const sources = node('div', undefined, 'gcts-reference-layer');
    paragraph(sources, 'Purple ordered reference offsets'); math(sources, '\\left(' + entry.offsets.join(',') + '\\right)');
    p.m.filter(q => q[0] >= 2).forEach(q => math(sources, 'm(' + q[0] + ',' + q[1] + ')=' + q[2]));
    sources.hidden = !referenceLayer; square.append(sources); wrap.append(square);
    const details = node('details'); details.append(node('summary', 'All literal point values and identity'));
    code(details, {id: p.id, key: p.key, orientation: 'identity', transform: p.identity_preimage.transform, t: p.t, m: p.m});
    wrap.append(details); return wrap;
  }
  function typeset(targets) {
    if (global.MathJax && typeof global.MathJax.typesetPromise === 'function') {
      const ready = global.MathJax.startup && global.MathJax.startup.promise || Promise.resolve();
      return ready.then(() => global.MathJax.typesetPromise(targets)).catch(error => { throw new Error('MathJax typesetting failed: ' + error.message); });
    }
    return Promise.resolve(); // Root supplies the established renderer.
  }
  function installStyle() {
    if (document.getElementById('gcts-geometry-reader-style')) return;
    const style = node('style', '#reader .gcts-proof-row{display:grid;grid-template-columns:210px minmax(0,1fr);gap:18px;margin:18px 0;padding:14px;border:1px solid #c9d1dd;border-radius:8px}#reader .gcts-literal-square{box-sizing:border-box;width:190px;height:190px;border:2px solid #263448;padding:8px;display:flex;flex-direction:column;justify-content:space-between;overflow:auto;background:white}#reader .gcts-literal-square p{margin:2px 0;font-size:11px}#reader .gcts-literal-square .gcts-math{font-size:12px}#reader .gcts-output-layer{border-left:4px solid #2463b8;background:#eaf2ff;padding:4px}#reader .gcts-reference-layer{border-left:4px solid #8651bd;background:#f3eafb;padding:4px}#reader .gcts-exact-json{white-space:pre-wrap;overflow-wrap:anywhere;max-height:24rem;overflow:auto;font-size:12px}#reader .gcts-pending{border-left:4px solid #b57600;padding:8px;background:#fff6df}#reader .gcts-error{color:#991b1b;border:1px solid #991b1b;padding:10px}#reader .gcts-math{overflow-wrap:anywhere}#reader .gcts-tile-panel details{font-size:12px;margin-top:7px}@media(max-width:640px){#reader .gcts-proof-row{grid-template-columns:1fr}#reader .gcts-literal-square{width:190px;height:190px}}');
    style.id = 'gcts-geometry-reader-style'; document.head.append(style);
  }
  function showTrace(observation, selected, target) {
    target.replaceChildren();
    const events = Array.isArray(observation.events) ? observation.events : [];
    let event = null, state, title;
    if (selected === 'initial') { state = observation.initial_state; title = 'Saved initial state'; }
    else if (selected === 'terminal') { state = observation.terminal_state; title = 'Saved terminal state'; }
    else {
      const index = Number(selected);
      event = events[index];
      if (!event) { paragraph(target, 'No saved trace event is supplied for this observation.'); return; }
      state = event.state; title = 'Saved trace event ' + (index + 1) + ' of ' + events.length;
    }
    paragraph(target, title + '. This is a search-state projection, not a proof.');
    paragraph(target, observation.independent_trace_accepted === true ? 'Root flags this trace as independently accepted.' : 'Independent trace acceptance is pending.');
    if (state && state.projection) {
      const projection = state.projection, graph = projection.graph;
      paragraph(target, 'Exact saved state digest: ' + String(state.full_semantic_sha256));
      if (graph) {
        const declared = {};
        for (const key of ['order', 'totals', 'marks', 'selected_generations', 'roots', 'excluded', 'domains']) {
          if (Object.prototype.hasOwnProperty.call(graph, key)) declared[key] = graph[key];
        }
        code(target, declared);
      } else paragraph(target, 'This event has no graph projection.');
      if (Object.prototype.hasOwnProperty.call(projection, 'hint_states')) { paragraph(target, 'Saved hint states'); code(target, projection.hint_states); }
    } else paragraph(target, 'This event has no saved state projection.');
    if (event) {
      const decision = {};
      for (const key of Object.keys(event)) if (key !== 'state') decision[key] = event[key];
      paragraph(target, 'Saved decision/event fields'); code(target, decision);
    }
    const full = node('details'); full.append(node('summary', event ? 'Complete saved event (all fields)' : 'Complete saved state (all fields)')); code(full, event || state); target.append(full);
  }
  function mount(data) {
    need(data && Array.isArray(data.formula_codes) && Array.isArray(data.recipes)
      && Array.isArray(data.hypotheses) && Array.isArray(data.observations), 'Root visual-data schema required');
    // Decode only displayed formulas; the full registry is not eagerly typeset.
    data.hypotheses.forEach(formulaLatex); formulaLatex(data.target);
    const elements = {};
    IDs.forEach(id => { elements[id] = document.getElementById(id); need(elements[id], 'Missing reader element #' + id); });
    need(elements.observation.tagName === 'SELECT' && elements['trace-event'].tagName === 'SELECT', 'Reader selectors must be SELECT elements');
    installStyle();
    elements.observation.replaceChildren();
    data.observations.forEach((o, index) => { const option = node('option', o.id + ' — ' + o.mode); option.value = String(index); elements.observation.append(option); });
    function render() {
      const observation = data.observations[Number(elements.observation.value) || 0];
      need(observation, 'No supplied observation');
      const proof = elements['proof-view'], trace = elements['trace-view'];
      if (global.MathJax && typeof global.MathJax.typesetClear === 'function') global.MathJax.typesetClear([proof]);
      proof.replaceChildren(); trace.replaceChildren();
      const supplied = value => value === undefined ? 'not supplied' : JSON.stringify(value);
      paragraph(proof, 'Observation ' + observation.id + ': ' + observation.status + '. Attempts: ' + supplied(observation.attempts) + '; saved seconds: ' + supplied(observation.seconds) + '.');
      if (data.scope) paragraph(proof, data.scope);
      if (observation.independent_scope) paragraph(proof, observation.independent_scope);
      const metrics = node('details'); metrics.append(node('summary', 'Exact saved node count, graph metrics and limits'));
      code(metrics, {node_count: observation.node_count, graph_metrics: observation.graph_metrics, limits: observation.limits}); proof.append(metrics);
      paragraph(proof, 'Hypotheses'); data.hypotheses.forEach(f => { const p = node('p'); math(p, formulaLatex(f)); proof.append(p); });
      paragraph(proof, 'Target'); const goal = node('p'); math(goal, formulaLatex(data.target)); proof.append(goal);
      const rows = certificateRows(data, observation);
      if (rows === null) {
        paragraph(proof, 'No point certificate was supplied. The recorded status and trace below do not establish a proof.', 'gcts-pending');
      } else {
        paragraph(proof, accepted(data, observation) ? 'Root supplied an explicit independent-acceptance flag for this certificate.' : 'Literal certificate supplied; independent acceptance is pending. These display checks do not replace the proof checker.', 'gcts-pending');
        paragraph(proof, 'Each square is one actual placement, ordered by saved row. All orientations are identity; tiles move by translation only. Blue marks carry the output formula code. Purple marks carry ordered references to earlier rows and their negative relative offsets.');
        for (const entry of rows) {
          const card = node('article', undefined, 'gcts-proof-row'); card.append(tile(entry, elements['formula-layer'].checked, elements['reference-layer'].checked));
          const words = node('div'); words.append(node('h3', 'Row ' + (entry.row + 1)));
          const f = node('p'); math(f, formulaLatex(entry.placement.command.formula)); words.append(f);
          paragraph(words, formulaEnglish(entry.placement.command.formula));
          paragraph(words, ruleEnglish(entry.placement.command, entry.refs, entry.recipe));
          if (entry.refs.length) {
            paragraph(words, 'Ordered receptor premises:'); entry.refs.forEach((ref, index) => {
              const p = node('p', 'Input ' + (index + 1) + ' from row ' + (ref + 1) + ': '); math(p, formulaLatex(entry.recipe.ordered_premise_formulas[index])); words.append(p);
            });
          }
          const commands = node('details'); commands.append(node('summary', 'Exact saved command and primitive recipe witness'));
          code(commands, {command: entry.placement.command, recipe_id: entry.recipe.id, primitive_witness: entry.recipe.primitive_witness}); words.append(commands);
          card.append(words); proof.append(card);
        }
        const local = observation.decoded_certificate && observation.decoded_certificate.local_certificate;
        if (local && Array.isArray(local.proof)) {
          const expansion = node('details'); expansion.append(node('summary', 'Exact decoded local certificate commands'));
          local.proof.forEach((command, index) => {
            const row = node('div'); paragraph(row, 'Primitive command ' + (index + 1));
            if (command.formula) math(row, formulaLatex(command.formula));
            code(row, command); expansion.append(row);
          });
          proof.append(expansion);
        }
      }
      const selector = elements['trace-event'], events = Array.isArray(observation.events) ? observation.events : [];
      selector.replaceChildren();
      if (observation.initial_state) { const option = node('option', 'Initial state'); option.value = 'initial'; selector.append(option); }
      events.forEach((event, index) => { const option = node('option', 'Event ' + (index + 1) + (event.kind ? ' — ' + event.kind : '')); option.value = String(index); selector.append(option); });
      if (observation.terminal_state) { const option = node('option', 'Terminal state'); option.value = 'terminal'; selector.append(option); }
      selector.disabled = !selector.options.length;
      selector.onchange = () => showTrace(observation, selector.value, trace);
      showTrace(observation, selector.value, trace);
      return typeset([proof]);
    }
    const guarded = () => Promise.resolve().then(render).catch(error => {
      elements['proof-view'].replaceChildren(node('p', error.message, 'gcts-error'));
      elements['trace-view'].replaceChildren();
    });
    elements.observation.onchange = guarded;
    elements['formula-layer'].onchange = guarded; elements['reference-layer'].onchange = guarded;
    return guarded();
  }
  async function start(options) {
    const url = options && options.url || 'visual-data.json';
    const response = await fetch(url, {cache: 'no-store'});
    need(response.ok, 'Could not load root visual-data.json: HTTP ' + response.status);
    return mount(await response.json());
  }
  global.GCTSGeometryReader = Object.freeze({start, mount, formulaLatex, formulaEnglish, certificateRows, ruleEnglish, accepted});
  if (typeof document !== 'undefined' && !global.GCTS_GEOMETRY_READER_NO_AUTOSTART) {
    const automatic = () => {
      const reader = document.getElementById('reader');
      if (!reader) return;
      start({url: reader.dataset.visualUrl || 'visual-data.json'}).catch(error => {
        const destination = document.getElementById('proof-view') || reader;
        destination.replaceChildren(node('p', error.message, 'gcts-error'));
      });
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', automatic, {once: true});
    else automatic();
  }
})(typeof window === 'undefined' ? globalThis : window);
