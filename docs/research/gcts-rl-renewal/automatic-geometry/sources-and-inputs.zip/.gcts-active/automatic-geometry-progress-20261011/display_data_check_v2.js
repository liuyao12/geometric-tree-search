'use strict';
// Display correspondence only. No graph/search/checker or scientific engine imports.
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');
const started = process.hrtime.bigint();
const root = process.cwd();
const prefix = 'docs/research/gcts-rl-renewal/automatic-geometry/';
const visualPath = path.join(root, prefix, 'visual-data.json');
const viewerPath = path.join(root, '.gcts-active/automatic-geometry-reader-source-v4-20261011/viewer.js');
require(viewerPath);
const api = global.GCTSGeometryReader;
const data = JSON.parse(fs.readFileSync(visualPath, 'utf8'));
const need = (value, message) => { if (!value) throw new Error(message); };
const pin = file => {
  const bytes = fs.readFileSync(file);
  return {path:path.relative(root,file),sha256:crypto.createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length};
};
const observations = [];
for (const observation of data.observations) {
  need(observation.point_certificate === null && api.certificateRows(data, observation) === null, 'No invented certificate');
  need(observation.independent_certificate_accepted === false && observation.independent_trace_accepted === true, 'Explicit independent scope');
  const deepest = api.deepestSelection(observation);
  const checked = [];
  for (const [label, state] of [['initial',observation.initial_state],['deepest',observation.events[Number(deepest)].state],['terminal',observation.terminal_state]]) {
    const snapshot = api.snapshotRows(data,state);
    need(snapshot.rows.length === state.projection.graph.order.length, 'Every actual selected square retained');
    need(snapshot.marks.length === state.projection.graph.marks.length, 'Every exact assigned marking retained');
    const exterior = snapshot.marks.filter(mark => mark[0] === 1 && mark[1] < 0);
    need(exterior.length === 23 && exterior.every(mark => mark[2] === -1), 'All literal exterior sentinels retained');
    snapshot.rows.forEach(row => { api.formulaLatex(row.formula); const english = api.formulaEnglish(row.formula); need(row.formula[0] === 'bot' || english.includes(String.raw`\(`), 'Actual mathematical identifiers use inline LaTeX'); });
    checked.push({label,rows:snapshot.rows.length,marks:snapshot.marks.length,exterior:exterior.length,pendingOrderedInputs:snapshot.rows.reduce((count,row)=>count+row.refs.filter(ref=>!ref.selected).length,0)});
  }
  observations.push({id:observation.id,defaultEventIndex:Number(deepest),checked});
}
const receipt = {
  status:'passed_representative_actual_display_data_correspondence',
  inputs:[pin(visualPath),pin(viewerPath),pin(__filename)],
  observations,
  actualDisplayStates:6,
  actualCertificates:0,
  scientificImports:0,
  searches:0,
  logicalOrNativeAcceptance:0,
  scope:'Actual initial/deepest/terminal states only; pure reader display functions. Whole trace validity comes from the separately owned independent audit. No DOM or MathJax claim.',
  seconds:Number(process.hrtime.bigint()-started)/1e9,
  browserQA:'pending live validation'
};
fs.writeFileSync(path.join(__dirname,'actual-display-data-validation-v2.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt));
