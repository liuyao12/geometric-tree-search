Check a whole searched proof in one Wang rectangle

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/connected_study_v1.py
  python3 -I -S -B source/connected_high_v1.py
  python3 -I -S -B publication/render_v1.py

The first command recompiles and replays the main comparison and rejects
the altered controls. The second replays the separately budgeted Hilbert
frame. Either accepts --build to regenerate its data. The last command
regenerates the reader. Replay is streamed and may take a few minutes.
The manifest gives SHA-256 for each included input and result.
