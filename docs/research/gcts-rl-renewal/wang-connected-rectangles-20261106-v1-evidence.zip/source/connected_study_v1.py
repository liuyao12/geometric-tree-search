"""Replay previously searched proofs as connected rectangles in the published palette."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source")]
from boundary_kernel_v1 import build
from connected_frame_v1 import run
from connected_wire_v1 import audit, canonical, compact
from decode_v1 import records
from definition_check_v1 import check
from definitions_v1 import compile_case
from fair_search_v1 import Search
from herbrand_v1 import signature
from induction_cases_v1 import arithmetic, hilbert, induction
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded

STEP_LIMIT = 600_000_000
EVENT_LIMIT = 2_000_000
EXTENDED_STEPS = 12_000_000_000
EXTENDED_EVENTS = 6_000_000


def read(name):
    return json.loads((ROOT / "input" / (name + "-v1.json")).read_text())


def freeze(value):
    if isinstance(value, dict):
        return {k: freeze(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return tuple(map(freeze, value))
    return value


def stress():
    term = ["a"]
    for i in range(16):
        term = ["f", term, ["b" if i % 3 else "c"]]
    def atom(p, arg):
        return ["atom", p, arg]
    def arrow(p, q):
        return ["all", "?x", "U", ["implies", atom(p, "?x"), atom(q, "?x")]]
    original = dict(id="closed-term-transport", sorts=["U"], equality=False,
                    functions={**{k: [[], "U"] for k in "abc"}, "f": [["U", "U"], "U"]},
                    predicates={k: ["U"] for k in "PQR"},
                    premises=[atom("P", term), arrow("P", "Q"), arrow("Q", "R")], goal=atom("R", term))
    normal, translation = compile_case(original)
    result = Search(normal, True).search(600)
    assert result["status"] == "PROVED"
    return original, normal, translation, result["proof"]


def cases():
    names = {"binary-witness-in-goal", "binary-witness-to-discover", "typed-shadowed-witness",
             "two-points-determine-a-line"}
    for row in read("fair-study")["rows"]:
        if row["original"]["id"] in names:
            yield row["original"], row["normal"], row["translation"], row["runs"]["demand"]["proof"]
    earlier = read("induction-proofs")
    zero = earlier["arithmetic"][0]
    assert zero["id"] == "zero-left" and not zero["parents"]
    for source, proof in zip(induction(next(arithmetic()), zero["variable"]), zero["proofs"], strict=True):
        yield source, proof["compiled"], proof["translation"], proof["proof"]["lines"]
    geo = earlier["geometry"]["proof"]
    yield hilbert(), geo["compiled"], geo["translation"], geo["proof"]["lines"]
    yield stress()


def controls(machine, wire):
    prefix, word = wire["prefix"], wire["word"]
    lines = records(word[:-1])
    top, out = lines[-1].split("/")
    label, left, right, pivot = top.split(":")
    assert label.startswith("R") and left != right and not out
    wrong_parent = ";".join((*lines[:-1], f"{label}:{right}:{right}:{pivot}/")) + ";!"
    i, line = next((i, r) for i, r in enumerate(lines) if r.startswith("G") and "=" in r)
    head, body = line.split("/")
    before, _ = head.rsplit(":", 1)
    wrong_term = ";".join((*lines[:i], before + ":(111111111111111111111111111111.)/" + body, *lines[i + 1:])) + ";!"
    unfinished = ";".join(lines[:-1]) + ";!"
    results = {}
    for name, bad in (("changed parent", wrong_parent), ("changed substitution", wrong_term),
                      ("missing contradiction", unfinished)):
        assert bad != word
        result = run(machine, prefix, bad, STEP_LIMIT, EVENT_LIMIT, checked=True)
        assert result["status"] == "REJECT"
        results[name] = {k: result[k] for k in ("status", "last", "steps")}
    return results


def study():
    machine = build().compile()
    assert machine.digest() == PUBLISHED_MACHINE
    rows, negative = [], None
    alias_rejected = False
    for original, normal, translation, proof in cases():
        name = original["id"]
        check(original, normal, translation)
        functions, predicates, schemata = signature(normal)
        sources, types = guarded(schemata, functions, normal["sorts"])
        proof = freeze(proof)
        assert proof and not proof[-1]["clause"]
        wire = compact(sources, proof)
        assert audit(wire, sources, proof) == len(proof)
        if name == "closed-term-transport":
            macro = next(k for k, v in wire["symbols"].items() if v[0] == "macro")
            wrong = dict(wire, symbols={**wire["symbols"], macro: ("macro", ("a",))})
            try:
                audit(wrong, sources, proof)
            except AssertionError:
                alias_rejected = True
            else:
                raise AssertionError("An altered expansion passed the source binding")
        encodings = canonical(normal, sources, functions, predicates, types, proof)
        encodings["compact"] = wire["prefix"], wire["word"]
        results = {}
        for label, (prefix, word) in encodings.items():
            result = run(machine, prefix, word, STEP_LIMIT, EVENT_LIMIT, checked=label == "compact")
            assert result["status"] in ("ACCEPT", "BOUNDED")
            results[label] = dict(result, prefix_chars=len(prefix), proof_chars=len(word))
            print(name, label, result["status"], result["steps"], result["events"],
                  len(prefix) + len(word), flush=True)
        if results["compact"]["status"] == "ACCEPT":
            assert len(results["compact"]["checkpoints"]) == len(proof)
            extended = None
        else:
            extended = run(machine, wire["prefix"], wire["word"], EXTENDED_STEPS, EXTENDED_EVENTS, checked=True)
            assert extended["status"] in ("ACCEPT", "BOUNDED")
            if extended["status"] == "ACCEPT":
                assert len(extended["checkpoints"]) == len(proof)
            print(name, "extended", extended["status"], extended["steps"], extended["events"],
                  len(extended["checkpoints"]), flush=True)
        if name == "typed-shadowed-witness":
            negative = controls(machine, wire)
        rows.append(dict(original=original, translation=translation, normal=normal,
                         proof=proof, wire=wire, runs=results, extended=extended))
    assert negative is not None and alias_rejected
    return dict(palette=PUBLISHED_MACHINE, step_limit=STEP_LIMIT, event_limit=EVENT_LIMIT,
                extended_steps=EXTENDED_STEPS, extended_events=EXTENDED_EVENTS,
                controls=negative, alias_rejected=alias_rejected, rows=rows)


def main():
    if not __debug__:
        raise RuntimeError("Wang checks require assertions")
    body = (json.dumps(study(), sort_keys=True, separators=(",", ":")) + "\n").encode()
    output = ROOT / "data/connected-v1.json.gz"
    if "--build" in sys.argv:
        output.write_bytes(gzip.compress(body, mtime=0))
    else:
        assert gzip.decompress(output.read_bytes()) == body


if __name__ == "__main__":
    main()
