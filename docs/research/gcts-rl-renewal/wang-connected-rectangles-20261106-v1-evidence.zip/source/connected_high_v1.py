"""Run the separately budgeted connected Hilbert incidence certificate."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source")]
from boundary_kernel_v1 import build
from connected_frame_v1 import run
from connected_study_v1 import freeze
from connected_wire_v1 import audit
from definition_check_v1 import check
from herbrand_v1 import signature
from native_v1 import PUBLISHED_MACHINE
from study_v1 import guarded

CASE = "two-points-determine-a-line"
LIMIT = 60_000_000_000
EVENTS = 14_000_000


def main():
    if not __debug__:
        raise RuntimeError("Wang checks require assertions")
    study = json.loads(gzip.decompress((ROOT / "data/connected-v1.json.gz").read_bytes()))
    row, = (row for row in study["rows"] if row["original"]["id"] == CASE)
    check(row["original"], row["normal"], row["translation"])
    functions, _, schemata = signature(row["normal"])
    sources, _ = guarded(schemata, functions, row["normal"]["sorts"])
    wire, proof = freeze(row["wire"]), freeze(row["proof"])
    assert audit(wire, sources, proof) == len(proof)
    machine = build().compile()
    assert machine.digest() == study["palette"] == PUBLISHED_MACHINE
    result = run(machine, wire["prefix"], wire["word"], LIMIT, EVENTS, checked=True)
    assert result["status"] in ("ACCEPT", "BOUNDED")
    if result["status"] == "ACCEPT":
        assert len(result["checkpoints"]) == len(proof)
    payload = dict(case=CASE, limit=LIMIT, events_limit=EVENTS, result=result)
    body = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode()
    out = ROOT / "data/connected-high-v1.json.gz"
    print(CASE, result["status"], result["steps"], result["events"], len(result["checkpoints"]), flush=True)
    if "--build" in sys.argv:
        out.write_bytes(gzip.compress(body, mtime=0))
    else:
        assert gzip.decompress(out.read_bytes()) == body


if __name__ == "__main__":
    main()
