"""Render connected frame costs and the logical records at their physical rows."""
from html import escape
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "wang/source")]
from herbrand_v1 import frozen
from proof_views_v1 import clause, explanation, expression, formula, math, tile_svg

NAME = "wang-connected-rectangles-20261106-v1"
TITLE = "Check a whole searched proof in one Wang rectangle"
LABELS = {
    "binary-witness-in-goal": "Nested term named in the goal",
    "binary-witness-to-discover": "Existential goal with hidden terms",
    "typed-shadowed-witness": "Typed witness with shadowed variables",
    "two-points-determine-a-line": "Hilbert incidence uniqueness",
    "between-on-the-line": "Hilbert betweenness on a line",
    "zero-left-base": "Peano zero on the left, induction base",
    "zero-left-step": "Peano zero on the left, induction step",
    "closed-term-transport": "Transport a repeated closed term",
}


def number(n):
    return f"{n:,}"


def state(run):
    if run is None:
        return "<td>—</td>"
    accept = run["status"] == "ACCEPT"
    return (f'<td><strong class="{"accept" if accept else "bounded"}">'
            f'{"Accepted" if accept else "At limit"}</strong><small>{number(run["steps"])} steps</small></td>')


def table(rows):
    result = []
    for row in rows:
        name = row["original"]["id"]
        a, b, c = (row["runs"][k] for k in ("canonical", "sliced", "compact"))
        sizes = (a["prefix_chars"] + a["proof_chars"], c["prefix_chars"] + c["proof_chars"])
        result.append(f'<tr><th scope="row">{LABELS[name]}</th><td>{len(row["proof"])}</td>'
                      f'<td>{number(sizes[0])} to {number(sizes[1])}</td>'
                      + "".join(map(state, (a, b, c, row["extended"]))) + "</tr>")
    return "".join(result)


def draw_row(point, tile_types):
    uses = []
    for i, tile in enumerate(frozen(point["row"])):
        number = tile_types.setdefault(tile, len(tile_types))
        uses.append(f'<use href="#wang-{number}" x="{36 * i}"/>')
    return (f'<figure><svg role="img" aria-label="Nine actual Wang squares" viewBox="0 0 324 36">'
            f'{"".join(uses)}</svg><figcaption>Physical row {point["step"] + 1:,}, '
            f'columns {point["column"]:,} to {point["column"] + 8:,}. Hover to read exact edge labels.</figcaption></figure>')


def proof_view(row, run, tile_types, selected=False):
    name = row["original"]["id"]
    original = row["original"]
    body = []
    prior = 1
    records = row["wire"]["word"][:-2].split(";")
    for line, point, word in zip(row["proof"], run["checkpoints"], records, strict=True):
        end = point["step"] + 1
        body.append(f'<li><div class="formula">{math(clause(line["clause"]))}</div><div>{explanation(line)}</div>'
                    f'<details class="tiles"><summary>Show Wang squares from rows {prior + 1:,} to {end:,}</summary>'
                    f'{draw_row(point, tile_types)}<pre><code>{escape(word)};</code></pre></details></li>')
        prior = end
    sources = "".join(f'<li>{math(formula(p))}</li>' for p in original["premises"])
    prefix, word = (escape(row["wire"][k]) for k in ("prefix", "word"))
    open_ = " open" if selected else ""
    return (f'<details class="proof"{open_}><summary>{LABELS[name]} · {len(body)} logical lines</summary>'
            f'<p>One connected frame of {run["columns"]:,} columns and {run["rows"]:,} rows.</p>'
            f'<div class="grid"><div><h3>Hypotheses</h3><ul class="formula">{sources}</ul></div>'
            f'<div><h3>Conclusion</h3><p class="formula">{math(formula(original["goal"]))}</p></div></div>'
            f'<ol class="steps">{"".join(body)}</ol><details><summary>Read the source and proof word</summary>'
            f'<pre><code>{prefix}\n{word}</code></pre></details></details>')


def main():
    data = json.loads(gzip.decompress((ROOT / "data/connected-v1.json.gz").read_bytes()))
    high = json.loads(gzip.decompress((ROOT / "data/connected-high-v1.json.gz").read_bytes()))
    frames = [(r, high["result"] if r["original"]["id"] == high["case"] else r["extended"] or r["runs"]["compact"])
              for r in data["rows"]]
    accepted = [(r, frame) for r, frame in frames if frame["status"] == "ACCEPT"]
    stress, exemplar = next((r, c) for r, c in accepted if r["original"]["id"] == "closed-term-transport")
    accepted.sort(key=lambda pair: (pair[0] is not stress, pair[0]["original"]["id"]))
    shapes = {}
    figure = draw_row(exemplar["checkpoints"][-1], shapes)
    readers = "".join(proof_view(r, c, shapes, r is stress) for r, c in accepted)
    definitions = "".join(tile_svg(tile, i) for tile, i in shapes.items())
    macros = [(code, record[1]) for code, record in stress["wire"]["symbols"].items() if record[0] == "macro"]
    code, example = max(macros, key=lambda pair: len(repr(pair[1])))
    a = stress["runs"]["canonical"]
    h = high["result"]
    verdict = (f'accepted all {len(h["checkpoints"])} logical lines in {h["steps"]:,} tape steps'
               if h["status"] == "ACCEPT" else
               f'reached the limit after checking {len(h["checkpoints"])} logical lines')
    long = f"The separate Hilbert incidence run {verdict}. Its cap was 60 billion steps and 14 million events."
    values = dict(title=TITLE, stem=NAME, table=table(data["rows"]), figure=figure, readers=readers,
                  verified=str(len(accepted)), total=str(len(data["rows"])),
                  proof_lines=number(sum(len(r["proof"]) for r, _ in accepted)),
                  shapes='<svg class="palette" aria-hidden="true" width="0" height="0"><defs>' + definitions + '</defs></svg>',
                  alias=f"<code>({code}.)</code>", term=math(expression(example)),
                  stress_raw=number(a["prefix_chars"] + a["proof_chars"]),
                  stress_compact=number(exemplar["prefix_chars"] + exemplar["proof_chars"]),
                  stress_steps=number(exemplar["steps"]), high=long)
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.palette{position:absolute;width:0;height:0;overflow:hidden;border:0}
td small{display:block;color:#42606f}.accept{color:#145c49}.bounded{color:#685324}
.steps li{padding:.45rem .15rem;border-bottom:1px solid #d3e0e5}
.proof>ol{padding-left:1.8rem}.formula{overflow:auto}
.tiles{margin:.4rem 0}.tiles summary{font-size:.9rem}
#rectangle figure,.tiles figure{max-width:31rem}
.frame-map{display:flex;gap:.15rem;align-items:stretch;margin:.85rem 0}
.frame-map span{padding:.65rem;font-weight:700;flex:1;border-radius:.25rem}
.frame-map .source{background:#cde1f1}.frame-map .word{background:#cde9d9}
.frame-map .cap{background:#eedebf}
@media(max-width:32rem){.frame-map{flex-direction:column}}
</style>""")
    body = (ROOT / "publication/connected-body-v1.html").read_text()
    for key, value in values.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
