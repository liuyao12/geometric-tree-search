const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-connected-rectangles-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#reader mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison tbody tr").count(), 8);
      assert.equal(await page.locator("#rectangle svg use").count(), 9);
      const last = page.locator("#reader .proof[open] .steps > li").last();
      await last.locator("summary").click();
      await last.locator("svg").waitFor();
      assert.equal(await last.locator("svg > use").count(), 9);
      assert.ok(await last.locator("svg > use").first().evaluate(node => node.getBBox().width >= 36));
      assert.match(await last.locator(".formula").textContent(), /⊥/);
      assert.match(await last.locator("pre").innerText(), /^R/);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      console.log("Verified", width, "px, connected proof record and exact tile row.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
