"""Paired checks and learned ordering for seeded covers with open outer boundaries."""
from collections import defaultdict
from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Bank,Inventory,Region,solve as fixed_cover
from cases_v1 import frozen,load,patch_ring,rhomb_grid
from clipping_v1 import Core, sign, twice
from geometry_v1 import add,mul,sub
from open_cases_v1 import geometries,seam_core,shared
from open_cover_v1 import solve,verify
import model_v1 as penrose

NODE_LIMIT=2000
POOL_LIMIT=4000
ORDERS=("cluster","single")


def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,sort_keys=True,separators=(",",":"))+"\n")


def prepare(g,row):
    return Core(Region(g,frozen(row["envelope"])),frozen(row["core"])),frozen(row["seed"])


def cluster_library(g,units,record):
    models=[]
    for outline in frozen(record["cluster_outlines"]):
        result=fixed_cover(Region(g,outline),units,"cluster-donor")
        assert result["status"]=="POSITIVE"
        g.verify(outline,result["patch"])
        models.append(dict(outline=outline,patch=result["patch"],counts=result["counts"]))
    return Inventory(g,[x["patch"] for x in models]),models


class Policy:
    def __init__(self,wide=False):
        self.rng=Random(44417)
        self.costs=defaultdict(lambda:defaultdict(list))
        self.wide=wide

    def context(self,core,seed):
        ports=sum(core.forces(e) for e in core.g.boundary(seed))
        total=tuple(map(sum,zip(*(twice(poly) for poly in core.polygons))))
        big=self.wide and core.g.kind=="penrose" and sign(sub(total,(3,0)))>0
        return core.g.kind,int(big),int(ports>1)

    def choose(self,core,seed,train=False):
        context=self.context(core,seed)
        stats=self.costs[context]
        if train:
            for order in ORDERS:
                if not stats[order]:
                    return order
            if self.rng.random()<.25:
                return self.rng.choice(ORDERS)
        def rank(order):
            scores=stats.get(order) or self.costs[(*context[:2],2)].get(order)
            return sum(scores)/len(scores) if scores else 1e8
        return min(ORDERS,key=rank)

    def update(self,core,seed,order,cost):
        key=self.context(core,seed)
        self.costs[key][order].append(cost)
        self.costs[(*key[:2],2)][order].append(cost)


def training_cases(g):
    if g.kind=="turtle":
        p1=next(frozen(x["patch"]) for x in load("input/growth-v1.json")["levels"] if x["id"]=="T1")
        pool=sorted(p1)
        for i in range(12):
            patch=tuple(g.shift(t,(i+5,4-i)) for t in pool)
            seed=patch[i%len(patch)]
            env=patch_ring(g,patch)
            ports=shared(g,patch,seed)
            j=i%len(ports)
            radii=(1,Fraction(1,2),Fraction(1,32)) if i%2 else (Fraction(1,16),)
            polys=[seam_core(g,env,ports[j],radii)]
            if i%3==2 and len(ports)>1:
                polys.append(seam_core(g,env,ports[(j+1)%len(ports)]))
            yield env,seed,tuple(polys),5
    else:
        for i in range(12):
            width=1+i%2
            original=rhomb_grid(2+(i%3==2),2,width)
            offset=(i+2,-i,0,1)
            patch=tuple(g.shift(t,offset) for t in original)
            seed=g.shift(penrose.rhomb(g.zero,0,width),offset)
            env=patch_ring(g,patch)
            ports=shared(g,patch,seed)
            if i%3==1:
                u,v=(penrose.DIRECTIONS[j] for j in (0,width))
                d=8
                raw=tuple(add(mul(d,offset),add(mul(a,u),mul(b,v)))
                          for a,b in ((2,2),(11,2),(11,11),(2,11)))
                polys=((d,raw),)
            else:
                polys=tuple(seam_core(g,env,e) for e in (ports if i%3==2 else ports[:1]))
            yield env,seed,polys,5


def large_penrose_training(g):
    for i in range(8):
        width=1+i%2
        patch0=rhomb_grid(5,3,width)
        offset=(i+4,-2,1-i,0)
        patch=tuple(g.shift(t,offset) for t in patch0)
        seed=g.shift(penrose.rhomb(g.zero,0,width),offset)
        u,v=(penrose.DIRECTIONS[k] for k in (0,width))
        upper=13+i%3
        core=(4,tuple(add(mul(4,offset),add(mul(a,u),mul(b,v)))
                      for a,b in ((1,1),(upper,1),(upper,5),(1,5))))
        yield patch_ring(g,patch),seed,(core,),10


def train(g,library,policy,large=False):
    rows=[]
    cases=large_penrose_training(g) if large else training_cases(g)
    for i,(env,seed,polys,cap) in enumerate(cases):
        core=Core(Region(g,env),polys)
        order=policy.choose(core,seed,True)
        result=solve(core,library,seed,f"training-{i+1}",Bank(),cap=cap,order=order,
                     node_limit=120 if large else NODE_LIMIT,pool_limit=2000 if large else POOL_LIMIT)
        counts=result["counts"]
        status=result["status"]
        assert status in ("POSITIVE","BOUNDED","NEGATIVE")
        cost=(counts.get("placement_checks",0)+counts.get("pool_probes",0)/20
              +20*counts["nodes"]+100*len(result.get("patch",())))
        if status!="POSITIVE":
            cost+=10000
        policy.update(core,seed,order,cost)
        rows.append(dict(order=order,cost=cost,status=status,counts=counts,envelope=env,seed=seed,core=polys,cap=cap))
    return rows


def main():
    spec=load("input/open-cases-v1.json")
    policy=Policy()
    wide=Policy(wide=True)
    rows=[]
    for name,g in geometries().items():
        record=spec[name]
        units=Inventory(g)
        library,cluster_donors=cluster_library(g,units,record)
        bank=Bank()
        donor=record["donor"]
        c,seed=prepare(g,donor)
        res=solve(c,units,seed,donor["id"],bank,cap=donor["cap"],node_limit=NODE_LIMIT)
        assert res["status"]=="NEGATIVE" and len(bank.donors)==1
        assert next(iter(bank.donors.values()))["edge"]==frozen(donor["port"])
        episodes=train(g,library,policy)
        wide_episodes=train(g,library,wide)
        if name=="penrose":
            wide_episodes+=train(g,library,wide,large=True)
        evaluations=[]
        for case in record["queries"]:
            arms=[]
            for arm,inventory,marks,ranking in (("plain",units,None,None),("marked",units,bank,None),
                                        ("clusters",library,bank,None),("bandit",library,bank,policy),
                                        ("wide-bandit",library,bank,wide)):
                core,seed=prepare(g,case)
                order=ranking.choose(core,seed) if ranking else "cluster"
                inherited=deepcopy(marks) if marks else None
                result=solve(core,inventory,seed,case["id"],inherited,cap=case["cap"],order=order,
                             node_limit=NODE_LIMIT,pool_limit=POOL_LIMIT)
                assert result["status"]==case["expected"], (name,case["id"],arm,result)
                if result["status"]=="POSITIVE":
                    verify(core,seed,result["patch"],result["areas"],result["boundary"],case["cap"])
                    if case["id"]!="relaxed-port":
                        assert set(result["boundary"])!=core.region.edges
                if inherited:
                    result["marks"]=dict(donors=inherited.donors,hits=inherited.hits)
                arms.append(dict(arm=arm,order=order,**result))
                print(json.dumps(dict(kind=name,case=case["id"],arm=arm,order=order,status=result["status"],
                                      tiles=len(result.get("patch",())),counts=result["counts"]),sort_keys=True),flush=True)
            evaluations.append(dict(query=case,arms=arms))
        remote=next(q for q in record["queries"] if q["id"]=="remote-core")
        c,seed=prepare(g,remote)
        cutoff=solve(c,units,seed,"pool-cutoff",cap=remote["cap"],node_limit=NODE_LIMIT,pool_limit=1)
        assert cutoff["status"]=="BOUNDED" and cutoff["reason"]=="PoolLimit"
        rows.append(dict(kind=name,donor=donor,donor_result=res,donor_marks=bank.donors,cluster_donors=cluster_donors,
                         cluster_poses=library.cluster_poses,training=episodes,wide_training=wide_episodes,
                         cases=evaluations,cap_control=cutoff))
    models={key:{f"{kind}/{size}/{group}":costs for (kind,size,group),costs in p.costs.items()}
            for key,p in (("small",policy),("wide",wide))}
    write("data/results-v1.json",dict(status="CHECKED_OPEN_ENVELOPE_SOLVER",rows=rows,policy=models,
                                     protocol=dict(node_limit=NODE_LIMIT,pool_limit=POOL_LIMIT,seed=44417)))


if __name__=="__main__":
    main()
