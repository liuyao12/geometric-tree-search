"""Measure the two convex-core cases with cold exact geometry caches."""
from pathlib import Path
import json
from statistics import median
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory
from cases_v1 import load
from clipping_v1 import Core
from open_cases_v1 import geometries
from open_cover_v1 import solve
from open_experiment_v1 import cluster_library,prepare,NODE_LIMIT,POOL_LIMIT
import check_v1 as independent
import model_v1 as penrose


def clear(g):
    Core.pieces.cache_clear()
    g.boundary.cache_clear()
    if g.kind=="turtle":
        g.sites.cache_clear()
    else:
        penrose.clear_geometry()
        for f in (g.poly,g.mass,independent.corners,independent.imaginary_normal,
                  independent.hull,independent.canonical_contact):
            f.cache_clear()


def main():
    data=load("input/open-cases-v1.json")
    rows=[]
    for name,g in geometries().items():
        units=Inventory(g)
        inventory,_=cluster_library(g,units,data[name])
        query=next(r for r in data[name]["queries"] if r["id"]=="convex-core")
        raw={"plain":[],"clusters":[]}
        for i in range(5):
            arms=("plain","clusters") if not i%2 else ("clusters","plain")
            for label in arms:
                clear(g)
                t=perf_counter_ns()
                core,seed=prepare(g,query)
                begin=perf_counter_ns()
                ans=solve(core,units if label=="plain" else inventory,seed,query["id"],cap=query["cap"],
                          node_limit=NODE_LIMIT,pool_limit=POOL_LIMIT)
                end=perf_counter_ns()
                assert ans["status"]=="POSITIVE"
                raw[label].append(dict(setup_ns=begin-t,search_ns=end-begin,tiles=len(ans["patch"])))
        times={label:{k:int(median(r[k] for r in results)) for k in ("setup_ns","search_ns")}
               for label,results in raw.items()}
        rows.append(dict(kind=name,case="convex-core",samples=raw,median=times))
    result=dict(status="LOCAL_ALTERNATING_TIMING",rows=rows)
    (ROOT/"data/timing-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
