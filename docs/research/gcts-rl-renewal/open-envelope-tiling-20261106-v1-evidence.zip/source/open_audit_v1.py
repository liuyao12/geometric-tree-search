"""Replay open-cover certificates using an independent convex intersection calculation."""
from fractions import Fraction
from functools import cmp_to_key
from itertools import combinations
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import check_v1 as independent
from boundary_search_v1 import Inventory
from cases_v1 import frozen,load
from clipping_v1 import (ZERO, center, determinant, divide, padd, product, psub, side, sign, twice)
from geometry_v1 import add,chain,mul,pairs,rings_from_edges,sub
from open_cases_v1 import geometries
from open_cover_v1 import component
from open_experiment_v1 import prepare


def point_compare(a,b):
    return sign(sub(a[0],b[0])) or sign(sub(a[1],b[1]))


def hull(points):
    ordered=sorted(set(points),key=cmp_to_key(point_compare))
    if len(ordered)<3:
        return ()
    def half(rows):
        out=[]
        for p in rows:
            while len(out)>=2 and sign(side(out[-2],out[-1],p))<=0:
                out.pop()
            out.append(p)
        return out[:-1]
    return tuple(half(ordered)+half(reversed(ordered)))


def crossing(a,b,c,d):
    u,v=psub(b,a),psub(d,c)
    det=determinant(u,v)
    if not sign(det):
        return None
    p=psub(c,a)
    t,s=(divide(z,det) for z in (determinant(p,v),determinant(p,u)))
    if all(sign(x)>=0 and sign(sub((1,0),x))>=0 for x in (t,s)):
        return padd(a,product(u,t))
    return None


def inside(poly,p):
    return all(sign(side(a,b,p))>=0 for a,b in pairs(poly))


def intersect_area(poly,shape):
    vertices=[p for p in poly if inside(shape,p)]+[p for p in shape if inside(poly,p)]
    for a,b in pairs(poly):
        for c,d in pairs(shape):
            q=crossing(a,b,c,d)
            if q is not None:
                vertices.append(q)
    region=hull(vertices)
    return twice(region) if len(region)>=3 else ZERO


def coverage(core,patch):
    measured=[]
    for p in core.polygons:
        result=ZERO
        for t in patch:
            for s in core.pieces(t):
                result=add(result,intersect_area(p,s))
        assert result==twice(p)
        measured.append(result)
    return measured


def direct_at(g,edge):
    a,b=edge
    if g.kind=="penrose":
        return {t for t in independent.corners(a)
                if b in t and all(independent.order(independent.imaginary_normal(
                    sub(b,a),sub(p,a)),(0,0))>=0 for p in t)}
    return {g.shift(t,sub(a,x)) for t in g.bases for x,y in g.boundary(t) if sub(y,x)==sub(b,a)}


def obstruction(core,inv,edge,local,patch):
    g=core.g
    assert edge[::-1] in chain(g,patch) and core.forces(edge)
    options=[t for t, in inv.at(edge)]
    assert set(options)==direct_at(g,edge)
    for t,template in zip(options,local,strict=True):
        kind,*q=core.region.relocate(template,edge[0])
        if kind=="site":
            point,=q
            scale=g.model.scale
            assert g.wind(g.poly(t),point,scale)==1
            assert not core.region.inside(point,scale) or any(g.wind(g.poly(x),point,scale)==1 for x in patch)
        elif kind=="center":
            assert q[0]==tuple(map(sum,zip(*t))) and not core.region.inside(q[0],4)
        elif kind=="line":
            assert tuple(q) in core.region.lines and g.intrudes(*q,t)
        else:
            assert kind=="tile" and q[0] in patch and not independent.contact(t,q[0])
    return len(options)


def trace_cover(core,seed,row,cap):
    g=core.g
    path=[seed]
    remainder=core.subtract(core.polygons,(seed,))
    bridge=0
    for step in row["moves"]:
        patch=frozen(step["patch"])
        reason=step["kind"]
        if reason=="forced-edge":
            edge=frozen(step["edge"])
            assert edge[::-1] in chain(g,path) and core.forces(edge)
            assert edge in chain(g,patch)
        elif reason=="interior-point":
            assert remainder
            assert core.contains(patch[0],center(remainder[0]))
        else:
            assert reason=="connect" and not remainder
            anchored=component(g,path)
            assert len(anchored)<len(path)
            assert any(e[::-1] in chain(g,anchored) for e in chain(g,patch))
            bridge+=len(patch)
        remainder=core.subtract(remainder,patch)
        path.extend(patch)
    patch=tuple(path)
    assert patch==frozen(row["patch"]) and not remainder and len(patch)<=cap
    assert len(component(g,patch))==len(patch)
    assert set(chain(g,patch))==set(frozen(row["boundary"]))
    assert all(core.region.exterior(t) is None for t in patch)
    if g.kind=="penrose":
        assert all(t in independent.corners(t[0]) for t in patch)
        assert all(independent.contact(a,b) for a,b in combinations(patch,2))
    else:
        from triangle_geometry_v1 import polygon_overlap
        assert all(not polygon_overlap(g.poly(a),g.poly(b))["overlap"] for a,b in combinations(patch,2))
    covered=coverage(core,patch)
    assert covered==[tuple(Fraction(a,b) for a,b in expected) for expected in row["areas"]]
    return bridge


def main():
    data=load("data/results-v1.json")
    evidence=[]
    gs=geometries()
    for cohort in data["rows"]:
        g=gs[cohort["kind"]]
        inv=Inventory(g)
        queries={r["query"]["id"]:r["query"] for r in cohort["cases"]}
        queries[cohort["donor"]["id"]]=cohort["donor"]
        prepared={k:prepare(g,v) for k,v in queries.items()}
        n=outer=hits=exclusions=bridges=0
        new_outlines=set()
        seen_donors=set()
        for case in cohort["cases"]:
            query=case["query"]
            id=query["id"]
            core,seed=prepared[id]
            for row in case["arms"]:
                if row["status"]=="POSITIVE":
                    bridges+=trace_cover(core,seed,row,query["cap"])
                    outline=frozen(row["boundary"])
                    if set(outline)!=core.region.edges:
                        new_outlines.add(outline)
                        outer+=1
                    assert rings_from_edges(outline) is not None
                    n+=1
                if "marks" in row:
                    markers=row["marks"]
                    for key,donor in markers["donors"].items():
                        if key in seen_donors:
                            continue
                        c,_=prepared[donor["case"]]
                        exclusions+=obstruction(c,inv,frozen(donor["edge"]),frozen(donor["local"]),
                                                frozen(donor["placed"]))
                        seen_donors.add(key)
                    for hit in markers["hits"]:
                        tag=markers["donors"][hit["donor"]]
                        assert sub(*reversed(hit["edge"]))==sub(*reversed(tag["edge"]))
                        assert hit["case"]==id
                        exclusions+=obstruction(core,inv,frozen(hit["edge"]),frozen(tag["local"]),
                                                frozen(hit["placed"]))
                        hits+=1
            if query["expected"]=="NEGATIVE":
                e=frozen(query["port"])
                assert e[::-1] in g.boundary(seed) and core.forces(e)
                occ=core.region.extend(frozenset(),(seed,))
                assert all(core.region.block(t,occ) is not None for t in direct_at(g,e))
        bad,good=(queries[k] for k in ("moved-obstruction","relaxed-port"))
        assert bad["seed"]==good["seed"] and bad["core"]==good["core"]
        evidence.append(dict(kind=g.kind,positive_arms=n,non_envelope_arms=outer,
                             different_derived_outlines=len(new_outlines),bridge_tiles=bridges,
                             transferred_hits=hits,checked_candidate_exclusions=exclusions,
                             cap_control=cohort["cap_control"]["status"]))
    report=dict(status="AUDITED_OPEN_COVERS_AND_FORCED_PORTS",rows=evidence)
    (ROOT/"data/audit-v1.json").write_text(json.dumps(report,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(report,sort_keys=True))


if __name__=="__main__":
    main()
