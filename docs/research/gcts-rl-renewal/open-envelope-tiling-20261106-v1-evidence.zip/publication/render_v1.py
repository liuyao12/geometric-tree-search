"""Render the computed open outlines and exact donor witnesses."""
from cmath import exp
from html import escape
import json
from math import pi,sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory
from cases_v1 import frozen,load
from geometry_v1 import chain
from open_cases_v1 import geometries
from open_experiment_v1 import prepare

STEM="open-envelope-tiling-20261106-v1"
NAMES={"turtle":"Turtle","penrose":"Penrose rhombs"}
CASES={"convex-core":"Convex core","remote-core":"Remote core","two-core-pieces":"Two core pieces",
       "moved-obstruction":"Moved obstruction","relaxed-port":"Relaxed envelope"}
PALETTE=("#68a5a9","#ad92c9","#91b99a","#7fa7ca")


def project(g,p):
    if g.kind=="turtle":
        x,y=p
        return x+y/2,-sqrt(3)*y/2
    z=sum(a*exp(2j*pi*k/5) for k,a in enumerate(p))
    return z.real,-z.imag


def scaled(p,n):
    return tuple(x/n for x in p)


def pair(g,p):
    return ",".join(f"{x:.5f}" for x in project(g,p))


def path(g,points):
    return "M"+"L".join(pair(g,p) for p in points)+"Z"


def line(g,e):
    return "M"+"L".join(pair(g,p) for p in e)


def arm(case,name):
    return next(r for r in case["arms"] if r["arm"]==name)


def picture(g,query,result,blocked=None):
    env=frozen(query["envelope"])
    seed=frozen(query["seed"])
    core=frozen(query["core"])
    outline="".join(path(g,ring) for ring in env)
    points=[p for ring in env for p in ring]
    parts=[f'<path class="envelope" d="{outline}" fill="#eff5f6" fill-rule="evenodd" stroke="#688491" '
           'stroke-width="1.5" stroke-dasharray="6 4"/>']
    parts.append(f'<path class="tile seed" d="{path(g,g.poly(seed))}" fill="#426c88" stroke="#fff" stroke-width="1"/>')
    if result:
        for i,s in enumerate(result["moves"]):
            patch=frozen(s["patch"])
            kind=s["kind"]
            tone=("#e8b46e" if kind=="connect" else PALETTE[i%len(PALETTE)] if len(patch)>1 else "#a9c5c7")
            cls="bridge" if kind=="connect" else "cluster" if len(patch)>1 else "placement"
            parts.append(f'<g class="{cls}"><title>Move {i+1} places {len(patch)} tiles by {kind}</title>')
            for t in patch:
                parts.append(f'<path class="tile" d="{path(g,g.poly(t))}" fill="{tone}" stroke="#fff" stroke-width="1"/>')
            parts.append("</g>")
        edge_path="".join(line(g,e) for e in frozen(result["boundary"]))
        parts.append(f'<path class="outer" d="{edge_path}" fill="none" stroke="#264f61" stroke-width="1.7"/>')
    if blocked:
        e,t,guard=blocked
        poly=g.poly(t)
        points.extend(poly)
        parts.append(f'<path class="rejected" d="{path(g,poly)}" fill="#e28f4560" stroke="#9a531c" '
                     'stroke-width="1.4" stroke-dasharray="5 3"/>')
        parts.append(f'<path class="blocked-edge" d="{line(g,e)}" stroke="#ba2832" stroke-width="3.2"/>')
        mode,*q=guard
        if mode=="line":
            parts.append(f'<path class="guard" d="{line(g,q)}" stroke="#ba2832" stroke-width="2.5"/>')
        elif mode in ("site","center"):
            p=scaled(q[0],g.model.scale if mode=="site" else 4)
            x,y=project(g,p)
            parts.append(f'<circle class="guard" cx="{x:.5f}" cy="{y:.5f}" r="%%R%%" fill="#ba2832" stroke="#fff" stroke-width="1"/>')
        else:
            parts.append(f'<path class="guard" d="{path(g,g.poly(q[0]))}" fill="none" stroke="#ba2832" stroke-width="2"/>')
    for den,poly in core:
        fill=path(g,tuple(scaled(p,den) for p in poly))
        parts.append(f'<path class="core" d="{fill}" fill="#37a96e35" stroke="#08763f" stroke-width="1.8"/>')
        if query["id"]=="remote-core":
            middle=scaled(tuple(map(sum,zip(*poly))),den*len(poly))
            x,y=project(g,middle)
            parts.append(f'<circle class="core-locator" cx="{x:.5f}" cy="{y:.5f}" r="%%LOC%%" fill="none" '
                         'stroke="#08763f" stroke-width="1.3" stroke-dasharray="2 2"/>')
    xs,ys=zip(*(project(g,p) for p in points))
    span=max(max(xs)-min(xs),max(ys)-min(ys))
    m=.07*span
    view=" ".join(f"{x:.5f}" for x in (min(xs)-m,min(ys)-m,max(xs)-min(xs)+2*m,max(ys)-min(ys)+2*m))
    raw="".join(parts).replace("%%R%%",f"{span*.012:.5f}").replace("%%LOC%%",f"{span*.021:.5f}")
    label=escape(NAMES[g.kind]+" "+CASES[query["id"]])
    return f'<svg role="img" aria-label="{label}" viewBox="{view}">{raw}</svg>'


def figure(svg,caption):
    return f'<figure>{svg}<figcaption>{caption}</figcaption></figure>'


def negative_family(g,query,negative,relaxed):
    raw=arm(negative,"marked")["marks"]
    hit,=raw["hits"]
    donor=raw["donors"][hit["donor"]]
    edge=frozen(hit["edge"])
    core,_=prepare(g,query)
    places=Inventory(g).at(edge)
    guards=[core.region.relocate(w,edge[0]) for w in frozen(donor["local"])]
    i=next((i for i,g in enumerate(guards) if g[0] in ("site","center")),0)
    b=picture(g,query,None,(edge,places[i][0],guards[i]))
    a=picture(g,relaxed["query"],arm(relaxed,"marked"))
    return (f'<details><summary>{NAMES[g.kind]} port transfer and relaxation</summary>'
            '<div class="gallery">'+figure(b,f'The red port is forced. The transferred marking excludes all {len(places)} neighbors. The orange outline is one of them.')
            +figure(a,"The same seed and core in a relaxed envelope. The solver admitted a neighbor and completed the cover.")+'</div></details>')


def main():
    r=load("data/results-v1.json")
    audit=load("data/audit-v1.json")
    timing=load("data/timing-v1.json")
    gs=geometries()
    covers,remotes,negative,table,times=[],[],[],[],[]
    for cohort in r["rows"]:
        g=gs[cohort["kind"]]
        cases={x["query"]["id"]:x for x in cohort["cases"]}
        c=cases["convex-core"]
        mode="plain" if g.kind=="turtle" else "clusters"
        proof=arm(c,mode)
        covers.append(figure(picture(g,c["query"],proof),
                             f'{NAMES[g.kind]}. The computed patch has {len(proof["patch"])} tiles. The dashed envelope bounds the search and the green polygon is the required core.'))
        c=cases["remote-core"]
        proof=arm(c,"plain")
        bridges=sum(len(x["patch"]) for x in proof["moves"] if x["kind"]=="connect")
        remotes.append(figure(picture(g,c["query"],proof),
                              f'{NAMES[g.kind]}. The gold tiles connect the seed to the part covering the remote core. This trace added {bridges} bridge '+("tile." if bridges==1 else "tiles.")))
        c=cases["moved-obstruction"]
        negative.append(negative_family(g,c["query"],c,cases["relaxed-port"]))
        for case in cohort["cases"]:
            name=case["query"]["id"]
            row=[f'<tr><th scope="row">{NAMES[g.kind]} · {CASES[name]}</th>']
            for label in ("plain","marked","clusters","bandit","wide-bandit"):
                a=arm(case,label)
                checks=a["counts"].get("placement_checks",0)
                tile_count=len(a.get("patch",()))
                row.append(f'<td>{checks:,} <span class="count">({tile_count if tile_count else "–"})</span></td>')
            row.append('<td>'+("Covered" if case["query"]["expected"]=="POSITIVE" else "Obstructed")+"</td></tr>")
            table.append("".join(row))
    for item in timing["rows"]:
        a,b=(item["median"][k] for k in ("plain","clusters"))
        times.append(f'<tr><th scope="row">{NAMES[item["kind"]]}</th><td>{a["setup_ns"]/1e6:.1f}</td>'
                     f'<td>{a["search_ns"]/1e6:.1f}</td><td>{b["search_ns"]/1e6:.1f}</td></tr>')
    vals=dict(STEM=STEM,COVERS="".join(covers),REMOTE="".join(remotes),NEGATIVE="".join(negative),
              TABLE="".join(table),TIMING="".join(times),
              CHECKED=str(sum(x["positive_arms"] for x in audit["rows"])),
              OPEN=str(sum(x["non_envelope_arms"] for x in audit["rows"])))
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for k,v in vals.items():
        m="%%"+k+"%%"
        assert m in html
        html=html.replace(m,v)
    assert "%%" not in html
    (ROOT/"report"/f"{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
