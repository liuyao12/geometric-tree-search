# Replay the open-envelope tiling experiment

Use Python 3.12 and its standard library. In an extracted copy of the
archive, preserve the supplied evidence and run the following commands.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/open_cases_v1.py
    python3.12 -I -S -B source/open_experiment_v1.py
    python3.12 -I -S -B source/open_audit_v1.py

Compare the three scientific outputs with the hashes in
`publication/replay-v1.json`. The independent audit can also run
directly on the archived results. It checks core coverage from exact
intersection hulls and replays the forced-port obstruction guards.

To regenerate the published notebook with its original timing receipt:

    cp archived-data/timing-v1.json data/
    python3.12 -I -S -B publication/render_v1.py

The separate `source/open_timing_v1.py` script measures local search
time. The browser qualification uses MathJax and headless Chromium.
Set `GCTS_PLAYWRIGHT` and `GCTS_CHROME` for custom installations before
running `node publication/check_v1.cjs`.

The Turtle lattice model and its authoring patches are from the preceding
Golden Hex coordinate recovery. The exact seed, core polygons, and
envelope are recorded for every query. The solver receives these inputs
and the declared donor inventory. It computes each output boundary from
the returned tiles. The Penrose adapter uses unmarked edge-to-edge rhombs.
