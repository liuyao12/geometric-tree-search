const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/open-envelope-tiling-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 9);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("svg").count(), 8);
    assert.equal(await page.locator("#marks .blocked-edge").count(), 2);
    assert.equal(await page.locator("#marks .guard").count(), 2);
    assert.equal(await page.locator("#results table").first().locator("tbody tr").count(), 10);
    const mainCovers = await page.locator("#covers figure").evaluateAll(rows =>
      rows.map(figure => figure.querySelectorAll(".tile").length));
    assert.deepEqual(mainCovers, [4, 7]);
    const bridgeTiles = await page.locator("#remote figure").evaluateAll(rows =>
      rows.map(figure => figure.querySelectorAll(".bridge .tile").length));
    assert.deepEqual(bridgeTiles, [1, 2]);
    await page.locator("#marks summary").first().click();
    assert.equal(await page.locator("#marks details[open] svg:visible").count(), 2);
    if (!process.argv[2]) {
      await page.locator("#covers .gallery").screenshot({ path: path.join(__dirname, "covers-v1.png") });
      await page.locator("#remote .gallery").screenshot({ path: path.join(__dirname, "bridges-v1.png") });
      await page.locator("#marks details").first().screenshot({ path: path.join(__dirname, "mark-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_OPEN_ENVELOPE_READER", figures: 8, mainCovers, bridgeTiles,
      math: await page.locator("mjx-container").count(), mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
