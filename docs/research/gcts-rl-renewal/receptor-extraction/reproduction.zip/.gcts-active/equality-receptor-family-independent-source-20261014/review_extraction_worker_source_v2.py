"""Metadata/AST-only narrow successor review. No project imports/functions."""
import ast
import hashlib
import json
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/equality-receptor-family-independent-source-20261014'
PACKET=ROOT/'.gcts-active/equality-receptor-family-extraction-source-20261014'

def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def save(name,value):
    p=HERE/name
    with p.open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
    return pin(p)

def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[]
    def check(value,label):
        checks.append({'name':label,'passed':bool(value)})
        if not value:mismatches.append(label)
    def scan(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                p=Path(value['path']);p=p if p.is_absolute() else ROOT/p
                a=pin(p);a['path']=value['path'];check(a==value,'raw pin '+value['path']);refs.append(value)
            for v in value.values():scan(v)
        elif isinstance(value,list):
            for v in value:scan(v)
    old=json.loads((PACKET/'handoff-v1.json').read_bytes())
    new=json.loads((PACKET/'handoff-v2.json').read_bytes())
    contract=json.loads((PACKET/'source-contract-v2.json').read_bytes())
    scan(new);scan(contract)
    a=Path(old['source']['path']).read_text();b=Path(new['source']['path']).read_text()
    ta,tb=ast.parse(a),ast.parse(b);compile(tb,new['source']['path'],'exec')
    defs_a={n.name:n for n in ta.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    defs_b={n.name:n for n in tb.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
    check(set(defs_b)==set(defs_a)|{'callback_state'},'one added direct callback state helper')
    unchanged=[]
    for name in defs_a:
        if name!='main':
            same=ast.dump(defs_a[name],include_attributes=False)==ast.dump(defs_b[name],include_attributes=False)
            check(same,'same inherited top-level helper '+name);unchanged.append(name)
    constants_a=[ast.dump(n,include_attributes=False) for n in ta.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef))]
    constants_b=[ast.dump(n,include_attributes=False) for n in tb.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef))]
    check(constants_a==constants_b,'all imports/source maps/role sets/limits/constants unchanged')
    check(set(new['sources'])==set(old['sources']) and len(new['sources'])==10,'same ten exact raw roles')
    check([k for k in new['sources'] if new['sources'][k]!=old['sources'][k]]==['worker'],'only worker pin changed in ten-role map')
    # Independent textual inverse; never exec/evaluate the repaired callbacks.
    lines=b.splitlines(keepends=True);helper=defs_b['callback_state']
    helper_text=''.join(lines[helper.lineno-1:helper.end_lineno])
    inverse=b.replace(helper_text+'\n\n','',1)
    old_callback="""        guarded_function=source_guard;guarded_code=source_guard.__code__
        def invoke_guard():
            if source_guard is not guarded_function or source_guard.__code__ is not guarded_code:
                raise ValueError('exact delegated guard identity/code before invocation')
            source_guard()
            if source_guard is not guarded_function or source_guard.__code__ is not guarded_code:
                raise ValueError('exact delegated guard identity/code after invocation')
"""
    new_callback="""        source_guard_anchor=callback_state(source_guard)
        def invoke_guard():
            if callback_state(source_guard)!=source_guard_anchor:
                raise ValueError('exact delegated guard function/code/default/closure before invocation')
            source_guard()
            if callback_state(source_guard)!=source_guard_anchor:
                raise ValueError('exact delegated guard function/code/default/closure after invocation')
        invoke_guard_anchor=callback_state(invoke_guard)
"""
    check(inverse.count(new_callback)==1,'one exact callback/shim anchor replacement')
    inverse=inverse.replace(new_callback,old_callback,1)
    direct="""        if any(vars(own).get(name) is not value or value.__code__ is not code for name,value,code in own_functions):
            raise ValueError('original own validator/code before invoking callback shim')
        if callback_state(source_guard)!=source_guard_anchor or callback_state(invoke_guard)!=invoke_guard_anchor:
            raise ValueError('full original delegated guard and invoking shim authority before use')
"""
    check(inverse.count(direct)==6,'all six outer invocations receive direct original-function/shim/guard rejection')
    inverse=inverse.replace(direct,'')
    check(inverse==a,'exact independent inverse restores all parent bytes')
    helper_source=ast.unparse(helper)
    check(all(x in helper_source for x in ('__code__','__defaults__','__kwdefaults__','__closure__','cell.cell_contents','id(cell)')),
          'guard state includes function/code/default/kwdefault/closure cell and contents')
    main=defs_b['main'];nested={n.name:n for n in ast.walk(main) if isinstance(n,ast.FunctionDef)}
    check(ast.dump(nested['source_guard'],include_attributes=False)==ast.dump(
        next(n for n in ast.walk(defs_a['main']) if isinstance(n,ast.FunctionDef) and n.name=='source_guard'),include_attributes=False),
        'delegated source authority body itself unchanged')
    invoke=nested['invoke_guard'];invoke_source=ast.unparse(invoke)
    check(invoke_source.count('callback_state(source_guard)')==2,'before and after delegated callback checks')
    check('invoke_guard_anchor' not in invoke_source,'shim anchor has no uninitialized self-reference cell')
    old_findings=pin(HERE/'extraction-worker-source-findings-v1.json')
    review={'schema':'equality-receptor-family-extraction-worker-source-review-v2',
        'source_only':True,'source_review_passed':not mismatches,'scientific_calls':0,
        'author_identity':'/root/hilbert_ordering_diagnosis','reviewer_identity':'/root/arithmetic_induction',
        'sources':new['sources'],'source':new['source'],
        'scope':'Whole wrapper V1 plus exact narrow original delegated guard/shim closure repair; old source negative retained.',
        'author_partition':'Reviewer authored the auditor role; geometry author independently reviewed that exact role. This is an independent review of the worker, not an independent source review of the reviewer-authored auditor.',
        'conditional_requirements':['Future ROOT exact ten-field leaf/ten-field flat generic owner/raw runtime/input/current reviews and one genuine same-handle cold resource stage are pending.',
            'Current all-root SOURCE readiness is not an executed audit, universal family theorem, inventory/advice/recipient/math/native/search qualification.',
            'Shared20s covers cold module loading/extraction/all-root audit/full candidate result preparation; receipt publication uses separately disclosed cold60s/512MiB/caller90s scopes unchanged.',
            'Complete actual caller/postwrite/finalprint/reaping predicates are required; no hard OS memory cap or whole-host completeness is claimed.'],
        'all_checks_passed':not mismatches,'mismatches':mismatches,'actual_source_functions_called':0,
        'previous_negative_findings':old_findings}
    finding=save('extraction-worker-source-findings-v2.json',dict(review,checks=checks,raw_references=refs,
        contract=pin(PACKET/'source-contract-v2.json'),handoff=pin(PACKET/'handoff-v2.json'),
        full_unchanged_helpers=unchanged,independent_inverse_restores_parent_bytes=inverse==a,
        blocker_disposition='V1 only blocker resolved by exact callback/shim identity/code/default/closure anchoring at all six outer callsites.' if not mismatches else 'Not resolved.',
        metadata_helper_seconds_before_outputs=time.perf_counter()-began))
    typed=save('extraction-worker-source-review-v2.json',dict(review,findings=finding))
    handoff=save('extraction-worker-review-handoff-v2.json',{
        'schema':'independent-extraction-worker-source-review-handoff-v2','findings':finding,'review':typed,
        'source_only':True,'source_review_passed':not mismatches,'scientific_calls':0,'sources':new['sources']})
    print(json.dumps({'handoff':handoff,'findings':finding,'review':typed,'all_checks_passed':not mismatches},sort_keys=True))

if __name__=='__main__':main()
