"""Independent SOURCE/metadata-only review; never imports any project source."""
import ast
import hashlib
import json
import time
from pathlib import Path

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE = ROOT/'.gcts-active/equality-receptor-family-independent-source-20261014'
PACKET = ROOT/'.gcts-active/equality-receptor-family-extraction-source-20261014'

def pin(path):
    raw=path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def save(name, value):
    path=HERE/name
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    return pin(path)

def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[]
    def check(value,name):
        checks.append({'name':name,'passed':bool(value)})
        if not value:mismatches.append(name)
    def walk(value):
        if isinstance(value,dict):
            if set(value)=={'path','sha256','bytes'}:
                p=Path(value['path']);p=p if p.is_absolute() else ROOT/p
                actual=pin(p);actual['path']=value['path']
                check(actual==value,'exact raw record '+value['path']);refs.append(value)
            for v in value.values():walk(v)
        elif isinstance(value,list):
            for v in value:walk(v)
    handoff=json.loads((PACKET/'handoff-v1.json').read_bytes())
    contract=json.loads((PACKET/'source-contract-v1.json').read_bytes())
    walk(handoff);walk(contract)
    worker=Path(handoff['source']['path']);raw=worker.read_bytes();tree=ast.parse(raw)
    compile(tree,str(worker),'exec')
    assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)
        and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
    roles=ast.literal_eval(assignments['SOURCE_ROLES']);exec_roles=ast.literal_eval(assignments['EXECUTABLE_ROLES'])
    check(set(handoff['sources'])==roles and len(roles)==10,'exact ten raw source roles')
    check(exec_roles==('reader','logical_oracle','family','auditor'),'only four raw-compiled project modules')
    frozen=ast.literal_eval(assignments['FROZEN_SOURCES'])
    check(frozen=={k:v for k,v in handoff['sources'].items() if k!='worker'},'all nine nonself literal source pins')
    check(len(ast.literal_eval(assignments['FIELDS']))==10,'strict ten-field leaf ABI')
    main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    callbacks={n.name:n for n in ast.walk(main) if isinstance(n,ast.FunctionDef)}
    guard=callbacks['source_guard'];invoke=callbacks['invoke_guard']
    check(len(guard.args.args)==0 and len(guard.args.kwonlyargs)==0,'zero-argument cold source guard')
    invoke_text=ast.unparse(invoke)
    check('guarded_function' in invoke_text and 'guarded_code' in invoke_text,'outer guard anchors function and code')
    full_anchor_present=any(token in invoke_text for token in ('__closure__','guard_state','function_anchor','guarded_anchor'))
    check(full_anchor_present,'outer delegated guard captured-authority/default/closure anchor')
    findings=[{'id':'outer-delegated-validator-closure','severity':'preactivation blocker',
        'source_lines':[218,225],'scope':'Exact ordinary Python delegated-function identity/code/default/closure mutation scope used by the inherited cold adapters.',
        'fact':'Nested invoke_guard compares source_guard identity and __code__ only. source_guard closes over frozen/own_frozen/modules/ClosedInputs/plan and source authority; its cell contents are mutable and are not anchored by this caller once family/auditor Boundaries return.',
        'counterexample_source_only':'Keeping the same source_guard object/code while replacing a captured frozen expected snapshot cell with a snapshot of changed module code changes what the later validator accepts. Code-only invoke_guard still passes. No mutation was executed in this review.',
        'required_repair':'Additively seal original delegated guard function/code/default/keyword-default/cell and cell-content identities, and directly check the invocation shim before every outer call; preserve all old bytes and scientific semantics.'}]
    # These are whole-source review conclusions, not executed control receipts.
    conclusions=[
        'Strict leaf10/rawsources10/owner10; exact old donor reader5d03/kernel3b6 and fixed original three-certificate selector. Current I2 proof/source reader is not a donor.',
        'Named required raw reader roots are exact selector/design/handoff/ROOT original math, each donor six pins plus each old header three streams; no arbitrary ancestor/capsule decoding.',
        'Cold four-module raw-buffer compile/cache allowlist starts inside shared20s. Project helper/Graph/compiler/search/solver/native/RL modules are not imported or invoked.',
        'Entire producer candidate return and independent auditor keyword API run with the same real deadline, original ClosedInputs and GroundChecker. Entire library remains byte-value unchanged and no favorable root/family count is an admission input.',
        'Independent all-root audit reconstructs complete wire/licensing/dependency/point/provenance projection and actual ground exposed-receptor checks. Its source was authored by this reviewer; this worker review is not claimed as an independent source review of that auditor.',
        'Library/audit/result/evidence are provisional first. Any shared-inner failure removes aliases and retains provisional bytes/failure receipt; no accepted candidate prefix is established.',
        'Shared20s ends after all candidate/audit/result/evidence serialization and final alias guard/clock. Worker receipt publication is explicitly a separate cold lifecycle phase under whole60/512/caller90; that distinction is recorded and is not a cap enlargement.',
        'Leaf reserves cold55s and12MiB; generic owner measured wait4/ps/owned births and retrospective conservative peak use its original60s/512MiB plus conditional2s/8MiB reserve, unchanged. No OS hard aggregate memory cap or whole-host independent observer is claimed.',
        'Generic owner must be copied to a fresh flat .gcts-active directory, exact ROOT-relative closure/runtime paths, one immutable attempt; ps preflight precedes activation. Owner/closer same-handle actual caller+postwrite/final print+14 gates remain mandatory.',
        'No universally quantified scheme, library/advice admission, recipient proof, fullboard/fulltrajectory/native/performance/RL result follows from this source-only package.'
    ]
    field_review={'schema':'equality-receptor-family-extraction-worker-source-review-v1','source_only':True,
        'source_review_passed':not mismatches,'scientific_calls':0,'author_identity':'/root/hilbert_ordering_diagnosis',
        'reviewer_identity':'/root/arithmetic_induction','sources':handoff['sources'],
        'source':handoff['source'],'scope':'whole frozen cold extraction wrapper and explicit ten raw role closure; auditor self-authorship disclosed',
        'actual_source_functions_called':0,'conditional_requirements':['Any real caller/source/plan/runtime/ownership/math qualification is ROOT-only and pending.'],
        'blockers':findings,'source_or_science_execution_authorized':False}
    finding_pin=save('extraction-worker-source-findings-v1.json',dict(field_review,
        all_checks_passed=not mismatches,mismatches=mismatches,checks=checks,raw_references=refs,
        contract=pin(PACKET/'source-contract-v1.json'),handoff=pin(PACKET/'handoff-v1.json'),
        whole_source_conclusions=conclusions,metadata_helper_seconds_before_outputs=time.perf_counter()-began))
    typed_pin=save('extraction-worker-source-review-v1.json',dict(field_review,findings=finding_pin))
    result=save('extraction-worker-review-handoff-v1.json',{'schema':'independent-extraction-worker-source-review-handoff-v1',
        'findings':finding_pin,'review':typed_pin,'source_review_passed':not mismatches,'source_only':True,'scientific_calls':0})
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__':main()
