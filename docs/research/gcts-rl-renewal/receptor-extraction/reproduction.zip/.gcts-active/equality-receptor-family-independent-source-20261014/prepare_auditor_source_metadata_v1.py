"""Metadata-only freezer: hash/AST/JSON/ZIP; no project imports or calls."""
import ast
import builtins
import hashlib
import json
import symtable
import time
import zipfile
from pathlib import Path

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE = ROOT / '.gcts-active/equality-receptor-family-independent-source-20261014'
AUDITOR = HERE / 'independent_Incident_family_audit_v1.py'
PRODUCER = ROOT / '.gcts-active/equality-receptor-family-I2-recipient-source-20261014'
DONOR = ROOT / '.gcts-active/equality-receptor-family-implementation-source-20261013'

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def save(name, value):
    path = HERE/name
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True); stream.write('\n')
    return pin(path)

def main():
    start = time.perf_counter(); raw = AUDITOR.read_bytes(); tree = ast.parse(raw)
    compile(tree, str(AUDITOR), 'exec')  # Code object only, never executed/imported.
    module = symtable.symtable(raw.decode(), str(AUDITOR), 'exec')
    globals_defined = {s.get_name() for s in module.get_symbols() if s.is_assigned() or s.is_imported() or s.is_namespace()}
    globals_defined |= set(dir(builtins)) | {'__name__', '__file__', '__builtins__'}
    unknown = set(); pending = [module]
    while pending:
        table = pending.pop(); pending.extend(table.get_children())
        for symbol in table.get_symbols():
            if symbol.is_referenced() and symbol.is_global() and symbol.get_name() not in globals_defined:
                unknown.add(symbol.get_name())
    imports = [n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]
    names = [alias.name for n in imports if isinstance(n, ast.Import) for alias in n.names]
    names += [n.module for n in imports if isinstance(n, ast.ImportFrom)]
    expected = ['copy', 'gzip', 'hashlib', 'io', 'json', 'math', 'struct', 'time', 'types', 'pathlib']
    syntax_ok = not unknown and names == expected
    training = json.loads((DONOR/'training-inputs-v1.json').read_bytes())
    parent_contract = json.loads((PRODUCER/'source-contract-v2.json').read_bytes())
    refs = []; errors = []
    def scan(value):
        if isinstance(value, dict):
            if set(value) == {'path', 'sha256', 'bytes'}:
                declared = Path(value['path']); path = declared if declared.is_absolute() else ROOT/declared
                actual = pin(path); actual['path'] = value['path']
                refs.append(value)
                if actual != value:
                    errors.append(value['path'])
            for v in value.values():
                scan(v)
        elif isinstance(value, list):
            for v in value:
                scan(v)
    scan(training); scan(parent_contract)
    assertions = {
        'stdlib_only_imports': names == expected,
        'all_global_identifier_bindings_resolved': not unknown,
        'syntax_only_code_object_constructed_not_executed': True,
        'all_direct_raw_input_pins_match': not errors,
        'production_module_not_imported': True,
        'no_dynamic_project_import_in_auditor': not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
            and n.func.id in ('exec', 'eval', '__import__') for n in ast.walk(tree)),
        'no_production_family_helper_reference': not any(isinstance(n, ast.Attribute) and n.attr in
            ('extract_training', 'transport_body', 'complete_catalogue', 'reconstruct', 'literal_points') for n in ast.walk(tree)),
        'no_SelectedWire_recipe_or_licenses_execution': not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
            and n.func.attr in ('SelectedWire', 'licenses', 'recipe', 'place', 'exclude', 'rollback', 'search') for n in ast.walk(tree)),
        'strict_keyword_only_public_API': next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name=='audit_extraction').args.args == [],
        'strict_all_fields_library_projection': "set(library) == set(expected)" in raw.decode(),
        'declared_source_scientific_calls_zero': True,
    }
    controls = [
        {'id':'omit-command-root', 'mutation':'Remove one entry from complete_origin_census.', 'required':'Audit rejects: derived every command root remains present.'},
        {'id':'duplicate-command-root', 'mutation':'Duplicate a root with the same certificate/root index.', 'required':'Audit rejects exact complete census mismatch.'},
        {'id':'source-selected-proposed', 'mutation':'Relabel one source proposal as actually selected.', 'required':'Audit rejects actual whole cert/result/event/proposal attribution.'},
        {'id':'source-state-link', 'mutation':'Change linked source-state SHA or one whole state field.', 'required':'Audit rejects source state/event/payload identity.'},
        {'id':'missing-license', 'mutation':'In a separately pinned negative input fixture, remove or alter one full license row.', 'required':'Audit rejects EOF/count/index/record mismatch; no subset accepted.'},
        {'id':'recipe-tail', 'mutation':'Append a byte or remove a recipe row from independently pinned negative stream.', 'required':'Audit rejects exact full stream dimensions/hash.'},
        {'id':'formula-code', 'mutation':'Change one output/source formula code or registry word.', 'required':'Audit rejects registry/preimage/license/primitive/source reconstruction.'},
        {'id':'reordered-ports', 'mutation':'Swap equality/formula receptor ordering or MP input ordering.', 'required':'Audit rejects exact ordered shape/strict ancestry/local ground proof.'},
        {'id':'drop-ancestor', 'mutation':'Omit a required physical receptor ancestor or its original occurrence.', 'required':'Audit rejects dependency walk; pending mark is not a source.'},
        {'id':'fixed-point-conflict', 'mutation':'Change an assigned zero/exterior/target/local point value or refcount.', 'required':'Audit rejects complete source/current/fixed literal point equality.'},
        {'id':'body-command', 'mutation':'Change one eq_subst or MP body field/formula/parameter.', 'required':'Audit rejects rederived shape/whole command/licensing/local checker result.'},
        {'id':'family-meta', 'mutation':'Change a meta term, slot, normalized witness, shape SHA or source parameter.', 'required':'Audit rejects full family/evidence projection.'},
        {'id':'correlation', 'mutation':'Treat two equal source sequents as independent, or collapse distinct occurrence sequents.', 'required':'Audit rejects derived ordered-Gamma+target correlation mapping.'},
        {'id':'discard-ineligible', 'mutation':'Keep only positive root decisions.', 'required':'Audit rejects full every-root eligibility and reason census.'},
        {'id':'invent-authority', 'mutation':'Set universal/native/ROOT_inventory/full-board/recipient authority true or insert extra field.', 'required':'Audit rejects candidate library exact field set and false authority fields.'},
        {'id':'instance-shadow', 'mutation':'Replace supplied checker/ClosedInputs effective method on ordinary instance.', 'required':'Anchored endpoint checks reject before delegated use.'},
        {'id':'guard-code', 'mutation':'Replace source_guard code/default/closure or guard identity.', 'required':'Direct anchor comparison rejects before/after call.'},
        {'id':'deadline', 'mutation':'Have an external synthetic clock/deadline gate expire during complete work or final receipt.', 'required':'No completed audit/usable prefix escapes; budget result UNKNOWN.'},
    ]
    controls_pin = save('prospective-negative-controls-v1.json', {
        'schema':'independent-Incident-donor-audit-negative-controls-source-v1', 'author_identity':'/root/arithmetic_induction',
        'controls':controls, 'executed':False, 'scientific_calls':0,
        'scope':'Prospective corruption requirements only. No fixture data, root count, target route or expected winning body is supplied; actual ROOT construction/dispatch/negative receipts are future gates.'})
    contract = {
        'schema':'independent-Incident-donor-audit-source-contract-v1', 'author_identity':'/root/arithmetic_induction',
        'source':pin(AUDITOR), 'source_only':True, 'scientific_calls':0, 'scientific_acceptance':False,
        'public_API':'audit_extraction(*, training_spec, library, reader, checker_class, closed, source_guard, deadline)',
        'output_schema':'independent-complete-Incident-donor-root-audit-v1',
        'required_positive_fields':['completed','all_checks_passed'],
        'false_authority_fields':['ROOT_inventory_admitted','schema_universally_validated','native_accepted','recipient_proof_accepted','full24_board_accepted','full_trajectory_accepted','new_lemma_discovered','new_RL_training'],
        'candidate_library_schema':'candidate-finite-Incident-transport-library-v1',
        'producer_source':parent_contract['source'], 'receiver_source_review':pin(HERE/'receiver-source-findings-v1.json'),
        'prior_parent_independent_review':parent_contract['parent_independent_SOURCE_review'],
        'fixed_training_spec':pin(DONOR/'training-inputs-v1.json'),
        'donor_sources':parent_contract['donor_sources'],
        'required_raw_reader_roots':'Fixed training selector, design/handoff/ROOT donor math disposition, each old donor certificate/result/qualification/header/licenses/resource pin, each original header nodes/formulas/recipes stream, original DONOR7. No new I2 proof or recipient q/scientific payload is consumed by the auditor.',
        'input_scope':'The three fixed old certificate files are correlated evidence. All roots are derived from complete reconstructed commands; no favorable family/root count or proof word is a control input.',
        'algorithm_independence':['Own complete canonical gzip/DAG/little-endian wire parser and recipe/preimage SHA reconstruction.',
          'All formula words/registry injectivity and complete original license rows compared; all primitive interfaces rechecked by unchanged injected GroundChecker.command.',
          'Own strict-prior dependency worklist and command expansion retaining all indexed ambient Gamma occurrences plus consumed subset.',
          'Unique whole saved checked proof/current state/event/proposal origin, selected versus proposed preserved.',
          'Own eq_subst/ordered MP dependency motif and normalization, every root including ineligible decisions.',
          'Own exact t/m/full fixed+current union/refcount accumulation including assigned zero and remote points.',
          'Every eligible extracted local ground body rebuilt from its exposed ordered receptors and checked by injected GroundChecker; full original-Gamma proof checked independently.',
          'Complete candidate-library semantic projection compared, no producer helper imported/called or producer output used to derive expected shape.'],
        'correlated_donor_caching':'Only exact identical whole header+license pin pair is reused; metrics disclose reuse. Every donor certificate/root/whole proof/origin/point-union still independently processed.',
        'trust_boundary':'Future ROOT cold wrapper must raw-read/hash/compile exact modules and bind whole module functions/defaults/closures/globals/class/MRO/properties/effective objects. Old reader.ClosedInputs and unchanged GroundChecker are exact injected endpoints. Filename/hash alone is not executed-code authority. Auditor adds anchored guard+effective methods but never substitutes for caller admission.',
        'reader_methods':'Only old ClosedInputs.verify/close raw accounting is called. SelectedWire, reader.licenses, donor compiler/decoder/search/Graph and production extractor helpers are never invoked.',
        'resource_protocol':'Future worker extracts and audits under one shared 20-second internal deadline; generic owned whole60 seconds/512MiB/caller90 seconds remain unchanged. No agent runtime/capacity claim. Loading/complete catalog/rechecks/all roots/local checks/point union/comparison/final in-memory guards are inside deadline; file serialization/cleanup are under owned/caller bounds.',
        'cost_reporting':'Partial nested elapsed spans are not added as full pipeline totals. Started/completed actual primitive/proof/body/root/point counters are separate; interrupt has no completed receipt. Cold loading/imports/serialization/observer/resource/cleanup costs are charged by worker/owner/caller.',
        'prospective_negative_controls':controls_pin,
        'unexecuted_gaps':['No scientific helper/fixture/auditor/extractor/kernel operation has run for this source packet.',
          'ROOT and independent source review plus exact once-only worker plan/cold lifetime prerequisites precede execution.',
          'No universal parameterized family proof, ROOT library admission, recipient grounding/proof, search/performance/RL/native/trajectory/full-board acceptance follows from source readiness.',
          'Production consumer/DFS/worker/source epochs are separate pending successors, not supplied by this auditor.']}
    contract_pin = save('auditor-source-contract-v1.json',contract)
    checks_pin = save('auditor-source-static-checks-v1.json',{
        'schema':'independent-Incident-auditor-source-static-checks-v1', 'source':pin(AUDITOR),
        'all_checks_passed':all(assertions.values()) and syntax_ok, 'checks':assertions,
        'unresolved_global_names':sorted(unknown), 'raw_pin_mismatches':errors, 'raw_pin_references':refs,
        'distinct_raw_path_sha_bytes':len({(p['path'],p['sha256'],p['bytes']) for p in refs}),
        'syntax_compile_only':True, 'source_module_imports':0,'source_functions_executed':0,'scientific_calls':0,
        'metadata_helper_elapsed_before_outputs_seconds':time.perf_counter()-start})
    code_freeze = save('auditor-code-freeze-v1.json',{
        'schema':'independent-Incident-auditor-raw-code-freeze-v1','source':pin(AUDITOR),
        'source_only':True,'source_functions_executed':0,'scientific_calls':0,
        'source_immutable_after_this_freeze':True,'repair_policy':'Any concrete source finding gets an additive version; no overwrite.'})
    paths = [AUDITOR, HERE/'review_receiver_source_v1.py', HERE/'receiver-source-findings-v1.json',
             HERE/'receiver-review-handoff-v1.json', HERE/'prepare_auditor_source_metadata_v1.py',
             HERE/'prospective-negative-controls-v1.json', HERE/'auditor-source-contract-v1.json',
             HERE/'auditor-source-static-checks-v1.json', HERE/'auditor-code-freeze-v1.json']
    archive = HERE/'source-package-v1.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for path in paths:
            z.writestr(path.name, path.read_bytes())
    handoff = save('auditor-handoff-v1.json',{
        'schema':'independent-Incident-auditor-source-handoff-v1','author_identity':'/root/arithmetic_induction',
        'source':pin(AUDITOR),'contract':contract_pin,'static_checks':checks_pin,'code_freeze':code_freeze,
        'source_package':pin(archive),'reviewer_required':True,'source_only':True,'scientific_calls':0,
        'public_API':contract['public_API'],'output_schema':contract['output_schema'],
        'actual_worker_owner_author':'/root/hilbert_ordering_diagnosis; ROOT actual sole dispatch',
        'all_metadata_source_checks_passed':all(assertions.values()) and syntax_ok,
        'metadata_authoring_helper_elapsed_before_handoff_seconds':time.perf_counter()-start})
    manifest = save('integration-v1.json',{'schema':'independent-Incident-auditor-task-source-integration-v1',
        'files':[pin(path) for path in paths]+[pin(archive),handoff], 'source_only':True,
        'scientific_calls':0,'public_files_modified':False,'source_functions_executed':0})
    print(json.dumps({'handoff':handoff,'integration':manifest,'all_checks_passed':all(assertions.values()) and syntax_ok,
                      'scientific_calls':0},sort_keys=True))

if __name__ == '__main__':
    main()
