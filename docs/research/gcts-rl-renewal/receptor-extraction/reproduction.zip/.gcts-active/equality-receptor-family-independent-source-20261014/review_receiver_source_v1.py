"""Metadata/AST-only independent receiver delta review. Never imports project code."""
import ast
import copy
import hashlib
import json
import time
from pathlib import Path

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
OUT = ROOT / '.gcts-active/equality-receptor-family-independent-source-20261014'
PARENT = ROOT / '.gcts-active/equality-receptor-family-implementation-source-20261013/equality_receptor_family_v1.py'
CHILD = ROOT / '.gcts-active/equality-receptor-family-I2-recipient-source-20261014/equality_receptor_family_I2_v2.py'
PACKET = CHILD.parent

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def main():
    start = time.perf_counter(); checks = []; mismatches = []; refs = []
    def check(ok, label):
        checks.append({'name': label, 'passed': bool(ok)})
        if not ok:
            mismatches.append(label)
    def scan(value):
        if isinstance(value, dict):
            if set(value) == {'path', 'sha256', 'bytes'}:
                path = Path(value['path']); path = path if path.is_absolute() else ROOT / path
                actual = pin(path); actual['path'] = value['path']
                check(actual == value, 'raw pin '+value['path']); refs.append(value)
            for item in value.values():
                scan(item)
        elif isinstance(value, list):
            for item in value:
                scan(item)
    parent = ast.parse(PARENT.read_bytes()); child = ast.parse(CHILD.read_bytes())
    originals = {x.name: x for x in parent.body if isinstance(x, (ast.FunctionDef, ast.ClassDef))}
    revised = {x.name: x for x in child.body if isinstance(x, (ast.FunctionDef, ast.ClassDef))}
    check(set(revised) == set(originals) | {'validate_I2_recipient'}, 'one new metadata guard definition')
    changes = []
    for name, old in originals.items():
        new = copy.deepcopy(revised[name])
        if name == 'FamilySession':
            constructor = next(x for x in new.body if isinstance(x, ast.FunctionDef) and x.name == '__init__')
            start_i = next(i for i, x in enumerate(constructor.body) if isinstance(x, ast.Assign)
                           and any(isinstance(t, ast.Name) and t.id == 'recipient_q' for t in x.targets))
            removed = constructor.body[start_i:start_i+3]
            check(len(removed) == 3 and ast.unparse(removed[1]).startswith('validate_I2_recipient(')
                  and ast.unparse(removed[2]) == 'boundary.check(deadline)', 'exact three constructor statements only')
            del constructor.body[start_i:start_i+3]
        equal = ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False)
        check(equal, 'inherited callable AST '+name)
        if not equal:
            changes.append(name)
    def assignments(tree):
        out = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                out[node.targets[0].id] = node.value
        return out
    a, b = assignments(parent), assignments(child)
    check(set(b) == set(a) | {'I2_RECIPIENT_BINDINGS_PIN'}, 'only one extra source assignment')
    exceptional = {'VERSION', 'ADMISSION_SCHEMA', 'UPSTREAM_SOURCE_PINS', 'DONOR_SOURCE_PINS'}
    for name in set(a) - exceptional:
        check(ast.dump(a[name], include_attributes=False) == ast.dump(b[name], include_attributes=False),
              'unchanged assignment '+name)
    upstream_old = ast.literal_eval(a['UPSTREAM_SOURCE_PINS'])
    donor_new = ast.literal_eval(b['DONOR_SOURCE_PINS'])
    upstream_new = ast.literal_eval(b['UPSTREAM_SOURCE_PINS'])
    check(donor_new == upstream_old, 'all seven old donor source pins explicit and retained')
    check(set(upstream_new) == set(upstream_old) and [k for k in upstream_new if upstream_new[k] != upstream_old[k]] == ['reader'],
          'recipient reader is the sole changed upstream role')
    check(upstream_new['reader']['sha256'] == 'c8fa4aeba82fcc2af9bd091fd351d72f86a24ae97cb5edd92ff558e81c23501b', 'exact current I2 receiver reader')
    contract = json.loads((PACKET/'source-contract-v2.json').read_bytes())
    bindings = json.loads((PACKET/'I2-recipient-bindings-v1.json').read_bytes())
    training = json.loads(Path(ast.literal_eval(b['TRAINING_SPEC_PIN'])['path']).read_bytes())
    check(len(training['certificates']) == 3 and ast.literal_eval(a['TRAINING_SPEC_PIN']) == ast.literal_eval(b['TRAINING_SPEC_PIN']), 'same frozen three original donor inputs')
    check(bindings['fixture_case_count'] == 16 and len(bindings['recipients']) == 2, 'receiver-only sixteen-case fixture and two literal cases')
    # Read only the fixed static metadata, never any recipe/model/proof function.
    static = json.loads(Path(bindings['static_ROOT_disposition']['path']).read_bytes()) if 'static_ROOT_disposition' in bindings else None
    scan(contract); scan(bindings); scan(training)
    guard_text = ast.unparse(revised['validate_I2_recipient'])
    check("expected_consumer_source_binding" in guard_text and "set(q) == set(base)" in guard_text, 'only future consumer field differs and complete q field set remains exact')
    check(not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ('proof', 'recipe', 'place', 'exclude', 'rollback')
                  for n in ast.walk(revised['validate_I2_recipient'])), 'metadata-only new guard has no mathematical or graph calls')
    check(contract['inventory_admitted'] is False and contract['heldout_or_I2_proof_accepted'] is False, 'source packet disclaims mathematical and library acceptance')
    result = {'schema': 'independent-I2-receiver-source-review-v1', 'source_only': True,
        'author_identity': '/root/hilbert_advice_controls', 'reviewer_identity': '/root/arithmetic_induction',
        'source': pin(CHILD), 'parent_source': pin(PARENT), 'source_contract': pin(PACKET/'source-contract-v2.json'),
        'parent_independent_review': contract['parent_independent_SOURCE_review'],
        'all_checks_passed': not mismatches, 'source_review_passed': not mismatches,
        'checks': checks, 'mismatches': mismatches, 'raw_references': refs,
        'source_only_callables_executed': 0, 'scientific_calls': 0, 'metadata_authoring_helper_invoked': True,
        'conditions': ['Future ROOT cold/source/runtime/current recipient/consumer admission remains mandatory.',
          'This comparison qualifies only the source delta, not the new metadata guard at runtime.',
          'Current I2 nineteen-command proof is not a donor and no new library/lemma/held-out proof is established.',
          'All unchanged extraction/grounding/point/current-union/budget/fallback/scheduler semantics retain their inherited conditional review.'],
        'elapsed_metadata_helper_before_output_seconds': time.perf_counter()-start}
    name = OUT/'receiver-source-findings-v1.json'
    with name.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True); stream.write('\n')
    handoff = {'schema': 'independent-I2-receiver-review-handoff-v1', 'findings': pin(name),
               'all_checks_passed': not mismatches, 'source_review_passed': not mismatches, 'scientific_calls': 0,
               'source': pin(CHILD), 'reviewer_identity': '/root/arithmetic_induction', 'scientific_acceptance': False}
    with (OUT/'receiver-review-handoff-v1.json').open('x') as stream:
        json.dump(handoff, stream, indent=2, sort_keys=True); stream.write('\n')
    print(json.dumps(handoff, sort_keys=True))

if __name__ == '__main__':
    main()
