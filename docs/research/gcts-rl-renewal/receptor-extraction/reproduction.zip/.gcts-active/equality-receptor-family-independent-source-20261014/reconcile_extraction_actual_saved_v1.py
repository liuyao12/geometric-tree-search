"""Saved JSON/raw-pin reconciliation only: no project imports or semantic calls."""
import gzip
import hashlib
import json
import time
from pathlib import Path

ROOT=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
HERE=ROOT/'.gcts-active/equality-receptor-family-independent-source-20261014'
PROGRESS=ROOT/'.gcts-active/equality-receptor-family-extraction-progress-20261014'

def canonical(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()

def pathof(v):
    p=Path(v);return p if p.is_absolute() else ROOT/p

def pin(path):
    p=pathof(path);raw=p.read_bytes()
    return {'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}

def main():
    began=time.perf_counter();checks=[];mismatches=[];refs=[];raw_inputs={}
    def check(ok,label):
        checks.append({'name':label,'passed':bool(ok)})
        if not ok:mismatches.append(label)
    def verify(record):
        actual=pin(record['path']);actual['path']=record['path'];refs.append(record)
        check(actual==record,'raw bytes '+record['path'])
        return pathof(record['path'])
    def scan(v):
        if isinstance(v,dict):
            if set(v)=={'path','sha256','bytes'}:verify(v)
            for x in v.values():scan(x)
        elif isinstance(v,list):
            for x in v:scan(x)
    def read(path):
        p=pathof(path);raw=p.read_bytes();raw_inputs[str(p)]=pin(p)
        if p.name.endswith('.gz'):raw=gzip.decompress(raw)
        return json.loads(raw)
    def pinned_json(record):
        verify(record);return read(record['path'])
    files={'plan':'worker-plan-v1.json','owner_plan':'replay-plan-v1.json','ROOT_review':'ROOT-source-review-v1.json',
        'worker':'worker-output-v1/worker-receipt-v1.json','result':'worker-output-v1/extraction-result-v1.json',
        'evidence':'worker-output-v1/extraction-evidence-v1.json','library':'worker-output-v1/candidate-library-v1.json',
        'audit':'worker-output-v1/independent-all-origin-audit-v1.json','caller':'replay-actual-tool-observations-v1.json',
        'owner':'replay-owner-v1/ROOT-terminal-v1.json','post':'replay-owner-v1/post-write-observation-v1.json',
        'resource':'replay-ROOT-final-decision-v1.json','math':'ROOT-actual-family-extraction-disposition-v1.json',
        'launch':'replay-owner-v1/launch-v1.json'}
    values={name:read(PROGRESS/path) for name,path in files.items()}
    for name,value in values.items():scan(value)
    p,o,w,r,e,lib,a,c,t,post,resource,math=(values[k] for k in
        ('plan','owner_plan','worker','result','evidence','library','audit','caller','owner','post','resource','math'))
    limits={'whole_seconds':60,'peak_bytes':536870912,'caller_seconds':90,'control_seconds':20}
    check(len(p)==10 and len(o)==10,'actual exact ten-field leaf and flat ten-field owner')
    check(p['limits']==o['limits']==post['limits']==resource['limits']==limits,'unchanged whole60/512/caller90/shared20 bounds')
    check(p['ROOT_owned_once_only'] is True and o['stage']==w['stage']==resource['stage']=='replay','once-only extraction transport-stage identity')
    check(o['argv']==[str(pathof(p['runtime']['binary']['path'])),'-B',p['sources']['worker']['path'],str(PROGRESS/'worker-plan-v1.json'),str(PROGRESS/'replay-plan-v1.json')],
          'literal canonical interpreter/worker/plan argv')
    check(p['owner_plan_path']==str(PROGRESS/'replay-plan-v1.json') and p['output_directory']==str(PROGRESS/'worker-output-v1'), 'actual flat path/owner/output identity')
    check(len(p['sources'])==10 and all(v['sources']==p['sources'] for v in (w,e,math,values['ROOT_review'])), 'same exact ten source records across actual receipts and Root review')
    handoff=read(ROOT/'.gcts-active/equality-receptor-family-extraction-source-20261014/handoff-v2.json');scan(handoff)
    check(handoff['sources']==p['sources'],'actual sources equal frozen selected V2 handoff')
    peer=pinned_json(p['reviews']['independent']);root_review=pinned_json(p['reviews']['ROOT'])
    check(peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
          and peer['author_identity']=='/root/hilbert_ordering_diagnosis' and peer['reviewer_identity']=='/root/arithmetic_induction'
          and peer['sources']==p['sources'],'genuine distinct worker author/reviewer, current source-only positive map')
    check(root_review['source_review_passed'] is True and root_review['scientific_calls']==0 and root_review['sources']==p['sources'],'current Root source review selected')
    closure={str(pathof(x['path'])):dict(x,path=str(pathof(x['path']))) for x in p['closure']}
    owner_closure={str(pathof(x['path'])):dict(x,path=str(pathof(x['path']))) for x in o['closure']}
    check(len(closure)==len(p['closure'])==math['whole_named_closure_paths'],'exact current named closure path census')
    check(all(owner_closure.get(k)==v for k,v in closure.items()) and owner_closure.get(str(PROGRESS/'worker-plan-v1.json'))==pin(PROGRESS/'worker-plan-v1.json'), 'owner preserves whole leaf/plan raw closure')
    check(math['actual_result']==pin(PROGRESS/files['result']) and math['actual_worker']==pin(PROGRESS/files['worker'])
        and math['actual_evidence']==pin(PROGRESS/files['evidence']) and math['actual_candidate_library']==pin(PROGRESS/files['library'])
        and math['actual_independent_audit']==pin(PROGRESS/files['audit']) and math['actual_resource_gate']==pin(PROGRESS/files['resource']), 'Root sealed exact complete output buffers')
    check(w['result']==e['result']==pin(PROGRESS/files['result']) and w['candidate_library']==r['candidate_library']==pin(PROGRESS/files['library'])
        and w['independent_audit']==r['independent_audit']==pin(PROGRESS/files['audit']) and w['evidence']==pin(PROGRESS/files['evidence']), 'whole output references agree')
    for name in ('candidate-library-v1.json','independent-all-origin-audit-v1.json','extraction-result-v1.json','extraction-evidence-v1.json'):
        check((PROGRESS/'worker-output-v1'/name).read_bytes()==(PROGRESS/'worker-output-v1/provisional-output-v1'/name).read_bytes(),'provisional/final alias bytes '+name)
    check((PROGRESS/'worker-output-v1/worker-receipt-v1.json').read_bytes()==(PROGRESS/'worker-output-v1/provisional-worker-receipt-v1.json').read_bytes(),'worker success/provisional receipt bytes retained')
    spec=pinned_json(p['training_specification']);scan(spec)
    check(w['training_specification']==r['training_specification']==e['training_specification']==math['original_training_specification']==p['training_specification'], 'unchanged fixed old donor selector')
    check(lib['training_spec_sha256']==a['training_spec_sha256']==digest(spec),'complete selector semantic digest reconciles')
    check(a['completed'] is True and a['all_checks_passed'] is True and a['mismatches']==[] and a['producer_source_called'] is False
        and a['independent_compact_decoder'] is True,'whole actual independent audit completed, not a source-only receipt')
    check(a['candidate_library_sha256']==digest(lib),'whole candidate library value digest, distinct from raw formatted file pin')
    projection={k:v for k,v in lib.items() if k!='elapsed_seconds_before_final_guards'}
    check(a['independent_semantic_projection_sha256']==digest(projection),'complete all-field candidate semantic projection digest')
    check(a['complete_command_root_census']==lib['complete_origin_census'] and a['correlated_sequents']==lib['correlated_sequents'], 'whole all-root and correlation outputs match')
    # This walk checks saved dependency metadata and literal provenance only. It
    # never expands a binary model, evaluates a formula, or invokes a checker.
    derivations={d['certificate']['sha256']:d for d in lib['derivations']}
    root_decisions=[];donors=[];catalogue_headers={};all_bodies=[]
    for donor in spec['certificates']:
        cert=pinned_json(donor['certificate']);source_result=pinned_json(donor['result'])
        q=pinned_json(donor['qualification']);header=pinned_json(donor['header']);scan(header)
        donor_resource=pinned_json(donor['resource_disposition'])
        d=derivations[donor['certificate']['sha256']];patch=cert['checked_patch']['patch'];commands=d['original_commands'];keys=d['original_keys']
        check(commands==patch['commands'] and keys==patch['primitive_keys'],'entire saved donor primitive word and full keys '+donor['certificate']['sha256'])
        check(d['origin']==donor['origin']==cert['origin_kind'],'retained selected/proposed attribution '+donor['certificate']['sha256'])
        check(d['original_ordered_Gamma']==patch['exact_original_ordered_gamma']==header['context']['ordered_local_premises'], 'same ordered ambient Gamma '+donor['certificate']['sha256'])
        check(q['catalog']==donor['header'] and q['independent']['licenses']==donor['licenses'] and cert['qualification_pin']==donor['qualification']
            and cert['result_pin']==donor['result'] and donor_resource['logical_certificate']==donor['certificate'] and donor_resource['result']==donor['result'], 'whole old donor qualification/license/resource binding')
        cp=cert['checked_patch'];check(source_result['first_checked_proof']==cp and digest(cp)==cert['checked_patch_sha256']
            and source_result['graph_states'][cp['source_state_sha256']]==cp['source_state'] and digest(cp['source_state'])==cp['source_state_sha256'], 'whole original source result/state/certificate SHA')
        matching=[event for event in source_result['events'] if event['kind']=='first_checked_logical_proof' and event['proof_sha256']==digest(cp)
            and event['origin_kind']==cp['origin_kind'] and event['source_link']==cp['source_link']]
        check(len(matching)==1,'unique retained producer proof event')
        check(cp['prospective_current_point_union_accepted'] is True and cp['primary_endpoint_eligible'] is True and patch['kernel_result']==d['independent_ground_check'], 'actual saved donor kernel/current-union receipt, not rerun')
        check(d['correlated_sequent_id']==digest([d['original_ordered_Gamma'],patch['conclusion']]),'ordered original sequent correlation digest')
        row_index={k[1]:i for i,k in enumerate(keys)}
        check(len(row_index)==len(keys)==len(commands),'every donor command has a distinct exact physical row key')
        for i,(command,k) in enumerate(zip(commands,keys)):
            check(type(k[0]) is int and type(k[1]) is int and 0<=k[1]<24 and len(k[2])==(2 if command['rule']=='mp' else 0), 'literal primitive key/port arity')
            if command['rule']=='mp':
                check(0<=command['antecedent']<i and 0<=command['implication']<i,'saved strict-prior command sources')
                check(k[2]==[keys[command['antecedent']][1],keys[command['implication']][1]],'ordered physical source rows equal saved command refs')
            elif command['rule']=='assumption':
                occurrence=command['index'];check(command['formula']==d['original_ordered_Gamma'][occurrence] and k[1]==occurrence
                    and k[0]==header['assumption_recipe_indices'][occurrence],'original indexed occurrence preserved')
        def ancestry(index):
            agenda=[index];found=set()
            while agenda:
                n=agenda.pop()
                if n in found:continue
                found.add(n);cmd=commands[n]
                if cmd['rule']=='mp':agenda.extend([cmd['antecedent'],cmd['implication']])
            return sorted(found)
        consumed=sorted({commands[i]['index'] for i in ancestry(len(commands)-1) if commands[i]['rule']=='assumption'})
        check(consumed==d['consumed_original_occurrence_indices']==patch['consumed_original_occurrence_indices'],'consumed occurrences derived from complete saved final ancestry')
        origins=[x for x in lib['complete_origin_census'] if x['certificate']==donor['certificate']]
        check([x['command_root'] for x in origins]==list(range(len(commands))),'every eligible and ineligible command root retained')
        root_decisions.extend(origins)
        eligible=[x for x in origins if x['eligible']]
        census=next(x for x in a['census'] if x['certificate']==donor['certificate'])
        check(census['command_roots']==len(commands) and census['eligible_roots']==len(eligible)
            and census['all_original_Gamma_occurrences']==list(range(len(d['original_ordered_Gamma']))) and census['consumed_original_occurrence_indices']==consumed
            and census['origin']==d['origin'] and census['primitive_recipe_count']==header['dimensions']['primitive_license_count'], 'full donor audit census reconciled')
        body_evidence=[(f,body) for f in lib['families'] for body in f['evidence'] if body['origin']['certificate']==donor['certificate']]
        check(sorted(b['origin']['command_root'] for _,b in body_evidence)==[x['command_root'] for x in eligible], 'no eligible evidence omitted/duplicated or preferred subset')
        for f,body in body_evidence:
            root=body['origin']['command_root'];members=body['body_command_indices'];ports=body['ordered_external_command_indices']
            check(body['origin']==next(x for x in origins if x['command_root']==root) and body['shape']==f['shape'] and body['family_id']==f['family_id'], 'complete family evidence/origin/shape link')
            check(f['family_id']=='Incident-transport-'+digest(f['shape']), 'normalized full family shape ID')
            check(members[2]==root and commands[root]['rule']=='mp' and members[1]==commands[root]['implication']
                and commands[members[1]]['rule']=='mp' and members[0]==commands[members[1]]['implication']
                and commands[members[0]]['rule']=='eq_subst' and ports==[commands[members[1]]['antecedent'],commands[root]['antecedent']], 'saved ET_STEP three-command ordered motif')
            check(body['source_body_keys']==[keys[i] for i in members] and body['source_body_rows']==[keys[i][1] for i in members], 'all source body member identities retained')
            check(body['ordered_receptor_ancestor_rows']==[[keys[i][1] for i in ancestry(n)] for n in ports], 'all ordered receptor saved ancestry rows')
            check(body['ordered_receptor_consumed_occurrences']==[sorted({commands[i]['index'] for i in ancestry(n) if commands[i]['rule']=='assumption'}) for n in ports], 'ordered receptor consumed occurrence metadata')
            local=next(x for x in a['open_ground_body_checks'] if x['certificate']==donor['certificate'] and x['command_root']==root)
            check(local['family_id']==f['family_id'] and local['ordered_exposed_receptors']==[commands[n]['formula'] for n in ports], 'local ground check binds exposed receptors in declared order')
            local_commands=local['commands']
            check(len(local_commands)==len(members)+len(ports) and local['kernel_result']['rows']==len(local_commands)
                and local['kernel_result']['original_ground_sequent_accepted'] is True and local['kernel_result']['native_accepted'] is False
                and local['schema_universally_validated'] is False,'complete exposed-receptor ground receipt retains narrow host scope')
            check([x['formula'] for x in local_commands[:2]]==local['ordered_exposed_receptors'] and [x['index'] for x in local_commands[:2]]==[0,1], 'indexed local ground assumptions distinct')
            for position,source_index in enumerate(members):
                check({k:v for k,v in local_commands[2+position].items() if k not in ('antecedent','implication')}==
                      {k:v for k,v in commands[source_index].items() if k not in ('antecedent','implication')}, 'ground local body exact source witness, not a new authored target route')
            all_bodies.append(body)
        catalog_key=canonical([donor['header'],donor['licenses']]);catalogue_headers[catalog_key]=header
        donors.append({'certificate':donor['certificate'],'origin':d['origin'],'commands':len(commands),
            'eligible_bodies':len(eligible),'correlation':d['correlated_sequent_id'], 'consumed_Gamma':consumed})
    check(root_decisions==lib['complete_origin_census']==a['complete_command_root_census'],'complete ordered all-root census')
    metrics=a['metrics'];counts={'all_command_roots':len(root_decisions),'eligible_bodies':len(all_bodies),'families':len(lib['families']),
        'derivations':len(donors),'distinct_correlated_sequents':len(lib['correlated_sequents'])}
    check(math['counts']==dict(counts,independent_metrics=metrics),'Root count seal equals whole saved values')
    expected_metrics={'catalogues_started':len(catalogue_headers),'catalogues_completed':len(catalogue_headers),
        'exact_catalogue_cache_reuses':len(donors)-len(catalogue_headers),
        'complete_DAG_nodes':sum(h['codec']['node_count'] for h in catalogue_headers.values()),
        'complete_formula_codes':sum(h['dimensions']['formula_count'] for h in catalogue_headers.values())}
    total_licenses=sum(h['dimensions']['primitive_license_count'] for h in catalogue_headers.values())
    expected_metrics.update({k:total_licenses for k in ('complete_recipe_interfaces','complete_license_lines','primitive_commands_started','primitive_commands_completed')})
    expected_metrics.update({k:len(donors) for k in ('certificate_proofs_started','certificate_proofs_completed','point_unions_started','point_unions_completed')})
    expected_metrics.update({k:len(root_decisions) for k in ('command_roots_started','command_roots_completed')})
    expected_metrics.update({k:len(all_bodies) for k in ('open_ground_bodies_started','open_ground_bodies_completed')})
    check(metrics==expected_metrics,'all real started/completed/cached/catalogue/proof/body/root/point counts reconcile')
    check(r['complete_origin_count']==counts['all_command_roots'] and r['family_count']==counts['families'] and r['derivation_count']==counts['derivations'],'actual result summaries equal complete outputs')
    check(r['calls']==w['calls']=={'extraction_started':1,'extraction_completed':1,'independent_audit_started':1,'independent_audit_completed':1},'one producer and one audit invocation completed')
    false_a=('ROOT_inventory_admitted','schema_universally_validated','native_accepted','recipient_proof_accepted','full24_board_accepted','full_trajectory_accepted','new_lemma_discovered','new_RL_training')
    check(all(a[k] is False for k in false_a),'all audit authority boundaries remain false')
    check(lib['ROOT_inventory_admitted'] is False and lib['schema_universally_validated'] is False and lib['primitive_source_body_count']==0,'candidate library is unadmitted/universal-unproved/primitive inventory zero')
    check(all(math[k] is False for k in ('ROOT_library_admitted','ROOT_advice_admission','native_accepted','full24_board_accepted','full_trajectory_accepted','plane_tiling_accepted','universal_compiler_accepted','universal_schema_validity_accepted','new_RL_training'))
        and math['new_theorems']==math['recipient_proofs']==0,'Root seal does not admit schemes/library/new recipients/native/RL/speed')
    check(math['ROOT_complete_finite_extraction_and_ground_audit_accepted'] is True and math['saved_metadata_reconciliation_only'] is True and math['semantic_replay'] is False,'exact limited Root accepted finite actual checks, no additional replay')
    # Complete resource/caller chain from saved rows and wait4 receipts only.
    ledger=pinned_json(t['ownership_ledger']);scan(ledger)
    check(len(ledger['samples'])==t['sampled_observations'] and ledger['leftovers']=={} and ledger['kernel_worker_peak_bytes']==t['worker_kernel_peak_bytes'], 'whole retained owner/worker wait4 row ledger')
    conservative=max([t['ROOT_peak_bytes']+t['worker_kernel_peak_bytes']+t['direct_children_peak_sum_bytes']+t['observer_peak_bytes']]+[s['combined_bytes'] for s in ledger['samples']])
    check(conservative==t['peak_bytes'],'conservative kernel+owned sampled memory arithmetic')
    check(t['worker_returncode']==0 and t['owned_leftovers']==[] and t['all_direct_children_terminal_and_reaped'] is True
        and w['all_direct_children_terminal_and_reaped'] is True and w['direct_children']==w['direct_children_peak_sum_bytes']==0,'actual worker/observer ownership terminal closure, no worker child')
    check(post['resource_gate_accepted'] is True and post['terminal']['sha256']==pin(PROGRESS/files['owner'])['sha256']
        and post['elapsed_seconds']<=limits['whole_seconds'] and post['peak_bytes']<=limits['peak_bytes'],'postwrite true terminal hash/clock/peak gate')
    terminal=c['terminal'];owner_print=json.loads(terminal['output'].strip().splitlines()[-1])
    caller_seconds=(c['terminal_observed_ms']-c['started_ms'])/1000
    check(terminal['exit_code']==0 and c['chunks'][-1]==dict(terminal,observed_ms=c['terminal_observed_ms']), 'actual same terminal chunk observed before model resumes')
    check(len(c['chunks'])==2 and c['chunks'][0]['session_id']==31424 and c['chunks'][1]['exit_code']==0 and caller_seconds+1<=90, 'once-only initial+same-handle terminal polling and genuine caller clock')
    check(owner_print['resource_gate_accepted'] is True and owner_print['cancelled_at_final_print'] is False
        and owner_print['elapsed_seconds']==post['elapsed_seconds'] and owner_print['peak_bytes']==post['peak_bytes'], 'actual final owner print agrees with saved postwrite')
    check(resource['ROOT_final_accepted'] is True and resource['mismatches']==[] and len(resource['predicates'])==14 and all(resource['predicates'].values()),'all fourteen Root actual resource predicates true')
    check(math['resource_predicates']==resource['predicates'] and caller_seconds==resource['caller_elapsed_seconds']==math['costs']['caller_seconds'], 'Root math/resource actual caller clock linkage')
    check(w['inner_complete_seconds']<=20 and w['seconds']<55 and t['elapsed_before_write_seconds']+2<=60
        and t['peak_bytes']+8*1024*1024<=536870912 and w['peak_self_bytes']+12*1024*1024<=536870912,'source-bound inner/cold/publication reserves are inside original ceilings')
    cost={'caller_seconds':caller_seconds,'caller_finish_margin_seconds':1,'owned_postwrite_seconds':post['elapsed_seconds'],
        'inner_complete_seconds':w['inner_complete_seconds'],'extraction_call_seconds':r['extraction_call_seconds'],
        'independent_audit_call_seconds':r['independent_audit_call_seconds'],'owned_conservative_peak_bytes':post['peak_bytes']}
    check(math['costs']=={'caller_seconds':cost['caller_seconds'],'caller_finish_margin_seconds':1,'owned_seconds':cost['owned_postwrite_seconds'],
        'inner_complete_seconds':cost['inner_complete_seconds'],'extraction_call_seconds':cost['extraction_call_seconds'],
        'independent_audit_call_seconds':cost['independent_audit_call_seconds'],'peak_bytes':cost['owned_conservative_peak_bytes']},'all Root reported nested costs exact, not additively double counted')
    output={'schema':'independent-Incident-family-extraction-actual-saved-findings-v1','source_only':False,
        'saved_metadata_only':True,'all_checks_passed':not mismatches,'mismatches':mismatches,'scientific_calls':0,
        'reviewer_identity':'/root/arithmetic_induction','actual_worker_author':'/root/hilbert_ordering_diagnosis',
        'authorship_scope':'Reviewer authored the actual independent auditor Source; this saved review is provenance/metadata reconciliation, not a newly independent semantic replay of that auditor. Worker Source author is distinct and its Source review is genuine.',
        'metadata_or_resource_or_mathematical_authority_issued':False,'semantic_replay':False,
        'counts':counts,'donors':donors,'independent_actual_metrics':metrics,'costs':cost,
        'cost_scope':'Caller is an enclosing actual interval. Owned, inner, extraction and audit spans overlap and are not added as separate total pipeline cost. Source authoring/static helper costs are separate retained evidence, not excluded mathematical work.',
        'ROOT_math_disposition':pin(PROGRESS/files['math']),'actual_result':pin(PROGRESS/files['result']),
        'actual_library':pin(PROGRESS/files['library']),'actual_audit':pin(PROGRESS/files['audit']),
        'current_sources':p['sources'],'whole_named_raw_inputs':list(raw_inputs.values()),
        'raw_references_checked':len(refs),'distinct_raw_identities':len({(v['path'],v['sha256'],v['bytes']) for v in refs}),
        'checks':checks,'whole_explicit_pin_references':refs,
        'scope':['The actual finite three-donor extraction and independent ground/source/point/root checks were accepted by Root; all saved raw metadata agrees.',
            'Two parameterized Incident transport descriptions and four ground extracted bodies are correlated source evidence, not two new mathematical theorems or an I2 necessity/lemma proof.',
            'Universal schemas, ROOT inventory/advice admission, every future recipient grounding/current union/cold consumer/search/resource gate remain separate and unqualified here.',
            'No new recipient proof, native proof, full-board tiling, trajectory replay, RL training or comparative speed gain was performed by this reconciliation.'],
        'metadata_helper_elapsed_before_output_seconds':time.perf_counter()-began}
    findings=HERE/'extraction-actual-saved-findings-v1.json'
    with findings.open('x') as f:json.dump(output,f,indent=2,sort_keys=True);f.write('\n')
    handoff={'schema':'independent-Incident-family-extraction-actual-saved-review-handoff-v1',
        'findings':pin(findings),'all_checks_passed':not mismatches,'mismatches':mismatches,
        'scientific_calls':0,'saved_metadata_only':True,'ROOT_math_disposition':pin(PROGRESS/files['math'])}
    hp=HERE/'extraction-actual-saved-review-handoff-v1.json'
    with hp.open('x') as f:json.dump(handoff,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(dict(handoff=pin(hp),findings=pin(findings),checks=len(checks),mismatches=mismatches),sort_keys=True))

if __name__=='__main__':main()
