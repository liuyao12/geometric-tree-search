"""ROOT presentation/archive assembly from saved metadata; no scientific calls."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/equality-receptor-family-extraction-progress-20261014'
PUBLIC=HERE/'public-report-v1'


def snapshot(path,expected=None):
    path=Path(path)
    if not path.is_absolute():path=ROOT/path
    assert path.resolve()==path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size)==(after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size)
    record=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
    if expected is not None:assert record==dict(expected,path=str(path))
    return path,raw,record


def pin(path):return snapshot(path)[2]


def save(path,value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')


def main():
    assert len(sys.argv)==2
    peer_path,peer_raw,peer_pin=snapshot(Path(sys.argv[1]).resolve());peer=json.loads(peer_raw)
    assert peer['all_checks_passed'] is True and peer['scientific_calls']==0
    seal_path,seal_raw,seal_pin=snapshot(PROGRESS/'ROOT-actual-family-extraction-disposition-v1.json')
    assert seal_pin['sha256']=='757606d7a20048e5a8335559c96cf1749e1ab53f900bdff593fb10beeed8a173'
    assert peer_pin['sha256']=='ebba366615a1e5ce96028dcad0dd5c819d9b82564545d004a937f44b12e577b4'
    seal=json.loads(seal_raw)
    assert seal['ROOT_complete_finite_extraction_and_ground_audit_accepted'] is True
    assert not PUBLIC.exists();PUBLIC.mkdir()
    for name in ('reader.html','viewer.js'):
        (PUBLIC/name).write_bytes(snapshot(HERE/name)[1])
    for record,name in [(seal['actual_candidate_library'],'candidate-library.json'),(seal['actual_independent_audit'],'independent-audit.json')]:
        (PUBLIC/name).write_bytes(snapshot(record['path'],record)[1])
    (PUBLIC/'qualification.json').write_bytes(seal_raw)
    (PUBLIC/'independent-review.json').write_bytes(peer_raw)
    summary=dict(schema='notebook157-complete-family-extraction-reader-summary-v1',completed=True,
        counts=seal['counts'],costs=seal['costs'],qualification=seal_pin,independent_review=peer_pin,
        library_admitted=False,recipient_searches=0,new_theorems=0,new_RL_training=False)
    save(PUBLIC/'summary.json',summary)
    worker_path,worker_raw,worker_pin=snapshot(seal['actual_worker']['path'],seal['actual_worker'])
    worker=json.loads(worker_raw)
    plan_path,plan_raw,plan_pin=snapshot(worker['plan']['path'],worker['plan'])
    plan=json.loads(plan_raw)
    files={}
    def add(path,expected=None,scope='fresh task Source/history snapshot'):
        path,raw,record=snapshot(path,expected)
        if str(path) in files:
            assert files[str(path)][1:3]==(raw,record)
            return
        files[str(path)]=(path,raw,record,scope)
    for record in plan['closure']:
        path,raw,verified=snapshot(record['path'],record)
        if ROOT in path.parents:files[str(path)]=(path,raw,verified,'exact activated named input closure')
    for record in [seal_pin,peer_pin,worker_pin,plan_pin,seal['actual_resource_gate'],seal['actual_result'],seal['actual_candidate_library'],seal['actual_independent_audit'],seal['actual_evidence']]:
        add(record['path'],record,'declared actual evidence pin')
    directories=[PROGRESS,ROOT/'.gcts-active/equality-receptor-family-extraction-source-20261014',
        ROOT/'.gcts-active/equality-receptor-family-independent-source-20261014',
        ROOT/'.gcts-active/equality-receptor-family-I2-recipient-source-20261014',
        ROOT/'.gcts-active/equality-receptor-family-ROOT-source-20261014']
    for directory in directories:
        for path in directory.rglob('*'):
            if path.is_file() and path.suffix not in ('.zip','.pyc'):
                assert path.resolve()==path
                add(path)
    for name in ('reader.html','viewer.js','build_report_v1.py'):
        add(HERE/name)
    for path in HERE.glob('*findings*.json'):
        add(path)
    members=[]
    with zipfile.ZipFile(PUBLIC/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        archive.writestr('README.txt',
            'Notebook157: one actual complete original-donor family extraction and independent audit.\n'
            'ROOT scientific activation only; Source/history/reader files are not new scientific runs.\n'
            'Project member paths retain original repository-relative names and whole bytes.\n'
            'Runtime binaries are hashes only, not archived. Reproduction requires a fresh namespace, exact runtime/path/source requalification, and the reviewed worker/owner.\n'
            'All original donor roots retained. Universal family validity, usable inventory admission, recipient search, new theorem, RL and speed comparisons remain open.\n')
        for path,raw,record,scope in sorted(files.values(),key=lambda item:str(item[0])):
            name=str(path.relative_to(ROOT))
            archive.writestr(name,raw)
            members.append(dict(member=name,sha256=record['sha256'],bytes=record['bytes'],scope=scope))
    save(PUBLIC/'source-archive-manifest.json',dict(schema='notebook157-source-and-actual-evidence-archive-manifest-v1',
        project_members=members,member_count=len(members),runtime_binary_files_archived=False,
        scope='Whole named activated input closure plus complete actual run, Source review/history and presentation sources. No consumer trial or semantic replay added.'))
    pubfiles=[]
    for path in sorted(PUBLIC.iterdir()):
        raw=pin(path);pubfiles.append(dict(raw,destination='docs/research/gcts-rl-renewal/receptor-extraction/'+path.name))
    save(HERE/'ROOT-notebook157-task-file-manifest-v1.json',dict(schema='ROOT-notebook157-task-publication-manifest-v1',
        files=pubfiles,author_identity='/root',only_task_owned_files=True,existing_destination='GitHub Pages geometric-tree-search',
        hub_index_source='Use existing deployed isolated checkout index, adding the task panel only; preserve Root unrelated index.'))
    print(json.dumps(dict(public=str(PUBLIC),public_files=len(pubfiles),archive_project_members=len(members),science=0)))


if __name__=='__main__': main()
