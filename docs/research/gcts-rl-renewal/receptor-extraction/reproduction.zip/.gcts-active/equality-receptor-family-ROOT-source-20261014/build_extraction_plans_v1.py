"""ROOT metadata assembly only. No project imports or scientific functions."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PROGRESS = ROOT / '.gcts-active/equality-receptor-family-extraction-progress-20261014'


def pin(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def read(record):
    path = Path(record['path'])
    assert pin(path) == record
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
    return pin(path)


def owner_pin(record):
    record = dict(record)
    path = Path(record['path'])
    if ROOT in path.parents:
        record['path'] = str(path.relative_to(ROOT))
    return record


def main():
    assert len(sys.argv) == 2
    peer_pin = pin(sys.argv[1]); peer = read(peer_pin)
    handoff_pin = pin(ROOT / '.gcts-active/equality-receptor-family-extraction-source-20261014/handoff-v2.json')
    handoff = read(handoff_pin)
    assert handoff_pin['sha256'] == '0bc4f483c1bcb6ac430e6862d8d8ff06f12e9c159ce31c442efd8f1e59c7166e'
    sources = handoff['sources']
    assert len(sources) == 10 and peer['sources'] == sources
    assert peer['source_only'] is True and peer['source_review_passed'] is True
    assert peer['scientific_calls'] == 0 and peer['author_identity'] == '/root/hilbert_ordering_diagnosis'
    assert peer['reviewer_identity'] != peer['author_identity']
    for record in sources.values():
        assert pin(record['path']) == record
    prior_review_pin = pin(ROOT / '.gcts-active/hilbert-next-owned-progress-20261013/ROOT-source-review-v1.json')
    runtime = read(prior_review_pin)['runtime']
    for key in ('executable', 'observer', 'resource_ext', 'posix_ext'):
        assert pin(runtime[key]['path']) == runtime[key]
    assert not PROGRESS.exists()
    PROGRESS.mkdir()
    owner_source = handoff['flat_supervision']['owner']
    closer_source = handoff['flat_supervision']['closer']
    for original, name in ((owner_source, 'run_owned_bridge_v2.py'), (closer_source, 'close_stage_decision_v1.py')):
        assert pin(original['path']) == original
        (PROGRESS / name).write_bytes(Path(original['path']).read_bytes())
    root_review = dict(schema='ROOT-equality-receptor-family-extraction-source-review-v1',
        reviewer_identity='/root', source_only=True, source_review_passed=True, scientific_calls=0,
        execution_authorized=True, sources=sources, runtime=runtime,
        source_whole_read=['parent-worker804a09 plus entire narrow successor delta7fefb8', 'auditor739e25', 'familyde5f58', 'old-reader5d03'],
        source_assessment=[
            'Entire frozen worker and independent auditor read and reviewed; actual finite extraction remains unexecuted.',
            'Original three donor certificates and all command roots retained; independently reconstructed full catalogue, licensing, provenance, ordered ports, ground proofs and exact current point unions.',
            'Four source modules execute in one cold worker; ten raw roles authenticated. No graph, search, new target, native authority, inventory or RL activation.',
            'Shared20s includes cold module loading, extraction, independent audit, serialization, final alias guards; incomplete work removes usable candidate aliases.',
            'Byte-identical inherited owner and closer retain complete14-predicate resource closure and separate genuine caller measurement.'
        ],
        handoff=handoff_pin, independent_worker_review=peer_pin,
        owner_source_pin=pin(PROGRESS/'run_owned_bridge_v2.py'),
        closer_source_pin=pin(PROGRESS/'close_stage_decision_v1.py'),
        trust='Pinned runtime, source guards and task-owned process filtering trusted; no hard OS memory cap or universal mathematical schema claim.')
    root_pin = save(PROGRESS/'ROOT-source-review-v1.json', root_review)
    spec_pin = handoff['training_specification']; spec = read(spec_pin)
    records = list(sources.values()) + [runtime['executable'], root_pin, peer_pin, spec_pin]
    records += [spec[k] for k in ('design', 'handoff', 'ROOT_mathematical_disposition')]
    for donor in spec['certificates']:
        records += [donor[k] for k in ('certificate', 'result', 'qualification', 'header', 'licenses', 'resource_disposition')]
        records += list(read(donor['header'])['streams'].values())
    closure = {}
    for record in records:
        assert pin(record['path']) == record
        assert record['path'] not in closure or closure[record['path']] == record
        closure[record['path']] = record
    limits = dict(whole_seconds=60, peak_bytes=536870912, caller_seconds=90, control_seconds=20)
    owner_path = PROGRESS/'replay-plan-v1.json'
    worker_path = PROGRESS/'worker-plan-v1.json'
    worker = dict(schema='ROOT-equality-receptor-family-extraction-worker-plan-v1',
        ROOT_owned_once_only=True, sources=sources, runtime={'binary':runtime['executable']},
        reviews={'ROOT':root_pin, 'independent':peer_pin}, closure=list(closure.values()),
        limits=limits, output_directory=str(PROGRESS/'worker-output-v1'),
        owner_plan_path=str(owner_path), training_specification=spec_pin)
    worker_pin = save(worker_path, worker)
    extended = list(closure.values()) + [worker_pin, pin(PROGRESS/'run_owned_bridge_v2.py'),
        pin(PROGRESS/'close_stage_decision_v1.py')] + [runtime[k] for k in ('observer','resource_ext','posix_ext')]
    extra = {r['path']:r for r in extended}
    argv = [runtime['executable']['path'], '-B', sources['worker']['path'], str(worker_path), str(owner_path)]
    owner = dict(schema='ROOT-guard-native-owned-plan-v1', stage='replay',
        worker=str(Path(sources['worker']['path']).relative_to(ROOT)), argv=argv,
        worker_receipt=str((PROGRESS/'worker-output-v1/worker-receipt-v1.json').relative_to(ROOT)),
        limits=limits, runtime_binary=runtime['executable'], ROOT_source_review=owner_pin(root_pin),
        scope='Complete original donor family extraction and independent audit; no search replay. One immutable ROOT attempt.',
        closure=[owner_pin(r) for r in extra.values()])
    owner_plan_pin = save(owner_path, owner)
    print(json.dumps(dict(progress=str(PROGRESS), worker_plan=worker_pin, owner_plan=owner_plan_pin,
        raw_source_roles=10, executed_roles=4, leaf_fields=len(worker), owner_fields=len(owner),
        closure_paths=len(closure), scientific_calls=0)))


if __name__ == '__main__':
    main()
