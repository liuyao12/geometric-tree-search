"""ROOT saved-metadata disposition of actual timed checks; no semantic replay."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PROGRESS = ROOT / '.gcts-active/equality-receptor-family-extraction-progress-20261014'
OUT = PROGRESS/'worker-output-v1'


def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def read(path):
    return json.loads(Path(path).read_bytes())


def check_record(record):
    path = Path(record['path'])
    if not path.is_absolute(): path = ROOT/path
    assert pin(path) == dict(record, path=str(path))
    return path


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def main():
    gate_path=PROGRESS/'replay-ROOT-final-decision-v1.json'; gate=read(gate_path)
    assert gate['ROOT_final_accepted'] is True and len(gate['predicates'])==14 and all(gate['predicates'].values())
    plan=read(PROGRESS/'worker-plan-v1.json')
    for record in plan['closure']: check_record(record)
    worker=read(OUT/'worker-receipt-v1.json')
    assert worker['stage_completed'] is True and worker['scientific_stage']=='complete_original_donor_family_extraction_and_audit'
    result=read(check_record(worker['result'])); library=read(check_record(worker['candidate_library']))
    audit=read(check_record(worker['independent_audit'])); evidence=read(check_record(worker['evidence']))
    assert result['completed'] is True and result['accepted_prefix'] is False
    assert audit['completed'] is True and audit['all_checks_passed'] is True and audit['mismatches']==[]
    assert audit['candidate_library_sha256']==digest(library)
    assert library['complete_origin_census']==audit['complete_command_root_census']
    assert result['complete_origin_count']==len(library['complete_origin_census'])==audit['metrics']['command_roots_completed']
    assert result['family_count']==len(library['families']) and result['derivation_count']==len(library['derivations'])
    assert worker['calls']==result['calls']==dict(extraction_started=1,extraction_completed=1,independent_audit_started=1,independent_audit_completed=1)
    for start,end in [('catalogues_started','catalogues_completed'),('certificate_proofs_started','certificate_proofs_completed'),('open_ground_bodies_started','open_ground_bodies_completed'),('command_roots_started','command_roots_completed'),('point_unions_started','point_unions_completed'),('primitive_commands_started','primitive_commands_completed')]:
        assert audit['metrics'][start]==audit['metrics'][end]
    assert audit['metrics']['open_ground_bodies_completed']==sum(root['eligible'] for root in library['complete_origin_census'])==len(audit['open_ground_body_checks'])
    for ground in audit['open_ground_body_checks']:
        assert ground['kernel_result']['original_ground_sequent_accepted'] is True
        assert ground['schema_universally_validated'] is False and ground['native_accepted'] is False
    assert worker['inner_complete_seconds']<=20 and gate['caller_elapsed_seconds']+1<=90
    assert not any(result[k] for k in ('ROOT_library_admitted','ROOT_advice_admission','universal_schema_validity_accepted','recipient_proofs','target_searches','new_RL_training'))
    assert not library['ROOT_inventory_admitted'] and not library['schema_universally_validated']
    owner_post=read(PROGRESS/'replay-owner-v1/post-write-observation-v1.json')
    disposition=dict(schema='ROOT-actual-complete-Incident-family-extraction-disposition-v1',author_identity='/root',
        actual_scientific_invocations=1, saved_metadata_reconciliation_only=True, semantic_replay=False,
        ROOT_complete_finite_extraction_and_ground_audit_accepted=True,
        actual_resource_gate=pin(gate_path), actual_worker=pin(OUT/'worker-receipt-v1.json'),
        actual_result=worker['result'], actual_candidate_library=worker['candidate_library'],
        actual_independent_audit=worker['independent_audit'], actual_evidence=worker['evidence'],
        original_training_specification=plan['training_specification'], sources=plan['sources'],
        whole_named_closure_paths=len(plan['closure']), resource_predicates=gate['predicates'],
        counts=dict(derivations=len(library['derivations']),distinct_correlated_sequents=len(library['correlated_sequents']),
            all_command_roots=len(library['complete_origin_census']),eligible_bodies=len(audit['open_ground_body_checks']),
            families=len(library['families']), independent_metrics=audit['metrics']),
        costs=dict(inner_complete_seconds=worker['inner_complete_seconds'],owned_seconds=owner_post['elapsed_seconds'],
            caller_seconds=gate['caller_elapsed_seconds'],caller_finish_margin_seconds=1,peak_bytes=owner_post['peak_bytes'],
            extraction_call_seconds=worker['extraction_call_seconds'],independent_audit_call_seconds=worker['independent_audit_call_seconds']),
        ROOT_library_admitted=False,ROOT_advice_admission=False,universal_schema_validity_accepted=False,
        recipient_proofs=0,new_theorems=0,new_RL_training=False,native_accepted=False,full24_board_accepted=False,
        full_trajectory_accepted=False,universal_compiler_accepted=False,plane_tiling_accepted=False,
        scope='Actual finite source-bound extraction and independent full-root/current-union/ground-body checks accepted. Ground exposed receptors are local hypotheses, not universally quantified lemma validity. Candidate inventory is not yet admitted; no recipient or speed comparison has run.')
    target=PROGRESS/'ROOT-actual-family-extraction-disposition-v1.json'
    with target.open('x') as stream:
        json.dump(disposition,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(disposition=pin(target),counts=disposition['counts'],costs=disposition['costs'],ROOT_library_admitted=False)))


if __name__=='__main__': main()
