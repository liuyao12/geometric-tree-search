Notebook157: one actual complete original-donor family extraction and independent audit.
ROOT scientific activation only; Source/history/reader files are not new scientific runs.
Project member paths retain original repository-relative names and whole bytes.
Runtime binaries are hashes only, not archived. Reproduction requires a fresh namespace, exact runtime/path/source requalification, and the reviewed worker/owner.
All original donor roots retained. Universal family validity, usable inventory admission, recipient search, new theorem, RL and speed comparisons remain open.
