"""ROOT actual saved-result disposition; raw metadata only, no semantic replay."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/hilbert-i2-first-proof-progress-20261014'
PEER=ROOT/'.gcts-active/receptor-i2-independent-implementation-review-20261013'

def pin(path):
    path=Path(path);path=path if path.is_absolute() else ROOT/path
    raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    actual=pin(record['path']);assert actual['sha256']==record['sha256'] and actual['bytes']==record['bytes']
    return Path(actual['path'])

def read(path):
    path=Path(path);raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.name.endswith('.gz') else raw)

def read_verified(record):
    path=Path(record['path']);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    return json.loads(gzip.decompress(raw) if path.name.endswith('.gz') else raw)

def main():
    construction_path=PROGRESS/'ROOT-construction-v1.json';construction_pin=dict(path=str(construction_path),sha256='5b133e1d0fa3a4e8be74684a2fa2c9c4e3fa43c2498c5777fab5b469b60687c7',bytes=30774);construction=read_verified(construction_pin)
    review_path=PEER/'I2-first-proof-four-lane-actual-saved-findings-v1.json';review_pin=pin(review_path);assert review_pin['sha256']=='1cffc498a3880ffbb349dca9ba24a425a71c397428b2f3ec4fda5dd32989292d';review=read_verified(review_pin)
    assert review['scientific_calls']==0 and review['all_checks_passed'] is True and review['mismatches']==[]
    trials=[]
    for lane in construction['lanes']:
        directory=Path(lane['owner_plan']['path']).parent
        resource_path=directory/'ROOT-resource-disposition-v1.json';resource_pin=pin(resource_path);resource=read_verified(resource_pin)
        assert resource['resource_accepted'] is True and resource['owner_plan']==lane['owner_plan']
        for key in ('owner_plan','actual_terminal','owner_terminal','post_write','worker_receipt','result','qualified_context'):check(resource[key])
        result=read_verified(resource['result']);q=read_verified(resource['qualified_context']);header=read_verified(q['catalog'])
        assert q['instance_id']==lane['selector'] and len(q)==11
        assert q['all_complete_catalog_licenses_and_initial24domains_accepted'] is True
        assert header['bodies']==header['complete_cluster_inventory']==[]
        assert result['root_restored'] is True and result['training_updates']==0
        assert result['commits']==[] and result['rng_draws']==[] and result['registered_whole_descriptor_count']==0
        accepted=resource['checked_logical_target_candidate'];essential=False;consumed=[];rules={}
        if accepted:
            certificate=read_verified(resource['logical_certificate']);proof=certificate['checked_patch'];patch=proof['patch']
            assert proof['original_Gamma_target_sequent_accepted'] is True and proof['primary_endpoint_eligible'] is True
            assert proof['prospective_current_point_union_accepted'] is True
            assert patch['conclusion']==header['target'] and patch['exact_original_ordered_gamma']==header['context']['ordered_local_premises']
            assert patch['kernel_result']['original_ground_sequent_accepted'] is True
            commands=patch['commands'];assert patch['kernel_result']['rows']==len(commands)==len(patch['primitive_keys'])
            pending=[len(commands)-1];closure=set()
            while pending:
                i=pending.pop()
                if i in closure:continue
                closure.add(i);c=commands[i]
                if c['rule']=='mp':
                    assert 0<=c['antecedent']<i and 0<=c['implication']<i
                    pending.extend([c['antecedent'],c['implication']])
            named=[i for i in sorted(closure) if commands[i]['rule']=='axiom' and commands[i]['name']=='I.2']
            essential=bool(named) and any(commands[i]['rule']=='mp' and any(j in named for j in (commands[i]['antecedent'],commands[i]['implication'])) for i in closure)
            consumed=patch['consumed_original_occurrence_indices']
            for c in commands:rules[c['rule']]=rules.get(c['rule'],0)+1
            assert result['trace_complete'] is True and result['logical_target_proof_accepted'] is True
            assert result['status']=='first_checked_original_Gamma_target_proof'
            assert proof['origin_kind']==resource['logical_origin_kind']
            assert result['actual_selected_target_proof_accepted'] is (proof['origin_kind']=='actual_selected')
            assert all(proof[k] is False for k in ('full24_board_accepted','native_accepted','full_trajectory_accepted','inventory_admitted','new_RL_training','universal_compiler_accepted'))
        else:
            assert resource['logical_certificate'] is None and result['first_checked_proof'] is None
            assert result['logical_target_proof_accepted'] is False
        trials.append(dict(selector=lane['selector'],lane=lane['lane'],mode=lane['mode'],
            status=result['status'],ROOT_checked_logical_derivation_accepted=accepted,
            origin_kind=resource['logical_origin_kind'],essential_I2_in_strict_dependency_closure=essential,
            consumed_original_occurrence_indices=consumed,rule_census=rules,
            resource_disposition=resource_pin,result=resource['result'],logical_certificate=resource['logical_certificate'],qualified_context=resource['qualified_context'],
            exact_original_Gamma=header['context']['ordered_local_premises'],exact_target=header['target'],
            placements=result['attempts'],events=len(result['events']),trace_complete=result['trace_complete'],
            search_seconds=result['search_seconds_including_certificate_and_return_preparation'],
            caller_seconds_with_margin=resource['caller_seconds_with_margin'],owned_postwrite_seconds=resource['owner_postwrite_seconds'],
            conservative_peak_bytes=resource['conservative_owned_peak_bytes'],candidate_advice_construction=result['candidate_advice']['construction'],
            full24_board_accepted=False,native_accepted=False,independent_full_trajectory_accepted=False,new_RL_training=False,performance_comparison_accepted=False))
    assert len(trials)==4
    value=dict(schema='ROOT-I2-first-checked-proofs-disposition-v1',author_identity='/root',ROOT_final_accepted=True,
        scientific_calls_in_this_metadata_seal=0,actual_once_only_trials=4,restarts=0,complete_resources_accepted=4,
        checked_logical_derivations=sum(t['ROOT_checked_logical_derivation_accepted'] for t in trials),
        distinct_proved_sequents=len({t['selector'] for t in trials if t['ROOT_checked_logical_derivation_accepted']}),
        selected_derivations=sum(t['origin_kind']=='actual_selected' for t in trials),
        completed_unselected_source_proposals=sum(t['origin_kind']=='completed_source_proposal' for t in trials),
        preserved_UNKNOWN_trials=sum(not t['ROOT_checked_logical_derivation_accepted'] for t in trials),
        essential_I2_derivations=sum(t['essential_I2_in_strict_dependency_closure'] for t in trials),
        trials=trials,construction=construction_pin,independent_saved_audit=review_pin,
        endpoint_preregistration=pin(ROOT/'.gcts-active/hilbert-i2-ROOT-source-20261013/ROOT-first-checked-endpoint-preregistration-v1.json'),
        proof_input_sequences_supplied=False,all_inventories_empty=True,preregistered_endpoint_unchanged=True,
        mathematical_authority='Actual timed independent GroundChecker and literal point/current-union checks in the exact source-sealed observer, with each complete cold owned/caller resource chain. Peer saved audit and this seal reconcile metadata without semantic replay.',
        full24_board_accepted=False,native_accepted=False,independent_full_trajectory_accepted=False,
        learned_marking=False,new_RL_training=False,performance_comparison_accepted=False,universal_compiler_accepted=False,whole_plane_tiling_accepted=False,research_program_complete=False,
        provenance=pin(__file__),assessment='The saved actual bounded outcomes are reported without selecting successes only. I.2 use requires the named axiom to lie in the strict dependency closure and be consumed by modus ponens, rather than merely being available in the catalogue. Selected ancestry and compatible unselected proposal origins are separate. The generic adviser is conventional target-blind witness search, not RL; no superiority or full research-objective claim.')
    destination=HERE/'ROOT-actual-first-checked-I2-proofs-v1.json'
    with destination.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
    print(json.dumps(dict(disposition=pin(destination),proofs=value['checked_logical_derivations'],I2=value['essential_I2_derivations'],UNKNOWN=value['preserved_UNKNOWN_trials'],scientific_calls_in_seal=0)))

if __name__=='__main__':main()
