"""Pack reviewed display-only fixes, preserving all actual scientific capsules."""
import copy
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PUB=Path('/private/tmp/gcts-family-router-publish-20261010')
PUBLIC=Path('docs/research/gcts-rl-renewal/hilbert-i2')

def pin(path):
    raw=Path(path).read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def raw_verified(record):
    raw=Path(record['path']).read_bytes()
    assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    return raw

def save(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')

def main():
    parent=HERE/'public-report-v1';dest=HERE/'public-report-display-v2';dest.mkdir()
    manifest=json.loads((parent/'source-archive-manifest.json').read_bytes())
    parent_zip=manifest['archive'];raw_verified(parent_zip)
    extras=[HERE/'display-source-v2/reader.html',HERE/'display-source-v2/viewer.js',Path(__file__),
        ROOT/'.gcts-active/hilbert-i2-first-proof-report-independent-20261014/findings-v1.json',
        ROOT/'.gcts-active/hilbert-i2-first-proof-report-independent-20261014/display-v2-findings-v1.json']
    assert pin(extras[-1])['sha256']=='74689b6ac5fb35c5c481f2f1ea116bc1c9e3292e33bd5b74de6c45fbc00dd9dc'
    members=copy.deepcopy(manifest['members'])
    with zipfile.ZipFile(parent_zip['path']) as source,zipfile.ZipFile(dest/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as target:
        for item in members:
            raw=source.read(item['archive_path'])
            assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
            target.writestr(item['archive_path'],raw)
        target.writestr('REPRODUCTION.txt',source.read('REPRODUCTION.txt')+b'Display V2 adds narrow reviewed grid overflow and singular/plural fixes. All actual proof, UNKNOWN, resource and mathematical authority records are byte-unchanged. Original reader sources remain available alongside the successors.\n')
        for path in extras:
            record=pin(path);raw=raw_verified(record);name=str(path.relative_to(ROOT))
            target.writestr(name,raw);members.append(dict(archive_path=name,source=record))
    with zipfile.ZipFile(dest/'reproduction.zip') as package:
        assert len(package.namelist())==len(members)+1
        for item in members:
            raw=package.read(item['archive_path'])
            assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
    manifest.update(members=members,archive=pin(dest/'reproduction.zip'),
        display_only_successor=True,scientific_capsules_unchanged=True,
        original_archive=parent_zip,independent_display_review=pin(extras[-1]))
    save(dest/'source-archive-manifest.json',manifest)
    for name in ('reader.html','viewer.js'):
        raw=(HERE/'display-source-v2'/name).read_bytes();(dest/name).write_bytes(raw)
    for repo in (ROOT,PUB):
        for path in dest.iterdir():(repo/PUBLIC/path.name).write_bytes(path.read_bytes())
    task=json.loads((HERE/'ROOT-notebook156-task-file-manifest-v1.json').read_bytes())
    for record in task['files']:
        current=pin(PUB/record['path'])
        record.update(sha256=current['sha256'],bytes=current['bytes'])
    task.update(archive_project_members=len(members),display_only_successor=True,
        independent_display_review=pin(extras[-1]),scientific_capsules_unchanged=True)
    save(HERE/'ROOT-notebook156-task-file-manifest-v2.json',task)
    print(json.dumps(dict(task_files=len(task['files']),archive_members=len(members),proofs=1,UNKNOWN=3,scientific_calls=0)))

if __name__=='__main__':main()
