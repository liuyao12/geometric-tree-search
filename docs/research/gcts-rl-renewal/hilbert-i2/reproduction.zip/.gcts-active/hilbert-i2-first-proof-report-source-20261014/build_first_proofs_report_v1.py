"""ROOT saved proof/resource metadata to HTML reader data; no scientific replay."""
import copy
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PROGRESS=ROOT/'.gcts-active/hilbert-i2-first-proof-progress-20261014'
PUB=Path('/private/tmp/gcts-family-router-publish-20261010')
PUBLIC=Path('docs/research/gcts-rl-renewal/hilbert-i2')
ROOT_SEAL=ROOT/'.gcts-active/hilbert-i2-first-proof-ROOT-source-20261014/ROOT-actual-first-checked-I2-proofs-v1.json'

def pin(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

def check(record):
    path=Path(record['path']);path=path if path.is_absolute() else ROOT/path
    current=pin(path);assert current['sha256']==record['sha256'] and current['bytes']==record['bytes']
    return path

def read(path):
    path=Path(path);raw=path.read_bytes()
    if path.name.endswith('.gz'):raw=gzip.decompress(raw)
    return json.loads(raw)

def verified_bytes(record):
    path=Path(record['path']);path=path if path.is_absolute() else ROOT/path
    before=path.stat();raw=path.read_bytes();after=path.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
    return path,raw

def read_verified(record):
    path,raw=verified_bytes(record)
    return json.loads(gzip.decompress(raw) if path.name.endswith('.gz') else raw)

def write(path,raw):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(raw)

def save(path,value):write(path,(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n').encode())

def main():
    seal_pin=pin(ROOT_SEAL);assert seal_pin['sha256']=='1bfae2aac3a86271e5895726e2271e9544972261fb553143126645ccfd28a5da';seal=read_verified(seal_pin)
    assert seal['ROOT_final_accepted'] is True and len(seal['trials'])==4
    audit_path=check(seal['independent_saved_audit'])
    old_index=PUB/'docs/research/gcts-rl-renewal/index.html'
    assert pin(old_index)['sha256']=='e3d6e9ad1bd0541491930a14807bc3429752525f030ad10bf8941a97e881f57a'
    output=HERE/'public-report-v1';output.mkdir()
    for name in ('reader.html','viewer.js'):write(output/name,(HERE/name).read_bytes())
    write(output/'qualification.json',verified_bytes(seal_pin)[1])
    write(output/'independent-review.json',verified_bytes(seal['independent_saved_audit'])[1])
    raw_routes=[];proofs=[];trials=[];archive={};declared_archive={};external={}
    for trial in seal['trials']:
        case=trial['selector'];lane=trial['lane'];directory=PROGRESS/case/lane
        resource_path=check(trial['resource_disposition']);resource=read_verified(trial['resource_disposition'])
        result_path=check(trial['result']);result=read_verified(trial['result'])
        prefix=Path('evidence')/case/lane
        exports={'result-v1.json.gz':trial['result'],'resources-v1.json':trial['resource_disposition']}
        if trial['logical_certificate']:exports['proof-v1.json']=trial['logical_certificate']
        for name,record in exports.items():
            path,raw=verified_bytes(record)
            relative=prefix/name;write(output/relative,raw)
            assert (output/relative).read_bytes()==raw
            raw_routes.append(dict(public_path=str(relative),source=record))
        row=copy.deepcopy(trial)
        row.update(accepted=trial['ROOT_checked_logical_derivation_accepted'],
            raw_result_url=str(prefix/'result-v1.json.gz'),raw_resource_url=str(prefix/'resources-v1.json'),
            raw_certificate_url=str(prefix/'proof-v1.json') if trial['logical_certificate'] else None,
            proposals_scanned=result.get('proof_observer',{}).get('metrics',{}).get('proposals_scanned'),
            adviser_work=trial['candidate_advice_construction'])
        trials.append(row)
        if trial['logical_certificate']:
            certificate=read_verified(trial['logical_certificate']);proof=certificate['checked_patch'];patch=proof['patch']
            marks={(x,y):value for x,y,value in patch['literal_points']['m']}
            selected_keys={json.dumps(k,separators=(',',':')) for k in proof['source_state']['order']}
            tiles=[]
            assert len(patch['primitive_keys'])==len(patch['commands'])
            for key,command in zip(patch['primitive_keys'],patch['commands']):
                recipe,row_address,refs=key
                assigned=[[1,row_address,marks[1,row_address]]]
                for position,ref in enumerate(refs):
                    assigned.extend([[1,ref,marks[1,ref]],[2+position,row_address,marks[2+position,row_address]]])
                tiles.append(dict(key=key,recipe_index=recipe,row=row_address,refs=refs,
                    already_selected=json.dumps(key,separators=(',',':')) in selected_keys,
                    command=command,formula_code=marks[1,row_address],t=[[0,row_address,1]],m=assigned))
            proofs.append(dict(selector=case,lane=lane,origin_kind=proof['origin_kind'],essential_I2=trial['essential_I2_in_strict_dependency_closure'],consumed_original_occurrence_indices=trial['consumed_original_occurrence_indices'],
                gamma=trial['exact_original_Gamma'],target=trial['exact_target'],root_row=proof['root_row'],
                tiles=tiles,formula_points=[mark for mark in patch['literal_points']['m'] if mark[0]==1 and mark[1]>=0],
                current_occupied=sum(x==1 for x in proof['source_state']['totals']),
                raw_certificate_url=str(prefix/'proof-v1.json'),source_certificate=trial['logical_certificate'],
                kernel_result=patch['kernel_result'],logical_kernel_seconds=patch['kernel_seconds'],
                literal_point_seconds=patch['literal_point_seconds'],current_union_accepted=True))
        owner_path=check(resource['owner_plan']);owner=read_verified(resource['owner_plan'])
        for record in owner['closure']:
            path=check(record);canonical=path.resolve()
            if ROOT not in canonical.parents:
                current=pin(canonical);external[current['path']]=current;continue
            name=str(canonical.relative_to(ROOT));assert name not in archive or archive[name].read_bytes()==canonical.read_bytes()
            archive[name]=canonical
            expected=dict(record,path=str(canonical))
            assert name not in declared_archive or declared_archive[name]==expected
            declared_archive[name]=expected
        for subfolder in ('worker-output-v1','owner-output-v1'):
            for path in (directory/subfolder).rglob('*'):
                if path.is_file():archive[str(path.relative_to(ROOT))]=path
        for path in (owner_path,directory/'actual-terminal-v1.json',resource_path):archive[str(path.relative_to(ROOT))]=path
    for path in (ROOT_SEAL,audit_path,ROOT/'.gcts-active/receptor-i2-independent-implementation-review-20261013/I2-first-proof-four-lane-preactivation-saved-findings-v1.json',PROGRESS/'ROOT-construction-v1.json',ROOT/'.gcts-active/hilbert-i2-first-proof-ROOT-source-20261014/seal_ROOT_first_proofs_v1.py',Path(__file__),HERE/'reader.html',HERE/'viewer.js'):
        archive[str(path.relative_to(ROOT))]=path
    assert len(proofs)==seal['checked_logical_derivations'] and len(trials)==4 and len(raw_routes)==8+len(proofs)
    summary=dict(schema='ROOT-notebook156-first-checked-proof-reader-data-v1',scientific_calls=0,
        source_disposition=seal_pin,independent_saved_audit=seal['independent_saved_audit'],
        trials=trials,proofs=proofs,all_proof_commands_copied_from_actual_certificates=True,
        display_tile_support_projection_only=True,viewer_performs_no_logical_or_point_validation=True,
        no_new_proof_or_search_constructed=True,full24_accepted=False,new_RL_training=False)
    save(output/'summary.json',summary)
    assert all(not name.startswith('.git/') and not Path(name).name.startswith('.env') for name in archive)
    members=[]
    with zipfile.ZipFile(output/'reproduction.zip','x',compression=zipfile.ZIP_DEFLATED) as package:
        for name,path in sorted(archive.items()):
            if name in declared_archive:
                _,raw=verified_bytes(declared_archive[name]);record=declared_archive[name]
            else:
                raw=path.read_bytes();record=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
            package.writestr(name,raw);members.append(dict(archive_path=name,source=record))
        package.writestr('REPRODUCTION.txt','Notebook156 actual four once-only geometry proof-search trials. Activated complete raw closures, reviewed source/metadata gates and whole saved output capsules, including UNKNOWN, are preserved. Mathematical authority is the actual timed observer/independent GroundChecker/literal-point checks plus full owned/caller resource closure; independent saved audit is metadata reconciliation, not semantic replay. No RL, learned inventory, full24, native, full-trajectory, superiority, universal palette or plane claim. Official runtime files are hashes only. Original-host paths/output namespaces are immutable: use fresh namespaces and rebind/requalify paths/runtime/source on any reproduction, never rerun an owner into an existing capsule. The conventional adviser constructs witnesses; zero primitive placements is not zero proof-search cost.\n')
    with zipfile.ZipFile(output/'reproduction.zip') as package:
        assert len(package.namelist())==len(members)+1
        for item in members:
            raw=package.read(item['archive_path']);assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
    save(output/'source-archive-manifest.json',dict(schema='ROOT-notebook156-source-archive-manifest-v1',
        members=members,external_runtime_files_not_redistributed=list(external.values()),
        archive=pin(output/'reproduction.zip'),scientific_calls=0,scope='Declared activated task closure and saved capsules only.'))
    index=old_index.read_text();marker='<section class="panel" id="fresh-proofs">'
    assert index.count(marker)==1
    panel=r'''<section class="panel" id="hilbert-i2">
  <p class="eyebrow">NOTEBOOK 156 · FRESH HILBERT INCIDENCE EXPERIMENT</p>
  <h2>Search with Hilbert’s incidence axiom.</h2>
  <p>Four predeclared trials test line uniqueness and incidence transport under the same original formal hypotheses. Complete fresh catalogue audits, current observer controls and full cold resource records are retained. The reader reports every outcome and whether the named I.2 axiom occurs in a discovered proof’s actual dependency ancestry.</p>
  <p><a href="hilbert-i2/reader.html?v=n156#proof-reader">Inspect the actual tiles, colored markings, formula and English translations</a>.</p>
  <p>Implementation, independent review and reusable receptor-family development proceed in parallel. No RL, admitted inventory, full-board or performance advantage is claimed.</p>
</section>
'''
    write(HERE/'index-source-v1.html',index.replace(marker,panel+marker).encode())
    changed=[]
    for path in sorted(output.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(output);destination=PUB/PUBLIC/relative;destination.parent.mkdir(parents=True,exist_ok=True)
        assert not destination.exists();destination.write_bytes(path.read_bytes())
        local=ROOT/PUBLIC/relative
        local.parent.mkdir(parents=True,exist_ok=True);assert not local.exists();local.write_bytes(path.read_bytes())
        changed.append(dict(path=str(PUBLIC/relative),sha256=pin(path)['sha256'],bytes=path.stat().st_size))
    new_index=HERE/'index-source-v1.html';old_index.write_bytes(new_index.read_bytes())
    changed.append(dict(path='docs/research/gcts-rl-renewal/index.html',sha256=pin(new_index)['sha256'],bytes=new_index.stat().st_size))
    save(HERE/'ROOT-notebook156-task-file-manifest-v1.json',dict(schema='ROOT-notebook156-task-file-manifest-v1',
        scientific_calls=0,files=changed,raw_routes=raw_routes,all_raw_routes_equal_original=True,
        archive_project_members=len(members),external_runtime_files=len(external),
        proof_rows=sum(len(p['tiles']) for p in proofs),ROOT_index_untouched=True,viewer_is_renderer_only=True))
    print(json.dumps(dict(task_files=len(changed),proofs=len(proofs),proof_rows=sum(len(p['tiles']) for p in proofs),raw_routes=len(raw_routes),archive_members=len(members),scientific_calls=0)))

if __name__=='__main__':main()
