const data = JSON.parse(document.getElementById("tile-data").textContent);
const choice = document.getElementById("proof-choice");
const line = document.getElementById("proof-line");
const board = document.getElementById("tile-board");
const caption = document.getElementById("tile-caption");
const origin = document.getElementById("tile-origin");
const mapping = document.getElementById("tile-symbols");
const jump = document.getElementById("tile-proof-link");
const previous = document.getElementById("prev-line");
const next = document.getElementById("next-line");
const svgSpace = "http://www.w3.org/2000/svg";
const sides = ["N", "E", "S", "W"];
const triangles = [
  "0,0 36,0 18,18", "36,0 36,36 18,18",
  "36,36 0,36 18,18", "0,36 0,0 18,18",
];
const fmt = new Intl.NumberFormat("en-US");

function svg(tag, attributes, content) {
  const node = document.createElementNS(svgSpace, tag);
  for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, value);
  if (content !== undefined) node.textContent = content;
  return node;
}

function cell(tile, i) {
  const [label, head, ids] = tile;
  const group = svg("g", {
    class: "wang-cell", transform: "translate(" + (36 * (i % 9)) + " " + (36 * Math.floor(i / 9)) + ")",
  });
  group.append(svg("title", {}, ids.map((key, side) => sides[side] + " " + data.edges[key][1]).join(" / ")));
  for (const [j, key] of ids.entries()) {
    group.append(svg("polygon", { points: triangles[j], fill: data.edges[key][0] }));
  }
  group.append(svg("rect", { width: 36, height: 36, fill: "none", stroke: "#536778", "stroke-width": ".7" }));
  if (head) {
    group.append(svg("rect", { class: "head", x: 1, y: 1, width: 34, height: 34,
      fill: "none", stroke: "#24334e", "stroke-width": 2 }));
  }
  group.append(svg("text", { x: 18, y: 21, "text-anchor": "middle" }, label));
  return group;
}

function update() {
  const proof = data.proofs[choice.value];
  const max = proof.lines.length;
  const index = Math.min(max, Math.max(1, Math.trunc(Number(line.value) || 1)));
  line.value = index;
  line.max = max;
  previous.disabled = index === 1;
  next.disabled = index === max;
  const selected = proof.lines[index - 1];
  const [row, column, cells] = data.windows[selected.key];
  board.replaceChildren(...cells.map(cell));
  caption.textContent = "Fragment rows " + fmt.format(row) + "–" + fmt.format(row + 4) +
    ", columns " + fmt.format(column) + "–" + fmt.format(column + 8) + ".";
  const donor = data.donors[selected.key];
  if (selected.mode === "donor") {
    origin.textContent = "Reused from " + donor.title + ", line " + donor.line + ".";
  } else if (selected.mode === "local") {
    origin.textContent = "Reused from an earlier line in this proof.";
  } else {
    origin.textContent = "Fresh check in this proof.";
  }
  mapping.replaceChildren();
  for (const [code, receiver] of Object.entries(selected.symbols)) {
    const tr = document.createElement("tr");
    for (const value of [code, selected.mode === "donor" ? donor.symbols[code] : "—", receiver]) {
      const td = document.createElement("td");
      const token = document.createElement("code");
      token.textContent = value;
      td.append(token);
      tr.append(td);
    }
    mapping.append(tr);
  }
  jump.href = "#" + choice.value + "-line-" + index;
}

for (const [id, proof] of Object.entries(data.proofs)) {
  const option = document.createElement("option");
  option.value = id;
  option.textContent = proof.title;
  choice.append(option);
}
choice.value = "balanced_unit_23";
line.value = data.proofs[choice.value].lines.length;
choice.addEventListener("change", () => { line.value = 1; update(); });
line.addEventListener("change", update);
previous.addEventListener("click", () => { line.value = Number(line.value) - 1; update(); });
next.addEventListener("click", () => { line.value = Number(line.value) + 1; update(); });
jump.addEventListener("click", () => {
  const row = document.getElementById(jump.hash.slice(1));
  row.closest("details.proof-lines").open = true;
});
for (const button of document.querySelectorAll(".line-view")) {
  button.addEventListener("click", () => {
    choice.value = button.dataset.proof;
    line.value = button.dataset.line;
    update();
    document.getElementById("tiles").scrollIntoView();
  });
}
update();
