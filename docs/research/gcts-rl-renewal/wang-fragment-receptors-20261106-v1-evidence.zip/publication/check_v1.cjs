const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 930 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-fragment-receptors-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, { waitUntil: "commit", timeout: 60000 });
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelector("#depth mjx-container") &&
      document.querySelectorAll("#tile-board .wang-cell").length === 45, null, { timeout: 60000 });
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("#search tbody tr").count(), 16);
    assert.equal(await page.locator("#transfer tbody tr").count(), 14);
    assert.equal(await page.locator(".proof").count(), 14);
    assert.equal(await page.locator("#proof-line").inputValue(), "207");
    const sums = await page.evaluate(() => {
      const data = JSON.parse(document.getElementById("tile-data").textContent);
      return Object.values(data.proofs).reduce((total, proof) => total + proof.lines.length, 0);
    });
    assert.equal(await page.locator(".line-view").count(), sums);
    const click = page.locator("#peano-add-one-line-15 .line-view");
    await click.click();
    assert.equal(await page.locator("#proof-choice").inputValue(), "peano-add-one");
    assert.equal(await page.locator("#proof-line").inputValue(), "15");
    assert(await page.locator("#tile-symbols tr").count() > 0);
    assert.equal(await page.locator("#tile-board .wang-cell").count(), 45);
    if (!process.argv[2]) {
      await page.locator("#tiles").screenshot({ path: path.join(__dirname, "peano-view-v1.png") });
    }
    await page.selectOption("#proof-choice", "fresh_wide_23");
    await page.locator("#proof-line").fill("207");
    await page.locator("#proof-line").dispatchEvent("change");
    assert.match(await page.locator("#tile-origin").innerText(), /Reused from/);
    assert.equal(await page.locator("#tile-proof-link").getAttribute("href"), "#fresh_wide_23-line-207");
    if (!process.argv[2]) {
      await page.locator("#tiles").screenshot({ path: path.join(__dirname, "donor-view-v1.png") });
    }
    await page.locator("#tile-proof-link").click();
    assert(await page.locator("#fresh_wide_23-line-207").isVisible());
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt={status:"CHECKED_WANG_RECEPTOR_READER",proofs:14,cases:16,selectableProofLines:sums,
      squaresPerView:45,donorMapVerified:true,mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2]?"browser-live-v1.json":"browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode=1; });
