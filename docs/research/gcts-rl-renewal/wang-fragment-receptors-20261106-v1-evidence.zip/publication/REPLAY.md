# Replay the Wang fragment and tactic study

Use Python 3.12 and its standard library. Run from the extracted
archive root, with a fresh data directory.

    python3 -I -S -B source/receptor_origin_v1.py
    python3 -I -S -B source/fragment_receptors_v1.py
    python3 -I -S -B source/depth_ground_audit_v1.py
    python3 -I -S -B source/tactic_policy_v1.py
    python3 -I -S -B source/tactic_policy_audit_v1.py
    python3 -I -S -B source/ground_unit_audit_v1.py tactics
    python3 -I -S -B publication/render_v1.py

The first step checks the inherited source and donor files against
the published archive manifests. The next steps regenerate the
canonical fragments, compare the ground exclusions with literal
enumeration, train and freeze the tactic selector, and directly
execute its selected schedules. The fragment audit verifies the
colored square traces and the typed receiver boundaries and links.

Compare the eight scientific outputs with publication/replay-v1.json.
For the browser check, run node publication/check_v1.cjs with Playwright,
Chromium, and access to the notebook's MathJax script. Set GCTS_CHROME
and GCTS_PLAYWRIGHT for custom installations.
