"""Render exact tiles and proof lines for the checked tactic study."""
from html import escape
from pathlib import Path
import sys
import json

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"publication"))
from proof_views_v1 import clause, color, explanation, formula, frame_window, load_frame, math
from boundary_kernel_v1 import build
import decode_v1 as decoder
from lifted_experiment_v1 import load
from lifted_frames_v1 import EXPECTED, restore

STEM="wang-fragment-receptors-20261106-v1"
TITLES={
    "balanced_unit_11":"Eleven balanced choices",
    "balanced_unit_17":"Seventeen balanced choices",
    "balanced_unit_23":"Twenty-three balanced choices",
    "fresh_wide_17":"Seventeen right-associated choices",
    "fresh_wide_23":"Twenty-three right-associated choices",
    "held_chain_11":"Eleven implications",
    "held_parity_10":"Ten equivalences",
    "held_term_8":"Eight function applications",
    "peano-add-one":"Peano addition of one and one",
    "exists-map":"Existential image under implication",
    "incidence-existence":"Existence of an incident point and line",
    "peano-nonzero-successor":"Peano successor is nonzero",
    "hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
    "tptp-tutorial-family":"TPTP family exercise",
    "tptp-tutorial-capital":"TPTP capital exercise",
    "quantifier-swap-control":"Quantifier-swap control",
    "proof-by-cases":"Proof by cases",
    "quantifier-duality":"Quantifier duality",
    "shadowed-existential":"Shadowed existential",
    "typed-shadowed-witness":"Typed witness with shadowing",
    "wide-choices-5":"Five independent choices",
}
OUTCOMES={"PROVED":"Proved","BOUNDED":"Bounded","UNIT_CLOSED":"Unit closure",
          "TERM_BOUND":"Term cap","INSTANCE_BOUND":"Instance cap",
          "GROUND_WORK_BOUND":"Grounding cap","SATURATED_WITHOUT_REFUTATION":"Saturated"}
LABELS={"lift":"Lifted","shallow":"Depth zero, then lifted","one-step":"Depth one, then lifted",
        "staged":"Depth zero, depth one, then lifted","unit0":"Depth zero","unit1":"Depth one"}


def title(key):
    return TITLES[key]


def cells(values):
    return "".join(f"<td>{v:,}</td>" if type(v) is int else f"<td>{escape(v)}</td>" for v in values)


def policy_view(training):
    terms="".join(f'<li>{escape(k.capitalize())} · {escape(LABELS[v])}</li>'
                  for k,v in training["policy"].items())
    return f'<details><summary>Frozen choices by context</summary><ul>{terms}</ul></details>'


def search_table(rows):
    result=[]
    for row in rows:
        key=row["id"]
        raw=row["raw"]
        proof=row["proof"]
        label=escape(title(key))
        if proof is not None:
            label=f'<a href="#{key}">{label}</a>'
        values=[OUTCOMES[raw[k]["status"]] for k in ("lift","unit0","unit1")]
        values.extend((LABELS[row["selected_schedule"]],
                       LABELS[row["selected"]["final_action"]],OUTCOMES[row["selected"]["status"]],
                       len(proof["lines"]) if proof else "—"))
        result.append(f'<tr><th scope="row">{label}</th>{cells(values)}</tr>')
    return "".join(result)


def reuse_table(audit):
    result=[]
    for row in audit:
        key=row["id"]
        receipt=row["receipt"]
        c=row["counts"]
        values=(receipt["fragment_calls"],c.get("exact_donor_hits",0),c.get("donor_hits",0),
                c.get("local_reuse",0),receipt["fresh_tile_runs"])
        result.append(f'<tr><th scope="row"><a href="#{key}">{escape(title(key))}</a></th>{cells(values)}</tr>')
    return "".join(result)


def donors():
    study=load("data/receptors-v1.json")
    rows={r["id"]:r for r in load("input/search-v1.json")["results"]}
    donors={}
    for key in study["frozen_donor_cases"]:
        r=rows[key]
        b=restore(r["original"],r["definition"]["proof"]["lines"],normal=r["compiled"],project=True)
        names={v:k for k,v in b.symbols.items()}
        for i,call in enumerate(study["cases"][key]["calls"],1):
            donors.setdefault(call["fragment"],dict(title=title(key),line=i,
                symbols={k:names[v] for k,v in call["bindings"].items()}))
    return donors


def proof_html(row,bindings,traces):
    key=row["id"]
    statement=row["original"]
    source=restore(statement,row["proof"]["lines"],normal=row["compiled"],project=True)
    formulas=[]
    view=[]
    for i,(line,record) in enumerate(zip(row["proof"]["lines"],bindings,strict=True),1):
        ref=record["receptor"]
        trace=traces[ref]
        raw=decoder.read(trace["prefix"],trace["word"]+"!",require_empty=False)[-1]["raw"]
        mode="donor" if record["donor"] else "local" if record["reuse"] else "fresh"
        view.append(dict(key=ref,mode=mode,symbols=record["symbols"]))
        formulas.append(f'<tr id="{key}-line-{i}"><th scope="row">{i}</th><td>{explanation(line)}</td>'
                        f'<td>{math(clause(line["clause"]))}</td><td>'
                        f'<button class="line-view" type="button" data-proof="{key}" data-line="{i}">Inspect squares</button>'
                        f'<details><summary>Canonical record</summary><code>{escape(raw)}</code></details></td></tr>')
    assumptions="".join(f"<li>{math(formula(x))}</li>" for x in statement["premises"])
    used="".join(f'<li><code>{escape(r["id"])}</code> {math(clause(r["clause"]))}</li>' for r in source.sources.values())
    open_=" open" if key=="peano-add-one" else ""
    html=f"""<section class="proof" id="{key}">
<h2>{escape(title(key))}</h2>
<p class="goal">Goal {math(formula(statement["goal"]))}</p>
<details><summary>Original hypotheses</summary><ul>{assumptions}</ul></details>
<details><summary>Checked boundary clauses used</summary><ul>{used}</ul></details>
<details class="proof-lines"{open_}><summary>Read all {len(view)} proof lines</summary>
<div class="table"><table><thead><tr><th>Line</th><th>Reading</th><th>Ground clause</th><th>Wang record</th></tr></thead>
<tbody>{"".join(formulas)}</tbody></table></div></details></section>"""
    return html,dict(title=title(key),lines=view)


def atlas(machine,traces,proofs,bank):
    edges={}
    colors=[]
    windows={}
    required={x["key"] for proof in proofs.values() for x in proof["lines"]}
    for key in sorted(required):
        t=traces[key]
        evidence=dict(prefix=t["prefix"],word=t["word"],padding=0,trace=t["fragment"])
        time=t["steps"]-5
        rows,col=frame_window(machine,evidence,time,t["head"])
        contents=[]
        for row in rows:
            for tile in row:
                ids=[]
                for edge in tile:
                    if edge not in edges:
                        edges[edge]=len(colors)
                        colors.append((color(edge),str(edge)))
                    ids.append(edges[edge])
                label=tile[0][1][-1]
                head=tile[0][1][0]=="head"
                contents.append(("H" if head else label if len(label)==1 else "·",head,ids))
        assert len(contents)==45
        windows[key]=(time+1,col,contents)
    return json.dumps(dict(proofs=proofs,windows=windows,edges=colors,
                           donors={k:v for k,v in bank.items() if k in required}),
                      separators=(",",":"),ensure_ascii=False).replace("<",r"\u003c")


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    rows=load("data/tactic-receivers-v1.json")["results"]
    training=load("data/tactic-training-v1.json")
    audit=load("data/tactic-audit-v1.json")["results"]
    checks={x["id"]:x for x in audit}
    traces=load_frame("data/canonical-fragments-v1.json.gz")
    fresh=load_frame("data/tactic-new-fragments-v1.json.gz")
    assert all(traces[k]==fresh[k] for k in traces.keys() & fresh.keys())
    traces.update(fresh)
    sections=[]
    proofs={}
    links=[]
    for row in rows:
        if row["proof"] is None:
            continue
        key=row["id"]
        html,view=proof_html(row,checks[key]["bindings"],traces)
        sections.append(html)
        proofs[key]=view
        links.append(f'<a href="#{key}">{escape(title(key))}</a>')
    replacements=dict(STEM=STEM,SEARCH=search_table(rows),POLICY=policy_view(training),REUSE=reuse_table(audit),
        PROOFS="".join(sections),LINKS="".join(links),TILEDATA=atlas(machine,traces,proofs,donors()),
        VIEWER=(ROOT/"publication/viewer_v1.js").read_text())
    text=(ROOT/"publication/notebook-v1.html").read_text()
    for k,v in replacements.items():
        text=text.replace(f"%%{k}%%",v)
    assert "%%" not in text
    (ROOT/f"report/{STEM}.html").write_text(text)
    print(len(proofs),"checked proofs with an exact square view for every line.")


if __name__=="__main__":
    main()
