What helps search find a Wang proof?

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/rl_study_v1.py
  python3 -I -S -B source/rl_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats training, calibration and held-out evaluation and
checks every returned equality path. The second replays the normalizer and
fixed-palette Wang proofs, including the bindings from wire names to terms.
Either accepts --build to regenerate its checked data. The last command
regenerates the self-contained proof reader. MathJax typesets its formulas.
The manifest gives SHA-256 for each included input and result.
