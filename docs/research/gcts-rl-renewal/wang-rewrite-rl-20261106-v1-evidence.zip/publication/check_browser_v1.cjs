const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-rewrite-rl-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#triple-factor-grid-01 mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison #counts meter").count(), 8);
      assert.equal(await page.locator("#comparison #counts tbody tr").count(), 4);
      assert.equal(await page.locator('#counts meter[aria-label="Random queues"]').getAttribute("value"), "23");
      await page.locator("#budget").selectOption("240");
      assert.equal(await page.locator('#counts meter[aria-label="Random queues"]').getAttribute("value"), "28");
      assert.equal(await page.locator("#wang use").count(), 45);
      assert.ok(await page.locator("#triple-factor-grid-01 .steps .left-phase").count() > 0);
      assert.ok(await page.locator("#triple-factor-grid-01 .steps .right-phase").count() > 0);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      await page.locator("#comparison").screenshot({ path: "publication/comparison-" + width + ".png" });
      await page.locator("#wang").screenshot({ path: "publication/wang-" + width + ".png" });
      console.log("Verified", width, "px, interactive budget, typeset certificate and Wang window.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
