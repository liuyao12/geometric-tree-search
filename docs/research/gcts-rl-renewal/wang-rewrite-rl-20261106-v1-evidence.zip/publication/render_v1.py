"""Render the held-out scheduling study and a line-by-line cluster certificate."""
from collections import defaultdict
import gzip
from html import escape
import json
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "source", "wang/source")]
from boundary_kernel_v1 import build
from proof_views_v1 import frame_window, math, tile_svg
from rl_search_v1 import CAPS
from rl_study_v1 import BASELINES, score


NAME = "wang-rewrite-rl-20261106-v1"
TITLE = "What helps search find a Wang proof?"
LABELS = {"breadth": "Breadth", "balanced": "Balanced", "directed": "Directed",
          "cycle": "Rotating queues", "uniform": "Random queues"}
FAMILIES = {"binomial-grid": "Two binomials", "triple-factor-grid": "Three factors with two sums",
            "square-coupling": "Square expansions", "refactor-both-sides": "Refactor both sides"}


def label(name):
    return LABELS.get(name, f"Learned · seed {name.split('-')[-1]}")


def load(name, compressed=False):
    raw = (ROOT / name).read_bytes()
    return json.loads(gzip.decompress(raw) if compressed else raw)


def term(t, vars_, precedence=0):
    if isinstance(t, str):
        return t[1:]
    head, *args = t
    if head.startswith("parameter"):
        return vars_[int(head[9:])][1:]
    if head == "zero":
        return "0"
    if head == "S":
        return "S(" + term(args[0], vars_) + ")"
    op, rank = {"plus": ("+", 1), "times": (r"\times ", 2)}[head]
    result = term(args[0], vars_, rank) + op + term(args[1], vars_, rank+1)
    return "(" + result + ")" if precedence > rank else result


def equation(a, b, variables):
    return math(term(a, variables) + "=" + term(b, variables))


def family_table(groups, modes, cap):
    headers = "".join(f'<th scope="col">{label(mode)}</th>' for mode in modes)
    rows = []
    for family, members in groups.items():
        cells = "".join(f'<td>{score(members, mode, cap)["proved"]} of {len(members)}</td>' for mode in modes)
        rows.append(f'<tr><th scope="row">{FAMILIES[family]}</th>{cells}</tr>')
    return (f'<div class="table" role="region" tabindex="0" aria-label="Proofs found by family"><table>'
            f'<thead><tr><th scope="col">Held-out family</th>{headers}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>')


def chart(rows, modes, selected, cap):
    bars = []
    for mode in modes:
        summary = score(rows, mode, cap)
        count = summary["proved"]
        css = "learned" if mode.startswith("learned-") else "base"
        name = label(mode) + (" (selected)" if mode == selected else "")
        bars.append(f'<div class="bar"><span>{name}</span><meter class="{css}" min="0" max="{len(rows)}" '
                    f'value="{count}" aria-label="{name}"></meter><strong>{count}</strong></div>')
    return "".join(bars)


def proof(sample, certificate, variant, open_=False):
    rows = certificate["normalizer"]
    steps = certificate["replay"]["lines"]
    k = rows["half_lengths"][0]
    labels = {"addition-associates": "Regroup the sum", "addition-commutes": "Swap two summands",
              "multiplication-associates": "Regroup the product", "multiplication-commutes": "Swap two factors",
              "right-distributivity": "Distribute over the left sum",
              "left-distributivity": "Distribute over the right sum"}
    details = []
    bundle = certificate["replay"]
    assert len(steps) == len(bundle["segments"])-1
    for i, (line, ids) in enumerate(zip(steps, bundle["segments"][:-1], strict=True), 1):
        place = "." if not line["path"] else " within a larger expression."
        direction = " in reverse" if line["side"] else ""
        phase = "left-phase" if i <= k else "right-phase"
        details.append(f'<li class="{phase}"><div class="mathline">'
                       f'{equation(line["before"], line["after"], sample["variables"])}</div>'
                       f'{labels[line["rule"]]}{direction}{place} '
                       f'<span class="quiet">Wang records {ids[0]+1}–{ids[-1]+1}</span></li>')
    name = sample["name"]
    imports = ", ".join(escape(x.replace("-", " ")) for x in bundle["imports"])
    open_flag = " open" if open_ else ""
    target = equation(sample["left"], sample["right"], sample["variables"])
    return (f'<details class="proof" id="{name}"{open_flag}><summary>{variant}</summary><p>{target}</p>'
            f'<p>Both sides reach {math(term(rows["normal_form"], sample["variables"]))}.</p>'
            f'<p>This certificate uses {imports}. Blue lines go from the left expression to the common form. '
            'Green lines reverse the corresponding path from the right expression.</p>'
            f'<ol class="steps">{"".join(details)}</ol></details>')


def window(bank, key):
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    evidence = bank["traces"][key]
    start = evidence["steps"]-5
    trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
    tiles, first = frame_window(machine, trace, start, evidence["head"])
    ids, uses = {}, []
    for y, row in enumerate(tiles):
        for x, t in enumerate(row):
            i = ids.setdefault(t, len(ids))
            uses.append(f'<use href="#wang-t-{i}" x="{36*x}" y="{36*y}"/>')
    defs = "".join(tile_svg(t, f"t-{i}") for t, i in ids.items())
    return (f'<figure><svg role="img" aria-label="Nine columns and five rows of checked Wang squares" '
            f'viewBox="0 0 324 180"><defs>{defs}</defs>{"".join(uses)}</svg>'
            f'<figcaption>Verifier rows {start+1:,} to {start+5:,} and tape columns {first:,} to {first+8:,}. '
            'Point to a tile to see its four exact edge labels.</figcaption></figure>')


def main():
    result = load("data/rl-study-v1.json")
    certs = load("wang/data/rl-proofs-v1.json.gz", True)
    bank = load("wang/data/rl-bank-v1.json.gz", True)
    receipt = load("wang/data/rl-receipt-v1.json")
    learned = result["selected"]["learned"]
    fixed = result["selected"]["fixed"]
    modes = (*BASELINES, *result["training"])
    tests = result["test"]
    groups = defaultdict(list)
    for case in tests:
        groups[case["family"]].append(case)
    summary = []
    for cap in CAPS:
        s = " selected" if cap == CAPS[1] else ""
        summary.append(f'<option value="{cap}"{s}>{cap} expansions</option>')
    templates = "".join(f'<template id="cap-{cap}">{chart(tests, modes, learned, cap)}'
                        f'{family_table(groups, (fixed, "cycle", "uniform", learned), cap)}</template>' for cap in CAPS)
    examples = [
        (groups["triple-factor-grid"][0], "Three factors with two sums"),
        (groups["binomial-grid"][7], "Two binomials with reordered factors"),
        (groups["square-coupling"][0], "Square of a sum"),
        (groups["refactor-both-sides"][0], "Refactor both sides"),
    ]
    readers = "".join(proof(case, certs[case["name"]], title, i == 0) for i, (case, title) in enumerate(examples))
    main_case = examples[0][0]["name"]
    sample_key = certs[main_case]["replay"]["calls"][-1]
    lengths = [len(certs[c["name"]]["replay"]["lines"]) for c in tests]
    selected_80 = score(tests, learned, CAPS[1])
    random_80 = score(tests, "uniform", CAPS[1])
    selected_240 = score(tests, learned, CAPS[2])
    random_240 = score(tests, "uniform", CAPS[2])
    h = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    h = h.replace("</style>", """
#comparison .bar{display:grid;grid-template-columns:minmax(8rem,13rem) minmax(3rem,1fr) 2rem;gap:.4rem;align-items:center}
#comparison meter{display:block;width:100%;height:1.15rem}meter.learned::-webkit-meter-optimum-value{background:#6a4e9a}
meter.base::-webkit-meter-optimum-value{background:#168087}.steps li{padding:.3rem .3rem .5rem;border-bottom:1px solid #cadbe3}
.steps .left-phase{border-left:.28rem solid #7aa7d0}.steps .right-phase{border-left:.28rem solid #49a88f}
.mathline{overflow:auto}.quiet{font-size:.85rem;color:#3d6171}.wang figure{max-width:33rem}
#replay code{overflow-wrap:anywhere}
</style>""")
    body = f"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>{TITLE}</h1>
<p>Changing the order of local rewrites gave mixed results. A second experiment grouped
checked distributivity and rearrangement lemmas into a move that connected the two
expressions through a common form. It proved all 40 held-out equalities.</p>
<nav><a href="#comparison">Compare policies</a><a href="#method">Methods</a><a href="#cluster">Read certificates</a>
<a href="#wang">Wang squares</a><a href="#replay">Replay</a></nav></header>
<section id="comparison"><h2>Learned versus fixed move ordering</h2>
<p>At {CAPS[1]} expansions, the selected learned policy proved {selected_80["proved"]} of 40 and random
queue selection proved {random_80["proved"]}. At {CAPS[2]}, they proved {selected_240["proved"]} and
{random_240["proved"]}, respectively. Every local scheduler missed the ten equations with three factors and two sums.</p>
<label for="budget">Search budget</label> <select id="budget">{"".join(summary)}</select>
<p class="quiet">The bars count equations proved. The table shows the split by family.</p>
<div id="counts"></div>{templates}</section>
<section id="method"><h2>What the controller learned</h2>
<p>All schedulers used the same bidirectional term graph, exact rewrite generator and inventory of 11 earlier theorems.
A search step expanded a term nominated by a breadth, balanced or target-directed queue.
Intermediate terms were capped at eight nodes beyond the larger endpoint.
The controller observed elapsed work, the endpoint shapes, best progress toward either endpoint and
the number of distinct available nominations. A successful connection earned 15, a continued search
cost one and a training timeout cost 16. A temporal-difference SARSA update learned which queue to select.
<a href="https://www.incompleteideas.net/book/bookdraft2018mar21.pdf">Sutton and Barto, Chapter 6</a></p>
<p>The three models trained on 36 equations from four families for 12 rounds each.
The strongest learned seed and the strongest fixed queue were chosen on 16 equations from two calibration families.
All settings were frozen for 40 equations in four other families.
The split excludes identical formula pairs under variable renaming or reversal. Formula structures within each family
are related. This is a small transfer study in one arithmetic signature.</p>
<p>The inventory stops at multiplication associativity. It withholds the binomial product and the square-of-a-sum theorem.
Every returned proof path was checked against the exact initial and final terms.
Four polynomially unequal controls yielded zero checked proofs.</p></section>
<section id="cluster"><h2>Compose a move across both boundaries</h2>
<p>The local search failure motivated a separate follow-up. First distribute each product over its sums.
Then associate and sort factors within a product and summands within a sum.
The common expression is a boundary shared by the two proof clusters.
Each side produces a trace of exact rewrites, and concatenating one trace with the other in reverse proves the equation.</p>
<div class="flows"><div><strong>40 of 40</strong>Held-out equalities checked</div>
<div><strong>10 of 10</strong>Previously unsolved three-factor cases</div>
<div><strong>{min(lengths)}–{max(lengths)}</strong>Primitive rewrites per certificate, median {median(lengths):g}</div></div>
<p>The larger move is a hand-designed tactic for positive sums and products. It uses only checked lemmas and
has a different work unit from the queue expansion experiment. The four unequal controls produced different normal forms.</p>
{readers}</section>
<section id="wang" class="wang"><h2>The square tiles in the certificate</h2>
<p>The fixed palette checked {receipt["records"]:,} logical records with {receipt["unique_fragments"]}
distinct compressed inputs. A binding check reconnects each compact name to the exact term or clause.
The window below comes from the final record in the first three-factor proof. Tile orientation is fixed.
Color encodes exact edge labels and darker edges carry verifier-head state.</p>
{window(bank, sample_key)}
</section>
<section id="replay"><h2>Evidence</h2>
<p>The archive contains all 40 normalized proof traces and three representative scheduler certificates.
<a href="{NAME}-evidence.zip">Download code, search traces and Wang certificates</a></p>
<p>Split digest <code>{result["dataset_sha256"]}</code></p></section></main>
<script>
const input = document.getElementById("budget");
function update() {{
  document.getElementById("counts").replaceChildren(document.getElementById("cap-" + input.value).content.cloneNode(true));
}}
input.addEventListener("change", update);
update();
</script></body></html>
"""
    (ROOT / "report" / (NAME+".html")).write_text(h+body)


if __name__ == "__main__":
    main()
