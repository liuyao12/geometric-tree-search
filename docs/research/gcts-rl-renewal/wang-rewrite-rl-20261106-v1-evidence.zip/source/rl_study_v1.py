"""Train only on donor families, choose on calibration and replay every found path."""
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mul_cases_v1 import AXIOMS, CASES
from mul_study_v1 import DATA, checked_case, frozen
from rl_cases_v1 import controls, dataset
from rl_search_v1 import CAPS, QUEUES, SEEDS, TRAIN_CAP, ROUNDS, evaluate, train


BASELINES = (*QUEUES, "cycle", "uniform")


def inventory():
    data = frozen(json.loads((DATA / "arithmetic-v1.json").read_text()))
    available = []
    for eq in CASES:
        if eq.name == "binomial-product":
            break
        row = data[eq.name]["inventory"]
        used, _ = checked_case(eq, row["proof"], available)
        assert tuple(used) == row["imports"]
        available.append(eq)
    return tuple(available)


def score(runs, label, cap):
    rows = [row["runs"][label] for row in runs]
    found = sum(row["path"] is not None and row["expanded"] <= cap for row in rows)
    spent = sum(min(row["expanded"], cap) for row in rows)
    return dict(proved=found, spent=spent, total=len(rows))


def rank(rows, label):
    a, b, c = (score(rows, label, cap) for cap in CAPS)
    return b["proved"], a["proved"], c["proved"], -b["spent"], -c["spent"], -a["spent"]


def eval_rows(problems, earlier, models, split):
    rows = []
    for partition, family, eq in problems:
        assert split == partition
        row = dict(name=eq.name, family=family, variables=eq.variables, left=eq.left, right=eq.right, runs={})
        for label in (*BASELINES, *models):
            mode = "learned" if label in models else label
            result = evaluate(eq, (*AXIOMS, *earlier), mode, model=models.get(label))
            path = result["path"]
            if path is not None:
                assert partition != "control"
                obligation = dict(induction=None, phases=[dict(phase="direct", status="PROVED", path=path)])
                used, audited = checked_case(eq, obligation, earlier)
                result.update(imports=used, lines=audited["direct"]["lines"])
            row["runs"][label] = result
        rows.append(row)
    return rows


def study():
    groups = defaultdict(list)
    all_rows = dataset()
    for split, family, eq in all_rows:
        groups[split].append((split, family, eq))
    prior = inventory()
    rules = (*AXIOMS, *prior)
    models, training = {}, {}
    for seed in SEEDS:
        label = f"learned-{seed}"
        model, curves = train([eq for _, _, eq in groups["train"]], rules, seed)
        training[label] = dict(curves=curves, weights=model.weights)
        models[label] = model
        print(label, curves[0], curves[-1], flush=True)
    calibration = eval_rows(groups["calibrate"], prior, models, "calibrate")
    learned = max(models, key=lambda label: rank(calibration, label))
    fixed = max(QUEUES, key=lambda label: rank(calibration, label))
    print("Selected on calibration", learned, fixed, flush=True)
    test = eval_rows(groups["test"], prior, models, "test")
    negatives = eval_rows(controls(), prior, models, "control")
    canonical = json.dumps([(split, family, vars(eq)) for split, family, eq in all_rows],
                           sort_keys=True, separators=(",", ":")).encode()
    return dict(training=training, limits=dict(evaluation=CAPS, training=TRAIN_CAP, rounds=ROUNDS),
                dataset_sha256=sha256(canonical).hexdigest(), inventory=[r.name for r in prior],
                calibration=calibration, test=test, controls=negatives,
                selected=dict(learned=learned, fixed=fixed))


def main():
    if not __debug__:
        raise RuntimeError("Proof audit requires assertions")
    result = study()
    text = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    target = DATA / "rl-study-v1.json"
    if "--build" in sys.argv:
        target.write_text(text)
    else:
        assert target.read_text() == text
    for label in (*BASELINES, *result["training"]):
        print(label, [score(result["test"], label, c) for c in CAPS])


if __name__ == "__main__":
    main()
