"""Deterministic, alpha-distinct Peano equality families for training and transfer."""
from collections import Counter
from random import Random

from mul_cases_v1 import A, M, S, ZERO, Equality


TRAIN = ("one-sided-distribute", "factor-permutation", "nested-single-sum", "combine-like-terms")
CALIBRATE = ("additive-permutation", "affine-context")
TEST = ("binomial-grid", "triple-factor-grid", "square-coupling", "refactor-both-sides")
COUNTS = {"train": 9, "calibrate": 8, "test": 10}
VARS = tuple("?" + ch for ch in "abcde")


def fold(values, fn, rng, shuffle=False):
    values = list(values)
    if shuffle:
        rng.shuffle(values)
    if len(values) == 1:
        return values[0]
    mid = rng.randrange(1, len(values))
    return fn(fold(values[:mid], fn, rng), fold(values[mid:], fn, rng))


def family(name, rng):
    a, b, c, d, e = rng.sample(VARS, len(VARS))

    def plus(terms, shuffle=True):
        return fold(terms, A, rng, shuffle)

    def times(terms):
        return fold(terms, M, rng, True)

    if name == "one-sided-distribute":
        terms = (b, c, d, e)[:rng.randrange(2, 5)]
        return times((a, plus(terms))), plus(times((a, t)) for t in terms)
    if name == "factor-permutation":
        terms = (a, b, c, d, e)[:rng.randrange(3, 6)]
        return times(terms), times(terms)
    if name == "nested-single-sum":
        return times((a, b, plus((c, d, e)))), plus(times((a, b, t)) for t in (c, d, e))
    if name == "combine-like-terms":
        p = (times((a, b)), times((a, c)), times((b, d)), e)
        q = (times((a, plus((b, c)))), times((b, d)), e)
        return plus(p), plus(q)
    if name == "additive-permutation":
        terms = (a, b, c, d, e)[:rng.randrange(4, 6)]
        return plus(terms), plus(terms)
    if name == "affine-context":
        inside = plus((b, c, d))
        return plus((times((a, inside)), e)), plus((times((a, b)), times((a, c)), times((a, d)), e))
    if name == "binomial-grid":
        return times((plus((a, b)), plus((c, d)))), plus(times((x, y)) for x in (a, b) for y in (c, d))
    if name == "triple-factor-grid":
        return times((a, plus((b, c)), plus((d, e)))), plus(
            times((a, x, y)) for x in (b, c) for y in (d, e))
    if name == "square-coupling":
        return times((plus((a, b)), plus((a, b)))), plus(
            times((x, y)) for x in (a, b) for y in (a, b))
    assert name == "refactor-both-sides"
    return (plus(times((x, plus((b, c)))) for x in (a, d)),
            plus(times((plus((a, d)), y)) for y in (b, c)))


def alpha_pair(left, right):
    def encode(a, b):
        rename = {}
        def rec(t):
            if isinstance(t, str):
                return rename.setdefault(t, len(rename))
            return (t[0], *(rec(v) for v in t[1:]))
        return repr((rec(a), rec(b)))
    return min(encode(left, right), encode(right, left))


def variables(t):
    return {t} if isinstance(t, str) else set().union(*(variables(v) for v in t[1:]))


def polynomial(t):
    """Dataset audit only. The rewrite search has no access to this oracle."""
    if isinstance(t, str):
        return Counter({(t,): 1})
    if t == ZERO:
        return Counter()
    op, *args = t
    if op == "S":
        return Counter({(): 1}) + polynomial(args[0])
    a, b = map(polynomial, args)
    if op == "plus":
        return a+b
    assert op == "times"
    result = Counter()
    for u, m in a.items():
        for v, n in b.items():
            result[tuple(sorted(u+v))] += m*n
    return result


def dataset():
    seen = set()
    rows = []
    for split, names, seed in (("train", TRAIN, 13101), ("calibrate", CALIBRATE, 23831), ("test", TEST, 50323)):
        rng = Random(seed)
        for name in names:
            count = 0
            for _ in range(1000):
                a, b = family(name, rng)
                canonical = alpha_pair(a, b)
                if a == b or canonical in seen:
                    continue
                assert polynomial(a) == polynomial(b)
                count += 1
                seen.add(canonical)
                rows.append((split, name, Equality(f"{name}-{count:02}", tuple(sorted(variables(a)|variables(b))), a, b)))
                if count == COUNTS[split]:
                    break
            assert count == COUNTS[split]
    return rows


def controls():
    rows = []
    for split, name, eq in dataset():
        if split == "test" and eq.name.endswith("-01"):
            right = S(eq.right)
            assert polynomial(eq.left) != polynomial(right)
            rows.append(("control", name, Equality("false-"+eq.name, eq.variables, eq.left, right)))
    return rows
