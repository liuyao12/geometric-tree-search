"""One checked rewrite graph with interchangeable search queues and a SARSA controller."""
from heapq import heappop, heappush
from random import Random

from mul_cases_v1 import obligations, size
from rewrite_search_v1 import Offers, distance


QUEUES = ("breadth", "balanced", "directed")
CAPS = (24, 80, 240)
TRAIN_CAP = 100
ROUNDS = 12
SEEDS = (741, 2053, 8819)
GAMMA = 0.94
ALPHA = 0.09


class Search:
    def __init__(self, eq, rules):
        ((_, (left, right), _),) = obligations(eq, None)
        assert left != right
        self.terms = (left, right)
        self.maximum = max(size(left), size(right)) + 8
        self.offers = Offers(rules, True)
        self.heaps = [[[], []] for _ in QUEUES]
        self.parents = [{left: None}, {right: None}]
        self.popped = [set(), set()]
        self.best = [distance(left, right), distance(right, left)]
        self.serial = 0
        self.expanded = 0
        self.middle = None
        self.push(0, left, 0)
        self.push(1, right, 0)

    def push(self, side, term, depth):
        diff, length = distance(term, self.terms[1-side]), size(term)
        ranks = (depth, depth + .19*diff + .19*length, depth + .60*diff + .05*length)
        self.best[side] = min(diff, self.best[side])
        for pair, rank in zip(self.heaps, ranks, strict=True):
            heappush(pair[side], (rank, self.serial, depth, term))
        self.serial += 1

    def options(self):
        choices = []
        for pair in self.heaps:
            for side, heap in enumerate(pair):
                while heap and heap[0][-1] in self.popped[side]:
                    heappop(heap)
            options = [(heap[0], side) for side, heap in enumerate(pair) if heap]
            if not options:
                return None
            (rank, order, depth, term), side = min(options)
            choices.append((side, term, depth))
        return choices

    def step(self, choice):
        side, term, depth = choice
        assert term not in self.popped[side]
        self.popped[side].add(term)
        self.expanded += 1
        for other, record in self.offers.at(term, self.maximum):
            if other in self.parents[side]:
                continue
            self.parents[side][other] = term, record
            if other in self.parents[1-side]:
                self.middle = other
                return
            self.push(side, other, depth+1)

    def features(self, choices):
        first, second = self.terms
        base = max(1, distance(first, second))
        progress = min(3, 4*min(self.best)//base)
        phase = sum(self.expanded >= cut for cut in (6, 24, 80))
        gap = min(3, abs(size(first)-size(second))//4)
        same_root = first[0] == second[0]
        diversity = len({(side, term) for side, term, _ in choices})
        return ("bias", f"phase{phase}", f"gap{gap}", f"root{int(same_root)}",
                f"progress{progress}", f"diversity{diversity}", f"phase{phase}progress{progress}")

    def proof(self):
        if self.middle is None:
            return None
        a, b = [], []
        term = self.middle
        while self.parents[0][term] is not None:
            term, record = self.parents[0][term]
            a.append(record)
        term = self.middle
        while self.parents[1][term] is not None:
            term, (rule, side, path, bindings) = self.parents[1][term]
            b.append((rule, 1-side, path, bindings))
        return (*reversed(a), *b)


class Learner:
    def __init__(self):
        self.weights = [{} for _ in QUEUES]

    def value(self, action, features):
        return sum(self.weights[action].get(feature, 0.0) for feature in features)

    def action(self, features, rng, epsilon=0):
        if epsilon and rng.random() < epsilon:
            return rng.randrange(len(QUEUES))
        return max(range(len(QUEUES)), key=lambda a: (self.value(a, features), a == 1, -a))

    def update(self, action, features, reward, future):
        error = reward + GAMMA*future - self.value(action, features)
        change = ALPHA*error/len(features)
        row = self.weights[action]
        for feature in features:
            row[feature] = row.get(feature, 0.0) + change


def train(problems, rules, seed):
    rng = Random(seed)
    model = Learner()
    results = []
    order = list(problems)
    for epoch in range(ROUNDS):
        rng.shuffle(order)
        epsilon = .24 - .16*epoch/(ROUNDS-1)
        solved = expansions = 0
        for eq in order:
            search = Search(eq, rules)
            choices = search.options()
            state = search.features(choices)
            action = model.action(state, rng, epsilon)
            while True:
                search.step(choices[action])
                if search.middle is not None:
                    model.update(action, state, 15, 0)
                    solved += 1
                    break
                choices = search.options()
                if choices is None or search.expanded >= TRAIN_CAP:
                    model.update(action, state, -16, 0)
                    break
                successor = search.features(choices)
                next_action = model.action(successor, rng, epsilon)
                model.update(action, state, -1, model.value(next_action, successor))
                state, action = successor, next_action
            expansions += search.expanded
        results.append(dict(epoch=epoch+1, solved=solved, expanded=expansions))
    return model, results


def evaluate(eq, rules, mode, *, model=None, seed=741):
    rng = Random(seed)
    search = Search(eq, rules)
    counts = [0 for _ in QUEUES]
    early = []
    for _ in range(CAPS[-1]):
        choices = search.options()
        if choices is None:
            break
        if mode in QUEUES:
            action = QUEUES.index(mode)
        elif mode == "cycle":
            action = search.expanded % len(QUEUES)
        elif mode == "uniform":
            action = rng.randrange(len(QUEUES))
        else:
            assert mode == "learned" and model is not None
            action = model.action(search.features(choices), rng)
        counts[action] += 1
        if len(early) < 20:
            side, term, depth = choices[action]
            early.append(dict(queue=QUEUES[action], side=side, term=term, depth=depth,
                              available=len({(s, t) for s, t, _ in choices})))
        search.step(choices[action])
        if search.middle is not None:
            break
    path = search.proof()
    return dict(path=path, expanded=search.expanded, queues=counts, early=early,
                matches=search.offers.counts["matches"], offers=search.offers.counts["offers"])
