"""Universal equalities in the Peano signature and their induction obligations."""
from dataclasses import dataclass
from functools import lru_cache


ZERO = ("zero",)
x, y, z, u, v = ("?" + t for t in "xyzuv")


def S(t):
    return "S", t


def A(a, b):
    return "plus", a, b


def M(a, b):
    return "times", a, b


@dataclass(frozen=True)
class Equality:
    name: str
    variables: tuple
    left: tuple
    right: tuple


AXIOMS = (
    Equality("add-zero-right", (x,), A(x, ZERO), x),
    Equality("add-successor-right", (x, y), A(x, S(y)), S(A(x, y))),
    Equality("multiply-zero-right", (x,), M(x, ZERO), ZERO),
    Equality("multiply-successor-right", (x, y), M(x, S(y)), A(M(x, y), x)),
)
CASES = (
    Equality("add-zero-left", (x,), A(ZERO, x), x),
    Equality("add-successor-left", (x, y), A(S(x), y), S(A(x, y))),
    Equality("addition-commutes", (x, y), A(x, y), A(y, x)),
    Equality("addition-associates", (x, y, z), A(A(x, y), z), A(x, A(y, z))),
    Equality("multiply-zero-left", (x,), M(ZERO, x), ZERO),
    Equality("multiply-one-right", (x,), M(x, S(ZERO)), x),
    Equality("multiply-successor-left", (x, y), M(S(x), y), A(M(x, y), y)),
    Equality("multiplication-commutes", (x, y), M(x, y), M(y, x)),
    Equality("left-distributivity", (x, y, z), M(x, A(y, z)), A(M(x, y), M(x, z))),
    Equality("right-distributivity", (x, y, z), M(A(x, y), z), A(M(x, z), M(y, z))),
    Equality("multiplication-associates", (x, y, z), M(M(x, y), z), M(x, M(y, z))),
    Equality("binomial-product", (x, y, u, v), M(A(x, y), A(u, v)),
             A(A(M(x, u), M(x, v)), A(M(y, u), M(y, v)))),
    Equality("square-of-a-sum", (x, y), M(A(x, y), A(x, y)),
             A(A(M(x, x), M(y, y)), A(M(x, y), M(x, y)))),
)


def put(term, bindings):
    return bindings[term] if isinstance(term, str) else (term[0], *(put(t, bindings) for t in term[1:]))


def instantiate(eq, bindings):
    return put(eq.left, bindings), put(eq.right, bindings)


def obligations(eq, variable):
    values = {v: (f"parameter{i}",) for i, v in enumerate(eq.variables)}
    if variable is None:
        return (("direct", instantiate(eq, values), None),)
    assert variable in values
    base = instantiate(eq, {**values, variable: ZERO})
    assumed = instantiate(eq, values)
    step = instantiate(eq, {**values, variable: S(values[variable])})
    return ("base", base, None), ("step", step, Equality("induction-hypothesis", (), *assumed))


@lru_cache(maxsize=30000)
def size(t):
    return 1 if isinstance(t, str) else 1 + sum(map(size, t[1:]))


def induction_order(eq):
    scores = {v: 0 for v in reversed(eq.variables)}

    def scan(t):
        if isinstance(t, str):
            return
        if t[0] in ("times", "plus") and t[2] in scores:
            scores[t[2]] += 2 if t[0] == "times" else 1
        for child in t[1:]:
            scan(child)

    scan(eq.left)
    scan(eq.right)
    return sorted(scores, key=scores.get, reverse=True)
