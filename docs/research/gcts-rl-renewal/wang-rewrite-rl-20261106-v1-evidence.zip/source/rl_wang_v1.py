"""Replay hierarchical normalization paths, and compile them into the fixed Wang palette."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mul_cases_v1 import AXIOMS, Equality
from mul_study_v1 import checked_case
from mul_wang_v1 import (
    BANK, DATA, build_bank, decoder, elaborate, encoded, fingerprint, fragment, match, records, verify_bank,
)
from rl_cluster_v1 import compose
from rl_study_v1 import inventory
from schematic_capsules_v1 import frozen


def encode_rows(result, earlier):
    wires, proofs = {}, {}
    def certify(eq, label, path):
        proof = dict(induction=None, phases=[dict(phase="direct", status="PROVED", path=path)])
        used, checked = checked_case(eq, proof, earlier)
        row = checked["direct"]
        sources, functions, clauses, segments = elaborate(eq, row, (*AXIOMS, *earlier))
        calls = []
        for i, clause in enumerate(clauses):
            names, prefix, word = fragment(clauses, i, sources, functions)
            parsed = decoder.read(prefix, word+"!", require_empty=False)
            match(clauses, i, sources, names, parsed, prefix)
            key = fingerprint(prefix, records(word))
            wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=(eq.name, label, i+1),
                                               uses=0, rule=clause["rule"]))
            assert (prefix, word) == (wire["prefix"], wire["word"])
            wire["uses"] += 1
            calls.append(key)
        return dict(imports=used, lines=row["lines"], sources=sources, clauses=clauses, calls=calls, segments=segments)
    for group in ("test", "controls"):
        for case in result[group]:
            eq = Equality(*(case[k] for k in ("name", "variables", "left", "right")))
            task = compose(eq)
            if task["steps"] is None:
                assert group == "controls"
                proofs[eq.name] = task
                continue
            assert group == "test"
            proofs[eq.name] = dict(normalizer=task, replay=certify(eq, "normalized", task["steps"]))
            if eq.name in ("binomial-grid-08", "square-coupling-01"):
                for label in (result["selected"]["learned"], "uniform"):
                    path = case["runs"][label]["path"]
                    if path is not None:
                        proofs[eq.name][label] = certify(eq, label, path)
    return wires, proofs


def main():
    if not __debug__:
        raise RuntimeError("Wang replay requires assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    args = parser.parse_args()
    result = frozen(json.loads((DATA / "rl-study-v1.json").read_text()))
    wires, proofs = encode_rows(result, inventory())
    bank_path, proofs_path, receipt_path = (BANK / n for n in
        ("rl-bank-v1.json.gz", "rl-proofs-v1.json.gz", "rl-receipt-v1.json"))
    bank = build_bank(wires) if args.build else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(scheduler_examples=sum(len(p)-2 for p in proofs.values() if "replay" in p),
                   cluster_proofs=sum("replay" in p for p in proofs.values()),
                   distinct_controls=sum(p.get("status") == "DIFFERENT-NORMAL-FORMS" for p in proofs.values()),
                   records=sum(w["uses"] for w in wires.values()), **verify_bank(wires, bank))
    for path, body, compress in ((bank_path, bank, True), (proofs_path, proofs, True), (receipt_path, receipt, False)):
        expected = encoded(body) + b"\n"
        if args.build:
            path.write_bytes(gzip.compress(expected, mtime=0) if compress else expected)
        else:
            stored = path.read_bytes()
            assert (gzip.decompress(stored) if compress else stored) == expected
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
