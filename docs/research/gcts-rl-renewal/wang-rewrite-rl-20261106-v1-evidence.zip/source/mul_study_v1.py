"""Run matched rewrite searches and independently check the returned proofs."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from mul_cases_v1 import AXIOMS, CASES, Equality, S, ZERO, induction_order, obligations
from rewrite_search_v1 import find


DATA = ROOT / "data"
CAP = 700


def frozen(value):
    if isinstance(value, list):
        return tuple(map(frozen, value))
    if isinstance(value, dict):
        return {key: frozen(v) for key, v in value.items()}
    return value


def evaluate(term, env):
    if isinstance(term, str):
        return env[term]
    return (term[0], *(evaluate(child, env) for child in term[1:]))


def check_ground(term, arities):
    assert isinstance(term, tuple) and term and term[0] in arities
    assert len(term) == 1 + arities[term[0]]
    for child in term[1:]:
        check_ground(child, arities)


def rewrite_checked(term, path, old, new):
    if not path:
        assert term == old
        return new
    i, *rest = path
    assert type(i) is int and 1 <= i < len(term)
    arguments = list(term)
    arguments[i] = rewrite_checked(arguments[i], rest, old, new)
    return tuple(arguments)


def expected_phases(eq, variable):
    assert variable is None or variable in eq.variables
    values = {v: (f"parameter{i}",) for i, v in enumerate(eq.variables)}

    def pair(env):
        return evaluate(eq.left, env), evaluate(eq.right, env)

    if variable is None:
        return (("direct", pair(values), None),)
    return (("base", pair({**values, variable: ZERO}), None),
            ("step", pair({**values, variable: S(values[variable])}), pair(values)))


def checked_case(eq, proof, library):
    arities = {"zero": 0, "S": 1, "plus": 2, "times": 2}
    arities.update({f"parameter{i}": 0 for i in range(len(eq.variables))})
    phases = expected_phases(eq, proof["induction"])
    assert len(proof["phases"]) == len(phases)
    available = {rule.name: rule for rule in (*AXIOMS, *library)}
    used = set()
    audited = {}
    for (phase, (left, right), ih), row in zip(phases, proof["phases"], strict=True):
        assert row["phase"] == phase and row["status"] == "PROVED"
        rules = dict(available)
        if ih is not None:
            rules["induction-hypothesis"] = Equality("induction-hypothesis", (), *ih)
        current, lines = left, []
        for name, side, path, binding in row["path"]:
            schema = rules[name]
            assert type(side) is int and side in (0, 1)
            env = dict(binding)
            assert len(env) == len(binding) and set(env) == set(schema.variables)
            for term in env.values():
                check_ground(term, arities)
            first, second = (evaluate(t, env) for t in (schema.left, schema.right))
            old, new = (second, first) if side else (first, second)
            after = rewrite_checked(current, path, old, new)
            lines.append(dict(rule=name, side=side, path=path, bindings=env,
                              before=current, after=after, instance=(first, second)))
            current = after
            if name in {rule.name for rule in library}:
                used.add(name)
        assert current == right
        audited[phase] = dict(left=left, right=right, ih=ih, lines=lines)
    return sorted(used), audited


def prove(eq, inventory, indexed, priority):
    attempts = []
    for variable in (None, *induction_order(eq)):
        phases = []
        for phase, (left, right), ih in obligations(eq, variable):
            rules = (*AXIOMS, *inventory, *((ih,) if ih else ()))
            row = find(left, right, rules, cap=CAP, indexed=indexed, priority=priority)
            phases.append(dict(phase=phase, **row))
            if row["path"] is None:
                break
        attempts.append(dict(induction=variable, phases=phases))
        if phases[-1]["status"] == "PROVED":
            proof = attempts[-1]
            imports, audited = checked_case(eq, proof, inventory)
            return dict(proof=proof, attempts=attempts, imports=imports, audited=audited)
    return dict(proof=None, attempts=attempts)


def workload(row, key):
    return sum(p["counts"].get(key, 0) for attempt in row["attempts"] for p in attempt["phases"])


def study():
    inventory = []
    rows = {}
    for eq in CASES:
        modes = dict(axioms=prove(eq, (), True, "balanced"),
                     inventory=prove(eq, tuple(inventory), True, "balanced"),
                     unindexed=prove(eq, tuple(inventory), False, "balanced"))
        a, b = modes["inventory"], modes["unindexed"]
        assert a["proof"] is not None and b["proof"] is not None
        assert a["audited"] == b["audited"]
        assert workload(a, "expanded") == workload(b, "expanded")
        rows[eq.name] = modes
        inventory.append(eq)
    target = CASES[-1]
    proof = rows[target.name]["inventory"]["proof"]
    first, *rest = proof["phases"][0]["path"]
    bad = dict(proof, phases=[dict(proof["phases"][0], path=((first[0], first[1], (0,), first[3]), *rest))])
    for candidate, permitted in ((bad, CASES[:-1]), (proof, ())):
        try:
            checked_case(target, candidate, permitted)
        except (AssertionError, KeyError):
            continue
        raise AssertionError("Accepted a corrupt rewrite or a withheld lemma")
    return rows


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    result = study()
    body = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    out = DATA / "arithmetic-v1.json"
    if "--build" in sys.argv:
        out.write_text(body)
    else:
        assert out.read_text() == body
    for mode in ("axioms", "inventory", "unindexed"):
        runs = [row[mode] for row in result.values()]
        print(mode, sum(r["proof"] is not None for r in runs),
              *(workload_total(runs, field) for field in ("expanded", "matches")))


def workload_total(rows, field):
    return sum(workload(r, field) for r in rows)


if __name__ == "__main__":
    main()
