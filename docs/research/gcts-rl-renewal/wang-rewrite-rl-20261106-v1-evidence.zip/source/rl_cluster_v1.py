"""Compose checked equality lemmas into a distributive-normalization move."""
from mul_cases_v1 import CASES, obligations
from rewrite_search_v1 import at, match, put, replace


LAWS = {"plus": ("addition-associates", "addition-commutes"),
        "times": ("multiplication-associates", "multiplication-commutes")}
RULES = {e.name: e for e in CASES}


class MoveLimit(Exception):
    pass


class Normalizer:
    def __init__(self, start, limit):
        self.term = start
        self.limit = limit
        self.steps = []

    def rewrite(self, path, name, side=0):
        if len(self.steps) >= self.limit:
            raise MoveLimit
        schema = RULES[name]
        left, right = (schema.right, schema.left) if side else (schema.left, schema.right)
        env = {}
        assert match(left, at(self.term, path), env)
        self.term = replace(self.term, path, put(right, env))
        self.steps.append((name, side, path, tuple(sorted(env.items()))))

    def sort_chain(self, path, op):
        assoc, commute = LAWS[op]
        cursor = path
        while at(self.term, cursor)[0] == op:
            while at(self.term, cursor+(1,))[0] == op:
                self.rewrite(cursor, assoc)
            cursor += (2,)
        while True:
            cursor = path
            changed = False
            while at(self.term, cursor)[0] == op:
                _, left, rest = at(self.term, cursor)
                has_tail = rest[0] == op
                right = rest[1] if has_tail else rest
                if left > right:
                    if has_tail:
                        self.rewrite(cursor, assoc, 1)
                        self.rewrite(cursor+(1,), commute)
                        self.rewrite(cursor, assoc)
                    else:
                        self.rewrite(cursor, commute)
                    changed = True
                cursor += (2,)
            if not changed:
                return

    def normalize(self, path=()):
        op = at(self.term, path)[0]
        if op not in LAWS:
            return
        self.normalize(path+(1,))
        self.normalize(path+(2,))
        _, a, b = at(self.term, path)
        if op == "times" and (a[0] == "plus" or b[0] == "plus"):
            name = "right-distributivity" if a[0] == "plus" else "left-distributivity"
            self.rewrite(path, name)
            self.normalize(path)
        else:
            self.sort_chain(path, op)


def compose(eq, limit=512):
    """Normalize both boundaries, then connect equal forms with exact rewrites."""
    ((_, (left, right), _),) = obligations(eq, None)
    a, b = Normalizer(left, limit), Normalizer(right, limit)
    try:
        a.normalize()
        b.normalize()
    except MoveLimit:
        return dict(status="BOUNDED", steps=None)
    if a.term != b.term:
        return dict(status="DIFFERENT-NORMAL-FORMS", steps=None)
    inverse = ((name, 1-side, path, env) for name, side, path, env in reversed(b.steps))
    return dict(status="PROVED", steps=(*a.steps, *inverse), normal_form=a.term,
                half_lengths=(len(a.steps), len(b.steps)))
