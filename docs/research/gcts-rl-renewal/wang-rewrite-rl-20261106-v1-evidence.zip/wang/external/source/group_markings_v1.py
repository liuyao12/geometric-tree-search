"""Measure pre-unification markings on frozen TPTP group problems."""
import argparse
from collections import Counter
from hashlib import sha256
from itertools import islice
import json
from pathlib import Path
import sys
from time import perf_counter

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(HERE / "source"), str(ROOT / "source")]
from equality_experiment_v1 import compact
from front_v1 import clausify
from lifted_equality_ground_v1 import elaborate
from lifted_ground_v1 import compile_proof
from lifted_marks_v1 import applies, at, clashes, discover
from lifted_prover_v1 import Bound, subst, unifier
from logical_projection_v1 import reject, verify
from shared_wang_v1 import attach, verify_certificate
from subsumption_v1 import Subsuming
from tptp_cnf_v1 import CNF
from tptp_pilot_v1 import write
from tptp_transport_v1 import transport

OFFERS, NODES, RAW_REWRITES, BANK_SIZE = 120_000, 30_000, 600_000, 12
ARMS = ("support", "subsumption", "rigid", "learned", "rigid-learned")


def require_failure(a, b, functions):
    types = {}

    def scope(term, side):
        if isinstance(term, str):
            name = side + term
            types[name] = "U"
            return name
        return term[0], *(scope(t, side) for t in term[1:])

    lhs = scope(a, "l")
    rhs = scope(b, "r")
    assert unifier(lhs, rhs, types, functions, Counter()) is None


class RewriteStudy(Subsuming):
    def __init__(self, source, normal, arm, marks=()):
        super().__init__(source, normal=normal, goal_bias=24, offer_cap=OFFERS,
                         node_cap=NODES, subsumption=arm == "subsumption")
        self.train = arm == "train"
        self.rigid_gate = arm in ("rigid", "rigid-learned")
        self.marks_to_try = tuple(m for m in marks if arm != "rigid-learned" or m[0] == "alias")
        self.frequency = Counter()
        self.hit_frequency = Counter()
        self.examples = {}

    def rewrite(self, equation, target):
        left, i, side = equation
        right, j, path = target
        if not self.supported(left, right):
            self.counts["support_skips"] += 1
            return None
        self.counts["raw_rewrite_pairs"] += 1
        if self.counts["raw_rewrite_pairs"] > RAW_REWRITES:
            raise Bound
        if self.train or self.rigid_gate or self.marks_to_try:
            a = self.nodes[left]["clause"][i][1][side + 1]
            b = at(self.nodes[right]["clause"][j][1], path)
            if self.rigid_gate:
                self.counts["rigid_tests"] += 1
                clash = next(clashes(a, b), None)
                if clash is not None:
                    self.record_skip(("rigid", clash), a, b, "rigid_skips")
                    return None
            for mark in self.marks_to_try:
                self.counts["learned_tests"] += 1
                if applies(mark, a, b):
                    self.record_skip(mark, a, b, "learned_skips")
                    return None
        before = self.counts["rewrite_unification_failures"]
        result = super().rewrite(equation, target)
        if self.train and self.counts["rewrite_unification_failures"] > before:
            for mark in discover(a, b):
                self.frequency[mark] += 1
                self.examples.setdefault(mark, (a, b))
        return result

    def record_skip(self, mark, a, b, counter):
        self.counts[counter] += 1
        self.hit_frequency[mark] += 1
        self.examples.setdefault(mark, (a, b))


def read(name):
    return json.loads((HERE / "data" / name).read_text())


def load_case(name):
    parser = CNF(HERE / "input")
    return parser, parser.source(name + ".p")


def run(name, arm, marks=()):
    parser, source = load_case(name)
    normal, _ = clausify(source, 1024)
    prover = RewriteStudy(source, normal, arm, marks)
    start = perf_counter()
    status, root = prover.run()
    seconds = perf_counter() - start
    for mark, (a, b) in prover.examples.items():
        assert applies(mark, a, b)
        require_failure(a, b, prover.functions)
    row = dict(id=name, arm=arm, status=status, counts=dict(prover.counts),
               node_count=len(prover.nodes), seconds=round(seconds, 6),
               examples=[dict(mark=m, terms=prover.examples[m], hits=prover.hit_frequency[m])
                         for m in sorted(prover.examples, key=repr)])
    if prover.deletions:
        sample = next((d for d in prover.deletions if d["bindings"]), prover.deletions[0])
        donor = prover.nodes[sample["donor"]]
        row["subsumption_example"] = {**sample, "pattern": donor["clause"],
            "instance": [(p, subst(a, sample["bindings"])) for p, a in donor["clause"]]}
    if root is not None and arm != "train":
        direct, _, _ = compile_proof(prover, prover.proof(root), elaborate)
        normal, translation, proof = transport(source, direct.lines)
        bundle = compact(source, normal, translation, proof)
        row.update(direct_lines=len(direct.lines), receipt=verify(source, bundle))
        reject({**source, "goal": ["not", source["goal"]]}, bundle)
        label = f"{name}-{arm}"
        write(f"{label}-direct-v1.json", dict(lines=direct.lines, clauses=parser.rows, source=source))
        write(f"{label}-logical-v1.json", bundle)
        if (name, arm) == ("GRP008-1", "subsumption"):
            full = attach(source, "fol", normal, translation, proof)
            row["full_wang"] = verify_certificate(source, full)
            write(f"{label}-wang-v1.json", full)
    print(name, arm, status, prover.counts["offers"], prover.counts["raw_rewrite_pairs"],
          prover.counts["learned_skips"], prover.counts["forward_subsumed"], round(seconds, 3), flush=True)
    return row, prover.frequency


def learn(names):
    frequencies, donors = Counter(), []
    for name in names:
        row, frequency = run(name, "train")
        frequencies.update(frequency)
        donors.append(dict(id=name, status=row["status"], counts=row["counts"],
                           observations=[{**example, "count": frequency[example["mark"]]}
                                         for example in row["examples"]]))
    order = sorted(frequencies, key=lambda m: (-frequencies[m], repr(m)))
    marks = tuple(islice(order, BANK_SIZE))
    write("group-mark-bank-v1.json", dict(marks=marks, donors=donors,
          ranking="descending failed-pair frequency; stable repr tie-break"))
    return marks


def native(cohort):
    # The original training partition produced zero native equality proposals.
    # The old pilot is development data and does contain native rewrites.
    # No held-out case is eligible to donate.
    donors = cohort["training"] + cohort["development"]
    marks = learn(donors)
    assert marks
    results = []
    for name in cohort["development"] + cohort["held_out"]:
        for arm in ARMS:
            active = marks if arm in ("learned", "rigid-learned") else ()
            row, _ = run(name, arm, active)
            results.append(row)
            write("group-mark-results-v1.json", results)


def conventional(names, vendor):
    sys.path.insert(0, str(vendor))
    from z3_control_v1 import Language, z3
    assert z3.get_version() == (4, 15, 4, 0)
    results, inputs = [], {}
    for name in names:
        parser, source = load_case(name)
        language = Language(source)
        solver = z3.Solver()
        solver.set(timeout=10_000, random_seed=1)
        solver.add(*(language.formula(row["formula"]) for row in parser.rows))
        inputs[name] = solver.sexpr()
        status = str(solver.check())
        assert status in ("unsat", "unknown")
        results.append(dict(id=name, status=status,
                            reason=solver.reason_unknown() if status == "unknown" else None))
        print("Z3", name, status, flush=True)
    write("group-z3-v1.json", results)
    write("group-z3-inputs-v1.json", inputs)


def check_retained():
    count = full_count = 0
    for row in read("group-mark-results-v1.json"):
        if row["status"] != "PROVED":
            continue
        _, source = load_case(row["id"])
        label = f"{row['id']}-{row['arm']}"
        bundle = read(f"{label}-logical-v1.json")
        assert verify(source, bundle) == row["receipt"]
        reject({**source, "goal": ["not", source["goal"]]}, bundle)
        count += 1
        if "full_wang" in row:
            full = read(f"{label}-wang-v1.json")
            assert verify_certificate(source, full) == row["full_wang"]
            full_count += 1
    print("Independently checked", count, "logical certificates and", full_count, "full Wang witness.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--z3", type=Path)
    mode.add_argument("--check", action="store_true")
    args = parser.parse_args()
    cohort = read("cohort-v1.json")
    for filename, entry in read("sources-v1.json").items():
        assert sha256((HERE / "input" / filename).read_bytes()).hexdigest() == entry["sha256"], filename
    if args.check:
        check_retained()
    elif args.z3:
        conventional(cohort["held_out"], args.z3)
    else:
        native(cohort)


if __name__ == "__main__":
    main()
