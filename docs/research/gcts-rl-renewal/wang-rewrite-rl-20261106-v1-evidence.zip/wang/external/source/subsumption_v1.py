"""Forward clause subsumption with an address-indexed exact matcher."""
from collections import defaultdict

import herbrand_v1 as fol
from lifted_equality_v1 import positions
from lifted_prover_v1 import subst
from tptp_transport_v1 import GoalSupport


def match(pattern, target, binding):
    if isinstance(pattern, str):
        return binding.setdefault(pattern, target) == target
    if isinstance(target, str) or pattern[0] != target[0] or len(pattern) != len(target):
        return False
    return all(match(a, b, binding) for a, b in zip(pattern[1:], target[1:], strict=True))


def signature(literal):
    sign, atom = literal
    return sign, atom[0]


def keys(literal):
    tag = signature(literal)
    return tuple((tag, path, term[0], len(term)) for path, term in positions(literal[1]))


def subsumes(source, target):
    destinations = defaultdict(list)
    for literal in target:
        destinations[signature(literal)].append(literal[1])
    queue = []
    for literal in source:
        possible = []
        for other in destinations[signature(literal)]:
            mapping = {}
            if match(literal[1], other, mapping):
                possible.append(mapping)
        if not possible:
            return None
        queue.append(possible)
    queue.sort(key=len)

    def join(i, binding):
        if i == len(queue):
            return binding
        for mapping in queue[i]:
            if all(binding.get(key, value) == value for key, value in mapping.items()):
                result = join(i+1, binding | mapping)
                if result is not None:
                    return result
        return None

    return join(0, {})


def check_witness(pattern, candidate, mapping, pattern_types, candidate_types, functions):
    assert set(mapping) == set(pattern_types)
    assert all(fol.inspect_term(t, candidate_types, functions) == pattern_types[v] for v,t in mapping.items())
    assert {(p, subst(a, mapping)) for p,a in pattern} <= set(candidate)


class Subsuming(GoalSupport):
    def __init__(self, *args, subsumption=True, match_cap=48, donor_width=2, **kwargs):
        super().__init__(*args, **kwargs)
        self.subsumption = subsumption
        self.match_cap = match_cap
        self.donor_width = donor_width
        self.by_anchor = defaultdict(list)
        self.tags = {}
        self.deletions = []

    def remember(self, num, node):
        if not self.subsumption or len(node["clause"]) > self.donor_width:
            return
        row = node["clause"]
        anchors = [key for literal in row for key in keys(literal)]
        anchor = min(anchors, key=lambda key: (len(self.by_anchor.get(key, ())), -len(key[1]), repr(key)))
        self.by_anchor[anchor].append(num)
        self.tags[num] = frozenset(map(signature, row))

    def redundant(self, clause, types, kind, schema, parents):
        if not self.subsumption or not clause or kind == "source":
            return False
        support = any(self.nodes[i]["goal_support"] for i in parents)
        tags = frozenset(map(signature, clause))
        ids = {i for literal in clause for key in keys(literal) for i in self.by_anchor.get(key, ())}
        candidates = [i for i in ids if self.tags[i] <= tags and len(self.nodes[i]["clause"]) <= len(clause)
                      and (not support or self.nodes[i]["goal_support"])]
        candidates.sort(key=lambda i: (len(self.nodes[i]["clause"]), i))
        for i in candidates[:self.match_cap]:
            self.counts["subsumption_probes"] += 1
            source = self.nodes[i]
            mapping = subsumes(source["clause"], clause)
            if mapping is None:
                continue
            check_witness(source["clause"], clause, mapping, source["types"], types, self.functions)
            self.deletions.append(dict(donor=i, candidate=clause, types=types, bindings=mapping))
            self.counts["forward_subsumed"] += 1
            return True
        return False
