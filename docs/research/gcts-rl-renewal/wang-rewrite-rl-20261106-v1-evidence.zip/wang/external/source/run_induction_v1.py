"""Search, replay and audit induction and incidence on one Wang palette."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parents[1] / "source")]
from definition_composition_v1 import signature
import decode_v1 as decoder
from equality_cases_v1 import holds
from induction_cases_v1 import arithmetic, finite_no_induction, finite_no_uniqueness, hilbert, induction
from induction_search_v1 import context, geometry, search_arithmetic
from opaque_replay_v1 import build_bank, fragment, match, records, verify_bank
from lifted_native_v1 import fingerprint
from native_v1 import PUBLISHED_MACHINE
from schematic_capsules_v1 import encoded, frozen
from shared_wang_v1 import binding


DATA = HERE.parent / "data"
BUNDLE = DATA / "proofs-v1.json"
BANK = DATA / "traces-v1.json.gz"
RECEIPT = DATA / "receipt-v1.json"


def add_proof(wires, source, certificate):
    assert certificate["kind"] == "fol" and certificate["machine_sha256"] == PUBLISHED_MACHINE
    normal = certificate["compiled"]
    binding(source, "fol", normal, certificate["translation"])
    functions, _, sources, _ = signature(dict(compiled=normal))
    proof = frozen(certificate["proof"]["lines"])
    assert proof and not proof[-1]["clause"]
    keys = []
    for index, row in enumerate(proof):
        names, prefix, word = fragment(proof, index, sources, functions)
        parsed = decoder.read(prefix, word + "!", require_empty=False)
        match(proof, index, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        item = wires.setdefault(key, dict(prefix=prefix, word=word, example=[source["id"], index + 1],
                                          uses=0, rule=row["rule"]))
        assert (item["prefix"], item["word"]) == (prefix, word)
        item["uses"] += 1
        keys.append(key)
    return keys


def prepare(result):
    wires = {}
    counts = {}
    previous = []
    for expected, item in zip(arithmetic(), result["arithmetic"], strict=True):
        assert item["id"] == expected["id"]
        source = context(expected, previous, item["parents"])
        stages = induction(source, item["variable"])
        counts[item["id"]] = [add_proof(wires, stage, proof)
                              for stage, proof in zip(stages, item["proofs"], strict=True)]
        previous.append(expected["goal"])
    h = hilbert()
    assert result["geometry"]["id"] == h["id"]
    counts[h["id"]] = [add_proof(wires, h, result["geometry"]["proof"])]
    return wires, counts


def negative(result):
    row = result["arithmetic"][2]
    assert row["parents"]
    attacked = (
        ("step checked as base", {**row, "proofs": row["proofs"][::-1]}),
        ("omitted verified lemmas", {**row, "parents": []}),
        ("unverified future lemma", {**row, "parents": [3]}),
        ("changed induction variable", {**row, "variable": "?x" if row["variable"] == "?y" else "?y"}),
    )
    for label, fake in attacked:
        cases = list(result["arithmetic"])
        cases[2] = fake
        try:
            prepare({**result, "arithmetic": cases})
        except (AssertionError, KeyError, IndexError, ValueError):
            continue
        raise AssertionError("Invalid induction witness accepted: " + label)
    return [label for label, _ in attacked]


def countermodels():
    arithmetic_goal = next(arithmetic())
    sat, goal = holds(arithmetic_goal, finite_no_induction())
    assert all(sat) and not goal
    source = hilbert()
    weaker = {**source, "premises": source["premises"][1:]}
    sat, goal = holds(weaker, finite_no_uniqueness())
    assert all(sat) and not goal
    return ["addition recursion without induction", "betweenness and incidence without line uniqueness"]


def search():
    previous, found = [], []
    for source in arithmetic():
        item = search_arithmetic(source, previous)
        found.append(item)
        previous.append(source["goal"])
        print(item["id"], "induct on", item["variable"], "imports", item["parents"],
              "attempts", len(item["attempts"]), "direct", item["direct"]["status"], flush=True)
    geo = geometry(hilbert())
    for arm, counts in geo["compared"].items():
        print(geo["id"], arm, counts, flush=True)
    return dict(arithmetic=found, geometry=geo)


def main():
    if not __debug__:
        raise RuntimeError("Proof checking requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    result = json.loads(encoded(search())) if rebuild else json.loads(BUNDLE.read_text())
    wires, by_case = prepare(result)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(BANK.read_bytes()))
    receipt = dict(records={name: list(map(len, groups)) for name, groups in by_case.items()},
                   countermodels=countermodels(), rejected=negative(result), **verify_bank(wires, bank))
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if rebuild:
        BUNDLE.write_bytes(encoded(result) + b"\n")
        BANK.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        RECEIPT.write_bytes(encoded(receipt) + b"\n")
    else:
        assert receipt == json.loads(RECEIPT.read_text())


if __name__ == "__main__":
    main()
