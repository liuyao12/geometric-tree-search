"""The source statements and exact induction obligations."""
from itertools import product


def atom(name, *terms):
    return ["atom", name, *terms]


def close(names, body, quantifier="all"):
    for name, sort in reversed(names):
        body = [quantifier, name, sort, body]
    return body


def conj(*formulas):
    head, *rest = formulas
    return ["and", head, conj(*rest)] if rest else head


def implies(a, b):
    return ["implies", a, b]


def plus(a, b):
    return ["plus", a, b]


def successor(n):
    return ["S", n]


def eq(a, b):
    return atom("=Nat", a, b)


NAT = "Nat"
ZERO = ["zero"]
ARITHMETIC = {"zero": [[], NAT], "S": [[NAT], NAT], "plus": [[NAT, NAT], NAT]}
x, y, z = "?x", "?y", "?z"
RECURSION = [
    close([(x, NAT)], eq(plus(x, ZERO), x)),
    close([(x, NAT), (y, NAT)], eq(plus(x, successor(y)), successor(plus(x, y)))),
]


def arithmetic():
    for name, variables, goal in [
        ("zero-left", [x], eq(plus(ZERO, x), x)),
        ("successor-left", [x, y], eq(plus(successor(x), y), successor(plus(x, y)))),
        ("addition-commutes", [x, y], eq(plus(x, y), plus(y, x))),
        ("addition-associates", [x, y, z], eq(plus(plus(x, y), z), plus(x, plus(y, z)))),
    ]:
        yield dict(id=name, sorts=[NAT], equality=True, functions=ARITHMETIC, predicates={},
                   premises=RECURSION, goal=close([(v, NAT) for v in variables], goal))


def instantiate(node, env):
    def term(t):
        return env.get(t, t) if isinstance(t, str) else [t[0], *(term(arg) for arg in t[1:])]

    op, *args = node
    if op == "atom":
        return atom(args[0], *map(term, args[1:]))
    if op in ("all", "exists"):
        v, sort, body = args
        return [op, v, sort, instantiate(body, {key: t for key, t in env.items() if key != v})]
    return [op, *(instantiate(child, env) for child in args)]


def prefix(goal):
    variables = []
    while goal[0] == "all":
        _, v, sort, goal = goal
        variables.append((v, sort))
    assert len({v for v, _ in variables}) == len(variables)
    return variables, goal


def induction(source, variable):
    """Open every outer binder with an arbitrary, fresh constant."""
    assert source["sorts"] == [NAT] and source["functions"] == ARITHMETIC
    assert source["equality"] is True and not source["predicates"]
    variables, body = prefix(source["goal"])
    assert variable in dict(variables) and all(sort == NAT for _, sort in variables)
    parameters = {v: [f"parameter{i}"] for i, (v, _) in enumerate(variables)}
    assert not ({t[0] for t in parameters.values()} & source["functions"].keys())
    seed = parameters[variable]
    functions = {**source["functions"], **{t[0]: [[], NAT] for t in parameters.values()}}
    phi_zero = instantiate(body, {**parameters, variable: ZERO})
    phi_seed = instantiate(body, parameters)
    phi_next = instantiate(body, {**parameters, variable: successor(seed)})
    stem = {**source, "functions": functions}
    base = dict(stem, id=source["id"] + "-base", goal=phi_zero)
    step = dict(stem, id=source["id"] + "-step", premises=[*source["premises"], phi_seed], goal=phi_next)
    return base, step


def hilbert():
    # A plane incidence/order fragment in the symbolic language I and B.
    p, q, r, line, m = "?p", "?q", "?r", "?l", "?m"
    point, line_sort = "Point", "Line"
    incidence = lambda a, l: atom("I", a, l)
    between = lambda a, b, c: atom("B", a, b, c)
    distinct = lambda a, b: ["not", atom("=Point", a, b)]
    uniqueness = close([(p, point), (q, point), (line, line_sort), (m, line_sort)],
                       implies(conj(distinct(p, q), incidence(p, line), incidence(q, line),
                                    incidence(p, m), incidence(q, m)), atom("=Line", line, m)))
    order = close([(p, point), (q, point), (r, point)],
                  implies(between(p, q, r), conj(distinct(p, r), close(
                      [(line, line_sort)], conj(incidence(p, line), incidence(q, line), incidence(r, line)),
                      "exists"))))
    a, b, c, ell = ["a"], ["b"], ["c"], ["ell"]
    return dict(id="between-on-the-line", sorts=[point, line_sort], equality=True,
                functions={"a": [[], point], "b": [[], point], "c": [[], point], "ell": [[], line_sort]},
                predicates={"I": [point, line_sort], "B": [point] * 3},
                premises=[uniqueness, order, between(a, b, c), incidence(a, ell), incidence(c, ell)],
                goal=incidence(b, ell))


def finite_no_induction():
    """A recursion model with a successor cycle disjoint from zero."""
    values = (0, 1)
    return dict(domains={NAT: values},
                functions={"zero": {(): 0}, "S": {(a,): a for a in values},
                           "plus": {(a, b): a for a, b in product(values, repeat=2)}},
                predicates={})


def finite_no_uniqueness():
    return dict(domains={"Point": (0, 1, 2), "Line": (0, 1)},
                functions={"a": {(): 0}, "b": {(): 1}, "c": {(): 2}, "ell": {(): 0}},
                predicates={"B": {(0, 1, 2)}, "I": {(0, 0), (2, 0), (0, 1), (1, 1), (2, 1)}})
