"""Retrieve and check the pinned upstream benchmark text."""
from hashlib import sha256
import json
from pathlib import Path
import sys
from urllib.request import urlopen

sys.path.insert(0, str(Path(__file__).resolve().parent))
from tptp_cnf_v1 import problem_text

ROOT = Path(__file__).resolve().parents[1]


def main():
    sources = json.loads((ROOT / "data/sources-v1.json").read_text())
    collected = {}
    for name, record in sources.items():
        with urlopen(record["url"], timeout=30) as response:
            raw = problem_text(response.read().decode()).encode()
        assert sha256(raw).hexdigest() == record["sha256"], name
        collected[name] = raw
    for name, raw in collected.items():
        dest = ROOT / "input" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)
    print(f"Verified {len(collected)} upstream benchmark files.")


if __name__ == "__main__":
    main()
