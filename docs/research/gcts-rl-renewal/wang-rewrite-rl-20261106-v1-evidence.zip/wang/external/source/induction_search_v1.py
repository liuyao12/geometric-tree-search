"""Search Peano induction obligations and symbolic incidence."""
from itertools import combinations, product

from induction_cases_v1 import induction, prefix
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_closure_v1 import domain, prove
from equality_experiment_v1 import compact
from herbrand_v1 import inspect_term
from lifted_equality_prove_v1 import solve
from schematic_capsules_v1 import frozen
from tptp_transport_v1 import GoalSupport


OFFER_CAP = 10_000
NODE_CAP = 4_000


def lift(source):
    normal, translation = compile_case(source)
    check(source, normal, translation)
    prover = GoalSupport(source, normal=normal, goal_bias=24, offer_cap=OFFER_CAP, node_cap=NODE_CAP)
    summary, bundle, _ = solve(source, normal, translation, prover)
    return summary, bundle


def induction_variables(goal):
    """Try variables which expose addition recursion when replaced by a successor."""
    binders, body = prefix(goal)
    # Stable order starts with the innermost binder when scores tie.
    scores = {v: 0 for v, _ in reversed(binders)}

    def walk(node):
        if isinstance(node, list):
            if len(node) == 3 and node[0] == "plus" and isinstance(node[2], str) and node[2] in scores:
                scores[node[2]] += 1
            for child in node[1:]:
                walk(child)

    walk(body)
    return sorted(scores, key=scores.get, reverse=True)


def context(source, previous, dependencies):
    assert list(dependencies) == sorted(set(dependencies))
    assert all(type(i) is int and 0 <= i < len(previous) for i in dependencies)
    return {**source, "premises": [*source["premises"], *(previous[i] for i in dependencies)]}


def search_arithmetic(source, previous):
    attempts = []
    for size in range(len(previous) + 1):
        for parents in combinations(range(len(previous)), size):
            local = context(source, previous, parents)
            for variable in induction_variables(local["goal"]):
                base, step = induction(local, variable)
                b_stats, b_proof = lift(base)
                s_stats, s_proof = lift(step) if b_proof is not None else (None, None)
                attempts.append(dict(parents=list(parents), variable=variable, base=b_stats, step=s_stats))
                if s_proof is not None:
                    direct, _ = lift(local)
                    return dict(id=source["id"], parents=list(parents), variable=variable,
                                proofs=[b_proof, s_proof], attempts=attempts, direct=direct)
    raise RuntimeError("Induction search exhausted its finite proposal list: " + source["id"])


def witness_frontier(source, normal, translation):
    """Seed existential witness terms from matched ground guard facts."""
    functions = normal["functions"]
    facts = [frozen(row[1:]) for row in source["premises"] if row[0] == "atom"]
    witnesses = {tuple(row["path"]): row["witness"] for row in translation["definitions"]
                 if row["operator"] == "exists"}
    candidates = []
    active = []

    def match(pattern, fact, values):
        if isinstance(pattern, str):
            return values.setdefault(pattern, fact) == fact
        return (not isinstance(fact, str) and len(pattern) == len(fact) and pattern[0] == fact[0]
                and all(match(p, f, values) for p, f in zip(pattern[1:], fact[1:], strict=True)))

    def visit(node, path, scope, guard):
        op, *args = node
        if op == "all":
            v, sort, body = args
            visit(body, (*path, 0), (*scope, (v, sort)), guard)
        elif op == "implies" and args[0][0] == "atom":
            visit(args[1], (*path, 1), scope, frozen(args[0][1:]))
        elif op == "and":
            for j, child in enumerate(args):
                visit(child, (*path, j), scope, guard)
        elif op == "exists":
            fn = witnesses[path]
            active.append(fn)
            for fact in facts:
                values = {}
                if guard is not None and match(guard, fact, values) and all(v in values for v, _ in scope):
                    t = (fn, *(values[v] for v, _ in scope))
                    sort = inspect_term(t, {}, functions)
                    candidates.append(dict(term=t, sort=sort, fact=fact, path=path))

    for i, premise in enumerate(source["premises"]):
        visit(premise, (i,), (), None)
    return candidates, list(dict.fromkeys(active))


def geometry(source):
    normal, translation = compile_case(source)
    check(source, normal, translation)
    ordinary = domain(source, normal, 0, 64)
    demand, active = witness_frontier(source, normal, translation)
    assert ordinary is not None and demand
    selected = ordinary.copy()
    for row in demand:
        sort, term = row["sort"], row["term"]
        selected[sort] = tuple(dict.fromkeys((*selected[sort], term)))
    constants = {s: tuple((f,) for f, (args, out) in source["functions"].items()
                          if not args and out == s) for s in source["sorts"]}
    eager = ordinary.copy()
    for fn in active:
        args, out = normal["functions"][fn]
        terms = tuple((fn, *values) for values in product(*(constants[s] for s in args)))
        eager[out] = tuple(dict.fromkeys((*eager[out], *terms)))
    results = {}
    for name, terms in (("no-witness", ordinary), ("all-original-tuples", eager), ("matched-witness", selected)):
        status, proof, stats = prove(source, normal, 1, selected=terms, clause_limit=9_000)
        results[name] = dict(status=status, counts=stats, terms=sum(map(len, terms.values())))
    assert status == "PROVED"
    return dict(id=source["id"], demand=demand, compared=results,
                proof=compact(source, normal, translation, proof))
