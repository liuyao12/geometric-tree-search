"""Render the comparison and every checked logical line beside its Wang fragment."""
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "wang/source")]
from boundary_kernel_v1 import build
from proof_views_v1 import clause, explanation, formula, frame_window, math, tile_svg

NAME = "wang-fair-demand-20261106-v1"
TITLE = "Fair first-order search with Wang certificates"
LABELS = {
    "binary-witness-in-goal": "Nested term named in the goal",
    "binary-witness-to-discover": "Existential goal with hidden intermediate terms",
    "proof-by-cases": "Proof by cases",
    "typed-shadowed-witness": "Typed witness with shadowed variables",
    "two-points-determine-a-line": "Hilbert incidence uniqueness",
    "between-on-the-line": "Hilbert betweenness on a line",
    "mixed-quantifier-swap": "Mixed-sort quantifier swap",
    "occurs-check-control": "Cyclic unification control",
}
BATCH = {
    "PROVED": "Proved",
    "TERM_CAP": "Term cap",
    "INSTANCE_CAP": "Instance cap",
    "ELIMINATION_CAP": "Elimination cap",
    "DEPTH_CAP": "Depth cap",
}
EXAMPLE = "binary-witness-to-discover/demand"


def read(path):
    file = ROOT / path
    return json.loads(gzip.decompress(file.read_bytes()) if file.suffix == ".gz" else file.read_bytes())


def cell(run):
    proved = run["status"] == "PROVED"
    state = "Proved" if proved else "Open at limit"
    counts = run["counts"]
    style = "found" if proved else "open"
    return (f'<td><strong class="{style}">{state}</strong><small>{counts["rounds"]:,} rounds'
            f'<br>{counts.get("resolutions", 0):,} resolutions</small></td>')


def comparison(data):
    rows = []
    for item in data["rows"]:
        label = LABELS[item["original"]["id"]]
        if item["countermodel"]:
            label += "<small>Checked countermodel</small>"
        batch = BATCH[item["batches"]["status"]]
        rows.append(f'<tr><th scope="row">{label}</th><td>{batch}</td>'
                    f'{cell(item["runs"]["fair"])}{cell(item["runs"]["demand"])}</tr>')
    return "".join(rows)


def palette(bank):
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    tiles, windows, patches = {}, {}, []
    for i, (key, entry) in enumerate(bank["traces"].items()):
        end = entry["steps"]
        evidence = dict(prefix=entry["prefix"], word=entry["word"], padding=0, trace=entry["fragment"])
        rows, start = frame_window(machine, evidence, end - 5, entry["head"])
        uses = []
        for y, row in enumerate(rows):
            for x, tile in enumerate(row):
                number = tiles.setdefault(tile, len(tiles))
                uses.append(f'<use href="#wang-{number}" x="{36 * x}" y="{36 * y}"/>')
        ident = f"window-{i}"
        patches.append(f'<g id="{ident}">{"".join(uses)}</g>')
        windows[key] = (ident, end, start)
    defs = "".join(tile_svg(tile, i) for tile, i in tiles.items()) + "".join(patches)
    return '<svg class="palette" width="0" height="0" aria-hidden="true"><defs>' + defs + "</defs></svg>", windows


def figure(window):
    ident, end, start = window
    return (f'<figure><svg role="img" aria-label="Window of 45 checked Wang squares" '
            f'viewBox="0 0 324 180"><use href="#{ident}"/></svg>'
            f'<figcaption>Verifier rows {end - 4:,} to {end:,} and columns {start:,} to '
            f'{start + 8:,}. Hover over a square for its edge labels.</figcaption></figure>')


def proof_view(label, bundle, problem, windows, traces):
    name, mode = label.split("/")
    rows = []
    selected = label == EXAMPLE
    for i, (row, call) in enumerate(zip(bundle["clauses"], bundle["calls"], strict=True), 1):
        entry = traces[call]
        id_attr = f' id="witness-line-{i}"' if selected else ""
        rows.append(
            f'<li{id_attr}><div class="formula">{math(clause(row["clause"]))}</div>'
            f'<div>{explanation(row)}</div><details class="wire"><summary>Show Wang squares and input</summary>'
            f'{figure(windows[call])}<pre><code>{escape(entry["prefix"])}\n'
            f'{escape(entry["word"])}</code></pre></details></li>')
    assumptions = "".join(f'<li>{math(formula(p))}</li>' for p in problem["premises"])
    suffix = "with demand" if mode == "demand" else "exhaustive only"
    opened = " open" if selected else ""
    return (f'<details class="proof"{opened}><summary>{LABELS[name]} · {suffix}</summary>'
            f'<div class="grid"><div><h3>Hypotheses</h3><ul class="formulas">{assumptions}</ul></div>'
            f'<div><h3>Conclusion</h3><div class="formula">{math(formula(problem["goal"]))}</div></div></div>'
            f'<ol class="steps">{"".join(rows)}</ol></details>')


def main():
    data = read("data/fair-study-v1.json")
    receipt = read("wang/data/fair-receipt-v1.json")
    bank = read("wang/data/fair-bank-v1.json.gz")
    proofs = read("wang/data/fair-proofs-v1.json.gz")
    problems = {row["original"]["id"]: row["original"] for row in data["rows"]}
    defs, windows = palette(bank)
    example_call = proofs[EXAMPLE]["calls"][-1]
    order = [EXAMPLE, *(key for key in proofs if key != EXAMPLE)]
    all_proofs = "".join(proof_view(key, proofs[key], problems[key.split("/")[0]],
                                    windows, bank["traces"]) for key in order)
    vals = dict(title=TITLE, stem=NAME, table=comparison(data), palette=defs,
                example=figure(windows[example_call]), proofs=all_proofs,
                records=f'{receipt["records"]:,}', distinct=f'{receipt["unique_fragments"]:,}',
                proof_count=str(receipt["proofs"]), cap=f'{bank["cap"]:,}')
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.palette{position:absolute;width:0;height:0;overflow:hidden;border:0}
#tiles figure,.wire figure{max-width:26rem}
td small,th small{display:block;color:#42606f}.found{color:#145c49}.open{color:#685324}
.steps li{padding:.4rem .1rem;border-bottom:1px solid #d3e0e5}
.formula,.formulas li{overflow:auto;padding:.14rem 0}
.wire{margin:.3rem 0}.wire summary{font-size:.9rem}
.proof>ol{padding-left:1.8rem}.proof h3{font-size:1rem}
</style>""")
    body = (ROOT / "publication/fair-body-v1.html").read_text()
    for key, value in vals.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
