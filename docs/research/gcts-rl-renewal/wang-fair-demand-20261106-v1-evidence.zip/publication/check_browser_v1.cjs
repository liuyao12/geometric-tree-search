const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-fair-demand-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#reader mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison tbody tr").count(), 8);
      assert.match(await page.locator("#comparison tbody tr").nth(5).textContent(), /564,996/);
      assert.equal(await page.locator("#reader .proof").count(), 6);
      assert.equal(await page.locator("#reader .steps > li").count(), 235);
      const line = page.locator("#witness-line-47");
      await line.getByText("Show Wang squares and input").click();
      await line.locator("svg").waitFor();
      const window = await line.locator("svg > use").getAttribute("href");
      assert.equal(await page.locator(window + " > use").count(), 45);
      assert.match(await line.locator("pre").innerText(), /R10/);
      assert.match(await line.locator(".formula").textContent(), /⊥/);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      console.log("Verified", width, "px, search comparison, proof disclosure and Wang squares.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
