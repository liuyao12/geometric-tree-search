Fair first-order search with Wang certificates

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/fair_study_v1.py
  python3 -I -S -B source/fair_wang_v1.py
  python3 -I -S -B publication/render_v1.py

The first command repeats the benchmark and checks the two countermodels.
The second binds each refutation to the source formulas and replays it on
the fixed Wang palette. Either accepts --build to regenerate its data.
The last command regenerates the proof reader. MathJax typesets its formulas.
The manifest gives SHA-256 for each included input and result.
