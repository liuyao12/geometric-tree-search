"""Draw a conflict and read the resulting Wang proof."""
import gzip
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/source"), str(ROOT / "publication")]
from core_wang_v1 import problem, prepare
from boundary_kernel_v1 import build
from proof_views_v1 import frame_window, math, tile_svg
from schematic_capsules_v1 import frozen
from site_cover_study_v1 import Region, cases, independent_domains, setup

NAME = "turtle-conflict-replay-20261106-v1"
MODES = ("packed", "chronological", "backjump", "reuse", "cached")
LABELS = ("Packed", "Explain only", "Backjump", "Reuse", "Reuse and cache")


def read(name):
    return json.loads((ROOT / name).read_text())


def xy(p, den=1):
    a, b = p
    return (a + b/2) / den, -sqrt(3) * b / (2*den)


def polygon(points, color, border="#36535d", width=.14, extra=""):
    coords = " ".join(f"{a:.4f},{b:.4f}" for a, b in map(xy, points))
    return f'<polygon points="{coords}" fill="{color}" stroke="{border}" stroke-width="{width}" {extra}/>'


def figure(pts, shapes, caption):
    x, y = zip(*map(xy, pts))
    view = f"{min(x)-1:.4f} {min(y)-1:.4f} {max(x)-min(x)+2:.4f} {max(y)-min(y)+2:.4f}"
    return (f'<figure><svg role="img" aria-label="{escape(caption)}" viewBox="{view}">{shapes}</svg>'
            f'<figcaption>{caption}</figcaption></figure>')


def cover(g, tiles):
    polys = [(t, g.poly(t)) for t in tiles]
    shapes = "".join(polygon(p, f"hsl({155 + 7*t[0]} 48% {69 + 7*(t[0]%3)}%)") for t, p in polys)
    return figure((p for _, poly in polys for p in poly), shapes,
                  "The 597-tile cover produced from the fixed outline and checked independently.")


def mark(region, run):
    g = region.g
    ev = run["first_reuse"]
    row = run["proof"][ev["ref"]]
    core, q = row["core"], row["site"]
    assert not row["children"]
    incident = independent_domains(region)(q)
    selected = set().union(*(g.sites(t) for t in core))
    tile = min(incident, key=lambda t: (len(incident[t] & selected), t))
    hit = min(incident[tile] & selected)
    polys = [(t, g.poly(t)) for t in core]
    shapes = "".join(polygon(p, "#b294e5" if t == ev["trigger"] else "#90ccd0") for t, p in polys)
    rejected = g.poly(tile)
    shapes += polygon(rejected, "#f0a1a8", "#a33d50", .26, 'fill-opacity=".28" stroke-dasharray=".65 .4"')
    for site, color in ((q, "#ffcb56"), (hit, "#9f2942")):
        a, b = xy(site, g.model.scale)
        shapes += f'<circle cx="{a:.4f}" cy="{b:.4f}" r=".30" fill="{color}" stroke="#442d39" stroke-width=".09"/>'
    diagram = figure((p for _, poly in (*polys, (tile, rejected)) for p in poly), shapes,
                     "The purple tile completes the saved group. The dashed candidate covers the gold site "
                     "and overlaps a committed tile at the red sample.")
    return diagram, len(core), len(incident), len(ev["placements"])


def table(headers, rows):
    head = "".join(f'<th scope="col">{x}</th>' for x in headers)
    body = "".join("<tr>" + "".join(f"<td>{x}</td>" for x in row) + "</tr>" for row in rows)
    return f'<div class="table" tabindex="0"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>'


def token(name):
    return rf"T_{{{int(name[1:])}}}"


def formula(row):
    return math(r"\lor ".join(("" if positive else r"\neg ") + token(a)
                              for positive, (a,) in row["clause"]) or r"\bot")


def group(atoms, join):
    return math(join.join(map(token, atoms)))


def meaning(row):
    keep = [a for positive, (a,) in row["clause"] if not positive]
    choose = [a for positive, (a,) in row["clause"] if positive]
    if not keep and not choose:
        return "A cover of the outline is impossible."
    if not choose:
        return f"No cover can use all of {group(keep, ', ')}."
    options = group(choose, ", ")
    demand = f"a cover must use {options}" if len(choose) == 1 else f"a cover must use at least one of {options}"
    if keep:
        return f"If {group(keep, ', ')} are all used, {demand}."
    return demand.capitalize() + "."


def wang_view():
    rows, _, _, sources, _ = problem()
    proof = frozen(read("wang/data/core-proof-v1.json"))
    _, calls = prepare(proof, sources)
    bank = json.loads(gzip.decompress((ROOT / "wang/data/core-bank-v1.json.gz").read_bytes()))
    evidence = bank["traces"][calls[-1]]
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    start = evidence["steps"] - 5
    trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
    window, first = frame_window(machine, trace, start, evidence["head"])
    ids, cells = {}, []
    for y, row in enumerate(window):
        for x, tile in enumerate(row):
            i = ids.setdefault(tile, len(ids))
            cells.append(f'<use href="#wang-{i}" x="{36*x}" y="{36*y}"/>')
    defs = "".join(tile_svg(tile, i) for tile, i in ids.items())
    tape = (f'<figure><svg role="img" aria-label="Translation-only Wang squares at the closing resolution" '
            f'viewBox="0 0 324 180"><defs>{defs}</defs>{"".join(cells)}</svg>'
            f'<figcaption>Closing resolution. Verifier rows {start+1:,} to {start+5:,}, '
            f'tape columns {first:,} to {first+8:,}. Colors identify matching edges.</figcaption></figure>')
    readings = []
    for i, row in enumerate(proof, 1):
        if row["rule"] == "G":
            j = int(row["source"].split("-")[1])
            pos = math(str(rows[j]["site"]))
            step = f"Import the checked placement options at sample {pos}."
        else:
            pivot = math(token(row["pivot"][0]))
            step = f"Resolve lines {row['left']+1} and {row['right']+1} on {pivot}."
        readings.append((i, step, formula(row), meaning(row)))
    return tape, table(("Line", "Checked operation", "Formula", "Reading"), readings)


def main():
    g, _, _ = setup()
    rows = read("data/conflict-study-v1.json")
    times = read("data/conflict-timing-v1.json")
    large = frozen(read("data/repair-14-core-v1.json"))
    receipt = read("wang/data/core-receipt-v1.json")
    fixtures = {r["id"]: r for r in cases(g)}
    region = Region(g, fixtures["repair-14"]["rings"])
    diagram, core_size, options, depth = mark(region, large)
    outline, hole = fixtures["rotated-hole"]["rings"]
    cavity = figure(outline, polygon(outline, "#9bcdd1") + polygon(hole, "#fff5da", "#a33d50", .33),
                    "The fixed outer boundary and the hole in its prescribed orientation.")
    score = table(("Outline", "Tiles by area", "Visit cap", "Outcome", *LABELS),
                  [(r["id"], r["tiles"], r["cap"],
                    {"POSITIVE": "Cover", "NEGATIVE": "Impossible", "BOUNDED": "Open"}[r["arms"]["cached"]["status"]],
                    *(f'{r["arms"][k]["counts"]["nodes"]:,}' for k in MODES)) for r in rows])
    timings = table(("Outline", *LABELS),
                    [(r["id"], *(f'{r["medians"][k]:.3f} s' for k in MODES)) for r in times])
    tape, proof = wang_view()
    positions = table(("Placement", "Turn and lattice translation"),
                      [(math(token(n)), math(str(tuple(receipt["tiles"][n]))))
                       for n in sorted(receipt["tiles"], key=lambda n: int(n[1:]))])
    measured = next(r["medians"] for r in times if r["id"] == "repair-14")
    positive = sum(r["arms"]["cached"]["status"] == "POSITIVE" for r in rows)
    negative = sum(r["arms"]["cached"]["status"] == "NEGATIVE" for r in rows)
    improved = sum(r["arms"]["cached"]["counts"]["nodes"] < r["arms"]["packed"]["counts"]["nodes"] for r in rows)
    counts = large["counts"]
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", "Turtle search with reusable conflict marks")
    head = head.replace("</style>", ".table:focus{outline:2px solid #13787b}#wang figure,#mark figure{max-width:35rem}</style>")
    page = head + rf"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>Turtle search with reusable conflict marks</h1>
<p>A failed branch yields a checked set of placements that cannot coexist in a cover.
On the largest outline, using these sets cut search visits from 3,188 to 1,404.</p>
<nav><a href="#cover">597-tile cover</a><a href="#mark">Reused conflict</a><a href="#benchmark">Controls</a>
<a href="#wang">Wang proof</a><a href="{NAME}-evidence.zip">Replay archive</a></nav></header>
<section id="cover"><h2>Cover the 597-tile outline</h2>
{cover(g, large["patch"])}
<p>Every arm receives the same fixed outline and the same primitive poses. The initial placement set is empty.
The cover checker compares the exact perimeter and checks the tile count and pairwise non-overlap.</p></section>
<section id="mark"><h2>Reuse a failure across branches</h2>
{diagram}
<p>At the gold site, every one of the {options} primitive poses that fits the outline overlaps
at least one of the {core_size} committed tiles shown. The next branch matched all {core_size}
placements after placing {depth} tiles. The remaining tiles in that prefix are irrelevant to this conflict.</p>
<p>A more general mark can also use previously certified conflicts. For a sample \(q\) and a
set \(C\) of committed placements, consider every in-bounds tile that could cover \(q\).
Each option either overlaps \(C\) or extends \(C\) to a previously refuted set.
The checker then certifies the clause \(\bigvee_{{t\in C}}\neg T_t\), where \(T_t\) means the cover uses pose \(t\).</p>
<p>If the clause holds before the most recent decision, the solver returns it past that decision
and skips the remaining sibling branches. The inventory indexes small clauses by pose and
checks whether the current branch contains the whole set.
The 597-tile run stored {counts["stored_cores"]} such sets of at most ten placements and used them
to close {counts["reuse_hits"]} branches. This pilot stores placements in outline coordinates.
<a href="https://doi.org/10.1016/0004-3702(90)90046-3">Dechter on constraint learning and backjumping</a></p></section>
<section id="benchmark"><h2>Separate search visits from elapsed time</h2>
<p>All five arms classified the same {positive} tileable and {negative} impossible outlines within the listed caps.
Reuse with the blocker cache reduced visits on {improved} outlines. The explain-only control followed the packed
solver’s search and produced the same covers. Backjumping changes which sibling branches get visited.
The reuse arms add an inventory. The last arm also caches one geometric blocker per rejected pose and checks
that the blocker is still selected before accepting it.</p>{score}
<p>Each elapsed value is the median of five runs, with arm order rotated across repetitions.
The clock includes outline setup, board construction, search and certificate construction.
Independent verification runs outside these timed trials.
On the 597-tile case the packed solver took {measured["packed"]:.3f} seconds and
the inventory with the blocker cache took {measured["cached"]:.3f} seconds.
The checker rebuilt every saved site domain by direct sample translation.</p>{timings}</section>
<section id="wang"><h2>Refute the rotated hole in Wang tiles</h2>
{cavity}
<p>The geometry checker reconstructed {receipt["geometry"]["rows"]} conflict clauses by testing
{receipt["geometry"]["options"]:,} incident poses, counting each pose once per checked row.
It rejected a tampered certificate that dropped an option from the final site clause.
The refutation uses {receipt["inputs"]} reachable geometry clauses and {receipt["records"]} logical records.
Each atom names a particular Turtle placement. The final clause is empty, which rules out a cover.</p>
<p>The Wang checker reads the imported clauses and replays resolution on fixed-orientation squares.
The geometry audit supplies the link from lattice placements to those premises.</p>
{tape}<details id="lines"><summary>Read all {receipt["records"]} records in formulas and words</summary>{proof}</details>
<details id="placements"><summary>Look up the placement named by each atom</summary>{positions}
<p>Each triple gives the symmetry index followed by the two \(A_2\) translation coordinates.
Sample coordinates in the proof use the integer grid scaled by \(18\).</p></details>
</section></main></body></html>"""
    (ROOT / "report" / (NAME + ".html")).write_text(page)


if __name__ == "__main__":
    main()
