Turtle search with reusable conflict marks

From the archive root, run these commands with Python 3.12.

    python3 -I -S -B source/conflict_study_v1.py
    python3 -I -S -B source/core_wang_v1.py --build
    python3 -I -S -B source/core_wang_v1.py
    python3 -I -S -B publication/render_v1.py

These commands rerun the outline searches, audit their geometric clauses,
rebuild and verify the Wang trace bank, and render the HTML report.

The saved timing receipt is machine-dependent. To repeat the timed
trials, run the study with --timing 5.
