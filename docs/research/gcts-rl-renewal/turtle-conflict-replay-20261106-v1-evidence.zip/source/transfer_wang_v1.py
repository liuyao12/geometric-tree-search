"""Replay one shared-conflict exclusion on two independently checked boundaries."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from geometry_v1 import add, mul
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate
from support_study_v1 import Region, cases, independent_domains, load, setup


DATA = ROOT / "wang/data"


def check_geometry(region, data):
    g = region.g
    occupied = set()
    for tile in data["path"]:
        part = g.sites(tile)
        assert part <= region.sites and not part & occupied
        occupied.update(part)
    q = data["site"]
    assert q in region.sites and q not in occupied
    domain = {t for t, cells in independent_domains(region)(q).items() if not cells & occupied}
    assert domain == set(data["choices"]) and len(domain) == 2
    rejected = data["excluded"]
    part = g.sites(rejected)
    assert rejected not in domain and part <= region.sites and not part & occupied
    for tile, site in zip(data["choices"], data["overlap"], strict=True):
        assert site in part and site in g.sites(tile)


def problem():
    g, _, _ = setup()
    rows = {row["id"]: row for row in cases(g)}
    mark = frozen(load("data/support-study-v1.json")["transfer"])
    donor, receiver, shift = (mark[k] for k in ("donor", "receiver", "shift"))
    regions = {}
    for name, data in (("repair-09", donor), ("repair-13", receiver)):
        regions[name] = Region(g, rows[name]["rings"])
        check_geometry(regions[name], data)
    assert {(add(a, shift), add(b, shift)) for a, b in regions["repair-09"].edges} != regions["repair-13"].edges
    assert add(donor["site"], mul(g.model.scale, shift)) == receiver["site"]
    assert g.shift(donor["excluded"], shift) == receiver["excluded"]
    assert tuple(g.shift(t, shift) for t in donor["choices"]) == receiver["choices"]
    assert tuple(add(q, mul(g.model.scale, shift)) for q in donor["overlap"]) == receiver["overlap"]
    wrong = {**receiver, "choices": receiver["choices"][:-1], "overlap": receiver["overlap"][:-1]}
    try:
        check_geometry(regions["repair-13"], wrong)
    except AssertionError:
        rejected = True
    else:
        raise AssertionError("Omitted site option was accepted")
    clauses = {
        "complete-site-domain": ((True, ("A",)), (True, ("B",))),
        "overlap-with-A": ((False, ("A",)), (False, ("X",))),
        "overlap-with-B": ((False, ("B",)), (False, ("X",))),
        "assume-X": ((True, ("X",)),),
    }
    return {k: dict(id=k, variables={}, clause=v) for k, v in clauses.items()}, mark, rejected


def derive(sources):
    b = Certificate(sources, {}, {k: [] for k in "ABX"}, ["U"], {})
    site, mutex_a, mutex_b, assume = (b.instance(s, {}) for s in sources)
    a = b.resolve(assume, mutex_a, ("X",))
    c = b.resolve(assume, mutex_b, ("X",))
    d = b.resolve(site, a, ("A",))
    b.resolve(d, c, ("B",))
    return b.lines


def prepare(proof, sources):
    assert proof and not proof[-1]["clause"]
    wires, calls = {}, []
    for i, row in enumerate(proof):
        names, prefix, word = fragment(proof, i, sources, {})
        parsed = decoder.read(prefix, word + "!", require_empty=False)
        match(proof, i, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=i+1, uses=0, rule=row["rule"]))
        assert (wire["prefix"], wire["word"]) == (prefix, word)
        wire["uses"] += 1
        calls.append(key)
    return wires, calls


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    sources, mark, rejected = problem()
    proof_path, bank_path = DATA / "transfer-proof-v1.json", DATA / "transfer-bank-v1.json.gz"
    proof = frozen(derive(sources)) if rebuild else frozen(json.loads(proof_path.read_text()))
    wires, calls = prepare(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(mark=mark, rejected_omission=rejected, records=len(calls), **verify_bank(wires, bank))
    print(json.dumps({k: v for k, v in receipt.items() if k != "mark"}, sort_keys=True), flush=True)
    receipt_path = DATA / "transfer-receipt-v1.json"
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert json.loads(encoded(receipt)) == json.loads(receipt_path.read_text())


if __name__ == "__main__":
    main()
