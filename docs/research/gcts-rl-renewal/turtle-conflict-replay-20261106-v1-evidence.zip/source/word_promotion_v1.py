"""Infer a short word recurrence and test its next strip in a promoted frame."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import save, sub
from cluster_v1 import load
from collar_audit_v1 import freeze
from mixed_orbits_v1 import joined_border, shift
from scaffold_v1 import Scaffold, make
from strip_fit_v1 import attach, overlap, possible_letters, receptor_bank


def infer(observed,observed_later,rounds=8):
    """Fit binary concatenation with a fixed order and two steps per layer."""
    a,b=tuple(observed),tuple(observed_later)
    assert b[:len(a)]==a and b[-len(a):]==a and len(b)>2*len(a)
    previous=b[len(a):-len(a)]
    assert a[:len(previous)]==previous and len(a)>len(previous)
    first=a[len(previous):]
    words=[first,previous]
    for _ in range(rounds):
        words.append(words[-1]+words[-2])
    assert words[2]==a and words[4]==b
    return tuple(words)


def signed(edges):
    return sum(x*v-y*u for (x,y),(u,v) in edges)


def fit_hole(s,shape,cycle):
    wanted={(b,a) for a,b in cycle}
    target=min(p for e in wanted for p in e)
    options=set()
    for turn in s.model.groups:
        patch=s.geom.moved(shape,turn)
        edges=s.geom.boundary(patch)
        left=min(p for e in edges for p in e)
        delta=sub(target,left)
        translated=shift(patch,delta)
        if s.geom.boundary(translated)==wanted:
            options.add(translated)
    if not options:
        return None
    one,=options
    return one


def fill_cavities(s,shape,core):
    cycles=core["cycles"]
    if sum(signed(c)>0 for c in cycles)!=1:
        return None
    holes=[c for c in cycles if signed(c)<0]
    caps=[]
    for hole in holes:
        placed=fit_hole(s,shape,hole)
        if placed is None:
            return None
        caps.append(placed)
    return tuple(sorted(caps))


def predicted_strips(s,frame,turn,word):
    geom=s.geom
    lanes,required,stride=possible_letters(s,frame,turn)
    border=[(geom.boundary(part),(0,0)) for part in frame]
    found=[]
    checks=Counter(lanes=len(lanes))
    for site,slots in sorted(lanes.items()):
        for first in sorted(slots):
            tiles=[]
            other=[]
            hit=set()
            for j,k in enumerate(word):
                row=slots.get(first+j,{}).get(k)
                if row is None:
                    break
                p,q,edges=row
                tiles.append(p)
                other.append(q)
                hit.update(edges)
            else:
                checks["admitted_words"]+=1
                if hit!=required or not geom.occupied(tuple(tiles)).isdisjoint(geom.occupied(tuple(other))):
                    continue
                path=tuple(tiles)
                twin=tuple(other)
                boundary=joined_border((*border,(geom.boundary(path),(0,0)),(geom.boundary(twin),(0,0))))
                if boundary:
                    checks["closed"]+=1
                    pieces=(*frame,path,twin)
                    patch=tuple(sorted(t for p in pieces for t in p))
                    found.append(dict(phase=turn,lane=site,first=first,word=word,pieces=pieces,patch=patch,
                                      perimeter=len(boundary),stride=stride))
    return checks,found


def prior(recovered,result):
    chosen=result["cases"][0]
    tri=chosen["winners"][0]
    t2=recovered["parents"][0]["patch"]
    p2=chosen["recipe"]
    path=p2["pieces"][-2:]
    alphabet=dict(recovered["alphabet"])
    dx,dy=alphabet["stride"]
    alphabet["path"]=tuple((g,x+i*dx,y+i*dy) for i,k in enumerate(p2["word"])
                           for g,x,y in (alphabet["letters"][k],))
    return dict(motif=p2["patch"],doublet=recovered["motif"],seed=t2,
                strips=path,motif_pairs=p2["pieces"][:5],alphabet=alphabet,
                parents=[dict(pieces=(*tri["pieces"][4:],*tri["pieces"][1:4]))])


def predict(new,recipe,small_cap,word):
    bank=receptor_bank(new,recipe)
    phases=[new.core(g,allow_holes=True) for g in new.phases]
    best=max(c["score"] for p in phases for c in p["candidates"])
    found={}
    scan=[]
    for phase in phases:
        for i,core in enumerate(phase["candidates"]):
            if core["score"]!=best:
                continue
            caps=fill_cavities(new,small_cap,core)
            stats=Counter()
            if caps is not None:
                stats["filled_cavities"]=len(caps)
                for frame in attach(new,core["pieces"],bank):
                    stats["attached_frames"]+=1
                    if any(overlap(new,a,b) for a in frame[-2:] for b in caps):
                        stats["receiver_cap_collision"]+=1
                        continue
                    full=(*frame,*caps)
                    for turn in new.model.groups:
                        for form in dict.fromkeys((word,word[::-1])):
                            checks,patches=predicted_strips(new,full,turn,form)
                            stats.update(checks)
                            for r in patches:
                                found.setdefault(r["patch"],dict(core_phase=phase["phase"],core_index=i,
                                    core=core,caps=caps,**r))
            scan.append(dict(phase=phase["phase"],core_index=i,counts=stats))
    result=sorted(found.values(),key=lambda r:(Fraction(r["perimeter"]**2,len(r["patch"])),r["patch"]))
    return dict(scaffold_score=best,search=scan,assemblies=result)


def main():
    s,old=make()
    result=freeze(load("data/capped-orbits-v1.json"))
    chosen=result["cases"][0]
    next_data=prior(old,result)
    words=infer(old["alphabet"]["word"],chosen["recipe"]["word"])
    new=Scaffold(s.geom,next_data)
    result=predict(new,next_data,s.triangle,words[6])
    save("data/word-promotion-v1.json",dict(status="PREDICTED_STRIP_RECURRENCE_AND_PROMOTED_FRAMES",
                                           words=words,**result))
    print("words",[len(w) for w in words],"core score",result["scaffold_score"],
          "assemblies",len(result["assemblies"]),flush=True)
    for r in result["assemblies"][:6]:
        print(r["core_phase"],r["phase"],len(r["patch"]),r["perimeter"],len(r["caps"]),flush=True)


if __name__=="__main__":
    main()
