"""Use a proved Turtle plane tiling to propose a core for fixed-boundary search."""
from collections import Counter
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from boundary_search_v1 import Inventory, Region, remove, solve
from cluster_v1 import load, mat
from geometry_v1 import Turtle, add, chain, check_rings, rings_from_edges
from window_v1 import Hierarchy, freeze, rectangle

LIMIT = 360
REPAIR_LIMIT = 42
ACTIONS = ("direct", "all", "collar", "marked")


def setup():
    g = Turtle(load("input/exact-point-model-v1.json"))
    rule = freeze(load("input/coordinate-v1.json"))["rule"]
    alphabet = freeze(load("input/recovered-production-v1.json"))["alphabet"]
    return g, Hierarchy(g.model, rule, alphabet), Inventory(g)


def placed_children(atlas, node, turn, offset):
    for kind, n, g, p in atlas.nodes[node].children:
        yield (kind, n), atlas.model.compose[turn, g], add(mat(atlas.model.groups[turn], p), offset)


def expand(atlas, address):
    node, turn, offset = address
    if atlas.nodes[node].children:
        return tuple(t for child in placed_children(atlas, node, turn, offset) for t in expand(atlas, child))
    return tuple((g, *add((x, y), offset))
                 for t in atlas.nodes[node].tiles for g, x, y in (atlas.model.action(turn, t),))


def pool(atlas, size):
    atlas.ensure(5)
    pending = [(("T", 5), 0, (0, 0))]
    while pending:
        address = pending.pop()
        node = address[0]
        if node == size:
            yield address
            continue
        if node[0] in ("T", "P") and node[1] >= size[1]:
            pending.extend(placed_children(atlas, *address))


def ring_of(g, patch):
    rings = rings_from_edges(chain(g, patch))
    if rings is None or len(rings) != 1:
        return None
    return rings[0]


def extend(g, atlas, inv, patch, amount, selection):
    occupied = frozenset().union(*(g.sites(t) for t in patch))
    previous = None
    for step in range(amount):
        boundary = chain(g, patch)
        edges = sorted(boundary if previous is None else boundary & frozenset(g.boundary(previous)))
        if not edges:
            return None
        edges = edges[selection % len(edges):] + edges[:selection % len(edges)]
        for a, b in edges:
            for (candidate,) in inv.at((b, a)):
                sites = g.sites(candidate)
                if occupied & sites:
                    continue
                if ring_of(g, (*patch, candidate)) is None:
                    continue
                if not step and candidate in atlas.query(g.poly(candidate))[0]:
                    continue
                patch = (*patch, candidate)
                occupied |= sites
                previous = candidate
                break
            else:
                continue
            break
        else:
            return None
    return patch


def cases(g, atlas, inv):
    # Donor clusters and test clusters have disjoint primitive tile sets.
    requests = (
        ("train", "aligned", ("P", 1), 0, (0, 0)),
        ("train", "edited", ("T", 2), 2, (0, 0)),
        ("train", "edited", ("P", 2), 3, (0, 0)),
        ("train", "shifted", ("P", 1), 1, (17, -9)),
        ("train", "shifted", ("T", 2), 2, (-29, 16)),
        ("train", "shifted", ("P", 2), 1, (37, 19)),
        ("test", "aligned", ("T", 2), 0, (0, 0)),
        ("test", "edited", ("T", 2), 1, (0, 0)),
        ("test", "edited", ("T", 2), 4, (0, 0)),
        ("test", "edited", ("P", 2), 2, (0, 0)),
        ("test", "edited", ("P", 2), 4, (0, 0)),
        ("test", "shifted", ("P", 1), 2, (-31, 23)),
        ("test", "shifted", ("T", 2), 3, (11, 19)),
        ("test", "shifted", ("P", 2), 2, (9, -31)),
        ("test", "edited", ("T", 3), 3, (0, 0)),
        ("test", "trap", ("P", 2), 3, (0, 0)),
        ("test", "trap", ("T", 2), 4, (0, 0)),
    )
    # Reserve the largest clusters first so their smaller descendants cannot
    # be assigned to another request.
    seen = set()
    result = {}
    for i in sorted(range(len(requests)), key=lambda j: (-atlas_size(atlas, requests[j][2]), j)):
        partition, kind, size, steps, shift = requests[i]
        for address in pool(atlas, size):
            core = expand(atlas, address)
            if not seen.isdisjoint(core):
                continue
            if kind == "trap":
                patch = trap(g, atlas, inv, core, steps, 7*i+3)
            else:
                patch = extend(g, atlas, inv, core, steps, 7*i+3) if steps else core
            if patch is None:
                continue
            seen.update(patch)
            placed = tuple(sorted(g.shift(t, shift) for t in patch))
            outline = ring_of(g, placed)
            assert outline is not None
            check_rings(g, (outline,))
            result[i] = dict(id=f"repair-{i:02d}", partition=partition, kind=kind, rings=(outline,),
                             construction=placed, edit_tiles=steps, atlas_address=address, translation=shift)
            break
        else:
            raise ValueError(f"No construction for case {i}")
    return [result[i] for i in sorted(result)]


def trap(g, atlas, inv, core, steps, selection):
    """Select a boundary edit where a whole atlas tile conflicts with the edits."""
    for delta in range(48):
        patch = extend(g, atlas, inv, core, steps, selection+delta)
        if patch is None:
            continue
        edits = patch[len(core):]
        added_sites = frozenset().union(*(g.sites(t) for t in edits))
        overlaps = {t for edit in edits for t in atlas.query(g.poly(edit))[0]}
        if any(g.sites(t) <= added_sites for t in overlaps.difference(patch)):
            return patch
    return None


def atlas_size(atlas, size):
    atlas.ensure(5)
    return atlas.nodes[size].count


def atlas_seed(g, atlas, region):
    x, y = zip(*region.rings[0])
    window = rectangle(min(x), min(y), max(x)-min(x), max(y)-min(y))
    candidates, receipt = atlas.query(window)
    inside, crossing, indexed = set(), set(), 0
    for t in candidates:
        indexed += 1
        sites = g.sites(t)
        if sites <= region.sites:
            inside.add(t)
        elif sites & region.sites:
            crossing.add(t)
    outside_edges = frozenset(e[::-1] for t in crossing for e in g.boundary(t))
    strip = {t for t in inside if any(e in outside_edges or e in region.edges for e in g.boundary(t))}
    return (tuple(sorted(inside)), tuple(sorted(inside - strip)),
            dict(inside=len(inside), crossing=len(crossing), collar=len(strip), containment_checks=indexed,
                 query=receipt))


def work(answer):
    search = answer["counts"]
    preflight = answer["preflight"]
    return (search.get("placement_checks", 0) + 8*search.get("nodes", 0)
            + answer["seed_tiles"] + preflight.get("containment_checks", 0)
            + preflight.get("query", {}).get("counts", {}).get("visited", 0)
            + answer.get("mark_checks", 0))


def mark_repair(region, inv, seed):
    """Drop seed commitments that certify an empty residual edge domain."""
    g = region.g
    working = set(seed)
    witness = []
    owner = {p: t for t in seed for p in g.sites(t)}
    boundary_owner = {e: t for t in seed for e in g.boundary(t)}
    probes = 0
    for _ in range(4):
        edges = remove(region.edges, chain(g, working))
        for edge in sorted(edges, key=lambda e: (e in region.edges, inv.direction_count(e), e))[:24]:
            options = []
            for (candidate,) in inv.at(edge):
                probes += 1
                outside = region.exterior(candidate)
                if outside:
                    options.append((candidate, outside, ()))
                    continue
                blocked = {}
                for p in sorted(g.sites(candidate)):
                    t = owner.get(p)
                    if t in working:
                        blocked.setdefault(t, p)
                if not blocked:
                    break
                options.append((candidate, None, tuple(sorted(blocked.items()))))
            else:
                releases = [tuple(t for t, _ in blockers) for _, outside, blockers in options if not outside]
                anchor = boundary_owner.get(edge[::-1])
                drop = min(releases, key=lambda ts: (len(ts), ts)) if releases else (
                    (anchor,) if anchor in working else ())
                if not drop:
                    return tuple(sorted(working)), witness, probes
                witness.append(dict(edge=edge, options=options, release=drop))
                working.difference_update(drop)
                break
        else:
            break
    return tuple(sorted(working)), witness, probes


def attempt_region(region, inv, row, action, preview):
    assert action in ACTIONS
    if region.counts is None:
        result = solve(region, inv, row["id"], limit=LIMIT)
        return {**result, "action": action, "seed": (), "seed_tiles": 0, "preflight": {}, "repair": None}
    total = region.counts[0]
    limit = max(LIMIT, 2*total+40)
    if action == "direct":
        result = solve(region, inv, row["id"], limit=limit)
        return {**result, "action": action, "seed": (), "seed_tiles": 0, "preflight": {}, "repair": None}
    all_tiles, collar, preflight = preview
    seed = collar if action == "collar" else all_tiles
    mark_fields = {}
    if action == "marked":
        seed, marks, probes = mark_repair(region, inv, seed)
        mark_fields = dict(marks=marks, mark_checks=probes)
    if not seed:
        result = solve(region, inv, row["id"], limit=limit)
        return {**result, **mark_fields, "action": action, "seed": seed, "seed_tiles": 0,
                "preflight": preflight, "repair": None}
    repair_limit = max(REPAIR_LIMIT, min(128, total//4))
    first = solve(region, inv, row["id"], limit=repair_limit, seed=seed)
    if first["status"] == "POSITIVE":
        return {**first, **mark_fields, "action": action, "seed": seed, "seed_tiles": len(seed),
                "preflight": preflight, "repair": first["status"]}
    # Rebuild the unconditioned problem. A seed failure only refutes that seed.
    used = min(first["counts"].get("nodes", 0), repair_limit)
    result = solve(Region(region.g, row["rings"]), inv, row["id"], limit=limit-used)
    totals = Counter(first["counts"])
    totals.update(result["counts"])
    return {**result, **mark_fields, "counts": dict(totals), "action": action, "seed": seed, "seed_tiles": len(seed),
            "preflight": preflight, "repair": first["status"], "fallback": result["status"]}


def context(preflight, total):
    covered = preflight["inside"]
    return ("strong" if 5*covered >= 4*total else "weak",
            "small" if total < 100 else "large")
