"""Screen shape-only seeds, transfer blocked edges, and train move ordering."""
from collections import Counter, defaultdict
from pathlib import Path
from random import Random
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, ROOT, save
from cluster_v1 import Model, load
from collars_v1 import Collar, Mark

ORDERS=("lex","compact","spread")
SCREEN_RADIUS=10


def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x


def pool(result):
    candidates={}
    for i,family in enumerate(result["half_turns"]):
        for j,row in enumerate(family["assemblies"]):
            p=freeze(row["key"])
            assert p not in candidates
            candidates[p]=dict(id=f"C{i:02}-{j:02}",family=i,perimeter=row["perimeter"])
    return candidates


def objective(row):
    c=row["stats"]
    return 100*c.get("states",0)+c.get("placement_checks",0)//100+(
        100_000 if row["status"]!="COVERED" else 0)


def policy_action(scores):
    return min(ORDERS,key=lambda x:sum(scores[x])/len(scores[x]))


def train(solver,seed,bank):
    rng=Random(271833)
    cohorts=defaultdict(lambda:defaultdict(list))
    episodes=[]
    for radius in (5,6,7,8,9,11,13,14,15,16,17,19):
        group="near" if radius<=12 else "wide"
        costs=cohorts[group]
        options=[a for a in ORDERS if not costs[a]]
        if options:
            action=options[0]
        elif rng.random()<.25:
            action=rng.choice(ORDERS)
        else:
            action=policy_action(costs)
        row=solver.search(seed,radius,action,bank,maximum=250,orbit=True)
        loss=objective(row)
        costs[action].append(loss)
        episodes.append(dict(radius=radius,group=group,order=action,loss=loss,run=row))
        print("training",radius,action,row["status"],flush=True)
    return episodes,{k:policy_action(s) for k,s in sorted(cohorts.items())}


def main():
    shape=load("data/assemblies-v1.json")
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    solver=Collar(geom)
    candidates=pool(shape)
    pairs=shape["half_turns"]
    pair_min=min(r["pair_boundary"] for r in pairs)
    pair,=(freeze(r["pair"]) for r in pairs if r["pair_boundary"]==pair_min)
    perimeter=min(row["perimeter"] for row in candidates.values())
    selected,=(p for p,row in candidates.items() if row["perimeter"]==perimeter)
    donors={}
    for seed,spec in candidates.items():
        if spec["family"] not in (2,4,6,8,10):
            continue
        row=solver.search(seed,8,"compact",learn=True,maximum=180)
        for source in row["donors"]:
            mark=Mark(freeze(source["direction"]),freeze(source["blockers"]),freeze(source["cover"]))
            donors.setdefault(mark,dict(id=spec["id"],seed=seed,**source))
    assert donors
    bank=tuple(donors)
    screen=[]
    for seed,spec in candidates.items():
        plain=solver.search(seed,SCREEN_RADIUS,"compact",maximum=250)
        used=spec["family"] not in (2,4,6,8,10)
        marked=solver.search(seed,SCREEN_RADIUS,"compact",bank,maximum=250) if used else None
        if marked is not None:
            assert plain["status"]==marked["status"]
            if plain["status"]=="COVERED":
                assert plain["patch"]==marked["patch"]
        screen.append(dict(**spec,seed=seed,plain=plain,marked=marked))
    survivors=[freeze(row["seed"]) for row in screen if row["plain"]["status"]=="COVERED"]
    assert len(survivors)>=2 and selected in survivors
    alternative=min((p for p in survivors if p!=selected),key=lambda p:candidates[p]["perimeter"])
    print("screened",Counter(row["plain"]["status"] for row in screen),"marks",len(bank),flush=True)
    episodes,policy=train(solver,alternative,bank)
    receivers=[]
    for radius in (10,18,24,30,40):
        group="near" if radius<=12 else "wide"
        chosen=policy[group]
        arms={}
        for name,action,orbit,inventory in (
            ("unit","compact",False,()),("orbit","compact",True,()),
            ("marked","compact",True,bank),("learned",chosen,True,bank)
        ):
            if name=="learned" and chosen=="compact":
                result=arms["marked"]
            else:
                result=solver.search(selected,radius,action,inventory,maximum=450,orbit=orbit)
            arms[name]=result
        receivers.append(dict(radius=radius,policy=chosen,arms=arms))
        print("receiver",radius,chosen,{a:(v["status"],v["stats"].get("states"),len(v["patch"] or ()),
              v["stats"].get("mark_hits",0)) for a,v in arms.items()},flush=True)
    save("data/collars-v1.json",dict(status="SHAPE_ONLY_INVENTORY_AND_CHECKED_LOCAL_GROWTH",
         selected_pair=pair,selected_seed=selected,alternative=alternative,screen_radius=SCREEN_RADIUS,
         screened=screen,donors=list(donors.values()),training=episodes,policy=policy,receivers=receivers))


if __name__=="__main__":
    main()
