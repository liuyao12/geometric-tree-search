"""Audit the learned words, exact finite productions, and held-back Turtle patches."""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import add, save
from capped_orbits_v1 import candidate_inventory
from cluster_v1 import Model, load, mat
from collar_audit_v1 import Audit, exposed, freeze
from golden_geometry_v1 import area2
from scaffold_v1 import make


def cycles(edges):
    out=dict(edges)
    assert len(out)==len(edges) and set(out)==set(out.values())
    result=[]
    while out:
        a=min(out)
        p=a
        ring=[]
        while True:
            q=out.pop(p)
            ring.append((p,q))
            p=q
            if p==a:
                break
        result.append(tuple(ring))
    return tuple(result)


def signed(ring):
    return sum(a*d-b*c for (a,b),(c,d) in ring)


def verify_patch(audit,patch):
    assert tuple(sorted(set(patch)))==patch
    buckets=defaultdict(list)
    pairs=0
    for i,(g,x,y) in enumerate(patch):
        a,b,c,d=audit.box[g]
        keys=[(j,k) for j in range((a+x)//8,(b+x)//8+1)
               for k in range((c+y)//8,(d+y)//8+1)]
        prior=set().union(*(set(buckets[key]) for key in keys))
        for j in prior:
            assert not audit.overlap(patch[j],patch[i])
        pairs+=len(prior)
        for key in keys:
            buckets[key].append(i)
    border=exposed(audit.model.poly(t) for t in patch)
    ring,=cycles(border)
    assert signed(ring)>0 and signed(ring)==len(patch)*area2(audit.model.polygons[0])
    return dict(tiles=len(patch),perimeter=len(border),candidate_tile_pairs=pairs)


def verify_pieces(row,audit):
    patch=row["patch"]
    pieces=row["pieces"]
    assert tuple(sorted(t for part in pieces for t in part))==patch
    receipt=verify_patch(audit,patch)
    assert receipt["perimeter"]==row["perimeter"]
    return receipt


def verify_cavities(row,audit,small):
    frame=row["core"]["pieces"]
    boundary=exposed(audit.model.poly(t) for p in frame for t in p)
    holes={frozenset((b,a) for a,b in e) for e in cycles(boundary) if signed(e)<0}
    caps=row["caps"]
    assert len(holes)==len(caps)>0
    assert all(audit.geom.normalize(p)==audit.geom.normalize(small) for p in caps)
    assert holes=={frozenset(exposed(audit.model.poly(t) for t in p)) for p in caps}
    return len(holes)


def strip_positions(row,alphabet,model,turn):
    d=mat(model.groups[turn],alphabet["stride"])
    assert d==row["stride"]
    letters=tuple(model.action(turn,t) for t in alphabet["letters"])
    sites=[]
    for i,k in enumerate(row["word"],row["first"]):
        g,x,y=letters[k]
        at=add(row["lane"],(x+i*d[0],y+i*d[1]))
        sites.append((g,*at))
    return tuple(sites),d,letters


def verify_strip(row,alphabet,audit,turn):
    strip,d,letters=strip_positions(row,alphabet,audit.model,turn)
    assert strip==row["pieces"][-2]
    assert tuple(sorted(row["pieces"][-1]))==audit.geom.moved(strip,audit.geom.rot2)
    assert all(not audit.overlap(a,b) for a,b in zip(strip,strip[1:]))
    return d,letters


def altered_letter(row,alphabet,audit):
    _,d,letters=strip_positions(row,alphabet,audit.model,row["phase"])
    frame=tuple(t for part in row["pieces"][:-2] for t in part)
    for j,k in enumerate(row["word"]):
        i=row["first"]+j
        g,x,y=letters[1-k]
        t=(g,*add(row["lane"],(x+i*d[0],y+i*d[1])))
        for q in frame:
            if audit.overlap(t,q):
                point=min(audit.geom.atoms(t)&audit.geom.atoms(q))
                return dict(letter=j,original=k,replacement=1-k,tile=t,blocker=q,sample=point,
                            scale=audit.model.scale,neighbors=row["pieces"][-2][max(0,j-2):j+3])
    raise AssertionError("Expected a flipped-letter collision in the tested frame")


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    audit=Audit(model)
    geom=audit.geom
    s,recovered=make()
    alphabet=recovered["alphabet"]
    half=freeze(load("data/strip-fit-v1.json"))
    full=freeze(load("data/strip-fit-all-v1.json"))
    assert half["assemblies"]==full["assemblies"]
    capped=freeze(load("data/capped-orbits-v1.json"))
    candidates=candidate_inventory(s,half["assemblies"])
    assert {x["id"]:x["recipe"] for x in candidates}=={x["id"]:x["recipe"] for x in capped["cases"]}
    for item in candidates:
        row=item["recipe"]
        verify_pieces(row,audit)
        verify_strip(row,alphabet,audit,row["turn"])
    t3=capped["cases"][0]
    p2=t3["recipe"]
    expected=Fraction(t3["best"]**2,len(t3["winners"][0]["patch"]))
    assert expected==Fraction(*t3["score"])
    for item in capped["cases"]:
        for row in item["winners"]:
            verify_pieces(row,audit)
        if item["winners"]:
            assert Fraction(item["best"]**2,len(item["winners"][0]["patch"]))>=expected
    promotion=freeze(load("data/word-promotion-v1.json"))
    t4=freeze(load("data/triangle-transfer-v1.json"))
    p4=freeze(load("data/frame-transfer-v1.json"))
    words=promotion["words"]
    assert words[2]==alphabet["word"] and words[4]==p2["word"]
    assert all(words[i]==words[i-1]+words[i-2] for i in range(2,len(words)))
    layered={}
    sets={"P2":(p2,),"T3":t3["winners"],"P3":promotion["assemblies"],
          "T4":t4["winners"],"P4":p4["assemblies"]}
    for label,rows in sets.items():
        layered[label]=[verify_pieces(row,audit) for row in rows]
        if label in ("P3","P4"):
            cap=recovered["seed"] if label=="P3" else recovered["parents"][0]["patch"]
            word=words[6 if label=="P3" else 8]
            for row in rows:
                assert row["word"] in (word,word[::-1])
                verify_strip(row,alphabet,audit,row["phase"])
                verify_cavities(row,audit,cap)
        print(label,layered[label][0],len(rows),flush=True)
    # Release the reference only after the independent replay of the generated geometry.
    ref=freeze(load("input/held-back-v1.json"))
    for label,rows in sets.items():
        reference=geom.normalize(ref[label]["patch"])
        assert all(geom.normalize(row["patch"])==reference for row in rows),label
    ranks=sorted((Fraction(len(geom.boundary(x["canonical"]))**2,len(x["canonical"])),x["id"]) for x in candidates)
    rank=next(i for i,(_,name) in enumerate(ranks,1) if name==t3["id"])
    save("data/audit-v1.json",dict(status="AUDITED_LEARNED_TURTLE_WORDS_AND_FINITE_PROMOTIONS",layers=layered,
        selected=t3["id"],standalone_rank=rank,halfturn_classes=len(candidates),
        strip_control=altered_letter(promotion["assemblies"][0],alphabet,audit),
        exact_polygon_tests=audit.counts["polygon_overlap_tests"]))
    print("selected",t3["id"],"standalone rank",rank,flush=True)


if __name__=="__main__":
    main()
