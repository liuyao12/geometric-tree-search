"""Use exact interface counts to skip dominated boundary-cycle checks."""
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from cluster_v1 import Model, load, mat
from mixed_orbits_v1 import Join, add, freeze, joined_border, oriented_variants, sub


def interface(a,b):
    reversed_edges=defaultdict(list)
    for c,d in b:
        reversed_edges[sub(c,d)].append(d)
    return Counter(sub(p,r) for p,q in a for r in reversed_edges[sub(q,p)])


def proposals(join,b):
    c=join.geom
    b1=c.moved(b,join.turn)
    b2=c.moved(b1,join.turn)
    edges=(c.boundary(b),c.boundary(b1),c.boundary(b2))
    aa=interface(join.edges_a,join.edges_a)
    ab=interface(join.edges_a,edges[0])
    bb=interface(edges[0],edges[1])
    forbid_ab=join.collisions.blocked(join.anchor,b)
    forbid_bb=join.collisions.blocked(b,b1)
    # Any connected cyclic contact graph contains an A-B edge. Another
    # cross phase or a same-kind contact determines the orbit translation.
    ab_ports=ab.keys()-forbid_ab
    aa_ports=aa.keys()-join.block_aa
    bb_ports=bb.keys()-forbid_bb
    coords={(s,sub(s,t)) for s in ab_ports for t in ab_ports if s!=t}
    coords.update((s,u) for s in ab_ports for u in aa_ports)
    coords.update((s,sub(sub(add(s,w),mat(join.matrix,s)),join.offset)) for s in ab_ports for w in bb_ports)
    total=3*(len(join.edges_a)+len(edges[0]))
    answers=[]
    for s,u in coords:
        _,v,x,y=join.phases(s,u)
        w=sub(x,s)
        t,z=sub(s,u),sub(s,v)
        if u in join.block_aa or w in forbid_bb or t in forbid_ab or z in forbid_ab:
            continue
        shared=aa[u]+bb[w]+ab[s]+ab[t]+ab[z]
        perimeter=total-6*shared
        assert perimeter>0
        answers.append((perimeter,s,u,v,x,y))
    return len(coords),sorted(answers),edges


def exact_bounds(deck,join):
    layers={}
    for row in deck["entries"]:
        patch=freeze(row["patch"])
        n=len(patch)
        stage=layers.setdefault(n,dict(best=None,winners=[],counts=Counter()))
        for i,b in enumerate(oriented_variants(join.geom,patch)):
            possible,ranked,edges=proposals(join,b)
            stage["counts"]["contact_assemblies"]+=possible
            stage["counts"]["disjoint"]+=len(ranked)
            for p,s,u,v,x,y in ranked:
                if stage["best"] is not None and p>stage["best"]:
                    break
                stage["counts"]["boundary_checks"]+=1
                border=joined_border(((join.edges_a,(0,0)),(join.edges_a,u),(join.edges_a,v),
                                      (edges[0],s),(edges[1],x),(edges[2],y)))
                if border is None:
                    continue
                assert len(border)==p
                if stage["best"] is None or p<stage["best"]:
                    stage["best"]=p
                    stage["winners"]=[]
                stage["winners"].append((row["id"],i,s,u))
        print(row["id"],n,stage["best"],stage["counts"]["boundary_checks"],flush=True)
    return layers


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    deck=load("input/recovered-bank-v1.json")
    join=Join(Geometry(model),freeze(deck["seed"]))
    bounds=exact_bounds(deck,join)
    ranked=[]
    for n,stage in bounds.items():
        if stage["best"] is not None:
            tiles=3*(len(join.anchor)+n)
            value=Fraction(stage["best"]**2,tiles)
            ranked.append((value,n))
    scores=[dict(size=n,value=(q.numerator,q.denominator)) for q,n in sorted(ranked)]
    save("data/port-score-v1.json",dict(status="CHECKED_COMPACTNESS_WITH_PORT_BOUNDS",
                                       layers=bounds,normalized_scores=scores))


if __name__=="__main__":
    main()
