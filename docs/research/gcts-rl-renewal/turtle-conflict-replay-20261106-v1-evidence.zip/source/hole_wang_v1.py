"""Translate the independently checked no-cover tree into Wang resolution."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from site_cover_study_v1 import audit_negative, cases, load, Region, setup
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate


DATA = ROOT / "wang/data"


def problem():
    g, _, _ = setup()
    request = next(r for r in cases(g) if r["id"] == "rotated-hole")
    result = next(r for r in frozen(load("data/results-v1.json")) if r["id"] == request["id"])
    assert result["rings"] == request["rings"]
    region = Region(g, request["rings"])
    proof = result["arms"]["batch"]["proof"]
    geometry_receipt = audit_negative(region, proof)
    nodes = []

    def add(tree, chosen):
        site, children = tree
        i = len(nodes)
        node = dict(site=site, chosen=chosen, children=[])
        nodes.append(node)
        for tile, subtree in children:
            node["children"].append(add(subtree, (*chosen, tile)))
        return i

    assert add(proof, ()) == 0 and len(nodes) == geometry_receipt["nodes"]

    def clause(i, node):
        return ((False, (f"N{i}",)), *((True, (f"N{j}",)) for j in node["children"]))

    sources = {f"branch-{i}": dict(id=f"branch-{i}", variables={}, clause=clause(i, node))
               for i, node in enumerate(nodes)}
    sources["assume-cover"] = dict(id="assume-cover", variables={}, clause=((True, ("N0",)),))
    return nodes, sources, geometry_receipt


def derive(nodes, sources):
    predicates = {f"N{i}": [] for i in range(len(nodes))}
    builder = Certificate(sources, {}, predicates, ["U"], {})
    outputs = {}
    for i in reversed(range(len(nodes))):
        current = builder.instance(f"branch-{i}", {})
        for child in nodes[i]["children"]:
            current = builder.resolve(current, outputs[child], (f"N{child}",))
        outputs[i] = current
    root = builder.instance("assume-cover", {})
    builder.resolve(root, outputs[0], ("N0",))
    return builder.lines


def check_records(proof, sources):
    assert proof and not proof[-1]["clause"]
    wires = {}
    calls = []
    for i, row in enumerate(proof):
        names, prefix, word = fragment(proof, i, sources, {})
        parsed = decoder.read(prefix, word + "!", require_empty=False)
        match(proof, i, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=i + 1, uses=0, rule=row["rule"]))
        assert (wire["prefix"], wire["word"]) == (prefix, word)
        wire["uses"] += 1
        calls.append(key)
    return wires, calls


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    nodes, sources, geometry_receipt = problem()
    proof_path, bank_path = DATA / "hole-proof-v1.json", DATA / "hole-bank-v1.json.gz"
    if rebuild:
        proof = frozen(derive(nodes, sources))
    else:
        proof = frozen(json.loads(proof_path.read_text()))
    wires, calls = check_records(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(geometry=geometry_receipt, wang_records=len(calls), **verify_bank(wires, bank))
    print(json.dumps(receipt, sort_keys=True), flush=True)
    receipt_path = DATA / "hole-receipt-v1.json"
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert receipt == json.loads(receipt_path.read_text())


if __name__ == "__main__":
    main()
