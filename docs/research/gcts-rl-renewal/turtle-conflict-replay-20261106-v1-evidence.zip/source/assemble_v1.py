"""Enumerate symmetric assemblies from the unmarked Turtle occupancy field."""
from collections import defaultdict
from functools import lru_cache
from itertools import pairwise
from math import gcd
from pathlib import Path
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from cluster_v1 import Model, load
from golden_geometry_v1 import add, area2, sub, transform

ROOT=Path(__file__).resolve().parents[1]
ROOT_TILE=(0,0,0)


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def steps(poly):
    signed=sum(x*v-y*u for (x,y),(u,v) in pairwise((*poly,poly[0])))
    if signed<0:
        poly=poly[::-1]
    for a,b in pairwise((*poly,poly[0])):
        x,y=sub(b,a)
        n=gcd(x,y)
        direction=x//n,y//n
        for _ in range(n):
            p=add(a,direction)
            yield a,p
            a=p


class Geometry:
    def __init__(self,model):
        self.model=model
        self.rot2,=(g for g,m in model.groups.items() if m==[[-1,0],[0,-1]])
        self.rot3=tuple(g for g in model.groups if g and model.compose[model.compose[g,g],g]==0)

    def moved(self,patch,g,shift=(0,0)):
        return transform(self.model,patch,g,shift)

    @lru_cache(maxsize=100000)
    def atoms(self,tile):
        return frozenset(self.model.support(tile))

    @lru_cache(maxsize=20000)
    def occupied(self,patch):
        atoms=frozenset().union(*(self.atoms(p) for p in patch))
        assert len(atoms)==240*len(patch)
        return atoms

    @lru_cache(maxsize=20000)
    def boundary(self,patch):
        exposed=set()
        for tile in patch:
            for a,b in steps(self.model.poly(tile)):
                if (b,a) in exposed:
                    exposed.remove((b,a))
                else:
                    assert (a,b) not in exposed
                    exposed.add((a,b))
        return frozenset(exposed)

    @lru_cache(maxsize=20000)
    def normalize(self,patch):
        keys=[]
        for g in self.model.groups:
            turned=self.moved(patch,g)
            x,y=min((x,y) for _,x,y in turned)
            keys.append(tuple(sorted((g,a-x,b-y) for g,a,b in turned)))
        return min(keys)

    def poses(self,a,b):
        indexed=defaultdict(list)
        for p,q in self.boundary(b):
            indexed[sub(p,q)].append(q)
        return {sub(p,t) for p,q in self.boundary(a) for t in indexed[sub(q,p)]}

    def ring(self,patch):
        edges=self.boundary(patch)
        outgoing={}
        incoming={}
        for a,b in edges:
            if a in outgoing or b in incoming:
                return None
            outgoing[a]=b
            incoming[b]=a
        start=min(outgoing)
        ring=[start]
        node=outgoing.pop(start)
        while node!=start:
            ring.append(node)
            node=outgoing.pop(node)
        if outgoing:
            return None
        assert area2(tuple(ring))==len(patch)*area2(self.model.polygons[0])
        return tuple(ring)

    def overlaps(self,a,b):
        return bool(self.occupied(a)&self.occupied(b))

    def doublets(self):
        root=(ROOT_TILE,)
        groups={}
        considered=0
        for g in self.model.groups:
            proto=((g,0,0),)
            for x,y in sorted(self.poses(root,proto)):
                considered+=1
                other=((g,x,y),)
                if self.overlaps(root,other):
                    continue
                p=tuple(sorted((*root,*other)))
                groups[self.normalize(p)]=None
        pairs=sorted(groups)
        halves=[]
        for p in pairs:
            r=self.moved(p,self.rot2)
            x,y=min((x,y) for _,x,y in p)
            u,v=min((x,y) for _,x,y in r)
            if self.moved(r,0,(x-u,y-v))==p:
                halves.append(p)
        return pairs,halves,considered

    def triples(self,base):
        trials=0
        out={}
        for r in self.rot3:
            other=self.moved(base,r)
            for shift in sorted(self.poses(base,other)):
                trials+=1
                b=self.moved(other,0,shift)
                if self.overlaps(base,b):
                    continue
                c=self.moved(b,r,shift)
                if self.overlaps(base,c) or self.overlaps(b,c):
                    continue
                assert self.moved(c,r,shift)==base
                tiles=tuple(sorted((*base,*b,*c)))
                key=self.normalize(tiles)
                if key not in out:
                    out[key]=dict(patch=tiles,pairs=(base,b,c),rotation=r,shift=shift,
                                  perimeter=len(self.boundary(tiles)),ring=self.ring(tiles))
        return out,trials


def main():
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    pairs,halves,checks=geom.doublets()
    rows=[]
    for patch in halves:
        answers,probes=geom.triples(patch)
        rows.append(dict(pair=patch,pair_boundary=len(geom.boundary(patch)),trials=probes,
                         assemblies=[dict(key=k,**a) for k,a in sorted(answers.items())]))
    save("data/assemblies-v1.json",dict(status="EXHAUSTED_SHAPE_ONLY_ORBITS",contact_probes=checks,
         pairs=pairs,half_turns=rows,third_turns=geom.rot3))
    print(len(pairs),len(halves),checks,[(len(a["assemblies"]),a["pair_boundary"]) for a in rows])


if __name__=="__main__":
    main()
