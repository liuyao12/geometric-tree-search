"""Compile audited Turtle conflict clauses into the shared Wang checker."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from conflict_study_v1 import audit_conflicts
from opaque_replay_v1 import build_bank, verify_bank
from schematic_capsules_v1 import encoded, frozen
from site_cover_study_v1 import Region, cases, load, setup
from study_v1 import Certificate
from transfer_wang_v1 import prepare


DATA = ROOT / "wang/data"


def problem():
    g, _, _ = setup()
    fixture = next(row for row in cases(g) if row["id"] == "rotated-hole")
    region = Region(g, fixture["rings"])
    answer = frozen(load("data/rotated-hole-core-v1.json"))
    geometry = audit_conflicts(region, answer)
    assert answer["status"] == "NEGATIVE"
    rows, root = answer["proof"], answer["root"]
    reachable, todo = set(), [root]
    while todo:
        j = todo.pop()
        if j not in reachable:
            reachable.add(j)
            todo.extend(k for _, k in rows[j]["children"])
    tiles = sorted({tile for j in reachable for tile in rows[j]["core"]})
    names = {tile: "T" + str(i) for i, tile in enumerate(tiles, 1)}
    sources = {}
    for j in sorted(reachable):
        row = rows[j]
        clause = tuple((False, (names[t],)) for t in row["core"])
        clause += tuple((True, (names[t],)) for t, _ in row["children"])
        key = "site-" + str(j)
        sources[key] = dict(id=key, variables={}, clause=clause)
    return rows, sorted(reachable), names, sources, geometry


def derive(rows, reachable, names, sources):
    b = Certificate(sources, {}, {name: [] for name in names.values()}, ["U"], {})
    conclusions = {}
    for j in reachable:
        ref = b.instance("site-" + str(j), {})
        for tile, child in rows[j]["children"]:
            ref = b.resolve(ref, conclusions[child], (names[tile],))
        conclusions[j] = ref
        expected = {(False, (names[t],)) for t in rows[j]["core"]}
        assert set(b.lines[ref]["clause"]) == expected
    assert not b.lines[-1]["clause"]
    return b.lines


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    rows, reachable, names, sources, geometry = problem()
    proof_path, bank_path = DATA / "core-proof-v1.json", DATA / "core-bank-v1.json.gz"
    expected = frozen(derive(rows, reachable, names, sources))
    proof = expected if rebuild else frozen(json.loads(proof_path.read_text()))
    assert proof == expected
    wires, calls = prepare(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(records=len(calls), inputs=len(sources), tiles={n: t for t, n in names.items()},
                   reachable=reachable, geometry=geometry, **verify_bank(wires, bank))
    receipt_path = DATA / "core-receipt-v1.json"
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert json.loads(encoded(receipt)) == json.loads(receipt_path.read_text())
    print(json.dumps({k: v for k, v in receipt.items() if k != "tiles"}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
