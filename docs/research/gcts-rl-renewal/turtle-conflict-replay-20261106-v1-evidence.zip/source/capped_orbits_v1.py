"""Test candidate half-turn motifs in the next triangular context."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import add, save, sub
from cluster_v1 import load, mat
from collar_audit_v1 import freeze
from mixed_orbits_v1 import joined_border, shift
from scaffold_v1 import centred, make


def variants(s,patch):
    p={s.geom.moved(patch,g) for g in s.model.groups}
    return tuple(sorted(p))


def candidate_inventory(s,records):
    families={}
    for row in records:
        k=s.geom.normalize(row["patch"])
        families.setdefault(k,row)
    return tuple(dict(id=f"C{i:02}",canonical=centred(s.geom,k),recipe=r)
                 for i,(k,r) in enumerate(families.items()))


def capped(s,a,c,b):
    geom=s.geom
    rotation=s.geom.rot3[0]
    m=s.model.groups[rotation]
    rotations=(0,rotation,s.model.compose[rotation,rotation])
    a_poses=variants(s,a)
    a_cache={}
    for x in a_poses:
        _,aa=s.ports(x,x)
        _,ca=s.ports(c,x)
        a_cache[x]=(aa,ca)
        assert all(geom.moved(x,g)==x for g in rotations)
    assert all(geom.moved(c,g)==c for g in rotations)
    stats=Counter()
    best=None
    winners={}
    for j,y in enumerate(variants(s,b)):
        y1=geom.moved(y,rotation)
        y2=geom.moved(y1,rotation)
        bc_edges,bc_bad=s.ports(c,y)
        bb_edges,bb_bad=s.ports(y,y1)
        anchors=[]
        for p in sorted(bc_edges.keys()-bc_bad):
            stats["cap_ports"]+=1
            pp=mat(m,p)
            delta=sub(pp,p)
            if delta in bb_bad:
                stats["middle_collision"]+=1
                continue
            if not bb_edges[delta]:
                stats["missing_middle_seam"]+=1
                continue
            ppp=mat(m,pp)
            anchors.append((p,pp,ppp,bc_edges[p],bb_edges[delta]))
        for i,x in enumerate(a_poses):
            ba_edges,ba_bad=s.ports(y,x)
            aa_bad,ca_bad=a_cache[x]
            aa_edges,_=s.ports(x,x)
            ca_edges,_=s.ports(c,x)
            ports=sorted(ba_edges.keys()-ba_bad)
            initial=len(geom.boundary(c))+3*(len(geom.boundary(x))+len(geom.boundary(y)))
            for p,pp,ppp,nc,nb in anchors:
                for t in ports:
                    q=add(p,t)
                    qq=mat(m,q)
                    qqq=mat(m,qq)
                    stats["outer_proposals"]+=1
                    if q in ca_bad or sub(qq,q) in aa_bad or sub(qq,p) in ba_bad or sub(qqq,p) in ba_bad:
                        stats["outer_collision"]+=1
                        continue
                    if ca_edges[q] or aa_edges[sub(qq,q)] or ba_edges[sub(qq,p)] or ba_edges[sub(qqq,p)]:
                        stats["unwanted_contacts"]+=1
                        continue
                    stats["disjoint"]+=1
                    score=initial-6*(nc+nb+ba_edges[t])
                    if best is not None and score>best:
                        continue
                    stats["boundary_checks"]+=1
                    outline=joined_border(((geom.boundary(c),(0,0)),
                                           (geom.boundary(y),p),(geom.boundary(y1),pp),(geom.boundary(y2),ppp),
                                           (geom.boundary(x),q),(geom.boundary(x),qq),(geom.boundary(x),qqq)))
                    if outline is None:
                        continue
                    assert len(outline)==score
                    pieces=(c,shift(y,p),shift(y1,pp),shift(y2,ppp),shift(x,q),shift(x,qq),shift(x,qqq))
                    patch=tuple(sorted(v for part in pieces for v in part))
                    if best is None or score<best:
                        best=score
                        winners={}
                    winners.setdefault(patch,dict(patch=patch,pieces=pieces,anchors=(i,j,p,q),
                                       seams=(nc,nb,ba_edges[t]),perimeter=score))
    return dict(stats=stats,best=best,winners=list(winners.values()))


def main():
    s,recovered=make()
    before=freeze(load("data/strip-fit-v1.json"))["assemblies"]
    candidates=candidate_inventory(s,before)
    a=centred(s.geom,recovered["parents"][0]["patch"])
    c=s.triangle
    table=[]
    for item in candidates:
        out=capped(s,a,c,item["canonical"])
        score=None
        if out["winners"]:
            n=len(out["winners"][0]["patch"])
            value=Fraction(out["best"]**2,n)
            score=(value.numerator,value.denominator)
        table.append(dict(**item,**out,score=score))
        print(item["id"],len(item["canonical"]),out["best"],len(out["winners"]),out["stats"],flush=True)
    table.sort(key=lambda r:(r["score"] is None,Fraction(*r["score"]) if r["score"] else 0,r["id"]))
    save("data/capped-orbits-v1.json",dict(status="SEARCHED_CAPPED_THREEFOLD_PRODUCTIONS",seed=a,cap=c,cases=table))


if __name__=="__main__":
    main()
