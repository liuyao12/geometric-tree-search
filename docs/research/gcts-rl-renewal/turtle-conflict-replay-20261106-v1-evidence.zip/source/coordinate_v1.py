"""Infer centered placements from recovered productions, then construct a new level."""
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save, sub
from cluster_v1 import Model, load, mat
from collar_audit_v1 import Audit, freeze
from layer_audit_v1 import verify_patch
from mixed_orbits_v1 import shift
from scaffold_v1 import center, centred, negate, orientation
from word_promotion_v1 import infer


def read_inputs():
    old=freeze(load("input/recovered-production-v1.json"))
    second=freeze(load("input/capped-orbits-v1.json"))["cases"][0]
    third=freeze(load("input/word-promotion-v1.json"))["assemblies"][0]
    fourth=freeze(load("input/frame-transfer-v1.json"))["assemblies"][0]
    t4=freeze(load("input/triangle-transfer-v1.json"))["winners"][0]
    p=[dict(patch=old["doublet"]),
       dict(patch=old["motif"],pieces=(*old["motif_pairs"],*old["strips"]),word=old["alphabet"]["word"]),
       second["recipe"],third,fourth]
    t=[None,dict(patch=old["seed"],pieces=old["seed_pairs"]),old["parents"][0],second["winners"][0],t4]
    return old["alphabet"],p,t


def strip(alphabet,word):
    dx,dy=alphabet["stride"]
    return tuple(sorted((g,x+i*dx,y+i*dy) for i,k in enumerate(word)
                        for g,x,y in [alphabet["letters"][k]]))


def p_frame(geom,row,alphabet):
    standard=strip(alphabet,row["word"])
    for turn in geom.model.groups:
        patch=geom.moved(row["patch"],turn)
        origin=negate(center(geom,patch))
        for path in row["pieces"][-2:]:
            placed=geom.moved(path,turn,origin)
            anchor=sub(min(v[1:] for v in placed),min(v[1:] for v in standard))
            if shift(standard,anchor)==placed:
                return shift(patch,origin),tuple(geom.moved(p,turn,origin) for p in row["pieces"]),anchor
    raise AssertionError("strip cannot anchor recovered half-turn frame")


def t_frame(geom,row,mid):
    models=[]
    for turn in geom.model.groups:
        origin=negate(center(geom,geom.moved(row["patch"],turn)))
        parts=tuple(geom.moved(p,turn,origin) for p in row["pieces"])
        for p in parts:
            if len(p)!=len(mid):
                continue
            x,y=center(geom,p)
            if x>0 and y>0 and geom.moved(mid,4,(x,y))==p:
                models.append((geom.moved(row["patch"],turn,origin),tuple(sorted(parts))))
    model,=set(models)
    return model


def fit(rows,constant=False):
    dimension=3 if constant else 2
    matrix=[]
    for current,previous,point in rows[:dimension]:
        basis=(1,current,previous) if constant else (current,previous)
        matrix.append(list(map(Fraction,(*basis,*point))))
    assert len(matrix)==dimension
    for i in range(dimension):
        j=next(j for j in range(i,dimension) if matrix[j][i])
        matrix[i],matrix[j]=matrix[j],matrix[i]
        matrix[i]=[x/matrix[i][i] for x in matrix[i]]
        for j in range(dimension):
            if j!=i:
                k=matrix[j][i]
                matrix[j]=[u-k*v for u,v in zip(matrix[j],matrix[i],strict=True)]
    coefficients=tuple(tuple(row[-2:]) for row in matrix)
    assert all(x.denominator==1 for row in coefficients for x in row)
    coeff=tuple(tuple(int(x) for x in row) for row in coefficients)
    if not constant:
        coeff=((0,0),*coeff)
    assert all(evaluate(coeff,a,b)==p for a,b,p in rows)
    return dict(coefficients=coeff,training=dimension,checked=len(rows))


def evaluate(coeff,a,b):
    return tuple(c+x*a+y*b for c,x,y in zip(*coeff,strict=True))


def fit_rule(geom,alphabet,p_rows,t_rows):
    words=infer(p_rows[1]["word"],p_rows[2]["word"],rounds=10)
    lengths=[len(w) for w in words[::2]]
    p=[centred(geom,p_rows[0]["patch"])]
    t=[()]
    known_parts={}
    placements=defaultdict(list)
    orientations=defaultdict(set)

    def observe(name,i,part,prototype=None):
        point=center(geom,part) if prototype else part
        placements[name].append((lengths[i],lengths[i-1],point))
        if prototype:
            orientations[name].add(orientation(geom,prototype,part))

    for i,row in enumerate(p_rows[1:],1):
        patch,parts,anchor=p_frame(geom,row,alphabet)
        known_parts["P",i]=tuple(sorted(parts))
        motifs={center(geom,part):part for part in parts[:5]}
        p.append(patch)
        observe("strip",i,anchor)
        for role,point in (("p_center",(0,0)),
                           ("p_arm",next((x,y) for x,y in motifs if x>0 and y>0)),
                           ("p_side",next((x,y) for x,y in motifs if x<0 and y>0))):
            observe(role,i,motifs[point],p[i-1])

    for i,row in enumerate(t_rows[1:],1):
        patch,parts=t_frame(geom,row,p[i-1])
        t.append(patch)
        known_parts["T",i]=parts
        mid,=(v for v in parts if len(v)==len(p[i-1]) and all(x>0 for x in center(geom,v)))
        observe("t_middle",i,mid,p[i-1])
        if i>=2:
            corner,=(v for v in parts if len(v)==len(t[i-1]) and center(geom,v)[0]==0 and center(geom,v)[1]>0)
            observe("t_corner",i,corner,t[i-1])
        if i>=3:
            cap,=(v for v in parts if len(v)==len(t[i-2]) and center(geom,v)==(0,0))
            observe("t_cap",i,cap,t[i-2])

    for i,row in enumerate(p_rows[2:],2):
        _,parts,_=p_frame(geom,row,alphabet)
        corner,=(v for v in parts[5:-2] if len(v)==len(t[i-1]) and all(x>0 for x in center(geom,v)))
        observe("p_corner",i,corner,t[i-1])
        if i>=3:
            cap,=(v for v in parts[5:-2] if len(v)==len(t[i-2]) and all(x>0 for x in center(geom,v)))
            observe("p_cap",i,cap,t[i-2])

    roles={name:dict(**fit(rows,name=="strip"),points=rows) for name,rows in placements.items()}
    for name,turns in orientations.items():
        turn,=turns
        roles[name]["turn"]=turn
    return dict(words=words,lengths=lengths,roles=roles,bases={"P0":p[0],"T1":t[1]}),p,t,known_parts


def children(model,rule,kind,n,a,b):
    roles=rule["roles"]

    def address(role,label,level):
        slot=roles[role]
        return label,level,slot.get("turn",0),evaluate(slot["coefficients"],a,b)

    def orbit(row,turns):
        label,level,g,point=row
        return [(label,level,model.compose[r,g],mat(model.groups[r],point)) for r in turns]

    if kind=="T":
        rows=orbit(address("t_middle","P",n-1),(0,3,4))
        if n>=2:
            rows+=orbit(address("t_corner","T",n-1),(0,3,4))
        if n>=3:
            rows.append(address("t_cap","T",n-2))
        return rows
    rows=[address("p_center","P",n-1)]
    for key,label,level in (("p_arm","P",n-1),("p_side","P",n-1),("strip","S",n),
                            ("p_corner","T",n-1),("p_cap","T",n-2)):
        if label!="T" or level>=1:
            rows+=orbit(address(key,label,level),(0,6))
    return rows


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    geom=Geometry(model)
    alphabet,p_rows,t_rows=read_inputs()
    rule,known_p,known_t,known_parts=fit_rule(geom,alphabet,p_rows,t_rows)
    library={("P",0):rule["bases"]["P0"],("T",1):rule["bases"]["T1"]}
    audit=Audit(model)
    levels={}
    patches={}
    for n,word in enumerate(rule["words"][2::2],1):
        a,b=rule["lengths"][n],rule["lengths"][n-1]
        library["S",n]=strip(alphabet,word)
        for kind,known in (("T",known_t),("P",known_p)):
            rows=children(model,rule,kind,n,a,b)
            placed=[geom.moved(library[k,i],g,xy) for k,i,g,xy in rows]
            patch=tuple(sorted(t for part in placed for t in part))
            if n<len(known):
                assert patch==known[n],(kind,n)
                assert tuple(sorted(placed))==known_parts[kind,n],(kind,n)
            library[kind,n]=patch
            name=f"{kind}{n}"
            levels[name]=dict(children=rows,**verify_patch(audit,patch))
            if n>=len(known):
                patches[name]=patch
            print(name,levels[name]["tiles"],levels[name]["perimeter"],flush=True)
    save("data/coordinate-v1.json",dict(status="CHECKED_DIRECT_COORDINATE_TRANSFER",rule=rule,levels=levels))
    save("data/predictions-v1.json",patches)


if __name__=="__main__":
    main()
