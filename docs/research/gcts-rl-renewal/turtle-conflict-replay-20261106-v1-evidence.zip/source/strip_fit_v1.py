"""Transfer exact receptors and synthesize finite strips from the open seams."""
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import add, save, sub
from cluster_v1 import load, mat
from collar_audit_v1 import freeze
from mixed_orbits_v1 import joined_border, shift
from scaffold_v1 import center, centred, contacts, make, negate
from port_score_v1 import interface


def receptor_bank(s,recovered):
    """Extract poses of a triangular cluster in the frame of a docked motif."""
    geom=s.geom
    raw=recovered["parents"][0]["pieces"]
    triangles=raw[:3]
    motifs=raw[3:]
    bank=set()
    for motif in motifs:
        target=center(geom,motif)
        a,=tuple(p for p in triangles if contacts(geom,p,motif))
        for g in geom.model.groups:
            if geom.moved(centred(geom,motif),g)!=s.big:
                continue
            inverse=geom.moved(shift(a,negate(target)),g)
            bank.add(inverse)
    assert bank
    return tuple(sorted(bank))


def attach(s,core,bank):
    geom=s.geom
    chosen=core[1]
    at=center(geom,chosen)
    family=centred(geom,chosen)
    options=set()
    for g in geom.model.groups:
        if geom.moved(s.big,g)==family:
            options.update(geom.moved(b,g,at) for b in bank)
    for triangle in sorted(options):
        partner=geom.moved(triangle,geom.rot2)
        both=(*core,triangle,partner)
        if sum(map(len,both))>1500:
            hits=overlap(s,triangle,partner) or any(overlap(s,a,b) for a in (triangle,partner) for b in core)
            if hits:
                continue
        else:
            support=set()
            for part in both:
                field=geom.occupied(part)
                if not support.isdisjoint(field):
                    break
                support.update(field)
            else:
                if tuple(i for i,p in enumerate(core) if contacts(geom,triangle,p))==(1,):
                    yield both
            continue
        if tuple(i for i,p in enumerate(core) if contacts(geom,triangle,p))==(1,):
            yield both


def overlap(s,a,b):
    p,q=(center(s.geom,part) for part in (a,b))
    left=shift(a,negate(p))
    right=shift(b,negate(q))
    return sub(q,p) in s.ports(left,right)[1]


def lane(p,d):
    axis=0 if d[0] else 1
    k=p[axis]//d[axis]
    return sub(p,(k*d[0],k*d[1])),k


def split_path(points):
    block=[]
    for k in sorted(points):
        if block and k!=block[-1]+1:
            yield block
            block=[]
        block.append(k)
    if block:
        yield block


def possible_letters(s,frame,turn):
    geom=s.geom
    d=mat(s.model.groups[turn],s.strip["stride"])
    letters=tuple(s.model.action(turn,t) for t in s.strip["letters"])
    allowed=frozenset((*s.strip_roles,5))
    # Half-turn partners of the three roles in the old scaffold.
    flip={0:0,1:3,2:4,3:1,4:2,5:6,6:5}
    opposite={flip[i] for i in allowed}
    edge_sets=[geom.boundary(part) for part in frame]
    complete=tuple(sorted(t for part in frame for t in part))
    lanes=defaultdict(lambda:defaultdict(dict))
    for i,(g,x,y) in enumerate(letters):
        single=((g,0,0),)
        offsets=geom.poses(complete,single)-s.collision.blocked(complete,single)
        seams=[interface(e,geom.boundary(single)) for e in edge_sets]
        for p in sorted(offsets):
            roles={j for j,table in enumerate(seams) if table[p]}
            if not roles or not roles<=allowed:
                continue
            t=(g,*p)
            other,=geom.moved((t,),geom.rot2)
            if other==t:
                continue
            u,v=other[1:]
            if sub((u,v),p) in s.collision.base[g,other[0]]:
                continue
            iroles={flip[j] for j in roles}
            assert iroles<=opposite
            base,k=lane(sub(p,(x,y)),d)
            lanes[base][k][i]=(t,other,roles)
    return lanes,allowed,d


def search_strips(s,frame,turn):
    geom=s.geom
    lanes,required,stride=possible_letters(s,frame,turn)
    closed={}
    counts=Counter(lanes=len(lanes))
    frame_border=[(geom.boundary(part),(0,0)) for part in frame]
    for site,slots in sorted(lanes.items()):
        for sequence in split_path(slots):
            for first in range(len(sequence)):
                active=[]
                letters=[]
                def visit(j,seen):
                    if seen==required:
                        counts["full_contacts"]+=1
                        path=tuple(t for t,_ in active)
                        mirror=tuple(u for _,u in active)
                        outline=joined_border((*frame_border,(geom.boundary(path),(0,0)),
                                               (geom.boundary(mirror),(0,0))))
                        if outline:
                            counts["closed"]+=1
                            combined=(*frame,path,mirror)
                            patch=tuple(sorted(t for part in combined for t in part))
                            score=Fraction(len(outline)**2,len(patch))
                            closed.setdefault(patch,dict(patch=patch,pieces=combined,perimeter=len(outline),
                                word=tuple(letters),score=(score.numerator,score.denominator),turn=turn,
                                stride=stride,lane=site,first=sequence[first]))
                    if j==len(sequence):
                        return
                    k=sequence[j]
                    for letter,(t,other,roles) in sorted(slots[k].items()):
                        if any(sub(v[1:],t[1:]) in s.collision.base[t[0],v[0]]
                               or sub(other[1:],u[1:]) in s.collision.base[u[0],other[0]]
                               for u,v in active):
                            counts["strip_cross_collision"]+=1
                            continue
                        counts["letter_choices"]+=1
                        active.append((t,other))
                        letters.append(letter)
                        visit(j+1,seen|roles)
                        letters.pop()
                        active.pop()
                visit(first,set())
    return counts,closed


def fit(use_all=False):
    s,d=make()
    bank=receptor_bank(s,d)
    found={}
    breakdown=[]
    source=freeze(load("data/scaffolds-v1.json"))
    limit=max(c["score"] for r in source["phases"] for c in r["candidates"])
    for r in source["phases"]:
        for i,core in enumerate(r["candidates"]):
            if not use_all and core["score"]<limit:
                continue
            stats=Counter()
            for frame in attach(s,core["pieces"],bank):
                stats["receivers"]+=1
                for turn in s.model.groups:
                    counts,closed=search_strips(s,frame,turn)
                    stats.update(counts)
                    for p,result in closed.items():
                        found.setdefault(p,dict(phase=r["phase"],core_index=i,**result))
            breakdown.append(dict(phase=r["phase"],core_index=i,counts=stats))
    results=sorted(found.values(),key=lambda x:(Fraction(*x["score"]),x["patch"]))
    return dict(status="HALF_TURN_FRAME_STRIP_SEARCH",receptors=bank,core_filter="all" if use_all else "max-shared",
                best_core_score=limit,counts=breakdown,assemblies=results)


def main():
    result=fit()
    full=fit(True)
    assert result["assemblies"]==full["assemblies"]
    save("data/strip-fit-v1.json",result)
    save("data/strip-fit-all-v1.json",full)
    print("receptors",len(result["receptors"]), "assemblies",len(result["assemblies"]))
    for r in result["assemblies"][:12]:
        print(r["phase"],r["core_index"],len(r["patch"]),r["perimeter"],r["score"],r["word"],flush=True)


if __name__=="__main__":
    main()
