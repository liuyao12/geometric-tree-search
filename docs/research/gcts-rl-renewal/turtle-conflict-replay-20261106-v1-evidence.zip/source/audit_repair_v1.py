"""Independently check the successful covers and each released seed commitment."""
from copy import deepcopy
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from boundary_search_v1 import remove
from collar_audit_v1 import Audit, exposed
from geometry_v1 import chain, sub
from layer_audit_v1 import verify_patch
from repair_v1 import Region, atlas_seed, freeze, load, setup
from study_repair_v1 import write


def check_cover(g, audit, region, patch):
    patch = tuple(sorted(patch))
    receipt = verify_patch(audit, patch)
    assert exposed(g.model.poly(t) for t in patch) == set(region.edges)
    assert receipt["tiles"] == region.counts[0]
    return receipt


def anchor_options(g, edge):
    a, b = edge
    return {g.shift(tile, sub(a, p)) for tile in g.bases for p, q in g.boundary(tile)
            if sub(q, p) == sub(b, a)}


def check_marks(g, audit, region, retained, answer):
    working = set(retained)
    scale = g.model.scale
    checked = 0
    for item in answer["marks"]:
        edge = item["edge"]
        residual = remove(region.edges, chain(g, working))
        assert edge in residual
        entries = item["options"]
        assert {p for p, _, _ in entries} == anchor_options(g, edge)
        assert len(entries) == len({p for p, _, _ in entries})
        choices = []
        for candidate, outside, blockers in entries:
            sites = g.sites(candidate)
            if outside:
                kind, point = outside
                assert kind == "site" and point in sites
                winding = [g.wind(r, point, scale) for r in region.rings]
                assert None not in winding and sum(winding) == 0
                assert not blockers
            else:
                assert sites <= region.sites and blockers
                expected = {t for t in working if g.sites(t) & sites}
                assert {t for t, _ in blockers} == expected
                for tile, point in blockers:
                    assert point in sites & g.sites(tile)
                    assert audit.overlap(tile, candidate)
                choices.append(tuple(t for t, _ in blockers))
            checked += 1
        released = item["release"]
        if choices:
            assert released == min(choices, key=lambda ts: (len(ts), ts))
        else:
            assert len(released) == 1 and edge[::-1] in g.boundary(released[0])
        assert released and set(released) <= working
        working.difference_update(released)
    assert tuple(sorted(working)) == answer["seed"]
    return checked


def main():
    g, atlas, _ = setup()
    audit = Audit(g.model)
    cases = {row["id"]: row for row in freeze(load("input/cases-v1.json"))}
    results = freeze(load("data/results-v1.json"))
    checks = []
    rejected = 0
    for row in results:
        source = cases[row["id"]]
        region = Region(g, source["rings"])
        generator = check_cover(g, audit, region, source["construction"])
        whole, collar, preflight = atlas_seed(g, atlas, region)
        if row["kind"] == "trap":
            hidden = set(source["construction"])
            assert set(whole)-hidden
        methods = {}
        for name, answer in row["arms"].items():
            checks_here = check_marks(g, audit, region, whole, answer) if "marks" in answer else 0
            if row["id"] == "repair-15" and name == "marked":
                altered = deepcopy(answer)
                first, *rest = altered["marks"]
                altered["marks"] = ({**first, "options": first["options"][1:]}, *rest)
                try:
                    check_marks(g, audit, region, whole, altered)
                except AssertionError:
                    rejected += 1
                else:
                    raise AssertionError("Accepted an incomplete anchored catalogue")
            if answer["action"] == "all":
                assert answer["seed"] == whole
            if answer["action"] == "collar":
                assert answer["seed"] == collar
            if answer["action"] != "direct":
                assert answer["preflight"] == preflight
            if answer["status"] == "POSITIVE":
                receipt = check_cover(g, audit, region, answer["patch"])
                if answer["repair"] == "POSITIVE":
                    assert set(answer["seed"]) <= set(answer["patch"])
                methods[name] = {**receipt, "marked_candidate_checks": checks_here}
            else:
                assert answer["status"] == "BOUNDED"
                methods[name] = dict(marked_candidate_checks=checks_here)
        checks.append(dict(id=row["id"], construction=generator, methods=methods))
    write("data/audit-v1.json", checks)
    assert rejected == 1
    print("Checked", sum("tiles" in v for r in checks for v in r["methods"].values()),
          "returned covers and",
          sum(v["marked_candidate_checks"] for r in checks for v in r["methods"].values()),
          "candidate exclusions. Rejected the incomplete catalogue control.")


if __name__ == "__main__":
    main()
