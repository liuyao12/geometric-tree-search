"""Propagate exact conflicts shared by every option at an uncovered site."""
from collections import Counter
from functools import reduce
from operator import or_

from site_cover_v1 import bits, translation


def low_domains(board, residue, wanted, active, threshold=2):
    """Return masks of sites with zero, one, or at most threshold supports."""
    levels = [0] * (threshold + 1)
    for h, poses in enumerate(active):
        if not poses:
            continue
        for delta in board.offset_ids[h][residue]:
            cover = (poses << delta) & wanted
            for i in range(threshold, 0, -1):
                levels[i] |= levels[i - 1] & cover
            levels[0] |= cover
    return (wanted & ~levels[0], *(a & ~b for a, b in zip(levels, levels[1:])))


def conflicts(board, pose):
    h, i = pose
    return tuple(translation(mask, start + i) for mask, start in board.conflicts[h])


def common_blockers(board, options, active):
    """Remove rows conflicting with all alternatives, except alternatives themselves."""
    shared = list(active)
    for pose in options:
        for h, mask in enumerate(conflicts(board, pose)):
            shared[h] &= mask
    for h, i in options:
        shared[h] &= ~(1 << i)
    return tuple(shared)


def component_remainder(board, wanted, tile_sites):
    pending = reduce(or_, wanted)
    while pending:
        seen = fringe = pending & -pending
        while fringe:
            near = (fringe << 1) | (fringe >> 1) | (fringe << board.width) | (fringe >> board.width)
            fringe = near & pending & ~seen
            seen |= fringe
        if sum((part & seen).bit_count() for part in wanted) % tile_sites:
            return seen
        pending &= ~seen
    return 0


def run(board, limit, mode="support", width=2, proposal_cap=12, components=False):
    """Use global small domains and optional shared-conflict elimination."""
    assert mode in ("global", "support")
    counts = Counter()
    residues = tuple(range(len(board.wanted)))
    placed = []
    selected_marks = []
    witness = None
    tile_sites = len(board.g.sites(board.g.bases[0]))

    def charge_pose(pose, want, active):
        counts["placements"] += 1
        return board.apply(pose, want, active)

    def sites(want, active):
        forced = {}
        small = []
        for r in residues[:width]:
            if not want[r]:
                continue
            counts["sweeps"] += 1
            zero, one, two = low_domains(board, r, want[r], active)
            if zero:
                return next(((r, i) for i in bits(zero))), None, None
            if one:
                for pose, i in board.forced_poses(r, one, active):
                    forced.setdefault(pose, (r, i))
            if len(small) < proposal_cap:
                for i in bits(two):
                    small.append((r, i))
                    if len(small) == proposal_cap:
                        break
        return None, forced, small

    def sampled(want, active):
        best = None
        for r in residues:
            if want[r]:
                i = next(bits(want[r]))
                domain = tuple(board.choose(r, i, active))
                if best is None or len(domain) < len(best[2]):
                    best = r, i, domain
        return best

    def recurse(want, active):
        nonlocal witness
        counts["nodes"] += 1
        if counts["nodes"] > limit:
            raise TimeoutError
        if not any(want):
            witness = tuple(selected_marks)
            return tuple(placed)
        start = len(placed)
        nmarks = len(selected_marks)
        try:
            for _ in range(12):
                if not any(want):
                    witness = tuple(selected_marks)
                    return tuple(placed)
                if components:
                    counts["component_checks"] += 1
                    if component_remainder(board, want, tile_sites):
                        counts["component_failures"] += 1
                        return None
                dead, forced, small = sites(want, active)
                if dead is not None:
                    counts["dead"] += 1
                    return None
                if forced:
                    counts["waves"] += 1
                    for pose, site in forced.items():
                        h, i = pose
                        if not (active[h] >> i) & 1:
                            counts["dead"] += 1
                            return None
                        want, active = charge_pose(pose, want, active)
                        placed.append(board.tile(pose))
                    continue
                if mode != "support" or not small:
                    break
                made = False
                visited = set()
                for r, i in small:
                    domain = tuple(board.choose(r, i, active))
                    if not domain:
                        counts["dead"] += 1
                        return None
                    if domain in visited:
                        continue
                    visited.add(domain)
                    if len(domain) == 1:
                        made = True
                        want, active = charge_pose(domain[0], want, active)
                        placed.append(board.tile(domain[0]))
                        break
                    lost = common_blockers(board, domain, active)
                    cut = sum(mask.bit_count() for mask in lost)
                    if cut:
                        counts["support_cuts"] += 1
                        counts["excluded"] += cut
                        selected_marks.append(dict(site=board.site(r, i),
                                                   choices=tuple(board.tile(t) for t in domain),
                                                   cut=cut, chosen=len(placed)))
                        active = tuple(a & ~b for a, b in zip(active, lost, strict=True))
                        made = True
                if not made:
                    break
            if not any(want):
                witness = tuple(selected_marks)
                return tuple(placed)
            fresh = next(((r, i) for r, i in small if (want[r] >> i) & 1), None)
            if fresh is not None:
                r, i = fresh
                domain = tuple(board.choose(r, i, active))
            else:
                r, i, domain = sampled(want, active)
            counts["branch_sites"] += 1
            for pose in domain:
                a, b = charge_pose(pose, want, active)
                placed.append(board.tile(pose))
                result = recurse(a, b)
                placed.pop()
                if result is not None:
                    return result
            return None
        finally:
            del placed[start:]
            del selected_marks[nmarks:]

    try:
        answer = recurse(board.wanted, board.initial)
    except (TimeoutError, RecursionError):
        return dict(status="BOUNDED", counts=dict(counts))
    return dict(status="POSITIVE" if answer is not None else "EXHAUSTED",
                counts=dict(counts), patch=answer, marks=witness)
