"""Freeze fixed outlines, train an ordering policy, and compare exact repairs."""
import argparse
from collections import defaultdict
from fractions import Fraction
import json
from pathlib import Path
from random import Random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from repair_v1 import ACTIONS, Region, atlas_seed, attempt_region, cases, context, freeze, load, setup, work

ROOT = Path(__file__).resolve().parents[1]


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def call(g, inv, row, preview, action, pays_preview=False):
    region = Region(g, row["rings"])
    answer = attempt_region(region, inv, row, action, preview)
    if action == "direct" and pays_preview:
        answer["preflight"] = preview[2]
    assert answer["status"] in ("POSITIVE", "BOUNDED"), (row["id"], action, answer["status"])
    return dict(**answer, work=work(answer))


def learn(g, atlas, inv, training):
    rng = Random(62217)
    logs, rewards = [], defaultdict(dict)
    episodes = list(training)*5
    rng.shuffle(episodes)
    for row in episodes:
        region = Region(g, row["rings"])
        preview = atlas_seed(g, atlas, region)
        total = region.counts[0]
        state = context(preview[2], total)
        options = rewards[state]
        untried = [a for a in ACTIONS if a not in options]
        explore = bool(untried) or rng.randrange(6) == 0
        action = rng.choice(untried or ACTIONS) if explore else max(
            options, key=lambda a: (sum(options[a])/len(options[a]), -ACTIONS.index(a)))
        answer = call(g, inv, row, preview, action, pays_preview=True)
        reward = -Fraction(answer["work"], total)
        if answer["status"] == "BOUNDED":
            reward -= 100
        options.setdefault(action, []).append(reward)
        logs.append(dict(id=row["id"], context=state, action=action, explore=explore,
                         reward=(reward.numerator, reward.denominator), status=answer["status"],
                         work=answer["work"]))
    policy = {}
    for state, options in rewards.items():
        policy[state] = max(options, key=lambda a: (sum(options[a])/len(options[a]), -ACTIONS.index(a)))
    return policy, logs


def evaluate():
    rows = freeze(load("input/cases-v1.json"))
    g, atlas, inv = setup()
    train = [r for r in rows if r["partition"] == "train"]
    test = [r for r in rows if r["partition"] == "test"]
    policy, episodes = learn(g, atlas, inv, train)
    write("data/policy-v1.json", dict(episodes=episodes, states=[
          dict(context=s, action=a) for s,a in sorted(policy.items())]))
    answers = []
    for row in test:
        region = Region(g, row["rings"])
        total = region.counts[0]
        preview = atlas_seed(g, atlas, region)
        state = context(preview[2], total)
        selected = policy.get(state, "direct")
        fixed = {a: call(g, inv, row, preview, a) for a in ACTIONS}
        chosen = dict(fixed[selected])
        if selected == "direct":
            chosen["preflight"] = preview[2]
            chosen["work"] = work(chosen)
        answers.append(dict(id=row["id"], kind=row["kind"], total=total, context=state,
                            selected=selected, arms={**fixed, "policy": chosen}))
        print(row["id"], total, state, selected,
              [(a, out["status"], out["counts"].get("nodes"), out["work"])
               for a,out in answers[-1]["arms"].items()], flush=True)
    write("data/results-v1.json", answers)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--generate", action="store_true")
    if parser.parse_args().generate:
        g, atlas, inv = setup()
        rows = cases(g, atlas, inv)
        write("input/cases-v1.json", rows)
        print("Frozen", len(rows), "requests.")
    else:
        evaluate()


if __name__ == "__main__":
    main()
