"""Explain exact-cover conflicts and reuse them by their committed placements."""
from collections import Counter, defaultdict
from functools import lru_cache

from site_cover_v1 import bits, translation


def search(board, limit, jump=True, learn=True, cache=True):
    counts = Counter()
    nodes = []
    seen_core = {}
    watched = defaultdict(list)
    last_blocker = {}
    first_reuse = None

    @lru_cache(maxsize=1200)
    def domain(r, i):
        return tuple(board.choose(r, i, board.initial))

    def select(wanted, active):
        for r in [r for r, w in enumerate(wanted) if w][:2]:
            counts["residue_sweeps"] += 1
            zero, forced = board.cover(r, wanted[r], active)
            if zero or forced:
                i = next(bits(zero or forced))
                moves = tuple(board.choose(r, i, active))
                assert len(moves) == (0 if zero else 1)
                return r, i, moves, forced if not zero else 0
        best = None
        for r, w in enumerate(wanted):
            if w:
                i = next(bits(w))
                moves = tuple(board.choose(r, i, active))
                counts["site_probes"] += 1
                if best is None or len(moves) < len(best[2]):
                    best = r, i, moves, 0
                    if len(moves) <= 1:
                        break
        return best

    def covers(pose, selected):
        h, i = pose
        return tuple(mask & translation(form, i + start)
                     for mask, (form, start) in zip(selected, board.conflicts[h], strict=True))

    def conflict(r, i, selected, path, children):
        # A child can already contradict the parent's commitments.
        for tile, child in children.items():
            if tile not in nodes[child]["core"]:
                return child
        initial = domain(r, i)
        blockers = set()
        depths = {p: j for j, p in enumerate(path)}
        for candidate in initial:
            if candidate in children:
                blockers.update(nodes[children[candidate]]["core"] - {candidate})
                continue
            blocker = last_blocker.get(candidate)
            if cache and blocker in depths:
                counts["blocker_cache_hits"] += 1
            else:
                masks = covers(candidate, selected)
                poses = ((h, j) for h, mask in enumerate(masks) for j in bits(mask))
                blocker = min(poses, key=depths.__getitem__)
                if cache:
                    last_blocker[candidate] = blocker
                counts["exact_blocker_searches"] += 1
            blockers.add(blocker)
            counts["blocker_choices"] += 1
        core = frozenset(blockers)
        assert core <= set(path)
        old = seen_core.get(core)
        if learn and old is not None:
            counts["duplicate_cores"] += 1
            return old
        ref = len(nodes)
        nodes.append(dict(site=board.site(r, i), core=core, children=tuple(children.items())))
        if learn and len(core) <= 10:
            seen_core[core] = ref
            for tile in core:
                watched[tile].append(ref)
            counts["stored_cores"] += 1
        return ref

    def reuse(pose, selected, path):
        nonlocal first_reuse
        if not learn:
            return None
        for ref in watched[pose]:
            counts["core_probes"] += 1
            if all((selected[h] >> j) & 1 for h, j in nodes[ref]["core"]):
                counts["reuse_hits"] += 1
                if first_reuse is None:
                    first_reuse = dict(ref=ref, placements=tuple(map(board.tile, path)),
                                       trigger=board.tile(pose))
                return ref
        return None

    def apply(pose, wanted, active, selected):
        a, b = board.apply(pose, wanted, active)
        h, i = pose
        selected = (*selected[:h], selected[h] | (1 << i), *selected[h+1:])
        counts["tile_applications"] += 1
        return a, b, selected

    def visit(wanted, active, selected, path):
        counts["nodes"] += 1
        if counts["nodes"] > limit:
            raise TimeoutError
        if not any(wanted):
            return path, None
        r, i, moves, forced = select(wanted, active)
        if forced:
            trail = []
            counts["batches"] += 1
            for pose, site in board.forced_poses(r, forced, active):
                h, j = pose
                assert (wanted[r] >> site) & 1
                if not (active[h] >> j) & 1:
                    counts["blocked"] += 1
                    answer, ref = None, conflict(r, site, selected, path, {})
                    break
                trail.append((pose, site, selected, path))
                wanted, active, selected = apply(pose, wanted, active, selected)
                path = (*path, pose)
                counts["forced"] += 1
                ref = reuse(pose, selected, path)
                if ref is not None:
                    answer = None
                    break
            else:
                answer, ref = visit(wanted, active, selected, path)
            if answer is None:
                for pose, site, chosen, prior in reversed(trail):
                    ref = conflict(r, site, chosen, prior, {pose: ref})
            return answer, ref
        counts["forced"] += len(moves) == 1
        counts["blocked"] += not moves
        children = {}
        for j, pose in enumerate(moves):
            a, b, c = apply(pose, wanted, active, selected)
            extended = (*path, pose)
            ref = reuse(pose, c, extended)
            if ref is None:
                answer, ref = visit(a, b, c, extended)
                if answer is not None:
                    return answer, None
            if jump and pose not in nodes[ref]["core"]:
                counts["jump_returns"] += 1
                counts["skipped_siblings"] += len(moves) - j - 1
                return None, ref
            children[pose] = ref
        return None, conflict(r, i, selected, path, children)

    try:
        answer, ref = visit(board.wanted, board.initial, (0,) * len(board.initial), ())
    except (TimeoutError, RecursionError):
        status, answer, ref = "BOUNDED", None, None
    else:
        status = "POSITIVE" if answer is not None else "NEGATIVE"
        if ref is not None:
            assert not nodes[ref]["core"]
    saved = [dict(site=row["site"], core=tuple(sorted(map(board.tile, row["core"]))),
                  children=tuple((board.tile(p), ref) for p, ref in row["children"]))
             for row in nodes]
    return dict(status=status, counts=dict(counts), root=ref, proof=saved, first_reuse=first_reuse,
                patch=tuple(map(board.tile, answer)) if answer is not None else None)
