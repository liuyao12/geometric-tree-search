"""Time complete cold searches for three preselected fixed outlines."""
from pathlib import Path
from statistics import median
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from repair_v1 import Region, atlas_seed, attempt_region, freeze, load, setup
from study_repair_v1 import write


def main():
    requests = {row["id"]: row for row in freeze(load("input/cases-v1.json"))}
    results = []
    for name in ("repair-12", "repair-14", "repair-15"):
        records = {a: [] for a in ("direct", "all", "marked")}
        for repeat in range(5):
            order = list(records)
            order = order[repeat % len(order):] + order[:repeat % len(order)]
            for action in order:
                start = perf_counter()
                g, atlas, inv = setup()
                region = Region(g, requests[name]["rings"])
                preview = None if action == "direct" else atlas_seed(g, atlas, region)
                value = attempt_region(region, inv, requests[name], action, preview)
                records[action].append(dict(seconds=round(perf_counter()-start, 6), status=value["status"]))
                g.boundary.cache_clear()
                g.sites.cache_clear()
        times = {a: dict(runs=rs, median_seconds=median(r["seconds"] for r in rs))
                 for a,rs in records.items()}
        results.append(dict(id=name, arms=times))
        print(name, {a: (r["runs"][0]["status"],r["median_seconds"]) for a,r in times.items()}, flush=True)
    write("data/timing-v1.json", results)


if __name__ == "__main__":
    main()
