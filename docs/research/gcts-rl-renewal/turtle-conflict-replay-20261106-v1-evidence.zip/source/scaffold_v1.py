"""Promote a recovered half-turn contact scaffold to a larger motif."""
from collections import Counter
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, add, save, sub
from cluster_v1 import Model, load, mat
from collars_v1 import vertex_center
from collar_audit_v1 import freeze

from mixed_orbits_v1 import Collision, joined_border, shift
from port_score_v1 import interface


def negate(p):
    return -p[0],-p[1]


def dot(a,b):
    x,y=a
    u,v=b
    return 2*x*u+x*v+y*u+2*y*v


def center(geom,patch):
    pos,n=vertex_center(geom,patch)
    assert all(x%n==0 for x in pos)
    return tuple(x//n for x in pos)


def centred(geom,p):
    return shift(p,negate(center(geom,p)))


def contacts(geom,a,b):
    e=geom.boundary(a)
    f=geom.boundary(b)
    return sum((q,p) in f for p,q in e)


def orientation(geom,proto,patch):
    return min(g for g in geom.model.groups if geom.moved(proto,g)==centred(geom,patch))


def border_cycles(items):
    edges=set()
    for ring,(x,y) in items:
        for (a,b),(c,d) in ring:
            u,v=(a+x,b+y),(c+x,d+y)
            if (v,u) in edges:
                edges.remove((v,u))
            else:
                assert (u,v) not in edges
                edges.add((u,v))
    out=dict(edges)
    if len(out)!=len(edges) or set(out)!=set(out.values()):
        return ()
    cycles=[]
    while out:
        start=min(out)
        p=start
        cycle=[]
        while True:
            q=out.pop(p)
            cycle.append((p,q))
            p=q
            if p==start:
                break
        cycles.append(tuple(cycle))
    return tuple(cycles)


class Scaffold:
    def __init__(self,geom,recovered):
        self.geom=geom
        self.model=geom.model
        self.collision=Collision(geom)
        self.midpoint=center(geom,recovered["motif"])
        self.big=centred(geom,recovered["motif"])
        self.small=centred(geom,recovered["doublet"])
        self.triangle=centred(geom,recovered["seed"])
        self.strip=recovered["alphabet"]
        paths=recovered["strips"]
        self.old_strips=tuple(shift(p,negate(self.midpoint)) for p in paths)
        first=self.old_strips[0]
        pieces=tuple(shift(p,negate(self.midpoint)) for p in recovered["motif_pairs"])
        source={center(geom,p):p for p in pieces}
        self.source=source
        self.centre=source[(0,0)]
        outer=sorted(p for xy,p in source.items() if xy!=(0,0))
        best=sorted((contacts(geom,first,p),p) for p in outer)
        _,self.left=best[-1]
        self.left_vec=center(geom,self.left)
        candidates=[p for p in outer if p!=self.left and contacts(geom,self.left,p)]
        self.side,=candidates
        self.side_vec=center(geom,self.side)
        self.old=(self.centre,self.left,self.side)
        self.roles=tuple(orientation(geom,self.small,p) for p in self.old)
        self.old_core_links=tuple(contacts(geom,a,b) for a,b in combinations(self.old,2))
        # The lower layer fixes which three motif roles border one strip.
        old_core=(self.centre,self.left,self.side,source[negate(self.left_vec)],source[negate(self.side_vec)])
        self.strip_roles=tuple(i for i,p in enumerate(old_core) if contacts(geom,first,p))
        # Determine the path stencil's orientation from the earlier recovered strip.
        path=self.strip["path"]
        delta=tuple(sorted(path))
        fits=[]
        for turn in geom.model.groups:
            oriented=geom.moved(delta,turn)
            root=min(t[1:] for t in oriented)
            target=min(t[1:] for t in first)
            moved=shift(oriented,sub(target,root))
            if moved==tuple(sorted(first)):
                fits.append(turn)
        self.strip_turn=min(fits)
        self.phases=tuple(g for g in geom.model.groups if g<=geom.model.compose[geom.rot2,g])

    @lru_cache(maxsize=192)
    def ports(self,a,b):
        lookup=interface(self.geom.boundary(a),self.geom.boundary(b))
        blocked=self.collision.blocked(a,b)
        return lookup,blocked

    def poses(self,phase):
        model=self.model
        geom=self.geom
        return tuple(geom.moved(self.big,model.compose[g,phase]) for g in self.roles)

    def core(self,phase,allow_holes=False):
        c,a,b=self.poses(phase)
        ca,blocked_ca=self.ports(c,a)
        cb,blocked_cb=self.ports(c,b)
        ab,blocked_ab=self.ports(a,b)
        _,blocked_aa=self.ports(a,a)
        _,blocked_bb=self.ports(b,b)
        a_ports=sorted(ca.keys()-blocked_ca)
        b_ports=sorted(cb.keys()-blocked_cb)
        stats=Counter(left_ports=len(a_ports),side_ports=len(b_ports))
        candidates=[]
        for p in a_ports:
            for q in b_ports:
                if dot(p,self.left_vec)<=0 or dot(q,self.side_vec)<=0:
                    continue
                stats["directional_pairs"]+=1
                if negate(add(p,p)) in blocked_aa or negate(add(q,q)) in blocked_bb:
                    stats["opposite_collision"]+=1
                    continue
                close,far=sub(q,p),sub(negate(q),p)
                if close in blocked_ab or far in blocked_ab:
                    stats["cross_collision"]+=1
                    continue
                if not ab[close] or ab[far]:
                    stats["interface_mismatch"]+=1
                    continue
                core=(c,shift(a,p),shift(b,q),shift(a,negate(p)),shift(b,negate(q)))
                edges=[self.geom.boundary(x) for x in (c,a,b)]
                lines=((edges[0],(0,0)),(edges[1],p),(edges[2],q),
                       (edges[1],negate(p)),(edges[2],negate(q)))
                cycles=border_cycles(lines) if allow_holes else ()
                ring=tuple(e for c in cycles for e in c) if allow_holes else joined_border(lines)
                if not ring:
                    stats["multiple_rings"]+=1
                    continue
                score=ca[p]+cb[q]+ab[close]
                assert len(ring)==5*len(edges[0])-4*score
                stats["closed_cores"]+=1
                row=dict(p=p,q=q,score=score,perimeter=len(ring),pieces=core,
                         seam_counts=(ca[p],cb[q],ab[close]))
                if allow_holes:
                    row["cycles"]=cycles
                candidates.append(row)
        candidates.sort(key=lambda x:(-x["score"],x["p"],x["q"]))
        return dict(phase=phase,counts=stats,candidates=candidates)


def make():
    data=freeze(load("input/recovered-production-v1.json"))
    geom=Geometry(Model(load("input/exact-point-model-v1.json")))
    return Scaffold(geom,data),data


def main():
    s,_=make()
    rows=[s.core(g) for g in s.phases]
    save("data/scaffolds-v1.json",dict(status="LIFTED_HALF_TURN_SCAFFOLD",roles=s.roles,
         old_ports=s.old_core_links,old_directions=(s.left_vec,s.side_vec),strip_roles=s.strip_roles,
         strip_turn=s.strip_turn,phases=rows))
    for r in rows:
        best=r["candidates"][0] if r["candidates"] else {}
        print(r["phase"],dict(r["counts"]),{k:v for k,v in best.items() if k!="pieces"},flush=True)


if __name__=="__main__":
    main()
