"""Compare conflict search against packed exact cover and audit its certificates."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
from statistics import median
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from conflict_v1 import search as explain
from site_cover_study_v1 import (
    Audit, Board, Region, audit_cover, audit_negative, budget, cases,
    independent_domains, save, search, setup,
)


ARMS = {
    "packed": lambda b, cap: search(b, cap, "batch"),
    "chronological": lambda b, cap: explain(b, cap, jump=False, learn=False, cache=False),
    "backjump": lambda b, cap: explain(b, cap, learn=False, cache=False),
    "reuse": lambda b, cap: explain(b, cap, cache=False),
    "cached": explain,
}
REPRESENTATIVES = {"repair-09", "repair-13", "repair-14", "rotated-hole"}


def occupied(region, tiles):
    used = set()
    turns = {h for h, _, _ in region.g.bases}
    for tile in tiles:
        assert len(tile) == 3 and all(type(c) is int for c in tile) and tile[0] in turns
        sites = region.g.sites(tile)
        assert sites <= region.sites and used.isdisjoint(sites)
        used.update(sites)
    return used


def audit_conflicts(region, answer):
    incident = independent_domains(region)
    proof = answer["proof"]
    options_checked = blocked = 0
    for i, row in enumerate(proof):
        core = set(row["core"])
        assert tuple(sorted(core)) == row["core"]
        used = occupied(region, row["core"])
        site = row["site"]
        assert site in region.sites and site not in used
        options = incident(site)
        children = dict(row["children"])
        assert len(children) == len(row["children"]) and children.keys() <= options.keys()
        for tile, part in options.items():
            if tile in children:
                j = children[tile]
                assert type(j) is int and 0 <= j < i and used.isdisjoint(part)
                earlier = set(proof[j]["core"])
                assert tile in earlier and earlier - {tile} <= core
            else:
                assert not used.isdisjoint(part)
                blocked += 1
        options_checked += len(options)
    ref = answer["root"]
    if answer["status"] == "NEGATIVE":
        assert type(ref) is int and 0 <= ref < len(proof) and not proof[ref]["core"]
    else:
        assert ref is None
    event = answer["first_reuse"]
    if event is not None:
        j = event["ref"]
        assert type(j) is int and 0 <= j < len(proof)
        placements = event["placements"]
        assert placements[-1] == event["trigger"]
        assert event["trigger"] in proof[j]["core"] and set(proof[j]["core"]) <= set(placements)
        occupied(region, placements)
    return dict(rows=len(proof), options=options_checked, overlaps=blocked,
                largest_core=max((len(r["core"]) for r in proof), default=0),
                reuse_witness=event is not None)


def cap_for(row, region):
    return 4000 if row["id"] == "repair-14" else budget(region)


def reject_omission(region, answer):
    proof = answer["proof"].copy()
    j = answer["root"]
    assert proof[j]["children"]
    proof[j] = dict(proof[j], children=proof[j]["children"][1:])
    try:
        audit_conflicts(region, dict(answer, proof=proof))
    except AssertionError:
        return True
    raise AssertionError("An omitted option was accepted")


def study(g, rows):
    results = []
    for row in rows:
        region = Region(g, row["rings"])
        board = Board(region)
        cap = cap_for(row, region)
        arms = {}
        for mode, run in ARMS.items():
            answer = run(board, cap)
            status = answer["status"]
            if mode != "packed":
                verified = audit_conflicts(region, answer)
            elif status == "NEGATIVE":
                verified = audit_negative(region, answer["proof"])
            else:
                verified = {}
            if status == "POSITIVE":
                verified["cover"] = audit_cover(Audit(g.model), region, answer["patch"])
            if mode == "packed":
                baseline = answer
            elif mode == "chronological":
                assert {k: answer["counts"][k] for k in baseline["counts"]} == baseline["counts"]
                assert baseline.get("patch") == answer["patch"] and baseline["status"] == status
            elif baseline["status"] != "BOUNDED" and status != "BOUNDED":
                assert status == baseline["status"]
            if mode == "cached" and row["id"] in REPRESENTATIVES:
                if row["id"] == "rotated-hole":
                    verified["omission_rejected"] = reject_omission(region, answer)
                save(row["id"] + "-core", answer)
            arms[mode] = dict(status=status, counts=answer["counts"], checked=verified)
        result = dict(id=row["id"], kind=row["kind"], tiles=region.counts[0], cap=cap, arms=arms)
        results.append(result)
        print(row["id"], [(k, v["status"], v["counts"]["nodes"]) for k, v in arms.items()], flush=True)
    return results


def timing(rows, repetitions):
    actions = ("packed", "chronological", "backjump", "reuse", "cached")
    results = []
    for row in rows:
        if row["id"] not in REPRESENTATIVES:
            continue
        times = defaultdict(list)
        for i in range(repetitions):
            for name in (*actions[i % len(actions):], *actions[:i % len(actions)]):
                g, _, _ = setup()
                start = perf_counter()
                region = Region(g, row["rings"])
                result = ARMS[name](Board(region), cap_for(row, region))
                times[name].append(perf_counter() - start)
                assert result["status"] != "BOUNDED"
        item = dict(id=row["id"], samples=dict(times), medians={k: median(v) for k, v in times.items()})
        results.append(item)
        print(row["id"], {k: round(v, 3) for k, v in item["medians"].items()}, flush=True)
    return results


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--timing", type=int, default=0, metavar="REPEATS")
    args = parser.parse_args()
    g, _, _ = setup()
    rows = [r for r in cases(g) if r["partition"] == "test"]
    if args.timing:
        save("conflict-timing", timing(rows, args.timing))
    else:
        save("conflict-study", study(g, rows))


if __name__ == "__main__":
    main()
