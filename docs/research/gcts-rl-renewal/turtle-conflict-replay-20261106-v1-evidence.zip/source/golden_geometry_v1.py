"""Unmarked Turtle exact cover, group actions and patch boundary matching."""

from collections import Counter, defaultdict
from itertools import pairwise
from math import gcd

from cluster_v1 import bounds, inside, mat


def add(a,b):
    return a[0]+b[0],a[1]+b[1]


def sub(a,b):
    return a[0]-b[0],a[1]-b[1]


def area2(ring):
    return abs(sum(x*v-y*u for (x,y),(u,v) in pairwise((*ring,ring[0]))))


def unit_segments(ring):
    for a,b in pairwise(ring):
        x,y=sub(b,a)
        steps=gcd(x,y)
        if not steps:
            continue
        d=(x//steps,y//steps)
        for _ in range(steps):
            q=add(a,d)
            yield tuple(sorted((a,q)))
            a=q


def perimeter(model,patch):
    edges=Counter(edge for t in patch for edge in unit_segments((*model.poly(t),model.poly(t)[0])))
    assert all(v in (1,2) for v in edges.values())
    return {e for e,n in edges.items() if n==1}


def loops(model,patch):
    edges=perimeter(model,patch)
    neighbors=defaultdict(set)
    for a,b in edges:
        neighbors[a].add(b)
        neighbors[b].add(a)
    if any(len(v)!=2 for v in neighbors.values()):
        return []
    rings=[]
    while edges:
        first,second=min(edges)
        ring=[first,second]
        edges.remove((first,second))
        a,b=first,second
        while b!=first:
            c,=neighbors[b]-{a}
            edges.remove(tuple(sorted((b,c))))
            ring.append(c)
            a,b=b,c
        rings.append(tuple(ring))
    rings.sort(key=area2,reverse=True)
    if rings and all(inside(r[0],tuple(pairwise(rings[0]))) for r in rings[1:]):
        return rings
    return []


def signature(edges):
    origin=min(p for e in edges for p in e)
    return origin,frozenset((sub(a,origin),sub(b,origin)) for a,b in edges)


def transform(model,patch,g,shift=(0,0)):
    return tuple(sorted((h,x+shift[0],y+shift[1]) for h,x,y in (model.action(g,t) for t in patch)))


def support(model,patch):
    sites=set()
    for tile in patch:
        part=set(model.support(tile))
        assert not sites.intersection(part)
        sites.update(part)
    return sites


def polygon_points(model,ring):
    assert ring[0]==ring[-1]
    xmin,xmax,ymin,ymax=bounds(ring)
    scale=model.scale
    outline=tuple(pairwise((scale*x,scale*y) for x,y in ring))
    samples={q for x in range(xmin,xmax) for y in range(ymin,ymax)
             for a,b in model.residues if inside(q:=(scale*x+a,scale*y+b),outline)}
    assert sum(model.residues[(x%scale,y%scale)] for x,y in samples)==area2(ring)
    return samples


def cover(model,ring):
    wanted=polygon_points(model,ring)
    xmin,xmax,ymin,ymax=bounds(ring)
    candidates={}
    domains={q:[] for q in wanted}
    for g,poly in model.polygons.items():
        ax,bx,ay,by=bounds(poly)
        for x in range(xmin-ax,xmax-bx+1):
            for y in range(ymin-ay,ymax-by+1):
                t=(g,x,y)
                patch=frozenset(model.support(t))
                if patch<=wanted:
                    candidates[t]=patch
                    for q in patch:
                        domains[q].append(t)
    solutions=[]
    calls=0

    def search(left,selected):
        nonlocal calls
        calls+=1
        if not left:
            solutions.append(tuple(sorted(selected)))
            return
        choices=None
        for q in sorted(left):
            moves=[t for t in domains[q] if candidates[t]<=left]
            if not moves:
                return
            if choices is None or len(moves)<len(choices):
                choices=moves
                if len(moves)==1:
                    break
        for t in choices:
            search(left-candidates[t],(*selected,t))

    search(wanted,())
    for patch in solutions:
        assert support(model,patch)==wanted
        assert perimeter(model,patch)==set(unit_segments(ring))
    return solutions,len(candidates),calls


def matches(model,patch,paths):
    """Fit an exact outer boundary to independently snapped closed paths."""
    bins={}
    for g in model.groups:
        pose=transform(model,patch,g)
        anchor,key=signature(perimeter(model,pose))
        bins.setdefault(key,[]).append((pose,anchor))
    found={}
    for ring in paths:
        if ring[0]!=ring[-1]:
            continue
        edges=set(unit_segments(ring))
        if not edges:
            continue
        anchor,key=signature(edges)
        for pose,prior in bins.get(key,[]):
            shift=sub(anchor,prior)
            item=transform(model,pose,0,shift)
            assert perimeter(model,item)==edges
            found[item]=None
    return sorted(found)


def words(n):
    rows=["1","0","001"]
    for _ in range(1,n):
        rows.append(rows[-1]+rows[-2])
    return rows[1:]


def strip(word):
    return tuple((11 if bit=="0" else 10,4*i,-2*i-(3 if bit=="1" else 0))
                 for i,bit in enumerate(word))
