"""Search outward from unmarked clusters with exact open-disk edge obligations."""
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, add, sub, steps
from cluster_v1 import mat


def norm(p):
    x,y=p
    return x*x+x*y+y*y


def scale(p,k):
    return tuple(k*x for x in p)


def meeting(a,b,center,radius):
    """Positive length of a segment lies in an open disk of lattice radius."""
    total,den=center
    p,q=(sub(scale(v,den),total) for v in (a,b))
    d=sub(q,p)
    n=norm(d)
    u=norm(q)-norm(p)-n
    r=radius*den
    if u>=0:
        return norm(p)<r*r
    if u<=-2*n:
        return norm(q)<r*r
    return 4*n*(norm(p)-r*r)<u*u


def vertex_center(geom,patch):
    pts=[p for t in patch for p in geom.model.poly(t)]
    return tuple(map(sum,zip(*pts))),len(pts)


class Limit(Exception):
    pass


@dataclass(frozen=True)
class Mark:
    direction: tuple
    blockers: tuple
    cover: tuple


class Collar:
    def __init__(self,geom):
        self.geom=geom
        self.rotations=tuple(g for g,m in geom.model.groups.items()
                             if m[0][0]*m[1][1]-m[0][1]*m[1][0]==1)
        self.neighbors=defaultdict(set)
        for g,poly in geom.model.polygons.items():
            for p,q in steps(poly):
                self.neighbors[sub(p,q)].add((g,-q[0],-q[1]))
        self.neighbors={d:tuple(sorted(p)) for d,p in self.neighbors.items()}

    @lru_cache(maxsize=10000)
    def edge_tiles(self,edge):
        a,b=edge
        return tuple((g,x+a[0],y+a[1]) for g,x,y in self.neighbors[sub(b,a)])

    def relative(self,tile,root):
        g,x,y=tile
        return g,x-root[0],y-root[1]

    def derive(self,edge,patch):
        a,b=edge
        receiver=self.edge_tiles(edge)
        pairs={}
        for t in patch:
            atoms=self.geom.atoms(t)
            for c in receiver:
                shared=atoms&self.geom.atoms(c)
                if shared:
                    pairs.setdefault(t,{})[c]=min(shared)
        remaining=set(receiver)
        chosen=[]
        cover=[]
        while remaining:
            blocker=min(pairs,key=lambda t:(-len(remaining & pairs[t].keys()),t))
            hits=remaining & pairs[blocker].keys()
            assert hits
            chosen.append(self.relative(blocker,a))
            for c in sorted(hits):
                sample=sub(pairs[blocker][c],scale(a,self.geom.model.scale))
                cover.append((self.relative(c,a),chosen[-1],sample))
            remaining-=hits
        return Mark(sub(b,a),tuple(sorted(chosen)),tuple(sorted(cover)))

    def extend_marks(self,marks):
        bank=defaultdict(set)
        for m in marks:
            for g in self.rotations:
                d=mat(self.geom.model.groups[g],m.direction)
                p=tuple(sorted(self.geom.model.action(g,t) for t in m.blockers))
                bank[d].add(p)
        return {d:tuple(sorted(poses,key=lambda x:(len(x),x))) for d,poses in bank.items()}

    def present(self,edge,selected,index):
        a,b=edge
        for blockers in index.get(sub(b,a),()):
            if all((g,x+a[0],y+a[1]) in selected for g,x,y in blockers):
                return blockers
        return None

    def affine_turn(self,seed):
        center,den=vertex_center(self.geom,seed)
        g=self.geom.rot3[0]
        n=sub(center,mat(self.geom.model.groups[g],center))
        assert all(x%den==0 for x in n)
        shift=tuple(x//den for x in n)
        assert self.geom.moved(seed,g,shift)==seed
        return g,shift

    @lru_cache(maxsize=10000)
    def orbit(self,tile,rotation):
        if rotation is None:
            return (tile,)
        g,shift=rotation
        b,=self.geom.moved((tile,),g,shift)
        c,=self.geom.moved((b,),g,shift)
        assert self.geom.moved((c,),g,shift)==(tile,)
        return tuple(sorted({tile,b,c}))

    def search(self,seed,radius,order="lex",marks=(),learn=False,maximum=350,orbit=False):
        geom=self.geom
        center=vertex_center(geom,seed)
        assert any(norm(sub(scale(p,center[1]),center[0]))<(radius*center[1])**2
                   for t in seed for p in geom.model.poly(t))
        rotation=self.affine_turn(seed) if orbit else None
        stats=Counter()
        initial=geom.occupied(seed)
        frontier={e:0 for e in geom.boundary(seed)}
        index=self.extend_marks(marks)
        donors={}
        uses={}
        failed={}
        refutations=[]

        def reject(key,edge,children=(),blockers=None):
            failed[key]=len(refutations)
            refutations.append(dict(edge=edge,children=children,blockers=blockers))

        def visit(patch,occupied,boundary,history):
            key=frozenset(patch)
            if key in failed:
                stats["known_failures"]+=1
                return None
            stats["states"]+=1
            if stats["states"]>maximum:
                raise Limit
            active=sorted(e for e in boundary if meeting(*e,center,radius))
            if not active:
                return patch,boundary,history
            chosen=None
            forced=None
            for e in active:
                stats["edge_obligations"]+=1
                block=self.present(e,key,index)
                if block is not None:
                    stats["mark_hits"]+=1
                    uses.setdefault((sub(e[1],e[0]),block),(e,tuple(sorted(key))))
                    reject(key,e,blockers=block)
                    return None
                options=[]
                unit_options=0
                for t in self.edge_tiles(e):
                    stats["placement_checks"]+=1
                    if not occupied.isdisjoint(geom.atoms(t)):
                        continue
                    unit_options+=1
                    moves=self.orbit(t,rotation)
                    atoms=frozenset().union(*(geom.atoms(m) for m in moves))
                    if len(atoms)==240*len(moves) and occupied.isdisjoint(atoms):
                        options.append((t,moves,atoms))
                if not options:
                    stats["dead_edges"]+=1
                    if learn and not unit_options:
                        mark=self.derive(e,patch)
                        donors.setdefault(mark,(e,tuple(sorted(key))))
                    reject(key,e)
                    return None
                k=(boundary[e],len(options),e)
                if len(options)==1 and (forced is None or k<forced[0]):
                    forced=k,options
                if chosen is None or k<chosen[0]:
                    chosen=k,options
            (generation,_,e),options=forced or chosen
            if len(options)==1:
                stats["forced"]+=1
            else:
                stats["branches"]+=1
                if order=="compact":
                    options.sort(key=lambda option:(-sum((b,a) in boundary for t in option[1]
                                                       for a,b in geom.boundary((t,))),option[0]))
                elif order=="spread":
                    p,den=center
                    options.sort(key=lambda option:(-norm(sub(scale(option[0][1:],den),p)),option[0]))
            children=[]
            for t,moves,atoms in options:
                updated=dict(boundary)
                for tile in moves:
                    for a,b in geom.boundary((tile,)):
                        if (b,a) in updated:
                            del updated[b,a]
                        else:
                            assert (a,b) not in updated
                            updated[a,b]=generation+1
                grown=(*patch,*moves)
                accepted=visit(grown,occupied|atoms,updated,(*history,(e,t,moves,len(options),generation)))
                if accepted:
                    return accepted
                children.append((t,failed[frozenset(grown)]))
            reject(key,e,children)
            return None

        try:
            found=visit(seed,initial,frontier,())
        except Limit:
            status,found="BOUNDED",None
        else:
            status="COVERED" if found else "EXHAUSTED"
        return dict(status=status,stats=dict(stats),center=center,rotation=rotation,
                    failure=dict(root=failed[frozenset(seed)],nodes=refutations) if status=="EXHAUSTED" else None,
                    patch=None if not found else tuple(sorted(found[0])),
                    boundary=None if not found else tuple(sorted(found[1])),
                    history=None if not found else found[2],
                    donors=[dict(direction=m.direction,blockers=m.blockers,cover=m.cover,edge=e,patch=p)
                            for m,(e,p) in sorted(donors.items(),key=lambda item:repr(item[0]))],
                    hits=[dict(direction=d,blockers=b,edge=e,patch=p)
                          for (d,b),(e,p) in sorted(uses.items())])
