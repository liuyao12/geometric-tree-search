"""Enumerate two threefold cluster orbits from contacts and exact displacements."""
from collections import Counter, defaultdict
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, ROOT, add, save, sub
from cluster_v1 import Model, load, mat
from collars_v1 import Collar


def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x


def shift(patch,pos):
    x,y=pos
    return tuple((g,a+x,b+y) for g,a,b in patch)


def recenter(patch):
    x,y=min(p[1:] for p in patch)
    return shift(patch,(-x,-y))


def oriented_variants(geom,patch):
    variants={}
    for g in geom.model.groups:
        p=recenter(geom.moved(patch,g))
        variants.setdefault(p,g)
    return sorted(variants)


class Collision:
    def __init__(self,geom):
        model=geom.model
        scale=model.scale
        fibers={}
        for g,atoms in model.atoms.items():
            rows=defaultdict(list)
            for x,y in atoms:
                u,r=divmod(x,scale)
                v,s=divmod(y,scale)
                rows[r,s].append((u,v))
            fibers[g]=rows
        self.base={}
        for g,left in fibers.items():
            for h,right in fibers.items():
                self.base[g,h]={(a-u,b-v) for key,positions in left.items() for a,b in positions
                                for u,v in right.get(key,())}

    def blocked(self,left,right):
        positions=set()
        for g,a,b in left:
            for h,u,v in right:
                x,y=a-u,b-v
                positions.update((dx+x,dy+y) for dx,dy in self.base[g,h])
        return positions


def joined_border(items):
    boundary=set()
    for edges,(x,y) in items:
        for (a,b),(c,d) in edges:
            start,end=(a+x,b+y),(c+x,d+y)
            if (end,start) in boundary:
                boundary.remove((end,start))
            else:
                assert (start,end) not in boundary
                boundary.add((start,end))
    if not boundary:
        return None
    graph=dict(boundary)
    if len(graph)!=len(boundary) or len(set(graph.values()))!=len(boundary):
        return None
    start=min(graph)
    point=graph.pop(start)
    while point!=start:
        point=graph.pop(point)
    return None if graph else boundary


class Join:
    def __init__(self,geom,anchor):
        self.geom=geom
        self.anchor=anchor
        self.turn,self.offset=Collar(geom).affine_turn(anchor)
        self.matrix=geom.model.groups[self.turn]
        self.collisions=Collision(geom)
        self.block_aa=self.collisions.blocked(anchor,anchor)
        self.edges_a=geom.boundary(anchor)
        self.contacts_aa=geom.poses(anchor,anchor)-self.block_aa

    def phases(self,s,u):
        v=add(u,mat(self.matrix,u))
        q=add(u,self.offset)
        x=add(mat(self.matrix,s),q)
        y=add(mat(self.matrix,x),q)
        return u,v,x,y

    def variant(self,b):
        b1=self.geom.moved(b,self.turn)
        b2=self.geom.moved(b1,self.turn)
        ab=self.collisions.blocked(self.anchor,b)
        bb=self.collisions.blocked(b,b1)
        edges=(self.geom.boundary(b),self.geom.boundary(b1),self.geom.boundary(b2))
        raw=self.geom.poses(self.anchor,b)
        ports=sorted(raw-ab)
        counts=Counter(contacts=len(raw),ports=len(ports))
        links_bb=self.geom.poses(b,b1)-bb
        coords=set()
        for s in ports:
            for t in ports:
                if s!=t:
                    coords.add((s,sub(s,t)))
            for u in self.contacts_aa:
                coords.add((s,u))
            for d in links_bb:
                x=add(s,d)
                q=sub(x,mat(self.matrix,s))
                coords.add((s,sub(q,self.offset)))
        valid=[]
        for s,u in sorted(coords):
            counts["contact_assemblies"]+=1
            u,v,x,y=self.phases(s,u)
            if u in self.block_aa:
                counts["anchor_collision"]+=1
                continue
            if sub(x,s) in bb:
                counts["mate_collision"]+=1
                continue
            if sub(s,u) in ab or sub(s,v) in ab:
                counts["other_cross_collision"]+=1
                continue
            counts["disjoint"]+=1
            border=joined_border(((self.edges_a,(0,0)),(self.edges_a,u),(self.edges_a,v),
                                  (edges[0],s),(edges[1],x),(edges[2],y)))
            if border is None:
                counts["multiple_boundary_loops"]+=1
                continue
            counts["closed"]+=1
            valid.append((len(border),s,u))
        return counts,valid

    def patch(self,b,s,u):
        u,v,x,y=self.phases(s,u)
        b1=self.geom.moved(b,self.turn)
        b2=self.geom.moved(b1,self.turn)
        pieces=(self.anchor,shift(self.anchor,u),shift(self.anchor,v),shift(b,s),shift(b1,x),shift(b2,y))
        return tuple(sorted(p for piece in pieces for p in piece)),pieces


def run_entry(join,row):
    motif=freeze(row["patch"])
    totals=Counter()
    choices=[]
    variants=oriented_variants(join.geom,motif)
    for i,b in enumerate(variants):
        counts,valid=join.variant(b)
        totals.update(counts)
        choices.extend((p,i,s,t) for p,s,t in valid)
    choices.sort()
    # Keep a complete list of compact placement addresses, and one exact
    # representative for the visual reader.
    representative=None
    if choices:
        p,i,s,t=choices[0]
        patch,pieces=join.patch(variants[i],s,t)
        representative=dict(perimeter=p,patch=patch,pieces=pieces)
    return dict(id=row["id"],size=len(motif),perimeter=row["perimeter"],counts=dict(totals),
                variants=variants,placements=choices,representative=representative)


def main():
    g=Geometry(Model(load("input/exact-point-model-v1.json")))
    deck=load("input/recovered-bank-v1.json")
    join=Join(g,freeze(deck["seed"]))
    rows=[]
    for row in deck["entries"]:
        result=run_entry(join,row)
        rows.append(result)
        if result["counts"].get("closed",0):
            print(result["id"],result["size"],result["counts"]["closed"],result["placements"][0],flush=True)
    save("data/closures-v1.json",dict(status="EXHAUSTED_MIXED_ORBIT_CONTACTS",turn=join.turn,
                                        origin=join.offset,entries=rows))


if __name__=="__main__":
    main()
