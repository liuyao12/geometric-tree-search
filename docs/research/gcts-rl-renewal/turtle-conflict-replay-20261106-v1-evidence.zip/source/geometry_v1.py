"""Exact oriented boundary adapters for unmarked Turtle and Penrose rhombs."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, pairwise
from math import ceil, gcd

import check_v1 as independent
import model_v1 as penrose
from cluster_v1 import Model
from triangle_geometry_v1 import polygon_overlap


def add(a,b):
    return tuple(x+y for x,y in zip(a,b,strict=True))


def sub(a,b):
    return tuple(x-y for x,y in zip(a,b,strict=True))


def mul(k,p):
    return tuple(k*x for x in p)


def area(poly,cross):
    terms = [cross(a,b) for a,b in pairs(poly)]
    return tuple(map(sum,zip(*terms)))


def pairs(poly):
    return pairwise((*poly,poly[0]))


def lattice_cross(a,b):
    return (a[0]*b[1]-a[1]*b[0],)


def field_product(a,b):
    x,y = a
    u,v = b
    return x*u+y*v, x*v+y*u+y*v


def winding(poly,p,den,cross,sign,unit,transverse):
    """Winding of a rationally scaled point, or None on the ring."""
    n=0
    for a,b in pairs(poly):
        u,v=sub(mul(den,a),p),sub(mul(den,b),p)
        y,z=sign(cross(unit,u)),sign(cross(unit,v))
        side=sign(cross(u,v))
        if not side and dot_between(u,v,cross,sign,unit,transverse):
            return None
        if y<=0<z and side>0:
            n+=1
        if z<=0<y and side<0:
            n-=1
    return n


def dot_between(u,v,cross,sign,unit,transverse):
    """Zero lies between collinear endpoints, using a nonzero projection."""
    p,q=sign(cross(unit,u)),sign(cross(unit,v))
    if p or q:
        return p*q<=0
    p,q=sign(cross(transverse,u)),sign(cross(transverse,v))
    return p*q<=0


def intersects(a,b,c,d,cross,sign,unit,transverse):
    def side(x,y,z):
        return sign(cross(sub(y,x),sub(z,x)))
    x,y=side(a,b,c),side(a,b,d)
    z,w=side(c,d,a),side(c,d,b)
    if x*y<0 and z*w<0:
        return True
    return ((x==0 and dot_between(sub(a,c),sub(b,c),cross,sign,unit,transverse))
            or (y==0 and dot_between(sub(a,d),sub(b,d),cross,sign,unit,transverse))
            or (z==0 and dot_between(sub(c,a),sub(d,a),cross,sign,unit,transverse))
            or (w==0 and dot_between(sub(c,b),sub(d,b),cross,sign,unit,transverse)))


def compact_corners(geometry,ring):
    axes=geometry.cross,geometry.sign,geometry.unit,geometry.transverse
    corners=[]
    for j,b in enumerate(ring):
        a,c=ring[j-1],ring[(j+1)%len(ring)]
        incoming,outgoing=sub(b,a),sub(c,b)
        if geometry.sign(geometry.cross(incoming,outgoing)):
            corners.append(b)
        else:
            assert not dot_between(incoming,outgoing,*axes)
    assert len(corners)>=3
    return tuple(corners)


def check_rings(geometry,rings):
    assert rings
    predicates=(geometry.cross,geometry.sign,geometry.unit,geometry.transverse)
    known=[]
    for i,ring in enumerate(rings):
        assert len(ring)>=3 and len(ring)==len(set(ring))
        assert geometry.sign(area(ring,geometry.cross)) == (1 if not i else -1)
        ring=compact_corners(geometry,ring)
        lines=list(pairs(ring))
        for (j,(a,b)),(k,(c,d)) in combinations(enumerate(lines),2):
            if k==j+1 or (j==0 and k==len(lines)-1):
                continue
            assert not intersects(a,b,c,d,*predicates)
        if i:
            assert geometry.wind(known[0],ring[0],1)==1
        for j,other in enumerate(known):
            for a,b in lines:
                for c,d in pairs(other):
                    assert not intersects(a,b,c,d,*predicates)
            if j:
                assert geometry.wind(other,ring[0],1)==0 and geometry.wind(ring,other[0],1)==0
        known.append(ring)


def chain(geometry,patch):
    directed=Counter(e for t in patch for e in geometry.boundary(t))
    out=set()
    for e,n in directed.items():
        assert abs(n-directed[e[::-1]])<=1
        if n>directed[e[::-1]]:
            out.add(e)
    return frozenset(out)


def rings_from_edges(edges):
    """Recover vertex-disjoint cycles from an exact boundary."""
    out=dict(edges)
    if len(out)!=len(edges) or set(out)!=set(out.values()):
        return None
    rings=[]
    while out:
        p=min(out)
        cycle=[p]
        q=out.pop(p)
        while q!=p:
            cycle.append(q)
            if q not in out:
                return None
            q=out.pop(q)
        rings.append(tuple(cycle))
    return rings


class Turtle:
    kind="turtle"
    cross=staticmethod(lattice_cross)
    sign=staticmethod(lambda a:(a[0]>0)-(a[0]<0))
    unit=(1,0)
    transverse=(0,1)
    zero=(0,0)

    def __init__(self,source):
        self.model=Model(source)
        self.turns=tuple(self.model.groups)
        self.bases=tuple((g,0,0) for g in self.turns)
        self.tile_area=area(self.poly(self.bases[0]),self.cross)[0]

    def wind(self,poly,p,den):
        return winding(poly,p,den,self.cross,self.sign,self.unit,self.transverse)

    def poly(self,t):
        raw=self.model.poly(t)
        return raw if self.sign(area(raw,self.cross))>0 else raw[::-1]

    def turn(self,t,g):
        return self.model.action(g,t)

    @staticmethod
    def shift(t,p):
        g,x,y=t
        return g,x+p[0],y+p[1]

    def atomize(self,a,b):
        d=sub(b,a)
        n=gcd(*d)
        assert n
        s=tuple(x//n for x in d)
        normal=(s[1],-s[0])
        if normal<(0,0):
            normal=mul(-1,normal)
        assert normal in self.model.normals
        for _ in range(n):
            c=add(a,s)
            yield a,c
            a=c
        assert a==b

    @lru_cache(maxsize=30000)
    def boundary(self,t):
        return tuple(e for a,b in pairs(self.poly(t)) for e in self.atomize(a,b))

    @lru_cache(maxsize=15000)
    def sites(self,t):
        return frozenset(self.model.support(t))

    def counts(self,a):
        n,rest=divmod(a[0],self.tile_area)
        return (n,) if n>=0 and not rest else None

    def mass(self,t):
        return (1,)

    def verify(self,rings,patch):
        assert chain(self,patch)==frozenset(e for ring in rings for a,b in pairs(ring) for e in self.atomize(a,b))
        assert all(not polygon_overlap(self.poly(a),self.poly(b))["overlap"] for a,b in combinations(patch,2)
                   if bbox_overlap(self.poly(a),self.poly(b)))


def bbox_overlap(a,b):
    return all(max(min(x),min(y))<min(max(x),max(y)) for x,y in zip(zip(*a),zip(*b)))


class Penrose:
    kind="penrose"
    cross=staticmethod(independent.imaginary_normal)
    sign=staticmethod(lambda a:independent.order(a,(0,0)))
    unit=penrose.ONE
    transverse=penrose.DIRECTIONS[1]
    zero=penrose.ZERO
    turns=tuple(range(10))

    def __init__(self):
        self.bases=tuple(sorted({tuple(sub(p,t[0]) for p in t) for t in penrose.incident(self.zero)}))

    def wind(self,poly,p,den):
        return winding(poly,p,den,self.cross,self.sign,self.unit,self.transverse)

    @lru_cache(maxsize=30000)
    def poly(self,t):
        a=t[0]
        b,c=[p for p in t[1:] if sub(p,a) in penrose.DIRECTIONS]
        d=next(p for p in t if p not in (a,b,c))
        if self.sign(self.cross(sub(b,a),sub(c,a)))<0:
            b,c=c,b
        return a,b,d,c

    @staticmethod
    def turn(t,g):
        return tuple(sorted(penrose.rotate(p,g) for p in t))

    @staticmethod
    def shift(t,p):
        return tuple(add(a,p) for a in t)

    def atomize(self,a,b):
        delta=sub(b,a)
        for ray in penrose.DIRECTIONS:
            i=next(i for i,v in enumerate(ray) if v)
            n=delta[i]//ray[i]
            if n>0 and mul(n,ray)==delta:
                for _ in range(n):
                    c=add(a,ray)
                    yield a,c
                    a=c
                assert a==b
                return
        raise ValueError("A Penrose side must be an integer chain of unit edges")

    @lru_cache(maxsize=30000)
    def boundary(self,t):
        return tuple(pairs(self.poly(t)))

    def counts(self,a):
        return tuple(n//2 for n in a) if all(n>=0 and n%2==0 for n in a) else None

    @lru_cache(maxsize=30000)
    def mass(self,t):
        a=self.counts(area(self.poly(t),self.cross))
        assert a in ((0,1),(1,0))
        return a

    def verify(self,rings,patch):
        assert chain(self,patch)==frozenset(e for ring in rings for a,b in pairs(ring) for e in self.atomize(a,b))
        assert all(independent.contact(a,b) for a,b in combinations(patch,2))

    def intrudes(self,a,b,tile):
        """Does the target segment meet the open convex tile?"""
        zero,one=(0,0),(1,0)
        lo,hi=(zero,one),(one,one)
        def cmp(u,v):
            return self.sign(sub(field_product(u[0],v[1]),field_product(v[0],u[1])))
        for p,q in pairs(self.poly(tile)):
            edge=sub(q,p)
            u,v=self.cross(edge,sub(a,p)),self.cross(edge,sub(b,p))
            change=sub(v,u)
            direction=self.sign(change)
            if not direction:
                if self.sign(u)<=0:
                    return False
            elif direction>0:
                threshold=(mul(-1,u),change)
                if cmp(threshold,lo)>0:
                    lo=threshold
            else:
                threshold=(u,mul(-1,change))
                if cmp(threshold,hi)<0:
                    hi=threshold
            if cmp(lo,hi)>=0:
                return False
        return True


def lattice_sites(geometry,rings):
    """Sample the exact arrangement cells using rational scanline intersections."""
    model=geometry.model
    s=model.scale
    by_y=defaultdict(list)
    for x,y in model.residues:
        by_y[y].append(x)
    x,y=zip(*rings[0])
    xmin,xmax=min(x),max(x)
    sides=[(mul(s,a),mul(s,b)) for r in rings for a,b in pairs(compact_corners(geometry,r))]
    target=set()
    for j in range(min(y),max(y)):
        for ry,xs in by_y.items():
            height=s*j+ry
            intersections=defaultdict(int)
            for (ax,ay),(bx,by) in sides:
                if min(ay,by)<=height<max(ay,by):
                    intersections[Fraction(ax*(by-ay)+(height-ay)*(bx-ax),by-ay)]+=1 if by>ay else -1
            points=sorted(intersections)
            assert all(p.denominator!=1 or not (s*xmin<=p<s*xmax) or p.numerator%s not in xs
                       for p in points)
            winding=0
            for a,b in zip(points,points[1:]):
                winding-=intersections[a]
                if not winding:
                    continue
                assert winding==1
                for rx in xs:
                    first=max(xmin,(a-rx)//s+1)
                    stop=min(xmax,ceil((b-rx)/s))
                    target.update((s*i+rx,height) for i in range(first,stop))
            assert not points or winding==intersections[points[-1]]
    return frozenset(target)
