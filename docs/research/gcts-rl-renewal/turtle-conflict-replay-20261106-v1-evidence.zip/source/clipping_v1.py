"""Exact convex clipping over Q(phi), with rational coordinates as a subfield."""
from fractions import Fraction
from functools import lru_cache
from math import lcm

from geometry_v1 import add, area, field_product, intersects, mul, pairs, sub
from model_v1 import sign as field_sign
from triangle_geometry_v1 import triangulate

ZERO=(0,0)
REAL=((2,0),(-1,1),(0,-1),(0,-1))


def sign(x):
    return field_sign(*x)


def divide(x,y):
    a,b=y
    norm=a*a+a*b-b*b
    assert norm
    return field_product(x,(Fraction(a+b)/norm,-Fraction(b)/norm))


def scl(x,f):
    return tuple(f*v for v in x)


def psub(a,b):
    return sub(a[0],b[0]),sub(a[1],b[1])


def padd(a,b):
    return add(a[0],b[0]),add(a[1],b[1])


def product(p,f):
    return field_product(p[0],f),field_product(p[1],f)


def determinant(p,q):
    return sub(field_product(p[0],q[1]),field_product(p[1],q[0]))


def side(a,b,p):
    return determinant(psub(b,a),psub(p,a))


def twice(poly):
    total=ZERO
    for a,b in pairs(poly):
        total=add(total,determinant(a,b))
    return total


def part(poly):
    if len(poly)<3:
        return ()
    poly=tuple(poly)
    signed=sign(twice(poly))
    assert signed>=0
    return poly if signed else ()


def split(poly,a,b):
    inside,outside=[],[]
    for p,q in pairs(poly):
        u,v=side(a,b,p),side(a,b,q)
        s,t=sign(u),sign(v)
        if s>=0:
            inside.append(p)
        if s<=0:
            outside.append(p)
        if s*t<0:
            x=padd(p,product(psub(q,p),divide(u,sub(u,v))))
            inside.append(x)
            outside.append(x)
    return part(inside),part(outside)


def subtract(poly,cutter):
    outside=[]
    for a,b in pairs(cutter):
        poly,excess=split(poly,a,b)
        if excess:
            outside.append(excess)
        if not poly:
            break
    return outside


def intersection(poly,cutter):
    for a,b in pairs(cutter):
        poly,_=split(poly,a,b)
        if not poly:
            break
    return twice(poly) if poly else ZERO


def center(poly):
    n=len(poly)
    return tuple(tuple(sum(p[j][k] for p in poly)/Fraction(n) for k in range(2)) for j in range(2))


def floor_positive(x):
    assert sign(x)>=0
    a,b=x
    low,high=0,int(abs(a)+2*abs(b))+2
    while high-low>1:
        m=(low+high)//2
        if sign(sub(x,(m,0)))>=0:
            low=m
        else:
            high=m
    return low


class Core:
    def __init__(self,region,polygons):
        self.region=region
        self.g=region.g
        self.raw=polygons
        self.polygons=[]
        for den,raw in polygons:
            assert type(den) is int and den>0
            assert len(raw)>=3
            poly=tuple(self.point(p,den) for p in raw)
            assert all(sign(side(a,b,p))>0 for a,b in pairs(poly) for p in poly if p not in (a,b))
            assert all(region.inside(p,den) for p in raw)
            for a,b in pairs(raw):
                assert not any(intersects(a,b,mul(den,p),mul(den,q),self.g.cross,self.g.sign,
                                          self.g.unit,self.g.transverse) for p,q in region.lines)
            self.polygons.append(poly)
        assert self.polygons
        self.polygons=tuple(self.polygons)

    def point(self,p,den=1):
        f=Fraction(1,den)
        if self.g.kind=="turtle":
            return (p[0]*f,0),(p[1]*f,0)
        real=tuple(sum(q*r[k] for q,r in zip(p,REAL,strict=True))*f/2 for k in range(2))
        imag=scl(self.g.cross(self.g.unit,p),f)
        return real,imag

    @lru_cache(maxsize=15000)
    def pieces(self,tile):
        poly=self.g.poly(tile)
        rings=triangulate(poly) if self.g.kind=="turtle" else [poly]
        return tuple(tuple(self.point(p) for p in ring) for ring in rings)

    def forces(self,edge):
        p=self.point(add(*edge),2)
        return any(all(sign(side(a,b,p))>0 for a,b in pairs(poly)) for poly in self.polygons)

    def contains(self,tile,p):
        if self.g.kind=="turtle":
            x,y=map(lambda a:Fraction(a[0]),p)
            den=lcm(x.denominator,y.denominator)
            return self.g.wind(self.g.poly(tile),(int(x*den),int(y*den)),den)!=0
        return any(all(sign(side(a,b,p))>=0 for a,b in pairs(poly)) for poly in self.pieces(tile))

    def subtract(self,polys,tiles):
        for t in tiles:
            for piece in self.pieces(t):
                polys=tuple(q for p in polys for q in subtract(p,piece))
                if not polys:
                    return ()
        return polys

    def counts_area(self):
        total=ZERO
        for r in self.region.rings:
            value=area(r,self.g.cross)
            total=add(total,(value[0],0) if self.g.kind=="turtle" else value)
        unit=self.g.tile_area if self.g.kind=="turtle" else 2
        return floor_positive(scl(total,Fraction(1,unit)))

    def receipt(self,patch):
        records=[]
        for poly in self.polygons:
            original=twice(poly)
            obtained=ZERO
            for tile in patch:
                for shape in self.pieces(tile):
                    obtained=add(obtained,intersection(poly,shape))
            assert original==obtained
            records.append(tuple((Fraction(x).numerator,Fraction(x).denominator) for x in original))
        return records
