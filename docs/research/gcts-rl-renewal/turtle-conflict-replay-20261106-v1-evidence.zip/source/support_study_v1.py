"""Audit shared-conflict cuts and compare them with forced-batch search."""
from collections import defaultdict
from pathlib import Path
from statistics import median
from time import perf_counter
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from collar_audit_v1 import Audit
from geometry_v1 import add, sub
from site_cover_study_v1 import (
    Board, Region, audit_cover, audit_negative, budget, cases, independent_domains, load, save, search, setup,
)
from support_search_v1 import run


def offsets(g):
    """Generate conflicts by direct support translations, without packed masks."""
    s = g.model.scale
    buckets = {}
    for h, _, _ in g.bases:
        groups = defaultdict(list)
        for x, y in g.sites((h, 0, 0)):
            groups[x % s, y % s].append((x, y))
        buckets[h] = groups
    return {h: tuple(sorted({(k, (ax-bx)//s, (ay-by)//s)
                              for k, other in buckets.items() for r, a in shape.items()
                              for ax, ay in a for bx, by in other[r]}))
            for h, shape in buckets.items()}


def component_basis(g):
    s = g.model.scale
    for tile in g.bases:
        support = g.sites(tile)
        assert len(support) == 240
        cells = {(x//s, y//s) for x, y in support}
        queue = [min(cells)]
        seen = set(queue)
        for p in queue:
            for direction in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                q = add(p, direction)
                if q in cells and q not in seen:
                    seen.add(q)
                    queue.append(q)
        assert seen == cells
    return len(g.bases)


def audit_marks(region, result, translate, retain_first=False):
    g = region.g
    domains = independent_domains(region)
    occupied, disabled = set(), set()
    patch = result["patch"]
    at = 0
    first = None
    for mark in result["marks"]:
        assert at <= mark["chosen"] <= len(patch)
        for t in patch[at:mark["chosen"]]:
            part = g.sites(t)
            assert not occupied & part and t not in disabled
            occupied.update(part)
        at = mark["chosen"]
        q = mark["site"]
        assert q in region.sites and q not in occupied
        options = {t: cells for t, cells in domains(q).items() if t not in disabled and not occupied & cells}
        assert options.keys() == set(mark["choices"]) and len(options) >= 2
        h, x, y = min(options)
        common = []
        for k, dx, dy in translate[h]:
            tile = k, x+dx, y+dy
            if tile in options or tile in disabled:
                continue
            sites = g.sites(tile)
            if sites <= region.sites and not occupied & sites and all(sites & cells for cells in options.values()):
                common.append(tile)
        assert len(common) == mark["cut"]
        disabled.update(common)
        if first is None and retain_first:
            first = dict(site=q, domain=tuple(sorted(options)), chosen=patch[:at], excluded=tuple(sorted(common)))
    assert not disabled.intersection(patch)
    return dict(marks=len(result["marks"]), removed=len(disabled)), first


def transport_mark(g, donors, receivers):
    """Match a marked exclusion at an exact translated receiver site."""
    s = g.model.scale
    delta = sub(receivers["site"], donors["site"])
    assert not any(d % s for d in delta)
    shift = tuple(d//s for d in delta)
    before = {g.shift(tile, shift) for tile in donors["domain"]}
    after = set(receivers["domain"])
    assert before == after
    images = {g.shift(t, shift): t for t in donors["excluded"]}
    t = min(set(receivers["excluded"]) & images.keys())

    def witness(data, pose):
        sites = g.sites(pose)
        return dict(site=data["site"], choices=data["domain"], path=data["chosen"], excluded=pose,
                    overlap=tuple(min(sites & g.sites(choice)) for choice in data["domain"]))

    return dict(shift=shift, donor=witness(donors, images[t]), receiver=witness(receivers, t))


def evaluate(g, rows):
    inspector = Audit(g.model)
    offsets_ = offsets(g)
    kept = {}
    records = []
    for row in rows:
        if row["partition"] != "test":
            continue
        region = Region(g, row["rings"])
        board = Board(region)
        limit = budget(region)
        baseline = search(board, limit, "batch")
        if row["id"] == "repair-14":
            baseline_extended = search(board, 4000, "batch")
            assert baseline_extended["status"] == "POSITIVE"
            audit_cover(inspector, region, baseline_extended["patch"])
        else:
            baseline_extended = None
        arms = {"batch": baseline,
                "waves": run(board, limit, "global"),
                "support": run(board, limit, "support"),
                "components": run(board, limit, "support", components=True)}
        if baseline_extended is not None:
            arms["extended"] = baseline_extended
        short = {"batch": search(board, 100, "batch"),
                 "waves": run(board, 100, "global"),
                 "support": run(board, 100, "support"),
                 "components": run(board, 100, "support", components=True)}
        receipt = {}
        audited_paths = {}
        for name, result in (*arms.items(), *((f"short-{k}", v) for k, v in short.items())):
            if result["status"] == "POSITIVE":
                receipt[name] = audit_cover(inspector, region, result["patch"])
                if result.get("marks") is not None:
                    donor = row["id"] in ("repair-09", "repair-13")
                    key = result["patch"], tuple(tuple(m[k] for k in ("site", "choices", "cut", "chosen"))
                                                 for m in result["marks"])
                    if key not in audited_paths:
                        audited_paths[key] = audit_marks(region, result, offsets_, retain_first=donor)
                    checked, first = audited_paths[key]
                    receipt[name].update(checked)
                    if donor and name == "components":
                        assert first is not None
                        kept[row["id"]] = first
            elif result["status"] == "NEGATIVE":
                receipt[name] = audit_negative(region, result["proof"])
            elif result["status"] == "EXHAUSTED":
                assert baseline["status"] == "NEGATIVE"
        def compact(v):
            return {k: data for k, data in v.items() if k not in ("marks", "proof")}
        records.append(dict(id=row["id"], rings=region.rings, tile_area_count=region.counts[0], limit=limit,
                            arms={k: compact(v) for k, v in arms.items()}, short={k: compact(v) for k, v in short.items()},
                            checked=receipt))
        print(row["id"], [(k, v["status"], v["counts"]["nodes"]) for k, v in arms.items()], flush=True)
    transfer = transport_mark(g, kept["repair-09"], kept["repair-13"])
    return dict(cases=records, transfer=transfer, component_orientations=component_basis(g))


def timing(g, rows):
    report = []
    for row in rows:
        if row["id"] not in ("repair-06", "repair-09", "repair-13", "repair-14"):
            continue
        modes = ("batch", "waves", "support", "components")
        times = defaultdict(list)
        for j in range(5):
            n = j % len(modes)
            for mode in (*modes[n:], *modes[:n]):
                g.sites.cache_clear()
                start = perf_counter()
                region = Region(g, row["rings"])
                board = Board(region)
                if mode == "batch":
                    search(board, budget(region), "batch")
                elif mode == "waves":
                    run(board, budget(region), "global")
                else:
                    run(board, budget(region), "support", components=mode == "components")
                times[mode].append(perf_counter()-start)
        if row["id"] == "repair-14":
            for _ in range(5):
                g.sites.cache_clear()
                start = perf_counter()
                board = Board(Region(g, row["rings"]))
                result = search(board, 4000, "batch")
                assert result["status"] == "POSITIVE"
                times["extended"].append(perf_counter()-start)
        report.append(dict(id=row["id"], median={k: median(v) for k, v in times.items()}))
    return report


def main():
    g, _, _ = setup()
    rows = cases(g)
    if sys.argv[1:] == ["--time"]:
        save("timing", timing(g, rows))
        return
    assert not sys.argv[1:]
    save("support-study", evaluate(g, rows))


if __name__ == "__main__":
    main()
