"""Bind the window index to the previously replayed all-level Turtle rule."""
from pathlib import Path
import sys
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import load, pin

ARCHIVE_SHA256="53fd99d8b215c4d7bbd8b65a4eee5c4bb5cd923d573c4259b0449a9dca7f4234"


def main():
    archive=ROOT/"input/coordinate-evidence-v1.zip"
    assert pin(archive)["sha256"]==ARCHIVE_SHA256
    with ZipFile(archive) as evidence:
        for key in ("coordinate","predictions","bridge","plane-replay"):
            name=f"{key}-v1.json"
            assert evidence.read(f"data/{name}")== (ROOT/"input"/name).read_bytes()
        for key in ("exact-point-model","recovered-production"):
            path=f"input/{key}-v1.json"
            assert evidence.read(path)==(ROOT/path).read_bytes()
        assert evidence.read("source/coordinate_v1.py")== (ROOT/"source/coordinate_v1.py").read_bytes()
    assert load("input/bridge-v1.json")["status"]=="CHECKED_COEFFICIENTWISE_GOLDEN_HEX_CONJUGACY"
    assert load("input/plane-replay-v1.json")["nested_odd_levels"]
    print("Window inputs match the pinned coordinate-rule evidence.")


if __name__=="__main__":
    main()
