"""Replay the geometry, failed edge trees, and held-back Golden Hex comparison."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, pairwise
from math import gcd
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, ROOT_TILE, save
from cluster_v1 import Model, bounds, load, mat
from collar_experiment_v1 import pool
from triangle_geometry_v1 import _strict_sat, triangulate


def freeze(x):
    if isinstance(x,dict):
        return {k:freeze(v) for k,v in x.items()}
    if isinstance(x,list):
        return tuple(map(freeze,x))
    return x


def step(a,b):
    return a[0]-b[0],a[1]-b[1]


def translated(p,x,y):
    return tuple((a+x,b+y) for a,b in p)


def dot(a,b):
    x,y=a
    u,v=b
    return 2*x*u+x*v+y*u+2*y*v


def closest(a,b,center):
    pos,den=center
    s,t=tuple(Fraction(v,den) for v in pos)
    origin=a[0]-s,a[1]-t
    direction=step(b,a)
    u=max(0,min(1,Fraction(-dot(origin,direction),dot(direction,direction))))
    point=tuple(x+u*v for x,v in zip(origin,direction,strict=True))
    return dot(point,point)/2


def exposed(polygons):
    chain=Counter()
    for poly in polygons:
        raw=tuple(pairwise((*poly,poly[0])))
        if sum(x*v-y*u for (x,y),(u,v) in raw)<0:
            raw=tuple((b,a) for a,b in raw)
        for a,b in raw:
            x,y=step(b,a)
            length=gcd(x,y)
            u,v=x//length,y//length
            for i in range(length):
                p,q=((a[0]+j*u,a[1]+j*v) for j in (i,i+1))
                e=tuple(sorted((p,q)))
                chain[e]+=1 if p<q else -1
    assert all(abs(n)<=1 for n in chain.values())
    return {k if v>0 else k[::-1] for k,v in chain.items() if v}


class Audit:
    def __init__(self,model):
        self.model=model
        self.geom=Geometry(model)
        self.tri={g:triangulate(poly) for g,poly in model.polygons.items()}
        self.box={g:bounds(p) for g,p in model.polygons.items()}
        self.outgoing=defaultdict(set)
        for g,p in model.polygons.items():
            for a,b in exposed([p]):
                self.outgoing[step(a,b)].add((g,-b[0],-b[1]))
        self.counts=Counter()
        self.transfer={}

    @lru_cache(maxsize=100000)
    def relative_overlap(self,g,h,x,y):
        a,b,c,d=self.box[g]
        p,q,r,s=self.box[h]
        if b<=p+x or q+x<=a or d<=r+y or s+y<=c:
            return False
        self.counts["polygon_overlap_tests"]+=1
        others=[translated(t,x,y) for t in self.tri[h]]
        return any(_strict_sat(a,b) for a in self.tri[g] for b in others)

    def overlap(self,a,b):
        g,x,y=a
        h,u,v=b
        return self.relative_overlap(g,h,u-x,v-y)

    def placements(self,edge):
        (x,y),b=edge
        return {(g,u+x,v+y) for g,u,v in self.outgoing[step(b,(x,y))]}

    def copies(self,tile,rotation):
        if rotation is None:
            return (tile,)
        g,(x,y)=rotation
        def apply(v):
            h,a,b=self.model.action(g,v)
            return h,a+x,b+y
        a=apply(tile)
        b=apply(a)
        assert apply(b)==tile
        return tuple(sorted({tile,a,b}))

    def valid(self,edge,patch,rotation):
        good={}
        for t in self.placements(edge):
            moves=self.copies(t,rotation)
            if any(self.overlap(a,b) for a,b in combinations(moves,2)):
                continue
            if any(self.overlap(a,b) for a in moves for b in patch):
                continue
            good[t]=moves
        return good

    def mark(self,d):
        vector=d["direction"]
        blockers=set(d["blockers"])
        original=d["edge"]
        a,b=original
        assert vector==step(b,a)
        shifted={(g,x-a[0],y-a[1]) for g,x,y in d["patch"]}
        assert blockers<=shifted
        assert original in exposed(self.model.poly(t) for t in d["patch"])
        assert vector!=(0,0)
        choices=self.placements(((0,0),vector))
        covered=set()
        for t,block,point in d["cover"]:
            assert t in choices and t not in covered and block in blockers
            assert self.overlap(t,block)
            assert point in self.model.support(t) and point in self.model.support(block)
            covered.add(t)
        assert covered==choices
        for g,m in self.model.groups.items():
            if m[0][0]*m[1][1]-m[0][1]*m[1][0]==1:
                signature=mat(m,vector),tuple(sorted(self.model.action(g,t) for t in blockers))
                self.transfer.setdefault(signature,set()).add(d["id"])
        self.counts["blocker_marks"]+=1

    def run(self,run,seed,radius):
        center=run["center"]
        points=[p for t in seed for p in self.model.poly(t)]
        assert center==(tuple(map(sum,zip(*points))),len(points))
        # A vertex strictly in the disk has neighboring tile interior in it.
        origin=tuple(Fraction(x,center[1]) for x in center[0])
        assert any(dot(v,v)<2*radius*radius for v in (step(p,origin) for p in points))
        rot=run["rotation"]
        if rot is not None:
            assert {c for t in seed for c in self.copies(t,rot)}==set(seed)
        assert all(not self.overlap(a,b) for a,b in combinations(seed,2))
        status=run["status"]
        if status=="BOUNDED":
            assert run["failure"] is None and run["patch"] is None
            return
        if status=="EXHAUSTED":
            self.refutation(run["failure"],seed,radius,center,rot)
            self.counts["certified_exhaustions"]+=1
            return
        assert status=="COVERED" and run["failure"] is None
        patch=seed
        for edge,t,moves,degree,_ in run["history"]:
            current=exposed(self.model.poly(v) for v in patch)
            assert edge in current and closest(*edge,center)<radius*radius
            choices=self.valid(edge,patch,rot)
            assert choices[t]==moves and len(choices)==degree
            patch=(*patch,*moves)
            self.counts["verified_moves"]+=1
        assert tuple(sorted(patch))==run["patch"]
        actual=exposed(self.model.poly(t) for t in patch)
        assert actual==set(run["boundary"])
        assert all(closest(*e,center)>=radius*radius for e in actual)
        self.counts["certified_covers"]+=1

    def refutation(self,proof,seed,radius,center,rotation):
        records=proof["nodes"]
        seen={}
        def visit(i,patch):
            key=tuple(sorted(patch))
            if i in seen:
                assert seen[i]==key
                return
            seen[i]=key
            node=records[i]
            edge=node["edge"]
            assert edge in exposed(self.model.poly(v) for v in patch)
            assert closest(*edge,center)<radius*radius
            offered=self.valid(edge,patch,rotation)
            branches=dict(node["children"])
            assert len(branches)==len(node["children"]) and set(offered)==set(branches)
            if node["blockers"] is not None:
                a,b=edge
                relative={(g,x-a[0],y-a[1]) for g,x,y in patch}
                assert (step(b,a),node["blockers"]) in self.transfer
                assert set(node["blockers"])<=relative and not offered
                self.counts["replayed_mark_nodes"]+=1
            for t,moves in offered.items():
                assert branches[t]<i
                visit(branches[t],(*patch,*moves))
        visit(proof["root"],seed)
        assert len(seen)==len(records)
        self.counts["failed_states_replayed"]+=len(seen)


def trial_shifts(left,right):
    u,v,w,z=bounds(left)
    a,b,c,d=bounds(right)
    return ((x,y) for x in range(u-b,v-a+1) for y in range(w-d,z-c+1))


def complete_catalogue(audit,shape):
    model=audit.model
    g=audit.geom
    pairs=set()
    root=(ROOT_TILE,)
    p=model.poly(ROOT_TILE)
    edges=exposed([p])
    for h,q in model.polygons.items():
        for x,y in trial_shifts(p,q):
            other=(h,x,y)
            border=exposed([model.poly(other)])
            if any((b,a) in border for a,b in edges) and not audit.overlap(ROOT_TILE,other):
                pairs.add(g.normalize(tuple(sorted((ROOT_TILE,other)))))
    assert pairs==set(shape["pairs"])
    half_turn=[]
    for pair in sorted(pairs):
        moved=g.moved(pair,g.rot2)
        a=min(t[1:] for t in pair)
        b=min(t[1:] for t in moved)
        if g.moved(moved,0,step(a,b))==pair:
            half_turn.append(pair)
    assert tuple(half_turn)==tuple(r["pair"] for r in shape["half_turns"])
    found=0
    for base,row in zip(half_turn,shape["half_turns"],strict=True):
        a=[model.poly(t) for t in base]
        edges=exposed(a)
        motifs=set()
        for rot in g.rot3:
            turned=g.moved(base,rot)
            b=[model.poly(t) for t in turned]
            for dx,dy in trial_shifts([v for p in a for v in p],[v for q in b for v in q]):
                second=g.moved(turned,0,(dx,dy))
                border=exposed(model.poly(t) for t in second)
                if not any((v,u) in border for u,v in edges):
                    continue
                third=g.moved(second,rot,(dx,dy))
                assert g.moved(third,rot,(dx,dy))==base
                joined=(*base,*second,*third)
                if any(audit.overlap(p,q) for p,q in combinations(joined,2)):
                    continue
                motifs.add(g.normalize(tuple(sorted(joined))))
        expected={m["key"] for m in row["assemblies"]}
        assert motifs==expected
        assert row["pair_boundary"]==len(edges)
        for m in row["assemblies"]:
            assert m["perimeter"]==len(exposed(model.poly(t) for t in m["key"]))
        found+=len(motifs)
    return dict(doublets=len(pairs),half_turns=len(half_turn),threefold=found)


def occurrences(geom,proto,patch):
    by_group=defaultdict(list)
    for h,x,y in patch:
        by_group[h].append((x,y))
    target=set(patch)
    found=set()
    for g in geom.model.groups:
        variant=geom.moved(proto,g)
        h,x,y=min(variant,key=lambda t:len(by_group[t[0]]))
        for u,v in by_group[h]:
            placed=geom.moved(variant,0,(u-x,v-y))
            if all(t in target for t in placed):
                found.add(placed)
    return sorted(found)



def motif_audit(audit,collars,motifs):
    patches={str(r["radius"]):set(r["arms"]["orbit"]["patch"])
             for r in collars["receivers"] if r["radius"] in motifs["radii"]}
    tested=0
    for scan in motifs["scans"]:
        for row in scan["shared"]:
            for radius,trial in row["examples"].items():
                cluster=set(trial["base"])
                assert cluster<=patches[radius]
                assert len(cluster)<=motifs["maximum"] and len(trial["peels"])<=scan["peels"]
                def half(tile):
                    g,x,y=audit.model.action(audit.geom.rot2,tile)
                    a,b=trial["shift"]
                    return g,x+a,y+b
                assert {half(p) for p in cluster}==cluster
                for pair in trial["peels"]:
                    a,b=pair
                    assert a!=b and half(a)==b and set(pair)<=cluster
                    border=exposed(audit.model.poly(t) for t in cluster)
                    assert (exposed([audit.model.poly(a)])|exposed([audit.model.poly(b)]))&border
                    cluster-=set(pair)
                    assert cluster
                    # Check connectivity using the exact exposed-edge incidence.
                    edges=defaultdict(set)
                    for t in cluster:
                        for e in exposed([audit.model.poly(t)]):
                            edges[tuple(sorted(e))].add(t)
                    graph=defaultdict(set)
                    for side in edges.values():
                        for t in side:
                            graph[t].update(side-{t})
                    seen={min(cluster)}
                    pending=list(seen)
                    while pending:
                        add=graph[pending.pop()]-seen
                        seen.update(add)
                        pending.extend(add)
                    assert seen==cluster
                final=tuple(sorted(cluster))
                assert final==trial["patch"] and audit.geom.normalize(final)==row["key"]
                assert len(final)==row["tiles"] and len(exposed(audit.model.poly(t) for t in final))==row["perimeter"]
                assert audit.geom.ring(final)
                tested+=1
    return tested

def main():
    source=load("input/exact-point-model-v1.json")
    assert not source["initial_markings"]
    audit=Audit(Model(source))
    shape=freeze(load("data/assemblies-v1.json"))
    collars=freeze(load("data/collars-v1.json"))
    counts=complete_catalogue(audit,shape)
    for mark in collars["donors"]:
        audit.mark(mark)
    candidates=pool(shape)
    assert set(candidates)=={r["seed"] for r in collars["screened"]}
    for row in collars["screened"]:
        assert candidates[row["seed"]]["id"]==row["id"]
        audit.run(row["plain"],row["seed"],collars["screen_radius"])
        if row["marked"] is not None:
            audit.run(row["marked"],row["seed"],collars["screen_radius"])
    print("screen",dict(audit.counts),flush=True)
    for row in collars["training"]:
        audit.run(row["run"],collars["alternative"],row["radius"])
    for receiver in collars["receivers"]:
        for name,row in receiver["arms"].items():
            audit.run(row,collars["selected_seed"],receiver["radius"])
        print("receiver",receiver["radius"],dict(audit.counts),flush=True)
    motifs=freeze(load("data/motifs-v1.json"))
    verified_motifs=motif_audit(audit,collars,motifs)
    # Reference coordinates enter only after the independent searches and checks.
    ref=freeze(load("input/comparison-v1.json"))
    geom=audit.geom
    pair=geom.normalize(ref["P0"])
    triple=geom.normalize(ref["T1"])
    assert pair==collars["selected_pair"] and triple==collars["selected_seed"]
    larger=[]
    for receiver in collars["receivers"]:
        row=receiver["arms"]["orbit"]
        if row["status"]=="COVERED":
            matches={name:len(occurrences(geom,ref[name],row["patch"])) for name in ("P0","T1","P1","T2")}
            larger.append(dict(radius=receiver["radius"],motifs=matches))
    target=geom.normalize(ref["P1"])
    rankings=[]
    for scan in motifs["scans"]:
        cohort=[r for r in scan["shared"] if r["tiles"]==len(target)]
        idx=next((i for i,r in enumerate(cohort,1) if r["key"]==target),None)
        rankings.append(dict(peels=scan["peels"],population=len(cohort),rank=idx,
                             perimeter=cohort[idx-1]["perimeter"] if idx is not None else None))
    save("data/audit-v1.json",dict(status="AUDITED_SHAPE_ONLY_TURTLE_ASSEMBLIES_AND_COLLARS",
        catalogue=counts,counts=audit.counts,matched_pair="P0",matched_seed="T1",occurrences=larger,
        checked_motifs=verified_motifs,parallelogram_rank=rankings))


if __name__=="__main__":
    main()
