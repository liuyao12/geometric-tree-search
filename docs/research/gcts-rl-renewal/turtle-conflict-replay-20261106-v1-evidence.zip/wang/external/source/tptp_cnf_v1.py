"""Read the CNF subset used by the selected TPTP group benchmarks."""
from functools import reduce
from html import unescape
from pathlib import Path
import re


def problem_text(html):
    matches = re.findall(r"<pre>(.*?)</pre>", html, re.S)
    assert len(matches) == 1
    return unescape(re.sub(r"</?a\b[^>]*>", "", matches[0]))


TOKEN = re.compile(r"\s+|%[^\n]*|[a-zA-Z][a-zA-Z0-9_]*|'[A-Za-z0-9/_\.\-]+'|!=|[=(),.|~]")


def join(op, formulas):
    return reduce(lambda a, b: [op, a, b], formulas)


class CNF:
    def __init__(self, root):
        self.root = root
        self.functions = {}
        self.predicates = {}
        self.rows = []
        self.files = set()

    def parse(self, filename):
        assert re.fullmatch(r"(?:Axioms/)?GRP[0-9]{3}-[0-9]+\.(?:ax|p)", filename)
        if filename in self.files:
            return
        self.files.add(filename)
        data = (self.root / filename).read_text()
        tokens = []
        end = 0
        for item in TOKEN.finditer(data):
            assert item.start() == end, data[end:item.start()]
            end = item.end()
            token = item.group()
            if not token.isspace() and not token.startswith("%"):
                tokens.append(token)
        assert end == len(data)
        stream = iter(tokens)
        current = next(stream, None)

        def take(expected=None):
            nonlocal current
            token = current
            assert token is not None and (expected is None or token == expected), (expected, token)
            current = next(stream, None)
            return token

        variables = set()

        def term():
            name = take()
            assert re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name)
            if name[0].isupper():
                variables.add(name)
                return "?" + name
            result = [name]
            if current == "(":
                take("(")
                result.append(term())
                while current == ",":
                    take(",")
                    result.append(term())
                take(")")
            return result

        def record_term(value):
            if isinstance(value, str):
                return
            head, *children = value
            signature = [["U"] * len(children), "U"]
            assert self.functions.setdefault(head, signature) == signature
            for child in children:
                record_term(child)

        def literal():
            sign = current != "~"
            if not sign:
                take("~")
            a = term()
            if current in ("=", "!="):
                sign = sign == (take() == "=")
                b = term()
                record_term(a)
                record_term(b)
                value = ["atom", "=U", a, b]
            else:
                assert isinstance(a, list)
                head, *children = a
                signature = ["U"] * len(children)
                assert self.predicates.setdefault(head, signature) == signature
                for child in children:
                    record_term(child)
                value = ["atom", *a]
            return value if sign else ["not", value]

        while current is not None:
            kind = take()
            take("(")
            if kind == "include":
                include = take()
                assert include.startswith("'") and include.endswith("'")
                self.parse(include[1:-1])
            else:
                assert kind == "cnf"
                label = take()
                take(",")
                role = take()
                assert role in ("axiom", "hypothesis", "negated_conjecture")
                take(",")
                variables.clear()
                bracket = current == "("
                if bracket:
                    take("(")
                row = [literal()]
                while current == "|":
                    take("|")
                    row.append(literal())
                if bracket:
                    take(")")
                formula = join("or", row)
                for variable in reversed(sorted(variables)):
                    formula = ["all", "?" + variable, "U", formula]
                self.rows.append(dict(filename=filename, label=label, role=role, formula=formula))
            take(")")
            take(".")

    def source(self, filename):
        self.parse(filename)
        premises = [r["formula"] for r in self.rows if r["role"] != "negated_conjecture"]
        negation = [r["formula"] for r in self.rows if r["role"] == "negated_conjecture"]
        assert negation and not (self.functions.keys() & self.predicates.keys())
        return dict(id=Path(filename).stem, sorts=["U"], equality=True, functions=self.functions,
                    predicates=self.predicates, premises=premises, goal=["not", join("and", negation)])
