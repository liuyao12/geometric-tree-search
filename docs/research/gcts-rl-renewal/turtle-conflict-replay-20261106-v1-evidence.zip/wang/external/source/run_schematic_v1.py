"""Generate, audit and replay the three schematic equality certificates."""
from argparse import ArgumentParser
from collections import Counter
from copy import deepcopy
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))

from schematic_capsules_v1 import build, encoded, frozen, local_case, origin, verify_bundle
from logical_projection_v1 import projection
from shared_wang_v1 import attach, verify_certificate
from tptp_cnf_v1 import CNF


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
LIFTED = {
    "GRP014-1": "GRP014-1-e-lifted-v1.json",
    "GRP167-1": "GRP167-1-e-lifted-v1.json",
    "GRP002-2": "GRP002-2-marked-completion-lifted-v1.json",
}
SAMPLES = (66, 99)


def read(name):
    return json.loads((DATA / name).read_text())


def write(name, value):
    (DATA / name).write_bytes(encoded(value) + b"\n")


def term_nodes(term):
    return 1 if isinstance(term, str) else 1 + sum(term_nodes(t) for t in term[1:])


def source_case(name):
    return CNF(ROOT / "input").source(name + ".p")


def rejection_audit(source, bundle):
    def rejected(edit, problem=source):
        copy = deepcopy(bundle)
        edit(copy)
        try:
            verify_bundle(problem, copy)
        except (AssertionError, IndexError, KeyError, TypeError, ValueError):
            return
        raise AssertionError("Invalid capsule bundle accepted")

    rejected(lambda c: c["interfaces"][-1]["parents"].__setitem__(0, len(c["interfaces"]) - 1))
    rejected(lambda c: c["interfaces"][65]["parents"].reverse())
    rejected(lambda c: c["interfaces"][65]["clause"][0].__setitem__(0, False))
    rejected(lambda c: c["interfaces"][0].__setitem__("schema", c["interfaces"][1]["schema"]))
    rejected(lambda c: c["records"].pop())
    rejected(lambda c: c["records"][65]["proof"]["lines"][-1].__setitem__("left", 99))
    rejected(lambda c: c["interfaces"][65]["clause"][0][1].__setitem__(1, ["capsule_parameter0"]))
    altered = {**source, "goal": ["not", source["goal"]]}
    # Recompute the outer digest to require rejection by the bound local proof.
    rejected(lambda c: c.__setitem__("source_sha256", sha256(encoded(altered)).hexdigest()), altered)
    colliding = {**source, "functions": {**source["functions"], "capsule_parameter0": [[], "U"]}}
    local, _, params, dead, _ = local_case(colliding, origin(colliding), frozen(bundle["interfaces"]), 65)
    assert all(t[0] not in colliding["functions"] for t in (*params.values(), dead))
    assert len(local["functions"]) == len(colliding["functions"]) + len(params) + 1
    return ["self-reference", "permuted parents", "flipped conclusion", "changed source clause",
            "missing final certificate", "altered primitive dependency", "escaped local parameter",
            "different conjecture with recomputed digest"]


def tile_samples(source, bundle, rebuild):
    roots = origin(source)
    receipts = []
    for number in SAMPLES:
        case, _, _, _, _ = local_case(source, roots, frozen(bundle["interfaces"]), number - 1)
        compact = bundle["records"][number - 1]
        path = DATA / f"GRP014-1-capsule-{number}-wang-v1.json.gz"
        if rebuild:
            full = attach(case, "fol", compact["compiled"], compact["translation"], compact["proof"])
            path.write_bytes(gzip.compress(encoded(full) + b"\n", compresslevel=6, mtime=0))
        else:
            full = json.loads(gzip.decompress(path.read_bytes()))
        assert projection(full) == compact
        receipt = verify_certificate(case, full)
        receipts.append(dict(row=number, **receipt))
    return receipts


def tile_all():
    """Replay each local Wang computation and retain its trace digest."""
    name = "GRP014-1"
    source = source_case(name)
    bundle = read(name + "-capsules-v1.json")
    counts = verify_bundle(source, bundle)
    roots = origin(source)
    interfaces = frozen(bundle["interfaces"])
    receipts = []
    for i, compact in enumerate(bundle["records"]):
        local, _, _, _, _ = local_case(source, roots, interfaces, i)
        try:
            full = attach(local, "fol", compact["compiled"], compact["translation"], compact["proof"])
        except RuntimeError as exc:
            raise RuntimeError(f"Tile audit stopped in capsule {i + 1}: {exc}") from exc
        assert projection(full) == compact
        receipt = verify_certificate(local, full)
        assert receipt["fragment_calls"] == counts[i]
        receipts.append(dict(row=i + 1, sha256=sha256(encoded(full)).hexdigest(), **receipt))
        if (i + 1) % 10 == 0 or i + 1 == len(interfaces):
            print(f"Checked exact Wang traces for {i + 1}/{len(interfaces)} capsules", flush=True)
    write(name + "-all-tile-receipts-v1.json", receipts)


def run(rebuild):
    for filename, item in read("sources-v1.json").items():
        assert sha256((ROOT / "input" / filename).read_bytes()).hexdigest() == item["sha256"], filename
    results = []
    for name, file in LIFTED.items():
        source = source_case(name)
        bundle_name = name + "-capsules-v1.json"
        if rebuild:
            write(bundle_name, build(source, read(file)["rows"]))
        bundle = read(bundle_name)
        counts = verify_bundle(source, bundle)
        rows = bundle["interfaces"]
        refs = Counter(p for r in rows for p in r["parents"])
        terms = (t for b in bundle["records"] for line in b["proof"]["lines"]
                 for _, atom in line["clause"] if atom[0] == "=U" for t in atom[1:])
        result = dict(problem=name, capsules=len(counts), calls=sum(counts), max_calls=max(counts),
                      reused=sum(n > 1 for n in refs.values()), max_term=max(map(term_nodes, terms)),
                      bundle_bytes=(DATA / bundle_name).stat().st_size)
        if name == "GRP014-1":
            result["rejected"] = rejection_audit(source, bundle)
            result["wang"] = tile_samples(source, bundle, rebuild)
            result["row66_uses"] = [i for i, row in enumerate(rows, 1) if 65 in row["parents"]]
            assert len(result["row66_uses"]) == refs[65]
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    if rebuild:
        write("schematic-receipt-v1.json", results)
    else:
        assert results == read("schematic-receipt-v1.json")


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--build", action="store_true")
    mode.add_argument("--tile-all", action="store_true")
    args = parser.parse_args()
    if args.tile_all:
        tile_all()
    else:
        run(args.build)
