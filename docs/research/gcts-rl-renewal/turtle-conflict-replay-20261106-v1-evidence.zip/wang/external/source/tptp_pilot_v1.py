"""Try the frozen equality policy on official TPTP CNF problems."""
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(HERE / "source"), str(ROOT / "source")]
from definition_check_v1 import check
from definitions_v1 import compile_case
from herbrand_v1 import frozen
from lifted_equality_prove_v1 import solve
from lifted_equality_study_v1 import OFFERS, NODES, make_prover
from lifted_prover_v1 import Prover
from tptp_cnf_v1 import CNF, problem_text

PROBLEMS = ("GRP001-1", "GRP001-5", "GRP009-1", "GRP002-2", "GRP167-1")
AXIOMS = ("GRP003-0", "GRP004-0", "GRP004-2")


def write(name, value):
    (HERE / "data" / name).write_text(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def prepare(raw):
    root = HERE / "input"
    (root / "Axioms").mkdir(exist_ok=True)
    manifest = {}
    for group, names in (("Problems/GRP", PROBLEMS), ("Axioms", AXIOMS)):
        for name in names:
            target = f"{name}.p" if group.startswith("Problems") else f"Axioms/{name}.ax"
            text = problem_text((raw / f"{name}.html").read_text())
            (root / target).write_text(text)
            suffix = target.rsplit("/", 1)[-1]
            manifest[target] = dict(sha256=sha256(text.encode()).hexdigest(),
                url=f"https://seetptp.tptp.org/file/TPTPWorld/TPTP/{group}/{suffix}")
    write("sources-v1.json", manifest)


def main():
    if len(sys.argv) > 1:
        prepare(Path(sys.argv[1]))
    manifest = json.loads((HERE / "data/sources-v1.json").read_text())
    for name, entry in manifest.items():
        assert sha256((HERE / "input" / name).read_bytes()).hexdigest() == entry["sha256"], name
    policy = json.loads((ROOT / "data/lifted-equality-policy-v1.json").read_text())
    results = []
    for name in PROBLEMS:
        parser = CNF(HERE / "input")
        source = parser.source(name + ".p")
        normal, translation = compile_case(source)
        check(source, normal, translation)
        plain = Prover(source, normal=normal, offer_cap=OFFERS, node_cap=NODES)
        control, _, _ = solve(source, normal, translation, plain)
        marked = make_prover(source, normal, policy["bias"], frozen(policy["marks"]))
        lifted, proof, trace = solve(source, normal, translation, marked)
        if proof is not None:
            write(f"{name}-logical-v1.json", proof)
            write(f"{name}-lifted-v1.json", trace)
        results.append(dict(id=name, source=source, clauses=parser.rows, files=sorted(parser.files),
                            lifted_axioms=control, learned=lifted))
        print(name, len(parser.rows), control["status"], lifted["status"], lifted["counts"].get("offers"),
              lifted.get("receipt", {}).get("records"), flush=True)
    write("results-v1.json", results)


if __name__ == "__main__":
    main()
