"""Compose source-bound Wang refutations of fresh instances of unit lemmas."""
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "source"))

from check_lifted_unit_v1 import frozen
from tptp_transport_v1 import (
    Certificate, clausify, compact, elaborate, guarded, signature, transport, verify,
)
from herbrand_v1 import inspect_term
from lifted_prover_v1 import subst


FORMAT = "WANG-SCHEMATIC-UNIT-CAPSULES-v1"


def encoded(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


def formula(clause, variables):
    ((sign, atom),) = clause
    body = ("atom", *atom)
    if not sign:
        body = ("not", body)
    for v in reversed(sorted(variables)):
        body = ("all", v, variables[v], body)
    return body


def used_variables(term):
    if isinstance(term, str):
        return {term}
    return set().union(*(used_variables(t) for t in term[1:]))


def interface_check(clause, variables, functions):
    assert isinstance(clause, tuple) and isinstance(variables, dict)
    if not clause:
        assert not variables
        return
    ((sign, (relation, left, right)),) = clause
    assert type(sign) is bool and relation == "=U"
    assert variables == dict.fromkeys(used_variables(left) | used_variables(right), "U")
    assert inspect_term(left, variables, functions) == inspect_term(right, variables, functions) == "U"


def origin(source):
    assert source["sorts"] == ["U"] and source["equality"] is True and not source["predicates"]
    normal, witnesses = clausify(source, 1024)
    assert not witnesses
    _, _, schemas = signature(normal)
    rows = {}
    for row in schemas:
        if row["id"].startswith("formula"):
            assert row["clause"]
            interface_check(row["clause"], row["variables"], source["functions"])
            rows[row["id"]] = dict(clause=row["clause"], types=row["variables"])
    return rows


def local_case(source, roots, interfaces, index):
    row = interfaces[index]
    assert set(row) == {"clause", "types", "schema", "parents"}
    clause, variables, schema, parent_ids = (row[k] for k in ("clause", "types", "schema", "parents"))
    functions = source["functions"].copy()
    interface_check(clause, variables, functions)
    assert bool(clause) == (index < len(interfaces) - 1)
    assert len(parent_ids) <= 2
    assert all(type(p) is int and 0 <= p < index for p in parent_ids)
    if schema is None:
        assert parent_ids
        parents = [interfaces[p] for p in parent_ids]
    else:
        assert not parent_ids and clause
        parents = [roots[schema]]
    names = (f"capsule_parameter{i}" for i in range(len(functions) + len(variables) + 1)
             if f"capsule_parameter{i}" not in functions)
    params = {v: (next(names),) for v in sorted(variables)}
    dead = (next(names),)
    functions.update({name: ([], "U") for (name,) in (*params.values(), dead)})
    ground = tuple((sign, subst(atom, params)) for sign, atom in clause)
    if ground:
        ((sign, atom),) = ground
        denied = formula(((not sign, atom),), {})
    else:
        denied = ("atom", "=U", dead, dead)
    local = dict(id=f"{source['id']}-capsule-{index + 1}", sorts=["U"], equality=True,
                 functions=functions, predicates={},
                 premises=[formula(p["clause"], p["types"]) for p in parents],
                 goal=("not", denied))
    return json.loads(encoded(local)), parents, params, dead, ground


def build_local(local, parents, params, dead, ground, dag, node):
    normal, witnesses = clausify(local, 1024)
    assert not witnesses
    functions, predicates, schemas = signature(normal)
    boundary, guards = guarded(schemas, functions, normal["sorts"])
    builder = Certificate(boundary, functions, predicates, normal["sorts"], guards)
    complete = params | dict.fromkeys(node["dead"], dead)
    maps = [{v: subst(t, complete) for v, t in env.items()} for env in node["maps"]]
    instances = []
    counter = 0
    for j, (parent, env) in enumerate(zip(parents, maps, strict=True), 1):
        assert parent["types"].keys() == env.keys()
        bindings = {}
        for v in sorted(parent["types"]):
            bindings[f"?v{counter}"] = env[v]
            counter += 1
        instances.append(builder.unguard(f"formula{j}-clause1", bindings))
    if node["kind"] == "source":
        inferred, = instances
    elif node["kind"] == "resolve":
        a, b = instances
        ((sign, pivot),) = builder.lines[a]["clause"]
        left, right = (a, b) if sign else (b, a)
        inferred = builder.resolve(left, right, pivot)
    else:
        inferred = elaborate(builder, dag, node, complete, maps, instances)
    assert tuple(builder.lines[inferred]["clause"]) == ground
    if ground:
        ((sign, pivot),) = ground
        denied = builder.unguard(f"formula{len(parents) + 1}-clause1", {})
        left, right = (inferred, denied) if sign else (denied, inferred)
        builder.resolve(left, right, pivot)
    assert not builder.lines[-1]["clause"]
    return transport(local, builder.lines)


def build(source, lifted):
    dag = frozen(lifted)
    roots = origin(source)
    interfaces = [{k: node[k] for k in ("clause", "types", "schema", "parents")} for node in dag]
    records = []
    for i, node in enumerate(dag):
        local, parents, params, dead, ground = local_case(source, roots, interfaces, i)
        normal, translation, proof = build_local(local, parents, params, dead, ground, dag, node)
        records.append(compact(local, normal, translation, proof))
    return dict(format=FORMAT, source_sha256=sha256(encoded(source)).hexdigest(),
                interfaces=interfaces, records=records)


def verify_bundle(source, bundle):
    """Use only the original problem and checked predecessor interfaces."""
    if not __debug__:
        raise RuntimeError("Schematic checking requires Python assertions")
    assert bundle["format"] == FORMAT
    assert bundle["source_sha256"] == sha256(encoded(source)).hexdigest()
    interfaces = frozen(bundle["interfaces"])
    assert interfaces
    roots = origin(source)
    counts = []
    for i, certificate in enumerate(bundle["records"]):
        local, _, _, _, _ = local_case(source, roots, interfaces, i)
        assert certificate["kind"] == "fol"
        counts.append(verify(local, certificate)["records"])
    assert len(counts) == len(interfaces)
    return counts
