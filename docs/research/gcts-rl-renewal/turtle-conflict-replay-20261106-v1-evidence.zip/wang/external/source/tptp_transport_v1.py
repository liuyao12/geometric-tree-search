"""Transport direct-CNF refutations to the standard source-bound Wang checker."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(HERE / "source"), str(ROOT / "source")]
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_closure_v1 import trim
from equality_experiment_v1 import compact
from front_v1 import clausify
from herbrand_v1 import frozen, signature
from lifted_equality_ground_v1 import elaborate
from lifted_equality_v1 import EqualityProver
from lifted_ground_v1 import compile_proof
from logical_projection_v1 import reject, verify
from shared_wang_v1 import attach, verify_certificate
from study_v1 import Certificate, guarded
from tptp_cnf_v1 import CNF
from tptp_pilot_v1 import PROBLEMS, write


class GoalSupport(EqualityProver):
    """Search pairs that have at least one clause descended from the denied goal."""
    def supported(self, left, right):
        return self.nodes[left]["goal_support"] or self.nodes[right]["goal_support"]

    def offer(self, left, i, right, j, factor=False):
        if self.supported(left, right):
            return super().offer(left, i, right, j, factor)
        self.counts["support_skips"] += 1
        return None

    def rewrite(self, equation, target):
        if self.supported(equation[0], target[0]):
            return super().rewrite(equation, target)
        self.counts["support_skips"] += 1
        return None


def path_name(path):
    return "_".join(map(str, path))


def source_routes(source):
    """Recover the direct compiler's universal variables and each conjunct path."""
    counter = 0
    routes = {}

    def walk(formula, path, edges, bindings):
        nonlocal counter
        op, *args = formula
        if op == "and":
            for i, body in enumerate(args):
                yield from walk(body, (*path, i), (*edges, (path, i + 1)), bindings)
        elif op == "all":
            _, sort, body = args
            assert sort == "U"
            direct = f"?v{counter}"
            counter += 1
            typed = {**bindings, direct: "?v" + path_name(path)}
            yield from walk(body, (*path, 0), (*edges, (path, 1)), typed)
        else:
            assert op in ("or", "atom", "not")
            yield path, edges, bindings, formula

    for i, formula in enumerate(source["premises"]):
        for j, route in enumerate(walk(formula, (i,), (), {}), 1):
            routes[f"formula{i + 1}-clause{j}"] = route
    i = len(source["premises"])
    negation, denied = source["goal"]
    assert negation == "not"
    for j, route in enumerate(walk(denied, (i, 0), (), {}), 1):
        routes[f"formula{i + 1}-clause{j}"] = route
    return routes


def transport(source, direct):
    normal, translation = compile_case(source)
    check(source, normal, translation)
    functions, predicates, schemas = signature(normal)
    boundary, guards = guarded(schemas, functions, normal["sorts"])
    builder = Certificate(boundary, functions, predicates, normal["sorts"], guards)
    definitions = {tuple(row["path"]): row["name"] for row in translation["definitions"]}
    routes = source_routes(source)
    indices = []

    def ordinary(row):
        path, edges, variables, formula = routes[row["source"]]
        env = {variables[v]: frozen(t) for v, t in row["bindings"].items()}
        family = f"formula{path[0] + 1}-"

        def resolve(line, site, rule):
            predicate = definitions[site]
            active = [atom for sign, atom in builder.lines[line]["clause"] if sign and atom[0] == predicate]
            assert len(active) == 1
            name = family + f"node-{path_name(site)}-{rule}"
            clause = builder.unguard(name, {v: env[v] for v in boundary[name]["variables"]})
            return builder.resolve(line, clause, active[0])

        def unfold(line, site, node):
            if node[0] != "or":
                assert node[0] in ("atom", "not")
                return line
            line = resolve(line, site, 3)
            for j, child in enumerate(node[1:]):
                line = unfold(line, (*site, j), child)
            return line

        line = builder.unguard(family + "root", {})
        for site, rule in edges:
            if site in definitions:
                line = resolve(line, site, rule)
        return unfold(line, path, formula)

    for row in direct:
        if row["rule"] == "R":
            index = builder.resolve(indices[row["left"]], indices[row["right"]], frozen(row["pivot"]))
        elif row["source"] in routes:
            index = ordinary(row)
        else:
            assert row["rule"] == "G" and not row["source"].startswith("formula")
            index = builder.unguard(row["source"], {v: frozen(t) for v, t in row["bindings"].items()})
        assert set(builder.lines[index]["clause"]) == set(frozen(row["clause"]))
        indices.append(index)
    assert not builder.lines[indices[-1]]["clause"]
    return normal, translation, dict(lines=trim(builder.lines, indices[-1]))


def main():
    results = []
    for name in PROBLEMS:
        parser = CNF(HERE / "input")
        source = parser.source(name + ".p")
        normal, _ = clausify(source, 1024)
        prover = GoalSupport(source, normal=normal, goal_bias=24, offer_cap=120_000, node_cap=30_000)
        status, root = prover.run()
        result = dict(id=name, status=status, counts=dict(prover.counts))
        if root is not None:
            direct, _, _ = compile_proof(prover, prover.proof(root), elaborate)
            write(f"{name}-support-direct-v1.json", dict(lines=direct.lines))
            normal, translation, proof = transport(source, direct.lines)
            certificate = compact(source, normal, translation, proof)
            result.update(direct_lines=len(direct.lines), receipt=verify(source, certificate))
            reject({**source, "goal": ["not", source["goal"]]}, certificate)
            write(f"{name}-support-logical-v1.json", certificate)
            if name == "GRP009-1":
                full = attach(source, "fol", normal, translation, proof)
                result["full_wang"] = verify_certificate(source, full)
                write(f"{name}-support-wang-v1.json", full)
        results.append(result)
        print(name, status, result.get("direct_lines"), result.get("receipt"), flush=True)
    write("support-results-v1.json", results)


if __name__ == "__main__":
    main()
