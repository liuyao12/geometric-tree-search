"""Validate source binding and the exact typed unit-equality DAG independently."""
from herbrand_v1 import inspect_term, signature
from lifted_equality_v1 import replaced
from lifted_marks_v1 import at
from lifted_prover_v1 import subst
from tptp_transport_v1 import clausify


def frozen(value):
    if isinstance(value, list):
        return tuple(map(frozen, value))
    if isinstance(value, dict):
        return {k:frozen(v) for k,v in value.items()}
    return value


def apply(row, env):
    return tuple((sign, subst(atom, env)) for sign,atom in row)


def check_lifted(source, dag):
    dag = frozen(dag)
    normal, _ = clausify(source, 1024)
    functions, _, clauses = signature(normal)
    original = {r["id"]:r for r in clauses if r["id"].startswith("formula")}
    assert dag and not dag[-1]["clause"]
    for i, node in enumerate(dag):
        types, dead = node["types"], node["dead"]
        assert not types.keys() & dead.keys()
        available = types | dead
        clause = node["clause"]
        assert len(clause) <= 1
        if clause:
            sign, atom = clause[0]
            assert type(sign) is bool and atom[0] == "=U" and len(atom)==3
            assert all(inspect_term(t, types, functions)=="U" for t in atom[1:])
        parents = node["parents"]
        kind = node["kind"]
        if kind == "source":
            assert not parents
            row = original[node["schema"]]
            sources = ((row["variables"], row["clause"]),)
        else:
            assert all(type(p) is int and 0<=p<i for p in parents)
            sources = tuple((dag[p]["types"],dag[p]["clause"]) for p in parents)
        used = []
        for (sorts, row), env in zip(sources, node["maps"], strict=True):
            assert env.keys() == sorts.keys()
            assert all(inspect_term(t, available, functions)==sorts[v] for v,t in env.items())
            used.append(apply(row, env))
        if kind in ("source", "eq-instance"):
            assert [clause] == used
        elif kind == "eq-rewrite":
            (donor,), (target,) = used
            assert donor[0]
            j, k, side, path = node["sites"]
            assert j==k==0 and side in (0,1) and path and all(type(p) is int and p>=0 for p in path)
            assert at(target[1], path) == donor[1][side+1]
            changed = replaced(target[1], path, donor[1][2-side])
            assert clause == ((target[0], changed),)
        elif kind == "eq-reflexive":
            ((sign, atom),), = used
            assert not sign and atom[1]==atom[2] and not clause
        else:
            assert kind=="resolve" and not clause
            ((p,a),), ((q,b),) = used
            assert p != q and a == b
    return len(dag)
