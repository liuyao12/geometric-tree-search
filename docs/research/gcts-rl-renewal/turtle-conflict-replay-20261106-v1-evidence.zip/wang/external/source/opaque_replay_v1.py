"""Replay G and R fragments with reversible names for ground expressions."""
from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parents[1] / "source")]
import decode_v1 as decoder
from definition_composition_v1 import signature
from herbrand_v1 import inspect_term
from lifted_native_v1 import CAP, NativeBank, fingerprint
from native_audit_v1 import qualify_fragment
from native_v1 import PUBLISHED_MACHINE
from run_schematic_v1 import DATA, LIFTED, read, source_case
from schematic_capsules_v1 import encoded, frozen, local_case, origin
from shared_wang_v1 import binding


FORMAT = "WANG-OPAQUE-FRAGMENT-BANK-v1"
TARGET = DATA / "opaque-bank-v1.json.gz"
CONTROL = ("GRP014-1", 2, 32)


def records(word):
    return tuple(part + ";" for part in decoder.records(word))


def ground(t):
    return not isinstance(t, str) and all(ground(x) for x in t[1:])


class Names:
    """Keep function heads, closed terms and closed atoms in separate namespaces."""
    def __init__(self, variables=()):
        self.codes = {}
        self.values = {}
        self.variables = dict(zip(variables, (f"{i:b}" for i in range(len(variables))), strict=True))
        self.back = {code: name for name, code in self.variables.items()}

    def label(self, role, value):
        key = role, value
        if key not in self.codes:
            code = f"{len(self.codes):b}"
            self.codes[key] = code
            self.values[code] = key
        return self.codes[key]

    def expression(self, t, atom=False):
        if isinstance(t, str):
            return self.variables[t]
        if ground(t):
            return (self.label("atom" if atom else "term", t),)
        head, *args = t
        label = self.label("predicate" if atom else "function", head)
        return (label, *(self.expression(x) for x in args))

    def expand(self, t, atom=False):
        if isinstance(t, str):
            assert not atom
            return self.back[t]
        role, value = self.values[t[0]]
        if role == ("atom" if atom else "term"):
            assert len(t) == 1
            return value
        assert role == ("predicate" if atom else "function")
        return value, *(self.expand(x) for x in t[1:])

    def clause(self, row):
        return [(sign, self.expression(a, atom=True)) for sign, a in row]

    def open(self, row):
        return tuple((sign, self.expand(a, atom=True)) for sign, a in row)


def wire_term(value):
    if isinstance(value, str):
        return f"%{value},"
    return "(" + value[0] + "." + "".join(map(wire_term, value[1:])) + ")"


def wire_clause(row):
    return "".join(("+" if s else "-") + wire_term(a) for s, a in row)


def fragment(proof, index, sources, functions):
    row = proof[index]
    if row["rule"] == "G":
        schema = sources[row["source"]]
        variables = schema["variables"]
        assert row["bindings"].keys() == variables.keys()
        assert all(inspect_term(t, {}, functions) == variables[v] for v, t in row["bindings"].items())
        names = Names(sorted(variables))
        pattern = names.clause(schema["clause"])
        env = {names.variables[v]: names.expression(row["bindings"][v]) for v in sorted(variables)}
        emitted = [(sign, decoder.instance(a, env)) for sign, a in pattern]
        wire_bindings = "".join(f"={v}:{wire_term(t)}" for v, t in env.items())
        prefix = ">C0:" + wire_clause(pattern) + ";#"
        word = "G0:0:" + wire_bindings + "/" + wire_clause(emitted) + ";"
        return names, prefix, word

    assert row["rule"] == "R"
    parent_ids = row["left"], row["right"]
    assert all(type(p) is int and 0 <= p < index for p in parent_ids)
    names = Names()
    left, right = (wire_clause(names.clause(proof[p]["clause"])) for p in parent_ids)
    pivot = wire_term(names.expression(row["pivot"], atom=True))
    result = wire_clause(names.clause(row["clause"]))
    return names, f">C0:{left};C1:{right};#", f"G0:0:/{left};G1:1:/{right};R10:0:1:{pivot}/{result};"


def match(proof, index, sources, names, parsed, prefix):
    """Check that the accepted wire proves this step after expanding its names."""
    row = proof[index]
    last = parsed[-1]
    assert last["rule"] == row["rule"] and names.open(last["clause"]) == row["clause"]
    boundary = [decoder.clause(s.split(":", 1)[1], template=True)
                for s in decoder.records(prefix[1:-1])]
    if row["rule"] == "G":
        schema = sources[row["source"]]
        assert len(parsed) == 1 and last["schema"] == "0"
        template, = boundary
        assert names.open(template) == schema["clause"]
        expanded = {names.back[v]: names.expand(t) for v, t in last["substitution"].items()}
        assert expanded == row["bindings"]
        return

    assert len(parsed) == 3 and (last["left"], last["right"]) == (0, 1)
    left, right = (proof[row[k]]["clause"] for k in ("left", "right"))
    assert tuple(map(names.open, boundary)) == (left, right)
    assert names.expand(last["pivot"], atom=True) == row["pivot"]
    pivot = row["pivot"]
    assert set(row["clause"]) == (set(left) - {(True, pivot)}) | (set(right) - {(False, pivot)})


def prepare():
    """Bind every capsule to its inputs, then compute the exact compressed tapes."""
    wires = {}
    tally = {}
    control = None
    for file, entry in read("sources-v1.json").items():
        assert sha256((HERE.parent / "input" / file).read_bytes()).hexdigest() == entry["sha256"]
    for name in LIFTED:
        source = source_case(name)
        bundle = read(name + "-capsules-v1.json")
        assert bundle["source_sha256"] == sha256(encoded(source)).hexdigest()
        interfaces = frozen(bundle["interfaces"])
        assert len(interfaces) == len(bundle["records"]) > 0
        roots = origin(source)
        counts = Counter(capsules=len(interfaces))
        keys = set()
        for i, capsule in enumerate(bundle["records"]):
            local, *_ = local_case(source, roots, interfaces, i)
            assert capsule["kind"] == "fol"
            assert capsule["machine_sha256"] == PUBLISHED_MACHINE
            normal = capsule["compiled"]
            binding(local, "fol", normal, capsule["translation"])
            funcs, _, sources, _ = signature(dict(compiled=normal))
            proof = frozen(capsule["proof"]["lines"])
            assert proof and not proof[-1]["clause"]
            for j, line in enumerate(proof):
                names, prefix, word = fragment(proof, j, sources, funcs)
                parsed = decoder.read(prefix, word + "!", require_empty=False)
                match(proof, j, sources, names, parsed, prefix)
                key = fingerprint(prefix, records(word))
                keys.add(key)
                old = capsule["records"][capsule["calls"][j]["fragment"]]
                size, old_size = len(prefix) + len(word), len(old["prefix"]) + len(old["word"])
                counts["calls"] += 1
                counts["wire_chars"] += size
                counts["old_wire_chars"] += old_size
                counts["max_wire"] = max(counts["max_wire"], size)
                counts["max_old_wire"] = max(counts["max_old_wire"], old_size)
                location = name, i + 1, j + 1
                wires.setdefault(key, dict(prefix=prefix, word=word, example=list(location), uses=0,
                                           rule=line["rule"]))
                assert (prefix, word) == (wires[key]["prefix"], wires[key]["word"])
                wires[key]["uses"] += 1
                if location == CONTROL:
                    control = dict(problem=name, capsule=i + 1, record=j + 1, key=key,
                                   old_chars=old_size, chars=size)
        counts["distinct_inputs"] = len(keys)
        tally[name] = dict(counts)
    assert control is not None
    return wires, tally, control


def verify_bank(wires, bank):
    assert bank["format"] == FORMAT and bank["machine"] == PUBLISHED_MACHINE and bank["cap"] == CAP
    traces = bank["traces"]
    assert set(traces) == set(wires)
    machine = NativeBank().verifier
    steps = 0
    repeated_steps = 0
    for key, input_ in wires.items():
        trace = traces[key]
        assert trace["prefix"] == input_["prefix"] and trace["word"] == input_["word"]
        assert qualify_fragment(machine, key, trace) is not None
        steps += trace["steps"]
        repeated_steps += trace["steps"] * input_["uses"]
    return dict(unique_fragments=len(wires), unique_by_rule=dict(Counter(r["rule"] for r in wires.values())),
                implied_steps=steps, implied_steps_without_reuse=repeated_steps)


def build_bank(wires):
    bank = NativeBank()
    for i, (key, input_) in enumerate(wires.items(), 1):
        prefix, word = input_["prefix"], input_["word"]
        try:
            actual, trace, reused = bank.get(prefix, records(word), True)
        except RuntimeError as exc:
            raise RuntimeError(f"Tile limit on {input_['example']} at {len(prefix) + len(word)} chars") from exc
        assert actual == key and not reused and trace["stop"] == bank.verifier.finish
        if i % 25 == 0:
            print(f"Executed {i}/{len(wires)} distinct compact inputs", flush=True)
    return dict(format=FORMAT, machine=PUBLISHED_MACHINE, cap=CAP, traces=bank.traces)


def negative_checks(wires, bank):
    failures = []

    def reject(label, callback):
        try:
            callback()
        except (AssertionError, IndexError, KeyError, TypeError, ValueError):
            failures.append(label)
            return
        raise AssertionError("Invalid compressed certificate accepted: " + label)

    def unit(sign, term):
        return ((sign, ("p", (term,))),)

    proof = [dict(rule="G", source="a", bindings={"?x": ("a",)}, clause=unit(True, "a"))]
    schema = dict(variables={"?x": "U"}, clause=((True, ("p", "?x")),))
    sources = {"a": schema}
    names, prefix, word = fragment(proof, 0, sources, {"a": ([], "U")})
    parsed = decoder.read(prefix, word + "!", require_empty=False)
    altered = [{**proof[0], "bindings": {"?x": ("b",)}}]
    reject("different ground substitution", lambda: match(altered, 0, sources, names, parsed, prefix))
    different = {"a": {**schema, "clause": ((True, ("q", "?x")),)}}
    reject("different source predicate", lambda: match(proof, 0, different, names, parsed, prefix))

    pivot = ("p", ("a",))
    proof = [dict(clause=unit(True, "a")), dict(clause=unit(False, "b")),
             dict(rule="R", left=0, right=1, pivot=pivot, clause=())]
    names, _, _ = fragment(proof, 2, {}, {})
    prefix = ">C0:+(0.);C1:-(0.);#"
    word = "G0:0:/+(0.);G1:1:/-(0.);R10:0:1:(0.)/;"
    parsed = decoder.read(prefix, word + "!")
    reject("two distinct atoms merged into the same name",
           lambda: match(proof, 2, {}, names, parsed, prefix))

    proof[1]["clause"] = unit(False, "a")
    proof[2]["clause"] = unit(True, "b")
    names, prefix, word = fragment(proof, 2, {}, {})
    parsed = decoder.read(prefix, word + "!", require_empty=False)
    reject("resolution output with an added literal",
           lambda: match(proof, 2, {}, names, parsed, prefix))

    key = min(wires, key=lambda k: bank["traces"][k]["steps"])
    trace = bank["traces"][key]
    corrupted = {**bank, "traces": {key: {**trace, "steps": trace["steps"] + 1}}}
    reject("changed tape trace length", lambda: verify_bank({key: wires[key]}, corrupted))
    return failures


def baseline_control(control):
    capsule = read(control["problem"] + "-capsules-v1.json")["records"][control["capsule"] - 1]
    call = capsule["calls"][control["record"] - 1]
    item = capsule["records"][call["fragment"]]
    assert len(item["prefix"]) + len(item["word"]) == control["old_chars"]
    try:
        NativeBank().get(item["prefix"], records(item["word"]), True)
    except RuntimeError as exc:
        assert str(exc) == "Admission exceeded its tape or step budget"
    else:
        raise AssertionError("Uncompressed control did not hit the limit")


def main():
    if not __debug__:
        raise RuntimeError("Opaque replay requires Python assertions")
    wires, tally, control = prepare()
    print(json.dumps(dict(problems=tally, unique=len(wires)), sort_keys=True), flush=True)
    if sys.argv[1:] == ["--plan"]:
        return
    if sys.argv[1:] == ["--control"]:
        baseline_control(control)
        print("Uncompressed control reached the limit", control, flush=True)
        return
    if sys.argv[1:] == ["--build"]:
        bank = build_bank(wires)
        TARGET.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
    else:
        assert not sys.argv[1:]
        bank = json.loads(gzip.decompress(TARGET.read_bytes()))
    control["compact_steps"] = bank["traces"][control["key"]]["steps"]
    report = dict(problems=tally, control=control, rejected=negative_checks(wires, bank),
                  **verify_bank(wires, bank))
    print(json.dumps(report, sort_keys=True), flush=True)
    if sys.argv[1:]:
        (DATA / "opaque-receipt-v1.json").write_bytes(encoded(report) + b"\n")
    else:
        assert report == read("opaque-receipt-v1.json")


if __name__ == "__main__":
    main()
