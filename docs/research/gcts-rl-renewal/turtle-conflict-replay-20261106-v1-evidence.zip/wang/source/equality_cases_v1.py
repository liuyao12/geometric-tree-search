"""Small symbolic arithmetic and incidence requests and finite controls."""
from copy import deepcopy
from itertools import product
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def atom(name, *terms):
    return ["atom", name, *terms]


def eq(a, b):
    return atom("=Nat", a, b)


def all_(v, sort, formula):
    return ["all", v, sort, formula]


def iterate(n, term):
    for _ in range(n):
        term = ["S", term]
    return term


def arithmetic(mode, n):
    constants = {"congruence":("a","b","c"),"cancel":("a","b"),"nonzero":("a","b","zero")}[mode]
    source = dict(id=f"peano-{mode}-{n}", sorts=["Nat"], equality=True,
                  functions={**{k:[[],"Nat"] for k in constants}, "S":[["Nat"],"Nat"]},
                  predicates={})
    a, b, c, zero = (["a"], ["b"], ["c"], ["zero"])
    if mode == "congruence":
        premises = [eq(a,b), eq(b,c)]
        goal = eq(iterate(n,a),iterate(n,c))
    elif mode == "cancel":
        rule = ["implies", eq(iterate(1,"?x"),iterate(1,"?y")), eq("?x","?y")]
        premises = [all_("?x","Nat",all_("?y","Nat",rule)), eq(iterate(n,a),iterate(n,b))]
        goal = eq(a,b)
    else:
        assert mode == "nonzero"
        rule = all_("?x","Nat",["not",eq(iterate(1,"?x"),zero)])
        premises = [rule, eq(a,iterate(n,b))]
        goal = ["not",eq(a,zero)]
    return dict(**source,premises=premises,goal=goal)


def incidence():
    original = json.loads((ROOT/"input/archived-cases-v1.json").read_text())
    source = deepcopy(next(r for r in original if r["id"]=="hilbert-incidence-uniqueness"))
    transfer = deepcopy(source)
    transfer["id"] = "hilbert-incidence-transfer"
    transfer["functions"]["p"] = [[], "Point"]
    transfer["premises"].append(atom("I",["p"],["ell"]))
    transfer["goal"][3][2] = atom("I",["p"],"?m")
    return source, transfer


def addition(n):
    zero=["zero"]
    def plus(x,y):
        return ["plus",x,y]
    x,y="?x","?y"
    first=all_(x,"Nat",eq(plus(x,zero),x))
    second=all_(x,"Nat",all_(y,"Nat",eq(plus(x,["S",y]),["S",plus(x,y)])))
    goal=all_(x,"Nat",eq(plus(x,iterate(n,zero)),iterate(n,x)))
    return dict(id=f"peano-add-successors-{n}",sorts=["Nat"],equality=True,
        functions={"zero":[[],"Nat"],"S":[["Nat"],"Nat"],"plus":[["Nat","Nat"],"Nat"]},
        predicates={},premises=[first,second],goal=goal)


def holds(source, model):
    domains, functions, predicates = (model[k] for k in ("domains","functions","predicates"))

    def term(t, scope):
        if isinstance(t,str):
            return scope[t]
        name,*args=t
        return functions[name][tuple(term(a,scope) for a in args)]

    def truth(node, scope):
        kind,*args=node
        if kind=="atom":
            name,*terms=args
            values=tuple(term(t,scope) for t in terms)
            return values[0]==values[1] if name.startswith("=") else values in predicates[name]
        if kind=="not":
            return not truth(args[0],scope)
        if kind in ("all","exists"):
            v,s,body=args
            values=(truth(body,scope|{v:x}) for x in domains[s])
            return all(values) if kind=="all" else any(values)
        a,b=map(lambda n:truth(n,scope),args)
        return {"implies":not a or b,"and":a and b,"or":a or b,"iff":a==b}[kind]

    for name,(args,out) in source["functions"].items():
        assert set(functions[name])==set(product(*(domains[s] for s in args)))
        assert all(v in domains[out] for v in functions[name].values())
    return [truth(p,{}) for p in source["premises"]],truth(source["goal"],{})


def examples():
    uniqueness,transfer=incidence()
    a=arithmetic("cancel",3)
    no_injectivity={**a,"id":"peano-without-injectivity","premises":a["premises"][1:]}
    no_distinct={**transfer,"id":"hilbert-without-distinctness",
                 "premises":[p for i,p in enumerate(transfer["premises"]) if i!=1]}
    nat=dict(domains={"Nat":(0,1)},functions={"a":{():0},"b":{():1},"c":{():0},"zero":{():0},
                "S":{(0,):0,(1,):0}},predicates={})
    geom=dict(domains={"Point":(0,1),"Line":(0,1)},
             functions={"a":{():0},"b":{():0},"p":{():1},"ell":{():0}},
             predicates={"I":{(0,0),(0,1),(1,0)}})
    result=[(arithmetic("congruence",n),n,None) for n in (2,4,7)]
    result += [(arithmetic("cancel",n),n,None) for n in (2,4,7)]
    result += [(arithmetic("nonzero",3),3,None),(uniqueness,0,None),(transfer,0,None)]
    result += [(no_injectivity,3,nat),(no_distinct,0,geom)]
    result += [(addition(n),n+1,None) for n in (2,4,7)]
    add7=addition(7)
    missing_recursion={**add7,"id":"peano-without-addition-recursion","premises":add7["premises"][:1]}
    add_model=dict(domains={"Nat":(0,1)},functions={"zero":{():0},
                   "S":{(0,):1,(1,):0},"plus":{(x,y):x for x,y in product((0,1),repeat=2)}},
                   predicates={})
    result.append((missing_recursion,8,add_model))
    return result
