"""Bind measured pocket coefficients to already checked Peano obstruction lemmas."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from logical_projection_v1 import projection, verify
from pocket_arithmetic_v1 import statement


def read(name):
    return json.loads((ROOT/name).read_text())


def write(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def main():
    measurements=read("data/residue-summary-v1.json")
    proof_results=read("data/arithmetic-spine-summary-v1.json")
    by_id={r["case"]:r for r in proof_results}
    assert all(p["receipt"]["status"]=="CHECKED" for p in proof_results)
    bank={}
    contexts=[]
    for row in measurements:
        result=row["relation"]
        coefficients=result["measured_area"]
        weights=result["weights"]
        assert all(v>=0 for v in coefficients)
        used=[]
        for i,coefficient in enumerate(coefficients):
            positive={w[i] for w in weights if w[i]>0}
            (stride,)=positive
            assert all(w[i] in (0,stride) for w in weights)
            if coefficient%stride==0:
                continue
            original=statement(stride,coefficient)
            label=original["id"]
            reused=label in bank
            if not reused:
                record=by_id[label]
                bundle=projection(read("data/"+record["artifact"]))
                receipt=verify(original,bundle)
                assert receipt["records"]==record["receipt"]["fragment_calls"]
                name=f"data/{label}-logical-v1.json"
                write(name,bundle)
                bank[label]=dict(path=name,receipt=receipt)
            used.append(dict(coordinate=i,lemma=label,reuse=reused))
        if row["result"]["status"]=="COUNTERMODEL":
            assert not used
        else:
            assert used
        contexts.append(dict(case=row["id"],lemmas=used))
    assert len(bank)==3
    assert sum(u["reuse"] for c in contexts for u in c["lemmas"])==2
    forged=read(bank["area-coefficient-2-1"]["path"])
    try:
        verify(statement(2,2),forged)
    except (AssertionError,ValueError):
        pass
    else:
        raise AssertionError("Foreign arithmetic statement accepted")
    write("data/spine-transfer-v1.json",dict(status="CHECKED_AREA_LEMMA_REUSE",
          contexts=contexts,bank=bank,wrong_goal="REJECTED"))
    print(contexts,flush=True)


if __name__=="__main__":
    main()
