"""Train a small contextual tactic policy and verify held-out source proofs."""
from collections import Counter, defaultdict
from pathlib import Path
from random import Random
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definition_experiment_v1 import attempt
from definitions_v1 import compile_case
from ground_unit_v1 import prove
from lifted_experiment_v1 import save
from tactic_cohort_v1 import cohorts

ACTIONS={
    "lift":("lift",),
    "shallow":("unit0","lift"),
    "one-step":("unit1","lift"),
    "staged":("unit0","unit1","lift"),
}


def context(problem):
    flag=set()
    deepest=0

    def term(t):
        return 1+max((term(x) for x in t[1:]),default=-1) if isinstance(t,list) else 0

    def formula(node):
        nonlocal deepest
        op,*args=node
        flag.add(op)
        if op=="atom":
            deepest=max(deepest,*(term(x) for x in args[1:]),0)
        elif op in ("all","exists"):
            formula(args[2])
        else:
            for a in args:
                formula(a)

    for node in (*problem["premises"],problem["goal"]):
        formula(node)
    if deepest>=2:
        return "nested terms"
    if deepest:
        return "shallow terms"
    if "iff" in flag:
        return "biconditional"
    if "exists" in flag:
        return "explicit existence"
    return "relational"


def execute_action(action,case,normal,proofs):
    if action!="lift":
        b,stats=prove(normal,int(action[-1]))
        cost=sum(stats.get(x,0) for x in ("terms","certified_schemas","checked_groundings","watcher_visits"))
        return dict(status=stats["status"],work=cost,stats=stats,
                    proof=dict(lines=b.lines) if proofs and b else None)
    r=attempt(case,normal,keep_proof=proofs)
    cost=len(normal["clauses"])+sum(r["counts"].get(x,0) for x in ("offers","equations"))
    return dict(status=r["status"],work=cost,stats=r["counts"],proof=r["proof"])


def trials(case,*,proofs):
    normal,cert=compile_case(case)
    check(case,normal,cert)
    options={a:execute_action(a,case,normal,proofs) for a in ("unit0","unit1","lift")}
    return options,normal,cert


def run(schedule,actions):
    work=0
    outcome=None
    steps=[]
    for action in ACTIONS[schedule]:
        attempt_=actions[action]
        steps.append(action)
        work+=attempt_["work"]
        outcome=attempt_["status"]
        if outcome=="PROVED":
            break
    return dict(status=outcome,work=work,steps=steps,final_action=steps[-1])


def solve(case,normal,schedule):
    work=0
    steps=[]
    for action in ACTIONS[schedule]:
        trial=execute_action(action,case,normal,True)
        work+=trial["work"]
        steps.append(action)
        if trial["status"]=="PROVED":
            break
    return dict(status=trial["status"],work=work,steps=steps,final_action=steps[-1]),trial["proof"]


def learn(rows,seed=614731,epochs=9):
    rng=Random(seed)
    rewards=defaultdict(lambda:defaultdict(list))
    episodes=[]
    for _ in range(epochs):
        order=list(rows)
        rng.shuffle(order)
        for row in order:
            f=row["context"]
            bank=rewards[f]
            untried=[a for a in ACTIONS if a not in bank]
            if untried or rng.random()<.15:
                action=rng.choice(untried or list(ACTIONS))
            else:
                action=min(bank,key=lambda a:(sum(bank[a])/len(bank[a]),tuple(ACTIONS).index(a)))
            trial=run(action,row["trials"])
            loss=trial["work"]+(1_000_000 if trial["status"]!="PROVED" else 0)
            bank[action].append(loss)
            episodes.append(dict(id=row["id"],context=f,action=action,loss=loss))
    assert all(set(v)==set(ACTIONS) for v in rewards.values())
    means={f:{a:dict(total=sum(v),episodes=len(v)) for a,v in bank.items()} for f,bank in rewards.items()}
    frozen={f:min(m,key=lambda a:(m[a]["total"]/m[a]["episodes"],tuple(ACTIONS).index(a)))
            for f,m in means.items()}
    return frozen,episodes,means


def main():
    train,receivers=cohorts()
    donors=[]
    for case in train:
        actions,_,_=trials(case,proofs=False)
        donors.append(dict(id=case["id"],context=context(case),trials=actions))
    frozen,episodes,rewards=learn(donors)
    save("data/tactic-training-v1.json",dict(status="FROZEN_TACTIC_POLICY",training=donors,
                                           policy=frozen,episodes=episodes,reward_records=rewards))
    print("Policy",frozen,flush=True)
    results=[]
    for case in receivers:
        actions,normal,cert=trials(case,proofs=True)
        feat=context(case)
        winner=frozen.get(feat,"lift")
        tested={a:run(a,actions) for a in ACTIONS}
        selected=tested[winner]
        proof=actions[selected["final_action"]]["proof"]
        results.append(dict(id=case["id"],original=case,compiled=normal,certificate=cert,context=feat,
             selected_schedule=winner,selected=selected,compared=tested,
             raw={a:{k:v for k,v in row.items() if k!="proof"} for a,row in actions.items()},proof=proof))
        print(case["id"],feat,winner,selected["status"],selected["work"],tested["lift"]["status"],
              tested["lift"]["work"],flush=True)
    totals={a:Counter(r["compared"][a]["status"] for r in results) for a in ACTIONS}
    totals["learned"]=Counter(r["selected"]["status"] for r in results)
    save("data/tactic-receivers-v1.json",dict(status="CHECKED_TACTIC_RECEIVERS",results=results,counts=totals))


if __name__=="__main__":
    main()
