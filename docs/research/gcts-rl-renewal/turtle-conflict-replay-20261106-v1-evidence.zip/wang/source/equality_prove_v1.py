"""Search arbitrary first-order input with the bounded equality tactic."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_closure_v1 import prove
from equality_experiment_v1 import compact
from logical_projection_v1 import verify as verify_records
from shared_wang_v1 import attach, natural, verify_certificate
from term_demand_v1 import domain as demanded


def search(source, depth, terms):
    normal,translation=compile_case(source)
    check(source,normal,translation)
    attempts=[]
    modes=("full","rewrite") if terms=="both" else (terms,)
    for d in range(depth+1):
        for mode in modes:
            selected=None
            if mode=="rewrite":
                selected,_=demanded(source,normal,d)
                if selected is None:
                    attempts.append(dict(depth=d,terms=mode,status="TERM_BOUND"))
                    continue
            status,proof,stats=prove(source,normal,d,selected=selected)
            attempts.append(dict(depth=d,terms=mode,status=status,counts=stats))
            if proof is not None:
                return normal,translation,proof,attempts
    return normal,translation,None,attempts


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--depth",type=natural,required=True)
    parser.add_argument("--terms",choices=("full","rewrite","both"),default="both")
    parser.add_argument("--full",action="store_true",help="write full Wang transition witnesses")
    args=parser.parse_args()
    source=json.loads(args.source.read_text())
    if source.get("equality") is not True:
        parser.error("this tactic requires the equality flag in the source")
    normal,translation,proof,attempts=search(source,args.depth,args.terms)
    if proof is None:
        print(json.dumps(dict(status="NO_REFUTATION_FOUND",attempts=attempts),sort_keys=True))
        return 2
    if args.full:
        result=attach(source,"fol",normal,translation,proof)
        receipt=verify_certificate(source,result)
    else:
        result=compact(source,normal,translation,proof)
        receipt=verify_records(source,result)
    with args.output.open("x") as handle:
        json.dump(result,handle,sort_keys=True,separators=(",",":"))
        handle.write("\n")
    print(json.dumps(dict(receipt=receipt,attempts=attempts),sort_keys=True))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
