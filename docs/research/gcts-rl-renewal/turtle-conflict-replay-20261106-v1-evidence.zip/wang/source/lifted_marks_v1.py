"""Syntactic no-unifier witnesses that can be reapplied at term addresses."""
from collections import defaultdict
from itertools import combinations


def rigid(a,b):
    return isinstance(a,tuple) and isinstance(b,tuple) and (a[0]!=b[0] or len(a)!=len(b))


def clashes(a,b,path=()):
    if rigid(a,b):
        yield path
    elif isinstance(a,tuple) and isinstance(b,tuple):
        for i,(x,y) in enumerate(zip(a[1:],b[1:],strict=True)):
            yield from clashes(x,y,path+(i,))


def positions(atom):
    vars_=defaultdict(list)
    def visit(term,path):
        if isinstance(term,str):
            vars_[term].append(path)
        else:
            for i,t in enumerate(term[1:]):
                visit(t,path+(i,))
    visit(atom,())
    return vars_.values()


def at(term,path):
    for i in path:
        if isinstance(term,str) or i+1>=len(term):
            return None
        term=term[i+1]
    return term


def discover(a,b):
    # Root predicates are already identical. A shallow head clash has its
    # own indexed guard, so a transferable mark starts deeper in a term.
    for path in clashes(a,b):
        if len(path)>1:
            yield ("rigid",path)
    for i,(pattern,other) in enumerate(((a,b),(b,a))):
        for group in positions(pattern):
            for p,q in combinations(group,2):
                x,y=at(other,p),at(other,q)
                for tail in clashes(x,y):
                    yield ("alias",i,p,q,tail)


def applies(mark,a,b):
    if mark[0]=="rigid":
        _,path=mark
        return rigid(at(a,path),at(b,path))
    kind,i,p,q,tail=mark
    assert kind=="alias"
    pattern,other=(a,b) if i==0 else (b,a)
    v=at(pattern,p)
    return isinstance(v,str) and v==at(pattern,q) and rigid(at(other,p+tail),at(other,q+tail))
