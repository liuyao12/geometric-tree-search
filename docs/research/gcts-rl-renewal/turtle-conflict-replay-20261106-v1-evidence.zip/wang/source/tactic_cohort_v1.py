"""Freeze development episodes and separate Wang tactic receivers."""
from definition_cases_v1 import a, all_, case, exists, implies
from lifted_experiment_v1 import load
from receptor_receivers_v1 import receiver


def chain(label,n):
    preds=[f"{label}P{i}" for i in range(n+1)]
    p=lambda i:a(preds[i],"?x")
    hypotheses=[a(preds[0],["c"])]+[all_("?x",implies(p(i),p(i+1))) for i in range(n)]
    return case(label,{"c":0},dict.fromkeys(preds,1),hypotheses,a(preds[-1],["c"]))


def parity(label,n):
    p=[f"{label}P{i}" for i in range(n+1)]
    atom=lambda i:a(p[i],["c"])
    hypotheses=[["iff",atom(i),atom(i+1)] for i in range(n)]
    return case(label,{"c":0},dict.fromkeys(p,1),hypotheses,["iff",atom(0),atom(n)])


def terms(label,n):
    term=["c"]
    for _ in range(n):
        term=["f",term]
    rule=all_("?x",implies(a("P","?x"),a("P",["f","?x"])))
    return case(label,{"c":0,"f":1},{"P":1},[a("P",["c"]),rule],a("P",term))


def witness(label,n):
    names=[f"{label}Q{i}" for i in range(n+1)]
    source=all_("?x",exists("?y",a("R","?x","?y")))
    first=all_("?x",all_("?y",implies(a("R","?x","?y"),a(names[0],"?y"))))
    rules=[all_("?v",implies(a(names[i],"?v"),a(names[i+1],"?v"))) for i in range(n)]
    return case(label,{"c":0},{"R":2,**dict.fromkeys(names,1)},[source,first,*rules],
                exists("?z",a(names[-1],"?z")))


def addition():
    eq=lambda x,y:a("=U",x,y)
    first=all_("?x",eq(["plus","?x",["zero"]],"?x"))
    second=all_("?x",all_("?y",eq(["plus","?x",["S","?y"]],["S",["plus","?x","?y"]])))
    return case("peano-add-one",{"zero":0,"S":1,"plus":2},{},[first,second],
                eq(["plus",["S",["zero"]],["S",["zero"]]],["S",["S",["zero"]]]),equality=True)


def cohorts():
    archived={r["id"]:r for r in load("input/cases-v1.json")+load("input/new-cases-v1.json")
              +load("input/tutorial-cases-v1.json")["cases"]}
    train=[]
    for n in (3,5,7,9):
        train.extend([receiver(f"train_choices_{n}",n,"balanced"),chain(f"train_chain_{n}",n),
                      parity(f"train_parity_{n}",n)])
    train.extend(terms(f"train_term_{n}",n) for n in (1,2,4,6))
    train.extend(witness(f"train_witness_{n}",n) for n in (1,3,5,7))
    cases=[
        receiver("balanced_unit_11",11,"balanced"),receiver("balanced_unit_17",17,"balanced"),
        receiver("balanced_unit_23",23,"balanced"),receiver("fresh_wide_17",17,"comb"),
        receiver("fresh_wide_23",23,"comb"),chain("held_chain_11",11),
        parity("held_parity_10",10),terms("held_term_8",8),addition(),
    ]
    for n in ("exists-map","incidence-existence","peano-nonzero-successor","hilbert-incidence-uniqueness",
              "tptp-tutorial-family","tptp-tutorial-capital","quantifier-swap-control"):
        cases.append(archived[n])
    assert not {x["id"] for x in train}&{x["id"] for x in cases}
    return train,cases
