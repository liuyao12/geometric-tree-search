"""Compare on-demand equality with eager axioms on identical finite term domains."""
from collections import defaultdict, deque
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definition_check_v1 import check
from definition_composition_v1 import fragment
from definitions_v1 import compile_case
from depth_ground_v1 import instances
from equality_cases_v1 import examples, holds
from equality_closure_v1 import domain, prove
import herbrand_v1 as fol
from lifted_native_v1 import fingerprint
from logical_projection_v1 import SCHEMA, verify as verify_records
from native_marked_v1 import records
from native_v1 import PUBLISHED_MACHINE
import resolution_v1 as prop
from shared_wang_v1 import attach, verify_certificate
from term_demand_v1 import domain as demanded


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def eager(original,normal,depth,limit=3000,candidate_cap=20000,selected=None):
    _,_,schemas=fol.signature(normal)
    terms=domain(original,normal,depth,64) if selected is None else selected
    if terms is None:
        return dict(status="TERM_BOUND")
    universe={t for values in terms.values() for t in values}
    _,rows,stats=instances(schemas,terms,depth,limit,candidate_cap,allowed_terms=universe)
    if rows is None:
        return stats
    clauses=[frozenset(prop.literals(pair)) for pair in rows]
    stats["ground_instances"]=len(clauses)
    if frozenset() in clauses:
        return dict(**stats,status="PROVED")
    agenda=deque(next(iter(c)) for c in clauses if len(c)==1)
    truth=set()
    watchers=defaultdict(list)
    for clause in clauses:
        for lit in sorted(clause):
            watchers[lit].append(clause)
    status="CLOSED_WITHOUT_REFUTATION"
    while agenda:
        literal=agenda.popleft()
        if literal in truth:
            continue
        if -literal in truth:
            status="PROVED"
            break
        truth.add(literal)
        for clause in watchers[-literal]:
            stats["clause_visits"]=stats.get("clause_visits",0)+1
            if stats["clause_visits"]>1_000_000:
                return dict(**stats,status="WORK_BOUND")
            if clause & truth:
                continue
            rest=[a for a in clause if -a not in truth]
            if not rest:
                status="PROVED"
                break
            if len(rest)==1:
                agenda.append(rest[0])
        if status=="PROVED":
            break
    return dict(**stats,status=status)


def compact(source,normal,translation,proof):
    row=dict(original=source,compiled=normal,definition=dict(proof=proof))
    calls=[]
    items={}
    for i in range(len(proof["lines"])):
        step=fragment(row,proof["lines"],i)
        prefix,word=step.prefix(),step.words()[:-1]
        key=fingerprint(prefix,records(word))
        calls.append(dict(fragment=key,reuse=key in items))
        items[key]=dict(prefix=prefix,word=word)
    return json.loads(json.dumps(dict(schema=SCHEMA,machine_sha256=PUBLISHED_MACHINE,kind="fol",
        compiled=normal,translation=translation,proof=proof,calls=calls,records=items)))


def main():
    suite=[]
    for source,depth,model in examples():
        normal,translation=compile_case(source)
        check(source,normal,translation)
        expected="PROVED" if model is None else "COUNTERMODEL"
        selected, demand = (None,None)
        if "plus" in source["functions"]:
            selected,demand=demanded(source,normal,depth)
            assert selected is not None
        status,proof,stats=prove(source,normal,depth,selected=selected)
        plain=eager(source,normal,depth,selected=selected)
        generous=eager(source,normal,depth,30000,200000,selected=selected)
        label=source["id"]
        row=dict(id=label,source=source,expected=expected,depth=depth,
                 on_demand=dict(status=status,counts=stats),eager=plain,eager_generous=generous)
        if selected is not None:
            row["term_proposal"]=dict(counts=demand,selected=selected,
                full_terms="TERM_BOUND" if domain(source,normal,depth,64) is None else "WITHIN_BOUND")
        if model is not None:
            facts,goal=holds(source,model)
            assert all(facts) and not goal and status!="PROVED"
            row["countermodel"]=dict(domains=model["domains"],functions={f:list(values.items()) for f,values in model["functions"].items()},
                                    predicates={p:sorted(v) for p,v in model["predicates"].items()})
        elif proof is not None:
            bundle=compact(source,normal,translation,proof)
            row["receipt"]=verify_records(source,bundle)
            save(f"data/{label}-logical-v1.json",bundle)
            if label in ("peano-nonzero-3","hilbert-incidence-transfer","peano-add-successors-4"):
                full=attach(source,"fol",normal,translation,proof)
                row["full_wang"]=verify_certificate(source,full)
                save(f"data/{label}-wang-v1.json",full)
        assert status=="PROVED" or model is not None, (label,status)
        suite.append(row)
        print(label, status, plain["status"], generous["status"], stats.get("proof_records"),flush=True)
    save("data/equality-experiment-v1.json",dict(status="CHECKED_EQUALITY_EXPERIMENT",cases=suite))


if __name__=="__main__":
    main()
