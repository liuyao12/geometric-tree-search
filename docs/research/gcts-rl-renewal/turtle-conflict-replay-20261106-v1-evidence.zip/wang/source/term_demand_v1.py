"""Propose bounded ground terms by rewriting only syntax already in view."""
from collections import Counter, deque

import herbrand_v1 as fol


def ground(term):
    return not isinstance(term,str) and all(map(ground,term[1:]))


def tree_size(term):
    return 1+sum(map(tree_size,term[1:]))


def from_premises(original):
    for formula in original["premises"]:
        while formula[0]=="all":
            formula=formula[3]
        if formula[0]=="atom" and formula[1].startswith("="):
            a,b=map(fol.frozen,formula[2:])
            for lhs,rhs in ((a,b),(b,a)):
                if not isinstance(lhs,str) and lhs!=rhs:
                    yield lhs,rhs


def bind(pattern,term,environment):
    if isinstance(pattern,str):
        return environment.setdefault(pattern,term)==term
    return (pattern[0]==term[0] and len(pattern)==len(term) and
            all(bind(x,y,environment) for x,y in zip(pattern[1:],term[1:],strict=True)))


def inst(pattern,environment):
    return environment[pattern] if isinstance(pattern,str) else (pattern[0],*(
        inst(x,environment) for x in pattern[1:]))


def rewrites(term,rules):
    for left,right in rules:
        environment={}
        if bind(left,term,environment):
            try:
                yield inst(right,environment)
            except KeyError:
                continue
    for i,arg in enumerate(term[1:],1):
        for output in rewrites(arg,rules):
            yield (*term[:i],output,*term[i+1:])


def domain(original,normal,depth,limit=64):
    functions=normal["functions"]
    seeds=set()
    def collect(term):
        if isinstance(term,str):
            return
        for sub in term[1:]:
            collect(sub)
        if ground(term) and fol.depth(term)<=depth:
            seeds.add(term)
    for row in normal["clauses"]:
        for _,atom in row["clause"]:
            for term in atom[1:]:
                collect(fol.frozen(term))
    known={s:set() for s in normal["sorts"]}
    for term in seeds:
        known[fol.inspect_term(term,{},functions)].add(term)
    for sort,terms in known.items():
        if not terms:
            choices=sorted(name for name,(args,out) in functions.items() if not args and out==sort)
            terms.add((choices[0],))
    size_cap=max(tree_size(t) for values in known.values() for t in values)+depth
    rules=tuple(from_premises(original))
    queue=deque(sorted(t for values in known.values() for t in values))
    counts=Counter(seeds=len(queue), rules=len(rules))
    if any(len(values)>limit for values in known.values()):
        return None,dict(counts)

    def add(term):
        sort=fol.inspect_term(term,{},functions)
        if term in known[sort]:
            return
        if len(known[sort])>=limit:
            counts["term_cap_hits"]+=1
            return
        for child in term[1:]:
            add(child)
        if any(child not in known[fol.inspect_term(child,{},functions)] for child in term[1:]):
            return
        if len(known[sort])>=limit:
            counts["term_cap_hits"]+=1
            return
        known[sort].add(term)
        queue.append(term)
        counts["proposed_terms"]+=1

    while queue:
        term=queue.popleft()
        for other in rewrites(term,rules):
            counts["rewrite_proposals"]+=1
            if fol.depth(other)<=depth and tree_size(other)<=size_cap:
                add(other)
    return {sort:sorted(values) for sort,values in known.items()},dict(counts)
