"""Generate arithmetic statements for sealed-pocket area coefficients."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SORT="Nat"
Z=["zero"]


def succ(t,n=1):
    for _ in range(n):
        t=["S",t]
    return t


def eq(a,b):
    return ["atom","="+SORT,a,b]


def q(tag,v,body):
    return [tag,v,SORT,body]


def statement(scale,coefficient):
    x,y="?x","?y"
    f=lambda t:["F",t]
    axioms=[
        q("all",x,["not",eq(succ(x),Z)]),
        q("all",x,q("all",y,["implies",eq(succ(x),succ(y)),eq(x,y)])),
        q("all",x,["or",eq(x,Z),q("exists",y,eq(x,succ(y)))]),
        eq(f(Z),Z),
        q("all",x,eq(f(succ(x)),succ(f(x),scale))),
    ]
    return dict(id=f"area-coefficient-{scale}-{coefficient}",sorts=[SORT],
                functions={"zero":[[],SORT],"S":[[SORT],SORT],"F":[[SORT],SORT]},
                predicates={},equality=True,premises=axioms,
                goal=q("all",x,["not",eq(f(x),succ(Z,coefficient))]))


def main():
    for scale,coefficient in ((2,1),(2,3),(5,9)):
        name=f"coefficient-{scale}-{coefficient}.json"
        (ROOT/"input"/name).write_text(json.dumps(statement(scale,coefficient),sort_keys=True)+"\n")


if __name__=="__main__":
    main()
