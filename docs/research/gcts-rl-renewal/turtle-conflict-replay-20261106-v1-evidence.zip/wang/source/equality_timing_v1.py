"""Time proof search, compact checking and the original-formula Z3 control."""
from collections import defaultdict
from pathlib import Path
import json
import platform
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definitions_v1 import compile_case
from equality_closure_v1 import prove
from logical_projection_v1 import verify
from term_demand_v1 import domain as demanded
from z3_control_v1 import Language, evaluate, z3


def measure(fn):
    start=perf_counter_ns()
    value=fn()
    return value,perf_counter_ns()-start


def main():
    suite=json.loads((ROOT/"data/equality-experiment-v1.json").read_text())["cases"]
    values=defaultdict(lambda:defaultdict(list))
    for trial in range(5):
        for row in suite if trial%2==0 else reversed(suite):
            label=row["id"]
            source=row["source"]
            compact=None
            if row["expected"]=="PROVED":
                compact=json.loads((ROOT/f"data/{label}-logical-v1.json").read_text())

            def search():
                normal,_=compile_case(source)
                depth=row["depth"]
                selected=None if "term_proposal" not in row else demanded(source,normal,depth)[0]
                status,_,_=prove(source,normal,depth,selected=selected)
                return status

            def solve():
                language=Language(source)
                premises=[language.formula(p) for p in source["premises"]]
                solver=z3.Solver()
                solver.set(timeout=3000,random_seed=1)
                solver.add(*premises,z3.Not(language.formula(source["goal"])))
                return str(solver.check())

            arms=[("on_demand",search),("z3_source",solve)]
            if compact:
                arms.append(("compact_check",lambda:verify(source,compact)["status"]))
            for name,fn in arms if trial%2==0 else reversed(arms):
                answer,elapsed=measure(fn)
                expected={"on_demand":row["on_demand"]["status"],
                          "z3_source":"unsat" if compact else "sat",
                          "compact_check":"CHECKED_LOGICAL_RECORDS"}[name]
                assert answer==expected
                values[label][name].append(elapsed)
    result=dict(status="MEASURED_EQUALITY_PROOF_SEARCH",trial_count=5,
        system=dict(platform=platform.system(),architecture=platform.machine(),python=platform.python_version()),
        z3=z3.get_full_version(),measurements=values)
    (ROOT/"data/equality-timing-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print("Measured",len(values),"requests",flush=True)


if __name__=="__main__":
    main()
