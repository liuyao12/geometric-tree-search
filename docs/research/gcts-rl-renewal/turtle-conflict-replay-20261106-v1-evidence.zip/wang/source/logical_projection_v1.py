"""Check source-bound Wang proof records directly, with a compact certificate."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import decode_v1 as decoder
from definition_composition_v1 import link
from lifted_native_v1 import fingerprint
from native_marked_v1 import records
from native_v1 import PUBLISHED_MACHINE
from shared_wang_v1 import binding, verify_certificate

SCHEMA="SHARED-WANG-LOGICAL-RECORDS-v1"


def projection(bundle):
    data={k:bundle[k] for k in ("machine_sha256","kind","compiled","translation","proof","calls")}
    data["schema"]=SCHEMA
    data["records"]={key:{k:row[k] for k in ("prefix","word")} for key,row in bundle["traces"].items()}
    return data


def verify(source,bundle):
    if not __debug__:
        raise RuntimeError("Proof record checking requires Python assertions")
    assert bundle["schema"]==SCHEMA and bundle["machine_sha256"]==PUBLISHED_MACHINE
    binding(source,bundle["kind"],bundle["compiled"],bundle["translation"])
    seen=set()
    for call in bundle["calls"]:
        key=call["fragment"]
        assert call["reuse"]==(key in seen)
        seen.add(key)
    assert seen==set(bundle["records"])
    decoded={}
    inputs={}
    for key,item in bundle["records"].items():
        prefix,word=item["prefix"],item["word"]
        assert key==fingerprint(prefix,records(word))
        decoded[key]=decoder.read(prefix,word+"!",require_empty=False)
        inputs[key]=dict(prefix=prefix,steps=0)
    row=dict(original=source,compiled=bundle["compiled"],definition=dict(proof=bundle["proof"]))
    counts,used=link(row,bundle["calls"],inputs,decoded)
    assert used==seen
    return dict(status="CHECKED_LOGICAL_RECORDS",records=counts["fragment_calls"],unique_records=len(seen))


def read(path):
    return json.loads((ROOT/path).read_text())


def reject(source,bundle):
    try:
        verify(source,bundle)
    except (AssertionError,ValueError,KeyError,IndexError):
        return
    raise AssertionError("Altered logical records accepted")


def main():
    cases=("turtle-pocket","penrose-regular","penrose-concave")
    summary=[]
    for name in cases:
        original=read(f"input/{name}-fol-v1.json")
        path=ROOT/"data"/f"{name}-wang-v1.json"
        full=json.loads(path.read_text())
        old=verify_certificate(original,full)
        compact=projection(full)
        raw=json.dumps(compact,sort_keys=True,separators=(",",":")).encode()+b"\n"
        target=ROOT/"data"/f"{name}-records-v1.json"
        target.write_bytes(raw)
        report=verify(original,json.loads(target.read_text()))
        assert report["records"]==old["fragment_calls"]
        forged=deepcopy(compact)
        call=forged["calls"][-1]
        old_key=call["fragment"]
        row=forged["records"].pop(old_key)
        assert row["word"].endswith("/;")
        row["prefix"]=row["prefix"].replace("+","-",1)
        key=fingerprint(row["prefix"],records(row["word"]))
        assert key!=old_key
        forged["records"][key]=row
        for c in forged["calls"]:
            if c["fragment"]==old_key:
                c["fragment"]=key
        reject(original,forged)
        dependency=deepcopy(compact)
        dependency["proof"]["lines"][-1]["left"]=len(dependency["proof"]["lines"])
        reject(original,dependency)
        different=deepcopy(original)
        different["goal"]=["not",different["goal"]]
        reject(different,compact)
        summary.append(dict(id=name,raw_sha256=sha256(raw).hexdigest(),full_bytes=path.stat().st_size,
                            logical_bytes=len(raw),rejected=("premise","dependency","original_goal"),
                            receipt=report))
        print(summary[-1],flush=True)
    (ROOT/"data/logical-projection-v1.json").write_text(json.dumps(summary,sort_keys=True)+"\n")


if __name__=="__main__":
    main()
