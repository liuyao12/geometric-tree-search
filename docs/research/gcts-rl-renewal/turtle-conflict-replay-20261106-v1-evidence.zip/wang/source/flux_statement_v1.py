"""A single explicit Peano induction instance for zero edge increments."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
SORT="Nat"
Z=["zero"]


def eq(a,b):
    return ["atom","=Nat",a,b]


def all_(x,body):
    return ["all",x,SORT,body]


def F(x):
    return ["F",x]


def source():
    x="?x"
    sx=["S",x]
    p0=eq(F(Z),Z)
    p=eq(F(x),Z)
    recurrence=all_(x,eq(F(sx),F(x)))
    step=all_(x,["implies",p,eq(F(sx),Z)])
    conclusion=all_(x,p)
    induction=["implies",["and",p0,step],conclusion]
    return dict(id="zero-flux-induction",sorts=[SORT],functions={"zero":[[],SORT],"S":[[SORT],SORT],
           "F":[[SORT],SORT]},predicates={},equality=True,premises=[p0,recurrence,induction],goal=conclusion)


def main():
    (ROOT/"input/flux-induction-v1.json").write_text(json.dumps(source(),sort_keys=True)+"\n")


if __name__=="__main__":
    main()
