"""Audit the arithmetic boundary against the pinned measured contours."""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from shared_wang_v1 import verify_certificate


def read(path):
    return json.loads((ROOT/path).read_text())


def det(a,b):
    return a[0]*b[1]-a[1]*b[0]


def pair_sum(a,b):
    return a[0]+b[0],a[1]+b[1]


def product_field(a,b):
    x,y=a
    u,v=b
    return x*u+y*v,x*v+y*u+y*v


def difference(a,b):
    return a[0]-b[0],a[1]-b[1]


def physical(p):
    a,b,c,d=p
    return (Fraction(2*a-b,2),Fraction(b-c-d,2)),(c-d,b)


def sum_polygon(points,cross):
    terms=[cross(a,b) for a,b in zip(points,(*points[1:],points[0]),strict=True)]
    return tuple(map(sum,zip(*terms,strict=True)))


def penrose(points):
    def cross(a,b):
        return difference(product_field(a[0],b[1]),product_field(a[1],b[0]))
    return sum_polygon(tuple(map(physical,points)),cross)


def truth(node,valuation):
    op,*args=node
    if op=="atom":
        return valuation.get(args[0],False)
    if op=="not":
        return not truth(args[0],valuation)
    left,right=(truth(a,valuation) for a in args)
    return left and right if op=="and" else left or right if op=="or" else not left or right


def audited_residue(source,receipt):
    n,k=receipt["cap"],receipt["modulus"]
    increments=(0,*(v[receipt["coordinate"]] for v in receipt["weights"]))
    atoms=set()
    state=[[f"r{i}_{j}" for j in range(k)] for i in range(n+1)]
    options=[[f"a{i}_{j}" for j in range(len(increments))] for i in range(n)]
    formulae=source["premises"]
    assert formulae[0]==["atom",state[0][0]]
    j=1
    checked=0
    for block in (*state,*options):
        length=len(block)
        size=1+length*(length-1)//2
        fragment=formulae[j:j+size]
        for flags in product((False,True),repeat=length):
            env=dict(zip(block,flags,strict=True))
            assert all(truth(p,env) for p in fragment)==(sum(flags)==1)
            checked+=1
        atoms.update(block)
        j+=size
    assert atoms==set(source["predicates"]) and all(not spec for spec in source["predicates"].values())
    assert len(formulae)-j==n*k*len(increments)
    for i in range(n):
        fragment=formulae[j:j+k*len(increments)]
        for l,a,r in product(range(k),range(len(increments)),range(k)):
            env={name:True for name in (state[i][l],options[i][a],state[i+1][r])}
            assert all(truth(p,env) for p in fragment)==(r==(l+increments[a])%k)
            checked+=1
        j+=k*len(increments)
    assert source["goal"]==["not",["atom",state[-1][receipt["required_residue"]]]]
    return checked


def main():
    pins=read("input/geometry-pins-v1.json")
    cases={r["id"]:r for r in read("input/measured-pockets-v1.json")}
    output=[]
    for trial in read("data/residue-summary-v1.json"):
        key=trial["id"]
        row=cases[key]
        data=trial["relation"]
        assert sorted(row["source_sha256"])==sorted(v["sha256"] for v in pins[row["kind"]]["entries"].values())
        if row["kind"]=="turtle":
            pocket=sum(abs(sum_polygon(r,lambda p,q:(det(p,q),))[0]) for r in row["cycles"])
            unit=abs(sum_polygon(row["tile"],lambda p,q:(det(p,q),))[0])
            assert pocket*data["weights"][0][0]==unit*data["measured_area"][0]
            assert data["cap"]==pocket//unit
        else:
            a,b=tuple(map(sum,zip(*(penrose(r) for r in row["cycles"]),strict=True)))
            assert [a,b]==data["measured_area"]
            assert data["weights"]==[[2,0],[0,2]]
            assert b>=0
            # Rational brackets for phi suffice for these three input areas.
            low,high=a+b*Fraction(1618,1000),a+b*Fraction(1619,1000)
            cap=data["cap"]
            assert 2*cap<=low<=high<2*(cap+1)
        coord=data["coordinate"]
        modulus=data["modulus"]
        assert all(w[coord]%modulus==0 for w in data["weights"])
        assert data["measured_area"][coord]%modulus==data["required_residue"]
        source=read(f"input/{key}-fol-v1.json")
        truth_rows=audited_residue(source,data)
        if row["expected"]=="PROVED":
            result=verify_certificate(source,read(f"data/{key}-wang-v1.json"))
            assert result==trial["result"]
        else:
            env={name:True for name in trial["result"]["true_atoms"]}
            assert all(truth(p,env) for p in source["premises"])
            assert not truth(source["goal"],env)
            result=trial["result"]
        output.append(dict(id=key,truth_rows=truth_rows,status=result["status"]))
    (ROOT/"data/residue-audit-v1.json").write_text(json.dumps(output,sort_keys=True)+"\n")
    print(output,flush=True)


if __name__=="__main__":
    main()
