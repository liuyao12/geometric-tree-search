"""Qualify negative donor fragments and combine exclusions with native admission."""
from collections import defaultdict
from pathlib import Path
import gzip
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from herbrand_v1 import frozen
from lifted_experiment_v1 import ROOT, load, save
from lifted_marks_v1 import applies
from lifted_native_v1 import Boundary, NativeBank, Receiver
from lifted_prover_v1 import Prover, subst
from native_experiment_v1 import LIMITS
from study_v1 import write_gzip


def names(term):
    if isinstance(term,str):
        return {term}
    return set().union(*(names(t) for t in term[1:]))


def rejection_attempt(left,right):
    atoms=[]
    types={}
    for i,atom in enumerate((left,right)):
        remap={v:f"?s{i}_{j}" for j,v in enumerate(sorted(names(atom)))}
        atoms.append(subst(atom,remap))
        types.update({v:"U" for v in remap.values()})
    environment={}
    def bind(a,b):
        if isinstance(a,str) and not names(b):
            environment.setdefault(a,b)
        elif isinstance(b,str) and not names(a):
            environment.setdefault(b,a)
        elif isinstance(a,tuple) and isinstance(b,tuple) and a[0]==b[0] and len(a)==len(b):
            for x,y in zip(a[1:],b[1:],strict=True):
                bind(x,y)
    bind(*atoms)
    out=Boundary()
    before,lines=[],[]
    for i,atom in enumerate(atoms):
        scope={v:f"{j:b}" for j,v in enumerate(sorted(names(atom)))}
        clause=((i==0,atom),)
        before.append(f"C{i:b}:"+out.row(clause,scope,{})+";")
    for i,atom in enumerate(atoms):
        bindings="".join(f"={j:b}:"+out.term(environment.get(v,v),{},types)
                         for j,v in enumerate(sorted(names(atom))))
        text=out.row(((i==0,subst(atom,environment)),),{},types)
        lines.append(f"G{i:b}:{i:b}:"+bindings+"/"+text+";")
    pivot=out.atom(subst(atoms[0],environment),{},types)
    lines.append("R10:0:1:"+pivot+"/;")
    return ">"+ "".join(before)+"#",tuple(lines)


def records(word):
    assert word.endswith(";")
    return tuple(r+";" for r in word[:-1].split(";"))


def main():
    data=load("data/search-v1.json")
    cohort=load("input/cohort-v1.json")
    candidates=defaultdict(list)
    for source in cohort["donors"]:
        search=Prover(source,learn=True,**LIMITS)
        assert search.run()[0]=="PROVED"
        for mark,(left,right) in search.discovered.items():
            candidates[mark].append((source["id"],left,right))
    selected=tuple(sorted(candidates,key=lambda m:(-len(candidates[m]),m))[:5])
    tape=NativeBank()
    qualification=[]
    for mark in selected:
        origin,a,b=candidates[mark][0]
        assert applies(mark,a,b)
        prefix,lines=rejection_attempt(a,b)
        key,rejected,hit=tape.get(prefix,lines,False)
        assert not hit and rejected["stop"]==1 and rejected["commits"]==2
        qualification.append(dict(mark=mark,id=origin,left=a,right=b,fragment=key))
    write_gzip(ROOT/"data/negative-fragments-v1.json.gz",tape.traces)
    with gzip.open(ROOT/"data/native-fragments-v1.json.gz","rt") as stream:
        tape.traces=json.load(stream)
    warm={}
    for donor in data["donors"]:
        for event in donor["events"]:
            label=event["fragment"]
            trace=tape.traces[label]
            warm[(trace["prefix"],records(trace["word"]),())]=label
    original=set(tape.traces)
    holdout={s["id"]:s for s in cohort["holdout"]}
    comparisons=[]
    for row in data["cases"]:
        if row["id"] not in ("iterate-depth-8","receiver-alias","hilbert-incidence-uniqueness"):
            continue
        tape.memo=dict(warm)
        gate=Receiver(tape,"shape")
        run=Prover(holdout[row["id"]],order="goal",marks=selected,admission=gate,**LIMITS)
        status,root=run.run()
        control=row["arms"]["warm"]
        assert status==control["status"]=="PROVED" and gate.counts==control["tape"]
        assert json.loads(json.dumps(gate.events))==control["events"]
        assert json.loads(json.dumps(run.proof(root)))==row["proof"]["lifted"]
        assert run.counts["offers"]==control["counts"]["offers"]
        uses=[(m,a,b,n) for (m,a,b),n in sorted(run.failed_uses.items(),key=repr)]
        assert sum(n for _,_,_,n in uses)==control["counts"]["unifications"]-run.counts["unifications"]
        comparisons.append(dict(id=row["id"],counts=dict(run.counts),tape=dict(gate.counts),marks=uses))
    assert set(tape.traces)==original
    save("data/combined-v1.json",dict(status="QUALIFIED_NATIVE_DONORS_AND_COMBINED_RECEIVERS",
                                      donors=qualification,cases=comparisons))


if __name__=="__main__":
    main()
