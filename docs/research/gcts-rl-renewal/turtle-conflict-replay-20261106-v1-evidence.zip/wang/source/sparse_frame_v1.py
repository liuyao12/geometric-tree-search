"""Compile compact sweep traces and check their exact framed Wang semantics."""
from functools import lru_cache
import re

import tiles_v1 as til
from marker_tm_v1 import FREE


class FixedPalette(til.Palette):
    """The inherited frame with sparse deterministic transitions."""
    def __init__(self, machine):
        self.verifier = machine
        self.machine = {"start": machine.start, "accept": 0, "reject": 1, "input_alphabet": FREE}
        self.symbols = set(machine.alphabet)
        self.states = set(range(len(machine.names)))

    def delta(self, q, read):
        return self.verifier.delta(q, read)

    @lru_cache(maxsize=32768)
    def local(self, a, b, c, after):
        tile = til.cfg(b), til.pair(b, c), til.cfg(after), til.pair(a, b)
        if not self.allows(tile):
            raise ValueError("Illegal active Wang square")
        return tile


class Sweeps:
    def __init__(self, machine, tape):
        self.codes = {s: i for i, s in enumerate(machine.alphabet)}
        self.symbols = machine.alphabet
        self.data = bytearray(self.codes[s] for s in tape)
        self.reverse = self.data[::-1]
        self.rules = {}
        pure = {}
        for (q, a), (n, w, d) in machine.rules.items():
            self.rules[q, self.codes[a]] = n, self.codes[w], d
            if q == n and a == w and d:
                pure.setdefault((q, d), []).append(self.codes[a])
        self.scans = {k: re.compile(b"[" + re.escape(bytes(a)) + b"]+") for k, a in pure.items()}

    def sweep(self, q, h, d, length=None):
        pattern = self.scans.get((q, d))
        if pattern is None:
            return 0
        tape, start = (self.data, h) if d == 1 else (self.reverse, len(self.data) - 1 - h)
        end = len(tape) if length is None else start + length
        hit = pattern.match(tape, start, end)
        return hit.end() - start if hit else 0

    def transition(self, q, h):
        read = self.data[h]
        return self.rules.get((q, read), (1, read, 0))

    def write(self, h, value):
        self.data[h] = self.reverse[len(self.data) - 1 - h] = value


def execute(machine, prefix, proof, padding, max_steps):
    tape, _ = machine.input(prefix, proof, padding)
    tape = Sweeps(machine, tape)
    trace, commits = [], []
    q, h, steps = machine.start, 0, 0
    previous = None
    while q not in (0, 1) and 0 <= h < len(tape.data) and steps < max_steps:
        if q != previous and machine.names[q] == "finish":
            commits.append([steps, h])
        previous = q
        nxt, write, d = tape.transition(q, h)
        if nxt == q and write == tape.data[h] and d:
            run = tape.sweep(q, h, d)
            assert run
            trace.append([run, d])
            h += run * d
            steps += run
        else:
            trace.append([nxt, write, d])
            tape.write(h, write)
            q, h, steps = nxt, h + d, steps + 1
    if steps > max_steps or q not in (0, 1):
        return dict(status="BOUNDED", steps=steps, last=machine.names[q])
    return dict(status="ACCEPT" if q == 0 else "REJECT", steps=steps, commits=commits,
                trace=trace if q == 0 else None)


def update_tiles(palette, tape, q, h, nxt, write, d):
    # All other columns have headless old triples and their unique transport tile.
    codes, symbols = tape.data, tape.symbols
    new_head = h + d
    if not 0 <= new_head < len(codes):
        raise ValueError("Head leaves frame")

    def before(i):
        if i < 0:
            return til.L
        if i == len(codes):
            return til.R
        return til.cell(symbols[codes[i]], q if i == h else None)

    row = []
    for i in range(max(0, h - 1), min(h + 2, len(codes))):
        after = til.cell(symbols[write if i == h else codes[i]], nxt if i == new_head else None)
        row.append((i, palette.local(before(i - 1), before(i), before(i + 1), after)))
    return row


def verify(machine, prefix, proof, padding, trace, max_steps):
    palette = FixedPalette(machine)
    chars, free = machine.input(prefix, proof, padding)
    boundary = [("input", "head", chars[0])] + [
        ("input", "free") if i in free else ("input", "fixed", a) for i, a in enumerate(chars[1:], 1)]
    top = [palette.top(n, til.cell(a, machine.start if i == 0 else None))
           for i, (n, a) in enumerate(zip(boundary, chars, strict=True))]
    if not all(map(palette.allows, top)):
        raise ValueError("Top tiles fail membership")
    tape = Sweeps(machine, chars)
    q, h, steps, runs, active = machine.start, 0, 0, 0, 0
    for event in trace:
        if q in (0, 1) or steps >= max_steps or not 0 <= h < len(chars):
            raise ValueError("Unexpected transition")
        if len(event) == 2:
            length, direction = event
            if (type(length) is not int or type(direction) is not int or direction not in (-1, 1)
                    or not 1 <= length <= max_steps - steps
                    or not 0 <= h + length * direction < len(chars)
                    or tape.sweep(q, h, direction, length) != length):
                raise ValueError("Sweep contains a write, state change, or wrong direction")
            for i in {h, h + (length - 1) * direction}:
                update_tiles(palette, tape, q, i, q, tape.data[i], direction)
            h += length * direction
            steps += length
            runs += 1
        elif len(event) == 3:
            nxt, write, d = event
            if (any(type(a) is not int for a in event) or not 0 <= nxt < len(machine.names)
                    or not 0 <= write < len(tape.symbols) or d not in (-1, 0, 1)):
                raise ValueError("Invalid transition fields")
            active += len(update_tiles(palette, tape, q, h, nxt, write, d))
            tape.write(h, write)
            q, h, steps = nxt, h + d, steps + 1
        else:
            raise ValueError("Invalid sparse event")
    if q != 0:
        raise ValueError("Frame has no accepting cap")
    final = [til.cell(tape.symbols[a], q if i == h else None) for i, a in enumerate(tape.data)]
    cap = palette.cap(final)
    if not all(map(palette.allows, cap)):
        raise ValueError("Bottom tiles fail membership")
    return dict(status="CHECKED_SPARSE_FRAME", steps=steps, rows=steps+2,
                columns=len(chars)+2, squares=(steps+2)*(len(chars)+2),
                open_characters=len(free), sweep_runs=runs, explicit_active_checks=active,
                operation_pins=0, trace_events=len(trace))
