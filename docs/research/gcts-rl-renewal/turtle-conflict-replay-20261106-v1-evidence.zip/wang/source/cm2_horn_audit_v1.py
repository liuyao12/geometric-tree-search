"""Replay the CM2 proof traces on the arithmetic and geometry palette."""
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from boundary_kernel_v1 import build
from cm2_horn_v1 import encode,fixtures,numeral,state
from native_marked_v1 import records
import decode_v1 as decoder
import herbrand_v1 as fol
from lifted_experiment_v1 import ROOT,load,save
from lifted_frames_v1 import CAP,EXPECTED,restore
from lifted_prover_v1 import subst,unifier
from collections import Counter
from sparse_frame_v1 import execute,verify
from study_v1 import write_gzip


def step(program,configuration):
    i,a,b=configuration
    if i>=len(program):
        return None
    op,c,*jump=program[i]
    u=[a,b]
    if op=="inc":
        u[c]+=1
    elif u[c]>0:
        u[c]-=1
        return (min(jump[0],len(program)),*u)
    return (i+1,*u)


def qualify(case,normal):
    f,_,schemas=fol.signature(normal)
    count=0
    for i in range(len(case["program"])+1):
        for a in range(5):
            for b in range(5):
                args=state(i,numeral(a),numeral(b))
                derived=[]
                for row in schemas:
                    if len(row["clause"])!=2:
                        continue
                    (q,x),(p,y)=row["clause"]
                    assert not q and p
                    if x[0]!=args[0]:
                        continue
                    found=unifier(x,args,row["variables"],f,Counter())
                    if found is not None:
                        derived.append(subst(y,found))
                reference=step(case["program"],(i,a,b))
                if reference is None:
                    assert not derived
                else:
                    j,x,y=reference
                    assert derived==[state(j,numeral(x),numeral(y))]
                count+=1
    return count


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    rows=load("data/cm2-search-v1.json")["results"]
    assert [r["case"] for r in rows]==fixtures()
    checked=[]
    for row in rows:
        case,normal=row["case"],row["compiled"]
        assert normal==json.loads(json.dumps(encode(case)))
        count=qualify(case,normal)
        p,x,y=case["initial"]
        configuration=(min(p,len(case["program"])),x,y)
        seen=set()
        for observed in row["configurations"]:
            i,a,b=configuration
            assert fol.frozen(observed)==state(i,numeral(a),numeral(b))
            assert configuration not in seen
            seen.add(configuration)
            configuration=step(case["program"],configuration)
        kind=row["status"]
        record=dict(id=row["id"],qualifications=count,outcome=kind)
        if kind=="PROVED":
            assert configuration is None
            proof=row["proof"]["lines"]
            b=restore(case,proof,normal=normal)
            prefix,word=b.prefix(),b.words()
            assert len(decoder.records(prefix[1:-1]))==len(normal["clauses"])
            run=execute(machine,prefix,word,1,CAP)
            assert run["status"]=="ACCEPT"
            receipt=verify(machine,prefix,word,1,run["trace"],CAP)
            assert len(decoder.read(prefix,word))==len(proof)==len(run["commits"])
            path=f"data/{row['id']}-shared-frame-v1.json.gz"
            write_gzip(ROOT/path,dict(prefix=prefix,word=word,padding=1,trace=run["trace"],
                                       machine_sha256=EXPECTED,commits=run["commits"]))
            record.update(frame=path,receipt=receipt,source_clauses=len(normal["clauses"]))
            if row["id"]=="C02":
                before,*_,last=records(word[:-1])
                assert before.startswith("G") and last.startswith("R")
                head,body=last.split("/",1)
                bad=word[:-len(last)-1]+head.rsplit(":",1)[0]+":"+b.token(("zero",),{})+"/"+body+"!"
                rejected=execute(machine,prefix,bad,1,CAP)
                assert rejected["status"]=="REJECT"
                try:
                    decoder.read(prefix,bad)
                except ValueError:
                    pass
                else:
                    raise AssertionError("Invalid pivot accepted")
                record["wrong_pivot"]=dict(status=rejected["status"],steps=rejected["steps"])
        elif kind=="CLOSED":
            assert configuration in seen and row["proof"] is None
        else:
            assert kind=="BOUNDED" and configuration not in seen and row["proof"] is None
        print(row["id"],kind,count,record.get("receipt",{}).get("steps"),flush=True)
        checked.append(record)
    save("data/cm2-audit-v1.json",dict(status="CHECKED_CM2_ON_ARITHMETIC_GEOMETRY_PALETTE",
            machine_sha256=EXPECTED,results=checked))


if __name__=="__main__":
    main()
