"""Compare source representations and search from independently checked clauses."""
from collections import Counter
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_cases_v1 import cases
from definitions_v1 import compile_case
from definition_check_v1 import check
import front_v1 as front
from lifted_experiment_v1 import save
from lifted_ground_v1 import compile_proof
from lifted_prover_v1 import Prover

LIMITS=dict(offer_cap=65000,node_cap=24000)


def attempt(original,normal,*,keep_proof=False,order="size",admission=None):
    engine=Prover(original,normal=normal,order=order,admission=admission,**LIMITS)
    outcome,index=engine.run()
    proof=None
    if outcome=="PROVED" and keep_proof:
        dag=engine.proof(index)
        builder,events,_=compile_proof(engine,dag)
        proof=dict(lifted=dag,lines=builder.lines,events=events,skolem=[])
    return dict(status=outcome,counts=dict(engine.counts),proof=proof)


def main():
    rows=[]
    for original in cases():
        normal,certificate=compile_case(original)
        qualification=check(original,normal,certificate)
        try:
            legacy,_=front.clausify(original,1024)
        except ValueError as exc:
            assert str(exc)=="Clausification distribution limit"
            control=dict(status="DISTRIBUTION_LIMIT",clauses=None)
        else:
            control=dict(clauses=len(legacy["clauses"]),**attempt(original,legacy))
        result=attempt(original,normal,keep_proof=True)
        row=dict(id=original["id"],original=original,compiled=normal,certificate=certificate,
                 qualified=qualification,control=control,definition=result)
        rows.append(row)
        print(row["id"],control["status"],control["clauses"],result["status"],
              qualification["rows"],result["counts"].get("offers",0),
              len(result["proof"]["lines"]) if result["proof"] else None,flush=True)
    save("data/search-v1.json",dict(status="SEARCHED_CHECKED_DEFINITIONAL_BOUNDARIES",
             results=rows,counts=dict(Counter(r["definition"]["status"] for r in rows))))


if __name__=="__main__":
    main()
