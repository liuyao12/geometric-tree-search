"""Statement-level controls for equality search with unresolved alternatives."""
from functools import reduce

from equality_cases_v1 import addition, arithmetic, atom, examples, iterate
from lifted_cases_v1 import all_, case


def disjoin(rows):
    return reduce(lambda a, b: ["or", a, b], rows)


def alternatives(count, depth, negative=False):
    left = [f"a{i}" for i in range(count)]
    right = [f"b{i}" for i in range(count)]
    symbols = {**dict.fromkeys(left + right, 0), "S": 1}
    eqs = [atom("=U", [a], [b]) for a, b in zip(left, right, strict=True)]

    def proposition(name):
        return atom("P", iterate(depth, [name]))

    source = case(f"alternatives-{count}-depth-{depth}", symbols, {"P": 1},
                  [disjoin(eqs), *map(proposition, left)], disjoin(map(proposition, right)),
                  equality=True)
    if not negative:
        return source, None
    source["id"] += "-missing-fact"
    source["premises"].pop()
    model = dict(domains={"U": (0, 1)}, functions={
        **{name: {(): int(name == left[-1])} for name in left},
        **{name: {(): 1} for name in right}, "S": {(0,): 0, (1,): 1},
    }, predicates={"P": {(0,)}})
    return source, model


def incidence_choice():
    ell, m, n, p = (["ell"], ["m"], ["n"], ["p"])

    def eq(a, b):
        return atom("=Line", a, b)

    def incident(line):
        return atom("I", p, line)

    return dict(id="incidence-choice", sorts=["Line", "Point"], equality=True,
        functions={"ell": [[], "Line"], "m": [[], "Line"], "n": [[], "Line"], "p": [[], "Point"]},
        predicates={"I": ["Point", "Line"]},
        premises=[["or", eq(ell, m), eq(ell, n)], incident(ell)],
        goal=["or", incident(m), incident(n)])


def nested_identity(tag, number, repeated):
    f, pair, identity, P, U = (tag + label for label in ("f", "pair", "u", "P", "U"))
    constants = [tag + f"c{i}" for i in range(2 * number + 1)]
    good, *others = ([c] for c in constants)
    x = "?x"
    match = [f, [pair, x, x] if repeated else [pair, [identity, x], x]]
    rule = all_(x, atom("=U", match, x))
    receiver = [f, [pair, good, good] if repeated else [pair, [identity, good], good]]
    decoys = [atom(P, [f, [pair, a, b]]) for a, b in zip(others[::2], others[1::2], strict=True)]
    facts = [rule, *decoys, atom(U, receiver)]
    functions = {f: 1, pair: 2, identity: 1, **dict.fromkeys(constants, 0)}
    return case(f"{tag}-{'alias' if repeated else 'rigid'}-{number}", functions, {P: 1, U: 1},
                facts, atom(U, good), equality=True)


def cohort():
    donors = [nested_identity(f"donor{i}", 4 + i, bool(i % 2)) for i in range(4)]
    tests = [(*alternatives(2, 1), 1), (*alternatives(3, 2), 2), (*alternatives(4, 1), 1),
             (*alternatives(2, 1, True), 1), (*alternatives(3, 2, True), 2),
             (incidence_choice(), None, 0)]
    tests.extend((nested_identity(f"test{i}", n, repeated), None, 2)
                 for i, (n, repeated) in enumerate(((9, False), (12, True), (17, False), (20, True))))
    selected = {"peano-congruence-7", "peano-cancel-4", "hilbert-incidence-transfer",
                "peano-add-successors-2", "peano-add-successors-7"}
    tests.extend((source, model, depth) for source, depth, model in examples() if source["id"] in selected)
    tests.append((addition(11), None, 12))
    scheduler = [addition(n) for n in (3, 5, 8, 9)]
    scheduler.extend(arithmetic("cancel", n) for n in (2, 3, 5))
    scheduler.extend((alternatives(2, 2)[0], alternatives(3, 1)[0], *donors))
    held_out = [(*alternatives(2, 3), 3), (*alternatives(3, 3), 3), (*alternatives(5, 1), 1),
                (*alternatives(4, 2, True), 2)]
    held_out.extend((nested_identity(f"holdout{i}", n, repeated), None, 2)
                    for i, (n, repeated) in enumerate(((23, False), (26, True))))
    held_out.extend((addition(n), None, n + 1) for n in (6, 10, 13))
    held_out.append((arithmetic("cancel", 6), None, 6))
    return donors, scheduler, tests, held_out
