"""Fixed experiment statements and exact bounded comparison inputs."""
from lifted_cases_v1 import a, all_, case, disjunction, exists, implies
from lifted_experiment_v1 import load


def combine(op,items):
    items=list(items)
    assert items
    result=items.pop()
    for item in reversed(items):
        result=[op,item,result]
    return result


def wide(n):
    p,q=[f"P{i}" for i in range(n)],[f"Q{i}" for i in range(n)]
    conjunctions=[["and",a(x,"?x"),a(y,"?x")] for x,y in zip(p,q,strict=True)]
    formula=all_("?x",combine("or",conjunctions))
    goal=all_("?x",combine("or",[a(x,"?x") for x in p]))
    return case(f"wide-choices-{n}",{},{x:1 for x in (*p,*q)},[formula],goal)


def biconditional(n):
    p=[f"P{i}" for i in range(n)]
    atoms=[a(x,["c"]) for x in p]
    return case(f"nested-iff-{n}",{"c":0},{x:1 for x in p},atoms,combine("iff",atoms))


def typed_scope():
    left=all_("?x",all_("?z",exists("?y",a("R","?x","?y"),"Line"),"Line"),"Point")
    right=all_("?x",exists("?x",a("R",["origin"],"?x"),"Line"),"Point")
    return dict(id="typed-shadowed-witness",sorts=["Point","Line"],
                functions={"origin":[[],"Point"],"def_0_0_0":[[],"Line"]},
                predicates={"R":["Point","Line"]},
                premises=[left],goal=right,equality=False)


def mixed_swap():
    return dict(id="mixed-quantifier-swap",sorts=["Point","Line"],
        functions={},predicates={"R":["Point","Line"]},
        premises=[all_("?x",exists("?y",a("R","?x","?y"),"Line"),"Point")],
        goal=exists("?y",all_("?x",a("R","?x","?y"),"Point"),"Line"),equality=False)


def cases():
    old={p["id"]:p for p in load("input/cases-v1.json")+load("input/new-cases-v1.json")}
    return [disjunction(),old["quantifier-duality"],old["shadowed-existential"],
            old["peano-nonzero-successor"],old["hilbert-incidence-uniqueness"],typed_scope(),
            wide(5),wide(11),biconditional(12),mixed_swap()]
