"""The qualified framed-Wang construction, with an intensional palette."""

from functools import lru_cache
import deterministic_tm_wang_v1 as inherited

L,R=("wall","left"),("wall","right")
OL,OR,OB=("outer","left"),("outer","right"),("outer","bottom")
FL,FR=("frame","left"),("frame","right")
LINK=("input-link",)
BEFORE,AFTER=("cap","before"),("cap","after")


def cell(symbol, state=None):
    return ("symbol",symbol) if state is None else ("head",state,symbol)


def cfg(c):
    return ("configuration",c)


def pair(a,b):
    return ("old-pair",a,b)


class Palette:
    def __init__(self,machine):
        self.machine=inherited.parse_machine(machine,check=lambda:None)
        self.table=inherited._table(machine)
        self.symbols=set(machine["symbols"])
        self.states=set(machine["states"])

    @lru_cache(maxsize=100000)
    def core(self,a,b,c):
        d=inherited._local_successor(self.machine,list(a),list(b),list(c),self.table)
        assert d is not None
        return cfg(b),pair(b,c),cfg(tuple(d)),pair(a,b)

    def top(self,descriptor,c):
        assert descriptor[0]=="input"
        return descriptor,LINK,cfg(c),LINK

    def step(self,config):
        padded=(L,*config,R)
        return [(FL,pair(L,config[0]),FL,OL)]+[
            self.core(a,b,c) for a,b,c in zip(padded,padded[1:],padded[2:])
        ]+[(FR,OR,FR,pair(config[-1],R))]

    def cap(self,config):
        flag=BEFORE
        result=[(FL,BEFORE,OB,OL)]
        for c in config:
            after=flag
            if c[0]=="head":
                assert c[1]==self.machine["accept"] and flag==BEFORE
                after=AFTER
            result.append((cfg(c),after,OB,flag))
            flag=after
        assert flag==AFTER
        return result+[(FR,OR,OB,AFTER)]

    def allows(self,tile):
        """Decide membership from the four atomic colors alone."""
        n,e,s,w=tile
        if n[0]=="configuration" and e[0]==w[0]=="old-pair" and s[0]=="configuration":
            a,b,c=w[1],n[1],e[2]
            if w[2]!=b or e[1]!=b:
                return False
            if not self.is_cell(b) or (a!=L and not self.is_cell(a)) or (c!=R and not self.is_cell(c)):
                return False
            heads=[i for i,t in enumerate((a,b,c)) if t[0]=="head"]
            if len(heads)>1:
                return False
            if not heads:
                return s==cfg(b)
            index=heads[0]
            q,read=(a,b,c)[index][1:]
            dest,write,move=self.delta(q,read)
            if index==1:
                if (move==-1 and a==L) or (move==1 and c==R):
                    return False
                output=cell(write,dest) if move==0 else cell(write)
            elif index+move==1:
                output=cell(b[1],dest)
            else:
                output=b
            return s==cfg(output)
        if n==FL:
            return (s==FL and w==OL and e[0]=="old-pair" and e[1]==L and self.is_cell(e[2])) or (
                (e,s,w)==(BEFORE,OB,OL))
        if n==FR:
            return (s==FR and e==OR and w[0]=="old-pair" and w[2]==R and self.is_cell(w[1])) or (
                (e,s,w)==(OR,OB,AFTER))
        if n==("top","left"):
            return (e,s,w)==(LINK,FL,OL)
        if n==("top","right"):
            return (e,s,w)==(OR,FR,LINK)
        if n[0]=="input" and e==w==LINK and s[0]=="configuration" and self.is_cell(s[1]):
            c=s[1]
            if n==("input","free"):
                return c[0]=="symbol" and c[1] in self.machine["input_alphabet"]
            return n==(("input","fixed",c[1]) if c[0]=="symbol" else ("input","head",c[2])) and (
                c[0]=="symbol" or c[1]==self.machine["start"])
        if n[0]=="configuration" and s==OB and self.is_cell(n[1]):
            c=n[1]
            return ((c[0]=="symbol" and e==w and w in (BEFORE,AFTER))
                    or (c[0]=="head" and c[1]==self.machine["accept"] and w==BEFORE and e==AFTER))
        return False

    def is_cell(self,c):
        return ((len(c)==2 and c[0]=="symbol" and c[1] in self.symbols)
                or (len(c)==3 and c[0]=="head" and c[1] in self.states and c[2] in self.symbols))

    def delta(self,q,read):
        if q in (self.machine["accept"],self.machine["reject"]):
            return q,read,0
        t=self.table[q,read]
        return t["next"],t["write"],t["move"]

    def from_config(self,config):
        head,= [i for i,c in enumerate(config) if c[0]=="head"]
        q,read=config[head][1:]
        n,w,d=self.delta(q,read)
        position=head+d
        assert 0<=position<len(config)
        result=list(config)
        result[head]=cell(w)
        result[position]=cell(result[position][1],n)
        return tuple(result)


def build_frame(palette,word,prefix_length,configs):
    descriptors=[("input","head",word[0])]+[
        ("input","fixed",a) if i<prefix_length or i==len(word)-1 else ("input","free")
        for i,a in enumerate(word[1:],1)]
    grid=[[ (("top","left"),LINK,FL,OL),
           *(palette.top(n,c) for n,c in zip(descriptors,configs[0])),
           (("top","right"),OR,FR,LINK)]]
    grid.extend(palette.step(row) for row in configs[:-1])
    grid.append(palette.cap(configs[-1]))
    boundary=[("top","left"),*descriptors,("top","right")]
    return boundary,grid


def verify_frame(palette,boundary,grid):
    used=set()
    previous=None
    config=None
    for y,row in enumerate(grid):
        assert len(row)==len(boundary) and row[0][3]==OL and row[-1][1]==OR
        for x,t in enumerate(row):
            if t not in used:
                assert palette.allows(t)
                used.add(t)
            assert t[0]==(boundary[x] if y==0 else previous[x][2])
            if x:
                assert row[x-1][1]==t[3]
            if y==len(grid)-1:
                assert t[2]==OB
        if y<len(grid)-1:
            decoded=tuple(t[2][1] for t in row[1:-1])
            if config is not None:
                assert decoded==palette.from_config(config)
            config=decoded
        else:
            q,=[c[1] for c in config if c[0]=="head"]
            assert q==palette.machine["accept"]
        previous=row
    return dict(rows=len(grid),columns=len(boundary),tiles=len(grid)*len(boundary),
                used_types=len(used),steps=len(grid)-2)
