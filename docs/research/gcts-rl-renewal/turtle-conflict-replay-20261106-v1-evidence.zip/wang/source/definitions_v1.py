"""Structure-preserving first-order clause compilation."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol

CONNECTIVES={
    "and":((-1,2),(-1,3),(1,-2,-3)),
    "or":((1,-2),(1,-3),(-1,2,3)),
    "implies":((1,2),(1,-3),(-1,-2,3)),
    "iff":((-1,-2,3),(-1,2,-3),(1,2,3),(1,-2,-3)),
}
QUANTIFIERS={"all":((-1,2),(1,-3)),"exists":((1,-2),(-1,3))}


def key(path):
    return "_".join(map(str,path))


def flipped(literal):
    sign,atom=literal
    return not sign,atom


def substitute(value,var,term):
    if isinstance(value,str):
        return term if value==var else value
    return (value[0],*(substitute(t,var,term) for t in value[1:]))


def compile_case(problem):
    sorts=problem["sorts"]
    functions=dict(problem["functions"])
    predicates=dict(problem["predicates"])
    initial=predicates|({"="+s:[s,s] for s in sorts} if problem["equality"] else {})
    used=set(functions)|set(initial)
    definitions=[]
    clauses=[]

    def fresh(prefix,path):
        name=prefix+key(path)
        while name in used:
            name+="_"
        used.add(name)
        return name

    def emit(path,suffix,row,types):
        variables={}
        def visit(term):
            if isinstance(term,str):
                variables[term]=types[term]
            else:
                for child in term[1:]:
                    visit(child)
        for _,a in row:
            visit(a)
        clauses.append(dict(id=f"formula{path[0]+1}-{suffix}",
                            variables=dict(sorted(variables.items())),clause=sorted(set(row),key=repr)))

    def walk(node,path,scope):
        op,*children=node
        if op=="atom":
            name,*args=children
            free={}
            def term(t):
                if isinstance(t,str):
                    v,s=scope[t]
                    free[v]=s
                    return v
                return (t[0],*map(term,t[1:]))
            atom=(name,*map(term,args))
            assert tuple(fol.inspect_term(t,free,functions) for t in atom[1:])==tuple(initial[name])
            return (True,atom),free
        if op=="not":
            inner,=children
            literal,free=walk(inner,(*path,0),scope)
            return flipped(literal),free

        witness=None
        if op in QUANTIFIERS:
            name,sort,body=children
            assert name.startswith("?") and sort in sorts
            variable="?v"+key(path)
            literal,body_vars=walk(body,(*path,0),{**scope,name:(variable,sort)})
            if variable not in body_vars:
                return literal,body_vars
            free={v:s for v,s in body_vars.items() if v!=variable}
            arguments=tuple(sorted(free))
            witness=fresh("wdef_",path)
            functions[witness]=([free[v] for v in arguments],sort)
            sign,atom=literal
            arguments_body=(literal,(sign,substitute(atom,variable,(witness,*arguments))))
            templates=QUANTIFIERS[op]
        else:
            left,right=children
            first,lvars=walk(left,(*path,0),scope)
            second,rvars=walk(right,(*path,1),scope)
            free=lvars|rvars
            body_vars=free
            arguments=tuple(sorted(free))
            arguments_body=(first,second)
            templates=CONNECTIVES[op]
        name=fresh("def_",path)
        predicates[name]=[free[v] for v in arguments]
        top=(True,(name,*arguments))
        literals=(top,*arguments_body)
        definitions.append(dict(path=path,operator=op,name=name,witness=witness,templates=templates))
        for j,template in enumerate(templates,1):
            emit(path,f"node-{key(path)}-{j}",
                 [literals[k-1] if k>0 else flipped(literals[-k-1]) for k in template],body_vars)
        return top,free

    for i,formula in enumerate((*problem["premises"],problem["goal"])):
        root,free=walk(formula,(i,),{})
        assert not free
        emit((i,),"root",[root if i<len(problem["premises"]) else flipped(root)],{})
    inhabitants={}
    for i,s in enumerate(sorts):
        if not any(not args and out==s for args,out in functions.values()):
            name=fresh("inhabitant_",(i,))
            functions[name]=([],s)
            inhabitants[s]=name
    normal=dict(id=problem["id"],sorts=sorts,functions=dict(sorted(functions.items())),
                predicates=dict(sorted(predicates.items())),equality=problem["equality"],clauses=clauses,goal=None)
    return normal,dict(definitions=definitions,inhabitants=inhabitants)
