"""Measure and verify portable Wang fragments under injective local relabeling."""
from collections import Counter
import gzip
import json
from pathlib import Path
import re
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import NativeBank, fingerprint
from native_marked_v1 import records
from native_audit_v1 import qualify_fragment
from study_v1 import write_gzip

SYMBOL=re.compile(r"\(([01]+)\.")


def relabel(text, mapping):
    return SYMBOL.sub(lambda match: "("+mapping[match.group(1)]+".",text)


def normalize(prefix,word):
    ordered={}
    for part in (prefix,word):
        for match in SYMBOL.finditer(part):
            raw=match.group(1)
            ordered.setdefault(raw,f"{len(ordered):b}")
    return relabel(prefix,ordered),relabel(word,ordered),{v:k for k,v in ordered.items()}


def bind(original,canonical,bindings):
    tokens={m.group(1) for part in (canonical["prefix"],canonical["word"]) for m in SYMBOL.finditer(part)}
    assert set(bindings)==tokens and len(set(bindings.values()))==len(bindings)
    assert all(relabel(canonical[part],bindings)==original[part] for part in ("prefix","word"))


def main():
    proofs=load("input/composed-v1.json")["proofs"]
    with gzip.open(ROOT/"input/composed-fragments-v1.json.gz","rt") as fh:
        raw=json.load(fh)
    bank=NativeBank()
    selected={}
    by_case={}
    sources={}
    for proof in proofs:
        label=proof["id"]
        counter=Counter()
        calls=[]
        for call in proof["calls"]:
            original=raw[call["fragment"]]
            prefix,word,bindings=normalize(original["prefix"],original["word"])
            key=fingerprint(prefix,records(word))
            assert key not in selected or selected[key][0]==(prefix,word)
            if key not in selected:
                selected[key]=((prefix,word),label)
            counter["calls"]+=1
            counter["global_reuses"]+=call["reuse"]
            if key in sources:
                counter["canonical_reuses"]+=1
                counter["other_proof_reuses"]+=sources[key]!=label
            else:
                sources[key]=label
            bind(original,dict(prefix=prefix,word=word),bindings)
            calls.append(dict(original=call["fragment"],fragment=key,bindings=bindings))
        by_case[label]=dict(counts=dict(counter),calls=calls)
        print(label,dict(counter),flush=True)
    print("Distinct",len(raw),"global and",len(selected),"canonical",flush=True)
    receivers={"hilbert-incidence-uniqueness","wide-choices-11","nested-iff-12"}
    donor_canonical={c["fragment"] for label,r in by_case.items() if label not in receivers for c in r["calls"]}
    donor_global={c["original"] for label,r in by_case.items() if label not in receivers for c in r["calls"]}
    frozen={}
    for label,r in by_case.items():
        if label not in receivers:
            continue
        frozen[label]=dict(calls=len(r["calls"]),
            canonical_hits=sum(c["fragment"] in donor_canonical for c in r["calls"]),
            global_hits=sum(c["original"] in donor_global for c in r["calls"]))
    print("Frozen donor comparisons",frozen,flush=True)
    if sys.argv[1:]==["counts"]:
        return
    assert not sys.argv[1:]
    for key,((prefix,word),_) in selected.items():
        actual,trace,reuse=bank.get(prefix,records(word),True)
        assert actual==key and not reuse and trace["stop"]==bank.verifier.finish
    for key,trace in bank.traces.items():
        assert qualify_fragment(bank.verifier,key,trace) is not None
    for proof in by_case.values():
        for call in proof["calls"]:
            bind(raw[call["original"]],bank.traces[call["fragment"]],call["bindings"])
    tested=next(c for r in by_case.values() for c in r["calls"] if len(c["bindings"])>=2)
    bad=dict(tested["bindings"])
    a,b=tuple(bad)[:2]
    bad[a],bad[b]=bad[b],bad[a]
    try:
        bind(raw[tested["original"]],bank.traces[tested["fragment"]],bad)
    except AssertionError:
        rejected=True
    else:
        raise AssertionError("Wrong receiver map accepted")
    for label,stats in frozen.items():
        calls=by_case[label]["calls"]
        stats["implied_transitions_all_calls"]=sum(bank.traces[c["fragment"]]["steps"] for c in calls)
        stats["implied_transitions_without_donor_hit"]=sum(bank.traces[c["fragment"]]["steps"]
            for c in calls if c["fragment"] not in donor_canonical)
    save("data/receptors-v1.json",dict(status="CHECKED_CANONICAL_GROUND_WANG_RECEPTORS",
        baseline_fragments=len(raw),canonical_fragments=len(selected),cases=by_case,
        frozen_donor_cases=sorted(set(by_case)-receivers),frozen_receivers=frozen,
        wrong_injective_map_rejected=rejected))
    write_gzip(ROOT/"data/canonical-fragments-v1.json.gz",bank.traces)


if __name__=="__main__":
    main()
