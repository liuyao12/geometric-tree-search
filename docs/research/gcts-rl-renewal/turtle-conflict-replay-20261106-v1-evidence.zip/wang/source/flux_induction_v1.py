"""Find and replay a proof using an explicit induction instance."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definitions_v1 import compile_case
from flux_statement_v1 import source
import herbrand_v1 as fol
from logical_projection_v1 import projection,verify
import resolution_v1 as prop
from shared_wang_v1 import attach,verify_certificate
from study_v1 import Certificate,grounded,guarded


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def main():
    original=source()
    normal,translation=compile_case(original)
    f,p,rows=fol.signature(normal)
    names={r["id"]:r for r in rows}
    witness={tuple(d["path"]):d.get("witness") for d in translation["definitions"]}
    step=(witness[(2,0,1)],)
    goal=(witness[(3,)],)
    chosen=[(r["id"],{}) for r in rows if not r["variables"]]
    chosen.extend((
        ("formula2-node-1-1",{"?v1":step}),
        ("formula3-node-2_0_1_0-1",{"?v2_0_1":step}),
        ("formula3-node-2_0_1_0-2",{"?v2_0_1":step}),
        ("transitive-Nat",{"?x":("F",("S",step)),"?y":("F",step),"?z":("zero",)}),
        ("formula3-node-2_1-1",{"?v2_1":goal})
    ))
    atoms={}
    raw=[]
    for name,env in chosen:
        raw.append([(1 if sign else -1)*atoms.setdefault(atom,len(atoms)+1)
                    for sign,atom in grounded(names[name],env)])
    engine=prop.Search(raw,dict(clauses=5000,seconds=10),"PLAIN")
    assert engine.eliminate(len(atoms))=="UNSAT"
    resolution=engine.proof()
    prop.verify_resolution(raw,resolution)
    used,order,premises,lines=fol.reduce_proof(raw,resolution)
    prop.verify_resolution(premises,lines)
    assert any(chosen[j][0]=="formula3-root" for j in used)
    sources,guards=guarded(rows,f,normal["sorts"])
    cert=Certificate(sources,f,p,normal["sorts"],guards)
    ids=[cert.unguard(*chosen[j]) for j in used]
    inverse={v:k for k,v in atoms.items()}
    for row in lines:
        ids.append(cert.resolve(ids[row["left"]],ids[row["right"]],inverse[order[row["pivot"]-1]]))
    bundle=attach(original,"fol",normal,translation,dict(lines=cert.lines))
    full=verify_certificate(original,bundle)
    logical=projection(bundle)
    compact=verify(original,logical)
    save("data/flux-induction-wang-v1.json",bundle)
    save("data/flux-induction-logical-v1.json",logical)
    out=dict(status="CHECKED_EXPLICIT_INDUCTION",selected=len(chosen),used=len(used),
             induction_source_used=True,full=full,logical=compact)
    save("data/flux-induction-v1.json",out)
    print(out,flush=True)


if __name__=="__main__":
    main()
