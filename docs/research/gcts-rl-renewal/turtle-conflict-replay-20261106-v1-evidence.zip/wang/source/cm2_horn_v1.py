"""Compile CM2 halting as a Horn entailment for the existing Wang verifier."""
from collections import Counter, defaultdict, deque
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from lifted_experiment_v1 import load, save
from lifted_prover_v1 import subst, unifier
from study_v1 import Certificate


def numeral(n):
    term=("zero",)
    for _ in range(n):
        term=("S",term)
    return term


def state(pc,a,b):
    return (f"P{pc}",a,b)


def encode(case):
    program=case["program"]
    halt=len(program)
    x,y="?x","?y"
    parameters={x:"U",y:"U"}
    facts=[]

    def row(name,values,*atoms):
        facts.append(dict(id=name,variables=values,clause=atoms))

    pc,a,b=case["initial"]
    assert all(type(v) is int and v>=0 for v in (pc,a,b))
    row("initial",{},(True,state(min(pc,halt),numeral(a),numeral(b))))
    for i,instruction in enumerate(program):
        op,c,*targets=instruction
        assert type(c) is int and c in (0,1)
        terms=(x,y)
        successor=list(terms)
        successor[c]=("S",terms[c])
        if op=="inc":
            assert not targets
            row(f"instruction-{i}-inc",parameters,(False,state(i,*terms)),(True,state(i+1,*successor)))
        else:
            target,=targets
            assert op=="dec" and type(target) is int and target>=0
            row(f"instruction-{i}-nonzero",parameters,
                (False,state(i,*successor)),(True,state(min(target,halt),*terms)))
            zero=list(terms)
            zero[c]=("zero",)
            row(f"instruction-{i}-zero",{terms[1-c]:"U"},(False,state(i,*zero)),(True,state(i+1,*zero)))
    row("denied-halt",parameters,(False,state(halt,x,y)))
    return dict(id=case["id"],sorts=["U"],functions={"zero":[[],"U"],"S":[["U"],"U"]},
                predicates={f"P{i}":["U","U"] for i in range(halt+1)},
                equality=False,clauses=facts,goal=None)


def search(normal,limit=None):
    f,p,schemas=fol.signature(normal)
    by_head=defaultdict(list)
    builder=Certificate({r["id"]:r for r in schemas},f,p,normal["sorts"],{})
    queued=deque()
    seen={}
    statistics=Counter()
    order=[]
    for s in schemas:
        first,*rest=s["clause"]
        if first[0]:
            assert not rest and not s["variables"]
            queued.append((first[1],builder.instance(s["id"],{})))
            seen[first[1]]=0
        else:
            by_head[first[1][0]].append(s)
    while queued and (limit is None or len(order)<limit):
        atom,line=queued.popleft()
        order.append(atom)
        for row in by_head[atom[0]]:
            _,pattern=row["clause"][0]
            statistics["offers"]+=1
            found=unifier(pattern,atom,row["variables"],f,statistics)
            if found is None:
                continue
            if len(row["clause"])==1:
                last=builder.resolve(line,builder.instance(row["id"],found),atom)
                assert not builder.lines[last]["clause"]
                return dict(status="PROVED",configurations=order,proof=dict(lines=builder.lines),stats=dict(statistics))
            next_=subst(row["clause"][1][1],found)
            if next_ in seen:
                statistics["revisits"]+=1
                continue
            next_line=builder.resolve(line,builder.instance(row["id"],found),atom)
            assert builder.lines[next_line]["clause"]==[(True,next_)]
            queued.append((next_,next_line))
            seen[next_]=len(order)
    return dict(status="BOUNDED" if queued else "CLOSED",configurations=order,proof=None,stats=dict(statistics))


def fixtures():
    return [*load("input/programs-v1.json"),
        dict(id="C05",name="Increase the first counter forever",program=[["inc",0],["inc",1],["dec",1,0]],
             initial=[0,0,0],max_lines=24,counter_cap=40),
        dict(id="C06",name="Transfer two units and drain the second counter",program=[["inc",1],["dec",0,0],["dec",1,2]],
             initial=[1,2,0],max_lines=24,counter_cap=10),
        dict(id="C07",name="Take a second-counter zero branch",program=[["dec",1,0],["inc",0]],
             initial=[0,0,0],max_lines=8,counter_cap=10)]


def main():
    rows=[]
    for case in fixtures():
        compiled=encode(case)
        result=search(compiled,case["max_lines"])
        rows.append(dict(id=case["id"],case=case,compiled=compiled,**result))
        print(case["id"],result["status"],len(result["configurations"]),
              len(result["proof"]["lines"]) if result["proof"] else None,flush=True)
    save("data/cm2-search-v1.json",dict(status="SEARCHED_CM2_HORN_ON_SHARED_PALETTE",results=rows))


if __name__=="__main__":
    main()
