"""Replay geometric search with source-bound arithmetic certificates at its cuts."""
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]


def main():
    geometry=ROOT/"geometry/penrose"
    result=subprocess.run([sys.executable,"-I","-S","-B","source/proof_cuts_v1.py"],
                          cwd=geometry,check=True,capture_output=True,text=True)
    value=json.loads(result.stdout)
    (ROOT/"data/proof-cuts-v1.json").write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")
    print(value["status"],len(value["matched"]),len(value["uses"]),len(value["lemmas"]),flush=True)


if __name__=="__main__":
    main()
