"""Compare native first-order admission schedules on identical symbolic proposals."""
from collections import defaultdict
from pathlib import Path
from random import Random
import re
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_cases_v1 import a, all_, implies
from lifted_experiment_v1 import load, save
from lifted_ground_v1 import compile_proof
from lifted_native_v1 import NativeBank, Receiver
from lifted_prover_v1 import Prover
from native_v1 import PUBLISHED_MACHINE
from study_v1 import write_gzip

ROOT=Path(__file__).resolve().parents[1]
LIMITS=dict(offer_cap=2500,node_cap=4000)
ORDERS=("size","goal")
TARGETS=("factoring-to-universal","proof-by-cases","iterate-depth-8","exists-map","incidence-existence",
         "hilbert-incidence-uniqueness","tptp-tutorial-family","receiver-alias",
         "occurs-check-control","quantifier-swap-control")


def features(s):
    if len(s["sorts"])>1:
        return "many-sorted"
    return "equality" if s["equality"] else "ordinary"


def typed_training(i):
    p,q,r=(f"r{i}{j}" for j in range(3))
    x,l,m="?x","?l","?m"
    point,left,right=(f"b{i}",),(f"u{i}",),(f"v{i}",)
    ps,ls="Point","Line"
    raw=["and",a(p,x,l),["and",a(q,x,m),a(r,x)]]
    axiom=all_(x,all_(l,all_(m,implies(raw,a("=Line",l,m)),ls),ls),ps)
    return dict(id=f"typed-training-{i}",sorts=[ps,ls],equality=True,
                functions={point[0]:[[],ps],left[0]:[[],ls],right[0]:[[],ls]},
                predicates={p:[ps,ls],q:[ps,ls],r:[ps]},
                premises=[axiom,a(p,point,left),a(q,point,right),a(r,point)],
                goal=a("=Line",left,right))


def setup(bank,s,order,mode,defer=True,seed=None):
    bank.memo=dict(seed or {})
    gate=None if mode=="direct" else Receiver(bank,mode)
    engine=Prover(s,order=order,admission=gate,defer=defer,**LIMITS)
    status,root=engine.run()
    return engine,root,dict(status=status,order=order,counts=dict(engine.counts),
                            tape=dict(gate.counts) if gate else {},
                            events=gate.events if gate else [])


def preferred(scores):
    return min(ORDERS,key=lambda x:sum(scores[x])/len(scores[x]))


def train(bank,cases):
    episodes=[]
    stats=defaultdict(lambda:defaultdict(list))
    rng=Random(10671)
    for s in cases:
        kind=features(s)
        scores=stats[kind]
        unseen=[x for x in ORDERS if not scores[x]]
        if unseen:
            order=unseen[0]
        elif rng.random()<.25:
            order=rng.choice(ORDERS)
        else:
            order=preferred(scores)
        _,_,row=setup(bank,s,order,"shape")
        tape=row["tape"]
        loss=tape.get("implied_steps",0)//100000+2*tape.get("admissions",0)+row["counts"].get("offers",0)
        if row["status"]!="PROVED":
            loss+=4*LIMITS["offer_cap"]
        scores[order].append(loss)
        episodes.append(dict(id=s["id"],group=kind,loss=loss,**row))
    return episodes,{k:preferred(v) for k,v in sorted(stats.items())}


def warm_donors(bank,cases):
    memo={}
    qualified=[]
    for s in cases:
        _,_,row=setup(bank,s,"goal","shape",seed=memo)
        assert row["status"]=="PROVED"
        memo.update(bank.memo)
        qualified.append(dict(id=s["id"],**row))
    return qualified,memo


def forgeries(bank,rows):
    records={}
    pair=next(e for row in rows for e in row["arms"]["shape"]["events"]
              if e["node"]["kind"]=="resolve" and e["node"]["clause"])
    accepted=bank.traces[pair["fragment"]]
    prefix=accepted["prefix"]
    one,two,move=tuple(x+";" for x in accepted["word"][:-1].split(";"))
    pivot=move[move.rfind(":",0,move.index("/"))+1:move.index("/")]
    wrong=move.replace(pivot+"/","(111111111.)/",1)
    for name,lines in (
        ("wrong-pivot",(one,two,wrong)),
        ("omitted-residual",(one,two,move.split("/")[0]+"/;")),
    ):
        label,result,hit=bank.get(prefix,lines,False)
        assert not hit and result["stop"]==1 and result["commits"]==2
        records[name]=label
    with_binding=next(e for row in rows for e in row["arms"]["shape"]["events"]
                      if e["node"]["kind"]=="factor")
    sample=bank.traces[with_binding["fragment"]]
    altered=re.sub(r"=0:\([01]+\.\)",r"=0:(111111111.)",sample["word"],count=1)
    assert altered!=sample["word"]
    label,result,_=bank.get(sample["prefix"],(altered,),False)
    assert result["stop"]==1 and result["commits"]==0
    records["wrong-instantiation"]=label
    return records


def main():
    bank=NativeBank()
    c=load("input/cohort-v1.json")
    donors,warm=warm_donors(bank,c["donors"])
    training=[*c["training"],*(typed_training(i) for i in range(6))]
    episodes,policy=train(bank,training)
    rows=[]
    for spec in c["holdout"]:
        name=spec["id"]
        if name not in TARGETS:
            continue
        fixed="goal"
        baseline,base_root,bare=setup(bank,spec,fixed,"direct")
        arms={"direct":bare}
        captured=None
        for key,mode,defer,seed in (
            ("eager","off",False,None),("demand","off",True,None),("exact","exact",True,None),
            ("shape","shape",True,None),("warm","shape",True,warm)
        ):
            engine,root,row=setup(bank,spec,fixed,mode,defer,seed)
            assert (engine.nodes,root,row["status"])==(baseline.nodes,base_root,bare["status"])
            arms[key]=row
            if key=="warm" and root is not None:
                captured=engine,root
        chosen=policy[features(spec)]
        engine,root,ranked=setup(bank,spec,chosen,"shape",seed=warm)
        if chosen==fixed:
            assert (engine.nodes,root,ranked)==(baseline.nodes,base_root,arms["warm"])
        arms["ranked"]=ranked
        row=dict(id=name,arms=arms)
        if captured:
            engine,root=captured
            dag=engine.proof(root)
            builder,events,counts=compile_proof(engine,dag)
            row["proof"]=dict(lifted=dag,events=events,elaboration=dict(counts),skolem=engine.skolems,
                              lines=builder.lines,source_clauses=list(builder.sources.values()))
        rows.append(row)
        print(name,bare["status"],"order",chosen,
              {k:(v["tape"].get("admissions",0),v["tape"].get("runs",0),v["tape"].get("reuse",0))
               for k,v in arms.items()},flush=True)
    controls=forgeries(bank,rows)
    result=dict(status="LIFTED_MOVES_ADMITTED_BY_FIXED_WANG",limits=LIMITS,machine_sha256=PUBLISHED_MACHINE,
                donors=donors,episodes=episodes,policy=policy,cases=rows,controls=controls,
                seeded_shapes=len(warm))
    save("data/search-v1.json",result)
    write_gzip(ROOT/"data/native-fragments-v1.json.gz",bank.traces)


if __name__=="__main__":
    main()
