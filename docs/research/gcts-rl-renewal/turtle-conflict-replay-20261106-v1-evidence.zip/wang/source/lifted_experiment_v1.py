"""Learn unification exclusions and compare paired searches before tile replay."""
from collections import Counter, defaultdict
from pathlib import Path
from random import Random
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_prover_v1 import Prover
from lifted_ground_v1 import compile_proof
import herbrand_v1 as fol

ROOT=Path(__file__).resolve().parents[1]
ACTIONS=("size","goal")
LIMITS=dict(offer_cap=20_000,node_cap=18_000)
MODES=("size","size-marked","goal","goal-marked")


def load(name):
    return json.loads((ROOT/name).read_text())


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def features(case):
    return "equality" if case["equality"] else "ordinary"


def value(stats,status):
    return stats["offers"]+stats["equations"]+stats["mark_tests"]+(
        4*LIMITS["offer_cap"] if status!="PROVED" else 0)


def preferred(cost):
    return min(ACTIONS,key=lambda a:sum(cost[a])/len(cost[a]))


def train(cases,bank):
    rng=Random(309921)
    groups=defaultdict(lambda:defaultdict(list))
    episodes=[]
    for case in cases:
        group=features(case)
        costs=groups[group]
        unseen=[a for a in ACTIONS if not costs[a]]
        if unseen:
            order=unseen[0]
        elif rng.random()<.25:
            order=rng.choice(ACTIONS)
        else:
            order=preferred(costs)
        engine=Prover(case,order=order,marks=bank,**LIMITS)
        result,_=engine.run()
        loss=value(engine.counts,result)
        costs[order].append(loss)
        episodes.append(dict(id=case["id"],group=group,order=order,loss=loss,outcome=result))
    return episodes,{g:preferred(groups[g]) for g in sorted(groups)}


def propose():
    cohort=load("input/cohort-v1.json")
    donor_index=defaultdict(list)
    for case in cohort["donors"]:
        learner=Prover(case,learn=True,**LIMITS)
        status,_=learner.run()
        assert status=="PROVED"
        for mark,(left,right) in learner.discovered.items():
            donor_index[mark].append(dict(id=case["id"],left=left,right=right))
    bank=tuple(sorted(donor_index,key=lambda a:(-len(donor_index[a]),a))[:5])
    assert any(m[0]=="alias" for m in bank) and any(m[0]=="rigid" for m in bank)
    donors=[dict(mark=m,sources=donor_index[m]) for m in bank]
    episodes,policy=train(cohort["training"],bank)
    rows=[]
    for case in cohort["holdout"]:
        row=dict(id=case["id"],selected_policy=policy[features(case)]+"-marked",arms={})
        proof_candidates=[]
        baseline={}
        for mode in MODES:
            order=mode.split("-")[0]
            marked=mode.endswith("-marked")
            engine=Prover(case,order=order,marks=bank if marked else (),**LIMITS)
            outcome,root=engine.run()
            proof=engine.proof(root) if root is not None else None
            if not marked:
                baseline[order]=(outcome,root,engine.nodes)
                if proof is not None:
                    proof_candidates.append((len(proof),order,proof,engine))
            else:
                # Same search proposals, accepted inferences, and certificate.
                assert baseline[order]==(outcome,root,engine.nodes)
            row["arms"][mode]=dict(status=outcome,counts=dict(engine.counts),
                                   lifted_lines=None if proof is None else len(proof),
                                   marks=[(m,a,b,n) for (m,a,b),n in sorted(engine.failed_uses.items(),key=repr)])
        if proof_candidates:
            _,order,proof,engine=min(proof_candidates,key=lambda x:(x[0],x[1]))
            builder,events,counts=compile_proof(engine,proof)
            depths=[fol.depth(t) for line in builder.lines if line["rule"]=="G" for t in line["bindings"].values()]
            proof_depth=max((fol.depth(t) for line in builder.lines for _,atom in line["clause"]
                             for t in atom[1:]),default=0)
            row["proof"]=dict(lifted=proof,order=order,events=events,elaboration=dict(counts),
                skolem=engine.skolems,lines=builder.lines,source_clauses=list(builder.sources.values()),
                maximum_substitution_depth=max(depths,default=0),maximum_proof_term_depth=proof_depth)
        rows.append(row)
        print(json.dumps(dict(id=row["id"],policy=row["selected_policy"],
            arms={a:(r["status"],r["counts"].get("offers"),r["counts"].get("marked_skips",0))
                  for a,r in row["arms"].items()},lines=len(row.get("proof",{}).get("lines",[]))),sort_keys=True),flush=True)
    save("data/search-v1.json",dict(status="PAIRED_FIRST_ORDER_SEARCH",limits=LIMITS,donors=donors,
                                     policy=policy,episodes=episodes,cases=rows))


if __name__=="__main__":
    propose()
