"""Check the unbounded-schedule prototype's finite proof witnesses."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definition_cases_v1 import a, all_
from definition_composition_v1 import fragment, link
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import NativeBank
from native_audit_v1 import qualify_fragment
from native_marked_v1 import records
from study_v1 import write_gzip


def main():
    bank=NativeBank()
    receipts=[]
    verified={}
    countermodels=[]
    for item in load("data/fair-ground-v1.json")["results"]:
        spec=item["original"]
        normal=item["normal"]
        check(spec,normal,item["certificate"])
        if item["proof"] is None:
            assert item["status"]=="DEPTH_BOUND"
            assert spec["premises"]==[all_("?x",a("P","?x"))]
            assert spec["goal"]==all_("?x",a("Q","?x"))
            domain=(0,)
            relations={"P":((0,),),"Q":()}
            assert all((x,) in relations["P"] for x in domain)
            assert any((x,) not in relations["Q"] for x in domain)
            countermodels.append(dict(id=spec["id"],domain=domain,relations=relations))
            continue
        proof=item["proof"]
        row=dict(original=spec,compiled=normal,definition=dict(proof=proof))
        calls=[]
        for i in range(len(proof["lines"])):
            b=fragment(row,proof["lines"],i)
            key,trace,hit=bank.get(b.prefix(),records(b.words()[:-1]),True)
            if key not in verified:
                verified[key]=qualify_fragment(bank.verifier,key,trace)
                assert verified[key] is not None
            calls.append(dict(fragment=key,reuse=hit))
        receipt,_=link(row,calls,bank.traces,verified)
        receipts.append(dict(id=spec["id"],receipt=receipt,calls=calls))
        print(spec["id"],receipt,flush=True)
    assert len(receipts)==3
    write_gzip(ROOT/"data/fair-ground-fragments-v1.json.gz",bank.traces)
    save("data/fair-ground-audit-v1.json",dict(status="CHECKED_SHARED_WANG_GROUND_WITNESSES",
        machine_sha256=bank.verifier.machine.digest(),receipts=receipts,countermodels=countermodels))


if __name__=="__main__":
    main()
