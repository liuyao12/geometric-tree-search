"""Select Peano ground instances along a demanded successor spine."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definitions_v1 import compile_case
import herbrand_v1 as fol
from pocket_arithmetic_v1 import statement
import resolution_v1 as prop
from shared_wang_v1 import attach, verify_certificate
from study_v1 import Certificate, grounded, guarded


def power(t,n):
    for _ in range(n):
        t=("S",t)
    return t


def instantiate(source,scale,target):
    assert target%scale
    normal,translation=compile_case(source)
    functions,predicates,schemas=fol.signature(normal)
    by_name={row["id"]:row for row in schemas}
    defs={tuple(row["path"]):row for row in translation["definitions"]}
    chosen={}
    def use(name,**env):
        assert env.keys()==by_name[name]["variables"].keys()
        chosen[(name,tuple(sorted(env.items())))]=None

    for row in schemas:
        if not row["variables"]:
            use(row["id"])

    def eq_sym(a,b):
        use("symmetric-Nat",**{"?x":a,"?y":b})

    def eq_trans(a,b,c):
        use("transitive-Nat",**{"?x":a,"?y":b,"?z":c})

    def eq_cong(a,b):
        use("congruence-F",**{"?l0":a,"?r0":b})

    def nonzero(t):
        use("formula1-node-0-1",**{"?v0":t})

    def cancel(a,b):
        use("formula2-node-1-1",**{"?v1":a})
        env={"?v1":a,"?v1_0":b}
        use("formula2-node-1_0-1",**env)
        use("formula2-node-1_0_0-3",**env)

    z=("zero",)
    x=(defs[(5,)]["witness"],)
    pred=defs[(2,0,1)]["witness"]
    for residual in range(target,0,-scale):
        y=(pred,x)
        sy=("S",y)
        want=power(z,residual)
        fx,f0,fsy,fy=("F",x),("F",z),("F",sy),("F",y)
        raised=power(fy,scale)
        for clause in ("formula3-node-2-1","formula3-node-2_0-3","formula3-node-2_0_1-2"):
            use(clause,**{"?v2":x})
        eq_cong(x,z)
        eq_sym(fx,want)
        eq_trans(want,fx,f0)
        eq_trans(want,f0,z)
        nonzero(power(z,residual-1))
        eq_cong(x,sy)
        use("formula5-node-4-1",**{"?v4":y})
        eq_trans(fx,fsy,raised)
        eq_sym(fx,raised)
        eq_trans(raised,fx,want)
        for i in range(1,min(scale,residual)+1):
            cancel(power(fy,scale-i),power(z,residual-i))
        if residual<scale:
            nonzero(power(fy,scale-residual-1))
        x=y

    origins=list(chosen)
    atoms={}
    premises=[]
    for name,env in origins:
        premises.append([(1 if sign else -1)*atoms.setdefault(atom,len(atoms)+1)
                         for sign,atom in grounded(by_name[name],dict(env))])
    engine=prop.Search(premises,dict(clauses=200000,seconds=20),"PLAIN")
    assert engine.eliminate(len(atoms))=="UNSAT"
    resolution=engine.proof()
    prop.verify_resolution(premises,resolution)
    used,names,checks,lines=fol.reduce_proof(premises,resolution)
    prop.verify_resolution(checks,lines)
    sources,guards=guarded(schemas,functions,normal["sorts"])
    builder=Certificate(sources,functions,predicates,normal["sorts"],guards)
    references=[]
    for index in used:
        name,env=origins[index]
        references.append(builder.unguard(name,dict(env)))
    inverse={n:p for p,n in atoms.items()}
    for row in lines:
        pivot=inverse[names[row["pivot"]-1]]
        references.append(builder.resolve(references[row["left"]],references[row["right"]],pivot))
    assert not builder.lines[-1]["clause"]
    return normal,translation,dict(lines=builder.lines),dict(selected=len(origins),used=len(used),atoms=len(atoms))


def main():
    results=[]
    for scale,value in ((2,1),(2,3),(5,9)):
        source=statement(scale,value)
        normal,translation,proof,stats=instantiate(source,scale,value)
        bundle=attach(source,"fol",normal,translation,proof)
        receipt=verify_certificate(source,bundle)
        name=f"peano-spine-{scale}-{value}-v1.json"
        (ROOT/"data"/name).write_text(json.dumps(bundle,sort_keys=True,separators=(",",":"))+"\n")
        results.append(dict(case=source["id"],artifact=name,search=stats,receipt=receipt))
        print(source["id"],stats,receipt,flush=True)
    (ROOT/"data/arithmetic-spine-summary-v1.json").write_text(json.dumps(results,sort_keys=True)+"\n")


if __name__=="__main__":
    main()
