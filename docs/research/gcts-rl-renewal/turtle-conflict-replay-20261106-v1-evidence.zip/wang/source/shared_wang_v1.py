"""Search and independently replay portable certificates on the shared palette."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import cm2_horn_v1 as cm2
from definition_check_v1 import check
from definition_composition_v1 import fragment, link
from definitions_v1 import compile_case
import fair_ground_v1 as fair
from lifted_experiment_v1 import load
from lifted_native_v1 import CAP,NativeBank
from native_audit_v1 import qualify_fragment
from native_marked_v1 import records
from native_v1 import PUBLISHED_MACHINE
from tactic_policy_v1 import context, solve

SCHEMA="SHARED-WANG-CERTIFICATE-v1"


def json_value(value):
    return json.loads(json.dumps(value))


def binding(source,kind,normal,translation):
    if kind=="fol":
        check(source,normal,translation)
    else:
        assert kind=="cm2" and translation is None
        assert normal==json_value(cm2.encode(source))


def attach(source,kind,normal,translation,proof,steps=CAP):
    row=dict(original=source,compiled=normal,definition=dict(proof=proof))
    bank=NativeBank(cap=steps)
    calls=[]
    for i in range(len(proof["lines"])):
        b=fragment(row,proof["lines"],i)
        key,evidence,reused=bank.get(b.prefix(),records(b.words()[:-1]),True)
        assert evidence["stop"]==bank.verifier.finish
        calls.append(dict(fragment=key,reuse=reused))
    return json_value(dict(schema=SCHEMA,machine_sha256=PUBLISHED_MACHINE,kind=kind,
        compiled=normal,translation=translation,proof=proof,calls=calls,traces=bank.traces))


def verify_certificate(source,bundle):
    if not __debug__:
        raise RuntimeError("Certificate checking requires Python assertions")
    assert bundle["schema"]==SCHEMA and bundle["machine_sha256"]==PUBLISHED_MACHINE
    kind,normal,translation=(bundle[k] for k in ("kind","compiled","translation"))
    binding(source,kind,normal,translation)
    traces=bundle["traces"]
    calls=bundle["calls"]
    seen=set()
    for c in calls:
        k=c["fragment"]
        assert c["reuse"]==(k in seen)
        seen.add(k)
    assert seen==set(traces)
    bank=NativeBank()
    decoded={k:qualify_fragment(bank.verifier,k,v) for k,v in traces.items()}
    row=dict(original=source,compiled=normal,definition=dict(proof=bundle["proof"]))
    receipt,used=link(row,calls,traces,decoded)
    assert used==seen
    return dict(status="CHECKED",kind=kind,machine_sha256=PUBLISHED_MACHINE,**receipt)


def propose(source,kind,limit=None,guided=False):
    if kind=="cm2":
        assert not guided
        normal=cm2.encode(source)
        return normal,None,cm2.search(normal,limit)
    assert kind=="fol"
    normal,translation=compile_case(source)
    check(source,normal,translation)
    prepass=None
    if guided:
        policy=load("input/tactic-policy-v1.json")["policy"]
        prepass,proof=solve(source,normal,policy.get(context(source),"lift"))
        if proof is not None:
            return normal,translation,dict(status="PROVED",proof=proof,route="guided",prepass=prepass)
    result=fair.search(normal,limit)
    return normal,translation,dict(**result,route="increasing-depth",prepass=prepass)


def natural(value):
    n=int(value)
    if n<0:
        raise argparse.ArgumentTypeError("bound must be nonnegative")
    return n


def main():
    if not __debug__:
        raise RuntimeError("Certificate checking requires Python assertions")
    parser=argparse.ArgumentParser(description=__doc__)
    commands=parser.add_subparsers(dest="action",required=True)
    prove=commands.add_parser("prove")
    prove.add_argument("kind",choices=("fol","cm2"))
    prove.add_argument("source",type=Path)
    prove.add_argument("output",type=Path)
    prove.add_argument("--limit",type=natural,help="fallback term depth or number of CM2 configurations")
    prove.add_argument("--guided",action="store_true",help="try the frozen tactic policy before first-order fallback")
    prove.add_argument("--tile-steps",type=natural,default=CAP,help="maximum tape steps per local proof record")
    verify=commands.add_parser("verify")
    verify.add_argument("source",type=Path)
    verify.add_argument("bundle",type=Path)
    args=parser.parse_args()
    source=json.loads(args.source.read_text())
    if args.action=="verify":
        receipt=verify_certificate(source,json.loads(args.bundle.read_text()))
    else:
        if args.guided and args.kind!="fol":
            parser.error("--guided applies to first-order inputs")
        normal,translation,result=propose(source,args.kind,args.limit,args.guided)
        if result["proof"] is None:
            print(json.dumps({k:v for k,v in result.items() if k!="proof"},sort_keys=True))
            return 2
        bundle=attach(source,args.kind,normal,translation,result["proof"],args.tile_steps)
        receipt=verify_certificate(source,bundle)
        with args.output.open("x") as f:
            json.dump(bundle,f,sort_keys=True,separators=(",",":"))
            f.write("\n")
        if "route" in result:
            receipt["route"]=result["route"]
    print(json.dumps(receipt,sort_keys=True))
    return 0


if __name__=="__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, KeyError, OSError, TypeError, ValueError, RuntimeError) as exc:
        print(f"Rejected input or certificate: {exc or type(exc).__name__}",file=sys.stderr)
        raise SystemExit(1)
