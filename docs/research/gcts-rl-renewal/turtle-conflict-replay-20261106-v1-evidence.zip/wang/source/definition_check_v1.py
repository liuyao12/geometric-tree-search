"""Independently check the clause boundary against closed first-order formulas."""
from itertools import product
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from herbrand_v1 import frozen, signature


def admitted(op,mark,left,right):
    if op=="all":
        return (not mark or left) and (mark or not right)
    if op=="exists":
        return (mark or not left) and (not mark or right)
    value={"and":left and right,"or":left or right,
           "implies":not left or right,"iff":left==right}[op]
    return mark==value


def check(problem,compiled,certificate):
    sorts=problem["sorts"]
    assert len(set(sorts))==len(sorts) and sorts
    functions=dict(problem["functions"])
    predicates=dict(problem["predicates"])
    assert type(problem["equality"]) is bool
    assert all(not name.startswith(("$type:","=")) for name in functions.keys()|predicates.keys())
    assert all(s in sorts for args,out in functions.values() for s in (*args,out))
    assert all(s in sorts for args in predicates.values() for s in args)
    typed={p:tuple(args) for p,args in predicates.items()}
    if problem["equality"]:
        typed.update({"="+s:(s,s) for s in sorts})
    fresh=set(functions)|set(typed)
    definitions={tuple(d["path"]):d for d in certificate["definitions"]}
    assert len(definitions)==len(certificate["definitions"])
    rows=[]
    checked_tables=0

    def claim(name):
        assert isinstance(name,str) and name and not name.startswith(("$type:","="))
        assert name not in fresh
        fresh.add(name)

    def variables(t):
        if isinstance(t,str):
            return {t}
        return set().union(*(variables(arg) for arg in t[1:]))

    def certify_clause(i,label,literals,typing):
        unique=set(literals)
        needed=set().union(*(variables(atom) for _,atom in unique))
        rows.append((f"formula{i+1}-{label}",{v:typing[v] for v in needed},tuple(sorted(unique,key=repr))))

    def typed_term(t,env):
        if isinstance(t,str):
            return env[t]
        name,*args=t
        expected,sort=problem["functions"][name]
        values=[typed_term(x,env) for x in args]
        assert [s for _,s in values]==expected
        return (name,*(v for v,_ in values)),sort

    def visit(node,path,env,typing):
        nonlocal checked_tables
        op,*parts=node
        if op=="atom":
            pred,*terms=parts
            values=[typed_term(t,env) for t in terms]
            assert tuple(s for _,s in values)==typed[pred]
            return True,(pred,*(t for t,_ in values))
        if op=="not":
            body,=parts
            sign,atom=visit(body,(*path,0),env,typing)
            return not sign,atom
        suffix="_".join(str(i) for i in path)
        if op in ("all","exists"):
            var,sort,body=parts
            assert var.startswith("?") and sort in sorts
            v="?v"+suffix
            typing={**typing,v:sort}
            sign,atom=visit(body,(*path,0),{**env,var:(v,sort)},typing)
            free=variables(atom)
            if v not in free:
                return sign,atom
            parameters=tuple(sorted(free-{v}))
            record=definitions.pop(path)
            witness=record["witness"]
            claim(witness)
            functions[witness]=([typing[t] for t in parameters],sort)
            value=(witness,*parameters)
            def replace(term):
                if isinstance(term,str):
                    return value if term==v else term
                return (term[0],*(replace(x) for x in term[1:]))
            children=((sign,atom),(sign,replace(atom)))
        else:
            assert op in ("and","or","implies","iff")
            left,right=parts
            children=(visit(left,(*path,0),env,typing),visit(right,(*path,1),env,typing))
            parameters=tuple(sorted(variables(children[0][1])|variables(children[1][1])))
            record=definitions.pop(path)
            assert record["witness"] is None
        assert record["operator"]==op
        symbol=record["name"]
        claim(symbol)
        predicates[symbol]=[typing[t] for t in parameters]
        templates=record["templates"]
        assert all(clause and all(type(k) is int and 1<=abs(k)<=3 for k in clause)
                   for clause in templates)
        for valuation in product((False,True),repeat=3):
            observed=all(any(valuation[abs(k)-1]==(k>0) for k in clause) for clause in templates)
            assert observed==admitted(op,*valuation),(path,valuation)
            checked_tables+=1
        top=True,(symbol,*parameters)
        slots=(top,*children)
        for j,template in enumerate(templates,1):
            line=[]
            for slot in template:
                sign,atom=slots[abs(slot)-1]
                line.append((sign==(slot>0),atom))
            certify_clause(path[0],f"node-{suffix}-{j}",line,typing)
        return top

    for i,formula in enumerate((*problem["premises"],problem["goal"])):
        sign,atom=visit(formula,(i,),{},{})
        certify_clause(i,"root",[(sign==(i<len(problem["premises"])),atom)],{})
    assert not definitions
    inhabitants=dict(certificate["inhabitants"])
    for s in sorts:
        if not any(not args and out==s for args,out in functions.values()):
            name=inhabitants.pop(s)
            claim(name)
            functions[name]=([],s)
    assert not inhabitants
    assert compiled["id"]==problem["id"] and compiled["sorts"]==sorts and compiled["goal"] is None
    assert compiled["equality"]==problem["equality"]
    def normalized_functions(bank):
        return {f:(tuple(args),out) for f,(args,out) in bank.items()}
    assert normalized_functions(compiled["functions"])==normalized_functions(functions)
    assert compiled["predicates"]==predicates
    actual=[(r["id"],r["variables"],frozen(r["clause"])) for r in compiled["clauses"]]
    assert actual==rows
    signature(compiled)
    return dict(definitions=len(certificate["definitions"]),rows=len(rows),local_truth_assignments=checked_tables)
