"""Check the inherited donor traces and source problem fixtures against their pins."""
from hashlib import sha256
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_experiment_v1 import ROOT, load


def main():
    origin=load("input/origin-v1.json")
    for name,row in origin.items():
        raw=(ROOT/name).read_bytes()
        assert len(raw)==row["bytes"] and sha256(raw).hexdigest()==row["sha256"]
    previous=load("input/composed-audit-v1.json")
    calls=load("input/composed-v1.json")
    assert previous["status"]=="CHECKED_COMPOSED_WANG_REFUTATIONS"
    assert previous["distinct_fragments"]==calls["distinct_fragments"]
    assert {r["id"]:len(r["calls"]) for r in calls["proofs"]}=={
        name:row["fragment_calls"] for name,row in previous["proof_receipts"].items()}
    print(len(origin),"inherited files match the earlier archive manifests.",flush=True)


if __name__=="__main__":
    main()
