"""Run the compact-record command line on valid and mismatched inputs."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]


def command(*args,expected=0):
    result=subprocess.run([sys.executable,"-I","-S","-B","source/logical_records_cli_v1.py",*args],
                          cwd=ROOT,capture_output=True,text=True)
    assert result.returncode==expected,result.stderr
    if expected:
        assert "Proof records rejected" in result.stderr
        return {"status":"REJECTED"}
    return json.loads(result.stdout)


def main():
    source="input/penrose-regular-fol-v1.json"
    full="data/penrose-regular-wang-v1.json"
    with TemporaryDirectory() as scratch:
        output=Path(scratch)/"projection.json"
        first=command("project",source,full,str(output))
        assert output.read_bytes()==(ROOT/"data/penrose-regular-records-v1.json").read_bytes()
        second=command("verify",source,str(output))
        assert first==second
        wrong=command("verify","input/penrose-concave-fol-v1.json",str(output),expected=1)
    turtle=command("verify","input/coefficient-5-9.json","data/area-coefficient-5-9-logical-v1.json")
    report=dict(status="CHECKED_RECORDS_CLI",projection=first,wrong_source=wrong,turtle=turtle)
    (ROOT/"data/records-cli-v1.json").write_text(json.dumps(report,sort_keys=True,separators=(",",":"))+"\n")
    print(report,flush=True)


if __name__=="__main__":
    main()
