"""Decode proof text independently of the tape program and check every line."""
import re


def digits(text):
    if re.fullmatch("[01]+", text) is None:
        raise ValueError("Expected a binary token")
    return text


def atom(text, start=0, template=False):
    if template and text[start:start+1] == "%":
        end = text.index(",", start)
        return digits(text[start+1:end]), end+1
    if text[start:start+1] != "(":
        raise ValueError("Expected term")
    end = text.index(".", start)
    name = digits(text[start+1:end])
    children = []
    i = end+1
    while text[i:i+1] != ")":
        t, i = atom(text, i, template)
        children.append(t)
    return (name, *children), i+1


def single(text):
    t, i = atom(text)
    if i != len(text):
        raise ValueError("Extra characters after term")
    return t


def clause(text, template=False):
    values = []
    i = 0
    while i < len(text):
        sign = text[i]
        if sign not in "+-":
            raise ValueError("Expected literal sign")
        a, i = atom(text, i+1, template)
        if isinstance(a, str):
            raise ValueError("Predicate name cannot be a variable")
        values.append((sign == "+", a))
    return values


def records(text):
    if not text.endswith(";"):
        raise ValueError("Missing record terminator")
    return text[:-1].split(";")


def instance(t, env):
    return env[t] if isinstance(t, str) else (t[0], *(instance(x, env) for x in t[1:]))


def read(prefix, proof, *, require_empty=True):
    if not prefix.startswith(">") or not prefix.endswith("#") or not proof.rstrip("~").endswith("!"):
        raise ValueError("Missing boundary")
    schemas = {}
    for item in records(prefix[1:-1]):
        if not item.startswith("C"):
            raise ValueError("Expected source record")
        name, body = item[1:].split(":", 1)
        schemas.setdefault(digits(name), clause(body, template=True))

    rows = []
    earlier = {}
    for line in records(proof.rstrip("~")[:-1]):
        head, body = line.split("/")
        out = clause(body)
        rule, fields = head[:1], head[1:].split(":")
        name = digits(fields[0])
        if rule == "G":
            _, schema, bindings = fields[0], digits(fields[1]), ":".join(fields[2:])
            env = {}
            if bindings:
                if not bindings.startswith("="):
                    raise ValueError("Expected binding marker")
                for binding in bindings[1:].split("="):
                    x, term = binding.split(":")
                    env.setdefault(digits(x), single(term))
            expected = [(sign, instance(a, env)) for sign, a in schemas[schema]]
            if out != expected:
                raise ValueError("Invalid simultaneous instance")
            evidence = dict(schema=schema, substitution=env)
        elif rule == "R":
            _, left, right, raw = fields
            left, right = digits(left), digits(right)
            a, b = (set(rows[earlier[key]]["clause"]) for key in (left, right))
            pivot = single(raw)
            if (True, pivot) not in a or (False, pivot) not in b:
                raise ValueError("Pivot signs disagree")
            if not (a - {(True, pivot)}) | (b - {(False, pivot)}) <= set(out):
                raise ValueError("Resolution conclusion drops a residual literal")
            evidence = dict(left=earlier[left], right=earlier[right], pivot=pivot)
        else:
            raise ValueError("Unknown rule")
        earlier.setdefault(name, len(rows))
        rows.append(dict(rule=rule, raw=line, clause=out, **evidence))
    if not rows or (require_empty and rows[-1]["clause"]):
        raise ValueError("Empty final clause required")
    return rows


def accepts(prefix, proof):
    try:
        read(prefix, proof)
    except (ValueError, KeyError, IndexError):
        return False
    return True
