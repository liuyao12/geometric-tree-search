"""Test the frozen canonical bank on larger renamed and reshaped receivers."""
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_cases_v1 import a, all_, case, combine
from definition_check_v1 import check
from definition_composition_v1 import fragment, link
from definition_experiment_v1 import attempt
from definitions_v1 import compile_case
import decode_v1 as decoder
from fragment_receptors_v1 import bind, normalize
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import NativeBank, fingerprint
from native_audit_v1 import qualify_fragment
from native_marked_v1 import records


def balanced(items):
    if len(items)==1:
        return items[0]
    split=len(items)//2
    return ["or",balanced(items[:split]),balanced(items[split:])]


def receiver(label,n,grouping):
    left=[f"{label}A{i}" for i in range(n)]
    right=[f"{label}B{i}" for i in range(n)]
    clauses=[["and",a(p,"?r"),a(q,"?r")] for p,q in zip(left,right,strict=True)]
    goal=[a(p,"?z") for p in left]
    if grouping=="balanced":
        premise=balanced(clauses)
        wanted=balanced(goal[::-1])
    else:
        premise=combine("or",clauses)
        wanted=combine("or",goal)
    return case(label,{},dict.fromkeys((*left,*right),1),
                [all_("?r",premise)],all_("?z",wanted))


def main():
    study=load("data/receptors-v1.json")
    with gzip.open(ROOT/"data/canonical-fragments-v1.json.gz","rt") as fh:
        canonical=json.load(fh)
    frozen_cases=set(study["frozen_donor_cases"])
    donor_keys={c["fragment"] for n,r in study["cases"].items() if n in frozen_cases for c in r["calls"]}
    exact_keys={c["original"] for n,r in study["cases"].items() if n in frozen_cases for c in r["calls"]}
    bank=NativeBank()
    verified={}
    output={}
    for label,n,shape in (("fresh_wide_17",17,"comb"),("fresh_balanced_17",17,"balanced"),
                          ("fresh_wide_23",23,"comb")):
        original=receiver(label,n,shape)
        normal,cert=compile_case(original)
        check(original,normal,cert)
        found=attempt(original,normal,keep_proof=True)
        print(label,found["status"],found["counts"].get("offers"),flush=True)
        if found["proof"] is None:
            output[label]=dict(status=found["status"],offers=found["counts"]["offers"])
            continue
        row=dict(original=original,compiled=normal,definition=found)
        row["definition"]=json.loads(json.dumps(found))
        calls=[]
        virtual={}
        translated={}
        hits=0
        raw_hits=0
        for i in range(len(row["definition"]["proof"]["lines"])):
            part=fragment(row,row["definition"]["proof"]["lines"],i)
            prefix,word=part.prefix(),part.words()[:-1]
            original_text=dict(prefix=prefix,word=word)
            raw_hits+=fingerprint(prefix,records(word)) in exact_keys
            p,w,binding=normalize(prefix,word)
            key=fingerprint(p,records(w))
            hit=key in donor_keys
            hits+=hit
            if hit:
                cert_=canonical[key]
            else:
                digest,cert_,_=bank.get(p,records(w),True)
                assert digest==key
            if key not in verified:
                verified[key]=qualify_fragment(bank.verifier,key,cert_)
                assert verified[key] is not None
            bind(original_text,cert_,binding)
            synthetic=f"{i}"
            virtual[synthetic]=dict(**original_text,steps=cert_["steps"])
            translated[synthetic]=decoder.read(prefix,word+"!",require_empty=False)
            calls.append(dict(fragment=synthetic,reuse=hit))
        receipt,_=link(row,calls,virtual,translated)
        output[label]=dict(status="PROVED",width=n,shape=shape,clauses=len(normal["clauses"]),
            offers=found["counts"]["offers"],lines=len(calls),canonical_donor_hits=hits,
            exact_donor_hits=raw_hits,checked_link=receipt)
        print(label,output[label],flush=True)
    save("data/fresh-receivers-v1.json",dict(status="CHECKED_RENAMED_FRAGMENT_RECEIVERS",cases=output))


if __name__=="__main__":
    main()
