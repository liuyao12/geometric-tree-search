"""Reject invalid source bindings and exercises repeated typed guards."""
from copy import deepcopy
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definition_composition_v1 import signature
import herbrand_v1 as fol
from logical_projection_v1 import verify
from study_v1 import Certificate, grounded


def load(path):
    return json.loads((ROOT/path).read_text())


def main():
    experiment=load("data/equality-experiment-v1.json")
    sample=next(r for r in experiment["cases"] if r["id"]=="hilbert-incidence-transfer")
    source=sample["source"]
    compact=load("data/hilbert-incidence-transfer-logical-v1.json")
    receipt=verify(source,compact)
    functions,predicates,schemas,guards=signature(compact)
    _,_,original_rows=fol.signature(compact["compiled"])
    aliased=next(r for r in original_rows if r["id"].startswith("formula") and
                 len(r["variables"])>len(set(r["variables"].values())))
    constants={s:(min(n for n,(args,out) in functions.items() if not args and out==s),)
               for s in source["sorts"]}
    bindings={v:constants[s] for v,s in aliased["variables"].items()}
    duplicates=len(bindings)-len(set(bindings.values()))
    assert duplicates>0
    builder=Certificate(schemas,functions,predicates,source["sorts"],guards)
    result=builder.unguard(aliased["id"],bindings)
    assert set(builder.lines[result]["clause"])==set(grounded(aliased,bindings))
    altered=deepcopy(compact)
    altered["proof"]["lines"][-1]["left"]=len(altered["proof"]["lines"])
    deleted={**source,"premises":[p for i,p in enumerate(source["premises"]) if i!=1]}
    for original,bundle in ((source,altered),(deleted,compact)):
        try:
            verify(original,bundle)
        except (AssertionError,KeyError,ValueError):
            continue
        raise AssertionError("Invalid proof or source accepted")
    result=dict(status="CHECKED_EQUALITY_CERTIFICATE_AUDIT",receipt=receipt,
                repeated_typed_bindings=duplicates, alias_fixture=aliased["id"],
                altered_dependency="REJECTED", altered_source="REJECTED")
    (ROOT/"data/equality-audit-v1.json").write_text(json.dumps(result,sort_keys=True)+"\n")
    print(result,flush=True)


if __name__=="__main__":
    main()
