"""Admit lifted proposals through checked G and R fragments of the fixed palette."""
from collections import Counter
from hashlib import sha256
import json

import herbrand_v1 as fol
from lifted_prover_v1 import subst
from native_v1 import Admission

CAP=400_000_000


class Boundary:
    """Encode variables as fresh rigid names, with a reversible scope map."""
    def __init__(self):
        self.symbols={}

    def symbol(self,key):
        return self.symbols.setdefault(key,f"{len(self.symbols):b}")

    def term(self,t,variables,parameters):
        if isinstance(t,str):
            if t in variables:
                return "%"+variables[t]+","
            return "("+self.symbol(("parameter",t,parameters[t]))+".)"
        f,*args=t
        return "("+self.symbol(("function",f,len(args)))+"."+"".join(
            self.term(a,variables,parameters) for a in args)+")"

    def atom(self,a,variables,parameters):
        p,*args=a
        return "("+self.symbol(("predicate",p,len(args)))+"."+"".join(
            self.term(t,variables,parameters) for t in args)+")"

    def row(self,clause,variables,parameters):
        return "".join(("+" if p else "-")+self.atom(a,variables,parameters) for p,a in clause)


def scope(prover,node):
    out=Boundary()
    types=node["types"]|node["dead"]
    parents=[prover.nodes[i] for i in node["parents"]]
    prefixes,lines=[],[]
    for i,parent in enumerate(parents):
        v={name:f"{j:b}" for j,name in enumerate(sorted(parent["types"]))}
        template=out.row(parent["clause"],v,{})
        prefixes.append(f"C{i:b}:"+template+";")
    instances=[]
    for i,(parent,env) in enumerate(zip(parents,node["maps"],strict=True)):
        assert set(env)==set(parent["types"])
        assert all(fol.inspect_term(t,types,prover.functions)==parent["types"][name] for name,t in env.items())
        bindings="".join(f"={j:b}:"+out.term(env[v],{},types)
                         for j,v in enumerate(sorted(parent["types"])))
        instance=tuple((p,subst(a,env)) for p,a in parent["clause"])
        instances.append(instance)
        lines.append(f"G{i:b}:{i:b}:"+bindings+"/"+out.row(instance,{},types)+";")
    for _,(p,*args) in node["clause"]:
        assert tuple(fol.inspect_term(t,types,prover.functions) for t in args)==tuple(prover.predicates[p])
    if node["kind"]=="resolve":
        left,right=instances
        a,b=node["sites"]
        pivot=node["pivot"]
        assert left[a]==(True,pivot) and right[b]==(False,pivot)
        lines.append("R10:0:1:"+out.atom(pivot,{},types)+"/"+out.row(node["clause"],{},types)+";")
    else:
        assert node["kind"]=="factor"
        first,=instances
        a,b=node["sites"]
        assert a!=b and first[a]==first[b] and first[a][1]==node["pivot"]
        assert set(first)==set(node["clause"])
    return ">"+ "".join(prefixes)+"#",tuple(lines),list(out.symbols.items())


def fingerprint(prefix,lines):
    content=json.dumps([prefix,lines],separators=(",",":")).encode()
    return sha256(content).hexdigest()


class NativeBank:
    def __init__(self,cap=CAP):
        self.verifier=Admission(cap=cap)
        self.traces={}
        self.memo={}

    def execute(self,prefix,lines):
        tape=self.verifier.tape(prefix,"".join(lines))
        q,h=self.verifier.machine.start,0
        commits,trace,steps=0,[],0
        label,read="",""
        for _ in lines:
            stage=self.verifier.advance(tape,q,h,record=True)
            steps+=stage.steps
            trace.extend(stage.events)
            q,h,label,read=stage.q,stage.head,stage.label,stage.read
            if q!=self.verifier.finish:
                assert q==1
                break
            commits+=1
        result=dict(prefix=prefix,word="".join(lines),lines=len(lines),parents=[],fragment=trace,
                    commits=commits,stop=q,head=h,label=label,read=read,steps=steps)
        return result

    def get(self,prefix,lines,reuse,namespace=()):
        key=prefix,lines,namespace
        label=fingerprint(prefix,lines)
        if reuse and key in self.memo:
            evidence=self.traces[label]
            assert evidence["prefix"]==prefix and evidence["word"]=="".join(lines)
            return label,evidence,True
        evidence=self.execute(prefix,lines)
        if label not in self.traces:
            assert self.verifier.replay(evidence)==evidence["steps"]
            self.traces[label]=evidence
        else:
            assert self.traces[label]==evidence
        if reuse and evidence["commits"]==len(lines):
            self.memo[key]=label
        return label,evidence,False


class Receiver:
    def __init__(self,bank,mode):
        self.bank=bank
        self.mode=mode
        self.authorized=set()
        self.events=[]
        self.counts=Counter()

    def check(self,prover,index,node):
        parents=[prover.nodes[j] for j in node["parents"]]
        assert all(p["kind"]=="source" or i in self.authorized
                   for i,p in zip(node["parents"],parents,strict=True))
        assert index not in self.authorized
        prefix,lines,symbols=scope(prover,node)
        namespace=tuple(symbols) if self.mode=="exact" else ()
        label,trace,hit=self.bank.get(prefix,lines,self.mode!="off",namespace)
        if trace["commits"]!=len(lines):
            raise ValueError("Wang fragment rejected proposed lifted move")
        self.authorized.add(index)
        self.counts["admissions"]+=1
        self.counts[node["kind"]]+=1
        self.counts["reuse" if hit else "runs"]+=1
        if not hit:
            self.counts["implied_steps"]+=trace["steps"]
        self.events.append(dict(index=index,node=node,parents=parents,symbols=symbols,fragment=label,
                                reuse=hit))
