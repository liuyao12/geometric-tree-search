"""Replay the frozen policy with only its selected actions and audit its inputs."""
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from lifted_audit_v1 import countermodel
from lifted_experiment_v1 import load, save
from tactic_cohort_v1 import cohorts
from tactic_policy_v1 import context, learn, run, solve


def main():
    training=load("data/tactic-training-v1.json")
    policy,episodes,rewards=learn(training["training"])
    assert (policy,episodes,rewards)==tuple(training[k] for k in ("policy","episodes","reward_records"))
    develop,holdout=cohorts()
    assert {p["id"]:context(p) for p in develop}=={r["id"]:r["context"] for r in training["training"]}
    rows=load("data/tactic-receivers-v1.json")["results"]
    assert [r["original"] for r in rows]==holdout
    model=None
    checked=[]
    for row in rows:
        case,normal=(row[k] for k in ("original","compiled"))
        check(case,normal,row["certificate"])
        feature=context(case)
        chosen=policy.get(feature,"lift")
        assert (feature,chosen)==(row["context"],row["selected_schedule"])
        assert all(run(a,row["raw"])==out for a,out in row["compared"].items())
        result,proof=solve(case,normal,chosen)
        assert result==row["selected"]
        assert json.loads(json.dumps(proof))==row["proof"]
        checked.append(dict(id=row["id"],**result))
        if row["id"]=="quantifier-swap-control":
            assert result["status"]!="PROVED"
            model=countermodel(case)
    assert model is not None
    save("data/tactic-execution-v1.json",dict(status="REPLAYED_FROZEN_SELECTED_ACTIONS",checked=checked,
                 countermodel=model))
    print(len(checked),"selected schedules executed directly",flush=True)


if __name__=="__main__":
    main()
