"""Exercise the user-facing commands and attempt certificate tampering."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_experiment_v1 import ROOT, load, save
from study_v1 import write_gzip


def command(*args,expected=0):
    result=subprocess.run([sys.executable,"-I","-S","-B","source/shared_wang_v1.py",*args],
                          cwd=ROOT,capture_output=True,text=True,check=False)
    assert result.returncode==expected,result.stderr
    if expected==1:
        assert "Rejected input or certificate" in result.stderr
        return dict(status="REJECTED")
    return json.loads(result.stdout)


def main():
    fol="input/example-fol-v1.json"
    cm2="input/example-cm2-v1.json"
    negative="input/example-non-theorem-v1.json"
    results={}
    with TemporaryDirectory() as temporary:
        scratch=Path(temporary)
        fol_certificate,cm2_certificate,other=[str(scratch/n) for n in ("fol","cm2","other")]
        for kind,path,certificate,bound in (("fol",fol,fol_certificate,"5"),("cm2",cm2,cm2_certificate,"24")):
            proposed=command("prove",kind,path,certificate,"--limit",bound)
            verified=command("verify",path,certificate)
            assert verified["status"]==proposed["status"]=="CHECKED"
            results[kind]=dict(prove=proposed,verify=verified)
            write_gzip(ROOT/f"data/cli-{kind}-v1.json.gz",load(certificate))
        guided=command("prove","fol",fol,other,"--guided","--limit","5")
        assert guided["route"]=="guided"
        results["guided"]=guided
        Path(other).unlink()
        unresolved=command("prove","fol",negative,other,"--guided","--limit","2",expected=2)
        assert unresolved["status"]=="DEPTH_BOUND" and unresolved["route"]=="increasing-depth"
        assert unresolved["prepass"]["status"]!="PROVED" and not Path(other).exists()
        results["fallback_after_prepass"]=unresolved
        limited=command("prove","fol",fol,other,"--limit","4",expected=2)
        assert limited["status"]=="DEPTH_BOUND" and not Path(other).exists()
        results["depth_four"]=limited
        results["wrong_statement"]=command("verify",negative,fol_certificate,expected=1)
        original=load(cm2_certificate)
        changed_source=load(cm2)
        changed_source["program"][0][1]=1
        Path(other).write_text(json.dumps(changed_source))
        results["wrong_program"]=command("verify",other,cm2_certificate,expected=1)
        for label in ("wrong_palette","wrong_trace","wrong_parent"):
            altered=deepcopy(original)
            if label=="wrong_palette":
                altered["machine_sha256"]="0"*64
            elif label=="wrong_trace":
                first=altered["traces"][altered["calls"][0]["fragment"]]
                first["fragment"][0][0]+=1
            else:
                altered["proof"]["lines"][-1]["left"]=0
            Path(other).write_text(json.dumps(altered))
            results[label]=command("verify",cm2,other,expected=1)
    save("data/cli-audit-v1.json",dict(status="CHECKED_CLI",results=results))
    for k,v in results.items():
        print(k,v.get("status","CHECKED"),flush=True)


if __name__=="__main__":
    main()
