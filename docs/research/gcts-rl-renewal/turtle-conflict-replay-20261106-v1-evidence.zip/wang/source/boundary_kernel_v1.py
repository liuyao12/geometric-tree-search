"""One fixed tape program for first-order clausal refutations.

G records take a simultaneous ground instance of a fixed source clause.
R records resolve two earlier clauses, with optional weakening.
The last clause must be empty. The source front end owns clausification.
"""
from marker_tm_v1 import DATA, FREE, Program

ATOM = "01.()"
SIGNS = "+-"
END_LIT = "+-;"
RECORD_CHARS = set(FREE) - {";", "!", "~"}
MARKERS = ("home", "line", "p", "context", "a", "b", "source", "bind",
           "out", "left", "right", "pivot", "probe", "balance")


def build():
    m = Program(MARKERS)
    fresh = m.fresh

    def clone(label, source, target, dest):
        m.copy(label, source, target, dest)

    def take(label, p, dest):
        m.move(label, p, 1, dest)

    def ground(label, p, dest):
        open_term, grow, node, children, close, shrink, done = (fresh("term") for _ in range(7))
        clone(label, "home", "balance", open_term)
        m.expect(open_term, p, "(", grow)
        take(grow, "balance", node)
        m.number(node, p, ".", children)
        open_again = fresh("nested")
        m.read(children, p, {"(": open_again, ")": close})
        take(open_again, p, grow)
        take(close, p, shrink)
        m.move(shrink, "balance", -1, done)
        m.read(done, "balance", {">": dest}, children)

    def lookup(label, query, previous, dest):
        """Find the first exact ID, leaving b at its colon and context at its tag."""
        start, scan, loop, kind, clone_id, start_id, match, skip, following = (fresh("lookup") for _ in range(9))
        clone(label, "home", "context", start)
        if previous:
            take(start, "context", scan)
            at_boundary = fresh("proof-boundary")
            m.scan(scan, "context", set(DATA) - {"#"}, {"#": at_boundary})
            take(at_boundary, "context", loop)
            m.same(loop, "context", "line", "reject", kind)
            types = "GR"
        else:
            kind = loop
            take(start, "context", loop)
            types = "C"
        m.read(kind, "context", dict.fromkeys(types, clone_id))
        clone(clone_id, "context", "b", start_id)
        start_query = fresh("lookup-query")
        take(start_id, "b", start_query)
        clone(start_query, query, "a", match)
        m.compare(match, "a", "b", "01", ":", ":", dest, skip)
        skip_chars = RECORD_CHARS if previous else set(DATA) - {";", "#"}
        m.scan(skip, "context", skip_chars, {";": following})
        take(following, "context", loop)

    def literal_equal(label, a, b, yes, no):
        plus, minus, next_a, next_b, body = (fresh("literal-equal") for _ in range(5))
        m.read(label, a, {"+": plus, "-": minus}, no)
        m.read(plus, b, {"+": next_a}, no)
        m.read(minus, b, {"-": next_a}, no)
        take(next_a, a, next_b)
        take(next_b, b, body)
        m.compare(body, a, b, ATOM, END_LIT, END_LIT, yes, no)

    # Move to the first certificate record. The fixed prefix ends at #.
    m.scan("start", "line", set(DATA + ">") - {"#"}, {"#": "first"})
    take("first", "line", "record")
    clone("record", "line", "p", "dispatch")
    m.read("dispatch", "p", {"G": "g-tag", "R": "r-tag"})
    take("g-tag", "p", "g-id")
    take("r-tag", "p", "r-id")
    m.number("g-id", "p", ":", "g-find-source")
    m.number("r-id", "p", ":", "r-find-left")

    # Grounding. Validate every binding before substituting it.
    lookup("g-find-source", "p", False, "g-source")
    take("g-source", "b", "g-save-source")
    clone("g-save-source", "b", "source", "g-source-id")
    m.number("g-source-id", "p", ":", "g-save-bind")
    clone("g-save-bind", "p", "bind", "g-binding")
    m.read("g-binding", "p", {"=": "g-bind-tag", "/": "g-slash"})
    take("g-bind-tag", "p", "g-bind-name")
    m.number("g-bind-name", "p", ":", "g-bind-term")
    ground("g-bind-term", "p", "g-binding")
    take("g-slash", "p", "g-save-out")
    clone("g-save-out", "p", "out", "g-match")
    template = {"%": "g-variable", ";": "g-end"}
    for symbol in ATOM + SIGNS:
        label = fresh("ground-character")
        template[symbol] = label
        m.expect(label, "p", symbol, "g-advance-source")
    m.read("g-match", "source", template)
    take("g-advance-source", "source", "g-match")
    m.read("g-end", "p", {";": "finish"})
    take("g-variable", "source", "g-find-binding")
    clone("g-find-binding", "bind", "probe", "g-try-binding")
    m.expect("g-try-binding", "probe", "=", "g-copy-name")
    clone("g-copy-name", "probe", "b", "g-copy-var")
    clone("g-copy-var", "source", "a", "g-compare-name")
    m.compare("g-compare-name", "a", "b", "01", ",", ":", "g-found-var", "g-skip-binding")
    m.scan("g-skip-binding", "probe", ATOM + ":", {"=": "g-try-binding"})
    clone("g-found-var", "a", "source", "g-after-name")
    take("g-after-name", "b", "g-match-term")
    term_choices = {"=": "g-advance-source", "/": "g-advance-source"}
    for symbol in ATOM:
        label = fresh("term-character")
        term_choices[symbol] = label
        m.expect(label, "p", symbol, "g-advance-term")
    m.read("g-match-term", "b", term_choices)
    take("g-advance-term", "b", "g-match-term")

    # Resolution. Earlier proofs are read by their record identifiers.
    for side, following in (("left", "r-find-right"), ("right", "r-save-pivot")):
        lookup(f"r-find-{side}", "p", True, f"r-skip-{side}")
        m.scan(f"r-skip-{side}", "b", RECORD_CHARS - {"/"}, {"/": f"r-at-{side}"})
        take(f"r-at-{side}", "b", f"r-save-{side}")
        clone(f"r-save-{side}", "b", side, f"r-read-{side}")
        m.number(f"r-read-{side}", "p", ":", following)
    clone("r-save-pivot", "p", "pivot", "r-pivot")
    ground("r-pivot", "p", "r-slash")
    m.expect("r-slash", "p", "/", "r-save-out")
    clone("r-save-out", "p", "out", "r-literals")
    m.read("r-literals", "p", {"+": "r-sign", "-": "r-sign", ";": "left-pivot"})
    take("r-sign", "p", "r-atom")
    ground("r-atom", "p", "r-literals")

    def pivot_test(label, sign, yes, no):
        start, advance, pivot, match = (fresh("pivot") for _ in range(4))
        m.read(label, "p", {sign: start}, no)
        clone(start, "p", "a", advance)
        take(advance, "a", pivot)
        clone(pivot, "pivot", "b", match)
        m.compare(match, "a", "b", ATOM, END_LIT, "/", yes, no)

    for side, sign, following in (("left", "+", "right-pivot"), ("right", "-", "finish")):
        present, again, skip, restart, residual, check, out, scan, from_p, compare, try_next, advance = (
            f"{side}-{part}" for part in ("present", "again", "skip", "restart", "residual",
                                       "check", "out", "scan", "from-p", "compare", "try-next", "advance"))
        clone(f"{side}-pivot", side, "p", present)
        m.read(present, "p", dict.fromkeys(SIGNS, again))
        pivot_test(again, sign, restart, skip)
        def skip_literal(label, p, dest):
            begin = fresh("skip-literal")
            take(label, p, begin)
            m.scan(begin, p, ATOM, dict.fromkeys(END_LIT, dest))
        skip_literal(skip, "p", present)
        clone(restart, side, "p", residual)
        m.read(residual, "p", {"+": check, "-": check, ";": following})
        pivot_test(check, sign, advance, out)
        clone(out, "out", "probe", scan)
        m.read(scan, "probe", dict.fromkeys(SIGNS, from_p))
        clone(from_p, "p", "a", f"{compare}-probe")
        clone(f"{compare}-probe", "probe", "b", compare)
        literal_equal(compare, "a", "b", advance, try_next)
        skip_literal(try_next, "probe", scan)
        skip_literal(advance, "p", residual)

    # Only an empty final clause opens the accepting cap.
    clone("finish", "out", "line", "finish-shape")
    m.read("finish-shape", "line", {";": "empty-end", "+": "finish-scan", "-": "finish-scan"})
    m.scan("finish-scan", "line", ATOM + SIGNS, {";": "nonempty-end"})
    take("nonempty-end", "line", "record")
    take("empty-end", "line", "empty-next")
    m.read("empty-next", "line", {"!": "done-tag", "G": "record", "R": "record"})
    take("done-tag", "line", "padding")
    m.scan("padding", "line", "~", {"$": "accept"})
    return m
