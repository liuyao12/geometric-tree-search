"""Bounded ground unit search with source-checkable equality explanations."""
from collections import Counter, defaultdict, deque

from depth_ground_v1 import instances
import herbrand_v1 as fol
from study_v1 import Certificate, grounded as instance, guarded


class Equality:
    def __init__(self, terms, builder, stats):
        self.sorts = {t: s for s, values in terms.items() for t in values}
        self.parent = {t: t for t in self.sorts}
        self.graph = defaultdict(list)
        self.builder = builder
        self.stats = stats
        self.known = {}

    def root(self, term):
        root = term
        while root != self.parent[root]:
            root = self.parent[root]
        while term != root:
            following = self.parent[term]
            self.parent[term] = root
            term = following
        return root

    def atom(self, a, b):
        assert self.sorts[a] == self.sorts[b]
        return "=" + self.sorts[a], a, b

    def merge(self, a, b, line):
        u, v = self.root(a), self.root(b)
        if u == v:
            return False
        self.parent[max(u, v)] = min(u, v)
        self.graph[a].append((b, line, False))
        self.graph[b].append((a, line, True))
        self.known[a, b] = line
        self.stats["merges"] += 1
        return True

    def reverse(self, a, b, line):
        sort = self.sorts[a]
        rule = self.builder.unguard("symmetric-" + sort, {"?x": a, "?y": b})
        return self.builder.resolve(line, rule, self.atom(a, b))

    def explain(self, a, b):
        assert self.root(a) == self.root(b)
        if (a, b) in self.known:
            return self.known[a, b]
        self.stats["explanations"] += 1
        if a == b:
            line = self.builder.unguard("reflexive-" + self.sorts[a], {"?x": a})
        elif (b, a) in self.known:
            line = self.reverse(b, a, self.known[b, a])
        else:
            path = {a: None}
            queue = deque((a,))
            while b not in path:
                u = queue.popleft()
                for v, ref, reversed_ in self.graph[u]:
                    if v not in path:
                        path[v] = u, ref, reversed_
                        queue.append(v)
            steps = []
            tail = b
            while tail != a:
                head, ref, reversed_ = path[tail]
                if reversed_:
                    ref = self.reverse(tail, head, ref)
                steps.append((head, tail, ref))
                tail = head
            _, last, line = steps.pop()
            for u, v, ref in reversed(steps):
                assert u == last
                rule = self.builder.unguard("transitive-" + self.sorts[a], {"?x": a, "?y": u, "?z": v})
                rule = self.builder.resolve(line, rule, self.atom(a, u))
                line = self.builder.resolve(ref, rule, self.atom(u, v))
                last = v
        self.known[a, b] = line
        return line

    def apply(self, schema, a, b):
        assert a[0] == b[0]
        bindings = {f"?{side}{i}": t for side, atom in (("l", a), ("r", b))
                    for i, t in enumerate(atom[1:])}
        line = self.builder.unguard(schema + a[0], bindings)
        for u, v in dict.fromkeys(zip(a[1:], b[1:], strict=True)):
            line = self.builder.resolve(self.explain(u, v), line, self.atom(u, v))
        return line

    def close(self):
        while True:
            changed = False
            seen = {}
            for t in self.sorts:
                if len(t) == 1:
                    continue
                self.stats["function_probes"] += 1
                signature = (t[0], *(self.root(u) for u in t[1:]))
                u = seen.setdefault(signature, t)
                if self.root(u) != self.root(t):
                    line = self.apply("congruence-", u, t)
                    changed |= self.merge(u, t, line)
                    self.stats["function_merges"] += 1
            if not changed:
                return

    def key(self, atom):
        pred, *terms = atom
        roots = tuple(self.root(t) for t in terms)
        return (pred, *sorted(roots)) if pred.startswith("=") else (pred, *roots)

    def negative_equality(self, known, target, proof):
        _, u, v = known
        _, s, t = target
        sort = self.sorts[u]
        if self.root(u) != self.root(s):
            rule = self.builder.unguard("symmetric-" + sort, {"?x": v, "?y": u})
            proof = self.builder.resolve(rule, proof, self.atom(u, v))
            u, v = v, u
        assert self.root(u) == self.root(s) and self.root(v) == self.root(t)
        if u != s:
            rule = self.builder.unguard("transitive-" + sort, {"?x": u, "?y": s, "?z": v})
            rule = self.builder.resolve(self.explain(u, s), rule, self.atom(u, s))
            proof = self.builder.resolve(rule, proof, self.atom(u, v))
        if v != t:
            rule = self.builder.unguard("transitive-" + sort, {"?x": s, "?y": t, "?z": v})
            rule = self.builder.resolve(self.explain(t, v), rule, self.atom(t, v))
            proof = self.builder.resolve(rule, proof, self.atom(s, v))
        return proof

    def transport(self, sign, old, target, proof):
        if old == target:
            return proof
        self.stats["literal_transports"] += 1
        if target[0].startswith("="):
            assert not sign
            return self.negative_equality(old, target, proof)
        if sign:
            rule = self.apply("substitution-", old, target)
            return self.builder.resolve(proof, rule, old)
        rule = self.apply("substitution-", target, old)
        return self.builder.resolve(rule, proof, old)


def trim(lines, end):
    used, todo = set(), [end]
    while todo:
        n = todo.pop()
        if n in used:
            continue
        used.add(n)
        row = lines[n]
        if row["rule"] == "R":
            todo.extend((row["left"], row["right"]))
    ordered = sorted(used)
    indices = {n: i for i, n in enumerate(ordered)}
    return [row if row["rule"] == "G" else {**row, "left": indices[row["left"]], "right": indices[row["right"]]}
            for n in ordered for row in (lines[n],)]


def domain(original, normal, depth, limit):
    functions = {name: sig for name, sig in normal["functions"].items()
                 if name in original["functions"] or not sig[0]}
    return fol.ground_terms(normal, functions, depth, limit)


def prove(original, normal, depth, term_limit=64, clause_limit=3000, selected=None):
    assert normal["equality"] and normal["goal"] is None
    functions, predicates, schemas = fol.signature(normal)
    terms = domain(original, normal, depth, term_limit) if selected is None else selected
    if terms is None:
        return "TERM_BOUND", None, {}
    ordinary = [s for s in schemas if s["id"].startswith("formula")]
    by_name = {s["id"]: s for s in ordinary}
    universe = {t for values in terms.values() for t in values}
    _, grounded, stats = instances(ordinary, terms, depth, clause_limit, allowed_terms=universe)
    if grounded is None:
        return stats["status"], None, stats
    stats = Counter(stats)
    stats["terms"] = sum(map(len, terms.values()))
    source, types = guarded(schemas, functions, normal["sorts"])
    builder = Certificate(source, functions, predicates, normal["sorts"], types)
    equality = Equality(terms, builder, stats)
    clauses = tuple((tuple(sorted(set(instance(by_name[row["schema"]], row["substitution"])), key=repr)), row)
                    for row in grounded.values())
    units = {}

    def finish(end):
        assert not builder.lines[end]["clause"]
        lines = trim(builder.lines, end)
        stats["proof_records"] = len(lines)
        return "PROVED", dict(lines=lines), dict(stats)

    def evidence(literal, index):
        sign, atom = literal
        if sign and atom[0].startswith("=") and equality.root(atom[1]) == equality.root(atom[2]):
            return equality.explain(atom[1], atom[2])
        old, proof = index[sign, equality.key(atom)]
        return equality.transport(sign, old, atom, proof)

    while True:
        stats["rounds"] += 1
        index = {}
        for (sign, atom), ref in units.items():
            key = equality.key(atom)
            index.setdefault((sign, key), (atom, ref))
            if sign and not atom[0].startswith("=") and (False, key) in index:
                return finish(builder.resolve(ref, evidence((False, atom), index), atom))
            if not sign and (True, key) in index:
                return finish(builder.resolve(evidence((True, atom), index), ref, atom))
            if not sign and atom[0].startswith("=") and equality.root(atom[1]) == equality.root(atom[2]):
                return finish(builder.resolve(equality.explain(atom[1], atom[2]), ref, atom))

        def truth(literal):
            sign, atom = literal
            if atom[0].startswith("=") and equality.root(atom[1]) == equality.root(atom[2]):
                return sign
            key = equality.key(atom)
            if (sign, key) in index:
                return True
            if (not sign, key) in index:
                return False
            return None

        new = {}
        for clause, origin in clauses:
            stats["clause_visits"] += 1
            if stats["clause_visits"] > 1_000_000:
                return "WORK_BOUND", None, dict(stats)
            rest = []
            for literal in clause:
                value = truth(literal)
                if value is True:
                    break
                if value is None:
                    rest.append(literal)
                    if len(rest) > 1:
                        break
            else:
                if rest and rest[0] in new:
                    continue
                line = builder.unguard(origin["schema"], origin["substitution"])
                for sign, atom in clause:
                    if rest and (sign, atom) == rest[0]:
                        continue
                    ref = evidence((not sign, atom), index)
                    line = builder.resolve(line, ref, atom) if sign else builder.resolve(ref, line, atom)
                if not rest:
                    return finish(line)
                new[rest[0]] = line
        if not new:
            return "CLOSED_WITHOUT_REFUTATION", None, dict(stats)
        units.update(new)
        stats["units"] += len(new)
        changed = False
        for (sign, atom), ref in new.items():
            if sign and atom[0].startswith("="):
                changed |= equality.merge(atom[1], atom[2], ref)
        if changed:
            equality.close()
