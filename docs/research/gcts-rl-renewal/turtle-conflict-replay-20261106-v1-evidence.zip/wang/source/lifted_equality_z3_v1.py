"""Check the original quantified formulas with pinned Z3."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from equality_experiment_v1 import save
from z3_control_v1 import Language, z3

ROOT = Path(__file__).resolve().parents[1]
TIMEOUT_MS = 3_000


def main():
    assert z3.get_version() == (4, 15, 4, 0)
    experiment = json.loads((ROOT / "data/lifted-equality-experiment-v1.json").read_text())
    results = {}
    inputs = {}
    for name in ("development", "held_out"):
        for item in experiment[name]:
            source = item["source"]
            language = Language(source)
            solver = z3.Solver()
            solver.set(timeout=TIMEOUT_MS, random_seed=1)
            solver.add(*(language.formula(p) for p in source["premises"]))
            solver.add(z3.Not(language.formula(source["goal"])))
            inputs[item["id"]] = solver.sexpr()
            status = str(solver.check())
            expected = "sat" if item["expected"] == "COUNTERMODEL" else "unsat"
            assert status in (expected, "unknown"), item["id"]
            results[item["id"]] = dict(status=status, reason=solver.reason_unknown() if status == "unknown" else None)
    save("data/lifted-equality-z3-v1.json", dict(version=z3.get_full_version(), timeout_ms=TIMEOUT_MS, cases=results))
    save("data/lifted-equality-z3-inputs-v1.json", inputs)


if __name__ == "__main__":
    main()
