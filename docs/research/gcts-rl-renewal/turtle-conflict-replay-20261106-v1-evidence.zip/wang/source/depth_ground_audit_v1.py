"""Compare certified grounding exclusions with literal Cartesian enumeration."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import depth_ground_v1 as bounded
from definitions_v1 import compile_case
import herbrand_v1 as fol
from lifted_experiment_v1 import save
from tactic_cohort_v1 import cohorts


def main():
    controls=[]
    train,holdout=cohorts()
    for case in (*train,*holdout):
        compiled,_=compile_case(case)
        f,_,schemas=fol.signature(compiled)
        for level in (0,1,2):
            terms=fol.ground_terms(compiled,f,level,64)
            if terms is None:
                continue
            a,b,stats=bounded.instances(schemas,terms,level,3000)
            if stats["cartesian_candidates"]>30000:
                continue
            assert (a,b)==fol.instances(schemas,terms,level,3000)
            controls.append(dict(case=case["id"],depth=level,**stats))
    # The second occurrence is deeper. Pointing the certificate at the first
    # occurrence would discard the exact depth information for this variable.
    clause={"variables":{"?x":"U"},"clause":((True,("P","?x",("f","?x"))),)}
    mark=bounded.addresses(clause)
    bounded.verify(clause,mark)
    valid_mark=mark["variables"]["?x"]
    mark["variables"]["?x"]=(0,0)
    try:
        bounded.verify(clause,mark)
    except AssertionError:
        rejected=True
    else:
        raise AssertionError("A false depth bound passed the certificate check")
    assert len(controls)>=45
    save("data/depth-audit-v1.json",dict(status="CHECKED_DEPTH_EXCLUSION_MARKS",cases=controls,
                                       example=dict(schema=clause,deepest_variable_address=valid_mark,
                                                    forged_address=mark["variables"]["?x"]),
                                       forged_shallower_address_rejected=rejected))
    print(len(controls),"literal comparison arms verified",flush=True)


if __name__=="__main__":
    main()
