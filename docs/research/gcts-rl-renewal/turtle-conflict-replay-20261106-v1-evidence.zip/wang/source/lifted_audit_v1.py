"""Audit the found lifted DAGs, exact guards, finite countermodels, and Wang frames."""
from pathlib import Path
from collections import Counter
import gzip
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
import front_v1 as front
import herbrand_v1 as fol
from boundary_kernel_v1 import build
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import CAP, EXPECTED, restore
from sparse_frame_v1 import verify


def term(t,env):
    if isinstance(t,str):
        return env[t]
    return (t[0],*(term(x,env) for x in t[1:]))


def literals(row,env):
    return tuple((p,term(a,env)) for p,a in row)


def typed(env,expected,types,f):
    assert env.keys()==expected.keys()
    for v,t in env.items():
        assert fol.inspect_term(t,types,f)==expected[v]


def proof_audit(case,proof,*,normal=None):
    normal,skolems=front.clausify(case,1024) if normal is None else (normal,[])
    f,p,sources=fol.signature(normal)
    src={c["id"]:c for c in sources}
    assert json.loads(json.dumps(skolems))==proof["skolem"]
    seen=[]
    for i,node in enumerate(proof["lifted"]):
        kind=node["kind"]
        row=fol.frozen(node["clause"])
        types=node["types"]
        assert not (types.keys() & node["dead"].keys())
        for _,atom in row:
            assert tuple(fol.inspect_term(t,types,f) for t in atom[1:])==tuple(p[atom[0]])
        temp=types|node["dead"]
        maps=[{v:fol.frozen(t) for v,t in env.items()} for env in node["maps"]]
        if kind=="source":
            old=src[node["schema"]]
            mapping,=maps
            typed(mapping,old["variables"],temp,f)
            expected=literals(old["clause"],mapping)
            assert not node["parents"] and not node["sites"] and node["pivot"] is None
        else:
            assert all(0<=j<i for j in node["parents"])
            parents=[seen[j] for j in node["parents"]]
            for parent,mapping in zip(parents,maps,strict=True):
                typed(mapping,parent[1],temp,f)
            a,b=node["sites"]
            pivot=fol.frozen(node["pivot"])
            first=literals(parents[0][0],maps[0])
            if kind=="factor":
                assert len(parents)==1 and a!=b and first[a]==first[b] and first[a][1]==pivot
                expected=first[:b]+first[b+1:]
            else:
                assert kind=="resolve" and len(parents)==2
                second=literals(parents[1][0],maps[1])
                assert first[a]==(True,pivot) and second[b]==(False,pivot)
                expected=first[:a]+first[a+1:]+second[:b]+second[b+1:]
        assert set(row)==set(expected)
        seen.append((row,types))
    assert seen[-1][0]==()
    for event in proof["events"]:
        index=event["line"]
        node=proof["lifted"][event["node"]]
        mapping={v:fol.frozen(t) for v,t in event["instance"].items()}
        typed(mapping,node["types"],{},f)
        if index is not None:
            output=set(fol.frozen(proof["lines"][index]["clause"]))
            assert output<=set(literals(fol.frozen(node["clause"]),mapping))
    return Counter(r["kind"] for r in proof["lifted"])


def frame_audit(case,proof,receipt,machine):
    b=restore(case,proof["lines"])
    assert json.loads(json.dumps(list(b.sources.values())))==proof["source_clauses"]
    with gzip.open(ROOT/receipt["artifact"],"rt") as fh:
        data=json.load(fh)
    assert data["machine_sha256"]==EXPECTED
    assert b.prefix()==data["prefix"] and b.words()==data["word"]
    assert proof["maximum_proof_term_depth"]==max(
        (fol.depth(t) for line in b.lines for _,atom in line["clause"] for t in atom[1:]),default=0)
    rows=decoder.read(data["prefix"],data["word"])
    for raw,line in zip(rows,b.lines,strict=True):
        assert raw["rule"]==line["rule"]
        assert raw["clause"]==decoder.clause(b.literals(line["clause"],{}))
        if raw["rule"]=="R":
            assert (raw["left"],raw["right"])==(line["left"],line["right"])
            assert raw["pivot"]==decoder.single(b.token(line["pivot"],{}))
        else:
            var=b.variable_names(b.sources[line["source"]])
            assert raw["schema"]==bin(b.ids[line["source"]])[2:]
            assert raw["substitution"]=={var[v]:decoder.single(b.token(t,{})) for v,t in line["bindings"].items()}
    assert verify(machine,data["prefix"],data["word"],data["padding"],data["trace"],CAP)==receipt["receipt"]
    return len(rows)


def read_path(a,path):
    for i in path:
        if not isinstance(a,list) or not 0<=i<len(a)-1:
            return None
        a=a[i+1]
    return a


def obstruction(mark,a,b):
    if mark[0]=="rigid":
        _,p=mark
        assert p
        x,y=read_path(a,p),read_path(b,p)
    else:
        tag,side,p,q,trail=mark
        assert tag=="alias" and side in (0,1) and p!=q
        primary,other=(a,b) if side==0 else (b,a)
        v=read_path(primary,p)
        if not isinstance(v,str) or v!=read_path(primary,q):
            return False
        x,y=read_path(other,p+trail),read_path(other,q+trail)
    return isinstance(x,list) and isinstance(y,list) and (x[0],len(x))!=(y[0],len(y))


def mark_audit(study):
    donors={}
    for item in study["donors"]:
        mark=item["mark"]
        for r in item["sources"]:
            assert obstruction(mark,r["left"],r["right"])
        donors[json.dumps(mark)]=len(item["sources"])
    total=Counter()
    for case in study["cases"]:
        for mode in ("size","goal"):
            plain,marked=(case["arms"][m] for m in (mode,mode+"-marked"))
            assert plain["status"]==marked["status"]
            assert plain["lifted_lines"]==marked["lifted_lines"]
            counts,filtered=plain["counts"],marked["counts"]
            for k in ("offers","successful_factors","successful_resolutions","stored","given","shallow_skips"):
                assert counts.get(k,0)==filtered.get(k,0)
            assert counts.get("given",0)//4==counts.get("age_slots",0)==filtered.get("age_slots",0)
            difference=counts.get("unifications",0)-filtered.get("unifications",0)
            assert difference==filtered.get("marked_skips",0)==sum(n for _,_,_,n in marked["marks"])
            for mark,a,b,n in marked["marks"]:
                assert obstruction(mark,a,b) and json.dumps(mark) in donors
                total[mark[0]]+=n
    return total


def countermodel(case):
    label=case["id"]
    if label=="tptp-tutorial-family-mutation":
        domain=(0,1,2,3)
        constants=dict(iokaste=0,oedipus=1,polyneikes=2,thersandros=3)
        predicates=dict(parent_of=((0,1),(0,2),(1,2),(2,3)),patricide=((1,),))
        functions={}
    else:
        domain=(0,1)
        constants={}
        cycle=label=="occurs-check-control"
        predicates=dict(R=((0,1),(1,0)) if cycle else ((0,0),(1,1)))
        functions={"f":{(0,):1,(1,):0}} if cycle else {}

    def interpret(t,env):
        if isinstance(t,str):
            return env[t]
        name,*args=t
        return constants[name] if not args else functions[name][tuple(interpret(a,env) for a in args)]

    def truth(row,env):
        op,*parts=row
        if op=="atom":
            p,*args=parts
            values=tuple(interpret(a,env) for a in args)
            return values[0]==values[1] if p=="=U" else values in predicates[p]
        if op in ("all","exists"):
            v,sort,body=parts
            assert sort=="U"
            return (all if op=="all" else any)(truth(body,{**env,v:t}) for t in domain)
        if op=="not":
            return not truth(parts[0],env)
        left,right=map(lambda sub:truth(sub,env),parts)
        if op=="implies":
            return not left or right
        assert op=="and"
        return left and right

    assert all(truth(p,{}) for p in case["premises"]) and not truth(case["goal"],{})
    tables={name:[(args,value) for args,value in rows.items()] for name,rows in functions.items()}
    return dict(domain=domain,constants=constants,relations=predicates,functions=tables,premises=True,goal=False)


def main():
    machine=build().compile()
    study=load("data/search-v1.json")
    frames=load("data/frames-v1.json")
    cohort=load("input/cohort-v1.json")
    assert machine.digest()==frames["machine_sha256"]==EXPECTED
    index={r["id"]:r for r in frames["frames"]}
    models={}
    totals=Counter()
    checks=[]
    for case,row in zip(cohort["holdout"],study["cases"],strict=True):
        assert case["id"]==row["id"]
        proof=row.get("proof")
        if proof is None:
            assert case["id"] in cohort["negative"]
            models[case["id"]]=countermodel(case)
            continue
        assert case["id"] not in cohort["negative"]
        kinds=proof_audit(case,proof)
        tiles=frame_audit(case,proof,index[case["id"]],machine)
        print(case["id"],dict(kinds),tiles,flush=True)
        checks.append(dict(id=case["id"],lifted=kinds,ground=tiles))
        totals.update(kinds)
    assert len(checks)==len(index) and set(models)==set(cohort["negative"])
    marks=mark_audit(study)
    assert totals["factor"]>0 and all(marks[k]>0 for k in ("alias","rigid"))
    save("data/audit-v1.json",dict(status="CHECKED_LIFTED_PROOFS_AND_FIXED_WANG_FRAMES",cases=checks,
                                   lifted=totals,ground=sum(c["ground"] for c in checks),
                                   mark_uses=marks,countermodels=models))


if __name__=="__main__":
    main()
