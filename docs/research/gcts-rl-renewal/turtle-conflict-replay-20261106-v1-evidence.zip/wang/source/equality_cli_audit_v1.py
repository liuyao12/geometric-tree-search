"""Run an unseen statement through the public equality CLI and check the output."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from equality_cases_v1 import addition,examples


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def main():
    original=addition(6)
    bad=next(source for source,_,model in examples() if source["id"]=="hilbert-without-distinctness")
    save("input/peano-add-six-unseen-v1.json",original)
    save("input/hilbert-control-cli-v1.json",bad)
    python=[sys.executable,"-I","-S","-B"]
    with TemporaryDirectory() as temp:
        destination=Path(temp)/"verified.json"
        positive=subprocess.run([*python,"source/equality_prove_v1.py","input/peano-add-six-unseen-v1.json",
            str(destination),"--depth","7","--terms","rewrite"],cwd=ROOT,capture_output=True,text=True,check=True)
        proof=subprocess.run([*python,"source/logical_records_cli_v1.py","verify",
            "input/peano-add-six-unseen-v1.json",str(destination)],cwd=ROOT,capture_output=True,text=True,check=True)
        receipt=json.loads(proof.stdout)
        assert receipt["status"]=="CHECKED_LOGICAL_RECORDS"
        (ROOT/"data/peano-add-six-cli-v1.json").write_bytes(destination.read_bytes())
        excluded=Path(temp)/"no-proof.json"
        negative=subprocess.run([*python,"source/equality_prove_v1.py","input/hilbert-control-cli-v1.json",
            str(excluded),"--depth","0"],cwd=ROOT,capture_output=True,text=True)
        assert negative.returncode==2 and not excluded.exists()
        assert json.loads(negative.stdout)["status"]=="NO_REFUTATION_FOUND"
    result=dict(status="CHECKED_UNSEEN_EQUALITY_CLI",receipt=receipt,
                attempts=json.loads(positive.stdout)["attempts"],control="NO_REFUTATION_FOUND")
    save("data/equality-cli-audit-v1.json",result)
    print(receipt,flush=True)


if __name__=="__main__":
    main()
