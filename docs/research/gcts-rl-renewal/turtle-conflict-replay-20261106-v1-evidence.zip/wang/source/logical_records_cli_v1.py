"""Export and verify compact source-bound Wang proof records."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from logical_projection_v1 import projection, verify
from shared_wang_v1 import SCHEMA as FULL_SCHEMA


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="action",required=True)
    export=sub.add_parser("project")
    check=sub.add_parser("verify")
    for mode in (export,check):
        mode.add_argument("source",type=Path)
        mode.add_argument("certificate",type=Path)
    export.add_argument("output",type=Path)
    args=parser.parse_args()
    if not __debug__:
        parser.exit(1,"Proof checking requires Python assertions.\n")
    try:
        source=json.loads(args.source.read_bytes())
        bundle=json.loads(args.certificate.read_bytes())
        if args.action=="project":
            assert bundle["schema"]==FULL_SCHEMA
            bundle=projection(bundle)
        result=verify(source,bundle)
        if args.action=="project":
            with args.output.open("x") as target:
                json.dump(bundle,target,sort_keys=True,separators=(",",":"))
                target.write("\n")
    except (AssertionError,IndexError,KeyError,OSError,TypeError,ValueError) as error:
        parser.exit(1,f"Proof records rejected ({type(error).__name__}).\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
