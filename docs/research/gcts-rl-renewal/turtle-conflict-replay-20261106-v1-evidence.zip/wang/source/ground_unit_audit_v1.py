"""Check the ground-unit proofs through the frozen receptor bank."""
from collections import Counter
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
from definition_check_v1 import check
from definition_composition_v1 import fragment, link
from fragment_receptors_v1 import bind, normalize
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import NativeBank, fingerprint
from native_audit_v1 import qualify_fragment
from native_marked_v1 import records
from study_v1 import write_gzip


def main():
    mode=sys.argv[1:]
    assert mode in ([],["tactics"])
    tactics=bool(mode)
    prior=load("data/receptors-v1.json")
    names=prior["frozen_donor_cases"]
    donors={r["fragment"] for n in names for r in prior["cases"][n]["calls"]}
    exact={r["original"] for n in names for r in prior["cases"][n]["calls"]}
    with gzip.open(ROOT/"data/canonical-fragments-v1.json.gz","rt") as f:
        archive=json.load(f)
    checked={}
    fresh_traces={}
    output=[]
    inputs=load("data/tactic-receivers-v1.json" if tactics else "data/ground-unit-v1.json")["results"]
    for entry in inputs:
        spec=entry["original"]
        normal=entry["compiled"] if tactics else entry["normal"]
        check(spec,normal,entry["certificate"])
        proof=entry["proof"] if tactics else dict(lines=entry["lines"])
        if proof is None:
            continue
        lines=proof["lines"]
        row=dict(original=spec,compiled=normal,definition=dict(proof=proof))
        bank=NativeBank()
        counts=Counter()
        calls=[]
        virtual={}
        decoded={}
        maps=[]
        for i in range(len(lines)):
            builder=fragment(row,lines,i)
            prefix,word=builder.prefix(),builder.words()[:-1]
            text=dict(prefix=prefix,word=word)
            p,w,mapping=normalize(prefix,word)
            key=fingerprint(p,records(w))
            donor=key in donors
            counts["donor_hits"]+=donor
            counts["exact_donor_hits"]+=fingerprint(prefix,records(word)) in exact
            if donor:
                evidence=archive[key]
                hit=True
            else:
                actual,evidence,hit=bank.get(p,records(w),True)
                assert actual==key
                counts["local_reuse"]+=hit
                counts["fresh_transitions"]+=evidence["steps"] if not hit else 0
                assert fresh_traces.setdefault(key,evidence)==evidence
            if key not in checked:
                checked[key]=qualify_fragment(bank.verifier,key,evidence)
            assert checked[key] is not None
            bind(text,evidence,mapping)
            label=str(i)
            virtual[label]=dict(**text,steps=evidence["steps"])
            decoded[label]=decoder.read(prefix,word+"!",require_empty=False)
            calls.append(dict(fragment=label,reuse=hit))
            names={code:name for name,code in builder.symbols.items()}
            maps.append(dict(receptor=key,donor=donor,reuse=hit,
                             bindings=mapping,symbols={k:names[v] for k,v in mapping.items()}))
        receipt,_=link(row,calls,virtual,decoded)
        assert counts["donor_hits"]+counts["local_reuse"]+receipt["fresh_tile_runs"]==len(lines)
        output.append(dict(id=spec["id"],counts=dict(counts),receipt=receipt,bindings=maps))
        print(spec["id"],dict(counts),receipt,flush=True)
    label="tactic" if tactics else "ground-unit"
    save(f"data/{label}-audit-v1.json",dict(status="CHECKED_RECEPTOR_WANG_PROOFS",results=output))
    write_gzip(ROOT/f"data/{label}-new-fragments-v1.json.gz",fresh_traces)


if __name__=="__main__":
    main()
