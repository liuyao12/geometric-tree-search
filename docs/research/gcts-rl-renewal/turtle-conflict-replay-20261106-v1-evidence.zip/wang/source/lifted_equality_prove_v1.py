"""Search a first-order source with lifted equality and write checked Wang proof records."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_experiment_v1 import compact
from lifted_equality_ground_v1 import elaborate
from lifted_equality_v1 import EqualityProver
from lifted_ground_v1 import compile_proof
from logical_projection_v1 import verify
from shared_wang_v1 import attach, natural, verify_certificate


def solve(source, normal, translation, prover, full=False):
    status, root = prover.run()
    stats = {"status": status, "counts": dict(prover.counts)}
    if root is None:
        return stats, None, None
    dag = prover.proof(root)
    builder, trace, kinds = compile_proof(prover, dag, elaborate)
    proof = dict(lines=builder.lines)
    if full:
        bundle = attach(source, "fol", normal, translation, proof)
        receipt = verify_certificate(source, bundle)
    else:
        bundle = compact(source, normal, translation, proof)
        receipt = verify(source, bundle)
    stats.update(receipt=receipt, lifted_nodes=len(dag), elaborations=dict(kinds))
    return stats, bundle, dict(nodes=dag, grounding=trace)


def main():
    if not __debug__:
        raise RuntimeError("Proof checking requires Python assertions")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--policy", type=Path, help="load a frozen bias and rewrite marking policy")
    parser.add_argument("--bias", type=natural, help="override the scheduler bias")
    parser.add_argument("--offers", type=natural, default=12_000)
    parser.add_argument("--nodes", type=natural, default=3_000)
    parser.add_argument("--both-orientations", action="store_true")
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    source = json.loads(args.source.read_text())
    if source.get("equality") is not True:
        parser.error("the lifted equality tactic requires the source equality flag")
    normal, translation = compile_case(source)
    check(source, normal, translation)
    policy = json.loads(args.policy.read_text()) if args.policy else {}
    from herbrand_v1 import frozen
    bias = policy.get("bias", 0) if args.bias is None else args.bias
    prover = EqualityProver(source, normal=normal, goal_bias=bias, decreasing=not args.both_orientations,
                            rewrite_marks=frozen(policy.get("marks", [])),
                            offer_cap=args.offers, node_cap=args.nodes)
    stats, bundle, _ = solve(source, normal, translation, prover, args.full)
    if bundle is not None:
        with args.output.open("x") as handle:
            json.dump(bundle, handle, sort_keys=True, separators=(",", ":"))
            handle.write("\n")
    print(json.dumps(stats, sort_keys=True))
    return 0 if bundle is not None else 2


if __name__ == "__main__":
    raise SystemExit(main())
