"""Turn exact pocket areas into replayable residue refutations."""
import json
from itertools import combinations, pairwise
from math import gcd
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from definitions_v1 import compile_case
import fair_ground_v1 as fair
from shared_wang_v1 import attach, verify_certificate


def add(a,b):
    return tuple(x+y for x,y in zip(a,b,strict=True))


def determinant(a,b):
    return a[0]*b[1]-a[1]*b[0]


def terms(ring):
    return pairwise((*ring,ring[0]))


def multiply(a,b):
    raw=[0]*5
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            raw[(i+j)%5]+=x*y
    return tuple(raw[i]-raw[4] for i in range(4))


def conjugate(a):
    return (a[0]-a[1],-a[1],a[3]-a[1],a[2]-a[1])


def area(ring):
    out=(0,0)
    for a,b in terms(ring):
        _,u,v,w=multiply(conjugate(a),b)
        out=add(out,(v-w,u))
    return out


def sign(value):
    a,b=value
    u=2*a+b
    if not u or not b or (u>0)==(b>0):
        v=u or b
    else:
        v=(u*u-5*b*b)*(1 if u>0 else -1)
    return (v>0)-(v<0)


def measured(row):
    if row["kind"]=="turtle":
        value=sum(abs(sum(determinant(a,b) for a,b in terms(r))) for r in row["cycles"])
        tile=abs(sum(determinant(a,b) for a,b in terms(row["tile"])))
        divisor=gcd(value,tile)
        return (value//divisor,),((tile//divisor,),),value//tile
    unit=(1,0,0,0)
    zero=(0,0,0,0)
    shapes=[(zero,unit,add(unit,v),v) for v in ((0,0,0,-1),(0,1,0,0))]
    weights=tuple(area(p) for p in shapes)
    assert weights==((2,0),(0,2))
    coefficients=(0,0)
    for cycle in row["cycles"]:
        v=area(cycle)
        assert sign(v)>0
        coefficients=add(coefficients,v)
    count=0
    while sign((coefficients[0]-2*(count+1),coefficients[1]))>=0:
        count+=1
    return coefficients,weights,count


def combine(tag,items):
    values=list(items)
    result=values.pop()
    for x in reversed(values):
        result=[tag,x,result]
    return result


def problem(row):
    measured_area,weights,cap=measured(row)
    divisors=tuple(gcd(*(v[i] for v in weights)) for i in range(len(measured_area)))
    coord=next((i for i,d in enumerate(divisors) if measured_area[i]%d),0)
    modulus=divisors[coord]
    residue=measured_area[coord]%modulus
    choices=(0,*(w[coord] for w in weights))
    symbols={}
    def atom(name):
        symbols[name]=[]
        return ["atom",name]
    def exactly_one(values):
        yield combine("or",values)
        yield from (["not",["and",a,b]] for a,b in combinations(values,2))
    state=[[atom(f"r{i}_{j}") for j in range(modulus)] for i in range(cap+1)]
    action=[[atom(f"a{i}_{j}") for j in range(len(choices))] for i in range(cap)]
    premises=[state[0][0]]
    for values in (*state,*action):
        premises.extend(exactly_one(values))
    for i,values in enumerate(action):
        for j,previous in enumerate(state[i]):
            for k,option in enumerate(values):
                result=state[i+1][(j+choices[k])%modulus]
                premises.append(["implies",["and",previous,option],result])
    goal=["not",state[cap][residue]]
    source=dict(id=row["id"],sorts=["U"],functions={},predicates=symbols,equality=False,
                premises=premises,goal=goal)
    return source,dict(measured_area=measured_area,weights=weights,cap=cap,coordinate=coord,
                       modulus=modulus,required_residue=residue)


def evaluate(f,values):
    tag,*args=f
    if tag=="atom":
        return args[0] in values
    if tag=="not":
        return not evaluate(args[0],values)
    a,b=(evaluate(v,values) for v in args)
    return {"and":a and b,"or":a or b,"implies":not a or b}[tag]


def main():
    rows=json.loads((ROOT/"input/measured-pockets-v1.json").read_text())
    summary=[]
    for row in rows:
        original,relation=problem(row)
        (ROOT/"input"/(row["id"]+"-fol-v1.json")).write_text(json.dumps(original,sort_keys=True)+"\n")
        normal,translation=compile_case(original)
        outcome=fair.search(normal,0)
        if row["expected"]=="PROVED":
            assert outcome["status"]=="PROVED"
            certificate=attach(original,"fol",normal,translation,outcome["proof"])
            result=verify_certificate(original,certificate)
            name=row["id"]+"-wang-v1.json"
            (ROOT/"data"/name).write_text(json.dumps(certificate,sort_keys=True,separators=(",",":"))+"\n")
        else:
            assert outcome["status"]=="DEPTH_BOUND"
            n=relation["cap"]
            # Use four actual type counts admitted by the pooled exact area.
            m,k=(a//2 for a in relation["measured_area"])
            choice=(1,)*m+(2,)*k+(0,)*(n-m-k)
            assert len(choice)==n
            valuation={f"r{i}_0" for i in range(n+1)}|{f"a{i}_{a}" for i,a in enumerate(choice)}
            assert all(evaluate(f,valuation) for f in original["premises"])
            assert not evaluate(original["goal"],valuation)
            result=dict(status="COUNTERMODEL",true_atoms=sorted(valuation))
        summary.append(dict(id=row["id"],relation=relation,result=result))
        print(row["id"],relation,result,flush=True)
    (ROOT/"data/residue-summary-v1.json").write_text(json.dumps(summary,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
