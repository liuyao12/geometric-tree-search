"""Independently check tape windows, decoded scopes, cache reuse and end proofs."""
from collections import Counter
from pathlib import Path
import gzip
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
import front_v1 as front
import herbrand_v1 as fol
import tiles_v1 as til
from lifted_audit_v1 import countermodel, frame_audit, obstruction, proof_audit
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import CAP, fingerprint
from lifted_prover_v1 import subst
from native_experiment_v1 import typed_training
from native_marked_v1 import records, rejection_attempt
from native_v1 import Admission, PUBLISHED_MACHINE


def compressed(path):
    with gzip.open(ROOT/path,"rt") as reader:
        return json.load(reader)


def qualify_fragment(machine,key,trace):
    prefix,word=trace["prefix"],trace["word"]
    assert fingerprint(prefix,records(word))==key
    assert len(records(word))==trace["lines"]
    assert machine.replay(trace)==trace["steps"]
    chars,free=machine.machine.input(prefix,word)
    for i,c in enumerate(chars):
        q=machine.machine.start if i==0 else None
        mark=("input","head",c) if i==0 else ("input","free") if i in free else ("input","fixed",c)
        tile=machine.palette.top(mark,til.cell(c,q))
        assert machine.palette.allows(tile)
    if trace["stop"]==machine.finish:
        assert trace["commits"]==trace["lines"]
        return decoder.read(prefix,word+"!",require_empty=False)
    assert trace["stop"]==1 and trace["commits"]<trace["lines"]
    return None


def normalized(spec):
    normal,_=front.clausify(spec,1024)
    f,p,rows=fol.signature(normal)
    return f,p,{r["id"]:r for r in rows}


def decode_case(event,signature,trace,parsed):
    functions,predicates,sources=signature
    node=event["node"]
    vars_=node["types"]|node["dead"]
    assert not node["types"].keys() & node["dead"].keys()
    fwd=dict((tuple(k),v) for k,v in event["symbols"])
    inv={v:k for k,v in fwd.items()}
    assert len(fwd)==len(inv)==len(event["symbols"])

    def term(raw,env):
        if isinstance(raw,str):
            return env[raw]
        code,*args=raw
        role,name,arity=inv[code]
        if role=="parameter":
            assert not args and vars_[name]==arity
            return name
        assert role=="function" and len(args)==arity
        assert len(functions[name][0])==arity
        return (name,*(term(t,env) for t in args))

    def atom(raw,env):
        code,*args=raw
        role,name,arity=inv[code]
        assert role=="predicate" and len(args)==arity==len(predicates[name])
        return (name,*(term(t,env) for t in args))

    def row(raw,env):
        return tuple((p,atom(a,env)) for p,a in raw)

    for _,(p,*ts) in fol.frozen(node["clause"]):
        assert tuple(fol.inspect_term(t,node["types"],functions) for t in ts)==tuple(predicates[p])
    parents=event["parents"]
    templates=records(trace["prefix"][1:-1])
    assert len(templates)==len(parents)
    assert len(parsed)==len(parents)+(node["kind"]=="resolve")
    for i,(parent,template,line,mapping) in enumerate(zip(parents,templates,parsed[:len(parents)],node["maps"],strict=True)):
        schema,text=template.split(":",1)
        assert schema==f"C{i:b}"
        v={f"{j:b}":name for j,name in enumerate(sorted(parent["types"]))}
        assert row(decoder.clause(text[:-1],template=True),v)==fol.frozen(parent["clause"])
        assert line["rule"]=="G" and line["schema"]==f"{i:b}"
        mapped={v[k]:term(t,{}) for k,t in line["substitution"].items()}
        assert mapped=={k:fol.frozen(t) for k,t in mapping.items()}
        assert set(mapped)==set(parent["types"])
        assert all(fol.inspect_term(t,vars_,functions)==parent["types"][k] for k,t in mapped.items())
        if parent["kind"]=="source":
            source=sources[parent["schema"]]
            source_map={k:fol.frozen(t) for k,t in parent["maps"][0].items()}
            assert source_map.keys()==source["variables"].keys()
            assert all(fol.inspect_term(t,parent["types"],functions)==source["variables"][k]
                       for k,t in source_map.items())
            assert {(p,subst(a,source_map)) for p,a in source["clause"]}==set(fol.frozen(parent["clause"]))
    if node["kind"]=="factor":
        a,b=node["sites"]
        literal=row(parsed[0]["clause"],{})
        assert a!=b and literal[a]==literal[b]
        assert set(literal)==set(fol.frozen(node["clause"]))
    else:
        assert node["kind"]=="resolve"
        final=parsed[-1]
        assert final["rule"]=="R" and final["left"]==0 and final["right"]==1
        pivot=atom(final["pivot"],{})
        assert pivot==fol.frozen(node["pivot"])
        a,b=node["sites"]
        assert row(parsed[0]["clause"],{})[a]==(True,pivot)
        assert row(parsed[1]["clause"],{})[b]==(False,pivot)
        assert row(final["clause"],{})==fol.frozen(node["clause"])


def check_arm(run,signature,trace,decoded,seen,mode,cache):
    authorized={}
    nodes={}
    counts=Counter()
    for event in run["events"]:
        node=event["node"]
        assert event["index"] not in authorized
        for num,parent in zip(node["parents"],event["parents"],strict=True):
            assert 0<=num<event["index"]
            if parent["kind"]!="source":
                assert authorized[num]==parent
            assert nodes.setdefault(num,parent)==parent
        key=event["fragment"]
        namespace=fol.frozen(event["symbols"]) if mode=="exact" else ()
        entry=key,namespace
        assert event["reuse"]==(mode!="off" and entry in cache)
        counts["reuse" if event["reuse"] else "runs"]+=1
        counts["admissions"]+=1
        counts[node["kind"]]+=1
        if not event["reuse"]:
            counts["implied_steps"]+=trace[key]["steps"]
        assert decoded[key] is not None
        decode_case(event,signature,trace[key],decoded[key])
        authorized[event["index"]]=node
        assert event["index"] not in nodes
        nodes[event["index"]]=node
        if mode!="off":
            cache.add(entry)
        seen.add(key)
    assert counts==Counter(run["tape"])
    if run["status"]=="PROVED":
        root,=(i for i,n in authorized.items() if not n["clause"])
        output=[]
        mapped={}
        def visit(i):
            if i not in mapped:
                node=nodes[i]
                parents=[visit(p) for p in node["parents"]]
                mapped[i]=len(output)
                output.append({**node,"parents":parents})
            return mapped[i]
        assert visit(root)==len(output)-1
        return output
    return None


def main():
    machine=Admission(cap=CAP)
    c=load("input/cohort-v1.json")
    study=load("data/search-v1.json")
    frames=load("data/frames-v1.json")
    index={r["id"]:r for r in frames["frames"]}
    assert study["machine_sha256"]==frames["machine_sha256"]==PUBLISHED_MACHINE
    all_cases={s["id"]:s for s in (*c["donors"],*c["training"],*c["holdout"],
                                  *(typed_training(i) for i in range(6)))}
    signatures={name:normalized(s) for name,s in all_cases.items()}
    fragments=compressed("data/native-fragments-v1.json.gz")
    decoded={}
    for i,(key,trace) in enumerate(fragments.items(),1):
        decoded[key]=qualify_fragment(machine,key,trace)
        if i%100==0:
            print("verified local fragments",i,flush=True)
    seen=set()
    seed=set()
    for row in study["donors"]:
        check_arm(row,signatures[row["id"]],fragments,decoded,seen,"shape",seed)
    assert len(seed)==study["seeded_shapes"]
    for row in study["episodes"]:
        check_arm(row,signatures[row["id"]],fragments,decoded,seen,"shape",set())
    controls=study["controls"]
    assert all(decoded[k] is None for k in controls.values())
    seen.update(controls.values())
    checked=[]
    counters={}
    total_tape=Counter()
    for row in study["cases"]:
        name=row["id"]
        spec=all_cases[name]
        direct=row["arms"]["direct"]
        for arm,run in row["arms"].items():
            if arm=="direct":
                assert not run["events"] and not run["tape"]
                continue
            if arm!="ranked" or run["order"]==direct["order"]:
                assert (run["status"],run["counts"])==(direct["status"],direct["counts"])
            mode=arm if arm in ("shape","exact") else "shape" if arm in ("warm","ranked") else "off"
            cache=seed.copy() if arm in ("warm","ranked") else set()
            checked_proof=check_arm(run,signatures[name],fragments,decoded,seen,mode,cache)
            if arm=="warm" and checked_proof is not None:
                assert checked_proof==row["proof"]["lifted"]
            total_tape.update(run["tape"])
        proof=row.get("proof")
        if proof:
            receipt=index[name]
            proof={**proof,"maximum_proof_term_depth":receipt["maximum_proof_term_depth"]}
            kinds=proof_audit(spec,proof)
            lines=frame_audit(spec,proof,receipt,machine.machine)
            checked.append(dict(id=name,lifted=dict(kinds),lines=lines))
        else:
            counters[name]=countermodel(spec)
    assert seen==fragments.keys() and len(checked)==len(index)
    negative=compressed("data/negative-fragments-v1.json.gz")
    combined=load("data/combined-v1.json")
    taught=[]
    for d in combined["donors"]:
        f=negative[d["fragment"]]
        prefix,lines=rejection_attempt(fol.frozen(d["left"]),fol.frozen(d["right"]))
        assert (prefix,"".join(lines))==(f["prefix"],f["word"])
        assert qualify_fragment(machine,d["fragment"],f) is None and f["commits"]==2
        assert obstruction(d["mark"],d["left"],d["right"])
        taught.append(d["mark"])
    marks=0
    for row in combined["cases"]:
        for m,a,b,n in row["marks"]:
            assert m in taught and obstruction(m,a,b)
            marks+=n
    assert marks
    save("data/audit-v1.json",dict(status="AUDITED_NATIVE_LIFTED_SEARCH",cases=checked,
        ground=sum(c["lines"] for c in checked),local_fragments=len(fragments),
        native_uses=total_tape,donor_mark_fragments=len(negative),combined_mark_uses=marks,
        controls={k:"REJECTED" for k in controls},countermodels=counters))


if __name__=="__main__":
    main()
