"""Increasing-depth proof search with complete finite ground elimination."""
from itertools import count
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_cases_v1 import a,all_,case
from definition_check_v1 import check
from definitions_v1 import compile_case
import herbrand_v1 as fol
from lifted_experiment_v1 import save
import resolution_v1 as prop
from study_v1 import Certificate,guarded
from tactic_cohort_v1 import parity,terms


def search(normal,maximum_depth=None):
    functions,predicates,schemas=fol.signature(normal)
    raw_schemas,guards=guarded(schemas,functions,normal["sorts"])
    builder=Certificate(raw_schemas,functions,predicates,normal["sorts"],guards)
    limits=dict(clauses=float("inf"),seconds=float("inf"))
    attempts=[]
    for depth in count():
        if maximum_depth is not None and depth>maximum_depth:
            return dict(status="DEPTH_BOUND",attempts=attempts,proof=None)
        terms_=fol.ground_terms(normal,functions,depth,float("inf"))
        atoms,instances=fol.instances(schemas,terms_,depth,float("inf"))
        raw=[prop.literals(pair) for pair in instances]
        engine=prop.Search(raw,limits,"PLAIN")
        result=engine.eliminate(len(atoms))
        assert result in ("SAT","UNSAT")
        attempts.append(dict(depth=depth,ground_instances=len(instances),atoms=len(atoms),
                             status=result,counts=dict(engine.counts)))
        if result!="UNSAT":
            continue
        if [] in raw:
            origin=list(instances.values())[raw.index([])]
            builder.unguard(origin["schema"],origin["substitution"])
        else:
            resolution=engine.proof()
            prop.verify_resolution(raw,resolution)
            used,names,premises,lines=fol.reduce_proof(raw,resolution)
            inv={v:k for k,v in atoms.items()}
            named=[inv[i] for i in names]
            origins=[list(instances.values())[i] for i in used]
            fol.verify_instances(schemas,origins,premises,named,functions)
            prop.verify_resolution(premises,lines)
            ids=[builder.unguard(o["schema"],o["substitution"]) for o in origins]
            for row in lines:
                ids.append(builder.resolve(ids[row["left"]],ids[row["right"]],named[row["pivot"]-1]))
        assert not builder.lines[-1]["clause"]
        return dict(status="PROVED",attempts=attempts,proof=dict(lines=builder.lines))


def main():
    non_theorem=case("independent-predicates",{},{"P":1,"Q":1},[all_("?x",a("P","?x"))],
                     all_("?x",a("Q","?x")))
    examples=[(parity("three-equivalences",3),0),(terms("three-applications",3),3),
              (terms("five-applications",5),5),(non_theorem,2)]
    result=[]
    for original,depth in examples:
        normal,cert=compile_case(original)
        check(original,normal,cert)
        row=search(normal,depth)
        result.append(dict(original=original,normal=normal,certificate=cert,**row))
        print(original["id"],row["status"],[(a["depth"],a["ground_instances"],a["status"]) for a in row["attempts"]],
              len(row["proof"]["lines"]) if row["proof"] else None,flush=True)
    assert [r["status"] for r in result]==["PROVED","PROVED","PROVED","DEPTH_BOUND"]
    save("data/fair-ground-v1.json",dict(status="CHECKED_INCREASING_GROUND_SEARCH",results=result))


if __name__=="__main__":
    main()
