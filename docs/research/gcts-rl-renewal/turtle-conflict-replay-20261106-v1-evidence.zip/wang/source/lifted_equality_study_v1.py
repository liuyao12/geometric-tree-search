"""Train a scheduler and audit reusable rewrite marks on fixed source cohorts."""
from collections import Counter
from pathlib import Path
from random import Random
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from equality_closure_v1 import prove as ground
from equality_experiment_v1 import compact, save
from lifted_equality_cases_v1 import cohort
from lifted_equality_prove_v1 import solve
from lifted_equality_v1 import EqualityProver
from lifted_prover_v1 import Prover
from logical_projection_v1 import reject
from shared_wang_v1 import attach, verify_certificate
from term_demand_v1 import domain as demanded

OFFERS = 12_000
NODES = 3_000
BIASES = (0, 6, 12, 24)


def prepared(source):
    normal, translation = compile_case(source)
    check(source, normal, translation)
    return normal, translation


def make_prover(source, normal, bias=0, marks=(), learn=False):
    return EqualityProver(source, normal=normal, goal_bias=bias, rewrite_marks=marks,
                          learn_rewrites=learn, offer_cap=OFFERS, node_cap=NODES)


def independently_impossible(mark, left, right):
    def subterm(term, path):
        for position in path:
            assert isinstance(term, tuple) and 0 <= position < len(term) - 1
            term = term[1 + position]
        return term

    if mark[0] == "rigid":
        _, path = mark
        a, b = subterm(left, path), subterm(right, path)
    else:
        tag, side, p, q, tail = mark
        assert tag == "alias" and side in (0, 1) and p != q
        pattern, other = (left, right) if side == 0 else (right, left)
        variable = subterm(pattern, p)
        assert isinstance(variable, str) and subterm(pattern, q) == variable
        a, b = subterm(other, p + tail), subterm(other, q + tail)
    assert isinstance(a, tuple) and isinstance(b, tuple) and (a[0] != b[0] or len(a) != len(b))


def markings(donors):
    learned = {}
    for source in donors:
        normal, _ = prepared(source)
        prover = make_prover(source, normal, learn=True)
        status, _ = prover.run()
        assert status == "PROVED"
        for mark, (a, b) in prover.rewrite_failures.items():
            independently_impossible(mark, a, b)
            learned.setdefault(mark, dict(source=source["id"], left=a, right=b))
    assert {mark[0] for mark in learned} == {"rigid", "alias"}
    return tuple(sorted(learned, key=repr)), [dict(mark=m, **learned[m]) for m in sorted(learned, key=repr)]


def train(sources, marks):
    """Single-decision epsilon-greedy policy with only chosen-action feedback."""
    rng = Random(53019)
    observations = []
    estimates = {b: 0.0 for b in BIASES}
    counts = Counter()
    cache = {}
    prepared_sources = [(s, prepared(s)[0]) for s in sources]
    for epoch in range(10):
        order = list(prepared_sources)
        rng.shuffle(order)
        for source, normal in order:
            exploratory = len(counts) < len(BIASES) or rng.random() < 0.22
            if len(counts) < len(BIASES):
                action = next(b for b in BIASES if b not in counts)
            elif exploratory:
                action = rng.choice(BIASES)
            else:
                action = max(BIASES, key=lambda b: (estimates[b], -b))
            key = source["id"], action
            if key not in cache:
                prover = make_prover(source, normal, action, marks)
                status, _ = prover.run()
                cache[key] = status, prover.counts["offers"]
            status, offers = cache[key]
            reward = 1 - offers / OFFERS if status == "PROVED" else -1
            counts[action] += 1
            estimates[action] += (reward - estimates[action]) / counts[action]
            observations.append(dict(epoch=epoch, source=source["id"], action=action,
                                     exploration=exploratory, status=status, offers=offers))
    selected = max(BIASES, key=lambda b: (estimates[b], -b))
    return dict(bias=selected, marks=marks, counts=dict(counts), means=estimates, observations=observations)


def model_record(model):
    return dict(domains=model["domains"], functions={f: sorted(v.items()) for f, v in model["functions"].items()},
                predicates={p: sorted(v) for p, v in model["predicates"].items()})


def baseline(source, normal, translation, depth):
    selected, _ = demanded(source, normal, depth) if "plus" in source["functions"] else (None, None)
    status, proof, counts = ground(source, normal, depth, selected=selected)
    receipt = None
    if proof is not None:
        from logical_projection_v1 import verify
        receipt = verify(source, compact(source, normal, translation, proof))
    return dict(status=status, counts=counts, receipt=receipt)


def run_case(source, model, depth, marks, bias):
    normal, translation = prepared(source)
    expected = "COUNTERMODEL" if model is not None else "PROVED"
    item = dict(id=source["id"], source=source, expected=expected, ground=baseline(source, normal, translation, depth))
    assert item["ground"]["receipt"] is None or model is None
    naive = Prover(source, normal=normal, offer_cap=OFFERS, node_cap=NODES)
    item["eager_axioms"], _, _ = solve(source, normal, translation, naive)
    no_bias = make_prover(source, normal)
    item["plain_rewrite"], _, _ = solve(source, normal, translation, no_bias)
    fixed = {}
    artifacts = {}
    for action in BIASES:
        prover = make_prover(source, normal, action, marks)
        fixed[str(action)], bundle, trace = solve(source, normal, translation, prover)
        artifacts[action] = prover, bundle, trace
    marked, bundle, trace = artifacts[bias]
    matched = make_prover(source, normal, bias)
    item["same_bias_without_marks"], bare, _ = solve(source, normal, translation, matched)
    assert marked.nodes == matched.nodes
    assert item["same_bias_without_marks"]["status"] == fixed[str(bias)]["status"]
    assert bundle == bare
    skips = []
    for (mark, a, b), uses in marked.rewrite_skips.items():
        independently_impossible(mark, a, b)
        skips.append(dict(mark=mark, left=a, right=b, uses=uses))
    assert sum(row["uses"] for row in skips) == marked.counts["rewrite_mark_skips"]
    item.update(fixed_biases=fixed, learned=fixed[str(bias)], certified_skips=skips)
    if model is not None:
        assert not any(b for _, b, _ in artifacts.values())
        assert all(item[name]["status"] != "PROVED"
                   for name in ("eager_axioms", "plain_rewrite", "same_bias_without_marks"))
        premises, goal = holds(source, model)
        assert all(premises) and not goal
        item["countermodel"] = model_record(model)
    if bundle is not None:
        name = source["id"]
        save(f"data/{name}-logical-v1.json", bundle)
        save(f"data/{name}-lifted-v1.json", trace)
        reject({**source, "goal": ["not", source["goal"]]}, bundle)
        if name in {"alternatives-2-depth-3", "incidence-choice"}:
            full = attach(source, "fol", normal, translation, bundle["proof"])
            item["full_wang"] = verify_certificate(source, full)
            save(f"data/{name}-wang-v1.json", full)
    return item


def main():
    donors, training, development, held_out = cohort()
    assert {s["id"] for s in training}.isdisjoint(s["id"] for s, _, _ in development + held_out)
    assert {s["id"] for s, _, _ in development}.isdisjoint(s["id"] for s, _, _ in held_out)
    marks, witnesses = markings(donors)
    policy = train(training, marks)
    save("data/lifted-equality-policy-v1.json", {**policy, "witnesses": witnesses})
    print("Policy", policy["bias"], policy["counts"], policy["means"], flush=True)
    groups = {}
    for name, cases in (("development", development), ("held_out", held_out)):
        rows = []
        for source, model, depth in cases:
            item = run_case(source, model, depth, marks, policy["bias"])
            rows.append(item)
            arms = (item["ground"], item["eager_axioms"], item["plain_rewrite"], item["learned"])
            print(name, item["id"], [a["status"] for a in arms], item["learned"]["counts"].get("offers"),
                  item["learned"]["counts"].get("rewrite_mark_skips", 0), flush=True)
        groups[name] = rows
    save("data/lifted-equality-experiment-v1.json",
         dict(status="CHECKED_LIFTED_EQUALITY", offer_cap=OFFERS, node_cap=NODES, **groups))


if __name__ == "__main__":
    main()
