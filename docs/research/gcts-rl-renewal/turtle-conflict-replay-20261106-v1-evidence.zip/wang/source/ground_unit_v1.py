"""Proof-producing bounded grounding with a unit-resolution agenda."""
from collections import defaultdict, deque
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from depth_ground_v1 import instances as restricted_instances
from definitions_v1 import compile_case
import herbrand_v1 as fol
from lifted_experiment_v1 import save
import resolution_v1 as prop
from study_v1 import Certificate, guarded


def prove(normal,depth=0,limit=3000):
    f,p,s=fol.signature(normal)
    terms=fol.ground_terms(normal,f,depth,64)
    if terms is None:
        return None,dict(status="TERM_BOUND")
    atom_ids,instances,ground=restricted_instances(s,terms,depth,limit)
    term_count=sum(map(len,terms.values()))
    if instances is None:
        return None,dict(**ground,terms=term_count)
    atoms={v:k for k,v in atom_ids.items()}
    origins=list(instances.values())
    clauses=[frozenset(prop.literals(pair)) for pair in instances]
    initial=len(clauses)
    recorded=[]
    pending=deque((next(iter(c)),j) for j,c in enumerate(clauses) if len(c)==1)
    watchers=defaultdict(list)
    active=list(range(initial))
    for i,c in enumerate(clauses):
        for literal in sorted(c):
            watchers[literal].append(i)
    seen=set()
    final=next((i for i,c in enumerate(clauses) if not c),None)
    examinations=0
    watcher_visits=0
    while pending and final is None:
        literal,proof=pending.popleft()
        if literal in seen:
            continue
        seen.add(literal)
        for slot in watchers[-literal]:
            watcher_visits+=1
            old=active[slot]
            if -literal not in clauses[old]:
                continue
            examinations+=1
            reduced=clauses[old]-{-literal}
            idx=len(clauses)
            clauses.append(reduced)
            left,right=(proof,old) if literal>0 else (old,proof)
            recorded.append((left,right,abs(literal)))
            active[slot]=idx
            if not reduced:
                final=idx
                break
            if len(reduced)==1:
                pending.append((next(iter(reduced)),idx))
    stats=dict(**ground,status="PROVED" if final is not None else "UNIT_CLOSED",terms=term_count,
               ground_instances=initial,unit_resolutions=examinations,watcher_visits=watcher_visits)
    if final is None:
        return None,stats
    sources,guards=guarded(s,f,normal["sorts"])
    builder=Certificate(sources,f,p,normal["sorts"],guards)
    indices={}
    def elaborate(i):
        if i in indices:
            return indices[i]
        if i<initial:
            o=origins[i]
            j=builder.unguard(o["schema"],o["substitution"])
        else:
            l,r,k=recorded[i-initial]
            j=builder.resolve(elaborate(l),elaborate(r),atoms[k])
        expected={(a>0,atoms[abs(a)]) for a in clauses[i]}
        assert set(builder.lines[j]["clause"])==expected
        indices[i]=j
        return j
    end=elaborate(final)
    assert end==len(builder.lines)-1 and not builder.lines[end]["clause"]
    return builder,dict(**stats,proof_lines=len(builder.lines))


def main():
    from receptor_receivers_v1 import receiver
    results=[]
    for k in (11,17,23):
        original=receiver(f"balanced_unit_{k}",k,"balanced")
        normal,cert=compile_case(original)
        check(original,normal,cert)
        proof,stats=prove(normal)
        assert proof is not None
        results.append(dict(original=original,normal=normal,certificate=cert,stats=stats,lines=proof.lines))
        print(k,stats,flush=True)
    save("data/ground-unit-v1.json",dict(status="CHECKED_GROUND_UNIT_PROPOSALS",results=results))


if __name__=="__main__":
    main()
