"""Independent Z3 controls for the original formulas and bounded ground clauses."""
from pathlib import Path
import json
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
if len(sys.argv)==2:
    sys.path.insert(0,sys.argv[1])
import z3
from definitions_v1 import compile_case
from depth_ground_v1 import instances
from equality_closure_v1 import domain
import herbrand_v1 as fol
import resolution_v1 as prop

TIMEOUT=3000


class Language:
    def __init__(self, source):
        self.sorts={s:z3.DeclareSort(s) for s in source["sorts"]}
        self.functions={n:z3.Function(n,*(self.sorts[s] for s in (*args,out)))
                        for n,(args,out) in source["functions"].items()}
        self.predicates={n:z3.Function(n,*(self.sorts[s] for s in args),z3.BoolSort())
                         for n,args in source["predicates"].items() if not n.startswith("=")}

    def term(self, term, env):
        if isinstance(term,str):
            return env[term]
        return self.functions[term[0]](*(self.term(t,env) for t in term[1:]))

    def atom(self, atom, env):
        name,*raw=atom
        terms=tuple(self.term(t,env) for t in raw)
        if name.startswith("="):
            return terms[0]==terms[1]
        return self.predicates[name](*terms)

    def formula(self, row, env=None):
        env={} if env is None else env
        kind,*args=row
        if kind=="atom":
            return self.atom(args,env)
        if kind=="not":
            return z3.Not(self.formula(args[0],env))
        if kind in ("all","exists"):
            name,sort,body=args
            var=z3.FreshConst(self.sorts[sort],"scope")
            quantified=z3.ForAll if kind=="all" else z3.Exists
            return quantified([var],self.formula(body,env|{name:var}))
        a,b=(self.formula(x,env) for x in args)
        return {"and":z3.And,"or":z3.Or,"implies":z3.Implies,"iff":lambda a,b:a==b}[kind](a,b)


def evaluate(formulas):
    s=z3.Solver()
    s.set(timeout=TIMEOUT,random_seed=1)
    s.add(*formulas)
    started=perf_counter_ns()
    answer=s.check()
    elapsed=perf_counter_ns()-started
    receipt=dict(status=str(answer),solve_ns=elapsed,reason=s.reason_unknown() if answer==z3.unknown else None)
    return receipt,s.sexpr()


def ground_formula(source,normal,depth,selected):
    _,_,schemas=fol.signature(normal)
    clauses=[row for row in schemas if row["id"].startswith("formula")]
    terms=domain(source,normal,depth,64) if selected is None else {
        s:[fol.frozen(t) for t in values] for s,values in selected.items()}
    assert terms is not None
    universe={t for values in terms.values() for t in values}
    atoms,rows,_=instances(clauses,terms,depth,3000,allowed_terms=universe)
    assert rows is not None
    language=Language(normal)
    expressions={i:language.atom(atom,{}) for atom,i in atoms.items()}
    return [z3.Or(*(expressions[abs(i)] if i>0 else z3.Not(expressions[abs(i)])
                   for i in prop.literals(row))) for row in rows]


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def main():
    data=json.loads((ROOT/"data/equality-experiment-v1.json").read_text())
    results=[]
    inputs={}
    for row in data["cases"]:
        source=row["source"]
        language=Language(source)
        original,raw=evaluate([*(language.formula(p) for p in source["premises"]),
                               z3.Not(language.formula(source["goal"]))])
        normal,_=compile_case(source)
        selected=row.get("term_proposal",{}).get("selected")
        bounded,finite=evaluate(ground_formula(source,normal,row["depth"],selected))
        expected="unsat" if row["expected"]=="PROVED" else "sat"
        assert bounded["status"]==expected and original["status"] in (expected,"unknown")
        label=row["id"]
        results.append(dict(id=label,source=original,same_terms=bounded))
        inputs[label]=dict(source=raw,same_terms=finite)
        print(label,original["status"],bounded["status"],flush=True)
    save("data/z3-control-v1.json",dict(status="CHECKED_EXTERNAL_Z3_CONTROL",version=z3.get_full_version(),
        timeout_ms=TIMEOUT,cases=results))
    save("data/z3-inputs-v1.json",inputs)


if __name__=="__main__":
    main()
