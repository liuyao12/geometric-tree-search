"""Bind the arithmetic inputs to the original geometric search certificates."""
from hashlib import sha256
from pathlib import Path
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]


def load(path):
    return json.loads((ROOT/path).read_text())


def main():
    pins=load("input/geometry-pins-v1.json")
    for label,pin in pins.items():
        for name,expected in (pin["entries"]|pin.get("audit_entries",{})).items():
            blob=(ROOT/"geometry"/label/name).read_bytes()
            assert expected["bytes"]==len(blob) and expected["sha256"]==sha256(blob).hexdigest()
    receipts={}
    for shape in ("turtle","penrose"):
        proc=subprocess.run([sys.executable,"-I","-S","-B","source/qualify_v1.py"],
                            cwd=ROOT/"geometry"/shape,check=True,text=True,capture_output=True)
        receipts[shape]=json.loads(proc.stdout)
    measured={r["id"]:r for r in load("input/measured-pockets-v1.json")}
    turtle=receipts["turtle"]
    assert measured["turtle-pocket"]["cycles"]==[turtle["cycle"]]
    assert measured["turtle-pocket"]["tile"]==load("geometry/turtle/input/exact-point-model-v1.json")["polygon"]
    for r in receipts["penrose"]:
        assert measured[r["id"]]["cycles"]==(r["cycles"] if "cycles" in r else [r["cycle"]])
    (ROOT/"data/geometry-binding-v1.json").write_text(json.dumps(receipts,sort_keys=True)+"\n")
    print(turtle["status"],[r["status"] for r in receipts["penrose"]],flush=True)


if __name__=="__main__":
    main()
