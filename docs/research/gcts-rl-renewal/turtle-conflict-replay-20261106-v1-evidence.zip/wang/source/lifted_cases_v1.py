"""Freeze theorem statements, training donors, and negative controls."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]


def load(name):
    return json.loads((ROOT/"input"/name).read_text())


def a(p,*terms):
    return ["atom",p,*terms]


def all_(v,b,sort="U"):
    return ["all",v,sort,b]


def exists(v,b,sort="U"):
    return ["exists",v,sort,b]


def implies(p,q):
    return ["implies",p,q]


def neg(p):
    return ["not",p]


def iterate(f,x,n):
    for _ in range(n):
        x=[f,x]
    return x


def case(name,functions,predicates,premises,goal,*,equality=False):
    return dict(id=name,sorts=["U"],functions={f:[["U"]*n,"U"] for f,n in functions.items()},
                predicates={p:["U"]*n for p,n in predicates.items()},premises=premises,
                goal=goal,equality=equality)


def routes(label,tag,num,wide=False):
    p,q,r=(tag+x for x in ("P","Q","R"))
    f,g,h,k,j=(tag+x for x in ("f","g","h","k","j"))
    c=tag+"a"
    constants=[c,*(tag+f"b{i}" for i in range(num))]
    fx,gx=[f,"?x"],[g,"?x"]
    aliases=[a(p,[f,[c]],[g,[b]]) for b in constants[1:]]
    ridges=[a(p,[f,[k,[b]]],[g,[b]]) for b in constants[1:]]
    if wide:
        ridges.extend(a(p,[f,[h,[b]]],[g,[b]]) for b in constants[1:])
    rules=[all_("?x",implies(a(p,fx,gx),a(q,[h,"?x"]))),
           all_("?x",implies(a(p,[f,[j,"?x"]],gx),a(r,"?x")))]
    seed=a(p,[f,[c]],[g,[c]])
    funcs={f:1,g:1,h:1,k:1,j:1,**{t:0 for t in constants}}
    return case(label,funcs,{p:2,q:1,r:1},[*aliases,*ridges,*rules,seed],a(q,[h,[c]]))


def deep(n):
    funcs={"a":0,"f":1}
    premises=[a("P",["a"]),all_("?x",implies(a("P","?x"),a("P",["f","?x"]))),
              all_("?x",implies(a("P",iterate("f","?x",n)),a("Q","?x")))]
    return case(f"iterate-depth-{n}",funcs,{"P":1,"Q":1},premises,exists("?x",a("Q","?x")))


def disjunction():
    return case("proof-by-cases",{},{"P":1,"Q":1,"R":1},
                [all_("?x",["or",a("P","?x"),a("Q","?x")]),
                 all_("?x",implies(a("P","?x"),a("R","?x"))),
                 all_("?x",implies(a("Q","?x"),a("R","?x")))],
                all_("?x",a("R","?x")))


def factoring():
    return case("factoring-to-universal",{},{"P":1},
                [all_("?x",all_("?y",["or",a("P","?x"),a("P","?y")]))],
                all_("?z",a("P","?z")))


def control():
    return case("occurs-check-control",{"f":1},{"R":2},
                [all_("?x",a("R","?x",["f","?x"]))],exists("?x",a("R","?x","?x")))


def main():
    base={c["id"]:c for c in load("cases-v1.json")+load("new-cases-v1.json")}
    tutorial=load("tutorial-cases-v1.json")["cases"]
    donors=[routes(f"donor-{i}",f"d{i}",2+i%3,True) for i in range(8)]
    donors.extend({**deep(i),"id":f"donor-depth-{i}"} for i in (3,4,5))
    train=[routes(f"train-route-{i}",f"t{i}",2+i%3,True) for i in range(8)]
    train.extend(deep(i) for i in (2,3,4,5))
    train.extend(base[k] for k in ("nested-choice","quantifier-duality","shadowed-existential"))
    for n in range(2,8):
        constants={f"c{i}":0 for i in range(n+1)}
        equality=lambda x,y:a("=U",x,y)
        edges=[equality([f"c{i}"],[f"c{i+1}"]) for i in range(n)]
        train.append(case(f"train-equality-{n}",constants,{},edges,equality(["c0"],[f"c{n}"]),equality=True))
    cohort=[factoring(),disjunction(),deep(8),base["exists-map"],base["incidence-existence"],
            base["peano-nonzero-successor"],base["hilbert-incidence-uniqueness"],*tutorial,
            routes("receiver-clash","r",10,True),routes("receiver-alias","s",18),
            control(),base["quantifier-swap-control"]]
    cases=dict(donors=donors,training=train,holdout=cohort,negative=["occurs-check-control","quantifier-swap-control","tptp-tutorial-family-mutation"])
    (ROOT/"input/cohort-v1.json").write_text(json.dumps(cases,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
