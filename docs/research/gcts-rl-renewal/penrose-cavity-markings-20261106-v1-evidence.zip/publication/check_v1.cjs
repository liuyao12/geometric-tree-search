const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({viewport: {width: 1180, height: 920}});
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/penrose-cavity-markings-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit", timeout: 60000});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelector("#geometry mjx-container"), null, {timeout: 60000});
    assert.equal(await page.locator("#reader svg").count(), 4);
    assert.equal(await page.locator("#two-pockets path.cavity").count(), 2);
    assert.equal(await page.locator("#seal-move path.added").count(), 1);
    assert.equal(await page.locator("#optional path.optional").count(), 1);
    assert.equal(await page.locator("#benchmark details tbody tr").count(), 27);
    await page.locator("#benchmark details summary").click();
    assert(await page.locator("#benchmark details tbody tr").last().isVisible());
    if (!process.argv[2]) {
      await page.locator("#reader .visuals").screenshot({path: path.join(__dirname,"cavity-view-v1.png")});
    }
    await page.setViewportSize({width: 390,height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors,[]);
    const receipt={status:"CHECKED_PENROSE_CAVITY_READER",cases:27,visuals:4,
      closingMove:true,optionalHole:true,mobileNoOverflow:true,mathTypeset:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}
main().catch(error => {console.error(error); process.exitCode = 1;});
