"""Package the validated notebook, exact witnesses, and reproducible evidence."""
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0,str(Path(__file__).resolve().parent))
from replay_v1 import INPUTS, OUTPUTS, ROOT, STEM, pin


def load(path):
    return json.loads((ROOT/path).read_text())


def save(path,obj):
    (ROOT/path).write_text(json.dumps(obj,sort_keys=True,indent=2)+"\n")


def main():
    report=ROOT/"report"
    replay=load("publication/replay-v1.json")
    for name,expected in replay["outputs"].items():
        assert pin((ROOT/name).read_bytes())==expected
    assert pin((ROOT/"data/cavity-timing-v1.json").read_bytes())==replay["timing_input"]
    search=load("data/cavity-search-v1.json")
    summary=f"report/{STEM}-results.json"
    save(summary,dict(schema="PENROSE-CAVITY-MARKINGS-RESULTS-v1",audit=load("data/cavity-audit-v1.json"),
         reader=load("publication/browser-v1.json"),replay=replay,timing=load("data/cavity-timing-v1.json"),
         results=search["results"],node_limit=search["node_limit"],marks=search["proof"]["marks"]))
    paths=[ROOT/p for p in (*INPUTS,*OUTPUTS,summary)]
    paths.extend(sorted((ROOT/"data").glob("*.log")))
    paths.extend(ROOT/"publication"/p for p in ("REPLAY.md","replay_v1.py","replay-v1.json","browser-v1.json",
                 "package_v1.py","check_v1.cjs","cavity-view-v1.png"))
    archive=report/f"{STEM}-evidence.zip"
    pins={}
    with ZipFile(archive,"w") as bundle:
        for path in paths:
            name,raw=str(path.relative_to(ROOT)),path.read_bytes()
            if path.suffix!=".png":
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)",raw),name
            assert name not in pins
            pins[name]=pin(raw)
            item=ZipInfo(name,(2026,11,6,0,0,0))
            item.external_attr=0o100644<<16
            bundle.writestr(item,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p:pin(bundle.read(p)) for p in bundle.namelist()}==pins
    assets={p.name:pin(p.read_bytes()) for p in (report/f"{STEM}.html",ROOT/summary,archive)}
    save(f"report/{STEM}-manifest.json",dict(schema="PENROSE-CAVITY-MARKINGS-MANIFEST-v1",
                                          assets=assets,archive_entries=pins))
    print(json.dumps(dict(assets=assets,entries=len(pins)),indent=2))


if __name__=="__main__":
    main()
