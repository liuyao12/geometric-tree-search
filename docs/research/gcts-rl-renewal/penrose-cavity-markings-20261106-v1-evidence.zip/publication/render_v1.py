"""Render the search results, exact pockets, and optional-hole control."""
from html import escape
import json
from math import cos, pi, sin
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cases_v1 import frozen
from geometry_v1 import Penrose

STEM="penrose-cavity-markings-20261106-v1"
ARMS=("baseline","fresh","learned")


def load(path):
    return json.loads((ROOT/path).read_text())


def project(point,den=1):
    return sum(v*cos(2*pi*k/5) for k,v in enumerate(point))/den, -sum(
        v*sin(2*pi*k/5) for k,v in enumerate(point))/den


def svg(shapes,label):
    all_points=[p for shape,_ in shapes for p in shape]
    xs,ys=zip(*all_points)
    a,b,c,d=min(xs),min(ys),max(xs),max(ys)
    margin=max(c-a,d-b)*.075
    view=f"{a-margin:.5f} {b-margin:.5f} {c-a+2*margin:.5f} {d-b+2*margin:.5f}"
    parts=[f'<svg role="img" aria-label="{escape(label)}" viewBox="{view}">']
    for polygon,kind in shapes:
        positions="L".join(f"{x:.5f},{y:.5f}" for x,y in polygon)
        parts.append(f'<path class="{kind}" d="M{positions}Z"/>')
    return "".join((*parts,"</svg>"))


def poly(points,den=1):
    return tuple(project(p,den) for p in points)


def case_svg(g,row,patch,cycle,label,optional=False):
    seed=frozen(row["seed"])
    shapes=[(poly(g.poly(t)),"shape seed" if t in seed else "shape added") for t in patch]
    shapes.append((poly(cycle),"optional" if optional else "cavity"))
    shapes.extend((poly(raw,den),"core") for den,raw in row.get("core",[]))
    return svg(shapes,label)


def figure(title,picture,caption,key):
    return f'<figure id="{key}"><h3>{title}</h3>{picture}<figcaption>{caption}</figcaption></figure>'


def table(headers,rows,kind=""):
    heads="".join(f"<th>{h}</th>" for h in headers)
    body=[]
    for first,*rest in rows:
        body.append(f'<tr><th scope="row">{first}</th>'+"".join(f"<td>{x}</td>" for x in rest)+"</tr>")
    return f'<div class="table {kind}"><table><thead><tr>{heads}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def main():
    g=Penrose()
    pilot=load("data/cavity-pilot-v1.json")
    results=load("data/cavity-search-v1.json")
    timing=load("data/cavity-timing-v1.json")
    inputs={r["id"]:r for r in load("input/cavity-cases-v1.json")}
    by_id={r["id"]:r for r in results["results"]}
    events={e["case"]:e for e in results["proof"]["learned_events"]}
    twin=pilot["witness"]
    shapes=[(poly(g.poly(frozen(t))),"shape seed") for patch in twin["patches"] for t in patch]
    shapes.extend((poly(ring),"cavity") for ring in twin["cavities"])
    pictures=[figure("Two separate regular pockets",svg(shapes,"Two distinct sealed regular pentagons"),
              "Both pockets fail individually. Their combined area has integer rhomb coefficients.","two-pockets")]
    event=events["moving-open-1"]
    pictures.append(figure("A move seals a required pocket",case_svg(g,inputs[event["case"]],frozen(event["path"]),
             event["cycle"],"Blue seed rhombs, purple closing rhomb, orange pocket and green required core"),
             "The purple rhomb closes the orange pocket inside the green core. The branch can end immediately.","seal-move"))
    event=events["fixed-concave-0"]
    pictures.append(figure("A different outline",case_svg(g,inputs[event["case"]],frozen(event["path"]),
             event["cycle"],"Exact concave pentagon surrounded by rhombs"),
             "The concave pentagon supplies the second certificate. Its area differs from the regular pentagon.","concave"))
    optional=by_id["moving-optional-hole"]["arms"]["learned"]
    row=inputs["moving-optional-hole"]
    pictures.append(figure("A pocket outside the request",case_svg(g,row,frozen(optional["patch"]),row["cycle"],
            "A legal cover of the small green requested core with the pentagonal pocket left open",optional=True),
            "The green request lies outside the pocket. The search leaves the pocket open and extends the cover by one rhomb.","optional"))
    gallery='<div class="visuals">'+"".join(pictures)+'</div>'
    resolved=[r for r in results["results"] if r["arms"]["baseline"]["status"]!="BOUNDED"]
    work=[]
    for label,k in (("Visited nodes","nodes"),("Placement checks","placement_checks"),
                    ("Exact cavity area evaluations","cavity_area_checks")):
        chosen=resolved if k!="cavity_area_checks" else results["results"]
        work.append((label,*(f'{sum(r["arms"][arm]["counts"].get(k,0) for r in chosen):,}' for arm in ARMS)))
    work_table=table(("Work measure","Baseline","Fresh check","Learned bank"),work,"work-table")
    work_table+="<p class=\"small\">Node and placement totals cover the 26 resolved requests. Cavity area evaluations cover all 27 requests.</p>"
    rows=[]
    for case,result in by_id.items():
        status=result["arms"]["baseline"]["status"].title()
        rows.append((escape(case),escape(result["mode"]),status,*(result["arms"][a]["counts"].get("nodes",0)
                                                               for a in ARMS)))
    cases=table(("Request","Boundary","Outcome","Baseline nodes","Fresh nodes","Learned nodes"),rows)
    groups=(("All requests","all"),("Resolved requests","resolved"),("Presealed pockets","sealed"),
            ("Nearly closed prefixes","open-prefix"),("Fillable controls","fillable"),("Optional pocket","optional"))
    timing_rows=[(label,*(f'{timing["median_totals"][a][group]/1e6:.1f}' for a in ARMS)) for label,group in groups]
    timing_table=table(("Local wall time in ms","Baseline","Fresh check","Learned bank"),timing_rows)
    timing_table+="<p>The table reports the median of seven run totals per arm in separate interpreter processes. The fresh and learned checks reduced total time on this cohort. Certificate reuse saved area evaluations and had similar elapsed time to the fresh check.</p>"
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for key,val in dict(STEM=STEM,GALLERY=gallery,WORK=work_table,CASES=cases,TIMING=timing_table).items():
        html=html.replace(f"%%{key}%%",val)
    assert "%%" not in html
    (ROOT/"report"/f"{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
