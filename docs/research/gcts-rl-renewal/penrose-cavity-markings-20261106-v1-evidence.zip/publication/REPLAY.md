# Replay the Penrose cavity marking study

Run with Python 3.10 or newer and assertions enabled. The recorded run used Python 3.12 and the standard library.

```sh
python3 -I -S -B publication/replay_v1.py
```

The clean replay independently generates the two kinds of supporting frame, all 27 requests, the three matched search arms, and the certificate audit. It compares the data and rendered HTML byte for byte. The archived timing sample is carried into rendering as an input because elapsed times vary across runs. Re-measure with:

```sh
python3 -I -S -B source/cavity_timing_v1.py
```

The cut evidence stores the exposed oriented pocket, all placed rhombs, the exact area coordinates, and the donor mark where applicable. The audit checks coverage semantics separately for fixed targets and for convex requested cores. It also validates every successful witness and rejects three altered cuts. Open-prefix cases give the same initial preferred frontier edge to all arms. The bank starts empty and follows the published request order.

The reader audit can be rerun using `node publication/check_v1.cjs` with Playwright and Chromium.
