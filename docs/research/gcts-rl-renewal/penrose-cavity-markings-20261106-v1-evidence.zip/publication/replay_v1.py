"""Rebuild the deterministic Penrose cavity artifacts in a fresh workspace."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
STEM="penrose-cavity-markings-20261106-v1"
STAGES=("source/cavity_pilot_v1.py","source/cavity_cases_v1.py","source/cavity_experiment_v1.py",
        "source/cavity_audit_v1.py","publication/render_v1.py")
OUTPUTS=("input/cavity-cases-v1.json","data/cavity-pilot-v1.json","data/cavity-search-v1.json",
         "data/cavity-audit-v1.json",f"report/{STEM}.html")
SOURCES=("boundary_search","cases","cavity_audit","cavity_cases","cavity_experiment","cavity_marks",
         "cavity_pilot","cavity_timing","check","clipping","cluster","geometry","model",
         "open_cases","open_cover","triangle_geometry")
INPUTS=tuple(f"source/{s}_v1.py" for s in SOURCES)+(
    "publication/render_v1.py","publication/notebook-v1.html","data/cavity-timing-v1.json")


def pin(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())


def main():
    with TemporaryDirectory() as scratch:
        clean=Path(scratch)
        for folder in ("data","input","source","publication","report"):
            (clean/folder).mkdir()
        for path in INPUTS:
            shutil.copyfile(ROOT/path,clean/path)
        for stage in STAGES:
            subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=clean,check=True)
        receipt={}
        for path in OUTPUTS:
            raw=(clean/path).read_bytes()
            assert raw==(ROOT/path).read_bytes(),path
            receipt[path]=pin(raw)
    result=dict(status="MATCHED_CLEAN_REPLAY",python=list(sys.version_info[:3]),outputs=receipt,
                stages=STAGES,timing_input=pin((ROOT/"data/cavity-timing-v1.json").read_bytes()))
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print("Matched",len(receipt),"deterministic artifacts.",flush=True)


if __name__=="__main__":
    main()
