"""Compare exact search with a fresh cavity check and a learned mark bank."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, solve as fixed
from cases_v1 import frozen
from cavity_marks_v1 import CavityBank
from clipping_v1 import Core
from geometry_v1 import Penrose
from open_cover_v1 import solve as movable

LIMIT=600


def load_cases():
    return [{k:frozen(v) for k,v in r.items()}
            for r in json.loads((ROOT/"input/cavity-cases-v1.json").read_text())]


def run(g,inv,row,bank):
    region=Region(g,row["envelope"])
    port=row.get("port")
    inspect=1 if port is not None else 6
    if row["mode"]=="fixed":
        return fixed(region,inv,row["id"],limit=LIMIT,seed=row["seed"],cavities=bank,
                     first_port=port,inspect=inspect)
    core=Core(region,row["core"])
    first,*rest=row["seed"]
    return movable(core,inv,first,row["id"],initial=tuple(rest),cavities=bank,cap=row["cap"],
                   node_limit=LIMIT,order="single",first_port=port,inspect=inspect)


def main():
    g=Penrose()
    inv=Inventory(g)
    bank=CavityBank()
    fresh=CavityBank(learn=False)
    results=[]
    for row in load_cases():
        arms={name:run(g,inv,row,b) for name,b in (("baseline",None),("fresh",fresh),("learned",bank))}
        assert arms["fresh"]["status"]==arms["learned"]["status"]
        if "expected" in row:
            assert all(a["status"] in (row["expected"],"BOUNDED") for a in arms.values())
        if arms["baseline"]["status"]=="POSITIVE":
            assert arms["learned"]["status"]=="POSITIVE"
        if arms["learned"]["status"]=="POSITIVE" and arms["baseline"]["status"]=="NEGATIVE":
            raise AssertionError(row["id"])
        if arms["learned"]["status"]==arms["fresh"]["status"]=="POSITIVE":
            assert arms["learned"]["patch"]==arms["fresh"]["patch"]
        results.append(dict(id=row["id"],mode=row["mode"],kind=row["kind"],arms=arms))
        print(row["id"],[(name,a["status"],a["counts"].get("nodes",0),
                         a["counts"].get("cavity_cuts",0)) for name,a in arms.items()],flush=True)
    proof=dict(marks=bank.marks,learned_events=bank.events,fresh_events=fresh.events)
    values=dict(status="RAN_PAIRED_CAVITY_SEARCH",node_limit=LIMIT,results=results,proof=proof)
    (ROOT/"data/cavity-search-v1.json").write_text(json.dumps(values,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
