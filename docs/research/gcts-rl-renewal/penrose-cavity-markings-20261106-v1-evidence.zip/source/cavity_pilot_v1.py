"""Recover exact sealed Penrose cavities at vertex-touching rhomb frames."""
from collections import defaultdict
from itertools import combinations, product
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import check_v1 as exact
from geometry_v1 import Penrose, add, area, chain, check_rings, pairs, rings_from_edges, sub
from model_v1 import DIRECTIONS, ZERO, incident, rotate

ROOT=Path(__file__).resolve().parents[1]
TURNS={d:i for i,d in enumerate(DIRECTIONS)}


def residual_faces(edges):
    """Trace left faces on the reverse of the exposed occupied boundary."""
    outgoing=defaultdict(list)
    for a,b in edges:
        outgoing[a].append(b)
    next_edge={}
    for a,b in edges:
        back=TURNS[sub(a,b)]
        if not outgoing[b] or a in outgoing[b]:
            return ()
        c=min(outgoing[b],key=lambda c:(back-TURNS[sub(c,b)])%10)
        next_edge[a,b]=b,c
    if set(next_edge)!=set(next_edge.values()):
        return ()
    rings=[]
    remaining=set(edges)
    while remaining:
        first=min(remaining)
        edge=first
        points=[]
        while edge in remaining:
            remaining.remove(edge)
            points.append(edge[0])
            edge=next_edge[edge]
        assert edge==first
        rings.append(tuple(points))
    return tuple(rings)


def sealed(geometry,patch,cycle):
    check_rings(geometry,(cycle,))
    assert len(patch)==len(set(patch))
    assert all(exact.contact(a,b) for a,b in combinations(patch,2))
    edges=chain(geometry,patch)
    assert all((b,a) in edges for a,b in pairs(cycle))
    for tile in patch:
        center=tuple(map(sum,zip(*tile)))
        assert geometry.wind(cycle,center,4)==0
        assert not any(geometry.intrudes(a,b,tile) for a,b in pairs(cycle))
    mass=area(cycle,geometry.cross)
    assert geometry.counts(mass) is None
    return mass


def candidates(geometry,turns):
    vertices=[ZERO]
    for i in turns:
        vertices.append(add(vertices[-1],DIRECTIONS[i]))
    assert vertices.pop()==ZERO
    polygon=tuple(vertices)
    domains=tuple(tuple(t for t in incident(a) if (b,a) in geometry.boundary(t)) for a,b in pairs(polygon))
    rings=[]
    for patch in product(*domains):
        if len(set(patch))!=len(patch) or not all(exact.contact(a,b) for a,b in combinations(patch,2)):
            continue
        edge_set=chain(geometry,patch)
        if not all((b,a) in edge_set for a,b in pairs(polygon)):
            continue
        if any(geometry.wind(polygon,tuple(map(sum,zip(*t))),4)!=0
               or any(geometry.intrudes(a,b,t) for a,b in pairs(polygon)) for t in patch):
            continue
        faces=residual_faces(frozenset((b,a) for a,b in edge_set))
        cycle,=tuple(f for f in faces if set(pairs(f))==set(pairs(polygon)))
        assert sealed(geometry,patch,cycle)==area(polygon,geometry.cross)
        rings.append((patch,cycle,rings_from_edges(edge_set) is None))
    return rings


def main():
    geometry=Penrose()
    regular=candidates(geometry,(0,2,4,6,8))
    concave=candidates(geometry,(0,2,4,8,6))
    assert len(regular)==724 and len(concave)==168
    assert all(pinched for _,_,pinched in regular)
    patch,cycle,_=regular[0]
    mass=sealed(geometry,patch,cycle)
    shift=(10,0,0,0)
    second=tuple(geometry.shift(t,shift) for t in patch)
    translated=tuple(add(p,shift) for p in cycle)
    assert all(exact.contact(a,b) for a in patch for b in second)
    assert sealed(geometry,second,translated)==mass
    for turn in range(10):
        rotated=tuple(geometry.turn(t,turn) for t in patch)
        rotated_cycle=tuple(rotate(p,turn) for p in cycle)
        assert sealed(geometry,rotated,rotated_cycle)==mass
    joint=geometry.counts(add(mass,mass))
    assert joint
    witness=dict(patches=(patch,second),cavities=(cycle,translated),area_twice=mass,joint_mass=joint)
    result=dict(status="CHECKED_PENROSE_CAVITY_PILOT",valid_frames=len(regular),witness=witness,
                alternative=dict(valid_frames=len(concave),examples=[dict(patch=p,cycle=c) for p,c,_ in concave[:16]],
                                 area_twice=area(concave[0][1],geometry.cross),
                                 pinched=sum(p for _,_,p in concave)))
    (ROOT/"data/cavity-pilot-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print("checked",len(regular),len(concave),"frames; pocket area",mass,"joint area counts",joint)


if __name__=="__main__":
    main()
