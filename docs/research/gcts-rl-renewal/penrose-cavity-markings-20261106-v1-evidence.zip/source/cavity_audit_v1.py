"""Independently check the cut certificates and every positive search witness."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Region, remove
from cavity_experiment_v1 import load_cases
from cases_v1 import frozen
from check_v1 import contact
from clipping_v1 import Core, intersection, side, sign, twice
from geometry_v1 import Penrose, add, chain, check_rings, intersects, pairs, sub
from model_v1 import rotate
from open_cover_v1 import component


def physical(p,den=1):
    a,b,c,d=p
    f=Fraction(1,den)
    return ((2*a-b)*f/2,(b-c-d)*f/2),((c-d)*f,b*f)


def legal(g,path,seed):
    assert path[:len(seed)]==seed and len(path)==len(set(path))
    assert all(contact(a,b) for a,b in combinations(path,2))
    assert all(g.boundary(t) for t in path)


def verify_cut(g,row,event):
    path=frozen(event["path"])
    ring=frozen(event["cycle"])
    legal(g,path,row["seed"])
    check_rings(g,(ring,))
    assert all((b,a) in chain(g,path) for a,b in pairs(ring))
    assert all(g.wind(ring,tuple(map(sum,zip(*tile))),4) in (0,1)
               and not any(g.intrudes(a,b,tile) for a,b in pairs(ring)) for tile in path)
    m=twice(tuple(physical(p) for p in ring))
    assert m==tuple(event["area_twice"])
    assert sign(m)>0 and any(v<0 or v%2 for v in m)
    region=Region(g,row["envelope"])
    if row["mode"]=="fixed":
        remaining=region.edges
        for tile in path:
            remaining=remove(remaining,g.boundary(tile))
        assert (region.edges-remaining)|frozenset((b,a) for a,b in remaining-region.edges)==chain(g,path)
        # Both shapes are wholly in the interior if all pocket edges avoid the
        # target boundary and no excluded target hole lies inside the pocket.
        assert all(region.inside(p,1) for p in ring)
        axes=g.cross,g.sign,g.unit,g.transverse
        assert not any(intersects(a,b,p,q,*axes) for a,b in pairs(ring) for p,q in region.lines)
        assert all(g.wind(ring,hole[0],1)==0 for hole in region.rings[1:])
    else:
        assert any(all(sign(side(a,b,physical(p)))>=0
                       for a,b in pairs(tuple(physical(q,den) for q in shape))
                       for p in ring) for den,shape in row["core"])
    if len(path)>len(row["seed"]):
        assert row.get("port") is not None
        assert row["port"] in g.boundary(path[len(row["seed"])])
    return len(path)-len(row["seed"])


def normalized(ring):
    forms=[]
    for turn in range(10):
        path=tuple(rotate(p,turn) for p in ring)
        zero=min(path)
        start=path.index(zero)
        forms.append(tuple(sub(path[(i+start)%len(path)],zero) for i in range(len(path))))
    return min(forms)


def verify_positive(g,row,arm):
    patch=frozen(arm["patch"])
    legal(g,patch,row["seed"])
    region=Region(g,row["envelope"])
    if row["mode"]=="fixed":
        assert chain(g,patch)==region.edges
    else:
        assert len(patch)<=row["cap"] and component(g,patch)==set(patch)
        assert all(region.exterior(t) is None for t in patch)
        core=Core(region,row["core"])
        # Full coverage by independent direct intersection sums over rhombs.
        rhombs=[tuple(physical(p) for p in g.poly(t)) for t in patch]
        for den,shape in row["core"]:
            target=tuple(physical(p,den) for p in shape)
            total=(0,0)
            for tile in rhombs:
                total=add(total,intersection(target,tile))
            assert total==twice(target)
        assert len(core.polygons)==len(row["core"])
    return len(patch)


def main():
    rows={r["id"]:r for r in load_cases()}
    data=json.loads((ROOT/"data/cavity-search-v1.json").read_text())
    g=Penrose()
    proof=data["proof"]
    audit=Counter()
    for mode in ("learned","fresh"):
        active=set()
        for event in proof[mode+"_events"]:
            row=rows[event["case"]]
            depth=verify_cut(g,row,event)
            audit[mode+"_cuts"]+=1
            if depth:
                audit[mode+"_after_moves"]+=1
            key=event["mark"]
            if mode=="fresh":
                assert key is None
                continue
            mark=proof["marks"][key]
            assert tuple(event["area_twice"])==tuple(mark["area_twice"])
            assert normalized(frozen(event["cycle"]))==frozen(mark["shape"])
            if key not in active:
                assert mark["donor"]==event["case"]
                active.add(key)
            elif mark["donor"]!=event["case"]:
                audit["cross_request_hits"]+=1
        if mode=="learned":
            assert active==set(proof["marks"])
    for result in data["results"]:
        row=rows[result["id"]]
        arms=result["arms"]
        assert len({a["status"] for a in arms.values()})==1
        for arm in arms.values():
            if arm["status"]=="POSITIVE":
                verify_positive(g,row,arm)
                audit["positive_witnesses"]+=1
        if row["kind"]=="optional":
            assert arms["learned"]["counts"].get("cavity_outside_request",0)>0
            assert arms["learned"]["status"]=="POSITIVE"
    origin=proof["learned_events"][0]
    for tamper in ("mass","missing-rhomb","optional-request"):
        event=deepcopy(origin)
        row=rows[origin["case"]]
        if tamper=="mass":
            event["area_twice"][0]+=2
        elif tamper=="missing-rhomb":
            event["path"].pop()
        else:
            row=rows["moving-optional-hole"]
            event["path"]=row["seed"]
            event["cycle"]=row["cycle"]
        try:
            verify_cut(g,row,event)
        except AssertionError:
            audit["tampered_cuts_rejected"]+=1
        else:
            raise AssertionError(tamper)
    assert audit["learned_cuts"]==audit["fresh_cuts"]==20
    assert audit["learned_after_moves"]==audit["fresh_after_moves"]==6
    assert audit["cross_request_hits"]==18 and audit["positive_witnesses"]==21
    result=dict(status="CHECKED_PENROSE_CAVITY_SEARCH",audit=dict(audit))
    (ROOT/"data/cavity-audit-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print(dict(audit),flush=True)


if __name__=="__main__":
    main()
