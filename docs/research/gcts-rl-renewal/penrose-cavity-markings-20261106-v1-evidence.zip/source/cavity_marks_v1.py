"""Learn sealed Penrose cavity obstructions, subject to the coverage boundary."""
from hashlib import sha256
import json

from cavity_pilot_v1 import residual_faces
from clipping_v1 import side, sign
from geometry_v1 import area, check_rings, intersects, pairs, sub
from model_v1 import rotate


def relative(ring):
    i=min(range(len(ring)),key=ring.__getitem__)
    ordered=ring[i:]+ring[:i]
    return tuple(sub(p,ordered[0]) for p in ordered)


def key_forms(ring):
    return tuple(sorted({relative(tuple(rotate(p,j) for p in ring)) for j in range(10)}))


def required(region,core,ring):
    g=region.g
    if core is not None:
        points=tuple(core.point(p) for p in ring)
        return any(all(sign(side(a,b,p))>=0 for a,b in pairs(poly) for p in points)
                   for poly in core.polygons)
    # Strict containment and no excluded boundary ring inside the pocket.
    if not all(region.inside(p,1) for p in ring):
        return False
    axes=g.cross,g.sign,g.unit,g.transverse
    if any(intersects(a,b,p,q,*axes) for a,b in pairs(ring) for p,q in region.lines):
        return False
    return all(g.wind(ring,hole[0],1)==0 for hole in region.rings[1:])


class CavityBank:
    def __init__(self,learn=True):
        self.learn=learn
        self.forms={}
        self.marks={}
        self.events=[]

    def cut(self,region,core,frontier,path,case,stats):
        assert region.g.kind=="penrose"
        g=region.g
        stats["cavity_scans"]+=1
        if not frontier:
            return False
        for ring in residual_faces(frozenset((b,a) for a,b in frontier)):
            if len(ring)<3 or len(set(ring))!=len(ring):
                continue
            key=relative(ring)
            prior=self.forms.get(key)
            if prior is None:
                mass=area(ring,g.cross)
                stats["cavity_area_checks"]+=1
                if g.sign(mass)<=0 or g.counts(mass) is not None:
                    continue
                try:
                    check_rings(g,(ring,))
                except AssertionError:
                    continue
            else:
                mass=self.marks[prior]["area_twice"]
            if not required(region,core,ring):
                stats["cavity_outside_request"]+=1
                continue
            if prior is not None:
                stats["cavity_reuse"]+=1
                if self.marks[prior]["donor"]!=case:
                    stats["cavity_transfer"]+=1
            elif self.learn:
                forms=key_forms(ring)
                prior=sha256(json.dumps(forms[0],separators=(",",":")).encode()).hexdigest()
                self.marks[prior]=dict(donor=case,shape=forms[0],area_twice=mass)
                for rotated in forms:
                    self.forms[rotated]=prior
                stats["cavity_learned"]+=1
            stats["cavity_cuts"]+=1
            self.events.append(dict(case=case,mark=prior,cycle=ring,area_twice=mass,path=path))
            return True
        return False
