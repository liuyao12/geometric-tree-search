"""Author seeded core/envelope queries without specifying an output outline."""
from fractions import Fraction
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cases_v1 import frozen, fuse, load, patch_ring, relocate, rhomb_grid
from boundary_search_v1 import Inventory, Region
from clipping_v1 import Core
from geometry_v1 import Penrose, Turtle, add, chain, mul, rings_from_edges, sub
import model_v1 as penrose


def geometries():
    return {"turtle":Turtle(load("input/exact-point-model-v1.json")),"penrose":Penrose()}


def shared(g,patch,t):
    others={e for x in patch if x!=t for e in g.boundary(x)}
    return tuple(sorted(e for e in g.boundary(t) if e[::-1] in others))


def contact(g,a,b):
    return g.sites(a).isdisjoint(g.sites(b)) if g.kind=="turtle" else penrose.legal_contact(a,b)


def square(g,p,den,radius):
    f=Fraction(radius)
    d=den*f.denominator
    c=mul(f.denominator,p)
    u,v=(mul(f.numerator*den,x) for x in (g.unit,g.transverse))
    return d,(sub(sub(c,u),v),sub(add(c,u),v),add(add(c,u),v),add(sub(c,u),v))


def fit_square(g,envelope,p,den,scales):
    region=Region(g,envelope)
    for r in scales:
        poly=square(g,p,den,r)
        try:
            Core(region,(poly,))
        except AssertionError:
            continue
        return poly
    raise ValueError("No interior core around the query point")


def seam_core(g,envelope,e,radii=(Fraction(1,32),)):
    return fit_square(g,envelope,add(*e),2,radii)


def tile_interior(g,t):
    if g.kind=="penrose":
        return tuple(map(sum,zip(*t))),4
    poly=g.poly(t)
    scale=g.model.scale
    s=tuple(map(sum,zip(*poly)))
    n=len(poly)
    q=min(g.sites(t),key=lambda p:(sum(abs(n*a-scale*b) for a,b in zip(p,s,strict=True)),p))
    return q,scale


def assemble(g,rings,seed):
    region=Region(g,rings)
    outer=fuse(region.edges,chain(g,(seed,)))
    cycles=rings_from_edges(outer) if outer else None
    if cycles is None or len(cycles)!=1:
        return None
    envelope=tuple(cycles)
    try:
        combined=Region(g,envelope)
    except (AssertionError,ValueError):
        return None
    if combined.counts!=add(region.counts,g.mass(seed)):
        return None
    return envelope


def negative_pair(g,data,inv):
    bad=data["donor"]
    start=data["donor_edge"]
    delta=data["translated_anchor"]
    moved=dict(data["movable"])["moved-negative"]
    edge=tuple(add(a,delta) for a in start)
    for seed, in inv.at(start[::-1]):
        envelope=assemble(g,bad,seed)
        receiver=g.shift(seed,delta)
        updated=assemble(g,moved,receiver)
        if envelope is None or updated is None:
            continue
        donor_region=Region(g,envelope)
        receive_region=Region(g,updated)
        occ=donor_region.extend(frozenset(),(seed,))
        options=inv.at(start)
        guards=[donor_region.block(t,occ) for t, in options]
        if not guards or not all(guards):
            continue
        received_occ=receive_region.extend(frozenset(),(receiver,))
        if not all(receive_region.blocked(receive_region.relocate(w,delta),received_occ) for w in guards):
            continue
        core=seam_core(g,envelope,start)
        receive_core=seam_core(g,updated,edge)
        donor=dict(id="obstruction-donor",envelope=envelope,seed=seed,core=(core,),cap=4,
                   expected="NEGATIVE",port=start)
        negative=dict(id="moved-obstruction",envelope=updated,seed=receiver,core=(receive_core,),cap=4,
                      expected="NEGATIVE",port=edge)
        for t, in inv.at(edge):
            if not contact(g,receiver,t):
                continue
            good=patch_ring(g,(receiver,t))
            if good is None:
                continue
            relaxed_core=seam_core(g,good,edge)
            relaxed=dict(id="relaxed-port",envelope=good,seed=receiver,core=(relaxed_core,),cap=2,
                         expected="POSITIVE",port=edge)
            return donor,negative,relaxed
    raise AssertionError(f"No seeded transfer pair for {g.kind}")


def puzzle(name,g,patch,seed,polys,cap):
    envelope=patch_ring(g,patch)
    assert envelope
    core=Core(Region(g,envelope),tuple(polys))
    assert core.region.exterior(seed) is None
    return dict(id=name,envelope=envelope,core=tuple(polys),seed=seed,cap=cap,expected="POSITIVE")


def turtle_queries(g):
    p1=next(frozen(row["patch"]) for row in load("input/growth-v1.json")["levels"] if row["id"]=="P1")
    envelope=patch_ring(g,p1)
    seed=min(p1,key=lambda t:(-len(shared(g,p1,t)),t))
    e=shared(g,p1,seed)[0]
    core=seam_core(g,envelope,e,(2,1,Fraction(1,2),Fraction(1,32)))
    yield puzzle("convex-core",g,p1,seed,(core,),8)
    # Pick a point in a tile two steps from the root in the known patch.
    adjacent={t:{u for u in p1 if t!=u and any(e[::-1] in g.boundary(u) for e in g.boundary(t))}
              for t in p1}
    remote=min(set().union(*(adjacent[t] for t in adjacent[seed]))-{seed}-adjacent[seed])
    q,d=tile_interior(g,remote)
    inside=fit_square(g,envelope,q,d,(Fraction(1,128),Fraction(1,256)))
    yield puzzle("remote-core",g,p1,seed,(inside,),5)
    seed=min(p1)
    seams=shared(g,p1,seed)
    centers=(seam_core(g,envelope,seams[0]),seam_core(g,envelope,seams[-1]))
    assert centers[0]!=centers[1]
    yield puzzle("two-core-pieces",g,p1,seed,centers,5)


def penrose_queries(g):
    u,v=(penrose.DIRECTIONS[i] for i in (0,2))
    grid=rhomb_grid(4,3,2)
    core=(4,tuple(add(mul(i,u),mul(j,v)) for i,j in ((1,1),(9,1),(9,5),(1,5))))
    yield puzzle("convex-core",g,grid,penrose.rhomb(g.zero,0,2),(core,),8)
    strip=rhomb_grid(6,1,2)
    seed=penrose.rhomb(g.zero,0,2)
    remote=penrose.rhomb(mul(3,u),0,2)
    q,d=tile_interior(g,remote)
    envelope=patch_ring(g,strip)
    inside=fit_square(g,envelope,q,d,(Fraction(1,16),))
    yield puzzle("remote-core",g,strip,seed,(inside,),5)
    edges=shared(g,grid,seed)
    assert len(edges)==2
    envelope=patch_ring(g,grid)
    yield puzzle("two-core-pieces",g,grid,seed,tuple(seam_core(g,envelope,e) for e in edges),5)


def create():
    source={k:{n:frozen(x) for n,x in v.items()} for k,v in load("input/cases-v1.json").items()}
    result={}
    for name,g in geometries().items():
        donor,bad,relaxed=negative_pair(g,source[name],Inventory(g))
        queries=list(turtle_queries(g) if name=="turtle" else penrose_queries(g))
        result[name]=dict(donor=donor,queries=(*queries,bad,relaxed),cluster_outlines=source[name]["training"])
    return result


if __name__=="__main__":
    evidence=create()
    (ROOT/"input/open-cases-v1.json").write_text(json.dumps(evidence,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps({k:[r["id"] for r in v["queries"]] for k,v in evidence.items()},sort_keys=True))
