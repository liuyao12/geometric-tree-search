"""Time each arm in separate interpreter processes with fresh search caches."""
from pathlib import Path
import json
from statistics import median
import subprocess
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory
from cavity_experiment_v1 import load_cases,run
from cavity_marks_v1 import CavityBank
from geometry_v1 import Penrose

ARMS=("baseline","fresh","learned")
REPEATS=7


def sample(name):
    g=Penrose()
    inv=Inventory(g)
    bank=None if name=="baseline" else CavityBank(learn=name=="learned")
    rows=load_cases()
    result={}
    for row in rows:
        start=perf_counter_ns()
        out=run(g,inv,row,bank)
        result[row["id"]]=(out["status"],perf_counter_ns()-start)
    print(json.dumps(result),flush=True)


def main():
    raw={a:[] for a in ARMS}
    source=json.loads((ROOT/"data/cavity-search-v1.json").read_text())
    ids={r["id"]:r["arms"]["baseline"]["status"] for r in source["results"]}
    groups={r["id"]:r["kind"] for r in source["results"]}
    for i in range(REPEATS):
        for name in ARMS[i%len(ARMS):]+ARMS[:i%len(ARMS)]:
            out=subprocess.run([sys.executable,"-I","-S","-B",str(Path(__file__).resolve()),name],
                               cwd=ROOT,check=True,capture_output=True,text=True)
            sample_=json.loads(out.stdout)
            assert {k:v[0] for k,v in sample_.items()}==ids
            raw[name].append({k:v[1] for k,v in sample_.items()})
    summaries={}
    for name,values in raw.items():
        totals={}
        for group in ("all","resolved","sealed","open-prefix","fillable","optional"):
            take=[case for case in ids if group=="all" or group=="resolved" and ids[case]!="BOUNDED"
                  or groups[case]==group]
            totals[group]=int(median(sum(v[case] for case in take) for v in values))
        summaries[name]=totals
    result=dict(status="MEASURED_LOCAL_WALL_TIME",repeats=REPEATS,
                unit="nanoseconds",samples=raw,median_totals=summaries)
    (ROOT/"data/cavity-timing-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(summaries,sort_keys=True),flush=True)


if __name__=="__main__":
    if len(sys.argv)>1:
        sample(sys.argv[1])
    else:
        main()
