"""Grow a seeded cover of a core inside an envelope with no supplied outer outline."""
from collections import Counter
from itertools import combinations

from clipping_v1 import center, intersection, sign
from geometry_v1 import chain, sub
import check_v1 as independent


class PoolLimit(Exception):
    pass


class CandidatePool:
    """Enumerate an anchored superdomain only when no forced edge is available."""
    def __init__(self,region,inventory,seed,maximum,limit,stats):
        self.region,self.inv,self.seed=region,inventory,seed
        self.maximum,self.limit,self.stats=maximum,limit,stats
        self.known=None

    def all(self):
        if self.known is None:
            seen=self.lattice() if self.region.g.kind=="turtle" else self.anchored()
            self.known=tuple(sorted(seen))
            self.stats["pool_size"]=len(seen)
        return self.known

    def lattice(self):
        g=self.region.g
        seen={self.seed}
        occupied=g.sites(self.seed)
        x,y=zip(*self.region.rings[0])
        xmin,xmax,ymin,ymax=min(x),max(x),min(y),max(y)
        for turn,_,_ in g.bases:
            u,v=zip(*g.model.polygons[turn])
            for a in range(xmin-min(u),xmax-max(u)+1):
                for b in range(ymin-min(v),ymax-max(v)+1):
                    t=turn,a,b
                    self.stats["pool_probes"]+=1
                    if self.region.exterior(t) is None and g.sites(t).isdisjoint(occupied):
                        seen.add(t)
                        if len(seen)>self.limit:
                            raise PoolLimit
        return seen

    def anchored(self):
        g=self.region.g
        seen={self.seed}
        visited={self.seed}
        frontier=(self.seed,)
        for _ in range(self.maximum-1):
            following=set()
            for t in frontier:
                for edge in g.boundary(t):
                    for other, in self.inv.at(edge[::-1]):
                        if other not in visited:
                            visited.add(other)
                            self.stats["pool_probes"]+=1
                            if self.region.exterior(other) is None and independent.contact(self.seed,other):
                                following.add(other)
                                if len(seen)+len(following)>self.limit:
                                    raise PoolLimit
            if not following:
                break
            seen.update(following)
            frontier=tuple(sorted(following))
        return seen


def component(g,patch):
    adjacent={t:set() for t in patch}
    edges={e:t for t in patch for e in g.boundary(t)}
    for e,t in edges.items():
        if e[::-1] in edges:
            adjacent[t].add(edges[e[::-1]])
    root=patch[0]
    found={root}
    queue=[root]
    for t in queue:
        for u in sorted(adjacent[t]-found):
            found.add(u)
            queue.append(u)
    return found


def macro_offers(inv,edge,frontier):
    anchor,b=edge
    proposals=[]
    for local in inv.macros.get(sub(b,anchor),()):
        patch=tuple(inv.g.shift(t,anchor) for t in local)
        shell=inv.placed_boundary(local,anchor)
        matches=sum(e[::-1] in frontier for e in shell)
        assert matches
        proposals.append((-matches,-len(patch),patch))
    return [patch for _,_,patch in sorted(proposals)[:6]]


def solve(core,inventory,seed,case,bank=None,*,cap,node_limit=3000,pool_limit=4000,order="cluster",
          initial=(),cavities=None,inspect=6,first_port=None):
    g=core.g
    region=core.region
    assert region.exterior(seed) is None
    max_tiles=min(cap,core.counts_area())
    assert max_tiles>=1
    stats=Counter()
    pool=CandidatePool(region,inventory,seed,max_tiles,pool_limit,stats)
    visited=set()
    steps=[]

    def test(t,occ):
        stats["placement_checks"]+=1
        return region.block(t,occ)

    def valid_macro(patch,occ):
        return all(test(t,occ) is None for t in patch)

    def visit(path,occ,remainder):
        stats["nodes"]+=1
        if stats["nodes"]>node_limit:
            raise TimeoutError
        signature=frozenset(path)
        if signature in visited:
            stats["duplicate_states"]+=1
            return None
        visited.add(signature)
        anchored=component(g,path)
        if not remainder and len(anchored)==len(path):
            return path,tuple(steps)
        if len(path)>=max_tiles:
            return None
        frontier=chain(g,path)
        if cavities is not None and cavities.cut(region,core,frontier,path,case,stats):
            return None
        forced=[e[::-1] for e in sorted(frontier) if core.forces(e)]
        if first_port is not None and len(path)==1+len(initial):
            assert first_port in forced
            forced.remove(first_port)
            forced.insert(0,first_port)
        if forced:
            if bank and any(bank.find(region,e,occ,case,path,stats) for e in forced):
                return None
            options=None
            for e in forced[:inspect]:
                candidates=inventory.at(e)
                blockers=[test(t,occ) for t, in candidates]
                eligible=[p for p,w in zip(candidates,blockers,strict=True) if w is None]
                if not eligible:
                    if bank:
                        bank.learn(region,e,blockers,candidates,occ,case,path)
                    return None
                if options is None or len(eligible)<len(options[1]):
                    options=e,eligible
                if len(eligible)==1:
                    break
            e,units=options
            offers=macro_offers(inventory,e,frontier)
            macros=[p for p in offers if len(path)+len(p)<=max_tiles]
            stats["cluster_offers"]+=len(macros)
            if order=="cluster":
                branches=macros+units
            else:
                assert order=="single"
                branches=units+macros
            reason="forced-edge"
        elif remainder:
            # This point is interior to a remaining positive-area convex piece.
            poly=remainder[0]
            q=center(poly)
            branches=[]
            for t in pool.all():
                if t in signature or not core.contains(t,q):
                    continue
                if test(t,occ) is None and any(sign(intersection(poly,p))>0 for p in core.pieces(t)):
                    branches.append((t,))
            stats["interior_queries"]+=1
            reason="interior-point"
            e=None
        else:
            # Any connected completion adds a tile across this component's boundary.
            candidates={p for edge in chain(g,sorted(anchored)) for p in inventory.at(edge[::-1])}
            branches=[p for p in sorted(candidates) if test(p[0],occ) is None]
            stats["bridge_queries"]+=1
            reason="connect"
            e=None
        for patch in branches:
            if len(patch)>1:
                if not valid_macro(patch,occ):
                    continue
                stats["cluster_moves"]+=1
            new=core.subtract(remainder,patch) if remainder else ()
            stats["branches"]+=1
            steps.append(dict(kind=reason,edge=e,patch=patch))
            solution=visit((*path,*patch),region.extend(occ,patch),new)
            if solution is not None:
                return solution
            steps.pop()
        return None

    try:
        path=(seed,*initial)
        assert len(path)<=max_tiles
        occupied=frozenset()
        for tile in path:
            assert region.block(tile,occupied) is None
            occupied=region.extend(occupied,(tile,))
        result=visit(path,occupied,core.subtract(core.polygons,path))
    except (PoolLimit,TimeoutError) as e:
        return dict(status="BOUNDED",reason=type(e).__name__,counts=dict(stats),max_tiles=max_tiles)
    if result is None:
        return dict(status="NEGATIVE",counts=dict(stats),max_tiles=max_tiles)
    patch,moves=result
    return dict(status="POSITIVE",counts=dict(stats),max_tiles=max_tiles,patch=patch,moves=moves,
                boundary=sorted(chain(g,patch)),areas=core.receipt(patch))


def verify(core,seed,patch,areas,boundary,cap):
    assert patch[0]==seed and len(patch)==len(set(patch)) and len(patch)<=cap
    g=core.g
    region=core.region
    assert len(component(g,patch))==len(patch)
    assert chain(g,patch)==frozenset(boundary)
    assert all(region.exterior(t) is None for t in patch)
    if g.kind=="penrose":
        assert all(independent.contact(a,b) for a,b in combinations(patch,2))
    else:
        seen=set()
        for t in patch:
            sites=g.sites(t)
            assert seen.isdisjoint(sites)
            seen.update(sites)
    assert areas==core.receipt(patch)
