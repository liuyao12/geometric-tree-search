"""Build fixed and movable boundary cases from exact rhomb placements."""
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region
from cases_v1 import frozen, patch_ring, rhomb_grid
from check_v1 import contact
from clipping_v1 import Core
from geometry_v1 import Penrose, add, chain, mul, pairs, sub
from model_v1 import DIRECTIONS, ZERO, rhomb, rotate
from open_cases_v1 import seam_core
from open_cover_v1 import component


def belt(g,cols,levels):
    tiles=[]
    origin=ZERO
    for direction in levels:
        tiles.extend(rhomb(add(origin,mul(i,DIRECTIONS[0])),0,direction) for i in range(cols))
        origin=add(origin,DIRECTIONS[direction])
    rings=patch_ring(g,tuple(tiles))
    assert rings is not None
    return rings,tuple(tiles)


def move(g,patch,turn,delta):
    return tuple(g.shift(g.turn(t,turn),delta) for t in patch)


def move_cycle(cycle,turn,delta):
    return tuple(add(rotate(p,turn),delta) for p in cycle)


def expanded(cycle):
    # Dilate about the exact centroid by a factor of seventeen sixteenths.
    n=len(cycle)
    total=tuple(map(sum,zip(*cycle)))
    return 16*n,tuple(sub(mul(17*n,p),total) for p in cycle)


def hull(g,points):
    def project(p):
        # Order by two independent exact projections.
        return g.cross(g.unit,p),g.cross(g.transverse,p)
    from functools import cmp_to_key
    def compare(p,q):
        u,v=project(p)
        a,b=project(q)
        return g.sign(sub(u,a)) or g.sign(sub(v,b))
    ranked=sorted(set(points),key=cmp_to_key(compare))
    def half(sequence):
        answer=[]
        for p in sequence:
            while len(answer)>=2 and g.sign(g.cross(sub(answer[-1],answer[-2]),sub(p,answer[-1])))<=0:
                answer.pop()
            answer.append(p)
        return answer[:-1]
    return tuple(half(ranked)+half(reversed(ranked)))


def n_components(g,patch):
    todo=set(patch)
    n=0
    while todo:
        todo-=component(g,tuple(sorted(todo)))
        n+=1
    return n


def connect(g,inv,patch,cycle):
    forbidden={(b,a) for a,b in pairs(cycle)}
    while n_components(g,patch)>1:
        old=n_components(g,patch)
        choices={t for e in chain(g,patch)-forbidden for t, in inv.at(e[::-1])
                 if t not in patch and all(contact(t,u) for u in patch)}
        rank,tile=min((n_components(g,(*patch,t)),t) for t in choices)
        assert rank<old
        patch=(*patch,tile)
    return patch


def location(g,rings,patch,turn):
    envelope=Region(g,rings)
    # Try a deterministic finite set of lattice offsets around the center of the envelope.
    center=tuple(map(sum,zip(*rings[0])))
    scale=len(rings[0])
    preferred=tuple(v//scale for v in center)
    offsets=[preferred]
    offsets.extend(add(preferred,(a,b,c,d)) for a in range(-2,3) for b in range(-2,3)
                   for c in range(-2,3) for d in range(-2,3))
    for delta in offsets:
        placed=move(g,patch,turn,delta)
        if all(envelope.exterior(t) is None for t in placed):
            return delta
    raise ValueError("No legal location for seed")


def main():
    data=json.loads((ROOT/"data/cavity-pilot-v1.json").read_text())
    pilot=data["witness"]
    frame=frozen(pilot["patches"][0])
    cycle=frozen(pilot["cavities"][0])
    g=Penrose()
    inv=Inventory(g)
    linked=connect(g,inv,frame,cycle)
    fixtures=[]
    for i,(cols,levels,turn) in enumerate((
        (7,(1,2,1,2,1,2,1),0),(8,(2,1,2,1,2,1,2),3),
        (7,(2,2,1,1,2,2,1,1),6),(8,(1,2,2,1,2,1,2),8)
    )):
        envelope,_=belt(g,cols,levels)
        delta=location(g,envelope,linked,turn)
        translated=move(g,linked,turn,delta)
        boundary=move_cycle(cycle,turn,delta)
        fixtures.append(dict(id=f"fixed-sealed-{i}",mode="fixed",kind="sealed",envelope=envelope,
                             seed=translated[:5],expected="NEGATIVE",cycle=boundary))
        core=(expanded(boundary),)
        fixtures.append(dict(id=f"moving-sealed-{i}",mode="movable",kind="sealed",envelope=envelope,
                             core=core,seed=translated,cap=len(translated)+4,expected="NEGATIVE",cycle=boundary))
        if i:
            proposals=[]
            for j,tile in enumerate(translated[:5]):
                seed=tuple(t for t in translated if t!=tile)
                exposed=chain(g,seed)
                proposals.extend((j,e,seed) for e in g.boundary(tile) if e[::-1] in exposed)
            j,port,open_seed=proposals[(i-1)%len(proposals)]
            bigger=(expanded(hull(g,(*boundary,*translated[j]))),)
            fixtures.append(dict(id=f"moving-open-{i}",mode="movable",kind="open-prefix",envelope=envelope,
                                 core=bigger,seed=open_seed,cap=len(translated)+3,cycle=boundary,port=port))
            fixtures.append(dict(id=f"fixed-open-{i}",mode="fixed",kind="open-prefix",envelope=envelope,
                                 seed=open_seed,cycle=boundary,port=port))
    envelope,_=belt(g,7,(1,2,1,2,1,2,1))
    delta=location(g,envelope,linked,0)
    placed=move(g,linked,0,delta)
    boundary=move_cycle(cycle,0,delta)
    region=Region(g,envelope)
    ring_edges={(b,a) for a,b in pairs(boundary)}
    for e in sorted(chain(g,placed)-ring_edges):
        if not any(region.block(t,frozenset(placed)) is None for t, in inv.at(e[::-1])):
            continue
        core=(seam_core(g,envelope,e,(Fraction(1,16),)),)
        fixtures.append(dict(id="moving-optional-hole",mode="movable",kind="optional",envelope=envelope,
                             core=core,seed=placed,cap=len(placed)+1,expected="POSITIVE",cycle=boundary))
        break
    for size in (3,4,5):
        full=rhomb_grid(size,size,width=1 if size%2 else 2)
        target=patch_ring(g,full)
        inner=full[size+1]
        seed=tuple(t for t in full if t!=inner)
        fixtures.append(dict(id=f"fixed-fillable-{size}",mode="fixed",kind="fillable",envelope=target,
                             seed=seed,expected="POSITIVE",cycle=g.poly(inner)))
        envelope,_=belt(g,8,(1,2,1,2,1,2,1,2))
        delta=location(g,envelope,full,0)
        placed=move(g,seed,0,delta)
        boundary=move_cycle(g.poly(inner),0,delta)
        fixtures.append(dict(id=f"moving-fillable-{size}",mode="movable",kind="fillable",envelope=envelope,
                             core=(expanded(boundary),),seed=placed,cap=len(placed)+2,expected="POSITIVE",
                             cycle=boundary))
    for i,turn in enumerate((1,4,7)):
        record=data["alternative"]["examples"][i]
        cavity=frozen(record["cycle"])
        cluster=connect(g,inv,frozen(record["patch"]),cavity)
        envelope,_=belt(g,7+i,(1,2,1,2,1,2,1))
        delta=location(g,envelope,cluster,turn)
        placed=move(g,cluster,turn,delta)
        boundary=move_cycle(cavity,turn,delta)
        fixtures.append(dict(id=f"fixed-concave-{i}",mode="fixed",kind="sealed",envelope=envelope,
                             seed=placed,expected="NEGATIVE",cycle=boundary))
        fixtures.append(dict(id=f"moving-concave-{i}",mode="movable",kind="sealed",envelope=envelope,
                             core=(expanded(hull(g,boundary)),),seed=placed,cap=len(placed)+4,
                             expected="NEGATIVE",cycle=boundary))
    assert len(fixtures)==27
    for row in fixtures:
        region=Region(g,row["envelope"])
        assert all(region.exterior(t) is None for t in row["seed"])
        assert all(contact(a,b) for a,b in combinations(row["seed"],2))
        if row["mode"]=="movable":
            Core(region,row["core"])
    (ROOT/"input/cavity-cases-v1.json").write_text(json.dumps(fixtures,sort_keys=True,separators=(",",":"))+"\n")
    print("prepared",len(fixtures),"fixed and movable queries",flush=True)


if __name__=="__main__":
    main()
