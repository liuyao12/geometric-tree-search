"""Compose two symbolic recipe outputs and retain a primitive replay."""

from lifted_recipe_v1 import Recipe,check_symbolic,mapped,order,rewrite,unify,variables


def combine(first,second,functions,step_cap):
    a,b=len(first.leaves),len(second.leaves)
    m,n=len(first.steps),len(second.steps)
    if m+n+1>step_cap:
        return
    lnames={v:f"?L{i}" for i,(v,_) in enumerate(first.types)}
    rnames={v:f"?R{i}" for i,(v,_) in enumerate(second.types)}
    types={**{lnames[v]:s for v,s in first.types},**{rnames[v]:s for v,s in second.types}}
    left=mapped(first.output,lnames)
    right=mapped(second.output,rnames)
    for yes,p in left:
        if not yes:
            continue
        for sign,q in right:
            if sign or p[0]!=q[0]:
                continue
            binding={}
            if not unify(p[1:],q[1:],binding,types,functions):
                continue
            pivot=rewrite(p,binding)
            leaves=tuple(mapped(mapped(r,names),binding) for recipe,names in
                         ((first,lnames),(second,rnames)) for r in recipe.leaves)
            l,r=set(mapped(left,binding)),set(mapped(right,binding))
            out=order((l-{(True,pivot)})|(r-{(False,pivot)}))
            if not out or any((not s,t) in out for s,t in out):
                continue
            steps=[]
            for recipe,names,leaf_offset,step_offset in ((first,lnames,0,0),(second,rnames,a,m)):
                def relocate(i):
                    return i+leaf_offset if i<len(recipe.leaves) else a+b+step_offset+i-len(recipe.leaves)
                for i,j,term,row in recipe.steps:
                    steps.append((relocate(i),relocate(j),rewrite(rewrite(term,names),binding),
                                  mapped(mapped(row,names),binding)))
            steps.append((a+b+m-1,a+b+m+n-1,pivot,out))
            free=sorted(set().union(*(variables(t) for row in leaves for _,t in row)))
            names={v:f"?p{i}" for i,v in enumerate(free)}
            recipe=Recipe(tuple((names[v],types[v]) for v in free),
                          tuple(mapped(row,names) for row in leaves),
                          tuple((i,j,rewrite(p,names),mapped(r,names)) for i,j,p,r in steps))
            if check_symbolic(recipe):
                yield recipe
