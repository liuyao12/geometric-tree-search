"""Compare typed unification constraints with exhaustive finite assignments."""

from itertools import product
from pathlib import Path
import random
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from lifted_recipe_v1 import rewrite,unify
from serial_blocks_v1 import prop


def main():
    rng=random.Random(20261106)
    types={"?x":"Nat","?y":"Nat","?p":"Point","?q":"Point"}
    functions={"a":[[],"Nat"],"b":[[],"Nat"],"S":[["Nat"],"Nat"],
               "p":[[],"Point"],"q":[[],"Point"]}
    terms={"Nat":[("a",),("b",),("S",("a",)),("S",("b",)),("S",("S",("a",))),("S",("S",("b",)))],
           "Point":[("p",),("q",)]}
    choices=[*types,*terms["Nat"],*terms["Point"],("S","?x"),("S","?y"),("S",("S","?x"))]
    assignments=[dict(zip(types,values,strict=True)) for values in product(*(terms[s] for s in types.values()))]
    accepted=nonempty=0
    for _ in range(600):
        equations=[(rng.choice(choices),rng.choice(choices)) for _ in range(rng.randint(1,4))]
        l,r=map(tuple,zip(*equations,strict=True))
        result={}
        okay=unify(l,r,result,types,functions)
        accepted+=okay
        exact=[env for env in assignments if all(rewrite(a,env)==rewrite(b,env) for a,b in equations)]
        observed=[env for env in assignments if all(rewrite(v,env)==rewrite(t,env)
                  for v,t in result.items())] if okay else []
        assert exact==observed
        nonempty+=bool(exact)
    prop.save("data/lifted-qualification-v1.json",dict(status="PASS",systems=600,assignments_per_system=len(assignments),
                                                      unifiable=accepted,solutions_in_window=nonempty))


if __name__=="__main__":
    main()
