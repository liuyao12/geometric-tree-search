"""Compare model-time term attachments with a prepared recipe library."""

from itertools import product
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from context_experiment_v1 import tree
from in_grid_v1 import Prefix
from lifted_experiment_v1 import certificate,lookup
from lifted_recipe_v1 import Recipe,rewrite,verify
from lifted_search_v1 import expand,run
from online_receptors_v1 import Online
from schematic_receivers_v1 import align
from serial_blocks_v1 import catalog,prop


def audit_rejections(chooser,full):
    for k,bindings in chooser.bad:
        a=chooser.matches[k]
        env=dict(bindings)
        domains=chooser.domains
        if any(rewrite(t,env) not in domains[chooser.schema_types[s][v]]
               for s,sub in a["source"] for v,t in sub.items()):
            continue
        ids=chooser.ids
        row_ids=lambda r:{ids[rewrite(p,env)] if sign else -ids[rewrite(p,env)] for sign,p in r}
        try:
            leaves=[row_ids(row) for row in a["leaves"]]
        except KeyError:
            continue
        if any(prop.mask(row) not in full or any(-v in row for v in row) for row in leaves):
            continue
        recipe=chooser.recipes[a["recipe"]]
        bound={v:rewrite(t,env) for v,t in a["binding"].items()}
        def literal(sign,atom):
            i=ids[rewrite(atom,bound)]
            return i if sign else -i
        for i,j,pivot,result in recipe.steps:
            try:
                p=ids[rewrite(pivot,bound)]
                want={literal(s,x) for s,x in result}
            except KeyError:
                break
            if p not in leaves[i] or -p not in leaves[j]:
                break
            joined=(leaves[i]-{p})|(leaves[j]-{-p})
            if want!=joined or any(-v in joined for v in joined):
                break
            leaves.append(joined)
        else:
            raise AssertionError("An independently admissible binding was marked failed")
    return len(chooser.bad)


def main():
    plan=prop.load("online-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    archived=prop.load("prior/lifted-v1.json")
    peano=prop.load("prior/peano-lift-v1.json")
    common=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in archived["recipes"]]
    arithmetic=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in peano["recipes"]]
    cases=[(r["source"],0,common) for r in archived["cases"]]
    cases.extend((r["source"],int(r["id"].removesuffix("-control").rsplit("-",1)[1]),arithmetic)
                 for r in peano["cases"])
    output=[]
    palette=prop.wang.palette()
    for source,depth,recipes in cases:
        s,normal,(functions,predicates,schemas)=lookup(source,5000)
        terms=fol.ground_terms(normal,functions,depth,24)
        atoms=sorted((p,*xs) for p,sorts in predicates.items() for xs in product(*(terms[x] for x in sorts)))
        start=time.monotonic()
        offers,leaves,templates,match=align(recipes,schemas,functions,terms,atoms,plan["match"],symbolic_only=True)
        assert not offers and not leaves
        construction=time.monotonic()-start
        results=[]
        search_objects=[]
        for marked in (False,True):
            chooser=Online(recipes,templates,atoms,terms,schemas,plan["literal_probes"],marked)
            r=run(schemas,terms,atoms,[],"demand",plan["search"],chooser)
            assert r["status"]=="BOUNDED" or (r["status"]=="GROUND_MODEL")==source["id"].endswith("-control")
            search_objects.append((chooser,r))
        # Build the exhaustive bank only after the online search has stopped.
        full=catalog(Prefix(schemas,terms,atoms,[],[]))
        for chooser,r in search_objects:
            assert all(verify(o,chooser.origins) for o in r["active"])
            checked=audit_rejections(chooser,full)
            assert chooser.origins.keys()<=full.keys()
            fol.verify_instances(schemas,list(chooser.origins.values()),[prop.literals(m) for m in chooser.origins],atoms,functions)
            rec=dict(marked=chooser.marked,status=r["status"],counts=r["counts"],online=dict(chooser.stats),
                     activated=len(r["active"]),admitted=len(r["source"]),marks=checked)
            if r["status"]=="REFUTED":
                (origins,premises,proof),_,used=expand(r,chooser.origins)
                prop.verify_resolution(premises,proof)
                reduced=slice_proof(dict(atoms=atoms,origins=origins,premises=premises,proof=proof))
                rec.update(proof=reduced,used=len(used))
                if chooser.marked and source["id"] in plan["export"]:
                    rec["rectangle"],rec["rectangle_file"]=certificate(s,functions,schemas,terms,reduced,palette,
                                                                       f'{source["id"]}-online')
            elif r["status"]=="GROUND_MODEL":
                truth={i if b else -i for i,b in enumerate(r["model"],1)}
                assert all(truth.intersection(prop.literals(m)) for m in full)
            results.append(rec)
        print(json.dumps(dict(id=source["id"],alignments=match["symbolic_alignments"],results=[
            (r["marked"],r["status"],r["activated"],r["counts"].get("decisions",0),
             r["online"].get("checked_bindings",0),r["online"].get("mark_hits",0),r.get("used",0))
             for r in results]),sort_keys=True),flush=True)
        output.append(dict(id=source["id"],match=match,construction=construction,results=results))
    prop.save("data/online-v1.json",output)


if __name__=="__main__":
    main()
