"""Rank violated recipe outputs by their contact with the source frontier."""

from math import log1p
import random

from admission_policy_v1 import logits
from serial_blocks_v1 import prop


LABELS=("new-source","known-source","width","long-recipe","shared-output")
REFERENCE=2


class Selector:
    def __init__(self,atom_count,action=REFERENCE,weights=None,override=None,seed=None):
        self.action=action
        self.weights=weights
        self.override=override
        self.atom_count=atom_count
        self.rng=random.Random(seed) if seed is not None else None
        self.masks={}
        self.trace=[]

    def choose(self,candidates,active,truth,source,additions,counts,quota):
        data=[]
        new_atoms={abs(l) for m in additions for l in prop.literals(m)}
        for offer in candidates:
            if offer.result in active:
                continue
            counts["recipe_checks"]+=1
            if truth.intersection(offer.result):
                continue
            leaves=self.masks.get(offer.leaves)
            if leaves is None:
                leaves=frozenset(prop.mask(row) for row in offer.leaves)
                self.masks[offer.leaves]=leaves
            new=sum(r in additions for r in leaves)/len(leaves)
            seen=sum(r in source for r in leaves)/len(leaves)
            shared=sum(abs(v) in new_atoms for v in offer.result)/len(offer.result)
            data.append((offer,new,seen,shared))
        if not data:
            return []
        x=(1.,min(1.,log1p(len(data))/8),max(r[1] for r in data),
           sum(r[2] for r in data)/len(data),sum(r[3] for r in data)/len(data),
           min(1.,log1p(self.atom_count)/7),sum((a|b).bit_count()>=3 for a,b in additions)/len(additions))
        action=self.action
        if self.weights is not None:
            scores=logits(self.weights,x)
            action=scores.index(max(scores))
        if self.override is not None and len(self.trace)==self.override[0]:
            action=self.override[1]
        self.trace.append(dict(features=x,action=action,eligible=len(data)))
        if self.rng:
            self.rng.shuffle(data)
        elif action!=REFERENCE:
            if action==0:
                key=lambda d:(-d[1],-d[2])
            elif action==1:
                key=lambda d:(-d[2],-d[1])
            elif action==3:
                key=lambda d:-len(d[0].steps)
            else:
                key=lambda d:-d[3]
            data.sort(key=key)
        return [r[0] for r in data[:quota]]
