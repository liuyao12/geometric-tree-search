"""Attach a recipe to complete source schemata before finite instantiation."""

from collections import Counter,defaultdict
from itertools import product

from lifted_recipe_v1 import Recipe,grounded,mapped,rewrite,unify,variables
from serial_blocks_v1 import prop


def profile(row):
    return tuple(sorted((sign,atom[0]) for sign,atom in row))


def align(recipes,schemas,functions,terms,atoms,limits,*,symbolic_only=False):
    profiles=defaultdict(list)
    for schema in schemas:
        profiles[profile(schema["clause"])].append(schema)
    ids={a:i+1 for i,a in enumerate(atoms)}
    domain={s:set(xs) for s,xs in terms.items()}
    stats=Counter()
    origins={}
    placements={}
    matches=[]
    capped=False

    for index,recipe in enumerate(recipes):
        buckets=[profiles[profile(row)] for row in recipe.leaves]
        if any(not bucket for bucket in buckets):
            continue
        order=tuple(sorted(range(len(buckets)),key=lambda i:(len(buckets[i]),i)))

        def emit(env,types,source):
            nonlocal capped
            leaves=tuple(mapped(row,env) for row in recipe.leaves)
            steps=tuple((a,b,rewrite(p,env),mapped(row,env)) for a,b,p,row in recipe.steps)
            by_leaf=[source[i] for i in range(len(leaves))]
            target=[(name,{v:rewrite(t,env) for v,t in substitution.items()})
                    for name,substitution in by_leaf]
            live=sorted(set().union(*(variables(atom) for row in leaves for _,atom in row),
                                   *(variables(t) for _,sub in target for t in sub.values())))
            free=tuple((v,types[v]) for v in live)
            attached=Recipe(free,leaves,steps)
            if len(matches)>=limits["alignments"]:
                capped=True
                return
            stats["symbolic_alignments"]+=1
            metadata=dict(recipe=index,types=free,source=target)
            if symbolic_only:
                metadata.update(leaves=leaves,output=attached.output,
                                binding={v:rewrite(v,env) for v,_ in recipe.types})
            matches.append(metadata)
            if symbolic_only:
                return
            for terms_here in product(*(terms[s] for _,s in free)):
                if stats["bindings"]>=limits["bindings"] or len(placements)>=limits["offers"]:
                    capped=True
                    return
                stats["bindings"]+=1
                ground=dict(zip(live,terms_here,strict=True))
                base={}
                try:
                    for row,(name,sub) in zip(leaves,target,strict=True):
                        m=prop.mask((1 if s else -1)*ids[rewrite(a,ground)] for s,a in row)
                        final={v:rewrite(t,ground) for v,t in sub.items()}
                        if m[0]&m[1] or any(t not in domain[types_for_source[name][v]] for v,t in final.items()):
                            break
                        base[m]=dict(schema=name,substitution=final)
                    else:
                        binding={v:rewrite(v,{**env,**ground}) for v,_ in recipe.types}
                        placement=grounded(recipe,index,binding,ids,base)
                        if placement is not None:
                            # Reject no-op imports of a lemma already present as a source row.
                            if prop.mask(placement.result) not in base:
                                placements.setdefault((placement.result,tuple(sorted(placement.leaves))),placement)
                                origins.update(base)
                            continue
                except KeyError:
                    pass
                stats["ground_rejections"]+=1

        def attach(at,env,types,source):
            nonlocal capped
            if at==len(order):
                emit(env,types,source)
                return
            i=order[at]
            for candidate in buckets[i]:
                change={v:f"?r{i}:{k}" for k,v in enumerate(sorted(candidate["variables"]))}
                joined={**types,**{change[v]:s for v,s in candidate["variables"].items()}}
                ground=mapped(candidate["clause"],change)

                def pair(want,available,bindings):
                    nonlocal capped
                    if not want:
                        attach(at+1,bindings,joined,{**source,i:(candidate["id"],change)})
                        return
                    (s,p),*rest=want
                    for j,(sign,atom) in enumerate(available):
                        if stats["unification_probes"]>=limits["probes"]:
                            capped=True
                            return
                        stats["unification_probes"]+=1
                        if sign!=s or atom[0]!=p[0]:
                            continue
                        current=bindings.copy()
                        if unify(p[1:],atom[1:],current,joined,functions):
                            pair(rest,available[:j]+available[j+1:],current)
                        if capped:
                            return
                pair(recipe.leaves[i],ground,env)
                if capped:
                    return

        types_for_source={s["id"]:s["variables"] for s in schemas}
        attach(0,{},dict(recipe.types),{})
        if capped:
            break
    stats["placements"]=len(placements)
    return list(placements.values()),origins,matches,dict(**stats,complete=not capped)
