"""Give conventional SAT solvers the same independently checked lifted outputs."""

import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from context_experiment_v1 import tree
from in_grid_v1 import Prefix
from lifted_recipe_v1 import Recipe
from recipe_rank_experiment_v1 import world
from serial_blocks_v1 import catalog,prop


def main():
    plan=prop.load("paired-cdcl-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    config=prop.load("protocol-v1.json")
    deps=Path(sys.argv[1])
    assert all(prop.pin(deps/k)==v for k,v in config["pysat_files"].items())
    sys.path.insert(0,str(deps))
    from pysat.solvers import Solver
    original=prop.load("prior/lifted-v1.json")
    peano=prop.load("prior/peano-lift-v1.json")
    common=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in original["recipes"]]
    arithmetic=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in peano["recipes"]]
    cases=[(r["source"],0,common) for r in original["cases"]]
    cases.extend((r["source"],int(r["id"].removesuffix("-control").rsplit("-",1)[1]),arithmetic)
                 for r in peano["cases"])
    output=[]
    for source,depth,recipes in cases:
        w=world(source,depth,recipes,plan)
        full=catalog(Prefix(w["schemas"],w["terms"],w["atoms"],[],[]))
        base=[prop.literals(m) for m in sorted(full) if not m[0]&m[1]]
        exported=sorted({o.result for o in w["offers"] if prop.mask(o.result) not in full})
        results=[]
        for kind in ("glucose4","cadical195"):
            for name,addition in (("cold",[]),("same-library",exported)):
                with Solver(name=kind,bootstrap_with=base+addition) as s:
                    s.conf_budget(plan["conflicts"])
                    outcome=s.solve_limited()
                    counts=s.accum_stats()
                    assert outcome is None or outcome is source["id"].endswith("-control")
                    if outcome is True:
                        values=set(s.get_model())
                        assert all(values.intersection(r) for r in base+addition)
                results.append(dict(solver=kind,arm=name,sat=outcome,counts=counts,imported=len(addition)))
        print(json.dumps(dict(id=source["id"],arms=[(r["solver"],r["arm"],r["counts"]["conflicts"])
                                                   for r in results]),sort_keys=True),flush=True)
        output.append(dict(id=source["id"],base=len(base),results=results))
    prop.save("data/paired-cdcl-v1.json",output)


if __name__=="__main__":
    main()
