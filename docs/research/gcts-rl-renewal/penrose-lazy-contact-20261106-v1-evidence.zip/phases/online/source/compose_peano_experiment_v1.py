"""Test deeper arithmetic proof moves learned by symbolic composition."""

from dataclasses import asdict
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from atom_slice_v1 import slice_proof
from context_experiment_v1 import tree
from lifted_compose_v1 import combine
from lifted_experiment_v1 import certificate
from lifted_recipe_v1 import Recipe,verify
from lifted_search_v1 import expand,run
from peano_lift_v1 import compile_problem,source
from schematic_receivers_v1 import align
from serial_blocks_v1 import prop


def main():
    plan=prop.load("compose-peano-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    previous=prop.load("prior/peano-lift-v1.json")
    base=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in previous["recipes"]]
    _,functions,_,_,_=compile_problem(source(2,donor=True),2,plan)
    libraries=[base]
    layers=[]
    current=base
    for cap in plan["step_caps"]:
        new=[]
        for a in current:
            for b in current:
                for r in combine(a,b,functions,cap):
                    if r not in current and r not in new:
                        new.append(r)
        current=current+new[:plan["library_cap"]]
        libraries.append(current)
        layers.append([asdict(r) for r in new[:plan["library_cap"]]])
    palette=prop.wang.palette()
    reports=[]
    for depth in plan["depths"]:
        original=source(depth)
        s,f,schemas,terms,atoms=compile_problem(original,depth,plan)
        arms=[]
        for index,recipes in enumerate(libraries):
            offers,leaves,_,match=align(recipes,schemas,f,terms,atoms,plan["match"])
            assert all(verify(o,leaves) for o in offers)
            fol.verify_instances(schemas,list(leaves.values()),[prop.literals(r) for r in leaves],atoms,f)
            for mode in ("demand","eager"):
                r=run(schemas,terms,atoms,offers,mode,plan["search"])
                row=dict(library=index,mode=mode,status=r["status"],match=match,counts=r["counts"],
                         activated=len(r["active"]),admitted=len(r["source"]))
                if r["status"]=="REFUTED":
                    (origins,premises,proof),_,used=expand(r,leaves)
                    prop.verify_resolution(premises,proof)
                    out=slice_proof(dict(atoms=atoms,origins=origins,premises=premises,proof=proof))
                    fol.verify_instances(schemas,out["origins"],out["premises"],out["atoms"],f)
                    row.update(proof=out,used=[asdict(o) for o in sorted(used,key=repr)],
                               deepest=max((len(o.steps) for o in used),default=0))
                    if [depth,index,mode] in plan["export"]:
                        row["rectangle"],row["rectangle_file"]=certificate(
                            s,f,schemas,terms,out,palette,f'{original["id"]}-composed-{index}-{mode}')
                arms.append(row)
        print(json.dumps(dict(id=original["id"],arms=[(r["library"],r["mode"],r["status"],
                         r["counts"].get("decisions",0),r.get("deepest",0),r.get("rectangle",{}).get("status"))
                         for r in arms]),sort_keys=True),flush=True)
        reports.append(dict(source=original,arms=arms))
    prop.save("data/compose-peano-v1.json",dict(layers=layers,cases=reports))


if __name__=="__main__":
    main()
