"""Instantiate typed recipe interfaces only when their head falsifies a model."""

from collections import Counter,defaultdict
from itertools import product

from lifted_recipe_v1 import grounded,pmatch,rewrite,variables
from serial_blocks_v1 import prop


class Online:
    def __init__(self,recipes,alignments,atoms,terms,schemas,limit,marked):
        self.recipes=recipes
        self.matches=sorted(alignments,key=lambda r:(len(r["output"]),r["recipe"],repr(r["source"])))
        self.atoms=atoms
        self.terms=terms
        self.domains={s:set(t) for s,t in terms.items()}
        self.schema_types={s["id"]:s["variables"] for s in schemas}
        self.ids={a:i+1 for i,a in enumerate(atoms)}
        self.limit=limit
        self.marked=marked
        self.origins={}
        self.bad=set()
        self.accepted=set()
        self.stats=Counter()

    def materialize(self,alignment,ground):
        base={}
        try:
            for row,(schema,sub) in zip(alignment["leaves"],alignment["source"],strict=True):
                resolved={v:rewrite(t,ground) for v,t in sub.items()}
                if any(t not in self.domains[self.schema_types[schema][v]] for v,t in resolved.items()):
                    return None,{}
                m=prop.mask((1 if s else -1)*self.ids[rewrite(a,ground)] for s,a in row)
                if m[0]&m[1]:
                    return None,{}
                base[m]=dict(schema=schema,substitution=resolved)
            recipe=alignment["recipe"]
            binding={v:rewrite(t,ground) for v,t in alignment["binding"].items()}
            return grounded(self.recipes[recipe],recipe,binding,self.ids,base),base
        except KeyError:
            return None,{}

    def choose(self,candidates,active,truth,source,additions,counts,quota):
        groups=defaultdict(list)
        available=set()
        for i,atom in enumerate(self.atoms,1):
            sign=i not in truth
            groups[sign,atom[0]].append(atom)
            available.add((sign,atom))
        chosen={}
        cap=self.stats["literal_probes"]+self.limit
        bounded=False
        for k,a in enumerate(self.matches):
            types=dict(a["types"])
            literals=sorted(a["output"],key=lambda t:len(groups[t[0],t[1][0]]))

            def join(i,env):
                nonlocal bounded
                if bounded or len(chosen)>=quota:
                    return
                if i==len(literals):
                    missing=sorted(set(types)-env.keys())
                    for terms_here in product(*(self.terms[types[v]] for v in missing)):
                        if len(chosen)>=quota:
                            return
                        ground={**env,**dict(zip(missing,terms_here,strict=True))}
                        signature=(k,tuple(sorted(ground.items())))
                        if signature in self.accepted:
                            continue
                        if self.marked and signature in self.bad:
                            self.stats["mark_hits"]+=1
                            continue
                        self.stats["checked_bindings"]+=1
                        item,base=self.materialize(a,ground)
                        if item is None:
                            self.bad.add(signature)
                            continue
                        assert not truth.intersection(item.result)
                        self.accepted.add(signature)
                        if item.result in active or item.result in chosen:
                            continue
                        self.origins.update(base)
                        chosen[item.result]=item
                    return
                sign,pattern=literals[i]
                partly=rewrite(pattern,env)
                if self.stats["literal_probes"]>=cap:
                    bounded=True
                    return
                if not variables(partly):
                    self.stats["literal_probes"]+=1
                    if (sign,partly) in available:
                        join(i+1,env)
                    return
                for atom in groups[sign,pattern[0]]:
                    if self.stats["literal_probes"]>=cap:
                        bounded=True
                        return
                    self.stats["literal_probes"]+=1
                    new=env.copy()
                    if pmatch(pattern,atom,new) and all(t in self.domains[types[v]] for v,t in new.items()):
                        join(i+1,new)
                    if len(chosen)>=quota or bounded:
                        return
            join(0,{})
            if len(chosen)>=quota or bounded:
                break
        self.stats["bounded_turns"]+=bounded
        return list(chosen.values())
