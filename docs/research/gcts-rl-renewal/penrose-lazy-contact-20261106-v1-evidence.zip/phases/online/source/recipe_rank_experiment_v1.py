"""Train a model-triggered receptor ranking policy on separate sources."""

from collections import Counter
from itertools import product
import json
from math import log1p
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import herbrand_v1 as fol
from admission_policy_v1 import initial,train
from atom_slice_v1 import slice_proof
from context_experiment_v1 import tree
from in_grid_v1 import Prefix
from lifted_cases_v1 import family,geometry
from lifted_experiment_v1 import certificate,lookup
from lifted_recipe_v1 import Recipe,verify
from lifted_search_v1 import expand,run
from peano_lift_v1 import source as peano_source
from recipe_rank_v1 import LABELS,REFERENCE,Selector
from schematic_receivers_v1 import align
from serial_blocks_v1 import catalog,prop


def world(original,depth,recipes,plan):
    s,c,(f,pred,schemas)=lookup(original,5000)
    terms=fol.ground_terms(c,f,depth,24)
    atoms=sorted((p,*xs) for p,sorts in pred.items() for xs in product(*(terms[x] for x in sorts)))
    offers,leaves,_,work=align(recipes,schemas,f,terms,atoms,plan["match"])
    assert all(verify(o,leaves) for o in offers)
    fol.verify_instances(schemas,list(leaves.values()),[prop.literals(r) for r in leaves],atoms,f)
    return dict(source=s,functions=f,schemas=schemas,terms=terms,atoms=atoms,offers=offers,leaves=leaves,work=work)


def trial(w,plan,mode="demand",**config):
    selector=Selector(len(w["atoms"]),**config) if config else None
    r=run(w["schemas"],w["terms"],w["atoms"],w["offers"],mode,plan["search"],selector)
    c=r["counts"]
    cost=c.get("decisions",0)+4*c.get("conflicts",0)+len(r["active"])+(c.get("recipe_checks",0)+63)//64
    return r,cost,selector.trace if selector else []


def main():
    plan=prop.load("recipe-rank-protocol-v1.json")
    assert prop.pin(Path(sys.executable))==plan["runtime"]
    assert all(prop.pin(Path(k))==digest for k,digest in plan["pins"].items())
    original=prop.load("prior/lifted-v1.json")
    peano=prop.load("prior/peano-lift-v1.json")
    common=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in original["recipes"]]
    arithmetic=[Recipe(*(tree(r[k]) for k in ("types","leaves","steps"))) for r in peano["recipes"]]
    axiom=prop.load("prior/hilbert-slice-input-v1.json")["source"]["premises"][0]
    training=[]
    samples=[]
    for task,size,control in plan["train"]:
        if task=="family":
            s=family(size,broken=control,branch=True)
            recipes,depth=common,0
        elif task=="geometry":
            s=geometry(axiom,size,broken=control)
            recipes,depth=common,0
        else:
            s=peano_source(size,control=control)
            recipes,depth=arithmetic,size
        w=world(s,depth,recipes,plan)
        expected="GROUND_MODEL" if control else "REFUTED"
        ref,cost,trace=trial(w,plan,action=REFERENCE)
        subset=[]
        for i in sorted({0,len(trace)//2}) if trace else ():
            choices=[]
            for a in range(len(LABELS)):
                if a==REFERENCE:
                    r,effort=ref,cost
                else:
                    r,effort,path=trial(w,plan,action=REFERENCE,override=(i,a))
                    assert path[i]["features"]==trace[i]["features"]
                choices.append(dict(outcome=r["status"],work=effort))
            best=min((x["work"] for x in choices if x["outcome"]==expected),default=None)
            if best is not None:
                rewards=[max(-3.,log1p(best)-log1p(x["work"])) if x["outcome"]==expected else -3. for x in choices]
                subset.append(dict(features=trace[i]["features"],choices=choices,rewards=rewards))
        training.append(dict(id=s["id"],outcome=ref["status"],reference=cost,samples=subset))
        samples.extend(subset)
    assert samples
    weights,epochs=train(samples,*plan["policy"])
    holdouts=[(r["source"],0,common) for r in original["cases"]]
    holdouts.extend((r["source"],int(r["id"].removesuffix("-control").rsplit("-",1)[1]),arithmetic)
                    for r in peano["cases"])
    palette=prop.wang.palette()
    reports=[]
    for s,depth,recipes in holdouts:
        w=world(s,depth,recipes,plan)
        expected="GROUND_MODEL" if s["id"].endswith("-control") else "REFUTED"
        arms=[(label,"demand",dict(action=i)) for i,label in enumerate(LABELS)]
        arms += [("plain","demand",{}),("eager","eager",{}),("initial","demand",dict(weights=initial())),
                 ("learned","demand",dict(weights=weights)),("random","demand",dict(action=REFERENCE,seed=977))]
        out=[]
        for arm,mode,settings in arms:
            r,cost,trace=trial(w,plan,mode,**settings)
            assert r["status"] in {expected,"BOUNDED"}
            item=dict(arm=arm,status=r["status"],work=cost,counts=r["counts"],
                      actions=dict(Counter(t["action"] for t in trace)),activated=len(r["active"]))
            if r["status"]=="REFUTED":
                (origins,premises,proof),_,used=expand(r,w["leaves"])
                prop.verify_resolution(premises,proof)
                item["used"]=len(used)
                if arm=="learned" and s["id"] in plan["export"]:
                    reduced=slice_proof(dict(atoms=w["atoms"],origins=origins,premises=premises,proof=proof))
                    item["rectangle"],item["rectangle_file"]=certificate(w["source"],w["functions"],w["schemas"],
                                  w["terms"],reduced,palette,f'{s["id"]}-learned-ranking')
            if r["status"]=="GROUND_MODEL":
                b=catalog(Prefix(w["schemas"],w["terms"],w["atoms"],[],[]))
                truth={i if bit else -i for i,bit in enumerate(r["model"],1)}
                assert all(truth.intersection(prop.literals(row)) for row in b)
            out.append(item)
        reports.append(dict(id=s["id"],arms=out,matching=w["work"]))
        print(json.dumps(dict(id=s["id"],arms=[(r["arm"],r["work"],r["actions"],r.get("used",0)) for r in out]),
                         sort_keys=True),flush=True)
    prop.save("data/recipe-rank-v1.json",dict(training=training,epochs=epochs,weights=weights,cases=reports))


if __name__=="__main__":
    main()
