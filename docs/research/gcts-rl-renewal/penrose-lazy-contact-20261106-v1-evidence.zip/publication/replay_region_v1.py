"""Copy frozen inputs and replay a selected phase in an empty directory."""

import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PHASES = {
    "targets": ("", "geometry", "penrose_lazy_experiment", "wang-protocol-v1.json"),
    "polygons": ("", "polygon", "polygon_experiment", "wang-protocol-v1.json"),
    "seed-pair": ("", "polygon-pair", "polygon_pair", "wang-protocol-v1.json"),
    "composition": ("phases/ranking", "compose-peano", "compose_peano_experiment", ""),
    "ranking": ("phases/ranking", "recipe-rank", "recipe_rank_experiment", ""),
    "conventional": ("phases/ranking", "paired-cdcl", "paired_cdcl", "protocol-v1.json"),
    "online": ("phases/online", "online", "online_experiment", ""),
}


def main():
    phase, destination, *dependencies = sys.argv[1:]
    location, config, source, dependency_pin = PHASES[phase]
    archived = ROOT / location
    target = Path(destination).resolve() / phase
    assert len(dependencies) == bool(dependency_pin)
    target.mkdir(parents=True)
    (target / "data").mkdir()
    config += "-protocol-v1.json"
    spec = json.loads((archived / config).read_bytes())
    names = {config, *spec["pins"]}
    if dependency_pin:
        names.add(dependency_pin)
    for name in names:
        relative = Path(name)
        assert not relative.is_absolute() and ".." not in relative.parts
        (target / relative).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(archived / relative, target / relative)
    subprocess.run([sys.executable, "-I", "-S", "-B", str(target / "source" / (source + "_v1.py")),
                    *[str(Path(p).resolve()) for p in dependencies]], cwd=target, check=True)


if __name__ == "__main__":
    main()
