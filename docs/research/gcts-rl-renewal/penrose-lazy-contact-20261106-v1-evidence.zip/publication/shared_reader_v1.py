"""Render checked conclusion-side search and the ground-resolution control."""

import gzip
from html import escape
import json
import math as numeric
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "publication"))
from proof_presentation import STYLE, TITLES, atom, clause, formula, load, math, strip, term, wang

STEM = "fixed-wang-serial-suffix-20261105-v1"
OLD = "fixed-wang-open-benchmark-20261105-v1.html"


def title(name):
    return TITLES.get(name, {
        "tptp-tutorial-family": "TPTP family theorem",
        "tptp-tutorial-capital": "TPTP capital theorem",
        "tptp-tutorial-family-mutation": "Mutated family statement",
        "quantifier-swap-control": "Quantifier order control",
        "forged-source-clause": "Forged-source control",
        "odd-cycle-5": "A five-cycle has no two-coloring",
        "odd-cycle-7": "A seven-cycle has no two-coloring",
        "pigeonhole-4-3": "Four pigeons cannot occupy three distinct holes",
        "pigeonhole-5-4-fresh": "Five pigeons cannot occupy four distinct holes",
        "agatha-vampire-guide": "Who killed Agatha?",
        "odd-cycle-11-fresh": "An eleven-cycle has no two-coloring",
        "odd-cycle-13-fresh": "A thirteen-cycle has no two-coloring",
        "peano-iterated-injectivity-donor": "Peano arithmetic · Injectivity of two successors",
        "peano-successor-injectivity-4": "Peano arithmetic · Equality after four successors",
        "incidence-branch-2": "Hilbert geometry · Incidence with two choices",
        "family-branch-5": "Family logic · Five layers of alternatives",
    }.get(name, name))


def table(head, rows):
    columns = "".join(f'<th scope="col">{escape(c)}</th>' for c in head)
    contents = "".join("<tr>" + "".join(f"<td>{escape(str(c))}</td>" for c in row) + "</tr>" for row in rows)
    return f'<div class="scroll"><table><thead><tr>{columns}</tr></thead><tbody>{contents}</tbody></table></div>'


def panel(row, original, filename, method):
    proof = row["proof"]
    with gzip.open(ROOT / filename, "rt") as stream:
        saved = json.load(stream)
    circuit, certificate = saved["circuit"], saved["certificate"]
    palette = wang.palette()
    lines = []
    for i, (premise, origin) in enumerate(zip(proof["premises"], proof["origins"], strict=True)):
        terms = ", ".join(math(term(var) + r"\mapsto " + term(value))
                          for var, value in sorted(origin["substitution"].items()))
        reading = f'Source <code>{escape(origin["schema"])}</code>'
        if terms:
            reading += " with " + terms
        lines.append((premise, reading + ".", f"premise{i}:positive"))
    for i, step in enumerate(proof["proof"]):
        reading = f'Resolve lines {step["left"] + 1} and {step["right"] + 1} on '
        reading += math(atom(proof["atoms"][step["pivot"] - 1])) + "."
        lines.append((step["clause"], reading, f"line{i}:"))
    body = "".join(
        f'<tr><th scope="row">{i}</th><td><div class="scroll clause">{math(clause(c, proof["atoms"]))}</div>'
        f'<div class="scroll">{reading}</div>'
        f'<details><summary>Show associated Wang squares</summary>{strip(circuit, certificate, field, palette)}'
        f'</details></td></tr>' for i, (c, reading, field) in enumerate(lines, 1))
    given = "".join(f'<li><div class="scroll">{math(formula(p))}</div></li>' for p in original["premises"])
    name = row["id"]
    return f"""<article class="proof" id="case-{name}"><h3>{escape(title(name))}</h3>
<p>{escape(method)}</p><details><summary>Read the input premises</summary><ol>{given}</ol></details>
<p><strong>Conclusion</strong></p><div class="scroll">{math(formula(original["goal"]))}</div>
<table class="proof-table"><thead><tr><th>Line</th><th>Clause, reading and squares</th></tr></thead>
<tbody>{body}</tbody></table></article>"""


def layer_chart(counts):
    bars = []
    for i, count in enumerate(counts):
        x = 35 + 121 * i
        height = 10 + 18 * numeric.log(count, 2)
        y = 254 - height
        bars.append(f'<rect x="{x}" y="{y:.1f}" width="70" height="{height:.1f}" rx="4" fill="#6277a4"></rect>'
                    f'<text x="{x + 35}" y="{y - 8:.1f}">{count:,}</text>'
                    f'<text x="{x + 35}" y="276">{i}</text>')
    return ('<svg viewBox="0 0 600 300" role="img" aria-labelledby="layers-title" class="layers">'
            '<title id="layers-title">Exact TPTP family suffix states by steps from contradiction</title>'
            '<g text-anchor="middle" font-size="16" fill="#1e382f">' + "".join(bars) +
            '<text x="300" y="296">Resolution steps to contradiction</text></g></svg>')


def main():
    originals = {r["id"]: r for r in load("input/cases-v1.json") + load("input/new-cases-v1.json") +
                 load("input/tutorial-cases-v1.json")["cases"]}
    ground = {r["id"]: r for r in load("data/ground-control-v1.json")}
    sweeps = {k: {r["id"]: r for r in load(f"{'sweep-' + str(k) + '/' if k != 3 else ''}data/suffix-v1.json")}
              for k in (3, 4, 5, 6)}
    prior = {r["id"]: r for r in load("data/prior-blocks-v1.json")}
    hilbert = "hilbert-incidence-uniqueness"
    family = "tptp-tutorial-family"
    capital = "tptp-tutorial-capital"
    assert all(sum(r["status"] == "SAT" for r in sweeps[k].values()) == (7 if k == 3 else 8) for k in sweeps)
    assert sum(r["status"] == "REFUTED" and r["method"] == "unit" and r["rectangle"]["status"] == "VERIFIED"
               for r in ground.values()) == 9
    assert sum(r["status"] == "GROUND_MODEL" for r in ground.values()) == 3
    choices = (family, capital, hilbert)
    panels = [
        panel(sweeps[4][family], originals[family], f"sweep-4/data/{family}-suffix-wang-v1.json.gz",
              "The two searches met with four resolutions left. The clause choices and instantiations were open."),
        panel(ground[capital], originals[capital], f"data/{capital}-ground-control-v1.json.gz",
              "Ground unit propagation found the derivation. Its size set the rectangle dimensions."),
        panel(sweeps[4][hilbert], originals[hilbert], f"sweep-4/data/{hilbert}-suffix-wang-v1.json.gz",
              "The two searches met with four resolutions left. The clause choices and instantiations were open."),
    ]
    menu = "".join(f'<option value="{n}">{escape(title(n))}</option>' for n in choices)
    results = []
    for name in (hilbert, family):
        baseline = next(r for r in prior[name]["results"] if r["mode"] == "block-marked")
        results.append([title(name), "Forward only", 0, baseline["status"], baseline["counts"]["nodes"], 0])
        for cap, values in sweeps.items():
            r = values[name]
            results.append([title(name), cap, len(r["layers"]) - 1, r["status"],
                            r["counts"]["nodes"], r["candidates"]])
    ground_rows = [[title(n), "Unit propagation" if r["method"] == "unit" else "Glucose",
                    r["status"], r.get("discovered_layout", {}).get("premises", "—"),
                    r.get("discovered_layout", {}).get("resolutions", "—")] for n, r in ground.items()]
    rule = math(r"C=(R\setminus Q)\cup S\cup\{\bar\ell\}")
    page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Meet in the middle in a Wang proof</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.layers{{display:block;max-width:680px;width:100%;margin-inline:auto}}
figure{{margin-inline:0}}figcaption{{color:#3e5b50;text-align:center}}
.proof-table{{table-layout:fixed}}
.proof-table tr>:first-child{{width:3.15rem}}
.clause{{font-size:1.04rem;margin-bottom:.35rem}}
.proof-table .strip{{overflow:auto}}
</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · Conclusion-side marks · November 2026</p>
<h1>Meet in the middle in a Wang proof</h1>
<p>Exact continuation marks let the search join a partly built proof to a derivation from the conclusion side.
The family theorem reaches a checked Wang rectangle in the four-step join. On this same bank, conventional ground unit propagation finds all nine positive proofs.</p>
<nav aria-label="On this page"><a href="#reader">Proof lines</a><a href="#layers">Conclusion-side marks</a>
<a href="#control">Ground control</a><a href="#evidence">Evidence</a></nav>
<p><a href="{OLD}">Open Wang benchmark and the original forward searches</a></p></header>
<section id="reader"><h2>Read the proof lines</h2>
<p>Expand a line to see squares in the machine row that reads the proof fields. Each square keeps its orientation.</p>
<p><label>Statement <select id="case-menu">{menu}</select></label></p>{''.join(panels)}</section>
<section id="layers"><h2>Build an exact continuation inventory</h2>
<p>Start at the empty clause and enumerate its predecessors. At a target clause {math("R")}, take any admitted premise
{math("P")} and a pivot literal {math(r"\ell")} in it. The residual premise {math(r"Q=P\setminus\{\ell\}")}
must lie in {math("R")}. Every predecessor has form {rule} with {math(r"S\subseteq Q\setminus\{\bar\ell\}")}.
The complementary pivot {math(r"\bar\ell")} cannot lie in {math(r"R\setminus Q")}. Enumerating these choices
gives every legal non-tautological predecessor. With {math("k")} rows left, an active clause may have at most {math("k")} literals,
since each row can remove at most one.</p>
<figure>{layer_chart(sweeps[4][family]["layers"])}<figcaption>Family theorem continuation inventory. Bar height uses a logarithmic scale.</figcaption></figure>
<p>A completed layer is a boundary condition. If a forward state is absent from the layer for its remaining row count, that branch is exhausted.
A present state carries a checked continuation. If a layer reaches its work cap, the solver uses the last complete layer.</p>
{table(["Statement", "Requested depth", "Completed depth", "Outcome", "Forward nodes", "Backward candidates"], results)}
<p>Forward nodes and backward candidates measure different operations. Every arm uses the same serial clause moves and a 120,000-node forward cap.
The backward pass can consider up to 120,000 predecessor candidates. A second implementation recomputed all completed layers and checked every recorded mark.
A separate forward enumeration agreed on 512 layers across 128 small clause banks.</p></section>
<section id="control"><h2>Give a conventional prover the same ground clauses</h2>
<p>This control sees every admitted ground clause at the same term depth. It runs unit propagation, records reasons and reconstructs a resolution derivation
from a conflict. When propagation stops without a conflict, Glucose tests the remaining ground problem.
Proof length sets the rectangle dimensions in this control. The nine reconstructed proofs pass the original Wang checker.</p>
{table(["Statement", "Method", "Outcome", "Used premise rows", "Resolution rows"], ground_rows)}
<p>A ground model satisfies the finite clause bank. A full countermodel to the quantified statement requires checking the quantified domains.
The benchmark demonstrates automated proof discovery and lets us compare markings under a fixed move set.
For these positives, ordinary ground propagation already finds a proof. Measuring the contribution of GCTS and RL to stronger proof search will require cases that survive that control.</p>
<p><a href="https://tptp.org/UserDocs/TPTPWorldTutorial/LogicFOF.html">TPTP first-order tutorial</a> ·
<a href="https://pysathq.github.io/docs/api/solvers.html">PySAT solver interface</a></p></section>
<section id="evidence"><h2>Replay the searches</h2>
<ul><li><a href="{STEM}-results.json">Results summary</a></li><li><a href="{STEM}-evidence.zip">Protocols, source, logs, marks and rectangles</a></li>
<li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li></ul>
<p>The archive has separate frozen depth-sweep directories. The previous benchmark explains the shared dependency pins.</p></section>
</main><script>
const menu=document.getElementById("case-menu");
function choose(){{for(const p of document.querySelectorAll(".proof[id^=case-]")) p.hidden=p.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""
    summary = dict(status="CHECKED_WANG_SUFFIX_AND_GROUND_CONTROL",
                   readers=list(choices), suffix_rows=results,
                   ground={n: {k: v for k, v in r.items() if k not in ("proof", "model", "raw_proof")}
                           for n, r in ground.items()},
                   qualification=load("data/suffix-qualification-v1.json"))
    with (ROOT / "report" / (STEM + ".html")).open("x") as stream:
        stream.write(page)
    with (ROOT / "report" / (STEM + "-results.json")).open("x") as stream:
        json.dump(summary, stream, indent=2, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    main()
