"""Render the checked Penrose results and the two Wang proof readers."""

import cmath
from html import escape
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from shared_reader_v1 import ROOT, STYLE, math, panel, table

sys.path.insert(0, str(ROOT / "source"))
from penrose_polygon_v1 import thin, tile_polygon

STEM = "penrose-lazy-contact-20261106-v1"


def read(name):
    return json.loads((ROOT / name).read_bytes())


def project(point):
    zeta = cmath.exp(2j * cmath.pi / 5)
    value = sum(v * zeta**k for k, v in enumerate(point))
    return value.real, -value.imag


def patch(title, tiles, boundary=(), targets=(), highlighted=()):
    """Project exact coordinates for display only."""
    points = [project(p) for tile in tiles for p in tile]
    points.extend(map(project, (*boundary, *targets)))
    x0, x1 = min(x for x, _ in points), max(x for x, _ in points)
    y0, y1 = min(y for _, y in points), max(y for _, y in points)
    scale = min(570 / (x1 - x0), 303 / (y1 - y0))

    def xy(p):
        x, y = project(p)
        return 310 + scale * (x - (x0 + x1) / 2), 175 + scale * (y - (y0 + y1) / 2)

    def coordinates(vertices):
        return " ".join(f"{x:.2f},{y:.2f}" for x, y in map(xy, vertices))

    rhombs = []
    for tile in tiles:
        color = "#dc9d6c" if tile in highlighted else ("#add3bd" if thin(tile) else "#9eafd7")
        rhombs.append(f'<polygon points="{coordinates(tile_polygon(tuple(map(tuple, tile))))}" fill="{color}" class="rhomb"></polygon>')
    outlines = f'<polygon points="{coordinates(boundary)}" class="outline"></polygon>' if boundary else ""
    dots = "".join(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3.2" class="target"></circle>' for x, y in map(xy, targets))
    return (f'<svg viewBox="0 0 620 350" class="geometry" role="img" aria-label="{escape(title)}">'
            f'<title>{escape(title)}</title>{"".join(rhombs)}{outlines}{dots}</svg>')


def main():
    lazy = read("data/lazy-contact-v1.json")
    polygons = read("data/polygon-v1.json")
    pair = read("data/polygon-pair-v1.json")
    audit = read("publication/pages-audit-v1.json")
    rows = []
    for c in lazy["cases"]:
        for r in c["results"]:
            assert r["independent"]
            rows.append(dict(case=c["case"]["id"], arm=r["mode"], outcome=r["status"],
                             targets=len(c["case"]["target"]), candidates=len(c["inventory"]),
                             warm=len(r["warm"]), models=r["counts"].get("models", 0),
                             decisions=r["counts"].get("decisions", 0), geometry=len(r["geometry"]),
                             rup=len(r["cuts"]), seconds=r["seconds"]))
    assert len(rows) == 65
    assert sum(r["outcome"] == "POSITIVE" for r in rows) == 40
    fixed = []
    for c in polygons["cases"]:
        w = c["world"]
        baseline = c.get("baseline", w)
        fixed.append(dict(case=c["id"], counts=w["counts"], candidates=len(w.get("tiles", [])),
                          outcome=baseline["status"], reason=baseline["reason"],
                          probes=[p["status"] for p in c.get("probes", [])]))
    assert [r["outcome"] for r in fixed] == ["POSITIVE"] * 4 + ["NEGATIVE"] * 2
    assert fixed[3]["probes"] == ["NEGATIVE"]
    slit = next(c for c in lazy["cases"] if c["case"]["id"] == "P04")
    learned = next(r for r in slit["results"] if r["mode"] == "learned")
    slit_svg = patch("A Penrose patch covering the 46 requested slit targets", learned["witness"],
                     targets=slit["case"]["target"])
    assert pair["joint"]["status"] == "NEGATIVE" and pair["joint"]["cuts"] == [[]]
    seed_a, seed_b = pair["seeds"]
    witness_a, witness_b = pair["witnesses"]
    assert seed_a in witness_a and seed_b in witness_b
    valid_a = patch("The first seed extends to a full tiling", witness_a, boundary=pair["boundary"], highlighted=[seed_a])
    valid_b = patch("The second seed extends to a full tiling", witness_b, boundary=pair["boundary"], highlighted=[seed_b])
    blocked_svg = patch("Both seeds fit each other but have no shared completion", pair["seeds"],
                        boundary=pair["boundary"], highlighted=pair["seeds"])

    peano = read("prior/wang/compose-peano-v1.json")["cases"][1]
    arithmetic = next(a for a in peano["arms"][-2:] if a["mode"] == "demand")
    h_id = "incidence-branch-2"
    h_source = next(c["source"] for c in read("prior/wang/lifted-v1.json")["cases"] if c["id"] == h_id)
    hilbert = next(c["results"][-1] for c in read("prior/wang/online-v1.json") if c["id"] == h_id)
    readers = [
        panel(dict(id=peano["source"]["id"], **arithmetic), peano["source"],
              "prior/wang/" + Path(arithmetic["rectangle_file"]).name,
              "Peano arithmetic. The search used two rounds of composed successor recipes."),
        panel(dict(id=h_id, **hilbert), h_source, "prior/wang/" + Path(hilbert["rectangle_file"]).name,
              "Hilbert incidence. The search used on-demand bindings and checked receptor marks."),
    ]
    readers[0] = readers[0].replace(">peano-successor-injectivity-8</h3>", ">Peano arithmetic · Injectivity of eight successors</h3>")
    wang = dict(
        peano=[dict(library=a["library"], mode=a["mode"], decisions=a["counts"]["decisions"], deepest=a["deepest"])
               for a in peano["arms"]],
        checked_rejected_attachments=720, decisions_unchanged_online=True, recipe_ranking_changed_choices=0,
        paired_conventional_conflict_counts_unchanged=13,
    )
    summary = dict(status="CHECKED_PENROSE_REGIONS", vertex_targets=rows, fixed_polygons=fixed,
                   training_episodes=len(lazy["training"]), warm_oriented_rules=lazy["oriented_donor_rules"],
                   withheld_orbits=lazy["held_out_orbits"], cardinality_tests=polygons["cardinality_checks"],
                   boundary_pair=dict(case=pair["case"], individual=["POSITIVE"] * 2, joint="NEGATIVE", rup=1),
                   wang=wang, pages=audit)
    (ROOT / "report" / (STEM + "-results.json")).write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    measurements = table(
        ("Case", "Targets", "Candidates", "Arm", "Outcome", "Decisions", "Models", "Fresh contacts", "RUP cuts"),
        [(r["case"], r["targets"], r["candidates"], r["arm"], r["outcome"], r["decisions"],
          r["models"], r["geometry"], r["rup"]) for r in rows],
    )
    fixed_table = table(
        ("Region", "Thin", "Thick", "Candidates", "Outcome", "Tested seed extensions"),
        [(r["case"], *r["counts"], r["candidates"], r["outcome"], ", ".join(r["probes"]) or "—") for r in fixed],
    )
    page = rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Exact Penrose regions and reusable Wang proof clusters</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.gallery{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,270px),1fr));gap:1rem}}
figure{{margin:0}}figcaption{{font-size:.94rem;color:#365547}}
.geometry{{display:block;width:100%;background:#f7faf8;border:1px solid #c6dbd0;border-radius:.55rem}}
.rhomb{{stroke:#344c4b;stroke-width:1.15}}.outline{{fill:none;stroke:#192d27;stroke-width:2.2}}
.target{{fill:#202b32;stroke:#fff;stroke-width:.7}}.proof-table{{table-layout:fixed}}
.proof-table tr>:first-child{{width:3.5rem}}.proof-table .strip{{overflow:auto}}
.clause{{font-size:1.04rem;margin-bottom:.4rem}}.legend{{margin:.75rem 0}}
.legend span{{display:inline-block;margin-right:1rem}}.legend i{{display:inline-block;width:.8rem;height:.8rem;border-radius:2px;margin-right:.3rem}}
</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · November 2026</p>
<h1>Exact Penrose regions and reusable Wang proof clusters</h1>
<p>Exact contact cuts settled thirteen finite Penrose vertex-target cases. A separate solver tiled four specified convex polygons and certified two impossible ones. The Wang experiments measured how typed clusters reduce repeated search work.</p>
<nav aria-label="On this page"><a href="#boundary">Fixed polygons</a><a href="#targets">Vertex targets</a>
<a href="#reader">Wang proof lines</a><a href="#evidence">Evidence</a></nav>
</header>
<section id="boundary"><h2>Tile a specified polygon</h2>
<div class="gallery">
<figure>{valid_a}<figcaption>The first seed extends to a complete tiling.</figcaption></figure>
<figure>{valid_b}<figcaption>The second seed extends to a different complete tiling.</figcaption></figure>
<figure>{blocked_svg}<figcaption>The seeds satisfy the pairwise geometry rules. Requiring both gives a checked contradiction for this boundary.</figcaption></figure>
</div>
<p class="legend"><span><i style="background:#add3bd"></i>Thin</span><span><i style="background:#9eafd7"></i>Thick</span><span><i style="background:#dc9d6c"></i>Required seed</span></p>
<p>Vertices have exact coordinates in {math(r"\mathbb Z[\zeta_5]")}. The tiles are the two unmarked Penrose rhombs with unit sides, and contacts must be edge to edge. In units of {math(r"\sin(\pi/5)")}, polygon area has the form {math(r"a+b\varphi")}, where {math(r"\varphi=(1+\sqrt{5})/2")}. A thin rhomb contributes one unit and a thick rhomb contributes {math(r"\varphi")}, so the two coefficients uniquely fix the tile counts.</p>
<p>For a convex polygon with {math(r"N")} tiles, every tile vertex is reachable from a boundary corner in at most {math(r"2N+1")} unit steps. The first rhomb has four vertices, and each rhomb added across a full edge introduces at most two. Enumeration within that radius gives a finite placement inventory. The solver enforces the tile counts and covers each unit boundary edge exactly once. An independent check verifies containment, pairwise contact and exact total area. These conditions imply full coverage.</p>
{fixed_table}
<p>The fractional-side polygon has a side whose length is outside the positive integers. The pentagon has unmatched opposite edge directions. Every full-edge rhomb tiling has integer-length sides and balanced opposite directions, so these obstructions certify impossibility before search.</p>
<p>For the illustrated pair, the count and boundary clauses with both seed assumptions contradict by unit propagation alone. Each singleton has a witness, so the pair is a minimal failed attachment for this boundary. This gives a boundary-dependent mark that can be indexed by the boundary and the two placements. The wider hexagon also has a failed two-seed extension, with a three-step reverse unit propagation certificate.</p>
</section>
<section id="targets"><h2>Learn from failed local contacts</h2>
<figure>{slit_svg}<figcaption>The learned policy covers every sector at the 46 dark target vertices in the slit case. The outer boundary of this patch is free.</figcaption></figure>
<p>Each target requires its ten angular sectors to be covered exactly once. The SAT solver proposes a selection of rhombs. Exact geometry checks each selected pair and turns any invalid contact into a reusable forbidden pair. Donor certificates supply the warm marks. Withholding complete rotation-and-translation orbits keeps the four test seed obstructions out of this donor inventory.</p>
<p>Four separate training fixtures supplied sixteen episodes for the frozen reinforcement learning policy. Plain starts without donor marks. Guarded uses the marks with the initial move order. Learned and random change that order. Glucose uses the same warm clauses and adds exact cuts in the same outer loop.</p>
<p>All five arms settled the same eight positives and five negatives. For the slit, warm marks reduced the number of fresh geometric cuts from 310 to 80, and the learned order needed zero. Glucose also needed zero and ran faster on this case. The learned order required more decisions than the initial order in seven of the eight positive cases. Decision counts across solvers reflect different branching implementations.</p>
<p>The earlier unmarked geometric depth-first search exhausted its budget on the slit and on a second positive target. The new solver produces checked tilings for both.</p>
<details><summary>Show all 65 runs</summary>{measurements}</details>
<p>The polygon results cover strictly convex specified regions under the same edge-to-edge rule. The vertex targets allow free outer boundaries. These are finite experiments on unmarked rhombs.</p>
</section>
<section id="reader"><h2>Inspect the Wang proofs line by line</h2>
<p>Typed receptors bind a cluster to the formulas currently available. Binding a recipe produces a checked logical derivation. The colors in each strip show the edge labels of the translation-only Wang squares. Expand a proof line to see a machine row that reads part of that line.</p>
<p class="legend"><span><i style="background:#68a98f"></i>Vertical transfer</span><span><i style="background:#ce8750"></i>Gate role</span><span><i style="background:#ad87c3"></i>Horizontal bus</span></p>
<p>For eight successors, two rounds of recipe composition changed on-demand search from 1,512 to 1,218 decisions. Eager admission changed from 247 to 306 decisions. On the larger Hilbert incidence pair, certified failed-attachment marks saved 360 binding checks per case, with the same decision counts. The frozen recipe ranker kept the initial choice in all 62 eligible windows. Conventional SAT controls with the same full library kept the same conflict counts across all thirteen cases.</p>
{''.join(readers)}
</section>
<section id="evidence"><h2>Evidence and publication</h2>
<ul><li><a href="{STEM}-results.json">Machine-readable results</a></li>
<li><a href="{STEM}-evidence.zip">Reproduction archive with sources, protocols, proof certificates and logs</a></li>
<li><a href="{STEM}-manifest.json">Archive file hashes</a></li></ul>
<p>GitHub Pages is configured to publish the repository root. Two attempts to deploy its {audit["failed_artifact_bytes"]:,}-byte artifact timed out. One projection under 900 million raw bytes would move 1,055 payload paths. The existing Pages configuration and published paths are preserved.</p>
<p><a href="https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits">GitHub Pages size and deployment limits</a></p>
</section>
</main></body></html>"""
    (ROOT / "report" / (STEM + ".html")).write_text(page)


if __name__ == "__main__":
    main()
