const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1250, height: 900 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const report = path.join(__dirname, "../report/penrose-lazy-contact-20261106-v1.html");
    await page.goto(pathToFileURL(report).href, { waitUntil: "commit" });
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length > 50);
    await page.evaluate(() => window.MathJax.startup.promise);
    const stats = await page.evaluate(() => {
      const panels = [...document.querySelectorAll("#reader .proof")];
      const details = panels.flatMap(p => [...p.querySelectorAll("tbody details")]);
      for (const detail of details) {
        detail.querySelector("summary").click();
        if (!detail.open || detail.querySelectorAll("svg.tile").length !== 7) {
          throw Error("Missing Wang strip");
        }
        detail.querySelector("summary").click();
      }
      return {
        panels: panels.length,
        lines: details.length,
        geometry: document.querySelectorAll("svg.geometry").length,
        targets: document.querySelectorAll("#targets circle.target").length,
        illustratedTiles: [...document.querySelectorAll("#boundary svg")].map(svg => svg.querySelectorAll(".rhomb").length),
        runs: document.querySelectorAll("#targets tbody tr").length,
        math: document.querySelectorAll("mjx-container").length,
        mathErrors: document.querySelectorAll("mjx-merror").length,
      };
    });
    assert.deepEqual(errors, []);
    assert.equal(stats.panels, 2);
    assert.equal(stats.geometry, 4);
    assert.equal(stats.targets, 46);
    assert.deepEqual(stats.illustratedTiles, [3, 3, 2]);
    assert.equal(stats.runs, 65);
    assert.equal(stats.mathErrors, 0);
    await page.locator("#boundary .gallery").screenshot({ path: path.join(__dirname, "boundary-v1.png") });
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    const receipt = { status: "CHECKED_READER", ...stats, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, "browser-v1.json"), JSON.stringify(receipt, null, 2) + "\n");
    process.stdout.write(JSON.stringify(receipt) + "\n");
  } finally {
    await browser.close();
  }
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
