# Replay the region and proof-search results

The results include exact coordinates, witnesses, learned cuts, failed search
costs, and proof rectangles. The frozen protocols pin the Python interpreter
and sources. The SAT phases also pin the PySAT extension files. The observed
runtime was CPython 3.12 and PySAT 1.9.dev21 on Apple Silicon.

Extract the archive. Set the environment variables in the commands below
to the pinned interpreter and the directory containing the pinned PySAT
installation. Supply a fresh output directory.

```sh
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py targets "$GCTS_OUTPUT" "$GCTS_PYSAT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py polygons "$GCTS_OUTPUT" "$GCTS_PYSAT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py seed-pair "$GCTS_OUTPUT" "$GCTS_PYSAT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py composition "$GCTS_OUTPUT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py ranking "$GCTS_OUTPUT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py conventional "$GCTS_OUTPUT" "$GCTS_PYSAT"
"$GCTS_PYTHON" -I -S -B publication/replay_region_v1.py online "$GCTS_OUTPUT"
```

Timing fields are observational. Compare the classifications, decision counts,
cuts, and checked witnesses. The archived outputs in the phase folders retain
all collected certificates and logs.
