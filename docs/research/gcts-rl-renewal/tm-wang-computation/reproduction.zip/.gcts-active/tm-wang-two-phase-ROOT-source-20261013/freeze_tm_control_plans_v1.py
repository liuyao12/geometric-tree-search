"""ROOT SOURCE/metadata freeze only; never executes a compiler or oracle."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACKAGE=ROOT/'.gcts-active/tm-wang-two-phase-control-source-20261013'
STAGE=ROOT/'.gcts-active/tm-wang-two-phase-control-progress-v3-20261013'

def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
    p=Path(p);b=p.read_bytes();assert p.is_absolute() and p.resolve()==p
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def verify(p):assert pin(p['path'])==p
def relative(p):
    p=dict(p)
    try:p['path']=str(Path(p['path']).relative_to(ROOT))
    except ValueError:pass
    return p
def write(p,d):
    with Path(p).open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')

def main():
    assert len(sys.argv)==2
    peer_path=Path(sys.argv[1]);assert peer_path.is_absolute() and peer_path.resolve()==peer_path
    contract=read(PACKAGE/'source-contract-v3.json');sources=contract['sources']
    assert len(sources)==4 and len(contract['inputs'])==2
    for p in [*sources.values(),*contract['inputs'].values()]:verify(p)
    assert sources['worker']['sha256']=='320d37eb6c3b276bd34862b375a2d8261373c0c0896a41908c8fb986a7fbd0ae'
    for role in ('compiler','oracle','worker'):ast.parse(Path(sources[role]['path']).read_bytes())
    worker=Path(sources['worker']['path']).read_text()
    assert worker.index('guard_fn=unchanged_executable;guard_code=guard_fn.__code__')<worker.index("modules[role]=load(plan['sources'][role]")
    assert 'or need is not need_fn or need_fn.__code__ is not need_code' in worker
    peer=read(peer_path)
    assert peer['source_only'] is True and peer['source_review_passed'] is True and peer['scientific_calls']==0
    assert peer['sources']==sources and peer['author_identity']=='/root/arithmetic_induction' and peer['reviewer_identity']!=peer['author_identity']
    review=dict(schema='ROOT-configured-TM-Wang-cold-control-SOURCE-review-v1',source_only=True,
        source_review_passed=True,scientific_calls=0,author_identity='/root/arithmetic_induction',reviewer_identity='/root',
        sources=sources,inputs=contract['inputs'],peer=pin(peer_path),contract=pin(PACKAGE/'source-contract-v3.json'),
        checks=['Whole compiler, direct oracle, worker control/guards and all4 configured inputs read; actual functions not called.',
            'Complete raw palette and every full-palette horizontal join, no favored patch or expected-result advice.',
            'All816 width1..3 tape/head/state inputs; NORMAL relation compares all direct edges, ACCEPT compares accepting edges only.',
            'Shared ND latch binds one complete write/move rule; finite walls reject escaping moves.',
            'Fourth stationary program isolates a legal nonaccepting edge and invalid incoming scan1 boundary bypass.',
            'Independent literal integer t/m and refcount unions; zero assigned versus absent, horizontal and both vertical mismatch controls.',
            'Initial accepting-state variants change recorded bottom input tokens only, not compiled machine/palette.',
            'V3 captures validator and need function/code before project loading; direct bootstrap if/raise precedes anchored own/module validation.',
            'Exact4sources/2inputs and11/10 leaf/owner ABI; flat root anchor;60s512MiB90caller with55s500MiB pre-receipt reserve.'],
        scope='SOURCE only. Future actual evidence is finite configured-machine palette/row relation conformance, not GCTS search, proofchecker, UTM, universal theorem, RL, aperiodicity or plane tiling.')
    review_path=HERE/'ROOT-SOURCE-review-v1.json';write(review_path,review)
    assert not STAGE.exists();STAGE.mkdir();assert STAGE.parents[1]==ROOT
    shutil.copyfile(review_path,STAGE/'ROOT-source-review-v1.json')
    for key,name in [('owner_reference','run_owned_bridge_v2.py'),('closer_reference','close_stage_decision_v1.py')]:
        verify(contract[key]);shutil.copyfile(contract[key]['path'],STAGE/name)
    runtime=read(ROOT/'.gcts-active/hilbert-current-physical-control-progress-v2-20261013/physical-worker-plan-v1.json')['runtime']
    oldowner=read(ROOT/'.gcts-active/hilbert-current-physical-control-progress-v2-20261013/replay-plan-v1.json')
    closure={}
    def add(p):
        verify(p);assert p['path'] not in closure or closure[p['path']]==p;closure[p['path']]=p
    reviews=dict(ROOT=pin(STAGE/'ROOT-source-review-v1.json'),independent=pin(peer_path))
    for p in [*sources.values(),*contract['inputs'].values(),*reviews.values(),runtime['binary'],runtime['resource_extension'],
              pin(STAGE/'run_owned_bridge_v2.py'),pin(STAGE/'close_stage_decision_v1.py'),pin(__file__),
              pin(PACKAGE/'source-contract-v3.json'),pin(PACKAGE/'handoff-v3.json')]:add(p)
    for p in oldowner['closure']:
        if 'lib-dynload/_posixsubprocess.' in p['path']:add(p)
    leaf_path=STAGE/'tm-wang-control-worker-plan-v1.json';owner_path=STAGE/'replay-plan-v1.json'
    leaf=dict(schema=contract['leaf_schema'],ROOT_owned_once_only=True,scope=contract['scope'],
        sources=sources,inputs=contract['inputs'],runtime=runtime,reviews=reviews,
        closure=[closure[k] for k in sorted(closure)],limits=contract['limits'],
        owner_plan_path=str(owner_path),output_directory=str(STAGE/'tm-wang-control-output-v1'))
    assert len(leaf)==11;write(leaf_path,leaf);add(pin(leaf_path))
    owner=dict(schema=contract['owner_schema'],stage=contract['owner_stage'],
        runtime_binary=relative(runtime['binary']),worker=str(Path(sources['worker']['path']).relative_to(ROOT)),
        argv=[runtime['binary']['path'],'-B',sources['worker']['path'],contract['command'],str(leaf_path),str(owner_path)],
        worker_receipt=str((STAGE/'tm-wang-control-output-v1/tm-wang-control-result-v1.json').relative_to(ROOT)),
        limits=contract['limits'],closure=sorted([relative(p) for p in closure.values()],key=lambda x:x['path']),
        ROOT_source_review=relative(reviews['ROOT']),scope=contract['scope'])
    assert len(owner)==10;write(owner_path,owner)
    for p in closure.values():verify(p)
    record=dict(schema='ROOT-TM-Wang-controls-metadata-freeze-v1',metadata_only=True,scientific_calls=0,
        actual_stage_invoked=False,flat_repository_anchor_correct=True,
        root_source_review=pin(review_path),peer_source_review=pin(peer_path),worker_plan=pin(leaf_path),owner_plan=pin(owner_path),
        literal_command=[runtime['binary']['path'],'-B',str(STAGE/'run_owned_bridge_v2.py'),str(owner_path)],
        leaf_closure_count=len(leaf['closure']),owner_closure_count=len(owner['closure']),limits=contract['limits'])
    write(HERE/'ROOT-construction-v1.json',record);print(json.dumps(record))

if __name__=='__main__':main()
