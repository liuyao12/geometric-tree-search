"""SOURCE independent direct whole-tape TM step relation.

No compiler import, tile/window/colour/point code, or oracle call in authoring.
Accept states are absorbing; attempted finite-wall escape has no successor.
This distinct whole-configuration algorithm is a prospective control oracle,
not independently executed evidence or universal proof-system authority.
"""
import math
import time

VERSION = 'direct-finite-wall-tm-step-oracle-v1'


def reject_unless(condition,message):
    if not condition:raise ValueError(message)


def direct_successors(program,configuration,*,deadline):
    """Return every enabled direct TM edge, including its declared identity."""
    reject_unless(type(deadline) in (int,float) and math.isfinite(deadline),'finite deadline')
    if time.perf_counter()>=deadline:raise TimeoutError('whole direct step unfinished')
    reject_unless(type(program) is dict and set(program)=={'schema','states','alphabet',
        'initial_state','accept_states','blank','transitions'} and
        program['schema']=='finite-wall-turing-machine-v1','entire configured program')
    for field in ('states','alphabet','accept_states'):
        reject_unless(type(program[field]) is list and
            all(type(v) is str and v for v in program[field]) and
            len(set(program[field]))==len(program[field]),'finite distinct program names')
    reject_unless(program['states'] and program['alphabet'] and
        program['initial_state'] in program['states'] and program['blank'] in program['alphabet'] and
        set(program['accept_states'])<=set(program['states']) and type(program['transitions']) is list,
        'complete valid program alphabets')
    seen=set()
    for rule in program['transitions']:
        reject_unless(type(rule) is dict and set(rule)=={'id','state','read','write','next_state','move'}
            and type(rule['id']) is str and rule['id'] and rule['id'] not in seen and
            rule['state'] in program['states'] and rule['state'] not in program['accept_states'] and
            rule['next_state'] in program['states'] and rule['read'] in program['alphabet'] and
            rule['write'] in program['alphabet'] and rule['move'] in ('L','R','S'),
            'entire finite transition relation, accept is absorbing')
        seen.add(rule['id'])
    reject_unless(type(configuration) is dict and set(configuration)=={'tape','head','state'}
        and type(configuration['tape']) is list and configuration['tape'] and
        all(type(a) is str and a in program['alphabet'] for a in configuration['tape']) and
        type(configuration['head']) is int and 0<=configuration['head']<len(configuration['tape']) and
        configuration['state'] in program['states'],'one actual head and entire finite tape')
    tape=configuration['tape'];position=configuration['head'];state=configuration['state']
    if state in program['accept_states']:
        answer=[dict(transition_identity=['absorbing_accept',state,tape[position]],
                     configuration=dict(tape=list(tape),head=position,state=state),accepting=True)]
        if time.perf_counter()>=deadline:raise TimeoutError('whole direct step unfinished; no prefix')
        return answer
    answers=[]
    for rule in sorted(program['transitions'],key=lambda t:t['id']):
        if time.perf_counter()>=deadline:raise TimeoutError('whole direct step unfinished; no prefix')
        if rule['state']!=state or rule['read']!=tape[position]:continue
        destination=position+{'L':-1,'R':1,'S':0}[rule['move']]
        if not 0<=destination<len(tape):continue
        updated=list(tape);updated[position]=rule['write']
        successor=dict(tape=updated,head=destination,state=rule['next_state'])
        answers.append(dict(transition_identity=['declared',rule['id']],configuration=successor,
                            accepting=rule['next_state'] in program['accept_states']))
    if time.perf_counter()>=deadline:raise TimeoutError('whole direct step unfinished; no prefix')
    return answers
