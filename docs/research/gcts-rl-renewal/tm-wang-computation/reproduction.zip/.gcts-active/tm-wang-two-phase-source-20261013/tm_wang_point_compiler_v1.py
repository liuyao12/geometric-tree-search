"""SOURCE finite configured-machine to translation-only Wang/point palette.

No compiler/model/fixture/search is executed by the source author. Two micro
rows encode one nondeterministic TM step: unique head announces one rule,
then a deterministic radius-one row applies that same latched rule everywhere.
Accepting states are explicitly absorbing (finite accept padding only). Walls
reject a move beyond the declared finite tape. This is not a universal proof
checker tile set, aperiodicity construction, or infinite-plane claim.
"""
from itertools import product
import json
import math
import time

VERSION = 'configured-tm-two-phase-wang-point-compiler-v1'
CHANNELS = ('horizontal_window','horizontal_mode','horizontal_scan',
            'vertical_symbol','vertical_phase')
PLAIN = 'plain'
LATCH = 'latched'
FINAL = 'final'
NORMAL = 'normal'
ACCEPT = 'accept_scan'
WALL = ('wall',)


def need(value,label):
    if not value:
        raise ValueError(label)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)


def tick(deadline):
    need(type(deadline) in (int,float) and math.isfinite(deadline),'finite charged deadline')
    if time.perf_counter() >= deadline:
        raise TimeoutError('whole finite compiler/model unfinished; no accepted prefix')


def machine(value):
    need(type(value) is dict and set(value)=={'schema','states','alphabet',
        'initial_state','accept_states','blank','transitions'}
        and value['schema']=='finite-wall-turing-machine-v1','exact configured-machine grammar')
    for key in ('states','alphabet','accept_states'):
        need(type(value[key]) is list and all(type(x) is str and x for x in value[key])
             and len(value[key])==len(set(value[key])), 'finite distinct symbol/state names')
    need(value['states'] and value['alphabet']
         and value['initial_state'] in value['states']
         and value['blank'] in value['alphabet']
         and set(value['accept_states'])<=set(value['states']), 'configured finite alphabets')
    need(type(value['transitions']) is list,'entire finite declared transition relation')
    ids=set();rules=[]
    for t in value['transitions']:
        need(type(t) is dict and set(t)=={'id','state','read','write','next_state','move'}
             and type(t['id']) is str and t['id'] and t['id'] not in ids
             and t['state'] in value['states'] and t['next_state'] in value['states']
             and t['state'] not in value['accept_states']
             and t['read'] in value['alphabet'] and t['write'] in value['alphabet']
             and t['move'] in ('L','R','S'),'entire exact transition, absorbing accept states')
        ids.add(t['id']);rules.append(dict(t))
    return dict(schema=value['schema'],states=sorted(value['states']),
        alphabet=sorted(value['alphabet']),initial_state=value['initial_state'],
        accept_states=sorted(value['accept_states']),blank=value['blank'],
        transitions=sorted(rules,key=lambda t:t['id']))


def effective_rules(m):
    rows=[dict(t,identity=['declared',t['id']],origin='declared') for t in m['transitions']]
    for q in m['accept_states']:
        for a in m['alphabet']:
            rows.append(dict(id=None,state=q,read=a,write=a,next_state=q,move='S',
                             identity=['absorbing_accept',q,a],origin='absorbing_accept'))
    return tuple(rows)


def alphabets(m,rules):
    p=tuple([('symbol',a) for a in m['alphabet']]+
            [('head',q,a) for q in m['states'] for a in m['alphabet']])
    l=tuple([('symbol',a) for a in m['alphabet']]+
            [('latch',i) for i in range(len(rules))])
    return p,l


def latch_outputs(window,rules):
    left,center,right=window
    if sum(token[0]=='head' for token in window)>1:
        return ()
    if center[0]=='symbol':
        return (center,)
    return tuple(('latch',i) for i,t in enumerate(rules)
                 if (t['state'],t['read'])==(center[1],center[2]))


def apply_output(window,rules):
    left,center,right=window
    if sum(token[0]=='latch' for token in window)>1:
        return None
    if center[0]=='latch':
        t=rules[center[1]]
        if (t['move']=='L' and left==WALL) or (t['move']=='R' and right==WALL):
            return None
        return ('head',t['next_state'],t['write']) if t['move']=='S' else ('symbol',t['write'])
    arriving=[]
    if left[0]=='latch' and rules[left[1]]['move']=='R':arriving.append(rules[left[1]])
    if right[0]=='latch' and rules[right[1]]['move']=='L':arriving.append(rules[right[1]])
    if len(arriving)>1:return None
    return ('head',arriving[0]['next_state'],center[1]) if arriving else center


def horizontal(phase,left,center,right):
    west=('left_wall',phase) if left==WALL else ('pair',phase,left,center)
    east=('right_wall',phase) if right==WALL else ('pair',phase,center,right)
    return west,east


def compile_palette(configured_machine,*,deadline):
    """Complete finite raw palette, no sampling or machine-specific route."""
    began=time.perf_counter();tick(deadline);m=machine(configured_machine)
    rules=effective_rules(m);p,l=alphabets(m,rules);raw=[]
    def add(phase,window,out,mode,incoming,outgoing):
        west,east=horizontal(phase,*window)
        raw.append(dict(phase=phase,window=window,output=out,mode=mode,
            south={'vertical_phase':phase,'vertical_symbol':window[1]},
            north={'vertical_phase':LATCH if phase==PLAIN else
                   FINAL if mode==ACCEPT else PLAIN,'vertical_symbol':out},
            west={'horizontal_window':west,'horizontal_mode':mode,'horizontal_scan':incoming},
            east={'horizontal_window':east,'horizontal_mode':mode,'horizontal_scan':outgoing}))
    for left,center,right in product(p+(WALL,),p,p+(WALL,)):
        tick(deadline);window=(left,center,right)
        for out in latch_outputs(window,rules):add(PLAIN,window,out,NORMAL,0,0)
    for left,center,right in product(l+(WALL,),l,l+(WALL,)):
        tick(deadline);window=(left,center,right);out=apply_output(window,rules)
        if out is None:continue
        add(LATCH,window,out,NORMAL,0,0)
        accepts=out[0]=='head' and out[1] in m['accept_states']
        for incoming in (0,1):add(LATCH,window,out,ACCEPT,incoming,int(bool(incoming or accepts)))
    # Colour IDs are exact integers, with zero still an assigned colour.
    values={channel:{} for channel in CHANNELS}
    def collect(channel,value):values[channel][canonical(value)]=value
    for tile in raw:
        for edge in ('west','east','south','north'):
            for channel,value in tile[edge].items():collect(channel,value)
    for phase in (PLAIN,LATCH):
        collect('horizontal_window',('left_wall',phase))
        collect('horizontal_window',('right_wall',phase))
    for token in p+l:collect('vertical_symbol',token)
    for value in (PLAIN,LATCH,FINAL):collect('vertical_phase',value)
    for value in (NORMAL,ACCEPT):collect('horizontal_mode',value)
    for value in (0,1):collect('horizontal_scan',value)
    colors={channel:[dict(id=i,value=values[channel][text])
                     for i,text in enumerate(sorted(values[channel]))] for channel in CHANNELS}
    ids={channel:{canonical(x['value']):x['id'] for x in rows} for channel,rows in colors.items()}
    raw.sort(key=canonical);tiles=[]
    coordinates={'west':(-1,0),'east':(1,0),'south':(0,-1),'north':(0,1)}
    for index,tile in enumerate(raw):
        tick(deadline);marks=[];edges={}
        for edge,(x,y) in coordinates.items():
            edges[edge]={channel:ids[channel][canonical(value)] for channel,value in tile[edge].items()}
            for channel,code in sorted(edges[edge].items()):marks.append([channel,x,y,code])
        tiles.append(dict(id=index,logical_window=tile,edge_color_ids=edges,
                          t=[[0,0,1]],m=sorted(marks)))
    tick(deadline)
    return dict(schema=VERSION,machine=m,effective_rules=list(rules),
        accepting_padding_semantics='accept states are absorbing; no declared outgoing rule',
        colors=colors,tiles=tiles,complete_palette=True,
        point_domain='integer coordinates scaled by2; centers even/even, horizontal edges odd/even, vertical edges even/odd',
        channels=list(CHANNELS),transformations=dict(orientation='identity',translations='even integer vectors only',rotations=False,reflections=False),
        configured_machine_only=True,universal_proof_checker_tile_set=False,
        aperiodicity_claim=False,infinite_plane_claim=False,native_proof_accepted=False,
        compiler_seconds=time.perf_counter()-began)


def finite_model(palette,tape,head,macro_steps,*,deadline):
    """Fixed wall rectangle with free final symbols and accepting scan."""
    tick(deadline);need(palette['schema']==VERSION and palette['complete_palette'] is True,
                        'full configured palette, not a favoured subset')
    m=machine(palette['machine'])
    need(type(tape) is list and tape and all(type(a) is str and a in m['alphabet'] for a in tape)
         and type(head) is int and 0<=head<len(tape)
         and type(macro_steps) is int and macro_steps>=1,'entire finite tape and positive exact macro horizon')
    width=len(tape);height=2*macro_steps
    ids={channel:{canonical(z['value']):z['id'] for z in rows} for channel,rows in palette['colors'].items()}
    fixed={}
    def mark(channel,x,y,value):
        code=ids[channel][canonical(value)];point=(channel,x,y)
        need(point not in fixed or fixed[point]==code,'compatible fixed boundary assignments')
        fixed[point]=code
    for x,a in enumerate(tape):
        mark('vertical_phase',2*x,-1,PLAIN)
        mark('vertical_symbol',2*x,-1,('head',m['initial_state'],a) if x==head else ('symbol',a))
        mark('vertical_phase',2*x,2*height-1,FINAL)
        # No top symbol assignment: acceptance uses the finite scan, not a supplied final tape.
    for y in range(height):
        tick(deadline);phase=PLAIN if y%2==0 else LATCH;mode=ACCEPT if y==height-1 else NORMAL
        mark('horizontal_window',-1,2*y,('left_wall',phase))
        mark('horizontal_window',2*width-1,2*y,('right_wall',phase))
        for x,scan in ((-1,0),(2*width-1,1 if mode==ACCEPT else 0)):
            mark('horizontal_mode',x,2*y,mode);mark('horizontal_scan',x,2*y,scan)
    result=dict(schema='finite-wall-tm-wang-point-model-v1',width=width,micro_rows=height,
        macro_steps=macro_steps,initial_tape=list(tape),initial_head=head,
        required_t=[[2*x,2*y,1] for y in range(height) for x in range(width)],
        root_generations=[[2*x,2*y,0] for y in range(height) for x in range(width)],
        fixed_m=[[channel,x,y,value] for (channel,x,y),value in sorted(fixed.items())],
        allowed_translations=[[2*x,2*y] for y in range(height) for x in range(width)],
        complete_candidate_universe='every full palette tile at every declared translation; marking agreement rejects incompatibility',
        scheduler='global dead, then global forced, then earliest generation; degree only generation tie',
        rollback='trail all point totals, assigned marking values/refcounts, incidence, exclusions and generations',
        final_symbols_supplied=False,acceptance='last apply output has an accepting head certified by left0/right1 OR scan',
        proof_or_tiling_certificate_issued=False,execution_or_conformance_measured=False)
    tick(deadline)
    return result
