"""Future ROOT-owned finite TM palette relation controls; SOURCE-only authoring."""
import collections
import hashlib
import importlib.util
import inspect
import itertools
import json
import math
from pathlib import Path
import resource
import sys
import time
ROOT=Path(__file__).resolve().parents[2]
SCHEMA = 'ROOT-two-phase-TM-Wang-control-plan-v1'
SCOPE = 'whole-configured-palette-and-complete-two-row-literal-controls-no-GCTS-search'
COMMAND = 'ROOT-two-phase-TM-Wang-controls'
AUTHOR = '/root/arithmetic_induction'
MAX_METADATA = 67108864
LIMITS = {'whole_seconds': 60, 'peak_bytes': 536870912, 'caller_seconds': 90}
FROZEN_SOURCES = {'compiler': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/tm-wang-two-phase-source-20261013/tm_wang_point_compiler_v1.py', 'sha256': 'bed3c9d86f8634ac124a8cb3da45b3b99fd3251f4a142d73baedc5614609a0b7', 'bytes': 11440}, 'oracle': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/tm-wang-two-phase-source-20261013/direct_tm_step_oracle_v1.py', 'sha256': 'b258de856d0ae34e47f6706c346ca9ccd14301cce2b7f32205462846b4d5d112', 'bytes': 4021}, 'master': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md', 'sha256': 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'bytes': 21657}}
FROZEN_INPUTS = {'specification': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/tm-wang-two-phase-source-20261013/control-specification-v1.json', 'sha256': '8c658501f08f054839bc36fba393fe0513a2b0c8ac4c2db23576ee275a892cc1', 'bytes': 6048}, 'supplement': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/.gcts-active/tm-wang-two-phase-control-source-20261013/supplemental-control-input-v1.json', 'sha256': 'b331c7eb4404f8054a8ce4ca7089094ac63fbc9fc0c469a5c8c68f0704c2293b', 'bytes': 996}}
PROGRAM_IDS = ['deterministic', 'nondeterministic', 'stationary-nonaccept', 'stuck']
SOURCE_ROLES=set(FROZEN_SOURCES)|{'worker'}
INPUT_ROLES={'specification','supplement'}


def need(value, label):
    if not value:
        raise ValueError(label)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def pin(path):
    path = Path(path)
    need(path.is_absolute() and str(path.resolve()) == str(path) and not path.is_symlink(), 'canonical ABS pin')
    h = hashlib.sha256(); count = 0; before = path.stat()
    with path.open('rb') as stream:
        for raw in iter(lambda: stream.read(65536), b''):
            h.update(raw); count += len(raw)
    after = path.stat()
    need((before.st_dev,before.st_ino,before.st_mtime_ns,before.st_size) ==
         (after.st_dev,after.st_ino,after.st_mtime_ns,after.st_size), 'whole stable raw bytes')
    return dict(path=str(path), sha256=h.hexdigest(), bytes=count)

def verify(record):
    need(type(record) is dict and set(record) == {'path','sha256','bytes'}
         and type(record['bytes']) is int and record['bytes'] >= 0
         and type(record['sha256']) is str and len(record['sha256']) == 64
         and all(c in '0123456789abcdef' for c in record['sha256'])
         and pin(record['path']) == record, 'typed canonical full pin')
    return record

def parse(raw):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            need(name not in result, 'duplicate JSON field'); result[name] = value
        return result
    return json.loads(raw, object_pairs_hook=unique,
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError('nonfinite JSON '+token)))

def read(record, maximum=MAX_METADATA):
    verify(record)
    with Path(record['path']).open('rb') as stream:
        raw = stream.read(maximum+1)
        need(len(raw) <= maximum and stream.read(1) == b'', 'whole bounded raw buffer, no prefix')
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'parse the authenticated same raw buffer')
    value = parse(raw); verify(record); return value

def load(record, name):
    verify(record); raw = Path(record['path']).read_bytes()
    need(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
         'same exact raw source execution buffer')
    spec = importlib.util.spec_from_file_location(name, record['path'])
    need(spec is not None, 'source metadata spec')
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    exec(compile(raw, record['path'], 'exec'), module.__dict__)
    need(str(Path(module.__file__).resolve()) == record['path'], 'bound raw source origin, no bytecode loader')
    return module

def normalize(record):
    path = Path(record['path']); actual = path if path.is_absolute() else ROOT/path
    return dict(record, path=str(actual))

def value_state(value):
    """Detect ordinary namespace/default mutation without accepting origin claims."""
    if value is None or type(value) in (str, int, bool, float, list, dict, tuple):
        try: return canonical(value)
        except (TypeError, ValueError): pass
    return None

def executable_state(module, *, class_roots=()):
    state = []; namespaces = []; mros = []; seen_classes = set()
    def keys(owner):
        return tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE')
    def add(owner, name, value):
        if isinstance(value, (staticmethod, classmethod)): value = value.__func__
        code = value.__code__ if inspect.isfunction(value) else None
        defaults = (value_state(value.__defaults__), value_state(value.__kwdefaults__)) if code else None
        closure = tuple((cell.cell_contents, value_state(cell.cell_contents))
                        for cell in (value.__closure__ or ())) if code else None
        state.append((owner, name, value, code, defaults, closure, value_state(value)))
        if isinstance(value, property):
            # The descriptor object can stay unchanged while its getter code mutates.
            for accessor in ('fget', 'fset', 'fdel'):
                add(value, accessor, getattr(value, accessor))
    def record_class(value):
        # Generated methods may dispatch through super() or a captured base_type.
        # Preserve every actual MRO class/method, not just that class object's ID.
        for parent in value.__mro__:
            if parent is object or parent in seen_classes: continue
            seen_classes.add(parent); mros.append((parent, parent.__mro__))
            namespaces.append((parent, keys(parent)))
            for field, child in vars(parent).items():
                if field not in ('__dict__', '__weakref__'): add(parent, field, child)
    namespaces.append((module, keys(module)))
    for name, value in vars(module).items():
        if name.startswith('__') or name == '_NEXT_CAPSULE': continue
        add(module, name, value)
        if isinstance(value, type) and value.__module__ == module.__name__:
            record_class(value)
    for value in class_roots:
        need(isinstance(value, type), 'actual generated endpoint class')
        record_class(value)
    return namespaces, state, mros

def unchanged_executable(state):
    namespaces, records, mros = state
    for owner, original_mro in mros:
        need(owner.__mro__ == original_mro and all(a is b for a, b in zip(owner.__mro__, original_mro)),
             'compiled generated endpoint inheritance changed')
    for owner, names in namespaces:
        need(tuple(k for k in vars(owner) if not k.startswith('__') and k != '_NEXT_CAPSULE') == names,
             'compiled namespace gained or lost bindings')
    for owner, name, original, code, defaults, closure, data in records:
        actual = getattr(owner, name) if isinstance(owner, property) else vars(owner).get(name)
        if isinstance(actual, (staticmethod, classmethod)): actual = actual.__func__
        need(actual is original, 'compiled namespace/function identity changed')
        if code is not None:
            need(actual.__code__ is code and
                 (value_state(actual.__defaults__), value_state(actual.__kwdefaults__)) == defaults,
                 'compiled executable/defaults changed; co_filename is insufficient')
            current = actual.__closure__ or ()
            need(len(current) == len(closure) and all(cell.cell_contents is old and value_state(cell.cell_contents) == text
                 for cell, (old, text) in zip(current, closure)), 'compiled source closure changed')
        if data is not None: need(value_state(actual) == data, 'compiled source constant changed')

def source_cache_guard(sources, modules, anchors):
    """An explicit executable allowlist; evidence closure cannot authorize code."""
    allowed={record['path']:record for record in sources.values() if record['path'].endswith('.py')}
    ledger={}
    need(set(modules)==set(anchors) and all(modules[role] is value for role,value in anchors.items()),
         'original exact directly compiled module endpoints')
    for module in tuple(sys.modules.values()):
        origin=getattr(module,'__file__',None)
        if not origin:continue
        path=Path(origin).resolve()
        if ROOT not in path.parents or path.suffix!='.py':continue
        need(str(path) in allowed and str(path)==origin,'only exact disclosed executable raw paths')
        verify(allowed[str(path)]);ledger[str(path)]=allowed[str(path)]
    return [ledger[path] for path in sorted(ledger)]

def preflight(plan_path, owner_path):
    plan_pin, owner_pin = pin(plan_path), pin(owner_path)
    plan = read(plan_pin,2*1048576); owner = read(owner_pin,2*1048576)
    need(set(plan)=={'schema','ROOT_owned_once_only','scope','sources','inputs','runtime',
        'reviews','closure','limits','owner_plan_path','output_directory'}
        and plan['schema']==SCHEMA and plan['ROOT_owned_once_only'] is True
        and plan['scope']==SCOPE and plan['limits']==LIMITS,
        'same strict11-field leaf and original60/512/90 stage')
    need(plan_path.parent==owner_path.parent and plan['owner_plan_path']==str(owner_path)
        and set(plan['sources'])==SOURCE_ROLES and set(plan['inputs'])==INPUT_ROLES
        and set(plan['reviews'])=={'ROOT','independent'},'whole exact source/input/review ABI')
    need({k:v for k,v in plan['sources'].items() if k!='worker'}==FROZEN_SOURCES
        and plan['sources']['worker']==pin(Path(__file__).resolve()),
        'exact current20-role executable/source set, never arbitrary raw closure')
    output=Path(plan['output_directory'])
    need(output.is_absolute() and output==output.resolve() and output.parent==plan_path.parent
        and not output.exists(),'exclusive future full output namespace')
    closure={}
    for record in plan['closure']:
        verify(record);need(record['path'] not in closure,'whole closure has unique canonical paths')
        closure[record['path']]=record
    need(list(closure)==sorted(closure),'sorted complete declared raw closure')
    for record in [*plan['sources'].values(),*plan['inputs'].values(),*plan['reviews'].values()]:
        verify(record);need(closure.get(record['path'])==record,'each direct pin closed')
    for which in ('ROOT','independent'):
        review=read(plan['reviews'][which])
        need(review.get('source_only') is True and review.get('source_review_passed') is True
            and type(review.get('scientific_calls')) is int and review['scientific_calls']==0
            and review.get('sources')==plan['sources'],'current whole SOURCE review, not acceptance')
        if which=='independent':
            need(review.get('author_identity')==AUTHOR and type(review.get('reviewer_identity')) is str
                and review['reviewer_identity']!=AUTHOR,'separate SOURCE reviewer')
    need(plan['reviews']['ROOT']['path']==str(plan_path.parent/'ROOT-source-review-v1.json'),
         'existing owner local ROOT source review')
    runtime=plan['runtime']
    need(set(runtime)=={'binary','resource_extension','python_version','platform'}
        and runtime['python_version']==[3,9,6] and runtime['platform']=='darwin'
        and list(sys.version_info[:3])==[3,9,6] and sys.platform=='darwin',
        'same frozen actual CLT runtime')
    for role in ('binary','resource_extension'):
        verify(runtime[role]);need(closure.get(runtime[role]['path'])==runtime[role],'runtime closed')
    need(str(Path(sys.executable).resolve())==runtime['binary']['path']
        and str(Path(resource.__file__).resolve())==runtime['resource_extension']['path'],
        'actual runtime and resource extension origins')
    argv=[runtime['binary']['path'],'-B',plan['sources']['worker']['path'],
          COMMAND,str(plan_path),str(owner_path)]
    need(set(owner)=={'schema','stage','runtime_binary','worker','argv','worker_receipt',
                     'limits','closure','ROOT_source_review','scope'}
        and owner['schema']=='ROOT-guard-native-owned-plan-v1'
        and owner['stage']=='replay' and owner['limits']==LIMITS and owner['argv']==argv
        and owner['scope']==SCOPE
        and normalize(owner['ROOT_source_review'])==plan['reviews']['ROOT']
        and normalize(owner['runtime_binary'])==runtime['binary']
        and normalize(dict(path=owner['worker'],sha256='',bytes=0))['path']==str(Path(__file__).resolve())
        and normalize(dict(path=owner['worker_receipt'],sha256='',bytes=0))['path']==str(output/'tm-wang-control-result-v1.json'),
        'unchanged exact10-field owned-stage ABI')
    owner_closure={normalize(record)['path']:normalize(record) for record in owner['closure']}
    need(len(owner_closure)==len(owner['closure'])
        and all(owner_closure.get(path)==record for path,record in closure.items())
        and owner_closure.get(str(plan_path))==plan_pin,'whole explicit owner closure')
    for record in owner_closure.values():verify(record)
    for module in tuple(sys.modules.values()):
        origin=getattr(module,'__file__',None)
        if origin and ROOT in Path(origin).resolve().parents and Path(origin).suffix=='.py':
            need(Path(origin).resolve()==Path(__file__).resolve(),'genuine cold source worker')
    return plan,output,plan_pin,owner_pin,closure,owner_closure

def clone(v):return json.loads(canonical(v))
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()

def color(palette,channel,value):
    matches=[r['id'] for r in palette['colors'][channel] if canonical(r['value'])==canonical(value)]
    need(len(matches)==1,'whole injective actual colour table');return matches[0]
def value(palette,channel,code):
    rows=palette['colors'][channel];need(type(code) is int and 0<=code<len(rows) and rows[code]['id']==code,'exact actual colour id')
    return rows[code]['value']
def edges(tile,side):return tuple(sorted(tile['edge_color_ids'][side].items()))

def audit_palette(palette):
    need(palette['complete_palette'] is True and palette['transformations']==dict(orientation='identity',translations='even integer vectors only',rotations=False,reflections=False),'whole translation-only fresh palette')
    coords={'west':(-1,0),'east':(1,0),'south':(0,-1),'north':(0,1)}
    for channel,rows in palette['colors'].items():
        need([r['id'] for r in rows]==list(range(len(rows))) and len({canonical(r['value']) for r in rows})==len(rows),'whole colour ids including zero')
    for i,tile in enumerate(palette['tiles']):
        need(tile['id']==i and tile['t']==[[0,0,1]],'complete literal tile id/unit center')
        expected=[]
        for side,(x,y) in coords.items():
            for channel,code in tile['edge_color_ids'][side].items():
                need(canonical(value(palette,channel,code))==canonical(tile['logical_window'][side][channel]),'raw symbolic colour correspondence')
                expected.append([channel,x,y,code])
        need(sorted(expected)==tile['m'],'all raw point marks and edge fields agree')
    return dict(tiles_checked=len(palette['tiles']),all_color_ids_and_t_m_checked=True,assigned_zero_preserved=True)

def translated(palette,tile_ids,y):
    return [dict(key=[i,2*x,2*y],t=[[a+2*x,b+2*y,v] for a,b,v in palette['tiles'][i]['t']],
                 m=[[c,a+2*x,b+2*y,v] for c,a,b,v in palette['tiles'][i]['m']]) for x,i in enumerate(tile_ids)]

def literal_patch(records,fixed,required):
    """Independent complete integer point union, no compiler/window semantics."""
    target={(x,y):v for x,y,v in required};need(len(target)==len(required),'whole distinct target points')
    totals={};marks={};counts={};keys=set()
    def assign(c,x,y,v):
        need(type(c) is str and all(type(z) is int for z in (x,y,v)),'literal marking coordinates/value')
        p=(c,x,y);need(p not in marks or marks[p]==v,'literal assigned marking disagreement')
        marks[p]=v;counts[p]=counts.get(p,0)+1
    for c,x,y,v in fixed:assign(c,x,y,v)
    for record in records:
        k=canonical(record['key']);need(k not in keys,'distinct placement occurrence');keys.add(k)
        for x,y,v in record['t']:
            need(all(type(z) is int for z in (x,y,v)) and v>=0,'exact integer t values')
            p=(x,y);totals[p]=totals.get(p,0)+v
            need(totals[p]<=target.get(p,0),'complete global capacity, no outside positive support')
        for c,x,y,v in record['m']:assign(c,x,y,v)
    need(all(totals.get(p,0)==v for p,v in target.items()),'every required point exactly filled')
    return dict(t=[[x,y,v] for (x,y),v in sorted(totals.items())],
        m=[[c,x,y,v] for (c,x,y),v in sorted(marks.items())],
        marks=[[c,x,y,v,counts[c,x,y]] for (c,x,y),v in sorted(marks.items())],
        whole_literal_t_and_m_accepted=True,point_checker_calls_no_Graph_or_compiler=True)

def row_index(palette):
    index={}
    for tile in palette['tiles']:
        south=tile['edge_color_ids']['south'];key=(south['vertical_phase'],south['vertical_symbol'],edges(tile,'west'))
        index.setdefault(key,[]).append(tile['id'])
    need(sum(map(len,index.values()))==len(palette['tiles']),'every tile in complete row index')
    return index

def row_joins(palette,index,word,phase,mode,left_scan,right_scan,deadline,tick):
    """All horizontal joins from exact colours only, no logical window shortcut."""
    west=tuple(sorted(dict(horizontal_window=color(palette,'horizontal_window',['left_wall',phase]),
        horizontal_mode=color(palette,'horizontal_mode',mode),horizontal_scan=color(palette,'horizontal_scan',left_scan)).items()))
    east=tuple(sorted(dict(horizontal_window=color(palette,'horizontal_window',['right_wall',phase]),
        horizontal_mode=color(palette,'horizontal_mode',mode),horizontal_scan=color(palette,'horizontal_scan',right_scan)).items()))
    symbols=[color(palette,'vertical_symbol',token) for token in word];phase_id=color(palette,'vertical_phase',phase);answer=[]
    def walk(x,edge,chosen):
        tick();need(time.perf_counter()<deadline,'whole row join deadline')
        if x==len(word):
            if edge==east:
                answer.append(dict(tile_ids=list(chosen),output_tokens=[value(palette,'vertical_symbol',palette['tiles'][i]['edge_color_ids']['north']['vertical_symbol']) for i in chosen]))
            return
        for tile_id in index.get((phase_id,symbols[x],edge),[]):
            walk(x+1,edges(palette['tiles'][tile_id],'east'),chosen+[tile_id])
    walk(0,west,[]);return answer

def configuration_word(config):
    return [['head',config['state'],a] if x==config['head'] else ['symbol',a] for x,a in enumerate(config['tape'])]
def decode_word(word):
    heads=[(x,t) for x,t in enumerate(word) if t[0]=='head'];need(len(heads)==1,'complete one-head output configuration')
    head,token=heads[0];need(all(t[0] in ('head','symbol') for t in word),'plain actual output tokens')
    return dict(tape=[t[-1] for t in word],head=head,state=token[1])

def declared_boundary(base,palette,config,mode):
    """Declared input symbol override; compiled machine/palette never changed."""
    model=clone(base);fixed={(c,x,y):v for c,x,y,v in model['fixed_m']};width=len(config['tape'])
    overrides=[]
    for x,token in enumerate(configuration_word(config)):
        point=('vertical_symbol',2*x,-1);code=color(palette,'vertical_symbol',token)
        overrides.append(dict(point=list(point),old_code=fixed[point],declared_code=code,declared_token=token));fixed[point]=code
    for x in (-1,2*width-1):
        fixed['horizontal_mode',x,2]=color(palette,'horizontal_mode',mode)
        fixed['horizontal_scan',x,2]=color(palette,'horizontal_scan',0 if x==-1 or mode=='normal' else 1)
    for x in range(width):fixed['vertical_phase',2*x,3]=color(palette,'vertical_phase','plain' if mode=='normal' else 'final')
    model['fixed_m']=[[c,x,y,v] for (c,x,y),v in sorted(fixed.items())]
    model.update(schema='two-microrow-normal-relation-boundary-v1' if mode=='normal' else 'declared-input-acceptance-boundary-v1',
        declared_input_configuration=config,input_token_overrides=overrides,
        configured_machine_initial_state_unchanged=True,palette_unchanged=True,
        boundary_scope='NORMAL step relation' if mode=='normal' else 'original FINAL/left0/right1 accepting strip with declared input tokens')
    need(not any(c=='vertical_symbol' and y==3 for c,x,y,v in model['fixed_m']),'top symbol absence, not zero')
    return model

def two_rows(palette,index,config,mode,model,deadline,tick):
    outputs=[];latch_rows=row_joins(palette,index,configuration_word(config),'plain','normal',0,0,deadline,tick)
    for first in latch_rows:
        tokens=first['output_tokens'];latched=[t for t in tokens if t[0]=='latch'];need(len(latched)==1,'actual one shared latch')
        identity=palette['effective_rules'][latched[0][1]]['identity']
        for second in row_joins(palette,index,tokens,'latched',mode,0,0 if mode=='normal' else 1,deadline,tick):
            records=translated(palette,first['tile_ids'],0)+translated(palette,second['tile_ids'],1)
            points=literal_patch(records,model['fixed_m'],model['required_t']);configuration=decode_word(second['output_tokens'])
            outputs.append(dict(transition_identity=identity,configuration=configuration,
                accepting=configuration['state'] in palette['machine']['accept_states'],
                rows=[first,second],placements=records,point_receipt=points))
    return outputs,len(latch_rows)

def mutant_controls(palette,records,model):
    controls=[]
    def reject(name,rs,fixed,required):
        try:literal_patch(rs,fixed,required)
        except ValueError as exc:controls.append(dict(name=name,rejected=True,reason=str(exc)));return
        raise ValueError('literal negative control accepted '+name)
    required=[[0,0,1]];zero=[dict(key=['literal-fixture'],t=[[0,0,1]],m=[['fixture',0,1,0]])]
    literal_patch(zero,[],required);literal_patch(zero,[['fixture',0,1,0]],required)
    reject('assigned_zero_is_not_absent',zero,[['fixture',0,1,1]],required)
    literal_patch([dict(key=['absent-fixture'],t=[[0,0,1]],m=[])],[['fixture',0,1,0]],required)
    controls.append(dict(name='absent_channel_is_unconstrained_and_zero_assigned',passed=True))
    for channel in ('horizontal_window','vertical_symbol','vertical_phase'):
        counts=collections.Counter(tuple(mark[:3]) for r in records for mark in r['m'])
        shared=next(p for p,n in counts.items() if p[0]==channel and n>=2)
        rs=clone(records)
        changed=False
        for r in rs:
            for m in r['m']:
                if tuple(m[:3])==shared:
                    m[3]=(m[3]+1)%len(palette['colors'][channel]);changed=True;break
            if changed:break
        reject('literal_'+channel+'_mismatch',rs,model['fixed_m'],model['required_t'])
    # Raw marking fixtures above do not mutate or become compiled palette tiles.
    return controls

def main():
    began=time.perf_counter();need(len(sys.argv)==4 and sys.argv[1]==COMMAND,'one cold TM control invocation')
    pp,op=(Path(x) for x in sys.argv[2:]);need(pp.parent.parents[1]==ROOT,'flat owner/closer namespace')
    plan,output,ppin,opin,closure,owner_closure=preflight(pp,op);need(plan['inputs']==FROZEN_INPUTS,'exact original specification plus explicit fourth program supplement')
    artifacts=[];calls=collections.Counter()
    def tick():need(time.perf_counter()-began<55 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<500*1048576,'whole controls before original receipt reserves')
    def save(name,v):
        tick();raw=(canonical(v)+'\n').encode();need(len(raw)<=64*1048576,'whole bounded actual output')
        with (output/name).open('xb') as f:need(f.write(raw)==len(raw),'whole exclusive output')
        r=pin(output/name);artifacts.append(r);return r
    try:
        specification=read(plan['inputs']['specification']);supplement=read(plan['inputs']['supplement'])
        programs=clone(specification['toy_programs']);need(not set(programs)&set(supplement['additional_programs']),'additive distinct program')
        programs.update(supplement['additional_programs']);need(sorted(programs)==PROGRAM_IDS,'exact four configured programs')
        guard_fn=unchanged_executable;guard_code=guard_fn.__code__
        need_fn=need;need_code=need_fn.__code__
        modules={};states=[];own_state=executable_state(sys.modules[__name__])
        for role in ('compiler','oracle'):
            modules[role]=load(plan['sources'][role],'_tm_controls_'+role);states.append(executable_state(modules[role]))
        anchors=dict(modules);immutable=canonical((plan,closure,owner_closure,specification,supplement,programs))
        palettes={};palette_words={}
        def guard():
            if (unchanged_executable is not guard_fn or guard_fn.__code__ is not guard_code
                or need is not need_fn or need_fn.__code__ is not need_code):
                raise ValueError('caller guard/rejection endpoint identity or code changed')
            guard_fn(own_state)
            for state in states:guard_fn(state)
            need(canonical((plan,closure,owner_closure,specification,supplement,programs))==immutable,'whole unchanged inputs/programs/plans')
            for name,palette in palettes.items():need(canonical(palette)==palette_words[name],'fresh whole palette unchanged')
            source_cache_guard(plan['sources'],modules,anchors)
            for r in [*closure.values(),*owner_closure.values()]:verify(r)
            need(pin(pp)==ppin and pin(op)==opin,'whole plans unchanged');tick()
        guard();output.mkdir();results=[];visual=[];controls=[];sample=None;relations={}
        for name in PROGRAM_IDS:
            guard();palette=modules['compiler'].compile_palette(programs[name],deadline=began+55);calls['compile_palette']+=1
            palettes[name]=palette;palette_words[name]=canonical(palette);audit=audit_palette(palette);index=row_index(palette)
            palette_pin=save(name+'-whole-palette-v1.json',palette);program_cases=[]
            for width in (1,2,3):
                for tape in itertools.product(sorted(programs[name]['alphabet']),repeat=width):
                    for head in range(width):
                        for state in sorted(programs[name]['states']):
                            tick();config=dict(tape=list(tape),head=head,state=state)
                            expected=modules['oracle'].direct_successors(programs[name],config,deadline=began+55);calls['direct_successors']+=1
                            base=modules['compiler'].finite_model(palette,list(tape),head,1,deadline=began+55);calls['finite_model']+=1
                            mode_results={}
                            for mode in ('normal','accept_scan'):
                                model=declared_boundary(base,palette,config,mode)
                                outcomes,latches=two_rows(palette,index,config,mode,model,began+55,tick)
                                actual=[{k:r[k] for k in ('transition_identity','configuration','accepting')} for r in outcomes]
                                wanted=expected if mode=='normal' else [r for r in expected if r['accepting']]
                                need(sorted(map(canonical,actual))==sorted(map(canonical,wanted)),'entire two-row relation versus direct whole tape')
                                mode_results[mode]=dict(boundary=model,outcomes=outcomes,latch_row_count=latches)
                                if sample is None and width>=2 and outcomes:sample=(palette,outcomes[0]['placements'],model)
                            record=dict(configuration=config,expected_direct=expected,modes=mode_results)
                            program_cases.append(record);relations[name,canonical(config)]=record
            guard();result_pin=save(name+'-complete-census-v1.json',dict(program=programs[name],cases=program_cases,
                complete_configuration_count=len(program_cases),all_normal_and_accept_relations_equal=True))
            normal=sum(len(r['modes']['normal']['outcomes']) for r in program_cases);accept=sum(len(r['modes']['accept_scan']['outcomes']) for r in program_cases)
            results.append(dict(program_id=name,palette=palette_pin,palette_audit=audit,census=result_pin,configurations=len(program_cases),normal_edges=normal,accept_edges=accept))
            representative=next((r for r in program_cases if r['modes']['accept_scan']['outcomes']),None)
            groups={}
            for tile in palette['tiles']:
                w=tile['logical_window'];g=canonical([w['phase'],w['mode'],w['window'][1][0],w['output'][0]])
                if g not in groups:groups[g]=tile
            visual.append(dict(program_id=name,machine=programs[name],whole_palette=palette_pin,colors=palette['colors'],
                representative_actual_tiles=list(groups.values()),representative_configuration_translation=representative,
                orientation='identity',compiled_machine_initial_state_unchanged=True,not_a_proofchecker_or_UTM=True))
        need(len(results)==4 and sum(r['configurations'] for r in results)==816,'whole preregistered census')
        # Explicit tests use declared fixture configurations, never supplied expected outcomes as row search advice.
        ndconfig=dict(tape=['_','0','_'],head=1,state=programs['nondeterministic']['initial_state']);nd=relations['nondeterministic',canonical(ndconfig)]
        forbidden=[dict(tape=['_','0','_'],head=2,state='a'),dict(tape=['_','1','_'],head=0,state='a')]
        need(all(canonical(f)!=canonical(o['configuration']) for f in forbidden for o in nd['modes']['normal']['outcomes']),'no mixed independent ND write/move choices')
        controls.append(dict(name='ND_shared_transition_no_mixed_choices',passed=True,actual_record=nd,forbidden_configurations=forbidden))
        wall=relations['deterministic',canonical(dict(tape=['0'],head=0,state='q'))]
        need(wall['modes']['normal']['outcomes']==wall['modes']['accept_scan']['outcomes']==[],'wall escape has no apply strip')
        controls.append(dict(name='finite_right_wall_escape',passed=True,actual_record=wall))
        stationary=relations['stationary-nonaccept',canonical(dict(tape=['0'],head=0,state='q'))]
        need(len(stationary['modes']['normal']['outcomes'])==1 and stationary['modes']['accept_scan']['outcomes']==[],'valid nonaccepting step rejected by OR final scan')
        controls.append(dict(name='valid_nonaccepting_stationary_step_FINAL_rejected',passed=True,actual_record=stationary))
        palette=palettes['stationary-nonaccept'];idx=row_index(palette)
        word=configuration_word(dict(tape=['0'],head=0,state='q'));first=row_joins(palette,idx,word,'plain','normal',0,0,began+55,tick)
        need(len(first)==1,'actual stationary nonaccepting latch row fixture')
        zero_scan=row_joins(palette,idx,first[0]['output_tokens'],'latched','accept_scan',0,1,began+55,tick)
        invalid=row_joins(palette,idx,first[0]['output_tokens'],'latched','accept_scan',1,1,began+55,tick)
        need(zero_scan==[] and invalid,'incoming1 would bypass OR scan if not rejected at left boundary')
        base=modules['compiler'].finite_model(palette,['0'],0,1,deadline=began+55);calls['finite_model']+=1
        model=declared_boundary(base,palette,dict(tape=['0'],head=0,state='q'),'accept_scan')
        rs=translated(palette,first[0]['tile_ids'],0)+translated(palette,invalid[0]['tile_ids'],1)
        try:literal_patch(rs,model['fixed_m'],model['required_t'])
        except ValueError as exc:controls.append(dict(name='invalid_left_scan1_rejected_by_declared_left0',rejected=True,reason=str(exc),literal_fixture_records=rs,boundary=model))
        else:raise ValueError('left scan1 boundary mutant accepted')
        need(sample is not None,'actual full patch for point mutants');controls.extend(mutant_controls(*sample))
        # Two-step padding reuses the compiled palette and declares accepting input, never recompiles machine(initial_state=a).
        palette=palettes['deterministic'];idx=row_index(palette);config=dict(tape=['0'],head=0,state='a')
        base=modules['compiler'].finite_model(palette,['0'],0,2,deadline=began+55);calls['finite_model']+=1
        fixed={(ch,x,y):v for ch,x,y,v in base['fixed_m']};fixed['vertical_symbol',0,-1]=color(palette,'vertical_symbol',['head','a','0'])
        rows=[];word=configuration_word(config)
        for y in range(4):
            phase='plain' if y%2==0 else 'latched';mode='accept_scan' if y==3 else 'normal'
            joined=row_joins(palette,idx,word,phase,mode,0,1 if y==3 else 0,began+55,tick);need(len(joined)==1,'unique absorbing accept padding strip')
            rows+=translated(palette,joined[0]['tile_ids'],y);word=joined[0]['output_tokens']
        points=literal_patch(rows,[[ch,x,y,v] for (ch,x,y),v in sorted(fixed.items())],base['required_t'])
        need(decode_word(word)==config,'absorbing padding final configuration')
        controls.append(dict(name='accept_input_override_two_step_padding',passed=True,configuration=config,placements=rows,point_receipt=points,
            original_compiled_initial_state=palette['machine']['initial_state'],no_machine_or_palette_recompile=True))
        guard();control_pin=save('mandatory-controls-v1.json',dict(controls=controls,all_passed=True,raw_mutants_are_point_fixtures_not_palette_edits=True))
        visual_pin=save('visual-data-v1.json',dict(schema='actual-two-phase-tm-point-visual-data-v1',programs=visual,controls=control_pin,
            all_tiles_and_patches_are_actual_future_generated_records=True,scope='configured finite toy machines, no proofchecker/UTM/universality/aperiodicity/infiniteplane/GCTS engine claim'))
        evidence=save('tm-wang-control-evidence-v1.json',dict(schema='two-phase-tm-palette-relation-control-evidence-v1',worker_plan=ppin,owner_plan=opin,
            sources=plan['sources'],inputs=plan['inputs'],programs=results,mandatory_controls=control_pin,visual_data=visual_pin,
            call_counts=dict(calls),complete_configuration_count=816,normal_edge_count=sum(r['normal_edges'] for r in results),accept_edge_count=sum(r['accept_edges'] for r in results),
            source_ledger=source_cache_guard(plan['sources'],modules,anchors),actual_Graph_search_RL_native_calls=0,
            native_or_proofchecker_UTM_universality_claim=False,resource_acceptance_issued=False))
        guard();save('tm-wang-control-result-v1.json',dict(schema='two-phase-tm-control-worker-receipt-v1',stage='replay',stage_completed=True,
            status='complete_configured_palette_and_literal_relations_pending_ROOT_resources',evidence=evidence,worker_plan=ppin,owner_plan=opin,
            call_counts=dict(calls),all_direct_children_terminal_and_reaped=True,direct_children_peak_sum_bytes=0,
            worker_elapsed_before_receipt_seconds=time.perf_counter()-began,worker_SELF_peak_before_receipt_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_queries=0,target_searches=0,new_RL_training=False,native_accepted=False,GCTS_engine_conformance_accepted=False,
            UTM_or_universal_proofchecker_accepted=False,resource_acceptance_issued=False))
        tick();print(canonical(dict(stage_completed=True,complete_configurations=816,scope='literal_row_relation_controls_only')),flush=True)
    except BaseException as exc:
        if output.exists():
            raw=(canonical(dict(stage='replay',stage_completed=False,status='UNKNOWN_incomplete_full_controls',error=dict(type=type(exc).__name__,message=str(exc)[:512]),
                partial_artifact_pins=artifacts,accepted_prefix=False,native_accepted=False,GCTS_or_universality_claim=False))+'\n').encode()
            with (output/'failure-v1.json').open('xb') as f:f.write(raw)
        raise

if __name__=='__main__':main()
