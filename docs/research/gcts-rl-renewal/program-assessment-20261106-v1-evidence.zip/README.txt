GCTS research program: full-scope evidence assessment

This package contains the requirement assessment, the audit driver, pinned
archive URLs and hashes, eleven fresh replay receipts and their command output.
It does not duplicate the fourteen earlier evidence archives.

Use Python 3.12 with assertions enabled. From the extracted package root:

    python3.12 -I -S -B publication/replay_v1.py

This authenticates the package, fetches the pinned evidence archives into
input/cache if necessary, authenticates their members, checks the stored replay
receipts and shared proof-palette sources, and verifies exact report rendering.
The newly linked archive additions must be deployed before the online replay
can retrieve every archive. The shape-only Turtle archive uses its verified
pinned GitHub URL, as provided by the current public notebook.

To rerun all eleven selected whole experiments from clean extractions:

    python3.12 -I -S -B publication/replay_v1.py --full

The full run recreates the audit logs and receipts. Each original experiment
must reproduce its archived deterministic files byte for byte. Machine-dependent
timing trials are excluded. The first three silhouette-recovery commands run
without the reference directory; the shape-only catalogue, collar and motif
commands run without the comparison file. Those references are restored only
for later audits.

When the original local experiment tree is available, append --source-root and
its path to either command to use those archives without downloading. Without
that option, previously downloaded files in input/cache support an offline run.

Open report/program-assessment-20261106-v1.html for the twelve objective rows,
their qualifications, the unbounded computational encoding argument, replay
tables and links to the complete original evidence. The claim about computational
expressiveness is a mathematical construction for the existing grammar; it is
not described as a theorem discovered by the search engine.
