"""Render the full-scope evidence assessment, keeping limits beside each claim."""
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
NAME = 'program-assessment-20261106-v1'


def main():
    requirements = json.loads((ROOT / 'input/requirements-v1.json').read_text())
    pins = {x['id']: x for x in json.loads((ROOT / 'input/pins-v1.json').read_text())}
    auth = json.loads((ROOT / 'data/archive-authentication-v1.json').read_text())
    receipts = {p.name.removesuffix('-receipt-v1.json'): json.loads(p.read_text())
                for p in (ROOT / 'data').glob('*-receipt-v1.json')}
    details = []
    for row in requirements:
        links = []
        for key in row['evidence']:
            pin = pins[key]
            archive = pin['url'].rsplit('/',1)[1]
            page = archive.replace('-evidence.zip','.html')
            status = 'Fresh byte-identical replay' if key in receipts else 'Authenticated archive; inspected source and prior certificates'
            links.append('<li><a href="'+page+'">'+escape(key.replace('-',' '))+'</a> — '+status+'</li>')
        details.append('<article id="'+row['id']+'"><h3>'+escape(row['title'])+'</h3>'
                       +'<p>'+escape(row['result'])+'</p><p class="limit"><b>Scope:</b> '+escape(row['limit'])+'</p>'
                       +'<details><summary>Evidence and replay scope</summary><ul>'+''.join(links)+'</ul></details></article>')
    replay_rows = ''.join('<tr><th>'+escape(key.replace('-',' '))+'</th><td>'+str(len(r['commands']))+'</td><td>'
                          +str(r['authenticated_members'])+'</td><td>Byte identical</td></tr>' for key,r in sorted(receipts.items()))
    archive_rows = ''.join('<tr><th><a href="'+p['url']+'">'+escape(p['id'].replace('-',' '))+'</a></th><td><code>'
                          +p['sha256']+'</code></td></tr>' for p in pins.values())
    body = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>What the GCTS research experiments establish</title><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script><style>
*{box-sizing:border-box}body{margin:0;background:#edf3f6;color:#183643;font:1rem/1.6 system-ui,sans-serif}main{max-width:72rem;margin:auto;padding:1rem clamp(.7rem,3vw,2rem) 3rem}header,section{background:white;border:1px solid #c4d8e1;border-radius:.7rem;padding:clamp(.9rem,3vw,1.7rem);margin-bottom:1rem}header{border-top:5px solid #247b84}h1,h2,h3{line-height:1.2}h1{font-size:clamp(2rem,5vw,3.5rem);margin:.3rem 0 .8rem}h2{margin:.2rem 0 1rem}h3{font-size:1.17rem;margin:.2rem 0 .7rem}p{margin:.3rem 0 .9rem}a,summary{color:#075c65}.kicker{font-size:.84rem;font-weight:700;color:#426575}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem}article{min-width:0;border:1px solid #cbdee5;border-radius:.5rem;padding:1rem}.limit{border-left:3px solid #9c73b9;padding:.5rem .7rem;background:#f8f3fc}summary{cursor:pointer;font-weight:600}.table,.formula{max-width:100%;overflow:auto}.table{border:1px solid #c5d9e3}table{border-collapse:collapse;min-width:100%;font-size:.94rem}td,th{text-align:left;padding:.6rem;border-bottom:1px solid #d5e3e9}th{font-weight:600}thead{background:#edf5f7}code{font:.82rem/1.5 ui-monospace,monospace}li{margin:.45rem 0}.proof-note{border-left:4px solid #247b84;padding:.5rem 1rem;background:#eef8f8}.flow{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.7rem;margin:1rem 0}.flow div{border:2px solid #338295;border-radius:.4rem;padding:.75rem;background:#eff9fc}.flow .advice{border-color:#946bb3;background:#f7f0fc}.flow small{display:block;line-height:1.4;margin-top:.3rem}.small{font-size:.86rem;color:#486471}@media(max-width:48rem){.grid{grid-template-columns:1fr}.flow{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style></head><body><main><header><p class="kicker">GCTS research program · evidence assessment · 6 November 2026</p><h1>What the experiments establish</h1>
<p>There is now a working path from unmarked tiling searches to certified failures, learned proposals and reusable clusters, and a separate path from symbolic statements to automatically found Wang proof diagrams. The prototypes have reproducible evidence. A broad practical advantage from GCTS or RL remains unproved.</p>
<p><a href="latest-verified-20261106-v1.html">Browse the research notebooks</a> · <a href="#requirements">Inspect each objective</a> · <a href="#replays">Fresh replay results</a> · <a href="''' + NAME + r'''-evidence.zip">Audit source and receipts</a></p></header>
<section><h2>Two related experiments, with separate validity checks</h2><div class="flow"><div>Unmarked shape<small>Exact Turtle coordinates on \(A_2\)</small></div><div class="advice">Failed attempts<small>Discover geometric obstruction certificates</small></div><div class="advice">Learned proposals<small>Choose tiles, orbits or move orders</small></div><div>Checked construction<small>Finite covers and a separately linked plane argument</small></div></div>
<div class="flow"><div>Formula and axioms<small>Arithmetic or symbolic Hilbert geometry</small></div><div class="advice">Search with an inventory<small>Match typed receptors and expand lemma families</small></div><div>Fixed Wang checker<small>Ground instantiation, resolution and exact copy markings</small></div><div>Readable proof rows<small>Formulas, English descriptions and actual squares</small></div></div>
<p>The common idea is to retain information from earlier work and compose checked local pieces. This is a useful design direction. It does not by itself establish an advantage over conventional constraint learning, lemma mining or given-clause provers.</p></section>
<section id="requirements"><h2>Requirement-by-requirement assessment</h2><div class="grid">''' + ''.join(details) + r'''</div></section>
<section id="expressiveness"><h2>Why the current proof grammar can encode computation</h2><p>This is our mathematical construction for the existing grammar, rather than a new theorem discovered by its search. Consider the two-counter instruction convention studied by <a href="https://doi.org/10.4230/LIPIcs.FSCD.2022.16">Dudenhefner</a>: increment advances to the next instruction; a positive decrement jumps, while zero advances. Its halting problem is undecidable.</p>
<p>For a program with finitely many labels, use one binary predicate \(A_p\) per label, a constant \(0\), a unary constructor \(S\), and a nullary predicate \(H\). The boundary contains its starting fact. An increment of the first counter has the clause</p><div class="formula">\[\neg A_p(x,y)\lor A_{p+1}(S(x),y).\]</div>
<p>A first-counter decrement with positive jump destination \(q\) has two clauses:</p><div class="formula">\[\neg A_p(S(x),y)\lor A_q(x,y),\qquad\neg A_p(0,y)\lor A_{p+1}(0,y).\]</div>
<p>Exchange arguments for the second counter. Identify every out-of-program destination with the halt label. At that label add \(\neg A_{\mathrm{halt}}(x,y)\lor H\), and deny the goal with \(\neg H\). All free clause variables are universally quantified.</p>
<p>Every machine step gives a ground instance and a resolution from the preceding configuration fact. A halting run therefore gives a finite refutation. Conversely, if the machine does not halt, interpret \(A_p(S^i(0),S^j(0))\) as true exactly for reachable configurations, and interpret \(H\) as false. This Herbrand interpretation satisfies all the clauses, so soundness rules out a refutation. Thus a finite accepting proof diagram exists exactly when the encoded computation halts.</p>
<p>The number of predicates changes the encoded boundary text, not the tile palette. Their names, terms and proof references use finite strings over the fixed tape alphabet. The same source-instantiation and resolution verifier handles these clauses and the arithmetic and geometry examples.</p>
<div class="proof-note"><p>This establishes expressiveness in the unbounded mathematical system. It neither makes all true statements provable nor makes theorem search decidable. A mathematical theory still needs specified axioms. The current <a href="wang-fair-backstop-20261106-v1.html">fair backstop</a> takes a finite clause boundary; searching an infinite axiom schema requires an additional fair enumeration of finite axiom prefixes.</p></div></section>
<section id="replays"><h2>Fresh checks against whole archived experiments</h2><p>The audit authenticated ''' + str(len(auth)) + ' archives and ' + str(sum(p['members'] for p in auth)) + r''' member hashes. It then reran the following requirements from clean extractions, preserving the archived deterministic outputs byte for byte. Machine-dependent timings were not rerun or presented as fresh timings.</p>
<div class="table" tabindex="0"><table><thead><tr><th>Experiment</th><th>Commands</th><th>Archive members</th><th>Result</th></tr></thead><tbody>''' + replay_rows + r'''</tbody></table></div>
<p>During the Turtle shape-only catalogue, collar and motif searches, the comparison file was absent. During the first three silhouette-recovery commands, the reference directory was absent. The reference inputs were restored for the separate geometric and all-level comparisons. This distinguishes discovery under the stated inputs from later reference validation.</p>
<p>The shared-palette check compares the exact machine program, compiler, tile semantics and sparse-frame verifier in four proof archives. The arithmetic replay checked all 13 searched theorems, 22 direct or induction obligations and 424 primitive records against the saved native bank. The newer geometry and fair-backstop notebooks retain their own full native replays and browser checks.</p>
<details><summary>Inspect every pinned evidence archive</summary><div class="table" tabindex="0"><table><thead><tr><th>Archive</th><th>SHA-256</th></tr></thead><tbody>''' + archive_rows + r'''</tbody></table></div></details></section>
<section><h2>The next scientific question</h2><p>The examples establish that the system can discover proofs without a human supplying each proof. They do not yet establish that the geometric organization is the reason it finds useful proofs, or that learning improves performance reliably. The clause-encoding control is particularly important: conventional direct clauses with propagation solved the same fourteen geometry cases as the mined inventory. On that representation the inventory reduced counted resolution work, with additional premise-matching work.</p>
<p>The strongest next comparison would freeze a learned inventory and test genuinely different theorem structures, accounting for donor training, matching, expanded proof checking, memory and elapsed time. Conventional propagation, conventional lemma reuse and an external prover should receive the same statements and available lemmas. Automatic decisions about which receptor families to retain or compose would then test the proposed hierarchy more directly.</p>
<p class="small">This audit records the available evidence and its limits. The open performance questions above are recorded as open findings; this page does not claim a solved general proof-search problem.</p></section></main></body></html>'''
    path = ROOT / 'report' / (NAME + '.html')
    if '--build' in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    print('Rendered', len(requirements), 'requirement assessments and', len(receipts), 'fresh whole-experiment replays')


if __name__ == '__main__':
    main()
