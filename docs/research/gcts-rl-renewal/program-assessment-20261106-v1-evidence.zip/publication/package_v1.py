"""Archive the assessment source and receipts without duplicating old evidence."""
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
NAME = 'program-assessment-20261106-v1'


def main():
    files = [ROOT / 'README.txt']
    files += sorted((ROOT / 'source').glob('*.py'))
    files += sorted((ROOT / 'input').glob('*.json'))
    files += sorted((ROOT / 'data').glob('*.json'))
    files += sorted((ROOT / 'data').glob('*.log'))
    files += [ROOT / 'report' / (NAME+'.html')]
    files += [ROOT / 'publication' / n for n in ('render_v1.py','package_v1.py','replay_v1.py','browser_v1.cjs','browser-v1.log')]
    manifest = {str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in files}
    path = ROOT / 'report' / (NAME+'-evidence.zip')
    with ZipFile(path, 'w', ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            z.writestr(str(p.relative_to(ROOT)), p.read_bytes())
        z.writestr('MANIFEST.json', json.dumps(manifest,sort_keys=True,indent=2)+'\n')
    print('Packaged',len(files),'audit files;',path.stat().st_size,'bytes;',sha256(path.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
