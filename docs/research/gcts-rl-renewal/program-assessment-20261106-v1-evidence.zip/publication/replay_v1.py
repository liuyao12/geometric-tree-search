"""Verify the audit package; optionally repeat all whole-experiment checks."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    if not __debug__:
        raise RuntimeError('Replay requires assertions')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--full', action='store_true')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for name, digest in manifest.items():
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert sha256((ROOT / path).read_bytes()).hexdigest() == digest, name
    command = [sys.executable, '-I', '-S', '-B', 'source/audit_v1.py']
    if args.source_root:
        command += ['--source-root', str(args.source_root)]
    subprocess.run(command, cwd=ROOT, check=True)
    pins = {p['id']: p for p in json.loads((ROOT / 'input/pins-v1.json').read_text())}
    receipts = []
    for path in sorted((ROOT / 'data').glob('*-receipt-v1.json')):
        row = json.loads(path.read_text())
        assert row['status'] == 'BYTE_IDENTICAL_REPLAY'
        assert row['archive_sha256'] == pins[row['id']]['sha256']
        log = ROOT / 'data' / (row['id'] + '-replay-v1.log')
        assert sha256(log.read_bytes()).hexdigest() == row['log_sha256']
        if row['id'] == 'turtle-silhouette-recovery':
            assert row['reference_hidden_during_first_three_commands']
        if row['id'] == 'turtle-shape-only-bases':
            assert row['comparison_hidden_during_shape_search']
        receipts.append(row)
    assert len(receipts) == 11
    if args.full:
        for row in receipts:
            subprocess.run([*command, '--replay', row['id']], cwd=ROOT, check=True)
    subprocess.run([sys.executable, '-I', '-S', '-B', 'publication/render_v1.py'], cwd=ROOT, check=True)
    print('Verified audit package, fourteen evidence archives, eleven replay receipts, shared palette sources and exact report rendering')


if __name__ == '__main__':
    main()
