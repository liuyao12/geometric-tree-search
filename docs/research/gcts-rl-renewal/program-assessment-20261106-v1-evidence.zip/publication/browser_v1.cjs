const assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.GCTS_PLAYWRIGHT);
async function main(){
 const browser=await chromium.launch({executablePath:process.env.GCTS_CHROME,headless:true,args:['--no-sandbox']});
 try{
  for(const width of [390,1280]){
   const page=await browser.newPage({viewport:{width,height:900}}),errors=[];
   page.on('pageerror',e=>errors.push(e.message));
   await page.goto(pathToFileURL(process.cwd()+'/report/program-assessment-20261106-v1.html').href,{waitUntil:'load',timeout:60000});
   await page.locator('#expressiveness mjx-container').first().waitFor({timeout:60000});
   assert.equal(await page.locator('#requirements article').count(),12);
   assert.equal(await page.locator('#replays table').first().locator('tbody tr').count(),11);
   assert.equal(await page.locator('#replays details tbody tr').count(),14);
   assert.equal(await page.locator('mjx-merror').count(),0);
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),width);
   assert.deepEqual(errors,[]);
   await page.screenshot({path:`publication/preview-top-${width}.png`});
   await page.locator('#requirements').scrollIntoViewIfNeeded();
   await page.screenshot({path:`publication/preview-requirements-${width}.png`});
   await page.locator('#expressiveness').scrollIntoViewIfNeeded();
   await page.screenshot({path:`publication/preview-expressiveness-${width}.png`});
   console.log('Verified',width,'px, twelve requirements, eleven replays, fourteen archives, typeset construction and no overflow or page errors');
   await page.close();
  }
 }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1});
