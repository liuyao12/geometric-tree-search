"""Authenticate the program's evidence and replay a selected whole requirement."""
import argparse
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
from tempfile import TemporaryDirectory
from urllib.request import Request, urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
TASKS = {
    'turtle-silhouette-recovery': ['source/silhouette_study_v1.py', 'source/silhouette_predict_v1.py',
                                   'source/silhouette_audit_v1.py', 'source/reference_replay_v1.py',
                                   'source/silhouette_validate_v1.py'],
    'penrose-centered-cycles': ['source/center_v1.py'],
    'wang-multiplication': ['source/mul_study_v1.py', 'source/mul_wang_v1.py'],
    'wang-conditional-clusters': ['source/family_study_v1.py', 'source/family_controls_v1.py'],
    'wang-rewrite-rl': ['source/rl_study_v1.py'],
    'turtle-shape-only-bases': ['source/assemble_v1.py', 'source/collar_experiment_v1.py',
                              'source/motif_inventory_v1.py', 'source/collar_audit_v1.py'],
    'turtle-receptor-policy': ['source/move_policy_study_v1.py', 'source/targeted_policy_v1.py'],
    'penrose-arrow-classes': ['source/arrow_classes_v1.py', 'source/arrow_audit_v1.py'],
    'turtle-area-budget': ['source/area_study_v1.py'],
    'penrose-area-budget': ['source/rhomb_study_v1.py'],
    'turtle-convex-boundary': ['source/convex_search_v1.py', 'source/convex_audit_v1.py',
                               'source/convex_wang_v1.py', 'source/movable_v1.py'],
}


def authenticate(archive, pin):
    raw = archive.read_bytes()
    assert len(raw) == pin['bytes'] and sha256(raw).hexdigest() == pin['sha256'], pin['id']
    with ZipFile(archive) as z:
        for info in z.infolist():
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts and '\\' not in info.filename
            assert (info.external_attr >> 28) != 10
        if 'MANIFEST.json' in z.namelist():
            manifest = json.loads(z.read('MANIFEST.json'))
            assert set(z.namelist()) == set(manifest) | {'MANIFEST.json'}
            for name, digest in manifest.items():
                assert sha256(z.read(name)).hexdigest() == digest, name
        else:
            manifest = {n: sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
    return manifest


def shared_palette(archives):
    out = {}
    for name in ('wang-multiplication', 'wang-rewrite-rl', 'wang-conditional-clusters', 'wang-direct-hilbert-control'):
        with ZipFile(archives[name]) as z:
            row = {}
            for basename in ('boundary_kernel_v1.py', 'marker_tm_v1.py', 'tiles_v1.py', 'sparse_frame_v1.py'):
                hashes = {sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('/' + basename)}
                assert len(hashes) == 1, (name, basename)
                row[basename] = hashes.pop()
        out[name] = row
    assert all(row == next(iter(out.values())) for row in out.values())
    (ROOT / 'data/shared-palette-source-v1.json').write_text(json.dumps(out, sort_keys=True, indent=2)+'\n')


def replay(archive, pin):
    manifest = authenticate(archive, pin)
    with TemporaryDirectory(prefix='gcts-program-audit-') as tmp:
        target = Path(tmp)
        with ZipFile(archive) as z:
            z.extractall(target)
        tasks = TASKS[pin['id']]
        reference = target / 'reference'
        withheld = target / 'withheld-reference'
        unmarked = pin['id'] == 'turtle-silhouette-recovery'
        shape_only = pin['id'] == 'turtle-shape-only-bases'
        if unmarked:
            reference.rename(withheld)
        comparison = target / 'input/comparison-v1.json'
        held_comparison = target / 'comparison-held-back.json'
        if shape_only:
            comparison.rename(held_comparison)
        log_path = ROOT / 'data' / (pin['id'] + '-replay-v1.log')
        with log_path.open('w') as log:
            for i, task in enumerate(tasks):
                if unmarked and i == 3:
                    withheld.rename(reference)
                if shape_only and i == 3:
                    held_comparison.rename(comparison)
                print('Replaying', pin['id'], task, flush=True)
                subprocess.run([sys.executable, '-I', '-S', '-B', task], cwd=target,
                               stdout=log, stderr=subprocess.STDOUT, check=True)
        for name, digest in manifest.items():
            assert sha256((target / name).read_bytes()).hexdigest() == digest, name
    result = dict(id=pin['id'], archive_sha256=pin['sha256'], status='BYTE_IDENTICAL_REPLAY',
                  authenticated_members=len(manifest), commands=tasks,
                  reference_hidden_during_first_three_commands=unmarked,
                  comparison_hidden_during_shape_search=shape_only,
                  log_sha256=sha256(log_path.read_bytes()).hexdigest())
    (ROOT / 'data' / (pin['id'] + '-receipt-v1.json')).write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
    print(json.dumps(result), flush=True)


def main():
    if not __debug__:
        raise RuntimeError('Audit requires assertions')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path)
    parser.add_argument('--replay', choices=tuple(TASKS))
    args = parser.parse_args()
    pins = json.loads((ROOT / 'input/pins-v1.json').read_text())
    rows, archives = [], {}
    for pin in pins:
        if args.replay and pin['id'] != args.replay:
            continue
        if args.source_root:
            archive = args.source_root / pin['relative']
        else:
            cache = ROOT / 'input/cache'
            cache.mkdir(exist_ok=True)
            archive = cache / Path(pin['relative']).name
            if not archive.exists():
                with urlopen(Request(pin['url'], headers={'User-Agent':'GCTS-program-audit'}), timeout=60) as response:
                    raw = response.read()
                assert sha256(raw).hexdigest() == pin['sha256']
                archive.write_bytes(raw)
        manifest = authenticate(archive, pin)
        archives[pin['id']] = archive
        rows.append(dict(id=pin['id'], archive_sha256=pin['sha256'], members=len(manifest)))
        if args.replay:
            replay(archive, pin)
    if not args.replay:
        shared_palette(archives)
        (ROOT / 'data/archive-authentication-v1.json').write_text(json.dumps(rows, sort_keys=True, indent=2)+'\n')
        print('Authenticated', len(rows), 'whole archives and', sum(r['members'] for r in rows), 'member hashes')


if __name__ == '__main__':
    main()
