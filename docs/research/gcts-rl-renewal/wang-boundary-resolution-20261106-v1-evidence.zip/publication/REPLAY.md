# Replay the fixed Wang proof notebook

Use Python 3.12 with its standard library. In an extracted copy, preserve
the supplied evidence and run from the archive root.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/study_v1.py
    python3.12 -I -S -B source/audit_v1.py
    python3.12 -I -S -B publication/render_v1.py

The study uses the same fixed verifier for all examples. Its resource
caps and ground search depths are in the study source. The Hilbert case
contains billions of implied transitions. Replay the sweep certificates
directly or use the included verifier. The audit expands every literal
square only for the small qualification case.

The replay receipt gives hashes for the seven scientific outputs. On
slower machines, reaching the process-time search cap before the declared
clause cap can change a bounded search's statistics. The supplied proof
text and sparse frame certificates can be checked independently of search.

The HTML uses MathJax. To run the browser qualification, set
`GCTS_CHROME` and `GCTS_PLAYWRIGHT` for a custom installation and invoke
the included `publication/check_v1.cjs` with Node.js.

The source programs adapt the earlier first-order grounding study and
the generic framed Wang construction. The fixed normalized source
clauses are regenerated from the original formulas during the audit.
All proof strings are decoded before they are used in the reader.
