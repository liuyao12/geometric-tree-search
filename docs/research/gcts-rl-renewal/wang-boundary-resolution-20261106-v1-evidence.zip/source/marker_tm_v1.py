"""Compile a finite program over position markers to one tape.

Each input character is followed by one slot per marker. The frame fixes all
marker slots. A machine instruction relocates, reads, or compares markers by
scanning the tape. Omitted state-symbol pairs reject.
"""
from hashlib import sha256
import json

DATA = "01.()%,:;#+-=!/CGR~"
FREE = "01.():;+-=!/GR~"
FIRST, LAST, EDGE, SLOT = ">", "$", "@", "_"


class Program:
    def __init__(self, markers):
        self.markers = tuple(markers)
        self.code = {}
        self.serial = 0

    def fresh(self, hint):
        self.serial += 1
        return f"{hint}.{self.serial}"

    def add(self, label, *op):
        assert label not in self.code
        self.code[label] = op

    def read(self, label, p, cases, default="reject"):
        self.add(label, "read", p, dict(cases), default)

    def move(self, label, p, n, dest):
        self.add(label, "move", p, n, dest)

    def copy(self, label, p, q, dest):
        assert p != q
        self.add(label, "copy", p, q, dest)

    def same(self, label, p, q, yes, no):
        assert p != q
        self.add(label, "same", p, q, yes, no)

    def expect(self, label, p, chars, dest):
        go = self.fresh("advance")
        self.read(label, p, dict.fromkeys(chars, go))
        self.move(go, p, 1, dest)

    def scan(self, label, p, allowed, stops, default="reject"):
        assert not set(allowed) & stops.keys()
        go = self.fresh("scan")
        self.read(label, p, {**dict.fromkeys(allowed, go), **stops}, default)
        self.move(go, p, 1, label)

    def compare(self, label, p, q, chars, end_p, end_q, yes, no):
        """Destructive comparison of strings with distinct allowed terminators."""
        go_p, go_q = self.fresh("compare-move"), self.fresh("compare-move")
        self.move(go_p, p, 1, go_q)
        self.move(go_q, q, 1, label)
        test = self.fresh("compare-end")
        self.read(test, q, dict.fromkeys(end_q, yes), no)
        choices = dict.fromkeys(end_p, test)
        for char in chars:
            case = self.fresh("compare-char")
            choices[char] = case
            self.read(case, q, {char: go_p}, no)
        self.read(label, p, choices, no)

    def number(self, label, p, stop, dest):
        more = self.fresh("digits")
        take = self.fresh("separator")
        self.expect(label, p, "01", more)
        self.scan(more, p, "01", {stop: take})
        self.move(take, p, 1, dest)

    def compile(self):
        return Compiler(self).build()


class Compiler:
    def __init__(self, program):
        self.p = program
        self.marks = {p: f"h:{p}" for p in program.markers}
        self.alphabet = tuple(DATA + FIRST + LAST + EDGE + SLOT) + tuple(self.marks.values())
        assert len(set(self.alphabet)) == len(self.alphabet)
        self.rules = {}
        self.serial = 0
        self.offset = {p: i + 1 for i, p in enumerate(program.markers)}
        self.width = 1 + len(self.offset)

    def new(self):
        self.serial += 1
        return f"@{self.serial}"

    def put(self, q, a, nxt, write=None, move=0):
        assert (q, a) not in self.rules
        self.rules[q, a] = (nxt, a if write is None else write, move)

    def find(self, label, p, action):
        find = self.new()
        mark = self.marks[p]
        for a in self.alphabet:
            if a == FIRST:
                self.put(label, a, find, move=1)
            else:
                self.put(label, a, label, move=-1)
            if a == mark:
                self.put(find, a, action)
            elif a != EDGE:
                self.put(find, a, find, move=1)

    def walk(self, q, count, dest, start=None):
        # A zero-distance move is useful when reading adjacent marker slots.
        sign = 1 if count > 0 else -1 if count < 0 else 0
        for i in range(max(1, abs(count))):
            following = dest if i + 1 >= abs(count) else self.new()
            for a in self.alphabet:
                if a == EDGE:
                    continue
                if i == 0 and start is not None:
                    before, after = start
                    if a != before:
                        continue
                    self.put(q, a, following, after, sign)
                else:
                    self.put(q, a, following, move=sign)
            q = following

    def build(self):
        for label, ins in self.p.code.items():
            kind, p, *args = ins
            at = self.new()
            if kind == "copy":
                target, dest = args
                seek_p, on_p, on_target = self.new(), self.new(), self.new()
                self.find(label, target, at)
                self.put(at, self.marks[target], seek_p, SLOT)
                self.find(seek_p, p, on_p)
                self.walk(on_p, self.offset[target] - self.offset[p], on_target)
                self.put(on_target, SLOT, dest, self.marks[target])
                continue
            self.find(label, p, at)
            if kind == "read":
                cases, default = args
                on = self.new()
                self.walk(at, -self.offset[p], on)
                for a in DATA + FIRST + LAST:
                    self.put(on, a, cases.get(a, default))
            elif kind == "move":
                n, dest = args
                on = self.new()
                m = self.marks[p]
                self.walk(at, n * self.width, on, (m, SLOT))
                self.put(on, SLOT, dest, m)
            else:
                assert kind == "same"
                target, yes, no = args
                on = self.new()
                self.walk(at, self.offset[target] - self.offset[p], on)
                self.put(on, SLOT, no)
                self.put(on, self.marks[target], yes)
        states = set(self.p.code) | {"accept", "reject"}
        states.update(q for q, _ in self.rules)
        assert {q for q, _, _ in self.rules.values()} <= states
        names = ["accept", "reject"] + sorted(states - {"accept", "reject"})
        ids = {name: i for i, name in enumerate(names)}
        table = {(ids[q], a): (ids[n], w, m) for (q, a), (n, w, m) in self.rules.items()}
        return Machine(table, names, self.alphabet, self.marks, ids["start"])


class Machine:
    def __init__(self, rules, names, alphabet, marks, start):
        self.rules, self.names, self.alphabet, self.marks, self.start = rules, names, alphabet, marks, start

    def delta(self, q, symbol):
        if q in (0, 1):
            return q, symbol, 0
        return self.rules.get((q, symbol), (1, symbol, 0))

    def input(self, prefix, certificate, padding=0):
        assert prefix.startswith(FIRST) and prefix.endswith("#") and set(prefix[1:]) <= set(DATA)
        assert set(certificate) <= set(FREE)
        tokens = prefix + certificate + "~" * padding + LAST
        tape, open_columns = [], []
        for i, token in enumerate(tokens):
            if len(prefix) <= i < len(tokens) - 1:
                open_columns.append(len(tape))
            tape.append(token)
            tape.extend(self.marks.values() if not i else [SLOT] * len(self.marks))
        tape.append(EDGE)
        return tape, open_columns

    def digest(self):
        body = [self.names, self.alphabet, list(self.marks), self.start,
                sorted((q, a, n, w, m) for (q, a), (n, w, m) in self.rules.items())]
        return sha256(json.dumps(body, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
