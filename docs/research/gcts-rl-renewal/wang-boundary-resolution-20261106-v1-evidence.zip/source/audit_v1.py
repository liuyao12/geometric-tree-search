"""Audit raw proof decoding, trace qualification, and a finite countermodel."""
from itertools import pairwise
import gzip
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import decode_v1 as decoder
import study_v1 as study
from marker_tm_v1 import FREE
from sparse_frame_v1 import FixedPalette, execute
import tiles_v1 as til


def full_frame(machine):
    prefix, proof = ">C0:;#", "G0:0:/;!"
    tape, free = machine.input(prefix, proof)
    colors = [("input", "free") if i in free else ("input", "fixed", a)
              for i, a in enumerate(tape)]
    colors[0] = ("input", "head", tape[0])
    palette = FixedPalette(machine)
    q, head, rows = machine.start, 0, 0
    old = [til.cell(a, q if i == 0 else None) for i, a in enumerate(tape)]
    north = [("top", "left"), *colors, ("top", "right")]

    def check(row):
        nonlocal north, rows
        assert [tile[0] for tile in row] == north
        assert row[0][3] == til.OL and row[-1][1] == til.OR
        assert all(a[1] == b[3] for a, b in pairwise(row))
        assert all(map(palette.allows, row))
        north = [tile[2] for tile in row]
        rows += 1

    check([(("top", "left"), til.LINK, til.FL, til.OL),
           *(palette.top(n, c) for n, c in zip(colors, old, strict=True)),
           (("top", "right"), til.OR, til.FR, til.LINK)])
    while q not in (0, 1):
        assert rows < 100_000
        q, tape[head], move = machine.delta(q, tape[head])
        head += move
        nxt = [til.cell(a, q if i == head else None) for i, a in enumerate(tape)]
        padded = [til.L, *old, til.R]
        core = [palette.local(a, b, c, d) for a, b, c, d in
                zip(padded, old, padded[2:], nxt)]
        check([(til.FL, til.pair(til.L, old[0]), til.FL, til.OL), *core,
               (til.FR, til.OR, til.FR, til.pair(old[-1], til.R))])
        old = nxt
    assert q == 0
    check(palette.cap(old))
    assert set(north) == {til.OB}
    sparse = execute(machine, prefix, proof, 0, rows)
    assert sparse["steps"] + 2 == rows
    return dict(columns=len(north), rows=rows, squares=rows*len(north))


def differential(machine):
    trials = [
        (">C0:;#", "G0:0:/;!"),
        (">C0:+(0.);C1:-(0.);#", "G0:0:/+(0.);G1:1:/-(0.);R10:0:1:(0.)/;!"),
        (">C0:+(0.%1,%1,);C1:-(0.(1.)(1.));#",
         "G0:0:=1:(1.)/+(0.(1.)(1.));G1:1:/-(0.(1.)(1.));R10:0:1:(0.(1.)(1.))/;!"),
        (">C0:+(0.);C1:-(0.);#", "G0:0:/+(0.);G1:1:/-(0.);R10:0:1:(0.)/+(1.);!"),
    ]
    rng = random.Random(83271)
    cases = set(trials)
    for prefix, word in trials:
        for _ in range(35):
            i = rng.randrange(len(word))
            choice = rng.choice(FREE)
            cases.add((prefix, rng.choice((word[:i]+choice+word[i+1:],
                                          word[:i]+word[i+1:], word[:i]+choice+word[i:]))))
    counts = {"accepted": 0, "rejected": 0}
    for prefix, word in sorted(cases):
        expected = decoder.accepts(prefix, word)
        got = execute(machine, prefix, word, 0, 10_000_000)["status"]
        assert got == ("ACCEPT" if expected else "REJECT"), (prefix, word, expected, got)
        counts["accepted" if expected else "rejected"] += 1
    return counts


def archive_rows(machine):
    results = json.loads((ROOT / "data/results-v1.json").read_text())
    assert results["machine_sha256"] == machine.digest()
    count = 0
    for result in results["rows"]:
        if result["status"] != "PROVED":
            continue
        with gzip.open(ROOT / "data" / result["evidence"], "rt") as stream:
            certificate = json.load(stream)
        assert certificate["machine_sha256"] == machine.digest()
        case = result["source"]
        normal, _ = study.front_v1.clausify(case, 1024)
        functions, predicates, schemas = study.fol.signature(normal)
        source, type_ids = study.guarded(schemas, functions, normal["sorts"])
        builder = study.Certificate(source, functions, predicates, normal["sorts"], type_ids)
        assert builder.prefix() == certificate["prefix"]
        decoded = decoder.read(certificate["prefix"], certificate["word"])
        assert len(decoded) == len(result["lines"])
        for raw, known in zip(decoded, result["lines"], strict=True):
            assert raw["rule"] == known["rule"]
            expected = [(p, decoder.single(builder.token(a, {}))) for p, a in known["clause"]]
            assert raw["clause"] == expected
            if raw["rule"] == "R":
                assert all(raw[k] == known[k] for k in ("left", "right"))
                assert raw["pivot"] == decoder.single(builder.token(known["pivot"], {}))
            else:
                schema = source[known["source"]]
                names = builder.variable_names(schema)
                assert raw["schema"] == bin(builder.ids[known["source"]])[2:]
                assert raw["substitution"] == {names[v]: decoder.single(builder.token(t, {}))
                                                for v, t in known["bindings"].items()}
            count += 1
    return count


def main():
    machine = study.build().compile()
    domain = (0, 1)
    relation = {(0, 0), (1, 1)}
    antecedent = all(any((x, y) in relation for y in domain) for x in domain)
    consequent = any(all((x, y) in relation for x in domain) for y in domain)
    assert antecedent and not consequent
    audit = dict(status="CHECKED_BOUNDARY_PROOF_AUDIT", machine_sha256=machine.digest(),
                 fully_expanded=full_frame(machine), differential=differential(machine),
                 independently_decoded_rows=archive_rows(machine),
                 quantifier_swap_countermodel={"domain": domain, "relation": sorted(relation)})
    (ROOT/"data"/"audit-v1.json").write_text(json.dumps(audit, sort_keys=True, indent=2)+"\n")
    print(json.dumps(audit, sort_keys=True))


if __name__ == "__main__":
    main()
