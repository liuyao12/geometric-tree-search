"""Draw the recovered Turtle productions, held predictions and Wang control."""
import gzip
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/source"), str(ROOT / "publication")]
from boundary_kernel_v1 import build
from collar_audit_v1 import freeze
from geometry_v1 import Turtle, area
from macro_outline_v1 import transform_ring
from proof_views_v1 import frame_window, math, tile_svg
from silhouette_study_v1 import read
from silhouette_wang_v1 import prepare, problem

NAME = "turtle-silhouette-recovery-20261106-v1"
COLORS = {"P": "#8bc8cb", "T": "#b69adb", "S": "#f2bd63"}
ORDER = ("P0", "T1", "S1", "S2", "P1", "T2", "P2", "T3", "P3", "T4", "P4")


def table(headers, rows, ident=""):
    head = "".join(f'<th scope="col">{x}</th>' for x in headers)
    body = "".join("<tr>" + "".join(f"<td>{x}</td>" for x in row) + "</tr>" for row in rows)
    attr = f' id="{ident}"' if ident else ""
    return f'<div class="table" tabindex="0"{attr}><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def xy(p):
    x, y = p
    return x+y/2, -sqrt(3)*y/2


def polygon(ring, color, width=.16, stroke="#48616d"):
    coords = " ".join(f"{x:.4f},{y:.4f}" for x, y in map(xy, ring))
    return f'<polygon points="{coords}" fill="{color}" stroke="{stroke}" stroke-width="{width}"/>'


def diagram(ring, shapes, caption, pad=1.5):
    x, y = zip(*map(xy, ring))
    view = f"{min(x)-pad:.4f} {min(y)-pad:.4f} {max(x)-min(x)+2*pad:.4f} {max(y)-min(y)+2*pad:.4f}"
    return (f'<figure><svg role="img" aria-label="{escape(caption)}" viewBox="{view}">{shapes}</svg>'
            f'<figcaption>{caption}</figcaption></figure>')


def produced(g, outlines, item, caption):
    parts = []
    for name, turn, shift in item["parts"]:
        ring = transform_ring(g, outlines[name], turn, shift)
        parts.append(polygon(ring, COLORS[name[0]], .9))
    parts.append(polygon(item["ring"], "none", 1.4))
    return diagram(item["ring"], "".join(parts), caption, pad=4)


def strip_view(g, strip, key, colors):
    ring, patch = strip["ring"], strip["patch"]
    drawn = "".join(polygon(g.poly(t), colors[t[0]], .18) for t in patch)
    return diagram(ring, drawn, f"{key} has {len(patch)} primitive placements.")


def segment(edge, color, width):
    coords = " ".join(f"{x:.4f},{y:.4f}" for x, y in map(xy, edge))
    return f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="{width}" stroke-linecap="round"/>'


def rival_view(g, outlines, rival):
    target = outlines[rival["target"]]
    proof = rival["result"]["tree"]
    r = rival["result"]["root"]
    gold, ((part, ref),) = proof[r]
    red, options = proof[ref]
    assert not options
    name, turn, shift = part
    marks = polygon(target, "#eef6f5", .5)
    marks += polygon(transform_ring(g, outlines[name], turn, shift), "#8bc8cb", .5)
    marks += segment(gold, "#b26e21", 2.1)
    marks += segment(red, "#a13853", 2.1)
    return diagram(target, marks, "The gold edge forces the teal cluster. The red edge then has no legal neighbor "
                   "with the periodic strip in the library.", 3)


def wang():
    sources, proof, _, _ = problem()
    _, calls = prepare(proof, sources)
    bank = json.loads(gzip.decompress((ROOT / "wang/data/silhouette-bank-v1.json.gz").read_bytes()))
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    rows, windows = [], []
    for i, (step, key) in enumerate(zip(proof, calls, strict=True), 1):
        clause = step["clause"]
        if not clause:
            text, formula = "No partition exists with this library.", r"\bot"
        elif clause[0][0]:
            text, formula = "The first edge forces the teal cluster.", r"C_1"
        else:
            text, formula = "The teal cluster leaves an edge with no available neighbor.", r"\neg C_1"
        kind = "Resolve lines 2 and 1." if step["rule"] == "R" else "Import a checked edge clause."
        rows.append((i, kind, math(formula), text))
        evidence = bank["traces"][key]
        start = evidence["steps"]-5
        trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
        tiles, first = frame_window(machine, trace, start, evidence["head"])
        ids, uses = {}, []
        for y, row in enumerate(tiles):
            for x, t in enumerate(row):
                j = ids.setdefault(t, len(ids))
                uses.append(f'<use href="#wang-{i}-{j}" x="{36*x}" y="{36*y}"/>')
        defs = "".join(tile_svg(t, f"{i}-{j}") for t, j in ids.items())
        windows.append(f'<details class="wang-row"><summary>Wang squares for line {i}</summary><figure>'
                       f'<svg role="img" aria-label="Wang squares for line {i}" viewBox="0 0 324 180">'
                       f'<defs>{defs}</defs>{"".join(uses)}</svg><figcaption>Verifier rows '
                       f'{start+1:,} to {start+5:,}, tape columns {first:,} to {first+8:,}.'
                       f'</figcaption></figure></details>')
    return table(("Line", "Checked operation", "Formula", "Reading"), rows, "proof-lines"), "".join(windows)


def main():
    g = Turtle(read("input/exact-point-model-v1.json"))
    outlines = freeze(read("input/silhouettes-v1.json"))
    study = freeze(read("data/silhouette-study-v1.json"))
    audits = read("data/silhouette-audit-v1.json")
    data = freeze(read("data/silhouette-prediction-v1.json"))
    validation = read("data/silhouette-validation-v1.json")
    outlines.update({k: row["ring"] for k, row in study["strips"].items()})
    outlines["S5"] = data["strip"]
    sizes = {k: g.counts(area(outlines[k], g.cross))[0] for k in ORDER}
    cases = table(("Outline", "Primitive tiles by area", "Candidate placements", "Search visits", "Checked partitions"),
                  [(k, f"{sizes[k]:,}", f'{study["assemblies"][k]["counts"]["catalogue"]:,}',
                    study["assemblies"][k]["counts"]["visits"], audits["cases"][k]["covers"]) for k in ORDER])
    half = validation["withheld"]["P5"]
    triangle = validation["withheld"]["T5"]
    p5 = produced(g, outlines, data["prediction"]["P5"],
                  f'The predicted half-turn outline. {half["tiles"]:,} primitive tiles in {half["children"]} clusters or strips.')
    t5 = produced(g, outlines, data["prediction"]["T5"],
                  f'The predicted triangular outline. {triangle["tiles"]:,} primitive tiles in {triangle["children"]} clusters.')
    colors = dict(zip((h for h, _ in study["strip"]["letters"]), ("#86c5c8", "#eab95e"), strict=True))
    strips = "".join(strip_view(g, study["strips"][k], k, colors) for k in ("S1", "S2", "S3"))
    lines, windows = wang()
    grammar = table(("Parent", "Child", "First level", "Symmetry index", math("c"), math("u"), math("v")), [
        (math(kind + "_n"), math(role["child"] + "_{" + (f'n{role["lag"]}' if role["lag"] else "n") + "}"),
         role["first"], role["turn"], *(math(str(p)) for p in role["coeff"]))
        for kind, roles in data["grammar"].items() for role in roles])
    title = "Recovering the Turtle hierarchy from outlines"
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", title)
    head = head.replace("</style>", ".table:focus{outline:2px solid #13787b}"
                        "#predictions .grid svg{height:20rem}#strips figure{max-width:36rem;margin-bottom:.9rem}"
                        "#control>figure,#control .wang-row figure{max-width:31rem}.swatch{display:inline-block;"
                        "width:.8em;height:.8em;margin:0 .2em;border:1px solid #536778}"
                        "@media(max-width:43rem){#proof-lines table{min-width:0}"
                        "#proof-lines thead{position:absolute;clip-path:inset(50%)}"
                        "#proof-lines tr,#proof-lines td{display:block}#proof-lines tr{border-bottom:1px solid #d6e3e9}"
                        "#proof-lines td{border:0;padding:.14rem .3rem}}</style>")
    body = rf"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>{title}</h1>
<p>An unmarked Turtle solver recovered the cluster placements through level four from fixed outlines.
The fitted rule predicted two level-five outlines and matched a previously proved plane construction
coefficient by coefficient.</p>
<nav><a href="#predictions">Level-five predictions</a><a href="#strips">Learn the strips</a>
<a href="#search">Check the searches</a><a href="#plane">Plane certificate</a><a href="#control">Wang proof</a>
<a href="{NAME}-evidence.zip">Replay archive</a></nav></header>
<section id="predictions"><h2>Predict two outlines that the learner never receives</h2>
<div class="grid">{t5}{p5}</div>
<p><span class="swatch" style="background:{COLORS['P']}"></span> Half-turn clusters
<span class="swatch" style="background:{COLORS['T']}"></span> Triangular clusters
<span class="swatch" style="background:{COLORS['S']}"></span> Strips</p>
<p>The learner sees the primitive polygon, two ordered families of fixed outlines through level four,
and two small strip outlines. The references supply those silhouettes for the benchmark.
Child placements, strip letters, and level-five outlines enter only in the separate comparison.
The predicted level-five parts match the withheld placements and their exact outer boundaries.</p>
</section>
<section id="strips"><h2>Learn two strip letters and their recurrence</h2>
{strips}
<p>The first two strips were tiled with primitive Turtles. The solver inferred two oriented letters on
a common stride of \((2,2)\) in \(A_2\) coordinates. The observed words of lengths \(4\) and \(11\)
fit concatenation \(W_{{j+2}}=W_{{j+1}}W_j\), with \(W_0=0\) and \(W_1=001\).
Taking every second word gives lengths \(4,11,29,76,199\). The length-\(29\) and length-\(76\)
strip outlines close the two larger half-turn frames in the finite searches.</p>
</section>
<section id="search"><h2>Promote a solved outline to a reusable piece</h2>
<p>Primitive search fills the two base clusters and the two observed strips. The next search treats
solved lower-level outlines as pieces and tries all permitted orientations and translations.
A frontier edge supplies a finite set of ways to attach a piece. The solver never receives the number
of placements of each family or their proposed positions.</p>
{cases}
<p>The independent checker enumerates every candidate at each recorded edge, using direct exact
sample containment and overlap tests. Each finite partition is unique within its supplied library,
counting symmetric placements of the same silhouette once. The checker rejected a certificate
that omitted a legal branch.</p>
</section>
<section id="plane"><h2>Connect the inferred rule to a plane-covering proof</h2>
<p>The fitting step groups the observed placements by child family and level difference. It fits each
translation in the form \(c+uL_n+vL_{{n-1}}\), where \(L_n=\lvert W_{{2n}}\rvert\).
It chooses constant, homogeneous linear, or affine coordinates and keeps the fitted orientations.</p>
<details><summary>Inspect every fitted child placement</summary>{grammar}</details>
<p>A perturbed affine placement fit both of its training observations and diverged at level five.
The symbolic checker rejected that competing fit.</p>
<p>The finite tests supply the candidate. To verify it for all levels, the audit matches the base clusters
and strip letters to the Golden Hex construction, then checks the placement coefficients under a
change of frame and the verified child symmetries. The replayed reference certificate proves
that the nested odd triangular levels contain disks of unbounded radius. This establishes plane
coverage for the recovered production. <a href="https://arxiv.org/abs/2307.12322">Akiyama and Araki's Turtle construction</a></p>
</section>
<section id="control"><h2>Read the proof rejecting a periodic strip</h2>
{rival_view(g, outlines, study["periodic"])}
<p>The control repeats the observed length-\(4\) word and truncates it at length \(29\).
It has the same tile count as the inferred strip. The checker exhausted the resulting library on the
834-tile outline. The two checked edge clauses give a three-line refutation.</p>
{lines}
<p>Each excerpt shows the closing five verifier rows for its line. Colors mark the edges of the
translation-only Wang squares.</p>
{windows}</section>
</main></body></html>"""
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
