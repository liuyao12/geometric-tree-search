"""Fit a coordinate production from recovered partitions and predict the next outlines."""
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from collar_audit_v1 import freeze
from geometry_v1 import Turtle, check_rings, rings_from_edges, sub
from macro_outline_v1 import boundary, transform_ring
from silhouette_study_v1 import read, ring_of, save, strip_tiles


def evaluate(coeff, a, b):
    return tuple(c+x*a+y*b for c, x, y in zip(*coeff, strict=True))


def slopes(p, q):
    a, b, point = p
    c, d, other = q
    det = a*d-b*c
    assert det
    u = tuple(Fraction(d*x-b*y, det) for x, y in zip(point, other, strict=True))
    v = tuple(Fraction(a*y-c*x, det) for x, y in zip(point, other, strict=True))
    return u, v


def fit(points):
    assert len(points) >= 2
    base = points[0][2]
    if all(p == base for _, _, p in points):
        return (base, (0, 0), (0, 0)), "constant"
    u, v = slopes(*points[:2])
    coeff = (0, 0), u, v
    family = "linear"
    if any(evaluate(coeff, a, b) != p for a, b, p in points):
        a, b, base = points[0]
        u, v = slopes(*[(x-a, y-b, sub(p, base)) for x, y, p in points[1:3]])
        coeff = tuple(p-x*a-y*b for p, x, y in zip(base, u, v, strict=True)), u, v
        family = "affine"
    assert all(Fraction(k).denominator == 1 for vec in coeff for k in vec)
    result = tuple(tuple(map(int, vec)) for vec in coeff)
    assert all(evaluate(result, a, b) == p for a, b, p in points)
    return result, family


def infer(study):
    words = study["strip"]["words"]
    lengths = [len(w) for w in words[::2]]
    roles = {"T": defaultdict(list), "P": defaultdict(list)}
    for n in range(1, 5):
        for kind in ("T", "P"):
            if kind == "T" and n == 1:
                continue
            assembly = study["assemblies"][kind+str(n)]
            assert assembly["status"] == "EXHAUSTED" and len(assembly["solutions"]) == 1
            groups = defaultdict(list)
            for name, turn, shift in assembly["solutions"][0]:
                groups[name[0], int(name[1:])-n].append((shift, turn))
            for (child, lag), parts in groups.items():
                for i, (shift, turn) in enumerate(sorted(parts)):
                    roles[kind][child, lag, i].append((n, turn, shift))
    grammar = {}
    for kind, group in roles.items():
        grammar[kind] = []
        for (child, lag, i), samples in sorted(group.items()):
            first = samples[0][0]
            assert [n for n, _, _ in samples] == list(range(first, 5))
            turn, = {g for _, g, _ in samples}
            coeff, form = fit([(lengths[n], lengths[n-1], shift) for n, _, shift in samples])
            grammar[kind].append(dict(child=child, lag=lag, slot=i, first=first, turn=turn,
                                      coeff=coeff, form=form, observations=samples))
    return grammar, lengths


def positions(roles, level, a, b):
    return [(r["child"] + str(level+r["lag"]), r["turn"], evaluate(r["coeff"], a, b))
            for r in roles if level >= r["first"]]


def oriented_sum(g, polygons):
    net = Counter()
    for polygon in polygons:
        for a, b in boundary(g, polygon):
            net[min((a, b), (b, a))] += 1 if a < b else -1
    result = {e: n for e, n in net.items() if n}
    assert all(abs(n) == 1 for n in result.values())
    return frozenset(e if n == 1 else e[::-1] for e, n in result.items())


def main():
    study = freeze(read("data/silhouette-study-v1.json"))
    g = Turtle(read("input/exact-point-model-v1.json"))
    outlines = freeze(read("input/silhouettes-v1.json"))
    grammar, lengths = infer(study)
    n = 5
    strip = study["strip"]
    patch = strip_tiles(g, strip, strip["words"][2*n])
    outlines["S5"] = ring_of(g, patch)
    prediction = {}
    for kind, roles in grammar.items():
        placement = positions(roles, n, lengths[n], lengths[n-1])
        polygons = [transform_ring(g, outlines[name], turn, shift) for name, turn, shift in placement]
        edges = oriented_sum(g, polygons)
        rings = rings_from_edges(edges)
        assert rings is not None and len(rings) == 1
        check_rings(g, rings)
        prediction[kind+"5"] = dict(ring=rings[0], parts=placement)
    save("data/silhouette-prediction-v1.json", dict(grammar=grammar, lengths=lengths,
                                                  prediction=prediction, strip=outlines["S5"]))
    print("predicted", [(k, len(v["ring"]), len(v["parts"])) for k, v in prediction.items()], flush=True)


if __name__ == "__main__":
    main()
