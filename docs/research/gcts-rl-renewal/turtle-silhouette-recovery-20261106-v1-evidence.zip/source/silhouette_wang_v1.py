"""Compile an exact rejection of the periodic strip into the shared Wang checker."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from silhouette_audit_v1 import Auditor, Turtle, freeze, read
from study_v1 import Certificate


DATA = ROOT / "wang/data"


def problem():
    g = Turtle(read("input/exact-point-model-v1.json"))
    study = freeze(read("data/silhouette-study-v1.json"))
    rival = study["periodic"]
    name = rival["target"]
    outlines = freeze(read("input/silhouettes-v1.json"))
    library = {k: rival["ring"] if k == "S3" else outlines[k] for k in study["libraries"][name]}
    result = rival["result"]
    verified = Auditor(g, outlines[name], library).verify(result)
    assert verified["covers"] == 0
    tree = result["tree"]
    poses = sorted({p for _, options in tree for p, _ in options})
    atoms = {pose: "C" + str(i) for i, pose in enumerate(poses, 1)}
    sources, order = {}, []

    def collect(index, selected):
        edge, options = tree[index]
        assert edge is not None
        key = "port-" + str(index)
        clause = tuple((False, (atoms[p],)) for p in selected)
        clause += tuple((True, (atoms[p],)) for p, _ in options)
        sources[key] = dict(id=key, clause=clause, variables={})
        for p, j in options:
            collect(j, (*selected, p))
        order.append((index, key))

    collect(result["root"], ())
    c = Certificate(sources, {}, {a: [] for a in atoms.values()}, ["U"], {})
    refs = {}
    for index, key in order:
        ref = c.instance(key, {})
        for pose, j in tree[index][1]:
            ref = c.resolve(ref, refs[j], (atoms[pose],))
        refs[index] = ref
    assert not c.lines[-1]["clause"]
    return sources, frozen(c.lines), verified, {a: p for p, a in atoms.items()}


def prepare(proof, sources):
    wires, calls = {}, []
    for i, row in enumerate(proof):
        names, prefix, word = fragment(proof, i, sources, {})
        parsed = decoder.read(prefix, word + "!", require_empty=False)
        match(proof, i, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=i+1, uses=0, rule=row["rule"]))
        assert (wire["prefix"], wire["word"]) == (prefix, word)
        wire["uses"] += 1
        calls.append(key)
    return wires, calls


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    sources, expected, geometry, atoms = problem()
    proof_path, bank_path = DATA / "silhouette-proof-v1.json", DATA / "silhouette-bank-v1.json.gz"
    receipt_path = DATA / "silhouette-receipt-v1.json"
    proof = expected if rebuild else frozen(json.loads(proof_path.read_text()))
    assert proof == expected
    wires, calls = prepare(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(records=len(calls), geometry=geometry, atoms=atoms, **verify_bank(wires, bank))
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert json.loads(encoded(receipt)) == json.loads(receipt_path.read_text())
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
