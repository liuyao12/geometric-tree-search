"""Export only fixed outlines to the search and keep reference placements separate."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from collar_audit_v1 import freeze
from coordinate_v1 import children
from geometry_v1 import Turtle
from repair_v1 import expand, ring_of
from window_v1 import Hierarchy


ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return freeze(json.loads((ROOT / name).read_text()))


def write(name, item):
    (ROOT / name).write_text(json.dumps(item, sort_keys=True, separators=(",", ":")) + "\n")


def main():
    g = Turtle(json.loads((ROOT / "input/exact-point-model-v1.json").read_text()))
    rule = read("reference/coordinate-v1.json")["rule"]
    alphabet = read("reference/recovered-production-v1.json")["alphabet"]
    atlas = Hierarchy(g.model, rule, alphabet)
    atlas.ensure(5)
    keys = [("P", 0), ("T", 1), ("S", 1), ("S", 2)]
    keys += [(kind, n) for n in range(1, 5) for kind in ("P", "T") if (kind, n) != ("T", 1)]
    rings, reference = {}, {}
    for kind, n in (*keys, ("S", 3), ("S", 4), ("S", 5), ("T", 5), ("P", 5)):
        key = kind + str(n)
        tiles = expand(atlas, ((kind, n), 0, (0, 0)))
        ring = ring_of(g, tiles)
        assert ring
        rings[key] = ring
        if kind != "S" and (kind, n) not in (("P", 0), ("T", 1)):
            a, b = atlas.lengths[2*n], atlas.lengths[2*n-2]
            steps = children(g.model, rule, kind, n, a, b)
            reference[key] = [(k + str(j), h, p) for k, j, h, p in steps]
        print(key, len(ring), len(tiles), flush=True)
    write("input/silhouettes-v1.json", {kind + str(n): rings[kind + str(n)] for kind, n in keys})
    write("reference/placements-v1.json", dict(steps=reference, strips={k: rings[k] for k in ("S3", "S4", "S5")},
                                               withheld={k: rings[k] for k in ("T5", "P5")}))


if __name__ == "__main__":
    main()
