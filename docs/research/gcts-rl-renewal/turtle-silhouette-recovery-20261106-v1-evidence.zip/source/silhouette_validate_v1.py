"""Compare learned coordinates symbolically with the proved all-level recurrence."""
from collections import Counter
from itertools import product
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry
from bridge_v1 import affine_rows, conjugate, reference, signature
from cluster_v1 import mat
from collar_audit_v1 import freeze
from geometry_v1 import Turtle, area
from golden_geometry_v1 import strip as golden_strip, words as golden_words
from macro_outline_v1 import boundary, transform_ring
from scaffold_v1 import centred
from silhouette_predict_v1 import evaluate, oriented_sum
from silhouette_study_v1 import read, save, strip_tiles


SYMMETRY = {"P": (0, 6), "T": (0, 3, 4), "S": (0,)}


def pieces(g, outlines, placements):
    return Counter((k, boundary(g, transform_ring(g, outlines[k], h, p))) for k, h, p in placements)


def verify_finite(g, outlines, study, derived):
    reference_cases = freeze(read("reference/placements-v1.json"))
    counts = {}
    for key, steps in reference_cases["steps"].items():
        if key not in study["assemblies"]:
            continue
        found, = study["assemblies"][key]["solutions"]
        assert pieces(g, outlines, found) == pieces(g, outlines, steps)
        counts[key] = len(found)
    for name, ring in reference_cases["strips"].items():
        observed = derived["strip"] if name == "S5" else outlines[name]
        assert boundary(g, observed) == boundary(g, ring)
    outlines["S5"] = derived["strip"]
    predicted = {}
    for key, row in derived["prediction"].items():
        target = reference_cases["withheld"][key]
        polygons = [transform_ring(g, outlines[k], h, t) for k, h, t in row["parts"]]
        assert oriented_sum(g, polygons) == boundary(g, target) == boundary(g, row["ring"])
        assert pieces(g, outlines, row["parts"]) == pieces(g, outlines, reference_cases["steps"][key])
        tile_mass = g.counts(area(row["ring"], g.cross))
        assert tile_mass is not None
        predicted[key] = dict(tiles=tile_mass[0], edges=len(boundary(g, target)), children=len(row["parts"]))
    return counts, predicted


def symbolic(g, study, grammar):
    model = g.model
    geom = Geometry(model)
    bases = freeze(read("reference/reference-bases-v1.json"))
    frames = {}
    for k, name in (("P", "P0"), ("T", "T1")):
        solved, = study["assemblies"][name]["solutions"]
        patch = tuple(sorted((h, *p) for _, h, p in solved))
        assert all(geom.moved(patch, h) == patch for h in SYMMETRY[k])
        target = centred(geom, bases[name])
        frames[k] = [h for h in model.groups if geom.moved(patch, h) == target]
    rule = study["strip"]
    assert rule["words"][:2] == ((0,), (0, 0, 1))
    assert tuple(tuple(map(int, w)) for w in golden_words(11)[:len(rule["words"])]) == rule["words"]
    alphabet_witnesses = ((0,), (1,), (0, 0), (1, 1))
    frames["S"] = [h for h in model.groups if all(
        geom.moved(strip_tiles(g, rule, word), h) == tuple(sorted(golden_strip("".join(map(str, word)))))
        for word in alphabet_witnesses)]
    checked = {}
    pairs = {}
    for kind, n in (("P", 1), ("P", 2), ("P", 3), ("T", 2), ("T", 3)):
        earlier = [(r["child"], n+r["lag"], r["turn"], r["coeff"])
                   for r in grammar[kind] if n >= r["first"]]
        assert all(r["first"] <= 3 for r in grammar[kind])
        target = affine_rows(lambda a, b: reference(model, kind, n, a, b))
        assert len(target) == len(earlier)
        for h in SYMMETRY[kind]:
            turned = [(k, j, model.compose[h, turn], tuple(mat(model.groups[h], p) for p in terms))
                      for k, j, turn, terms in earlier]
            assert signature(model, turned, SYMMETRY) == signature(model, earlier, SYMMETRY)
        pairs[kind, n] = earlier, target
        checked[kind+str(n)] = dict(slots=len(earlier), covers_all_later_levels=n == 3)
    matches = []
    for p, t, s in product(frames["P"], frames["T"], frames["S"]):
        candidate = dict(P=p, T=t, S=s)
        if all(signature(model, conjugate(model, inferred, k, candidate), SYMMETRY)
               == signature(model, target, SYMMETRY) for (k, _), (inferred, target) in pairs.items()):
            matches.append(candidate)
    assert matches
    for kind, turn in matches[0].items():
        inverse = next(h for h in model.groups if model.compose[turn, h] == 0)
        assert {model.compose[model.compose[turn, h], inverse] for h in SYMMETRY[kind]} == set(SYMMETRY[kind])
    return dict(frames=matches[0], alternatives=len(matches), cases=checked, symmetry=SYMMETRY)


def affine_control(g, study, prediction):
    original = prediction["grammar"]
    late = next(i for i, r in enumerate(original["P"]) if r["first"] == 3)
    role = original["P"][late]
    lengths = prediction["lengths"]
    a, b, c = lengths[2:5]
    null = (b*b-a*c, a-b, c-b)
    adjusted = tuple((x+d, y) for (x, y), d in zip(role["coeff"], null, strict=True))
    for n, _, p in role["observations"]:
        assert evaluate(adjusted, lengths[n], lengths[n-1]) == p
    at_five = evaluate(adjusted, lengths[5], lengths[4])
    assert at_five != evaluate(role["coeff"], lengths[5], lengths[4])
    modified = dict(original, P=list(original["P"]))
    modified["P"][late] = dict(role, coeff=adjusted)
    try:
        symbolic(g, study, modified)
    except AssertionError:
        return dict(training_matches=len(role["observations"]), rejected=True)
    raise AssertionError("Accepted a competing affine fit")


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    g = Turtle(read("input/exact-point-model-v1.json"))
    outlines = freeze(read("input/silhouettes-v1.json"))
    study = freeze(read("data/silhouette-study-v1.json"))
    prediction = freeze(read("data/silhouette-prediction-v1.json"))
    outlines.update({k: v["ring"] for k, v in study["strips"].items()})
    finite, withheld = verify_finite(g, outlines, study, prediction)
    all_levels = symbolic(g, study, prediction["grammar"])
    alternate = affine_control(g, study, prediction)
    plane = read("data/plane-replay-v1.json")
    assert plane["status"] == "REPLAYED_PINNED_PLANE_CERTIFICATE" and plane["nested_odd_levels"]
    assert plane["result"]["sha256"] == read("reference/reference-origin-v1.json")["data/plane-v1.json"]
    save("data/silhouette-validation-v1.json", dict(finite=finite, withheld=withheld, symbolic=all_levels,
                                                     alternate_affine=alternate, plane=plane))
    print("withheld", withheld, "symbolic", all_levels, flush=True)


if __name__ == "__main__":
    main()
