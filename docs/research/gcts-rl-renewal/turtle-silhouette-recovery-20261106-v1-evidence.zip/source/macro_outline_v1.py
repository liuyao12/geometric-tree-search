"""Exact-cover search over rigid outlines with no marked seams."""
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache

from boundary_search_v1 import remove
from cluster_v1 import mat
from geometry_v1 import add, area, lattice_sites, pairs, sub
from site_cover_v1 import bits, translation


def mask(indices):
    if not indices:
        return 0
    raw = bytearray(max(indices)//8 + 1)
    for i in indices:
        raw[i//8] |= 1 << (i % 8)
    return int.from_bytes(raw, "little")


def transform_ring(g, ring, turn, shift=(0, 0)):
    out = tuple(add(mat(g.model.groups[turn], p), shift) for p in ring)
    return out if g.sign(area(out, g.cross)) > 0 else out[::-1]


def boundary(g, ring):
    return frozenset(e for a, b in pairs(ring) for e in g.atomize(a, b))


def aligned(polygon):
    x, y = zip(*polygon)
    origin = min(x), min(y)
    return origin, tuple(sub(p, origin) for p in polygon)


def runs(offsets):
    if not offsets:
        return ()
    first, *rest = sorted(offsets)
    start = prev = first
    result = []
    for q in rest:
        if q != prev + 1:
            result.append((start, prev-start+1))
            start = q
        prev = q
    result.append((start, prev-start+1))
    return sorted(result, key=lambda v: (-v[1], v[0]))


def orientations(g, ring):
    seen = set()
    for turn in g.turns:
        oriented = transform_ring(g, ring, turn)
        _, normalized = aligned(oriented)
        signature = boundary(g, normalized)
        if signature not in seen:
            seen.add(signature)
            yield turn, oriented


@dataclass(frozen=True)
class Form:
    name: str
    turn: int
    origin: tuple
    support: tuple
    edges: tuple
    ports: dict
    anchors: int
    mass: int


class MacroBoard:
    def __init__(self, region, library):
        self.region = region
        self.g = g = region.g
        self.scale = g.model.scale
        self.residues = tuple(sorted(g.model.residues))
        self.residue_ids = {p: i for i, p in enumerate(self.residues)}
        raw = self.group(region.sites)
        xs = [x for row in raw for x, _ in row]
        ys = [y for row in raw for _, y in row]
        self.origin = min(xs), min(ys)
        self.nx, self.ny = max(xs)-min(xs)+1, max(ys)-min(ys)+1
        self.width = self.nx + 3
        self.wanted = tuple(mask([self.offset(sub(q, self.origin)) for q in row]) for row in raw)
        self.counts = Counter()
        self.run_masks = {}
        self.forms = [self.make_form(name, turn, poly) for name, ring in library.items()
                      for turn, poly in orientations(g, ring)]
        self.forms = [f for f in self.forms if f.anchors]
        self.counts["catalogue"] = sum(f.anchors.bit_count() for f in self.forms)

    def group(self, sites):
        result = [[] for _ in self.residues]
        for x, y in sites:
            a, r = divmod(x, self.scale)
            b, s = divmod(y, self.scale)
            result[self.residue_ids[r, s]].append((a, b))
        return result

    def offset(self, p):
        return p[0] + self.width*p[1]

    def cell(self, i):
        b, a = divmod(i, self.width)
        return add((a, b), self.origin)

    def eroded(self, residue, length):
        target = self.wanted[residue]
        if length == 1:
            return target
        key = residue, length
        if key not in self.run_masks:
            half = length//2
            smaller = self.eroded(residue, half)
            paired = smaller & (smaller >> half)
            if length % 2:
                paired &= target >> (length-1)
            self.run_masks[key] = paired
        return self.run_masks[key]

    def make_form(self, name, turn, ring):
        sites = lattice_sites(self.g, (ring,))
        groups = self.group(sites)
        ox = min(x for row in groups for x, _ in row)
        oy = min(y for row in groups for _, y in row)
        origin = ox, oy
        dims = (max(x-ox for row in groups for x, _ in row),
                max(y-oy for row in groups for _, y in row))
        nx, ny = self.nx-dims[0], self.ny-dims[1]
        if min(nx, ny) <= 0:
            return Form(name, turn, origin, (), (), {}, 0, len(sites))
        anchors = (((1 << (ny*self.width))-1) // ((1 << self.width)-1)) * ((1 << nx)-1)
        # A few exposed samples reject most anchor translations before full tests.
        for target, group in zip(self.wanted, groups, strict=True):
            if group:
                sample = {fn(group, key=key) for key in (
                    lambda p: p, lambda p: p[::-1], lambda p: (sum(p), p)) for fn in (min, max)}
                for point in sorted(sample):
                    anchors &= target >> self.offset(sub(point, origin))
            if not anchors:
                return Form(name, turn, origin, (), (), {}, 0, len(sites))
        offsets = tuple([self.offset(sub(p, origin)) for p in row] for row in groups)
        support = tuple(map(mask, offsets))
        # Intersect whole horizontal runs before testing sparse surviving anchors.
        complete = True
        for r, row in enumerate(offsets):
            if anchors.bit_count() <= 20:
                complete = False
                break
            for start, length in runs(row):
                anchors &= self.eroded(r, length) >> start
                self.counts["run_intersections"] += 1
                if anchors.bit_count() <= 20:
                    complete = False
                    break
        if complete:
            valid = anchors
        else:
            valid = 0
            for i in bits(anchors):
                self.counts["fit_checks"] += 1
                if all((part << i) & target == part << i
                       for part, target in zip(support, self.wanted, strict=True)):
                    valid |= 1 << i
        edges = tuple(sorted((sub(a, origin), sub(b, origin)) for a, b in boundary(self.g, ring)))
        port_points = defaultdict(set)
        for a, b in edges:
            port_points[sub(b, a)].add(a)
        ports = {}
        for delta, points in port_points.items():
            offsets = [self.offset(p) for p in points]
            top = max(offsets)
            ports[delta] = (top, mask([top-o for o in offsets]), points)
        return Form(name, turn, origin, support, edges, ports, valid, len(sites))

    @lru_cache(maxsize=20000)
    def at(self, edge):
        a, b = edge
        ray = sub(b, a)
        index = self.offset(sub(a, self.origin))
        options = []
        for j, f in enumerate(self.forms):
            if ray in f.ports:
                top, match, starts = f.ports[ray]
                options.extend((j, i) for i in bits(f.anchors & translation(match, index-top))
                               if sub(a, self.cell(i)) in starts)
        return tuple(sorted(options, key=lambda p: (-self.forms[p[0]].mass, p)))

    def part(self, pose):
        j, i = pose
        f = self.forms[j]
        anchor = self.cell(i)
        return f.name, f.turn, sub(anchor, f.origin)

    def current(self, pose, wanted):
        j, i = pose
        return all((part << i) & target == part << i
                   for part, target in zip(self.forms[j].support, wanted, strict=True))

    def place(self, pose, wanted, edges):
        j, i = pose
        f = self.forms[j]
        p = self.cell(i)
        cover = tuple(target & ~(part << i) for part, target in zip(f.support, wanted, strict=True))
        frontier = remove(edges, ((add(a, p), add(b, p)) for a, b in f.edges))
        return cover, frontier


def solve(board, visit_cap=4000, solution_cap=8):
    counts = Counter(board.counts)
    solutions = []
    completed = []

    def visit(wanted, edges, path):
        counts["visits"] += 1
        if counts["visits"] > visit_cap:
            raise TimeoutError
        if not edges:
            assert not any(wanted)
            solutions.append(tuple(sorted(path)))
            completed.append((None, ()))
            if len(solutions) >= solution_cap:
                raise OverflowError
            return len(completed)-1
        best = None
        for edge in sorted(edges, key=lambda e: (len(board.at(e)), e)):
            options = tuple(p for p in board.at(edge) if board.current(p, wanted))
            counts["edge_probes"] += 1
            if best is None or len(options) < len(best[1]):
                best = edge, options
                if len(options) <= 1:
                    break
        edge, options = best
        rows = []
        for pose in options:
            left, boundary = board.place(pose, wanted, edges)
            part = board.part(pose)
            ref = visit(left, boundary, (*path, part))
            rows.append((part, ref))
        completed.append((edge, tuple(rows)))
        return len(completed)-1

    try:
        root = visit(board.wanted, board.region.edges, ())
    except (TimeoutError, OverflowError) as exc:
        status = "VISIT_CAP" if isinstance(exc, TimeoutError) else "SOLUTION_CAP"
        root = None
    else:
        status = "EXHAUSTED"
    assert len(solutions) == len(set(solutions))
    return dict(status=status, counts=dict(counts), solutions=solutions, tree=completed, root=root)
