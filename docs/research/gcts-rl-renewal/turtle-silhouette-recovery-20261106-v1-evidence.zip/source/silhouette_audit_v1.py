"""Independently enumerate every branch of each finite silhouette certificate."""
from collections import Counter, defaultdict
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from boundary_search_v1 import Region
from cluster_v1 import mat
from collar_audit_v1 import freeze
from geometry_v1 import Turtle, add, area, lattice_sites, mul, pairs, sub
from silhouette_study_v1 import read, save


def edges(g, ring):
    return frozenset(e for a, b in pairs(ring) for e in g.atomize(a, b))


def box(ring):
    return tuple((min(values), max(values)) for values in (
        [x for x, _ in ring], [y for _, y in ring], [x+y for x, y in ring]))


class Auditor:
    def __init__(self, g, ring, library):
        self.g = g
        self.region = Region(g, (ring,))
        self.box = box(ring)
        self.forms = {}
        self.by_ray = defaultdict(list)
        self.samples = {}
        self.scale = g.model.scale
        self.counts = Counter()
        for label, prototype in library.items():
            seen = set()
            for h, matrix in g.model.groups.items():
                shape = tuple(mat(matrix, p) for p in prototype)
                if g.sign(area(shape, g.cross)) < 0:
                    shape = shape[::-1]
                border = edges(g, shape)
                start = min(shape)
                key = frozenset((sub(a, start), sub(b, start)) for a, b in border)
                if key in seen:
                    continue
                seen.add(key)
                self.forms[label, h] = shape, border, box(shape)
                for a, b in border:
                    self.by_ray[sub(b, a)].append((label, h, a))

    def parts(self, key):
        if key not in self.samples:
            shape, _, _ = self.forms[key]
            raw = lattice_sites(self.g, (shape,))
            limits = {fn(raw, key=ordering) for ordering in
                      (lambda p: p, lambda p: p[::-1], lambda p: (sum(p), p)) for fn in (min, max)}
            self.samples[key] = (*sorted(limits), *(p for p in raw if p not in limits))
        return self.samples[key]

    def domain(self, edge, occupied):
        a, b = edge
        target = self.region.sites
        for kind, h, v in self.by_ray[sub(b, a)]:
            offset = sub(a, v)
            x, y = offset
            key = kind, h
            _, _, source = self.forms[key]
            self.counts["boundary_poses"] += 1
            if not all(lo <= u+d and v+d <= hi
                       for (lo, hi), (u, v), d in zip(self.box, source, (x, y, x+y), strict=True)):
                continue
            dx, dy = mul(self.scale, offset)
            self.counts["geometry_probes"] += 1
            for u, v in self.parts(key):
                p = u+dx, v+dy
                if p not in target or p in occupied:
                    break
            else:
                yield kind, h, offset

    def attach(self, pose, frontier):
        label, h, shift = pose
        key = label, h
        _, border, _ = self.forms[key]
        values = Counter({e: 1 for e in frontier})
        values.subtract((add(a, shift), add(b, shift)) for a, b in border)
        assert all(abs(n) <= 1 for n in values.values())
        remaining = frozenset(e if n > 0 else e[::-1] for e, n in values.items() if n)
        assert all(e[::-1] not in remaining for e in remaining)
        dx, dy = mul(self.scale, shift)
        sites = {(u+dx, v+dy) for u, v in self.parts(key)}
        return remaining, sites

    def verify(self, result):
        assert result["status"] == "EXHAUSTED" and type(result["root"]) is int
        tree = result["tree"]
        reached, found, occupied = set(), [], set()

        def visit(index, frontier, path):
            assert type(index) is int and 0 <= index < len(tree) and index not in reached
            reached.add(index)
            edge, entries = tree[index]
            if edge is None:
                assert not entries and not frontier and len(occupied) == len(self.region.sites)
                found.append(tuple(sorted(path)))
                return
            assert edge in frontier
            supplied = dict(entries)
            assert len(supplied) == len(entries)
            assert supplied.keys() == set(self.domain(edge, occupied))
            for pose, ref in entries:
                assert ref < index
                left, part = self.attach(pose, frontier)
                assert part <= self.region.sites and occupied.isdisjoint(part)
                occupied.update(part)
                visit(ref, left, (*path, pose))
                occupied.difference_update(part)

        visit(result["root"], self.region.edges, ())
        assert len(reached) == len(tree) == result["counts"]["visits"]
        assert sorted(found) == sorted(result["solutions"])
        return dict(rows=len(reached), covers=len(found), **self.counts)


def omission_control(auditor, result):
    tree = list(result["tree"])
    j = result["root"]
    edge, entries = tree[j]
    assert entries
    tree[j] = edge, entries[1:]
    try:
        auditor.verify(dict(result, tree=tree))
    except AssertionError:
        return True
    raise AssertionError("Accepted a missing macro branch")


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    g = Turtle(read("input/exact-point-model-v1.json"))
    outlines = freeze(read("input/silhouettes-v1.json"))
    result = freeze(read("data/silhouette-study-v1.json"))
    outlines.update({k: v["ring"] for k, v in result["strips"].items()})
    outlines["unit"] = g.poly((0, 0, 0))
    checks = {}
    for name, entry in result["assemblies"].items():
        library = {k: outlines[k] for k in result["libraries"][name]}
        verifier = Auditor(g, outlines[name], library)
        checks[name] = verifier.verify(entry)
        if name == "T3":
            checks[name]["omitted_branch_rejected"] = omission_control(verifier, entry)
        print(name, checks[name], flush=True)
        del verifier
    control = result["periodic"]
    name = control["target"]
    library = {k: control["ring"] if k == "S3" else outlines[k] for k in result["libraries"][name]}
    negative = Auditor(g, outlines[name], library).verify(control["result"])
    assert negative["covers"] == 0
    save("data/silhouette-audit-v1.json", dict(cases=checks, periodic=negative))
    print("periodic control", negative, flush=True)


if __name__ == "__main__":
    main()
