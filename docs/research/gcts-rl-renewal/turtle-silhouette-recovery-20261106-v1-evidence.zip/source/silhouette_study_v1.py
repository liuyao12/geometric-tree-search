"""Learn from unmarked outlines and predict higher strip and cluster placements."""
import json
from collections import Counter
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from boundary_search_v1 import Region
from collar_audit_v1 import freeze
from geometry_v1 import Turtle, add, chain, mul, rings_from_edges, sub
from macro_outline_v1 import MacroBoard, solve


ROOT = Path(__file__).resolve().parents[1]
BASE = ("P0", "T1", "S1", "S2")


def read(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def find(g, ring, library, cap=4000, solutions=8):
    board = MacroBoard(Region(g, (ring,)), library)
    try:
        return solve(board, cap, solutions)
    finally:
        MacroBoard.at.cache_clear()


def strip_read(g, patch, stride):
    u, v = stride
    direction = (2*u+v, u+2*v)

    def place(pose):
        x, y = map(sum, zip(*g.poly(pose)))
        return x*direction[0] + y*direction[1], pose

    ordered = sorted(map(place, patch))
    if len({x for x, _ in ordered}) != len(ordered):
        return None
    letters, word = {}, []
    for i, (_, (h, x, y)) in enumerate(ordered):
        start = sub((x, y), mul(i, stride))
        if letters.setdefault(h, start) != start:
            return None
        word.append(h)
    return letters, tuple(word)


def strip_fit(g, assemblies):
    samples = [[tuple((h, *shift) for _, h, shift in sol) for sol in assemblies[k]["solutions"]]
               for k in ("S1", "S2")]
    rules = set()
    for small in samples[0]:
        strides = {sub(a[1:], b[1:]) for a, b in combinations(small, 2) if a[0] == b[0]}
        strides = {d if d > g.zero else mul(-1, d) for d in strides if d != g.zero}
        for step in sorted(strides):
            trial = strip_read(g, small, step)
            if trial is None:
                continue
            letters, a = trial
            if len(letters) != 2:
                continue
            for larger in samples[1]:
                read_back = strip_read(g, larger, step)
                if read_back is None:
                    continue
                other, b = read_back
                if letters.keys() != other.keys() or len({sub(other[h], p) for h, p in letters.items()}) != 1:
                    continue
                if b[:len(a)] != a or b[-len(a):] != a or len(b) <= 2*len(a):
                    continue
                second = b[len(a):-len(a)]
                if a[:len(second)] != second or len(a) <= len(second):
                    continue
                first = a[len(second):]
                rules.add((step, tuple(sorted(letters.items())), first, second))
    rule, = rules
    step, letters, first, second = rule
    ids = {h: i for i, (h, _) in enumerate(letters)}
    words = [tuple(ids[h] for h in w) for w in (first, second)]
    for _ in range(10):
        words.append(words[-1] + words[-2])
    return dict(stride=step, letters=letters, words=words)


def strip_tiles(g, rule, word):
    poses = []
    for i, j in enumerate(word):
        h, p = rule["letters"][j]
        poses.append((h, *add(p, mul(i, rule["stride"]))))
    return tuple(poses)


def ring_of(g, tiles):
    result = rings_from_edges(chain(g, tiles))
    assert result is not None and len(result) == 1
    return result[0]


def run(maximum):
    g = Turtle(read("input/exact-point-model-v1.json"))
    outlines = freeze(read("input/silhouettes-v1.json"))
    units = {"unit": g.poly((0, 0, 0))}
    assemblies, library = {}, {}
    for key in BASE:
        result = find(g, outlines[key], units)
        assert result["status"] == "EXHAUSTED" and result["solutions"]
        assemblies[key] = result
        library[key] = tuple(units)
        print(key, result["counts"]["visits"], len(result["solutions"]), flush=True)
    strip = strip_fit(g, assemblies)
    print("strip", strip["stride"], [len(w) for w in strip["words"][::2]], flush=True)
    strips = {}
    for n in range(1, maximum+1):
        strip_id = "S" + str(n)
        word = strip["words"][2*n]
        patch = strip_tiles(g, strip, word)
        strips[strip_id] = dict(ring=ring_of(g, patch), patch=patch)
        if n <= 2:
            assert tuple(sorted(("unit", h, (x, y)) for h, x, y in patch)) in assemblies[strip_id]["solutions"]
        outlines[strip_id] = strips[strip_id]["ring"]
        for kind in ("T", "P"):
            if kind == "T" and n == 1:
                continue
            prior = ["P" + str(n-1)]
            prior.extend("T" + str(j) for j in (n-1, n-2) if j >= 1)
            if kind == "P":
                prior.append(strip_id)
            key = kind + str(n)
            result = find(g, outlines[key], {k: outlines[k] for k in prior})
            library[key] = tuple(prior)
            assemblies[key] = result
            print(key, result["status"], result["counts"], len(result["solutions"]),
                  dict(Counter(t[0] for t in result["solutions"][0])) if result["solutions"] else {},
                  flush=True)
            assert result["solutions"], "no cover " + key
    wrong = None
    if maximum >= 3:
        observed, expected = strip["words"][2], strip["words"][6]
        distractor = tuple(observed[i % len(observed)] for i in range(len(expected)))
        assert distractor != expected
        distractor_tiles = strip_tiles(g, strip, distractor)
        fake = ring_of(g, distractor_tiles)
        parts = {k: outlines[k] if k != "S3" else fake for k in library["P3"]}
        result = find(g, outlines["P3"], parts)
        wrong = dict(target="P3", word=distractor, ring=fake, result=result)
        print("periodic control", result["status"], result["counts"], len(result["solutions"]), flush=True)
    save("data/silhouette-study-v1.json", dict(assemblies=assemblies, libraries=library,
                                               strip=strip, strips=strips, periodic=wrong))


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Search requires Python assertions")
    run(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
