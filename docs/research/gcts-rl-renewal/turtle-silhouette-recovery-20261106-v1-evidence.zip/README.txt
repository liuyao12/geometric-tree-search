Recovering the Turtle hierarchy from outlines

From the archive root, run these commands with Python 3.12.

    python3 -I -S -B source/silhouette_study_v1.py
    python3 -I -S -B source/silhouette_predict_v1.py
    python3 -I -S -B source/silhouette_audit_v1.py
    python3 -I -S -B source/reference_replay_v1.py
    python3 -I -S -B source/silhouette_validate_v1.py
    python3 -I -S -B source/silhouette_wang_v1.py --build
    python3 -I -S -B source/silhouette_wang_v1.py
    python3 -I -S -B publication/render_v1.py

The first three commands use the unmarked polygon and fixed outlines.
They can run with the reference directory absent. The remaining
commands audit the inferred rule and replay the plane and Wang proofs.
To regenerate the supplied fixture outlines from the old hierarchy,
run source/silhouette_input_v1.py separately.
