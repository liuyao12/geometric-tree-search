"""Render held move-order results and a checked Wang refutation."""
from collections import Counter
import gzip
import json
from math import sqrt
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/source"), str(ROOT / "publication")]
from core_wang_v1 import prepare, problem
from boundary_kernel_v1 import build
from move_policy_study_v1 import FIXED, LEARNED, RANDOM
from proof_views_v1 import frame_window, math, tile_svg
from schematic_capsules_v1 import frozen
from site_cover_study_v1 import setup

NAME = "turtle-receptor-policy-20261106-v1"
LABELS = dict(zip(FIXED, ("Original", "Reverse", "Fewest conflicts", "Most conflicts"), strict=True))
LABELS.update((name, "Learned " + name.split("-")[-1]) for name in LEARNED)


def read(name):
    return json.loads((ROOT / name).read_text())


def table(headers, rows, ident=""):
    head = "".join(f'<th scope="col">{x}</th>' for x in headers)
    body = "".join("<tr>" + "".join(f"<td>{x}</td>" for x in row) + "</tr>" for row in rows)
    attr = f' id="{ident}"' if ident else ""
    return f'<div class="table" tabindex="0"{attr}><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def xy(p, scale=1):
    a, b = p
    return (a+b/2)/scale, -sqrt(3)*b/(2*scale)


def proposal(g, data):
    candidates = [tuple(t) for t in data["candidates"]]
    proposed = [tuple(t) for t in data["proposals"]]
    x, y = zip(*(xy(p) for t in candidates for p in g.poly(t)))
    box = f"{min(x)-1:.4f} {min(y)-1:.4f} {max(x)-min(x)+2:.4f} {max(y)-min(y)+2:.4f}"
    a, b = xy(data["site"], g.model.scale)

    def panel(tile, color, caption):
        p = " ".join(f"{u:.4f},{v:.4f}" for u, v in map(xy, g.poly(tile)))
        return (f'<figure><svg role="img" aria-label="{caption}" viewBox="{box}">'
                f'<polygon points="{p}" fill="{color}" stroke="#3f5e66" stroke-width=".15"/>'
                f'<circle cx="{a:.4f}" cy="{b:.4f}" r=".29" fill="#ffc653" stroke="#514138" stroke-width=".09"/>'
                f'</svg><figcaption>{caption}</figcaption></figure>')

    panels = panel(candidates[0], "#8ecbd0", "First choice in the original order.")
    panels += panel(proposed[0], "#b69be2", "First choice in the learned order.")
    ranks = table(("Pose", "Original rank", "Learned rank", "Learned score"), [
        (math(str(t)), i, proposed.index(t)+1, f"{value:.3f}")
        for i, (t, value) in enumerate(zip(candidates, data["scores"], strict=True), 1)])
    return f'<div class="grid" id="move-pair">{panels}</div>{ranks}'


def atom(name):
    return rf"T_{{{int(name[1:])}}}"


def reading(row):
    pos = [atom(t) for p, (t,) in row["clause"] if p]
    neg = [atom(t) for p, (t,) in row["clause"] if not p]
    if not pos and not neg:
        return "The prescribed outline has no cover."
    if not pos:
        return f"No cover can use {'all of ' if len(neg)>1 else ''}{math(', '.join(neg))}."
    choices = math(r"\lor ".join(pos))
    if not neg:
        return f"Every cover must use at least one option in {choices}."
    return f"If the cover uses {math(', '.join(neg))}, it must use at least one option in {choices}."


def wang():
    rows, _, _, sources, _ = problem()
    proof = frozen(read("wang/data/core-proof-v1.json"))
    _, calls = prepare(proof, sources)
    bank = json.loads(gzip.decompress((ROOT / "wang/data/core-bank-v1.json.gz").read_bytes()))
    evidence = bank["traces"][calls[-1]]
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    start = evidence["steps"] - 5
    trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
    window, first = frame_window(machine, trace, start, evidence["head"])
    ids, cells = {}, []
    for y, row in enumerate(window):
        for x, tile in enumerate(row):
            i = ids.setdefault(tile, len(ids))
            cells.append(f'<use href="#wang-{i}" x="{36*x}" y="{36*y}"/>')
    defs = "".join(tile_svg(tile, i) for tile, i in ids.items())
    figure = (f'<figure><svg role="img" aria-label="Fixed-orientation Wang squares" viewBox="0 0 324 180">'
              f'<defs>{defs}</defs>{"".join(cells)}</svg><figcaption>Closing resolution. '
              f'Verifier rows {start+1:,} to {start+5:,}, tape columns {first:,} to {first+8:,}.</figcaption></figure>')
    logical = []
    for i, row in enumerate(proof, 1):
        if row["rule"] == "G":
            q = rows[int(row["source"].split("-")[1])]["site"]
            how = f"Import the checked site clause at {math(str(q))}."
        else:
            how = f"Resolve lines {row['left']+1} and {row['right']+1} on {math(atom(row['pivot'][0]))}."
        formula = math(r"\lor ".join(("" if p else r"\neg ") + atom(t) for p, (t,) in row["clause"]) or r"\bot")
        logical.append((i, how, formula, reading(row)))
    return figure, table(("Line", "Operation", "Formula", "Reading"), logical, "proof-lines"), len(proof)


def visit(arm):
    return f'{arm["counts"]["nodes"]:,}' if arm["status"] != "BOUNDED" else "Open"


def main():
    g, _, _ = setup()
    rows = read("data/move-policy-study-v1.json")
    targeted = read("data/move-policy-targeted-v1.json")["result"]
    train = read("data/move-policy-training-v1.json")
    times = read("data/move-policy-timing-v1.json")
    proposal_data = read("data/repair-14-policy-witness-v1.json")["first_proposal"]
    by_name = {r["id"]: r["arms"] for r in rows}
    large, changed = by_name["repair-14"], by_name["trim-14"]
    stress = targeted["arms"]
    best = train["donor_fixed"]
    timed = tuple(dict.fromkeys(("forward", best, *LEARNED)))
    short, full = Counter(), Counter()
    comparison = Counter()
    results = []
    for row in rows:
        arms = row["arms"]
        random = sorted(RANDOM, key=lambda k: (arms[k]["status"] == "BOUNDED", arms[k]["counts"]["nodes"]))
        results.append((row["id"], row["tiles"], *(visit(arms[k]) for k in (*FIXED, random[1], *LEARNED))))
        saved = arms["forward"]["counts"]["nodes"] - median(arms[k]["counts"]["nodes"] for k in LEARNED)
        comparison[(saved > 0) - (saved < 0)] += 1
        for k, a in arms.items():
            short[k] += a["tight"] != "BOUNDED"
            full[k] += a["status"] != "BOUNDED"
    visits = table(("Outline", "Tiles", *map(LABELS.__getitem__, FIXED),
                    "Random median", *map(LABELS.__getitem__, LEARNED)), results)
    stress_visits = table(("Edit", "Original", *map(LABELS.__getitem__, LEARNED)),
                          [(targeted["id"], *(visit(stress[k]) for k in ("forward", *LEARNED)))])
    caps = table(("Move order", "Settled at tight cap", "Settled at full cap"), [
        (LABELS.get(k, "Random " + k.split("-")[-1]), short[k], full[k]) for k in (*FIXED, *RANDOM, *LEARNED)])
    elapsed = next(r["medians"] for r in times if r["id"] == "repair-14")
    timings = table(("Outline", *map(LABELS.__getitem__, timed)), [
        (r["id"], *(f'{r["medians"][k]:.3f} s' for k in timed)) for r in times])
    factorial = table(("Outline", "Original · online marks", "Seed 14 · online marks",
                       "Original · imported bank", "Seed 14 · imported bank"), [
        (name, *(visit(by_name[name][k]) for k in ("online-forward", "online-learned", "forward", LEARNED[0])))
        for name in ("repair-14", "repair-15")])
    tape, proof, n = wang()
    receipt = read("wang/data/core-receipt-v1.json")
    atoms = table(("Atom", "Symmetry and lattice translation"), [
        (math(atom(k)), math(str(tuple(t)))) for k, t in sorted(receipt["tiles"].items(), key=lambda kv: int(kv[0][1:]))])
    report_title = "Learning which Turtle placement to try first"
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", report_title)
    head = head.replace("</style>", ".table:focus{outline:2px solid #13787b}#move-pair{max-width:42rem}"
                        "#move-pair svg{max-height:17rem}#wang figure{max-width:34rem}"
                        "@media(max-width:43rem){#proof-lines table{min-width:0}"
                        "#proof-lines thead{position:absolute;clip-path:inset(50%)}"
                        "#proof-lines tr,#proof-lines td{display:block}#proof-lines tr{border-bottom:1px solid #d6e3e9}"
                        "#proof-lines td{border:0;padding:.14rem .3rem}}</style>")
    branch = proposal_data["outcome"]
    outcome = "returned a cover" if branch["solved"] else "closed without a cover"
    branch_cost = f'{branch["visits"]:,} ' + ("visit" if branch["visits"] == 1 else "visits")
    main_page = rf"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>{report_title}</h1>
<p>With the same imported conflict bank, the three learned move orders covered the 597-tile outline
in {", ".join(visit(large[k]) for k in LEARNED)} visits. The original order took {visit(large["forward"])}.</p>
<nav><a href="#proposal">One proposed move</a><a href="#training">Training</a><a href="#benchmark">Held tests</a>
<a href="#wang">Wang proof</a><a href="{NAME}-evidence.zip">Replay archive</a></nav></header>
<section id="proposal"><h2>Compare the first changed choice</h2>
<p>The panels show the first branch where seed 14 changed the leading choice on the 597-tile outline.
Both poses cover the gold sample. The solver had committed {proposal_data["committed"]} tiles.</p>
{proposal(g, proposal_data)}
<p>The selected subtree {outcome} after {branch_cost}.
Each pose triple gives the symmetry index and two \(A_2\) translation coordinates.</p>
</section>
<section id="training"><h2>Learn from completed branch attempts</h2>
<p>The model scores each legal pose from its symmetry, its position relative to the chosen sample,
nearby uncovered sites, original rank, and search depth. The solver tries moves by score.
Site selection, forced placements, and the imported conflict bank follow the same rules in each arm.</p>
<p>For a branch attempt that costs \(v\) visits including the initial placement, the training target is
\(8\mathbf{{1}}_{{\mathrm{{cover}}}}-\min(7,\log_2(1+v))\). The cover indicator is set when that subtree returns a full cover.
The model updates a linear action value from this return and explores by shuffling a fraction of decisions.
Each seed runs eight rounds over six donor outlines. The weights are frozen for the held tests.
<a href="https://mitpress.mit.edu/9780262039246/reinforcement-learning/">Sutton and Barto on return-based action values</a></p>
<p>The reward and features were chosen for this experiment. Changing the move order can change which new
conflicts the solver discovers. The same checker validates covers and refutations throughout.</p>
</section>
<section id="benchmark"><h2>Check fixed orders, random orders and fresh boundary edits</h2>
<p>There are {len(rows)} held cases, including four new outlines made by trimming one exposed tile
from an existing held boundary. The solver receives the outline. All settled results were independently audited.
The best fixed order on the training donors was {LABELS[best].lower()}, which took {visit(large[best])}
visits on the original 597-tile outline.</p>
<p>Compared with the original order, the median learned run used fewer visits on {comparison[1]} cases,
the same on {comparison[0]}, and more on {comparison[-1]}.</p>
<p>The first 596-tile edit reproduced the original visit counts for all ten orders.
The original took {visit(changed["forward"])} and the learned orders took
{", ".join(visit(changed[k]) for k in LEARNED)}.</p>{visits}
<p>A separate stress test removed the exposed tile covering the gold sample in the move diagram.
This removes the disputed sample from the outline. The policy weights and conflict bank stayed frozen.</p>{stress_visits}
<p>The tight cap is 100 visits for the smaller outlines and 1,200 for the two largest.
The full caps are 360 and 4,000. An open search has no verdict at its cap.</p>{caps}
<p>Times are medians of three runs and include outline setup, binding the bank, search, and certificate construction.
On the 597-tile outline the original order took {elapsed["forward"]:.3f} seconds, and the median across
learned seeds was {median(elapsed[k] for k in LEARNED):.3f} seconds.</p>{timings}
<details><summary>Separate move ordering and imported marks</summary>
<p>All four arms learn within the receiving outline. The final two columns add the same prelearned bank.</p>
{factorial}</details></section>
<section id="wang"><h2>Read the refutation found with learned ordering</h2>
<p>Seed 14 changed the move order on the rotated-hole fixture. The Wang checker verifies the resulting
{n}-line refutation against site clauses independently audited on the lattice.</p>
{tape}<details id="reader"><summary>Read all {n} lines in formulas and words</summary>{proof}</details>
<details id="atoms"><summary>Look up the physical placements</summary>{atoms}</details></section>
</main></body></html>"""
    (ROOT / "report" / (NAME + ".html")).write_text(head + main_page)


if __name__ == "__main__":
    main()
