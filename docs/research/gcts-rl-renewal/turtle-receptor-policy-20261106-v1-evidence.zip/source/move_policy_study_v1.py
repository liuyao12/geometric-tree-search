"""Compare frozen action values with fixed and random proposal orders."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
from random import Random
from statistics import median
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from conflict_study_v1 import audit_conflicts
from conflict_v1 import search
from geometry_v1 import chain
from move_value_v1 import FIXED, Ordering
from receptor_study_v1 import import_audit, mine
from receptor_v1 import Inventory
from repair_v1 import ring_of
from site_cover_study_v1 import Audit, Board, Region, audit_cover, cases, save, setup


SEEDS = (14, 37, 101)
LEARNED = tuple("learned-" + str(s) for s in SEEDS)
RANDOM = tuple("random-" + str(s) for s in SEEDS)
MODES = FIXED + RANDOM + LEARNED
TIMED = {"repair-06", "repair-09", "repair-14", "repair-15"}


def trimmed_cases(g, original):
    existing = {chain(g, row["construction"]) for row in original if "construction" in row}
    by_name = {row["id"]: row for row in original}
    output = []
    for name in ("repair-08", "repair-10", "repair-14", "repair-15"):
        construction = by_name[name]["construction"]
        boundary = chain(g, construction)
        for tile in sorted(construction, key=lambda t: (t[2], t[1], t[0])):
            if boundary.isdisjoint(g.boundary(tile)):
                continue
            patch = tuple(t for t in construction if t != tile)
            ring = ring_of(g, patch)
            if ring is None or chain(g, patch) in existing:
                continue
            case = dict(id="trim-" + name[-2:], parent=name, rings=(ring,), partition="test",
                        source_removed=tile)
            checked = audit_cover(Audit(g.model), Region(g, case["rings"]), patch)
            assert checked["tiles"] == len(construction) - 1
            output.append(case)
            break
        else:
            raise AssertionError("No boundary edit for " + name)
    return output


def make_policy(name, models):
    if name == "forward":
        return None
    if name in FIXED:
        return Ordering(name)
    kind, seed = name.rsplit("-", 1)
    return Ordering(kind, int(seed), models.get(name, ()))


def training(g, rows, bank):
    boards = {row["id"]: Board(Region(g, row["rings"])) for row in rows if row["partition"] == "train"}
    bound = {name: Inventory(board, bank) for name, board in boards.items()}
    logs, models = {}, {}
    for seed in SEEDS:
        name = "learned-" + str(seed)
        policy = Ordering("learned", seed, training=True)
        rng = Random(seed + 500)
        episodes = []
        for epoch in range(8):
            order = list(boards)
            rng.shuffle(order)
            policy.epsilon = .20 if epoch < 4 else .10
            for case in order:
                start, wins, reward = policy.steps, policy.solves, policy.return_sum
                result = search(boards[case], 360, inventory=bound[case], policy=policy)
                episodes.append(dict(epoch=epoch+1, donor=case, epsilon=policy.epsilon,
                                     attempts=policy.steps-start, solved_attempts=policy.solves-wins,
                                     return_sum=policy.return_sum-reward,
                                     status=result["status"], visits=result["counts"]["nodes"]))
        logs[name] = dict(episodes=episodes, weights=sorted(policy.weights.items()), attempts=policy.steps,
                          solved_attempts=policy.solves, return_sum=policy.return_sum)
        models[name] = dict(policy.weights)
        print(name, policy.steps, policy.solves, len(policy.weights), flush=True)
    static = {}
    for name in FIXED:
        observations = [search(board, 360, inventory=bound[case], policy=make_policy(name, models))
                        for case, board in boards.items()]
        static[name] = dict(bounded=sum(a["status"] == "BOUNDED" for a in observations),
                            visits=sum(a["counts"]["nodes"] for a in observations))
    winner = min(FIXED, key=lambda n: (static[n]["bounded"], static[n]["visits"]))
    return models, dict(seeds=SEEDS, learned=logs, fixed_donors=static, donor_fixed=winner)


def caps(board):
    return (1200, 4000) if board.tile_count > 200 else (100, 360)


def inspect(region, bank, answer):
    checked = audit_conflicts(region, answer)
    checked["imports"] = import_audit(region, bank, answer)
    if answer["status"] == "POSITIVE":
        checked["cover"] = audit_cover(Audit(region.g.model), region, answer["patch"])
    return checked


def evaluate(g, rows, models, bank):
    results = []
    for row in rows:
        if row["partition"] != "test":
            continue
        name = row["id"]
        region = Region(g, row["rings"])
        board = Board(region)
        inv = Inventory(board, bank)
        tight, full = caps(board)
        arms = {}
        extras = ("online-forward", "online-learned") if name in {"repair-14", "repair-15"} else ()
        for mode in MODES + extras:
            ordering = ("forward" if mode == "online-forward" else LEARNED[0]) if mode in extras else mode
            bound = None if mode in extras else inv
            policy = make_policy(ordering, models)
            witness = mode == LEARNED[0] and name in {"repair-14", "rotated-hole"}
            answer = search(board, full, inventory=bound, policy=policy, trace=witness)
            checked = inspect(region, bank if bound is not None else [], answer)
            cost = answer["counts"]["nodes"]
            short = answer["status"] if cost <= tight else "BOUNDED"
            if mode in ("forward", LEARNED[0]) and name in ("repair-09", "repair-14"):
                replay = search(board, tight, inventory=bound, policy=make_policy(ordering, models))
                assert replay["status"] == short
            if witness:
                save(name + "-policy-witness", answer)
            arms[mode] = dict(status=answer["status"], tight=short, counts=answer["counts"], checked=checked)
        statuses = {arm["status"] for arm in arms.values()} - {"BOUNDED"}
        assert len(statuses) <= 1
        if "parent" in row:
            assert statuses <= {"POSITIVE"}
        results.append(dict(id=name, parent=row.get("parent"), tiles=board.tile_count,
                            tight_cap=tight, full_cap=full, arms=arms))
        print(name, [(n, a["counts"]["nodes"], a["status"]) for n, a in arms.items()], flush=True)
    return results


def timing(rows, models, bank, best_fixed, repeats):
    modes = tuple(dict.fromkeys(("forward", best_fixed, *LEARNED)))
    results = []
    for row in rows:
        if row["id"] not in TIMED:
            continue
        trials = defaultdict(list)
        for i in range(repeats):
            for mode in (*modes[i % len(modes):], *modes[:i % len(modes)]):
                g, _, _ = setup()
                start = perf_counter()
                region = Region(g, row["rings"])
                board = Board(region)
                outcome = search(board, caps(board)[1], inventory=Inventory(board, bank),
                                 policy=make_policy(mode, models))
                trials[mode].append(perf_counter() - start)
                assert outcome["status"] != "BOUNDED"
        medians = {k: median(v) for k, v in trials.items()}
        print(row["id"], {k: round(v, 3) for k, v in medians.items()}, flush=True)
        results.append(dict(id=row["id"], trials=dict(trials), medians=medians))
    return results


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--timing", type=int, default=0, metavar="REPEATS")
    repeats = parser.parse_args().timing
    g, _, _ = setup()
    rows = cases(g)
    extra = trimmed_cases(g, rows)
    banks, _, _ = mine(g, rows, verify=not repeats)
    bank = banks["both"]
    models, train = training(g, rows, bank)
    if repeats:
        save("move-policy-timing", timing(rows, models, bank, train["donor_fixed"], repeats))
    else:
        save("move-policy-training", train)
        save("move-policy-bank", bank)
        save("move-policy-held", extra)
        save("move-policy-study", evaluate(g, (*rows, *extra), models, bank))


if __name__ == "__main__":
    main()
