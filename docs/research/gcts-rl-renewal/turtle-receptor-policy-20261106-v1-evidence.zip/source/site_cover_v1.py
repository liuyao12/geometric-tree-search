"""Exact Turtle cover using packed lattice-cell and placement masks."""
from collections import Counter
from functools import lru_cache

from geometry_v1 import sub


def bits(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def translation(mask, delta):
    return mask << delta if delta >= 0 else mask >> -delta


@lru_cache(maxsize=4)
def conflict_offsets(shapes):
    return tuple(tuple({(ax - bx, ay - by) for u, v in zip(shape, other, strict=True)
                        for ax, ay in u for bx, by in v} for other in shapes) for shape in shapes)


class Board:
    """One bit plane per sample residue, and one per orientation of a tile."""
    def __init__(self, region):
        self.g = g = region.g
        if g.kind != "turtle" or not region.sites or region.counts is None:
            raise ValueError("The packed board requires a positive-area Turtle region of compatible area")
        self.tile_count = region.counts[0]
        self.scale = scale = g.model.scale
        self.residues = tuple(sorted(g.model.residues))
        self.residue_ids = {r: i for i, r in enumerate(self.residues)}
        local = [self.groups(g.sites(t)) for t in g.bases]
        lo = [(min(x for group in shape for x, _ in group), min(y for group in shape for _, y in group))
              for shape in local]
        shapes = tuple(tuple(tuple(sorted(sub(q, corner) for q in group)) for group in shape)
                       for shape, corner in zip(local, lo, strict=True))
        self.offsets = lo
        world = self.groups(region.sites)
        xs = [x for group in world for x, _ in group]
        ys = [y for group in world for _, y in group]
        mx = max(x for shape in shapes for group in shape for x, _ in group)
        my = max(y for shape in shapes for group in shape for _, y in group)
        self.x0, self.y0 = min(xs) - mx - 1, min(ys) - my - 1
        self.width = max(xs) - min(xs) + 1 + 2 * (mx + 1)
        self.wanted = tuple(sum(1 << self.index(q) for q in group) for group in world)
        self.offset_ids = tuple(tuple(tuple(self.offset(q) for q in group) for group in shape)
                                for shape in shapes)
        self.tile_masks = tuple(tuple(sum(1 << v for v in group) for group in shape)
                                for shape in self.offset_ids)
        self.anchor_sets = tuple(tuple(sum(1 << (max(group) - v) for v in group) if group else 0
                                       for group in shape) for shape in self.offset_ids)
        self.anchors = tuple(tuple(max(group, default=0) for group in shape) for shape in self.offset_ids)
        allowed = []
        for shape in self.offset_ids:
            mask = None
            for board, offsets in zip(self.wanted, shape, strict=True):
                for delta in offsets:
                    valid = board >> delta
                    mask = valid if mask is None else mask & valid
                    if not mask:
                        break
                if mask == 0:
                    break
            allowed.append(mask or 0)
        self.initial = tuple(allowed)
        conflicts = []
        for shape in conflict_offsets(shapes):
            row = []
            for other in shape:
                deltas = {self.offset(q) for q in other}
                start = min(deltas)
                row.append((sum(1 << (d - start) for d in deltas), start))
            conflicts.append(tuple(row))
        self.conflicts = tuple(conflicts)
        self.by_turn = {turn: i for i, (turn, _, _) in enumerate(g.bases)}

    def groups(self, sites):
        groups = [[] for _ in self.residues]
        for x, y in sites:
            a, p = divmod(x, self.scale)
            b, q = divmod(y, self.scale)
            groups[self.residue_ids[p, q]].append((a, b))
        return tuple(groups)

    def offset(self, q):
        x, y = q
        return x + self.width * y

    def index(self, q):
        return self.offset(sub(q, (self.x0, self.y0)))

    def cell(self, index):
        y, x = divmod(index, self.width)
        return x + self.x0, y + self.y0

    def site(self, residue, index):
        a, b = self.cell(index)
        x, y = self.residues[residue]
        return self.scale * a + x, self.scale * b + y

    def tile(self, pose):
        h, i = pose
        a, b = sub(self.cell(i), self.offsets[h])
        return self.g.bases[h][0], a, b

    def pose(self, tile):
        turn, a, b = tile
        h = self.by_turn[turn]
        x, y = self.offsets[h]
        return h, self.index((a + x, b + y))

    def choose(self, residue, index, placements):
        for h, board in enumerate(placements):
            mask = board & translation(self.anchor_sets[h][residue], index - self.anchors[h][residue])
            yield from ((h, i) for i in bits(mask))

    def cover(self, residue, uncovered, placements):
        once = twice = 0
        for h, board in enumerate(placements):
            for delta in self.offset_ids[h][residue]:
                cover = (board << delta) & uncovered
                twice |= once & cover
                once |= cover
        return uncovered & ~once, once & ~twice

    def forced_poses(self, residue, forced, placements):
        for h, board in enumerate(placements):
            hits = 0
            for delta in self.offset_ids[h][residue]:
                hits |= (forced >> delta) & board
            for i in bits(hits):
                witnesses = forced & (self.tile_masks[h][residue] << i)
                yield (h, i), (witnesses & -witnesses).bit_length() - 1

    def apply(self, pose, uncovered, placements):
        h, i = pose
        assert placements[h] & (1 << i)
        remain = tuple(u & ~(mask << i) for u, mask in zip(uncovered, self.tile_masks[h], strict=True))
        legal = tuple(v & ~translation(mask, start + i)
                      for v, (mask, start) in zip(placements, self.conflicts[h], strict=True))
        return remain, legal


def search(board, limit, mode="sweep", seed=(), residue_order=None, sweep_width=2):
    """Branch on one uncovered site. A negative node records every option."""
    counts = Counter()
    uncovered, placements = board.wanted, board.initial
    initial = sum(v.bit_count() for v in placements)
    residues = tuple(range(len(uncovered))) if residue_order is None else residue_order
    assert set(residues) == set(range(len(uncovered)))
    assert mode in ("sample", "sweep", "batch")
    for tile in seed:
        uncovered, placements = board.apply(board.pose(tile), uncovered, placements)

    def select(wanted, active):
        if mode != "sample":
            for r in [r for r in residues if wanted[r]][:sweep_width]:
                counts["residue_sweeps"] += 1
                zero, forced = board.cover(r, wanted[r], active)
                if zero or forced:
                    i = ((zero or forced) & -(zero or forced)).bit_length() - 1
                    moves = tuple(board.choose(r, i, active))
                    assert len(moves) == (0 if zero else 1)
                    return r, i, moves, forced if mode == "batch" and not zero else 0
        best = None
        for r in residues:
            if wanted[r]:
                i = (wanted[r] & -wanted[r]).bit_length() - 1
                moves = tuple(board.choose(r, i, active))
                counts["site_probes"] += 1
                if best is None or len(moves) < len(best[2]):
                    best = r, i, moves, 0
                    if len(moves) <= 1:
                        break
        return best

    def visit(wanted, active, chosen):
        counts["nodes"] += 1
        if counts["nodes"] > limit:
            raise TimeoutError
        if not any(wanted):
            return chosen, None
        r, i, moves, forced = select(wanted, active)
        if forced:
            path = []
            counts["batches"] += 1
            for (h, j), witness in board.forced_poses(r, forced, active):
                site = board.site(r, witness)
                assert (wanted[r] >> witness) & 1
                if not (active[h] >> j) & 1:
                    counts["blocked"] += 1
                    answer, proof = None, (site, ())
                    break
                tile = board.tile((h, j))
                wanted, active = board.apply((h, j), wanted, active)
                counts["tile_applications"] += 1
                path.append((site, tile))
                counts["forced"] += 1
            else:
                answer, proof = visit(wanted, active, (*chosen, *(tile for _, tile in path)))
            if answer is None:
                for site, tile in reversed(path):
                    proof = (site, ((tile, proof),))
            return answer, proof
        counts["forced"] += len(moves) == 1
        counts["blocked"] += not moves
        branches = []
        for pose in moves:
            tile = board.tile(pose)
            remaining, allowed = board.apply(pose, wanted, active)
            counts["tile_applications"] += 1
            answer, child = visit(remaining, allowed, (*chosen, tile))
            if answer is not None:
                return answer, None
            branches.append((tile, child))
        return None, (board.site(r, i), tuple(branches))

    try:
        patch, proof = visit(uncovered, placements, tuple(seed))
    except (TimeoutError, RecursionError) as exc:
        reason = "NODE_LIMIT" if isinstance(exc, TimeoutError) else "RECURSION_LIMIT"
        return dict(status="BOUNDED", reason=reason, counts=dict(counts), initial_placements=initial)
    status = "POSITIVE" if patch is not None else "NEGATIVE"
    return dict(status=status, counts=dict(counts), initial_placements=initial, patch=patch, proof=proof)
