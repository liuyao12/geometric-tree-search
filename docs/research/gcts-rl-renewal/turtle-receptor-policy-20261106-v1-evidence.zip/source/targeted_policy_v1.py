"""Remove the exposed tile that contains the first disputed branch sample."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from geometry_v1 import chain
from move_policy_study_v1 import evaluate
from repair_v1 import freeze, ring_of
from site_cover_study_v1 import Audit, Region, audit_cover, cases, load, save, setup


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    g, _, _ = setup()
    original = next(row for row in cases(g) if row["id"] == "repair-14")
    witness = load("data/repair-14-policy-witness-v1.json")["first_proposal"]
    site = tuple(witness["site"])
    tiles = original["construction"]
    removed, = (t for t in tiles if site in g.sites(t))
    assert removed == tuple(witness["candidates"][0])
    assert not chain(g, tiles).isdisjoint(g.boundary(removed))
    patch = tuple(t for t in tiles if t != removed)
    ring = ring_of(g, patch)
    assert ring is not None
    row = dict(id="branch-trim-14", parent=original["id"], partition="test", rings=(ring,))
    region = Region(g, row["rings"])
    assert site not in region.sites
    verified = audit_cover(Audit(g.model), region, patch)
    train = load("data/move-policy-training-v1.json")
    models = {k: {tuple(feature): weight for feature, weight in data["weights"]}
              for k, data in train["learned"].items()}
    bank = freeze(load("data/move-policy-bank-v1.json"))
    result, = evaluate(g, (row,), models, bank)
    save("move-policy-targeted", dict(removed=removed, site=site, rings=(ring,), cover=verified, result=result))


if __name__ == "__main__":
    main()
