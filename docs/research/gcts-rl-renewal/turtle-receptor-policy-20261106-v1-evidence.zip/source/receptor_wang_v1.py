"""Verify the same Wang proof of a compound mark on donor and receiver."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from conflict_study_v1 import audit_conflicts
from opaque_replay_v1 import build_bank, verify_bank
from receptor_v1 import instance, reachable
from schematic_capsules_v1 import encoded, frozen
from site_cover_study_v1 import Region, cases, load, setup
from study_v1 import Certificate
from transfer_wang_v1 import prepare


DATA = ROOT / "wang/data"


def subproof(proof, root):
    refs = reachable(proof, root)
    index = {ref: j for j, ref in enumerate(refs)}
    return [dict(proof[j], children=tuple((t, index[k]) for t, k in proof[j]["children"])) for j in refs]


def proof_for(rows):
    tiles = sorted({t for row in rows for t in row["core"]})
    names = {tile: "T" + str(i) for i, tile in enumerate(tiles, 1)}
    sources = {}
    for j, row in enumerate(rows):
        clause = tuple((False, (names[t],)) for t in row["core"])
        clause += tuple((True, (names[t],)) for t, _ in row["children"])
        key = "site-" + str(j)
        sources[key] = dict(id=key, variables={}, clause=clause)
    for i, t in enumerate(rows[-1]["core"]):
        key = "assume-" + str(i)
        sources[key] = dict(id=key, variables={}, clause=((True, (names[t],)),))
    b = Certificate(sources, {}, {name: [] for name in names.values()}, ["U"], {})
    conclusions = []
    for j, row in enumerate(rows):
        ref = b.instance("site-" + str(j), {})
        for tile, child in row["children"]:
            ref = b.resolve(ref, conclusions[child], (names[tile],))
        conclusions.append(ref)
    for i, tile in enumerate(rows[-1]["core"]):
        premise = b.instance("assume-" + str(i), {})
        ref = b.resolve(premise, ref, (names[tile],))
    assert not b.lines[ref]["clause"]
    return sources, frozen(b.lines), {name: tile for tile, name in names.items()}


def problem():
    g, _, _ = setup()
    rows = {row["id"]: row for row in cases(g)}
    data = frozen(load("data/receptor-witness-v1.json"))
    template = data["template"]
    endpoints = {}
    for name, answer, root, anchor in (
        (template["donor"], data["donor_proof"], template["root"], template["origin"]),
        (data["receiver"], data["receiver_proof"], data["receiver_root"], data["anchor"]),
    ):
        region = Region(g, rows[name]["rings"])
        audit_conflicts(region, answer)
        sub = subproof(answer["proof"], root)
        assert sub == instance(g, template, anchor)
        endpoints[name] = proof_for(sub)
    donor, receiver = (endpoints[n] for n in (template["donor"], data["receiver"]))
    assert donor[:2] == receiver[:2]
    assert template["origin"] != data["anchor"] and donor[2] != receiver[2]
    placements = {n: v[2] for n, v in endpoints.items()}
    return donor[0], donor[1], placements, data


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    sources, expected, placements, data = problem()
    proof_path = DATA / "receptor-proof-v1.json"
    bank_path = DATA / "receptor-bank-v1.json.gz"
    receipt_path = DATA / "receptor-receipt-v1.json"
    proof = expected if rebuild else frozen(json.loads(proof_path.read_text()))
    assert proof == expected
    wires, calls = prepare(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(records=len(calls), rows=len(data["template"]["nodes"]),
                   template=data["template"]["id"], placements=placements, **verify_bank(wires, bank))
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert json.loads(encoded(receipt)) == json.loads(receipt_path.read_text())
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
