"""Mine on donor outlines, bind on held outlines, and audit actual imports."""
from argparse import ArgumentParser
from collections import defaultdict
from pathlib import Path
from statistics import median
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from conflict_study_v1 import audit_conflicts, cap_for, occupied
from conflict_v1 import search
from receptor_v1 import Binder, Inventory, compile_bank, instance
from site_cover_study_v1 import (
    Audit, Board, Region, audit_cover, cases, independent_domains, save, setup,
)
from site_cover_v1 import bits


MODES = ("online", "leaves", "compound", "universal", "both")
TIMED = {"repair-06", "repair-09", "repair-13", "repair-14", "repair-15", "rotated-hole"}


def mine(g, rows, verify):
    donors = {}
    receipts = {}
    for row in rows:
        if row["partition"] != "train":
            continue
        region = Region(g, row["rings"])
        name = row["id"]
        answer = search(Board(region), cap_for(row, region))
        donors[name] = answer
        if verify:
            receipt = audit_conflicts(region, answer)
            assert answer["status"] == "POSITIVE"
            receipt["cover"] = audit_cover(Audit(g.model), region, answer["patch"])
            receipts[name] = receipt
    leaves, compounds = compile_bank(g, donors)
    for j, template in enumerate(leaves + compounds):
        template["id"] = j
    banks = {
        "online": [], "leaves": leaves, "compound": compounds, "both": leaves + compounds,
        "universal": [t for t in leaves + compounds if not t["guards"]],
    }
    return banks, donors, receipts


def import_audit(region, bank, answer):
    proof = answer["proof"]
    kinds = defaultdict(int)
    for j, anchor, ref in answer.get("imports", ()):
        template = bank[j]
        expected = instance(region.g, template, anchor)
        start = ref + 1 - len(expected)
        for row in expected:
            row["children"] = tuple((t, start+k) for t, k in row["children"])
        assert proof[start:ref+1] == expected
        kinds["compound" if len(expected) > 1 else "leaf"] += 1
        kinds["guarded" if template["guards"] else "universal"] += 1
    ev = answer.get("first_import")
    if ev is not None:
        j, ref, anchor = ev["template"], ev["ref"], ev["anchor"]
        assert (j, anchor, ref) in answer["imports"]
        occupied(region, ev["placements"])
        assert ev["placements"][-1] == ev["trigger"]
        assert ev["trigger"] in proof[ref]["core"] and set(proof[ref]["core"]) <= set(ev["placements"])
    return dict(kinds)


def guard_control(region, board, templates):
    """Find an in-bounds occurrence whose geometry changes a proof premise."""
    binder = Binder(board)
    domain = independent_domains(region)
    g = region.g
    for template in templates:
        if not template["guards"]:
            continue
        admitted = binder.fit(template)
        naive = binder.fit(template, enforce_guards=False)
        rejected = naive & ~admitted
        if not rejected:
            continue
        anchor = board.cell(next(bits(rejected)))
        rows = instance(g, template, anchor)
        answer = dict(status="BOUNDED", root=None, proof=rows, first_reuse=None)
        try:
            audit_conflicts(region, answer)
        except AssertionError:
            pass
        else:
            raise AssertionError("Guard-free import accepted by geometry auditor")
        for row in rows:
            used = set().union(*(g.sites(t) for t in row["core"]))
            children = {t for t, _ in row["children"]}
            for tile, samples in domain(row["site"]).items():
                if tile not in children and used.isdisjoint(samples):
                    assert tile in {g.shift(t, anchor) for t in template["guards"]}
                    return dict(template=template["id"], anchor=anchor, candidate=tile,
                                checked_site=row["site"], core=row["core"],
                                naive_embeddings=naive.bit_count(), admitted_embeddings=admitted.bit_count())
        raise AssertionError("Expected a concrete new option")
    return None


def direct_fit(region, board, template):
    """Reference binder using explicit coordinates, independent of the bit shifts."""
    g, s = region.g, region.g.model.scale
    a, b = template["nodes"][-1][0]
    receiver = {(x//s, y//s) for x, y in region.sites if (x % s, y % s) == (a, b)}
    verified = set()
    for anchor in receiver:
        x, y = anchor
        if any((u+s*x, v+s*y) not in region.sites for u, v in template["sites"]):
            continue
        if any(not g.sites(g.shift(t, anchor)) <= region.sites for t in template["allowed"]):
            continue
        if any(g.sites(g.shift(t, anchor)) <= region.sites for t in template["guards"]):
            continue
        verified.add(anchor)
    observed = {board.cell(i) for i in bits(Binder(board).fit(template))}
    assert observed == verified
    return len(verified)


def witness(banks, donors, row, answer):
    j, anchor, ref = min((item for item in answer["imports"] if len(banks["both"][item[0]]["nodes"]) > 1),
                         key=lambda item: (len(banks["both"][item[0]]["nodes"]), item))
    template = banks["both"][j]
    return dict(receiver=row["id"], anchor=anchor, template=template, donor_proof=donors[template["donor"]],
                receiver_proof=answer, receiver_root=ref)


def study(g, rows, banks, donors, donor_receipts):
    results, example, rejected, exact = [], None, None, None
    for row in rows:
        if row["partition"] != "test":
            continue
        name = row["id"]
        region = Region(g, row["rings"])
        board = Board(region)
        cap = cap_for(row, region)
        result = dict(id=name, tiles=region.counts[0], cap=cap, arms={})
        for mode in MODES:
            bank = banks[mode]
            bound = Inventory(board, bank) if bank else None
            answer = search(board, cap, inventory=bound)
            receipt = audit_conflicts(region, answer)
            receipt["imports"] = import_audit(region, bank, answer)
            if answer["status"] == "POSITIVE":
                receipt["cover"] = audit_cover(Audit(g.model), region, answer["patch"])
            result["arms"][mode] = dict(status=answer["status"], counts=answer["counts"], checked=receipt,
                                        candidate_anchors=sum(m.bit_count() for m in bound.fits) if bound else 0)
            if mode == "both" and name == "repair-14":
                example = witness(banks, donors, row, answer)
            if mode == "both" and name == "repair-06":
                rejected = guard_control(region, board, bank)
                assert rejected is not None
                guarded = next(t for t in bank if t["id"] == rejected["template"])
                exact = {str(t["id"]): direct_fit(region, board, t) for t in (bank[0], guarded, bank[-1])}
        statuses = {r["status"] for r in result["arms"].values()} - {"BOUNDED"}
        assert len(statuses) <= 1
        print(name, [(k, a["status"], a["counts"]["nodes"], a["counts"].get("import_hits", 0))
                     for k, a in result["arms"].items()], flush=True)
        results.append(result)
    assert example and rejected
    save("receptor-study", dict(cases=results, bank=banks["both"], donors=donor_receipts,
                                guard_test=dict(rejected, receiver="repair-06"), exact=exact))
    save("receptor-witness", example)


def timing(rows, banks, repeats):
    results = []
    for row in rows:
        if row["id"] not in TIMED:
            continue
        elapsed, binding = defaultdict(list), defaultdict(list)
        for i in range(repeats):
            for mode in (*MODES[i % len(MODES):], *MODES[:i % len(MODES)]):
                g, _, _ = setup()
                start = perf_counter()
                region = Region(g, row["rings"])
                board = Board(region)
                before = perf_counter()
                inv = Inventory(board, banks[mode]) if banks[mode] else None
                binding[mode].append(perf_counter() - before)
                outcome = search(board, cap_for(row, region), inventory=inv)
                elapsed[mode].append(perf_counter() - start)
                assert outcome["status"] != "BOUNDED"
        medians = {k: median(v) for k, v in elapsed.items()}
        results.append(dict(id=row["id"], trials=dict(elapsed), binding=dict(binding), medians=medians))
        print(row["id"], {k: round(v, 3) for k, v in medians.items()}, flush=True)
    save("receptor-timing", results)


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--timing", type=int, default=0, metavar="REPEATS")
    repeats = parser.parse_args().timing
    g, _, _ = setup()
    rows = cases(g)
    banks, donors, receipts = mine(g, rows, verify=not repeats)
    if repeats:
        timing(rows, banks, repeats)
    else:
        study(g, rows, banks, donors, receipts)


if __name__ == "__main__":
    main()
