"""Compile relative conflict proofs and bind their guards to a new outline."""
from collections import defaultdict
from functools import lru_cache

from site_cover_v1 import bits, translation


def reachable(proof, root):
    pending, seen = [root], set()
    while pending:
        j = pending.pop()
        if j not in seen:
            seen.add(j)
            pending.extend(k for _, k in proof[j]["children"])
    return sorted(seen)


def shift_site(site, shift, scale):
    return tuple(x + scale*d for x, d in zip(site, shift, strict=True))


def all_domains(g):
    """Primitive placements incident to a site on the whole lattice."""
    scale = g.model.scale
    by_residue = defaultdict(list)
    for h, _, _ in g.bases:
        for x, y in g.sites((h, 0, 0)):
            u, a = divmod(x, scale)
            v, b = divmod(y, scale)
            by_residue[a, b].append((h, -u, -v))

    def domain(site):
        u, a = divmod(site[0], scale)
        v, b = divmod(site[1], scale)
        return tuple(sorted(g.shift(t, (u, v)) for t in by_residue[a, b]))

    return domain


def compile_bank(g, donors, per_kind=24):
    domain = all_domains(g)
    scale = g.model.scale
    templates = {}

    @lru_cache(maxsize=4096)
    def row_guards(site, core, children):
        used = set().union(*(g.sites(t) for t in core))
        return tuple(t for t in domain(site) if t not in children and used.isdisjoint(g.sites(t)))

    for name, answer in donors.items():
        proof = answer["proof"]
        for i, row in enumerate(proof):
            if not 2 <= len(row["core"]) <= 10:
                continue
            refs = reachable(proof, i)
            if len(refs) > 8:
                continue
            origin = tuple(x // scale for x in row["site"])
            relative = tuple(-x for x in origin)
            index = {ref: j for j, ref in enumerate(refs)}
            nodes = []
            allowed, forbidden, sites = set(), set(), set()
            for ref in refs:
                original = proof[ref]
                site = shift_site(original["site"], relative, scale)
                core = tuple(g.shift(t, relative) for t in original["core"])
                children = tuple((g.shift(t, relative), index[j]) for t, j in original["children"])
                nodes.append((site, core, children))
                sites.add(site)
                allowed.update(core)
                forbidden.update(row_guards(site, core, tuple(t for t, _ in children)))
            assert allowed.isdisjoint(forbidden)
            key = tuple(nodes)
            templates.setdefault(key, dict(nodes=key, donor=name, root=i, origin=origin,
                                           allowed=tuple(sorted(allowed)), guards=tuple(sorted(forbidden)),
                                           sites=tuple(sorted(sites))))

    def rank(t):
        return len(t["nodes"][-1][1]), len(t["guards"]), len(t["nodes"]), t["nodes"]

    ordered = sorted(templates.values(), key=rank)
    leaves = [t for t in ordered if len(t["nodes"]) == 1][:per_kind]
    compounds = [t for t in ordered if len(t["nodes"]) > 1][:per_kind]
    return leaves, compounds


class Binder:
    """For each template, find receiver anchors by exact mask intersections."""
    def __init__(self, board):
        self.board = board
        self.width = w = board.width
        height = (max(b.bit_length() for b in board.wanted) + w - 1) // w
        self.column = ((1 << (height*w)) - 1) // ((1 << w) - 1)
        self.aligned_poses = {}
        self.aligned_sites = {}

    def align(self, mask, dx, dy):
        start = max(0, dx)
        stop = min(self.width, self.width + dx)
        if start >= stop:
            return 0
        columns = (((1 << (stop-start)) - 1) << start) * self.column
        return translation(mask & columns, -self.board.offset((dx, dy)))

    def pose(self, tile):
        if tile not in self.aligned_poses:
            turn, x, y = tile
            h = self.board.by_turn[turn]
            u, v = self.board.offsets[h]
            self.aligned_poses[tile] = self.align(self.board.initial[h], x+u, y+v)
        return self.aligned_poses[tile]

    def site(self, sample):
        if sample not in self.aligned_sites:
            s = self.board.scale
            x, a = divmod(sample[0], s)
            y, b = divmod(sample[1], s)
            r = self.board.residue_ids[a, b]
            self.aligned_sites[sample] = self.align(self.board.wanted[r], x, y)
        return self.aligned_sites[sample]

    def fit(self, template, enforce_guards=True):
        anchors = self.site(template["nodes"][-1][0])
        for q in template["sites"]:
            anchors &= self.site(q)
        for t in template["allowed"]:
            if not anchors:
                return 0
            anchors &= self.pose(t)
        if enforce_guards:
            for t in template["guards"]:
                if not anchors:
                    return 0
                anchors &= ~self.pose(t)
        return anchors


def instance(g, template, anchor):
    return [dict(site=shift_site(q, anchor, g.model.scale),
                 core=tuple(g.shift(t, anchor) for t in core),
                 children=tuple((g.shift(t, anchor), j) for t, j in children))
            for q, core, children in template["nodes"]]


class Inventory:
    def __init__(self, board, templates):
        self.board = board
        self.templates = templates
        binder = Binder(board)
        self.watch = defaultdict(list)
        self.fits = []
        for j, template in enumerate(templates):
            anchors = binder.fit(template)
            self.fits.append(anchors)
            if not anchors:
                continue
            relative = []
            for turn, x, y in template["nodes"][-1][1]:
                h = board.by_turn[turn]
                a, b = board.offsets[h]
                relative.append((h, board.offset((x+a, y+b))))
            for h, delta in relative:
                self.watch[h].append((delta, anchors, tuple(relative), j))

    def match(self, pose, selected):
        h, i = pose
        for delta, anchors, relative, j in self.watch[h]:
            a = i - delta
            if 0 <= a < anchors.bit_length() and (anchors >> a) & 1:
                if all((selected[k] >> (a+d)) & 1 for k, d in relative):
                    return j, self.board.cell(a)
        return None

    def instance(self, j, anchor):
        return instance(self.board.g, self.templates[j], anchor)
