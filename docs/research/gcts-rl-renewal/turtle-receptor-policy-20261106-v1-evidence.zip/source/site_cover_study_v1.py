"""Matched Turtle outline tests, residue-order policy and independent certificates."""
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache
import json
from pathlib import Path
from random import Random
from statistics import median
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_repair_v1 import check_cover
from collar_audit_v1 import Audit, exposed
from repair_v1 import Region, atlas_seed, freeze, load, mark_repair, rectangle, setup, solve
from site_cover_v1 import Board, bits, search


ROOT = Path(__file__).resolve().parents[1]
ACTIONS = (0, 2, 4, 6, 8, 10)


def save(name, value):
    (ROOT / "data" / (name + "-v1.json")).write_text(
        json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n")


def cases(g):
    rows = freeze(load("input/cases-v1.json"))
    base = next(row for row in rows if row["id"] == "repair-06")
    outer = base["rings"][0]
    x, y = (sum(p[i] for p in outer) // len(outer) for i in (0, 1))
    actual = min(base["construction"], key=lambda t: ((t[1] - x) ** 2 + (t[2] - y) ** 2, t))
    rotate = ((actual[0] + 1) % len(g.turns), *actual[1:])
    assert rotate not in base["construction"]
    for name, tile in (("hole-from-cover", actual), ("rotated-hole", rotate)):
        rings = outer, g.poly(tile)[::-1]
        rows += (dict(id=name, kind="prescribed hole", partition="test", rings=rings),)
    for j, (a, b) in enumerate(((4, 5), (5, 4), (8, 5), (5, 8), (12, 5), (5, 12))):
        rows += (dict(id=f"rectangle-{j + 1}", kind="area-compatible rectangle", partition="test",
                      rings=(rectangle(183*j+11, -201*j+8, a, b),)),)
    return rows


def budget(region):
    return max(360, 2 * region.counts[0] + 40)


def order(start):
    return tuple(range(start, 12)) + tuple(range(start))


def train(g, rows):
    donors = {r["id"]: Region(g, r["rings"]) for r in rows if r["partition"] == "train"}
    boards = {name: Board(region) for name, region in donors.items()}
    rng = Random(512083)
    rewards = defaultdict(list)
    tried = {}
    episodes = list(donors) * 8
    rng.shuffle(episodes)
    history = []
    for name in episodes:
        unseen = [a for a in ACTIONS if a not in rewards]
        explore = bool(unseen) or rng.randrange(5) == 0
        a = rng.choice(unseen or ACTIONS) if explore else best(rewards)
        key = name, a
        if key not in tried:
            tried[key] = search(boards[name], budget(donors[name]), "batch", residue_order=order(a))
        outcome = tried[key]
        counts = outcome["counts"]
        cost = sum(counts.get(k, 0) * w for k, w in
                   (("nodes", 1), ("residue_sweeps", 3), ("site_probes", 1), ("tile_applications", 1)))
        reward = -Fraction(cost, donors[name].counts[0]) - (100 if outcome["status"] == "BOUNDED" else 0)
        rewards[a].append(reward)
        history.append(dict(case=name, residue=a, explore=explore, cost=cost, status=outcome["status"],
                            reward=[reward.numerator, reward.denominator]))
    return dict(selected=best(rewards), episodes=history)


def best(rewards):
    return max(rewards, key=lambda a: (sum(rewards[a]) / len(rewards[a]), -a))


def audit_cover(audit, region, tiles):
    if len(region.rings) == 1:
        return check_cover(region.g, audit, region, tiles)
    g = region.g
    used = set()
    for tile in tiles:
        atoms = set(g.sites(tile))
        assert not used.intersection(atoms)
        used.update(atoms)
    assert used == region.sites
    assert exposed(g.model.poly(tile) for tile in tiles) == set(region.edges)
    assert len(tiles) == region.counts[0]
    return dict(tiles=len(tiles), perimeter=len(region.edges), sites=len(used))


def independent_domains(region):
    """Enumerate incident poses by direct sample translation, without masks."""
    s, g = region.g.model.scale, region.g
    index = defaultdict(list)
    for (h, _, _) in g.bases:
        for x, y in sorted(g.sites((h, 0, 0))):
            index[x % s, y % s].append((h, x, y))

    @lru_cache(maxsize=200)
    def incident(site):
        x, y = site
        found = {}
        for h, a, b in index[x % s, y % s]:
            tile = (h, (x-a) // s, (y-b) // s)
            part = g.sites(tile)
            if part <= region.sites:
                assert tile not in found
                found[tile] = part
        return found

    return incident


def audit_negative(region, tree):
    incident = independent_domains(region)
    stack = [(tree, frozenset())]
    nodes = branches = leaves = 0
    while stack:
        (site, children), occupied = stack.pop()
        assert site in region.sites and site not in occupied
        legal = {tile: sites for tile, sites in incident(site).items() if occupied.isdisjoint(sites)}
        recorded = {tile: subtree for tile, subtree in children}
        assert len(recorded) == len(children) and recorded.keys() == legal.keys()
        nodes += 1
        branches += len(children)
        leaves += not children
        stack.extend((subtree, occupied | legal[tile]) for tile, subtree in children)
    return dict(nodes=nodes, branches=branches, leaves=leaves)


def audit_catalogue(region, board):
    """Cross-check the entire packed initial catalogue by explicit offsets."""
    g = region.g
    s = g.model.scale
    samples = defaultdict(list)
    for x, y in region.sites:
        samples[x % s, y % s].append((x, y))
    expected = set()
    for h, _, _ in g.bases:
        offsets = sorted(g.sites((h, 0, 0)))
        ax, ay = offsets[0]
        for x, y in samples[ax % s, ay % s]:
            dx, dy = x - ax, y - ay
            if all((a + dx, b + dy) in region.sites for a, b in offsets):
                expected.add((h, dx // s, dy // s))
    packed = {board.tile((h, i)) for h, mask in enumerate(board.initial) for i in bits(mask)}
    assert packed == expected
    return len(expected)


def run(g, atlas, inv, rows, policy):
    audit = Audit(g.model)
    results = []
    for row in rows:
        if row["partition"] != "test":
            continue
        region = Region(g, row["rings"])
        board = Board(region)
        cap = budget(region)
        initial_holes = sum(board.cover(r, u, board.initial)[0].bit_count() for r, u in enumerate(board.wanted))
        arms = {"boundary": solve(region, inv, row["id"], limit=cap)}
        for mode in ("sample", "sweep", "batch"):
            arms[mode] = search(board, cap, mode)
        arms["learned"] = search(board, cap, "batch", residue_order=order(policy["selected"]))
        # The large case keeps the hierarchy as a separate source of proposals.
        if row["id"] == "repair-14":
            all_tiles, _, _ = atlas_seed(g, atlas, region)
            seed, _, _ = mark_repair(region, inv, all_tiles)
            answer = search(board, cap, "batch", seed=seed)
            assert answer["status"] == "POSITIVE"
            arms["atlas-batch"] = dict(answer, seed=len(seed))
        checked = {}
        for arm, answer in arms.items():
            if answer["status"] == "POSITIVE":
                checked[arm] = audit_cover(audit, region, answer["patch"])
            elif answer["status"] == "NEGATIVE" and arm != "boundary":
                checked[arm] = audit_negative(region, answer["proof"])
        if row["id"] == "rotated-hole":
            assert initial_holes == 0
            site, children = arms["batch"]["proof"]
            assert children
            try:
                audit_negative(region, (site, children[1:]))
            except AssertionError:
                rejected = True
            else:
                raise AssertionError("An omitted exact-cover branch was accepted")
        else:
            rejected = None
        catalogue = audit_catalogue(region, board) if row["id"] in ("repair-13", "rotated-hole", "hole-from-cover") else None
        item = dict(id=row["id"], kind=row["kind"], rings=row["rings"], tiles=region.counts[0],
                    initial_placements=sum(v.bit_count() for v in board.initial), unsupported=initial_holes,
                    arms=arms, checked=checked, omission_rejected=rejected, catalogue_checked=catalogue)
        results.append(item)
        print(row["id"], [(k, v["status"], v["counts"]["nodes"]) for k, v in arms.items()], flush=True)
    return results


def timing(rows, policy):
    selected = {"repair-06", "repair-13", "repair-14", "rotated-hole"}
    times = []
    for row in rows:
        if row["id"] not in selected:
            continue
        measurements = defaultdict(list)
        for i in range(5):
            actions = ("boundary", "batch", "learned")
            for mode in (*actions[i % 3:], *actions[:i % 3]):
                g, _, inv = setup()
                start = perf_counter()
                region = Region(g, row["rings"])
                cap = budget(region)
                if mode == "boundary":
                    solve(region, inv, row["id"], limit=cap)
                else:
                    board = Board(region)
                    search(board, cap, "batch", residue_order=order(policy["selected"]) if mode == "learned" else None)
                measurements[mode].append(perf_counter() - start)
        times.append(dict(id=row["id"], median={k: median(v) for k, v in measurements.items()},
                          samples=dict(measurements)))
    return times


def main():
    g, atlas, inv = setup()
    rows = cases(g)
    if sys.argv[1:] == ["--time"]:
        save("timing", timing(rows, load("data/policy-v1.json")))
        return
    assert not sys.argv[1:]
    policy = train(g, rows)
    save("policy", policy)
    print("Learned first residue", policy["selected"], flush=True)
    save("results", run(g, atlas, inv, rows, policy))


if __name__ == "__main__":
    main()
