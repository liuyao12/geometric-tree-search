"""Learn action scores from the return of each attempted Turtle placement."""
from collections import defaultdict
from math import log2
from random import Random

from site_cover_v1 import translation


FIXED = ("forward", "reverse", "fewest-conflicts", "most-conflicts")


class Ordering:
    def __init__(self, name, seed=0, weights=(), training=False):
        self.name = name
        self.rng = Random(seed)
        self.weights = defaultdict(float, weights)
        self.training = training
        self.epsilon = .20
        self.steps = 0
        self.solves = 0
        self.return_sum = 0.

    def features(self, board, wanted, r, i, moves, depth):
        x, y = board.cell(i)
        neighborhood = 0
        for j, delta in enumerate(((1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1))):
            q = i + board.offset(delta)
            if q >= 0 and (wanted[r] >> q) & 1:
                neighborhood |= 1 << j
        size = min(len(moves), 7)
        progress = min(3, 4 * depth // board.tile_count)
        result = {}
        for rank, pose in enumerate(moves):
            h, a, b = board.tile(pose)
            order = (2 * rank + (len(moves)-1)//2) // (len(moves)-1)
            dx, dy = a-x, b-y
            result[pose] = (
                ("turn", h), ("rank", size, order), ("offset", r, h, dx, dy),
                ("local", r, neighborhood, h), ("offset-local", r, neighborhood, h, dx, dy),
                ("progress", progress, size, order),
            )
        return result

    def arrange(self, board, wanted, active, r, i, moves, depth):
        if self.name == "learned":
            features = self.features(board, wanted, r, i, moves, depth)
            scores = tuple(sum(self.weights.get(f, 0.) for f in features[pose]) for pose in moves)
        elif self.name in ("fewest-conflicts", "most-conflicts"):
            multiplier = 1 if self.name == "most-conflicts" else -1
            scores = tuple(multiplier * sum(
                (mask & translation(form, j+start)).bit_count()
                for mask, (form, start) in zip(active, board.conflicts[h], strict=True)
            ) for h, j in moves)
            features = None
        elif self.name == "random":
            scores, features = tuple(self.rng.random() for _ in moves), None
        elif self.name == "reverse":
            return moves[::-1], None, None
        else:
            assert self.name == "forward"
            return moves, None, None
        if self.training and self.rng.random() < self.epsilon:
            order = list(moves)
            self.rng.shuffle(order)
            return tuple(order), scores, features
        by_score = sorted(zip(scores, moves, strict=True), key=lambda row: row[0], reverse=True)
        return tuple(pose for _, pose in by_score), scores, features

    def feedback(self, features, visits, solved):
        value = (8 if solved else 0) - min(7, log2(1 + visits))
        error = value - sum(self.weights.get(f, 0.) for f in features)
        for f in features:
            self.weights[f] += .16 * error / len(features)
        self.steps += 1
        self.solves += solved
        self.return_sum += value
