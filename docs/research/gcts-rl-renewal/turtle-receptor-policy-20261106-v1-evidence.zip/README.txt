Learning which Turtle placement to try first

From the archive root, run these commands with Python 3.12.

    python3 -I -S -B source/move_policy_study_v1.py
    python3 -I -S -B source/targeted_policy_v1.py
    python3 -I -S -B source/core_wang_v1.py --build
    python3 -I -S -B source/core_wang_v1.py
    python3 -I -S -B publication/render_v1.py

These commands mine donor marks, train all three policies, run and audit
the held-outline searches, replay the Wang proof, and render the HTML.

The saved timing receipt is machine-dependent. To repeat the timed
trials, run move_policy_study_v1.py with --timing 3.
