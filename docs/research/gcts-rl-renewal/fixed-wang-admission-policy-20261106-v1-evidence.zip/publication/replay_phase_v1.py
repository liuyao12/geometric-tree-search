"""Replay one pinned phase in a clean directory without changing the archive."""

import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
PHASES = {
    "admission": ("admission-protocol-v1.json", "admission_experiment_v1.py", True),
    "wide": ("wide-context-protocol-v1.json", "widened_context_v1.py", True),
    "ground": ("ground-marks-protocol-v1.json", "ground_marks_v1.py", False),
    "slice": ("atom-slice-protocol-v1.json", "atom_slice_v1.py", False),
    "marks": ("marks-protocol-v1.json", "marked_lemma_pilot_v1.py", False),
    "lazy": ("lazy-protocol-v1.json", "lazy_experiment_v1.py", False),
}


def main():
    phase, destination, *dependencies = sys.argv[1:]
    protocol, source, needs_dependency = PHASES[phase]
    assert len(dependencies) == int(needs_dependency)
    target = Path(destination).resolve() / phase
    target.mkdir(parents=True)
    (target / "data").mkdir()
    spec = json.loads((ROOT / protocol).read_bytes())
    for name in (protocol, *spec["pins"]):
        child = Path(name)
        assert not child.is_absolute() and ".." not in child.parts
        (target / child).parent.mkdir(parents=True, exist_ok=True)
        archived = ROOT / child
        if phase in {"marks", "lazy"} and name == "source/lemma_search_v1.py":
            archived = ROOT / "prior/marked-pilot/original-lemma-search_v1.py"
        shutil.copyfile(archived, target / child)
    subprocess.run([sys.executable, "-I", "-S", "-B", str(target / "source" / source),
                    *[str(Path(p).resolve()) for p in dependencies]], cwd=target, check=True)


if __name__ == "__main__":
    main()
