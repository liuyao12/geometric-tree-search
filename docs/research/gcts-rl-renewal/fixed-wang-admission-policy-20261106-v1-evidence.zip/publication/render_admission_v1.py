"""Build the visual notebook for checked lemma admission and atom cuts."""

from html import escape
import json
from pathlib import Path
import random
from statistics import median
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from shared_reader_v1 import ROOT, STYLE, clause, load, math, panel, table, title

STEM = "fixed-wang-admission-policy-20261106-v1"
OLD = "fixed-wang-lemma-transfer-20261106-v1.html"


def short(n):
    return {"agatha-vampire-guide":"Agatha", "hilbert-incidence-uniqueness":"Hilbert incidence",
            "pigeonhole-4-3":"Four pigeons, three holes",
            "pigeonhole-5-4-fresh":"Five pigeons, four holes",
            "pigeonhole-4-4-fresh":"Four pigeons, four holes",
            "pigeonhole-3-3":"Three pigeons, three holes",
            "pigeonhole-2-2":"Two pigeons, two holes"}.get(
                n, n.replace("-fresh", "").replace("odd-cycle-", "Odd cycle ").replace("broken-cycle-", "Broken cycle "))


def display_names(spec):
    if spec["family"] == "cycle":
        names = [f"color{i}" for i in range(spec["size"])]
    else:
        names = [f"pigeon{i}hole{j}" for i in range(spec["size"]) for j in range(spec["holes"])]
    names = sorted(["claim", *names, *(f"unused{i}" for i in range(2*spec.get("noise",0)))])
    labels = [f"bit{i:02}" for i in range(len(names))]
    random.Random(spec["seed"]).shuffle(labels)
    return dict(zip(labels,names,strict=True))


def humanize(proof, source, names):
    if not names:
        return proof,source

    def rename(node):
        if node[0] == "atom":
            return [node[0],names[node[1]],*node[2:]]
        return [node[0],*(rename(n) for n in node[1:])]

    return ({**proof,"atoms":[[names[p],*t] for p,*t in proof["atoms"]]},
            {**source,"premises":[rename(p) for p in source["premises"]],"goal":rename(source["goal"])})


def gate_chart(rows):
    maximum=max(r["base"]["gates"] for r in rows)
    svg=[]
    for i,r in enumerate(rows):
        y=26+88*i
        svg.append(f'<text x="12" y="{y}" font-size="16">{escape(short(r["id"]))}</text>')
        for j,(key,color) in enumerate((("base","#9aacc5"),("reduced","#527a66"))):
            gates=r[key]["gates"]
            width=max(2,480*gates/maximum)
            by=y+8+23*j
            svg.append(f'<rect x="12" y="{by}" width="{width:.2f}" height="16" rx="2" fill="{color}"></rect>'
                       f'<text x="{21+width:.2f}" y="{by+13}" font-size="14">{gates:,}</text>')
    return ('<svg class="gate-chart" viewBox="0 0 565 184" role="img" aria-labelledby="gate-title">'
            '<title id="gate-title">Full and reduced compiler gate counts for Agatha and Hilbert incidence</title>'
            + "".join(svg) + "</svg>")


def main():
    calibration = load("admission-protocol-v1.json")
    trained = load("data/admission-training-v1.json")
    admissions = load("data/admission-v1.json")
    slices = load("data/atom-slice-v1.json")
    wider = load("data/wide-context-v1.json")
    ground = load("data/ground-marks-v1.json")
    marks = load("prior/marked-pilot/marks-v1.json")
    lazy = load("prior/marked-pilot/lazy-v1.json")
    bank = {r["id"]:r for r in admissions}
    names = {r["id"]:display_names(r) for r in calibration["fresh_holdout"]}
    panels=[]
    for r in slices:
        panels.append((r["id"],panel(r,r["source"],r["rectangle_file"],
                                    f'Derivation found by {r["discovery"]}. This reader uses the reduced checked atom catalogue.')))
    for n in ("odd-cycle-7","pigeonhole-4-3"):
        r = next(r for r in bank[n]["results"] if r["arm"]=="learned")
        panels.append((n,panel({**r,"id":n},bank[n]["source"],r["rectangle_file"],
                               "The learned schedule selected two checked lemma outputs per receptor. Its derivation was expanded to source clauses and checked.")))
    large=next(r for r in ground if r["id"]=="pigeonhole-5-4-fresh")
    winner=next((r for r in large["rows"] if "rectangle" in r),None)
    if winner:
        n=large["id"]
        p,source=humanize(winner["proof"],bank[n]["source"],names[n])
        panels.append((n,panel({**winner,"id":n,"proof":p},source,winner["rectangle_file"],
                               "The search learned cuts on the statement atoms, replayed them as resolution, and checked the result. Descriptive names are restored in this reader.")))
    menu="".join(f'<option value="{n}">{escape(title(n))}</option>' for n,_ in panels)
    comparison=[]
    activity=[]
    action_counts={}
    for c in admissions:
        r={x["arm"]:x for x in c["results"]}
        assert r["initial"]["work"]==r["fixed-8"]["work"]
        assert r["learned"]["work"]==r["fixed-2"]["work"]
        for a,n in r["learned"]["actions"].items():
            action_counts[a]=action_counts.get(a,0)+n
        best=min((x for label,x in r.items() if label.startswith("fixed") and x["status"]!="BOUNDED"),
                 key=lambda x:x["work"],default=None)
        shams=[x["work"] for label,x in r.items() if label.startswith("shuffle")]
        comparison.append([short(c["id"]),r["learned"]["status"],c["offers"],r["fixed-0"]["work"],
                           r["initial"]["work"],r["learned"]["work"],int(median(shams)),
                           r["eager-library"]["work"],best["arm"] if best else "Bounded"])
        activity.append([short(c["id"]), c["validation"]["steps"], r["initial"]["stats"].get("pairs",0),
                         r["learned"]["stats"].get("pairs",0),r["learned"]["stats"].get("subset_probes",0),
                         r["learned"]["stats"].get("inserted_claims",0),
                         r["learned"].get("proof_work",{}).get("proof_replays",0),r["learned"]["checked"]])
    assert set(action_counts)=={"1"}
    pq=next(r for r in marks if r["id"]=="pigeonhole-4-3")["results"]
    pv=next(r for r in lazy if r["id"]=="pigeonhole-4-3")
    failure_rows=[[r["mode"],"Marked" if r["marked"] else "Plain",r["stats"]["pairs"],r["checked"],
                   r["stats"].get("subset_probes",0)] for r in pq]
    lazy_rows=[[r["mode"],"Deferred" if r["kernel"]=="LazySearch" else "Eager",r["stats"]["pairs"],
                r["stats"].get("macro_replays",0),r.get("proof_work",{}).get("proof_replays",0)]
               for r in pv["results"]]
    slice_rows=[[short(r["id"]),r["base"]["atoms"],r["reduced"]["atoms"],r["base"]["gates"],r["reduced"]["gates"],
                 r["attack"]["status"]] for r in slices]
    wide_rows=[[short(r["id"]),bank[r["id"]]["offers"],r["offers"],
                sum(c["status"]=="BOUNDED" for c in r["results"]),r["ground_control"]["counts"]["conflicts"]] for r in wider]
    ground_rows=[[short(r["id"]),a["mode"],a["imported"],a["status"],a["stats"].get("decisions",0),
                  len(a["cuts"]),len(a.get("proof",{}).get("proof",[])),a.get("rectangle",{}).get("status","—")]
                 for r in ground for a in r["rows"]]
    cut = min((c for r in large["rows"] if not r["seeded"] for c in r["cuts"] if len(c)>=2),key=len)
    atoms = list(map(list,(winner or next(r for r in large["rows"] if "proof" in r))["proof"]["atoms"]))
    key=names[large["id"]]
    labelled=[[key[p],*args] for p,*args in atoms]
    cut_formula=math(clause(cut,labelled))
    work_formula=math(r"W=P+\lceil S/4\rceil+4A+R")
    totals=len(trained["cases"])
    contexts=sum(len(c["samples"]) for c in trained["cases"])
    html=f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Which lemmas should enter a Wang proof?</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.proof-table{{table-layout:fixed}}.proof-table tr>:first-child{{width:3.15rem}}
.clause{{font-size:1.04rem;margin-bottom:.35rem}}.proof-table .strip{{overflow:auto}}
.gate-chart{{display:block;width:100%;max-width:660px;border:1px solid #ced9d1;background:#f8f8f3}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;overflow:auto;background:#e5eee6;padding:.7rem}}
figure{{margin-inline:0}}
</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · Admission policies and atom cuts · November 2026</p>
<h1>Which lemmas should enter a Wang proof?</h1>
<p>A learned admission schedule chose a small batch everywhere in the held-out bank. It helped on the smaller cycles. The harder pigeonhole instance required a different search representation.</p>
<nav aria-label="On this page"><a href="#reader">Proof lines</a><a href="#admission">Admission</a>
<a href="#defer">Failure marks</a><a href="#ground">Atom cuts</a><a href="#slice">Smaller certificates</a><a href="#evidence">Evidence</a></nav>
<p><a href="{OLD}">Previous notebook on composing proof clusters</a></p></header>
<section id="reader"><h2>Read the checked derivations</h2>
<p>Each formula line gives its source or its two resolution parents. Expand a line to see its Wang squares in placement order. The checker wires the discovered parent links and checks source admission, pivots and exact clause values.</p>
<p><label>Statement <select id="case-menu">{menu}</select></label></p>{''.join(p for _,p in panels)}</section>
<section id="admission"><h2>Learn which checked lemma batches to admit</h2>
<p>When a source clause reaches the frontier, its receptors offer checked lemma outputs. A batch takes up to zero, two, eight, thirty-two or all distinct candidates. Every arm ranks candidates by width, contact with settled clauses and recipe length. The shuffled arm samples the same quota before restoring rank order.</p>
<p>Training used {totals} separate synthetic cases and {contexts} paired anchor contexts. In each context, one batch action changed and the other actions followed the reference schedule. The policy gradient used the measured reward of all five rollouts. The frozen policy selected two at all {action_counts["1"]} held-out windows it reached. It ties the fixed-two schedule.</p>
<p>The training score {work_formula} counts resolution pair attempts, subset probes, admitted claims and final replay steps respectively. This is an experimental weighting. The component counts and one-time library validation appear separately.</p>
{table(["Statement","Learned outcome","Offers","Cold work","Initial work","Learned work","Shuffle median","Eager work","Best fixed"],comparison)}
{table(["Statement","Library validation steps","Initial pairs","Learned pairs","Subset probes","Claims admitted","Final replay steps","Checked marks"],activity)}
<p>Eight is better on four pigeons, and zero is better on the fresh eleven- and thirteen-cycles. The observed variation is a target for the next policy comparison.</p></section>
<section id="defer"><h2>Prune failures and expand only the lemmas used</h2>
<p>Two complementary contacts forbid every one-pivot join of a clause pair. A stronger clause already in the agenda can subsume a proposed resolvent. The checks replay these two failure marks from exact literal sets. Here is the earlier four-pigeon pilot with the same composed library.</p>
{table(["Library access","Failure marks","Pair attempts","Checked marks","Subset probes"],failure_rows)}
<p>A deferred run verifies the library once and holds its outputs as single search moves. It expands the outputs used by the final derivation. The four-pigeon library required {pv["library_validation"]["steps"]:,} validation steps, shared by both schedules.</p>
{table(["Library access","Expansion","Pairs","During search","After search"],lazy_rows)}</section>
<section id="ground"><h2>Learn cuts on the statement atoms</h2>
<p>The four-hole cases offered no placements with one extra literal per receptor. Allowing two extras created checked offers, while each clause saturation schedule still reached the common limit. Ground Glucose saw the same input and the certified output clauses.</p>
{table(["Statement","One-extra offers","Two-extra offers","Saturation runs bounded","Seeded Glucose conflicts"],wide_rows)}
<p>The atom search branches on truth values for ground statement atoms. A propagation failure traces back to a clause over the decisions. The search can jump past irrelevant decisions, and an independent pass replays every learned cut. One cut from the five-pigeon search appears below.</p>
<div class="scroll clause">{cut_formula}</div>
{table(["Statement","Atom order","Imported lemmas","Outcome","Decisions","Checked cuts","Resolution rows","Wang check"],ground_rows)}
<p>Proof rows are primitive resolutions from admitted source clauses after expanding any imported lemmas. The ground Glucose results measure conventional performance on the same finite formulas.</p></section>
<section id="slice"><h2>Give the checker a smaller atom catalogue</h2>
<p>The certificate includes only atoms used by the found proof. Every literal in a selected ground source instance still needs a matching atom, so deleting a literal cannot make that premise easier to admit. The attack changed an original premise to its truncated version. Both attacks were rejected.</p>
<figure>{gate_chart(slices)}<figcaption>The upper bar in each pair is the full wired circuit. The lower bar is the reduced circuit checked as a Wang rectangle.</figcaption></figure>
{table(["Statement","Full atoms","Reduced atoms","Full gates","Reduced gates","Omission attack"],slice_rows)}
<p>Both full circuits accept their respective derivations. Ground unit propagation found the quantified Agatha proof at term depth one. The earlier marked serial search found Hilbert incidence uniqueness. <a href="https://vprover.github.io/vampireGuide/docs/tutorial/intro/#example-who-killed-agatha-puz0011">Vampire guide example</a></p></section>
<section id="evidence"><h2>Replay the experiments</h2>
<ul><li><a href="{STEM}-results.json">Results summary</a></li><li><a href="{STEM}-evidence.zip">Full experiment archive</a></li>
<li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li></ul>
<p>Each phase replays from its pinned inputs in a fresh subdirectory. The archive also includes the marked and deferred pilots.</p>
<pre><code>python3.12 -I -S -B publication/replay_phase_v1.py admission /tmp/wang-admission /tmp/wang-pysat
python3.12 -I -S -B publication/replay_phase_v1.py wide /tmp/wang-admission /tmp/wang-pysat
python3.12 -I -S -B publication/replay_phase_v1.py ground /tmp/wang-admission
python3.12 -I -S -B publication/replay_phase_v1.py slice /tmp/wang-admission
python3.12 -I -S -B publication/replay_phase_v1.py marks /tmp/wang-admission
python3.12 -I -S -B publication/replay_phase_v1.py lazy /tmp/wang-admission</code></pre></section>
</main><script>
const menu=document.getElementById("case-menu");
function choose(){{for(const p of document.querySelectorAll(".proof[id^=case-]")) p.hidden=p.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""
    report=dict(status="CHECKED_WANG_ADMISSION_AND_ATOM_CUTS",readers=[n for n,_ in panels],
                training=dict(cases=totals,contexts=contexts,actions=action_counts),comparison=comparison,
                activity=activity,marked_pilot=failure_rows,deferred_pilot=lazy_rows,
                slices=slice_rows,widened=wide_rows,atom_cuts=ground_rows)
    with (ROOT/"report"/(STEM+".html")).open("x") as stream:
        stream.write(html)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as stream:
        stream.write(json.dumps(report,indent=2,sort_keys=True)+"\n")


if __name__ == "__main__":
    main()
