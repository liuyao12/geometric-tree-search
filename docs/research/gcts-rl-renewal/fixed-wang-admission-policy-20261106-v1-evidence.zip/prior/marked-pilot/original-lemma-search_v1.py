"""Saturate clauses with checked receptor offers and a learned move order."""

from collections import Counter, defaultdict
import heapq
from itertools import combinations
import math
import time

from ground_control_v1 import Derivation
from lemma_receptors_v1 import ordered
from serial_blocks_v1 import prop


class Search:
    def __init__(self, admitted, offers, mode, limits, weights=(), rng=None, marking=False):
        self.d = Derivation(admitted)
        self.mode = mode
        self.limits = limits
        self.stats = Counter()
        self.queue = []
        self.queued = set()
        self.index = defaultdict(list)
        self.by_anchor = defaultdict(list)
        self.macro = {}
        self.macro_steps = {}
        self.marking = marking
        self.cuts = []
        self.enqueued_order = {}
        self.weights = weights
        self.rng = rng
        self.gradients = []
        self.started = time.monotonic()
        for node in self.d.active:
            self.enqueue(node)
        if mode == "seeded":
            for offer in offers:
                self.place(offer)
        elif mode != "cold":
            source = [ordered(self.d.clauses[i]) for i in self.d.active]
            shuffled = list(source)
            if mode == "shuffled":
                rng.shuffle(shuffled)
            route = dict(zip(source, shuffled, strict=True))
            for offer in offers:
                anchor = min(offer.leaves, key=lambda row: (len(row), row))
                self.by_anchor[route[anchor]].append(offer)

    def enqueue(self, node):
        if node in self.queued:
            return
        self.queued.add(node)
        self.enqueued_order[node] = self.stats["enqueued"]
        heapq.heappush(self.queue, (len(self.d.clauses[node]), node))
        self.stats["enqueued"] += 1

    def place(self, offer):
        nodes = [self.d.known[frozenset(row)] for row in offer.leaves]
        self.stats["activated"] += 1
        start = len(self.d.clauses)
        for a, b, pivot, expected in offer.steps:
            node = self.d.add_resolution(nodes[a], nodes[b], pivot)
            assert self.d.clauses[node] == frozenset(expected)
            nodes.append(node)
            self.stats["macro_replays"] += 1
        root = nodes[-1]
        for node in range(start, len(self.d.clauses)):
            self.macro_steps[node] = offer
        if root >= start:
            self.macro[root] = offer
        self.enqueue(root)

    def features(self, key):
        width, node = key
        inputs = len(self.d.premises)
        clause = self.d.clauses[node]
        contacts = sum(bool(self.index.get(-v)) for v in clause)
        return (1 / (width + 1), float(node in self.macro), float(node < inputs),
                contacts / max(1, width), 1 / (1 + node / max(1, inputs)))

    def choose(self):
        if self.mode not in {"trained", "learning"}:
            return heapq.heappop(self.queue)[1]
        batch = [heapq.heappop(self.queue) for _ in range(min(self.limits["frontier"], len(self.queue)))]
        features = [self.features(k) for k in batch]
        scores = [sum(a * b for a, b in zip(self.weights, row, strict=True)) for row in features]
        peak = max(scores)
        if self.mode == "trained":
            i = scores.index(peak)
        else:
            probabilities = [math.exp(s - peak) for s in scores]
            i = self.rng.choices(range(len(batch)), weights=probabilities)[0]
            normalizer = sum(probabilities)
            self.gradients.append([features[i][j] - sum(p * f[j] for p, f in zip(probabilities, features, strict=True))
                                   / normalizer for j in range(len(self.weights))])
        selected = batch.pop(i)
        for move in batch:
            heapq.heappush(self.queue, move)
        self.stats["ranked"] += len(features)
        return selected[1]

    def run(self):
        while self.queue:
            if time.monotonic() - self.started >= self.limits["seconds"]:
                return "BOUNDED", None
            node = self.choose()
            row = self.d.clauses[node]
            self.stats["settled"] += 1
            if not row:
                return "REFUTED", node
            for offer in self.by_anchor.pop(ordered(row), ()):
                self.place(offer)
            blocked = set()
            for lit in ordered(row):
                for other in self.index[-lit]:
                    if self.stats["pairs"] >= self.limits["pairs"]:
                        return "BOUNDED", None
                    self.stats["pairs"] += 1
                    right = self.d.clauses[other]
                    if self.marking:
                        if other in blocked:
                            self.stats["blocked_pivots"] += 1
                            continue
                        contacts = tuple(v for v in row if -v in right)
                        if len(contacts) > 1:
                            self.cuts.append(("pair", node, other, *ordered(contacts)[:2]))
                            blocked.add(other)
                            self.stats["blocked_pivots"] += 1
                            continue
                    result = (row - {lit}) | (right - {-lit})
                    if any(-v in result for v in result):
                        continue
                    if self.marking and result and result not in self.d.known:
                        witness = self.subsuming(result)
                        if witness is not None:
                            self.cuts.append(("subsumption", node, other, lit, witness, self.stats["enqueued"]))
                            self.stats["subsumed_resolvents"] += 1
                            continue
                    if lit > 0:
                        child = self.d.add_resolution(node, other, lit)
                    else:
                        child = self.d.add_resolution(other, node, -lit)
                    self.enqueue(child)
            for lit in ordered(row):
                self.index[lit].append(node)
        return "EXHAUSTED", None

    def subsuming(self, clause):
        literals = ordered(clause)
        for n in range(1, len(clause)):
            for part in combinations(literals, n):
                self.stats["subset_probes"] += 1
                witness = self.d.known.get(frozenset(part))
                if witness in self.queued:
                    return witness
        return None

    def used(self, root):
        support = set()
        pending = [root]
        while pending:
            node = pending.pop()
            if node in support:
                continue
            support.add(node)
            if node in self.d.steps:
                pending.extend(self.d.steps[node][:2])
        return sorted({self.macro_steps[node] for node in support if node in self.macro_steps},
                      key=lambda offer: (offer.pattern, offer.leaves, offer.mapping))


def synthetic(rng):
    n = rng.choice((3, 9, 11))
    labels = list(range(1, n + 5))
    rng.shuffle(labels)
    guard, vertices, spare = labels[0], labels[1:n + 1], labels[n + 1:]
    bank = {prop.mask([-guard]): None}
    edges = [*zip(vertices, vertices[1:] + vertices[:1], strict=True), *zip(spare, spare[1:])]
    for a, b in edges:
        for polarity in (1, -1):
            bank[prop.mask([guard, polarity * a, polarity * b])] = None
    return bank, tuple((False, ("U",)) for _ in labels)


def train(patterns, fit, config):
    import random
    rng = random.Random(config["seed"])
    weights = [2., .25, .2, .0, .25]
    average = .2
    episodes = []
    for i in range(config["episodes"]):
        bank, types = synthetic(rng)
        rows = {ordered(prop.literals(c)) for c in bank}
        offers, _ = fit(patterns, rows, types, config["match_trials"], config["match_offers"])
        search = Search(bank, offers, "learning", config["limits"], weights, rng)
        status, _ = search.run()
        cost = search.stats["pairs"] + search.stats["macro_replays"]
        reward = 1 / (1 + cost / 250) if status == "REFUTED" else -.3
        advantage = reward - average
        average = .9 * average + .1 * reward
        if search.gradients:
            for j, values in enumerate(zip(*search.gradients, strict=True)):
                update = config["rate"] * advantage * sum(values) / len(values)
                weights[j] = max(-5., min(5., weights[j] + update))
        episodes.append(dict(episode=i, status=status, reward=reward, offers=len(offers),
                             stats=dict(search.stats), weights=weights[:]))
    return weights, episodes
