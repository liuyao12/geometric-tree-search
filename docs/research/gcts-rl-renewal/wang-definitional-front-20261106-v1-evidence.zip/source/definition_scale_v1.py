"""Check linear growth against the distributive wide-choice family."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_cases_v1 import wide
from definition_check_v1 import check
from definitions_v1 import compile_case
from front_v1 import clausify
from lifted_experiment_v1 import save


def main():
    rows=[]
    for k in range(2,21):
        case=wide(k)
        normal,certificate=compile_case(case)
        actual=check(case,normal,certificate)
        clauses=2**k+k
        assert actual["rows"]==9*k
        try:
            previous,_=clausify(case,1024)
        except ValueError as error:
            assert str(error)=="Clausification distribution limit" and k>=11
            observed=None
        else:
            observed=len(previous["clauses"])
            assert observed==clauses and k<=10
        rows.append(dict(choices=k,compiled=actual["rows"],legacy_observed=observed,
                         legacy_unbounded_count=clauses))
    save("data/scale-v1.json",dict(status="CHECKED_CLAUSE_SCALING",rows=rows,distribution_limit=1024))
    print("Wide-choice counts checked at 19 sizes.",flush=True)


if __name__=="__main__":
    main()
