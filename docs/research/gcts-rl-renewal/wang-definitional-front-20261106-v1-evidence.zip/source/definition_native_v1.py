"""Check on-activation Wang admissions after source definitions have been audited."""
from pathlib import Path
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from definition_check_v1 import check
from definition_experiment_v1 import LIMITS
import herbrand_v1 as fol
from lifted_experiment_v1 import ROOT, load, save
from lifted_native_v1 import NativeBank, Receiver
from lifted_prover_v1 import Prover
from native_audit_v1 import check_arm, qualify_fragment
from study_v1 import write_gzip


def main():
    selected={"quantifier-duality","typed-shadowed-witness"}
    results={}
    traces={}
    for row in load("data/search-v1.json")["results"]:
        name=row["id"]
        if name not in selected:
            continue
        normal=row["compiled"]
        check(row["original"],normal,row["certificate"])
        f,p,source=fol.signature(normal)
        signature=f,p,{r["id"]:r for r in source}
        record={}
        for mode in ("off","shape"):
            bank=NativeBank()
            receiver=Receiver(bank,mode)
            prover=Prover(row["original"],normal=normal,admission=receiver,**LIMITS)
            status,index=prover.run()
            assert status=="PROVED"
            lifted=json.loads(json.dumps(prover.proof(index)))
            assert lifted==row["definition"]["proof"]["lifted"]
            run=dict(status=status,tape=dict(receiver.counts),events=json.loads(json.dumps(receiver.events)))
            decoded={k:qualify_fragment(bank.verifier,k,t) for k,t in bank.traces.items()}
            seen=set()
            audited=check_arm(run,signature,bank.traces,decoded,seen,mode,set())
            assert audited==lifted and seen==set(bank.traces)
            for k,t in bank.traces.items():
                assert traces.setdefault(k,t)==t
            record[mode]=run
        assert record["off"]["tape"]["admissions"]==record["shape"]["tape"]["admissions"]
        results[name]=record
        print(name,{m:r["tape"] for m,r in record.items()},flush=True)
    assert set(results)==selected
    write_gzip(ROOT/"data/native-fragments-v1.json.gz",traces)
    save("data/native-v1.json",dict(status="CHECKED_ON_ACTIVATION_WITH_DEFINITIONS",results=results,
                                   distinct_fragments=len(traces)))


if __name__=="__main__":
    main()
