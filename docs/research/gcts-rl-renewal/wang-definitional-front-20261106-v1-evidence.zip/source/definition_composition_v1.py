"""Compose small Wang fragments by checking the clauses at their interfaces."""
from collections import Counter
from copy import deepcopy
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
from definition_check_v1 import check
import herbrand_v1 as fol
from lifted_audit_v1 import proof_audit
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import restore
from lifted_native_v1 import NativeBank
from native_audit_v1 import qualify_fragment
from native_marked_v1 import records
from study_v1 import Certificate, guarded, write_gzip


def signature(row):
    f,p,s=fol.signature(row["compiled"])
    sources,guards=guarded(s,f,row["compiled"]["sorts"])
    return f,p,sources,guards


def fragment(row,lines,index):
    functions,predicates,sources,guards=signature(row)
    line=lines[index]
    if line["rule"]=="G":
        source=line["source"]
        schemas={source:sources[source]}
    else:
        assert line["rule"]=="R"
        a,b=(line[k] for k in ("left","right"))
        assert 0<=a<index and 0<=b<index
        schemas={n:dict(id=n,variables={},clause=fol.frozen(lines[j]["clause"]))
                 for n,j in zip(("left","right"),(a,b),strict=True)}
    builder=Certificate(schemas,functions,predicates,row["compiled"]["sorts"],guards)
    if line["rule"]=="G":
        bindings={v:fol.frozen(t) for v,t in line["bindings"].items()}
        builder.instance(line["source"],bindings)
    else:
        a=builder.instance("left",{})
        b=builder.instance("right",{})
        builder.resolve(a,b,fol.frozen(line["pivot"]))
    assert tuple(builder.lines[-1]["clause"])==fol.frozen(line["clause"])
    return builder


def decoded_clause(values,symbols,variables):
    def expression(value):
        if isinstance(value,str):
            return variables[value]
        head,*args=value
        return (symbols[head],*(expression(t) for t in args))
    return tuple((sign,expression(a)) for sign,a in values)


def link(row,calls,traces,decoded):
    proof=row["definition"]["proof"]
    lines=proof["lines"]
    normal=row["compiled"]
    proof_audit(row["original"],proof,normal=normal)
    f,p,sources,guards=signature(row)
    globals_=Certificate(sources,f,p,normal["sorts"],guards)
    names={v:k for k,v in globals_.symbols.items()}
    earlier=[]
    used=set()
    counts=Counter()
    for i,(record,call) in enumerate(zip(lines,calls,strict=True)):
        key=call["fragment"]
        evidence=traces[key]
        parsed=decoded[key]
        assert parsed is not None and len(parsed)==(1 if record["rule"]=="G" else 3)
        templates=decoder.records(evidence["prefix"][1:-1])
        if record["rule"]=="G":
            expected=[sources[record["source"]]]
        else:
            a,b=(record[k] for k in ("left","right"))
            assert all(type(j) is int and 0<=j<i for j in (a,b))
            expected=[dict(variables={},clause=earlier[j]) for j in (a,b)]
        for j,(part,source) in enumerate(zip(templates,expected,strict=True)):
            source_id,text=part.split(":",1)
            assert source_id==f"C{j:b}"
            vars_={f"{n:b}":v for n,v in enumerate(sorted(source["variables"]))}
            assert decoded_clause(decoder.clause(text,template=True),names,vars_)==tuple(source["clause"])
        last=parsed[-1]
        assert last["rule"]==record["rule"]
        if last["rule"]=="G":
            args=sorted(expected[0]["variables"])
            subst={args[int(k,2)]:decoded_clause(((True,value),),names,{})[0][1]
                   for k,value in last["substitution"].items()}
            assert subst=={v:fol.frozen(t) for v,t in record["bindings"].items()}
        else:
            assert (last["left"],last["right"])==(0,1)
            assert decoded_clause(((True,last["pivot"]),),names,{})[0][1]==fol.frozen(record["pivot"])
        clause=decoded_clause(last["clause"],names,{})
        assert clause==fol.frozen(record["clause"])
        earlier.append(clause)
        used.add(key)
        counts["fragment_calls"]+=1
        counts["implied_steps"]+=evidence["steps"]
        counts["fresh_tile_runs"]+=not call["reuse"]
    assert earlier and not earlier[-1]
    restore(row["original"],lines,normal=normal,project=True)
    return dict(counts),used


def compose():
    bank=NativeBank()
    output=[]
    for row in load("data/search-v1.json")["results"]:
        proof=row["definition"]["proof"]
        if proof is None:
            continue
        check(row["original"],row["compiled"],row["certificate"])
        calls=[]
        for i in range(len(proof["lines"])):
            b=fragment(row,proof["lines"],i)
            label,evidence,reuse=bank.get(b.prefix(),records(b.words()[:-1]),True)
            assert evidence["stop"]==bank.verifier.finish
            calls.append(dict(fragment=label,reuse=reuse))
        output.append(dict(id=row["id"],calls=calls))
        print(row["id"],len(calls),flush=True)
    save("data/composed-v1.json",dict(status="COMPOSED_WANG_CLAUSE_INTERFACES",
                                      proofs=output,distinct_fragments=len(bank.traces)))
    write_gzip(ROOT/"data/composed-fragments-v1.json.gz",bank.traces)


def audit():
    rows={r["id"]:r for r in load("data/search-v1.json")["results"]}
    composed=load("data/composed-v1.json")
    with gzip.open(ROOT/"data/composed-fragments-v1.json.gz","rt") as fh:
        traces=json.load(fh)
    assert len(traces)==composed["distinct_fragments"]
    bank=NativeBank()
    decoded={key:qualify_fragment(bank.verifier,key,value) for key,value in traces.items()}
    union=set()
    receipts={}
    seen=set()
    for proof in composed["proofs"]:
        row=rows[proof["id"]]
        check(row["original"],row["compiled"],row["certificate"])
        for call in proof["calls"]:
            assert call["reuse"]==(call["fragment"] in seen)
            seen.add(call["fragment"])
        receipt,used=link(row,proof["calls"],traces,decoded)
        receipts[row["id"]]=receipt
        union.update(used)
        print(row["id"],receipt,flush=True)
    assert union==set(traces)
    assert set(receipts)=={key for key,r in rows.items() if r["definition"]["proof"]}
    case=deepcopy(rows["wide-choices-11"])
    calls=next(p["calls"] for p in composed["proofs"] if p["id"]==case["id"])
    lines=case["definition"]["proof"]["lines"]
    for i,line in enumerate(lines):
        if line["rule"]=="R" and i>=2:
            old=line["left"]
            alternative=next(j for j in range(i) if lines[j]["clause"]!=lines[old]["clause"])
            line["left"]=alternative
            break
    try:
        link(case,calls,traces,decoded)
    except (AssertionError,KeyError,ValueError):
        rejected=True
    else:
        raise AssertionError("Wrong link accepted")
    save("data/composed-audit-v1.json",dict(status="CHECKED_COMPOSED_WANG_REFUTATIONS",
               proof_receipts=receipts,distinct_fragments=len(traces),wrong_parent_rejected=rejected))


if __name__=="__main__":
    if sys.argv[1:] == ["audit"]:
        audit()
    else:
        assert not sys.argv[1:]
        compose()
