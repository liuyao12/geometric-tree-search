"""Summarize the nine completed single-rectangle controls."""
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
from boundary_kernel_v1 import build
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import CAP, EXPECTED, restore
from sparse_frame_v1 import verify

IDS=("proof-by-cases","quantifier-duality","shadowed-existential","peano-nonzero-successor",
     "hilbert-incidence-uniqueness","typed-shadowed-witness","wide-choices-5",
     "wide-choices-11","nested-iff-12")


def main():
    mode=sys.argv[1:]
    assert not mode or len(mode)==2 and mode[0]=="verify" and mode[1] in (*IDS,"all")
    machine=build().compile()
    assert machine.digest()==EXPECTED
    rows={r["id"]:r for r in load("data/search-v1.json")["results"]}
    receipts={f["id"]:f for f in load("data/frames-v1.json")["frames"]}
    assert receipts.keys()==set(IDS)
    summaries=[]
    for name in IDS:
        row=rows[name]
        path=f"data/{name}-frame-v1.json.gz"
        with gzip.open(ROOT/path,"rt") as fh:
            frame=json.load(fh)
        assert frame["machine_sha256"]==EXPECTED
        b=restore(row["original"],row["definition"]["proof"]["lines"],normal=row["compiled"],project=True)
        assert (b.prefix(),b.words())==(frame["prefix"],frame["word"])
        assert len(decoder.read(frame["prefix"],frame["word"]))==len(b.lines)
        steps=sum(e[0] if len(e)==2 else 1 for e in frame["trace"])
        archived=receipts[name]
        assert steps==archived["receipt"]["steps"]
        assert len(frame["trace"])==archived["receipt"]["trace_events"]
        assert len(b.lines)==len(archived["commits"])
        if mode and mode[1] in ("all",name):
            receipt=verify(machine,frame["prefix"],frame["word"],frame["padding"],frame["trace"],CAP)
            assert receipt==archived["receipt"]
            print("verified",name,steps,flush=True)
        summaries.append(dict(id=name,artifact=path,proof_lines=len(b.lines),steps=steps,
                              trace_events=len(frame["trace"])))
    if not mode:
        save("data/full-v1.json",dict(status="MEASURED_SINGLE_RECTANGLE_CONTROLS",machine=EXPECTED,frames=summaries))


if __name__=="__main__":
    main()
