"""Qualify source/definition satisfiability on all two-element relation tables."""
from itertools import product


def truth(formula,relations,domain,env):
    op,*parts=formula
    if op=="atom":
        pred,*args=parts
        return (pred,tuple(env[x] for x in args)) in relations
    if op in ("all","exists"):
        var,_,body=parts
        agg=all if op=="all" else any
        return agg(truth(body,relations,domain,{**env,var:x}) for x in domain)
    if op=="not":
        return not truth(parts[0],relations,domain,env)
    a,b=(truth(arg,relations,domain,env) for arg in parts)
    return {"and":a and b,"or":a or b,"iff":a==b,"implies":not a or b}[op]


def sat(rows):
    if not rows:
        return True
    smallest=min(rows,key=len)
    if not smallest:
        return False

    def assign(literal):
        return [r-{(-literal)} for r in rows if literal not in r]

    literal=min(smallest)
    return sat(assign(literal)) or (len(smallest)>1 and sat(assign(-literal)))


def qualify(original,compiled):
    domain=(0,1)
    assert not original["functions"] and not original["equality"]
    inputs=[(p,a) for p,types in original["predicates"].items()
            for a in product(domain,repeat=len(types))]
    outputs=[(f,a) for f,(types,_) in compiled["functions"].items()
             for a in product(domain,repeat=len(types))]
    assignments=0
    accepted=0
    first_countermodel=None

    def extension(relations,values):
        fun=dict(zip(outputs,values,strict=True))
        grounded=[]
        atom_ids={}
        for source in compiled["clauses"]:
            names=tuple(sorted(source["variables"]))
            for inputs_ in product(domain,repeat=len(names)):
                env=dict(zip(names,inputs_,strict=True))
                def term(value):
                    if isinstance(value,str):
                        return env[value]
                    name,*args=value
                    return fun[name,tuple(term(t) for t in args)]

                row=set()
                for sign,(pred,*args) in source["clause"]:
                    atom=(pred,tuple(term(t) for t in args))
                    if pred in original["predicates"]:
                        if (atom in relations)==sign:
                            break
                    else:
                        number=atom_ids.setdefault(atom,len(atom_ids)+1)
                        row.add(number if sign else -number)
                else:
                    if not any(-i in row for i in row):
                        grounded.append(row)
        return sat(grounded)

    for values in product((False,True),repeat=len(inputs)):
        relations={a for a,b in zip(inputs,values,strict=True) if b}
        wanted=all(truth(p,relations,domain,{}) for p in original["premises"])
        wanted=wanted and not truth(original["goal"],relations,domain,{})
        observed=False
        for values_ in product(domain,repeat=len(outputs)):
            assignments+=1
            if extension(relations,values_):
                observed=True
                break
        assert wanted==observed
        accepted+=observed
        if observed and first_countermodel is None:
            first_countermodel=sorted(relations)
    return dict(structures=2**len(inputs),witness_tables_tested=assignments,
                countermodels=accepted,example=first_countermodel)
