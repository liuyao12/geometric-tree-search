"""Write complete fixed-palette certificates for source-checked refutations."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from boundary_kernel_v1 import build
from definition_check_v1 import check
from definition_full_v1 import IDS
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import CAP, EXPECTED, restore
from sparse_frame_v1 import execute, verify
from study_v1 import write_gzip


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    selected=set(sys.argv[1:] or IDS)
    frames=[]
    for row in load("data/search-v1.json")["results"]:
        if row["id"] not in selected:
            continue
        proof=row["definition"]["proof"]
        if proof is None:
            continue
        normal=row["compiled"]
        check(row["original"],normal,row["certificate"])
        builder=restore(row["original"],proof["lines"],normal=normal,project=True)
        prefix,word=builder.prefix(),builder.words()
        run=execute(machine,prefix,word,1,CAP)
        assert run["status"]=="ACCEPT",(row["id"],run.get("last"),run["steps"])
        assert len(run["commits"])==len(builder.lines)
        receipt=verify(machine,prefix,word,1,run["trace"],CAP)
        artifact=f"data/{row['id']}-frame-v1.json.gz"
        write_gzip(ROOT/artifact,dict(prefix=prefix,word=word,padding=1,trace=run["trace"],machine_sha256=EXPECTED))
        frames.append(dict(id=row["id"],artifact=artifact,receipt=receipt,commits=run["commits"],
                           boundary_schemas=list(builder.sources),symbol_codes=builder.symbols,
                           width=len(prefix)+len(word)))
        print(row["id"],"lines",len(builder.lines),"steps",receipt["steps"],flush=True)
    assert selected=={f["id"] for f in frames}
    save("data/frames-v1.json",dict(status="CHECKED_DEFINITIONAL_WANG_FRAMES",frames=frames,machine_sha256=EXPECTED))


if __name__=="__main__":
    main()
