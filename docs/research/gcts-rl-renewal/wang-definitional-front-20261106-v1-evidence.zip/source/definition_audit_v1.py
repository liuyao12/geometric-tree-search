"""Bind the original formulas to accepting rectangles and reject forged boundaries."""
from copy import deepcopy
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import decode_v1 as decoder
from boundary_kernel_v1 import build
from definition_cases_v1 import cases
from definition_check_v1 import check
from finite_definition_v1 import qualify
import herbrand_v1 as fol
from lifted_audit_v1 import proof_audit
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import CAP, EXPECTED
from sparse_frame_v1 import execute, verify
from study_v1 import Certificate, guarded, write_gzip


def assert_rejected(case,normal,cert):
    try:
        check(case,normal,cert)
    except (AssertionError,KeyError,TypeError,ValueError):
        return True
    raise AssertionError("Invalid source boundary accepted")


def mutate(row,machine):
    original,normal,cert=(row[k] for k in ("original","compiled","certificate"))
    changed=deepcopy(normal)
    changed["clauses"].pop()
    omitted_root=assert_rejected(original,changed,cert)
    changed=deepcopy(normal)
    changed["clauses"][-1]["clause"][0][0]=not changed["clauses"][-1]["clause"][0][0]
    flipped_goal=assert_rejected(original,changed,cert)
    changed=deepcopy(cert)
    quantifiers=[d for d in changed["definitions"] if d["witness"]]
    quantifiers[0]["templates"].pop()
    lost_direction=assert_rejected(original,normal,changed)
    changed=deepcopy(cert)
    quantifiers=[d for d in changed["definitions"] if d["witness"]]
    quantifiers[-1]["witness"]=quantifiers[0]["witness"]
    captured_witness=assert_rejected(original,normal,changed)
    changed=deepcopy(normal)
    dependent=next(d["witness"] for d in cert["definitions"] if d["witness"] and normal["functions"][d["witness"]][0])
    changed["functions"][dependent][0].pop()
    dropped_parameter=assert_rejected(original,changed,cert)

    forged=deepcopy(normal)
    forged["predicates"]["forged_claim"]=[]
    for sign in (True,False):
        forged["clauses"].append(dict(id=f"forged-{sign}",variables={},clause=[(sign,("forged_claim",))]))
    functions,predicates,schemas=fol.signature(forged)
    sources,guards=guarded(schemas,functions,forged["sorts"])
    relevant={k:sources[k] for k in ("forged-True","forged-False")}
    builder=Certificate(relevant,functions,predicates,forged["sorts"],guards)
    a=builder.instance("forged-True",{})
    b=builder.instance("forged-False",{})
    builder.resolve(a,b,("forged_claim",))
    prefix,word=builder.prefix(),builder.words()
    run=execute(machine,prefix,word,1,CAP)
    assert run["status"]=="ACCEPT"
    receipt=verify(machine,prefix,word,1,run["trace"],CAP)
    assert len(decoder.read(prefix,word))==3
    assert_rejected(original,forged,cert)
    artifact="data/forged-boundary-frame-v1.json.gz"
    write_gzip(ROOT/artifact,dict(prefix=prefix,word=word,trace=run["trace"],padding=1,
                                machine_sha256=EXPECTED))
    return dict(omitted_root=omitted_root,flipped_goal=flipped_goal,lost_direction=lost_direction,
                captured_witness=captured_witness,dropped_parameter=dropped_parameter,
                forged_boundary=dict(tile_verifier="ACCEPT",statement_checker="REJECT",
                                     artifact=artifact,receipt=receipt,commit=run["commits"][-1]))


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    rows={r["id"]:r for r in load("data/search-v1.json")["results"]}
    assert {k:r["original"] for k,r in rows.items()}=={r["id"]:r for r in cases()}
    result={}
    finite={}
    for name,r in rows.items():
        assert check(r["original"],r["compiled"],r["certificate"])==r["qualified"]
        if name in ("quantifier-duality","proof-by-cases","mixed-quantifier-swap"):
            finite[name]=qualify(r["original"],r["compiled"])
    for name,row in rows.items():
        proof=row["definition"]["proof"]
        if proof is not None:
            result[name]=dict(lifted_inferences=dict(proof_audit(row["original"],proof,normal=row["compiled"])),
                              ground_lines=len(proof["lines"]))
    assert finite["mixed-quantifier-swap"]["countermodels"]>0
    assert all(x["countermodels"]==0 for k,x in finite.items() if k!="mixed-quantifier-swap")
    control=mutate(rows["mixed-quantifier-swap"],machine)
    save("data/audit-v1.json",dict(status="CHECKED_SOURCE_FORMULAS_AND_WANG_REFUTATIONS",
               symbolic=result,finite=finite,controls=control))
    print("finite",finite,"controls",control,flush=True)


if __name__=="__main__":
    main()
