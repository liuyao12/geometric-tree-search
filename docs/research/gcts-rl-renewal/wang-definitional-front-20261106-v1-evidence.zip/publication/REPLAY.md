# Replay the source-checked Wang proofs

Use Python 3.12 and its standard library. In an extracted copy, move
the supplied data directory aside, create a new one, and copy the
nine complete-rectangle controls named in data/full-v1.json back
into the new directory, together with data/frames-v1.json. Preserve their file names.

Run from the archive root.

    python3 -I -S -B source/definition_experiment_v1.py
    python3 -I -S -B source/definition_scale_v1.py
    python3 -I -S -B source/definition_audit_v1.py
    python3 -I -S -B source/definition_native_v1.py
    python3 -I -S -B source/definition_composition_v1.py
    python3 -I -S -B source/definition_composition_v1.py audit
    python3 -I -S -B source/definition_full_v1.py
    python3 -I -S -B publication/render_v1.py

The clean replay reruns the search, the clause audit, all linked
fragments and their independent interface audit, and the forged
rectangle. The nine full controls supply the matched transition
counts. Check any supplied full rectangle directly with

    python3 -I -S -B source/definition_full_v1.py verify peano-nonzero-successor

Use verify all to verify all nine. Recreate the full controls with
the following command. A single case ID selects a smaller run.
The Hilbert control requires substantial CPU and memory.

    python3 -I -S -B source/definition_frames_v1.py

Compare the outputs with publication/replay-v1.json. For the browser
check run node publication/check_v1.cjs with Playwright and Chromium.
Set GCTS_CHROME and GCTS_PLAYWRIGHT for custom installations.
