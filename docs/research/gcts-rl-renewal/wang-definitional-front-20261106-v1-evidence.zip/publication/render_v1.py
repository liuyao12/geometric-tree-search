"""Render the checked source clauses, proof lines, and actual Wang squares."""
from html import escape
from math import log10
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"publication"))
from proof_views_v1 import clause, explanation, formula, load_frame, math, symbol, window_svg
import decode_v1 as decoder
from boundary_kernel_v1 import build
from lifted_experiment_v1 import load
from lifted_frames_v1 import EXPECTED, restore

STEM="wang-definitional-front-20261106-v1"
NAMES={
    "proof-by-cases":"Proof by cases",
    "quantifier-duality":"Quantifier duality",
    "shadowed-existential":"Shadowed existential",
    "peano-nonzero-successor":"Peano successor is nonzero",
    "hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
    "typed-shadowed-witness":"Typed witness with shadowing",
    "wide-choices-5":"Five independent choices",
    "wide-choices-11":"Eleven independent choices",
    "nested-iff-12":"Twelve nested biconditional operands",
    "mixed-quantifier-swap":"Mixed-sort quantifier swap",
}
OUTCOMES={"PROVED":"Proved","DISTRIBUTION_LIMIT":"Distribution limit","BOUNDED":"Search limit",
          "SATURATED_WITHOUT_REFUTATION":"Saturated"}


def scale(rows):
    points=lambda values: " ".join(f"{x(k):.1f},{y(v):.1f}" for k,v in values)
    x=lambda k: 105+(k-2)*28
    y=lambda v: 262-(log10(v)-1)*34
    parts=['<svg class="bars" viewBox="0 0 680 320" role="img" '
           'aria-label="Logarithmic clause counts for the wide-choice family">']
    parts.append('<text x="105" y="52">Clauses on a logarithmic scale</text>')
    for v in (10,100,1000,10_000,100_000,1_000_000):
        h=y(v)
        parts.append(f'<path d="M105,{h}H609" stroke="#d6e1e7"/>'
                     f'<text x="97" y="{h+5}" text-anchor="end">{v:,}</text>')
    for k in (2,5,8,11,14,17,20):
        parts.append(f'<text x="{x(k)}" y="285" text-anchor="middle">{k}</text>')
    cap=y(1024)
    parts.append(f'<path d="M105,{cap}H609" stroke="#8c5c35" stroke-dasharray="3 4"/>')
    observed=[(r["choices"],r["legacy_observed"]) for r in rows if r["legacy_observed"]]
    extensions=[(r["choices"],r["legacy_unbounded_count"]) for r in rows if r["choices"]>=10]
    defined=[(r["choices"],r["compiled"]) for r in rows]
    for values,color,dash in ((observed,"#ae5737",""),(extensions,"#ae5737",' stroke-dasharray="6 4"'),
                               (defined,"#087189","")):
        parts.append(f'<polyline points="{points(values)}" fill="none" stroke="{color}" stroke-width="3"{dash}/>')
    parts.append('<text x="340" y="310" text-anchor="middle">Independent choices</text></svg>')
    caption=("Blue shows checked definitional counts. Orange shows distribution, with the dashed part calculated "
             "from the expansion formula beyond the implementation limit. The horizontal dotted line is the 1,024-clause cap.")
    return f'<figure style="max-width:44rem">{"".join(parts)}<figcaption>{caption}</figcaption></figure>'


def chart_table(rows,frame_by_id):
    body=[]
    for r in rows:
        title=escape(NAMES[r["id"]])
        frame=frame_by_id.get(r["id"])
        label=f'<a href="#{r["id"]}">{title}</a>' if frame else title
        old=r["control"]
        proof=r["definition"]
        values=(OUTCOMES[old["status"]],old["clauses"],old.get("counts",{}).get("offers",0) if old["clauses"] else None,
                r["qualified"]["rows"],proof["counts"].get("offers",0),len(frame["calls"]) if frame else None)
        def cell(v):
            return "—" if v is None else f"{v:,}" if type(v) is int else escape(v)
        body.append(f'<tr><th scope="row">{label}</th>'+ "".join(f'<td class="counts">{cell(v)}</td>' for v in values)+"</tr>")
    return "".join(body)


def subformula(original,path):
    forms=(*original["premises"],original["goal"])
    node=forms[path[0]]
    for i in path[1:]:
        if node[0] in ("all","exists"):
            assert i==0
            node=node[3]
        else:
            node=node[i+1]
    return node


def dictionary(row):
    parts=[]
    for d in row["certificate"]["definitions"]:
        path=d["path"]
        position=f"Formula {path[0]+1}"
        if len(path)>1:
            position+=" · "+".".join(str(v+1) for v in path[1:])
        text=math(formula(subformula(row["original"],path)))
        name=math(symbol(d["name"]))
        witness=math(symbol(d["witness"])) if d["witness"] else "—"
        if d["witness"]:
            args,sort=row["compiled"]["functions"][d["witness"]]
            inputs=r",\, ".join(map(symbol,args)) if args else r"\varnothing"
            witness+=" "+math(inputs+r"\to "+symbol(sort))
        parts.append(f"<tr><th scope=\"row\">{name}</th><td>{position}</td><td>{text}</td><td>{witness}</td></tr>")
    if not parts:
        return ""
    return ("<details><summary>Definition dictionary and witness signatures</summary>"
            "<div class=\"table\"><table><thead><tr><th>New name</th><th>Source address</th><th>Original subformula</th>"
            "<th>Witness and argument sorts</th></tr></thead><tbody>"+"".join(parts)+"</tbody></table></div></details>")


def model_view(model):
    pairs={tuple(x[1]) for x in model["example"]}
    body=[]
    for i in range(2):
        cells="".join(f'<td>{"Incident" if (i,j) in pairs else "—"}</td>' for j in range(2))
        body.append(f'<tr><th scope="row">{math(f"p_{i}")}</th>{cells}</tr>')
    return ('<div class="table"><table><thead><tr><th>Point</th>'+
            "".join(f"<th>{math(r'\ell_'+str(i))}</th>" for i in range(2))+
            "</tr></thead><tbody>"+"".join(body)+"</tbody></table></div>")


def read_fragments(machine, row, linked, traces, name):
    proof=row["definition"]["proof"]
    statement=row["original"]
    builder=restore(statement,proof["lines"],normal=row["compiled"],project=True)
    rows=[]
    for i,(line,call) in enumerate(zip(proof["lines"],linked["calls"],strict=True),1):
        trace=traces[call["fragment"]]
        raw=decoder.read(trace["prefix"],trace["word"]+"!",require_empty=False)[-1]
        rows.append(f'<tr><th scope="row">{i}</th><td>{explanation(line)}</td>'
                    f'<td>{math(clause(line["clause"]))}</td><td><details>'
                    f'<summary>Fragment row {trace["steps"]+1:,}</summary>'
                    f'<code>{escape(raw["raw"])}</code></details></td></tr>')
    trace=traces[linked["calls"][-1]["fragment"]]
    evidence=dict(prefix=trace["prefix"],word=trace["word"],padding=0,trace=trace["fragment"])
    svg,label=window_svg(machine,evidence,(trace["steps"]-5,trace["head"]))
    premises="".join(f'<li>{math(formula(p))}</li>' for p in statement["premises"])
    assumptions=f'<details><summary>Original hypotheses</summary><ul>{premises}</ul></details>' if premises else ""
    fixed="".join(f'<li><code>{escape(s["id"])}</code> {math(clause(s["clause"]))}</li>'
                  for s in builder.sources.values())
    expanded=" open" if name=="wide-choices-11" else ""
    return f"""<section id="{name}" class="proof">
<h2>{escape(NAMES[name])}</h2>
<p class="goal">Goal {math(formula(statement["goal"]))}</p>
{assumptions}{dictionary(row)}
<details><summary>Checked source and sort clauses used</summary><ul>{fixed}</ul></details>
<div class="table"><table><thead><tr><th>Line</th><th>Reading</th><th>Clause</th><th>Wang record</th></tr></thead>
<tbody>{"".join(rows)}</tbody></table></div>
<details{expanded}><summary>View the Wang squares in the final fragment</summary>
<figure>{svg}<figcaption>{label} The outlined square carries the machine head. Hover over a square for its four exact edge colors.</figcaption></figure></details>
</section>"""


def interface_table(full,composed):
    rows=[]
    for key,p in composed.items():
        title=escape(NAMES[key])
        match=f'{full[key]["steps"]:,}' if key in full else "—"
        rows.append(f'<tr><th scope="row">{title}</th><td>{p["fragment_calls"]:,}</td><td>{match}</td>'
                    f'<td>{p["implied_steps"]:,}</td><td>{p["fresh_tile_runs"]:,}</td></tr>')
    return "".join(rows)


def main():
    machine=build().compile()
    assert machine.digest()==EXPECTED
    rows=load("data/search-v1.json")["results"]
    full={f["id"]:f for f in load("data/full-v1.json")["frames"]}
    composed={f["id"]:f for f in load("data/composed-v1.json")["proofs"]}
    composed_audit=load("data/composed-audit-v1.json")["proof_receipts"]
    traces=load_frame("data/composed-fragments-v1.json.gz")
    checks=load("data/audit-v1.json")
    sections=[]
    links=[]
    for row in rows:
        ident=row["id"]
        if ident not in composed:
            continue
        sections.append(read_fragments(machine,row,composed[ident],traces,ident))
        links.append(f'<a href="#{ident}">{escape(NAMES[ident])}</a>')
    forged=checks["controls"]["forged_boundary"]
    evidence=load_frame(forged["artifact"])
    svg,label=window_svg(machine,evidence,forged["commit"])
    forged_view=f'<figure>{svg}<figcaption>{label} This is the accepting forged-boundary control.</figcaption></figure>'
    values=dict(STEM=STEM,SCALE=scale(load("data/scale-v1.json")["rows"]),
                INTERFACES=interface_table(full,composed_audit),
                RESULTS=chart_table(rows,composed),MODEL=model_view(checks["finite"]["mixed-quantifier-swap"]),
                FORGED=forged_view,FINITE=sum(x["structures"] for x in checks["finite"].values()),
                LINKS="".join(links),PROOFS="".join(sections))
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for key,markup in values.items():
        html=html.replace(f"%%{key}%%",str(markup))
    assert "%%" not in html
    (ROOT/f"report/{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
