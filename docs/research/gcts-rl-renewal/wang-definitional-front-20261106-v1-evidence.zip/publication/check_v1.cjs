const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-definitional-front-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, { waitUntil: "commit", timeout: 60000 });
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("#method mjx-container[display='true']").length === 2,
      null, { timeout: 60000 });
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator(".proof").count(), 9);
    assert.equal(await page.locator("#results tbody tr").count(), 10);
    assert.equal(await page.locator("#interfaces tbody tr").count(), 9);
    assert.equal(await page.locator("#wide-choices-11 > .table tbody tr").count(), 99);
    assert.equal(await page.locator("#nested-iff-12 > .table tbody tr").count(), 47);
    assert.equal(await page.locator("#wide-choices-11 svg .wang-cell").count(), 45);
    assert.equal(await page.locator("#controls svg .wang-cell").count(), 45);
    const word = page.locator("#wide-choices-11 > .table tbody tr").last().locator("details");
    await word.locator("summary").click();
    assert(await word.locator("code").isVisible());
    if (!process.argv[2]) {
      await page.locator("#results figure").screenshot({ path: path.join(__dirname, "scale-v1.png") });
      await page.locator("#wide-choices-11 > details[open] figure").screenshot({ path: path.join(__dirname, "wang-v1.png") });
      await page.locator("#controls figure").screenshot({ path: path.join(__dirname, "forged-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt={status:"CHECKED_DEFINITIONAL_WANG_READER",proofs:9,wideProofLines:99,iffProofLines:47,
      wideWangSquares:45,forgedWangSquares:45,mobileNoOverflow:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2]?"browser-live-v1.json":"browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
