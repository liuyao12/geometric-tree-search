"""Render exact recovered assemblies and a rejected strip placement."""
from fractions import Fraction
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from assemble_v1 import Geometry
from cluster_v1 import Model, load
from collar_audit_v1 import freeze
from layer_audit_v1 import cycles

STEM = "turtle-halfturn-layer-20261106-v1"

def euclidean(p):
    x,y=p
    return x+y/2,sqrt(3)*y/2


class Diagram:
    def __init__(self,points,width=600,height=400,disk=None):
        x,y=map(list,zip(*(euclidean(p) for p in points)))
        if disk:
            center,radius=disk
            a,b=euclidean(center)
            x.extend((a-radius,a+radius))
            y.extend((b-radius,b+radius))
        self.w,self.h=width,height
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2
        self.scale=min((width-34)/(max(x)-min(x)),(height-34)/(max(y)-min(y)))

    def at(self,p):
        x,y=euclidean(p)
        u,v=self.center
        return self.w/2+(x-u)*self.scale,self.h/2-(y-v)*self.scale

    def poly(self,shape,cls,fill):
        points=" ".join(f"{a:.3f},{b:.3f}" for a,b in map(self.at,shape))
        return f'<polygon class="{cls}" points="{points}" fill="{fill}"/>'

    def lines(self,edges,cls):
        parts=[]
        for edge in sorted(edges):
            (x,y),(u,v)=map(self.at,edge)
            parts.append(f"M{x:.3f},{y:.3f}L{u:.3f},{v:.3f}")
        return f'<path class="{cls}" d="{"".join(parts)}"/>'

    def circle(self,center,radius,cls,*,pixels=False):
        x,y=self.at(center)
        r=radius if pixels else radius*self.scale
        return f'<circle class="{cls}" cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}"/>'

    def svg(self,title,content):
        return f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{escape(title)}">{content}</svg>'


MOTIFS = ("#95cbbb", "#abdad0", "#88c2b5", "#abdad0", "#88c2b5")
CORNERS = "#a6c9e7"
CAP = "#d4bde8"
STRIP = "#f0c272"


def shape_path(diagram, edges, cls, fill=None):
    rings = []
    for ring in cycles(edges):
        points = [diagram.at(p) for p, _ in ring]
        pairs = "L".join(f"{x:.3f},{y:.3f}" for x, y in points)
        rings.append(f"M{pairs}Z")
    paint = f' fill="{fill}"' if fill else ""
    return f'<path class="{cls}" d="{"".join(rings)}"{paint}/>'


def patch_figure(geom, row, colors, title, caption, width=680, height=400):
    outer = geom.boundary(row["patch"])
    diagram = Diagram([p for p, _ in outer], width, height)
    content = [shape_path(diagram, geom.boundary(part), "patch-piece", color)
               for part, color in zip(row["pieces"], colors, strict=True)]
    content.append(shape_path(diagram, outer, "macro-outline"))
    return f'<figure>{diagram.svg(title, "".join(content))}<figcaption>{caption}</figcaption></figure>'


def collision(geom, mark):
    model = geom.model
    blocker = model.poly(mark["blocker"])
    wrong = model.poly(mark["tile"])
    neighbors = [model.poly(t) for t in mark["neighbors"]]
    diagram = Diagram([*blocker, *wrong, *(p for poly in neighbors for p in poly)], 680, 280)
    content = [diagram.poly(poly, "tile", "#f7e6c9") for poly in neighbors]
    content.append(diagram.poly(blocker, "tile blocker", "#a6c9e7"))
    content.append(diagram.poly(wrong, "ghost", "#f0c27265"))
    point = tuple(v / mark["scale"] for v in mark["sample"])
    content.append(diagram.circle(point, 4.5, "collision", pixels=True))
    svg = diagram.svg("A rejected letter overlaps the frame at the red point", "".join(content))
    return rf"<figure>{svg}<figcaption>Replacing the first letter (0) of the 29-letter strip with (1) places the dashed Turtle over a frame tile. The red point is a certified shared interior sample. The pale tiles show the beginning of the accepted strip.</figcaption></figure>"


def tex(body):
    return rf"\({body}\)"


def score(value):
    body = str(value.numerator) if value.denominator == 1 else rf"\frac{{{value.numerator}}}{{{value.denominator}}}"
    return tex(body)


def comparison(cases):
    rows = []
    for i, case in enumerate(cases):
        motif = case["recipe"]
        motif_tiles = len(motif["patch"])
        parent_tiles = len(case["winners"][0]["patch"])
        values = (motif_tiles, score(Fraction(motif["perimeter"]**2, motif_tiles)),
                  parent_tiles, case["best"], score(Fraction(*case["score"])))
        cells = "".join(f"<td>{v}</td>" for v in values)
        css = ' class="winner-row"' if i == 0 else ""
        rows.append(f'<tr{css}><th scope="row">{case["id"]}</th>{cells}</tr>')
    return "".join(rows)


def checks(layers):
    rows = []
    for name in ("P2", "T3", "P3", "T4", "P4"):
        samples = layers[name]
        row = samples[0]
        label = tex(f"{name[0]}_{name[1:]}")
        rows.append(f'<tr><th scope="row">{label}</th><td>{row["tiles"]:,}</td>'
                    f'<td>{row["perimeter"]:,}</td><td>{len(samples)}</td></tr>')
    return "".join(rows)


def main():
    model = Model(load("input/exact-point-model-v1.json"))
    geom = Geometry(model)
    capped = freeze(load("data/capped-orbits-v1.json"))
    p2 = capped["cases"][0]["recipe"]
    t3 = capped["cases"][0]["winners"][0]
    p3 = freeze(load("data/word-promotion-v1.json"))["assemblies"][0]
    t4 = freeze(load("data/triangle-transfer-v1.json"))["winners"][0]
    p4 = freeze(load("data/frame-transfer-v1.json"))["assemblies"][0]
    audit = freeze(load("data/audit-v1.json"))
    frame_colors = (*MOTIFS, CORNERS, CORNERS, CAP, CAP, STRIP, STRIP)
    tri_colors = (CAP, "#95cbbb", "#abdad0", "#88c2b5", CORNERS, CORNERS, CORNERS)
    p4_view = patch_figure(geom, p4, frame_colors, "The recovered 5,654-tile frame",
                           r"\(P_4\) uses five 834-tile motifs, two 594-tile corner triangles, two 72-tile cavity caps, and two 76-tile strips.",
                           width=940, height=505)
    gallery = "".join([
        patch_figure(geom, p2, (*MOTIFS, CORNERS, CORNERS, STRIP, STRIP),
                     "The selected 124-tile motif", r"\(P_2\) contains 124 Turtles. Its two 11-tile strips were recovered by geometric fit."),
        patch_figure(geom, t3, tri_colors, "The recovered 594-tile triangle",
                     r"\(T_3\) uses three copies of \(P_2\), three copies of \(T_2\), and one copy of \(T_1\)."),
        patch_figure(geom, p3, frame_colors, "The recovered 834-tile frame",
                     r"\(P_3\) contains 834 Turtles. The purple caps fill two cavities. The amber strips each use the predicted 29 letters."),
        patch_figure(geom, t4, tri_colors, "The recovered 4,356-tile triangle",
                     r"\(T_4\) uses three copies of \(P_3\), three copies of \(T_3\), and one copy of \(T_2\)."),
    ])
    template = (ROOT / "publication/notebook-v1.html").read_text()
    values = {"STEM": STEM, "P4": p4_view, "GALLERY": gallery, "TABLE": comparison(capped["cases"]),
              "COLLISION": collision(geom, audit["strip_control"]), "CHECKS": checks(audit["layers"])}
    for key, value in values.items():
        template = template.replace(f"%%{key}%%", value)
    assert "%%" not in template
    (ROOT / f"report/{STEM}.html").write_text(template)


if __name__ == "__main__":
    main()
