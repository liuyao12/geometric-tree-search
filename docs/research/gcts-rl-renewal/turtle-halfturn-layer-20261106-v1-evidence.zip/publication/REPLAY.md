# Replay the Turtle layer experiments

Use Python 3.12. The search and independent audit use only the standard library.
Run from the archive root. Move the held-back reference coordinates aside while
running the first six steps.

```sh
mv input/held-back-v1.json held-back-v1.json
python3 -I -S -B source/scaffold_v1.py
python3 -I -S -B source/strip_fit_v1.py
python3 -I -S -B source/capped_orbits_v1.py
python3 -I -S -B source/word_promotion_v1.py
python3 -I -S -B source/triangle_transfer_v1.py
python3 -I -S -B source/frame_transfer_v1.py
mv held-back-v1.json input/held-back-v1.json
python3 -I -S -B source/layer_audit_v1.py
python3 -I -S -B publication/render_v1.py
```

Compare the eight result files to the hashes in `publication/replay-v1.json`.
The browser check uses Node.js, Playwright, Chromium, and network access to the
notebook's MathJax dependency. Set `GCTS_PLAYWRIGHT` and `GCTS_CHROME` if the
package or browser is in a custom location. Run `node publication/check_v1.cjs`.
