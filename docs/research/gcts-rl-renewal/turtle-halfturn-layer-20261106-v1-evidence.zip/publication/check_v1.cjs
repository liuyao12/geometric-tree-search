const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-halfturn-layer-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 17);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator(".hero .patch-piece").count(), 11);
    assert.equal(await page.locator("#assembly .gallery svg").count(), 4);
    assert.equal(await page.locator("#word .collision").count(), 1);
    assert.equal(await page.locator("#context tbody tr").count(), 10);
    assert.equal(await page.locator("#checks tbody tr").count(), 5);
    const winner = await page.locator("#context .winner-row").innerText();
    assert(winner.includes("C04") && winner.includes("124") && winner.includes("594"));
    if (!process.argv[2]) {
      await page.locator(".hero").screenshot({ path: path.join(__dirname, "parent-v1.png") });
      await page.locator("#assembly .gallery").screenshot({ path: path.join(__dirname, "gallery-v1.png") });
      await page.locator("#word figure").screenshot({ path: path.join(__dirname, "collision-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_TURTLE_HALF_TURN_LAYER_READER", parentTiles: 5654,
      assemblyPanels: 5, rankedCandidates: 10, auditRows: 5, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
