"""Test the second held-out word in a frame built entirely from recovered patches."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import save
from cluster_v1 import load
from collar_audit_v1 import freeze
from large_collision_v1 import RowCollision
from scaffold_v1 import Scaffold, centred, make
from word_promotion_v1 import predict


def main():
    s,old=make()
    selection=freeze(load("data/capped-orbits-v1.json"))["cases"][0]
    p2=selection["recipe"]["patch"]
    t3=selection["winners"][0]["patch"]
    p3result=freeze(load("data/word-promotion-v1.json"))
    p3=p3result["assemblies"][0]
    t4=freeze(load("data/triangle-transfer-v1.json"))["winners"][0]
    alphabet=dict(old["alphabet"])
    dx,dy=alphabet["stride"]
    alphabet["path"]=tuple((g,x+i*dx,y+i*dy) for i,k in enumerate(p3["word"])
                           for g,x,y in (alphabet["letters"][k],))
    recipe=dict(motif=p3["patch"],doublet=p2,seed=t3,motif_pairs=p3["pieces"][:5],
                strips=p3["pieces"][-2:],alphabet=alphabet,
                parents=[dict(pieces=(*t4["pieces"][4:],*t4["pieces"][1:4]))])
    new=Scaffold(s.geom,recipe)
    new.collision=RowCollision(s.geom)
    cap=centred(s.geom,old["parents"][0]["patch"])
    result=predict(new,recipe,cap,p3result["words"][8])
    save("data/frame-transfer-v1.json",dict(status="TRANSFERRED_HALF_TURN_FRAME_AND_PREDICTED_WORD",
        length=len(p3result["words"][8]),**result))
    print("core",result["scaffold_score"],"assemblies",len(result["assemblies"]),flush=True)
    for r in result["assemblies"][:6]:
        print(len(r["patch"]),r["perimeter"],len(r["caps"]),flush=True)


if __name__=="__main__":
    main()
