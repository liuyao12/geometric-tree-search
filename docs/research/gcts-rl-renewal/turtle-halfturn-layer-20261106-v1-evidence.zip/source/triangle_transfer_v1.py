"""Replay capped triangular placement one scale above the learned half-turn frame."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import save
from cluster_v1 import load
from collar_audit_v1 import freeze
from capped_orbits_v1 import capped
from large_collision_v1 import RowCollision
from scaffold_v1 import centred, make


def main():
    s,first=make()
    state=freeze(load("data/capped-orbits-v1.json"))
    promoted=freeze(load("data/word-promotion-v1.json"))
    assert promoted["assemblies"]
    smaller=centred(s.geom,first["parents"][0]["patch"])
    child=centred(s.geom,state["cases"][0]["winners"][0]["patch"])
    middle=centred(s.geom,promoted["assemblies"][0]["patch"])
    fast=RowCollision(s.geom)
    checks=0
    for a,b in ((smaller,state["cases"][0]["canonical"]),
                (s.big,child),(s.small,middle)):
        assert fast.blocked(a,b)==s.collision.blocked(a,b)
        checks+=1
    s.collision=fast
    result=capped(s,child,smaller,middle)
    save("data/triangle-transfer-v1.json",dict(status="TRANSFERRED_CAPPED_TRIANGULAR_PRODUCTION",
        checked_displacement_pairs=checks,cap=smaller,triangle=child,motif=middle,**result))
    print(dict(best=result["best"],winners=len(result["winners"]),
        size=len(result["winners"][0]["patch"]) if result["winners"] else None,stats=result["stats"]),flush=True)


if __name__=="__main__":
    main()
