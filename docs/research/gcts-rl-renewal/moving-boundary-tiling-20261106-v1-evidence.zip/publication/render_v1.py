"""Render exact region boundaries, learned cluster placements, and one guard."""
from cmath import exp
from html import escape
import json
from math import pi,sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory,Region
from cases_v1 import frozen,load
from experiment_v1 import geometry
from geometry_v1 import chain

STEM="moving-boundary-tiling-20261106-v1"
COLORS=("#81b3c1","#c1a3d4","#e6b377","#8fbe9b","#99aadb","#d38c89")
NAMES={"parallelogram":"Parallelogram","hole":"Region with a hole","crop":"Irregular crop",
       "large":"Larger region","concave":"Concave outline","mixed-zonogon":"Mixed zonogon",
       "moved-negative":"Obstructed alternative","moved-positive":"Tiled alternative"}
KINDS={"turtle":"Turtle","penrose":"Penrose rhombs"}


def project(g,p):
    if g.kind=="turtle":
        x,y=p
        return x+y/2,-y*sqrt(3)/2
    z=sum(q*exp(2j*pi*k/5) for k,q in enumerate(p))
    return z.real,-z.imag


def coord(g,p):
    return ",".join(f"{x:.4f}" for x in project(g,p))


def path(g,points):
    return "M"+"L".join(coord(g,p) for p in points)+"Z"


def segment(g,a,b):
    return "M"+coord(g,a)+"L"+coord(g,b)


def outline(g,edges):
    return "".join(segment(g,a,b) for a,b in sorted(edges))


def drawing(g,rings,moves=(),core=None,blocked=None,label="Exact tiling"):
    raw=[]
    points=[p for ring in rings for p in ring]
    region="".join(path(g,r) for r in rings)
    raw.append(f'<path d="{region}" fill="#e9f1f3" fill-rule="evenodd"/>')
    for i,step in enumerate(moves):
        patch=step["patch"]
        fill=COLORS[i%len(COLORS)] if len(patch)>1 else "#dce5e6"
        style="cluster" if len(patch)>1 else "single"
        raw.append(f'<g class="{style}"><title>Move {i+1} places {len(patch)} tiles</title>')
        for t in patch:
            raw.append(f'<path class="tile" d="{path(g,g.poly(t))}" fill="{fill}" stroke="#fff" stroke-width=".8"/>')
        if len(patch)>1:
            raw.append(f'<path d="{outline(g,chain(g,patch))}" fill="none" stroke="#456d7c" stroke-width="1.4"/>')
        raw.append("</g>")
    raw.append(f'<path d="{region}" fill="none" stroke="#284d60" stroke-width="1.55"/>')
    if core is not None:
        raw.append(f'<path class="core" d="{path(g,g.poly(core))}" fill="#5ab8c922" stroke="#08647d" '
                   'stroke-width="2" stroke-dasharray="4 3"/>')
    if blocked:
        edge,t,w=blocked
        poly=g.poly(t)
        points.extend(poly)
        raw.append(f'<path class="offer" d="{path(g,poly)}" fill="#f4b06755" stroke="#a44d17" '
                   'stroke-width="1.3" stroke-dasharray="4 3"/>')
        raw.append(f'<path class="blocked-edge" d="{segment(g,*edge)}" stroke="#c02e33" stroke-width="3.2"/>')
        kind,*q=w
        if kind in ("site","center"):
            den=g.model.scale if kind=="site" else 4
            site=tuple(x/den for x in q[0])
            points.append(site)
            x,y=project(g,site)
            raw.append(f'<circle class="guard" cx="{x:.4f}" cy="{y:.4f}" r="3.3" fill="#c02e33" '
                       'vector-effect="non-scaling-stroke" stroke-width="1.1" stroke="#fff"/>')
        else:
            assert kind=="line"
            raw.append(f'<path class="guard" d="{segment(g,*q)}" stroke="#c02e33" stroke-width="2.5"/>')
    xs,ys=zip(*(project(g,p) for p in points))
    width,height=max(xs)-min(xs),max(ys)-min(ys)
    pad=max(width,height)*.09
    box=(min(xs)-pad,min(ys)-pad,width+2*pad,height+2*pad)
    # Put the marker in diagram coordinates while keeping its visual radius consistent.
    raw=[r.replace('r="3.3"',f'r="{max(width,height)*.014:.4f}"') if r.startswith('<circle') else r
         for r in raw]
    view=" ".join(f"{v:.4f}" for v in box)
    return f'<svg role="img" aria-label="{escape(label)}" viewBox="{view}">{"".join(raw)}</svg>'


def arm(case,key):
    return next(r for r in case["arms"] if r["arm"]==key)


def negative_picture(g,cohort,negative,positive):
    bank=cohort["marks"]["moved-negative/marked"]
    hit=next(h for h in bank["hits"] if h["case"]=="moved-negative")
    donor=bank["donors"][hit["donor"]]
    edge=frozen(hit["edge"])
    bad=Region(g,frozen(negative["rings"]))
    options=Inventory(g).at(edge)
    guards=[bad.relocate(w,edge[0]) for w in frozen(donor["local"])]
    choice=next((i for i,w in enumerate(guards) if w[0] in ("site","center")),0)
    blocked=(edge,options[choice][0],guards[choice])
    core=frozen(cohort["common_core"])
    figures=(drawing(g,bad.rings,core=core,blocked=blocked,label=f"{KINDS[g.kind]} blocked outline"),
             drawing(g,frozen(positive["rings"]),frozen_moves(arm(positive,"clusters")),core=core,
                     label=f"{KINDS[g.kind]} tiled outline"))
    return f'''<section class="boundary-family" id="{g.kind}-movable">
<h3>{KINDS[g.kind]} boundary alternatives</h3>
<div class="gallery">
<figure>{figures[0]}<figcaption>Obstructed outline. The red edge needs a tile. The orange outline shows one candidate and its red exclusion witness. The transferred mark excludes all {len(options)} candidates.</figcaption></figure>
<figure>{figures[1]}<figcaption>Feasible outline. The search returned a complete cover. The blue dashed tile is a common core contained in both alternatives.</figcaption></figure>
</div></section>'''


def frozen_moves(row):
    return [{"patch":frozen(x["patch"])} for x in row["moves"]]


def table_rows(cohort):
    cells=[]
    for c in cohort["cases"]:
        row=f'<tr><th scope="row">{KINDS[cohort["kind"]]} · {NAMES[c["id"]]}</th>'
        row+=f'<td>{sum(c["counts"])}</td>'
        for name in ("plain","marked","clusters","bandit","wide-bandit"):
            trial=arm(c,name)
            checks=trial["counts"].get("placement_checks",0)
            nodes=trial["counts"]["nodes"]
            row+=f'<td>{checks:,} <span class="nodes">({nodes:,})</span></td>'
        row+=f'<td>{c["expected"].title()}</td></tr>'
        cells.append(row)
    return "".join(cells)


def main():
    result=load("data/results-v1.json")
    timing=load("data/timing-v1.json")
    audit=load("data/audit-v1.json")
    models=geometry()
    large, families, tables=[],[],[]
    for cohort in result["rows"]:
        name=cohort["kind"]
        g=models[name]
        cases={r["id"]:r for r in cohort["cases"]}
        row=cases["large"]
        r=arm(row,"clusters")
        image=drawing(g,frozen(row["rings"]),frozen_moves(r),label=f"{KINDS[name]} full region tiled with clusters")
        clusters=sum(len(s["patch"])>1 for s in r["moves"])
        large.append(f'<figure>{image}<figcaption>{KINDS[name]}. {sum(row["counts"])} tiles in the complete '
                     f'cover, with {clusters} cluster moves. Each colored patch was placed as a unit.</figcaption></figure>')
        families.append(negative_picture(g,cohort,cases["moved-negative"],cases["moved-positive"]))
        tables.append(table_rows(cohort))
    elapsed=[]
    for row in timing["rows"]:
        plain,cluster=(row["median"][x] for x in ("plain","clusters"))
        elapsed.append(f'<tr><th scope="row">{KINDS[row["kind"]]}</th><td>{plain["setup_ns"]/1e6:.1f}</td>'
                       f'<td>{plain["search_ns"]/1e6:.1f}</td><td>{cluster["search_ns"]/1e6:.1f}</td>'
                       f'<td>{row["macro_inventory_ns"]/1e6:.1f}</td></tr>')
    report=(ROOT/"publication"/"notebook-v1.html").read_text()
    vals=dict(STEM=STEM,LARGE="".join(large),FAMILIES="".join(families),TABLE="".join(tables),
              TIMING="".join(elapsed),AUDIT_ARMS=str(sum(r["verified_positive_arms"] for r in audit["rows"])),
              HITS=str(sum(r["hits"] for r in audit["rows"])))
    for name,v in vals.items():
        key="%%"+name+"%%"
        assert key in report
        report=report.replace(key,v)
    assert "%%" not in report
    (ROOT/"report"/f"{STEM}.html").write_text(report)


if __name__=="__main__":
    main()
