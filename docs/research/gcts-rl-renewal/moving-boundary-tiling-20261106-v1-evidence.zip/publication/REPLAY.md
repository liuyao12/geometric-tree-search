# Replay the exact region searches

Use Python 3.12 with its standard library. Preserve the supplied evidence
and run these commands in an extracted copy of the archive.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/cases_v1.py
    python3.12 -I -S -B source/experiment_v1.py
    python3.12 -I -S -B source/audit_v1.py

The three deterministic outputs are listed in the replay receipt. The
audit can also run directly against the archived result and check the
complete covers and no-placement witnesses without running the search.

To regenerate the published notebook with the original timing receipt, run:

    cp archived-data/timing-v1.json data/
    python3.12 -I -S -B publication/render_v1.py

For a new local timing sample, run the separate timing script. Its output
depends on the machine and workload. The headless browser check uses
MathJax and Chromium. Set `GCTS_PLAYWRIGHT` and `GCTS_CHROME` for custom
installations before running `node publication/check_v1.cjs`.

The input Turtle patch coordinates come from the preceding Golden Hex
coordinate recovery. The held-out searches receive the outer rings and
holes, together with the declared donor outlines. The Penrose examples
use exact ring coordinates and unmarked edge-to-edge contact.
