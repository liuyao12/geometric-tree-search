const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/moving-boundary-tiling-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length === 5);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("svg").count(), 6);
    assert.equal(await page.locator("#moving .blocked-edge").count(), 2);
    assert.equal(await page.locator("#moving .guard").count(), 2);
    assert.equal(await page.locator("#moving .core").count(), 4);
    assert.equal(await page.locator("#results table").first().locator("tbody tr").count(), 12);
    const large = await page.locator("#fixed figure").evaluateAll(fs => fs.map(f => f.querySelectorAll(".tile").length));
    assert.deepEqual(large, [72, 49]);
    const clusters = await page.locator("#fixed figure").evaluateAll(fs => fs.map(f => f.querySelectorAll(".cluster").length));
    assert.deepEqual(clusters, [7, 17]);
    if (!process.argv[2]) {
      await page.locator("#fixed .gallery").screenshot({ path: path.join(__dirname, "fixed-v1.png") });
      await page.locator("#penrose-movable .gallery").screenshot({ path: path.join(__dirname, "penrose-movable-v1.png") });
      await page.locator("#turtle-movable .gallery").screenshot({ path: path.join(__dirname, "turtle-movable-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_MOVING_BOUNDARY_READER", figures: 6, largeTiles: large, clusters,
      math: await page.locator("mjx-container").count(), mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
