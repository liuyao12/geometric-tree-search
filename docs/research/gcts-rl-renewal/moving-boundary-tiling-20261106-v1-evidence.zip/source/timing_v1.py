"""Repeat two larger fixed searches and separate region setup from search."""
from copy import deepcopy
import json
from pathlib import Path
from statistics import median
import sys
from time import perf_counter_ns

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, solve
from cases_v1 import frozen, load
from experiment_v1 import geometry, learn_block, learn_clusters, NODE_LIMIT
import check_v1 as independent
import model_v1 as penrose


def clear(g):
    g.boundary.cache_clear()
    if g.kind=="turtle":
        g.sites.cache_clear()
    else:
        penrose.clear_geometry()
        for op in (g.poly,g.mass,independent.corners,independent.imaginary_normal,
                   independent.hull,independent.canonical_contact):
            op.cache_clear()


def main():
    frozen_data={k:{name:frozen(v) for name,v in x.items()} for k,x in load("input/cases-v1.json").items()}
    rows=[]
    for name,g in geometry().items():
        d=frozen_data[name]
        units=Inventory(g)
        learned,_=learn_clusters(g,d)
        t=perf_counter_ns()
        library=Inventory(g,learned)
        inventory_ns=perf_counter_ns()-t
        bank=learn_block(g,units,d)
        rings=dict(d["fixed"])["large"]
        result={"plain":[],"clusters":[]}
        for i in range(5):
            methods=("plain","clusters") if i%2==0 else ("clusters","plain")
            for label in methods:
                clear(g)
                marks=None if label=="plain" else deepcopy(bank)
                t=perf_counter_ns()
                r=Region(g,rings)
                begin=perf_counter_ns()
                solved=solve(r,units if label=="plain" else library,"large",marks,limit=NODE_LIMIT)
                end=perf_counter_ns()
                assert solved["status"]=="POSITIVE"
                result[label].append(dict(setup_ns=begin-t,search_ns=end-begin))
        medians={arm:{k:int(median(r[k] for r in samples)) for k in ("setup_ns","search_ns")}
                 for arm,samples in result.items()}
        rows.append(dict(kind=name,repeats=result,median=medians,macro_inventory_ns=inventory_ns))
    out=dict(status="LOCAL_ALTERNATING_TIMING",rows=rows,scope="Search excludes cluster learning and final proof replay.")
    (ROOT/"data/timing-v1.json").write_text(json.dumps(out,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(out,sort_keys=True))


if __name__=="__main__":
    main()
