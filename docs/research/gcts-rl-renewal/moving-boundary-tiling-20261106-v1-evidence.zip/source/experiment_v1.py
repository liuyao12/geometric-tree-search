"""Run paired fixed and movable polygon searches on two exact lattices."""
from collections import defaultdict
from copy import deepcopy
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cases_v1 import frozen, load, neighbors, patch_ring, relocate, rhomb_grid
from boundary_search_v1 import Bank, Inventory, Region, solve
from geometry_v1 import Penrose, Turtle

ORDERS=("large","seal","single")
NODE_LIMIT=2000


def dump(name,record):
    (ROOT/name).write_text(json.dumps(record,sort_keys=True,separators=(",",":"))+"\n")


class Bandit:
    """Select one move-order strategy per episode and learn from its cost."""
    def __init__(self,wide=False):
        self.rng=Random(30217)
        self.value=defaultdict(lambda:defaultdict(list))
        self.wide=wide

    def category(self,g,region):
        n=sum(region.counts)
        boundary_per_tile=len(region.edges)/n
        dense=boundary_per_tile < (12 if g.kind=="turtle" else 3.5)
        return g.kind,int(self.wide and n>=20),int(dense)

    def choose(self,g,region,train):
        context=self.category(g,region)
        data=self.value[context]
        if train:
            untouched=[rule for rule in ORDERS if not data.get(rule)]
            if untouched:
                return untouched[0]
            if self.rng.random()<.23:
                return self.rng.choice(ORDERS)
        broad=self.value[(*context[:2],2)]
        def score(rule):
            values=data.get(rule) or broad.get(rule)
            return (sum(values)/len(values) if values else -1000,-ORDERS.index(rule))
        return max(ORDERS,key=score)

    def update(self,g,region,rule,value):
        self.value[self.category(g,region)][rule].append(value)
        self.value[(*self.category(g,region)[:2],2)][rule].append(value)


def geometry():
    return {"turtle":Turtle(load("input/exact-point-model-v1.json")),"penrose":Penrose()}


def learn_clusters(g,data):
    forms=[]
    donors=[]
    units=Inventory(g)
    for i,rings in enumerate(data["training"]):
        region=Region(g,rings)
        record=solve(region,units,f"cluster-{i+1}",limit=NODE_LIMIT)
        assert record["status"]=="POSITIVE"
        patch=record["patch"]
        g.verify(rings,patch)
        forms.append(patch)
        donors.append(dict(id=f"cluster-{i+1}",rings=rings,patch=patch,checks=record["counts"]))
    return tuple(forms),donors


def learn_block(g,units,data):
    r=Region(g,data["donor"])
    edge=data["donor_edge"]
    candidates=units.at(edge)
    guards=[r.exterior(t) for t, in candidates]
    assert candidates and all(w is not None for w in guards)
    bank=Bank()
    bank.learn(r,edge,guards,candidates,frozenset(),"donor",())
    return bank


def training(g,library,policy,large=False):
    records=[]
    if g.kind=="turtle":
        t2=next(frozen(row["patch"]) for row in load("input/growth-v1.json")["levels"] if row["id"]=="T2")
        sizes=(20,26,33,40,47,54) if large else (3,4,5,7,8,9)
        prototypes=[patch_ring(g,neighbors(g,t2,n)) for n in sizes]
        offsets=[(3*i-5,2-i) for i in range(15)]
    else:
        specs=(((5,4,1,()),(5,5,2,((1,1),)),(6,4,1,()),(5,6,2,((4,5),)),
                (5,5,1,()),(6,6,2,((1,1),(3,3)))) if large else
               ((2,2,1,()),(2,2,2,()),(3,1,1,()),(3,2,2,((2,1),)),
                (3,2,1,()),(3,3,2,((1,1),))))
        prototypes=[patch_ring(g,rhomb_grid(m,n,w,omit)) for m,n,w,omit in specs]
        offsets=[(i-2,0,3-i,2*i) for i in range(15)]
    assert all(prototypes)
    for i,offset in enumerate(offsets):
        rings=relocate(g,prototypes[i%len(prototypes)],offset)
        region=Region(g,rings)
        rule=policy.choose(g,region,True)
        trial=solve(region,library,f"policy-{i+1}",Bank(),rule,limit=NODE_LIMIT)
        assert trial["status"] in ("POSITIVE","BOUNDED")
        counts=trial["counts"]
        reward=-(counts["placement_checks"]+4*counts["nodes"])/sum(region.counts)
        if trial["status"]=="BOUNDED":
            reward-=10000
        policy.update(g,region,rule,reward)
        records.append(dict(order=rule,reward=reward,counts=counts,ring=rings,status=trial["status"]))
    return records


def pilot(data):
    for name,g in geometry().items():
        source=data[name]
        units=Inventory(g)
        library=Inventory(g,learn_clusters(g,source)[0])
        marks=learn_block(g,units,source)
        for id,rings in source["fixed"]+source["movable"]:
            for label,inv,bank in (("plain",units,None),("macro",library,deepcopy(marks))):
                result=solve(Region(g,rings),inv,id,bank,limit=NODE_LIMIT)
                print(name,id,label,result["status"],result["counts"],flush=True)


def main(data):
    combined=[]
    policy=Bandit()
    wide=Bandit(wide=True)
    for name,g in geometry().items():
        source=data[name]
        units=Inventory(g)
        forms,cluster_donors=learn_clusters(g,source)
        library=Inventory(g,forms)
        bank=learn_block(g,units,source)
        episodes=training(g,library,policy)
        wide_episodes=training(g,library,wide)+training(g,library,wide,large=True)
        trials=[]
        banks={}
        choices=defaultdict(list)
        for id,rings in source["fixed"]+source["movable"]:
            expected="NEGATIVE" if id=="moved-negative" else "POSITIVE"
            arms=[]
            for label,inv,marked,learned in (
                ("plain",units,False,None),("marked",units,True,None),
                ("clusters",library,True,None),("bandit",library,True,policy),
                ("wide-bandit",library,True,wide),
            ):
                region=Region(g,rings)
                if id.startswith("moved"):
                    assert region.exterior(source["added_tile"]) is None
                rules=deepcopy(bank) if marked else None
                rule=learned.choose(g,region,False) if learned else "large"
                result=solve(region,inv,id,rules,rule,limit=NODE_LIMIT)
                assert result["status"] in (expected,"BOUNDED"), (name,id,label,result)
                if result["status"]=="POSITIVE":
                    g.verify(rings,result["patch"])
                    if id.startswith("moved"):
                        choices[label].append(id)
                if rules:
                    banks[id+"/"+label]=dict(donors=rules.donors,hits=rules.hits)
                arms.append(dict(arm=label,order=rule,**result))
                print(json.dumps(dict(kind=name,id=id,arm=label,order=rule,status=result["status"],
                                      counts=result["counts"]),sort_keys=True),flush=True)
            trials.append(dict(id=id,rings=rings,counts=region.counts,expected=expected,arms=arms))
        combined.append(dict(kind=name,cluster_poses=library.cluster_poses,cluster_donors=cluster_donors,
                             episodes=episodes,wide_episodes=wide_episodes,cases=trials,marks=banks,movable_witness=dict(choices),
                             common_core=source["added_tile"],motion=source["translated_anchor"]))
    models={name:{f"{kind}/{size}/{density}":rules for (kind,size,density),rules in q.value.items()}
            for name,q in (("small",policy),("wide",wide))}
    dump("data/results-v1.json",dict(status="CHECKED_FIXED_AND_MOVABLE_REGIONS",rows=combined,policy=models,
                                     limits=dict(nodes=NODE_LIMIT,edge_lookahead=6,training_seed=30217)))


if __name__=="__main__":
    data={k:{n:frozen(x) for n,x in v.items()} for k,v in load("input/cases-v1.json").items()}
    pilot(data) if "--pilot" in sys.argv else main(data)
