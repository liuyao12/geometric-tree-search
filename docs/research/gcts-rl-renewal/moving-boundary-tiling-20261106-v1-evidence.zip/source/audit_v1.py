"""Audit cover boundaries and replay each learned edge obstruction."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from boundary_search_v1 import Inventory, Region, remove
from cases_v1 import frozen, load
from experiment_v1 import geometry
from geometry_v1 import add, chain, sub
import check_v1 as independent


def direct_candidates(g,edge):
    a,b=edge
    if g.kind=="penrose":
        return {t for t in independent.corners(a)
                if b in t and all(independent.order(independent.imaginary_normal(
                    sub(b,a),sub(p,a)),(0,0))>=0 for p in t)}
    wanted=sub(b,a)
    return {g.shift(t,sub(a,p)) for t in g.bases for p,q in g.boundary(t) if sub(q,p)==wanted}


def check_witness(g,region,t,guard,placed):
    kind,*values=guard
    if kind=="site":
        p,=values
        scale=g.model.scale
        assert g.wind(g.poly(t),p,scale)==1
        outside=not region.inside(p,scale)
        assert outside or any(g.wind(g.poly(old),p,scale)==1 for old in placed)
    elif kind=="center":
        p,=values
        assert p==tuple(map(sum,zip(*t))) and not region.inside(p,4)
    elif kind=="line":
        assert tuple(values) in region.lines and g.intrudes(*values,t)
    else:
        old,=values
        assert kind=="tile" and old in placed and not independent.contact(t,old)


def verify_block(g,inv,region,edge,guards,placed):
    assert edge in remove(region.edges,chain(g,placed))
    options=[t for t, in inv.at(edge)]
    assert set(options)==direct_candidates(g,edge) and len(options)==len(guards)
    for t,w in zip(options,guards,strict=True):
        check_witness(g,region,t,w,placed)
    return len(options)


def main():
    data={k:{name:frozen(v) for name,v in x.items()} for k,x in load("input/cases-v1.json").items()}
    evidence=load("data/results-v1.json")
    geos=geometry()
    rows=[]
    for cohort in evidence["rows"]:
        name=cohort["kind"]
        g=geos[name]
        inv=Inventory(g)
        original=data[name]
        regions={"donor":Region(g,original["donor"])}
        verified_patches=set()
        full_witnesses=0
        for case in cohort["cases"]:
            id=case["id"]
            rings=frozen(case["rings"])
            regions[id]=Region(g,rings)
            if id.startswith("moved"):
                assert regions[id].exterior(frozen(cohort["common_core"])) is None
            for arm in case["arms"]:
                assert arm["status"]==case["expected"]
                if arm["status"]=="POSITIVE":
                    patch=frozen(arm["patch"])
                    residual=regions[id].edges
                    sequence=[]
                    for step in arm["moves"]:
                        edge,block=frozen(step["edge"]),frozen(step["patch"])
                        assert edge in residual and edge in chain(g,block)
                        residual=remove(residual,chain(g,block))
                        sequence.extend(block)
                    assert not residual and tuple(sequence)==patch
                    signature=(id,tuple(sorted(patch)))
                    if signature not in verified_patches:
                        g.verify(rings,patch)
                        masses=tuple(map(sum,zip(*(g.mass(t) for t in patch))))
                        assert masses==frozen(case["counts"])
                        verified_patches.add(signature)
                    full_witnesses+=1
        checked_donors=set()
        hits=transferred=candidates=0
        for bank in cohort["marks"].values():
            for digest,donor in bank["donors"].items():
                edge=frozen(donor["edge"])
                current=regions[donor["case"]]
                placed=frozen(donor["placed"])
                guards=[current.relocate(w,edge[0]) for w in frozen(donor["local"])]
                signature=(digest,donor["case"],edge,placed)
                if signature not in checked_donors:
                    candidates+=verify_block(g,inv,current,edge,guards,placed)
                    checked_donors.add(signature)
            for hit in bank["hits"]:
                donor=bank["donors"][hit["donor"]]
                edge=frozen(hit["edge"])
                region=regions[hit["case"]]
                placed=frozen(hit["placed"])
                assert sub(edge[1],edge[0])==sub(*reversed(frozen(donor["edge"])))
                guards=[region.relocate(w,edge[0]) for w in frozen(donor["local"])]
                candidates+=verify_block(g,inv,region,edge,guards,placed)
                hits+=1
                transferred+=donor["case"]!=hit["case"]
        original_edge=frozen(original["donor_edge"])
        new_edge=tuple(add(x,original["translated_anchor"]) for x in original_edge)
        reject=regions["moved-negative"]
        assert new_edge in reject.edges and all(reject.exterior(t) is not None
                                                for t in direct_candidates(g,new_edge))
        assert all(v==["moved-positive"] for v in cohort["movable_witness"].values())
        rows.append(dict(kind=name,verified_positive_arms=full_witnesses,
                         independent_patch_shapes=len(verified_patches),donors=len(checked_donors),
                         hits=hits,changed_boundary_hits=transferred,placements_excluded=candidates))
    result=dict(status="AUDITED_EXACT_BOUNDARY_WITNESSES",rows=rows)
    (ROOT/"data/audit-v1.json").write_text(json.dumps(result,sort_keys=True,separators=(",",":"))+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":
    main()
