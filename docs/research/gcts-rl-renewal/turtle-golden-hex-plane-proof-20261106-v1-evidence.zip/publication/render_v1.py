"""Render the Golden Hex plane certificate as a standalone HTML notebook."""
import gzip
from html import escape
import json
from math import sqrt
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load
from fixed_palette_v1 import palette, tile_at
from golden_geometry_v1 import words
from golden_seams_v1 import receptors
from symbolic_v1 import signed_labels
from verify_plane_v1 import direct

STEM = "turtle-golden-hex-plane-proof-20261106-v1"
COLORS = ("#075985", "#a83a04", "#166534", "#853ba1")
MODEL = Model(load("input/exact-point-model-v1.json"))
GROWTH = {row["id"]: row for row in load("input/growth-v1.json")["levels"]}
MASKS = signed_labels(MODEL)


def project(point):
    x, y = point
    return x + y / 2, -sqrt(3) * y / 2


def pair(point):
    return ",".join(f"{v:.3f}" for v in project(point))


def path(points):
    return "M" + "L".join(map(pair, points)) + "Z"


def geom_svg(ring, content, label):
    xy = [project(point) for point in ring]
    xmin, xmax = min(x for x, _ in xy), max(x for x, _ in xy)
    ymin, ymax = min(y for _, y in xy), max(y for _, y in xy)
    pad = 0.06 * max(xmax - xmin, ymax - ymin)
    box = (xmin - pad, ymin - pad, xmax - xmin + 2 * pad, ymax - ymin + 2 * pad)
    return (f'<svg role="img" aria-label="{escape(label)}" viewBox="' +
            " ".join(f"{x:.3f}" for x in box) + '">' + content + "</svg>")


def seam_svg(kind):
    ring = GROWTH[kind + "3"]["ring"]
    paths = []
    for color, args in zip(COLORS, receptors(MODEL, kind, 3, words(7))):
        segments = direct(MODEL, MASKS, *args, 1)
        assert all(not key[0] for key in segments)
        commands = "".join(f'M{pair(start)}L{pair((start[0] + edge[0], start[1] + edge[1]))}'
                           for (_, _, start, _, edge), coefficient in segments.items() if coefficient)
        paths.append(f'<path class="seam" d="{commands}" stroke="{color}" stroke-width="2"/>')
    return geom_svg(ring, f'<path d="{path(ring)}" fill="#ecf4f5"/>' + "".join(paths),
                    "Triangle with three colored paths" if kind == "T" else "Parallelogram with four colored paths")


def nested_svg():
    rings = [GROWTH[f"T{n}"]["ring"] for n in (5, 3, 1)]
    rings[1] = [(-x, -y) for x, y in rings[1]]
    radius = len(words(11)[11][:-2]) - 1
    shapes = []
    for ring, fill, stroke in zip(rings, ("#e2f0f5", "#f5d5aa", "#642b84"), COLORS):
        shapes.append(f'<path d="{path(ring)}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>')
    shapes.insert(1, f'<circle r="{radius}" fill="none" stroke="#075985" stroke-dasharray="5 5" stroke-width="1"/>')
    return geom_svg(rings[0], "".join(shapes), "Three nested triangle patches and a certified disk in the largest")


def wang_svg(kind):
    with gzip.open(ROOT / f"data/wang-{kind.lower()}-v1.json.gz", "rt") as stream:
        evidence = json.load(stream)
    circuit, cert = evidence["circuit"], evidence["certificate"]
    tiles = palette()["tiles"]
    bit = int(kind == "P")
    y, x = next((y, x) for y, row in enumerate(cert["rows"]) for x, identifier in row["active"]
                if tiles[identifier]["N"] == ["READ", bit] and 2 <= x < len(circuit["inputs"]))
    x0, y0 = max(0, x - 2), max(0, y - 1)
    colors = {"CROSS": ("#d7e4ee", "#80aecb"), "READ": ("#a6d9c1", "#419f79"),
              "NAND": ("#ffd296", "#f79d43"), "NOT": ("#f0c1df", "#df84ba"),
              "WRITE": ("#d4c3eb", "#a385d4")}
    horizontals = ("#eceff1", "#646d80")
    parts = []
    for dy in range(4):
        for dx in range(8):
            xx, yy = x0 + dx, y0 + dy
            identifier = tile_at(circuit, cert, xx, yy)
            t = tiles[identifier]
            attrs = f' data-x="{xx}" data-y="{yy}" data-id="{identifier}"'
            parts.append(f'<g class="wang-cell" transform="translate({dx * 32} {dy * 32})"{attrs}>')
            parts.append(f'<title>Tile {identifier} at ({xx}, {yy}). N {t["N"]}, E {t["E"]}, S {t["S"]}, W {t["W"]}</title>')
            for triangle, color in zip(("0,0 32,0 16,16", "32,0 32,32 16,16", "32,32 0,32 16,16", "0,32 0,0 16,16"),
                                       (colors[t["N"][0]][t["N"][1]], horizontals[t["E"]],
                                        colors[t["S"][0]][t["S"][1]], horizontals[t["W"]])):
                parts.append(f'<polygon points="{triangle}" fill="{color}"/>')
            parts.append('<rect width="32" height="32" fill="none" stroke="#2c4052" stroke-width=".65"/>')
            parts.append(f'<text x="16" y="19" text-anchor="middle" paint-order="stroke" stroke="#fff" stroke-width="2" fill="#172733">{identifier}</text>')
            if (xx, yy) == (x, y):
                parts.append('<rect class="read" x="1" y="1" width="30" height="30" fill="none" stroke="#1b5033" stroke-width="2"/>')
            parts.append("</g>")
    svg = '<svg class="wang" role="img" aria-label="Real Wang tile window with choice read outlined" viewBox="0 0 256 128">' + "".join(parts) + "</svg>"
    return svg, f"Columns {x0}–{x0 + 7}, rows {y0}–{y0 + 3}. The outline identifies the read of choice bit {bit}."


def tables():
    search = load("data/symbolic-v1.json")["rows"]
    wang = load("data/wang-v1.json")["rows"]
    proof = load("data/plane-v1.json")
    a, b, c = [], [], []
    for s, w, g in zip(search, wang, proof["identity"], strict=True):
        name = {"T": "Triangle", "P": "Parallelogram"}[s["kind"]]
        a.append(f'<tr><th scope="row">{name}</th><td>{s["sites"]}</td><td>{s["term_keys"]:,}</td>'
                 f'<td>{s["stats"]["nodes"]}</td><td>{g["shifted_first_seam_nonzero_coefficients"]:,}</td></tr>')
        b.append(f'<tr><th scope="row">{name}</th><td>{w["bits"]}</td><td>{w["distinct_constraints"]}</td>'
                 f'<td>{w["gates"]:,}</td><td>{w["wang"]["cells"]:,}</td><td>{w["rejected"]}/{w["controls"]}</td></tr>')
        for i, (choice, expansion) in enumerate(zip(s["solution"], s["expansions"], strict=True), 1):
            c.append(rf'<tr><th scope="row">{name}, {i}</th><td>{choice}</td><td>\({"".join(expansion)}\)</td></tr>')
    return tuple("".join(rows) for rows in (a, b, c))


def main():
    search, wang, choices = tables()
    t_grid, t_note = wang_svg("T")
    p_grid, p_note = wang_svg("P")
    template = (ROOT / "publication" / "notebook-v1.html").read_text()
    values = dict(STEM=STEM, TRIANGLE=seam_svg("T"), PARALLELOGRAM=seam_svg("P"), NESTED=nested_svg(),
                  SEARCH=search, WANG=wang, CHOICES=choices, T_GRID=t_grid, P_GRID=p_grid,
                  T_NOTE=t_note, P_NOTE=p_note)
    for key, value in values.items():
        marker = "%%" + key + "%%"
        assert marker in template
        template = template.replace(marker, value)
    assert "%%" not in template
    (ROOT / "report").mkdir(exist_ok=True)
    (ROOT / "report" / (STEM + ".html")).write_text(template)


if __name__ == "__main__":
    main()
