"""Build and verify the task-owned publication assets."""
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
STEM = "turtle-golden-hex-plane-proof-20261106-v1"
REPORT = ROOT / "report"


def read(name):
    return json.loads((ROOT / name).read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def main():
    protocol = read("protocol-v1.json")
    replay = read("publication/replay-v1.json")
    for path, record in protocol["pins"].items():
        assert pin((ROOT / path).read_bytes()) == record, path
    for path, digest in replay["outputs"].items():
        assert pin((ROOT / "data" / path).read_bytes())["sha256"] == digest, path

    summary = dict(schema="GCTS-GOLDEN-HEX-PLANE-RESULTS-v1",
                   plane=read("data/plane-v1.json"), search=read("data/symbolic-v1.json"),
                   topology=read("data/topology-v1.json"), wang=read("data/wang-v1.json"),
                   replay=replay, reader=read("publication/browser-v1.json"),
                   reference="https://doi.org/10.1007/s00454-025-00717-6")
    results = REPORT / f"{STEM}-results.json"
    write_json(results, summary)
    paths = set(protocol["pins"])
    paths.update(f"data/{p}" for p in replay["outputs"])
    paths.update(f"data/{kind}.{channel}.log" for kind in ("symbolic", "topology", "plane", "wang")
                 for channel in ("stdout", "stderr"))
    paths.update(f"publication/{p}" for p in ("REPLAY.md", "check_v1.cjs", "notebook-v1.html", "render_v1.py",
                                             "package_v1.py", "replay-v1.json", "browser-v1.json"))
    html = REPORT / f"{STEM}.html"
    paths.update(("protocol-v1.json", str(html.relative_to(ROOT)), str(results.relative_to(ROOT))))
    archive = REPORT / f"{STEM}-evidence.zip"
    records = {}
    with ZipFile(archive, "w") as out:
        for path in sorted(paths):
            raw = (ROOT / path).read_bytes()
            if not path.endswith(".gz"):
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), path
            info = ZipInfo(path, (2026, 11, 6, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            out.writestr(info, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
            records[path] = pin(raw)
    with ZipFile(archive) as check:
        assert check.testzip() is None
        assert {p: pin(check.read(p)) for p in check.namelist()} == records
    assets = {path.name: pin(path.read_bytes()) for path in (html, results, archive)}
    write_json(REPORT / f"{STEM}-manifest.json", dict(schema="GCTS-PUBLICATION-MANIFEST-v1",
                                                    assets=assets, archive_entries=records))
    print(json.dumps(dict(assets=assets, archive_entries=len(records)), indent=2))


if __name__ == "__main__":
    main()
