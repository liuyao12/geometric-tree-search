const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"]
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname,
      "../report/turtle-golden-hex-plane-proof-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.evaluate(async () => {
      if (window.MathJax?.startup) await window.MathJax.startup.promise;
    });
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 90);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("svg").count(), 5);
    assert.equal(await page.locator(".seam").count(), 7);
    assert.equal(await page.locator(".wang-cell").count(), 64);
    assert.equal(await page.locator(".wang .read").count(), 2);
    await page.locator("#proof summary").click();
    assert.equal(await page.locator("#proof details tbody tr:visible").count(), 65);
    const seamFigures = await page.locator("#markings figure").evaluateAll(nodes => nodes.map(n => n.querySelectorAll(".seam").length));
    assert.deepEqual(seamFigures, [3, 4]);
    if (!process.argv[2]) {
      for (const [selector, output] of [["#markings .gallery", "markings"], [".figure-wide", "nested"], ["#wang .gallery", "wang"]]) {
        await page.locator(selector).screenshot({ path: path.join(__dirname, output + "-v1.png") });
      }
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_PLANE_PROOF_READER", formulas: await page.locator("mjx-container").count(),
      figures: 5, seamFigures, wangCells: 64, choiceRows: 65, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(e => { console.error(e); process.exitCode = 1; });
