# Reproduce the Golden Hex plane certificate

The four scientific commands use only the Python standard library.
Set `GCTS_PYTHON` to a Python 3.12 executable. The exact replay used the
interpreter fingerprint in `protocol-v1.json`.

In a fresh extracted copy, run these commands from the archive root.

    mv data archived-data
    mkdir data
    "$GCTS_PYTHON" -I -S -B source/symbolic_v1.py
    "$GCTS_PYTHON" -I -S -B source/topology_v1.py
    "$GCTS_PYTHON" -I -S -B source/verify_plane_v1.py
    "$GCTS_PYTHON" -I -S -B source/wang_seams_v1.py

The plane verifier pins the original executable as well as the source and
input files. For a replay on another Python build, record your executable's
byte count and SHA-256 in the `runtime` object of a local copy of the protocol.
Keep the scientific file pins. Compare the six outputs in `data` with the
hashes in `publication/replay-v1.json`.

To check the plane certificate directly, copy the archived
`symbolic-v1.json` back into `data` and run `source/verify_plane_v1.py`.
The checker uses the saved choices to rebuild the symbolic chains and
tests their cancellation, the path topology, and the base cases.

To regenerate the notebook after the replay, run
`"$GCTS_PYTHON" -I -S -B publication/render_v1.py`. The browser check
uses Node.js, Playwright, Chromium, and access to the notebook's MathJax
script. Set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom installations.

The lattice vectors in the input snapshots were recovered using figures
from Shigeki Akiyama and Yoshiaki Araki, *An Alternative Proof for an
Aperiodic Monotile*, Discrete & Computational Geometry 74, 771–792 (2025).
The source is licensed under CC BY 4.0. The previous research notebook
documents the figure conversion and coordinate recovery.

- [Golden Hex construction](https://doi.org/10.1007/s00454-025-00717-6)
- [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
- [Coordinate recovery and window tiling](https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/turtle-golden-hex-windows-20261106-v1.html)
