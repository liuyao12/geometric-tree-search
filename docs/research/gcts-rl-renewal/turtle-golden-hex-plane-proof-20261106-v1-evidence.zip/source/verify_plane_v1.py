"""Replay the all-level Golden Hex proof and qualify its finite reductions."""

from collections import Counter
from dataclasses import dataclass
from itertools import pairwise,product
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,bounds,load,mat,pin,save
from golden_geometry_v1 import add,strip,support,words
from golden_growth_v1 import ball,from_tiles,norm
from symbolic_v1 import (AXES,Lin,PREFIX,STEP,children,differences,edge_term,kernel,ledger,scaled_vector,
                         signed_labels,sides,word_options,world_sides)
from topology_v1 import U_MIN,V_MIN,check_local,corner,ends,guides,ordered
from triangle_geometry_v1 import polygon_overlap,validate_polygon


def exact(p,u,v):
    result=tuple(x.at(u,v) if isinstance(x,Lin) else x for x in p)
    assert all(int(x)==x for x in result)
    return tuple(map(int,result))


def cleaned(counter):
    return {k:v for k,v in counter.items() if v}


def word_tail(s):
    """Finite-state prefix, suffix, and forbidden-factor summary."""
    return len(s) if len(s)<len(PREFIX)+2 else len(PREFIX)+2,s[:len(PREFIX)+2],s[-2:],not (
        "11" in s or "101" in s)


def join_words(a,b):
    size=min(len(PREFIX)+2,a[0]+b[0])
    suffix=(a[2]+b[2])[-2:]
    prefix=(a[1]+b[1])[:len(PREFIX)+2]
    ok=a[3] and b[3] and "11" not in a[2]+b[1][:2] and "101" not in a[2]+b[1][:2]
    return size,prefix,suffix,ok


def words_certificate():
    left,right=word_tail("0"),word_tail("001")
    states={}
    i=1
    while (left,right) not in states:
        assert left[3] and right[3]
        if i>=5:
            assert right[0]==len(PREFIX)+2 and right[1].startswith(PREFIX)
            assert right[2]==("01" if i%2 else "10")
        states[left,right]=i
        left,right=right,join_words(right,left)
        i+=1
    first=states[left,right]
    assert first>=5 and i%2==first%2
    initial=words(6)
    assert (len(initial[5][:-2]),len(initial[6][:-2]))==(U_MIN,V_MIN)
    assert initial[1][:-2]=="0" and initial[2][:-2]=="00"
    return dict(states=len(states),cycle_from=first,period=i-first,base_palindromes=["0","00"])


def direct(model,masks,role,word,g,shift,sign):
    out=Counter()
    matrix=model.groups[g]
    ctx="^"+word+"$"
    for i in range(len(word)):
        base=add(shift,scaled_vector(i,mat(matrix,STEP)))
        for a,b in kernel(model,masks,role,ctx[i:i+3],min(i,3),min(len(word)-i-1,3)):
            edge_term(out,"",(),base,"",mat(matrix,a),mat(matrix,b),sign)
    return out


def expand(symbolic,actual):
    out=Counter()
    lengths=tuple(map(len,actual))
    for (chunk,step,start,ctx,d),n in symbolic.items():
        assert ctx==""
        point=exact(start,*lengths)
        if not chunk:
            out[point,d]+=n
            continue
        assert chunk in ("U","V") and step in AXES
        word=actual[chunk=="V"]
        for i,b in enumerate(word):
            if b=="1":
                out[add(point,scaled_vector(i,step)),d]+=n
    return cleaned(out)


def check_identity(model,masks,certificate):
    admitted=word_options()
    symbolic_total=Counter()
    arithmetic_checks=0
    kind=certificate["kind"]
    sites=list(world_sides(model,kind))
    chosen=certificate["expansions"]
    assert len(sites)==len(chosen)
    actuals=[]
    for n in (4,5):
        sequence=words(2*n+1)
        actual=tuple(sequence[2*n-k][:-2] for k in (3,2))
        assert all(w==w[::-1] and w.startswith(PREFIX) for w in actual)
        actuals.append((sequence,actual))
    for (sign,role,label,g,shift),tokens in zip(sites,chosen,strict=True):
        assert tuple(tokens) in admitted[label]
        formal=ledger(model,masks,role,tokens,g,shift,sign)
        symbolic_total.update(formal)
        for seq,actual in actuals:
            parts=dict(U=actual[0],V=actual[1])
            h,p,w=(seq[i][:-2] for i in (-1,-2,-3))
            expected=dict(h=h,p=p,w=w,d="01"+p+"10",s=p+"10",
                          e="01"+actual[1]+"10",u=actual[0])[label]
            assert "".join(parts.get(t,t) for t in tokens)==expected
            numeric=direct(model,masks,role,expected,g,exact(shift,*map(len,actual)),sign)
            assert expand(formal,actual)==expand(differences(numeric),actual)
            arithmetic_checks+=1
    assert not cleaned(symbolic_total)
    sign,role,label,g,shift=sites[0]
    mutated=symbolic_total.copy()
    mutated.subtract(ledger(model,masks,role,chosen[0],g,shift,sign))
    mutated.update(ledger(model,masks,role,chosen[0],g,add(shift,(1,0)),sign))
    mismatch=len(cleaned(mutated))
    assert mismatch
    return dict(kind=kind,sites=len(sites),numeric_expansion_checks=arithmetic_checks,
                shifted_first_seam_nonzero_coefficients=mismatch)


def base_and_strips(model):
    valid=validate_polygon(model.polygons[0])
    base=[]
    for case in load("input/growth-v1.json")["levels"]:
        if int(case["id"][1:]) not in (2,3):
            continue
        patch=tuple(map(tuple,case["patch"]))
        _,ring=from_tiles(model,patch)
        assert ring==tuple(map(tuple,case["ring"])) and ball(ring)>0
        assert len(support(model,patch))==240*len(patch)
        base.append(dict(name=case["id"],tiles=len(patch),disk_radius=ball(ring)))
    for a,b in product("01",repeat=2):
        left,right=map(model.poly,strip(a+b))
        assert not polygon_overlap(left,right)["overlap"]
    boxes=[bounds(model.poly(t))[:2] for t in strip("01")]
    boxes[1]=tuple(x-4 for x in boxes[1])
    assert max(b for _,b in boxes)-min(a for a,_ in boxes)<8
    return dict(base=base,strip_pair_checks=4,strip_x_span=max(b for _,b in boxes)-min(a for a,_ in boxes))


def main():
    p=load("protocol-v1.json")
    assert p["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/k)==d for k,d in p["pins"].items())
    model=Model(load("input/exact-point-model-v1.json"))
    masks=signed_labels(model)
    certificate=load("data/symbolic-v1.json")["rows"]
    identity=[check_identity(model,masks,row) for row in certificate]
    paths={k:ordered(e) for k,e in masks.items()}
    transitions=check_local(paths)
    boundary=[]
    for kind in ("T","P"):
        guide=guides(model,kind)
        all_ends=[ends(paths,g) for g in guide]
        assert len({a for a,b in all_ends})==len(guide)
        successor=dict(all_ends)
        start=point=next(iter(successor))
        for _ in guide:
            point=successor.pop(point)
        assert point==start and not successor
        pairs=[corner(paths,a,b) for j,a in enumerate(guide) for b in guide[j+1:]]
        boundary.append(dict(kind=kind,pairs=pairs))
    turns={g for kind in ("T","P") for _,_,_,g,_ in world_sides(model,kind)}
    assert all((a*d-b*c)==1 for g in turns for (a,b),(c,d) in (model.groups[g],))
    assert all(norm(mat(model.groups[g],x))==norm(x) for g in turns for x in ((1,0),(0,1),(1,1)))
    for kind in ("T","P"):
        shifts=[row[-1] for row in children(model,kind)]+[row[-1] for row in world_sides(model,kind)]
        for pair in shifts:
            for term in pair:
                k=term if isinstance(term,Lin) else Lin(term)
                assert all(int(t)==t for t in (k.c,k.u,k.v))
    assert all(x+2*y<=3 for key,path in paths.items() if key[0]=="T" for x,y in path)
    raw=load("input/growth-v1.json")["levels"]
    shapes={r["id"]:set(map(tuple,r["patch"])) for r in raw}
    assert {model.action(6,t) for t in shapes["T1"]}<shapes["T3"]
    assert {model.action(6,t) for t in shapes["T3"]}<shapes["T5"]
    result=dict(status="CHECKED_GOLDEN_HEX_ALL_LEVEL_CERTIFICATE",induction_from=4,
                words=words_certificate(),identity=identity,local_path_transitions=transitions,
                topology=boundary,bases_and_strips=base_and_strips(model),
                disk_bound="length(p[2*n+1]) - 1",nested_odd_levels=True)
    save("data/plane-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
