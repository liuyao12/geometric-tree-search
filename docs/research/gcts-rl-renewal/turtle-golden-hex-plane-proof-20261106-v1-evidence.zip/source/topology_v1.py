"""Certify simple Golden Hex boundaries by finite path and corner checks."""

from collections import Counter
from fractions import Fraction
from itertools import combinations, pairwise, product
import json
from math import ceil, floor
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,load,mat,save
from golden_geometry_v1 import add,sub
from symbolic_v1 import H,K,L,M,PREFIX,STEP,Lin,scaled_vector,sides,signed_labels
from triangle_geometry_v1 import _segments_meet

U_MIN,V_MIN=16,27


def constant(x):
    x=x if isinstance(x,Lin) else Lin(x)
    assert x.u==x.v==0,x
    return x.c


def lower(x):
    x=x if isinstance(x,Lin) else Lin(x)
    assert x.u>=0 and x.v>=0,x
    return x.at(U_MIN,V_MIN)


def positive(x):
    return x.u>=0 and x.v>=0 and lower(x)>0


def cross(a,b):
    return a[0]*b[1]-a[1]*b[0]


def ordered(edges):
    if not edges:
        return ()
    outgoing=dict(edges)
    assert len(outgoing)==len(edges)
    start,=set(outgoing)-{v for _,v in edges}
    path=[start]
    while path[-1] in outgoing:
        path.append(outgoing.pop(path[-1]))
    assert not outgoing and len(set(path))==len(path)
    return tuple(path)


def check_two(first,second,shared=None):
    for (a,b),(c,d) in product(pairwise(first),pairwise(second)):
        overlap={a,b}&{c,d}
        if shared is not None and overlap=={shared}:
            p,=({a,b}-{shared})
            q,=({c,d}-{shared})
            u,v=sub(p,shared),sub(q,shared)
            assert cross(u,v)!=0 or u[0]*v[0]+u[1]*v[1]<0
        else:
            assert not _segments_meet(a,b,c,d),(a,b,c,d,shared)


def check_path(path):
    edges=list(pairwise(path))
    for (i,a),(j,b) in combinations(enumerate(edges),2):
        check_two(a,b,a[1] if j==i+1 else None)


def endpoints(role,position):
    if role=="D":
        front="01"+PREFIX
        end=PREFIX[::-1]+"10"
    else:
        front=PREFIX
        end=PREFIX[::-1]
    if position>=0:
        padded="^"+front
        return padded[position:position+3],min(position,3),3
    padded=end+"$"
    k=len(end)+position-1
    return padded[k:k+3],3,min(-position-1,3)


def fragment(paths,role,position):
    return paths[role,*endpoints(role,position)]


def check_local(paths):
    for path in paths.values():
        check_path(path)
        assert all(-4<=x<=1 for x,_ in path)
    transitions=0
    for role in ("T","H","D"):
        for bits in product("01",repeat=4):
            word="".join(bits)
            if "11" in word or "101" in word:
                continue
            a,b=(paths[role,word[i:i+3],3,3] for i in (0,1))
            shifted=tuple(add(p,STEP) for p in b)
            assert a and shifted and a[-1]==shifted[0]
            check_two(a,shifted,a[-1])
            transitions+=1
        for head in (True,False):
            indices=tuple(range(6)) if head else tuple(range(-6,0))
            boundary=[fragment(paths,role,i) for i in indices]
            if not head and role=="D":
                assert boundary[-2:]==[(),()]
                boundary=boundary[:-2]
            assert all(boundary)
            for a,b in pairwise(boundary):
                shifted=tuple(add(p,STEP) for p in b)
                assert a[-1]==shifted[0]
                check_two(a,shifted,a[-1])
                transitions+=1
    return transitions


def size(label):
    return {"h":L+M-2,"d":L+2}[label]


def guides(model,kind):
    return [dict(role=r,origin=o,matrix=model.groups[g],step=mat(model.groups[g],STEP),length=size(w))
            for r,w,g,o in sides(model,kind,0)]


def point(side,index,p):
    return add(add(side["origin"],scaled_vector(index,side["step"])),mat(side["matrix"],p))


def ends(paths,side):
    role=side["role"]
    last=-3 if role=="D" else -1
    return (point(side,0,fragment(paths,role,0)[0]),
            point(side,side["length"]+last,fragment(paths,role,last)[-1]))


def projections(paths,side,axis):
    values=[cross(mat(side["matrix"],p),axis) for k,path in paths.items() if k[0]==side["role"] for p in path]
    return min(values),max(values)


def candidates(paths,side,origin,margin):
    last=side["length"]-1
    base=0 if origin.u==origin.v==0 else last
    offset=constant(origin-base)
    indices=[]
    for k in range(ceil(offset+margin[0]),floor(offset+margin[1])+1):
        i=base+k
        if base==0 and k<0 or base!=0 and k>0:
            continue
        assert abs(k)<10 and lower(last)>abs(k)
        edges=fragment(paths,side["role"],k if base==0 else k-1)
        indices.append((k,tuple(point(side,i,p) for p in edges)))
    return indices


def corner(paths,a,b):
    da,db=a["step"],b["step"]
    gap=sub(b["origin"],a["origin"])
    determinant=cross(da,db)
    shared=set(ends(paths,a))&set(ends(paths,b))
    if not determinant:
        assert not shared
        ax,bx=(projections(paths,s,da) for s in (a,b))
        lo,hi=bx[0]-ax[1],bx[1]-ax[0]
        separation=cross(gap,da)
        assert positive(separation+lo) or positive(-separation-hi)
        return dict(kind="parallel",checks=1)
    common,=shared
    samples=[]
    for axis in (db,da):
        ax,bx=(projections(paths,s,axis) for s in (a,b))
        margin=sorted(Fraction(q,determinant) for q in (bx[0]-ax[1],bx[1]-ax[0]))
        index=cross(gap,axis)*Fraction(1,determinant)
        samples.append((index,margin))
    left=candidates(paths,a,*samples[0])
    right=candidates(paths,b,*samples[1])
    checks=0
    for (_,p),(_,q) in product(left,right):
        x,y=(tuple(tuple(map(constant,sub(v,common))) for v in path) for path in (p,q))
        check_two(x,y,(0,0))
        checks+=1
    return dict(kind="corner",checks=checks,offsets=[list(map(lambda z:z[0],x)) for x in (left,right)])


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    paths={k:ordered(v) for k,v in signed_labels(model).items()}
    local=check_local(paths)
    rows=[]
    for kind in ("T","P"):
        shape=guides(model,kind)
        joints=[ends(paths,s) for s in shape]
        assert len({a for a,_ in joints})==len(shape)
        outgoing=dict(joints)
        v=start=next(iter(outgoing))
        for _ in shape:
            v=outgoing.pop(v)
        assert v==start and not outgoing
        cases=[corner(paths,a,b) for a,b in combinations(shape,2)]
        row=dict(kind=kind,sides=len(shape),cases=cases)
        print(json.dumps(row,sort_keys=True),flush=True)
        rows.append(row)
    save("data/topology-v1.json",dict(status="CHECKED_ALL_LEVEL_SIMPLE_BOUNDARIES",local_transitions=local,rows=rows))


if __name__=="__main__":
    main()
