"""Search for coefficientwise cancellation of parameterized Golden Hex seams."""

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from cluster_v1 import Model, load, mat, save
from golden_geometry_v1 import add, strip, sub, words
from golden_growth_v1 import primitive, p_children, t_children
from golden_seams_v1 import receptors

STEP = (4, -2)
AXES = ((4,-2),(2,2),(2,-4))
TRIPLES = ("000", "001", "010", "100")
CAP = 4
PREFIX = "0010001001000"


@dataclass(frozen=True, order=True)
class Lin:
    c: Fraction = 0
    u: Fraction = 0
    v: Fraction = 0

    def __add__(self, x):
        x = x if isinstance(x, Lin) else Lin(x)
        return Lin(self.c+x.c, self.u+x.u, self.v+x.v)

    __radd__ = __add__

    def __mul__(self, k):
        return Lin(self.c*k, self.u*k, self.v*k)

    __rmul__ = __mul__

    def __neg__(self):
        return self * -1

    def __sub__(self, x):
        return self + -x

    def __rsub__(self, x):
        return x + -self

    def at(self, u, v):
        return self.c+self.u*u+self.v*v


U, V = Lin(u=1), Lin(v=1)
L, M, K, H = 2*V+U+6, V+U+4, V+2, U+2


def xy(u, v):
    return u, (v-u)*Fraction(1, 2)


def word_options():
    w = (("V","1","0","U"),("U","0","1","V"))
    p = tuple(x+("0","1","V") for x in w)+tuple(("V","1","0")+x for x in w)
    h = tuple(a+("1","0")+b for a,b in product(p,w))+tuple(a+("0","1")+b for a,b in product(w,p))
    return {"w":w,"p":p,"h":tuple(dict.fromkeys(h)),
            "d":tuple(("0","1")+a+("1","0") for a in p),
            "s":tuple(a+("1","0") for a in p),
            "e":(("0","1","V","1","0"),),"u":(("U",),)}


def signed_labels(model):
    seed = {(r["role"],r["context"]):[tuple(map(tuple,e)) for e in r["edges"]]
            for r in load("input/seams-v1.json")["labels"]}
    masks = {}
    for row in load("input/growth-v1.json")["levels"]:
        n = int(row["id"][1:])
        if n > 3:
            continue
        actual = set(primitive(tuple(map(tuple,row["ring"]))))
        seen = set()
        for role,w,g,shift in receptors(model,row["id"][0],n,words(2*n+1)):
            got = set()
            ctx = "^"+w+"$"
            for i in range(len(w)):
                key = role,ctx[i:i+3],min(i,3),min(len(w)-1-i,3)
                off = (4*i,-2*i)
                value = []
                for a,b in seed[role,ctx[i:i+3]]:
                    edge = tuple(add(mat(model.groups[g],add(p,off)),shift) for p in (a,b))
                    if edge not in actual:
                        edge = edge[::-1]
                        a,b = b,a
                    assert edge in actual
                    if edge not in seen:
                        got.add(edge)
                        value.append((a,b))
                value = tuple(sorted(value))
                assert key not in masks or masks[key] == value
                masks[key] = value
            seen.update(got)
        assert seen == actual
    return masks


def prefix(token):
    return PREFIX if token in ("U","V") else token


def suffix(token):
    return PREFIX[::-1] if token in ("U","V") else token


def length(token):
    return {"U":U,"V":V}.get(token,Lin(1))


def kernel(model, masks, role, ctx, low=3, high=3):
    if role != "S":
        return masks[role,ctx,low,high]
    g,x,y = strip(ctx[1])[0]
    return tuple(primitive(tuple(add(p,(x,y)) for p in model.polygons[g])))


def edge_term(out, chunk, step, base, ctx, a, b, sign):
    start = add(base,a)
    d = sub(b,a)
    if d < (0,0):
        start = add(start,d)
        d = (-d[0],-d[1])
        sign = -sign
    out[chunk,step,start,ctx,d] += sign


def scaled_vector(k,v):
    return tuple(k*x for x in v)


def differences(out):
    total=Counter()
    for (chunk,step,start,ctx,d),coefficient in out.items():
        if not coefficient:
            continue
        work=[(start,coefficient)]
        if chunk.startswith("C"):
            assert step in AXES
            axes=tuple(s for s in AXES if s!=step)
            work.append((add(start,scaled_vector(length(chunk[1]),step)),-coefficient))
            chunk,step="",()
        else:
            axes=AXES
        for axis in axes:
            work.extend((add(p,axis),-v) for p,v in work[:])
        for p,v in work:
            total[chunk,step,p,ctx,d]+=v
    return {k:v for k,v in total.items() if v}


def ledger(model, masks, role, tokens, g, shift, sign):
    out = Counter()
    matrix = model.groups[g]
    step = mat(matrix,STEP)
    cursor = Lin()
    total = sum(map(length,tokens), Lin())
    for j,token in enumerate(tokens):
        if token in ("U","V"):
            m = length(token)
            reverse = step < (0,0)
            origin = cursor+m-1 if reverse else cursor
            delta = tuple(-x for x in step) if reverse else step
            base = add(shift,tuple(origin*x for x in step))
            oriented={k:Counter(kernel(model,masks,role,k[::-1] if reverse else k)) for k in TRIPLES}
            for shift_index,ctx in ((None,"000"),(-1,"100"),(0,"010"),(1,"001")):
                coefficients=oriented[ctx].copy()
                if shift_index is not None:
                    coefficients.subtract(oriented["000"])
                adjusted=base if shift_index is None else add(base,scaled_vector(-shift_index,delta))
                chunk="C"+token if shift_index is None else token
                low_skip=CAP if shift_index is None else CAP+shift_index
                high_skip=CAP if shift_index is None else CAP-shift_index
                for (a,b),weight in coefficients.items():
                    if not weight:
                        continue
                    a,b=mat(matrix,a),mat(matrix,b)
                    edge_term(out,chunk,delta,adjusted,"",a,b,sign*weight)
                    fixed=[Lin(i) for i in range(low_skip)
                           if shift_index is None or PREFIX[i]=="1"]
                    fixed.extend(m-i-1 for i in range(high_skip)
                                 if shift_index is None or PREFIX[i]=="1")
                    for i in fixed:
                        edge_term(out,"",(),add(adjusted,scaled_vector(i,delta)),"",a,b,-sign*weight)
            head = prefix(token)[:CAP+1]
            tail = suffix(token)[-(CAP+1):]
            before = suffix(tokens[j-1])[-1] if j else "^"
            after = prefix(tokens[j+1])[0] if j+1<len(tokens) else "$"
            fixed = [(Lin(i),(before+head)[i:i+3]) for i in range(CAP)]
            fixed += [(m-CAP+i,(tail+after)[i:i+3]) for i in range(CAP)]
        else:
            before = suffix(tokens[j-1])[-1] if j else "^"
            after = prefix(tokens[j+1])[0] if j+1<len(tokens) else "$"
            fixed = [(Lin(),before+token+after)]
        for i,ctx in fixed:
            index = cursor+i
            behind = total-index-1
            low = min(3,int(index.c)) if index.u==index.v==0 else 3
            high = min(3,int(behind.c)) if behind.u==behind.v==0 else 3
            base = add(shift,tuple(index*x for x in step))
            for a,b in kernel(model,masks,role,ctx,low,high):
                edge_term(out,"",(),base,"",mat(matrix,a),mat(matrix,b),sign)
        cursor += length(token)
    return differences(out)


def sides(model, kind, age):
    if kind == "S":
        return [("S","s",0,(0,0))]
    L0,K0 = (L,K) if age==0 else (K,V-U)
    if kind == "T":
        label = ("h","w","u")[age]
        n = (L+M-2,M-2,H-2)[age]
        start = (2*n-3,2)
        return [("T",label,model.compose[g,6],mat(model.groups[g],start)) for g in (0,3,4)]
    horizontal,diagonal = ("h","d") if age==0 else ("w","e")
    a,b = 5*L0-2*K0-7,3*L0-3
    d,e = -3*L0+2*K0+2,3*L0-K0-1
    return [("H",horizontal,0,xy(-a,-b)),("H",horizontal,6,xy(a,b)),
            ("D",diagonal,3,(d,e)),("D",diagonal,9,(-d,-e))]


def children(model,kind):
    level=4
    rows=t_children(model,level,L,H,xy) if kind=="T" else p_children(level,L,M,K,H,xy)
    return [(shape,level-n,turn,shift) for shape,n,turn,shift in rows]


def world_sides(model,kind):
    for role,label,g,shift in sides(model,kind,0):
        yield -1,role,label,g,shift
    for shape,age,turn,offset in children(model,kind):
        for role,label,g,shift in sides(model,shape,age):
            yield 1,role,label,model.compose[turn,g],add(mat(model.groups[turn],shift),offset)


def choose(variants):
    tables = defaultdict(dict)
    for i,group in enumerate(variants):
        for j,row in enumerate(group):
            for k,v in row.items():
                tables[k].setdefault(i,{})[j] = v
    stats = Counter()
    def solve(domains):
        stats["nodes"]+=1
        while True:
            changed=False
            for key,options in tables.items():
                sites=list(options)
                vals=[{options[i].get(j,0) for j in domains[i]} for i in sites]
                front=[{0}]
                back=[{0}]
                for v in vals:
                    front.append({a+b for a,b in product(front[-1],v)})
                if 0 not in front[-1]:
                    stats["contradictions"]+=1
                    return None
                for v in vals[::-1]:
                    back.append({a+b for a,b in product(back[-1],v)})
                for r,i in enumerate(sites):
                    support={-a-b for a,b in product(front[r],back[-r-2])}
                    new={j for j in domains[i] if options[i].get(j,0) in support}
                    assert new
                    if new!=domains[i]:
                        domains[i]=new
                        changed=True
            if not changed:
                break
        if all(len(d)==1 for d in domains):
            return [next(iter(d)) for d in domains]
        i=min((i for i,d in enumerate(domains) if len(d)>1),key=lambda i:len(domains[i]))
        for j in sorted(domains[i]):
            split=domains[:]
            split[i]={j}
            out=solve(split)
            if out is not None:
                return out
        return None
    result=solve([set(range(len(group))) for group in variants])
    return result,dict(stats),len(tables)


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    masks=signed_labels(model)
    options=word_options()
    for n in (4,5,6):
        seq=words(2*n+1)
        u,v=(seq[2*n-k][:-2] for k in (3,2))
        for kind, f in (("T",t_children),("P",p_children)):
            got=[(a,n-k,g,tuple(x.at(len(u),len(v)) if isinstance(x,Lin) else x for x in p))
                 for a,k,g,p in children(model,kind)]
            actual=f(model,n,len(seq[2*n]),len(seq[2*n-1])-len(seq[2*n-2])) if kind=="T" else f(
                n,*(len(seq[i]) for i in (2*n,2*n-1,2*n-2)),len(seq[2*n-1])-len(seq[2*n-2]))
            assert [(a,n if a=="S" else k,g,p) for a,k,g,p in got]==actual
    output=[]
    for kind in ("T","P"):
        items=list(world_sides(model,kind))
        domains=[]
        for sign,role,label,g,shift in items:
            domains.append([ledger(model,masks,role,tokens,g,shift,sign) for tokens in options[label]])
        solution, stats, terms=choose(domains)
        row=dict(kind=kind,sites=len(items),term_keys=terms,stats=stats,solution=solution)
        print(json.dumps(row,sort_keys=True),flush=True)
        if solution is not None:
            total=Counter()
            for group,i in zip(domains,solution,strict=True):
                total.update(group[i])
            assert not any(total.values())
            row["expansions"]=[options[label][i] for (_,_,label,_,_),i in zip(items,solution,strict=True)]
        output.append(row)
    save("data/symbolic-v1.json",dict(rows=output))


if __name__=="__main__":
    main()
