"""Check the untrusted word-decomposition choices with the fixed Wang palette."""

from collections import Counter,defaultdict
import gzip
from itertools import product
import json
from pathlib import Path
from random import Random
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model,load,save
import fixed_palette_v1 as wang
from ribbon_checker_v3 import verify
from symbolic_v1 import ledger,signed_labels,word_options,world_sides


def inputs_for(group,shape):
    start=2
    widths=[]
    ports=[]
    inputs=[dict(name="zero",value=0),dict(name="one",value=1)]
    for i,choices in enumerate(group):
        w=(len(choices)-1).bit_length()
        widths.append(w)
        ports.append(list(range(start,start+w)))
        inputs.extend(dict(name=f"{shape} side {i+1} choice bit {j+1}",value=None) for j in range(w))
        start+=w
    return inputs,widths,ports


def encode(choices,widths):
    return [0,1]+[(n>>j)&1 for n,w in zip(choices,widths,strict=True) for j in range(w)]


def compile_seams(options,shape):
    inputs,widths,ports=inputs_for(options,shape)
    b=wang.Builder(inputs)
    selectors=[tuple(b.word_eq(p,b.const_word(j,len(p))) for j in range(len(a)))
               for p,a in zip(ports,options,strict=True)]
    checks=[b.any(row) for row in selectors]
    terms=defaultdict(dict)
    for i,group in enumerate(options):
        for j,formula in enumerate(group):
            for k,v in formula.items():
                terms[k].setdefault(i,[0]*len(group))[j]=v
    signatures=set()
    for rows in terms.values():
        constant=0
        variables=[]
        for i,sequence in sorted(rows.items()):
            values=defaultdict(list)
            for j,x in enumerate(sequence):
                values[x].append(j)
            if len(values)==1:
                constant+=next(iter(values))
            else:
                variables.append((i,tuple((x,tuple(ids)) for x,ids in sorted(values.items()))))
        signatures.add((constant,tuple(variables)))
    for constant,signature in sorted(signatures):
        good=[]
        for combo in product(*(values for _,values in signature)):
            if constant+sum(value for value,_ in combo)==0:
                good.append(b.all(b.any(selectors[i][j] for j in ids)
                                  for (i,_),(_,ids) in zip(signature,combo,strict=True)))
        checks.append(b.any(good))
    return b.finish(b.all(checks)),widths,len(terms),len(signatures)


def directly(options,selection):
    out=Counter()
    for rows,j in zip(options,selection,strict=True):
        if j>=len(rows):
            return False
        out.update(rows[j])
    return not any(out.values())


def main():
    m=Model(load("input/exact-point-model-v1.json"))
    masks=signed_labels(m)
    words=word_options()
    certificates=load("data/symbolic-v1.json")["rows"]
    palette=wang.palette()
    rows=[]
    for row in certificates:
        kind=row["kind"]
        variants=[[ledger(m,masks,role,word,g,shift,sign) for word in words[label]]
                  for sign,role,label,g,shift in world_sides(m,kind)]
        choices=row["solution"]
        c,widths,terms,signatures=compile_seams(variants,kind)
        bits=encode(choices,widths)
        assert directly(variants,choices) and wang.evaluate(c,bits)[1]==1
        cert=wang.certificate(c,bits,palette)
        check=verify(c,cert,palette)
        assert check["status"]=="VERIFIED",check
        controls=set()
        for i,options in enumerate(variants):
            for code in range(1<<widths[i]):
                alt=choices[:]
                alt[i]=code
                if alt!=choices:
                    controls.add(tuple(alt))
        rng=Random(192031)
        for _ in range(100):
            controls.add(tuple(rng.randrange(len(v)) for v in variants))
        rejected=0
        for test in controls:
            agree=directly(variants,test)
            assert agree==bool(wang.evaluate(c,encode(test,widths))[1])
            rejected+=not agree
        assert rejected
        corrupt={**cert,"input_bits":cert["input_bits"][:]}
        corrupt["input_bits"][2]^=1
        assert verify(c,corrupt,palette)["status"]=="REJECTED"
        output=dict(kind=kind,bits=sum(widths),gates=len(c["gates"]),terms=terms,distinct_constraints=signatures,
                    controls=len(controls),rejected=rejected,wang=check,
                    certificate=f"data/wang-{kind.lower()}-v1.json.gz")
        with (ROOT/output["certificate"]).open("xb") as raw:
            with gzip.GzipFile(fileobj=raw,mode="wb",mtime=0,filename="") as stream:
                stream.write(wang.canonical(dict(circuit=c,certificate=cert)))
        print(json.dumps(output,sort_keys=True),flush=True)
        rows.append(output)
    save("data/wang-v1.json",dict(status="CHECKED_WANG_SEAM_CHOICES",rows=rows))


if __name__=="__main__":
    main()
