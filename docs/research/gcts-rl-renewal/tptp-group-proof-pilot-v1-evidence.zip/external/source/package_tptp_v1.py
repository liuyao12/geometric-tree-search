"""Package the external benchmark evidence and pinned fetch information."""
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[2]
STEM = "tptp-group-proof-pilot-v1"


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    folders = ("source", "external/source")
    scripts = sorted(str(path.relative_to(ROOT)) for folder in folders for path in (ROOT / folder).glob("*.py"))
    data = sorted(str(path.relative_to(ROOT)) for path in (ROOT / "external/data").glob("*.json"))
    notebook = f"external/report/{STEM}.html"
    paths = (*scripts, *data, "data/lifted-equality-policy-v1.json", "publication/render_v1.py",
             "publication/proof_views_v1.py", "publication/notebook-v1.html", "external/REPLAY.md", notebook)
    archive = ROOT / f"external/report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in paths:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            manifest[name] = pin(raw)
            entry = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            entry.external_attr = 0o100644 << 16
            bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    files = (archive, ROOT / notebook)
    result = dict(schema="TPTP-WANG-BENCHMARK-MANIFEST-v1", archive_entries=manifest,
                  assets={path.name: pin(path.read_bytes()) for path in files})
    (ROOT / f"external/report/{STEM}-manifest.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
