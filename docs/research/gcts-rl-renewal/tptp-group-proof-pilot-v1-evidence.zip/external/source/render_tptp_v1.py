"""Render the external benchmark and the decoded proof rows."""
from html import escape
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(ROOT / "publication"), str(ROOT / "source")]
from boundary_kernel_v1 import build
from proof_views_v1 import clause, explanation, formula, math, tile_svg
from render_v1 import table, windows


def read(name):
    return json.loads((HERE / "data" / name).read_text())


def source_name(line, source):
    if line["rule"] != "G" or not line["source"].startswith("formula"):
        return line
    head, clause_id = line["source"].split("-")
    i = int(head.removeprefix("formula")) - 1
    j = int(clause_id.removeprefix("clause")) - 1
    premises = [row["label"] for row in source["clauses"] if row["role"] != "negated_conjecture"]
    denied = [row["label"] for row in source["clauses"] if row["role"] == "negated_conjecture"]
    name = premises[i] if i < len(premises) else denied[j]
    return {**line, "source": name}


def proof_table(lines, source=None):
    return table(("Line", "Reading", "Clause"),
        [(i, explanation(source_name(line, source) if source else line), math(clause(line["clause"])))
         for i, line in enumerate(lines, 1)])


def display(value):
    return value.replace("_", " ").lower()


def main():
    sources = {row["id"]: row for row in read("results-v1.json")}
    support = {row["id"]: row for row in read("support-results-v1.json")}
    direct = {row["id"]: row for row in read("direct-cnf-v1.json") if row["arm"] == "direct_generous"}
    z3 = {row["id"]: row for row in read("z3-original-v1.json")}
    manifest = read("sources-v1.json")
    summary = []
    proofs = []
    for name, source in sources.items():
        link = manifest[name + ".p"]["url"]
        accepted = support[name]
        summary.append((f'<a href="{escape(link, quote=True)}">{name}</a>', len(source["clauses"]),
                        display(source["learned"]["status"]), display(direct[name]["status"]),
                        display(accepted["status"]), z3[name]["status"],
                        accepted.get("receipt", {}).get("records", "—")))
        if accepted["status"] != "PROVED":
            continue
        short = read(f"{name}-support-direct-v1.json")["lines"]
        full = read(f"{name}-support-logical-v1.json")["proof"]["lines"]
        proofs.append(f'<article><h3>{name}</h3><p>Goal {math(formula(source["source"]["goal"]))}</p>'
                      f'<details><summary>Direct derivation · {len(short)} lines</summary>'
                      f'{proof_table(short, source)}</details>'
                      f'<details><summary>Source-bound Wang records · {len(full)} lines</summary>'
                      f'{proof_table(full)}</details></article>')
    palette = {}
    cells, caption = windows(read("GRP009-1-support-wang-v1.json"), build().compile(), palette)[-1]
    defs = "".join(tile_svg(tile, i) for tile, i in palette.items())
    squares = "".join(f'<use href="#wang-{tile}" x="{36*(i%9)}" y="{36*(i//9)}"/>'
                      for i, tile in enumerate(cells))
    table_html = table(("Problem", "Input clauses", "Frozen policy", "Direct rewrite, larger cap",
                        "Goal support, larger cap", "Z3", "Checked records"), summary)
    head = (ROOT / "publication/notebook-v1.html").read_text().split("<body>", 1)[0]
    head = head.replace("Lifted equality search for Wang proofs", "First external group-theory pilot")
    html = f"""{head}<body><main>
<header><p class="kicker">GCTS research notebook · External benchmark pilot</p>
<h1>Two checked TPTP group-theory proofs</h1>
<p>The frozen equality policy reached its bounds on five published problems. Requiring inferences to involve the denied goal or its descendants yielded two proofs after direct clausal compilation.</p>
<nav><a href="#comparison">Benchmark</a><a href="#proof">Proofs</a><a href="#tiles">Wang squares</a><a href="#replay">Replay</a></nav></header>
<section id="comparison"><h2>Compare the frozen and goal-directed searches</h2>
<p>The source is TPTP v9.3.1. The reader translates the five CNF problems and their included axioms into universally closed formulas. The negated conjecture clauses are conjoined for refutation. The translation preserves the clauses, and the solver receives their formulas and recorded search settings.</p>
<p>The direct-clause arms both allow 120,000 inference offers and 30,000 stored clauses. They use the same clause priority and rewrite orientation. The goal-directed arm filters resolution and rewrite pairs. The frozen arm uses its original limits and definitional compiler.</p>
{table_html}
<p>Z3 4.15.4 checks the universal closures of the original clauses and included axioms. It reaches the ten-second timeout on the lattice-ordered case. A search arm that stops without a refutation has failed to prove the request within its rules and limits.</p>
</section>
<section id="proof"><h2>Read the derivations</h2>
<p>The direct proof is produced by search. The expanded proof derives each used direct clause from the original formula boundary with ground instances and resolution. The same Wang checker accepts the expanded record and rejects it when the submitted goal changes.</p>
{"".join(proofs)}</section>
<section id="tiles"><h2>Inspect a fixed-palette witness</h2>
<div class="grid"><figure><svg viewBox="0 0 324 180" role="img" aria-label="Five rows of Wang squares for the final left-inverse proof line">
<defs>{defs}</defs>{squares}</svg><figcaption>{caption}</figcaption></figure>
<p>These are the final five transitions for line 72 of the left-inverse uniqueness proof. The outlined squares carry the verifier head. The edge colors encode exact matching labels.</p></div></section>
<section id="replay"><h2>Reproduce the benchmark</h2>
<p>Extract the evidence archive and follow <code>external/REPLAY.md</code>. Each proof records its source formulas and independently checked Wang boundary.</p>
<p><a href="tptp-group-proof-pilot-v1-evidence.zip">Source and evidence archive</a> · <a href="tptp-group-proof-pilot-v1-manifest.json">File hashes</a> · <a href="https://tptp-manual.tptp.org/home">TPTP benchmark guidance</a></p>
</section></main></body></html>"""
    (HERE / "report/tptp-group-proof-pilot-v1.html").write_text(html)


if __name__ == "__main__":
    main()
