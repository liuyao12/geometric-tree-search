"""Reproduce the direct-clause ablation and independent Z3 control."""
import argparse
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path[:0] = [str(HERE / "source"), str(ROOT / "source")]
from front_v1 import clausify
from lifted_equality_study_v1 import make_prover
from lifted_equality_v1 import EqualityProver
from lifted_prover_v1 import Prover
from tptp_cnf_v1 import CNF
from tptp_pilot_v1 import PROBLEMS, write


def direct():
    results = []
    for name in PROBLEMS:
        source = CNF(HERE / "input").source(name + ".p")
        normal, _ = clausify(source, 1024)
        arms = (
            ("direct_axioms", Prover(source, normal=normal, offer_cap=12_000, node_cap=3_000)),
            ("direct_rewrite", make_prover(source, normal, bias=24)),
            ("direct_generous", EqualityProver(source, normal=normal, goal_bias=24,
                                                offer_cap=120_000, node_cap=30_000)),
        )
        for arm, prover in arms:
            status, root = prover.run()
            assert root is None
            results.append(dict(id=name, arm=arm, status=status, offers=prover.counts["offers"],
                                nodes=len(prover.nodes)))
    write("direct-cnf-v1.json", results)


def conventional(vendor):
    sys.path.insert(0, str(vendor))
    from z3_control_v1 import Language, z3
    assert z3.get_version() == (4, 15, 4, 0)
    results = []
    inputs = {}
    for name in PROBLEMS:
        parser = CNF(HERE / "input")
        source = parser.source(name + ".p")
        language = Language(source)
        solver = z3.Solver()
        solver.set(timeout=10_000, random_seed=1)
        solver.add(*(language.formula(row["formula"]) for row in parser.rows))
        inputs[name] = solver.sexpr()
        status = str(solver.check())
        assert status in ("unsat", "unknown")
        results.append(dict(id=name, status=status, reason=solver.reason_unknown() if status == "unknown" else None))
    write("z3-original-v1.json", results)
    write("z3-inputs-v1.json", inputs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--z3", type=Path)
    args = parser.parse_args()
    direct()
    if args.z3:
        conventional(args.z3)


if __name__ == "__main__":
    main()
