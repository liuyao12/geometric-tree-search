# Replay the external TPTP pilot

Run these commands from the parent lifted equality study directory. Use CPython 3.12 and install the pinned Z3 package in a separate vendor directory.

~~~sh
python3.12 -I -S -B external/source/fetch_tptp_v1.py
python3.12 -I -S -B external/source/tptp_pilot_v1.py
python3.12 -I -S -B external/source/tptp_controls_v1.py --z3 /path/to/vendor
python3.12 -I -S -B external/source/tptp_transport_v1.py
python3.12 -I -S -B external/source/render_tptp_v1.py
~~~

The archive retains official source URLs and hashes under `external/data`. The fetch command checks the TPTP v9.3.1 inputs before writing them into `external/input`. The control uses Z3 4.15.4. The frozen policy is in the parent study’s `data/lifted-equality-policy-v1.json`. The transport script uses the established first-order source checker and fixed Wang palette.
