"""Replay one pinned phase in a clean directory without changing the archive."""

import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
PHASES = {
    "lifted": ("lifted-protocol-v1.json", "lifted_experiment_v1.py", True),
    "schematic": ("schematic-protocol-v1.json", "schematic_experiment_v1.py", False),
    "peano": ("peano-lift-protocol-v1.json", "peano_lift_v1.py", False),
    "demand": ("demand-protocol-v1.json", "demand_experiment_v1.py", False),
    "model": ("model-ground-protocol-v1.json", "model_ground_v1.py", False),
    "fair": ("fair-window-protocol-v1.json", "fair_window_v1.py", False),
}


def main():
    phase, destination, *dependencies = sys.argv[1:]
    protocol, source, needs_dependency = PHASES[phase]
    assert len(dependencies) == int(needs_dependency)
    target = Path(destination).resolve() / phase
    target.mkdir(parents=True)
    (target / "data").mkdir()
    previous = phase in {"demand","model","fair"}
    config = ROOT / "prior/demand-pilot" / protocol if previous else ROOT / protocol
    spec = json.loads(config.read_bytes())
    for name in (protocol, *spec["pins"]):
        child = Path(name)
        assert not child.is_absolute() and ".." not in child.parts
        (target / child).parent.mkdir(parents=True, exist_ok=True)
        archived = ROOT / child
        if name == protocol:
            archived = config
        elif previous and child.parts[0] == "prior":
            archived = ROOT / "prior/demand-inputs" / Path(*child.parts[1:])
        shutil.copyfile(archived, target / child)
    subprocess.run([sys.executable, "-I", "-S", "-B", str(target / "source" / source),
                    *[str(Path(p).resolve()) for p in dependencies]], cwd=target, check=True)


if __name__ == "__main__":
    main()
