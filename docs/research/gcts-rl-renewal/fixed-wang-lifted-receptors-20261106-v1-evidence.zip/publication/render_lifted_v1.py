"""Publish the typed recipe experiments and automatic grounding pilot."""

from html import escape
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from shared_reader_v1 import ROOT,STYLE,clause,load,math,panel,table,term,title

STEM="fixed-wang-lifted-receptors-20261106-v1"
OLD="fixed-wang-admission-policy-20261106-v1.html"


def name(identifier):
    labels={"family-chain-6":"Family chain, six links","family-branch-3":"Family branch, three layers",
            "family-branch-5":"Family branch, five layers","incidence-branch-2":"Incidence, two choices",
            "incidence-branch-3":"Incidence, three choices","peano-successor-injectivity-3":"Three successors",
            "peano-successor-injectivity-4":"Four successors","agatha-vampire-guide":"Agatha",
            "peano-nonzero-successor":"Peano nonzero successor","hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
            "tptp-tutorial-capital":"TPTP capital","tptp-tutorial-family":"TPTP family"}
    base=identifier.removesuffix("-control")
    return labels.get(base,base)+(" control" if identifier!=base else "")


def symbolic(row):
    def rename(t):
        if isinstance(t,str):
            return "?v"+t.removeprefix("?p")
        return [t[0],*(rename(x) for x in t[1:])]
    atoms=[rename(a) for _,a in row]
    return math(clause([i if sign else -i for i,(sign,_) in enumerate(row,1)],atoms))


def receiver_diagram(recipe):
    shapes=[]
    count=len(recipe["leaves"])
    for i in range(count):
        x=170+i*235
        shapes.append(f'<path d="M{x} 54 L286 106" stroke="#66748c" fill="none"></path>'
                      f'<rect x="{x-76}" y="20" width="152" height="34" rx="5" fill="#d8e9df"></rect>'
                      f'<text x="{x}" y="42" text-anchor="middle">Receptor {i+1}</text>')
    chart=('<svg class="attachment" viewBox="0 0 570 155" role="img" aria-labelledby="attach-title">'
           '<title id="attach-title">Two complete source clauses attach to a shared resolution recipe</title>'
           + "".join(shapes) + '<rect x="188" y="105" width="196" height="33" rx="5" fill="#dddff2"></rect>'
           '<text x="286" y="127" text-anchor="middle">Checked output</text></svg>')
    interfaces="".join(f'<li><div class="scroll clause">{symbolic(row)}</div></li>' for row in recipe["leaves"])
    return chart+f'<ol>{interfaces}</ol><div class="scroll clause">{symbolic(recipe["steps"][-1][3])}</div>'


def main():
    lifted=load("data/lifted-v1.json")
    aligned={r["id"]:r for r in load("data/schematic-v1.json")}
    peano=load("data/peano-lift-v1.json")
    demand=load("prior/demand-pilot/demand-v1.json")
    model=load("prior/demand-pilot/model-ground-v1.json")
    fair=load("prior/demand-pilot/fair-window-v1.json")
    qualification=load("prior/demand-pilot/demand-qualification-v1.json")
    agatha=load("prior/demand-inputs/agatha-v1.json")["source"]
    recipients={r["id"]:r for r in lifted["cases"]}
    peano_cases={r["id"]:r for r in peano["cases"]}
    panels=[]
    dn=peano["donor"]["id"]
    panels.append((dn,panel(dict(id=dn,proof=peano["donor_proof"]),peano["donor"],peano["donor_rectangle_file"],
                            "Ground search discovered this donor proof. Its first resolution links two instances of the successor injectivity axiom.")))
    ar=peano_cases["peano-successor-injectivity-4"]
    pn=ar["id"]
    run=next(r for r in ar["results"] if r["mode"]=="demand")
    panels.append((pn,panel(dict(id=pn,**run),ar["source"],run["rectangle_file"],
                            "The receiver used two imported outputs from the learned arithmetic recipes. Every selected recipe expands to its original premises.")))
    for n,mode,method in (
            ("incidence-branch-2","eager","The eager arm used four lifted conclusions in this proof. The hypotheses contain only symbolic incidence and equality."),
            ("family-branch-5","demand","The model-triggered arm used thirteen lifted conclusions in this proof.")):
        chosen=next(r for r in recipients[n]["results"] if r["mode"]==mode)
        panels.append((n,panel(dict(id=n,**chosen),recipients[n]["source"],chosen["rectangle_file"],method)))
    ag=next(r for r in demand if r["id"]=="agatha-vampire-guide" and r["depth"]==1)
    panels.append((ag["id"],panel(ag,agatha,"prior/demand-pilot/"+Path(ag["rectangle_file"]).name,
                                 "The unit agenda requested source instances as needed and found this proof at term depth one.")))
    menu="".join(f'<option value="{n}">{escape(title(n))}</option>' for n,_ in panels)
    macro=peano["recipes"][0]
    assert len(macro["leaves"])==2
    figure=receiver_diagram(macro)
    binding_rows=[]
    for offer in run["used"]:
        pairs=", ".join(math(term("?v"+v.removeprefix("?p"))+r"\mapsto "+term(t)) for v,t in offer["binding"])
        binding_rows.append(f'<li><div class="scroll clause">{pairs}</div></li>')
    placements=[]
    outcomes=[]
    for case in lifted["cases"]:
        n=case["id"]
        x=aligned[n]
        assert x["comparison"]["missing"]==0
        placements.append([name(n),case["fixed"]["placements"],case["lifted"]["placements"],
                           case["lifted"].get("term_probes",0),x["counts"].get("unification_probes",0),
                           x["counts"].get("symbolic_alignments",0),x["counts"].get("bindings",0)])
        for r in case["results"]:
            if r["mode"]=="fixed":
                continue
            outcomes.append([name(n),r["mode"],r["status"],r["admitted"],r["activated"],
                             r["counts"].get("decisions",0),len(r["cuts"]),len(r.get("used_outputs",()))])
    arith=[[name(x["id"]),r["mode"],r["status"],x["matching"]["placements"],r["admitted"],
            r["counts"].get("decisions",0),len(r.get("used",()))] for x in peano["cases"] for r in x["results"]]
    unit=[[name(r["id"]),r["depth"],r["status"],r["counts"]["admitted_instances"],r["full"]["admitted"],
           r["counts"].get("bindings",0)] for r in demand]
    candidate=[[name(r["id"]),r["depth"],r["status"],r["admitted"],r["full"],len(r["rounds"]),len(r["cuts"])]
               for r in model]
    schedule=[[name(r["id"]),", ".join(f'{a["depth"]} {a["status"].lower().replace("_"," ")}'
                                       for a in r["attempts"]),
               r["found"]["depth"] if r["found"] else "—"] for r in fair]
    assert qualification["status"]=="PASS"
    html=f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Typed receptors for reusable Wang proof fragments</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.proof-table{{table-layout:fixed}}.proof-table tr>:first-child{{width:3.15rem}}
.clause{{font-size:1.04rem;margin-bottom:.35rem}}.proof-table .strip{{overflow:auto}}
.attachment{{display:block;width:100%;max-width:620px;border:1px solid #ced9d1;background:#f8f8f3}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;overflow:auto;background:#e5eee6;padding:.7rem}}
figure{{margin-inline:0}}
</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · Typed receptors and on-demand grounding · November 2026</p>
<h1>Typed receptors for reusable Wang proof fragments</h1>
<p>A discovered proof can supply a recipe with typed term parameters. New clauses can bind those parameters, including to nested terms. The final checker sees every original source premise and primitive resolution.</p>
<nav aria-label="On this page"><a href="#reader">Proof lines</a><a href="#recipe">Inspect a recipe</a><a href="#transfer">Transfer controls</a>
<a href="#grounding">Automatic grounding</a><a href="#evidence">Evidence</a></nav>
<p><a href="{OLD}">Previous notebook on lemma admission and atom cuts</a></p></header>
<section id="reader"><h2>Read the checked derivations</h2>
<p>Choose Peano arithmetic, Hilbert geometry or one of the quantified logic examples. The formula and explanation give the proof line. Expand the row to see its Wang squares in placement order. The checker wires the discovered parent links and checks the source instances and resolution values.</p>
<p><label>Statement <select id="case-menu">{menu}</select></label></p>{''.join(p for _,p in panels)}</section>
<section id="recipe"><h2>One recipe, several bindings</h2>
<p>The arithmetic donor asks whether applying successor twice preserves injectivity. The search found a proof and lifted its first resolution to the recipe below. Its two free parameters have type {math(r"\mathrm{Nat}")}. The green inputs represent complete source-clause receptors. The output follows by one resolution.</p>
<figure>{figure}</figure>
<p>The four-successor receiver used the following bindings among its imported conclusions. The same parameter binds consistently across all receptors and pivots. In a separate check, a point failed to unify with a line, and a parameter failed to unify with a successor of itself.</p>
<ul>{''.join(binding_rows)}</ul>
{table(["Statement","Arm","Outcome","Placements","Admitted clauses","Decisions","Used outputs"],arith)}</section>
<section id="transfer"><h2>Join source schemata before enumerating terms</h2>
<p>Eight recipes came from the archived family and incidence derivations. Keeping donor constants fixed yielded no placements in these fresh sources. Replacing them with typed parameters made it possible to match the new clauses. Each grounded recipe still had to match all its premises and replay every pivot. Removing a required receiver clause or changing a pivot made the affected recipe fail its check. <a href="https://tptp.org/UserDocs/TPTPWorldTutorial/LogicFOF.html">TPTP family donor</a></p>
<p>The ground-first matcher builds the finite clause bank before looking for placements. The schematic matcher first unifies complete source clauses, then instantiates the remaining parameters. It reproduced every placement on this bank. The exhaustive bank was built afterward for the independent comparison.</p>
{table(["Statement","Fixed constants","Typed placements","Ground term probes","Unification probes","Schematic alignments","Bindings tried"],placements)}
<p>The cold arm adds source instances falsified by the current model. Eager adds the checked library up front. Model-triggered adds a small batch of checked outputs falsified by the current model. Shuffle offers the same batch quota from a fixed random ordering. Proof replay first treats imported outputs as opaque, then expands the ones reached by the final derivation.</p>
{table(["Statement","Arm","Outcome","Admitted source clauses","Activated lemmas","Decisions","Cuts","Imported outputs used"],outcomes)}
<p>The family branch and Hilbert branch positives require branching in the full ground control. Eager loading generally used fewer decisions. Model-triggered loading activated fewer recipes. The counters separate matcher work and solver decisions.</p></section>
<section id="grounding"><h2>Find the term depth and source instances</h2>
<p>The unit agenda asks for a source instance when known units can eliminate all but one of its literals. The comparison counts distinct non-tautological clauses in the full ground bank. The matcher agreed with exhaustive enumeration on {qualification["typed_banks"]} small typed banks and {qualification["models"]} candidate models.</p>
{table(["Statement","Term depth","Unit outcome","Instances admitted","Full non-tautological clauses","Binding probes"],unit)}
<p>The model-driven search adds instances that falsify a candidate model of the current bank. The full-column count here includes tautological clauses. A ground model in a particular term window is a statement about that finite window. At depth one, the Agatha refutation used a small fraction of the available ground clauses. <a href="https://vprover.github.io/vampireGuide/docs/tutorial/intro/#example-who-killed-agatha-puz0011">Vampire guide example</a></p>
{table(["Statement","Depth","Outcome","Admitted clauses","Full clauses","Rounds","Cuts"],candidate)}
<p>One diagonal schedule tried the same depths and resource multipliers for every source. It discovered six refutations. Two controls had finite models throughout the tested windows. The earlier Peano and TPTP capital derivations also have checked Wang rectangles in the archive.</p>
{table(["Statement","Windows tried in order","First refuting depth"],schedule)}</section>
<section id="evidence"><h2>Replay the experiments</h2>
<ul><li><a href="{STEM}-results.json">Results summary</a></li><li><a href="{STEM}-evidence.zip">Full source, protocols, recipes, logs and Wang rectangles</a></li>
<li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li></ul>
<p>The replay helper copies each phase's pinned inputs into a fresh subdirectory. The archived demand pilot includes the typed matcher qualification and the depth schedule.</p>
<pre><code>python3.12 -I -S -B publication/replay_phase_v1.py lifted /tmp/wang-receptors /tmp/wang-pysat
python3.12 -I -S -B publication/replay_phase_v1.py schematic /tmp/wang-receptors
python3.12 -I -S -B publication/replay_phase_v1.py peano /tmp/wang-receptors
python3.12 -I -S -B publication/replay_phase_v1.py demand /tmp/wang-receptors
python3.12 -I -S -B publication/replay_phase_v1.py fair /tmp/wang-receptors</code></pre></section>
</main><script>
const menu=document.getElementById("case-menu");
function choose(){{for(const p of document.querySelectorAll(".proof[id^=case-]")) p.hidden=p.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""
    result=dict(status="CHECKED_WANG_TYPED_RECEPTORS",readers=[n for n,_ in panels],placements=placements,
                recipes=len(lifted["recipes"]),outcomes=outcomes,arithmetic=arith,
                demand=unit,models=candidate,schedule=schedule,qualification=qualification)
    with (ROOT/"report"/(STEM+".html")).open("x") as stream:
        stream.write(html)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as stream:
        stream.write(json.dumps(result,indent=2,sort_keys=True)+"\n")


if __name__=="__main__":
    main()
