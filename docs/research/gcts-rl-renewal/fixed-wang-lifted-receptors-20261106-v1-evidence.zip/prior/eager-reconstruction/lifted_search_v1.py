"""Search with checked lifted recipes and replay only their source derivations."""

from collections import Counter
import random
import time

from backjump_v1 import BoundarySearch
from ground_control_v1 import Derivation
from model_ground_v1 import Instantiator
from propagated_cuts_v1 import Replay
from serial_blocks_v1 import prop


def priority(o):
    return len(o.result),len(o.steps),o.result,o.leaves,o.recipe


def run(schemas,terms,atoms,offers,mode,plan):
    source={}
    active={}
    cuts=[]
    counts=Counter()
    turns=[]
    models=None
    status="BOUNDED"
    by_head={}
    for o in sorted(offers,key=priority):
        by_head.setdefault(o.result,o)
    candidates=list(by_head.values())
    if mode=="shuffle":
        random.Random(plan["shuffle_seed"]).shuffle(candidates)
    if mode=="eager":
        active={o.result:o for o in candidates}
    start=time.monotonic()
    fields=[dict(name=a[0]) for a in atoms]
    for _ in range(plan["rounds"]):
        primitive=[tuple(prop.literals(r)) for r in source]
        cnf=primitive+list(active)+cuts
        step=BoundarySearch(cnf,len(atoms),len(atoms),plan["sat"],"activity",fields)
        result,bits=step.run()
        counts.update(step.stats)
        audit=Replay(primitive+list(active)+cuts)
        for c in step.ordered:
            assert audit.refute(c)
            audit.add(c)
        cuts.extend(step.ordered)
        if result=="UNSAT":
            status="REFUTED"
            break
        if result=="BOUNDED":
            break
        check=Instantiator(schemas,terms,atoms,bits,plan["probes"])
        additions=check.find(source,plan["source_batch"])
        counts["source_probes"]+=check.probes
        if not additions:
            if not check.bounded:
                status="GROUND_MODEL"
                models=bits
            break
        chosen=[]
        if mode in {"demand","shuffle"}:
            truth={i if bit else -i for i,bit in enumerate(bits,1)}
            for offer in candidates:
                if offer.result in active:
                    continue
                counts["recipe_checks"]+=1
                if mode=="shuffle" or not truth.intersection(offer.result):
                    chosen.append(offer)
                if len(chosen)==plan["lemma_batch"]:
                    break
            active.update((o.result,o) for o in chosen)
        turns.append(dict(source=len(additions),new_recipes=len(chosen),cuts=len(step.ordered)))
        source.update(additions)
    return dict(status=status,counts=dict(counts),cuts=cuts,turns=turns,seconds=time.monotonic()-start,
                source=source,active=list(active.values()),model=models)


def expand(run,full):
    source=run["source"].copy()
    for o in run["active"]:
        for r in o.leaves:
            m=prop.mask(r)
            source.setdefault(m,full[m])
    d=Derivation(source)
    annotations={}
    root_by_placement={}
    for o in run["active"]:
        nodes=[d.known[frozenset(r)] for r in o.leaves]
        for a,b,p,row in o.steps:
            k=len(d.clauses)
            i=d.add_resolution(nodes[a],nodes[b],p)
            assert d.clauses[i]==frozenset(row)
            if i==k:
                annotations[i]=o
            nodes.append(i)
        root_by_placement[nodes[-1]]=o
    for cut in run["cuts"]:
        i=d.refute(frozenset(cut))
        assert i is not None and d.clauses[i]<=frozenset(cut)
    empty=d.refute(frozenset())
    assert empty is not None
    used=set()
    pending=[empty]
    while pending:
        i=pending.pop()
        if i in used:
            continue
        used.add(i)
        if i in d.steps:
            pending.extend(d.steps[i][:2])
    return d.support(empty,source),{annotations[i] for i in used if i in annotations}, {
        root_by_placement[i] for i in used if i in root_by_placement and i in annotations}
