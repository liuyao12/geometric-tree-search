"""Render checked formulas, rewrite markings and Wang square windows."""
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "publication")]
from boundary_kernel_v1 import build
from proof_views_v1 import clause, explanation, formula, frame_window, math, symbol, tile_svg

STEM = "wang-lifted-equality-20261106-v1"


def read(path):
    return json.loads((ROOT / path).read_text())


def label(name):
    return name.replace("peano", "Peano").replace("hilbert", "Hilbert").replace("-", " ")


def table(headers, rows):
    head = "".join(f'<th scope="col">{h}</th>' for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def status(value):
    return value.replace("_", " ").lower()


def term_tree(term, marks, path=()):
    name = term if isinstance(term, str) else term[0]
    children = "" if isinstance(term, str) or len(term) == 1 else (
        "<ul>" + "".join(term_tree(child, marks, (*path, i)) for i, child in enumerate(term[1:])) + "</ul>")
    marking = marks.get(path, "")
    return f'<li><span class="term {marking}">{math(symbol(name))}</span>{children}</li>'


def witnesses(policy):
    panels = []
    for witness in policy["witnesses"]:
        tag, *parts = witness["mark"]
        if tag == "rigid":
            path = tuple(parts[0])
            marks = ({path: "clash"}, {path: "clash"})
            title = "Rigid clash at one address"
        else:
            side, p, q, tail = parts
            marks = [{tuple(p): "alias", tuple(q): "alias"},
                     {tuple(p + tail): "clash", tuple(q + tail): "clash"}]
            if side:
                marks.reverse()
            title = "Repeated variable at two addresses"
        trees = "".join(f"<div><strong>{name}</strong><ul>{term_tree(witness[key], m)}</ul></div>"
                        for name, key, m in zip(("Equation term", "Candidate term"), ("left", "right"), marks, strict=True))
        panels.append(f'<div class="witness"><h3>{title}</h3><div class="grid">{trees}</div></div>')
    return '<div class="grid">' + "".join(panels) + "</div>"


def proof_view(row, bundle):
    source, name = row["source"], row["id"]
    hypotheses = "<ol>" + "".join(f"<li>{math(formula(x))}</li>" for x in source["premises"]) + "</ol>"
    lines = []
    for i, (line, call) in enumerate(zip(bundle["proof"]["lines"], bundle["calls"], strict=True), 1):
        record = bundle["records"][call["fragment"]]
        text = escape(record["prefix"] + "\n" + record["word"])
        view = (f'<button type="button" data-case="{name}" data-line="{i}">See tiles</button>'
                if "full_wang" in row else "")
        detail = f"{view}<details><summary>Boundary record</summary><code>{text}</code></details>"
        lines.append((i, explanation(line), math(clause(line["clause"])), detail))
    lifted = row["learned"]["elaborations"].get("eq-rewrite", 0)
    return (f'<details class="proof" id="{name}"><summary>{label(name)} · {len(lines)} lines</summary>'
            f'<p>Goal {math(formula(source["goal"]))}</p><p>Lifted rewrite steps in the winning derivation {lifted}.</p>'
            f'<details><summary>Original premises</summary>{hypotheses}</details>'
            f'{table(("Line", "Reading", "Clause", "Evidence"), lines)}</details>')


def windows(bundle, machine, palette):
    assert bundle["machine_sha256"] == machine.digest()
    result = []
    for call in bundle["calls"]:
        trace = bundle["traces"][call["fragment"]]
        frame = dict(prefix=trace["prefix"], word=trace["word"], padding=0, trace=trace["fragment"])
        time = trace["steps"] - 5
        active, first = frame_window(machine, frame, time, trace["head"])
        tiles = [palette.setdefault(t, len(palette)) for row in active for t in row]
        result.append((tiles, f"Actual Wang rows {time + 1:,}–{time + 5:,}, columns {first:,}–{first + 8:,}."))
    return result


def main():
    study = read("data/lifted-equality-experiment-v1.json")
    policy = read("data/lifted-equality-policy-v1.json")
    z3 = read("data/lifted-equality-z3-v1.json")["cases"]
    proofs, models = [], []
    machine = build().compile()
    palette, tiles = {}, {}
    arms = ("ground", "eager_axioms", "plain_rewrite", "learned")
    headers = ("Request", "Ground unit", "Lifted axioms", "Plain rewrite", "Learned priority and marks",
               "Rewrite unifications without / with marks", "Z3", "Checked lines")
    groups = {}
    for group in ("held_out", "development"):
        summary = []
        for row in study[group]:
            name = row["id"]
            bare, marked = (row[key]["counts"].get("rewrite_unifications", 0)
                            for key in ("same_bias_without_marks", "learned"))
            summary.append((label(name), *(status(row[k]["status"]) for k in arms), f"{bare:,} / {marked:,}",
                            z3[name]["status"], row["learned"].get("receipt", {}).get("records", "—")))
            if "countermodel" in row:
                model = escape(json.dumps(row["countermodel"], indent=2))
                models.append(f'<details><summary>{label(name)} finite model</summary><pre><code>{model}</code></pre></details>')
            if row["learned"]["status"] == "PROVED":
                proofs.append(proof_view(row, read(f"data/{name}-logical-v1.json")))
                if "full_wang" in row:
                    tiles[name] = windows(read(f"data/{name}-wang-v1.json"), machine, palette)
        groups[group] = table(headers, summary)
    positives = [r for r in study["held_out"] if r["expected"] == "PROVED"]
    biases = []
    for bias in sorted(policy["means"], key=int):
        runs = [r["fixed_biases"][bias] for r in positives]
        successes = [r for r in runs if r["status"] == "PROVED"]
        biases.append((bias, len(successes), sum(r["counts"].get("offers", 0) for r in runs),
                       f'{policy["means"][bias]:.3f}'))
    fields = dict(HELD=groups["held_out"], DEVELOPMENT=groups["development"], BIAS=policy["bias"],
        BIASES=table(("Bias", "Proofs", "Offers across all requests", "Mean training reward"), biases),
        MARKS=witnesses(policy),
        SKIPS=sum(r["learned"]["counts"].get("rewrite_mark_skips", 0) for r in study["held_out"]),
        PROOFS="".join(proofs), MODELS="".join(models),
        TILE_DEFS="".join(tile_svg(t, n) for t, n in palette.items()),
        TILE_CASES="".join(f'<option value="{name}">{label(name)}</option>' for name in tiles),
        TILE_DATA=json.dumps(tiles, separators=(",", ":")))
    html = (ROOT / "publication/notebook-v1.html").read_text()
    for name, value in fields.items():
        html = html.replace(f"%%{name}%%", str(value))
    assert "%%" not in html
    (ROOT / f"report/{STEM}.html").write_text(html)


if __name__ == "__main__":
    main()
