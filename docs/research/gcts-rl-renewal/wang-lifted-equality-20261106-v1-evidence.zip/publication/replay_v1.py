"""Repeat the lifted equality study in an isolated directory."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
from subprocess import run
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
STEM = "wang-lifted-equality-20261106-v1"
Z3_FILES = ("data/lifted-equality-z3-v1.json", "data/lifted-equality-z3-inputs-v1.json")


def inputs():
    return tuple(sorted(str(p.relative_to(ROOT)) for folder in ("source", "publication")
                        for p in (ROOT / folder).glob("*.py"))) + (
        "input/archived-cases-v1.json", "publication/notebook-v1.html", *Z3_FILES,
    )


def outputs():
    return tuple(sorted(str(p.relative_to(ROOT)) for p in (ROOT / "data").glob("*.json")
                        if str(p.relative_to(ROOT)) not in Z3_FILES)) + (f"report/{STEM}.html",)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--z3", type=Path)
    args = parser.parse_args()
    retained = outputs() + (Z3_FILES if args.z3 else ())
    assert len(retained) > 30
    with TemporaryDirectory() as temp:
        clean = Path(temp)
        for name in (*inputs(), *retained):
            (clean / name).parent.mkdir(parents=True, exist_ok=True)
        for name in inputs():
            copyfile(ROOT / name, clean / name)
        python = (sys.executable, "-I", "-S", "-B")
        run((*python, "source/lifted_equality_study_v1.py"), cwd=clean, check=True)
        if args.z3:
            run((*python, "source/lifted_equality_z3_v1.py", str(args.z3.resolve())), cwd=clean, check=True)
        run((*python, "publication/render_v1.py"), cwd=clean, check=True)
        hashes = {}
        for name in retained:
            regenerated = (clean / name).read_bytes()
            assert regenerated == (ROOT / name).read_bytes(), name
            hashes[name] = sha256(regenerated).hexdigest()
    receipt = dict(status="CHECKED_CLEAN_REPLAY", sha256=hashes, includes_z3=args.z3 is not None)
    (ROOT / "publication/replay-v1.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
    print(f"Matched {len(hashes)} outputs byte for byte.")


if __name__ == "__main__":
    main()
