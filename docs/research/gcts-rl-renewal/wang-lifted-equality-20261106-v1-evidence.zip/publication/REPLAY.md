# Replay lifted equality proof search

Extract the ZIP and run this from the archive root with CPython 3.12.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The clean replay retrains the scheduler from the donors, rebuilds the rewrite failure witnesses, reruns all source-bound proof checks and countermodel evaluations, and regenerates the reader. It compares the outputs byte for byte with the archived copies.

To also regenerate the Z3 check, install `z3-solver==4.15.4.0` in a separate vendor directory and pass that directory to the replay.

```sh
python3.12 -I -S -B publication/replay_v1.py --z3 /path/to/vendor
```

To search another source, pass a JSON file in the same formula format. The policy file supplies the trained priority and marking settings. A bounded failure exits with status 2 and leaves the target path available. Omit `--policy` for the unmarked search. Add `--full` to write explicit Wang transition witnesses, which are checked by the full certificate command.

```sh
python3.12 -I -S -B source/lifted_equality_prove_v1.py statement.json proof.json --policy data/lifted-equality-policy-v1.json
python3.12 -I -S -B source/logical_records_cli_v1.py verify statement.json proof.json
python3.12 -I -S -B source/shared_wang_v1.py verify statement.json full-proof.json
```

The indexed rewrite search is bounded and uses a heuristic orientation. Each proof is checked against the original formula with the same ground instance and resolution records as the earlier Wang checker.
