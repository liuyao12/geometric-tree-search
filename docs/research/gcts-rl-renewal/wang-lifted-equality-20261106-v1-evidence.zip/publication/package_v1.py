"""Package the checked study with deterministic evidence and file hashes."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import ROOT, STEM, Z3_FILES, inputs, outputs


def read(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def pin(raw):
    return dict(bytes=len(raw), sha256=sha256(raw).hexdigest())


def main():
    replay = read("publication/replay-v1.json")
    assert replay["includes_z3"] and set(replay["sha256"]) == set((*outputs(), *Z3_FILES))
    assert all(pin((ROOT / name).read_bytes())["sha256"] == digest for name, digest in replay["sha256"].items())
    browser = read("publication/browser-v1.json")
    assert browser["status"] == "CHECKED_LIFTED_EQUALITY_READER"
    result = f"report/{STEM}-results.json"
    save(result, dict(schema="WANG-LIFTED-EQUALITY-RESULTS-v1", replay=replay, browser=browser,
        experiment=read("data/lifted-equality-experiment-v1.json"), z3=read(Z3_FILES[0]),
        policy=read("data/lifted-equality-policy-v1.json")))
    paths = (*inputs(), *outputs(), result, "publication/REPLAY.md", "publication/replay-v1.json",
             "publication/browser-v1.json", "publication/check_v1.cjs", "publication/study-v1.log")
    archive = ROOT / f"report/{STEM}-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in paths:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            manifest[name] = pin(raw)
            member = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            member.external_attr = 0o100644 << 16
            bundle.writestr(member, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest
    assets = (archive, ROOT / result, ROOT / f"report/{STEM}.html")
    save(f"report/{STEM}-manifest.json", dict(schema="WANG-LIFTED-EQUALITY-MANIFEST-v1",
        archive_entries=manifest, assets={path.name: pin(path.read_bytes()) for path in assets}))
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
