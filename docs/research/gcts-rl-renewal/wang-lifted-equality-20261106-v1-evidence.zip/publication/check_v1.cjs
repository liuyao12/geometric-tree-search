const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"],
  });
  try {
    const page = await browser.newPage({ viewport: { width: 1120, height: 900 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-lifted-equality-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, { waitUntil: "commit" });
    if (process.argv[2]) assert.equal(response.status(), 200);
    assert.equal(await page.locator("#proof .proof").count(), 22);
    assert.equal(await page.locator("#marks .witness").count(), 2);
    assert.equal(await page.locator("#marks .term.clash").count(), 4);
    assert.equal(await page.locator("#marks .term.alias").count(), 2);
    assert.equal(await page.locator("#comparison table").count(), 3);
    await page.locator("#alternatives-2-depth-3>summary").click();
    await page.waitForSelector("#alternatives-2-depth-3 mjx-container");
    assert.equal(await page.locator("#alternatives-2-depth-3 tbody tr:visible").count(), 30);
    await page.locator('button[data-case="alternatives-2-depth-3"][data-line="1"]').click();
    assert.equal(await page.locator("#selection").textContent(), "Proof line 1");
    assert.equal(await page.locator("#tile-view svg use").count(), 45);
    await page.locator("#case").selectOption("incidence-choice");
    assert.equal(await page.locator("#selection").textContent(), "Proof line 33");
    assert.equal(await page.locator("#tile-view svg use title").count(), 45);
    if (!process.argv[2]) {
      await page.locator("#marks").screenshot({ path: path.join(__dirname, "marks-v1.png") });
      await page.locator("#tiles").screenshot({ path: path.join(__dirname, "tiles-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_LIFTED_EQUALITY_READER", proofs: 22, fullWitnesses: 2, marks: 2,
      wangSquares: 45, mathTypeset: true, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
