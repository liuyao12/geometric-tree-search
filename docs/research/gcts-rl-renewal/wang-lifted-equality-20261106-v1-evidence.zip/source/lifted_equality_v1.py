"""Lifted resolution with indexed equality rewrites and reusable failure marks."""
from collections import Counter, defaultdict

from lifted_marks_v1 import applies, at, discover
from lifted_prover_v1 import Bound, Prover, size, subst, unifier


def positions(term, path=()):
    if not isinstance(term, str):
        yield path, term
        for i, child in enumerate(term[1:]):
            yield from positions(child, (*path, i))


def replaced(term, path, value):
    if not path:
        return value
    i, *tail = path
    return (*term[:i + 1], replaced(term[i + 1], tail, value), *term[i + 2:])


def head(term):
    return term[0], len(term)


class EqualityProver(Prover):
    def __init__(self, case, *, rewrite_marks=(), learn_rewrites=False, decreasing=True,
                 goal_bias=0, **kwargs):
        super().__init__(case, **kwargs)
        assert self.normal["equality"]
        self.search_sources = [row for row in self.sources if row["id"].startswith("formula")]
        self.equations = defaultdict(list)
        self.targets = defaultdict(list)
        self.rewrite_marks = tuple(rewrite_marks)
        self.learn_rewrites = learn_rewrites
        self.decreasing = decreasing
        self.goal_bias = goal_bias
        self.goal_schema = f"formula{len(case['premises']) + 1}-"
        self.rewrite_failures = {}
        self.rewrite_skips = Counter()

    def priority(self, node, weight):
        node["goal_support"] = ((node["schema"] or "").startswith(self.goal_schema) or
                                any(self.nodes[i]["goal_support"] for i in node["parents"]))
        if node["goal_support"] and len(node["clause"]) == 1:
            return weight - self.goal_bias
        return weight

    def charge(self, action):
        self.counts[action] += 1
        self.counts["offers"] += 1
        if self.counts["offers"] > self.offer_cap:
            raise Bound

    def remove_negative_equality(self, node, index):
        self.charge("equality_resolutions_offered")
        row, types, names = self.scoped(node, "e")
        _, (relation, a, b) = row[index]
        env = unifier(a, b, types, self.functions, self.counts)
        if env is None:
            return None
        self.counts["equality_resolutions_unified"] += 1
        clause = [(sign, subst(atom, env)) for i, (sign, atom) in enumerate(row) if i != index]
        bindings = {v: subst(t, env) for v, t in names.items()}
        return self.add(clause, types, "eq-reflexive", parents=(node,), maps=(bindings,),
                        pivot=(relation, subst(a, env), subst(b, env)), sites=(index,))

    def rewrite(self, equation, target):
        self.charge("rewrites_offered")
        left, i, side = equation
        right, j, path = target
        a = self.nodes[left]["clause"][i][1][side + 1]
        b = at(self.nodes[right]["clause"][j][1], path)
        for mark in self.rewrite_marks:
            self.counts["rewrite_mark_tests"] += 1
            if applies(mark, a, b):
                self.rewrite_skips[mark, a, b] += 1
                self.counts["rewrite_mark_skips"] += 1
                return None
        first, types, left_names = self.scoped(left, "l")
        second, other_types, right_names = self.scoped(right, "r")
        types.update(other_types)
        _, eq = first[i]
        sign, atom = second[j]
        lhs, rhs = eq[side + 1], eq[2 - side]
        selected = at(atom, path)
        if not self.same_sort(lhs, selected, types):
            self.counts["rewrite_sort_rejections"] += 1
            return None
        self.counts["rewrite_unifications"] += 1
        env = unifier(lhs, selected, types, self.functions, self.counts)
        if env is None:
            self.counts["rewrite_unification_failures"] += 1
            if self.learn_rewrites:
                for mark in discover(a, b):
                    self.rewrite_failures.setdefault(mark, (a, b))
            return None
        if subst(lhs, env) == subst(rhs, env):
            self.counts["rewrite_identities"] += 1
            return None
        self.counts["rewrites_unified"] += 1
        rest = [lit for k, lit in enumerate(first) if k != i]
        rest.extend(lit for k, lit in enumerate(second) if k != j)
        rest.append((sign, replaced(atom, path, rhs)))
        clause = [(p, subst(t, env)) for p, t in rest]
        maps = tuple({v: subst(t, env) for v, t in names.items()}
                     for names in (left_names, right_names))
        return self.add(clause, types, "eq-rewrite", parents=(left, right), maps=maps,
                        sites=(i, j, side, path))

    def same_sort(self, a, b, types):
        def sort(term):
            return types[term] if isinstance(term, str) else self.functions[term[0]][1]
        return sort(a) == sort(b)

    def extend(self, given):
        clause = self.nodes[given]["clause"]
        equations, targets = [], []
        for i, (sign, atom) in enumerate(clause):
            if atom[0].startswith("="):
                if sign:
                    for side, (lhs, rhs) in enumerate((atom[1:], atom[:0:-1])):
                        if isinstance(lhs, str):
                            continue
                        if self.decreasing and (size(lhs), repr(lhs)) <= (size(rhs), repr(rhs)):
                            continue
                        equations.append((head(lhs), (given, i, side)))
                else:
                    found = self.remove_negative_equality(given, i)
                    if found is not None:
                        return found
            for path, term in positions(atom):
                if path:
                    targets.append((head(term), (given, i, path)))
        for key, equation in equations:
            for target in self.targets[key]:
                found = self.rewrite(equation, target)
                if found is not None:
                    return found
        for key, target in targets:
            for equation in self.equations[key]:
                found = self.rewrite(equation, target)
                if found is not None:
                    return found
        for key, equation in equations:
            self.equations[key].append(equation)
        for key, target in targets:
            self.targets[key].append(target)
        return None
