"""Elaborate a lifted rewrite into existing ground G and R proof records."""
from lifted_equality_v1 import replaced
from lifted_marks_v1 import at
from lifted_prover_v1 import subst


def equality(sort, a, b):
    return "=" + sort, a, b


def reflexive(builder, atom):
    relation, a, b = atom
    assert a == b
    return builder.unguard("reflexive-" + relation[1:], {"?x": a})


def congruence(builder, a, b, path, base):
    sort = builder.functions[a[0]][1]
    requested = equality(sort, a, b)
    if a == b:
        return reflexive(builder, requested)
    if requested == base:
        return None
    if not path:
        assert requested == (base[0], base[2], base[1])
        return builder.unguard("symmetric-" + sort, {"?x": b, "?y": a})
    assert a[0] == b[0]
    args, _ = builder.functions[a[0]]
    result = builder.unguard("congruence-" + a[0], paired(a, b))
    index, *tail = path
    for i, (s, x, y) in enumerate(zip(args, a[1:], b[1:], strict=True)):
        guard = equality(s, x, y)
        if (False, guard) not in builder.lines[result]["clause"]:
            continue
        if i == index:
            condition = congruence(builder, x, y, tail, base)
        else:
            condition = reflexive(builder, guard)
        if condition is not None:
            result = builder.resolve(condition, result, guard)
    assert set(builder.lines[result]["clause"]) <= {(False, base), (True, requested)}
    return result


def paired(a, b):
    return {f"?{side}{i}": term for side, row in (("l", a), ("r", b))
            for i, term in enumerate(row[1:])}


def implication(builder, before, after, path, base):
    index, *tail = path
    x, y = before[index + 1], after[index + 1]
    name = before[0]
    if name.startswith("="):
        sort = name[1:]
        if index == 0:
            x, y = y, x
            bindings = {"?x": x, "?y": y, "?z": before[2]}
        else:
            assert index == 1
            bindings = {"?x": before[1], "?y": x, "?z": y}
        line = builder.unguard("transitive-" + sort, bindings)
    else:
        sorts = builder.sources["substitution-" + name]["variables"]
        sort = sorts[f"?l{index}"]
        line = builder.unguard("substitution-" + name, paired(before, after))
        for i, term in enumerate(before[1:]):
            if i == index:
                continue
            guard = equality(sorts[f"?l{i}"], term, after[i + 1])
            if (False, guard) in builder.lines[line]["clause"]:
                line = builder.resolve(reflexive(builder, guard), line, guard)
    guard = equality(sort, x, y)
    condition = congruence(builder, x, y, tail, base)
    if condition is not None and (False, guard) in builder.lines[line]["clause"]:
        line = builder.resolve(condition, line, guard)
    assert set(builder.lines[line]["clause"]) <= {(False, base), (False, before), (True, after)}
    return line


def elaborate(builder, dag, node, complete, maps, parents):
    if node["kind"] == "eq-reflexive":
        original, = parents
        pivot = subst(node["pivot"], complete)
        if (False, pivot) not in builder.lines[original]["clause"]:
            return original
        return builder.resolve(reflexive(builder, pivot), original, pivot)

    assert node["kind"] == "eq-rewrite"
    i, j, side, path = node["sites"]
    eq_parent, target_parent = parents
    first, second = (dag[parent]["clause"] for parent in node["parents"])
    eq_sign, equation = first[i]
    sign, old = second[j]
    base = subst(equation, maps[0])
    old = subst(old, maps[1])
    assert at(old, path) == base[side + 1]
    new = replaced(old, path, base[2 - side])
    assert eq_sign
    if (True, base) not in builder.lines[eq_parent]["clause"]:
        return eq_parent
    if old == new or (sign, old) not in builder.lines[target_parent]["clause"]:
        return target_parent
    before, after = (old, new) if sign else (new, old)
    line = implication(builder, before, after, path, base)
    if (not sign, old) in builder.lines[line]["clause"]:
        left, right = (target_parent, line) if sign else (line, target_parent)
        line = builder.resolve(left, right, old)
    if (False, base) in builder.lines[line]["clause"]:
        line = builder.resolve(eq_parent, line, base)
    return line
