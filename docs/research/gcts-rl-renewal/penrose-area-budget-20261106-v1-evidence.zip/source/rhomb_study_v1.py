"""Audit whole-rhomb ownership, then compare exact scores on movable boundaries."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from arrow_classes_v1 import frozen
import center_v1 as center
import check_v1 as ring
import discover_v1 as geo
import field_clip_v1 as f
from rhomb_audit_v1 import audit
from rhomb_rank_v1 import Atlas, solve


def read(name):
    return frozen(json.loads((ROOT / "input" / (name + "-v1.json")).read_text()))


def load():
    s, c = read("standard-proof"), read("center")
    seed, rules, marks = c["seed"], s["rules"], s["marks"]
    return Atlas(seed, rules), marks


def leaves(atlas, ref, path):
    if ref[0] == 0:
        yield (*ref[1], ref[2]), path
    else:
        for i, child in enumerate(atlas.children(ref)):
            yield from leaves(atlas, child, (*path, i))


def verify_pairing(atlas, marks):
    basis = [tuple(int(i == j) for j in range(4)) for i in range(4)]
    assert all(f.determinant(f.point(p), f.point(q)) == ring.imaginary_normal(p, q)
               for p in basis for q in basis)
    assert center.has_quarter_disk(atlas.seed)
    assert center.qualify(atlas.rules, marks) == 4
    stage = center.substitute(center.substitute(atlas.seed, atlas.rules), atlas.rules)
    assert set(atlas.seed) <= {center.turn(p, -1) for p in stage}
    stage = center.substitute(center.substitute(stage, atlas.rules), atlas.rules)
    aligned = tuple(center.turn(p, -2) for p in stage)
    roots = atlas.roots(4)
    paths = dict((p, path) for i, r in enumerate(roots) for p, path in leaves(atlas, r, (i,)))
    assert paths.keys() == set(aligned)
    records = center.edges(aligned, marks)
    owned = {tuple(sorted(atlas.vertices(ref))) for root in roots for kind in (0, 1)
             for ref in atlas.expand(root, kind)}
    assert len(owned) == sum(sum(atlas.count(r)) for r in roots)
    paired = set()
    cross = cross_root = 0
    for values in records.values():
        if len(values) != 2 or values[0][1] != 1:
            continue
        a, b = values
        assert a[0] == b[0]
        k, l = a[2], b[2]
        diagonal = tuple(sorted(geo.placed(k)[1:]))
        rhomb = center.pairing(a, b, diagonal)
        owner = min((k, l), key=lambda p: geo.placed(p)[0])
        assert rhomb in owned and rhomb not in paired
        assert tuple(sorted(atlas.vertices(atlas.at(roots, paths[owner])))) == rhomb
        paired.add(rhomb)
        cross += paths[k][:-1] != paths[l][:-1]
        cross_root += paths[k][0] != paths[l][0]
    assert cross > 0 and cross_root > 0
    return dict(triangles=len(aligned), paired=len(paired), cross_parent=cross, cross_root=cross_root)


def scale(n, v):
    return tuple(n * x for x in v)


def parallelogram(c, a, b):
    return tuple(ring.plus(c, ring.plus(scale(i, a), scale(j, b)))
                 for i, j in ((-1, -1), (1, -1), (1, 1), (-1, 1)))


def requests():
    x, y = geo.ONE, ring.RAYS[2]
    def shape(a, b, center=geo.ZERO):
        return parallelogram(center, scale(a, x), scale(b, y))
    h1 = shape(1, 1, scale(-3, x))
    h2 = shape(2, 1, scale(4, x))
    return (
        ("small-window", shape(2, 2), (), 10, True),
        ("offset-window", shape(3, 2, ring.RAYS[1]), (), 17, True),
        ("two-holes", shape(8, 5), (h1, h2), 100, True),
        ("two-holes-near-area", shape(8, 5), (h1, h2), 173, True),
        ("diagonal-strip", parallelogram(geo.ZERO, scale(45, ring.RAYS[1]), scale(2, y)), (), 160, True),
        ("medium-window", shape(15, 12), (), 840, True),
        ("wide-window", shape(50, 42), (), 9800, False),
        ("distant-window", shape(5, 4, scale(10**6, ring.RAYS[3])), (), 56, True),
        ("padding-budget", shape(1, 1), (), 40, True),
    )


def study():
    atlas, marks = load()
    pairs = verify_pairing(atlas, marks)
    rows = []
    for name, outer, holes, count, compare in requests():
        region = f.Region(outer, holes)
        result = solve(atlas, outer, region, count)
        receipt = audit(atlas, outer, region, result)
        work = None
        if compare:
            control = solve(atlas, outer, region, count, bulk=False)
            assert result["ranked"]["error"] == control["ranked"]["error"]
            work = control["stats"].get("clipped", 0)
        advantage = f.sub(f.decode(result["naive"]["error"]), f.decode(result["ranked"]["error"]))
        rows.append(dict(name=name, outer=outer, holes=holes, result=result, receipt=receipt,
                         advantage=f.encode(advantage), leaf_clips=work))
        print(name, count, result["stats"].get("clipped", 0), work,
              result["ranked"]["types"], result["naive"]["types"], f.encode(advantage), flush=True)
    strict = next(row for row in rows if f.sign(f.decode(row["advantage"])) > 0)
    r = strict["result"]
    forged = dict(r, ranked=r["naive"])
    try:
        audit(atlas, strict["outer"], f.Region(strict["outer"], strict["holes"]), forged)
    except AssertionError:
        pass
    else:
        raise AssertionError("A worse equal-count selection passed the score audit")
    return dict(pairing=pairs, rows=rows, wrong_cutoff_rejected=True)


def main():
    if not __debug__:
        raise RuntimeError("Replay requires assertions")
    data = json.dumps(study(), sort_keys=True, separators=(",", ":")) + "\n"
    path = ROOT / "data/penrose-area-v1.json"
    if "--build" in sys.argv:
        path.write_text(data)
    else:
        assert path.read_text() == data


if __name__ == "__main__":
    main()
