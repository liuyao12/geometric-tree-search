"""Independent verification of the recovered standard Penrose arrow system."""

from collections import Counter, defaultdict
from functools import lru_cache
from itertools import combinations
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import check_v1 as ring
import model_v1 as real

ZERO=real.ZERO
ONE=real.ONE
PHI=(0,0,-1,-1)
PROTOS=((ZERO,ONE,real.DIRECTIONS[1]),(ZERO,ONE,real.DIRECTIONS[3]))


def load(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name,value):
    with (ROOT/name).open("x") as f:
        json.dump(value,f,sort_keys=True,separators=(",",":"))
        f.write("\n")


def edges(poly):
    return zip(poly,poly[1:]+poly[:1])


def axes(limit):
    scale=ring.minus(PHI,ONE)
    lengths={}
    for k in range(-1,limit+1):
        lengths[k]=scale
        scale=ring.multiply(PHI,scale)
    return {ring.multiply(d,n):(a,k) for a,d in enumerate(real.DIRECTIONS) for k,n in lengths.items()}


def place(p):
    kind,turn,mirror,base=p
    return tuple(ring.plus(tuple(base),real.rotate(ring.star(q) if mirror else q,turn)) for q in PROTOS[kind])


def area_tag(polys):
    total=ZERO
    for poly in polys:
        for a,b in edges(poly):
            term=ring.multiply(ring.star(a),b)
            total=ring.plus(total,ring.minus(term,ring.star(term)))
    return total


def contained(p,poly,directions,strict=False):
    for a,b in edges(poly):
        axis,_=directions[ring.minus(b,a)]
        if real.compare(real.project(axis,p),real.project(axis,a))<int(strict):
            return False
    return True


def disjoint(a,b,directions):
    for p in (a,b):
        for x,y in edges(p):
            axis,_=directions[ring.minus(y,x)]
            al,ah=real.bounds(axis,a)
            bl,bh=real.bounds(axis,b)
            if real.compare(ah,bl)<=0 or real.compare(bh,al)<=0:
                return True
    return False


def scaled(p,depth):
    for _ in range(depth):
        p=ring.multiply(PHI,p)
    return p


def verify_patch(kind,depth,cells,marks,directions):
    parent=tuple(scaled(p,depth) for p in PROTOS[kind])
    tiles=[place(p) for p in cells]
    assert all(contained(q,parent,directions) for tile in tiles for q in tile)
    assert all(disjoint(a,b,directions) for a,b in combinations(tiles,2))
    assert area_tag(t if not c[2] else t[::-1] for c,t in zip(cells,tiles,strict=True))==area_tag([parent])
    seam_map=defaultdict(list)
    for i,(c,tile) in enumerate(zip(cells,tiles,strict=True)):
        for j,((a,b),arrow) in enumerate(zip(edges(tile),marks[c[0]],strict=True)):
            if arrow<0:
                a,b=b,a
            seam_map[tuple(sorted((a,b)))].append(dict(tile=i,edge=j,mark=(a,b,abs(arrow))))
    rhombs=[]
    external=[]
    for e,records in seam_map.items():
        parent_side=[]
        for j,(a,b) in enumerate(edges(parent)):
            axis,_=directions[ring.minus(b,a)]
            value=real.project(axis,a)
            if all(real.project(axis,q)==value for q in e):
                parent_side.append(j)
        if parent_side:
            side,=parent_side
            record,=records
            external.append((side,record["mark"]))
            continue
        a,b=records
        assert a["mark"]==b["mark"]
        if a["edge"]!=1:
            assert b["edge"]!=1
            continue
        assert b["edge"]==1
        i,j=a["tile"],b["tile"]
        assert cells[i][0]==cells[j][0]
        top,bottom=tiles[i][0],tiles[j][0]
        assert ring.plus(top,bottom)==ring.plus(*e)
        rhomb=tuple(sorted((top,bottom,*e)))
        assert len(set(rhomb))==4
        assert rhomb in real.incident(top)
        rhombs.append(dict(triangles=(i,j),vertices=rhomb,kind=cells[i][0]))
    return parent,tiles,external,rhombs


def boundary_maps(kind,parent,external,marks,directions):
    maps={}
    for i,(a,b) in enumerate(edges(parent)):
        arrow=marks[kind][i]
        if arrow<0:
            a,b=b,a
        axis,scale=directions[ring.minus(b,a)]
        pieces=[]
        for side,(x,y,c) in external:
            if side!=i:
                continue
            p=real.rotate(ring.minus(x,a),-axis)
            q=real.rotate(ring.minus(y,a),-axis)
            assert real.project(0,p)==real.project(0,q)==(0,0)
            pieces.append((p,q,c))
        domain=(scale-1,abs(arrow))
        word=tuple(sorted(pieces))
        if domain in maps:
            assert maps[domain]==word
        maps[domain]=word
    return maps


def main():
    protocol=load("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    reference=load("input/standard-figure-v1.json")
    marks=reference["signed_edge_arrows"]
    discovery=load("input/discovery-results-v1.json")
    index,=[i for i,v in enumerate(discovery["systems"]) if v["marks"]==marks]
    solution=discovery["systems"][index]
    nesting,=[r["seed"] for r in discovery["nested"] if r["system"]==index]
    kind,depth=nesting["root"],nesting["depth"]
    directions=axes(depth+1)
    proof_maps={}
    counts=[]
    for k,rules in enumerate(solution["rules"]):
        p,_,outer,rhombs=verify_patch(k,1,rules,marks,directions)
        counts.append(dict(kind=k,children=dict(Counter(c[0] for c in rules)),interior_rhombs=len(rhombs)))
        for channel,word in boundary_maps(k,p,outer,marks,directions).items():
            if channel in proof_maps:
                assert proof_maps[channel]==word
            proof_maps[channel]=word
    assert len(proof_maps)==4
    assert [r["children"] for r in counts]==[{0:1,1:1},{0:1,1:2}]
    p,tiles,outer,rhombs=verify_patch(kind,depth,nesting["cells"],marks,directions)
    assert json.loads(json.dumps(p))==nesting["parent"]
    seed=nesting["seed"]
    assert seed in nesting["cells"] and seed[0]==kind
    assert all(contained(q,p,directions,True) for q in place(seed))
    # Pull the seed back to its original orientation with an exact isometry.
    _,turn,mirror,offset=seed
    def back(q):
        v=real.rotate(ring.minus(q,offset),-turn)
        return ring.star(v) if mirror else v
    assert tuple(map(back,place(seed)))==PROTOS[kind]
    outer_after=tuple(map(back,p))
    proof=dict(status="VERIFIED_STANDARD_P3_SUBSTITUTION",system=index,marks=marks,rules=solution["rules"],
               child_counts=counts,boundary_receptors=[dict(channel=k,word=v) for k,v in sorted(proof_maps.items())],
               nest=dict(kind=kind,depth=depth,seed=seed,parent=p,parent_after_alignment=outer_after,
                         triangles=nesting["cells"],matched_rhombs=rhombs),
               scope="Exact geometry, de Bruijn standard rhomb arrows, common-edge subdivision compatibility, and a strictly nested affine seed.")
    save("data/proof-v1.json",proof)
    summary=dict(status=proof["status"],system=index,child_counts=counts,boundary_receptors=len(proof_maps),
                 depth=depth,nested_triangles=len(tiles),interior_rhombs=dict(Counter(r["kind"] for r in rhombs)),
                 reference=reference["doi"],scope=proof["scope"])
    save("data/summary-v1.json",summary)
    print(json.dumps(summary,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
