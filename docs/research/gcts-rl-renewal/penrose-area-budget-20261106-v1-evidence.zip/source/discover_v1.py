"""Discover marked golden-triangle subdivisions in the exact cyclotomic ring."""

from collections import Counter, defaultdict
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import check_v1 as exact
import model_v1 as control

ZERO=(0,0,0,0)
ONE=(1,0,0,0)
PHI=(0,0,-1,-1)
UNIT=exact.RAYS[1]
TILES=((ZERO,ONE,UNIT),(ZERO,ONE,exact.RAYS[3]))
LENGTHS=(("unit","short","unit"),("unit","long","unit"))
TURNS=range(10)


def read(name):
    return json.loads((ROOT/name).read_bytes())


def pin(path):
    import hashlib
    data=path.read_bytes()
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name,value):
    with (ROOT/name).open("x") as out:
        json.dump(value,out,sort_keys=True,separators=(",",":"))
        out.write("\n")


def edges(poly):
    return tuple(zip(poly,poly[1:]+poly[:1]))


def cross(a,b,c):
    return exact.imaginary_normal(exact.minus(b,a),exact.minus(c,a))


def sign(p):
    return exact.order(p,(0,0))


def add2(a,b):
    return a[0]+b[0],a[1]+b[1]


def area(poly):
    answer=(0,0)
    for a,b in edges(poly):
        answer=add2(answer,cross(ZERO,a,b))
    return answer


def ccw(poly):
    assert sign(area(poly))
    return poly if sign(area(poly))>0 else poly[::-1]


def inside(p,poly,strict=False):
    return all(sign(cross(a,b,p))>=int(strict) for a,b in edges(poly))


@lru_cache(maxsize=100000)
def overlap(a,b):
    return not any(all(sign(cross(p,q,r))<=0 for r in other)
                   for poly,other in ((a,b),(b,a)) for p,q in edges(poly))


def transform(turn,mirror,p):
    return exact.multiply(exact.RAYS[turn],exact.star(p) if mirror else p)


def placed(cell):
    kind,turn,mirror,offset=cell
    return tuple(exact.plus(transform(turn,mirror,p),offset) for p in TILES[kind])


def inflate(poly):
    return tuple(exact.multiply(PHI,p) for p in poly)


def determinant_length(delta):
    w,x,y,z=exact.multiply(exact.star(delta),delta)
    assert not x and y==z
    return w,y


def qualification():
    assert tuple(exact.RAYS)==control.DIRECTIONS
    small=exact.minus(PHI,ONE)
    assert exact.multiply(PHI,small)==ONE
    assert all(sign(area(t))>0 for t in TILES)
    lengths={key:determinant_length(v) for key,v in (("unit",ONE),("short",small),("long",PHI))}
    for kind,tri in enumerate(TILES):
        assert tuple(determinant_length(exact.minus(q,p)) for p,q in edges(tri))==tuple(lengths[k] for k in LENGTHS[kind])
    assert area(TILES[1])==(0,1) and area(TILES[0])==(1,0)
    for p in exact.RAYS:
        for q in exact.RAYS:
            ab=exact.imaginary_normal(p,q)
            assert sign(ab)==control.sign(*ab)


def discover(kind,limits):
    parent=inflate(TILES[kind])
    goal=area(parent)
    places={}
    visits=0
    begun=time.perf_counter()
    answers={}
    seen=set()

    @lru_cache(maxsize=500)
    def at(q):
        result=set()
        for tile,turn,mirror in product(range(2),TURNS,(False,True)):
            for v in TILES[tile]:
                offset=exact.minus(q,transform(turn,mirror,v))
                rec=(tile,turn,mirror,offset)
                poly=placed(rec)
                if all(inside(p,parent) for p in poly):
                    key=tuple(sorted(poly))
                    result.add(key)
                    places.setdefault(key,set()).add(rec)
        return result

    def visit(prefix,used):
        nonlocal visits
        key=tuple(sorted(prefix))
        if key in seen:
            return
        seen.add(key)
        visits+=1
        assert visits<=limits["visits"] and time.perf_counter()-begun<limits["seconds"]
        if used==goal:
            answers[key]=None
            return
        if len(prefix)==limits["children"]:
            return
        points=set(parent).union(*(set(q) for q in prefix))
        for key in sorted(set().union(*(at(p) for p in points))):
            if key in prefix:
                continue
            candidate=_ordered(key)
            size=add2(used,area(candidate))
            if exact.order(size,goal)>0 or any(overlap(candidate,_ordered(old)) for old in prefix):
                continue
            visit((*prefix,key),size)

    visit((),(0,0))
    result=[]
    for key in sorted(answers):
        result.append([sorted(places[cell]) for cell in key])
    return result,dict(visits=visits,placements=len(places),geometric_partitions=len(result))


def _ordered(points):
    # A triangle's order is fixed by its exact signed area.
    return ccw(tuple(points))


def dot_sign(a,b):
    w,x,y,z=exact.multiply(exact.star(a),b)
    return exact.order((2*w-x,x-y-z),(0,0))


def oriented_key(a,b):
    return (a,b) if a<b else (b,a)


def shape_edges(cells,marks):
    for cell in cells:
        j=cell[0]
        for (a,b),length,mark in zip(edges(placed(cell)),LENGTHS[j],marks[j],strict=True):
            yield a,b,length,mark


def boundary_words(kind,cells,marks):
    parent=inflate(TILES[kind])
    out=[{} for _ in parent]
    internal=defaultdict(list)
    for a,b,length,mark in shape_edges(cells,marks):
        found=False
        for i,(p,q) in enumerate(edges(parent)):
            if cross(p,q,a)!=(0,0) or cross(p,q,b)!=(0,0):
                continue
            if dot_sign(exact.minus(q,p),exact.minus(b,a))<0:
                a,b,mark=b,a,-mark
            if a in out[i]:
                return None
            out[i][a]=b,length,mark
            found=True
            break
        if not found:
            internal[oriented_key(a,b)].append((length,mark if a<b else -mark))
    if any(len(v)!=2 or v[0]!=v[1] for v in internal.values()):
        return None
    words={}
    for i,(a,b) in enumerate(edges(parent)):
        seq=[]
        point=a
        while point!=b:
            if point not in out[i]:
                return None
            point,length,mark=out[i][point]
            seq.append((length,mark))
            if len(seq)>len(out[i]):
                return None
        if len(seq)!=len(out[i]):
            return None
        arrow=marks[kind][i]
        if arrow<0:
            seq=[(length,-mark) for length,mark in reversed(seq)]
        channel=LENGTHS[kind][i],abs(arrow)
        word=tuple(seq)
        if channel in words and words[channel]!=word:
            return None
        words[channel]=word
    return words


def find_marks(partitions):
    arrows=(-2,-1,1,2)
    left=[p for part in partitions[0] for p in product(*part)]
    right=[p for part in partitions[1] for p in product(*part)]
    solutions=[]
    tested=0
    for a,b,c,d in product(arrows,repeat=4):
        if {abs(x) for x in (a,b,c,d)}!={1,2}:
            continue
        marks=((a,3,b),(c,3,d))
        pairs=[[(cells,w) for cells in proposals if (w:=boundary_words(i,cells,marks)) is not None]
               for i,proposals in enumerate((left,right))]
        tested+=len(left)+len(right)
        for (x,a_words),(y,b_words) in product(*pairs):
            if all(a_words[ch]==b_words[ch] for ch in a_words.keys()&b_words.keys()):
                words=a_words|b_words
                solutions.append(dict(marks=marks,rules=(x,y),
                    words=[dict(length=k[0],arrow=k[1],subdivision=v) for k,v in sorted(words.items())]))
    return solutions,dict(oriented_candidates=[len(left),len(right)],mark_checks=tested,marked_systems=len(solutions))


def compose(parent,child):
    i,g,mirror,pos=parent
    j,h,reflect,offset=child
    return (j,(g-h if mirror else g+h)%10,mirror!=reflect,
            exact.plus(exact.multiply(PHI,pos),transform(g,mirror,offset)))


def verify_patch(cells,parent,marks):
    polygons=[ccw(placed(p)) for p in cells]
    assert all(inside(q,parent) for poly in polygons for q in poly)
    total=(0,0)
    for i,poly in enumerate(polygons):
        total=add2(total,area(poly))
        assert all(not overlap(poly,other) for other in polygons[:i])
    assert total==area(parent)
    edge_map=defaultdict(list)
    for a,b,length,mark in shape_edges(cells,marks):
        edge_map[oriented_key(a,b)].append((length,mark if a<b else -mark))
    diagonal=0
    for (a,b),entries in edge_map.items():
        boundary=any(cross(p,q,a)==cross(p,q,b)==(0,0) for p,q in edges(parent))
        assert len(entries)==(1 if boundary else 2)
        if not boundary:
            assert entries[0]==entries[1]
            diagonal+=entries[0][0]!="unit"
    return dict(triangles=len(cells),interior_rhombs=diagonal,checked_edges=len(edge_map))


def grow(solution,max_depth):
    marks=solution["marks"]
    rules=solution["rules"]
    for kind in range(2):
        parent=TILES[kind]
        cells=[(kind,0,False,ZERO)]
        records=[]
        for step in range(1,max_depth+1):
            parent=inflate(parent)
            cells=[compose(p,q) for p in cells for q in rules[p[0]]]
            checked=verify_patch(cells,parent,marks)
            records.append(dict(depth=step,**checked))
            for p in cells:
                if p[0]==kind and all(inside(q,parent,True) for q in placed(p)):
                    return dict(root=kind,depth=step,seed=p,parent=parent,cells=cells,verified=records)
    return None


def main():
    protocol=read("protocol-v1.json")
    assert protocol["runtime"]==pin(Path(sys.executable))
    assert all(pin(ROOT/name)==v for name,v in protocol["pins"].items())
    qualification()
    partitions=[]
    stages=[]
    for kind in range(2):
        patches,stage=discover(kind,protocol["limits"])
        partitions.append(patches)
        stages.append(stage)
        print(json.dumps(dict(kind=kind,**stage)),flush=True)
    solutions,marked=find_marks(partitions)
    print(json.dumps(marked),flush=True)
    examples=[]
    for i,solution in enumerate(solutions):
        for kind in range(2):
            verify_patch(solution["rules"][kind],inflate(TILES[kind]),solution["marks"])
        seed=grow(solution,protocol["seed_depth"])
        if seed:
            examples.append(dict(system=i,seed=seed))
    save("data/results-v1.json",dict(partitions=partitions,systems=solutions,nested=examples))
    result=dict(status="CHECKED_CYCLOTOMIC_GOLDEN_TRIANGLE_DISCOVERY",stages=stages,marks=marked,
                nested_systems=len(examples),smallest_nested_depth=min((r["seed"]["depth"] for r in examples),default=None),
                scope="Exact candidate search from two unmarked half-rhomb shapes. Compatible marked subdivisions preserve edge matching. A nested seed certifies a plane tiling for its recovered marking system. Standard Penrose arrow equivalence is a separate comparison.")
    save("data/summary-v1.json",result)
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=="__main__":
    main()
