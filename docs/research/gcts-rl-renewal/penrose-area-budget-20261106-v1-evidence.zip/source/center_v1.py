"""Find finite central cycles of the recovered Penrose substitution."""
from collections import Counter, defaultdict
from functools import lru_cache
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import check_v1 as ring
import discover_v1 as geom
import model_v1 as real
import standard_v1 as checker
from arrow_classes_v1 import frozen


ZERO, ONE, PHI = geom.ZERO, geom.ONE, geom.PHI
FULL = (1 << 10)-1


def scale(n, z):
    return tuple(n*x for x in z)


def real_sign(z):
    w, x, y, t = z
    assert x == 0 and y == t and ring.star(z) == z
    return real.sign(w, -y)


def norm(z):
    return ring.multiply(z, ring.star(z))


def turn(tile, steps=2):
    k, orientation, mirrored, origin = tile
    return k, (orientation+steps) % 10, mirrored, real.rotate(origin, steps)


@lru_cache(maxsize=2048)
def tile_vertices(tile):
    return geom.placed(tile)


def sector(tile, rays):
    vertices = tile_vertices(tile)
    assert ZERO in vertices
    a, b = (rays[p] for p in vertices if p != ZERO)
    width = (b-a) % 10
    if width > 5:
        a, width = b, 10-width
    assert 1 <= width <= 3
    return sum(1 << ((a+j) % 10) for j in range(width))


def ray_map():
    lengths = (ring.minus(PHI, ONE), ONE, PHI)
    rays = {ring.multiply(axis, n): i for i, axis in enumerate(ring.RAYS) for n in lengths}
    assert len(rays) == 30
    return rays


def candidates():
    rays = ray_map()
    stars = set()
    for kind in range(2):
        for orientation in range(10):
            for mirrored in (False, True):
                for p in geom.TILES[kind]:
                    offset = scale(-1, geom.transform(orientation, mirrored, p))
                    stars.add((kind, orientation, mirrored, offset))
    rotation_orbits = {}
    for t in sorted(stars):
        orbit = tuple(sorted(turn(t, 2*j) for j in range(5)))
        assert set(orbit) <= stars and len(orbit) == len(set(orbit)) == 5
        masks = [sector(p, rays) for p in orbit]
        if sum(m.bit_count() for m in masks) == (mask := combine(masks)).bit_count():
            rotation_orbits[orbit] = mask
    found = set()

    def extend(mask, current):
        if mask == FULL:
            found.add(tuple(sorted(current)))
            return
        empty = (FULL ^ mask) & -(FULL ^ mask)
        for orbit, covered in rotation_orbits.items():
            if covered & empty and not covered & mask:
                extend(mask | covered, (*current, *orbit))

    extend(0, ())
    assert found
    for state in found:
        assert {turn(t) for t in state} == set(state)
    return sorted(found), len(stars), len(rotation_orbits)


def combine(masks):
    result = 0
    for mask in masks:
        result |= mask
    return result


def edges(state, marks):
    out = defaultdict(list)
    for cell in state:
        tile = tile_vertices(cell)
        for i, (a, b) in enumerate(geom.edges(tile)):
            m = marks[cell[0]][i]
            out[tuple(sorted((a, b)))].append((m if a < b else -m, i, cell))
    return out


def pairing(a, b, edge):
    _, i, first = a
    _, j, second = b
    assert (i == 1) == (j == 1)
    if i != 1:
        return None
    assert first[0] == second[0]
    apex, opposite = (tile_vertices(t)[0] for t in (first, second))
    assert ring.plus(apex, opposite) == ring.plus(*edge)
    rhomb = tuple(sorted((apex, opposite, *edge)))
    assert rhomb in real.incident(apex)
    return rhomb


def star_contact(state, marks):
    for e, records in edges(state, marks).items():
        if ZERO not in e:
            continue
        if len(records) != 2:
            return "unpaired radial edge"
        a, b = records
        if a[0] != b[0]:
            return "radial arrows disagree"
        pairing(a, b, e)
    return None


def substitute(state, rules):
    return tuple(sorted(geom.compose(p, q) for p in state for q in rules[p[0]]))


def central(state, rules):
    children = substitute(state, rules)
    answer = tuple(p for p in children if ZERO in tile_vertices(p))
    assert all(not geom.inside(ZERO, geom.ccw(tile_vertices(p))) for p in children if p not in answer)
    return answer


def has_quarter_disk(state):
    for tile in state:
        u, v = (p for p in tile_vertices(tile) if p != ZERO)
        dot = ring.plus(ring.multiply(ring.star(u), v), ring.multiply(ring.star(v), u))
        square4 = ring.minus(scale(4, ring.multiply(norm(u), norm(v))), ring.multiply(dot, dot))
        side4 = scale(4, norm(ring.minus(u, v)))
        assert real_sign(ring.minus(scale(16, square4), side4)) > 0
        assert all(real_sign(ring.minus(scale(16, norm(p)), ONE)) > 0 for p in (u, v))
    return True


def transitions(marks, rules, stars):
    rejected = Counter()
    admissible = []
    for s in stars:
        reason = star_contact(s, marks)
        if reason:
            rejected[reason] += 1
        else:
            admissible.append(s)
    mapping = [admissible.index(central(s, rules)) for s in admissible]
    cycles = set()
    for start in range(len(admissible)):
        path = []
        i = start
        while i not in path:
            path.append(i)
            i = mapping[i]
        cycle = tuple(path[path.index(i):])
        root = cycle.index(min(cycle))
        cycles.add(cycle[root:]+cycle[:root])
    assert cycles
    returns = []
    for cycle in cycles:
        for i in cycle:
            assert has_quarter_disk(admissible[i])
        seed = admissible[cycle[0]]
        step, rotation = next((n, j) for n in range(1, len(cycle)+1) for j in range(10)
                              if {turn(p, j) for p in seed} == set(admissible[cycle[n % len(cycle)]]))
        returns.append((step, rotation))
    return dict(states=admissible, map=mapping, cycles=sorted(cycles), corrected=sorted(returns), rejected=dict(rejected))


def qualify(rules, marks):
    words = {}
    for k, row in enumerate(rules):
        dirs = checker.axes(2)
        parent, _, external, _ = checker.verify_patch(k, 1, row, marks, dirs)
        for label, word in checker.boundary_maps(k, parent, external, marks, dirs).items():
            assert label not in words or words[label] == word
            words[label] = word
    assert len(words) == 4
    return len(words)


def on_segment(p, a, b):
    if geom.cross(a, b, p) != (0, 0):
        return False
    axis = ring.star(ring.minus(b, a))
    start = ring.multiply(axis, ring.minus(p, a))
    stop = ring.multiply(axis, ring.minus(b, p))
    return real_sign(start) >= 0 and real_sign(stop) >= 0


def separate(polygons):
    bounds = [(real.bounds(0, t), real.bounds(2, t), t) for t in polygons]
    active = []
    tests = 0
    for vertical, horizontal, triangle in sorted(bounds, key=lambda p: real.ORDER(p[0][0])):
        low, high = vertical
        active = [a for a in active if real.compare(a[0], low) > 0]
        for _, other, rival in active:
            if real.compare(other[0], horizontal[1]) >= 0 or real.compare(horizontal[0], other[1]) >= 0:
                continue
            tests += 1
            assert not geom.overlap(triangle, rival)
        active.append((high, horizontal, triangle))
    return tests


def verify_stage(seed, patch, marks, level):
    # Independent finite cross-check of the induction, using exact pair separation and edge incidence.
    original = edges(seed, marks)
    boundary = [tuple(checker.scaled(p, level) for p in e) for e, v in original.items() if len(v) == 1]
    polygons = [geom.ccw(tile_vertices(p)) for p in patch]
    containers = [geom.ccw(tuple(checker.scaled(v, level) for v in tile_vertices(t))) for t in seed]
    assert len(patch) == len(set(patch))
    assert all(any(all(geom.inside(v, box) for v in triangle) for box in containers) for triangle in polygons)
    tests = separate(polygons)
    area = (0, 0)
    for t in polygons:
        area = geom.add2(area, geom.area(t))
    expected = (0, 0)
    for box in containers:
        expected = geom.add2(expected, geom.area(box))
    assert area == expected
    rhombs = []
    for e, records in edges(patch, marks).items():
        external = any(all(on_segment(p, *line) for p in e) for line in boundary)
        assert len(records) == (1 if external else 2)
        if not external:
            a, b = records
            assert a[0] == b[0]
            r = pairing(a, b, e)
            if r is not None:
                rhombs.append((a[2][0], r))
    return dict(rhombs=sorted(rhombs), triangles=len(patch), pair_tests=tests,
                boundary_edges=sum(len(v)==1 for v in edges(patch, marks).values()))


def study():
    geom.qualification()
    # The positive real factor by which a hypothetical period is shortened.
    rotation = ring.RAYS[2]
    shrink = ring.plus(rotation, ring.star(rotation))
    assert shrink == ring.minus(PHI, ONE) and ring.multiply(shrink, PHI) == ONE
    assert real_sign(shrink) > 0 and real_sign(ring.minus(ONE, shrink)) > 0
    stars, poses, orbits = candidates()
    source = frozen(json.loads((ROOT / "reference/arrow-study-v1.json").read_text()))
    standard = frozen(json.loads((ROOT / "reference/standard-proof-v1.json").read_text()))
    results = []
    for row in source["systems"]:
        marks, rules = row["marks"], row["rules"]
        channels = qualify(rules, marks)
        results.append(dict(**transitions(marks, rules, stars), channels=channels))
    index, = [i for i, s in enumerate(source["systems"]) if s["marks"] == standard["marks"] and
              all(set(a) == set(b) for a, b in zip(s["rules"], standard["rules"], strict=True))]
    result = results[index]
    cycle = result["cycles"][0]
    seed = result["states"][cycle[0]]
    delay, orientation = result["corrected"][0]
    assert (delay, orientation) == (2, 1)
    rules, marks = standard["rules"], standard["marks"]
    active = seed
    thin, thick = (sum(t[0] == k for t in seed) for k in range(2))
    growth = []
    for level in range(25):
        assert active == result["states"][cycle[level % len(cycle)]]
        if level in (0, 2, 4, 8, 16, 24):
            growth.append(dict(level=level, total=thin+thick, center=len(active),
                               checked_child_candidates=sum(len(rules[p[0]]) for p in active)))
        thin, thick = thin+thick, thin+2*thick
        active = central(active, rules)
    patch = seed
    stages = []
    for level in range(len(cycle)+1):
        checked = verify_stage(seed, patch, marks, level)
        assert {turn(p) for p in patch} == set(patch)
        if level % len(cycle) == 0:
            assert set(seed) <= set(patch)
        aligned = 0
        if level == delay:
            assert set(seed) <= {turn(p, -orientation) for p in patch}
            aligned = -orientation
        stages.append(dict(level=level, cells=patch, alignment=aligned, **checked))
        patch = substitute(patch, rules)
    return dict(poses=poses, orbits=orbits, geometric_stars=len(stars), systems=results, standard=index,
                seed=seed, stages=stages, shrink=shrink, radius_denominator=4, growth=growth)


def main():
    if not __debug__:
        raise RuntimeError("Cycle audit requires assertions")
    results = study()
    path = ROOT / "data/center-v1.json"
    body = json.dumps(results, sort_keys=True, separators=(",", ":"))+"\n"
    if "--build" in sys.argv:
        path.write_text(body)
    else:
        assert path.read_text() == body
    i = results["standard"]
    system = results["systems"][i]
    print("orbits", results["orbits"], "geometry", results["geometric_stars"],
          "standard", i, "states", len(system["states"]), "cycles", system["cycles"],
          "finite stages", [(r["level"],r["triangles"],len(r["rhombs"])) for r in results["stages"]])


if __name__ == "__main__":
    main()
