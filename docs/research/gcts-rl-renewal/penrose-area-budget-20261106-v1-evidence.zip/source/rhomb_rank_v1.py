"""Rank whole rhombs from the nested half-rhomb substitution."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations

import check_v1 as ring
import discover_v1 as geo
import field_clip_v1 as f
import model_v1 as real

AREAS = ((2, 0), (0, 2))


def offset_child(parent, child):
    _, turn, mirror = parent
    kind, step, reflected, pos = child
    return (kind, (turn + (-step if mirror else step)) % 10, mirror != reflected), geo.transform(turn, mirror, pos)


class Atlas:
    def __init__(self, seed, rules):
        self.seed = seed
        self.rules = rules
        self.powers = [geo.ONE]
        for k in (0, 1):
            p, u, v = geo.TILES[k]
            q = ring.minus(ring.plus(u, v), p)
            assert f.area(f.ccw(tuple(f.point(x) for x in (p, u, q, v)))) == AREAS[k]
            assert all(f.sign(f.sub((4, 0), norm(ring.minus(a, b)))) > 0
                       for a, b in combinations((p, u, q, v), 2))

    def power(self, n):
        while len(self.powers) <= n:
            self.powers.append(ring.multiply(geo.PHI, self.powers[-1]))
        return self.powers[n]

    def scale(self, n, p):
        return ring.multiply(self.power(n), p)

    @lru_cache(maxsize=None)
    def leaf(self, pose):
        p, u, v = geo.placed((*pose, geo.ZERO))
        q = ring.minus(ring.plus(u, v), p)
        if p < q:
            return p, u, q, v
        return ()

    @lru_cache(maxsize=None)
    def offsets(self, n, pose):
        result = [offset_child(pose, child) for child in self.rules[pose[0]]]
        return tuple((child, self.scale(n - 1, delta)) for child, delta in result)

    @lru_cache(maxsize=None)
    def catalog(self, n, pose):
        if n == 0:
            leaf = self.leaf(pose)
            count = tuple(int(bool(leaf) and k == pose[0]) for k in (0, 1))
            return count, f.box(tuple(map(f.point, leaf))) if leaf else None
        bands = [(self.catalog(n - 1, child), f.point(delta)) for child, delta in self.offsets(n, pose)]
        count = tuple(sum(row[0][k] for row, _ in bands) for k in (0, 1))
        corners = tuple(p for (_, bounds), delta in bands if bounds for p in f.rect(move(bounds, delta)))
        return count, f.box(corners) if corners else None

    def roots(self, n):
        assert n % 2 == 0
        return tuple((n, (k, (turn - n // 2) % 10, mirror),
                      self.scale(n, real.rotate(pos, -n // 2))) for k, turn, mirror, pos in self.seed)

    def root_level(self, outer, count):
        for n in range(0, 62, 2):
            if self.contains(outer, n) and sum(self.count(r)[0] for r in self.roots(n)) >= count:
                return n
        raise ValueError("Request exceeds the supported atlas depth")

    def contains(self, outer, n):
        p = self.power(n)
        assert p[1] == 0 and p[2] == p[3]
        radius = f.sub(f.scale(Fraction(1, 4), (p[0], -p[2])), (2, 0))
        if f.sign(radius) <= 0:
            return False
        square = f.mul(radius, radius)
        return all(f.sign(f.sub(square, norm(z))) > 0 for z in outer)

    def count(self, ref):
        return self.catalog(*ref[:2])[0]

    def bounds(self, ref):
        bounds = self.catalog(*ref[:2])[1]
        return move(bounds, f.point(ref[2])) if bounds else None

    def children(self, ref):
        n, pose, pos = ref
        assert n > 0
        return tuple((n - 1, child, ring.plus(pos, delta)) for child, delta in self.offsets(n, pose))

    def at(self, roots, path):
        ref = roots[path[0]]
        for i in path[1:]:
            ref = self.children(ref)[i]
        return ref

    def vertices(self, ref):
        n, pose, pos = ref
        assert n == 0
        return tuple(ring.plus(pos, z) for z in self.leaf(pose))

    def polygon(self, ref):
        return f.ccw(tuple(map(f.point, self.vertices(ref))))

    def expand(self, ref, kind):
        if not self.count(ref)[kind]:
            return
        if not ref[0]:
            yield ref
        else:
            for child in self.children(ref):
                yield from self.expand(child, kind)


def move(bounds, delta):
    return tuple((f.add(a, shift), f.add(b, shift)) for (a, b), shift in zip(bounds, delta, strict=True))


def norm(z):
    w, x, y, t = ring.multiply(z, ring.star(z))
    assert x == 0 and y == t
    return w, -y


def scan(atlas, roots, region, bulk):
    stats = Counter()
    stops = []
    pending = [((i,), r) for i, r in enumerate(roots)]
    while pending:
        path, ref = pending.pop()
        counts = atlas.count(ref)
        if not any(counts):
            continue
        stats["visited"] += 1
        bounds = atlas.bounds(ref)
        mark = region.classify(bounds) if bulk else ("E" if f.disjoint(bounds, region.bound) else "M")
        if mark == "M" and ref[0]:
            pending.extend(((*path, i), child) for i, child in enumerate(atlas.children(ref)))
            continue
        if mark == "M":
            stats["clipped"] += 1
            overlap = region.overlap(atlas.polygon(ref))
            full = AREAS[ref[1][0]]
            assert f.sign(overlap) >= 0 and f.sign(f.sub(full, overlap)) >= 0
            mark = "E" if overlap == f.Z else "F" if overlap == full else "C"
        else:
            overlap = f.Z
        stats[mark] += sum(counts)
        stops.append((path, ref, mark, overlap if mark == "C" else f.Z))
    return stops, dict(stats)


def weight(mark, partial, kind):
    return AREAS[kind] if mark == "F" else f.Z if mark == "E" else partial


def score(overlap, kind):
    return f.sub(f.scale(2, overlap), AREAS[kind])


def take(atlas, path, ref, kind, count):
    if count == atlas.count(ref)[kind]:
        yield path, kind
    else:
        for i, child in enumerate(atlas.children(ref)):
            use = min(count, atlas.count(child)[kind])
            if use:
                yield from take(atlas, (*path, i), child, kind, use)
                count -= use
            if not count:
                return
        assert not count


def choose(atlas, stops, count, ranked):
    offers = [(weight(mark, cut, k), k, path, ref) for path, ref, mark, cut in stops
              for k, population in enumerate(atlas.count(ref)) if population]
    assert count <= sum(atlas.count(ref)[k] for _, k, _, ref in offers)
    offers.sort(key=lambda r: (f.order(f.scale(-1, score(r[0], r[1]) if ranked else r[0])), r[1], r[2]))
    selected, total, areas, used = [], f.Z, f.Z, [0, 0]
    for overlap, kind, path, ref in offers:
        if not count:
            break
        size = min(count, atlas.count(ref)[kind])
        selected.extend(take(atlas, path, ref, kind, size))
        total = f.add(total, f.scale(size, overlap))
        areas = f.add(areas, f.scale(size, AREAS[kind]))
        used[kind] += size
        count -= size
    return dict(selected=sorted(selected), types=used, area=f.encode(areas), intersection=f.encode(total))


def solve(atlas, outer, region, count, bulk=True):
    assert type(count) is int and count >= 0
    level = atlas.root_level(outer, count)
    roots = atlas.roots(level)
    stops, stats = scan(atlas, roots, region, bulk)
    area = f.summation(f.scale(n, weight(mark, cut, k)) for _, ref, mark, cut in stops
                       for k, n in enumerate(atlas.count(ref)))
    assert area == region.area
    offers = [choose(atlas, stops, count, ranked) for ranked in (True, False)]
    for offer in offers:
        offer["error"] = f.encode(f.add(region.area, f.sub(f.decode(offer["area"]),
                                                            f.scale(2, f.decode(offer["intersection"])))))
    return dict(level=level, count=count, root_count=sum(sum(atlas.count(r)) for r in roots),
                region_area=f.encode(region.area), stats=stats, ranked=offers[0], naive=offers[1],
                frontier=[(path, mark, f.encode(cut)) for path, _, mark, cut in sorted(stops)])
