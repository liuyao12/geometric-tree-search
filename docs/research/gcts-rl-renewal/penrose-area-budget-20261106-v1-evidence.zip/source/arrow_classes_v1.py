"""Recover exact Penrose rules and quotient harmless changes of decoration."""
from collections import Counter
from itertools import product
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import discover_v1 as discovery
import standard_v1 as verify


ROOT = Path(__file__).resolve().parents[1]
AXES = (1, 3)
LIMITS = {"visits": 2000, "seconds": 15, "children": 8}
GAUGES = tuple(product((False, True), (False, True), (False, True), (-1, 1), (-1, 1)))


def frozen(x):
    if isinstance(x, list):
        return tuple(map(frozen, x))
    if isinstance(x, dict):
        return {k: frozen(v) for k, v in x.items()}
    return x


def read(name):
    return frozen(json.loads((ROOT / name).read_text()))


def save(name, result):
    (ROOT / name).write_text(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")


def key(marks, rules):
    return tuple(marks), tuple(tuple(sorted(r)) for r in rules)


def change_pose(parent, cell, flip):
    kind, turn, mirror, offset = cell
    if flip[kind]:
        turn += -AXES[kind] if mirror else AXES[kind]
        mirror = not mirror
    if flip[parent]:
        turn = AXES[parent]-turn
        mirror = not mirror
        offset = discovery.transform(AXES[parent], True, offset)
    return kind, turn % 10, mirror, offset


def change(system, gauge):
    marks, rules = system
    a, b, swap, s1, s2 = gauge
    flip = a, b
    sign = s1, s2

    def recode(arrow):
        return (1 if arrow > 0 else -1) * sign[abs(arrow)-1] * (3-abs(arrow) if swap else abs(arrow))

    # A reflected prototype reverses its base arrow. Each base has its own length,
    # so a per-length change of sign on that reserved channel restores +3.
    changed = [(recode(-t), 3, recode(-s)) if flip[k] else (recode(s), 3, recode(t))
               for k, (s, _, t) in enumerate(marks)]
    patterns = [[change_pose(parent, cell, flip) for cell in cells] for parent, cells in enumerate(rules)]
    return key(changed, patterns)


def one_magnitude(partitions):
    oriented = tuple(tuple(tuple(product(*shape)) for shape in group) for group in partitions)
    receipts = []
    for kind, group in enumerate(oriented):
        shapes = []
        for i, choices in enumerate(group):
            ok, failures = [], Counter()
            for j, cells in enumerate(choices):
                for a, b, c, d in product((-1, 1), repeat=4):
                    marks = ((a, 3, b), (c, 3, d))
                    channels = discovery.boundary_words(kind, cells, marks)
                    if channels is None:
                        failures["rejected"] += 1
                    else:
                        ok.append((j, marks))
            shapes.append(dict(index=i, poses=len(choices), checks=len(choices)*16,
                               rejected=failures["rejected"], accepted=ok))
        receipts.append(shapes)
    assert not any(row["accepted"] for row in receipts[0])
    return receipts


def run():
    discovery.qualification()
    geometry = [discovery.discover(k, LIMITS) for k in range(2)]
    partitions = tuple(frozen(x[0]) for x in geometry)
    systems, counts = discovery.find_marks(partitions)
    original = sorted(key(r["marks"], r["rules"]) for r in systems)
    remaining = set(original)
    assert len(remaining) == len(systems)
    groups = []
    while remaining:
        seed = min(remaining)
        orbit = {change(seed, g) for g in GAUGES}
        assert orbit <= remaining
        remaining.difference_update(orbit)
        groups.append(dict(representative=original.index(seed), members=sorted(original.index(r) for r in orbit)))
    by_system = []
    directions = verify.axes(2)
    for marks, rules in original:
        all_channels = {}
        for kind, cells in enumerate(rules):
            parent, _, outer, _ = verify.verify_patch(kind, 1, cells, marks, directions)
            words = verify.boundary_maps(kind, parent, outer, marks, directions)
            for channel, word in words.items():
                assert all_channels.setdefault(channel, word) == word
        assert len(all_channels) == 4
        by_system.append(dict(marks=marks, rules=rules))
    result = dict(partitions=partitions, counts=dict(counts, stages=[x[1] for x in geometry]),
                  systems=by_system, orbits=groups, gauges=len(GAUGES),
                  one_magnitude=one_magnitude(partitions))
    save("data/arrow-study-v1.json", result)
    print(len(original), "systems,", [len(r["members"]) for r in groups], "orbit sizes", flush=True)


if __name__ == "__main__":
    if not __debug__:
        raise RuntimeError("Search requires Python assertions")
    run()
