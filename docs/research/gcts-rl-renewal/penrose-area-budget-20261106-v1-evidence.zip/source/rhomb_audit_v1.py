"""Recompute the area cutoff with independent convex intersection vertices."""
from collections import Counter
from itertools import chain

import field_clip_v1 as f
from rhomb_rank_v1 import AREAS, weight


def hull_side(points):
    stack = []
    for p in points:
        while len(stack) >= 2 and f.sign(f.side(stack[-2], stack[-1], p)) <= 0:
            stack.pop()
        stack.append(p)
    return stack[:-1]


def meeting(a, b, c, d):
    u, v, w = f.between(b, a), f.between(d, c), f.between(c, a)
    denominator = f.determinant(u, v)
    if denominator == f.Z:
        return None
    first, second = f.determinant(w, v), f.determinant(w, u)
    sign = f.sign(denominator)
    if all(sign * f.sign(x) >= 0 and sign * f.sign(f.sub(denominator, x)) >= 0
           for x in (first, second)):
        return f.at(a, u, f.divide(first, denominator))
    return None


def overlap(a, b):
    ea, eb = tuple(f.edges(a)), tuple(f.edges(b))
    candidates = {p for p in chain(a, b) if f.inside(p, ea) and f.inside(p, eb)}
    candidates.update(p for u, v in ea for x, y in eb if (p := meeting(u, v, x, y)) is not None)
    points = sorted(candidates, key=lambda p: tuple(map(f.order, p)))
    return f.area(tuple(hull_side(points) + hull_side(reversed(points)))) if len(points) > 2 else f.Z


def check_measure(region, poly):
    bounds = f.box(poly)
    if f.disjoint(bounds, region.bound):
        return f.Z
    return f.sub(overlap(poly, region.outer), f.summation(overlap(poly, h) for h, hb, _ in region.voids
                                                         if not f.disjoint(bounds, hb)))


def audit(atlas, outer, region, result):
    level = result["level"]
    assert level % 2 == 0 and atlas.contains(outer, level)
    roots = atlas.roots(level)
    root_counts = tuple(sum(atlas.count(r)[k] for r in roots) for k in (0, 1))
    assert root_counts[0] >= result["count"] and sum(root_counts) == result["root_count"]
    logged = {tuple(path): (mark, f.decode(cut)) for path, mark, cut in result["frontier"]}
    assert len(logged) == len(result["frontier"])
    checked = {}
    pending = [((i,), ref) for i, ref in enumerate(roots)]
    flags = Counter()
    while pending:
        path, ref = pending.pop()
        counts = atlas.count(ref)
        if not any(counts):
            assert path not in logged
            continue
        if path not in logged:
            assert ref[0]
            pending.extend(((*path, i), child) for i, child in enumerate(atlas.children(ref)))
            continue
        mark, cut = logged[path]
        flags[mark] += sum(counts)
        if ref[0]:
            assert mark in ("F", "E") and cut == f.Z
            poly = f.rect(atlas.bounds(ref))
            assert check_measure(region, poly) == (f.area(poly) if mark == "F" else f.Z)
        else:
            kind = ref[1][0]
            measured = check_measure(region, atlas.polygon(ref))
            assert measured == weight(mark, cut, kind)
            assert mark == ("E" if measured == f.Z else "F" if measured == AREAS[kind] else "C")
            assert mark == "C" or cut == f.Z
        checked[path] = counts, mark, cut
    assert logged.keys() == checked.keys()
    assert all(flags[k] == result["stats"].get(k, 0) for k in ("F", "E", "C"))
    assert sum(flags.values()) == sum(root_counts)
    integral = f.summation(f.scale(n, weight(mark, cut, k)) for counts, mark, cut in checked.values()
                            for k, n in enumerate(counts))
    assert integral == region.area == f.decode(result["region_area"])

    receipts = {}
    for mode in ("ranked", "naive"):
        chosen = result[mode]
        used = Counter()
        by_type = [0, 0]
        earlier = {0: (), 1: ()}
        for path, kind in sorted((tuple(p), k) for p, k in chosen["selected"]):
            assert kind in (0, 1) and path and all(type(i) is int and i >= 0 for i in path)
            prev = earlier[kind]
            assert not prev or path[:len(prev)] != prev
            earlier[kind] = path
            ancestor = next((path[:i] for i in range(1, len(path) + 1) if path[:i] in checked), None)
            assert ancestor
            n = atlas.count(atlas.at(roots, path))[kind]
            assert n > 0
            used[ancestor, kind] += n
            by_type[kind] += n
        assert by_type == chosen["types"] and sum(by_type) == result["count"]
        enclosed, chosen_scores, excluded_scores = f.Z, [], [(-2, 0) if mode == "ranked" else f.Z]
        for path, (counts, mark, cut) in checked.items():
            for kind, population in enumerate(counts):
                n = used[path, kind]
                assert n <= population
                w = weight(mark, cut, kind)
                key = f.sub(f.scale(2, w), AREAS[kind]) if mode == "ranked" else w
                if n:
                    enclosed = f.add(enclosed, f.scale(n, w))
                    chosen_scores.append(key)
                if n < population:
                    excluded_scores.append(key)
        lowest = min(chosen_scores, key=f.order) if chosen_scores else None
        highest = max(excluded_scores, key=f.order)
        assert lowest is None or f.sign(f.sub(lowest, highest)) >= 0
        area = f.summation(f.scale(n, AREAS[k]) for k, n in enumerate(by_type))
        error = f.add(region.area, f.sub(area, f.scale(2, enclosed)))
        assert [f.encode(x) for x in (enclosed, area, error)] == [chosen[k] for k in ("intersection", "area", "error")]
        receipts[mode] = dict(min_selected=f.encode(lowest) if lowest is not None else None,
                              max_omitted=f.encode(highest), selected_records=len(chosen["selected"]))
    assert f.sign(f.sub(f.decode(result["naive"]["error"]), f.decode(result["ranked"]["error"]))) >= 0
    return dict(frontier=len(checked), **receipts)
