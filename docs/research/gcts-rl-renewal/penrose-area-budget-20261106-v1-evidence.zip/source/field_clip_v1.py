"""Exact real-field geometry for cyclotomic Penrose coordinates."""
from fractions import Fraction
from functools import cmp_to_key, lru_cache

import model_v1 as model

Z, U = (0, 0), (1, 0)
PHI = (0, 1)
REAL2 = ((2, 0), (-1, 1), (0, -1), (0, -1))
order = cmp_to_key(model.compare)


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def sub(a, b):
    return a[0] - b[0], a[1] - b[1]


def mul(a, b):
    x, y = a
    z, w = b
    return x * z + y * w, x * w + y * z + y * w


def scale(n, a):
    return n * a[0], n * a[1]


def divide(a, b):
    x, y = b
    norm = x * x + x * y - y * y
    c, d = mul(a, (x + y, -y))
    return Fraction(c) / norm, Fraction(d) / norm


def sign(a):
    return model.sign(*a)


def summation(values):
    result = Z
    for a in values:
        result = add(result, a)
    return result


@lru_cache(maxsize=40000)
def point(z):
    x, y = summation(scale(a, b) for a, b in zip(z, REAL2, strict=True))
    real = (x // 2 if x % 2 == 0 else Fraction(x, 2), y // 2 if y % 2 == 0 else Fraction(y, 2))
    return real, model.project(0, z)


def between(p, q):
    return tuple(sub(a, b) for a, b in zip(p, q, strict=True))


def determinant(a, b):
    return sub(mul(a[0], b[1]), mul(a[1], b[0]))


def side(a, b, p):
    return determinant(between(b, a), between(p, a))


def edges(poly):
    return zip(poly, poly[1:] + poly[:1])


def area(poly):
    return summation(determinant(a, b) for a, b in edges(poly))


def ccw(poly):
    return poly if sign(area(poly)) > 0 else poly[::-1]


def box(poly):
    return tuple((min(v, key=order), max(v, key=order)) for v in zip(*poly, strict=True))


def rect(bounds):
    (x0, x1), (y0, y1) = bounds
    return ((x0, y0), (x1, y0), (x1, y1), (x0, y1))


def disjoint(a, b):
    return any(model.compare(hi, low) <= 0 or model.compare(high, lo) <= 0
               for (lo, hi), (low, high) in zip(a, b, strict=True))


def inside(p, edges_, strict=False):
    return all(sign(side(a, b, p)) >= int(strict) for a, b in edges_)


def separated(a, b):
    return any(all(sign(side(p, q, r)) <= 0 for r in right)
               for left, right in ((a, b), (b, a)) for p, q in edges(left))


def at(a, delta, t):
    return tuple(add(x, mul(t, v)) for x, v in zip(a, delta, strict=True))


def clip(subject, cutter):
    """Convex intersection by successive half-plane clipping."""
    for a, b in edges(cutter):
        if not subject:
            return Z
        result = []
        for p, q in edges(subject):
            s, t = side(a, b, p), side(a, b, q)
            u, v = sign(s), sign(t)
            if u >= 0:
                result.append(p)
            if u * v < 0:
                result.append(at(p, between(q, p), divide(s, sub(s, t))))
        subject = tuple(result)
    return area(subject)


def polygon(ring):
    points = ccw(tuple(map(point, ring)))
    if len(points) < 3 or len(set(points)) != len(points):
        raise ValueError("A polygon needs distinct vertices")
    if not all(sign(side(a, b, p)) > 0 for a, b in edges(points) for p in points if p not in (a, b)):
        raise ValueError("Each ring must be strictly convex")
    return points


class Region:
    def __init__(self, outer, holes):
        self.outer = polygon(outer)
        self.holes = tuple(polygon(r) for r in holes)
        border = tuple(edges(self.outer))
        assert all(inside(p, border, True) for h in self.holes for p in h)
        assert all(separated(h, g) for i, h in enumerate(self.holes) for g in self.holes[:i])
        self.bound = box(self.outer)
        self.voids = tuple((h, box(h), tuple(edges(h))) for h in self.holes)
        self.area = sub(area(self.outer), summation(area(h) for h in self.holes))

    def classify(self, bounds):
        if disjoint(bounds, self.bound):
            return "E"
        poly = rect(bounds)
        if separated(poly, self.outer):
            return "E"
        for h, hb, he in self.voids:
            if not disjoint(bounds, hb) and all(inside(p, he) for p in poly):
                return "E"
        if all(inside(p, tuple(edges(self.outer))) for p in poly) and all(
            disjoint(bounds, hb) or separated(poly, h) for h, hb, _ in self.voids
        ):
            return "F"
        return "M"

    def overlap(self, poly, intersect=clip):
        bound = box(poly)
        if disjoint(bound, self.bound) or separated(poly, self.outer):
            return Z
        return sub(intersect(poly, self.outer), summation(intersect(poly, h) for h, hb, _ in self.voids
                                                          if not disjoint(bound, hb) and not separated(poly, h)))


def encode(value):
    return [[p.numerator, p.denominator] for p in value]


def decode(value):
    return tuple(Fraction(*p) for p in value)
