const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/penrose-area-budget-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#score mjx-container").first().waitFor();
      const patch = page.locator(".patch:visible");
      assert.equal(await patch.locator("polygon:visible").count(), 10);
      assert.equal(await patch.locator(".thin:visible").count(), 2);
      assert.ok(await patch.locator(".request").evaluate(node => node.getBBox().width > 0));
      await page.selectOption("#mode", "naive");
      assert.equal(await patch.locator("polygon:visible").count(), 10);
      assert.equal(await patch.locator(".thin:visible").count(), 0);
      await page.selectOption("#mode", "difference");
      assert.equal(await patch.locator("polygon:visible").count(), 12);
      await page.selectOption("#shape", "two-holes-near-area");
      await page.selectOption("#mode", "ranked");
      assert.equal(await patch.locator("polygon:visible").count(), 173);
      assert.equal((await patch.locator(".request").getAttribute("d")).split("M").length, 4);
      assert.equal(await page.locator("#comparison tbody tr").count(), 9);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.equal(await page.evaluate(() => document.documentElement.scrollWidth), width);
      assert.deepEqual(errors, []);
      console.log("Verified", width, "px, score comparison, whole-rhomb counts and two holes.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
