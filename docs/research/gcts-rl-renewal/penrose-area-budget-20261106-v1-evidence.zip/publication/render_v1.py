"""Render exact comparisons and the selectable whole-rhomb outlines."""
from decimal import Decimal, localcontext
from fractions import Fraction
import json
from math import pi, sin
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
import field_clip_v1 as f
from rhomb_study_v1 import load

NAME = "penrose-area-budget-20261106-v1"
TITLE = "Choose a movable Penrose boundary at a fixed rhomb count"
LABELS = {
    "small-window": "Ten rhombs near the origin",
    "offset-window": "Offset window",
    "two-holes": "Two holes, 100 rhombs",
    "two-holes-near-area": "Two holes, 173 rhombs",
    "diagonal-strip": "Diagonal strip",
    "medium-window": "Medium window",
    "wide-window": "Wide window",
    "distant-window": "Distant window",
    "padding-budget": "Count beyond positive overlap",
}
VIEWS = ("small-window", "two-holes-near-area", "offset-window")


def number(x):
    x = Fraction(x)
    return Decimal(x.numerator) / Decimal(x.denominator)


def approx(value):
    a, b = value
    with localcontext() as ctx:
        ctx.prec = 50
        phi = (1 + Decimal(5).sqrt()) / 2
        return number(a) + number(b) * phi


def display(value):
    return f"{approx(f.scale(Fraction(1, 2), f.decode(value))):.3f}"


def exact(value):
    a, b = f.scale(Fraction(1, 2), f.decode(value))
    assert a.denominator == b.denominator == 1
    sign = "+" if b > 0 else "-"
    return r"\(" + f"{a}{sign}{abs(b)}" + r"\varphi\)"


def drawing(z):
    x, y = f.point(tuple(z))
    return float(approx(x)), -sin(pi / 5) * float(approx(y))


def points(ring):
    return " ".join(f"{x:.3f},{y:.3f}" for x, y in map(drawing, ring))


def selection(atlas, roots, result):
    return {tuple(atlas.vertices(leaf)): k for path, k in result["selected"]
            for leaf in atlas.expand(atlas.at(roots, path), k)}


def window(atlas, row):
    r = row["result"]
    roots = atlas.roots(r["level"])
    chosen = selection(atlas, roots, r["ranked"])
    baseline = selection(atlas, roots, r["naive"])
    assert len(chosen) == len(baseline) == r["count"]
    tiles = {**chosen, **baseline}
    all_points = [drawing(p) for ring in (*tiles, row["outer"]) for p in ring]
    low = [min(v) - .45 for v in zip(*all_points)]
    high = [max(v) + .45 for v in zip(*all_points)]
    box = " ".join(f"{v:.3f}" for v in (*low, high[0] - low[0], high[1] - low[1]))
    outline = " ".join("M" + points(v) + "Z" for v in (row["outer"], *row["holes"]))
    svg = []
    for tile, k in sorted(tiles.items()):
        role = "both" if tile in chosen and tile in baseline else "ranked-only" if tile in chosen else "naive-only"
        svg.append(f'<polygon class="{role} {"thin" if k == 0 else "thick"}" points="{points(tile)}"/>')
    key = row["name"]
    hidden = "" if key == VIEWS[0] else " hidden"
    captions = []
    for mode, label in (("ranked", "Area-aware selection"), ("naive", "Overlap-only selection")):
        a, b = r[mode]["types"]
        captions.append(f'<p class="mode-caption {mode}">{label} uses {a} thin and {b} thick rhombs. '
                        f'Disagreement area is {display(r[mode]["error"])} thin-rhomb areas.</p>')
    return (f'<article class="patch" data-name="{key}"{hidden}><svg role="img" aria-label="{LABELS[key]}" viewBox="{box}">'
            f'<path class="backdrop" d="{outline}"/><g>{"".join(svg)}</g><path class="request" d="{outline}"/></svg>'
            f'{"".join(captions)}<p class="mode-caption difference">The two selections have '
            f'{len(chosen.keys() & baseline.keys())} rhombs in common.</p></article>')


def main():
    atlas, _ = load()
    data = json.loads((ROOT / "data/penrose-area-v1.json").read_text())
    rows = {r["name"]: r for r in data["rows"]}
    table = []
    for name, row in rows.items():
        r = row["result"]
        leaf = "—" if row["leaf_clips"] is None else f'{row["leaf_clips"]:,}'
        table.append(f'<tr><th scope="row">{LABELS[name]}</th><td>{r["count"]:,}</td>'
                     f'<td>{r["stats"]["clipped"]:,}</td><td>{leaf}</td>'
                     f'<td>{row["receipt"]["ranked"]["selected_records"]:,}</td>'
                     f'<td>{display(r["ranked"]["error"])}</td><td>{display(r["naive"]["error"])}</td></tr>')
    values = dict(title=TITLE, stem=NAME, table="".join(table), example=exact(rows["small-window"]["advantage"]),
                  wide_gap=exact(rows["wide-window"]["advantage"]),
                  options="".join(f'<option value="{n}">{LABELS[n]}</option>' for n in VIEWS),
                  windows="".join(window(atlas, rows[n]) for n in VIEWS))
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.patch[hidden]{display:none}.control{margin:1rem 0}
.patch svg{width:100%;max-height:32rem;background:#f8fbfc}
.patch polygon{stroke:#4f6667;stroke-width:.024;stroke-linejoin:round}
.patch .thin{fill:#87c3b5}.patch .thick{fill:#90b9df}
.backdrop{fill:#f5e9d7;fill-rule:evenodd}
.request{fill:none;stroke:#794d1c;stroke-width:.055;stroke-dasharray:.2 .12}
#viewer[data-mode=ranked] .naive-only,#viewer[data-mode=naive] .ranked-only{display:none}
.mode-caption{display:none}
#viewer[data-mode=ranked] .mode-caption.ranked,#viewer[data-mode=naive] .mode-caption.naive,
#viewer[data-mode=difference] .mode-caption.difference{display:block}
#viewer[data-mode=difference] .both{fill:#e0e8eb}
#viewer[data-mode=difference] .ranked-only{fill:#5fb798}
#viewer[data-mode=difference] .naive-only{fill:#e9b374}
</style>""")
    body = (ROOT / "publication/rhomb-body-v1.html").read_text()
    for key, value in values.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
