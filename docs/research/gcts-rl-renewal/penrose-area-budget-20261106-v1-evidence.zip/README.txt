Choose a movable Penrose boundary at a fixed rhomb count

Use Python 3.12 with assertions enabled. From the archive root:

  python3 -I -S -B source/rhomb_study_v1.py
  python3 -I -S -B publication/render_v1.py

The first command audits pairing and reruns the requests. It checks the
frontier, the area-aware cutoff, and the leaf-clipping control. Add --build
to regenerate its data. The second command regenerates the notebook.
The included rule and seed come from the certified centered Penrose study.
The manifest gives SHA-256 for each included input and result.
