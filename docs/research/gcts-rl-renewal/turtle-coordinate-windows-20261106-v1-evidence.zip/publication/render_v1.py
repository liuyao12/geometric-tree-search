"""Draw small exact windows in local coordinates, including far translations."""
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from cluster_v1 import Model, load
from golden_geometry_v1 import sub

def euclidean(p):
    x,y=p
    return x+y/2,sqrt(3)*y/2


class Diagram:
    def __init__(self,points,width=600,height=400,disk=None):
        x,y=map(list,zip(*(euclidean(p) for p in points)))
        if disk:
            center,radius=disk
            a,b=euclidean(center)
            x.extend((a-radius,a+radius))
            y.extend((b-radius,b+radius))
        self.w,self.h=width,height
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2
        self.scale=min((width-34)/(max(x)-min(x)),(height-34)/(max(y)-min(y)))

    def at(self,p):
        x,y=euclidean(p)
        u,v=self.center
        return self.w/2+(x-u)*self.scale,self.h/2-(y-v)*self.scale

    def poly(self,shape,cls,fill):
        points=" ".join(f"{a:.3f},{b:.3f}" for a,b in map(self.at,shape))
        return f'<polygon class="{cls}" points="{points}" fill="{fill}"/>'

    def lines(self,edges,cls):
        parts=[]
        for edge in sorted(edges):
            (x,y),(u,v)=map(self.at,edge)
            parts.append(f"M{x:.3f},{y:.3f}L{u:.3f},{v:.3f}")
        return f'<path class="{cls}" d="{"".join(parts)}"/>'

    def circle(self,center,radius,cls,*,pixels=False):
        x,y=self.at(center)
        r=radius if pixels else radius*self.scale
        return f'<circle class="{cls}" cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}"/>'

    def svg(self,title,content):
        return f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{escape(title)}">{content}</svg>'



LABELS=("Origin rectangle","Offset rectangle","Distant rectangle",
        "Trillion-unit rectangle","Trillion-unit concave window","Very distant rectangle","Exact six-tile boundary")
PALETTE=("#a6c9e7","#abdad0","#95cbbb","#bed9ef")


def draw(model,ring,tiles,label,index=None):
    anchor=ring[0]
    window=tuple(sub(p,anchor) for p in ring)
    patches=[tuple(sub(p,anchor) for p in model.poly(t)) for t in tiles]
    diagram=Diagram([*window,*(p for q in patches for p in q)],720,380)
    polygons=[diagram.poly(q,"tile",PALETTE[t[0]%len(PALETTE)])
              for t,q in zip(tiles,patches,strict=True)]
    polygons.append(diagram.poly(window,"macro-outline","none"))
    attrs="" if index is None else f' data-case="{index}"'+(" hidden" if index else "")
    return f'<figure{attrs}>{diagram.svg(label,"".join(polygons))}<figcaption>{escape(label)}. {len(tiles)} intersecting tiles.</figcaption></figure>'


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    data=load("data/windows-v1.json")
    gallery=[]
    options=[]
    rows=[]
    for i,(label,case) in enumerate(zip(LABELS,data["runs"],strict=True)):
        gallery.append(draw(model,case["polygon"],case["tiles"],label,i))
        options.append(f'<option value="{i}">{escape(label)}</option>')
        fields=(case["level"],case["counts"]["visited"],case["counts"]["polygon_checks"],
                case["returned"],case["excess_double_area"])
        cells="".join(f"<td>{v:,}</td>" for v in fields)
        rows.append(f'<tr><th scope="row">{escape(label)}</th>{cells}</tr>')
    control=data["strip_control"]
    values=dict(OPTIONS="".join(options),GALLERY="".join(gallery),RUNS="".join(rows),
                CONTROL=draw(model,control["polygon"],control["tiles"],"Matched strip query"))
    text=(ROOT/"publication/notebook-v1.html").read_text()
    for name,markup in values.items():
        text=text.replace(f"%%{name}%%",markup)
    assert "%%" not in text
    (ROOT/"report/turtle-coordinate-windows-20261106-v1.html").write_text(text)


if __name__=="__main__":
    main()
