# Replay the exact Turtle window queries

Use Python 3.12. Run from the extracted archive root.

    python3 -I -S -B source/window_origin_v1.py
    python3 -I -S -B source/window_v1.py
    python3 -I -S -B publication/render_v1.py

The first step checks the inputs against the pinned coordinate-rule
evidence. The second runs all seven exact window audits and the strip
ablation. Use a JSON reader with arbitrary-precision integers for the
largest coordinates. Compare data/windows-v1.json to publication/replay-v1.json.
Run node publication/check_v1.cjs for the reader check. It needs Playwright,
Chromium, and access to the notebook's MathJax script. Set GCTS_CHROME and
GCTS_PLAYWRIGHT for custom installations.
