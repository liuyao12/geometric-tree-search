const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");

(async () => {
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
    const target = pathToFileURL(path.join(__dirname, "../report/turtle-coordinate-windows-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || target);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 4);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    const gallery = page.locator("#window-gallery");
    assert.equal(await gallery.locator("figure:visible").count(), 1);
    await page.selectOption("#window-choice", "5");
    assert.equal(await gallery.locator("figure:visible polygon.tile").count(), 41);
    if (!process.argv[2]) await gallery.screenshot({ path: path.join(__dirname, "far-window-v1.png") });
    await page.selectOption("#window-choice", "6");
    assert.equal(await gallery.locator("figure:visible polygon.tile").count(), 6);
    if (!process.argv[2]) await gallery.screenshot({ path: path.join(__dirname, "fixed-window-v1.png") });
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    const receipt={status:"CHECKED_COMPRESSED_TURTLE_WINDOW_READER",panels:7,
      farTiles:41,fixedTiles:6,mobileNoOverflow:true};
    const filename=process.argv[2]?"browser-live-v1.json":"browser-v1.json";
    fs.writeFileSync(path.join(__dirname,filename), JSON.stringify(receipt,null,2)+"\n");
    console.log(receipt.status);
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
