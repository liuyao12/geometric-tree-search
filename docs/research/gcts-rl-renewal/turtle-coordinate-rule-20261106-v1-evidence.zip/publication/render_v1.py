"""Render the recovered coordinate rules and the directly constructed level five."""
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import Geometry
from cluster_v1 import Model, load
from collar_audit_v1 import freeze
from coordinate_v1 import strip
from layer_audit_v1 import cycles

STEM="turtle-coordinate-rule-20261106-v1"
def euclidean(p):
    x,y=p
    return x+y/2,sqrt(3)*y/2


class Diagram:
    def __init__(self,points,width=600,height=400,disk=None):
        x,y=map(list,zip(*(euclidean(p) for p in points)))
        if disk:
            center,radius=disk
            a,b=euclidean(center)
            x.extend((a-radius,a+radius))
            y.extend((b-radius,b+radius))
        self.w,self.h=width,height
        self.center=(min(x)+max(x))/2,(min(y)+max(y))/2
        self.scale=min((width-34)/(max(x)-min(x)),(height-34)/(max(y)-min(y)))

    def at(self,p):
        x,y=euclidean(p)
        u,v=self.center
        return self.w/2+(x-u)*self.scale,self.h/2-(y-v)*self.scale

    def poly(self,shape,cls,fill):
        points=" ".join(f"{a:.3f},{b:.3f}" for a,b in map(self.at,shape))
        return f'<polygon class="{cls}" points="{points}" fill="{fill}"/>'

    def lines(self,edges,cls):
        parts=[]
        for edge in sorted(edges):
            (x,y),(u,v)=map(self.at,edge)
            parts.append(f"M{x:.3f},{y:.3f}L{u:.3f},{v:.3f}")
        return f'<path class="{cls}" d="{"".join(parts)}"/>'

    def circle(self,center,radius,cls,*,pixels=False):
        x,y=self.at(center)
        r=radius if pixels else radius*self.scale
        return f'<circle class="{cls}" cx="{x:.3f}" cy="{y:.3f}" r="{r:.3f}"/>'

    def svg(self,title,content):
        return f'<svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{escape(title)}">{content}</svg>'


def shape_path(diagram, edges, cls, fill=None):
    rings = []
    for ring in cycles(edges):
        points = [diagram.at(p) for p, _ in ring]
        pairs = "L".join(f"{x:.3f},{y:.3f}" for x, y in points)
        rings.append(f"M{pairs}Z")
    paint = f' fill="{fill}"' if fill else ""
    return f'<path class="{cls}" d="{"".join(rings)}"{paint}/>'


def patch_figure(geom, row, colors, title, caption, width=680, height=400):
    outer = geom.boundary(row["patch"])
    diagram = Diagram([p for p, _ in outer], width, height)
    content = [shape_path(diagram, geom.boundary(part), "patch-piece", color)
               for part, color in zip(row["pieces"], colors, strict=True)]
    content.append(shape_path(diagram, outer, "macro-outline"))
    return f'<figure>{diagram.svg(title, "".join(content))}<figcaption>{caption}</figcaption></figure>'



COLORS={"P":("#95cbbb","#abdad0","#88c2b5"),"T":("#a6c9e7",),"S":("#f0c272",)}
ROLES=(
    ("p_center","Central half-turn child",r"(0,0)"),
    ("p_arm","First half-turn pair",r"(a+b,a-2b)"),
    ("p_side","Second half-turn pair",r"(-a+2b,2a-b)"),
    ("p_corner","Corner triangles",r"(2a+b,a-b)"),
    ("p_cap","Cavity caps",r"(b,a-b)"),
    ("strip","Strip anchor",r"(5-4a+b,2-a+b)"),
    ("t_middle","Middle half-turn children",r"(b,a-b)"),
    ("t_corner","Outer triangles",r"(0,2a)"),
    ("t_cap","Center cap",r"(0,0)"),
)
TURNS={0:"I",3:"R",4:"R^2",6:"H",9:"HR"}


def tex(s):
    return rf"\({s}\)"


def name(k,n):
    return tex(f"{k}_{n}")


def role_rows(roles):
    output=[]
    for key,label,formula in ROLES:
        model=roles[key]
        train=model["training"]
        remain=model["checked"]-train
        parent="P" if key=="strip" else key[0].upper()
        output.append(f'<tr><th scope="row">{tex(parent+"_n")}</th>'
                      f'<td>{label}</td><td>{tex(formula)}</td><td>{train}</td><td>{remain}</td></tr>')
    return "".join(output)


def address_rows(levels):
    output=[]
    for k in ("T","P"):
        for label,n,g,xy in levels[f"{k}5"]["children"]:
            address=tex(f"({xy[0]},{xy[1]})")
            output.append(f'<tr><th scope="row">{name(k,5)}</th><td>{name(label,n)}</td>'
                          f'<td>{tex(TURNS[g])}</td><td>{address}</td></tr>')
    return "".join(output)


def paint(rows):
    index=0
    colors=[]
    for kind,n,_,_ in rows:
        if kind=="T" and n==3:
            colors.append("#d4bde8")
        elif kind=="P":
            colors.append(COLORS[kind][index % len(COLORS[kind])])
            index+=1
        else:
            colors.append(COLORS[kind][0])
    return tuple(colors)


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    geom=Geometry(model)
    result=freeze(load("data/coordinate-v1.json"))
    saved=freeze(load("data/predictions-v1.json"))
    words=result["rule"]["words"]
    bases=result["rule"]["bases"]
    alphabet=freeze(load("input/recovered-production-v1.json"))["alphabet"]
    library={("P",0):bases["P0"],("T",1):bases["T1"]}
    figures=[]
    for n,word in enumerate(words[2::2],1):
        library["S",n]=strip(alphabet,word)
        for kind in ("T","P"):
            ident=f"{kind}{n}"
            row=result["levels"][ident]
            addresses=row["children"]
            pieces=[geom.moved(library[k,i],g,xy) for k,i,g,xy in addresses]
            patch=tuple(sorted(tile for part in pieces for tile in part))
            library[kind,n]=patch
            if n==5:
                assert patch==saved[ident]
                summary=f'{name(kind,n)} · {row["tiles"]:,} Turtles · {row["perimeter"]:,} boundary segments'
                figures.append(patch_figure(geom,dict(patch=patch,pieces=pieces),paint(addresses),
                                            f"{kind}{n} with {row['tiles']:,} Turtles",summary))
    template=(ROOT/"publication/notebook-v1.html").read_text()
    tokens=dict(STEM=STEM,FIGURES="".join(figures),ADDRESSES=address_rows(result["levels"]),
                ROLES=role_rows(result["rule"]["roles"]))
    for key,value in tokens.items():
        template=template.replace(f"%%{key}%%",value)
    assert "%%" not in template
    (ROOT/f"report/{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
