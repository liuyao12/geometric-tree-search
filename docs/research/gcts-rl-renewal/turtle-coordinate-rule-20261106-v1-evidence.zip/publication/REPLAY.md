# Replay the learned Turtle coordinate rule

Use Python 3.12. The experiments and proof check use the standard library.
Run from the extracted archive root. Withhold the reference files during
the fitting and prediction step.

    mkdir withheld
    mv input/reference-* withheld/
    python3 -I -S -B source/coordinate_v1.py
    mv withheld/reference-* input/
    rmdir withheld
    python3 -I -S -B source/reference_replay_v1.py
    python3 -I -S -B source/bridge_v1.py
    python3 -I -S -B publication/render_v1.py

The evidence includes the earlier plane certificate as a pinned nested
archive. Its verifier replays with a temporary runtime pin for the active
Python build. The original source and input pins are checked.

Compare the four scientific files with the hashes in
`publication/replay-v1.json`. Run `node publication/check_v1.cjs` for
the notebook browser check. It uses Playwright, Chromium, and access to
the notebook MathJax script. Set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for
custom installations.
