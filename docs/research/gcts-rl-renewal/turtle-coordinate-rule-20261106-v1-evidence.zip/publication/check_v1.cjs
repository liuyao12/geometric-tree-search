const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-coordinate-rule-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelector("#proof mjx-container[display='true']"));
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("#construction svg").count(), 2);
    assert.equal(await page.locator("#construction .patch-piece").count(), 18);
    assert.equal(await page.locator("#construction tbody tr").count(), 18);
    assert.equal(await page.locator("#fit tbody tr").count(), 9);
    const figures = await page.locator("#construction .gallery").innerText();
    assert(figures.includes("30,624") && figures.includes("38,568"));
    assert.equal(await page.locator("#proof mjx-container[display='true']").count(), 1);
    if (!process.argv[2]) {
      await page.locator("#construction .gallery").screenshot({ path: path.join(__dirname, "assembly-v1.png") });
      await page.locator("#fit .table").screenshot({ path: path.join(__dirname, "roles-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_TURTLE_COORDINATE_READER", triangleTiles: 30624,
      frameTiles: 38568, assemblyPanels: 2, childAddresses: 18, fittedRoles: 9, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
