"""Replay the pinned all-level proof and check the origin of bridge inputs."""
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import save
from cluster_v1 import Model, load, pin


def main():
    path=ROOT/"input/reference-plane-v1.zip"
    origin=load("input/reference-origin-v1.json")
    archive_key="report/turtle-golden-hex-plane-proof-20261106-v1-evidence.zip"
    assert pin(path)["sha256"]==origin[archive_key]
    with ZipFile(path) as z, TemporaryDirectory(prefix="gcts-plane-replay-") as temp:
        root=Path(temp)
        for key,digest in origin.items():
            if key!=archive_key:
                assert sha256(z.read(key)).hexdigest()==digest
        for f in ("cluster_v1","golden_geometry_v1","golden_growth_v1","triangle_geometry_v1"):
            name=f"source/{f}.py"
            assert z.read(name)==(ROOT/name).read_bytes()
        archived_model=Model(json.loads(z.read("input/exact-point-model-v1.json")))
        local=Model(load("input/exact-point-model-v1.json"))
        assert vars(archived_model)==vars(local)
        growth={x["id"]:x["patch"] for x in json.loads(z.read("input/growth-v1.json"))["levels"]}
        recovery={x["name"]:x["patch"] for x in json.loads(z.read("input/recovery-v1.json"))["levels"]}
        assert {"P0":recovery["P0"],"T1":growth["T1"]}==load("input/reference-bases-v1.json")
        assert {k:growth[k] for k in ("P5","T5")}==load("input/reference-witnesses-v1.json")

        protocol=json.loads(z.read("protocol-v1.json"))
        runtime=pin(Path(sys.executable))
        for name,digest in protocol["pins"].items():
            raw=z.read(name)
            assert dict(bytes=len(raw),sha256=sha256(raw).hexdigest())==digest,name
        (root/"source").mkdir()
        (root/"input").mkdir()
        (root/"data").mkdir()
        for name in z.namelist():
            p=PurePosixPath(name)
            if (len(p.parts)==2 and (p.parts[0],p.suffix) in (("source",".py"),("input",".json"))
                    or name=="data/symbolic-v1.json"):
                (root/p).write_bytes(z.read(name))
        protocol["runtime"]=runtime
        (root/"protocol-v1.json").write_text(json.dumps(protocol))
        command=[sys.executable,"-I","-S","-B",str(root/"source/verify_plane_v1.py")]
        subprocess.run(command,cwd=root,stdout=subprocess.PIPE,check=True)
        proof=root/"data/plane-v1.json"
        assert proof.read_bytes()==z.read("data/plane-v1.json")
        certificate=json.loads(proof.read_text())
        save("data/plane-replay-v1.json",dict(status="REPLAYED_PINNED_PLANE_CERTIFICATE",
            archive=pin(path),result=pin(proof),
            induction_from=certificate["induction_from"],disk_bound=certificate["disk_bound"],
            nested_odd_levels=certificate["nested_odd_levels"]))
    print("Replayed the pinned all-level proof byte for byte.",flush=True)


if __name__=="__main__":
    main()
