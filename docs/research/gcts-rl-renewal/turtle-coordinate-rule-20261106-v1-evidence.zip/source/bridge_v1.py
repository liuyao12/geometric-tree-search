"""Transport the recovered coordinate rules to the checked Golden Hex recurrence."""
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from itertools import product
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from cluster_v1 import Model, load, mat
from collar_audit_v1 import freeze
from coordinate_v1 import children, read_inputs, strip
from golden_geometry_v1 import strip as reference_strip, words as reference_words
from golden_growth_v1 import p_children, t_children
from scaffold_v1 import centred


@dataclass(frozen=True)
class Affine:
    constant: Fraction = 0
    current: Fraction = 0
    previous: Fraction = 0

    def __add__(self, other):
        other=other if isinstance(other,Affine) else Affine(other)
        return Affine(self.constant+other.constant,self.current+other.current,self.previous+other.previous)

    __radd__=__add__

    def __mul__(self, scalar):
        return Affine(self.constant*scalar,self.current*scalar,self.previous*scalar)

    __rmul__=__mul__

    def __neg__(self):
        return self*-1

    def __sub__(self, other):
        return self+-other

    def __rsub__(self, other):
        return -self+other


def coefficients(point):
    values=tuple(v if isinstance(v,Affine) else Affine(v) for v in point)
    rows=tuple(tuple(getattr(v,key) for v in values)
               for key in ("constant","current","previous"))
    assert all(Fraction(x).denominator==1 for row in rows for x in row)
    return tuple(tuple(map(int,row)) for row in rows)


def affine_rows(rule):
    return [(kind,n,g,coefficients(p)) for kind,n,g,p in rule(Affine(current=1),Affine(previous=1))]


def reference(model,kind,n,a,b):
    def axial(u,v):
        return u,Fraction(1,2)*(v-u)
    if kind=="P":
        return p_children(n,a,a-b,b,a-2*b,axial)
    return [x for x in t_children(model,n,a,a-2*b,axial) if x[1]>=1 or x[0]=="P"]


def signature(model,rows,symmetry):
    return Counter((kind,i,min(model.compose[g,h] for h in symmetry[kind]),points)
                   for kind,i,g,points in rows)


def conjugate(model,rows,parent,frames):
    inverse={kind:next(h for h in model.groups if model.compose[g,h]==0)
             for kind,g in frames.items()}
    frame=frames[parent]
    return [(kind,n,model.compose[model.compose[frame,g],inverse[kind]],
             tuple(mat(model.groups[frame],p) for p in coefficients))
            for kind,n,g,coefficients in rows]


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    geom=Geometry(model)
    rule=freeze(load("data/coordinate-v1.json"))["rule"]
    alphabet,_,_=read_inputs()
    ref_bases=freeze(load("input/reference-bases-v1.json"))
    symmetry={"P":(0,6),"T":(0,3,4),"S":(0,)}
    for kind,level in (("P",0),("T",1)):
        base=rule["bases"][f"{kind}{level}"]
        assert all(geom.moved(base,g)==base for g in symmetry[kind])
    assert tuple(tuple(map(int,w)) for w in reference_words(11)[:len(rule["words"])])==rule["words"]
    assert rule["words"][:2]==((0,),(0,0,1))
    # Equal starting letters and equal steps imply equal transformed strips of any length.
    probes=((0,),(1,),(0,0),(1,1))
    align_s=[g for g in model.groups if all(
        geom.moved(strip(alphabet,w),g)==tuple(sorted(reference_strip("".join(map(str,w)))))
        for w in probes)]
    align=[]
    for kind in ("P","T"):
        name=f"{kind}{0 if kind=='P' else 1}"
        target=centred(geom,ref_bases[name])
        align.append([g for g in model.groups if geom.moved(rule["bases"][name],g)==target])

    pairs={}
    for kind,n in product(("P","T"),range(1,4)):
        prior=affine_rows(lambda a,b: children(model,rule,kind,n,a,b))
        target=affine_rows(lambda a,b: reference(model,kind,n,a,b))
        for rotation in symmetry[kind]:
            rotated=[(k,i,model.compose[rotation,g],tuple(mat(model.groups[rotation],p) for p in pos))
                     for k,i,g,pos in prior]
            assert signature(model,rotated,symmetry)==signature(model,prior,symmetry)
        pairs[kind,n]=prior,target
    accepted=[]
    for p,t,s in product(*align,align_s):
        frames=dict(P=p,T=t,S=s)
        if all(signature(model,conjugate(model,prior,kind,frames),symmetry)==signature(model,target,symmetry)
               for (kind,_),(prior,target) in pairs.items()):
            accepted.append(frames)
    assert accepted
    frames=accepted[0]
    for kind,gs in symmetry.items():
        inverse=next(h for h in model.groups if model.compose[frames[kind],h]==0)
        assert {model.compose[model.compose[frames[kind],g],inverse] for g in gs}==set(gs)
    predictions=freeze(load("data/predictions-v1.json"))
    targets=freeze(load("input/reference-witnesses-v1.json"))
    matches={}
    for name,patch in predictions.items():
        target=centred(geom,targets[name])
        assert geom.moved(patch,frames[name[0]])==target,name
        matches[name]=len(patch)
    save("data/bridge-v1.json",dict(status="CHECKED_COEFFICIENTWISE_GOLDEN_HEX_CONJUGACY",
        frames=frames,equivalent_frames=len(accepted),finite_exact_matches=matches,
        child_symmetries=symmetry,
        cases=[dict(kind=k,level=n,all_later_levels=(n==3),addresses=len(x))
               for (k,n),(x,_) in pairs.items()],
        reference_origin=load("input/reference-origin-v1.json")))
    print("coefficientwise frames",frames,"finite matches",matches,flush=True)


if __name__=="__main__":
    main()
