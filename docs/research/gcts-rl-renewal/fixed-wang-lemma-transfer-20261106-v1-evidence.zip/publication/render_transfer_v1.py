"""Publish the branching calibration, receptor composition, and proof reader."""

from collections import defaultdict
from html import escape
import json
from pathlib import Path
from statistics import median
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from shared_reader_v1 import ROOT, STYLE, clause, load, math, panel, table, title

STEM = "fixed-wang-lemma-transfer-20261106-v1"
OLD = "fixed-wang-serial-suffix-20261105-v1.html"


def name(identifier):
    return title(identifier).replace("odd-cycle-", "Odd cycle ").replace("broken-cycle-", "Broken cycle ").replace(
        "pigeonhole-", "Pigeonhole ")


def plot(outer, bank, atoms):
    leaves = outer["leaves"]
    steps = outer["steps"]
    levels = [0] * len(leaves)
    for a, b, _, _ in steps:
        levels.append(1 + max(levels[a], levels[b]))
    by_level = defaultdict(list)
    for i, level in enumerate(levels):
        by_level[level].append(i)
    positions = {i: (720 * (j + 1) / (len(nodes) + 1), 32 + 62 * level)
                 for level, nodes in by_level.items() for j, i in enumerate(nodes)}
    rectangles = []
    rules = []
    edges = []
    for i, (x, y) in positions.items():
        if i < len(leaves):
            earlier = tuple(leaves[i]) not in bank
            label = f"Receptor {i + 1}"
            color = "#e7dbef" if earlier else "#dcebe3"
            note = "Earlier checked cluster" if earlier else "Source clause"
            row = leaves[i]
        else:
            j = i - len(leaves)
            a, b, _, row = steps[j]
            label, color, note = f"Step {j + 1}", "#dce7f5", "Resolution"
            for ref in (a, b):
                ax, ay = positions[ref]
                edges.append(f'<path d="M{ax:.1f} {ay + 16} L{x:.1f} {y - 17}" stroke="#657486" '
                             'stroke-width="1.5" marker-end="url(#cluster-arrow)"></path>')
        rectangles.append(f'<rect x="{x - 47:.1f}" y="{y - 15}" width="94" height="30" rx="5" fill="{color}"></rect>'
                          f'<text x="{x:.1f}" y="{y + 5}" text-anchor="middle">{label}</text>')
        rules.append(f'<li><strong>{label}</strong> · {note}<div class="scroll">{math(clause(row, atoms))}</div></li>')
    svg = (f'<svg class="cluster-chart" viewBox="0 0 720 {max(y for _, y in positions.values()) + 33}" '
           'role="img" aria-labelledby="cluster-svg-title"><title id="cluster-svg-title">'
           'A composed proof cluster with earlier outputs and source clauses as receptors</title>'
           '<defs><marker id="cluster-arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">'
           '<path d="M0 0 L6 3 L0 6 Z" fill="#657486"></path></marker></defs>'
           + "".join(edges + rectangles) + "</svg>")
    return svg + '<details><summary>Read the actual receptor and output clauses</summary><ol>' + "".join(rules) + "</ol></details>"


def main():
    previous = load("data/transfer-v1.json")
    data = {r["id"]: r for r in load("data/context-v1.json")}
    wired = {r["id"]: r for r in load("data/wired-v1.json")}
    ranks = load("data/rank-ablation-v1.json")
    sources = {r["id"]: r for r in load("input/new-cases-v1.json")}
    choices = ["odd-cycle-5", "odd-cycle-7", "pigeonhole-4-3"]
    rows, matches, shuffled, cdcl, checks, panels = [], [], [], [], [], []
    for r in previous["cases"]:
        n = r["id"]
        context = data[n]
        libraries = {lib["library"]: lib for lib in context["libraries"]}
        cold = next(x for x in r["results"] if x["mode"] == "cold")
        alternatives = [x["stats"].get("pairs", 0) for x in r["results"] if x["mode"] == "shuffled"]
        shuffled.append([name(n), min(alternatives), int(median(alternatives)), max(alternatives)])
        m = r["matching"]
        e = libraries["exact"]["matching"]
        f = libraries["flexible"]["matching"]
        h = libraries["two-layer"]["matching"]
        matches.append([name(n), m["trials"], e.get("literal_trials", 0), e.get("row_trials", 0),
                        e["offers"], f["offers"], len(context["bridges"]), "Complete" if h["complete"] else "Capped"])
        cdcl.append([name(n), r["external"][0]["stats"]["conflicts"],
                     *[libraries[k]["cdcl"]["stats"]["conflicts"] for k in ("exact", "flexible", "two-layer")],
                     r["external"][0]["status"]])
        for label, lib in libraries.items():
            found = {m["mode"]: m for m in lib["search"]}
            s = found["receptor"]
            rows.append([name(n), label, s["status"], cold["stats"].get("pairs", 0),
                         found["seeded"]["stats"].get("pairs", 0), s["stats"].get("pairs", 0),
                         s["stats"].get("macro_replays", 0), s.get("nested_used", 0)])
        if n in choices:
            s = next(k for k in libraries["two-layer"]["search"] if k["mode"] == "receptor")
            record = wired.get(n, {**s, "id":n})
            assert record["rectangle"]["status"] == "VERIFIED"
            checks.append([name(n), len(record["proof"]["premises"]), len(record["proof"]["proof"]),
                           "Parent wires from found proof" if n in wired else "Open parent selectors",
                           record["rectangle"]["height"]])
            panels.append((n, panel(record, sources[n], record["rectangle_file"],
                                   "The search found the proof using two layers of checked clusters. " +
                                   ("The replay wires its discovered parent links into the circuit."
                                    if n in wired else "The open checker verifies the parent selectors."))))
    big = data["pigeonhole-4-3"]
    biglib = next(k for k in big["libraries"] if k["library"] == "two-layer")
    large = next(k for k in biglib["search"] if k["mode"] == "receptor")
    used = {json.dumps(o, sort_keys=True) for o in large["used"]}
    final_clauses = {frozenset(step["clause"]) for step in large["proof"]["proof"]}
    retained = [b for b in big["bridges"] if json.dumps(b["flattened"], sort_keys=True) in used
                and frozenset(b["flattened"]["steps"][-1][3]) in final_clauses]
    assert len(retained) == 7
    bridge = retained[0]
    source = {tuple(sorted(c, key=lambda lit:(abs(lit),lit<0))) for c in large["proof"]["premises"]}
    # All leaves used by the flat recipe are original source clauses.
    assert all(tuple(row) in source for row in bridge["flattened"]["leaves"])
    diagram = plot(bridge["outer"], {tuple(c) for c in bridge["flattened"]["leaves"]}, large["proof"]["atoms"])
    training_rows = [[name(r["id"]), r["library"], r["results"]["initial"]["status"],
                      r["results"]["initial"]["stats"].get("pairs", 0), r["results"]["learned"]["status"],
                      r["results"]["learned"]["stats"].get("pairs", 0)] for r in ranks]
    menu = "".join(f'<option value="{n}">{escape(name(n))}</option>' for n, _ in panels)
    assert len(previous["donors"]) == 5 and len(previous["training"]) == 32
    assert len(large["proof"]["proof"]) == 70 and large["nested_used"] == 12
    source_summary = load("prior/calibration-receipt-v1.json")
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Proof clusters that accept new receptors</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>{STYLE}
.cluster-chart{{display:block;width:100%;max-width:720px;margin:auto;background:#f8f8f3;border:1px solid #ced9d1}}
figure{{margin-inline:0}}figcaption{{color:#3e5b50;margin-top:.55rem}}
.proof-table{{table-layout:fixed}}.proof-table tr>:first-child{{width:3.15rem}}
.clause{{font-size:1.04rem;margin-bottom:.35rem}}.proof-table .strip{{overflow:auto}}
pre{{white-space:pre-wrap;overflow-wrap:anywhere;overflow:auto;background:#e5eee6;padding:.7rem}}
</style></head><body><main>
<header><p class="eyebrow">GCTS proof notebook · Transfer on branching proofs · November 2026</p>
<h1>Proof clusters that accept new receptors</h1>
<p>Five small clusters were extracted from two checked proofs. The search placed them in new statements and used some of their outputs as receptors for a second layer. Twelve composed clusters contributed rows to the checked four-pigeon proof. Seven of their final outputs appear in the proof.</p>
<nav aria-label="On this page"><a href="#reader">Proof lines</a><a href="#cluster">A composed cluster</a>
<a href="#comparison">Transfer controls</a><a href="#learning">Learned move order</a><a href="#evidence">Evidence</a></nav>
<p><a href="{OLD}">Previous notebook on conclusion-side marks and ground unit propagation</a></p></header>
<section id="reader"><h2>Read the discovered proofs</h2>
<p>The first rows admit source clauses. Each subsequent row resolves two earlier clauses. The empty clause contradicts the negated conclusion. Expand any row to see its Wang squares in placement order.</p>
<p><label>Statement <select id="case-menu">{menu}</select></label></p>{''.join(p for _, p in panels)}</section>
<section id="cluster"><h2>Inspect a composed cluster</h2>
<p>The donors were the three-cycle and the three-pigeon proofs. A receptor is a signed clause pattern. A placement binds its atoms consistently across every receptor and preserves each atom's type. A flexible receptor may carry one extra literal. The recipe computes the new output by replaying its resolutions, carrying any surviving extra literals forward.</p>
<figure>{diagram}<figcaption>Purple receptors take earlier checked cluster outputs. Green receptors take source clauses. The blue rows replay the outer cluster. Its output is a row in the four-pigeon proof.</figcaption></figure>
<p>The checker expands the composite back to original admitted clauses. The palette and its oriented edge rules are the same. Direct wiring for two displayed proofs fixes discovered parent links as part of the checker program, with the pivots, source fields and clause values still checked. A flipped final clause bit was rejected in both.</p>
{table(["Statement","Premise rows","Resolution rows","Parent links in checker","Machine rows"],checks)}</section>
<section id="comparison"><h2>Separate library effects from search effects</h2>
<p>The calibration has five positives that need branching and five satisfiable companions. Exhaustive source truth tables qualified all ten. Two positives supplied the donor proofs and the other eight statements were held out. An earlier direct open-rectangle pilot solved only the smallest cycle with the two SAT controls. Its boundary-cut arms reached their limits on all eight tested windows.</p>
<p>Exact indexed matching independently reproduced all exact placements. The table counts literal and row probes separately. A second layer can be capped, as it was on the four-pigeon case.</p>
{table(["Statement","Plain literal trials","Indexed literal trials","Indexed row trials","Exact offers","Flexible offers","New composed offers","Second pass"],matches)}
<p>All saturation arms use the same ordinary resolution moves. Eager seeding receives the same library as receptor activation. Pair attempts and primitive replay steps are separate work counts. Matching and independent replay cost additional work. The raw results contain timings.</p>
{table(["Statement","Library","Receptor outcome","Cold pairs","Eager pairs","Receptor pairs","Receptor replay steps","Composed clusters contributing rows"],rows)}
<p>For the exact library, the shuffled control activates the same valid offers at different source rows. The five-cycle receptor result of 41 pairs ties eager seeding and the best shuffle. On the seven-cycle, adding the second layer reduced receptor attempts from 965 to 55 and required 596 replay steps. Eager seeding reached 12 pairs with the same library.</p>
{table(["Statement","Fewest shuffled pairs","Median shuffled pairs","Most shuffled pairs"],shuffled)}
<p>Glucose also receives the same certified output clauses. Its conflicts measure a different operation. For the four-pigeon case, the library reduced Glucose conflicts from seven to two. The ground SAT control remains much smaller than the open proof search.</p>
{table(["Statement","Cold conflicts","Exact conflicts","Flexible conflicts","Two-layer conflicts","Ground result"],cdcl)}</section>
<section id="learning"><h2>Compare the same frontier before and after training</h2>
<p>A policy ranks the next clause from the same frontier of at most 14 candidates. It was trained with reward for low pair and replay counts over 32 separate synthetic episodes. The table holds the frontier, clauses and receptor offers fixed and changes only the weights. Training increased work on the held-out positives. The largest trained search with two layers reached its limit.</p>
{table(["Statement","Library","Initial outcome","Initial pairs","Trained outcome","Trained pairs"],training_rows)}</section>
<section id="evidence"><h2>Replay the experiments</h2>
<ul><li><a href="{STEM}-results.json">Results summary</a></li>
<li><a href="{STEM}-evidence.zip">Full source, protocols, proofs, traces and Wang rectangles</a></li>
<li><a href="{STEM}-manifest.json">SHA-256 manifest</a></li></ul>
<p>Each command starts from the pinned inputs for one phase and writes to a separate directory. The previous notebook gives the shared PySAT dependency pins. Timing fields can vary between runs.</p>
<pre><code>python3.12 -I -S -B publication/replay_phase_v1.py transfer /tmp/wang-transfer /tmp/wang-pysat
python3.12 -I -S -B publication/replay_phase_v1.py context /tmp/wang-transfer /tmp/wang-pysat
python3.12 -I -S -B publication/replay_phase_v1.py wired /tmp/wang-transfer
python3.12 -I -S -B publication/replay_phase_v1.py rank /tmp/wang-transfer</code></pre></section></main>
<script>
const menu=document.getElementById("case-menu");
function choose(){{for(const p of document.querySelectorAll(".proof[id^=case-]")) p.hidden=p.id!=="case-"+menu.value;}}
menu.addEventListener("change",choose);choose();
</script></body></html>"""
    result = dict(status="CHECKED_WANG_LEMMA_TRANSFER", proof_readers=[n for n, _ in panels], checks=checks,
                  calibration=source_summary, matching=matches, saturation=rows, shuffled=shuffled,
                  cdcl=cdcl, rank_ablation=training_rows, representative_bridge=bridge,
                  donor_patterns=len(previous["donors"]), training_episodes=len(previous["training"]),
                  pigeonhole_composed_outputs_in_proof=len(retained))
    with (ROOT/"report"/(STEM+".html")).open("x") as stream:
        stream.write(html)
    with (ROOT/"report"/(STEM+"-results.json")).open("x") as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
