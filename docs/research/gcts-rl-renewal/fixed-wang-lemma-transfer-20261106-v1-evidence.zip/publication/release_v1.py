"""Check the reader, package evidence and prepare an isolated Git commit."""

import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from render_transfer_v1 import OLD, ROOT, STEM
from resolution_v1 import pin

GIT = "/private/tmp/gcts-history-publication-20261102-v1.git"
REPO = "liuyao12/geometric-tree-search"
PREFIX = "docs/research/gcts-rl-renewal/"
BASE = "https://liuyao12.github.io/geometric-tree-search/"
PARENT = "bf0959ad34ef3b6ba5e993a53edd305f88114065"
MAIN = STEM+".html"
SUMMARY = STEM+"-results.json"
ARCHIVE = STEM+"-evidence.zip"
MANIFEST = STEM+"-manifest.json"
PACKAGE = ROOT/"package"


def read(path):
    return json.loads(path.read_bytes())


def wire(value):
    return (json.dumps(value, indent=2, sort_keys=True)+"\n").encode()


def owned(path, payload):
    with path.open("xb") as stream:
        stream.write(payload)


class Reader(HTMLParser):
    void = {"meta", "link", "img", "br", "hr", "input"}

    def __init__(self):
        super().__init__()
        self.stack, self.links, self.ids = [], set(), set()
        self.svgs = self.bars = self.rows = self.math = 0

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.svgs += tag == "svg"
        self.bars += "bar" in attrs.get("class", "").split()
        self.rows += tag == "tr"
        if tag == "a":
            self.links.add(attrs["href"])
        if "id" in attrs:
            assert attrs["id"] not in self.ids
            self.ids.add(attrs["id"])
        if tag not in self.void:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        assert self.stack and self.stack.pop() == tag

    def handle_data(self, text):
        if self.stack and self.stack[-1] not in ("script", "style"):
            assert text.count(r"\(") == text.count(r"\)")
            self.math += text.count(r"\(")


def static_check():
    raw = (ROOT/"report"/MAIN).read_text()
    parser = Reader()
    parser.feed(raw)
    parser.close()
    assert not parser.stack and (parser.svgs, parser.bars, parser.rows) == (1030, 0, 231)
    assert parser.math == 299
    assert {"reader", "case-menu", "cluster", "comparison", "learning", "evidence"} <= parser.ids
    assert {SUMMARY, ARCHIVE, MANIFEST, OLD} <= parser.links
    assert "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js" in raw
    source = ROOT/"report"/SUMMARY
    summary = read(source)
    assert summary["status"] == "CHECKED_WANG_LEMMA_TRANSFER"
    assert len(summary["saturation"]) == 24 and len(summary["proof_readers"]) == 3
    assert summary["donor_patterns"] == 5 and summary["training_episodes"] == 32
    browser = read(ROOT/"publication/browser-v1.json")
    assert browser["status"] == "CHECKED_WANG_TRANSFER_READER"
    assert browser["cases"] == 3 and browser["lines"] == 147 and browser["math_errors"]==0
    assert browser["math"] == parser.math
    receipt = dict(status="PASS_STATIC_READER_CHECK", report=pin(ROOT/"report"/MAIN),
                   scientific_result=pin(source), svgs=parser.svgs, bars=parser.bars,
                   table_rows=parser.rows, math_expressions=parser.math,
                   scope="HTML structure, expected content and exact data references.")
    owned(ROOT/"publication/static-v1.json", wire(receipt))
    print(json.dumps(receipt), flush=True)


def confirm_remote():
    command = ["/Users/liuyao/bin/gh", "api", "--hostname", "github.com", "--method", "GET",
               "repos/"+REPO+"/git/ref/heads/main"]
    state = json.loads(subprocess.check_output(command, timeout=45))
    assert state["ref"] == "refs/heads/main" and state["object"]["type"] == "commit"
    assert state["object"]["sha"] == PARENT
    return state


def verify_archive(path, manifest):
    assert pin(path) == manifest["archive"]
    with zipfile.ZipFile(path) as archive:
        expected = manifest["files"]
        assert set(archive.namelist()) == set(expected) and len(archive.namelist()) == len(expected)
        assert archive.testzip() is None
        for name, ref in expected.items():
            raw = archive.read(name)
            assert ref == dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()), name
    return len(expected)


def prepare():
    receipt = read(ROOT/"publication/static-v1.json")
    assert receipt["report"] == pin(ROOT/"report"/MAIN)
    assert receipt["scientific_result"] == pin(ROOT/"report"/SUMMARY)
    owned(ROOT/"publication/remote-base-v1.json", wire(confirm_remote()))
    PACKAGE.mkdir()
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    env.update(GIT_INDEX_FILE=str(PACKAGE/"index"), GIT_NO_LAZY_FETCH="1",
               GIT_AUTHOR_NAME="Codex", GIT_AUTHOR_EMAIL="codex@openai.com",
               GIT_COMMITTER_NAME="Codex", GIT_COMMITTER_EMAIL="codex@openai.com")

    def git(*args, input=None):
        return subprocess.check_output(["git", "-c", "core.hooksPath=/dev/null",
            "-c", "gc.auto=0", "--git-dir="+GIT, *args], env=env, input=input, timeout=90)

    assert git("rev-parse", "--is-bare-repository").strip() == b"true"
    assert git("show", PARENT+":docs/basic-tiling-algorithm.md") == (
        ROOT/"publication/basic-tiling-algorithm-at-parent.md").read_bytes()
    old = git("show", PARENT+":"+PREFIX+OLD)
    assert old.count(b"</h1>") == 1 and MAIN.encode() not in old
    backlink = f'<p><a href="{MAIN}">Continue with transferable proof clusters on branching examples.</a></p>'.encode()
    prior = ROOT/"publication/previous-report-with-backlink-v1.html"
    owned(prior, old.replace(b"</h1>", b"</h1>"+backlink, 1))
    files = {}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if rel.parts[0] == "package":
            continue
        assert not path.is_symlink()
        if path.is_file():
            files[rel.as_posix()] = pin(path)
    archive = PACKAGE/ARCHIVE
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for name in files:
            bundle.write(ROOT/name, name)
    manifest = dict(schema="Wang-clause-cluster-transfer-evidence-v1", archive=pin(archive), files=files,
                    scope="All completed transfer and context experiments, source snapshots, rank ablation, and checked proof rectangles.")
    assert verify_archive(archive, manifest) == len(files)
    owned(PACKAGE/MANIFEST, wire(manifest))
    assert confirm_remote()["object"]["sha"] == PARENT
    git("read-tree", PARENT)
    targets = [(MAIN, ROOT/"report"/MAIN), (ARCHIVE, archive), (MANIFEST, PACKAGE/MANIFEST),
               (SUMMARY, ROOT/"report"/SUMMARY), (OLD, prior)]
    assets = {}
    for name, source in targets:
        target = PREFIX+name
        if name != OLD:
            assert not git("ls-tree", PARENT, "--", target)
        assert source.stat().st_size < 50*1024*1024
        blob = git("hash-object", "-w", "--stdin", input=source.read_bytes()).decode().strip()
        git("update-index", "--add", "--cacheinfo", "100644", blob, target)
        assets[name] = pin(source)
    tree = git("write-tree", "--missing-ok").decode().strip()
    commit = git("commit-tree", tree, "-p", PARENT, "-m", "Publish transferable Wang proof clusters and held-out learning controls").decode().strip()
    diff = set(git("diff-tree", "--no-commit-id", "--no-renames", "--name-status", "-r", PARENT, commit).decode().splitlines())
    assert diff == {("M" if name == OLD else "A")+"\t"+PREFIX+name for name, _ in targets}
    assert git("rev-list", "--parents", "-n", "1", commit).decode().split() == [commit, PARENT]
    result = dict(status="PREPARED_TASK_ASSETS_ONLY", commit=commit, parent=PARENT, tree=tree,
                  assets=assets, original_files=len(files), diff=sorted(diff))
    owned(PACKAGE/"prepared-v1.json", wire(result))
    print(json.dumps(result), flush=True)


def remote_check(destination):
    prepared = read(PACKAGE/"prepared-v1.json")
    commit = prepared["commit"]
    if destination == "live":
        pages = read(ROOT/"publication/pages-final-v1.json")
        assert pages["headSha"] == commit and pages["status"] == "completed" and pages["conclusion"] == "success"
        assert {j["name"] for j in pages["jobs"]} == {"build", "report-build-status", "deploy"}
        assert all(j["status"] == "completed" and j["conclusion"] == "success" for j in pages["jobs"])
        url_prefix = BASE+PREFIX
        suffix = "?v="+commit[:12]
        extra = dict(pages_run=pages["databaseId"])
        status = "PUBLISHED_VERIFIED"
    else:
        assert destination == "repository"
        url_prefix = "https://raw.githubusercontent.com/"+REPO+"/"+commit+"/"+PREFIX
        suffix = ""
        extra = {}
        status = "VERIFIED_PUBLIC_REPOSITORY_BYTES"
    live = PACKAGE/destination
    live.mkdir()
    urls = {}
    for name, expected in prepared["assets"].items():
        url = url_prefix+name+suffix
        (live/name).parent.mkdir(exist_ok=True,parents=True)
        subprocess.run(["/usr/bin/curl", "--silent", "--show-error", "--fail", "--proto", "=https",
                        "--connect-timeout", "15", "--max-time", "90", "--max-filesize", "52428800",
                        "--header", "Accept-Encoding: identity", "--output", str(live/name), url],
                       check=True, timeout=100)
        assert pin(live/name) == expected, name
        urls[name] = url
    verified = verify_archive(live/ARCHIVE, read(live/MANIFEST))
    assert verified == prepared["original_files"]
    result = dict(status=status, commit=commit, parent=prepared["parent"], **extra,
                  assets=urls, archive_original_files=verified, goal_turn_classification="PROGRESS",
                  program_goal_status="ACTIVE")
    owned(ROOT/f"publication/{destination}-verified-v1.json", wire(result))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    assert len(sys.argv) == 2
    mode = sys.argv[1]
    if mode in {"live","repository"}:
        remote_check(mode)
    else:
        {"static": static_check, "prepare": prepare}[mode]()
