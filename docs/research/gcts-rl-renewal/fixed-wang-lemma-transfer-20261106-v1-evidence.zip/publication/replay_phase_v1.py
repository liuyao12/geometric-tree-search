"""Replay one pinned phase in a clean directory without changing the archive."""

import json
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
PHASES = {
    "transfer": ("transfer-protocol-v1.json", "transfer_experiment_v1.py", True),
    "context": ("context-protocol-v1.json", "context_experiment_v1.py", True),
    "wired": ("wired-protocol-v1.json", "wired_replay_v1.py", False),
    "rank": ("rank-ablation-protocol-v1.json", "rank_ablation_v1.py", False),
}


def main():
    phase, destination, *dependencies = sys.argv[1:]
    protocol, source, needs_dependency = PHASES[phase]
    assert len(dependencies) == int(needs_dependency)
    target = Path(destination).resolve() / phase
    target.mkdir(parents=True)
    (target / "data").mkdir()
    spec = json.loads((ROOT / protocol).read_bytes())
    for name in (protocol, *spec["pins"]):
        child = Path(name)
        assert not child.is_absolute() and ".." not in child.parts
        (target / child).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / child, target / child)
    subprocess.run([sys.executable, "-I", "-S", "-B", str(target / "source" / source),
                    *[str(Path(p).resolve()) for p in dependencies]], cwd=target, check=True)


if __name__ == "__main__":
    main()
