"""Replay hierarchy certificates with affine coefficients and exact polygon clipping."""
from collections import Counter, defaultdict
from copy import deepcopy
from fractions import Fraction
from functools import cmp_to_key
from itertools import combinations
from pathlib import Path
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import check_v1 as ring
import clipping_v1 as clip
import standard_v1 as standard
from model_v1 import ONE, ZERO

ROOT = Path(__file__).resolve().parents[1]
PHI = standard.PHI
INVERSE = ring.minus(PHI,ONE)


def read(path):
    return json.loads((ROOT/path).read_text())


def freeze(x):
    return tuple(map(freeze,x)) if isinstance(x,list) else x


def edges(poly):
    return zip(poly,poly[1:]+poly[:1])


def times(k,p):
    return tuple(k*x for x in p)


def sum_field(u,v):
    return u[0]+v[0],u[1]+v[1]


def real_point(p,den=1):
    w,x,y,z=p
    d=Fraction(1,den)
    return ((2*w-x)*d/2,(x-y-z)*d/2),((y-z)*d,x*d)


def ordered_field(poly,den=1):
    points=tuple(real_point(p,den) for p in poly)
    a=clip.sign(clip.twice(points))
    assert a
    return points if a>0 else points[::-1]


def coefficient(u,p,mirror):
    return ring.multiply(u,ring.star(p) if mirror else p)


def world(node):
    kind,u,mirror,origin=node
    return tuple(ring.plus(origin,coefficient(u,p,mirror)) for p in standard.PROTOS[kind])


def children(node,rule):
    kind,u,mirror,origin=node
    unit=ring.multiply(u,INVERSE)
    return tuple((c,coefficient(unit,ring.RAYS[turn],mirror),mirror!=reflected,
                  ring.plus(origin,coefficient(unit,offset,mirror)))
                 for c,turn,reflected,offset in rule[kind])


def descendants(node,h,rule):
    if not h:
        yield node
        return
    for child in children(node,rule):
        yield from descendants(child,h-1,rule)


def exact_inside(point,poly,den):
    def orient(a,b,p,n):
        return ring.order(ring.imaginary_normal(ring.minus(b,a),ring.minus(p,times(n,a))),(0,0))
    orientation=orient(*poly,1)
    assert orientation
    return all(orient(a,b,point,den)==orientation for a,b in edges(poly))


def qualify(proof,rules):
    period=proof["nest"]["depth"]
    directions=standard.axes(period+1)
    word_by_channel={}
    for kind,rule in enumerate(rules):
        parent,_,outer,_=standard.verify_patch(kind,1,rule,proof["marks"],directions)
        for channel,word in standard.boundary_maps(kind,parent,outer,proof["marks"],directions).items():
            assert word_by_channel.setdefault(channel,word)==word
    assert tuple(sorted(word_by_channel.items()))==tuple((r["channel"],r["word"]) for r in proof["boundary_receptors"])
    nest=proof["nest"]
    kind=nest["kind"]
    assert not nest["seed"][2]
    scale=standard.scaled(ONE,period)
    parent=(kind,scale,False,ZERO)
    expected={standard.place(c) for c in nest["triangles"]}
    assert {world(c) for c in descendants(parent,period,rules)}==expected
    assert standard.verify_patch(kind,period,nest["triangles"],proof["marks"],directions)[0]==nest["parent"]
    seed=standard.place(nest["seed"])
    assert seed in expected and all(exact_inside(p,nest["parent"],1) for p in seed)
    factor=ring.multiply(scale,ring.RAYS[-nest["seed"][1]])
    offset=ring.multiply(ring.RAYS[-nest["seed"][1]],times(-1,nest["seed"][3]))
    root=(kind,ONE,False,ZERO)
    aligned=(kind,factor,False,offset)
    assert world(aligned)==nest["parent_after_alignment"]
    assert root in set(descendants(aligned,period,rules))
    return root,factor,offset


def grow(root,levels,factor,offset):
    for _ in range(levels):
        kind,u,mirror,origin=root
        root=(kind,ring.multiply(factor,u),mirror,ring.plus(ring.multiply(factor,origin),offset))
    return root


def supports(d,poly):
    return [ring.imaginary_normal(d,p) for p in poly]


def verified_separation(d,poly,part,den):
    assert len(d)==4 and any(d)
    a,b=supports(d,tuple(times(den,p) for p in poly)),supports(d,part)
    return (all(ring.order(p,q)<=0 for p in a for q in b)
            or all(ring.order(q,p)<=0 for p in a for q in b))


def triangle_marks(node,marks):
    return tuple((a,b,m) if a<b else (b,a,-m)
                 for (a,b),m in zip(edges(world(node)),marks[node[0]],strict=True))


def locate(expected,root,h,rule):
    centroid=tuple(map(sum,zip(*expected)))
    while h:
        root,=tuple(c for c in children(root,rule) if exact_inside(centroid,world(c),3))
        h-=1
    assert set(world(root))==set(expected)
    return root


def rhomb(node,root,outer,h,period,proof,rules):
    p,a,b=world(node)
    q=ring.minus(ring.plus(a,b),p)
    centroid=tuple(map(sum,zip(q,a,b)))
    if exact_inside(centroid,world(root),3):
        mate=locate((q,a,b),root,h,rules)
    else:
        mate=locate((q,a,b),outer,h+period,rules)
    assert mate[0]==node[0]
    first,second=(triangle_marks(t,proof["marks"]) for t in (node,mate))
    assert first[1]==second[1]
    return (tuple(sorted((p,a,q,b))),node[0],tuple(sorted((first[0],first[2],second[0],second[2]))))


def flat_candidates(root,h,rules,windows):
    """Enumerate every unit triangle and use two support directions before clipping."""
    axes=ring.RAYS[:2]
    bounds=[]
    for a in axes:
        key=cmp_to_key(ring.order)
        bounds.append((a,[(min(v,key=key),max(v,key=key)) for v in
                          (supports(a,p) for p in windows["parts"])]))
    for node in descendants(root,h,rules):
        poly=world(node)
        for j,part in enumerate(windows["parts"]):
            for axis,intervals in bounds:
                values=supports(axis,tuple(times(windows["den"],p) for p in poly))
                lo,hi=intervals[j]
                if all(ring.order(v,lo)<=0 for v in values) or all(ring.order(v,hi)>=0 for v in values):
                    break
            else:
                if clip.intersection(ordered_field(poly),ordered_field(part,windows["den"]))!=(0,0):
                    yield tuple(sorted(poly))
                    break


def check_window(spec,case,proof,rules,start,factor,offset):
    result=case["certificate"]
    rounds,h=result["rounds"],result["level"]
    period=proof["nest"]["depth"]
    assert h==rounds*period
    root=grow(start,rounds,factor,offset)
    outer=grow(root,1,factor,offset)
    assert all(exact_inside(p,world(root),spec["den"]) for part in spec["parts"] for p in part)
    if rounds:
        prior=world(grow(start,rounds-1,factor,offset))
        assert any(not exact_inside(p,prior,spec["den"]) for part in spec["parts"] for p in part)
    window=tuple(ordered_field(p,spec["den"]) for p in spec["parts"])
    assert all(clip.intersection(a,b)==(0,0) for a,b in combinations(window,2))
    skip=dict(result["skips"])
    assert len(skip)==len(result["skips"])
    hits=set(result["hits"])
    assert len(hits)==len(result["hits"]) and not (hits & skip.keys())
    used=set()
    target={}
    leaf_hits=set()
    visits=Counter()
    def walk(node,level,address):
        visits[level]+=1
        poly=world(node)
        if address in skip:
            directions=skip[address]
            assert len(directions)==len(window)
            assert all(verified_separation(d,poly,part,spec["den"])
                       for d,part in zip(directions,spec["parts"],strict=True))
            used.add(address)
        elif level:
            assert address not in hits
            for i,c in enumerate(children(node,rules)):
                walk(c,level-1,address+str(i))
        else:
            assert address in hits and any(clip.intersection(ordered_field(poly),part)!=(0,0) for part in window)
            used.add(address)
            leaf_hits.add(tuple(sorted(poly)))
            key,kind,arrows=rhomb(node,root,outer,h,period,proof,rules)
            assert target.setdefault(key,(kind,arrows))==(kind,arrows)
    walk(root,h,"")
    assert used==hits|skip.keys() and len(leaf_hits)==len(hits)
    assert tuple(sorted(visits.items()))==result["by_level"]
    assert sum(visits.values())==result["counts"]["visited"]
    flat=False
    if h<=8 or spec["id"]=="hole":
        assert set(flat_candidates(root,h,rules,spec))==leaf_hits
        flat=True
    output={tuple(sorted(t["vertices"])):(t["kind"],t["arrows"]) for t in result["rhombs"]}
    assert output==target and len(output)==len(result["rhombs"])==result["counts"]["retained"]
    obtained=[(0,0) for _ in window]
    contacts=defaultdict(list)
    boundary=defaultdict(list)
    for tile in result["rhombs"]:
        verts=tile["vertices"]
        poly=tuple(real_point(p) for p in verts)
        assert clip.sign(clip.twice(poly))>0
        for a,b in edges(verts):
            boundary[tuple(sorted((a,b)))].append((a,b))
        for j,part in enumerate(window):
            obtained[j]=sum_field(obtained[j],clip.intersection(poly,part))
        for a,b,m in tile["arrows"]:
            contacts[a,b].append(m)
    assert tuple(obtained)==tuple(map(clip.twice,window))
    assert all(len(a)<=2 and len(set(a))==1 for a in contacts.values())
    assert boundary.keys()==contacts.keys()
    assert all(len(sides)==len(contacts[k]) and (len(sides)==1 or sides[0]==sides[1][::-1])
               for k,sides in boundary.items())
    assert tuple(sorted(sides[0] for sides in boundary.values() if len(sides)==1))==result["boundary"]
    hole_clear=None
    if spec["id"]=="hole":
        p,q=map(clip.center,window[:2])
        midpoint=tuple(tuple(x/2 for x in sum_field(a,b)) for a,b in zip(p,q,strict=True))
        hole_clear=all(any(clip.sign(clip.side(a,b,midpoint))<0 for a,b in edges(ordered_field(t["vertices"])))
                       for t in result["rhombs"])
        assert hole_clear
    return dict(id=spec["id"],regions=len(window),visited=sum(visits.values()),
                checked_skips=len(skip),paired_halves=len(hits),rhombs=len(output),
                boundary_edges=len(result["boundary"]),flat_match=flat,hole_clear=hole_clear)


def main():
    proof=freeze_record(read("input/standard-proof-v1.json"))
    rules=proof["rules"]
    root,factor,offset=qualify(proof,rules)
    cohort=read("input/cases-v1.json")["holdout"]
    runs=read("data/results-v1.json")
    assert runs["status"]=="CHECKED_EXACT_HIERARCHICAL_PENROSE_WINDOWS"
    checks=[]
    for spec,row in zip(cohort,runs["cases"],strict=True):
        assert row["id"]==spec["id"]
        checks.append(check_window(freeze_record(spec),freeze_record(row),proof,rules,root,factor,offset))
        print(json.dumps(checks[-1],sort_keys=True),flush=True)
    controls={}
    first=freeze_record(runs["cases"][0])
    spec=freeze_record(cohort[0])
    tile=first["certificate"]["rhombs"][0]
    a,b,m=tile["arrows"][0]
    corruptions={
        "omitted_hit":{"hits":()},
        "forged_root_skip":{"hits":(),"skips":(("",((1,0,0,0),)),)},
        "wrong_arrow":{"rhombs":({**tile,"arrows":((a,b,-m),*tile["arrows"][1:])},)},
    }
    for label,changes in corruptions.items():
        altered=deepcopy(first)
        altered["certificate"].update(changes)
        try:
            check_window(spec,altered,proof,rules,root,factor,offset)
        except AssertionError:
            controls[label]="REJECTED"
        else:
            raise AssertionError(label)
    receipt=dict(status="AUDITED_EXACT_PENROSE_WINDOW_CERTIFICATES",cases=checks,
                 controls=controls,verified_boundary_channels=len(proof["boundary_receptors"]))
    (ROOT/"data/audit-v1.json").write_text(json.dumps(receipt,sort_keys=True,separators=(",",":"))+"\n")


def freeze_record(x):
    if isinstance(x,dict):
        return {k:freeze_record(v) for k,v in x.items()}
    if isinstance(x,list):
        return tuple(map(freeze_record,x))
    return x


if __name__=="__main__":
    main()
