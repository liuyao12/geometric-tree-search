"""Rank registered Penrose phases with exact cyclotomic area."""
from functools import cmp_to_key
from itertools import product
from pathlib import Path
from random import Random
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
import check_v1 as ring
import clipping_v1 as clip
from model_v1 import rotate
from window_audit_v1 import check_window,freeze_record,ordered_field,qualify
from window_cases_v1 import region,xy
from window_model_v1 import Atlas,Cell,ONE,UNIT,ZERO,edges,query,times

PHASES=((0,0,0),)+tuple((g,x,y) for g,x,y in product((0,5),(-1,0,1),(-1,0,1)) if (g,x,y)!=(0,0,0))


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def plus(a,b):
    return a[0]+b[0],a[1]+b[1]


def fraction_pair(a):
    return tuple((x.numerator,x.denominator) for x in a)


class PenroseAtlas:
    def __init__(self):
        self.atlas=Atlas()
        self.weights=[]
        for kind in range(2):
            tile=self.atlas.rhomb(Cell(kind,0,False,ZERO))
            weight=clip.twice(ordered_field(tile["vertices"]))
            assert all(a.denominator==1 for a in weight)
            self.weights.append(tuple(map(int,weight)))
        self.proof=freeze_record(self.atlas.proof)
        self.rules=self.proof["rules"]
        self.qualified=qualify(self.proof,self.rules)

    def pose(self,part,den,phase,inverse=False):
        turn,x,y=PHASES[phase]
        shift=times(den,xy(x,y))
        if inverse:
            return tuple(rotate(ring.minus(p,shift),(-turn)%10) for p in part)
        return tuple(ring.plus(rotate(p,turn),shift) for p in part)

    def tiles(self,result,phase):
        output=[]
        for tile in result["rhombs"]:
            verts=self.pose(tile["vertices"],1,phase)
            j=verts.index(min(verts))
            arrows=[]
            for a,b,m in tile["arrows"]:
                a,b=self.pose((a,b),1,phase)
                arrows.append((a,b,m) if a<b else (b,a,-m))
            output.append(dict(kind=tile["kind"],vertices=verts[j:]+verts[:j],arrows=sorted(arrows)))
        return tuple(sorted(output,key=lambda t:t["vertices"]))

    def locate(self,spec,phase,limit=None,*,trace=False):
        local={**spec,"parts":tuple(self.pose(p,spec["den"],phase,True) for p in spec["parts"])}
        mass=(0,0)
        def cutoff(tile):
            nonlocal mass
            mass=plus(mass,self.weights[tile["kind"]])
            return limit is not None and ring.order(mass,limit)>=0
        result=query(self.atlas,local,trace=trace,stop=cutoff)
        assert mass==self.score(result["rhombs"])
        return mass,self.tiles(result,phase),result,local

    def score(self,tiles):
        value=(0,0)
        for tile in tiles:
            value=plus(value,self.weights[tile["kind"]])
        return value

    def target_area(self,spec):
        value=(0,0)
        for part in spec["parts"]:
            value=plus(value,clip.twice(ordered_field(part,spec["den"])))
        return value

    def check_cut(self,spec,tiles,bound):
        parts=tuple(ordered_field(r,spec["den"]) for r in spec["parts"])
        assert len({t["vertices"] for t in tiles})==len(tiles)
        assert all(any(clip.intersection(ordered_field(t["vertices"]),p)!=(0,0) for p in parts) for t in tiles)
        assert ring.order(self.score(tiles),bound)>=0


def cases(atlas):
    random=Random(88129)
    output=[]
    for split,total in (("train",14),("test",12)):
        for i in range(total):
            base=xy((i+3)*123,-(i+2)*87) if split=="train" else xy(-(i+9)*277,(i+4)*271)
            source=region("source","Source",base,(ONE,UNIT),[(-2,3,-2,3)])
            _,tiles,_,_=atlas.locate(source,0)
            seed=tiles[i%len(tiles)]
            selected=[seed]
            if i%2:
                boundary=set(edges(seed["vertices"]))
                second=next((t for t in tiles if any((b,a) in boundary for a,b in edges(t["vertices"]))),None)
                if second:
                    selected.append(second)
            phase=random.randrange(len(PHASES))
            parts=tuple(atlas.pose(t["vertices"],1,phase) for t in selected)
            output.append(dict(id=f"{split}-fixed-{i:02d}",split=split,kind="fixed",den=1,parts=parts,
                               construction_phase=phase,expected=atlas.score(selected)))
            shape=(ONE,UNIT) if i%3==0 else (xy(2,1),xy(-1,2))
            boxes=[(-2,3,-2,2)] if i%3!=2 else [(-2,3,-2,0),(-2,0,0,3)]
            if split=="test" and i==total-1:
                base=ring.plus(base,xy(10**15,-10**15))
            spec=region(f"{split}-movable-{i:02d}","Movable",base,shape,boxes,3)
            output.append(dict(**spec,split=split,kind="movable"))
    return output


def main():
    atlas=PenroseAtlas()
    output=[]
    for spec in cases(atlas):
        area=atlas.target_area(spec)
        arms=[]
        for phase in range(len(PHASES)):
            mass,tiles,result,_=atlas.locate(spec,phase)
            assert ring.order(mass,area)>=0
            arms.append(dict(score=mass,counts=result["counts"]))
        best=min((r["score"] for r in arms),key=cmp_to_key(ring.order))
        if spec["kind"]=="fixed":
            assert best==area==spec["expected"]==arms[spec["construction_phase"]]["score"]
        context=f"{'integral' if all(v.denominator==1 for v in area) else 'fractional'}-{'single' if len(spec['parts'])==1 else 'other'}"
        output.append(dict(**spec,area2=fraction_pair(area),minimum=best,context=context,arms=arms))
        print(spec["id"],best,arms[0]["score"],flush=True)
    save("data/oracle-v1.json",dict(status="CHECKED_PENROSE_PHASE_ORACLE",
        phases=PHASES,weights=atlas.weights,requests=output))


if __name__=="__main__":
    main()
