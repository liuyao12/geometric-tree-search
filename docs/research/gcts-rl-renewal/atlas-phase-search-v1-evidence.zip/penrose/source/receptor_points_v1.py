"""Reject fixed Penrose phases when a certified rhomb crosses a receptor."""
from collections import Counter
from functools import lru_cache
from pathlib import Path
from types import SimpleNamespace
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(ROOT.parent/"study/source"))
from atlas_phases_v1 import PenroseAtlas,save
import check_v1 as ring
from receptor_driver_v1 import study
from window_audit_v1 import children,freeze_record,grow,rhomb,world
from window_model_v1 import canonical_axis,edges,oriented,side,times


def scaled_edges(poly,denominator):
    return tuple((times(denominator,a),times(denominator,b)) for a,b in edges(oriented(poly)))


def inside(edges_,point,strict=False):
    values=(side(a,b,point) for a,b in edges_)
    return all(v>0 if strict else v>=0 for v in values)


class PenroseReceptors:
    def __init__(self,cache=True):
        self.atlas=PenroseAtlas()
        self.polygon=self.atlas.atlas.polygon
        self.edges_for=scaled_edges
        if cache:
            self.polygon=lru_cache(maxsize=20000)(self.polygon)
            self.edges_for=lru_cache(maxsize=20000)(self.edges_for)
            # Bind the immutable proof and rule tables outside the cache key.
            self.audit_rhomb=lru_cache(maxsize=4000)(self.bound_rhomb)
        else:
            self.audit_rhomb=self.bound_rhomb

    def bound_rhomb(self,node,root,outer,depth,period):
        return rhomb(node,root,outer,depth,period,self.atlas.proof,self.atlas.rules)

    def edges(self,row):
        # Multipart fixed requests here have full-edge contacts.
        directed=Counter(e for tile in row["parts"] for e in edges(tile))
        assert (len(row["parts"])==1 or row["den"]==1) and set(directed.values())=={1}
        return tuple(sorted(e for e in directed if e[::-1] not in directed))

    def length(self,edge):
        return 1

    def feature(self,edge):
        return canonical_axis(ring.minus(*edge))[0]

    def exact(self,row,phase):
        return row["arms"][phase]["score"]==row["expected"]

    def full(self,row,phase):
        score,_,raw,_=self.atlas.locate(row,phase)
        return score==row["expected"],raw["counts"]["visited"]

    def local_point(self,row,edge,phase):
        denominator=2*row["den"]
        return self.atlas.pose((ring.plus(*edge),),denominator,phase,True)[0],denominator

    def probe(self,row,phase,edge):
        point,den=self.local_point(row,edge,phase)
        atlas=self.atlas.atlas
        n,root,depth=atlas.enclose(SimpleNamespace(den=den,parts=((point,),)))
        pending=[(root,depth,"")]
        visits=0
        while pending:
            cell,h,path=pending.pop()
            visits+=1
            if not inside(self.edges_for(self.polygon(cell,h),den),point):
                continue
            if h:
                for i,c in enumerate(atlas.children(cell,h)):
                    pending.append((c,h-1,path+str(i)))
            else:
                tile=atlas.rhomb(cell)
                if inside(self.edges_for(tile["vertices"],den),point,True):
                    return dict(rounds=n,path=path,tile=tile),visits
        return None,visits

    def verify(self,row,phase,edge,witness):
        point,den=self.local_point(row,edge,phase)
        proof,rules=self.atlas.proof,self.atlas.rules
        start,factor,offset=self.atlas.qualified
        period=proof["nest"]["depth"]
        n=witness["rounds"]
        assert type(n) is int and 0<=n<=64
        root=grow(start,n,factor,offset)
        assert inside(self.edges_for(world(root),den),point,True)
        depth=n*period
        node=root
        assert len(witness["path"])==depth
        for char in witness["path"]:
            options=children(node,rules)
            assert char.isdigit() and 0<=int(char)<len(options)
            node=options[int(char)]
        outer=grow(root,1,factor,offset)
        vertices,kind,arrows=self.audit_rhomb(node,root,outer,depth,period)
        tile=witness["tile"]
        assert vertices==tuple(sorted(tile["vertices"])) and kind==tile["kind"]
        assert arrows==tuple(tile["arrows"])
        assert inside(self.edges_for(tile["vertices"],den),point,True)


def main():
    oracle=freeze_record(json.loads((ROOT/"data/oracle-v1.json").read_text()))
    save("data/receptors-v1.json",study(oracle,PenroseReceptors()))


if __name__=="__main__":
    main()
