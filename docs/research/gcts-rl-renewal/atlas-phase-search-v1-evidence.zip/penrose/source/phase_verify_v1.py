"""Audit Penrose phase cutoffs by replaying each retained half-triangle address."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from atlas_phases_v1 import PHASES,PenroseAtlas,fraction_pair,save
import check_v1 as ring
import clipping_v1 as clip
from window_audit_v1 import (check_window,children,exact_inside,freeze_record,grow,
                             ordered_field,rhomb,world)


def check_hits(atlas,local,raw):
    start,factor,offset=atlas.qualified
    rounds=raw["rounds"]
    depth=raw["level"]
    period=atlas.proof["nest"]["depth"]
    assert depth==rounds*period
    root=grow(start,rounds,factor,offset)
    outer=grow(root,1,factor,offset)
    assert all(exact_inside(p,world(root),local["den"]) for part in local["parts"] for p in part)
    parts=tuple(ordered_field(p,local["den"]) for p in local["parts"])
    observed={}
    assert len(raw["hits"])==len(set(raw["hits"]))
    for path in raw["hits"]:
        assert len(path)==depth
        node=root
        for char in path:
            options=children(node,atlas.rules)
            assert char.isdigit() and 0<=int(char)<len(options)
            node=options[int(char)]
        assert any(clip.intersection(ordered_field(world(node)),part)!=(0,0) for part in parts)
        key,kind,arrows=rhomb(node,root,outer,depth,period,atlas.proof,atlas.rules)
        assert observed.setdefault(key,(kind,arrows))==(kind,arrows)
    assert len(raw["rhombs"])==len(observed)
    actual={tuple(sorted(t["vertices"])):(t["kind"],tuple(t["arrows"])) for t in raw["rhombs"]}
    assert observed==actual


def run(atlas,row,planned):
    target=atlas.target_area(row)
    best=None
    events=[]
    prefix=None
    order=(*planned,*(i for i in range(len(PHASES)) if i not in planned))
    for i,phase in enumerate(order,1):
        limit=best["score"] if best else None
        score,tiles,receipt,local=atlas.locate(row,phase,limit)
        check_hits(atlas,local,receipt)
        atlas.check_cut(row,tiles,score)
        if "cutoff" in receipt:
            assert ring.order(score,limit)>=0 and ring.order(row["arms"][phase]["score"],score)>=0
        else:
            assert score==row["arms"][phase]["score"]
        event=dict(phase=phase,score=score,tiles=tiles,receipt=receipt)
        events.append(event)
        if limit is None or ring.order(score,limit)<0:
            assert "cutoff" not in receipt
            best=event
        if i==len(planned):
            prefix=best["score"]
        if best["score"]==target:
            if prefix is None:
                prefix=best["score"]
            break
    assert best["score"]==row["minimum"] and prefix is not None
    if row["kind"]=="fixed":
        assert best["score"]==target
    if best["score"]!=target:
        assert len(events)==len(PHASES)
    score,tiles,receipt,local=atlas.locate(row,best["phase"],trace=True)
    assert score==best["score"] and tiles==best["tiles"]
    check=check_window(freeze_record(local),{"certificate":freeze_record(receipt)},atlas.proof,
                       atlas.rules,*atlas.qualified)
    excess=tuple(a-b for a,b in zip(score,target,strict=True))
    return dict(events=events,winner=best["phase"],score=score,prefix=prefix,
                coverage=check,excess=fraction_pair(excess),exact_fixed_boundary=excess==(0,0),
                visits=sum(v["receipt"]["counts"]["visited"] for v in events),
                cuts=sum("cutoff" in v["receipt"] for v in events))


def main():
    atlas=PenroseAtlas()
    source=freeze_record(json.loads((ROOT/"data/oracle-v1.json").read_text()))
    policy=json.loads((ROOT.parent/"study/data/policy-v1.json").read_text())["results"]["penrose"]
    by_id={r["id"]:r for r in policy["trials"]}
    results=[]
    rejected=False
    for row in source["requests"]:
        if row["split"]!="test":
            continue
        planned=by_id[row["id"]]["arms"]["learned"]
        direct=run(atlas,row,(0,))
        learned=run(atlas,row,planned["actions"])
        assert learned["prefix"]==tuple(planned["score"])
        full=sum(v["counts"]["visited"] for v in row["arms"])
        results.append(dict(id=row["id"],kind=row["kind"],parts=row["parts"],den=row["den"],full_visits=full,
                            direct=direct,learned=learned))
        if not rejected:
            event=next(x for x in learned["events"] if x["receipt"]["hits"])
            receipts=event["receipt"]
            local={**row,"parts":tuple(atlas.pose(p,row["den"],event["phase"],True) for p in row["parts"])}
            wrong={**receipts,"hits":["9"+receipts["hits"][0][1:],*receipts["hits"][1:]]}
            try:
                check_hits(atlas,local,wrong)
            except AssertionError:
                rejected=True
            else:
                raise AssertionError("A fabricated half-triangle address was accepted")
        print(row["id"],full,direct["visits"],learned["visits"],flush=True)
    assert rejected
    save("data/verified-v1.json",dict(status="CHECKED_FINITE_PENROSE_PHASE_OPTIMA",results=results,
                                     false_address="REJECTED"))


if __name__=="__main__":
    main()
