"""Record local cold-cache query timings, separate from exact work counts."""
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from window_model_v1 import Atlas, canonical_axis, freeze, linear, load, macro_axes, query, ring
from window_experiment_v1 import save


def main():
    runs=load("data/results-v1.json")
    bank=freeze(runs["bank"])
    checks=[]
    for spec,row in zip(load("input/cases-v1.json")["holdout"],runs["cases"],strict=True):
        expected=freeze(row["certificate"]["hits"])
        costs=[]
        for _ in range(7):
            for operation in (linear,canonical_axis,macro_axes,ring.imaginary_normal):
                operation.cache_clear()
            start=perf_counter_ns()
            run=query(Atlas(),spec,row["policy"],bank)
            costs.append((perf_counter_ns()-start)//1000)
            assert tuple(run["hits"])==expected
        checks.append(dict(id=spec["id"],microseconds=costs,median_microseconds=median(costs)))
    save("data/timing-v1.json",dict(status="LOCAL_QUERY_WALL_CLOCK",trials=7,cases=checks))


if __name__=="__main__":
    main()
