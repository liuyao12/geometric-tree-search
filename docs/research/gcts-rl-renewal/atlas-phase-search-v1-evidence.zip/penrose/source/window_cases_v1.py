"""Freeze training and evaluation regions without consulting the atlas."""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from window_model_v1 import ROOT, ONE, UNIT, PROTOS, times
from check_v1 import plus


def xy(x,y):
    return plus(times(x,ONE),times(y,UNIT))


def outline(origin,x,y,left,right,bottom,top):
    def point(i,j):
        return plus(origin,plus(times(i,x),times(j,y)))
    return [point(left,bottom),point(right,bottom),point(right,top),point(left,top)]


def region(label,description,origin,frame,boxes,den=1):
    return dict(id=label,description=description,den=den,
                parts=[outline(origin,*frame,*v) for v in boxes])


def main():
    grid=(ONE,UNIT)
    slant=(xy(2,1),xy(-1,2))
    bevel=(xy(3,-1),xy(1,3))
    training=[]
    for i in range(42):
        frame=(grid,slant,slant,bevel,slant,bevel)[i%6]
        a,b=((i*71+5)*(1+i%3), -(37*i+9)*(1+i%2))
        training.append(region(f"train-{i:02}","Training parallelogram",
                               xy(a,b),frame,[(-2,3,-2,2)],4))
    regions=[
        dict(id="seed-half",description="Window exactly on a prototype triangle",den=1,parts=[PROTOS[0]]),
        region("local-grid","Small oblique box near the seed",xy(1,-1),grid,[(-3,3,-3,3)],2),
        region("local-bend","Slanted L-shaped window",xy(-4,3),slant,[(-4,5,-3,0),(-4,-1,0,5)],4),
        region("hole","Four slanted strips around an open hole",xy(3,5),slant,
               [(-7,7,-7,-4),(-7,7,4,7),(-7,-4,-4,4),(4,7,-4,4)],4),
        region("local-large","Larger slanted window",xy(-3,-8),bevel,[(-9,9,-7,7)],3),
        region("remote-million","Slanted window far from the seed",xy(2_000_017,-3_000_061),slant,[(-5,5,-3,3)],3),
        region("remote-billion","Oblique window at a billion-unit offset",xy(-2_000_000_013,3_000_000_047),grid,
               [(-5,5,-4,4)],3),
        dict(id="split-remote",description="Two small windows with a distant gap",den=5,
             parts=[outline(xy(-3,7),*slant,-3,4,-2,4),
                    outline(xy(1_700_001_001,-6_112_097_111),*bevel,-3,4,-2,4)]),
    ]
    doc=dict(schema="PENROSE-CYCLOTOMIC-WINDOWS-v1",donors=training[:18],training=training[18:],holdout=regions)
    (ROOT/"input/cases-v1.json").write_text(json.dumps(doc,sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
