"""Learn directional exclusion witnesses and rank their use on new windows."""
from collections import Counter, defaultdict
from pathlib import Path
from random import Random
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from window_model_v1 import Atlas, ROOT, Window, load, query

ACTIONS=("macro","receiver","bank","matched")


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def cost(result):
    c=result["counts"]
    return sum(c[k] for k in ("supports","node_projections","window_projections"))


def select(samples):
    return min(ACTIONS,key=lambda a:sum(samples[a])/len(samples[a]))


def small(result):
    return {k:v for k,v in result.items() if k not in ("rhombs","skips","hits","boundary")}


def main():
    atlas=Atlas()
    config=load("input/cases-v1.json")
    evidence,donor_counts=[],Counter()
    for spec in config["donors"]:
        result=query(atlas,spec,trace=False,learn=True)
        donor_counts.update(dict(result["marks"]))
        evidence.append(dict(id=spec["id"],axes=result["marks"]))
    bank=tuple(d for d,_ in sorted(donor_counts.items(),key=lambda kv:(-kv[1],kv[0]))[:4])
    assert bank and all(donor_counts[d]>0 for d in bank)
    rng=Random(79431)
    sample=defaultdict(lambda:defaultdict(list))
    episodes=[]
    for spec in config["training"]:
        group=Window(spec).shape_group
        costs=sample[group]
        available=[a for a in ACTIONS if not costs[a]]
        action=available[0] if available else rng.choice(ACTIONS) if rng.random()<.25 else select(costs)
        run=query(atlas,spec,action,bank,trace=False)
        costs[action].append(cost(run))
        episodes.append(dict(id=spec["id"],group=group,action=action,cost=cost(run)))
    policy={g:select(sample[g]) for g in sorted(sample)}
    cases=[]
    for spec in config["holdout"]:
        order=policy[Window(spec).shape_group]
        expected=query(atlas,spec,"macro")
        comparison={"macro":small(expected)}
        for action in ACTIONS[1:]:
            current=query(atlas,spec,action,bank)
            for key in ("hits","rhombs","boundary","by_level"):
                assert current[key]==expected[key]
            comparison[action]=small(current)
        accepted=query(atlas,spec,order,bank)
        assert accepted["hits"]==expected["hits"] and accepted["rhombs"]==expected["rhombs"]
        cases.append(dict(id=spec["id"],policy=order,certificate=accepted,comparison=comparison))
        print(json.dumps(dict(id=spec["id"],depth=expected["level"],policy=order,
                              visits=accepted["counts"]["visited"],retained=accepted["counts"]["retained"],
                              costs={a:cost(r) for a,r in comparison.items()})),flush=True)
    save("data/results-v1.json",dict(status="CHECKED_EXACT_HIERARCHICAL_PENROSE_WINDOWS",
        donors=evidence,bank=bank,episodes=episodes,sample=sample,policy=policy,cases=cases))


if __name__=="__main__":
    main()
