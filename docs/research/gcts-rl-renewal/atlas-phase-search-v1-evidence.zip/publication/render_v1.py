"""Draw exact phase selections, boundary witnesses, and matched controls."""
from fractions import Fraction
from html import escape
from math import cos,pi,sin,sqrt
from pathlib import Path
from statistics import median
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"study/source"))
from phase_policy_v1 import scalar


def read(path):
    return json.loads((ROOT/path).read_text())


def table(headers,rows):
    head="".join(f'<th scope="col">{x}</th>' for x in headers)
    body="".join("<tr>"+"".join(f"<td>{cell}</td>" for cell in row)+"</tr>" for row in rows)
    return f'<div class="table"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def add(a,b):
    return tuple(x+y for x,y in zip(a,b,strict=True))


def rotate(p,turn):
    for _ in range((3*turn)%5):
        w,x,y,z=p
        p=(-z,w-z,x-z,y-z)
    return tuple(-x for x in p) if turn%2 else p


def mat(m,p):
    return tuple(sum(x*y for x,y in zip(row,p,strict=True)) for row in m)


def project(name,p):
    if name=="turtle":
        x,y=p
        return x+y/2,-sqrt(3)*y/2
    return (sum(x*cos(2*pi*i/5) for i,x in enumerate(p)),
            -sum(x*sin(2*pi*i/5) for i,x in enumerate(p)))


def svg(name,layers,caption,point=None):
    origin=layers[0][0][0]
    def local(p):
        return project(name,tuple(x-y for x,y in zip(p,origin,strict=True)))
    content=[]
    paths=[(tuple(map(local,poly)),css) for poly,css in layers]
    x,y=zip(*(p for poly,_ in paths for p in poly))
    dx,dy=max(x)-min(x),max(y)-min(y)
    pad=.07*max(dx,dy)
    box=f"{min(x)-pad:.5f} {min(y)-pad:.5f} {dx+2*pad:.5f} {dy+2*pad:.5f}"
    for poly,css in paths:
        coords=" ".join(f"{a:.5f},{b:.5f}" for a,b in poly)
        tag="polyline" if len(poly)==2 else "polygon"
        content.append(f'<{tag} class="{css}" points="{coords}"/>')
    if point is not None:
        a,b=local(point)
        content.append(f'<circle class="point" cx="{a:.5f}" cy="{b:.5f}" r="{.023*max(dx,dy):.5f}"/>')
    return (f'<figure><svg role="img" aria-label="{escape(caption)}" viewBox="{box}">{"".join(content)}</svg>'
            f'<figcaption>{caption}</figcaption></figure>')


MODEL=read("turtle/input/exact-point-model-v1.json")
POSES={row["id"]:row["matrix"] for row in MODEL["groups"]}


def turtle_tile(t):
    turn,x,y=t
    return tuple(add(mat(POSES[turn],p),(x,y)) for p in MODEL["polygon"])


def core(name,row):
    if name=="turtle":
        return (row["ring"],)
    return tuple(tuple(tuple(Fraction(x,row["den"]) for x in p) for p in poly) for poly in row["parts"])


def mass(value):
    if isinstance(value,int):
        return str(value)
    a,b=value
    return f"\\({a}+{b}\\phi\\)"


def cover_view(name,row,event,caption):
    tiles=event["tiles"]
    layers=[(turtle_tile(t),"tile") if name=="turtle" else
            (t["vertices"],"tile thick" if t["kind"] else "tile") for t in tiles]
    layers.extend((p,"core") for p in core(name,row))
    return svg(name,layers,caption)


def cover_comparison(name,cert):
    movable=[r for r in cert["results"] if r["kind"]=="movable"]
    def improvement(row):
        initial=row["learned"]["events"][0]
        s=len(initial["tiles"]) if name=="turtle" else initial["score"]
        return scalar(s)-scalar(row["learned"]["score"])
    best=max(movable,key=improvement)
    result=best["learned"]
    initial=result["events"][0]
    final=next(e for e in result["events"] if e["phase"]==result["winner"])
    a,b=(len(initial["tiles"]),len(final["tiles"])) if name=="turtle" else (initial["score"],final["score"])
    left=cover_view(name,best,initial,f"{name.title()} original phase with score {mass(a)}")
    right=cover_view(name,best,final,f"{name.title()} chosen phase with score {mass(b)}")
    return f'<div class="grid pair">{left}{right}</div>'


def crossing(name,oracle,marks):
    run=next(r for r in marks["results"] if r["outcomes"]["learned"]["cuts"])
    witness=run["outcomes"]["learned"]["cuts"][0]
    row=next(r for r in oracle["requests"] if r["id"]==run["id"])
    turn,x,y=oracle["phases"][witness["phase"]]
    raw=witness["witness"]["tile"]
    if name=="turtle":
        tile=tuple(add(mat(POSES[turn],p),(x,y)) for p in turtle_tile(raw))
    else:
        translation=add((x,0,0,0),tuple(y*a for a in rotate((1,0,0,0),1)))
        tile=tuple(add(rotate(p,turn),translation) for p in raw["vertices"])
    edge=witness["edge"]
    point=tuple(Fraction(x+y,2) for x,y in zip(*edge,strict=True))
    return svg(name,[(p,"region") for p in core(name,row)]+[(tile,"fail"),(edge,"port")],
               f"{name.title()} candidate tile crossing the exposed segment",point)


def main():
    policy=read("study/data/policy-v1.json")["results"]
    optimum=[];routes=[];local=[]
    comparisons=[];witnesses=[]
    notes=[];negative=[]
    for name in ("turtle","penrose"):
        oracle=read(f"{name}/data/oracle-v1.json")
        cert=read(f"{name}/data/verified-v1.json")
        marks=read(f"{name}/data/receptors-v1.json")
        rejected=read(f"{name}/data/negative-phases-v1.json")
        negative.append((name.title(),len(rejected["results"]),rejected["absent"],
            sum(r["baseline"]["full_queries"] for r in rejected["results"]),
            sum(r["learned"]["full_queries"] for r in rejected["results"])))
        measured=read(f"{name}/data/receptor-timing-v1.json")["ns"]
        if "learned-uncached" in measured:
            notes.append(f'Penrose with uncached probe geometry took a median of '
                         f'{median(measured["learned-uncached"])/1e6:.1f} milliseconds.')
        r=cert["results"]
        optimum.append((name.title(),len(r),sum(x["kind"]=="fixed" for x in r),
            *(f"{v:,}" for v in (sum(x["full_visits"] for x in r),sum(x["direct"]["visits"] for x in r),
                                 sum(x["learned"]["visits"] for x in r),sum(x["learned"]["cuts"] for x in r)))))
        comparisons.append(cover_comparison(name,cert))
        witnesses.append(crossing(name,oracle,marks))
        for arm in ("nearby","shuffle","trained-static","learned"):
            row=policy[name]["totals"][arm]
            routes.append((name.title(),arm.replace("-"," "),f'{row["optimal"]} / {len(r)}',
                           row["fixed"],row["calls"]))
        for arm in ("baseline","first","long","learned"):
            row=marks["totals"][arm]
            time=f'{median(measured[arm])/1e6:.1f}' if arm in measured else "—"
            local.append((name.title(),arm,row["cuts"],row["full_queries"],f'{row["visits"]:,}',time))
    values=dict(OPTIMAL=table(("System","Requests","Exact fixed matches","Exhaustive visits",
         "Ordered cuts visits","Learned-first cuts visits","Certified partial cuts"),optimum),
        WINDOWS="".join(comparisons),POLICY=table(("System","Policy","Optima in four queries",
         "Exact fixed matches","Queries"),routes),RECEPTORS=table(("System","Probe order","Cuts","Full queries",
         "Hierarchy visits","Median batch ms"),local)+
         "<p>Timing covers five matched repeats with a fresh atlas per batch and includes checking the midpoint witnesses. "
         +" ".join(notes)+"</p>",
        CROSSINGS='<div class="grid">'+"".join(witnesses)+"</div>")
    values["NEGATIVES"]=table(("System","Authored targets","No registered match",
                              "Baseline full queries","With probes"),negative)
    html=(ROOT/"publication/notebook-v1.html").read_text()
    for k,v in values.items():
        html=html.replace(f"%%{k}%%",v)
    assert "%%" not in html
    (ROOT/"report/atlas-phase-search-v1.html").write_text(html)


if __name__=="__main__":
    main()
