# Replay the exact phase search

From the study root, use CPython 3.12.

```sh
python3.12 -I -S -B publication/replay_v1.py
```

The clean replay regenerates the 18-phase score tables, trains the proposal policies, replays the checked phase cutoffs and coverage witnesses, relearns the midpoint ranking, reruns the authored fixed-boundary controls, and rebuilds the visual notebook. It compares ten outputs byte for byte with the retained copies. Timing receipts are retained as inputs so the HTML is reproducible.

To repeat the measured fixed-boundary searches separately, run these commands. Wall-clock results depend on the machine.

```sh
python3.12 -I -S -B study/source/receptor_timing_v1.py turtle
python3.12 -I -S -B study/source/receptor_timing_v1.py penrose
```

The earlier plane certificates are the basis for the two atlases. The verified optima in this experiment range over the registered finite phase families.
