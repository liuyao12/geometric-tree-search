"""Package the atlas phase study and the inputs needed to replay it."""
from hashlib import sha256
import json
from pathlib import Path
import re
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
from replay_v1 import OUTPUTS, ROOT, inputs


def pin(raw):
    return {"bytes": len(raw), "sha256": sha256(raw).hexdigest()}


def main():
    replay = json.loads((ROOT / "publication/replay-v1.json").read_text())
    assert set(replay["sha256"]) == set(OUTPUTS)
    for name, digest in replay["sha256"].items():
        assert pin((ROOT / name).read_bytes())["sha256"] == digest, name

    evidence = (
        *inputs(), *OUTPUTS, "publication/REPLAY.md", "publication/replay-v1.json",
        "publication/browser-v1.json",
    )
    archive = ROOT / "report/atlas-phase-search-v1-evidence.zip"
    manifest = {}
    with ZipFile(archive, "w") as bundle:
        for name in evidence:
            raw = (ROOT / name).read_bytes()
            assert name not in manifest, name
            assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            manifest[name] = pin(raw)
            entry = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            entry.external_attr = 0o100644 << 16
            bundle.writestr(entry, raw, compress_type=ZIP_DEFLATED, compresslevel=9)

    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {name: pin(bundle.read(name)) for name in bundle.namelist()} == manifest

    notebook = ROOT / "report/atlas-phase-search-v1.html"
    assets = {path.name: pin(path.read_bytes()) for path in (notebook, archive)}
    receipt = {"schema": "ATLAS-PHASE-SEARCH-MANIFEST-v1", "archive_entries": manifest, "assets": assets}
    (ROOT / "report/atlas-phase-search-v1-manifest.json").write_text(
        json.dumps(receipt, sort_keys=True, indent=2) + "\n"
    )
    print(f"Packaged {len(manifest)} evidence files.")


if __name__ == "__main__":
    main()
