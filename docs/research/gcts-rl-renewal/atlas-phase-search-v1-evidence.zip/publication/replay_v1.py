"""Rebuild the exact phase study and reader in a clean directory."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
SYSTEMS=("turtle","penrose")
STAGES=(
    *((name,"source/atlas_phases_v1.py") for name in SYSTEMS),
    (".","study/source/phase_policy_v1.py"),
    *((name,f"source/{stage}_v1.py") for name in SYSTEMS for stage in ("phase_verify","receptor_points")),
    *((".","study/source/negative_phases_v1.py",name) for name in SYSTEMS),
    (".","publication/render_v1.py"),
)
OUTPUTS=tuple(f"{name}/data/{part}-v1.json" for name in SYSTEMS for part in ("oracle","verified","receptors","negative-phases"))+(
    "study/data/policy-v1.json","report/atlas-phase-search-v1.html")


def inputs():
    folders=("turtle/source","penrose/source","study/source","publication")
    source=sorted(str(p.relative_to(ROOT)) for folder in folders for p in (ROOT/folder).glob("*.py"))
    inherited=sorted(str(p.relative_to(ROOT)) for name in SYSTEMS for p in (ROOT/name/"input").glob("*.json"))
    return (*source,*inherited,"publication/notebook-v1.html",
            *(f"{name}/data/receptor-timing-v1.json" for name in SYSTEMS))


def main():
    retained=inputs()
    hashes={}
    with TemporaryDirectory() as temporary:
        clean=Path(temporary)
        for path in (*retained,*OUTPUTS):
            (clean/path).parent.mkdir(parents=True,exist_ok=True)
        for path in retained:
            shutil.copyfile(ROOT/path,clean/path)
        for folder,script,*args in STAGES:
            subprocess.run([sys.executable,"-I","-S","-B",script,*args],cwd=clean/folder,check=True)
        for path in OUTPUTS:
            expected,actual=(ROOT/path).read_bytes(),(clean/path).read_bytes()
            assert actual==expected,path
            hashes[path]=sha256(actual).hexdigest()
    receipt=dict(status="CHECKED_CLEAN_REPLAY",sha256=hashes)
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print("Matched",len(hashes),"outputs byte for byte.")


if __name__=="__main__":
    main()
