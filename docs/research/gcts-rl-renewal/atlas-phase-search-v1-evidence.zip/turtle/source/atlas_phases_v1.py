"""Search registered Turtle atlas phases with exact overlap bounds."""
from itertools import product
from pathlib import Path
from random import Random
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import Geometry
from cluster_v1 import Model,load,mat
from collar_audit_v1 import Audit,freeze
from golden_geometry_v1 import add,sub,transform
from triangle_geometry_v1 import area2,positive_overlap,triangulate
from window_v1 import Hierarchy,audit_window,rectangle

PHASES=((0,0,0),)+tuple((g,x,y) for g,x,y in product((0,6),(-1,0,1),(-1,0,1)) if (g,x,y)!=(0,0,0))


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,sort_keys=True,separators=(",",":"))+"\n")


def compact_ring(ring):
    def turn(a,b,c):
        x,y=sub(b,a)
        u,v=sub(c,b)
        return x*v-y*u
    return tuple(b for i,b in enumerate(ring) if turn(ring[i-1],b,ring[(i+1)%len(ring)]))


class TurtleAtlas:
    def __init__(self):
        self.model=Model(load("input/exact-point-model-v1.json"))
        rule=freeze(load("input/coordinate-v1.json"))["rule"]
        alphabet=freeze(load("input/recovered-production-v1.json"))["alphabet"]
        self.hierarchy=Hierarchy(self.model,rule,alphabet)
        self.geometry=Geometry(self.model)
        self.audit=Audit(self.model)
        self.tile_area=area2(self.model.polygons[0])
        assert self.geometry.rot2==6

    def map(self,ring,phase):
        g,x,y=PHASES[phase]
        return tuple(add(mat(self.model.groups[g],p),(x,y)) for p in ring)

    def local(self,ring,phase):
        g,x,y=PHASES[phase]
        inverse=next(h for h in self.model.groups if self.model.compose[h,g]==0)
        return tuple(mat(self.model.groups[inverse],sub(p,(x,y))) for p in ring)

    def locate(self,ring,phase,limit=None,*,deeper=False,witness=False):
        g,x,y=PHASES[phase]
        local=self.local(ring,phase)
        n=self.hierarchy.root(local)[0]+2 if deeper else None
        tiles,receipt=self.hierarchy.query(local,n,stop=limit,witness=witness)
        return transform(self.model,tiles,g,(x,y)),receipt

    def check_cut(self,ring,tiles,bound):
        assert len(tiles)==len(set(tiles))==bound
        target=triangulate(ring)
        assert all(any(positive_overlap(a,b) for a in triangulate(self.model.poly(t)) for b in target)
                   for t in tiles)

    def check_paths(self,ring,phase,tiles,receipt):
        turn,dx,dy=PHASES[phase]
        level,g0=self.hierarchy.root(self.local(ring,phase))
        assert level==receipt["level"] and g0==receipt["turn"]
        self.hierarchy.ensure(level)
        found=[]
        for address in receipt["paths"]:
            key,g,offset=("T",level),g0,(0,0)
            for i in address[:-1]:
                children=self.hierarchy.nodes[key].children
                assert type(i) is int and 0<=i<len(children)
                label,n,h,shift=children[i]
                key=(label,n)
                offset=add(offset,mat(self.model.groups[g],shift))
                g=self.model.compose[g,h]
            leaves=self.hierarchy.nodes[key].tiles
            i=address[-1]
            assert type(i) is int and 0<=i<len(leaves)
            h,x,y=self.model.action(g,leaves[i])
            found.append((h,*add((x,y),offset)))
        assert transform(self.model,found,turn,(dx,dy))==tiles


def cases(atlas):
    random=Random(98271)
    choices=[]
    for split,total in (("train",16),("test",14)):
        for i in range(total):
            x,y=((i+3)*157,(-9-i)*91) if split=="train" else ((-i-2)*541,(i+11)*263)
            source,_=atlas.locate(rectangle(x,y,18,18),0)
            seed=min(source,key=lambda t:(sum(abs(a-b) for a,b in zip(t[1:],(x+9,y+9),strict=True)),t))
            patch=[seed]
            for _ in range(i%3):
                frontier=atlas.geometry.boundary(tuple(sorted(patch)))
                for tile in source:
                    if tile in patch or not any((b,a) in frontier for a,b in atlas.geometry.boundary((tile,))):
                        continue
                    candidate=tuple(sorted((*patch,tile)))
                    if atlas.geometry.ring(candidate):
                        patch.append(tile)
                        break
            phase=random.randrange(len(PHASES))
            ring=compact_ring(atlas.geometry.ring(tuple(sorted(patch))))
            rotated=atlas.map(ring,phase)
            choices.append(dict(id=f"{split}-fixed-{i:02d}",split=split,kind="fixed",
                                ring=rotated,construction_phase=phase,expected=len(patch)))
            u,v=(8+2*(i%6),9+3*(i%4))
            ring=rectangle(x+37,y-39,u,v)
            if i%3==1:
                a,b=ring[0]
                ring=((a,b),(a+u,b),(a+u,b+3),(a+4,b+3),(a+4,b+v),(a,b+v))
            elif i%3==2:
                ring=tuple((a+(b-y+39)//2,b) for a,b in ring)
            if split=="test" and i==total-1:
                ring=tuple(add(p,(10**28,-10**28)) for p in ring)
            choices.append(dict(id=f"{split}-movable-{i:02d}",split=split,kind="movable",ring=ring))
    return choices


def features(ring,area,tile_area):
    return f"{'integral' if area%tile_area==0 else 'fractional'}-{'quadrilateral' if len(ring)==4 else 'other'}"


def main():
    atlas=TurtleAtlas()
    result=[]
    for row in cases(atlas):
        ring=row["ring"]
        area=area2(ring)
        minimum=(area+atlas.tile_area-1)//atlas.tile_area
        arms=[]
        for phase in range(len(PHASES)):
            tiles,stats=atlas.locate(ring,phase)
            assert len(tiles)>=minimum
            arms.append(dict(score=len(tiles),counts=stats["counts"]))
        best=min(r["score"] for r in arms)
        if row["kind"]=="fixed":
            assert arms[row["construction_phase"]]["score"]==row["expected"]==best==minimum
        result.append(dict(**row,area2=area,area_bound=minimum,minimum=best,
                           context=features(ring,area,atlas.tile_area),arms=arms))
        print(row["id"],best,arms[0]["score"],flush=True)
    save("data/oracle-v1.json",dict(status="CHECKED_TURTLE_PHASE_ORACLE",
        phases=PHASES,tile_area2=atlas.tile_area,requests=result))


if __name__=="__main__":
    main()
