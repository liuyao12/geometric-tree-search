"""Use interior midpoint witnesses to reject fixed-boundary Turtle phases."""
from fractions import Fraction
from itertools import pairwise
from math import gcd
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(ROOT.parent/"study/source"))
from atlas_phases_v1 import PHASES,TurtleAtlas,save
from cluster_v1 import inside,mat
from collar_audit_v1 import freeze
from golden_geometry_v1 import add,sub,transform
from receptor_driver_v1 import study
from window_v1 import AXES,dot,squared_norm


def strict(p,poly):
    edges=tuple(pairwise((*poly,poly[0])))
    for a,b in edges:
        u,v=sub(b,a)
        x,y=sub(p,a)
        if u*y==v*x and all(min(i,j)<=k<=max(i,j) for i,j,k in zip(a,b,p,strict=True)):
            return False
    return inside(p,edges)


class TurtleReceptors:
    def __init__(self):
        self.atlas=TurtleAtlas()

    def edges(self,row):
        return tuple(pairwise((*row["ring"],row["ring"][0])))

    def length(self,edge):
        return squared_norm(sub(*edge))

    def feature(self,edge):
        d=sub(*edge)
        n=gcd(*d)
        u=tuple(v//n for v in d)
        return max(u,tuple(-v for v in u)),int(n>1)

    def exact(self,row,phase):
        return row["arms"][phase]["score"]==row["expected"]

    def full(self,row,phase):
        tiles,receipt=self.atlas.locate(row["ring"],phase)
        return len(tiles)==row["expected"],receipt["counts"]["visited"]

    def local_point(self,edge,phase):
        doubled=add(*edge)
        model=self.atlas.model
        g,x,y=PHASES[phase]
        inverse=next(h for h in model.groups if model.compose[h,g]==0)
        return mat(model.groups[inverse],sub(doubled,(2*x,2*y)))

    def probe(self,row,phase,edge):
        point=self.local_point(edge,phase)
        h=self.atlas.hierarchy
        model=self.atlas.model
        depth,g0=h.root((tuple(Fraction(a,2) for a in point),))
        projected=tuple(dot(u,point) for u in AXES)
        pending=[(("T",depth),g0,(0,0),())]
        visits=0
        while pending:
            key,g,offset,path=pending.pop()
            visits+=1
            node=h.nodes[key]
            box=h.placed_bounds(node.bounds,g,offset)
            if not all(2*a<=p<=2*b for p,(a,b) in zip(projected,box,strict=True)):
                continue
            if node.children:
                for i,(label,n,t,shift) in enumerate(node.children):
                    pending.append(((label,n),model.compose[g,t],add(offset,mat(model.groups[g],shift)),(*path,i)))
            else:
                for i,t in enumerate(node.tiles):
                    t,=transform(model,(t,),g,offset)
                    if strict(point,tuple((2*a,2*b) for a,b in model.poly(t))):
                        return dict(tile=t,path=(*path,i),depth=depth,turn=g0),visits
        return None,visits

    def verify(self,row,phase,edge,witness):
        point=self.local_point(edge,phase)
        h=self.atlas.hierarchy
        model=self.atlas.model
        depth,g0=h.root((tuple(Fraction(a,2) for a in point),))
        assert (depth,g0)==(witness["depth"],witness["turn"])
        key,g,offset=("T",depth),g0,(0,0)
        for i in witness["path"][:-1]:
            children=h.nodes[key].children
            assert type(i) is int and 0<=i<len(children)
            label,n,t,shift=children[i]
            key=(label,n)
            offset=add(offset,mat(model.groups[g],shift))
            g=model.compose[g,t]
        leaves=h.nodes[key].tiles
        i=witness["path"][-1]
        assert type(i) is int and 0<=i<len(leaves)
        tile,=transform(model,(leaves[i],),g,offset)
        assert tile==witness["tile"]
        assert strict(point,tuple((2*a,2*b) for a,b in model.poly(tile)))


def main():
    oracle=freeze(json.loads((ROOT/"data/oracle-v1.json").read_text()))
    save("data/receptors-v1.json",study(oracle,TurtleReceptors()))


if __name__=="__main__":
    main()
