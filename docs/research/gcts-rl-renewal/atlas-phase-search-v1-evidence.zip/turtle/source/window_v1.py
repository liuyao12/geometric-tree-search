"""Extract an exact polygon window from the proved nested Turtle tiling."""
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import Geometry, save
from cluster_v1 import Model, load, mat
from collar_audit_v1 import Audit, freeze
from coordinate_v1 import children, strip
from golden_geometry_v1 import add, polygon_points, support
from triangle_geometry_v1 import area2, overlap, positive_overlap, triangulate

AXES=((1,0),(0,1),(1,1))


def dot(axis,point):
    return sum(a*b for a,b in zip(axis,point,strict=True))


def bounds(points):
    points=tuple(points)
    return tuple((min(row),max(row)) for row in (tuple(dot(u,p) for p in points) for u in AXES))


def touches(a,b):
    return all(max(lo,p)<min(hi,q) for (lo,hi),(p,q) in zip(a,b,strict=True))


def squared_norm(p):
    x,y=p
    return x*x+x*y+y*y


@dataclass(frozen=True)
class Node:
    bounds: tuple
    count: int
    children: tuple = ()
    tiles: tuple = ()


class Hierarchy:
    def __init__(self,model,rule,alphabet):
        self.model=model
        self.rule=rule
        self.stride=alphabet["stride"]
        self.axes={}
        for turn,((a,b),(c,d)) in model.groups.items():
            maps=[]
            for x,y in AXES:
                u=(a*x+c*y,b*x+d*y)
                axis,sign=next((i,s) for i,v in enumerate(AXES) for s in (1,-1)
                               if u==(s*v[0],s*v[1]))
                maps.append((axis,sign))
            self.axes[turn]=tuple(maps)
        self.nodes={}
        self.lengths=[1,3]
        for key,tiles in [(("P",0),rule["bases"]["P0"]),(("T",1),rule["bases"]["T1"]),
                          (("W",0),strip(alphabet,(0,))),(("W",1),strip(alphabet,(0,0,1)))]:
            self.nodes[key]=Node(bounds(v for t in tiles for v in model.poly(t)),len(tiles),tiles=tiles)
        self.primitive={g:bounds(model.polygons[g]) for g in model.groups}
        self.triangles={g:triangulate(poly) for g,poly in model.polygons.items()}
        self.level=0

    def placed_bounds(self,box,turn,offset):
        result=[]
        for u,(i,sign) in zip(AXES,self.axes[turn],strict=True):
            a,b=box[i]
            if sign<0:
                a,b=-b,-a
            delta=dot(u,offset)
            result.append((a+delta,b+delta))
        return tuple(result)

    def put(self,key,steps):
        boxes=[self.placed_bounds(self.nodes[k,n].bounds,g,offset) for k,n,g,offset in steps]
        hull=tuple((min(v[i][0] for v in boxes),max(v[i][1] for v in boxes)) for i in range(3))
        self.nodes[key]=Node(hull,sum(self.nodes[k,n].count for k,n,_,_ in steps),children=tuple(steps))

    def ensure(self,level):
        for n in range(self.level+1,level+1):
            for j in range(len(self.lengths),2*n+1):
                a,b=self.lengths[-1],self.lengths[-2]
                self.lengths.append(a+b)
                delta=tuple(a*x for x in self.stride)
                self.put(("W",j),(("W",j-1,0,(0,0)),("W",j-2,0,delta)))
            a,b=self.lengths[2*n],self.lengths[2*n-2]
            self.nodes["S",n]=self.nodes["W",2*n]
            for k in ("T","P"):
                if (k,n) not in self.nodes:
                    self.put((k,n),children(self.model,self.rule,k,n,a,b))
        self.level=max(self.level,level)

    def disk(self,n):
        return 2*self.lengths[2*n]-self.lengths[2*n-2]-3

    def root(self,polygon):
        radius2=max(map(squared_norm,polygon))
        n=5
        self.ensure(n)
        while radius2>=self.disk(n)**2:
            n+=2
            self.ensure(n)
        return n,6 if ((n-1)//2)%2 else 0

    def query(self,polygon,level=None,*,stop=None,witness=False):
        query_box=bounds(polygon)
        target=triangulate(polygon)
        minimal,turn=self.root(polygon)
        if level is not None:
            assert level>=minimal and level%2
            turn=6 if ((level-1)//2)%2 else 0
        else:
            level=minimal
        self.ensure(level)
        result=[]
        paths=[]
        stats=Counter()
        stopped=False

        pending=[(('T',level),turn,(0,0),())]
        while pending:
            key,g,offset,address=pending.pop()
            node=self.nodes[key]
            stats["visited"]+=1
            if not touches(self.placed_bounds(node.bounds,g,offset),query_box):
                stats["pruned"]+=1
                continue
            if node.children:
                for i,(label,n,h,shift) in enumerate(node.children):
                    child=(*address,i) if witness else ()
                    pending.append(((label,n),self.model.compose[g,h],add(mat(self.model.groups[g],shift),offset),child))
                continue
            for i,tile in enumerate(node.tiles):
                stats['leaf_boxes']+=1
                h,x,y=self.model.action(g,tile)
                pos=add((x,y),offset)
                if not touches(self.placed_bounds(self.primitive[h],0,pos),query_box):
                    continue
                stats["polygon_checks"]+=1
                ts=[tuple(add(v,pos) for v in triangle) for triangle in self.triangles[h]]
                if any(positive_overlap(a,b) for a in ts for b in target):
                    result.append((h,*pos))
                    if witness:
                        paths.append((*address,i))
                    if stop is not None and len(result)>=stop:
                        stopped=True
                        pending.clear()
                        break

        result=tuple(sorted(result))
        assert len(set(result))==len(result)
        receipt=dict(level=level,turn=turn,root_tiles=self.nodes["T",level].count,
                     records=len(self.nodes),counts=dict(stats),returned=len(result))
        if stopped:
            receipt["cutoff"]=stop
        if witness:
            receipt["paths"]=paths
        return result,receipt


def audit_window(audit,ring,tiles):
    model=audit.model
    for i,t in enumerate(tiles):
        assert all(not audit.overlap(t,q) for q in tiles[:i])
    region=triangulate(ring)
    total=0
    for tile in tiles:
        covered=0
        for a in triangulate(model.poly(tile)):
            for b in region:
                result=overlap(a,b)
                if result["overlap"]:
                    covered+=Fraction(*result["witness"]["area2"])
        assert covered>0
        total+=covered
    window_area=area2(ring)
    assert total==window_area
    excess=len(tiles)*area2(model.polygons[0])-total
    assert excess>=0
    return dict(window_double_area=int(total),excess_double_area=int(excess),
                exact_fixed_boundary=excess==0)


def rectangle(x,y,w,h):
    return ((x,y),(x+w,y),(x+w,y+h),(x,y+h))


def compare_strips(model,rule,alphabet):
    depth=9
    compressed=Hierarchy(model,rule,alphabet)
    compressed.ensure(depth)
    level=depth-1
    a,b=compressed.lengths[2*level],compressed.lengths[2*level-2]
    d,e=compressed.lengths[2*depth],a
    _,_,g,offset=children(model,rule,"T",depth,d,e)[0]
    _,_,_,anchor=next(row for row in children(model,rule,"P",level,a,b) if row[0]=="S")
    middle=add(anchor,tuple((a//2)*x for x in alphabet["stride"]))
    x,y=add(offset,mat(model.groups[g],middle))
    ring=rectangle(x-12,y-12,24,24)
    compact_tiles,compact=compressed.query(ring,depth)

    flat=Hierarchy(model,rule,alphabet)
    flat.ensure(depth)
    words=[(0,),(0,0,1)]
    while len(words)<=2*depth:
        words.append(words[-1]+words[-2])
    total=0
    for i in range(1,depth+1):
        path=strip(alphabet,words[2*i])
        node=flat.nodes["S",i]
        assert node.bounds==bounds(p for tile in path for p in model.poly(tile))
        assert node.count==len(path)
        flat.nodes["S",i]=Node(node.bounds,node.count,tiles=path)
        total+=len(path)
    flat_tiles,literal=flat.query(ring,depth)
    assert flat_tiles==compact_tiles
    assert compact["counts"]["leaf_boxes"]<literal["counts"]["leaf_boxes"]
    return dict(polygon=ring,tiles=compact_tiles,compressed=compact,flat=literal,
                flat_strip_pose_records=total,compressed_strip_pose_records=4)


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    rule=freeze(load("input/coordinate-v1.json"))["rule"]
    alphabet=freeze(load("input/recovered-production-v1.json"))["alphabet"]
    audit=Audit(model)
    finite=freeze(load("input/predictions-v1.json"))["T5"]
    studies=[rectangle(0,0,24,24),rectangle(-174,56,24,24),
             rectangle(123456789,-250000000,24,24),rectangle(-10**12,10**12,24,24),
             ((-10**12,10**12),(-10**12+35,10**12+7),(-10**12+16,10**12+15),
              (-10**12+21,10**12+39),(-10**12-5,10**12+24)),
             rectangle(10**100,-10**100,24,24),Geometry(model).ring(rule["bases"]["T1"])]
    output=[]
    for j,ring in enumerate(studies):
        hierarchy=Hierarchy(model,rule,alphabet)
        tiles,receipt=hierarchy.query(ring)
        other,deeper=hierarchy.query(ring,receipt["level"]+2)
        assert tiles==other
        receipt["next_root_agreement"]=deeper["level"]
        receipt.update(audit_window(audit,ring,tiles))
        if j<2:
            target=polygon_points(model,(*ring,ring[0]))
            brute=tuple(t for t in finite if not target.isdisjoint(model.support(t)))
            assert brute==tiles
            receipt["literal_comparison"]=len(finite)
        if j<4 or j==5:
            target=polygon_points(model,(*ring,ring[0]))
            assert target<=support(model,tiles)
            assert all(not target.isdisjoint(model.support(t)) for t in tiles)
            receipt["sample_cells"]=len(target)
        output.append(dict(polygon=ring,tiles=tiles,**receipt))
        print(j,receipt,flush=True)
    comparison=compare_strips(model,rule,alphabet)
    print("strip ablation",comparison["compressed"]["counts"],comparison["flat"]["counts"],flush=True)
    save("data/windows-v1.json",dict(status="CHECKED_COMPRESSED_COORDINATE_WINDOWS",runs=output,
                                     strip_control=comparison))


if __name__=="__main__":
    main()
