"""Check finite-family optimality by coverage and lower-bound certificates."""
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from atlas_phases_v1 import PHASES,TurtleAtlas,save
from collar_audit_v1 import freeze
from window_v1 import audit_window


def run(atlas,row,planned):
    ring=row["ring"]
    best=None
    events=[]
    prefix=None
    order=(*planned,*(i for i in range(len(PHASES)) if i not in planned))
    for i,phase in enumerate(order,1):
        limit=len(best["tiles"]) if best else None
        tiles,receipt=atlas.locate(ring,phase,limit,witness=True)
        atlas.check_paths(ring,phase,tiles,receipt)
        atlas.check_cut(ring,tiles,len(tiles))
        if "cutoff" in receipt:
            assert len(tiles)==limit and row["arms"][phase]["score"]>=limit
        else:
            assert len(tiles)==row["arms"][phase]["score"]
        event=dict(phase=phase,tiles=tiles,receipt=receipt)
        events.append(event)
        if limit is None or len(tiles)<limit:
            assert "cutoff" not in receipt
            best=event
        if i==len(planned):
            prefix=len(best["tiles"])
        if len(best["tiles"])==row["area_bound"]:
            if prefix is None:
                prefix=len(best["tiles"])
            break
    assert len(best["tiles"])==row["minimum"] and prefix is not None
    exact=audit_window(atlas.audit,ring,best["tiles"])
    if row["kind"]=="fixed":
        assert exact["exact_fixed_boundary"]
    if not len(best["tiles"])==row["area_bound"]:
        assert len(events)==len(PHASES)
    deeper,_=atlas.locate(ring,best["phase"],deeper=True)
    assert deeper==best["tiles"]
    return dict(events=events,winner=best["phase"],score=len(best["tiles"]),prefix=prefix,
                coverage=exact,visits=sum(v["receipt"]["counts"]["visited"] for v in events),
                cuts=sum("cutoff" in v["receipt"] for v in events))


def main():
    atlas=TurtleAtlas()
    source=freeze(json.loads((ROOT/"data/oracle-v1.json").read_text()))
    policy=json.loads((ROOT.parent/"study/data/policy-v1.json").read_text())["results"]["turtle"]
    by_id={r["id"]:r for r in policy["trials"]}
    results=[]
    tested=False
    for row in source["requests"]:
        if row["split"]!="test":
            continue
        planned=by_id[row["id"]]["arms"]["learned"]
        direct=run(atlas,row,(0,))
        learned=run(atlas,row,planned["actions"])
        assert learned["prefix"]==planned["score"]
        full=sum(v["counts"]["visited"] for v in row["arms"])
        results.append(dict(id=row["id"],kind=row["kind"],ring=row["ring"],full_visits=full,
                            direct=direct,learned=learned))
        if not tested:
            event=next(x for x in learned["events"] if x["receipt"]["paths"])
            paths=event["receipt"]["paths"]
            wrong={**event["receipt"],"paths":[(*paths[0][:-1],999),*paths[1:]]}
            try:
                atlas.check_paths(row["ring"],event["phase"],event["tiles"],wrong)
            except AssertionError:
                tested=True
            else:
                raise AssertionError("A fabricated hierarchy address was accepted")
        print(row["id"],full,direct["visits"],learned["visits"],flush=True)
    assert tested
    save("data/verified-v1.json",dict(status="CHECKED_FINITE_TURTLE_PHASE_OPTIMA",results=results,
                                     false_address="REJECTED"))


if __name__=="__main__":
    main()
