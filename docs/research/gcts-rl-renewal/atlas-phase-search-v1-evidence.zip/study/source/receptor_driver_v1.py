"""Learn local boundary-probe order and compare equal-budget exact searches."""
from collections import Counter
from fractions import Fraction

BUDGET=2


def solve(oracle,adapter,row,mode,train,costs):
    edges=adapter.edges(row)
    if mode=="baseline":
        order=()
    elif mode=="learned":
        order=sorted(edges,key=lambda e:-Fraction(train[adapter.feature(e)],
                          max(1,costs[adapter.feature(e)])))[:BUDGET]
    elif mode=="long":
        order=sorted(edges,key=adapter.length,reverse=True)[:BUDGET]
    else:
        order=edges[:BUDGET]
    visits,probes,cuts,checked=0,0,[],0
    for phase,_ in enumerate(oracle["phases"]):
        rejected=False
        for edge in order:
            witness,work=adapter.probe(row,phase,edge)
            probes+=1
            visits+=work
            if witness is not None:
                adapter.verify(row,phase,edge,witness)
                assert not adapter.exact(row,phase)
                cuts.append(dict(phase=phase,edge=edge,witness=witness))
                rejected=True
                break
        if rejected:
            continue
        checked+=1
        found,work=adapter.full(row,phase)
        visits+=work
        assert found==adapter.exact(row,phase)
        if found:
            return dict(winner=phase,visits=visits,probes=probes,full_queries=checked,cuts=cuts)
    return dict(winner=None,visits=visits,probes=probes,full_queries=checked,cuts=cuts)


def study(oracle,adapter):
    train=Counter()
    costs=Counter()
    trials=[]
    for row in oracle["requests"]:
        if row["kind"]!="fixed":
            continue
        edges=adapter.edges(row)
        if row["split"]=="train":
            for phase,_ in enumerate(oracle["phases"]):
                for edge in edges:
                    witness,work=adapter.probe(row,phase,edge)
                    feature=adapter.feature(edge)
                    train[feature]+=int(witness is not None)
                    costs[feature]+=work
                    if witness:
                        assert not adapter.exact(row,phase)
            continue
        outcomes={mode:solve(oracle,adapter,row,mode,train,costs)
                  for mode in ("baseline","first","long","learned")}
        assert len({v["winner"] for v in outcomes.values()})==1 and outcomes["baseline"]["winner"] is not None
        trials.append(dict(id=row["id"],outcomes=outcomes))
        print(row["id"],{k:(v["visits"],v["full_queries"]) for k,v in outcomes.items()},flush=True)
    totals={mode:dict(visits=sum(t["outcomes"][mode]["visits"] for t in trials),
                       full_queries=sum(t["outcomes"][mode]["full_queries"] for t in trials),
                       cuts=sum(len(t["outcomes"][mode]["cuts"]) for t in trials))
            for mode in ("baseline","first","long","learned")}
    return dict(status="CHECKED_FIXED_PHASE_RECEPTORS",budget=BUDGET,results=trials,totals=totals,
                training=[(k,train[k],costs[k]) for k in sorted(costs)])
