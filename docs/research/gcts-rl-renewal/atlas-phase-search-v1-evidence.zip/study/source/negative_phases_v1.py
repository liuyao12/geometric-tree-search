"""Test authored area-compatible fixed outlines without a registered cover."""
from collections import Counter
from pathlib import Path
import json
import sys

BASE=Path(__file__).resolve().parents[2]
FAMILY=sys.argv[1]
ROOT=BASE/FAMILY
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(BASE/"study/source"))
from receptor_driver_v1 import solve
from atlas_phases_v1 import save

if FAMILY=="turtle":
    from receptor_points_v1 import TurtleReceptors as Adapter,freeze
    from window_v1 import rectangle
else:
    assert FAMILY=="penrose"
    from receptor_points_v1 import PenroseReceptors as Adapter,freeze_record as freeze
    from window_cases_v1 import region,xy
    from window_model_v1 import ONE,UNIT
    from model_v1 import rotate


def read(name):
    return freeze(json.loads((ROOT/f"data/{name}-v1.json").read_text()))


def cases(adapter):
    for i,(a,b) in enumerate(((4,5),(5,4),(8,5),(5,8),(12,5),(5,12))):
        if FAMILY=="turtle":
            expected=a*b*2//adapter.atlas.tile_area
            assert expected*adapter.atlas.tile_area==a*b*2
            yield dict(id=f"authored-fixed-{i}",ring=rectangle(183*i+11,-201*i+8,a,b),expected=expected)
        else:
            kind=i%2
            direction=UNIT if kind==0 else rotate(ONE,2)
            # The exact target area is checked below. The longer side and the
            # short side remain asymmetric under any unit-rhomb registration.
            n=2+i//2
            row=region(f"authored-fixed-{i}","Fixed asymmetric parallelogram",
                       xy(531*i+29,-471*i-31),(ONE,direction),[(0,4*n,0,1)],2)
            row["expected"]=tuple(n*x for x in adapter.atlas.weights[kind])
            assert adapter.atlas.target_area(row)==row["expected"]
            yield freeze(row)


def main():
    atlas=Adapter()
    oracle=read("oracle")
    marks=read("receptors")
    train=Counter({k:v for k,v,_ in marks["training"]})
    costs=Counter({k:w for k,_,w in marks["training"]})
    results=[]
    for row in cases(atlas):
        arms=[]
        for phase,_ in enumerate(oracle["phases"]):
            if FAMILY=="turtle":
                tiles,_=atlas.atlas.locate(row["ring"],phase)
                score=len(tiles)
            else:
                score,_,_,_=atlas.atlas.locate(row,phase)
            arms.append(dict(score=score))
        row=dict(**row,arms=arms)
        baseline=solve(oracle,atlas,row,"baseline",train,costs)
        learned=solve(oracle,atlas,row,"learned",train,costs)
        assert baseline["winner"]==learned["winner"]
        results.append(dict(request=row,baseline=baseline,learned=learned))
    assert any(r["baseline"]["winner"] is None for r in results)
    save("data/negative-phases-v1.json",dict(status="CHECKED_AUTHORED_FIXED_PHASES",results=results,
        absent=sum(r["baseline"]["winner"] is None for r in results)))
    print(FAMILY,sum(r["baseline"]["winner"] is None for r in results),
          sum(r["learned"]["full_queries"] for r in results),flush=True)


if __name__=="__main__":
    main()
