"""Learn which atlas registration to try next under a four-query budget."""
from collections import defaultdict
from fractions import Fraction
from functools import cmp_to_key
from hashlib import sha256
from math import sqrt
from pathlib import Path
from random import Random
import json

ROOT=Path(__file__).resolve().parents[2]
BUDGET=4
EPOCHS=18
ALGORITHMS=("nearby","shuffle","trained-static","learned")


def sign(a,b):
    x=2*a+b
    if not x or not b or (x>0)==(b>0):
        value=x or b
    else:
        value=(x*x-5*b*b)*(1 if x>0 else -1)
    return (value>0)-(value<0)


def compare(a,b):
    if isinstance(a,int):
        return (a>b)-(a<b)
    return sign(a[0]-b[0],a[1]-b[1])


def scalar(score):
    return float(score) if isinstance(score,int) else float(score[0])+float(score[1])*(1+sqrt(5))/2


def lower(row):
    return row["area_bound"] if "area_bound" in row else tuple(Fraction(*x) for x in row["area2"])


def better(a,b):
    return compare(a,b)<0


def complete(row,score):
    return compare(score,lower(row))==0


def read(family):
    return json.loads((ROOT/family/"data/oracle-v1.json").read_text())


def scores(row):
    return [r["score"] for r in row["arms"]]


def features(row,phase,steps,best,first):
    delta=max(0,scalar(first)-scalar(best))
    return row["context"], steps, int(phase!=0), min(3,int(delta))


class Policy:
    def __init__(self,seed,n):
        self.rng=Random(seed)
        self.n=n
        self.history=defaultdict(lambda:[0.0,0])
        self.updates=0

    def keys(self,feature,action):
        return (action,),(feature[0],action),(*feature,action)

    def choose(self,feature,options):
        def value(action):
            a,b,c=(self.history.get(k,(0,0)) for k in self.keys(feature,action))
            return (a[0]/max(1,a[1])+b[0]+2*c[0])/(1+b[1]+2*c[1])
        return max(options,key=value)

    def train(self,requests):
        for epoch in range(EPOCHS):
            order=requests[:]
            self.rng.shuffle(order)
            for row in order:
                mass=scores(row)
                available=list(range(1,self.n))
                first=best=mass[0]
                winning=0
                steps=[]
                for j in range(1,BUDGET):
                    if complete(row,best):
                        break
                    state=features(row,winning,j,best,first)
                    a=self.rng.choice(available) if epoch<3 or self.rng.random()<.3 else self.choose(state,available)
                    available.remove(a)
                    reward=0
                    if better(mass[a],best):
                        reward=scalar(best)-scalar(mass[a])
                        best,winning=mass[a],a
                    steps.append((state,a,reward))
                value=0
                for feature,action,reward in reversed(steps):
                    value=reward+.85*value
                    for key in self.keys(feature,action):
                        entry=self.history[key]
                        entry[0]+=value
                        entry[1]+=1
                    self.updates+=1


def trained_static(requests,n):
    known=[(scores(r),scores(r)[0]) for r in requests]
    chosen=[0]
    while len(chosen)<BUDGET:
        def utility(a):
            return sum(max(0,scalar(b)-scalar(values[a])) for values,b in known)
        a=max((i for i in range(1,n) if i not in chosen),key=utility)
        chosen.append(a)
        known=[(values,values[a] if better(values[a],b) else b) for values,b in known]
    return chosen


def rollout(row,phases,kind,policy,static):
    mass=scores(row)
    first=best=mass[0]
    winner=0
    available=list(range(1,len(phases)))
    if kind=="nearby":
        available.sort(key=lambda i:(abs(phases[i][1])+abs(phases[i][2]),phases[i][0]!=0,i))
    elif kind=="shuffle":
        seed=int(sha256(row["id"].encode()).hexdigest()[:8],16)
        Random(seed).shuffle(available)
    elif kind=="trained-static":
        available=static[1:]
    seen=[0]
    for j in range(1,BUDGET):
        if complete(row,best):
            break
        a=policy.choose(features(row,winner,j,best,first),available) if kind=="learned" else available[0]
        available.remove(a)
        seen.append(a)
        if better(mass[a],best):
            best,winner=mass[a],a
    return dict(actions=seen,winner=winner,score=best,optimal=compare(best,row["minimum"])==0,
                exact=row["kind"]=="fixed" and complete(row,best),
                gap=round(scalar(best)-scalar(row["minimum"]),8))


def main():
    results={}
    for name in ("turtle","penrose"):
        source=read(name)
        phases=source["phases"]
        train=[r for r in source["requests"] if r["split"]=="train"]
        test=[r for r in source["requests"] if r["split"]=="test"]
        assert not {r["id"] for r in train}&{r["id"] for r in test}
        policy=Policy(7511,len(phases))
        policy.train(train)
        static=trained_static(train,len(phases))
        trials=[]
        for row in test:
            arms={kind:rollout(row,phases,kind,policy,static) for kind in ALGORITHMS}
            trials.append(dict(id=row["id"],kind=row["kind"],minimum=row["minimum"],arms=arms))
        totals={kind:dict(optimal=sum(r["arms"][kind]["optimal"] for r in trials),
                          fixed=sum(r["arms"][kind]["exact"] for r in trials),
                          gap=round(sum(r["arms"][kind]["gap"] for r in trials),8),
                          calls=sum(len(r["arms"][kind]["actions"]) for r in trials)) for kind in ALGORITHMS}
        results[name]=dict(static=static,updates=policy.updates,training=len(train),test=len(test),
                           totals=totals,trials=trials)
        print(name,totals,flush=True)
    (ROOT/"study/data/policy-v1.json").write_text(
        json.dumps(dict(status="CHECKED_PHASE_POLICY",budget=BUDGET,results=results),sort_keys=True,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
