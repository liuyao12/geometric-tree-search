"""Repeat the same fixed requests and time certified probe and plain arms."""
from collections import Counter
from pathlib import Path
from statistics import median
from time import perf_counter_ns
import json
import sys

BASE=Path(__file__).resolve().parents[2]
FAMILY=sys.argv[1]
ROOT=BASE/FAMILY
sys.path.insert(0,str(ROOT/"source"))
sys.path.insert(0,str(BASE/"study/source"))
from receptor_driver_v1 import solve

if FAMILY=="turtle":
    from receptor_points_v1 import TurtleReceptors as Adapter,freeze
else:
    assert FAMILY=="penrose"
    from receptor_points_v1 import PenroseReceptors as Adapter,freeze_record as freeze


def read(name):
    return freeze(json.loads((ROOT/f"data/{name}-v1.json").read_text()))


def main():
    oracle=read("oracle")
    old=read("receptors")
    matches={r["id"]:r["outcomes"] for r in old["results"]}
    requests=[r for r in oracle["requests"] if r["id"] in matches]
    train=Counter({k:v for k,v,_ in old["training"]})
    costs=Counter({k:w for k,_,w in old["training"]})
    trials={"baseline":[],"learned":[]}
    if FAMILY=="penrose":
        trials["learned-uncached"]=[]
    for repeat in range(5):
        for arm in trials if repeat%2==0 else reversed(trials):
            adapter=Adapter(cache=arm!="learned-uncached") if FAMILY=="penrose" else Adapter()
            start=perf_counter_ns()
            mode=arm.split("-")[0]
            for row in requests:
                actual=solve(oracle,adapter,row,mode,train,costs)
                expected=matches[row["id"]][mode]
                assert (actual["winner"],actual["visits"])==(expected["winner"],expected["visits"])
            trials[arm].append(perf_counter_ns()-start)
    result=dict(status="MEASURED_FIXED_RECEPTOR_SEARCH",cases=len(requests),ns=trials)
    (ROOT/"data/receptor-timing-v1.json").write_text(json.dumps(result,sort_keys=True)+"\n")
    print(FAMILY,{k:round(median(v)/1e6,1) for k,v in trials.items()},flush=True)


if __name__=="__main__":
    main()
