"""Draw the two refinement profiles, all arrow gauges, and the searched proof."""
from cmath import exp, pi
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/source"), str(ROOT / "publication")]
from arrow_classes_v1 import read
from arrow_wang_v1 import prepare, problem
from boundary_kernel_v1 import build
from proof_views_v1 import frame_window, math, tile_svg
from standard_v1 import PROTOS, edges, place, scaled

NAME = "penrose-arrow-classes-20261106-v1"
BASIS = tuple(exp(2j*pi*k/5) for k in range(4))
FILLS = ("#91cdd1", "#c3a8e4")
INK = {1: "#13757b", 2: "#a64a6d", 3: "#536578"}


def xy(p):
    z = sum(a*b for a, b in zip(p, BASIS, strict=True))
    return z.real, -z.imag


def coords(points):
    return " ".join(f"{x:.5f},{y:.5f}" for x, y in points)


def polygon(poly, fill, width=.016, stroke="#4d6371"):
    return f'<polygon points="{coords(map(xy, poly))}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>'


def arrow(a, b, mark):
    if mark < 0:
        a, b = b, a
    x, y = xy(a)
    u, v = xy(b)
    dx, dy = u-x, v-y
    size = (dx*dx+dy*dy)**.5
    nx, ny = -dy/size, dx/size
    out = []
    for t in ((.50,) if abs(mark) == 1 else (.43, .57) if abs(mark) == 2 else (.36, .50, .64)):
        cx, cy = x+t*dx, y+t*dy
        points = ((cx-.045*dx/size+.025*nx, cy-.045*dy/size+.025*ny),
                  (cx+.043*dx/size, cy+.043*dy/size),
                  (cx-.045*dx/size-.025*nx, cy-.045*dy/size-.025*ny))
        out.append(f'<polyline points="{coords(points)}" fill="none" stroke="{INK[abs(mark)]}" '
                   'stroke-width=".017" stroke-linecap="round" stroke-linejoin="round"/>')
    return "".join(out)


def scene(parent, shapes, caption, pad=.06):
    x, y = zip(*map(xy, parent))
    view = f"{min(x)-pad:.5f} {min(y)-pad:.5f} {max(x)-min(x)+2*pad:.5f} {max(y)-min(y)+2*pad:.5f}"
    return (f'<figure><svg role="img" aria-label="{escape(caption)}" viewBox="{view}">{shapes}</svg>'
            f'<figcaption>{caption}</figcaption></figure>')


def geom_profile(record, i):
    parent = tuple(scaled(p, 1) for p in PROTOS[0])
    shapes = "".join(polygon(place(t), FILLS[t[0]]) for t in record["cells"])
    for route in record["routes"]:
        color = "#14747b" if len(route) == 2 else "#a75522"
        shapes += f'<polyline points="{coords(map(xy, route))}" fill="none" stroke="{color}" stroke-width=".027"/>'
        for p in route[1:-1]:
            x, y = xy(p)
            shapes += f'<circle cx="{x:.5f}" cy="{y:.5f}" r=".034" fill="#a75522" stroke="white" stroke-width=".012"/>'
    return scene(parent, shapes, f"Partition {i}. The teal side has one edge. The orange side has two.", .10)


def scheme(row):
    panels = []
    for k, cells in enumerate(row["rules"]):
        parent = tuple(scaled(p, 1) for p in PROTOS[k])
        shapes = "".join(polygon(place(t), FILLS[t[0]]) for t in cells)
        for t in cells:
            shapes += "".join(arrow(a, b, m) for (a, b), m in zip(edges(place(t)), row["marks"][t[0]], strict=True))
        panels.append(scene(parent, shapes, ("Acute", "Obtuse")[k] + " parent and marked children.", .08))
    return '<div class="grid">' + "".join(panels) + "</div>"


def growth(reference):
    nest = reference["nest"]
    shapes = "".join(polygon(place(t), FILLS[t[0]], .021) for t in nest["triangles"])
    shapes += polygon(place(nest["seed"]), "#efb951", .043, "#5d4d2e")
    return scene(nest["parent"], shapes, "The gold triangle lies strictly inside the fourth inflation.", .17)


def table(headers, rows, ident=""):
    head = "".join(f'<th scope="col">{h}</th>' for h in headers)
    data = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in rows)
    attr = f' id="{ident}"' if ident else ""
    return f'<div class="table" tabindex="0"{attr}><table><thead><tr>{head}</tr></thead><tbody>{data}</tbody></table></div>'


TOKENS = {"P1": r"P_1", "P2": r"P_2", "U": r"U"}
READINGS = {
    frozenset(("P1", "P2")): "The acute parent uses one of the two checked partitions.",
    frozenset(("U",)): "Assume the unit sides share a single receptor type.",
    frozenset(("-P1", "-U")): "Partition one has different refinements on its two unit sides.",
    frozenset(("-P2", "-U")): "Partition two has different refinements on its two unit sides.",
    frozenset(("-P1",)): "Under that assumption, partition one is ruled out.",
    frozenset(("-P2",)): "Under that assumption, partition two is ruled out.",
    frozenset(("P2",)): "The acute parent must use partition two.",
    frozenset(): "The single-receptor assumption leads to a contradiction.",
}


def wang():
    sources, proof, _ = problem()
    _, calls = prepare(proof, sources)
    bank = json.loads(gzip.decompress((ROOT / "wang/data/arrow-bank-v1.json.gz").read_bytes()))
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    rows, windows = [], []
    for i, (step, key) in enumerate(zip(proof, calls, strict=True), 1):
        literals = frozenset(("" if s else "-") + n for s, (n,) in step["clause"])
        formula = r"\lor ".join(("" if s else r"\neg ") + TOKENS[n] for s, (n,) in step["clause"]) or r"\bot"
        if step["rule"] == "R":
            op = f"Resolve lines {step['left']+1} and {step['right']+1} on {math(TOKENS[step['pivot'][0]])}."
        else:
            op = "Introduce the assumption." if step["source"] == "assume-one" else "Import a checked geometry clause."
        rows.append((i, op, math(formula), READINGS[literals]))
        evidence = bank["traces"][key]
        start = evidence["steps"]-5
        trace = dict(prefix=evidence["prefix"], word=evidence["word"], padding=0, trace=evidence["fragment"])
        tiles, first = frame_window(machine, trace, start, evidence["head"])
        ids, uses = {}, []
        for y, row in enumerate(tiles):
            for x, t in enumerate(row):
                j = ids.setdefault(t, len(ids))
                uses.append(f'<use href="#wang-{i}-{j}" x="{36*x}" y="{36*y}"/>')
        defs = "".join(tile_svg(t, f"{i}-{j}") for t, j in ids.items())
        windows.append(f'<details class="wang-row"><summary>Wang squares for line {i}</summary><figure>'
                       f'<svg role="img" aria-label="Wang squares for line {i}" viewBox="0 0 324 180">'
                       f'<defs>{defs}</defs>{"".join(uses)}</svg><figcaption>Verifier rows '
                       f'{start+1:,} to {start+5:,}, tape columns {first:,} to {first+8:,}.'
                       f'</figcaption></figure></details>')
    return table(("Line", "Checked operation", "Formula", "Reading"), rows, "proof-lines"), "".join(windows)


def main():
    data = read("data/arrow-study-v1.json")
    audit = read("data/arrow-audit-v1.json")
    reference = read("reference/standard-proof-v1.json")
    n = audit["standard"]["index"]
    controls = []
    templates = []
    for i, (row, transform) in enumerate(zip(data["systems"], audit["standard"]["gauge_from_standard"], strict=True)):
        controls.append(f'<option value="{i}"{" selected" if i == n else ""}>'
                        + ("Standard de Bruijn rule" if i == n else f"Equivalent encoding {i+1}") + "</option>")
        acute, obtuse, swap, one, two = transform
        flips = [name for flag, name in ((acute, "acute"), (obtuse, "obtuse")) if flag]
        pieces = ["Prototype frames " + ("reflected for " + " and ".join(flips) if flips else "kept")]
        pieces.append("unit labels " + ("exchanged" if swap else "kept"))
        signs = [name for sign, name in ((one, "single"), (two, "double")) if sign < 0]
        pieces.append("arrow directions " + ("reversed for " + " and ".join(signs) if signs else "kept"))
        templates.append(f'<template id="scheme-{i}">{scheme(row)}<p>{", ".join(pieces)}.</p></template>')
    profile = "".join(geom_profile(r, i) for i, r in enumerate(audit["profiles"], 1))
    signs = table(("Parent", "Partition", "Assignments", "Fail at seam", "Fail at receptor", "Survive"), [
        (("Acute", "Obtuse")[k], i, c["tried"], c.get("seam", 0), c.get("receptor", 0), c.get("admitted", 0))
        for k, group in enumerate(audit["one_magnitude"])
        for i, r in enumerate(group, 1) for c in (r["counts"],)])
    proof, windows = wang()
    title = "What the Penrose arrows have to distinguish"
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", title)
    head = head.replace("</style>", ".table:focus{outline:2px solid #13787b}"
                        "#minimum .grid svg,#markings .grid svg{height:15rem}"
                        "#plane figure,#wang .wang-row figure{max-width:35rem}"
                        "@media(max-width:43rem){#proof-lines table{min-width:0}"
                        "#proof-lines thead{position:absolute;clip-path:inset(50%)}"
                        "#proof-lines tr,#proof-lines td{display:block}#proof-lines tr{border-bottom:1px solid #d6e3e9}"
                        "#proof-lines td{border:0;padding:.14rem .3rem}}</style>")
    body = rf"""
<body><main><header><p class="kicker">GCTS research notebook · 6 November 2026</p>
<h1>{title}</h1>
<p>The exact search recovered 32 marked triangle substitutions. They form one class under
changes of notation and prototype frame. Geometry alone explains why the two unit-edge
receptor types are necessary.</p>
<nav><a href="#minimum">Why two marks</a><a href="#markings">Compare encodings</a><a href="#plane">Plane cover</a>
<a href="#wang">Wang proof</a><a href="{NAME}-evidence.zip">Replay archive</a></nav></header>
<section id="minimum"><h2>Two sides of the same length need different marks</h2>
<div class="grid">{profile}</div>
<p>The inputs are two unmarked golden triangles, ten rotation directions, reflections, and inflation
by \(\varphi\). Coordinates are exact in \(\mathbb{{Z}}[\zeta_5]\). The independent search starts at an
extreme corner and grows through full shared edges. It found two acute partitions and three obtuse partitions.</p>
<p>In each acute partition, the equal parent sides have different refinement profiles. One becomes
a single edge of length \(\varphi\). The other becomes edges of lengths \(1\) and \(\varphi^{{-1}}\).
Reversing directions preserves the number of edges in a profile. A single unit receptor would
require the same profile on both sides, so at least two types are necessary in this edge-to-edge rule model.</p>
<details><summary>Check the sign assignments for a single arrow type</summary>
<p>The table includes orientation choices for each child and all sign choices on the four unit edges.
The two base lengths keep their diagonal channel. An obtuse rule alone can pass, while every
acute candidate fails.</p>{signs}</details>
</section>
<section id="markings"><h2>Inspect the 32 encodings of one rule</h2>
<p>Changing a prototype frame conjugates its child placements. Renaming the two unit labels
and reversing a label's arrow directions consistently preserve matching. Each of the two
diagonal lengths has its own reserved channel.</p>
<div class="control"><label for="gauge">Choose an encoding</label><select id="gauge">{''.join(controls)}</select></div>
<div id="selected">{scheme(data["systems"][n])}</div>
{''.join(templates)}
<p>The independent audit rebuilt all 32 rules from the geometric catalogue and checked their
seams and boundary subdivisions. Applying the 32 recodings to the standard rule reaches each
encoding exactly once. <a href="https://research.tue.nl/en/publications/updown-generation-of-penrose-patterns/">De Bruijn's reference arrows in Figure 2</a></p>
</section>
<section id="plane"><h2>Replay the strictly nested seed</h2>
{growth(reference)}
<p>The audit checked the four common-edge refinement channels and recomputed the fourth
inflation, with 34 triangles and 13 complete paired rhombs. The highlighted child has the
same type as its parent and lies strictly inside it.</p>
<p>Aligning the child with the base triangle makes the inflated parent an expanding copy
containing that base in its interior. Iteration gives nested patches with disks of unbounded
radius. The audit transported the exact seed and patch to all 32 encodings. This is the
plane-covering argument for the recovered marked rule.</p>
</section>
<section id="wang"><h2>Read the automatically searched proof</h2>
<p>\(P_1\) and \(P_2\) name the two acute partitions. \(U\) means that there is just one unit
receptor type. The geometry audit supplies the exhaustive choice and its two exclusions.
Resolution search chooses the proof steps, and the fixed Wang checker replays them.</p>
{proof}
<p>Open a line to see the closing five verifier rows for its record. Colors show the edge
labels of the fixed-orientation Wang squares.</p>{windows}
</section></main>
<script>
const gauge = document.querySelector("#gauge")
const selected = document.querySelector("#selected")
function showGauge() {{
  const source = document.querySelector("#scheme-" + gauge.value)
  selected.replaceChildren(source.content.cloneNode(true))
}}
gauge.addEventListener("change", showGauge)
showGauge()
</script></body></html>"""
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
