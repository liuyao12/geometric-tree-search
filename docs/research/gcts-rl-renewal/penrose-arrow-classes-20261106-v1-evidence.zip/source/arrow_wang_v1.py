"""Search for and replay a refutation of a single unit-edge receptor."""
from argparse import ArgumentParser
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "source"), str(ROOT / "wang/external/source"), str(ROOT / "wang/source")]
from arrow_audit_v1 import geometric_profiles, shared_edge_partitions
from arrow_classes_v1 import read
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from resolution_v1 import Search, literals
from schematic_capsules_v1 import encoded, frozen
from study_v1 import Certificate


DATA = ROOT / "wang/data"
ATOMS = {1: ("P1",), 2: ("P2",), 3: ("U",)}


def clause(numbers):
    return tuple((i > 0, ATOMS[abs(i)]) for i in numbers)


def problem():
    acute, _ = shared_edge_partitions(0)
    witnesses = geometric_profiles((acute,))
    assert frozen(witnesses) == read("data/arrow-audit-v1.json")["profiles"]
    assert len(witnesses) == 2
    labels = ("all-shapes", "first-splits", "second-splits", "assume-one")
    initial = ((1, 2), (-1, -3), (-2, -3), (3,))
    sources = {k: dict(id=k, variables={}, clause=clause(v)) for k, v in zip(labels, initial, strict=True)}
    outcome = Search(initial, {"clauses": 100, "seconds": 10}, "MARKED")
    assert outcome.given() == "UNSAT"
    cert = Certificate(sources, {}, {name: [] for (name,) in ATOMS.values()}, ["U"], {})
    done = {}

    def emit(i):
        if i not in done:
            if i < outcome.premises:
                ref = cert.instance(labels[i], {})
            else:
                a, b, pivot = outcome.dependencies[i]
                ref = cert.resolve(emit(a), emit(b), ATOMS[pivot])
            assert set(cert.lines[ref]["clause"]) == set(clause(literals(outcome.clauses[i])))
            done[i] = ref
        return done[i]

    emit(outcome.index[(0, 0)])
    assert not cert.lines[-1]["clause"]
    return sources, frozen(cert.lines), dict(outcome.counts)


def prepare(proof, sources):
    wires, calls = {}, []
    for i, row in enumerate(proof):
        names, prefix, word = fragment(proof, i, sources, {})
        parsed = decoder.read(prefix, word + "!", require_empty=False)
        match(proof, i, sources, names, parsed, prefix)
        key = fingerprint(prefix, records(word))
        wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=i+1, uses=0, rule=row["rule"]))
        assert (wire["prefix"], wire["word"]) == (prefix, word)
        wire["uses"] += 1
        calls.append(key)
    return wires, calls


def main():
    if not __debug__:
        raise RuntimeError("Replay requires Python assertions")
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build", action="store_true")
    rebuild = parser.parse_args().build
    sources, expected, counts = problem()
    proof_path, bank_path = DATA / "arrow-proof-v1.json", DATA / "arrow-bank-v1.json.gz"
    receipt_path = DATA / "arrow-receipt-v1.json"
    proof = expected if rebuild else frozen(json.loads(proof_path.read_text()))
    assert proof == expected
    wires, calls = prepare(proof, sources)
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_path.read_bytes()))
    receipt = dict(records=len(calls), search=counts, **verify_bank(wires, bank))
    if rebuild:
        proof_path.write_bytes(encoded(proof) + b"\n")
        bank_path.write_bytes(gzip.compress(encoded(bank) + b"\n", compresslevel=6, mtime=0))
        receipt_path.write_bytes(encoded(receipt) + b"\n")
    else:
        assert json.loads(encoded(receipt)) == json.loads(receipt_path.read_text())
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
