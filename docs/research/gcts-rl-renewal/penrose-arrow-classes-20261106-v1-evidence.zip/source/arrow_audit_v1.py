"""Check exhaustive edge-to-edge geometry and the minimum number of unit arrow types."""
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from arrow_classes_v1 import GAUGES, change, change_pose, key, read, save
import check_v1 as exact
import discover_v1 as discovery
import model_v1 as ring
import standard_v1 as verify


def sorted_shape(cell):
    return tuple(sorted(verify.place(cell)))


def shared_edge_partitions(kind):
    """Grow via full common edges using the separate exact projection predicates."""
    axes = verify.axes(2)
    parent = tuple(verify.scaled(p, 1) for p in verify.PROTOS[kind])
    tags = [verify.area_tag([p]) for p in verify.PROTOS]
    assert any(tags[0][i]*tags[1][j] != tags[0][j]*tags[1][i] for i, j in combinations(range(4), 2))
    quota = ((1, 1), (1, 2))[kind]
    assert tuple(sum(n*t[i] for n, t in zip(quota, tags, strict=True)) for i in range(4)) == verify.area_tag([parent])
    choices = tuple((k, t, m, ring.ZERO) for k, t, m in product(range(2), range(10), (False, True)))
    moved = [(c, verify.place(c)) for c in choices]
    contained = {}
    by_edge = defaultdict(list)
    anchored = defaultdict(list)
    for (k, turn, mirror, _), poly in moved:
        for p in poly:
            anchored[k].append((turn, mirror, p))
        for a, b in verify.edges(poly):
            by_edge[exact.minus(b, a)].append((k, turn, mirror, a))
            by_edge[exact.minus(a, b)].append((k, turn, mirror, b))

    def legal(cell):
        if cell not in contained:
            polygon = verify.place(cell)
            contained[cell] = all(verify.contained(p, parent, axes) for p in polygon)
        return contained[cell]

    found, seen = set(), set()
    outcomes = defaultdict(set)
    stack = [((k, t, m, exact.minus(parent[0], p)),)
             for k in range(2) for t, m, p in anchored[k]]
    while stack:
        cells = stack.pop()
        polygons = tuple(verify.place(t) for t in cells)
        signature = tuple(sorted(tuple(sorted(p)) for p in polygons))
        if signature in seen or any(not legal(t) for t in cells):
            continue
        seen.add(signature)
        counts = Counter(t[0] for t in cells)
        if all(counts[k] == quota[k] for k in range(2)):
            found.add(signature)
            continue
        for old in polygons:
            for x, y in verify.edges(old):
                for k, t, m, a in by_edge[exact.minus(y, x)]:
                    if counts[k] >= quota[k]:
                        continue
                    cell = k, t, m, exact.minus(x, a)
                    if legal(cell) and all(verify.disjoint(verify.place(cell), p, axes) for p in polygons):
                        stack.append((*cells, cell))
    # Reconstruct all decorated poses of each admitted geometry from scratch.
    for partition in found:
        for shape in partition:
            first = min(shape)
            for k in range(2):
                for t, m, p in anchored[k]:
                    cell = k, t, m, exact.minus(first, p)
                    if sorted_shape(cell) == shape:
                        outcomes[shape].add(cell)
    return tuple(tuple(tuple(sorted(outcomes[s])) for s in p) for p in sorted(found)), len(seen)


def side_words(kind, parent, outer, marks, directions):
    """Normalize each marked side in the direction of its parent arrow."""
    words = []
    for i, (a, b) in enumerate(verify.edges(parent)):
        arrow = marks[kind][i]
        if arrow < 0:
            a, b = b, a
        axis, scale = directions[exact.minus(b, a)]
        word = tuple(sorted((ring.rotate(exact.minus(p, a), -axis), ring.rotate(exact.minus(q, a), -axis), h)
                            for side, (p, q, h) in outer if side == i))
        words.append(((scale-1, abs(arrow)), word))
    return words


def single_arrow(partitions):
    directions = verify.axes(2)
    results = []
    for kind, catalogue in enumerate(partitions):
        summary = []
        for i, part in enumerate(catalogue):
            counts = Counter()
            example = None
            for cells in product(*part):
                for a, b, c, d in product((-1, 1), repeat=4):
                    marks = ((a, 3, b), (c, 3, d))
                    counts["tried"] += 1
                    try:
                        parent, _, outer, _ = verify.verify_patch(kind, 1, cells, marks, directions)
                    except AssertionError:
                        counts["seam"] += 1
                        continue
                    channels = {}
                    split = side_words(kind, parent, outer, marks, directions)
                    for j, (channel, word) in enumerate(split):
                        prior, before = channels.setdefault(channel, (j, word))
                        if before != word:
                            counts["receptor"] += 1
                            if example is None:
                                example = dict(cells=cells, marks=marks, sides=(prior, j), words=(before, word))
                            break
                    else:
                        counts["admitted"] += 1
            assert counts["tried"] == sum(counts[k] for k in ("seam", "receptor", "admitted"))
            summary.append(dict(index=i, counts=dict(counts), example=example))
        results.append(summary)
    assert len(results[0]) == 2 and all(not r["counts"].get("admitted") for r in results[0])
    return results


def geometric_profiles(partitions):
    """Compare boundary subdivisions even before assigning arrow directions."""
    parent = tuple(verify.scaled(p, 1) for p in verify.PROTOS[0])
    axes = verify.axes(2)
    output = []
    for part in partitions[0]:
        cells = tuple(aliases[0] for aliases in part)
        boundary = Counter(tuple(sorted(e)) for cell in cells for e in verify.edges(verify.place(cell)))
        profiles = []
        for side in (0, 2):
            a, b = tuple(verify.edges(parent))[side]
            forward = exact.minus(b, a)
            pieces = {}
            for (p, q), count in boundary.items():
                if count != 1 or discovery.cross(a, b, p) != (0, 0) or discovery.cross(a, b, q) != (0, 0):
                    continue
                if discovery.dot_sign(forward, exact.minus(q, p)) < 0:
                    p, q = q, p
                assert p not in pieces
                pieces[p] = q
            point, route = a, [a]
            while point != b:
                point = pieces.pop(point)
                route.append(point)
            assert not pieces
            profiles.append(tuple(route))
        assert sorted(len(r)-1 for r in profiles) == [1, 2]
        lengths = [tuple(sorted(axes[exact.minus(q, p)][1] for p, q in zip(r, r[1:])))
                   for r in profiles]
        assert sorted(lengths) == [(-1, 0), (1,)]
        output.append(dict(cells=cells, sides=(0, 2), routes=profiles))
    return output


def independent_systems(partitions):
    directions = verify.axes(2)
    admitted = []
    for a, b, c, d in product((-2, -1, 1, 2), repeat=4):
        if {abs(x) for x in (a, b, c, d)} != {1, 2}:
            continue
        marks = ((a, 3, b), (c, 3, d))
        by_kind = []
        for kind, catalogue in enumerate(partitions):
            compatible = []
            for part in catalogue:
                for cells in product(*part):
                    try:
                        parent, _, outer, _ = verify.verify_patch(kind, 1, cells, marks, directions)
                        words = verify.boundary_maps(kind, parent, outer, marks, directions)
                    except AssertionError:
                        continue
                    compatible.append((cells, words))
            by_kind.append(compatible)
        for (first, a_words), (second, b_words) in product(*by_kind):
            if all(a_words[k] == b_words[k] for k in a_words.keys() & b_words.keys()):
                admitted.append(key(marks, (first, second)))
    return tuple(sorted(admitted))


def verify_standard(study):
    reference = read("reference/standard-proof-v1.json")
    figure = read("reference/standard-figure-v1.json")
    assert reference["marks"] == figure["signed_edge_arrows"]
    standard = key(reference["marks"], reference["rules"])
    systems = [key(row["marks"], row["rules"]) for row in study["systems"]]
    index = systems.index(standard)
    moves = {change(standard, g): g for g in GAUGES}
    assert len(moves) == len(GAUGES) and set(moves) == set(systems)
    marks, rules = standard
    nest = reference["nest"]
    k, depth, seed = (nest[f] for f in ("kind", "depth", "seed"))
    def expand(steps):
        cells = [(k, 0, False, ring.ZERO)]
        for _ in range(depth):
            cells = [discovery.compose(a, b) for a in cells for b in steps[a[0]]]
        return cells

    cells = expand(rules)
    assert sorted(cells) == sorted(nest["triangles"]) and seed in cells and seed[0] == k
    directions = verify.axes(depth+1)
    parent, _, _, rhombs = verify.verify_patch(k, depth, cells, marks, directions)
    assert parent == nest["parent"]
    assert all(verify.contained(p, parent, directions, strict=True) for p in verify.place(seed))
    for system in systems:
        flips = moves[system][:2]
        other_marks, other_rules = system
        patch = expand(other_rules)
        assert sorted(patch) == sorted(change_pose(k, c, flips) for c in cells)
        moved_seed = change_pose(k, seed, flips)
        assert moved_seed in patch
        _, _, _, pairs = verify.verify_patch(k, depth, patch, other_marks, directions)
        assert len(pairs) == len(rhombs)
        assert all(verify.contained(p, parent, directions, strict=True) for p in verify.place(moved_seed))
    return dict(index=index, gauge_from_standard=[moves[s] for s in systems],
                nested=dict(kind=k, depth=depth, triangles=len(cells), rhombs=len(rhombs), seed=seed,
                            transported=len(systems)))


def main():
    if not __debug__:
        raise RuntimeError("Audit requires Python assertions")
    study = read("data/arrow-study-v1.json")
    reference = []
    checked = []
    for kind in range(2):
        actual, visited = shared_edge_partitions(kind)
        expected = study["partitions"][kind]
        def entries(catalogue):
            return {tuple(sorted(tuple(sorted(alias)) for alias in part)) for part in catalogue}
        assert entries(actual) <= entries(expected)
        # Any shape in the original list missing from a full-edge search must have a split interior edge.
        parent = tuple(verify.scaled(p, 1) for p in verify.PROTOS[kind])
        for part in expected:
            if tuple(sorted(tuple(sorted(a)) for a in part)) in entries(actual):
                continue
            cells = [alias[0] for alias in part]
            edges = Counter(tuple(sorted(e)) for t in cells for e in verify.edges(verify.place(t)))
            assert any(n == 1 and not any(discovery.cross(a,b,p)==discovery.cross(a,b,q)==(0,0)
                                           for a,b in verify.edges(parent))
                       for (p,q), n in edges.items())
        reference.append(actual)
        checked.append(dict(kind=kind, partitions=len(actual), visited=visited))
    proof = single_arrow(reference)
    profiles = geometric_profiles(reference)
    systems = independent_systems(reference)
    assert systems == tuple(key(row["marks"], row["rules"]) for row in study["systems"])
    standard = verify_standard(study)
    save("data/arrow-audit-v1.json", dict(geometry=checked, one_magnitude=proof, standard=standard,
                                           catalogues=reference, profiles=profiles,
                                           checked_systems=len(systems)))
    print(checked, [[r["counts"] for r in side] for side in proof], standard["nested"], flush=True)


if __name__ == "__main__":
    main()
