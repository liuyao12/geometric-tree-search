What the Penrose arrows have to distinguish

From the archive root, run these commands with Python 3.12.

    python3 -I -S -B source/arrow_classes_v1.py
    python3 -I -S -B source/arrow_audit_v1.py
    python3 -I -S -B source/arrow_wang_v1.py --build
    python3 -I -S -B source/arrow_wang_v1.py
    python3 -I -S -B publication/render_v1.py

The first command reconstructs the candidate rules from unmarked triangle
geometry. The next one checks the exact partitions, the minimum marking
argument, the standard arrow comparison and the transported nested seed.
The final commands search for and replay the Wang proof and render the HTML.
