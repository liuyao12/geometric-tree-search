"""Replay one of the frozen envelope experiments in a new directory."""

import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PHASES = {
    "envelope": ("protocol-v1.json", "envelope_experiment_v1.py", True),
    "seams": ("seam-protocol-v1.json", "seam_experiment_v1.py", True),
    "clusters": ("cluster-protocol-v1.json", "cluster_reader_v1.py", False),
}


def main():
    phase, destination, *dependencies = sys.argv[1:]
    config, script, sat = PHASES[phase]
    assert len(dependencies) == sat
    target = Path(destination).resolve() / phase
    target.mkdir(parents=True)
    (target / "data").mkdir()
    pins = json.loads((ROOT / config).read_bytes())["pins"]
    for name in (config, *pins):
        rel = Path(name)
        assert not rel.is_absolute() and ".." not in rel.parts
        (target / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / rel, target / rel)
    subprocess.run([sys.executable, "-I", "-S", "-B", str(target / "source" / script),
                    *[str(Path(d).resolve()) for d in dependencies]], cwd=target, check=True)


if __name__ == "__main__":
    main()
