"""Render exact witnesses, conditional marks, and paired measurements."""

import cmath
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "source"))
from penrose_lazy_experiment_v1 import exact
from penrose_polygon_v1 import thin, tile_polygon

STEM = "penrose-envelope-marks-20261106-v1"
ZETA = cmath.exp(2j * cmath.pi / 5)


def read(name):
    return json.loads((ROOT / "data" / (name + "-v1.json")).read_bytes())


def table(headers, rows):
    head = "".join(f"<th scope='col'>{escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{escape(str(cell))}</td>" for cell in row) + "</tr>" for row in rows)
    return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


def picture(label, tiles, ports, *, hulls=(), targets=(), seeds=(), option=None, reference=()):
    points = {p for t in (*tiles, *reference) for p in t} | {p for e in (*ports, *hulls) for p in e} | set(targets)
    plane = {p: sum(v*ZETA**k for k,v in enumerate(p)).conjugate() for p in points}
    x0, x1 = min(z.real for z in plane.values()), max(z.real for z in plane.values())
    y0, y1 = min(z.imag for z in plane.values()), max(z.imag for z in plane.values())
    zoom = min(566/(x1-x0), 328/(y1-y0))
    screen = {p:(306+zoom*(z.real-(x0+x1)/2),185+zoom*(z.imag-(y0+y1)/2)) for p,z in plane.items()}

    def coords(vertices):
        return " ".join(f"{x:.2f},{y:.2f}" for x,y in (screen[p] for p in vertices))

    blocks = []
    for tile in tiles:
        style = "thin" if thin(tile) else "thick"
        if tile in seeds:
            style = ("seed-a", "seed-b")[seeds.index(tile)] if len(seeds) == 2 else "seed-a"
        blocks.append(f'<polygon class="tile {style}" points="{coords(tile_polygon(tile))}"></polygon>')
    if option:
        blocks.append(f'<polygon class="option" points="{coords(tile_polygon(option))}"></polygon>')
    for poly in hulls:
        blocks.append(f'<polygon class="seam" points="{coords(poly)}"></polygon>')
    for a,b in ports:
        (x,y),(xx,yy) = screen[a],screen[b]
        arrow = complex(xx-x,yy-y)
        head = complex(xx,yy)
        depth = min(16, abs(arrow)/3)
        tail = head-depth*arrow/abs(arrow)
        left,right=tail+.38j*depth*arrow/abs(arrow),tail-.38j*depth*arrow/abs(arrow)
        blocks.append(f'<line class="port" x1="{x:.2f}" x2="{xx:.2f}" y1="{y:.2f}" y2="{yy:.2f}"></line>'
                      f'<polygon class="head" points="{xx:.2f},{yy:.2f} {left.real:.2f},{left.imag:.2f} {right.real:.2f},{right.imag:.2f}"></polygon>')
    for p in targets:
        x,y=screen[p]
        blocks.append(f'<circle class="target" cx="{x:.2f}" cy="{y:.2f}" r="2.4"></circle>')
    return f'<svg viewBox="0 0 612 370" role="img" aria-label="{escape(label)}"><title>{escape(label)}</title>{"".join(blocks)}</svg>'


def main():
    envelopes, seams, clusters = [read(name) for name in ("envelope", "seam", "cluster")]
    donor = envelopes["source"][0]
    pair, port, blockers = (exact(donor[k]) for k in ("seeds", "port", "blockers"))
    assert len(blockers) == 4
    diagrams = []
    for i, (tile, excluded) in enumerate(blockers, 1):
        by = " and ".join("AB"[j] for j in excluded)
        label = f"Option {i} conflicts with seed {by}"
        diagrams.append(f"<figure>{picture(label, pair, (port,), seeds=pair, option=tile, reference=tuple(t for t,_ in blockers))}"
                        f"<figcaption>{escape(label)}.</figcaption></figure>")
    data = []
    for case in envelopes["cases"] + seams["cases"]:
        name = case.get("id", f"Seam {case.get('side')}")
        for arm in case["results"]:
            data.append(dict(case=name, mode=arm["arm"], candidates=len(case["tiles"]), transferred=len(arm["warm"]),
                             result=arm["status"], decisions=arm["counts"].get("decisions",0), models=arm["counts"].get("models",0),
                             fresh_contacts=len(arm["geometry"]), seconds=arm["seconds"]))
    assert len(data) == 70 and all(r["result"] in ("POSITIVE","NEGATIVE") for r in data)
    stats = [[case["case"],case["clusters"],case["targets"],case["forced"],case["tiles"],
              f'{1000*case["proposal_seconds"]:.1f}', f'{1000*case["checked_seconds"]:.1f}'] for case in clusters["cases"]]
    biggest = clusters["cases"][-1]
    witness, ports, footprint, vertices = (exact(biggest[k]) for k in ("witness", "ports", "footprint", "vertices"))
    patch = picture("Checked 432-rhomb patch assembled from 144 hexagons", witness, ports,
                    hulls=footprint, targets=vertices)
    summary=dict(status="CHECKED_DIRECTED_EDGE_MARKS", donor_port_trials=envelopes["donor_trials"],
                 comparisons=data, cluster_runs=[{k:case[k] for k in ("case","clusters","targets","forced","tiles","proposal_seconds",
                               "checked_seconds","candidates")} for case in clusters["cases"]])
    (ROOT / "report" / (STEM + "-results.json")).write_text(json.dumps(summary, indent=2,sort_keys=True)+"\n")
    runs=table(("Case","Arm","Outcome","Candidates","Marks","Decisions","Models","Fresh contacts"),
               [[r[k] for k in ("case","mode","result","candidates","transferred","decisions","models","fresh_contacts")] for r in data])
    page=rf"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Directed Penrose marks and movable boundaries</title>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>
body{{margin:0;background:#f7f6f0;color:#20372f;font:1rem/1.55 system-ui,sans-serif}}
main{{max-width:1050px;margin:auto;padding:1rem clamp(1rem,4vw,2.75rem) 3rem}}
header{{padding:1.5rem 0}}h1{{font-size:clamp(2rem,5vw,3.2rem);line-height:1.12;margin:.5rem 0}}
h2{{font-size:1.65rem}}h3{{font-size:1.25rem}}a{{color:#23634d}}section{{margin-bottom:2rem}}
nav{{display:flex;flex-wrap:wrap;gap:.65rem 1.2rem}}.eyebrow{{letter-spacing:.08em;text-transform:uppercase;font-weight:700;font-size:.81rem}}
.gallery{{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,225px),1fr));gap:.8rem}}
figure{{margin:0}}figcaption{{font-size:.92rem;color:#36584b}}svg{{width:100%;display:block;background:#fafdfb;border:1px solid #c0d5c9;border-radius:.6rem}}
.tile{{stroke:#394e47;stroke-width:.65}}.thin{{fill:#acd0b6}}.thick{{fill:#a4b4d6}}
.seed-a{{fill:#e3a16e}}.seed-b{{fill:#b9a3d1}}.option{{fill:#79bcaa;fill-opacity:.45;stroke:#17654d;stroke-width:2.25;stroke-dasharray:6 4}}
.seam{{fill:none;stroke:#233a33;stroke-width:1}}.port{{stroke:#0b6452;stroke-width:3}}.head{{fill:#0b6452}}
.target{{fill:#1d3029;stroke:#f5fbf7;stroke-width:.55}}.scroll{{overflow:auto}}
table{{width:100%;border-collapse:collapse}}td,th{{padding:.45rem .6rem;border-bottom:1px solid #c9d7cc;text-align:left}}
th{{background:#e7efe7}}summary{{cursor:pointer;color:#23634d;font-weight:650}}
</style></head><body><main>
<header><p class="eyebrow">GCTS research notebook · November 2026</p><h1>Directed Penrose marks and movable boundaries</h1>
<p>One required edge explains why two otherwise compatible rhombs cannot coexist. The mark transfers to several new envelopes, including patches with shared seams.</p>
<nav aria-label="On this page"><a href="#receptor">Directed edge</a><a href="#comparison">Search results</a><a href="#clusters">Cluster recipes</a><a href="#evidence">Evidence</a></nav></header>
<section id="receptor"><h2>Reduce a fixed-boundary failure to one directed edge</h2>
<p>The earlier fixed hexagon gave two individually extendible seeds. This experiment tries each of its six oriented sides as the sole required edge. Two sides alone reproduce the contradiction. They yield the same template after rotation and translation.</p>
<div class="gallery">{''.join(diagrams)}</div>
<p>Seed A is orange and seed B is lavender. The arrow is the required unit edge. The dashed green rhomb in each diagram is one legal way to cover it from the left. Each option conflicts with at least one seed.</p>
<p>For the oriented edge \(e\), let \(D(e)\) be its four possible rhombs. At least one must be present, and each member of \(D(e)\) has an independently checked incompatible contact with \(A\) or \(B\). Assuming both seeds leaves an empty domain. Unit propagation certifies \(\neg(A\land B)\) under the edge requirement.</p>
<p>On a new request the checker rebuilds the exact local domain in \(\mathbb Z[\zeta_5]\), filters it to placements within the envelope, and replays the transported cut. The outside boundary of the selected patch is free inside the envelope. Full-sector targets and directed edge requirements stay fixed. Removing the edge or requiring the opposite side gives checked positive controls with both seeds.</p>
</section>
<section id="comparison"><h2>Compare the same searches with and without the mark</h2>
<p>Ten envelope tests and four connected seam tests use the same geometry checker and candidate sets across arms. Plain uses the initial GCTS order. Marked adds the transferred cuts. Learned adds the frozen policy trained on the earlier vertex-target cases. The two Glucose arms isolate the effect of giving the same cuts to a conventional solver.</p>
<p>The three negative envelope cases go from 3, 1 and 5 decisions to zero in GCTS. Marked Glucose also closes all three before branching. On the seven positive envelope cases and four positive seam cases the initial GCTS order uses the same decision counts with and without the mark. The learned order uses more decisions on all four seam cases. On the largest, it uses 512 decisions and 300 fresh cuts, compared with 206 decisions and zero fresh cuts for the initial order.</p>
<details><summary>Show all 70 search runs</summary>{runs}</details>
</section>
<section id="clusters"><h2>Attach alternative fillings to the same hexagon</h2>
<figure>{patch}<figcaption>A checked patch of 432 rhombs inside 144 supplied hexagon footprints. Dark outlines are cluster seams and dots are requested full vertices.</figcaption></figure>
<p>Each footprint accepts either of two checked three-rhomb fillings. The requested vertex sectors and seed placements select allowed fillings. The recipes agree along every full hexagon edge, so choices that survive the local checks assemble along the seams. An independent global check tests every emitted witness for pairwise contact, containment and coverage of the requested receptors.</p>
{table(("Case","Hexagons","Targets","Forced recipes","Rhombs","Proposal ms","Including check ms"),stats)}
<p>In the largest case, 52 of the 144 hexagons have a forced recipe. The other 92 accept either recipe. These timings use supplied footprints and measure recipe selection within that family.</p>
</section>
<section id="evidence"><h2>Evidence</h2>
<p><a href="{STEM}-results.json">Machine-readable results</a> · <a href="{STEM}-evidence.zip">Reproduction archive</a> · <a href="{STEM}-manifest.json">File hashes</a></p>
</section></main></body></html>"""
    (ROOT / "report" / (STEM + ".html")).write_text(page)


if __name__ == "__main__":
    main()
