const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function check() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1250, height: 930 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const file = path.join(__dirname, "../report/penrose-envelope-marks-20261106-v1.html");
    const result = await page.goto(process.argv[2] || pathToFileURL(file).href);
    if (process.argv[2]) assert.equal(result.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length === 7);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("#receptor .option").count(), 4);
    assert.equal(await page.locator("#clusters .tile").count(), 432);
    assert.equal(await page.locator("#clusters .seam").count(), 144);
    assert.equal(await page.locator("#clusters .target").count(), 129);
    await page.locator("#comparison summary").click();
    assert.equal(await page.locator("#comparison tbody tr:visible").count(), 70);
    assert.deepEqual(errors, []);
    if (!process.argv[2]) {
      await page.locator("#receptor .gallery").screenshot({ path: path.join(__dirname, "receptors-v1.png") });
      await page.locator("#clusters figure").screenshot({ path: path.join(__dirname, "clusters-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    const receipt = { status: "CHECKED_READER", optionDiagrams: 4, patchTiles: 432, seamsDrawn: 144,
      targetsDrawn: 129, searchRows: 70, formulas: 7, mobileNoOverflow: true };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}

check().catch(error => { console.error(error); process.exitCode = 1; });
