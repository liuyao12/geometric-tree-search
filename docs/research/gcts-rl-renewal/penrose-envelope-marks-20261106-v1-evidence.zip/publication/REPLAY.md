# Reproduce the directed-edge and cluster tests

The archive contains the frozen protocols, exact rhomb coordinates, SAT clauses,
conditional cut receipts, search traces and checked witnesses.

Extract it and run the replay driver with the pinned Python interpreter.
Use a fresh output directory. The envelope and seam tests also require the
pinned PySAT installation. These experiments used CPython 3.12 and PySAT
1.9.dev21 on Apple Silicon.

    "$GCTS_PYTHON" -I -S -B publication/replay_v1.py envelope "$GCTS_OUTPUT" "$GCTS_PYSAT"
    "$GCTS_PYTHON" -I -S -B publication/replay_v1.py seams "$GCTS_OUTPUT" "$GCTS_PYSAT"
    "$GCTS_PYTHON" -I -S -B publication/replay_v1.py clusters "$GCTS_OUTPUT"

Compare the outcomes, certificates and decision counts. The replay receipt
records matching hashes after excluding timing fields.
