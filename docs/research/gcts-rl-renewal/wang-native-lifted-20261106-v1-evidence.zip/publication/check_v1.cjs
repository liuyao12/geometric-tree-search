const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 920 } });
    const errors = [];
    page.on("pageerror", e => errors.push(e.message));
    const local = pathToFileURL(path.join(__dirname, "../report/wang-native-lifted-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local);
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelectorAll("mjx-container").length >= 180);
    assert.equal(await page.locator("mjx-merror").count(), 0);
    assert.equal(await page.locator("section.proof").count(), 8);
    assert.equal(await page.locator("section.proof > .table tbody tr").count(), 87);
    assert.equal(await page.locator(".wang-cell").count(), 450);
    assert.equal(await page.locator(".fragment .wang-cell").count(), 90);
    assert.equal(await page.locator(".move-table tbody tr").count(), 54);
    assert.equal(await page.locator(".move-table .reuse").count(), 27);
    const details = page.locator(".fragment details").first();
    await details.locator("summary").click();
    await details.locator("code").waitFor();
    assert.match(await details.locator("code").textContent(), /^>C0:/);
    const geometry = page.locator("#hilbert-incidence-uniqueness");
    assert.equal(await geometry.locator(".wang-cell:visible").count(), 45);
    await geometry.locator(":scope > .table td details summary").first().click();
    await geometry.locator(":scope > .table td details code").first().waitFor();
    if (!process.argv[2]) {
      await page.locator("#fragments .dual").screenshot({ path: path.join(__dirname, "fragments-v1.png") });
      await geometry.locator("figure").screenshot({ path: path.join(__dirname, "wang-v1.png") });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt = { status: "CHECKED_NATIVE_LIFTED_WANG_READER", proofs: 8, groundLines: 87,
      localWindows: 2, incidenceAdmissions: 54, wangCells: 450, mobileNoOverflow: true,
      math: await page.locator("mjx-container").count() };
    fs.writeFileSync(path.join(__dirname, process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt, null, 2) + "\n");
  } finally {
    await browser.close();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
