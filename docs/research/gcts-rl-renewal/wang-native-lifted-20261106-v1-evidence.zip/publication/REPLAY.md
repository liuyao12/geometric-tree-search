# Replay lifted moves with the fixed Wang palette

Use Python 3.12 and its standard library. In an extracted copy, preserve
the supplied results and run these commands from the archive root.

    mv data archived-data
    mkdir data
    python3.12 -I -S -B source/lifted_cases_v1.py
    python3.12 -I -S -B source/native_experiment_v1.py
    python3.12 -I -S -B source/native_marked_v1.py
    python3.12 -I -S -B source/native_frames_v1.py
    python3.12 -I -S -B source/native_audit_v1.py
    python3.12 -I -S -B publication/render_v1.py

The native experiment fixes the symbolic proposals while comparing
immediate checks, on-activation checks, name-sensitive replay,
shape-based replay, and donor-seeded replay. The ranker trains on separate
episodes. The marked experiment replays failure attempts, then checks
their transfer jointly with native admission and positive fragment reuse.

The audit reconstructs the input theory, decodes every scope map, checks
cache use and admission order, and verifies that the proof used in each
complete rectangle follows its admitted clause dependencies. It can also
run directly on the included data without repeating search.

Use `publication/replay-v1.json` to compare deterministic outputs.
For the browser check, set `GCTS_CHROME` and `GCTS_PLAYWRIGHT` for custom
installations and run `node publication/check_v1.cjs`.
