"""Package the native lifted Wang proof search and its public reproducibility evidence."""
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
STEM = "wang-native-lifted-20261106-v1"


def pin(data):
    return dict(bytes=len(data), sha256=sha256(data).hexdigest())


def load(path):
    return json.loads((ROOT/path).read_text())


def json_file(path, value):
    (ROOT/path).write_text(json.dumps(value, sort_keys=True, indent=2)+"\n")


def main():
    report = ROOT/"report"
    summary = report/f"{STEM}-results.json"
    study = load("data/search-v1.json")
    replay = load("publication/replay-v1.json")
    for path, expected in replay["outputs"].items():
        assert pin((ROOT/path).read_bytes()) == expected
    json_file(summary, dict(**study, audit=load("data/audit-v1.json"),
                            frames=load("data/frames-v1.json"), combined=load("data/combined-v1.json"),
                            inputs=load("input/cohort-v1.json"),
                            replay=replay, reader=load("publication/browser-v1.json")))
    html = report/f"{STEM}.html"
    paths = [html, summary]
    paths.extend(sorted((ROOT/"source").glob("*.py")))
    paths.extend(sorted((ROOT/"input").glob("*.json")))
    paths.extend(sorted((ROOT/"data").glob("*-v1.json*")))
    paths.extend(sorted((ROOT/"data").glob("*.log")))
    paths.extend(ROOT/"publication"/p for p in ("REPLAY.md", "replay-v1.json", "browser-v1.json",
                                               "render_v1.py", "notebook-v1.html", "check_v1.cjs",
                                               "proof_views_v1.py", "package_v1.py"))
    archive = report/f"{STEM}-evidence.zip"
    pins = {}
    with ZipFile(archive, "w") as bundle:
        for path in paths:
            name, raw = str(path.relative_to(ROOT)), path.read_bytes()
            if path.suffix != ".gz":
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)", raw), name
            assert name not in pins
            pins[name] = pin(raw)
            item = ZipInfo(name, (2026, 11, 6, 0, 0, 0))
            item.external_attr = 0o100644 << 16
            bundle.writestr(item, raw, compress_type=ZIP_DEFLATED, compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p: pin(bundle.read(p)) for p in bundle.namelist()} == pins
    assets = {p.name: pin(p.read_bytes()) for p in (html, summary, archive)}
    json_file(report/f"{STEM}-manifest.json", dict(schema="GCTS-NATIVE-LIFTED-WANG-MANIFEST-v1",
                                                 assets=assets, archive_entries=pins))
    print(json.dumps(dict(assets=assets, entries=len(pins)), indent=2))


if __name__ == "__main__":
    main()
