"""Render scoped native move evidence and complete checked Wang proofs."""
from html import escape
from pathlib import Path
import gzip
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"publication"))
from proof_views_v1 import clause, expression, math, proof_section, symbol, window_svg
from boundary_kernel_v1 import build

STEM="wang-native-lifted-20261106-v1"
NAMES={
    "factoring-to-universal":"A universal conclusion by factoring",
    "proof-by-cases":"Proof by cases",
    "iterate-depth-8":"An existential conclusion at term depth eight",
    "exists-map":"Existential image under implication",
    "incidence-existence":"Existence of an incident point and line",
    "hilbert-incidence-uniqueness":"Hilbert incidence uniqueness",
    "tptp-tutorial-family":"TPTP family exercise",
    "receiver-alias":"Repeated-variable receiver",
    "occurs-check-control":"Cyclic binding control",
    "quantifier-swap-control":"Quantifier swap control",
}


def read(path):
    return json.loads((ROOT/path).read_text())


def compressed(path):
    with gzip.open(ROOT/path,"rt") as stream:
        return json.load(stream)


def cells(title,*columns):
    content="".join(f'<td class="counts">{x:,}</td>' for x in columns)
    return f'<tr><th scope="row">{escape(title)}</th>{content}</tr>'


def local_view(machine,trace):
    data=dict(prefix=trace["prefix"],word=trace["word"],padding=0,trace=trace["parents"]+trace["fragment"])
    svg,label=window_svg(machine,data,(trace["steps"]-5,trace["head"]))
    return f'<figure>{svg}<figcaption>{label}</figcaption></figure>'


def raw_block(trace):
    records=trace["word"][:-1].split(";")
    content=trace["prefix"]+"\n"+"\n".join(record+";" for record in records)
    return f'<details><summary>Show exact tape text</summary><code>{escape(content)}</code></details>'


def witness_views(machine,study,cases,combined,traces,negative):
    receiver=cases["receiver-alias"]
    origins={e["fragment"]:(donor["id"],e) for donor in study["donors"] for e in donor["events"]}
    selected=next(e for e in receiver["arms"]["warm"]["events"] if e["reuse"] and e["fragment"] in origins)
    donor_name,prior=origins[selected["fragment"]]
    original=dict((code,key) for key,code in prior["symbols"])
    new=dict((code,key) for key,code in selected["symbols"])
    assert original.keys()==new.keys()
    changes=[f'<li><code>{escape(c)}</code> {math(symbol(original[c][1]))} becomes {math(symbol(new[c][1]))}</li>'
             for c in original if original[c][1]!=new[c][1]][:4]
    trace=traces[selected["fragment"]]
    success=f'''<article class="fragment">
<h3>A checked fragment used again</h3>
<p>Donor <code>{escape(donor_name)}</code> derives {math(clause(prior["node"]["clause"]))}. The receiver uses the same tape text to derive {math(clause(selected["node"]["clause"]))}.</p>
<ul>{"".join(changes)}</ul>
{local_view(machine,trace)}{raw_block(trace)}
</article>'''
    mark=next(d for d in combined["donors"] if d["mark"][0]=="alias")
    failure=negative[mark["fragment"]]
    assert failure["stop"]==1
    rejected=f'''<article class="fragment">
<h3>A rejected binding attempt</h3>
<p>The first atom is {math(expression(mark["left"]))}. The negative literal uses {math(expression(mark["right"]))}. A repeated variable faces two distinct terms. The two instantiations complete before the proposed resolution rejects.</p>
{local_view(machine,failure)}{raw_block(failure)}
</article>'''
    return success+rejected


def parameter_view(row):
    event=next(e for e in row["arms"]["warm"]["events"] if e["node"]["types"] and
               any(k[0]=="parameter" and k[1] in e["node"]["types"] for k,_ in e["symbols"]))
    node=event["node"]
    fields=[f'{math(symbol(k[1]))} uses tape code <code>{escape(v)}</code> of sort {math(symbol(k[2]))}'
            for k,v in event["symbols"] if k[0]=="parameter" and k[1] in node["types"]]
    return f'<p>One open clause admitted in the incidence proof search is {math(clause(node["clause"]))}. '+           ". ".join(fields)+".</p>"


def geometry_view(row):
    lines=[]
    for event in row["arms"]["warm"]["events"]:
        reuse=event["reuse"]
        badge='<span class="badge reuse">Reused</span>' if reuse else '<span class="badge fresh">Fresh check</span>'
        lines.append(f'<tr><th scope="row">{event["index"]+1}</th>'
                     f'<td>{math(clause(event["node"]["clause"]))}</td><td>{badge}</td>'
                     f'<td><code>{event["fragment"][:12]}</code></td></tr>')
    return f'''<p>Numbers follow the search’s clause store. A gap denotes a normalized source or a candidate that never became active.</p>
<div class="table move-table"><table><thead><tr><th>Clause</th><th>Admitted formula</th><th>Disposition</th><th>Fragment</th></tr></thead><tbody>{"".join(lines)}</tbody></table></div>'''


def main():
    study=read("data/search-v1.json")
    combined=read("data/combined-v1.json")
    frames=read("data/frames-v1.json")
    audit=read("data/audit-v1.json")
    machine=build().compile()
    assert machine.digest()==study["machine_sha256"]==frames["machine_sha256"]
    cases={row["id"]:row for row in study["cases"]}
    specs={row["id"]:row for row in read("input/cohort-v1.json")["holdout"]}
    indexed={r["id"]:r for r in frames["frames"]}
    results,checks,proofs,links=[],[],[],[]
    for row in study["cases"]:
        name=row["id"]
        order=row["arms"]
        values=[order[arm]["tape"].get("runs",0)
                for arm in ("eager","demand","exact","shape","warm","ranked")]
        results.append(cells(NAMES[name],order["direct"]["counts"].get("offers",0),*values))
        proof=row.get("proof")
        if proof is not None:
            file={**proof,**indexed[name],"attachments":[]}
            proofs.append(proof_section(specs[name],file,machine,NAMES[name],name))
            links.append(f'<a href="#{name}">{escape(NAMES[name])}</a>')
    for row in combined["cases"]:
        name=row["id"]
        controls=cases[name]["arms"]["warm"]["counts"]
        checks.append(cells(NAMES[name],controls.get("unifications",0),row["counts"].get("unifications",0),
                            row["tape"].get("admissions",0),row["tape"].get("runs",0)))
    geo=cases["hilbert-incidence-uniqueness"]
    geom=geo["arms"]
    traces=compressed("data/native-fragments-v1.json.gz")
    neg=compressed("data/negative-fragments-v1.json.gz")
    exhibits=witness_views(machine,study,cases,combined,traces,neg)
    template=(ROOT/"publication/notebook-v1.html").read_text()
    note="A contradiction is checked before it can end the search."
    assert note in template
    anchor='</section>\n<section id="fragments">'
    template=template.replace(anchor,parameter_view(geo)+"\n"+anchor,1)
    replacements=dict(STEM=STEM,WITNESSES=exhibits,COMBINED="".join(checks),
        TABLE="".join(results),EAGER=f'{geom["eager"]["tape"]["implied_steps"]:,}',
        SHAPE=f'{geom["shape"]["tape"]["implied_steps"]:,}',GEOMETRY=geometry_view(geo),
        LINKS="".join(links),PROOFS="\n".join(proofs),FRAMES=str(len(indexed)),
        GROUND=str(audit["ground"]),LOCAL=str(audit["local_fragments"]+audit["donor_mark_fragments"]),
        DONORS=str(len(study["donors"])),TRAIN=str(len(study["episodes"])))
    for key,value in replacements.items():
        template=template.replace("%%"+key+"%%",value)
    assert "%%" not in template
    (ROOT/"report"/f"{STEM}.html").write_text(template)


if __name__=="__main__":
    main()
