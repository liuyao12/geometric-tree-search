"""Fair given-clause resolution with typed unification and checkable proof provenance."""
from collections import Counter, defaultdict, deque
from heapq import heappop, heappush
from itertools import combinations
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
import front_v1 as front
import herbrand_v1 as fol
from lifted_marks_v1 import applies, discover, rigid


def subst(term,environment):
    if isinstance(term,str):
        return environment.get(term,term)
    return (term[0],*(subst(a,environment) for a in term[1:]))


def size(term):
    return 1 if isinstance(term,str) else 1+sum(map(size,term[1:]))


def names(term):
    if isinstance(term,str):
        return set()
    return {term[0]}.union(*(names(t) for t in term[1:]))


def unifier(a,b,types,functions,stats):
    environment={}
    pending=[(a,b)]
    while pending:
        x,y=pending.pop()
        x,y=subst(x,environment),subst(y,environment)
        stats["equations"]+=1
        if x==y:
            continue
        if not isinstance(x,str) and isinstance(y,str):
            x,y=y,x
        if isinstance(x,str):
            if fol.inspect_term(y,types,functions)!=types[x]:
                return None
            if occurs(x,y):
                return None
            for v,t in environment.items():
                environment[v]=subst(t,{x:y})
            environment[x]=y
        elif rigid(x,y):
            return None
        else:
            pending.extend(reversed(tuple(zip(x[1:],y[1:],strict=True))))
    return environment


def occurs(variable,term):
    return variable==term if isinstance(term,str) else any(occurs(variable,t) for t in term[1:])


def normalize(row,types):
    """Stable first occurrence numbering within a shape-sorted clause."""
    env={}
    def pattern(term):
        return ("?",types[term]) if isinstance(term,str) else (term[0],*map(pattern,term[1:]))
    def rename(term):
        if isinstance(term,str):
            return env.setdefault(term,f"?v{len(env)}")
        return (term[0],*map(rename,term[1:]))
    ordered=sorted(set(row),key=lambda p:(repr((p[0],pattern(p[1]))),repr(p)))
    clause=tuple(sorted(((p,rename(a)) for p,a in ordered),key=repr))
    return clause,{env[v]:types[v] for v in env},env


class Bound(Exception):
    pass


class Prover:
    def __init__(self,case,*,order="size",marks=(),learn=False,memo=False,admission=None,defer=True,offer_cap=65_000,node_cap=18_000):
        self.case=case
        self.order=order
        self.marks=tuple(marks)
        self.learn=learn
        self.admission=admission
        self.defer=defer
        self.memo=set() if memo else None
        self.offer_cap,self.node_cap=offer_cap,node_cap
        self.normal,self.skolems=front.clausify(case,1024)
        self.functions,self.predicates,self.sources=fol.signature(self.normal)
        self.nodes=[]
        self.seen=set()
        self.age,self.heap,self.passive=deque(),[],set()
        self.index=defaultdict(list)
        self.counts=Counter()
        self.discovered={}
        self.failed_uses=Counter()
        self.goal_symbols=set().union(*(names(a) for row in self.sources if row["id"].startswith(
            f"formula{len(case['premises'])+1}-") for _,a in row["clause"]))

    def add(self,row,types,kind,*,schema=None,parents=(),maps=(),pivot=None,sites=()):
        clause,types2,rename=normalize(row,types)
        if clause in self.seen:
            self.counts["duplicates"]+=1
            return
        if any((not p,a) in clause for p,a in clause):
            self.counts["tautologies"]+=1
            return
        if len(self.nodes)>=self.node_cap:
            raise Bound
        maps=tuple({v:subst(t,rename) for v,t in row.items()} for row in maps)
        num=len(self.nodes)
        auxiliary=not schema.startswith("formula") if schema is not None else any(
            self.nodes[i]["auxiliary"] for i in parents)
        node=dict(clause=clause,types=types2,kind=kind,schema=schema,auxiliary=auxiliary,
                               parents=parents,maps=maps,sites=sites,pivot=subst(pivot,rename) if pivot else None,
                               dead={v:t for v,t in types.items() if v not in rename})
        if self.admission is not None and kind!="source" and (not self.defer or not clause):
            self.admission.check(self,num,node)
        self.nodes.append(node)
        self.seen.add(clause)
        self.counts["stored"]+=1
        if not clause:
            return num
        weight=sum(size(a) for _,a in clause)+len(clause)
        if self.order=="goal":
            symbols=set().union(*(names(a) for _,a in clause))
            overlap=len(self.goal_symbols & symbols)
            weight+=24*auxiliary-2*overlap
        heappush(self.heap,(weight,num))
        self.age.append(num)
        self.passive.add(num)

    def pick(self):
        self.counts["given"]+=1
        if self.counts["given"]%4==0:
            self.counts["age_slots"]+=1
            while self.age[0] not in self.passive:
                self.age.popleft()
            result=self.age.popleft()
        else:
            while self.heap[0][1] not in self.passive:
                heappop(self.heap)
            _,result=heappop(self.heap)
        self.passive.remove(result)
        return result

    def scoped(self,num,prefix):
        node=self.nodes[num]
        env={v:f"?{prefix}{i}" for i,v in enumerate(sorted(node["types"]))}
        types={env[v]:s for v,s in node["types"].items()}
        row=tuple((p,subst(a,env)) for p,a in node["clause"])
        return row,types,env

    def offer(self,left,i,right,j,factor=False):
        self.counts["offers"]+=1
        if self.counts["offers"]>self.offer_cap:
            raise Bound
        a=self.nodes[left]["clause"][i][1]
        b=self.nodes[right]["clause"][j][1]
        assert a[0]==b[0] and len(a)==len(b)
        if any(rigid(x,y) for x,y in zip(a[1:],b[1:],strict=True)):
            self.counts["shallow_skips"]+=1
            return
        memo=self.memo if not factor else None
        if memo is not None and (a,b) in memo:
            self.counts["exact_memo_skips"]+=1
            return
        if not factor:
            for mark in self.marks:
                self.counts["mark_tests"]+=1
                if applies(mark,a,b):
                    self.counts["marked_skips"]+=1
                    self.failed_uses[(mark,a,b)]+=1
                    return
        first,types,lmap=self.scoped(left,"l")
        if factor:
            second,rmap=first,lmap
        else:
            second,other,rmap=self.scoped(right,"r")
            types.update(other)
        self.counts["unifications"]+=1
        environment=unifier(first[i][1],second[j][1],types,self.functions,self.counts)
        if environment is None:
            self.counts["failed_unifications"]+=1
            if memo is not None:
                memo.add((a,b))
            if self.learn and not factor:
                for mark in discover(a,b):
                    self.discovered.setdefault(mark,(a,b))
            return
        if factor:
            self.counts["successful_factors"]+=1
            rest=[lit for k,lit in enumerate(first) if k!=j]
            parents,links=(left,),(lmap,)
        else:
            self.counts["successful_resolutions"]+=1
            rest=[lit for k,lit in enumerate(first) if k!=i]+[lit for k,lit in enumerate(second) if k!=j]
            parents,links=(left,right),(lmap,rmap)
        clause=[(p,subst(t,environment)) for p,t in rest]
        maps=tuple({v:subst(t,environment) for v,t in link.items()} for link in links)
        return self.add(clause,types,"factor" if factor else "resolve",parents=parents,maps=maps,
                        pivot=subst(first[i][1],environment),sites=(i,j))

    def run(self):
        try:
            for schema in self.sources:
                source_map={v:v for v in schema["variables"]}
                found=self.add(schema["clause"],schema["variables"],"source",schema=schema["id"],maps=(source_map,))
                if found is not None:
                    return "PROVED",found
            while self.passive:
                given=self.pick()
                node=self.nodes[given]
                if self.admission is not None and self.defer and node["kind"]!="source":
                    self.admission.check(self,given,node)
                clause=node["clause"]
                for (i,(sign,a)),(j,(other,b)) in combinations(enumerate(clause),2):
                    if sign==other and a[0]==b[0]:
                        found=self.offer(given,i,given,j,True)
                        if found is not None:
                            return "PROVED",found
                for i,(sign,a) in enumerate(clause):
                    for other,j in self.index[not sign,a[0]]:
                        pair=(given,i,other,j) if sign else (other,j,given,i)
                        found=self.offer(*pair)
                        if found is not None:
                            return "PROVED",found
                # Self-resolution uses two separately scoped copies.
                for i,(sign,a) in enumerate(clause):
                    if sign:
                        for j,(other,b) in enumerate(clause):
                            if not other and a[0]==b[0]:
                                found=self.offer(given,i,given,j)
                                if found is not None:
                                    return "PROVED",found
                for i,(sign,a) in enumerate(clause):
                    self.index[sign,a[0]].append((given,i))
            return "SATURATED_WITHOUT_REFUTATION",None
        except Bound:
            return "BOUNDED",None

    def proof(self,root):
        selected={}
        def visit(i):
            if i not in selected:
                row=self.nodes[i]
                parents=tuple(visit(j) for j in row["parents"])
                selected[i]=len(selected)
                output.append({**row,"parents":parents})
            return selected[i]
        output=[]
        assert visit(root)==len(output)-1
        return output
