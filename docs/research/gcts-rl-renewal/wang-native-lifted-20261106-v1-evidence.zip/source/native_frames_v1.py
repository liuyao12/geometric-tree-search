"""Emit full Wang rectangles from the proofs found under native admission."""
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from boundary_kernel_v1 import build
import herbrand_v1 as fol
from lifted_experiment_v1 import ROOT, load, save
from lifted_frames_v1 import CAP, restore
from native_v1 import PUBLISHED_MACHINE
from sparse_frame_v1 import execute, verify
from study_v1 import write_gzip


def main():
    machine=build().compile()
    assert machine.digest()==PUBLISHED_MACHINE
    search=load("data/search-v1.json")
    cohort={s["id"]:s for s in load("input/cohort-v1.json")["holdout"]}
    frames=[]
    for row in search["cases"]:
        proof=row.get("proof")
        if proof is None:
            continue
        name=row["id"]
        builder=restore(cohort[name],proof["lines"])
        prefix,word=builder.prefix(),builder.words()
        raw=execute(machine,prefix,word,1,CAP)
        assert raw["status"]=="ACCEPT" and len(raw["commits"])==len(builder.lines),name
        receipt=verify(machine,prefix,word,1,raw["trace"],CAP)
        path=f"data/{name}-frame-v1.json.gz"
        write_gzip(ROOT/path,dict(prefix=prefix,word=word,padding=1,trace=raw["trace"],machine_sha256=PUBLISHED_MACHINE))
        term_depth=max((fol.depth(t) for line in builder.lines for _,a in line["clause"]
                        for t in a[1:]),default=0)
        frames.append(dict(id=name,artifact=path,receipt=receipt,commits=raw["commits"],
                           maximum_proof_term_depth=term_depth))
        print(name,len(builder.lines),receipt["steps"],flush=True)
    save("data/frames-v1.json",dict(status="ACCEPTED_PROOFS_FOUND_UNDER_NATIVE_ADMISSION",
                                    machine_sha256=PUBLISHED_MACHINE,frames=frames))


if __name__=="__main__":
    main()
