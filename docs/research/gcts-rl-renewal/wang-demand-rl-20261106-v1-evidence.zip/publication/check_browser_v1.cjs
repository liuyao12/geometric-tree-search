const assert = require("node:assert/strict");
const { pathToFileURL } = require("node:url");
const { chromium } = require(process.env.GCTS_PLAYWRIGHT);

async function main() {
  const browser = await chromium.launch({
    executablePath: process.env.GCTS_CHROME, headless: true, args: ["--no-sandbox"],
  });
  try {
    for (const width of [390, 1280]) {
      const page = await browser.newPage({ viewport: { width, height: 900 } });
      const errors = [];
      page.on("pageerror", error => errors.push(error.message));
      if (process.env.GCTS_MATHJAX) {
        await page.route("https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js",
          route => route.fulfill({ path: process.env.GCTS_MATHJAX, contentType: "application/javascript" }));
      }
      const file = pathToFileURL(process.cwd() + "/report/wang-demand-rl-20261106-v1.html");
      await page.goto(file.href, { waitUntil: "load", timeout: 60000 });
      await page.locator("#reader mjx-container").first().waitFor();
      assert.equal(await page.locator("#comparison > .table tbody tr").count(), 11);
      assert.match(await page.locator("#comparison .fifo .bar").textContent(), /14 of 18/);
      assert.equal(await page.locator("#decision .chosen").count(), 1);
      assert.equal(await page.locator("#reader .proof").count(), 4);
      const line = page.locator("#witness-line-124");
      await line.getByText("Show Wang squares and input").click();
      await line.locator("svg").waitFor();
      const window = await line.locator("svg > use").getAttribute("href");
      assert.equal(await page.locator(window + " > use").count(), 45);
      assert.ok(await line.locator("svg > use").evaluate(node => node.getBBox().width >= 324));
      assert.match(await line.locator("pre").innerText(), /R10/);
      assert.match(await line.locator(".formula").textContent(), /⊥/);
      assert.equal(await page.locator("mjx-merror").count(), 0);
      assert.deepEqual(errors, []);
      const layout = await page.evaluate(() => ({
        width: document.documentElement.scrollWidth,
        sections: [...document.querySelectorAll("main > section")].filter(node =>
          node.scrollWidth > node.clientWidth + 4).map(node => node.id),
      }));
      assert.deepEqual(layout, { width, sections: [] });
      console.log("Verified", width, "px, search comparison, proof disclosure and Wang squares.");
      await page.close();
    }
  } finally {
    await browser.close();
  }
}

main().catch(error => { console.error(error); process.exitCode = 1; });
