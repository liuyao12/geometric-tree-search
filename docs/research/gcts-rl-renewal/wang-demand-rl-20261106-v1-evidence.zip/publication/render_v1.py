"""Render the comparison and every checked logical line beside its Wang fragment."""
import gzip
from html import escape
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("publication", "wang/source")]
from boundary_kernel_v1 import build
from proof_views_v1 import clause, explanation, formula, frame_window, math, tile_svg

NAME = "wang-demand-rl-20261106-v1"
TITLE = "Learn which first-order match to try next"
LABELS = {
    "two-points-determine-a-line": "Hilbert incidence uniqueness",
    "between-on-the-line": "Hilbert betweenness on a line",
    "mixed-quantifier-swap": "Mixed-sort quantifier swap",
    "occurs-check-control": "Cyclic unification control",
    "zero-left-base": "Zero on the left, induction base",
    "zero-left-step": "Zero on the left, induction step",
    "successor-left-base": "Successor on the left, induction base",
    "successor-left-step": "Successor on the left, induction step",
}
ARMS = {"fifo": "FIFO", "fixed": "Fixed score", "random": "Random",
        "learned": "Learned with exact marks", "blind": "Learned with marks hidden"}
DISPLAY = ("fifo", "fixed", "random", "learned", "blind")
EXAMPLE = "test-typed-3/learned-29"
SHOW = (EXAMPLE, "test-typed-3/blind-47", "two-points-determine-a-line/fifo",
        "two-points-determine-a-line/blind-47")


def read(path):
    file = ROOT / path
    return json.loads(gzip.decompress(file.read_bytes()) if file.suffix == ".gz" else file.read_bytes())


def caption(name):
    if name in LABELS:
        return LABELS[name]
    _, family, number = name.split("-")
    kind = {"typed": "Typed route", "exists": "Hidden-term witness", "diamond": "Split and rejoin"}[family]
    return f"{kind}, {int(number) + 2} stages"


def run_label(mode):
    kind, _, seed = mode.partition("-")
    return ARMS[kind] + (f", seed {seed}" if seed else "")


def mode_keys(runs):
    return [key for group in DISPLAY for key in runs if key == group or key.startswith(group + "-")]


def comparison(data):
    rows, summary = [], []
    test = data["test"]
    positive = [item for item in test if not item["countermodel"]]
    common = [item for item in positive if all(run["proof"] for run in item["runs"].values())]
    for key in mode_keys(positive[0]["runs"]):
        solved = [item["runs"][key] for item in positive if item["runs"][key]["proof"]]
        shown = "".join(f'<td>{sum(r["counts"]["resolutions"] <= limit for r in solved)}</td>'
                        for limit in (250, 1000))
        fraction = 100 * len(solved) / len(positive)
        work = "".join(f'<td>{sum(item["runs"][key]["counts"].get(field, 0) for item in common):,}</td>'
                       for field in ("resolutions", "probes", "ranked_units"))
        summary.append(f'<tr class="{key.split("-")[0]}"><th scope="row">{run_label(key)}</th>{shown}'
                       f'<td><div class="bar" style="--coverage:{fraction:.2f}%">{len(solved)} of {len(positive)}</div>'
                       f'</td>{work}</tr>')
    for item in test:
        label = caption(item["original"]["id"])
        if item["countermodel"]:
            label += "<small>Checked countermodel</small>"
        cells = []
        for mode in DISPLAY:
            keys = [key for key in item["runs"] if key == mode or key.startswith(mode + "-")]
            lines = []
            for key in keys:
                run = item["runs"][key]
                state = "found" if run["proof"] else "open"
                suffix = "" if run["proof"] else f' · {run["stop"]} cap'
                lines.append(f'<span class="{state}">{run["counts"]["resolutions"]:,}{suffix}</span>')
            cells.append("<td>" + "<br>".join(lines) + "</td>")
        rows.append(f'<tr><th scope="row">{label}</th>{"".join(cells)}</tr>')
    return "".join(summary), "".join(rows), len(common)


def palette(bank):
    machine = build().compile()
    assert machine.digest() == bank["machine"]
    tiles, windows, patches = {}, {}, []
    for i, (key, entry) in enumerate(bank["traces"].items()):
        end = entry["steps"]
        evidence = dict(prefix=entry["prefix"], word=entry["word"], padding=0, trace=entry["fragment"])
        rows, start = frame_window(machine, evidence, end - 5, entry["head"])
        uses = []
        for y, row in enumerate(rows):
            for x, tile in enumerate(row):
                number = tiles.setdefault(tile, len(tiles))
                uses.append(f'<use href="#wang-{number}" x="{36 * x}" y="{36 * y}"/>')
        ident = f"window-{i}"
        patches.append(f'<g id="{ident}">{"".join(uses)}</g>')
        windows[key] = (ident, end, start)
    defs = "".join(tile_svg(tile, i) for tile, i in tiles.items()) + "".join(patches)
    return '<svg class="palette" width="0" height="0" aria-hidden="true"><defs>' + defs + "</defs></svg>", windows


def figure(window):
    ident, end, start = window
    return (f'<figure><svg role="img" aria-label="Window of 45 checked Wang squares" '
            f'viewBox="0 0 324 180"><use href="#{ident}"/></svg>'
            f'<figcaption>Verifier rows {end - 4:,} to {end:,} and columns {start:,} to '
            f'{start + 8:,}. Hover over a square for its edge labels.</figcaption></figure>')


def proof_view(label, bundle, problem, windows, traces):
    name, mode = label.split("/")
    rows = []
    selected = label == EXAMPLE
    for i, (row, call) in enumerate(zip(bundle["clauses"], bundle["calls"], strict=True), 1):
        entry = traces[call]
        id_attr = f' id="witness-line-{i}"' if selected else ""
        rows.append(
            f'<li{id_attr}><div class="formula">{math(clause(row["clause"]))}</div>'
            f'<div>{explanation(row)}</div><details class="wire"><summary>Show Wang squares and input</summary>'
            f'{figure(windows[call])}<pre><code>{escape(entry["prefix"])}\n'
            f'{escape(entry["word"])}</code></pre></details></li>')
    assumptions = "".join(f'<li>{math(formula(p))}</li>' for p in problem["premises"])
    opened = " open" if selected else ""
    return (f'<details class="proof"{opened}><summary>{caption(name)} · {run_label(mode)}</summary>'
            f'<div class="grid"><div><h3>Hypotheses</h3><ul class="formulas">{assumptions}</ul></div>'
            f'<div><h3>Conclusion</h3><div class="formula">{math(formula(problem["goal"]))}</div></div></div>'
            f'<ol class="steps">{"".join(rows)}</ol></details>')


def main():
    data = read("data/demand-study-v1.json")
    receipt = read("wang/data/demand-receipt-v1.json")
    bank = read("wang/data/demand-bank-v1.json.gz")
    proofs = read("wang/data/demand-proofs-v1.json.gz")
    problems = {row["original"]["id"]: row["original"] for row in data["test"]}
    included = {call for label in SHOW for call in proofs[label]["calls"]}
    traces = {key: trace for key, trace in bank["traces"].items() if key in included}
    defs, windows = palette({**bank, "traces": traces})
    example_call = proofs[EXAMPLE]["calls"][-1]
    all_proofs = "".join(proof_view(key, proofs[key], problems[key.split("/")[0]],
                                    windows, traces) for key in SHOW)
    typed = next(row for row in data["test"] if row["original"]["id"] == "test-typed-3")
    example = typed["runs"]["learned-29"]["example"]
    decision = []
    for i, (unit, score, f) in enumerate(zip(example["units"], example["scores"], example["features"], strict=True)):
        chosen = ' class="chosen"' if i == example["chosen"] else ""
        tag = " · chosen" if chosen else " · oldest" if i == 0 else ""
        decision.append(f'<tr{chosen}><th scope="row">{i + 1}{tag}</th><td>{math(clause(unit))}</td>'
                        f'<td>{int(f[5])}</td><td>{round(f[7] * 5)}</td><td>{round(f[8] * 5)}</td>'
                        f'<td>{score:.3f}</td></tr>')
    summary, details, common = comparison(data)
    vals = dict(title=TITLE, stem=NAME, summary=summary, table=details, common=str(common),
                decision="".join(decision), example_round=str(example["round"]), palette=defs,
                example=figure(windows[example_call]), proofs=all_proofs,
                records=f'{receipt["records"]:,}', distinct=f'{receipt["unique_fragments"]:,}',
                proof_count=str(receipt["proofs"]), cap=f'{bank["cap"]:,}')
    head = (ROOT / "publication/group-notebook-head-v1.html").read_text().replace(
        "Lifted equality search for Wang proofs", TITLE)
    head = head.replace("</style>", """
.palette{position:absolute;width:0;height:0;overflow:hidden;border:0}
#tiles figure,.wire figure{max-width:26rem}
td small,th small{display:block;color:#42606f}.found{color:#145c49}.open{color:#685324}
.steps li{padding:.4rem .1rem;border-bottom:1px solid #d3e0e5}
.formula,.formulas li{overflow:auto;padding:.14rem 0}
.wire{margin:.3rem 0}.wire summary{font-size:.9rem}
.proof>ol{padding-left:1.8rem}.proof h3{font-size:1rem}
.bar{background:linear-gradient(90deg,#e0ecef var(--coverage),transparent var(--coverage));min-width:5.2rem;padding:.1rem .22rem}
.learned .bar{background:linear-gradient(90deg,#bde8d5 var(--coverage),transparent var(--coverage))}
.blind .bar{background:linear-gradient(90deg,#f1dfb4 var(--coverage),transparent var(--coverage))}
.chosen{background:#dcf2e7}td .open{font-size:.88rem}
</style>""")
    body = (ROOT / "publication/demand-body-v1.html").read_text()
    for key, value in vals.items():
        body = body.replace("%%" + key.upper() + "%%", value)
    assert "%%" not in body
    (ROOT / "report" / (NAME + ".html")).write_text(head + body)


if __name__ == "__main__":
    main()
