"""Train and freeze demand selection before testing on disjoint proof families."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("source", "wang/source", "wang/external/source")]
from definition_check_v1 import check
from definitions_v1 import compile_case
from equality_cases_v1 import holds
from demand_cases_v1 import testing, training
from demand_policy_v1 import FEATURES, Guided, train

SEEDS = (11, 29, 47)
PASSES = 4
TRAIN = dict(rounds=125, resolutions=4000, instances=3600, probes=7200)
TEST = dict(rounds=400, resolutions=28000, instances=11000, probes=26000)
MODES = ("fifo", "fixed", "random", "learned", "blind")


def compile_(original):
    normal, translation = compile_case(original)
    return original, normal, translation, check(original, normal, translation)


def study():
    source = [compile_(p) for p in training()]
    held_out = testing()
    train_ids = {p["id"] for p, _, _, _ in source}
    test_ids = {p["id"] for p, _ in held_out}
    assert len(train_ids) == len(source) and len(test_ids) == len(held_out)
    assert train_ids.isdisjoint(test_ids)
    models = {mode: {} for mode in ("learned", "blind")}
    for mode, bank in models.items():
        for seed in SEEDS:
            bank[seed] = train([(p, n) for p, n, _, _ in source], seed, TRAIN, PASSES, mode == "learned")
            if mode == "blind":
                assert bank[seed]["weights"][5:9] == [0.0] * 4
            print("train", mode, seed, [r["solved"] for r in bank[seed]["passes"]], flush=True)
    rows = []
    for original, model in held_out:
        original, normal, translation, qualification = compile_(original)
        if model is not None:
            premises, goal = holds(original, model)
            assert all(premises) and not goal
        runs = {}
        for mode in MODES:
            for seed in (SEEDS if mode in ("learned", "blind", "random") else (0,)):
                name = f"{mode}-{seed}" if seed else mode
                engine = Guided(normal, original["goal"], "learned" if mode == "blind" else mode, TEST, seed,
                                weights=models[mode][seed]["weights"] if mode in models else (),
                                marked=mode != "blind")
                out = engine.run()
                assert model is None or out["status"] == "BOUNDED"
                assert all(out["counts"].get(key, 0) <= cap for key, cap in TEST.items())
                runs[name] = dict(out, example=engine.example)
        rows.append(dict(original=original, normal=normal, translation=translation,
                         qualification=qualification, countermodel=model is not None, runs=runs))
        print(original["id"], " ".join(f'{n}:{r["counts"].get("resolutions", 0)}'
                                      f'{"*" if r["proof"] else ""}' for n, r in runs.items()), flush=True)
    return dict(training=[p for p, _, _, _ in source], models=models, test=rows, features=FEATURES,
                seeds=SEEDS, train_limits=TRAIN, test_limits=TEST, passes=PASSES)


def main():
    if not __debug__:
        raise RuntimeError("Replay requires assertions")
    result = study()
    expected = json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n"
    path = ROOT / "data/demand-study-v1.json"
    if "--build" in sys.argv:
        path.write_text(expected)
    else:
        assert path.read_text() == expected


if __name__ == "__main__":
    main()
