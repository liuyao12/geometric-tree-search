"""Bind every policy arm's returned proofs to the same fixed Wang checker."""
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / p) for p in ("wang/source", "wang/external/source")]
from definition_check_v1 import check
from herbrand_v1 import signature
from opaque_replay_v1 import build_bank, decoder, fingerprint, fragment, match, records, verify_bank
from schematic_capsules_v1 import encoded, frozen
from study_v1 import guarded

BANK = ROOT / "wang/data"


def prepare(data):
    wires, bundles = {}, {}
    for item in data["test"]:
        original, normal, translation = (item[k] for k in ("original", "normal", "translation"))
        assert check(original, normal, translation) == item["qualification"]
        functions, _, schemata = signature(normal)
        sources, _ = guarded(schemata, functions, normal["sorts"])
        sources = frozen(sources)
        for mode, run in item["runs"].items():
            if run["status"] != "PROVED":
                continue
            label = original["id"] + "/" + mode
            proof = frozen(run["proof"])
            assert proof and not proof[-1]["clause"]
            calls = []
            for i, row in enumerate(proof):
                names, prefix, word = fragment(proof, i, sources, functions)
                parsed = decoder.read(prefix, word + "!", require_empty=False)
                match(proof, i, sources, names, parsed, prefix)
                key = fingerprint(prefix, records(word))
                wire = wires.setdefault(key, dict(prefix=prefix, word=word, example=(label, i + 1),
                                                  uses=0, rule=row["rule"]))
                assert (prefix, word) == (wire["prefix"], wire["word"])
                wire["uses"] += 1
                calls.append(key)
            bundles[label] = dict(clauses=proof, calls=calls, sources=sources)
    return wires, bundles


def reject_wrong_parent(bundles):
    bundle = bundles["test-exists-0/fifo"]
    proof, sources = bundle["clauses"], bundle["sources"]
    i = len(proof) - 1
    functions = {}
    names, prefix, word = fragment(proof, i, sources, functions)
    parsed = decoder.read(prefix, word + "!")
    forged = (*proof[:i], {**proof[i], "left": proof[i]["right"]})
    try:
        match(forged, i, sources, names, parsed, prefix)
    except AssertionError:
        return True
    raise AssertionError("Substitution of the wrong proof parent was accepted")


def main():
    if not __debug__:
        raise RuntimeError("Proof replay requires assertions")
    data = json.loads((ROOT / "data/demand-study-v1.json").read_text())
    wires, bundles = prepare(data)
    bank_file = BANK / "demand-bank-v1.json.gz"
    rebuild = "--build" in sys.argv
    bank = build_bank(wires) if rebuild else json.loads(gzip.decompress(bank_file.read_bytes()))
    receipt = dict(proofs=len(bundles), records=sum(w["uses"] for w in wires.values()),
                   wrong_parent_rejected=reject_wrong_parent(bundles), **verify_bank(wires, bank))
    outputs = ((bank_file, bank, True), (BANK / "demand-proofs-v1.json.gz", bundles, True),
               (BANK / "demand-receipt-v1.json", receipt, False))
    for path, body, compressed in outputs:
        expected = encoded(body) + b"\n"
        if rebuild:
            path.write_bytes(gzip.compress(expected, mtime=0) if compressed else expected)
        else:
            actual = path.read_bytes()
            assert (gzip.decompress(actual) if compressed else actual) == expected
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
