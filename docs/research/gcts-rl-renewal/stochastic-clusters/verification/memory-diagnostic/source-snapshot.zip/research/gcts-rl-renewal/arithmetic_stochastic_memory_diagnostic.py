"""Bounded read-only gzip-footer/prefix diagnostic; never loads full traces."""
import hashlib
import json
import re
import resource
import struct
import time
from pathlib import Path
import gzip

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'
OUT = BASE/'memory-diagnostic-v1'
TOKEN = re.compile(rb'(?P<string>"(?:[^"\\]|\\.)*")|(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|\[\s*(?P<a>-?\d+)\s*,\s*(?P<b>-?\d+)\s*,\s*(?P<c>-?\d+)\s*,\s*(?P<d>-?\d+)\s*\]')


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1 << 20), b''):
            value.update(part)
    return value.hexdigest()


def main():
    began = time.perf_counter()
    plan = json.loads((OUT/'plan.json').read_bytes())
    for path, pin in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if sha(ROOT/path) != pin:
            raise ValueError('read-only memory diagnostic binding '+path)
    rows = []
    for path in plan['traces']:
        file = ROOT/path
        with file.open('rb') as stream:
            stream.seek(-8, 2)
            crc, isize = struct.unpack('<II', stream.read(8))
        with gzip.open(file, 'rb') as stream:
            prefix = stream.read(plan['prefix_bytes'])
        arrays, unique = 0, set()
        for match in TOKEN.finditer(prefix):
            if match.group('partial') is not None:
                break
            if match.group('a') is not None:
                arrays += 1
                unique.add(tuple(int(match.group(key)) for key in ('a','b','c','d')))
        rows.append(dict(path=path, sha256=sha(file), compressed_bytes=file.stat().st_size,
            gzip_isize_mod_2_to_32=isize, footer_crc32=crc,
            bounded_prefix_bytes=len(prefix), prefix_sha256=hashlib.sha256(prefix).hexdigest(),
            quoted_token_aware_four_integer_array_occurrences=arrays,
            distinct_four_integer_arrays_in_prefix=len(unique),
            exact_top_level_search_tree_marker_offset_in_prefix=prefix.find(b',"tree":'),
            sample_scope='First1MiB only, quoted tokens skipped; no whole trace parse, graph replay, complete array census or new validity claim. GzipISIZE is a footer field, modulo2^32; not independently recomputed.'))
    result = dict(status='completed_bounded_read_only_memory_diagnosis', traces=rows,
        seconds=time.perf_counter()-began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        original_evaluation_audit_status='unknown_independent_phase_resource_budget',
        original_attempted_audit_jobs=['base-r1'], original_unexecuted_audit_jobs=['untrained-r1','trained-r1','trained-r2','untrained-r2','base-r2'],
        original_kernel_worker_peak_bytes=1643200512, original_conservative_phase_peak_bytes=1720975360,
        diagnosis='json.load(stream) calls stream.read() internally, so gzip text is fully decoded before JSON parsing; repeated four-integer candidate arrays allocate independent Python lists/ints across every census. Loading trace before model prevents a second large model during parse but does not avoid full decoded text or duplicate key arrays. Later model/catalog/registry and literal graph/features add live memory.',
        repair_options=[
            dict(priority=1, option='Versioned audit-only import of previously verified commutativity_cluster_intern_v3.load',
                 mechanism='Stream quoted-token-preserving replacement of every four-integer array with reserved reference, write reduced temporary JSON, parse with restoration to shared exact ordered tuples.',
                 advantages='Keeps unchanged recursive auditor and all node/event/value semantics; prior full13 four-tree audit passed404193280B.',
                 required_gate='Fresh source/input freeze and complete canonical JSON-value correspondence for new base/untrained/trained traces, including strings/prefix collisions/floats/tokens; all six full graph/event replays and final512MiB phase gate remain mandatory.',
                 risk='Still retains all decoded objects; new policy feature/event objects and registry lifetimes may use remaining headroom. tuple/list JSON equivalence must be audited for all consumers; no success assumption.'),
            dict(priority=2, option='Streaming node consumer with bounded event/header retention',
                 mechanism='Parse exact saved tree sequentially and replay each node with traversal stack; reconstruct full literal graph/features/RNG independently without retaining every prior census.',
                 advantages='Memory scales with active recursion/state and bounded policy metadata rather than every saved census.',
                 required_gate='New independent traversal implementation and full original-field/event/order/value correspondence; retain all child/fallback/cutoff checks, exact weights/RNG and every node. Never omit census or truncate events.',
                 risk='More source surface and ordering/lifetime risks; requires separately frozen meaningful controls before any replay.'),
            dict(priority=3, option='Release preparation-only catalog/native registry and binding witnesses before graph replay',
                 mechanism='Retain only already bound model/rules/families; del temporary returned placements/canonical bytes/catalog/registry and collect garbage before tree.',
                 advantages='Reduces live ancillary objects without altering graph/tree semantics.',
                 required_gate='Exact old-request/catalog/native-admission bindings still completed and receipted before release.',
                 risk='Insufficient alone for1.64GB peak reached while full duplicate-key trace exists; allocator RSS may remain high.')],
        root_owned_future_gate='Prospective options only. Root has explicitly retained the evaluation audit UNKNOWN this turn; no repair/full replay or gate amendment executed.',
        searches=0, training_episodes=0, native_queries=0, complete_trace_inflations=0,
        collector_scope='Separate frozen read-only collector may scan actual fields after authorization; this diagnostic does not invoke it.')
    if result['seconds'] > plan['seconds'] or result['peak_rss_bytes'] > plan['rss_bytes']:
        result['status'] = 'unknown_bounded_memory_diagnostic_resource_gate'
    with (OUT/'diagnosis.json').open('x') as stream:
        stream.write(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(status=result['status'], seconds=result['seconds'], peak_rss_bytes=result['peak_rss_bytes'],
        receipt_sha256=sha(OUT/'diagnosis.json'), traces=rows)))


if __name__ == '__main__':
    main()
