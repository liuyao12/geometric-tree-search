"""Integrate terminal evidence only; no engine, training or native execution."""
import gzip
import hashlib
import html
import json
import re
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DOC = ROOT / 'docs/research/gcts-rl-renewal'
DEST = DOC / 'stochastic-clusters'
ARITH = ROOT / '.gcts-active/arithmetic-stochastic-clusters-20261011'
RUN = ARITH / 'execution-v2'
GEOM = ROOT / '.gcts-active/hilbert-aggregate-expansion-20261011'
CHECK = ROOT / '.gcts-active/hilbert-aggregate-independent-audit-20261011'


def load(path):
    with (gzip.open(path, 'rt') if path.suffix == '.gz' else path.open()) as stream:
        return json.load(stream)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def math(value):
    return r'\(' + html.escape(str(value)) + r'\)'


def term(value):
    if value[0] == 'var':
        return {'point0': 'p_0', 'point1': 'p_1', 'line0': r'\ell_0', 'line1': r'\ell_1', 'incidenceHole': 'u'}.get(value[1], value[1])
    name = r'\ell' if value[1] == 'l' else value[1]
    return name + ('(' + ','.join(map(term, value[2])) + ')' if value[2] else '')


def formula(value):
    op = value[0]
    if op == 'pred':
        return r'\operatorname{' + value[1] + '}(' + ','.join(map(term, value[2])) + ')'
    if op == 'eq':
        return term(value[1]) + '=' + term(value[2])
    if op == 'all':
        return r'\forall ' + term(['var', value[1]]) + r'\,(' + formula(value[2]) + ')'
    if op == 'not':
        return r'\neg(' + formula(value[1]) + ')'
    if op in ('and', 'imp'):
        return '(' + formula(value[1]) + {'and': r'\land ', 'imp': r'\rightarrow '}[op] + formula(value[2]) + ')'
    raise ValueError(value)


def table(headers, rows):
    return '<div class="table-scroll"><table><thead><tr>' + ''.join('<th>' + x + '</th>' for x in headers) + '</tr></thead><tbody>' + ''.join('<tr>' + ''.join('<td>' + x + '</td>' for x in row) + '</tr>' for row in rows) + '</tbody></table></div>'


def main():
    DEST.mkdir(exist_ok=True)
    files, origins = set(), []
    def copy(source, relative):
        target = DEST / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        files.add(str(target.relative_to(ROOT)))
        origins.append(dict(path=str(target.relative_to(ROOT)), origin=str(source.relative_to(ROOT)), sha256=digest(source), bytes=source.stat().st_size))
    plan = load(ARITH / 'experiment-plan-v2.json')
    phases = {phase: load(RUN / phase / 'phase-summary.json') for phase in ('effect', 'training', 'evaluation')}
    audits = {phase: load(RUN / phase / 'independent-audit.json') for phase in ('effect', 'training', 'evaluation')}
    effect = audits['effect']
    training = audits['training']
    evaluation = audits['evaluation']
    collection = load(ARITH / 'collector-v1/final-audited-v1.json')
    assert effect['status'] == 'passed_complete_action_effect_graph_and_policy_gate'
    assert training['status'] == 'passed_complete_training_graph_rng_and_updates'
    eval_pass = evaluation['status'] == 'passed_complete_balanced_evaluation_graph_rng_and_policy'
    checkpoint = load(GEOM / 'production-checkpoint-v2.json')
    geometry_plan = load(CHECK / 'full-audit-plan-v2.json')
    geometry_audit_path = ROOT / geometry_plan['outputs']['audit']
    geometry_lifetime_path = ROOT / geometry_plan['outputs']['lifetime']
    geometry_audit = load(geometry_audit_path) if geometry_audit_path.exists() else None
    geometry_lifetime = load(geometry_lifetime_path)
    geometry_pass = geometry_lifetime['status'] == 'passed_full_lifetime_static_audit_gate'
    if geometry_pass:
        assert geometry_audit['status'] == 'passed_independent_finite_static_symbolic_and_aggregate_audit'
    for phase in phases:
        for source in (RUN / phase).glob('*'):
            if source.is_file():
                copy(source, 'arithmetic/' + phase + '/' + source.name)
    for source in RUN.glob('activation*.json'):
        copy(source, 'arithmetic/preparation/' + source.name)
    for source in (ARITH / 'collector-v1').glob('*'):
        if source.is_file():
            copy(source, 'arithmetic/collector/' + source.name)
    for source in (ARITH / 'memory-diagnostic-v1').glob('*'):
        if source.is_file():
            copy(source, 'verification/memory-diagnostic/' + source.name)
    for name in ('experiment-plan.json', 'experiment-plan-v2.json', 'source-ready-receipt-v2.json', 'fixture-plan.json', 'fixtures.json', 'fixture-plan-v2.json', 'fixtures-v2.json', 'fixture-plan-v3.json', 'fixtures-v3.json', 'fixture-attempt-01-source.zip', 'fixture-attempt-02-source.zip', 'review-source-freeze-v2.zip'):
        copy(ARITH / name, 'arithmetic/preparation/' + name)
    for source in (ARITH / 'effect').glob('*'):
        if source.is_file():
            copy(source, 'arithmetic/preparation/failed-dispatch/' + source.name)
    for name in ('policy-math-controls.json', 'independent-feature-fixture-plan.json', 'independent-feature-fixture.json', 'independent-feature-fixture-sources.zip', 'trace-mutation-plan.json', 'trace-mutation-controls.json', 'arithmetic-root-review.json', 'report-scope-plan.json'):
        copy(HERE / name, 'verification/' + name)
    for source in (ARITH / 'independent-implementation-review-v1').glob('*'):
        if source.is_file():
            copy(source, 'verification/implementation-review/' + source.name)
    for source in GEOM.glob('*'):
        if source.is_file() and source.suffix in ('.json', '.gz', '.py', '.txt'):
            copy(source, 'geometry/production/' + source.name)
    for source in CHECK.glob('*'):
        if source.is_file() and source.suffix in ('.json', '.gz', '.py', '.txt'):
            copy(source, 'geometry/verification/' + source.name)
    bindings = dict(plan['source_sha256'])
    collector_source = ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_collect.py'
    bindings[str(collector_source.relative_to(ROOT))] = digest(collector_source)
    bindings.update(plan['input_sha256'])
    for phase in audits:
        audit_plan = load(RUN / phase / 'independent-audit-plan.json')
        bindings.update(audit_plan['source_sha256'])
        bindings.update(audit_plan['input_sha256'])
    scientific_plan = load(GEOM / 'plan-v1.json')
    # Authoritative mathematical inputs are distinct from preservation-only history.
    for pin in scientific_plan['inputs']:
        bindings[pin['path']] = pin['sha256']
    for pin in geometry_plan['sources']:
        bindings[pin['path']] = pin['sha256']
    bindings[str(Path(__file__).relative_to(ROOT))] = digest(Path(__file__))
    # Already exported traces stay as individual files rather than being copied
    # into a second huge ZIP. The binding manifest resolves each exact pin.
    published_origins = {item['origin']: item['path'] for item in origins}
    binding_records = []
    archive = DEST / 'sources-and-inputs.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for path, sha in sorted(bindings.items()):
            source = ROOT / path
            assert digest(source) == sha, 'current frozen source/input changed: ' + path
            public_path = published_origins.get(path)
            binding_records.append(dict(path=path, sha256=sha, bytes=source.stat().st_size,
                                        published_path=public_path, archive_member=None if public_path else path))
            if not public_path:
                bundle.write(source, path)
    files.add(str(archive.relative_to(ROOT)))
    (DEST / 'source-input-bindings.json').write_text(json.dumps(binding_records, indent=2) + '\n')
    files.add(str((DEST / 'source-input-bindings.json').relative_to(ROOT)))
    (DEST / 'origins.json').write_text(json.dumps(origins, indent=2) + '\n')
    files.add(str((DEST / 'origins.json').relative_to(ROOT)))
    pilot = load(RUN / 'effect/effect-pilot-summary.json')
    observations = []
    for job in plan['observations']:
        path = RUN / job['phase'] / (job['id'] + '-summary.json')
        if path.exists():
            observations.append(dict(job=job, summary=load(path)))
    eval_rows = []
    for observation in observations:
        job, summary = observation['job'], observation['summary']
        if job['phase'] != 'evaluation':
            continue
        m = summary.get('metrics', {})
        eval_rows.append([html.escape(job['id']), html.escape(summary.get('search_status', summary['status'])),
                         math(m.get('attempts', 0)), math(m.get('max_satisfied_points', 0)),
                         math(m.get('executed_changed_first_branches', 0)),
                         math(round(summary.get('search_seconds', 0), 3)),
                         '<a href="arithmetic/evaluation/' + job['id'] + '-audit.json">Resource cutoff</a>' if (RUN / 'evaluation' / (job['id'] + '-audit.json')).exists() else 'Not executed'])
    reward_rows, bars = [], []
    for i in range(1, 9):
        transition = load(RUN / 'training' / ('train-%02d-policy.json' % i))
        update = transition['update']
        reward_rows.append([math(i), math(round(update['reward'], 6)), math(round(update['advantage'], 6)),
                            math(round(update['advantage_scaled_gradient_norm'], 6)), math(round(update['applied_gradient_scale'], 6))])
        bars.append('<div class="barrow"><span>' + math(i) + '</span><div class="track"><div class="bar" style="width:' + str(max(0, min(100, 100 * update['reward']))) + '%"></div></div><span>' + math(round(update['reward'], 3)) + '</span></div>')
    content = r'''<section class="intro"><p class="eyebrow">THREE PARALLEL TRACKS · ACTUAL SEARCH AND INDEPENDENT REPLAY</p><h1>Does learning change the search?</h1><p class="deck">A real stochastic cluster policy, eight fresh training episodes, matched controls, and a separately checked primitive geometry inventory.</p><p><a href="#arithmetic">Arithmetic results</a> · <a href="#training">Training</a> · <a href="#geometry">Geometry inventory</a> · <a href="#reader">Colored primitive rows</a> · <a href="#assessment">Assessment</a></p></section>'''
    content += '<section class="panel" id="arithmetic"><p class="eyebrow">NOTEBOOK 100 · SAME COMPLETE THIRTEEN-ROW TARGET</p><h2>The policy now changes actual legal moves.</h2><div class="cards"><div><strong>' + math(pilot['metrics']['executed_changed_first_branches']) + '</strong>Visited changed-first branches in the pilot</div><div><strong>' + math(8) + '</strong>Fresh, independently replayed training episodes</div><div><strong>' + ('passed' if eval_pass else 'incomplete') + '</strong>Complete matched evaluation audit</div></div>'
    content += r'''<p>The target remains \(\forall x\,\forall y\,(x+y=y+x)\), with the same \(19848\) base placements, \(52\) required point obligations, \(153\) rules and \(94\) previously admitted definitions. No ordinary proof word or old search trajectory is used as training input. The new features encode translation-relative command and source attachments, source-row occupancy, and distant marking dependencies. An independent saved-state check reproduces all \(13\) feature vectors and \(322\) entries.</p><p>The untrained pilot visits \(18\) branches whose first legal move changes. Every actual node, complete domain, proposal, feature, RNG draw, hint continuation, fallback alternative and rollback is independently replayed. The pilot reaches \(500\) attempts and remains unknown. Its old fixed-policy predecessor changed no branch ordering; this comparison establishes action effect, not improved proof finding.</p><p>All six planned evaluation jobs retain \(5000\) attempts and \(60\) search seconds, with \(100\) seconds for each full worker lifecycle. They run in balanced order: baseline, untrained, trained, trained, untrained, baseline. Seeds differ from training; every theorem is still the same instance. This is not held-out-theorem generalization.</p>'''
    content += table(['Lane', 'Outcome', 'Attempts', 'Peak satisfied obligations', 'Visited changed-first branches', 'Search seconds', 'Complete audit'], eval_rows)
    content += '<p>All six producer searches finished without a proof, each reaching ' + math(5000) + ' attempts and the same peak of ' + math(45) + ' satisfied obligations. Their reported mean search times are ' + math(31.985) + ' seconds for baseline, ' + math(42.935) + ' for untrained and ' + math(44.759) + ' for trained selection. These are producer observations pending complete evaluation replay; they show no proof-finding gain.</p>'
    content += '<p class="note">' + ('Every evaluation trajectory and resource gate passes independent replay. Budget-limited runs remain unknown; this experiment makes no native acceptance claim for a newly found candidate.' if eval_pass else 'The first independent evaluation replay reached a kernel peak of about 1.64 GB, exceeding its declared 512 MiB gate. Its phase receipt is UNKNOWN, with five audit jobs unexecuted. All six producer searches executed; their full independent evaluation is incomplete. No comparative acceleration claim is licensed.') + '</p>'
    content += '<p>The arithmetic experiment uses the existing exact scalar point adaptation, with four roles per proof row. It does not implement primitive unit-occupancy Wang squares. The complete graph and primitive colored geometry inventory below have different execution status.</p>'
    content += '<p>GCTS maintains complete point/candidate bookkeeping, checks global dead ends and forced moves, and branches at the earliest generation. RL proposes validated clusters and changes continuation preferences; every base alternative remains available. This experiment learns policy weights. Learned failure markings have not been activated or promoted to proof rules.</p>'
    content += '<p>Complete evaluation producer phase: ' + math(round(phases['evaluation']['seconds_before_final_phase_receipt_write'], 3)) + ' seconds. Retained incomplete replay phase: ' + math(round(evaluation['seconds_before_final_phase_receipt_write'], 3)) + ' seconds. Full worker startup, output serialization and conservative owner/child kernel peaks are recorded separately from search time.</p>'
    content += '<p><a href="arithmetic/effect/independent-audit.json">Actual pilot gate</a> · <a href="arithmetic/evaluation/independent-audit.json">Matched evaluation gate</a> · <a href="arithmetic/preparation/experiment-plan-v2.json">Frozen experiment</a> · <a href="../certificate-hierarchy/reader.html#reader">Earlier ordinary proof, line by line</a></p></section>'
    content += r'''<section class="panel" id="training"><p class="eyebrow">NOTEBOOK 101 · ENGINE-GENERATED TRAJECTORIES</p><h2>Eight episodes produce a frozen learned policy.</h2><p>Each training episode retains \(500\) attempts, \(10\) search seconds and a \(30\)-second complete worker lifecycle. At each eligible branch, a proposal is sampled from \(p_i=0.9q_i+0.1/n\), where \(q\) is the softmax of the sparse feature scores. The update uses the mixture’s actual log-gradient, including its \(0.9q_i/p_i\) correction. The episode mean gradient is multiplied by observed return minus an exponential baseline, then clipped in norm. Proposal counts never replace complete base domains.</p><p>The return rewards peak satisfied obligations and subtracts observed dead ends, backtracking, branching and proposal effort. Unknown episodes contribute their observed finite return; they are not evidence of unprovability. All rewards, corrected gradients, advantage clipping, baseline changes and weights are independently recomputed. All \(21\) numerical finite-difference checks pass; eight corruptions of the actual pilot trace are rejected.</p><div class="rewardchart" aria-label="Observed training returns">''' + ''.join(bars) + '</div>'
    content += table(['Episode', 'Observed return', 'Advantage', 'Scaled gradient norm', 'Applied clipping scale'], reward_rows)
    content += '<p>Training producer phase: ' + math(round(phases['training']['seconds_before_final_phase_receipt_write'], 3)) + ' seconds. Full independent training replay: ' + math(round(training['seconds_before_final_phase_receipt_write'], 3)) + ' seconds. These costs must be included in a practical acceleration assessment. Source authorship, experiment design and uninstrumented preparation are additional costs, not zero.</p><p><a href="arithmetic/training/policy-final.json">Frozen learned weights</a> · <a href="arithmetic/training/independent-audit.json">Every training replay and update</a> · <a href="verification/trace-mutation-controls.json">Actual trace corruption checks</a></p></section>'
    content += '<section class="panel"><h2>Account for checking and preparation too.</h2><p>The selected producer and audit phases, including the failed dispatch, total ' + math(round(collection['costs']['selected_known_cost_sum_seconds'], 3)) + ' seconds. The read-only result collector adds ' + math(round(collection['collector_seconds_before_receipt_write'], 3)) + ' seconds; its own kernel peak is ' + math(round(collection['collector_peak_rss_bytes'] / 1048576, 3)) + ' MiB. This is a partial cost ledger, not an overall speedup result. Component search, proposal, worker and phase clocks overlap and must not be summed again. Earlier fixtures, source authorship and final receipt writes have separately disclosed exclusions.</p><p><a href="arithmetic/collector/final-audited-v1.json">Exact collected outcomes and non-overlapping cost ledger</a> · <a href="verification/memory-diagnostic/diagnosis.json">Bounded evaluation memory diagnosis</a></p></section>'
    counts = checkpoint['counts']
    content += '<section class="panel" id="geometry"><p class="eyebrow">NOTEBOOK 102 · SYMBOLIC HILBERT INCIDENCE</p><h2>' + ('Primitive geometry clusters pass a separate logical audit.' if geometry_pass else 'The primitive geometry logical audit remains unresolved.') + '</h2><div class="cards"><div><strong>' + math(counts['named_definitions']) + '</strong>Mapped source definitions</div><div><strong>' + math(counts['source_body_leaf_occurrences']) + '</strong>Primitive leaf occurrences</div><div><strong>' + math(counts['primitive_recipe_types']) + '</strong>Primitive recipe types</div></div>'
    content += r'''<p>The inventory preserves every literal source body and ordered dependency, including \(630\) zero-occupancy assumption aliases and \(216\) recursive block calls. Its injective formula registry has \(217\) values. A new full decorated identity binds exact point values, ordered references, context, registry and frozen authority. Older printed IDs bound command, context and row only; their limited historical meaning is retained.</p><p>The authored two-step incidence chain still uses \(13+13-5=21\) distinct inference placements plus three premise seeds. The independent symbolic checker separately checks the guarded Hilbert uniqueness axiom, instantiation, equality substitution and modus ponens; point consistency alone cannot admit an invalid inference. The two clusters share actual decorated placements, not merely equal formulas.</p>'''
    if geometry_pass:
        content += '<p>All source expansions, canonical aggregates, receptor projections, full identities, registry and the authored shared example pass complete independent static reconstruction. The ' + math(31) + ' named controls include positive fixtures and collectively reject ' + math(geometry_audit['corruption_count']) + ' explicit corrupt variants. This establishes finite source-level logical and point consistency; it does not establish search discovery or native/compiler correspondence.</p>'
    content += r'''<p class="note">The \(24\)- and \(65\)-row models are declared finite grammars. Their complete primitive placement graphs have not been constructed. Validated clusters can be a proposal family with complete primitive fallback; enumerating every aggregate embedding is not required for that use. An atomic aggregate shortcut needs a separate equivalence argument. The proposed \(65\)-row padding is a conditional one-way lift. Scheduler/rollback execution, primitive-to-native/compiler correspondence and a fresh whole native request remain open. The chain shown below is authored, not a newly discovered theorem.</p>'''
    content += '<p>Production including the first failed attempt: ' + math(round(checkpoint['cumulative_production_outer_seconds'], 3)) + ' seconds. The original serializer exceeded the ' + math(512) + ' MiB limit. A versioned streaming repair produces byte-identical data under the same cumulative gate. Independent audit lifetime: ' + math(round(geometry_lifetime['full_lifetime_seconds_before_final_receipt_write'], 3)) + ' seconds. Its final receipt write is excluded and disclosed.</p><p><a href="geometry/production/production-checkpoint-v2.json">Exact expansion and retained failures</a> · <a href="geometry/production/reader-data-v2.json">All mapped definitions and compact primitive inventory</a> · <a href="geometry/verification/' + geometry_audit_path.name + '">Complete static audit</a> · <a href="geometry/verification/' + geometry_lifetime_path.name + '">Full audit lifetime</a></p></section>'
    example = load(GEOM / 'example-correspondence-v2.json')
    first, second = [set(c['aggregate']['constituent_ids']) for c in example['clusters']]
    content += r'''<section class="panel" id="reader"><p class="eyebrow">TRANSLATION ONLY · ACTUAL COLORED POINT MARKINGS</p><h2>The shared geometry proof, row by row.</h2><p>Each square depicts \(t(0,r)=1\). Blue tags carry formula values, purple tags ordered reference offsets. Gold rows belong to both clusters and contribute occupancy once. Neither points nor lines in the statement are drawn geometrically. The coordinates belong to its proof encoding.</p><p><label><input id="formula-layer" type="checkbox" checked>Formula markings</label> <label><input id="reference-layer" type="checkbox" checked>Reference markings</label></p>'''
    content += '<p>The three hypotheses say that two distinct points lie on the first and second lines, the same points lie on the second and third lines, and another point lies on the first line. Hilbert line uniqueness and equality substitution yield that the last point lies on the third line. The final symbolic conclusion is ' + math(formula(example['placements'][-1]['command']['formula'])) + '.</p>'
    explanation = {'assumption': 'Given ordered hypothesis.', 'axiom': 'Use guarded line uniqueness.', 'instantiate': 'Instantiate the universal statement.', 'eq_subst': 'Use equality substitution.', 'mp': 'Use the two cited rows by modus ponens.'}
    for placement in example['placements']:
        row, command = placement['row'], placement['command']
        group = 'shared' if placement['id'] in first & second else 'first' if placement['id'] in first else 'second' if placement['id'] in second else 'seed'
        content += '<article class="proof-row ' + group + '" id="row-' + str(row) + '"><div class="tile">' + math(row) + '<small><code>' + command['rule'] + '</code></small></div><div><p class="row-formula">' + math(formula(command['formula'])) + '</p><p>' + explanation[command['rule']] + ' Sources: ' + (', '.join('<a href="#row-' + str(r) + '">' + math(r) + '</a>' for r in placement['ordered_inputs']) or 'none') + '.</p><p class="marks">'
        for x, y, value in placement['m']:
            content += '<span class="mark ' + ('formula-mark' if x == 1 else 'reference-mark') + '">' + math('m(' + str(x) + ',' + str(y) + ')=' + str(value)) + '</span>'
        compact = {k: placement[k] for k in ('id', 'row', 'command', 'ordered_inputs', 't', 'm')}
        content += '</p><details><summary>Exact symbolic command and point values</summary><pre>' + html.escape(json.dumps(compact, indent=2)) + '</pre></details></div></article>'
    content += '</section>'
    content += r'''<section class="panel" id="assessment"><h2>What parallel work contributes.</h2><p>It gives us separate experiments and independent implementation checks. We now have actual RL updates and proof-search action changes. An advantage in proof finding still requires stronger results under matched controls and total costs; a changed order or higher partial return is insufficient. This experiment addresses one arithmetic instance, with only two evaluation seeds per policy.</p><p>The six producer evaluations report no proof gain and the same peak of \(45\) satisfied obligations. The full evaluation audit hit its memory gate, so the comparative results remain provisional. The geometry work makes exact lemma reuse concrete and inspectable, but does not yet execute the new primitive inventory as a search engine. The next decisions are driven by the observed failures: repair memory use in evaluation replay without changing its mathematical checks, construct a complete implicit primitive graph for geometry, and keep checking separate from proposal selection. Turtle and Penrose remain controls in the broader program.</p><p><a href="sources-and-inputs.zip">Exact executable sources and direct mathematical inputs</a> · <a href="source-input-bindings.json">Exact source and input bindings</a> · <a href="origins.json">Published file origins</a> · <a href="../parallel-progress/reader.html">Previous diagnoses and native result</a> · <a href="../#goals">Active research goals</a></p><p class="small">Earlier preservation-only history is retained in the preceding notebooks. The source/input ZIP and individually published files jointly provide this experiment’s complete exact bindings and actual traces. Missing proof, resource failures and unfinished correspondence are preserved explicitly.</p></section>'''
    header = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GCTS stochastic clusters · actual learning and primitive geometry</title><link rel="stylesheet" href="../report.css"><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script><style>main{max-width:1200px}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin:24px 0}.cards>div{background:#edf2e8;padding:20px;border-radius:8px;font-size:14px}.cards strong{display:block;font-size:29px;margin-bottom:10px}.rewardchart{padding:20px;background:#eff3eb;border-radius:8px}.barrow{display:grid;grid-template-columns:30px 1fr 70px;gap:15px;align-items:center;margin:12px 0}.track{background:#dde5d7;height:18px;border-radius:3px}.bar{background:#52785d;height:100%;border-radius:3px}.proof-row{display:grid;grid-template-columns:75px minmax(0,1fr);gap:18px;padding:18px;margin:9px 0;border-radius:8px}.first{background:#edf4fe}.second{background:#f0ebfb}.shared{background:#fff1d4}.seed{background:#eff2f3}.tile{height:75px;background:white;border:2px solid #637364;display:flex;flex-direction:column;align-items:center;justify-content:center}.tile small{font-size:10px}.row-formula{overflow:auto}.marks{display:flex;flex-wrap:wrap;gap:6px}.mark{padding:5px 8px;font-size:12px;border-radius:5px}.formula-mark{background:#d7e9ff;color:#173b78}.reference-mark{background:#e6d9ff;color:#503180}.hide-formulas .formula-mark,.hide-references .reference-mark{display:none}pre{max-height:300px;overflow:auto}.note{padding:18px;border-left:4px solid #a57334;background:#fff4e3}h2{scroll-margin-top:20px}label{margin-right:18px}td{font-size:13px}@media(max-width:650px){.cards{grid-template-columns:1fr}.proof-row{grid-template-columns:55px minmax(0,1fr);padding:10px;gap:10px}.tile{height:55px}.barrow{grid-template-columns:25px 1fr 60px}}</style></head><body><header class="masthead"><a href="../#stochastic-clusters">Research report</a><span>NOTEBOOKS 100–102</span><a href="#assessment">Assessment</a></header><main>'''
    tail = '''</main><script>for(const [id,cls] of [['formula-layer','hide-formulas'],['reference-layer','hide-references']])document.getElementById(id).addEventListener('change',e=>document.getElementById('reader').classList.toggle(cls,!e.target.checked));</script></body></html>'''
    target = DEST / 'reader.html'
    target.write_text(header + content + tail)
    files.add(str(target.relative_to(ROOT)))
    index = DOC / 'index.html'
    original = index.read_text()
    if original.count('id="stochastic-clusters"') == 1:
        original = re.sub(r'<section class="panel" id="stochastic-clusters">.*?</section>\n\n', '', original, count=1, flags=re.S)
        original = original.replace('RESEARCH NOTEBOOK · 102', 'RESEARCH NOTEBOOK · 99', 1)
        baseline = Path('/private/tmp/gcts-family-router-publish-20261010/docs/research/gcts-rl-renewal/index.html')
        assert original == baseline.read_text(), 'refresh would overwrite unrelated notebook changes'
    assert original.count('id="stochastic-clusters"') == 0
    panel = r'''<section class="panel" id="stochastic-clusters"><p class="eyebrow">NOTEBOOKS 100–102 · THREE PARALLEL TRACKS</p><h2>Actual stochastic cluster learning and checked primitive geometry.</h2><p>The new arithmetic policy changes \(18\) actually visited first moves in its pilot. Eight fresh engine-generated training episodes and every learned update pass independent replay. The matched evaluation compares baseline, untrained stochastic and trained selection on the same complete thirteen-row target. Every unresolved or failed result remains visible.</p><p>The geometry track expands \(171\) source definitions into \(1845\) primitive leaf occurrences and a \(229\)-recipe inventory. Its independent logical and point audit is separate from search discovery and native/compiler correspondence. The reader shows the exact shared primitive rows and their colored formula/reference markings.</p><p><a class="button" href="stochastic-clusters/reader.html#arithmetic">Read the new parallel results</a> <a href="stochastic-clusters/reader.html#reader">Inspect primitive geometry rows</a></p></section>'''
    original = original.replace('RESEARCH NOTEBOOK · 99', 'RESEARCH NOTEBOOK · 102', 1)
    original = original.replace('  <section class="panel" id="parallel-progress">', panel + '\n\n  <section class="panel" id="parallel-progress">', 1)
    index.write_text(original)
    files.add(str(index.relative_to(ROOT)))
    manifest = dict(status='prepared_terminal_evidence_pending_publication', previous_commit='4d19cb3dad76e2b09b0889e875c6fb993e152a41',
                    files=[dict(path=p, sha256=digest(ROOT / p), bytes=(ROOT / p).stat().st_size) for p in sorted(files)],
                    scope='Actual same-instance RL with exact graphs, independent update replay and matched outcome evidence; independent static symbolic primitive geometry. No new native query or infinite tiling result.')
    manifest['total_bytes'] = sum(x['bytes'] for x in manifest['files'])
    (HERE / 'publication-files.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(status=manifest['status'], files=len(files), bytes=manifest['total_bytes'], evaluation_passed=eval_pass, geometry_passed=geometry_pass)))


if __name__ == '__main__':
    main()
