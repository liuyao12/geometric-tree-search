"""Fresh lifetime owner for each authorized observation and bounded dispatcher."""
import argparse
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time
from pathlib import Path
from native_certificate_stage import processes, descendants, kill_verified

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'
OUT = BASE/'execution-v2'
PLAN_PATH = BASE/'experiment-plan-v2.json'


def preparation(phase):
    plan_path = PLAN_PATH
    plan = json.loads(plan_path.read_text())
    activation = json.loads((OUT/'activation.json').read_text())
    if activation['status'] != 'authorized_by_root_after_independent_review' or activation['plan_sha256'] != hashlib.sha256(plan_path.read_bytes()).hexdigest() or phase not in activation['approved_phases']:
        raise ValueError('independent root activation required')
    for path, digest in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != digest:
            raise ValueError('owner frozen input '+path)
    required = {'effect': [], 'training': ['effect/independent-audit.json'],
                'evaluation': ['training/independent-audit.json', 'training/policy-final.json']}[phase]
    pins = activation['prerequisite_sha256'].get(phase, {})
    for name in required:
        path = OUT/name;relative = str(path.relative_to(ROOT))
        if relative not in pins or hashlib.sha256(path.read_bytes()).hexdigest() != pins[relative]:
            raise ValueError('owner exact prerequisite '+relative)
    for path, digest in pins.items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != digest:
            raise ValueError('owner root frozen prerequisite '+path)
    return plan


def own(name):
    entire = time.perf_counter()
    raw_plan = json.loads((PLAN_PATH).read_text())
    job = next(job for job in raw_plan['observations'] if job['id'] == name)
    plan = preparation(job['phase'])
    # Capability must be resolved before there is a live worker to clean up.
    processes()
    folder = OUT/job['phase'];folder.mkdir(exist_ok=True)
    if any(folder.glob(name+'-*')):
        raise ValueError('single-execution owner refuses existing job artifacts '+name)
    with (folder/(name+'-stdout.txt')).open('wb') as stdout, (folder/(name+'-stderr.txt')).open('wb') as stderr:
        began = time.perf_counter()
        child = subprocess.Popen([sys.executable, str(ROOT/'research/gcts-rl-renewal/arithmetic_stochastic_worker_v3.py'), '--job', name],
                                 cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
        identities, samples = {}, []
        sampler_peak = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        violation = None;signalled = None;status = None;usage = None;error = None;forced = False
        try:
            while True:
                waited, raw_status, usage = os.wait4(child.pid, os.WNOHANG)
                if waited:
                    status = os.waitstatus_to_exitcode(raw_status);child.returncode = status;break
                now = time.perf_counter()
                rows = processes()
                sampler_peak = max(sampler_peak, resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
                live = descendants(rows, child.pid)
                for row in live:
                    identities[row[0]] = row[4]
                resident = sum(row[3]*1024 for row in descendants(rows, os.getpid()))
                samples.append(dict(seconds=now-began, rss_bytes=resident, pids=[row[0] for row in live]))
                if violation is None and (now-began > job['lifecycle_seconds'] or resident > plan['rss_bytes']):
                    violation = 'wall' if now-began > job['lifecycle_seconds'] else 'memory'
                    try:os.kill(child.pid, signal.SIGUSR1)
                    except ProcessLookupError:pass
                    signalled = now
                if signalled is not None and now-signalled > 5:
                    forced = True;kill_verified(identities, child.pid)
                time.sleep(.2)
        except Exception as exc:
            error = type(exc).__name__+': '+str(exc);violation = violation or 'observation_failure'
        finally:
            if status is None:
                try:os.kill(child.pid, signal.SIGUSR1)
                except ProcessLookupError:pass
                until = time.perf_counter()+5
                while time.perf_counter() < until:
                    waited, raw_status, usage = os.wait4(child.pid, os.WNOHANG)
                    if waited:
                        status = os.waitstatus_to_exitcode(raw_status);child.returncode = status;break
                    time.sleep(.1)
                if status is None:
                    forced = True
                    try:kill_verified(identities, child.pid)
                    except Exception as exc:
                        error = (error or '')+'; cleanup '+str(exc)
                        try:os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:pass
                    _, raw_status, usage = os.wait4(child.pid, 0)
                    status = os.waitstatus_to_exitcode(raw_status);child.returncode = status
    lifetime = time.perf_counter()-began
    leftovers = None;cleaned = []
    try:
        rows = processes()
        leftovers = [row[0] for row in rows if row[0] != child.pid and identities.get(row[0]) == row[4]]
        if leftovers:
            cleaned = leftovers[:];kill_verified(identities, child.pid, grow=False)
            rows = processes()
            leftovers = [row[0] for row in rows if row[0] != child.pid and identities.get(row[0]) == row[4]]
    except Exception as exc:
        error = (error or '')+'; final observation '+str(exc)
    summary_path = folder/(name+'-summary.json')
    summary = None
    try:
        summary = json.loads(summary_path.read_text()) if summary_path.exists() else None
        if summary is not None and not isinstance(summary, dict):
            raise ValueError('worker receipt must be an object')
    except (ValueError, OSError) as exc:
        error = (error or '')+'; malformed worker receipt '+type(exc).__name__+': '+str(exc)
    own_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    conservative = own_peak+sampler_peak+usage.ru_maxrss
    passed = (status == 0 and summary is not None and summary.get('status') == 'complete_observation_pending_independent_audit'
              and not violation and not error and not forced and not cleaned and leftovers == []
              and lifetime <= job['lifecycle_seconds'] and conservative <= plan['rss_bytes']
              and summary.get('lifecycle_wall_overshoot_seconds') == 0 and summary.get('memory_overshoot_bytes') == 0)
    result = dict(id=name, status='passed_complete_observation_lifetime_gate' if passed else 'unknown_observation_lifetime_gate',
                  worker_exit_code=status, worker_terminal_and_reaped=True, worker_lifetime_seconds=lifetime,
                  owner_seconds_before_final_receipt_write=time.perf_counter()-entire,
                  kernel_owner_peak_bytes=own_peak, kernel_sampler_peak_before_worker_reaping_bytes=sampler_peak,
                  kernel_worker_peak_bytes=usage.ru_maxrss, conservative_peak_bytes=conservative,
                  sampled_peak_bytes=max((sample['rss_bytes'] for sample in samples), default=0), samples=samples,
                  watchdog_violation=violation, observer_error=error, forced_kill=forced,
                  cleaned_orphans=cleaned, remaining_owned_pids=leftovers,
                  wall_overshoot_seconds=max(0, lifetime-job['lifecycle_seconds']),
                  memory_overshoot_bytes=max(0, conservative-plan['rss_bytes']),
                  summary_sha256=hashlib.sha256(summary_path.read_bytes()).hexdigest() if summary else None,
                  enforcement='Bounded ps snapshots, fresh owned worker, SIGUSR1 cleanup grace, verified PID/birth cleanup, kernel and aggregate RSS retrospective gates. No hard OS memory cap.')
    (folder/(name+'-lifetime.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key != 'samples'}), flush=True)
    if not passed:
        raise SystemExit(2)


def phase(name):
    began = time.perf_counter()
    plan = preparation(name)
    jobs = [job for job in plan['observations'] if job['phase'] == name]
    folder = OUT/name;folder.mkdir(exist_ok=True)
    if (folder/'phase-summary.json').exists():
        raise ValueError('single-execution phase refuses existing receipt '+name)
    result = dict(status='running_phase', phase=name, observations=[], attempted=[], failed_jobs=[], unexecuted=[job['id'] for job in jobs], native_queries=0)
    for job in jobs:
        remaining = plan['phase_seconds'][name]-(time.perf_counter()-began)
        if remaining < job['lifecycle_seconds']:
            result['status'] = 'unknown_phase_reservation_budget';break
        result['attempted'].append(job['id']);result['unexecuted'].remove(job['id'])
        child = subprocess.run([sys.executable, __file__, '--job', job['id']], cwd=ROOT)
        if child.returncode:
            result['failed_jobs'].append(dict(id=job['id'], owner_exit_code=child.returncode))
            result['status'] = 'unknown_or_failed_lifetime_gate';break
        receipt = json.loads((folder/(job['id']+'-lifetime.json')).read_text())
        result['observations'].append(receipt)
        (folder/'phase-summary.json').write_text(json.dumps(result, indent=2)+'\n')
    else:
        result['status'] = 'complete_phase_pending_independent_audit'
    seconds = time.perf_counter()-began
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    combined = peak+max((receipt['conservative_peak_bytes'] for receipt in result['observations']), default=0)
    result.update(seconds_before_final_phase_receipt_write=seconds, dispatcher_peak_bytes=peak,
                  conservative_dispatcher_plus_observation_peak_bytes=combined,
                  wall_overshoot_seconds=max(0, seconds-plan['phase_seconds'][name]),
                  memory_overshoot_bytes=max(0, combined-plan['rss_bytes']))
    if result['wall_overshoot_seconds'] or result['memory_overshoot_bytes']:
        result['status'] = 'unknown_phase_resource_budget'
    (folder/'phase-summary.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key != 'observations'}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser();parser.add_argument('--job');parser.add_argument('--phase', choices=('effect', 'training', 'evaluation'))
    args = parser.parse_args()
    if bool(args.job) == bool(args.phase):
        raise ValueError('one owner job or phase')
    if args.job:own(args.job)
    else:phase(args.phase)
