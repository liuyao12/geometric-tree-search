"""Source-bound, graph-neighborhood features and epsilon-mixture REINFORCE.

Only ordering preferences are learned. No marking, graph degree, candidate
legality, theorem witness or induction-variable label is supplied by policy.
"""
import collections
import hashlib
import json
import math
from commutativity13_guidance import vectors as legacy_vectors

EPSILON = .1
TEMPERATURE = 1.
LEARNING_RATE = .2
BASELINE_DECAY = .9
GRADIENT_NORM_LIMIT = 1.
WEIGHT_LIMIT = 4.
LEGACY = ('family', 'base_growth', 'novel_formula', 'justified_inputs',
          'target_output', 'mark_extension', 'shape_density', 'complete_rows', 'defer')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def formula_pin(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def binding_features(item, metadata, rules, point):
    """Translation-relative semantic receptor tokens; no absolute source IDs.

    Within an item, each occupied row/role is unique. Relative row, role and
    relative source therefore distinguish alternate attachments to that port.
    Premise/formula tokens are shared AST identities, not correct-action labels.
    """
    if item is None:
        return {}
    anchor_row = point[0] // 4
    result = {}
    for raw in item['members']:
        key = tuple(raw)
        slot, role = key[:2]
        meta = metadata[key]
        relative = slot - anchor_row
        if role >= 2:
            source = meta['source']
            delta = 'unused' if source is None else str(source-slot)
            premise = meta['requirements'][0][1] if meta['requirements'] else None
            token = 'port:%d:%d:%s:%s' % (relative, role-2, delta, formula_pin(premise))
            result[token] = 1.
        if role < 2:
            result['command:%d:%d:%s' % (relative, role, formula_pin(meta['command']))] = 1.
        if role == 1:
            rule = rules[meta['inference']]
            token = 'guard:%d:%s:%s' % (relative, rule['description']['operation'], formula_pin(meta['command']['formula']))
            result[token] = 1.
    return result


class FeatureIndex:
    """Complete marking-support indexes; construction and queries are charged."""
    def __init__(self, model):
        self.model = model
        self.at_point = collections.defaultdict(set)
        self.by_value = collections.defaultdict(set)
        for key, tile in model.cache.items():
            for point, value in tile.marks:
                self.at_point[point].add(key)
                self.by_value[point, value].add(key)
        self.static_membership_count = sum(map(len, self.at_point.values()))

    def vectors(self, items, state, graph, point):
        model = self.model
        old = legacy_vectors(items, model, state, graph)
        legal_keys = set(graph.edges)
        selected_roles = {(key[0], key[1]) for key in state.selected}
        roots = len(state.roots)
        features, work = [], collections.Counter()
        for item, previous in zip(items, old):
            current = {'legacy:'+name: float(value) for name, value in zip(LEGACY, previous)}
            if item is None:
                features.append(dict(sorted(current.items())))
                continue
            current.update(binding_features(item, model.metadata, model.rules, point))
            current['pending_fraction'] = len(item['pending']) / max(1, len(item['members']))
            current['landing_degree_fraction'] = len(graph.domains[point]) / max(1, len(model.align_cache[point]))
            sources = []
            for key in item['members']:
                meta = model.metadata[key]
                if key[1] < 2 or meta['source'] is None:
                    continue
                source = meta['source']
                # The input tile explicitly carries the expected source formula
                # at the extended mark-only point. Zero is an assigned value.
                formula_point = (4*source+2, 0)
                expected = dict(model.cache[key].marks)[formula_point]
                occupied = sum((source, role) in selected_roles for role in range(4))/4
                assigned = float(formula_point in state.marks)
                agreed = float(formula_point in state.marks and state.marks[formula_point] == expected)
                degrees = [len(graph.domains.get((4*source, role), ())) / max(1, len(model.align_cache[(4*source, role)])) for role in range(4)]
                sources.append([occupied, assigned, agreed]+degrees)
                work['source_port_queries'] += 1
            names = ('source_occupied_roles', 'source_formula_assigned', 'source_formula_agrees',
                     'source_C_domain', 'source_G_domain', 'source_I1_domain', 'source_I2_domain')
            for i, name in enumerate(names):
                current[name] = sum(values[i] for values in sources) / max(1, len(sources))
            marks = {}
            for key in item['pending']:
                for q, value in model.cache[key].marks:
                    if q in marks and marks[q] != value:
                        raise ValueError('policy received incompatible aggregate')
                    marks[q] = value
            conflicting, agreeing, remote = set(), set(), 0
            for q, value in sorted(marks.items()):
                work['mark_neighborhood_queries'] += 1
                remote += int(q not in state.roots)
                support = self.at_point.get(q, set())
                same = self.by_value.get((q, value), set())
                work['mark_dependency_memberships_examined'] += len(support)
                agreeing.update(same & legal_keys)
                if q not in state.marks:
                    conflicting.update((support-same) & legal_keys)
            touched_roots = {q for key in conflicting for q in graph.edges[key]}
            current.update(mark_conflicting_candidate_fraction=len(conflicting)/max(1, len(legal_keys)),
                           mark_agreeing_candidate_fraction=len(agreeing)/max(1, len(legal_keys)),
                           mark_impacted_frontier_fraction=len(touched_roots)/max(1, roots),
                           mark_remote_support_fraction=remote/max(1, len(marks)),
                           mark_already_assigned_fraction=sum(q in state.marks for q in marks)/max(1, len(marks)))
            features.append(dict(sorted(current.items())))
        return features, dict(work)


def distribution(features, weights, epsilon=EPSILON, temperature=TEMPERATURE):
    if not features or not 0 <= epsilon <= 1 or temperature <= 0:
        raise ValueError('declared stochastic mixture')
    scores = [sum(weights.get(key, 0.)*value for key, value in vector.items())/temperature for vector in features]
    maximum = max(scores)
    exponentials = [math.exp(score-maximum) for score in scores]
    total = sum(exponentials)
    soft = [value/total for value in exponentials]
    probability = [(1-epsilon)*value+epsilon/len(features) for value in soft]
    return scores, soft, probability


def choose(items, features, weights, rng):
    scores, soft, probability = distribution(features, weights)
    uniform, cumulative, index = rng.random(), 0., len(items)-1
    for i, value in enumerate(probability):
        cumulative += value
        if uniform < cumulative:
            index = i
            break
    return items[index], dict(index=index, features=features, scores=scores,
                             softmax_probabilities=soft, probabilities=probability,
                             uniform=uniform, epsilon=EPSILON, temperature=TEMPERATURE)


def event_gradient(event):
    features = event['features']
    selected = event['index']
    soft, probability = event['softmax_probabilities'], event['probabilities']
    expected = collections.defaultdict(float)
    for p, vector in zip(soft, features):
        for key, value in vector.items():
            expected[key] += p*value
    factor = (1-event['epsilon'])*soft[selected]/probability[selected]/event['temperature']
    chosen = features[selected]
    return {key: factor*(chosen.get(key, 0.)-expected.get(key, 0.)) for key in sorted(chosen.keys() | expected.keys())}


def episode_return(metrics):
    """Finite, observed growth/effort return, including unknown-budget episodes.

    Peak satisfied obligations are checked from exact t-values at every node.
    No bonus for macro count, target theorem labels or native acceptance.
    """
    attempts = max(1, metrics.get('attempts', 0))
    return (metrics.get('max_satisfied_points', 0)/52
            - .5*metrics.get('dead', 0)/attempts
            - .25*metrics.get('backtracks', 0)/attempts
            - .1*metrics.get('branch', 0)/attempts
            - .05*(metrics.get('validation_checks', 0)+metrics.get('sample_pair_tests', 0))/(2048*attempts))


def update(weights, events, value, baseline):
    gradient = collections.defaultdict(float)
    for event in events:
        for key, entry in event_gradient(event).items():
            gradient[key] += entry/max(1, len(events))
    advantage = value-baseline
    score_norm = math.sqrt(sum(value*value for value in gradient.values()))
    update_gradient = {key: advantage*entry for key, entry in gradient.items()}
    norm = math.sqrt(sum(entry*entry for entry in update_gradient.values()))
    scale = min(1., GRADIENT_NORM_LIMIT/max(norm, 1e-300))
    result = dict(weights)
    for key in sorted(gradient):
        result[key] = max(-WEIGHT_LIMIT, min(WEIGHT_LIMIT, weights.get(key, 0.)+LEARNING_RATE*scale*update_gradient[key]))
    result = dict(sorted(result.items()))
    return result, BASELINE_DECAY*baseline+(1-BASELINE_DECAY)*value, dict(
        reward=value, baseline_before=baseline, advantage=advantage,
        mean_score_gradient=dict(sorted(gradient.items())), mean_score_gradient_norm=score_norm,
        advantage_scaled_gradient=dict(sorted(update_gradient.items())),
        advantage_scaled_gradient_norm=norm, applied_gradient_scale=scale,
        clipped_update_gradient_norm=norm*scale,
        weights_after_sha256=hashlib.sha256(canonical(result)).hexdigest())
