"""Generic arity-aware fixed proposals, exact aggregates, complete base fallback.

Proof-backed two-row receptors and ordinary rows are merely proposal generators.
Bounded arbitrary shapes remain eligible. No RL training or learned restriction.
"""
import collections
import hashlib
import itertools
from certificate_boundary_search import canonical
from commutativity_catalog import motif_families
from commutativity_points import row_keys
from native_inference_inventory import aggregate

FEATURES = ('promoted_certificate_member', 'new_occupancy_rows', 'new_output_formula',
            'justified_source_fraction', 'target_output', 'new_mark_assignments_per_1000',
            'row_density', 'completed_row_fraction', 'defer')
FIXED = (.7, .3, 1., .8, .2, -.1, .2, .2, 0.)


def row_requirements(model, keys, row):
    by = {k[1]: k for k in keys if k[0] == row}
    if set(by) != {0, 1, 2, 3}:
        return None
    c, g = model.metadata[by[0]], model.metadata[by[1]]
    if c['inference'] != g['inference'] or c['command'] != g['command']:
        return None
    r = model.rules[c['inference']]
    refs = []
    for role in range(2):
        m = model.metadata[by[2 + role]]
        if m['mode'] != model.rule_modes[c['inference']]:
            return None
        if role < len(r['premises']):
            if m['source'] is None or not 0 <= m['source'] < row:
                return None
            refs.append((m['source'], r['premises'][role]))
        elif m['source'] is not None:
            return None
    return refs


def known_rows(model, state):
    known, facts = set(), set()
    for row in range(model.spec['length']):
        refs = row_requirements(model, state.selected, row)
        if refs is not None and all(source in known for source, formula in refs):
            known.add(row)
            guard = next(k for k in state.selected if k[0] == row and k[1] == 1)
            facts.add(canonical(model.metadata[guard]['command']['formula']))
    return known, facts


def vector(item, model, state, graph):
    if item is None:
        return [0.] * 8 + [1.]
    known, facts = known_rows(model, state)
    slots = {k[0] for k in item['members']}
    guards = [model.metadata[k] for k in item['members'] if k[1] == 1]
    refs = [pair for row in slots for pair in (row_requirements(model, list(state.selected) + item['members'], row) or [])]
    if not refs:
        refs = [pair for k in item['members'] for pair in model.metadata[k]['requirements']]
    complete = sum(row_requirements(model, item['members'], row) is not None for row in slots)
    return [float(any(g['inference'] in model.promoted_rules for g in guards)),
            item['new_occupancy'] / 48,
            float(any(canonical(g['command']['formula']) not in facts for g in guards)),
            sum(source in known for source, formula in refs) / max(1, len(refs)),
            float(any(g['command']['formula'] == model.spec['target'] for g in guards)),
            item['new_marks'] / 1000,
            len(slots) / (max(slots) - min(slots) + 1), complete / max(1, len(slots)), 0.]


class Join:
    def __init__(self, model, enable_lemmas=True):
        self.model = model
        self.families = motif_families(model.compiled) if enable_lemmas else []
        self.guard_by_rule = {(k[0], m['inference']): k for k, m in model.metadata.items() if k[1] == 1}

    def __call__(self, state, graph, point, limit=24, checks=2048):
        model, pool, seen, work = self.model, [], set(), collections.Counter()
        anchors = sorted(graph.domains[point])

        def save(kind, members):
            if work['validation_checks'] >= checks or len(pool) >= limit:
                return
            work['validation_checks'] += 1
            item = aggregate(model, members, state)
            if item is None or not any(k in graph.domains[point] for k in item['pending']):
                return
            key = tuple(item['members'])
            if key in seen:
                return
            seen.add(key)
            item.update(kind=kind, level=0)
            pool.append(item)

        # Complete family parameter domain; bounded runtime proposal prefix.
        # Its bounds never remove any candidate from the shared base graph.
        for family in self.families:
            for j in range(model.spec['length']):
                if (j, family['rewrite_rule']) not in self.guard_by_rule:
                    continue
                for k in range(j):
                    for source in range(j):
                        if source == k:
                            continue
                        members = row_keys(model, k, family['root_rule'], []) + row_keys(model, j, family['rewrite_rule'], [source, k])
                        if not any(anchor in members for anchor in anchors):
                            continue
                        save('promoted-family', members)
                        if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                            break
                    if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                        break
                if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                    break
            if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                break
        work['family_pool'] = len(pool)
        # All rule kinds use their actual mode/arity, including zero-input
        # theorem blocks and unary primitive generalization.
        occupied = {model.placement(k).occupancy[0][0]: k for k in state.selected}
        for anchor in anchors[:4]:
            j = anchor[0]
            for (row, rule), guard in sorted(self.guard_by_rule.items()):
                if row != j:
                    continue
                pair = [(j, 0, guard[2], 0), guard]
                if anchor[1] < 2 and anchor not in pair:
                    continue
                if any(k not in state.selected and not state.legal(model.placement(k)) for k in pair):
                    continue
                mode = model.rule_modes[rule]
                candidates = []
                for role in (2, 3):
                    at = (4 * j, role)
                    keys = [occupied[at]] if at in occupied else model.align_cache[at]
                    keys = [key for key in keys if model.metadata[key]['mode'] == mode and (key in state.selected or state.legal(model.placement(key))) and (anchor[1] != role or key == anchor)]
                    candidates.append(keys)
                for a, b in itertools.product(*candidates):
                    save('complete-row', pair + [a, b])
                    if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
                        break
                if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
                    break
            if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
                break
        work['row_pool'] = len(pool) - work['family_pool']
        legal = sorted({key for keys in graph.domains.values() for key in keys})
        for anchor in anchors[:4]:
            save('open-shape', [anchor])
            members = [anchor]
            ranked = sorted(legal, key=lambda key: (hashlib.sha256(canonical([anchor, key])).digest(), key))
            for key in ranked:
                if key in members:
                    continue
                if work['sample_pair_tests'] >= 64:
                    break
                work['sample_pair_tests'] += 1
                if aggregate(model, members + [key], state, record=False):
                    members.append(key)
                if len(members) == 3:
                    break
            if len(members) > 1:
                save('open-shape', members)
            if work['validation_checks'] >= checks or len(pool) >= limit:
                break
        work['items'] = len(pool)
        # Concrete proposals precede defer on equal fixed scores.
        return pool + [None], dict(work)
