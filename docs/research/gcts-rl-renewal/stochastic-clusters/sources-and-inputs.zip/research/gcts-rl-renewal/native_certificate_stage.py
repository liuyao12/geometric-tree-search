"""External lifetime observer for this task's one producer or replay worker."""
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'.gcts-active/hierarchical-native-20261011'


def processes():
    text=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,pgid=,rss=,lstart='],text=True,timeout=2)
    rows=[]
    for line in text.splitlines():
        fields=line.split(None,4)
        if len(fields)==5:rows.append((*map(int,fields[:4]),fields[4]))
    return rows


def descendants(rows,leader):
    owned={leader}
    while True:
        expanded=owned|{row[0] for row in rows if row[1] in owned}
        if expanded==owned:return [row for row in rows if row[0] in owned]
        owned=expanded


def kill_verified(identities,leader,grow=True):
    # Never signal historical process groups: PIDs/groups can be reused.
    # Each non-leader victim must still have its observed birth identity.
    rows=processes()
    if grow:
        live=descendants(rows,leader)
        for row in live:identities[row[0]]=row[4]
    for row in sorted(rows,key=lambda row:row[0]==leader):
        if identities.get(row[0])==row[4]:
            try:os.kill(row[0],signal.SIGKILL)
            except ProcessLookupError:pass


def main():
    mode=sys.argv[1]
    if mode not in ('produce','audit'):raise ValueError('declared stage')
    plan_path=OUT/('plan.json' if mode=='produce' else 'audit-plan.json')
    plan=json.loads(plan_path.read_text())
    # Verify the observer and worker bindings before creating a child.
    for name,pin in {**plan['source_sha256'],**plan['input_sha256']}.items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=pin:raise ValueError('observer frozen binding '+name)
    preflight_start=time.perf_counter();processes();preflight_seconds=time.perf_counter()-preflight_start
    stdout=(OUT/(mode+'-worker-stdout.txt')).open('wb')
    stderr=(OUT/(mode+'-worker-stderr.txt')).open('wb')
    start=time.perf_counter()
    child=subprocess.Popen([sys.executable,str(ROOT/plan['worker'])],cwd=ROOT,stdout=stdout,stderr=stderr,start_new_session=True)
    (OUT/(mode+'-owner.json')).write_text(json.dumps({'pid':child.pid,'mode':mode,'plan_sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest()})+'\n')
    samples=[];identities={};sampler_peak=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss;violation=None;signalled=None;hard_kill=False;status=None;usage=None;next_log=0;observer_error=None
    try:
        while True:
            waited,raw_status,rusage=os.wait4(child.pid,os.WNOHANG)
            if waited:
                status=os.waitstatus_to_exitcode(raw_status);usage=rusage;child.returncode=status;break
            now=time.perf_counter();rows=processes();live=descendants(rows,child.pid)
            sampler_peak=max(sampler_peak,resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
            resident=sum(row[3]*1024 for row in descendants(rows,os.getpid()))
            for row in live:identities[row[0]]=row[4]
            samples.append({'seconds':now-start,'rss_bytes':resident,'pids':[row[0] for row in live]})
            if violation is None and (now-start>plan['ceilings']['phase_seconds'] or resident>plan['ceilings']['rss_bytes']):
                violation='wall' if now-start>plan['ceilings']['phase_seconds'] else 'aggregate_rss'
                try:os.kill(child.pid,signal.SIGUSR1)
                except ProcessLookupError:pass
                signalled=now
            if signalled is not None and now-signalled>5:
                hard_kill=True
                kill_verified(identities,child.pid)
            if now-start>=next_log:
                print(json.dumps({'stage':mode,'worker_pid':child.pid,'live_seconds':round(now-start,3),'sampled_aggregate_rss_bytes':resident,'watchdog_violation':violation}),flush=True)
                next_log+=20
            time.sleep(.2)
    except Exception as exc:
        observer_error=type(exc).__name__+': '+str(exc)
        violation=violation or 'observation_failure'
    finally:
        if status is None:
            # Give the worker's own unconditional cleanup a bounded opportunity.
            try:os.kill(child.pid,signal.SIGUSR1)
            except ProcessLookupError:pass
            cleanup_start=time.perf_counter()
            while time.perf_counter()-cleanup_start<5:
                waited,raw_status,usage=os.wait4(child.pid,os.WNOHANG)
                if waited:
                    status=os.waitstatus_to_exitcode(raw_status);child.returncode=status;break
                time.sleep(.1)
            if status is None:
                hard_kill=True
                try:kill_verified(identities,child.pid)
                except Exception as exc:
                    observer_error=(observer_error or '')+'; cleanup observation: '+str(exc)
                    # Its un-reaped child leader cannot have a reused PID/session.
                    try:os.killpg(child.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                _,raw_status,usage=os.wait4(child.pid,0);status=os.waitstatus_to_exitcode(raw_status);child.returncode=status
        stdout.close();stderr.close()
    elapsed=time.perf_counter()-start
    leftovers=None;cleaned_orphans=[]
    try:
        rows=processes();leftovers=[row[0] for row in rows if row[0]!=child.pid and identities.get(row[0])==row[4]]
        if leftovers:
            cleaned_orphans=list(leftovers);kill_verified(identities,child.pid,grow=False)
            time.sleep(.1)
            rows=processes();leftovers=[row[0] for row in rows if row[0]!=child.pid and identities.get(row[0])==row[4]]
    except Exception as exc:
        observer_error=(observer_error or '')+'; final observation: '+str(exc)
    inner_path=OUT/('summary.json' if mode=='produce' else 'audit.json')
    inner=json.loads(inner_path.read_text()) if inner_path.exists() else None
    own_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    worker_peak=usage.ru_maxrss
    descendant_peak=inner.get('kernel_waited_children_peak_bytes',0) if inner else 0
    conservative=own_peak+worker_peak+descendant_peak+sampler_peak
    stage_ok=(status==0 and inner is not None and not violation and not observer_error and not hard_kill and leftovers==[] and not cleaned_orphans and elapsed<=plan['ceilings']['phase_seconds'] and conservative<=plan['ceilings']['rss_bytes'] and inner.get('all_direct_children_terminal_and_reaped') is True and not inner.get('wall_overshoot_seconds') and not inner.get('memory_overshoot_bytes'))
    receipt={'status':'passed_complete_worker_lifetime_resource_gate' if stage_ok else 'unknown_worker_lifetime_resource_gate',
             'mode':mode,'plan_sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),'worker_pid':child.pid,
             'worker_exit_code':status,'worker_terminal_and_reaped':True,'owned_descendant_pids':sorted(identities),
             'remaining_owned_pids':leftovers,'observer_error':observer_error,'observer_cleaned_orphan_pids':cleaned_orphans,'preflight_process_capability_seconds':preflight_seconds,'worker_lifetime_seconds_including_imports_and_final_receipt_write':elapsed,
             'supervisor_seconds_before_final_receipt_write':time.perf_counter()-start,
             'kernel_supervisor_peak_bytes':own_peak,'kernel_sampler_peak_before_worker_reaping_bytes':sampler_peak,'kernel_worker_peak_bytes':worker_peak,
             'kernel_waited_worker_children_peak_bytes':descendant_peak,'conservative_total_peak_bytes':conservative,
             'sampled_total_peak_bytes':max((s['rss_bytes'] for s in samples),default=0),'watchdog_violation':violation,
             'forced_verified_pid_kill':hard_kill,'process_ownership':'Observed PID plus lstart birth identity; no historical process group signaling.','worker_receipt_sha256':hashlib.sha256(inner_path.read_bytes()).hexdigest() if inner else None,
             'samples':samples,'observer_final_receipt_write':'Outside reported supervisor timer; worker receipt writes are included.',
             'memory_semantics':'Aggregate sampled RSS plus the conservative sum of supervisor, sampler, worker and waited worker-child kernel peaks. One serialized compile/query child at a time; no OS hard limit credited.'}
    (OUT/(mode+'-lifetime.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='samples'}),flush=True)
    if not stage_ok:raise SystemExit(2)


if __name__=='__main__':main()
