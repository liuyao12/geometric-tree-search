"""Freeze pure fixtures / prospective source-review plan; never runs an engine."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'
OLD = ROOT/'.gcts-active/commutativity13-20261011'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(fixture_only=False):
    OUT.mkdir(exist_ok=True)
    old = json.loads((OLD/'execution-freeze.json').read_text())
    sources = dict(old['source_sha256'])
    for name in ('arithmetic_stochastic_features.py', 'arithmetic_stochastic_search.py',
                 'arithmetic_stochastic_worker.py', 'arithmetic_stochastic_owner.py',
                 'arithmetic_stochastic_fixtures.py', 'arithmetic_stochastic_plan.py',
                 'native_certificate_stage.py', 'arithmetic_stochastic_fixtures_v2.py', 'arithmetic_stochastic_plan_v2.py'):
        path = ROOT/'research/gcts-rl-renewal'/name
        sources[str(path.relative_to(ROOT))] = sha(path)
    paths = [ROOT/'docs/basic-tiling-algorithm.md', OLD/'execution-freeze.json', OLD/'model13.json.gz',
             OLD/'binding13.json.gz', OLD/'tree-audit-stream.json',
             ROOT/'.gcts-active/commutativity-receptors-20261011/attempt-02/two-lemmas-retained-core.json.gz',
             ROOT/'.gcts-active/commutativity-receptors-20261011/native-complete/registry.json.gz',
             ROOT/'.gcts-active/commutativity-receptors-20261011/native-complete/registry-audit.json',
             ROOT/'docs/research/gcts-rl-renewal/parallel-progress/diagnostic/receipt.json',
             ROOT/'docs/research/gcts-rl-renewal/parallel-progress/diagnostic/fixed-r1-diagnostic.json']
    inputs = {str(path.relative_to(ROOT)): sha(path) for path in paths}
    assert inputs['docs/research/gcts-rl-renewal/parallel-progress/diagnostic/receipt.json'] == '1447f95f61e94a567dd080056761327ac9249efa2c39c9eab45832a9afdc9c9d'
    for path, pin in {**sources, **inputs}.items():
        assert sha(ROOT/path) == pin, path
    if fixture_only:
        plan = dict(status='prospectively_frozen_pure_fixtures_only', source_sha256=sources,
                    input_sha256=inputs, seconds=60, rss_bytes=536870912,
                    native_queries=0, training_episodes=0, target_searches=0,
                    permitted='Pure synthetic point/scheduler/rollback/math tests, token-only saved alias comparison, one saved decision-state reconstruction. Never call search or train a model.')
        name = 'fixture-plan-v2.json'
    else:
        fixture = json.loads((OUT/'fixtures-v2.json').read_text())
        assert fixture['status'] == 'passed_pure_scheduler_feature_math_and_saved_state_fixtures'
        for path in (OUT/'fixture-plan-v2.json', OUT/'fixtures-v2.json', OUT/'fixture-plan.json', OUT/'fixtures.json', OUT/'fixture-attempt-01-source.zip'):
            inputs[str(path.relative_to(ROOT))] = sha(path)
        case = dict(old['case']);case['length'] = 13
        jobs = [dict(id='effect-pilot', phase='effect', mode='untrained', seed=16001,
                     attempts=500, search_seconds=10, lifecycle_seconds=60)]
        jobs += [dict(id='train-%02d' % episode, phase='training', mode='training', episode=episode,
                      seed=17000+episode, attempts=500, search_seconds=10, lifecycle_seconds=30)
                 for episode in range(1, 9)]
        for mode, rep in [('base', 1), ('untrained', 1), ('trained', 1), ('trained', 2), ('untrained', 2), ('base', 2)]:
            jobs.append(dict(id='%s-r%d' % (mode, rep), phase='evaluation', mode=mode,
                             seed=27000+rep, attempts=5000, search_seconds=60, lifecycle_seconds=100))
        plan = dict(status='frozen_prospective_stochastic_program_pending_root_source_review_and_activation',
            source_sha256=sources, input_sha256=inputs, case=case,
            complete_model_sha256='b131949034b0e396ab885a5a94b870f12d1443e2bdc5df0550963ec0e0698c11',
            complete_placements=19848, required_points=52, rules=153, native_admitted_definitions=94,
            model_scope='Unchanged full 13-row scalar point adaptation, complete formula-ID catalog and all induction/source alternatives. Not primitive square Wang occupancy.',
            proposal_semantics='Unchanged exact indexed Join; 24 proposal items plus defer, 2048 validation checks, arbitrary validated 1–3-placement open clusters and promoted families. Waiting hints persist. Complete base graph and all fallback alternatives are authoritative.',
            feature_semantics='Legacy9 plus translation-relative port/premise and guard/AST tokens; source occupancy, zero-aware formula assignment/agreement, complete C/G/I frontier degrees; full remote mark dependency compatibility/conflict counts. Features only, never exclusions.',
            selection=dict(epsilon=.1, temperature=1., rng='random.Random(job.seed), exactly one random() per policy event',
                           score='Sorted sparse-feature dot product / temperature, max-subtracted softmax, then 0.9*q+0.1/pool_size; canonical original pool order; first cumulative interval containing draw.'),
            learning=dict(episodes=8, origin='Fresh engine-generated full13 trajectories, no old trajectory or known proof as training data.',
                          adaptation='Per-instance on-policy episode-averaged, advantage-scaled clipped REINFORCE heuristic. Fresh evaluation seeds are not held-out-theorem generalization.',
                          reward='max_satisfied_points/52 - 0.5*dead/A - 0.25*backtracks/A - 0.1*branch/A - 0.05*(validation_checks+sample_pair_tests)/(2048*A), A=max(1,attempts)',
                          gradient='(1-epsilon)*q_chosen/p_chosen*(f_chosen-E_q[f])/temperature; average over episode events; multiply by return-minus-baseline, clip resulting L2 norm to1, rate0.2, coordinate weights clip ±4.',
                          baseline='Start0, EMA 0.9*old+0.1*return after each episode.',
                          unknowns='Unknown budget episodes supply observed finite growth/effort return, never a negative unprovability label; incomplete/resource-failed episodes stop progression.'),
            observations=jobs, training_episodes=8, rss_bytes=536870912,
            phase_seconds=dict(effect=60, training=180, evaluation=660),
            independent_audit_seconds=dict(effect=90, training=180, evaluation_per_run=120, evaluation_total=780),
            serialization_semantics='Every complete node census, state hash, hint lifecycle, complete alternatives, child transition, candidate, pool/order/features/weights digest/probabilities/RNG draw/work counter and final root rollback saved. Checkpoint before trace serialization; setup/cache/feature/proposal/search/update/serialization/full worker and dispatcher lifetime separately charged.',
            resource_semantics='Fresh task-owned worker per observation. Full worker lifetime includes imports, preparation and receipt serialization; aggregate RSS samples and conservative worker+owner+sampler+dispatcher peaks, all at512MiB. Retrospective gates, no hard OS memory cap. Owner final receipt/phase assembler writes excluded and disclosed.',
            action_effect_gate='Fresh seed16001 full13 pilot must have at least one actually visited changed-first branch (valid selected cluster, changed first candidate actually placed), complete independent graph/policy/RNG/hint/fallback/rollback replay and lifetime gate. A fixture/score change alone is insufficient. Stop before training if not passed.',
            training_gate='Complete eight engine trajectories and every reward/gradient/EMA/weight transition independently replayed under exact sources; all producer lifetimes/phase gates pass before trained evaluation. Audit binds final weight SHA and freezes it into evaluation activation.',
            evaluation_gate='Fresh equal language/budget base/untrained/trained balanced six-run order. Every actual tree/event independently replayed with complete literal domains/scheduler and new features/epsilon-mixture/RNG. Report all unknowns, changed-order counts and cost, with trained-vs-untrained and total-training-cost comparisons. No native query authorized.',
            independent_audit_requirements=['Exact full model SHA across every observation; preserve all19,848 placements,52 roots,153 rules,94 admitted definitions and source inventory.',
                 'Literal full-universe domain recomputation at every actual node; global dead/forced/earliest-generation checks; full census/state and strict-prior source decoding.',
                 'Independent reconstruction of all proposal pools/work order, old9 and new graph/source/mark features, sorted floating arithmetic, all softmax/mixture scores, RNG sequence and selected indices.',
                 'Full waiting/completed/invalid/eligible hint lifecycle, every fallback alternative, every visited child including failed-child hint retirement, all point/graph/generation rollback.',
                 'All counters including peak satisfied52, actual changed-first placements, costs/cutoffs, every training return/log-mixture gradient/advantage clipping/EMA/final weights.',
                 'Mutation controls: lost remote dependency, missing fallback, late-generation scheduling, stale failed hint, missing port binding, wrong plain-softmax gradient, RNG draw change, zero-as-missing and wrong training weight digest.',
                 'No incomplete/audit-resource-unknown can pass; checkpoint and preserve failed gates, exact process handles, overshoots, all unexecuted counts.'],
            activation='No searches/training/native execution until root independently reviews this source/plan and writes separate activation.json bound to this exact plan SHA. prerequisite_sha256[training] must bind exact effect/independent-audit.json; prerequisite_sha256[evaluation] must bind training/independent-audit.json and policy-final.json. Stages separately activated; producer refuses preexisting job/phase artifacts and separates attempted failures from unexecuted jobs. No retries or amendments by producer.',
            historical_scope='Earlier fixed-policy four5000-attempt unknowns and aliased actions stay unchanged; published ordinary proof/solver words never seed/order/train this program.',
            native_queries=0, proof_acceptance='Any point-model proof candidate requires fresh independent whole-certification plan; this experiment authorizes no native target query or heap change.')
        name = 'experiment-plan.json'
    destination = OUT/name
    if destination.exists():
        raise ValueError('never replace frozen plan '+name)
    destination.write_text(json.dumps(plan, indent=2)+'\n')
    print(json.dumps(dict(status=plan['status'], path=str(destination), sha256=sha(destination), sources=len(sources), inputs=len(inputs))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser();parser.add_argument('--fixtures', action='store_true')
    build(parser.parse_args().fixtures)
