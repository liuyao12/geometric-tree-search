"""Reference full point graph and reversible cluster preferences.

The only new decisions are epsilon-softmax cluster selection and inspectable
features. Waiting continuation, global scheduler and fallback stay unchanged.
"""
import collections
import hashlib
import random
import resource
import time
from native_receptor_points import fingerprint
from native_inference_inventory import aggregate
from commutativity13_guidance import Join
from arithmetic_stochastic_features_v2 import FeatureIndex, canonical, choose
from turtle import Graph


def review(model, state, graph, hint, point):
    if hint is None:
        return None, dict(phase='absent', pending=[], eligible=[])
    pending = [key for key in hint['item']['members'] if key not in state.selected]
    if not pending:
        return None, dict(phase='completed', pending=[], eligible=[])
    illegal = [key for key in pending if not state.legal(model.placement(key))]
    if illegal:
        return None, dict(phase='invalid', pending=pending, illegal=illegal, eligible=[])
    eligible = [key for key in pending if key in graph.domains.get(point, set())]
    return hint, dict(phase='eligible' if eligible else 'waiting', pending=pending, eligible=eligible)


def alternatives(kind, keys, active, status):
    preferred = set(status['eligible']) if active else set()
    ordered = keys if kind == 'forced' else [key for key in keys if key in preferred]+[key for key in keys if key not in preferred]
    return ordered, preferred


def needs_proposal(kind, active, mode):
    return kind == 'branch' and active is None and mode != 'base'


def search(model, mode='base', weights=None, seed=0, attempts=500,
           seconds=10, proposal_limit=24, proposal_checks=2048, rss_bytes=536870912):
    if mode not in ('base', 'untrained', 'trained', 'training'):
        raise ValueError('declared stochastic lane')
    weights = dict(sorted((weights or {}).items()))
    if mode == 'untrained' and any(weights.values()):
        raise ValueError('untrained policy must have zero weights')
    began = time.perf_counter()
    initial = model.initial()
    graph = Graph(model, initial)
    root_state, root_graph = fingerprint(initial), graph.fingerprint()
    metrics, events, hints = collections.Counter(), [], []
    found = None
    rng = random.Random(seed)
    stage = time.perf_counter()
    join = Join(model) if mode != 'base' else None
    join_seconds = time.perf_counter()-stage
    stage = time.perf_counter()
    feature_index = FeatureIndex(model) if mode != 'base' else None
    feature_seconds = time.perf_counter()-stage
    weights_pin = hashlib.sha256(canonical(weights)).hexdigest()

    def visit(state, current_graph, hint):
        nonlocal found
        kind, point, keys = current_graph.decision(state)
        metrics['nodes'] += 1
        satisfied = sum(state.totals.get(p, 0) == 12 for p in state.roots)
        metrics['max_satisfied_points'] = max(metrics['max_satisfied_points'], satisfied)
        active, status = review(model, state, current_graph, hint, point)
        node = dict(kind=kind, point=point,
                    census=[dict(point=p, generation=state.generations[p], keys=sorted(candidates)) for p, candidates in sorted(current_graph.domains.items())],
                    state_sha256=fingerprint(state), hint_in=hint['id'] if hint else None,
                    review=status, children=[], satisfied_points=satisfied)
        if hint:
            metrics['hint_'+status['phase']] += 1
        if kind == 'dead':
            metrics['dead'] += 1
            return False, node
        if kind == 'empty':
            found = state
            return True, node
        metrics[kind] += 1
        if needs_proposal(kind, active, mode):
            stage = time.perf_counter()
            items, work = join(state, current_graph, point, proposal_limit, proposal_checks)
            for key, value in work.items():
                metrics[key] += value
            feature_stage = time.perf_counter()
            vectors, feature_work = feature_index.vectors(items, state, current_graph, point)
            metrics['feature_seconds'] += time.perf_counter()-feature_stage
            for key, value in feature_work.items():
                metrics['features:'+key] += value
            item, event = choose(items, vectors, weights, rng)
            event.update(id=len(events), point=point, chosen=list(state.order), items=items,
                         weights_sha256=weights_pin, work=work, feature_work=feature_work,
                         base_first=keys[0], selected_point_domain=keys)
            node['policy_event'] = event['id']
            events.append(event)
            metrics['proposal_seconds'] += time.perf_counter()-stage
            if item is not None:
                expected = {key: item[key] for key in ('members', 'pending', 'aggregate_sha256', 'new_occupancy', 'new_marks')}
                if aggregate(model, item['members'], state) != expected:
                    raise ValueError('invalid proposed aggregate')
                active = dict(id=len(hints), item=item)
                hints.append(dict(id=active['id'], chosen=list(state.order), point=point, item=item))
                node['hint_start'] = active['id']
                metrics['hints_started'] += 1
                active, status = review(model, state, current_graph, active, point)
                node['start_review'] = status
                if active is None or not status['eligible']:
                    raise ValueError('proposal must touch scheduler-selected point')
        ordered, preferred = alternatives(kind, keys, active, status)
        node['alternatives'] = ordered
        if kind == 'branch' and ordered[0] != keys[0]:
            metrics['changed_first_branches'] += 1
        for key in ordered:
            elapsed = time.perf_counter()-began
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            if metrics['attempts'] >= attempts or elapsed >= seconds or peak >= rss_bytes:
                node.update(cutoff='before_placement', budget_reason='attempts' if metrics['attempts'] >= attempts else 'time' if elapsed >= seconds else 'memory')
                return None, node
            metrics['attempts'] += 1
            if len(node['children']) == 0 and kind == 'branch' and ordered[0] != keys[0]:
                metrics['executed_changed_first_branches'] += 1
            child, child_graph = state.copy(), current_graph.copy()
            child_graph.update(model, child, child.place(model.placement(key)))
            answer, sub = visit(child, child_graph, active)
            node['children'].append(dict(key=key, role='member' if key in preferred else 'base', tree=sub))
            if answer is not False:
                return answer, node
            metrics['backtracks'] += 1
        return False, node

    answer, tree = visit(initial, graph, None)
    restored = fingerprint(initial) == root_state and graph.fingerprint() == root_graph
    if not restored:
        raise ValueError('root state and complete graph rollback')
    return dict(schema='arithmetic-stochastic-cluster-search-v1',
                status='finite_marked_proof_region' if answer else 'unknown_search_budget' if answer is None else 'exhausted_finite_marked_region',
                proof=model.decode(found.order) if found else None,
                placements=found.order if found else [], tile_generations=found.tile_generations if found else [],
                tree=tree, metrics=dict(metrics), graph_metrics=dict(model.metrics), events=events, hints=hints,
                mode=mode, weights=weights, weights_sha256=weights_pin, seed=seed, stochastic=mode != 'base',
                root_state_sha256=root_state, root_restored=restored,
                proposer_initialization_seconds=join_seconds, feature_initialization_seconds=feature_seconds,
                feature_index_memberships=feature_index.static_membership_count if feature_index else 0,
                seconds=time.perf_counter()-began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                limits=dict(attempts=attempts, seconds=seconds, proposal_limit=proposal_limit,
                            proposal_checks=proposal_checks, rss_bytes=rss_bytes),
                scope='Same complete 13-row scalar point model. Reference global dead/forced/earliest-generation scheduler, waiting hints, full fallback and exact rollback. Per-instance stochastic ordering only; no learned marking restriction or native query.')
