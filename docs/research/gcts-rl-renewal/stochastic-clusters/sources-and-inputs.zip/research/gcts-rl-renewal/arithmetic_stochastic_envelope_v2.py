"""Freeze the versioned dispatch-envelope repair; never executes an observation."""
import ast
import copy
import difflib
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2)+'\n')


def main():
    original_path = BASE/'experiment-plan.json'
    original = json.loads(original_path.read_text())
    if digest(original_path) != '635079ab4e08c373f329b4c3201ca1e9279097a911973fe6a83711ba93b43a5d':
        raise ValueError('exact original plan required')
    failed_path = BASE/'effect/phase-summary.json'
    failed = json.loads(failed_path.read_text())
    if (failed['status'] != 'unknown_phase_reservation_budget'
            or failed['attempted'] != [] or failed['observations'] != []
            or failed['unexecuted'] != ['effect-pilot']
            or failed['seconds_before_final_phase_receipt_write'] != .01854625):
        raise ValueError('exact no-worker historical reservation failure required')
    for path, pin in {**original['source_sha256'], **original['input_sha256']}.items():
        if digest(ROOT/path) != pin:
            raise ValueError('original immutable binding '+path)
    sources = copy.deepcopy(original['source_sha256'])
    inputs = copy.deepcopy(original['input_sha256'])
    replacements = {}
    for kind in ('worker', 'owner'):
        old = ROOT/'research/gcts-rl-renewal'/('arithmetic_stochastic_'+kind+'_v2.py')
        new = ROOT/'research/gcts-rl-renewal'/('arithmetic_stochastic_'+kind+'_v3.py')
        expected = old.read_text().replace(
            "OUT = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'",
            "BASE = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'\nOUT = BASE/'execution-v2'\nPLAN_PATH = BASE/'experiment-plan-v2.json'")
        expected = expected.replace("OUT/'experiment-plan.json'", 'PLAN_PATH')
        if kind == 'owner':
            expected = expected.replace('arithmetic_stochastic_worker_v2.py', 'arithmetic_stochastic_worker_v3.py')
        if expected != new.read_text():
            raise ValueError('loader/path-only source correspondence '+kind)
        replacements[str(new.relative_to(ROOT))] = list(difflib.unified_diff(
            old.read_text().splitlines(), new.read_text().splitlines(),
            fromfile=str(old.relative_to(ROOT)), tofile=str(new.relative_to(ROOT)), lineterm=''))
        sources[str(new.relative_to(ROOT))] = digest(new)
    sources[str(Path(__file__).resolve().relative_to(ROOT))] = digest(Path(__file__).resolve())
    for path in (original_path, BASE/'activation.json', failed_path,
                 BASE/'source-ready-receipt.json', BASE/'review-source-freeze.zip'):
        inputs[str(path.relative_to(ROOT))] = digest(path)
    plan = copy.deepcopy(original)
    plan['source_sha256'] = sources
    plan['input_sha256'] = inputs
    plan['active_sources'] = [path.replace('_worker_v2.py', '_worker_v3.py').replace('_owner_v2.py', '_owner_v3.py')
                              for path in original['active_sources']]
    plan['phase_seconds']['effect'] = 75
    plan['activation'] = original['activation'].replace('separate activation.json', 'separate execution-v2/activation.json')
    plan['execution_root'] = str((BASE/'execution-v2').relative_to(ROOT))
    plan['versioned_amendment'] = dict(
        status='prospective_root_authorized_envelope_repair_pending_source_review_and_activation',
        original_plan_sha256=digest(original_path),
        original_activation_sha256=digest(BASE/'activation.json'),
        historical_reservation_receipt_sha256=digest(failed_path),
        historical_unknown_status=failed['status'], historical_workers_launched=0,
        historical_cost_seconds=failed['seconds_before_final_phase_receipt_write'],
        effect_phase_seconds_before=60, effect_phase_seconds_after=75,
        effect_worker_lifecycle_seconds=60, dispatch_preparation_report_allowance_seconds=15,
        cumulative_effect_budget_with_historical_failed_cost_seconds=75.01854625,
        reason='Equal60s phase and60s worker ceilings make reservation fail after any nonzero hashing/preparation. New75s phase permits60s unchanged worker plus15s dispatch overhead.',
        unchanged='All observations, seeds, attempt/search/worker caps, model, proposals, features, reward, gradient, training/evaluation and audit ceilings; no target witness or new native query.',
        preserved='Original plan, activation, phase summary and all prior source/evidence bytes unchanged. Fresh execution-v2 prefix, no overwrites or implicit retries.')
    altered = {'source_sha256', 'input_sha256', 'active_sources', 'phase_seconds', 'activation',
               'execution_root', 'versioned_amendment'}
    for key, value in original.items():
        if key not in altered and plan[key] != value:
            raise ValueError('unexpected plan change '+key)
    if {key: value for key, value in plan['phase_seconds'].items() if key != 'effect'} != {
            key: value for key, value in original['phase_seconds'].items() if key != 'effect'}:
        raise ValueError('non-effect phase changed')
    parsed = 0
    for path, pin in {**sources, **inputs}.items():
        if digest(ROOT/path) != pin:
            raise ValueError('v2 immutable binding '+path)
        if path in sources and path.endswith('.py'):
            ast.parse((ROOT/path).read_text(), filename=path);parsed += 1
    plan_path = BASE/'experiment-plan-v2.json'
    write_new(plan_path, plan)
    source_zip = BASE/'review-source-freeze-v2.zip'
    with zipfile.ZipFile(source_zip, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(sources):
            info = zipfile.ZipInfo(path, date_time=(2026, 10, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (ROOT/path).read_bytes())
    receipt = dict(status='frozen_dispatch_envelope_repair_ready_for_root_review_not_activated',
        plan_path=str(plan_path.relative_to(ROOT)), plan_sha256=digest(plan_path),
        source_pins=len(sources), input_pins=len(inputs), all_pins_match=True,
        parsed_python_sources=parsed, active_source_sha256={path:sources[path] for path in plan['active_sources']},
        source_zip_sha256=digest(source_zip), execution_root=plan['execution_root'],
        exact_loader_only_source_diffs=replacements,
        historical_reservation_receipt_sha256=digest(failed_path),
        historical_cost_seconds=failed['seconds_before_final_phase_receipt_write'],
        model_sha256=plan['complete_model_sha256'], all_observation_specs_unchanged=plan['observations'] == original['observations'],
        only_phase_cap_change=dict(effect=[60,75]), worker_lifecycle_unchanged=60,
        independent_audit_caps_unchanged=plan['independent_audit_seconds'] == original['independent_audit_seconds'],
        fresh_activation_exists=(BASE/'execution-v2/activation.json').exists(),
        new_searches=0, training_episodes=0, native_queries=0,
        static_reservation_fixture=dict(nonzero_preparation_seconds=.01854625,
            original_remaining_seconds=60-.01854625, original_worker_reservable=False,
            new_remaining_seconds=75-.01854625, unchanged_worker_reservable=True),
        scope='Source/plan/pin/AST and pure reservation arithmetic only. No owner, worker, engine, training or native execution.')
    receipt_path = BASE/'source-ready-receipt-v2.json'
    write_new(receipt_path, receipt)
    print(json.dumps(dict(status=receipt['status'], plan_sha256=digest(plan_path),
        receipt_sha256=digest(receipt_path), zip_sha256=digest(source_zip),
        sources=len(sources), inputs=len(inputs), active_source_sha256=receipt['active_source_sha256'])))


if __name__ == '__main__':
    main()
