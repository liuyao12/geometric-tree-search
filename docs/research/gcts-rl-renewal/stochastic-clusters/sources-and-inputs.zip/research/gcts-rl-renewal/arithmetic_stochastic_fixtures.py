"""Pure point/feature/math fixtures; never calls search or trains a policy."""
import collections
import gzip
import hashlib
import json
import math
import random
import resource
import time
from pathlib import Path
from turtle import State, Placement, Graph
from native_receptor_points import fingerprint
from native_inference_inventory import aggregate
from audit_semantic_inventory import LiteralDomains
from arithmetic_stochastic_features import (FeatureIndex, binding_features, canonical,
    distribution, choose, event_gradient, update, episode_return)
from arithmetic_stochastic_search import review, alternatives, needs_proposal
from commutativity13_guidance import Join

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'


def need(value, label):
    if not value:
        raise AssertionError(label)


def load(path):
    with gzip.open(path, 'rt') as stream:
        return json.load(stream)


class PointData:
    def __init__(self, placements, roots, initial_marks=()):
        self.cache, self.metadata = {}, {}
        self.dependencies, self.align_cache = collections.defaultdict(set), collections.defaultdict(list)
        self.metrics = collections.Counter()
        self.roots = tuple(tuple(point) for point in roots)
        self.initial_marks = [(tuple(point), value) for point, value in initial_marks]
        for record in placements:
            key = tuple(record['key'])
            occupancy = tuple((tuple(point), value) for point, value in record['occupancy'])
            marks = tuple((tuple(point), value) for point, value in record['marks'])
            self.cache[key] = Placement(key, occupancy, marks, ())
            self.metadata[key] = record
            for point, value in occupancy:
                self.align_cache[point].append(key)
            for point, value in occupancy+marks:
                self.dependencies[point].add(key)
        for point in self.roots:
            self.align_cache[point]
    def initial(self):
        roots = {point: 0 for point in self.roots}
        return State(marks=dict(self.initial_marks), generations=roots.copy(), roots=roots,
                     allowed_points=frozenset(roots))
    def placement(self, key):
        return self.cache[key]
    def alignments(self, point):
        return self.align_cache[point]


def literal_state(state):
    return dict(totals=state.totals, marks=state.marks, roots=state.roots, generations=state.generations,
                selected=state.selected, order=state.order, tile_generations=state.tile_generations)


def exact_graph(model, state, graph):
    inventory = {key: dict(key=key, occupancy=tile.occupancy, marks=tile.marks) for key, tile in model.cache.items()}
    domains = LiteralDomains(inventory)(literal_state(state))
    need({point: sorted(keys) for point, keys in graph.domains.items()} == domains,
         'complete graph equals independent literal enumeration')


def scheduler_fixtures():
    p, q, r, remote = (0, 0), (4, 0), (8, 0), (99, 0)
    tiles = [dict(key=(0, 0, i, 0), occupancy=[(p, 12)], marks=[(remote, i)]) for i in (0, 1)]
    tiles += [dict(key=(1, 0, 0, 0), occupancy=[(q, 12)], marks=[(remote, 0)])]
    tiles += [dict(key=(2, 0, i, 0), occupancy=[(r, 12)], marks=[]) for i in (0, 1)]
    model = PointData(tiles, [p, q, r])
    state = model.initial();graph = Graph(model, state);exact_graph(model, state, graph)
    need(graph.decision(state)[:2] == ('forced', q), 'global forced before branch')
    snapshot = fingerprint(state), graph.fingerprint()
    hint = dict(id=0, item=aggregate(model, [(2, 0, 1, 0)], state))
    active, phase = review(model, state, graph, hint, p)
    need(active is hint and phase['phase'] == 'waiting' and not needs_proposal('branch', active, 'untrained'), 'waiting continuation suppresses replanning')
    child, child_graph = state.copy(), graph.copy()
    changed = child.place(model.placement((0, 0, 1, 0)));child_graph.update(model, child, changed)
    exact_graph(model, child, child_graph)
    need(child_graph.decision(child)[:2] == ('dead', q), 'remote dead outranks forced and branches')
    bad_hint = dict(id=1, item=dict(members=[(1, 0, 0, 0)]))
    active, phase = review(model, child, child_graph, bad_hint, r)
    need(active is None and phase['phase'] == 'invalid', 'failed-child hint invalidation')
    need(snapshot == (fingerprint(state), graph.fingerprint()), 'all parent totals/marks/generation/incidence restored')
    # Mutation: omitting the extended marking dependency leaves stale domains.
    stale = graph.copy();stale.update(model, child, {p})
    need(stale.fingerprint() != child_graph.fingerprint(), 'lost distant dependency mutant rejected')
    marked = model.initial();marked.marks[remote] = 1
    mg = Graph(model, marked);exact_graph(model, marked, mg)
    need(mg.decision(marked)[:2] == ('dead', q), 'late dead before simultaneous forced point')
    branch_tiles = [dict(key=(0, 0, i, 0), occupancy=[(p, 12)], marks=[]) for i in range(3)]
    branch_tiles += [dict(key=(2, 0, i, 0), occupancy=[(r, 12)], marks=[]) for i in range(2)]
    bm = PointData(branch_tiles, [p, r]);bs = bm.initial();bs.generations[r] = bs.roots[r] = 7
    bg = Graph(bm, bs);exact_graph(bm, bs, bg)
    need(bg.decision(bs)[:2] == ('branch', p), 'earliest generation before smaller degree')
    shared = [dict(key=(0, 0, i, 0), occupancy=[(p, 6), (q, 6)], marks=[]) for i in range(2)]
    sm = PointData(shared, [p, q]);ss = sm.initial();sg = Graph(sm, ss)
    sg.update(sm, ss, ss.place(sm.placement((0, 0, 0, 0))));exact_graph(sm, ss, sg)
    need(sg.decision(ss)[0] == 'forced', 'shared fractional residual becomes forced')
    sg.update(sm, ss, ss.place(sm.placement((0, 0, 1, 0))));exact_graph(sm, ss, sg)
    need(sg.decision(ss)[0] == 'empty' and ss.totals[p] == ss.totals[q] == 12, 'exact shared candidate capacity')
    return dict(dead_before_forced=True, forced_before_branch=True, earliest_generation=True,
                extended_mark_mutation_rejected=True, failed_hint_retired=True,
                waiting_preserved=True, snapshot_rollback=True, shared_fractional=True)


def policy_math_fixtures():
    fs = [dict(a=1., b=.3), dict(a=-.4, c=.7), dict(b=.6, c=-.2)]
    weights = dict(a=.2, b=-.3, c=.1)
    scores, soft, probability = distribution(fs, weights)
    event = dict(features=fs, index=1, softmax_probabilities=soft, probabilities=probability,
                 epsilon=.1, temperature=1.)
    gradient = event_gradient(event);errors = []
    for key in weights:
        plus, minus = dict(weights), dict(weights)
        plus[key] += 1e-6;minus[key] -= 1e-6
        numerical = (math.log(distribution(fs, plus)[2][1])-math.log(distribution(fs, minus)[2][1]))/2e-6
        errors.append(abs(numerical-gradient[key]))
    need(max(errors) < 1e-9, 'epsilon-mixture log-gradient finite differences')
    mutant = {key: fs[1].get(key, 0)-sum(p*v.get(key, 0) for p, v in zip(soft, fs)) for key in weights}
    need(any(abs(mutant[key]-gradient[key]) > 1e-4 for key in weights), 'plain softmax gradient mutant rejected')
    zero = distribution(fs, {})[2]
    need(all(abs(value-1/3) < 1e-15 for value in zero), 'zero-weight uniform policy')
    # Pure numerical clipping fixture, not a model/trajectory training episode.
    _, _, details = update(weights, [event], 10., 0.)
    need(details['advantage_scaled_gradient_norm'] > 1 and abs(details['clipped_update_gradient_norm']-1) < 1e-12,
         'actual advantage-scaled update clipping')
    return dict(derivative_errors=errors, wrong_gradient_rejected=True, zero_uniform=True,
                advantage_scaled_clipping=True, synthetic_math_only=True)


def saved_action_fixture():
    raw = load(ROOT/'.gcts-active/commutativity13-20261011/model13.json.gz')
    record = raw['model']
    model = PointData(record['placements'], record['roots'], record['initial_marks'])
    model.spec = raw['case'];model.rules = record['inference_rules']
    model.rule_modes = {i: i+1 if rule['premises'] else 0 for i, rule in enumerate(model.rules)}
    model.promoted_rules = set(record['promoted_rules'])
    model.compiled = load(ROOT/'.gcts-active/commutativity-receptors-20261011/attempt-02/two-lemmas-retained-core.json.gz')
    diagnostic = json.loads((ROOT/'docs/research/gcts-rl-renewal/parallel-progress/diagnostic/fixed-r1-diagnostic.json').read_text())
    separated = compared = 0
    for event in diagnostic['events']:
        winner = event['actions'][event['selected']]
        item = None if not winner['members'] else dict(members=winner['members'])
        feature = binding_features(item, model.metadata, model.rules, event['point'])
        alternatives_found = []
        for action in event['actions']:
            if action['changes_first'] and action['features'] == winner['features']:
                compared += 1
                other = binding_features(dict(members=action['members']), model.metadata, model.rules, event['point'])
                alternatives_found.append(feature != other)
        if alternatives_found:
            need(all(alternatives_found), 'all previously feature-identical changing attachments separated')
            separated += 1
    need(separated == 474, 'complete previously aliased decision coverage')
    # One saved decision is a pure fixture, never a winning target proof path.
    event = diagnostic['events'][4]
    state = model.initial();graph = Graph(model, state)
    for raw_key in event['chosen']:
        key = tuple(raw_key);need(state.legal(model.placement(key)), 'saved fixture placement legal')
        graph.update(model, state, state.place(model.placement(key)))
    exact_graph(model, state, graph)
    kind, point, keys = graph.decision(state)
    need(kind == 'branch' and list(point) == event['point'] and [list(key) for key in keys] == event['domain'], 'saved fixture exact scheduler domain')
    items, work = Join(model)(state, graph, point)
    need([None if item is None else [list(key) for key in item['members']] for item in items] == [None if not action['members'] else action['members'] for action in event['actions']], 'unchanged saved proposal pool and order')
    index = FeatureIndex(model)
    fs, feature_work = index.vectors(items, state, graph, point)
    class Midpoint:
        def random(self):return .5
    item, chosen = choose(items, fs, {}, Midpoint())
    hint = dict(id=0, item=item);active, status = review(model, state, graph, hint, point)
    ordered, preferred = alternatives(kind, keys, active, status)
    need(ordered[0] != keys[0] and sorted(ordered) == keys, 'stochastic fixture changes first with full fallback')
    parent = fingerprint(state), graph.fingerprint()
    child, cg = state.copy(), graph.copy()
    cg.update(model, child, child.place(model.placement(ordered[0])));exact_graph(model, child, cg)
    need(parent == (fingerprint(state), graph.fingerprint()), 'changed branch parent restored')
    need(any(value == 0 for value in state.marks.values()), 'explicit zero remains assigned in feature fixture')
    need(fs[0] != fs[1], 'source binding separates formerly identical first two actions')
    return dict(previous_aliased_decisions=separated, previously_aliased_action_pairs=compared,
                saved_event_fixture=4, actual_new_searches=0, stochastic_draw=.5,
                selected_index=chosen['index'], first_changed=True, full_fallback=True,
                producer_features=fs, feature_work=feature_work, source_binding_mutant_rejected=True,
                scope='Read-only saved single-state fixture plus complete token-only alias coverage; not an actual new policy-effect observation.')


def main():
    began = time.perf_counter();plan = json.loads((OUT/'fixture-plan.json').read_text())
    for path, digest in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == digest, 'frozen pure fixture binding '+path)
    result = dict(status='running_pure_conformance_fixtures', target_searches=0,
                  native_queries=0, model_training_episodes=0,
                  fixture_plan_sha256=hashlib.sha256((OUT/'fixture-plan.json').read_bytes()).hexdigest())
    try:
        result.update(scheduler=scheduler_fixtures(), policy_math=policy_math_fixtures(), saved_actions=saved_action_fixture())
        result['status'] = 'passed_pure_scheduler_feature_math_and_saved_state_fixtures'
    except (AssertionError, ValueError, MemoryError) as exc:
        result.update(status='failed_or_unknown_pure_fixture', failure=str(exc), failure_type=type(exc).__name__)
    result.update(seconds_before_final_receipt_write=time.perf_counter()-began,
                  peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    if result['seconds_before_final_receipt_write'] > plan['seconds'] or result['peak_rss_bytes'] > plan['rss_bytes']:
        result['status'] = 'unknown_pure_fixture_resource_budget'
    (OUT/'fixtures.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({key:value for key,value in result.items() if key != 'saved_actions'}), flush=True)
    need(result['status'].startswith('passed'), 'all pure fixtures passed')


if __name__ == '__main__':main()
