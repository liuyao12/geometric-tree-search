"""Read-only receipt and cutoff collector; imports no engine or policy producer.

This records declared and observed budgets, provenance and disjoint cost scopes.
It is not a graph replay, policy evaluator, proof checker or process monitor.
"""
import argparse
import collections
import gzip
import hashlib
import io
import json
import math
import re
import resource
import signal
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'
OUT = BASE/'collector-v1'
EXPERIMENT = BASE/'experiment-plan-v2.json'
TOKEN = re.compile(rb'\s*(?:(?P<string>"(?:[^"\\]|\\.)*")|(?P<other>[{}\[\]:,]|[^\s{}\[\]:,"]+))')
PASSED_AUDITS = {
    'effect': 'passed_complete_action_effect_graph_and_policy_gate',
    'training': 'passed_complete_training_graph_rng_and_updates',
    'evaluation': 'passed_complete_balanced_evaluation_graph_rng_and_policy'}


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def file_sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            result.update(block)
    return result.hexdigest()


def identity(path):
    info = path.stat()
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns]


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2)+'\n')


def cutoff_fields(stream, block_size=65536):
    """Lexically count actual JSON object cutoff fields, using bounded buffers.

    Quoted strings and escaped quotes are indivisible, so lookalike strings do
    not become fields. The independently replayed trace is the validity source;
    this census alone does not check JSON structure or reconstruct the graph.
    """
    fields = {'budget_reason': collections.Counter(), 'cutoff': collections.Counter()}
    buffer, previous, awaiting, eof = b'', None, None, False
    while not eof or buffer:
        if not eof:
            block = stream.read(block_size)
            eof = not block
            buffer += block
        position = 0
        while position < len(buffer):
            match = TOKEN.match(buffer, position)
            if match is None:
                if buffer[position:].strip() == b'':
                    position = len(buffer);break
                if not eof:
                    break
                raise ValueError('incomplete or invalid lexical token')
            # A primitive at a block end might continue in the next block.
            if not eof and match.end() == len(buffer) and match.lastgroup == 'other' and match.group('other') not in b'{}[]:,':
                break
            position = match.end()
            if match.lastgroup == 'string':
                token = match.group('string')
                if awaiting is not None:
                    value = json.loads(token)
                    if not isinstance(value, str):
                        raise ValueError('cutoff field must be a string')
                    fields[awaiting][value] += 1
                    awaiting = None
                # Only decode prospective field-name tokens; arbitrary strings
                # cannot activate a field unless the following token is colon.
                previous = json.loads(token) if token.startswith((b'"budget', b'"cutoff')) else None
            else:
                token = match.group('other')
                if awaiting is not None:
                    raise ValueError('nonstring cutoff field')
                awaiting = previous if token == b':' and previous in fields else None
                previous = None
        buffer = buffer[position:]
        if len(buffer) > (1 << 20):
            raise ValueError('collector lexical token exceeds1MiB buffer ceiling')
        if eof and buffer:
            raise ValueError('unconsumed lexical suffix')
    if awaiting is not None:
        raise ValueError('missing cutoff value')
    return {key: dict(sorted(value.items())) for key, value in fields.items()}


def finite_return(metrics):
    a = max(1, metrics.get('attempts', 0))
    return (metrics.get('max_satisfied_points', 0)/52
            -.5*metrics.get('dead', 0)/a -.25*metrics.get('backtracks', 0)/a
            -.1*metrics.get('branch', 0)/a
            -.05*(metrics.get('validation_checks', 0)+metrics.get('sample_pair_tests', 0))/(2048*a))


def producer_category(summary, lifetime, attempted):
    if summary is not None and lifetime is not None and summary.get('status') == 'complete_observation_pending_independent_audit' and lifetime.get('status') == 'passed_complete_observation_lifetime_gate':
        return 'complete_producer_observation'
    if lifetime is not None or summary is not None:
        return 'failed_or_unknown_producer_observation'
    return 'attempted_incomplete_snapshot' if attempted else 'unexecuted'


def audit_category(audit, lifetime):
    if audit is None and lifetime is None:
        return 'pending_or_unexecuted'
    if audit is not None and lifetime is not None and audit.get('status') == 'passed_complete_actual_graph_rng_and_policy_replay' and lifetime.get('status') == 'passed_complete_replay_lifetime':
        return 'complete_independent_observation_replay'
    return 'failed_unknown_or_incomplete_independent_replay'


def check_plan(plan):
    for path, pin in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if file_sha(ROOT/path) != pin:
            raise ValueError('collector immutable pin '+path)


def collect(plan, phases):
    experiment = json.loads(EXPERIMENT.read_bytes())
    execution = ROOT/experiment['execution_root']
    pins, errors, phases_out = {}, [], []

    def capture(path):
        if not path.exists():
            return None
        before = identity(path)
        if before[2] > 8 << 20:
            errors.append(dict(path=str(path.relative_to(ROOT)), failure='small-receipt ceiling8MiB'))
            return None
        raw = path.read_bytes()
        relative = str(path.relative_to(ROOT))
        pins[relative] = dict(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), identity=before)
        if identity(path) != before:
            errors.append(dict(path=relative, failure='changed while captured'))
        try:
            value = json.loads(raw)
            if not isinstance(value, dict):
                raise ValueError('receipt must be an object')
            return value
        except (ValueError, OSError) as exc:
            errors.append(dict(path=relative, failure=type(exc).__name__+': '+str(exc)))
            return None

    final_policy = capture(execution/'training/policy-final.json')
    final_policy_sha = hashlib.sha256(encoded(final_policy['weights'])).hexdigest() if final_policy else None
    for phase in phases:
        folder = execution/phase
        phase_receipt = capture(folder/'phase-summary.json')
        phase_audit = capture(folder/'independent-audit.json')
        jobs = [job for job in experiment['observations'] if job['phase'] == phase]
        observations, produced, audited, search_results = [], collections.Counter(), collections.Counter(), collections.Counter()
        for job in jobs:
            name = job['id']
            summary = capture(folder/(name+'-summary.json'))
            lifetime = capture(folder/(name+'-lifetime.json'))
            audit = capture(folder/(name+'-audit.json'))
            audit_lifetime = capture(folder/(name+'-audit-lifetime.json'))
            policy = capture(folder/(name+'-policy.json')) if phase == 'training' else None
            attempted = name in (phase_receipt or {}).get('attempted', []) or any(folder.glob(name+'-*'))
            category = producer_category(summary, lifetime, attempted)
            replay = audit_category(audit, audit_lifetime)
            produced[category] += 1;audited[replay] += 1
            actual_status = (summary or {}).get('search_status')
            if actual_status is not None:
                search_results[actual_status] += 1
            item = dict(id=name, phase=phase, mode=job['mode'], seed=job['seed'], declared_budgets=job,
                        producer_category=category, independent_category=replay,
                        producer_status=(summary or {}).get('status'), search_status=actual_status,
                        lifetime_status=(lifetime or {}).get('status'), audit_status=(audit or {}).get('status'),
                        audit_lifetime_status=(audit_lifetime or {}).get('status'),
                        metrics=(summary or {}).get('metrics'), proof_rows=(summary or {}).get('proof_rows'),
                        full_model_sha256=(summary or {}).get('complete_model_sha256'),
                        initial_weights_sha256=(summary or {}).get('weights_sha256'),
                        costs=dict(search_seconds=(summary or {}).get('search_seconds'),
                            model_setup_seconds=(summary or {}).get('model_setup_seconds'),
                            model_binding_seconds=(summary or {}).get('model_binding_seconds'),
                            proposer_initialization_seconds=(summary or {}).get('proposer_initialization_seconds'),
                            feature_initialization_seconds=(summary or {}).get('feature_initialization_seconds'),
                            feature_seconds=(summary or {}).get('metrics', {}).get('feature_seconds'),
                            proposal_seconds=(summary or {}).get('metrics', {}).get('proposal_seconds'),
                            trace_serialization_seconds=(summary or {}).get('trace_serialization_seconds'),
                            update_seconds=(summary or {}).get('update_seconds'),
                            full_worker_lifetime_seconds=(lifetime or {}).get('worker_lifetime_seconds'),
                            owner_seconds_before_final_receipt_write=(lifetime or {}).get('owner_seconds_before_final_receipt_write'),
                            independent_full_worker_seconds=(audit_lifetime or {}).get('full_worker_seconds')),
                        resources=dict(worker_peak_bytes=(summary or {}).get('kernel_worker_peak_bytes'),
                            owner_conservative_peak_bytes=(lifetime or {}).get('conservative_peak_bytes'),
                            search_wall_overshoot_seconds=(summary or {}).get('search_wall_overshoot_seconds'),
                            worker_wall_overshoot_seconds=(lifetime or {}).get('wall_overshoot_seconds'),
                            memory_overshoot_bytes=(lifetime or {}).get('memory_overshoot_bytes'),
                            watchdog_violation=(lifetime or {}).get('watchdog_violation'),
                            independent_peak_bytes=(audit_lifetime or {}).get('conservative_owner_plus_child_kernel_peak_bytes')),
                        cutoff_fields=None, trace_sha256=None)
            # Do not consume a potentially live/partial trace as completed.
            trace = folder/(name+'-search.json.gz')
            if category == 'complete_producer_observation' and trace.exists():
                before = identity(trace)
                digest = file_sha(trace)
                pins[str(trace.relative_to(ROOT))] = dict(sha256=digest, bytes=before[2], identity=before)
                try:
                    with gzip.open(trace, 'rb') as stream:
                        item['cutoff_fields'] = cutoff_fields(stream)
                    if identity(trace) != before or file_sha(trace) != digest:
                        raise ValueError('trace changed during read-only census')
                    item['trace_sha256'] = digest
                except (ValueError, OSError, EOFError) as exc:
                    errors.append(dict(path=str(trace.relative_to(ROOT)), failure=type(exc).__name__+': '+str(exc)))
            if policy:
                details = policy.get('update', {})
                before = policy.get('weights_before', {})
                after = policy.get('weights_after', {})
                recomputed = finite_return((summary or {}).get('metrics', {}))
                item['learning_provenance'] = dict(episode=policy.get('episode'), seed=policy.get('seed'),
                    trace_sha256=policy.get('search_sha256'), trace_binding_matches=item['trace_sha256'] == policy.get('search_sha256'),
                    weights_before_sha256=hashlib.sha256(encoded(before)).hexdigest(),
                    weights_after_sha256=hashlib.sha256(encoded(after)).hexdigest(),
                    weights_before_count=len(before), weights_after_count=len(after),
                    nonzero_weights_after=sum(value != 0 for value in after.values()),
                    reward=details.get('reward'), finite_return_from_summary=recomputed,
                    stored_reward_matches_summary=math.isclose(details.get('reward', math.nan), recomputed, rel_tol=2e-12, abs_tol=2e-12),
                    baseline_before=details.get('baseline_before'), baseline_after=policy.get('baseline_after'),
                    advantage=details.get('advantage'), mean_score_gradient_norm=details.get('mean_score_gradient_norm'),
                    advantage_scaled_gradient_norm=details.get('advantage_scaled_gradient_norm'),
                    applied_gradient_scale=details.get('applied_gradient_scale'),
                    clipped_update_gradient_norm=details.get('clipped_update_gradient_norm'),
                    adaptation=policy.get('adaptation'),
                    scope='Receipt provenance and summary-return consistency only; root independent replay supplies gradient/chain validity.')
            if job['mode'] == 'trained':
                item['frozen_final_policy_sha256'] = final_policy_sha
                item['final_policy_identity_matches_summary'] = final_policy_sha == item['initial_weights_sha256']
            observations.append(item)
        phase_complete = bool(phase_receipt and phase_receipt.get('status') == 'complete_phase_pending_independent_audit'
                              and not phase_receipt.get('unexecuted') and produced['complete_producer_observation'] == len(jobs))
        phase_audited = bool(phase_audit and phase_audit.get('status') == PASSED_AUDITS[phase]
                            and not phase_audit.get('unexecuted') and audited['complete_independent_observation_replay'] == len(jobs))
        # Phase times include workers; select them instead of adding both scopes.
        producer_cost = (phase_receipt or {}).get('seconds_before_final_phase_receipt_write')
        producer_basis = 'phase_receipt_includes_workers_before_final_receipt_write'
        if producer_cost is None:
            producer_cost = sum(item['costs']['owner_seconds_before_final_receipt_write'] or 0 for item in observations)
            producer_basis = 'available_owner_receipt_sum_partial_lower_bound'
        audit_cost = (phase_audit or {}).get('seconds_before_final_phase_receipt_write')
        audit_basis = 'independent_phase_receipt_includes_workers_before_final_receipt_write'
        if audit_cost is None:
            audit_cost = sum(item['costs']['independent_full_worker_seconds'] or 0 for item in observations)
            audit_basis = 'available_independent_worker_receipt_sum_partial_lower_bound'
        phases_out.append(dict(phase=phase, declared_observations=len(jobs), producer_complete=phase_complete,
            independent_phase_complete=phase_audited, producer_status=(phase_receipt or {}).get('status'),
            independent_status=(phase_audit or {}).get('status'), producer_counts=dict(produced),
            independent_counts=dict(audited), search_result_counts=dict(search_results),
            observations=observations, production_seconds=producer_cost, production_cost_basis=producer_basis,
            independent_audit_seconds=audit_cost, independent_cost_basis=audit_basis,
            producer_phase_wall_overshoot_seconds=(phase_receipt or {}).get('wall_overshoot_seconds'),
            producer_phase_memory_overshoot_bytes=(phase_receipt or {}).get('memory_overshoot_bytes')))
    historical = experiment['versioned_amendment']['historical_cost_seconds']
    production = sum(phase['production_seconds'] for phase in phases_out)
    independent = sum(phase['independent_audit_seconds'] for phase in phases_out)
    return dict(status='read_only_result_snapshot_not_new_validation', requested_phases=phases,
        experiment_plan_sha256=file_sha(EXPERIMENT), model_sha256=experiment['complete_model_sha256'],
        phases=phases_out, consumed_file_pins=pins, capture_errors=errors,
        final_policy=dict(weights_sha256=final_policy_sha, baseline=(final_policy or {}).get('baseline'),
            origin=(final_policy or {}).get('origin')),
        costs=dict(selected_phase_production_seconds=production, selected_phase_independent_audit_seconds=independent,
            preserved_no_worker_reservation_failure_seconds=historical,
            selected_known_cost_sum_seconds=production+independent+historical,
            overlap_semantics='Never add worker/owner/search components to inclusive phase totals; feature time is inside proposal time, proposal and initialization inside search time. Partial sums are explicit lower bounds.',
            exclusions='Source-authoring time, earlier fixtures/preparation/audits and historical studies are not reconstructed here; final receipt writes excluded by original clocks. No overall speedup claim.'),
        interpretation='Same-instance stochastic adaptation and fresh-seed evaluation only. Complete producer observations may be search unknowns. This collector cannot confer graph/policy/proof validity or held-out theorem generalization; no native proof query/acceptance.',
        searches_executed_by_collector=0, training_episodes_executed_by_collector=0, native_queries=0,
        process_status_scope='File snapshot only; no PID polling or authoritative running/terminal inference for absent receipts.')


def fixtures():
    began = time.perf_counter()
    plan = json.loads((OUT/'fixture-plan.json').read_bytes());check_plan(plan)
    sample = {'search': {'tree': {'budget_reason': 'attempts', 'cutoff': 'before_placement',
                'children': [{'tree': {'budget_reason': 'time', 'cutoff': 'before_placement'}}]},
                'message': 'lookalike "budget_reason":"memory" and escaped \\"quote'},
              'budget_reason_lookalike': 'none'}
    raw = encoded(sample)
    expected = dict(budget_reason={'attempts': 1, 'time': 1}, cutoff={'before_placement': 2})
    for size in (1, 2, 3, 7, 31, 65536):
        assert cutoff_fields(io.BytesIO(raw), size) == expected
    for bad in (b'{"budget_reason":null}', b'{"budget_reason":'):
        try:cutoff_fields(io.BytesIO(bad), 1)
        except ValueError:pass
        else:raise ValueError('invalid cutoff mutant accepted')
    assert producer_category(None, None, False) == 'unexecuted'
    assert producer_category(None, None, True) == 'attempted_incomplete_snapshot'
    assert producer_category({'status':'unknown'}, None, True) == 'failed_or_unknown_producer_observation'
    assert producer_category({'status':'complete_observation_pending_independent_audit'},
                             {'status':'passed_complete_observation_lifetime_gate'}, True) == 'complete_producer_observation'
    assert audit_category({'status':'passed_complete_actual_graph_rng_and_policy_replay'}, None) != 'complete_independent_observation_replay'
    result = dict(status='passed_pure_collector_fixtures', token_chunk_sizes=[1,2,3,7,31,65536],
        escaped_lookalike_rejected=True, missing_nonstring_mutants_rejected=2,
        unknown_unexecuted_complete_categories_distinct=True, missing_lifetime_never_audit_complete=True,
        seconds=time.perf_counter()-began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        searches=0, training_episodes=0, native_queries=0)
    if result['seconds'] > plan['seconds'] or result['peak_rss_bytes'] > plan['rss_bytes']:
        result['status'] = 'unknown_collector_fixture_resource_gate'
    write_new(OUT/'fixtures.json', result)
    print(json.dumps(result))


def freeze(fixture_only):
    OUT.mkdir(exist_ok=True)
    source = Path(__file__).resolve()
    inputs = {str(EXPERIMENT.relative_to(ROOT)): file_sha(EXPERIMENT)}
    if not fixture_only:
        fixture = json.loads((OUT/'fixtures.json').read_bytes())
        if fixture['status'] != 'passed_pure_collector_fixtures':
            raise ValueError('passed pure collector fixture required')
        for path in (OUT/'fixture-plan.json', OUT/'fixtures.json'):
            inputs[str(path.relative_to(ROOT))] = file_sha(path)
    plan = dict(status='frozen_pure_collector_fixture_plan' if fixture_only else 'frozen_read_only_collector_before_actual_output_collection',
        source_sha256={str(source.relative_to(ROOT)): file_sha(source)}, input_sha256=inputs,
        seconds=60 if fixture_only else 300, rss_bytes=536870912, phases=['effect','training','evaluation'],
        scope='Standard-library only; no engine/proposer/training/checker import, subprocess, native call or process polling. Reads exact terminal receipts/lexical cutoff fields; phase incomplete remains incomplete.',
        execution_root='.gcts-active/arithmetic-stochastic-clusters-20261011/execution-v2',
        output_root=str(OUT.relative_to(ROOT)), overwrite=False,
        cost_scope='Disjoint phase producer/audit totals, historical reservation failure, component diagnostics and collector cost. No speedup/generalization/proof acceptance inference.',
        searches=0, training_episodes=0, native_queries=0)
    path = OUT/('fixture-plan.json' if fixture_only else 'plan.json')
    write_new(path, plan)
    manifest = dict(status=plan['status'], files=[dict(path=str(p.relative_to(ROOT)), sha256=file_sha(p), bytes=p.stat().st_size)
        for p in (source, path, *([] if fixture_only else [OUT/'fixture-plan.json', OUT/'fixtures.json']))])
    destination = OUT/('fixture-manifest.json' if fixture_only else 'manifest.json')
    write_new(destination, manifest)
    print(json.dumps(dict(plan_sha256=file_sha(path), manifest_sha256=file_sha(destination), source_sha256=file_sha(source), status=plan['status'])))


def timeout(*_):
    raise TimeoutError('read-only collector wall ceiling')


def main(phases, name):
    began = time.perf_counter()
    plan = json.loads((OUT/'plan.json').read_bytes());check_plan(plan)
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', name):
        raise ValueError('simple task-owned snapshot name required')
    path = OUT/(name+'.json')
    if path.exists():
        raise ValueError('collector refuses overwrite')
    signal.signal(signal.SIGALRM, timeout);signal.setitimer(signal.ITIMER_REAL, plan['seconds'])
    try:
        result = collect(plan, phases)
    except Exception as exc:
        result = dict(status='failed_or_unknown_read_only_collection', failure_type=type(exc).__name__, failure=str(exc),
                      requested_phases=phases, searches=0, training_episodes=0, native_queries=0)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    result.update(collector_plan_sha256=file_sha(OUT/'plan.json'), collector_seconds_before_receipt_write=time.perf_counter()-began,
                  collector_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    if result['collector_seconds_before_receipt_write'] > plan['seconds'] or result['collector_peak_rss_bytes'] > plan['rss_bytes']:
        result['status'] = 'unknown_collector_resource_budget'
    write_new(path, result)
    print(json.dumps(dict(status=result['status'], path=str(path.relative_to(ROOT)), sha256=file_sha(path),
        seconds=result['collector_seconds_before_receipt_write'], peak_rss_bytes=result['collector_peak_rss_bytes'])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--freeze-fixtures', action='store_true');mode.add_argument('--fixtures', action='store_true')
    mode.add_argument('--freeze', action='store_true');mode.add_argument('--collect', action='store_true')
    parser.add_argument('--phases', nargs='+', choices=('effect','training','evaluation'), default=['effect','training','evaluation'])
    parser.add_argument('--name', default='snapshot')
    args = parser.parse_args()
    if args.freeze_fixtures:freeze(True)
    elif args.fixtures:fixtures()
    elif args.freeze:freeze(False)
    else:main(args.phases, args.name)
