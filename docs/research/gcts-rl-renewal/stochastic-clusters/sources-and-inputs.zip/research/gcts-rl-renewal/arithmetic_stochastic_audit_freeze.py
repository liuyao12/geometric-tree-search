"""Freeze source and already terminal trace inputs before independent replay."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.gcts-active/arithmetic-stochastic-clusters-20261011'
OUT = BASE / 'execution-v2'
PLAN = BASE / 'experiment-plan-v2.json'


def pin(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def closure():
    found = {}
    def walk(path):
        key = str(path.relative_to(ROOT))
        if key in found:
            return
        data = path.read_bytes()
        found[key] = hashlib.sha256(data).hexdigest()
        for node in ast.walk(ast.parse(data)):
            names = [node.module] if isinstance(node, ast.ImportFrom) and node.module else [x.name for x in node.names] if isinstance(node, ast.Import) else []
            for name in names:
                candidate = path.parent / (name.split('.')[0] + '.py')
                if candidate.exists():
                    walk(candidate)
    for name in ('arithmetic_stochastic_audit_worker.py', 'arithmetic_stochastic_audit_stage.py', 'arithmetic_stochastic_audit_freeze.py'):
        walk(ROOT / 'research/gcts-rl-renewal' / name)
    return found


def main(phase):
    experiment = json.loads(PLAN.read_bytes())
    folder = OUT / phase
    phase_receipt = json.loads((folder / 'phase-summary.json').read_bytes())
    if phase_receipt['status'] != 'complete_phase_pending_independent_audit' or phase_receipt['unexecuted']:
        raise ValueError('all fresh producer observations must pass the phase gate first')
    jobs = [job for job in experiment['observations'] if job['phase'] == phase]
    budget = {'effect': 90, 'training': 180, 'evaluation': 780}[phase]
    seconds = {'effect': 85, 'training': 25, 'evaluation': 115}[phase]
    life = {'effect': 90, 'training': 30, 'evaluation': 120}[phase]
    sources = closure()
    common = dict(experiment_plan=str(PLAN.relative_to(ROOT)),
        model_path='.gcts-active/commutativity13-20261011/model13.json.gz',
        catalog_path='.gcts-active/commutativity-receptors-20261011/attempt-02/two-lemmas-retained-core.json.gz',
        registry_path='.gcts-active/commutativity-receptors-20261011/native-complete/registry.json.gz',
        rss_bytes=536870912)
    phase_plan = dict(status='frozen_before_complete_actual_trace_replay', phase=phase,
        folder=str(folder.relative_to(ROOT)), seconds=budget, rss_bytes=536870912,
        source_sha256=sources, input_sha256={}, jobs=[],
        native_queries=0, searches=0, training_episodes=0,
        scope='Actual engine observation replay only; no proof search, native query, theorem transfer or learned-marking admission.')
    for job in jobs:
        name = job['id']
        paths = [PLAN, folder / 'phase-summary.json', folder / (name + '-search.json.gz'),
                 folder / (name + '-summary.json'), folder / (name + '-lifetime.json')]
        paths += [ROOT / common[k] for k in ('model_path', 'catalog_path', 'registry_path')]
        plan = dict(common, source_sha256=sources, job=name, seconds=seconds,
            trace_path=str((folder / (name + '-search.json.gz')).relative_to(ROOT)),
            lifetime_path=str((folder / (name + '-lifetime.json')).relative_to(ROOT)),
            output_path=str((folder / (name + '-audit.json')).relative_to(ROOT)))
        if phase == 'training':
            transition = folder / (name + '-policy.json')
            plan['transition_path'] = str(transition.relative_to(ROOT))
            paths.append(transition)
            if job['episode'] > 1:
                previous = folder / ('train-%02d-policy.json' % (job['episode'] - 1))
                plan['previous_transition_path'] = str(previous.relative_to(ROOT))
                paths.append(previous)
        if job['mode'] == 'trained':
            for key, path in [('policy_path', OUT / 'training/policy-final.json'),
                              ('training_audit_path', OUT / 'training/independent-audit.json')]:
                plan[key] = str(path.relative_to(ROOT))
                paths.append(path)
        plan['input_sha256'] = {str(p.relative_to(ROOT)): pin(p) for p in paths}
        destination = folder / (name + '-audit-plan.json')
        if destination.exists():
            raise ValueError('immutable audit plan exists')
        destination.write_text(json.dumps(plan, indent=2) + '\n')
        phase_plan['input_sha256'].update(plan['input_sha256'])
        phase_plan['jobs'].append(dict(job=name, plan_path=str(destination.relative_to(ROOT)),
            plan_sha256=pin(destination), output_path=plan['output_path'], lifecycle_seconds=life))
    if phase == 'training':
        policy = folder / 'policy-final.json'
        phase_plan['policy_path'] = str(policy.relative_to(ROOT))
        phase_plan['input_sha256'][phase_plan['policy_path']] = pin(policy)
    destination = folder / 'independent-audit-plan.json'
    if destination.exists():
        raise ValueError('immutable phase audit plan exists')
    destination.write_text(json.dumps(phase_plan, indent=2) + '\n')
    print(json.dumps(dict(status=phase_plan['status'], jobs=len(jobs), sources=len(sources),
                         path=str(destination), sha256=pin(destination))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('effect', 'training', 'evaluation'), required=True)
    main(parser.parse_args().phase)
