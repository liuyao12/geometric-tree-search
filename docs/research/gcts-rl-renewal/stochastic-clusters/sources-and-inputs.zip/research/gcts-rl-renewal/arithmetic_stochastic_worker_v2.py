"""One prospectively authorized observation; no native queries or proof seeds."""
import argparse
import copy
import gc
import gzip
import hashlib
import json
import resource
import signal
import time
from pathlib import Path
from commutativity_cluster_points import Model
from commutativity13_runner import binding
from commutativity13_json import save
from arithmetic_stochastic_features_v2 import canonical, episode_return, update
from arithmetic_stochastic_search_v2 import search

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'.gcts-active/arithmetic-stochastic-clusters-20261011'
PARENT = ROOT/'.gcts-active/commutativity-receptors-20261011'


def load(path):
    with gzip.open(path, 'rt') as stream:
        return json.load(stream)


def check(plan):
    for path, digest in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != digest:
            raise ValueError('frozen stochastic experiment binding '+path)


def activation(plan_path, phase):
    declared = json.loads((OUT/'activation.json').read_text())
    if declared['status'] != 'authorized_by_root_after_independent_review' or declared['plan_sha256'] != hashlib.sha256(plan_path.read_bytes()).hexdigest() or phase not in declared['approved_phases']:
        raise ValueError('root review and phase activation required')
    required = {'effect': [], 'training': ['effect/independent-audit.json'],
                'evaluation': ['training/independent-audit.json', 'training/policy-final.json']}[phase]
    pins = declared['prerequisite_sha256'].get(phase, {})
    for name in required:
        path = OUT/name
        relative = str(path.relative_to(ROOT))
        if relative not in pins or hashlib.sha256(path.read_bytes()).hexdigest() != pins[relative]:
            raise ValueError('root frozen phase prerequisite '+relative)
    for path, digest in pins.items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != digest:
            raise ValueError('root exact prerequisite '+path)


def interrupt(*args):
    raise TimeoutError('unknown_complete_observation_lifecycle_budget')


def main(name):
    began = time.perf_counter()
    plan_path = OUT/'experiment-plan.json'
    plan = json.loads(plan_path.read_text())
    job = next(job for job in plan['observations'] if job['id'] == name)
    activation(plan_path, job['phase'])
    check(plan)
    folder = OUT/job['phase'];folder.mkdir(exist_ok=True)
    for suffix in ('-checkpoint.json', '-search.json.gz', '-summary.json', '-policy.json'):
        if (folder/(name+suffix)).exists():
            raise ValueError('single-execution worker refuses existing artifact '+name+suffix)
    result = dict(id=name, status='running_observation', phase=job['phase'],
                  native_queries=0, target_searches=0,
                  plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest())
    signal.signal(signal.SIGALRM, interrupt)
    signal.signal(signal.SIGUSR1, interrupt)
    signal.setitimer(signal.ITIMER_REAL, job['lifecycle_seconds'])
    try:
        if job['phase'] == 'training':
            gate = json.loads((OUT/'effect/independent-audit.json').read_text())
            if gate['status'] != 'passed_complete_action_effect_graph_and_policy_gate':
                raise ValueError('actual visited action effect and independent graph gate required')
            if job['episode'] == 1:
                weights, baseline = {}, 0.
            else:
                previous = json.loads((folder/('train-%02d-policy.json' % (job['episode']-1))).read_text())
                weights, baseline = previous['weights_after'], previous['baseline_after']
        elif job['mode'] == 'trained':
            gate = json.loads((OUT/'training/independent-audit.json').read_text())
            if gate['status'] != 'passed_complete_training_graph_rng_and_updates':
                raise ValueError('complete training audit before trained evaluation')
            policy = json.loads((OUT/'training/policy-final.json').read_text())
            if hashlib.sha256(canonical(policy['weights'])).hexdigest() != gate['weights_sha256']:
                raise ValueError('independently audited frozen trained weights')
            weights, baseline = policy['weights'], policy['baseline']
        else:
            weights, baseline = {}, 0.
        spec = copy.deepcopy(plan['case'])
        registry_path = PARENT/'native-complete/registry.json.gz'
        stage = time.perf_counter()
        model = Model(spec, load(PARENT/'attempt-02/two-lemmas-retained-core.json.gz'),
                      load(registry_path), json.loads((PARENT/'native-complete/registry-audit.json').read_text()), registry_path.read_bytes())
        result['model_setup_seconds'] = time.perf_counter()-stage
        stage = time.perf_counter()
        record = model.record()
        digest = hashlib.sha256(canonical(binding(record, model.domains, 13))).hexdigest()
        if digest != plan['complete_model_sha256']:
            raise ValueError('unchanged complete 13-row model across all phases and lanes')
        result['model_binding_seconds'] = time.perf_counter()-stage
        del record;gc.collect()
        result['target_searches'] = 1
        observed = search(model, mode=job['mode'], weights=weights, seed=job['seed'],
                          attempts=job['attempts'], seconds=job['search_seconds'],
                          proposal_limit=24, proposal_checks=2048, rss_bytes=plan['rss_bytes'])
        checkpoint = dict(id=name, case=spec, observation=job, search_status=observed['status'],
                          metrics=observed['metrics'], proof=observed['proof'], placements=observed['placements'],
                          complete_model_sha256=digest, native_queries=0,
                          weights_sha256=observed['weights_sha256'], discovery='GCTS search only if independently replayed')
        (folder/(name+'-checkpoint.json')).write_text(json.dumps(checkpoint, indent=2)+'\n')
        stage = time.perf_counter()
        save(folder/(name+'-search.json.gz'), dict(case=spec, observation=job, search=observed,
                                                complete_model_sha256=digest, native_queries=0))
        result['trace_serialization_seconds'] = time.perf_counter()-stage
        result.update(status='complete_observation_pending_independent_audit', search_status=observed['status'],
                      metrics=observed['metrics'], proof_rows=len(observed['proof']) if observed['proof'] else None,
                      search_seconds=observed['seconds'], proposer_initialization_seconds=observed['proposer_initialization_seconds'],
                      feature_initialization_seconds=observed['feature_initialization_seconds'],
                      complete_model_sha256=digest, weights_sha256=observed['weights_sha256'],
                      search_wall_overshoot_seconds=max(0, observed['seconds']-job['search_seconds']))
        if job['phase'] == 'training':
            stage = time.perf_counter()
            value = episode_return(observed['metrics'])
            after, new_baseline, details = update(weights, observed['events'], value, baseline)
            transition = dict(episode=job['episode'], seed=job['seed'], weights_before=weights,
                              weights_after=after, baseline_after=new_baseline,
                              search_sha256=hashlib.sha256((folder/(name+'-search.json.gz')).read_bytes()).hexdigest(),
                              update=details, adaptation='same-instance on-policy, episode-averaged clipped REINFORCE heuristic')
            (folder/(name+'-policy.json')).write_text(json.dumps(transition, indent=2)+'\n')
            result['update_seconds'] = time.perf_counter()-stage
            if job['episode'] == plan['training_episodes']:
                (folder/'policy-final.json').write_text(json.dumps(dict(weights=after, baseline=new_baseline,
                     origin='eight fresh full-13 engine-generated training observations; independently audited before evaluation'), indent=2)+'\n')
    except (ValueError, TimeoutError, MemoryError, OSError) as exc:
        result.update(status='unknown_or_failed_observation', failure_type=type(exc).__name__, failure=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGUSR1, signal.SIG_IGN)
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        elapsed = time.perf_counter()-began
        result.update(worker_seconds_before_final_receipt_write=elapsed, kernel_worker_peak_bytes=peak,
                      lifecycle_wall_overshoot_seconds=max(0, elapsed-job['lifecycle_seconds']),
                      memory_overshoot_bytes=max(0, peak-plan['rss_bytes']))
        if result['lifecycle_wall_overshoot_seconds'] or result['memory_overshoot_bytes']:
            result['status'] = 'unknown_observation_resource_budget'
        (folder/(name+'-summary.json')).write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser();parser.add_argument('--job', required=True)
    main(parser.parse_args().job)
