"""Registry-authorized wrapper; unchanged complete scalar point construction."""
import hashlib
from certificate_boundary_search import canonical
from induction_receptors_points import Model as ExactModel


class Model(ExactModel):
    def __init__(self, spec, catalog, registry, audit, registry_bytes):
        if audit['status'] != 'passed_complete_exact94_native_admission_registry':
            raise ValueError('complete independent registry audit required')
        h = hashlib.sha256(registry_bytes).hexdigest()
        if audit['registry_sha256'] != h or registry['theory'] != spec['theory'] or registry['target'] != spec['target']:
            raise ValueError('exact registry/theory/target binding')
        declared = {d['name']: canonical(d) for d in catalog['definitions']}
        admitted = {d['name']: canonical(d['definition']) for d in registry['definitions'] if d['status'] == 'native_accepted'}
        if len(declared) != 94 or len(admitted) != 94 or declared != admitted:
            raise ValueError('entire exact native definition inventory')
        super().__init__(spec, catalog, dict(status='native_accepted', registry_sha256=h))
        self.registry_sha256 = h
        self.promoted_rules = {i for i, r in enumerate(self.rules) if r['description']['operation'] == 'transferred-searched-theorem'}

    def record(self):
        record = super().record()
        record.update(registry_sha256=self.registry_sha256, promoted_rules=sorted(self.promoted_rules))
        return record
