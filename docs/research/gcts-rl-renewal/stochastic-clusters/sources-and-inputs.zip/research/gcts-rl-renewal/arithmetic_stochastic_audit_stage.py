"""Bounded owned replay workers and fail-closed phase assembly; no search."""
import argparse
import hashlib
import json
import resource
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main(plan_path):
    began = time.perf_counter()
    plan = json.loads(plan_path.read_bytes())
    folder = ROOT / plan['folder']
    destination = folder / 'independent-audit.json'
    if destination.exists():
        raise ValueError('immutable independent phase receipt exists')
    for p, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != h:
            raise ValueError('frozen independent phase binding ' + p)
    result = dict(status='checking_independent_phase', phase=plan['phase'],
                  plan_sha256=hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                  observations=[], unexecuted=[job['job'] for job in plan['jobs']],
                  searches=0, training_episodes=0, native_queries=0)
    for job in plan['jobs']:
        remaining = plan['seconds'] - (time.perf_counter() - began)
        if remaining <= 0:
            result['status'] = 'unknown_independent_phase_budget'
            break
        path = ROOT / job['plan_path']
        if hashlib.sha256(path.read_bytes()).hexdigest() != job['plan_sha256']:
            raise ValueError('immutable observation audit plan')
        result['unexecuted'].remove(job['job'])
        output = ROOT / job['output_path']
        start = time.perf_counter()
        terminal, failure = None, None
        with (folder / (job['job'] + '-audit-stdout.txt')).open('xb') as stdout, (folder / (job['job'] + '-audit-stderr.txt')).open('xb') as stderr:
            child = subprocess.Popen([sys.executable, str(ROOT / 'research/gcts-rl-renewal/arithmetic_stochastic_audit_worker.py'), '--plan', str(path)],
                                     cwd=ROOT, stdout=stdout, stderr=stderr)
            try:
                terminal = child.wait(timeout=min(remaining, job['lifecycle_seconds']))
            except subprocess.TimeoutExpired:
                child.kill()
                terminal = child.wait()
                failure = 'audit_lifetime_timeout'
        seconds = time.perf_counter() - start
        try:
            receipt = json.loads(output.read_bytes())
        except (ValueError, OSError):
            receipt = None
            failure = failure or 'missing_or_invalid_worker_receipt'
        conservative = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        passed = (terminal == 0 and failure is None and receipt is not None
                  and receipt['status'] == 'passed_complete_actual_graph_rng_and_policy_replay'
                  and seconds <= job['lifecycle_seconds'] and conservative <= plan['rss_bytes'])
        lifetime = dict(job=job['job'], status='passed_complete_replay_lifetime' if passed else 'unknown_or_failed_replay_lifetime',
                        pid=child.pid, exit_code=terminal, terminal_and_reaped=True, failure=failure,
                        full_worker_seconds=seconds, conservative_owner_plus_child_kernel_peak_bytes=conservative,
                        receipt_sha256=hashlib.sha256(output.read_bytes()).hexdigest() if output.exists() else None,
                        resource_semantics='Wall timeout kills/reaps this pure audit child; conservative kernel peak gate after exit. No hard OS memory cap, no external RSS sample claim.')
        (folder / (job['job'] + '-audit-lifetime.json')).write_text(json.dumps(lifetime, indent=2) + '\n')
        result['observations'].append(dict(lifetime=lifetime, replay=receipt))
        if not passed:
            result['status'] = 'unknown_or_failed_independent_phase'
            break
    else:
        result['status'] = {'effect': 'passed_complete_action_effect_graph_and_policy_gate',
                            'training': 'passed_complete_training_graph_rng_and_updates',
                            'evaluation': 'passed_complete_balanced_evaluation_graph_rng_and_policy'}[plan['phase']]
        if plan['phase'] == 'training':
            policy = json.loads((ROOT / plan['policy_path']).read_bytes())
            value = hashlib.sha256(json.dumps(policy['weights'], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
            if value != result['observations'][-1]['replay']['weights_after_sha256']:
                result['status'] = 'failed_final_policy_identity'
            result['weights_sha256'] = value
    result.update(seconds_before_final_phase_receipt_write=time.perf_counter() - began,
                  conservative_owner_plus_child_kernel_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    if result['seconds_before_final_phase_receipt_write'] > plan['seconds'] or result['conservative_owner_plus_child_kernel_peak_bytes'] > plan['rss_bytes']:
        result['status'] = 'unknown_independent_phase_resource_budget'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'observations'}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    main(Path(parser.parse_args().plan))
