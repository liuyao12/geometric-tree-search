"""Streaming reversible array interning before JSON parsing.

Quoted tokens are copied intact, including across chunks. Every complete array
of four integers is replaced by a reserved string reference and restored to the
exact ordered tuple. Original strings using that reserved prefix fail closed.
Original trace bytes are read only. No candidate, node or scalar is omitted.
"""
import gzip
import json
import re
import tempfile
from pathlib import Path

TOKEN = re.compile(rb'(?P<string>"(?:[^"\\]|\\.)*")|(?P<partial>"(?:[^"\\]|\\.)*(?:\\)?$)|\[\s*(?P<a>-?\d+)\s*,\s*(?P<b>-?\d+)\s*,\s*(?P<c>-?\d+)\s*,\s*(?P<d>-?\d+)\s*\]')


def load(path):
    arrays, indexes = [], {}
    with tempfile.TemporaryFile('w+b', dir=Path(path).parent) as reduced:
        with gzip.open(path, 'rb') as source:
            pending = b''
            while True:
                part = source.read(65536)
                eof = not part
                data = pending + part
                last = 0
                for match in TOKEN.finditer(data):
                    if match.group('partial') is not None:
                        break
                    reduced.write(data[last:match.start()])
                    if match.group('string') is not None:
                        original = match.group('string')
                        if json.loads(original).startswith('#'):
                            raise ValueError('reserved interning string collision')
                        reduced.write(original)
                    else:
                        key = tuple(int(match.group(name)) for name in ('a', 'b', 'c', 'd'))
                        index = indexes.get(key)
                        if index is None:
                            index = len(arrays)
                            indexes[key] = index
                            arrays.append(key)
                        reduced.write(('"#%d"' % index).encode())
                    last = match.end()
                pending = data[last:]
                if eof:
                    reduced.write(pending)
                    break
                if len(pending) > 2097152:
                    raise ValueError('unknown_decoder_long_token_resource_budget')
        reduced.seek(0)

        def restore(value):
            if isinstance(value, str) and value.startswith('#'):
                index = int(value[1:])
                if str(index) != value[1:] or not 0 <= index < len(arrays):
                    raise ValueError('invalid reversible array reference')
                return arrays[index]
            if isinstance(value, list):
                return [restore(x) if not isinstance(x, dict) else x for x in value]
            return value

        def hook(obj):
            return {key: restore(value) for key, value in obj.items()}

        return json.load(reduced, object_hook=hook)
