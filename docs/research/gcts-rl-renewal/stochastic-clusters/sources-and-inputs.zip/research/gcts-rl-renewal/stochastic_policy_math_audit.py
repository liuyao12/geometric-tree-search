"""Independent numerical checks for the prospective epsilon-softmax policy.

This does not import a search, feature builder, training implementation, or
stored proof. It checks the stated mixture distribution and its log-gradient;
actual engine trajectories require a separate full graph/tree replay.
"""
import hashlib
import json
import math
import random
import time
from pathlib import Path


def probabilities(vectors, weights, epsilon, temperature):
    assert 0 <= epsilon <= 1 and temperature > 0
    assert vectors
    scores = [math.fsum(weights.get(k, 0.) * v for k, v in x.items()) / temperature
              for x in vectors]
    maximum = max(scores)
    exponents = [math.exp(s - maximum) for s in scores]
    denominator = math.fsum(exponents)
    soft = [v / denominator for v in exponents]
    mixed = [epsilon / len(vectors) + (1 - epsilon) * p for p in soft]
    return mixed, soft


def log_gradient(vectors, weights, chosen, epsilon, temperature):
    mixed, soft = probabilities(vectors, weights, epsilon, temperature)
    keys = set(weights).union(*(set(x) for x in vectors))
    factor = (1 - epsilon) * soft[chosen] / mixed[chosen] / temperature
    return {k: factor * (vectors[chosen].get(k, 0.) -
                         math.fsum(p * x.get(k, 0.) for p, x in zip(soft, vectors)))
            for k in keys}


def controls():
    cases = [
        ([{'a': 1., 'source': -2.}, {'a': 1., 'source': 3.}, {}],
         {'a': .7, 'source': -.3}, .1, 1.),
        ([{'a': 1.}, {'a': 1.}, {'a': 1.}], {'a': 4.}, .1, 1.),
        ([{'a': -1.}, {'a': 2.}, {'b': 1.}], {'a': -.2, 'b': .8}, 0., 2.),
        ([{'a': 0.}, {'a': 2.}, {}], {'a': .5}, 1., 1.),
        ([{'a': 1.}, {'a': -1.}, {}], {'a': 4.}, .1, .5),
    ]
    rows = []
    for vectors, weights, epsilon, temperature in cases:
        mixed, soft = probabilities(vectors, weights, epsilon, temperature)
        assert all(math.isfinite(p) and 0 < p <= 1 for p in mixed)
        assert abs(math.fsum(mixed) - 1) < 1e-14
        for chosen in range(len(vectors)):
            derivative = log_gradient(vectors, weights, chosen, epsilon, temperature)
            for key, expected in sorted(derivative.items()):
                step = 1e-5
                plus, minus = dict(weights), dict(weights)
                plus[key] = plus.get(key, 0.) + step
                minus[key] = minus.get(key, 0.) - step
                upper = math.log(probabilities(vectors, plus, epsilon, temperature)[0][chosen])
                lower = math.log(probabilities(vectors, minus, epsilon, temperature)[0][chosen])
                numerical = (upper - lower) / (2 * step)
                assert abs(numerical - expected) < 1e-8
                rows.append(dict(epsilon=epsilon, temperature=temperature, chosen=chosen,
                                 feature=key, analytic=expected, numerical=numerical))
        # The mixture of uniform and uniform is uniform. Duplicate feature
        # vectors remain distinct proposals: this is not a first-action quotient.
        zero, _ = probabilities(vectors, {}, epsilon, temperature)
        assert all(abs(p - 1 / len(vectors)) < 1e-15 for p in zero)
    # One random draw selects a categorical action through cumulative intervals.
    rng = random.Random(27001)
    draws = [rng.random() for _ in range(5)]
    replay = random.Random(27001)
    assert draws == [replay.random() for _ in range(5)]
    # A useful negative control: ordinary softmax gradient is incorrect for
    # epsilon-mixture log probabilities when epsilon is nonzero.
    vectors, weights, epsilon, temperature = cases[0]
    mixed, soft = probabilities(vectors, weights, epsilon, temperature)
    correct = log_gradient(vectors, weights, 0, epsilon, temperature)['source']
    uncorrected = vectors[0]['source'] - math.fsum(p * x.get('source', 0.)
                                                               for p, x in zip(soft, vectors))
    assert abs(correct - uncorrected) > .01
    return dict(status='passed_independent_epsilon_mixture_math_controls',
                numerical_derivatives=len(rows), derivatives=rows,
                ordinary_softmax_gradient_mutant_rejected=True,
                zero_weights_uniform=True, duplicate_proposals_not_merged=True,
                searches=0, training_episodes=0, native_queries=0,
                scope='Distribution/log-gradient numerical controls only; no producer '
                      'source, actual feature, engine, or training-update validation.')


def main():
    began = time.perf_counter()
    result = controls()
    result['seconds'] = time.perf_counter() - began
    result['source_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out = Path(__file__).resolve().parents[2] / '.gcts-active/primitive-policy-program-20261011'
    assert out.is_dir()
    (out / 'policy-math-controls.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'derivatives'}))


if __name__ == '__main__':
    main()
