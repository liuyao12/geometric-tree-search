"""Independent literal graph, sparse features, RNG and learning-update replay.

Imports only pre-existing independent audit helpers and the root's numerical
policy audit. No stochastic producer, feature, search or worker is imported.
The input is an actual saved trace; this program does not search for a proof.
"""
import collections
import copy
import gzip
import hashlib
import json
import math
import random
import resource
import signal
import sys
import time
from pathlib import Path
from commutativity_cluster_audit import (initial, families, proposals, features,
                                        refs, same, need, model_binding, packed)
from audit_semantic_inventory import LiteralDomains, legal, advance
from audit_native_receptor_points import state_pin
from stochastic_policy_math_audit import probabilities, log_gradient

ROOT = Path(__file__).resolve().parents[2]
LEGACY = ('family', 'base_growth', 'novel_formula', 'justified_inputs',
          'target_output', 'mark_extension', 'shape_density', 'complete_rows', 'defer')


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def load(path):
    with (gzip.open(path, 'rt') if path.suffix == '.gz' else path.open('r')) as stream:
        return json.load(stream)


def near(actual, expected, label):
    if isinstance(expected, dict):
        need(set(actual) == set(expected), label + ' keys')
        for key in expected:
            near(actual[key], expected[key], label + '/' + key)
    elif isinstance(expected, list):
        need(len(actual) == len(expected), label + ' length')
        for a, e in zip(actual, expected):
            near(a, e, label)
    elif type(expected) is float:
        need(type(actual) in (int, float) and math.isfinite(actual)
             and math.isclose(actual, expected, rel_tol=2e-11, abs_tol=2e-12), label)
    else:
        need(actual == expected, label)


class LiteralFeatures:
    def __init__(self, inventory, rules, spec):
        self.inventory, self.rules, self.spec = inventory, rules, spec
        self.support, self.values, self.alignments = {}, {}, collections.Counter()
        for key, tile in inventory.items():
            for p, _ in tile['occupancy']:
                self.alignments[tuple(p)] += 1
            for p, value in tile['marks']:
                p = tuple(p)
                self.support.setdefault(p, set()).add(key)
                self.values.setdefault((p, value), set()).add(key)
        self.memberships = sum(map(len, self.support.values()))

    def vectors(self, items, state, domains, point):
        legal_keys = set().union(*map(set, domains.values()))
        selected_roles = {(key[0], key[1]) for key in state['selected']}
        out, work = [], collections.Counter()
        for item in items:
            old = features(item, self.inventory, self.rules, self.spec, state)
            v = {'legacy:' + name: float(x) for name, x in zip(LEGACY, old)}
            if item is None:
                out.append(dict(sorted(v.items())))
                continue
            members, pending = map(lambda xs: [tuple(k) for k in xs],
                                   (item['members'], item['pending']))
            anchor = point[0] // 4
            sources = []
            for key in members:
                slot, role = key[:2]
                tile = self.inventory[key]
                relative = slot - anchor
                if role < 2:
                    v['command:%d:%d:%s' % (relative, role, sha(tile['command']))] = 1.
                if role == 1:
                    operation = self.rules[tile['inference']]['description']['operation']
                    v['guard:%d:%s:%s' % (relative, operation, sha(tile['command']['formula']))] = 1.
                if role >= 2:
                    source = tile['source']
                    delta = 'unused' if source is None else str(source - slot)
                    premise = tile['requirements'][0][1] if tile['requirements'] else None
                    v['port:%d:%d:%s:%s' % (relative, role - 2, delta, sha(premise))] = 1.
                    if source is not None:
                        fp = (4 * source + 2, 0)
                        assigned = fp in state['marks']
                        expected = dict((tuple(p), value) for p, value in tile['marks'])[fp]
                        source_values = [sum((source, r) in selected_roles for r in range(4)) / 4,
                                         float(assigned), float(assigned and state['marks'][fp] == expected)]
                        source_values += [len(domains.get((4 * source, r), ())) /
                                          max(1, self.alignments[4 * source, r]) for r in range(4)]
                        sources.append(source_values)
                        work['source_port_queries'] += 1
            v['pending_fraction'] = len(pending) / max(1, len(members))
            v['landing_degree_fraction'] = len(domains[point]) / max(1, self.alignments[point])
            names = ('source_occupied_roles', 'source_formula_assigned', 'source_formula_agrees',
                     'source_C_domain', 'source_G_domain', 'source_I1_domain', 'source_I2_domain')
            for index, name in enumerate(names):
                v[name] = sum(x[index] for x in sources) / max(1, len(sources))
            marking = {}
            for key in pending:
                for p, value in self.inventory[key]['marks']:
                    p = tuple(p)
                    need(p not in marking or marking[p] == value, 'compatible proposed marking')
                    marking[p] = value
            disagree, agree, remote = set(), set(), 0
            for p, value in sorted(marking.items()):
                support = self.support.get(p, set())
                equal = self.values.get((p, value), set())
                work['mark_neighborhood_queries'] += 1
                work['mark_dependency_memberships_examined'] += len(support)
                agree |= equal & legal_keys
                if p not in state['marks']:
                    disagree |= (support - equal) & legal_keys
                remote += int(p not in state['roots'])
            touched = {tuple(p) for key in disagree for p, value in self.inventory[key]['occupancy']
                       if tuple(p) in domains and value > 0}
            v.update(mark_conflicting_candidate_fraction=len(disagree) / max(1, len(legal_keys)),
                     mark_agreeing_candidate_fraction=len(agree) / max(1, len(legal_keys)),
                     mark_impacted_frontier_fraction=len(touched) / max(1, len(state['roots'])),
                     mark_remote_support_fraction=remote / max(1, len(marking)),
                     mark_already_assigned_fraction=sum(p in state['marks'] for p in marking) / max(1, len(marking)))
            out.append(dict(sorted(v.items())))
        return out, dict(work)


def tree(spec, model, result, declared_families):
    inventory = {tuple(tile['key']): tile for tile in model['placements']}
    domains_of = LiteralDomains(inventory)
    root, metrics = initial(model), collections.Counter()
    feature_index = LiteralFeatures(inventory, model['inference_rules'], spec) if result['mode'] != 'base' else None
    events, hints = result['events'], result['hints']
    rng = random.Random(result['seed'])
    weights = result['weights']
    need(result['weights_sha256'] == sha(weights), 'weights identity')
    if result['mode'] == 'untrained':
        need(not any(weights.values()), 'untrained zero weights')
    need(result['stochastic'] == (result['mode'] != 'base'), 'declared stochastic lane')
    if result['mode'] == 'base':
        need(not any(weights.values()), 'baseline zero weights')
    ei = hi = 0
    found = None

    def review(state, domains, hint, point):
        if hint is None:
            return None, dict(phase='absent', pending=[], eligible=[])
        pending = [tuple(k) for k in hint['item']['members'] if tuple(k) not in state['selected']]
        if not pending:
            return None, dict(phase='completed', pending=[], eligible=[])
        bad = [k for k in pending if not legal(inventory[k], state)]
        if bad:
            return None, dict(phase='invalid', pending=pending, illegal=bad, eligible=[])
        eligible = [k for k in pending if k in domains.get(point, [])]
        return hint, dict(phase='eligible' if eligible else 'waiting', pending=pending, eligible=eligible)

    def visit(state, node, hint):
        nonlocal ei, hi, found
        metrics['nodes'] += 1
        domains = domains_of(state)
        census = [dict(point=p, generation=state['generations'][p], keys=keys) for p, keys in sorted(domains.items())]
        need(same(node['census'], census) and node['state_sha256'] == state_pin(state), 'complete literal graph/state')
        satisfied = sum(state['totals'].get(p, 0) == 12 for p in state['roots'])
        need(node['satisfied_points'] == satisfied, 'actual satisfied obligations')
        metrics['max_satisfied_points'] = max(metrics['max_satisfied_points'], satisfied)
        dead = sorted(p for p, keys in domains.items() if not keys)
        forced = sorted(p for p, keys in domains.items() if len(keys) == 1)
        if dead:
            kind, point = 'dead', dead[0]
        elif forced:
            kind, point = 'forced', forced[0]
        elif not domains:
            kind, point = 'empty', None
        else:
            kind, point = 'branch', min(domains, key=lambda p: (state['generations'][p], len(domains[p]), p))
        need(node['kind'] == kind and same(node['point'], point), 'global dead/forced/earliest generation')
        need(node['hint_in'] == (hint['id'] if hint else None), 'local hint inheritance')
        active, status = review(state, domains, hint, point)
        need(same(node['review'], status), 'hint retirement/waiting/eligibility')
        if hint:
            metrics['hint_' + status['phase']] += 1
        if kind in ('dead', 'empty'):
            need(not node['children'] and 'policy_event' not in node, 'terminal before policy')
            if kind == 'dead':
                metrics['dead'] += 1
                return False
            found = state
            return True
        metrics[kind] += 1
        if kind == 'branch' and active is None and result['mode'] != 'base':
            need(node['policy_event'] == ei and ei < len(events), 'each stochastic event')
            event = events[ei]
            items, work = proposals(inventory, model['inference_rules'], declared_families, state, domains,
                                    point, result['limits']['proposal_limit'], result['limits']['proposal_checks'])
            vectors, feature_work = feature_index.vectors(items, state, domains, point)
            need(same(event['items'], items) and same(event['work'], work), 'exact independent proposals/work')
            near(event['features'], vectors, 'every independent feature')
            need(event['feature_work'] == feature_work, 'all feature work counters')
            need(event['id'] == ei and event['weights_sha256'] == sha(weights)
                 and same(event['chosen'], state['order']) and same(event['point'], point), 'state-bound policy')
            need(event['epsilon'] == .1 and event['temperature'] == 1., 'frozen exploration')
            mixed, soft = probabilities(vectors, weights, .1, 1.)
            scores = [math.fsum(weights.get(k, 0.) * value for k, value in vector.items()) for vector in vectors]
            near(event['scores'], scores, 'scores')
            near(event['softmax_probabilities'], soft, 'softmax')
            near(event['probabilities'], mixed, 'epsilon mixture')
            draw, cumulative, chosen = rng.random(), 0., len(items) - 1
            need(event['uniform'] == draw, 'one exact seeded RNG draw per event')
            for i, p in enumerate(mixed):
                cumulative += p
                if draw < cumulative:
                    chosen = i
                    break
            need(event['index'] == chosen, 'actual stochastic action')
            need(same(event['base_first'], domains[point][0]) and same(event['selected_point_domain'], domains[point]), 'full domain consumed by policy')
            metrics.update(work)
            metrics.update({'features:' + k: v for k, v in feature_work.items()})
            ei += 1
            item = items[chosen]
            if item is not None:
                need(node['hint_start'] == hi and same(hints[hi], dict(id=hi, chosen=state['order'], point=point, item=item)), 'validated hint')
                active = dict(id=hi, item=item)
                hi += 1
                metrics['hints_started'] += 1
                active, status = review(state, domains, active, point)
                need(active is not None and status['eligible'] and same(node['start_review'], status), 'legal scheduler attachment')
            else:
                need('hint_start' not in node and 'start_review' not in node, 'defer has no new hint')
        else:
            need('policy_event' not in node and 'hint_start' not in node, 'global propagation/waiting before policy')
        preferred = set(status['eligible']) if active else set()
        keys = domains[point]
        alternatives = keys if kind == 'forced' else [k for k in keys if k in preferred] + [k for k in keys if k not in preferred]
        need(same(node['alternatives'], alternatives), 'complete base fallback')
        changed = kind == 'branch' and alternatives[0] != keys[0]
        if changed:
            metrics['changed_first_branches'] += 1
        for i, child in enumerate(node['children']):
            need(i < len(alternatives) and same(child['key'], alternatives[i])
                 and child['role'] == ('member' if alternatives[i] in preferred else 'base'), 'actual legal constituent')
            metrics['attempts'] += 1
            if i == 0 and changed:
                metrics['executed_changed_first_branches'] += 1
            answer = visit(advance(inventory[alternatives[i]], state), child['tree'], active)
            if answer is not False:
                need(i + 1 == len(node['children']), 'no sibling after success/unknown')
                return answer
            metrics['backtracks'] += 1
        if len(node['children']) < len(alternatives):
            limits = result['limits']
            reason = node.get('budget_reason')
            exhausted = {'attempts': metrics['attempts'] >= limits['attempts'],
                         'time': result['seconds'] >= limits['seconds'],
                         'memory': result['peak_rss_bytes'] >= limits['rss_bytes']}
            need(node.get('cutoff') == 'before_placement' and exhausted.get(reason, False), 'actual unknown budget cause')
            return None
        need('cutoff' not in node, 'exhausted all alternatives')
        return False

    answer = visit(root, result['tree'], None)
    status = 'finite_marked_proof_region' if answer else 'unknown_search_budget' if answer is None else 'exhausted_finite_marked_region'
    need(result['status'] == status and result['root_restored'] and result['root_state_sha256'] == state_pin(root), 'terminal/rollback semantics')
    actual_metrics = {k: v for k, v in result['metrics'].items() if k not in ('proposal_seconds', 'feature_seconds')}
    need(actual_metrics == dict(metrics) and ei == len(events) and hi == len(hints), 'all counters/events/hints')
    need(result['feature_index_memberships'] == (feature_index.memberships if feature_index else 0), 'complete feature index')
    need(same(result['placements'], found['order'] if found else [])
         and result['tile_generations'] == (found['tile_generations'] if found else []), 'all placements/generations')
    proof = None
    if found:
        selected = {(k[0], k[1]): k for k in found['selected']}
        proof = []
        for row in range(spec['length']):
            command = copy.deepcopy(inventory[selected[row, 0]]['command'])
            required = refs(inventory, model['inference_rules'], found['selected'], row)
            need(required is not None, 'all exact rule/port modes')
            for source, formula in required:
                need(inventory[selected[source, 0]]['command']['formula'] == formula, 'strict-prior receptor formula')
            if command['rule'] == 'block':
                command['inputs'] = [source for source, _ in required]
            elif command['rule'] == 'generalize':
                command['source'] = required[0][0]
            proof.append(command)
    need(proof == result['proof'], 'independently decoded word')
    return dict(status=status, nodes=metrics['nodes'], policy_events=ei, hints=hi,
                executed_changed_first_branches=metrics['executed_changed_first_branches'], metrics=dict(metrics))


def learning_update(result, transition):
    """Recompute the episode return and the corrected mixture score gradient."""
    m, events, weights = result['metrics'], result['events'], result['weights']
    count = max(1, m.get('attempts', 0))
    value = (m.get('max_satisfied_points', 0) / 52 - .5 * m.get('dead', 0) / count
             - .25 * m.get('backtracks', 0) / count - .1 * m.get('branch', 0) / count
             - .05 * (m.get('validation_checks', 0) + m.get('sample_pair_tests', 0)) / (2048 * count))
    baseline = transition['update']['baseline_before']
    gradient = collections.defaultdict(float)
    for event in events:
        current = log_gradient(event['features'], weights, event['index'], .1, 1.)
        # Zero-only old weight keys are not feature keys and have zero derivative.
        represented = set().union(*(set(v) for v in event['features']))
        for key in sorted(represented):
            gradient[key] += current[key] / max(1, len(events))
    advantage = value - baseline
    scaled = {k: advantage * entry for k, entry in gradient.items()}
    norm = math.sqrt(math.fsum(entry * entry for entry in scaled.values()))
    scale = min(1., 1. / max(norm, 1e-300))
    updated = dict(weights)
    for key in sorted(gradient):
        updated[key] = max(-4., min(4., weights.get(key, 0.) + .2 * scale * scaled[key]))
    updated = dict(sorted(updated.items()))
    details = dict(reward=value, baseline_before=baseline, advantage=advantage,
                   mean_score_gradient=dict(sorted(gradient.items())),
                   mean_score_gradient_norm=math.sqrt(math.fsum(x * x for x in gradient.values())),
                   advantage_scaled_gradient=dict(sorted(scaled.items())),
                   advantage_scaled_gradient_norm=norm, applied_gradient_scale=scale,
                   clipped_update_gradient_norm=norm * scale)
    near(transition['weights_before'], weights, 'training initial weights')
    near(transition['weights_after'], updated, 'all learned weights')
    near(transition['baseline_after'], .9 * baseline + .1 * value, 'EMA baseline')
    near({k: transition['update'][k] for k in details}, details, 'all update details')
    need(transition['update']['weights_after_sha256'] == sha(transition['weights_after']), 'learned weights identity')
    return details


if __name__ == '__main__':
    raise SystemExit('Library only until a separately frozen actual-trace execution plan is supplied.')
