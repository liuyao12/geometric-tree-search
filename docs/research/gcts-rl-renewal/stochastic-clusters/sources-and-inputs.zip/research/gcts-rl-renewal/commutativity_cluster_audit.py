"""Independent complete point universe, receptors, fixed features and trees.

Imports no new point model, guidance, search, preflight or runner producer.
"""
import collections
import copy
import gzip
import hashlib
import itertools
import json
import math
import resource
import time
from pathlib import Path
from induction_receptors_audit import model_binding, packed, need
from audit_semantic_inventory import LiteralDomains, legal, advance
from audit_native_inventory_policy import cluster
from audit_native_receptor_points import state_pin
from audit_certificate_boundary import pin

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / '.gcts-active/commutativity-cluster-search-20261011'
PARENT = ROOT / '.gcts-active/commutativity-receptors-20261011'
FIXED = [.7, .3, 1., .8, .2, -.1, .2, .2, 0.]


def load(path):
    with gzip.open(path, 'rt') as f:
        return json.load(f)


def same(a, b):
    return packed(a) == packed(b)


def initial(record):
    roots = {tuple(p): 0 for p in record['roots']}
    return dict(totals={}, marks={tuple(p): v for p, v in record['initial_marks']},
                generations=roots.copy(), roots=roots, selected=set(), order=[], tile_generations=[])


def families(catalog):
    roots = {packed(r['conclusion']): i for i, r in enumerate(catalog['rules'])
             if r['description']['operation'] == 'transferred-searched-theorem'}
    result = []
    for i, r in enumerate(catalog['rules']):
        if len(r['premises']) != 2 or r['description']['operation'] not in ('rewrite', 'conditional-rewrite'):
            continue
        if packed(r['premises'][1]) in roots:
            result.append(dict(root_rule=roots[packed(r['premises'][1])], rewrite_rule=i,
                               lemma_premise=1, external_premise=0,
                               scope='Proof-backed deterministic cluster family, not RL or a learned exclusion.'))
    return result


def row(inventory, rules, guards, slot, rule, sources):
    guard = guards[slot, rule]
    mode = rule + 1 if rules[rule]['premises'] else 0
    return [(slot, 0, guard[2], 0), guard] + [(slot, 2 + i, mode, sources[i] + 1 if i < len(sources) else 0) for i in range(2)]


def refs(inventory, rules, keys, slot):
    selected = {k[1]: k for k in keys if k[0] == slot}
    if set(selected) != {0, 1, 2, 3}:
        return None
    command, guard = (inventory[selected[i]] for i in (0, 1))
    if command['inference'] != guard['inference'] or command['command'] != guard['command']:
        return None
    inference = command['inference']
    premises = rules[inference]['premises']
    expected_mode = inference + 1 if premises else 0
    result = []
    for i in range(2):
        port = inventory[selected[2 + i]]
        if port['mode'] != expected_mode:
            return None
        if i < len(premises):
            if port['source'] is None or not 0 <= port['source'] < slot:
                return None
            result.append((port['source'], premises[i]))
        elif port['source'] is not None:
            return None
    return result


def features(item, inventory, rules, spec, state):
    if item is None:
        return [0.] * 8 + [1.]
    known, facts = set(), set()
    for slot in range(spec['length']):
        required = refs(inventory, rules, state['selected'], slot)
        if required is not None and all(source in known for source, formula in required):
            known.add(slot)
            guard = next(k for k in state['selected'] if k[0] == slot and k[1] == 1)
            facts.add(packed(inventory[guard]['command']['formula']))
    members = [tuple(k) for k in item['members']]
    slots = {k[0] for k in members}
    guards = [inventory[k] for k in members if k[1] == 1]
    required = [x for slot in slots for x in (refs(inventory, rules, list(state['selected']) + members, slot) or [])]
    if not required:
        required = [x for k in members for x in inventory[k]['requirements']]
    promoted = {i for i, r in enumerate(rules) if r.get('description', {}).get('operation') == 'transferred-searched-theorem'}
    return [float(any(g['inference'] in promoted for g in guards)), item['new_occupancy'] / 48,
            float(any(packed(g['command']['formula']) not in facts for g in guards)),
            sum(source in known for source, formula in required) / max(1, len(required)),
            float(any(g['command']['formula'] == spec['target'] for g in guards)),
            item['new_marks'] / 1000, len(slots) / (max(slots) - min(slots) + 1),
            sum(refs(inventory, rules, members, slot) is not None for slot in slots) / max(1, len(slots)), 0.]


def proposals(inventory, rules, declared_families, state, domains, point, limit, checks):
    anchors = domains[point]
    guards = {(k[0], c['inference']): k for k, c in inventory.items() if k[1] == 1}
    pool, seen, work = [], set(), collections.Counter()

    def emit(kind, members):
        if work['validation_checks'] >= checks or len(pool) >= limit:
            return
        work['validation_checks'] += 1
        item = cluster(inventory, members, state)
        if item is None or not any(k in anchors for k in item['pending']):
            return
        key = tuple(item['members'])
        if key in seen:
            return
        seen.add(key)
        item.update(kind=kind, level=0)
        pool.append(item)

    for family in declared_families:
        for j in range(len(state['roots']) // 4):
            if (j, family['rewrite_rule']) not in guards:
                continue
            for k in range(j):
                for source in range(j):
                    if k == source:
                        continue
                    members = row(inventory, rules, guards, k, family['root_rule'], []) + row(inventory, rules, guards, j, family['rewrite_rule'], [source, k])
                    if not any(anchor in members for anchor in anchors):
                        continue
                    emit('promoted-family', members)
                    if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                        break
                if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                    break
            if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
                break
        if work['validation_checks'] >= checks or len(pool) >= max(1, limit // 2):
            break
    work['family_pool'] = len(pool)
    occupied = {tuple(inventory[k]['occupancy'][0][0]): k for k in state['selected']}
    at = collections.defaultdict(list)
    for key, tile in sorted(inventory.items()):
        at[tuple(tile['occupancy'][0][0])].append(key)
    for anchor in anchors[:4]:
        j = anchor[0]
        for (slot, inference), guard in sorted(guards.items()):
            if slot != j:
                continue
            pair = [(j, 0, guard[2], 0), guard]
            if anchor[1] < 2 and anchor not in pair:
                continue
            if any(k not in state['selected'] and not legal(inventory[k], state) for k in pair):
                continue
            mode = inference + 1 if rules[inference]['premises'] else 0
            fields = []
            for role in (2, 3):
                p = (4 * j, role)
                keys = [occupied[p]] if p in occupied else at[p]
                fields.append([k for k in keys if inventory[k]['mode'] == mode and (k in state['selected'] or legal(inventory[k], state)) and (anchor[1] != role or k == anchor)])
            for a, b in itertools.product(*fields):
                emit('complete-row', pair + [a, b])
                if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
                    break
            if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
                break
        if work['validation_checks'] >= checks or len(pool) >= max(1, limit - 4):
            break
    work['row_pool'] = len(pool) - work['family_pool']
    legal_keys = sorted({k for keys in domains.values() for k in keys})
    for anchor in anchors[:4]:
        emit('open-shape', [anchor])
        chosen = [anchor]
        ranking = sorted(legal_keys, key=lambda k: (hashlib.sha256(packed([anchor, k])).digest(), k))
        for key in ranking:
            if key in chosen:
                continue
            if work['sample_pair_tests'] >= 64:
                break
            work['sample_pair_tests'] += 1
            if cluster(inventory, chosen + [key], state, False):
                chosen.append(key)
            if len(chosen) == 3:
                break
        if len(chosen) > 1:
            emit('open-shape', chosen)
        if work['validation_checks'] >= checks or len(pool) >= limit:
            break
    work['items'] = len(pool)
    return pool + [None], dict(work)


def tree(spec, model, result, declared_families):
    inventory = {tuple(c['key']): c for c in model['placements']}
    enumerate_domains = LiteralDomains(inventory)
    root = initial(model)
    metrics = collections.Counter()
    events, hints = result['events'], result['hints']
    ei = hi = 0
    found = None

    def review(state, domains, hint, point):
        if hint is None:
            return None, dict(phase='absent', pending=[], eligible=[])
        pending = [tuple(k) for k in hint['item']['members'] if tuple(k) not in state['selected']]
        if not pending:
            return None, dict(phase='completed', pending=[], eligible=[])
        bad = [k for k in pending if not legal(inventory[k], state)]
        if bad:
            return None, dict(phase='invalid', pending=pending, illegal=bad, eligible=[])
        eligible = [k for k in pending if k in domains.get(point, [])]
        return hint, dict(phase='eligible' if eligible else 'waiting', pending=pending, eligible=eligible)

    def visit(state, node, hint):
        nonlocal ei, hi, found
        metrics['nodes'] += 1
        domains = enumerate_domains(state)
        census = [dict(point=p, generation=state['generations'][p], keys=keys) for p, keys in sorted(domains.items())]
        need(same(node['census'], census) and node['state_sha256'] == state_pin(state), 'entire independently rebuilt graph/state')
        dead = sorted(p for p, keys in domains.items() if not keys)
        forced = sorted(p for p, keys in domains.items() if len(keys) == 1)
        if dead:
            kind, p = 'dead', dead[0]
        elif forced:
            kind, p = 'forced', forced[0]
        elif not domains:
            kind, p = 'empty', None
        else:
            kind, p = 'branch', min(domains, key=lambda p: (state['generations'][p], len(domains[p]), p))
        need(node['kind'] == kind and same(node['point'], p), 'global dead/forced/earliest generation')
        need(node['hint_in'] == (hint['id'] if hint else None), 'branch-local hint inheritance')
        active, status = review(state, domains, hint, p)
        need(same(node['review'], status), 'exact hint retirement/waiting/eligibility')
        if hint:
            metrics['hint_' + status['phase']] += 1
        if kind in ('dead', 'empty'):
            need(not node['children'] and 'policy_event' not in node, 'global terminal before policy')
            if kind == 'dead':
                metrics['dead'] += 1
                return False
            found = state
            return True
        metrics[kind] += 1
        if kind == 'branch' and active is None and result['mode'] != 'base':
            need(node['policy_event'] == ei and ei < len(events), 'each policy event')
            event = events[ei]
            items, work = proposals(inventory, model['inference_rules'], declared_families, state, domains, p, result['limits']['proposal_limit'], result['limits']['proposal_checks'])
            vectors = [features(item, inventory, model['inference_rules'], spec, state) for item in items]
            need(same(event['items'], items) and same(event['work'], work) and same(event['features'], vectors), 'independent complete bounded proposal pool/work/features')
            need(event['weights'] == FIXED and same(event['chosen'], state['order']) and same(event['point'], p), 'fixed state-bound policy')
            scores = [sum(w * x for w, x in zip(FIXED, v)) for v in vectors]
            top = max(scores)
            exp = [math.exp(x - top) for x in scores]
            prob = [x / sum(exp) for x in exp]
            need(event['scores'] == scores and event['probabilities'] == prob and event['uniform'] is None, 'fixed score distribution')
            chosen = max(range(len(scores)), key=lambda i: (scores[i], -i))
            need(event['index'] == chosen, 'deterministic chosen proposal/defer')
            for k, v in work.items():
                metrics[k] += v
            ei += 1
            item = items[chosen]
            if item is not None:
                need(node['hint_start'] == hi and same(hints[hi], dict(id=hi, chosen=state['order'], point=p, item=item)), 'exact validated hint')
                active = dict(id=hi, item=item)
                hi += 1
                metrics['hints_started'] += 1
                active, status = review(state, domains, active, p)
                need(active is not None and status['eligible'] and same(node['start_review'], status), 'scheduled cluster attachment')
        else:
            need('policy_event' not in node and 'hint_start' not in node, 'global forced/waiting before proposals')
        preferred = set(status['eligible']) if active else set()
        keys = domains[p]
        alternatives = keys if kind == 'forced' else [k for k in keys if k in preferred] + [k for k in keys if k not in preferred]
        need(same(node['alternatives'], alternatives), 'every original fallback remains in the graph')
        for i, child in enumerate(node['children']):
            need(i < len(alternatives) and same(child['key'], alternatives[i]) and child['role'] == ('member' if alternatives[i] in preferred else 'base'), 'scheduled base constituent and complete alternatives')
            metrics['attempts'] += 1
            answer = visit(advance(inventory[alternatives[i]], state), child['tree'], active)
            if answer is not False:
                need(i + 1 == len(node['children']), 'no siblings after success/unknown')
                return answer
            metrics['backtracks'] += 1
        if len(node['children']) < len(alternatives):
            limits = result['limits']
            need(node.get('cutoff') == 'before_placement' and
                 (metrics['attempts'] >= limits['attempts'] or result['seconds'] >= limits['seconds'] or result['peak_rss_bytes'] >= limits['rss_bytes']), 'unknown cutoff has actual budget evidence')
            return None
        need('cutoff' not in node, 'exhausted all alternatives')
        return False

    answer = visit(root, result['tree'], None)
    status = 'finite_marked_proof_region' if answer else 'unknown_search_budget' if answer is None else 'exhausted_finite_marked_region'
    need(result['status'] == status and result['root_restored'] and result['root_state_sha256'] == state_pin(root), 'terminal semantics/root rollback')
    need({k: v for k, v in result['metrics'].items() if k != 'proposal_seconds'} == dict(metrics) and ei == len(events) and hi == len(hints), 'every counter/event/hint')
    need(same(result['placements'], found['order'] if found else []) and result['tile_generations'] == (found['tile_generations'] if found else []), 'all actually placed base tiles/generations')
    proof = None
    if found:
        selected = {(k[0], k[1]): k for k in found['selected']}
        proof = []
        for j in range(spec['length']):
            command = copy.deepcopy(inventory[selected[j, 0]]['command'])
            required = refs(inventory, model['inference_rules'], found['selected'], j)
            need(required is not None, 'all output/guard/input modes')
            for source, f in required:
                need(inventory[selected[source, 0]]['command']['formula'] == f, 'exact strict-prior formula receptor')
            if command['rule'] == 'block':
                command['inputs'] = [source for source, f in required]
            elif command['rule'] == 'generalize':
                command['source'] = required[0][0]
            proof.append(command)
    need(proof == result['proof'], 'independently decoded complete word')
    return dict(nodes=metrics['nodes'], policy_events=ei, hints=hi, status=status)


def main():
    began = time.perf_counter()
    plan = json.loads((OUT / 'preflight-audit-plan.json').read_text())
    for path, h in {**plan['source_sha256'], **plan['input_sha256']}.items():
        need(hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == h, 'audit source/input freeze ' + path)
    raw = load(OUT / 'preflight-model.json.gz')
    catalog = load(PARENT / 'attempt-02/two-lemmas-retained-core.json.gz')
    placements = model_binding(raw['case'], catalog, raw['model'])
    inventory = {tuple(c['key']): c for c in placements}
    need(len(inventory) == 17158, 'entire retained point universe')
    registry = load(PARENT / 'native-complete/registry.json.gz')
    need({d['name']: d for d in catalog['definitions']} == {d['name']: d['definition'] for d in registry['definitions']}, 'exact admitted registry definitions')
    declared = families(catalog)
    producer = load(OUT / 'preflight-families.json.gz')
    need(declared == producer['families'] and len(declared) == 42, 'every proof-backed family form')
    guards = {(k[0], c['inference']): k for k, c in inventory.items() if k[1] == 1}
    rows = []
    for family_id, family in enumerate(declared):
        for j in range(12):
            if (j, family['rewrite_rule']) not in guards:
                continue
            for k in range(j):
                for source in range(j):
                    if k == source:
                        continue
                    keys = row(inventory, catalog['rules'], guards, k, family['root_rule'], []) + row(inventory, catalog['rules'], guards, j, family['rewrite_rule'], [source, k])
                    totals, marks = {}, {}
                    for key in keys:
                        for p, v in inventory[key]['occupancy']:
                            p = tuple(p)
                            totals[p] = totals.get(p, 0) + v
                            need(totals[p] <= 12, 'family exact occupancy')
                        for p, v in inventory[key]['marks']:
                            p = tuple(p)
                            need(p not in marks or marks[p] == v, 'family exact mark agreement')
                            marks[p] = v
                    rows.append(dict(family=family_id, row=j, lemma_row=k, source=source,
                                     aggregate=dict(keys=keys, occupancy=sorted(totals.items()), marks=sorted(marks.items()))))
    need(len(rows) == 13860 and same(rows, producer['instances']), 'all receptor/source parameters and exact aggregates')
    fixtures = load(OUT / 'preflight-fixtures.json.gz')
    state = initial(raw['model'])
    for fixture in fixtures['real_partial_fixtures']:
        child = copy.deepcopy(state)
        for key in fixture['keys']:
            tile = inventory[tuple(key)]
            need(legal(tile, child), 'real partial fixture legal')
            child = advance(tile, child)
        required = refs(inventory, catalog['rules'], child['selected'], 0 if fixture['kind'].startswith('zero') else 1)
        if fixture['kind'].startswith('zero'):
            need(required == [] and fixture['modes'] == [0, 0] and fixture['restored_parent'], 'zero-input theorem block mode and rollback')
        else:
            need(same(required, fixture['required_sources']) and fixture['wrong_zero_mode_rejected'], 'unary generalization source mode')
    primitive = fixtures['primitive_fixture']
    model_binding(primitive['case'], primitive['catalog'], primitive['model'])
    fixture_trees = [tree(primitive['case'], primitive['model'], row['search'], []) for row in primitive['tests']]
    active = {packed(f) for r in catalog['rules'] for f in r['premises'] + [r['conclusion']]}
    result = dict(status='passed_complete_graph_family_and_focused_conformance_preflight',
                  placements=17158, families=42, family_instances=13860,
                  active_output_premise_formulas=len(active), preserved_formula_id_catalog_entries=len(catalog['basis']),
                  primitive_fixture_trees=fixture_trees, target_searches=0, native_target_queries=0,
                  seconds=time.perf_counter() - began, peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  scope='Independent complete scalar point construction and every family/source aggregate; isolated zero-input/generalization modes and synthetic primitive fixed/base/fallback/rollback trees. No target search/proof/native result.')
    (OUT / 'preflight-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
