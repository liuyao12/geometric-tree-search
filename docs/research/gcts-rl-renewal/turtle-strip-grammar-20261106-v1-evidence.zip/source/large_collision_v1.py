"""Compose oriented displacement marks using exact integer rows."""
from collections import defaultdict
from functools import lru_cache

from mixed_orbits_v1 import Collision


class RowCollision(Collision):
    @lru_cache(maxsize=48)
    def dilate(self,left):
        result={}
        turns=sorted({h for _,h in self.base})
        for h in turns:
            ox=min(x+min(u for u,_ in self.base[g,h]) for g,x,_ in left)
            rows=defaultdict(int)
            for g,x,y in left:
                for a,b in self.base[g,h]:
                    rows[y+b]|=1<<(x+a-ox)
            result[h]=ox,tuple(sorted(rows.items()))
        return result

    def blocked(self,left,right):
        bands=self.dilate(left)
        xmin=min(bands[h][0]-u for h,u,_ in right)
        rows=defaultdict(int)
        for h,x,y in right:
            start,dilation=bands[h]
            offset=start-x-xmin
            for i,mask in dilation:
                rows[i-y]|=mask<<offset
        output=set()
        for y,mask in rows.items():
            while mask:
                bit=mask&-mask
                output.add((xmin+bit.bit_length()-1,y))
                mask^=bit
        return output
