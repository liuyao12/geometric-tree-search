"""Recover a strip grammar by testing competing continuations in exact seams."""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import area2, save, sub
from capped_orbits_v1 import capped
from cluster_v1 import load, mat
from collar_audit_v1 import freeze
from large_collision_v1 import RowCollision
from mixed_orbits_v1 import joined_border
from scaffold_v1 import Scaffold, centred, make
from strip_fit_v1 import attach, lane, overlap, possible_letters, receptor_bank
from word_promotion_v1 import fill_cavities, prior, signed


def apply(pattern,a,b):
    return tuple(x for register in pattern for x in (a if register=="A" else b))


def advance(rule,a,b):
    left,right=rule
    return apply(left,a,b),apply(right,a,b)


def rules(a,next_a,max_tokens=5):
    patterns=["".join(chars) for n in range(1,max_tokens+1) for chars in product("AB",repeat=n)]
    fragments={next_a[i:j] for i in range(len(next_a)) for j in range(i+1,len(next_a)+1)}
    # A rule using only A cannot explain these observed lengths.
    assert len(next_a)%len(a)
    rows=[]
    for left in patterns:
        for auxiliary in sorted(fragments):
            if apply(left,a,auxiliary)!=next_a:
                continue
            for right in patterns:
                _,b=advance((left,right),a,auxiliary)
                prediction,new_b=advance((left,right),next_a,b)
                future=apply(left,prediction,new_b)
                rows.append(dict(rule=(left,right),auxiliary=auxiliary,cost=len(left)+len(right)+len(auxiliary),
                                 next=prediction,later=future))
    return sorted(rows,key=lambda r:(r["cost"],r["rule"],r["auxiliary"]))


def prefixes(words):
    trie={}
    for word in words:
        for direction in (word,word[::-1]):
            node=trie
            for bit in direction:
                node=node.setdefault(bit,{})
            node.setdefault(None,set()).add(word)
    return trie


def flat_scan(s,frame,lanes,required,border,words):
    geom=s.geom
    admitted=defaultdict(set)
    matched=0
    for slots in lanes.values():
        for start in slots:
            for proposed in words:
                for word in dict.fromkeys((proposed,proposed[::-1])):
                    path=[]
                    hit=set()
                    for offset,bit in enumerate(word):
                        entry=slots.get(start+offset,{}).get(bit)
                        if entry is None:
                            break
                        matched+=1
                        a,b,roles=entry
                        if any(sub(p[1:],q[1:]) in s.collision.base[q[0],p[0]]
                               for q in (a,b) for left,right in path for p in (left,right)):
                            break
                        path.append((a,b))
                        hit.update(roles)
                    else:
                        if hit!=required:
                            continue
                        left,right=zip(*path,strict=True)
                        outline=joined_border((*border,(geom.boundary(left),(0,0)),
                                               (geom.boundary(right),(0,0))))
                        if outline:
                            admitted[proposed].add(tuple(sorted(t for p in (*frame,left,right) for t in p)))
    return admitted,matched


def strips(s,frame,turn,trie,words):
    geom=s.geom
    lanes,required,stride=possible_letters(s,frame,turn)
    border=[(geom.boundary(part),(0,0)) for part in frame]
    found=defaultdict(dict)
    counts=Counter(lanes=len(lanes))
    for site,slots in sorted(lanes.items()):
        for start in sorted(slots):
            pending=[(start,trie,(),(),frozenset(),())]
            while pending:
                pos,node,left,right,hit,word=pending.pop()
                if None in node and hit==required:
                    counts["full_contacts"]+=1
                    outline=joined_border((*border,(geom.boundary(left),(0,0)),(geom.boundary(right),(0,0))))
                    if outline:
                        parts=(*frame,left,right)
                        patch=tuple(sorted(t for part in parts for t in part))
                        assert len(set(patch))==len(patch)
                        row=dict(phase=turn,lane=site,first=start,word=word,pieces=parts,patch=patch,
                                 perimeter=len(outline),stride=stride)
                        for proposed in node[None]:
                            found[proposed].setdefault(patch,row)
                for bit,(tile,other,roles) in sorted(slots.get(pos,{}).items()):
                    if bit not in node:
                        continue
                    counts["prefix_checks"]+=1
                    if any(sub(p[1:],q[1:]) in s.collision.base[q[0],p[0]]
                           for q in (tile,other) for p in (*left,*right)):
                        counts["collision"]+=1
                        continue
                    pending.append((pos+1,node[bit],(*left,tile),(*right,other),hit|roles,(*word,bit)))
    flat,matched=flat_scan(s,frame,lanes,required,border,words)
    assert flat=={word:set(rows) for word,rows in found.items()}
    counts["flat_letter_matches"]=matched
    counts["compared_lanes"]=len(lanes)
    return counts,found


def cavity_key(model,cycle):
    forms=[]
    for matrix in model.groups.values():
        moved=tuple((mat(matrix,a),mat(matrix,b)) for a,b in cycle)
        if signed(moved)>0:
            moved=tuple((b,a) for a,b in moved)
        origin=min(p for edge in moved for p in edge)
        forms.append(tuple(sorted((sub(a,origin),sub(b,origin)) for a,b in moved)))
    return min(forms)


def search(s,recipe,small_cap,words,marks=None,receiver=None):
    bank=receptor_bank(s,recipe)
    phases=[s.core(g,allow_holes=True) for g in s.phases]
    best=max(c["score"] for p in phases for c in p["candidates"])
    found=defaultdict(dict)
    trie=prefixes(words)
    scan=[]
    obstructions=[]
    tile_area=area2(s.model.polygons[0])
    for phase in phases:
        for i,core in enumerate(phase["candidates"]):
            if core["score"]!=best:
                continue
            stats=Counter()
            holes=[c for c in core["cycles"] if signed(c)<0]
            marked=[]
            if marks is not None:
                marked=[(-signed(h),cavity_key(s.model,h)) for h in holes if -signed(h)%tile_area]
            prior_marks=[marks[key] for _,key in marked if key in marks]
            if prior_marks:
                assert all(a==marks[key]["double_area"] for a,key in marked if key in marks)
                caps=None
                stats["marked_skips"]+=1
            else:
                caps=fill_cavities(s,small_cap,core)
                stats["cap_checks"]+=1
            if caps is None:
                if marked:
                    for area,key in marked:
                        marks.setdefault(key,dict(donor=receiver,double_area=area,key=key))
                proof=prior_marks[0] if prior_marks else marks[marked[0][1]] if marked else None
                obstructions.append(dict(phase=phase["phase"],core_index=i,cycles=core["cycles"],
                                         pieces=core["pieces"],mark=proof,pruned=bool(prior_marks)))
            else:
                stats["filled_cavities"]=len(caps)
                for frame in attach(s,core["pieces"],bank):
                    stats["attached_frames"]+=1
                    if any(overlap(s,a,b) for a in frame[-2:] for b in caps):
                        stats["receiver_cap_collision"]+=1
                        continue
                    for turn in s.model.groups:
                        checks,patches=strips(s,(*frame,*caps),turn,trie,words)
                        stats.update(checks)
                        for word,rows in patches.items():
                            for patch,row in rows.items():
                                found[word].setdefault(patch,dict(core_phase=phase["phase"],core_index=i,**row))
            scan.append(dict(phase=phase["phase"],core_index=i,counts=stats))
    accepted=[dict(prediction=w,assemblies=sorted(patches.values(),
              key=lambda r:(Fraction(r["perimeter"]**2,len(r["patch"])),r["patch"])))
              for w,patches in sorted(found.items())]
    return dict(scaffold_score=best,distinct_predictions=len(words),search=scan,
                accepted=accepted,cap_obstructions=obstructions)


def input_words(geom,old,observed):
    # Decode the two geometric strip records using the orientation stencil.
    alphabet=old["alphabet"]
    letters={g:(i,x,y) for i,(g,x,y) in enumerate(alphabet["letters"])}
    words=[]
    for rows in (old["strips"],observed["cases"][0]["recipe"]["pieces"][-2:]):
        candidates=set()
        for row in rows:
            for turn in geom.model.groups:
                patch=geom.moved(row,turn)
                if any(g not in letters for g,_,_ in patch):
                    continue
                positions=[]
                for g,x,y in patch:
                    bit,dx,dy=letters[g]
                    address,slot=lane((x-dx,y-dy),alphabet["stride"])
                    positions.append((address,slot,bit))
                positions.sort()
                if len({a for a,_,_ in positions})!=1:
                    continue
                start=positions[0][1]
                if all(slot==start+i for i,(_,slot,_) in enumerate(positions)):
                    candidates.add(tuple(bit for _,_,bit in positions))
        assert candidates
        words.append(min(candidates))
    return tuple(words)


def promote(initial,old,observations,recipe,promoted,survivors,marks,receiver):
    old_parent=centred(initial.geom,old["parents"][0]["patch"])
    tri=centred(initial.geom,observations["cases"][0]["winners"][0]["patch"])
    middle=centred(initial.geom,promoted["patch"])
    grown=capped(initial,tri,old_parent,middle)
    if not grown["winners"]:
        return dict(status="NO_TRIANGLE_AT_SEARCHED_CONTACTS",triangle=grown,survivors=[])
    t4=grown["winners"][0]
    alphabet=dict(old["alphabet"])
    dx,dy=alphabet["stride"]
    alphabet["path"]=tuple((g,x+i*dx,y+i*dy) for i,k in enumerate(promoted["word"])
                           for g,x,y in (alphabet["letters"][k],))
    next_recipe=dict(motif=promoted["patch"],doublet=recipe["motif"],seed=tri,
                     motif_pairs=promoted["pieces"][:5],strips=promoted["pieces"][-2:],
                     alphabet=alphabet,parents=[dict(pieces=(*t4["pieces"][4:],*t4["pieces"][1:4]))])
    next_stage=Scaffold(initial.geom,next_recipe)
    next_stage.collision=RowCollision(initial.geom)
    step_two=search(next_stage,next_recipe,old_parent,{r["later"] for r in survivors},marks,receiver)
    allowed={r["prediction"] for r in step_two["accepted"]}
    return dict(status="RECEIVER_SEARCHED",triangle=grown,**step_two,
                survivors=[r for r in survivors if r["later"] in allowed])


def main():
    initial,old=make()
    observations=freeze(load("input/observed-second-layer-v1.json"))
    a,b=input_words(initial.geom,old,observations)
    candidates=rules(a,b)
    save("data/strip-rules-v1.json",dict(training=(a,b),max_tokens=5,candidates=candidates))
    recipe=prior(old,observations)
    stage=Scaffold(initial.geom,recipe)
    step_one=search(stage,recipe,initial.triangle,{r["next"] for r in candidates})
    allowed={r["prediction"] for r in step_one["accepted"]}
    survivors=[r for r in candidates if r["next"] in allowed]
    save("data/strip-receiver-one-v1.json",dict(**step_one,survivors=survivors))
    print("fitted",len(candidates),"next words",step_one["distinct_predictions"],
          "accepted",len(allowed),"rules",len(survivors),flush=True)
    initial.collision=RowCollision(initial.geom)
    continuation=[]
    marks={}
    for row in step_one["accepted"]:
        word=row["prediction"]
        selected=[r for r in survivors if r["next"]==word]
        assert len({initial.geom.normalize(p["patch"]) for p in row["assemblies"]})==1
        promoted=row["assemblies"][0]
        result=promote(initial,old,observations,recipe,promoted,selected,marks,len(word))
        continuation.append(dict(incoming=word,**result))
        print("incoming length",len(word),result["status"],"survivors",
              [(r["rule"],r["cost"]) for r in result["survivors"]],flush=True)
    finalists=sorted((r for row in continuation for r in row["survivors"]),
                     key=lambda r:(r["cost"],r["rule"],r["auxiliary"]))
    save("data/strip-receiver-two-v1.json",dict(branches=continuation,survivors=finalists))


if __name__=="__main__":
    main()
