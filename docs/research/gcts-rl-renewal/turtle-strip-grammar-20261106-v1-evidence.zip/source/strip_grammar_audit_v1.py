"""Qualify the geometric witnesses and prove the surviving recodings equivalent."""
from itertools import product
from fractions import Fraction
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from assemble_v1 import save, sub
from cluster_v1 import Model, load, mat
from collar_audit_v1 import Audit, exposed, freeze
from layer_audit_v1 import signed, verify_disjoint, verify_patch


def stencil(alphabet,word):
    dx,dy=alphabet["stride"]
    return tuple(sorted((g,x+i*dx,y+i*dy) for i,k in enumerate(word)
                        for g,x,y in (alphabet["letters"][k],)))


def occurrences(geometry,expected,patch):
    result=set()
    for turn in geometry.model.groups:
        candidate=geometry.moved(expected,turn)
        offset=sub(min(t[1:] for t in patch),min(t[1:] for t in candidate))
        if geometry.moved(candidate,0,offset)==tuple(sorted(patch)):
            result.add((turn,offset))
    return result


def grammar_audit(training,rules):
    a,b=training
    expected=set()
    for na,nb in product(range(6),repeat=2):
        if not nb or not 1<=na+nb<=5:
            continue
        residue=len(b)-na*len(a)
        if residue<=0 or residue%nb:
            continue
        width=residue//nb
        for bits in product("AB",repeat=na+nb):
            if bits.count("A")!=na:
                continue
            prefix=bits.index("B")*len(a)
            seed=b[prefix:prefix+width]
            if tuple(t for bit in bits for t in (a if bit=="A" else seed))!=b:
                continue
            for n in range(1,6):
                expected.update((("".join(bits),"".join(right)),seed)
                                for right in product("AB",repeat=n))
    assert expected=={(r["rule"],r["auxiliary"]) for r in rules}
    assert len(expected)==len(rules)
    for row in rules:
        left,right=row["rule"]
        strings=dict(A="".join(map(str,a)),B="".join(map(str,row["auxiliary"])))
        history=[]
        for _ in range(3):
            strings={key:"".join(strings[c] for c in part) for key,part in zip("AB",(left,right),strict=True)}
            history.append(tuple(int(c) for c in strings["A"]))
        assert history==[b,row["next"],row["later"]]
    return len(expected)


def subst(term,**words):
    return "".join(words[c] for c in term)


def equivalence(training,finalists,reference):
    rows={r["rule"]:r["auxiliary"] for r in finalists}
    assert len(rows)==len(finalists)==4
    a,_=training
    b=rows.pop(("ABA","AB"))
    canonical=("ABA","AB")
    symbolic=[]
    for rule,aux in ((("AB","ABB"),"BA"),(("BA","BAB"),"AB")):
        assert rows.pop(rule)==(b+a if aux=="BA" else a+b)
        assert tuple(subst(p,A="A",B=aux) for p in rule)==("ABA",subst(aux,A="ABA",B="AB"))
        symbolic.append(dict(rule=rule,auxiliary=aux))
    c=rows.pop(("AAB","AB"))
    assert not rows and a+c==b+a
    # Under A C = B A, the two rules output the same A'. This relation
    # propagates because A' C' = A B A A C = A B A B A = B' A'.
    left,right=("AC","BA")
    assert "AAC".replace(left,right,1)=="ABA"
    assert "ABAAC".replace(left,right,1)=="ABABA"=="AB"+"ABA"
    # Two simultaneous rounds of (U,V) -> (UV,U) give (UVU,UV).
    u,v="A","B"
    for _ in range(2):
        u,v=u+v,u
    assert (u,v)==canonical
    words=reference["coordinate_words"]
    assert a==words[2] and b==words[1]
    for j in range(2,len(words)):
        assert words[j]==words[j-1]+words[j-2]
    assert reference["bridge"]["status"]=="CHECKED_COEFFICIENTWISE_GOLDEN_HEX_CONJUGACY"
    return dict(canonical=canonical,initial=(a,b),recodings=symbolic,
                conjugacy=dict(rule=("AAB","AB"),initial=c,invariant="AC=BA"),
                reference_initial_indices=(2,1),coordinate_word_entries=len(words))


def anchored(edges):
    edges=tuple(edges)
    origin=min(p for edge in edges for p in edge)
    return frozenset((sub(p,origin),sub(q,origin)) for p,q in edges)


def check_obstructions(audit,cap,branch):
    g=audit.geom
    base=g.boundary(cap)
    area=signed(base)
    tile_area=signed(exposed([g.model.polygons[0]]))
    signatures={anchored(g.boundary(g.moved(cap,turn))) for turn in g.model.groups}
    checked=[]
    for item in branch["cap_obstructions"]:
        patch=tuple(sorted(t for p in item["pieces"] for t in p))
        tested_pairs=verify_disjoint(audit,patch)
        boundary=exposed(g.model.poly(t) for t in patch)
        loops=item["cycles"]
        assert all(all(loop[i-1][1]==p for i,(p,q) in enumerate(loop)) for loop in loops)
        assert boundary=={edge for loop in loops for edge in loop}
        assert len(boundary)==sum(map(len,loops))
        assert len({p for p,q in boundary})==len(boundary)==len({q for p,q in boundary})
        outer=sum(signed(loop)>0 for loop in loops)
        sizes=[-signed(loop) for loop in loops if signed(loop)<0]
        failed=sum(anchored((q,p) for p,q in loop) not in signatures
                   for loop in loops if signed(loop)<0)
        assert outer!=1 or failed
        fractions=[Fraction(size,tile_area) for size in sizes]
        assert outer==1 and any(f.denominator!=1 for f in fractions)
        mark=item["mark"]
        assert mark and mark["double_area"] in sizes
        valid_keys=set()
        for loop in loops:
            if signed(loop)!=-mark["double_area"]:
                continue
            alternatives=[]
            for matrix in g.model.groups.values():
                edges=tuple((mat(matrix,p),mat(matrix,q)) for p,q in loop)
                if signed(edges)>0:
                    edges=tuple((q,p) for p,q in edges)
                alternatives.append(tuple(sorted(anchored(edges))))
            valid_keys.add(min(alternatives))
        assert mark["key"] in valid_keys
        checked.append(dict(phase=item["phase"],core_index=item["core_index"],
                            outer_cycles=outer,hole_double_areas=sizes,shape_mismatches=failed,
                            mark=mark,pruned=item["pruned"],
                            candidate_tile_pairs=tested_pairs,
                            hole_tile_areas=[(f.numerator,f.denominator) for f in fractions]))
    return dict(cap_double_area=area,tile_double_area=tile_area,cores=checked)


def main():
    model=Model(load("input/exact-point-model-v1.json"))
    audit=Audit(model)
    g=audit.geom
    old=freeze(load("input/recovered-production-v1.json"))
    second=freeze(load("input/observed-second-layer-v1.json"))
    words=freeze(load("data/strip-rules-v1.json"))
    first=freeze(load("data/strip-receiver-one-v1.json"))
    later=freeze(load("data/strip-receiver-two-v1.json"))
    reference=freeze(load("input/reference-patches-v1.json"))
    ref_rule=freeze(load("input/reference-rule-v1.json"))
    recodings=equivalence(words["training"],later["survivors"],ref_rule)
    for word,paths in zip(words["training"],(old["strips"],second["cases"][0]["recipe"]["pieces"][-2:]),strict=True):
        assert all(occurrences(g,stencil(old["alphabet"],word),p) for p in paths)
    enumerated=grammar_audit(words["training"],words["candidates"])
    proof=[]
    observed=[(2,row) for row in first["accepted"]]
    observed.extend((3,row) for branch in later["branches"] for row in branch.get("accepted",()))
    for level,row in observed:
        variants=[]
        for item in row["assemblies"]:
            expected=stencil(old["alphabet"],item["word"])
            assert row["prediction"] in (item["word"],item["word"][::-1])
            assert all(occurrences(g,expected,p) for p in item["pieces"][-2:])
            assert tuple(sorted(item["pieces"][-1]))==g.moved(item["pieces"][-2],g.rot2)
            assert tuple(sorted(t for p in item["pieces"] for t in p))==item["patch"]
            receipt=verify_patch(audit,item["patch"])
            assert receipt["perimeter"]==item["perimeter"]
            variants.append(receipt)
        key=g.normalize(row["assemblies"][0]["patch"])
        matches=tuple(label for label in ("P3","P4") if key==g.normalize(reference[label]["patch"]))
        proof.append(dict(receiver=level+1,word=row["prediction"],variants=variants,reference_match=matches))
    p3=next(r for r in proof if "P3" in r["reference_match"])
    p4=next(r for r in proof if "P4" in r["reference_match"])
    assert len(p3["word"])==29 and len(p4["word"])==76
    triangles=[]
    gaps=[]
    donors={}
    transferred=0
    skipped=0
    for branch in later["branches"]:
        gap=check_obstructions(audit,old["parents"][0]["patch"],branch)
        receiver=len(branch["incoming"])
        gaps.append(dict(incoming_length=receiver,**gap))
        for core in gap["cores"]:
            mark=core["mark"]
            if core["pruned"]:
                assert donors[mark["key"]]==mark
                skipped+=1
                transferred+=mark["donor"]!=receiver
            else:
                assert mark["key"] not in donors and mark["donor"]==receiver
                donors[mark["key"]]=mark
        for t in branch["triangle"]["winners"]:
            receipt=verify_patch(audit,t["patch"])
            matches=g.normalize(t["patch"])==g.normalize(reference["T4"]["patch"])
            triangles.append(dict(incoming_length=len(branch["incoming"]),reference_match=matches,**receipt))
    assert sum(t["reference_match"] for t in triangles)==1
    assert len(donors)==1 and skipped==11 and transferred==6
    save("data/strip-audit-v1.json",dict(status="CHECKED_TURTLE_STRIP_GRAMMAR",enumerated=enumerated,
         equivalence=recodings,half_turn_witnesses=proof,triangles=triangles,cap_obstructions=gaps,
         markings=dict(learned=len(donors),skipped=skipped,cross_branch=transferred)))
    print("checked",enumerated,"grammars",sum(len(r["variants"]) for r in proof),"half-turn variants",
          len(triangles),"triangles and symbolic equivalence",flush=True)


if __name__=="__main__":
    main()
