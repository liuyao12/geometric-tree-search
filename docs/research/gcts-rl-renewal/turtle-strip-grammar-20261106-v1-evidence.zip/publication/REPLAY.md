# Replay the Turtle strip grammar and failure markings

Use Python 3.10 or newer with assertions enabled. The recorded replay used Python 3.12 and the standard library.

From the extracted archive root, run the clean comparison:

```sh
python3 -I -S -B publication/replay_v1.py
```

The comparison copies the orientation stencil, finite recovered Turtle observations, source, and rendering template to a fresh directory. It runs the grammar enumeration and both geometric receivers without either `input/reference-*.json` file. It then adds the reference files for the symbolic comparison and polygon audit. It rebuilds the notebook and compares all five generated files byte for byte.

The first receiver checks all distinct predicted words in both directions. Its direct scan and prefix-shared scan return the same accepted patch sets. The next receiver carries forward all three surviving visible words. The negative certificates contain the exact core placements, oriented boundary cycles, and the normalized cavity mark. The audit reconstructs the boundary using independent polygon geometry and verifies the nonintegral tile-area ratio, donor, and receiver instances.

The all-scale result follows from the symbolic register equivalences and the already published coordinate recurrence and topology certificate. The two withheld geometric receiver tests use the inherited contact templates, orientation stencil, and maximum-contact core selection.
