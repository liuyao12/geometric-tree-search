"""Render the learned Turtle strip grammar and its geometric receivers."""
from html import escape
from math import sqrt
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"source"))
from assemble_v1 import Geometry
from cluster_v1 import Model, load
from collar_audit_v1 import freeze
from layer_audit_v1 import cycles, signed

STEM="turtle-strip-grammar-20261106-v1"
COLORS=("#b4cfdd","#9dc5d5","#a7cbc0","#9dc5d5","#a7cbc0","#dbd0ea","#dbd0ea","#e1d5ee","#e1d5ee")
STRIP=("#f5cd79","#e38a56")


def bitword(word):
    return r"\mathtt{"+ "".join(map(str,word))+"}"


def formula(value):
    return r"\("+escape(value)+r"\)"


def render_svg(paths,label):
    points=[(x+y/2,-sqrt(3)*y/2) for rings,_,_ in paths for ring in rings for x,y in ring]
    xs,ys=zip(*points,strict=True)
    x0,y0,x1,y1=min(xs),min(ys),max(xs),max(ys)
    margin=max(x1-x0,y1-y0)*.08
    box=f"{x0-margin:.3f} {y0-margin:.3f} {x1-x0+2*margin:.3f} {y1-y0+2*margin:.3f}"
    svg=[f'<svg viewBox="{box}" role="img" aria-label="{escape(label)}">']
    for rings,kind,fill in paths:
        code=" ".join("M"+"L".join(f"{x+y/2:.3f},{-sqrt(3)*y/2:.3f}" for x,y in ring)+"Z" for ring in rings)
        style=f' style="fill:{fill}"' if fill else ""
        svg.append(f'<path class="{kind}"{style} d="{code}"/>')
    return "".join((*svg,"</svg>"))


def patch_svg(g,example,label):
    parts=example["pieces"]
    regions=[(tuple(tuple(a for a,_ in loop) for loop in cycles(g.boundary(tuple(sorted(p))))),
              "patch-piece",color) for p,color in zip(parts[:-2],COLORS)]
    for strip in parts[-2:]:
        first=strip[0][0]
        regions.extend(((g.model.poly(tile),),"tile",STRIP[tile[0]!=first]) for tile in strip)
    return render_svg(regions,label)


def obstruction_svg(obstruction,label):
    rings=obstruction["cycles"]
    paths=[]
    for loop in rings:
        path=tuple(p for p,q in loop)
        paths.append(((path,),"mesh" if signed(loop)>0 else "failed-hole",None))
    return render_svg(paths,label)


def table_row(values):
    a,*b=values
    return "<tr><th scope=\"row\">"+str(a)+"</th>"+"".join(f"<td>{x}</td>" for x in b)+"</tr>"


def main():
    g=Geometry(Model(load("input/exact-point-model-v1.json")))
    data,one,two,audit=[freeze(load(f"data/{name}-v1.json")) for name in
                       ("strip-rules","strip-receiver-one","strip-receiver-two","strip-audit")]
    candidates=data["candidates"]
    snapshots=((len(candidates),one["distinct_predictions"],"Fit the two observations"),
               (len(one["survivors"]),len(one["accepted"]),"Close the first receiver"),
               (len(two["survivors"]),sum(len(b.get("accepted",())) for b in two["branches"]),"Promote the receiver"))
    flow='<ol class="milestones">'+ "".join(f'<li>{title}<b>{n:,} rules</b><span>{k:,} predicted words</span></li>'
                                         for n,k,title in snapshots)+'</ol>'
    second={b["incoming"]:b for b in two["branches"]}
    caps={b["incoming_length"]:b for b in audit["cap_obstructions"]}
    pages=[]
    receiver=[]
    for row in sorted(one["accepted"],key=lambda r:len(r["prediction"])):
        word=row["prediction"]
        n=len(word)
        first=row["assemblies"][0]
        branch=second[word]
        tri=branch["triangle"]["winners"][0]
        kept=branch["survivors"]
        if kept:
            promoted=branch["accepted"][0]["assemblies"][0]
            closed=patch_svg(g,promoted,"The second half-turn frame and its 76-letter strips")
            caption=f'The promoted half-turn patch closes with {len(promoted["patch"]):,} Turtles.'
            outcome="Closed with 76 letters"
        else:
            obstruction=branch["cap_obstructions"][0]
            closed=obstruction_svg(obstruction,f"Exposed cavity outlines after the {n}-letter strip")
            missed=len(caps[n]["cores"])
            caption=f'The red rings each enclose {formula(r"9/5")} tile areas. All {missed} searched cores have this obstruction.'
            outcome=f"Fractional cavities in {missed} cores"
        view=patch_svg(g,first,f"Half-turn patch with two {n}-letter strips")
        pages.append(f'<details class="branch-view" id="branch-{n}"'+(" open" if kept else "")+
                     f'><summary>{n}-letter branch · {len(kept)} final rules</summary>'
                     f'<p>First prediction {formula(bitword(word))}.</p><div class="branch-grid">'
                     f'<figure>{view}<figcaption>{len(first["patch"]):,} Turtles. Orange and amber mark the two strip orientations.</figcaption></figure>'
                     f'<figure>{closed}<figcaption>{caption}</figcaption></figure></div></details>')
        receiver.append(table_row((f'<a href="#branch-{n}">{n} letters</a>',f'{len(first["patch"]):,} tiles',
                                   f'{len(tri["patch"]):,} tiles',outcome,len(kept))))
    headings='<thead><tr><th>Visible update</th><th>Auxiliary update</th><th>Initial auxiliary word</th><th>Rule cost</th></tr></thead>'
    rule_rows="".join(table_row((formula(r"A\mapsto "+x),formula(r"B\mapsto "+y),
                                 formula(bitword(r["auxiliary"])),r["cost"]))
                      for r in two["survivors"] for x,y in (r["rule"],))
    rules=f'<div class="table"><table>{headings}<tbody>{rule_rows}</tbody></table></div>'
    totals={k:sum(s["counts"].get(k,0) for s in one["search"])
            for k in ("prefix_checks","flat_letter_matches")}
    html=(ROOT/"publication/notebook-v1.html").read_text()
    values=dict(FLOW=flow,BRANCHES="".join(pages),RECEIVER_ROWS="".join(receiver),RULES=rules,
                PREFIX=f'{totals["prefix_checks"]:,}',FLAT=f'{totals["flat_letter_matches"]:,}',STEM=STEM)
    for k,v in values.items():
        html=html.replace(f"%%{k}%%",v)
    assert "%%" not in html
    (ROOT/"report"/f"{STEM}.html").write_text(html)


if __name__=="__main__":
    main()
