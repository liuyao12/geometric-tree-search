const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { pathToFileURL } = require("node:url");

async function main() {
  const { chromium } = require(process.env.GCTS_PLAYWRIGHT || "playwright");
  const browser = await chromium.launch({ executablePath: process.env.GCTS_CHROME,
    args: ["--disable-breakpad", "--disable-background-networking"] });
  try {
    const page = await browser.newPage({ viewport: { width: 1180, height: 920 } });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    const local = pathToFileURL(path.join(__dirname, "../report/turtle-strip-grammar-20261106-v1.html")).href;
    const response = await page.goto(process.argv[2] || local, {waitUntil: "commit", timeout: 60000});
    if (process.argv[2]) assert.equal(response.status(), 200);
    await page.waitForFunction(() => document.querySelector("#equivalence mjx-container"), null, {timeout: 60000});
    assert.equal(await page.locator("#receivers details").count(), 3);
    assert.equal(await page.locator("#receivers tbody tr").count(), 3);
    assert.equal(await page.locator("#equivalence tbody tr").count(), 4);
    assert.equal(await page.locator("#branch-29 path.tile").count(), 210);
    assert.equal(await page.locator("#branch-18 path.failed-hole").count(), 2);
    await page.locator('a[href="#branch-18"]').click();
    assert.equal(await page.locator("#branch-18").getAttribute("open"), "");
    assert(await page.locator("#branch-18 .failed-hole").first().isVisible());
    assert.equal(await page.locator("mjx-merror").count(), 0);
    if (!process.argv[2]) {
      await page.locator("#branch-29").screenshot({path: path.join(__dirname, "branch-view-v1.png")});
    }
    await page.setViewportSize({width: 390, height: 844});
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
    assert.deepEqual(errors, []);
    const receipt={status:"CHECKED_TURTLE_STRIP_READER",branches:3,finalRules:4,visibleStripTiles:210,
      mobileNoOverflow:true,mathTypeset:true,cavityView:true};
    fs.writeFileSync(path.join(__dirname,process.argv[2] ? "browser-live-v1.json" : "browser-v1.json"),
      JSON.stringify(receipt,null,2)+"\n");
    console.log(JSON.stringify(receipt));
  } finally {
    await browser.close();
  }
}
main().catch(error => {console.error(error); process.exitCode = 1;});
