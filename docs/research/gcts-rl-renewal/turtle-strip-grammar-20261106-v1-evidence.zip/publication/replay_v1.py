"""Rebuild the strip study with both reference files absent during search."""
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
OUTPUTS=tuple("data/"+name+"-v1.json" for name in
    ("strip-rules","strip-receiver-one","strip-receiver-two","strip-audit"))+(
    "report/turtle-strip-grammar-20261106-v1.html",)


def run(clean,stage):
    subprocess.run([sys.executable,"-I","-S","-B",stage],cwd=clean,check=True)


def main():
    with TemporaryDirectory() as scratch:
        clean=Path(scratch)
        for sub in ("data","input","source","publication","report"):
            (clean/sub).mkdir()
        templates=[ROOT/"publication"/name for name in ("render_v1.py","notebook-v1.html")]
        references=sorted((ROOT/"input").glob("reference-*.json"))
        training=sorted(set((ROOT/"input").glob("*.json"))-set(references))
        for path in (*training,*(ROOT/"source").glob("*.py"),*templates):
            shutil.copyfile(path,clean/path.relative_to(ROOT))
        assert not list((clean/"input").glob("reference-*.json"))
        run(clean,"source/strip_grammar_v1.py")
        for path in references:
            shutil.copyfile(path,clean/path.relative_to(ROOT))
        run(clean,"source/strip_grammar_audit_v1.py")
        run(clean,"publication/render_v1.py")
        pins={}
        for name in OUTPUTS:
            raw=(clean/name).read_bytes()
            assert raw==(ROOT/name).read_bytes(),name
            pins[name]=dict(bytes=len(raw),sha256=sha256(raw).hexdigest())
    receipt=dict(status="MATCHED_CLEAN_REPLAY",references_absent_during_search=True,
                 python=list(sys.version_info[:3]),outputs=pins)
    (ROOT/"publication/replay-v1.json").write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    print("Matched",len(pins),"artifacts byte for byte.",flush=True)


if __name__=="__main__":
    main()
