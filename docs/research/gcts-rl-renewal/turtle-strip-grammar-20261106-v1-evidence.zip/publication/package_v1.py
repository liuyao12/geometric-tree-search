"""Package the public Turtle strip study and all replay evidence."""
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT=Path(__file__).resolve().parents[1]
STEM="turtle-strip-grammar-20261106-v1"


def pin(raw):
    return dict(bytes=len(raw),sha256=sha256(raw).hexdigest())


def load(path):
    return json.loads((ROOT/path).read_text())


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")


def main():
    report=ROOT/"report"
    audit=load("data/strip-audit-v1.json")
    first=load("data/strip-receiver-one-v1.json")
    second=load("data/strip-receiver-two-v1.json")
    replay=load("publication/replay-v1.json")
    for path,expected in replay["outputs"].items():
        assert pin((ROOT/path).read_bytes())==expected
    summary=f"report/{STEM}-results.json"
    save(summary,dict(schema="TURTLE-STRIP-GRAMMAR-RESULTS-v1",audit=audit,replay=replay,
         reader=load("publication/browser-v1.json"),first={k:first[k] for k in
          ("distinct_predictions","search","scaffold_score")},final_rules=second["survivors"],
         second=[{k:r[k] for k in ("incoming","status","distinct_predictions","search")}
                 for r in second["branches"]]))
    paths=sorted((ROOT/"source").glob("*.py"))+sorted((ROOT/"input").glob("*-v1.json"))
    paths.extend(ROOT/p for p in (*replay["outputs"],summary))
    paths.extend(sorted((ROOT/"data").glob("*.log")))
    paths.extend(ROOT/"publication"/p for p in ("REPLAY.md","replay-v1.json","browser-v1.json",
                  "notebook-v1.html","render_v1.py","replay_v1.py","package_v1.py",
                  "check_v1.cjs","branch-view-v1.png"))
    archive=report/f"{STEM}-evidence.zip"
    pins={}
    with ZipFile(archive,"w") as bundle:
        for path in paths:
            name,raw=str(path.relative_to(ROOT)),path.read_bytes()
            if path.suffix!=".png":
                assert not re.search(rb"/(?:Users/|private/tmp/|var/folders/)",raw),name
            assert name not in pins
            pins[name]=pin(raw)
            item=ZipInfo(name,(2026,11,6,0,0,0))
            item.external_attr=0o100644<<16
            bundle.writestr(item,raw,compress_type=ZIP_DEFLATED,compresslevel=9)
    with ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert {p:pin(bundle.read(p)) for p in bundle.namelist()}==pins
    assets={p.name:pin(p.read_bytes()) for p in (report/f"{STEM}.html",ROOT/summary,archive)}
    save(f"report/{STEM}-manifest.json",dict(schema="TURTLE-STRIP-GRAMMAR-MANIFEST-v1",
                                          assets=assets,archive_entries=pins))
    print(json.dumps(dict(assets=assets,entries=len(pins)),indent=2))


if __name__=="__main__":
    main()
