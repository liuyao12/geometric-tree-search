"""Administrative data joins only; no project Source imports or replay."""
import base64, collections, hashlib, json, pathlib, stat, zlib
N=pathlib.Path('/private/tmp/gcts-cluster-receptors-20261027-v2');A=N/'actual-v1';OUT=N/'independent-C'
def encoded(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(encoded(x)).hexdigest()
def rawsha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=pathlib.Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not p.is_symlink();b=p.read_bytes();t=p.lstat();assert (s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_ino,t.st_size,t.st_mtime_ns) and len(b)==s.st_size;return b
def pin(p,b=None):
 if b is None:b=read(p)
 return {'path':str(p),'bytes':len(b),'sha256':rawsha(b)}
def pairs(xs):
 d={}
 for k,v in xs:assert k not in d;d[k]=v
 return d
def bad(x):raise ValueError(x)
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def checked(r):
 b=read(r['path']);assert pin(r['path'],b)==r;return b
def unpack(e,cap,lines=False):
 assert set(e)=={'schema','encoding','record_count','raw_bytes','raw_sha256','compressed_bytes','compressed_sha256','data_base64'}
 c=base64.b64decode(e['data_base64'],validate=True);assert len(c)==e['compressed_bytes'] and rawsha(c)==e['compressed_sha256'] and base64.b64encode(c).decode()==e['data_base64']
 z=zlib.decompressobj();digest=hashlib.sha256();size=count=0;buf=bytearray();whole=[]
 for start in range(0,len(c),65536):
  pending=c[start:start+65536]
  while pending:
   before=len(pending);b=z.decompress(pending,1048576);pending=z.unconsumed_tail;assert not z.unused_data and (b or len(pending)<before);size+=len(b);assert size<=cap;digest.update(b)
   if lines:
    buf.extend(b)
    while True:
     pos=buf.find(b'\n')
     if pos<0:break
     line=bytes(buf[:pos+1]);del buf[:pos+1];assert len(line)<=67108864;v=parse(line);assert encoded(v)==line;count+=1;yield v
    assert len(buf)<=67108864
   else:whole.append(b)
 assert z.eof and not z.unused_data and not z.unconsumed_tail and not buf and size==e['raw_bytes'] and digest.hexdigest()==e['raw_sha256']
 if lines:assert count==e['record_count']
 else:
  b=b''.join(whole);assert b.count(b'\n')==e['record_count']==1;v=parse(b);assert encoded(v)==b;yield v
result=parse(read(A/'result.json'));index=parse(checked(result['outcome']['index']));refs={pathlib.Path(r['path']).name:r for r in result['artifacts']};assert len(refs)==183
physical=[pin(p) for p in sorted(A.iterdir())];assert len(physical)==187
for r in result['artifacts']:checked(r)
assert sum(r['bytes'] for r in result['artifacts'])==result['named_bytes_before_final_result']
initial=parse(checked(index['initial_policy']));frozen=parse(checked(index['frozen_trained_policy']));armrefs=[r['record'] for r in index['training']]+[r['record'] for r in index['evaluation']];assert len(armrefs)==112 and len({r['path'] for r in armrefs})==112
costmap={r['body']['path']:r for r in index['arm_costs']};arms={};codec=[];witnesses=[];join_failures=[]
for number,r in enumerate(armrefs):
 name=pathlib.Path(r['path']).name;e=parse(checked(r));assert e['schema']=='GCTS-lossless-cluster-main-arm-v1' and e['encoding']=='CANONICAL_JSON_ZLIB1_BASE64';d=next(unpack(e,67108864));assert d['schema']=='GCTS-cluster-receptor-main-arm-v1'
 # Exhaust generator to run all trailing checks before retaining a document.
 g=unpack(e,67108864);d=next(g)
 try:next(g)
 except StopIteration:pass
 else:raise AssertionError('extra document')
 log=d['audit_log'];assert log['schema']=='GCTS-lossless-runtime-audit-log-v1' and log['encoding']=='CANONICAL_JSONL_ZLIB1_BASE64'
 events=[];validrows={};obsrows={};counts=collections.Counter();states={};cleanupstart=len(d['trace']);tracecounter=0
 for j,row in enumerate(unpack(log,268435456,True)):
  counts[row['kind']]+=1
  if row['kind']=='NATIVE_EVENT':
   state=row['verification']['normalized_state'];hs=sha(state);event=row['event'];ev={'log_row':j,'kind':event['kind'],'data':event['data'],'state_sha256':hs,'selected':state['selected'] if event['kind']=='DECISION' else None,'verification_sha256':sha(row['verification']),'native_snapshot_sha256':row['native_snapshot_sha256']}
   if event['kind']=='PLACED':ev['placed_present_in_saved_normalized_selected']=event['data']['id'] in state['selected']
   events.append(ev)
   digest={'seq':tracecounter,'kind':event['kind'],'data':{'restored_state_sha256':hs} if event['kind']=='ROLLED_BACK' else event['data'],'domains_sha256':sha(state['eligible_domains']),'state_sha256':hs}
   expected=(d['trace']+d['cleanup_trace'])[tracecounter];assert digest==expected;tracecounter+=1
  elif row['kind']=='PROPOSAL_VALIDATED':
   q=row['producer_receipt'];state=row['state_verification']['normalized_state'];validrows[q['index']]={'log_row':j,'state_sha256':sha(state),'receipt_sha256':sha(q),'independent_status':row['independent_verification']['status'],'independent_verification_sha256':sha(row['independent_verification'])}
  elif row['kind']=='PROPOSAL_OBSERVATION':obsrows[sha(row['observation'])]={'log_row':j,'state_sha256':sha(row['verification']['normalized_state'])}
 assert tracecounter==len(d['trace'])+len(d['cleanup_trace'])
 actor=d['actor_final'];calls=[] if actor is None else actor['calls'];props=d['proposal_evidence'];assert len({q['index'] for q in props})==len(props)
 callmap={c['index']:c for c in calls};proposal_details=[];origin_links={}
 for q in props:
  c=callmap.get(q['index']);base={'index':q['index'],'status':q['status'],'observation_sha256':q['observation_sha256'],'logical_before':q['logical_before_sha256'],'logical_after':q['logical_after_sha256'],'ordered_candidates':q['ordered_candidates'],'clusters_accepted':sum(z['accepted'] for z in q['clusters']),'call_mode':None if c is None else c['mode'],'origin_call':None if c is None else c['origin_call'],'original_members':None if c is None else c['original_members'],'accepted_placement_join':None}
  if c is not None:assert c['observation_sha256']==q['observation_sha256'] and c['observation']==q['observation'] and c['packet']==q['raw_packet']
  if q['status']=='VALIDATED':
   v=validrows[q['index']];assert v['receipt_sha256']==sha(q) and v['independent_status']=='VERIFIED_COMPLETE_CLUSTER_ORDER'
   # Find the first subsequent native decision; no crossing an intervening rollback/result.
   dec=None;placed=None
   for ev in events:
    if ev['log_row']<=v['log_row']:continue
    if ev['kind'] in ('ROLLED_BACK','SOLVE_RESULT'):break
    if ev['kind']=='DECISION':dec=ev;break
   if dec is not None and dec['data']['kind']=='BRANCH' and dec['state_sha256']==v['state_sha256'] and dec['data']['point']==q['observation']['point'] and dec['data']['candidates']==q['ordered_candidates']:
    for ev in events:
     if ev['log_row']<=dec['log_row']:continue
     if ev['kind'] in ('DECISION','ROLLED_BACK','SOLVE_RESULT'):break
     if ev['kind']=='PLACED':placed=ev;break
   if placed is not None and placed['data']['reason']=='BRANCH' and placed['data']['id']==q['ordered_candidates'][0] and placed['placed_present_in_saved_normalized_selected']:
    chosen=placed['data']['id'];accepted=[z for z in q['clusters'] if z['accepted'] and chosen in z['incident_ids'] and chosen in z['new_ids']];join={'proposal_log_row':v['log_row'],'proposal_state_sha256':v['state_sha256'],'decision_log_row':dec['log_row'],'decision':dec['data'],'placed_log_row':placed['log_row'],'placed':placed['data'],'accepted_cluster_ids':[z['id'] for z in accepted],'nonlex_order':q['ordered_candidates']!=q['observation']['incident_domain'],'nonlex_first':chosen!=q['observation']['incident_domain'][0]}
    base['accepted_placement_join']=join
    if c is not None and c['mode']=='FRESH' and c['original_members'] and chosen==c['original_members'][0] and accepted:origin_links[c['index']]=join
    if c is not None and c['mode']=='PENDING_REUSE' and chosen in c['original_members'] and c['original_members'].index(chosen)>=1 and accepted:
     origin=callmap.get(c['origin_call']);shared_first=c['original_members'][0];selected=q['observation']['selected'];match=[z for z in accepted if z['raw_cluster']['members']==c['original_members'] and shared_first in z['shared_ids']]
     if origin is not None and origin['mode']=='FRESH' and origin['original_members']==c['original_members'] and c['origin_call'] in origin_links and shared_first in selected and match:
      witnesses.append({'arm':r,'decoded_raw_sha256':e['raw_sha256'],'proposal_index':q['index'],'actor_call_index':c['index'],'origin_call_index':c['origin_call'],'original_member_index':c['original_members'].index(chosen),'original_members':c['original_members'],'shared_first':shared_first,'origin_packet_sha256':sha(origin['packet']),'current_packet_sha256':sha(c['packet']),'origin_root_actual_placement':origin_links[c['origin_call']],'current_later_actual_placement':join,'proposal_receipt_sha256':sha(q),'actor_call_sha256':sha(c),'accepted_cluster_id':match[0]['id'],'shared_ids':match[0]['shared_ids'],'no_intervening_boundary':True})
  proposal_details.append(base)
 ret=d['return'];metric=ret['metrics'];actinfo=None
 if actor is not None:
  assert d['independent_actor_check']['kernel_receipt_sha256']==sha(props) and d['independent_actor_check']['snapshot_sha256']==sha(actor)
  actinfo={'policy':actor['policy'],'policy_sha256':actor['policy_sha256'],'snapshot_sha256':sha(actor),'entry_policy_sha256':d['actor_entry']['policy_sha256'],'config':actor['config'],'costs':actor['costs'],'pending_count':len(actor['pending']),'call_count':len(calls),'fresh_calls':sum(c['mode']=='FRESH' for c in calls),'pending_reuses':sum(c['mode']=='PENDING_REUSE' for c in calls),'tokens':sum(len(c['tokens']) for c in calls),'calls':[{'index':c['index'],'mode':c['mode'],'origin_call':c['origin_call'],'observation_sha256':c['observation_sha256'],'original_members':c['original_members'],'root_selected_sha256':sha(c['root_selected']),'packet_sha256':sha(c['packet']),'termination':c['termination']} for c in calls]}
 timing=costmap[str(r['path'])];summary={'rawpin':r,'decoded_raw_bytes':e['raw_bytes'],'decoded_raw_sha256':e['raw_sha256'],'engine':d['engine'],'strategy':d['strategy'],'input':{k:d['input'][k] for k in ('width','steps','initial','final','negative_final')},'seed':d['seed'],'marking_version':d['marking_version'],'model_sha256':sha(d['model']),'entry_sha256':sha(d['entry']),'normalized_initial_sha256':events[0]['state_sha256'],'status':ret['status'],'reason':ret['reason'],'nodes':ret['nodes'],'metrics':metric,'window':d['search_window'],'arm_through_write_seconds':timing['through_complete_body_write_seconds'],'elapsed_before_outer_serialization':d['elapsed_before_outer_body_serialization'],'result_check_status':d['result_check']['status'],'certificate_kind':d['result_check'].get('certificate_kind'),'restored_entry_exact':d['restored_entry_exact'],'feedback_required_points':d['feedback_required_points'],'max_verified_filled':d['max_verified_filled'],'indexed_preparation':d['indexed_preparation'],'cluster_preparation':d['cluster_preparation'],'actor':actinfo,'proposal_metrics':d['proposal_metrics'],'proposal_details':proposal_details,'trace':d['trace'],'native_event_data_joins':events,'audit_metadata':{k:v for k,v in log.items() if k!='data_base64'},'audit_row_kinds':dict(counts),'result_context':ret['context'],'point_check_sha256':sha(d['result_check'])}
 arms[name]=summary;codec.append({'rawpin':r,'outer_raw_bytes':e['raw_bytes'],'outer_raw_sha256':e['raw_sha256'],'inner_raw_bytes':log['raw_bytes'],'inner_raw_sha256':log['raw_sha256'],'inner_records':log['record_count'],'complete_outer_and_inner_integrity':True})
 if number%16==0:print('processed',number+1,flush=True)
extraction={'schema':'C-cluster-N2-complete-causal-data-extraction-v1','scope':'Saved-data joins only, all scientific admission pending; no project functions or numeric reinforce replay.','prefreeze':pin(OUT/'cluster-N2-causal-control-assessment-prefreeze-v1.json'),'result':pin(A/'result.json'),'index':result['outcome']['index'],'all187_physical_rawpins':physical,'all183_named_refs_matched':True,'all112_outer_inner_codec_integrity':codec,'all112_arm_summaries_and_full_event_data_joins':arms,'all_actual_pending_later_member_witnesses':witnesses,'initial_policy':initial,'frozen_policy':frozen,'index_training':index['training'],'index_evaluation':index['evaluation'],'index_evaluation_pairs':index['evaluation_pairs'],'index_training_pair_checks':index['training_pair_checks'],'index_updates':index['updates'],'terminal':'DATA_EXTRACTION_COMPLETE_NO_SOURCE_EXECUTION'}
b=(json.dumps(extraction,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode();p=OUT/'cluster-N2-complete-causal-data-extraction-v1.json'
with p.open('xb') as f:f.write(b)
print('FROZEN',json.dumps(pin(p,b)), 'WITNESSES',len(witnesses),flush=True)
