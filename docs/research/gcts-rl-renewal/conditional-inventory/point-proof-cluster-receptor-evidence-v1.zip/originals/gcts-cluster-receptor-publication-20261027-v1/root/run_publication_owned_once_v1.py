"""Root administrative custody only; no scientific code imports or evaluation."""
from pathlib import Path
import sys, os, json, hashlib, subprocess, time

ROOT=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1/root')
P2=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher-recovery-6338a77')
D90=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
BOOT=Path('/private/tmp/gcts-cluster-receptors-20261027-v2/root/authenticated-source-bootstrap-v1.py')
AUTH=ROOT/'cluster-multipart-publication-once-authority-v1.json'
SOURCES={
 'publish':('publish_cluster_receptor_multipart_api_v1.py',14576,'6f6f8f684da182f17e4dea94b1dd3eab7b8308426cd3b314b0361930ce8c40ec'),
 'tls':('verify_cluster_receptor_multipart_live_v1.py',6914,'100d25dc8954047df662b2a02a4f9d721bf1a455ea090a99ff43da8d079f551e')}
def pin(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def checked(p,n,h):
 b=p.read_bytes(); assert len(b)==n and hashlib.sha256(b).hexdigest()==h; return b
def write(p,d):
 b=(json.dumps(d,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
 return pin(p)
assert len(sys.argv)==2 and sys.argv[1] in SOURCES
mode=sys.argv[1]
assert Path.cwd()==P2 and Path(sys.executable).resolve()==D90
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.optimize==0
checked(D90,18058560,'d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840')
bootstrap=checked(BOOT,344,'f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62')
name,n,h=SOURCES[mode]
source=ROOT.parent/'implementation-B'/name
body=checked(source,n,h)
if mode=='publish':
 assert AUTH.is_file() and not Path(str(AUTH)+'.CONSUMED.json').exists()
else:
 admission=json.loads((ROOT/'cluster-multipart-publication-Root-adoption-v1.json').read_bytes())
 assert admission['decision']=='ADMIT_COMPLETE_TEN_PATH_PUBLICATION_ONCE'
args=[str(D90),'-I','-S','-B','-c',bootstrap.decode(),str(source),str(n),h]
if mode=='publish':args+=['--authority',str(AUTH)]
capture=ROOT/('multipart-'+mode+'-owned-capture-v1')
capture.mkdir()
write(capture/'INVOKED.json',{'schema':'Root-administrative-owned-once-invocation-v1','mode':mode,'source':pin(source),'runtime':pin(D90),'bootstrap':pin(BOOT),'cwd':str(P2),'authority':pin(AUTH) if mode=='publish' else None,'scientific_execution':False})
start=time.monotonic()
with (capture/'stdout.bin').open('xb') as out,(capture/'stderr.bin').open('xb') as err:
 process=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err,cwd=P2)
 after_popen=time.monotonic()
 process.communicate(input=body)
 out.flush();os.fsync(out.fileno());err.flush();os.fsync(err.fileno())
elapsed=time.monotonic()-start
assert checked(source,n,h)==body
checked(D90,18058560,'d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840')
result={'schema':'Root-administrative-owned-once-terminal-v1','mode':mode,'pid':process.pid,'exit':process.returncode,'owned_parent_before_Popen_through_wait_seconds':elapsed,'Popen_return_offset_seconds':after_popen-start,'stdout':pin(capture/'stdout.bin'),'stderr':pin(capture/'stderr.bin'),'source':pin(source),'runtime':pin(D90),'bootstrap':pin(BOOT),'cwd':str(P2),'scientific_execution':False,'automatic_retries':0}
receipt=write(capture/'terminal.json',result)
print(json.dumps({'terminal':receipt,'exit':process.returncode,'mode':mode}))
raise SystemExit(process.returncode)
