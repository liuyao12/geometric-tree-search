# Passive ranked-arithmetic audit

`review/passive_ranked_audit_v1.py` is Source-only until Root reads the complete
body and authorizes one passive audit after all intended scientific attempts
have ended. It imports only `pathlib`, `collections`, `gzip`, `hashlib`, `json`
and `sys`. No scientific module is imported, and no compiler, rank computation,
model construction, engine, semantic/fullgraph checker, oracle or native kernel
is called or replayed.

Future invocation must use the protocol's exact isolated runtime and flags:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B review/passive_ranked_audit_v1.py
```

The script writes exactly one new file by exclusive creation:

```text
review/passive-ranked-outcomes-v1.json
schema: Ranked-arithmetic-passive-audit-v1
status: PASS_SAVED_RANKED_OUTCOMES_WITH_EXPLICIT_SCOPES
```

PASS means that saved-byte, process, receipt, census and native-projection
associations agree. It does not mean every phase ran, a target proof was found,
the rank argument was rerun, or the research goal is complete. A failed
association raises without producing a PASS receipt. Raw/scientific UNKNOWN,
unrun phases and failed/incomplete processes remain explicit and are not
promoted to mathematical proof or finite absence.

## Required evidence and scope

- Exact current frozen `source/reference/input/plan`, admitted review refs,
  current master and runtime flags/version/binary. There is no reused prior
  evidence namespace in this cold study.
- Five generic actual phase records: `qualify`, `prepare`, `rank`, `evaluate`,
  `baseline`. PID/phase/protocol/result/log, native exit, guards and frozen
  postchecks are joined. Clean process, scientific admission and proof admission
  remain different fields.
- Qualification: saved original twenty tiny and two logical engine runs with
  176 actual maps and nine controls; six rank cases with eighteen additional
  engine runs and 129 maps. Every actual observation joins its raw event and
  saved paired-state hashes, with complete T/paired receipts. Complete tiny
  subset records and all saved covers are compared across BASE/RANK_MARKS/
  RANK_FILTER; no assignment is recomputed. Five conventional tiny positives
  and the original two logical positives remain qualification evidence.
- Cold preparation: full declared RF core/generation, R/Q/N gates, whole
  prepared catalogue/model/universe, migration and every native ZERO payload
  receipt/hash. Counts come from actual complete carriers and receipts.
- Rank: actual P candidate/V status and exact input/model/rank/forbidden/reason
  hashes. Every original row and old mark stays in all models; only the fresh
  guard seed/forbidden-row literals or matched ordinary unary list may change.
  All five actual controls are joined. Ranks are read and typed, not recomputed.
- Point evaluation: complete raw model, endpoint/event hashes and statuses
  join the saved C receipt. Complete emitted payload does not make a raw/C
  UNKNOWN prefix a complete SAT or finite-exhaustion certificate. Statistics
  and reasons join actual raw records exactly.
- Conventional control: actual selected original CIDs and selection hash,
  original prepared/model scope, optional authenticated rank information and
  explicit specialized-search status. Failure is never bounded absence.
- Every admitted native positive has exact complete M/N semantic projection,
  original statement/prepared scope/selection, saved native proof and B line/
  typed rule-count joins. Receipt truth still depends on the authenticated
  frozen invocation; these joins are not a new native proof check.

## Output ABI

Top fields include `protocol`, `frozen`, `phases`, `qualification`,
`preparation`, `rank`, `evaluation`, `baseline`, `native_proofs`,
`native_proof_counts`, `physical_files`, `artifact_pins`, `check_count`, `scope`.
Current data/run physical files and every referenced byte/hash are retained.
Archive member/CRC/publication validation is a separate gate.

Each `phases` row has `name`, `pid`, `native_exit_code`, `scientific_status`,
`process_status`, `process_clean`, `scientific_admitted`, `refs`, `costs` and
optional parse-error metadata. Expected scientific statuses are `QUALIFIED`,
`PREPARED`, `RANK_ADMITTED`, `EVALUATED`, `BASELINE_RECORDED`. An admitted
`EVALUATED` phase may consist entirely of UNKNOWN search outcomes.

`rank.activation_admitted` is true only with clean actual rank process and all
current rank/control/model gates. A saved child activation flag from an
unadmitted process remains metadata and cannot activate the audited layer.
`rank.association` carries independent receipt status, input/model bindings,
census and rank/forbidden/reason hashes; it explicitly says `learned=False`
and `bounded_absence=False`. `evaluation.lanes` retains point admissions and
separate native status. `baseline` retains specialized candidate/refusal,
native status, optional rank custody, costs and refs.

Native proof rows have `id`, `role`, `lines`, `statement_sha256`,
`selected_sha256`, `proof_sha256`, `proof_ref`, `native_ref`, decoder refs,
rule census and scope. Ref comparison uses path/bytes/SHA-256 and optional
pointer; an original J decoded packet uses pointer `/proof`.

| Proof ID | Role |
|---|---|
| `qual-<J logical case id>` | `QUALIFICATION` |
| `qual-plan-<rank case id>` | `QUALIFICATION_SPECIALIZED_CONTROL` |
| `arith-BASE`, `arith-RANK_MARKS`, `arith-RANK_FILTER` | `POINT_SEARCH` |
| `conventional-target` | `SPECIALIZED_CONTROL` |

Only actual admitted positives enter this collection; no target-positive count
is predetermined. These roles must stay distinct in report and publication
joins. Process/helper/cold preparation/search/native intervals remain separate;
overlapping intervals and unlike work units are not summed as speed evidence.
No learned marking, RL, geometric transfer, full PA or uniform universal Wang
palette claim is made by this audit.
