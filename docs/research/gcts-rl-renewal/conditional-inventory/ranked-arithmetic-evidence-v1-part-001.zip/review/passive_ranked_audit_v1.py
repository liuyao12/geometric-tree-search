"""Passive ranked-run file/receipt ledger auditor, no scientific imports/replay.

SOURCE ONLY until Root full review and actual scientific phases have ended.
PASS is saved-evidence scope consistency, not mathematical goal completion.
"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL='protocol/frozen-protocol-v1.json'
OUTPUT='review/passive-ranked-outcomes-v1.json'
PHASES=('qualify','prepare','rank','evaluate','baseline')
PROJECTION=('statement','proof','slots','slot_to_native','native_to_slot',
    'reference_mapping','proof_dag','selected','selected_sha256','original_statement_sha256','scope')
NATIVE_RULES=('axiom','tautology','refl','instantiate','distribute','eq_subst','mp','generalize')
LEDGER={}
CHECKS=0
PROOFS=[]
SITE='certified:rank:guard:v1'


def need(ok, why):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),
                       allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a,b,why):
    need(wire(a)==wire(b),why)


def local(name):
    need(type(name) is str and name and not Path(name).is_absolute()
         and '..' not in Path(name).parts,'LOCAL_REFERENCE')
    path=ROOT
    for part in Path(name).parts:
        path=path/part
        need(not path.is_symlink(),'NO_REFERENCE_SYMLINK')
    need(path.resolve().is_relative_to(ROOT),'REFERENCE_CONTAINMENT')
    return path


def filepin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def reference(name):
    value=dict(path=name,**filepin(local(name)))
    if name in LEDGER:
        same(value,LEDGER[name],'UNCHANGED_DURING_AUDIT:'+name)
    LEDGER[name]=value
    return value


def logical_pin(name):
    path=local(name);h=hashlib.sha256();size=0
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def exact(ref):
    actual=reference(ref['path'])
    need(type(ref['bytes']) is int and ref['bytes']>=0,'NATIVE_FILE_SIZE')
    same(actual,{k:ref[k] for k in actual},'PHYSICAL_REF:'+ref['path'])
    if 'complete_json' in ref:
        need(ref['complete_json'] is True,'COMPLETE_REFERENCED_JSON')
        need(logical_pin(ref['path'])['bytes']==ref['logical_json_bytes'],'LOGICAL_CAPTURE_SIZE')


def read(name,ref=None):
    reference(name)
    if ref is not None:
        exact(ref)
    path=local(name)
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        raw=stream.read(134217729)
    need(len(raw)<=134217728,'SAVED_JSON_READ_BOUND')
    return json.loads(raw)


def readref(ref):
    return read(ref['path'],ref)


def allrefs(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=set(value) and not value['path'].startswith('/'):
            exact(value)
        for v in value.values():allrefs(v)
    elif type(value) is list:
        for v in value:allrefs(v)


def normal(model):
    value=json.loads(wire(model));value['roots'].sort()
    for k in ('t','m'):value['seed'][k].sort()
    for row in value['inventory']['placements']:
        row['t'].sort();row['m'].sort()
    value['inventory']['placements'].sort(key=lambda r:r['id'])
    value['pair_nogoods'].sort();value['unary_nogoods'].sort()
    return value


def environment():
    p=read(PROTOCOL);need(p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    same(p['phases'],list(PHASES),'EXACT_CURRENT_PHASES')
    same(p['admitted_statuses'],dict(qualify='QUALIFIED',prepare='PREPARED',rank='RANK_ADMITTED',
        evaluate='EVALUATED',baseline='BASELINE_RECORDED'),'EXACT_CURRENT_SCIENTIFIC_STATUSES')
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():names.add(path.relative_to(ROOT).as_posix())
    for ref in admission['reviewed']:exact(ref);names.add(ref['path'])
    same([reference(n) for n in sorted(names)],p['files'],'EXACT_FROZEN_FILE_SET')
    for ref in (p['master'],p['runtime']['executable']):
        same(filepin(Path(ref['path'])),{k:ref[k] for k in ('bytes','sha256')},'CURRENT_MASTER_RUNTIME_BINARY')
    executable=Path(sys.executable).resolve()
    actual=dict(executable=dict(path=str(executable),**filepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    same(actual,p['runtime'],'PINNED_AUDIT_RUNTIME')
    return p,dict(file_count=len(names),exact_set=True,current_runtime=p['runtime'],current_master=p['master'],limits=p['limits'])


def process(name,p):
    paths=dict(started='run/'+name+'/started.json',invocation='run/'+name+'/invocation.json',
        observer='run/'+name+'/observer.json',result='data/'+name+'/result.json')
    values={};parse_errors={}
    for key,path in paths.items():
        if local(path).exists():
            try:values[key]=read(path)
            except (ValueError,UnicodeError,EOFError) as error:
                need(key=='result','MALFORMED_PROCESS_RECEIPT')
                parse_errors[key]=type(error).__name__+':'+str(error)
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    clean=False
    if s is not None:
        need(s['phase']==name and type(s['pid']) is int and s['pid']>0,'STARTED_PHASE_PID')
        same(s['protocol'],reference(PROTOCOL),'STARTED_FROZEN_PROTOCOL')
    for v in (i,o):
        if v is not None:need(v['phase']==name,'ACTUAL_PHASE_ASSOCIATION')
    if s is not None and i is not None and o is not None:
        need(type(i['pid']) is int and type(o['pid']) is int and s['pid']==i['pid']==o['pid'],'ACTUAL_PID_ASSOCIATION')
        exact(o['log']);need(o['log']['path']=='run/'+name+'/stdout.log','OWNED_LOG_PATH')
        if i.get('result') is not None:
            need(i['result'].get('complete_json') is True,'INVOCATION_RESULT_COMPLETE_JSON')
            exact(i['result']);need(i['result']['path']==paths['result'],'EXACT_RESULT_PATH')
            need(result is not None and i['scientific_status']==result['status'],'SCIENTIFIC_STATUS_ASSOCIATION')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None and i.get('result') is not None
            and result is not None and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==p['status'])
    if result is not None:allrefs(result)
    return dict(name=name,process_status='CLEAN_RECORDED_PHASE' if clean else
        ('NOT_RUN' if not values and not parse_errors else 'FAILED_OR_INCOMPLETE_PROCESS'),
        native_exit_code=None if o is None else o.get('native_exit_code'),scientific_status=None if result is None else result['status'],
        process_clean=clean,scientific_admitted=clean and result['status']==p['admitted_statuses'][name],
        pid=None if o is None else o.get('pid'),parse_errors=parse_errors,
        refs={k:reference(path) for k,path in paths.items() if local(path).exists()},
        costs=dict(worker_seconds=None if i is None else i.get('seconds'),observer_seconds=None if o is None else o.get('seconds'),
            worker_maxrss=None if i is None else i.get('maxrss'),worker_maxrss_units=None if i is None else i.get('maxrss_units'),
            sampled_peak_rss_bytes=None if o is None else o.get('peak_observed_rss_bytes'))),result


def raw_join(model,raw,c):
    normalized=normal(model);binding=sha(normalized)
    need(raw['model_sha256']==binding or raw['status']=='UNKNOWN' and raw['model_sha256'] is None,'RAW_MODEL_HASH')
    for endpoint in ('entry','final','restored'):
        value=raw[endpoint+'_state'];digest=raw['state_hashes'][endpoint]
        need(digest is None if value is None else sha(value)==digest,'ENDPOINT_BYTE_HASH')
    if raw['entry_state'] is not None:same(raw['entry_state'],raw['restored_state'],'EXACT_ENDPOINT_RESTORATION')
    total=raw['event_extent']['total'];retained=len(raw['events']);h=hashlib.sha256()
    need(raw['event_extent']['retained']==retained<=total,'EVENT_PREFIX_CENSUS')
    for j,e in enumerate(raw['events']):
        need(type(e['seq']) is int and e['seq']==j,'EVENT_SEQUENCE');h.update(wire(e))
    if retained==total:need(h.hexdigest()==raw['event_extent']['sha256'],'FULL_EVENT_STREAM_HASH')
    admitted='UNKNOWN'
    if c['status']=='VERIFIED':
        need(raw['status'] in ('SAT','UNSAT') and c['run_status']==raw['status'] and c['event_coverage']=='COMPLETE'
             and retained==total==c['counts']['decision_events_checked'],'COMPLETE_SEMANTIC_ASSOCIATION')
        need(c['model_sha256']==binding and c['event_sha256']==raw['event_extent']['sha256'],'C_SCOPE_HASHES')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'SCOPED_ABSENCE_BOOL')
        need(c['claim']==('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status']=='SAT'
             else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'),'EXACT_SEMANTIC_CLAIM')
        admitted='POINT_SAT' if raw['status']=='SAT' else 'BOUNDED_EXHAUSTION'
        if raw['status']=='SAT':
            selected=raw['selected'];need(selected==sorted(set(selected)),'EXACT_SELECTED_IDS')
            byid={r['id']:r for r in normalized['inventory']['placements']}
            same(raw['certificate']['placements'],[byid[x] for x in selected],'WHOLE_SELECTED_POINT_ROWS')
        else:need(raw['selected']==[] and raw['certificate'] is None,'NO_UNSAT_PROOF_CERTIFICATE')
    else:
        need(c['bounded_absence'] is False,'UNADMITTED_C_NEVER_ABSENCE')
        if c['status']=='REJECTED':admitted='REJECTED_ASSURANCE'
    if raw['status']=='UNKNOWN':
        need(raw['selected']==[] and raw['certificate'] is None and raw['final_state'] is None,'UNKNOWN_NO_COMMITTED_CERTIFICATE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c.get('reason'),point_admission=admitted,bounded_absence=c['bounded_absence'],
        model_sha256=binding,event_payload_coverage='COMPLETE_EMITTED_PAYLOAD' if retained==total else 'RETAINED_PREFIX',
        semantic_certificate_scope=c.get('claim') if c['status']=='VERIFIED' else 'NO_COMPLETE_PROOF_OR_REFUTATION',
        events_retained=retained,events_emitted=total,stats=raw['stats'],
        scope='Saved semantic receipt and full endpoint/event byte association, not a new replay or observed intermediate producer graph.')


def engine(refs):
    model=readref(refs['model']);raw=readref(refs['raw']);c=readref(refs['semantic'])
    answer=raw_join(model,raw,c);answer['refs']=refs
    return answer,raw


def native_projection(refs,statement,selected,identifier,role,prepared_scope):
    mk='adapter_decoded' if 'adapter_decoded' in refs else 'decoded'
    nk='independent_decoded';bk='native_receipt' if 'native_receipt' in refs else 'native'
    m=readref(refs[mk]);n=readref(refs[nk]);b=readref(refs[bk])
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE','BOTH_NATIVE_DECODERS')
    for key in PROJECTION:same(m[key],n[key],'TWO_DECODER_CONTENT:'+key)
    same(m['scope'],prepared_scope,'EXACT_NATIVE_PREPARED_SCOPE')
    same(m['statement'],statement,'ORIGINAL_NATIVE_STATEMENT');same(m['selected'],sorted(selected),'ACTUAL_SELECTED_PROJECTION')
    need(m['selected_sha256']==sha(sorted(selected)) and m['original_statement_sha256']==sha(statement),'NATIVE_BINDING_HASHES')
    need(b['status']=='VERIFIED' and type(b['checked_lines']) is int and b['checked_lines']==len(m['proof']),'COMPLETE_NATIVE_RECEIPT')
    rule_counts=Counter(line['rule'] for line in m['proof'])
    need(set(rule_counts)<=set(NATIVE_RULES),'NO_HIDDEN_NATIVE_PROOF_RULE')
    need(type(b['rule_counts']) is dict and set(b['rule_counts'])==set(NATIVE_RULES)
         and all(type(x) is int and x>=0 for x in b['rule_counts'].values()),'COMPLETE_NATIVE_RULE_COUNT_TYPES')
    same(b['rule_counts'],{rule:rule_counts[rule] for rule in NATIVE_RULES},'ALL_NATIVE_RULE_COUNTS_BOUND_TO_PROOF')
    need(sum(b['rule_counts'].values())==b['checked_lines'],'NATIVE_RULE_COUNT_WHOLE_LENGTH')
    need(m['proof'] and m['proof'][-1]['formula']==statement['goal'],'UNCHANGED_PROOF_GOAL')
    if 'native_proof' in refs:same(readref(refs['native_proof']),m['proof'],'SAVED_WHOLE_PROOF_BYTES')
    if 'projection' in refs:
        projection=readref(refs['projection'])
        need(projection['adapter_decoded_sha256']==sha(m) and projection['independent_decoded_sha256']==sha(n),'PROJECTION_RECEIPT_CONTENT')
    record=dict(id=identifier,role=role,lines=len(m['proof']),statement_sha256=sha(statement),
        selected_sha256=sha(sorted(selected)),proof_sha256=sha(m['proof']),
        proof_ref=refs['native_proof'] if 'native_proof' in refs else dict(refs[mk],pointer='/proof'),
        native_ref=refs[bk],decoder_refs={mk:refs[mk],nk:refs[nk]},
        rules=dict(Counter(line['rule'] for line in m['proof'])),refs=refs,
        scope='Native receipt/context and exact stored decoder/proof joins only; no native kernel rerun.')
    PROOFS.append(record)
    return record


def graph_receipts(row):
    refs=row['refs'];info,raw=engine(refs)
    observations=readref(refs['observations']);trace=readref(refs['full_graphs']);paired=readref(refs['paired_graphs'])
    need(info['point_admission'] in ('POINT_SAT','BOUNDED_EXHAUSTION')
         and trace['status']==paired['status']=='VERIFIED','COMPLETE_TINY_ASSURANCE')
    need(len(observations)==len(raw['events'])==trace['counts']['observations_checked']
         ==paired['events_checked']==len(paired['comparisons'])==row['actual_snapshots'],'ALL_TINY_OBSERVATIONS_BOUND')
    need(trace['model_sha256']==info['model_sha256'] and trace['run_status']==raw['status'],'TINY_T_MODEL_RESULT')
    for observation,event,comparison in zip(observations,raw['events'],paired['comparisons']):
        same(observation['event'],event,'ACTUAL_EVENT_ORDER')
        need(comparison['equal'] is True and comparison['seq']==event['seq']
             and comparison['kind']==event['kind'] and comparison['actual_sha256']
             ==comparison['reconstructed_sha256']==sha(observation['state']),'C_TO_ACTUAL_MAP_ASSOCIATION')
    need(row['raw_status']==raw['status'] and row['semantic_status']==row['full_graph_status']
         ==row['paired_graph_status']=='VERIFIED' and row['engine_calls']==1,'TINY_ROW_STATUS_CENSUS')
    if 'metrics' in row:same(row['metrics'],raw['stats'],'TINY_ACTUAL_STATS')
    return info,raw,len(observations)


def oracle_covers(ref,model_sha):
    value=readref(ref)
    need(value['status']=='EXHAUSTED' and value['subsets_coverage']=='COMPLETE'
         and value['model_sha256']==model_sha==sha(normal(value['model'])),'COMPLETE_TINY_ORACLE_SCOPE')
    count=len(value['candidate_ids']);need(count<=16 and value['subsets_total']==1<<count
        and len(value['subsets'])==value['subsets_total'],'EVERY_TINY_SUBSET_RETAINED')
    need([r['mask'] for r in value['subsets']]==list(range(1<<count)),'SUBSET_MASK_CENSUS')
    expected=[dict(mask=r['mask'],selected=r['selected']) for r in value['subsets'] if r['solution'] is True]
    same(value['solutions'],expected,'SOLUTIONS_ARE_SAVED_TRUE_SUBSETS')
    need(value['exists'] is bool(expected) and value['witness_exists'] is bool(expected),'ORACLE_EXISTS_ASSOCIATION')
    covers=sorted(wire(sorted(r['selected'])).decode('ascii') for r in expected)
    need(len(covers)==len(set(covers)),'DISTINCT_COMPLETE_COVERS')
    return covers,dict(status=value['status'],exists=value['exists'],solutions=len(covers),
        subsets=value['subsets_total'],model_sha256=model_sha,receipt=ref)


def rank_controls(rows):
    ids=['boolean-rank','foreign-exclusion','missing-guard','wrong-filter','zero-work']
    need([r['id'] for r in rows]==ids,'ALL_FIVE_DECLARED_RANK_CONTROLS')
    output=[]
    for row in rows:
        readref(row['input']);receipt=readref(row['receipt'])
        expected='UNKNOWN' if row['id']=='zero-work' else 'REJECTED'
        need(row['expected']==row['status']==receipt['status']==expected,'RANK_CONTROL_EXPECTATION')
        need(receipt['bounded_absence'] is False and receipt['learned'] is False,'RANK_CONTROL_NOT_PROOF_OR_LEARNING')
        output.append(dict(id=row['id'],status=receipt['status'],reason=receipt.get('reason'),
            seconds=row['seconds'],input=row['input'],receipt=row['receipt']))
    return output


def rank_associations(prepared,base,packet,receipt,marked,control):
    need(packet['schema']=='Rank-pruning-analysis-v1' and packet['status']=='CANDIDATE'
         and receipt['status']=='VERIFIED_REDUNDANT_RANK_CONSTRAINT','COMPLETED_RANK_AND_INDEPENDENT_GATE')
    bindings=dict(catalogue_sha256=sha(prepared['catalogue']),prepared_scope=prepared['binding']['scope'],
        base_model_sha256=sha(normal(base)),slots=prepared['binding']['slots'])
    same(packet['bindings'],bindings,'RANK_INPUT_BYTES');same(receipt['bindings'],bindings,'V_INPUT_BYTES')
    n=len(prepared['catalogue']['formulas']);table=packet['ranks']
    need(type(table) is list and len(table)==n,'FULL_SAVED_RANK_TABLE')
    for fid,pair in enumerate(table,1):
        need(type(pair) is list and len(pair)==2 and type(pair[0]) is int and pair[0]==fid
             and (pair[1] is None or type(pair[1]) is int and 1<=pair[1]<=n),'SAVED_RANK_ENTRY_TYPES')
    forbidden=packet['forbidden'];rows=base['inventory']['placements'];ids=[r['id'] for r in rows]
    need(type(forbidden) is list and forbidden==sorted(set(forbidden)) and set(forbidden)<=set(ids),'SAVED_FORBIDDEN_MEMBERSHIP')
    need([r[0] for r in packet['reasons']]==forbidden,'SAVED_REASON_CENSUS')
    need(receipt['ranks_sha256']==sha(table) and receipt['forbidden_sha256']==sha(forbidden)
         and receipt['reasons_sha256']==sha(packet['reasons']),'V_COMPLETE_PACKET_HASH_ASSOCIATION')
    need(receipt['bounded_absence'] is False and receipt['learned'] is False
         and receipt['preservation']=='ALL_ORIGINAL_COMPLETE_POINT_SOLUTIONS_INCLUDING_PAD_AND_UNUSED_ACTIVE_FACTS','RANK_REDUNDANCY_NOT_ABSENCE_OR_LEARNING')
    for key in ('formulas','rows','slots','zero_definitions','mp_definitions','gen_definitions'):
        need(type(receipt['counts'][key]) is int and receipt['counts'][key]==prepared['census'][key],'V_CENSUS:'+key)
    need(type(receipt['counts']['forbidden_rows']) is int and receipt['counts']['forbidden_rows']==len(forbidden),'V_FORBIDDEN_CENSUS')
    expected=dict(base=sha(normal(base)),marked=sha(normal(marked)),control=sha(normal(control)))
    same(receipt['model_bindings'],expected,'V_ALL_ACTUAL_MODELS')
    for model in (marked,control):
        need(set(model)==set(base),'NO_NEW_MODEL_FIELDS')
        for key in ('schema','capacity','roots','pair_nogoods'):same(model[key],base[key],'UNCHANGED_MODEL:'+key)
        need(model['inventory']['kind']=='EXPLICIT' and len(model['inventory']['placements'])==len(rows),'ALL_ROWS_RETAINED')
    need(base['pair_nogoods']==base['unary_nogoods']==marked['pair_nogoods']==marked['unary_nogoods']==[],'BASE_AND_MARKED_ORDINARY_FILTERS_EMPTY')
    need(marked['version']==base['version']+':rank-marked-v1' and control['version']==base['version']+':rank-filter-v1','RANK_MODEL_VERSIONS')
    same(control['unary_nogoods'],forbidden,'MATCHED_UNARY_FILTER');same(control['seed'],base['seed'],'CONTROL_OLD_SEED')
    same(marked['seed'],dict(t=base['seed']['t'],m=sorted(base['seed']['m']+[[SITE,'0']])),'LITERAL_GUARD_ZERO')
    points=set(base['roots'])
    for kind in ('t','m'):points.update(p for p,v in base['seed'][kind])
    bad=set(forbidden)
    for row,m,f in zip(rows,marked['inventory']['placements'],control['inventory']['placements']):
        points.update(p for p,v in row['t']+row['m']);same(f,row,'FILTER_RETAINS_COMPLETE_OLD_ROW')
        same(m,dict(row,m=sorted(row['m']+([[SITE,'1']] if row['id'] in bad else []))),'ONLY_CERTIFIED_ROW_GUARD_ADDITION')
    need(SITE not in points,'FRESH_MARK_ONLY_SITE')
    return dict(status=receipt['status'],bindings=bindings,model_bindings=expected,
        counts=receipt['counts'],forbidden_count=len(forbidden),forbidden_sha256=sha(forbidden),
        ranks_sha256=sha(table),reasons_sha256=sha(packet['reasons']),work=receipt['work'],seconds=receipt['seconds'],
        learned=False,bounded_absence=False,
        scope='Saved complete V packet/model/hash associations and exact overlay bytes, without recomputing ranks, producer closure or mathematical preservation.')


def planner_receipt(result,prepared,base):
    need(result['schema']=='Conventional-proof-search-v1','CONVENTIONAL_SCHEMA')
    if result['status']=='FOUND_CANDIDATE':
        selected=result['selected'];ids={r['id'] for r in prepared['universe']}
        need(selected==sorted(set(selected)) and set(selected)<=ids and len(selected)==prepared['binding']['slots'],'CONVENTIONAL_ORIGINAL_SELECTED_IDS')
        need(result['selected_sha256']==sha(selected),'CONVENTIONAL_SELECTED_HASH')
        need(result['bindings']['catalogue_sha256']==sha(prepared['catalogue'])
             and result['bindings']['prepared_scope']==prepared['binding']['scope']
             and result['bindings']['slots']==prepared['binding']['slots']
             and result['bindings']['base_model_sha256']==sha(normal(base)),'CONVENTIONAL_ORIGINAL_CONTEXT')
    else:
        need(result['status'] in ('UNKNOWN','REJECTED_INPUT'),'NO_CONVENTIONAL_FALSE_ABSENCE_STATUS')
        need('selected' not in result,'NO_INVENTED_PLAN_ON_REFUSAL')
    return dict(status=result['status'],reason=result.get('reason'),used_rank_analysis=result['used_rank_analysis'],
        costs=result['costs'],limits=result['limits'],bounded_absence=False,
        scope='Saved specialized-control candidate/refusal only; native positive admission is a separate M/N/B join and a control failure is not finite absence.')


def qualification(result):
    need(result['schema']=='Rank-search-qualification-v1' and result['status']=='QUALIFIED','QUALIFICATION_RESULT')
    original=readref(result['original_qualification']);need(original['status']=='QUALIFIED','FRESH_ORIGINAL_QUALIFICATION')
    same(original['counts'],result['original_counts'],'ORIGINAL_QUALIFICATION_COUNTS')
    declarations=read('input/qualification-cases-v1.json')['cases']
    need(len(original['cases'])==20 and len(original['logical'])==2 and len(original['controls'])==9,'ORIGINAL_20_PLUS_TWO_AND_NINE_CONTROLS')
    need([r['id'] for r in original['cases']]==[r['id'] for r in declarations],'ALL_ORIGINAL_TINY_CASE_IDS')
    original_maps=0;original_oracles=[]
    for declared,row in zip(declarations,original['cases']):
        info,raw,maps=graph_receipts(row);original_maps+=maps
        need(raw['status']==declared['expected']['raw_status'],'PROSPECTIVE_TINY_RAW_STATUS')
        covers,summary=oracle_covers(row['oracle'],info['model_sha256'])
        need(bool(covers) is (raw['status']=='SAT'),'TINY_ORACLE_AND_ACTUAL_EXISTENCE');original_oracles.append(summary)
    engine_controls=Counter()
    for row in original['controls']:
        if row['id']=='max-nodes-zero':
            info,raw=engine(row['refs']);need(raw['status']=='UNKNOWN' and info['point_admission']=='UNKNOWN','ZERO_NODE_IS_UNKNOWN')
            engine_controls['UNKNOWN']+=1
        else:
            receipt=readref(row['receipt']);need(receipt['status']=='REJECTED','INVALID_ENGINE_CONTROL_REJECTED')
            engine_controls['REJECTED']+=1
    for row in original['logical']:
        info,raw,maps=graph_receipts(row['engine']);original_maps+=maps
        prepared=readref(row['refs']['prepared']);oracle_covers(row['refs']['oracle'],info['model_sha256'])
        need(info['point_admission']=='POINT_SAT','LOGICAL_QUALIFIER_ACTUAL_POSITIVE')
        native_projection(row['refs'],prepared['statement'],raw['selected'],'qual-'+row['id'],'QUALIFICATION',prepared['binding']['scope'])
    need(original_maps==original['counts']['actual_tiny_snapshots']+original['counts']['actual_logical_snapshots']==176,'ALL_176_ORIGINAL_MAPS')
    extra=read('input/rank-qualification-declarations-v1.json')['cases']
    expected_ids=[r['id'] for r in original['logical']]+[r['id'] for r in extra]
    need([r['id'] for r in result['rank_cases']]==expected_ids and len(expected_ids)==6,'ALL_SIX_PROSPECTIVE_RANK_CASES')
    cases=[];rank_maps=0;rank_engine_calls=0;rank_oracle_calls=0
    for row in result['rank_cases']:
        need(row['status']=='QUALIFIED','TINY_RANK_CASE_QUALIFIED')
        refs=row['refs'];prepared=readref(refs['prepared']);base=readref(refs['base_model'])
        packet=readref(refs['analysis']);receipt=readref(refs['rank_receipt'])
        need([r['lane'] for r in row['actual']]==[r['lane'] for r in row['oracle']]
             ==['BASE','RANK_MARKS','RANK_FILTER'],'TINY_THREE_MATCHED_LANES')
        lane_models={r['lane']:readref(r['refs']['model']) for r in row['actual']}
        same(lane_models['BASE'],base,'TINY_BASE_MODEL_BYTES')
        rank_info=rank_associations(prepared,base,packet,receipt,lane_models['RANK_MARKS'],lane_models['RANK_FILTER'])
        cover_sets=[];oracle_summaries=[]
        for actual,oracle in zip(row['actual'],row['oracle']):
            info,raw,maps=graph_receipts(actual);rank_maps+=maps;rank_engine_calls+=1
            covers,summary=oracle_covers(oracle['receipt'],info['model_sha256']);rank_oracle_calls+=1
            need(oracle['solutions']==len(covers) and bool(covers) is (raw['status']=='SAT'),'RANK_TINY_EXISTENCE_JOIN')
            cover_sets.append(covers);oracle_summaries.append(dict(lane=actual['lane'],**summary))
        same(cover_sets[0],cover_sets[1],'EVERY_ORIGINAL_COVER_SURVIVES_MARKS')
        same(cover_sets[0],cover_sets[2],'EVERY_ORIGINAL_COVER_SURVIVES_FILTER')
        controls=rank_controls(row['controls']);search=readref(refs['conventional_search'])
        plan=planner_receipt(search,prepared,base);need(plan['status']==row['conventional_status'],'QUALIFIED_CONVENTIONAL_STATUS')
        if cover_sets[0]:
            need(search['status']=='FOUND_CANDIDATE' and wire(search['selected']).decode('ascii') in cover_sets[0],'ACTUAL_CONTROL_CANDIDATE_IS_A_COMPLETE_TINY_COVER')
            native=native_projection(refs['conventional_native'],prepared['statement'],search['selected'],
                'qual-plan-'+row['id'],'QUALIFICATION_SPECIALIZED_CONTROL',prepared['binding']['scope'])
            need(row['native_status']=='VERIFIED_NATIVE_PROOF' and row['native_lines']==native['lines'],'QUALIFIED_CONTROL_NATIVE_LINES')
        else:
            need(search['status']=='UNKNOWN' and row['native_status'] is None,'SPECIALIZED_FAILURE_NOT_ABSENCE')
        stopped=readref(refs['conventional_zero_work']);need(stopped['status']=='UNKNOWN','CONVENTIONAL_ZERO_WORK_UNKNOWN')
        if 'input_admission' in row:
            admission=row['input_admission'];model_receipt=readref(admission['model'])
            need(model_receipt['status']=='VERIFIED' and model_receipt['model_sha256']==sha(prepared['model'])
                 and model_receipt['catalogue_sha256']==sha(prepared['catalogue']),'EXTRA_COMPLETE_GENERIC_MODEL_GATE')
            if 'basis' in admission:need(readref(admission['basis'])['status']=='VERIFIED','EXTRA_GROUND_BASIS_GATE')
            native_zeros=readref(admission['zeros']);need([r['id'] for r in native_zeros]
                ==[r['id'] for r in prepared['catalogue']['zeros']],'ALL_EXTRA_ZERO_IDS')
            for z in native_zeros:
                b=readref(z['receipt']);need(b['status']=='VERIFIED' and b['checked_lines']==1,'EXTRA_NATIVE_ZERO_CHECK')
        cases.append(dict(id=row['id'],rank=rank_info,original_rows=len(base['inventory']['placements']),
            cover_count=len(cover_sets[0]),all_three_cover_sets_sha256=sha(cover_sets[0]),oracles=oracle_summaries,
            controls=controls,conventional=plan,refs=refs))
    need(rank_maps==result['rank_actual_snapshots']==129 and rank_engine_calls==result['total_rank_engine_calls']==18
         and rank_oracle_calls==result['total_rank_oracle_calls']==18,'ALL_RANK_QUALIFICATION_GRAPH_ORACLE_COUNTS')
    return dict(status='PASS_SAVED_QUALIFICATION_ASSOCIATIONS',original_engine_calls=22,original_actual_maps=original_maps,
        original_engine_controls=dict(engine_controls),original_oracles=original_oracles,
        rank_engine_calls=rank_engine_calls,rank_actual_maps=rank_maps,rank_oracle_calls=rank_oracle_calls,cases=cases,
        scope='Current actual saved C/T/paired maps, complete tiny subset-cover sets and native receipts bound by hashes/census. No engine, rank checker, oracle or native helper replay.')


def preparation(result):
    r=result['refs'];allrefs(r)
    declaration=readref(r['declaration']);compiled=readref(r['compiled']);generation=readref(r['generation'])
    prepared=readref(r['prepared']);base=readref(r['model']);rf=readref(r['rf_receipt'])
    bridge=readref(r['bridge']);q=readref(r['bridge_receipt']);n=readref(r['model_receipt'])
    same(declaration,read('input/arithmetic-declaration-v1.json'),'ACTUAL_FROZEN_COLD_DECLARATION')
    same(prepared['statement'],declaration['problem'],'ORIGINAL_TARGET_STATEMENT')
    need(rf['status']==q['status']==n['status']=='VERIFIED','FRESH_RF_BRIDGE_MODEL_ADMISSION')
    need(rf['declaration_sha256']==sha(declaration) and rf['compiled_core_sha256']==generation['compiled_core_sha256']
         ==sha({k:v for k,v in compiled.items() if k not in ('costs','scope')}),'FULL_COLD_RF_COMPILED_CORE')
    same(bridge['catalogue'],prepared['catalogue'],'FULL_BRIDGE_CATALOGUE');same(q['bindings'],bridge['bindings'],'BRIDGE_RECEIPT_BINDINGS')
    same(result['prepared_binding'],prepared['binding'],'PREPARED_SCOPE');same(n['census'],prepared['census'],'FULL_N_MODEL_CENSUS')
    need(n['model_sha256']==sha(prepared['model']) and n['universe_sha256']==sha(prepared['universe'])
         and n['catalogue_sha256']==sha(prepared['catalogue'])==bridge['bindings']['catalogue_sha256']
         and n['original_statement_sha256']==sha(prepared['statement']),'WHOLE_PREPARED_MODEL_UNIVERSE_CATALOGUE')
    same(compiled['logical_basis']['formulas'],prepared['catalogue']['formulas'],'ALL_ORIGINAL_RF_FORMULAS_RETAINED')
    zeros=readref(r['zero_native_receipts']);need(len(zeros)==len(compiled['zero_instances'])
        ==prepared['census']['zero_definitions']==result['ZERO_checks'],'EVERY_FRESH_NATIVE_ZERO')
    for z,b in zip(compiled['zero_instances'],zeros):
        need(z['id']==b['id'] and z['formula_id']==b['formula_id'] and sha(z['line'])==b['native_line_sha256']
             and b['receipt']['status']=='VERIFIED' and type(b['receipt']['checked_lines']) is int
             and b['receipt']['checked_lines']==1,'EXACT_NATIVE_ZERO_PAYLOAD_HASH')
    for key in ('capacity','roots','seed','inventory'):same(base[key],prepared['model'][key],'UNCHANGED_LITERAL_MIGRATION:'+key)
    need(base['schema']=='Z-growing-point-model-v3' and base['version']==prepared['model']['version']+':engine-v4'
         and base['pair_nogoods']==base['unary_nogoods']==[] and sha(normal(base))==result['scope_sha256'],'EXACT_ORIGINAL_ENGINE_BASE')
    return dict(status='PASS_SAVED_COLD_PREPARATION_ASSOCIATIONS',census=prepared['census'],ZERO_checks=len(zeros),
        scope_sha256=result['scope_sha256'],costs=result['costs'],refs=r,
        scope='Fresh current compilation/profile/complete-model/native-ZERO receipt associations; no compiler, model or native call replay.'),dict(
        prepared=prepared,base=base,statement=prepared['statement'])


def rank_stage(result,phase,context):
    answer=dict(status='NOT_RUN' if result is None else result['status'],activation_admitted=False)
    if result is None:return answer
    r=result['refs'];answer.update(refs=r,costs=result.get('costs'),reason=result.get('reason'),stopped_stage=result.get('stopped_stage'))
    if context is None:
        answer['scope']='No admitted current prepared context; no rank/model activation inferred.';return answer
    packet=readref(r['analysis']);answer['analysis_status']=packet['status']
    if 'rank_receipt' in r:
        receipt=readref(r['rank_receipt']);answer['independent_status']=receipt['status']
        if packet['status']=='CANDIDATE' and receipt['status']=='VERIFIED_REDUNDANT_RANK_CONSTRAINT':
            marked=readref(r['marked_candidate']);control=readref(r['control_candidate'])
            answer['association']=rank_associations(context['prepared'],context['base'],packet,receipt,marked,control)
    if phase['scientific_admitted']:
        need(result['status']=='RANK_ADMITTED' and result['activation_admitted'] is True
             and answer.get('independent_status')=='VERIFIED_REDUNDANT_RANK_CONSTRAINT','ALL_RANK_ACTIVATION_GATES')
        controls=rank_controls(readref(r['activation_controls']));answer['controls']=controls
        need(result['forbidden_count']==len(packet['forbidden']) and result['prepared_scope']==context['prepared']['binding']['scope'],'RANK_RESULT_SCOPE_CENSUS')
        same(result['model_bindings'],answer['association']['model_bindings'],'ALL_ADMITTED_MODEL_BINDINGS')
        for key,expected in (('base_model',context['base']),('marked_model',marked),('control_model',control)):
            same(readref(r[key]),expected,'EXACT_ADMITTED_MODEL_FILE:'+key)
        answer.update(activation_admitted=True,model_bindings=result['model_bindings'])
    else:
        answer.update(saved_activation_flag=result.get('activation_admitted'),
            scope='Saved child rank/model claim retained, but no current mathematical activation is admitted without clean process and scientific gates.')
    return answer


def evaluation(result,rank,context):
    need(rank['activation_admitted'] is True,'FRESH_POINT_EVALUATION_REQUIRES_RANK_ADMISSION');rows=[]
    need([x['lane'] for x in result['lanes']]==['BASE','RANK_MARKS','RANK_FILTER'],'ACTUAL_THREE_LANE_ORDER')
    for item in result['lanes']:
        lane=item['lane'];key={'BASE':'base','RANK_MARKS':'marked','RANK_FILTER':'control'}[lane]
        info,raw=engine(item['refs']);same(item['stats'],raw['stats'],'ACTUAL_POINT_STATS_LEDGER');same(item['reason'],raw['reason'],'ACTUAL_POINT_REASON_LEDGER')
        need(item['raw_status']==info['raw_status'] and item['semantic_status']==info['semantic_status']
             and item['model_sha256']==info['model_sha256']==rank['model_bindings'][key],'EXACT_FRESH_LANE_BINDINGS')
        if item['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
            need(info['point_admission']=='POINT_SAT' and item['native_status']=='VERIFIED','POINT_NATIVE_REQUIRES_COMPLETE_SAT')
            native=native_projection(item['native_refs'],context['statement'],raw['selected'],'arith-'+lane,'POINT_SEARCH',context['prepared']['binding']['scope'])
            need(item['native_proof_lines']==native['lines'] and item['bounded_absence'] is False,'TARGET_NATIVE_CENSUS')
        elif item['admitted_status']=='VERIFIED_BOUNDED_EXHAUSTION':
            need(info['point_admission']=='BOUNDED_EXHAUSTION' and item['bounded_absence'] is True,'ONLY_COMPLETE_FINITE_ABSENCE')
        else:need(item['bounded_absence'] is False,'UNKNOWN_REJECTED_NATIVE_REFUSAL_NEVER_NEGATIVE')
        rows.append(dict(lane=lane,**info,admitted_status=item['admitted_status'],native_status=item['native_status'],
            native_refs=item.get('native_refs'),costs=item['costs']))
    need(result['native_positives']==sum(r['admitted_status']=='VERIFIED_NATIVE_POSITIVE' for r in rows)
         and result['finite_exhaustions']==sum(r['bounded_absence'] for r in rows),'ACTUAL_RESULT_SUMMARY_CENSUS')
    return dict(status=result['status'],lanes=rows,
        scope='Fresh actual point-search/semantic/native ledger. A complete emitted payload alone does not convert a raw/C UNKNOWN prefix into a proof or finite refutation.')


def baseline(result,context,rank_phase):
    search=readref(result['refs']['search']);info=planner_receipt(search,context['prepared'],context['base'])
    need(result['search_status']==search['status'] and result['bounded_absence'] is False,'CONVENTIONAL_SAVED_STATUS_NOT_ABSENCE')
    need(type(result['rank_information']) is bool and search['used_rank_analysis'] is result['rank_information'],'ACTUAL_CONTROL_INFORMATION_SCOPE')
    if result['rank_information']:
        need(rank_phase['scientific_admitted'] is True and result['rank_custody']=='CLEAN_NATIVE_RANK_PHASE_ADMITTED','CONTROL_RANK_INFORMATION_REAL_PROCESS_GATE')
    if result['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
        need(search['status']=='FOUND_CANDIDATE' and result['native_status']=='VERIFIED','CONVENTIONAL_NATIVE_CANDIDATE')
        native=native_projection(result['native_refs'],context['statement'],search['selected'],'conventional-target','SPECIALIZED_CONTROL',context['prepared']['binding']['scope'])
        need(result['native_proof_lines']==native['lines'],'CONVENTIONAL_NATIVE_LINE_CENSUS')
    else:need(result['admitted_status'] in ('UNKNOWN','REJECTED_NATIVE_PROOF'),'NO_FALSE_CONVENTIONAL_NONDERIVABILITY')
    info.update(admitted_status=result['admitted_status'],native_status=result['native_status'],
        native_refs=result.get('native_refs'),costs=result['costs'],rank_custody=result['rank_custody'],
        rank_information=result['rank_information'],refs=result['refs'])
    return info


def main():
    protocol,frozen=environment();need(protocol['schema']=='Ranked-arithmetic-protocol-v1','CURRENT_RANKED_PROTOCOL')
    phases=[];results={}
    for name in PHASES:
        row,result=process(name,protocol);phases.append(row);results[name]=result
    byphase={r['name']:r for r in phases};qual=dict(status='NOT_RUN_OR_NOT_ADMITTED');prep=dict(status='NOT_RUN_OR_NOT_ADMITTED');context=None
    if byphase['qualify']['scientific_admitted']:qual=qualification(results['qualify'])
    if byphase['prepare']['scientific_admitted']:prep,context=preparation(results['prepare'])
    ranked=rank_stage(results['rank'],byphase['rank'],context)
    evaluated=dict(status='NOT_RUN_OR_NOT_ADMITTED',lanes=[]);conventional=dict(status='NOT_RUN_OR_NOT_ADMITTED')
    if byphase['evaluate']['scientific_admitted']:
        need(context is not None,'EVALUATION_HAS_ADMITTED_PREPARATION');evaluated=evaluation(results['evaluate'],ranked,context)
    if byphase['baseline']['scientific_admitted']:
        need(context is not None,'BASELINE_HAS_ADMITTED_PREPARATION');conventional=baseline(results['baseline'],context,byphase['rank'])
    physical=[]
    for folder in ('data','run'):
        if (ROOT/folder).exists():
            for path in sorted((ROOT/folder).rglob('*')):
                need(not path.is_symlink(),'NO_CURRENT_DATA_SYMLINK')
                if path.is_file():physical.append(dict(path=path.relative_to(ROOT).as_posix(),**filepin(path)))
    for ref in list(LEDGER.values()):same(filepin(local(ref['path'])),{k:ref[k] for k in ('bytes','sha256')},'FINAL_REFERENCED_BYTES_UNCHANGED')
    output=dict(schema='Ranked-arithmetic-passive-audit-v1',status='PASS_SAVED_RANKED_OUTCOMES_WITH_EXPLICIT_SCOPES',
        check_count=CHECKS,protocol=reference(PROTOCOL),frozen=frozen,phases=phases,
        qualification=qual,preparation=prep,rank=ranked,evaluation=evaluated,baseline=conventional,native_proofs=PROOFS,
        native_proof_counts=dict(Counter(row['role'] for row in PROOFS)),physical_files=physical,
        artifact_pins=[LEDGER[k] for k in sorted(LEDGER)],
        scope='Passive current file/process/hash/census/native-decoder associations only. No rank computation, compiler, model, oracle, engine, semantic/fullgraph checker, learner or native kernel imported/called/replayed. All current outcomes remain distinct from process completion. No prior run data used, no learned/RL/geometric/universal-Wang or cold comparative-speed claim; archive and publication are separate gates.')
    with local(OUTPUT).open('xb') as stream:stream.write(wire(output))
    print(json.dumps(dict(status=output['status'],receipt=reference(OUTPUT),checks=CHECKS,native_proof_counts=output['native_proof_counts'])))


if __name__=='__main__':
    main()

