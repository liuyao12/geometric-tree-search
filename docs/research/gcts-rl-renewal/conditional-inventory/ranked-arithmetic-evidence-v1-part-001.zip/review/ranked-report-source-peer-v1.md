# Ranked arithmetic reader Source peer

Status: `PASS_SOURCE_ONLY_REVIEW`. Full renderer/API review found no
outstanding blocker. This is not a passive build, executed saved-data audit,
native check, browser qualification or publication receipt.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `publication/build_ranked_report_v1.py` | 47959 | `efeb647c205c0c73c17e576301caf7f634a65c613c1a6cedaa5359916de6b373` |
| `publication/ranked-report-API-v1.md` | 5518 | `d0cfc1a6416ca9d57a699afa71cc80a75952244a8c978d0d8a78f08028006cac` |

Only direct Source reads, byte hashing and a standard-library AST parse were
performed. No renderer/scientific module was imported, no build/helper/checker/
kernel/search was run, and no frozen Source or input was edited.

The reader is cold/current-root only. It checks the exact frozen file/review
set, current runtime/version/flags/binary and master, then joins all five phase
positions to their actual protocol, PID, result/log bytes, native exit, guards
and frozen postchecks. It distinguishes phase completion from scientific
admission and proof admission. Its required independent audit joins the current
protocol and every phase PID/native/scientific/process/admission field.

Proof construction preserves complete original M/N semantic projections,
literal selected rows and saved native proof/receipt references. Point proofs
add actual C-verified SAT, exact selected IDs and model/event hash joins.
Specialized planner proofs are explicitly attributed to that separate control;
they receive no invented GCTS trace. Every displayed proof must match an
audited ID, role, full proof hash, line count, statement/selection hashes and
artifact refs, including the decoded-packet `/proof` pointer. The agreed IDs
and roles are `qual-*`/`QUALIFICATION`,
`qual-plan-*`/`QUALIFICATION_SPECIALIZED_CONTROL`,
`arith-*`/`POINT_SEARCH` and `conventional-target`/`SPECIALIZED_CONTROL`.
No target-positive count or baseline outcome is hardcoded.

Raw and semantic UNKNOWN states stay visible and supply no bounded absence.
Complete retained event payload is explicitly distinguished from completed
search. Unresolved lane choices clear the proof, goal, slot diagram and raw
proof view; they do not borrow a qualifier or conventional proof. Actual
point-target proofs receive default priority when present. Qualification
examples remain conspicuously separate and are not counted as target theorems.

The rank view uses actual saved formula ranks/reasons/counts and the independent
receipt, without recomputing derivability. The candidate/activation distinction,
five controls, exact admitted model hashes and whole inventory remain visible.
The text states the earliest-slot necessary bound, covers own and remote
positive requests and unused facts, exempts PAD zero, and distinguishes
derivation height from minimum DAG line count and growth generation. It calls
this analytically certified pruning, not learned marking discovery or RL.

The native reader uses the established serialized MathJax queue and actual
saved ASTs, with explicit display-only aliases and original names available.
Orange activity, purple formula IDs, the literal extra guard and arrows from
actual earlier-slot references are distinguished. The cards are described as
anchored symbolic point slots, not a fixed universal Wang palette. Line/slot
interaction and PAD-null highlighting remain consistent with saved maps.

All five current process intervals, native high-water RSS and cold preparation,
rank/control, point-search/assurance and specialized-control cost scopes remain
inspectable. Overlapping intervals and unlike work/state units are not summed
as comparable speed. The report does not assume a winner, superiority, full PA/
induction, learned marking, RL, geometric transfer or universal tile-set result.

The renderer imports only standard-library file/JSON/hash/gzip modules. Paths
are contained and reject symlinks; artifact reads are bounded, large raw lane
objects leave the cache after projection, and all output files are exclusive.
There is no Git/network/push or primary-checkout staging operation. Actual
terminal outcomes, executed passive audit, first build, final UI and separate
publication gates remain required before live-result claims.
