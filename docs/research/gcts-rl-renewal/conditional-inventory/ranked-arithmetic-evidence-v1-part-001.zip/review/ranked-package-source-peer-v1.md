# Ranked arithmetic packager Source peer

Status: `PASS_SOURCE_ONLY_REVIEW`. The complete held packager and API were
read; no outstanding blocker was found. This is not package execution, archive
verification, Git preparation, UI qualification or live-publication admission.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `publication/package_ranked_v1.py` | 36079 | `dc6fdd18261dbf63ffd941c4f3c5c15f85256d381a57f84e7af214403acec3a6` |
| `publication/package-ranked-API-v1.md` | 7907 | `15895148e8c4863f3d84b5761236752ac8832186cf658addbab8a6771d254a34` |

Only direct Source reads, byte hashing and a standard-library AST parse were
performed. The packager was not imported or executed. No scientific helper,
build, package, network, Git, push or mirror operation was performed. No Source
or frozen scientific file was changed.

## Current cold evidence and proof scope

The fixed protocol pin, schema/status, complete dynamic frozen file set,
historical Source admission, current runtime/isolation/binary and current master
plus reference copy are checked. Five phase positions are retained:
`qualify`, `prepare`, `rank`, `evaluate`, `baseline`. Actual started/invocation/
observer PID/phase/protocol, result/log byte pins, native exit, guards and frozen
postchecks determine clean process and scientific admission. Missing, partial,
refused and UNKNOWN outcomes are represented without a fabricated successful
phase. No reused output namespace, prior LABEL gate or historical proof input
is required or consumed by this milestone.

The independent passive audit must have the exact ranked schema/status and
current protocol. Its phase classifications join actual process data; rank
activation has an explicit boolean scope. The report must bind the actual audit,
current protocol/process projection, renderer and all artifact pins. Its native
proof ID collection is exactly the independent audit collection, without
omitted qualifiers or invented target positives. Roles, line counts,
statement/selection hashes, complete native/proof artifact refs, optional
`/proof` pointer, saved whole proof and native receipt are joined. Public
selected-row IDs must hash to the admitted selection.

Qualification, point-search and specialized conventional proofs stay distinct.
The README/API explicitly distinguish rank lower bounds from minimum proof
size, redundant constraints from learning, conventional candidate search from
the GCTS scheduler, emitted payload from complete search, and workflow status
from proof success. No target-positive count, winner, speed advantage, RL gain,
full PA/FOL completeness or universal Wang encoding is predetermined. The
larger program remains ACTIVE.

## Report and final publication readiness

The pre-build Source/data authority is separate from final publication
admission. Original renderer bytes are preserved and hashed. Collapsing the one
archive marker region must leave the current main page equal to the original;
unrelated HTML edits cannot pass as archive insertion.

`--prepare-links` plans the volume links without network/Git, preserves earlier
differing plans and is forbidden after a cut/prepared receipt. Packaging requires
the actual postlink main/data pins, final UI with zero math errors, no overflow,
empty fatal/console fields, and Root publication admission binding all nine
required current protocol/report/audit/tool/UI/build-authority paths. Historical
Source approval alone cannot authorize final publication bytes.

## Physical archive and custody

Every current-root file except generated `package/` outputs is included at the
cut under its own original path. Symlinks and canonical-path violations refuse.
Equal bytes at different paths remain separate physical members. The changed
predecessor-reader backlink is materialized before collecting originals, so it
is included in this same physical archive. Later index/commit/push/Pages/live
receipts are explicitly postcut custody, not claimed inside their own archive.

Independent ZIP volumes have a 44 MiB ceiling and remain strictly below
50 MiB. Each contains the complete internal inventory. Verification reads every
member, checks exact member sets, duplicates, inventory bytes, CRC, uncompressed
size/SHA-256, physical cross-volume coverage and complete volume hashes. Every
original cut path and the entire cut set are rechecked before Git preparation.
There is no alias table or remote dependency replacing an original member.
Changed final volume count refuses before the archive cut instead of publishing
stale links/UI.

## Existing destination and isolated Git

The official GitHub GET discovers the current `main` commit and checks a
supplied expected SHA when present. The exact remote is checked again before
local commit preparation. No fetch, branch update or push is performed by this
script. The caller must make that commit object available in the existing
isolated bare repository.

Git environment variables are cleared and an exclusive task-local index is
used. Hooks and automatic GC are disabled for mutations. The primary checkout,
index and unrelated tree are untouched. New public asset collisions refuse.
Only the ranked HTML, data, manifest and volume assets are added; the existing
streamed reader receives the sole allowed backlink edit. With one ZIP this is
five public assets; further volumes add only their declared archive asset paths.
The prepared tree, exact sole parent and complete name/status diff are checked.
The prepared receipt explicitly says `pushed:false`.

Actual Root-reviewed audit/build/UI/final-admission products, a successful
package execution, normal push and full live asset/archive readback are still
separate outstanding publication gates. This Source review does not attest
that any of those actions occurred.
