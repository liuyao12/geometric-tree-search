Cold finite arithmetic proof search and certified derivation-height exclusions.

Download EVERY ranked-arithmetic-evidence-v1-part-NNN.zip together with
ranked-arithmetic-evidence-manifest-v1.json and extract into one directory.
Every independent volume is at most 44 MiB and contains the same complete
ARCHIVE-file-manifest-v1.json. Every original current-run path present at the
cut is physically stored once. Equal bytes at distinct paths are stored
separately; no alias table or remote reference substitutes for original bytes.
All member sizes/SHA256, CRCs, exact path sets and physical volume hashes are
verified before commit preparation.

All current Source/input/reference/plan/review files, raw events/endpoints,
UNKNOWN/refusal/failure outcomes, genuine native receipts, logs, current report
data, publication tools/planning, local paths, original renderer snapshot and
changed predecessor-reader backlink asset are included. Only generated
package/ outputs are excluded from their own input cut. Index/commit/push/Pages/
live receipts created after the cut are later custody files, not claimed inside
their own earlier archive. Predecessor archives remain separately linked;
there is no warm prior-output namespace or historical proof input in this run.
Full current evidence and local paths/logs are user-approved for this existing
public destination; no new audience is created.

Serve the extracted directory and open report/ranked-arithmetic-v1.html.
Actual passive audit/process receipts distinguish qualification, cold full
preparation, rank admission, point-search evaluation and conventional control.
Only exactly native-admitted records appear as proofs, with explicit roles.
Qualification/control proofs are not silently relabeled as GCTS target proofs.
UNKNOWN prefixes, complete emitted payloads and bounded exhaustion retain
separate scopes. A workflow word such as EVALUATED is not proof success.

Ranks are derivation-height lower bounds, not minimum proof-line/DAG size.
Certified rank exclusions test every positive formula demand and preserve the
whole original inventory through redundant markings or a matched filter.
Rank generation/admission and fresh full RF/native ZERO/model checks cost time;
no prior proof, bank, known bad CID or prepared output is a search input.
The conventional shared-fact planner is an explicitly specialized acyclic
unique-formula control; it is not the GCTS scheduler and its failures mean
UNKNOWN. Read actual saved lane/phase statuses, roles and complete validation
receipts before drawing a conclusion. No winner, theorem, speed advantage,
RL gain, full PA/FOL completeness or fixed universal Wang search is assumed.
The larger research program remains ACTIVE.
