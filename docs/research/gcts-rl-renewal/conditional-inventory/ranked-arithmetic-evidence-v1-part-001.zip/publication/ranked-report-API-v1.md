# Cold ranked-arithmetic passive reader

Source: `publication/build_ranked_report_v1.py`. Source-only until Root review;
no build or scientific helper import/call is authorized during authoring. The
reader adapts the held v3 code but has five fresh cold phases and no prior/warm
namespace. Use the pinned Python executable with `-I -S -B` when Root builds.

## Saved-data gates and projection

The builder checks `protocol/frozen-protocol-v1.json`, schema
`Ranked-arithmetic-protocol-v1`, exact frozen file set, reviewed refs, isolated
runtime/version/binary and current master. Each phase's actual PID, native
exit, result/log pins, scientific status and source postchecks remain separate
from its scientific admission. Missing/refused/UNKNOWN phases stay explicit.

Mandatory audit is `review/passive-ranked-outcomes-v1.json`, schema
`Ranked-arithmetic-passive-audit-v1`, status
`PASS_SAVED_RANKED_OUTCOMES_WITH_EXPLICIT_SCOPES`. Its protocol, five phase
PID/native/science/process/admission fields and every displayed native proof's
role, line count, statement/selection/proof hashes and artifact refs are joined.
Audit PASS does not mean target-proof or search success.

Only standard-library file/JSON/gzip/hash operations are used. Relative paths
reject symlinks/root escape. JSON reads have a 128 MiB decompressed bound;
large raw objects leave the cache after projection. Canonical metadata SHA
uses the standard-library incremental encoder. No engine transition, rank
analysis, graph, subset oracle, compiler or kernel is replayed.

Data schema is `Ranked-arithmetic-reader-data-v1`, status
`PASS_PASSIVE_SAVED_DATA_PROJECTION`. Main fields:

- `phases`, `declaration`, `aliases`, `preparation`: actual five current
  processes and cold full RF/slot/row/native-ZERO admission and costs.
- `rank`: actual analysis, independent receipt, explicit `activated` and
  identical `activation_admitted`, full rank table/formula registry, derived
  forbidden counts by owner kind/slot, selected literal reason examples,
  controls and artifact refs. A candidate can remain unactivated. Complete
  forbidden/reason lists remain in the original archive, not duplicated into
  the reader. Rank is derivation height, not shared-DAG line count or growth
  generation. PAD zero is exempt; unused active facts remain covered.
- `lanes`: admitted fresh BASE/RANK_MARKS/RANK_FILTER records, actual raw/C/
  native/UNKNOWN status, statistics, costs and first/last retained event
  samples. Complete emitted payload is not completed search or finite absence.
- `baseline`: actual specialized planner status, checked-candidate admission,
  optional clean rank-custody information, search/preparation costs and refs.
  Failure never becomes absence; the planner is not master GCTS.
- `qualification`: original fresh engine counts and six tiny rank cases,
  actual map/oracle/control counts and exact complete-cover-set summaries.
  The generic literal nested-GEN fixture is not labeled a full RF profile.
- `proofs`: unchanged native ASTs, decoded slot/reference maps, literal
  selected rows and artifact associations. Point proofs require actual
  C-verified SAT plus both M/N projections and whole B. Specialized proofs
  have M/N/B admission and their separate finder attribution.
- `protocol`, `saved_data_audit`, `saved_data_audits:[{ref,status}]`,
  `provenance.artifact_pins`, `scope`.

Proof IDs/roles align with the auditor:

| ID | Role |
|---|---|
| `qual-<J logical id>` | `QUALIFICATION` |
| `qual-plan-<rank case id>` | `QUALIFICATION_SPECIALIZED_CONTROL` |
| `arith-BASE`, `arith-RANK_MARKS`, `arith-RANK_FILTER` | `POINT_SEARCH` |
| `conventional-target` | `SPECIALIZED_CONTROL` |

Each retains `audit_id=id`, `line_count`, `statement_sha256`,
`selected_sha256`, `proof_ref`, `native_ref`, exact proof/statement/selected
rows and maps. A qualifier's decoded packet can use pointer `/proof`. At most
seven successful qualification proofs are displayed; they are not target
results. Actual point-target proofs are preferred, then a separately labeled
conventional-target proof. Unresolved point options clear the proof and diagram.

## Outputs and publication

Exclusive outputs:

- `report/ranked-arithmetic-v1.html`.
- `report/ranked-arithmetic-data-v1.json.gz`, deterministic gzip/canonical JSON.
- `report/build-receipt-v1.json`, schema
  `Ranked-arithmetic-passive-build-v1`, status
  `PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`.

Receipt fields are `outputs:{main,data}`, `renderer_source`, `protocol`,
`phases`, `artifact_pins`, `scope`, with `{path,bytes,sha256}` refs. It is
archive-only. Main has `#reader`, `#evidence` and one marker:

```html
<!-- RANKED_ARITHMETIC_ARCHIVE_LINK -->
```

Predecessor/backlink is `streamed-arithmetic-v1.html`. Planned archive names
are `ranked-arithmetic-evidence-v1-part-NNN.zip` and
`ranked-arithmetic-evidence-manifest-v1.json`. Root owns archive insertion,
original-render preservation, final UI, admission and existing-site deployment.

Proof cards retain orange activity, purple formula, blue/red extra guard
layers, actual earlier-reference arrows, line/slot interaction and original
AST/literal-name inspection. Formula and English rule explanations use the
established serialized MathJax queue. All cold qualification/preparation/rank/
control/search/native-assurance process costs and native high-water RSS remain
visible. No RL, learned marking, full PA/induction, fixed universal Wang search,
new theorem, held-out transfer or performance advantage is assumed.
