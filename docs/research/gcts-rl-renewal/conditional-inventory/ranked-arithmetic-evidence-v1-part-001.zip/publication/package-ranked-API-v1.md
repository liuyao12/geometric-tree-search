# Cold ranked arithmetic publication preparation

Source-only handoff. Held `publication/package_ranked_v1.py` is 36,079 bytes / SHA256 `dc6fdd18261dbf63ffd941c4f3c5c15f85256d381a57f84e7af214403acec3a6`. Root must review its full body and peer closure before invoking it. No scientific import/call, build, package, Git or network operation was performed by the author. The immutable baseline is V3 `package_streamed_v1.py`, 37,486 bytes / SHA256 `6616e32444215554d88e63b0b5f3e1728a799dfe71e59d594fd961332149c728`; the full and compact zero-context adaptation patches both contain all textual changes.

## Order and commands

First prepare links, using the frozen runtime:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_ranked_v1.py --prepare-links
```

This checks current saved gates, preserves `publication/rendered-before-archive-links-v1.html`, writes the README and fills only the `RANKED_ARITHMETIC_ARCHIVE_LINK` marker region. Volume-count planning reaches a fixed point and saves `publication/archive-plan-v1.json`, retaining any differing prior plan. This step uses no Git/network. Then Root must run final UI on the exact postlink bytes and write the separate final publication admission below.

Root must fetch the current official `main` into the existing isolated bare repository, then may prepare one local commit:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_ranked_v1.py EXPECTED_REMOTE_MAIN_SHA
```

The final SHA is optional: omission means Root intentionally accepts the official main discovered by this invocation. The tool performs an official GitHub GET, checks any supplied SHA, then rechecks the remote immediately before local Git preparation. It never fetches, pushes or updates a branch. A changed supplied parent or absent local base object refuses preparation.

## Final UI and Root gate

`publication/local-ui-v1.json` requires actual postlink observations and pin:

```json
{"status":"PASS_LOCAL_UI","source":{"path":"report/ranked-arithmetic-v1.html","bytes":0,"sha256":"ACTUAL_POSTLINK_SHA256"},"math_errors":0,"body_overflow":false,"fatal":"","console":[]}
```

Zero is an illustrative size only; replace it with the actual native integer. Extra screenshot/observation fields are allowed. `publication/root-publication-admission-v1.json` has enforced status `PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES`; recursively every relative file reference is verified. Exactly these nine paths are mandatory (extra reviewed references are allowed):

```json
{
 "schema":"Root-ranked-publication-admission-v1",
 "status":"PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES",
 "reviewed":[
  {"path":"protocol/frozen-protocol-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"report/ranked-arithmetic-v1.html","bytes":0,"sha256":"ACTUAL_POSTLINK_SHA256"},
  {"path":"report/ranked-arithmetic-data-v1.json.gz","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"publication/build_ranked_report_v1.py","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"publication/package_ranked_v1.py","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"review/passive-ranked-outcomes-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"publication/local-ui-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"report/build-receipt-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
  {"path":"review/root-passive-publication-admission-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"}
 ],
 "scope":"Reviewed bytes with actual cold-search, rank-admission and specialized-control scopes; no assumed winner."
}
```

Replace every illustrative pin. `schema` and `scope` are documentary; status and reference coverage are enforced. The before-build file `review/root-passive-publication-admission-v1.json` remains separate: schema `Root-passive-publication-admission-v1`, status `PASS_SOURCE_READ_AND_SAVED_DATA_AUDIT_BEFORE_BUILD`. Changed postlink HTML requires renewed final UI/admission.

## Actual evidence, not assumed results

The current protocol is exactly 7,174 bytes / `2b38971540547b693c9d47c01081bddab71b7d5c64b47ee2c3145576190ce7e7`, schema `Ranked-arithmetic-protocol-v1`, status `FROZEN_BEFORE_SCIENTIFIC_IMPORTS`. The complete dynamic frozen Source/reference/input/plan set plus four source-admission review references must match, as must current runtime/isolation/master bytes. Current source admission is `Rank-search-root-source-admission-v1` / `PASS_SOURCE_REVIEW_BEFORE_FREEZE`.

The five positions are `qualify`, `prepare`, `rank`, `evaluate`, `baseline`. Actual retained process/log/result/PID/protocol/native exit/guard/postcheck data determine process/scientific admission. Missing, failed, refusal or UNKNOWN outcomes are preserved; a workflow word is not a proof. Required passive products are:

- `review/passive-ranked-outcomes-v1.json`: `Ranked-arithmetic-passive-audit-v1` / `PASS_SAVED_RANKED_OUTCOMES_WITH_EXPLICIT_SCOPES`;
- `report/build-receipt-v1.json`: `Ranked-arithmetic-passive-build-v1` / `PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`;
- public data: `Ranked-arithmetic-reader-data-v1` / `PASS_PASSIVE_SAVED_DATA_PROJECTION`.

All current phase and native proof collections must match the audit, including exact roles, statement/selected hashes, whole stored proof (`/proof` pointer supported), native receipt and line counts. Qualification, point-search and specialized conventional proofs remain distinct. A specialized planner failure is UNKNOWN, not absence; complete emitted payload can still be only a search prefix. No prior output/prepared namespace or warm gate is consumed. Rank is derivation height, not minimum shared-DAG size. No target proof, acceleration, GCTS/RL advantage or fixed universal Wang search is assumed by the publisher. The research program remains ACTIVE.

## Physical archive, exact diff and outputs

Every original current-run file present at the cut is physically stored once under its own path, including equal-byte copies, all Sources/reviews/raw outcomes/logs/local paths and publication tools. Only generated `package/` outputs are excluded. Before cutting, the old reader plus its sole backlink is materialized at `publication/previous-report-with-backlink-v1.html`, so those changed bytes are archived too. Later index/prepared/push/Pages/live custody is explicitly postcut; prior archives stay separately linked, not silently counted.

Independent ZIPs are at most 44 MiB and strictly below 50 MiB; each carries the complete `ARCHIVE-file-manifest-v1.json`. Every original member, exact set, CRC, size/SHA256, physical coverage and volume hash is read back; no alias or remote pointer substitutes for originals. All cut bytes and the complete cut set are rechecked before Git. A changed final volume count refuses before cutting and requires replan/UI renewal.

The prefix is `docs/research/gcts-rl-renewal/conditional-inventory/`. Only existing `streamed-arithmetic-v1.html` may be modified, with one backlink. Additions are `ranked-arithmetic-v1.html`, `ranked-arithmetic-data-v1.json.gz`, `ranked-arithmetic-evidence-manifest-v1.json` and all `ranked-arithmetic-evidence-v1-part-NNN.zip`. Existing new-path collisions refuse via `ls-tree`. Bare Git `/private/tmp/gcts-history-publication-20261102-v1.git` and new `publication/index-v1` preserve the primary checkout/index and unrelated tree. Sole parent/tree/exact name-status diff are checked. No push occurs.

Success writes `publication/prepared-v1.json`, status `PREPARED_TASK_ASSETS_ONLY`, with exact commit/tree/base, all asset pins/URLs/blobs, archive verification/readiness and `pushed:false`. An existing package directory, prepared receipt or isolated index refuses a retry over earlier bytes. Root separately owns push, official Pages/remote checks, full live asset/archive verification and mirroring.
