"""Passive QMT saved-data reader. Never import scientific modules or replay.

Read frozen protocol/file/process pins and actual completed/refused phase
outputs. A missing/stopped phase is displayed, not replaced with a proof.
Root reviews Source before executing this assembler/renderer.
"""
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'report'
PROTOCOL='protocol/frozen-protocol-v1.json'
PHASES=['qualify','prepare','rank','evaluate','baseline']
SEMANTIC=['statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
          'proof_dag','selected','selected_sha256','original_statement_sha256','scope']
LEDGER={};CACHE={};BOUND=134217728


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):
    h=hashlib.sha256();n=0
    for text in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(x):
        raw=text.encode('ascii');n+=len(raw);need(n<BOUND,'PASSIVE_METADATA_HASH_BOUND');h.update(raw)
    h.update(b'\n');return h.hexdigest()
def same(a,b,why):need(wire(a)==wire(b),why)


def bytepin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())


def local(name):
    need(type(name) is str and bool(name),'RELATIVE_PATH');p=Path(name)
    need(not p.is_absolute() and '..' not in p.parts,'ROOT_PATH')
    out=ROOT
    for part in p.parts:out=out/part;need(not out.is_symlink(),'NO_SYMLINK')
    need(out.resolve().is_relative_to(ROOT),'ROOT_CONTAINMENT');return out


def pin(name):
    value=dict(path=name,**bytepin(local(name)));LEDGER[name]=value;return value


def read(name,reference=None):
    value=pin(name)
    if reference is not None:
        same(value,{k:reference[k] for k in ('path','bytes','sha256')},'EXACT_SAVED_BYTES:'+name)
        need(reference.get('complete_json',True) is True,'COMPLETE_SAVED_JSON')
    if name not in CACHE:
        p=local(name)
        with gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb') as f:b=f.read(BOUND+1)
        need(len(b)<=BOUND,'JSON_READ_BOUND');CACHE[name]=json.loads(b)
    return CACHE[name]


def projected(ref,prefix=''):
    need(not prefix,'COLD_CURRENT_ROOT_ONLY');return ref


def checked(ref,prefix=''):
    need(not prefix,'COLD_CURRENT_ROOT_ONLY');return read(ref['path'],ref)


def refs_in(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=value.keys():
            same(pin(value['path']),{k:value[k] for k in ('path','bytes','sha256')},'EXACT_ARTIFACT_REF')
            need(value.get('complete_json',True) is True,'COMPLETE_CAPTURE')
        else:
            for v in value.values():refs_in(v)
    elif type(value) is list:
        for v in value:refs_in(v)


def environment():
    p=read(PROTOCOL);need(p['schema']=='Ranked-arithmetic-protocol-v1' and p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    a=read('review/root-source-admission-v1.json');need(a['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix!='.pyc' and '__pycache__' not in path.parts,'NO_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for ref in a['reviewed']:
        same(pin(ref['path']),{k:ref[k] for k in ('path','bytes','sha256')},'REVIEW_PIN');names.add(ref['path'])
    same([pin(n) for n in sorted(names)],p['files'],'EXACT_FROZEN_SET')
    executable=Path(sys.executable).resolve()
    runtime=dict(executable=dict(path=str(executable),**bytepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    need(sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'ISOLATED_PINNED_RUNTIME')
    same(runtime,p['runtime'],'CURRENT_RUNTIME')
    master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
    same(dict(path=str(master),**bytepin(master)),p['master'],'CURRENT_MASTER')
    return p,dict(runtime=runtime,master=p['master'],frozen_files=len(names))


def phase(name,protocol,prefix=''):
    paths=dict(result=prefix+'data/'+name+'/result.json',started=prefix+'run/'+name+'/started.json',
        invocation=prefix+'run/'+name+'/invocation.json',observer=prefix+'run/'+name+'/observer.json')
    values={k:read(n) for k,n in paths.items() if local(n).exists()}
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    state='NOT_RUN' if not values else 'IN_PROGRESS_OR_INCOMPLETE';clean=False
    protocol_ref=pin(prefix+PROTOCOL)
    expected_protocol=dict(protocol_ref,path=PROTOCOL)
    if s is not None:same(s['protocol'],expected_protocol,'STARTED_PROTOCOL');need(s['phase']==name,'STARTED_PHASE')
    if i is not None:need(i['phase']==name,'INVOCATION_PHASE')
    if o is not None:
        need(o['phase']==name,'OBSERVER_PHASE')
        same(projected(o['log'],prefix),pin(prefix+'run/'+name+'/stdout.log'),'OWNED_LOG_BYTES')
        state='FAILED_OR_STOPPED_PROCESS'
    if s is not None and i is not None and o is not None:
        need(all(type(x['pid']) is int and x['pid']>0 for x in (s,i,o)) and s['pid']==i['pid']==o['pid'],'PHASE_PID')
        if i.get('result') is not None:
            same(checked(i['result'],prefix),result,'EXACT_PHASE_RESULT_BYTES')
            need(i['scientific_status']==result['status'],'INVOCATION_SCIENCE_STATUS')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None and i.get('result') is not None
            and result is not None and i.get('scientific_status')==result['status']
            and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==protocol['status'])
        state='CLEAN_RECORDED_PHASE' if clean else 'FAILED_OR_STOPPED_PROCESS'
    if result is not None:refs_in(result)
    record=dict(name=name,namespace=prefix or 'CURRENT_ROOT',process_status=state,
        pid=None if o is None else o['pid'],native_exit_code=None if o is None else o['native_exit_code'],
        process_clean=clean,scientific_status=None if result is None else result['status'],
        worker_seconds=None if i is None else i['seconds'],observer_seconds=None if o is None else o['seconds'],
        worker_highwater_rss_bytes=None if i is None else i['maxrss']*(1 if i['maxrss_units']=='bytes' else 1024),
        guard_reason=None if o is None else o['guard_reason'],error=None if i is None else i['error_type'],
        protocol_ref=protocol_ref,refs={k:pin(n) for k,n in paths.items() if k in values})
    record['admitted']=clean and result is not None and result['status']==protocol['admitted_statuses'][name]
    return record,result


def event_sample(raw):
    events=raw.get('events',[]);indices=sorted(set(range(min(12,len(events))))|set(range(max(0,len(events)-12),len(events))))
    out=[]
    for index in indices:
        e=json.loads(wire(events[index]))
        if e['kind']=='BRANCH':
            d=e['data'];e['data']=dict(generation=d['generation'],legal_count=len(d['legal']),
                order_count=len(d['order']),first_candidate=d['order'][0])
        out.append(e)
    return dict(records=out,retained_payload_rows=len(events),emitted_total=raw['event_extent']['total'],
                scope='First/last retained event sample; last retained is not an omitted suffix. Full original domains and payloads remain in the archive.')


def engine_summary(refs):
    raw=checked(refs['raw']);CACHE.pop(refs['raw']['path'],None);c=checked(refs['semantic'])
    if c['status']=='VERIFIED':
        need(raw['status']==c['run_status'] and c['event_coverage']=='COMPLETE','SEMANTIC_RAW_JOIN')
        same(c['event_sha256'],raw['event_extent']['sha256'],'SEMANTIC_EVENT_BINDING')
        same(c['model_sha256'],raw['model_sha256'],'SEMANTIC_MODEL_BINDING')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'EXACT_ABSENCE_SCOPE')
    else:need(c['bounded_absence'] is False,'NO_UNKNOWN_ABSENCE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c['reason'],bounded_absence=c['bounded_absence'],stats=raw['stats'],
        event_extent=raw['event_extent'],rollback_extent=raw['rollback_extent'],sample=event_sample(raw),
        selected=raw['selected'],refs=refs,producer_intermediate_bookkeeping='NOT_OBSERVED_IN_LARGE_RUN')


def proof_record(identifier,kind,label,m,n,b,model,refs,catalogue,aliases):
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE' and b['status']=='VERIFIED','ONLY_ADMITTED_PROOFS')
    for k in SEMANTIC:same(m[k],n[k],'TWO_NATIVE_PROJECTIONS:'+k)
    same(b['checked_lines'],len(m['proof']),'WHOLE_NATIVE_PROOF_COUNT')
    same(sha(m['statement']),m['original_statement_sha256'],'PROOF_ORIGINAL_STATEMENT')
    byid={x['id']:x for x in model['inventory']['placements']}
    need(all(cid in byid for cid in m['selected']),'SELECTED_LITERAL_ROWS')
    proof_ref=refs.get('native_proof')
    if proof_ref is None:proof_ref=dict(refs['decoded'],pointer='/proof')
    native_ref=refs.get('native_receipt',refs.get('native'))
    need(native_ref is not None,'EXACT_NATIVE_RECEIPT_REFERENCE')
    return dict(id=identifier,audit_id=identifier,role='QUALIFICATION' if kind=='QUALIFICATION' else 'EVALUATION',
        kind=kind,label=label,statement=m['statement'],proof=m['proof'],slots=m['slots'],
        line_count=len(m['proof']),statement_sha256=m['original_statement_sha256'],selected_sha256=m['selected_sha256'],
        proof_ref=proof_ref,native_ref=native_ref,
        native_to_slot=m['native_to_slot'],slot_to_native=m['slot_to_native'],reference_mapping=m['reference_mapping'],
        proof_dag=m['proof_dag'],selected_rows=[byid[c] for c in m['selected']],
        native_status=b['status'],aliases=aliases,scope=m['scope'],refs=refs,
        formula_lookup={str(x['formula_id']):catalogue['formulas'][x['formula_id']-1]
                        for x in m['slots'] if x['formula_id']>0})


def positive_engine(refs,selected):
    raw=checked(refs['raw']);CACHE.pop(refs['raw']['path'],None);c=checked(refs['semantic'])
    need(raw['status']=='SAT' and c['status']=='VERIFIED' and c['run_status']=='SAT'
        and c['claim']=='SEMANTIC_COMPLETE_SAT_CERTIFICATE' and c['event_coverage']=='COMPLETE'
        and c['bounded_absence'] is False,'ONLY_ACTUAL_SEMANTIC_POSITIVES')
    same(c['model_sha256'],raw['model_sha256'],'POSITIVE_ENGINE_MODEL_BINDING')
    same(c['event_sha256'],raw['event_extent']['sha256'],'POSITIVE_ENGINE_EVENT_BINDING')
    same(selected,raw['selected'],'ACTUAL_SELECTED_NATIVE_PROOF')
    return dict(raw_status=raw['status'],semantic_status=c['status'],claim=c['claim'],
                model_sha256=c['model_sha256'],event_sha256=c['event_sha256'])


def add_proof(proofs,identifier,role,label,refs,prepared,model,aliases,engine_refs=None):
    m=checked(refs.get('adapter_decoded',refs.get('decoded')))
    n=checked(refs['independent_decoded']);b=checked(refs.get('native_receipt',refs.get('native')))
    kind='QUALIFICATION' if role.startswith('QUALIFICATION') else 'ARITHMETIC'
    p=proof_record(identifier,kind,label,m,n,b,model,refs,prepared['catalogue'],aliases)
    p['role']=role
    if engine_refs is not None:
        p['engine_assurance']=positive_engine(engine_refs,m['selected']);p['engine_refs']=engine_refs
    else:p['engine_assurance']=dict(scope='Specialized planner candidate, exact point M/N decoding and whole native B; no GCTS trace claim.')
    if 'native_proof' in refs:same(checked(refs['native_proof']),m['proof'],'EXACT_SAVED_NATIVE_PROOF')
    proofs.append(p);return p


def rank_view(packet,receipt,refs,activated,prepared):
    view=dict(status=packet['status'],activated=activated,activation_admitted=activated,receipt=receipt,refs=refs,
        costs=packet.get('costs'),ranks=[],by_kind_slot=[],examples=[],forbidden_count=None)
    if packet['status']!='CANDIDATE':return view
    table={fid:h for fid,h in packet['ranks']};counts={};examples=[]
    for cid,demands in packet['reasons']:
        token=json.loads(cid);slot,kind=token[:2];key=(slot,kind);counts[key]=counts.get(key,0)+1
        remote=any(x[1]!=slot for x in demands);own_fits=all(x[1]!=slot for x in demands)
        example=dict(cid=cid,owner_slot=slot,kind=kind,demands=demands,remote=remote,own_output_fits=own_fits)
        if len(examples)<10:examples.append(example)
        if remote and own_fits and not any(x['remote'] and x['own_output_fits'] for x in examples):examples.append(example)
    view.update(ranks=[[fid,h] for fid,h in packet['ranks']],forbidden_count=len(packet['forbidden']),
        formulas=prepared['catalogue']['formulas'],by_kind_slot=[dict(slot=k[0],kind=k[1],count=v) for k,v in sorted(counts.items())],
        examples=examples,bindings=packet['bindings'],unreachable_formulas=sum(x is None for x in table.values()))
    return view


def assemble():
    protocol,external=environment();phases=[];results={}
    for name in PHASES:
        record,value=phase(name,protocol);phases.append(record);results[name]=value
    admitted={x['name']:x['admitted'] for x in phases}
    declaration=read('input/arithmetic-declaration-v1.json')
    aliases={declaration['names'][k]:v for k,v in dict(S='S',add='add',x='x',zero='0').items()}
    qa={'qqualx':'x','qqualP':'P','qqualQ':'Q','rankx':'x','ranky':'y','rankP':'P','rankQ':'Q'}
    proofs=[];qualification=None;prepared=None;base=None;preparation=None;rank=None;lanes=[];baseline=None
    if admitted['qualify']:
        q=results['qualify'];original=checked(q['original_qualification'])
        for item in original['logical']:
            refs=item['refs'];p=checked(refs['prepared'])
            add_proof(proofs,'qual-'+item['id'],'QUALIFICATION','Fresh qualification · '+item['id'],refs,p,p['model'],qa,item['engine']['refs'])
        rank_cases=[]
        for item in q['rank_cases']:
            p=checked(item['refs']['prepared']);model=checked(item['refs']['base_model'])
            if item['native_status']=='VERIFIED_NATIVE_PROOF':
                add_proof(proofs,'qual-plan-'+item['id'],'QUALIFICATION_SPECIALIZED_CONTROL',
                    'Fresh planner qualification · '+item['id'],item['refs']['conventional_native'],p,model,qa)
            rank_cases.append(dict(id=item['id'],status=item['status'],original_rows=item['original_rows'],
                forbidden_count=item['forbidden_count'],oracle=item['oracle'],actual=item['actual'],controls=item['controls'],
                conventional_status=item['conventional_status'],native_status=item['native_status'],native_lines=item['native_lines']))
        qualification=dict(original_counts=q['original_counts'],rank_cases=rank_cases,
            rank_actual_snapshots=q['rank_actual_snapshots'],total_rank_engine_calls=q['total_rank_engine_calls'],
            total_rank_oracle_calls=q['total_rank_oracle_calls'],scope=q['scope'])
    if admitted['prepare']:
        p=results['prepare'];prepared=checked(p['refs']['prepared']);base=checked(p['refs']['model'])
        same(p['prepared_binding'],prepared['binding'],'CURRENT_COMPLETE_PREPARATION_BINDING')
        same(sha(base),p['scope_sha256'],'CURRENT_PREPARED_MODEL_SCOPE')
        same(prepared['statement'],declaration['problem'],'CURRENT_ORIGINAL_STATEMENT')
        preparation=dict(census=p['census'],ZERO_checks=p['ZERO_checks'],slots=p['slots'],costs=p['costs'],refs=p['refs'])
    r=results['rank']
    if r is not None and 'analysis' in r.get('refs',{}):
        packet=checked(r['refs']['analysis']);receipt=checked(r['refs']['rank_receipt']) if 'rank_receipt' in r['refs'] else None
        rank=rank_view(packet,receipt,r['refs'],admitted['rank'],prepared)
        rank.update(phase_status=r['status'],stopped_stage=r.get('stopped_stage'),reason=r.get('reason'),phase_costs=r.get('costs'))
        if 'activation_controls' in r['refs']:
            controls=checked(r['refs']['activation_controls']);refs_in(controls);rank['controls']=[]
            for c in controls:
                v=checked(c['receipt']);same(v['status'],c['status'],'ACTUAL_RANK_CONTROL_RETURN')
                rank['controls'].append(dict(c,reason=v.get('reason'),work=v.get('work')))
        else:rank['controls']=[]
        if admitted['rank']:
            need(r['activation_admitted'] is True and receipt['status']=='VERIFIED_REDUNDANT_RANK_CONSTRAINT'
                and receipt['bounded_absence'] is False and receipt['learned'] is False,'ADMITTED_REDUNDANT_RANK_ONLY')
            same(receipt['bindings'],packet['bindings'],'EXACT_ADMITTED_ANALYSIS')
            models={k:checked(r['refs'][k+'_model']) for k in ('base','marked','control')}
            hashes={k:sha(v) for k,v in models.items()}
            same(hashes,r['model_bindings'],'ACTUAL_ADMITTED_MODEL_FILES');same(hashes,receipt['model_bindings'],'CHECKED_MODEL_FILES')
    if admitted['evaluate']:
        need(admitted['rank'],'EVALUATION_REQUIRES_RANK_ADMISSION');e=results['evaluate']
        same([x['lane'] for x in e['lanes']],['BASE','RANK_MARKS','RANK_FILTER'],'EXACT_FRESH_POINT_LANE_ORDER')
        for item in e['lanes']:
            row=engine_summary(item['refs']);row.update(lane=item['lane'],admitted_status=item['admitted_status'],
                native_status=item['native_status'],costs=item['costs']);lanes.append(row)
            if item['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
                p=add_proof(proofs,'arith-'+item['lane'],'POINT_SEARCH','GCTS point search · '+item['lane'],
                    item['native_refs'],prepared,checked(item['refs']['model']),aliases,item['refs'])
                same(p['statement'],declaration['problem'],'UNCHANGED_POINT_TARGET')
    if admitted['baseline']:
        b=results['baseline'];search=checked(b['refs']['search'])
        same(search['status'],b['search_status'],'ACTUAL_SPECIALIZED_PLANNER_RETURN')
        baseline=dict(search_status=b['search_status'],admitted_status=b['admitted_status'],native_status=b['native_status'],
            bounded_absence=b['bounded_absence'],rank_information=b['rank_information'],rank_custody=b['rank_custody'],
            costs=b['costs'],search_costs=search.get('costs'),reason=search.get('reason'),refs=b['refs'],scope=b['scope'])
        need(b['bounded_absence'] is False,'PLANNER_NEVER_CERTIFIES_ABSENCE')
        if b['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
            p=add_proof(proofs,'conventional-target','SPECIALIZED_CONTROL','Conventional goal-directed planner',
                b['native_refs'],prepared,base,aliases)
            same(p['statement'],declaration['problem'],'UNCHANGED_CONVENTIONAL_TARGET')
            same([x['id'] for x in p['selected_rows']],search['selected'],'ACTUAL_PLANNER_SELECTION')
    ap='review/passive-ranked-outcomes-v1.json';audit=read(ap)
    need(audit['schema']=='Ranked-arithmetic-passive-audit-v1'
        and audit['status']=='PASS_SAVED_RANKED_OUTCOMES_WITH_EXPLICIT_SCOPES','INDEPENDENT_SAVED_DATA_AUDIT')
    same(audit['protocol'],pin(PROTOCOL),'AUDITED_CURRENT_PROTOCOL')
    pa={x['name']:x for x in audit['phases']};same(sorted(pa),sorted(PHASES),'AUDITED_ALL_PHASES')
    for p in phases:
        for k in ('pid','native_exit_code','scientific_status','process_clean'):same(p[k],pa[p['name']][k],'AUDITED_PHASE:'+k)
        same(p['admitted'],pa[p['name']]['scientific_admitted'],'AUDITED_SCIENCE_ADMISSION')
    native={x['id']:x for x in audit['native_proofs']};need(len(native)==len(audit['native_proofs']),'DISTINCT_AUDITED_PROOFS')
    for p in proofs:
        need(p['audit_id'] in native,'PROOF_INCLUDED_IN_INDEPENDENT_AUDIT');n=native[p['audit_id']]
        for k in ('role','statement_sha256','selected_sha256'):same(p[k],n[k],'AUDITED_NATIVE_METADATA:'+k)
        same(p['line_count'],n['lines'],'AUDITED_NATIVE_LINE_COUNT');same(sha(p['proof']),n['proof_sha256'],'AUDITED_FULL_NATIVE_PROOF')
        for k in ('proof_ref','native_ref'):
            same({a:p[k].get(a) for a in ('path','bytes','sha256','pointer')},
                 {a:n[k].get(a) for a in ('path','bytes','sha256','pointer')},'AUDITED_NATIVE_REF:'+k)
    return dict(schema='Ranked-arithmetic-reader-data-v1',status='PASS_PASSIVE_SAVED_DATA_PROJECTION',run_root=ROOT.name,
        declaration=declaration,aliases=aliases,phases=phases,preparation=preparation,rank=rank,lanes=lanes,baseline=baseline,
        qualification=qualification,proofs=proofs,protocol=pin(PROTOCOL),saved_data_audit=pin(ap),
        saved_data_audits=[dict(status=audit['status'],ref=pin(ap))],
        provenance=dict(external=external,artifact_pins=list(LEDGER.values())),
        scope='Fresh cold full RF/eight-slot point-proof study. Rank constraints analytically preserve all original complete solutions; they are not learned markings, growth generations or minimum DAG lengths. Specialized conventional control is separate. No supplied target derivation, RL, full PA/induction, uniform Wang proof search or superiority assumption.')


def write(name,raw):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as f:f.write(raw)
    return dict(path=p.relative_to(ROOT).as_posix(),**bytepin(p))


def build():
    d=assemble();data=write('ranked-arithmetic-data-v1.json.gz',gzip.compress(wire(d),mtime=0))
    main=write('ranked-arithmetic-v1.html',PAGE.encode('utf-8'))
    result=dict(schema='Ranked-arithmetic-passive-build-v1',status='PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD',
        outputs=dict(main=main,data=data),renderer_source=dict(path=Path(__file__).relative_to(ROOT).as_posix(),**bytepin(Path(__file__))),
        protocol=d['protocol'],phases=d['phases'],artifact_pins=list(LEDGER.values()),
        scope='Saved-data/byte/projection only; no scientific helper imports, model construction, search, oracle, kernel or graph replay.')
    return write('build-receipt-v1.json',wire(result))


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ranked arithmetic proof search</title><style>
:root{--ink:#18343b;--muted:#5d7179;--line:#dbe3df;--green:#167c70;--purple:#8059ad;--orange:#ba7730;--red:#bc4e48}*{box-sizing:border-box}body{margin:0;background:#f4f6f2;color:var(--ink);font:16px/1.6 system-ui,-apple-system,sans-serif}main{max-width:1190px;margin:auto;padding:35px 24px 70px}nav{display:flex;gap:18px;flex-wrap:wrap;font-size:13px}a{color:var(--green)}h1{font-size:clamp(35px,5.7vw,66px);line-height:1.07;letter-spacing:-.045em;margin:35px 0 20px}h2{font-size:26px;letter-spacing:-.025em;margin:0 0 12px}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:var(--green)}.lede{font-size:19px;color:var(--muted);max-width:930px}section{margin:30px 0}.panel{background:#fff;border:1px solid var(--line);padding:23px;border-radius:15px;min-width:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.muted,small{color:var(--muted)}.note{border-left:4px solid var(--green);padding:12px 15px;background:#edf6f1;border-radius:0 8px 8px 0}.warning{border-color:var(--orange);background:#fff8ec}.tag{display:inline-block;background:#edf2ee;padding:3px 7px;border-radius:6px;font-size:11px;margin:2px;overflow-wrap:anywhere}.good{color:#28724e}.bad{color:var(--red)}.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:13px 0}select,button{font:inherit;font-size:13px;padding:8px 11px;border:1px solid #c5d4cc;border-radius:8px;background:white;max-width:100%}.scroll,.math{max-width:100%;overflow:auto}.math{display:block;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px 8px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line);overflow-wrap:anywhere}th{font-size:11px;color:var(--muted);white-space:nowrap}.proof{table-layout:fixed}.proof th:nth-child(1){width:5%}.proof th:nth-child(2){width:43%}.proof th:nth-child(3){width:31%}.proof th:nth-child(4){width:21%}.active{background:#eef6ef}code,pre{font:12px/1.5 ui-monospace,monospace}pre{background:#eff3ef;border-radius:8px;padding:13px;max-width:100%;overflow:auto}details{margin:12px 0}summary{font-size:13px;color:var(--muted);cursor:pointer}.cards{display:flex;gap:10px;flex-wrap:wrap}.tile code{overflow-wrap:anywhere;white-space:normal}.tile{flex:1;min-width:135px;border:2px solid var(--green);border-radius:2px;padding:12px;background:#fafdf8}.stripe{height:13px;border-radius:2px;margin:7px 0}.port{background:var(--purple)}.guard0{background:#3e72b5}.guard1{background:#c85845}.proposed{border-style:dashed;background:repeating-linear-gradient(135deg,#fff,#fff 8px,#f1eee8 8px,#f1eee8 16px)}.absent{background:repeating-linear-gradient(135deg,#fff,#fff 4px,#dfe6e0 4px,#dfe6e0 8px)}.diagram{overflow:auto;border:1px solid var(--line);background:#fafdf8;border-radius:12px}.diagram svg{display:block;width:100%;height:auto;min-width:560px}#fatal{white-space:pre-wrap;color:var(--red)}mjx-container{max-width:100%}mjx-container[display=true]{overflow:auto}@media(max-width:800px){main{padding:24px 13px}.panel{padding:17px}.grid{grid-template-columns:1fr}.proof{min-width:680px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="streamed-arithmetic-v1.html">Previous streamed attempt</a><a href="#results">Results</a><a href="#rank">Rank markings</a><a href="#reader">Proof reader</a><a href="#assessment">Assessment</a></nav>
<p class="eyebrow">GCTS research · fresh cold finite proof search</p><h1>Can rank markings<br>help proof search?</h1><p class="lede">The full logical grammar stays fixed. A certified lower bound on derivation height rules out impossible early formula requests, encoded either as literal point markings or the same ordinary unary filter. A conventional goal-directed planner is a separate control.</p><div id="fatal"></div><div id="outcome" class="note"></div>
<section class="panel"><h2>The original arithmetic statement</h2><div id="target"></div><div id="preparation"></div><p class="muted">One seen addition-zero/equality-congruence corollary, with a declared finite formula universe and slot bound. No target derivation is an input; this is not full PA or induction, a uniform Wang palette, geometric transfer or RL.</p></section>
<section id="results" class="panel"><h2>Actual search results</h2><div id="results-table" class="scroll"></div><p class="muted">Point-search SAT requires independent C admission, both native decoders and whole B validation. The conventional planner has its own checked candidate route and never certifies absence on failure. Workflow completion is not proof success.</p><details><summary>Actual process and scientific phase statuses</summary><div id="phase-table" class="scroll"></div></details></section>
<section id="rank" class="panel"><h2>The rank constraint and its literal marking</h2><div id="rank-status"></div><p>The rank takes the minimum over all producers, with \(h_{\mathrm{ZERO}}=1\), \(h_{\mathrm{GEN}}=1+h_{\mathrm{source}}\), and \(h_{\mathrm{MP}}=1+\max(h_{\mathrm{antecedent}},h_{\mathrm{implication}})\).</p><p>For an active formula at zero-based slot \(k\), every complete original certificate satisfies \(h(F)\leq k+1\). This covers unused facts as well as the final goal. PAD has formula zero and is preserved. A row is rejected if any positive own or remote formula request violates this bound.</p><p class="note warning">Minimum derivation height is not minimum shared-DAG line count, not a sufficient proof-existence test, and not the engine's growth generation. The reference global-dead, global-forced, earliest-generation scheduler is unchanged.</p>
<div class="grid"><div><h3>Actual formula ranks</h3><select id="rank-select"></select><div id="rank-formula"></div></div><div><h3>Forbidden rows by owner slot and kind</h3><div id="rank-counts" class="scroll"></div></div></div>
<h3>Actual forbidden-port example</h3><select id="example-select"></select><div id="rank-example"></div><div id="guard-cards" class="cards"></div><p class="muted">The guard is the prospectively prescribed fresh mark-only site <code>certified:rank:guard:v1</code>. Assigned zero is a literal value; absence is unconstrained. Full original CIDs and positive/mandatory marking data remain in the inventory. This is analytically proved pruning, not learned markings.</p><details><summary>Actual activation controls and rank metadata</summary><div id="controls" class="scroll"></div><pre id="rank-json"></pre></details></section>
<section id="reader" class="panel"><p class="eyebrow">Actual whole native-checked certificates</p><h2>Read the proof line by line</h2><div class="controls"><select id="proof-select"></select><label><input id="literal" type="checkbox"> Literal symbol names</label></div><div id="proof-scope"></div><div id="proof-goal"></div><div id="slots" class="diagram"></div><div id="proof-table" class="scroll"></div><details><summary>Unchanged proof AST and exact slot/reference maps</summary><pre id="proof-json"></pre></details><p class="muted">Cards are anchored symbolic point-slot owners, not a fixed square Wang palette. Orange denotes activity, purple formula-ID markings and arrows actual earlier-slot receptors. Their logical assertions are the formulas in the table. Native source and display-only aliases remain inspectable.</p></section>
<section id="assessment" class="grid"><div class="panel"><h2>What the evidence supports</h2><div id="assessment-data"></div><p>Literal markings and the ordinary filter encode the same certified exclusions. A proof found by the conventional control is attributed to that control. One execution per method and a change in branches do not establish a distinct GCTS or speed advantage.</p><p>Any complete exhaustion is finite and grammar/slot scoped, not mathematical negation or unrestricted nonprovability. UNKNOWN remains unresolved.</p></div><div class="panel"><h2>Complete costs and limits</h2><div id="costs"></div><p class="muted">Cold compilation, native ZERO/profile/model gates, rank construction, independent admission, mutation controls, search and native assurance all count. Worker/helper/observer intervals overlap. Specialized planner states and engine work units are not interchangeable. Native worker high-water RSS is separate from possibly missed polling samples.</p></div></section>
<section class="panel"><h2>Fresh qualification</h2><div id="qualification"></div><details><summary>All tiny cover-set and graph checks</summary><div id="qual-table" class="scroll"></div></details><p class="muted">Qualification proofs are labeled separately from target proofs. The literal nested-GEN fixture has a declared generic catalogue/model and native ZERO gate; it is not presented as a full RF profile. Large arithmetic runs have semantic event/endpoints assurance, not observations of every intermediate producer map.</p></section>
<!-- RANKED_ARITHMETIC_ARCHIVE_LINK -->
<section id="evidence" class="panel"><h2>Exact evidence</h2><p><a href="ranked-arithmetic-data-v1.json.gz">Reader data</a>. Full original Sources, raw records, refusals, proofs and logs are retained in the approved physical archive.</p><details><summary>Protocol, process records and byte pins</summary><pre id="provenance"></pre></details></section>
</main><script>'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+x+'\\)</span>';let D,P,A={},literal=false,selectedLine=null,mathQueue=Promise.resolve();const num=x=>x==null?'not recorded':Number(x).toLocaleString(undefined,{maximumFractionDigits:4});
function typeset(el){mathQueue=mathQueue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math error: '+e.message;});}
async function load(){const r=await fetch('ranked-arithmetic-data-v1.json.gz');if(!r.ok)throw Error('Data HTTP '+r.status);const b=new Uint8Array(await r.arrayBuffer());if(b[0]===31&&b[1]===139)return JSON.parse(await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).text());return JSON.parse(new TextDecoder().decode(b));}
function symbol(x){return literal?x:(A[x]??x);}function term(a){if(a[0]==='var')return tex(symbol(a[1]));const name=symbol(a[1]);if(!a[2].length)return name==='0'?'0':'\\operatorname{'+tex(name)+'}';return (name==='S'?'S':'\\operatorname{'+tex(name)+'}')+'('+a[2].map(term).join(',')+')';}
function formula(a){switch(a[0]){case'pred':return '\\operatorname{'+tex(symbol(a[1]))+'}'+(a[2].length?'('+a[2].map(term).join(',')+')':'');case'eq':return term(a[1])+'='+term(a[2]);case'imp':return '('+formula(a[1])+'\\Rightarrow '+formula(a[2])+')';case'and':case'or':return '('+formula(a[1])+(a[0]==='and'?'\\land ':'\\lor ')+formula(a[2])+')';case'not':return '\\neg '+formula(a[1]);case'all':return '\\forall '+tex(symbol(a[1]))+'\\,('+formula(a[2])+')';case'bot':return '\\bot';default:return '\\text{'+tex(JSON.stringify(a))+'}';}}
function reason(line){const n=x=>Number(x)+1;switch(line.rule){case'axiom':return 'Use the named hypothesis '+line.name+'.';case'refl':return 'A term equals itself.';case'instantiate':return 'Use universal instantiation at the recorded term; the displayed implication is the native schema.';case'eq_subst':return 'Use equality substitution in the recorded formula context.';case'distribute':return 'Use the quantified distribution schema with its checked side conditions.';case'tautology':return 'Use a propositional tautology.';case'mp':return 'From line '+n(line.antecedent)+' and its implication on line '+n(line.implication)+', infer the consequent.';case'generalize':return 'Generalize line '+n(line.source)+' over '+symbol(line.variable)+' under the closed hypothesis context.';default:return line.rule;}}
function refs(line){return line.rule==='mp'?[line.antecedent,line.implication]:line.rule==='generalize'?[line.source]:[];}
function slotDiagram(){if(!P)return '';const ss=P.slots,w=Math.max(600,ss.length*112),h=205,row=new Map(P.selected_rows.map(r=>[r.id,r]));let s='<svg viewBox="0 0 '+w+' '+h+'" role="img" aria-label="Actual selected slot owners and remote marking receptors"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#ad9cc5"/></marker></defs>';for(const x of ss){const token=JSON.parse(x.cid);for(const earlier of token[3]){const x1=55+x.slot*112,x2=55+earlier*112;s+='<path d="M'+x1+',105 Q'+((x1+x2)/2)+','+(15+Math.abs(x1-x2)%50)+' '+x2+',105" fill="none" stroke="#b8a5d0" stroke-width="1.5" marker-end="url(#arrow)"/>';}}for(const x of ss){const xx=9+x.slot*112,selected=selectedLine!==null&&x.native_line_index_or_null===selectedLine,m=row.get(x.cid),extra=m.m.find(([p,v])=>p==='certified:rank:guard:v1');s+='<g data-slot="'+x.slot+'"><rect x="'+xx+'" y="105" width="94" height="89" rx="2" fill="'+(selected?'#e9f5ec':'#fafff7')+'" stroke="'+(selected?'#167c70':'#93afa0')+'" stroke-width="2"/><text x="'+(xx+8)+'" y="122" font-size="12">slot '+x.slot+' · '+JSON.parse(x.cid)[1]+'</text><rect x="'+(xx+8)+'" y="131" width="78" height="10" fill="'+(x.active?'#c18943':'#dde2d9')+'"/><rect x="'+(xx+8)+'" y="147" width="78" height="10" fill="#b39acb"/><text x="'+(xx+8)+'" y="174" font-size="10">active '+x.active+'; FID '+x.formula_id+'</text><rect x="'+(xx+8)+'" y="181" width="78" height="5" fill="'+(extra?(extra[1]==='0'?'#3e72b5':'#c85845'):'#e8ece5')+'"/></g>';}return s+'</svg>';}
function renderProof(){const id=$('proof-select').value;P=D.proofs.find(p=>p.id===id);selectedLine=null;if(!P){$('proof-scope').innerHTML='<p class="note warning">No native-admitted proof is attached to this selected record. Fresh qualifiers and the conventional control are separate choices.</p>';$('proof-goal').innerHTML='';$('proof-table').innerHTML='';$('slots').innerHTML='';$('proof-json').textContent='';return;}A=P.aliases;literal=$('literal').checked;$('proof-scope').innerHTML='<p class="note '+(P.kind==='QUALIFICATION'?'warning':'')+'"><b>'+esc(P.kind==='QUALIFICATION'?'Fresh qualification only — not the arithmetic target':P.role==='SPECIALIZED_CONTROL'?'Conventional planner proof — not GCTS search':'Actual GCTS point-search proof')+'</b> · '+esc(P.label)+' · '+P.proof.length+' native-checked lines, '+P.slots.length+' slots.</p>';$('proof-goal').innerHTML=math(formula(P.statement.goal))+'<details><summary>Exact hypothesis context and display symbol map</summary><pre>'+esc(JSON.stringify({theory:P.statement.theory,display_aliases:P.aliases},null,2))+'</pre></details>';$('proof-table').innerHTML='<table class="proof"><thead><tr><th>Line</th><th>Decoded assertion</th><th>English meaning</th><th>Rule / references</th></tr></thead><tbody>'+P.proof.map((l,i)=>'<tr id="line-'+i+'"><td><button data-line="'+i+'">'+(i+1)+'</button></td><td>'+math(formula(l.formula))+'</td><td>'+esc(reason(l))+'</td><td><code>'+esc(l.rule)+'</code><br>'+refs(l).map(x=>'line '+(x+1)).join(', ')+'<br>slot '+P.native_to_slot[i]+'</td></tr>').join('')+'</tbody></table>';$('slots').innerHTML=slotDiagram();const choose=i=>{selectedLine=i;for(const tr of $('proof-table').querySelectorAll('tbody tr'))tr.classList.toggle('active',tr.id==='line-'+i);$('slots').innerHTML=slotDiagram();bindSlots();};const bindSlots=()=>{for(const g of $('slots').querySelectorAll('[data-slot]'))g.onclick=()=>{const i=P.slots.find(x=>x.slot===+g.dataset.slot).native_line_index_or_null;choose(i);};};for(const b of $('proof-table').querySelectorAll('[data-line]'))b.onclick=()=>choose(+b.dataset.line);bindSlots();$('proof-json').textContent=JSON.stringify({proof:P.proof,slots:P.slots,reference_mapping:P.reference_mapping,proof_dag:P.proof_dag},null,2);typeset($('reader'));}

function phaseTable(rows){return '<table><thead><tr><th>Phase / PID</th><th>Scientific</th><th>Process / native exit</th><th>Worker / observed seconds</th></tr></thead><tbody>'+rows.map(x=>'<tr><td>'+esc(x.name)+' / '+esc(x.pid??'none')+'</td><td>'+esc(x.scientific_status??'not run')+'</td><td>'+esc(x.process_status)+' / '+esc(x.native_exit_code??'no worker')+'</td><td>'+num(x.worker_seconds)+' / '+num(x.observer_seconds)+'</td></tr>').join('')+'</tbody></table>';}
function renderRank(){
 const r=D.rank;if(!r){$('rank-status').innerHTML='<p class="muted">No rank output is available.</p>';$('rank-select').innerHTML='';$('rank-formula').innerHTML='';$('rank-counts').innerHTML='';$('example-select').innerHTML='';$('rank-example').innerHTML='';$('guard-cards').innerHTML='';return;}
 $('rank-status').innerHTML='<p class="note '+(r.activated?'':'warning')+'"><b>'+(r.activated?'Certified rank layer activated':'Rank candidate NOT ACTIVATED')+'</b> · phase '+esc(r.phase_status)+' · independent checker '+esc(r.receipt?.status??'not reached')+'. '+(r.forbidden_count==null?'':num(r.forbidden_count)+' forbidden CIDs; '+num(r.unreachable_formulas)+' unreachable formulas.')+'</p>';
 $('rank-select').innerHTML=r.ranks.map(([f,h])=>'<option value="'+f+'">FID '+f+' · '+(h===null?'unreachable':'height '+h)+'</option>').join('');
 const showRank=()=>{if(!r.ranks.length){$('rank-formula').innerHTML='<p>No complete rank table.</p>';return;}const id=+$('rank-select').value,h=r.ranks.find(x=>x[0]===id)[1],saved=A;A=D.aliases;$('rank-formula').innerHTML=math(formula(r.formulas[id-1]))+math('h(F)='+(h===null?'\\infty':h));A=saved;typeset($('rank-formula'));};
 $('rank-select').onchange=showRank;showRank();
 $('rank-counts').innerHTML=r.by_kind_slot.length?'<table><thead><tr><th>Owner slot</th><th>Kind</th><th>Forbidden CIDs</th></tr></thead><tbody>'+r.by_kind_slot.map(x=>'<tr><td>'+x.slot+'</td><td>'+esc(x.kind)+'</td><td>'+num(x.count)+'</td></tr>').join('')+'</tbody></table>':'<p>No complete forbidden census.</p>';
 $('example-select').innerHTML=r.examples.map((x,i)=>'<option value="'+i+'">slot '+x.owner_slot+' '+x.kind+(x.remote?' · remote demand':'')+(x.own_output_fits?' · own output fits':'')+'</option>').join('');
 const showExample=()=>{const x=r.examples[+$('example-select').value];if(!x){$('rank-example').innerHTML='<p>No forbidden example is available.</p>';}else{$('rank-example').innerHTML='<pre>'+esc(x.cid)+'</pre><table><thead><tr><th>Requested FID</th><th>Port slot</th><th>Actual rank</th><th>Allowed prefix height</th></tr></thead><tbody>'+x.demands.map(([f,k,h])=>'<tr><td>'+f+'</td><td><code>f:'+k+'</code></td><td>'+math(h===null?'\\infty':String(h))+'</td><td>'+math(String(k+1))+'</td></tr>').join('')+'</tbody></table>';typeset($('rank-example'));}
 $('guard-cards').innerHTML='<div class="tile">Seed at fresh guard<div class="stripe guard0"></div>literal <code>"0"</code></div><div class="tile '+(r.activated?'':'proposed')+'">'+(r.activated?'Certified forbidden row':'PROPOSED forbidden row')+'<div class="stripe guard1"></div>literal <code>"1"</code></div><div class="tile">Every other row<div class="stripe absent"></div>additional component absent</div>';};
 $('example-select').onchange=showExample;showExample();
 $('controls').innerHTML=r.controls?.length?'<table><thead><tr><th>Actual control</th><th>Status</th><th>Required</th><th>Reason</th></tr></thead><tbody>'+r.controls.map(x=>'<tr><td>'+esc(x.id)+'</td><td>'+esc(x.status)+'</td><td>'+esc(x.expected)+'</td><td><code>'+esc(x.reason??'not recorded')+'</code></td></tr>').join('')+'</tbody></table>':'<p>No completed controls.</p>';
 $('rank-json').textContent=JSON.stringify({status:r.status,activated:r.activated,receipt:r.receipt,bindings:r.bindings,costs:r.phase_costs,refs:r.refs},null,2);
}
function init(){
 const pt=D.proofs.filter(p=>p.role==='POINT_SEARCH'),cp=D.proofs.filter(p=>p.role==='SPECIALIZED_CONTROL');
 $('outcome').innerHTML='<b>'+pt.length+' GCTS point-search target certificate(s); '+cp.length+' specialized-control target certificate(s).</b> '+(pt.length||cp.length?'These concern the same seen statement, not separate new theorems.':'No target proof is admitted in this snapshot.')+' Qualification examples remain separate.';
 A=D.aliases;$('target').innerHTML='<p>Hypothesis '+math(formula(D.declaration.problem.theory.axioms[Object.keys(D.declaration.problem.theory.axioms)[0]]))+'</p><p>Goal '+math(formula(D.declaration.problem.goal))+'</p>';
 $('preparation').innerHTML=D.preparation?'<p>Fresh cold admission: '+D.preparation.census.formulas+' formulas, '+D.preparation.census.rows+' complete rows, '+D.preparation.slots+' slots and '+D.preparation.ZERO_checks+' native ZERO checks.</p>':'<p class="muted">No admitted complete target preparation.</p>';
 $('phase-table').innerHTML=phaseTable(D.phases);
 const rows=D.lanes.map(x=>'<tr><td>'+esc(x.lane)+' · GCTS</td><td>'+esc(x.raw_status)+' / '+esc(x.semantic_status)+'</td><td>'+esc(x.admitted_status)+'</td><td>'+num(x.stats.branches)+' / '+num(x.stats.backtracks)+'</td><td>'+num(x.stats.elapsed_seconds)+'</td><td><code>'+esc(x.reason)+'</code></td></tr>');
 if(D.baseline)rows.push('<tr><td>Conventional planner</td><td>'+esc(D.baseline.search_status)+'</td><td>'+esc(D.baseline.admitted_status)+'</td><td>separate search class</td><td>'+num(D.baseline.costs.search_seconds)+'</td><td><code>'+esc(D.baseline.reason??'candidate checked')+'</code></td></tr>');
 $('results-table').innerHTML=rows.length?'<table><thead><tr><th>Method</th><th>Raw / semantic</th><th>Native admission</th><th>Branches / backtracks</th><th>Inner search seconds</th><th>Actual reason</th></tr></thead><tbody>'+rows.join('')+'</tbody></table>':'<p class="muted">No admitted search phase yet. Missing outcomes are not zeros.</p>';
 const unresolved=D.lanes.filter(x=>x.admitted_status!=='VERIFIED_NATIVE_POSITIVE');
 $('proof-select').innerHTML=D.proofs.map(p=>'<option value="'+esc(p.id)+'">'+esc(p.label)+'</option>').join('')+unresolved.map(x=>'<option value="none-'+esc(x.lane)+'">'+esc(x.lane)+' · '+esc(x.raw_status)+' · no admitted proof</option>').join('');
 if(pt.length)$('proof-select').value=pt[0].id;else if(cp.length)$('proof-select').value=cp[0].id;else if(unresolved.length)$('proof-select').value='none-'+unresolved[0].lane;renderProof();$('proof-select').onchange=renderProof;$('literal').onchange=renderProof;renderRank();
 $('assessment-data').innerHTML='<p>'+esc(D.scope)+'</p><p>'+pt.length+' point-search and '+cp.length+' conventional target certificate records. '+(!pt.length&&cp.length?'The found target proof is attributable to the conventional planner, not GCTS. ':'')+(D.lanes.length&&D.lanes.every(x=>x.admitted_status==='UNKNOWN')?'All point lanes remain unresolved; complete retained event payloads may only certify a decision prefix. ':'')+'All-method comparison includes the cold preparation and assurance pipeline below.</p>';
 $('costs').innerHTML=D.phases.map(x=>'<p><b>'+x.name+'</b>: '+num(x.worker_seconds)+' s worker; '+num(x.observer_seconds)+' s observed; native high-water '+(x.worker_highwater_rss_bytes==null?'not recorded':num(x.worker_highwater_rss_bytes/1048576)+' MiB')+'.</p>').join('')+'<details><summary>Actual helper cost intervals</summary><pre>'+esc(JSON.stringify({prepare:D.preparation?.costs,rank:D.rank?.phase_costs,point_lanes:D.lanes.map(x=>({lane:x.lane,costs:x.costs})),conventional:D.baseline?.costs},null,2))+'</pre></details>';
 const q=D.qualification;
 $('qualification').innerHTML=q?'<p>Fresh original qualification: '+q.original_counts.tiny_cases+' tiny models and '+q.original_counts.logical_cases+' logical qualifiers. Additional rank cases: '+q.rank_cases.length+'; '+q.total_rank_engine_calls+' actual engine calls and '+q.total_rank_oracle_calls+' complete subset calls. Actual maps: '+(q.original_counts.actual_tiny_snapshots+q.original_counts.actual_logical_snapshots)+' original plus '+q.rank_actual_snapshots+' rank checks. Qualifier proofs are not target results.</p>':'<p class="muted">No admitted qualification.</p>';
 $('qual-table').innerHTML=q?'<table><thead><tr><th>Rank case</th><th>Full rows</th><th>Forbidden</th><th>Complete covers BASE / MARKS / FILTER</th><th>Planner / native</th></tr></thead><tbody>'+q.rank_cases.map(x=>'<tr><td>'+esc(x.id)+'</td><td>'+x.original_rows+'</td><td>'+x.forbidden_count+'</td><td>'+x.oracle.map(o=>o.solutions).join(' / ')+'</td><td>'+esc(x.conventional_status)+' / '+esc(x.native_status??'not applicable')+'</td></tr>').join('')+'</tbody></table>':'';
 $('provenance').textContent=JSON.stringify({protocol:D.protocol,phases:D.phases,audit:D.saved_data_audit,scope:D.scope,artifact_pins:D.provenance.artifact_pins},null,2);typeset(document.querySelector('main'));
}
load().then(x=>{D=x;init();}).catch(e=>{$('fatal').textContent='Actual saved data unavailable: '+e.message;});
</script></body></html>'''

if __name__=='__main__':print(json.dumps(build(),sort_keys=True))
