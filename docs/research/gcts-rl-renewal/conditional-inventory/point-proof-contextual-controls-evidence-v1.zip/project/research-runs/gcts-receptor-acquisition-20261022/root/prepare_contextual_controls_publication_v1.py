"""Administrative report and approved full evidence packaging, without replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
STAGE = ROOT / 'publication-contextual-controls-v1'
PAYLOAD = P2 / 'publication-payload-contextual-controls-v1'
PRIOR = ROOT / 'publication-stratified-acquisition-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html',
         'point-proof-contextual-controls-summary-v1.json',
         'point-proof-contextual-controls-evidence-v1.zip')


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def main():
    admission_path = ROOT / 'contextual-library-controls-v1-case-0-Root-complete-whole-admission-v1.json'
    admission = json.loads(raw(admission_path))
    assert admission['qualification_admitted'] is True
    assert admission['resources_and_custody_accepted'] is True
    case = STUDY / 'actual' / admission['case_id']
    plan_path = Path(admission['plan']['path'])
    plan = json.loads(raw(plan_path))
    for key in ('plan', 'result', 'bank', 'complete_C_review'):
        assert pin(Path(admission[key]['path'])) == admission[key]
    assert json.loads(raw(admission['complete_C_review']['path']))['review_passed'] is True
    authorization = ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'
    assert json.loads(raw(authorization))['direct_human_answer'] == 'Approve publishing the full archive'
    audit_path = ROOT / 'contextual-library-controls-complete-raw-Root-passive-audit-v1.json'
    audit = json.loads(raw(audit_path))
    observed_path = Path(admission['observed_coverage']['path'])
    assert pin(observed_path) == admission['observed_coverage']
    bank = json.loads(raw(case / 'contextual-bank.json'))
    assert bank['counts'] == dict(failed=0, groups=6, passed=6)
    members, external = {}, []

    def include(path, role, expected=None):
        path = Path(path)
        body = raw(path)
        ref = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {k: expected[k] for k in ('path', 'bytes', 'sha256')}
        try:
            name = 'project/' + path.relative_to(REPO).as_posix()
        except ValueError:
            assert ref == plan['python']
            external.append(dict(role=role, **ref, supplied_separately=True))
            return
        assert not any(p in ('.git', '.ssh', '.aws') for p in path.parts)
        if name in members:
            assert members[name]['ref'] == ref
        else:
            members[name] = dict(role=role, ref=ref, body=body)

    for row in plan['files']:
        include(row['path'], 'current-runtime-or-explicit-metadata-guard', row)
    for row in audit['all_files']:
        include(row['path'], 'complete-current-actual-or-observer-file', row)
    extras = [admission_path, Path(admission['complete_C_review']['path']), audit_path,
              observed_path, Path(json.loads(raw(observed_path))['complete_assessment']['path']),
              plan_path, authorization,
              ROOT / 'grants/contextual-library-controls-v1-case-0.json',
              ROOT / 'contextual-library-controls-v1-case-0-Root-once-acceptance-v1.json',
              ROOT / 'contextual-library-controls-study-preparation-v1.json',
              ROOT / 'contextual-controls-prospective-metadata-Root-passive-audit-v1.json',
              STUDY / 'review-C/typed-contextual-library-controls-complete-whole-prospective-review-v1.json',
              STUDY / 'implementation-B/receptor-family-and-instance-API-v2.json',
              STUDY / 'implementation-B/contextual-library-consumer-and-matched-baseline-DESIGN-v1.json',
              ROOT / 'admit_contextual_controls_v1.py',
              Path(__file__).resolve(), ROOT / 'publish_contextual_controls_api_v1.py',
              ROOT / 'verify_contextual_controls_live_v1.py']
    for relative in ('implementation-B/contextual-library-consumer-Source-handoff-v1.json',
                     'diagnostics-L/contextual-library-independent-bank-Source-handoff-v1.json',
                     'root/contextual-controls-worker-Source-handoff-v1.json'):
        packet_path = STUDY / relative
        extras.append(packet_path)
        packet = json.loads(raw(packet_path))
        def visit(v):
            if type(v) is dict:
                if {'path', 'bytes', 'sha256'} <= set(v) and Path(v['path']).is_absolute():
                    include(v['path'], 'explicit-current-Source-handoff-component', v)
                else:
                    for value in v.values():
                        visit(value)
            elif type(v) is list:
                for value in v:
                    visit(value)
        visit(packet)
    prior_zip = PRIOR / 'point-proof-stratified-acquisition-evidence-v1.zip'
    extras.append(prior_zip)
    for p in extras:
        include(p, 'explicit-current-review-or-provenance-or-prior-archive')
    catalog = dict(schema='Root-contextual-controls-full-evidence-catalog-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(), case_id=case.name,
        Root_admission=pin(admission_path), direct_user_archive_authorization=pin(authorization),
        members=[dict(member=n, role=v['role'], **v['ref']) for n,v in sorted(members.items())],
        external_runtime=external, prior_archive=pin(prior_zip), scientific_replay=False,
        scope='All forty current explicit guards except separately supplied Python; every complete actual/observer file; explicit complete Source packets, reviews, admission and unchanged prior full archive. Exact selected-case closure, not transitive closure of all historical citations. Two historical nonruntime design/API papers are included as provenance; neither was one of the forty runtime guards. Future evaluation Sources and unexecuted target plans are excluded.')
    STAGE.mkdir()
    PAYLOAD.mkdir()
    archive_path = STAGE / NAMES[2]
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for n, body in [('catalog.json', js(catalog))] + [(n,v['body']) for n,v in sorted(members.items())]:
            info = zipfile.ZipInfo(n, (2026,10,25,0,0,0))
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(archive_path) as bundle:
        assert set(bundle.namelist()) == set(members) | {'catalog.json'}
        assert len(bundle.namelist()) == len(members)+1
        for n, v in members.items():
            assert bundle.read(n) == v['body']
    cases = bank['controls'][0]['observations']['cases']
    summary = dict(schema='public-contextual-controls-summary-v1',
        status='FINITE_SYNTHETIC_QUALIFICATION_ADMITTED',
        scope='Authored infrastructure tests; no newly discovered theorem, learned inventory transfer, GCTS or RL advantage.',
        groups=bank['counts'], normal_searches=20, paired_cases=10,
        normal_candidate_results=14, normal_unknown_results=6,
        original_compiler_component_cases=8, original_fallback_case=1,
        candidate_dual_check_pairs=23, selected_fault_probes=7, detached_map_tamper_probes=8,
        selected_closed_applications=4, selected_open_applications=0,
        selected_hierarchy=0, selected_consumer_CD_contexts=0, selected_consumer_quotient_contractions=0,
        cases=[dict(name=c['name'], observed_use=c['observed_use'],
                    statuses=[x['status'] for x in c['complete_results']]) for c in cases],
        coverage_limits=bank['coverage_limits'],
        metrics={k:audit[k] for k in ('observer_seconds','final_observer_gate_seconds',
                 'whole_peak_bytes','positive_body_bytes','all_actual_and_observer_bytes')},
        scientific_admission=pin(admission_path), complete_C_review=admission['complete_C_review'],
        holdout_loaded=False, holdout_searched=False, production_inventory_loaded=False,
        next_test=dict(arms=['NO_LIBRARY','CONDITIONAL_LEMMA_CD','RECEPTOR_DAG'],
                       status='Prospectively specified; not executed in this milestone.'),
        evidence_archive=dict(name=NAMES[2], **{k:pin(archive_path)[k] for k in ('bytes','sha256')}, entries=len(members)+1))
    section = r'''<style>.coverage-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}.coverage-cell{padding:18px;border:1px solid var(--rule);border-radius:10px;background:#edf6f2}.coverage-cell.pending{background:#f4f0e8;border-style:dashed}.coverage-cell b{display:block}.coverage-cell span{display:block;font-size:14px;margin-top:7px;color:var(--muted)}.attachment-diagram{width:100%;height:auto;margin:18px 0}.controls-lead{border-top:6px solid var(--teal)}@media(max-width:700px){.coverage-grid{grid-template-columns:1fr}}</style>
<section class="panel controls-lead" id="contextual-controls-current"><p class="status">Current result · consumer qualification · 25 October 2026 UTC</p>
<h1>Closed lemma reuse works in the tests.<br>Open and nested reuse remain unexercised.</h1>
<p>The new contextual consumer passed the complete independent six-group test suite. It can offer parameterized proof families, demand proofs of their boundary premises, and preserve ordinary proof search as a fallback. Both comparison arms receive the same families, substitutions and search order. They differ in how a selected family is expanded: conditional lemmas with discharge, or direct attachment to a proof DAG.</p>
<div class="grid"><article class="card"><h3>Normal searches</h3><span class="fact">\(20\)</span><p>Ten paired cases: fourteen checked candidates and six normal unknown results.</p></article><article class="card"><h3>Selected closed uses</h3><span class="fact">\(4\)</span><p>One application per arm in two cases. The other successful cases used ordinary proof steps.</p></article><article class="card"><h3>Whole observer time</h3><span class="fact">\(18.792\,\mathrm{s}\)</span><p>Includes cold imports, tests, both validators, complete output, readback and custody.</p></article></div>
<div class="notice"><strong>These are authored tests of the machinery.</strong> They are not new theorem discoveries or a benchmark speedup. The learned seven-family inventory and frozen evaluation target were not loaded. No GCTS marking or trained RL policy directed this search.</div>
<h2>Where the evidence reaches</h2>
<div class="coverage-grid"><div class="coverage-cell"><b>Observed: closed-family attachment</b><span>Two cases selected a family in each arm. Every final candidate was checked by both original validators.</span></div><div class="coverage-cell pending"><b>Unexercised: open-boundary use</b><span>Boundary-demand offers were produced, but ordinary proof steps won the selected first solutions.</span></div><div class="coverage-cell pending"><b>Unexercised: nested family use</b><span>The recursive recipe produced offers; its final solution selected ordinary modus ponens. Offers alone do not establish hierarchy.</span></div><div class="coverage-cell"><b>Separate component checks</b><span>Eight original compiler cases checked ordered/shared ports, discharge and symbolic quotient maps. These do not establish use by the new consumer.</span></div></div>
<svg class="attachment-diagram" viewBox="0 0 1020 180" role="img" aria-labelledby="attachment-title attachment-desc"><title id="attachment-title">A family attaches only after its boundary demands have proofs</title><desc id="attachment-desc">Teal shows the observed closed application path. Dashed amber boxes show boundary and hierarchy paths not selected in this run.</desc><defs><marker id="controls-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#176f66"/></marker></defs><rect x="12" y="24" width="205" height="116" rx="9" fill="#edf6f2" stroke="#176f66" stroke-width="2"/><text x="114" y="66" text-anchor="middle" font-size="18" fill="#203239">Goal / obligation</text><text x="114" y="98" text-anchor="middle" font-size="14" fill="#576a70">match family output</text><path d="M218 82 H285" stroke="#176f66" stroke-width="3" marker-end="url(#controls-arrow)"/><rect x="290" y="24" width="205" height="116" rx="9" fill="#edf6f2" stroke="#176f66" stroke-width="2"/><text x="392" y="66" text-anchor="middle" font-size="18" fill="#203239">Selected family</text><text x="392" y="98" text-anchor="middle" font-size="14" fill="#576a70">closed use observed</text><path d="M496 82 H563" stroke="#176f66" stroke-width="3" marker-end="url(#controls-arrow)"/><rect x="568" y="24" width="205" height="116" rx="9" fill="#edf6f2" stroke="#176f66" stroke-width="2"/><text x="670" y="66" text-anchor="middle" font-size="18" fill="#203239">Primitive proof</text><text x="670" y="98" text-anchor="middle" font-size="14" fill="#576a70">both validators agree</text><rect x="804" y="24" width="204" height="116" rx="9" fill="#f4f0e8" stroke="#9a5617" stroke-width="2" stroke-dasharray="7 5"/><text x="906" y="59" text-anchor="middle" font-size="16" fill="#203239">Boundary proofs</text><text x="906" y="86" text-anchor="middle" font-size="16" fill="#203239">Nested families</text><text x="906" y="113" text-anchor="middle" font-size="13" fill="#9a5617">not selected in this run</text></svg>
<p class="caption">This is an evidence-coverage diagram. Its colors are reader annotations, not learned markings or a finite Wang palette. The consumer is an ordinary symbolic obligation-search adaptation; distinct geometric point-placement conformance is not claimed.</p>
<h2>What was checked</h2><p>The suite retained every normal query, certificate and validation return. There were \(23\) dual-check pairs across search candidates, compiler components and the original fallback case. Seven selected fault probes preserved the original first exception; eight detached-map mutations were refused by the independent association checker. The self-cycle and mutual-cycle cases returned unknown rather than proving themselves. No public consumer verifier was invented for these tests.</p>
<p>The complete bank and result used \(6761154\,\mathrm{bytes}\) of the shared \(50331648\,\mathrm{bytes}\) allowance. The conservative whole memory peak was \(280051712\,\mathrm{bytes}\). All eleven actual and observer files were retained. Qualification cost is separate from earlier proof acquisition and later evaluation; this timing is not a speed comparison.</p>
<h2>The next comparison is fixed in advance</h2><p>Use the existing frozen target first with no library, then with ordinary conditional-lemma reuse, then with direct DAG attachment. Give the two library arms the same seven acquired families and retain primitive fallback. Read the complete primitive proof and root-used application map before counting success. This will test ordinary lemma transfer and expansion cost. GCTS and RL still need separate matched experiments.</p>
<p>The target remains unopened and unsearched at this milestone. Open and nested use must be assessed from the actual selected proof, with the current coverage gap retained even if all test groups are green.</p>
<p><a href="point-proof-contextual-controls-summary-v1.json">Exact results and coverage by case</a> · <a href="point-proof-contextual-controls-evidence-v1.zip">Full approved evidence archive</a> · <a href="#stratified-acquisition-current">The seven acquired families, line by line</a> · <a href="point-proof-discovered-proofs-v1.html">Original training proofs</a></p>
<p class="caption">The archive includes current Source snapshots, complete certificates, execution logs, independent reviews and local provenance paths under direct user approval, plus the unchanged earlier full archive. The pinned external Python runtime is identified and supplied separately. Future evaluation Sources are excluded.</p></section>
<p class="notice"><strong>Earlier milestones below.</strong> Their current-status and unrun labels describe earlier checkpoints. The consumer qualification above is the current result.</p>'''
    page = raw(PRIOR / NAMES[0]).decode()
    assert page.count('<body><main>') == 1
    page = page.replace('<body><main>', '<body><main>' + section, 1)
    page = page.replace('<title>Acquired proof families: seven checked schemas</title>',
                        '<title>Proof-family search: closed reuse observed, open reuse unexercised</title>', 1)
    assert not any(ord(c)<32 and c not in '\n\t' for c in page)
    rows=[]
    for name,body in zip(NAMES, (page.encode(), js(summary), raw(archive_path))):
        if name != NAMES[2]:
            write(STAGE/name, body)
        write(PAYLOAD/name, body)
        rows.append(dict(path=PREFIX+name, root_source=str(STAGE/name),
            publisher_source=str(PAYLOAD/name), bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
            git_blob_sha1=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()))
    staging=dict(schema='Root-contextual-controls-three-path-staging-v1', scientific_execution=False,
        admission=pin(admission_path), baseline=pin(PRIOR/NAMES[0]),
        direct_user_archive_authorization=pin(authorization), files=rows,
        archive_entries=len(members)+1, archive_members_verified=True, external_runtime=external,
        scope='Exact report, public results summary and full approved task archive; isolated P2 only.')
    write(STAGE/'P2-staging.json', js(staging))
    print(json.dumps(pin(STAGE/'P2-staging.json')))


if __name__ == '__main__':
    main()
