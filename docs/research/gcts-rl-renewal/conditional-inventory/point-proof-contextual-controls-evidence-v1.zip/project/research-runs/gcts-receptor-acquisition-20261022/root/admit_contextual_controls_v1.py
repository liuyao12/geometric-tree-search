"""External metadata disposition of the complete once qualification; no replay."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent


def pin(path):
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def main():
    case_id = 'contextual-library-controls-v1-case-0'
    case = STUDY / 'actual' / case_id
    plan_path = ROOT / 'plans' / (case_id + '.json')
    plan = json.loads(plan_path.read_bytes())
    review_path = STUDY / 'review-C/typed-contextual-library-controls-complete-whole-actual-review-v1.json'
    review = json.loads(review_path.read_bytes())
    assert review['schema'] == 'C-contextual-library-controls-complete-whole-actual-review-v1'
    assert review['review_passed'] is True and review['blockers'] == []
    assert review['subjects']['plan'] == pin(plan_path)
    assert review['subjects']['result'] == pin(case / 'result.json')
    assert review['subjects']['bank'] == pin(case / 'contextual-bank.json')
    audit_path = ROOT / 'contextual-library-controls-complete-raw-Root-passive-audit-v1.json'
    audit = json.loads(audit_path.read_bytes())
    observed_path = STUDY / 'diagnostics-L/contextual-library-controls-observed-use-receipt-v1.json'
    observed = json.loads(observed_path.read_bytes())
    assert pin(Path(observed['complete_assessment']['path'])) == observed['complete_assessment']
    assert observed['selected_use']['closed_applications'] == 4
    assert observed['selected_use']['open_use'] == observed['selected_use']['hierarchy'] == 0
    for row in plan['files']:
        assert pin(Path(row['path'])) == row
    for row in audit['all_files']:
        assert pin(Path(row['path'])) == row
    result = json.loads((case / 'result.json').read_bytes())
    term = json.loads((case / 'terminal.json').read_bytes())
    obs = json.loads((Path(str(case)+'.observer') / 'observer.json').read_bytes())
    assert result['candidate_complete'] is True and result['first_Root_fault'] is False
    assert result['contextual6_qualification']['counts'] == dict(failed=0, groups=6, passed=6)
    assert result['accepted'] is False and result['qualification_admitted'] is False
    assert result['proof_admitted'] is False
    assert term['process_exit_code'] == 0 and term['reason'] is None and term['errors'] == []
    assert term['header_valid'] is True and term['final_custody_gate_passed'] is True
    assert obs['resource_candidate_accepted'] is True and obs['parent_exit_code'] == 0
    assert obs['errors'] == [] and obs['reason'] is None
    for record in (term, obs):
        for log in record['logs'].values():
            assert log['eof'] is True and log['overflow'] is False
    value = dict(schema='Root-contextual-library-controls-complete-whole-admission-v1',
        issued_utc=datetime.now(timezone.utc).isoformat(), case_id=case_id,
        status='COMPLETE_FINITE_SYNTHETIC_QUALIFICATION_ADMITTED',
        qualification_admitted=True, resources_and_custody_accepted=True,
        complete_C_review=pin(review_path), plan=pin(plan_path),
        result=pin(case/'result.json'), bank=pin(case/'contextual-bank.json'),
        module_pins=plan['module_pins'], passive_audit=pin(audit_path),
        observed_coverage=pin(observed_path),
        grant=pin(ROOT/'grants'/(case_id+'.json')),
        once_acceptance=pin(ROOT/(case_id+'-Root-once-acceptance-v1.json')),
        original_candidate_flags_unchanged=True,
        counts=observed['census'], selected_use=observed['selected_use'],
        metrics=dict(observer_elapsed_seconds=obs['elapsed_seconds'],
                     final_observer_gate_seconds=obs['final_observer_gate_seconds'],
                     conservative_whole_peak_bytes=obs['final_conservative_whole_peak_bytes'],
                     shared_positive_bytes=audit['positive_body_bytes'],
                     shared_cap_bytes=plan['limits']['result_bytes'],
                     complete_physical_bytes=audit['all_actual_and_observer_bytes']),
        coverage_limits=observed['not_established'],
        qualification_scope='Six authored synthetic groups only. Four selected closed applications; no selected open use, hierarchy, consumer CD temporary contexts or consumer quotient contraction. Eight original compiler cases are separate component evidence. Finite infrastructure admission does not establish production transfer or universal consumer correctness.',
        conformance='Ordinary monotone symbolic context-obligation adaptation. No distinct geometric point placements, complete point-incidence rollback or GCTS/RL conformance claim. Shared candidate domain/order and fallback semantics are Source-reviewed and observed-prefix tested.',
        holdout_loaded=False, holdout_searched=False, production_inventory_loaded=False,
        new_research_theorems=0, GCTS_RL_advantage=False,
        scientific_calls_or_replays_in_external_disposition=0,
        next_priority='Separately reviewed fixed no-library / conditional-lemma / direct-DAG comparison on the same untouched frozen target; no planted intermediates, target reselection or same-case retries.')
    out = ROOT / (case_id+'-Root-complete-whole-admission-v1.json')
    with out.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True, allow_nan=False)
        stream.write('\n')
    print(json.dumps(pin(out)))


if __name__ == '__main__':
    main()
