Retained quantified proof-search evidence.

The manifest joins each original absolute path to exact whole bytes in objects/SHA256. All six once-only runs and every native request are retained. Source-only and saved-data reviews have separate scopes.

Do not reuse any consumed actual directory. A follow-up execution requires new exact paths, frozen Sources, current independent reviews and fresh max-one Root grants. The original grants are already consumed.

The exact Python executable and Z3 package are external runtime inputs; their full maps and official acquisition identity are in the frozen runtime closure. Bundled standard library, platform and loader remain trusted runtime assumptions. This archive proves neither general first-order completeness nor a universal primitive Wang compilation.
