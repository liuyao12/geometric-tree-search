from pathlib import Path
import ast,json,hashlib,difflib,symtable,subprocess,sys,copy
B=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B')
def sh(b):return hashlib.sha256(b).hexdigest()
def jb(v):return (json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sh(b)}
def defs(t,s):
 lines=s.splitlines(keepends=True);out={}
 def scan(node,path):
  for n in ast.iter_child_nodes(node):
   if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):
    q='.'.join(path+[n.name]);a=min([n.lineno]+[d.lineno for d in n.decorator_list]);raw=''.join(lines[a-1:n.end_lineno]).encode();out[q]={'name':q,'kind':type(n).__name__,'line':a,'end_line':n.end_lineno,'raw_bytes':len(raw),'raw_sha256':sh(raw),'AST_sha256':sh(ast.dump(n,include_attributes=False).encode()),'positioned_AST_sha256':sh(ast.dump(n,include_attributes=True).encode()),'signature':ast.unparse(n.args)if hasattr(n,'args')else None,'full_callset':sorted({ast.unparse(x.func)for x in ast.walk(n)if isinstance(x,ast.Call)})};scan(n,path+[n.name])
   else:scan(n,path)
 scan(t,[]);return out

def scopes(st,path='module'):
 es=[]
 for name in sorted(st.get_identifiers()):
  s=st.lookup(name);es.append({'name':name,'parameter':s.is_parameter(),'referenced':s.is_referenced(),'assigned':s.is_assigned(),'global':s.is_global(),'local':s.is_local(),'free':s.is_free(),'nonlocal':s.is_nonlocal(),'imported':s.is_imported()})
 out=[{'path':path,'type':st.get_type(),'line':st.get_lineno(),'complete_entries':es,'entries_sha256':sh(jb(es))}]
 for i,c in enumerate(st.get_children()):out+=scopes(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 return out
c=json.loads((B/'cluster-receptor-multipart-complete-mechanical-replacement-census-v1.json').read_text());allroles=[];patches=[]
for role in c['roles']:
 op=Path(role['old_Source']['path']);np=Path(role['new_Source']['path']);old=op.read_bytes();new=np.read_bytes();assert pin(op)==role['old_Source'] and pin(np)==role['new_Source'];os=old.decode();ns=new.decode()
 inverse=ns
 for r in reversed(role['complete_ordered_replacement_classes']):
  assert inverse.count(r['new'])==r['occurrences'],r['class'];inverse=inverse.replace(r['new'],r['old'])
 assert inverse.encode()==old
 # Full native forward and inverse patches apply to exact complete bodies.
 for direction,a,b,base,expected in [('forward',os,ns,op,new),('inverse',ns,os,np,old)]:
  patch=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+base.name,tofile='b/'+np.name));pp=B/('multipart-'+role['role']+'-'+direction+'-v1.patch');pp.write_text(patch);out=B/('multipart-'+role['role']+'-'+direction+'-native-readback-v1.py');rr=subprocess.run(['/usr/bin/patch','-s','-o',str(out),str(base),str(pp)],capture_output=True);assert rr.returncode==0,(rr.stdout,rr.stderr);assert out.read_bytes()==expected
  patches.append({'role':role['role'],'direction':direction,'patch':pin(pp),'native_apply_exit':rr.returncode,'whole_byte_identity':True,'output':pin(out)})
 ot=ast.parse(os,filename=str(op));nt=ast.parse(ns,filename=str(np));it=ast.parse(inverse,filename=str(op));assert ast.dump(ot,include_attributes=True)==ast.dump(it,include_attributes=True)
 co=compile(new,str(np),'exec',dont_inherit=True,optimize=0);del co
 ods=defs(ot,os);nds=defs(nt,ns);assert set(ods)==set(nds)
 imports=[ast.unparse(n)for n in nt.body if isinstance(n,(ast.Import,ast.ImportFrom))];assert imports==[ast.unparse(n)for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))]
 for k in ods:assert ods[k]['signature']==nds[k]['signature'] and ods[k]['full_callset']==nds[k]['full_callset']
 changed=[k for k in ods if ods[k]['raw_sha256']!=nds[k]['raw_sha256']]
 expected=['publish','main']if role['role']=='publisher'else['verify'];assert changed==expected,(changed,expected)
 allroles.append({'role':role['role'],'Source':pin(np),'predecessor':pin(op),'whole_AST_sha256':sh(ast.dump(nt,include_attributes=False).encode()),'whole_positioned_AST_sha256':sh(ast.dump(nt,include_attributes=True).encode()),'whole_inverse_raw_AST_identity':True,'imports_unchanged':imports,'all_helpers_callsets_and_signatures_unchanged':True,'definition_count':len(nds),'complete_helper_preservation':[{'old':ods[k],'new':nds[k],'raw_equal':ods[k]['raw_sha256']==nds[k]['raw_sha256'],'AST_equal':ods[k]['AST_sha256']==nds[k]['AST_sha256']}for k in ods],'changed_only_literal_helpers':changed,'complete_symbol_scopes':scopes(symtable.symtable(ns,str(np),'exec')),'all_functions_compiled_unused':'PASS; no code object execution'})
# Explicit fixed-bound checks from raw Source AST literals, never importing either module.
def vals(t):
 d={}
 for n in t.body:
  if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:d[n.targets[0].id]=ast.literal_eval(n.value)
   except ValueError:pass
 return d
pv=vals(ast.parse(Path(allroles[0]['Source']['path']).read_text()));tv=vals(ast.parse(Path(allroles[1]['Source']['path']).read_text()))
assert len(pv['NAMES'])==10 and pv['NAMES']==tv['NAMES'] and len(set(pv['NAMES']))==10
assert pv['CAP']==tv['CAP']==67108864 and pv['ADMIN_CAP']==1048576 and pv['BASELINE']=='5e2663862dddd3892591e9149169da50b20ca457'
assert sum(r['definition_count']for r in allroles)==28
out={'schema':'Root-cluster-receptor-multipart-complete-Source-static-and-preservation-v1','status':'PASS_SOURCE_ONLY','Source_roles':allroles,'complete_mechanical_census':pin(B/'cluster-receptor-multipart-complete-mechanical-replacement-census-v1.json'),'complete_four_patches':patches,'names':list(pv['NAMES']),'same_imports_signatures_callsets':True,'whole_raw_and_positioned_AST_inverse_identity':True,'28definitions_all_covered':True,'25helper_raw_AST_unchanged':True,'all_changed_helpers_are_literal_only':['publisher.publish','publisher.main','verifier.verify'],'static_runtime':{'executable':sys.executable,'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'Source_function_calls':0,'network_or_payload_calls':0,'code_object_execution':0,'execution_authorized':False}
p=B/'cluster-receptor-multipart-complete-Source-static-and-preservation-v1.json';p.write_bytes(jb(out));print(json.dumps({'static':pin(p),'definitions':[(r['role'],r['definition_count'],len(r['complete_symbol_scopes']))for r in allroles],'patches':4,'classes':c['total_classes'],'occurrences':c['total_occurrences']},sort_keys=True,indent=2))
