from pathlib import Path
import json, hashlib, html, re

PUB=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1')
D=PUB/'implementation-B/actual-data-draft-v1'
OUT=PUB/'root/report-assembly-v2'
BASE=Path('/private/tmp/gcts-corner-family-publication-20261027-v1/root/publication-corner-family-v1/point-proof-parallel-progress-v1.html')
def load(p): return json.loads(Path(p).read_bytes())
def esc(v): return html.escape(str(v),quote=True)
def ref(p):
    b=Path(p).read_bytes(); return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
data=load(D/'cluster-N2-focused-public-outcome-tables-draft-v1.json')
board=load(D/'cluster-receptor-large-computation-board-draft-v1.json')
visual=load(D/'cluster-receptor-visual-records-draft-v1.json')
held=load(PUB/'implementation-C/cluster-N2-heldout-fresh-and-pending-inspector-samples-v1.json')
samples=held['samples']+visual['samples']
assert len(samples)==8 and len({s['id'] for s in samples})==8
inspector=(PUB/'implementation-B/cluster-inspector-fragment-v1.html').read_text()
placeholder='{"schema":"Root-cluster-receptor-visual-records-v1","samples":[]}'
assert inspector.count(placeholder)==1
# Presentation-only successor: two JS-source slashes yield one DOM MathJax slash.
old_delimiter='\\'*4
new_delimiter='\\'*2
coordinate_line=next(line for line in inspector.splitlines() if 'coordinate.textContent=' in line)
assert coordinate_line.count(old_delimiter)==2
inspector=inspector.replace(coordinate_line,coordinate_line.replace(old_delimiter,new_delimiter),1)
inspector=inspector.replace(placeholder,json.dumps({'schema':'Root-cluster-receptor-visual-records-v1','samples':samples},separators=(',',':')).replace('<','\\u003c'))
style_note=(PUB/'root/cluster-report-static-style-and-failure-note-v1.html').read_text()
style=style_note[style_note.index('<style>'):style_note.index('</style>')+8]
failure=style_note[style_note.index('<details id="cr-failed-predecessor">'):]
strategy={'LEX_NO_CLUSTER':'Lexical','UNTRAINED_CLUSTER':'Untrained clusters','TRAINED_FIRST_ONLY':'Trained first only','TRAINED_CLUSTER':'Trained full clusters'}
status={'FINITE_EXACT_SOLUTION':'SAT','EXHAUSTED_FINITE_SEARCH':'UNSAT','UNKNOWN':'UNKNOWN'}
rows=[]
for pair in data['all24_evaluation_pairs']:
    p,c=pair['arms']['point'],pair['arms']['csp']
    values=[str(pair['context']), '20 reused layers' if pair['reused_marking'] else 'Original Wang',strategy[pair['strategy']]]
    for a in [p,c]:
        values.extend([status[a['status']],str(a['nodes']),f"{a['through_complete_body_write_seconds']:.3f}"])
    values.extend([str((p['actor_costs'] or {}).get('pending_reuses',0))+'/'+str((c['actor_costs'] or {}).get('pending_reuses',0)), 'Complete' if pair['comparison']['full_trace_status_nodes_and_common_metrics_asserted'] else 'Common prefix'])
    rows.append('<tr>'+''.join('<td>'+esc(v)+'</td>' for v in values)+'</tr>')
eval_table='<div class="cr-scroll"><table id="cr-evaluation-table"><caption>All 24 paired evaluations: 48 actual arms, in the saved execution order</caption><thead><tr>'+''.join('<th>'+s+'</th>' for s in ['Case','Information','Strategy','Point status','Nodes','Seconds','CSP status','Nodes','Seconds','Later uses P/C','Paired trace'])+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'
training=[]
for e in data['all32_training_updates_and64arms']:
    a,b=e['arms']['POINT'],e['arms']['CSP']
    vals=[e['episode'],e['descriptor']['word'],'Flipped' if e['descriptor']['negative'] else 'Positive',status[a['status']],a['nodes'],status[b['status']],b['nodes'],e['feedback']['status'],f"{e['reward_terms']['reward']:.5f}",e['token_count']]
    training.append('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in vals)+'</tr>')
training='<details id="cr-all-training"><summary>All 32 training updates and 64 training arms</summary><div class="cr-scroll"><table><thead><tr>'+''.join('<th>'+s+'</th>' for s in ['Episode','Input word','Target','Point status','Nodes','CSP status','Nodes','Feedback','Reward','Tokens'])+'</tr></thead><tbody>'+''.join(training)+'</tbody></table></div></details>'
weights='<details><summary>All 12 final policy weights</summary><div class="cr-scroll"><table><thead><tr><th>Feature identifier</th><th>Final weight</th></tr></thead><tbody>'+''.join('<tr><td><code>'+esc(n)+'</code></td><td>'+esc(repr(w))+'</td></tr>' for n,w in data['final_weights_by_feature'])+'</tbody></table></div><p>Initial weights were zero. The frozen policy hash is <code>1811f5dffd4b15c34bcdef45ac223367a35178532b1d3e624fb000aa38770b7f</code>.</p></details>'

# Display saved placements and labels only. This does not evaluate Rule 90.
svg=['<svg id="cr-computation-svg" viewBox="-30 -30 1060 940" role="img" aria-label="Saved 72-tile Wang computation with original edge labels and orange learned corner layer zero"><title>Actual large positive CSP solution, lexical strategy with 20 reused certified layers</title>']
for cell in board['cells']:
    x,y=cell['cell']; px,py=x*112,y*112
    svg.append(f'<g><title>{esc(cell["full_placement_row"]["id"])}</title><rect x="{px}" y="{py}" width="112" height="112" fill="{["#edf7f5","#fff"][y not in [0,7]]}" stroke="#33857c" stroke-width="2"/>')
    for edge,dx,dy in [('N',56,15),('S',56,104),('W',23,58),('E',88,58)]:
        svg.append(f'<text x="{px+dx}" y="{py+dy}" text-anchor="middle" font-family="monospace" font-size="9" fill="#176f66">{esc(cell["palette_edges"][edge])}</text>')
    svg.append(f'<text x="{px+56}" y="{py+79}" text-anchor="middle" font-size="10" fill="#4c6070">{esc(cell["tile_id"])}</text></g>')
slots={}
for cell in board['cells']:
    for x,y,ch,v in cell['full_placement_row']['m']:
        if ch=='LEARNED_CORNER:0': slots.setdefault((x,y),set()).add(v)
for (x,y),vs in sorted(slots.items()):
    px,py=(x+1)*56,(y+1)*56
    svg.append(f'<circle cx="{px}" cy="{py}" r="6" fill="#b65e13" stroke="white" stroke-width="2"><title>LEARNED_CORNER:0 literal {esc("/".join(sorted(vs)))}, saved point ({x},{y})</title></circle><text x="{px+8}" y="{py-6}" font-family="monospace" font-size="10" fill="#894000">{esc("/".join(sorted(vs)))}</text>')
svg.append('</svg>')
wordrows=[]
for row in board['state_words_read_from_stored_south_edge_labels']:
    k=row['from_tile_row']; word=row['word'].replace('#',r'\#')
    wordrows.append(f'<tr><td>{k}</td><td>\\(s^{{({k})}}=\\mathtt{{{word}}}\\)</td><td>{"Read the initial boundary" if k==0 else "After encoded XOR step "+str(k)}</td></tr>')
boardview='<figure>'+''.join(svg)+'<figcaption>Actual saved lexical CSP solution: 72 ordinary tiles in eight rows; the exterior collar is omitted from this picture. Teal labels are the original Wang layer; orange dots and their literal values show one of the 20 previously certified corner layers, <code>LEARNED_CORNER:0</code>. Fixed orientation, translations only. The other 19 corner channels remain in the certificate.</figcaption></figure><div class="cr-scroll"><table id="cr-row-translation"><thead><tr><th>Boundary after tile row</th><th>Decoded formula</th><th>Reading</th></tr></thead><tbody>'+''.join(wordrows)+'</tbody></table></div><p class="cr-muted">These words are decoded from the saved south-edge labels. The eighth tile row checks the specified output boundary. This is a finite computation certificate, not a Peano-arithmetic or Hilbert-geometry theorem. Source original: <code>'+esc(board['source_ref']['path'])+'</code>; SHA256 <code>'+board['source_ref']['sha256']+'</code>.</p>'
archive_names=['point-proof-cluster-receptor-evidence-v1.zip']+[f'point-proof-cluster-receptor-evidence-v1-part-{i:02d}.zip' for i in range(2,9)]
links='<ol>'+''.join('<li><a href="'+n+'">Evidence volume '+str(i)+'</a></li>' for i,n in enumerate(archive_names,1))+'</ol>'
section=r'''<section id="cluster-receptor-current" aria-labelledby="cr-current-title">
STYLE
<p class="cr-kicker">Research update · 27 October 2026 · complete finite study N2</p>
<h1 id="cr-current-title">Clusters can continue; useful learning is still unproven</h1>
<div class="cr-verdict"><p><strong>The policy was updated, and a proposed cluster could supply a later actual move. This held-out panel shows no benefit from training or composition.</strong> The trained, untrained and first-move-only controls have the same branch order wherever their saved histories can be compared. The complete small cases take at least as many nodes as lexical search and more total time.</p></div>
<div class="cr-stats"><div class="cr-stat"><strong>32</strong>training updates from 64 paired arms</div><div class="cr-stat"><strong>48</strong>evaluation arms, all reported below</div><div class="cr-stat"><strong>4</strong>actual later-member uses in evaluation</div></div>
<nav class="cr-links" aria-label="Current study sections"><a href="#cr-inspector">Inspect actual clusters</a><a href="#cr-evaluation">All evaluations</a><a href="#cr-computation">Tiles to readable rows</a><a href="#cr-training">Learning and costs</a><a href="#cr-archive">Complete evidence</a><a href="#cr-next">Next research targets</a><a href="#corner-family-current">Earlier marking study</a></nav>
<h2>What this experiment establishes</h2>
<p>A fresh softmax policy proposes up to four jointly compatible placements, conditioned on the current selected tiles and boundary. A later call can retain an earlier member as a shared attachment and propose a remaining member. The current graph and marking checks validate each proposal again. The ordinary controller still propagates forced moves and chooses each base placement; every ordinary branch remains available. A cluster is a preference, not a proved implication that forces its tail.</p>
<p>The records contain 48 actual later-member placements: 44 during training and four during evaluation. Of these, 29 choose a value other than lexical first; the remaining 19 already agree with lexical first. Learning changes the full proposal contents in 31 of 71 matched observations, but those changes produce no observed branch-order difference from the untrained control. Actual use is therefore established; useful learned transfer is not.</p>
<div class="cr-limit"><strong>Scope:</strong> the palette has 33 fixed XOR-computation Wang types. This phase reuses an explicitly certified 20-layer marking map as one control; it does not learn those markings again from scratch. These finite rectangular unit-anchor models make every required point a generation-zero root. They do not test the general growing frontier, movable boundaries, universal first-order proof tiles, or a learned inventory of mathematical lemmas.</div>
<h2>A held-out continuation, with its limitation</h2>
<p>The first two inspector choices are consecutive saved observations from the small positive evaluation. At actor call 5, a two-member proposal supplies the next move. At call 6, that first member remains selected and the second member becomes the actual next nonforced placement. The red cross is the scheduled point, and color distinguishes the marking channel and placement role. This same second choice also appears in the first-move-only control: the visible continuation is not evidence that composition improved the search.</p>
INSPECTOR
<h2 id="cr-evaluation">All evaluation cases and controls</h2>
<p>The training words were <code>000</code>, <code>011</code>, <code>101</code> and <code>110</code>, with four repetitions and positive/flipped final boundaries. Evaluation uses two different fixed input words. Cases 0 and 1 use <code>001</code> on a \(5\times4\) board; cases 2 and 3 use <code>0010111</code> on a \(9\times8\) board. Odd cases flip one final symbol. The search windows are five seconds for small evaluations and ten for large evaluations, with 5,000 nodes allowed. These are cooperative limits, not hard interruption guarantees.</p>
<p>“Seconds” below includes preparation, auditing, verification, lossless encoding and complete evidence writing. It is not raw solver time. SAT means a checked finite exact solution; UNSAT means checked complete exhaustion of this finite problem; UNKNOWN remains unresolved. A common decision prefix does not imply equal status, equal nodes or equal speed.</p>
EVALUATIONS
<p>There are 12 complete paired semantic traces and 12 nonvacuous common-prefix comparisons. Both engines receive the same information and ordering preferences. All larger original-Wang arms remain UNKNOWN. With the reused marking map, the ordinary CSP completes both large targets; the point engine reaches its window. Every marked evaluation has zero branches and zero actor calls, so its completion cannot be credited to the new cluster policy. Eager policy and cluster preparation still adds cost.</p>
<p>On the small positive original problem, lexical search needs 29 nodes and each cluster control needs 31. On the negative original problem, all strategies need 33. The observed continuation never changes the trained-full branch order relative to trained-first-only at a shared history. This panel provides no practical GCTS/RL advantage and no comparison with industrial automated theorem provers. It has only four fixed contexts and one seed per context; there is no statistical generalization claim.</p>
<h2 id="cr-computation">One complete computation, row by row</h2>
BOARD
<h2 id="cr-training">What was learned, and what it cost</h2>
<p>All 32 updates change the weight vector, starting from zero. Only the point trajectory supplies the gradient; its reward is tied to the paired checks. Four episodes have a paired verified SAT completion; the other 28 receive UNKNOWN shaping and cost feedback. No timeout is counted as an impossibility proof.</p>
<p>With verified completion bonus \(I\), verified ordinary-anchor fill fraction \(f\), attempts \(a\), branches \(b\), backtracks \(r\) and actor candidate visits \(v\), the reward is</p>
\[R=I+0.1f-0.005(a+b+r)-10^{-5}v.\]
<p>The update uses the token score sum divided by the fixed horizon \(H=4\), learning rate \(0.04\), clipping to \([-4,4]\), and baseline smoothing \(0.2\). The fill denominator is the unseeded ordinary anchors, not the drawn collar. A full generated cluster is paid for even in the first-move-only control.</p>
TRAINING
WEIGHTS
<p>The owned parent interval through child wait is 532.700 seconds. The worker samples 531.076 seconds before final result writing. Observed child lifetime RSS high-water is 449,232,896 bytes; the observer is measured separately. The complete named saved outputs occupy 145,355,866 bytes. These are observed, scope-specific resource measurements, not hard process-tree limits. The full scientific attempt passed whole-cohort review; its 112 main arms and all raw evidence remain available.</p>
FAILURE
<h2 id="cr-archive">Approved complete public evidence</h2>
<p><a href="point-proof-cluster-receptor-summary-v1.json">Download the machine-readable results and admission summary</a>. The full archive is stored in eight independent ordinary ZIP volumes. Download all eight for the complete collection and extract them into one directory; there is no split-stream reassembly. Each volume contains a catalogue with original paths, bytes, SHA256 hashes and the volume containing each file. It preserves both attempts, source snapshots, proof certificates, runtime logs, reviews and the prior marking evidence.</p>
ARCHIVES
<p>Archive contents stop at the preparation cut described in the catalogue. The final web files and subsequent publication, TLS and browser receipts are outside that cut. Source/runtime pins and once-run custody distinguish the failed predecessor from the admitted successor. Main arm envelopes and their nested audit logs are lossless standard JSON/base64/zlib; the original stored bytes are preserved. Transient native argument states were recorded by hashes; full native entry, final and restored states, complete normalized audit rows and returned checks are retained. Post-run review joined bytes and records without rerunning a solver, actor, certificate evaluator or policy update.</p>
<h2 id="cr-next">Where this leaves the proof-search program</h2>
<p>The next decisive task is an actual fixed, expressive proof palette with a small trusted checker and readable row decoding. Arithmetic and symbolic Hilbert geometry should share this logical core while providing their axioms as input. A benchmark must ask the system to discover proofs without supplied proof scripts, preserve failed and timed-out cases, and compare ordinary search, learned ordering, reusable certified lemmas and parameterized receptor families at the same information and resource budget.</p>
<p>Useful evidence would be fewer expansions or more newly proved held-out statements after charging for learning, validation and inventory construction. The present conditional clusters are not yet such lemmas. Practical arbitrary-region tiling, movable boundaries, Turtle on the \(A_2\) lattice and Penrose arithmetic over \(\mathbb Z[\zeta_5]\) remain open research goals. A substitution rule is one possible tool, not a required endpoint.</p>
<p class="cr-muted">The earlier studies follow below in their original form. Their dates, claims and limitations remain historical; this leading section is the current disposition.</p>
</section>
'''
for key,val in [('STYLE',style),('INSPECTOR',inspector),('EVALUATIONS',eval_table),('BOARD',boardview),('TRAINING',training),('WEIGHTS',weights),('FAILURE',failure),('ARCHIVES',links)]:
    assert section.count(key)==1,(key,section.count(key)); section=section.replace(key,val)
base=BASE.read_text()
oldtitle='<title>Learning certified corner markings: complete finite study</title>'
newtitle='<title>Cluster receptors: complete GCTS and RL evaluation</title>'
assert base.count(oldtitle)==1 and base.count('<body>')==1
final=base.replace(oldtitle,newtitle).replace('<body>','<body>'+section,1)
assert final.replace(section,'',1).replace(newtitle,oldtitle).encode()==BASE.read_bytes()
assert final.count('id="cluster-receptor-current"')==1
(OUT/'point-proof-parallel-progress-v1.html').write_text(final)
(OUT/'current-section-v1.html').write_text(section)
(OUT/'assembly-data-provenance-v1.json').write_text(json.dumps({'schema':'Root-cluster-report-assembly-data-provenance-v1','inputs':[ref(BASE),ref(D/'cluster-N2-focused-public-outcome-tables-draft-v1.json'),ref(D/'cluster-receptor-large-computation-board-draft-v1.json'),ref(D/'cluster-receptor-visual-records-draft-v1.json'),ref(PUB/'implementation-C/cluster-N2-heldout-fresh-and-pending-inspector-samples-v1.json')],'prior_body_preservation':'Removing exact leading section and restoring title yields entire prior bytes','new_section':ref(OUT/'current-section-v1.html'),'html':ref(OUT/'point-proof-parallel-progress-v1.html'),'scientific_execution':False},indent=2)+'\n')
print(json.dumps(ref(OUT/'point-proof-parallel-progress-v1.html')))
