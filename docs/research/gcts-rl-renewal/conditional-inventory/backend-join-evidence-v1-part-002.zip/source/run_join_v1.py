"""Frozen, one-execution backend qualification and actual arithmetic join.

This certifies an already searched proof. No proof or tile search runs here.
The large tile certificate is compressed, with literal refusal retained.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
KERNEL_LIMITS=dict(max_depth=256,max_operations=10000000,max_proof_lines=4096)

def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(value):return hashlib.sha256(wire(value)).hexdigest()
def pin(path):
    h=hashlib.sha256();n=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())
def save(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('xb') as raw:
        stream=gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=6) if p.suffix=='.gz' else raw
        try:
            for part in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value):stream.write(part.encode('ascii'))
            stream.write(b'\n')
        finally:
            if stream is not raw:stream.close()
    return dict(path=name,**pin(p))
def read(name):
    p=ROOT/name
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open(encoding='ascii')) as f:return json.load(f)
def mod(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
def freeze(phase):
    sources={p.relative_to(ROOT).as_posix():pin(p) for folder in ('source','reference','input') for p in sorted((ROOT/folder).rglob('*')) if p.is_file()}
    master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
    assert pin(master)==pin(ROOT/'reference/basic-tiling-algorithm.md')
    protocol=dict(schema='BJ-prospective-protocol-v1',phase=phase,pins=sources,
        python=dict(path=sys.executable,version=sys.version,**pin(Path(sys.executable))),
        arithmetic_bounds=dict(nodes=32,variables=2,functions=3,predicates=0,axioms=1,lines=12,substitutions=4,arity=2),
        qualification_bounds=dict(nodes=3,variables=1,functions=1,predicates=0,axioms=0,lines=1,substitutions=0,arity=2),
        qualification_free_input_cap=12,decoder_limits=dict(max_items=10000000,max_work=20000000,wall_seconds=30),
        process_guards=dict(rss_bytes=2147483648,cpu_seconds=900,wall_seconds=1200),
        scope='Generic raw-checker backend join of exact prior selected12-line arithmetic proof. No new proof search, no primitive large-grid Wang search, no witness-dependent problem pins. Tiny reflexivity is qualification only.')
    save('data/'+phase+'-protocol-v1.json',protocol);return protocol
def unchanged(protocol):
    for name,expected in protocol['pins'].items():assert pin(ROOT/name)==expected,name
    runtime=protocol['python'];assert pin(Path(runtime['path']))=={k:runtime[k] for k in ('bytes','sha256')}
    assert pin(Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md'))==protocol['pins']['reference/basic-tiling-algorithm.md']

def stages(name,compiled,proof,bounds,provenance,modules,protocol):
    A,D,F,R,N=modules;started=time.perf_counter();refs={};objects={}
    calls=[('prepare',lambda:A.prepare(compiled,proof,bounds=bounds,provenance=provenance)),
        ('compile',lambda:A.compile_backend(objects['prepare'])),
        ('encode',lambda:A.build_bits(objects['prepare'],objects['compile']))]
    expected={'prepare':'PREPARED','compile':'COMPILED','encode':'ENCODED'}
    for label,call in calls:
        value=call();refs[label]=save('data/'+name+'/'+label+'.json.gz',value);objects[label]=value
        print(json.dumps(dict(case=name,stage=label,status=value['status'],seconds=value['seconds'])),flush=True)
        if value['status']!=expected[label]:
            record=dict(id=name,status='INCOMPLETE_BACKEND_CONSTRUCTION',stopped_stage=label,artifacts=refs,
                pipeline_seconds=time.perf_counter()-started)
            save('data/'+name+'-result-v1.json',record);return record,objects
    prepared,backend,encoded=(objects[k] for k in ('prepare','compile','encode'))
    inverse=D.decode(bounds,backend['circuit']['inputs'],encoded['input_bits'],prepared['original_statement'],
        variables=prepared['encoding_theory']['variables'],**protocol['decoder_limits'])
    refs['inverse']=save('data/'+name+'/inverse-check.json',inverse)
    raw=F.check(bounds,inverse['raw_certificate']) if inverse['status']=='VERIFIED' else dict(status='NOT_APPLICABLE')
    refs['raw']=save('data/'+name+'/raw-check.json',raw)
    if inverse['status']=='VERIFIED':
        human=inverse['human'];native=N.check(human['theory'],human['proof'],human['goal'],KERNEL_LIMITS)
        roundtrip=A._modules()['data'].encode_bits(bounds,inverse['raw_certificate'],backend['circuit']['inputs'])
        def projection(lines):
            rules=dict(axiom=('name',),mp=('antecedent','implication'),generalize=('source','variable'),
                instantiate=('universal','term'),refl=(),eq_subst=('variable','template','left','right'))
            ast_keys={'formula','universal','term','template','left','right'}
            return [{key:A._normalize(line[key]) if key in ast_keys else line[key]
                for key in ('rule','formula')+rules[line['rule']]} for line in lines]
        actual_projection=projection(prepared['proof']);decoded_projection=projection(human['proof'])
        binding=dict(status='VERIFIED' if inverse['raw_certificate']==encoded['raw_certificate'] and roundtrip==encoded['input_bits'] and
            actual_projection==decoded_projection and sha(human['normalized_original_statement'])==prepared['normalized_statement_sha256'] else 'REJECTED',
            raw_certificate_roundtrip=inverse['raw_certificate']==encoded['raw_certificate'],
            exact_bit_roundtrip=roundtrip==encoded['input_bits'],
            exact_normalized_native_lines=actual_projection==decoded_projection,
            normalized_native_line_sha256=sha(decoded_projection),
            normalized_statement_sha256=sha(human['normalized_original_statement']),
            original_statement_sha256=prepared['original_statement_sha256'],
            normalization=prepared['normalization'])
    else:native=binding=dict(status='NOT_APPLICABLE')
    refs['native']=save('data/'+name+'/decoded-native-check.json',native)
    refs['binding']=save('data/'+name+'/common-statement-check.json',binding)
    assert all(v['status']=='VERIFIED' for v in (inverse,raw,native,binding)),(name,inverse.get('reason'),raw,native,binding)
    ribbon=A.build_ribbon(prepared,backend,encoded);refs['ribbon']=save('data/'+name+'/ribbon.json.gz',ribbon);objects['ribbon']=ribbon
    print(json.dumps(dict(case=name,stage='ribbon',status=ribbon['status'],seconds=ribbon['seconds'])),flush=True)
    if ribbon['status']=='CERTIFICATE_BUILT':
        symbolic=R.verify(backend['circuit'],ribbon['ribbon'],backend['palette'])
        refs['symbolic']=save('data/'+name+'/symbolic-tile-check.json',symbolic)
        literal=R.verify_literal(backend['circuit'],ribbon['ribbon'],backend['palette'])
        refs['literal']=save('data/'+name+'/literal-tile-check.json',literal)
        assert symbolic['status']=='VERIFIED' and literal['status'] in ('VERIFIED','UNKNOWN'),(symbolic,literal)
        status='VERIFIED_COMPRESSED_BACKEND_JOIN'
    else:status='INCOMPLETE_TILE_BACKEND'
    record=dict(id=name,status=status,artifacts=refs,bounds=bounds,
        proof_lines=len(proof),pipeline_seconds=time.perf_counter()-started,
        metrics=dict(prepare=prepared['metrics'],compile=backend['metrics'],encode=encoded['metrics'],ribbon=ribbon.get('metrics')),
        scope='Exact original searched proof retained. Native/raw/common-statement checks independent of tile certificate; compressed expansion is not primitive grid search or literal verification.')
    save('data/'+name+'-result-v1.json',record)
    return record,objects

def qualification(modules,protocol):
    A,D,F,R,N=modules;c=['fun','c',[]];goal=['eq',c,c]
    compiled=dict(theory=dict(functions={'c':0},predicates={},axioms={}),goal=goal,
        logical_basis=dict(formulas=[goal]),zero_instances=[])
    proof=[dict(rule='refl',formula=goal)]
    save('data/qualification-declaration-v1.json',dict(compiled=compiled,proof=proof,bounds=protocol['qualification_bounds'],scope='Hand-declared kernel/codec qualification only; not a new searched theorem.'))
    record,objects=stages('qualification',compiled,proof,protocol['qualification_bounds'],{},modules,protocol)
    assert record['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN'
    prepared,backend,encoded,ribbon=(objects[k] for k in ('prepare','compile','encode','ribbon'))
    assert read(record['artifacts']['literal']['path'])['status']=='VERIFIED'
    circuit=backend['circuit'];free=[i for i,item in enumerate(circuit['inputs']) if item['value'] is None]
    assert len(free)<=protocol['qualification_free_input_cap'] and all(circuit['inputs'][i]['name'].startswith('line.0.') for i in free)
    trials=[];accepted=0
    for mask in range(1<<len(free)):
        bits=list(encoded['input_bits'])
        for bit,index in enumerate(free):bits[index]=(mask>>bit)&1
        raw=copy.deepcopy(encoded['raw_certificate'])
        for field in raw['proof'][0]:
            entries=[(int(item['name'].rsplit('.',1)[1]),bits[i]) for i,item in enumerate(circuit['inputs']) if item['name'].startswith('line.0.'+field+'.')]
            raw['proof'][0][field]=sum(value<<k for k,value in entries)
        raw_check=F.check(prepared['bounds'],raw);_,bit=A._modules()['fp'].evaluate(circuit,bits)
        inverse=D.decode(prepared['bounds'],circuit['inputs'],bits,prepared['original_statement'],variables=prepared['encoding_theory']['variables'],**protocol['decoder_limits'])
        assert raw_check['status'] in ('VERIFIED','REJECTED') and bit==int(raw_check['status']=='VERIFIED')
        if inverse['status']=='VERIFIED':assert inverse['raw_certificate']==raw
        if bit:assert inverse['status']=='VERIFIED';accepted+=1
        trials.append(dict(mask=mask,input_bits=bits,raw_certificate=raw,raw_check=raw_check,
            circuit_acceptance_bit=bit,decoder_status=inverse['status'],decoder_reason=inverse.get('reason')))
    table=save('data/qualification-truth-table-v1.json.gz',dict(free_indices=free,assignments=trials,accepted=accepted))
    controls=[]
    def corrupt(cid,inputs,bits,statement):
        value=dict(circuit_inputs=inputs,input_bits=bits,original_statement=statement,bounds=prepared['bounds'],variables=prepared['encoding_theory']['variables'])
        source=save('data/qualification/'+cid+'-input.json.gz',value)
        result=D.decode(value['bounds'],inputs,bits,statement,variables=value['variables'],**protocol['decoder_limits'])
        check=save('data/qualification/'+cid+'-check.json',result);assert result['status']=='REJECTED',(cid,result)
        controls.append(dict(id=cid,input=source,check=check))
    pins=copy.deepcopy(circuit['inputs']);index=next(i for i,x in enumerate(pins) if x['name'].startswith('goal.'))
    bits=list(encoded['input_bits']);bits[index]^=1;corrupt('changed-frozen-goal-bit',pins,bits,prepared['original_statement'])
    pins=copy.deepcopy(circuit['inputs']);pins[index]['value']=None;corrupt('missing-statement-pin',pins,encoded['input_bits'],prepared['original_statement'])
    pins=copy.deepcopy(circuit['inputs']);pins[free[0]]['value']=encoded['input_bits'][free[0]];corrupt('extra-proof-witness-pin',pins,encoded['input_bits'],prepared['original_statement'])
    pins=copy.deepcopy(circuit['inputs']);pins[2],pins[3]=pins[3],pins[2];corrupt('altered-input-order',pins,encoded['input_bits'],prepared['original_statement'])
    limited=D.decode(prepared['bounds'],circuit['inputs'],encoded['input_bits'],prepared['original_statement'],variables=prepared['encoding_theory']['variables'],max_work=1)
    assert limited['status']=='UNKNOWN';save('data/qualification/resource-refusal.json',limited)
    altered=copy.deepcopy(ribbon['ribbon']);altered['rows'][0]['active'][0][1]=(altered['rows'][0]['active'][0][1]+1)%100
    mutant=save('data/qualification/altered-active-tile.json.gz',altered)
    rejected=dict(symbolic=R.verify(circuit,altered,backend['palette']),literal=R.verify_literal(circuit,altered,backend['palette']))
    assert all(x['status']=='REJECTED' for x in rejected.values());ref=save('data/qualification/altered-active-tile-check.json',rejected)
    result=dict(status='VERIFIED_BACKEND_QUALIFICATION',baseline=record,truth_table=table,
        assignments=len(trials),accepted=accepted,codec_controls=controls,ribbon_mutant=dict(input=mutant,check=ref),resource_refusal=limited)
    save('data/qualification-results-v1.json',result)

def arithmetic(modules,protocol):
    snapshot=read('review/input-snapshot-v1.json')
    for entry in snapshot['files']:assert pin(ROOT/entry['path'])=={k:entry[k] for k in ('bytes','sha256')}
    assert read('data/qualification-results-v1.json')['status']=='VERIFIED_BACKEND_QUALIFICATION'
    prepared=read('input/arithmetic-prepared.json.gz');raw=read('input/arithmetic-search-raw.json.gz')
    native=read('input/arithmetic-native-check.json');graph=read('input/arithmetic-graph-check.json')
    assert raw['result']['status']=='SAT' and graph['status']=='VERIFIED' and native['status']=='VERIFIED'
    assert sha(raw['model'])==graph['model_sha256'] and sha(prepared['lanes']['MARKS']['universe'])==graph['universe_sha256']
    assert sorted(raw['result']['selected'])==native['decoded']['tree']['selected']
    assert native['decoded']['target']==prepared['compiled']['goal'] and native['decoded']['proof'][-1]['formula']==prepared['compiled']['goal']
    provenance=dict(source_public_commit='8b2f7e381943d713b4dd200250f30eb508cbaefc',input_snapshot=snapshot,
        actual_point_case=raw['id'],scope='Only original MARKS selected proof; no DP/control proof read or used. This is an end-to-end backend join of previously searched output, not new proof discovery.')
    record,objects=stages('arithmetic',prepared['compiled'],native['decoded']['proof'],protocol['arithmetic_bounds'],provenance,modules,protocol)
    save('data/arithmetic-results-v1.json',dict(status=record['status'],record=record,
        original_theory_reader=prepared['theory_reader'],original_proof_reader=native['proof_reader'],provenance=provenance))

def main():
    p=argparse.ArgumentParser();p.add_argument('phase',choices=('qualification','arithmetic'));args=p.parse_args()
    started=time.perf_counter();protocol=freeze(args.phase)
    try:
        modules=(mod('backend_adapter','source/backend_join_v1.py'),mod('inverse_codec','reference/raw_input_decoder_v1.py'),
            mod('independent_raw_fol','reference/upstream/raw_fol_checker_v1.py'),mod('independent_ribbon','reference/upstream/ribbon_checker_v3.py'),
            mod('independent_native_fol','reference/native_fol_checker_v1.py'))
        (qualification if args.phase=='qualification' else arithmetic)(modules,protocol)
        unchanged(protocol)
    finally:
        save('review/'+args.phase+'-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',phase=args.phase,
            main_seconds=time.perf_counter()-started,platform=sys.platform,ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Own fresh invocation including inline independent assurance and preceding persistence; Darwin RSS high-water bytes.'))
if __name__=='__main__':main()
