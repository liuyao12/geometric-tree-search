"""Staged exact native-proof -> raw kernel -> NAND -> fixed-palette backend.

No proof discovery, producer catalogue, policy or independent checker is used.
Dependencies are lazy, unchanged byte-pinned snapshots. A constructed artifact
is not an independent verification receipt. Resource refusals stay UNKNOWN.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time


ROOT = Path(__file__).resolve().parents[1]
VERSION = 'Fresh-actual-proof-backend-join-v1'
DEFAULT_BOUNDS = dict(nodes=32, variables=2, functions=3, predicates=0,
                      axioms=1, lines=12, substitutions=4, arity=2)
KERNEL_CAPS = dict(nodes=64, variables=8, functions=16, predicates=16,
                   axioms=16, lines=16, substitutions=4, arity=4)
DEFAULT_RESOURCES = dict(max_nand_gates=2000000, max_inputs=20000,
                         max_ribbon_rows=2000000, max_nominal_cells=10000000000000)
PINS = {
    'fixed_palette_v1.py': '8d4c09e1977302fd89454f1ab6d8b752d475c0a1a318ddcedac3f434518635fc',
    'kernel_data_v1.py': '7fc693a12fca8940e95fa7d49ce0982094d03efdfda32d23d839fbe52833596f',
    'raw_kernel_circuit_v1.py': '493e903c688e7aa5a57b5e4eaa4630182bc0bd42245685f3f58cf548d93c089d',
    'raw_kernel_circuit_v2.py': 'a38aa4f2415965e894ce6b6764b0fb5be166f10259b0e12664b11780604f99cb',
    'raw_kernel_circuit_v3.py': '921dd80dfff1db388a8d36b7e8ae93df5cba33dfc0a01917f15a178d86b7593f',
    'raw_fol_checker_v1.py': '831727d9a9ef0e0d4c37a480921b9b4787ad5f3e009f21877e9a36a9f01071c2',
    'ribbon_checker_v3.py': 'e346951922cfe71366f6c31b474c77955a51715eb3e043ff053c169dc8b0adbd',
}
_MODULES = None


class BindingError(ValueError):
    pass


class ResourceRefusal(ValueError):
    pass


def _need(condition, message):
    if not condition:
        raise BindingError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def source_pins():
    result = {}
    for name, expected in PINS.items():
        path = ROOT/'reference/upstream'/name
        raw = path.read_bytes()
        _need(hashlib.sha256(raw).hexdigest() == expected, 'UPSTREAM_SOURCE_CHANGED:'+name)
        result['reference/upstream/'+name] = dict(bytes=len(raw), sha256=expected)
    return result


def _modules():
    global _MODULES
    source_pins()
    if _MODULES is not None:
        return _MODULES
    names = ('fixed_palette_v1', 'kernel_data_v1', 'raw_kernel_circuit_v1',
             'raw_kernel_circuit_v2', 'raw_kernel_circuit_v3')
    missing = object()
    old = {name: sys.modules.get(name, missing) for name in names}
    loaded = {}
    try:
        for name in names:
            spec = importlib.util.spec_from_file_location(name, ROOT/'reference/upstream'/(name+'.py'))
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            loaded[name] = module
    finally:
        for name, value in old.items():
            if value is missing:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value
    _MODULES = dict(fp=loaded['fixed_palette_v1'], data=loaded['kernel_data_v1'],
                    kernel=loaded['raw_kernel_circuit_v3'])
    return _MODULES


def _stage(name, function):
    started = time.perf_counter()
    try:
        result = function()
    except Exception as error:
        if isinstance(error, (ResourceRefusal, MemoryError, RecursionError, TimeoutError, OSError)) or type(error).__name__ in ('ResourceLimit', 'EncodingError'):
            result = dict(status='UNKNOWN', reason=type(error).__name__+':'+str(error),
                scope='Encoding/construction resource or profile refusal, not nonprovability or an invalidity claim about the original checked proof.')
        elif isinstance(error, (BindingError, ValueError, TypeError, KeyError, IndexError, AssertionError)):
            result = dict(status='REJECTED_INPUT', reason=type(error).__name__+':'+str(error))
        else:
            raise
    result.update(schema='Proof-backend-stage-v1', stage=name, version=VERSION,
                  seconds=time.perf_counter()-started)
    return result


def _bounds(bounds):
    _need(type(bounds) is dict and set(bounds) == set(KERNEL_CAPS), 'EXACT_BOUNDS_FIELDS')
    for name, maximum in KERNEL_CAPS.items():
        minimum = 2 if name in ('nodes', 'arity') else 1 if name in ('variables', 'lines') else 0
        _need(type(bounds[name]) is int and bounds[name] >= minimum, 'BOUND_TYPE_OR_RANGE:'+name)
        if bounds[name] > maximum:
            raise ResourceRefusal('UNCHANGED_KERNEL_CAP:'+name)
    return dict(bounds)


def _resources(resources):
    _need(type(resources) is dict and set(resources) == set(DEFAULT_RESOURCES), 'EXACT_RESOURCE_FIELDS')
    for key, value in resources.items():
        _need(type(value) is int and value > 0, 'POSITIVE_NATIVE_RESOURCE_CAP:'+key)
    _need(resources['max_nand_gates'] <= 2000000, 'UNCHANGED_COMPILER_HAS_HARD_CAP_2M')
    return dict(resources)


def _normalize(ast):
    """Explicit data-only human and/or abbreviations; no logical oracle."""
    _need(type(ast) is list and ast and type(ast[0]) is str, 'LITERAL_AST_REQUIRED')
    tag = ast[0]
    if tag == 'var':
        _need(len(ast) == 2 and type(ast[1]) is str, 'VARIABLE_AST')
        return list(ast)
    if tag in ('fun', 'pred'):
        _need(len(ast) == 3 and type(ast[1]) is str and type(ast[2]) is list, 'APPLICATION_AST')
        return [tag, ast[1], [_normalize(child) for child in ast[2]]]
    if tag in ('eq', 'imp', 'and', 'or'):
        _need(len(ast) == 3, 'BINARY_AST')
        a, b = _normalize(ast[1]), _normalize(ast[2])
        if tag == 'and':
            return ['not', ['imp', a, ['not', b]]]
        if tag == 'or':
            return ['imp', ['not', a], b]
        return [tag, a, b]
    if tag == 'all':
        _need(len(ast) == 3 and type(ast[1]) is str, 'UNIVERSAL_AST')
        return [tag, ast[1], _normalize(ast[2])]
    if tag == 'not':
        _need(len(ast) == 2, 'NEGATION_AST')
        return [tag, _normalize(ast[1])]
    _need(tag == 'bot' and len(ast) == 1, 'UNSUPPORTED_RAW_KERNEL_AST')
    return ['bot']


def _normalized_statement(statement):
    theory = copy.deepcopy(statement['theory'])
    theory['axioms'] = {name: _normalize(formula) for name, formula in theory['axioms'].items()}
    return dict(theory=theory, goal=_normalize(statement['goal']))


def _variables(compiled):
    """Derive the name pool from the whole declared basis/zero schemas only."""
    result = set()

    def visit(value):
        if type(value) is dict:
            for child in value.values():
                visit(child)
        elif type(value) is list:
            if value and value[0] in ('var', 'all'):
                _need(len(value) >= 2 and type(value[1]) is str and value[1], 'DECLARED_VARIABLE_NAME')
                result.add(value[1])
            for child in value:
                visit(child)
    for key in ('theory', 'goal', 'logical_basis', 'zero_instances'):
        _need(key in compiled, 'ORIGINAL_COMPILED_FIELD_REQUIRED:'+key)
        visit(compiled[key])
    return sorted(result)


def prepare(original_compiled, actual_selected_nativeproof, *, bounds=None,
            resource_limits=None, provenance=None):
    """Prepare problem-only raw pins, retaining the exact searched line list.

    The supplied proof is data from the separately audited native decoder.
    Its origin and validity require upstream receipts; this adapter does not
    generate, shorten, deduplicate, reorder or pad that proof.
    """
    def run():
        b = _bounds(DEFAULT_BOUNDS if bounds is None else bounds)
        limits = _resources(DEFAULT_RESOURCES if resource_limits is None else resource_limits)
        _need(type(original_compiled) is dict, 'ORIGINAL_COMPILED_OBJECT')
        theory = copy.deepcopy(original_compiled['theory'])
        _need(type(theory) is dict and set(theory) == {'functions', 'predicates', 'axioms'},
              'EXACT_ORIGINAL_THEORY_SIGNATURE_AND_AXIOMS')
        statement = dict(theory=theory, goal=copy.deepcopy(original_compiled['goal']))
        proof = actual_selected_nativeproof.get('lines') if type(actual_selected_nativeproof) is dict else actual_selected_nativeproof
        _need(type(proof) is list and proof, 'ACTUAL_NATIVE_LINE_LIST_REQUIRED')
        if len(proof) != b['lines']:
            raise ResourceRefusal('EXACT_LINE_BOUND_NO_PADDING:'+str(len(proof)))
        normalized = _normalized_statement(statement)
        _need(canonical(_normalize(proof[-1]['formula'])) == canonical(normalized['goal']),
              'ACTUAL_PROOF_FINAL_FORMULA_ORIGINAL_GOAL_BINDING')
        variables = _variables(original_compiled)
        if len(variables) > b['variables']:
            raise ResourceRefusal('DECLARED_VARIABLE_POOL_BOUND')
        for key in ('functions', 'predicates', 'axioms'):
            if len(theory[key]) > b[key]:
                raise ResourceRefusal('ORIGINAL_SIGNATURE_OR_AXIOM_BOUND:'+key)
        encoding_theory = dict(copy.deepcopy(theory), variables=variables)
        data = _modules()['data']
        pins, metadata = data.build_problem(b, encoding_theory, statement['goal'])
        return dict(status='PREPARED', bounds=b, resource_limits=limits,
            original_statement=statement, encoding_theory=encoding_theory, goal=statement['goal'],
            proof=copy.deepcopy(proof), problem_metadata=metadata, pins=pins,
            original_compiled_sha256=digest(original_compiled), original_statement_sha256=digest(statement),
            normalized_original_statement=normalized, normalized_statement_sha256=digest(normalized),
            original_proof_sha256=digest(proof), pins_sha256=digest(pins),
            normalization=dict(schema='Explicit-human-to-raw-FOL-abbreviations-v1',
                changed=canonical(statement) != canonical(normalized),
                rules=dict(and_abbreviation='NOT(A IMP NOT B)', or_abbreviation='(NOT A) IMP B'),
                scope='The original human AST/statement hash remains authoritative; raw syntax uses these explicit abbreviations. No silent claim of literal AST identity.'),
            provenance=copy.deepcopy(provenance) if provenance is not None else {},
            source_pins=source_pins(), metrics=dict(problem_prefix_nodes=len(metadata['node_prefix']),
                problem_pin_bits=len(pins), original_proof_lines=len(proof), declared_variables=len(variables)),
            scope='Problem-only statement/signature/closure pins; all remaining proof/syntax/substitution data free. Preparation is not logical verification, provenance admission or new proof search.')
    return _stage('prepare', run)


def _prepared(prepared):
    _need(prepared['status'] == 'PREPARED', 'PREPARED_PACKET_REQUIRED')
    _bounds(prepared['bounds'])
    _resources(prepared['resource_limits'])
    statement = prepared['original_statement']
    _need(digest(statement) == prepared['original_statement_sha256'] and
          digest(prepared['proof']) == prepared['original_proof_sha256'], 'ORIGINAL_STATEMENT_OR_PROOF_HASH')
    encoding = prepared['encoding_theory']
    _need(canonical({key: value for key, value in encoding.items() if key != 'variables'}) ==
          canonical(statement['theory']) and canonical(prepared['goal']) == canonical(statement['goal']),
          'ENCODING_ADDS_ONLY_VARIABLE_NAME_METADATA')
    normalized = _normalized_statement(statement)
    _need(canonical(normalized) == canonical(prepared['normalized_original_statement']) and
          digest(normalized) == prepared['normalized_statement_sha256'], 'EXPLICIT_NORMALIZATION_BINDING')
    modules = _modules()
    pins, metadata = modules['data'].build_problem(prepared['bounds'], encoding, statement['goal'])
    _need(canonical(pins) == canonical(prepared['pins']) and digest(pins) == prepared['pins_sha256'] and
          canonical(metadata) == canonical(prepared['problem_metadata']), 'RECONSTRUCTED_PROBLEM_ONLY_PINS')
    return modules


def compile_backend(prepared):
    """Compile the unchanged generic kernel using only frozen problem pins."""
    def run():
        modules = _prepared(prepared)
        started = time.perf_counter()
        circuit, metadata = modules['kernel'].compile_kernel(prepared['bounds'], prepared['pins'])
        compile_seconds = time.perf_counter()-started
        inputs, gates = len(circuit['inputs']), len(circuit['gates'])
        limits = prepared['resource_limits']
        if inputs > limits['max_inputs'] or gates > limits['max_nand_gates']:
            raise ResourceRefusal('COMPLETE_CIRCUIT_SIZE_CAP:'+str(dict(inputs=inputs, gates=gates)))
        nominal = (inputs+gates)*gates
        if nominal > limits['max_nominal_cells']:
            raise ResourceRefusal('NOMINAL_GRID_CELL_CAP:'+str(nominal))
        palette = modules['fp'].palette()
        return dict(status='COMPILED', prepared_sha256=digest(prepared),
            original_statement_sha256=prepared['original_statement_sha256'],
            circuit=circuit, metadata=metadata, palette=palette,
            circuit_sha256=digest(circuit), metadata_sha256=digest(metadata), palette_sha256=digest(palette),
            metrics=dict(compile_seconds=compile_seconds, inputs=inputs, gates=gates,
                nominal_grid_width=inputs+gates, nominal_grid_height=gates, nominal_grid_cells=nominal,
                literal_cells_expanded=0, fixed_input_bits=sum(i['value'] is not None for i in circuit['inputs'])),
            scope='Generic raw11rule checker compiled before witness encoding. No producer admission catalogue, proof search, ribbon construction or primitive Wang search.')
    return _stage('compile_backend', run)


def _backend(prepared, backend):
    modules = _prepared(prepared)
    _need(backend['status'] == 'COMPILED' and backend['prepared_sha256'] == digest(prepared) and
          backend['original_statement_sha256'] == prepared['original_statement_sha256'], 'BACKEND_PREPARATION_BINDING')
    _need(digest(backend['circuit']) == backend['circuit_sha256'] and
          digest(backend['metadata']) == backend['metadata_sha256'] and
          digest(backend['palette']) == backend['palette_sha256'], 'BACKEND_CONTENT_HASHES')
    _need(canonical(backend['palette']) == canonical(modules['fp'].palette()), 'UNCHANGED_FIXED100_PALETTE')
    _need(canonical(backend['circuit']['inputs']) == canonical(backend['metadata']['inputs']) and
          backend['metadata']['bounds'] == prepared['bounds'], 'CIRCUIT_METADATA_INPUT_BINDING')
    seen = set()
    for index, item in enumerate(backend['circuit']['inputs']):
        name, value = item['name'], item['value']
        _need(name not in seen, 'DUPLICATE_CIRCUIT_INPUT_NAME')
        seen.add(name)
        expected = index if index < 2 else prepared['pins'].get(name)
        _need(name == ('zero', 'one')[index] if index < 2 else True, 'CONSTANT_INPUT_NAMES')
        _need(type(value) is int and value in (0, 1) if value is not None else expected is None,
              'EXACT_FIXED_INPUT_BIT_TYPE')
        _need(value == expected, 'NO_WITNESS_DEPENDENT_FIXED_INPUT:'+name)
    _need(set(prepared['pins']) <= seen, 'EVERY_PROBLEM_PIN_HAS_AN_INPUT')
    return modules


def build_bits(prepared, backend):
    """Encode exactly the supplied proof after the checker circuit is frozen."""
    def run():
        modules = _backend(prepared, backend)
        started = time.perf_counter()
        certificate = modules['data'].build_witness(prepared['bounds'], prepared['problem_metadata'], prepared['proof'])
        bits = modules['data'].encode_bits(prepared['bounds'], certificate,
                                         dict(backend['metadata'], pins=prepared['pins']))
        return dict(status='ENCODED', prepared_sha256=digest(prepared),
            original_statement_sha256=prepared['original_statement_sha256'],
            original_proof_sha256=prepared['original_proof_sha256'],
            circuit_sha256=backend['circuit_sha256'], raw_certificate=certificate, input_bits=bits,
            raw_certificate_sha256=digest(certificate), input_bits_sha256=digest(bits),
            metrics=dict(encoding_seconds=time.perf_counter()-started, input_bits=len(bits),
                raw_nodes=len(certificate['nodes']), raw_lines=len(certificate['proof']),
                substitution_tasks=len(certificate['substitutions'])),
            scope='Data encoding only; exact original line list retained. Independent raw kernel and inverse common-statement/bit-roundtrip checks remain required.')
    return _stage('build_bits', run)


def build_ribbon(prepared, backend, encoded):
    """Evaluate the encoded bits, then construct the unchanged FP ribbon form.

    This performs two circuit evaluations: one explicit evaluation and the
    unchanged certificate builder's internal evaluation. Costs include both.
    The nominal large rectangle is not expanded or primitively searched.
    """
    def run():
        modules = _backend(prepared, backend)
        _need(encoded['status'] == 'ENCODED' and encoded['prepared_sha256'] == digest(prepared) and
              encoded['circuit_sha256'] == backend['circuit_sha256'] and
              encoded['original_statement_sha256'] == prepared['original_statement_sha256'] and
              encoded['original_proof_sha256'] == prepared['original_proof_sha256'], 'ENCODED_PACKET_BINDINGS')
        _need(digest(encoded['raw_certificate']) == encoded['raw_certificate_sha256'] and
              digest(encoded['input_bits']) == encoded['input_bits_sha256'], 'RAW_CERTIFICATE_OR_BITS_HASH')
        expected = modules['data'].encode_bits(prepared['bounds'], encoded['raw_certificate'],
                                             dict(backend['metadata'], pins=prepared['pins']))
        _need(expected == encoded['input_bits'], 'ENCODED_CERTIFICATE_BIT_ALIGNMENT')
        circuit, inputs = backend['circuit'], encoded['input_bits']
        if len(circuit['gates']) > prepared['resource_limits']['max_ribbon_rows']:
            raise ResourceRefusal('RIBBON_ROW_CONSTRUCTION_CAP')
        started = time.perf_counter()
        gates, accepted = modules['fp'].evaluate(circuit, inputs)
        evaluation_seconds = time.perf_counter()-started
        if accepted != 1:
            return dict(status='CIRCUIT_REJECTED', circuit_acceptance_bit=accepted,
                gate_bits_sha256=digest(gates), metrics=dict(evaluation_seconds=evaluation_seconds, gates=len(gates)),
                scope='The supplied encoding was rejected by the raw-checker circuit; original native proof validity must be assessed separately.')
        started = time.perf_counter()
        ribbon = modules['fp'].certificate(circuit, inputs, backend['palette'])
        ribbon_seconds = time.perf_counter()-started
        return dict(status='CERTIFICATE_BUILT', prepared_sha256=digest(prepared),
            original_statement_sha256=prepared['original_statement_sha256'],
            circuit_sha256=backend['circuit_sha256'], palette_sha256=backend['palette_sha256'],
            raw_certificate_sha256=encoded['raw_certificate_sha256'], input_bits_sha256=encoded['input_bits_sha256'],
            gate_bits=gates, gate_bits_sha256=digest(gates), circuit_acceptance_bit=accepted,
            ribbon=ribbon, ribbon_sha256=digest(ribbon),
            metrics=dict(evaluation_seconds=evaluation_seconds, ribbon_seconds=ribbon_seconds,
                circuit_evaluations=2, gates=len(gates), ribbon_rows=len(ribbon['rows']),
                nominal_grid_cells=(len(inputs)+len(gates))*len(gates), literal_cells_expanded=0),
            scope='Constructed compressed fixed100palette certificate from an actual proof encoding; independent raw/inverse/ribbon checks still required. No new proof search, primitive Wang search, literal expansion or speed claim.')
    return _stage('build_ribbon', run)
