"""Post-positive checks of actual arithmetic raw data; no baseline/search rerun.

Source-only until Root review/execution. Every mutated input is persisted before
assurance. Original circuit/pins are immutable; an extra supplied pin tests the
decoder boundary, not a claim that the old circuit checks its own pin metadata.
"""
import copy
import importlib.util
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

def main():
    started=time.perf_counter();D=module('frozen_join_driver','source/run_join_v1.py')
    assert not (ROOT/'review/counterchecks-invocation-v1.json').exists()
    protocol=None
    try:
        original=D.read('data/arithmetic-protocol-v1.json');D.unchanged(original)
        runtime=original['python'];assert D.pin(Path(runtime['path']))=={k:runtime[k] for k in ('bytes','sha256')}
        master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
        assert D.pin(master)==D.pin(ROOT/'reference/basic-tiling-algorithm.md')
        protocol=dict(schema='BJ-post-positive-counterchecks-protocol-v1',phase='counterchecks',
            pins={**original['pins'],'review/join_counterchecks_v1.py':D.pin(Path(__file__))},
            python=runtime,decoder_limits=original['decoder_limits'],
            controls=['actual-ui-root-active-omitted','actual-mp-future-reference','actual-unlisted-rule11','extra-known-proof-pin'],
            scope='Post-positive controls motivated by this actual joined proof, not held-out search. Same original circuit and exact12-line certificate; no compilation, search or ribbon/baseline reconstruction.')
        protocol_ref=D.save('data/counterchecks-protocol-v1.json',protocol)
        result=D.read('data/arithmetic-results-v1.json');assert result['status']=='VERIFIED_COMPRESSED_BACKEND_JOIN'
        artifacts=result['record']['artifacts']
        objects={}
        for label in ('prepare','compile','encode'):
            ref=artifacts[label];assert D.pin(ROOT/ref['path'])=={k:ref[k] for k in ('bytes','sha256')}
            objects[label]=D.read(ref['path'])
        prepared,backend,encoded=(objects[k] for k in ('prepare','compile','encode'))
        A=module('frozen_backend_adapter','source/backend_join_v1.py')
        inverse=module('independent_inverse','reference/raw_input_decoder_v1.py')
        raw_checker=module('independent_raw_checker','reference/upstream/raw_fol_checker_v1.py')
        native=module('independent_named_checker','reference/native_fol_checker_v1.py')
        helpers=A._modules();circuit=backend['circuit'];bounds=prepared['bounds'];base=encoded['raw_certificate']
        assert D.sha(circuit)==backend['circuit_sha256'] and D.sha(base)==encoded['raw_certificate_sha256']
        ui_line=next(i for i,row in enumerate(base['proof']) if row['rule']==3)
        task=base['proof'][ui_line]['aux0'];root=base['substitutions'][task]['source']
        mp_line=next(i for i,row in enumerate(base['proof']) if row['rule']==1)
        free=next(i for i,row in enumerate(circuit['inputs']) if row['value'] is None and row['name'].startswith('line.'))
        records=[]
        for cid in protocol['controls']:
            case_started=time.perf_counter();raw=copy.deepcopy(base);inputs=copy.deepcopy(circuit['inputs'])
            if cid=='actual-ui-root-active-omitted':
                assert raw['substitutions'][task]['active'][root]==1
                raw['substitutions'][task]['active'][root]=0
                change=dict(ui_line=ui_line,task=task,source_node=root,field='active[source]',before=1,after=0)
                expected=dict(raw='REJECTED',decoder='VERIFIED',native='VERIFIED',circuit=0)
            elif cid=='actual-mp-future-reference':
                before=raw['proof'][mp_line]['ref0'];raw['proof'][mp_line]['ref0']=mp_line
                change=dict(proof_line=mp_line,field='ref0',before=before,after=mp_line)
                expected=dict(raw='REJECTED',decoder='VERIFIED',native='REJECTED',circuit=0)
            elif cid=='actual-unlisted-rule11':
                before=raw['proof'][0]['rule'];raw['proof'][0]['rule']=11
                change=dict(proof_line=0,field='rule',before=before,after=11)
                expected=dict(raw='REJECTED',decoder='REJECTED',native='NOT_APPLICABLE',circuit=0)
            else:
                assert cid=='extra-known-proof-pin' and inputs[free]['value'] is None
                inputs[free]['value']=encoded['input_bits'][free]
                change=dict(input_index=free,name=inputs[free]['name'],field='value',before=None,after=inputs[free]['value'])
                expected=dict(raw='VERIFIED',decoder='REJECTED',native='NOT_APPLICABLE',circuit=1)
            # Encode only the mutated raw data into the ORIGINAL input layout.
            # The extra-pin control deliberately changes the decoder argument,
            # never the frozen circuit or its constant-folded gate program.
            bits=helpers['data'].encode_bits(bounds,raw,circuit['inputs'])
            packet=dict(id=cid,bounds=bounds,raw_certificate=raw,input_bits=bits,circuit_inputs=inputs,
                original_statement=prepared['original_statement'],variables=prepared['encoding_theory']['variables'],
                change=change,expected=expected,evaluated_original_circuit=artifacts['compile'],
                original_circuit_sha256=backend['circuit_sha256'])
            source_ref=D.save('data/counterchecks/'+cid+'-input.json.gz',packet)
            raw_check=raw_checker.check(bounds,raw)
            raw_ref=D.save('data/counterchecks/'+cid+'-raw-check.json',raw_check)
            decoded=inverse.decode(bounds,inputs,bits,prepared['original_statement'],
                variables=prepared['encoding_theory']['variables'],**protocol['decoder_limits'])
            inverse_ref=D.save('data/counterchecks/'+cid+'-inverse-check.json',decoded)
            if decoded['status']=='VERIFIED':
                assert D.wire(decoded['raw_certificate'])==D.wire(raw)
                human=decoded['human'];named=native.check(human['theory'],human['proof'],human['goal'],D.KERNEL_LIMITS)
            else:named=dict(status='NOT_APPLICABLE',reason='NO_ACCEPTED_NAMED_CODEC_OUTPUT')
            named_ref=D.save('data/counterchecks/'+cid+'-native-check.json',named)
            gates,accept=helpers['fp'].evaluate(circuit,bits)
            evaluation=dict(status='EVALUATED_ORIGINAL_FROZEN_CIRCUIT',acceptance_bit=accept,
                circuit_sha256=backend['circuit_sha256'],input_bits_sha256=D.sha(bits),
                gate_bits=gates,gate_bits_sha256=D.sha(gates),
                boundary_scope='Original frozen NAND program. Extra supplied known-pin metadata is outside its Boolean acceptance predicate.')
            evaluation_ref=D.save('data/counterchecks/'+cid+'-circuit-evaluation.json.gz',evaluation)
            actual=dict(raw=raw_check['status'],decoder=decoded['status'],native=named['status'],circuit=accept)
            record=dict(id=cid,status='VERIFIED' if actual==expected else 'REJECTED',expected=expected,actual=actual,
                input=source_ref,raw_check=raw_ref,inverse_check=inverse_ref,native_check=named_ref,
                circuit_evaluation=evaluation_ref,seconds=time.perf_counter()-case_started)
            D.save('data/counterchecks/'+cid+'-record.json',record);records.append(record)
            print(D.wire(dict(id=cid,status=record['status'],actual=actual)).decode().strip(),flush=True)
            assert record['status']=='VERIFIED',record
        for name,p in protocol['pins'].items():assert D.pin(ROOT/name)==p,name
        assert D.pin(Path(runtime['path']))=={k:runtime[k] for k in ('bytes','sha256')}
        assert D.pin(master)==D.pin(ROOT/'reference/basic-tiling-algorithm.md')
        D.save('data/counterchecks-results-v1.json',dict(schema='BJ-post-positive-counterchecks-v1',
            status='VERIFIED_POST_POSITIVE_COUNTERCHECKS',protocol=protocol_ref,records=records,
            original_arithmetic_result=dict(path='data/arithmetic-results-v1.json',**D.pin(ROOT/'data/arithmetic-results-v1.json')),
            sources_runtime_master_unchanged=True,
            scope='Actual proof counterchecks only. Codec success does not validate active maps; the raw logical kernel and original circuit reject their invalidity. Added proof-pin metadata is rejected by the decoder, while the original circuit remains accepting.'))
    finally:
        D.save('review/counterchecks-invocation-v1.json',dict(status='FAILED' if sys.exc_info()[0] else 'COMPLETE',phase='counterchecks',
            main_seconds=time.perf_counter()-started,platform=sys.platform,ru_maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            scope='Post-positive actual-input read/encode/logical/circuit checks and preceding persistence; no compilation, proof/tile search or baseline ribbon rebuild.'))
if __name__=='__main__':main()
