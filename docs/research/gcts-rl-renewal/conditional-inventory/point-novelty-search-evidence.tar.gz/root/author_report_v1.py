"""Author a passive report builder from the prior frozen report template."""
from pathlib import Path

B=Path(__file__).resolve().parent.parent
prior=B.parent/'gcts-novelty-proof-pilot-20261020'
s=(prior/'root/build_novel_report_v1.py').read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace('pointrows=[];ordering=[]','pointrows=[];ordering=[];point_clusters=[]')
replace("ordering.append(dict(case_id=spec['id']", "ordering.append(dict(whole_job_admitted=admitted,case_id=spec['id']")
replace("if not admitted:status='NOT ADMITTED: the whole case failed its memory gate. This saved S0 observation has accepted Host/point-region/Native checker records, but is not an admitted D10 result. The earlier byte-point experiment independently admitted its S0 proof.'", "if not admitted:status='NOT ADMITTED: the complete positive case failed its whole-memory gate. This saved '+a['id']+' observation has accepted Host/point-region/Native checker records but is diagnostic only. The earlier D12 experiment independently admitted the same S0/SC certificates; that historical qualification does not admit this D13 job.'")
replace('    take_donors=admitted and not donors', '''    if admitted:
        reviewed=read(B/'review-C/typed-point-novelty-actual-scientific-review-v1.json')
        for a in c['arms']:
            if a['method']!='point' or not a['cluster_enabled']:continue
            for event_index,event in enumerate(a['search']['trace']):
                if event['event']!='cluster_proposals':continue
                for packet_hint in event['proposals']:
                    joins=[j for j in reviewed['point_packet_member_literal_joins'] if j['case_id']==spec['id'] and j['arm']==a['id'] and j['packet_trace_index']==event_index and j['instance']==packet_hint['instance']]
                    assert len(joins)==1
                    join=joins[0]
                    assert join['resource_admitted'] and join['members']==packet_hint['members']
                    assert join['prefix_rows_before']==packet_hint['prefix_rows'] and join['prefix_rows_after']==len(packet_hint['checked_primitive_proof'])
                    assert packet_hint['host_check']['accepted'] and packet_hint['checked_primitive_proof'][packet_hint['prefix_rows']:]==packet_hint['commands']
                    rows=[]
                    for row_index,command in enumerate(packet_hint['checked_primitive_proof']):
                        members=[bykey[tuple(k)] for k in packet_hint['members'] if k[0]==row_index]
                        indices=[tile(p,'Qualified local '+a['id']+' event '+str(event_index)+' row '+str(row_index+1)+' '+p['metadata']['kind']) for p in sorted(members,key=lambda p:p['key'][1])]
                        assert all(tiles[i]['command']==command for i in indices)
                        rows.append(dict(row=row_index+1,command=command,tile_indices=indices,new_extension=row_index>=packet_hint['prefix_rows']))
                    point_clusters.append(dict(title=a['id']+' — '+packet_hint['instance']+' — prefix '+str(packet_hint['prefix_rows'])+' to '+str(len(rows)),arm=a['id'],case_id=spec['id'],spec=dict(theory=spec['theory'],target=packet_hint['result_formula']),recipient_target=spec['target'],proof=packet_hint['checked_primitive_proof'],tile_rows=rows,packet=packet_hint,literal_member_join=join,packet_trace_index=event_index,completion_trace_index=join['all_members_selected_at'],whole_job_admitted=True,source=pin(path),status='Qualified negative-case local branch extension. The saved Host check accepted this prefix; both nominated command and guard members later coexist on this recorded branch. This is no completed recipient proof, no Native-admitted macro and no measured search advantage.'))
    take_donors=admitted and not donors''')
replace("schema='Root-passive-novel-cluster-search-assessment-v1'","schema='Root-passive-point-novelty-search-assessment-v1'")
replace("B.parent/'gcts-ordering-proof-pilot-20261020/root/passive-actual-assessment-v1.json'","B.parent/'gcts-novelty-proof-pilot-20261020/root/passive-actual-assessment-v1.json'")
start=s.index("assert summary['accepted_recipient_proofs']==2")
end=s.index('symbolic_comparison=[]',start)
s=s[:start]+'''assert summary['accepted_recipient_proofs']==0
assert summary['resource_admitted_case_jobs']==1 and summary['resource_rejected_case_jobs']==2
assert [a['arm'] for a in totals[0]['checker_accepted_candidates']]==['S0','SC']
assert [a['rows'] for a in totals[0]['checker_accepted_candidates']]==[14,14]
assert proofs[0]['proof']==proofs[1]['proof'] and not proofs[0]['whole_job_admitted'] and not proofs[1]['whole_job_admitted']
assert len(pointrows)==12 and all(p['status']=='unknown_search_budget' for p in pointrows)
assert summary['searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['point_placement_attempts']==293 and summary['complete_point_domain_audits']==24
assert summary['admitted_point_placement_attempts']==86 and summary['admitted_complete_point_domain_audits']==8
assert summary['admitted_searches_returned']==6
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==16
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==2
assert len(point_clusters)==4 and len(tiles)==70
summary.update(ordering_only_policy=True,exact_prefix_abstention=True,common_point_formula_novelty_order=True,registered_ground_blocks=False,successful_ordering_proposals_observed=16,point_packets_observed=8,point_packets_qualified=4,qualified_local_member_completions=4,literal_symbolic_order_changes=2,accepted_recipient_certificates=0,distinct_recipient_statements=0,new_theorem=False,admitted_word_controls=48,observed_word_controls=144)
save(B/'root/passive-actual-assessment-v1.json',summary)
''' +s[end:]
replace("B.parent/'gcts-ordering-proof-pilot-20261020/actual'","B.parent/'gcts-novelty-proof-pilot-20261020/actual'")
replace("symbolic_comparison.append(dict(title=", "symbolic_comparison.append(dict(current_admitted=next(t['resource_candidate_accepted'] for t in totals if t['case_id']==spec['id']),title=")
start=s.index('headline=')
end=s.index('\ndef prose_spacing',start)
s=s[:start]+'''headline="Point hints complete local extensions; the positive jobs fail whole-memory qualification."
conclusion="The admitted negative control contains four point hint packets whose command and guard members are later placed: two local steps repeated across P01 and P11. No target proof is found. Both positive jobs return complete records but exceed the unchanged whole-memory gate, so their observations remain diagnostic. Useful GCTS or RL proof-search advantage remains unproved."
assessment=[
    'All four point arms share one general branch preference: novel hinted formulas, novel ordinary formulas, repeated hinted formulas, repeated ordinary formulas. Ordering is stable inside each tier. Forced choices, the Graph-selected point, every original alternative and exact rollback remain unchanged. No hint becomes a proof rule.',
    'The admitted negative job supplies four local point packets. Each expands one primitive modus-ponens command and its guard, with actual earlier-row receptors. Both members later coexist before backtracking, growing the primitive prefix from four to five or six to seven rows. These are two local mathematical steps repeated across two arms, not four theorems.',
    'Earlier D12 point calls supplied no packets. This cohort shows that the new shared point order can reach actual contexts where hints activate and their primitive members are selected. It does not isolate a useful causal advantage from cluster guidance: the primitive controls receive the same novelty heuristic, all point searches remain UNKNOWN, and only one whole job qualifies.',
    'Two positive jobs exceed the unchanged whole-job memory ceiling. Their 14-row S0/SC checker-accepted observations are diagnostic only. Earlier D12 qualified certificates remain unchanged, and cannot rescue this cohort. The three-case admitted comparison is incomplete.',
    'There are eighteen observed searches, 293 point placements, twenty-four audits and 144 word controls. Only the negative job qualifies: six searches, 86 placements, eight audits and 48 controls. No admitted recipient certificate is produced in this cohort.',
    'Whole memory includes worker, waited Native, custodian, observer and declared reserves. First/equality parent bounds individually pass, but their complete observer-plus-reserve totals exceed one GiB. Existing high-water readings do not identify the causal allocation phase; no memory phase profile was measured.',
    'Ground registry queries remain Native UNKNOWN, unadmitted and usable empty. Actual-context Host-checked primitive preferences are separate from registered inference blocks. No trained RL, new pruning rule, physical universal Wang bridge or broadly useful proof-search gain is established.',
    'The next step should address bounded memory ownership with unchanged logical semantics and resource gates, then repeat a separately reviewed matched cohort. A change needs fresh Sources, reviews and one-use plans. Current failed jobs will remain failed; no rerun or memory-limit relaxation is included here.',
    'The full program remains practical boundary tiling, hierarchical receptor and lemma families, learned proposal policies, automated arithmetic and symbolic Hilbert geometry, and honest conventional benchmarks. Turtle/Penrose plane constructions and the universal Wang bridge remain unfinished.'
]
next_path=B/'implementation-B/point-novelty-outcome-next-assessment-v1.json'
report=dict(schema='point-novelty-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='No D13 recipient certificate is admitted. The first two entries are explicitly diagnostic S0/SC 14-row observations from the memory-rejected positive job. The three elementary donor proofs come from the admitted negative job. For the qualified point-search progress, use the separate local-extension reader above.',cases=cases,proofs=proofs,point_clusters=point_clusters,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),symbolic_comparison=symbolic_comparison,ordering=ordering,assessment=assessment,next_assessment=read(next_path),next_assessment_source=pin(next_path),ordering_diagnostic_text='Point packets now reach real earlier-row receptors and their members are placed on the admitted negative branch. Positive jobs fail whole-memory admission. Proposal, activation, local member completion, a complete target proof and a useful measured advantage are separate milestones.',review_summary='Initial Source and whole-plan reviews preceded three serial cold jobs. Independent complete-record reviews classify two whole-memory failures and one admitted negative job. All eighteen bounded observations are retained, with only six searches qualified. Registry UNKNOWN, local Host checks, target proof checking and whole-job admission remain separate. No scientific replay occurred outside actuals.')
''' + s[end:]
replace("OUT/'novel-cluster-search-data.json'","OUT/'point-novelty-search-data.json'")
replace("OUT/'novel-cluster-search-engineering.json'","OUT/'point-novelty-search-engineering.json'")
replace("schema='novel-cluster-search-method-v1'","schema='point-novelty-search-method-v1'")
(B/'root/build_point_report_v1.py').write_text(s)
print('Authored passive complete-record report builder.')
