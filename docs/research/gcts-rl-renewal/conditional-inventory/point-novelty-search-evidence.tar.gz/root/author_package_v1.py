"""Author passive byte packaging and exact reader insertion."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
s=(B.parent/'gcts-novelty-proof-pilot-20261020/root/package_novel_report_v1.py').read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace("D11=B.parent/", "D12=B.parent/'gcts-novelty-proof-pilot-20261020'\nD11=B.parent/")
replace("PREFIX='novel-cluster-search'","PREFIX='point-novelty-search'")
replace("summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0","summary['resource_admitted_case_jobs']==1 and summary['resource_rejected_case_jobs']==2")
replace("summary['admitted_point_placement_attempts']==169 and summary['admitted_complete_point_domain_audits']==24","summary['admitted_point_placement_attempts']==86 and summary['admitted_complete_point_domain_audits']==8")
replace('typed-saturated-hint-','typed-point-novelty-')
replace('b92f5d1d1fd7a6c7959c70b4e9d57a337f39a1868f693d9d3b504143052d1514','522059cfb30e309138772748d9853f235576909077e1c738782398c80280c982')
start=s.index("insert=('")
end=s.index("offset=",start)
s=s[:start]+'''insert=('<section id="point-novelty-update" class="panel"><h2>Point hints reach local proof receptors</h2>'
        '<p><a href="point-novelty-search.html#local-clusters">Inspect the qualified local extensions, formulas, English and colored tiles</a>. '
        'The admitted negative case records four local packets whose members were later placed, representing two steps repeated across two arms. '
        'Both positive jobs fail the unchanged whole-memory gate. No target proof or useful GCTS/RL search advantage is established; all complete observations remain available with their admission scope.</p></section>\\n').encode()
''' +s[end:]
replace("before.index(b'<section id=\"cluster-ordering-update\"')", "before.index(b'<section id=\"novel-cluster-update\"')")
replace("schema='novel-cluster-reader-exact-insertion-v1'","schema='point-novelty-reader-exact-insertion-v1'")
replace("paths.update([D11/", "paths.update([D12/'implementation-B/proof_search_pilot_v10.py',D12/'implementation-B/API-v1.json',\n              D12/'implementation-B/handoff-v1.json',D12/'root/protocol-v1.json',\n              D12/'root/passive-actual-assessment-v1.json',D12/'root/initial-passive-actual-join-v1.json',\n              D12/'publication/novel-cluster-search-data.json',\n              P/'docs/research/gcts-rl-renewal/conditional-inventory/novel-cluster-search-manifest.json',\n              D11/")
replace("elif path.is_relative_to(D11):", "elif path.is_relative_to(D12):name='dependencies/D12/'+path.relative_to(D12).as_posix()\n    elif path==P/'docs/research/gcts-rl-renewal/conditional-inventory/novel-cluster-search-manifest.json':name='dependencies/D12/publication/novel-cluster-search-manifest.json'\n    elif path.is_relative_to(D11):")
replace("schema='novel-cluster-search-evidence-archive-v1'","schema='point-novelty-search-evidence-archive-v1'")
replace('resource_admitted_case_attempts=3,resource_rejected_case_attempts=0','resource_admitted_case_attempts=1,resource_rejected_case_attempts=2')
replace('admitted_searches=18','admitted_searches=6')
replace('admitted_point_placements=169,admitted_point_audits=24','admitted_point_placements=86,admitted_point_audits=8')
replace("qualified_recipient_certificates=2,distinct_recipient_statements=1,recipient_engine='S0 conventional and SC cluster-guided symbolic searches; exact same primitive proof'", "qualified_recipient_certificates=0,distinct_recipient_statements=0,diagnostic_checker_accepted_certificates=2,qualified_local_point_packets=4,recipient_engine='No admitted target certificate; S0/SC checker records belong to a rejected whole job'")
replace('scientific_comparison_complete=True','scientific_comparison_complete=False')
start=s.index("              scope='All three fresh D12")
end=s.index('\nmb=',start)
s=s[:start]+"""              scope='D13 has two memory-rejected jobs and one admitted negative case. All18 observed bounded arms return; only6searches86placements8audits48controls qualify. Four qualified local point packets complete their paired members on the saved branch, not the target. Registry UNKNOWN/unadmitted/usableempty. No new theorem, trainedRL or useful measured advantage. Full D13 Sources and complete actuals are included; historical D12 raw actuals remain in its prior published archive pinned by the included manifest. D12 qualification never rescues D13 failures. Original D8 L handoff is inherited provenance. B assessment is passive posthoc diagnosis; publication review is outside this snapshot.')"""+s[end:]
replace("schema='novel-cluster-archive-complete-byte-scan-v1'","schema='point-novelty-archive-complete-byte-scan-v1'")
replace("schema='novel-cluster-search-publication-manifest-v1'","schema='point-novelty-search-publication-manifest-v1'")
start=s.index("            conclusion='Three admitted jobs")
end=s.index('\nsave(D/',start)
s=s[:start]+"""            conclusion='Two whole-memory failures and one admitted negative case. Observed18searches293placements24audits144controls; qualified6/86/8/48. Four qualified point packets locally complete two primitive steps repeated across P01/P11. Zero admitted recipient proofs; positive S0/SC checker observations diagnostic only. No useful acceleration or trainedRL.')"""+s[end:]
(B/'root/package_point_report_v1.py').write_text(s)
v=(B.parent/'gcts-novelty-proof-pilot-20261020/root/verify_live_publication_v1.py').read_text().replace('gcts-novelty-proof-pilot-20261020','gcts-point-novelty-proof-pilot-20261020').replace('novel-cluster-','point-novelty-')
(B/'root/verify_live_publication_v1.py').write_text(v)
print('Authored passive package and full-body live verifier.')
