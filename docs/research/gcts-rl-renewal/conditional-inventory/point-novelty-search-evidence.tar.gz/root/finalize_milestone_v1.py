"""Terminal progress handoff from complete saved metadata only."""
from pathlib import Path
import hashlib,json,subprocess,sys
B=Path(__file__).resolve().parent.parent
P=B.parent/'gcts-batch-20261020/publisher'
def read(p):
    assert '.partial' not in p.name
    return json.loads(p.read_bytes())
def pin(p):
    raw=p.read_bytes()
    return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
commit=sys.argv[1]
for ref in ('HEAD','origin/main'):
    assert subprocess.check_output(['git','rev-parse',ref],cwd=P,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=P,text=True)
live=read(B/'root/full-live-body-verification-v1.json')
assert live['all_matched'] and live['normal_TLS'] and live['commit']==commit
for kind in ('local','live'):
    assert read(B/('root/'+kind+'-browser-QA-v1.json'))['all_passed']
pages=read(B/'root/pages-deployment-v1.json')
assert pages['status']=='completed' and pages['conclusion']=='success' and pages['headSha']==commit
pub=read(B/'publication-C/typed-publication-review-v1.json')
assert pub['review_passed'] and all(c['passed'] for c in pub['checks'])
s=read(B/'root/passive-actual-assessment-v1.json')
assert s['resource_admitted_case_jobs']==1 and s['resource_rejected_case_jobs']==2
assert s['accepted_recipient_certificates']==0 and not s['scientific_complete']
assert s['admitted_point_placement_attempts']==86 and s['admitted_complete_point_domain_audits']==8
receipt=dict(schema='D13-Root-terminal-progress-milestone-v1',classification='PROGRESS',
    whole_goal_complete=False,goal_remains_active=True,publication_commit=commit,
    live_url='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/point-novelty-search.html?v='+commit+'#local-clusters',
    evidence={name:pin(B/path) for name,path in {
        'scientific_assessment':'root/passive-actual-assessment-v1.json',
        'scientific_review':'review-C/typed-point-novelty-actual-scientific-review-v1.json',
        'resource_review':'verification-L/typed-point-novelty-resource-custody-review-v1.json',
        'publication_review':'publication-C/typed-publication-review-v1.json',
        'full_live_bytes':'root/full-live-body-verification-v1.json',
        'pages':'root/pages-deployment-v1.json',
        'live_browser_QA':'root/live-browser-QA-v1.json',
        'local_browser_QA':'root/local-browser-QA-v1.json',
        'posthoc_next_assessment':'implementation-B/point-novelty-outcome-next-assessment-v1.json'}.items()},
    remaining_once_grants=0,actual_case_jobs=3,all_actual_jobs_terminal=True,
    observed=dict(searches=18,point_placements=293,point_audits=24,word_controls=144,Native_queries=288,point_packets=8,checker_accepted_recipient_records=2),
    qualified=dict(case_ids=['pilot-fork-join-missing-Pa'],searches=6,point_placements=86,point_audits=8,word_controls=48,Native_queries=89,point_packets=4,local_member_completions=4,distinct_local_steps=2,recipient_certificates=0),
    registry_status='UNKNOWN / unadmitted / usable empty',ordering_only_instances=[7,11,7],
    new_theorem=False,trained_RL=False,useful_cluster_acceleration=False,
    scientific_calls_outside_actuals=0,partial_files_parsed=False,
    preserved='All old cohorts, grants and qualifications immutable. Failed D13 jobs remain failed. Primary research index/reader and .gcts-active untouched; eight own public paths only. Unrelated work preserved.',
    next_action='Assess bounded memory ownership from Source without changing logical semantics or resource gates. Any implementation and matched repetition require separately reviewed exact Sources, full plans and fresh one-use grants. No causal phase profile is claimed, no memory ceiling increase or current-job rescue, no fresh actual authorized by this handoff.',
    unresolved_full_program=['Practical fixed/movable boundary tiling and fair Turtle/Penrose plane growth',
        'General learned geometric failure markings and multiscale receptor families',
        'Reusable automatically acquired lemma families with held-out transfer',
        'Trained RL cluster proposals and honest conventional benchmarks',
        'Automated arithmetic and symbolic Hilbert geometry proof search',
        'Fixed universal Wang construction and physical certificate checking bridge'])
p=B/'root/Root-final-milestone-v1.json'
assert not p.exists()
p.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(pin(p)))
