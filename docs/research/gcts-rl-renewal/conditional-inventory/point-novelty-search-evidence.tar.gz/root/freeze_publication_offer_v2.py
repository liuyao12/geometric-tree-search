"""Pin the eight already packaged publication bodies for passive review."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
D=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
paths=sorted(D.glob('point-novelty-search*'))+[D/'reader.html']
assert len(paths)==8
offer=dict(schema='D13-frozen-publication-review-offer-v2',files=[pin(p) for p in paths],
    scientific_assessment=pin(B/'root/passive-actual-assessment-v1.json'),
    archive_scan=pin(B/'root/archive-scan-v1.json'),
    reader_delta=pin(B/'root/reader-publication-delta-v1.json'),
    posthoc_next_assessment=pin(B/'implementation-B/point-novelty-outcome-next-assessment-v1.json'),
    scope='Publication bytes, full archive member pins, literal proof/tile display and scope review only. Exactly eight own paths. No scientific imports, replay, helpers or probes; partial raw metadata only. Two whole-memory failures, one qualified negative job. Observed18/293/24/144 versus qualified6/86/8/48, zero qualified target certificates. Four qualified local packets are two steps repeated across two arms; full member joins/prefix growth, not target proofs or advantage. All current D13 complete actuals/Sources included; historical D12 raw remains in its separately pinned published archive. Browser QA separate.')
p=B/'root/publication-review-offer-v2.json'
p.write_text(json.dumps(offer,sort_keys=True,indent=2)+'\n')
print(json.dumps(pin(p)))
