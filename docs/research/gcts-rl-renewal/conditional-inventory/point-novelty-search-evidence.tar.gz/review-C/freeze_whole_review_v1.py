"""Independent passive complete metadata and Source/AST preflight only."""
from pathlib import Path
import ast
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-point-novelty-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'
R = D / 'root'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == row

offer_path = R / 'prospective-whole-offer-v1.json'
offer = read(offer_path)
assert pin(offer_path)['sha256'] == '3b4d1d87f13ab18de8eb3f0cfcdf4daa6d092052cb8aa2d3dc2670e4b37c8ba6'
assert pin(offer_path)['bytes'] == 24196
assert len(offer['files']) == len({r['path'] for r in offer['files']}) == 45
assert len(offer['plans']) == 3
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references'] + offer['initial_Source_reviews']:
    verify(row)
for field in ['scientific_calls', 'new_actuals', 'new_grants', 'old_grants_remaining']:
    assert offer[field] == 0
assert offer['expected_case_jobs'] == 3 and offer['expected_explicit_arm_outcomes'] == 18
protocol = read(offer['protocol']['path'])
api_path = D / 'implementation-B/API-v1.json'
api = read(api_path)
parent = read(offer['ordering_policy']['path'])
abstention = read(offer['abstention_policy']['path'])
old_protocol = read(OLD / 'root/protocol-v1.json')
assert offer['ordering_policy'] == api['policy'] == protocol['ordering_policy'] == abstention['parent_ordering_policy']
assert offer['abstention_policy'] == api['abstention_policy'] == protocol['abstention_policy']
assert offer['superseded_acquisition'] == parent['superseded_acquisition_document'] == protocol['superseded_acquisition']
assert protocol['explicit_override'] == parent['explicit_override'] == old_protocol['explicit_override']
assert parent['registry']['native_registry_required_for_ordering'] is False
assert abstention['successor'] == api['predecessor'] and api['entry']['sha256'] == '3ec6ff3b7acc8335b43c2dc366f6dddbd05c0f9bcfc3d899733999373d91afe6'
assert offer['point_ordering_policy'] == api['point_ordering_policy'] == protocol['point_ordering_policy']
point_policy = read(offer['point_ordering_policy']['path'])
assert point_policy['successor'] == api['entry'] and point_policy['predecessor'] == api['predecessor']
assert point_policy['inherited_policies'] == [api['policy'],api['abstention_policy']]
assert api['policy_lineage'] == point_policy['inherited_policies'] + [api['point_ordering_policy']]
assert protocol['limits'] == old_protocol['limits']
assert protocol['scientific_limits'] == old_protocol['scientific_limits'] == api['limits']
assert protocol['input'] == api['corpus'] == parent['logical_corpus']
assert protocol['input']['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
assert protocol['normative_references'] == offer['normative_references']
assert [r['sha256'] for r in offer['normative_references']] == ['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
assert offer['python']['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
sources = [Path(r['path']) for r in offer['files'] if r['path'].endswith('.py')]
assert len(sources) == len(offer['source_AST_checks']) == 33
assert {r['path'] for r in offer['source_AST_checks']} == set(map(str, sources))
assert all(r['AST_and_unused_compile'] is True for r in offer['source_AST_checks'])
for p in sources:
    tree = ast.parse(p.read_bytes(), filename=str(p))
    compile(tree, str(p), 'exec')
runtime = sorted((D / 'runtime').glob('*.py'))
names = ['case_worker_v1.py', 'run_case_once_v3.py', 'observe_case_once_v2.py', 'independent_countermodel_v1.py']
copied = runtime + [R / name for name in names]
assert len(runtime) == 28 and len(copied) == 32
baseline_path = R / 'baseline-copy-pins-v1.json'
baseline = read(baseline_path)
assert len(baseline['files']) == 32 and {r['target'] for r in baseline['files']} == set(map(str, copied))
for row in baseline['files']:
    before = Path(row['source'])
    after = Path(row['target'])
    assert before.is_relative_to(OLD) and before.relative_to(OLD) == after.relative_to(D)
    assert before.read_bytes() == after.read_bytes()
    assert pin(before)['sha256'] == pin(after)['sha256'] == row['sha256']
    assert pin(before)['bytes'] == pin(after)['bytes'] == row['bytes']
for field in ['model_source', 'verifier_source']:
    verify(api[field])
    assert (D / 'runtime' / Path(api[field]['path']).name).read_bytes() == Path(api[field]['path']).read_bytes()
expected_closure = set(map(str, copied)) | {api['entry']['path'], str(api_path), str(D/'implementation-B/handoff-v1.json'), offer['ordering_policy']['path'], offer['abstention_policy']['path'], offer['point_ordering_policy']['path'], offer['superseded_acquisition']['path'], api['corpus']['path'], offer['python']['path']}
native_rows = [r for r in offer['files'] if '/recovered/and-support/' in r['path']]
assert len(native_rows) == 4
expected_closure |= {r['path'] for r in native_rows}
assert expected_closure == {r['path'] for r in offer['files']}
doc = read(protocol['input']['path'])
assert [t['length'] for t in doc['tests']] == [14, 13, 14]
assert [t['length'] for t in doc['training']] == [3, 5, 5]
for row, spec in zip(offer['plans'], doc['tests'], strict=True):
    plan = read(row['path'])
    old_plan = read(OLD / 'root' / Path(row['path']).name)
    assert plan['case_id'] == spec['id'] and plan['schema'] == 'proof-search-case-once-plan-v1'
    assert plan['experiment'] == 'common-point-novelty-v1'
    assert plan['files'] == offer['files'] and plan['protocol'] == offer['protocol']
    for field in ['ordering_policy', 'abstention_policy', 'point_ordering_policy', 'superseded_acquisition']:
        assert plan[field] == offer[field]
    assert plan['limits'] == protocol['limits'] == old_plan['limits']
    assert plan['experiment_limits'] == protocol['scientific_limits'] == old_plan['experiment_limits']
    assert plan['modules'] == api['roles'] == old_plan['modules']
    assert plan['native'] == old_plan['native'] and plan['python'] == offer['python'] == old_plan['python']
    assert plan['input_path'] == protocol['input']['path'] == old_plan['input_path']
    assert plan['entry_path'] == api['entry']['path'] and plan['runtime_dir'] == str(D/'runtime')
    for field, name in [('worker_path', names[0]), ('runner_path', names[1]), ('observer_path', names[2]), ('control_path', names[3])]:
        assert plan[field] == str(R/name)
    assert plan['actual_dir'] == str(D/'actual'/spec['id'])
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
assert not list(R.glob('grant-*.json')) and not (R/'Root-preflight-v1.json').exists()
C_path = D/'review-C/typed-point-novelty-Source-review-v1.json'
L_path = D/'verification-L/typed-point-novelty-Source-ABI-review-v1.json'
assert pin(C_path)['sha256'] == '4a4fc720eba8979b0325aa80c3f3f3a8bbd19cb3220cdf7673de68280f2f6f47'
assert pin(L_path)['sha256'] == 'c3ed3a3f293d189df53f9d31656d0dd8fc00f20f2c205e72743aa90f20859297'
assert read(C_path)['review_passed'] is read(L_path)['review_passed'] is True
assert offer['initial_Source_reviews'] == [pin(C_path), pin(L_path)]
inherited_path = OLD/'review-C/typed-saturated-hint-whole-prospective-Source-review-v1.json'
assert pin(inherited_path)['sha256'] == '0303262999d47ed0d81df2806b9b8610fc873345f40ba5ddc145a92646559284'
original_L = BASE/'research-runs/gcts-word-point-proof-pilot-20261020/verification-L/handoff-v1.json'
assert pin(original_L)['sha256'] == '5cfa4cc5ed78ff1f762040c6c394375a87165c11416bebded0ce2233a97386c2'

checks = [
    ('exact-complete-closure-and-parser','All45 offered file pins, three plan pins, protocol, both normative masters and initial C/L reviews independently revalidated. Exact33 Sources AST parsed and unused compiled under pinned CPython without import/execution. Complete closure includes three policy generations and original acquisition/input/Native dependencies; no narrowed donor/case or unseen helper.'),
    ('unchanged-runtime-worker-parent-observer','All28 runtime and four worker/parent/observer/control bodies equal corresponding D12 raw files; original model/verifier pins equal runtime copies. Scoped prior independent word-reduction/domain/incidence/scheduler/rollback and fixed nonhostile custody arguments apply to exact copies. No new semantic or timer logic in custodians; no fit/physicalWang/fullVM claim from Source reuse.'),
    ('initial-reviews-and-three-policy-lineage','Exact C4a4fc720 and Lc3ed3a3f conditional reviews bind v11 and e371 common point order. All plans/protocol now join D11 ordering57ee with original7d55 specialization/freeze override, D12 abstention9c22 and D13 point policye371. The abstention successor correctly remains v10 while current point policy successor is v11. Inherited completion wording is explicitly base ordering-protocol scope, not a relabeling of older records.'),
    ('Graph-authority-and-complete-common-order','Reviewed ranking only stably permutes existing keys at the unchanged Graph-selected BRANCH point, with novelty then optional validated hint inside four bins. All four point arms share the same novelty priority; forced keys retain original order and global DEAD/FORCED/earliest-generation authority remains. Complete multiplicity/fallback and primitive repetitions remain; State/Graph/markings/rollback and final primitive universe are unchanged. No target-route scoring, prune, new inference, macro or RL.'),
    ('proof-registry-and-observation-separation','Registry query/status/cost and bounded UNKNOWN unadmitted/usable[] semantics persist; rejected/unrecognized/Root/foreign faults remain hard. D12 actual-prefix abstention and surviving context Host/trial-key gates remain. Final Host/full finite region/Native blocks=[] gates unchanged. order.preferred is only hint nomination and activation is not executed cluster; no new tier/realization metrics or counterfactual improvement is implied.'),
    ('three-full-cold-cases-and-matched-fairness','Three exact distinct absent actual/observer paths retain the full original corpus,14/13/14 targets, fresh3/5/5 donor acquisition and six relative arm schedules. Same point novelty for P00/P01/P10/P11 leaves existing marking/hint factors as the intended comparison. S0/SC Source unchanged. No supplied routes, reused learned library/result/prefix/grant, target weakening or outcome-dependent retry; all18 outcomes and final candidate gates required for complete comparison.'),
    ('unchanged-caps-and-charged-new-work','All scientific and outer limits exactly equal D12, including600attempts/cooperative2s from before Graph/setup/audits, two domain audits and all Native/compiler/marking/cluster bounds;160work/180positive/210custody/225fallback,1GiB/128MiB/9MiBreserve/400mcallbacks and log/result ceilings. New prefix/tier/per-key/final-check work is charged inside those clocks and can reduce attempted work. Novel formulas may be irrelevant/repeats useful. Actual full outputs, waits/reaping, stable census and tool/observer resource joins decide admission; no predicted receptor availability/proof/fit/gain.'),
    ('fresh-independent-and-Root-once-barrier','No actual/observer/grant/preflight files existed at freeze and all offered counts are zero. This receipt is complete Source/plan preflight, not an actual grant or measured qualification, and does not assume the new L whole-plan PASS. Root must separately collect that receipt, issue exact fresh once grants and observe all tools idle before serial actuals. D12/older/P bytes remain unchanged; no partial content parsed/projected/adopted.')
]
review = dict(schema='typed-point-novelty-whole-prospective-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_EXACT_WHOLE_SOURCE_PLAN_PREFLIGHT_SEPARATE_L_WHOLE_REVIEW_AND_ROOT_ONCE_GRANTS_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,logical_replays=0,actual_execution_authorized=False,grant_authority=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],whole_offer=pin(offer_path),protocol=offer['protocol'],plans=offer['plans'],complete_input_pins=offer['files'],normative_references=offer['normative_references'],AST_unused_compile_count=33,unchanged_runtime_Source_count=28,unchanged_custodian_Source_count=4,exact_D12_copy_manifest=pin(baseline_path),initial_scientific_C_review=pin(C_path),separate_initial_L_review=pin(L_path),inherited_D12_C_whole_review=pin(inherited_path),original_D8_L_verifier_handoff=pin(original_L),ordering_policy=offer['ordering_policy'],abstention_policy=offer['abstention_policy'],point_ordering_policy=offer['point_ordering_policy'],superseded_acquisition=offer['superseded_acquisition'],metadata_authors=[pin(R/'prepare_case_plans_v1.py'),pin(R/'authorize_cases_v1.py')],metadata_author_scope='Read as Root authoring-only metadata; neither helper executed by reviewer and no grant issued.',separate_D13_L_whole_review_required=True,L_whole_PASS_not_assumed=True,resource_fit='UNMEASURED',new_actuals=0,new_grants=0,old_grants_remaining=0,partial_policy='No partial content opened, parsed, projected or admitted.',manual_scope='Conditional Source/manual complete preflight, not mathematical checker replay, actual conformance or performance qualification.',tools_stopped=True)
target = D/'review-C/typed-point-novelty-whole-prospective-Source-review-v1.json'
with target.open('x')as stream:
    json.dump(review,stream,indent=2)
    stream.write('\n')
print(json.dumps(pin(target)))

