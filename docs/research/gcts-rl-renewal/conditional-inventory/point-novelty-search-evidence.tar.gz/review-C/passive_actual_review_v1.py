"""Passive joins over complete saved JSON only; no research imports or replay."""
from pathlib import Path
import collections
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-point-novelty-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'
D8 = BASE / 'research-runs/gcts-word-point-proof-pilot-20261020'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

offer_path = D / 'root/prospective-whole-offer-v1.json'
offer = read(offer_path)
assert len(offer['files']) == 45
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references']:
    verify(row)
corpus = read(next(r['path'] for r in offer['files'] if r['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'))
bank = read(D8 / 'verification-L/declarative-diagnostic-bank-v1.json')
control_ids = [r['id'] for r in bank['controls']]
external_path = D / 'root/external-tool-observer-v1.json'
external = read(external_path)
assert external['all_three_sessions_terminal'] is True
terminals = [r for r in external['observations'] if 'exit_code' in r]
assert len(terminals) == 3 and [r['exit_code'] for r in terminals] == [2,2,0]
assert {r['session_id'] for r in terminals} == set(external['terminal_sessions'])
cases = [s['id'] for s in corpus['tests']]
expected = [dict(S0=14, SC=14, P00=30, P01=29, P10=27, P11=21),
            dict(S0=600, SC=600, P00=30, P01=26, P10=27, P11=17),
            dict(S0=600, SC=600, P00=22, P01=22, P10=26, P11=16)]
expected_peaks = [1083572224, 1095286784, 1027194880]
expected_instances = [7, 11, 7]
expected_proposals = [4, 0, 4]
expected_order_changes = [0, 0, 2]
observations = []
actual_pins = []
grant_pins = []
status_total = collections.Counter()
point_total = audit_total = proposal_total = changed_order_total = 0
for index, cid in enumerate(cases):
    path = D / 'actual' / cid
    observer_path = D / 'actual' / (cid + '.observer') / 'observer.json'
    result_path = path / 'result.json'
    rp = pin(result_path)
    record = read(result_path)
    s = record['scientific_result']
    assert len(s['tests']) == 1
    t = s['tests'][0]
    header = read(path / 'worker-header.json')
    terminal = read(path / 'terminal.json')
    observer = read(observer_path)
    tool = dict(terminal=next(r for r in terminals if r['case_id'] == cid))
    plan_path = D / 'root' / ('plan-' + cid + '-v1.json')
    plan = read(plan_path)
    grant_path = D / 'root' / ('grant-' + cid + '-v1.json')
    grant = read(grant_path)
    consumed = read(path / 'CONSUMED.json')
    grant_pins.append(pin(grant_path))
    assert record['case_id'] == s['selected_case_id'] == header['case_id'] == terminal['case_id'] == observer['case_id'] == cid
    assert consumed['case_id'] == grant['case_id'] == cid and consumed['uses'] == grant['uses'] == 1
    assert consumed['plan_sha256'] == grant['plan_sha256'] == pin(plan_path)['sha256']
    assert consumed['grant_sha256'] == pin(grant_path)['sha256']
    assert grant['authorized'] is grant['no_retry'] is True and grant['old_grants_reused'] is False
    for row in grant['reviews']:
        verify(row)
    assert s['inputs'] == corpus and s['limits'] == plan['experiment_limits']
    assert s['job_record_complete'] is s['all_six_searched'] is s['scientific_complete'] is s['complete'] is True
    assert s['resource_accepted'] is False
    assert s['registry_native_admitted'] is s['registered_inference_used'] is False
    assert s['ordering_hints_enabled'] is True
    assert s['ordering_policy']['id'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
    assert s['ordering_policy']['native_registry_required_for_ordering'] is False
    assert record['status'] == header['status'] == 'COMPLETE' and record['error'] is None
    assert record['first_Root_fault'] is header['first_Root_fault'] is False
    assert terminal['header_valid'] is True and terminal['process_exit_code'] == 0
    assert header['result'] == terminal['result'] == rp and terminal['header'] == header
    assert record['source_unchanged'] is terminal['sources_unchanged'] is True
    assert record['old_qualification_reused'] is record['full_physical_Wang_claim'] is False
    admitted = index == 2
    assert observer['resource_candidate_accepted'] is admitted
    assert observer['parent_exit_code'] == 0 and tool['terminal']['exit_code'] == (0 if admitted else 2)
    assert observer['conservative_whole_peak_bytes'] == expected_peaks[index]
    assert (expected_peaks[index] < plan['limits']['memory_bytes']) is admitted
    transport = record['native_transport']
    queries = record['native_queries']
    assert s['native_records'] == queries and transport['complete_records'] == len(queries)
    assert transport['all_reaped'] is transport['closed'] is True and transport['native_exit_code'] == 0
    assert [q['id'] for q in queries] == list(range(len(queries)))
    assert len(transport['request_stages']) == len(queries)
    for q, stage in zip(queries, transport['request_stages'], strict=True):
        assert hashlib.sha256(canonical(q['request'])).hexdigest() == q['request_sha256']
        assert stage['record_id'] == stage['ordinal'] == q['id'] and stage['stage'] == 'COMPLETED'
        assert stage['purpose'] == q['purpose'] and stage['limit'] == plan['experiment_limits']['native_steps']
        for key in ['input_sha256', 'output_sha256', 'request_sha256']:
            assert stage[key] == q[key]
    assert pin(path / 'native/input.bin')['sha256'] == queries[-1]['input_sha256']
    assert pin(path / 'native/output.bin')['sha256'] == queries[-1]['output_sha256']
    qs = collections.Counter(q['result']['status'] for q in queries)
    status_total.update(qs)
    ground = t['clusters']
    gq = queries[ground['admission_query']]
    assert gq['purpose'] == 'pilot_ground_cluster_admission' and gq['request']['theory'] == t['spec']['theory']
    assert gq['request']['blocks'] == [r['definition'] for r in ground['instances']]
    assert ground['instances'] == ground['ordering_instances']
    assert len(ground['instances']) == expected_instances[index]
    assert gq['result']['status'] == ground['native_status'] == 'unknown_step_budget'
    assert gq['result']['micro_steps'] == 1000000000 and ground['binding_work'] == 20003
    assert ground['usable'] == [] and ground['registry_native_admitted'] is False
    assert ground['ordering_hints_enabled'] is True and ground['usage'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
    wr = s['word_reference_diagnostics']
    assert wr['complete'] is True and [r['id'] for r in wr['controls']] == control_ids
    assert all(r['status'] == 'PASSED' for r in wr['controls']) and wr['tiny_full_byte_pair_comparisons'] == 49
    assert s['diagnostics']['status'] == 'complete'
    assert s['diagnostics']['base_solutions'] == s['diagnostics']['marked_solutions']
    assert s['diagnostics']['global_dead_forced_generation_controls'] is s['diagnostics']['callback_identity_propagated'] is True
    for key in ['reference_check', 'word_model_check', 'marked_extension_check', 'marking_certificate_check']:
        assert t[key]['complete'] is True
    m = t['model']
    bykey = {tuple(r['key']): r for r in m['placements']}
    assert len(bykey) == len(m['placements']) == t['reference_check']['accepted_placements']
    assert len(m['word_dictionary']) == t['reference_check']['distinct_complete_words']
    assert len(m['conflicts']) == t['reference_check']['internal_conflicts']
    assert m['word_terminator'] == 256 and m['initial']['marks'] == [[[4 * (t['spec']['length'] - 1), 100], 0]]
    assert bytes.fromhex(m['word_dictionary'][0]) == canonical(t['spec']['target'])
    assert sum(len(r['keys']) for r in m['dependencies']) == t['reference_check']['dependency_memberships']
    roots = {tuple(r['point']): r['keys'] for r in m['alignments']}
    certs = t['markings']['certificates']
    assert len(certs) == t['marking_certificate_check']['certificates'] == t['marked_extension_check']['auxiliary_points'] == 12
    for ordinal, c in enumerate(certs):
        assert c['id'] == ordinal and c['trial'] == [c['auxiliary']['placement']]
        assert c['trial'][0][:2] == [0, 0] and c['exhausted_root'] == [0, 1]
        assert c['auxiliary']['point'] == [-100, ordinal] and c['auxiliary']['placement_value'] == 0 and c['auxiliary']['initial_value'] == 1
        assert [r['key'] for r in c['all_candidates']] == roots[(0, 1)]
    donors = []
    assert len(s['training']) == len(s['library']) == 3 and s['library_frozen_before_tests'] is True
    for tr, length in zip(s['training'], [3, 5, 5], strict=True):
        assert len(tr['search']['proof']) == len(tr['essential_proof']) == length
        assert tr['host_check']['accepted'] is tr['essential_host_check']['accepted'] is tr['region']['complete'] is tr['reference_check']['complete'] is True
        for field, proof in [('native_query', tr['search']['proof']), ('essential_native_query', tr['essential_proof'])]:
            q = queries[tr[field]]
            assert q['result']['status'] == 'accepted'
            assert q['request']['proof'] == proof and q['request']['theory'] == tr['spec']['theory']
            assert q['request']['target'] == tr['spec']['target'] and q['request']['blocks'] == []
        donors.append(dict(id=tr['spec']['id'], rows=length, whole_query=tr['native_query'], essential_query=tr['essential_native_query']))
    assert [a['id'] for a in t['arms']] == corpus['protocol']['arm_order'][cid] and len(t['arms']) == 6
    arms = {a['id']: a for a in t['arms']}
    arm_rows = []
    for a in t['arms']:
        aid = a['id']
        search = a['search']
        trace = search['trace']
        metrics = search['metrics']
        assert a['execution_status'] == 'SEARCH_RETURNED' and search['root_restored'] is True
        assert metrics['attempts'] == expected[index][aid]
        obs = a['ordering_observations']
        cluster = aid in ['SC', 'P01', 'P11']
        marked = aid in ['P10', 'P11']
        assert a['cluster_enabled'] is cluster and a['marking_enabled'] is marked
        assert obs['enabled'] is cluster and obs['available_instances'] == (expected_instances[index] if cluster else 0)
        assert obs['symbolic_activation_count'] is obs['realized_primitive_choice_count'] is None
        assert obs['successful_proposals'] == metrics.get('cluster_proposals', 0)
        events = collections.Counter(e['event'] for e in trace)
        row = dict(id=aid, status=search['status'], metrics=metrics, trace_event_counts=dict(events), seconds=search['seconds'], full_arm_seconds=a['timings']['full_arm_seconds'], root_restored=True, ordering_observations=obs, proof_verification_status=a['proof_verification_status'])
        if aid.startswith('P'):
            assert search['status'] == 'unknown_search_budget' and search['proof'] is None and search['placements'] == []
            assert len(search['domain_audits']) == 2 and all(r['complete'] is True for r in search['domain_audits'])
            assert events['place'] == metrics['attempts'] and events['decision'] == metrics['nodes']
            assert events['return'] == metrics.get('backtracks', 0)
            assert trace[-1] == dict(event='cutoff', attempts=metrics['attempts'])
            kinds = collections.Counter(e['kind'] for e in trace if e['event'] == 'decision')
            for kind in ['branch', 'forced', 'dead']:
                assert kinds[kind] == metrics.get(kind, 0)
            for ordinal, e in enumerate(trace):
                if e['event'] == 'decision':
                    assert e['ordinal'] == ordinal
                elif e['event'] == 'order':
                    decision = trace[e['decision']]
                    assert decision['kind'] in ['forced', 'branch']
                    assert sorted(e['alternatives']) == sorted(decision['original_alternatives'])
                elif e['event'] in ['place', 'return']:
                    order = next(r for r in trace[e['decision'] + 1:] if r['event'] == 'order' and r['decision'] == e['decision'])
                    assert e['key'] in order['alternatives']
                elif e['event'] == 'cluster_proposals':
                    assert type(e['proposals']) is list
            assert len(search['initial_auxiliary_removals']) == (12 if marked else 0)
            assert metrics['auxiliary_removed_incidences'] == 0
            if marked:
                assert [w['candidate'] for w in search['initial_auxiliary_removals']] == [c['auxiliary']['placement'] for c in certs]
            if cluster:
                assert obs['point_activated_proposal_packets'] == metrics.get('cluster_hints', 0)
                assert obs['successful_proposals'] == metrics.get('cluster_proposals', 0) == (0 if index == 1 else 2)
            else:
                assert obs['point_activated_proposal_packets'] is None
            row['completed_audits'] = search['domain_audits']
            row['initial_auxiliary_witnesses'] = len(search['initial_auxiliary_removals'])
            point_total += metrics['attempts']
            audit_total += 2
        else:
            assert events['extend'] == metrics['attempts']
            assert events['decision'] == metrics['nodes'] - (1 if search['proof'] is not None else 0)
            assert events['return'] == metrics.get('backtracks', 0) + (14 if search['proof'] is not None else 0)
            path_commands = []
            proposals = changes = 0
            for e in trace:
                if e['event'] == 'decision':
                    assert e['row'] == len(path_commands)
                    assert sorted(e['ordered_candidates']) == sorted(e['original_candidates'])
                    changes += e['ordered_candidates'] != e['original_candidates']
                    for p in e['proposals']:
                        assert p['instance'] in {r['id'] for r in ground['instances']}
                        assert p['prefix_rows'] == len(path_commands)
                        assert p['checked_primitive_proof'] == path_commands + p['commands']
                        assert p['result_formula'] not in [c['formula'] for c in path_commands]
                        assert p['host_check']['accepted'] is True
                        assert p['host_check']['rows'] == len(p['checked_primitive_proof'])
                        assert p['host_check']['target'] == p['result_formula'] == p['commands'][-1]['formula']
                        assert any(m['domains'][e['row']][k] == p['commands'][0] for k, v in e['original_candidates'])
                    proposals += len(e['proposals'])
                elif e['event'] == 'extend':
                    dec = trace[e['decision']]
                    assert [e['skeleton'], e['variant']] in dec['ordered_candidates']
                    path_commands.append(m['domains'][dec['row']][e['skeleton']])
                elif e['event'] == 'return':
                    assert len(path_commands) == trace[e['decision']]['row'] + 1
                    path_commands.pop()
            assert proposals == metrics.get('cluster_proposals', 0)
            assert proposals == (expected_proposals[index] if aid == 'SC' else 0)
            assert changes == (expected_order_changes[index] if aid == 'SC' else 0)
            row['passive_trace_successful_proposal_packets'] = proposals
            row['passive_trace_decisions_with_changed_order'] = changes
            row['passive_trace_metric_scope'] = 'Literal saved decision-array comparisons; not realized primitive-choice or completed-cluster counts.'
            proposal_total += proposals
            changed_order_total += changes
        if index == 0 and aid in ['S0', 'SC']:
            assert a['native_proof_accepted'] is a['host_check']['accepted'] is a['region']['complete'] is True
            assert len(search['proof']) == 14 and len(search['placements']) == 28
            q = queries[a['native_query']]
            assert q['result']['status'] == 'accepted' and q['purpose'] == 'pilot_test_' + cid + '_' + aid
            assert q['request']['proof'] == search['proof'] and q['request']['theory'] == t['spec']['theory']
            assert q['request']['target'] == t['spec']['target'] and q['request']['blocks'] == []
            for key in search['placements']:
                item = bykey[tuple(key)]
                slot, k = item['command_reference']
                assert m['domains'][slot][k] == search['proof'][slot]
            prior = read(OLD / 'actual' / cid / 'result.json')
            prior_proof = next(x['search']['proof'] for x in prior['scientific_result']['tests'][0]['arms'] if x['id'] == 'S0')
            assert search['proof'] == prior_proof
            row['checker_accepted_primitive_certificate'] = dict(whole_job_admitted=admitted, arm=aid, rows=14, selected_placements=28, Native_query=q['id'], Native_status='accepted', rules=dict(collections.Counter(c['rule'] for c in search['proof'])), repeated_D12_S0_certificate=True, novel_theorem=False, GCTS_point_proof=False)
        else:
            assert search['proof'] is None and search['status'] == 'unknown_search_budget'
        arm_rows.append(row)
    for bare, marked in [('P00', 'P10'), ('P01', 'P11')]:
        b = arms[bare]['search']['domain_audits']
        a = arms[marked]['search']['domain_audits']
        assert b[0]['incidences'] - a[0]['incidences'] == 12 and b[0]['decision'] == a[0]['decision']
        assert b[1] == a[1]
    assert arms['P00']['search']['domain_audits'] == arms['P01']['search']['domain_audits']
    assert arms['P10']['search']['domain_audits'] == arms['P11']['search']['domain_audits']
    control = record['independent_external_controls']
    assert control['supplied_to_proof_search'] is False
    assert all(control['base']['premise_truths']) and control['base']['goal_truth'] is False
    files = sorted(p for folder in [path, observer_path.parent] for p in folder.rglob('*') if p.is_file())
    assert not any('.partial' in p.name for p in files) and len(files) == 14
    actual_pins.extend(pin(p) for p in files)
    observations.append(dict(case_id=cid, resource_admitted=admitted, packet=rp, whole_peak_bytes=observer['conservative_whole_peak_bytes'], observer_gate_seconds=observer['final_observer_gate_seconds'], plan=pin(plan_path), grant=pin(grant_path), consumed=pin(path/'CONSUMED.json'), Native_queries=len(queries), Native_status_counts=dict(qs), donors=donors, library_family_ids=[r['id'] for r in s['library']], registry_native_admitted=False, registry_status=ground['native_status'], registry_usable=0, ordering_instances=len(ground['ordering_instances']), registry_binding_work=ground['binding_work'], scientific_complete=True, word_reference_controls=48, full_shared_setup_seconds=t['full_shared_setup_seconds'], compile_and_model_seconds=t['compile_and_model_seconds'], arms=arm_rows))

assert point_total == 293 and audit_total == 24 and proposal_total == 8 and changed_order_total == 2
assert len(actual_pins) == 42 and dict(status_total) == dict(accepted=76, rejected=209, unknown_step_budget=3)
assert len({r['sha256'] for r in grant_pins}) == 3
old_review_path = OLD / 'review-C/typed-saturated-hint-actual-scientific-review-v1.json'
old_review = read(old_review_path)
assert pin(old_review_path)['sha256'] == '770cf6d03f4c835716a3e77a64d4b8844fdd0b0137da557015c9b8bb9a3143e9'
for row in old_review['actual_file_pins']:
    verify(row)
first = read(D/'actual'/cases[0]/'result.json')['scientific_result']['tests'][0]
first_arms = {a['id']: a for a in first['arms']}
base = first_arms['S0']['search']
guided = first_arms['SC']['search']
assert base['proof'] == guided['proof'] and base['placements'] == guided['placements']
base_decisions = [e for e in base['trace'] if e['event'] == 'decision']
guided_decisions = [e for e in guided['trace'] if e['event'] == 'decision']
assert len(base_decisions) == len(guided_decisions) == 14
assert [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in base_decisions] == [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in guided_decisions]
assert [{k:v for k,v in e.items() if k != 'proposals'} for e in base['trace']] == [{k:v for k,v in e.items() if k != 'proposals'} for e in guided['trace']]
assert base['metrics']['attempts'] == guided['metrics']['attempts'] == 14
assert base['metrics']['skeleton_tests'] == guided['metrics']['skeleton_tests'] == 47209
assert all(p['result_formula'] not in [c['formula'] for c in p['checked_primitive_proof'][:p['prefix_rows']]] for e in guided_decisions for p in e['proposals'])
expected_results = [('aa10ecba6eab546c80cfdcc87c3e7b67621dcee72648eb4a4073e1bca7eb8999',31619612),('d123e7f2ec1d3ac0860e46c4ae6d37dc020d75caa3a2900d95d060450bd8b4e7',31180600),('4d686c3e460becc7a5009964181f09d2a01cb97ce21303a67bf9ad26cbf60cd5',31557415)]
for row, expected_result in zip(observations, expected_results, strict=True):
    assert (row['packet']['sha256'], row['packet']['bytes']) == expected_result
C_source_path = D/'review-C/typed-point-novelty-Source-review-v1.json'
C_whole_path = D/'review-C/typed-point-novelty-whole-prospective-Source-review-v1.json'
assert pin(C_source_path)['sha256'] == '4a4fc720eba8979b0325aa80c3f3f3a8bbd19cb3220cdf7673de68280f2f6f47'
assert pin(C_whole_path)['sha256'] == 'a11b78e3caa4a69495b55e3ac1f49f6bfb79c9c01f511a46e0e2229e5957568e'
assert read(C_source_path)['review_passed'] is read(C_whole_path)['review_passed'] is True
assert read(C_whole_path)['whole_offer'] == pin(offer_path)

def saved_prefix(model, selected):
    roles = {(k[0],k[1]):k for k in selected}
    prefix = []
    for row in range(len(model['domains'])):
        if (row,0) not in roles or (row,1) not in roles:
            break
        a = model['domains'][row][roles[row,0][2]]
        b = model['domains'][row][roles[row,1][2]]
        if a != b:
            break
        prefix.append(a)
    return prefix

point_packet_observations = []
tier_order_observations = []
for index,cid in enumerate(cases):
    record = read(D/'actual'/cid/'result.json')
    t = record['scientific_result']['tests'][0]
    m = t['model']
    keyed = {tuple(p['key']):p for p in m['placements']}
    for a in t['arms']:
        if a['method'] != 'point':
            continue
        selected = []
        packets = []
        orders = forced = branch = 0
        for ordinal,e in enumerate(a['search']['trace']):
            if e['event'] == 'cluster_proposals':
                prefix = saved_prefix(m,selected)
                for p in e['proposals']:
                    assert p['prefix_rows'] == len(prefix)
                    assert p['checked_primitive_proof'] == prefix+p['commands']
                    assert p['host_check']['accepted'] is True
                    assert p['host_check']['rows'] == len(p['checked_primitive_proof'])
                    assert p['host_check']['target'] == p['result_formula'] == p['commands'][-1]['formula']
                    assert p['result_formula'] not in [c['formula'] for c in prefix]
                    assert p['instance'] in {r['id'] for r in t['clusters']['ordering_instances']}
                    assert len(p['members']) == 2*len(p['commands'])
                    assert p['pending'] == [k for k in p['members'] if k not in selected]
                    for offset,command in enumerate(p['commands']):
                        command_key,guard_key = p['members'][2*offset:2*offset+2]
                        assert command_key[:2] == [len(prefix)+offset,0]
                        assert guard_key[:2] == [len(prefix)+offset,1]
                        for key in [command_key,guard_key]:
                            owned = keyed[tuple(key)]
                            row,k = owned['command_reference']
                            assert m['domains'][row][k] == command
                    packets.append(dict(packet_trace_index=ordinal,packet=p,all_members_selected_at=None,prefix_after=None))
            elif e['event'] == 'order':
                decision = a['search']['trace'][e['decision']]
                keys = decision['original_alternatives']
                assert all(k in keys for k in e['preferred'])
                if decision['kind'] == 'forced':
                    assert e['alternatives'] == keys
                    forced += 1
                else:
                    assert decision['kind'] == 'branch'
                    formulas = [c['formula'] for c in saved_prefix(m,selected)]
                    bins = [[],[],[],[]]
                    for key in keys:
                        row,k = keyed[tuple(key)]['command_reference']
                        formula = m['domains'][row][k]['formula']
                        repeated = formula in formulas
                        tier = (2 if repeated else 0)+(0 if key in e['preferred'] else 1)
                        bins[tier].append(key)
                    assert e['alternatives'] == [k for group in bins for k in group]
                    branch += 1
                orders += 1
            elif e['event'] == 'place':
                selected.append(e['key'])
                for owned in packets:
                    p = owned['packet']
                    if owned['all_members_selected_at'] is None and all(k in selected for k in p['members']):
                        prefix = saved_prefix(m,selected)
                        assert prefix[:p['prefix_rows']+len(p['commands'])] == p['checked_primitive_proof']
                        owned['all_members_selected_at'] = ordinal
                        owned['prefix_after'] = len(prefix)
            elif e['event'] == 'return':
                assert selected.pop() == e['key']
        assert sum(len(e['proposals']) for e in a['search']['trace'] if e['event']=='cluster_proposals') == a['search']['metrics'].get('cluster_proposals',0)
        assert len(packets) == a['search']['metrics'].get('cluster_hints',0)
        tier_order_observations.append(dict(case_id=cid,arm=a['id'],resource_admitted=index==2,recorded_orders=orders,forced_orders_unchanged=forced,branch_orders_exact_stable_four_tiers=branch))
        for owned in packets:
            p = owned['packet']
            assert owned['all_members_selected_at'] is not None
            point_packet_observations.append(dict(case_id=cid,arm=a['id'],resource_admitted=index==2,packet_trace_index=owned['packet_trace_index'],instance=p['instance'],prefix_rows_before=p['prefix_rows'],expanded_primitive_commands=len(p['commands']),members=p['members'],pending=p['pending'],Host_receipt=p['host_check'],result_formula=p['result_formula'],all_members_selected_at=owned['all_members_selected_at'],prefix_rows_after=owned['prefix_after'],interpretation='Literal member co-occurrence and agreeing paired-prefix growth on this recorded branch; not a complete recipient theorem, benefit metric or activation=execution assumption.'))
assert len(point_packet_observations) == 8
assert sum(p['resource_admitted'] for p in point_packet_observations) == 4
assert [(p['arm'],p['prefix_rows_before'],p['prefix_rows_after']) for p in point_packet_observations if p['resource_admitted']] == [('P01',4,5),('P01',6,7),('P11',4,5),('P11',6,7)]
admitted_cases = [c for c in observations if c['resource_admitted']]
rejected_cases = [c for c in observations if not c['resource_admitted']]
assert len(admitted_cases) == 1 and admitted_cases[0]['case_id'] == cases[2]
admitted_point = sum(a['metrics']['attempts'] for c in admitted_cases for a in c['arms'] if a['id'].startswith('P'))
assert admitted_point == 86
checks = [
    ('complete-raw-evidence-and-fresh-attempts','All45 closure pins,42 complete actual/observer files and three fresh consumed grants join exact plans/reviews. All workers/parents exit0 and return complete packets; observer/tool exits2/2/0 truthfully reflect whole memory admission.288 Native request/stage/digest/raw-tail joins remain complete. No partials, research functions or mathematical checker replay.'),
    ('whole-memory-admission-split','First/equality whole peaks1,083,572,224/1,095,286,784B exceed unchanged1GiB; complete outputs and Host/Native observations remain diagnostic only. Negative1,027,194,880B qualifies. Thus18searched/293placements24audits/144controls are observed, while only negative6searches86placements8audits48controls qualify. No failed positive prefix/certificate rescue or complete admitted three-case comparison.'),
    ('registry-donors-and-original-proof-authority','Observed Native counts76accepted/209rejected/3unknown across288queries, all0closed/reaped. Three registry batches remain UNKNOWN/unadmitted/usable[] with7/11/7 separate preference instances; no block inference used. Donors3/5/5 plus whole/essential checks are observed afresh in every job but only the negative job contributes qualified donor observations. Exact final positive S0/SC flat proof queries89/90 accepted, yet both certificates are NOT admitted because their whole job failed. Earlier D12 admitted certificates remain unchanged.'),
    ('exact-common-tier-order-and-rollback','Every recorded point order independently matches the Source rule using saved actual selected-key prefix and existing candidate metadata: forced arrays unchanged; branch arrays the stable novel-hint/novel-ordinary/repeated-hint/repeated-ordinary permutation with every original key. This holds in all four arms. Saved event keys/counters/cutoffs/root restoration and24initial full-domain audits reconcile; only8audits belong to the admitted negative. No per-node Graph/checker replay or arbitrary-state correctness claim.'),
    ('actual-hint-context-and-local-members','Point P01/P11 each emit2packets on first and negative,0equality:8observed/4qualified packets and matching activations. Every packet joins actual contiguous prefix, full primitive suffix, accepted Host receipt, original command+guard keys and pending members. On negative both arms later select every member of each packet with agreeing prefix growth4to5 and6to7. These literal local branch observations support receptor/primitive placement progress, not a complete theorem, automatic useful abstraction or an assumption that activation alone equals execution. Trial legality is Source-backed emission, not independently replayed here.'),
    ('controls-markings-and-reduction-scope','Full model/word/payload/dependency/certificate receipts and all48word controls/case returned; only negative48 qualify. Initial marked Graph audits in both pairs/case have12fewer incidences at same decision, with equal second states. All36 local failure certificates are shallow first-row support exhaustion; no high-level learned lemma or universal word-state reduction claim. No additional during-placement auxiliary removal is observed.'),
    ('symbolic-records-and-no-new-admitted-proof','First S0/SC still have identical14row proof/28placements/candidate ordering and path,4SCpackets0changes, but are nonadmitted diagnostic artifacts. Equality SC0packets600UNKNOWN and negative SC4packets2changes600UNKNOWN remain. All12 point calls UNKNOWN. Current recipient admitted proof count is0; the admitted negative provides local packet/member observations only. No trainedRL, solved new theorem or GCTS proof-search advantage established.'),
    ('fair-costs-and-immutable-history','All cold setup/marking/registry/search/ranking/output/custody costs remain under original caps and cooperative clocks. More/different timed-prefix placements and whole peaks give no causal phase-memory or statistical speedup evidence. Full D12 actual raw pins revalidate unchanged; its admitted baseline recovery is neither revoked nor used to qualify failed D13 jobs. Three-case comparison remains incomplete under resource admission and broader tiling/logic/RL/physicalWang goals remain active.')
]
review = dict(schema='typed-point-novelty-actual-scientific-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_TRUTHFUL_PASSIVE_CLASSIFICATION_TWO_WHOLE_CASES_REJECTED_ONLY_NEGATIVE_ADMITTED',passive_complete_saved_data_only=True,scientific_calls=0,logical_replays=0,actual_execution_authorized=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],resource_admitted_case_ids=[c['case_id']for c in admitted_cases],resource_rejected_case_ids=[c['case_id']for c in rejected_cases],complete_pilot_comparison=False,observed_totals=dict(searches=18,skips=0,point_placements=293,point_domain_audits=24,word_controls=144,Native_queries=288,Native_status_counts=dict(status_total),donor_whole_essential_acceptances=18,checker_accepted_recipient_certificate_occurrences=2,symbolic_successful_packets=8,symbolic_changed_order_decisions=2,point_successful_packets=8,point_activated_packets=8),admitted_totals=dict(searches=6,skips=0,point_placements=86,point_domain_audits=8,word_controls=48,Native_queries=89,Native_status_counts=dict(accepted=22,rejected=66,unknown_step_budget=1),donor_whole_essential_acceptances=6,recipient_certificate_occurrences=0,symbolic_successful_packets=4,symbolic_changed_order_decisions=2,point_successful_packets=4,point_activated_packets=4),admitted_recipient_proofs=0,GCTS_point_proofs_admitted=0,novel_mathematical_theorem=False,GCTS_or_RL_advantage_established=False,point_tier_order_literal_joins=tier_order_observations,point_packet_member_literal_joins=point_packet_observations,source_trial_legality_not_replayed=True,cases=observations,complete_input_pins=offer['files'],actual_file_pins=actual_pins,grant_pins=grant_pins,whole_offer=pin(offer_path),protocol=offer['protocol'],scientific_Source_review=pin(C_source_path),whole_Source_review=pin(C_whole_path),external_tool_observer=pin(external_path),Root_initial_passive_join=pin(D/'root/initial-passive-actual-join-v1.json'),D12_historical_review=pin(old_review_path),partial_policy='No partial contents opened/projected/admitted; failed positive whole jobs are not rescued from complete outputs.',remaining='Only negative whole job qualifies. Local packet/member progress is observed there; complete matched comparison, useful search advantage and full program remain open.',tools_stopped=True)
resource = D/'verification-L/typed-point-novelty-resource-custody-review-v1.json'
if resource.exists():
    assert read(resource)['review_passed'] is True
    review['independent_resource_review'] = pin(resource)
target = D/'review-C/typed-point-novelty-actual-scientific-review-v1.json'
with target.open('x')as stream:
    json.dump(review,stream,indent=2,ensure_ascii=False)
    stream.write('\n')
print(json.dumps(pin(target)))
