"""Source/AST and complete metadata review only; no offered research imports."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-point-novelty-proof-pilot-20261020'
B = D / 'implementation-B'
OLD = BASE / 'research-runs/gcts-novelty-proof-pilot-20261020'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == row

handoff_path = B/'handoff-v1.json'
h = read(handoff_path)
for field in ['entry','api','policy','patch','ast_diff','manual','manifest','model_source','verifier_source']:
    verify(h[field])
assert h['entry']['sha256'] == '3ec6ff3b7acc8335b43c2dc366f6dddbd05c0f9bcfc3d899733999373d91afe6'
assert h['entry']['bytes'] == 54044
assert h['api']['sha256'] == '8870de2fc3f88843e8acede17ca205b773b3719d0de1acbbc61f21c46a137f08'
api = read(h['api']['path'])
policy = read(h['policy']['path'])
manifest = read(h['manifest']['path'])
for row in manifest['files'] + manifest['dependencies']:
    verify(row)
for row in api['policy_lineage'] + [api['predecessor'],api['corpus'],policy['posthoc_motivation']]:
    verify(row)
assert api['entry'] == h['entry'] == policy['successor']
assert api['predecessor'] == policy['predecessor']
assert api['point_ordering_policy'] == h['policy']
assert api['policy_lineage'] == policy['inherited_policies'] + [h['policy']]
assert api['policy_lineage'][0] == api['policy'] and api['policy_lineage'][1] == api['abstention_policy']
assert api['policy']['sha256'] == '57ee2d9d253fd8d6cb30c54a2c8bdfda8ce76be99d02b019390cd7948f5025db'
assert api['abstention_policy']['sha256'] == '9c22ef40b0d63af01bc2a5382008b144be34dd03d29c1dac8aa4d7f6fc0922ea'
old_path = Path(api['predecessor']['path'])
new_path = Path(api['entry']['path'])
old = old_path.read_text()
new = new_path.read_text()
old_tree = ast.parse(old,filename=str(old_path))
new_tree = ast.parse(new,filename=str(new_path))
compile(old_tree,str(old_path),'exec')
compile(new_tree,str(new_path),'exec')
dump = lambda node: ast.dump(node,include_attributes=False)
types = (ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)
old_defs = {n.name:n for n in old_tree.body if isinstance(n,types)}
new_defs = {n.name:n for n in new_tree.body if isinstance(n,types)}
assert old_defs.keys() == new_defs.keys()
changed = [name for name in old_defs if dump(old_defs[name]) != dump(new_defs[name])]
assert changed == ['search_points']
unchanged = [name for name in old_defs if name not in changed]
assert len(unchanged) == 28
old_line = "        alternatives = keys if kind == 'forced' else [k for k in keys if k in preferred] + [k for k in keys if k not in preferred]\n"
new_block = """        if kind == 'forced':
            alternatives = keys
        else:
            completed_formulas = [c['formula'] for c in _prefix(model, state)]
            tiers = ([], [], [], [])
            for key in keys:
                budget.check()
                formula = model.metadata[key]['command']['formula']
                repeated = any(formula == prior for prior in completed_formulas)
                tier = (2 if repeated else 0) + (0 if key in preferred else 1)
                tiers[tier].append(key)
            alternatives = [key for tier in tiers for key in tier]
            budget.check()
"""
assert old.count(old_line) == new.count(new_block) == 1
inverse = new.replace(new_block,old_line,1).replace("VERSION = 'native-point-matched-proof-search-pilot-v11-common-point-novelty-tiers'", "VERSION = 'native-point-matched-proof-search-pilot-v10-novel-cluster-conclusions'",1)
assert inverse == old
patch = ''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile=str(old_path),tofile=str(new_path)))
assert patch.encode() == Path(h['patch']['path']).read_bytes()
restored = copy.deepcopy(new_tree)
new_search = next(n for n in restored.body if isinstance(n,ast.FunctionDef) and n.name == 'search_points')
old_visit = next(n for n in old_defs['search_points'].body if isinstance(n,ast.FunctionDef) and n.name == 'visit')
new_visit = next(n for n in new_search.body if isinstance(n,ast.FunctionDef) and n.name == 'visit')
old_assign = next(n for n in old_visit.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'alternatives' for t in n.targets))
expected_if = ast.parse('\n'.join(line[8:] if line.startswith('        ') else line for line in new_block.splitlines())).body[0]
new_if_indices = [i for i,n in enumerate(new_visit.body) if dump(n) == dump(expected_if)]
assert len(new_if_indices) == 1
new_visit.body[new_if_indices[0]] = copy.deepcopy(old_assign)
old_version = next(n for n in old_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'VERSION' for t in n.targets))
new_version = next(n for n in restored.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'VERSION' for t in n.targets))
new_version.value = copy.deepcopy(old_version.value)
assert dump(restored) == dump(old_tree)
old_api = read(OLD/'implementation-B/API-v1.json')
for field in ['roles','limits','model_source','verifier_source','corpus','policy','abstention_policy']:
    assert api[field] == old_api[field]
masters = [BASE/'docs/basic-tiling-algorithm.md',BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md']
assert [pin(p)['sha256'] for p in masters] == ['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9','ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
parser = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
assert pin(parser)['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
prior_source = OLD/'review-C/typed-saturated-hint-Source-review-v1.json'
prior_actual = OLD/'review-C/typed-saturated-hint-actual-scientific-review-v1.json'
assert pin(prior_source)['sha256'] == 'b4311b9243bca5274f621b3d8f8969141fbccb3012cf1b30500da308cb1effaf'
assert pin(prior_actual)['sha256'] == '770cf6d03f4c835716a3e77a64d4b8844fdd0b0137da557015c9b8bb9a3143e9'

checks = [
    ('exact-shared-function-delta','All frozen artifacts/dependencies independently pinned. Exact full raw inverse and unified patch reproduce v10. Only search_points differs among29 function/class ASTs;28 unchanged. Its one old alternatives assignment is replaced by the exact reviewed If/tier block. Replacing that block and VERSION recovers the whole old module AST. AST/unused compile only, no offered Source imports/calls.'),
    ('Graph-authority-and-forced-moves','The change follows unchanged Graph.decision and initial full audits, with DEAD/EMPTY early returns unchanged. It cannot select another frontier point/generation or change candidate domains/degrees. Forced alternatives remain keys exactly; prefix/tier construction is skipped for forced moves. Global DEAD/FORCED/earliest-generation rules retain authority.'),
    ('stable-complete-permutation','At a branch every original key is visited once and appended once to exactly one of four bins: novel-hinted,novel-ordinary,repeated-hinted,repeated-ordinary. Flattening preserves original order inside each bin and every multiplicity. Existing sorted-alternatives equality remains. Repeated or padding derivations remain possible; hints cannot move a repeated key ahead of an ordinary novel key. This is ranking only, not pruning or a new marking certificate.'),
    ('actual-prefix-read-only-ownership','Formula novelty is exact list-AST equality against the unchanged _prefix actual contiguous earlier paired C/G commands. Candidate formulas come from existing metadata; no target/reference proof, future expansion, alpha normalization or route label is consulted. Call-local formula/tier lists do not mutate prefix/model/State/Graph/library. Fixed well-formed literal-domain and nonhostile assumptions remain; no arbitrary-object equality claim.'),
    ('common-four-arm-fairness-and-proof-authority','The same search_points function gives all four point arms the same novelty priority independently of marking/cluster flags. Only the already validated preferred subset affects order within tiers. S0/SC, D12 saturated-hint abstention, D11 registry query/status/cost/UNKNOWN policy and hard faults, empty no-block Model/compiler and final Host/fullregion/Native blocks=[] gates are AST-identical. No new inference, macro, proof-length shortcut or RL policy.'),
    ('checkpoints-cost-and-rollback','Every branch key invokes the existing budget.check before scoring, plus one check after flattening; all ranking stays after the original2s clock start and inside cumulative Root limits. No ranking catch/reclassification is added. Mid-ranking owned cutoff stays UNKNOWN before any affected placement, and existing identity guard/traceback cleanup/root restoration remains. State copies/Graph updates/recursive fallback are unchanged. Additional scan/allocation/check costs may reduce completed work; no fit/phase benefit inferred.'),
    ('honest-trace-metrics-and-utility-limits','order.preferred remains a hint-nominated subset, not the final global priority: novelty may place ordinary keys first. An activated packet is not completed cluster execution. No tier/rejection/realization counters are introduced; current full traces retain original alternatives and final order. Novel formulas may be irrelevant and repeats useful; complete fallback protects enumeration/validity, not finite-budget performance. This disclosed follow-up is neither blind validation nor a guarantee of useful receptors/proof discovery.'),
    ('conditional-policy-and-fresh-Root-barrier','Exact e371 point policy binds inherited57ee ordering/acquisition override and9c22 abstention, unchanged corpus/roles/quotas. Fresh Root protocol/closure/three cold full-case plans and independent whole reviews must join all three policies and unchanged costs/schedules/caps before any fresh Root once grant/idle execution. This Source receipt reviews no Root plans and authorizes no actual or publication. D12/P remain unchanged; no partial content opened.')
]
review = dict(schema='typed-common-point-novelty-scientific-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_CONDITIONAL_STABLE_COMMON_POINT_BRANCH_ORDERING_FRESH_WHOLE_PLAN_REVIEW_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,logical_replays=0,whole_plan_reviewed=False,actual_execution_authorized=False,grant_authority=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],entry=api['entry'],predecessor=api['predecessor'],API=h['api'],implementation_handoff=pin(handoff_path),point_ordering_policy=h['policy'],inherited_policies=policy['inherited_policies'],artifacts=[pin(p) for p in sorted(B.iterdir())if p.is_file()],dependency_pins=[api['model_source'],api['verifier_source'],api['corpus'],policy['posthoc_motivation']],normative_references=[pin(p)for p in masters],metadata_parser_runtime=pin(parser),changed_functions=['search_points'],unchanged_function_class_AST_count=28,unchanged_function_classes=unchanged,full_raw_Source_inverse_exact=True,full_module_AST_inverse_exact=True,patch_reproduced=True,forced_alternatives_unchanged=True,all_four_point_arms_same_novelty_priority=True,complete_original_candidate_multiplicity_preserved=True,no_new_marking_or_inference=True,prior_D12_Source_review=pin(prior_source),prior_D12_actual_review=pin(prior_actual),limits=api['limits'],fit_and_usefulness='UNMEASURED',required_fresh_Root_joins=['Exact three-policy lineage and old acquisition override in new protocol/full closure/plans.','All full cold donor/test cases, six arms/schedules, candidate identities, quotas, audits, costs and final gates unchanged.','Independent whole-plan reviews/fresh Root once grants/all-agent idle barrier before Root-only actual.'],partial_policy='No partial content read, parsed, projected or admitted.',manual_scope='Independent conditional Source/manual ordering/permutation/ownership review, not mechanized soundness or runtime/performance qualification.',tools_stopped=True)
target = D/'review-C/typed-point-novelty-Source-review-v1.json'
with target.open('x')as stream:
    json.dump(review,stream,indent=2)
    stream.write('\n')
print(json.dumps(pin(target)))
