"""Inert independent indexed audit for explicit finite unit-anchor/root0 models.

No producer import/call, IO, CLI, solver, model construction or hidden cache.
Preparation validates all literals and freezes indexes; every event checks the
whole state and graph. Public native trail tokens are metadata, not a private
trail proof. Complete CSP certificates are checked without search/replay.
"""
from dataclasses import dataclass
from types import MappingProxyType
import hashlib
import json
import math
import time


VERSION = 'GCTS-INDEXED-UNIT-INDEPENDENT-v2'
LEX = 'LEX_ID'
PERMUTED = 'VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX'
POLICY = {'empty': 'GLOBAL_LEX_POINT', 'forced': 'GLOBAL_LEX_POINT',
          'branch': 'MIN_GENERATION_DOMAIN_POINT', 'value': LEX,
          'generation': 'ALL_REQUIRED_ROOT_0'}
METRICS = ('nodes', 'attempts', 'accepted_base_placements', 'seed_placements',
           'forced_placements', 'branch_decisions', 'backtracks',
           'candidate_removals', 'max_frontier_points', 'max_active_candidates',
           'max_edges', 'final_frontier_points', 'final_active_candidates', 'final_edges')
PROPOSAL_METRICS = ('branch_observations', 'proposer_calls', 'packets_rejected',
                    'clusters_proposed', 'clusters_accepted', 'clusters_rejected',
                    'joint_members_checked', 'joint_t_terms_checked', 'joint_m_terms_checked',
                    'branch_order_changes', 'proposal_audit_calls')
_SEAL = object()


class IndexedOracleError(ValueError):
    """Owned invalid evidence or callback shape."""


class UnsupportedProfile(IndexedOracleError):
    """Valid general model outside the finite unit-anchor/root0 profile."""


class IndexedBudgetExceeded(RuntimeError):
    """An unresolved check, never proof of a negative proposition."""


def _need(ok, message='INVALID_EVIDENCE'):
    if not ok:
        raise IndexedOracleError(message)


def _record(value, keys):
    _need(type(value) is dict and set(value) == set(keys))


def _int(value, minimum=0):
    _need(type(value) is int and value >= minimum)
    return value


def _string(value):
    _need(type(value) is str)
    return value


def _point(value):
    _need(type(value) is list and len(value) == 2
          and all(type(x) is int for x in value))
    return tuple(value)


def _same(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return set(left) == set(right) and all(_same(left[k], right[k]) for k in left)
    if type(left) in (list, tuple):
        return len(left) == len(right) and all(_same(a, b) for a, b in zip(left, right))
    return left == right


def _eq(left, right):
    _need(_same(left, right))


def _bytes(value):
    # JSON-only input; this also rejects NaN/Infinity. Types are separately
    # checked where they carry scientific meaning, including bool versus int.
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode()


def canonical_sha256(value):
    return hashlib.sha256(_bytes(value)).hexdigest()


def _clone(value):
    """Iterative exact plain JSON copy; scientific proof depth is not clipped."""
    root = [None]
    stack, parents = [(value, root, 0, False)], set()
    while stack:
        current, parent, key, leaving = stack.pop()
        if leaving:
            parents.remove(id(current))
            continue
        kind = type(current)
        if current is None or kind in (str, bool, int):
            parent[key] = current
            continue
        if kind is float:
            _need(math.isfinite(current), 'NON_JSON_EVIDENCE')
            parent[key] = current
            continue
        _need(kind in (list, dict) and id(current) not in parents, 'NON_JSON_EVIDENCE')
        parents.add(id(current))
        stack.append((current, None, None, True))
        if kind is list:
            result = [None] * len(current)
            parent[key] = result
            for index in range(len(current) - 1, -1, -1):
                stack.append((current[index], result, index, False))
        else:
            _need(all(type(k) is str for k in current), 'NON_JSON_EVIDENCE')
            result = {}
            parent[key] = result
            for name in reversed(list(current)):
                stack.append((current[name], result, name, False))
    return root[0]


class _Meter:
    __slots__ = ('start', 'callback', 'calls', 'units')

    def __init__(self, callback):
        self.start = time.perf_counter()
        _need(callback is None or callable(callback), 'INVALID_CALLBACK')
        self.callback = callback
        self.calls = 0
        self.units = 0
        self.tick()

    def tick(self):
        if self.callback is None:
            return
        self.calls += 1
        value = self.callback()
        if value is False:
            raise IndexedBudgetExceeded('BUDGET')
        _need(value is None or value is True, 'INVALID_CALLBACK')

    def work(self):
        self.units += 1
        if self.units % 1024 == 0:
            self.tick()

    def costs(self):
        return {'elapsed_seconds': time.perf_counter() - self.start,
                'budget_callbacks': self.calls}


def _inputs(budget, *values):
    # Snapshot input before the first external callback, so callback mutation
    # cannot bind hashes to a different model than the one actually indexed.
    # This atomic plain-data copy is timed, but has no cooperative midpoint.
    meter = _Meter(None)
    _need(budget is None or callable(budget), 'INVALID_CALLBACK')
    copies = tuple(_clone(value) for value in values)
    meter.callback = budget
    meter.tick()
    return meter, copies


@dataclass(frozen=True, slots=True, eq=False)
class PreparedModel:
    version: str
    raw_model_sha256: str
    model_sha256: str
    preparation_costs: tuple
    _canonical: bytes
    _ids: tuple
    _rank: object
    _rows: object
    _anchors: object
    _marks: object
    _by_anchor: object
    _by_slot: object
    _required: tuple
    _seeds: tuple
    _points: tuple
    _free: tuple
    _seal: object


@dataclass(frozen=True, slots=True, eq=False)
class PreparedSpec:
    version: str
    spec_sha256: str
    value_policy: str
    preparation_costs: tuple
    _model: PreparedModel
    _canonical: bytes
    _seal: object


@dataclass(frozen=True, slots=True, eq=False)
class CheckpointReceipt:
    version: str
    raw_model_sha256: str
    model_sha256: str
    native: bool
    state_sha256: str
    preparation_costs: tuple
    _model: PreparedModel
    _canonical: bytes
    _seal: object


@dataclass(frozen=True, slots=True, eq=False)
class AuditCursor:
    version: str
    model_sha256: str
    raw_model_sha256: str
    value_policy: str
    events_checked: int
    _model: PreparedModel
    _state: bytes
    _event: bytes
    _reachable: frozenset
    _seal: object


def _model_handle(prepared):
    _need(type(prepared) is PreparedModel and prepared._seal is _SEAL
          and prepared.version == VERSION, 'INVALID_PREPARED_MODEL')
    return prepared


def _spec_handle(prepared):
    _need(type(prepared) is PreparedSpec and prepared._seal is _SEAL
          and prepared.version == VERSION, 'INVALID_PREPARED_SPEC')
    _model_handle(prepared._model)
    return prepared


def _receipt(model, meter, **fields):
    return dict(schema='GCTS-indexed-independent-check-v1', status='VERIFIED', verifier_version=VERSION,
                raw_model_sha256=model.raw_model_sha256,
                model_sha256=model.model_sha256, costs=meter.costs(), **fields)


def _selected(model, selected, meter):
    _need(type(selected) is list and all(type(i) is str for i in selected)
          and len(selected) == len(set(selected)))
    _need(all(i in model._rows for i in selected))
    totals, marks = {}, {}
    for pid in selected:
        meter.tick()
        p = model._anchors[pid]
        totals[p] = totals.get(p, 0) + 1
        _need(totals[p] <= 1)
        for slot, value in model._marks[pid]:
            meter.work()
            _need(slot not in marks or marks[slot][0] == value)
            marks[slot] = (value, marks.get(slot, (value, 0))[1] + 1)
    return totals, marks


def _context(model, selected, excluded, meter):
    _need(type(selected) is list and selected[:len(model._seeds)] == list(model._seeds))
    _selected(model, selected, meter)
    _need(type(excluded) is list)
    ids = []
    selected_ids = set(selected)
    for row in excluded:
        meter.tick()
        _record(row, ('id', 'reason'))
        pid = _string(row['id']); _string(row['reason'])
        _need(pid in model._rows and pid not in selected_ids)
        ids.append(pid)
    _need(ids == sorted(set(ids)))
    return {'selected': list(selected),
            'excluded': [{'id': r['id'], 'reason': r['reason']} for r in excluded]}


def prepare_model(raw_model, *, budget=None):
    meter, (raw_model,) = _inputs(budget, raw_model)
    _record(raw_model, ('schema', 'capacity', 'required', 'placements', 'seeds'))
    _eq(raw_model['schema'], 'GCTS-finite-point-instance-v1')
    cap = _int(raw_model['capacity'], 1)
    _need(type(raw_model['required']) is list and type(raw_model['placements']) is list
          and type(raw_model['seeds']) is list)
    required = [_point(p) for p in raw_model['required']]
    _need(len(required) == len(set(required)))
    rows = {}
    for row in raw_model['placements']:
        meter.tick()
        _record(row, ('id', 'type', 'translation', 't', 'm'))
        pid = _string(row['id']); _string(row['type']); _point(row['translation'])
        _need(pid not in rows and type(row['t']) is list and row['t']
              and type(row['m']) is list)
        positive, marks = {}, {}
        for term in row['t']:
            meter.tick()
            _need(type(term) is list and len(term) == 3)
            point = _point(term[:2]); units = _int(term[2], 1)
            _need(units <= cap and point not in positive)
            positive[point] = units
        for term in row['m']:
            meter.tick()
            _need(type(term) is list and len(term) == 4)
            slot = _point(term[:2]) + (_string(term[2]),)
            _string(term[3]); _need(slot not in marks)
            marks[slot] = term[3]
        rows[pid] = {'id': pid, 'type': row['type'], 'translation': list(row['translation']),
                     't': [[*p, positive[p]] for p in sorted(positive)],
                     'm': [[*s, marks[s]] for s in sorted(marks)]}
    seeds = list(raw_model['seeds'])
    _need(all(type(i) is str and i in rows for i in seeds)
          and len(seeds) == len(set(seeds)))
    req = set(required)
    for pid, row in rows.items():
        _need(pid in seeds or any(tuple(t[:2]) in req for t in row['t']))
    # Validate general seed legality before declaring specialization unsupported.
    seed_t, seed_m = {}, {}
    for pid in seeds:
        meter.tick()
        for x, y, u in rows[pid]['t']:
            p = (x, y); seed_t[p] = seed_t.get(p, 0) + u
            _need(seed_t[p] <= cap)
        for x, y, ch, value in rows[pid]['m']:
            slot = (x, y, ch)
            _need(slot not in seed_m or seed_m[slot] == value)
            seed_m[slot] = value
    if cap != 1 or any(len(r['t']) != 1 or r['t'][0][2] != 1 for r in rows.values()):
        raise UnsupportedProfile('FINITE_UNIT_ANCHOR_ROOT0_ONLY')
    canonical = {'schema': raw_model['schema'], 'capacity': cap,
                 'required': [list(p) for p in sorted(req)],
                 'placements': [rows[i] for i in sorted(rows)], 'seeds': seeds}
    ids = tuple(sorted(rows))
    anchors = {i: tuple(rows[i]['t'][0][:2]) for i in ids}
    marks = {i: tuple((tuple(m[:3]), m[3]) for m in rows[i]['m']) for i in ids}
    by_anchor, by_slot = {}, {}
    for i in ids:
        meter.tick()
        by_anchor.setdefault(anchors[i], []).append(i)
        for slot, value in marks[i]:
            by_slot.setdefault(slot, {}).setdefault(value, []).append(i)
    row_index = MappingProxyType({i: (rows[i]['type'], tuple(rows[i]['translation']),
                                    anchors[i], marks[i]) for i in ids})
    slot_index = MappingProxyType({s: MappingProxyType({v: tuple(vs) for v, vs in values.items()})
                                   for s, values in by_slot.items()})
    occupied = {anchors[i] for i in seeds}
    meter.tick()
    raw_sha = canonical_sha256(raw_model)
    canonical_bytes = _bytes(canonical)
    canonical_sha = hashlib.sha256(canonical_bytes).hexdigest()
    rank_index = MappingProxyType({i: j for j, i in enumerate(ids)})
    anchor_index = MappingProxyType(anchors)
    mark_index = MappingProxyType(marks)
    by_anchor_index = MappingProxyType({p: tuple(v) for p, v in by_anchor.items()})
    required_index = tuple(sorted(req))
    seed_index = tuple(seeds)
    point_index = tuple(sorted(req | set(anchors.values())))
    free_index = tuple(sorted(req - occupied))
    meter.tick()
    preparation_costs = tuple(meter.costs().items())
    # Only fixed-field immutable handle assembly remains after the sample.
    return PreparedModel(VERSION, raw_sha, canonical_sha, preparation_costs,
                         canonical_bytes, ids, rank_index, row_index,
                         anchor_index, mark_index, by_anchor_index, slot_index,
                         required_index, seed_index, point_index, free_index, _SEAL)


def _state(model, context, meter, native=False):
    selected, excluded = context['selected'], context['excluded']
    totals, marks = _selected(model, selected, meter)
    chosen, banned = set(selected), {r['id'] for r in excluded}
    assigned = {model._anchors[i]: i for i in selected if i not in model._seeds}
    # Index all conflicts, including mark-only points outside required/frontier.
    mark_conflicts = {}
    for slot, (value, _count) in marks.items():
        meter.tick()
        for other, ids in model._by_slot[slot].items():
            if other != value:
                for pid in ids:
                    meter.work()
                    mark_conflicts.setdefault(pid, []).append(slot)
    physical, eligible, active = [], [], []
    for p in model._free:
        meter.tick()
        if totals.get(p, 0):
            continue
        domain = [i for i in model._by_anchor.get(p, ())
                  if i not in chosen and i not in mark_conflicts]
        actual = [i for i in domain if i not in banned]
        physical.append({'point': list(p), 'candidates': domain})
        eligible.append({'point': list(p), 'generation': 0, 'candidates': actual})
        active.extend(actual)
    active.sort()
    state = {'schema': 'GCTS-unit-cell-normalized-state-v1', 'selected': list(selected),
             'assigned': [{'point': list(p), 'id': assigned[p]} for p in sorted(assigned)],
             'excluded': [{'id': r['id'], 'reason': r['reason']} for r in excluded],
             'physical_domains': physical, 'eligible_domains': eligible,
             'active_candidates': active,
             'forward_incidence': [[*r['point'], i, 1] for r in eligible for i in r['candidates']],
             'reverse_incidence': [{'id': i, 'points': [[*model._anchors[i], 1]]} for i in active]}
    if not native:
        return state
    candidate = []
    active_set = set(active)
    for pid in model._ids:
        meter.tick()
        point = model._anchors[pid]
        cap = [list(point)] if totals.get(point, 0) + 1 > 1 else []
        conflict = [list(s) for s in sorted(mark_conflicts.get(pid, ()))]
        candidate.append({'id': pid, 'selected': pid in chosen, 'excluded': pid in banned,
                          'legal': pid not in chosen and not cap and not conflict,
                          'active': pid in active_set, 'capacity_conflicts': cap,
                          'marking_conflicts': conflict})
    generations = set(model._required) | {model._anchors[i] for i in selected}
    full = {'schema': 'GCTS-finite-point-snapshot-v1', 'selected': list(selected),
            'excluded': state['excluded'],
            'totals': [[*p, totals.get(p, 0)] for p in model._points],
            'markings': [[*s, marks[s][0], marks[s][1]] for s in sorted(marks)],
            'point_generations': [[*p, 0] for p in sorted(generations)],
            'tile_generations': [[i, 0 if i in model._seeds else 1] for i in selected],
            'frontier': eligible, 'candidate_rows': candidate, 'active_candidates': active,
            'forward_incidence': state['forward_incidence'],
            'reverse_incidence': state['reverse_incidence']}
    return state, full


def _policy(value):
    _need(type(value) is str and value in (LEX, PERMUTED), 'INVALID_VALUE_POLICY')
    return value


def _decision(state):
    rows = state['eligible_domains']
    if not rows:
        return {'kind': 'SOLUTION', 'point': None, 'candidates': []}
    empty = [r for r in rows if not r['candidates']]
    forced = [r for r in rows if len(r['candidates']) == 1]
    if empty:
        row = min(empty, key=lambda r: r['point']); kind = 'DEAD'
    elif forced:
        row = min(forced, key=lambda r: r['point']); kind = 'FORCED'
    else:
        row = min(rows, key=lambda r: (r['generation'], len(r['candidates']), r['point']))
        kind = 'BRANCH'
    return {'kind': kind, 'point': list(row['point']), 'candidates': list(row['candidates'])}


def _choice(actual, expected, policy):
    _record(actual, ('kind', 'point', 'candidates'))
    _eq(actual['kind'], expected['kind']); _eq(actual['point'], expected['point'])
    ids = actual['candidates']
    _need(type(ids) is list and all(type(i) is str for i in ids))
    if expected['kind'] == 'BRANCH' and policy == PERMUTED:
        _need(len(ids) == len(set(ids)) and sorted(ids) == expected['candidates'])
    else:
        _eq(ids, expected['candidates'])


def _checked_state(model, state, meter):
    _need(type(state) is dict and 'selected' in state and 'excluded' in state)
    ctx = _context(model, state['selected'], state['excluded'], meter)
    expected = _state(model, ctx, meter)
    _eq(state, expected)
    return expected


def _checked_native(model, snapshot, meter):
    _record(snapshot, ('schema', 'selected', 'excluded', 'totals', 'markings',
                      'point_generations', 'tile_generations', 'frontier', 'candidate_rows',
                      'active_candidates', 'forward_incidence', 'reverse_incidence', 'trail_size'))
    ctx = _context(model, snapshot['selected'], snapshot['excluded'], meter)
    normalized, expected = _state(model, ctx, meter, native=True)
    _int(snapshot['trail_size'])
    _eq({k: v for k, v in snapshot.items() if k != 'trail_size'}, expected)
    return normalized


def _event(model, state, event, policy, meter):
    meter.tick()
    _record(event, ('kind', 'data'))
    kind, data = event['kind'], event['data']
    _need(type(kind) is str and type(data) is dict)
    if kind == 'INITIALIZED':
        _eq(data, {})
        _eq(state, _state(model, {'selected': list(model._seeds), 'excluded': []}, meter))
    elif kind == 'DECISION':
        _choice(data, _decision(state), policy)
    elif kind == 'PLACED':
        _record(data, ('id', 'reason', 'generation'))
        _string(data['reason']); _eq(data['generation'], 1)
        _need(bool(state['selected']) and state['selected'][-1] == data['id'])
    elif kind == 'EXCLUDED':
        _record(data, ('id', 'reason'))
        _need(any(_same(data, row) for row in state['excluded']))
    elif kind == 'ROLLED_BACK':
        if set(data) == {'checkpoint'}:
            _int(data['checkpoint'])
        else:
            _record(data, ('restored_state_sha256',))
            _eq(data['restored_state_sha256'], canonical_sha256(state))
    elif kind == 'SOLVE_RESULT':
        _record(data, ('status', 'nodes', 'reason'))
        _int(data['nodes']); _string(data['reason'])
        _need(data['status'] in ('FINITE_EXACT_SOLUTION', 'EXHAUSTED_FINITE_SEARCH', 'UNKNOWN'))
        if data['status'] == 'FINITE_EXACT_SOLUTION':
            _eq(data['reason'], 'SOLUTION'); _whole(model, state['selected'], state['excluded'], meter)
        elif data['status'] == 'EXHAUSTED_FINITE_SEARCH':
            _eq(data['reason'], 'EXHAUSTED')
        else:
            _need(data['reason'] in ('NODE_LIMIT', 'EXTERNAL_BUDGET'))
    else:
        raise IndexedOracleError('INVALID_EVENT')


def verify_point_snapshot(prepared_model, snapshot, event=None, *, value_policy=LEX, budget=None):
    meter, (snapshot, event) = _inputs(budget, snapshot, event)
    model = _model_handle(prepared_model); policy = _policy(value_policy)
    state = _checked_native(model, snapshot, meter)
    if event is not None:
        _event(model, state, event, policy, meter)
    meter.tick()
    return _receipt(model, meter, normalized_state=state,
                    snapshot_sha256=canonical_sha256(snapshot), state_sha256=canonical_sha256(state),
                    domains_sha256=canonical_sha256(state['eligible_domains']),
                    candidate_rows=len(model._ids), value_policy=policy,
                    trail_scope='NONNEGATIVE_PUBLIC_METADATA_ONLY')


def _expected_spec(model, value_policy, meter):
    domains = {p: tuple(i for i in model._by_anchor.get(p, ()) if i not in model._seeds)
               for p in model._free}
    seeds = set(model._seeds)
    occupied = {model._anchors[i] for i in seeds}
    pre = [{'id': i, 'anchor': list(model._anchors[i]),
            'reason': 'SEED_SELECTED' if i in seeds else 'SEED_ANCHOR_OCCUPIED'}
           for i in model._ids if model._anchors[i] in occupied]
    variables = [{'point': list(p), 'generation': 0, 'domain': list(domains[p])} for p in model._free]
    free_ids = {i for ids in domains.values() for i in ids}
    unaries = []
    seed_maps = {i: dict(model._marks[i]) for i in seeds}
    for pid in sorted(free_ids):
        meter.tick()
        pm = dict(model._marks[pid]); conflicts = []
        for sid in sorted(seeds):
            sm = seed_maps[sid]
            slots = [list(s) for s, value in pm.items() if s in sm and sm[s] != value]
            if slots:
                conflicts.append({'seed': sid, 'slots': sorted(slots)})
        unaries.append({'id': pid, 'allowed': not conflicts, 'seed_conflicts': conflicts})
    # Unlike the producer's forward-check state, this is a raw slot/value scan.
    # Build sparse forbidden ordered ID pairs using complete literal incidence.
    forbidden = {}
    for slot, values in model._by_slot.items():
        meter.tick()
        for av, ais in values.items():
            for bv, bis in values.items():
                if av == bv:
                    continue
                for ai in ais:
                    if ai not in free_ids:
                        continue
                    ap = model._anchors[ai]
                    for bi in bis:
                        meter.work()
                        if bi in free_ids and ap < model._anchors[bi]:
                            bp = model._anchors[bi]
                            forbidden.setdefault((ap, bp), set()).add((ai, bi))
    binary = []
    for (left, right), bad in sorted(forbidden.items()):
        meter.tick()
        binary.append({'left': list(left), 'right': list(right),
                       'allowed_rows': [sum(1 << j for j, b in enumerate(domains[right])
                                            if (a, b) not in bad) for a in domains[left]]})
    policy = dict(POLICY); policy['value'] = value_policy
    return {'schema': 'GCTS-unit-cell-csp-spec-v1', 'model': json.loads(model._canonical),
            'variables': variables, 'unaries': unaries, 'binary': binary,
            'preprocessed': pre, 'policy': policy}


def prepare_unit_cell_spec(prepared_model, sparse_spec, *, budget=None):
    meter, (sparse_spec,) = _inputs(budget, sparse_spec)
    model = _model_handle(prepared_model)
    _record(sparse_spec, ('schema', 'model', 'variables', 'unaries', 'binary', 'preprocessed', 'policy'))
    _record(sparse_spec['policy'], POLICY)
    policy = _policy(sparse_spec['policy']['value'])
    expected = _expected_spec(model, policy, meter)
    _eq(sparse_spec, expected)
    meter.tick(); body = _bytes(expected)
    return PreparedSpec(VERSION, hashlib.sha256(body).hexdigest(), policy,
                        tuple(meter.costs().items()), model, body, _SEAL)


def verify_normalized_state(prepared_spec, state, event=None, *, budget=None):
    meter, (state, event) = _inputs(budget, state, event)
    spec = _spec_handle(prepared_spec); model = spec._model
    checked = _checked_state(model, state, meter)
    if event is not None:
        _event(model, checked, event, spec.value_policy, meter)
    meter.tick()
    return _receipt(model, meter, spec_sha256=spec.spec_sha256, normalized_state=checked,
                    state_sha256=canonical_sha256(checked),
                    domains_sha256=canonical_sha256(checked['eligible_domains']))


def _metrics_check(metrics, state, nodes=None):
    keys = METRICS if nodes is not None else METRICS[1:]
    _record(metrics, keys)
    for key in keys:
        if key == 'candidate_removals':
            _record(metrics[key], ('SELECTED', 'EXCLUDED', 'CAPACITY', 'MARKING', 'NO_FRONTIER'))
            for value in metrics[key].values():
                _int(value)
        else:
            _int(metrics[key])
    if nodes is not None:
        _eq(metrics['nodes'], nodes)
    _eq(metrics['final_frontier_points'], len(state['eligible_domains']))
    _eq(metrics['final_active_candidates'], len(state['active_candidates']))
    _eq(metrics['final_edges'], len(state['forward_incidence']))
    for end, high in (('final_frontier_points', 'max_frontier_points'),
                      ('final_active_candidates', 'max_active_candidates'), ('final_edges', 'max_edges')):
        _need(metrics[high] >= metrics[end])


def _whole(model, selected, excluded, meter):
    context = _context(model, selected, excluded, meter)
    totals, _marks = _selected(model, context['selected'], meter)
    _need(all(totals.get(p, 0) == 1 for p in model._required))


def verify_point_result(prepared_model, result, *, budget=None):
    meter, (result,) = _inputs(budget, result)
    model = _model_handle(prepared_model)
    _record(result, ('schema', 'status', 'reason', 'nodes', 'selected', 'context',
                     'model', 'solution_verified', 'metrics'))
    _eq(result['schema'], 'GCTS-finite-point-solve-result-v1')
    _eq(result['model'], json.loads(model._canonical))
    _record(result['context'], ('selected', 'excluded'))
    ctx = _context(model, result['context']['selected'], result['context']['excluded'], meter)
    _int(result['nodes'])
    status = result['status']
    _need(status in ('FINITE_EXACT_SOLUTION', 'EXHAUSTED_FINITE_SEARCH', 'UNKNOWN'))
    if status == 'FINITE_EXACT_SOLUTION':
        _eq(result['reason'], 'SOLUTION'); _eq(result['solution_verified'], True)
        _need(type(result['selected']) is list and result['selected'][:len(ctx['selected'])] == ctx['selected'])
        _whole(model, result['selected'], ctx['excluded'], meter)
    else:
        _eq(result['solution_verified'], False); _eq(result['selected'], ctx['selected'])
        _need(result['reason'] in (('EXHAUSTED',) if status == 'EXHAUSTED_FINITE_SEARCH'
                                  else ('NODE_LIMIT', 'EXTERNAL_BUDGET')))
    state = _state(model, {'selected': result['selected'], 'excluded': ctx['excluded']}, meter)
    _metrics_check(result['metrics'], state)
    meter.tick()
    return _receipt(model, meter, status_checked=status,
                    scope='WHOLE_SAT_OR_NATIVE_ENVELOPE_EXHAUSTION_REQUIRES_SAME_CONTEXT_CSP_UNSAT')


def _proof(model, root, entry, policy, meter):
    pending = [(root, entry)]; count = 0
    while pending:
        meter.tick()
        node, ctx = pending.pop()
        _need(type(node) is dict and type(node.get('kind')) is str)
        state = _state(model, ctx, meter); choice = _decision(state)
        _eq(node.get('domains_sha256'), canonical_sha256(state['eligible_domains']))
        kind = node['kind']; count += 1
        if kind == 'DEAD':
            _record(node, ('kind', 'domains_sha256', 'point'))
            _eq(choice['kind'], 'DEAD'); _eq(node['point'], choice['point'])
        elif kind == 'FORCED':
            _record(node, ('kind', 'domains_sha256', 'point', 'id', 'child'))
            _eq(choice['kind'], 'FORCED'); _eq(node['point'], choice['point'])
            _eq(node['id'], choice['candidates'][0])
            pending.append((node['child'], {'selected': ctx['selected'] + [node['id']],
                                           'excluded': ctx['excluded']}))
        elif kind == 'BRANCH':
            _record(node, ('kind', 'domains_sha256', 'point', 'candidates', 'id', 'child', 'remainder'))
            _eq(choice['kind'], 'BRANCH')
            _choice({'kind': kind, 'point': node['point'], 'candidates': node['candidates']}, choice, policy)
            _need(bool(node['candidates'])); _eq(node['id'], node['candidates'][0])
            pid = node['id']
            child = {'selected': ctx['selected'] + [pid], 'excluded': ctx['excluded']}
            rest = {'selected': list(ctx['selected']),
                    'excluded': sorted(ctx['excluded'] + [{'id': pid, 'reason': 'EXHAUSTED_CHILD'}],
                                       key=lambda row: row['id'])}
            pending.append((node['remainder'], rest)); pending.append((node['child'], child))
        else:
            raise IndexedOracleError('INVALID_UNSAT_NODE')
    return count


def _event_transition(model, state, event, previous, previous_event, reachable, meter):
    kind, data = event['kind'], event['data']
    if previous is None:
        _eq(kind, 'INITIALIZED')
    elif kind == 'PLACED':
        pid = data['id']
        _need(any(pid in row['candidates'] for row in previous['eligible_domains']))
        if data['reason'] in ('FORCED', 'BRANCH'):
            _need(previous_event is not None and previous_event['kind'] == 'DECISION')
            _eq(previous_event['data']['kind'], data['reason'])
            _eq(previous_event['data']['candidates'][0], pid)
        _eq(state['selected'], previous['selected'] + [pid])
        _eq(state['excluded'], previous['excluded'])
    elif kind == 'EXCLUDED':
        _eq(state['selected'], previous['selected'])
        _eq(state['excluded'], sorted(previous['excluded'] + [data], key=lambda row: row['id']))
    elif kind == 'DECISION':
        _eq(state, previous)
    elif kind == 'ROLLED_BACK':
        _need(canonical_sha256(state) in reachable, 'UNREACHED_ROLLBACK_STATE')
    elif kind == 'INITIALIZED':
        raise IndexedOracleError('DUPLICATE_INITIALIZATION')
    elif kind == 'SOLVE_RESULT':
        if data['status'] == 'FINITE_EXACT_SOLUTION':
            # A complete SAT history cannot jump over decisions/placements.
            _eq(state, previous)
            _need(previous_event is not None and previous_event['kind'] == 'DECISION')
            _eq(previous_event['data'], {'kind': 'SOLUTION', 'point': None, 'candidates': []})
        else:
            # Owned UNKNOWN/exhaustion may restore entry before notification.
            _need(canonical_sha256(state) in reachable, 'UNREACHED_RESULT_STATE')
    meter.tick()


def _advance_cursor(model, checked, event, cursor, policy, meter):
    _event(model, checked, event, policy, meter)
    if cursor is None:
        previous, previous_event, reachable, count = None, None, frozenset(), 0
    else:
        _need(type(cursor) is AuditCursor and cursor._seal is _SEAL
              and cursor.version == VERSION and cursor._model is model
              and cursor.model_sha256 == model.model_sha256
              and cursor.raw_model_sha256 == model.raw_model_sha256
              and cursor.value_policy == policy, 'INVALID_AUDIT_CURSOR')
        previous, previous_event = json.loads(cursor._state), json.loads(cursor._event)
        reachable, count = cursor._reachable, cursor.events_checked
    _event_transition(model, checked, event, previous, previous_event, reachable, meter)
    body = _bytes(checked); sha = hashlib.sha256(body).hexdigest()
    next_cursor = AuditCursor(VERSION, model.model_sha256, model.raw_model_sha256, policy,
                              count + 1, model, body, _bytes(event), reachable | {sha}, _SEAL)
    meter.tick()
    return (_receipt(model, meter, normalized_state=checked, state_sha256=sha,
                     domains_sha256=canonical_sha256(checked['eligible_domains']),
                     events_checked=count + 1, rollback_scope='EXACT_REACHABLE_PUBLIC_STATE_HASH'), next_cursor)


def verify_event(prepared_model, state, event, cursor=None, *, value_policy=LEX, budget=None):
    meter, (state, event) = _inputs(budget, state, event)
    model = _model_handle(prepared_model); policy = _policy(value_policy)
    checked = _checked_state(model, state, meter)
    return _advance_cursor(model, checked, event, cursor, policy, meter)


def verify_point_event(prepared_model, snapshot, event, cursor=None, *, value_policy=LEX, budget=None):
    """Fused full native plus transition audit: no duplicate state enumeration."""
    meter, (snapshot, event) = _inputs(budget, snapshot, event)
    model = _model_handle(prepared_model); policy = _policy(value_policy)
    checked = _checked_native(model, snapshot, meter)
    receipt, next_cursor = _advance_cursor(model, checked, event, cursor, policy, meter)
    receipt['snapshot_sha256'] = canonical_sha256(snapshot)
    receipt['candidate_rows'] = len(model._ids)
    receipt['trail_scope'] = 'NONNEGATIVE_PUBLIC_METADATA_ONLY'
    receipt['costs'] = meter.costs()
    return receipt, next_cursor


def verify_normalized_event(prepared_spec, state, event, cursor=None, *, budget=None):
    """Fused full normalized plus transition audit bound to prepared masks."""
    meter, (state, event) = _inputs(budget, state, event)
    spec = _spec_handle(prepared_spec); model = spec._model
    checked = _checked_state(model, state, meter)
    receipt, next_cursor = _advance_cursor(model, checked, event, cursor, spec.value_policy, meter)
    receipt['spec_sha256'] = spec.spec_sha256
    receipt['costs'] = meter.costs()
    return receipt, next_cursor


def _events(model, events, policy, meter):
    _need(type(events) is list and bool(events))
    previous, previous_event, reachable = None, None, set()
    for seq, row in enumerate(events):
        meter.tick()
        _record(row, ('seq', 'kind', 'data', 'snapshot', 'domains_sha256', 'state_sha256'))
        _eq(row['seq'], seq)
        state = _checked_state(model, row['snapshot'], meter)
        sha = canonical_sha256(state)
        _eq(row['state_sha256'], sha)
        _eq(row['domains_sha256'], canonical_sha256(state['eligible_domains']))
        event = {'kind': row['kind'], 'data': row['data']}
        _event(model, state, event, policy, meter)
        _event_transition(model, state, event, previous, previous_event, reachable, meter)
        previous, previous_event = state, event; reachable.add(sha)
    return previous


def verify_unit_cell_result(prepared_spec, result, normalized_events=None, *, budget=None):
    meter, (result, normalized_events) = _inputs(budget, result, normalized_events)
    spec = _spec_handle(prepared_spec); model = spec._model
    _record(result, ('schema', 'status', 'reason', 'nodes', 'selected', 'context',
                     'solution_verified', 'metrics', 'certificate', 'model_sha256',
                     'spec_sha256', 'entry', 'final'))
    _eq(result['schema'], 'GCTS-unit-cell-csp-solve-result-v1')
    _eq(result['model_sha256'], model.model_sha256); _eq(result['spec_sha256'], spec.spec_sha256)
    _record(result['context'], ('selected', 'excluded'))
    entry = _context(model, result['context']['selected'], result['context']['excluded'], meter)
    _eq(result['entry'], _state(model, entry, meter))
    final = _checked_state(model, result['final'], meter)
    _eq(result['selected'], final['selected'])
    _int(result['nodes']); _metrics_check(result['metrics'], final, result['nodes'])
    cert = result['certificate']
    _record(cert, ('schema', 'kind', 'model_sha256', 'spec_sha256', 'entry', 'root', 'solution'))
    _eq(cert['schema'], 'GCTS-unit-cell-csp-certificate-v1')
    _eq(cert['model_sha256'], model.model_sha256); _eq(cert['spec_sha256'], spec.spec_sha256)
    _eq(cert['entry'], entry)
    kind = cert['kind']; _need(kind in ('SAT', 'UNSAT', 'INCOMPLETE'))
    proof_nodes = 0
    if kind == 'SAT':
        _eq(result['status'], 'FINITE_EXACT_SOLUTION'); _eq(result['reason'], 'SOLUTION')
        _eq(result['solution_verified'], True); _eq(cert['root'], None)
        _need(final['selected'][:len(entry['selected'])] == entry['selected'])
        _need(all(any(_same(row, current) for current in final['excluded']) for row in entry['excluded']))
        _whole(model, final['selected'], entry['excluded'], meter)
        _eq(cert['solution'], final['assigned'])
    elif kind == 'UNSAT':
        _eq(result['status'], 'EXHAUSTED_FINITE_SEARCH'); _eq(result['reason'], 'EXHAUSTED')
        _eq(result['solution_verified'], False); _eq(cert['solution'], None)
        _eq(final, result['entry'])
        proof_nodes = _proof(model, cert['root'], entry, spec.value_policy, meter)
    else:
        _eq(result['status'], 'UNKNOWN'); _eq(result['solution_verified'], False)
        _need(result['reason'] in ('NODE_LIMIT', 'EXTERNAL_BUDGET'))
        _eq(cert['root'], None); _eq(cert['solution'], None); _eq(final, result['entry'])
    if normalized_events is not None:
        end = _events(model, normalized_events, spec.value_policy, meter)
        if normalized_events[-1]['kind'] == 'SOLVE_RESULT':
            _eq(end, final)
        else:
            _need(kind == 'INCOMPLETE' and result['reason'] == 'EXTERNAL_BUDGET')
        notifications = [r for r in normalized_events if r['kind'] == 'SOLVE_RESULT']
        if notifications:
            _eq(notifications[-1]['data'], {'status': result['status'], 'nodes': result['nodes'],
                                           'reason': result['reason']})
        else:
            _need(kind == 'INCOMPLETE' and result['reason'] == 'EXTERNAL_BUDGET')
    meter.tick()
    return _receipt(model, meter, spec_sha256=spec.spec_sha256, certificate_kind=kind,
                    proof_nodes_checked=proof_nodes, value_policy=spec.value_policy,
                    event_scope='CERTIFICATE_ENTRY_FINAL_ONLY' if normalized_events is None
                    else 'COMPLETE_NORMALIZED_EVENT_BODIES_CHECKED',
                    complete_finite_negative=(kind == 'UNSAT'),
                    check_scope='PREPARED_FULL_EXPORT_MASKS_AND_COMPLETE_CERTIFICATE_NO_SEARCH')


def checkpoint(prepared_model, state, *, native=False, budget=None):
    meter, (state,) = _inputs(budget, state)
    model = _model_handle(prepared_model)
    _need(type(native) is bool)
    if native:
        _checked_native(model, state, meter)
    else:
        _checked_state(model, state, meter)
    meter.tick(); body = _bytes(state)
    return CheckpointReceipt(VERSION, model.raw_model_sha256, model.model_sha256, native,
                             hashlib.sha256(body).hexdigest(), tuple(meter.costs().items()),
                             model, body, _SEAL)


def verify_rollback(prepared_model, receipt, state, *, budget=None):
    meter, (state,) = _inputs(budget, state)
    model = _model_handle(prepared_model)
    _need(type(receipt) is CheckpointReceipt and receipt._seal is _SEAL
          and receipt._model is model and receipt.version == VERSION
          and receipt.raw_model_sha256 == model.raw_model_sha256
          and receipt.model_sha256 == model.model_sha256, 'INVALID_CHECKPOINT_BINDING')
    if receipt.native:
        normalized = _checked_native(model, state, meter)
    else:
        normalized = _checked_state(model, state, meter)
    _eq(state, json.loads(receipt._canonical))
    _eq(canonical_sha256(state), receipt.state_sha256)
    meter.tick()
    return _receipt(model, meter, checkpoint_sha256=receipt.state_sha256,
                    normalized_state=normalized, native_public_fields=receipt.native,
                    rollback_scope='EXACT_FULL_BOUND_PUBLIC_CHECKPOINT_INCLUDING_TRAIL_SIZE_IF_NATIVE')


def _observation(model, state, inventory_version, marking_version, meter):
    _need(type(inventory_version) is str and bool(inventory_version)
          and type(marking_version) is str and bool(marking_version))
    choice = _decision(state)
    _eq(choice['kind'], 'BRANCH')
    bits = bytearray((len(model._ids) + 7) // 8)
    for pid in state['active_candidates']:
        meter.tick()
        rank = model._rank[pid]
        bits[rank // 8] |= 1 << (rank % 8)
    return {'schema': 'GCTS-cluster-receptor-observation-v1',
            'model_sha256': model.model_sha256, 'inventory_version': inventory_version,
            'marking_version': marking_version, 'value_policy': PERMUTED,
            'selected': list(state['selected']),
            'excluded': [r['id'] for r in state['excluded']],
            'point': choice['point'], 'generation': 0,
            'incident_domain': choice['candidates'],
            'active_bitset': {'encoding': 'LSB0_HEX',
                              'id_order_sha256': canonical_sha256(list(model._ids)),
                              'universe_size': len(model._ids), 'hex': bytes(bits).hex()}}


def verify_cluster_observation(prepared_model, state, observation, *,
                               inventory_version='BASE', marking_version='MODEL', budget=None):
    meter, (state, observation) = _inputs(budget, state, observation)
    model = _model_handle(prepared_model)
    checked = _checked_state(model, state, meter)
    expected = _observation(model, checked, inventory_version, marking_version, meter)
    _eq(observation, expected)
    meter.tick()
    return _receipt(model, meter, observation_sha256=canonical_sha256(expected),
                    state_sha256=canonical_sha256(checked),
                    active_candidates=len(checked['active_candidates']),
                    scope='FULL_SCHEDULER_POINT_DOMAIN_AND_REVERSIBLE_ACTIVE_BITSET')


def _cluster_row(model, state, observation, raw, index, seen, counts, meter):
    expected = {'index': index, 'raw_cluster': raw, 'id': None, 'shared_ids': [],
                'new_ids': [], 'incident_ids': [], 'accepted': False, 'rejection': None}
    counts['clusters_proposed'] += 1
    if type(raw) is not dict or set(raw) != {'id', 'inventory_version', 'marking_version', 'members'}:
        expected['rejection'] = 'CLUSTER_SHAPE'
        return expected
    cid = raw['id']
    if type(cid) is not str or not cid or cid in seen:
        expected['rejection'] = 'CLUSTER_ID'
        return expected
    seen.add(cid); expected['id'] = cid
    if (not _same(raw['inventory_version'], observation['inventory_version'])
            or not _same(raw['marking_version'], observation['marking_version'])):
        expected['rejection'] = 'CLUSTER_VERSION'
        return expected
    members = raw['members']
    if (type(members) is not list or not members or len(members) > 256
            or any(type(i) is not str for i in members) or len(members) != len(set(members))):
        expected['rejection'] = 'CLUSTER_MEMBERS'
        return expected
    if any(i not in model._rows for i in members):
        expected['rejection'] = 'UNKNOWN_MEMBER'
        return expected
    selected = set(state['selected']); banned = {r['id'] for r in state['excluded']}
    active = set(state['active_candidates']); domain = set(observation['incident_domain'])
    shared = [i for i in members if i in selected]
    new = [i for i in members if i not in selected]
    expected.update(shared_ids=shared, new_ids=new, incident_ids=[i for i in new if i in domain])
    if any(i in banned for i in members):
        expected['rejection'] = 'EXCLUDED_MEMBER'
        return expected
    if any(i not in active for i in new):
        expected['rejection'] = 'INACTIVE_MEMBER'
        return expected
    union = state['selected'] + new
    totals = {}
    for pid in union:
        meter.tick()
        counts['joint_members_checked'] += 1
        counts['joint_t_terms_checked'] += 1
        p = model._anchors[pid]; totals[p] = totals.get(p, 0) + 1
        if totals[p] > 1:
            expected['rejection'] = 'CAPACITY_CONFLICT'
            return expected
    marks = {}
    for pid in union:
        meter.tick()
        for slot, value in model._marks[pid]:
            meter.work()
            counts['joint_m_terms_checked'] += 1
            if slot in marks and marks[slot] != value:
                expected['rejection'] = 'MARKING_CONFLICT'
                return expected
            marks[slot] = value
    if not expected['incident_ids']:
        expected['rejection'] = 'NO_INCIDENT_MEMBER'
    else:
        expected['accepted'] = True
    return expected


def _packet(model, state, observation, evidence, meter):
    packet = evidence['raw_packet']
    pending = [(packet, 0)]
    while pending:
        value, depth = pending.pop()
        _need(depth <= 64, 'SERIALIZED_PACKET_EXCEEDS_PUBLIC_DEPTH')
        if type(value) is dict:
            pending.extend((v, depth + 1) for v in value.values())
        elif type(value) is list:
            pending.extend((v, depth + 1) for v in value)
    rejection, rows = None, []
    counts = dict.fromkeys(PROPOSAL_METRICS, 0)
    counts['branch_observations'] = counts['proposer_calls'] = 1
    # Unserializable original objects cannot be recovered from raw_packet=null.
    # Verify only its declared source refusal plus complete logical fallback.
    if packet is None and evidence['packet_rejection'] == 'NON_JSON_PACKET':
        rejection = 'NON_JSON_PACKET'
    elif packet is not None:
        if (type(packet) is not dict
                or set(packet) != {'schema', 'observation_sha256', 'clusters'}
                or not _same(packet.get('schema'), 'GCTS-concrete-cluster-proposals-v1')
                or type(packet.get('observation_sha256')) is not str
                or type(packet.get('clusters')) is not list):
            rejection = 'PACKET_SHAPE'
        elif not _same(packet['observation_sha256'], canonical_sha256(observation)):
            rejection = 'PACKET_BINDING'
        elif len(packet['clusters']) > 64:
            rejection = 'PACKET_SIZE'
        else:
            seen = set()
            for index, cluster in enumerate(packet['clusters']):
                meter.tick()
                row = _cluster_row(model, state, observation, cluster, index, seen, counts, meter)
                rows.append(row)
                counts['clusters_accepted' if row['accepted'] else 'clusters_rejected'] += 1
    counts['packets_rejected'] = int(rejection is not None)
    ordered = []
    for row in rows:
        if row['accepted']:
            for pid in row['incident_ids']:
                if pid not in ordered:
                    ordered.append(pid)
    ordered.extend(i for i in observation['incident_domain'] if i not in ordered)
    counts['branch_order_changes'] = int(ordered != observation['incident_domain'])
    return rejection, rows, ordered, counts


def verify_cluster_receipt(prepared_model, state, evidence, *,
                           inventory_version='BASE', marking_version='MODEL', budget=None):
    """Complete final ordering/expansion check; partial exceptions not admitted.

    Cumulative counters are shape-checked and bounded below by independently
    reconstructed current-attempt work. Exact whole-history counter sites and
    callback isolation remain separately source/qualification-checked.
    """
    meter, (state, evidence) = _inputs(budget, state, evidence)
    model = _model_handle(prepared_model)
    checked = _checked_state(model, state, meter)
    _record(evidence, ('schema', 'index', 'status', 'observation', 'observation_sha256',
                       'raw_packet', 'packet_rejection', 'clusters', 'ordered_candidates',
                       'logical_before_sha256', 'logical_after_sha256', 'value_policy',
                       'counters', 'error_type'))
    _eq(evidence['schema'], 'GCTS-cluster-proposal-receipt-v1')
    _int(evidence['index']); _eq(evidence['status'], 'VALIDATED')
    _eq(evidence['error_type'], None); _eq(evidence['value_policy'], PERMUTED)
    observation = _observation(model, checked, inventory_version, marking_version, meter)
    _eq(evidence['observation'], observation)
    sha = canonical_sha256(observation)
    for key in ('observation_sha256', 'logical_before_sha256', 'logical_after_sha256'):
        _eq(evidence[key], sha)
    rejection, rows, ordered, counts = _packet(model, checked, observation, evidence, meter)
    _eq(evidence['packet_rejection'], rejection)
    _eq(evidence['clusters'], rows); _eq(evidence['ordered_candidates'], ordered)
    _record(evidence['counters'], PROPOSAL_METRICS)
    for key in PROPOSAL_METRICS:
        _int(evidence['counters'][key])
        _need(evidence['counters'][key] >= counts[key])
    meter.tick()
    return _receipt(model, meter, observation_sha256=sha,
                    evidence_sha256=canonical_sha256(evidence), ordered_candidates=ordered,
                    current_attempt_counts=counts, accepted_clusters=counts['clusters_accepted'],
                    counter_scope='CUMULATIVE_SHAPE_AND_CURRENT_ATTEMPT_LOWER_BOUND',
                    nonJSON_scope='UNSERIALIZABLE_ORIGIN_SOURCE_REFUSAL_ONLY_LOGICAL_FALLBACK_CHECKED',
                    exception_scope='ONLY_FINAL_VALIDATED_RECORDS_COMPLETE_PARTIAL_RECORDS_UNADMITTED')
