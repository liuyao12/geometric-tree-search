"""Administrative saved-byte/JSON display extraction only. No producer imports."""
from pathlib import Path
import json,hashlib,base64,zlib,collections,copy,time
N=Path('/private/tmp/gcts-cluster-receptors-20261027-v2')
A=N/'actual-v1'
D=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B/actual-data-draft-v1')
CAP=67108864
started=time.perf_counter()
def cbytes(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(cbytes(x)).hexdigest()
def strict(b):
 def pairs(xs):
  d={}
  for k,v in xs:
   assert k not in d,'duplicate key';d[k]=v
  return d
 def bad(x):raise ValueError(x)
 return json.loads(b,object_pairs_hook=pairs,parse_constant=bad)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def body(r):
 p=Path(r['path']);assert p.parent in [A,N/'root'],p
 b=p.read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
def read(r):return strict(body(r))
def write(name,x):
 p=D/name;p.write_text(json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n');return pin(p)
def inflate(env,limit):
 assert set(env)=={'schema','encoding','record_count','raw_bytes','raw_sha256','compressed_bytes','compressed_sha256','data_base64'}
 assert type(env['raw_bytes'])is int and 0<=env['raw_bytes']<=limit and type(env['record_count'])is int
 comp=base64.b64decode(env['data_base64'],validate=True)
 assert base64.b64encode(comp).decode()==env['data_base64'] and len(comp)==env['compressed_bytes'] and hashlib.sha256(comp).hexdigest()==env['compressed_sha256']
 dec=zlib.decompressobj();chunks=[];size=0
 for i in range(0,len(comp),65536):
  pending=comp[i:i+65536]
  while pending:
   before=len(pending);part=dec.decompress(pending,65536);pending=dec.unconsumed_tail
   assert not dec.unused_data and (part or len(pending)<before)
   size+=len(part);assert size<=limit;chunks.append(part)
 raw=b''.join(chunks)
 assert dec.eof and not dec.unused_data and not dec.unconsumed_tail and size==env['raw_bytes'] and hashlib.sha256(raw).hexdigest()==env['raw_sha256']
 assert raw.count(b'\n')==env['record_count'] and raw.endswith(b'\n')
 return raw
capturep=N/'root/cluster-N2-owned-complete-capture-association-v1.json';capture=strict(capturep.read_bytes())
assert pin(capturep)=={'path':str(capturep),'bytes':3290,'sha256':'820884a1a403ad54939dc12e46932028fe3e4fe0efe036574dd18e4e099820b7'}
result=read(capture['result']);index=read(result['outcome']['index']);custody=read(capture['custody']);plan=read(custody['plan'])
allrefs=result['artifacts']+[capture['result']]
assert len(allrefs)==184 and len({r['path'] for r in allrefs})==184
assert sum(r['bytes'] for r in allrefs)==capture['named_stored_bytes']==145355866
for r in allrefs:body(r)
initial=read(index['initial_policy']);trained=read(index['frozen_trained_policy'])
assert sha(initial)==index['initial_policy']['sha256'] and sha(trained)==index['frozen_trained_policy']['sha256']
metadata={r['record']['path']:dict(r,phase='TRAINING') for r in index['training']}
metadata.update({r['record']['path']:dict(r,phase='EVALUATION') for r in index['evaluation']})
costs={r['body']['path']:r for r in index['arm_costs']}
assert len(metadata)==112 and len(costs)==112
summaries={};provenance=[];sample_candidates=[];board=None
whole_counts=collections.Counter();inner_counts=collections.Counter();check_statuses=collections.Counter();observed_calls=collections.Counter();catalogue={r['id']:r for r in read(index['legacy_qualification'])['palette_receipt']['palette']}
def describe_check(v):
 if v is None:return None
 return {'schema':v.get('schema'),'status':v.get('status'),'verifier_version':v.get('verifier_version'),'canonical_sha256':sha(v),'costs':copy.deepcopy(v.get('costs')),'status_checked':v.get('status_checked'),'scope':v.get('scope'),'certificate_kind':v.get('certificate_kind')}
for ordinal,cost in enumerate(index['arm_costs']):
 ref=cost['body'];m=metadata[ref['path']];env=read(ref)
 assert env['schema']=='GCTS-lossless-cluster-main-arm-v1' and env['encoding']=='CANONICAL_JSON_ZLIB1_BASE64' and env['record_count']==1
 raw=inflate(env,CAP);a=strict(raw);assert cbytes(a)==raw and a['schema']=='GCTS-cluster-receptor-main-arm-v1'
 assert a['engine']==m['engine'] and a['strategy']==('TRAINED_CLUSTER' if m['phase']=='TRAINING' else m['strategy'])
 ret=a['return'];whole_counts[(m['phase'],a['engine'],ret['status'])]+=1
 log=a['audit_log'];assert log['schema']=='GCTS-lossless-runtime-audit-log-v1' and log['encoding']=='CANONICAL_JSONL_ZLIB1_BASE64'
 lograw=inflate(log,268435456);loglines=lograw.splitlines();assert len(loglines)==log['record_count']
 rows=[];rowmeta=[];offset=0
 for i,line in enumerate(loglines):
  assert len(line)+1<=CAP;v=strict(line);assert cbytes(v)==line+b'\n';rows.append(v);inner_counts[v['kind']]+=1
  entry={'index':i,'kind':v['kind'],'raw_offset':offset,'raw_bytes':len(line)+1,'raw_sha256':hashlib.sha256(line+b'\n').hexdigest()};offset+=len(line)+1
  if 'event'in v:entry['event']=copy.deepcopy(v['event'])
  for key in ['verification','observation_check','state_verification','independent_verification']:
   if key in v:
    vv=v[key];entry[key]={'schema':vv.get('schema'),'status':vv.get('status'),'canonical_sha256':sha(vv),'state_sha256':vv.get('state_sha256'),'costs':vv.get('costs')};check_statuses[(key,str(vv.get('status')))]+=1
  rowmeta.append(entry)
 checks={k:describe_check(a[k]) for k in ['result_check','final_check','rollback_check','independent_actor_check']}
 for k,v in checks.items():
  if v:check_statuses[(k,str(v['status']))]+=1
 actor=a['actor_final'];actorcost=None if actor is None else copy.deepcopy(actor['costs'])
 if actor is not None:
  observed_calls['main_actor_instances']+=1;observed_calls['main_actor_snapshot_independent_checks']+=int(a['independent_actor_check'] is not None)
  for k in ['calls','fresh_calls','pending_reuses','pending_drops','tokens','stop_tokens','candidate_feature_visits','budget_callbacks']:
   observed_calls['actor_'+k]+=actorcost.get(k,0)
 pm=a['proposal_metrics']
 for k,v in pm.items():observed_calls['kernel_'+k]+=v
 observed_calls['main_solves']+=1;observed_calls['main_explicit_rollbacks']+=1
 observed_calls['L_model_preparations']+=1;observed_calls['L_spec_preparations']+=int(a['indexed_spec_preparation'] is not None);observed_calls['C_model_preparations']+=int(a['cluster_preparation'] is not None)
 fields={'ordinal':ordinal,'source_ref':ref,'phase':m['phase'],'engine':a['engine'],'strategy':a['strategy'],'seed':a['seed'],'marking_version':a['marking_version'],'context':{k:copy.deepcopy(a['input'][k]) for k in ['width','steps','initial','final','negative_final']},'status':ret['status'],'reason':ret['reason'],'nodes':ret['nodes'],'metrics':copy.deepcopy(ret['metrics']),'search_window':copy.deepcopy(a['search_window']),'proposal_metrics':copy.deepcopy(pm),'actor_costs':actorcost,'actor_config':None if actor is None else copy.deepcopy(actor['config']),'actor_policy_sha256':None if actor is None else actor['policy_sha256'],'actor_snapshot_sha256':None if actor is None else sha(actor),'through_complete_body_write_seconds':cost['through_complete_body_write_seconds'],'body_write_clock_scope':cost['scope'],'elapsed_before_outer_body_serialization':a['elapsed_before_outer_body_serialization'],'preparations':{k:copy.deepcopy(a[k]) for k in ['indexed_preparation','indexed_spec_preparation','cluster_preparation']},'recorded_checks':checks,'restored_entry_exact':a['restored_entry_exact'],'feedback_required_points':a['feedback_required_points'],'max_verified_filled':a['max_verified_filled'],'trace_event_count':len(a['trace']),'cleanup_event_count':len(a['cleanup_trace']),'proposal_record_count':len(a['proposal_evidence']),'full_outer_original':{k:env[k] for k in ['schema','encoding','raw_bytes','raw_sha256','compressed_bytes','compressed_sha256','record_count']},'inner_audit':{k:log[k] for k in ['schema','encoding','raw_bytes','raw_sha256','compressed_bytes','compressed_sha256','record_count']}}
 summaries[ref['path']]=fields
 provenance.append({'source_ref':ref,'ordinal':ordinal,'full_outer_original':fields['full_outer_original'],'inner_audit':fields['inner_audit'],'all_inner_row_descriptors':rowmeta,'checks':checks,'canonical_original_byte_identity':True,'model_sha256':sha(a['model']),'spec_sha256':None if a['spec']is None else sha(a['spec'])})
 # Saved-proposal/state -> next nonforced decision -> actual placement joins only.
 callmap={} if actor is None else {c['index']:c for c in actor['calls']}
 placed_by_call={};per_arm_candidates=[]
 for ri,row in enumerate(rows):
  if row['kind']!='PROPOSAL_VALIDATED':continue
  receipt=row['producer_receipt'];call=callmap.get(receipt['index'])
  if not call or receipt['status']!='VALIDATED' or row['independent_verification']['status']!='VERIFIED_COMPLETE_CLUSTER_ORDER':continue
  assert call['observation']==receipt['observation'] and call['packet']==receipt['raw_packet'] and call['observation_sha256']==receipt['observation_sha256']==sha(receipt['observation'])
  after=[(j,v) for j,v in enumerate(rows[ri+1:],ri+1) if v['kind']=='NATIVE_EVENT']
  if len(after)<2:continue
  di,dr=after[0];pi,pr=after[1];de=dr['event'];pe=pr['event']
  if de['kind']!='DECISION' or de['data'].get('kind')!='BRANCH' or pe['kind']!='PLACED' or pe['data'].get('reason')=='FORCED':continue
  if de['data'].get('point')!=receipt['observation']['point'] or de['data'].get('candidates')!=receipt['ordered_candidates']:continue
  if dr['verification']['state_sha256']!=row['state_verification']['state_sha256']:continue
  actual=pe['data']['id'];placed_by_call[receipt['index']]=actual
  for cr in receipt['clusters']:
   if cr['accepted'] is not True or actual not in cr['incident_ids']:continue
   cluster=cr['raw_cluster'];mode=call['mode'];fresh=mode=='FRESH' and len(cluster['members'])>=2
   origin=callmap.get(call['origin_call']);pending=(mode=='PENDING_REUSE' and origin is not None and call['origin_call']<call['index'] and actual in origin['original_members'][1:] and placed_by_call.get(call['origin_call'])==origin['original_members'][0])
   if not (fresh or pending):continue
   union=set(receipt['observation']['selected'])|set(cluster['members']);placement_rows=[x for x in a['model']['placements'] if x['id']in union];assert {x['id'] for x in placement_rows}==union and len(placement_rows)==len(union)
   contextkey=(a['strategy'],sha(a['input']))
   candidate={'ordinal':ordinal,'call_index':call['index'],'mode':mode,'context_key':list(contextkey),'fresh_criterion':fresh,'pending_later_nonforced_criterion':pending,'sample':{'id':'cr-saved-'+str(ordinal)+'-'+str(call['index']),'label':m['phase'].lower()+' '+a['strategy']+' '+a['engine']+' '+mode+' '+''.join(a['input']['initial']),'engine':a['engine'],'strategy':a['strategy'],'observation':copy.deepcopy(receipt['observation']),'cluster':copy.deepcopy(cluster),'placement_rows':placement_rows,'actual_placed_id':actual,'kernel_status':receipt['status'],'reused_from_call':call['origin_call'] if mode=='PENDING_REUSE' else None,'source_ref':ref},'evidence':{'source_ref':ref,'outer_original_sha256':env['raw_sha256'],'inner_audit_raw_sha256':log['raw_sha256'],'proposal_row':ri,'producer_receipt_index':receipt['index'],'producer_receipt_sha256':sha(receipt),'actor_call_index':call['index'],'actor_call_sha256':sha(call),'recorded_independent_status':row['independent_verification']['status'],'recorded_independent_sha256':sha(row['independent_verification']),'current_state_sha256':row['state_verification']['state_sha256'],'decision_row':di,'decision_event':de,'placement_row':pi,'placement_event':pe,'origin_call':call['origin_call'],'origin_first_observed_placement':placed_by_call.get(call['origin_call']),'scope':'Saved-record relational join only, no replay/causal proof/all-members-executed claim; whole admission pending.'}}
   per_arm_candidates.append(candidate)
 sample_candidates.extend(per_arm_candidates)
 # Optional literal extraction of one saved completed large reused-marking CSP solution.
 if board is None and m['phase']=='EVALUATION' and m['reused_marking'] and a['engine']=='CSP' and a['input']['width']==9 and not a['input']['negative_final'] and ret['status']=='FINITE_EXACT_SOLUTION':
  selected=set(ret['selected']);cells=[]
  for row in a['model']['placements']:
   if row['id'] not in selected:continue
   typ=strict(row['type'])
   if typ[0]!='WANG':continue
   x,y=row['translation'];assert x%2==0 and y%2==0
   cells.append({'cell':[x//2,y//2],'tile_id':typ[1],'palette_edges':catalogue[typ[1]],'full_placement_row':row})
  cells.sort(key=lambda x:(x['cell'][1],x['cell'][0]));byrow=collections.defaultdict(list)
  for c in cells:byrow[c['cell'][1]].append(c)
  words=[]
  for y,cs in sorted(byrow.items()):
   labels=[c['palette_edges']['S'] for c in cs]
   if all(label.startswith('S:')for label in labels):words.append({'from_tile_row':y,'stored_south_labels':labels,'symbols':[x[2:]for x in labels],'word':''.join(x[2:]for x in labels)})
  board={'schema':'Root-cluster-receptor-saved-computation-board-draft-v1','status':'DRAFT_UNADMITTED','source_ref':ref,'outer_original_sha256':env['raw_sha256'],'engine':a['engine'],'strategy':a['strategy'],'marking_version':a['marking_version'],'input':a['input'],'selected_ids':ret['selected'],'cells':cells,'state_words_read_from_stored_south_edge_labels':words,'tile_row_count':len(byrow),'ordinary_tile_count':len(cells),'reported_status':ret['status'],'recorded_result_check':checks['result_check'],'scope':'Exact saved assignment/palette-label extraction only; no transition evaluation, solve replay, new theorem/proof or scientific admission.'}
 if ordinal%16==0:print('decoded',ordinal+1,'of112',flush=True)
 del rows,loglines,lograw,raw,a
assert len(provenance)==112
# First qualifying fresh sample, then first qualifying pending reuse with an unused strategy/context,
# then earliest qualifying records with distinct strategy/context; never select on reward/result quality.
sample_candidates.sort(key=lambda x:(x['ordinal'],x['call_index']))
chosen=[];used=set()
def take(c):
 key=tuple(c['context_key'])
 if key in used:return False
 used.add(key);chosen.append(c);return True
for predicate in [lambda c:c['fresh_criterion'],lambda c:c['pending_later_nonforced_criterion']]:
 for c in sample_candidates:
  if predicate(c) and take(c):break
for c in sample_candidates:
 if len(chosen)>=6:break
 take(c)
examples={'schema':'Root-cluster-receptor-visual-records-v1','samples':[c['sample']for c in chosen]}
for s in examples['samples']:assert len(s)==11
selection={'schema':'Root-cluster-receptor-example-selection-provenance-draft-v1','status':'DRAFT_UNADMITTED','selection_order':'Whole saved arm execution order from index.arm_costs, then producer receipt/actor call index; first accepted FRESH>=2 with actual next branch member, then first accepted PENDING_REUSE later original member actually next-chosen with earlier origin-first member observed, subject to unused strategy/context, then earliest distinct strategy/context qualifying records up to6. Engine is not part of uniqueness key. No result/reward score selection.','candidate_count':len(sample_candidates),'selected':[{k:v for k,v in c.items()if k!='sample'}for c in chosen],'reused_marking_proposal_records':sum(s['proposal_record_count']for s in summaries.values()if s['marking_version'].startswith('REUSED_CERTIFIED_CORNER20:')),'scope':'Root whole scientific admission and C causal review pending. Display data are draft extractions, not acceptance proof or all-member execution.'}
updates=[];previous=initial
for episode,ref in enumerate(index['updates']):
 u=read(ref);assert u['episode']==episode and u['before_policy']==previous and u['update']['before_policy_sha256']==sha(previous)
 assert u['independent_update_check']['update_sha256']==sha(u['update'])
 assert u['point']==summaries[u['point']['path']]['source_ref'] and u['csp']==summaries[u['csp']['path']]['source_ref']
 assert u['verification_association']['point']==u['point'] and u['verification_association']['csp']==u['csp']
 pair=read(u['paired_check']);assert sha(pair)==u['paired_check']['sha256']
 previous=u['update']['after_policy'];updates.append({'source_ref':ref,'full_saved_update':u})
assert previous==trained and len(updates)==32
training=[]
for episode in range(32):
 arms=[summaries[x['record']['path']]for x in index['training']if x['episode']==episode];assert len(arms)==2
 training.append({'episode':episode,'declared_descriptor':{k:v for k,v in next(x for x in index['training']if x['episode']==episode).items()if k not in ['record','engine']},'saved_execution_engine_order':[x['engine']for x in arms],'arms':arms,'pair_check_ref':index['training_pair_checks'][episode],'pair_check':read(index['training_pair_checks'][episode]),'update':updates[episode]})
evalpairs=[]
for p in index['evaluation_pairs']:
 evalpairs.append({k:copy.deepcopy(v)for k,v in p.items()if k not in ['point','csp']}|{'point':summaries[p['point']['path']],'csp':summaries[p['csp']['path']]})
assert len(evalpairs)==24 and len(index['evaluation'])==48 and len(training)==32
qual={}
for key in ['legacy_qualification','cluster_qualification','explicit_reused_marking']:
 v=read(index[key]);entry={'source_ref':index[key],'schema':v['schema'],'canonical_sha256':sha(v)}
 for k in ['status','counts','coverage','costs','source_versions','scope','rawrefs']:
  if k in v:entry[k]=v[k]
 for k in ['production_audit','independent_audit','independent_contacts']:
  if k in v:entry[k]={'canonical_sha256':sha(v[k]),'status':v[k].get('status'),'scope':v[k].get('scope')}
 qual[key]=entry
agg=[]
for phase in ['TRAINING','EVALUATION']:
 for engine in ['POINT','CSP']:
  for strategy in ['LEX_NO_CLUSTER','UNTRAINED_CLUSTER','TRAINED_FIRST_ONLY','TRAINED_CLUSTER']:
   for reused in [False,True]:
    xs=[s for s in summaries.values()if s['phase']==phase and s['engine']==engine and s['strategy']==strategy and s['marking_version'].startswith('REUSED_CERTIFIED_CORNER20:')==reused]
    if not xs:continue
    agg.append({'phase':phase,'engine':engine,'strategy':strategy,'reused_marking':reused,'arms':len(xs),'reported_status_counts':dict(collections.Counter(s['status']for s in xs)),'window_triggered_count':sum(s['search_window']['triggered']for s in xs),'nodes_sum_not_comparable_across_cutoffs':sum(s['nodes']for s in xs),'through_body_write_seconds_sum':sum(s['through_complete_body_write_seconds']for s in xs),'solve_return_interval_seconds_sum':sum(s['search_window']['solve_return_interval_seconds']for s in xs),'branch_decisions_sum':sum(s['metrics']['branch_decisions']for s in xs),'backtracks_sum':sum(s['metrics']['backtracks']for s in xs),'forced_placements_sum':sum(s['metrics']['forced_placements']for s in xs),'proposal_calls_sum':sum(s['proposal_metrics']['proposer_calls']for s in xs),'branch_order_changes_sum':sum(s['proposal_metrics']['branch_order_changes']for s in xs)})
transport={'schema':'Root-cluster-N2-112-arm-standard-data-decoding-provenance-v1','status':'DRAFT_UNADMITTED','capture':pin(capturep),'result':capture['result'],'index':result['outcome']['index'],'raw_original_refs':allrefs,'outer_arms':provenance,'outer_original_bytes_sum':sum(x['full_outer_original']['raw_bytes']for x in provenance),'inner_decoded_bytes_sum':sum(x['inner_audit']['raw_bytes']for x in provenance),'inner_record_count_sum':sum(x['inner_audit']['record_count']for x in provenance),'inner_kind_counts':dict(inner_counts),'recorded_check_status_counts':[{'field':k[0],'status':k[1],'count':v}for k,v in sorted(check_statuses.items())],'checks':'Every184rawref fullhash/bytes; all112outer exact8/canonicalbase64/zlibboundedEOF/fullrawSHA+count/canonicalJSON bytes; everyinner112log fullbytes/hash/recordcount/no trailing, everyJSONLrow strictparsed and hashed. Generic data integrity/relations only, not solver/checker/reinforcement replay or scientific admission.','subject_calls':0}
pr=write('cluster-N2-complete-normalized-data-provenance-draft-v1.json',transport)
er=write('cluster-receptor-visual-records-draft-v1.json',examples)
sr=write('cluster-receptor-visual-selection-provenance-draft-v1.json',selection)
br=None if board is None else write('cluster-receptor-large-computation-board-draft-v1.json',board)
summary={'schema':'Root-cluster-receptor-complete-public-summary-draft-v1','status':'DRAFT_UNADMITTED','scientific_admission':False,'title':'Finite point cluster/receptor proposals and paired policy training: complete saved N2 cohort, review pending','provenance':{'capture':pin(capturep),'result':capture['result'],'custody':capture['custody'],'index':result['outcome']['index'],'plan':custody['plan'],'all_current_184_original_refs':allrefs,'complete_decoding_and_normalized_row_provenance':pr,'initial_policy_ref':index['initial_policy'],'trained_policy_ref':index['frozen_trained_policy'],'examples':er,'examples_selection':sr,'optional_computation_board':br},'reported_completion':{'main_solves':112,'training_episodes':32,'training_arms':64,'updates':32,'evaluation_arms':48,'collapsed_evaluation_pairs':24,'named_prefinal':183,'named_including_result':184,'physical_after_custody':187,'stored_named_bytes':145355866},'policies':{'initial':initial,'frozen_trained':trained,'final_policy_sha256':sha(trained),'all32updates_and_after_weights':'Fully retained in training_episodes[].update.full_saved_update.update, with complete before/after policy, feedback/reward terms/gradient/token counts and independent returns.'},'training_episodes':training,'evaluation_pairs':evalpairs,'aggregates_no_speed_inference':agg,'observed_main_call_and_work_counters':dict(observed_calls),'reported_qualification_census':qual,'costs_and_resources':{'worker_MAIN_ENTRY_before_final_result_seconds':result['worker_main_entry_before_final_result_seconds'],'worker_MAIN_ENTRY_tail':result['clock_tail'],'observer_before_Popen_through_owned_wait_seconds':custody['before_Popen_through_owned_wait_seconds'],'observer_after_Popen_return_through_owned_wait_seconds':custody['after_Popen_return_through_owned_wait_seconds'],'observer_MAIN_ENTRY_before_final_receipt_seconds':custody['observer_main_entry_before_final_receipt_seconds'],'observer_clock_tail':custody['clock_tail'],'owned_child_lifetime_RSS_highwater_bytes':custody['owned_child_lifetime_RSS_highwater_bytes'],'observer_lifetime_RSS_highwater_bytes_at_sample':custody['observer_lifetime_RSS_highwater_bytes_at_sample'],'RSS_scope':custody['RSS_scope'],'aggregate_all112_arm_through_complete_write_seconds':sum(s['through_complete_body_write_seconds']for s in summaries.values()),'all32_update_elapsed_seconds':sum(u['full_saved_update']['update_elapsed_seconds']for u in updates),'all32_independent_update_check_elapsed_seconds':sum(u['full_saved_update']['independent_update_check_elapsed_seconds']for u in updates),'limits_unchanged':plan['limits'],'scope':'Costs are observed scope-specific clocks, with preparation/audit/codec/serialization inside arm through-write and global worker clock. Child/observer highwaters sampled separately, not exact simultaneous process-tree allocation or hard quota.'},'cautions':['Whole scientific admission and C causal review pending; statuses and check returns here are reported saved facts.','UNKNOWN remains UNKNOWN; fewer nodes/branches or lower elapsed in a cut-off arm do not demonstrate a speedup or stronger solving.','Policy snapshots/cluster validation do not establish that all proposed members were executed; actual examples require saved decision+placement joins.','Original WANG and explicit reused admitted Mark20 are separate information conditions; Mark20 is a reused control, not cold learning in this cohort.','Finite unit-anchor/all-root specialization; no infinite construction, universal/FOL proof palette, new theorem, formal proof discovery or causal RL advantage established.','N1 failed attempt permanently spent/unadmitted; no N1 failed policy/results were used as inputs or promoted.','No tool executed scientific Source, checkers/solvers/helpers/getters/model/history/reinforcement/codec code; standard saved-byte JSON/base64/zlib/hash relations only.'],'publication_authorized':False}
sumref=write('cluster-N2-complete-public-summary-draft-v1.json',summary)
receipt={'schema':'Root-cluster-N2-public-draft-extraction-handoff-v1','status':'DRAFT_UNADMITTED','summary':sumref,'provenance':pr,'visual_records':er,'visual_selection':sr,'optional_board':br,'data_operations_only':True,'Source_or_actual_bytes_mutated':False,'publication':False,'scientific_admission':False,'extraction_elapsed_seconds':time.perf_counter()-started,'terminal_state':'IDLE'}
hr=write('cluster-N2-public-draft-extraction-handoff-v1.json',receipt)
print(json.dumps({'handoff':hr,'summary':sumref,'provenance':pr,'samples':len(chosen),'sample_modes':[c['mode']for c in chosen],'board':br,'reported_status_counts':[(list(k),v)for k,v in whole_counts.items()],'inner_rows':sum(inner_counts.values()),'all_main_calls':dict(observed_calls),'aggregate_count':len(agg)},sort_keys=True),flush=True)
