"""Administrative Source/AST inspection only. Subject imports/functions/network forbidden."""
from pathlib import Path
import ast,difflib,hashlib,json,symtable,sys
D=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B');OUT=Path(__file__).parent

def enc(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def ah(n,pos=False):return h(ast.dump(n,include_attributes=pos).encode())
def definitions(t,b):
 ls=b.splitlines(keepends=True);out={}
 def walk(n,prefix=''):
  for c in ast.iter_child_nodes(n):
   if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    q=prefix+c.name;start=min([c.lineno]+[x.lineno for x in c.decorator_list]);r=b''.join(ls[start-1:c.end_lineno]);out[q]={'name':q,'line':start,'end_line':c.end_lineno,'kind':type(c).__name__,'raw_bytes':len(r),'raw_sha256':h(r),'AST_sha256':ah(c),'positioned_AST_sha256':ah(c,True),'signature':None if isinstance(c,ast.ClassDef)else ast.unparse(c.args),'full_callset':sorted({ast.unparse(x.func)for x in ast.walk(c)if isinstance(x,ast.Call)}),'_raw':r,'_node':c};walk(c,q+'.')
   else:walk(c,prefix)
 walk(t);return out

def scopes(st):
 rows=[]
 def walk(t,path='module'):
  entries=[{'name':s.get_name(),'local':s.is_local(),'global':s.is_global(),'nonlocal':s.is_nonlocal(),'free':s.is_free(),'imported':s.is_imported(),'parameter':s.is_parameter(),'referenced':s.is_referenced(),'assigned':s.is_assigned()}for s in sorted(t.get_symbols(),key=lambda s:s.get_name())]
  rows.append({'path':path,'line':t.get_lineno(),'type':t.get_type(),'complete_entries':entries,'entries_sha256':h(enc(entries))})
  for i,c in enumerate(t.get_children()):walk(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 walk(st);return rows

def safe(v):return {k:x for k,x in v.items()if not k.startswith('_')}
hp=D/'cluster-receptor-multipart-complete-inert-Source-handoff-v1.json';hand=json.loads(hp.read_bytes());joined=[]
for r in hand['complete_packet']:assert pin(Path(r['path']))==r;joined.append(r)
census=json.loads((D/'cluster-receptor-multipart-complete-mechanical-replacement-census-v1.json').read_bytes());static=json.loads((D/'cluster-receptor-multipart-complete-Source-static-and-preservation-v1.json').read_bytes());abi=json.loads((D/'cluster-receptor-multipart-complete-effective-public-ABI-v1.json').read_bytes());offered_static={x['role']:x for x in static['Source_roles']};roles=[];replacement_total=occurrences=unchanged_total=0;patches=[]
for rc in census['roles']:
 role=rc['role'];op=Path(rc['old_Source']['path']);np=Path(rc['new_Source']['path']);a=op.read_bytes();b=np.read_bytes();assert pin(op)==rc['old_Source']and pin(np)==rc['new_Source'];ta,tb=ast.parse(a,filename=str(op)),ast.parse(b,filename=str(np));da,db=definitions(ta,a),definitions(tb,b);assert set(da)==set(db)
 reconstructed=a.decode()
 for change in rc['complete_ordered_replacement_classes']:
  assert reconstructed.count(change['old'])==change['occurrences'];reconstructed=reconstructed.replace(change['old'],change['new']);occurrences+=change['occurrences'];replacement_total+=1
 assert reconstructed.encode()==b
 inverse=b.decode()
 for change in reversed(rc['complete_ordered_replacement_classes']):
  assert inverse.count(change['new'])==change['occurrences'];inverse=inverse.replace(change['new'],change['old'])
 assert inverse.encode()==a and ah(ast.parse(inverse),True)==ah(ta,True)
 unchanged=[n for n in da if da[n]['_raw']==db[n]['_raw']and da[n]['AST_sha256']==db[n]['AST_sha256']];changed=[n for n in da if n not in unchanged];unchanged_total+=len(unchanged)
 assert changed==(['publish','main']if role=='publisher'else['verify'])
 for name in da:assert da[name]['signature']==db[name]['signature']and da[name]['full_callset']==db[name]['full_callset']
 imports_a=[ast.unparse(x)for x in ta.body if isinstance(x,(ast.Import,ast.ImportFrom))];imports_b=[ast.unparse(x)for x in tb.body if isinstance(x,(ast.Import,ast.ImportFrom))];assert imports_a==imports_b
 compile(b,str(np),'exec') # discarded unused code object, never executed
 sr=scopes(symtable.symtable(b.decode(),str(np),'exec'));off=offered_static[role];assert off['Source']==pin(np)and off['predecessor']==pin(op)and off['whole_AST_sha256']==ah(tb)and off['whole_positioned_AST_sha256']==ah(tb,True);assert len(off['complete_helper_preservation'])==len(db)
 for entry in off['complete_helper_preservation']:
  name=entry['new']['name'];assert entry['old']==safe(da[name])and entry['new']==safe(db[name]);assert entry['raw_equal']==(da[name]['_raw']==db[name]['_raw'])and entry['AST_equal']==(da[name]['AST_sha256']==db[name]['AST_sha256'])
 assert sr==off['complete_symbol_scopes']and imports_b==off['imports_unchanged']
 for label,left,right in [('forward',a,b),('inverse',b,a)]:
  p=D/('multipart-'+role+'-'+label+'-v1.patch');pb=p.read_bytes();headers=pb.decode().splitlines(True)[:2];ind=''.join(difflib.unified_diff(left.decode().splitlines(True),right.decode().splitlines(True),fromfile=headers[0][4:].rstrip('\n'),tofile=headers[1][4:].rstrip('\n'))).encode();assert ind==pb;patches.append({'pin':pin(p),'full_hunks_independently_regenerated':True,'header_convention':''.join(headers).rstrip()})
 nd=list(difflib.ndiff(a.decode().splitlines(True),b.decode().splitlines(True)));assert ''.join(difflib.restore(nd,1)).encode()==a and ''.join(difflib.restore(nd,2)).encode()==b
 constants={}
 for n in tb.body:
  if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:constants[n.targets[0].id]={'literal':ast.literal_eval(n.value),'source':ast.unparse(n.value)}
   except(ValueError,TypeError):constants[n.targets[0].id]={'source':ast.unparse(n.value)}
 assert list(constants['NAMES']['literal'])==abi['NAMES_exact_order']and constants['CAP']['literal']==67108864
 if role=='publisher':assert constants['BASELINE']['literal']==abi['baseline_report_blob']=='5e2663862dddd3892591e9149169da50b20ca457'and constants['ADMIN_CAP']['literal']==1048576
 roles.append({'role':role,'Source':pin(np),'predecessor':pin(op),'lines':len(b.splitlines()),'definition_count':len(db),'scope_count':len(sr),'unchanged_raw_AST':unchanged,'changed_literal_only':changed,'all_signatures_callsets_imports_equal':True,'full_replacement_census':rc['complete_ordered_replacement_classes'],'full_raw_and_positioned_AST_inverse':True,'whole_AST_sha256':ah(tb),'whole_positioned_AST_sha256':ah(tb,True),'complete_definitions':{n:safe(v)for n,v in db.items()},'complete_symbol_scopes':sr,'imports':imports_b,'module_bindings':constants,'unused_compile':'PASS, code object never executed'})
assert replacement_total==28 and occurrences==29 and unchanged_total==25 and sum(x['definition_count']for x in roles)==28 and sum(x['scope_count']for x in roles)==34
runtime=pin(Path(sys.executable));assert runtime['bytes']==18058560 and runtime['sha256']=='d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'
peer=D.parent/'independent-C/cluster-receptor-publication-complete-independent-Source-peer-review-v1.json';pp=json.loads(peer.read_bytes());assert pp['decision']=='PASS_INERT_SOURCE_WITH_EXPLICIT_EXTERNAL_ROOT_PRECONDITIONS'and not pp['blockers'];prior=D/'cluster-receptor-publication-complete-inert-Source-handoff-v1.json';assert pin(prior)==pp['subjects']['handoff']
for r in pp['subjects']['Sources'].values():assert pin(Path(r['path']))==r
out={'schema':'L-cluster-multipart-publication-complete-independent-Source-support-v1','status':'STATIC_AND_FULL_RAW_INVERSE_PASS','prefrozen_expectations':pin(OUT/'cluster-multipart-publication-prefrozen-Source-peer-expectations-v1.json'),'author_handoff':pin(hp),'author_packet_pins':joined,'prior_C_Source_peer':pin(peer),'prior_inert_handoff':pin(prior),'inherited_external_Root_preconditions':pp['required_external_Root_preconditions'],'prior_failure_limits':pp['failure_scope'],'runtime':runtime,'runtime_version':sys.version,'subject_execution':0,'network_calls':0,'payload_archive_actual_head_authority_intake':0,'roles':roles,'all4complete_author_patch_joins':patches,'replacement_classes':28,'replacement_occurrences':29,'normal_Git_route':{'GET':6,'blob_POST':10,'tree_POST':1,'commit_POST':1,'PATCH_force_false':1,'total':19,'reason':'publish contains current-parent GET plus ten blob loop plus tree and commit POST plus one PATCH; three head GET and two leaves GET helpers. No retry loops.'},'TLS_route':{'initial_target_opens':10,'same_origin_https_redirect_hops_may_add_requests':True,'timeout_per_open_seconds':45,'complete_body_cap':67108864},'review_scope':'All complete current Sources and exact predecessor bodies read statically; full inverse proves only declared literals/list expansion. No further ancestor Source intake/recursive closure needed; C original Source pass inherited with explicit external Root duties. No scientific/body/volume/content/pub acceptance.'}
p=OUT/'cluster-multipart-publication-complete-independent-Source-support-v1.json'
with p.open('xb')as f:f.write(enc(out))
print(json.dumps({'support':pin(p),'counts':{'definitions':28,'scopes':34,'unchanged':25,'classes':28,'occurrences':29},'subject_calls':0},indent=2))
