"""Root-only ordinary metadata adoption/grant author; no subject execution."""
from pathlib import Path
import hashlib
import json
import sys

D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')


def pin(path):
    p=Path(path).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def checked(d):
    assert pin(d['path'])==d,'exact raw reviewed preimage'
    return json.loads(Path(d['path']).read_bytes())


def contains(v,w):
    if v==w:return True
    if type(v)is dict:return any(contains(x,w)for x in v.values())
    if type(v)is list:return any(contains(x,w)for x in v)
    return False


def write(p,v):
    with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
    return pin(p)


def main(source_review,outer_review,plan_review):
    manifest_pin=pin(D/'prospective-metadata-manifest-v1.json');m=checked(manifest_pin)
    assert m['actual_execution_authorized']is False and m['actuals_launched']==0 and len(m['rows'])==8
    roles={k:pin(p)for k,p in [('Source',source_review),('outer_Source',outer_review),('plans',plan_review)]}
    reviews={k:checked(v)for k,v in roles.items()}
    for r in reviews.values():
        assert r['reviewer_identity']=='/root/conventional_control_review' and r['source_only']is True
        assert type(r['scientific_calls'])is int and r['scientific_calls']==0
        assert r['actual_execution_authorized']is False and r['scientific_acceptance']is False
    assert reviews['Source']['schema']=='direct-projection-qualification-components-Source-review-v1' and reviews['Source']['source_review_passed']is True
    assert reviews['outer_Source']['schema']=='direct-projection-qualification-outer-Source-review-v1' and reviews['outer_Source']['source_review_passed']is True
    assert reviews['plans']['schema']=='direct-projection-qualification-prospective-plan-review-v1' and reviews['plans']['prospective_review_passed']is True
    declaration=checked(m['declaration']);checked(m['runtime_closure'])
    hd=checked(declaration['harness_declaration'])
    assert contains(reviews['Source'],declaration['harness_declaration'])
    assert contains(reviews['plans'],m['declaration'])and contains(reviews['plans'],m['runtime_closure'])
    for row in m['rows']:
        plan=checked(row['plan']);subject={k:v for k,v in plan.items()if k!='authorization'}
        assert row['subject']==subject and row['subject_sha256']==hashlib.sha256(canonical(subject)).hexdigest()
        assert any(r['subject']==subject and r['subject_sha256']==row['subject_sha256']for r in reviews['plans']['subjects'])
        assert checked(plan['authorization'])['actual_execution_authorized']is False
        assert not Path(plan['actual_directory']).exists()
        assert {'arm':plan['arm'],'bank':plan['bank'],'inputs':plan['inputs']}in hd['subjects']
        for name,d in plan['sources'].items():
            assert pin(d['path'])==d
            if name in('worker','harness','adapter','arena'):assert contains(reviews['Source'],d)
            else:assert contains(reviews['outer_Source'],d)
        assert pin(plan['python']['path'])==plan['python']
        for item in plan['inputs']:assert pin(item['pin']['path'])==item['pin']
    # All preconditions above are checked before the first true grant is written.
    issued=[]
    for row in m['rows']:
        suffix=row['bank']+'-'+row['arm'];subject=row['subject']
        auth=write(D/'plans-v1'/('authorization-true-'+suffix+'.json'),dict(
            schema='ROOT-direct-projection-qualification-authorization-v1',author_identity='/root',
            actual_execution_authorized=True,maximum_actual_invocations=1,subject_sha256=row['subject_sha256'],
            review_roles=roles,scope='Exactly one whole declared finite representation helper under original180/210/1GiB/128MiB/400mArena/400mAdapter limits. No Native/Model/search/inverse/Reader/opaque decode. No proof/full production authority or prefix recovery. Serial workers; peers idle.'))
        plan=write(D/'plans-v1'/('plan-authorized-'+suffix+'.json'),dict(subject,authorization=auth))
        issued.append(dict(arm=row['arm'],bank=row['bank'],plan=plan,subject_sha256=row['subject_sha256'],authorization=auth))
    result=write(D/'ROOT-scope-adoption-and-grants-v1.json',dict(
        schema='ROOT-direct-projection-scope-adoption-and-grants-v1',author_identity='/root',
        prospective_manifest=manifest_pin,review_roles=roles,issued=issued,
        actual_execution_authorized=True,actual_invocations_maximum=8,launched_actuals=0,
        mathematical_proof_accepted=False,full_pipeline_qualified=False,goal_complete=False,
        stop_rule='Serial exact subjects only. A common protocol/code defect blocks dependent launches and leaves them NOT_RUN; preserve all attempted negatives. No consumed subject retry or cap increase. Pure resource failure of a complete bank is kept and does not erase the remaining fixed bank denominator.'))
    print(json.dumps(result,sort_keys=True))


if __name__=='__main__':
    assert len(sys.argv)==4,'exact component, outer, prospective review paths'
    main(*sys.argv[1:])
