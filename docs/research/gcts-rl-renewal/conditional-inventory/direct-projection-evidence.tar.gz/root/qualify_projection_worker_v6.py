"""Finite evidence-capture qualification, only inside one reviewed Root grant.

No proof search, Native, Model, inverse, Reader, or opaque program decode.
This worker imports only the selected adapter/Arena and the declared harness.
"""
import time
NOW = time.monotonic_ns
import hashlib
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'direct-projection-qualification-worker-v6'
PLAN_SCHEMA = 'ROOT-direct-projection-qualification-plan-v1'
PLAN_FIELDS = frozenset(('schema','invocation_id','actual_directory','arm','bank',
    'python','sources','inputs','limits','arena_limits','adapter_limits',
    'declaration','runtime_closure','authorization'))
SOURCE_ROLES = frozenset(('worker','harness','adapter','arena','runner','observer'))
LIMITS = dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,
    stderr_bytes=4194304,worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608,observer_bytes=1048576)

ARENA_LIMITS = {'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536,'depth':512,
    'documents_expanded_bytes':134217728,'edges':8000000,'fragment_bytes':4096,'integer_digits':4096,
    'materialized_bytes':4194304,'materialized_occurrences':100000,'nodes':2000000,
    'root_expanded_bytes':134217728,'roots':4096,'scalar_bytes':16777216,'wire_bytes':134217728,'work':400000000}
ADAPTER_LIMITS = {'operations':400000000,'value_bytes':134217728,'depth':512,'chunk_bytes':65536}


def need(value,message):
    if not value:raise ValueError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
                      allow_nan=False).encode('utf8')


def descriptor(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin,cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap,'strict bounded raw descriptor')
    p=Path(pin['path'])
    need(p.is_absolute() and p==p.resolve() and p.is_file() and not p.is_symlink(),
         'canonical regular source/input')
    raw=p.read_bytes();need(descriptor(p,raw)==pin,'whole raw descriptor equality');return raw


def save_new(path,value,cap):
    raw=canonical(value)+b'\n';need(len(raw)<=cap,'bounded ordinary metadata')
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return descriptor(path,raw)


def load(pin,name):
    raw=checked(pin);module=types.ModuleType(name);module.__file__=pin['path']
    sys.modules[name]=module
    exec(compile(raw,pin['path'],'exec'),module.__dict__)
    return module


def callable_snapshot(modules):
    bindings=[];codes=[];seen=set()
    def function(value):
        if isinstance(value,types.FunctionType):
            codes.append((value,value.__code__,value.__globals__,value.__defaults__,value.__kwdefaults__))
    def klass(module,cls):
        if cls in seen:return
        seen.add(cls)
        for name,value in list(vars(cls).items()):
            if isinstance(value,(staticmethod,classmethod)):
                bindings.append((cls,name,value));function(value.__func__)
            elif isinstance(value,types.FunctionType):bindings.append((cls,name,value));function(value)
            elif isinstance(value,property):
                bindings.append((cls,name,value))
                for member in (value.fget,value.fset,value.fdel):function(member)
            elif isinstance(value,type)and value.__module__==module.__name__:
                bindings.append((cls,name,value));klass(module,value)
    for module in modules:
        for name,value in list(vars(module).items()):
            if isinstance(value,(types.FunctionType,types.ModuleType,type)):
                bindings.append((module,name,value))
            function(value)
            if isinstance(value,type)and value.__module__==module.__name__:klass(module,value)
    bindings.extend([(json,'JSONEncoder',json.JSONEncoder),(json,'dumps',json.dumps),
                     (json,'loads',json.loads),(hashlib,'sha256',hashlib.sha256)])
    for name in ('iterencode','encode'):
        value=getattr(json.JSONEncoder,name);bindings.append((json.JSONEncoder,name,value));function(value)
    def guard():
        for owner,name,value in bindings:
            need(vars(owner).get(name)is value,'component callable/module binding unchanged')
        for value,code,namespace,defaults,kwdefaults in codes:
            need(value.__code__ is code and value.__globals__ is namespace and
                 value.__defaults__ is defaults and value.__kwdefaults__ is kwdefaults,
                 'component code/globals/default identities unchanged')
    return guard


def validate_qualification(q,plan,declaration,outputs):
    need(q['outputs']==outputs,'qualification/emitter/header output join')
    need(q['original_values_retained_through_worker_positive_boundary']is True,
         'complete originals retained through final positive boundary')
    for field in ('authority','full_pipeline_qualified','mathematical_proof_accepted',
                  'mathematical_authority','resource_authority','production_full_cold_qualified'):
        need(q[field]is False,'finite representation only, no proof or production authority')
    for field in ('scientific_calls','Native_calls','Model_calls','search_calls','Reader_calls','inverse_calls'):
        need(type(q[field])is int and q[field]==0,'no proof/search runtime')
    expected=declaration['finite_expected_census'];ic=q['instance_census'];cc=q['call_census']
    need(all(type(ic[k])is int for k in ('unique_Stores','unique_separate_direct_Arenas','unique_Arenas')),
         'strict instance census integers')
    need(type(cc['component_calls'])is int and 0<cc['component_calls']<=declaration['call_bounds']['component_calls']==1024,
         'bounded actual public API starts')
    for field in ('passive_statistics_calls','check_callbacks','guard_callbacks','cleanup_failures'):
        need(type(cc[field])is int and cc[field]>=0,'strict callback/passive/cleanup counts')
    rows=q['rows'];need(type(rows)is list,'complete ordered result rows')
    if plan['bank']=='generic':
        e=expected['generic_each'];order=declaration['generic_fixture_order']
        need(e['fixture_count']==23 and e['group_count']==6 and len(order)==23 and
             [[r['group'],r['fixture']]for r in rows]==order and len({g for g,n in order})==6,
             'all twenty-three exact ordered generic cases across six groups')
        na={'projection_caps','unread_tail_mutation','arena_foreign_phases'}
        need(na<={name for group,name in order},'three exact prospectively reference-NA cases')
        for r in rows:
            need(type(r['result'])is dict,'complete ordinary per-case result')
            actual_na=r['result'].get('status')=='DECLARED_NOT_APPLICABLE_NO_NEW_API'
            need(actual_na==(plan['arm']=='reference'and r['fixture']in na),'exact reference-NA scope')
        direct=e[plan['arm']+'_separate_direct_Arenas']
        need(ic['unique_Stores']==e['fresh_Stores']==21 and
             ic['unique_separate_direct_Arenas']==direct and direct==(3 if plan['arm']=='candidate'else 0) and
             ic['unique_Arenas']==e[plan['arm']+'_total_Arenas']==21+direct,
             'all unique generic Store/private/direct Arena instances')
        labels=['wide_array','wide_object','shared_subtree','equal_distinct','tuple_projection',
                'chunk_unicode','mixed_roots','repeated_ports','scalar_domain']
        need([Path(x['path']).name for x in outputs]==['canonical-'+x+'.json'for x in labels],
             'all nine complete generic output bodies in exact order')
        for name in ('mixed_roots','repeated_ports'):
            row=next(r for r in rows if r['fixture']==name)
            need(row['result']in outputs,'mixed/repeated-reference row tied to actual output')
    else:
        e=expected['bank_B'if plan['bank']=='bank_B_original006'else'bank_A_each']
        need(ic['unique_Stores']==e['fresh_Stores']==1 and ic['unique_separate_direct_Arenas']==0 and
             ic['unique_Arenas']==1,'one retained Store/Arena for whole original bank')
        need(cc['component_calls']==e['public_component_calls']==(10 if plan['bank']=='bank_B_original006'else 4),
             'exact complete bank public-call census')
        need(len(outputs)==e['complete_actual_outputs']==1 and len(rows)==1 and
             rows[0]['bank']==plan['bank']and rows[0]['complete_output']==outputs[0] and
             Path(outputs[0]['path']).name=='canonical-'+plan['bank']+'.json',
             'one complete exact bank row and output, no shortened input or suffix')


def main(plan_path):
    need(sys.platform=='darwin' and sys.flags.isolated and sys.flags.no_site and
         sys.dont_write_bytecode,'reviewed isolated Darwin worker')
    p=Path(plan_path).resolve();raw=p.read_bytes();need(len(raw)<=16777216,'bounded plan')
    plan=json.loads(raw)
    need(type(plan)is dict and set(plan)==PLAN_FIELDS and plan['schema']==PLAN_SCHEMA,'exact plan fields')
    need(plan['limits']==LIMITS and plan['arena_limits']==ARENA_LIMITS and
         plan['adapter_limits']==ADAPTER_LIMITS and plan['arm']in('reference','candidate') and
         Path(sys.executable).resolve()==Path(plan['python']['path']),'same finite numeric profile/Python')
    need(type(plan['sources'])is dict and set(plan['sources'])==SOURCE_ROLES and
         descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['worker'],'current worker Source')
    actual=Path(plan['actual_directory']);need(actual==actual.resolve()==Path.cwd(),'exact actual directory')
    marker=json.loads((actual/'CONSUMED.json').read_bytes())
    need(marker['schema']=='direct-projection-qualification-consumed-v1' and
         marker['invocation_id']==plan['invocation_id'] and marker['plan']==descriptor(p,raw) and
         marker['maximum_worker_launches']==1 and marker['consumed_before_Popen']is True,
         'consumed max-one worker boundary')
    began,work,overall=marker['began_ns'],marker['work_deadline_ns'],marker['overall_deadline_ns']
    need(work==began+180000000000 and overall==began+210000000000,'original absolute endpoints')
    phase='intake';guard=None;root_fault=None;denied=[];retained=[];outputs=[]
    logical_bytes=0;qualification=None;check_calls=0;guard_calls=0;cleanup_errors=[]
    def checkpoint():
        nonlocal root_fault,check_calls
        try:
            check_calls+=1;need(NOW()<work,'complete positive work before180')
            if guard is not None:guard()
        except BaseException as error:
            if root_fault is None:root_fault=error
            raise
    def source_guard():
        nonlocal guard_calls
        guard_calls+=1;checkpoint()
    def retain(value):retained.append(value)
    def emit_canonical(label,iterator):
        nonlocal logical_bytes
        checkpoint()
        need(type(label)is str and 0<len(label)<=80 and
             all(c in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'for c in label),
             'bounded safe output label')
        path=actual/('canonical-'+label+'.json');size=0;digest=hashlib.sha256()
        try:
            fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            with os.fdopen(fd,'wb')as stream:
                while True:
                    checkpoint()
                    try:part=next(iterator)
                    except StopIteration:
                        if iterator.completed is True:break
                        raise
                    need(type(part)is bytes and 0<len(part)<=65536,'bounded exact canonical chunk')
                    logical_bytes+=len(part);size+=len(part)
                    need(logical_bytes+1<=LIMITS['expanded_bytes'],'full logical output cap')
                    stream.write(part);digest.update(part)
                need(iterator.completed is True,'complete canonical stream only')
                stream.write(b'\n');digest.update(b'\n');size+=1;logical_bytes+=1
                stream.flush();os.fsync(stream.fileno())
        except BaseException:
            # Cleanup must never replace the exact active foreign/Root error.
            try:iterator.close()
            except BaseException as cleanup:
                try:cleanup_errors.append(dict(stage='emit_canonical_error_cleanup',type=type(cleanup).__name__))
                except BaseException:pass
            raise
        else:
            # With no active error, a genuine close failure remains a failure.
            iterator.close()
        result=dict(path=str(path),bytes=size,sha256=digest.hexdigest());outputs.append(result)
        need(sum(f.stat().st_size for f in actual.iterdir()if f.is_file())+9437184<=LIMITS['result_bytes'],
             'all current physical files plus original9MiB outer reserves')
        checkpoint();return result
    try:
        checkpoint();checked(plan['python'],67108864)
        for pin in plan['sources'].values():checked(pin);checkpoint()
        declaration=json.loads(checked(plan['declaration']))
        closure=json.loads(checked(plan['runtime_closure']))
        need(declaration['schema']=='ROOT-direct-projection-qualification-declaration-v1' and
             declaration['limits']==LIMITS and declaration['full_pipeline_qualified']is False,
             'finite qualification declaration')
        entry={'arm':plan['arm'],'bank':plan['bank'],'inputs':plan['inputs']}
        need(entry in declaration['subjects'] and declaration['arena_limits']==plan['arena_limits'] and
             declaration['adapter_limits']==plan['adapter_limits'],'whole declared bank and limits')
        harness_declaration=json.loads(checked(declaration['harness_declaration']))
        need(closure['schema']=='ROOT-direct-projection-qualification-runtime-closure-v1' and
             closure['python']==plan['python'] and closure['arms'][plan['arm']]==plan['sources'] and
             closure['declaration']==plan['declaration'],'complete selected runtime closure')
        for pin in closure['stdlib_files']:checked(pin);checkpoint()
        for item in plan['inputs']:checked(item['pin'],LIMITS['result_bytes']);checkpoint()
        def audit(event,args):
            if event in('subprocess.Popen','os.fork','os.posix_spawn','os.system',
                         'socket.connect','socket.bind','ctypes.dlopen'):
                denied.append(event);raise RuntimeError('process/network/dlopen forbidden in finite helper')
        sys.addaudithook(audit)
        phase='load_selected_components'
        arena=load(plan['sources']['arena'],'_projection_qualification_arena')
        adapter=load(plan['sources']['adapter'],'_projection_qualification_adapter')
        harness=load(plan['sources']['harness'],'_projection_qualification_harness')
        guard=callable_snapshot((arena,adapter,harness));checkpoint()
        phase='qualify'
        qualification=harness.run_subject(plan,harness_declaration,arena_module=arena,
            adapter_module=adapter,check=checkpoint,source_guard=source_guard,
            emit_canonical=emit_canonical,retain=retain)
        if root_fault is not None:raise root_fault
        checkpoint()
        need(type(qualification)is dict and qualification['schema']=='direct-projection-finite-qualification-v1' and
             qualification['status']=='FINITE_HELPER_CANDIDATE' and
             qualification['bank']==plan['bank'] and qualification['arm']==plan['arm'] and
             qualification['full_pipeline_qualified']is False and qualification['authority']is False and
             qualification['mathematical_proof_accepted']is False and not denied,
             'complete declared finite helper outcome only')
        validate_qualification(qualification,plan,harness_declaration,outputs)
        totals=qualification['operation_totals']
        need(type(totals)is dict and set(totals)=={'arena_work','adapter_operations'} and
             all(type(v)is int and 0<=v<=400000000 for v in totals.values()),
             'whole invocation aggregate400m Arena/adapter limits, no per-Store reset')
        need(0<len(retained)<=512,'retained originals/stores/capture roots through final checkpoint')
        for pin in plan['sources'].values():checked(pin);checkpoint()
        for item in plan['inputs']:checked(item['pin'],LIMITS['result_bytes']);checkpoint()
        phase='write_result'
        result=save_new(actual/'result.json',dict(schema='direct-projection-qualification-result-v1',
            version=VERSION,invocation_id=plan['invocation_id'],plan=descriptor(p,raw),
            qualification=qualification,outputs=outputs,canonical_logical_bytes=logical_bytes,
            retained_objects=len(retained),check_calls=check_calls,source_guard_calls=guard_calls,
            declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],
            full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,
            Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,search_calls=0,
            opaque_program_decodes=0,denied_events=denied,cleanup_errors=cleanup_errors),1048576)
        logical_bytes+=result['bytes'];need(logical_bytes<=LIMITS['expanded_bytes'],'complete logical output ledger')
        checkpoint()
        save_new(actual/'worker-receipt.json',dict(schema='direct-projection-qualification-worker-receipt-v1',
            invocation_id=plan['invocation_id'],plan=descriptor(p,raw),began_ns=began,
            work_deadline_ns=work,overall_deadline_ns=overall,positive_worker_completed_ns=NOW(),
            result=result,outputs=outputs,logical_result_bytes=logical_bytes,
            outer_metadata_reservation=9437184,finite_helper_candidate=True,
            full_pipeline_qualified=False,scientific_acceptance=False,
            mathematical_proof_accepted=False),4194304)
        checkpoint()
    except BaseException as error:
        try:
            prefix=getattr(error,'qualification_prefix',None)
            if prefix is not None:need(type(prefix)is dict and len(canonical(prefix))<=262144,'bounded failure prefix')
            save_new(actual/'worker-failure.json',dict(schema='direct-projection-qualification-failure-v1',
                status='FAILED_OR_UNFINISHED',authority=False,phase=phase,
                error_type=type(error).__name__,message=str(error)[:4096],
                root_fault_type=None if root_fault is None else type(root_fault).__name__,
                returned_nonadmitted_packet=qualification,qualification_prefix=prefix,
                canonical_logical_bytes=logical_bytes,outputs=outputs,retained_objects=len(retained),
                check_calls=check_calls,source_guard_calls=guard_calls,denied_events=denied,
                cleanup_errors=cleanup_errors,full_pipeline_qualified=False,scientific_acceptance=False,
                mathematical_proof_accepted=False),1048576)
        except BaseException:pass
        raise
    return 0


if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed once-plan path')
    raise SystemExit(main(sys.argv[1]))
