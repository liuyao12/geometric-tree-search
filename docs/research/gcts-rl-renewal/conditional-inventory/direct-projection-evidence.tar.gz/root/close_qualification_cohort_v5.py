"""Passive closure of saved ordinary metadata; no subject loading or replay."""
from pathlib import Path
import hashlib
import json
import os

D = Path('/private/tmp/gcts-direct-projection-ROOT-20261019')


def pin(p):
    b = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def main():
    gp = D / 'ROOT-scope-adoption-and-grants-v3.json'
    g = json.loads(gp.read_bytes())
    observation_path = D / 'ROOT-postfailure-owned-process-observation-v1.json'
    observation = json.loads(observation_path.read_bytes())
    assert observation['worker_process_absent'] is True
    assert observation['owned_process_group_absent'] is True
    assert observation['runner_wait4_exit_and_highwater_recovered'] is False
    rows = []
    for item in g['issued']:
        p = Path(item['plan']['path'])
        assert pin(p) == item['plan']
        plan = json.loads(p.read_bytes())
        a = Path(plan['actual_directory'])
        folder = p.parent / (p.stem + '-terminal-observation')
        row = dict(arm=item['arm'], bank=item['bank'], plan=item['plan'],
                   subject_sha256=item['subject_sha256'])
        if not a.exists():
            assert not os.path.lexists(folder)
            row.update(launched=False, gate_passed=False,
                       classification='Not run after cleanup protocol failure',
                       elapsed_seconds=None, worker_peak_bytes=None,
                       status='NOT_RUN_COMMON_PROTOCOL_ABORT')
            rows.append(row)
            continue
        r = json.loads((a / 'runner-receipt.json').read_bytes())
        t = json.loads((folder / 'terminal.json').read_bytes())
        assert r['plan'] == item['plan'] and t['plan'] == item['plan']
        assert r['worker_launch_attempts'] == 1 and r['regular_logs_closed'] is True
        passed = t['terminal_gate_passed'] is True
        usage = r.get('worker_wait4_usage')
        row.update(launched=True, gate_passed=passed,
                   classification='Helper gates passed' if passed else 'Deadline and cleanup gates failed',
                   status='FINITE_HELPER_GATE_PASS' if passed else 'FAILED_DEADLINE_AND_CLEANUP',
                   elapsed_seconds=t['runner_clock_elapsed_seconds'],
                   worker_peak_bytes=usage['ru_maxrss'] if usage is not None else None,
                   worker_exit_code=r.get('worker_exit_code'), runner_exit_code=t['runner_exit_code'],
                   runner_errors=r['errors'], worker_reaped_in_original_runner=r['worker_reaped'],
                   owned_group_absent_in_original_runner=r['owned_group_absent'],
                   actual_directory=str(a), terminal=pin(folder / 'terminal.json'),
                   files={f.name: pin(f) for f in a.iterdir() if f.is_file()},
                   complete_result_exists=(a / 'result.json').is_file(),
                   worker_success_receipt_exists=(a / 'worker-receipt.json').is_file())
        if passed:
            assert r['worker_reaped'] is True and r['owned_group_absent'] is True
            assert r.get('worker_exit_code') == 0 and usage is not None
        else:
            assert item['bank'] == 'bank_A_fixed' and item['arm'] == 'reference'
            assert observation['runner_receipt'] == pin(a / 'runner-receipt.json')
            assert r['worker_reaped'] is False and r['owned_group_absent'] is False
            assert r.get('worker_exit_code') is None and usage is None
            assert any(e.get('type') == 'PermissionError' and e.get('cleanup') is True for e in r['errors'])
            row['later_process_absence_observation'] = pin(observation_path)
            row['later_absence_does_not_recover_wait4_or_admission'] = True
        if (a / 'result.json').is_file():
            result = json.loads((a / 'result.json').read_bytes())
            row.update(complete_qualification=result['qualification'], complete_outputs=result['outputs'],
                       canonical_logical_bytes=result['canonical_logical_bytes'])
        if (a / 'worker-failure.json').is_file():
            f = json.loads((a / 'worker-failure.json').read_bytes())
            row.update(failure_phase=f['phase'], failure_error_type=f['error_type'], failure_message=f['message'],
                       failure_prefix=f.get('qualification_prefix'),
                       failure_returned_packet_has_no_authority=f.get('returned_nonadmitted_packet') is not None)
        rows.append(row)
    assert len(rows) == 8
    assert sum(r['launched'] for r in rows) == 3
    assert sum(r['gate_passed'] for r in rows) == 2
    assert sum(not r['launched'] for r in rows) == 5
    assert all(not r['gate_passed'] for r in rows if r['bank'] != 'generic')
    record = dict(schema='ROOT-direct-projection-qualification-cohort-closure-v1', author_identity='/root',
        current_cohort='V3 early aggregate lifetime registration; same complete banks/cases/caps',
        rows=rows, planned_subjects=8, launched_subjects=3, helper_gate_passes=2,
        candidate_helper_gate_passes=1, whole_bank_helper_gate_passes=0,
        original_caps_unchanged=True, all_owned_exec_handles_closed=True,
        all_owned_processes_and_groups_now_observed_absent=True,
        all_workers_reaped_by_original_runners=False,
        all_required_exit_and_highwater_observations_available=False,
        later_OS_observation=pin(observation_path),
        remaining_five_subjects='NOT_RUN_COMMON_PROTOCOL_ABORT',
        all_current_V3_grants_retired_for_further_Root_use=True,
        mathematical_proof_accepted=False, full_pipeline_qualified=False,
        candidate_finite_qualified=False, independent_saved_review_pending=True,
        Root_grants=pin(gp), historical_V2=pin(D / 'ROOT-cohort-V2-common-defect-closure-v1.json'),
        goal_status='active', goal_complete=False,
        limitations=[
            'Generic reference and candidate complete helper gates passed; reference has three prospectively N/A API-only cases. Generic timing is not a matched performance comparison.',
            'The first whole-bank reference exceeded the positive deadline during complete canonical emission. Its runner then encountered PermissionError in cleanup, exited without wait4 status/highwater and reported group absence false. Later privileged OS absence probes did not recover exit status, peak memory or original custody.',
            'The five dependent plans remain unrun and all V3 grants are retired. No unchanged-subject retry, reduced bank, cap increase or failed-prefix rescue.',
            'No whole-bank candidate was executed, so there is no large-input speed/memory comparison, candidate whole-bank qualification or full-cold production fit.',
            'The worker field retained_objects counts the one Root aggregate registration, not retained value entries or all reachable objects. Internal Source-enforced generic entry counts are reference76/candidate526 with duplicates and full lifetime preserved.',
            'Original180 positive/fullreading/knownexit and210 laterterminal;1GiB standalone helperhighwater,128MiB logical+physical and separate4MiBlogs/receipt/9MiBreserves;400m Arena/400mAdapter invocation totals remain. Native is absent.',
            'Finite representation helpers only. No theorem search/discovery, Model/Native/Reader/inverse execution, GCTS/RL ranking, learning or proof authority. Historical failures remain separate denominators.'
        ])
    p = D / 'ROOT-qualification-cohort-closure-v1.json'
    with p.open('x') as f:
        json.dump(record, f, sort_keys=True, indent=2)
        f.write('\n')
    print(json.dumps(dict(record=pin(p), launched=3, helper_passes=2, unrun=5), sort_keys=True))


if __name__ == '__main__':
    main()
