"""Ordinary raw/AST/JSON metadata author. Never loads any subject Source."""
from pathlib import Path
import ast
import hashlib
import json
import sys

D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
PY=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
LIB=PY.parent.parent/'lib/python3.12'


def pin(path):
    p=Path(path).resolve();b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def write(path,value):
    with path.open('x')as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
    return pin(path)


def literals(path):
    out={}
    for node in ast.parse(path.read_bytes()).body:
        if not isinstance(node,ast.Assign):continue
        for target in node.targets:
            if not isinstance(target,ast.Name):continue
            try:
                value=node.value
                if isinstance(value,ast.Call)and isinstance(value.func,ast.Name)and value.func.id=='dict'and not value.args and all(k.arg is not None for k in value.keywords):
                    out[target.id]={k.arg:ast.literal_eval(k.value)for k in value.keywords}
                else:out[target.id]=ast.literal_eval(value)
            except (ValueError,TypeError):pass
    return out


def main(harness_path,harness_declaration_path,subject_entries_path):
    h=Path(harness_path).resolve();hd=Path(harness_declaration_path).resolve()
    subject_entries=json.loads(Path(subject_entries_path).read_bytes())
    assert type(subject_entries)is list and len(subject_entries)==8
    assert {(v['arm'],v['bank'])for v in subject_entries}=={(a,b)for a in('reference','candidate')for b in('generic','bank_A_fixed','bank_A_symbolic','bank_B_original006')}
    for entry in subject_entries:
        assert set(entry)=={'arm','bank','inputs'}
        for item in entry['inputs']:
            assert set(item)=={'id','pin'} and pin(item['pin']['path'])==item['pin']
    folder=D/'plans-v2';folder.mkdir(exist_ok=False)
    common={'worker':pin(D/'qualify_projection_worker_v6.py'),'runner':pin(D/'run_projection_qualification_once_v4.py'),
            'observer':pin(D/'observe_projection_qualification_once_v1.py'),'harness':pin(h)}
    ref={'adapter':pin('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py'),
         'arena':pin('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py')}
    new={'adapter':pin(D/'owned_evidence_adapter_v4.py'),
         'arena':pin('/private/tmp/gcts-direct-projection-library-20261019/exact_evidence_arena_v4.py')}
    assert ref['adapter']['sha256']=='91fb57f8a3fdd4563cb74f641b630bd725b813bd305608463920dd191f0216a8'
    assert ref['arena']['sha256']=='fd3f1e1372c59365cc43c06dd8c815bdaca8cab6a2e4fa292d23a901d7f146f8'
    assert new['adapter']['sha256']=='9323bb2caf7eeb3907ff7079bb417e4764d5ad4813b669b08b23648209e3c769'
    assert new['arena']['sha256']=='99366602a91c83ccdf024107478bfa8d5814c7436f14d0e6d0b3ae870b478042'
    arms={'reference':dict(common,**ref),'candidate':dict(common,**new)}
    w=literals(Path(common['worker']['path']));r=literals(Path(common['runner']['path']))
    assert all(w[k]==r[k]for k in('LIMITS','ARENA_LIMITS','ADAPTER_LIMITS'))
    declaration=write(D/'qualification-declaration-v2.json',dict(
        schema='ROOT-direct-projection-qualification-declaration-v1',author_identity='/root',
        source_only=True,scientific_calls=0,actual_execution_authorized=False,
        limits=w['LIMITS'],arena_limits=w['ARENA_LIMITS'],adapter_limits=w['ADAPTER_LIMITS'],
        harness_declaration=pin(hd),subjects=subject_entries,full_pipeline_qualified=False,
        mathematical_proof_accepted=False,
        scope='Three complete original representation banks and one complete six-group generic bank, each reference/candidate in fresh serial workers. Exposed development fixtures, not theorem discovery, no Native or proof/search/Model/Reader/inverse execution; helper success is not production fit. All failures retained; no V3 failed prefix or shortened input.'))
    sources={d['path']:d for values in arms.values()for d in values.values()}
    census=[];modules=set()
    for d in sources.values():
        tree=ast.parse(Path(d['path']).read_bytes());imports=[]
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):imports.extend(a.name for a in node.names)
            elif isinstance(node,ast.ImportFrom):
                assert node.level==0 and node.module is not None;imports.append(node.module)
        modules.update(imports);census.append(dict(source=d,direct_imports=sorted(set(imports))))
    files={}
    for name in sorted(modules|{'json.encoder','json.decoder','json.scanner'}):
        p=LIB.joinpath(*name.split('.'));p=p.with_suffix('.py')if p.with_suffix('.py').is_file()else p/'__init__.py'
        if p.is_file():files[str(p.resolve())]=pin(p)
    closure=write(D/'runtime-closure-v2.json',dict(
        schema='ROOT-direct-projection-qualification-runtime-closure-v1',author_identity='/root',
        source_only=True,scientific_calls=0,actual_execution_authorized=False,scientific_acceptance=False,
        python=pin(PY),arms=arms,declaration=declaration,stdlib_files=list(files.values()),
        direct_import_census=census,direct_import_modules=sorted(modules),
        explicit_dynamic_edges=['Worker checked raw Source load/compile/exec for selected Arena/adapter/harness only.','Observer launches one exact runner; runner launches one exact helperworker.'],
        runtime_trust='Pinned interpreter and direct raw Python stdlib entry preimages; builtin/frozen/transitive stdlib and OS loader remain trusted, no hostile-code sandbox or whole-loader seal. Whole selected Source bytes checked before/after; callable/module/code/default identities checked at callbacks.',
        Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,search_calls=0,
        opaque_program_decodes=0,full_pipeline_qualified=False))
    manifest=[]
    order={'generic':0,'bank_A_fixed':1,'bank_A_symbolic':2,'bank_B_original006':3}
    for entry in sorted(subject_entries,key=lambda x:(order[x['bank']],x['arm']!='reference')):
        suffix=entry['bank']+'-'+entry['arm'];ident='direct-projection-qualification-'+suffix+'-ROOT-20261019-v2'
        subject=dict(schema='ROOT-direct-projection-qualification-plan-v1',invocation_id=ident,
            actual_directory=str(D/('actual-'+suffix+'-v2')),arm=entry['arm'],bank=entry['bank'],python=pin(PY),
            sources=arms[entry['arm']],inputs=entry['inputs'],limits=w['LIMITS'],arena_limits=w['ARENA_LIMITS'],
            adapter_limits=w['ADAPTER_LIMITS'],declaration=declaration,runtime_closure=closure)
        sha=hashlib.sha256(canonical(subject)).hexdigest()
        authorization=write(folder/('authorization-false-'+suffix+'.json'),dict(
            schema='ROOT-direct-projection-qualification-authorization-v1',author_identity='/root',
            actual_execution_authorized=False,maximum_actual_invocations=1,subject_sha256=sha,
            review_roles={},scope='FALSE metadata only. No subject execution authorized.'))
        plan=write(folder/('plan-false-'+suffix+'.json'),dict(subject,authorization=authorization))
        manifest.append(dict(arm=entry['arm'],bank=entry['bank'],plan=plan,subject=subject,subject_sha256=sha,
                             actual_directory=subject['actual_directory']))
    final=write(D/'prospective-metadata-manifest-v2.json',dict(schema='ROOT-direct-projection-prospective-metadata-manifest-v1',
        author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,
        author_source=pin(__file__),declaration=declaration,runtime_closure=closure,rows=manifest,
        total_actuals_proposed=8,actuals_launched=0))
    print(json.dumps(final,sort_keys=True))


if __name__=='__main__':
    assert len(sys.argv)==4,'harness Source, harness declaration, ordinary subjectentries JSON'
    main(*sys.argv[1:])
