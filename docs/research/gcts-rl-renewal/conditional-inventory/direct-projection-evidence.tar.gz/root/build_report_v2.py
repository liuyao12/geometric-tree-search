"""Passive saved-metadata report renderer, never a helper/proof invocation."""
from pathlib import Path
import html
import json

D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
OUT=D/'publication-staging-v1'


def esc(value):return html.escape(str(value))
def math(value):return '\\('+value+'\\)'


def main():
    summary=json.loads((D/'ROOT-qualification-cohort-closure-v1.json').read_bytes())
    assert summary['mathematical_proof_accepted']is False and summary['full_pipeline_qualified']is False
    OUT.mkdir(exist_ok=False)
    (OUT/'direct-projection-summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
    rows=[];bars=[]
    scale_bytes=max(2*1073741824,max((r.get('worker_peak_bytes')or 0)for r in summary['rows']))
    names={'generic':'Structural and failure checks','bank_A_fixed':'Complete saved result A',
           'bank_A_symbolic':'Complete saved result B','bank_B_original006':'Six complete development roots'}
    for row in summary['rows']:
        elapsed=row.get('elapsed_seconds');peak=row.get('worker_peak_bytes')
        time_text='Not measured'if elapsed is None else math(f'{elapsed:.3f}\\,\\mathrm{{s}}')
        peak_text='Not measured'if peak is None else math(f'{peak/1073741824:.3f}\\,\\mathrm{{GiB}}')
        arm='Previous normalization'if row['arm']=='reference'else'Direct capture'
        rows.append('<tr><th>'+esc(names[row['bank']])+'</th><td>'+arm+'</td><td>'+esc(row['classification'])+
                    '</td><td>'+time_text+'</td><td>'+peak_text+'</td></tr>')
        if row['bank']!='generic'and peak is not None:
            width=100*peak/scale_bytes
            bars.append('<div class="bar-row"><span>'+esc(names[row['bank']])+' · '+arm+'</span><div class="track">'+
                        '<i class="'+row['arm']+'" style="width:'+f'{width:.3f}'+'%"></i><b></b></div><span>'+peak_text+'</span></div>')
    candidate=sum(row['gate_passed']for row in summary['rows']if row['arm']=='candidate')
    accepted=sum(row['gate_passed']for row in summary['rows'])
    template=r'''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Direct evidence capture — GCTS research</title>
<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script>
<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>
<style>*{box-sizing:border-box}body{margin:0;background:#f2f5f4;color:#173940;font:17px/1.65 system-ui,sans-serif}main{max-width:1160px;margin:auto;padding:30px 26px 80px}nav{display:flex;gap:22px;flex-wrap:wrap;font-size:14px}a{color:#12666d}h1{font:600 clamp(34px,5vw,52px)/1.15 Georgia,serif;max-width:950px}h2{font:600 28px/1.3 Georgia,serif}.lead{font-size:21px;max-width:1000px}.eyebrow{font-size:12px;text-transform:uppercase;letter-spacing:1.4px;color:#416c73;margin-top:35px}.boundary{padding:20px 24px;background:#fff0d8;border-left:5px solid #aa7131}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}article{padding:20px 22px;background:white;border:1px solid #c4d5d4}article h3{margin-top:0;font-size:18px}.metric{font:600 34px Georgia,serif;color:#386b69}section{margin-top:44px;scroll-margin-top:22px}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;min-width:900px;background:white;font-size:14px}th,td{padding:13px 14px;border-bottom:1px solid #c4d5d4;text-align:left;vertical-align:top}thead{background:#e0eae8}.small{font-size:14px;color:#526b72}.pipeline{display:flex;gap:9px;align-items:stretch;flex-wrap:wrap;margin:15px 0}.box{padding:13px 16px;border:2px solid #427d79;background:#e0efeb}.temporary{border-color:#a67d50;background:#fff1df}.arrow{align-self:center}.bar-row{display:grid;grid-template-columns:310px 1fr 100px;align-items:center;gap:14px;margin:14px 0;font-size:13px}.track{height:22px;background:#dce5e4;position:relative}.track i{display:block;height:100%}.track i.reference{background:#9a7e5a}.track i.candidate{background:#367e7b}.track b{position:absolute;left:@@LIMIT@@%;top:-4px;height:30px;border-left:2px dashed #a34f43}code{font-size:.86em;background:#e4edeb;padding:2px 4px}footer{border-top:1px solid #bdcece;margin-top:50px;padding-top:18px}@media(max-width:740px){main{padding:22px 16px 60px}.grid{grid-template-columns:1fr}.bar-row{grid-template-columns:1fr 80px}.bar-row>span:first-child{grid-column:1/-1}.pipeline{display:grid;grid-template-columns:1fr}.arrow{display:none}}</style></head>
<body><main><nav><a href="reader.html#direct-projection">Research notebook</a><a href="cluster-composer.html#results">Previous failed comparison</a><a href="#results">Eight specifications</a><a href="#evidence">Evidence</a></nav>
<p class="eyebrow">19 October 2026 · finite representation experiment</p>
<h1>Can complete proof evidence be captured with fewer temporary copies?</h1>
<p class="lead">The earlier cluster-composer comparison stopped during evidence assembly. This round tests a new capture path on complete saved documents and fixed structural cases. It performs no proof search and discovers no theorem.</p>
<div class="grid"><article><div class="metric">@@CANDIDATE@@</div>New-path subjects passing complete helper gates.</article><article><div class="metric">@@ALL@@</div>All subjects passing the same resource and custody gates.</article><article><div class="metric">@@ZERO@@</div>New proofs. Full production qualification remains open.</article></div>
<section id="change"><h2>The change is at the evidence boundary.</h2>
<p>Both paths start with the same complete ordinary values. The previous adapter serializes a whole subtree, parses a normalized copy and serializes it again before capture. The new adapter builds the typed evidence graph directly. Exact tuples project to JSON arrays at this explicitly declared boundary.</p>
<div class="pipeline" aria-label="Previous capture path"><div class="box">Original complete values</div><span class="arrow">›</span><div class="box temporary">Whole JSON bytes and parsed copy</div><span class="arrow">›</span><div class="box">Typed capture and second read</div></div>
<div class="pipeline" aria-label="Direct capture path"><div class="box">Original complete values</div><span class="arrow">›</span><div class="box">Direct typed capture</div><span class="arrow">›</span><div class="box">Complete second read before publication</div></div>
<p class="small">These are representation diagrams, not proof tiles or learned markings. Bounded fragment caches and final serialization remain. Removing normalizing copies does not identify the allocation responsible for an earlier peak.</p>
<p>The legacy strict capture API remains unchanged. The new entry has its own execution profile and charges the work it actually performs. It retains every ordered occurrence, exact scalar distinction, complete byte preimage and full second reconciliation. Its reduced normalization work is not a retroactive pass under the previous operation trace.</p></section>
<section id="results"><h2>All predeclared outcomes.</h2><div class="table-wrap"><table><thead><tr><th>Complete bank</th><th>Capture path</th><th>Full helper outcome</th><th>Observed terminal</th><th>Worker highwater</th></tr></thead><tbody>@@ROWS@@</tbody></table></div>
<p class="small">Terminal elapsed time starts at runner Source entry. Failed or unfinished trials are retained; a cutoff is not a completed cost. Each complete original bank uses a fresh process for each implementation. Generic timing is not a speed comparison: the new API has additional diagnostics that are prospectively inapplicable to the reference.</p>
<h3>Whole-bank worker memory</h3>@@BARS@@
<p class="small">Bars use one common scale. The dashed line marks \(1\,\mathrm{GiB}\), the standalone helper bound. These are full-lifetime Darwin highwaters. Native is absent; these values cannot establish the production worker-plus-Native bound or remaining pipeline headroom.</p>
<p>All subjects retain the original \(180\,\mathrm{s}\) positive boundary and \(210\,\mathrm{s}\) later terminal boundary, \(128\,\mathrm{MiB}\) logical and physical output caps, separate log and receipt limits, and invocation-total \(400\) million Arena and \(400\) million adapter work ceilings. A small diagnostic quota exercises a refusal; it does not replace the global limits.</p></section>
<section id="coverage"><h2>What was specified and checked.</h2><p>The large banks are two whole saved results and all six complete retained development preimages, including the full model. Their provenance distinguishes complete representation acceptance from proof and production-resource acceptance. The original parents and their recorded timing-field exclusions remain explicit.</p>
<p>The generic bank has \(23\) fixed cases across \(6\) groups. It covers repeated references, exact scalar and tuple projections, size and depth refusals, callback ownership, reentrancy, incomplete streams and interrupted publication. Failure-phase counters record whether an injection actually reached its intended build, second-read or final-guard boundary. The three new-API cases are declared inapplicable to the reference.</p>
<p>Failed attempts keep bounded, detached diagnostics with no proof authority. Constructor work that cannot be observed is marked unavailable or a lower bound. Cleanup must preserve the active foreign exception; a real Root deadline or Source fault cannot satisfy an expected-negative test.</p></section>
<section id="earlier"><h2>The earlier bookkeeping failure remains in the record.</h2><p>The preceding version launched two generic subjects. The reference passed its finite gates. The candidate returned its check packet but the worker rejected its \(526\) separate lifetime registrations against a bound of \(512\). It has no admitted candidate result. The six large-bank subjects were not run after that common defect.</p><p>The successor uses one early Root-owned append-only collection containing every retained entry, including duplicates. It changes the registration layout while preserving all evidence and lifetimes. The original limits and cases remain fixed. The old failure and unused subjects stay separate; the current cohort does not rescue them.</p></section><section id="next"><h2>The proof-search question remains separate.</h2><p>A finite capture result does not establish a theorem, a GCTS advantage, learned markings, RL improvement or useful lemma-family transfer. It does not qualify the full cold pipeline. The next production test needs a fresh reviewed closure and the complete logical, point, inverse, result and resource checks under the original limits.</p>
<p>Parallel work separated implementation, fixture design and critical review. Review caught cleanup masking, missing failure diagnostics and incomplete case-to-output joins before execution. One reviewer covered the separate review scopes; Source authorship ancestry is recorded in the packet. The research program remains active.</p></section>
<section id="evidence"><h2>Inspect the record.</h2><p><a href="direct-projection-summary.json">Structured summary</a> · <a href="direct-projection-evidence.tar.gz">Evidence packet</a> · <a href="direct-projection-manifest.json">Publication manifest</a> · <a href="direct-projection-review.json">Independent review</a></p><p class="small">The packet and manifest distinguish current Sources from preserved drafts and failed or unexecuted subjects. Saved observations supply no replay permission or proof authority; a new execution needs its own bounded local declaration.</p></section>
<footer class="small">Rendered from saved ordinary metadata. No proof engine, search, Model, Native checker, Reader, inverse or failed-prefix decoder is invoked to produce this report.</footer></main></body></html>'''
    text=template.replace('@@ROWS@@',''.join(rows)).replace('@@BARS@@',''.join(bars))
    text=text.replace('@@CANDIDATE@@',math(str(candidate)+'/4')).replace('@@ALL@@',math(str(accepted)+'/8')).replace('@@ZERO@@',math('0'))
    text=text.replace('@@LIMIT@@',f'{100*1073741824/scale_bytes:.6f}')
    assert '@@'not in text
    (OUT/'direct-projection.html').write_text(text)
    print(json.dumps(dict(staging=str(OUT),rows=len(rows),candidate_helper_passes=candidate,all_helper_passes=accepted)))


if __name__=='__main__':main()
