"""Read saved ordinary receipts only after all owned actuals are closed."""
from pathlib import Path
import hashlib
import json
import os

D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')


def pin(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def main():
    gp=D/'ROOT-scope-adoption-and-grants-v3.json';g=json.loads(gp.read_bytes());rows=[]
    for item in g['issued']:
        p=Path(item['plan']['path']);plan=json.loads(p.read_bytes());a=Path(plan['actual_directory'])
        folder=p.parent/(p.stem+'-terminal-observation')
        row=dict(arm=item['arm'],bank=item['bank'],plan=item['plan'],subject_sha256=item['subject_sha256'])
        if not a.exists():
            assert not os.path.lexists(folder)
            row.update(launched=False,gate_passed=False,classification='Not run after common defect',elapsed_seconds=None,worker_peak_bytes=None)
            rows.append(row);continue
        r=json.loads((a/'runner-receipt.json').read_bytes());t=json.loads((folder/'terminal.json').read_bytes())
        assert r['worker_reaped']and r['owned_group_absent']and r['regular_logs_closed']
        assert r['plan']==item['plan']and t['plan']==item['plan']and r['worker_launch_attempts']==1
        passed=t['terminal_gate_passed']is True
        row.update(launched=True,gate_passed=passed,classification='Helper gates passed'if passed else'Complete helper gates failed',
            elapsed_seconds=t['runner_clock_elapsed_seconds'],worker_peak_bytes=r['worker_wait4_usage']['ru_maxrss'],
            worker_exit_code=r['worker_exit_code'],runner_exit_code=t['runner_exit_code'],runner_errors=r['errors'],
            actual_directory=str(a),terminal=pin(folder/'terminal.json'),
            files={f.name:pin(f)for f in a.iterdir()if f.is_file()},
            complete_result_exists=(a/'result.json').is_file(),worker_success_receipt_exists=(a/'worker-receipt.json').is_file())
        if (a/'result.json').is_file():
            result=json.loads((a/'result.json').read_bytes());q=result['qualification']
            row.update(complete_qualification=q,complete_outputs=result['outputs'],canonical_logical_bytes=result['canonical_logical_bytes'])
        if (a/'worker-failure.json').is_file():
            f=json.loads((a/'worker-failure.json').read_bytes())
            row.update(failure_phase=f['phase'],failure_error_type=f['error_type'],failure_message=f['message'],
                failure_prefix=f.get('qualification_prefix'),failure_returned_packet_has_no_authority=f.get('returned_nonadmitted_packet')is not None)
        rows.append(row)
    assert len(rows)==8
    v2=D/'ROOT-cohort-V2-common-defect-closure-v1.json'
    record=dict(schema='ROOT-direct-projection-qualification-cohort-closure-v1',author_identity='/root',
        current_cohort='V3 early aggregate lifetime registration; same complete banks/cases/caps',
        rows=rows,planned_subjects=8,launched_subjects=sum(r['launched']for r in rows),
        helper_gate_passes=sum(r['gate_passed']for r in rows),
        candidate_helper_gate_passes=sum(r['gate_passed']for r in rows if r['arm']=='candidate'),
        original_caps_unchanged=True,all_launched_actuals_closed=True,all_owned_groups_absent=True,
        all_exec_handles_closed=True,mathematical_proof_accepted=False,full_pipeline_qualified=False,
        candidate_finite_qualified=False,independent_saved_review_pending=True,
        Root_grants=pin(gp),historical_V2=pin(v2),goal_status='active',goal_complete=False,
        limits='Original180 positive/fullreading/knownexit,210 laterterminal;1GiB standalone helperhighwater,128MiB logical+physical with separate4MiBlogs/receipt and9MiBreserves;400m Arena/400mAdapter invocation totals. Native absent, no production sum or fit authority.',
        scope='Finite representation/helper experiment only, no theorem search/discovery, Model/Native/Reader/inverse execution or GCTS/RL ranking. Three whole banks are matched; generic candidate extras make generic times incomparable. No failed-prefix rescue or omission. Every historical/current failure and unrun subject remains in its own cohort denominator.')
    target=D/'ROOT-qualification-cohort-closure-v1.json'
    with target.open('x')as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(dict(record=pin(target),launched=record['launched_subjects'],helper_passes=record['helper_gate_passes'],candidate_helper_passes=record['candidate_helper_gate_passes']),sort_keys=True))


if __name__=='__main__':main()
