"""Package frozen saved evidence, raw Sources and complete declared inputs only."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile

D = Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
OUT = D / 'publication-staging-v1'


def descriptor(p):
    h = hashlib.sha256()
    n = 0
    tail = b''
    patterns = [rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
                rb'ghp_[A-Za-z0-9]{30,}', rb'github_pat_[A-Za-z0-9_]{30,}',
                rb'sk-proj-[A-Za-z0-9_-]{30,}', rb'AKIA[0-9A-Z]{16}',
                rb'(?i)Authorization:\s*Bearer\s+[A-Za-z0-9._-]{20,}']
    with p.open('rb') as f:
        while b := f.read(1048576):
            h.update(b)
            n += len(b)
            for pattern in patterns:
                assert re.search(pattern, tail + b) is None, ('possible secret; do not package', str(p))
            tail = b[-256:]
    return dict(path=str(p.resolve()), bytes=n, sha256=h.hexdigest())


def main():
    closure = json.loads((D / 'ROOT-qualification-cohort-closure-v1.json').read_bytes())
    assert closure['all_current_V3_grants_retired_for_further_Root_use'] is True
    assert closure['all_owned_processes_and_groups_now_observed_absent'] is True
    review = Path('/private/tmp/gcts-direct-projection-review-20261019/typed-saved-qualification-review-v3.json')
    assert review.is_file(), 'saved-data review must be frozen before packaging'
    sources = []
    for label, root in [
        ('root', D),
        ('library', Path('/private/tmp/gcts-direct-projection-library-20261019')),
        ('qualification', Path('/private/tmp/gcts-direct-projection-qualification-20261019')),
        ('review', Path('/private/tmp/gcts-direct-projection-review-20261019')),
        ('cleanup-diagnosis', Path('/private/tmp/gcts-direct-projection-cleanup-diagnosis-20261019')),
    ]:
        for p in sorted(root.rglob('*')):
            if OUT in p.parents or p.name.startswith('ROOT-publication-'):
                continue
            assert not p.is_symlink(), 'no symlinks in public packet'
            if p.is_file():
                assert p.suffix not in ('.pyc', '.gz'), 'unexpected binary/cache in source packet'
                sources.append((p, label + '/' + str(p.relative_to(root))))
    grants = json.loads((D / 'ROOT-scope-adoption-and-grants-v3.json').read_bytes())
    external = {}
    for row in grants['issued']:
        plan = json.loads(Path(row['plan']['path']).read_bytes())
        for item in plan['inputs']:
            pin = item['pin']
            external[pin['path']] = (pin, 'fixtures/' + pin['sha256'] + '-' + Path(pin['path']).name)
        if row['arm'] == 'reference':
            for role in ('arena', 'adapter'):
                pin = plan['sources'][role]
                external[pin['path']] = (pin, 'reference/' + Path(pin['path']).name)
    for path, (pin, arc) in sorted(external.items()):
        p = Path(path)
        assert descriptor(p) == pin
        sources.append((p, arc))
    assert len({arc for _, arc in sources}) == len(sources)
    records = [dict(archive_path=arc, original=descriptor(p)) for p, arc in sources]
    inventory = dict(schema='direct-projection-public-evidence-inventory-v1', entries=records,
        no_subject_execution=True, sensitive_pattern_scan_passed=True,
        scope='Raw saved evidence and complete original declared preimages. No primary reader/index or .gcts-active content is added. Historical bad drafts/failures/unrun plans stay explicitly nonauthoritative. All V2/V3 grants are retired; packet is not execution authorization.',
        portability='Original absolute descriptors are preserved with an archive path map. Interpreter and stdlib, Native and OS are not redistributed; this packet is not a portable replay environment. Complete eight fixture inputs are included; parent extraction provenance stays pinned, without opening the original opaque parent artifacts.',
        proof_authority=False, full_pipeline_qualified=False)
    readme = ('DIRECT EVIDENCE CAPTURE — FINITE AND NEGATIVE OBSERVATIONS\n\n'
              'Read root/ROOT-qualification-cohort-closure-v1.json first. V3: 8 planned, '
              '3 launched, 2 generic passes, 1 deadline+cleanup failure, 5 NOT_RUN. '
              'No whole-bank candidate ran. Original exit/highwater are unavailable for the failed worker; '
              'a later OS absence receipt is not recovery. All V2/V3 execution grants are retired.\n\n'
              'V2 negatives, Source corrections and unexecuted drafts are preserved. Inventory paths map '
              'original descriptors to archive entries. No theorem, GCTS/RL advantage, full-cold qualification '
              'or replay authorization is conferred. Original fixture inputs are complete; this archive '
              'does not redistribute the runtime or provide a portable trusted environment.\n').encode()
    target = OUT / 'direct-projection-evidence.tar.gz'
    assert not target.exists()
    with tarfile.open(target, 'w:gz', compresslevel=6) as archive:
        for p, arc in sources:
            info = archive.gettarinfo(str(p), arcname=arc)
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mode = 0o644
            with p.open('rb') as f:
                archive.addfile(info, f)
        for name, raw in [('EVIDENCE-INVENTORY.json', (json.dumps(inventory, sort_keys=True, indent=2) + '\n').encode()),
                          ('README.txt', readme)]:
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    print(json.dumps(dict(packet=descriptor(target), entries=len(records),
                          raw_bytes=sum(r['original']['bytes'] for r in records)), sort_keys=True))


if __name__ == '__main__':
    main()
