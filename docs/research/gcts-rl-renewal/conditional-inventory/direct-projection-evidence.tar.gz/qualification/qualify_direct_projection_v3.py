"""Finite harness Source only; fixture/component calls require a granted worker.

No loader, worker, controller, Native, Model, search, Reader or inverse lives here.
The Root worker injects exact modules, callbacks, output sink and lifetime owner.
"""
import hashlib
import json
from pathlib import Path

VERSION = 'direct-projection-finite-harness-v3-one-lifetime-aggregate'
FIXTURES = (
 ('wide_unique','wide_array'),('wide_unique','wide_object'),
 ('shared_repeated','shared_subtree'),('shared_repeated','equal_distinct'),
 ('shared_repeated','tuple_projection'),
 ('deep_and_boundary','depth_limit'),('deep_and_boundary','chunk_unicode'),
 ('deep_and_boundary','projection_caps'),
 ('multiple_roots_and_lifetimes','mixed_roots'),
 ('multiple_roots_and_lifetimes','repeated_ports'),
 ('multiple_roots_and_lifetimes','cross_store'),
 ('callback_and_foreign_failure','check_early'),
 ('callback_and_foreign_failure','check_during'),
 ('callback_and_foreign_failure','guard_stopiteration'),
 ('callback_and_foreign_failure','stream_stopiteration'),
 ('callback_and_foreign_failure','reentrancy'),
 ('callback_and_foreign_failure','store_postcommit_guard'),
 ('callback_and_foreign_failure','unread_tail_mutation'),
 ('callback_and_foreign_failure','arena_foreign_phases'),
 ('exact_scalars_and_absence','scalar_domain'),
 ('exact_scalars_and_absence','list_subclass'),
 ('exact_scalars_and_absence','nonstring_key'),
 ('exact_scalars_and_absence','cycle'))


class QualificationFailure(RuntimeError):
    pass


class ForeignQualificationError(BaseException):
    pass


def _need(ok, text):
    if not ok:
        raise QualificationFailure(text)


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,
                      allow_nan=False).encode('utf8')


class _Oracle:
    def __init__(self, segments):
        self.segments=tuple(memoryview(x) for x in segments)
        self.index=0;self.offset=0;self.total=sum(len(x) for x in self.segments)
        self.compared=0
    def compare(self,chunk):
        _need(type(chunk)is bytes and bool(chunk),'nonempty exact bytes stream chunk')
        at=0
        while at<len(chunk):
            while self.index<len(self.segments) and self.offset==len(self.segments[self.index]):
                self.index+=1;self.offset=0
            _need(self.index<len(self.segments),'actual output longer than immutable original')
            part=self.segments[self.index]
            n=min(len(chunk)-at,len(part)-self.offset)
            _need(chunk[at:at+n]==part[self.offset:self.offset+n],'entire actual byte preimage mismatch')
            at+=n;self.offset+=n;self.compared+=n
    def finish(self):
        _need(self.compared==self.total,'actual output shorter than immutable original')


class VerifiedStream:
    """Explicit cursor: foreign StopIteration never crosses a generator frame."""
    def __init__(self, stream, oracle):
        self.stream=stream;self.oracle=oracle;self.completed=False;self.digest=hashlib.sha256()
    def __iter__(self):return self
    def __next__(self):
        try:chunk=next(self.stream)
        except StopIteration:
            if self.stream.completed is not True:raise
            self.oracle.finish();self.completed=True;raise
        self.oracle.compare(chunk);self.digest.update(chunk);return chunk
    def close(self):
        # Caller owns active-exception preservation; normal close errors escape.
        return self.stream.close()


class _Context:
    def __init__(self,plan,decl,arena,adapter,check,guard,emit,retain):
        self.plan=plan;self.decl=decl;self.arena=arena;self.adapter=adapter
        self.check_root=check;self.guard_root=guard;self.emit_root=emit;self.retain_root=retain
        self.stores=[];self.direct=[];self.store_ids=set();self.direct_ids=set()
        self.last={};self.fault=None;self.hook=None;self.check_calls=0;self.guard_calls=0
        self.public_calls=0;self.passive_calls=0;self.cleanup_failures=0;self.outputs=[]
        self.shared_arena=None;self.direct_committed=[]
        self.rows=[];self.active_fixture=None;self.stage='subject_preflight'
        self.operation=None;self.inflight=None;self.active_input=None
        self.active_output=None;self.active_cursor=None
        self.lifetime=[];self.lifetime_registrations=0
    def root(self,function,*args):
        try:return function(*args)
        except BaseException as error:
            if self.fault is None:self.fault=error
            raise
    def no_fault(self,primary=None):
        if self.fault is not None:
            raise self.fault
    def register_lifetime(self):
        _need(self.lifetime_registrations==0,'one Root lifetime registration only')
        self.root(self.retain_root,self.lifetime)
        self.lifetime_registrations=1
    def retain(self,value):
        _need(self.lifetime_registrations==1,'Root-owned lifetime registered first')
        self.lifetime.append(value)  # Every old entry, including duplicates; no early release.
    def retention_census(self):
        return dict(root_registration_count=self.lifetime_registrations,
            aggregate_container_count=1,aggregate_value_entries=len(self.lifetime),
            root_registration_confirmed=self.lifetime_registrations==1,
            duplicate_entries_preserved=True,
            count_scope='Value entries, not all Python objects reachable through full retained graphs.')
    def sstats(self,s):self.passive_calls+=1;return s.statistics()
    def astats(self,a):self.passive_calls+=1;return a.statistics()
    def totals(self):
        arena_work=0;adapter_work=0
        for s in self.stores:
            st=self.sstats(s);aw=st['arena']['counters'].get('work',0);dw=st['operations']
            key=('store',id(s));old=self.last.get(key,(0,0))
            _need(aw>=old[0] and dw>=old[1],'failed attempted work cannot reset')
            self.last[key]=(aw,dw);arena_work+=aw;adapter_work+=dw
        for a in self.direct:
            aw=self.astats(a)['counters'].get('work',0);key=('arena',id(a));old=self.last.get(key,(0,0))
            _need(aw>=old[0],'direct Arena attempted work cannot reset')
            self.last[key]=(aw,0);arena_work+=aw
        result=dict(arena_work=arena_work,adapter_operations=adapter_work)
        _need(arena_work<=self.decl['operation_ceilings']['arena_work'] and
              adapter_work<=self.decl['operation_ceilings']['adapter_operations'],
              'invocation-total unique instance work ceilings')
        return result
    def pulse(self,kind):
        self.root(self.check_root if kind=='check' else self.guard_root)
        try:self.totals()
        except BaseException as error:
            if self.fault is None:self.fault=error
            raise
        if kind=='check':self.check_calls+=1
        else:self.guard_calls+=1
        hook=self.hook
        if hook is not None:hook(kind)
    def check(self):self.pulse('check')
    def guard(self):self.pulse('guard')
    def store(self):
        _need(len(self.stores)<self.decl['call_bounds']['fresh_Stores'],'fresh Store bound')
        _need(len(self.stores)+len(self.direct)<self.decl['call_bounds']['total_Arenas'],'total Arena bound')
        self.stage='construct_Store';self.inflight=dict(kind='Store',registered=False)
        s=self.adapter.Store(arena_module=self.arena,source_epoch='qualification-source-v1',
            semantic_epoch='qualification:'+self.plan['bank'],arena_limits=self.plan['arena_limits'],
            check=self.check,source_guard=self.guard,limits=self.plan['adapter_limits'])
        _need(id(s)not in self.store_ids,'each Store constructed once')
        self.store_ids.add(id(s));self.stores.append(s);self.inflight['registered']=True
        self.retain(s);self.totals();self.inflight=None;return s
    def direct_arena(self,overrides=None):
        limits=dict(self.plan['arena_limits'])
        if overrides:limits.update(overrides)
        _need(len(self.direct)<self.decl['call_bounds']['direct_Arenas'],'direct Arena bound')
        _need(len(self.stores)+len(self.direct)<self.decl['call_bounds']['total_Arenas'],'total Arena bound')
        self.stage='construct_direct_Arena';self.inflight=dict(kind='direct_Arena',registered=False)
        a=self.arena.Arena(source_epoch='q',semantic_epoch='q',check=self.check,
                           source_guard=self.guard,limits=limits)
        _need(id(a)not in self.direct_ids,'each separate direct Arena constructed once')
        self.direct_ids.add(id(a));self.direct.append(a);self.inflight['registered']=True
        self.retain(a);self.totals();self.inflight=None;return a
    def call(self,function,*args,**kwargs):
        self.public_calls+=1
        _need(self.public_calls<=self.decl['call_bounds']['component_calls'],'component call bound')
        self.operation=function.__name__;self.stage='component_precheck';self.check()
        # No finally/cleanup may replace a component's active primary object.
        self.stage='inside_component'
        value=function(*args,**kwargs)
        self.stage='component_return_check';self.no_fault();self.totals();return value
    def export(self,s,r,label,segments):
        sealed=self.call(s.seal,r);wire=self.call(s.wire,sealed)
        self.retain(dict(store=s,root=r,sealed=sealed,wire=wire))
        stream=self.call(s.canonical,r);cursor=VerifiedStream(stream,_Oracle(segments));self.retain(cursor)
        self.active_output=label;self.active_cursor=cursor;self.stage='emit_complete_canonical_BODY'
        output=self.root(self.emit_root,label,cursor)
        self.no_fault();_need(cursor.completed is True,'complete explicit cursor required')
        digest=cursor.digest.copy();digest.update(b'\n')
        _need(output['bytes']==cursor.oracle.total+1 and output['sha256']==digest.hexdigest(),
              'sink complete actual BODY+oneLF descriptor')
        self.outputs.append(output);self.active_output=None;self.active_cursor=None;return output


def _consume(ctx,cursor):
    try:
        while True:
            try:next(cursor)
            except StopIteration:
                if cursor.completed is True:break
                raise
    except BaseException:
        try:cursor.close()
        except BaseException:
            try:ctx.cleanup_failures+=1
            except BaseException:pass
        raise  # Exact primary, including foreign StopIteration/Root object.
    else:cursor.close()  # Normal cleanup failures are genuine failures.


def _negative(ctx,action,predicate):
    try:action()
    except BaseException as error:
        ctx.no_fault(primary=error)
        _need(predicate(error),'declared negative did not preserve its required class/identity')
        ctx.totals();return error
    raise QualificationFailure('declared negative unexpectedly returned')


def _owned_store_error(ctx,error):
    return (type(error)in(ctx.adapter.EvidenceDataError,ctx.adapter.EvidenceReentrancy)
            or ctx.adapter.is_own_limit(error) or type(error)is ctx.arena.ArenaDataError
            or ctx.arena.is_own_limit(error))


def _positive(ctx,value,label):
    expected=_canonical(value);ctx.retain(dict(original_value=value,expected=expected))
    s=ctx.store();r=ctx.call(s.assemble,value,label=label);ctx.retain(r)
    return ctx.export(s,r,label,[expected])


def _poison_rejects(ctx,s):
    _need(ctx.sstats(s)['failed'] is True,'upper Store poisoned on escaping failure')
    _negative(ctx,lambda:ctx.call(s.capture,None,label='post-failure'),
              lambda e:type(e)is ctx.adapter.EvidenceDataError)


def _arena_bytes(ctx,a,h,body):
    stream=ctx.call(a.iter_canonical,h);cursor=VerifiedStream(stream,_Oracle([body]));ctx.retain(cursor)
    _consume(ctx,cursor)


def _arena_baseline(ctx):
    if ctx.shared_arena is None:
        a=ctx.direct_arena();h=ctx.call(a.capture,[0],label='committed-baseline')
        ctx.shared_arena=a;ctx.direct_committed.append((h,b'[0]'));ctx.retain(h)
    return ctx.shared_arena


def _old_state_check(ctx,a,before):
    after=ctx.astats(a)
    for k in ('nodes','edges','roots','cache_entries','cache_bytes','documents','logical_document_bytes','physical_wire_bytes'):
        _need(after[k]==before[k],'failed local transaction changed committed observables')
    _need(after['counters'].get('work',0)>=before['counters'].get('work',0),'failed work monotone')
    for h,body in ctx.direct_committed:_arena_bytes(ctx,a,h,body)


def _caps_case(ctx):
    if ctx.plan['arm']=='reference':return dict(status='DECLARED_NOT_APPLICABLE_NO_NEW_API')
    a=_arena_baseline(ctx);values=[None,True,False,(),[],{},'\n雪"',-0.0]
    for number,value in enumerate(values):
        body=_canonical(value);ctx.retain(dict(value=value,body=body))
        for relation,cap in (('below',len(body)-1),('at',len(body)),('above',len(body)+1)):
            label='cap-'+str(number)+'-'+relation;before=ctx.astats(a)
            if relation=='below':
                _negative(ctx,lambda:ctx.call(a.capture_legacy_json,value,label=label,value_bytes=cap),
                    lambda e:ctx.arena.is_own_limit(e) and e.reason=='projection_value_bytes')
                _old_state_check(ctx,a,before)
            else:
                h=ctx.call(a.capture_legacy_json,value,label=label,value_bytes=cap)
                ctx.direct_committed.append((h,body));ctx.retain(h);_arena_bytes(ctx,a,h,body)
    global_arena=ctx.direct_arena({'root_expanded_bytes':32})
    _negative(ctx,lambda:ctx.call(global_arena.capture_legacy_json,'x'*40,label='global-bound',value_bytes=64),
        lambda e:ctx.arena.is_own_limit(e) and e.reason=='root_expanded_bytes')
    quota_arena=ctx.direct_arena({'work':4096})
    _negative(ctx,lambda:ctx.call(quota_arena.capture,[0]*8192,label='owned-work'),
        lambda e:ctx.arena.is_own_limit(e) and e.reason=='work')
    return dict(status='CANDIDATE_API_CAPS_EXERCISED',per_call_BODY_caps=True,
                diagnostic_global_root_bytes=32,diagnostic_work=4096)


def _projection_phase_case(ctx,mutation=False):
    if ctx.plan['arm']=='reference':return dict(status='DECLARED_NOT_APPLICABLE_NO_NEW_API')
    a=_arena_baseline(ctx)
    phases=('unread-tail',) if mutation else ('build','second-read','final-guard')
    factories=(lambda:None,) if mutation else (
        lambda:ValueError('foreign'),lambda:RuntimeError('foreign'),
        lambda:StopIteration('foreign'),lambda:GeneratorExit('foreign'),
        lambda:SystemExit('foreign'),lambda:ctx.arena.ArenaLimit('work'))
    observations=[]
    for phase in phases:
        for factory in factories:
            value=['x'*8192 for _ in range(64)]+[0];ctx.retain(value)
            base=ctx.astats(a);counts=base['counters'];foreign=factory();seen=[False];reached=[None]
            def hook(kind):
                now=ctx.astats(a)['counters']
                change=lambda name:now.get(name,0)-counts.get(name,0)
                eligible=(kind=='check' and change('projection_capture_frames')>0 and
                          change('projection_reconciliation_begins')==0) if phase=='build' else (
                    kind=='check' and change('projection_reconciliation_begins')>0 and
                    change('projection_reconciliation_edges')>0 and
                    change('projection_reconciliation_complete_reads')==0) if phase=='second-read' else (
                    kind=='guard' and change('projection_reconciliation_complete_reads')>0 and
                    change('publication_bookkeeping')>0) if phase=='final-guard' else (
                    kind=='check' and change('projection_reconciliation_begins')>0 and
                    change('projection_reconciliation_complete_reads')==0 and
                    0<change('projection_reconciliation_edges')<64)
                if eligible and not seen[0]:
                    seen[0]=True
                    reached[0]={key:change(key) for key in (
                        'projection_capture_frames','projection_reconciliation_begins',
                        'projection_reconciliation_frames','projection_reconciliation_edges',
                        'projection_reconciliation_complete_reads','publication_bookkeeping')}
                    if mutation:value[64]=1
                    else:raise foreign
            ctx.hook=hook
            try:
                _negative(ctx,lambda:ctx.call(a.capture_legacy_json,value,label='failed-'+phase,value_bytes=134217728),
                    (lambda e:type(e)is ctx.arena.ArenaDataError) if mutation else (lambda e:e is foreign))
            finally:ctx.hook=None
            _need(seen[0],'declared exact callback phase was actually reached')
            if not mutation and type(foreign)is ctx.arena.ArenaLimit:
                _need(not ctx.arena.is_own_limit(foreign),'same class foreign error is not owned quota')
            _old_state_check(ctx,a,base)
            observations.append(dict(phase=phase,foreign_type=None if mutation else type(foreign).__name__,
                reached=True,reached_counter_deltas=reached[0],no_returned_handle=True,
                old_committed_observables_preserved=True))
    return dict(status='CANDIDATE_LOCAL_TRANSACTION_CONTRACT_EXERCISED',observations=observations,
                mutation_scope='Flat array edges<64 proves final scalar tail not read in second traversal; not a universal mutation seal.')


def _callback_case(ctx,name):
    s=ctx.store();value=list(range(8192));ctx.retain(value)
    foreign=StopIteration('foreign') if name in ('guard_stopiteration','stream_stopiteration') else ForeignQualificationError()
    before_check=ctx.check_calls;before_guard=ctx.guard_calls;seen=[False]
    if name=='stream_stopiteration':
        r=ctx.call(s.capture,value,label='stream-root');stream=ctx.call(s.canonical,r)
        cursor=VerifiedStream(stream,_Oracle([_canonical(value)]));ctx.retain(cursor)
        before_check=ctx.check_calls
    def hook(kind):
        eligible=(kind=='check' and ctx.check_calls-before_check>=4) if name in ('check_during','stream_stopiteration') else (
            kind=='guard' and ctx.guard_calls-before_guard>=1) if name in ('guard_stopiteration','reentrancy') else (
            kind=='guard' and ctx.sstats(s)['counters'].get('completed_captures',0)>0 and
            ctx.sstats(s)['arena']['roots']>0) if name=='store_postcommit_guard' else (
                kind=='check' and ctx.check_calls-before_check>=2)
        if eligible and not seen[0]:
            seen[0]=True
            if name=='reentrancy':return ctx.call(s.capture,0,label='illegal-reentrant')
            raise foreign
    ctx.hook=hook
    try:
        action=(lambda:_consume(ctx,cursor)) if name=='stream_stopiteration' else lambda:ctx.call(s.capture,value,label='failed-root')
        _negative(ctx,action,(lambda e:type(e)is ctx.adapter.EvidenceReentrancy)
                  if name=='reentrancy' else lambda e:e is foreign)
    finally:ctx.hook=None
    _need(seen[0],'planned callback reached')
    if name=='stream_stopiteration':
        _need(cursor.completed is False,'foreign stream StopIteration is never natural completion')
    # A stream read failure is not declared a Store mutation/poison transition.
    if name!='stream_stopiteration':_poison_rejects(ctx,s)
    return dict(status='EXACT_FOREIGN_OR_REENTRANCY_OBSERVED',reached=True,
        Store_failed=ctx.sstats(s)['failed'],orphan_committed_Arena_root_permitted=(name=='store_postcommit_guard'))


def _generic(ctx,name):
    if name=='projection_caps':return _caps_case(ctx)
    if name in ('unread_tail_mutation','arena_foreign_phases'):
        return _projection_phase_case(ctx,mutation=name=='unread_tail_mutation')
    if name in ('check_early','check_during','guard_stopiteration','stream_stopiteration','reentrancy','store_postcommit_guard'):
        return _callback_case(ctx,name)
    if name=='mixed_roots':
        s=ctx.store();values=[{'x':[0,1]},(False,-0.0,'雪')];ctx.retain(values)
        refs=[ctx.call(s.capture,v,label='root-'+str(i)) for i,v in enumerate(values)]
        expected={'a':values[0],'b':values[1]};r=ctx.call(s.assemble,dict(zip(('a','b'),refs)),label=name)
        return ctx.export(s,r,name,[_canonical(expected)])
    if name=='repeated_ports':
        s=ctx.store();value=[0,True,None];ctx.retain(value);r=ctx.call(s.capture,value,label='shared')
        joined=ctx.call(s.assemble,[r]*64,label=name)
        return ctx.export(s,joined,name,[_canonical([value]*64)])
    if name=='cross_store':
        a=ctx.store();b=ctx.store();r=ctx.call(a.capture,[0],label='foreign-owner');ctx.retain(r)
        _negative(ctx,lambda:ctx.call(b.assemble,{'r':r},label='foreign-reject'),
                  lambda e:type(e)is ctx.adapter.EvidenceDataError)
        _poison_rejects(ctx,b);return dict(status='CROSS_OWNER_REJECTED')
    if name=='wide_array':value=list(range(4096))
    elif name=='wide_object':value={'k'+str(i):[i,False] for i in range(1024)}
    elif name=='shared_subtree':
        child=[0,{'x':'雪'}];value=[child]*128
    elif name=='equal_distinct':value=[[0,{'x':'雪'}] for _ in range(128)]
    elif name=='tuple_projection':value={'nested':(None,True,False,(),[],{},(1,1.0,-0.0)),'repeat':[(0,1)]*64}
    elif name=='chunk_unicode':value={'text':'雪"\\\n'*16384}
    elif name=='scalar_domain':value={'values':[None,True,False,0,1,1.0,-0.0,[],(),{},'雪"\\\n'],'zero':0,'present':None}
    elif name=='depth_limit':
        value=0
        for _ in range(513):value=[value]
    elif name=='list_subclass':
        class LocalList(list):pass
        value=LocalList([0])
    elif name=='nonstring_key':value={0:'not a string key'}
    elif name=='cycle':value=[];value.append(value)
    else:raise QualificationFailure('undeclared fixture')
    ctx.retain(value)
    if name in ('depth_limit','list_subclass','nonstring_key','cycle'):
        s=ctx.store();_negative(ctx,lambda:ctx.call(s.capture,value,label='rejected'),lambda e:_owned_store_error(ctx,e))
        _poison_rejects(ctx,s);return dict(status='DECLARED_DOMAIN_OR_LIMIT_REJECTION')
    _positive(ctx,value,name);return dict(status='COMPLETE_BYTES_EXACT')


def _load_bank(ctx,entries):
    loaded=[]
    for entry in entries:
        ctx.stage='read_verify_parse_original';ctx.active_input=entry['id']
        pin=entry['pin'];ctx.check();raw=Path(pin['path']).read_bytes()
        _need(len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'],'whole immutable original input')
        value=json.loads(raw);ctx.retain(dict(raw_original=raw,original_value=value,input=entry))
        loaded.append((raw,value))
    ctx.active_input=None
    return loaded


def _subject(ctx):
    plan=ctx.plan;d=ctx.decl;arena_module=ctx.arena;adapter_module=ctx.adapter
    _need(d['schema']=='direct-projection-finite-harness-declaration-v3','exact harness declaration')
    arm,bank=plan['arm'],plan['bank'];_need(arm in ('reference','candidate'),'declared arm')
    subject=dict(arm=arm,bank=bank,inputs=plan['inputs'])
    _need(subject in d['subjects'],'complete predeclared subject, no input substitution')
    _need(plan['arena_limits']==d['arena_limits'] and plan['adapter_limits']==d['adapter_limits'],'unchanged full profiles')
    expected=d['implementations'][arm]
    _need(arena_module.IMPLEMENTATION_VERSION==expected['arena_implementation'] and
          adapter_module.VERSION==expected['adapter_version'],'exact selected API profile')
    ctx.retain(ctx);ctx.check();rows=ctx.rows
    if bank=='generic':
        _need(plan['inputs']==[],'generic values generated only within this granted subject')
        _need([list(x) for x in FIXTURES]==d['generic_fixture_order'],'complete exact generic census')
        for group,name in FIXTURES:
            ctx.active_fixture=name;ctx.stage='fixture_start'
            ctx.check();result=_generic(ctx,name);ctx.no_fault();ctx.totals()
            rows.append(dict(group=group,fixture=name,result=result))
        ctx.active_fixture=None
    else:
        _need(plan['inputs']==d['banks'][bank]['inputs'],'exact bank ids and immutable input pins')
        loaded=_load_bank(ctx,plan['inputs']);s=ctx.store()
        if bank.startswith('bank_A_'):
            _need(len(loaded)==1 and loaded[0][0].endswith(b'\n'),'whole original result with oneLF')
            raw,value=loaded[0];segments=[memoryview(raw)[:-1]]
            r=ctx.call(s.assemble,value,label=bank)
        elif bank=='bank_B_original006':
            labels=d['banks'][bank]['root_labels'];_need(len(loaded)==len(labels)==6,'all six whole roots')
            _need([entry['id'] for entry in plan['inputs']]==labels,'exact six-root input id order')
            refs={label:ctx.call(s.capture,value,label=label) for label,(raw,value) in zip(labels,loaded)}
            ctx.retain(refs);r=ctx.call(s.assemble,refs,label=bank);segments=[b'{']
            for i,(label,(raw,value)) in enumerate(zip(labels,loaded)):
                if i:segments.append(b',')
                segments.extend([_canonical(label),b':',raw])
            segments.append(b'}')
        else:raise QualificationFailure('undeclared bank')
        ctx.retain(dict(store=s,root=r,immutable_oracle_segments=segments,all_originals=loaded))
        output=ctx.export(s,r,bank,segments);rows.append(dict(bank=bank,complete_output=output))
    ctx.stage='final_positive_work_check';ctx.check();totals=ctx.totals();ctx.no_fault()
    result=dict(schema='direct-projection-finite-qualification-v1',status='FINITE_HELPER_CANDIDATE',
        arm=arm,bank=bank,rows=rows,outputs=ctx.outputs,operation_totals=totals,
        instance_census=dict(unique_Stores=len(ctx.stores),unique_separate_direct_Arenas=len(ctx.direct),
            unique_Arenas=len(ctx.stores)+len(ctx.direct),deduplication='object identity registration only; each Store constructs a private distinct Arena'),
        call_census=dict(component_calls=ctx.public_calls,passive_statistics_calls=ctx.passive_calls,
            check_callbacks=ctx.check_calls,guard_callbacks=ctx.guard_calls,cleanup_failures=ctx.cleanup_failures),
        original_values_retained_through_worker_positive_boundary=True,
        scientific_calls=0,Native_calls=0,Model_calls=0,search_calls=0,Reader_calls=0,inverse_calls=0,
        authority=False,full_pipeline_qualified=False,mathematical_proof_accepted=False,
        mathematical_authority=False,resource_authority=False,production_full_cold_qualified=False)
    ctx.retain(result);result['retention_census']=ctx.retention_census()
    _need(result['retention_census']['aggregate_value_entries']==
          d['lifetime_layout']['expected_successful_value_entries'][bank][arm],
          'every full retained value entry preserved')
    ctx.no_fault();return result


def _detached(value,budget,depth=0):
    """Bounded metadata copy only; never traverse original values/forests."""
    budget[0]-=1
    if budget[0]<0 or depth>16:return 'UNAVAILABLE_PREFIX_COPY_BOUND'
    kind=type(value)
    if value is None or kind in(bool,int,float):return value
    if kind is str:return value if len(value)<=2048 else value[:2048]+' [TRUNCATED]'
    if kind in(list,tuple):
        out=[]
        for i,x in enumerate(value):
            if i==128:out.append('TRUNCATED_AFTER_128_METADATA_ENTRIES');break
            out.append(_detached(x,budget,depth+1))
        return out
    if kind is dict:
        out={}
        for i,(key,x) in enumerate(value.items()):
            if i==128:out['__prefix_truncated__']=True;break
            if type(key)is not str:continue
            out[key[:2048]]=_detached(x,budget,depth+1)
        return out
    return 'UNAVAILABLE_NON_ORDINARY_METADATA'


def _failure_prefix(ctx,plan,error):
    """Passive attachment only: never resource/proof/complete-result authority."""
    prefix=dict(schema='direct-projection-nonauthoritative-failure-prefix-v1',
        authority=False,full_pipeline_qualified=False,mathematical_proof_accepted=False,
        complete_result=False,failed_prefix_accepted=False,primary_type=type(error).__name__,
        active_bank=plan.get('bank'),arm=plan.get('arm'),registered_costs_are_lower_bound=True,
        scope='Detached metadata only; no recovered output, decoding, continuation or logical admission.')
    if ctx is None:
        prefix.update(stage='context_construction_unavailable',completed_rows=[],
            retention_census=dict(root_registration_count=0,aggregate_container_count=None,
                aggregate_value_entries=None,root_registration_confirmed=False,
                availability='UNAVAILABLE_CONTEXT_CONSTRUCTION_FAILED'),
            registered_instances=[],operation_totals_lower_bound=dict(arena_work=0,adapter_operations=0),
            census_complete=False,unregistered_instance_cost='UNAVAILABLE_CONTEXT_CONSTRUCTION_FAILED')
        detached=_detached(prefix,[16384]);body=_canonical(detached)
        _need(len(body)<=196608,'bounded detached failure metadata')
        return detached
    prefix.update(stage=ctx.stage,active_fixture=ctx.active_fixture,active_operation=ctx.operation,
        active_input=ctx.active_input,completed_rows=ctx.rows,completed_output_descriptors=ctx.outputs,
        retention_census=ctx.retention_census(),
        active_output=dict(label=ctx.active_output,
            compared_BODY_bytes=None if ctx.active_cursor is None else ctx.active_cursor.oracle.compared,
            cursor_completed=False if ctx.active_cursor is None else ctx.active_cursor.completed,
            partial_file_authority='Root worker owns partial actual-safe-label.json custody; no complete descriptor or acceptance inferred.'),
        constructor_inflight=ctx.inflight,
        instance_census=dict(registered_Stores=len(ctx.stores),registered_separate_Arenas=len(ctx.direct)),
        Root_fault_latched=ctx.fault is not None)
    records=[];arena_work=0;adapter_work=0;unavailable=False
    for kind,objects in (('Store',ctx.stores),('direct_Arena',ctx.direct)):
        for ordinal,obj in enumerate(objects):
            old=ctx.last.get(('store' if kind=='Store' else 'arena',id(obj)),(0,0))
            aw,dw=old;record=dict(kind=kind,ordinal=ordinal,last_registered_lower_bound=dict(arena_work=aw,adapter_operations=dw))
            try:
                stats=obj.statistics()
                current_aw=(stats['arena'] if kind=='Store' else stats)['counters'].get('work',0)
                current_dw=stats['operations'] if kind=='Store' else 0
                _need(type(current_aw)is int and type(current_dw)is int and current_aw>=aw and current_dw>=dw,
                      'passive failure costs remain monotone')
                aw,dw=current_aw,current_dw;record.update(passive_statistics=stats,availability='PASSIVE_SNAPSHOT')
            except BaseException:
                unavailable=True;record['availability']='UNAVAILABLE_PASSIVE_STATISTICS_LAST_LOWER_BOUND_ONLY'
            record['cost_lower_bound']=dict(arena_work=aw,adapter_operations=dw)
            records.append(record);arena_work+=aw;adapter_work+=dw
    unregistered=ctx.inflight is not None and ctx.inflight.get('registered')is not True
    prefix.update(registered_instances=records,
        operation_totals_lower_bound=dict(arena_work=arena_work,adapter_operations=adapter_work),
        census_complete=not unregistered and not unavailable,
        unregistered_instance_cost='UNAVAILABLE_CONSTRUCTOR_OR_REGISTRATION_FAILED_BEFORE_CENSUS' if unregistered else None,
        cost_boundary='Registered passive work only; callback-interrupted constructor/registration may add unmeasured work. Original Root timing/highwater/output custody remains separate.')
    detached=_detached(prefix,[16384]);body=_canonical(detached)
    _need(len(body)<=196608,'bounded detached failure metadata')
    return detached


def run_subject(plan,harness_declaration,*,arena_module,adapter_module,check,source_guard,emit_canonical,retain):
    """Only a later granted Root worker may call this explicit subject function."""
    ctx=None
    try:
        ctx=_Context(plan,harness_declaration,arena_module,adapter_module,
                     check,source_guard,emit_canonical,retain)
        ctx.register_lifetime()
        return _subject(ctx)
    except BaseException as error:
        try:
            prefix=_failure_prefix(ctx,plan,error)
            setattr(error,'qualification_prefix',prefix)
        except BaseException:
            pass  # Collection/allocation/attachment can never replace primary.
        raise  # Exact original active object; no failed-prefix admission.
