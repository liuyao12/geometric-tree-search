DIRECT EVIDENCE CAPTURE — FINITE AND NEGATIVE OBSERVATIONS

Read root/ROOT-qualification-cohort-closure-v1.json first. V3: 8 planned, 3 launched, 2 generic passes, 1 deadline+cleanup failure, 5 NOT_RUN. No whole-bank candidate ran. Original exit/highwater are unavailable for the failed worker; a later OS absence receipt is not recovery. All V2/V3 execution grants are retired.

V2 negatives, Source corrections and unexecuted drafts are preserved. Inventory paths map original descriptors to archive entries. No theorem, GCTS/RL advantage, full-cold qualification or replay authorization is conferred. Original fixture inputs are complete; this archive does not redistribute the runtime or provide a portable trusted environment.
