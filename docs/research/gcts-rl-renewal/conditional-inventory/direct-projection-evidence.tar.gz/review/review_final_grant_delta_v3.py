"""Narrow ordinary saved-metadata review only. No subject functions/imports."""
from pathlib import Path
import hashlib,json,os
C=Path('/private/tmp/gcts-direct-projection-review-20261019')
D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
checks=[];pinned={}
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb')as f:
  while True:
   b=f.read(1048576)
   if not b:break
   h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def need(name,v):checks.append(dict(check=name,passed=bool(v)))
def pin(p):
 if p['path']not in pinned:
  actual=desc(p['path']);need('exact_raw_pin:'+p['path'],actual==p);pinned[p['path']]=actual
 else:need('consistent_descriptor:'+p['path'],pinned[p['path']]==p)
 return p
def read(p):return json.loads(Path(p).read_bytes())
def same(a,b):return canonical(a)==canonical(b)
def walkpins(o):
 if type(o)is dict:
  if set(o)=={'path','bytes','sha256'}:pin(o)
  else:
   for v in o.values():walkpins(v)
 elif type(o)is list:
  for v in o:walkpins(v)
def save(n,o):
 p=C/n
 with p.open('xb')as f:f.write((json.dumps(o,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
 return desc(p)
scopepin=pin(dict(path=str(D/'ROOT-scope-adoption-and-grants-v3.json'),bytes=7080,sha256='df7a75c90c7dca39b60c5516ed5e5ef42e0a009d051203de82dbb706ad03bc45'))
scope=read(scopepin['path'])
manifestpin=pin(dict(path=str(D/'prospective-metadata-manifest-v3.json'),bytes=42111,sha256='44ee0d54068b14973489209f8984933c2a4fd361f683a7e579d8333a54105dc4'))
m=read(manifestpin['path'])
expectedroles={
'Source':dict(path=str(C/'typed-components-Source-review-v3b.json'),bytes=15360,sha256='9026796a6f6ce1416da126f86a7bd030d8cc0096dd0f822922d34f5a27f54b2a'),
'outer_Source':dict(path=str(C/'typed-outer-Source-review-v3b.json'),bytes=12379,sha256='ef23cb5022efe6c823979e7fc3814da33bcb3efafd4257d511fdbad254f9ec73'),
'plans':dict(path=str(C/'typed-prospective-plan-review-v3b.json'),bytes=56302,sha256='3851f8cecdd7d62a6910cd35e706b1926ff5564d1c1bfd2226e382f0c61d9840')}
reviews={}
for role,p in expectedroles.items():pin(p);reviews[role]=read(p['path'])
for role,schema in [('Source','direct-projection-qualification-components-Source-review-v1'),('outer_Source','direct-projection-qualification-outer-Source-review-v1'),('plans','direct-projection-qualification-prospective-plan-review-v1')]:
 r=reviews[role];need('exact_current_role:'+role,r['schema']==schema and r['reviewer_identity']=='/root/conventional_control_review'and r['source_only']is True and type(r['scientific_calls'])is int and r['scientific_calls']==0 and r['scientific_acceptance']is False and r['actual_execution_authorized']is False and r['prospective_review_passed'if role=='plans'else'source_review_passed']is True)
need('Root_adoption_exact_scopes_and_manifest',scope['review_roles']==expectedroles and scope['prospective_manifest']==manifestpin and scope['author_identity']=='/root'and scope['actual_execution_authorized']is True and type(scope['launched_actuals'])is int and scope['launched_actuals']==0 and type(scope['actual_invocations_maximum'])is int and scope['actual_invocations_maximum']==8)
need('no_mathematical_or_production_authority',scope['mathematical_proof_accepted']is False and scope['full_pipeline_qualified']is False)
need('eight_ordered_issued_subjects',len(scope['issued'])==len(m['rows'])==len(reviews['plans']['subjects'])==8)
walkpins(m['declaration']);walkpins(m['runtime_closure']);closure=read(m['runtime_closure']['path']);walkpins(closure['python']);walkpins(closure['stdlib_files'])
need('current_decl_closure_unchanged',reviews['plans']['declaration']==m['declaration']and reviews['plans']['runtime_closure']==m['runtime_closure'])
rows=[];directories=[];subjectshas=[];authkeys={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'}
for i,(issued,oldrow,reviewrow)in enumerate(zip(scope['issued'],m['rows'],reviews['plans']['subjects'])):
 prefix=str(i)+':'+issued['bank']+':'+issued['arm']
 truepin=pin(issued['plan']);true=read(truepin['path']);falsepin=pin(oldrow['plan']);false=read(falsepin['path']);authpin=pin(issued['authorization']);auth=read(authpin['path']);falseauthpin=pin(false['authorization']);falseauth=read(falseauthpin['path'])
 subject={k:v for k,v in true.items()if k!='authorization'};sha=hashlib.sha256(canonical(subject)).hexdigest()
 need('authorization_descriptor_only_delta:'+prefix,set(true)==set(false)and [k for k in true if not same(true[k],false[k])]==['authorization']and true['authorization']==authpin and true['authorization']!=false['authorization'])
 need('full_thirteen_fields_unchanged:'+prefix,len(true)==14 and len(subject)==13 and same(subject,oldrow['subject'])and same(subject,reviewrow['subject'])and sha==issued['subject_sha256']==oldrow['subject_sha256']==reviewrow['subject_sha256'])
 need('bank_arm_schedule_unchanged:'+prefix,issued['bank']==oldrow['bank']==true['bank']and issued['arm']==oldrow['arm']==true['arm'])
 need('exact_seven_field_Root_true_maxone:'+prefix,set(auth)==authkeys and auth['schema']=='ROOT-direct-projection-qualification-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and auth['review_roles']==expectedroles)
 need('false_grant_preserved_and_unconsumed:'+prefix,set(falseauth)==authkeys and falseauth['actual_execution_authorized']is False and type(falseauth['maximum_actual_invocations'])is int and falseauth['maximum_actual_invocations']==1 and falseauth['review_roles']=={}and falseauth['subject_sha256']==sha)
 need('authorization_only_scope_and_roles_changed:'+prefix,all(same(auth[k],falseauth[k])for k in ['schema','author_identity','maximum_actual_invocations','subject_sha256'])and all(k in auth['scope']for k in ['Exactly one','No Native/Model/search/inverse/Reader/opaque decode','No proof/full production authority or prefix recovery']))
 need('all_six_current_Source_roles:'+prefix,set(true['sources'])=={'worker','harness','adapter','arena','runner','observer'}and true['sources']==closure['arms'][true['arm']])
 for role in ['worker','harness','adapter','arena']:need('components_role_contains:'+prefix+':'+role,true['sources'][role]in reviews['Source']['subjects'])
 for role in ['runner','observer']:need('outer_role_contains:'+prefix+':'+role,true['sources'][role]in reviews['outer_Source']['subjects'])
 need('Source_role_full_harness_decl:'+prefix,reviews['Source']['harness_declaration']in reviews['Source']['subjects'])
 walkpins(true['sources']);walkpins(true['inputs']);walkpins(true['python']);walkpins(true['declaration']);walkpins(true['runtime_closure'])
 for field in ['limits','arena_limits','adapter_limits','inputs','sources','python','declaration','runtime_closure']:
  need('unchanged_full_field:'+prefix+':'+field,same(true[field],false[field]))
 actual=Path(true['actual_directory']);observer=Path(truepin['path']).parent/(Path(truepin['path']).stem+'-terminal-observation');falseobs=Path(falsepin['path']).parent/(Path(falsepin['path']).stem+'-terminal-observation')
 fresh=[str(actual),str(observer),str(falseobs),str(actual/'CONSUMED.json'),str(observer/'CONSUMED.json'),str(falseobs/'CONSUMED.json')]
 need('fresh_actual_authorized_observer_markers:'+prefix,all(not os.path.lexists(p)for p in fresh))
 directories.extend([str(actual),str(observer)]);subjectshas.append(sha)
 rows.append(dict(arm=true['arm'],bank=true['bank'],subject=subject,subject_sha256=sha,false_plan=falsepin,false_authorization=falseauthpin,authorized_plan=truepin,authorization=authpin,fresh_absence_checked=fresh))
need('all_unique_maxone_subjects_and_paths',len(set(subjectshas))==8 and len(set(directories))==16)
failed=[v for v in checks if not v['passed']]
negative_history=pin(dict(path=str(C/'typed-saved-V2-common-defect-review-v1.json'),bytes=76428,sha256='0e609cce48a1edc41edc1d889c21c6a49cd3deed497da4ce67e304520b70513f'))
failed=[v for v in checks if not v['passed']]
receipt=dict(schema='direct-projection-qualification-final-grant-delta-review-v3',reviewer_identity='/root/conventional_control_review',author_identity='/root',saved_metadata_only=True,source_only=True,scientific_calls=0,component_calls=0,component_imports=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Reader_calls=0,Native_calls=0,opaque_decodes=0,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,actual_execution_authorized=False,final_grant_delta_review_passed=not failed,Root_scope_and_grants=scopepin,prospective_manifest=manifestpin,review_roles=expectedroles,same_reviewer_in_all_three_roles=True,preserved_V2_negative_review=negative_history,V3b_scope='One early Root lifetime aggregate retains every prior value entry and duplicate for same duration; registrations and76/526 generic,A7/B13 entries distinct. Current qualification unexecuted; retired V2 failures/nonruns never rescued.',rows=rows,raw_pins=list(pinned.values()),check_count=len(checks),mismatch_count=len(failed),checks=checks,findings=failed,limitations=['Narrow raw-hash/ordinary saved-metadata delta review only. The complete Source/prospective reviews remain separately pinned and conditional; no target functions were imported/evaluated.','The eight Root grants are true/maxone, while this reviewer receipt grants no actual authority. Root alone owns later serial execution and common-defect stop; no worker/Native/process launch occurred in this review.','All eight thirteen-field subjects, Source/input/profile/caps/declaration/runtime descriptors remain exact. Only the authorization descriptor changed. Absence is a point-in-time pathname/marker check, not an OS/security seal or continuous guarantee.','One disclosed reviewer fills all three scopes; historical C author overlap is inherited exactly as recorded. No independent three-reviewer claim, runtime qualification, proof/production authority or causal benefit follows.'],tools_stopped_after_handoff=True)
p=save('typed-final-grant-delta-review-v3.json',receipt)
print(json.dumps(dict(receipt=p,final_grant_delta_review_passed=not failed,check_count=len(checks),mismatch_count=len(failed),findings=failed),sort_keys=True))
