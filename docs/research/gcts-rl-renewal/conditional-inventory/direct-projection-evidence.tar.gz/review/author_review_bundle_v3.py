from pathlib import Path
C=Path('/private/tmp/gcts-direct-projection-review-20261019')
s=(C/'review_full_bundle_v2b.py').read_text()
replacements=[("B/'handoff-v2.json'),bytes=2793,sha256='3b7cff80c99b8ff0eaf1c04b4755a52f6fe169bc42fa5074447cc5ca9101bcb6'","B/'handoff-v3.json'),bytes=2995,sha256='e779f3992fb72d80bd594b1b065036dfb51c6eb8567fda277efe3ed2ac87729a'"),("D/'prospective-metadata-manifest-v2.json'),bytes=42111,sha256='c317945a94eca85c1e098f02497c53ccdba90b74bd6a1aeb84c01fc5384617a8'","D/'prospective-metadata-manifest-v3.json'),bytes=42111,sha256='44ee0d54068b14973489209f8984933c2a4fd361f683a7e579d8333a54105dc4'"),("h['harness']['sha256']=='6a0d1e36d1e0a3f2c917c8b3e0f19db65041b028984bfd1a3e9a73723c4ea691' and h['harness_declaration']['sha256']=='3fc79c8ae7f8fc0d1a77693bec6ec81120da4e62570983a93d579b97caa41635'","h['harness']['sha256']=='fe75a4f9aaae247f298317a05aaf468b135d54d198c65ca0c70411cd4691dd55' and h['harness_declaration']['sha256']=='af7bc254ecf071e9748af0ec38921ca77940589e4a06a68c2c0a570c49467024'"),("hd['schema']=='direct-projection-finite-harness-declaration-v2'","hd['schema']=='direct-projection-finite-harness-declaration-v3'")]
for a,b in replacements:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
for a,b in [('qualification-bundle-v2b-raw-audit.json','qualification-bundle-v3-raw-audit.json'),('typed-components-Source-review-v2b.json\',dict','typed-components-Source-review-v3.json\',dict'),('typed-outer-Source-review-v2b.json\',dict','typed-outer-Source-review-v3.json\',dict'),('typed-prospective-plan-review-v2b.json\',dict','typed-prospective-plan-review-v3.json\',dict'),('qualification-review-handoff-v2b.json','qualification-review-handoff-v3.json')]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
lines=s.splitlines()
lines=["negative=desc(C/'typed-harness-Source-review-v1b-negative.json')"if line.startswith('negative=save(')else line for line in lines]
s='\n'.join(lines)+'\n'
# The prior check correction is retained as historical provenance, not repeated as a subject finding.
s=s.replace("schema='direct-projection-qualification-review-handoff-v2b'","schema='direct-projection-qualification-review-handoff-v3'")
s=s.replace("source_review_passed=not bad,subjects=source_subjects,","source_review_passed=not bad,subjects=source_subjects,V3_delta_review=delta_review,")
s=s.replace("source_review_passed=not bad,subjects=[runner,observer],","source_review_passed=not bad,subjects=[runner,observer],V3_delta_review=delta_review,")
s=s.replace("prospective_review_passed=not bad,subjects=subjects,","prospective_review_passed=not bad,subjects=subjects,V3_delta_review=delta_review,")
s=s.replace("checks=checks,reviewer_check_correction=reviewer_correction,raw_pins=","checks=checks,V3_delta_review=delta_review,reviewer_check_correction=reviewer_correction,raw_pins=")
s=s.replace("current B harnessV2/workerV6","current B harnessV3/unchanged workerV6")
s=s.replace("eight current full literal13-field subjects", "eight fresh V3 full literal13-field subjects")
s=s.replace("Eight distinct actual/false-observer paths and markers were absent at this audit.","Eight distinct V3 actual/false-observer paths and markers were absent at this audit; retired V2 consumed generic subjects and six NOT_RUN histories remain pinned.")
anchor="subjects=[];actuals=[];obsdirs=[]"
assert s.count(anchor)==1
extra=(C/'review_bundle_v3_extra.txt').read_text()
s=s.replace(anchor,extra+'\n'+anchor)
# Include explicit variant scope in all three receipts.
anchor="components=save('typed-components-Source-review-v3.json'"
idx=s.index(anchor)
s=s[:idx]+"limits.extend(['V3 changes only the lifetime registration layout: Root receives one append-only aggregate before subject work, preserving every previous full value entry, including duplicate identities/order, for the same charged lifetime. Root retained_objects now counts registrations (one), not retained values or all reachable objects. Successful entry counts76/526 generic,7 each A and13 B are internal Source-enforced census; unchanged worker/outer do not independently reconstruct object identities or these counts.','V3 retains the previous23 cases/full3banks/all eight original input files and numeric caps. Old V2 candidate failure and six NOT_RUN remain; no runtime qualification, cap raise, fewer retained values, lifetime shortening or causal benefit is inherited. Check/guard call sites remain exact; infrastructure retain callback scheduling intentionally changes from one per value to one aggregate registration, so no blanket all-negative/callback-trace equivalence is claimed.'])\n"+s[idx:]
q=C/'review_full_bundle_v3.py'
assert not q.exists();q.write_text(s);compile(s,str(q),'exec');print(str(q))
