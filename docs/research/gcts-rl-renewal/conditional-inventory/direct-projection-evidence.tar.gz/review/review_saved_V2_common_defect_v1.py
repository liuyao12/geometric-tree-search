"""Independent saved JSON/rawhash audit. Never imports/evaluates subject Source."""
from pathlib import Path
import hashlib,json,os
C=Path('/private/tmp/gcts-direct-projection-review-20261019');D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
checks=[];pins={}
def word(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def read(p):return json.loads(Path(p).read_bytes())
def desc(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb')as f:
  while True:
   b=f.read(1048576)
   if not b:break
   h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def need(k,v):checks.append(dict(check=k,passed=bool(v)))
def pin(p):
 if p['path']not in pins:pins[p['path']]=desc(p['path']);need('raw_pin:'+p['path'],p==pins[p['path']])
 else:need('consistent_pin:'+p['path'],p==pins[p['path']])
 return p
def save(n,v):
 p=C/n
 with p.open('xb')as f:f.write((json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
 return desc(p)
closurepin=pin(dict(path=str(D/'ROOT-cohort-V2-common-defect-closure-v1.json'),bytes=14311,sha256='8834ce6cc72da710a7421e8b0df6d36804a0b6e6359f56fff93a9270c9bbe21c'))
cohort=read(closurepin['path']);grant_reviewpin=pin(dict(path=str(C/'typed-final-grant-delta-review-v2.json'),bytes=115414,sha256='008dadd3a682a7d9e73aedd4315b0559cabb6ad663ee5c627b516c1ffe7fb6f0'));grant_review=read(grant_reviewpin['path'])
source_reviewpin=pin(dict(path=str(C/'typed-components-Source-review-v2b.json'),bytes=9813,sha256='30e9f0f81f70fe267b7281bf6ad8b1278f4ed865c66a228a6e9fa12e10b3a04e'))
manifestpin=pin(grant_review['prospective_manifest']);manifest=read(manifestpin['path']);declpin=pin(manifest['declaration']);decl=read(declpin['path']);runtimepin=pin(manifest['runtime_closure']);runtime=read(runtimepin['path']);hdeclpin=pin(decl['harness_declaration']);hd=read(hdeclpin['path'])
for roles in runtime['arms'].values():
 for p in roles.values():pin(p)
for role,p in grant_review['review_roles'].items():pin(p)
need('eight_subject_denominator_and_protocol_stop',len(cohort['rows'])==8 and cohort['proposed_subjects']==8 and cohort['launched_subjects']==2 and cohort['not_run_subjects']==6 and cohort['current_V2_grants_retired_for_further_Root_use']is True)
need('Root_scope_keeps_current_candidate_unqualified',cohort['candidate_finite_qualified']is False and cohort['admitted_candidate_subjects']==0 and cohort['admitted_reference_helper_subjects']==1 and cohort['full_pipeline_qualified']is False and cohort['mathematical_proof_accepted']is False)
need('authoritative_cohort_closed_metadata',cohort['all_exec_handles_closed']is True and cohort['all_launched_actuals_closed']is True and cohort['all_launched_owned_groups_absent']is True)
worksource=Path(runtime['arms']['candidate']['worker']['path']).read_text();n='need(0<len(retained)<=512,\'retained originals/stores/capture roots through final checkpoint\')'
need('literal_worker512_gate_before_result_and_header',n in worksource and worksource.index(n)<worksource.index("phase='write_result'")<worksource.index("save_new(actual/'worker-receipt.json'"))
need('literal_harness_registration_layout',"def retain(self,value):self.root(self.retain_root,value)"in Path(runtime['arms']['candidate']['harness']['path']).read_text())
launched=[];unrun=[];observerpins=[]
for i,(cr,gr)in enumerate(zip(cohort['rows'],grant_review['rows'])):
 label=str(i)+':'+cr['bank']+':'+cr['arm'];planpin=pin(cr['plan']);p=read(planpin['path']);need('exact_pregranted_plan:'+label,planpin==gr['authorized_plan'])
 subject={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(word(subject)).hexdigest()
 need('same_full13subject:'+label,len(subject)==13 and word(subject)==word(gr['subject'])and sha==gr['subject_sha256'])
 authpin=pin(p['authorization']);auth=read(authpin['path']);need('Root_maxone_and_review_binding:'+label,auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and auth['review_roles']==grant_review['review_roles'])
 need('exact_profiles_currentSources:'+label,p['sources']==runtime['arms'][p['arm']]and p['limits']==decl['limits']and p['arena_limits']==decl['arena_limits']and p['adapter_limits']==decl['adapter_limits']and p['inputs']==hd['banks'][p['bank']]['inputs'])
 if not cr['launched']:
  observer=Path(planpin['path']).parent/(Path(planpin['path']).stem+'-terminal-observation');actual=Path(p['actual_directory'])
  need('NOT_RUN_no_actual_or_observer:'+label,cr['classification']=='NOT_RUN_COMMON_PROTOCOL_ABORT'and cr['gate_passed']is False and not os.path.lexists(actual)and not os.path.lexists(observer))
  unrun.append(dict(bank=p['bank'],arm=p['arm'],plan=planpin,actual_directory=str(actual),observer_directory=str(observer),classification=cr['classification']));continue
 for r in cr['receipts'].values():pin(r)
 terminalpin=pin(cr['terminal']);terminal=read(terminalpin['path']);runnerpin=cr['receipts']['runner-receipt.json'];runner=read(runnerpin['path']);consume=read(cr['receipts']['CONSUMED.json']['path']);actual=Path(p['actual_directory'])
 need('oneuse_consumption_plan_subject:'+label,consume['plan']==planpin and consume['subject_sha256']==sha and consume['invocation_id']==p['invocation_id']and consume['consumed_before_Popen']is True and consume['maximum_worker_launches']==1)
 need('runner_current_plan_authorization_limits:'+label,runner['plan']==planpin and runner['authorization']==authpin and runner['subject_sha256']==sha and runner['limits']==p['limits']and runner['worker_launch_attempts']==1)
 need('runner_worker_reaped_group_absent_regular_logs:'+label,runner['worker_reaped']is True and runner['owned_group_absent']is True and runner['regular_logs_closed']is True and runner['signals']==[]and runner['worker_wait4_status']==runner['worker_exit_code']*256)
 need('terminal_runner_exact_join:'+label,terminal['plan']==planpin and terminal['runner_receipt']==runnerpin and terminal['runner_exit_code']==cr['runner_exit_code']and runner['worker_exit_code']==cr['worker_exit_code'])
 need('runner_work210_and_terminal210_clocks:'+label,runner['work_deadline_ns']==runner['began_ns']+180000000000 and runner['overall_deadline_ns']==runner['began_ns']+210000000000 and runner['began_ns']<runner['worker_terminal_observed_ns']<=runner['closed_ns']<runner['overall_deadline_ns']and terminal['terminal_observed_ns']<runner['overall_deadline_ns'])
 elapsed=(terminal['terminal_observed_ns']-runner['began_ns'])/1e9;instrument=(terminal['terminal_observed_ns']-terminal['observer_started_ns'])/1e9
 need('exact_clock_reference:'+label,elapsed==terminal['runner_clock_elapsed_seconds']==cr['elapsed_seconds']and instrument==terminal['observed_instrument_elapsed_seconds'])
 peak=runner['worker_wait4_usage']['ru_maxrss'];need('worker_only_highwater_below1GiB:'+label,type(peak)is int and peak==cr['worker_peak_bytes']and 0<peak<1073741824)
 need('observer_default_authority_remains_false:'+label,terminal['ROOT_resource_accepted']is False and terminal['scientific_acceptance']is False and terminal['full_pipeline_qualified']is False and terminal['mathematical_proof_accepted']is False)
 for k in ['Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls']:need('runner_zero_proof_runtime:'+label+':'+k,type(runner[k])is int and runner[k]==0)
 obsdir=Path(terminalpin['path']).parent
 for f in sorted(obsdir.iterdir()):
  need('observer_regular_file:'+label+':'+f.name,f.is_file()and not f.is_symlink());observerpins.append(pin(desc(f)))
 need('observer_whole1MiB:'+label,sum(f.stat().st_size for f in obsdir.iterdir())<=1048576)
 need('raw_log_pins_and_4MiB:'+label,runner['stdout']==cr['receipts']['stdout.bin']and runner['stderr']==cr['receipts']['stderr.bin']and runner['stdout']['bytes']<=4194304 and runner['stderr']['bytes']<=4194304)
 positive=cr['arm']=='reference'
 if positive:
  resultpin=cr['receipts']['result.json'];result=read(resultpin['path']);headerpin=cr['receipts']['worker-receipt.json'];header=read(headerpin['path']);q=result['qualification']
  need('reference_normal_positive_gates:'+label,cr['gate_passed']is True and runner['worker_exit_code']==0 and terminal['runner_exit_code']==0 and runner['finite_helper_candidate']is True and runner['resource_candidate_accepted']is True and terminal['terminal_gate_passed']is True and runner['errors']==[])
  need('reference_fullresult_header_joins:'+label,runner['result']==header['result']==resultpin and runner['worker_receipt']==headerpin and result['plan']==header['plan']==planpin and result['outputs']==q['outputs']==header['outputs']==runner['outputs'])
  need('reference_positive_complete_and_exit_before180:'+label,header['positive_worker_completed_ns']<=runner['worker_terminal_observed_ns']<=runner['positive_result_read_completed_ns']<runner['work_deadline_ns']and header['began_ns']==runner['began_ns']and header['work_deadline_ns']==runner['work_deadline_ns'])
  need('reference_retained_registration76_under512:'+label,type(result['retained_objects'])is int and result['retained_objects']==76<=512)
  need('reference_physical_ledger_exact9MiB:'+label,runner['physical_before_runner_receipt']==sum(v['bytes']for k,v in cr['receipts'].items()if k!='runner-receipt.json')and runner['conservative_physical_bytes']==runner['physical_before_runner_receipt']+9437184<=134217728)
  outcome='REFERENCE_GENERIC_FINITE_GATES_PASSED_ONLY'
 else:
  failurepin=cr['receipts']['worker-failure.json'];result=read(failurepin['path']);q=result['returned_nonadmitted_packet']
  need('candidate_primary_worker512_failure:'+label,result['error_type']=='ValueError'and result['message']=='retained originals/stores/capture roots through final checkpoint'and result['retained_objects']==526>512 and result['root_fault_type']is None and result['phase']=='qualify')
  need('candidate_failure_not_harness_prefix:'+label,result['qualification_prefix']is None and result['status']=='FAILED_OR_UNFINISHED'and type(q)is dict)
  need('candidate_no_result_or_workerheader:'+label,not os.path.lexists(actual/'result.json')and not os.path.lexists(actual/'worker-receipt.json'))
  need('candidate_no_positive_gates:'+label,cr['gate_passed']is False and runner['worker_exit_code']==1 and terminal['runner_exit_code']==2 and runner['finite_helper_candidate']is False and runner['resource_candidate_accepted']is False and terminal['terminal_gate_passed']is False)
  stderr=Path(cr['receipts']['stderr.bin']['path']).read_text();need('stderr_exact_Source_failure_site:'+label,'line 272, in main'in stderr and n in stderr and stderr.endswith('ValueError: retained originals/stores/capture roots through final checkpoint\n'))
  need('candidate_returned_outputs_diag_only:'+label,result['outputs']==q['outputs']and 'result'not in runner and 'worker_receipt'not in runner)
  outcome='CANDIDATE_WORKER_BOOKKEEPING_BOUND_FAILURE_NO_QUALIFICATION'
 need('literal23ordered_rows_sixgroups:'+label,[[x['group'],x['fixture']]for x in q['rows']]==hd['generic_fixture_order']and len(q['rows'])==23 and len({x['group']for x in q['rows']})==6)
 need('exact_generic_registered_census:'+label,q['instance_census']['unique_Stores']==21 and q['instance_census']['unique_separate_direct_Arenas']==(0 if positive else 3)and q['instance_census']['unique_Arenas']==(21 if positive else 24))
 need('complete9output_descriptors_and_logicalbytes:'+label,len(q['outputs'])==9 and sum(o['bytes']for o in q['outputs'])==result['canonical_logical_bytes']==191698)
 for o in q['outputs']:
  pin(o);raw=Path(o['path']).read_bytes();need('output_complete_oneLF:'+label+':'+Path(o['path']).name,raw.endswith(b'\n')and not raw.endswith(b'\n\n'))
 need('registered_400m_op_totals_not_resource_authority:'+label,set(q['operation_totals'])=={'arena_work','adapter_operations'}and all(type(v)is int and 0<=v<=400000000 for v in q['operation_totals'].values())and q['resource_authority']is False)
 for k in ['authority','mathematical_authority','mathematical_proof_accepted','full_pipeline_qualified','production_full_cold_qualified']:need('qualification_no_authority:'+label+':'+k,q[k]is False)
 for k in ['Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls','scientific_calls']:need('q_zero_proof_runtime:'+label+':'+k,type(q[k])is int and q[k]==0)
 if positive:
  need('reference_exact3declaredNAs',[x['fixture']for x in q['rows']if x['result'].get('status')=='DECLARED_NOT_APPLICABLE_NO_NEW_API']==['projection_caps','unread_tail_mutation','arena_foreign_phases'])
 else:
  mutation=next(x['result']for x in q['rows']if x['fixture']=='unread_tail_mutation')['observations'];foreign=next(x['result']for x in q['rows']if x['fixture']=='arena_foreign_phases')['observations']
  need('candidate_retained_unread_tail_actual_secondread',len(mutation)==1 and mutation[0]['reached']is True and 0<mutation[0]['reached_counter_deltas']['projection_reconciliation_edges']<64 and mutation[0]['reached_counter_deltas']['projection_reconciliation_complete_reads']==0)
  need('candidate_retained18foreign_six_by3',len(foreign)==18 and [(x['phase'],x['foreign_type'])for x in foreign]==[(phase,typ)for phase in ['build','second-read','final-guard']for typ in ['ValueError','RuntimeError','StopIteration','GeneratorExit','SystemExit','ArenaLimit']])
  for z,x in enumerate(foreign):
   d=x['reached_counter_deltas'];need('candidate_diag_foreign_actualphase:'+str(z),x['reached']is True and x['no_returned_handle']is True and x['old_committed_observables_preserved']is True and (d['projection_reconciliation_begins']==0 if x['phase']=='build'else d['projection_reconciliation_edges']>0 and d['projection_reconciliation_complete_reads']==(0 if x['phase']=='second-read'else 1)))
 launched.append(dict(arm=p['arm'],bank=p['bank'],classification=outcome,plan=planpin,terminal=terminalpin,runner=runnerpin,worker_evidence=cr['receipts']['worker-receipt.json'if positive else'worker-failure.json'],elapsed_from_runner_Source_seconds=elapsed,elapsed_from_observer_seconds=instrument,worker_peak_bytes=peak,worker_peak_MiB=peak/1048576,worker_exit_code=runner['worker_exit_code'],runner_exit_code=terminal['runner_exit_code'],retained_registrations=result['retained_objects'],rows=23,outputs=9,canonical_bytes=191698,operation_totals=q['operation_totals'],component_calls=q['call_census']['component_calls'],observed_runner=runner,observed_terminal=terminal))
need('strict_serial_observation_before_second_start',launched[0]['observed_terminal']['terminal_observed_ns']<launched[1]['observed_terminal']['observer_started_ns'])
need('nine_generic_raw_outputs_pairwise_exact_pins',all((a['bytes'],a['sha256'])==(b['bytes'],b['sha256'])for a,b in zip(read(cohort['rows'][0]['receipts']['result.json']['path'])['outputs'],read(cohort['rows'][1]['receipts']['worker-failure.json']['path'])['outputs'])))
failed=[c for c in checks if not c['passed']]
receipt=dict(schema='direct-projection-qualification-V2-saved-negative-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',saved_data_only=True,saved_review_passed=not failed,scientific_calls=0,component_calls=0,component_imports=0,fixture_calls=0,codec_calls=0,Reader_calls=0,inverse_calls=0,Native_calls=0,opaque_decodes=0,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,candidate_finite_qualified=False,actual_execution_authorized=False,classification='CONSISTENT_SAVED_COMMON_PROTOCOL_DEFECT_NO_CANDIDATE_QUALIFICATION',Root_closure=closurepin,prior_Source_review=source_reviewpin,prior_final_delta_review=grant_reviewpin,harness_declaration=hdeclpin,launched=launched,not_run=unrun,raw_pins=list(pins.values()),check_count=len(checks),mismatch_count=len(failed),checks=checks,findings=failed,missed_coupling=dict(responsibility='Root introduced512 lifetime-registration bound; Control Source/prospective review missed complete candidate526 registration count. Prior Source PASS never asserted runtime success; this actual exposes that missing coupling.',worker_Source=runtime['arms']['candidate']['worker'],harness_Source=runtime['arms']['candidate']['harness'],literal_bound=512,observed_candidate_registration_count=526,location='qualify_projection_worker_v6.py:272',failure_before='result.json and worker-receipt.json',source_and_metadata_ready_status_superseded_for_further_V2_use=True),conclusions=['Reference generic only passed its finite helper lifecycle/resource/result gates. Saved observer ROOT_resource_accepted remains false; narrow Root cohort classification is separate. Candidate did not qualify.','Candidate retained returned packet reports all23 rows/nine complete generic outputs; raw bytes match reference for these nine outputs. These are diagnostic facts and cannot rescue missing final result/header, admit candidate, or establish a large-bank performance result.','Six complete-bank subjects were NOT_RUN_COMMON_PROTOCOL_ABORT with no actual/observer directories; not resource/search/Arena failures. All V2 Root grants are retired from further Root use by cohort policy, not technically edited/revoked flags.','The registration bound failure is distinct from Arena work/resource/algorithm failure. The elapsed/peak values are whole attempted helper diagnostics and are not a matched-performance baseline because candidate had extra API cases. No production, theorem, GCTS/RL or causal speed/RAM claim follows.'],limitations=['Saved raw bytes and ordinary JSON only, no imports/functions/replay/validator/math/inverse/Native execution. Full runtime object identities and exception identity are represented by Source-reviewed finite observation packets, not reconstructed by this review.','Reaping/group absence/regular logs closure and serial exec release are saved authoritative receipt joins; no fresh process-table probe or continuous OS absence claim. Original180 positive/fullreading/knownexit, later210 closure, worker-only1GiB, both128MiB and400m/400m profiles remain. Candidate has no positive resource admission despite its subcap diagnostic peak.','The current result does not provide large-bank completion or actual full-production fit; none of the six original complete-bank inputs was read by a granted bank subject. Existing historical failures/qualifications retain their status.'],successor_Source_obligations=['Use one Root-owned lifetime aggregate registered before values accrue; retain every existing original value/object/cursor/root/Store by strong reference for the same lifetime. No final-only registration, identity replacement, pruning or silent dedup.','Distinguish Root registration count from number of values retained, keep original512 worker guard and all data/cases/caps, preserve failed costs/lower-bound prefix and no admitted-result fallback.','Freeze fresh Source/declaration/eight subjects and prospective/final-delta reviews; original consumed failures cannot be retried or rescued.'],tools_stopped_after_handoff=True)
p=save('typed-saved-V2-common-defect-review-v1.json',receipt);print(json.dumps(dict(receipt=p,check_count=len(checks),mismatch_count=len(failed),saved_review_passed=not failed,findings=failed),sort_keys=True))
