"""Raw/AST/ordinary metadata review only. Target code is never imported/evaluated."""
from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-direct-projection-review-20261019')
D=Path('/private/tmp/gcts-direct-projection-ROOT-20261019')
B=Path('/private/tmp/gcts-direct-projection-qualification-20261019')
checks=[];pins={}
def word(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def desc(p):
 p=Path(p);h=hashlib.sha256();size=0
 with p.open('rb')as f:
  while True:
   s=f.read(1048576)
   if not s:break
   h.update(s);size+=len(s)
 return dict(path=str(p),bytes=size,sha256=h.hexdigest())
def need(n,v,d=None):checks.append(dict(check=n,passed=bool(v),detail=d))
def pin(d):
 if d['path']not in pins:
  a=desc(d['path']);need('raw_pin:'+d['path'],a==d);pins[d['path']]=a
 else:need('consistent_pin:'+d['path'],pins[d['path']]==d)
 return d
def pt(o):
 if type(o)is dict:
  if set(o)=={'path','bytes','sha256'}:pin(o)
  else:
   for v in o.values():pt(v)
 elif type(o)is list:
  for v in o:pt(v)
def j(p):return json.loads(Path(p).read_bytes())
def same(a,b):return word(a)==word(b)
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_bytes((json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode());return desc(p)
def defs(tree):return {n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
def rawseg(s,n):return ast.get_source_segment(s,n)
def dump(n):return ast.dump(n,include_attributes=False)
def literal(tree,name):
 n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets));v=n.value
 if isinstance(v,ast.Call)and isinstance(v.func,ast.Name):
  if v.func.id=='dict'and not v.args:return {k.arg:ast.literal_eval(k.value)for k in v.keywords}
  if v.func.id=='frozenset':return frozenset(ast.literal_eval(v.args[0]))
 return ast.literal_eval(v)

hp=pin(dict(path=str(B/'handoff-v2.json'),bytes=2793,sha256='3b7cff80c99b8ff0eaf1c04b4755a52f6fe169bc42fa5074447cc5ca9101bcb6'))
h=j(hp['path']);pt(h)
manifest=pin(dict(path=str(D/'prospective-metadata-manifest-v2.json'),bytes=42111,sha256='c317945a94eca85c1e098f02497c53ccdba90b74bd6a1aeb84c01fc5384617a8'))
m=j(manifest['path']);declpin=pin(m['declaration']);clpin=pin(m['runtime_closure']);decl=j(declpin['path']);cl=j(clpin['path']);hd=j(h['harness_declaration']['path']);entries=j(h['subject_entries']['path']);provenance=j(h['input_provenance']['path'])
need('B_packet_current_exact_harness_decl',h['harness']['sha256']=='6a0d1e36d1e0a3f2c917c8b3e0f19db65041b028984bfd1a3e9a73723c4ea691' and h['harness_declaration']['sha256']=='3fc79c8ae7f8fc0d1a77693bec6ec81120da4e62570983a93d579b97caa41635')
need('no_current_authority_in_metadata',m['actual_execution_authorized'] is False and m['actuals_launched']==m['scientific_calls']==0 and decl['actual_execution_authorized'] is False and decl['full_pipeline_qualified'] is False and cl['actual_execution_authorized'] is False and cl['scientific_acceptance'] is False and h['actual_execution_authorized'] is False)
need('exact_harness_decl_coupling',decl['harness_declaration']==h['harness_declaration'] and hd['harness']==h['harness'] and hd['schema']=='direct-projection-finite-harness-declaration-v2')
need('Root_declaration_closure_schemas_match_actual_intake',decl['schema']=='ROOT-direct-projection-qualification-declaration-v1' and cl['schema']=='ROOT-direct-projection-qualification-runtime-closure-v1' and cl['declaration']==declpin)
need('whole_eight_subject_schedule_exact',len(entries)==len(m['rows'])==8 and same(decl['subjects'],entries)and same(hd['subjects'],entries))
pt(hd['master']);pt(hd['input_provenance']);pin(cl['python']);pt(cl['stdlib_files'])
need('same_full_bank_descriptors_previous_provenance',hd['banks']['bank_A_fixed']['inputs'][0]['pin']==j(C/'preimage-provenance-review-v1.json')['bank_A']['original_declared_inputs'][0]['result'] and hd['banks']['bank_A_symbolic']['inputs'][0]['pin']==j(C/'preimage-provenance-review-v1.json')['bank_A']['original_declared_inputs'][1]['result'])
old6=j(C/'preimage-provenance-review-v1.json')['bank_B_full6'];labels=hd['banks']['bank_B_original006']['root_labels']
need('full_six_B_roots_sorted_exact_no_shortening',labels==sorted(old6) and hd['banks']['bank_B_original006']['inputs']==[dict(id=k,pin=old6[k])for k in labels] and old6['model']['bytes']==59695933)
need('no_failed_prefix_input_or_math_adoption',type(provenance['failed_V3_prefixes_used'])is int and provenance['failed_V3_prefixes_used']==0 and hd['authority'] is False and hd['mathematical_proof_accepted'] is False and hd['full_pipeline_qualified'] is False)
all_sources={}
for arm,ss in cl['arms'].items():
 need('each_selected_six_source_roles:'+arm,set(ss)=={'arena','adapter','harness','worker','runner','observer'})
 for role,p in ss.items():pin(p);all_sources[p['path']]=p
need('exact_eight_whole_runtime_sources',len(all_sources)==8 and set(cl['arms'])=={'reference','candidate'})
need('exact_current_worker_runner_observer',all(cl['arms'][arm]['worker']['sha256']=='52f23a9502038e90a8833e9b131cc1d48c3741ff9f7d423679efda79ed3d4645' and cl['arms'][arm]['runner']['sha256']=='91d8c4b263079d283c299b87c247e07ad082cf0b055b2dbe85e159c3e8854f46' and cl['arms'][arm]['observer']['sha256']=='83c44206d7aedb14479d7479df8f8b02ca6ab6ac817d47b06e4b4ddbd578b557'for arm in cl['arms']))
need('both_arm_components_exact_declared',all(cl['arms'][a]['arena']==hd['implementations'][a]['arena'] and cl['arms'][a]['adapter']==hd['implementations'][a]['adapter'] and cl['arms'][a]['harness']==h['harness']for a in cl['arms']))
texts={p:Path(p).read_text()for p in all_sources};trees={p:ast.parse(t)for p,t in texts.items()}
for p,t in texts.items():unused=compile(t,p,'exec');del unused
need('all_eight_unused_compile_no_eval',True)
worker=cl['arms']['candidate']['worker'];runner=cl['arms']['candidate']['runner'];observer=cl['arms']['candidate']['observer'];wt,rt=trees[worker['path']],trees[runner['path']]
for name in ('LIMITS','ARENA_LIMITS','ADAPTER_LIMITS'):
 v=literal(wt,name);need('literal_worker_outer_same:'+name,v==literal(rt,name));need('declarations_match_literal:'+name,v==decl[{'LIMITS':'limits','ARENA_LIMITS':'arena_limits','ADAPTER_LIMITS':'adapter_limits'}[name]]==hd[{'LIMITS':'limits_and_clock','ARENA_LIMITS':'arena_limits','ADAPTER_LIMITS':'adapter_limits'}[name]] if name!='LIMITS'else v==decl['limits'])
need('original_global_numbers',literal(wt,'LIMITS')==dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576))
need('shared_operation_ceilings400m',hd['operation_ceilings']==dict(arena_work=400000000,adapter_operations=400000000,inverse_work_unused=30000000))
W,R=texts[worker['path']],texts[runner['path']];wf,rf=defs(wt),defs(rt)
need('worker_outer_validation_raw_AST_exact',rawseg(W,wf['validate_qualification'])==rawseg(R,rf['validate_qualification'])and dump(wf['validate_qualification'])==dump(rf['validate_qualification']))
validation=rawseg(W,wf['validate_qualification'])
for key in ['qualification/emitter/header output join','all twenty-three exact ordered generic cases','exact reference-NA scope','all nine complete generic output bodies','one complete exact bank row and output','exact complete bank public-call census']:
 need('independent_complete_result_gate:'+key,key in validation)
need('source_worker_and_outer_schema_roles',all(s in R for s in ['direct-projection-qualification-components-Source-review-v1','direct-projection-qualification-outer-Source-review-v1','direct-projection-qualification-prospective-plan-review-v1']))
need('worker_first_Root_fault_and_primary_cleanup',"if root_fault is None:root_fault=error"in W and "try:cleanup_errors.append"in W and "except BaseException:pass"in W)
need('strict_lifecycle_fresh_consumption_before_Popen',R.index("actual.mkdir(mode=0o700)")<R.index("consumed=save_new(actual/'CONSUMED.json'")<R.index('process=subprocess.Popen('))
need('positive_full_outputs_knownexit180_later_custody210',all(s in R for s in ['complete positive result/header/bytes/known-exit before180','worker normal exit0','complete logical ledger','later custody/resource checks before210','owned group reappeared; no unverified signal']))
need('metadata_and_observer_reservations_original',all(s in texts[observer['path']]for s in ['all observer files/logs inside reserved1MiB','timeout=225','worker_terminal_observed_ns','POST_RECEIPT_DEADLINE_FAILURE']))

H=texts[h['harness']['path']];ht=trees[h['harness']['path']];hf=defs(ht);oldH=(B/'qualify_direct_projection_v1.py').read_text();oldhf=defs(ast.parse(oldH))
fixtures=literal(ht,'FIXTURES');need('literal_23_ordered_six_groups',len(fixtures)==23 and len({g for g,n in fixtures})==6 and [list(f)for f in fixtures]==hd['generic_fixture_order'])
for name in ['_canonical','_Oracle','VerifiedStream','_consume','_negative','_owned_store_error','_positive','_poison_rejects','_arena_bytes','_arena_baseline','_old_state_check','_caps_case','_callback_case','_generic']:
 need('retained_full_generic_logic_raw_AST:'+name,rawseg(H,hf[name])==rawseg(oldH,oldhf[name]) and dump(hf[name])==dump(oldhf[name]))
need('no_subject_eval_loader_or_proof_import_in_harness',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in {'eval','exec','compile','__import__'} for n in ast.walk(ht)))
handler=hf['run_subject'].body[-1].handlers[0]
need('prefix_wrapper_bare_primary_rethrow',isinstance(handler,ast.ExceptHandler) and isinstance(handler.type,ast.Name) and handler.type.id=='BaseException' and isinstance(handler.body[-1],ast.Raise) and handler.body[-1].exc is None and handler.body[-1].cause is None and all(s in rawseg(H,hf['run_subject'])for s in ["prefix=_failure_prefix(ctx,plan,error)","setattr(error,'qualification_prefix',prefix)","except BaseException:"]))
fp=rawseg(H,hf['_failure_prefix'])
need('prefix_collection_passive_no_quota_or_callbacks',all(s not in fp for s in ['ctx.totals(','ctx.check(','ctx.guard(','ctx.call(','emit_root','read_bytes(']))
need('prefix_detached_lowerbound_not_result',all(s in fp for s in ['registered_costs_are_lower_bound=True','census_complete=not unregistered and not unavailable','UNAVAILABLE_CONSTRUCTOR_OR_REGISTRATION_FAILED_BEFORE_CENSUS','complete_result=False','failed_prefix_accepted=False','196608']))
need('prefix_B_bound_below_worker_cap',hd['failure_prefix']['maximum_canonical_BODY_bytes']==196608<hd['failure_prefix']['worker_outer_cap_bytes']==262144)
phase=rawseg(H,hf['_projection_phase_case'])
need('during_actual_second_read_and_unread_tail_counters',all(s in phase for s in ["change('projection_reconciliation_edges')>0","0<change('projection_reconciliation_edges')<64","reached_counter_deltas=reached[0]"]))
need('six_foreign_objects_three_phases_no_ownclass_laundering',all(s in phase for s in ["('build','second-read','final-guard')","StopIteration('foreign')","GeneratorExit('foreign')","SystemExit('foreign')","ctx.arena.ArenaLimit('work')","not ctx.arena.is_own_limit(foreign)"]))
need('reconciliation_and_final_guard_distinct_sourcepredicates',all(s in phase for s in ["change('projection_reconciliation_complete_reads')==0","kind=='guard' and change('projection_reconciliation_complete_reads')>0","change('publication_bookkeeping')>0"]))
cc=next(n for n in ht.body if isinstance(n,ast.ClassDef)and n.name=='_Context');cm={n.name:n for n in cc.body if isinstance(n,ast.FunctionDef)}
need('Root_fault_first_before_expected_negative_hook',rawseg(H,cm['pulse']).index('self.root(')<rawseg(H,cm['pulse']).index('hook(kind)') and rawseg(H,hf['_negative']).index('ctx.no_fault(primary=error)')<rawseg(H,hf['_negative']).index('predicate(error)'))
need('all_unique_Store_and_separate_Arena_total_work',all(s in rawseg(H,cm['totals'])for s in ["for s in self.stores:","for a in self.direct:","key=('store',id(s))","key=('arena',id(a))","aw>=old[0]","dw>=old[1]","arena_work+=aw","adapter_work+=dw"]))
need('construction_gap_explicit_not_fake_fullcost',all(s in H for s in ["self.inflight=dict(kind='Store',registered=False)","self.inflight=dict(kind='direct_Arena',registered=False)","self.inflight['registered']=True"]))
store_by_case={'wide_array':1,'wide_object':1,'shared_subtree':1,'equal_distinct':1,'tuple_projection':1,'depth_limit':1,'chunk_unicode':1,'projection_caps':0,'mixed_roots':1,'repeated_ports':1,'cross_store':2,'check_early':1,'check_during':1,'guard_stopiteration':1,'stream_stopiteration':1,'reentrancy':1,'store_postcommit_guard':1,'unread_tail_mutation':0,'arena_foreign_phases':0,'scalar_domain':1,'list_subclass':1,'nonstring_key':1,'cycle':1}
ge=hd['finite_expected_census']['generic_each'];need('21_Stores_derivation_all23cases',set(store_by_case)=={n for g,n in fixtures} and sum(store_by_case.values())==ge['fresh_Stores']==21)
need('candidate_only_three_local_APIfixtures_predeclared',ge['reference_predeclared_new_API_NA_cases']==['projection_caps','unread_tail_mutation','arena_foreign_phases'] and ge['reference_separate_direct_Arenas']==0 and ge['candidate_separate_direct_Arenas']==3 and ge['exact_foreign_phase_subcases']==18 and 'candidate_new_API_subcases'not in ge)
need('bank_full_byte_oracle_not_hash_only',all(s in H for s in ['chunk[at:at+n]==part[self.offset:self.offset+n]','self.compared==self.total','self.stream.completed is not True','cursor.completed is True','digest.update(b\'\\n\')']))
need('bank_A_oneLF_and_B_allsix_complete_source_layout',all(s in H for s in ["len(loaded)==1 and loaded[0][0].endswith(b'\\n')","segments=[memoryview(raw)[:-1]]","len(loaded)==len(labels)==6","[entry['id'] for entry in plan['inputs']]==labels","segments.extend([_canonical(label),b':',raw])"]))

subjects=[];actuals=[];obsdirs=[]
planfields=literal(wt,'PLAN_FIELDS');roles=literal(wt,'SOURCE_ROLES')
need('actual_plan14_and_subject13_schema',len(planfields)==14 and roles=={'worker','harness','adapter','arena','runner','observer'})
for i,(row,e)in enumerate(zip(m['rows'],entries)):
 pp=pin(row['plan']);p=j(pp['path']);sub={k:v for k,v in p.items()if k!='authorization'};sha=hashlib.sha256(word(sub)).hexdigest();authpin=pin(p['authorization']);auth=j(authpin['path'])
 need('exact_complete13_subject:'+str(i),set(p)==planfields and len(sub)==13 and same(sub,row['subject']) and sha==row['subject_sha256'])
 need('exact_predeclared_bank_arm_inputs:'+str(i),same(dict(arm=p['arm'],bank=p['bank'],inputs=p['inputs']),e) and row['arm']==p['arm'] and row['bank']==p['bank'])
 need('Root_decl_closure_full_descriptors:'+str(i),p['declaration']==declpin and p['runtime_closure']==clpin and cl['declaration']==declpin and p['sources']==cl['arms'][p['arm']] and p['python']==cl['python'])
 need('all_original_literal_profiles:'+str(i),p['limits']==literal(wt,'LIMITS') and p['arena_limits']==literal(wt,'ARENA_LIMITS') and p['adapter_limits']==literal(wt,'ADAPTER_LIMITS'))
 need('false_dormant_maxone_grant_not_authority:'+str(i),set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review_roles','scope'} and auth['author_identity']=='/root'and auth['actual_execution_authorized'] is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==sha and auth['review_roles']=={})
 for item in p['inputs']:
  pin(item['pin']);need('full_input_pin_from_exact_selected_bank:'+str(i)+':'+item['id'],item in hd['banks'][p['bank']]['inputs'])
 need('complete_input_order_and_no_generic_substitution:'+str(i),p['inputs']==hd['banks'][p['bank']]['inputs'])
 a=Path(p['actual_directory']);o=Path(pp['path']).parent/(Path(pp['path']).stem+'-terminal-observation')
 need('fresh_current_actual_observer_and_markers:'+str(i),not a.exists() and not o.exists() and not(a/'CONSUMED.json').exists()and not(o/'CONSUMED.json').exists())
 actuals.append(str(a));obsdirs.append(str(o));subjects.append(dict(subject=sub,subject_sha256=sha,plan=pp,authorization=authpin,invocation_id=p['invocation_id']))
need('eight_unique_fresh_subjects_and_directories',len(set(actuals))==len(set(obsdirs))==len({r['subject_sha256']for r in subjects})==8)
for item in cl['direct_import_census']:
 p=item['source']['path'];t=trees[p];roots=set()
 for n in ast.walk(t):
  if isinstance(n,ast.Import):roots.update(a.name.split('.')[0]for a in n.names)
  elif isinstance(n,ast.ImportFrom):roots.add(n.module.split('.')[0]if n.module else '')
 need('full_literal_import_census:'+p,sorted(roots)==item['direct_imports'])
need('no_proof_runtime_claim_in_closure',all(cl[k]==0 for k in ('Native_calls','Model_calls','Reader_calls','inverse_calls','search_calls','opaque_program_decodes','scientific_calls')))

reviewer_correction=dict(schema='direct-projection-reviewer-check-correction-v1',prior_audit=desc(C/'qualification-bundle-v2-raw-audit.json'),prior_components=desc(C/'typed-components-Source-review-v2.json'),prior_outer=desc(C/'typed-outer-Source-review-v2.json'),prior_prospective=desc(C/'typed-prospective-plan-review-v2.json'),prior_handoff=desc(C/'qualification-review-handoff-v2.json'),reason=['The provenance uses exact integer0 for failed_V3_prefixes_used, not booleanFalse. The corrected check requires exact int0.','ast.get_source_segment ends at the final bare raise token, excluding its trailing comment. The corrected check inspects ast.Raise with no exception/cause and the guarded attachment body.'],subject_Source_changes=False,subject_execution=False)
bad=[v for v in checks if not v['passed']]
negative=save('typed-harness-Source-review-v1b-negative.json',dict(schema='direct-projection-qualification-Source-review-v1-negative',reviewer_identity='/root/conventional_control_review',author_identity='/root/benchmark_design',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,source_review_passed=False,source=desc(B/'qualify_direct_projection_v1.py'),declaration=desc(B/'harness-declaration-v1.json'),superseded_by=h['harness'],findings=['V1 lacked an escaping-error qualification_prefix, so completed rows/active operation/work lower bounds were unavailable to Root worker on real bank failure. V2 adds passive bounded detached prefix and exact bare rethrow with constructor accounting limits.','V1 candidate_new_API_subcases18 actually described eighteen foreign-phase injections, not all new-API calls. V2 renames exact_foreign_phase_subcases18.','V1 second-read predicate could trigger at begins marker before actual edge read. V2 requires positive edge delta and retains reached counters. Root V6/outerV4 independently validate all complete rows/output/census rather than status only.'],runtime_observations=False))
audit=save('qualification-bundle-v2b-raw-audit.json',dict(schema='direct-projection-qualification-whole-bundle-raw-audit-v2',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,unused_compile_count=8,check_count=len(checks),mismatch_count=len(bad),checks=checks,reviewer_check_correction=reviewer_correction,raw_pins=list(pins.values()),subjects=subjects,store_census_derivation=store_by_case))
common=dict(reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,Reader_calls=0,inverse_calls=0,Native_calls=0,opaque_decodes=0,mathematical_proof_admitted=False,full_pipeline_qualified=False,audit=audit,check_count=len(checks),mismatch_count=len(bad),findings=bad,reviewer_check_correction=reviewer_correction)
source_subjects=[]
for role in ('arena','adapter','harness','worker'):
 for arm in ('reference','candidate'):
  p=cl['arms'][arm][role]
  if p not in source_subjects:source_subjects.append(p)
source_subjects.append(h['harness_declaration'])
limits=['Source-only independent raw/AST and unused compile review, no target/helper/fixture/function import or evaluation. Complete saved input bytes were raw-hashed; no Native/program/Reader/inverse/Model/search was called or opaque data decoded.',
 'Pinned Python/stdlib conversion, raw exec loader plus postload callable/code/global/default identities, later full raw custody and exclusive-owner/OS assumptions remain conditional. No formal continuous seal or hostile-runtime security guarantee.',
 'Operation totals cover unique registered instances; constructor-before-registration cost is unavailable on failure and prefix totals are lower bounds. Prefix collection is best effort, bounded detached metadata and may be unavailable; never complete output, accepted forest, recovered proof or continuation.',
 'Full bank inputs are strict stdlib JSON carriers; tuple behavior is finite generic coverage, not reconstruction of prior Python tuple/object identity. Candidate extras are prospectively N/A in reference, so generic runtimes are not a matched performance baseline. Source proof of unchanged legacy bodies is not new old-fixture runtime qualification.',
 'Foreign errors at build/actual unfinished second-read/final guard have meaningful prospective predicates, repeated root checks and counter evidence; finite tests are unexecuted. Genuine Root fault dominance and worker cleanup are Source-reviewed, not separately experimentally demonstrated by this review.',
 'Control authored historical symbolic/AND-helper/outer ancestors and earlier metadata reviews, including a preserved missed descriptor binding. Current Arena/adapter/harness/worker are separately authored; retained lifecycle ancestry is not fresh independent certification of Control own algorithms.',
 'Original180 positive/fullreading/knownexit, later210, worker-only helper1GiB (Native absent), physical+logical128MiB/log4MiB/9MiB reserve and invocation total400m each remain. No fit or causal speed/RAM, theorem, production, GCTS/RL/learning advantage follows.']
components=save('typed-components-Source-review-v2b.json',dict(common,schema='direct-projection-qualification-components-Source-review-v1',author_identity='/root',author_identities=['/root','/root/conventional_library','/root/benchmark_design'],source_review_passed=not bad,subjects=source_subjects,harness_handoff=hp,harness_declaration=h['harness_declaration'],input_provenance=h['input_provenance'],prior_Arena_scoped_review=desc(C/'typed-Arena-Source-review-v1.json'),prior_adapter_scoped_review=desc(C/'adapter-Source-interim-review-v1.json'),preserved_V1_negative=negative,
 conclusions=['Exact both-arm Arena+adapter and current B harnessV2/workerV6 reviewed. Scoped Arena135-check proof and adapter66-check reversible Source ancestry remain exact. New capture preserves strict legacy API, direct typed projection/full second occurrence read, per-call BODY cap before sole commit and exact foreign propagation; no new mathematical authority.',
 'Full immutable byte-oracle comparisons consume complete expected original BODY segments and every output occurrence, then Root sink adds exactlyone LF. All originals, parsed values, Stores/roots/sealed wire/cursors remain retained through final positive boundary. Complete bankB includes all six whole fields/59.7MB Model and all labels, not a projection/sample.',
 'All23 exact generic cases/six groups inspected:21 Stores, candidate3 separate direct Arenas, reference0; eighteen six-class/three-phase foreign injections and one provably unread-tail mutation have actual counter predicates. Strict domains, tuple/list projections, per-call/global/work negative classifications, repeated/root/cross-owner/seal/stream completion and Store postcommit poison are covered finitely as declared. New quota diagnostic uses legacy strict capture for the inherited work-limit classifier; no claim it exercises every new-API stop site.',
 'Whole invocation work sums every registered unique Store-private Arena and separate direct Arena plus adapter operations monotonically. Expected negative attempts remain in registered stats, no per-instance budget reset; range gates independent in worker/outer. New actual-operation profile remains distinct from old JSON normalization.',
 'V2 passive failure carrier retains detached bounded completed-row/active operation/output progress, registered stats/lower bounds and constructor-unavailable flags without quota/check/stream calls; collection/attachment error cannot replace exact primary. Root emitter corrected active-close/diagnostic handling and first-fault latch remain intact.'],limitations=limits,tools_stopped_after_handoff=True))
outer=save('typed-outer-Source-review-v2b.json',dict(common,schema='direct-projection-qualification-outer-Source-review-v1',author_identity='/root',source_review_passed=not bad,subjects=[runner,observer],worker_context=worker,harness_declaration=h['harness_declaration'],conclusions=['Exact current runnerV4/observerV1 read in full with retained worker coupling. Fourteen-field once plan/thirteen-field canonical subject and whole pins/declaration/closure/three exact review scopes/maxone Root grant precede exclusive marker and one worker launch. No Source-only receipt grants execution.',
 'Worker/outer raw-identical complete validator joins q/emitter/header outputs, exact ordered23/six groups and three referenceNAs, nine generic outputs and reference-owned descriptor joins,21+0/3 instance census, and one complete bank row/output plus exact4/10 public API starts. Strict zero proof/search runtime flags and registered totals each<=400m are independent gates.',
 'Known exit0/full result+header+all emitted file bytes must fit180; subsequent raw input/Source/Python custody/resource/group/log closure and external terminal210. Regular-log closure, wait4 reaping, permanent group-reappearance veto/no late signals, physical all-file+9MiB and worker-only highwater remain explicit. Observer225 is failure fallback only and all observer files fit1MiB. Literal observer ROOT_resource_accepted stays false; Root narrow adoption later is separate.'],limitations=limits,tools_stopped_after_handoff=True))
prospective=save('typed-prospective-plan-review-v2b.json',dict(common,schema='direct-projection-qualification-prospective-plan-review-v1',author_identity='/root',prospective_review_passed=not bad,subjects=subjects,declaration=declpin,runtime_closure=clpin,harness_declaration=h['harness_declaration'],subject_entries=h['subject_entries'],manifest=manifest,current_components_Source=components,current_outer_Source=outer,conclusions=['All eight current full literal13-field subjects and canonical hashes match exact14-field false plans and selected Source/input/limit/declaration/closure bindings. Schedule is generic reference/candidate then three complete banks reference/candidate, as predeclared. Eight distinct actual/false-observer paths and markers were absent at this audit.',
 'False Root authorization has actual_execution_authorized:false, empty review roles and a dormant maximum1, not max0; the true gate remains unlaunchable because boolean false. No grant or activation was created by this review. Fresh later true plans must preserve complete subjects and change only authorization descriptor under Root adoption plus final-delta/freshness review.',
 'Exact complete Bank A two originals and Bank B six private canonical preimages hash-match retained provenance and earlier finite representation authority, including fixed historical full-production failure. No protected parent raw results hydrated, failed V3 prefixes used, smaller Model/library/candidate set, proofroute or numericcap change. Source/master/old failure exposures stay explicit.',
 'Reference failures and all eight outcomes must be retained. Missing reference completion cannot establish complete paired equality or causal performance; candidate helper admission would still require its full independent bytes/all declared gates and separate saved-data review. Root controls serial launches/common-defect stop and actual ownership; all Source, plan and publication statuses remain distinct.'],limitations=limits,tools_stopped_after_handoff=True))
handoff=save('qualification-review-handoff-v2b.json',dict(schema='direct-projection-qualification-review-handoff-v2b',components=components,outer=outer,prospective=prospective,audit=audit,preserved_negative=negative,check_count=len(checks),mismatch_count=len(bad),scientific_calls=0,actual_execution_authorized=False,tools_stopped_after_handoff=True))
print(json.dumps(dict(components=components,outer=outer,prospective=prospective,audit=audit,handoff=handoff,check_count=len(checks),mismatch_count=len(bad),failures=bad),sort_keys=True))
