"""Parse/unused compile/inert text only; target Sources are never imported."""
from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-direct-projection-review-20261019')
old=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py')
new=Path('/private/tmp/gcts-direct-projection-ROOT-20261019/owned_evidence_adapter_v4.py')
contract=Path('/private/tmp/gcts-direct-projection-ROOT-20261019/adapter-Source-contract-v1.json')
checks=[]
def desc(p):
 b=Path(p).read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(n,v):checks.append(dict(check=n,passed=bool(v)))
def dump(n):return ast.dump(n,include_attributes=False)
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n');return desc(p)
a,b=old.read_text(),new.read_text();x,y=ast.parse(a),ast.parse(b)
need('parent_exactpin',desc(old)==dict(path=str(old),bytes=14997,sha256='91fb57f8a3fdd4563cb74f641b630bd725b813bd305608463920dd191f0216a8'))
need('new_exactpin',desc(new)==dict(path=str(new),bytes=15796,sha256='9323bb2caf7eeb3907ff7079bb417e4764d5ad4813b669b08b23648209e3c769'))
need('contract_exactpin',desc(contract)==dict(path=str(contract),bytes=2831,sha256='678880da77ec55196dabf3db8ec85d58953605236e897ea741e911635e531efe'))
def methods(m):
 cls=next(n for n in m.body if isinstance(n,ast.ClassDef)and n.name=='Store')
 return {n.name:n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
om,nm=methods(x),methods(y)
changed={k for k in om if dump(om[k])!=dump(nm[k])}
need('same_Store_method_set',set(om)==set(nm))
need('only_constructor_and_capture_AST_changes',changed=={'__init__','_capture'})
for k in om:
 if k not in changed:
  need('retained_Store_method_AST:'+k,dump(om[k])==dump(nm[k]))
  need('retained_Store_method_raw:'+k,ast.get_source_segment(a,om[k])==ast.get_source_segment(b,nm[k]))
for node in x.body:
 if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name!='Store':
  twin=next(t for t in y.body if type(t)is type(node)and t.name==node.name)
  need('retained_other_definition_raw_AST:'+node.name,dump(node)==dump(twin)and ast.get_source_segment(a,node)==ast.get_source_segment(b,twin))
# Reversible whole-file text proof, not running either resulting program.
oldhead="VERSION = 'owned-evidence-adapter-v1'"
newhead="VERSION = 'owned-evidence-adapter-v2-direct-tuple-projection'\nIMPLEMENTATION_VERSION = 'owned-evidence-adapter-v4-direct-tuple-projection'\nEXECUTION_PROFILE = 'owned-evidence-direct-projection-actual-operations-v1'\nPROJECTION_POLICY = 'STRICT_BUILTINS_TUPLE_TO_ARRAY_V1'"
oldtitle='Explicit owned evidence references over the unchanged qualified arena.'
newtitle='Explicit owned evidence references with evidence-only direct tuple projection.'
forward=a.replace(oldtitle,newtitle).replace(oldhead,newhead)
reverse=b.replace(newtitle,oldtitle).replace(newhead,oldhead)
for k in changed:
 os,ns=ast.get_source_segment(a,om[k]),ast.get_source_segment(b,nm[k])
 need('unique_inert_method_anchor:'+k,forward.count(os)==1 and reverse.count(ns)==1)
 forward=forward.replace(os,ns);reverse=reverse.replace(ns,os)
need('inert_forward_fullraw_exact',forward==b)
need('inert_reverse_fullraw_exact',reverse==a)
for p,s in ((old,a),(new,b)):
 unused=compile(s,str(p),'exec');del unused
need('both_unused_compiles_completed_without_eval',True)
init=ast.get_source_segment(b,nm['__init__']);capture=ast.get_source_segment(b,nm['_capture'])
need('exact_new_Arena_ABI_markers',all(v in init for v in ['exact-evidence-arena-v4-direct-tuple-projection','invocation-total-direct-tuple-projection-v1','PROJECTION_POLICY']))
need('direct_call_original_value_exact_label_percallcap','capture_legacy_json(value,label=label,value_bytes=self._limits[\'value_bytes\'])' in capture)
need('domain_reference_scan_before_direct_capture',capture.index('_contains_reference(value)')<capture.index('capture_legacy_json('))
need('no_fallback_normalize_or_error_relabel',all(v not in capture for v in ['json.loads','self._canonical','except ','raise EvidenceLimit']))
need('direct_request_and_completed_count_charged',capture.index("self._step('direct_projection_requests')")<capture.index('capture_legacy_json(')<capture.index("self._step('completed_captures')"))
need('Reference_return_only_after_last_finish',capture.index('self._finish();return Reference')>capture.index("self._step('completed_captures')"))
bad=[c for c in checks if not c['passed']]
audit=save('adapter-Source-interim-audit-v1.json',dict(schema='direct-projection-adapter-interim-raw-AST-audit-v1',source_only=True,scientific_calls=0,source_calls=0,fixture_calls=0,component_imports=0,unused_compile_count=2,inert_text_directions=2,checks=checks,check_count=len(checks),mismatch_count=len(bad),parent=desc(old),source=desc(new),contract=desc(contract)))
review=save('adapter-Source-interim-review-v1.json',dict(schema='direct-projection-adapter-interim-Source-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root',source_only=True,scientific_calls=0,component_calls=0,fixture_calls=0,component_imports=0,scientific_acceptance=False,actual_execution_authorized=False,adapter_static_delta_consistent=not bad,complete_components_Source_review_passed=False,qualification_passed=False,status='EXACT_ADAPTER_DELTA_REVIEWED_ARENA_AND_HARNESS_DEPENDENCIES_PENDING',source=desc(new),parent=desc(old),contract=desc(contract),audit=audit,check_count=len(checks),mismatch_count=len(bad),findings=bad,observations=['Full old adapter Source is restored by inert inverse text changes. Only Store constructor/_capture method ASTs and explicit module doc/version/profile markers differ; all other methods/classes/helpers raw-exact. Existing strict domain/reference/depth scan, canonical equality writer, callback gate, error poisoning and mixed assembly behavior remain.','New constructor binds exact proposed Arena implementation/profile/policy markers. Capture passes the original value and exact adapter value_bytes directly, charges the new request and retains old completed count/final checks/Reference return order. No catch, legacy fallback or own-Arena-limit relabel is introduced.','Removing JSON parse/duplicate normalization changes actual operations and fault opportunities. Selected new profile declares that change; no old-normalization work trace or finite exception-case qualification is inherited.'],required_scope_clarifications=['Invalid ordinary data may now fail with a different internal backend exception class/precedence, for example old JSON/UTF-8 normalization versus Arena syntax rejection. Exact foreign callbacks must preserve identity; claim fail-closed input domain rather than universal own-negative exception equivalence.','All-fallible-before-publication is the Arena root transaction guarantee, not multi-layer adapter atomicity: unchanged adapter completed_captures/_finish can fail after Arena root publication. Store then poisons, exposing only diagnostic orphan roots and no usable Reference/forest.','New Arena exact Source/markers, full second-read/body cap behavior, harness/root real-fault-latch, all execution dependencies and complete input banks must be reviewed before a final combined Source PASS. This interim note is not a runnable qualification receipt.'],ancestry='Control authored historical symbolic/AND-helper/outer ancestors and reviewed this adapter ancestor; Root authored both adapter versions, Library authors Arena. This is new Root delta review conditional on Library implementation, not independent certification of Control own algorithms.',tools_stopped_pending_next_frozen_packet=True))
print(json.dumps(dict(review=review,audit=audit,checks=len(checks),mismatch_count=len(bad),failures=bad),sort_keys=True))
