"""Independent raw/AST/unused-compile/inert text review. No target eval/import."""
from pathlib import Path
import ast,hashlib,json
C=Path('/private/tmp/gcts-direct-projection-review-20261019')
L=Path('/private/tmp/gcts-direct-projection-library-20261019')
old=Path('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py');new=L/'exact_evidence_arena_v4.py'
checks=[];pins=[]
def desc(p):
 b=Path(p).read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(n,v):checks.append(dict(check=n,passed=bool(v)))
def pin(d):
 q={k:d[k] for k in ('path','sha256','bytes')};a=desc(q['path']);need('raw_pin:'+q['path'],a==q);pins.append(a);return a
def dump(n):return ast.dump(n,include_attributes=False)
def save(n,o):
 p=C/n
 if p.exists():raise FileExistsError(p)
 p.write_text(json.dumps(o,sort_keys=True,ensure_ascii=False,allow_nan=False,indent=2)+'\n');return desc(p)
hp=pin(dict(path=str(L/'handoff-v1.json'),bytes=3128,sha256='3b7139802ea35bf715a5a36738c2882ecbdeb8c89815474eb57e0db89d8d8e9b'))
h=json.loads(Path(hp['path']).read_bytes())
for k in ('Source','parent','API','Source_contract','Source_delta','execution_profile','current_master'):pin(h[k])
a,b=old.read_text(),new.read_text();x,y=ast.parse(a),ast.parse(b)
need('new_and_parent_exact_source',desc(new)==h['Source'] and desc(old)==h['parent'])
oc=next(n for n in x.body if isinstance(n,ast.ClassDef)and n.name=='Arena');nc=next(n for n in y.body if isinstance(n,ast.ClassDef)and n.name=='Arena')
om={n.name:n for n in oc.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};nm={n.name:n for n in nc.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
added={'_capture_legacy_value','_reconcile_legacy_text','_reconcile_legacy_keys','_reconcile_legacy_value','capture_legacy_json'}
need('exact_five_new_Arena_methods',set(nm)-set(om)==added and not(set(om)-set(nm)))
for name,node in om.items():
 need('old_method_AST_exact:'+name,dump(node)==dump(nm[name]))
 need('old_method_raw_exact:'+name,ast.get_source_segment(a,node)==ast.get_source_segment(b,nm[name]))
for node in x.body:
 if isinstance(node,(ast.ClassDef,ast.FunctionDef))and node.name!='Arena':
  other=next(n for n in y.body if type(n)is type(node)and n.name==node.name)
  need('other_old_definition_raw_AST_exact:'+node.name,dump(node)==dump(other)and ast.get_source_segment(a,node)==ast.get_source_segment(b,other))
oldmarkers="IMPLEMENTATION_VERSION='exact-evidence-arena-v3-direct-reconciliation-parent-guards'\nEXECUTION_PROFILE='invocation-total-direct-reconciliation-parent-guards-v3'"
newmarkers="IMPLEMENTATION_VERSION='exact-evidence-arena-v4-direct-tuple-projection'\nEXECUTION_PROFILE='invocation-total-direct-tuple-projection-v1'\nPROJECTION_POLICY='STRICT_BUILTINS_TUPLE_TO_ARRAY_V1'"
parent_with_markers=a.replace(oldmarkers,newmarkers)
need('parent_header_anchor_unique',a.count(oldmarkers)==b.count(newmarkers)==1)
need('full_old_source_is_exact_changed_marker_prefix',b.startswith(parent_with_markers))
suffix=b[len(parent_with_markers):]
need('only_added_class_methods_after_prefix',suffix.startswith('\n    def _capture_legacy_value(')and len(ast.parse('class Arena:\n'+suffix).body[0].body)==5)
need('inert_forward_whole_file_exact',parent_with_markers+suffix==b)
need('inert_reverse_whole_file_exact',b[:-len(suffix)].replace(newmarkers,oldmarkers)==a)
for p,s in ((old,a),(new,b)):
 unused=compile(s,str(p),'exec');del unused
need('two_unused_compiles_without_evaluation',True)
segments={k:ast.get_source_segment(b,nm[k]) for k in added}
for n in ('_reconcile_legacy_text','_reconcile_legacy_keys','_reconcile_legacy_value'):
 candidate=segments[n].replace('_reconcile_legacy','_reconcile').replace('projection_reconciliation','reconciliation')
 if n=='_reconcile_legacy_value':candidate=candidate.replace("tag=='array' and kind not in (list,tuple)","tag=='array' and kind is not list")
 need('second_read_exact_old_algorithm_after_declared_mapping:'+n,candidate==ast.get_source_segment(a,om[n.replace('_legacy','')]))
builder=segments['_capture_legacy_value']
projected=builder.replace('_capture_legacy_value','_capture_value').replace('projection_capture_frames','capture_frames')
newdomain="if kind not in (list,tuple,dict):raise ArenaDataError('strict legacy JSON projection only; handles are not values')\n                if kind in (list,tuple):\n                    self._step('projection_array_classifications')\n                    if kind is tuple:self._observe('projection_tuple_occurrences',1)"
olddomain="if kind not in (list,dict):raise ArenaDataError('ordinary builtin JSON only; handles are not values')"
need('one_declared_first_builder_tuple_change',projected.count(newdomain)==1)
projected=projected.replace(newdomain,olddomain)
need('first_builder_exact_old_algorithm_after_declared_mapping',projected==ast.get_source_segment(a,om['_capture_value']))
entry=segments['capture_legacy_json'];reconcile=segments['_reconcile_legacy_value']
need('entry_exact_signature',dump(nm['capture_legacy_json'].args)==dump(ast.parse('def capture_legacy_json(self,value,*,label,value_bytes):pass').body[0].args))
need('strict_percall_cap_type_and_min_global',"type(value_bytes) is not int or value_bytes<=0" in entry and "body_cap=min(self._limits['root_expanded_bytes'],value_bytes)" in entry)
need('percall_owned_summary_cap_before_secondread_commit',entry.index('i=self._capture_legacy_value(value,t)')<entry.index("if t.summaries[i][0]>body_cap:self._stop('projection_value_bytes')")<entry.index('self._reconcile_legacy_value(value,t,i)')<entry.index('self._commit_root(t,i,label)'))
need('one_local_transaction_and_initial_guard','self._finish();t=_Transaction(self);self._label(label,t)'in entry and entry.count('_Transaction(self)')==1)
need('no_new_limit_mutation_or_reset',all('self._limits[' not in ast.get_source_segment(b,n) for n in ast.walk(nm['capture_legacy_json']) if isinstance(n,(ast.Assign,ast.AugAssign))and any(isinstance(t,ast.Subscript)for t in (n.targets if isinstance(n,ast.Assign)else[n.target]))))
need('one_finally_busy_release_no_catch',len([n for n in ast.walk(nm['capture_legacy_json'])if isinstance(n,ast.Try)])==1 and not any(isinstance(n,ast.ExceptHandler)for n in ast.walk(nm['capture_legacy_json']))and 'finally:self._busy=False'in entry)
need('new_functions_not_generators',not any(isinstance(n,(ast.Yield,ast.YieldFrom))for name in added for n in ast.walk(nm[name])))
need('no_new_module_imports',dump(ast.Module(body=[n for n in x.body if isinstance(n,(ast.Import,ast.ImportFrom))],type_ignores=[]))==dump(ast.Module(body=[n for n in y.body if isinstance(n,(ast.Import,ast.ImportFrom))],type_ignores=[])))
need('no_whole_JSON_normalization_in_new_methods',all(s not in '\n'.join(segments.values())for s in ('json.loads','JSONEncoder','iterencode','bytearray(')))
need('second_read_never_reinterns_or_builds_summaries',all(s not in reconcile for s in ('self._intern(','self._summary(','self._cache(','hash(')))
need('second_read_all_edges_before_complete_marker',reconcile.index("self._step('projection_reconciliation_edges')")<reconcile.index("self._step('projection_reconciliation_complete_reads')") and "frames.append(dict(value=child,index=expected,phase=0,depth=f['depth']+1))"in reconcile)
need('list_tuple_same_projection_declared',"kind not in (list,tuple)"in reconcile and "n=('array',tuple(f['refs']))"in builder)
api=json.loads((L/'API-v1.json').read_bytes());profile=json.loads((L/'execution-profile-v1.json').read_bytes());contract=json.loads((L/'Source-contract-v1.json').read_bytes())
need('metadata_has_no_grant_or_qualification',all(o['scientific_calls']==0 and o['actual_execution_authorized'] is False and o['production_pipeline_qualified'] is False for o in (h,api,profile)))
need('body_framing_and_allocation_scope_explicit','excluding external LF'in profile['logical_size'] and 'not a preallocation/RAM bound'in api['cap'])
need('tuple_projection_and_transaction_failure_scope_explicit','projection-equal'in api['equality'] and 'NOT universal Arena abort/poison'in api['failure'])
need('new_operation_no_old_trace_equivalence','not a retroactive pass'in profile['no_quota_equivalence_claim'] and 'no elapsed-latency/preemption/identicalordinal claim'in profile['checkpoint'])
bad=[c for c in checks if not c['passed']]
audit=save('Arena-Source-raw-AST-audit-v1.json',dict(schema='direct-projection-Arena-raw-AST-audit-v1',source_only=True,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,unused_compile_count=2,inert_text_directions=2,checks=checks,check_count=len(checks),mismatch_count=len(bad),raw_pins=pins,new_methods=sorted(added),legacy_method_count=len(om)))
review=save('typed-Arena-Source-review-v1.json',dict(schema='direct-projection-Arena-typed-Source-review-v1',reviewer_identity='/root/conventional_control_review',author_identity='/root/conventional_library',source_only=True,source_review_passed=not bad,partial_bundle_review=True,complete_components_Source_review_passed=False,scientific_calls=0,component_imports=0,component_calls=0,fixture_calls=0,codec_calls=0,inverse_calls=0,Native_calls=0,opaque_decodes=0,scientific_acceptance=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,actual_execution_authorized=False,subjects=[h['Source']],handoff=hp,API=h['API'],Source_contract=h['Source_contract'],execution_profile=h['execution_profile'],parent=h['parent'],current_master=h['current_master'],design_obligations=desc(C/'direct-projection-design-obligations-v1.json'),adapter_interim_review=desc(C/'adapter-Source-interim-review-v1.json'),audit=audit,check_count=len(checks),mismatch_count=len(bad),findings=bad,
 conclusions=['The complete old Arena Source remains an exact prefix after only implementation/profile marker substitution. All legacy methods/classes/helpers retain exact raw/AST bodies, including strict capture tuple rejection, quotas, custom non-generator stream completion, sourceguard/lifecycle and one-publication transaction rules. Exactly five new class methods are appended.',
 'New builder is the old occurrence builder with explicit list/tuple array classification and new counted/observational taxonomy. New text/key/full second-read bodies are exact old direct reconciliation after declared counter/name mapping and array tuple acceptance. Full scalar typed lexemes, sorted exact-string keys, strict parent paths/cycles/depth/occurrences, collision-safe interning, expanded summaries and bounded fragment machinery are inherited, without a second owned tree or equality-by-hash shortcut.',
 'capture_legacy_json requires a strict positive exact-int BODY cap, takes the minimum with global root cap, builds one provisional transaction, checks its owned expanded-root summary before the full second read, and returns through unchanged sole-commit path. It does not mutate/reset limits or catch/remap foreign callbacks. Initial/final forced guards are inherited; no new generator frame wraps StopIteration.',
 'The contract correctly separates tuple/list projection equality from Python object/type identity, global versus per-call own quota reasons, old committed Arena state from upper poisoned Store, and per-value BODY bytes from external LF/document/physical ledgers. Small value caps are not a preallocation/RAM guarantee.',
 'New actual-operation profile and counter mapping are explicit. Removing whole normalization encoding/parsing is not qualification under the old JSON-normalization trace, old callback ordinals or old finite fixtures. Existing bounded fragment creation may still serialize/copy small subtrees or an entire small root; the removed work is the separate full-value normalization carrier, not all serialization/caching.',
 'Conditional structural correspondence is credible: exact scalar lexical meanings plus ordered recursive arrays/list/tuple and sorted exact-string object recursion preserve canonical JSON projection; full second read rechecks every projected occurrence under exclusive ownership. This is a Source/reasoning argument, not a mechanized theorem or executed universal equivalence test.' ],
 qualification_obligations=['Bank A complete two original result preimages and Bank B all six complete006 field preimages, their representation-only acceptance/source framing and complete bytes remain mandatory. No failed current V3 prefix, smaller Model, route or warm shared state may replace them.',
 'Finite cases must cover repeated tuple/list occurrences and projection-equal container-kind substitutions, typed bool/int/float/signed-zero leaves, Unicode/escaping/string-key order, cycles/subclasses, depth/scalar/chunk/cache endpoints and per-call BODY versus global cap reason/limit immutability. Include null/true/false/empty containers and exact escaped/non-ASCII byte endpoints.',
 'Inject exact foreign errors at actual build/unfinished second-read/final guard opportunities with real Root fault latch first. Prove chosen mutation tail was unread; no universal temporal seal claim. Preserve private owned quota versus same-class foreign, attempted-work nonrollback, old-state/no-newhandle Arena failure, Store poison and manual completed flags.',
 'Full frozen Arena+adapter+harness+worker/outer/dependency closure and full prospective subjects/grants need separate combined reviews. This scoped module receipt cannot satisfy the final components role by itself; no runtime/production/proof/resource qualification is granted.' ],
 limits_and_ancestry=['No subject module/function/helper/fixture, Reader/codec/inverse/Native/Model/search or opaque data was evaluated/imported/replayed. Only raw bytes, AST, unused compile and reversible text mappings were used. Pinned Python/stdlib scalar conversions, loader/source-custody and exclusive owner/OS assumptions remain conditional, not a hostile-runtime seal.',
 'Control authored inherited symbolic/AND-helper/outer ancestors but did not author this Arena or its Library parent. Retained old finite results and Source ancestry are reused only for unchanged bodies; they do not qualify these appended methods. Parent negative actuals and earlier errors remain immutable.',
 'Unchanged numeric400m Arena/400m adapter and global180/210/1GiB/physical+logical128MiB/log caps are necessary gates, not guarantees the new operation profile or future integrated run fits. No causal speed/RAM or GCTS/RL/scientific advantage is established.' ],tools_stopped_pending_frozen_qualifier=True))
print(json.dumps(dict(review=review,audit=audit,checks=len(checks),mismatch_count=len(bad),failures=bad),sort_keys=True))
