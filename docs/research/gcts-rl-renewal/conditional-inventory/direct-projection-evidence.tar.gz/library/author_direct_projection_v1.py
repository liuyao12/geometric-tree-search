"""Source-only authoring: raw/AST/ordinary metadata, unused compile, no subjects.

The new Arena module is written but never imported, evaluated or called here.
Legacy strict methods remain byte-for-byte unchanged. No fixtures are run.
"""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

LIB=Path('/private/tmp/gcts-direct-projection-library-20261019')
PARENT=Path('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py')
OUTPUT=LIB/'exact_evidence_arena_v4.py'
PUBLISHER=Path('/private/tmp/gcts-split-controls-publish-20261015')
IMPLEMENTATION='exact-evidence-arena-v4-direct-tuple-projection'
PROFILE='invocation-total-direct-tuple-projection-v1'
POLICY='STRICT_BUILTINS_TUPLE_TO_ARRAY_V1'
CHECKS=[]


def need(ok,name):
    if not ok:raise ValueError('Source metadata refused: '+name)
    CHECKS.append(dict(name=name,passed=True))


def pin(path,raw=None):
    path=Path(path).resolve()
    if raw is None:raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def save(name,value):
    path=LIB/name
    raw=json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n'
    with path.open('xb')as stream:stream.write(raw)
    return pin(path,raw)


def exact(text,old,new,count=1):
    need(text.count(old)==count,'exact raw replacement '+old[:90])
    return text.replace(old,new)


def dump(node):return ast.dump(node,include_attributes=False)


def main():
    need(pin(PARENT)['sha256']=='fd3f1e1372c59365cc43c06dd8c815bdaca8cab6a2e4fa292d23a901d7f146f8'
         and pin(PARENT)['bytes']==38300,'whole immutable strict ArenaV3 parent')
    # Read the normative document from the isolated publisher Git object only.
    master=subprocess.run(['/usr/bin/git','-C',str(PUBLISHER),'show','HEAD:docs/basic-tiling-algorithm.md'],
                          check=True,capture_output=True).stdout
    head=subprocess.run(['/usr/bin/git','-C',str(PUBLISHER),'rev-parse','HEAD'],
                        check=True,capture_output=True).stdout.decode().strip()
    need(hashlib.sha256(master).hexdigest()=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
         and len(master)==36240,'current fully read publisher master rawpin')
    with (LIB/'basic-tiling-algorithm-current.md').open('xb')as stream:stream.write(master)
    old=PARENT.read_text();ot=ast.parse(old)
    arena=next(n for n in ot.body if isinstance(n,ast.ClassDef)and n.name=='Arena')
    methods={n.name:n for n in arena.body if isinstance(n,ast.FunctionDef)}
    lines=old.splitlines(True)
    def source(name):
        node=methods[name]
        return ''.join(lines[node.lineno-1:node.end_lineno])
    first=source('_capture_value')
    first=exact(first,'def _capture_value(self,value,t):','def _capture_legacy_value(self,value,t):')
    first=exact(first,"self._step('capture_frames')","self._step('projection_capture_frames')")
    first=exact(first,"if kind not in (list,dict):raise ArenaDataError('ordinary builtin JSON only; handles are not values')",
        "if kind not in (list,tuple,dict):raise ArenaDataError('strict legacy JSON projection only; handles are not values')\n                if kind in (list,tuple):\n                    self._step('projection_array_classifications')\n                    if kind is tuple:self._observe('projection_tuple_occurrences',1)")
    text=source('_reconcile_text')
    text=exact(text,'def _reconcile_text(self,value,expected):','def _reconcile_legacy_text(self,value,expected):')
    text=text.replace("'reconciliation_","'projection_reconciliation_")
    keys=source('_reconcile_keys')
    keys=exact(keys,'def _reconcile_keys(self,value,pairs):','def _reconcile_legacy_keys(self,value,pairs):')
    keys=keys.replace("'reconciliation_","'projection_reconciliation_")
    keys=exact(keys,'self._reconcile_text(key,expected)','self._reconcile_legacy_text(key,expected)')
    second=source('_reconcile_value')
    second=exact(second,'def _reconcile_value(self,value,t,index):','def _reconcile_legacy_value(self,value,t,index):')
    second=second.replace("'reconciliation_","'projection_reconciliation_")
    second=exact(second,'self._reconcile_text(v,n[1])','self._reconcile_legacy_text(v,n[1])')
    second=exact(second,"(tag=='array' and kind is not list)","(tag=='array' and kind not in (list,tuple))")
    second=exact(second,'self._reconcile_keys(v,n[1])','self._reconcile_legacy_keys(v,n[1])',count=2)
    public='''    def capture_legacy_json(self,value,*,label,value_bytes):
        """Explicit evidence projection, canonical JSON BODY bytes only.

        Exact tuples and lists both project to arrays. This does not compare
        Python list/tuple identity or prove mathematical validity. No complete
        JSON serialization or parsed-object normalization carrier is built.
        """
        self._start_write()
        try:
            if type(value_bytes) is not int or value_bytes<=0:
                raise ArenaDataError('strict positive exact-int projection BODY cap')
            body_cap=min(self._limits['root_expanded_bytes'],value_bytes)
            self._finish();t=_Transaction(self);self._label(label,t)
            self._step('projection_capture_calls')
            i=self._capture_legacy_value(value,t)
            self._step('projection_value_byte_checks')
            if t.summaries[i][0]>body_cap:self._stop('projection_value_bytes')
            # Every projected occurrence is read again before sole publication.
            self._reconcile_legacy_value(value,t,i)
            return self._commit_root(t,i,label)
        finally:self._busy=False
'''
    additions='\n'+first+'\n'+text+'\n'+keys+'\n'+second+'\n'+public
    new=exact(old,"IMPLEMENTATION_VERSION='exact-evidence-arena-v3-direct-reconciliation-parent-guards'",
              "IMPLEMENTATION_VERSION='"+IMPLEMENTATION+"'")
    new=exact(new,"EXECUTION_PROFILE='invocation-total-direct-reconciliation-parent-guards-v3'",
              "EXECUTION_PROFILE='"+PROFILE+"'\nPROJECTION_POLICY='"+POLICY+"'")
    new+=additions
    nt=ast.parse(new);compile(nt,str(OUTPUT),'exec')  # unused code object only
    need(not OUTPUT.exists(),'new immutable Arena Source path')
    with OUTPUT.open('xb')as stream:stream.write(new.encode())
    na=next(n for n in nt.body if isinstance(n,ast.ClassDef)and n.name=='Arena')
    nm={n.name:n for n in na.body if isinstance(n,ast.FunctionDef)}
    nlines=new.splitlines(True)
    for name,node in methods.items():
        need(dump(node)==dump(nm[name]) and source(name)==''.join(nlines[nm[name].lineno-1:nm[name].end_lineno]),
             'legacy entire Arena method raw/AST exact '+name)
    for node in ot.body:
        if isinstance(node,ast.ClassDef)and node.name!='Arena':
            other=next(n for n in nt.body if isinstance(n,ast.ClassDef)and n.name==node.name)
            need(dump(node)==dump(other),'legacy complete nonArena class AST exact '+node.name)
    need(dump(methods['capture'])==dump(nm['capture']),'strict public capture unchanged domain/body')
    need(set(nm)-set(methods)=={'_capture_legacy_value','_reconcile_legacy_text',
         '_reconcile_legacy_keys','_reconcile_legacy_value','capture_legacy_json'},'only five explicit new Arena methods')
    need([dump(n)for n in ot.body if isinstance(n,(ast.Import,ast.ImportFrom))]==
         [dump(n)for n in nt.body if isinstance(n,(ast.Import,ast.ImportFrom))],
         'imports unchanged json/math only; no components')
    need('json.loads'not in additions and 'JSONEncoder'not in additions and 'bytearray'not in additions,
         'no whole JSON bytes or parsed normalization intermediary')
    appended_ast=ast.parse('class Inert:\n'+additions)
    need(not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await))
                 for n in ast.walk(appended_ast)),
         'new capture/reconciliation use no generator callback wrapper')
    old_handlers=[dump(n)for n in ast.walk(methods['_reconcile_value'])if isinstance(n,ast.ExceptHandler)]
    new_handlers=[dump(n)for n in ast.walk(appended_ast)if isinstance(n,ast.ExceptHandler)]
    need(new_handlers==old_handlers and len(new_handlers)==1,
         'only inherited integer str conversion ValueError handler; no foreign callback catch')
    old_tries=[n for n in ast.walk(methods['_reconcile_value'])if isinstance(n,ast.Try)and n.handlers]
    new_tries=[n for n in ast.walk(appended_ast)if isinstance(n,ast.Try)and n.handlers]
    need([dump(n)for n in new_tries]==[dump(n)for n in old_tries] and len(new_tries)==1,
         'entire inherited local integer conversion try AST exact; no delegated callback in it')
    # The only differences from the prior full strict second read are names,
    # disclosed counter categories, and array-domain projection of tuples.
    normalized_second=second.replace('def _reconcile_legacy_value','def _reconcile_value')
    normalized_second=normalized_second.replace("'projection_reconciliation_","'reconciliation_")
    normalized_second=normalized_second.replace('self._reconcile_legacy_text','self._reconcile_text')
    normalized_second=normalized_second.replace('self._reconcile_legacy_keys','self._reconcile_keys')
    normalized_second=normalized_second.replace("(tag=='array' and kind not in (list,tuple))","(tag=='array' and kind is not list)")
    need(normalized_second==source('_reconcile_value'),'entire strict secondread recovers raw parent by declared projection inverses')
    restored=new[:-len(additions)]
    restored=restored.replace("IMPLEMENTATION_VERSION='"+IMPLEMENTATION+"'","IMPLEMENTATION_VERSION='exact-evidence-arena-v3-direct-reconciliation-parent-guards'")
    restored=restored.replace("EXECUTION_PROFILE='"+PROFILE+"'\nPROJECTION_POLICY='"+POLICY+"'","EXECUTION_PROFILE='invocation-total-direct-reconciliation-parent-guards-v3'")
    need(restored==old,'entire whole Source raw inverse parent recovered')
    for direction,before,after in [('forward',old,new),('inverse',new,old)]:
        patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
            fromfile='a/arena.py',tofile='b/arena.py'))
        with (LIB/('arena-'+direction+'.patch')).open('xb')as stream:stream.write(patch.encode())
    common=dict(author_identity='/root/conventional_library',cohort_owner_identity='/root',
        source_only=True,scientific_calls=0,component_imports=0,component_calls=0,
        fixture_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
        mathematical_authority=False,production_pipeline_qualified=False)
    current_master=dict(path=str(LIB/'basic-tiling-algorithm-current.md'),bytes=len(master),sha256=hashlib.sha256(master).hexdigest(),
        isolated_publisher=str(PUBLISHER),publisher_commit=head,git_object='HEAD:docs/basic-tiling-algorithm.md')
    operation_profile=save('execution-profile-v1.json',dict(schema='direct-tuple-projection-capture-profile-v1',**common,
        Source=pin(OUTPUT),VERSION='exact-evidence-arena-v1',WIRE_SCHEMA='exact-evidence-forest-v1',
        IMPLEMENTATION_VERSION=IMPLEMENTATION,EXECUTION_PROFILE=PROFILE,PROJECTION_POLICY=POLICY,
        explicit_entry='Arena.capture_legacy_json(value,*,label,value_bytes)',
        new_charged_categories=['projection_capture_calls','projection_capture_frames',
            'projection_array_classifications','projection_value_byte_checks','projection_reconciliation_*'],
        observational_counter='projection_tuple_occurrences counts tuplearray occurrences via _observe, not an extra workunit; arrayclassification is charged for everylist/tuple occurrence.',
        reused_operation_categories='Exact prior scalar validation/conversion, size/depth bounds, collisionbucket/fullnodeequality, summaries/fragments, transactionbookkeeping and commit costs retain their actual meanings.',
        removed_pipeline_operations='New entry does not perform Adapter legacy whole JSONEncoder serialization, whole json.loads normalization or duplicate whole normalizationencoding. Legacy strict API has no new behavior.',
        no_quota_equivalence_claim='Numeric limits are supplied unchanged, shared monotonically with legacyoperations. This NEW actual-operation profile is not a retroactive pass under old adapter JSON-normalization-work accounting or its fault-site/ordinal fixtures.',
        checkpoint='Reuses exact Arena._step weighted max1024 operations between delegated check dispatches, plus initial capture _finish and sole _commit_root final _finish. Changed operations mean changed callback traces; no elapsed-latency/preemption/identicalordinal claim.',
        logical_size='value_bytes is canonical JSON BODY bytes only, excluding external LF. Seal/output/physical ledgers remain separate; document logical bytes include1LF as before.'))
    api=save('API-v1.json',dict(schema='direct-tuple-projection-Arena-API-v1',**common,
        Source=pin(OUTPUT),entry='Arena.capture_legacy_json(value,*,label,value_bytes)->RootHandle',
        unchanged_ctor='Arena(*,source_epoch,semantic_epoch,check,source_guard,limits)',
        unchanged_wire_VERSION='exact-evidence-arena-v1',IMPLEMENTATION_VERSION=IMPLEMENTATION,
        EXECUTION_PROFILE=PROFILE,PROJECTION_POLICY=POLICY,execution_profile=operation_profile,
        domain='Exact builtin None,bool,int,finitefloat,Unicode-scalarstr,list,tuple,dict with exact scalarstr keys. No subclasses/References/handles/custom objects; lists and tuples project to JSON arrays. Dict keys sorted by existing Unicode ordering.',
        equality='Canonical JSON projection only: bool/int/float/-0.0 remain distinct; missing/keyset/order/multiplicity remain exact. Equal list/tuple substitutions are projection-equal, not a promised Python type/identity mutation refusal.',
        cap='Strict positive exact-int value_bytes, effective min(global root_expanded_bytes,value_bytes). Firstpass globalnode/edge/scalar/depth/root caps remain. Owned summary BODY cap checked before fullsecondread and publication. A small bodycap is not a preallocation/RAM bound.',
        errors=dict(invalid_cap='ArenaDataError',cap_exceeded="own ArenaLimit reason='projection_value_bytes'",existing_global_caps='unchanged own ArenaLimit classification',foreign='Exact delegated exception object rethrows without catch/normalization, including ValueError/RuntimeError/StopIteration/GeneratorExit/SystemExit.'),
        ownership='Invocation-local exclusive carrier ownership, read-only callbacks except passive statistics. All repeated occurrences traversed twice; no calleridentity/hash shortcut. RootHandle returned only after sole publication. No caller mutation by capture.',
        failure='Failed transaction leaves old committed Arena state and historical handles under legacy lifecycle, with monotone attemptedwork and no newhandle. This is NOT universal Arena abort/poison. Root-owned Store must preserve its failclosed poison/no completebundle/output policy.',
        legacy='Arena.capture(value,*,label) remains raw/AST exact, accepts strict ordinary JSONlists/dicts only and still rejects tuples; every oldmethod unchanged.',
        adapter_integration='Root explicitly checks new implementation/profile/policy and callable; retain _contains_reference domain/depth and guard gates, then call arena.capture_legacy_json(value,label=label,value_bytes=adapter_value_bytes). Keep legacy _canonical/equality APIs. No productionintegration included here.'))
    delta=save('Source-delta-v1.json',dict(schema='direct-tuple-projection-Source-delta-v1',**common,
        parent=pin(PARENT),successor=pin(OUTPUT),new_methods=[n for n in nm if n not in methods],
        new_method_lines={name:dict(start=nm[name].lineno,end=nm[name].end_lineno)for name in nm if name not in methods},
        retained_old_methods=list(methods),forward=pin(LIB/'arena-forward.patch'),inverse=pin(LIB/'arena-inverse.patch'),
        changes='Only implementation/profile metadata+explicitprojectionpolicy and appended5newArena methods. Newbuilder/secondread derived raw from legacy methods with exact typedtuplearray projection and newcharged counter names. No strictlegacybody changes.',
        fullsecondread_inverse='Normalize only private helpernames/counterprefix and projectedarray predicate; raw parent _reconcile_value restored. Same alloccurrence/strictscalar/keyset/cycle/length/orderededge/depth/size checks.',
        new_public_sequence='start_write; exactintcap; initial_finish; next-state transaction; label; firstprojectedbuild; ownedBODYcap; fullsecondread; unchanged_commit_root(final_finish,solepublish); busyFalse finally.',
        actual_inert_patch_executions=0,raw_inverse_verified=True))
    contract=save('Source-contract-v1.json',dict(schema='direct-tuple-projection-Source-contract-v1',**common,
        Source=pin(OUTPUT),parent=pin(PARENT),API=api,execution_profile=operation_profile,Source_delta=delta,
        current_master=current_master,status='FROZEN_SOURCE_ONLY_UNEXECUTED_UNQUALIFIED',
        obligations='All exact mathematical/evidence values retained under declared JSONprojection. Preserve legacy strictcapture domain and callback/lifecycle/reentrancy protocol, allfallible-before-solepublish, exact sourceguards, foreignexceptions, fullsecondread and no hash/identity-only matching. Projection is evidence storage only, no grammar/Native/search/mark or candidate change.',
        counts='No numeric limits raised or counters reset. New operation categories/profile explicit; no claims of same old JSONnormalization work profile or identical callbacksites/ordinals.',
        authority='No independent mathematical/evidence/runtime certificate or qualification inherited from previous Arena/helper/3oldsuccessfulcomponentinputs. Future independent Source review and fresh bounded fullqual/prospective/maxoncegrant required. OldV3fourfailures staynonadmitted/unrecoverable.',
        risks='No runtime tests/calls/performance/fit claim. Provisional typedDAG/transaction/frame/caches and fullsecondread stillcost memory/time; removing JSONnormalization intermediates neednot fit180s/1GiB or privatecaps. Fulllogicalbytes>128MiB cannot be rescued by compactwire under unchanged expandedcap.',
        future_qualification='Independent Root/B completeacceptedpreimages+boundedgeneric tuple/type/cycle/mutation/foreignerror/reentrancy/limit/closure/parity cases, fulloldstrictAPI regression separately scoped; no V3failedprefix recovery. No fixture implemented/executed here.',
        ancestry='Library authored parent Arena/directreconciliation, evidence/point/Model/cold/composer ancestors and this successor. Static authorargument not independent Source certification; Root ownsadapterintegration/controller, Controlindependentreview.'))
    audit=save('author-static-audit-v1.json',dict(schema='direct-tuple-projection-author-static-audit-v1',**common,
        check_count=len(CHECKS),checks=CHECKS,unused_compiles=1,actual_inert_patch_executions=0,
        Source=pin(OUTPUT),parent_legacy_methods_raw_AST_unchanged=True,
        no_subject_execution=True,no_test_results_claimed=True))
    handoff=save('handoff-v1.json',dict(schema='direct-tuple-projection-handoff-v1',**common,
        Source=pin(OUTPUT),API=api,Source_contract=contract,Source_delta=delta,
        execution_profile=operation_profile,author_static_audit=audit,author_Source=pin(__file__),
        parent=pin(PARENT),current_master=current_master,
        design=pin('/private/tmp/gcts-assembly-next-design-library-20261019/assembly-next-design-v1.json'),
        prior_milestone=pin('/private/tmp/gcts-new-quantified-integration-ROOT-20261019/ROOT-final-milestone-v1.json'),
        status='INACTIVE_UNEXECUTED_SOURCE_ONLY_NO_GRANT',tools_stopped_after_handoff=True))
    print(json.dumps(dict(Source=pin(OUTPUT),handoff=handoff,API=api,profile=operation_profile,
        checks=len(CHECKS),component_calls=0),sort_keys=True))


if __name__=='__main__':
    main()
