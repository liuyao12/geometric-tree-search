"""Inert administrative bundler; a separate reviewed Root once authority is required.

Only manifest/authority/own Source/runtime bodies are read before consume.
Scientific originals and the separately pinned historical baseline are opaque.
No project module, scientific parser, subprocess or network facility is used.
"""

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile
import zlib


SELF = Path(__file__).resolve()
STUDY = SELF.parent.parent
ROOT = STUDY / "root"
REPO = STUDY.parent.parent
R = REPO / "research-runs/gcts-receptor-acquisition-20261022"
ROOT_STAGE = ROOT / "publication-tableau-v1"
PUBLISHER_STAGE = (REPO / "research-runs/gcts-batch-20261020/"
                   "publisher-recovery-6338a77/publication-payload-tableau-v1")
PYTHON = {
    "path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
    "bytes": 18058560,
    "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840",
}
BASELINE = {
    "path": str(ROOT / "recovered-publication-inputs-v1/point-proof-parallel-progress-v1.html"),
    "bytes": 146811,
    "sha256": "d13aac0973e61a4b039877e737e681b7a4aeabcc41cb8ca1aeb36570e758fdb2",
}
EXTERNAL_ORIGINALS = {
    R / "review-C/translation-only-finite-Wang-point-GCTS-and-bounded-checker-design-v2.json",
    R / "review-C/translation-only-finite-Wang-point-GCTS-and-bounded-checker-design-fragment-v2.html",
    R / "root/full-evidence-archive-direct-user-publication-authorization-v1.json",
}
NAMES = (
    "point-proof-parallel-progress-v1.html",
    "point-proof-finite-tableau-qualification-summary-v1.json",
    "point-proof-finite-tableau-qualification-evidence-v1.zip",
)
TARGET_PREFIX = "docs/research/gcts-rl-renewal/conditional-inventory/"
CAP = 67108864
MEMBER_CAP = 33554432
ADMIN_CAP = 1048576
CHUNK = 65536
CATALOGUE_NAME = "catalogue.json"


class Refusal(Exception):
    pass


def require(ok, message):
    if not ok:
        raise Refusal(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)
            + "\n").encode("utf-8")


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate administrative JSON key")
            result[key] = value
        return result

    def nonfinite(_value):
        raise Refusal("nonfinite administrative JSON constant")

    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=nonfinite)


def rawpin(path, raw):
    return {"path": str(path), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def canonical(value):
    require(type(value) is str and value, "path exact nonempty string")
    path = Path(value)
    require(path.is_absolute() and str(path) == value
            and os.path.normpath(value) == value, "canonical absolute path required")
    require(all(not item.is_symlink() for item in (path, *path.parents)),
            "symlink ancestor/path refused")
    require(path.resolve() == path, "resolved path differs")
    return path


def regular(path):
    canonical(str(path))
    info = path.stat(follow_symlinks=False)
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1,
            "single-link regular file required")
    return info


def safe_study_path(path):
    return (path.is_relative_to(STUDY)
            and all(not part.startswith(".") for part in path.relative_to(STUDY).parts)
            and path.name not in {"index.html", "GCTS-I.html", "GCTS-II.html", "GCTS-III.html"})


def administrative_path(value):
    path = canonical(value)
    require(path.is_relative_to(ROOT) and safe_study_path(path)
            and path.suffix == ".json", "new-study Root JSON input required")
    regular(path)
    return path


def ref_shape(value, maximum=MEMBER_CAP):
    require(type(value) is dict and set(value) == {"path", "bytes", "sha256"},
            "rawref exact three fields required")
    path = canonical(value["path"])
    require(type(value["bytes"]) is int and 0 <= value["bytes"] <= maximum,
            "rawref exact bounded integer bytes required")
    require(type(value["sha256"]) is str
            and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]) is not None,
            "rawref lowercase SHA256 required")
    info = regular(path)
    require(info.st_size == value["bytes"], "rawref stat extent mismatch")
    return path


def full_read(path, cap):
    before = regular(path)
    require(before.st_size <= cap, "file extent exceeds bound")
    with path.open("rb") as handle:
        raw = handle.read(cap + 1)
    after = regular(path)
    require(len(raw) <= cap and len(raw) == before.st_size == after.st_size
            and (before.st_dev, before.st_ino, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_mtime_ns),
            "file changed or incomplete bounded read")
    return raw


def ref_read(value, maximum=MEMBER_CAP):
    path = ref_shape(value, maximum)
    raw = full_read(path, maximum)
    require(rawpin(path, raw) == value, "complete raw bytes/SHA256 mismatch")
    return raw


def runtime_guard():
    path = ref_shape(PYTHON, PYTHON["bytes"])
    before = regular(path)
    digest, count = hashlib.sha256(), 0
    with path.open("rb") as handle:
        while True:
            data = handle.read(CHUNK)
            if not data:
                break
            count += len(data)
            require(count <= PYTHON["bytes"], "runtime extent changed")
            digest.update(data)
    after = regular(path)
    require(count == PYTHON["bytes"] and digest.hexdigest() == PYTHON["sha256"]
            and (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
            "D90 complete runtime guard mismatch")
    return dict(PYTHON)


def archive_name(value):
    require(type(value) is str and value and len(value) <= 1024,
            "archive name exact bounded string required")
    path = PurePosixPath(value)
    require(bool(path.parts) and value not in (".", "..")
            and not path.is_absolute() and str(path) == value and "\\" not in value
            and re.match(r"^[A-Za-z]:", value) is None
            and all(ord(char) >= 32 and ord(char) != 127 for char in value)
            and all(part not in (".", "..") and not part.startswith(".")
                    for part in path.parts)
            and value != CATALOGUE_NAME, "unsafe or reserved archive name")
    return value


def allowed_original(path):
    return path in EXTERNAL_ORIGINALS or safe_study_path(path)


def output_directory(value, expected):
    path = canonical(value)
    require(path == expected and not path.exists(), "fixed fresh output directory required")
    require(path.parent.is_dir(), "output parent directory missing")
    return path


def preflight(manifest_arg, authority_arg):
    require(STUDY == Path("/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-finite-point-controller-20261026")
            and SELF == STUDY / "custody-L/prepare_finite_tableau_publication_v1.py",
            "fixed assigned preparer location required")
    require(__debug__ and sys.flags.optimize == 0 and sys.flags.isolated == 1
            and sys.flags.no_site == 1 and sys.flags.no_user_site == 1
            and sys.dont_write_bytecode and sys.flags.safe_path
            and sys.flags.ignore_environment == 1, "D90 -I -S -B assertions required")
    require(sys.implementation.name == "cpython" and sys.platform == "darwin"
            and sys.version_info[:3] == (3, 12, 14)
            and Path(sys.executable).resolve() == Path(PYTHON["path"]),
            "required D90 Darwin interpreter identity")
    manifest_path = administrative_path(manifest_arg)
    authority_path = administrative_path(authority_arg)
    require(manifest_path != authority_path, "manifest and authority must differ")
    # These two are typed administrative JSON, not scientific originals.
    manifest_raw = full_read(manifest_path, ADMIN_CAP)
    authority_raw = full_read(authority_path, 65536)
    manifest, authority = strict_json(manifest_raw), strict_json(authority_raw)
    require(type(manifest) is dict and set(manifest) == {
        "schema", "baseline", "fragment", "summary", "members", "python",
        "root_stage", "publisher_stage", "original_member_count"}, "manifest exact nine fields")
    require(type(manifest["schema"]) is str
            and manifest["schema"] == "Root-finite-tableau-publication-manifest-v1",
            "manifest schema mismatch")
    require(type(authority) is dict and set(authority) == {
        "schema", "authorized", "uses", "manifest", "preparer"}, "authority exact five fields")
    require(type(authority["schema"]) is str
            and authority["schema"] == "Root-finite-tableau-publication-preparer-once-authority-v1"
            and authority["authorized"] is True and type(authority["uses"]) is int
            and authority["uses"] == 1, "once authority values mismatch")
    ref_shape(authority["manifest"], ADMIN_CAP)
    require(authority["manifest"] == rawpin(manifest_path, manifest_raw),
            "authority must bind complete manifest")
    preparer_path = ref_shape(authority["preparer"])
    require(preparer_path == SELF, "authority must bind executing preparer")
    preparer_raw = ref_read(authority["preparer"])
    ref_shape(manifest["python"], PYTHON["bytes"])
    require(manifest["python"] == PYTHON, "manifest exact D90 rawpin required")
    runtime_guard()
    ref_shape(manifest["baseline"])
    require(manifest["baseline"] == BASELINE, "exact historical baseline required")
    for key, suffix in (("fragment", ".html"), ("summary", ".json")):
        path = ref_shape(manifest[key])
        require(path.is_relative_to(ROOT) and safe_study_path(path)
                and path.suffix == suffix, "Root-authored public fragment/summary path required")
    output_directory(manifest["root_stage"], ROOT_STAGE)
    output_directory(manifest["publisher_stage"], PUBLISHER_STAGE)
    require(type(manifest["members"]) is list and len(manifest["members"]) <= 256
            and type(manifest["original_member_count"]) is int
            and manifest["original_member_count"] == len(manifest["members"]),
            "explicit original member count mismatch")
    names, paths, total = set(), set(), 0
    prohibited = {manifest_path, authority_path,
                  Path(str(authority_path) + ".CONSUMED.json")}
    for item in manifest["members"]:
        require(type(item) is dict and set(item) == {"archive_name", "category", "ref"},
                "member exact three fields")
        name = archive_name(item["archive_name"])
        require(type(item["category"]) is str
                and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", item["category"]),
                "member category bounded literal label")
        path = ref_shape(item["ref"])
        require(allowed_original(path) and path not in prohibited
                and not path.is_relative_to(ROOT_STAGE)
                and not path.is_relative_to(PUBLISHER_STAGE), "nonallowed original path")
        require(name not in names and path not in paths, "duplicate member name or original path")
        names.add(name)
        paths.add(path)
        total += item["ref"]["bytes"]
    require(total <= CAP, "sum of explicit raw originals exceeds64MiB")
    require(all(manifest[key]["path"] in {str(path) for path in paths}
                for key in ("summary", "fragment")), "summary/fragment must be explicit originals")
    for key in ("summary", "fragment"):
        require(any(item["ref"] == manifest[key] for item in manifest["members"]),
                "public input member rawref mismatch")
    marker = Path(str(authority_path) + ".CONSUMED.json")
    require(not marker.exists() and not marker.is_symlink(), "authority already consumed")
    return {"manifest_path": manifest_path, "authority_path": authority_path,
            "manifest_raw": manifest_raw, "authority_raw": authority_raw,
            "manifest": manifest, "authority": authority,
            "preparer_raw": preparer_raw, "marker": marker,
            "raw_original_bytes": total}


def write_new(path, raw):
    require(len(raw) <= CAP, "controlled output extent exceeds64MiB")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    require(full_read(path, CAP) == raw, "new output complete readback mismatch")
    return rawpin(path, raw)


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class BoundedZIP(io.BytesIO):
    def write(self, data):
        require(self.tell() + len(data) <= CAP, "outer ZIP extent exceeds64MiB")
        return super().write(data)


def zip_info(name):
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    return info


def prepare(manifest_arg, authority_arg):
    state = preflight(manifest_arg, authority_arg)
    manifest, authority = state["manifest"], state["authority"]
    manifest_pin = rawpin(state["manifest_path"], state["manifest_raw"])
    authority_pin = rawpin(state["authority_path"], state["authority_raw"])
    preparer_pin = rawpin(SELF, state["preparer_raw"])
    consume = {"schema": "Root-finite-tableau-publication-preparer-consumed-v1",
               "manifest": manifest_pin, "authority": authority_pin,
               "preparer": preparer_pin, "uses": 1, "scientific_execution": False}
    consume_raw = encoded(consume)
    consume_pin = write_new(state["marker"], consume_raw)
    fsync_directory(state["marker"].parent)
    # First nonmetadata body transport is strictly below the exclusive consume.
    ROOT_STAGE.mkdir(mode=0o700)
    PUBLISHER_STAGE.mkdir(mode=0o700)
    originals = {}
    rows = []
    for item in sorted(manifest["members"], key=lambda item: item["archive_name"]):
        body = ref_read(item["ref"])
        originals[item["archive_name"]] = body
        rows.append(dict(item, CRC32=format(zlib.crc32(body) & 0xffffffff, "08x")))
    baseline = ref_read(manifest["baseline"])
    by_path = {item["ref"]["path"]: item["archive_name"] for item in manifest["members"]}
    fragment = originals[by_path[manifest["fragment"]["path"]]]
    summary = originals[by_path[manifest["summary"]["path"]]]
    # Summary/fragment are copied exactly; no scientific or public JSON schema is guessed.
    baseline.decode("utf-8")
    fragment.decode("utf-8")
    summary.decode("utf-8")
    openings = list(re.finditer(rb"<body(?:\s[^<>]*)?>", baseline, flags=re.IGNORECASE))
    require(len(openings) == 1, "pinned baseline must have exactly one body opening tag")
    offset = openings[0].end()
    report = baseline[:offset] + fragment + baseline[offset:]
    require(report[:offset] + report[offset + len(fragment):] == baseline
            and report[offset:offset + len(fragment)] == fragment,
            "complete insert-only historical inverse failed")
    catalogue = {"schema": "Root-finite-tableau-publication-evidence-catalogue-v1",
                 "manifest": manifest_pin, "administrative_manifest": manifest,
                 "authority": authority_pin, "administrative_authority": authority,
                 "preparer": preparer_pin, "external_runtime": PYTHON,
                 "runtime_association_only_in_archive": True,
                 "original_member_count": len(rows), "members": rows,
                 "scientific_execution": False,
                 "scope": "Exactly explicit selected originals only; no previous full external archive cloned, nested ZIP read, scientific validation or recursive historical closure. Catalogue has no selfhash."}
    catalogue_raw = encoded(catalogue)
    require(len(catalogue_raw) <= ADMIN_CAP, "catalogue metadata extent exceeds bound")
    all_bodies = dict(originals)
    all_bodies[CATALOGUE_NAME] = catalogue_raw
    buffer = BoundedZIP()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9, allowZip64=False) as archive:
        for name in sorted(all_bodies):
            archive.writestr(zip_info(name), all_bodies[name], compresslevel=9)
    archive_raw = buffer.getvalue()
    verified = []
    with zipfile.ZipFile(io.BytesIO(archive_raw), "r") as archive:
        require(archive.namelist() == sorted(all_bodies)
                and len(archive.infolist()) == len(rows) + 1,
                "complete unique archive census mismatch")
        require(archive.testzip() is None, "complete archive CRC failure")
        require(all(info.date_time == (1980, 1, 1, 0, 0, 0)
                    and info.create_system == 3
                    and info.external_attr == (stat.S_IFREG | 0o644) << 16
                    and info.compress_type == zipfile.ZIP_DEFLATED
                    and not (info.flag_bits & 1) and not info.is_dir()
                    for info in archive.infolist()) and archive.comment == b"",
                "deterministic regular ZIP metadata mismatch")
        require(archive.read(CATALOGUE_NAME) == catalogue_raw,
                "complete catalogue byte readback mismatch")
        for row in rows:
            name = row["archive_name"]
            member = archive.read(name)
            current = ref_read(row["ref"])
            info = archive.getinfo(name)
            require(member == originals[name] == current
                    and info.file_size == row["ref"]["bytes"]
                    and hashlib.sha256(member).hexdigest() == row["ref"]["sha256"]
                    and format(info.CRC, "08x") == row["CRC32"],
                    "complete original/member byte/hash/CRC pair mismatch")
            verified.append(dict(row, complete_original_member_byte_equality=True))
    require(ref_read(manifest["baseline"]) == baseline, "baseline changed after inverse")
    require(full_read(state["manifest_path"], ADMIN_CAP) == state["manifest_raw"]
            and full_read(state["authority_path"], 65536) == state["authority_raw"]
            and ref_read(preparer_pin) == state["preparer_raw"],
            "metadata/own Source postguard changed")
    runtime_guard()
    bodies = {NAMES[0]: report, NAMES[1]: summary, NAMES[2]: archive_raw}
    files = []
    for name in NAMES:
        body = bodies[name]
        files.append({"path": TARGET_PREFIX + name,
                      "root_source": str(ROOT_STAGE / name),
                      "publisher_source": str(PUBLISHER_STAGE / name),
                      "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest(),
                      "git_blob_sha1": hashlib.sha1(b"blob " + str(len(body)).encode()
                                                   + b"\0" + body).hexdigest()})
    staging = {"schema": "Root-finite-tableau-publication-three-path-staging-v1",
               "manifest": manifest_pin, "authority": authority_pin,
               "consume": consume_pin, "preparer": preparer_pin,
               "external_runtime": PYTHON, "baseline": manifest["baseline"],
               "fragment": manifest["fragment"], "summary": manifest["summary"],
               "files": files, "original_member_count": len(rows),
               "archive_entries": len(rows) + 1,
               "catalogue": {"bytes": len(catalogue_raw),
                             "sha256": hashlib.sha256(catalogue_raw).hexdigest()},
               "complete_original_pairs": verified,
               "raw_original_bytes": state["raw_original_bytes"],
               "baseline_full_inverse_verified": True,
               "pre_post_metadata_Source_runtime_guards_matched": True,
               "all_complete_CRC_and_original_pairs_verified": True,
               "scientific_execution": False, "publication": False,
               "controlled_physical_bytes": 0, "controlled_physical_cap": CAP,
               "scope": "Selected explicit raw transport only; independent package/content/visual/publisher/live gates remain. No scientific admission or recursive closure claim."}
    for _ in range(16):
        staging_raw = encoded(staging)
        total = len(consume_raw) + len(staging_raw) + 2 * sum(map(len, bodies.values()))
        if total == staging["controlled_physical_bytes"]:
            break
        staging["controlled_physical_bytes"] = total
    else:
        raise Refusal("physical-accounting fixed point did not converge")
    require(total <= CAP and len(staging_raw) <= ADMIN_CAP,
            "combined controlled outputs exceed64MiB or metadata bound")
    for name in NAMES:
        write_new(ROOT_STAGE / name, bodies[name])
        write_new(PUBLISHER_STAGE / name, bodies[name])
        require(full_read(ROOT_STAGE / name, CAP) == full_read(PUBLISHER_STAGE / name, CAP)
                == bodies[name], "complete Root/P2 twin mismatch")
    require({path.name for path in PUBLISHER_STAGE.iterdir()} == set(NAMES)
            and all(path.is_file() and not path.is_symlink()
                    for path in PUBLISHER_STAGE.iterdir()), "P2 must contain exact three payload files")
    staging_pin = write_new(ROOT_STAGE / "P2-staging.json", staging_raw)
    require({path.name for path in ROOT_STAGE.iterdir()} == set(NAMES) | {"P2-staging.json"},
            "Root stage unexpected producer output")
    fsync_directory(ROOT_STAGE)
    fsync_directory(PUBLISHER_STAGE)
    return {"schema": "Root-finite-tableau-publication-preparer-terminal-v1",
            "status": "PREPARED_EXACT_THREE_PATHS_NOT_PUBLISHED",
            "staging": staging_pin, "consume": consume_pin, "files": files,
            "controlled_physical_bytes": total, "scientific_execution": False,
            "scientific_admission": False, "publication": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--authority", required=True)
    args = parser.parse_args()
    try:
        result = prepare(args.manifest, args.authority)
        output = encoded(result)
        require(len(output) <= 65536, "terminal administrative extent refused")
        sys.stdout.buffer.write(output)
        sys.stdout.buffer.flush()
        return 0
    except BaseException as error:
        failure = {"schema": "Root-finite-tableau-publication-preparer-terminal-v1",
                   "status": "FAILED_UNPUBLISHABLE", "publication": False,
                   "scientific_execution": False,
                   "error": type(error).__name__ + ": " + str(error)[:2048],
                   "scope": "Consumed marker/partial directories, if present, remain spent and unpublishable. No automatic retry or scientific admission."}
        sys.stderr.buffer.write(encoded(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
