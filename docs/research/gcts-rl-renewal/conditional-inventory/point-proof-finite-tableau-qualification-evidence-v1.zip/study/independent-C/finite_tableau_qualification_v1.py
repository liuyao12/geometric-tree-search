"""Inert supplied-table qualification Source; reviewed five-role once required.

No project module is imported and no literal control/table is evaluated until
main authenticates the exact plan and retained Source bytes in a later actual.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import sys
import time
import traceback
import types

VERSION = "GCTS-FINITE-TABLEAU-QUALIFICATION-v1"
PLAN_SCHEMA = "GCTS-finite-tableau-once-plan-v1"
RESULT_SCHEMA = "GCTS-finite-tableau-qualification-result-v1"
PYTHON = {"path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
          "bytes": 18058560,
          "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840"}
LIMITS = {"worker_seconds": 90, "custody_seconds": 120, "observer_seconds": 150,
          "memory_bytes": 1073741824, "result_bytes": 67108864,
          "log_bytes": 1048576, "observer_reserve_bytes": 16777216}
EXPECTED_COUNTS = {"engine_instances": 8, "solve_calls": 8, "positive_returns": 3,
                   "finite_exhausted_returns": 2, "deliberate_unknown_returns": 3,
                   "raw_history_examinations": 98430, "compiler_calls": 26,
                   "production_decode_calls": 16, "malformed_spec_cases": 17,
                   "malformed_assignment_cases": 8, "malformed_bundle_cases": 4,
                   "valid_shuffled_table_controls": 1, "valid_reversed_assignment_controls": 1,
                   "accepted_history_records_including_repeats": 6}
EXPECTED_REJECTIONS = {"INITIAL": 94780, "FINAL": 3513, "TRANSITION": 131, "ACCEPTED": 6}
MAX_AUDITS = 2000
MAX_ALL_HISTORY_EXAMINATIONS = 100000


class QualificationError(RuntimeError):
    """Reject whole qualification; no partial scientific admission."""


def _need(condition, message):
    if not condition:
        raise QualificationError(message)

def _copy(value):
    return json.loads(json.dumps(value, allow_nan=False, separators=(",", ":")))

def _no_duplicate_object(pairs):
    result = {}
    for key, value in pairs:
        _need(key not in result, "duplicate JSON object key")
        result[key] = value
    return result

def _pin_shape(pin):
    _need(type(pin) is dict and set(pin) == {"path", "bytes", "sha256"}, "rawpin shape")
    _need(type(pin["path"]) is str and Path(pin["path"]).is_absolute(), "rawpin absolute path")
    _need(type(pin["bytes"]) is int and pin["bytes"] >= 0, "rawpin byte count")
    _need(type(pin["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", pin["sha256"]),
          "rawpin digest")

def _canonical_path(value, label, kind):
    _need(type(value) is str, label + " path string")
    path = Path(value)
    _need(path.is_absolute() and str(path) == value and os.path.normpath(value) == value,
          label + " canonical absolute path")
    for ancestor in (path, *path.parents):
        _need(not ancestor.is_symlink(), label + " nonsymlink ancestor chain")
    _need(str(path.resolve(strict=False)) == value, label + " resolved canonical path")
    if kind == "file":
        _need(path.is_file() and path.stat(follow_symlinks=False).st_nlink == 1,
              label + " single-link regular file")
    elif kind == "directory":
        _need(path.is_dir(), label + " directory")
    elif kind == "newfile":
        _need(not path.exists() and path.parent.is_dir(), label + " fresh file with owned parent")
    else:
        raise QualificationError("unknown canonical path kind")
    return path

def _load(pin, name):
    """Future main only: compile and execute these exact authenticated bytes."""
    authenticated = _check_pin(pin)
    code = compile(authenticated, pin["path"], "exec", dont_inherit=True, optimize=0)
    module = types.ModuleType(name)
    module.__file__ = pin["path"]
    module.__package__ = ""
    module.__loader__ = None
    module.__spec__ = None
    module.__cached__ = None
    sys.modules[name] = module
    exec(code, module.__dict__)
    return module


def _read_json(path):
    size = path.stat(follow_symlinks=False).st_size
    _need(size <= 65536, "administrative plan extent")
    with path.open("rb") as stream:
        raw = stream.read(65537)
    _need(len(raw) == size and len(raw) <= 65536, "complete bounded administrative plan")
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=_no_duplicate_object,
                       parse_constant=lambda unused: (_ for _ in ()).throw(QualificationError("nonfinite JSON")))
    return value, {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def _check_pin(pin):
    _pin_shape(pin)
    path = _canonical_path(pin["path"], "pinned Source/runtime", "file")
    _need(path.stat(follow_symlinks=False).st_size == pin["bytes"], "pinned stat extent")
    with path.open("rb") as stream:
        data = stream.read(pin["bytes"] + 1)
    _need(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
          "complete current rawpin mismatch: " + pin["path"])
    return data


def _authenticate(plan_path, result_path):
    _canonical_path(str(plan_path), "plan", "file")
    _canonical_path(str(result_path), "result", "newfile")
    study = Path(__file__).resolve().parent.parent
    _need(plan_path.is_relative_to(study / "root") and plan_path.suffix == ".json" and
          all(not part.startswith(".") for part in plan_path.relative_to(study).parts), "owned administrative plan")
    plan, plan_pin = _read_json(plan_path)
    _need(type(plan) is dict and set(plan) == {"schema", "case_id", "actual_dir", "python", "sources", "limits"},
          "strict plan6 fields")
    _need(type(plan["schema"]) is str and plan["schema"] == PLAN_SCHEMA, "plan schema")
    _need(type(plan["case_id"]) is str and re.fullmatch("[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"]), "case ID")
    actual = study / "actual" / plan["case_id"]
    _canonical_path(str(actual), "owned actual", "directory")
    _need(type(plan["actual_dir"]) is str and plan["actual_dir"] == str(actual) and
          result_path == actual / "worker-result.json", "owned actual/result association")
    _pin_shape(plan["python"])
    _need(plan["python"] == PYTHON and type(plan["limits"]) is dict and set(plan["limits"]) == set(LIMITS) and
          all(type(plan["limits"][key]) is int and plan["limits"][key] == value for key, value in LIMITS.items()),
          "D90 and exact limits7")
    _need(sys.executable == PYTHON["path"] and sys.platform == "darwin" and sys.flags.isolated == 1 and
          sys.flags.no_site == 1 and sys.flags.dont_write_bytecode == 1 and sys.flags.optimize == 0,
          "D90 isolated assertions-on invocation")
    _need(type(plan["sources"]) is dict and set(plan["sources"]) == {"observer", "worker", "engine", "compiler", "oracle"},
          "strict Sources5")
    expected_paths = {
        "observer": study / "custody-L/tableau_once_observer_v1.py", "worker": Path(__file__).resolve(),
        "engine": study / "root/recovered-current-sources-v1/finite_point_engine_v1.py",
        "compiler": study / "implementation-B/finite_local_table_tableau_v1.py",
        "oracle": study / "independent-C/finite_tableau_independent_v1.py"}
    for role, path in expected_paths.items():
        _pin_shape(plan["sources"][role])
        _need(plan["sources"][role]["path"] == str(path) and 0 < plan["sources"][role]["bytes"] <= 2097152,
              "exact bounded role Source")
        _check_pin(plan["sources"][role])
    _check_pin(PYTHON)
    return plan, plan_pin


def _primary_table():
    """New Source-literal adopted input table; never evaluated during authoring."""
    return [
        ["#", "#", "#", "#"], ["#", "#", "0", "#"], ["#", "#", "1", "#"],
        ["#", "0", "#", "0"], ["#", "0", "0", "0"], ["#", "0", "1", "1"],
        ["#", "1", "#", "0"], ["#", "1", "0", "0"], ["#", "1", "1", "1"],
        ["0", "#", "#", "#"], ["0", "#", "0", "#"], ["0", "#", "1", "#"],
        ["0", "0", "#", "0"], ["0", "0", "0", "0"], ["0", "0", "1", "1"],
        ["0", "1", "#", "0"], ["0", "1", "0", "0"], ["0", "1", "1", "1"],
        ["1", "#", "#", "#"], ["1", "#", "0", "#"], ["1", "#", "1", "#"],
        ["1", "0", "#", "1"], ["1", "0", "0", "1"], ["1", "0", "1", "0"],
        ["1", "1", "#", "1"], ["1", "1", "0", "1"], ["1", "1", "1", "0"]]


def _controls():
    return [
        ("primary-accepted", 5, 2, "#100#", "#101#", "FINITE_EXACT_SOLUTION", 10000, 19683),
        ("primary-impossible-final", 5, 2, "#100#", "#100#", "EXHAUSTED_FINITE_SEARCH", 10000, 19683),
        ("zero-step-equal-minwidth", 3, 0, "#1#", "#1#", "FINITE_EXACT_SOLUTION", 10000, 3),
        ("zero-step-unequal-minwidth", 3, 0, "#1#", "#0#", "EXHAUSTED_FINITE_SEARCH", 10000, 3),
        ("primary-node-zero", 5, 2, "#100#", "#101#", "UNKNOWN/NODE_LIMIT", 0, 19683),
        ("primary-node-one-rollback", 5, 2, "#100#", "#101#", "UNKNOWN/NODE_LIMIT", 1, 19683),
        ("primary-external-refusal", 5, 2, "#100#", "#101#", "UNKNOWN/EXTERNAL_BUDGET", 10000, 19683),
        ("alternate-supplied-table", 3, 1, "#1#", "#1#", "FINITE_EXACT_SOLUTION", 10000, 9)]


def _spec(control):
    identity, width, steps, initial, final, unused_status, unused_nodes, unused_domain = control
    table = _primary_table()
    if identity == "alternate-supplied-table":
        for row in table:
            if row[:3] == ["#", "1", "#"]:
                row[3] = "1"
    return {"schema": "GCTS-supplied-local-table-spec-v1", "alphabet": ["#", "0", "1"],
            "transitions": table, "width": width, "steps": steps,
            "initial": list(initial), "final": list(final)}


def _bad_specs(primary):
    cases = []

    def add(name, code, change):
        raw = _copy(primary)
        change(raw)
        cases.append({"id": name, "expected_code": code, "input": raw})

    add("extra-field", "SPEC_SCHEMA", lambda s: s.update(extra=0))
    add("wrong-schema", "SPEC_SCHEMA", lambda s: s.update(schema="WRONG"))
    add("alphabet-order", "SPEC_ALPHABET", lambda s: s["alphabet"].reverse())
    add("missing-triple", "SPEC_TRANSITIONS", lambda s: s["transitions"].pop())
    add("duplicate-triple", "SPEC_TRANSITIONS", lambda s: s["transitions"].__setitem__(-1, _copy(s["transitions"][0])))
    add("output-outside", "SPEC_TRANSITIONS", lambda s: s["transitions"][0].__setitem__(3, "X"))
    add("wall-output", "SPEC_TRANSITIONS", lambda s: s["transitions"][0].__setitem__(3, "0"))
    add("bool-width", "SPEC_DIMENSIONS", lambda s: s.update(width=True))
    add("float-steps", "SPEC_DIMENSIONS", lambda s: s.update(steps=2.0))
    add("dimension-outside", "SPEC_DIMENSIONS", lambda s: s.update(width=6))
    add("word-length", "SPEC_WORDS", lambda s: s["initial"].pop())
    add("word-symbol", "SPEC_WORDS", lambda s: s["initial"].__setitem__(1, "X"))
    add("word-guard", "SPEC_WORDS", lambda s: s["initial"].__setitem__(0, "0"))
    add("priority-schema", "SPEC_SCHEMA", lambda s: (s.update(extra=0), s["alphabet"].reverse()))
    add("priority-alphabet", "SPEC_ALPHABET", lambda s: (s["alphabet"].reverse(), s["transitions"].pop()))
    add("priority-transitions", "SPEC_TRANSITIONS", lambda s: (s["transitions"].pop(), s.update(width=True)))
    add("priority-dimensions", "SPEC_DIMENSIONS", lambda s: s.update(width=2, initial=["X"]))
    return cases


def _bad_assignments(assignment):
    cases = []

    def add(name, change):
        raw = _copy(assignment)
        change(raw)
        cases.append({"id": name, "expected_code": "ASSIGNMENT", "input": raw})

    add("missing", lambda a: a.pop())
    add("duplicate", lambda a: a.append(_copy(a[0])))
    add("nonregion", lambda a: a[0].__setitem__(0, -1))
    add("bool-coordinate", lambda a: a[0].__setitem__(0, True))
    add("float-coordinate", lambda a: a[0].__setitem__(1, 0.0))
    add("unknown-ID", lambda a: a[0].__setitem__(2, "UNKNOWN"))
    add("wrong-rowkind", lambda a: a[0].__setitem__(2, "C:#:#:#"))
    add("edge-conflict", lambda a: next(row for row in a if row[:2] == [1, 1]).__setitem__(2, "C:#:1:1"))
    return cases


def _bad_bundles(bundle):
    cases = []

    def add(name, change):
        raw = _copy(bundle)
        change(raw)
        cases.append({"id": name, "expected_code": "BUNDLE_CANONICAL", "input": raw})

    add("bundle-extra", lambda b: b.update(extra=0))
    add("bundle-palette-order", lambda b: b["palette"].reverse())
    add("bundle-spec-float", lambda b: b["spec"].update(width=5.0))
    add("bundle-spec-table-order", lambda b: b["spec"]["transitions"].reverse())
    return cases


class _Run:
    def __init__(self, engine, compiler, oracle, began):
        self.engine = engine
        self.compiler = compiler
        self.oracle = oracle
        self.began = began
        self.budget_calls = 0
        self.audit_count = 0
        self.compiler_calls = 0
        self.decode_calls = 0
        self.history_examined = 0
        self.controls = []

    def budget(self):
        self.budget_calls += 1
        _need(time.monotonic() - self.began < LIMITS["worker_seconds"], "worker cooperative time refusal")
        _need(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss + LIMITS["observer_reserve_bytes"]
              <= LIMITS["memory_bytes"], "worker cooperative self-highwater plus declared reserve refusal")

    def compile(self, spec):
        self.budget()
        self.compiler_calls += 1
        result = self.compiler.compile_tableau(spec)
        self.budget()
        return result

    def decode(self, bundle, assignment):
        self.budget()
        self.decode_calls += 1
        result = self.compiler.decode_tableau(bundle, assignment)
        self.budget()
        return result

    def control(self, descriptor):
        identity, unused_w, unused_t, unused_i, unused_f, wanted, nodes, domain = descriptor
        self.budget()
        started = time.monotonic()
        calls_before = self.budget_calls
        spec = _spec(descriptor)
        caller = _copy(spec)
        bundle = self.compile(caller)
        self.oracle._same(caller, spec, "compile leaves caller unchanged")
        # Poison only the throwaway caller AFTER compile, never the retained
        # raw spec or candidate universe. Detect child-list aliases as well.
        caller["alphabet"].append("POISON")
        caller["transitions"][0][3] = "POISON"
        caller["initial"][1] = "POISON"
        caller["final"][1] = "POISON"
        caller.clear()
        _need(self.oracle.tableau_equal(bundle, self.oracle.tableau_expected_bundle(spec)),
              "detached complete compiler bundle")
        model = self.engine.compile_wang(bundle["palette"], bundle["region"], bundle["boundary"])
        model_check = self.oracle.tableau_verify_bundle_model(spec, bundle, model)
        histories = self.oracle.tableau_histories(spec, self.budget, 20000)
        _need(histories["examined"] == domain and histories["complete"] is True, "complete control history domain")
        self.history_examined += histories["examined"]
        _need(self.history_examined <= MAX_ALL_HISTORY_EXAMINATIONS, "global history-domain refusal")
        expected = self.oracle.tableau_expected_solutions(bundle, model, histories)
        _need(len(expected["solutions"]) == (0 if wanted == "EXHAUSTED_FINITE_SEARCH" else 1),
              "declared independent solution count")
        events = []
        previous_metrics = {"value": None}
        static_dependencies = {"value": None}
        gate = {"refuse": False}

        def engine_budget():
            self.budget()
            return False if gate["refuse"] else None

        def audit(engine, event):
            self.budget()
            self.audit_count += 1
            _need(self.audit_count <= MAX_AUDITS, "full audit event cap; never truncate")
            _need(type(event) is dict and set(event) == {"kind", "data"} and type(event["kind"]) is str,
                  "stable audit shape")
            snapshot = engine.snapshot()
            check = self.oracle.verify_snapshot(model, snapshot)
            dependencies = engine.dependencies
            dependency_check = self.oracle.verify_dependencies(model, dependencies)
            if static_dependencies["value"] is None:
                static_dependencies["value"] = dependencies
            else:
                self.oracle._same(dependencies, static_dependencies["value"], "static dependency identity")
            metrics = engine.metrics
            self.oracle.verify_metrics(metrics, snapshot, previous_metrics["value"])
            previous_metrics["value"] = _copy(metrics)
            kind, data = event["kind"], event["data"]
            fields = {"INITIALIZED": set(), "PLACED": {"id", "reason", "generation"},
                      "EXCLUDED": {"id", "reason"}, "ROLLED_BACK": {"checkpoint"},
                      "DECISION": {"kind", "point", "candidates"},
                      "SOLVE_RESULT": {"status", "nodes", "reason"}}
            _need(kind in fields and type(data) is dict and set(data) == fields[kind], "stable audit fields")
            if kind == "DECISION":
                self.oracle._same(data, check["decision"], "complete-graph reference decision")
            elif kind == "PLACED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and type(data["generation"]) is int
                      and snapshot["selected"][-1] == data["id"] and
                      [data["id"], data["generation"]] in snapshot["tile_generations"], "placed event state")
            elif kind == "EXCLUDED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and
                      data in snapshot["excluded"], "excluded event state")
            elif kind == "ROLLED_BACK":
                _need(type(data["checkpoint"]) is int and data["checkpoint"] == snapshot["trail_size"],
                      "rollback exact trail boundary")
            elif kind == "SOLVE_RESULT":
                _need(type(data["nodes"]) is int and data["nodes"] >= 0 and
                      data["status"] in ("FINITE_EXACT_SOLUTION", "EXHAUSTED_FINITE_SEARCH", "UNKNOWN") and
                      data["reason"] in ("SOLUTION", "EXHAUSTED", "NODE_LIMIT", "EXTERNAL_BUDGET"),
                      "solve result event")
            exclusion_check = self.oracle.verify_contextual_exclusions(snapshot, expected["solutions"])
            events.append({"event": _copy(event), "snapshot": snapshot, "metrics": metrics,
                           "independent_snapshot": check, "dependency_check": dependency_check,
                           "search_exclusion_check": exclusion_check})
            self.budget()

        self.budget()
        engine = self.engine.Engine(model, audit=audit, budget=engine_budget)
        _need(len(events) == 1 and events[0]["event"]["kind"] == "INITIALIZED", "constructor complete stable audit")
        self.oracle._same(engine.model, self.oracle.canonical_model(model), "canonical raw point model")
        entry = engine.snapshot()
        checkpoint = engine.checkpoint()
        _need(type(checkpoint) is int and checkpoint == entry["trail_size"], "entry checkpoint")
        gate["refuse"] = identity == "primary-external-refusal"
        try:
            result = engine.solve(node_limit=nodes)
        finally:
            gate["refuse"] = False
        final = engine.snapshot()
        unknown = wanted.startswith("UNKNOWN/")
        result_check = self.oracle.verify_solve_result(model, result, entry, final, expected, unknown)
        expected_status, separator, expected_reason = wanted.partition("/")
        _need(result["status"] == expected_status and result["nodes"] <= nodes, "exact declared solve status/node ceiling")
        if separator:
            _need(result["reason"] == expected_reason, "exact deliberate UNKNOWN reason")
        if identity == "primary-node-zero":
            _need(result["nodes"] == 0 and not any(e["event"]["kind"] == "DECISION" for e in events),
                  "node-zero UNKNOWN without decision")
        if identity == "primary-node-one-rollback":
            _need(result["nodes"] == 1 and any(e["event"]["kind"] == "PLACED" and
                  e["event"]["data"]["reason"] == "FORCED" and
                  len(e["snapshot"]["selected"]) > len(entry["selected"]) for e in events),
                  "node-one UNKNOWN exercised forced-prefix rollback")
        inverse = None
        if result["status"] == "FINITE_EXACT_SOLUTION":
            independent = self.oracle.tableau_verify_point_result(spec, bundle, model, result["selected"])
            assignment = independent["assignment_for_production_inverse"]
            bundle_before, assignment_before = _copy(bundle), _copy(assignment)
            production = self.decode(bundle, assignment)
            self.oracle._same(bundle, bundle_before, "inverse leaves bundle unchanged")
            self.oracle._same(assignment, assignment_before, "inverse leaves assignment unchanged")
            self.oracle._same(production, independent["trace"], "whole production/independent trace inverse")
            inverse = {"independent": independent, "production": production}
            engine.rollback(checkpoint)
            self.oracle._same(engine.snapshot(), entry, "explicit success whole rollback")
        else:
            self.oracle._same(final, entry, "exhausted/UNKNOWN exact entry restoration")
        restored = engine.snapshot()
        self.oracle.verify_snapshot(model, restored)
        self.budget()
        record = {"id": identity, "spec": spec, "bundle": bundle, "model": model,
                  "static_dependencies": static_dependencies["value"], "histories": histories,
                  "expected_solutions": expected, "entry": entry, "entry_checkpoint": checkpoint,
                  "events": events, "solve_result": result, "final": final, "restored": restored,
                  "checks": {"bundle_model": model_check, "solve_result": result_check,
                             "whole_entry_rollback": True, "compile_input_detached": True},
                  "inverse": inverse,
                  "costs": {"elapsed_seconds": time.monotonic() - started,
                            "budget_callbacks": self.budget_calls - calls_before,
                            "self_lifetime_highwater_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
        _need(len(record) == 16, "complete control16 envelope")
        self.controls.append(record)

    def rejection(self, call, error_type, code):
        self.budget()
        try:
            call()
        except error_type as error:
            _need(error.args == (code,) and str(error) == code, "exact sole-message error code")
            return {"type": type(error).__name__, "args": list(error.args), "message": str(error)}
        raise QualificationError("malformed input accepted: " + code)

    def malformed(self):
        primary = self.controls[0]
        bundle = primary["bundle"]
        assignment = primary["expected_solutions"]["traces"][0]["assignment"]
        bad_specs = []
        for case in _bad_specs(primary["spec"]):
            code, raw = case["expected_code"], case["input"]
            b = self.rejection(lambda: self.compile(raw), self.compiler.TableauError, code)
            c = self.rejection(lambda: self.oracle.tableau_normalize_spec(raw), self.oracle.tableau_Error, code)
            bad_specs.append({**case, "production_rejection": b, "independent_rejection": c})
        bad_assignments = []
        for case in _bad_assignments(assignment):
            code, raw = case["expected_code"], case["input"]
            b = self.rejection(lambda: self.decode(bundle, raw), self.compiler.TableauError, code)
            c = self.rejection(lambda: self.oracle.tableau_decode_assignment(bundle, raw), self.oracle.tableau_Error, code)
            bad_assignments.append({**case, "canonical_bundle_control": primary["id"],
                                    "production_rejection": b, "independent_rejection": c})
        bad_bundles = []
        for case in _bad_bundles(bundle):
            code, raw = case["expected_code"], case["input"]
            b = self.rejection(lambda: self.decode(raw, assignment), self.compiler.TableauError, code)
            c = self.rejection(lambda: self.oracle.tableau_decode_assignment(raw, assignment), self.oracle.tableau_Error, code)
            bad_bundles.append({**case, "canonical_assignment_control": primary["id"],
                                "production_rejection": b, "independent_rejection": c})
        shuffled = _copy(primary["spec"])
        shuffled["transitions"].reverse()
        before = _copy(shuffled)
        normalized_bundle = self.compile(shuffled)
        self.oracle._same(shuffled, before, "shuffled input unchanged")
        self.oracle._same(normalized_bundle, bundle, "shuffled table normalizes identically")
        _need(self.oracle.tableau_equal(self.oracle.tableau_expected_bundle(shuffled), bundle),
              "independent shuffled normalization")
        private_bundle, private_assignment = _copy(bundle), list(reversed(_copy(assignment)))
        before_bundle, before_assignment = _copy(private_bundle), _copy(private_assignment)
        reversed_result = self.decode(private_bundle, private_assignment)
        expected_result = self.oracle.tableau_decode_assignment(private_bundle, private_assignment)
        self.oracle._same(reversed_result, expected_result, "arbitrary order full inverse")
        self.oracle._same(private_bundle, before_bundle, "inverse bundle unmutated")
        self.oracle._same(private_assignment, before_assignment, "inverse assignment unmutated")
        private_assignment[0][2] = "POISON"
        private_bundle["spec"]["initial"][1] = "POISON"
        private_bundle["spec"]["final"][1] = "POISON"
        private_bundle.clear()
        self.oracle._same(reversed_result, expected_result, "detached production inverse output")
        return {"spec_cases": bad_specs, "assignment_cases": bad_assignments, "bundle_cases": bad_bundles,
                "valid_shuffled_table": {"input": before, "bundle": normalized_bundle, "exact_normalization": True},
                "valid_reversed_assignment": {"input": before_assignment, "canonical_bundle_control": primary["id"],
                                              "production": reversed_result, "independent": expected_result,
                                              "input_unchanged_and_output_detached": True}}


def _qualification(engine, compiler, oracle, began):
    _need(engine.VERSION == "GCTS-FINITE-POINT-ENGINE-v1" and
          compiler.VERSION == "GCTS-SUPPLIED-LOCAL-TABLE-TABLEAU-v1" and
          oracle.VERSION == "GCTS-finite-point-independent-v2" and
          oracle.TABLEAU_VERSION == "GCTS-FINITE-TABLEAU-INDEPENDENT-v1", "exact role API versions")
    run = _Run(engine, compiler, oracle, began)
    for descriptor in _controls():
        run.control(descriptor)
    malformed = run.malformed()
    results = [c["solve_result"] for c in run.controls]
    counts = {"engine_instances": len(run.controls), "solve_calls": len(results),
              "positive_returns": sum(r["status"] == "FINITE_EXACT_SOLUTION" for r in results),
              "finite_exhausted_returns": sum(r["status"] == "EXHAUSTED_FINITE_SEARCH" for r in results),
              "deliberate_unknown_returns": sum(r["status"] == "UNKNOWN" for r in results),
              "raw_history_examinations": run.history_examined, "compiler_calls": run.compiler_calls,
              "production_decode_calls": run.decode_calls,
              "malformed_spec_cases": len(malformed["spec_cases"]),
              "malformed_assignment_cases": len(malformed["assignment_cases"]),
              "malformed_bundle_cases": len(malformed["bundle_cases"]),
              "valid_shuffled_table_controls": 1, "valid_reversed_assignment_controls": 1,
              "accepted_history_records_including_repeats": sum(len(c["histories"]["accepted"]) for c in run.controls)}
    oracle._same(counts, EXPECTED_COUNTS, "complete frozen recipe census")
    rejection_totals = {key: sum(c["histories"]["rejections"][key] for c in run.controls)
                        for key in ("INITIAL", "FINAL", "TRANSITION")}
    rejection_totals["ACCEPTED"] = counts["accepted_history_records_including_repeats"]
    oracle._same(rejection_totals, EXPECTED_REJECTIONS, "complete independent history partition")
    run.budget()
    return run, counts, malformed, rejection_totals


def main():
    began = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--result", required=True)
    args = parser.parse_args()
    plan_path = _canonical_path(args.plan, "plan CLI", "file")
    result_path = _canonical_path(args.result, "result CLI", "newfile")
    plan, plan_pin = _authenticate(plan_path, result_path)
    oracle = _load(plan["sources"]["oracle"], "gcts_tableau_independent_pinned")
    compiler = _load(plan["sources"]["compiler"], "gcts_tableau_compiler_pinned")
    engine = _load(plan["sources"]["engine"], "gcts_tableau_engine_pinned")
    run, counts, malformed, rejections = _qualification(engine, compiler, oracle, began)
    run.budget()
    envelope = {"schema": RESULT_SCHEMA, "status": "FINITE_TABLEAU_QUALIFICATION_PASS",
                "scope": "FINITE_SUPPLIED_TABLE_TRACE_BRIDGE_ONLY",
                "sources": plan["sources"], "plan": plan_pin, "limits": plan["limits"],
                "costs": {"elapsed_seconds_before_serialization": time.monotonic() - began,
                          "self_lifetime_highwater_bytes_before_serialization": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                          "budget_callbacks_before_serialization": run.budget_calls,
                          "stable_audits": run.audit_count,
                          "history_rejection_partition": rejections,
                          "scope": "Whole worker compile/graph/search/full-audit/history/inverse/evidence lifetime; captures precede serialization/readback. Separate observer late maxima/tail allowance required."},
                "counts": counts, "controls": run.controls, "malformed": malformed,
                "limitations": ["Full98430 raw histories include repeated contexts, not unique problems; no2**660 point-subset enumeration.",
                                "All33 types admitted at every cell before ordinary literal point legality; no known-trace or row scheduler shortlist.",
                                "AllQ root0/ordinary gen1; tableau time is not growth generation. No infinite-growth/fairness claim.",
                                "Supplied deterministic table/singleton words only; no FOL verifier, open certificate choices, logical proof-line extraction or universal palette.",
                                "No learned markings/RL/clusters/discovery/advantage or completion of the broader goal.",
                                "A complete expected-history witness never changes a deliberately UNKNOWN engine return into a returned engine proof.",
                                "Own time/RSS checks are cooperative. Observer lifetime child+self maxima+16MiB allowance is not a simultaneous/process-tree peak/hardRSS cap; outer tail unmeasured."]}
    _need(len(envelope) == 11, "result exact11 envelope")
    raw = json.dumps(envelope, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()+b"\n"
    _need(len(raw) <= LIMITS["result_bytes"], "complete64MiB result cap; no truncation")
    run.budget()
    for pin in plan["sources"].values():
        _check_pin(pin)
    _check_pin(PYTHON)
    _need(_read_json(plan_path)[1] == plan_pin, "whole plan postguard")
    with result_path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    run.budget()
    with result_path.open("rb") as stream:
        saved = stream.read(LIMITS["result_bytes"] + 1)
    _need(saved == raw, "complete bounded result readback")
    run.budget()
    print(json.dumps({"schema": "GCTS-finite-tableau-worker-terminal-v1", "status": envelope["status"],
                      "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"schema": "GCTS-finite-tableau-worker-error-v1", "type": type(error).__name__,
                          "error": str(error), "normal_result_admitted": False}), file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        raise SystemExit(2)
