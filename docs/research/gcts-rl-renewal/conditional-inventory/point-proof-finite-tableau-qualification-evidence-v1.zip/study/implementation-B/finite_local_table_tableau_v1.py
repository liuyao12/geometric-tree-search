"""Inert supplied-local-table compiler and complete Wang-assignment inverse.

No project import, IO, CLI, cache or top-level scientific work.  Calling these
definitions requires the separate reviewed runtime workflow.  Configuration
time is a tableau coordinate, not point-engine generation or placement order.
"""


VERSION = "GCTS-SUPPLIED-LOCAL-TABLE-TABLEAU-v1"
SPEC_SCHEMA = "GCTS-supplied-local-table-spec-v1"
BUNDLE_SCHEMA = "GCTS-supplied-local-table-tableau-v1"
TRACE_SCHEMA = "GCTS-supplied-local-table-trace-v1"
_ALPHABET = ("#", "0", "1")
_SPEC_KEYS = ("schema", "alphabet", "transitions", "width", "steps", "initial", "final")
_BUNDLE_KEYS = ("schema", "spec", "palette", "region", "boundary")


class TableauError(ValueError):
    """A rejected input; raised with one exact public error-code string."""


def _need(condition, code):
    if not condition:
        raise TableauError(code)


def _keys(value, expected):
    return (type(value) is dict and len(value) == len(expected)
            and all(type(key) is str for key in value)
            and set(value) == set(expected))


def _same_exact(actual, expected):
    """Mapping order is immaterial; value/container types and list order are not."""
    if type(actual) is not type(expected):
        return False
    if type(expected) is dict:
        return (_keys(actual, tuple(expected))
                and all(_same_exact(actual[key], expected[key]) for key in expected))
    if type(expected) is list:
        return (len(actual) == len(expected)
                and all(_same_exact(a, b) for a, b in zip(actual, expected)))
    return actual == expected


def _normalize_spec(spec):
    """Validate in the fixed public precedence and detach every mutable value."""
    _need(_keys(spec, _SPEC_KEYS), "SPEC_SCHEMA")
    _need(type(spec["schema"]) is str and spec["schema"] == SPEC_SCHEMA, "SPEC_SCHEMA")
    alphabet = spec["alphabet"]
    _need(type(alphabet) is list and len(alphabet) == 3
          and all(type(s) is str for s in alphabet)
          and alphabet == list(_ALPHABET), "SPEC_ALPHABET")
    transitions = spec["transitions"]
    _need(type(transitions) is list and len(transitions) == 27, "SPEC_TRANSITIONS")
    rule = {}
    for row in transitions:
        _need(type(row) is list and len(row) == 4
              and all(type(s) is str and s in _ALPHABET for s in row), "SPEC_TRANSITIONS")
        triple = tuple(row[:3])
        _need(triple not in rule, "SPEC_TRANSITIONS")
        _need(row[1] != "#" or row[3] == "#", "SPEC_TRANSITIONS")
        rule[triple] = row[3]
    # Twenty-seven distinct triples from a three-symbol cube exhaust that cube.
    canonical_transitions = [[a, b, c, rule[(a, b, c)]]
                             for a in _ALPHABET for b in _ALPHABET for c in _ALPHABET]
    width, steps = spec["width"], spec["steps"]
    _need(type(width) is int and 3 <= width <= 5
          and type(steps) is int and 0 <= steps <= 2, "SPEC_DIMENSIONS")
    for key in ("initial", "final"):
        word = spec[key]
        _need(type(word) is list and len(word) == width
              and all(type(s) is str and s in _ALPHABET for s in word)
              and word[0] == word[-1] == "#", "SPEC_WORDS")
    return {"schema": SPEC_SCHEMA, "alphabet": list(_ALPHABET),
            "transitions": canonical_transitions, "width": width, "steps": steps,
            "initial": list(spec["initial"]), "final": list(spec["final"])}


def _state(symbol):
    return "S:" + symbol


def _pair(left, right):
    return "P:" + left + ":" + right


def _computation_id(left, center, right):
    return "C:" + left + ":" + center + ":" + right


def _compile_normalized(spec):
    """Build the entire canonical palette and rectangle, without a shortlist."""
    palette = []
    for left, center, right, output in spec["transitions"]:
        palette.append({"id": _computation_id(left, center, right),
                        "N": _state(center), "E": _pair(center, right),
                        "S": _state(output), "W": _pair(left, center)})
    for symbol in _ALPHABET:
        palette.append({"id": "I:" + symbol, "N": "I:" + symbol,
                        "E": "ROW:TOP", "S": _state(symbol), "W": "ROW:TOP"})
    for symbol in _ALPHABET:
        palette.append({"id": "O:" + symbol, "N": _state(symbol),
                        "E": "ROW:BOT", "S": "O:" + symbol, "W": "ROW:BOT"})
    width, last = spec["width"], spec["steps"] + 1
    region = [[i, j] for j in range(last + 1) for i in range(width)]
    boundary = [[i, 0, "N", "I:" + spec["initial"][i]] for i in range(width)]
    boundary.extend([[i, last, "S", "O:" + spec["final"][i]] for i in range(width)])
    for j in range(last + 1):
        lateral = "ROW:TOP" if j == 0 else "ROW:BOT" if j == last else "P:#:#"
        boundary.append([0, j, "W", lateral])
        boundary.append([width - 1, j, "E", lateral])
    return {"schema": BUNDLE_SCHEMA, "spec": spec, "palette": palette,
            "region": region, "boundary": boundary}


def compile_tableau(spec):
    """Return detached canonical data; a wellformed impossible boundary compiles."""
    return _compile_normalized(_normalize_spec(spec))


def _canonical_bundle(bundle):
    """Map every malformed or noncanonical bundle to the single public code."""
    try:
        _need(_keys(bundle, _BUNDLE_KEYS), "BUNDLE_CANONICAL")
        _need(type(bundle["schema"]) is str and bundle["schema"] == BUNDLE_SCHEMA,
              "BUNDLE_CANONICAL")
        expected = _compile_normalized(_normalize_spec(bundle["spec"]))
    except TableauError:
        raise TableauError("BUNDLE_CANONICAL") from None
    _need(_same_exact(bundle, expected), "BUNDLE_CANONICAL")
    return expected


def _assignment_grid(assignment, palette, region, width, last):
    """Admit exactly one typed labeled placement per declared cell."""
    _need(type(assignment) is list and len(assignment) == len(region), "ASSIGNMENT")
    grid = {}
    for row in assignment:
        _need(type(row) is list and len(row) == 3, "ASSIGNMENT")
        x, y, identity = row
        _need(type(x) is int and type(y) is int and type(identity) is str,
              "ASSIGNMENT")
        _need(0 <= x < width and 0 <= y <= last and identity in palette,
              "ASSIGNMENT")
        _need((x, y) not in grid, "ASSIGNMENT")
        grid[(x, y)] = identity
    _need(set(grid) == {tuple(point) for point in region}, "ASSIGNMENT")
    return grid


def _check_colors(grid, palette, boundary, width, last):
    """Check every adjacency once and every exposed color explicitly."""
    for y in range(last + 1):
        for x in range(width):
            tile = palette[grid[(x, y)]]
            if x + 1 < width:
                _need(tile["E"] == palette[grid[(x + 1, y)]]["W"], "ASSIGNMENT")
            if y + 1 <= last:
                _need(tile["S"] == palette[grid[(x, y + 1)]]["N"], "ASSIGNMENT")
    for x, y, direction, color in boundary:
        _need(palette[grid[(x, y)]][direction] == color, "ASSIGNMENT")


def decode_tableau(bundle, assignment):
    """Validate the entire canonical Wang assignment and recover all time rows.

    This production inverse uses its own compiler reconstruction.  It is not
    the independent raw point/Wang/history qualification oracle.
    """
    canonical = _canonical_bundle(bundle)
    spec = canonical["spec"]
    width, steps, last = spec["width"], spec["steps"], spec["steps"] + 1
    palette = {row["id"]: row for row in canonical["palette"]}
    grid = _assignment_grid(assignment, palette, canonical["region"], width, last)
    triples = {_computation_id(a, b, c): (a, b, c) for a, b, c, unused in spec["transitions"]}
    rule = {(a, b, c): output for a, b, c, output in spec["transitions"]}
    input_caps = {"I:" + s: s for s in _ALPHABET}
    output_caps = {"O:" + s: s for s in _ALPHABET}
    for x, y in canonical["region"]:
        allowed = input_caps if y == 0 else output_caps if y == last else triples
        _need(grid[(x, y)] in allowed, "ASSIGNMENT")
    _check_colors(grid, palette, canonical["boundary"], width, last)
    rows = [[input_caps[grid[(x, 0)]] for x in range(width)]]
    _need(rows[0] == spec["initial"], "ASSIGNMENT")
    for t in range(steps):
        row_triples = [triples[grid[(x, t + 1)]] for x in range(width)]
        centers = [triple[1] for triple in row_triples]
        _need(centers == rows[-1] and centers[0] == centers[-1] == "#", "ASSIGNMENT")
        next_row = []
        for x, (left, center, right) in enumerate(row_triples):
            expected_left = "#" if x == 0 else centers[x - 1]
            expected_right = "#" if x + 1 == width else centers[x + 1]
            _need(left == expected_left and right == expected_right, "ASSIGNMENT")
            output = rule[(left, center, right)]
            tile = palette[grid[(x, t + 1)]]
            _need(tile["N"] == _state(center) and tile["S"] == _state(output), "ASSIGNMENT")
            next_row.append(output)
        _need(next_row[0] == next_row[-1] == "#", "ASSIGNMENT")
        rows.append(next_row)
    final_word = [output_caps[grid[(x, last)]] for x in range(width)]
    _need(rows[-1] == final_word == spec["final"], "ASSIGNMENT")
    return {"schema": TRACE_SCHEMA, "rows": rows,
            "assignment": [[x, y, grid[(x, y)]] for x, y in canonical["region"]]}
