"""INERT generic proof-cluster proposals; every instance needs the fixed kernels.

Inputs are theory/goal and caller-bound certificates discovered earlier. No
target-specific proof body or successful byte sequence occurs in this Source.
This is a proposal generator, not a theorem checker or complete proof search.
"""
import itertools
import json

VERSION = 'R-GENERIC-PROOF-FAMILY-PROPOSALS-v1'
LIMIT_KEYS = ('max_operations', 'max_depth', 'max_proof_lines',
              'max_candidates', 'max_rewrite_nodes', 'max_rewrite_steps',
              'max_universal_instances', 'max_generated_lemmas',
              'max_bridge_tests', 'max_bridge_premises')


class ProposalInputError(Exception):
    pass


class ProposalBudgetExceeded(Exception):
    pass


class Context:
    def __init__(self, limits, budget):
        if type(limits) is not dict or set(limits) != set(LIMIT_KEYS):
            raise ProposalInputError('exact limits')
        if any(type(v) is not int or v < 0 for v in limits.values()):
            raise ProposalInputError('nonnegative integer limits')
        if limits['max_bridge_premises'] > 2:
            raise ProposalInputError('bridge profile supports at most two premises')
        if budget is not None and not callable(budget):
            raise ProposalInputError('budget callback')
        self.limits = dict(limits)
        self.budget = budget
        self.counts = {'operations': 0, 'candidates': 0, 'rewrite_nodes': 0,
                       'universal_instances': 0, 'generated_lemmas': 0,
                       'bridge_tests': 0, 'callbacks': 0}
        self.seen_proofs = set()

    def tick(self, amount=1):
        proposed = self.counts['operations'] + amount
        if proposed > self.limits['max_operations']:
            raise ProposalBudgetExceeded('operations')
        self.counts['operations'] = proposed
        if self.budget is not None:
            self.counts['callbacks'] += 1
            self.budget()

    def reserve(self, name):
        self.tick()
        if self.counts[name] >= self.limits['max_' + name]:
            raise ProposalBudgetExceeded(name)
        self.counts[name] += 1

    def clone(self, value, depth=0, active=None):
        self.tick()
        if depth > self.limits['max_depth']:
            raise ProposalBudgetExceeded('depth')
        if type(value) is str:
            self.tick(len(value))
            return value
        if type(value) in (int, bool) or value is None:
            return value
        if type(value) not in (list, dict):
            raise ProposalInputError('native JSON value')
        active = set() if active is None else active
        if id(value) in active:
            raise ProposalInputError('cyclic input')
        active.add(id(value))
        self.tick(len(value))
        try:
            if type(value) is list:
                return [self.clone(v, depth + 1, active) for v in value]
            if any(type(k) is not str for k in value):
                raise ProposalInputError('native string keys')
            return {k: self.clone(v, depth + 1, active) for k, v in value.items()}
        finally:
            active.remove(id(value))


def key(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def is_term(value):
    return type(value) is list and bool(value) and value[0] in ('var', 'fun')


def is_formula(value):
    return type(value) is list and bool(value) and value[0] in ('bot', 'eq', 'pred', 'not', 'and', 'or', 'imp', 'all')


def term_vars(term, ctx):
    ctx.tick()
    if term[0] == 'var':
        return {term[1]}
    result = set()
    for child in term[2]:
        result.update(term_vars(child, ctx))
    return result


def free_vars(formula, ctx):
    ctx.tick()
    tag = formula[0]
    if tag == 'bot':
        return set()
    if tag == 'eq':
        return term_vars(formula[1], ctx) | term_vars(formula[2], ctx)
    if tag == 'pred':
        result = set()
        for term in formula[2]:
            result.update(term_vars(term, ctx))
        return result
    if tag == 'not':
        return free_vars(formula[1], ctx)
    if tag == 'all':
        return free_vars(formula[2], ctx) - {formula[1]}
    return free_vars(formula[1], ctx) | free_vars(formula[2], ctx)


def all_variable_names(value, ctx):
    ctx.tick()
    result = set()
    if type(value) is list:
        if value and value[0] in ('var', 'all'):
            result.add(value[1])
        for child in value:
            result.update(all_variable_names(child, ctx))
    elif type(value) is dict:
        for child in value.values():
            result.update(all_variable_names(child, ctx))
    return result


def fresh_name(used, ctx):
    index = 0
    while True:
        ctx.tick()
        name = 'fresh' + str(index)
        if name not in used:
            return name
        index += 1


def subst_term(term, variable, replacement, ctx):
    ctx.tick()
    if term[0] == 'var':
        return ctx.clone(replacement if term[1] == variable else term)
    return ['fun', term[1], [subst_term(t, variable, replacement, ctx) for t in term[2]]]


def subst_formula(formula, variable, replacement, ctx):
    ctx.tick()
    tag = formula[0]
    if tag == 'bot':
        return ['bot']
    if tag == 'eq':
        return ['eq', subst_term(formula[1], variable, replacement, ctx), subst_term(formula[2], variable, replacement, ctx)]
    if tag == 'pred':
        return ['pred', formula[1], [subst_term(t, variable, replacement, ctx) for t in formula[2]]]
    if tag == 'not':
        return ['not', subst_formula(formula[1], variable, replacement, ctx)]
    if tag == 'all':
        binder, body = formula[1:]
        if binder == variable:
            return ctx.clone(formula)
        if binder in term_vars(replacement, ctx) and variable in free_vars(body, ctx):
            used = all_variable_names(formula, ctx) | term_vars(replacement, ctx) | {variable}
            renamed = fresh_name(used, ctx)
            body = subst_formula(body, binder, ['var', renamed], ctx)
            binder = renamed
        return ['all', binder, subst_formula(body, variable, replacement, ctx)]
    return [tag, subst_formula(formula[1], variable, replacement, ctx), subst_formula(formula[2], variable, replacement, ctx)]


def simultaneous_term(term, mapping, ctx):
    ctx.tick()
    if term[0] == 'var':
        return ctx.clone(mapping.get(term[1], term))
    return ['fun', term[1], [simultaneous_term(t, mapping, ctx) for t in term[2]]]


def simultaneous_formula(formula, mapping, ctx):
    ctx.tick()
    tag = formula[0]
    if tag == 'bot':
        return ['bot']
    if tag == 'eq':
        return ['eq', simultaneous_term(formula[1], mapping, ctx), simultaneous_term(formula[2], mapping, ctx)]
    if tag == 'pred':
        return ['pred', formula[1], [simultaneous_term(t, mapping, ctx) for t in formula[2]]]
    if tag == 'not':
        return ['not', simultaneous_formula(formula[1], mapping, ctx)]
    if tag == 'all':
        binder, body = formula[1:]
        remaining = {k: v for k, v in mapping.items() if k != binder}
        relevant = free_vars(body, ctx) & set(remaining)
        replacement_vars = set()
        for variable in relevant:
            replacement_vars.update(term_vars(remaining[variable], ctx))
        if binder in replacement_vars:
            used = all_variable_names(formula, ctx) | replacement_vars | set(remaining)
            renamed = fresh_name(used, ctx)
            body = subst_formula(body, binder, ['var', renamed], ctx)
            binder = renamed
        return ['all', binder, simultaneous_formula(body, remaining, ctx)]
    return [tag, simultaneous_formula(formula[1], mapping, ctx), simultaneous_formula(formula[2], mapping, ctx)]


def term_catalog(formula, ctx):
    terms = {}
    def visit(value):
        ctx.tick()
        if is_term(value):
            terms.setdefault(key(value), ctx.clone(value))
        if type(value) is list:
            for child in value:
                visit(child)
    visit(formula)
    return [terms[k] for k in sorted(terms)]


def strip_all(formula, ctx):
    variables = []
    while formula[0] == 'all':
        ctx.tick()
        variables.append(formula[1])
        formula = formula[2]
    return variables, formula


class ProofBuilder:
    def __init__(self, ctx):
        self.ctx = ctx
        self.lines = []

    def add(self, rule, formula, **fields):
        self.ctx.tick()
        if len(self.lines) >= self.ctx.limits['max_proof_lines']:
            raise ProposalBudgetExceeded('proof lines')
        line = {'rule': rule, 'formula': self.ctx.clone(formula)}
        for name, value in fields.items():
            line[name] = self.ctx.clone(value)
        self.lines.append(line)
        return len(self.lines) - 1

    def import_lines(self, lines):
        offset = len(self.lines)
        for original in lines:
            line = self.ctx.clone(original)
            if line['rule'] == 'mp':
                line['antecedent'] += offset
                line['implication'] += offset
            elif line['rule'] == 'generalize':
                line['source'] += offset
            formula, rule = line.pop('formula'), line.pop('rule')
            self.add(rule, formula, **line)
        return len(self.lines) - 1

    def instantiate_axiom(self, name, formula, mapping):
        source = self.add('axiom', formula, name=name)
        current = formula
        original_variables, _ = strip_all(formula, self.ctx)
        for original_variable in original_variables:
            variable, body = current[1:]
            if original_variable not in mapping:
                raise ProposalInputError('complete axiom instantiation mapping')
            term = mapping[original_variable]
            instance = subst_formula(body, variable, term, self.ctx)
            schema = self.add('instantiate', ['imp', current, instance], universal=current, term=term)
            source = self.add('mp', instance, antecedent=source, implication=schema)
            current = instance
        return source

    def generalize(self, variables):
        for variable in reversed(variables):
            previous = len(self.lines) - 1
            self.add('generalize', ['all', variable, self.lines[previous]['formula']], source=previous, variable=variable)


def candidate(builder, goal, origin, parents, details):
    ctx = builder.ctx
    if not builder.lines or builder.lines[-1]['formula'] != goal:
        return None
    identity = key(builder.lines)
    if identity in ctx.seen_proofs:
        return None
    ctx.reserve('candidates')
    ctx.seen_proofs.add(identity)
    return {'origin': origin, 'proof': ctx.clone(builder.lines), 'target': ctx.clone(goal),
            'parents': ctx.clone(parents), 'details': ctx.clone(details),
            'counts_at_proposal': dict(ctx.counts), 'status': 'UNVERIFIED_PROPOSAL'}


def match_term(pattern, actual, variables, mapping, ctx):
    ctx.tick()
    if pattern[0] == 'var' and pattern[1] in variables:
        name = pattern[1]
        if name in mapping:
            return mapping[name] == actual
        mapping[name] = ctx.clone(actual)
        return True
    if pattern[0] != actual[0] or pattern[1] != actual[1]:
        return False
    if pattern[0] == 'var':
        return True
    return len(pattern[2]) == len(actual[2]) and all(match_term(p, a, variables, mapping, ctx) for p, a in zip(pattern[2], actual[2]))


def match_formula(pattern, actual, variables, mapping, ctx):
    ctx.tick()
    if pattern[0] != actual[0]:
        return False
    tag = pattern[0]
    if tag == 'bot':
        return True
    if tag == 'eq':
        return match_term(pattern[1], actual[1], variables, mapping, ctx) and match_term(pattern[2], actual[2], variables, mapping, ctx)
    if tag == 'pred':
        return pattern[1] == actual[1] and len(pattern[2]) == len(actual[2]) and all(match_term(p, a, variables, mapping, ctx) for p, a in zip(pattern[2], actual[2]))
    if tag == 'not':
        return match_formula(pattern[1], actual[1], variables, mapping, ctx)
    if tag == 'all':
        return pattern[1] == actual[1] and match_formula(pattern[2], actual[2], variables - {pattern[1]}, mapping, ctx)
    return match_formula(pattern[1], actual[1], variables, mapping, ctx) and match_formula(pattern[2], actual[2], variables, mapping, ctx)


def instantiate_inventory(entry, body, ctx):
    mapping = {}
    variables = free_vars(entry['formula'], ctx)
    if not match_formula(entry['formula'], body, variables, mapping, ctx):
        return None, None
    lines = ctx.clone(entry['proof'])
    # Proposal transformation only: local schema side conditions are rechecked
    # by the actual native and independent kernels for every produced instance.
    for line in lines:
        for field, value in list(line.items()):
            if is_formula(value):
                line[field] = simultaneous_formula(value, mapping, ctx)
            elif is_term(value):
                line[field] = simultaneous_term(value, mapping, ctx)
    return lines, mapping


def subterms(term, ctx, path=()):
    ctx.tick()
    yield path, term
    if term[0] == 'fun':
        for index, child in enumerate(term[2]):
            yield from subterms(child, ctx, path + (index,))


def replace_term(term, path, replacement, ctx):
    ctx.tick()
    if not path:
        return ctx.clone(replacement)
    children = ctx.clone(term[2])
    children[path[0]] = replace_term(children[path[0]], path[1:], replacement, ctx)
    return ['fun', term[1], children]


def find_rewrite(theory, body, ctx):
    if body[0] != 'eq':
        return None
    rules = []
    for name, axiom in sorted(theory['axioms'].items()):
        variables, matrix = strip_all(axiom, ctx)
        if matrix[0] == 'eq':
            rules.append((name, axiom, variables, matrix))
    start, target = body[1:]
    queue = [(ctx.clone(start), [])]
    seen = {key(start)}
    cursor = 0
    ctx.reserve('rewrite_nodes')
    while cursor < len(queue):
        term, history = queue[cursor]
        cursor += 1
        if term == target:
            return history
        if len(history) >= ctx.limits['max_rewrite_steps']:
            continue
        for path, redex in subterms(term, ctx):
            for name, axiom, variables, matrix in rules:
                mapping = {}
                if not match_term(matrix[1], redex, set(variables), mapping, ctx) or any(v not in mapping for v in variables):
                    continue
                rhs = simultaneous_term(matrix[2], mapping, ctx)
                updated = replace_term(term, path, rhs, ctx)
                identity = key(updated)
                if identity in seen:
                    continue
                ctx.reserve('rewrite_nodes')
                seen.add(identity)
                step = {'axiom': name, 'formula': ctx.clone(axiom), 'mapping': ctx.clone(mapping),
                        'path': list(path), 'before': ctx.clone(term), 'redex': ctx.clone(redex),
                        'replacement': rhs, 'after': updated}
                ctx.tick(len(history) + 1)
                queue.append((updated, history + [step]))
    return None


def rewrite_proof(theory, body, history, ctx):
    builder = ProofBuilder(ctx)
    original = body[1]
    accumulated = None
    used = all_variable_names(body, ctx) | all_variable_names(theory['axioms'], ctx)
    variable = fresh_name(used, ctx)
    for step in history:
        source = builder.instantiate_axiom(step['axiom'], step['formula'], step['mapping'])
        before, after = step['before'], step['after']
        if step['path']:
            context = replace_term(before, tuple(step['path']), ['var', variable], ctx)
            template = ['eq', before, context]
            left, right = step['redex'], step['replacement']
            reflection = builder.add('refl', ['eq', before, before])
            schema_formula = ['imp', ['eq', left, right], ['imp', ['eq', before, before], ['eq', before, after]]]
            schema = builder.add('eq_subst', schema_formula, variable=variable, template=template, left=left, right=right)
            implication = builder.add('mp', ['imp', ['eq', before, before], ['eq', before, after]], antecedent=source, implication=schema)
            source = builder.add('mp', ['eq', before, after], antecedent=reflection, implication=implication)
        if accumulated is None:
            accumulated = source
        else:
            template = ['eq', original, ['var', variable]]
            left, right = before, after
            antecedent = ['eq', original, before]
            conclusion = ['eq', original, after]
            schema_formula = ['imp', ['eq', left, right], ['imp', antecedent, conclusion]]
            schema = builder.add('eq_subst', schema_formula, variable=variable, template=template, left=left, right=right)
            implication = builder.add('mp', ['imp', antecedent, conclusion], antecedent=source, implication=schema)
            accumulated = builder.add('mp', conclusion, antecedent=accumulated, implication=implication)
    if accumulated is None:
        builder.add('refl', body)
    return builder


def schema_lemmas(theory, body, ctx):
    terms = term_catalog(body, ctx)
    # Ground/free instances of arbitrary given universal axioms. Variable-name
    # agreement is an ordering preference, never a restriction on the catalog.
    for name, axiom in sorted(theory['axioms'].items()):
        variables, matrix = strip_all(axiom, ctx)
        choices = []
        for variable in variables:
            preferred = ['var', variable]
            ctx.tick(len(terms))
            choices.append(sorted(terms, key=lambda t: (t != preferred, key(t))))
        ctx.tick(sum(len(values) for values in choices))
        combinations = itertools.product(*choices) if variables else [()]
        for values in combinations:
            ctx.reserve('universal_instances')
            builder = ProofBuilder(ctx)
            builder.instantiate_axiom(name, axiom, dict(zip(variables, values)))
            yield 'UNIVERSAL_AXIOM_INSTANCE', builder
    for term in terms:
        builder = ProofBuilder(ctx)
        builder.add('refl', ['eq', term, term])
        yield 'REFLEXIVITY_SCHEMA', builder
    used = all_variable_names(body, ctx)
    variable = fresh_name(used, ctx)
    template_terms = terms + [['var', variable]]
    # All atomic equality templates over the bounded goal-term catalog. There
    # is no branch for equality symmetry or any other named target theorem.
    ctx.tick(2 * len(template_terms) + 2 * len(terms))
    for first, second, left, right in itertools.product(template_terms, template_terms, terms, terms):
        ctx.tick()
        template = ['eq', first, second]
        if variable not in free_vars(template, ctx):
            continue
        premise = subst_formula(template, variable, left, ctx)
        conclusion = subst_formula(template, variable, right, ctx)
        formula = ['imp', ['eq', left, right], ['imp', premise, conclusion]]
        builder = ProofBuilder(ctx)
        builder.add('eq_subst', formula, variable=variable, template=template, left=left, right=right)
        yield 'ATOMIC_EQUALITY_SUBSTITUTION_SCHEMA', builder


def propose(theory, goal, inventory, limits, *, tautology_test=None, budget=None):
    """Yield UNVERIFIED_PROPOSAL records; caller checks actual bytes/kernels.

    tautology_test receives only a candidate formula and returns exactly
    VERIFIED, REJECTED or UNKNOWN_BUDGET. Its costs belong to the generator.
    Limits/catalog exhaustion never establishes mathematical unprovability.
    """
    ctx = Context(limits, budget)
    theory, goal, inventory = ctx.clone(theory), ctx.clone(goal), ctx.clone(inventory)
    if type(theory) is not dict or type(theory.get('axioms')) is not dict or type(inventory) is not list or not is_formula(goal):
        raise ProposalInputError('caller-bound theory/goal/inventory shape')
    variables, body = strip_all(goal, ctx)
    for entry in inventory:
        lines, mapping = instantiate_inventory(entry, body, ctx)
        if lines is None:
            continue
        builder = ProofBuilder(ctx)
        builder.import_lines(lines)
        builder.generalize(variables)
        record = candidate(builder, goal, 'INVENTORY_INSTANCE_GENERALIZATION', [entry['id']], {'term_mapping': mapping, 'variables': variables})
        if record is not None:
            yield record
    history = find_rewrite(theory, body, ctx)
    if history is not None:
        builder = rewrite_proof(theory, body, history, ctx)
        builder.generalize(variables)
        record = candidate(builder, goal, 'EQUATIONAL_REWRITE_SEARCH', [], {'rewrite_path': history, 'variables': variables})
        if record is not None:
            yield record
    pool, seen_formulas = [], set()
    sources = []
    for entry in inventory:
        builder = ProofBuilder(ctx)
        builder.import_lines(entry['proof'])
        sources.append(('FOUND_INVENTORY', builder))
    for origin, builder in itertools.chain(sources, schema_lemmas(theory, body, ctx)):
        formula = builder.lines[-1]['formula']
        identity = key(formula)
        if identity in seen_formulas:
            continue
        ctx.reserve('generated_lemmas')
        seen_formulas.add(identity)
        current = (origin, builder)
        pool.append(current)
        if formula == body:
            direct = ProofBuilder(ctx)
            direct.import_lines(builder.lines)
            direct.generalize(variables)
            record = candidate(direct, goal, 'RULE_INSTANCE_SEARCH', [], {'schema_origin': origin})
            if record is not None:
                yield record
        if tautology_test is None:
            continue
        for count in range(1, min(2, ctx.limits['max_bridge_premises']) + 1):
            # The newly added lemma must participate; old combinations were
            # considered at earlier additions. Ordering remains deterministic.
            ctx.tick(len(pool))
            tuples = [(current,)] if count == 1 else [(older, current) for older in pool[:-1]]
            for selected in tuples:
                bridge = ctx.clone(body)
                for _, proof in reversed(selected):
                    bridge = ['imp', proof.lines[-1]['formula'], bridge]
                ctx.reserve('bridge_tests')
                verdict = tautology_test(ctx.clone(bridge))
                if verdict not in ('VERIFIED', 'REJECTED', 'UNKNOWN_BUDGET'):
                    raise ProposalInputError('tautology callback exact status')
                if verdict != 'VERIFIED':
                    continue
                combined = ProofBuilder(ctx)
                premises = [combined.import_lines(proof.lines) for _, proof in selected]
                implication = combined.add('tautology', bridge)
                remainder = bridge
                for premise in premises:
                    remainder = remainder[2]
                    implication = combined.add('mp', remainder, antecedent=premise, implication=implication)
                combined.generalize(variables)
                record = candidate(combined, goal, 'PROPOSITIONAL_CLOSURE_SEARCH', [], {'premise_origins': [o for o, _ in selected], 'bridge': bridge})
                if record is not None:
                    yield record
