"""Inert closed tiny qualification; supplied producer objects only, no IO/main.

Literal row enumeration uses the NEW one-step colour wire. The retained old
CHOOSE/EXEC/T row module is incompatible and is never called. No proof fixtures.
"""
import hashlib
import itertools
import json
import time

VERSION = 'R-POINT-AND-COMPACT-QUALIFICATION-v1'
Q_OPERATIONS = 20000000
Q_SECONDS = 120
POINT_LIMITS = {'max_operations': 20000000, 'max_seconds': 30, 'max_points': 16,
                'max_groups': 32, 'max_variants': 65536, 'max_mark_entries': 4096,
                'max_trail_entries': 8192, 'max_nodes': 10000,
                'max_trace_events': 20000, 'max_name_bytes': 1024,
                'max_integer_bits': 64, 'max_model_bytes': 8388608}
COMPACT_LIMITS = {'max_operations': 20000000, 'max_tiles': 128}
NTM_LIMITS = {'max_operations': 20000000, 'max_configurations': 10000}
EXPECTED_CALLS = {'engine.solve': 77, 'engine.make_byte_model': 50,
                  'compact.compile_palette': 12, 'ntm.simulate': 32}


class QualificationFailure(Exception):
    pass


class QualificationBudgetExceeded(Exception):
    pass


class _Foreign(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise QualificationFailure(message)


def _wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _equal(a, b, message):
    _need(_wire(a) == _wire(b), message)


def _copy(value):
    return json.loads(_wire(value))


class _Run:
    def __init__(self, emit):
        _need(callable(emit), 'emit callable')
        self.emit_callback = emit
        self.started = time.monotonic()
        self.operations = 0
        self.calls = {k: 0 for k in EXPECTED_CALLS}
        self.names = set()
        self.records = []

    def tick(self, amount=1):
        if self.operations + amount > Q_OPERATIONS:
            raise QualificationBudgetExceeded('qualification logical-work ceiling')
        if time.monotonic() - self.started > Q_SECONDS:
            raise QualificationBudgetExceeded('qualification cooperative main-entry wall ceiling')
        self.operations += amount

    def call(self, name, function, *args, **kwargs):
        self.tick()
        _need(name in self.calls, 'closed public call name')
        self.calls[name] += 1
        answer = function(*args, **kwargs)
        self.tick()
        return answer

    def emit(self, name, record):
        self.tick()
        _need(type(name) is str and name and name[0].isalnum()
              and name.isascii() and all(c.isalnum() or c in '.-' for c in name), 'safe name')
        _need(name not in self.names and len(self.records) < 123, 'unique closed record count')
        raw = _wire(record)
        self.tick(len(raw) + 2)
        digest = hashlib.sha256(raw).hexdigest()
        result = self.emit_callback(name, record)
        self.tick()
        _need(hashlib.sha256(_wire(record)).hexdigest() == digest, 'emit did not mutate full record')
        self.names.add(name)
        self.records.append({'name': name, 'full_canonical_SHA256': digest,
                             'full_canonical_bytes': len(raw), 'emitter_return': result})


def _model(points, groups, fixed=None, version='qualification-unit-v1'):
    return {'schema': 'R-finite-singleton-mark-families-v1', 'version': version,
            'points': points, 'fixed_marks': [] if fixed is None else fixed, 'groups': groups}


def _explicit(name, anchor, variants):
    return {'id': name, 'kind': 'explicit', 'anchor': anchor, 'variants': variants}


def _expand(model, run):
    """Independent COMPLETE candidate expansion; no producer/domain helper."""
    _need(len(model['points']) <= 16 and len(model['groups']) <= 32, 'tiny model extent')
    points = sorted(tuple(p) for p in model['points'])
    fixed = {tuple(p): (v, 1) for p, v in model['fixed_marks']}
    groups = sorted(model['groups'], key=lambda g: g['id'])
    choices = {p: [] for p in points}
    all_candidates = {}
    bases = {}
    anchors = {}
    for g in groups:
        run.tick()
        gid, anchor = g['id'], tuple(g['anchor'])
        anchors[gid] = anchor
        if g['kind'] == 'byte':
            _need(type(g['allowed_mask']) is int and 0 <= g['allowed_mask'] < (1 << 256), 'byte mask')
            values = [v for v in range(256) if (g['allowed_mask'] >> v) & 1]
        else:
            _need(len(g['variants']) <= 65536, 'explicit tiny extent')
            values = range(len(g['variants']))
        run.tick(len(values))
        base = 0
        for v in values:
            rawmarks = [[g['mark_point'], v]] if g['kind'] == 'byte' else g['variants'][v]
            run.tick(1 + len(rawmarks))
            marks = tuple((tuple(p), value) for p, value in rawmarks)
            key = (gid, v)
            _need(key not in all_candidates, 'unique candidate')
            all_candidates[key] = (anchor, marks)
            choices[anchor].append((key, marks))
            base |= 1 << v
        bases[gid] = base
    return points, groups, fixed, choices, all_candidates, bases, anchors


def _merge(current, marks):
    changed = dict(current)
    for p, value in marks:
        if p in changed and changed[p][0] != value:
            return None
        changed[p] = (value, 1 if p not in changed else changed[p][1] + 1)
    return changed


def _brute(model, run):
    points, groups, fixed, choices, candidates, bases, anchors = _expand(model, run)
    solutions = []
    def visit(index, marks, selected):
        run.tick()
        if index == len(points):
            if len(solutions) >= 1024:
                raise QualificationBudgetExceeded('tiny complete brute solution cap')
            run.tick(len(selected) + 1)
            solutions.append([list(c) for c in sorted(selected)])
            return
        for candidate, additions in choices[points[index]]:
            run.tick(len(marks) + len(additions) + 1)
            merged = _merge(marks, additions)
            if merged is not None:
                visit(index + 1, merged, selected + [candidate])
    visit(0, fixed, [])
    return solutions


def _hex(value):
    _need(type(value) is str and value and all(c in '0123456789abcdef' for c in value), 'hex mask')
    result = int(value, 16)
    _need(format(result, 'x') == value, 'canonical hex mask')
    return result


def _check_state(model, state, run):
    _need(type(state) is dict and set(state) == {'schema', 'totals', 'markings', 'domains',
          'selected', 'excluded', 'frontier', 'forward_incidence', 'reverse_incidence'}, 'full state9')
    _need(state['schema'] == 'R-finite-unit-family-state-v1', 'state schema')
    points, groups, fixed, choices, candidates, bases, anchors = _expand(model, run)
    selected = [tuple(c) for c in state['selected']]
    _need(len(set(selected)) == len(selected), 'unique selected')
    marks, totals = dict(fixed), {p: 0 for p in points}
    for c in selected:
        run.tick()
        _need(c in candidates, 'selected full base identity')
        anchor, additions = candidates[c]
        totals[anchor] += 1
        _need(totals[anchor] == 1, 'unit capacity')
        marks = _merge(marks, additions)
        _need(marks is not None, 'selected exact marking agreement')
    excluded = {gid: _hex(mask) for gid, mask in state['excluded']}
    _need(set(excluded) == set(bases), 'full exclusions')
    domains = {gid: 0 for gid in bases}
    for gid in bases:
        _need(excluded[gid] & ~bases[gid] == 0, 'only represented exclusions')
    for c, (anchor, additions) in candidates.items():
        run.tick()
        gid, v = c
        if not totals[anchor] and not (excluded[gid] >> v) & 1 and _merge(marks, additions) is not None:
            domains[gid] |= 1 << v
    for gid, v in selected:
        _need(not (excluded[gid] >> v) & 1, 'selected candidate not excluded')
    degrees = {p: sum(domains[g['id']].bit_count() for g in groups if anchors[g['id']] == p)
               for p in points}
    expected = {'schema': 'R-finite-unit-family-state-v1',
                'totals': [[list(p), totals[p]] for p in points],
                'markings': [[list(p), v, n] for p, (v, n) in sorted(marks.items())],
                'domains': [[g['id'], format(domains[g['id']], 'x')] for g in groups],
                'selected': [list(c) for c in sorted(selected)],
                'excluded': [[g['id'], format(excluded[g['id']], 'x')] for g in groups],
                'frontier': [[list(p), 0, degrees[p]] for p in points if not totals[p]],
                'forward_incidence': [[list(p), [[g['id'], format(domains[g['id']], 'x')]
                     for g in groups if anchors[g['id']] == p and domains[g['id']]]]
                     for p in points if not totals[p]],
                'reverse_incidence': [[g['id'], list(anchors[g['id']]), format(domains[g['id']], 'x')]
                                      for g in groups]}
    _equal(state, expected, 'entire independently expanded state/graphs')
    return {'status': 'VERIFIED', 'selected_count': len(selected),
            'complete_candidates_examined': len(candidates), 'all_state9_fields_checked': True}


def _check_trace(result, run):
    trace = result['trace']
    events = trace['events']
    run.tick(len(events))
    raw = b''.join(_wire(e) for e in events)
    _need(len(events) == trace['retained_count'] and len(raw) == trace['retained_JSONL_bytes']
          and hashlib.sha256(raw).hexdigest() == trace['retained_SHA256'], 'full retained trace hash/count')
    _need(trace['event_count'] >= len(events) and trace['full_JSONL_bytes'] >= len(raw), 'trace extent')
    _need(all(e['seq'] == i for i, e in enumerate(events)), 'trace sequence')
    if trace['event_count'] == len(events):
        _need(trace['full_JSONL_bytes'] == len(raw) and trace['full_SHA256'] == trace['retained_SHA256'], 'full trace identity')
    if result['status'] != 'UNKNOWN':
        _need(trace['complete'] is True, 'all tiny normal traces retained without clipping')
        _need(result['counts']['nodes'] == sum(e['kind'] == 'PLACED' for e in events), 'placement event count')
        _need(result['counts']['forced_placements'] == sum(e['kind'] == 'PLACED' and e['data']['forced'] for e in events), 'forced count')
        _need(result['counts']['trail_entries_written'] == result['counts']['trail_entries_undone'], 'whole trail unwound')
    return {'status': 'VERIFIED', 'retained_events': len(events),
            'scope': 'Every retained event/hash/count and normal complete extent checked; all intermediate CHANGE states are retained, not independently semantically replayed here.'}


def _check_result(model, result, expected_solutions, run, expected=None):
    _need(type(result) is dict and set(result) == {'schema', 'status', 'version', 'model_sha256',
          'solution', 'solution_state', 'entry_state', 'restored_state', 'counts', 'costs',
          'trace', 'rollback', 'reason', 'scope'}, 'point exact14 receipt')
    _need(result['schema'] == 'R-finite-unit-marked-family-result-v1'
          and result['version'] == 'R-FINITE-UNIT-MARKED-FAMILY-SEARCH-v2', 'current point receipt version')
    actual = result['status']
    wanted = ('SAT' if expected_solutions else 'UNSAT') if expected is None else expected
    _need(actual == wanted, 'point status equals independent finite enumeration/declared refusal')
    checks = []
    if result['entry_state'] is not None:
        normal = _copy(model)
        normal['points'].sort(key=tuple)
        normal['fixed_marks'].sort(key=lambda row: tuple(row[0]))
        normal['groups'].sort(key=lambda row: row['id'])
        _need(result['model_sha256'] == hashlib.sha256(_wire(normal)).hexdigest(), 'exact normalized input/version model digest')
        _need(result['entry_state']['selected'] == []
              and all(type(v) is int and v == 0 for _, v in result['entry_state']['totals'])
              and all(_hex(mask) == 0 for _, mask in result['entry_state']['excluded']), 'fresh unselected unexcluded entry')
        checks.append(_check_state(model, result['entry_state'], run))
        _need(result['rollback']['prepared'] is True and result['rollback']['entry_restored'] is True
              and result['rollback']['trail_remaining'] == 0, 'prepared exact rollback receipt')
        if result['restored_state'] is not None:
            _need(result['entry_state'] is not result['restored_state'], 'fresh restored image')
            checks.append(_check_state(model, result['restored_state'], run))
            _equal(result['entry_state'], result['restored_state'], 'complete entry restored')
        else:
            _need(actual == 'UNKNOWN', 'normal final full restored image')
    if actual == 'SAT':
        _need(any(_wire(result['solution']) == _wire(s) for s in expected_solutions), 'SAT chosen IDs in full independent solution set')
        checks.append(_check_state(model, result['solution_state'], run))
        _equal(result['solution'], result['solution_state']['selected'], 'all chosen IDs retained')
        _need(all(v == 1 for _, v in result['solution_state']['totals']), 'whole target full')
    else:
        _need(result['solution'] is None and result['solution_state'] is None, 'no unknown/UNSAT solution prefix')
    return {'status': 'VERIFIED', 'independent_solutions': expected_solutions,
            'state_checks': checks, 'trace': _check_trace(result, run)}


def _point_case(run, engine, name, model, preferences=None, changes=None, expected=None):
    before = _wire(model)
    solutions = _brute(model, run)
    limits = dict(POINT_LIMITS)
    if changes:
        limits.update(changes)
    result = run.call('engine.solve', engine.solve, model, limits, preferences,
                      budget=run.tick)
    _need(_wire(model) == before, 'point input unchanged')
    receipt = _check_result(model, result, solutions, run, expected)
    if name == 'P02-global-dead':
        _need(result['counts']['nodes'] == 0 and result['counts']['forced_placements'] == 0,
              'distant global dead before forced')
    if name == 'P06-identities':
        _equal(result['solution'], [['B', 0]], 'preference retains distinct base identity')
    if name == 'P07-backtrack':
        _need(result['counts']['backtracks'] > 0, 'actual failed-child rollback exercised')
    run.emit(name, {'kind': 'POINT', 'model': model, 'limits': limits,
                    'preferences': preferences, 'result': result, 'independent_check': receipt})


def _direct_points(run, engine):
    p, q, remote = [0, 0, 0], [2, 0, 0], [9, 9, 9]
    empty = _model([], [])
    _point_case(run, engine, 'P01-empty', empty)
    _point_case(run, engine, 'P02-global-dead', _model([p, q], [_explicit('A', p, [[]])]))
    _point_case(run, engine, 'P03-remote-zero', _model([p, q], [
        _explicit('A', p, [[[remote, 0]]]), _explicit('B', q, [[[remote, 0]]])]))
    _point_case(run, engine, 'P04-remote-conflict', _model([p, q], [
        _explicit('A', p, [[[remote, 0]]]), _explicit('B', q, [[[remote, 1]]])]))
    _point_case(run, engine, 'P05-missing-zero', _model([p], [
        _explicit('A', p, [[], [[remote, 0]]])], [[remote, 1]]))
    _point_case(run, engine, 'P06-identities', _model([p], [
        _explicit('A', p, [[]]), _explicit('B', p, [[]])]), [['B', 0]])
    branch = _model([p, q], [_explicit('A', p, [[[remote, 0]], [[remote, 1]]]),
                           _explicit('B', q, [[[remote, 1]], [[remote, 1]]])])
    _point_case(run, engine, 'P07-backtrack', branch)
    _point_case(run, engine, 'P08-node-unknown', branch, changes={'max_nodes': 0}, expected='UNKNOWN')
    _point_case(run, engine, 'P09-operation-unknown', branch, changes={'max_operations': 0}, expected='UNKNOWN')
    _point_case(run, engine, 'P10-trail-unknown', branch, changes={'max_trail_entries': 0}, expected='UNKNOWN')
    _point_case(run, engine, 'P11-Unicode', _model([p], [_explicit('G\U0001f642', p, [[], []])], version='V\U0001f642'))
    def owned():
        run.tick()
        raise engine.SearchBudgetExceeded('authored qualification owned refusal')
    answer = run.call('engine.solve', engine.solve, empty, dict(POINT_LIMITS), budget=owned)
    checked = _check_result(empty, answer, [[]], run, 'UNKNOWN')
    run.emit('P12-owned-refusal', {'model': empty, 'limits': dict(POINT_LIMITS), 'preferences': None,
                                 'budget_profile': 'raise public owned exception at first callback',
                                 'result': answer, 'independent_check': checked})
    sentinel = _Foreign('authored foreign callback')
    def foreign():
        run.tick()
        raise sentinel
    try:
        run.call('engine.solve', engine.solve, empty, dict(POINT_LIMITS), budget=foreign)
    except _Foreign as error:
        _need(error is sentinel, 'exact foreign identity')
        foreign_record = {'type': type(error).__name__, 'message': str(error), 'same_instance': True}
    else:
        raise QualificationFailure('foreign error swallowed')
    run.emit('P13-foreign-refusal', {'model': empty, 'limits': dict(POINT_LIMITS), 'preferences': None,
                                  'exception': foreign_record, 'status': 'EXPECTED_EXACT_FOREIGN_PROPAGATION'})
    for name, bad in [('P14-bool-mark', _model([p], [_explicit('A', p, [[[remote, True]]])])),
                      ('P15-bool-mask', _model([p], [{'id': 'A', 'kind': 'byte', 'anchor': p,
                          'mark_point': remote, 'allowed_mask': True}]))]:
        before = _wire(bad)
        try:
            run.call('engine.solve', engine.solve, bad, dict(POINT_LIMITS), budget=run.tick)
        except engine.ModelError as error:
            error_record = {'type': type(error).__name__, 'message': str(error)}
        else:
            raise QualificationFailure('invalid exact type accepted')
        _need(_wire(bad) == before, 'invalid input unchanged')
        run.emit(name, {'model': bad, 'limits': dict(POINT_LIMITS), 'preferences': None,
                        'exception': error_record, 'status': 'EXPECTED_MODEL_ERROR'})


def _binary_points(run, engine):
    for length in (1, 2, 3):
        for bits in itertools.product((0, 1), repeat=length):
            run.tick()
            points, groups, fixed = [], [], []
            for i in range(length):
                anchor, private, shared = [2 * i, 0, 0], [2 * i, 0, 4], [-5, -5, 9]
                points.append(anchor)
                groups.append(_explicit('G' + str(i), anchor,
                    [[[private, 0], [shared, 0]], [[private, 1], [shared, 1]]]))
                fixed.append([private, bits[i]])
            _point_case(run, engine, 'Binary-' + str(length) + '-' + ''.join(map(str, bits)),
                        _model(points, groups, fixed))


def _binding(count, name):
    digest = lambda role: hashlib.sha256((role + ':' + name).encode('ascii')).hexdigest()
    return {'program_sha256': digest('SYNTHETIC-NOT-PROOF'), 'theory_sha256': digest('MODEL'),
            'goal_sha256': digest('REPRESENTATION'), 'byte_count': count,
            'boundary_version': 'SYNTHETIC-QUALIFICATION-v1'}


def _builder_case(run, engine, name, count, fixed, cuts, mode='COMPLETE'):
    nogoods = {'binding': _binding(count, name), 'cuts': cuts}
    original = _wire([fixed, nogoods])
    limits = dict(POINT_LIMITS)
    if mode == 'UNKNOWN':
        limits['max_operations'] = 0
    if mode == 'INVALID':
        nogoods['binding']['byte_count'] = count + 1
        original = _wire([fixed, nogoods])
        try:
            run.call('engine.make_byte_model', engine.make_byte_model, count, fixed, nogoods,
                     limits, budget=run.tick)
        except engine.ModelError as error:
            error_record = {'type': type(error).__name__, 'message': str(error)}
        else:
            raise QualificationFailure('binding mismatch accepted')
        _need(_wire([fixed, nogoods]) == original, 'invalid builder input unchanged')
        run.emit(name, {'byte_count': count, 'fixed_bytes': fixed, 'nogoods': nogoods,
                        'limits': limits, 'exception': error_record, 'status': 'EXPECTED_MODEL_ERROR'})
        return
    made = run.call('engine.make_byte_model', engine.make_byte_model, count, fixed, nogoods,
                    limits, budget=run.tick)
    _need(_wire([fixed, nogoods]) == original and made['status'] == mode, 'builder full outcome/input')
    if mode == 'UNKNOWN':
        _need(all(made[k] is None for k in ('model', 'binding', 'byte_group_ids',
               'clause_witness_groups', 'normalized_cuts')), 'no partial builder model')
        run.emit(name, {'byte_count': count, 'fixed_bytes': fixed, 'nogoods': nogoods, 'builder': made})
        return
    _need(len(made['byte_group_ids']) == count, 'full byte identity map')
    model = made['model']
    byid = {g['id']: g for g in model['groups']}
    for i, gid in enumerate(made['byte_group_ids']):
        g = byid[gid]
        _equal(g, {'id': gid, 'kind': 'byte', 'anchor': [2 * i, 0, 0],
                  'mark_point': [2 * i, 0, 1], 'allowed_mask': (1 << 256) - 1}, 'entire byte family')
    builder_check = _check_builder(count, fixed, nogoods, made, run)
    expected = _brute(model, run)
    chosen = dict(fixed)
    _need(len(chosen) == count, 'this closed builder cohort fixes every byte')
    allowed = not any(all(chosen[i] == b for i, b in cut) for cut in cuts)
    _need(bool(expected) == allowed, 'auxiliary point existential projection equals original forbidden joint relation')
    answer = run.call('engine.solve', engine.solve, model, dict(POINT_LIMITS), budget=run.tick)
    checked = _check_result(model, answer, expected, run)
    if name in ('Byte-V01', 'Byte-V02', 'Byte-V04'):
        _need(made['normalized_cuts'][0]['status'] == 'VACUOUS_WHOLE_CUT_DROPPED', 'whole cut vacuity')
    if name == 'Byte-V03':
        _need(made['normalized_cuts'][0]['status'] == 'RETAINED'
              and made['normalized_cuts'][0]['literals'] == [], 'duplicate/matched fixed literal normalization')
    run.emit(name, {'byte_count': count, 'fixed_bytes': fixed, 'nogoods': nogoods,
                    'builder': made, 'solver': answer, 'independent_check': checked,
                    'independent_builder_check': builder_check,
                    'original_cut_relation_allows_fixed_assignment': allowed,
                    'scope': 'Synthetic representation control, no learned rejection certificate or proof fixture.'})


def _check_builder(count, fixed, nogoods, made, run):
    fixed_map = dict(fixed)
    normalized = []
    for j, cut in enumerate(nogoods['cuts']):
        values = {}
        vacuous = False
        for i, b in cut:
            run.tick()
            if i in values and values[i] != b:
                vacuous = True
            values[i] = b
        vacuous = vacuous or any(i in fixed_map and fixed_map[i] != b for i, b in values.items())
        residual = [] if vacuous else [[i, b] for i, b in sorted(values.items()) if i not in fixed_map]
        normalized.append({'input_cut_index': j,
                           'status': 'VACUOUS_WHOLE_CUT_DROPPED' if vacuous else 'RETAINED',
                           'literals': residual})
    _equal(made['normalized_cuts'], normalized, 'entire independent cut normalization')
    _equal(made['binding'], nogoods['binding'], 'full returned caller binding')
    model = made['model']
    byid = {g['id']: g for g in model['groups']}
    used = set(made['byte_group_ids'])
    _need(len(used) == count, 'unique byte group map')
    points = [[2 * i, 0, 0] for i in range(count)]
    _need(len(made['clause_witness_groups']) == len(normalized), 'all input cut map rows')
    for row, cut in zip(made['clause_witness_groups'], normalized, strict=True):
        run.tick()
        _need(row['input_cut_index'] == cut['input_cut_index'], 'cut map exact association')
        if cut['status'] != 'RETAINED':
            _equal(row, {'input_cut_index': cut['input_cut_index'], 'anchor': None, 'groups': []}, 'whole vacuous cut absent')
            continue
        anchor = [2 * cut['input_cut_index'], 2, 0]
        points.append(anchor)
        _equal(row['anchor'], anchor, 'clause positive anchor')
        _need(len(row['groups']) == len(cut['literals']), 'all residual witness groups')
        for mapping, (i, b) in zip(row['groups'], cut['literals'], strict=True):
            gid = mapping['group_id']
            _need(gid not in used and gid in byid, 'unique actual witness map identity')
            used.add(gid)
            _equal(mapping, {'byte_index': i, 'forbidden_byte': b, 'group_id': gid}, 'witness literal association')
            _equal(byid[gid], {'id': gid, 'kind': 'byte', 'anchor': anchor,
                   'mark_point': [2 * i, 0, 1], 'allowed_mask': ((1 << 256) - 1) ^ (1 << b)}, 'entire actual complement witness family')
    _need(used == set(byid), 'no extra or missing model groups')
    _equal(model['points'], points, 'entire required point set')
    _equal(model['fixed_marks'], [[[2 * i, 0, 1], b] for i, b in sorted(fixed_map.items())], 'actual known byte markings')
    context = {'builder_version': made['version'], 'binding': nogoods['binding'],
               'fixed_bytes': [[i, b] for i, b in sorted(fixed_map.items())],
               'normalized_cuts': normalized}
    _need(model['version'] == made['version'] + ':' + hashlib.sha256(_wire(context)).hexdigest(), 'full context/fixed/cuts/version digest')
    return {'status': 'VERIFIED', 'all_groups_examined': len(byid),
            'all_cut_mappings_examined': len(normalized), 'full_context_digest_checked': True}


def _byte_controls(run, engine):
    for length in range(4):
        for bits in itertools.product((0, 1), repeat=length):
            fixed = [[i, b] for i, b in enumerate(bits)]
            base = 'Byte-' + str(length) + '-' + (''.join(map(str, bits)) or 'empty')
            _builder_case(run, engine, base + '-open', length, fixed, [])
            _builder_case(run, engine, base + '-forbid', length, fixed, [list(fixed)])
            if length:
                _builder_case(run, engine, base + '-mixed', length, fixed,
                              [[[0, 0]], [[0, 1], [length - 1, 1]]])
    _builder_case(run, engine, 'Byte-V01', 1, [[0, 0]], [[[0, 1]]])
    _builder_case(run, engine, 'Byte-V02', 1, [[0, 0]], [[[0, 0], [0, 1]]])
    _builder_case(run, engine, 'Byte-V03', 1, [[0, 0]], [[[0, 0], [0, 0]]])
    _builder_case(run, engine, 'Byte-V04', 2, [[0, 0], [1, 0]], [[[0, 1], [1, 0]]])
    _builder_case(run, engine, 'Byte-V05', 1, [[0, 0]], [], 'INVALID')
    _builder_case(run, engine, 'Byte-V06', 1, [[0, 0]], [], 'UNKNOWN')


def _machines():
    return [('D', {'states': ['q', 'a'], 'alphabet': ['0', '1'], 'start': 'q', 'accept': ['a'],
                    'transitions': [['q', '0', 'q', '1', 1], ['q', '1', 'a', '0', 0], ['a', '0', 'a', '0', 0]]}),
            ('N', {'states': ['q\U0001f642', 'a'], 'alphabet': ['0', '1'], 'start': 'q\U0001f642', 'accept': ['a'],
                    'transitions': [['q\U0001f642', '0', 'q\U0001f642', '1', -1],
                                    ['q\U0001f642', '0', 'a', '0', 0],
                                    ['q\U0001f642', '0', 'q\U0001f642', '1', 1],
                                    ['q\U0001f642', '1', 'q\U0001f642', '0', -1],
                                    ['q\U0001f642', '1', 'a', '1', 0],
                                    ['q\U0001f642', '1', 'q\U0001f642', '0', 1]]})]


def _colour(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'))


def _effective(machine):
    accept = set(machine['accept'])
    rows = [tuple(r) for r in machine['transitions'] if r[0] not in accept]
    rows += [(q, s, q, s, 0) for q in accept for s in machine['alphabet']]
    return sorted(rows)


def _check_compilation(machine, result, marked, run):
    _need(result['schema'] == 'C-compact-directional-NTM-Wang-compile-result-v1'
          and result['version'] == 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2', 'current compact receipt')
    _need(result['status'] == 'COMPLETE' and result['head_marks'] is marked
          and result['counts']['complete_census'] is True, 'normal full compiler result')
    _need(set(result) == {'schema', 'version', 'status', 'machine', 'machine_sha256', 'limits',
          'head_marks', 'effective_transitions', 'glyphs', 'palette', 'witnesses', 'counts', 'reason', 'scope'}, 'compiler exact14')
    normal = {'states': sorted(machine['states']), 'alphabet': sorted(machine['alphabet']),
              'start': machine['start'], 'accept': sorted(machine['accept']),
              'transitions': [list(r) for r in sorted(tuple(x) for x in machine['transitions'])]}
    _equal(result['machine'], normal, 'full canonical machine')
    _need(result['machine_sha256'] == hashlib.sha256(_wire(normal)).hexdigest(), 'full machine hash')
    effective = _effective(machine)
    _equal(result['effective_transitions'], [{'index': i, 'q': q, 'read': s, 'next': qn,
           'write': w, 'move': d, 'origin': 'IMPLICIT_ACCEPT_IDENTITY' if q in machine['accept'] else 'EXPLICIT'}
           for i, (q, s, qn, w, d) in enumerate(effective)], 'full effective transition relation')
    left = {r[2] for r in effective if r[4] == -1}
    right = {r[2] for r in effective if r[4] == 1}
    predicted = len(machine['alphabet']) + 1 + len(effective) + len(machine['alphabet']) * (len(left) + len(right))
    _need(len(result['palette']) == len(result['witnesses']) == predicted
          and result['counts']['predicted_tiles'] == result['counts']['tiles_constructed'] == predicted,
          'full exact predicted palette census')
    expected_ids = [['C', 'COPY', symbol] for symbol in sorted(machine['alphabet'])] + [['C', 'WALL']]
    for move in (0, 1, -1):
        expected_ids += [['C', 'SOURCE', q, s, qn, w, d] for q, s, qn, w, d in effective if d == move]
    for states, tag in [(right, 'RECEIVE_RIGHT'), (left, 'RECEIVE_LEFT')]:
        expected_ids += [['C', tag, q, symbol] for q in sorted(states) for symbol in sorted(machine['alphabet'])]
    _equal([tile['id'] for tile in result['palette']], [_colour(x) for x in expected_ids], 'entire canonical identity/order census')
    expected_families = {'COPY': len(machine['alphabet']), 'WALL': 1,
                        'STAY': sum(r[4] == 0 for r in effective),
                        'MOVE_RIGHT': sum(r[4] == 1 for r in effective),
                        'MOVE_LEFT': sum(r[4] == -1 for r in effective),
                        'RECEIVE_RIGHT': len(right) * len(machine['alphabet']),
                        'RECEIVE_LEFT': len(left) * len(machine['alphabet'])}
    _equal(result['counts']['families'], expected_families, 'all seven independent family counts')
    ids, vertical, horizontal = set(), {}, {}
    for tile, witness in zip(result['palette'], result['witnesses'], strict=True):
        run.tick()
        _need(set(tile) == {'id', 'N', 'E', 'S', 'W'} and tile['id'] not in ids, 'unique full tile')
        ids.add(tile['id'])
        ident = json.loads(tile['id'])
        idle = ['IDLE']
        transition_index = None
        if ident[1] == 'COPY':
            symbol = ident[2]
            family, n, e, so, w = 'COPY', ['P', symbol], idle, ['P', symbol], idle
        elif ident[1] == 'WALL':
            family, n, e, so, w = 'WALL', ['WALL'], idle, ['WALL'], idle
        elif ident[1] == 'SOURCE':
            _, _, q, read, target, write, move = ident
            transition_index = effective.index((q, read, target, write, move))
            family = 'STAY' if move == 0 else 'MOVE_RIGHT' if move == 1 else 'MOVE_LEFT'
            n = ['H', q, read]
            so = ['H', target, write] if move == 0 else ['P', write]
            e = ['RIGHT', target] if move == 1 else idle
            w = ['LEFT', target] if move == -1 else idle
        else:
            _, family, target, symbol = ident
            n, so = ['P', symbol], ['H', target, symbol]
            e = ['LEFT', target] if family == 'RECEIVE_LEFT' else idle
            w = ['RIGHT', target] if family == 'RECEIVE_RIGHT' else idle
        _equal(tile, {'id': tile['id'], 'N': _colour(n), 'E': _colour(e),
                      'S': _colour(so), 'W': _colour(w)}, 'all four literal edges equal independent identity interpretation')
        _need(witness['family'] == family and witness['transition_index'] == transition_index,
              'full family/effective transition association')
        _equal(witness['input_glyph'], n, 'input glyph association')
        _equal(witness['output_glyph'], so, 'output glyph association')
        message = e if family in ('MOVE_RIGHT', 'RECEIVE_LEFT') else w if family in ('MOVE_LEFT', 'RECEIVE_RIGHT') else idle
        _equal(witness['message'], message, 'full directional message association')
        for key, table in [('N', vertical), ('S', vertical), ('E', horizontal), ('W', horizontal)]:
            descriptor = json.loads(tile[key])
            _need(_colour(descriptor) == tile[key], 'canonical complete literal colour')
            table[tile[key]] = descriptor
        _need(set(witness) == {'tile_id', 'family', 'transition_index', 'input_glyph',
              'output_glyph', 'message', 'head_types', 'point_template'}, 'witness exact8')
        _need(witness['tile_id'] == tile['id'], 'whole witness identity')
        north, south = json.loads(tile['N']), json.loads(tile['S'])
        incoming, outgoing = int(north[0] == 'H'), int(south[0] == 'H')
        remote = [-2, -1, 1, 1] if json.loads(tile['W'])[0] == 'RIGHT' and north[0] == 'P' else [2, -1, 1, 1] if json.loads(tile['E'])[0] == 'LEFT' and north[0] == 'P' else None
        expected = [[-1, 0, 0, tile['W']], [0, -1, 0, tile['N']],
                    [0, 1, 0, tile['S']], [1, 0, 0, tile['E']]]
        if marked:
            expected += [[0, -1, 1, incoming], [0, 1, 1, outgoing]]
            if remote is not None:
                expected.append(remote)
        expected.sort(key=lambda v: tuple(v[:3]))
        _equal(witness['point_template'], {'t': [[0, 0, 0, 1]], 'm': expected}, 'all actual point support/assignedzero/m-only slots')
        _equal(witness['head_types'], {'input': incoming, 'output': outgoing, 'remote': remote}, 'all head-type metadata')
    for key, table in [('vertical', vertical), ('horizontal', horizontal)]:
        _equal(result['glyphs'][key], [{'id': k, 'glyph': table[k]} for k in sorted(table)], 'whole used colour catalogue')
    c = result['counts']
    folded = sum(r[0] in machine['accept'] for r in machine['transitions'])
    remote_slots = expected_families['RECEIVE_RIGHT'] + expected_families['RECEIVE_LEFT']
    for name, wanted in [('input_states', len(machine['states'])), ('input_symbols', len(machine['alphabet'])),
             ('accepting_states', len(machine['accept'])), ('input_transitions', len(machine['transitions'])),
             ('folded_accept_identities', folded), ('implicit_absorbing_transitions', len(machine['accept']) * len(machine['alphabet'])),
             ('effective_transition_count', len(effective)), ('left_receiver_states', len(left)), ('right_receiver_states', len(right)),
             ('positive_slots', predicted), ('wang_mark_slots', 4 * predicted),
             ('head_local_mark_slots', 2 * predicted if marked else 0), ('head_remote_mark_slots', remote_slots if marked else 0),
             ('total_mark_slots', 4 * predicted + (2 * predicted + remote_slots if marked else 0)),
             ('vertical_colours', len(vertical)), ('horizontal_colours', len(horizontal))]:
        _need(type(c[name]) is int and c[name] == wanted, 'exact compiler counter ' + name)
    _need(result['counts']['operations'] == sum(result['counts']['by_kind'].values())
          and sum(result['counts']['families'].values()) == predicted, 'operation/family totals')
    return {'status': 'VERIFIED', 'all_palette_tiles_examined': predicted,
            'scope': 'Whole return/effective counts/catalogues/actual point support checked; independent global configuration comparison follows on every closed row context.'}


def _grid_marks(grid, prototypes, run):
    union = {}
    for row_index, row in enumerate(grid):
        for column, ident in enumerate(row):
            run.tick()
            template = prototypes[ident]
            _equal(template['t'], [[0, 0, 0, 1]], 'one required unit anchor per selected cell')
            for x, y, z, value in template['m']:
                run.tick()
                point = (2 * column + x, 2 * row_index + y, z)
                _need(point not in union or _wire(union[point]) == _wire(value), 'whole grid actual m equality')
                union[point] = value
    return len(union)


def _decode_row(row, machine):
    glyphs = [json.loads(x) for x in row]
    _need(glyphs[0] == glyphs[-1] == ['WALL'], 'both fixed walls preserved')
    tape, heads = [], []
    for i, glyph in enumerate(glyphs[1:-1]):
        if len(glyph) == 2 and glyph[0] == 'P':
            symbol = glyph[1]
        else:
            _need(len(glyph) == 3 and glyph[0] == 'H' and glyph[1] in machine['states'], 'normal literal head glyph')
            symbol = glyph[2]
            heads.append((i, glyph[1]))
        _need(type(symbol) is str and symbol in machine['alphabet'], 'literal declared symbol')
        tape.append(symbol)
    _need(len(heads) == 1, 'exactly one head, not two orphan receivers')
    return {'state': heads[0][1], 'head': heads[0][0], 'tape': tape}


def _key(config):
    return config['state'], config['head'], tuple(config['tape'])


def _literal_layers(machine, compiled, marked, initial, run):
    tiles = compiled['palette']
    by_north = {}
    for tile in tiles:
        run.tick()
        by_north.setdefault(tile['N'], {}).setdefault(tile['W'], []).append(tile)
    plain_prototypes = {w['tile_id']: w['point_template'] for w in compiled['witnesses']}
    marked_prototypes = {w['tile_id']: w['point_template'] for w in marked['witnesses']}
    north = [_colour(['WALL'])] + [_colour(['H', initial['state'], s] if i == initial['head'] else ['P', s])
               for i, s in enumerate(initial['tape'])] + [_colour(['WALL'])]
    current = {_key(initial): (north, [])}
    layers = [{'step': 0, 'configurations': [_copy(initial)],
               'witnesses': [{'configuration': _copy(initial), 'tile_rows': []}]}]
    trials = completions = 0
    for step in (1, 2):
        run.tick()
        following = {}
        for prior in sorted(current):
            input_row, old_grid = current[prior]
            found = []
            def visit(column, west, outputs, ids):
                nonlocal trials, completions
                run.tick()
                if column == len(input_row):
                    if west == _colour(['IDLE']):
                        if completions >= 10000:
                            raise QualificationBudgetExceeded('complete literal row enumeration cap')
                        run.tick(len(ids) + len(outputs))
                        found.append((list(outputs), list(ids)))
                        completions += 1
                    return
                for tile in by_north.get(input_row[column], {}).get(west, ()):
                    run.tick()
                    trials += 1
                    visit(column + 1, tile['E'], outputs + [tile['S']], ids + [tile['id']])
            visit(0, _colour(['IDLE']), [], [])
            for output, ids in found:
                run.tick()
                configuration = _decode_row(output, machine)
                grid = old_grid + [ids]
                _grid_marks(grid, plain_prototypes, run)
                _grid_marks(grid, marked_prototypes, run)
                following.setdefault(_key(configuration), (output, grid))
        current = following
        witnesses = [{'configuration': _decode_row(current[k][0], machine),
                      'tile_rows': current[k][1]} for k in sorted(current)]
        layers.append({'step': step, 'configurations': [w['configuration'] for w in witnesses],
                       'witnesses': witnesses})
    return {'status': 'COMPLETE', 'layers': layers, 'candidate_trials': trials,
            'complete_row_tilings': completions,
            'accepts': any(c['state'] in machine['accept'] for c in layers[-1]['configurations']),
            'scope': 'Literal NEW N/E/S/W equality row DFS with fixed IDLE sides and WALL cells; every reachable configuration layer, one full grid witness per distinct configuration. Every enumerated extension checks full actual plain/head m union. Not all path histories after configuration dedup and no point-engine row solve.'}


def _compiler_and_rows(run, compact, ntm):
    machines = _machines()
    compiled = {}
    for label, machine in machines:
        before = _wire(machine)
        pair = []
        for flag, suffix in [(False, 'plain'), (True, 'head')]:
            result = run.call('compact.compile_palette', compact.compile_palette, machine,
                              dict(COMPACT_LIMITS), head_marks=flag, budget=run.tick)
            _need(_wire(machine) == before, 'compiler input unchanged')
            checked = _check_compilation(machine, result, flag, run)
            run.emit('Compiler-' + label + '-' + suffix,
                     {'machine': machine, 'limits': COMPACT_LIMITS, 'head_marks': flag,
                      'result': result, 'independent_check': checked})
            pair.append(result)
        _equal(pair[0]['palette'], pair[1]['palette'], 'identical full literal palette under head layer erasure')
        compiled[label] = pair
    base = machines[0][1]
    negative = []
    negative.append(('K01-cardinality', _copy(base), {'max_operations': 20000000, 'max_tiles': 128, 'extra': 0}, False, 'REJECTED'))
    bad = _copy(base); bad['transitions'][0][4] = True
    negative.append(('K02-bool-move', bad, dict(COMPACT_LIMITS), False, 'REJECTED'))
    bad = _copy(base); bad['transitions'].append(list(bad['transitions'][0]))
    negative.append(('K03-duplicate', bad, dict(COMPACT_LIMITS), False, 'REJECTED'))
    bad = _copy(base); bad['transitions'].append(['a', '0', 'q', '1', 0])
    negative.append(('K04-accept-outgoing', bad, dict(COMPACT_LIMITS), False, 'REJECTED'))
    negative.append(('K05-operation', _copy(base), {'max_operations': 0, 'max_tiles': 128}, False, 'UNKNOWN_BUDGET'))
    negative.append(('K06-tiles', _copy(base), {'max_operations': 20000000, 'max_tiles': 0}, False, 'UNKNOWN_BUDGET'))
    negative.append(('K07-head-bool', _copy(base), dict(COMPACT_LIMITS), 1, 'REJECTED'))
    for name, machine, limits, head, wanted in negative:
        result = run.call('compact.compile_palette', compact.compile_palette, machine, limits,
                          head_marks=head, budget=run.tick)
        _need(result['status'] == wanted and result['counts']['complete_census'] is False
              and all(result[k] is None for k in ('palette', 'glyphs', 'witnesses', 'effective_transitions')),
              'no invalid/unknown prefix palette')
        run.emit(name, {'machine': machine, 'limits': limits, 'head_marks': head, 'result': result})
    sentinel = _Foreign('compiler foreign callback')
    def foreign():
        run.tick()
        raise sentinel
    try:
        run.call('compact.compile_palette', compact.compile_palette, base, dict(COMPACT_LIMITS), budget=foreign)
    except _Foreign as error:
        _need(error is sentinel, 'compiler foreign error identity')
        foreign_record = {'type': type(error).__name__, 'message': str(error), 'same_instance': True}
    else:
        raise QualificationFailure('compiler swallowed foreign callback')
    run.emit('K08-foreign', {'machine': base, 'limits': dict(COMPACT_LIMITS), 'head_marks': False,
                             'exception': foreign_record, 'status': 'EXPECTED_EXACT_FOREIGN_PROPAGATION'})
    for label, machine in machines:
        plain, marked = compiled[label]
        for state_index, state in enumerate(machine['states']):
            for head in range(2):
                for tape in itertools.product(machine['alphabet'], repeat=2):
                    run.tick()
                    initial = {'state': state, 'head': head, 'tape': list(tape)}
                    original = _wire([machine, initial])
                    reference = run.call('ntm.simulate', ntm.simulate, machine, initial, 2, dict(NTM_LIMITS))
                    _need(_wire([machine, initial]) == original, 'NTM input unchanged')
                    _need(reference['status'] == 'COMPLETE' and reference['complete'] is True
                          and reference['steps_completed'] == 2 and len(reference['layers']) == 3, 'complete global reference')
                    literal = _literal_layers(machine, plain, marked, initial, run)
                    for step in range(3):
                        expected = sorted(_key(c) for c in reference['layers'][step]['configurations'])
                        actual = sorted(_key(c) for c in literal['layers'][step]['configurations'])
                        _equal(actual, expected, 'all exact normal global configuration layers')
                        _need(reference['layers'][step]['count'] == len(expected)
                              and reference['layers'][step]['accepting_count'] == sum(k[0] in machine['accept'] for k in expected), 'full reference layer counts')
                    _need(literal['accepts'] is reference['acceptance']['at_requested_step'], 'final actual accepting head')
                    name = 'Rows-' + label + '-' + str(state_index) + '-' + str(head) + '-' + ''.join(tape)
                    run.emit(name, {'machine': machine, 'initial': initial, 'steps': 2,
                                    'reference_limits': NTM_LIMITS, 'reference': reference,
                                    'literal_rows': literal, 'comparison': 'ALL_LAYERS_AND_FINAL_ACCEPTANCE_EQUAL',
                                    'literal_row_to_point_engine_solves': 0})


def qualify(engine, compact, ntm, emit):
    """Run only under a future caller-bound Root once; no internal imports/IO."""
    run = _Run(emit)
    _direct_points(run, engine)
    _binary_points(run, engine)
    _byte_controls(run, engine)
    _compiler_and_rows(run, compact, ntm)
    run.tick()
    _equal(run.calls, EXPECTED_CALLS, 'whole exact public call census')
    _need(len(run.records) == len(run.names) == 123, 'whole fixed cohort, no missing prefix')
    return {'schema': 'R-point-and-compact-qualification-result-v1',
            'status': 'COMPLETE_COMPONENT_QUALIFICATION', 'version': VERSION,
            'counts': {'point_controls': 79, 'compiler_controls': 12, 'row_contexts': 32,
                       'full_emitted_records': 123, 'old_Wang_row_module_calls': 0,
                       'literal_row_point_engine_solves': 0},
            'public_calls': dict(run.calls), 'records': list(run.records),
            'costs': {'qualification_operations': run.operations,
                      'elapsed_main_entry_seconds': time.monotonic() - run.started},
            'scope': 'Closed tiny component controls only. All saved producer returns and complete independent finite sets/layers are emitted. Old CHOOSE/EXEC/T row wire is incompatible, so new independent literal edge row DFS is used. Trace hashes/full boundary states verified; intermediate CHANGE states not semantically replayed. No proof fixtures/discovery, physicalC1, strictMachine5, universalpalette, generaltiler, RL or performance claim.'}
