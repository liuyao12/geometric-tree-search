"""Inert compact directional-message finite NTM Wang compiler.

The seven families encode one machine step per row under a one-head input and
closed IDLE/wall boundaries. Optional head marks are designed redundant only on
complete such boards in a fresh layer, not arbitrary free partial patches.
No model/runner/checker/CLI, input mutation, project import or module-top call.
"""
import hashlib
import json

VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v1'
SCHEMA = 'C-compact-directional-NTM-Wang-compile-result-v1'
FAMILIES = ('COPY', 'WALL', 'STAY', 'MOVE_RIGHT', 'MOVE_LEFT',
            'RECEIVE_RIGHT', 'RECEIVE_LEFT')
SCOPE = ('Finite machine compiler only; one row per effective transition under '
         'one-head input and complete rectangular closed-IDLE/wall boundaries. '
         'Head-type layer is fresh, designed redundant on complete solutions, '
         'not learned or redundant on arbitrary exposed-carry partial patches. '
         'No cap/board builder, machine execution, point-engine conformance, '
         'physical FOL acceptance, strict Machine5 expansion or proof search.')


class _Invalid(Exception):
    def __init__(self, code, detail):
        super().__init__(code)
        self.code = code
        self.detail = detail


class _Budget(Exception):
    def __init__(self, code, detail):
        super().__init__(code)
        self.code = code
        self.detail = detail


def _need(condition, code, detail):
    if not condition:
        raise _Invalid(code, detail)


def _fields(value, names, code):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(names), code, 'exact native record fields')


def _limits(limits):
    _fields(limits, ('max_operations', 'max_tiles'), 'LIMITS_SHAPE')
    _need(all(type(v) is int and v >= 0 for v in limits.values()),
          'LIMITS_VALUE', 'exact nonnegative integers, never bool/float')
    return dict(limits)


class _Meter:
    def __init__(self, limits, budget):
        self.limits = limits
        self.budget = budget
        self.operations = 0
        self.by_kind = {}
        self.callbacks = 0
        self.callback_failed = False

    def tick(self, kind, units=1):
        if type(units) is not int or units < 0:
            raise RuntimeError('internal metering units')
        if units > self.limits['max_operations'] - self.operations:
            raise _Budget('OPERATION_CAP', 'owned logical operation cap')
        self.operations += units
        self.by_kind[kind] = self.by_kind.get(kind, 0) + units
        if self.budget is not None:
            self.callbacks += 1
            try:
                self.budget()
            except BaseException:
                # Preserve every foreign callback exception, including private
                # exception class instances; do not recast it as data-invalid.
                self.callback_failed = True
                raise


def _counts():
    return {'operations': 0, 'by_kind': {}, 'budget_callbacks': 0,
            'complete_census': False, 'input_states': 0, 'input_symbols': 0,
            'accepting_states': 0, 'input_transitions': 0,
            'folded_accept_identities': 0, 'implicit_absorbing_transitions': 0,
            'effective_transition_count': 0, 'left_receiver_states': 0,
            'right_receiver_states': 0, 'predicted_tiles': 0,
            'families': {name: 0 for name in FAMILIES},
            'tiles_constructed': 0, 'positive_slots': 0, 'wang_mark_slots': 0,
            'head_local_mark_slots': 0, 'head_remote_mark_slots': 0,
            'total_mark_slots': 0, 'vertical_colours': 0,
            'horizontal_colours': 0}


def _names(values, label, meter, nonempty):
    _need(type(values) is list and (values or not nonempty),
          'STRING_LIST', label + ' exact list; states/alphabet nonempty')
    meter.tick('name_list_reservation', 1 + len(values))
    seen = set()
    private = []
    for value in values:
        _need(type(value) is str, 'STRING_TYPE', label + ' exact strings')
        meter.tick('name_characters', 1 + len(value))
        _need(value not in seen, 'DUPLICATE_NAME', label + ' duplicate name')
        seen.add(value)
        private.append(value)
    meter.tick('name_sort', len(private) * max(1, len(private).bit_length()))
    private.sort()
    return private, seen


def _machine(machine, meter, counts):
    _fields(machine, ('states', 'alphabet', 'transitions', 'start', 'accept'),
            'MACHINE_SHAPE')
    states, state_set = _names(machine['states'], 'states', meter, True)
    alphabet, symbol_set = _names(machine['alphabet'], 'alphabet', meter, True)
    accept, accepting = _names(machine['accept'], 'accept', meter, False)
    meter.tick('membership', 1 + len(accept))
    _need(all(q in state_set for q in accept), 'ACCEPT_STATE', 'accept subset of states')
    start = machine['start']
    _need(type(start) is str and start in state_set,
          'START_STATE', 'start exact declared state')
    delta = machine['transitions']
    _need(type(delta) is list, 'TRANSITION_LIST', 'transitions exact list')
    meter.tick('transition_reservation', 1 + 6 * len(delta))
    private, seen = [], set()
    folded = 0
    left, right = set(), set()
    for row in delta:
        _need(type(row) is list and len(row) == 5,
              'TRANSITION_SHAPE', 'transition exact list5')
        q, read, target, write, move = row
        _need(all(type(v) is str for v in (q, read, target, write)),
              'TRANSITION_NAME', 'transition names exact strings')
        meter.tick('transition_characters', 1 + len(q) + len(read) + len(target) + len(write))
        _need(q in state_set and target in state_set and read in symbol_set
              and write in symbol_set, 'TRANSITION_NAME', 'declared state/symbol membership')
        _need(type(move) is int and move in (-1, 0, 1),
              'TRANSITION_MOVE', 'exact nonbool move -1/0/1')
        item = (q, read, target, write, move)
        _need(item not in seen, 'DUPLICATE_TRANSITION', 'exact duplicate transition')
        if q in accepting:
            _need(item == (q, read, q, read, 0),
                  'ACCEPT_OUTGOING_CONFLICT', 'accepting states permit only identity STAY')
            folded += 1
        elif move == -1:
            left.add(target)
        elif move == 1:
            right.add(target)
        seen.add(item)
        private.append(item)
    meter.tick('transition_sort', len(private) * max(1, len(private).bit_length()))
    private.sort()
    meter.tick('normalized_machine_copy', 1 + 6 * len(private))
    normal = {'states': states, 'alphabet': alphabet, 'start': start,
              'accept': accept, 'transitions': [list(r) for r in private]}
    counts.update(input_states=len(states), input_symbols=len(alphabet),
                  accepting_states=len(accept), input_transitions=len(private),
                  folded_accept_identities=folded,
                  implicit_absorbing_transitions=len(accept) * len(alphabet),
                  effective_transition_count=len(private) - folded + len(accept) * len(alphabet),
                  left_receiver_states=len(left), right_receiver_states=len(right))
    return normal, private, accepting, left, right


def _json_bound(value):
    """Conservative ASCII serialization reservation on validated shallow data."""
    if type(value) is str:
        return 2 + 12 * len(value)
    if type(value) is int:
        return 24
    if type(value) is list or type(value) is tuple:
        return 2 + len(value) + sum(_json_bound(x) for x in value)
    if type(value) is dict:
        return 2 + 2 * len(value) + sum(_json_bound(k) + _json_bound(v)
                                       for k, v in value.items())
    raise RuntimeError('internal validated JSON descriptor type')


def _wire(value, meter, kind):
    meter.tick(kind, 1 + _json_bound(value))
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _effective(normal, rows, accepting, meter):
    meter.tick('effective_scan', 1 + len(rows))
    size = sum(row[0] not in accepting for row in rows)
    size += len(normal['accept']) * len(normal['alphabet'])
    meter.tick('effective_rows_reservation', 1 + 6 * size)
    values = [r for r in rows if r[0] not in accepting]
    for q in normal['accept']:
        for symbol in normal['alphabet']:
            meter.tick('implicit_accept_identity')
            values.append((q, symbol, q, symbol, 0))
    meter.tick('effective_sort', len(values) * max(1, len(values).bit_length()))
    values.sort()
    meter.tick('effective_metadata', 1 + 8 * len(values))
    return [{'index': i, 'q': q, 'read': read, 'next': target, 'write': write,
             'move': move, 'origin': 'IMPLICIT_ACCEPT_IDENTITY' if q in accepting else 'EXPLICIT'}
            for i, (q, read, target, write, move) in enumerate(values)]


def _colour(descriptor, catalogue, meter):
    wire = _wire(descriptor, meter, 'colour_serialization')
    if wire not in catalogue:
        meter.tick('colour_catalogue_insert', 2 + len(descriptor))
        catalogue[wire] = list(descriptor)
    return wire


def _emit(family, identity, north, east, south, west, transition_index,
          head_marks, meter, counts, palette, witnesses, vertical, horizontal):
    if counts['tiles_constructed'] >= meter.limits['max_tiles']:
        raise _Budget('TILE_CAP', 'tile capacity before materialization')
    meter.tick('tile_materialization', 64)
    tile_id = _wire(identity, meter, 'tile_identity_serialization')
    n = _colour(north, vertical, meter)
    e = _colour(east, horizontal, meter)
    s = _colour(south, vertical, meter)
    w = _colour(west, horizontal, meter)
    incoming = int(north[0] == 'H')
    outgoing = int(south[0] == 'H')
    remote = [-2, -1, 1, 1] if family == 'RECEIVE_RIGHT' else [2, -1, 1, 1] if family == 'RECEIVE_LEFT' else None
    marks = [[-1, 0, 0, w], [0, -1, 0, n], [0, 1, 0, s], [1, 0, 0, e]]
    if head_marks:
        meter.tick('head_mark_materialization', 2 + int(remote is not None))
        marks.extend([[0, -1, 1, incoming], [0, 1, 1, outgoing]])
        if remote is not None:
            marks.append(list(remote))
    meter.tick('mark_sort', len(marks) * max(1, len(marks).bit_length()))
    marks.sort(key=lambda r: (r[0], r[1], r[2]))
    tile = {'id': tile_id, 'N': n, 'E': e, 'S': s, 'W': w}
    message = east if family in ('MOVE_RIGHT', 'RECEIVE_LEFT') else west if family in ('MOVE_LEFT', 'RECEIVE_RIGHT') else ['IDLE']
    witness = {'tile_id': tile_id, 'family': family,
               'transition_index': transition_index,
               'input_glyph': list(north), 'output_glyph': list(south),
               'message': list(message),
               'head_types': {'input': incoming, 'output': outgoing,
                              'remote': list(remote) if remote is not None else None},
               'point_template': {'t': [[0, 0, 0, 1]], 'm': marks}}
    palette.append(tile)
    witnesses.append(witness)
    counts['families'][family] += 1
    counts['tiles_constructed'] += 1
    counts['positive_slots'] += 1
    counts['wang_mark_slots'] += 4
    counts['head_local_mark_slots'] += 2 * int(head_marks)
    counts['head_remote_mark_slots'] += int(head_marks and remote is not None)
    counts['total_mark_slots'] += len(marks)


def _catalogue(values, meter):
    meter.tick('catalogue_sort', len(values) * max(1, len(values).bit_length()))
    meter.tick('catalogue_metadata', 1 + sum(3 + len(v) for v in values.values()))
    return [{'id': key, 'glyph': list(values[key])} for key in sorted(values)]


def _receipt(status, reason, normal, digest, limits, head_marks, effective,
             glyphs, palette, witnesses, counts, meter):
    if meter is not None:
        counts['operations'] = meter.operations
        counts['by_kind'] = dict(meter.by_kind)
        counts['budget_callbacks'] = meter.callbacks
    return {'schema': SCHEMA, 'version': VERSION, 'status': status,
            'machine': normal, 'machine_sha256': digest, 'limits': limits,
            'head_marks': head_marks,
            'effective_transitions': effective, 'glyphs': glyphs,
            'palette': palette, 'witnesses': witnesses, 'counts': counts,
            'reason': reason, 'scope': SCOPE}


def compile_palette(machine, limits, *, head_marks=False, budget=None):
    """Pure complete compact palette; only owned caps become UNKNOWN_BUDGET."""
    normal = digest = checked_limits = meter = None
    selected_marks = head_marks if type(head_marks) is bool else None
    counts = _counts()
    try:
        checked_limits = _limits(limits)
        _need(budget is None or callable(budget), 'BUDGET_CALLBACK_TYPE', 'optional zero-argument callable')
        _need(type(head_marks) is bool, 'HEAD_MARKS_TYPE', 'exact bool head_marks')
        meter = _Meter(checked_limits, budget)
        meter.tick('entry')
        normal, explicit, accepting, left, right = _machine(machine, meter, counts)
        encoded = (_wire(normal, meter, 'machine_fingerprint_serialization') + '\n').encode('ascii')
        digest = hashlib.sha256(encoded).hexdigest()
        predicted = len(normal['alphabet']) + 1 + counts['effective_transition_count']
        predicted += len(normal['alphabet']) * (len(left) + len(right))
        counts['predicted_tiles'] = predicted
        meter.tick('palette_preflight')
        if predicted > checked_limits['max_tiles']:
            raise _Budget('TILE_CAP', 'complete predicted palette exceeds max_tiles before palette growth')
        effective = _effective(normal, explicit, accepting, meter)
        palette, witnesses, vertical, horizontal = [], [], {}, {}
        idle = ['IDLE']
        for symbol in normal['alphabet']:
            _emit('COPY', ['C', 'COPY', symbol], ['P', symbol], idle,
                  ['P', symbol], idle, None, head_marks, meter, counts,
                  palette, witnesses, vertical, horizontal)
        _emit('WALL', ['C', 'WALL'], ['WALL'], idle, ['WALL'], idle,
              None, head_marks, meter, counts, palette, witnesses, vertical, horizontal)
        for move, family in ((0, 'STAY'), (1, 'MOVE_RIGHT'), (-1, 'MOVE_LEFT')):
            for row in effective:
                meter.tick('source_rule_visit')
                if row['move'] != move:
                    continue
                source = ['H', row['q'], row['read']]
                south = ['H', row['next'], row['write']] if move == 0 else ['P', row['write']]
                east = ['RIGHT', row['next']] if move == 1 else idle
                west = ['LEFT', row['next']] if move == -1 else idle
                identity = ['C', 'SOURCE', row['q'], row['read'], row['next'], row['write'], move]
                _emit(family, identity, source, east, south, west, row['index'],
                      head_marks, meter, counts, palette, witnesses, vertical, horizontal)
        for states, family, tag in ((right, 'RECEIVE_RIGHT', 'RIGHT'),
                                    (left, 'RECEIVE_LEFT', 'LEFT')):
            meter.tick('receiver_state_sort', len(states) * max(1, len(states).bit_length()))
            for target in sorted(states):
                for symbol in normal['alphabet']:
                    meter.tick('receiver_rule_visit')
                    message = [tag, target]
                    _emit(family, ['C', family, target, symbol], ['P', symbol],
                          idle if tag == 'RIGHT' else message,
                          ['H', target, symbol], message if tag == 'RIGHT' else idle,
                          None, head_marks, meter, counts, palette, witnesses, vertical, horizontal)
        glyphs = {'vertical': _catalogue(vertical, meter),
                  'horizontal': _catalogue(horizontal, meter)}
        meter.tick('completion', 1 + len(palette) + len(witnesses))
        if counts['tiles_constructed'] != predicted or sum(counts['families'].values()) != predicted:
            raise RuntimeError('internal complete palette census mismatch')
        counts['vertical_colours'] = len(vertical)
        counts['horizontal_colours'] = len(horizontal)
        counts['complete_census'] = True
        return _receipt('COMPLETE', None, normal, digest, checked_limits,
                        head_marks, effective, glyphs, palette, witnesses, counts, meter)
    except (_Invalid, _Budget) as error:
        if meter is not None and meter.callback_failed:
            raise
        counts['complete_census'] = False
        return _receipt('UNKNOWN_BUDGET' if type(error) is _Budget else 'REJECTED',
                        {'code': error.code, 'detail': error.detail}, normal, digest,
                        checked_limits, selected_marks, None, None, None, None,
                        counts, meter)
