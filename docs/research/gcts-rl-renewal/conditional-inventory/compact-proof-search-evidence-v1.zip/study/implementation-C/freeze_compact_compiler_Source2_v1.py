"""Static minimal successor assembly/ledger only; no compiler functions run."""
import ast,builtins,difflib,hashlib,json,pathlib,re,symtable
D=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1/implementation-C')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,v):
 p=D/name;b=(json.dumps(v,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode('ascii')
 with p.open('xb') as f:f.write(b)
 return pin(p)
p1=D/'compact_ntm_wang_compiler_v1.py';old=p1.read_text();new=old.replace("VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v1'","VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2'")
a="_need(type(value) is dict and all(type(k) is str for k in value)\n          and set(value) == set(names), code, 'exact native record fields')"
b="_need(type(value) is dict and len(value) == len(names)\n          and all(type(k) is str for k in value)\n          and set(value) == set(names), code, 'exact native record fields')"
assert old.count(a)==1;new=new.replace(a,b);p2=D/'compact_ntm_wang_compiler_v2.py'
if p2.exists():assert p2.read_text()==new
else:
 with p2.open('x') as f:f.write(new)
assert new.replace(b,a).replace("VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2'","VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v1'")==old
A=ast.parse(old);B=ast.parse(new);compile(new,str(p2),'exec',dont_inherit=True)
line1=old.splitlines(keepends=True);line2=new.splitlines(keepends=True)
defs1={n.name:n for n in A.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};defs2={n.name:n for n in B.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};assert defs1.keys()==defs2.keys()
ledger=[]
for name,n in defs2.items():
 prev=defs1[name];s1=''.join(line1[prev.lineno-1:prev.end_lineno]);s2=''.join(line2[n.lineno-1:n.end_lineno]);same=s1==s2
 assert same==(name!='_fields')
 ledger.append({'name':name,'kind':type(n).__name__,'lines':[n.lineno,n.end_lineno],'raw_bytes':len(s2.encode()),'raw_sha256':hashlib.sha256(s2.encode()).hexdigest(),'AST_sha256':hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest(),'positioned_AST_sha256':hashlib.sha256(ast.dump(n,include_attributes=True).encode()).hexdigest(),'raw_identical_to_Source1':same,'AST_identical_to_Source1':ast.dump(n,include_attributes=False)==ast.dump(prev,include_attributes=False),'direct_named_calls':sorted({c.func.id for c in ast.walk(n) if isinstance(c,ast.Call) and isinstance(c.func,ast.Name)})})
st=symtable.symtable(new,str(p2),'exec')
def scopes(t):
 flags=['is_referenced','is_parameter','is_global','is_nonlocal','is_declared_global','is_local','is_free','is_imported','is_assigned','is_namespace','is_annotated']
 yield {'name':t.get_name(),'type':t.get_type(),'line':t.get_lineno(),'symbols':[{k:(x.get_name() if k=='name' else getattr(x,k)()) for k in ['name']+flags} for x in t.get_symbols()]}
 for child in t.get_children():yield from scopes(child)
ss=list(scopes(st));gg=set(st.get_identifiers());unresolved=sorted({x['name'] for r in ss[1:] for x in r['symbols'] if x['is_global'] and x['is_referenced'] and x['name'] not in gg and x['name'] not in dir(builtins)});assert not unresolved
oldss=list(scopes(symtable.symtable(old,str(p1),'exec')))
assert [{k:v for k,v in r.items() if k!='line'} for r in oldss if r['name']!='_fields']==[{k:v for k,v in r.items() if k!='line'} for r in ss if r['name']!='_fields']
oldfields=next(r for r in oldss if r['name']=='_fields');newfields=next(r for r in ss if r['name']=='_fields')
assert {x['name'] for x in newfields['symbols']}-{x['name'] for x in oldfields['symbols']}=={'len'}
assert [x for x in newfields['symbols'] if x['name']!='len']==oldfields['symbols']
# Complete unified-patch application verified as bytes, never executing output.
def apply(text,patch):
 src=text.splitlines(keepends=True);ls=patch.splitlines(keepends=True);out=[];cursor=0;i=2
 while i<len(ls):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:[^\n]*)\n?',ls[i]);assert m
  start=int(m[1])-1;assert start>=cursor;out.extend(src[cursor:start]);cursor=start;i+=1
  while i<len(ls) and not ls[i].startswith('@@ '):
   prefix,payload=ls[i][0],ls[i][1:];assert prefix in (' ','-','+')
   if prefix in (' ','-'):assert src[cursor]==payload;cursor+=1
   if prefix in (' ','+'):out.append(payload)
   i+=1
 out.extend(src[cursor:]);return ''.join(out)
patches=[]
for direction,x,y in [('forward',old,new),('inverse',new,old)]:
 delta=''.join(difflib.unified_diff(x.splitlines(keepends=True),y.splitlines(keepends=True),fromfile='before/compiler',tofile='after/compiler'));assert apply(x,delta)==y
 p=D/('compact-compiler-v1-v2-full-'+direction+'-v1.patch')
 with p.open('x') as f:f.write(delta)
 patches.append(pin(p))
assert ast.dump(ast.parse(apply(new,pathlib.Path(patches[1]['path']).read_text())),include_attributes=True)==ast.dump(A,include_attributes=True)
L=pathlib.Path('/private/tmp/gcts-L-R-compact-compiler-peer-v1/compact-compiler-complete-independent-Source-peer-review-v1.json');lr=pin(L);assert lr['bytes']==3844 and lr['sha256']=='1064e64deda1b1d9dfd347f83141269bbf7885d9ae38aafc3f4d20c2a680eae3'
staticref=save('compact-NTM-Wang-compiler-Source2-complete-static-helper-ledger-v1.json',{'schema':'C-compact-compiler-Source2-complete-static-v1','status':'STATIC_PASS_ALL_SUBJECTS_UNRUN','Source':pin(p2),'top_helpers':ledger,'all_scopes':ss,'scope_count':len(ss),'top_helper_count':len(ledger),'unresolved_globals':unresolved,'symtable_flags_exact_except_new_referenced_builtin_len_in_fields':True,'whole_AST_sha256':hashlib.sha256(ast.dump(B,include_attributes=False).encode()).hexdigest(),'whole_positioned_AST_sha256':hashlib.sha256(ast.dump(B,include_attributes=True).encode()).hexdigest(),'unused_compile':'PASS discarded codeobject never executed','module_top_calls':0,'preserved_cap_and_algorithm_scope':'Only VERSION and _fields cardinality guard changed.16other tophelpers raw/plainAST identical; same controls/signatures/limits/families/counts/mark geometry.'})
preservation=save('compact-NTM-Wang-compiler-Source1-Source2-complete-preservation-v1.json',{'schema':'C-compact-compiler-Source1-Source2-preservation-v1','status':'STATIC_FULL_RAW_INVERSE_PASS','Source1':pin(p1),'Source2':pin(p2),'accepted_finding':lr,'repair':'Exact dict type shortcircuit then len(value)==len(names) BEFORE all(keys)/set(value); reject arbitrary wrongshape cardinality without scanning/copying its keys. Applies both limits2 before meter and machine5 validation.','only_changed_top_helper':'_fields','raw_identical_top_helpers':[r['name'] for r in ledger if r['raw_identical_to_Source1']],'only_changed_global':'VERSION-v1 to VERSION-v2','wire_schema_unchanged':'C-compact-directional-NTM-Wang-compile-result-v1','signatures_and_control_requirements_unchanged':True,'full_forward_inverse_patches':patches,'exact_unified_patch_apply_both_directions':True,'whole_positioned_AST_inverse_exact':True,'scope':'Source1 preserved negative/unrun; currentSource2 contains no other changes, no new fixture/call/cap/algorithm or math scope. No subject execution.'})
api=json.loads((D/'compact-NTM-Wang-compiler-complete-public-ABI-v1.json').read_bytes());api['schema']='C-compact-directional-NTM-Wang-compiler-complete-public-ABI-v2';api['Source']=pin(p2);api['VERSION']='COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2';api['status']='CURRENT_SOURCE2_COMPLETE_INERT_UNRUN';api['Source_revision']='New Source2 path/version, unchanged wire schema/signature/fields/algorithm/cases/caps. Sole accepted preexecution malformed-cardinality preflight repair.';api['predecessor_Source1_negative']=lr;api['cardinality_preflight']='type(value)isdict and len(value)==len(names) before keys all/set. Thus wrongcardinality dict never key-scanned/copied by _fields, including limits before Meter.';api['complete_Source1_Source2_preservation']=preservation
apiref=save('compact-NTM-Wang-compiler-complete-public-ABI-v2.json',api)
manual=json.loads((D/'compact-NTM-Wang-compiler-complete-helper-walkthrough-v1.json').read_bytes());manual['schema']='C-compact-NTM-Wang-compiler-complete-helper-walkthrough-v2';manual['Source']=pin(p2);manual['public_ABI']=apiref
for row,current in zip(manual['helpers'],ledger,strict=True):
 assert row['name']==current['name'];row['lines']=current['lines'];row['raw_sha256']=current['raw_sha256']
 if row['name']=='_fields':row['walkthrough']='Exactnative dict type, then exact cardinality BEFORE scanning allkeys or constructing keyset; only matching-size keys inspect/string/set equivalence. One material malformed-resource preflight fix, no valid-input semantics change.'
manual['Source2_preservation']=preservation
manualref=save('compact-NTM-Wang-compiler-complete-helper-walkthrough-v2.json',manual)
proof=json.loads((D/'compact-NTM-Wang-compiler-correspondence-and-preservation-argument-v1.json').read_bytes());proof['schema']='C-compact-NTM-Wang-compiler-correspondence-and-preservation-v2';proof['Source']=pin(p2);proof['Source2_preservation']=preservation;proofref=save('compact-NTM-Wang-compiler-correspondence-and-preservation-argument-v2.json',proof)
controls=json.loads((D/'compact-NTM-Wang-compiler-prefrozen-control-requirements-v1.json').read_bytes());controls['schema']='C-compact-NTM-Wang-compiler-control-requirements-v2';controls['Source']=pin(p2);controls['Source2_note']='All control/case requirements unchanged; cardinality preflight repair needs focused Sourcepeer, no new solves/cases.';controlref=save('compact-NTM-Wang-compiler-prefrozen-control-requirements-v2.json',controls)
oldhand=json.loads((D/'compact-NTM-Wang-compiler-complete-inert-Source-handoff-v1.json').read_bytes())
hand={'schema':'C-compact-NTM-Wang-compiler-complete-inert-Source-handoff-v2','status':'FROZEN_CURRENT_SOURCE2_COMPLETE_INERT_UNRUN','Source':pin(p2),'public_ABI':apiref,'complete_static_helper_ledger':staticref,'complete_helper_walkthrough':manualref,'correspondence_and_preservation_argument':proofref,'prefrozen_control_requirements':controlref,'Source1_Source2_fullpreservation':preservation,'two_complete_patches':patches,'negative_predecessor_peer':lr,'contract':oldhand['contract'],'primary_master':oldhand['primary_master'],'prior_math':oldhand['prior_math'],'static_census':oldhand['static_census'],'revision':'Only _fields cardinality-first resource precheck plus newVERSION/path. All16other helper bodies, algorithm/families/counts/pointmarkscope/limits/cohortrequirements unchanged. Source1 never edited, allsubjectcalls0.','remaining':'Focused independent Source2peer/Rootadoption then new closedqualification/caller/freshonce. No Sources/imports/helpers/constructor/factory/model/fixture/CLI/tests/codeobject execution or grants.'}
hand['static_census']['source_lines']=len(line2)
ref=save('compact-NTM-Wang-compiler-complete-inert-Source-handoff-v2.json',hand)
print(json.dumps({'handoff':ref,'Source':pin(p2),'API':apiref,'preservation':preservation,'static':staticref,'manual':manualref,'proof':proofref,'controls':controlref}))
