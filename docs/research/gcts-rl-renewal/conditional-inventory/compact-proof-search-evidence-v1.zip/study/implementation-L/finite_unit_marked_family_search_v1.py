"""Inert finite singleton-t point families; no proof/clause oracle or entrypoint.

Unit finite roots only. All normal work and variable growth is precharged.
Mandatory rollback after refusal is bounded by the admitted trail and is counted
separately without invoking an already refusing callback. No hard OS quota.
"""
import hashlib
import json
import time

VERSION = 'R-FINITE-UNIT-MARKED-FAMILY-SEARCH-v1'
BUILDER_VERSION = 'R-EXACT-BYTE-POINT-MODEL-v1'
MODEL_SCHEMA = 'R-finite-singleton-mark-families-v1'
LIMIT_FIELDS = ('max_operations', 'max_seconds', 'max_points', 'max_groups',
                'max_variants', 'max_mark_entries', 'max_trail_entries',
                'max_nodes', 'max_trace_events', 'max_name_bytes',
                'max_integer_bits', 'max_model_bytes')
ALL_BYTES = (1 << 256) - 1


class ModelError(ValueError):
    """Invalid exact public input/profile; never an exhausted-search result."""


class SearchBudgetExceeded(Exception):
    """Owned cooperative refusal. Other callback exceptions propagate."""


def _need(ok, message):
    if not ok:
        raise ModelError(message)


def _fields(value, names):
    _need(type(value) is dict and len(value) == len(names), 'exact record cardinality')
    _need(all(type(k) is str for k in value) and set(value) == set(names), 'exact record fields')


def _limits(value):
    _fields(value, LIMIT_FIELDS)
    _need(all(type(value[k]) is int and value[k] >= 0 for k in LIMIT_FIELDS),
          'limits are exact nonnegative integers')
    return dict(value)


class _Meter:
    def __init__(self, limits, budget):
        _need(budget is None or callable(budget), 'budget callable or None')
        self.limits = _limits(limits)
        self.budget = budget
        self.started = time.monotonic()
        self.operations = 0
        self.callbacks = 0
        self.cleanup_operations = 0

    def tick(self, amount=1):
        proposed = self.operations + amount
        if proposed > self.limits['max_operations']:
            raise SearchBudgetExceeded('operation cap before owned work')
        if time.monotonic() - self.started > self.limits['max_seconds']:
            raise SearchBudgetExceeded('cooperative main-entry wall cap')
        self.operations = proposed
        if self.budget is not None:
            self.callbacks += 1
            self.budget()

    def bound(self, amount, key):
        self.tick()
        if amount > self.limits[key]:
            raise SearchBudgetExceeded(key + ' before owned growth')

    def costs(self):
        return {'operations': self.operations, 'budget_callbacks': self.callbacks,
                'rollback_cleanup_operations': self.cleanup_operations,
                'elapsed_main_entry_seconds': time.monotonic() - self.started}


def _name(value, meter):
    _need(type(value) is str and value, 'nonempty exact string')
    meter.bound(len(value), 'max_name_bytes')
    meter.tick(4 * len(value))
    try:
        raw = value.encode('utf-8')
    except UnicodeEncodeError as error:
        raise ModelError('name must have valid UTF-8 encoding') from error
    meter.bound(len(raw), 'max_name_bytes')
    return value


def _integer(value, meter):
    _need(type(value) is int, 'integer, not bool/float')
    meter.bound(value.bit_length(), 'max_integer_bits')
    meter.tick(value.bit_length())
    if value.bit_length() > 4096:
        raise SearchBudgetExceeded('defensive native JSON integer width4096 before serialization')
    return value


def _point(value, meter):
    _need(type(value) is list and len(value) == 3, 'exact point list triple')
    meter.tick(3)
    return tuple(_integer(x, meter) for x in value)


def _mark_list(value, meter, account):
    _need(type(value) is list, 'mark list')
    meter.bound(account[0] + len(value), 'max_mark_entries')
    meter.tick(len(value))
    answer = []
    seen = set()
    for row in value:
        _need(type(row) is list and len(row) == 2, 'mark exact pair')
        p, v = _point(row[0], meter), _integer(row[1], meter)
        _need(p not in seen, 'one assignment per point within marking')
        meter.tick(2)
        seen.add(p)
        answer.append((p, v))
    account[0] += len(value)
    return answer


def _sort(values, meter, key=None):
    meter.tick(len(values) * max(1, len(values).bit_length()))
    return sorted(values, key=key)


def _json_bound(value, meter):
    # Internal normalized model/event shapes have fixed shallow nesting.
    # ASCII JSON escape expansion and decimal integers are bounded before encode.
    meter.tick()
    if value is None:
        return 4
    if type(value) is bool:
        return 5
    if type(value) is int:
        return max(1, value.bit_length()) + 2
    if type(value) is str:
        return 2 + 6 * len(value)
    if type(value) in (list, tuple):
        return 2 + len(value) + sum(_json_bound(x, meter) for x in value)
    assert type(value) is dict
    return 2 + 2 * len(value) + sum(_json_bound(k, meter) + _json_bound(v, meter)
                                     for k, v in value.items())


def _digest(value, meter):
    upper = _json_bound(value, meter) + 1
    meter.bound(upper, 'max_model_bytes')
    meter.tick(upper)
    h = hashlib.sha256()
    extent = 0
    encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                               separators=(',', ':'), allow_nan=False)
    for part in encoder.iterencode(value):
        meter.tick(len(part))
        raw = part.encode('ascii')
        extent += len(raw)
        meter.bound(extent, 'max_model_bytes')
        h.update(raw)
    meter.tick()
    meter.bound(extent + 1, 'max_model_bytes')
    h.update(b'\n')
    return h.hexdigest()


def _normalize(model, meter):
    _fields(model, ('schema', 'version', 'points', 'fixed_marks', 'groups'))
    _need(model['schema'] == MODEL_SCHEMA, 'finite singleton model schema')
    version = _name(model['version'], meter)
    points = model['points']
    _need(type(points) is list, 'complete target point list')
    meter.bound(len(points), 'max_points')
    meter.tick(len(points))
    targets = []
    seen = set()
    for row in points:
        p = _point(row, meter)
        _need(p not in seen, 'unique target point')
        meter.tick(2)
        seen.add(p)
        targets.append(p)
    targets = _sort(targets, meter)
    account = [0]
    fixed = _mark_list(model['fixed_marks'], meter, account)
    fixed = _sort(fixed, meter, key=lambda x: x[0])
    rawgroups = model['groups']
    _need(type(rawgroups) is list, 'complete family group list')
    meter.bound(len(rawgroups), 'max_groups')
    meter.tick(len(rawgroups))
    groups = []
    ids = set()
    universe = 0
    for row in rawgroups:
        _need(type(row) is dict and len(row) in (4, 5), 'group cardinality')
        kind = row.get('kind')
        _need(kind in ('byte', 'explicit'), 'group kind')
        _fields(row, ('id', 'kind', 'anchor', 'mark_point', 'allowed_mask') if kind == 'byte'
                else ('id', 'kind', 'anchor', 'variants'))
        name = _name(row['id'], meter)
        _need(name not in ids, 'unique group identity')
        anchor = _point(row['anchor'], meter)
        _need(anchor in seen, 'every positive unit anchor is a required target')
        if kind == 'byte':
            mask = row['allowed_mask']
            _need(type(mask) is int and 0 <= mask <= ALL_BYTES, 'complete 256-bit byte mask')
            mark = _point(row['mark_point'], meter)
            meter.bound(max(0, mask.bit_length() - 1).bit_length(), 'max_integer_bits')
            universe += mask.bit_count()
            meter.bound(universe, 'max_variants')
            meter.bound(account[0] + 1, 'max_mark_entries')
            account[0] += 1
            meter.tick(2)
            group = {'id': name, 'kind': kind, 'anchor': anchor,
                     'mark_point': mark, 'allowed_mask': mask}
        else:
            variants = row['variants']
            _need(type(variants) is list, 'complete ordered explicit variants')
            universe += len(variants)
            meter.bound(universe, 'max_variants')
            meter.tick(len(variants))
            copied = []
            for marks in variants:
                item = _mark_list(marks, meter, account)
                meter.tick()
                copied.append(item)
            group = {'id': name, 'kind': kind, 'anchor': anchor, 'variants': copied}
        meter.tick(2)
        ids.add(name)
        groups.append(group)
    groups = _sort(groups, meter, key=lambda g: g['id'])
    canonical = {'schema': MODEL_SCHEMA, 'version': version, 'points': targets,
                 'fixed_marks': fixed, 'groups': groups}
    digest = _digest(canonical, meter)
    return canonical, digest, universe, account[0]


class _State:
    def __init__(self, model, meter):
        self.meter = meter
        self.model, self.digest, self.universe, self.mark_entries = _normalize(model, meter)
        self.points = self.model['points']
        self.groups = self.model['groups']
        n, g = len(self.points), len(self.groups)
        meter.tick(n * 8 + g * 10)
        self.point_index = {p: i for i, p in enumerate(self.points)}
        self.group_index = {row['id']: i for i, row in enumerate(self.groups)}
        self.anchors = [self.point_index[row['anchor']] for row in self.groups]
        self.at = [[] for _ in self.points]
        self.dependencies = {}
        self.supports = []
        self.base = []
        for gi, row in enumerate(self.groups):
            meter.tick()
            self.at[self.anchors[gi]].append(gi)
            if row['kind'] == 'byte':
                support = None
                mask = row['allowed_mask']
                dep_points = (row['mark_point'],)
            else:
                meter.tick(len(row['variants']) + 1)
                mask = (1 << len(row['variants'])) - 1
                support = {}
                for vi, marks in enumerate(row['variants']):
                    meter.tick((vi // 64) + 1)
                    bit = 1 << vi
                    for p, value in marks:
                        meter.tick((vi // 64) + 4)
                        if p not in support:
                            support[p] = [0, {}]
                        support[p][0] |= bit
                        values = support[p][1]
                        values[value] = values.get(value, 0) | bit
                dep_points = support
            for p in dep_points:
                meter.tick(2)
                if p not in self.dependencies:
                    self.dependencies[p] = []
                self.dependencies[p].append(gi)
            meter.tick(2)
            self.supports.append(support)
            self.base.append(mask)
        meter.tick(n * 3 + g * 3 + len(self.model['fixed_marks']))
        self.domains = [0] * g
        self.excluded = [0] * g
        self.selected = [None] * g
        self.totals = [0] * n
        self.counts = [0] * n
        self.marks = {p: (value, 1) for p, value in self.model['fixed_marks']}
        self.frontier, self.dead, self.forced = set(), set(), set()
        self.trail = []
        self.events = []
        self.event_hash = hashlib.sha256()
        self.prefix_hash = hashlib.sha256()
        self.event_count = 0
        self.event_bytes = 0
        self.prefix_bytes = 0
        self.statistics = {'nodes': 0, 'forced_placements': 0, 'branch_decisions': 0,
                           'backtracks': 0, 'exclusions': 0, 'domain_updates': 0,
                           'candidate_eliminations': 0, 'dependency_group_visits': 0,
                           'preference_checks': 0, 'preferred_branches': 0,
                           'trail_entries_written': 0, 'trail_entries_undone': 0,
                           'max_trail_size': 0, 'max_search_frames': 0}
        for gi in range(g):
            mask = self._legal(gi)
            meter.tick(2)
            self.domains[gi] = mask
            self.counts[self.anchors[gi]] += mask.bit_count()
        for pi in range(n):
            meter.tick(3)
            self.frontier.add(pi)
            if self.counts[pi] == 0:
                self.dead.add(pi)
            elif self.counts[pi] == 1:
                self.forced.add(pi)
        meter.tick(g * 2 + n + len(self.marks))
        self.root_domains = tuple(self.domains)
        self.root_counts = tuple(self.counts)
        self.root_marks = dict(self.marks)
        self.entry = self.snapshot()

    def _hex(self, value):
        self.meter.tick(max(1, (value.bit_length() + 3) // 4))
        return format(value, 'x')

    def _emit(self, kind, data):
        self.meter.tick()
        event = {'seq': self.event_count, 'kind': kind, 'data': data}
        upper = _json_bound(event, self.meter) + 1
        self.meter.tick(upper)
        raw = (json.dumps(event, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        assert len(raw) <= upper
        self.meter.tick(len(raw) + (1 if len(self.events) < self.meter.limits['max_trace_events'] else 0))
        self.event_hash.update(raw)
        self.event_count += 1
        self.event_bytes += len(raw)
        if len(self.events) < self.meter.limits['max_trace_events']:
            self.events.append(event)
            self.prefix_hash.update(raw)
            self.prefix_bytes += len(raw)

    def _wire(self, kind, value):
        if kind in ('domain', 'excluded'):
            return self._hex(value)
        if type(value) is tuple:
            self.meter.tick(len(value))
            return list(value)
        return value

    def _put(self, kind, key, value):
        obj = {'domain': self.domains, 'excluded': self.excluded,
               'selected': self.selected, 'total': self.totals,
               'count': self.counts, 'mark': self.marks,
               'frontier': self.frontier, 'dead': self.dead, 'forced': self.forced}[kind]
        old = obj.get(key) if kind == 'mark' else (key in obj if kind in ('frontier', 'dead', 'forced') else obj[key])
        if old == value:
            return
        self.meter.bound(len(self.trail) + 1, 'max_trail_entries')
        self.meter.tick()
        self.trail.append((kind, key, old))
        if kind == 'mark':
            if value is None:
                obj.pop(key, None)
            else:
                obj[key] = value
        elif kind in ('frontier', 'dead', 'forced'):
            if value:
                obj.add(key)
            else:
                obj.discard(key)
        else:
            obj[key] = value
        self.statistics['trail_entries_written'] += 1
        self.statistics['max_trail_size'] = max(self.statistics['max_trail_size'], len(self.trail))
        self._emit('CHANGE', {'field': kind, 'key': self._wire('key', key),
                             'old': self._wire(kind, old), 'new': self._wire(kind, value),
                             'trail_size': len(self.trail)})

    def _refresh(self, pi):
        active = self.totals[pi] == 0
        self._put('frontier', pi, active)
        self._put('dead', pi, active and self.counts[pi] == 0)
        self._put('forced', pi, active and self.counts[pi] == 1)

    def _legal(self, gi):
        self.meter.tick(max(1, (self.base[gi].bit_length() + 63) // 64))
        if self.totals[self.anchors[gi]]:
            return 0
        mask = self.base[gi] & ~self.excluded[gi]
        group = self.groups[gi]
        if group['kind'] == 'byte':
            mark = self.marks.get(group['mark_point'])
            if mark is not None:
                value = mark[0]
                mask &= (1 << value) if 0 <= value < 256 else 0
        else:
            for p, (any_mask, values) in self.supports[gi].items():
                self.meter.tick(max(1, (self.base[gi].bit_length() + 63) // 64))
                if p in self.marks:
                    mask &= ~(any_mask & ~values.get(self.marks[p][0], 0))
        return mask

    def _update_group(self, gi):
        self.statistics['dependency_group_visits'] += 1
        new = self._legal(gi)
        old = self.domains[gi]
        if new != old:
            self.statistics['domain_updates'] += 1
            self.statistics['candidate_eliminations'] += (old & ~new).bit_count()
            self._put('domain', gi, new)
            pi = self.anchors[gi]
            self._put('count', pi, self.counts[pi] + new.bit_count() - old.bit_count())
            self._refresh(pi)

    def _candidate_marks(self, gi, value):
        group = self.groups[gi]
        if group['kind'] == 'byte':
            return ((group['mark_point'], value),)
        return group['variants'][value]

    def place(self, gi, value, forced):
        self.meter.bound(self.statistics['nodes'] + 1, 'max_nodes')
        self.meter.tick()
        assert self.domains[gi] & (1 << value)
        pi = self.anchors[gi]
        assert not self.totals[pi] and self.selected[gi] is None
        self.statistics['nodes'] += 1
        self.statistics['forced_placements' if forced else 'branch_decisions'] += 1
        self._put('total', pi, 1)
        self._refresh(pi)
        self._put('selected', gi, value)
        # Positive-support and every mark-only dependency, regardless of Q.
        self.meter.tick(len(self.at[pi]))
        affected = set(self.at[pi])
        for p, markvalue in self._candidate_marks(gi, value):
            self.meter.tick()
            old = self.marks.get(p)
            assert old is None or old[0] == markvalue
            self._put('mark', p, (markvalue, 1 if old is None else old[1] + 1))
            self.meter.tick(len(self.dependencies[p]))
            affected.update(self.dependencies[p])
        for other in _sort(affected, self.meter):
            self._update_group(other)
        self._emit('PLACED', {'candidate': [self.groups[gi]['id'], value],
                              'forced': forced, 'generation': 1,
                              'root_point_generation': 0})

    def rollback(self, checkpoint, event=True):
        assert 0 <= checkpoint <= len(self.trail)
        undone = 0
        while len(self.trail) > checkpoint:
            kind, key, old = self.trail.pop()
            obj = {'domain': self.domains, 'excluded': self.excluded,
                   'selected': self.selected, 'total': self.totals,
                   'count': self.counts, 'mark': self.marks,
                   'frontier': self.frontier, 'dead': self.dead, 'forced': self.forced}[kind]
            if kind == 'mark':
                if old is None:
                    obj.pop(key, None)
                else:
                    obj[key] = old
            elif kind in ('frontier', 'dead', 'forced'):
                if old:
                    obj.add(key)
                else:
                    obj.discard(key)
            else:
                obj[key] = old
            undone += 1
        self.statistics['trail_entries_undone'] += undone
        self.meter.cleanup_operations += undone
        if event:
            self._emit('ROLLBACK', {'checkpoint': checkpoint, 'entries_undone': undone})

    def exclude(self, gi, value):
        self.meter.tick()
        assert not self.excluded[gi] & (1 << value)
        self._put('excluded', gi, self.excluded[gi] | (1 << value))
        self.statistics['exclusions'] += 1
        self._update_group(gi)
        self._emit('EXCLUDED', {'candidate': [self.groups[gi]['id'], value],
                                'scope': 'this restored parent context only'})

    def first(self, pi, preferences):
        for gi, value in preferences:
            self.meter.tick()
            self.statistics['preference_checks'] += 1
            if self.anchors[gi] == pi and self.domains[gi] & (1 << value):
                self.statistics['preferred_branches'] += 1
                return gi, value
        for gi in self.at[pi]:
            self.meter.tick()
            mask = self.domains[gi]
            if mask:
                return gi, (mask & -mask).bit_length() - 1
        raise AssertionError('complete nonempty point domain')

    def snapshot(self):
        # Only entry/terminal snapshots, never a whole-state copy per placement.
        self.meter.tick(len(self.points) * 6 + len(self.groups) * 5 + len(self.marks))
        totals = [[list(p), self.totals[i]] for i, p in enumerate(self.points)]
        markings = [[list(p), v, refs] for p, (v, refs) in _sort(self.marks.items(), self.meter)]
        domains = [[g['id'], self._hex(self.domains[i])] for i, g in enumerate(self.groups)]
        selected = [[g['id'], self.selected[i]] for i, g in enumerate(self.groups) if self.selected[i] is not None]
        excluded = [[g['id'], self._hex(self.excluded[i])] for i, g in enumerate(self.groups)]
        frontier = [[list(self.points[i]), 0, self.counts[i]] for i in _sort(self.frontier, self.meter)]
        forward = []
        for pi in _sort(self.frontier, self.meter):
            self.meter.tick(len(self.at[pi]) + 1)
            forward.append([list(self.points[pi]), [[self.groups[gi]['id'], self._hex(self.domains[gi])]
                                                   for gi in self.at[pi] if self.domains[gi]]])
        reverse = [[g['id'], list(g['anchor']), self._hex(self.domains[i])]
                   for i, g in enumerate(self.groups)]
        return {'schema': 'R-finite-unit-family-state-v1', 'totals': totals,
                'markings': markings, 'domains': domains, 'selected': selected,
                'excluded': excluded, 'frontier': frontier,
                'forward_incidence': forward, 'reverse_incidence': reverse}

    def certify(self):
        self.meter.tick(len(self.points) + len(self.marks))
        totals = [0] * len(self.points)
        marks = dict(self.root_marks)
        chosen = []
        for gi, value in enumerate(self.selected):
            self.meter.tick()
            if value is None:
                continue
            assert self.base[gi] & (1 << value)
            pi = self.anchors[gi]
            totals[pi] += 1
            self.meter.tick()
            chosen.append([self.groups[gi]['id'], value])
            for p, v in self._candidate_marks(gi, value):
                self.meter.tick()
                old = marks.get(p)
                assert old is None or old[0] == v
                marks[p] = (v, 1 if old is None else old[1] + 1)
        assert all(x == 1 for x in totals) and totals == self.totals
        assert marks == self.marks and not self.frontier
        self.meter.tick()
        return chosen

    def root_restored(self):
        # Mandatory bounded cleanup check, not skipped by a rejecting callback.
        self.meter.cleanup_operations += len(self.groups) * 3 + len(self.points) * 4 + len(self.marks)
        return (not self.trail and all(a == b for a, b in zip(self.domains, self.root_domains))
                and all(a == b for a, b in zip(self.counts, self.root_counts))
                and all(x == 0 for x in self.totals) and all(x == 0 for x in self.excluded)
                and all(x is None for x in self.selected) and self.marks == self.root_marks
                and len(self.frontier) == len(self.points)
                and all((i in self.dead) == (v == 0) and (i in self.forced) == (v == 1)
                        for i, v in enumerate(self.root_counts)))


def _preferences(value, state):
    if value is None:
        return ()
    _need(type(value) is list, 'preferences are ordered list or None')
    state.meter.bound(len(value), 'max_variants')
    state.meter.tick(len(value))
    answer, seen = [], set()
    for row in value:
        _need(type(row) is list and len(row) == 2, 'preference candidate exact pair')
        _need(type(row[0]) is str and type(row[1]) is int, 'candidate group string/exact index')
        state.meter.bound(len(row[0]), 'max_name_bytes')
        state.meter.tick(len(row[0]))
        _need(row[0] in state.group_index, 'known candidate group')
        gi, vi = state.group_index[row[0]], row[1]
        _need(0 <= vi < state.base[gi].bit_length(), 'preference index in full universe')
        state.meter.tick(max(1, (vi // 64) + 1))
        _need(bool(state.base[gi] & (1 << vi)), 'represented base preference candidate')
        _need((gi, vi) not in seen, 'unique preference candidate')
        state.meter.tick(2)
        seen.add((gi, vi))
        answer.append((gi, vi))
    return answer


def solve(model, limits, preferences=None, *, budget=None):
    """Exact finite unit point search; no global clause/checker semantics."""
    meter = _Meter(limits, budget)
    state = None
    status, reason = 'UNKNOWN', None
    solution = solution_state = None
    try:
        state = _State(model, meter)
        ordered = _preferences(preferences, state)
        frames = []
        while True:
            meter.tick()
            if state.dead:
                meter.tick(len(state.dead))
                state._emit('GLOBAL_DEAD', {'point': list(state.points[min(state.dead)])})
                if not frames:
                    status = 'UNSAT'
                    reason = 'complete finite root domain exhaustion'
                    break
                checkpoint, gi, vi = frames.pop()
                state.rollback(checkpoint)
                state.statistics['backtracks'] += 1
                state.exclude(gi, vi)
                continue
            if state.forced:
                meter.tick(len(state.forced))
                pi = min(state.forced)
                gi, vi = state.first(pi, ())
                state.place(gi, vi, True)
                continue
            if not state.frontier:
                solution = state.certify()
                solution_state = state.snapshot()
                status, reason = 'SAT', 'complete finite unit t/m solution internally checked'
                break
            meter.tick(len(state.frontier))
            pi = min(state.frontier)
            gi, vi = state.first(pi, ordered)
            meter.bound(len(frames) + 1, 'max_points')
            meter.tick()
            frames.append((len(state.trail), gi, vi))
            state.statistics['max_search_frames'] = max(state.statistics['max_search_frames'], len(frames))
            state._emit('BRANCH', {'point': list(state.points[pi]),
                                    'generation': 0, 'degree': state.counts[pi],
                                    'candidate': [state.groups[gi]['id'], vi]})
            state.place(gi, vi, False)
        meter.tick()
    except SearchBudgetExceeded as error:
        status, reason = 'UNKNOWN', str(error)
        solution = solution_state = None
    finally:
        if state is not None:
            state.rollback(0, event=False)
            assert state.root_restored(), 'complete entry restoration'
    restored = None
    if state is not None:
        try:
            restored = state.snapshot()
            meter.tick()
        except SearchBudgetExceeded as error:
            status, reason = 'UNKNOWN', 'restored-image resource refusal: ' + str(error)
            solution = solution_state = None
    if status != 'SAT':
        solution = solution_state = None
    if state is None:
        trace = {'events': [], 'event_count': 0, 'retained_count': 0,
                 'full_JSONL_bytes': 0, 'retained_JSONL_bytes': 0,
                 'full_SHA256': hashlib.sha256(b'').hexdigest(),
                 'retained_SHA256': hashlib.sha256(b'').hexdigest(), 'complete': False}
        counts, entry, digest = {}, None, None
    else:
        trace = {'events': state.events, 'event_count': state.event_count,
                 'retained_count': len(state.events), 'full_JSONL_bytes': state.event_bytes,
                 'retained_JSONL_bytes': state.prefix_bytes,
                 'full_SHA256': state.event_hash.hexdigest(),
                 'retained_SHA256': state.prefix_hash.hexdigest(),
                 'complete': status != 'UNKNOWN' and len(state.events) == state.event_count}
        counts = dict(state.statistics)
        counts.update({'target_points': len(state.points), 'groups': len(state.groups),
                       'represented_candidates': state.universe, 'prototype_mark_entries': state.mark_entries})
        entry, digest = state.entry, state.digest
    # Restored image is captured afresh from live restored indexes, never an alias
    # of entry. If a refusing callback prevents its capture it is explicitly null.
    return {'schema': 'R-finite-unit-marked-family-result-v1', 'status': status,
            'version': VERSION, 'model_sha256': digest, 'solution': solution,
            'solution_state': solution_state, 'entry_state': entry, 'restored_state': restored,
            'counts': counts, 'costs': meter.costs(), 'trace': trace,
            'rollback': {'prepared': state is not None, 'entry_restored': state is not None,
                         'trail_remaining': 0, 'scope': 'all mutable indexed state restored; mandatory cleanup bypasses refusing callback and is separately counted'},
            'reason': reason,
            'scope': 'Finite singleton unit t and exact point m equality, all roots generation0. Explicit bounded trace prefix/hash. No fractional/growing/general-geometric tiler, no proof oracle/clause scanner/RL or fixed Wang proof palette. Costs exclude return-record serialization/caller tail.'}


def _byte(value, count, meter):
    _need(type(value) is list and len(value) == 2, 'byte literal exact pair')
    i, b = value
    _need(type(i) is int and 0 <= i < count and type(b) is int and 0 <= b < 256,
          'byte index/value exact range')
    meter.tick()
    return i, b


def make_byte_model(byte_count, fixed_bytes, nogoods, limits, *, budget=None):
    """Compile scoped forbidden joint values into actual equality-mark witnesses."""
    meter = _Meter(limits, budget)
    try:
        _need(type(byte_count) is int and byte_count >= 0, 'exact nonnegative byte_count')
        meter.bound(byte_count, 'max_points')
        _need(type(fixed_bytes) is list, 'fixed byte list')
        meter.bound(len(fixed_bytes), 'max_mark_entries')
        _fields(nogoods, ('binding', 'cuts'))
        binding = nogoods['binding']
        _fields(binding, ('program_sha256', 'theory_sha256', 'goal_sha256', 'byte_count', 'boundary_version'))
        meter.tick(192)
        for k in ('program_sha256', 'theory_sha256', 'goal_sha256'):
            _need(type(binding[k]) is str and re_full_sha(binding[k]), 'context64lowerhex')
        _need(type(binding['byte_count']) is int and binding['byte_count'] == byte_count,
              'bound exact byte capacity')
        _name(binding['boundary_version'], meter)
        _need(type(nogoods['cuts']) is list, 'complete cut list')
        meter.bound(byte_count + len(nogoods['cuts']), 'max_points')
        meter.tick(len(fixed_bytes))
        fixed = {}
        for row in fixed_bytes:
            i, b = _byte(row, byte_count, meter)
            _need(i not in fixed or fixed[i] == b, 'fixed byte values consistent')
            meter.tick()
            fixed[i] = b
        normalized = []
        meter.tick(len(nogoods['cuts']))
        for j, cut in enumerate(nogoods['cuts']):
            _need(type(cut) is list, 'literal list for each cut')
            meter.bound(len(cut), 'max_mark_entries')
            meter.tick(len(cut))
            values = {}
            vacuous = False
            for row in cut:
                i, b = _byte(row, byte_count, meter)
                if i in values and values[i] != b:
                    vacuous = True
                meter.tick()
                values[i] = b
            meter.tick(len(values))
            if any(i in fixed and fixed[i] != b for i, b in values.items()):
                vacuous = True
            residual = [] if vacuous else [[i, b] for i, b in _sort(values.items(), meter) if i not in fixed]
            meter.tick()
            normalized.append({'input_cut_index': j,
                               'status': 'VACUOUS_WHOLE_CUT_DROPPED' if vacuous else 'RETAINED',
                               'literals': residual})
        meter.tick(len(fixed) + 5)
        binding_copy = dict(binding)
        fixed_rows = [[i, b] for i, b in _sort(fixed.items(), meter)]
        context = {'builder_version': BUILDER_VERSION, 'binding': binding_copy,
                   'fixed_bytes': fixed_rows, 'normalized_cuts': normalized}
        version = BUILDER_VERSION + ':' + _digest(context, meter)
        points, marks, groups, byte_ids, clauses = [], [], [], [], []
        universe = mark_count = 0
        for i in range(byte_count):
            meter.bound(len(groups) + 1, 'max_groups')
            meter.bound(universe + 256, 'max_variants')
            meter.bound(mark_count + 1 + len(fixed), 'max_mark_entries')
            meter.tick(10)
            anchor, mark = [2 * i, 0, 0], [2 * i, 0, 1]
            _point(anchor, meter)
            _point(mark, meter)
            gid = _indexed_name('byte:', i, meter)
            points.append(anchor)
            groups.append({'id': gid, 'kind': 'byte', 'anchor': anchor,
                           'mark_point': mark, 'allowed_mask': ALL_BYTES})
            byte_ids.append(gid)
            universe += 256
            mark_count += 1
        for i, b in fixed_rows:
            meter.tick()
            marks.append([[2 * i, 0, 1], b])
        for cut in normalized:
            j = cut['input_cut_index']
            if cut['status'] != 'RETAINED':
                meter.tick()
                clauses.append({'input_cut_index': j, 'anchor': None, 'groups': []})
                continue
            anchor = [2 * j, 2, 0]
            _point(anchor, meter)
            meter.tick()
            points.append(anchor)
            mapping = []
            for k, (i, b) in enumerate(cut['literals']):
                meter.bound(len(groups) + 1, 'max_groups')
                meter.bound(universe + 255, 'max_variants')
                meter.bound(mark_count + 1 + len(fixed), 'max_mark_entries')
                meter.tick(8)
                gid = _indexed_name(_indexed_name('clause:', j, meter) + ':literal:', k, meter)
                groups.append({'id': gid, 'kind': 'byte', 'anchor': anchor,
                               'mark_point': [2 * i, 0, 1],
                               'allowed_mask': ALL_BYTES ^ (1 << b)})
                mapping.append({'byte_index': i, 'forbidden_byte': b, 'group_id': gid})
                universe += 255
                mark_count += 1
            meter.tick()
            clauses.append({'input_cut_index': j, 'anchor': anchor, 'groups': mapping})
        model = {'schema': MODEL_SCHEMA, 'version': version, 'points': points,
                 'fixed_marks': marks, 'groups': groups}
        # Full typed model normalization is separately charged and rejects no prefix.
        _normalize(model, meter)
        meter.tick()
        return {'schema': 'R-byte-point-model-construction-v1', 'status': 'COMPLETE',
                'version': BUILDER_VERSION, 'model': model, 'binding': binding_copy,
                'byte_group_ids': byte_ids, 'clause_witness_groups': clauses,
                'normalized_cuts': normalized,
                'counts': {'bytes': byte_count, 'fixed_bytes': len(fixed),
                           'input_cuts': len(normalized), 'retained_cuts': sum(x['status'] == 'RETAINED' for x in normalized),
                           'groups': len(groups), 'represented_candidates': universe,
                           'costs': meter.costs()}, 'reason': None,
                'scope': 'Existential auxiliary equality-mark witnesses encode scoped forbidden joint byte values. Context digests are caller bindings, not cut-soundness authority. Additional learned families are not a fixed primitive Wang proof palette.'}
    except SearchBudgetExceeded as error:
        return {'schema': 'R-byte-point-model-construction-v1', 'status': 'UNKNOWN',
                'version': BUILDER_VERSION, 'model': None, 'binding': None,
                'byte_group_ids': None, 'clause_witness_groups': None,
                'normalized_cuts': None, 'counts': {'costs': meter.costs()},
                'reason': str(error), 'scope': 'No partial model or cut declaration from resource-refused construction.'}


def _indexed_name(prefix, index, meter):
    # bit_length+1 is a conservative decimal-size preallocation bound.
    size = len(prefix) + max(1, index.bit_length())
    meter.bound(size, 'max_name_bytes')
    meter.tick(size)
    return _name(prefix + str(index), meter)


def re_full_sha(value):
    return len(value) == 64 and all(c in '0123456789abcdef' for c in value)
