import ast,difflib,hashlib,json,pathlib,re,symtable,sys
R=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1/root');O=pathlib.Path('/private/tmp/gcts-L-R-oracle-boundary-qualifier-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def J(p):return json.loads(pathlib.Path(p).read_bytes())
def chk(r):assert ref(r['path'])==r;return r
def save(n,d):
 p=O/n;b=(json.dumps(d,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return ref(p)
hp=R/'oracle-boundary-qualification-complete-inert-Source-handoff-v2.json';h=J(hp);assert ref(hp)['sha256']=='9d97b54f446e71f8404f57ffd9579f6049ae2d015b86910d52a1ca5ddc7a07e0';pins=[ref(hp)]
for k,v in h.items():
 if type(v)is dict and set(v)=={'path','bytes','sha256'}:pins.append(chk(v))
a=R/'qualify_oracle_boundary_v1.py';b=pathlib.Path(h['Source']['path']);ab=a.read_bytes();bb=b.read_bytes();at=ast.parse(ab);bt=ast.parse(bb)
def apply(src,patch):
 lines=src.decode().splitlines(keepends=True);ps=patch.decode().splitlines(keepends=True);out=[];i=0;k=2
 while k<len(ps):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',ps[k]);assert m;pos=int(m[1])-1;out.extend(lines[i:pos]);i=pos;k+=1
  while k<len(ps) and not ps[k].startswith('@@ '):
   x=ps[k];k+=1
   if x.startswith(' '):assert lines[i]==x[1:];out.append(lines[i]);i+=1
   elif x.startswith('-'):assert lines[i]==x[1:];i+=1
   elif x.startswith('+'):out.append(x[1:])
   else:raise AssertionError(x)
 out.extend(lines[i:]);return ''.join(out).encode()
assert apply(ab,pathlib.Path(h['forward_patch']['path']).read_bytes())==bb;inverse=apply(bb,pathlib.Path(h['inverse_patch']['path']).read_bytes());assert inverse==ab;assert ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(at,include_attributes=True)
def inventory(source):
 rows=[];tree=ast.parse(source)
 def walk(n,prefix=''):
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
   name=prefix+n.name;raw=b''.join(source.splitlines(keepends=True)[n.lineno-1:n.end_lineno]);rows.append({'name':name,'lines':[n.lineno,n.end_lineno],'raw_sha256':H(raw),'AST_sha256':H(ast.dump(n,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'all_calls':sorted(set(ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call)))});prefix=name+'.'
  for child in ast.iter_child_nodes(n):walk(child,prefix)
 walk(tree);return rows
old=inventory(ab);rows=inventory(bb);oldmap={r['name']:r for r in old};assert len(old)==len(rows)==19;changed=[r['name'] for r in rows if r['raw_sha256']!=oldmap[r['name']]['raw_sha256']];assert set(changed)=={'qualify','qualify.pair'};unchanged=[r['name'] for r in rows if r['name'] not in changed];assert len(unchanged)==17 and all(r['AST_sha256']==oldmap[r['name']]['AST_sha256'] for r in rows if r['name'] in unchanged)
def const(t):return {n.targets[0].id:ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
ac=const(at);bc=const(bt);assert set(ac)==set(bc) and [k for k in ac if ac[k]!=bc[k]]==['VERSION'];assert ac['EXPECTED']==bc['EXPECTED']==h['exact_census']
static=J(h['complete_static']['path']);manual=J(h['complete_helper_walkthrough']['path']);assert static['whole_AST_sha256']==H(ast.dump(bt,include_attributes=False).encode()) and static['whole_positioned_AST_sha256']==H(ast.dump(bt,include_attributes=True).encode())
for author in static['all_named_definitions']:
 own=next(r for r in rows if r['name']==author['name']);assert all(own[k]==author[k] for k in ['raw_sha256','AST_sha256','positioned_AST_sha256'])
for author in manual['all_named_units']:assert author['raw_sha256']==next(r for r in rows if r['name']==author['name'])['raw_sha256']
sc=[]
def sw(s,prefix=''):
 sc.append({'name':prefix+s.get_name(),'line':s.get_lineno(),'kind':str(s.get_type()),'identifiers':list(s.get_identifiers())})
 for c in s.get_children():sw(c,prefix+s.get_name()+'.')
sw(symtable.symtable(bb.decode(),str(b),'exec'));assert len(sc)==23
api=J(h['public_ABI']['path']);assert api['closed_expected_counts']==bc['EXPECTED'];assert api['entry']=='qualify(native_vm, carrier, oracle, boundary, emit)'
support={'schema':'L-R-oracle-boundary-qualification-Source2-focused-static-support-v1','Source':h['Source'],'all_current_direct_rawpins':pins,'inherited_complete_Source1_review':ref(O/'oracle-boundary-qualifier-complete-independent-Source-peer-review-v1.json'),'runtime':ref(sys.executable),'complete_raw_patch_forward_inverse_exact':True,'whole_positioned_AST_inverse_exact':True,'only_changed_global':'VERSION v1->v2','changed_helpers':changed,'all17_other_helper_raw_AST_identical':unchanged,'all19_current_named_helpers':rows,'all23_scope_records':sc,'same_closed_expected_census':bc['EXPECTED'],'exact_guard_closure':{'private_images':'Native and oracle ordinary VM snapshots are full private wire copies; original producer/native returns retained unmodified.','normalization':'Only seconds removed from copies; native trace shortened to exactdeclared retainedprefix. Every other native/oracle VM key/value including status/heap_nodes/reason/function/pc must match.','direct_native_outcomes':'ExistingACCEPTED int1+accepted; existingCERTIFIED_REJECTION int0+rejected; existingNODEreturn actualcarrier byte_rows[0].node_id exactint>256+rejected; existingFAULT no value/rejected and typednative reason/function/pc. No source/private helper or extra producer call.','cut_and_context':'All previous fullheap/eventSHA/context/cut/dep/trace checks retained, same statuses/refusals and resource scope.'},'subject_calls':0,'scope':'Inherited fullSource1 semantic/manual/API/census read plus wholecurrentdelta/rawAST/static joins only; no imports/helpers/factories/models/tests/CLI/native/compiler/oracle/encoder execution.'}
sr=save('oracle-boundary-qualifier-Source2-focused-independent-static-support-v1.json',support)
review={'schema':'L-R-oracle-boundary-qualifier-Source2-complete-independent-Source-peer-review-v1','decision':'PASS_CURRENT_SOURCE2_COMPLETE_INHERITED_SCOPE_UNRUN','review_passed':True,'blockers':[],'Source':h['Source'],'handoff':ref(hp),'public_ABI':h['public_ABI'],'support':sr,'inherits':support['inherited_complete_Source1_review'],'finding_closed':'Direct native expectation categories now required before accepting every pairedcontrol. Entire ordinary VM receipt compared canonically after removing only seconds and applying exactnative retainedtraceprefix; all status/heap_nodes/faultreason/function/pc/optionalfields remain exact. Full originals unchanged/retained. Sole Source1 material gap closed.','preservation':'Wholeforward/inverse2761bytepatches andpositionedAST inverse exact; onlyVERSION+qualify.pair assertions (enclosingqualifyraw changes), all17otherhelpers raw/plainAST unchanged;19defs23scopes, same316primary/328emits/280oracle36boundary271native11compile12carrier/caps/signature/resultfields.','retained_scope':'Generic diagnostic DSL and GIVENformula boundary controls, no C1compile/run/proof fixtures/discovery. Full256watch, markerconsHIT/MISS, unread/emptycut/prefix/resource andallconstructor/minboundary scopes inherited. Foreigncontrol only sentinelclass propagation; no additional instanceidentity guarantee claimed.','remaining':'Root full currentSourceadoption, closedworker/observer/caller/exactfreshonce and completeactualreview before componentadmission. No execution/plan/authority/actual created here.','subject_calls':0,'terminal_state':'COMPLETE_TOOLS_TERMINAL_IDLE'}
rr=save('oracle-boundary-qualifier-Source2-complete-independent-Source-peer-review-v1.json',review)
print(json.dumps({'review':rr,'support':sr},indent=2))
