import ast,difflib,hashlib,json,pathlib,re,symtable
R=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1/root');D=pathlib.Path('/private/tmp/gcts-C-R-proof-proposals-Source-peer-v1')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,v):
 p=D/name;b=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return pin(p)
p1=R/'proof_family_proposals_v1.py';p2=R/'proof_family_proposals_v2.py';old=p1.read_text();new=p2.read_text();assert pin(p2)=={'path':str(p2),'bytes':23444,'sha256':'4ce2920d1235f6ae44505ceafec1258ef5dcbfb0e81d5917f4bf15cd7cbbe981'}
replace1=("VERSION = 'R-GENERIC-PROOF-FAMILY-PROPOSALS-v1'","VERSION = 'R-GENERIC-PROOF-FAMILY-PROPOSALS-v2'")
replace2=("if type(limits) is not dict or set(limits) != set(LIMIT_KEYS):","if (type(limits) is not dict or len(limits) != len(LIMIT_KEYS)\n                or set(limits) != set(LIMIT_KEYS)):")
assert old.replace(*replace1).replace(*replace2)==new
assert new.replace(replace2[1],replace2[0]).replace(replace1[1],replace1[0])==old
A=ast.parse(old);B=ast.parse(new);compile(new,str(p2),'exec',dont_inherit=True)
assert ast.dump(ast.parse(new.replace(replace2[1],replace2[0]).replace(replace1[1],replace1[0])),include_attributes=True)==ast.dump(A,include_attributes=True)
def units(s,a):
 lines=s.splitlines(keepends=True);out={}
 def walk(body,prefix=''):
  for n in body:
   if isinstance(n,(ast.FunctionDef,ast.ClassDef)):
    out[prefix+n.name]={'raw':''.join(lines[n.lineno-1:n.end_lineno]),'ast':ast.dump(n,include_attributes=False),'lines':[n.lineno,n.end_lineno]};walk(n.body,prefix+n.name+'.')
 walk(a.body);return out
u1,u2=units(old,A),units(new,B);assert u1.keys()==u2.keys();changed=[n for n in u1 if u1[n]['raw']!=u2[n]['raw']];assert changed==['Context','Context.__init__']
ledger=[{'name':n,'lines':u2[n]['lines'],'raw_sha256':hashlib.sha256(u2[n]['raw'].encode()).hexdigest(),'AST_sha256':hashlib.sha256(u2[n]['ast'].encode()).hexdigest(),'raw_identical':u1[n]['raw']==u2[n]['raw'],'AST_identical':u1[n]['ast']==u2[n]['ast']} for n in u2]
inverse=''.join(difflib.unified_diff(new.splitlines(keepends=True),old.splitlines(keepends=True),fromfile='Source2',tofile='Source1'))
ip=D/'proof-proposals-Source2-Source1-full-inverse-v1.patch'
with ip.open('x') as f:f.write(inverse)
# Complete symbol flags may gain builtin len in Context constructor only.
def scopes(t):
 flags=['is_referenced','is_parameter','is_global','is_nonlocal','is_declared_global','is_local','is_free','is_imported','is_assigned','is_namespace','is_annotated']
 yield {'name':t.get_name(),'type':t.get_type(),'line':t.get_lineno(),'symbols':[{k:(x.get_name() if k=='name' else getattr(x,k)()) for k in ['name']+flags} for x in t.get_symbols()]}
 for c in t.get_children():yield from scopes(c)
s1=list(scopes(symtable.symtable(old,str(p1),'exec')));s2=list(scopes(symtable.symtable(new,str(p2),'exec')));assert len(s1)==len(s2)==45
# The added len reference can change only symbols in constructor scope.
delta=[]
for x,y in zip(s1,s2,strict=True):
 if x['symbols']!=y['symbols']:delta.append({'scope':y['name'],'old':x['symbols'],'new':y['symbols']})
assert all(d['scope']=='__init__' for d in delta)
support=save('proof-proposals-Source2-focused-complete-static-support-v1.json',{'schema':'C-R-proof-proposals-Source2-focused-static-v1','Source1':pin(p1),'Source2':pin(p2),'exact_raw_forward_and_reverse_literal_reconstruction':True,'whole_positioned_AST_inverse':True,'producer_forward_patch':pin(R/'proof-family-proposals-Source1-Source2.patch'),'full_peer_inverse_patch':pin(ip),'all37_current_units':ledger,'all45_current_scopes':s2,'symbol_changes':delta,'unchanged_unit_count':35,'changed_units':changed,'unused_compile':'PASS discarded never executed','scope':'Full inherited Source1 review plus exact two-substitution Source2. No subject imports/functions/generator iterations/factories/fixtures/VM/checker/CLI or codeobject execution.'})
report=save('proof-proposals-Source2-complete-independent-focused-peer-v1.json',{'schema':'C-R-proof-proposals-Source2-focused-complete-peer-v1','decision':'PASS','blockers':[],'Source':pin(p2),'inherited_complete_Source1_review':pin(D/'proof-proposals-complete-independent-Source-peer-review-v1.json'),'current_Root_handoff':pin(R/'proof-family-proposals-Source2-inert-handoff-v1.json'),'current_effective_public_ABI':pin(R/'proof-family-proposals-complete-public-ABI-v1.json'),'current_Source2_static_support':support,'closure':'R1 fixed: exactdict check then len(limits)==len(LIMIT_KEYS) before set(limits), before any context allocation/meter. Valid limits/control semantics unchanged. Only other change VERSIONv2.','preservation':'All37units retained;35raw/plainAST identical; Context+constructor contain only cardinality guard. Whole byte and positioned AST reverse exact, all signatures/caps/generic generation/capture/ref logic unchanged. Source1 negative remains immutable.','ABI_precision':'Original public ABI file still binds historical Source1/version1; current immutable Source2 handoff explicitly prospectively supersedes those operative Source/version associations with unchanged interfaces/fields/scopes. Do not confuse old rawpin with executed Source2.','scope':'Source-only PASS, not proof search/validity or actual admission; all candidates UNVERIFIED until actual C1+B checks. No new solves/cases/authority. All subject calls0.'})
print(json.dumps({'review':report,'support':support}))
