"""Static Source data audit only. Never imports or executes subject code."""
from pathlib import Path
import ast
import hashlib
import json
import re
import symtable

D = Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1/implementation-C')
OUT = Path('/private/tmp/gcts-B-R-publication-Source-peer-v1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False).encode('ascii')


def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def readref(ref):
    assert pin(ref['path']) == ref
    return Path(ref['path']).read_bytes()


def patch(raw, diff):
    lines = raw.splitlines(keepends=True)
    rows = diff.decode().splitlines(keepends=True)
    out, cursor, i = [], 0, 0
    while i < len(rows):
        if not rows[i].startswith('@@ '):
            i += 1
            continue
        match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', rows[i])
        assert match
        start = int(match.group(1)) - 1
        assert start >= cursor
        out.extend(lines[cursor:start])
        cursor, i, old_count, new_count = start, i + 1, 0, 0
        while i < len(rows) and not rows[i].startswith('@@ '):
            row = rows[i]
            assert row[:1] in (' ', '+', '-')
            body = row[1:].encode()
            if row[0] in ' -':
                assert lines[cursor] == body
                cursor += 1
                old_count += 1
            if row[0] in ' +':
                out.append(body)
                new_count += 1
            i += 1
        assert (old_count, new_count) == (int(match.group(2) or 1), int(match.group(4) or 1))
    out.extend(lines[cursor:])
    return b''.join(out)


def differences(a, b, path='Module'):
    assert type(a) == type(b)
    if isinstance(a, ast.AST):
        rows = []
        for key, value in ast.iter_fields(a):
            rows += differences(value, getattr(b, key), path + '.' + key)
        return rows
    if isinstance(a, list):
        assert len(a) == len(b)
        rows = []
        for index, (x, y) in enumerate(zip(a, b)):
            rows += differences(x, y, path + '[' + str(index) + ']')
        return rows
    if a == b:
        return []
    assert type(a) is str
    return [{'path': path, 'old': a, 'new': b}]


def definitions(tree, prefix=''):
    rows = []
    for node in ast.iter_child_nodes(tree):
        name = prefix
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
            name = prefix + node.name
            rows.append((name, node))
            name += '.'
        rows += definitions(node, name)
    return rows


handoff_path = D / 'compact-proof-search-publication-complete-inert-Source-handoff-v1.json'
handoff = json.loads(handoff_path.read_bytes())
assert pin(handoff_path)['sha256'] == '89a9c7651944449099ad1cfeba612cc0aa0214f390e77169209ec78e5aea9dcd'
records = {key: json.loads(readref(ref)) for key, ref in handoff['supporting_records'].items()}
for ref in handoff['four_patches']:
    readref(ref)
static = records['complete_static']
manual = records['complete_helper_walkthrough']
abi = records['public_ABI']
preservation = records['complete_literal_preservation']
roles = {}
named = scopes_total = top_total = 0
for role in ('publisher', 'verifier'):
    offer = next(row for row in records['exact_substitutions']['roles'] if row['role'] == role)
    old = readref(offer['base'])
    current = readref(offer['source'])
    assert offer['source'] == handoff['subjects'][role] == abi['subjects'][role]
    rebuilt = old
    for item in offer['substitutions']:
        before, after = item['old'].encode(), item['new'].encode()
        assert rebuilt.count(before) == item['occurrences']
        rebuilt = rebuilt.replace(before, after)
    assert rebuilt == current
    stem = 'R-publisher' if role == 'publisher' else 'R-verifier'
    assert patch(old, (D / (stem + '-full-forward-v1.patch')).read_bytes()) == current
    assert patch(current, (D / (stem + '-full-inverse-v1.patch')).read_bytes()) == old
    old_tree, tree = ast.parse(old), ast.parse(current)
    author = static['records'][role]
    delta = differences(old_tree, tree)
    assert delta == author['AST_string_leaf_changes']
    assert sha(ast.dump(tree).encode()) == author['whole_AST_sha256']
    assert sha(ast.dump(tree, include_attributes=True).encode()) == author['whole_positioned_AST_sha256']
    code = compile(current, offer['source']['path'], 'exec', dont_inherit=True)
    del code
    lines = current.splitlines(keepends=True)
    helper_rows = []
    for name, node in definitions(tree):
        raw = b''.join(lines[node.lineno - 1:node.end_lineno])
        helper_rows.append({'name': name, 'lines': [node.lineno, node.end_lineno],
            'raw_bytes': len(raw), 'raw_sha256': sha(raw),
            'AST_sha256': sha(ast.dump(node).encode()),
            'positioned_AST_sha256': sha(ast.dump(node, include_attributes=True).encode()),
            'calls': sorted(set(ast.unparse(n.func) for n in ast.walk(node) if isinstance(n, ast.Call)))})
    assert helper_rows == author['all_named_definitions']
    imports = [ast.unparse(n) for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))]
    assert imports == author['imports']
    scope_rows = []
    def walk(table, prefix=''):
        name = prefix + table.get_name()
        entries = []
        for symbol in table.get_symbols():
            entry = {'name': symbol.get_name()}
            for flag in static['symbol_recipe']['flags']:
                entry[flag] = getattr(symbol, 'is_' + flag)()
            entries.append(entry)
        scope_rows.append({'name': name, 'type': table.get_type(), 'line': table.get_lineno(),
            'symbol_count': len(entries), 'complete_symbol_flags_sha256': sha(encoded(entries))})
        for child in table.get_children():
            walk(child, name + '.')
    walk(symtable.symtable(current.decode(), offer['source']['path'], 'exec'))
    assert scope_rows == author['all_scopes']
    top = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef))]
    for helper in (x for x in manual['helpers'] if x['role'] == role):
        row = next(x for x in helper_rows if x['name'] == helper['helper'])
        assert row['lines'] == helper['lines'] and row['raw_sha256'] == helper['raw_sha256']
    assert len(top) == author['top_def_count'] and len(helper_rows) == author['named_definition_count']
    assert len(scope_rows) == author['scope_count']
    assert not any(old_name in current for old_name in (b'unknown-proof-stream', b'UNKNOWN-PROOF-STREAM'))
    named += len(helper_rows)
    scopes_total += len(scope_rows)
    top_total += len(top)
    roles[role] = {'Source': offer['source'], 'predecessor': offer['base'],
        'whole_raw_forward_inverse_and_positioned_AST_inverse': True,
        'all_AST_changes_string_only': delta, 'all_substitution_counts': offer['substitutions'],
        'all_helpers': helper_rows, 'all_scopes': scope_rows, 'imports': imports,
        'unused_compile_discarded': True}
counts = {'named': named, 'scopes': scopes_total, 'top': top_total}
assert counts == handoff['static_census'] == static['total_census'] == {'named': 51, 'scopes': 64, 'top': 41}
basis = preservation['parent_identity_basis']
last_terminal = json.loads(readref(basis['last_Q_terminal']))
readref(basis['last_Q_final'])
assert last_terminal['commit'] == abi['parent_scope']['commit'] == 'b403c2ecc2cf56d389babc2839a78fe958e62f82'
assert last_terminal['after_tree'] == abi['parent_scope']['tree'] == 'ae57c0725bb27d5d3c16124f6f70709d9fd29cc3'
assert abi['fixed_targets'] == ['docs/research/gcts-rl-renewal/conditional-inventory/' + name for name in
    ('compact-proof-search-v1.html', 'compact-proof-search-results-v1.json', 'compact-proof-search-evidence-v1.zip')]
assert abi['publisher']['API_count'] == 12 and abi['TLS']['normal_requests'] == 3
support = {'schema': 'B-R-publication-complete-independent-static-support-v1',
    'decision': 'PASS_STATIC_ONLY', 'handoff': pin(handoff_path),
    'metadata': handoff['supporting_records'], 'all_four_patches': handoff['four_patches'],
    'roles': roles, 'census': counts, 'full_public_ABI': abi,
    'current_parent_admin_joins': {'terminal': basis['last_Q_terminal'], 'final': basis['last_Q_final'],
        'commit': last_terminal['commit'], 'tree': last_terminal['after_tree']},
    'subject_calls': 0, 'network_calls': 0, 'payload_reads': 0,
    'administrative_note': 'Initial static comparison used leaf-only symtable names; current complete pass uses the offered hierarchical top.* names. Exact symbol flags were unchanged. No subject code executed.'}
target = OUT / 'R-publication-complete-independent-static-support-v1.json'
with target.open('xb') as stream:
    stream.write((json.dumps(support, sort_keys=True, indent=2) + '\n').encode())
print(json.dumps({'support': pin(target), 'counts': counts, 'decision': support['decision']}))
