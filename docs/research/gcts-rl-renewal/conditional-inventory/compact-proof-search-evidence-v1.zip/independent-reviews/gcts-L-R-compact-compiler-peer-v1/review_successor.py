import ast,difflib,hashlib,json,pathlib,symtable,sys
R=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1');C=R/'implementation-C';O=pathlib.Path('/private/tmp/gcts-L-R-compact-compiler-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def J(p):return json.loads(pathlib.Path(p).read_bytes())
def chk(r):assert ref(r['path'])==r;return r
def save(n,d):
 p=O/n;b=(json.dumps(d,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return ref(p)
hp=C/'compact-NTM-Wang-compiler-complete-inert-Source-handoff-v2.json';h=J(hp);assert ref(hp)['sha256']=='25bba252f64bb5c8b5acd70837eabb0a295f7736ae4d317eb33f33d2ecd2beb1';pins=[ref(hp)]
for k,v in h.items():
 if type(v)is dict and set(v)=={'path','bytes','sha256'}:pins.append(chk(v))
for r in h['two_complete_patches']:pins.append(chk(r))
a=C/'compact_ntm_wang_compiler_v1.py';b=pathlib.Path(h['Source']['path']);ab=a.read_bytes();bb=b.read_bytes();at=ast.parse(ab);bt=ast.parse(bb);oldfields="    _need(type(value) is dict and all(type(k) is str for k in value)\n";newfields="    _need(type(value) is dict and len(value) == len(names)\n          and all(type(k) is str for k in value)\n";assert ab.count(oldfields.encode())==1 and bb.count(newfields.encode())==1
forward=ab.replace(b"VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v1'",b"VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2'").replace(oldfields.encode(),newfields.encode());inverse=bb.replace(b"VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2'",b"VERSION = 'COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v1'").replace(newfields.encode(),oldfields.encode());assert forward==bb and inverse==ab;assert ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(at,include_attributes=True)
for r,before,after in [(h['two_complete_patches'][0],ab,bb),(h['two_complete_patches'][1],bb,ab)]:
 expected=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='before/compiler',tofile='after/compiler')).encode();assert pathlib.Path(r['path']).read_bytes()==expected
old={n.name:n for n in at.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};new={n.name:n for n in bt.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};assert set(old)==set(new) and len(new)==17
lines=bb.splitlines(keepends=True);olines=ab.splitlines(keepends=True);rows=[];unchanged=[]
for name,n in new.items():
 raw=b''.join(lines[n.lineno-1:n.end_lineno]);oraw=b''.join(olines[old[name].lineno-1:old[name].end_lineno]);same=raw==oraw
 if same:unchanged.append(name)
 rows.append({'name':name,'lines':[n.lineno,n.end_lineno],'raw_sha256':H(raw),'AST_sha256':H(ast.dump(n,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'raw_identical_to_Source1':same,'all_calls':sorted(set(ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call)))})
assert len(unchanged)==16 and '_fields' not in unchanged
st=symtable.symtable(bb.decode(),str(b),'exec');sc=[]
def sw(s):
 sc.append({'name':s.get_name(),'line':s.get_lineno(),'type':str(s.get_type()),'identifiers':list(s.get_identifiers())})
 for c in s.get_children():sw(c)
sw(st);assert len(sc)==31
static=J(h['complete_static_helper_ledger']['path']);manual=J(h['complete_helper_walkthrough']['path']);assert static['whole_AST_sha256']==H(ast.dump(bt,include_attributes=False).encode()) and static['whole_positioned_AST_sha256']==H(ast.dump(bt,include_attributes=True).encode())
for author in static['top_helpers']:
 own=next(x for x in rows if x['name']==author['name']);assert all(author[k]==own[k] for k in ['raw_sha256','AST_sha256','positioned_AST_sha256'])
for author in manual['helpers']:assert author['raw_sha256']==next(x for x in rows if x['name']==author['name'])['raw_sha256']
abi=J(h['public_ABI']['path']);assert abi['VERSION']=='COMPACT_DIRECTIONAL_NTM_WANG_COMPILER-v2' and len(abi['result_exact14'])==14 and abi['result_schema']=='C-compact-directional-NTM-Wang-compile-result-v1'
# Public delta is metadata only; current complete ABI is a version/path successor.
def diff(a,b,path='$'):
 if type(a)!=type(b):return [{'path':path,'old':a,'new':b}]
 if type(a)is dict:
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a:out.append({'path':path+'.'+k,'added':b[k]})
   elif k not in b:out.append({'path':path+'.'+k,'removed':a[k]})
   else:out.extend(diff(a[k],b[k],path+'.'+k))
  return out
 if a!=b:return [{'path':path,'old':a,'new':b}]
 return []
abi_delta=diff(J(C/'compact-NTM-Wang-compiler-complete-public-ABI-v1.json'),abi)
s={'schema':'L-R-compact-compiler-Source2-focused-static-inverse-support-v1','current_Source':h['Source'],'all_direct_pins':pins,'inherited_complete_review':ref(O/'compact-compiler-complete-independent-Source-peer-review-v1.json'),'runtime':ref(sys.executable),'raw_forward_inverse_and_both_complete_patch_texts_exact':True,'whole_positioned_AST_inverse_exact':True,'only_changed_global':'VERSION','only_changed_top_helper':'_fields','raw_and_plain_AST_unchanged_helpers':unchanged,'all17_current_top_helper_fingerprints':rows,'all31_current_scope_records':sc,'public_ABI_delta':abi_delta,'guard_order':{'exactdict_first':True,'len_cardinality_before_all_or_set':True,'valid_input_field_string_set_check_retained':True,'same_limits2_and_machine5_apply':True},'subject_calls':0,'mode':'stdlib raw/AST/symtable/diff only, no codeobject/import/helper/fixture/CLI or compiler call.'}
sr=save('compact-compiler-Source2-focused-independent-static-support-v1.json',s)
r={'schema':'L-R-compact-compiler-Source2-complete-independent-Source-peer-review-v1','decision':'PASS_SOURCE2_COMPLETE_INHERITED_CORE_UNRUN','review_passed':True,'blockers':[],'Source':h['Source'],'handoff':ref(hp),'public_ABI':h['public_ABI'],'support':sr,'inherits':ref(O/'compact-compiler-complete-independent-Source-peer-review-v1.json'),'closure':'Exactdict -> len(value)==len(names) now shortcircuits before all(keys)/set(value). Wrong-cardinality arbitrary dictionaries refuse without those scans/allocations, including limits before meter and machine5 validation. Valid field/type/error semantics unchanged.','preservation':'Complete forward/inverse raw replacement and both682byte unified patch texts verified, whole positionedAST inverse exact, all16 other helper bodies/plainAST identical, same17top21named31scopes, same imports/allalgorithm/caps/families/counts/markschemas and14return wire. Only VERSIONv2 and _fields correction in Source. CurrentAPI/manual/static/proof/controlrequirement pins fully joined.','scope':'Inherited complete seven-family onehead/closedwall correspondence, exact effective accepting absorption/counts and optional freshhead assigned0-vsabsence/fullboard-vs-irregular boundary argument preserved. Symboliccolor→Linteger adapter remains separate Root work.','remaining':'Root Source2 adoption and new closed independent qualification/caller/freshonce needed. No empirical compiler/machine/physicalFOL/Machine5/GCTS/proof-discovery claim.','subject_calls':0,'terminal_state':'SOURCE_REVIEW_COMPLETE_TOOLS_TERMINAL_IDLE'}
rr=save('compact-compiler-Source2-complete-independent-Source-peer-review-v1.json',r)
print(json.dumps({'review':rr,'support':sr,'ABI_delta':abi_delta},indent=2))
