"""Administrative saved-data joins only; no project import or semantic replay."""
from pathlib import Path
import collections
import gzip
import hashlib
import json

R = Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1')
A = R / 'actual/qualification-001'
OUT = Path('/private/tmp/gcts-B-R-whole-actual-peer-v1')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(value, lf=False):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + ('\n' if lf else '')).encode('ascii')


def pairs(rows):
    result = {}
    for key, value in rows:
        assert key not in result, ('duplicate JSON key', key)
        result[key] = value
    return result


def parse(raw):
    def invalid(value):
        raise AssertionError(('nonfinite', value))
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def read_ref(ref):
    assert type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['bytes']) is int and ref['bytes'] >= 0
    assert pin(ref['path']) == ref
    return Path(ref['path']).read_bytes()


def values(value):
    if type(value) is dict:
        return 1 + sum(values(x) for x in value.values())
    if type(value) is list:
        return 1 + sum(values(x) for x in value)
    assert value is None or type(value) in (str, int, bool, float)
    return 1


def no_bool_integer(value, low=0):
    assert type(value) is int and value >= low


transport_path = R / 'root/qualification-001-original-owned-tool-transcript-v1.json'
transport = parse(transport_path.read_bytes())
assert pin(transport_path) == {'path': str(transport_path), 'bytes': 1711,
    'sha256': 'c1683d8d96e3354540af61920babe5e6881344160cacea82ac4c7460f1e04917'}
assert transport['original']['chunk_id'] == '26eab8'
assert transport['original']['session_id'] == 5035
assert transport['polls'][-1]['chunk_id'] == '357a5c'
assert transport['polls'][-1]['exit_code'] == transport['authoritative_observer_exit_code'] == 0
assert 'session_id' not in transport['polls'][-1]
outer = parse(read_ref(transport['full_stdout']))
assert read_ref(transport['full_stderr']) == b''
custody = parse(read_ref(transport['full_custody']))
worker = parse(read_ref(transport['result']))
assert custody['result'] == outer['admitted_result_candidate'] == transport['result']
assert custody['status'] == 'NORMAL_TRANSPORT_CANDIDATE'
assert outer['status'] == 'COMPLETE_NORMAL'
assert outer['requires_authoritative_exit_zero'] is True
assert outer['case_id'] == custody['case_id'] == worker['case_id'] == 'qualification-001'
plan = parse(read_ref(custody['plan']))
authority = parse(read_ref(custody['authority']))
consumed = parse(read_ref(custody['consumed']))
assert set(authority) == {'schema', 'authorized', 'uses', 'case_id', 'plan', 'observer'}
assert set(consumed) == {'schema', 'uses', 'case_id', 'plan', 'authority', 'observer', 'meaning'}
assert authority['authorized'] is True and type(authority['uses']) is int and authority['uses'] == 1
assert consumed['uses'] == 1 and type(consumed['uses']) is int
assert authority['plan'] == consumed['plan'] == custody['plan']
assert authority['observer'] == consumed['observer'] == plan['sources']['observer']
assert consumed['authority'] == custody['authority']
assert authority['case_id'] == consumed['case_id'] == 'qualification-001'
assert authority['schema'] == 'Root-raw-proof-integration-once-authority-v1'
assert consumed['schema'] == 'Root-raw-proof-integration-once-consumed-v1'
assert plan['actual_dir'] == str(A)
guards = {'sources': {k: pin(v['path']) for k, v in plan['sources'].items()},
          'metadata': {k: pin(v['path']) for k, v in plan['metadata'].items()},
          'python': pin(plan['python']['path'])}
assert guards['sources'] == plan['sources'] and guards['metadata'] == plan['metadata']
assert guards['python'] == plan['python']
assert len(guards['sources']) == 16 and len(guards['metadata']) == 14
assert custody['Source_and_runtime_pre_post_exact'] is True
child = custody['child']
assert child['child_exit'] == 0 and child['owned_wait_complete'] is True
assert child['process_group_gone'] is True and child['log_eof'] == {'stderr': True, 'stdout': True}
assert child['cleanup_errors'] == child['cleanup_signals'] == []
assert child['fault'] is child['supervisor_exception'] is None
assert child['combined_log_overflow'] is False
assert child['child_lifetime_highwater_bytes'] <= plan['limits']['child_rss_bytes']
terminal = parse(read_ref(custody['captures']['stdout']))
assert terminal == custody['worker_terminal']
assert read_ref(custody['captures']['stdout_tail']) == read_ref(custody['captures']['stdout'])
assert read_ref(custody['captures']['stderr']) == read_ref(custody['captures']['stderr_tail']) == b''
assert terminal['status'] == 'COMPLETE_COMPONENT_CONTROLS_RESULT_WRITTEN'
assert terminal['plan'] == custody['plan'] and terminal['result'] == custody['result']
assert terminal['public_calls'] == worker['public_calls']
assert terminal['post_readback_costs']['elapsed_main_entry_seconds'] < plan['limits']['worker_seconds']

files = sorted(A.iterdir())
assert all(p.is_file() and not p.is_symlink() for p in files)
physical = [pin(p) for p in files]
assert len(physical) == outer['owned_file_count'] == 569
assert sum(p['bytes'] for p in physical) == outer['owned_named_bytes'] == 4445110
prior = {r['path']: r for r in custody['all_prior_owned_files']}
assert len(prior) == 568
assert {x['path']: x for x in physical if x['path'] != str(A / 'custody.json')} == prior

artifacts = {}
artifact_rows = []
objects = {}
for art in worker['artifacts']:
    assert set(art) == {'encoding', 'name', 'raw_bytes', 'raw_sha256', 'stored'}
    name = art['name']
    assert type(name) is str and name not in artifacts
    assert Path(art['stored']['path']).parent == A
    assert art['stored'] == prior[art['stored']['path']]
    stored = read_ref(art['stored'])
    assert art['encoding'] in ('json', 'gzip-json')
    raw = gzip.decompress(stored) if art['encoding'] == 'gzip-json' else stored
    assert len(raw) == art['raw_bytes'] and digest(raw) == art['raw_sha256']
    obj = parse(raw)
    assert compact(obj, True) == raw
    artifacts[name] = art
    objects[name] = obj
    artifact_rows.append({'name': name, 'stored': art['stored'], 'encoding': art['encoding'],
        'raw_bytes': len(raw), 'raw_sha256': digest(raw), 'JSON_values': values(obj),
        'root_fields': sorted(obj) if type(obj) is dict else None})
assert len(artifacts) == transport['all_artifacts_complete_readback'] == 562
assert sum(a['raw_bytes'] for a in artifact_rows) == transport['raw_decoded_artifact_bytes'] == 10749480
assert sum(a['stored']['bytes'] for a in artifact_rows) == worker['total_stored_bytes'] == 3727791
assert max(a['raw_bytes'] for a in artifact_rows) <= plan['limits']['model_raw_bytes']
assert max(a['stored']['bytes'] for a in artifact_rows) <= plan['limits']['body_bytes']
assert sum(a['stored']['bytes'] for a in artifact_rows) <= plan['limits']['total_output_bytes']

program = objects['fixed-C1-fresh-program']
program_hash = digest(compact(program))
assert program['atom_max'] == program['nil'] == 256
research = worker['research']
assert research == objects['proof-search-results']
assert len(research['results']) == len(research['inventory']) == 7
case_names = [r['case'] for r in research['results']]
assert case_names == ['raw-reflexivity', 'raw-propositional-identity',
    'inventory-successor-reflexivity', 'equality-symmetry', 'addition-one-plus-one',
    'addition-right-one', 'distinct-lines-common-points-coincide']
callbacks = objects['proposal-tautology-callbacks']
assert len(callbacks) == 81
assert collections.Counter(x['case'] for x in callbacks) == {'equality-symmetry': 80,
    'distinct-lines-common-points-coincide': 1}
for row in callbacks:
    assert set(row) == {'case', 'formula', 'receipt'} and row['case'] in case_names
    assert row['receipt']['status'] in ('VERIFIED', 'REJECTED')
    assert row['receipt']['rule_counts']['tautology'] == 1
callback_statuses = dict(collections.Counter(x['receipt']['status'] for x in callbacks))
assert callback_statuses == {'REJECTED': 79, 'VERIFIED': 2}

case_rows = []
attempt_rows = []
accepted_rows = []
inventory_rows = []
point_count = direct_count = observation_count = decode_count = proposal_encodes = 0
prior_inventory = []
for case_index, case in enumerate(research['results']):
    name = case['case']
    input_record = objects[name + '-input-and-proposal']
    assert input_record['input']['id'] == name
    assert input_record['input']['family'] == case['family']
    assert input_record['input']['theory'] == case['theory']
    assert input_record['input']['goal'] == case['goal']
    assert input_record['generation'] == case['generation']
    theory3_hash = digest(compact(case['theory']))
    same_theory_ids = [r['id'] for r in prior_inventory if r['theory_sha256'] == theory3_hash]
    assert input_record['inventory_ids'] == same_theory_ids
    assert input_record['input']['raw_only'] is (case_index < 2)
    proposal = case['generation']['proposal']
    if case_index < 2:
        assert proposal is None and case['generation']['status'] == 'RAW_ONLY'
        assert name + '-proposal-encoding' not in artifacts
    else:
        assert case['generation']['status'] == proposal['status'] == 'UNVERIFIED_PROPOSAL'
        assert proposal['target'] == case['goal']
        assert all(parent in same_theory_ids for parent in proposal['parents'])
        enc = objects[name + '-proposal-encoding']
        assert enc['status'] == 'COMPLETE' and enc['operation'] == 'encode'
        assert enc['counts']['lines'] == len(proposal['proof'])
        assert len(bytes.fromhex(enc['stream_hex'])) == enc['counts']['bytes_emitted'] == case['byte_count']
        proposal_encodes += 1
    bc = objects[name + '-given-boundary-and-carrier']
    boundary, carrier = bc['boundary'], bc['carrier']['value']
    assert boundary['status'] == 'COMPLETE' and boundary['byte_count'] == case['byte_count']
    assert boundary['fixed_bytes'] == case['given_fixed_bytes']
    fixed = dict(boundary['fixed_bytes'])
    assert len(fixed) == len(boundary['fixed_bytes']) and fixed[0] == 1 and fixed[1] == 16
    assert 2 not in fixed and all(type(k) is int and type(v) is int for k, v in boundary['fixed_bytes'])
    suffix = bytes.fromhex(boundary['goal_wire_hex']) + bytes([17])
    assert boundary['minimum_stream_bytes'] == len(suffix) + 3
    assert [fixed[i] for i in range(case['byte_count'] - len(suffix), case['byte_count'])] == list(suffix)
    assert carrier['byte_count'] == len(carrier['byte_rows']) == case['byte_count']
    assert carrier['known']['target'] == case['goal']
    assert carrier['known']['theory'] == dict(case['theory'], schemas=[])
    assert carrier['known']['target_sha256'] == digest(compact(case['goal']))
    assert carrier['known']['theory_sha256'] == digest(compact(carrier['known']['theory']))
    assert carrier['program_sha256'] == program_hash
    assert carrier['nodes'][:carrier['program_prefix_nodes']] == program['nodes']
    assert len(set(carrier['marker_ids'])) == case['byte_count']
    carrier_hash = digest(compact(carrier))
    context = {'program_sha256': program_hash,
        'theory_sha256': carrier['known']['theory_sha256'],
        'goal_sha256': carrier['known']['target_sha256'], 'byte_count': case['byte_count'],
        'boundary_version': boundary['version']}
    lane_rows = []
    for lane in case['lanes']:
        lane_name = lane['lane']
        assert lane_name in ('point-markings', 'conventional-clauses')
        assert objects[name + '-' + lane_name + '-result'] == lane
        expected_cuts = []
        attempts = lane['attempts']
        solve_names = sorted(n for n in artifacts if n.startswith(name + '-' + lane_name + '-') and n.endswith('-solve'))
        if lane['status'] == 'UNKNOWN_SOLVER':
            assert name == case_names[-1] and lane_name == 'conventional-clauses'
            assert attempts == [] and lane['accepted'] is None and lane['certified_cuts'] == []
            assert solve_names == [name + '-' + lane_name + '-0-solve']
            solve = objects[solve_names[0]]
            assert solve['status'] == 'UNKNOWN' and solve['byte_values'] is None
            assert 0 <= solve['operations'] <= 20000000
            assert not any(n.startswith(name + '-' + lane_name) and n.endswith('-observation') for n in artifacts)
            direct_count += 1
            lane_rows.append({'lane': lane_name, 'status': lane['status'], 'solves': 1,
                'oracle_calls': 0, 'observed_operations': solve['operations'], 'nodes': solve['nodes'],
                'reason_scope': 'Independent direct operation cap; not a negative result or superiority comparison.'})
            continue
        assert lane['status'] == 'DISCOVERED_AND_INDEPENDENTLY_VERIFIED'
        assert len(solve_names) == len(attempts) and 1 <= len(attempts) <= 6
        for i, attempt in enumerate(attempts):
            prefix = name + '-' + lane_name + '-' + str(i)
            assert attempt['index'] == i
            solve = objects[prefix + '-solve']
            obs = objects[prefix + '-observation']
            observation_count += 1
            byte_values = obs['byte_values']
            assert len(byte_values) == case['byte_count']
            assert all(type(v) is int and 0 <= v <= 255 for v in byte_values)
            assert all(byte_values[k] == v for k, v in fixed.items())
            assert attempt['byte_sha256'] == digest(bytes(byte_values))
            assert attempt['status'] == obs['status']
            assert attempt['native_steps'] == obs['vm']['steps'] == obs['trace_extent']['total_events']
            assert obs['resources']['initial_heap_nodes'] == len(carrier['nodes'])
            assert obs['binding'] == dict(context, carrier_value_sha256=carrier_hash,
                carrier_version=carrier['version'], oracle_version=obs['version'])
            assert obs['vm']['event_sha256'] == obs['trace_extent']['full_event_sha256']
            assert len(obs['final_heap']) == obs['vm']['heap_nodes']
            assert obs['trace_extent']['retained_events'] == len(obs['vm']['trace']) == min(16, obs['vm']['steps'])
            rows = {r['node_index']: r for r in carrier['byte_rows']}
            for k, row in enumerate(carrier['nodes']):
                expected = [byte_values[rows[k]['byte_index']], row[1]] if k in rows else row
                assert obs['final_heap'][k] == expected
            deps = obs['dependencies']
            assert len({d['byte_index'] for d in deps}) == len(deps)
            assert [d['byte_index'] for d in deps] == attempt['watched_indices']
            assert [d['first_step'] for d in deps] == sorted(d['first_step'] for d in deps)
            for dep in deps:
                no_bool_integer(dep['byte_index']); assert dep['byte_index'] < len(byte_values)
                assert dep['value'] == byte_values[dep['byte_index']]
                for k in ('first_step', 'head_reads', 'cons_alias_consults'): no_bool_integer(dep[k])
                assert dep['first_step'] <= obs['vm']['steps']
                assert dep['head_reads'] + dep['cons_alias_consults'] > 0
            if lane_name == 'point-markings':
                point_count += 1
                builder = objects[prefix + '-model']
                assert builder['status'] == 'COMPLETE' and builder['binding'] == context
                assert builder['counts']['input_cuts'] == len(expected_cuts)
                assert builder['counts']['retained_cuts'] == len(expected_cuts)
                assert len(builder['normalized_cuts']) == len(expected_cuts)
                for index, normalized in enumerate(builder['normalized_cuts']):
                    residual = [[k, v] for k, v in expected_cuts[index] if k not in fixed]
                    assert normalized == {'input_cut_index': index, 'literals': residual, 'status': 'RETAINED'}
                model = builder['model']
                # This is a serialization-order join of already saved rows, not model synthesis.
                sorted_model = dict(model, points=sorted(model['points']), fixed_marks=sorted(model['fixed_marks'], key=lambda r:r[0]), groups=sorted(model['groups'], key=lambda g: g['id']))
                assert solve['model_sha256'] == digest(compact(sorted_model, True))
                assert solve['status'] == 'SAT' and solve['rollback']['entry_restored'] is True
                assert solve['rollback']['trail_remaining'] == 0
                assert solve['entry_state'] == solve['restored_state']
                assert solve['solution_state']['selected'] == solve['solution']
                assert solve['solution_state']['frontier'] == solve['solution_state']['forward_incidence'] == []
                assert all(t[1] == 1 for t in solve['solution_state']['totals'])
                selected = dict(solve['solution'])
                assert [selected[x] for x in builder['byte_group_ids']] == byte_values
                trace = solve['trace']
                raw_trace = b''.join(compact(e, True) for e in trace['events'])
                assert len(trace['events']) == trace['retained_count'] <= 64
                assert len(raw_trace) == trace['retained_JSONL_bytes']
                assert digest(raw_trace) == trace['retained_SHA256']
                assert [e['seq'] for e in trace['events']] == list(range(trace['retained_count']))
                assert trace['event_count'] >= trace['retained_count']
                if trace['complete']:
                    assert trace['event_count'] == trace['retained_count']
                    assert trace['full_SHA256'] == trace['retained_SHA256']
                    assert trace['full_JSONL_bytes'] == trace['retained_JSONL_bytes']
            else:
                direct_count += 1
                assert solve['status'] == 'SAT' and solve['byte_values'] == byte_values
                assert solve['operations'] <= 20000000
            if obs['status'] == 'CERTIFIED_REJECTION':
                assert obs['vm']['status'] == 'rejected' and type(obs['vm']['value']) is int and obs['vm']['value'] == 0
                cut = obs['cut']
                assert cut['binding'] == obs['binding'] and cut['value'] == 0
                assert cut['trace_sha256'] == obs['vm']['event_sha256']
                assert cut['literals'] == sorted([[d['byte_index'], d['value']] for d in deps])
                expected_cuts.append(cut['literals'])
            else:
                assert obs['status'] == 'ACCEPTED' and obs['vm']['status'] == 'accepted'
                assert type(obs['vm']['value']) is int and obs['vm']['value'] == 1 and obs['cut'] is None
                assert i == len(attempts) - 1
                acc = lane['accepted']
                decode = objects[prefix + '-independent-decode']
                check = objects[prefix + '-independent-check']
                decode_count += 1
                assert bytes.fromhex(acc['stream_hex']) == bytes(byte_values)
                assert decode['status'] == 'COMPLETE' and decode['operation'] == 'decode'
                assert decode['offset'] == decode['counts']['bytes_read'] == case['byte_count']
                assert decode['proof'] == acc['proof']
                assert check == acc['checker'] and check['status'] == 'VERIFIED'
                assert check['reason'] == 'WHOLE_PROOF_VERIFIED' and check['error_line'] is None
                assert check['checked_lines'] == len(acc['proof']) == decode['counts']['lines']
                assert acc['proof'][-1]['formula'] == case['goal']
                assert check['rule_counts'] == {k: sum(line['rule'] == k for line in acc['proof']) for k in check['rule_counts']}
                for line_index, line in enumerate(acc['proof']):
                    for key in ('antecedent', 'implication', 'line'):
                        if key in line:
                            assert type(line[key]) is int and 0 <= line[key] < line_index
                if proposal is None:
                    assert acc['matched_proposal'] is False and acc['proposal_origin'] is None
                    assert acc['origin'] == 'RAW_BYTE_SEARCH'
                else:
                    assert acc['matched_proposal'] is True and acc['proof'] == proposal['proof']
                    assert acc['origin'] == acc['proposal_origin'] == proposal['origin']
                    assert objects[name + '-proposal-encoding']['stream_hex'] == acc['stream_hex']
                accepted_rows.append({'case': name, 'lane': lane_name,
                    'observation': artifacts[prefix + '-observation'],
                    'decode': artifacts[prefix + '-independent-decode'],
                    'checker': artifacts[prefix + '-independent-check'],
                    'proof_sha256': digest(compact(acc['proof'])), 'proof_lines': len(acc['proof']),
                    'rules': [line['rule'] for line in acc['proof']],
                    'origin': acc['origin'], 'matched_proposal': acc['matched_proposal'],
                    'native_steps': obs['vm']['steps'], 'independent_operations': check['visits']['operations']})
            attempt_rows.append({'case': name, 'lane': lane_name, 'index': i,
                'observation': artifacts[prefix + '-observation'],
                'solver': artifacts[prefix + '-solve'], 'status': obs['status'],
                'native_steps': obs['vm']['steps'], 'dependencies': len(deps),
                'full_event_sha256': obs['vm']['event_sha256'],
                'cut_literals': None if obs['cut'] is None else obs['cut']['literals'],
                'all_binding_bytes_dependencies_heap_prefix_and_result_joins': True})
        assert expected_cuts == lane['certified_cuts']
        lane_rows.append({'lane': lane_name, 'status': lane['status'], 'solves': len(solve_names),
            'oracle_calls': len(attempts), 'cuts': len(expected_cuts),
            'proof_lines': len(lane['accepted']['proof']), 'seconds': lane['seconds']})
    assert [x['lane'] for x in case['lanes']] == ['point-markings', 'conventional-clauses']
    inv = research['inventory'][case_index]
    point_accepted = case['lanes'][0]['accepted']
    assert inv == {'id': name, 'formula': case['goal'], 'proof': point_accepted['proof'],
                   'theory_sha256': theory3_hash}
    prior_inventory.append(inv)
    inventory_rows.append({'id': name, 'same_theory_prior_ids': same_theory_ids,
        'generation_status': case['generation']['status'],
        'proposal_origin': None if proposal is None else proposal['origin'],
        'accepted_source': 'current case point lane full C1 value1 and independent VERIFIED',
        'formula_sha256': digest(compact(case['goal'])), 'proof_sha256': digest(compact(inv['proof']))})
    case_rows.append({'case': name, 'family': case['family'], 'byte_count': case['byte_count'],
        'input_record': artifacts[name + '-input-and-proposal'],
        'boundary_carrier_record': artifacts[name + '-given-boundary-and-carrier'],
        'generation_seconds': case['generation']['seconds'], 'lanes': lane_rows})

assert (point_count, direct_count, observation_count, decode_count, proposal_encodes) == (10, 10, 19, 13, 5)
point_qual = worker['qualification']['point_compact']
oracle_qual = worker['qualification']['oracle_boundary']
assert point_qual['status'] == 'COMPLETE_COMPONENT_QUALIFICATION'
assert point_qual['counts'] == {'point_controls': 79, 'compiler_controls': 12,
    'row_contexts': 32, 'full_emitted_records': 123, 'literal_row_point_engine_solves': 0,
    'old_Wang_row_module_calls': 0}
assert len(point_qual['records']) == 123
for record in point_qual['records']:
    art = record['emitter_return']
    assert art == artifacts[art['name']]
    assert record['full_canonical_bytes'] == art['raw_bytes']
    assert record['full_canonical_SHA256'] == art['raw_sha256']
assert len(oracle_qual['emissions']) == oracle_qual['counts']['emissions'] == 328
for record in oracle_qual['emissions']:
    art = record['reference']
    assert art == artifacts[art['name']] and record['id'] == art['name']
    assert objects[art['name']]['passed'] is True
assert oracle_qual['status'] == 'COMPLETE_PASS'
qual_names = {x['emitter_return']['name'] for x in point_qual['records']} | {x['reference']['name'] for x in oracle_qual['emissions']}
assert len(qual_names) == 451
assert len(set(artifacts) - qual_names) == 111
expected_calls = {
    'boundary.encode_goal_boundary': 36 + 14, 'carrier.build_carrier': 12 + 7,
    'codec.decode': decode_count, 'codec.encode': proposal_encodes,
    'compact.compile_palette': 12, 'engine.make_byte_model': 50 + point_count,
    'engine.solve': 77 + point_count, 'fol_checker.check': len(callbacks) + decode_count,
    'ntm_reference.simulate': 32, 'oracle.observe': 280 + observation_count,
    'oracle_qualification.qualify': 1, 'point_qualification.qualify': 1,
    'proposer.propose': 5, 'search.run': 1, 'tree_machine.Compiler': 11 + 1,
    'tree_machine.Heap': 271, 'tree_machine.declaration': 11 + 1,
    'tree_machine.run': 271, 'tree_machine.validate': 1}
assert expected_calls == worker['public_calls']
assert set(expected_calls) <= set(worker['public_call_caps'])
assert all(type(v) is int and 0 < v <= worker['public_call_caps'][k] for k, v in expected_calls.items())

support = {'schema': 'B-R-whole-saved-case-passive-join-support-v1',
    'status': 'COMPLETE_PASSIVE_JOINS_PASS', 'subject_calls': 0,
    'method': 'Strict duplicate-free JSON, complete stored bytes and stdlib gzip readback, canonical serialization hashes, exact saved-field/row associations and arithmetic only. No subject function/semantic checker, solver, byte decoder, builder, evaluator or VM replay.',
    'transport': pin(transport_path), 'outer': transport['full_stdout'], 'custody': transport['full_custody'],
    'worker_result': transport['result'], 'plan': custody['plan'], 'authority': custody['authority'],
    'consumed': custody['consumed'], 'Source_runtime_metadata_current_raw_joins': guards,
    'all_original_physical_files': physical, 'all_artifacts': artifact_rows,
    'totals': {'physical_files': len(physical), 'physical_bytes': sum(p['bytes'] for p in physical),
        'artifacts': len(artifacts), 'artifact_stored_bytes': worker['total_stored_bytes'],
        'artifact_raw_bytes': sum(a['raw_bytes'] for a in artifact_rows),
        'artifact_JSON_values': sum(a['JSON_values'] for a in artifact_rows),
        'encoding_counts': dict(collections.Counter(a['encoding'] for a in artifact_rows)),
        'qualification_records': len(qual_names), 'research_artifacts': len(artifacts) - len(qual_names)},
    'all_research_case_dispositions': case_rows, 'all_research_attempts': attempt_rows,
    'all_accepted_proof_dispositions': accepted_rows, 'all_inventory_dispositions': inventory_rows,
    'proposal_tautology_callbacks': {'record': artifacts['proposal-tautology-callbacks'],
        'count': len(callbacks), 'statuses': callback_statuses,
        'by_case': dict(collections.Counter(x['case'] for x in callbacks))},
    'reconstructed_adaptive_call_ledger_from_saved_censuses': expected_calls,
    'actual_call_caps': worker['public_call_caps'], 'custody_costs': {
        'worker_post_readback': terminal['post_readback_costs'], 'observer_late': custody['late_costs'],
        'owned_child': child},
    'precise_gaps': ['Main point traces retain at most64 CHANGE/PLACED/etc events with complete-run SHA/extent; this passive audit authenticates retained bytes, full boundary states and Source-run receipts, and does not claim independent replay of unretained intermediate events.',
        'Standalone accepted receipts establish derivability from each supplied finite closed theory; no PA schema recognizer, full Hilbert geometry, universal literal Wang proof tableau, physical proof execution or RL gain is established.',
        'Geometry conventional UNKNOWN has no oracle observation or negative cut. Direct20m and point50m operation units differ, and the simple control is not a competitive baseline; seven-versus-six is no comparative advantage result.',
        'Qualification semantic finite-set/row checks are separately reviewed by L; this B support joins every full record and all hashes/censuses without rerunning those checks.'],
    'administrative_note': 'An exploratory print initially used the wrong encoding label json-gzip; corrected to actual gzip-json before this complete audit. The first complete admin audit also stopped on an incorrect total_bytes lookup; corrected to exact plan total_output_bytes. The next admin join corrected byte_sha256 from a JSON-list digest to the exact stored raw-byte digest. The third admin pass also corrected model digest sorting to include saved point/fixed-mark rows, as the Source canonicalization specifies. All stops were standard data access only; no subject invocation, mutation or scientific rerun occurred.'}
target = OUT / 'R-whole-saved-case-complete-passive-support-v1.json'
with target.open('xb') as stream:
    stream.write((json.dumps(support, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())
print(json.dumps({'support': pin(target), 'totals': support['totals'],
    'case_rows': case_rows, 'expected_calls': expected_calls}, indent=2))
