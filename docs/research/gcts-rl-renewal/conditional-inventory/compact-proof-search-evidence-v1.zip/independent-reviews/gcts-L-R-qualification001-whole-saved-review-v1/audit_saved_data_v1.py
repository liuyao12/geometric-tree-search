"""Independent administrative saved-data analysis; imports stdlib only; no subject calls."""
import pathlib,json,gzip,hashlib,collections,itertools,math,stat,copy
R=pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1'); A=R/'actual/qualification-001'; OUT=pathlib.Path(__file__).parent
checks=collections.Counter(); artifact_rows=[]; guard_rows=[]; qual_rows=[]; state_rows=[]; grid_rows=[]; outcome=collections.Counter(); negatives=[]; unknowns=[]
def need(x,why):
 if not x: raise AssertionError(why)
 checks[why]+=1
def wire(x,nl=True):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+('\n' if nl else '')).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def same(a,b,why):need(wire(a)==wire(b),why)
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:raise ValueError('duplicate JSON key')
  d[k]=v
 return d
def load(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
def native(x):
 if isinstance(x,dict):
  need(all(type(k)is str for k in x),'JSON string keys')
  for v in x.values():native(v)
 elif isinstance(x,list):
  for v in x:native(v)
 else:need(x is None or type(x)in(str,int,bool) or type(x)is float and math.isfinite(x),'finite native JSON tree')
def pin(p):
 p=pathlib.Path(p);s=p.lstat();need(stat.S_ISREG(s.st_mode) and not p.is_symlink(),'regular nonsymlink raw input');b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def ref(t,kind):
 need(type(t)is dict and set(t)=={'path','bytes','sha256'} and type(t['bytes'])is int and t['bytes']>=0,'strict rawref3')
 z=pin(t['path']);same(z,t,'complete rawref match');guard_rows.append({'kind':kind,**z});return pathlib.Path(t['path']).read_bytes()
trans=load(ref({'path':str(R/'root/qualification-001-original-owned-tool-transcript-v1.json'),'bytes':1711,'sha256':'c1683d8d96e3354540af61920babe5e6881344160cacea82ac4c7460f1e04917'},'original-tool-transcript'))
result=load(ref({'path':str(A/'worker-result.json'),'bytes':586367,'sha256':'4b7ad804b70edb3a1fe594511d37ee7707d456f2ddaa2439e62302555cbad01b'},'worker-result'))
cust=load(ref({'path':str(A/'custody.json'),'bytes':127501,'sha256':'b888973def538010e424525e021f155d833b07b7747d02f1804592477796f7da'},'custody'))
need(trans['original']['session_id']==5035 and trans['original']['chunk_id']=='26eab8' and trans['polls'][-1]['chunk_id']=='357a5c' and trans['polls'][-1]['exit_code']==trans['authoritative_observer_exit_code']==0,'authoritative original owned exit0')
need(all(p.get('session_id',5035)==5035 for p in trans['polls']),'owned session only')
plan=load(ref(cust['plan'],'plan'));authority=load(ref(cust['authority'],'authority'));consumed=load(ref(cust['consumed'],'consumed'))
for k,t in plan['sources'].items():ref(t,'Source:'+k)
for k,t in plan['metadata'].items():ref(t,'metadata:'+k)
ref(plan['python'],'D90-runtime')
need(len(plan['sources'])==16 and len(plan['metadata'])==14,'complete current16Sources14metadata')
need(set(authority)=={'schema','authorized','uses','case_id','plan','observer'} and authority['authorized']is True and type(authority['uses'])is int and authority['uses']==1,'typed exact authority6')
need(set(consumed)=={'schema','uses','case_id','plan','observer','authority','meaning'} and type(consumed['uses'])is int and consumed['uses']==1,'typed exact consumed7')
same(authority['plan'],cust['plan'],'authority plan binding');same(authority['observer'],plan['sources']['observer'],'authority observer binding');same(consumed['authority'],cust['authority'],'consumed authority binding');same(consumed['plan'],cust['plan'],'consumed plan binding');same(consumed['observer'],plan['sources']['observer'],'consumed observer binding')
need(plan['actual_dir']==str(A) and plan['case_id']==authority['case_id']==consumed['case_id']==cust['case_id']==result['case_id']=='qualification-001','whole once identity')
refs={}; data={}; rawsum=0; storedsum=0
for t in result['artifacts']:
 need(set(t)=={'encoding','name','raw_bytes','raw_sha256','stored'} and t['encoding']in('json','gzip-json'),'artifact exact6 profile')
 n=t['name'];need(n not in refs,'unique artifact name');refs[n]=t
 sb=ref(t['stored'],'artifact');need(pathlib.Path(t['stored']['path']).parent==A,'artifact owned flat path')
 b=gzip.decompress(sb) if t['encoding']=='gzip-json' else sb
 need(len(b)==t['raw_bytes'] and sha(b)==t['raw_sha256'],'full decoded artifact bytes and SHA')
 x=load(b);native(x);need(b==wire(x),'complete canonical artifact JSON');data[n]=x
 artifact_rows.append({**t,'full_stored_raw_readback':True,'canonical_native_JSON':True});rawsum+=len(b);storedsum+=len(sb)
need(len(refs)==562 and rawsum==10749480 and storedsum==result['total_stored_bytes']==3727791,'whole562 artifact census totals')
for t in cust['all_prior_owned_files']:ref(t,'custody prior owned')
expected={t['path'] for t in cust['all_prior_owned_files']}|{str(A/'custody.json')};actual={str(p) for p in A.iterdir()}
need(actual==expected and len(actual)==569,'exact physical569 files no omitted extras');owned=sum(pathlib.Path(p).stat().st_size for p in actual);need(owned==4445110,'whole owned stored byte census')
for t in cust['captures'].values():ref(t,'child capture')
need(pathlib.Path(cust['captures']['stdout']['path']).read_bytes()==pathlib.Path(cust['captures']['stdout_tail']['path']).read_bytes() and cust['captures']['stderr']['bytes']==cust['captures']['stderr_tail']['bytes']==0,'full child captures no tail loss')
wt=load(pathlib.Path(cust['captures']['stdout']['path']).read_bytes());same(wt,cust['worker_terminal'],'child terminal full capture association');same(wt['result'],cust['result'],'worker terminal result binding');same(wt['public_calls'],result['public_calls'],'worker terminal whole call ledger');same(wt['plan'],cust['plan'],'worker terminal plan')
outer=load(ref(trans['full_stdout'],'outer stdout'));need(len(ref(trans['full_stderr'],'outer stderr'))==0,'outer stderr empty')
same(outer['custody'],trans['full_custody'],'outer custody full join');same(outer['admitted_result_candidate'],cust['result'],'outer worker result candidate join');need(outer['owned_file_count']==569 and outer['owned_named_bytes']==owned and outer['status']=='COMPLETE_NORMAL','outer census and status')
ch=cust['child'];need(ch['child_exit']==0 and ch['owned_wait_complete']is True and ch['process_group_gone']is True and ch['log_eof']=={'stdout':True,'stderr':True} and ch['cleanup_errors']==[] and ch['cleanup_signals']==[] and ch['fault']is None and ch['supervisor_exception']is None and ch['combined_log_overflow']is False,'complete normal owned child wait EOF cleanup')
need(ch['child_lifetime_highwater_bytes']==158187520 and ch['child_lifetime_highwater_bytes']<=plan['limits']['child_rss_bytes'],'observed child lifetime RSS cap');need(cust['Source_and_runtime_pre_post_exact']is True,'Source postguard receipt')
need(ch['post_Popen_return_to_owned_wait_seconds']<=plan['limits']['observer_seconds'] and wt['post_readback_costs']['elapsed_main_entry_seconds']<=plan['limits']['worker_seconds'],'named clock ceiling checks')
need(len(actual)<=plan['limits']['max_output_files'] and owned<=plan['limits']['total_output_bytes'] and all(t['stored']['bytes']<=plan['limits']['body_bytes'] for t in refs.values()),'all file count body aggregate caps')
# All summary references are joined to the one complete artifact inventory.
q=result['qualification'];pc=q['point_compact'];ob=q['oracle_boundary']
need(len(pc['records'])==123 and len(ob['emissions'])==328,'all451 qualification records')
for row in pc['records']:
 t=refs['point-qualification-'+row['name']];same(row['emitter_return'],t,'point record ref identity');need(row['full_canonical_SHA256']==t['raw_sha256'] and row['full_canonical_bytes']==t['raw_bytes'],'point canonical full field join')
for row in ob['emissions']:same(row['reference'],refs[row['id']],'oracle record ref identity')
# Independent direct finite raw-model expansion. No engine or qualifier imported/called.
def expand(m):
 need(set(m)=={'schema','version','points','fixed_marks','groups'},'raw point model exact5')
 ps=sorted(map(tuple,m['points']));need(len(ps)==len(set(ps)),'unique required points')
 gs=sorted(m['groups'],key=lambda g:g['id']);fixed={tuple(p):(v,1) for p,v in m['fixed_marks']};cs={};bases={};anchors={};choices={p:[] for p in ps}
 for g in gs:
  gid=g['id'];p=tuple(g['anchor']);need(gid not in bases and p in choices,'unique group positive anchor')
  if g['kind']=='byte':
   need(set(g)=={'id','kind','anchor','mark_point','allowed_mask'} and type(g['allowed_mask'])is int and 0<=g['allowed_mask']<1<<256,'complete byte256 family')
   vals=[(v,[(tuple(g['mark_point']),v)]) for v in range(256) if g['allowed_mask']>>v&1]
  else:
   need(g['kind']=='explicit' and set(g)=={'id','kind','anchor','variants'},'explicit family fields')
   vals=[(v,[(tuple(q),z) for q,z in ms]) for v,ms in enumerate(g['variants'])]
  bases[gid]=sum(1<<v for v,ms in vals);anchors[gid]=p
  for v,ms in vals:
   need(all(type(z)is int for q,z in ms),'integer markings missing distinct zero');cs[(gid,v)]=(p,ms);choices[p].append((gid,v))
 return ps,gs,fixed,cs,bases,anchors,choices
def merge(m,ms):
 o=dict(m)
 for p,v in ms:
  if p in o and o[p][0]!=v:return None
  o[p]=(v,o.get(p,(None,0))[1]+1)
 return o
def normal_model(m):
 x=copy.deepcopy(m);x['points']=sorted(x['points']);x['fixed_marks']=sorted(x['fixed_marks']);x['groups']=sorted(x['groups'],key=lambda g:g['id'])
 # Ordered explicit variants and their marking lists are preserved by the wire normalization.
 return x
def brute_saved(m):
 ps,gs,fx,cs,bs,anc,choices=expand(m);out=[]
 # Fixed-mark-incompatible candidates cannot occur in any raw assignment.
 for comb in itertools.product(*([c for c in choices[p] if merge(fx,cs[c][1])is not None] for p in ps)):
  marks=fx
  for c in comb:
   marks=merge(marks,cs[c][1])
   if marks is None:break
  if marks is not None:out.append([list(c) for c in sorted(comb)])
 return out
state_total=0;candidate_total=0;trace_total=0
def state_check(m,s,name,role):
 global state_total,candidate_total
 ps,gs,fx,cs,bs,anc,choices=expand(m);marks=fx;tot={p:0 for p in ps};selected=[tuple(c) for c in s['selected']]
 need(len(selected)==len(set(selected)),'state selected identities unique')
 for c in selected:
  need(c in cs,'selected belongs full base');p,ms=cs[c];tot[p]+=1;need(tot[p]==1,'selected exact unit capacity');marks=merge(marks,ms);need(marks is not None,'selected actual m equality')
 ex={g:int(v,16) for g,v in s['excluded']};need(set(ex)==set(bs) and len(ex)==len(s['excluded']),'whole exclusion groups')
 dom={gid:0 for gid in bs}
 for gid in bs:need(not ex[gid]&~bs[gid],'only represented exclusions')
 for c,(p,ms) in cs.items():
  if not tot[p] and not ex[c[0]]>>c[1]&1 and merge(marks,ms)is not None:dom[c[0]]|=1<<c[1]
 deg={p:sum(v.bit_count() for g,v in dom.items() if anc[g]==p) for p in ps}
 expected={'schema':'R-finite-unit-family-state-v1','totals':[[list(p),tot[p]] for p in ps],'markings':[[list(p),v,n] for p,(v,n) in sorted(marks.items())],'selected':[list(c) for c in sorted(selected)],'domains':[[g['id'],format(dom[g['id']],'x')] for g in gs],'excluded':[[g['id'],format(ex[g['id']],'x')] for g in gs],'frontier':[[list(p),0,deg[p]] for p in ps if not tot[p]],'forward_incidence':[[list(p),[[g['id'],format(dom[g['id']],'x')] for g in gs if anc[g['id']]==p and dom[g['id']]]] for p in ps if not tot[p]],'reverse_incidence':[[g['id'],list(anc[g['id']]),format(dom[g['id']],'x')] for g in gs]}
 same(s,expected,'all9 raw fields complete both graph directions');state_rows.append({'name':name,'role':role,'complete_candidates':len(cs),'selected':len(selected),'state_sha256':sha(wire(s))});state_total+=1;candidate_total+=len(cs)
def point_result(m,r,ic,name):
 global trace_total
 need(set(r)=={'schema','status','version','model_sha256','solution','solution_state','entry_state','restored_state','counts','costs','trace','rollback','reason','scope'},'point result exact14')
 need(r['schema']=='R-finite-unit-marked-family-result-v1' and r['version']=='R-FINITE-UNIT-MARKED-FAMILY-SEARCH-v2','current point schema version')
 sols=brute_saved(m);same(ic['independent_solutions'],sols,'entire saved independent finite solution set')
 for role in ['entry_state','solution_state','restored_state']:
  if r[role]is not None:state_check(m,r[role],name,role)
 if r['status']in('SAT','UNSAT'):
  need(r['entry_state']is not None and r['restored_state']is not None and r['rollback']['prepared']is True and r['rollback']['entry_restored']is True and r['rollback']['trail_remaining']==0,'normal complete entry rollback present');same(r['entry_state'],r['restored_state'],'exact complete rollback state')
  need(r['model_sha256']==sha(wire(normal_model(m))),'complete normalized actual model digest')
  if r['status']=='SAT':need(r['solution']in sols and r['solution_state']['selected']==r['solution'] and all(z[1]==1 for z in r['solution_state']['totals']),'whole SAT tiling witness')
  else:need(not sols and r['solution']is None and r['solution_state']is None,'UNSAT entire finite raw assignment set empty')
 else:need(r['status']=='UNKNOWN' and r['solution']is None and r['solution_state']is None,'UNKNOWN never false proof');unknowns.append({'name':name,'stage':'point solve','reason':r['reason']})
 t=r['trace'];ev=t['events'];raw=b''.join(wire(e) for e in ev);need([e['seq'] for e in ev]==list(range(len(ev))) and len(ev)==t['retained_count'] and sha(raw)==t['retained_SHA256'] and len(raw)==t['retained_JSONL_bytes'],'point every retained trace rawseq bytes SHA')
 if r['status']in('SAT','UNSAT'):need(t['complete']is True and t['event_count']==len(ev) and t['full_SHA256']==sha(raw) and t['full_JSONL_bytes']==len(raw),'normal whole trace extent not flag only')
 need(all(set(e)=={'seq','kind','data'} for e in ev),'trace exact3 rows');trace_total+=len(ev)
 for e in ev:
  if e['kind']=='PLACED':need(e['data']['generation']==1 and e['data']['root_point_generation']==0,'root0 local placement generation1')
 if r['counts'] and r['status']in('SAT','UNSAT'):
  c=r['counts'];need(c['nodes']==sum(e['kind']=='PLACED' for e in ev) and c['branch_decisions']==sum(e['kind']=='BRANCH' for e in ev) and c['forced_placements']==sum(e['kind']=='PLACED' and e['data']['forced']is True for e in ev),'complete trace placement branch forced counts')
 outcome['POINT:'+r['status']]+=1
 return len(sols)
# Independent builder shapes and direct clause projection, no builder invocation.
def builder_check(x,n):
 b=x['builder'];need(set(b)=={'schema','status','version','model','binding','byte_group_ids','clause_witness_groups','normalized_cuts','counts','reason','scope'},'builder exact11')
 if b['status']!='COMPLETE':
  need(b['status']=='UNKNOWN' and all(b[k]is None for k in ['model','byte_group_ids','clause_witness_groups','normalized_cuts']),'builder refusal no partial declared model');unknowns.append({'name':n,'stage':'builder','reason':b['reason']});return
 count=x['byte_count'];fixed=dict(x['fixed_bytes']);ng=x['nogoods'];norm=[]
 for i,cut in enumerate(ng['cuts']):
  d={};vacuous=False
  for j,v in cut:
   if j in d and d[j]!=v:vacuous=True
   d[j]=v
   if j in fixed and fixed[j]!=v:vacuous=True
  norm.append({'input_cut_index':i,'status':'VACUOUS_WHOLE_CUT_DROPPED' if vacuous else 'RETAINED','literals':[] if vacuous else [[j,v] for j,v in sorted(d.items()) if j not in fixed]})
 same(b['normalized_cuts'],norm,'all cut normalization fixed mismatch whole vacuity');same(b['binding'],ng['binding'],'whole builder binding')
 m=b['model'];expected_groups=[];points=[[2*i,0,0] for i in range(count)];maps=[]
 need(len(b['byte_group_ids'])==count and len(set(b['byte_group_ids']))==count,'exact byte group identity map')
 for i,gid in enumerate(b['byte_group_ids']):expected_groups.append({'id':gid,'kind':'byte','anchor':[2*i,0,0],'mark_point':[2*i,0,1],'allowed_mask':(1<<256)-1})
 for cut,row in zip(norm,b['clause_witness_groups'],strict=True):
  ci=cut['input_cut_index'];groups=[]
  if cut['status']=='RETAINED':
   p=[2*ci,2,0];points.append(p);need(len(row['groups'])==len(cut['literals']),'all residual witness families')
   for mp,(j,v) in zip(row['groups'],cut['literals'],strict=True):
    same({k:mp[k] for k in ['byte_index','forbidden_byte']},{'byte_index':j,'forbidden_byte':v},'actual witness literal association');gid=mp['group_id'];expected_groups.append({'id':gid,'kind':'byte','anchor':p,'mark_point':[2*j,0,1],'allowed_mask':((1<<256)-1)^(1<<v)});groups.append(mp)
   maps.append({'input_cut_index':ci,'anchor':p,'groups':groups})
  else:maps.append({'input_cut_index':ci,'anchor':None,'groups':[]})
 same(b['clause_witness_groups'],maps,'entire auxiliary witness map');same(m['groups'],expected_groups,'entire actual byte and witness families');same(m['points'],points,'all byte and clause positive anchors');same(m['fixed_marks'],[[[2*i,0,1],v] for i,v in sorted(fixed.items())],'whole fixed m values')
 context={'builder_version':b['version'],'binding':ng['binding'],'fixed_bytes':[[i,v] for i,v in sorted(fixed.items())],'normalized_cuts':norm};need(m['version']==b['version']+':'+sha(wire(context)),'builder full bound context semantic digest')
 cnt=point_result(m,x['solver'],x['independent_check'],n)
 if not fixed and count==1:
  allrows=[{'byte_values':[v],'allowed':all(any(v!=b for j,b in cut) for cut in ng['cuts'])} for v in range(256)]
  sols=x['independent_check']['independent_solutions'];project=sorted({dict((g,v) for g,v in s)[b['byte_group_ids'][0]] for s in sols});same(x['free_assignment_projection'],{'all256_direct_assignments':allrows,'projected_bytes':project,'independent_full_tiling_count':cnt},'full256 direct relation live255 auxiliary tilings');need(project==list(range(1,256)) and cnt==255,'all255 live witness byte projection')
 else:
  allows=all(any(fixed[j]!=v for j,v in cut) for cut in ng['cuts']);need(x['original_cut_relation_allows_fixed_assignment']is allows and bool(cnt)==allows,'fixed byte truth vs full auxiliary tiling projection')
 outcome['BUILDER:COMPLETE']+=1
# Compiler literal catalogue and complete point templates, compared by data only.
compiles={}
def compile_check(x,n):
 z=x['result'];m=x['machine'];h=x['head_marks'];need(set(z)=={'schema','version','status','machine','machine_sha256','limits','head_marks','effective_transitions','glyphs','palette','witnesses','counts','reason','scope'},'compiler exact14')
 if z['status']!='COMPLETE':
  need(z['status']in('REJECTED','UNKNOWN_BUDGET') and all(z[k]is None for k in ['effective_transitions','glyphs','palette','witnesses']),'compiler negative no complete prefix');(unknowns if z['status']=='UNKNOWN_BUDGET' else negatives).append({'name':n,'stage':'compiler','reason':z['reason']});outcome['COMPILER:'+z['status']]+=1;return
 normal={k:sorted(v) if k in('states','alphabet','accept','transitions') else v for k,v in m.items()};same(z['machine'],normal,'complete normalized Machine5');need(z['machine_sha256']==sha(wire(normal)),'Machine5 fingerprint')
 eff=sorted([tuple(t) for t in m['transitions'] if t[0]not in m['accept']]+[(q,s,q,s,0) for q in m['accept'] for s in m['alphabet']]);same(z['effective_transitions'],[{'index':i,'q':q,'read':s,'next':qn,'write':w,'move':d,'origin':'IMPLICIT_ACCEPT_IDENTITY' if q in m['accept'] else 'EXPLICIT'} for i,(q,s,qn,w,d) in enumerate(eff)],'all effective accept identities and nondet source transitions')
 expected=[]
 for s in sorted(m['alphabet']):expected.append((['C','COPY',s],['P',s],['P',s],['IDLE'],['IDLE'],'COPY',None,None))
 expected.append((['C','WALL'],['WALL'],['WALL'],['IDLE'],['IDLE'],'WALL',None,None))
 for move in [0,1,-1]:
  for i,(q,s,qn,w,d) in enumerate(eff):
   if d!=move:continue
   msg=['IDLE'] if d==0 else ['RIGHT' if d==1 else 'LEFT',qn]
   expected.append((['C','SOURCE',q,s,qn,w,d],['H',q,s],['H',qn,w] if d==0 else ['P',w],msg if d==-1 else ['IDLE'],msg if d==1 else ['IDLE'],'STAY' if d==0 else 'MOVE_RIGHT' if d==1 else 'MOVE_LEFT',i,msg))
 for move,tag in [(1,'RECEIVE_RIGHT'),(-1,'RECEIVE_LEFT')]:
  for q in sorted({r[2] for r in eff if r[4]==move}):
   for s in sorted(m['alphabet']):
    msg=['RIGHT' if move==1 else 'LEFT',q];expected.append((['C',tag,q,s],['P',s],['H',q,s],msg if move==1 else ['IDLE'],msg if move==-1 else ['IDLE'],tag,None,msg))
 need(len(expected)==len(z['palette'])==len(z['witnesses'])==z['counts']['predicted_tiles']==z['counts']['tiles_constructed'],'all predicted literal tiles present')
 col=lambda v:json.dumps(v,ensure_ascii=True,separators=(',',':'));fam=collections.Counter();markcount=0;remote=0;vcols={};hcols={}
 for want,t,w in zip(expected,z['palette'],z['witnesses'],strict=True):
  ident,ng,sg,wg,eg,f,i,msg=want;tid=col(ident);same(t,{'id':tid,'N':col(ng),'S':col(sg),'W':col(wg),'E':col(eg)},'all literal tile edge identities and ordering');fam[f]+=1
  ni=int(ng[0]=='H');si=int(sg[0]=='H');rr=[-2,-1,1,1] if f=='RECEIVE_RIGHT' else [2,-1,1,1] if f=='RECEIVE_LEFT' else None
  ms=[[-1,0,0,t['W']],[0,-1,0,t['N']],[0,1,0,t['S']],[1,0,0,t['E']]]
  if h:
   ms.extend([[0,-1,1,ni],[0,1,1,si]])
   if rr is not None:ms.append(rr);remote+=1
  ms.sort(key=lambda r:tuple(r[:3]));same(w['point_template'],{'t':[[0,0,0,1]],'m':ms},'entire t and local remote m point prototype')
  same(w,{'tile_id':tid,'family':f,'transition_index':i,'input_glyph':ng,'output_glyph':sg,'message':msg if msg is not None else ['IDLE'],'head_types':{'input':ni,'output':si,'remote':rr},'point_template':{'t':[[0,0,0,1]],'m':ms}},'full compiler witness fields')
  markcount+=len(ms)
  for edge in ['N','S']:vcols[t[edge]]=json.loads(t[edge])
  for edge in ['E','W']:hcols[t[edge]]=json.loads(t[edge])
 same(z['glyphs'],{'vertical':[{'id':s,'glyph':vcols[s]} for s in sorted(vcols)],'horizontal':[{'id':s,'glyph':hcols[s]} for s in sorted(hcols)]},'complete parseable glyph catalogue')
 same(z['counts']['families'],{k:fam[k] for k in ['COPY','WALL','STAY','MOVE_RIGHT','MOVE_LEFT','RECEIVE_RIGHT','RECEIVE_LEFT']},'all7 family counts')
 need(z['counts']['complete_census']is True and z['counts']['positive_slots']==len(expected) and z['counts']['total_mark_slots']==markcount and z['counts']['head_remote_mark_slots']==remote,'complete prototype slot counts')
 compiles[(n.split('-')[3],h)]=z;outcome['COMPILER:COMPLETE']+=1
point_names=[n for n in refs if n.startswith('point-qualification-')]
for n in point_names:
 x=data[n];rec={'name':n,'raw':refs[n]['raw_sha256']}
 if '-Rows-'in n:continue
 if '-Compiler-'in n or '-K0'in n:
  if 'result'in x:compile_check(x,n);rec['outcome']=x['result']['status']
  else:need(x['status']=='EXPECTED_EXACT_FOREIGN_PROPAGATION' and x['exception']['same_instance']is True,'compiler foreign exception exact instance');negatives.append({'name':n,'stage':'compiler callback','exception':x['exception']});rec['outcome']=x['status'];outcome['COMPILER:FOREIGN']+=1
 elif '-Byte-'in n:
  if 'builder'in x:builder_check(x,n);rec['outcome']=x['builder']['status'];
  else:need(x['status']=='EXPECTED_MODEL_ERROR' and x['exception']['type']=='ModelError','builder malformed exact rejection');negatives.append({'name':n,'stage':'builder','exception':x['exception']});rec['outcome']=x['status'];outcome['BUILDER:MODEL_ERROR']+=1
 elif 'result'in x:rec['complete_finite_tilings']=point_result(x['model'],x['result'],x['independent_check'],n);rec['outcome']=x['result']['status']
 else:
  need(x['status']in('EXPECTED_EXACT_FOREIGN_PROPAGATION','EXPECTED_MODEL_ERROR'),'point explicit negative receipt');
  if x['status']=='EXPECTED_EXACT_FOREIGN_PROPAGATION':need(x['exception']['same_instance']is True,'point foreign exact instance')
  negatives.append({'name':n,'stage':'point input or callback','exception':x['exception']});outcome['POINT:'+x['status']]+=1;rec['outcome']=x['status']
 qual_rows.append(rec)
# Whole saved literal grids: every saved reachable configuration layer, all cells/edges/t/m.
for n in point_names:
 if '-Rows-'not in n:continue
 x=data[n];m=x['machine'];tag=n.split('-')[3];p=compiles[(tag,False)];hp=compiles[(tag,True)];tiles={t['id']:t for t in p['palette']};witness=[{w['tile_id']:w for w in zz['witnesses']} for zz in [p,hp]];layers=x['literal_rows']['layers'];refx=x['reference'];need(x['steps']==2 and len(layers)==len(refx['layers'])==3 and refx['complete']is True and refx['status']=='COMPLETE' and refx['partial_layer']is None,'all3 exact NTM layers complete')
 same(refx['input']['machine'],m,'reference exact machine association');same(refx['input']['initial'],x['initial'],'reference initial binding')
 prev=None;gcount=0;cellcount=0
 for j,(ly,rl) in enumerate(zip(layers,refx['layers'],strict=True)):
  same(ly['configurations'],rl['configurations'],'all complete literal and global NTM configuration sets');need(ly['step']==rl['step']==j and rl['count']==len(ly['configurations']) and rl['accepting_count']==sum(c['state']in m['accept'] for c in ly['configurations']),'every layer count acceptance')
  need(len(ly['witnesses'])==len(ly['configurations']),'whole grid witness per distinct reached configuration');same([w['configuration'] for w in ly['witnesses']],ly['configurations'],'all grid witness associations')
  if j==0:same(ly['configurations'],[x['initial']],'literal layer0 actual initial')
  else:
   nextset=set()
   for c in prev:
    q=c['state'];hd=c['head'];tape=c['tape'];moves=[(q,tape[hd],q,tape[hd],0)] if q in m['accept'] else [r for r in m['transitions'] if r[0]==q and r[1]==tape[hd]]
    for _,_,qn,v,d in moves:
     if 0<=hd+d<len(tape):tt=list(tape);tt[hd]=v;nextset.add((qn,hd+d,tuple(tt)))
   need({(c['state'],c['head'],tuple(c['tape'])) for c in ly['configurations']}==nextset,'saved entire adjacent layers satisfy and exhaust raw global transition relation')
  for w in ly['witnesses']:
   grid=w['tile_rows'];need(len(grid)==j,'whole grid height');top=[['WALL']]+[['H',x['initial']['state'],v] if k==x['initial']['head'] else ['P',v] for k,v in enumerate(x['initial']['tape'])]+[['WALL']];marks=[{},{}];totals={}
   for y,row in enumerate(grid):
    need(len(row)==len(top),'whole grid width walls included');ts=[tiles[z] for z in row];need(json.loads(ts[0]['N'])==json.loads(ts[0]['S'])==json.loads(ts[-1]['N'])==json.loads(ts[-1]['S'])==['WALL'],'fixed left right wall cells')
    need(json.loads(ts[0]['W'])==json.loads(ts[-1]['E'])==['IDLE'],'closed IDLE exterior');same([json.loads(t['N']) for t in ts],top,'every cell literal vertical input edge');need(all(ts[k]['E']==ts[k+1]['W'] for k in range(len(ts)-1)),'every internal literal horizontal equality');top=[json.loads(t['S']) for t in ts]
    for cx,tid in enumerate(row):
     for mode,wm in enumerate(witness):
      proto=wm[tid]['point_template']
      for dx,dy,dz,u in proto['t']:
       key=(2*cx+dx,2*y+dy,dz)
       if mode==0:totals[key]=totals.get(key,0)+u;need(totals[key]==1,'full grid actual point t exact unit')
      for dx,dy,dz,v in proto['m']:
       key=(2*cx+dx,2*y+dy,dz);need(key not in marks[mode] or wire(marks[mode][key])==wire(v),'full grid actual assigned m equality including remote outsideQ');marks[mode][key]=v
    cellcount+=len(row)
   hh=[(k-1,g[1],g[2]) for k,g in enumerate(top) if g[0]=='H'];need(len(hh)==1,'whole row exact one actual head');head,q,s=hh[0];dec={'head':head,'state':q,'tape':[g[2] if g[0]=='H' else g[1] for g in top[1:-1]]};same(dec,w['configuration'],'decode actual final head and tape from full grid');gcount+=1
  prev=ly['configurations']
 accepts=any(c['state']in m['accept'] for c in layers[-1]['configurations']);need(x['literal_rows']['accepts']is accepts and refx['acceptance']['at_requested_step']is accepts,'actual final head acceptance not patch inference');need(x['literal_row_to_point_engine_solves']==0,'literal grid not point solve claim')
 grid_rows.append({'name':n,'layers':3,'full_grid_witnesses':gcount,'full_grid_cells_examined':cellcount,'both_plain_and_head_point_markings':True,'acceptance':accepts});qual_rows.append({'name':n,'outcome':'COMPLETE_ALL3_LAYERS','full_grid_witnesses':gcount});outcome['NTM:COMPLETE_CONTEXT']+=1
# Public byte grammar checked directly on the retained given syntax, not via any codec/checker.
def formula_wire(f):
 def name(n):
  need(type(n)is str and n and all(32<=ord(c)<=126 for c in n),'given raw formula names exact printable ASCII')
  return list(n.encode('ascii'))+[0]
 def terms(ts):
  need(type(ts)is list,'given term list exact array');o=[]
  for t in ts:o += [64]+term(t)
  return o+[65]
 def term(t):
  need(type(t)is list and t,'raw formal term array')
  if t[0]=='var':need(len(t)==2,'raw var arity');return [32]+name(t[1])
  need(t[0]=='fun' and len(t)==3,'raw function arity');return [33]+name(t[1])+terms(t[2])
 need(type(f)is list and f,'raw formal formula array')
 tag=f[0]
 if tag=='bot':need(len(f)==1,'raw bottom arity');return [48]
 if tag=='eq':need(len(f)==3,'raw equality arity');return [49]+term(f[1])+term(f[2])
 if tag=='pred':need(len(f)==3,'raw predicate arity');return [50]+name(f[1])+terms(f[2])
 if tag=='not':need(len(f)==2,'raw negation arity');return [51]+formula_wire(f[1])
 if tag in('and','or','imp'):need(len(f)==3,'raw binary connective arity');return [{'and':52,'or':53,'imp':54}[tag]]+formula_wire(f[1])+formula_wire(f[2])
 need(tag=='all' and len(f)==3,'raw quantifier arity');return [55]+name(f[1])+formula_wire(f[2])
# All oracle preparation/current context pairs and syntax-only boundary records.
preps={};oracle_statuses=collections.Counter();nativepairs=0;cutcount=0
for n in refs:
 if not n.startswith('oracle-qualification-'):continue
 x=data[n];need(set(x)=={'schema','id','kind','data','checks','passed'} and x['id']==n and x['passed']is True and x['checks'] and all(type(v)is bool and v for v in x['checks'].values()),'all oracle raw case fields and explicit assertions')
 if x['kind']=='PREPARATION':
  d=x['data'];c=d['carrier']['value'];need(d['input_role']=='input_node' and c['version']=='RAW-PROOF-BYTE-CARRIER-MIN8-v2','actual raw input triple not stream-only')
  need(c['known']['theory_sha256']==sha(wire(c['known']['theory'],False)) and c['known']['target_sha256']==sha(wire(c['known']['target'],False)) and c['program_sha256']==sha(wire(d['program'],False)),'carrier full program theory goal associations')
  nodes=c['nodes'];need(len({tuple(p) for p in nodes})==len(nodes),'whole heap canonical unique pair table')
  for i,pair in enumerate(nodes):need(type(pair)is list and len(pair)==2 and all(type(v)is int and 0<=v<257+i for v in pair),'whole heap acyclic native integer refs')
  need(len(c['byte_rows'])==c['byte_count']==len(c['marker_ids']) and len(set(c['marker_ids']))==c['byte_count'],'every byte distinct fresh private marker')
  for i,row in enumerate(c['byte_rows']):need(row['byte_index']==i and row['node_id']==row['node_index']+257 and nodes[row['node_index']]==[0,row['marker_id']] and row['marker_id']in c['marker_ids'] and row['marker_id']>=257+c['trusted_prefix_nodes'],'all byte HEAD private fresh tail binding')
  preps[n]=d;outcome['ORACLE:PREPARATION']+=1
for n in refs:
 if not n.startswith('oracle-qualification-'):continue
 x=data[n];d=x['data'];kind=x['kind'];qr={'name':n,'kind':kind}
 if kind=='NATIVE_OBSERVER_PAIR':
  prep=d['preparation'];same(prep['reference'],refs[prep['id']],'pair complete actual preparation reference');pd=preps[prep['id']];c=pd['carrier']['value'];p=pd['program'];v=d['byte_values'];nv=d['native'];ov=d['observer'];lim=d['observer_limits'];nativepairs+=1
  need(set(ov)=={'schema','version','status','reason','binding','byte_values','vm','final_heap','dependencies','cut','trace_extent','resources','scope'},'observer exact13 full raw receipt')
  same(ov['byte_values'],v,'observer actual bytes binding');need(all(type(b)is int and 0<=b<=255 for b in v) and len(v)==c['byte_count'],'every selected byte native domain')
  bind={'program_sha256':sha(wire(p,False)),'carrier_value_sha256':sha(wire(c,False)),'theory_sha256':sha(wire(c['known']['theory'],False)),'goal_sha256':sha(wire(c['known']['target'],False)),'byte_count':len(v),'boundary_version':'R-GIVEN-GOAL-WIRE-BOUNDARY-v1','carrier_version':'RAW-PROOF-BYTE-CARRIER-MIN8-v2','oracle_version':'R-BYTE-DEPENDENCY-TREE-VM-v1'};same(ov['binding'],bind,'full actual observation context binding')
  a=copy.deepcopy(nv);b=copy.deepcopy(ov['vm']);a.pop('seconds');b.pop('seconds');a['trace']=a['trace'][:lim['max_trace_records']];same(a,b,'entire native ordinary receipt excluding only seconds and trace prefix')
  same(ov['final_heap'],d['native_final_heap'],'whole final native and observed heap')
  selected=copy.deepcopy(c['nodes'])
  for row,byte in zip(c['byte_rows'],v,strict=True):selected[row['node_index']][0]=byte
  same(d['native_final_heap'][:len(selected)],selected,'entire trusted carrier prefix and selected byte HEADs preserved')
  need(len({tuple(row) for row in d['native_final_heap']})==len(d['native_final_heap']),'whole runtime heap unique interned pair rows')
  for i,row in enumerate(d['native_final_heap']):need(type(row)is list and len(row)==2 and all(type(z)is int and 0<=z<257+i for z in row),'whole final runtime heap acyclic exact refs')
  need(nv['heap_nodes']==len(d['native_final_heap']),'native full heap extent')
  nt=b''.join(wire(e,False)+b'\n' for e in nv['trace']);need(sha(nt)==nv['event_sha256'],'native full retained evaluator event SHA')
  te=ov['trace_extent'];need(te['retained_events']==len(ov['vm']['trace']) and te['full_event_sha256']==nv['event_sha256'] and te['complete_prefix']is(len(ov['vm']['trace'])==te['total_events']),'full event extent or explicit retained prefix')
  if 'value'in nv:
   need(type(nv['value'])is int and te['total_events']==nv['steps'],'normal true full evaluator count');expected='ACCEPTED' if nv['value']==1 else 'CERTIFIED_REJECTION' if nv['value']==0 else 'NORMAL_OTHER_RETURN';need(nv['status']==('accepted' if nv['value']==1 else 'rejected'),'native nonboolean exact value category')
  else:expected='UNKNOWN_FAULT';need(nv['status']=='rejected' and nv['reason'].startswith('invalid data operation: ') and type(nv['pc'])is int and type(nv['function'])is str,'fault direct native category not false cut')
  need(ov['status']==expected,'full normal/fault observation classification')
  direct_expected=('UNKNOWN_FAULT' if '-fault-'in n else 'NORMAL_OTHER_RETURN' if n.endswith('normal-data-node') else 'ACCEPTED' if n.endswith(('normal-true','all-opcodes','byte-255')) else 'CERTIFIED_REJECTION')
  need(expected==direct_expected,'independent declared diagnostic category not return selfclassification');oracle_statuses[expected]+=1
  if expected=='UNKNOWN_FAULT':unknowns.append({'name':n,'stage':'native/observer fault','reason':ov['reason'],'cut':None})
  deps=ov['dependencies'];need(len({z['byte_index'] for z in deps})==len(deps),'complete distinct byte dependency indexes')
  for z in deps:need(set(z)=={'byte_index','value','first_step','head_reads','cons_alias_consults'} and type(z['byte_index'])is int and 0<=z['byte_index']<len(v) and z['value']==v[z['byte_index']] and all(type(z[k])is int and z[k]>=0 for k in ['first_step','head_reads','cons_alias_consults']) and z['head_reads']+z['cons_alias_consults']>0,'all dependency raw roles and values')
  if prep['id'].endswith(('-watch','-unread')):need(len(deps)==1 and deps[0]['byte_index']==0 and deps[0]['head_reads']==1 and deps[0]['cons_alias_consults']==0,'full HEAD watch despite retained prefix')
  if prep['id'].endswith('-alias'):need(len(deps)==1 and deps[0]['cons_alias_consults']==1 and deps[0]['head_reads']==0 and len(ov['final_heap'])==len(c['nodes'])+int(v[0]!=7),'both intern HIT MISS cons-tail dependency')
  if expected=='CERTIFIED_REJECTION':
   same(ov['cut'],{'schema':'R-certified-byte-rejection-cut-v1','binding':bind,'literals':sorted([[z['byte_index'],v[z['byte_index']]] for z in deps]),'value':0,'trace_sha256':nv['event_sha256']},'full normal0 only exact contextual cut');cutcount+=1
  else:need(ov['cut']is None,'no cut from acceptance other or fault')
  if '-byte-'in n:need(v==[int(n[-3:])] and ov['status']==('ACCEPTED' if v[0]==255 else 'CERTIFIED_REJECTION'),'all256 actual byte classes')
  if n.endswith('normal-data-node'):need(nv['value']==c['byte_rows'][0]['node_id'] and nv['value']>256,'ordinary node return not proofreject')
  if n.endswith('all-opcodes'):need({e[2] for e in nv['trace']}=={'const','move','cons','head','tail','pair','atom','succ','not','branch','jump','call','return'} and nv['peak_frames']>=2,'all13 native opcode and nested frame control')
  qr['outcome']=expected;qr['dependency_count']=len(deps);qr['normal_cut']=ov['cut']is not None
 elif kind=='OWNED_OBSERVER_REFUSAL':need(d['observer']['status']=='UNKNOWN_BUDGET' and d['observer']['cut']is None,'all8 observer budget refusals not negatives');qr['outcome']='UNKNOWN_BUDGET';unknowns.append({'name':n,'stage':'observer','reason':d['observer']['reason']});oracle_statuses['UNKNOWN_BUDGET']+=1
 elif kind=='GIVEN_FORMULA_ONLY_BOUNDARY':
  b=d['boundary'];need(set(b)=={'schema','version','status','reason','goal_wire_hex','byte_count','minimum_stream_bytes','fixed_bytes','resources','scope'},'boundary exact10 raw fields');need(b['byte_count']==d['byte_count'],'boundary exact byte capacity')
  if d['formal_expected_wire']is not None:
   fw=d['formal_expected_wire'];same(fw,formula_wire(d['given_formula']),'full given formula direct byte grammar');minimum=len(fw)+4;need(b['minimum_stream_bytes']==minimum,'complete syntax minimum statement')
   if n.endswith('-exact'):
    need(b['status']=='COMPLETE' and b['goal_wire_hex']==bytes(fw).hex(),'exact full formal goal wire');start=d['byte_count']-len(fw)-1;same(b['fixed_bytes'],[[0,1],[1,16]]+[[start+i,v] for i,v in enumerate(fw)]+[[d['byte_count']-1,17]],'only prefix1 LINE and goal suffix END fixed no proof skeleton');need(start>=3,'at least one free rule byte')
   else:need(b['status']=='EMPTY_CAPACITY' and b['fixed_bytes']==[] and b['goal_wire_hex']is None,'onebelow no partial boundary')
  else:
   need(b['status']in('REJECTED_INPUT','UNKNOWN_BUDGET') and b['fixed_bytes']==[] and b['goal_wire_hex']is None,'malformed/resource no partial syntax map')
  qr['outcome']=b['status'];outcome['BOUNDARY:'+b['status']]+=1
  if b['status']=='UNKNOWN_BUDGET':unknowns.append({'name':n,'stage':'boundary','reason':b['reason']})
  elif b['status']!='COMPLETE':negatives.append({'name':n,'stage':'boundary syntax/capacity','reason':b['reason']})
 elif kind=='FOREIGN_CALLBACK_PROPAGATION':need(d['unexpected_return']is None and d['exception']['type']=='_ForeignSentinel','foreign observer/boundary callback class propagation');qr['outcome']='FOREIGN_PROPAGATION';negatives.append({'name':n,'stage':'observer or boundary foreign callback','exception':d['exception']})
 elif kind=='PREPARATION':qr['outcome']='PREPARATION_COMPLETE'
 else:raise AssertionError('unknown oracle kind '+kind)
 qual_rows.append(qr)
# Exact case coverage from all retained context descriptors, not merely record totals.
need({int(n[-3:]) for n in refs if n.startswith('oracle-qualification-byte-')}==set(range(256)),'complete byte0through255 control set')
need(len({(wire(data[n]['machine']),wire(data[n]['initial'])) for n in point_names if '-Rows-'in n})==32,'complete32 distinct NTM contexts')
need(len([n for n in point_names if '-Byte-'in n])==50 and len([n for n in point_names if '-Binary-'in n])==14,'all50 byte and14 binary controls')
need(nativepairs==271 and len(preps)==12 and len(qual_rows)==451,'all451 qualification raw records independently covered')
need(outcome['NTM:COMPLETE_CONTEXT']==32 and len(compiles)==4 and len(state_rows)>0,'complete32 contexts4 fixed palette variants')
# Concrete directed expected outcomes, without invoking producers or reconstructing execution.
def pointrec(suffix):return data['point-qualification-'+suffix]
need(pointrec('P02-global-dead')['result']['counts']['nodes']==pointrec('P02-global-dead')['result']['counts']['forced_placements']==0,'empty global domain precedes any forced placement')
need(pointrec('P03-remote-zero')['result']['status']=='SAT' and pointrec('P04-remote-conflict')['result']['status']=='UNSAT','outsideQ assigned zero agreement and disagreement')
need(pointrec('P05-missing-zero')['result']['solution']==[['A',0]],'missing marking remains unconstrained unlike assigned zero')
need(pointrec('P06-identities')['result']['solution']==[['B',0]],'actual preferred identity selected with complete base fallback')
need(pointrec('P07-backtrack')['result']['counts']['backtracks']>0 and pointrec('P07-backtrack')['result']['counts']['exclusions']>0,'actual failed branch exclusion rollback path exercised')
need(any(ord(c)>65535 for c in pointrec('P11-Unicode')['model']['groups'][0]['id']),'nonBMP accepted namespace actually exercised')
# Cross-observation controls use all stored raw evidence, not code replay.
u=data['oracle-qualification-unread-a']['data']['observer'];v=data['oracle-qualification-unread-b']['data']['observer'];same(u['cut'],v['cut'],'unread byte completion invariant whole cut');need(u['trace_extent']['full_event_sha256']==v['trace_extent']['full_event_sha256'],'unread values do not alter evaluator trace')
z=data['oracle-qualification-empty-watch-cut']['data']['observer'];need(z['dependencies']==[] and z['cut']['literals']==[],'complete normal false empty-watch cut explicitly global')
for n in ['oracle-qualification-trace-zero','oracle-qualification-trace-one']:
 o=data[n]['data']['observer'];need(o['trace_extent']['complete_prefix']is False and o['trace_extent']['total_events']>len(o['vm']['trace']) and o['cut']is not None,'clipped prefix cannot clip full watch/hash evaluation')
need(result['qualification']['oracle_boundary']['status']=='COMPLETE_PASS' and pc['status']=='COMPLETE_COMPONENT_QUALIFICATION','worker qualification statuses current')
need(pc['public_calls']=={'engine.solve':77,'engine.make_byte_model':50,'compact.compile_palette':12,'ntm.simulate':32},'fixed point qualifier actual call census')
support={'schema':'L-R-qualification001-full-saved-data-support-v1','subject_execution_calls':0,'method':'stdlib complete byte/gzip/native JSON and direct saved-data equality/finite relations; no project Source imported, compiled or invoked; no VM/solver/checker replay','artifacts':artifact_rows,'raw_guards':guard_rows,'qualification_records':qual_rows,'full_state9_checks':state_rows,'full_literal_grid_checks':grid_rows,'assertion_counts':dict(sorted(checks.items())),'outcomes':dict(outcome),'oracle_pair_outcomes':dict(oracle_statuses),'negative_controls':negatives,'unknown_controls':unknowns,'finite_point_UNSAT_records':[r['name'] for r in qual_rows if r.get('outcome')=='UNSAT'],'boundary_capacity_records':[r['name'] for r in qual_rows if r.get('outcome')=='EMPTY_CAPACITY'],'totals':{'artifacts':len(refs),'raw_artifact_bytes':rawsum,'stored_artifact_bytes':storedsum,'physical_owned_files':len(actual),'owned_stored_bytes':owned,'qualification_records':len(qual_rows),'point_state9_snapshots':state_total,'candidate_snapshot_pairs_examined':candidate_total,'point_trace_rows_full_retained':trace_total,'native_oracle_pairs':nativepairs,'normal0_cuts':cutcount,'NTM_contexts':len(grid_rows),'literal_grid_witnesses':sum(r['full_grid_witnesses'] for r in grid_rows),'literal_grid_cells':sum(r['full_grid_cells_examined'] for r in grid_rows)},'custody_costs':{'child':ch,'worker_post_readback':wt['post_readback_costs'],'observer_late':cust['late_costs'],'scope':cust['scopes']}}
(OUT/'complete-saved-data-support-v1.json').write_bytes(json.dumps(support,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False).encode()+b'\n')
print(json.dumps({'status':'PASS','totals':support['totals'],'outcomes':dict(outcome),'oracle':dict(oracle_statuses),'support':pin(OUT/'complete-saved-data-support-v1.json')},sort_keys=True))
