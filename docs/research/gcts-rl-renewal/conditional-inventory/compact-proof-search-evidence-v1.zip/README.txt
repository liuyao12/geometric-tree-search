GCTS compact tile and proof search evidence, phase R

This is a frozen evidence snapshot of one admitted research run. The scientific authority is permanently spent. The archive preserves original Source versions, all actual controls and certificates, independent reviews, and raw path/hash associations.

Proof search uses a native logical oracle and a finite equality-mark point model; the small literal Wang palettes are separate tape-machine controls. No trained RL, induction search or literal universal Wang proof tableau is established. Instruction traces may be retained prefixes; full event hashes and complete dependency sets are labeled.

Inspect study/root/report-draft/ for the final readable HTML and results JSON, study/actual/qualification-001/ for the complete original experiment, and independent-reviews/ for complete saved-data audits. Runtime binaries are identified, not bundled. This snapshot predates publication; live publication/TLS completion evidence is maintained separately.
