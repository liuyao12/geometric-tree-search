"""Static Source edits before handoff, no subject imports/calls."""
from pathlib import Path
D=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C')
p=D/'unknown_stream_qualification_worker_v1.py';s=p.read_text()
s=s.replace("heap=libs['tree_machine'].Heap(nodes,limit=200000)","heap=run.call('tree.Heap',libs['tree_machine'].Heap,nodes,limit=200000)")
s=s.replace("heap=TM.Heap([]);alltags=", "heap=run.call('tree.Heap',TM.Heap,[]);alltags=")
s=s.replace("native_heap=TM.Heap(program['nodes'])", "native_heap=run.call('tree.Heap',TM.Heap,program['nodes'])")
s=s.replace("'construction':lower.construction_receipt()", "'construction':run.call('C1.lower.receipt',lower.construction_receipt)")
s=s.replace("    return run.save('C1-full-construction-attempt.json',result)","    return {'status':result['status'],'evidence':run.save('C1-full-construction-attempt.json',result)}")
for role in ['real_parser','grammar_observer']:
    s=s.replace("run.call('tree.compile',libs['tree_machine'].Compiler,retained['"+role+"'].decode('ascii')).declaration()", "run.call('tree.declaration',run.call('tree.compile',libs['tree_machine'].Compiler,retained['"+role+"'].decode('ascii')).declaration)")
s=s.replace("run.call('tree.compile',libs['tree_machine'].Compiler,diagnostic_source()).declaration()", "run.call('tree.declaration',run.call('tree.compile',libs['tree_machine'].Compiler,diagnostic_source()).declaration)")
base={'tree.compile':3,'tree.declaration':3,'tree.Heap':49,'codec.encode':31,'codec.decode':52,'carrier.build':52,'carrier.verify':307,'native.run':47,'heap.decode':40,'fol.check':12,'tree.encode_json':7,'lower.construct':2,'lower.declaration':1,'carrier.mask':3,'carrier.materialize_physical':256,'carrier.materialize_binary':256,'carrier.decode_physical':257,'carrier.decode_binary':257,'lower.physical':2,'native.diagnostic':1,'lower.initial':1,'lower.virtual':1,'lower.physical_input':2,'C1.lower.construct':1}
extra={'C1.lower.declaration':1,'C1.lower.receipt':1,'C1.carrier.build':1,'C1.carrier.mask':1,'C1.lower.initial':1,'C1.lower.physical':1}
fn="""\ndef check_call_census(calls, construction_status):
    expected=dict(EXPECTED_CALL_BASE)
    if construction_status != 'UNKNOWN_SELECTED_CONSTRUCTION':expected.update(EXPECTED_CALL_C1_SELECTED)
    equal(calls,expected,'entire closed direct public call census, no hidden recipe')
\n"""
s=s.replace('def main():\n',fn+'\ndef main():\n')
s=s.replace("        guard_read(plan,plan_ref,once_refs);consumed_read(plan,plan_ref,directory);run.gate()", "        check_call_census(run.calls,construction_ref['status'])\n        guard_read(plan,plan_ref,once_refs);consumed_read(plan,plan_ref,directory);run.gate()")
pos=s.index('class Run:')
s=s[:pos]+'EXPECTED_CALL_BASE = '+repr(base)+'\nEXPECTED_CALL_C1_SELECTED = '+repr(extra)+'\n\n'+s[pos:]
p.write_text(s)
p=D/'unknown_stream_qualification_observer_v1.py';s=p.read_text().replace('EXPECTED_CALLS = None','EXPECTED_CALL_BASE = '+repr(base)+'\nEXPECTED_CALL_C1_SELECTED = '+repr(extra))
s=s.replace("require(type(value['public_calls']) is dict and all(type(k) is str and type(v) is int and v >= 1 for k,v in value['public_calls'].items()), 'worker complete typed direct-call census, worker controls bind exact branch-conditional recipe')", "require(encode(value['public_calls']) in (encode(EXPECTED_CALL_BASE),encode(dict(EXPECTED_CALL_BASE,**EXPECTED_CALL_C1_SELECTED))), 'whole exact direct-call census: full selected C1 construction or explicit selected-construction UNKNOWN only')")
p.write_text(s)
