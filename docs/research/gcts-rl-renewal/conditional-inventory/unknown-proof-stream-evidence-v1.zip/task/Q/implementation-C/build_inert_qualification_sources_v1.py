"""Administrative Source assembly only. Never imports/calls any subject module."""
import ast,hashlib,json,pathlib
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1')
P=pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
D=Q/'implementation-C'
def pin(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,s):
    with p.open('x') as f:f.write(s)
paths={'worker':str(D/'unknown_stream_qualification_worker_v1.py'),'observer':str(D/'unknown_stream_qualification_observer_v1.py'),'tree_machine':str(Q/'reused-sources/tree_machine.py'),'codec':str(Q/'implementation-B/independent_proof_byte_stream_v1.py'),'fol_checker':str(P/'implementation-B/independent_fol_checker_v1.py'),'carrier':str(Q/'implementation-L/proof_byte_carrier_v2.py'),'lowering':str(Q/'implementation-L/tape_tree_machine_min8_budgeted_v2.py'),'heap_decoder':str(Q/'implementation-L/ascii_tree_heap_decoder_v1.py'),'real_parser':str(D/'proof_byte_fol_checker_v1.tree'),'grammar_observer':str(D/'proof_byte_grammar_observer_v1.tree')}
meta_paths={'grammar':Q/'root/common-design-and-byte-grammar-v1.json','codec':Q/'implementation-B/independent-proof-byte-stream-complete-effective-public-ABI-v3.json','carrier':Q/'implementation-L/raw-proof-byte-carrier-MIN8-complete-public-ABI-v2.json','heap_decoder':Q/'implementation-L/ascii-tree-heap-decoder-complete-public-ABI-v1.json','real_parser':D/'runtime-proof-byte-parser-complete-public-ABI-v1.json','grammar_observer':D/'grammar-observer-sister-complete-public-ABI-v1.json','fol_checker':P/'implementation-B/independent-fol-checker-complete-effective-public-ABI-v2.json'}
# The grammar-observer API filename is resolved against exact known own packet, not a broad scan.
if not meta_paths['grammar_observer'].exists():
    hand=json.loads((D/'grammar-observer-sister-complete-inert-Source-handoff-v1.json').read_text())
    refs=[]
    def visit(x):
        if type(x)is dict:
            if set(x)>={'path','bytes','sha256'} and 'ABI' in x['path']:refs.append(x)
            for v in x.values():visit(v)
        elif type(x)is list:
            for v in x:visit(v)
    visit(hand)
    assert len(refs)==1
    meta_paths['grammar_observer']=pathlib.Path(refs[0]['path'])
components={r:(pin(pathlib.Path(p))['bytes'],pin(pathlib.Path(p))['sha256']) for r,p in paths.items() if r not in ('worker','observer')}
metadata={r:pin(p) for r,p in meta_paths.items()}
limits={'worker_seconds':1200,'observer_seconds':1260,'cleanup_seconds':5,'log_bytes':1048576,'body_bytes':268435456,'model_raw_bytes':536870912,'total_output_bytes':805306368,'max_output_files':128,'child_rss_bytes':2147483648,'native_steps':20000000,'observation_steps':10000000,'selected_steps':10000000,'physical_steps':100000000}
python={'path':'/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12','bytes':18058560,'sha256':'d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
const='ROOT = pathlib.Path('+repr(str(Q))+')\nPYTHON = '+repr(python)+'\nLIMITS = '+repr(limits)+'\nSOURCE_PATHS = '+repr(paths)+'\nCOMPONENT_PINS = '+repr(components)+'\nMETADATA_PINS = '+repr(metadata)+"\nCOHORT = 'AUTHORED-RAW-BYTE-INTEGRATION-G18-M16-S12-ALL256-OP13-v1'\nCONSUMED_MEANING = 'exclusive spent marker before the sole child launch; failures remain spent'\n"
old=(P/'implementation-C/component_qualification_worker_v3.py').read_text();tree=ast.parse(old)
names=['QualificationFailure','encode','sha','require','exact_fields','safe_file','read_ref','rawref','raw_association','parse_json','plan_read','guard_read','consumed_read']
lines=old.splitlines(keepends=True)
helpers='\n\n'.join(''.join(lines[n.lineno-1:n.end_lineno]) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names)
helpers=helpers.replace('GCTS-FOL-NTM-component-once-plan-v2','GCTS-raw-proof-integration-once-plan-v1').replace('Root-FOL-NTM-component-once-authority-v2','Root-raw-proof-integration-once-authority-v1').replace('Root-FOL-NTM-component-once-consumed-v2','Root-raw-proof-integration-once-consumed-v1')
helpers=helpers.replace("require(plan['python'] == PYTHON and type(plan['python']['bytes']) is int, 'D90 runtime')","require(encode(plan['python']) == encode(PYTHON), 'type-exact D90 runtime')")
body=(D/'qualification_worker_body_v1.txt').read_text()
body=body.replace("ops={x['instruction'][0] for x in native['trace']} if native['trace'] and type(native['trace'][0]) is dict else set()","ops={x[2] for x in native['trace']}\n    require(ops=={'const','move','cons','head','tail','pair','atom','succ','not','branch','jump','call','return'},'all13 opcodes actually executed in retained native trace')\n    require(native['peak_frames']>=2 and 257 in program['constants']+list(range(257,257+native['heap_nodes'])),'nested live-register/cons257 diagnostic')")
body=body.replace("result['selected']=run.save('C1-complete-selected-model.json.gz',{'program':program,'selected':selected,'construction':lower.construction_receipt()},True)","""result['selected']=run.save('C1-complete-selected-model.json.gz',{'program':program,'selected':selected,'construction':lower.construction_receipt()},True)
        carrier=run.call('C1.carrier.build',libs['carrier'].build_carrier,program,{'functions':{},'predicates':{},'axioms':{},'schemas':[]},['bot'],1,carrier_limits(),budget=run.budget)
        caps={'word_capacity':64,'heap_padding':4096,'stack_capacity':32768}
        mask=run.call('C1.carrier.mask',libs['carrier'].build_physical_mask,program,selected,carrier,caps,carrier_limits(),budget=run.budget)
        initial=run.call('C1.lower.initial',lower.initial,{'nodes':carrier['value']['nodes'],'node':carrier['value']['input_node']},**caps)
        equal(initial,mask['value']['selected_placeholder_initial'],'genuine C1 rawtriple physical-root/entire initial binding')
        result['genuine_C1_mask']=run.save('C1-complete-carrier-mask.json.gz',{'carrier':carrier,'mask':mask,'input_role':'input_node','proof_byte_domain':'all256 unselected; no proof AST input'},True)""")
worker='''"""INERT authored encoding/component qualification. No unknown-proof search.
All factories and subject loads occur only after a separately reviewed fresh once.
"""\nimport argparse,gzip,hashlib,itertools,json,os,pathlib,re,resource,stat,sys,time,traceback,types\n\nVERSION = 'GCTS-RAW-PROOF-INTEGRATION-WORKER-v1'\n'''+const+'\n'+helpers+'\n\n'+body
put(pathlib.Path(paths['worker']),worker)
obs=(P/'implementation-C/component_qualification_observer_v3.py').read_text()
a=obs.index('VERSION = ');z=obs.index('TAIL_BYTES = ')
oldboot=obs[obs.index('BOOTSTRAP = '):obs.index('EXPECTED_CALLS = ')]
obs=obs[:a]+"VERSION = 'GCTS-RAW-PROOF-INTEGRATION-OBSERVER-v1'\n"+const+oldboot+"EXPECTED_CALLS = None\n"+obs[z:]
replaces={'GCTS-FOL-NTM-component-once-plan-v2':'GCTS-raw-proof-integration-once-plan-v1','Root-FOL-NTM-component-once-authority-v2':'Root-raw-proof-integration-once-authority-v1','Root-FOL-NTM-component-once-consumed-v2':'Root-raw-proof-integration-once-consumed-v1','GCTS-FOL-NTM-worker-terminal-v1':'GCTS-raw-proof-worker-terminal-v1','COMPLETE_PASS_RESULT_WRITTEN':'COMPLETE_COMPONENT_CONTROLS_RESULT_WRITTEN','GCTS-FOL-NTM-owned-':'GCTS-raw-proof-owned-','scientific COMPLETE_PASS':'component COMPLETE_COMPONENT_CONTROLS','seven Source roles':'ten Source roles','fixed five component Source pins':'fixed eight component Source pins','four public ABI roles':'seven public ABI roles','FOL/NTM component':'raw proof-byte integration'}
for a,b in replaces.items():obs=obs.replace(a,b)
obs=obs.replace("require(encode(value['public_calls']) == encode(EXPECTED_CALLS), 'worker terminal complete public call census')","require(type(value['public_calls']) is dict and all(type(k) is str and type(v) is int and v >= 1 for k,v in value['public_calls'].items()), 'worker complete typed direct-call census, worker controls bind exact branch-conditional recipe')")
put(pathlib.Path(paths['observer']),obs)
put(D/'qualification-closed-Source-parameters-v1.json',json.dumps({'schema':'C-raw-proof-integration-closed-Source-parameters-v1','status':'SOURCE_ONLY_UNRUN_NOT_PLAN_OR_AUTHORITY','python':python,'Source_paths':paths,'component_pins':components,'metadata':metadata,'limits':limits,'cohort':'AUTHORED-RAW-BYTE-INTEGRATION-G18-M16-S12-ALL256-OP13-v1'},indent=2,sort_keys=True)+'\n')
print(json.dumps({'worker':pin(pathlib.Path(paths['worker'])),'observer':pin(pathlib.Path(paths['observer']))}))
