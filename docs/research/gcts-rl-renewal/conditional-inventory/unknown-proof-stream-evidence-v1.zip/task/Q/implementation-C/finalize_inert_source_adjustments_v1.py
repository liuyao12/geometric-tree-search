"""Source-only prefreeze adjustments; no subject code execution."""
from pathlib import Path
p=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/unknown_stream_qualification_worker_v1.py')
s=p.read_text()
s=s.replace("native=run.call('native.diagnostic',TM.run,program,TM.Heap(program['nodes']),256,limit=100000,keep=100000)","native_heap=TM.Heap(program['nodes'])\n    native=run.call('native.diagnostic',TM.run,program,native_heap,256,limit=100000,keep=100000)")
s=s.replace("require(virtual['status']=='accepted' and physical['status']=='accepted','native/selected/literal physical full opcode outcome')", """require(virtual['status']=='accepted' and physical['status']=='accepted','native/selected/literal physical full opcode outcome')
    parsed_heap=[]
    for record in virtual['words'][d['heap']].split(';'):
        if not record:continue
        identity,children=record.split(':');left,right=children.split(',')
        require(int(identity[::-1],2)==257+len(parsed_heap),'selected complete heap sequential IDs')
        parsed_heap.append([int(left[::-1],2),int(right[::-1],2)])
    equal(parsed_heap,clone(native_heap.nodes),'native/selected complete final heap equality')
    require(int(virtual['words'][d['work']][::-1],2)==native['value'],'native/selected returned data word equality')""")
s=s.replace("'native':native,'virtual':virtual,'literal':physical", "'native':native,'native_final_nodes':clone(native_heap.nodes),'virtual':virtual,'literal':physical")
# Additional generic decoder assurance uses Source literals, evaluated only in the future once.
s=s.replace("    return run.save('wire-resource-controls.json.gz',{'records':out},True)","""    # Canonical repeated-child DAG expands twice, not a shared native mutable object.
    dag=[[1,256],[257,256],[257,258],[1,259]]
    answer=run.call('heap.decode',H.decode_ascii_json,dag,260,heap_limits(),budget=run.budget)
    require(answer['status']=='DECODED','canonical repeated-edge DAG syntax')
    equal(answer['value'],[[],[]],'whole repeated-edge JSON')
    require(answer['value'][0] is not answer['value'][1],'expanded mutable children detached')
    out.append({'id':'heap-repeated-DAG','nodes':dag,'root':260,'return':answer})
    answer=run.call('heap.decode',H.decode_ascii_json,dag,260,heap_limits(max_expanded_output_nodes=2),budget=run.budget)
    require(answer['status']=='UNKNOWN_BUDGET' and answer['value'] is None,'repeated-edge output cap, no prefix')
    out.append({'id':'heap-repeated-DAG-cap','return':answer})
    # Duplicate raw key ASCII x, values null/true; every cons pair itself unique/canonical.
    dup=[[120,256],[6,256],[5,1],[257,258],[257,259],[261,256],[260,262],[0,263]]
    answer=run.call('heap.decode',H.decode_ascii_json,dup,264,heap_limits(),budget=run.budget)
    require(answer['status']=='REJECTED' and answer['value'] is None,'duplicate decoded object key rejected')
    out.append({'id':'heap-duplicate-key','nodes':dup,'root':264,'return':answer})
    return run.save('wire-resource-controls.json.gz',{'records':out},True)""")
p.write_text(s)
