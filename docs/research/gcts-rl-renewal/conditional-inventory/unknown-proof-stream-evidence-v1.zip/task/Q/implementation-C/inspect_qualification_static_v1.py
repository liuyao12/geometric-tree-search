import ast,hashlib,json,pathlib,symtable
D=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C')
for name in ['unknown_stream_qualification_worker_v1.py','unknown_stream_qualification_observer_v1.py']:
 p=D/name;s=p.read_text();a=ast.parse(s);st=symtable.symtable(s,str(p),'exec');compile(s,str(p),'exec',dont_inherit=True)
 def walk(t):
  yield t
  for c in t.get_children():yield from walk(c)
 allscopes=list(walk(st));globals0=set(st.get_identifiers());unresolved=sorted({symbol.get_name() for sc in allscopes[1:] for symbol in sc.get_symbols() if symbol.is_global() and symbol.is_referenced() and symbol.get_name() not in globals0 and symbol.get_name() not in __builtins__.__dict__})
 print(json.dumps({'file':name,'bytes':len(s.encode()),'sha256':hashlib.sha256(s.encode()).hexdigest(),'lines':len(s.splitlines()),'topdefs':[(n.name,n.lineno,n.end_lineno) for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))],'scopes':len(allscopes),'unresolved':unresolved}))
