"""Source-only immutable successor construction; never invokes subject code."""
import ast,pathlib
D=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C')
old=D/'unknown_stream_qualification_worker_v1.py';s=old.read_text()
s=s.replace("GCTS-RAW-PROOF-INTEGRATION-WORKER-v1","GCTS-RAW-PROOF-INTEGRATION-WORKER-v2").replace('/unknown_stream_qualification_worker_v1.py','/unknown_stream_qualification_worker_v2.py').replace('/unknown_stream_qualification_observer_v1.py','/unknown_stream_qualification_observer_v2.py')
a=ast.parse(s);run=next(n for n in a.body if isinstance(n,ast.ClassDef) and n.name=='Run');save=next(n for n in run.body if isinstance(n,ast.FunctionDef) and n.name=='save')
lines=s.splitlines(keepends=True)
new_save='''    def save(self,name,value,gz=False):
        self.current='SAVE '+name;self.gate()
        path=self.directory/name
        require(re.fullmatch('[A-Za-z0-9][A-Za-z0-9.-]*',name) is not None and not path.exists(),'new safe output')
        existing=[]
        for present in self.directory.iterdir():
            safe_file(str(present))
            info=present.stat()
            require(info.st_size<=LIMITS['body_bytes'],'existing body bound before new output')
            existing.append(info.st_size)
        prior_stored=sum(existing)
        reserve=2*LIMITS['log_bytes']
        require(len(existing)+1+9<=LIMITS['max_output_files'],'next owned file plus remaining custody/outer count reserve before open')
        require(prior_stored+1+reserve<=LIMITS['total_output_bytes'],'existing aggregate plus nonempty next body and whole reserve before open')
        rawhash=hashlib.sha256();rawsize=0
        encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
        with path.open('xb') as base:
            bounded=BoundedStoredWriter(base,prior_stored,reserve)
            destination=gzip.GzipFile(filename='',mode='wb',fileobj=bounded,mtime=0) if gz else bounded
            try:
                for part in itertools.chain(encoder.iterencode(value),['\\n']):
                    self.budget();raw=part.encode('ascii');rawsize+=len(raw)
                    require(rawsize<=LIMITS['model_raw_bytes'] if gz else rawsize<=LIMITS['body_bytes'],'complete JSON raw extent cap')
                    rawhash.update(raw);destination.write(raw)
            finally:
                if gz:destination.close()
            bounded.flush();os.fsync(base.fileno())
        storedhash=hashlib.sha256();storedsize=0
        with path.open('rb') as handle:
            while True:
                block=handle.read(1048576)
                if not block:break
                self.budget();storedhash.update(block);storedsize+=len(block)
        require(storedsize==bounded.tell() and storedsize<=LIMITS['body_bytes'],'stored readback extent equals every prechecked actual write')
        require(prior_stored+storedsize+reserve<=LIMITS['total_output_bytes'],'stored whole aggregate and unchanged reserve readback')
        check=hashlib.sha256();extent=0
        opener=gzip.open if gz else open
        with opener(path,'rb') as handle:
            while True:
                block=handle.read(1048576)
                if not block:break
                self.budget();check.update(block);extent+=len(block)
                require(extent<=LIMITS['model_raw_bytes'] if gz else extent<=LIMITS['body_bytes'],'readback raw extent')
        require(extent==rawsize and check.digest()==rawhash.digest(),'full lossless serialization readback')
        ref={'path':str(path),'bytes':storedsize,'sha256':storedhash.hexdigest()}
        record={'stored':ref,'encoding':'gzip-JSON-ASCII-LF' if gz else 'JSON-ASCII-LF','raw_bytes':rawsize,'raw_sha256':rawhash.hexdigest()}
        self.files.append(record)
        require(len(self.files)+10<=LIMITS['max_output_files'] and sum(x['stored']['bytes'] for x in self.files)+2*LIMITS['log_bytes']<=LIMITS['total_output_bytes'],'whole named output count/bytes reserve')
        self.gate();return record
'''
s=''.join(lines[:save.lineno-1])+new_save+''.join(lines[save.end_lineno:])
writer='''class BoundedStoredWriter:
    """Gate each actual base write, including gzip header/close trailer."""
    def __init__(self,base,prior_stored,reserve):
        self.base=base;self.prior_stored=prior_stored;self.reserve=reserve;self.stored=0
    def write(self,raw):
        require(type(raw) is bytes,'stored writer exact byte chunk')
        proposed=self.stored+len(raw)
        require(proposed<=LIMITS['body_bytes'],'proposed stored body bound before write')
        require(self.prior_stored+proposed+self.reserve<=LIMITS['total_output_bytes'],'proposed aggregate plus same whole reserve before write')
        written=self.base.write(raw)
        require(written==len(raw),'complete actual base write')
        self.stored=proposed
        return written
    def tell(self):
        return self.stored
    def flush(self):
        self.base.flush()


'''
s=s.replace('class Run:\n',writer+'class Run:\n',1)
with (D/'unknown_stream_qualification_worker_v2.py').open('x') as f:f.write(s)
s=(D/'unknown_stream_qualification_observer_v1.py').read_text().replace('GCTS-RAW-PROOF-INTEGRATION-OBSERVER-v1','GCTS-RAW-PROOF-INTEGRATION-OBSERVER-v2').replace('/unknown_stream_qualification_worker_v1.py','/unknown_stream_qualification_worker_v2.py').replace('/unknown_stream_qualification_observer_v1.py','/unknown_stream_qualification_observer_v2.py')
with (D/'unknown_stream_qualification_observer_v2.py').open('x') as f:f.write(s)
