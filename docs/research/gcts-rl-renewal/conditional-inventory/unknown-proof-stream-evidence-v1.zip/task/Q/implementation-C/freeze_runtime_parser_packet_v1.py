"""Administrative Source AST/manual/byte preservation only; no VM/codec calls."""
import ast,builtins,difflib,hashlib,json,pathlib,symtable
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');O=Q/'implementation-C';S=O/'proof_byte_fol_checker_v1.tree';P=O/'proof_byte_parser_prefix_v1.tree';OLD=pathlib.Path('/private/tmp/gcts-B-fixed-FOL-integration-audit-20261027-v1/fol_checker.tree')
def enc(x):return (json.dumps(x,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def save(name,x):
 p=O/name
 with p.open('xb') as f:f.write(enc(x))
 return pin(p)
raw=S.read_bytes();prefix=P.read_bytes();old=OLD.read_bytes();t=ast.parse(raw,filename=str(S));old_t=ast.parse(old);new_t=ast.parse(prefix)
assert len(raw)==29429 and h(raw)=='1e62e4052349d3ff0e6a7746b111acd426e6ffede92e264c23a6be31016af5a5'
renamed=old.replace(b'def main(request):',b'def ps_semantic_main(request):',1);assert old.count(b'def main(request):')==1 and raw==prefix+renamed
assert raw[len(prefix):].replace(b'def ps_semantic_main(request):',b'def main(request):',1)==old
primitives={'cons':2,'head':1,'tail':1,'is_pair':1,'atom_eq':2,'byte_succ':1}
functions={n.name:n for n in t.body};assert len(functions)==len(t.body)==92 and all(isinstance(n,ast.FunctionDef) for n in t.body)
assert t.body[0].name=='main' and len(t.body[0].args.args)==1
assert all(n.name=='main' or n.name.startswith('ps_') for n in new_t.body)
assert not (set(functions)&set(primitives))
arity={n.name:len(n.args.args) for n in t.body};syntax_visits=0

def expression(e,locals_):
 global syntax_visits
 syntax_visits+=1
 if isinstance(e,ast.Name):assert e.id in locals_,(e.id,e.lineno);return
 if isinstance(e,ast.Constant):assert e.value is None or type(e.value) is bool or type(e.value) is int and 0<=e.value<=255 or type(e.value) is str;return
 if isinstance(e,ast.Call):
  assert isinstance(e.func,ast.Name) and not e.keywords and e.func.id in set(arity)|set(primitives)
  assert len(e.args)==(arity|primitives)[e.func.id],(e.func.id,e.lineno)
  for a in e.args:expression(a,locals_)
  return
 if isinstance(e,ast.UnaryOp):assert isinstance(e.op,ast.Not);expression(e.operand,locals_);return
 if isinstance(e,ast.BoolOp):
  assert isinstance(e.op,(ast.And,ast.Or))
  for a in e.values:expression(a,locals_)
  return
 raise AssertionError((type(e).__name__,e.lineno))

def statements(body,locals_,loop_depth=0):
 for n in body:
  if isinstance(n,ast.Assign):
   assert len(n.targets)==1 and isinstance(n.targets[0],ast.Name);expression(n.value,locals_);locals_.add(n.targets[0].id)
  elif isinstance(n,ast.Return):expression(n.value,locals_)
  elif isinstance(n,ast.If):expression(n.test,locals_);statements(n.body,locals_,loop_depth);statements(n.orelse,locals_,loop_depth)
  elif isinstance(n,ast.While):assert not n.orelse;expression(n.test,locals_);statements(n.body,locals_,loop_depth+1)
  elif isinstance(n,ast.Break):assert loop_depth>0
  else:raise AssertionError((type(n).__name__,n.lineno))
for f in t.body:
 a=f.args;assert not (f.decorator_list or a.defaults or a.kw_defaults or a.kwonlyargs or a.vararg or a.kwarg or a.posonlyargs or f.returns)
 assert all(x.annotation is None for x in a.args)
 statements(f.body,{x.arg for x in a.args})
# Return-kinds are static proof annotations, not evaluated functions.
boolean={'nil','same','size1','size2','size3','member','is_type','text_is','fields','signature_ok','term_ok','formula_ok','byte_less','text_less','truth','valuations','tautology','formulas_ok','references','proof','rule_ok','ps_nil','ps_size3','ps_byte','ps_ascii_byte','ps_text_profile','ps_unary','ps_json_profile','ps_json_array','ps_json_object'}
conditions=[]
def bool_expr(e,fn):
 if isinstance(e,ast.Constant):return type(e.value) is bool or type(e.value) is int and e.value in (0,1)
 if isinstance(e,ast.Call):return isinstance(e.func,ast.Name) and e.func.id in boolean|{'is_pair','atom_eq'}
 if isinstance(e,ast.UnaryOp):return isinstance(e.op,ast.Not) and bool_expr(e.operand,fn)
 if isinstance(e,ast.BoolOp):return all(bool_expr(x,fn) for x in e.values)
 return isinstance(e,ast.Name) and fn=='free' and e.id=='bound'
for f in t.body:
 for n in ast.walk(f):
  if isinstance(n,(ast.If,ast.While)):
   assert bool_expr(n.test,f.name),(f.name,n.lineno,ast.unparse(n.test))
   conditions.append({'function':f.name,'line':n.lineno,'test':ast.unparse(n.test),'Bool01_contract':True})
for f in t.body:
 for n in ast.walk(f):
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='free':
   assert len(n.args)==2 and (isinstance(n.args[1],ast.Constant) and type(n.args[1].value) is bool or f.name=='free' and isinstance(n.args[1],ast.Name) and n.args[1].id=='bound')
# Complete raw+AST rows and conservative transitive closure; no Compiler invoked.
lines=raw.splitlines(keepends=True);old_lines=old.splitlines(keepends=True);rows=[];graph={};oldmap={x.name:x for x in old_t.body}
for f in t.body:
 b=b''.join(lines[f.lineno-1:f.end_lineno]);calls=sorted({n.func.id for n in ast.walk(f) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)});graph[f.name]=[n for n in calls if n in functions]
 inherited=(f.name in oldmap and f.name!='main') or f.name=='ps_semantic_main';origin='main' if f.name=='ps_semantic_main' else f.name
 original=None
 if inherited:
  of=oldmap[origin];ob=b''.join(old_lines[of.lineno-1:of.end_lineno]);original={'name':origin,'raw_sha256':h(ob),'AST_sha256':h(ast.dump(of).encode())}
  if f.name=='ps_semantic_main':assert b.replace(b'def ps_semantic_main(request):',b'def main(request):',1)==ob
  else:assert b==ob and ast.dump(f)==ast.dump(of)
 rows.append({'name':f.name,'arity':arity[f.name],'line':f.lineno,'end_line':f.end_lineno,'signature':ast.unparse(f.args),'raw_bytes':len(b),'raw_sha256':h(b),'AST_sha256':h(ast.dump(f).encode()),'positioned_AST_sha256':h(ast.dump(f,include_attributes=True).encode()),'calls':calls,'legacy_origin':original})
reachable=set();todo=['main']
while todo:
 n=todo.pop()
 if n in reachable:continue
 reachable.add(n);todo.extend(graph[n])
st=symtable.symtable(raw.decode(),str(S),'exec');scopes=[]
flags=[('assigned','is_assigned'),('free','is_free'),('global','is_global'),('imported','is_imported'),('local','is_local'),('nonlocal','is_nonlocal'),('parameter','is_parameter'),('referenced','is_referenced')]
def scope(s,path):
 entries=[]
 for name in sorted(s.get_identifiers()):
  z=s.lookup(name);entries.append({'name':name,'true_flags':[out for out,m in flags if getattr(z,m)()]})
 scopes.append({'path':path,'line':s.get_lineno(),'type':s.get_type(),'entries':entries,'entry_sha256':h(enc(entries))})
 for i,c in enumerate(s.get_children()):scope(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
scope(st,'module');assert len(scopes)==93
all_global_calls={n.func.id for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)};assert all_global_calls-set(functions)==set(primitives)
code=compile(raw,str(S),'exec',dont_inherit=True);del code
forward=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile='fol_checker.tree',tofile=S.name,n=3)).encode();inverse=''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),old.decode().splitlines(keepends=True),fromfile=S.name,tofile='fol_checker.tree',n=3)).encode()
patchrefs=[]
for name,b in [('old-semantic-to-runtime-parser-v1.patch',forward),('runtime-parser-to-old-semantic-v1.patch',inverse)]:
 p=O/name
 with p.open('xb') as out:out.write(b)
 patchrefs.append(pin(p))
strategy=pin(O/'runtime-proof-byte-parser-prefrozen-strategy-and-ABI-v1.json');grammar=pin(Q/'root/common-design-and-byte-grammar-v1.json');VM=pin(pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/recovered-logical-Source-v1/tree_machine.py'));master=pin(pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/basic-tiling-algorithm.current-published-master-v1.md'))
preserve=save('runtime-proof-byte-parser-complete-preservation-v1.json',{'schema':'C-runtime-proof-byte-parser-complete-preservation-v1','current_Source':pin(S),'prefix_fragment':pin(P),'old_semantic_Source':pin(OLD),'old_bytes':17577,'exact_one_edit':'def main(request): -> def ps_semantic_main(request):','renamed_suffix_bytes':len(renamed),'raw_equals_prefix_plus_exact_renamed_legacy':True,'exact_strip_prefix_reverse_rename_restores_entire_old_Source':True,'old63_nonmain_helpers_raw_and_plain_AST_identical':True,'oldmain_body_exact_with_only_name_changed':True,'current_functions':92,'new_prefix_functions':len(new_t.body),'old_functions':64,'patches':patchrefs,'scope':'Source transport/preservation only; no Compiler/VM/program/function execution.'})
static=save('runtime-proof-byte-parser-complete-static-helper-ledger-v1.json',{'schema':'C-runtime-proof-byte-parser-complete-static-helper-ledger-v1','Source':pin(S),'references':[grammar,VM,master,strategy,preserve],'all92_functions':rows,'call_graph':graph,'conservative_reachable_from_main':sorted(reachable),'not_reachable_in_conservative_graph':sorted(set(functions)-reachable),'primitive_calls_only':primitives,'all93_symbol_scopes':scopes,'symbol_flag_names':[x[0] for x in flags],'all_omitted_flags_false':True,'all_conditions_Bool01':conditions,'only_special_Bool_parameter':'free.bound; every call passes literal Bool or the same recursive bound Bool','compiler_compatibility':'Independently walk exact recovered Compiler language: only top FunctionDef/ordinary positionalargs/Name assignments/If/While/Return/Break and Constant/Name/NameCall/Not/And/Or. All arities/static names/local syntactic loads valid; byte constants0..255 only. This AST check is not an executed VMCompiler invocation.','static_expression_visits':syntax_visits,'whole_AST_sha256':h(ast.dump(t).encode()),'whole_positioned_AST_sha256':h(ast.dump(t,include_attributes=True).encode()),'unused_Python_compile':'PASS, discarded without execution','VM_compilation_declaration':None,'activity':{'project_imports_compiler_VM_parser_codec_semantic_functions':0,'proof_AST_fixtures_factories_models_CLI_tests':0,'codeobject_execution':0,'network':0}})
returns={'main':'Bool01; grammar/profile fail False, otherwise old semantic verdict','ps_nil':'Bool01','ps_size3':'Bool01','ps_byte':'Bool01 under validated Heap value domain0..256/nodes','ps_ascii_byte':'Bool01','ps_text_profile':'Bool01','ps_unary':'Bool01','ps_json_profile':'Bool01','ps_json_array':'Bool01','ps_json_object':'Bool01','ps_take':'False or cons(byte_atom,remaining_rows)','ps_name':'False or cons(JSONstring_node,remaining_rows)','ps_term_list':'False or cons(raw_JSONterm_item_list,remaining_rows)','ps_term':'False or cons(JSONterm_node,remaining_rows)','ps_two_terms':'False or cons(JSONformula_node,remaining_rows)','ps_two_formulas':'False or cons(JSONformula_node,remaining_rows)','ps_formula':'False or cons(JSONformula_node,remaining_rows)','ps_reference':'False or cons(JSONnatural_node,remaining_rows)','ps_one_formula_line':'False or cons(JSONline_object,remaining_rows)','ps_axiom_line':'False or cons(JSONline_object,remaining_rows)','ps_instantiate_line':'False or cons(JSONline_object,remaining_rows)','ps_distribute_line':'False or cons(JSONline_object,remaining_rows)','ps_eq_subst_line':'False or cons(JSONline_object,remaining_rows)','ps_mp_line':'False or cons(JSONline_object,remaining_rows)','ps_generalize_line':'False or cons(JSONline_object,remaining_rows)','ps_line':'False or cons(JSONline_object,remaining_rows)','ps_proof':'False or complete nonempty JSONproof_array; END17 already last','ps_request':'JSONrequest object with exactly five fixed unique fields','ps_semantic_main':'Inherited Bool01 semantic verdict'}
notes={'main':'Proper raw triple; generic prefix profile and exactempty schemas; version1; runtime parse; fixed request; renamed semantic call. No theorem/proof data from host.','ps_nil':'Exact nil256 test, not byte0.','ps_size3':'Short-circuit pair guards before all three tails; exact nil terminus.','ps_byte':'Under valid Heap, nonpair and nonnil is exactlybyte0..255. Reject node/nil before grammar.','ps_ascii_byte':'Finite32..126 scan; next successor only before126 so no255 trap.','ps_text_profile':'Proper nonempty rawbyteword and everybyte printable ASCII.','ps_unary':'Proper all1 list; known JSON integer canonical shape.','ps_json_profile':'Known generic JSON tags0..6, every JSONstring and objectkey profile; not a logical oracle or duplicatekey/acyclicity verifier.','ps_json_array':'Proper itemlist and recursive generic values.','ps_json_object':'Proper rows, raw printable keys and generic values. Canonical unique keys/acyclicity externalboundary.','ps_take':'Proper row-list head is row pair, marker tail is a node, rowhead byte. Return byte/rest carry. Marker freshness/identity/alias are carrier obligation, not guessed here.','ps_name':'Consume until0, reject empty/control/highbytes; reverse exactly and wrapstring2.','ps_term_list':'Only64+term item or65end, preserving order; emptyargumentlists allowed.','ps_term':'Only32var and33fun, with dynamic name/list values from stream.','ps_two_terms':'Sequential two terms, generic formula constructor.','ps_two_formulas':'Sequential two formulas, generic constructor.','ps_formula':'Complete eight tags48..55; recursively fixed prefix order, allsuccess carry pairs.','ps_reference':'80unarycount then81; construct exact JSONnat3/all1. Prior validity delegated to semantic checker.','ps_one_formula_line':'Only static tautology/refl callers; rule/formula unique fields.','ps_axiom_line':'Name then formula; unique rule/name/formula.','ps_instantiate_line':'Universal formula,term,formula in grammarorder.','ps_distribute_line':'Variable,antecedent,consequent,formula in grammarorder.','ps_eq_subst_line':'Variable,template,left,right,formula in grammarorder.','ps_mp_line':'Antecedentref,implicationref,formula in grammarorder.','ps_generalize_line':'Sourceref,variable,formula in grammarorder.','ps_line':'Exactly8 numericcodes0..7; no induction/assumption/block exposure.','ps_proof':'LINE16 sequence, at leastone complete line, END17 iff wholecursor exhausted; no accepted suffix/padding/prefix.','ps_request':'Object0 with protocolgcts-fol-1,given theory,emptyblocks,parsedproof,given target.','ps_semantic_main':'Exactly old main body; preserves complete inheritedchecker. Empty schemas/blocks and parser8codes restrict current bridge.'}
manual_rows=[]
for row in rows:
 name=row['name'];manual_rows.append({'name':name,'line':row['line'],'end_line':row['end_line'],'arity':row['arity'],'signature':row['signature'],'return_contract':returns.get(name,'Inherited old helper contract unchanged; see exact predecessor Source and direct callgraph'),'walk':notes.get(name,'Legacy helper retained byte-for-byte and plainAST-identical. Conservative transitive semantic/binding/substitution/tautology/rule/JSON/list code is unchanged; its sourcebody was read before authorship.'),'inherited':row['legacy_origin'] is not None})
manual=save('runtime-proof-byte-parser-complete-helper-walkthrough-v1.json',{'schema':'C-runtime-proof-byte-parser-complete-helper-walkthrough-v1','Source':pin(S),'all92_helpers':manual_rows,'preservation':preserve,'static':static,'parser_argument_independence':'ps_proof and its syntactic descendants receive rows/static tag names only, never theory or target. Known prefix is used for profile/semantic validation, not constructing a chosen proof AST.','progress_argument':'Every successful grammar loop consumes at leastone stream row; recursive term/formula calls follow already consumed tags. Prefix recursion is finite under canonical acyclic known heap. VMstep/heap cutoffs remain UNKNOWN, not grammar/theorem rejection.','read_only':'Only immutablecons construction/local assignment plus head/tail/tests; no mutation primitive exists. Carrierprefix isolation/physical rowheadmask must still be independently proved.'})
api=save('runtime-proof-byte-parser-complete-public-ABI-v1.json',{'schema':'C-runtime-proof-byte-parser-complete-public-ABI-v1','status':'COMPLETE_FIXED_SOURCE_UNRUN','Source':pin(S),'entry':'Static function0 main(raw), one proper rawcons triple(theory_JSON_node,target_JSON_formula_node,stream_rows). This is NOT the legacy full-request JSON wrapper ABI.','known_prefix':{'theory':'Canonical acyclic old JSONnode object exact4 functions/predicates/axioms/schemas; schemas must be empty JSONarray.','target':'Canonical acyclic JSONformula node.','profile':'Every raw objectkey and JSONstring value recursively nonempty printableASCII32..126; enforced insideprogram. Canonical unique objectkeys/acyclicity/valid nodeIDs remain carrierboundary preconditions.'},'rows':'Proper rawcons-list of row nodes; row=cons(byteAtom0..255,privateMarkerNode). Onlybytehead unknown; allotherlinks/markers/root/prefix known. Parserchecks pairlist/row/marker-node presence and byte-domain; private identities/freshness/alias scope are Lcarrier obligations.','grammar':grammar,'grammar_version':1,'wire_start':1,'LINE':16,'END':17,'nonemptyproof':True,'END_must_consume_whole_finite_stream':True,'padding_or_suffix':False,'name':'One or more32..126 bytes then0; no empty/control/DEL/high/Unicode-wire variant.','term_codes':{'32':'var(name)','33':'fun(name,termlist)'},'formula_codes':{'48':'bot','49':'eq(term,term)','50':'pred(name,termlist)','51':'not(formula)','52':'and(formula,formula)','53':'or(formula,formula)','54':'imp(formula,formula)','55':'all(name,formula)'},'termlist':'Repeated64+one term, then65; zeroitems permitted.','reference':'80 repeated naturalcount,81terminator; no prior-line check in parser.','rule_order':{'0':['axiom','name','formula'],'1':['tautology','formula'],'2':['refl','formula'],'3':['instantiate','universal','term','formula'],'4':['distribute','variable','antecedent','consequent','formula'],'5':['eq_subst','variable','template','left','right','formula'],'6':['mp','antecedent','implication','formula'],'7':['generalize','source','variable','formula']},'constructed_request':'Old JSONobject0 exactly protocol,theory,blocks,proof,target; protocolJSONstringgcts-fol-1, blocksemptyJSONarray, proofentire runtimeparsedarray, theory/target unchanged knownnodes. No given-schema privilege or unknown keys.','result':'Main returns atomBool1 iff grammar/profile complete and inherited semantic checker accepts;0 otherwise on normal completion. Internalcarry success tested only is_pair, never truthiness. VMlimit/heap-resource outcomes externalUNKNOWN; no false logical/nonexistence claim from cutoffs.','internal_helpers':{n:returns[n] for n in returns},'theory_projection_for_B':'Treeprefix exact4→independentBchecker exact3 by dropping only requiredempty schemas; samefunctions/predicates/closedaxioms/target and decodedproof.','semantic_verdict_relation':'No equivalence of verdictsets claimed. Preservedtree uses structuralsame/deterministicfresh0; Balpha-aware checker may accept additional alpha variants. Every actual treeACCEPTED decoded certificate must separatelyBVERIFY under adequate separatelydeclaredbudgets.','physical_scope':'RootMIN8_LSB DATA-word lowering is required for eight free rowheadbits; oldminimalword lowering is NOT this physicalbridge. Nil/nodeIDs retain>=9bits; CALLRETURNaddress_width stays unchanged. No physicalnormalizer/semanticopcode added to thisprogram. TapeMachine5/literalWangpalette/unknown-inputmask/scheduler/search/qualification are separatefuture gates.','fixedness':'One program independentoftheory,target,proof,capacity. Only external boundary data vary. No theorem-specific Source/tiletypes, hostknownproofAST or syntactic-skeleton input, builtinsemantic primitive or nativeFFI.','legacy_wrapper_warning':'Do not use tree_kernel.check(payload) to feed this Source: that wrapper encodes a whole supplied proof request. A new reviewed rawtriple/carrier caller is required.','references':[strategy,VM,master,preserve,static,manual],'execution':{'Source_compiler_constructor_VM_codec_parser_semantic_calls':0,'factory_proof_models_tests_CLI':0,'nativecodeobject_execution':0,'program_declaration':None},'remaining':['Independent B wholeSource/preservation/compiler-compatibility peer and Rootadoption','L genericMIN8lowering/carrier/alias/bitmask Source and independent peers','New complete closedqualification/caller/one-use authority before any subject call','Later actual unknown-proof search and literalWangacceptance correspondence; no new result claimed here']})
handoff=save('runtime-proof-byte-parser-complete-inert-Source-handoff-v1.json',{'schema':'C-runtime-proof-byte-parser-complete-inert-Source-handoff-v1','status':'COMPLETE_SOURCE_ONLY_UNRUN','Source':pin(S),'public_ABI':api,'complete_manual':manual,'complete_static':static,'complete_old_Source_preservation':preserve,'prefrozen_strategy':strategy,'grammar':grammar,'old_source':pin(OLD),'VMCompiler_Source':VM,'coverage':{'currentfunctions':92,'newprefixfunctions':len(new_t.body),'oldfunctions':64,'old_nonmain_exact':63,'onlyoldedit':'mainrename','scopes':93,'primitivekinds':6,'BoolconditionSites':len(conditions),'conservative_reachable':len(reachable),'Source_lines':len(lines),'unsupported_or_unresolved_calls':0,'subjectcalls':0},'no_grammar_change':True,'semantic_and_physical_limits':'One-way treeaccepted→independentBverify requirement, not allalpha verdict equality. Abstractrawbytes only; physicalMIN8carrier/lowering/tile bridge not established by parser. No VMdeclaration or result produced.','terminal_state':'IDLE'})
print(json.dumps({'Source':pin(S),'ABI':api,'manual':manual,'static':static,'preservation':preserve,'handoff':handoff,'reachable':len(reachable),'Boolconditions':len(conditions)},sort_keys=True))
