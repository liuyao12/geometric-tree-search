"""Independent static byte/AST delta joins. Does not execute subject code."""
import ast,hashlib,json,pathlib,re
D=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def apply(raw,patch):
 src=raw.splitlines(keepends=True);lines=patch.splitlines(keepends=True);out=[];cursor=0;i=2
 while i<len(lines):
  match=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@(?:[^\n]*)\n?',lines[i]);assert match
  start=int(match[1])-1;assert start>=cursor;out.extend(src[cursor:start]);cursor=start;i+=1
  while i<len(lines) and not lines[i].startswith('@@ '):
   line=lines[i];prefix=line[0];payload=line[1:]
   if prefix in (' ','-'):assert src[cursor]==payload;cursor+=1
   if prefix in (' ','+'):out.append(payload)
   assert prefix in (' ','-','+');i+=1
 out.extend(src[cursor:]);return ''.join(out)
def top(s):
 a=ast.parse(s);lines=s.splitlines(keepends=True)
 return a,{n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
rows=[]
for role in ('worker','observer'):
 p1=D/('unknown_stream_qualification_'+role+'_v1.py');p2=D/('unknown_stream_qualification_'+role+'_v2.py')
 a=p1.read_text();b=p2.read_text();forward=D/('qualification-'+role+'-full-forward-v2.patch');inverse=D/('qualification-'+role+'-full-inverse-v2.patch')
 assert apply(a,forward.read_text())==b and apply(b,inverse.read_text())==a
 ta,defs1=top(a);tb,defs2=top(b)
 unchanged=sorted(k for k in defs1 if defs1[k]==defs2[k]);changed=sorted(k for k in defs1 if defs1[k]!=defs2[k]);added=sorted(set(defs2)-set(defs1))
 if role=='worker':assert changed==['Run','semantic_run'] and added==['BoundedStoredWriter'] and len(unchanged)==34
 else:assert changed==[] and added==[] and len(unchanged)==22
 def assignments(t):return {n.targets[0].id:ast.dump(n.value,include_attributes=False) for n in t.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
 ca=assignments(ta);cb=assignments(tb);changed_globals=[k for k in ca if ca[k]!=cb[k]];assert set(changed_globals)=={'VERSION','SOURCE_PATHS'}
 # Exact old positioned AST is recovered, not merely location-stripped equality.
 reverse=apply(b,inverse.read_text());assert ast.dump(ast.parse(reverse),include_attributes=True)==ast.dump(ta,include_attributes=True)
 rows.append({'role':role,'predecessor':pin(p1),'current':pin(p2),'forward':pin(forward),'inverse':pin(inverse),'whole_raw_forward_and_inverse':True,'whole_positioned_AST_inverse':True,'raw_unchanged_helpers':unchanged,'changed_helpers':changed,'added_helpers':added,'changed_globals':changed_globals})
# Source-level checks of actual new write gate order and semantic-boundary order.
s=(D/'unknown_stream_qualification_worker_v2.py').read_text();a=ast.parse(s);t={n.name:n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
writer=t['BoundedStoredWriter'];write=next(n for n in writer.body if isinstance(n,ast.FunctionDef) and n.name=='write')
call_lines=[n.lineno for n in ast.walk(write) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='write'];require_lines=[n.lineno for n in ast.walk(write) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='require'];assert len(call_lines)==1 and len([x for x in require_lines if x<call_lines[0]])==3
run=t['Run'];save=next(n for n in run.body if isinstance(n,ast.FunctionDef) and n.name=='save')
# No direct base.write path is reachable from save: only BoundedStoredWriter owns it.
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='base' and n.func.attr=='write' for n in ast.walk(save))
assert "fileobj=bounded" in ast.get_source_segment(s,save) and "else bounded" in ast.get_source_segment(s,save)
sem=ast.get_source_segment(s,t['semantic_run']);assert sem.index("dec['status']=='COMPLETE'")<sem.index("c=run.call('carrier.build'") and sem.index("equal(dec['proof'],f['proof']")<sem.index("c=run.call('carrier.build'")
# Analytic scientific recipe/call constants identical in both complete Source ASTs.
old=ast.parse((D/'unknown_stream_qualification_worker_v1.py').read_text());oldmap={n.name:ast.dump(n,include_attributes=False) for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for name in ('grammar_fixtures','semantic_fixtures','grammar_run','control_run','physical_run','full_C1_construction','diagnostic_source','check_call_census'):assert ast.dump(t[name],include_attributes=False)==oldmap[name]
value={'schema':'C-Q-integration-Source2-complete-correction-inverse-audit-v1','status':'STATIC_PASS_ALL_SUBJECTS_UNRUN','findings_closed':['R1 pre-count/existing aggregate/next body+reserved bytes before xb and every actual stored write checked before forwarding incl gzip header/trailer','R2 all12 semantic byte-decodes must be COMPLETE and full exact authored NativeAST equality before native/B semantics'],'proofs':rows,'bounded_writer_order':{'three_exact_type/body/aggregate_guards_before_only_base_write':True,'save_has_no_base_write_bypass':True,'gzip_and_plain_both_target_bounded_writer':True,'gzip_header_and_close_trailer_use_same_target':True,'prior_owned_files_including_CONSUMED_stat_censused':True,'next_count_reserve':9,'whole_byte_reserve':2097152,'new_file_nonempty_minimum_prechecked':1,'raw_extent_and_full_stored_and_decompressed_readbacks_retained':True},'scientific_preservation':{'normal_grammar':18,'malformed_grammar':16,'semantic':12,'wire_resource':38,'all_byte_choices':256,'physical_diagnostic':1,'physical_negatives':6,'C1_attempts':1,'top_level_controls':348,'direct_calls':1643,'conditional_C1_calls':6,'no_added_solves_or_functions_called':True,'all_scientific_caps_unchanged':True},'v1_disposition':'PRESERVED_UNRUN_CHANGES_REQUIRED; no v1 execution/authority/prefix admission','scope':'Static raw/AST/patch/flow audit only; no subject constructors/factories/compiler/VM/codec/tests/CLI calls. Same signatures/schemas/cohort; new operational Source addresses/VERSIONv2 distinct from preserved wire ABIv1.'}
p=D/'qualification-Source2-complete-correction-and-inverse-audit-v1.json'
with p.open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(pin(p)))
