"""INERT authored encoding/component qualification. No unknown-proof search.
All factories and subject loads occur only after a separately reviewed fresh once.
"""
import argparse,gzip,hashlib,itertools,json,os,pathlib,re,resource,stat,sys,time,traceback,types

VERSION = 'GCTS-RAW-PROOF-INTEGRATION-WORKER-v1'
ROOT = pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1')
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
LIMITS = {'worker_seconds': 1200, 'observer_seconds': 1260, 'cleanup_seconds': 5, 'log_bytes': 1048576, 'body_bytes': 268435456, 'model_raw_bytes': 536870912, 'total_output_bytes': 805306368, 'max_output_files': 128, 'child_rss_bytes': 2147483648, 'native_steps': 20000000, 'observation_steps': 10000000, 'selected_steps': 10000000, 'physical_steps': 100000000}
SOURCE_PATHS = {'worker': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/unknown_stream_qualification_worker_v1.py', 'observer': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/unknown_stream_qualification_observer_v1.py', 'tree_machine': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/reused-sources/tree_machine.py', 'codec': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-B/independent_proof_byte_stream_v1.py', 'fol_checker': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent_fol_checker_v1.py', 'carrier': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L/proof_byte_carrier_v2.py', 'lowering': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L/tape_tree_machine_min8_budgeted_v2.py', 'heap_decoder': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L/ascii_tree_heap_decoder_v1.py', 'real_parser': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/proof_byte_fol_checker_v1.tree', 'grammar_observer': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/proof_byte_grammar_observer_v1.tree'}
COMPONENT_PINS = {'tree_machine': (13290, '8bede1b069975ba5b911f8d27d64e550b75cf81b779aae38ad6c0bf8371d2257'), 'codec': (18130, '92d7a4ce02b9d4f02b24c6f27498f59c8be07c6ec81db6963ac9df8e1120ee8c'), 'fol_checker': (21560, '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'), 'carrier': (23442, '42281d704e3d810f89b2d67ff4f373e8e68e6828323177249fbbaca1443e7b1b'), 'lowering': (23086, 'b2ef14f4512b314bfba8a1c0790acd039e19eb3cf37f1bbb51e157c398abeb96'), 'heap_decoder': (11691, 'd8704a3396759edcf0e85e086bd438428c855ca5a93c1735b39ced28497c693b'), 'real_parser': (29429, '1e62e4052349d3ff0e6a7746b111acd426e6ffede92e264c23a6be31016af5a5'), 'grammar_observer': (28854, '6ea6f3bf55519eb4f10fd9325cf186125effa1c8e7b1586f3a8e8f23b1f48c67')}
METADATA_PINS = {'grammar': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/root/common-design-and-byte-grammar-v1.json', 'bytes': 5481, 'sha256': '18393dd620c9c890baf43dad78bf454050c6a107f99f0ad70729784df6940e2f'}, 'codec': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-B/independent-proof-byte-stream-complete-effective-public-ABI-v3.json', 'bytes': 9483, 'sha256': '53797d2e675285fd40795254310386ea512033aeb4789c1a9427847ef0616c0b'}, 'carrier': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L/raw-proof-byte-carrier-MIN8-complete-public-ABI-v2.json', 'bytes': 7245, 'sha256': 'e356f04345adefcdeda1f74540bb8e829d62de8685b2f2f20636c0c31ab4a0af'}, 'heap_decoder': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L/ascii-tree-heap-decoder-complete-public-ABI-v1.json', 'bytes': 4745, 'sha256': '2f395d6bc67ad7a6c9e10d28a803ef4f11bd62d370f223370c061859b2b242f8'}, 'real_parser': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/runtime-proof-byte-parser-complete-public-ABI-v1.json', 'bytes': 8654, 'sha256': '4e9bc18f62c1dfa2a445d5e31dc0dabacf45c03493aed11020695d87565615a4'}, 'grammar_observer': {'path': '/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-C/grammar-observer-sister-public-ABI-v1.json', 'bytes': 3705, 'sha256': '23464e062f371514a6a3323cf741dfedf7b36c5873f626397f9c6c235b3d3b43'}, 'fol_checker': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-fol-checker-complete-effective-public-ABI-v2.json', 'bytes': 11910, 'sha256': '3a5efc7c5702e42800d9b58c5befa7fcf3e517cbc05f3ca00ae6dc2258730e72'}}
COHORT = 'AUTHORED-RAW-BYTE-INTEGRATION-G18-M16-S12-ALL256-OP13-v1'
CONSUMED_MEANING = 'exclusive spent marker before the sole child launch; failures remain spent'

class QualificationFailure(Exception):
    pass


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, label):
    if not condition:
        raise QualificationFailure(label)


def exact_fields(value, fields, label):
    require(type(value) is dict and all(type(k) is str for k in value) and set(value) == set(fields), label)


def safe_file(value):
    require(type(value) is str and pathlib.Path(value).is_absolute(), 'absolute path')
    p = pathlib.Path(value)
    require(str(p) == value and '..' not in p.parts, 'canonical path spelling')
    for q in (p,) + tuple(p.parents):
        require(not q.is_symlink(), 'symlink path')
    info = p.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'regular single-link file')
    return p


def read_ref(value, maximum=None):
    exact_fields(value, ('path', 'bytes', 'sha256'), 'rawref fields')
    require(type(value['bytes']) is int and value['bytes'] >= 0, 'rawref byte type')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'rawref SHA')
    if maximum is not None:
        require(value['bytes'] <= maximum, 'rawref cap')
    p = safe_file(value['path'])
    require(p.stat().st_size == value['bytes'], 'rawref stat size')
    raw = p.read_bytes()
    require(len(raw) == value['bytes'] and sha(raw) == value['sha256'], 'rawref full body identity')
    return raw


def rawref(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def raw_association(value, expected, label):
    exact_fields(value, ('path','bytes','sha256'), label+' rawref fields')
    require(type(value['path']) is str and type(value['bytes']) is int and value['bytes'] >= 0, label+' path/byte types')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None, label+' digest type')
    require(encode(value) == encode(expected), label+' type-exact canonical association')
    return read_ref(value,1048576)


def parse_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(QualificationFailure('nonfinite JSON')))


def plan_read(path):
    p = safe_file(path)
    require(p.parent == ROOT / 'root' and p.suffix == '.json' and not p.name.startswith('.'), 'plan location')
    raw = p.read_bytes()
    require(len(raw) <= 1048576, 'plan cap')
    plan = parse_json(raw)
    exact_fields(plan, ('schema','case_id','actual_dir','python','sources','metadata','limits','cohort'), 'plan fields')
    require(plan['schema'] == 'GCTS-raw-proof-integration-once-plan-v1', 'plan schema')
    require(type(plan['case_id']) is str and re.fullmatch('[a-z0-9][a-z0-9_-]{0,63}', plan['case_id']) is not None, 'case ID')
    require(plan['actual_dir'] == str(ROOT / 'actual' / plan['case_id']), 'actual directory')
    require(encode(plan['python']) == encode(PYTHON), 'type-exact D90 runtime')
    require(encode(plan['limits']) == encode(LIMITS) and plan['cohort'] == COHORT, 'fixed limits/cohort')
    exact_fields(plan['sources'], SOURCE_PATHS, 'source roles')
    for role, expected in SOURCE_PATHS.items():
        require(type(plan['sources'][role]) is dict and plan['sources'][role].get('path') == expected, 'source role path')
        if role in COMPONENT_PINS:
            size, digest = COMPONENT_PINS[role]
            require(plan['sources'][role].get('bytes') == size and plan['sources'][role].get('sha256') == digest, 'frozen component identity')
    exact_fields(plan['metadata'], METADATA_PINS, 'metadata roles')
    require(encode(plan['metadata']) == encode(METADATA_PINS), 'fixed effective public ABIs')
    return plan, rawref(p, raw)


def guard_read(plan, plan_ref, extra_refs=()):
    retained = {role: read_ref(ref, 1048576) for role, ref in plan['sources'].items()}
    for ref in plan['metadata'].values():
        read_ref(ref, 1048576)
    read_ref(plan['python'], 33554432)
    read_ref(plan_ref, 1048576)
    for ref in extra_refs:
        read_ref(ref,1048576)
    return retained


def consumed_read(plan, plan_ref, directory):
    path = safe_file(str(directory/'CONSUMED.json'))
    size = path.stat().st_size
    require(size <= 1048576, 'bounded once marker metadata')
    raw = path.read_bytes()
    require(len(raw) == size and len(raw) <= 1048576, 'whole bounded once marker')
    consumed_ref = rawref(path,raw)
    consumed = parse_json(raw)
    exact_fields(consumed, ('schema','uses','case_id','plan','authority','observer','meaning'), 'consumed exact seven fields')
    raw_association(consumed['plan'],plan_ref,'consumed current plan')
    raw_association(consumed['observer'],plan['sources']['observer'],'consumed current observer')
    authority_ref = consumed['authority']
    exact_fields(authority_ref, ('path','bytes','sha256'), 'current authority rawref fields')
    require(type(authority_ref['path']) is str, 'authority path type')
    authority_path = pathlib.Path(authority_ref['path'])
    require(authority_path.parent == ROOT/'root' and authority_path.suffix == '.json' and not authority_path.name.startswith('.'), 'current authority Root metadata location')
    authority_raw = read_ref(authority_ref,1048576)
    authority = parse_json(authority_raw)
    exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'current authority exact six fields')
    raw_association(authority['plan'],plan_ref,'authority current plan')
    raw_association(authority['observer'],plan['sources']['observer'],'authority current observer')
    expected_authority = {'schema':'Root-raw-proof-integration-once-authority-v1','authorized':True,'uses':1,
                          'case_id':plan['case_id'],'plan':plan_ref,'observer':plan['sources']['observer']}
    require(encode(authority) == encode(expected_authority), 'whole current authority flags and typed fields')
    expected_consumed = {'schema':'Root-raw-proof-integration-once-consumed-v1','uses':1,'case_id':plan['case_id'],
                         'plan':plan_ref,'authority':authority_ref,'observer':plan['sources']['observer'],'meaning':CONSUMED_MEANING}
    require(encode(consumed) == encode(expected_consumed), 'whole current consumed meaning and typed fields')
    return (authority_ref,consumed_ref)


EXPECTED_CALL_BASE = {'tree.compile': 3, 'tree.declaration': 3, 'tree.Heap': 49, 'codec.encode': 31, 'codec.decode': 52, 'carrier.build': 52, 'carrier.verify': 307, 'native.run': 47, 'heap.decode': 40, 'fol.check': 12, 'tree.encode_json': 7, 'lower.construct': 2, 'lower.declaration': 1, 'carrier.mask': 3, 'carrier.materialize_physical': 256, 'carrier.materialize_binary': 256, 'carrier.decode_physical': 257, 'carrier.decode_binary': 257, 'lower.physical': 2, 'native.diagnostic': 1, 'lower.initial': 1, 'lower.virtual': 1, 'lower.physical_input': 2, 'C1.lower.construct': 1}
EXPECTED_CALL_C1_SELECTED = {'C1.lower.declaration': 1, 'C1.lower.receipt': 1, 'C1.carrier.build': 1, 'C1.carrier.mask': 1, 'C1.lower.initial': 1, 'C1.lower.physical': 1}

class Run:
    def __init__(self, plan, plan_ref, started):
        self.plan,self.plan_ref,self.started=plan,plan_ref,started
        self.directory=pathlib.Path(plan['actual_dir'])
        self.callbacks=0;self.current='PREFLIGHT';self.files=[];self.calls={}
    def budget(self):
        self.callbacks+=1
        if self.callbacks%1024==1:
            self.gate()
    def gate(self):
        require(time.monotonic()-self.started<=LIMITS['worker_seconds'],'worker wall ceiling')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<=LIMITS['child_rss_bytes'],'worker cooperative Darwin SELF highwater')
    def call(self,name,fn,*args,**kwargs):
        self.current=name;self.calls[name]=self.calls.get(name,0)+1;self.gate()
        answer=fn(*args,**kwargs);self.gate();return answer
    def save(self,name,value,gz=False):
        self.current='SAVE '+name;self.gate()
        path=self.directory/name
        require(re.fullmatch('[A-Za-z0-9][A-Za-z0-9.-]*',name) is not None and not path.exists(),'new safe output')
        rawhash=hashlib.sha256();rawsize=0
        encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
        with path.open('xb') as base:
            destination=gzip.GzipFile(filename='',mode='wb',fileobj=base,mtime=0) if gz else base
            try:
                for part in itertools.chain(encoder.iterencode(value),['\n']):
                    self.budget();raw=part.encode('ascii');rawsize+=len(raw)
                    require(rawsize<=LIMITS['model_raw_bytes'] if gz else rawsize<=LIMITS['body_bytes'],'complete JSON raw extent cap')
                    rawhash.update(raw);destination.write(raw)
                    require(base.tell()<=LIMITS['body_bytes'],'stored body extent cap')
            finally:
                if gz:destination.close()
            base.flush();os.fsync(base.fileno())
        storedhash=hashlib.sha256();storedsize=0
        with path.open('rb') as handle:
            while True:
                block=handle.read(1048576)
                if not block:break
                self.budget();storedhash.update(block);storedsize+=len(block)
        require(storedsize<=LIMITS['body_bytes'],'stored readback cap')
        check=hashlib.sha256();extent=0
        opener=gzip.open if gz else open
        with opener(path,'rb') as handle:
            while True:
                block=handle.read(1048576)
                if not block:break
                self.budget();check.update(block);extent+=len(block)
                require(extent<=LIMITS['model_raw_bytes'] if gz else extent<=LIMITS['body_bytes'],'readback raw extent')
        require(extent==rawsize and check.digest()==rawhash.digest(),'full lossless serialization readback')
        ref={'path':str(path),'bytes':storedsize,'sha256':storedhash.hexdigest()}
        record={'stored':ref,'encoding':'gzip-JSON-ASCII-LF' if gz else 'JSON-ASCII-LF','raw_bytes':rawsize,'raw_sha256':rawhash.hexdigest()}
        self.files.append(record)
        require(len(self.files)+10<=LIMITS['max_output_files'] and sum(x['stored']['bytes'] for x in self.files)+2*LIMITS['log_bytes']<=LIMITS['total_output_bytes'],'whole named output count/bytes reserve')
        self.gate();return record


def clone(value):
    if type(value) is dict:return {k:clone(v) for k,v in value.items()}
    if type(value) in (list,tuple):return [clone(v) for v in value]
    require(value is None or type(value) in (str,int,bool,float),'native primitive clone')
    return value


def equal(a,b,label):
    require(encode(a)==encode(b),label)


def load_libraries(retained):
    require('tree_machine' not in sys.modules,'no preexisting tree_machine alias/cache')
    answer={}
    for role in ('tree_machine','codec','fol_checker','carrier','lowering','heap_decoder'):
        name='tree_machine' if role=='tree_machine' else '_Q_'+role
        require(name not in sys.modules,'no prior qualified module')
        module=types.ModuleType(name);module.__file__=SOURCE_PATHS[role]
        if role=='tree_machine':sys.modules[name]=module
        exec(compile(retained[role],SOURCE_PATHS[role],'exec',dont_inherit=True),module.__dict__,module.__dict__)
        answer[role]=module
    require(answer['lowering'].validate is answer['tree_machine'].validate,'retained tree_machine only import binding')
    return answer


def codec_limits(**changes):
    value={'max_operations':1000000,'max_depth':128,'max_lines':64,'max_items':1024,'max_name_bytes':128,'max_reference':64}
    value.update(changes);return value


def heap_limits(**changes):
    value={'max_operations':5000000,'max_heap_nodes':200000,'max_depth':256,'max_expanded_output_nodes':1000000,'max_string_bytes':1000000,'max_natural':100000}
    value.update(changes);return value


def carrier_limits(**changes):
    value={'max_operations':10000000,'max_nodes':200000,'max_stream_bytes':4096,'max_selected_cells':2000000,'max_physical_cells':2001000}
    value.update(changes);return value


def lower_limits(**changes):
    value={'max_operations':20000000,'max_states':200000,'max_transition_choices':1500000}
    value.update(changes);return value


def grammar_fixtures():
    x=['var','x'];y=['var','y'];c=['fun','c',[]];fx=['fun','f',[x]]
    p=['pred','P',[x]];q=['pred','Q',[]];e=['eq',x,x];a=['all','x',e]
    values=[
      [{'rule':'axiom','name':'ax','formula':a}],
      [{'rule':'tautology','formula':['imp',p,p]}],
      [{'rule':'refl','formula':e}],
      [{'rule':'instantiate','universal':a,'term':c,'formula':['imp',a,['eq',c,c]]}],
      [{'rule':'distribute','variable':'x','antecedent':q,'consequent':p,'formula':['imp',['all','x',['imp',q,p]],['imp',q,['all','x',p]]]}],
      [{'rule':'eq_subst','variable':'x','template':p,'left':x,'right':c,'formula':['imp',['eq',x,c],['imp',p,['pred','P',[c]]]]}],
      [{'rule':'mp','antecedent':0,'implication':3,'formula':q}],
      [{'rule':'generalize','source':0,'variable':'x','formula':a}],
      [{'rule':'tautology','formula':['bot']}],
      [{'rule':'tautology','formula':['not',p]}],
      [{'rule':'tautology','formula':['and',p,q]}],
      [{'rule':'tautology','formula':['or',p,q]}],
      [{'rule':'tautology','formula':['all','x',['all','x',['pred','P',[fx]]]]}],
      [{'rule':'refl','formula':['eq',['fun','g',[c,fx,y]],['fun','g',[c,fx,y]]]}],
      [{'rule':'axiom','name':' !~','formula':q}],
      [{'rule':'tautology','formula':['pred','empty',[]]}],
      [{'rule':'refl','formula':e},{'rule':'generalize','source':0,'variable':'x','formula':a}],
      [{'rule':'mp','antecedent':64,'implication':64,'formula':q}]
    ]
    return [{'id':'G%02d'%(i+1),'proof':v} for i,v in enumerate(values)]


def semantic_fixtures():
    x=['var','x'];y=['var','y'];c=['fun','c',[]];e=['eq',x,x];a=['all','x',e]
    p=['pred','P',[x]];q=['pred','Q',[]]
    theory={'functions':{'c':0},'predicates':{'P':1,'Q':0},'axioms':{'ax':a},'schemas':[]}
    proofs=[
      ('refl',[{'rule':'refl','formula':e}],e,True,'VERIFIED'),
      ('tautology',[{'rule':'tautology','formula':['imp',q,q]}],['imp',q,q],True,'VERIFIED'),
      ('axiom',[{'rule':'axiom','name':'ax','formula':a}],a,True,'VERIFIED'),
      ('instantiate',[{'rule':'instantiate','universal':a,'term':c,'formula':['imp',a,['eq',c,c]]}],['imp',a,['eq',c,c]],True,'VERIFIED'),
      ('distribute',[{'rule':'distribute','variable':'x','antecedent':q,'consequent':p,'formula':['imp',['all','x',['imp',q,p]],['imp',q,['all','x',p]]]}],['imp',['all','x',['imp',q,p]],['imp',q,['all','x',p]]],True,'VERIFIED'),
      ('eq-subst',[{'rule':'eq_subst','variable':'x','template':p,'left':x,'right':c,'formula':['imp',['eq',x,c],['imp',p,['pred','P',[c]]]]}],['imp',['eq',x,c],['imp',p,['pred','P',[c]]]],True,'VERIFIED'),
      ('generalize',[{'rule':'refl','formula':e},{'rule':'generalize','source':0,'variable':'x','formula':a}],a,True,'VERIFIED'),
      ('mp',[{'rule':'axiom','name':'ax','formula':a},{'rule':'tautology','formula':['imp',a,a]},{'rule':'mp','antecedent':0,'implication':1,'formula':a}],a,True,'VERIFIED'),
      ('false-tautology',[{'rule':'tautology','formula':q}],q,False,'REJECTED'),
      ('future-reference',[{'rule':'mp','antecedent':0,'implication':0,'formula':q}],q,False,'REJECTED'),
      ('target-mismatch',[{'rule':'refl','formula':e}],['eq',y,y],False,'REJECTED'),
      ('alpha-scope',[{'rule':'axiom','name':'ax','formula':['all','y',['eq',y,y]]}],['all','y',['eq',y,y]],False,'VERIFIED')]
    return [{'id':n,'theory':clone(theory),'proof':p0,'target':t,'tree_accept':ok,'independent_status':bs} for n,p0,t,ok,bs in proofs]


def diagnostic_source():
    return '''def main(input):
    a = 0
    b = 1
    c = 127
    d = 128
    e = 254
    f = 255
    n = None
    z = cons(a, n)
    copied = z
    if not is_pair(copied):
        return False
    if not atom_eq(head(copied), a):
        return False
    if not atom_eq(tail(copied), n):
        return False
    if not atom_eq(byte_succ(c), d):
        return False
    if not atom_eq(byte_succ(e), f):
        return False
    if is_pair(a):
        return False
    if atom_eq(z, z):
        return False
    result = outer(b)
    if not result or not atom_eq(c, 127) or not atom_eq(e, 254):
        return False
    while not atom_eq(a, b):
        a = byte_succ(a)
    return atom_eq(a, b)
def outer(x):
    keep = 128
    result = inner(x)
    return result and atom_eq(keep, 128)
def inner(x):
    return not not x
'''


def fill_carrier(carrier,raw):
    value=carrier['value'];nodes=clone(value['nodes'])
    require(len(raw)==value['byte_count'],'full chosen byte extent')
    for row,b in zip(value['byte_rows'],raw,strict=True):nodes[row['node_index']][0]=b
    return nodes


def native_run(run,libs,program,carrier,raw,role,limit):
    nodes=fill_carrier(carrier,raw)
    check=run.call('carrier.verify',libs['carrier'].verify_carrier_choice,carrier,nodes,carrier['value']['input_node'],budget=run.budget)
    equal(check['byte_values'],list(raw),'carrier recovered all bytes')
    heap=run.call('tree.Heap',libs['tree_machine'].Heap,nodes,limit=200000)
    root=carrier['value']['stream_node'] if role=='stream_node' else carrier['value']['input_node']
    answer=run.call('native.run',libs['tree_machine'].run,program,heap,root,limit=limit,keep=0)
    return {'input_role':role,'input_node':root,'carrier':carrier,'initial_nodes':nodes,'choice_check':check,'vm':answer,'final_nodes':clone(heap.nodes)}


def grammar_run(run,libs,program):
    records=[];base_theory={'functions':{},'predicates':{},'axioms':{},'schemas':[]};target=['bot']
    streams=[]
    for f in grammar_fixtures():
        before=encode(f['proof']);enc=run.call('codec.encode',libs['codec'].encode,f['proof'],codec_limits())
        require(enc['status']=='COMPLETE' and encode(f['proof'])==before,'normal grammar encode/no mutation')
        raw=bytes.fromhex(enc['stream_hex']);dec=run.call('codec.decode',libs['codec'].decode,raw,codec_limits())
        equal(dec['proof'],f['proof'],'independent byte native inverse')
        streams.append(raw)
        c=run.call('carrier.build',libs['carrier'].build_carrier,program,base_theory,target,len(raw),carrier_limits(),budget=run.budget)
        native=native_run(run,libs,program,c,raw,'stream_node',LIMITS['observation_steps'])
        require(native['vm'].get('value',0)>256 and native['vm']['status']=='rejected','normal nonbool data return only')
        parsed=run.call('heap.decode',libs['heap_decoder'].decode_ascii_json,native['final_nodes'],native['vm']['value'],heap_limits(),budget=run.budget)
        require(parsed['status']=='DECODED','complete observed data decode');equal(parsed['value'],dec['proof'],'whole observed NativeAST exactly equals independent decoder')
        records.append({'id':f['id'],'authored_proof':f['proof'],'encoder':enc,'decoder':dec,'native':native,'observed_JSON':parsed})
    seed=streams[2]
    bad=[('empty',b''),('version',bytes([2])+seed[1:]),('no-proof',bytes([1,17])),('line-marker',bytes([1,18,2,49,32,120,0,32,120,0,17])),('rule',bytes([1,16,8,17])),('term-tag',seed.replace(bytes([32]),bytes([31]),1)),('formula-tag',seed[:3]+bytes([47])+seed[4:]),('empty-name',seed.replace(b'x\x00',b'\x00',1)),('control-name',seed.replace(b'x\x00',b'\x1f\x00',1)),('high-name',seed.replace(b'x\x00',b'\x80\x00',1)),('trailing',seed+b'\x00'),('missing-END',seed[:-1]),('truncated-name',seed[:6]),('bad-ref',bytes([1,16,6,82,81,48,17])),('list-terminator',streams[15].replace(bytes([65]),bytes([66]),1)),('truncated-last',seed[:-2])]
    for ident,raw in bad:
        dec=run.call('codec.decode',libs['codec'].decode,raw,codec_limits());require(dec['status']=='REJECTED' and dec['proof'] is None,'malformed grammar B refusal')
        c=run.call('carrier.build',libs['carrier'].build_carrier,program,base_theory,target,len(raw),carrier_limits(),budget=run.budget)
        native=native_run(run,libs,program,c,raw,'stream_node',LIMITS['observation_steps'])
        require(native['vm'].get('value')==0 and native['vm']['status']=='rejected','runtime malformed grammar normal false, no data AST')
        records.append({'id':'M-'+ident,'stream_hex':raw.hex(),'decoder':dec,'native':native})
    return run.save('grammar-complete.json.gz',{'normal':18,'malformed':16,'records':records},True),streams


def semantic_run(run,libs,program):
    records=[]
    for f in semantic_fixtures():
        enc=run.call('codec.encode',libs['codec'].encode,f['proof'],codec_limits());require(enc['status']=='COMPLETE','semantic controls encode')
        raw=bytes.fromhex(enc['stream_hex']);dec=run.call('codec.decode',libs['codec'].decode,raw,codec_limits())
        c=run.call('carrier.build',libs['carrier'].build_carrier,program,f['theory'],f['target'],len(raw),carrier_limits(),budget=run.budget)
        native=native_run(run,libs,program,c,raw,'input_node',LIMITS['native_steps'])
        require('value' in native['vm'] and native['vm']['value']==int(f['tree_accept']),'normal real fixed-program semantic control')
        theory3={k:clone(f['theory'][k]) for k in ('functions','predicates','axioms')}
        checked=run.call('fol.check',libs['fol_checker'].check,theory3,dec['proof'],f['target'],{'max_operations':5000000,'max_depth':256,'max_proof_lines':64})
        require(checked['status']==f['independent_status'],'independent semantic control exact status')
        if native['vm']['value']==1:require(checked['status']=='VERIFIED','every actual TREE ACCEPTED independently verifies')
        records.append({'id':f['id'],'authored':f,'encoder':enc,'decoder':dec,'native':native,'independent':checked})
    return run.save('semantic-controls.json.gz',{'records':records,'one_way_only':True},True)


class ForeignSentinel(Exception):
    pass


def expect_exception(run,name,fn,kind,*args,**kwargs):
    try:run.call(name,fn,*args,**kwargs)
    except kind as error:
        require(type(error) is kind,'exact owned/declared exception class')
        return {'exception_type':type(error).__name__,'message':str(error)}
    raise QualificationFailure('expected narrowly typed exception '+name)


def control_run(run,libs,observer_program,streams):
    out=[];codec=libs['codec'];C=libs['carrier'];H=libs['heap_decoder'];TM=libs['tree_machine']
    cyclic=['not',None];cyclic[1]=cyclic
    proof=[{'rule':'tautology','formula':cyclic}]
    value=run.call('codec.encode',codec.encode,proof,codec_limits());require(value['status']=='REJECTED','native active cycle rejected')
    out.append({'id':'native-cycle','return':value,'input_descriptor':'list not references itself at child1; no finite JSON image'})
    budget_cases=[('operations',streams[0],{'max_operations':0}),('depth',streams[12],{'max_depth':1}),('lines',streams[16],{'max_lines':1}),('items',streams[13],{'max_items':0}),('name',streams[14],{'max_name_bytes':1}),('reference',streams[17],{'max_reference':0})]
    for name,raw,changes in budget_cases:
        answer=run.call('codec.decode',codec.decode,raw,codec_limits(**changes));require(answer['status']=='UNKNOWN_BUDGET' and answer['proof'] is None,'codec resource is UNKNOWN')
        out.append({'id':'codec-cap-'+name,'stream_hex':raw.hex(),'limits':codec_limits(**changes),'return':answer})
    c=run.call('carrier.build',C.build_carrier,observer_program,{'functions':{},'predicates':{},'axioms':{},'schemas':[]},['bot'],len(streams[2]),carrier_limits(),budget=run.budget)
    native=native_run(run,libs,observer_program,c,streams[2],'stream_node',0)
    require(native['vm']['status']=='unknown_step_budget' and 'value' not in native['vm'],'VM refusal not grammar/proof verdict')
    out.append({'id':'native-zero-step','native':native})
    good=fill_carrier(c,streams[2])
    mutations=[('known-prefix',0,0),('marker-tail',c['value']['byte_rows'][0]['node_index'],1),('stream-link',c['value']['stream_node']-257,1)]
    for name,index,field in mutations:
        bad=clone(good);old=bad[index][field];bad[index][field]=1 if old!=1 else 0
        error=expect_exception(run,'carrier.verify',C.verify_carrier_choice,C.CarrierError,c,bad,c['value']['input_node'],budget=run.budget)
        out.append({'id':'carrier-tamper-'+name,'nodes':bad,'return':error})
    error=expect_exception(run,'carrier.verify',C.verify_carrier_choice,C.CarrierError,c,good,c['value']['stream_node'],budget=run.budget)
    out.append({'id':'carrier-wrong-role-root','return':error})
    for name,changes in [('ops',{'max_operations':0}),('nodes',{'max_nodes':0}),('stream',{'max_stream_bytes':0})]:
        error=expect_exception(run,'carrier.build',C.build_carrier,C.CarrierBudgetExceeded,observer_program,{'functions':{},'predicates':{},'axioms':{},'schemas':[]},['bot'],1,carrier_limits(**changes),budget=run.budget)
        out.append({'id':'carrier-cap-'+name,'return':error})
    def foreign():raise ForeignSentinel('authored foreign budget sentinel')
    error=expect_exception(run,'carrier.build',C.build_carrier,ForeignSentinel,observer_program,{'functions':{},'predicates':{},'axioms':{},'schemas':[]},['bot'],1,carrier_limits(),budget=foreign)
    out.append({'id':'foreign-callback','return':error})
    heap=run.call('tree.Heap',TM.Heap,[]);alltags={'array':[],'object':{},'string':' ~','natural':3,'negative':-2,'boolean':True,'null':None}
    roots={name:run.call('tree.encode_json',TM.encode_json,heap,v) for name,v in alltags.items()}
    for name,v in alltags.items():
        answer=run.call('heap.decode',H.decode_ascii_json,clone(heap.nodes),roots[name],heap_limits(),budget=run.budget)
        require(answer['status']=='DECODED','all seven JSON tags');equal(answer['value'],v,'complete generic heap syntax inverse')
        out.append({'id':'heap-tag-'+name,'nodes':clone(heap.nodes),'root':roots[name],'return':answer})
    for name,changes in [('ops',{'max_operations':0}),('nodes',{'max_heap_nodes':0}),('depth',{'max_depth':0}),('expanded',{'max_expanded_output_nodes':0}),('string',{'max_string_bytes':0}),('natural',{'max_natural':0})]:
        root=roots['string'] if name=='string' else roots['natural']
        answer=run.call('heap.decode',H.decode_ascii_json,clone(heap.nodes),root,heap_limits(**changes),budget=run.budget)
        require(answer['status']=='UNKNOWN_BUDGET' and answer['value'] is None,'heap resource no partial data')
        out.append({'id':'heap-cap-'+name,'return':answer})
    for name,nodes,root in [('future',[[257,256]],257),('bool',[[True,256]],257),('duplicate',[[0,256],[0,256]],257),('bad-null',[[6,0]],257),('negative-zero',[[4,256]],257),('nonascii-string',[[127,256],[2,257]],258)]:
        answer=run.call('heap.decode',H.decode_ascii_json,nodes,root,heap_limits(),budget=run.budget)
        require(answer['status']=='REJECTED' and answer['value'] is None,'heap malformed whole data refusal')
        out.append({'id':'heap-bad-'+name,'nodes':nodes,'root':root,'return':answer})
    # Canonical repeated-child DAG expands twice, not a shared native mutable object.
    dag=[[1,256],[257,256],[257,258],[1,259]]
    answer=run.call('heap.decode',H.decode_ascii_json,dag,260,heap_limits(),budget=run.budget)
    require(answer['status']=='DECODED','canonical repeated-edge DAG syntax')
    equal(answer['value'],[[],[]],'whole repeated-edge JSON')
    require(answer['value'][0] is not answer['value'][1],'expanded mutable children detached')
    out.append({'id':'heap-repeated-DAG','nodes':dag,'root':260,'return':answer})
    answer=run.call('heap.decode',H.decode_ascii_json,dag,260,heap_limits(max_expanded_output_nodes=2),budget=run.budget)
    require(answer['status']=='UNKNOWN_BUDGET' and answer['value'] is None,'repeated-edge output cap, no prefix')
    out.append({'id':'heap-repeated-DAG-cap','return':answer})
    # Duplicate raw key ASCII x, values null/true; every cons pair itself unique/canonical.
    dup=[[120,256],[6,256],[5,1],[257,258],[257,259],[261,256],[260,262],[0,263]]
    answer=run.call('heap.decode',H.decode_ascii_json,dup,264,heap_limits(),budget=run.budget)
    require(answer['status']=='REJECTED' and answer['value'] is None,'duplicate decoded object key rejected')
    out.append({'id':'heap-duplicate-key','nodes':dup,'root':264,'return':answer})
    return run.save('wire-resource-controls.json.gz',{'records':out},True)


def literal_physical(d,tape,limit,run):
    tape=list(tape);head=0;q=d['start'];digest=hashlib.sha256();steps=0
    while steps<limit and q not in (d['accept'],d['reject'],d['space']):
        if steps%4096==0:run.budget()
        require(0<=head<len(tape),'literal finite physical head bound')
        default,overrides=d['rows'][q];symbol=tape[head]
        require(symbol in d['alphabet'],'literal physical alphabet')
        if symbol in overrides:out,write,move=overrides[symbol]
        elif default is not None:out,move=default;write=symbol
        else:q=d['reject'];break
        require(type(out) is int and type(move) is int and move in (-1,0,1) and write in d['alphabet'],'literal finite transition row')
        digest.update(encode([q,head,symbol,out,write,move]));tape[head]=write;head+=move;q=out;steps+=1
    status='accepted' if q==d['accept'] else 'rejected' if q==d['reject'] else 'unknown_space_budget' if q==d['space'] else 'unknown_step_budget'
    return {'status':status,'steps':steps,'state':q,'head':head,'tape':tape,'transition_sha256':digest.hexdigest(),'scope':'Only literal finite state/symbol/head/write/move table default/override interpretation; no VM/formula/heap callbacks.'}


def physical_run(run,libs,program):
    C=libs['carrier'];L=libs['lowering'];TM=libs['tree_machine']
    theory={'functions':{},'predicates':{},'axioms':{},'schemas':[]}
    lower=run.call('lower.construct',L.Lowering,program,lower_limits(),budget=run.budget)
    d=run.call('lower.declaration',lower.declaration)
    c=run.call('carrier.build',C.build_carrier,program,theory,['bot'],1,carrier_limits(),budget=run.budget)
    cap={'word_capacity':64,'heap_padding':512,'stack_capacity':2048}
    mask=run.call('carrier.mask',C.build_physical_mask,program,d,c,cap,carrier_limits(),budget=run.budget)
    run.save('physical-mask-and-carrier.json.gz',{'program':program,'selected':d,'carrier':c,'mask':mask},True)
    records=[]
    for byte in range(256):
        nodes=fill_carrier(c,bytes([byte]));heapcheck=run.call('carrier.verify',C.verify_carrier_choice,c,nodes,c['value']['input_node'],budget=run.budget)
        tape=run.call('carrier.materialize_physical',C.materialize_physical,mask,[byte],budget=run.budget)
        binary=run.call('carrier.materialize_binary',C.materialize_binary,mask,[byte],budget=run.budget)
        symbolcheck=run.call('carrier.decode_physical',C.decode_physical_choice,mask,tape,budget=run.budget)
        binarycheck=run.call('carrier.decode_binary',C.decode_binary_choice,mask,binary,budget=run.budget)
        equal(heapcheck['byte_values'],[byte],'all256 heap choices');equal(symbolcheck['byte_values'],[byte],'all256 symbol choices');equal(binarycheck['byte_values'],[byte],'all256 u32 choices')
        unknown={x['physical_cell'] for x in mask['value']['unknown_bits']}
        require(all(v==mask['value']['physical_template'][i] for i,v in enumerate(tape) if i not in unknown),'every fixed physical symbol unchanged')
        template=mask['value']['binary_input_template'];free={x['byte_offset']+k for x in mask['value']['binary_symbol_domains'] for k in range(4)}
        require(all(b==template[i] for i,b in enumerate(binary) if i not in free),'every fixed binary byte unchanged')
        records.append({'byte':byte,'heap_check':heapcheck,'physical_tape':tape,'binary_hex':binary.hex(),'symbol_check':symbolcheck,'binary_check':binarycheck})
    choices_ref=run.save('all-256-physical-choices.json.gz',{'records':records},True)
    pd=run.call('lower.physical',L.physical_declaration,d,lower_limits(max_operations=50000000,max_states=1000000,max_transition_choices=5000000),budget=run.budget)
    native_heap=run.call('tree.Heap',TM.Heap,program['nodes'])
    native=run.call('native.diagnostic',TM.run,program,native_heap,256,limit=100000,keep=100000)
    require(native.get('value')==1 and native['status']=='accepted','all opcode native diagnostic normal accept')
    initial=run.call('lower.initial',lower.initial,{'nodes':program['nodes'],'node':256},**cap)
    virtual=run.call('lower.virtual',L.virtual_run,d,initial,limit=LIMITS['selected_steps'],keep=0)
    physical_input=run.call('lower.physical_input',L.physical_input,initial)
    physical=literal_physical(pd,physical_input,LIMITS['physical_steps'],run)
    require(virtual['status']=='accepted' and physical['status']=='accepted','native/selected/literal physical full opcode outcome')
    parsed_heap=[]
    for record in virtual['words'][d['heap']].split(';'):
        if not record:continue
        identity,children=record.split(':');left,right=children.split(',')
        require(int(identity[::-1],2)==257+len(parsed_heap),'selected complete heap sequential IDs')
        parsed_heap.append([int(left[::-1],2),int(right[::-1],2)])
    equal(parsed_heap,clone(native_heap.nodes),'native/selected complete final heap equality')
    require(int(virtual['words'][d['work']][::-1],2)==native['value'],'native/selected returned data word equality')
    equal(physical['tape'],run.call('lower.physical_input',L.physical_input,{'words':virtual['words'],'heads':virtual['heads'],'capacities':initial['capacities']}),'complete physical final tape exactly selected final tape')
    ops={x[2] for x in native['trace']}
    require(ops=={'const','move','cons','head','tail','pair','atom','succ','not','branch','jump','call','return'},'all13 opcodes actually executed in retained native trace')
    require(native['peak_frames']>=2 and 257 in program['constants']+list(range(257,257+native['heap_nodes'])),'nested live-register/cons257 diagnostic')
    # Source-level complete opcode inventory is separately retained in program; native trace format retained unprojected.
    allops={ins[0] for fn in program['functions'] for ins in fn['code']}
    require(allops=={'const','move','cons','head','tail','pair','atom','succ','not','branch','jump','call','return'},'full declared opcode matrix')
    diagnostic_ref=run.save('all-opcode-physical-diagnostic.json.gz',{'program':program,'selected':d,'physical':pd,'initial':initial,'native':native,'native_final_nodes':clone(native_heap.nodes),'virtual':virtual,'literal':physical,'declared_opcodes':sorted(allops),'data_constants':[0,1,127,128,254,255,256,257]},True)
    bad_tape=clone(records[0]['physical_tape']);bad_tape[0]='B'
    bad_binary=bytearray.fromhex(records[0]['binary_hex']);bad_binary[0]^=1
    controls=[expect_exception(run,'carrier.decode_physical',C.decode_physical_choice,C.CarrierError,mask,bad_tape,budget=run.budget),expect_exception(run,'carrier.decode_binary',C.decode_binary_choice,C.CarrierError,mask,bytes(bad_binary),budget=run.budget)]
    for changes in ({'max_selected_cells':0},{'max_physical_cells':0}):controls.append(expect_exception(run,'carrier.mask',C.build_physical_mask,C.CarrierBudgetExceeded,program,d,c,cap,carrier_limits(**changes),budget=run.budget))
    controls.append(expect_exception(run,'lower.construct',L.Lowering,L.ConstructionBudgetExceeded,program,lower_limits(max_operations=0),budget=run.budget))
    controls.append(expect_exception(run,'lower.physical',L.physical_declaration,L.ConstructionBudgetExceeded,d,lower_limits(max_states=0),budget=run.budget))
    return {'choices':choices_ref,'diagnostic':diagnostic_ref,'controls':run.save('physical-negative-controls.json',controls)}


def full_C1_construction(run,libs,program):
    L=libs['lowering'];result={'attempts':1,'limits':lower_limits(),'selected':None,'physical':None,'status':None,'scope':'No physical FOL execution or Machine5 expansion in this cohort; small-control success is not physical FOL qualification.'}
    try:
        lower=run.call('C1.lower.construct',L.Lowering,program,lower_limits(),budget=run.budget)
        selected=run.call('C1.lower.declaration',lower.declaration)
        result['selected']=run.save('C1-complete-selected-model.json.gz',{'program':program,'selected':selected,'construction':run.call('C1.lower.receipt',lower.construction_receipt)},True)
        carrier=run.call('C1.carrier.build',libs['carrier'].build_carrier,program,{'functions':{},'predicates':{},'axioms':{},'schemas':[]},['bot'],1,carrier_limits(),budget=run.budget)
        caps={'word_capacity':64,'heap_padding':4096,'stack_capacity':32768}
        mask=run.call('C1.carrier.mask',libs['carrier'].build_physical_mask,program,selected,carrier,caps,carrier_limits(),budget=run.budget)
        initial=run.call('C1.lower.initial',lower.initial,{'nodes':carrier['value']['nodes'],'node':carrier['value']['input_node']},**caps)
        equal(initial,mask['value']['selected_placeholder_initial'],'genuine C1 rawtriple physical-root/entire initial binding')
        result['genuine_C1_mask']=run.save('C1-complete-carrier-mask.json.gz',{'carrier':carrier,'mask':mask,'input_role':'input_node','proof_byte_domain':'all256 unselected; no proof AST input'},True)
        try:
            physical=run.call('C1.lower.physical',L.physical_declaration,selected,lower_limits(),budget=run.budget)
            result['physical']=run.save('C1-complete-physical-model.json.gz',physical,True);result['status']='COMPLETE_FULL_MODELS_NO_FOL_EXECUTION'
        except L.ConstructionBudgetExceeded as error:
            result['status']='UNKNOWN_PHYSICAL_CONSTRUCTION';result['reason']=str(error)
    except L.ConstructionBudgetExceeded as error:
        result['status']='UNKNOWN_SELECTED_CONSTRUCTION';result['reason']=str(error)
    return {'status':result['status'],'evidence':run.save('C1-full-construction-attempt.json',result)}



def check_call_census(calls, construction_status):
    expected=dict(EXPECTED_CALL_BASE)
    if construction_status != 'UNKNOWN_SELECTED_CONSTRUCTION':expected.update(EXPECTED_CALL_C1_SELECTED)
    equal(calls,expected,'entire closed direct public call census, no hidden recipe')


def main():
    started=time.monotonic();parser=argparse.ArgumentParser()
    parser.add_argument('--plan',required=True);parser.add_argument('--result',required=True);args=parser.parse_args();run=None
    try:
        require(sys.executable==PYTHON['path'] and __file__==SOURCE_PATHS['worker'],'authenticated current runtime/Source path')
        require(sys.platform=='darwin' and sys.version_info[:2]==(3,12) and sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode,'isolated D90 Darwin')
        plan,plan_ref=plan_read(args.plan);directory=pathlib.Path(plan['actual_dir'])
        require(directory.is_dir() and not directory.is_symlink(),'owned existing directory')
        once_refs=consumed_read(plan,plan_ref,directory);retained=guard_read(plan,plan_ref,once_refs)
        require(args.result==str(directory/'worker-result.json') and not pathlib.Path(args.result).exists(),'exclusive fixed result')
        run=Run(plan,plan_ref,started);run.gate();libs=load_libraries(retained)
        real=run.call('tree.declaration',run.call('tree.compile',libs['tree_machine'].Compiler,retained['real_parser'].decode('ascii')).declaration)
        observation=run.call('tree.declaration',run.call('tree.compile',libs['tree_machine'].Compiler,retained['grammar_observer'].decode('ascii')).declaration)
        diagnostic=run.call('tree.declaration',run.call('tree.compile',libs['tree_machine'].Compiler,diagnostic_source()).declaration)
        program_ref=run.save('three-complete-fixed-programs.json.gz',{'real':real,'observation':observation,'diagnostic':diagnostic,'diagnostic_Source':diagnostic_source()},True)
        grammar_ref,streams=grammar_run(run,libs,observation)
        semantic_ref=semantic_run(run,libs,real)
        controls_ref=control_run(run,libs,observation,streams)
        physical=physical_run(run,libs,diagnostic)
        construction_ref=full_C1_construction(run,libs,real)
        check_call_census(run.calls,construction_ref['status'])
        guard_read(plan,plan_ref,once_refs);consumed_read(plan,plan_ref,directory);run.gate()
        summary={'schema':'GCTS-raw-proof-integration-result-v1','status':'COMPLETE_COMPONENT_CONTROLS','version':VERSION,'case_id':plan['case_id'],'plan':plan_ref,'sources':plan['sources'],'metadata':plan['metadata'],'cohort':COHORT,
          'public_calls':dict(run.calls),'evidence':{'programs':program_ref,'grammar':grammar_ref,'semantic':semantic_ref,'wire_resource':controls_ref,'physical':physical,'C1_construction':construction_ref,'all_prior_outputs':list(run.files)},
          'scope':'Authored encoding/component qualification only, not unknown-proof search or theorem discovery. One-way TREE_ACCEPTED implies B_VERIFIED, not equivalent verdict sets. Physical FOL acceptance and Machine5 expansion remain UNQUALIFIED even if complete construction succeeds; any construction refusal remains an explicit UNKNOWN gap.',
          'costs_before_result_serialization':{'elapsed_main_entry_seconds':time.monotonic()-started,'self_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_budget_callbacks':run.callbacks}}
        result=run.save('worker-result.json',summary)['stored'];guard_read(plan,plan_ref,once_refs);run.gate()
        terminal={'schema':'GCTS-raw-proof-worker-terminal-v1','status':'COMPLETE_COMPONENT_CONTROLS_RESULT_WRITTEN','case_id':plan['case_id'],'plan':plan_ref,'result':result,'public_calls':dict(run.calls),
          'post_readback_costs':{'elapsed_main_entry_seconds':time.monotonic()-started,'self_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_budget_callbacks':run.callbacks},
          'unmeasured_tail':'terminal encoding/flush and interpreter shutdown; fresh parent observes child lifetime highwater. No claim this fixed-input control searched an unknown proof.'}
        sys.stdout.buffer.write(encode(terminal));sys.stdout.buffer.flush();return 0
    except Exception as error:
        if run is not None:
            try:run.save('worker-failure.json',{'schema':'GCTS-raw-proof-worker-failure-v1','status':'UNADMITTED','exception_type':type(error).__name__,'message':str(error),'current':run.current,'calls':dict(run.calls),'all_retained_outputs':list(run.files)})
            except Exception:pass
        traceback.print_exc(file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
