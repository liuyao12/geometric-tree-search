"""Administrative single-entry Source sister authoring; no program execution."""
import ast,difflib,hashlib,json,pathlib
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');O=Q/'implementation-C';REAL=O/'proof_byte_fol_checker_v1.tree';NEW=O/'proof_byte_grammar_observer_v1.tree'
def enc(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def save(name,x):
 p=O/name
 with p.open('xb') as f:f.write(enc(x))
 return pin(p)
real=REAL.read_bytes();assert len(real)==29429 and h(real)=='1e62e4052349d3ff0e6a7746b111acd426e6ffede92e264c23a6be31016af5a5'
t=ast.parse(real);entry=t.body[0];assert entry.name=='main';lines=real.splitlines(keepends=True);old_main=b''.join(lines[entry.lineno-1:entry.end_lineno])
new_main=b'''def main(rows):
    version = ps_take(rows)
    if not is_pair(version):
        return False
    if not atom_eq(head(version), 1):
        return False
    return ps_proof(tail(version))
'''
raw=b''.join(lines[:entry.lineno-1])+new_main+b''.join(lines[entry.end_lineno:])
with NEW.open('xb') as f:f.write(raw)
u=ast.parse(raw);assert len(u.body)==len(t.body)==92 and u.body[0].name=='main' and [a.arg for a in u.body[0].args.args]==['rows']
current_lines=raw.splitlines(keepends=True);joins=[]
for a,b in zip(t.body[1:],u.body[1:]):
 before=b''.join(lines[a.lineno-1:a.end_lineno]);after=b''.join(current_lines[b.lineno-1:b.end_lineno]);assert a.name==b.name and before==after and ast.dump(a)==ast.dump(b)
 joins.append({'name':a.name,'arity':len(a.args.args),'old_line':a.lineno,'current_line':b.lineno,'raw_bytes':len(before),'raw_sha256':h(before),'plain_AST_sha256':h(ast.dump(a).encode()),'current_positioned_AST_sha256':h(ast.dump(b,include_attributes=True).encode()),'raw_and_plain_AST_identical':True})
# Whole inverse by replacing precisely the alternate first function.
e=u.body[0];restored=b''.join(current_lines[:e.lineno-1])+old_main+b''.join(current_lines[e.end_lineno:]);assert restored==real and ast.dump(ast.parse(restored),include_attributes=True)==ast.dump(t,include_attributes=True)
forward=''.join(difflib.unified_diff(real.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile=REAL.name,tofile=NEW.name,n=3)).encode();inverse=''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),real.decode().splitlines(keepends=True),fromfile=NEW.name,tofile=REAL.name,n=3)).encode();patches=[]
for name,data in [('proof-parser-to-grammar-observer-v1.patch',forward),('grammar-observer-to-proof-parser-v1.patch',inverse)]:
 p=O/name
 with p.open('xb') as f:f.write(data)
 patches.append(pin(p))
names={f.name:f for f in u.body};primitives={'cons':2,'head':1,'tail':1,'is_pair':1,'atom_eq':2,'byte_succ':1};graph={f.name:sorted({z.func.id for z in ast.walk(f) if isinstance(z,ast.Call) and isinstance(z.func,ast.Name) and z.func.id in names}) for f in u.body};reach=set();todo=['main']
while todo:
 n=todo.pop()
 if n in reach:continue
 reach.add(n);todo.extend(graph[n])
assert 'ps_semantic_main' not in reach and 'ps_request' not in reach and 'proof' not in reach and 'rule_ok' not in reach and 'ps_json_profile' not in reach
for f in u.body:
 for z in ast.walk(f):
  if isinstance(z,ast.Call):assert isinstance(z.func,ast.Name) and not z.keywords and len(z.args)==(len(names[z.func.id].args.args) if z.func.id in names else primitives[z.func.id])
main=u.body[0];assert not main.decorator_list and not main.args.defaults and not main.args.kwonlyargs
assert {z.func.id for z in ast.walk(main) if isinstance(z,ast.Call)}=={'ps_take','is_pair','atom_eq','head','ps_proof','tail'}
assert [z.name for z in u.body[1:]]==[z.name for z in t.body[1:]]
static=save('grammar-observer-sister-complete-static-preservation-v1.json',{'schema':'C-grammar-observer-sister-complete-static-preservation-v1','qualification_only_Source':pin(NEW),'real_fixed_proof_machine_Source_unchanged':pin(REAL),'first_main_before_raw_sha256':h(old_main),'first_main_after_raw_sha256':h(new_main),'only_change':'first function main(raw) replaced by generic main(rows), versioncheck then returnps_proof directly. No other Source bytes changed.','all91_nonmain_helpers':joins,'complete_inverse_exact_raw_and_positioned_AST':True,'patches':patches,'conservative_entry_reach':sorted(reach),'semantic_and_prefix_profile_functions_not_entry_reachable':True,'whole_AST_sha256':h(ast.dump(u).encode()),'whole_positioned_AST_sha256':h(ast.dump(u,include_attributes=True).encode()),'AST_parse_static_call_arity_only':True,'subject_compiler_VM_parser_decoder_proof_factory_test_CLI_codeobject_calls':0})
api=save('grammar-observer-sister-public-ABI-v1.json',{'schema':'C-grammar-observer-sister-public-ABI-v1','status':'INERT_QUALIFICATION_ONLY_NOT_PROOF_MACHINE','Source':pin(NEW),'real_proof_machine':pin(REAL),'entry':'First static main(rows), one proper raw stream-row cons list, NOT real main(rawtheorytargetrowstriple). Same privateMarker row and byte0..255 canonicalcarrier profile.','operation':'ps_take first row; requireVersion1; returnps_proof(rest) directly. Same fullnonempty LINE16/END17/ASCII/list/ref/term/form grammar1, all91 nonmain helper bodies exact. No theory,target,prefix-profile or semanticchecker call reachable from entry.','returned_value':{'grammar_success':'Existing newly constructed or interned JSONproofarray nodeID>256. Root observes value and full finalHeap through a separately qualified bounded generic JSONnode data decoder; no semantic callbacks.','grammar_failure':'Normal atom0/False, no proofdata node.','resources_or_bad_carrier':'VMunknown_step/heap budget or invalid-data outcome with no confirmed normal value is not a grammar verdict or proof result.'},'critical_VM_label_precision':'Recovered tree_machine.run labels rootreturn accepted iff value==1; all other normal values including a valid JSONproof NODE are labeled rejected. For this sister ONLY, use normal returnedvalue and data decoding; never interpret its Boolacceptance status as logical/grammar validity or proof-machine acceptance.','no_accidental_acceptance':'A successful ps_proof returns a consnode>=257, never atom1. Any VMaccepted/value1 on this sister is protocol inconsistency, not a theorem.','qualification_comparison':'After a complete normal returned node and bounded generic HeapJSON observation, compare whole nativeproof values with independently Bdecode of the exact same bytes. Data equality only. Semantic checks and actualunknownproofsearch use unchanged realC1 program separately.','instance_isolation':'Compile separately only under future once gate, create fresh declaration/Heap/carrier for this Source. Do not reuse nodeIDs or constant addresses from realC1 declaration; main literal discovery order can alter compilerconstant-pool IDs.','input_prefix_scope':'Same allhelper Source retained for preservation; known theory/target may exist in its own carrier but are not passed or consulted by this entry. Marker freshness/privateidentity/readonly/physicalMIN8 mask remain Ladapter obligations.','remaining':'Root supplied genericboundedHeapJSONobserver Source, focusedSource peer, exact closed once caller/cohort and freshauthority before any compiler/VM/parser/data-observer calls.','no_qualification_or_result':'Source authoring only. This is a static generic control program, never a new discovered theorem, newmachineproofacceptor, GCTS/RL outcome or performance claim.','static':static,'activity':{'subject_compiler_VM_parser_codec_semantic_observer_helpers_factories_proofs_tests_CLI_calls':0,'codeobject_compilation_execution':0,'network':0}})
handoff=save('grammar-observer-sister-complete-inert-Source-handoff-v1.json',{'schema':'C-grammar-observer-sister-complete-inert-Source-handoff-v1','status':'COMPLETE_QUALIFICATION_ONLY_SOURCE_UNRUN','Source':pin(NEW),'public_ABI':api,'complete_static_preservation':static,'inherited_full_real_parser_handoff':pin(O/'runtime-proof-byte-parser-complete-inert-Source-handoff-v1.json'),'coverage':{'only_main_changed':True,'nonmain_raw_AST_exact':91,'functions':92,'semantic_entry_reachable':False,'prefix_profile_entry_reachable':False,'entry_reachable_functions':len(reach),'subjectcalls':0},'terminal_state':'IDLE','remaining':'Focused B peer when Root dispatches, generic bounded data-observer Source and Root closed qualification. No actual search or proof admission from this program.'})
print(json.dumps({'Source':pin(NEW),'ABI':api,'static':static,'handoff':handoff,'reachable':len(reach)},sort_keys=True))
