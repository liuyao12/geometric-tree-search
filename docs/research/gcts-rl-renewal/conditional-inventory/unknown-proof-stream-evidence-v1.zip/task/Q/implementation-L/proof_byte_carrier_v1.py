"""Unrun generic raw-byte carrier and MIN8 data-word physical mask adapter.

Only known theory/target JSON is encoded. There is no proof-AST argument.
Every proof row has the full byte domain; zero fields are unselected layout
placeholders, never a proof/witness. No project imports, IO, VM or CLI.
"""
import hashlib
import json

VERSION = 'RAW-PROOF-BYTE-CARRIER-MIN8-v1'
WORD_PROFILE = 'MIN8_LSB_DATA_CANONICAL-v1'
NIL = 256
RAW = ('B', '^', '0', '1', ':', ',', ';')
LIMIT_KEYS = ('max_operations', 'max_nodes', 'max_stream_bytes',
              'max_selected_cells', 'max_physical_cells')


class CarrierError(Exception):
    pass


class CarrierBudgetExceeded(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise CarrierError(message)


def _canon(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False).encode('ascii')


def _sha(value):
    return hashlib.sha256(_canon(value)).hexdigest()


def _fields(value, keys):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(keys), 'exact record fields')


class _Meter:
    def __init__(self, limits, budget):
        _fields(limits, LIMIT_KEYS)
        _need(all(type(v) is int and v >= 0 for v in limits.values()), 'nonnegative exact limits')
        _need(budget is None or callable(budget), 'budget callable')
        self.limits = dict(limits)
        self.budget = budget
        self.operations = 0
        self.callbacks = 0

    def tick(self, units=1):
        if units > self.limits['max_operations'] - self.operations:
            raise CarrierBudgetExceeded('carrier operation cap')
        self.operations += units
        if self.budget is not None:
            self.callbacks += 1
            self.budget()

    def cost(self):
        return {'operations': self.operations, 'budget_callbacks': self.callbacks,
                'scope': 'Logical charged work and actual callbacks, not hard CPU/RAM/time. Foreign callback exceptions propagate.'}


def _ascii(value):
    _need(type(value) is str and value and all(32 <= ord(c) <= 126 for c in value),
          'nonempty printable ASCII known JSON string/key')


class _Heap:
    def __init__(self, nodes, meter):
        _need(type(nodes) is list, 'initial node list')
        self.nodes, self.index, self.m = [], {}, meter
        for raw in nodes:
            meter.tick()
            _need(type(raw) in (list, tuple) and len(raw) == 2, 'node pair')
            a, b = raw
            _need(type(a) is int and type(b) is int and 0 <= a < 257 + len(self.nodes)
                  and 0 <= b < 257 + len(self.nodes), 'earlier child or atom')
            _need((a, b) not in self.index, 'duplicate initial pair')
            self.cons(a, b)

    def cons(self, a, b):
        self.m.tick()
        _need(type(a) is int and type(b) is int and 0 <= a < 257 + len(self.nodes)
              and 0 <= b < 257 + len(self.nodes), 'cons existing children')
        pair = (a, b)
        if pair not in self.index:
            if len(self.nodes) >= self.m.limits['max_nodes']:
                raise CarrierBudgetExceeded('carrier node cap')
            self.index[pair] = 257 + len(self.nodes)
            self.nodes.append([a, b])
        return self.index[pair]

    def word(self, values):
        result = NIL
        for value in reversed(values):
            result = self.cons(value, result)
        return result


def _known_json(heap, value):
    """Independent syntax encoder for known theory/target only, never proof."""
    todo, values, active = [('visit', value)], [], set()
    while todo:
        heap.m.tick()
        op, x = todo.pop()
        if op == 'visit':
            if type(x) in (dict, list):
                _need(id(x) not in active, 'cyclic known JSON')
                active.add(id(x))
                if type(x) is dict:
                    for k in x:
                        _need(type(k) is str, 'known JSON object key type')
                        heap.m.tick(len(k))
                        _ascii(k)
                    heap.m.tick(len(x) * max(1, len(x).bit_length()))
                    items = sorted(x.items())
                    todo.append(('object', (id(x), [k for k, v in items])))
                    todo.extend(('visit', v) for k, v in reversed(items))
                else:
                    todo.append(('array', (id(x), len(x))))
                    todo.extend(('visit', v) for v in reversed(x))
            elif type(x) is str:
                heap.m.tick(len(x))
                _ascii(x)
                values.append(heap.cons(2, heap.word(list(x.encode('ascii')))))
            elif type(x) is bool:
                values.append(heap.cons(5, int(x)))
            elif type(x) is int:
                natural = NIL
                for _ in range(abs(x)):
                    natural = heap.cons(1, natural)
                values.append(heap.cons(3 if x >= 0 else 4, natural))
            elif x is None:
                values.append(heap.cons(6, NIL))
            else:
                raise CarrierError('known JSON exact native types only')
        else:
            identity, payload = x
            active.remove(identity)
            n = payload if op == 'array' else len(payload)
            children = values[-n:] if n else []
            if n:
                del values[-n:]
            if op == 'array':
                body = heap.word(children)
            else:
                pairs = [heap.cons(heap.word(list(k.encode('ascii'))), child)
                         for k, child in zip(payload, children, strict=True)]
                body = heap.word(pairs)
            values.append(heap.cons(1 if op == 'array' else 0, body))
    _need(len(values) == 1, 'known encoder stack')
    return values[0]


def _program(program):
    _fields(program, ('atom_max', 'nil', 'nodes', 'constants', 'functions'))
    _need(type(program['atom_max']) is int and program['atom_max'] == 256
          and type(program['nil']) is int and program['nil'] == 256,
          'tree program atom header')
    _need(type(program['functions']) is list and program['functions']
          and type(program['constants']) is list, 'trusted program arrays')
    # The fixed declaration is also fully validated by the reviewed lowering.
    # This adapter validates the entire inherited heap, not instruction semantics.
    return _sha(program)


def build_carrier(program, theory, target, byte_count, limits, *, budget=None):
    m = _Meter(limits, budget)
    m.tick()
    _need(type(program) is dict and type(program.get('nodes')) is list, 'program nodes')
    if len(program['nodes']) > m.limits['max_nodes']:
        raise CarrierBudgetExceeded('program prefix node cap')
    m.tick(len(program['nodes']))
    program_sha = _program(program)
    _fields(theory, ('functions', 'predicates', 'axioms', 'schemas'))
    _need(type(theory['schemas']) is list and not theory['schemas'], 'schemas empty common profile')
    _need(all(type(theory[k]) is dict for k in ('functions', 'predicates', 'axioms')),
          'known theory object fields')
    _need(type(byte_count) is int and byte_count >= 0, 'exact nonnegative byte count')
    if byte_count > m.limits['max_stream_bytes']:
        raise CarrierBudgetExceeded('stream byte cap')
    heap = _Heap(program['nodes'], m)
    program_nodes = len(heap.nodes)
    theory_node = _known_json(heap, theory)
    target_node = _known_json(heap, target)
    trusted_nodes = len(heap.nodes)
    markers, attempts = [], 0
    marker = NIL
    if byte_count:
        while True:
            attempts += 1
            marker = heap.cons(NIL, marker)
            if marker >= 257 + trusted_nodes:
                break
            _need(attempts <= trusted_nodes, 'fresh-chain finite prefix invariant')
        markers.append(marker)
        for _ in range(1, byte_count):
            marker = heap.cons(NIL, marker)
            markers.append(marker)
    rows = [heap.cons(0, marker) for marker in markers]
    stream_node = heap.word(rows)
    input_node = heap.word([theory_node, target_node, stream_node])
    m.tick(len(heap.nodes))
    value = {'version': VERSION, 'program_sha256': program_sha,
             'known': {'theory': json.loads(_canon(theory)), 'target': json.loads(_canon(target)),
                       'theory_sha256': _sha(theory), 'target_sha256': _sha(target)},
             'nodes': heap.nodes, 'input_node': input_node, 'theory_node': theory_node,
             'target_node': target_node, 'stream_node': stream_node,
             'program_prefix_nodes': program_nodes, 'trusted_prefix_nodes': trusted_nodes,
             'trusted_prefix_sha256': _sha(heap.nodes[:trusted_nodes]),
             'byte_count': byte_count, 'marker_ids': markers,
             'byte_rows': [{'byte_index': i, 'node_id': row, 'node_index': row - 257,
                            'marker_id': markers[i], 'head_placeholder': 0,
                            'domain': {'minimum': 0, 'maximum': 255, 'all_values_allowed': True}}
                           for i, row in enumerate(rows)],
             'fresh_marker_attempts': attempts,
             'binding': 'Proper raw cons-list3(theory JSON node,target JSON node,proper stream). Every row head unselected; all other nodes/links fixed. blocks=[] assembled only by fixed runtime parser.'}
    return {'schema': 'L-raw-proof-byte-carrier-v1', 'value': value, 'cost': m.cost()}


def verify_carrier_choice(carrier, nodes, input_node, *, budget=None):
    _fields(carrier, ('schema', 'value', 'cost'))
    _need(carrier['schema'] == 'L-raw-proof-byte-carrier-v1', 'carrier schema')
    c = carrier['value']
    _need(type(nodes) is list and len(nodes) == len(c['nodes'])
          and type(input_node) is int and input_node == c['input_node'], 'complete initial heap/root association')
    by_id = {r['node_id']: r for r in c['byte_rows']}
    seen, values = set(), [None] * c['byte_count']
    for i, (given, template) in enumerate(zip(nodes, c['nodes'], strict=True)):
        if budget is not None:
            budget()
        _need(type(given) in (list, tuple) and len(given) == 2, 'choice node pair')
        a, b = given
        _need(type(a) is int and type(b) is int and 0 <= a < 257 + i and 0 <= b < 257 + i,
              'choice earlier children')
        row = by_id.get(257 + i)
        if row is None:
            _need(given[0] == template[0] and given[1] == template[1], 'changed fixed heap record')
        else:
            _need(0 <= a <= 255 and b == row['marker_id'] == template[1], 'byte choice or marker')
            values[row['byte_index']] = a
        _need((a, b) not in seen, 'choice pair interning collision')
        seen.add((a, b))
    _need(all(type(v) is int for v in values), 'all byte rows covered')
    return {'status': 'VERIFIED', 'byte_values': values,
            'scope': 'Complete initial heap under the caller-bound generated carrier; no runtime appended heap or proof semantics.'}


def _data_bits(n):
    _need(type(n) is int and n >= 0, 'exact data natural')
    return format(n, 'b')[::-1].ljust(8, '0')



def _u32(value):
    _need(type(value) is int and 0 <= value < (1 << 32), 'unsigned32 physical input format')
    return list(value.to_bytes(4, 'little'))

def build_physical_mask(program, lowering, carrier, capacities, limits, *, budget=None):
    m = _Meter(limits, budget)
    _fields(carrier, ('schema', 'value', 'cost'))
    c = carrier['value']
    rebuilt = build_carrier(program, c['known']['theory'], c['known']['target'], c['byte_count'], limits, budget=budget)
    _need(_canon(rebuilt['value']) == _canon(c), 'complete carrier value regenerated from fixed known inputs')
    _fields(capacities, ('word_capacity', 'heap_padding', 'stack_capacity'))
    _need(all(type(v) is int and v >= 0 for v in capacities.values()), 'exact capacity values')
    _need(type(lowering) is dict, 'lowering declaration')
    _need(lowering.get('word_profile') == WORD_PROFILE
          and lowering.get('construction_source_version') == 'TREE-TAPE-MIN8-DATA-BUDGETED-v2'
          and lowering.get('program_sha256') == _program(program), 'current MIN8 program binding')
    for key in ('registers', 'arg', 'work', 'heap', 'next', 'stack', 'tapes', 'address_width'):
        _need(type(lowering.get(key)) is int and lowering[key] >= 0, 'integer lowering layout')
    r, arg, work = lowering['registers'], lowering['arg'], lowering['work']
    h, nxt, stack, tapes = (lowering[k] for k in ('heap', 'next', 'stack', 'tapes'))
    _need(r >= 1 and arg == r and work == r + max(f['arity'] for f in program['functions']) and h == work + 4
          and nxt == h + 1 and stack == nxt + 1 and tapes == stack + 1
          and lowering['address_width'] >= 1, 'complete tape-index layout')
    _need(type(lowering.get('allocation')) is list and lowering['allocation'], 'allocation declaration')
    slot = lowering['allocation'][0]['slots'][0]
    _need(type(slot) is int and 0 <= slot < r, 'main input register slot')
    m.tick(tapes)
    allocation = lowering['allocation']
    _need(len(allocation) == len(program['functions']), 'full allocation association')
    for function, record in zip(program['functions'], allocation, strict=True):
        slots = record['slots']
        m.tick(len(slots))
        _need(type(slots) is list and len(slots) == function['registers']
              and all(type(x) is int and 0 <= x < r for x in slots), 'full register slot mapping')
    _need(max(max(a['slots']) for a in allocation) + 1 == r, 'actual allocated register extent')
    values, heads = [''] * tapes, [1] * tapes
    for i in range(r):
        values[i] = _data_bits(c['input_node'] if i == slot else NIL)
    word_parts, fields_at, cursor = [], {}, 0
    for i, (a, b) in enumerate(c['nodes']):
        m.tick()
        identity = _data_bits(257 + i)
        head, tail = _data_bits(a), _data_bits(b)
        fields_at[257 + i] = {'record_word_offset': cursor, 'id_word_offset': cursor, 'id_width': len(identity),
                             'head_word_offset': cursor + len(identity) + 1, 'head_width': len(head),
                             'tail_word_offset': cursor + len(identity) + len(head) + 2, 'tail_width': len(tail),
                             'colon_offset': cursor + len(identity), 'comma_offset': cursor + len(identity) + len(head) + 1,
                             'semicolon_offset': cursor + len(identity) + len(head) + len(tail) + 2}
        record = identity + ':' + head + ',' + tail + ';'
        word_parts.append(record)
        cursor += len(record)
    values[h] = ''.join(word_parts)
    values[nxt] = _data_bits(257 + len(c['nodes']))
    values[stack] = ':' + ('0' * lowering['address_width']) + ';'
    heads[stack] = len(values[stack]) + 1
    sizes = [capacities['word_capacity']] * tapes
    sizes[h] = len(values[h]) + capacities['heap_padding']
    sizes[stack] = capacities['stack_capacity']
    _need(all(len(w) + 1 < n for w, n in zip(values, sizes, strict=True)), 'initial capacities leave terminal blank')
    if sum(sizes) > m.limits['max_selected_cells'] or 1 + sum(n + 2 for n in sizes) > m.limits['max_physical_cells']:
        raise CarrierBudgetExceeded('selected/physical cell cap')
    selected = [['^'] + list(w) + ['B'] * (n - len(w) - 1) for w, n in zip(values, sizes, strict=True)]
    physical, headers = ['L'], []
    for i, (body, head) in enumerate(zip(selected, heads, strict=True)):
        m.tick(len(body))
        _need(0 <= head < len(body), 'logical initial head')
        headers.append(len(physical))
        marked = list(body)
        marked[head] = '@' + marked[head]
        physical.extend(['S' + str(i)] + marked + ['#'])
    unknown = []
    for row in c['byte_rows']:
        f = fields_at[row['node_id']]
        _need(f['head_width'] == 8, 'complete eight-bit atom field')
        for bit in range(8):
            m.tick()
            selected_cell = 1 + f['head_word_offset'] + bit
            physical_cell = headers[h] + 1 + selected_cell
            _need(selected_cell != heads[h] and physical[physical_cell] == '0', 'unmarked placeholder bit')
            physical[physical_cell] = None
            unknown.append({'byte_index': row['byte_index'], 'row_id': row['node_id'], 'bit': bit,
                            'weight': 1 << bit, 'selected_tape': h, 'selected_cell': selected_cell,
                            'physical_cell': physical_cell, 'symbols': ['0', '1']})
    m.tick(len(physical))
    alphabet = ['L'] + list(RAW) + ['#'] + ['@' + x for x in list(RAW) + ['#']] + ['S' + str(i) for i in range(tapes)]
    header_words = [0x47544931, len(sizes), *sizes, len(physical)]
    binary_header = [b for n in header_words for b in _u32(n)]
    binary_template = list(binary_header)
    binary_domains = []
    ordinal = {symbol: i for i, symbol in enumerate(alphabet)}
    unknown_by_cell = {f['physical_cell']: f for f in unknown}
    for cell, symbol in enumerate(physical):
        m.tick(4)
        if symbol is None:
            f = unknown_by_cell[cell]
            binary_domains.append({'physical_cell': cell, 'byte_index': f['byte_index'], 'bit': f['bit'],
                                   'file_word_index': len(header_words) + cell, 'byte_offset': len(binary_template),
                                   'symbol_names': ['0', '1'], 'symbol_ids': [ordinal['0'], ordinal['1']],
                                   'little_endian_uint32_alternatives': [_u32(ordinal['0']), _u32(ordinal['1'])]})
            binary_template.extend([None] * 4)
        else:
            binary_template.extend(_u32(ordinal[symbol]))
    value = {'version': VERSION, 'word_profile': WORD_PROFILE,
             'program_sha256': c['program_sha256'], 'lowering_sha256': _sha(lowering),
             'lowering_source_version': lowering['construction_source_version'],
             'carrier_value_sha256': _sha(c), 'theory_sha256': c['known']['theory_sha256'],
             'target_sha256': c['known']['target_sha256'], 'input_node': c['input_node'],
             'byte_count': c['byte_count'], 'physical_template': physical,
             'unknown_bits': unknown, 'alphabet': alphabet, 'physical_initial_head': 0,
             'physical_initial_symbol': 'L', 'selected_placeholder_initial': {'words': values, 'heads': heads, 'capacities': sizes},
             'physical_headers': headers, 'binary_header_words': header_words,
             'binary_input_template': binary_template, 'binary_symbol_domains': binary_domains,
             'binary_scope': 'Exact tape_binary.write_input LE uint32 format; two correlated complete symbol-word alternatives, never independent free file bits.',
             'heap_tape': h, 'record_field_locations': {str(k): v for k, v in fields_at.items()},
             'scope': 'None and zero HEAD fields are unselected placeholders, never a proof. Only these8bits/byte vary. Complete physical Machine5 expansion/acceptance and future execution remain separate.'}
    return {'schema': 'L-proof-byte-MIN8-physical-mask-v1', 'value': value,
            'cost': {'adapter': m.cost(), 'full_carrier_regeneration': rebuilt['cost']}}


def _mask(mask):
    _fields(mask, ('schema', 'value', 'cost'))
    _need(mask['schema'] == 'L-proof-byte-MIN8-physical-mask-v1', 'mask schema')
    v = mask['value']
    _need(v['word_profile'] == WORD_PROFILE and type(v['byte_count']) is int
          and v['byte_count'] >= 0 and type(v['physical_template']) is list
          and type(v['unknown_bits']) is list and len(v['unknown_bits']) == 8 * v['byte_count'], 'complete mask extent')
    seen, pairs = set(), set()
    for field in v['unknown_bits']:
        _need(type(field['physical_cell']) is int and 0 <= field['physical_cell'] < len(v['physical_template'])
              and field['physical_cell'] not in seen and v['physical_template'][field['physical_cell']] is None,
              'unique unknown physical cell')
        i, bit = field['byte_index'], field['bit']
        _need(type(i) is int and 0 <= i < v['byte_count'] and type(bit) is int and 0 <= bit < 8
              and type(field['weight']) is int and field['weight'] == 1 << bit and field['symbols'] == ['0', '1'] and (i, bit) not in pairs,
              'complete bit domain')
        seen.add(field['physical_cell']); pairs.add((i, bit))
    _need({i for i, symbol in enumerate(v['physical_template']) if symbol is None} == seen,
          'no undeclared physical freedom')
    return v


def materialize_physical(mask, byte_values, *, budget=None):
    v = _mask(mask)
    _need(type(byte_values) in (list, tuple, bytes) and len(byte_values) == v['byte_count']
          and all(type(b) is int and 0 <= b <= 255 for b in byte_values), 'full actual byte choice')
    result = list(v['physical_template'])
    for f in v['unknown_bits']:
        if budget is not None:
            budget()
        result[f['physical_cell']] = str((byte_values[f['byte_index']] >> f['bit']) & 1)
    return result


def decode_physical_choice(mask, physical_tape, *, budget=None):
    v = _mask(mask)
    _need(type(physical_tape) in (list, tuple) and len(physical_tape) == len(v['physical_template']), 'full physical extent')
    unknown = {f['physical_cell']: f for f in v['unknown_bits']}
    values = [0] * v['byte_count']
    for i, (symbol, fixed) in enumerate(zip(physical_tape, v['physical_template'], strict=True)):
        if budget is not None:
            budget()
        _need(type(symbol) is str, 'physical symbol type')
        if i in unknown:
            _need(symbol in ('0', '1'), 'actual byte bit')
            f = unknown[i]
            values[f['byte_index']] |= int(symbol) << f['bit']
        else:
            _need(symbol == fixed, 'changed fixed physical input symbol')
    return {'status': 'VERIFIED', 'byte_values': values,
            'scope': 'Complete initial physical choice under the caller-bound generated mask; not a final VM proof or semantic verdict.'}



def materialize_binary(mask, byte_values, *, budget=None):
    v = _mask(mask)
    tape = materialize_physical(mask, byte_values, budget=budget)
    sizes = v['selected_placeholder_initial']['capacities']
    header = [0x47544931, len(sizes), *sizes, len(tape)]
    ordinal = {symbol: i for i, symbol in enumerate(v['alphabet'])}
    result = bytearray()
    for value in header:
        result.extend(_u32(value))
    for symbol in tape:
        if budget is not None:
            budget()
        result.extend(_u32(ordinal[symbol]))
    return bytes(result)


def decode_binary_choice(mask, raw, *, budget=None):
    v = _mask(mask)
    _need(type(raw) is bytes, 'exact binary input bytes')
    sizes = v['selected_placeholder_initial']['capacities']
    header = [0x47544931, len(sizes), *sizes, len(v['physical_template'])]
    prefix = bytes(b for n in header for b in _u32(n))
    _need(len(raw) == len(prefix) + 4 * len(v['physical_template']) and raw[:len(prefix)] == prefix,
          'exact full binary input header/extent')
    tape = []
    for offset in range(len(prefix), len(raw), 4):
        if budget is not None:
            budget()
        ordinal = int.from_bytes(raw[offset:offset + 4], 'little')
        _need(ordinal < len(v['alphabet']), 'full alphabet ordinal')
        tape.append(v['alphabet'][ordinal])
    return decode_physical_choice(mask, tape, budget=budget)
