"""Bounded observation-only decoder of the ASCII old encode_json heap profile.

No encoder, Heap, VM, parser, proof rule or project import. VM status is not an
input: a completed observation returning a JSON-node ID is decoded by value,
even if the old VM labels that non-boolean return 'rejected'. No proof verdict.
"""

VERSION = 'ASCII-TREE-HEAP-JSON-DECODER-v1'
NIL = 256
LIMIT_KEYS = ('max_operations', 'max_heap_nodes', 'max_depth',
              'max_expanded_output_nodes', 'max_string_bytes', 'max_natural')
SCOPE = ('Syntax observation only for nonempty printable ASCII strings/keys. '
         'No full Unicode inverse, mathematical logic, proof truth or VM-status interpretation. '
         'UNKNOWN and rejected receipts contain no partial decoded value.')


class _Reject(Exception):
    pass


class _Limit(Exception):
    pass


def _need(condition, reason):
    if not condition:
        raise _Reject(reason)


def _limits(value):
    _need(type(value) is dict and len(value) == len(LIMIT_KEYS) and all(type(k) is str for k in value)
          and set(value) == set(LIMIT_KEYS), 'LIMIT_FIELDS')
    _need(all(type(x) is int and x >= 0 for x in value.values()), 'LIMIT_VALUES')
    return dict(value)


class _Meter:
    def __init__(self, limits, budget):
        self.limits = limits
        self.budget = budget
        self.visits = {'operations': 0, 'budget_callbacks': 0, 'heap_nodes_validated': 0,
                       'unique_JSON_recipes': 0, 'list_links': 0, 'string_cells': 0,
                       'natural_cells': 0, 'recipe_edges': 0, 'max_value_depth_seen': 0,
                       'reserved_expanded_output_nodes': 0, 'reserved_string_bytes': 0,
                       'materialized_value_nodes': 0, 'materialized_key_nodes': 0,
                       'materialized_string_bytes': 0}

    def tick(self, units=1):
        if units > self.limits['max_operations'] - self.visits['operations']:
            raise _Limit('OPERATION_LIMIT')
        self.visits['operations'] += units
        if self.budget is not None:
            self.visits['budget_callbacks'] += 1
            self.budget()

    def depth(self, value):
        self.visits['max_value_depth_seen'] = max(self.visits['max_value_depth_seen'], value)
        if value > self.limits['max_depth']:
            raise _Limit('DEPTH_LIMIT')

    def weights(self, nodes, strings):
        if nodes > self.limits['max_expanded_output_nodes']:
            raise _Limit('EXPANDED_OUTPUT_LIMIT')
        if strings > self.limits['max_string_bytes']:
            raise _Limit('EXPANDED_STRING_LIMIT')


def _heap(nodes, meter):
    _need(type(nodes) is list, 'HEAP_ARRAY')
    if len(nodes) > meter.limits['max_heap_nodes']:
        raise _Limit('HEAP_NODE_LIMIT')
    result, seen = [], set()
    for i, pair in enumerate(nodes):
        meter.tick()
        _need(type(pair) in (list, tuple) and len(pair) == 2, 'HEAP_PAIR')
        a, b = pair
        _need(type(a) is int and type(b) is int and 0 <= a < 257 + i
              and 0 <= b < 257 + i, 'HEAP_EARLIER_REFERENCE')
        _need((a, b) not in seen, 'HEAP_DUPLICATE_PAIR')
        seen.add((a, b))
        result.append((a, b))
        meter.visits['heap_nodes_validated'] += 1
    return result


def _pair(heap, node):
    _need(type(node) is int and 257 <= node < 257 + len(heap), 'PAIR_REQUIRED')
    return heap[node - 257]


def _list(heap, node, meter, multiplier):
    result = []
    while node != NIL:
        meter.tick()
        head, node = _pair(heap, node)
        meter.weights(1 + multiplier * (len(result) + 1), 0)
        result.append(head)
        meter.visits['list_links'] += 1
    return result


def _text(heap, node, meter):
    root, length = node, 0
    while node != NIL:
        meter.tick()
        head, node = _pair(heap, node)
        _need(32 <= head <= 126, 'ASCII_STRING_CELL')
        if length >= meter.limits['max_string_bytes']:
            raise _Limit('STRING_LIMIT')
        length += 1
        meter.visits['string_cells'] += 1
    _need(length > 0, 'EMPTY_STRING')
    # No expanded native string is allocated during recipe analysis.
    return {'root': root, 'length': length}


def _natural(heap, node, meter):
    result = 0
    while node != NIL:
        meter.tick()
        head, node = _pair(heap, node)
        _need(head == 1, 'NATURAL_CELL')
        if result >= meter.limits['max_natural']:
            raise _Limit('NATURAL_LIMIT')
        result += 1
        meter.visits['natural_cells'] += 1
    return result


def _recipe(heap, node, meter):
    tag, payload = _pair(heap, node)
    _need(0 <= tag <= 6, 'JSON_TAG')
    if tag in (0, 1):
        items = _list(heap, payload, meter, 2 if tag == 0 else 1)
        children, keys, seen = [], [], set()
        for item in items:
            meter.tick()
            if tag == 0:
                key, item = _pair(heap, item)
                text = _text(heap, key, meter)
                # Whole-heap pair interning makes identical proper words have
                # exactly the same root ID; no string/hash collision assumption.
                _need(text['root'] not in seen, 'DUPLICATE_OBJECT_KEY')
                seen.add(text['root'])
                keys.append(text)
            _pair(heap, item)
            children.append(item)
            meter.visits['recipe_edges'] += 1
        return {'kind': 'object' if tag == 0 else 'array', 'children': children, 'keys': keys}
    if tag == 2:
        return {'kind': 'string', 'data': _text(heap, payload, meter)}
    if tag in (3, 4):
        natural = _natural(heap, payload, meter)
        _need(tag != 4 or natural > 0, 'NEGATIVE_ZERO')
        return {'kind': 'scalar', 'data': natural if tag == 3 else -natural}
    if tag == 5:
        _need(payload in (0, 1), 'BOOLEAN_PAYLOAD')
        return {'kind': 'scalar', 'data': bool(payload)}
    _need(payload == NIL, 'NULL_PAYLOAD')
    return {'kind': 'scalar', 'data': None}


def _analyze(heap, root, meter):
    memo, jobs = {}, [('visit', root, 1, None)]
    while jobs:
        meter.tick()
        action, node, depth, recipe = jobs.pop()
        meter.depth(depth)
        if action == 'visit':
            if node in memo:
                meter.depth(depth + memo[node]['height'] - 1)
                continue
            meter.weights(1, 0)
            recipe = _recipe(heap, node, meter)
            if recipe['kind'] in ('array', 'object'):
                meter.tick(1 + len(recipe['children']))
                jobs.append(('finish', node, depth, recipe))
                for child in reversed(recipe['children']):
                    jobs.append(('visit', child, depth + 1, None))
                continue
        if recipe['kind'] in ('array', 'object'):
            weights = 1 + (len(recipe['keys']) if recipe['kind'] == 'object' else 0)
            strings = sum(key['length'] for key in recipe['keys'])
            height = 1
            for child in recipe['children']:
                meter.tick()
                weights += memo[child]['weight_nodes']
                strings += memo[child]['weight_strings']
                height = max(height, 1 + memo[child]['height'])
                meter.weights(weights, strings)
            recipe.update(weight_nodes=weights, weight_strings=strings, height=height)
        else:
            recipe.update(weight_nodes=1, weight_strings=recipe['data']['length'] if recipe['kind'] == 'string' else 0, height=1)
        meter.weights(recipe['weight_nodes'], recipe['weight_strings'])
        meter.depth(depth + recipe['height'] - 1)
        memo[node] = recipe
        meter.visits['unique_JSON_recipes'] += 1
    return memo


def _material_string(heap, word, meter):
    chars, node = [], word['root']
    while node != NIL:
        meter.tick(0)
        head, node = _pair(heap, node)
        chars.append(chr(head))
    return ''.join(chars)


def _materialize(heap, memo, root, meter):
    total = memo[root]
    meter.weights(total['weight_nodes'], total['weight_strings'])
    # All repeated-edge output weights are checked/reserved BEFORE native output.
    meter.tick(total['weight_nodes'] + total['weight_strings'])
    meter.visits['reserved_expanded_output_nodes'] = total['weight_nodes']
    meter.visits['reserved_string_bytes'] = total['weight_strings']
    jobs, values = [('visit', root)], []
    while jobs:
        meter.tick(0)  # Foreign global budget still runs during expanded work.
        action, node = jobs.pop()
        recipe = memo[node]
        kind = recipe['kind']
        if action == 'visit' and kind in ('array', 'object'):
            jobs.append(('finish', node))
            for child in reversed(recipe['children']):
                jobs.append(('visit', child))
            continue
        if action == 'finish':
            count = len(recipe['children'])
            children = values[-count:] if count else []
            if count:
                del values[-count:]
            if kind == 'array':
                value = list(children)
            else:
                value = {}
                for key, child in zip(recipe['keys'], children, strict=True):
                    meter.tick(0)
                    text = _material_string(heap, key, meter)
                    value[text] = child
                    meter.visits['materialized_key_nodes'] += 1
                    meter.visits['materialized_string_bytes'] += key['length']
            values.append(value)
        elif kind == 'string':
            values.append(_material_string(heap, recipe['data'], meter))
            meter.visits['materialized_string_bytes'] += recipe['data']['length']
        else:
            values.append(recipe['data'])
        meter.visits['materialized_value_nodes'] += 1
    if len(values) != 1 or (meter.visits['materialized_value_nodes'] + meter.visits['materialized_key_nodes'] != total['weight_nodes']) or meter.visits['materialized_string_bytes'] != total['weight_strings']:
        raise RuntimeError('internal expanded output accounting')
    return values[0]


def decode_ascii_json(nodes, root, limits, *, budget=None):
    """Return complete syntax JSON, explicit badwire, or no-value own budgetunknown."""
    meter, checked, weights = None, None, None
    normalized = None
    root_record = root if type(root) is int else None
    try:
        normalized = _limits(limits)
        _need(budget is None or callable(budget), 'BUDGET_CALLABLE')
        meter = _Meter(normalized, budget)
        meter.tick()
        checked = _heap(nodes, meter)  # All records, not just the reachable root.
        _need(type(root) is int and 257 <= root < 257 + len(checked), 'JSON_ROOT')
        recipes = _analyze(checked, root, meter)
        value = _materialize(checked, recipes, root, meter)
        weights = {'expanded_output_nodes': recipes[root]['weight_nodes'],
                   'expanded_string_bytes': recipes[root]['weight_strings'],
                   'value_depth': recipes[root]['height']}
        return {'schema': 'L-ASCII-tree-heap-JSON-decode-v1', 'status': 'DECODED',
                'reason': 'COMPLETE_ASCII_JSON', 'value': value, 'root': root_record,
                'limits': normalized, 'visits': dict(meter.visits), 'weights': weights, 'scope': SCOPE}
    except _Reject as error:
        status, reason = 'REJECTED', str(error)
    except _Limit as error:
        status, reason = 'UNKNOWN_BUDGET', str(error)
    return {'schema': 'L-ASCII-tree-heap-JSON-decode-v1', 'status': status,
            'reason': reason, 'value': None, 'root': root_record,
            'limits': normalized, 'visits': {} if meter is None else dict(meter.visits),
            'weights': None, 'scope': SCOPE}
