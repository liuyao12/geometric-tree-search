"""Owned one-child custody for the inert FOL/NTM component qualification.

Only a fresh reviewed authority may invoke this Source. Result body is opaque;
normal admission additionally requires authoritative observer exit zero and the
complete outer stdout/stderr association. Observation is not an OS hard quota.
"""
import argparse
import base64
import hashlib
import json
import math
import os
import pathlib
import re
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time
import traceback

VERSION = 'GCTS-FOL-NTM-COMPONENT-QUALIFICATION-OBSERVER-v3'
ROOT = pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
LIMITS = {'worker_seconds': 165, 'observer_seconds': 180, 'cleanup_seconds': 5, 'log_bytes': 1048576, 'body_bytes': 8388608, 'total_output_bytes': 33554432, 'max_output_files': 64, 'child_rss_bytes': 1073741824, 'fol_operations': 1000000, 'fol_depth': 256, 'fol_lines': 64, 'compiler_operations': 2000000, 'compiler_tiles': 20000, 'reference_operations': 1000000, 'reference_configurations': 10000, 'row_operations': 5000000, 'row_solutions': 10000, 'row_distinct': 10000}
SOURCE_PATHS = {'worker': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-C/component_qualification_worker_v3.py', 'observer': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-C/component_qualification_observer_v3.py', 'fol_checker': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent_fol_checker_v1.py', 'legacy': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/recovered-logical-Source-v1/logic.py', 'compiler': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L/finite_ntm_wang_compiler_v1.py', 'ntm_reference': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent_ntm_reference_v2.py', 'wang_rows': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/independent_wang_rows_v2.py'}
COMPONENT_PINS = {'fol_checker': (21560, '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'), 'legacy': (10808, '5e607e81c4231836e7c2f979f7f9673988e1c6326335dfb6cfc25a173169a011'), 'compiler': (13714, 'deac82e9d69a1744b8994d838ff06e011cca9be4bca5556dad691b40f08a77a6'), 'ntm_reference': (11372, '027cc36dc9324aeb2d95ad2b98302368ff3489e027a9f4160e4a23b40cf82dab'), 'wang_rows': (11094, '6f60cb27168f3ca9875164090a65772b0ec492449db10467ba95ff0a81800184')}
METADATA_PINS = {'fol_checker': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-fol-checker-complete-effective-public-ABI-v2.json', 'bytes': 11910, 'sha256': '3a5efc7c5702e42800d9b58c5befa7fcf3e517cbc05f3ca00ae6dc2258730e72'}, 'compiler': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L/finite-NTM-Wang-compiler-complete-public-ABI-v1.json', 'bytes': 9678, 'sha256': 'd13253482e25d8c44c769942a3b4c5aea4d8e8d25ff415e64cba51ffe03683b9'}, 'ntm_reference': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-NTM-reference-complete-effective-public-ABI-v3.json', 'bytes': 10580, 'sha256': 'e13fbab0917fa034952552d15898011d0f1436b5626baa970c69b06c735f8cf3'}, 'wang_rows': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/independent-Wang-rows-complete-Source-ABI-v2.json', 'bytes': 3685, 'sha256': 'b0f54d58ae7b5c38c03799ffbbb43b3f24854953c0748e927c540a9e1f94a0c1'}}
COHORT = 'AUTHORED-FOL40-NTM120-LAYERS0TO2-v1'
CONSUMED_MEANING = 'exclusive spent marker before the sole child launch; failures remain spent'
BOOTSTRAP = "import base64,hashlib,sys\nb=base64.b64decode(sys.argv[1],validate=True)\nif len(b)!=int(sys.argv[2]) or hashlib.sha256(b).hexdigest()!=sys.argv[3]: raise RuntimeError('authenticated worker bytes')\np=sys.argv[4]\nsys.argv=[p]+sys.argv[5:]\ng={'__name__':'__main__','__file__':p}\nexec(compile(b,p,'exec',dont_inherit=True),g,g)\n"
EXPECTED_CALLS = {'fol':40,'legacy':12,'compiler':10,'reference':128,'rows':127}
TAIL_BYTES = 65536


class CustodyFailure(Exception):
    pass


def require(condition, label):
    if not condition:
        raise CustodyFailure(label)


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact_fields(value, fields, label):
    require(type(value) is dict and all(type(k) is str for k in value) and set(value) == set(fields), label)


def rawref(path, raw):
    return {'path':str(path),'bytes':len(raw),'sha256':sha(raw)}


def safe_file(value):
    require(type(value) is str and pathlib.Path(value).is_absolute(), 'absolute path')
    p = pathlib.Path(value)
    require(str(p) == value and '..' not in p.parts, 'canonical path spelling')
    for q in (p,) + tuple(p.parents):
        require(not q.is_symlink(), 'symlink path')
    info = p.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'regular single-link file')
    return p


def read_ref(value, maximum=None):
    exact_fields(value, ('path','bytes','sha256'), 'rawref fields')
    require(type(value['bytes']) is int and value['bytes'] >= 0, 'rawref byte type')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None, 'rawref digest type')
    if maximum is not None:
        require(value['bytes'] <= maximum, 'rawref body bound')
    p = safe_file(value['path'])
    require(p.stat().st_size == value['bytes'], 'rawref stat bytes')
    raw = p.read_bytes()
    require(len(raw) == value['bytes'] and sha(raw) == value['sha256'], 'rawref complete byte identity')
    return raw


def raw_association(value, expected, label):
    exact_fields(value, ('path','bytes','sha256'), label+' rawref fields')
    require(type(value['path']) is str and type(value['bytes']) is int and value['bytes'] >= 0, label+' path/byte types')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None, label+' digest type')
    require(encode(value) == encode(expected), label+' type-exact canonical association')
    return read_ref(value,1048576)


def parse_json(raw):
    def pairs(items):
        result = {}
        for key,value in items:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value: (_ for _ in ()).throw(CustodyFailure('nonfinite JSON')))


def admin_json(path):
    p = safe_file(path)
    require(p.parent == ROOT/'root' and p.suffix == '.json' and not p.name.startswith('.'), 'administrative JSON location')
    require(p.stat().st_size <= 1048576, 'administrative metadata bound')
    raw = p.read_bytes()
    return parse_json(raw),rawref(p,raw)


def plan_read(path):
    plan,ref = admin_json(path)
    exact_fields(plan, ('schema','case_id','actual_dir','python','sources','metadata','limits','cohort'), 'plan fields')
    require(plan['schema'] == 'GCTS-FOL-NTM-component-once-plan-v2', 'plan schema')
    require(type(plan['case_id']) is str and re.fullmatch('[a-z0-9][a-z0-9_-]{0,63}',plan['case_id']) is not None, 'case ID')
    require(plan['actual_dir'] == str(ROOT/'actual'/plan['case_id']), 'owned exact actual path')
    require(encode(plan['python']) == encode(PYTHON), 'D90 runtime rawref')
    require(encode(plan['limits']) == encode(LIMITS) and plan['cohort'] == COHORT, 'fixed complete cohort and limits')
    exact_fields(plan['sources'], SOURCE_PATHS, 'seven Source roles')
    for role,path in SOURCE_PATHS.items():
        require(type(plan['sources'][role]) is dict and plan['sources'][role].get('path') == path, 'fixed Source path')
        if role in COMPONENT_PINS:
            size,digest = COMPONENT_PINS[role]
            require(plan['sources'][role].get('bytes') == size and plan['sources'][role].get('sha256') == digest, 'fixed five component Source pins')
    exact_fields(plan['metadata'], METADATA_PINS, 'four public ABI roles')
    require(encode(plan['metadata']) == encode(METADATA_PINS), 'current exact effective ABI pins')
    return plan,ref


def authority_validate(authority, plan, plan_ref):
    exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'authority exact six fields')
    raw_association(authority['plan'],plan_ref,'authority current plan')
    raw_association(authority['observer'],plan['sources']['observer'],'authority current observer')
    expected = {'schema':'Root-FOL-NTM-component-once-authority-v2','authorized':True,'uses':1,
                'case_id':plan['case_id'],'plan':plan_ref,'observer':plan['sources']['observer']}
    require(encode(authority) == encode(expected), 'whole current authority flags and typed fields')


def consumed_validate(consumed_ref, plan, plan_ref, authority_ref):
    require(consumed_ref['path'] == str(pathlib.Path(plan['actual_dir'])/'CONSUMED.json'), 'owned consumed path')
    consumed = parse_json(read_ref(consumed_ref,1048576))
    exact_fields(consumed, ('schema','uses','case_id','plan','authority','observer','meaning'), 'postchild consumed exact seven')
    raw_association(consumed['plan'],plan_ref,'postchild consumed plan')
    raw_association(consumed['observer'],plan['sources']['observer'],'postchild consumed observer')
    raw_association(consumed['authority'],authority_ref,'postchild consumed authority')
    authority_validate(parse_json(read_ref(authority_ref,1048576)),plan,plan_ref)
    expected = {'schema':'Root-FOL-NTM-component-once-consumed-v2','uses':1,'case_id':plan['case_id'],'plan':plan_ref,
                'authority':authority_ref,'observer':plan['sources']['observer'],'meaning':CONSUMED_MEANING}
    require(encode(consumed) == encode(expected), 'postchild whole typed consumed meaning/current bindings')


def guards(plan, plan_ref, authority_ref):
    retained = {role:read_ref(ref,1048576) for role,ref in plan['sources'].items()}
    for ref in plan['metadata'].values():
        read_ref(ref,1048576)
    read_ref(plan['python'],33554432)
    read_ref(plan_ref,1048576)
    read_ref(authority_ref,1048576)
    return retained


def write_bytes(directory, name, raw):
    require(len(raw) <= LIMITS['body_bytes'], 'observer per-body bound')
    path = directory/name
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    require(path.read_bytes() == raw, 'observer complete output readback')
    return rawref(path,raw)


def census(directory):
    result = []
    for path in sorted(directory.iterdir()):
        require(path.parent == directory and re.fullmatch('[A-Za-z0-9][A-Za-z0-9.-]*',path.name) is not None, 'owned output name')
        safe_file(str(path))
        info = path.stat()
        require(info.st_size <= LIMITS['body_bytes'], 'individual owned file bound')
        raw = path.read_bytes()
        require(len(raw) == info.st_size, 'output full-byte stat join')
        result.append(rawref(path,raw))
    require(len(result)+2 <= LIMITS['max_output_files'], 'owned plus two external outer-capture file count bound')
    require(sum(ref['bytes'] for ref in result)+LIMITS['log_bytes'] <= LIMITS['total_output_bytes'], 'owned bytes reserve one MiB for complete external outer captures')
    return result


def group_exists(pgid):
    try:
        os.killpg(pgid,0)
        return True
    except ProcessLookupError:
        return False


def group_signal(pgid, sig, events):
    try:
        os.killpg(pgid,sig)
        events.append({'signal':int(sig),'delivered':True})
    except ProcessLookupError:
        events.append({'signal':int(sig),'delivered':False,'reason':'already gone'})


def supervise(worker_raw, plan, plan_ref, started):
    argv = [PYTHON['path'],'-I','-S','-B','-c',BOOTSTRAP,base64.b64encode(worker_raw).decode('ascii'),str(len(worker_raw)),sha(worker_raw),
            SOURCE_PATHS['worker'],'--plan',plan_ref['path'],'--result',str(pathlib.Path(plan['actual_dir'])/'worker-result.json')]
    selector = None
    heads = {'stdout':bytearray(),'stderr':bytearray()}
    tails = {'stdout':bytearray(),'stderr':bytearray()}
    totals = {'stdout':0,'stderr':0}
    eof = {'stdout':False,'stderr':False}
    events, cleanup_errors = [], []
    fault = None
    supervisor_exception = None
    escalation = None
    reaped_at = None
    post_popen = None
    owned_wait_complete = False
    cleanup_deadline = None

    def capture(label, chunk):
        totals[label] += len(chunk)
        room = max(0,LIMITS['log_bytes']-sum(len(v) for v in heads.values()))
        heads[label].extend(chunk[:room])
        tails[label].extend(chunk)
        if len(tails[label]) > TAIL_BYTES:
            del tails[label][:-TAIL_BYTES]

    def send(sig):
        try:
            group_signal(process.pid,sig,events)
        except Exception as error:
            cleanup_errors.append({'site':'group signal','exception_type':type(error).__name__,'message':str(error)})
            try:
                process.kill()
            except ProcessLookupError:
                pass
            except Exception as fallback:
                cleanup_errors.append({'site':'owned child kill fallback','exception_type':type(fallback).__name__,'message':str(fallback)})

    process = subprocess.Popen(argv,cwd=plan['actual_dir'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        # Every post-Popen setup operation is inside this cleanup-protected scope.
        post_popen = time.monotonic()
        selector = selectors.DefaultSelector()
        for label,stream in [('stdout',process.stdout),('stderr',process.stderr)]:
            os.set_blocking(stream.fileno(),False)
            selector.register(stream,selectors.EVENT_READ,label)
        while True:
            now = time.monotonic()
            if fault is None and now-started > LIMITS['observer_seconds']:
                fault = 'OBSERVER_WALL_CEILING'
            if fault is None and sum(totals.values()) > LIMITS['log_bytes']:
                fault = 'COMBINED_LOG_OVERFLOW'
            if fault is not None and escalation is None:
                send(signal.SIGTERM)
                escalation = now
            if escalation is not None and now-escalation >= 1 and group_exists(process.pid):
                send(signal.SIGKILL)
            if escalation is not None and now-escalation > LIMITS['cleanup_seconds']:
                break
            for key,_ in selector.select(timeout=0.05):
                label = key.data
                try:
                    chunk = os.read(key.fileobj.fileno(),65536)
                except BlockingIOError:
                    continue
                if not chunk:
                    eof[label] = True
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                capture(label,chunk)
            code = process.poll()
            if code is not None and reaped_at is None:
                process.wait(timeout=LIMITS['cleanup_seconds'])
                owned_wait_complete = True
                reaped_at = time.monotonic()
                if group_exists(process.pid):
                    if fault is None:
                        fault = 'CHILD_DESCENDANT_GROUP_REMAINED'
                    send(signal.SIGTERM)
                    escalation = reaped_at
            if code is not None and not selector.get_map() and not group_exists(process.pid):
                break
            if reaped_at is not None and time.monotonic()-reaped_at > LIMITS['cleanup_seconds']:
                if fault is None:
                    fault = 'POST_REAP_DRAIN_OR_GROUP_CEILING'
                send(signal.SIGKILL)
                break
    except Exception as error:
        if fault is None:
            fault = 'SUPERVISOR_SETUP_OR_DRAIN_EXCEPTION'
        supervisor_exception = {'exception_type':type(error).__name__,'message':str(error)}
    finally:
        try:
            # This fallback does not depend on a successfully built selector.
            need_cleanup = process.poll() is None or not all(eof.values()) or group_exists(process.pid)
            if need_cleanup:
                send(signal.SIGTERM)
                cleanup_started = time.monotonic()
                cleanup_deadline = cleanup_started+LIMITS['cleanup_seconds']
                streams = []
                for label,stream in [('stdout',process.stdout),('stderr',process.stderr)]:
                    if stream is not None and not stream.closed:
                        try:
                            os.set_blocking(stream.fileno(),False)
                            streams.append((label,stream))
                        except Exception as error:
                            cleanup_errors.append({'site':'cleanup pipe nonblocking','stream':label,'exception_type':type(error).__name__,'message':str(error)})
                sent_kill = False
                while time.monotonic()-cleanup_started <= LIMITS['cleanup_seconds']:
                    if not sent_kill and time.monotonic()-cleanup_started >= 1:
                        send(signal.SIGKILL)
                        sent_kill = True
                    remaining = []
                    for label,stream in streams:
                        try:
                            chunk = os.read(stream.fileno(),65536)
                        except BlockingIOError:
                            remaining.append((label,stream))
                            continue
                        except Exception as error:
                            cleanup_errors.append({'site':'cleanup pipe drain','stream':label,'exception_type':type(error).__name__,'message':str(error)})
                            continue
                        if chunk:
                            capture(label,chunk)
                            remaining.append((label,stream))
                        else:
                            eof[label] = True
                            stream.close()
                    streams = remaining
                    if process.poll() is not None and not streams and not group_exists(process.pid):
                        break
                    time.sleep(0.01)
        finally:
            # Owned terminal wait is attempted even if cleanup/drain setup fails.
            try:
                try:
                    if process.poll() is None or group_exists(process.pid):
                        send(signal.SIGKILL)
                        try:
                            process.kill()
                        except ProcessLookupError:
                            pass
                except Exception as error:
                    cleanup_errors.append({'site':'final owned kill','exception_type':type(error).__name__,'message':str(error)})
                finally:
                    wait_seconds = LIMITS['cleanup_seconds'] if cleanup_deadline is None else max(0.0,cleanup_deadline-time.monotonic())
                    try:
                        process.wait(timeout=wait_seconds)
                        owned_wait_complete = True
                        if reaped_at is None:
                            reaped_at = time.monotonic()
                    except subprocess.TimeoutExpired:
                        owned_wait_complete = False
                        cleanup_errors.append({'site':'bounded final owned wait','reason':'TIMEOUT_UNCONFIRMED_REAPING','timeout_seconds':wait_seconds})
                        if fault is None:
                            fault = 'OWNED_WAIT_TIMEOUT_UNCONFIRMED'
                    except Exception as error:
                        owned_wait_complete = False
                        cleanup_errors.append({'site':'bounded final owned wait','exception_type':type(error).__name__,'message':str(error)})
                        if fault is None:
                            fault = 'OWNED_WAIT_ERROR_UNCONFIRMED'
            finally:
                for label,stream in [('stdout',process.stdout),('stderr',process.stderr)]:
                    if stream is not None and not stream.closed:
                        try:
                            stream.close()
                        except Exception as error:
                            cleanup_errors.append({'site':'pipe close','stream':label,'exception_type':type(error).__name__,'message':str(error)})
                if selector is not None:
                    try:
                        selector.close()
                    except Exception as error:
                        cleanup_errors.append({'site':'selector close','exception_type':type(error).__name__,'message':str(error)})
    try:
        process_group_gone = not group_exists(process.pid)
    except Exception as error:
        process_group_gone = False
        cleanup_errors.append({'site':'final group observation','exception_type':type(error).__name__,'message':str(error)})
    if cleanup_errors and fault is None:
        fault = 'OWNED_CLEANUP_ERRORS'
    return {'child_exit':process.returncode,'fault':fault,'supervisor_exception':supervisor_exception,'cleanup_errors':cleanup_errors,
            'cleanup_signals':events,'stream_totals':totals,'combined_log_overflow':sum(totals.values()) > LIMITS['log_bytes'],'log_eof':eof,
            'heads':{k:bytes(v) for k,v in heads.items()},'tails':{k:bytes(v) for k,v in tails.items()},
            'process_group_gone':process_group_gone,'owned_wait_complete':owned_wait_complete,'pid':process.pid,
            'post_Popen_return_to_owned_wait_seconds':None if post_popen is None or reaped_at is None else reaped_at-post_popen,
            'child_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss if owned_wait_complete else None,
            'launch_mode':'one D90 -I -S -B -c authenticated retained-byte bootstrap; no worker path reread for code execution'}


def verify_terminal(raw, plan, plan_ref):
    require(len(raw) <= LIMITS['log_bytes'], 'worker terminal/log bound')
    value = parse_json(raw)
    require(encode(value) == raw, 'exact complete canonical worker terminal bytes')
    exact_fields(value, ('schema','status','case_id','plan','result','public_calls','post_readback_costs','unmeasured_tail'), 'terminal exact eight fields')
    require(value['schema'] == 'GCTS-FOL-NTM-worker-terminal-v1' and value['status'] == 'COMPLETE_PASS_RESULT_WRITTEN', 'normal worker terminal')
    require(type(value['case_id']) is str and value['case_id'] == plan['case_id'], 'worker terminal case association')
    raw_association(value['plan'],plan_ref,'worker terminal current plan')
    require(encode(value['public_calls']) == encode(EXPECTED_CALLS), 'worker terminal complete public call census')
    require(value['result'].get('path') == str(pathlib.Path(plan['actual_dir'])/'worker-result.json'), 'fixed result association')
    read_ref(value['result'],LIMITS['body_bytes'])
    exact_fields(value['post_readback_costs'], ('elapsed_main_entry_seconds','self_lifetime_highwater_bytes','worker_budget_callbacks'), 'terminal cost fields')
    cost = value['post_readback_costs']
    require(type(cost['elapsed_main_entry_seconds']) is float and math.isfinite(cost['elapsed_main_entry_seconds']) and cost['elapsed_main_entry_seconds'] >= 0, 'worker post-readback finite elapsed')
    require(type(cost['self_lifetime_highwater_bytes']) is int and cost['self_lifetime_highwater_bytes'] >= 0, 'worker post-readback RSS type')
    require(type(cost['worker_budget_callbacks']) is int and cost['worker_budget_callbacks'] >= 1, 'worker budget counter type')
    require(type(value['unmeasured_tail']) is str, 'worker tail disclosure')
    return value


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan',required=True)
    parser.add_argument('--authority',required=True)
    args = parser.parse_args()
    directory = None
    directory_owned = False
    plan = None
    outcome = None
    captures = {}
    plan_ref = None
    authority_ref = None
    try:
        require(sys.executable == PYTHON['path'] and __file__ == SOURCE_PATHS['observer'], 'authenticated current runtime and Source address')
        require(sys.platform == 'darwin' and sys.version_info[:2] == (3,12), 'Darwin CPython observation')
        require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode, 'D90 isolation flags')
        plan,plan_ref = plan_read(args.plan)
        authority,authority_ref = admin_json(args.authority)
        authority_validate(authority,plan,plan_ref)
        retained = guards(plan,plan_ref,authority_ref)
        directory = pathlib.Path(plan['actual_dir'])
        require(not directory.exists(), 'actual directory absent before once')
        parent = directory.parent
        require(parent == ROOT/'actual' and not parent.is_symlink(), 'owned actual parent')
        parent.mkdir(exist_ok=True)
        directory.mkdir()
        directory_owned = True
        consume = {'schema':'Root-FOL-NTM-component-once-consumed-v2','uses':1,'case_id':plan['case_id'],'plan':plan_ref,'authority':authority_ref,
                   'observer':plan['sources']['observer'],'meaning':CONSUMED_MEANING}
        consumed_ref = write_bytes(directory,'CONSUMED.json',encode(consume))
        outcome = supervise(retained['worker'],plan,plan_ref,started)
        captures = {}
        for label in ('stdout','stderr'):
            captures[label] = write_bytes(directory,'worker-'+label+'.bin',outcome['heads'][label])
            captures[label+'_tail'] = write_bytes(directory,'worker-'+label+'-tail.bin',outcome['tails'][label])
        consumed_validate(consumed_ref,plan,plan_ref,authority_ref)
        public = {k:v for k,v in outcome.items() if k not in ('heads','tails')}
        require(outcome['fault'] is None and outcome['child_exit'] == 0, 'whole child failed or supervision fault: '+str(outcome['fault']))
        require(outcome['owned_wait_complete'] is True and all(outcome['log_eof'].values()) and outcome['process_group_gone'], 'complete EOF/confirmed owned wait/group gone')
        require(sum(outcome['stream_totals'].values()) <= LIMITS['log_bytes'], 'all logs bounded and complete')
        require(outcome['child_lifetime_highwater_bytes'] <= LIMITS['child_rss_bytes'], 'observed fresh only-child Darwin lifetime high-water ceiling')
        require(outcome['heads']['stderr'] == b'', 'normal worker stderr must be empty')
        terminal = verify_terminal(outcome['heads']['stdout'],plan,plan_ref)
        require(terminal['post_readback_costs']['self_lifetime_highwater_bytes'] <= outcome['child_lifetime_highwater_bytes'], 'worker SELF peak associated with parent child lifetime observation')
        require(time.monotonic()-started <= LIMITS['observer_seconds'], 'late whole observer window gate')
        guards(plan,plan_ref,authority_ref)
        read_ref(consumed_ref,1048576)
        before_receipt = census(directory)
        receipt = {'schema':'GCTS-FOL-NTM-owned-custody-v1','status':'NORMAL_TRANSPORT_CANDIDATE','version':VERSION,
                   'case_id':plan['case_id'],'plan':plan_ref,'authority':authority_ref,'consumed':consumed_ref,
                   'Source_and_runtime_pre_post_exact':True,'child':public,'captures':captures,'worker_terminal':terminal,
                   'result':terminal['result'],'all_prior_owned_files':before_receipt,
                   'late_costs':{'observer_main_entry_elapsed_seconds':time.monotonic()-started,'observer_self_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
                   'scopes':{'result':'opaque complete raw bytes, scientific COMPLETE_PASS originates only in the reviewed worker',
                             'RSS':'Darwin lifetime high-water for fresh observer only-child via waited RUSAGE_CHILDREN, not a hard RAM quota, simultaneous peak or process-tree accounting',
                             'time':'observer main entry includes preflight and Popen; imports before main excluded. Separately labeled post-Popen-return window omits an unknown startup portion; no cross-origin clock inequality',
                             'tail':'custody serialization/readback, final directory census, outer encoding/flush/shutdown remain after the late sample',
                             'admission':'requires this receipt, full matching outer stdout/stderr and authoritative observer exit zero; no one file self-admits'}}
        custody_ref = write_bytes(directory,'custody.json',encode(receipt))
        final_census = census(directory)
        read_ref(consumed_ref,1048576)
        require(time.monotonic()-started <= LIMITS['observer_seconds'], 'final observer wall gate')
        outer = {'schema':'GCTS-FOL-NTM-owned-outer-v1','status':'COMPLETE_NORMAL','case_id':plan['case_id'],
                 'custody':custody_ref,'admitted_result_candidate':terminal['result'],'owned_file_count':len(final_census),
                 'owned_named_bytes':sum(ref['bytes'] for ref in final_census),'requires_authoritative_exit_zero':True}
        sys.stdout.buffer.write(encode(outer)); sys.stdout.buffer.flush()
        return 0
    except Exception as error:
        if directory_owned and directory is not None and directory.is_dir():
            failure = {'schema':'GCTS-FOL-NTM-owned-failure-v1','status':'UNADMITTED','case_id':None if plan is None else plan['case_id'],
                       'exception_type':type(error).__name__,'message':str(error),'admitted_result':None,
                       'plan':plan_ref,'authority':authority_ref,'captures':captures,
                       'child':None if outcome is None else {k:v for k,v in outcome.items() if k not in ('heads','tails')},'spent':'exclusive CONSUMED marker remains if created'}
            try:
                write_bytes(directory,'observer-failure.json',encode(failure))
            except Exception:
                pass
        traceback.print_exc(file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
