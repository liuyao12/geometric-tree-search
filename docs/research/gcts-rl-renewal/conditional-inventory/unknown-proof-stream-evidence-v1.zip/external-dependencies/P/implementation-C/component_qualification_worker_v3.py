"""Inert authored-regression qualification worker; execution needs a fresh once.

This is not proof search, theorem discovery, PA membership, or a GCTS benchmark.
All fixture factories below are called only by the separately authorized main.
"""
import argparse
import hashlib
import itertools
import json
import os
import pathlib
import re
import resource
import stat
import sys
import time
import traceback

VERSION = 'GCTS-FOL-NTM-COMPONENT-QUALIFICATION-WORKER-v3'
ROOT = pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
LIMITS = {'worker_seconds': 165, 'observer_seconds': 180, 'cleanup_seconds': 5,
          'log_bytes': 1048576, 'body_bytes': 8388608, 'total_output_bytes': 33554432,
          'max_output_files': 64, 'child_rss_bytes': 1073741824,
          'fol_operations': 1000000, 'fol_depth': 256, 'fol_lines': 64,
          'compiler_operations': 2000000, 'compiler_tiles': 20000,
          'reference_operations': 1000000, 'reference_configurations': 10000,
          'row_operations': 5000000, 'row_solutions': 10000, 'row_distinct': 10000}
SOURCE_PATHS = {'worker': str(ROOT / 'implementation-C/component_qualification_worker_v3.py'),
                'observer': str(ROOT / 'implementation-C/component_qualification_observer_v3.py'),
                'fol_checker': str(ROOT / 'implementation-B/independent_fol_checker_v1.py'),
                'legacy': str(ROOT / 'root/recovered-logical-Source-v1/logic.py'),
                'compiler': str(ROOT / 'implementation-L/finite_ntm_wang_compiler_v1.py'),
                'ntm_reference': str(ROOT / 'implementation-B/independent_ntm_reference_v2.py'),
                'wang_rows': str(ROOT / 'root/independent_wang_rows_v2.py')}
# Only current B2/reference and Root-row2 are active; predecessors are never run.
COMPONENT_PINS = {'fol_checker': (21560, '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'),
                  'legacy': (10808, '5e607e81c4231836e7c2f979f7f9673988e1c6326335dfb6cfc25a173169a011'),
                  'compiler': (13714, 'deac82e9d69a1744b8994d838ff06e011cca9be4bca5556dad691b40f08a77a6'),
                  'ntm_reference': (11372, '027cc36dc9324aeb2d95ad2b98302368ff3489e027a9f4160e4a23b40cf82dab'),
                  'wang_rows': (11094, '6f60cb27168f3ca9875164090a65772b0ec492449db10467ba95ff0a81800184')}
METADATA_PINS = {'fol_checker': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-fol-checker-complete-effective-public-ABI-v2.json', 'bytes': 11910, 'sha256': '3a5efc7c5702e42800d9b58c5befa7fcf3e517cbc05f3ca00ae6dc2258730e72'}, 'compiler': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L/finite-NTM-Wang-compiler-complete-public-ABI-v1.json', 'bytes': 9678, 'sha256': 'd13253482e25d8c44c769942a3b4c5aea4d8e8d25ff415e64cba51ffe03683b9'}, 'ntm_reference': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B/independent-NTM-reference-complete-effective-public-ABI-v3.json', 'bytes': 10580, 'sha256': 'e13fbab0917fa034952552d15898011d0f1436b5626baa970c69b06c735f8cf3'}, 'wang_rows': {'path': '/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/independent-Wang-rows-complete-Source-ABI-v2.json', 'bytes': 3685, 'sha256': 'b0f54d58ae7b5c38c03799ffbbb43b3f24854953c0748e927c540a9e1f94a0c1'}}
COHORT = 'AUTHORED-FOL40-NTM120-LAYERS0TO2-v1'
CONSUMED_MEANING = 'exclusive spent marker before the sole child launch; failures remain spent'


class QualificationFailure(Exception):
    pass


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(condition, label):
    if not condition:
        raise QualificationFailure(label)


def exact_fields(value, fields, label):
    require(type(value) is dict and all(type(k) is str for k in value) and set(value) == set(fields), label)


def safe_file(value):
    require(type(value) is str and pathlib.Path(value).is_absolute(), 'absolute path')
    p = pathlib.Path(value)
    require(str(p) == value and '..' not in p.parts, 'canonical path spelling')
    for q in (p,) + tuple(p.parents):
        require(not q.is_symlink(), 'symlink path')
    info = p.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'regular single-link file')
    return p


def read_ref(value, maximum=None):
    exact_fields(value, ('path', 'bytes', 'sha256'), 'rawref fields')
    require(type(value['bytes']) is int and value['bytes'] >= 0, 'rawref byte type')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'rawref SHA')
    if maximum is not None:
        require(value['bytes'] <= maximum, 'rawref cap')
    p = safe_file(value['path'])
    require(p.stat().st_size == value['bytes'], 'rawref stat size')
    raw = p.read_bytes()
    require(len(raw) == value['bytes'] and sha(raw) == value['sha256'], 'rawref full body identity')
    return raw


def rawref(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def raw_association(value, expected, label):
    exact_fields(value, ('path','bytes','sha256'), label+' rawref fields')
    require(type(value['path']) is str and type(value['bytes']) is int and value['bytes'] >= 0, label+' path/byte types')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None, label+' digest type')
    require(encode(value) == encode(expected), label+' type-exact canonical association')
    return read_ref(value,1048576)


def parse_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(QualificationFailure('nonfinite JSON')))


def plan_read(path):
    p = safe_file(path)
    require(p.parent == ROOT / 'root' and p.suffix == '.json' and not p.name.startswith('.'), 'plan location')
    raw = p.read_bytes()
    require(len(raw) <= 1048576, 'plan cap')
    plan = parse_json(raw)
    exact_fields(plan, ('schema','case_id','actual_dir','python','sources','metadata','limits','cohort'), 'plan fields')
    require(plan['schema'] == 'GCTS-FOL-NTM-component-once-plan-v2', 'plan schema')
    require(type(plan['case_id']) is str and re.fullmatch('[a-z0-9][a-z0-9_-]{0,63}', plan['case_id']) is not None, 'case ID')
    require(plan['actual_dir'] == str(ROOT / 'actual' / plan['case_id']), 'actual directory')
    require(plan['python'] == PYTHON and type(plan['python']['bytes']) is int, 'D90 runtime')
    require(encode(plan['limits']) == encode(LIMITS) and plan['cohort'] == COHORT, 'fixed limits/cohort')
    exact_fields(plan['sources'], SOURCE_PATHS, 'source roles')
    for role, expected in SOURCE_PATHS.items():
        require(type(plan['sources'][role]) is dict and plan['sources'][role].get('path') == expected, 'source role path')
        if role in COMPONENT_PINS:
            size, digest = COMPONENT_PINS[role]
            require(plan['sources'][role].get('bytes') == size and plan['sources'][role].get('sha256') == digest, 'frozen component identity')
    exact_fields(plan['metadata'], METADATA_PINS, 'metadata roles')
    require(encode(plan['metadata']) == encode(METADATA_PINS), 'fixed effective public ABIs')
    return plan, rawref(p, raw)


def guard_read(plan, plan_ref, extra_refs=()):
    retained = {role: read_ref(ref, 1048576) for role, ref in plan['sources'].items()}
    for ref in plan['metadata'].values():
        read_ref(ref, 1048576)
    read_ref(plan['python'], 33554432)
    read_ref(plan_ref, 1048576)
    for ref in extra_refs:
        read_ref(ref,1048576)
    return retained


def consumed_read(plan, plan_ref, directory):
    path = safe_file(str(directory/'CONSUMED.json'))
    size = path.stat().st_size
    require(size <= 1048576, 'bounded once marker metadata')
    raw = path.read_bytes()
    require(len(raw) == size and len(raw) <= 1048576, 'whole bounded once marker')
    consumed_ref = rawref(path,raw)
    consumed = parse_json(raw)
    exact_fields(consumed, ('schema','uses','case_id','plan','authority','observer','meaning'), 'consumed exact seven fields')
    raw_association(consumed['plan'],plan_ref,'consumed current plan')
    raw_association(consumed['observer'],plan['sources']['observer'],'consumed current observer')
    authority_ref = consumed['authority']
    exact_fields(authority_ref, ('path','bytes','sha256'), 'current authority rawref fields')
    require(type(authority_ref['path']) is str, 'authority path type')
    authority_path = pathlib.Path(authority_ref['path'])
    require(authority_path.parent == ROOT/'root' and authority_path.suffix == '.json' and not authority_path.name.startswith('.'), 'current authority Root metadata location')
    authority_raw = read_ref(authority_ref,1048576)
    authority = parse_json(authority_raw)
    exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'current authority exact six fields')
    raw_association(authority['plan'],plan_ref,'authority current plan')
    raw_association(authority['observer'],plan['sources']['observer'],'authority current observer')
    expected_authority = {'schema':'Root-FOL-NTM-component-once-authority-v2','authorized':True,'uses':1,
                          'case_id':plan['case_id'],'plan':plan_ref,'observer':plan['sources']['observer']}
    require(encode(authority) == encode(expected_authority), 'whole current authority flags and typed fields')
    expected_consumed = {'schema':'Root-FOL-NTM-component-once-consumed-v2','uses':1,'case_id':plan['case_id'],
                         'plan':plan_ref,'authority':authority_ref,'observer':plan['sources']['observer'],'meaning':CONSUMED_MEANING}
    require(encode(consumed) == encode(expected_consumed), 'whole current consumed meaning and typed fields')
    return (authority_ref,consumed_ref)


def clone(value):
    if type(value) is dict:
        return {clone(k): clone(v) for k, v in value.items()}
    if type(value) is list:
        return [clone(v) for v in value]
    if type(value) is tuple:
        return tuple(clone(v) for v in value)
    require(value is None or type(value) in (str, int, bool, float), 'authored fixture primitive')
    return value


def typed_image(value):
    if type(value) is dict:
        return {'type': 'dict', 'items': [[typed_image(k), typed_image(v)] for k, v in value.items()]}
    if type(value) is list or type(value) is tuple:
        return {'type': type(value).__name__, 'items': [typed_image(v) for v in value]}
    require(value is None or type(value) in (str, int, bool, float), 'typed request primitive')
    return {'type': 'null' if value is None else type(value).__name__, 'value': value}


def nonnegative(value):
    return type(value) is int and value >= 0


def checked_return(role, value):
    """Public wire/cost gates only, never a call back into a component."""
    require(type(value) is dict and type(value.get('status')) is str, 'component result record/status')
    if role == 'fol':
        exact_fields(value, ('schema','status','reason','error_line','checked_lines','rule_counts','visits','limits','scope'), 'FOL receipt exact nine')
        require(value['schema'] == 'GCTS-independent-FOL-check-receipt-v1' and value['status'] in ('VERIFIED','REJECTED','UNKNOWN_BUDGET'), 'FOL schema/status')
        require(type(value['reason']) is str and type(value['scope']) is str and nonnegative(value['checked_lines']), 'FOL scalar receipt types')
        require(value['error_line'] is None or nonnegative(value['error_line']), 'FOL error line type')
        exact_fields(value['rule_counts'], ('axiom','tautology','refl','instantiate','distribute','eq_subst','mp','generalize'), 'FOL eight counters')
        require(all(nonnegative(x) for x in value['rule_counts'].values()), 'FOL rule counter types')
        exact_fields(value['visits'], ('operations','max_depth_seen','by_kind','tautology_atoms_max','tautology_assignments'), 'FOL visit fields')
        cost = value['visits']
        require(type(cost['by_kind']) is dict and all(type(k) is str and nonnegative(v) for k,v in cost['by_kind'].items()), 'FOL charged-kind types')
        require(all(nonnegative(cost[k]) for k in ('operations','max_depth_seen','tautology_atoms_max','tautology_assignments')) and sum(cost['by_kind'].values()) == cost['operations'], 'FOL counter arithmetic')
        if value['limits'] is not None:
            exact_fields(value['limits'], ('max_operations','max_depth','max_proof_lines'), 'FOL retained limit fields')
            require(all(type(x) is int and x > 0 for x in value['limits'].values()), 'FOL retained limit types')
    elif role == 'compiler':
        exact_fields(value, ('schema','version','status','machine','machine_sha256','limits','effective_transitions','glyphs','palette','witnesses','counts','reason'), 'compiler exact twelve')
        require(value['schema'] == 'L-finite-NTM-translation-Wang-compile-result-v1' and value['version'] == 'FINITE_NTM_TRANSLATION_WANG_COMPILER-v1', 'compiler schema/version')
        require(value['status'] in ('COMPLETE','REJECTED','UNKNOWN_BUDGET'), 'compiler status')
        require(type(value['counts']) is dict and type(value['counts']['complete_census']) is bool, 'compiler complete census bool')
        if value['status'] == 'COMPLETE':
            require(value['reason'] is None and value['counts']['complete_census'] is True, 'compiler whole completion')
            require(type(value['palette']) is list and type(value['witnesses']) is list and len(value['palette']) == len(value['witnesses']) == value['counts']['tiles_constructed'], 'compiler full palette/witness cardinality')
            require([t['id'] for t in value['palette']] == [w['tile_id'] for w in value['witnesses']], 'compiler witness associations')
            for phase in ('choose','exec'):
                counts = value['counts']
                require(counts[phase+'_triples_examined'] == counts[phase+'_triples_total'] == counts[phase+'_valid_triples']+sum(counts[phase+'_rejections'].values()), 'compiler complete triple census')
        else:
            require(value['counts']['complete_census'] is False and all(value[k] is None for k in ('effective_transitions','glyphs','palette','witnesses')), 'compiler noncomplete has no palette prefix')
    elif role == 'reference':
        exact_fields(value, ('schema','status','reason','input','limits','layers','partial_layer','complete','steps_completed','acceptance','counts','costs','scope'), 'reference exact thirteen')
        require(value['schema'] == 'GCTS-independent-finite-NTM-simulation-v2' and value['status'] in ('COMPLETE','REJECTED','UNKNOWN_BUDGET'), 'reference B2 schema/status')
        require(type(value['complete']) is bool and type(value['layers']) is list, 'reference complete/list types')
        exact_fields(value['acceptance'], ('ever','at_requested_step','witness'), 'reference acceptance fields')
        exact_fields(value['costs'], ('operations','by_kind'), 'reference cost fields')
        require(nonnegative(value['costs']['operations']) and type(value['costs']['by_kind']) is dict and all(nonnegative(x) for x in value['costs']['by_kind'].values()) and sum(value['costs']['by_kind'].values()) == value['costs']['operations'], 'reference cost arithmetic')
        if value['status'] == 'COMPLETE':
            require(value['complete'] is True and value['partial_layer'] is None and type(value['acceptance']['ever']) is bool and type(value['acceptance']['at_requested_step']) is bool, 'reference whole normal return')
        else:
            require(value['complete'] is False and all(value['acceptance'][k] is None for k in ('ever','at_requested_step','witness')), 'reference noncomplete acceptance withheld')
    elif role == 'rows':
        fields = ('schema','status','layers','accepts','counts','reason','scope') if value['status'] == 'COMPLETE' else ('schema','status','layers','accepts','counts','reason')
        exact_fields(value, fields, 'row exact normal/noncomplete fields')
        require(value['schema'] == 'Root-independent-Wang-rows-v2' and value['status'] in ('COMPLETE','REJECTED','UNKNOWN_BUDGET'), 'Root rows2 schema/status')
        exact_fields(value['counts'], ('operations','palette_tiles','candidate_trials','row_solutions','halfsteps','distinct_rows'), 'row counts fields')
        require(all(nonnegative(x) for x in value['counts'].values()), 'row exact integer counts')
        if value['status'] == 'COMPLETE':
            require(type(value['layers']) is list and type(value['accepts']) is bool and value['reason'] is None, 'row complete fields')
        else:
            require(value['layers'] is None and value['accepts'] is None, 'row noncomplete no scientific prefix')
    else:
        raise QualificationFailure('unrecognized component return role')


def legacy_ast(value):
    if type(value) is list:
        return tuple(legacy_ast(v) for v in value)
    if type(value) is dict:
        return {k: legacy_ast(v) for k, v in value.items()}
    return value


class Run:
    def __init__(self, plan, plan_ref, started):
        self.plan, self.plan_ref, self.started = plan, plan_ref, started
        self.directory = pathlib.Path(plan['actual_dir'])
        self.callbacks = 0
        self.files = []
        self.current = None
        self.calls = {'fol':0,'legacy':0,'compiler':0,'reference':0,'rows':0}

    def budget(self):
        self.callbacks += 1
        require(time.monotonic() - self.started <= LIMITS['worker_seconds'], 'worker cooperative time ceiling')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= LIMITS['child_rss_bytes'], 'worker cooperative Darwin SELF high-water ceiling')

    def save(self, name, value):
        self.budget()
        require(type(name) is str and re.fullmatch('[a-z0-9][a-z0-9.-]*', name) is not None, 'output basename')
        raw = encode(value)
        require(len(raw) <= LIMITS['body_bytes'], 'per-body output ceiling')
        path = self.directory / name
        prior = list(self.directory.iterdir())
        require(len(prior) + 1 <= LIMITS['max_output_files'] - 8, 'worker reserves eight observer files')
        require(sum(p.stat().st_size for p in prior) + len(raw) <= LIMITS['total_output_bytes'] - 3*LIMITS['log_bytes'], 'worker reserves three MiB for observer and outer transport')
        with path.open('xb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        require(path.read_bytes() == raw, 'whole output readback')
        self.files.append(rawref(path, raw))
        files = list(self.directory.iterdir())
        require(len(files) <= LIMITS['max_output_files'], 'named output count ceiling')
        require(sum(p.stat().st_size for p in files) <= LIMITS['total_output_bytes'], 'named output byte ceiling')
        self.budget()
        return self.files[-1]

    def call(self, role, function, args):
        self.budget()
        before = encode(typed_image(args))
        result = function(*args)
        self.calls[role] += 1
        after = encode(typed_image(args))
        require(before == after, 'component caller-input mutation: ' + role)
        frozen = parse_json(encode(result))
        if self.current is not None:
            self.current['last_component_return'] = {'role':role,'return':frozen}
        checked_return(role,frozen)
        self.budget()
        return {'request_typed': parse_json(before), 'request_typed_sha256': sha(before),
                'return': frozen, 'return_sha256': sha(encode(frozen)), 'input_unchanged': True}


def fol_controls():
    """Forty authored certificates/data negatives; no search or external proof."""
    v = lambda x: ['var',x]
    a, b = ['fun','a',[]], ['fun','b',[]]
    P = lambda x: ['pred','P',[x]]
    R = lambda x,y: ['pred','R',[x,y]]
    A, B = ['pred','A',[]], ['pred','B',[]]
    eq = lambda x,y: ['eq',x,y]
    imp = lambda x,y: ['imp',x,y]
    all_ = lambda x,y: ['all',x,y]
    theory = {'functions': {'a':0,'b':0,'f':1,'cλ':0}, 'predicates': {'P':1,'R':2,'A':0,'B':0}, 'axioms': {}}
    limits = {'max_operations':LIMITS['fol_operations'],'max_depth':LIMITS['fol_depth'],'max_proof_lines':LIMITS['fol_lines']}
    cases = []
    def add(number, label, proof, target, status='VERIFIED', axioms=None, legacy=False, changed_limits=None, changed_theory=None):
        t = clone(theory if changed_theory is None else changed_theory)
        if axioms is not None:
            t['axioms'] = clone(axioms)
        cases.append({'id':'F%02d'%number,'label':label,'request': [t,proof,target,clone(limits if changed_limits is None else changed_limits)], 'expected_status':status,'legacy_compatible':legacy})
    add(1,'open reflexivity',[{'rule':'refl','formula':eq(v('x'),v('x'))}],eq(v('x'),v('x')),legacy=True)
    fa = ['fun','f',[a]]
    add(2,'nested ground reflexivity',[{'rule':'refl','formula':eq(fa,fa)}],eq(fa,fa),legacy=True)
    taut = ['or',P(v('x')),['not',P(v('x'))]]
    add(3,'classical excluded middle',[{'rule':'tautology','formula':taut}],taut,legacy=True)
    taut = imp(['bot'],A)
    add(4,'bottom implication',[{'rule':'tautology','formula':taut}],taut,legacy=True)
    u = all_('x',P(v('x')))
    add(5,'closed named axiom',[{'rule':'axiom','name':'u','formula':u}],u,axioms={'u':u},legacy=True)
    add(6,'strict-prior modus ponens',[{'rule':'axiom','name':'a','formula':A},{'rule':'axiom','name':'i','formula':imp(A,B)},{'rule':'mp','antecedent':0,'implication':1,'formula':B}],B,axioms={'a':A,'i':imp(A,B)},legacy=True)
    add(7,'generalize relative to closed axiom',[{'rule':'axiom','name':'a','formula':A},{'rule':'generalize','source':0,'variable':'x','formula':all_('x',A)}],all_('x',A),axioms={'a':A},legacy=True)
    u = all_('x',all_('y',R(v('x'),v('y'))))
    capture = imp(u,all_('z',R(v('y'),v('z'))))
    add(8,'capture-free alpha-renamed instantiation',[{'rule':'instantiate','universal':u,'term':v('y'),'formula':capture}],capture)
    u = all_('x',all_('x',P(v('x'))))
    form = imp(u,all_('x',P(v('x'))))
    add(9,'shadowed instantiation binder',[{'rule':'instantiate','universal':u,'term':a,'formula':form}],form,legacy=True)
    form = imp(all_('x',imp(A,P(v('x')))),imp(A,all_('x',P(v('x')))))
    add(10,'distribution with freshness',[{'rule':'distribute','variable':'x','antecedent':A,'consequent':P(v('x')),'formula':form}],form,legacy=True)
    template = all_('y',R(v('x'),v('y')))
    form = imp(eq(v('y'),a),imp(all_('z',R(v('y'),v('z'))),all_('y',R(a,v('y')))))
    add(11,'hygienic equality substitution',[{'rule':'eq_subst','variable':'x','template':template,'left':v('y'),'right':a,'formula':form}],form)
    u, renamed = all_('x',P(v('x'))), all_('z',P(v('z')))
    add(12,'bound alpha axiom matching',[{'rule':'axiom','name':'u','formula':renamed}],renamed,axioms={'u':u})
    reflex = eq(v('x'),v('x'))
    add(13,'generalization of open logical validity',[{'rule':'refl','formula':reflex},{'rule':'generalize','source':0,'variable':'x','formula':all_('x',reflex)}],all_('x',reflex),legacy=True)
    literal = ['fun','cλ',[]]
    add(14,'literal Unicode identifier',[{'rule':'refl','formula':eq(literal,literal)}],eq(literal,literal),legacy=True)
    form = imp(u,renamed)
    add(15,'alpha-equivalent quantified tautology atoms',[{'rule':'tautology','formula':form}],form)
    template = all_('x',P(v('x')))
    form = imp(eq(a,b),imp(template,template))
    add(16,'shadowed equality substitution',[{'rule':'eq_subst','variable':'x','template':template,'left':a,'right':b,'formula':form}],form,legacy=True)
    u = all_('x',all_('y',R(v('x'),v('y'))))
    wrong = imp(u,all_('y',R(v('y'),v('y'))))
    add(17,'reject captured instantiation',[{'rule':'instantiate','universal':u,'term':v('y'),'formula':wrong}],wrong,'REJECTED')
    wrong = all_('x',P(v('y')))
    add(18,'free name is not bound alpha',[{'rule':'axiom','name':'u','formula':wrong}],wrong,'REJECTED',axioms={'u':all_('x',P(v('x')))})
    form = imp(all_('x',imp(P(v('x')),A)),imp(P(v('x')),all_('x',A)))
    add(19,'distribution eigen-freshness violation',[{'rule':'distribute','variable':'x','antecedent':P(v('x')),'consequent':A,'formula':form}],form,'REJECTED')
    add(20,'open theory axiom refused',[{'rule':'refl','formula':eq(a,a)}],eq(a,a),'REJECTED',axioms={'open':P(v('x'))})
    form = all_('x',reflex)
    add(21,'generalization wrong free/bound result',[{'rule':'refl','formula':reflex},{'rule':'generalize','source':0,'variable':'y','formula':form}],form,'REJECTED')
    add(22,'false propositional atom',[{'rule':'tautology','formula':A}],A,'REJECTED')
    add(23,'nonreflexive equality',[{'rule':'refl','formula':eq(a,b)}],eq(a,b),'REJECTED')
    add(24,'wrong MP antecedent',[{'rule':'axiom','name':'a','formula':A},{'rule':'axiom','name':'i','formula':imp(B,B)},{'rule':'mp','antecedent':0,'implication':1,'formula':B}],B,'REJECTED',axioms={'a':A,'i':imp(B,B)})
    add(25,'future reference',[{'rule':'mp','antecedent':1,'implication':0,'formula':A}],A,'REJECTED')
    add(26,'bool is not proof reference',[{'rule':'axiom','name':'a','formula':A},{'rule':'mp','antecedent':False,'implication':0,'formula':A}],A,'REJECTED',axioms={'a':A})
    add(27,'unknown rule',[{'rule':'assume','formula':A}],A,'REJECTED')
    add(28,'extra proof field',[{'rule':'refl','formula':eq(a,a),'extra':0}],eq(a,a),'REJECTED')
    bad = clone(theory); bad['functions']['a'] = True
    add(29,'bool signature arity',[{'rule':'refl','formula':eq(a,a)}],eq(a,a),'REJECTED',changed_theory=bad)
    wrong = ['fun','f',[]]
    add(30,'wrong function arity',[{'rule':'refl','formula':eq(wrong,wrong)}],eq(wrong,wrong),'REJECTED')
    wrong = ['pred','UNDECLARED',[]]
    add(31,'undeclared predicate',[{'rule':'tautology','formula':imp(wrong,wrong)}],imp(wrong,wrong),'REJECTED')
    wrong = ('eq',a,a)
    add(32,'tuple is not wire formula',[{'rule':'refl','formula':wrong}],eq(a,a),'REJECTED')
    wrong = ['var','']
    add(33,'empty FOL identifier',[{'rule':'refl','formula':eq(wrong,wrong)}],eq(a,a),'REJECTED')
    add(34,'unknown named axiom',[{'rule':'axiom','name':'missing','formula':A}],A,'REJECTED')
    add(35,'final target mismatch',[{'rule':'refl','formula':eq(a,a)}],eq(b,b),'REJECTED')
    badlim = clone(limits); badlim['max_operations'] = True
    add(36,'bool limit invalid',[{'rule':'refl','formula':eq(a,a)}],eq(a,a),'REJECTED',changed_limits=badlim)
    badlim = clone(limits); badlim['max_depth'] = 1
    add(37,'depth refusal is UNKNOWN',[{'rule':'refl','formula':eq(fa,fa)}],eq(fa,fa),'UNKNOWN_BUDGET',changed_limits=badlim)
    badlim = clone(limits); badlim['max_operations'] = 1
    add(38,'operation refusal is UNKNOWN',[{'rule':'refl','formula':eq(a,a)}],eq(a,a),'UNKNOWN_BUDGET',changed_limits=badlim)
    badlim = clone(limits); badlim['max_proof_lines'] = 1
    add(39,'proof-line refusal is UNKNOWN',[{'rule':'refl','formula':eq(a,a)},{'rule':'refl','formula':eq(a,a)}],eq(a,a),'UNKNOWN_BUDGET',changed_limits=badlim)
    large = ['bot']
    for index in range(24):
        atom = ['eq',['var','p'+str(index)],['fun','a',[]]]
        large = ['and',['or',atom,['not',clone(atom)]],large] if index else ['or',atom,['not',clone(atom)]]
    badlim = clone(limits); badlim['max_operations'] = 10000
    add(40,'unfinished Boolean enumeration is UNKNOWN',[{'rule':'tautology','formula':large}],large,'UNKNOWN_BUDGET',changed_limits=badlim)
    require(len(cases) == 40, 'FOL census')
    return cases


def fixed_machines():
    first = {'states':['q0','qA','qH'],'alphabet':['0','1'],'start':'q0','accept':['qA'],
             'transitions':[['q0','0','qA','1',-1],['q0','0','qH','0',1],['q0','1','qA','1',-1],['q0','1','qH','0',1]]}
    second = {'states':['','qA'],'alphabet':['0','["wall"]'],'start':'','accept':['qA'],
              'transitions':[['','0','qA','["wall"]',0],['','["wall"]','qA','0',0],['qA','0','qA','0',0],['qA','["wall"]','qA','["wall"]',0]]}
    return [('LEFT_ACCEPT_RIGHT_HALT',first,72),('STAY_NAMESPACE_SMOKE',second,48)]


def fol_run(run, libraries):
    rows = []
    for case in fol_controls():
        run.current = {'stage':'FOL','case':case}
        record = run.call('fol',libraries['fol_checker']['check'],clone(case['request']))
        run.current['record'] = record
        require(record['return']['status'] == case['expected_status'], 'FOL unexpected status '+case['id'])
        legacy = None
        if case['legacy_compatible']:
            theory, proof, target, _ = clone(case['request'])
            args = [legacy_ast(theory['functions']),legacy_ast(theory['predicates']),legacy_ast(theory['axioms'])]
            adapted, adapted_target = legacy_ast(proof), legacy_ast(target)
            legacy_request = [args,adapted,adapted_target]
            before = encode(typed_image(legacy_request))
            run.budget()
            kernel = libraries['legacy']['Kernel'](*args)
            # Proof is an ordered sequence; tuple/list outer container is compatible.
            legacy = kernel.check(adapted,adapted_target)
            run.budget()
            run.calls['legacy'] += 1
            require(type(legacy) is bool and legacy is True, 'declared compatible legacy control')
            require(encode(typed_image(legacy_request)) == before, 'legacy input mutation')
            record['legacy_request_typed'] = parse_json(before)
            record['legacy_request_typed_sha256'] = sha(before)
            record['legacy_input_unchanged'] = True
            record['legacy_return'] = legacy
        rows.append({'id':case['id'],'label':case['label'],'expected_status':case['expected_status'],
                     'legacy_compatible':case['legacy_compatible'],'evidence':record})
    require(len(rows) == 40 and run.calls['legacy'] == 12, 'FOL complete census')
    return run.save('fol-controls.json',{'schema':'C-authored-FOL-controls-v1','controls':rows,'scope':'Authored regression certificates, never searched proofs.'})


def literal_wire(value):
    return json.dumps(value,ensure_ascii=True,separators=(',',':'),allow_nan=False)


def seed_row(initial):
    return [['wall']] + [(['normalHead',initial['state'],symbol] if i == initial['head'] else ['plain',symbol]) for i,symbol in enumerate(initial['tape'])] + [['wall']]


def decode_normal(row, machine):
    require(row[0] == ['wall'] and row[-1] == ['wall'], 'grid fixed walls')
    heads, tape = [], []
    for index, glyph in enumerate(row[1:-1]):
        require(type(glyph) is list and glyph, 'grid glyph')
        if glyph[0] == 'plain':
            require(len(glyph) == 2 and glyph[1] in machine['alphabet'], 'grid plain symbol')
            tape.append(glyph[1])
        else:
            require(len(glyph) == 3 and glyph[0] == 'normalHead' and glyph[1] in machine['states'] and glyph[2] in machine['alphabet'], 'grid normal head')
            heads.append((glyph[1],index)); tape.append(glyph[2])
    require(len(heads) == 1, 'grid exactly one head')
    return {'state':heads[0][0],'head':heads[0][1],'tape':tape}


def verify_grids(machine, compiled, initial, result):
    palette = {tile['id']: tile for tile in compiled['palette']}
    require(len(palette) == len(compiled['palette']), 'palette ID uniqueness')
    for layer in result['layers']:
        require(len(layer['witnesses']) == len(layer['configurations']), 'one full grid witness per configuration')
        require(encode([w['configuration'] for w in layer['witnesses']]) == encode(layer['configurations']), 'witness/config ordering association')
        for witness in layer['witnesses']:
            current = seed_row(initial)
            require(len(witness['tile_rows']) == 2*layer['step'], 'full halfstep grid height')
            for halfstep, ids in enumerate(witness['tile_rows']):
                phase = 'CHOOSE' if halfstep % 2 == 0 else 'EXEC'
                other = 'EXEC' if phase == 'CHOOSE' else 'CHOOSE'
                require(len(ids) == len(current), 'full grid width including two walls')
                west = literal_wire(['H',phase,['wall'],['wall']])
                output = []
                for column, ident in enumerate(ids):
                    require(ident in palette, 'foreign tile ID')
                    tile = palette[ident]
                    require(tile['N'] == literal_wire(['V',phase,current[column]]) and tile['W'] == west, 'literal north/west seams')
                    south = json.loads(tile['S'])
                    require(type(south) is list and len(south) == 3 and south[:2] == ['V',other], 'literal south phase')
                    output.append(south[2]); west = tile['E']
                require(west == literal_wire(['H',phase,['wall'],['wall']]), 'literal right ghost seam')
                require(output[0] == ['wall'] and output[-1] == ['wall'], 'wall coherence at each halfstep')
                current = output
            require(encode(decode_normal(current,machine)) == encode(witness['configuration']), 'full tile grid decodes to associated global configuration')


def compare_layers(machine, compiled, initial, reference, rows):
    require(reference['status'] == 'COMPLETE' and reference['complete'] is True, 'reference complete return')
    require(rows['status'] == 'COMPLETE', 'row enumeration complete return')
    require([x['step'] for x in reference['layers']] == [0,1,2] == [x['step'] for x in rows['layers']], 'all exact layers zero through two')
    for left, right in zip(reference['layers'],rows['layers']):
        require(encode(left['configurations']) == encode(right['configurations']), 'whole reachable configuration-set equality')
        require(type(left['count']) is int and left['count'] == len(right['configurations']), 'reference layer count')
        count = sum(1 for config in right['configurations'] if config['state'] in machine['accept'])
        require(type(left['accepting_count']) is int and left['accepting_count'] == count, 'per-layer accepting count')
    require(type(rows['accepts']) is bool and rows['accepts'] is reference['acceptance']['at_requested_step'], 'exact-step acceptance equality')
    require(type(reference['acceptance']['ever']) is bool and reference['acceptance']['ever'] is reference['acceptance']['at_requested_step'], 'absorbing accept ever/exact agreement')
    verify_grids(machine,compiled,initial,rows)


def ntm_run(run, libraries):
    compiler_limits = {'max_operations':LIMITS['compiler_operations'],'max_tiles':LIMITS['compiler_tiles']}
    reference_limits = {'max_operations':LIMITS['reference_operations'],'max_configurations':LIMITS['reference_configurations']}
    row_limits = {'max_operations':LIMITS['row_operations'],'max_row_solutions':LIMITS['row_solutions'],'max_distinct_rows':LIMITS['row_distinct']}
    compiled_all = []
    context_total = 0
    context_refs = []
    halted_baseline = None
    for machine_index, (label,machine,expected_count) in enumerate(fixed_machines()):
        run.current = {'stage':'COMPILE','machine':machine}
        compiled_record = run.call('compiler',libraries['compiler']['compile_palette'],[clone(machine),clone(compiler_limits)])
        compiled = compiled_record['return']
        require(compiled['status'] == 'COMPLETE' and compiled['counts']['complete_census'] is True, 'full palette compilation')
        if machine_index == 1:
            identities = [row for row in compiled['effective_transitions'] if row['q'] == 'qA']
            require(compiled['counts']['implicit_absorbing_transitions'] == 2 and len(identities) == 2, 'compiler supplies exactly two implicit accepting identities')
            require(all(row['next'] == 'qA' and row['read'] == row['write'] and type(row['move']) is int and row['move'] == 0 for row in identities) and sorted(row['read'] for row in identities) == sorted(machine['alphabet']), 'compiler effective accepting-identity semantics')
        compiled_ref = run.save('palette-%d.json'%machine_index,{'label':label,'evidence':compiled_record})
        compiled_all.append((machine,compiled,compiled_ref))
        pending = []
        local_count = 0
        for state in machine['states']:
            for head in range(3):
                for tape in itertools.product(machine['alphabet'],repeat=3):
                    initial = {'state':state,'head':head,'tape':list(tape)}
                    current = {'stage':'NTM','machine':machine_index,'initial':initial}
                    run.current = current
                    ref = run.call('reference',libraries['ntm_reference']['simulate'],[clone(machine),clone(initial),2,clone(reference_limits)])
                    # The full shared compiled input is retained ONCE by raw reference.
                    args = [clone(machine),clone(compiled),clone(initial),2,clone(row_limits)]
                    before = sha(encode(args))
                    run.budget()
                    row_return = libraries['wang_rows']['enumerate_tableaux'](*args)
                    run.calls['rows'] += 1
                    require(sha(encode(args)) == before, 'row enumerator input mutation')
                    rows = parse_json(encode(row_return))
                    checked_return('rows',rows)
                    row_record = {'request':{'machine':clone(machine),'compiled_artifact':compiled_ref,'compiled_return_sha256':compiled_record['return_sha256'],'initial':clone(initial),'steps':2,'limits':clone(row_limits)},
                                  'resolved_full_request_sha256':before,'return':rows,'return_sha256':sha(encode(rows)),'input_unchanged':True}
                    current.update({'reference':ref,'rows':row_record})
                    compare_layers(machine,compiled,initial,ref['return'],rows)
                    if machine_index == 1:
                        require(ref['return']['counts']['folded_accept_identities'] == 2, 'explicit accepting identities folded without duplicate successors')
                    if machine_index == 0 and initial == {'state':'qH','head':0,'tape':['0','0','0']}:
                        halted_baseline = {'context':context_total,'initial':clone(initial),'return':clone(rows),'return_sha256':sha(encode(rows))}
                    pending.append({'context':context_total,'machine':machine_index,'initial':initial,'reference':ref,'rows':row_record,'all_layers_and_literal_witnesses_match':True})
                    context_total += 1; local_count += 1
                    run.budget()
                    if len(pending) == 20:
                        context_refs.append(run.save('ntm-contexts-%03d.json'%(context_total-20),{'schema':'C-complete-NTM-context-block-v1','contexts':pending}))
                        pending = []
        if pending:
            context_refs.append(run.save('ntm-contexts-%03d.json'%(context_total-len(pending)),{'schema':'C-complete-NTM-context-block-v1','contexts':pending}))
        require(local_count == expected_count, 'per-machine full initial-context census')
    require(context_total == 120, 'all 120 contexts')
    require(halted_baseline is not None, 'closed adaptive halted-row baseline retained')
    return compiled_all, context_refs, halted_baseline


def row_control_call(run, libraries, machine, compiled, compiled_ref, initial, steps, limits):
    args = [clone(machine),clone(compiled),clone(initial),steps,clone(limits)]
    before = sha(encode(args))
    run.budget()
    result = libraries['wang_rows']['enumerate_tableaux'](*args)
    run.calls['rows'] += 1
    require(sha(encode(args)) == before, 'row control input mutation')
    frozen = parse_json(encode(result))
    checked_return('rows',frozen)
    run.budget()
    return {'request':{'machine':clone(machine),'compiled_artifact':compiled_ref,'compiled_return_sha256':sha(encode(compiled)),'initial':clone(initial),'steps':steps,'limits':clone(limits)},
            'resolved_full_request_sha256':before,'return':frozen,'return_sha256':sha(encode(frozen)),'input_unchanged':True}


def ntm_controls(run, libraries, compiled_all, halted_baseline):
    machine, compiled, shared_ref = compiled_all[0]
    limits_c = {'max_operations':LIMITS['compiler_operations'],'max_tiles':LIMITS['compiler_tiles']}
    limits_r = {'max_operations':LIMITS['reference_operations'],'max_configurations':LIMITS['reference_configurations']}
    limits_w = {'max_operations':LIMITS['row_operations'],'max_row_solutions':LIMITS['row_solutions'],'max_distinct_rows':LIMITS['row_distinct']}
    initial = {'state':'q0','head':0,'tape':['0','0','0']}
    records = []
    invalids = []
    bad = clone(machine); bad['extra'] = 0; invalids.append(('N01-extra-field',bad))
    bad = clone(machine); bad['transitions'].append(clone(bad['transitions'][0])); invalids.append(('N02-duplicate-transition',bad))
    bad = clone(machine); bad['transitions'][0][4] = True; invalids.append(('N03-bool-move',bad))
    bad = clone(machine); bad['transitions'].append(['qA','0','q0','0',0]); invalids.append(('N04-conflicting-accept-outgoing',bad))
    bad = clone(machine); bad['accept'].append('qA'); invalids.append(('N05-duplicate-accept',bad))
    bad = clone(machine); bad['accept'] = ['foreign']; invalids.append(('N06-foreign-accept',bad))
    for ident, bad in invalids:
        run.current = {'stage':'NTM_CONTROL','id':ident}
        left = run.call('compiler',libraries['compiler']['compile_palette'],[clone(bad),clone(limits_c)])
        right = run.call('reference',libraries['ntm_reference']['simulate'],[clone(bad),clone(initial),2,clone(limits_r)])
        require(left['return']['status'] == 'REJECTED' and right['return']['status'] == 'REJECTED', 'explicit malformed machine refusal '+ident)
        records.append({'id':ident,'compiler':left,'reference':right,'expected_status':'REJECTED'})
    for ident, changed in [('C01-zero-operations',{'max_operations':0,'max_tiles':LIMITS['compiler_tiles']}),('C02-zero-tiles',{'max_operations':LIMITS['compiler_operations'],'max_tiles':0})]:
        record = run.call('compiler',libraries['compiler']['compile_palette'],[clone(machine),changed])
        require(record['return']['status'] == 'UNKNOWN_BUDGET' and record['return']['palette'] is None, 'compiler resource refusal has no palette')
        records.append({'id':ident,'evidence':record,'expected_status':'UNKNOWN_BUDGET'})
    for ident, changed in [('R01-operation-cap',{'max_operations':1,'max_configurations':LIMITS['reference_configurations']}),('R02-configuration-cap',{'max_operations':LIMITS['reference_operations'],'max_configurations':1})]:
        record = run.call('reference',libraries['ntm_reference']['simulate'],[clone(machine),clone(initial),2,changed])
        require(record['return']['status'] == 'UNKNOWN_BUDGET' and record['return']['complete'] is False and record['return']['acceptance']['ever'] is None, 'reference unknown is not acceptance')
        records.append({'id':ident,'evidence':record,'expected_status':'UNKNOWN_BUDGET'})
    for ident, changed in [('W01-operation-cap',{'max_operations':0,'max_row_solutions':10000,'max_distinct_rows':10000}),('W02-row-cap',{'max_operations':5000000,'max_row_solutions':0,'max_distinct_rows':10000})]:
        record = row_control_call(run,libraries,machine,compiled,shared_ref,initial,2,changed)
        require(record['return']['status'] == 'UNKNOWN_BUDGET' and record['return']['layers'] is None and record['return']['accepts'] is None, 'row unknown has no complete prefix')
        records.append({'id':ident,'evidence':record,'expected_status':'UNKNOWN_BUDGET'})
    phase_bad = clone(compiled)
    south = json.loads(phase_bad['palette'][0]['S']); south[1] = 'CHOOSE' if south[1] == 'EXEC' else 'EXEC'
    phase_bad['palette'][0]['S'] = literal_wire(south)
    phase_ref = run.save('palette-phase-mutant.json',{'compiled':phase_bad,'parent':shared_ref,'authored_mutation':'flip one south phase, preserving tile ID'})
    record = row_control_call(run,libraries,machine,phase_bad,phase_ref,initial,2,limits_w)
    require(record['return']['status'] == 'REJECTED', 'incoherent phase/color rejected')
    records.append({'id':'W03-phase-coherence','evidence':record,'expected_status':'REJECTED'})
    wall_bad = clone(compiled)
    found = False
    for tile in wall_bad['palette']:
        descriptor = json.loads(tile['id'])
        if descriptor[1:5] == ['CHOOSE',['wall'],['wall'],['normalHead','q0','0']]:
            descriptor[5] = ['plain','0']
            tile['id'] = literal_wire(descriptor)
            tile['S'] = literal_wire(['V','EXEC',['plain','0']])
            found = True
            break
    require(found, 'authored wall-coherence mutation contact exists in full palette')
    wall_ref = run.save('palette-wall-mutant.json',{'compiled':wall_bad,'parent':shared_ref,'authored_mutation':'copying boundary wall changed to plain 0 with coherent ID/S'})
    record = row_control_call(run,libraries,machine,wall_bad,wall_ref,initial,2,limits_w)
    require(record['return']['status'] == 'REJECTED', 'literal row wall-coherence violation rejected')
    records.append({'id':'W04-wall-coherence','evidence':record,'expected_status':'REJECTED'})
    for ident, numeric_kind in [('W05-bool-tag-edge','bool'),('W06-float-tag-edge','float')]:
        mutant = clone(compiled)
        found = False
        for tile in mutant['palette']:
            descriptor = json.loads(tile['id'])
            center = descriptor[3]
            if descriptor[1] == 'EXEC' and center[0] == 'taggedHead' and type(center[3]) is int and center[3] in (0,1):
                forged = clone(center)
                forged[3] = bool(center[3]) if numeric_kind == 'bool' else float(center[3])
                tile['N'] = literal_wire(['V','EXEC',forged])
                found = True
                break
        require(found, 'authored low transition-index edge exists')
        mutant_ref = run.save('palette-tag-'+numeric_kind+'-mutant.json',{'compiled':mutant,'parent':shared_ref,'authored_mutation':numeric_kind+' is not the integer tag in tile ID'})
        record = row_control_call(run,libraries,machine,mutant,mutant_ref,initial,2,limits_w)
        require(record['return']['status'] == 'REJECTED', 'typed literal edge refuses bool/float conflation')
        records.append({'id':ident,'evidence':record,'expected_status':'REJECTED'})
    adaptive_limit = {'max_operations':halted_baseline['return']['counts']['operations']+16,'max_row_solutions':10000,'max_distinct_rows':10000}
    record = row_control_call(run,libraries,machine,compiled,shared_ref,halted_baseline['initial'],1000000,adaptive_limit)
    require(record['return']['status'] == 'UNKNOWN_BUDGET' and record['return']['layers'] is None, 'empty frontier halfstep/layer tail remains metered')
    records.append({'id':'W07-empty-frontier-tail','baseline':halted_baseline,'declared_cap_rule':'complete two-step baseline operations plus exact fixed reserve 16','evidence':record,'expected_status':'UNKNOWN_BUDGET'})
    require(len(records) == 17, 'NTM additional control census')
    return run.save('ntm-wire-resource-coherence-controls.json',{'schema':'C-NTM-wire-resource-coherence-controls-v1','controls':records,'shared_palette':shared_ref})


def load_libraries(retained):
    result = {}
    for role in ('fol_checker','legacy','compiler','ntm_reference','wang_rows'):
        namespace = {'__name__':'_qualified_'+role,'__file__':SOURCE_PATHS[role]}
        exec(compile(retained[role],SOURCE_PATHS[role],'exec',dont_inherit=True),namespace,namespace)
        result[role] = namespace
    return result


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan',required=True)
    parser.add_argument('--result',required=True)
    args = parser.parse_args()
    run = None
    try:
        require(sys.executable == PYTHON['path'] and __file__ == SOURCE_PATHS['worker'], 'authenticated current runtime and Source address')
        require(sys.platform == 'darwin' and sys.version_info[:2] == (3,12), 'Darwin CPython 3.12 observation semantics')
        require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode, 'isolated no-site no-bytecode interpreter')
        plan, plan_ref = plan_read(args.plan)
        directory = pathlib.Path(plan['actual_dir'])
        require(directory.is_dir() and not directory.is_symlink(), 'owned actual directory')
        once_refs = consumed_read(plan,plan_ref,directory)
        retained = guard_read(plan,plan_ref,once_refs)
        require(args.result == str(directory/'worker-result.json') and not pathlib.Path(args.result).exists(), 'exclusive fixed result')
        run = Run(plan,plan_ref,started)
        run.budget()
        libraries = load_libraries(retained)
        fol_ref = fol_run(run,libraries)
        compiled_all, contexts, halted_baseline = ntm_run(run,libraries)
        controls_ref = ntm_controls(run,libraries,compiled_all,halted_baseline)
        require(run.calls == {'fol':40,'legacy':12,'compiler':10,'reference':128,'rows':127}, 'exact complete public-call census')
        guard_read(plan,plan_ref,once_refs)
        run.budget()
        summary = {'schema':'GCTS-FOL-NTM-component-qualification-result-v1','version':VERSION,'status':'COMPLETE_PASS',
                   'case_id':plan['case_id'],'plan':plan_ref,'source_guards':plan['sources'],'metadata_guards':plan['metadata'],
                   'cohort':COHORT,'counts':{'fol_controls':40,'legacy_compatible_controls':12,'palettes':2,'normal_NTM_contexts':120,'layers_per_context':3,'additional_NTM_controls':17,'public_calls':dict(run.calls)},
                   'evidence':{'fol':fol_ref,'contexts':contexts,'additional_controls':controls_ref,'all_prior_outputs':list(run.files)},
                   'costs_before_result_serialization':{'elapsed_seconds':time.monotonic()-started,'self_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_budget_callbacks':run.callbacks},
                   'scope':'Authored component regression qualification only; no theorem discovery, PA/Hilbert membership, proof-search benchmark, fixed universal Wang palette, or performance claim.'}
        result_ref = run.save('worker-result.json',summary)
        guard_read(plan,plan_ref,once_refs)
        run.budget()
        terminal = {'schema':'GCTS-FOL-NTM-worker-terminal-v1','status':'COMPLETE_PASS_RESULT_WRITTEN','case_id':plan['case_id'],
                    'plan':plan_ref,'result':result_ref,'public_calls':dict(run.calls),
                    'post_readback_costs':{'elapsed_main_entry_seconds':time.monotonic()-started,'self_lifetime_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'worker_budget_callbacks':run.callbacks},
                    'unmeasured_tail':'terminal encoding/flush and interpreter shutdown; full child lifetime peak independently observed by fresh parent'}
        sys.stdout.buffer.write(encode(terminal)); sys.stdout.buffer.flush()
        return 0
    except Exception as error:
        if run is not None:
            failure = {'schema':'GCTS-FOL-NTM-worker-failure-v1','status':'UNADMITTED','exception_type':type(error).__name__,
                       'message':str(error),'current':run.current,'completed_public_calls':dict(run.calls),'all_retained_outputs':list(run.files)}
            try:
                run.save('worker-failure.json',failure)
            except Exception:
                pass
        traceback.print_exc(file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
