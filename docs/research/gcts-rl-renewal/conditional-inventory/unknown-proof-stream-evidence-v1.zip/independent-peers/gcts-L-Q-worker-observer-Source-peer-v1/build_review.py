import ast,builtins,difflib,hashlib,json,pathlib,re,symtable,sys
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');C=Q/'implementation-C';OUT=pathlib.Path('/private/tmp/gcts-L-Q-worker-observer-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def save(n,v):
 p=OUT/n
 with p.open('xb') as f:f.write((json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode())
 return ref(p)
def check(r):
 a=ref(r['path']);assert a==r,(a,r);return a
def rawnode(b,n):return b''.join(b.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
def stats(p):
 b=pathlib.Path(p).read_bytes();s=b.decode();t=ast.parse(s,filename=str(p));compile(s,str(p),'exec',dont_inherit=True)
 rows=[]
 def walk(ns,prefix=''):
  for n in ns:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+n.name
    rows.append({'name':name,'lines':[n.lineno,n.end_lineno],'raw_bytes':len(rawnode(b,n)),'raw_sha256':H(rawnode(b,n)),'AST_sha256':H(ast.dump(n,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'calls':sorted(set(ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call)))})
    walk(n.body,name+'.')
   else:
    for _,v in ast.iter_fields(n):
     if isinstance(v,list) and v and all(isinstance(x,ast.stmt) for x in v):walk(v,prefix)
 walk(t.body)
 st=symtable.symtable(s,str(p),'exec');sc=[]
 def sw(s,parents=''):
  sc.append({'name':parents+s.get_name(),'type':str(s.get_type()),'line':s.get_lineno(),'symbols':[{'name':x.get_name(),'local':x.is_local(),'global':x.is_global(),'free':x.is_free(),'referenced':x.is_referenced(),'assigned':x.is_assigned(),'parameter':x.is_parameter(),'imported':x.is_imported()} for x in s.get_symbols()]})
  for x in s.get_children():sw(x,parents+s.get_name()+'.')
 sw(st)
 const={}
 for n in t.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:const[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return {'Source':ref(p),'lines':len(s.splitlines()),'all_named_units':rows,'scopes':sc,'scope_count':len(sc),'imports':[ast.unparse(n) for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))],'whole_AST_sha256':H(ast.dump(t,include_attributes=False).encode()),'whole_positioned_AST_sha256':H(ast.dump(t,include_attributes=True).encode()),'unused_compile':True},const,t

def apply(b,patch):
 src=b.decode().splitlines(keepends=True);ps=patch.decode().splitlines(keepends=True);out=[];idx=0;k=2
 while k<len(ps):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',ps[k]);assert m,ps[k]
  old=int(m[1])-1;out.extend(src[idx:old]);idx=old;k+=1
  while k<len(ps) and not ps[k].startswith('@@ '):
   line=ps[k];k+=1
   if line.startswith(' '):assert src[idx]==line[1:];out.append(src[idx]);idx+=1
   elif line.startswith('-'):assert src[idx]==line[1:];idx+=1
   elif line.startswith('+'):out.append(line[1:])
   elif line.startswith('\\ No newline'):raise AssertionError('unexpected newline marker')
   else:raise AssertionError(line)
 out.extend(src[idx:]);return ''.join(out).encode()

hs={};sdata={};const={};trees={};pinjoins=[]
for v,expected in [(1,'b0f423fff1db2bf386b805371422a74d2a9973e6bc8e059325a478cbc37cf185'),(2,'91f618ca20b631a69b1697f0a7b506fd824b9f5a1bccc131d3ba553d80495e83')]:
 p=C/f'raw-proof-integration-worker-observer-complete-inert-Source-handoff-v{v}.json';assert ref(p)['sha256']==expected;hs[v]=load(p)
 pinjoins.append(ref(p))
 for r in list(hs[v]['sources'].values())+list(hs[v]['supporting_records'].values())+hs[v]['patches']:pinjoins.append(check(r))
 for role,r in hs[v]['sources'].items():
  sdata[v,role],const[v,role],trees[v,role]=stats(r['path'])
  manual=load(hs[v]['supporting_records']['complete_helper_walkthrough']['path']);static=load(hs[v]['supporting_records']['complete_static']['path'])
  top={n.name:n for n in trees[v,role].body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
  for mr in manual['helpers']:
   if mr['role']==role:assert H(rawnode(pathlib.Path(r['path']).read_bytes(),top[mr['helper']]))==mr['raw_sha256']
  for sr in static[role]['top_definitions']:
   n=top[sr['name']];assert H(rawnode(pathlib.Path(r['path']).read_bytes(),n))==sr['raw_sha256'];assert H(ast.dump(n,include_attributes=False).encode())==sr['AST_sha256'];assert H(ast.dump(n,include_attributes=True).encode())==sr['positioned_AST_sha256']
  assert static[role]['scope_count']==sdata[v,role]['scope_count']
  assert {mr['helper'] for mr in manual['helpers'] if mr['role']==role}==set(top)

# Exact literal role/metadata/runtime raw guards; bodies are hashed only, never imported.
w=const[2,'worker'];o=const[2,'observer']
for key in ['PYTHON','LIMITS','SOURCE_PATHS','COMPONENT_PINS','METADATA_PINS','COHORT','EXPECTED_CALL_BASE','EXPECTED_CALL_C1_SELECTED','CONSUMED_MEANING']:assert w[key]==o[key]
for role,(size,digest) in w['COMPONENT_PINS'].items():pinjoins.append(check({'path':w['SOURCE_PATHS'][role],'bytes':size,'sha256':digest}))
for r in w['METADATA_PINS'].values():pinjoins.append(check(r))
pinjoins.append(check(w['PYTHON']))
assert pathlib.Path(sys.executable).resolve()==pathlib.Path(w['PYTHON']['path']).resolve()
assert sys.version_info[:3]==(3,12,14)

# Author patch readback is independently applied to complete raw strings in memory.
patchproof=[]
ledger=load(hs[1]['supporting_records']['complete_inheritance_and_patches']['path'])
for role in ['worker','observer']:
 base=check(ledger['base_'+role]);pinjoins.append(base)
 for v,before in [(1,pathlib.Path(base['path']).read_bytes()),(2,pathlib.Path(hs[1]['sources'][role]['path']).read_bytes())]:
  after=pathlib.Path(hs[v]['sources'][role]['path']).read_bytes()
  f=C/f'qualification-{role}-full-forward-v{v}.patch';i=C/f'qualification-{role}-full-inverse-v{v}.patch'
  assert apply(before,f.read_bytes())==after
  assert apply(after,i.read_bytes())==before
  assert ast.dump(ast.parse(apply(after,i.read_bytes())),include_attributes=True)==ast.dump(ast.parse(before),include_attributes=True)
  patchproof.append({'role':role,'revision':v,'base':ref(base['path']) if v==1 else hs[1]['sources'][role],'current':hs[v]['sources'][role],'forward':ref(f),'inverse':ref(i),'full_raw_both_directions':True,'positioned_AST_inverse':True})

preservation={}
for role in ['worker','observer']:
 old=trees[1,role];new=trees[2,role];ob=pathlib.Path(hs[1]['sources'][role]['path']).read_bytes();nb=pathlib.Path(hs[2]['sources'][role]['path']).read_bytes()
 a={n.name:n for n in old.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};b={n.name:n for n in new.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
 unchanged=[k for k in a if k in b and rawnode(ob,a[k])==rawnode(nb,b[k])];changed=[k for k in a if k in b and k not in unchanged];added=sorted(set(b)-set(a));removed=sorted(set(a)-set(b))
 assert changed==(['Run','semantic_run'] if role=='worker' else []),(role,changed)
 assert added==(['BoundedStoredWriter'] if role=='worker' else []) and not removed
 c1=const[1,role];c2=const[2,role];assert set(c1)==set(c2)
 cg=[k for k in c1 if c1[k]!=c2[k]];assert cg==['VERSION','SOURCE_PATHS'],cg
 assert {k:(a[k],b[k]) for k in a if False}=={}
 preservation[role]={'raw_and_AST_unchanged_top_units':unchanged,'changed_top_units':changed,'added_top_units':added,'removed_top_units':removed,'changed_literal_globals':cg}
 assert all(H(ast.dump(a[k],include_attributes=False).encode())==H(ast.dump(b[k],include_attributes=False).encode()) for k in unchanged)
# No fixture factory or qualification function evaluated; the following are Source-text/AST facts only.
source2=pathlib.Path(hs[2]['sources']['worker']['path']).read_text()
assert source2.index("require(dec['status']=='COMPLETE','semantic bytes")<source2.index("c=run.call('carrier.build'",source2.index('def semantic_run'))
assert source2.index("equal(dec['proof'],f['proof'],'whole authored semantic")<source2.index("c=run.call('carrier.build'",source2.index('def semantic_run'))
assert len(w['LIMITS'])==13 and len(w['SOURCE_PATHS'])==10 and len(w['METADATA_PINS'])==7
assert sum(w['EXPECTED_CALL_BASE'].values())==1643 and sum(w['EXPECTED_CALL_C1_SELECTED'].values())==6
# Current public packet versions differ only data addresses/Source refs and scoped resource disclosures; census bytes identical.
assert hs[1]['supporting_records']['closed_analytic_census']['sha256']==hs[2]['supporting_records']['closed_analytic_census']['sha256']
extra=ref(C/'qualification-Source2-complete-correction-and-inverse-audit-v1.json');assert extra['sha256']=='12fc4c04e271213da3f305444c2bf4ec5d6622ff0b2722b4c1cbf5f9d63a9694';pinjoins.append(extra)
exp=ref(Q/'implementation-L/peer-Q-once-worker-observer-v1/Q-worker-observer-prefrozen-complete-Source-review-expectations-v1.json');assert exp['sha256']=='718035c0f074e95b9605e07a50f51f6a97163beda4342ac069203bcae7b3ac76'
support={'schema':'L-Q-independent-wrapper-Source-static-and-preservation-support-v1','status':'STATIC_COMPLETE_NO_SUBJECT_EXECUTION','runtime':ref(sys.executable),'runtime_version':sys.version,'prefrozen_expectations':exp,'exact_direct_rawpin_joins':pinjoins,'subjects':{str(v):{role:sdata[v,role] for role in ['worker','observer']} for v in [1,2]},'patches':patchproof,'Source2_preservation':preservation,'shared_literals':{k:w[k] for k in ['PYTHON','LIMITS','SOURCE_PATHS','COMPONENT_PINS','METADATA_PINS','COHORT','EXPECTED_CALL_BASE','EXPECTED_CALL_C1_SELECTED','CONSUMED_MEANING']},'manual_and_author_static':{'all_top_helper_raw_joins':True,'all_author_raw_AST_positioned_AST_fingerprints_joined':True,'all_scope_counts_joined':True},'subject_calls':0,'subject_imports':0,'scientific_fixture_factory_calls':0,'qualifications_executed':0,'unused_compile_only':True}
sr=save('Q-worker-observer-independent-complete-static-preservation-support-v1.json',support)
common={'prefrozen_expectations':exp,'support':sr,'scope':'Complete current wrapper Source and static recipe/caller/resource review; scientific libraries rely on separately accepted current Sources and public ABI/rawguard joins. This is Source approval only, no qualification, proof search, GCTS performance, physical FOL execution, Machine5 or tiling result. All subject calls remain zero.','closed_cohort':{'grammar':18,'malformed':16,'semantic':12,'wire_resource':38,'byte_choices':256,'diagnostic':1,'physical_negatives':6,'C1_construction_attempt':1,'total_controls':348,'direct_calls_base':1643,'conditional_C1_selected_calls':6},'libraries_and_guard_scope':'All8 component Source and7 public metadata/runtime rawpins verified without library semantic replay; retained tree_machine identity before lowerer execution is checked in future main. Exact stream_node grammar observation and input_node real parser/physical carrier roles preserved.','caller_scope':'Strict plan8/authority6/consume7 and exact3 rawrefs; durable exclusive consumed marker before sole authenticated retained-byte child; owned fresh group/protected setup/EOF/bounded TERM,KILL,wait,drain and postguards; authoritative owned tool/session terminal plus complete outer captures required separately. No current plan or authority granted.','resource_scope':'13 exact caps; cooperative worker main-entry and Darwin SELF highwater plus external observer watchdog/confirmed ownedwait lifetime child highwater; no hard OS memory guarantee, exact process-tree sum, cross-clock inequality or unknown-prefix admission. Full gzip/plain raw and stored lossless readback.','reviewed_semantics':['All18 grammar controls decode COMPLETE/exact proof, observe stream_node native returned JSON heap ID (old VM status rejected is not proof rejection), independent syntax decode equality; all16 malformed require normal false.','All12 fixed real-parser common-profile controls include8 true,3 both rejected,1 alpha one-way difference; accepted implies independent checker VERIFIED, converse withheld.','38 wire/resource controls cover exact statuses/foreign exception/tamper/all7JSON tags/duplicatekeys/expandedDAG/no shared mutable outputs.','All256 physical/binary masks preserve every fixed field with full round trips; generic13-opcode diagnostic native/selected/literal physical whole-state comparisons and6 negatives. No physical FOL run claimed.','One real parser bounded C1 selected/physical construction records COMPLETE model or owned UNKNOWN gap; refusal never proves physical FOL completeness; whole errors/census mismatches unadmitted.'],'immutability':'v1 sources and all old receipts preserved; no Source edits, functions, probes, plan, authority, actual or publication performed by reviewer.'}
v1={**common,'schema':'L-Q-worker-observer-complete-independent-Source-review-v1','decision':'CHANGES_REQUIRED_SOURCE1_UNRUN','review_passed':False,'sources':hs[1]['sources'],'handoff':ref(C/'raw-proof-integration-worker-observer-complete-inert-Source-handoff-v1.json'),'blockers':[{'id':'R1','source_unit':'Run.save','finding':'Stored body/count/aggregate reserve guards follow writes; gzip header/trailer bypass per-chunk base.tell guard. A rejected attempt may already exceed stated owned output bounds.','required_closure':'Census existing owned files/count and reserve before xb; intercept every actual base write, including gzip creation and close trailer, and reject proposed body/aggregate growth before base.write; preserve full hashes/readbacks/caps.'},{'id':'R2','source_unit':'semantic_run','finding':'Semantic decoder status COMPLETE and exact authored proof equality absent. In expected checker-REJECTED controls an uncompleted wire decode could be mislabeled as a semantic negative.','required_closure':'All12 semantic decoder results require COMPLETE and full exact authored proof equality before native/FOL checks. No extra controls/calls/caps.'}],'complete_batch':'Exactly two material findings after whole both Source bodies and recipe/custody read. No additional material issue identified.'}
r1=save('Q-worker-observer-complete-independent-Source-review-v1.json',v1)
v2={**common,'schema':'L-Q-worker-observer-complete-independent-Source-review-v2','decision':'PASS_SOURCE2_ONLY_ALL_SUBJECTS_UNRUN','review_passed':True,'sources':hs[2]['sources'],'handoff':ref(C/'raw-proof-integration-worker-observer-complete-inert-Source-handoff-v2.json'),'public_ABI':hs[2]['supporting_records']['public_ABI'],'inherited_complete_v1_review':r1,'blockers':[],'Source2_closure':{'R1':'Run.save pre-censuses all existing regular single-link owned files, checks next count+9 and prior bytes+1+2MiB reserve before xb. Both plain and gzip direct all actual base writes through BoundedStoredWriter; exact bytes proposed body and prior+proposed+reserve checked before base.write; gzip header/compressed writes/close trailer included. Full stored extent==bounded.tell plus full raw SHA/extent readback retained. Cooperative guards and every declared cap unchanged.','R2':'All12 semantic decodes require COMPLETE then full exact decoded NativeAST/authored proof equality before native/B semantic checks. Existing controls and public call counts unchanged.'},'preservation':preservation,'bootstrap':'Exact existing323-byte authenticated retained-worker bootstrap unchanged; observer all22 top helper bodies raw/AST unchanged; only VERSION and two Source path strings differ. No new cleanup/clock/once algorithm introduced.','remaining_separate_gates':['Root whole Source adoption.','Exact future closed plan/rawguards/fresh paths and prospective literal outer caller review.','Fresh explicit current authority, peer quiescence and one owned terminal launch under separate grant.','Complete actual outcomes, Source guards, once/capture/EOF/wait/cleanup/resource/artifact census/raw readbacks and all controls must be independently reviewed before any scientific admission.'],'terminal_state':'REVIEW_COMPLETE_TOOLS_TERMINAL_IDLE'}
r2=save('Q-worker-observer-complete-independent-Source-review-v2.json',v2)
print(json.dumps({'v1':r1,'v2':r2,'support':sr,'preservation':preservation},indent=2))
