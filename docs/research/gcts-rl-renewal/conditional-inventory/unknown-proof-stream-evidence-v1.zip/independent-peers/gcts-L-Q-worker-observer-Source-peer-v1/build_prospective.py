import ast,hashlib,json,pathlib,shlex,stat
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');R=Q/'root';C=Q/'implementation-C';O=pathlib.Path('/private/tmp/gcts-L-Q-worker-observer-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def J(p):return json.loads(pathlib.Path(p).read_bytes())
def typed(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
def safe(p):
 p=pathlib.Path(p);assert p.is_absolute() and p.resolve()==p
 for a in [p,*p.parents]:assert not a.is_symlink()
 st=p.stat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
 return ref(p)
def checked(r):a=safe(r['path']);assert typed(a,r);return a
p=R/'unknown-proof-integration-once-plan-001.json';c=R/'qualification-001-prospective-caller-v1.json'
assert ref(p)=={'path':str(p),'bytes':4587,'sha256':'5d5b6e874021a573aa4b79cd833b5cc8a92c7a665745bbf9369ab73cb5aedac1'}
assert ref(c)=={'path':str(c),'bytes':3013,'sha256':'0a27ad034fc60fba3e15ec3f5297dd6f1c9928c614c2c169ac71edfbb83fd62e'}
plan=J(p);caller=J(c);assert set(plan)==set('schema case_id actual_dir python sources metadata limits cohort'.split())
assert plan['schema']=='GCTS-raw-proof-integration-once-plan-v1' and plan['case_id']=='qualification-001' and plan['actual_dir']==str(Q/'actual/qualification-001')
const={}
for n in ast.parse((C/'unknown_stream_qualification_worker_v2.py').read_bytes()).body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:const[n.targets[0].id]=ast.literal_eval(n.value)
  except (TypeError,ValueError):pass
assert typed(plan['limits'],const['LIMITS']) and typed(plan['python'],const['PYTHON']) and plan['cohort']==const['COHORT']
assert set(plan['sources'])==set(const['SOURCE_PATHS']) and typed(plan['metadata'],const['METADATA_PINS'])
joins=[safe(p),safe(c)]
for role,r in plan['sources'].items():
 assert r['path']==const['SOURCE_PATHS'][role];joins.append(checked(r))
 if role in const['COMPONENT_PINS']:assert typed([r['bytes'],r['sha256']],const['COMPONENT_PINS'][role])
for r in plan['metadata'].values():joins.append(checked(r))
joins.append(checked(plan['python']));joins.append(checked(caller['Source_adoption']))
adopt=J(caller['Source_adoption']['path']);assert typed(adopt['Sources'],plan['sources']) and adopt['status']=='SOURCE_ADOPTED_PROSPECTIVE_CALLER_REQUIRED_NO_AUTHORITY'
joins.append(checked(adopt['peer']));joins.append(checked(adopt['Source_handoff']));joins.append(checked(caller['bootstrap']))
bootstrap=pathlib.Path(caller['bootstrap']['path']).read_bytes();assert len(bootstrap)==344 and H(bootstrap)=='f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62'
assert typed(caller['observer'],plan['sources']['observer']) and typed(caller['plan'],ref(p))
a=R/'unknown-proof-integration-once-authority-001.json';assert caller['authority_target']==str(a)
stdout=R/'qualification-001-outer-stdout.bin';stderr=R/'qualification-001-outer-stderr.bin';assert caller['outer_captures']==[str(stdout),str(stderr)]
cmd=caller['command'];assert cmd.startswith('set -C\nexec ')
argv=shlex.split(cmd.split('\n',1)[1]);assert argv[0]=='exec'
expected=['exec',plan['python']['path'],'-I','-S','-B','-c',bootstrap.decode(),plan['sources']['observer']['path'],'32486',plan['sources']['observer']['sha256'],'--plan',str(p),'--authority',str(a),'<',plan['sources']['observer']['path'],'>',str(stdout),'2>',str(stderr)]
assert argv==expected,(argv,expected)
assert caller['exec_options']=={'login':False,'max_output_tokens':2000,'workdir':'/private/tmp','yield_time_ms':1000}
paths=[pathlib.Path(plan['actual_dir']),pathlib.Path(plan['actual_dir'])/'CONSUMED.json',a,stdout,stderr]
absent=[]
for x in paths:
 assert not x.exists() and not x.is_symlink(),str(x)
 for q in x.parents:assert not q.is_symlink()
 absent.append({'path':str(x),'exists':False,'symlink':False})
future={'schema':'Root-raw-proof-integration-once-authority-v1','authorized':True,'uses':1,'case_id':plan['case_id'],'plan':ref(p),'observer':plan['sources']['observer']}
s={'schema':'L-Q-qualification001-independent-prospective-caller-support-v1','plan':plan,'caller':caller,'all_current_rawjoins':joins,'fresh_path_observations':absent,'parsed_shell_argv':argv,'bootstrap':caller['bootstrap'],'future_authority6_template_only_not_written':future,'const_caps_and_roles_exact':True,'proof_of_no_execution':'Only stdlib JSON/AST/string/shell-token/hash/file-stat comparisons. No subject import, function, helper, model, fixture, test, CLI or compiled code executed.','subject_calls':0}
def save(name,d):
 p=O/name;b=(json.dumps(d,sort_keys=True,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return ref(p)
sr=save('Q-qualification001-complete-prospective-caller-support-v1.json',s)
r={'schema':'L-Q-qualification001-complete-independent-prospective-caller-review-v1','decision':'PASS_PROSPECTIVE_ONLY_NO_EXECUTION_GRANT','review_passed':True,'blockers':[],'prefrozen_expectations':ref(O/'Q-qualification001-prefrozen-prospective-caller-expectations-v1.json'),'Source_review':ref(O/'Q-worker-observer-complete-independent-Source-review-v2.json'),'support':sr,'plan':ref(p),'caller':ref(c),'Root_Source_adoption':caller['Source_adoption'],'whole_current_guard_result':'All10 current Source roles,7 current metadata ABIs,D90,complete Root adoption/current Bpeer/current Source handoff and exact344-byte outer bootstrap rawpins passed; plan limits13/types/cohort8fieldplan/current2 addresses match reviewed Source2. Component bodies hashed opaque only.','future_authority':{'template':future,'exists':False,'creation_authority':'Root only after this review/adoption; reviewer created none'},'freshness':absent,'caller_checks':'Exact set -C newline exec D90 -I -S -B -c authenticated344-byte stdin observer bootstrap, exact current observer length/SHA, exact plan/future authority/input redirection and fresh noclobber stdout/stderr, no tee/capture-parent/retry or extra subject invocation. exec options login=false/workdir=/private/tmp/yield1000/maxoutput2000 as declared. Root must retain complete original toolresponse/session handle and authoritative owned terminal before any full capture/receipt admission.','consume_precision':'Current Source creates durable exclusive actual/qualification-001/CONSUMED.json exact7 BEFORE sole retained-worker launch; future A6 is separate Root metadata. The prefreeze generic adjacent-marker wording does not assert an authority-adjacent marker or add one. Actual directory and marker both absent.','closed_scope':'Whole348 authored controls,1643 base direct calls plus6 iff selected C1 completes; generic grammar/semantic/carrier/MIN8 physical encoding qualification only. C1 constructionUNKNOWN is an explicit gap; no proof discovery, unknown-proof search, strictMachine5, physical FOL, tiling or performance result from this review.','postactual_gates':['Exact current Source/runtime/plan/metadata/A6/consume pre/post rawguards and complete all artifact stored+decompressed readback/census/caps.','Whole worker result/actual controls, complete outer original transport/captures/owned session terminal, child0/EOF/groupgone/confirmedwait and full current terminal/result association.','All errors/time/memory/output/construction scopes truthful; no positive-prefix admission. Only separate actual review can admit components.'],'global_idle':'B/C idle reported by Root; Root must reconfirm all tools/peers quiescent immediately before its separate grant. L ends this review terminal/idle.','reviewer_subject_calls':0,'terminal_state':'TERMINAL_IDLE_NO_A6_OR_ACTUAL_CREATED'}
rr=save('Q-qualification001-complete-independent-prospective-caller-review-v1.json',r)
print(json.dumps({'review':rr,'support':sr},indent=2))
