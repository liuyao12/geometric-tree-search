from pathlib import Path
import ast,symtable,json,hashlib,re,builtins
P=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');L=P/'implementation-L';C=P/'implementation-C';O=Path('/private/tmp/gcts-B-syntax-heap-decoder-observer-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def enc(o):return(json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return{'path':str(p),'bytes':len(b),'sha256':H(b)}
def rr(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];return b

def save(n,o):
 p=O/n;b=enc(o);p.write_bytes(b);assert p.read_bytes()==b;return pin(p)
def derive(p):
 b=p.read_bytes();t=ast.parse(b,str(p));ls=b.splitlines(keepends=True);ns=[n for n in ast.walk(t)if isinstance(n,(ast.FunctionDef,ast.ClassDef))];ds=[]
 for n in sorted(ns,key=lambda n:n.lineno):
  pars=sorted([x for x in ns if x is not n and x.lineno<n.lineno<=n.end_lineno<=x.end_lineno],key=lambda x:x.lineno);name='.'.join([x.name for x in pars]+[n.name]);raw=b''.join(ls[n.lineno-1:n.end_lineno]);bs=[]
  for x in ast.walk(n):
   if isinstance(x,(ast.If,ast.IfExp,ast.For,ast.While,ast.Try,ast.ExceptHandler)):
    v=x.iter if isinstance(x,ast.For)else x.type if isinstance(x,ast.ExceptHandler)else None if isinstance(x,ast.Try)else x.test
    bs.append({'kind':type(x).__name__,'line':x.lineno,'end_line':x.end_lineno,'test':None if v is None else ast.unparse(v)})
  ds.append({'name':name,'kind':type(n).__name__,'line':n.lineno,'end_line':n.end_lineno,'signature':None if isinstance(n,ast.ClassDef)else ast.unparse(n.args),'raw_bytes':len(raw),'raw_sha256':H(raw),'AST_sha256':H(ast.dump(n).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'calls':sorted(set(ast.unparse(x.func)for x in ast.walk(n)if isinstance(x,ast.Call))),'branches':bs})
 st=symtable.symtable(b.decode(),str(p),'exec');ss=[];bound=set(st.get_identifiers());unresolved=[]
 def walk(s,name):
  es=[]
  for n in s.get_identifiers():
   v=s.lookup(n);e={'name':n};e.update({k:getattr(v,'is_'+k)()for k in['assigned','free','global','imported','local','nonlocal','parameter','referenced']});es.append(e)
   if v.is_global()and v.is_referenced()and n not in bound and not hasattr(builtins,n):unresolved.append((name,n))
  ss.append({'name':name,'type':s.get_type(),'line':s.get_lineno(),'entries':es})
  for c in s.get_children():walk(c,name+'.'+c.get_name())
 walk(st,'top');return {'Source':pin(p),'lines':len(ls),'definitions':ds,'symbol_scopes':ss,'unresolved_globals':unresolved,'whole_AST_sha256':H(ast.dump(t).encode()),'whole_positioned_AST_sha256':H(ast.dump(t,include_attributes=True).encode()),'imports':[ast.unparse(x)for x in t.body if isinstance(x,(ast.Import,ast.ImportFrom))]},t,b
hp=L/'ascii-tree-heap-decoder-complete-inert-Source-handoff-v1.json';hand=json.loads(hp.read_bytes());meta=[]
for k in['closure','manual','prefrozen_requirements','public_ABI','static']:rr(hand[k]);meta.append(hand[k])
dec,dt,db=derive(Path(hand['Source']['path']));a=json.loads(rr(hand['static']));assert dec['definitions']==a['definitions']and dec['symbol_scopes']==a['symbol_scopes'];assert dec['whole_AST_sha256']==a['whole_AST_sha256']and dec['whole_positioned_AST_sha256']==a['whole_positioned_AST_sha256'];assert len(dec['definitions'])==19 and len(dec['symbol_scopes'])==23 and not dec['imports']and not dec['unresolved_globals']
man=json.loads(rr(hand['manual']));dmap={x['name']:x for x in dec['definitions']};assert len(man['helpers'])==19
for x in man['helpers']:assert all(x[k]==dmap[x['name']][k]for k in['line','end_line','name','signature'])
# Sister entire preservation; all inherited syntax checked by prior complete parser peer.
oh=C/'grammar-observer-sister-complete-inert-Source-handoff-v1.json';ohand=json.loads(oh.read_bytes());obsmeta=[]
for k in['complete_static_preservation','inherited_full_real_parser_handoff','public_ABI']:rr(ohand[k]);obsmeta.append(ohand[k])
obs,ot,ob=derive(Path(ohand['Source']['path']));real,rt,rb=derive(C/'proof_byte_fol_checker_v1.tree');osp=json.loads(rr(ohand['complete_static_preservation']));assert obs['whole_AST_sha256']==osp['whole_AST_sha256']and obs['whole_positioned_AST_sha256']==osp['whole_positioned_AST_sha256'];om={x['name']:x for x in obs['definitions']};rm={x['name']:x for x in real['definitions']};assert len(om)==len(rm)==92 and len(obs['symbol_scopes'])==93
for n in rm:
 if n!='main':assert om[n]['raw_sha256']==rm[n]['raw_sha256']and om[n]['AST_sha256']==rm[n]['AST_sha256']
for x in osp['all91_nonmain_helpers']:
 n=x['name'];assert om[n]['raw_sha256']==x['raw_sha256']and om[n]['AST_sha256']==x['plain_AST_sha256']and om[n]['positioned_AST_sha256']==x['current_positioned_AST_sha256']and om[n]['line']==x['current_line']
rl=rb.splitlines(keepends=True);ol=ob.splitlines(keepends=True);rmain=b''.join(rl[rm['main']['line']-1:rm['main']['end_line']]);omain=b''.join(ol[om['main']['line']-1:om['main']['end_line']]);assert H(rmain)==osp['first_main_before_raw_sha256']and H(omain)==osp['first_main_after_raw_sha256'];inverse=ob.replace(omain,rmain,1);assert inverse==rb and ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(rt,include_attributes=True)
def apply(a,p):
 src=a.decode().splitlines(keepends=True);ls=p.decode().splitlines(keepends=True);i=2;cur=0;out=[]
 while i<len(ls):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i]);assert m;pos=int(m[1])-1;out.extend(src[cur:pos]);cur=pos;i+=1
  while i<len(ls)and not ls[i].startswith('@@ '):
   z=ls[i];i+=1
   if z.startswith('\\'):continue
   if z[0]in' -':assert src[cur]==z[1:];cur+=1
   if z[0]in' +':out.append(z[1:])
 out.extend(src[cur:]);return ''.join(out).encode()
for i,r in enumerate(osp['patches']):assert apply(rb if i==0 else ob,rr(r))==(ob if i==0 else rb)
arity={n:len(f.args.args)for n,f in[(x.name,x)for x in ot.body]};arity.update({'cons':2,'head':1,'tail':1,'is_pair':1,'atom_eq':2,'byte_succ':1});assert ot.body[0].name=='main'and arity['main']==1
for f in ot.body:
 assert isinstance(f,ast.FunctionDef)
 for x in ast.walk(f):
  if isinstance(x,ast.Call):assert isinstance(x.func,ast.Name)and not x.keywords and x.func.id in arity and len(x.args)==arity[x.func.id]
graph={n:sorted(set(x['calls'])&set(om))for n,x in om.items()};seen=set();todo=['main']
while todo:
 n=todo.pop()
 if n not in seen:seen.add(n);todo.extend(graph[n])
assert sorted(seen)==osp['conservative_entry_reach']and len(seen)==34;assert not seen&{'ps_json_profile','ps_semantic_main','ps_request','formula_ok','rule_ok','proof'}
support=save('syntax-heap-decoder-and-observer-entry-complete-independent-static-support-v1.json',{'schema':'B-syntax-heap-decoder-observer-complete-independent-static-support-v1','decoder_handoff':pin(hp),'decoder_metadata':meta,'decoder_full_raw_AST_symtable_call_branch_joins':dec,'decoder_all_author_static_fingerprints_manual_exact':True,'observer_handoff':pin(oh),'observer_metadata':obsmeta,'observer_complete_raw_AST_symbols_calls_branches':obs,'observer_old_real_Source':real['Source'],'all91_other_helpers_raw_AST_exact':True,'observer_whole_main_replacement_inverse_raw_positioned_AST_exact':True,'both_observer_patches_forward_inverse_exact':osp['patches'],'observer_all_static_arities_valid':True,'observer_entry_reach':sorted(seen),'subject_calls':0,'unused_compile':False})
dec_review=save('ASCII-syntax-heap-decoder-complete-independent-Source-review-v1.json',{'schema':'B-ASCII-syntax-heap-decoder-complete-independent-Source-review-v1','decision':'PASS_SOURCE_ONLY','complete_review':True,'blockers':[],'prefrozen_expectations':pin(O/'syntax-decoder-observer-prefrozen-whole-static-expectations-v1.json'),'Source':hand['Source'],'handoff':pin(hp),'public_ABI':hand['public_ABI'],'full_static_support':support,'findings':[{'id':'WHOLE_HEAP','detail':'Every raw record including unreachable records validated/copied: exact list of exact list/tuple pairs, nonbool integer children0..256 or strictly earlier ID, no duplicate pairs; full heapcount gate before growth. Earlier children prove acyclic finite DAG; syntax roots must existing pairIDs.'},{'id':'JSON_NATIVE_VALUES','detail':'Seven tags exact: proper arrays/objects with canonical rawword unique keys, nonempty printableASCII strings, bounded unary naturals, negative magnitude positive, bool payload0/1, nullpayloadNIL256. Native types/detached containers correct. No formula/rule/theory truth interpretation; null is DECODED/valueNone and requires status distinction.'},{'id':'REPEATED_EDGE_EXPANSION','detail':'Recipes retain rawIDs/lengths, memoization only avoids repeated analysis. Root expanded node/string/depth weights add every child edge occurrence plus every objectkey occurrence. Duplicate keys detected by equal canonical word IDs without early string allocation. Deep cached subtree height rechecked in each occurrence context. Exponential shared-DAG output cannot be admitted merely because input node count is small.'},{'id':'PREALLOCATION_AND_BUDGETS','detail':'Heap/operation/depth/expandednodes/string/natural caps cover whole analysis. Pending recipe jobs bulkcharged before queue growth; complete repeated-edge root weights and outputwork reserved before expanded native allocation. Materialization uses zero-unit globalbudget ticks so actual callbacks continue without doublecounting reservation; final actual nodes/key/string counters equal weights on success. All own resource refusals UNKNOWN/valueNone/weightsNone; foreign errors propagate.'},{'id':'PURITY_AND_BINDING','detail':'Source imports0,19defs23scopes, all author raw/plain/positionedAST/manual joins exact. Iterative analysis/materialization avoids native recursive tree evaluation. Full private checked node copy precedes syntax analysis; no input mutation or mutable output alias. Caller must bind actual normal VM returnedvalue+fullheap/currentSource and prohibit concurrent or callback-driven input mutation; decoder does not authenticate arbitrary self-authored heap provenance.'}],'scope':'Generic syntax-only observer for ASCII oldJSONwire; not a semantic checker/fullUnicodeinverse, proof verdict, proofdiscovery or physicalmachine/palette qualification. No Source function/import/constructor/VM/helper/fixture/CLI/codeobject run.','remaining':'Root fullread/adoption, exact controlled qualification/caller/once authority, full saved runtime-node and independent bytecodec equality; independent semantic checker only for real proof-machine acceptance.','terminal_state':'IDLE'})
obs_review=save('grammar-observer-entry-complete-independent-Source-review-v1.json',{'schema':'B-grammar-observer-entry-complete-independent-Source-review-v1','decision':'PASS_QUALIFICATION_OBSERVER_SOURCE_ONLY','complete_review':True,'blockers':[],'Source':ohand['Source'],'handoff':pin(oh),'public_ABI':ohand['public_ABI'],'full_static_support':support,'inherited_real_parser_peer':pin(Path('/private/tmp/gcts-B-runtime-byte-parser-Source-peer-v1/runtime-byte-parser-complete-independent-static-Source-peer-review-v2.json')),'findings':[{'id':'ONLY_MAIN','detail':'Entire newmain(rows) reads version1 then returns ps_proof(rest).91other helper bodies raw/plainAST identical, full inverse restores all29429 realSourcebytes/positionedAST; both published patches checked.92functions93scopes static arities correct; no helper/VM execution.'},{'id':'GRAMMAR_ONLY_REACH','detail':'Entry closure34functions contains parsing/constructors only; knownprefix validation/semantic entry/ps_request/formula/rule/proof lookups unreachable. Same complete nonempty fullEND/truncation/tag/name/list/reference grammar. Real proof-machine Source remains untouched.'},{'id':'NORMAL_NODE_VS_VM_LABEL','detail':'On grammar success ps_proof returns JSONarray consnode>=257. OldVM labels every normal nonboolean value rejected; this is not grammar or theorem rejection. Caller must require completed normal return with exactinteger value>256 and decode actual fullheap/value. VMaccepted/value1 is protocolinconsistency. Resource/invalid-data outcomes without confirmed normal node are not grammar success.'},{'id':'FRESH_INSTANCE_AND_ARGUMENT','detail':'Compile and initialize this sister independently under new Sourcepins; constant discovery order/nodeIDs differ from realmachine. Entry takes proper stream rows (the carrier stream_node), not realmachine rawtriple input_node. Do not reuse other program declarations/heaps/IDs or the rawtriple register binding. Markers/MIN8/mask/read-only/alias data remain independently qualified; generic realmachine mask always binds its own declared input_root.'},{'id':'OBSERVATION_ONLY','detail':'Compare completely decoded nativeproof with B bytecodec for exact same selected bytes. This sister is not the real proof acceptor and supplies no semantic theorem/checker result. Semantic acceptance remains separate realCSource plus one-way independent BVERIFY under same fixed theory/target.'}],'activities':{'subject_import_Compiler_Heap_Lowering_VM_codec_parser_decoder_semantic_helper_test_fixture_CLI':0,'codeobject_execution':0,'unused_compile':False,'model_or_plan_or_authority_or_actual_creation':0},'terminal_state':'IDLE'})
print(json.dumps({'decoder_review':dec_review,'observer_review':obs_review,'full_support':support},indent=2))
