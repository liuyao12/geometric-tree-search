import ast,gzip,hashlib,json,math,pathlib,stat
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');R=Q/'root';A=Q/'actual/qualification-001';OUT=pathlib.Path('/private/tmp/gcts-L-Q-qualification001-whole-custody-review-v1');PRE=pathlib.Path('/private/tmp/gcts-L-Q-worker-observer-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def E(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def eq(a,b):return E(a)==E(b)
def pairs(xs):
 d={}
 for k,v in xs:assert k not in d;d[k]=v
 return d
def J(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def load(p):return J(pathlib.Path(p).read_bytes())
def safe(p):
 p=pathlib.Path(p);assert p.is_absolute() and p.resolve()==p and not any(x.is_symlink() for x in [p,*p.parents]);s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 return ref(p)
def chk(r):
 assert set(r)=={'path','bytes','sha256'} and type(r['path']) is str and type(r['bytes']) is int and r['bytes']>=0 and type(r['sha256']) is str and len(r['sha256'])==64
 a=safe(r['path']);assert eq(a,r),(a,r);return a
def exact(d,keys):assert type(d) is dict and set(d)==set(keys.split())
def save(n,v):
 p=OUT/n;b=(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return ref(p)
planpath=R/'unknown-proof-integration-once-plan-001.json';plan=load(planpath);pr=ref(planpath);callerpath=R/'qualification-001-prospective-caller-v1.json';caller=load(callerpath)
assert pr['sha256']=='5d5b6e874021a573aa4b79cd833b5cc8a92c7a665745bbf9369ab73cb5aedac1';assert ref(callerpath)['sha256']=='0a27ad034fc60fba3e15ec3f5297dd6f1c9928c614c2c169ac71edfbb83fd62e'
sourcepeer=PRE/'Q-worker-observer-complete-independent-Source-review-v2.json';prospective=PRE/'Q-qualification001-complete-independent-prospective-caller-review-v1.json'
assert ref(sourcepeer)['sha256']=='a903ffea08d29f927d0053e1f48fd735b97e89d1761ea9184a8a2234018f0f66'
assert ref(prospective)['sha256']=='ab88b31672bf945f755751ff1d61530790c04d6411af7625933396d2293ed3cf'
const={}
for n in ast.parse(pathlib.Path(plan['sources']['worker']['path']).read_bytes()).body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:const[n.targets[0].id]=ast.literal_eval(n.value)
  except (TypeError,ValueError):pass
exact(plan,'schema case_id actual_dir python sources metadata limits cohort');assert eq(plan['limits'],const['LIMITS']) and eq(plan['python'],const['PYTHON']) and eq(plan['metadata'],const['METADATA_PINS']) and plan['cohort']==const['COHORT']
assert set(plan['sources'])==set(const['SOURCE_PATHS'])
guards=[chk(pr),chk(ref(callerpath))]
for role,r in plan['sources'].items():
 assert r['path']==const['SOURCE_PATHS'][role]
 if role in const['COMPONENT_PINS']:assert eq([r['bytes'],r['sha256']],const['COMPONENT_PINS'][role])
 guards.append(chk(r))
for r in plan['metadata'].values():guards.append(chk(r))
guards.append(chk(plan['python']));guards.append(chk(caller['Source_adoption']));guards.append(chk(caller['bootstrap']))
limits=plan['limits'];assert len(limits)==13
# Complete original owned tool transport is administrative evidence, not a recreated command execution.
transportpath=R/'qualification-001-original-owned-tool-transcript-v1.json';transport=load(transportpath)
assert transport['schema']=='Root-Q-original-owned-exec-transcript-v1';assert transport['initial_exec']['chunk_id']=='58e67d' and transport['initial_exec']['session_id']==31474 and 'exit_code' not in transport['initial_exec'];assert transport['terminal_poll']['chunk_id']=='ca3f89' and type(transport['terminal_poll']['exit_code']) is int and transport['terminal_poll']['exit_code']==0
assert transport['initial_exec']['output']==transport['terminal_poll']['output']==''
outerpaths=[pathlib.Path(x) for x in caller['outer_captures']];outerraw=[p.read_bytes() for p in outerpaths];assert outerraw[1]==b'' and len(outerraw[0])<=limits['log_bytes']
outer=J(outerraw[0]);assert E(outer)==outerraw[0]
exact(outer,'admitted_result_candidate case_id custody owned_file_count owned_named_bytes requires_authoritative_exit_zero schema status')
assert outer['schema']=='GCTS-raw-proof-owned-outer-v1' and outer['status']=='COMPLETE_NORMAL' and outer['requires_authoritative_exit_zero'] is True and outer['case_id']==plan['case_id']
cr=chk(outer['custody']);cust=load(cr['path']);rr=chk(outer['admitted_result_candidate']);result=load(rr['path'])
exact(cust,'schema status version case_id plan authority consumed child captures worker_terminal result all_prior_owned_files Source_and_runtime_pre_post_exact scopes late_costs')
assert cust['schema']=='GCTS-raw-proof-owned-custody-v1' and cust['status']=='NORMAL_TRANSPORT_CANDIDATE' and cust['version']=='GCTS-RAW-PROOF-INTEGRATION-OBSERVER-v2' and cust['Source_and_runtime_pre_post_exact'] is True
assert cust['case_id']==plan['case_id'] and eq(cust['plan'],pr) and eq(cust['result'],rr)
authoritypath=pathlib.Path(caller['authority_target']);ar=chk(cust['authority']);assert str(authoritypath)==ar['path'];authority=load(authoritypath)
exact(authority,'schema authorized uses case_id plan observer');assert authority['schema']=='Root-raw-proof-integration-once-authority-v1' and authority['authorized'] is True and type(authority['uses']) is int and authority['uses']==1 and authority['case_id']==plan['case_id'] and eq(authority['plan'],pr) and eq(authority['observer'],plan['sources']['observer'])
consumedref=chk(cust['consumed']);assert consumedref['path']==str(A/'CONSUMED.json');consumed=load(consumedref['path']);exact(consumed,'schema uses case_id plan authority observer meaning')
assert consumed['schema']=='Root-raw-proof-integration-once-consumed-v1' and type(consumed['uses']) is int and consumed['uses']==1 and consumed['case_id']==plan['case_id'] and eq(consumed['plan'],pr) and eq(consumed['observer'],plan['sources']['observer']) and eq(consumed['authority'],ar) and consumed['meaning']==const['CONSUMED_MEANING']
# Closed 18-file whole census, including current custody, not a prefix.
expected_names={'C1-complete-carrier-mask.json.gz','C1-complete-selected-model.json.gz','C1-full-construction-attempt.json','CONSUMED.json','all-256-physical-choices.json.gz','all-opcode-physical-diagnostic.json.gz','custody.json','grammar-complete.json.gz','physical-mask-and-carrier.json.gz','physical-negative-controls.json','semantic-controls.json.gz','three-complete-fixed-programs.json.gz','wire-resource-controls.json.gz','worker-result.json','worker-stderr-tail.bin','worker-stderr.bin','worker-stdout-tail.bin','worker-stdout.bin'}
paths=sorted(A.iterdir());assert {p.name for p in paths}==expected_names;actuals=[safe(p) for p in paths];total=sum(r['bytes'] for r in actuals)
assert len(actuals)==18 and total==2341330 and outer['owned_file_count']==18 and outer['owned_named_bytes']==total
assert len(actuals)+2<=limits['max_output_files'] and total+sum(len(b) for b in outerraw)<=limits['total_output_bytes'] and all(r['bytes']<=limits['body_bytes'] for r in actuals)
expectedprior=[r for r in actuals if pathlib.Path(r['path']).name!='custody.json'];assert eq(cust['all_prior_owned_files'],expectedprior)
child=cust['child'];exact(child,'child_exit child_lifetime_highwater_bytes cleanup_errors cleanup_signals combined_log_overflow fault launch_mode log_eof owned_wait_complete pid post_Popen_return_to_owned_wait_seconds process_group_gone stream_totals supervisor_exception')
assert type(child['child_exit']) is int and child['child_exit']==0 and child['fault'] is None and child['supervisor_exception'] is None and child['owned_wait_complete'] is True and child['process_group_gone'] is True and child['combined_log_overflow'] is False and child['cleanup_errors']==child['cleanup_signals']==[]
assert child['log_eof']=={'stderr':True,'stdout':True} and type(child['pid']) is int and child['pid']>0
assert type(child['child_lifetime_highwater_bytes']) is int and 0<=child['child_lifetime_highwater_bytes']<=limits['child_rss_bytes']
assert type(child['post_Popen_return_to_owned_wait_seconds']) is float and math.isfinite(child['post_Popen_return_to_owned_wait_seconds']) and child['post_Popen_return_to_owned_wait_seconds']>=0
capturerows={}
for label in ('stdout','stderr'):
 head=chk(cust['captures'][label]);tail=chk(cust['captures'][label+'_tail']);hb=pathlib.Path(head['path']).read_bytes();tb=pathlib.Path(tail['path']).read_bytes();assert type(child['stream_totals'][label]) is int and child['stream_totals'][label]==len(hb);assert tb==hb[-65536:]
 capturerows[label]={'whole':head,'tail':tail,'reported_total':child['stream_totals'][label],'complete_body_not_prefix':True}
assert sum(child['stream_totals'].values())<=limits['log_bytes'] and pathlib.Path(cust['captures']['stderr']['path']).read_bytes()==b''
terminalraw=pathlib.Path(cust['captures']['stdout']['path']).read_bytes();terminal=J(terminalraw);assert E(terminal)==terminalraw and eq(terminal,cust['worker_terminal'])
exact(terminal,'schema status case_id plan result public_calls post_readback_costs unmeasured_tail');assert terminal['schema']=='GCTS-raw-proof-worker-terminal-v1' and terminal['status']=='COMPLETE_COMPONENT_CONTROLS_RESULT_WRITTEN' and terminal['case_id']==plan['case_id'] and eq(terminal['plan'],pr) and eq(terminal['result'],rr)
exact(result,'schema status version case_id plan sources metadata cohort public_calls evidence scope costs_before_result_serialization');assert result['schema']=='GCTS-raw-proof-integration-result-v1' and result['status']=='COMPLETE_COMPONENT_CONTROLS' and result['version']=='GCTS-RAW-PROOF-INTEGRATION-WORKER-v2' and result['case_id']==plan['case_id'] and eq(result['plan'],pr) and eq(result['sources'],plan['sources']) and eq(result['metadata'],plan['metadata']) and result['cohort']==plan['cohort']
assert eq(result['public_calls'],terminal['public_calls'])
expectedcalls=dict(const['EXPECTED_CALL_BASE']);expectedcalls.update(const['EXPECTED_CALL_C1_SELECTED']);assert eq(expectedcalls,result['public_calls']) and sum(expectedcalls.values())==1649 and all(type(n) is int for n in expectedcalls.values())
for costs in (result['costs_before_result_serialization'],terminal['post_readback_costs']):
 exact(costs,'elapsed_main_entry_seconds self_lifetime_highwater_bytes worker_budget_callbacks');assert type(costs['elapsed_main_entry_seconds']) is float and math.isfinite(costs['elapsed_main_entry_seconds']) and 0<=costs['elapsed_main_entry_seconds']<=limits['worker_seconds'];assert type(costs['self_lifetime_highwater_bytes']) is int and 0<=costs['self_lifetime_highwater_bytes']<=limits['child_rss_bytes'];assert type(costs['worker_budget_callbacks']) is int and costs['worker_budget_callbacks']>=0
late=cust['late_costs'];exact(late,'observer_main_entry_elapsed_seconds observer_self_lifetime_highwater_bytes');assert type(late['observer_main_entry_elapsed_seconds']) is float and math.isfinite(late['observer_main_entry_elapsed_seconds']) and 0<=late['observer_main_entry_elapsed_seconds']<=limits['observer_seconds'];assert type(late['observer_self_lifetime_highwater_bytes']) is int and late['observer_self_lifetime_highwater_bytes']>=0
# Follow only result-declared artifact records; full gzip stream read hashes then strict complete JSON syntax, without any semantic verifier.
evidence=result['evidence'];exact(evidence,'C1_construction all_prior_outputs grammar physical programs semantic wire_resource');records=evidence['all_prior_outputs'];assert type(records) is list and len(records)==11
rawchecks=[];decoded={}
for record in records:
 exact(record,'stored encoding raw_bytes raw_sha256');stored=chk(record['stored']);assert pathlib.Path(stored['path']).parent==A
 cap=limits['model_raw_bytes'] if record['encoding']=='gzip-JSON-ASCII-LF' else limits['body_bytes'];assert record['encoding'] in ('gzip-JSON-ASCII-LF','JSON-ASCII-LF') and type(record['raw_bytes']) is int and 0<=record['raw_bytes']<=cap
 chunks=[];n=0;h=hashlib.sha256();op=gzip.open if record['encoding']=='gzip-JSON-ASCII-LF' else open
 with op(stored['path'],'rb') as f:
  while True:
   b=f.read(1048576)
   if not b:break
   n+=len(b);assert n<=cap;h.update(b);chunks.append(b)
 raw=b''.join(chunks);assert n==record['raw_bytes'] and h.hexdigest()==record['raw_sha256'];data=J(raw);assert raw.endswith(b'\n') and raw.decode('ascii') is not None
 decoded[pathlib.Path(stored['path']).name]=data
 rawchecks.append({'record':record,'full_stored_rawpin_match':True,'full_decompressed_or_plain_extent':n,'full_raw_sha256':h.hexdigest(),'complete_strict_JSON_ASCII_LF':True,'canonical_reencoding_not_assumed':'Original numeric dictionary keys may serialize as JSON strings; raw byte hashes, not a reordered decoded JSON image, bind original artifacts.','gzip_full_read_crc_and_trailer_check':record['encoding']=='gzip-JSON-ASCII-LF','scientific_semantic_validation_replayed':False})
assert len({x['record']['stored']['path'] for x in rawchecks})==11
assert set(x['record']['stored']['path'] for x in rawchecks)=={str(p) for p in paths if p.name not in {'CONSUMED.json','custody.json','worker-result.json','worker-stderr.bin','worker-stderr-tail.bin','worker-stdout.bin','worker-stdout-tail.bin'}}
recordmap={x['stored']['path']:x for x in records}
def assoc(r):assert eq(recordmap[r['stored']['path']],r)
for key in ['grammar','programs','semantic','wire_resource']:assoc(evidence[key])
for r in evidence['physical'].values():assoc(r)
assoc(evidence['C1_construction']['evidence'])
construction=decoded['C1-full-construction-attempt.json'];assert construction['status']==evidence['C1_construction']['status']=='UNKNOWN_PHYSICAL_CONSTRUCTION' and construction['attempts']==1 and type(construction['attempts']) is int and construction['physical'] is None and construction['reason']=='construction state cap';assoc(construction['selected']);assoc(construction['genuine_C1_mask']);assert construction['limits']=={'max_operations':20000000,'max_states':200000,'max_transition_choices':1500000}
# End-of-review guards are rehashed, not inherited from runtime flags.
endguards=[]
for r in guards+[ar,consumedref,rr,cr]:endguards.append(chk(r))
assert [safe(p) for p in sorted(A.iterdir())]==actuals
support={'schema':'L-Q-qualification001-whole-custody-and-artifact-support-v1','status':'COMPLETE_STANDARD_DATA_CHECKS_PASS','Source_review':ref(sourcepeer),'prospective_review':ref(prospective),'original_owned_tool_transcript':{'Source':ref(transportpath),'body':transport},'plan':pr,'caller':ref(callerpath),'authority':ar,'consumed':consumedref,'current_pre_and_end_guard_records':endguards,'whole_actual_census':{'files':actuals,'count':18,'bytes':total,'exact_18_names':True,'outer_captures':[safe(x) for x in outerpaths],'actual_plus_outer_bytes':total+sum(len(b) for b in outerraw),'whole_count_plus_outer':20},'outer':outer,'custody':cust,'worker_terminal':terminal,'worker_result_ref':rr,'worker_result_schema_and_metadata':{'schema':result['schema'],'status':result['status'],'version':result['version'],'scope':result['scope'],'public_calls':result['public_calls'],'evidence_links':{'all_prior_output_count':11,'all_named_evidence_associations':True}},'all11_stored_and_raw_full_readback_rows':rawchecks,'captures':capturerows,'construction_gap':construction,'numeric_observations':{'worker_pre_result_serialization':result['costs_before_result_serialization'],'worker_post_result_readback':terminal['post_readback_costs'],'observer_late':late,'post_Popen_return_to_owned_wait_seconds':child['post_Popen_return_to_owned_wait_seconds'],'child_lifetime_highwater_bytes':child['child_lifetime_highwater_bytes']},'boundaries':['No library, Source/helper/checker/solver/VM/compiler/codec invocation or replay. AST only for literal constants; all actual evidence operations are stdlib JSON/gzip/hash/stat/schema/cross-reference comparisons.','Full stored and raw hashes/JSON syntax checked for all11 evidence artifacts, including whole selected-model data; no independent machine/logic/numeric proof replay in this custody lane. B whole saved science review and Root actual admission remain separate.','Recorded runtime guard/consume-before-child control-flow is supported by reviewed immutable Source, matching current input/consume pins and complete owned normal terminal; filesystem chronology alone is not represented as a new proof of launch order.','No parent/child RSS addition, hard OS memory quota, exact simultaneous/process-tree peak, total original tool-duration or cross-clock inequality inferred.','UNKNOWN_PHYSICAL_CONSTRUCTION remains a real current gap. Generic physical diagnostic is not physical FOL execution, strictMachine5, unknown-proof search, discovery or universality.'],'administrative_review_history':'First audit iteration rejected a reordered JSON re-encoding of a raw artifact. This was an administrative canonical-order assumption, not an artifact/hash mismatch; original streamed numeric-key maps may decode to string keys with a different sorted order. Full original raw extent/digest and strict JSON parsing are authoritative; no payload or Source changed.','subject_calls':0}
sr=save('Q-qualification001-complete-independent-custody-artifact-support-v1.json',support)
review={'schema':'L-Q-qualification001-complete-independent-custody-review-v1','decision':'PASS_COMPLETE_SAVED_CUSTODY_AND_ARTIFACT_TRANSPORT_COMPONENT_SCIENCE_SEPARATE','review_passed':True,'blockers':[],'support':sr,'Source_review':ref(sourcepeer),'prospective_caller_review':ref(prospective),'owned_tool_transcript':ref(transportpath),'actual_directory':str(A),'complete_census':{'named_files':18,'actual_bytes':total,'outer_capture_bytes':sum(len(b) for b in outerraw),'all_actual_plus_two_outer_bytes':total+sum(len(b) for b in outerraw),'scientific_artifact_records_full_stored_and_raw_hashes':11},'actual_join':'Original58e67d/session31474 -> authoritative ca3f89 exit0; full original tool metadata and exact reviewed raw outer captures joined. Outer COMPLETE_NORMAL/custody NORMAL_TRANSPORT_CANDIDATE/current worker-result COMPLETE_COMPONENT_CONTROLS all exact links, all18 files including final custody and all11 lossless artifact bodies verified; no prefix selection.','once_and_guards':'Exact current plan8/A6/consumed7 identity/meaning/current10Sources+7metadata+D90/bootstrap and caller/Root Source adoption rawpins verified; current guards rehashed again at review end. Sole authority permanently spent.','capture_cleanup_and_resources':'Worker stdout1527 bytes with identical retained tail; both stderr streams empty; reported complete EOF/owned wait/groupgone/child0/no fault/no overflow/no cleanup errors or signals. Fresh child lifetime highwater209092608 bytes; observer late SELF43384832 separately. Post-Popen-return-to-ownedwait15.311670499999309 seconds, worker main-entry postreadback15.279470124980435, observer main-entry late15.344905874982942; origins and tail scopes distinct, no clock inequality or peak sum asserted. All13 reviewed caps and full census/reserves met.','reported_control_profile':'Whole worker1649 direct calls=1643base+6 selectedC1 conditional. Complete348 authored controls is a worker/profile association pending separate B whole science saved-result review, not independently reexecuted here.','explicit_construction_gap':{'status':'UNKNOWN_PHYSICAL_CONSTRUCTION','reason':'construction state cap','selected_model':'Complete saved selected model and genuine C1 mask fullraw hashes/readbacks verified.','physical_model':None,'attempts':1,'implication':'No current physical FOL acceptance/execution, strictMachine5 expansion, unknown-proof search, proof discovery, universality or GCTS benefit claim. No retry or prefix promotion.'},'separate_admission':'B whole saved science review and Root complete postdata adoption required for scientific admission; this PASS closes only independent whole custody/caller/guard/artifact transport lane. No new grant/publication performed.','reviewer_subject_calls':0,'terminal_state':'REVIEW_COMPLETE_ALL_TOOLS_TERMINAL_IDLE'}
rr2=save('Q-qualification001-complete-independent-custody-review-v1.json',review)
print(json.dumps({'review':rr2,'support':sr,'full_census':{'files':len(actuals),'bytes':total,'raw_artifact_bytes':sum(x['full_decompressed_or_plain_extent'] for x in rawchecks),'actual_plus_outer_bytes':total+sum(len(b) for b in outerraw)}},indent=2))
