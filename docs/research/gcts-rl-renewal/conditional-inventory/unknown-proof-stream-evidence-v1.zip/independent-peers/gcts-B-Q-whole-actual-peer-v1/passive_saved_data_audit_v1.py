"""Administrative saved-data joins only. No subject imports, decoder or machine replay."""
from pathlib import Path
import json,gzip,hashlib,math,struct,collections,stat
Q=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');D=Q/'actual/qualification-001';O=Path('/private/tmp/gcts-B-Q-whole-actual-peer-v1')
H=lambda b:hashlib.sha256(b).hexdigest()
def canon(v):return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def demand(v,m):
 if not v:raise RuntimeError(m)
def equal(a,b,m):demand(canon(a)==canon(b),m)
def pairs(items):
 d={}
 for k,v in items:demand(k not in d,'duplicate JSON');d[k]=v
 return d
def parse(b):return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def rr(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=H(b))
def auth(r):
 p=Path(r['path']);demand(set(r)=={'path','bytes','sha256'} and type(r['bytes'])is int and r['bytes']>=0,'ref type');demand(p.is_absolute()and not p.is_symlink()and p.stat().st_nlink==1,'filetype');equal(rr(p),r,'full rawref');return p.read_bytes()
# Every saved JSON value is traversed, finite and of the closed native type profile.
def census(v):
 ct=collections.Counter();todo=[v]
 while todo:
  x=todo.pop();ct[type(x).__name__]+=1
  if type(x)is dict:
   demand(all(type(k)is str for k in x),'keytype');todo.extend(x);todo.extend(x.values())
  elif type(x)is list:todo.extend(x)
  elif type(x)is float:demand(math.isfinite(x),'finite')
  else:demand(x is None or type(x)in(str,int,bool),'valueprofile')
 return dict(ct)
rawfiles={p.name:p.read_bytes()for p in sorted(D.iterdir())};demand(len(rawfiles)==18 and sum(map(len,rawfiles.values()))==2341330,'full physical extent')
refs=[rr(D/n)for n in rawfiles]
result=parse(rawfiles['worker-result.json']);custody=parse(rawfiles['custody.json']);terminal=parse(rawfiles['worker-stdout.bin']);consume=parse(rawfiles['CONSUMED.json']);outerraw=(Q/'root/qualification-001-outer-stdout.bin').read_bytes();outer=parse(outerraw);trans=parse((Q/'root/qualification-001-original-owned-tool-transcript-v1.json').read_bytes())
demand(trans['initial_exec']['chunk_id']=='58e67d' and trans['initial_exec']['session_id']==31474 and trans['terminal_poll']['chunk_id']=='ca3f89'and trans['terminal_poll']['exit_code']==0,'original exec exit')
demand((Q/'root/qualification-001-outer-stderr.bin').read_bytes()==b'','outer stderr');demand(rawfiles['worker-stderr.bin']==rawfiles['worker-stderr-tail.bin']==b'','inner stderr');equal(terminal,custody['worker_terminal'],'terminal entirety');demand(canon(terminal)==rawfiles['worker-stdout.bin']==rawfiles['worker-stdout-tail.bin'],'canonical full inner stdout');demand(canon(outer)==outerraw,'canonical outer')
equal(outer['custody'],rr(D/'custody.json'),'outer custody');equal(outer['admitted_result_candidate'],rr(D/'worker-result.json'),'outer result');demand(outer['owned_file_count']==18 and outer['owned_named_bytes']==2341330,'outer counts')
equal(custody['all_prior_owned_files'],[r for r in refs if Path(r['path']).name!='custody.json'],'full custody census');equal(custody['result'],terminal['result'],'resultassoc');auth(terminal['result']);equal(result['plan'],custody['plan'],'planassoc');equal(terminal['plan'],result['plan'],'terminalplan')
plan=parse(auth(result['plan']));authority=parse(auth(custody['authority']));equal(consume['plan'],result['plan'],'consumeplan');equal(consume['authority'],custody['authority'],'consumeauthority');equal(consume['observer'],plan['sources']['observer'],'consumeobserver');equal(custody['consumed'],rr(D/'CONSUMED.json'),'consumeref');equal(authority['plan'],result['plan'],'A6plan');equal(authority['observer'],plan['sources']['observer'],'A6observer');demand(authority['authorized']is True and type(authority['uses'])is int and authority['uses']==1,'A6 flags');demand(consume['uses']==1 and type(consume['uses'])is int,'consumeuses')
demand(set(plan)=={'schema','case_id','actual_dir','python','sources','metadata','limits','cohort'},'plan8');equal(result['sources'],plan['sources'],'sourceassociation');equal(result['metadata'],plan['metadata'],'ABIassociation');guards=[]
for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python']]:auth(r);guards.append(r)
demand(result['status']=='COMPLETE_COMPONENT_CONTROLS' and result['version']=='GCTS-RAW-PROOF-INTEGRATION-WORKER-v2','currentresult');demand(custody['status']=='NORMAL_TRANSPORT_CANDIDATE'and custody['Source_and_runtime_pre_post_exact']is True,'custody');ch=custody['child'];demand(ch['child_exit']==0 and ch['fault']is None and ch['owned_wait_complete']is True and ch['process_group_gone']is True and all(ch['log_eof'].values())and ch['cleanup_errors']==ch['cleanup_signals']==[],'normalchild');demand(ch['stream_totals']=={'stdout':1527,'stderr':0},'streambytes')
artifacts={};artifact_rows=[]
for a in result['evidence']['all_prior_outputs']:
 stored=auth(a['stored']);raw=gzip.decompress(stored)if a['encoding']=='gzip-JSON-ASCII-LF'else stored;demand(len(raw)==a['raw_bytes']and H(raw)==a['raw_sha256'],'full decompressed extent/digest');v=parse(raw);demand(canon(v)==raw,'complete canonical artifact');name=Path(a['stored']['path']).name;artifacts[name]=v;artifact_rows.append(dict(name=name,artifact=a,all_values=census(v)))
demand(set(artifacts)==set(rawfiles)-{'worker-result.json','custody.json','CONSUMED.json','worker-stdout.bin','worker-stdout-tail.bin','worker-stderr.bin','worker-stderr-tail.bin'},'all original science artifacts')
programs=artifacts['three-complete-fixed-programs.json.gz'];g=artifacts['grammar-complete.json.gz'];s=artifacts['semantic-controls.json.gz'];wire=artifacts['wire-resource-controls.json.gz'];pm=artifacts['physical-mask-and-carrier.json.gz'];choices=artifacts['all-256-physical-choices.json.gz'];diag=artifacts['all-opcode-physical-diagnostic.json.gz'];selected=artifacts['C1-complete-selected-model.json.gz'];cm=artifacts['C1-complete-carrier-mask.json.gz'];construction=artifacts['C1-full-construction-attempt.json'];negative=artifacts['physical-negative-controls.json']
# Hash/identity bindings for compiler declarations and all carrier base rows, without evaluating DSL/JSON heap.
native_rows=[]
def native_join(n,raw,program,role):
 c=n['carrier']['value'];demand(n['input_role']==role and n['input_node']==c[role],'actual native entry');equal(c['program_sha256'],H(canon(program)),'carrier program hash');equal(c['nodes'][:c['program_prefix_nodes']],program['nodes'],'exact compiler prefix');demand(c['byte_count']==len(raw)==len(c['byte_rows']),'byteextent');equal(n['choice_check']['byte_values'],list(raw),'all selected bytes');demand(n['choice_check']['status']=='VERIFIED','choicecheck')
 variable={r['node_index']:r for r in c['byte_rows']};demand(len(variable)==len(raw),'distinct rows');demand(len(n['initial_nodes'])==len(c['nodes']),'full initialheap extent')
 for i,(a,b)in enumerate(zip(n['initial_nodes'],c['nodes'],strict=True)):
  if i in variable:
   r=variable[i];demand(r['node_id']==i+257 and r['domain']=={'all_values_allowed':True,'minimum':0,'maximum':255},'full byte domains');demand(a[0]==raw[r['byte_index']]and a[1]==b[1]==r['marker_id'],'onlyselectedheads')
  else:equal(a,b,'every fixed initialheap record')
 equal(n['final_nodes'][:len(n['initial_nodes'])],n['initial_nodes'],'readonly append-only initial heap');demand(n['vm']['heap_nodes']==len(n['final_nodes']),'fullfinalheapextent');demand(n['vm']['steps']<=plan['limits']['native_steps'],'nativestepsbound')
 for i,row in enumerate(n['final_nodes']):demand(type(row)is list and len(row)==2 and all(type(v)is int and 0<=v<i+257 for v in row),'whole canonical earlier refs')
 demand(len({tuple(row)for row in n['final_nodes']})==len(n['final_nodes']),'whole uniqueheap')
 native_rows.append(dict(input_role=role,initial_nodes=len(n['initial_nodes']),final_nodes=len(n['final_nodes']),steps=n['vm']['steps'],status=n['vm']['status'],value=n['vm'].get('value'),native_full_sha256=H(canon(n))))
rows=[];demand(g['normal']==18 and g['malformed']==16 and len(g['records'])==34,'grammar census')
for i,r in enumerate(g['records']):
 dec=r['decoder'];raw=bytes.fromhex(r['encoder']['stream_hex']if i<18 else r['stream_hex']);native_join(r['native'],raw,programs['observation'],'stream_node')
 if i<18:
  demand(r['id']=='G%02d'%(i+1)and r['encoder']['status']==dec['status']=='COMPLETE','normalgrammar');equal(dec['proof'],r['authored_proof'],'complete authoreddec equality');equal(r['observed_JSON']['value'],dec['proof'],'fullactualobserved AST');demand(r['observed_JSON']['status']=='DECODED'and r['native']['vm']['status']=='rejected'and type(r['native']['vm']['value'])is int and r['native']['vm']['value']>256,'normalnonbool node');demand(dec['offset']==dec['counts']['bytes_read']==len(raw),'full byte consumption');demand(r['encoder']['counts']['bytes_emitted']==len(raw),'encodedextent')
 else:demand(dec['status']=='REJECTED'and dec['proof']is None and r['native']['vm']['status']=='rejected'and r['native']['vm']['value']==0,'malformednormalfalse')
 rows.append(dict(group='grammar',id=r['id'],full_record_sha256=H(canon(r)),status=dec['status'],vm_status=r['native']['vm']['status'],vm_value=r['native']['vm']['value'],bytes=len(raw),full_actual_AST_equal=i<18))
demand(len(s['records'])==12 and s['one_way_only']is True,'semanticcensus')
for r in s['records']:
 f=r['authored'];raw=bytes.fromhex(r['encoder']['stream_hex']);dec=r['decoder'];demand(dec['status']==r['encoder']['status']=='COMPLETE','complete semanticbytes');equal(dec['proof'],f['proof'],'semantic complete authoredproof');native_join(r['native'],raw,programs['real'],'input_node');equal(r['native']['carrier']['value']['known']['theory'],f['theory'],'fixedtheory');equal(r['native']['carrier']['value']['known']['target'],f['target'],'fixedtarget');v=r['native']['vm'];demand(v['value']==int(f['tree_accept'])and v['status']==('accepted'if f['tree_accept']else'rejected'),'semantic normalreturn');demand(r['independent']['status']==f['independent_status'],'independent verdict');demand(not f['tree_accept']or r['independent']['status']=='VERIFIED','onewayverified')
 rows.append(dict(group='semantic',id=r['id'],full_record_sha256=H(canon(r)),status=r['independent']['status'],tree_status=v['status'],tree_value=v['value'],bytes=len(raw)))
demand(collections.Counter(r['independent']['status']for r in s['records'])=={'VERIFIED':9,'REJECTED':3},'semantic counts')
# All wire result envelopes, declared status/exception classes, full source-authored negatives; no reevaluation.
demand(len(wire['records'])==38 and len({r['id']for r in wire['records']})==38,'wirecensus')
for r in wire['records']:
 name=r['id'];v=r.get('return',{});status=v.get('status',v.get('exception_type'))
 if name=='native-zero-step':
  n=r['native'];demand(n['vm']['status']=='unknown_step_budget'and n['vm']['steps']==0 and 'value'not in n['vm'],'zeroUNKNOWN');native_join(n,bytes.fromhex(g['records'][2]['encoder']['stream_hex']),programs['observation'],'stream_node');status='unknown_step_budget'
 elif name.startswith('codec-cap-'):demand(status=='UNKNOWN_BUDGET'and v['proof']is None and v['stream_hex']is None,'codec cap unknown')
 elif name.startswith('heap-cap-')or name=='heap-repeated-DAG-cap':demand(status=='UNKNOWN_BUDGET'and v['value']is None,'heap cap unknown')
 elif name.startswith('heap-tag-')or name=='heap-repeated-DAG':demand(status=='DECODED','heap tag data')
 elif name.startswith('carrier-tamper-')or name=='carrier-wrong-role-root':demand(status=='CarrierError','carriernegative')
 elif name.startswith('carrier-cap-'):demand(status=='CarrierBudgetExceeded','carriercap')
 elif name=='foreign-callback':demand(status=='ForeignSentinel','foreigncallback')
 else:demand(status=='REJECTED','syntaxnegative')
 rows.append(dict(group='wire_resource',id=name,status=status,reason=v.get('reason',v.get('message')),full_record_sha256=H(canon(r))))
# Exact saved data correspondence for every mask choice, including correlated LEu32 alternatives.
mask=pm['mask']['value'];cv=pm['carrier']['value'];equal(pm['program'],programs['diagnostic'],'diagnosticprogram');equal(pm['selected'],diag['selected'],'diagnostic selected');equal(mask['carrier_value_sha256'],H(canon(cv)),'mask carriervaluehash');equal(mask['program_sha256'],H(canon(pm['program'])),'mask programhash');equal(mask['lowering_sha256'],H(canon(pm['selected'])),'masklowerhash');demand(mask['byte_count']==cv['byte_count']==1 and len(mask['unknown_bits'])==len(mask['binary_symbol_domains'])==8,'8bitmask')
unknown={x['physical_cell']:x for x in mask['unknown_bits']};demand(len(unknown)==8,'distinctphysicalbits');template=bytes(mask['binary_input_template']);free={x['byte_offset']+k for x in mask['binary_symbol_domains']for k in range(4)};expected_free=set()
for u,b in zip(mask['unknown_bits'],mask['binary_symbol_domains'],strict=True):
 demand(u['bit']==b['bit']and u['physical_cell']==b['physical_cell']and u['weight']==1<<u['bit']and b['byte_offset']==4*b['file_word_index'],'bit domain mapping');demand(u['symbols']==b['symbol_names']==['0','1'],'literal symbols');demand(b['symbol_ids']==[mask['alphabet'].index('0'),mask['alphabet'].index('1')],'alphabetordinals')
 for k,id in enumerate(b['symbol_ids']):equal(b['little_endian_uint32_alternatives'][k],list(struct.pack('<I',id)),'correlated LEword')
 expected_free.add(u['physical_cell'])
demand(len(choices['records'])==256,'allchoices')
for byte,r in enumerate(choices['records']):
 demand(r['byte']==byte,'exact256order');t=r['physical_tape'];b=bytes.fromhex(r['binary_hex']);demand(len(t)==len(mask['physical_template'])and len(b)==len(template),'choiceextents')
 for check in ('heap_check','symbol_check','binary_check'):demand(r[check]['status']=='VERIFIED'and r[check]['byte_values']==[byte],'fullchoicechecks')
 for i,(v,base)in enumerate(zip(t,mask['physical_template'],strict=True)):
  if i in unknown:u=unknown[i];demand(v==u['symbols'][(byte>>u['bit'])&1],'actualbitliteral')
  else:demand(v==base,'everyfixedsymbol')
 demand(all(x==template[i]for i,x in enumerate(b)if i not in free),'everyfixedbinarybyte')
 for z in mask['binary_symbol_domains']:equal(list(b[z['byte_offset']:z['byte_offset']+4]),z['little_endian_uint32_alternatives'][(byte>>z['bit'])&1],'entirechosen LEword')
 demand(struct.unpack_from('<I',b,0)[0]==0x47544931,'GTI1magic');header=struct.unpack_from('<'+'I'*len(mask['binary_header_words']),b,0);equal(list(header),mask['binary_header_words'],'wholeGTI1header')
 ords=struct.unpack_from('<'+'I'*len(t),b,4*len(header));demand(all(mask['alphabet'][k]==v for k,v in zip(ords,t,strict=True)),'whole tape-to-binary saved association')
 rows.append(dict(group='all_byte_choices',id=byte,full_record_sha256=H(canon(r)),status='VERIFIED_THREE_VIEWS',physical_symbols=len(t),binary_bytes=len(b)))
# Diagnostic saved trace/index/data associations; do not execute any transition or instruction.
equal(diag['program'],programs['diagnostic'],'fullfixeddiag');demand(diag['native']['status']==diag['virtual']['status']==diag['literal']['status']=='accepted'and diag['native']['value']==1,'triple accepted');opset=sorted({x[2]for x in diag['native']['trace']});equal(opset,diag['declared_opcodes'],'all actual opcodes');demand(len(opset)==13 and len(diag['native']['trace'])==diag['native']['steps']==79 and diag['native']['peak_frames']==2,'13opcoverage');demand(diag['literal']['steps']==diag['virtual']['physical_steps']==5645913,'samephysicalstepcount');demand(diag['literal']['state']==diag['virtual']['state']==diag['physical']['accept'],'terminalstate');equal(diag['native_final_nodes'],[[0,256]],'saved whole finalheap');demand(diag['virtual']['words'][diag['selected']['heap']]=='100000001:00000000,000000001;','full saved selectedheap encoding');demand(int(diag['virtual']['words'][diag['selected']['work']][::-1],2)==diag['native']['value'],'fullreturned word')
# Full final physical tape bands can be compared directly with saved words/heads/capacities, not replayed.
tape=diag['literal']['tape'];pos=1;demand(tape[0]=='L','physicalleft')
for i,(word,head,cap)in enumerate(zip(diag['virtual']['words'],diag['virtual']['heads'],diag['initial']['capacities'],strict=True)):
 demand(tape[pos]=='S'+str(i),'physical fixedbandheader');band=tape[pos+1:pos+1+cap];demand(len(band)==cap,'fullbandextent');base='^'+word;demand(len(base)<=cap and 0<=head<cap,'wordextent/head')
 for j,value in enumerate(band):
  literal=base[j]if j<len(base)else'B';demand(value==('@'+literal if j==head else literal),'complete saved selected/physical finaltape')
 demand(tape[pos+1+cap]=='#','banddelimiter');pos+=cap+2
demand(pos==len(tape),'full finaltape consumed')
rows.append(dict(group='diagnostic',id='OP13',status='THREE_ACCEPTED_FULL_FINAL_STATE_BOUND',full_record_sha256=H(canon(diag)),native_steps=79,selected_steps=diag['virtual']['micro_steps'],physical_steps=diag['literal']['steps'],opcodes=opset))
demand(len(negative)==6,'sixphysicalnegatives');equal([x['exception_type']for x in negative],['CarrierError']*2+['CarrierBudgetExceeded']*2+['ConstructionBudgetExceeded']*2,'narrownegativeclasses')
for i,r in enumerate(negative):rows.append(dict(group='physical_negative',id=i,status=r['exception_type'],reason=r['message'],full_record_sha256=H(canon(r))))
# Genuine realprogram C1 compiled/known/selected/mask joins; no physical computation result exists.
equal(selected['program'],programs['real'],'fullC1compiled');cs=selected['selected'];cr=selected['construction'];demand(len(cs['rows'])==cr['states']==126775 and cr['transition_choices']==595476 and cr['operations']==953236,'whole selectedreceipt');equal(cr['limits'],construction['limits'],'constructioncaps');equal(cm['carrier']['value']['program_sha256'],H(canon(programs['real'])),'C1realprogramhash');equal(cm['mask']['value']['lowering_sha256'],H(canon(cs)),'C1wholelowerhash');equal(cm['mask']['value']['carrier_value_sha256'],H(canon(cm['carrier']['value'])),'C1carriervaluehash');demand(cm['input_role']=='input_node'and cm['mask']['value']['input_node']==cm['carrier']['value']['input_node']==548,'genuineC1inputroot');demand(cm['carrier']['value']['byte_count']==1 and len(cm['mask']['value']['unknown_bits'])==8,'C1unselected8bits');demand(construction['attempts']==1 and construction['status']=='UNKNOWN_PHYSICAL_CONSTRUCTION'and construction['physical']is None and construction['reason']=='construction state cap','actualUNKNOWNphysical');demand(not any('physical-model'in n for n in rawfiles),'no physical FOLmodelorresult');equal(result['evidence']['C1_construction']['status'],construction['status'],'constructionsummary');rows.append(dict(group='C1_construction',id='real-C1',status=construction['status'],full_record_sha256=H(canon(construction)),selected_states=cr['states'],selected_choices=cr['transition_choices'],selected_operations=cr['operations']))
# Exact full public counts from the frozen ABI; no replay to obtain expected values.
abi=parse((Q/'implementation-C/qualification-worker-observer-complete-public-ABI-v2.json').read_bytes());expected=dict(abi['plan_constants']['EXPECTED_CALL_BASE']);expected.update(abi['plan_constants']['EXPECTED_CALL_C1_SELECTED']);equal(result['public_calls'],expected,'full1649 public calls');equal(terminal['public_calls'],expected,'terminal calls');demand(sum(expected.values())==1649 and len(rows)==348,'whole census348/1649');equal(plan['limits'],abi['plan_constants']['LIMITS'],'samecaps');demand(result['cohort']==plan['cohort']==abi['plan_constants']['COHORT'],'samecohort')
for r in refs:demand(r['bytes']<=plan['limits']['body_bytes'],'allbodycap')
demand(len(refs)+2<=plan['limits']['max_output_files']and sum(x['bytes']for x in refs)+plan['limits']['log_bytes']<=plan['limits']['total_output_bytes'],'completeoutputcaps');demand(terminal['post_readback_costs']['self_lifetime_highwater_bytes']==ch['child_lifetime_highwater_bytes']==209092608<=plan['limits']['child_rss_bytes'],'RSSjoin');demand(terminal['post_readback_costs']['elapsed_main_entry_seconds']<=plan['limits']['worker_seconds']and custody['late_costs']['observer_main_entry_elapsed_seconds']<=plan['limits']['observer_seconds'],'clockscopes')
summary={'schema':'B-Q-whole-saved-data-passive-support-v1','decision':'PASS_COMPLETE_SAVED_DATA_RELATIONAL_JOINS','prefreeze':rr(O/'Q-whole-actual-prefrozen-passive-review-expectations-v1.json'),'raw_originals':refs,'raw_original_count':18,'raw_original_bytes':2341330,'outer_stdout':rr(Q/'root/qualification-001-outer-stdout.bin'),'outer_stderr':rr(Q/'root/qualification-001-outer-stderr.bin'),'original_owned_transcript':rr(Q/'root/qualification-001-original-owned-tool-transcript-v1.json'),'plan':result['plan'],'authority':custody['authority'],'consume':rr(D/'CONSUMED.json'),'all_current_Source_ABI_runtime_pins':guards,'all_artifact_stored_raw_complete_joins':artifact_rows,'all_348_control_dispositions':rows,'all_47_native_heap_entry_byte_joins':native_rows,'current_whole_public_calls':expected,'program_full_canonical_hashes':{k:H(canon(v))for k,v in programs.items()},'complete_own_data_fields':{'result':census(result),'custody':census(custody),'terminal':census(terminal)},'entire_full_scientific_JSON_value_profile':dict(sum((collections.Counter(x['all_values'])for x in artifact_rows),collections.Counter())),'C1_selected':cr,'construction_status':construction['status'],'costs':{'before_serialization':result['costs_before_result_serialization'],'post_readback':terminal['post_readback_costs'],'child':{k:v for k,v in ch.items()if k in('child_lifetime_highwater_bytes','post_Popen_return_to_owned_wait_seconds')},'observer_late':custody['late_costs']},'no_subject_calls':True,'method':'Closed saved records strictJSON/gzip/hash/type/key/list/arithmetic/equality, complete allvalue traversal and hand reasoning; no subject import/helper/grammar or logical decode/VM/lowering/constructor/model/fixture/replay executed.'}
f=O/'Q-whole-saved-data-complete-passive-support-v1.json';b=(json.dumps(summary,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode();f.write_bytes(b);print(f,len(b),H(b));print('rows',len(rows),'native',len(native_rows),'profile',summary['entire_full_scientific_JSON_value_profile'])
