import ast,hashlib,json,pathlib,re,symtable,sys
Q=pathlib.Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');C=Q/'implementation-C';OUT=pathlib.Path('/private/tmp/gcts-L-Q-publication-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def J(p):return json.loads(pathlib.Path(p).read_bytes())
def check(r):a=ref(r['path']);assert a==r;return a
def raw(b,n):return b''.join(b.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
def apply(b,patch):
 src=b.decode().splitlines(keepends=True);ps=patch.decode().splitlines(keepends=True);out=[];i=0;k=2
 while k<len(ps):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',ps[k]);assert m;pos=int(m[1])-1;out.extend(src[i:pos]);i=pos;k+=1
  while k<len(ps) and not ps[k].startswith('@@ '):
   x=ps[k];k+=1
   if x.startswith(' '):assert src[i]==x[1:];out.append(src[i]);i+=1
   elif x.startswith('-'):assert src[i]==x[1:];i+=1
   elif x.startswith('+'):out.append(x[1:])
   else:raise AssertionError(x)
 out.extend(src[i:]);return ''.join(out).encode()
def scopes(st):
 rows=[]
 def walk(x,path=''):
  flags=[]
  for s in x.get_symbols():flags.append([s.get_name(),s.is_local(),s.is_global(),s.is_free(),s.is_imported(),s.is_assigned(),s.is_referenced(),s.is_parameter(),s.is_namespace()])
  rows.append({'path':path+x.get_name(),'line':x.get_lineno(),'type':str(x.get_type()),'all_symbol_flags':flags})
  for child in x.get_children():walk(child,path+x.get_name()+'.')
 walk(st);return rows
hp=C/'unknown-proof-stream-publication-complete-inert-Source-handoff-v1.json';assert ref(hp)['sha256']=='e29e817f8ea87a8b330926318845de797984fbd28056c4f0a2799f7a0d7f10b6';handoff=J(hp)
pins=[ref(hp)]
for r in list(handoff['subjects'].values())+list(handoff['supporting_records'].values())+handoff['four_patches']:pins.append(check(r))
abi=J(handoff['supporting_records']['public_ABI']['path']);manual=J(handoff['supporting_records']['complete_helper_walkthrough']['path']);pres=J(handoff['supporting_records']['complete_literal_preservation']['path']);static=J(handoff['supporting_records']['complete_static']['path']);proof=[];allrows={};const={}
for rec in pres['records']:
 role=rec['role'];pins.append(check(rec['base']));check(rec['current']);before=pathlib.Path(rec['base']['path']).read_bytes();after=pathlib.Path(rec['current']['path']).read_bytes();tree=ast.parse(after);base_tree=ast.parse(before)
 # Every direct changed string and count independently applied; no other raw delta.
 transformed=before.decode()
 for sub in rec['literal_substitutions']:
  assert transformed.count(sub['old'])==sub['occurrences'];transformed=transformed.replace(sub['old'],sub['new'])
 assert transformed.encode()==after
 inverse=apply(after,pathlib.Path(rec['patches'][1]['path']).read_bytes())
 assert inverse==before
 assert ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(base_tree,include_attributes=True)
 f,i=rec['patches'];assert apply(before,pathlib.Path(f['path']).read_bytes())==after;assert apply(after,pathlib.Path(i['path']).read_bytes())==before
 compile(after,rec['current']['path'],'exec',dont_inherit=True)
 sc=scopes(symtable.symtable(after.decode(),rec['current']['path'],'exec'));bs=scopes(symtable.symtable(before.decode(),rec['base']['path'],'exec'));assert sc==bs
 imports=[ast.unparse(x) for x in tree.body if isinstance(x,(ast.Import,ast.ImportFrom))];assert imports==[ast.unparse(x) for x in base_tree.body if isinstance(x,(ast.Import,ast.ImportFrom))]
 top={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};oldtop={n.name:n for n in base_tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};assert set(top)==set(oldtop)
 rows=[]
 def walk(ns,parent=''):
  for n in ns:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    rows.append({'name':parent+n.name,'lines':[n.lineno,n.end_lineno],'raw_bytes':len(raw(after,n)),'raw_sha256':H(raw(after,n)),'AST_sha256':H(ast.dump(n,include_attributes=False).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'signature':None if isinstance(n,ast.ClassDef) else ast.unparse(n.args),'all_call_targets':sorted(set(ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call))),'branches':{'if':sum(isinstance(x,ast.If) for x in ast.walk(n)),'for':sum(isinstance(x,ast.For) for x in ast.walk(n)),'while':sum(isinstance(x,ast.While) for x in ast.walk(n)),'try':sum(isinstance(x,ast.Try) for x in ast.walk(n)),'raise':sum(isinstance(x,ast.Raise) for x in ast.walk(n))}})
    walk(n.body,parent+n.name+'.')
 walk(tree.body)
 # Complete author's current tophelper fingerprints/manual and own full nested walk.
 for record in rec['top_helpers']:
  n=top[record['name']];assert record['raw_sha256']==H(raw(after,n)) and record['AST_sha256']==H(ast.dump(n,include_attributes=False).encode()) and record['positioned_AST_sha256']==H(ast.dump(n,include_attributes=True).encode())
 for record in manual['helpers']:
  if record['role']==role:assert record['raw_sha256']==H(raw(after,top[record['helper']]))
 assert {m['helper'] for m in manual['helpers'] if m['role']==role}==set(top)
 for record in static['records'][role]['top_helpers']:
  n=top[record['name']];assert record['raw_sha256']==H(raw(after,n)) and record['AST_sha256']==H(ast.dump(n,include_attributes=False).encode()) and record['positioned_AST_sha256']==H(ast.dump(n,include_attributes=True).encode())
 assert static['records'][role]['whole_AST_sha256']==H(ast.dump(tree,include_attributes=False).encode())
 assert static['records'][role]['whole_positioned_AST_sha256']==H(ast.dump(tree,include_attributes=True).encode())
 unchanged=[name for name in top if raw(after,top[name])==raw(before,oldtop[name])];assert len(unchanged)==rec['raw_unchanged_top_helper_count']
 # Numeric and structural AST nodes unchanged; only strings differ at same positioned locations.
 strings=[]
 def pair(a,b,path='$'):
  assert type(a)==type(b),path
  if isinstance(a,ast.AST):
   assert list(ast.iter_fields(a)) and [k for k,_ in ast.iter_fields(a)]==[k for k,_ in ast.iter_fields(b)] or not list(ast.iter_fields(a))
   for k,v in ast.iter_fields(a):pair(v,getattr(b,k),path+'.'+k)
  elif type(a) is list:
   assert len(a)==len(b),path
   for index,(x,y) in enumerate(zip(a,b)):pair(x,y,path+'['+str(index)+']')
  elif a!=b:
   assert type(a) is str,(path,a,b);strings.append({'path':path,'old':a,'new':b})
 pair(base_tree,tree)
 constants={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:constants[n.targets[0].id]=ast.literal_eval(n.value)
   except (TypeError,ValueError):pass
 const[role]=constants
 allrows[role]={'Source':rec['current'],'top_helper_count':len(top),'all_named_definition_count':len(rows),'full_named_helper_fingerprints_signatures_calls_branches':rows,'all_symtable_scopes':sc,'scope_count':len(sc),'imports':imports,'unused_compile':True,'whole_AST_sha256':H(ast.dump(tree,include_attributes=False).encode()),'whole_positioned_AST_sha256':H(ast.dump(tree,include_attributes=True).encode())}
 proof.append({'role':role,'base':rec['base'],'current':rec['current'],'literal_substitutions':rec['literal_substitutions'],'all_actual_AST_string_differences':strings,'all_numeric_structural_nodes_exact':True,'complete_raw_forward_inverse_both_patches':True,'whole_positioned_AST_inverse':True,'all_symtables_identical':True,'imports_identical':True,'raw_unchanged_top_helper_names':unchanged,'changed_only_literals_top_helper_names':[x for x in top if x not in unchanged],'forward':f,'inverse':i})
assert const['publisher']['EXPECTED_PARENT']=='932d397dbdac3be5baa27eb07bbe253d89481880';assert const['publisher']['EXPECTED_TREE']=='5fc5c568cfe29c70ec9104cf2970eff138ffbb3a';assert const['publisher']['EXPECTED_API_CALLS']==12
names=('unknown-proof-stream-v1.html','unknown-proof-stream-results-v1.json','unknown-proof-stream-evidence-v1.zip');caps=(1048576,8388608,33554432)
assert const['publisher']['NAMES']==const['verifier']['NAMES']==names;assert const['publisher']['PAYLOAD_CAPS']==const['verifier']['CAPS']==caps
assert abi['fixed_targets']==['docs/research/gcts-rl-renewal/conditional-inventory/'+n for n in names];assert const['publisher']['PYTHON']==const['verifier']['PYTHON'];pins.append(check(const['publisher']['PYTHON']))
assert len(manual['helpers'])==41 and len(allrows['publisher']['full_named_helper_fingerprints_signatures_calls_branches'])==31 and len(allrows['verifier']['full_named_helper_fingerprints_signatures_calls_branches'])==20
exp=ref(OUT/'Q-publication-pair-prefrozen-complete-Source-review-expectations-v1.json')
def save(n,d):
 p=OUT/n;b=(json.dumps(d,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode()
 with p.open('xb') as f:f.write(b)
 return ref(p)
support={'schema':'L-Q-publication-complete-independent-static-preservation-support-v1','status':'PASS_STATIC_ALL_SUBJECTS_UNRUN','prefrozen_expectations':exp,'all_direct_pins':pins,'runtime':ref(sys.executable),'runtime_version':sys.version,'all_current_helpers_scopes_calls_branches':allrows,'whole_derivative_proofs':proof,'public_ABI':handoff['supporting_records']['public_ABI'],'literal_constants':const,'administrative_history':'Initial administrative reverse-str.replace attempted overlapping substring substitutions and failed; using full exact inverse patches is the correct unambiguous reconstruction. Full literal forward transform and all4 forward/inverse patches independently recover exact Sources; no subject changed.','mode':'D90 -I -S -B stdlib AST/symtable/unusedcompile/rawhash/textdiff only; no subject import or function/CLI/network invocation.','subject_calls':0,'network_calls':0,'payloads_read':0,'authorities_or_staging_created':0}
sr=save('Q-publication-pair-complete-independent-static-support-v1.json',support)
review={'schema':'L-Q-publication-pair-complete-independent-Source-peer-review-v1','decision':'PASS_COMPLETE_CURRENT_SOURCES_UNRUN','review_passed':True,'blockers':[],'prefrozen_expectations':exp,'Source':handoff['subjects'],'handoff':ref(hp),'public_ABI':handoff['supporting_records']['public_ABI'],'support':sr,'review_coverage':'Both entire Sources and all41 top helpers,51 full named definitions,all nested helper/call/branch paths,complete publicABI/manual/literal-delta records read; full own raw/AST/positionedAST/symtable/unusedcompile/helper joins. All4 full patches applied both directions in memory; exact old raw bodies and positionedAST recovered.','derivative':{'publisher':'Exact declared10 substitution classes/20 rawunchanged tophelpers,4 onlyliteral changed; all24 tophelpers preserved.','verifier':'Exact declared7 substitution classes/14 rawunchanged tophelpers,3 onlyliteral changed; all17 tophelpers preserved.','algorithms':'Allnumeric/structural AST nodes/imports/scopes/caps/fieldsets/cleanup/once/ownership/routes/protected-reader/noRetry behavior unchanged. String bindings only, including fixed parent/tree/newstage/Source/target/schema/version/UserAgent/message/docstring.'},'publication_semantics':{'repository':'liuyao12/geometric-tree-search','parent':'932d397dbdac3be5baa27eb07bbe253d89481880','tree':'5fc5c568cfe29c70ec9104cf2970eff138ffbb3a','targets':abi['fixed_targets'],'caps':{'HTML':1048576,'JSON':8388608,'ZIP':33554432},'once':'Exact plan9/authority6/currentSource+D90/fulltwinrawrefs/Gitblobs/humanquote-date-scope; exclusive authority+.CONSUMED.json fsynced before any payloadbody transport/network. Owned OUT flag false until successfulmkdir; preexisting/race failure cannot write foreign directory. Spent failure no retry.','routes':'Exactly12 calls:6GET,3blobPOST,treePOST,commitPOST,one nonforcePATCH. Allsafeunique complete untruncated recursive leaves before/after; only3new100644blobs and every nontarget mode/type/SHA/size preserved. Fixedmain parent/tree before mutations, prePATCHhead race guard and posthead identity. No localGit/maincheckout/index/protected reader reads.','transport':'Each ghAPI single owned process group with bounded nonblocking stdin/stdout/stderr, own cleanup/wait/EOF/group checks, complete rawrequests/responses/logs/transport JSON, prewrite outputcaps and postrawguards. Failure prefix never admitted, uncertain mutation reconciled separately read-only byRoot.'},'TLS_semantics':'Exact plan4/current complete Root-adopted publisher receipt/currentcommit+threepayloads and authority6. Exclusive consume beforefirstrequest; normal ssl default CERT_REQUIRED+hostname, NoRedirect/no bypass/no retry; exactly3 fixedsameorigin URLs with commitcachequery, fullbounded EOF/status200/exactfinalURL/ContentLength/rawtwin equality/SHA/Gitblob; savedfullbodies+status/parsedheaders/timings and allpostguards. No HTMLexecution/JSONscienceparse/archive decoder.','limits_scope':'Inherited cooperative main-entry/socket/API clocks, caps before storedwrites, bounded cleanup/readbacks; parsedheadercap is not rawwire headerlimit. No hard OS time/memory or wholelifetime bound; imports/parent/finalserialization-flush-shutdown tails explicit. External Root genuine receipt/authority/payload/human/caller authentication remains mandatory.','scientific_boundary':'Publication transport code is not evidence of qualified science. CurrentQwhole saved science/custody/Rootadmission/content/package/caller approvals remain separate. No proofsearch/discovery/physicalFOL/Machine5/GCTSbenefit inferred. Old authorities remain permanently spent.','remaining_gates':['Root complete Source adoption, wholeQscientific/content/packageadmission.','Exact future3payloads/stagingtwins/currenthead/concreteclosedplan+humanassociation and independently reviewed authenticated literalcaller.','Fresh Root publisher authority, original owned terminalexit0/fullcaptures/all12receipt+nontargetjoins, then separate current TLSplan/caller/onceauthority.','Exactly3normalTLS wholebodies and liveadoption before publication completion.'],'reviewer_subject_calls':0,'network_calls':0,'terminal_state':'REVIEW_COMPLETE_ALL_TOOLS_TERMINAL_IDLE'}
rr=save('Q-publication-pair-complete-independent-Source-peer-review-v1.json',review)
print(json.dumps({'review':rr,'support':sr,'counts':{role:{'top':x['top_helper_count'],'all_named':x['all_named_definition_count'],'scopes':x['scope_count']} for role,x in allrows.items()}},indent=2))
