from pathlib import Path
import ast,symtable,json,hashlib,collections
P=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');O=Path('/private/tmp/gcts-B-runtime-byte-parser-Source-peer-v1');newpath=P/'implementation-C/proof_byte_fol_checker_v1.tree';oldpath=Path('/private/tmp/gcts-B-fixed-FOL-integration-audit-20261027-v1/fol_checker.tree');vmpath=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/root/recovered-logical-Source-v1/tree_machine.py')
def H(b):return hashlib.sha256(b).hexdigest()
def enc(o):return(json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def fingerprint(fn,raw):
 lines=raw.splitlines(keepends=True);span=b''.join(lines[fn.lineno-1:fn.end_lineno]);return {'name':fn.name,'line':fn.lineno,'end_line':fn.end_lineno,'signature':ast.unparse(fn.args),'arity':len(fn.args.args),'raw_bytes':len(span),'raw_sha256':H(span),'AST_sha256':H(ast.dump(fn).encode()),'positioned_AST_sha256':H(ast.dump(fn,include_attributes=True).encode()),'all_calls':sorted(set(ast.unparse(x.func)for x in ast.walk(fn)if isinstance(x,ast.Call))),'all_branches':[{'line':x.lineno,'kind':type(x).__name__,'test':ast.unparse(x.test)}for x in ast.walk(fn)if isinstance(x,(ast.If,ast.While))]}
b=newpath.read_bytes();old=oldpath.read_bytes();t=ast.parse(b,str(newpath));ot=ast.parse(old,str(oldpath));assert len(b)==29429 and H(b)=='1e62e4052349d3ff0e6a7746b111acd426e6ffede92e264c23a6be31016af5a5';assert len(old)==17577 and H(old)=='8c86a24231d9c7d1777d7998b747a8cfd07087c168da64db6c5dff0820c802ed'
newf={f.name:f for f in t.body};oldf={f.name:f for f in ot.body};assert len(newf)==len(t.body)==92 and len(oldf)==len(ot.body)==64 and all(isinstance(x,ast.FunctionDef)for x in t.body);assert t.body[0].name=='main'and len(t.body[0].args.args)==1
idx=b.index(b'# Fixed program. Only finite atoms, cons/head/tail, tests, branches and calls.');suffix=b[idx:];assert suffix.count(b'def ps_semantic_main(request):')==1;inverse=suffix.replace(b'def ps_semantic_main(request):',b'def main(request):',1);assert inverse==old and ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(ot,include_attributes=True)
fps=[fingerprint(x,b)for x in t.body];ofps={x.name:fingerprint(x,old)for x in ot.body};nfps={x['name']:x for x in fps};preserved=[]
for name,f in oldf.items():
 n='ps_semantic_main'if name=='main'else name;xx=old.splitlines(keepends=True);yy=b.splitlines(keepends=True);a=b''.join(xx[f.lineno-1:f.end_lineno]);g=newf[n];bb=b''.join(yy[g.lineno-1:g.end_lineno]);assert bb==(a.replace(b'def main(request):',b'def ps_semantic_main(request):',1)if name=='main'else a);preserved.append({'old':name,'current':n,'raw_exact':name!='main','only_exact_function_name_rename':name=='main'})
vm=ast.parse(vmpath.read_bytes(),str(vmpath));primitives=ast.literal_eval(next(x.value for x in vm.body if isinstance(x,ast.Assign)and any(isinstance(z,ast.Name)and z.id=='PRIMITIVES'for z in x.targets)));arity={k:v[1]for k,v in primitives.items()};arity.update({k:len(f.args.args)for k,f in newf.items()});assert not set(newf)&set(primitives)
calls=[];syntax_nodes=collections.Counter();conditions=[];boolean_names={'ps_nil','ps_size3','ps_byte','ps_ascii_byte','ps_text_profile','ps_unary','ps_json_profile','ps_json_array','ps_json_object','ps_semantic_main','nil','same','size1','size2','size3','member','is_type','text_is','fields','signature_ok','term_ok','formula_ok','byte_less','text_less','truth','valuations','tautology','formulas_ok','references','proof','rule_ok','is_pair','atom_eq'}
def boolean_expr(x,fn):
 if isinstance(x,ast.Constant):return type(x.value)is bool
 if isinstance(x,ast.Name):return fn=='free'and x.id=='bound'
 if isinstance(x,ast.UnaryOp)and isinstance(x.op,ast.Not):return boolean_expr(x.operand,fn)
 if isinstance(x,ast.BoolOp):return all(boolean_expr(z,fn)for z in x.values)
 if isinstance(x,ast.Call):return isinstance(x.func,ast.Name)and x.func.id in boolean_names
 return False
for fn in t.body:
 args=fn.args;assert not fn.decorator_list and not args.defaults and not args.kw_defaults and not args.kwonlyargs and args.vararg is None and args.kwarg is None and not args.posonlyargs and fn.returns is None and all(a.annotation is None for a in args.args)
 locals={a.arg for a in args.args}|{x.targets[0].id for x in ast.walk(fn)if isinstance(x,ast.Assign)and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}
 for x in ast.walk(fn):
  syntax_nodes[type(x).__name__]+=1
  if isinstance(x,ast.Call):assert isinstance(x.func,ast.Name)and not x.keywords and x.func.id in arity and len(x.args)==arity[x.func.id];calls.append({'function':fn.name,'line':x.lineno,'callee':x.func.id,'arity':len(x.args)})
  if isinstance(x,ast.Name)and isinstance(x.ctx,ast.Load):assert x.id in locals or x.id in arity,(fn.name,x.id)
  if isinstance(x,ast.Constant):assert x.value is None or type(x.value)in(bool,str)or type(x.value)is int and 0<=x.value<=255
  if isinstance(x,(ast.If,ast.While)):assert boolean_expr(x.test,fn.name),(fn.name,x.lineno,ast.unparse(x.test));conditions.append({'function':fn.name,'line':x.lineno,'test':ast.unparse(x.test),'boolean_only_under_declared_invariants':True})
  if isinstance(x,ast.While):assert not x.orelse
  assert not isinstance(x,(ast.Import,ast.ImportFrom,ast.ClassDef,ast.Attribute,ast.Subscript,ast.List,ast.Tuple,ast.Dict,ast.For,ast.Try,ast.With,ast.Raise,ast.Lambda,ast.ListComp,ast.DictComp,ast.SetComp,ast.GeneratorExp,ast.BinOp,ast.Compare)),type(x).__name__
# Python symbol analysis is syntax-only; no tree Compiler/VM called.
st=symtable.symtable(b.decode(),str(newpath),'exec');scopes=[]
def walk(s,path):
 es=[]
 for name in sorted(s.get_identifiers()):
  v=s.lookup(name);es.append({'name':name,'true_flags':[k for k in['assigned','free','global','imported','local','nonlocal','parameter','referenced']if getattr(v,'is_'+k)()]})
 scopes.append({'path':path,'line':s.get_lineno(),'type':s.get_type(),'entries':es,'entries_sha256':H(enc(es))})
 for i,c in enumerate(s.get_children()):walk(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
walk(st,'module');assert len(scopes)==93
support={'schema':'B-runtime-byte-parser-complete-independent-static-Source-support-v1','Source':pin(newpath),'old_semantic_Source':pin(oldpath),'tree_Compiler_VM_Source':pin(vmpath),'all92_helpers':fps,'all93_symbol_scopes':scopes,'whole_AST_sha256':H(ast.dump(t).encode()),'whole_positioned_AST_sha256':H(ast.dump(t,include_attributes=True).encode()),'all_static_calls':calls,'static_call_count':len(calls),'all_Boolean_conditions':conditions,'condition_count':len(conditions),'bool_invariants':'New ps_ predicate helpers always return0/1. Inherited truth returns environment values constructed exclusively from False/True by valuations; free.bound is only passed True/False or itself. No raw node/byte truthiness in conditions. All other guarded parsing receipts are checked with is_pair.','all_old64_preservation':preserved,'whole_old_raw_and_positioned_AST_inverse_exact':True,'old63_helpers_raw_identical':True,'old_main_only_renamed_ps_semantic_main':True,'new_prefix_bytes':idx,'new_functions':list(newf)[:28],'primitive_arity_metadata':primitives,'static_syntax_nodes':dict(syntax_nodes),'static_Compiler_language_scope':'All92 ordinary positional functiondefs only; allowed static Assign/If/While/Return and Name/Constant/direct fixed arity calls/Not/And/Or. No Compiler construction/code generation/VM or helper evaluation performed.','activity':{'subject_import_constructor_Compiler_VM_codec_helper_test_fixture_CLI':0,'codeobject_execution':0,'unused_compile':False}}
p=O/'runtime-byte-parser-complete-independent-static-Source-support-v1.json';p.write_bytes(enc(support));print(json.dumps({'support':pin(p),'counts':{'functions':92,'old_functions':64,'new_prefix':28,'scopes':93,'static_calls':len(calls),'conditions':len(conditions),'Source_lines':len(b.splitlines())}},indent=2))
