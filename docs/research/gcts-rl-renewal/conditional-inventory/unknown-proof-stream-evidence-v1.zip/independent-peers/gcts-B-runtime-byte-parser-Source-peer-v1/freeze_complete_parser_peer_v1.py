from pathlib import Path
import json,hashlib,re,ast
P=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1');C=P/'implementation-C';O=Path('/private/tmp/gcts-B-runtime-byte-parser-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def enc(o):return(json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def rr(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];return b

def save(n,o):
 p=O/n;b=enc(o);p.write_bytes(b);assert p.read_bytes()==b;return pin(p)
S=O/'runtime-byte-parser-complete-independent-static-Source-support-v1.json';own=json.loads(S.read_bytes());hpath=C/'runtime-proof-byte-parser-complete-inert-Source-handoff-v1.json';handoff=json.loads(hpath.read_bytes());assert handoff['Source']==own['Source'];metadata=[]
for k in['VMCompiler_Source','complete_manual','complete_old_Source_preservation','complete_static','grammar','old_source','prefrozen_strategy','public_ABI']:
 rr(handoff[k]);metadata.append(handoff[k])
manual=json.loads(rr(handoff['complete_manual']));author=json.loads(rr(handoff['complete_static']));pres=json.loads(rr(handoff['complete_old_Source_preservation']));api=json.loads(rr(handoff['public_ABI']));fps={f['name']:f for f in own['all92_helpers']};assert len(fps)==92
for f in author['all92_functions']:
 x=fps[f['name']]
 for k in['line','end_line','signature','arity','raw_bytes','raw_sha256','AST_sha256','positioned_AST_sha256']:assert x[k]==f[k],(f['name'],k)
 assert x['all_calls']==f['calls']
assert own['whole_AST_sha256']==author['whole_AST_sha256']and own['whole_positioned_AST_sha256']==author['whole_positioned_AST_sha256']
assert len(author['all93_symbol_scopes'])==len(own['all93_symbol_scopes'])==93
for a,b in zip(own['all93_symbol_scopes'],author['all93_symbol_scopes']):
 for k in['path','line','type','entries']:assert a[k]==b[k]
 assert a['entries_sha256']==b['entry_sha256']
assert len(manual['all92_helpers'])==92
for row in manual['all92_helpers']:
 f=fps[row['name']]
 for k in['name','line','end_line','signature','arity']:assert row[k]==f[k]
 assert row['inherited']==(row['name']not in own['new_functions'])
assert [(x['function'],x['line'],x['test'])for x in own['all_Boolean_conditions']]==[(x['function'],x['line'],x['test'])for x in author['all_conditions_Bool01']]
graph={name:sorted(set(f['all_calls'])&set(fps))for name,f in fps.items()};assert graph==author['call_graph']
def closure(root):
 seen=set();todo=[root]
 while todo:
  x=todo.pop()
  if x not in seen:seen.add(x);todo.extend(graph[x])
 return sorted(seen)
assert closure('main')==author['conservative_reachable_from_main'];grammar_closure=closure('ps_proof');assert not set(grammar_closure)&{'get','signature_ok','formula_ok','rule_ok','proof','ps_semantic_main','main'}
def apply(original,patch):
 src=original.decode().splitlines(keepends=True);ps=patch.decode().splitlines(keepends=True);cur=0;out=[];i=2
 while i<len(ps):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ps[i]);assert m,ps[i];pos=int(m[1])-1;out.extend(src[cur:pos]);cur=pos;i+=1
  while i<len(ps)and not ps[i].startswith('@@ '):
   line=ps[i];i+=1
   if line.startswith('\\'):continue
   assert line[0]in' +-'
   if line[0]in' -':assert src[cur]==line[1:];cur+=1
   if line[0]in' +':out.append(line[1:])
 out.extend(src[cur:]);return ''.join(out).encode()
old=rr(handoff['old_source']);new=rr(handoff['Source']);prefix=rr(pres['prefix_fragment']);assert new[:len(prefix)]==prefix and new[len(prefix):].replace(b'def ps_semantic_main(request):',b'def main(request):',1)==old
for i,r in enumerate(pres['patches']):assert apply(old if i==0 else new,rr(r))==(new if i==0 else old)
# Exact shared grammar/public native field order comparisons, not a parser evaluation.
common=json.loads(rr(handoff['grammar']))['stream_grammar'];host=json.loads((P/'implementation-B/independent-proof-byte-stream-complete-effective-public-ABI-v3.json').read_bytes());assert api['wire_start']==common['start_byte']==1 and api['LINE']==common['line_marker']==16 and api['END']==common['proof_END']==17;assert api['formula_codes']=={k:v.replace('term-list','termlist')for k,v in common['formula_tags'].items()};assert api['term_codes']=={k:v.replace('term-list','termlist')for k,v in common['term_tags'].items()}
for code,values in api['rule_order'].items():assert host['line_exact_fields'][values[0]]==['rule']+values[1:]
joins=save('runtime-byte-parser-complete-packet-independent-joins-v1.json',{'schema':'B-runtime-byte-parser-complete-packet-independent-joins-v1','handoff':pin(hpath),'all_pinned_metadata':metadata,'all92_raw_AST_positioned_signature_callset_fingerprints_exact':True,'all93_symbol_scopes_entries_hash_exact':True,'all92_manual_spans_signature_arity_exact':True,'all230_conditions_exact':True,'all_static_callgraph_and_reachability_exact':True,'both_unified_patches_full_forward_inverse_exact':pres['patches'],'whole_raw_prefix_suffix_and_reverse_main_rename_exact':True,'all64_legacy_helpers_joined':True,'grammar_and_host_native_fieldsets_exact':True,'grammar_only_transitive_helpers':grammar_closure,'grammar_only_closure_no_theory_target_semantic_lookup':True,'subject_calls':0,'subject_compilation_VM_execution':0})
walks=[{'helper':r['name'],'line':r['line'],'end_line':r['end_line'],'disposition':'PASS_STATIC_WITH_DECLARED_CARRIER_AND_VM_PRECONDITIONS','scope':r['return_contract']}for r in manual['all92_helpers']]
review=save('runtime-byte-parser-complete-independent-static-Source-peer-review-v1.json',{'schema':'B-runtime-byte-parser-complete-independent-static-Source-peer-review-v1','decision':'PASS_SOURCE_ONLY_WITH_EXPLICIT_PRECONDITIONS','complete_review':True,'blockers':[],'prefrozen_expectations':pin(O/'runtime-byte-parser-prefrozen-complete-static-peer-expectations-v1.json'),'Source':own['Source'],'handoff':pin(hpath),'public_ABI':handoff['public_ABI'],'full_independent_static_support':pin(S),'complete_packet_join_support':joins,'findings':[{'id':'COMPLETE_SOURCE_PRESERVATION','decision':'PASS','detail':'Entire29429-byte/850-line current Source read by new11840-byte prefix plus full preserved legacy suffix.92functions/93scopes/1107static calls and230Bool conditions independently derived.63old nonmain helpers raw/AST identical; oldmain only renamed ps_semantic_main. Exact prefix removal and inverse rename restore all17577 oldbytes; both published patches independently applied in both directions.'},{'id':'COMPILER_VM_STATIC_LANGUAGE','decision':'PASS','detail':'Full recovered tree_machine Compiler/Heap/validate/run Source read. All92 ordinary positional functions, supported Name/Constant/directcalls/Not/And/Or and Assign/If/While/Return syntax, all arities/static references valid. No Compiler instance, VM declaration, code generation or run invoked. New predicates returnBoolean0/1; carried data are checked with is_pair, never arbitrary atom/node truthiness. Inherited free.bound and truth envBoolean invariants explicitly checked.'},{'id':'WHOLE_GRAMMAR','decision':'PASS','detail':'Complete Version1, exact16-line/rule0..7 payloads, term32/33 and formula48..55 map, ASCII32..126 nonempty0terminated names,64item/65end argument lists and80unary/81reference syntax match independent host codec and Root grammar. Truncation/unknown code/malformed list/name/ref/suffix/empty proof all reachFalse on normal completion, with no ignored padding. Every successful syntax loop consumes a byte row; recursive calls consume their tags before descent.'},{'id':'NATIVE_RUNTIME_AST_CONSTRUCTION','decision':'PASS','detail':'Each parser result is False or a newly immutable-cons-built AST/remainder carry. Terms/formulas/line fields are fixed unique JSON constructors from byte values; all8native rule field orders match host ABI. Grammar closure receives only rows/static tags, and has no theory/target/semantic lookup. The unknown proof is not supplied as host AST or recovered from a target-specific skeleton; parsing may share equal immutable canonical nodes without mutating the prefix.'},{'id':'KNOWN_PREFIX_SCOPE','decision':'PASS_WITH_MANDATORY_PRECONDITIONS','detail':'main requires exact raw triple, walks generic known JSON type tags/string/key ASCII profile, requires theory4 with schemas exactlyemptyarray and supplies fixed emptyblocks/protocol. Canonical unique-key JSON, valid existing heapIDs, acyclic backward-linked immutable heap and correct trusted theory/target roots remain authenticated carrier preconditions. ps_json_profile is not claimed to prove objectkey uniqueness, global alias freshness or heap acyclicity.'},{'id':'CARRIER_SCOPE','decision':'PASS_WITH_MANDATORY_PRECONDITIONS','detail':'ps_take checks proper rowlist head/row pair/marker pair/byte domain under validated Heap domain0..256-or-existingnodes. Private marker identities/firstfresh allocation, immutable links/knownprefix/read-only input and physical8-bit mask are independent L/Root obligations. No head/tail of unguarded malformed parser carry; failureFalse cannot masquerade as a cons success. No physical MIN8_LSB/tape/NTM/Wang-palette/search result inferred here.'},{'id':'SEMANTIC_ONE_WAY_RELATION','decision':'PASS_EXPLICIT_ASYMMETRY','detail':'Preserved tree checker uses exact structural same and fresh0-style renaming, while independent B8kernel permits alpha-equivalent formulas and different fresh names. Do not demand verdict bijection or BVERIFIED implies treeACCEPTED. Every later actually tree-accepted decoded proof must independently BVERIFY against exactly same finite closed theory/target, dropping only requiredempty schemas. Prior references, signatures, closed axioms, substitution and target equality remain in semantic checker, not hostgrammar.'},{'id':'RESOURCE_AND_FIXEDNESS_SCOPE','decision':'PASS_WITH_REMAINING_GATES','detail':'This is one fixed Source independent of supplied theory/target/proof capacity. Runtime step/heap or later wall/memory cutoffs remain UNKNOWN/unadmitted, never target unprovability. Host codec operation/depth/line/item/name/ref caps are independent observational controls; no equal VM cost claim. No Source function/compiler/parser/semantic/codeobject/fixture/test/CLI/network execution occurred. No machine declaration or finite palette produced.'}],'all92_helper_dispositions':walks,'remaining':['Root full Source/packet/adoption and other component independent peers.','Reviewed canonical carrier/MIN8_LSB lowering/mask/read-only/alias correspondence and exact qualification caller retaining complete runtime constructed AST for hostcomparison.','Fresh closed one-use qualification with good/negative/truncation/high/control/list/ref/trailing/alias/readonly/resource cases and treeACCEPTED implies independent BVERIFY gate.','Only separately authorized later unknown proof-byte search; authored control acceptance is not automatically discovered theorem evidence.'],'activities':{'subject_imports_helpers_getters_Compiler_VM_codec_semantic_calls':0,'proof_fixtures_constructors_models_tests_CLI':0,'codeobject_execution':0,'unused_compile':False,'only_Source_bytes_AST_symtable_static_metadata_and_patch_data_operations':True},'terminal_state':'IDLE'})
print(json.dumps({'review':review,'full_static_support':pin(S),'packet_joins':joins},indent=2))
