from pathlib import Path
import ast,symtable,json,hashlib,re
D=Path('/private/tmp/gcts-unknown-proof-stream-20261027-v1/implementation-L');O=Path('/private/tmp/gcts-B-carrier2-focused-Source-peer-v1')
def H(b):return hashlib.sha256(b).hexdigest()
def enc(o):return(json.dumps(o,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return{'path':str(p),'bytes':len(b),'sha256':H(b)}
def rr(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes']and H(b)==r['sha256'];return b

def save(n,o):
 p=O/n;b=enc(o);p.write_bytes(b);return pin(p)
hp=D/'raw-proof-byte-carrier-MIN8-complete-inert-Source-handoff-v2.json';h=json.loads(hp.read_bytes());meta=[]
for k in['closure','inherited_complete_Source1_handoff','manual','preservation','public_ABI','static']:rr(h[k]);meta.append(h[k])
pres=json.loads(rr(h['preservation']));stat=json.loads(rr(h['static']))['Source2_complete'];old=rr(pres['Source1']);new=rr(pres['Source2']);ot=ast.parse(old);nt=ast.parse(new);ol=old.splitlines(keepends=True);nl=new.splitlines(keepends=True)
def defs(t,lines):
 ns=[n for n in ast.walk(t)if isinstance(n,(ast.FunctionDef,ast.ClassDef))];d={}
 for n in ns:
  ps=sorted([p for p in ns if p is not n and p.lineno<n.lineno<=n.end_lineno<=p.end_lineno],key=lambda x:x.lineno);name='.'.join([x.name for x in ps]+[n.name]);raw=b''.join(lines[n.lineno-1:n.end_lineno]);d[name]={'line':n.lineno,'end_line':n.end_lineno,'raw_bytes':len(raw),'raw_sha256':H(raw),'AST_sha256':H(ast.dump(n).encode()),'positioned_AST_sha256':H(ast.dump(n,include_attributes=True).encode()),'signature':None if isinstance(n,ast.ClassDef)else ast.unparse(n.args),'calls':sorted(set(ast.unparse(x.func)for x in ast.walk(n)if isinstance(x,ast.Call)))}
 return d
od=defs(ot,ol);nd=defs(nt,nl);assert set(od)==set(nd)and len(nd)==27;changed=[n for n in od if od[n]['raw_sha256']!=nd[n]['raw_sha256']];assert set(changed)=={'_fields','_known_json','build_physical_mask'}
for d in stat['definitions']:
 assert all(nd[d['name']][k]==d[k]for k in nd[d['name']])
assert H(ast.dump(nt).encode())==stat['whole_AST_sha256']and H(ast.dump(nt,include_attributes=True).encode())==stat['whole_positioned_AST_sha256']
sc=[]
def walk(s,name):
 es=[]
 for n in s.get_identifiers():
  v=s.lookup(n);x={'name':n};x.update({k:getattr(v,'is_'+k)()for k in['assigned','free','global','imported','local','nonlocal','parameter','referenced']});es.append(x)
 sc.append({'name':name,'type':s.get_type(),'line':s.get_lineno(),'entries':es})
 for c in s.get_children():walk(c,name+'.'+c.get_name())
walk(symtable.symtable(new.decode(),'carrier2','exec'),'top');assert sc==stat['symbol_scopes']and len(sc)==44
inverse=new.decode()
for n in changed:
 a=nd[n];b=od[n];before=b''.join(nl[a['line']-1:a['end_line']]).decode();after=b''.join(ol[b['line']-1:b['end_line']]).decode();assert inverse.count(before)==1;inverse=inverse.replace(before,after,1)
inverse=inverse.replace("VERSION = 'RAW-PROOF-BYTE-CARRIER-MIN8-v2'","VERSION = 'RAW-PROOF-BYTE-CARRIER-MIN8-v1'",1);assert inverse.encode()==old and ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(ot,include_attributes=True)
def apply(a,p):
 src=a.decode().splitlines(keepends=True);ls=p.decode().splitlines(keepends=True);i=2;cur=0;out=[]
 while i<len(ls):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',ls[i]);assert m;pos=int(m[1])-1;out.extend(src[cur:pos]);cur=pos;i+=1
  while i<len(ls)and not ls[i].startswith('@@ '):
   z=ls[i];i+=1
   if z.startswith('\\'):continue
   if z[0]in' -':assert src[cur]==z[1:];cur+=1
   if z[0]in' +':out.append(z[1:])
 out.extend(src[cur:]);return ''.join(out).encode()
assert apply(old,rr(pres['forward']))==new and apply(new,rr(pres['inverse']))==old
rr(h['active_Sources']['lowering']);assert h['active_Sources']['lowering']==pres['bounded_MIN8lowering2_unchanged']
support=save('carrier2-complete-focused-independent-preservation-support-v1.json',{'schema':'B-carrier2-complete-focused-preservation-support-v1','handoff':pin(hp),'metadata':meta,'Source':pres['Source2'],'all27_current_helpers':nd,'all44_symbol_scopes':sc,'changed_helpers':changed,'unchanged_raw_AST_helpers':24,'entire_independent_helper_span_inverse_raw_positioned_AST_exact':True,'both_forward_inverse_patches_exact':[pres['forward'],pres['inverse']],'Source1':pres['Source1'],'lowering2_unchanged':h['active_Sources']['lowering'],'subject_calls':0})
review=save('carrier2-complete-focused-independent-Source-review-v1.json',{'schema':'B-carrier2-complete-focused-independent-Source-review-v1','decision':'PASS_SOURCE_ONLY','complete_review':True,'blockers':[],'Source':pres['Source2'],'handoff':pin(hp),'public_ABI':h['public_ABI'],'support':support,'inherited_whole_carrier1_negative':pin(Path('/private/tmp/gcts-B-carrier-MIN8-Source-peer-v1/carrier1-and-MIN8-lowering2-complete-independent-static-Source-review-v1.json')),'inherited_lowering2_PASS':pin(Path('/private/tmp/gcts-B-carrier-MIN8-Source-peer-v1/MIN8-lowering2-complete-independent-static-Source-disposition-v1.json')),'closures':[{'finding':'CAR_FIELDS_SIZE_PREFLIGHT','status':'CLOSED','detail':'Exact native dict and len(value)==len(keys) now precede all key traversal/set construction.'},{'finding':'CAR_KNOWN_LIST_PENDING_GROWTH','status':'CLOSED','detail':'Complete known list length charged before array exit task and all child visit queue growth; fixed ordering/cycle/encoding semantics unchanged.'},{'finding':'CAR_SELECTED_MATRIX_PRECHARGE','status':'CLOSED_ROOT_RESOLVED_MOVE','detail':'After separate selected/physical cap gates, full sum(sizes) is charged before selected matrix allocation. The old per-band samecell charge is moved to this earlier site rather than doublecounted, as current Root/L resolution specifies. Subsequent whole physical and LEu32 charges retained; no changed model/unknown field semantics.'}],'preservation':'Exactly3 helper changes plus SourceVERSION/value.version2.24 helper raw/AST bodies identical; whole helper-span inverse and bothpatches restore all originalbytes/positionedAST.27defs44scopes and all current author static fingerprints joined. BoundedMIN8lowering2 exactsame23086/b2ef14...; all inherited alias/domain/offset/onewaysemantic/precondition scopes continue.','scope':'Carrier correction only; no new proof stream, model, physicalMachine5, palette, semantic success or scientific execution. Controlled generated input/readonly binding and complete caller/loader/qualification gates remain mandatory.','activities':{'subject_import_Compiler_Heap_Lowering_VM_codec_parser_helper_fixture_model_test_CLI':0,'codeobject_execution':0,'unused_compile':False,'plan_authority_actual_creation':0},'terminal_state':'IDLE_FOR_NEXT_ASSIGNED_STATIC_PEER'})
print(json.dumps({'review':review,'support':support},indent=2))
