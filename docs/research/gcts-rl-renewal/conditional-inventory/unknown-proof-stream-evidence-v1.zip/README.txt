Unknown proof-byte integration evidence, version 1

This is the complete finite task-selected evidence cutoff before publication execution.
All original files are unchanged bytes. MANIFEST.json maps each safe archive member
to its absolute original source path, exact length, SHA256 and CRC32.
The manifest does not hash itself; its exterior full raw pin is in the package receipt.
There are 231 original files and two synthetic administrative entries (this README
and MANIFEST.json). All 18 owned qualification files are retained, including complete
gzip control/model artifacts. Gzip files remain original compressed bytes here.

Qualified scope: authored finite parser/carrier/encoding/component regression controls.
The complete Root and independent admission records preserve the full result scope.
Full C1 physical model construction refused with UNKNOWN; this archive does not
establish physical FOL execution, strict Machine5 expansion, an all-unknown proof
search, theorem discovery, universal proof palette, GCTS frontier conformance, RL
or comparative search advantage. No prefix is promoted beyond whole qualification.

Source versions that failed pre-execution review are preserved alongside current
successors. Earlier external dependencies are explicit static Source/API references;
this is not recursive historical closure or an old scientific archive clone.
No runtime binary, unrelated private corpus/configuration, primary reader/index,
package/staging twins, or publication/TLS/browser completion receipts are included.
Later publication completion is a separate durable record.
