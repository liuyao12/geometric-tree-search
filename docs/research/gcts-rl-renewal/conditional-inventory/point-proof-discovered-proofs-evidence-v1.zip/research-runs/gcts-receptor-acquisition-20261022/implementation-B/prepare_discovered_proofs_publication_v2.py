"""Administrative admitted-proof reader packaging; inert Source until Root orders.

No scientific import, query/certificate generation, search, checker replay,
receptor extraction, Git, network or publishing. Both direct Root/C whole
admissions are mandatory before any actual proof body is read for display.
"""
from pathlib import Path
import argparse
import binascii
import hashlib
import html
import json
import math
import zipfile

ROOT = Path(__file__).resolve().parents[1] / 'root'
REPO = ROOT.parents[2]
BASE = ROOT / 'publication-original-bank-cohort-v1'
P2 = ROOT.parents[1] / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
OUTPUT = ROOT / 'publication-discovered-proofs-v1'
PAYLOAD = P2 / 'publication-payload-discovered-proofs-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
EXPERIMENT = 'signed-propositional-cohort-proof-benchmark-v1'
NAMES = ('point-proof-search-v1.html', 'point-proof-parallel-progress-v1.html',
         'point-proof-discovered-proofs-v1.html', 'point-proof-discovered-proofs-data-v1.json',
         'point-proof-discovered-proofs-evidence-v1.zip')
CATALOG_FIELDS = ('schema', 'status', 'reviewed', 'issued_utc', 'new_research_proofs',
                  'observation', 'next_step', 'cohort_admission', 'donors',
                  'archive_files', 'disposition_records')
DONOR_FIELDS = ('donor_index', 'case_id', 'Root_admission', 'C_review', 'result',
                'query', 'certificate', 'observer', 'census')
BASE_PINS = {'point-proof-search-v1.html': [64549, 'c99d1120ed0b34e3db1c9a08fffd528f13f9ac5145f11a71fce409f77c2f752b'], 'point-proof-parallel-progress-v1.html': [13016, '96edf9261794d368dc8cc78890dfd71c03f13f9b15948ec3e39b1ce2602e8cca']}
HISTORY_PINS = {'point-proof-cohort-qualification-data-v1.json': [156409, 'd49cf79cd6adb8ed8d16e5459f3b281534e25e9139abf31ea197004707f18ec3'], 'point-proof-cohort-qualification-evidence-v1.zip': [10901999, 'ee000a8dc8ee443a2795b3d62a1720865a7112e8c875672c5b479b01d0f60b4e'], 'point-proof-lossless-qualification-data-v1.json': [153095, 'a51cf1451a7b28c3492d17bb2e078a63d24ce131bf8df5f1cdb7109901aa7e5e'], 'point-proof-lossless-qualification-evidence-v1.zip': [2681920, '5c989b772429adac253a47843f5f220371458792193fa4a192ecad9c9910d701'], 'point-proof-codec-source-manifest-v1.json': [16011, 'd90a7f5974ae3696ff39fd7854d3e1aca5d4eb39f8c34bd0117fe25a67f0de96'], 'point-proof-codec-source-evidence-v1.zip': [233675, 'f5b02331342e637b8be5b058d8dadc1b6e0b7f756c9d7f3dc7df8c2f72d17170'], 'point-proof-output-qualification-data-v1.json': [1674, 'e3d64511c564459d4d51335ed7e4a93cdf29a0b545a2e3a2b38f14a8b99f9fdb'], 'point-proof-output-qualification-evidence-v1.zip': [1778378, 'af5d5839c1b67ae07a3d3cca66c338e995b98e1ed9bc7497cdafcd3a96919d76']}

READER_HTML = '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n<title>Read the automatically acquired primitive proofs</title>\n<script>window.MathJax={tex:{inlineMath:[[\'\\\\(\',\'\\\\)\']],displayMath:[[\'\\\\[\',\'\\\\]\']]},options:{skipHtmlTags:[\'script\',\'noscript\',\'style\',\'pre\',\'code\']}};</script>\n<script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script>\n<style>\n:root{--ink:#203239;--muted:#53666c;--paper:#f7f5ee;--rule:#d4dedb;--teal:#176f66;--purple:#7154a5;--amber:#9a5617}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.65 system-ui,sans-serif}main{max-width:1200px;margin:auto;padding:30px 20px 70px}h1{font-size:clamp(2rem,5vw,3.3rem);line-height:1.15;max-width:950px}h2{line-height:1.3}a{color:#215f83;text-underline-offset:3px}.eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.12em;color:var(--muted)}.panel{padding:22px;background:#fff;border:1px solid var(--rule);border-radius:9px;margin:22px 0;min-width:0}.notice{padding:16px 19px;background:#fff2df;border-left:5px solid var(--amber)}.small{font-size:.88rem;color:var(--muted)}.controls{display:flex;flex-wrap:wrap;gap:12px 18px;align-items:end}label{display:grid;gap:5px;font-weight:650}select,input,button{font:inherit;border:1px solid #8aa49c;border-radius:5px;padding:8px 11px;background:white;color:var(--ink)}button{cursor:pointer}button:hover,button:focus-visible{background:#e0f2ec;outline:2px solid var(--teal);outline-offset:2px}button[aria-current=true]{background:var(--teal);color:#fff}input{max-width:150px}.math,.scroll{overflow:auto}table{border-collapse:collapse;width:100%}th,td{padding:11px 12px;border-bottom:1px solid var(--rule);text-align:left;vertical-align:top}th{background:#f1f6f4}td.math-cell{min-width:240px}.metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.metric{padding:16px;background:#f1f6f4;border-top:4px solid var(--teal)}.metric strong{display:block;font-size:1.6rem}.metric:nth-child(2){background:#f5f1fa;border-color:var(--purple)}.metric:nth-child(3){background:#fff5e9;border-color:var(--amber)}.row-detail{border-left:5px solid var(--purple)}.rule{display:inline-block;border-radius:4px;background:#e0f2ec;padding:3px 10px;font-weight:700}.formula{padding:16px;background:#f5f1fa;overflow:auto}.marking{border-left:5px solid var(--amber)}.legend{display:flex;gap:16px;flex-wrap:wrap}.swatch{display:inline-block;width:13px;height:13px;background:var(--teal);margin-right:6px}.swatch.purple{background:var(--purple)}.swatch.amber{background:#b66d15}.diagram{width:100%;min-width:500px;height:auto;background:#fafbf9;border:1px solid var(--rule)}pre{font-size:.8rem;background:#f5f6f6;padding:16px;overflow:auto;max-height:500px}code{overflow-wrap:anywhere}.pages{display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:15px 0}footer{margin-top:28px;padding-top:18px;border-top:1px solid var(--rule)}.error{color:#9a2820}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}@media(max-width:700px){main{padding:22px 12px}.panel{padding:17px}.metrics{grid-template-columns:1fr}th,td{padding:9px}.controls{align-items:stretch}select{max-width:100%}}\n</style></head><body><main>\n<header><p class="eyebrow">Fresh ordinary proof acquisition · original primitive certificates</p>\n<h1>Inspect the discovered proofs, one primitive row at a time</h1>\n<p>Two fresh automatically selected propositional statements have complete original-byte proof admissions from Root and the independent reviewer. The statements and every displayed row come from the saved original subject-checker receipts. No proof is simplified, repaired or replaced for this reader.</p>\n<p class="notice">The producer is ordinary signed propositional proof search. This is a proof-acquisition milestone, with no learned receptor library, GCTS search result, RL advantage or comparative speedup claim. The formulas are not claimed to be new mathematical theorems.</p>\n<nav><a href="point-proof-search-v1.html#discovered-proofs-current">Research notebook</a> · <a href="point-proof-parallel-progress-v1.html#discovered-proofs-current">Progress and costs</a> · <a href="point-proof-discovered-proofs-data-v1.json">Full reader data</a> · <a href="point-proof-discovered-proofs-evidence-v1.zip">Complete pinned evidence archive</a></nav></header>\n<p id="load-status" role="status" aria-live="polite">Loading the complete saved proof-row views…</p>\n<section class="panel" id="browser" hidden><h2>Choose a statement</h2><div class="controls"><label>Automatically selected donor<select id="theorem"></select></label><label>Primitive row index (starts at zero)<input id="row-index" type="number" min="0" step="1" value="0"></label><button id="go" type="button">Inspect row</button></div><div id="goal" class="formula math"></div><p class="small">Atom, function and variable identifiers are the original rigid identifiers. Parentheses and negations are preserved. All references and row indices below start at zero.</p><div id="metrics" class="metrics"></div></section>\n<section class="panel row-detail" id="detail" hidden aria-labelledby="row-heading"><h2 id="row-heading">Selected primitive row</h2><p id="rule" class="rule"></p><div id="formula" class="formula math"></div><p id="reason"></p><div id="references" class="controls"></div><h3>Saved witnesses</h3><div id="witnesses" class="math"></div><details><summary>Exact original subject row, including source spans and validation</summary><pre id="raw-row"></pre></details></section>\n<section class="panel marking" id="point-view" hidden><h2>Symbolic row tile and its formula ports</h2><p>A row occupies one cell with \\(t=1\\). Its formula-valued \\(m\\)-markings include the current conclusion and any earlier premise ports. Their offsets are relative to the selected row; only translation is used. Distant premise ports may lie outside the occupied cell.</p><div class="legend"><span><i class="swatch"></i>occupied row cell</span><span><i class="swatch purple"></i>conclusion formula port</span><span><i class="swatch amber"></i>premise dependency</span></div><div class="scroll"><svg id="diagram" class="diagram" role="img" aria-labelledby="diagram-title diagram-description"></svg></div><h3>Every saved marking on the selected tile</h3><div class="scroll"><table><thead><tr><th>Relative point</th><th>Global row port</th><th>Exact formula-valued marking</th></tr></thead><tbody id="marks"></tbody></table></div><p class="small">Colors aid reading only; the exact formula and point labels carry the identity. These are symbolic row tiles with formula-valued extended markings, not a fixed finite adjacency-only Wang palette. That universal finite palette remains unbuilt. The point observation is nonadmitting; proof authority comes from the original full byte checkers and whole Root/C admissions.</p><details><summary>Exact saved point tile</summary><pre id="raw-tile"></pre></details></section>\n<section class="panel" id="rows-panel" hidden><h2>All primitive rows</h2><p>Every original row is available in source order. Paging changes only the display; the data and certificate contain the complete proof.</p><div class="pages"><button id="previous" type="button">Previous page</button><span id="page-label" role="status"></span><button id="next" type="button">Next page</button></div><div class="scroll"><table><thead><tr><th>Row</th><th>Rule</th><th>Original formula</th><th>References</th></tr></thead><tbody id="rows"></tbody></table></div></section>\n<section class="panel" id="costs" hidden><h2>Acquisition and independent verification costs</h2><p>The table uses the saved observer elapsed clock for each cold whole attempt. Producer and checker call-stage clocks include their normal caller boundary checks; the producer stage includes primitive reconstruction. Final observer gate, worker-after-output and individual call stages are separate scopes, not interchangeable clocks or a causal phase profile. All cold imports, input selection, encodings, primitive reconstruction, both validators, point reduction and output/custody costs remain included.</p><div class="scroll"><table><thead><tr><th>Attempt</th><th>Observer elapsed</th><th>Producer call stage</th><th>Subject check stage</th><th>Independent check stage</th><th>Final observer gate</th><th>Conservative whole peak</th><th>Primitive rows</th><th>Original certificate</th></tr></thead><tbody id="cost-rows"></tbody></table></div><h3>One-time finite infrastructure qualification</h3><div id="qualification" class="math"></div><p>The original \\(221\\) controls plus \\(8\\) transport controls were admitted as a distinct finite cohort. They are not rerun or reclassified as proof-search speedup. Per-proof admission remains fresh and original-byte based. Costs are reported once with their actual scopes; peaks are never added. The arithmetic sum of three \\(225\\,\\mathrm{s}\\) reservations is not a hard wall guarantee.</p><details><summary>Complete saved stage and checker cost observations</summary><pre id="stage-costs"></pre></details></section>\n<footer><p>The evidence archive preserves the complete original actuals, both full validator views, Sources, contracts, raw census records and independent dispositions through an explicit pin list. Earlier negative studies remain unchanged. Automatic extraction of reusable receptor families and a matched same-library comparison are later work; this display performs no extraction, checker replay or proof search.</p></footer>\n</main><script>\n\'use strict\';\nconst $=id=>document.getElementById(id), pageSize=20;\nlet dataset=null, proof=null, page=0, rowIndex=0;\nconst logical=[\'H1\',\'H2\',\'H3\',\'Q1\',\'Q2\',\'Q3\',\'E1\',\'E2\'];\nfunction latex(tree){\n if(!Array.isArray(tree))throw Error(\'Saved core tree is not an array\');\n const tag=tree[0];\n if(tag===\'var\')return \'x_{\'+tree[1]+\'}\';\n if(tag===\'fun\')return \'\\\\mathsf{f}_{\'+tree[1]+\'}\\\\left(\'+tree[2].map(latex).join(\',\')+\'\\\\right)\';\n if(tag===\'pred\')return \'\\\\mathsf{P}_{\'+tree[1]+\'}\'+(tree[2].length?\'\\\\left(\'+tree[2].map(latex).join(\',\')+\'\\\\right)\':\'\');\n if(tag===\'eq\')return \'\\\\left(\'+latex(tree[1])+\'=\'+latex(tree[2])+\'\\\\right)\';\n if(tag===\'not\')return \'\\\\neg\\\\left(\'+latex(tree[1])+\'\\\\right)\';\n if(tag===\'imp\')return \'\\\\left(\'+latex(tree[1])+\'\\\\to \'+latex(tree[2])+\'\\\\right)\';\n if(tag===\'all\')return \'\\\\forall x_{\'+tree[1]+\'}\\\\,\\\\left(\'+latex(tree[2])+\'\\\\right)\';\n throw Error(\'Unknown saved core constructor\');\n}\nfunction math(node,tex){node.textContent=\'\\\\(\'+tex+\'\\\\)\';}\nfunction typeset(nodes){if(window.MathJax&&MathJax.typesetPromise){return MathJax.typesetPromise(nodes).catch(e=>{$(\'load-status\').textContent=\'Math display error: \'+e.message;});}return Promise.resolve();}\nfunction clearMath(nodes){if(window.MathJax&&MathJax.typesetClear)MathJax.typesetClear(nodes);}\nfunction rule(row){return row.rule_tag===1?logical[row.subtag]:row.rule;}\nfunction refs(row){return row.rule_tag===3?row.witness.slice(0,2):(row.rule_tag===4?[row.witness[0]]:[]);}\nfunction button(label,callback){const n=document.createElement(\'button\');n.type=\'button\';n.textContent=label;n.addEventListener(\'click\',callback);return n;}\nfunction cell(row,text){const td=document.createElement(\'td\');td.textContent=text;row.append(td);return td;}\nfunction seconds(x){return Number(x).toFixed(4)+\' s\';}\nfunction size(x){return Number(x).toLocaleString(\'en-US\')+\' bytes\';}\nfunction duration(p,name){const rows=p.stages.filter(s=>s.name===name&&s.status===\'COMPLETED\');if(rows.length!==1)throw Error(\'Exact saved call-stage clock required\');return rows[0].seconds;}\nfunction selectRow(index){\n if(!Number.isInteger(index)||index<0||index>=proof.subject_receipt.certificate.rows.length)return;\n rowIndex=index;page=Math.floor(index/pageSize);$(\'row-index\').value=String(index);\n const rows=proof.subject_receipt.certificate.rows,row=rows[index],tile=proof.point_receipt.tiles[index];\n clearMath([$(\'detail\'),$(\'point-view\')]);$(\'row-heading\').textContent=\'Primitive row \'+index;$(\'rule\').textContent=rule(row);math($(\'formula\'),latex(row.formula));\n let reason=\'This is the exact saved primitive rule instance, checked against the original query and complete certificate.\';\n if(row.rule_tag===1&&row.subtag===0)reason=\'H1 is instantiated with the saved formula witnesses: an antecedent remains available when another premise is introduced.\';\n if(row.rule_tag===1&&row.subtag===1)reason=\'H2 is instantiated with the saved witnesses: two implications with a common antecedent compose by the Hilbert distribution schema.\';\n if(row.rule_tag===1&&row.subtag===2)reason=\'H3 is the saved classical contraposition-schema instance. Its witness order is preserved below.\';\n if(row.rule_tag===3)reason=\'Modus ponens uses the first referenced row as antecedent and the second as the implication. The complete original checker verified that their exact formulas yield this conclusion.\';\n if(row.rule_tag===0)reason=\'This row refers to the saved ordered hypothesis occurrence in the original query.\';\n if(row.rule_tag===4)reason=\'The original checker verified generalization, including the full hypothesis-context freshness condition.\';\n $(\'reason\').textContent=reason;$(\'references\').replaceChildren();\n for(const ref of refs(row))$(\'references\').append(button(\'Inspect referenced row \'+ref,()=>selectRow(ref)));\n if(!refs(row).length)$(\'references\').textContent=\'This row has no earlier-row dependency.\';\n $(\'witnesses\').replaceChildren();row.witness.forEach((w,i)=>{const p=document.createElement(\'p\');p.append(\'Witness \'+i+\': \');const span=document.createElement(\'span\');if(Array.isArray(w)&&typeof w[0]===\'string\')math(span,latex(w));else span.textContent=JSON.stringify(w);p.append(span);$(\'witnesses\').append(p);});\n $(\'raw-row\').textContent=JSON.stringify(row,null,2);$(\'raw-tile\').textContent=JSON.stringify(tile,null,2);\n drawDiagram(row,tile);$(\'marks\').replaceChildren();\n for(const marking of tile.m){const tr=document.createElement(\'tr\');math(cell(tr,\'\'),\'(\'+marking[0][0]+\',\'+marking[0][1]+\')\');math(cell(tr,\'\'),\'(\'+(index+marking[0][0])+\',\'+marking[0][1]+\')\');const td=cell(tr,\'\');td.className=\'math-cell\';math(td,latex(marking[1]));$(\'marks\').append(tr);}\n renderRows();typeset([$(\'detail\'),$(\'point-view\'),$(\'rows-panel\')]);\n}\nfunction drawDiagram(row,tile){\n const svg=$(\'diagram\'),NS=\'http://www.w3.org/2000/svg\', indices=[...new Set([...tile.references,row.index])].sort((a,b)=>a-b),height=indices.length*110+30;\n svg.replaceChildren();svg.setAttribute(\'viewBox\',\'0 0 700 \'+height);\n function node(tag,attrs,text){const n=document.createElementNS(NS,tag);for(const [key,value]of Object.entries(attrs||{}))n.setAttribute(key,String(value));if(text!==undefined)n.textContent=text;svg.append(n);return n;}\n node(\'title\',{id:\'diagram-title\'},\'Selected symbolic row tile and exact earlier formula ports\');\n node(\'desc\',{id:\'diagram-description\'},\'Green rectangles are occupied row cells; purple circles are conclusion ports. Amber lines connect the selected tile to the saved earlier premise rows. Distances are schematic; integer row labels and the marking table give exact coordinates.\');\n const y=new Map(indices.map((index,i)=>[index,60+i*110]));\n for(const ref of tile.references)node(\'path\',{d:\'M 385 \'+y.get(row.index)+\' C 635 \'+y.get(row.index)+\' 635 \'+y.get(ref)+\' 385 \'+y.get(ref),stroke:\'#b66d15\',\'stroke-width\':3,fill:\'none\'});\n for(const index of indices){const selected=index===row.index;node(\'rect\',{x:50,y:y.get(index)-28,width:145,height:56,rx:5,fill:selected?\'#176f66\':\'#e0f2ec\',stroke:\'#176f66\',\'stroke-width\':2});node(\'text\',{x:65,y:y.get(index)+6,fill:selected?\'white\':\'#174f48\',\'font-size\':18},\'Row \'+index);node(\'line\',{x1:195,y1:y.get(index),x2:370,y2:y.get(index),stroke:\'#7154a5\',\'stroke-width\':3});node(\'circle\',{cx:385,cy:y.get(index),r:13,fill:\'#7154a5\'});node(\'text\',{x:410,y:y.get(index)+6,fill:\'#203239\',\'font-size\':16},selected?\'selected conclusion\':\'earlier conclusion\');}\n}\nfunction renderRows(){\n clearMath([$(\'rows-panel\')]);const rows=proof.subject_receipt.certificate.rows,start=page*pageSize,end=Math.min(rows.length,start+pageSize);$(\'rows\').replaceChildren();\n for(let index=start;index<end;index++){const row=rows[index],tr=document.createElement(\'tr\'),td=cell(tr,\'\');const b=button(\'Row \'+index,()=>selectRow(index));if(index===rowIndex)b.setAttribute(\'aria-current\',\'true\');td.append(b);cell(tr,rule(row));const formula=cell(tr,\'\');formula.className=\'math-cell\';math(formula,latex(row.formula));cell(tr,refs(row).length?refs(row).join(\', \'):\'none\');$(\'rows\').append(tr);}\n $(\'page-label\').textContent=\'Rows \'+start+\'–\'+(end-1)+\' of \'+rows.length;$(\'previous\').disabled=page===0;$(\'next\').disabled=end===rows.length;\n}\nfunction choose(index){\n proof=dataset.proofs[index];page=0;rowIndex=0;clearMath([$(\'goal\')]);math($(\'goal\'),latex(proof.subject_receipt.query.goal));$(\'row-index\').max=String(proof.subject_receipt.certificate.rows.length-1);\n $(\'metrics\').replaceChildren();for(const [value,label]of [[proof.subject_receipt.certificate.row_count,\'original primitive rows\'],[seconds(proof.metrics.observer_elapsed_seconds),\'cold whole observer elapsed\'],[seconds(duration(proof,\'SEARCH_PROPOSITIONAL\')),\'producer call stage, including reconstruction\'],[size(proof.metrics.conservative_whole_peak_bytes),\'conservative whole peak\']]){const div=document.createElement(\'div\');div.className=\'metric\';const strong=document.createElement(\'strong\');strong.textContent=value;div.append(strong,label);$(\'metrics\').append(div);}\n selectRow(0);typeset([$(\'goal\')]);\n}\n$(\'theorem\').addEventListener(\'change\',()=>choose(Number($(\'theorem\').value)));$(\'go\').addEventListener(\'click\',()=>selectRow(Number($(\'row-index\').value)));$(\'row-index\').addEventListener(\'keydown\',e=>{if(e.key===\'Enter\')selectRow(Number(e.target.value));});\n$(\'previous\').addEventListener(\'click\',()=>{page--;renderRows();typeset([$(\'rows-panel\')]);});$(\'next\').addEventListener(\'click\',()=>{page++;renderRows();typeset([$(\'rows-panel\')]);});\nasync function start(){\n const response=await fetch(\'point-proof-discovered-proofs-data-v1.json\',{cache:\'no-cache\'});if(!response.ok)throw Error(\'Reader data HTTP \'+response.status);dataset=await response.json();\n if(dataset.schema!==\'Root-discovered-proofs-publication-data-v1\'||dataset.status!==\'TWO_DONORS_ADMITTED\'||dataset.proofs.length!==2)throw Error(\'Complete two-donor reader data required\');\n dataset.proofs.forEach((p,index)=>{const option=document.createElement(\'option\');option.value=String(index);option.textContent=\'Donor \'+p.donor_index+\' · \'+p.subject_receipt.certificate.row_count+\' primitive rows\';$(\'theorem\').append(option);const tr=document.createElement(\'tr\');cell(tr,\'Donor \'+p.donor_index);cell(tr,seconds(p.metrics.observer_elapsed_seconds));cell(tr,seconds(duration(p,\'SEARCH_PROPOSITIONAL\')));cell(tr,seconds(duration(p,\'SUBJECT_FULL_VALIDATION\')));cell(tr,seconds(duration(p,\'REFERENCE_FULL_VALIDATION\')));cell(tr,seconds(p.metrics.observer_final_gate_seconds));cell(tr,size(p.metrics.conservative_whole_peak_bytes));cell(tr,String(p.subject_receipt.certificate.row_count));cell(tr,size(p.certificate.bytes));$(\'cost-rows\').append(tr);});\n const q=dataset.qualification_cost_reported_once;$(\'qualification\').textContent=\'Saved observer elapsed: \'+seconds(q.observer_elapsed_seconds)+\'. Conservative whole peak: \'+size(q.conservative_whole)+\'. This finite infrastructure cost is reported once, separately from both fresh donor attempts.\';\n $(\'stage-costs\').textContent=JSON.stringify(dataset.proofs.map(p=>({donor_index:p.donor_index,whole_metrics:p.metrics,stages:p.stages,subject_checker_cost:p.subject_receipt.cost,reference_checker_scope:p.reference_scope})),null,2);\n for(const id of [\'browser\',\'detail\',\'point-view\',\'rows-panel\',\'costs\'])$(id).hidden=false;$(\'load-status\').textContent=\'Both complete admitted proof views loaded. Select any original row.\';choose(0);typeset([$(\'costs\')]);\n}\nstart().catch(error=>{$(\'load-status\').className=\'error\';$(\'load-status\').textContent=\'Proof reader could not load: \'+error.message;});\n</script></body></html>\n'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def rawpin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def memberpin(body):
    return dict(**rawpin(body), crc32='%08x' % (binascii.crc32(body) & 0xffffffff))


def emit(path, body):
    need(not path.exists(), 'fresh exclusive publication output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        need(stream.write(body) == len(body), 'complete administrative write required')
    temporary.replace(path)


def jsonbody(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode('ascii')


def esc(value):
    return html.escape(str(value), quote=True)


def checked_ref(ref):
    need(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'exact rawpin required')
    need(type(ref['path']) is str and type(ref['bytes']) is int and ref['bytes'] >= 0,
         'typed raw path and length required')
    need(type(ref['sha256']) is str and len(ref['sha256']) == 64
         and all(c in '0123456789abcdef' for c in ref['sha256']), 'lowercase SHA256 required')
    path = Path(ref['path'])
    need(path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink(),
         'canonical complete ordinary file or opaque partial required')
    need(path.is_relative_to(REPO), 'only explicit repository evidence may be published')
    need(not any(p in ('.git', '.gcts-active', '.codex', '.agents', '.aws', '.ssh') for p in path.parts),
         'protected private metadata is not publication evidence')
    need(not path.name.startswith('.env'), 'environment/secrets cannot be evidence')
    need(path.suffix.lower() not in ('.html', '.htm', '.js', '.css'),
         'HTML/readers/scripts are never accepted from archive references')
    return path


def read_ref(ref):
    path = checked_ref(ref)
    body = path.read_bytes()
    need(rawpin(body) == {k: ref[k] for k in ('bytes', 'sha256')}, 'exact full rawpin mismatch')
    return body


def read_json_ref(ref):
    path = checked_ref(ref)
    need(path.suffix == '.json' and '.partial' not in path.name, 'only complete named JSON is parsed')
    return json.loads(read_ref(ref))


def read_catalog(path):
    need(path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink(),
         'canonical Root catalog required')
    need(path.parent == ROOT and path.suffix == '.json' and '.partial' not in path.name,
         'direct complete Root publication catalog required')
    body = path.read_bytes()
    cat = json.loads(body)
    need(type(cat) is dict and set(cat) == set(CATALOG_FIELDS), 'exact11 catalog fields required')
    need(cat['schema'] == 'Root-discovered-proofs-publication-catalog-v1'
         and cat['status'] == 'TWO_DONORS_ADMITTED' and cat['reviewed'] is True
         and type(cat['new_research_proofs']) is int and cat['new_research_proofs'] == 2,
         'two fresh complete external admissions are mandatory; Source/prepared/negative cannot package')
    for key in ('issued_utc', 'observation', 'next_step'):
        need(type(cat[key]) is str and bool(cat[key]), 'nonempty Root-owned publication wording required')
    need(type(cat['donors']) is list and len(cat['donors']) == 2, 'two ordered donor rows required')
    need(type(cat['archive_files']) is list and bool(cat['archive_files']), 'explicit evidence pin list required')
    need(type(cat['disposition_records']) is list and bool(cat['disposition_records']), 'explicit dispositions required')
    paths = set()
    for ref in cat['archive_files']:
        item = checked_ref(ref)
        need(item != path and str(item) not in paths, 'unique noncatalog explicit archive members required')
        paths.add(str(item))
    for ref in cat['disposition_records']:
        need(ref in cat['archive_files'] and checked_ref(ref).is_relative_to(ROOT.parent),
             'study-local raw disposition must be explicitly archived')
    need(any(checked_ref(ref).parent == ROOT for ref in cat['disposition_records']),
         'at least one direct Root disposition required')
    return body, cat


def admission_pair(cat):
    # Both external gates are checked BEFORE any saved actual result/proof body
    # is read for display. This is metadata association, no checker replay.
    need(cat['cohort_admission'] in cat['archive_files'], 'cohort gate must be archived')
    need(checked_ref(cat['cohort_admission']).parent == ROOT, 'direct Root cohort gate required')
    cohort = read_json_ref(cat['cohort_admission'])
    need(cohort['schema'] == 'Root-original-bank-cohort-complete-whole-disposition-v1'
         and cohort['cohort_admitted'] is True
         and cohort['status'] == 'ADMITTED_EXACT_FINITE_INFRASTRUCTURE_COHORT229',
         'unchanged complete finite229 cohort admission required')
    admissions = []
    for index, donor in enumerate(cat['donors']):
        need(type(donor) is dict and set(donor) == set(DONOR_FIELDS), 'exact9 donor fields required')
        case = EXPERIMENT + '-donor-' + str(index)
        need(type(donor['donor_index']) is int and donor['donor_index'] == index
             and donor['case_id'] == case, 'ordered original donor0/donor1 cases required')
        for key in DONOR_FIELDS[2:]:
            need(donor[key] in cat['archive_files'], 'every named donor reference must be archived')
        need(checked_ref(donor['Root_admission']).parent == ROOT, 'direct Root donor admission required')
        need(checked_ref(donor['C_review']).parent == ROOT.parent / 'review-C', 'direct independent C review required')
        root = read_json_ref(donor['Root_admission'])
        peer = read_json_ref(donor['C_review'])
        need(root['schema'] == 'Root-FPC-cohort-backed-donor-admission-v1'
             and root['proof_admitted'] is True and root['resources_and_custody_accepted'] is True
             and root['fresh_whole_original_byte_dual_gate'] is True
             and root['case_id'] == case and type(root['donor_index']) is int
             and root['donor_index'] == index and root['input_slot'] == 'donor' + str(index),
             'complete exact original-byte Root proof/resource/custody admission required')
        need(peer['schema'] == 'C-cohort-backed-per-proof-donor-complete-whole-actual-review-v1'
             and peer['review_passed'] is True and peer['blockers'] == []
             and peer['case_id'] == case and type(peer['donor_index']) is int
             and peer['donor_index'] == index, 'complete current independent review required')
        need(root['C_actual_review'] == donor['C_review'], 'canonical Root/C actual-review join required')
        if 'complete_C_review' in root:
            need(root['complete_C_review'] == donor['C_review'], 'optional alias must be exactly identical')
        for key in ('result', 'query', 'certificate', 'observer', 'census'):
            need(root[key] == donor[key], 'Root admission original body association mismatch')
        for source, key in (('result', 'result'), ('original_query', 'query'),
                            ('original_certificate', 'certificate'), ('census', 'census')):
            need(peer['subjects'][source] == donor[key], 'independent original body association mismatch')
        for key in ('plan', 'grant', 'terminal', 'worker_header', 'Root_passive_audit',
                    'input_authority', 'cohort_applicability'):
            need(root[key] in cat['archive_files'], 'all direct Root custody/Source authority pins required')
        for ref in peer['subjects'].values():
            if type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}:
                need(ref in cat['archive_files'], 'all direct independent subject pins required')
        admissions.append(root)
    need(cat['donors'][0]['query'] != cat['donors'][1]['query']
         and cat['donors'][0]['query']['sha256'] != cat['donors'][1]['query']['sha256'],
         'distinct fresh original donor queries required')
    return cohort, admissions


def display_proofs(cat, admissions):
    proofs = []
    input_images = []
    for donor, root in zip(cat['donors'], admissions):
        result = read_json_ref(donor['result'])
        observer = read_json_ref(donor['observer'])
        census = read_json_ref(donor['census'])
        need(census['schema'] == 'Root-cohort-backed-per-proof-terminal-raw-census-v1'
             and census['case_id'] == donor['case_id'] and census['file_count'] == len(census['files']),
             'complete named opaque census required')
        for row in census['files']:
            ref = {key: row[key] for key in ('path', 'bytes', 'sha256')}
            need(ref in cat['archive_files'], 'every complete/partial owned census member must be archived')
        need(result['schema'] == 'FPC-cohort-backed-per-proof-whole-worker-v1'
             and result['status'] == 'COMPLETE' and result['candidate_complete'] is True
             and result['proof_admitted'] is False and result['case_id'] == donor['case_id'],
             'complete original provisional worker view required; admission is separate')
        subject, reference, point = (result['subject_receipt'], result['reference_receipt'], result['point_receipt'])
        need(subject['complete'] is True and subject['accepted'] is True
             and subject['syntax_complete'] is True and subject['derivation_complete'] is True
             and subject['final_goal_equal'] is True and subject['status'] == 'VALID_DERIVATION'
             and reference['complete_check'] is True and reference['final_goal_equal'] is True
             and reference['status'] == 'VALID_DERIVATION', 'both full saved validator views required')
        need(point['complete'] is True and point['point_compatible'] is True and point['mismatches'] == []
             and point['proof_admitted'] is False and point['search_engine'] is False
             and point['GCTS_conformance'] is False, 'saved nonadmitting point observation required')
        certificate = subject['certificate']
        count = certificate['row_count']
        need(type(count) is int and count > 0 and count == len(certificate['rows'])
             and count == len(reference['rows']) and count == len(point['tiles'])
             and count == root['metrics']['primitive_rows'], 'complete original ordered row count required')
        for index, row in enumerate(certificate['rows']):
            need(type(row['index']) is int and row['index'] == index
                 and row['validation']['status'] == 'VALID', 'all saved rows retained in original source order')
        for key in ('query', 'certificate'):
            body = read_ref(donor[key])
            need(subject['raw_inputs'][key] == rawpin(body), 'original raw-body full identity join required')
            del body
        need(observer['schema'] == 'Root-case-external-observer-v1'
             and observer['case_id'] == donor['case_id'] and observer['resource_candidate_accepted'] is True,
             'complete original external observer required')
        metrics = root['metrics']
        need(metrics['observer_elapsed_seconds'] == observer['elapsed_seconds']
             and metrics['observer_final_gate_seconds'] == observer['final_observer_gate_seconds']
             and metrics['conservative_whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'],
             'display whole clocks/peaks must be exact saved independent scopes')
        freeze = result['input_freeze']
        input_images.append(jsonbody({key: freeze[key] for key in ('selection', 'slots', 'configuration')}))
        proofs.append(dict(donor_index=donor['donor_index'], case_id=donor['case_id'],
            Root_admission=donor['Root_admission'], C_review=donor['C_review'],
            result=donor['result'], query=donor['query'], certificate=donor['certificate'],
            metrics=metrics, stages=result['stages'], subject_receipt=subject, point_receipt=point,
            reference_scope=dict(schema=reference['schema'], status=reference['status'],
                complete_check=reference['complete_check'], final_goal_equal=reference['final_goal_equal'],
                full_original_view_location='Complete original result.json in evidence archive; not dropped from original evidence'),
            public_producer_receipt=result['search_result']['receipt'],
            cost_scope='Cold original run; observer elapsed, final gate, worker/output and individual stages remain separate.'))
    need(input_images[0] == input_images[1], 'both cold cases must retain complete identical all3 input freezes')
    return proofs


def _stage_seconds(proof, name):
    records = [row for row in proof['stages'] if row['name'] == name and row['status'] == 'COMPLETED']
    need(len(records) == 1, 'one complete saved call-stage clock required')
    value = records[0]['seconds']
    need((type(value) is int or type(value) is float) and math.isfinite(value) and value >= 0,
         'finite nonnegative saved call-stage duration required')
    return value


def summary_section(cat, proofs, cohort):
    lines = []
    for proof in proofs:
        m = proof['metrics']
        lines.append('<tr><th>Donor ' + str(proof['donor_index']) + '</th><td>\\(' + str(m['primitive_rows'])
            + '\\)</td><td>\\(' + format(m['observer_elapsed_seconds'], '.4f') + '\\,\\mathrm{s}\\)</td><td>\\('
            + format(_stage_seconds(proof, 'SEARCH_PROPOSITIONAL'), '.4f') + '\\,\\mathrm{s}\\)</td><td>\\('
            + str(m['conservative_whole_peak_bytes']) + '\\,\\mathrm{bytes}\\)</td></tr>')
    qm = cohort['metrics']
    return ('<section class="panel" id="discovered-proofs-current"><p class="status">TWO FRESH DONORS ADMITTED</p>'
        '<h2>Automatically acquired proofs: inspect the original rows</h2><p>' + esc(cat['observation']) + '</p>'
        '<p>Both fresh cold ordinary signed-propositional searches have complete original-byte admissions from Root '
        'and the independent reviewer. The full primitive proofs are retained; these formulas are not claimed '
        'to be new mathematical theorems.</p><div class="scroll"><table><thead><tr><th>Attempt</th><th>Primitive rows</th>'
        '<th>Observer elapsed</th><th>Producer call stage</th><th>Conservative whole peak</th></tr></thead><tbody>' + ''.join(lines) + '</tbody></table></div>'
        '<p>The separately observed one-time finite \\(229\\)-control infrastructure qualification took \\('
        + format(qm['observer_elapsed_seconds'], '.4f') + '\\,\\mathrm{s}\\) with conservative whole peak \\('
        + str(qm['conservative_whole']) + '\\,\\mathrm{bytes}\\). All cold search, reconstruction, paired checking, '
        'output and custody costs remain included. The producer-call stage includes primitive reconstruction and normal caller boundary checks; it is not a phase-time partition or causal profile. Distinct clock scopes and peaks are not added.</p>'
        '<p><a href="point-proof-discovered-proofs-v1.html">Choose a theorem and inspect every primitive row</a> '
        '&middot; <a href="point-proof-discovered-proofs-data-v1.json">Reader data and exact member hashes</a> '
        '&middot; <a href="point-proof-discovered-proofs-evidence-v1.zip">Complete pinned evidence archive</a></p>'
        '<p>The point view uses translated symbolic row cells and formula-valued extended markings. It is not '
        'a fixed finite adjacency-only Wang palette, which remains unbuilt. No learned receptor family, '
        'GCTS search conformance, RL advantage or comparative speedup is established. Earlier whole negatives '
        'and the earlier closed acquisition STOP remain unchanged.</p><p><strong>Next scientific step.</strong> '
        + esc(cat['next_step']) + '</p><p class="small">Root-owned publication catalog: '
        + esc(cat['issued_utc']) + '. Administrative display only: no scientific replay or extraction.</p></section>')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--catalog', required=True)
    parser.add_argument('--output', default=str(OUTPUT))
    args = parser.parse_args()
    need(Path(args.output) == OUTPUT, 'only the one dedicated fixed staging directory is permitted')
    catalog_path = Path(args.catalog)
    catalog_body, cat = read_catalog(catalog_path)
    cohort, admissions = admission_pair(cat)
    proofs = display_proofs(cat, admissions)
    bases = {}
    for name, expected in BASE_PINS.items():
        path = BASE / name
        need(path.is_file() and not path.is_symlink(), 'immutable existing secondary report required')
        body = path.read_bytes()
        need(rawpin(body) == dict(bytes=expected[0], sha256=expected[1]), 'exact current HTML base required')
        bases[name] = body
    history = []
    for name, expected in HISTORY_PINS.items():
        # Existing eight deployed artifact bodies remain untouched in sole P2.
        path = P2 / (PREFIX + name)
        need(path.is_file() and not path.is_symlink(), 'existing historical artifact required')
        body = path.read_bytes()
        need(rawpin(body) == dict(bytes=expected[0], sha256=expected[1]), 'historical artifact changed')
        history.append(dict(path=PREFIX + name, **rawpin(body)))
    need(not OUTPUT.exists() and not PAYLOAD.exists() and P2.is_dir(), 'fresh dedicated output/payload required')
    need(all(not (P2 / (PREFIX + name)).exists() for name in NAMES[2:]), 'all3 new Git paths must be absent')
    OUTPUT.mkdir()
    PAYLOAD.mkdir()
    entries, member_names = [], set()
    archive_partial = OUTPUT / (NAMES[4] + '.partial')
    with zipfile.ZipFile(archive_partial, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for ref in cat['archive_files']:
            path = checked_ref(ref)
            body = read_ref(ref)
            name = path.relative_to(REPO).as_posix()
            need(name not in member_names and name != 'discovered-proofs-publication-catalog.json',
                 'unique explicit archive member required')
            member_names.add(name)
            archive.writestr(name, body)
            entries.append(dict(name=name, **memberpin(body)))
        archive.writestr('discovered-proofs-publication-catalog.json', catalog_body)
        entries.append(dict(name='discovered-proofs-publication-catalog.json', **memberpin(catalog_body)))
    with zipfile.ZipFile(archive_partial) as archive:
        need(archive.testzip() is None and archive.namelist() == [row['name'] for row in entries],
             'whole ZIP CRC/order readback required')
        for row in entries:
            body = archive.read(row['name'])
            info = archive.getinfo(row['name'])
            need(memberpin(body) == {k: row[k] for k in ('bytes', 'sha256', 'crc32')}
                 and info.file_size == row['bytes'] and '%08x' % info.CRC == row['crc32'],
                 'entire uncompressed raw member identity required')
    archive_path = OUTPUT / NAMES[4]
    need(not archive_path.exists(), 'exclusive whole archive required')
    archive_partial.replace(archive_path)
    data = dict(schema='Root-discovered-proofs-publication-data-v1', status=cat['status'],
        issued_utc=cat['issued_utc'], catalog=dict(path=str(catalog_path), **rawpin(catalog_body)),
        observation=cat['observation'], next_step=cat['next_step'], proofs=proofs,
        qualification_cost_reported_once=cohort['metrics'], members=entries,
        archive=rawpin(archive_path.read_bytes()), archive_member_count=len(entries),
        historical_artifacts_unchanged=history, disposition_records=cat['disposition_records'],
        scientific_execution=False, extraction_performed=False, published=False)
    emit(OUTPUT / NAMES[3], jsonbody(data))
    emit(OUTPUT / NAMES[2], READER_HTML.encode('utf-8'))
    section = summary_section(cat, proofs, cohort)
    notice = ('<p class="notice" id="discovered-proofs-notice"><strong>Two fresh donor proofs are admitted.</strong> '
        'Inspect every original primitive row, checker view and translated formula-port marking. '
        '<a href="point-proof-discovered-proofs-v1.html">Open the proof reader</a>. '
        'No learned library or GCTS/RL advantage is claimed. Earlier panels remain historical.</p>')
    main_before = bases[NAMES[0]].decode('utf-8')
    notice_anchor = '<p class="notice" id="original-bank-cohort-notice">'
    section_anchor = '<section class="panel" id="original-bank-cohort-current">'
    need(main_before.count(notice_anchor) == main_before.count(section_anchor) == 1
         and 'id="discovered-proofs-notice"' not in main_before
         and 'id="discovered-proofs-current"' not in main_before, 'unique reversible current insertion anchors required')
    main_after = main_before.replace(notice_anchor, notice + notice_anchor, 1).replace(section_anchor, section + section_anchor, 1)
    need(main_after.replace(notice, '', 1).replace(section, '', 1).encode('utf-8') == bases[NAMES[0]],
         'exact64549-byte main inverse required')
    emit(OUTPUT / NAMES[0], main_after.encode('utf-8'))
    progress_before = bases[NAMES[1]].decode('utf-8')
    need(progress_before.count('<main>') == 1 and 'id="discovered-proofs-current"' not in progress_before,
         'unique reversible progress insertion anchor required')
    historical = ('<p class="notice" id="discovered-proofs-history"><strong>Historical reports below.</strong> '
        'Their old current-status labels are preserved verbatim; the admitted two-donor report above is the newest observation.</p>')
    progress_after = progress_before.replace('<main>', '<main>' + section + historical, 1)
    need(progress_after.replace(section + historical, '', 1).encode('utf-8') == bases[NAMES[1]],
         'exact13016-byte progress inverse required')
    emit(OUTPUT / NAMES[1], progress_after.encode('utf-8'))
    files = []
    for name in NAMES:
        body = (OUTPUT / name).read_bytes()
        emit(PAYLOAD / name, body)
        files.append(dict(path=PREFIX + name, publisher_source=str(PAYLOAD / name),
            **rawpin(body), git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode('ascii') + b'\0' + body).hexdigest()))
    emit(OUTPUT / 'P2-staging.json', jsonbody(dict(schema='Root-discovered-proofs-publication-staging-v1',
        catalog=dict(path=str(catalog_path), **rawpin(catalog_body)), files=files, prior_base_pins=BASE_PINS,
        unchanged_historical_artifacts=history, archive_members_verified=len(entries),
        new_targets_must_be_absent=list(NAMES[2:]), exact_main_inverse_bytes=64549,
        exact_progress_inverse_bytes=13016, scientific_execution=False, published=False,
        publisher_scope='Only sole P2/existing destination/five named targets. Root separately verifies baseGitblobs, '
                        'newpaths absent, explicit public catalog/payload association and all live assets. No Git/deploy in helper.')))
    need(rawpin(catalog_path.read_bytes()) == rawpin(catalog_body), 'Root catalog must remain exact through packaging')
    for ref in cat['archive_files']:
        read_ref(ref)
    print(json.dumps(dict(files=files, archive_members=len(entries),
        staging=str(OUTPUT / 'P2-staging.json'), scientific_execution=False, published=False)))


if __name__ == '__main__':
    main()
