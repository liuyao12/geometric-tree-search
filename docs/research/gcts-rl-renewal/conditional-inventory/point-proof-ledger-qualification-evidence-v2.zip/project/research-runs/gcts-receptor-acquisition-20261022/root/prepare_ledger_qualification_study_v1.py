"""Administrative metadata only; frozen Source AST and explicit acceptance, no imports of project code."""
from pathlib import Path
import argparse
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
WORKER = ROOT / 'ledger_qualification_worker_v1.py'
PROTOCOL = ROOT / 'ledger-normal-mode-controls-protocol-v1.json'
PREPARATION = ROOT / 'ledger-normal-mode-controls-study-preparation-v1.json'
NAMES = ('MODULE_ROLES','BANK_ROLES','CONTROL_IDS','CAPS','CUSTODY_RUNTIME','POLICY_BINDING','EXPERIMENT','PROFILE','CASE','PROTOCOL_SCHEMA','MODULE_VERSIONS','PUBLIC_ENTRIES','PLAN_FIELDS')
BANK_API = {'path': str(STUDY / 'diagnostics-L' / 'contextual-library-independent-bank-API-v2.json'),
    'bytes': 8507, 'sha256': '47ea1c9b7387e9f0fe718c18b93ddc57529e8b677dc4de6d42081886f32f30f0'}
CONSUMER_ACCEPTANCE = {'path': str(ROOT / 'ledger-Source3-controls-role-component-acceptance-v1.json'),
    'bytes': 1398, 'sha256': '8a4271c4c2231119bd6aefcdbb943601f14c2768ef065e6155b97a2b490a29d4'}


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    assert path.name not in ('index.html', '.gcts-active')
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def exact(record):
    assert type(record) is dict and set(record) == {'path', 'bytes', 'sha256'}
    assert record == pin(Path(record['path']))
    return record


def load(record):
    exact(record)
    return json.loads(raw(record['path']))


def js(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + '\n').encode('ascii')


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--acceptance',required=True)
    args = parser.parse_args()
    acceptance_path = Path(args.acceptance)
    acceptance = json.loads(raw(acceptance_path))
    assert acceptance['Source_component_accepted'] is True
    assert acceptance['Source'] == pin(WORKER)
    assert acceptance['metadata_Source'] == pin(Path(__file__).resolve())
    review = load(acceptance['independent_review'])
    assert review['review_passed'] is True and review['blockers'] == []
    values = {}
    for node in ast.parse(raw(WORKER),filename=str(WORKER)).body:
        if isinstance(node,ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target,ast.Name) and target.id in NAMES:
                assert target.id not in values
                values[target.id] = ast.literal_eval(node.value)
    assert set(values) == set(NAMES)
    roles = values['MODULE_ROLES']
    assert roles == ('checker','builders','reference','instance','ordinary','consumer','wide_encoder','bank')
    assert values['BANK_ROLES'] == ('consumer','ordinary','instance','checker','builders','reference','wide_encoder')
    assert values['CASE'] == 'ledger-normal-mode-controls-v1-case-0'
    assert values['EXPERIMENT'] == 'contextual-ledger-normal-mode-qualification-v1'
    assert values['PROFILE'] == 'fpc-ledger-normal-mode-six-group-whole-v1'
    assert values['PROTOCOL_SCHEMA'] == 'Root-FPC-contextual-ledger-controls-protocol-v1'
    assert values['PUBLIC_ENTRIES']['consumer'] == ('search_with_library','search_obligations','is_owned_error')
    assert len(values['PLAN_FIELDS']) == 15 and len(set(values['PLAN_FIELDS'])) == 15
    assert values['CAPS'] == dict(work_seconds=160,positive_seconds=180,custody_seconds=210,
        observer_fallback_seconds=225,memory_bytes=1073741824,physical_bytes=134217728,
        result_bytes=50331648,log_bytes=4194304,reserved_outer_bytes=9437184,root_callbacks=400000000)
    module_pins = acceptance['module_sources']
    assert type(module_pins) is dict and set(module_pins) == set(roles)
    bank_api = load(BANK_API)
    expected_modules = dict(bank_api['runtime_sources_metadata_only'])
    expected_modules['bank'] = bank_api['Source']
    assert module_pins == expected_modules
    assert values['MODULE_VERSIONS']['bank'] == bank_api['API']['VERSION']
    assert values['MODULE_VERSIONS']['consumer'] == bank_api['required_public_namespace_versions']['consumer']
    assert tuple(bank_api['API']['module_keys']) == values['BANK_ROLES']
    assert tuple(bank_api['API']['ordered_control_ids']) == values['CONTROL_IDS']
    assert bank_api['API']['return_schema'] == 'FPC-contextual-library-independent-controls-v1'
    assert bank_api['API']['return_fields'] == ['schema','version','population','complete','control_ids','controls','counts','scope','coverage_limits']
    source_components = acceptance['Source_components']
    assert type(source_components) is list and source_components
    assert len({record['path'] for record in source_components}) == len(source_components)
    component_acceptances = acceptance['component_acceptances']
    assert type(component_acceptances) is dict and set(component_acceptances) == {'consumer','bank'}
    assert component_acceptances['consumer'] == CONSUMER_ACCEPTANCE
    files = {}

    def include(record):
        exact(record)
        name = record['path']
        assert '/actual/' not in name and not name.endswith('.bin')
        if name in files:
            assert files[name] == record
        else:
            files[name] = record

    for record in list(module_pins.values())+list(values['CUSTODY_RUNTIME'].values())+source_components+[BANK_API]:
        include(record)
    for role in ('consumer','bank'):
        record = component_acceptances[role]
        component = load(record)
        assert component['Source_component_accepted'] is True
        assert component['Source'] == module_pins[role]
        c_review = load(component['independent_review'])
        assert c_review['review_passed'] is True and c_review['blockers'] == []
        include(record)
        include(component['Source'])
        include(component['independent_review'])
    include(pin(WORKER)); include(pin(Path(__file__).resolve()))
    include(acceptance['independent_review'])
    declared_guards = acceptance['guard_sources']
    assert type(declared_guards) is list and declared_guards
    assert len({record['path'] for record in declared_guards}) == len(declared_guards)
    assert {record['path']:exact(record) for record in declared_guards} == files
    # The enclosing acceptance cannot contain its own raw hash. Its own pin and
    # the fresh protocol pin are the only two closed, derived additions.
    assert str(acceptance_path) not in files
    include(pin(acceptance_path))
    population = [dict(population='contextual_library6',control_ids=list(values['CONTROL_IDS']),groups=6,bank_role='bank',
        subject_role=['consumer'],scope='Synthetic genuine-byte ledger normal-mode controls only; forty contextual and three ordinary searches in six groups; no learned inventory, target evaluation, GCTS or RL admission.')]
    protocol = dict(schema=values['PROTOCOL_SCHEMA'],experiment=values['EXPERIMENT'],limits=values['CAPS'],module_pins=module_pins,
        control_populations=population,job_recipes=[dict(case_id=values['CASE'],stage='qualification')],
        metadata=dict(profile=values['PROFILE'],input_authority=[],Source_components=source_components,
            reference_integer_policy=list(values['POLICY_BINDING'])))
    protocol_body = js(protocol)
    protocol_pin = dict(path=str(PROTOCOL),bytes=len(protocol_body),sha256=hashlib.sha256(protocol_body).hexdigest())
    assert str(PROTOCOL) not in files
    files[str(PROTOCOL)] = protocol_pin
    plan_path = ROOT/'plans'/(values['CASE']+'.json')
    plan = dict(schema='proof-search-case-once-plan-v1',case_id=values['CASE'],stage='qualification',experiment=values['EXPERIMENT'],
        actual_dir=str(STUDY/'actual'/values['CASE']),worker_path=str(WORKER),runner_path=values['CUSTODY_RUNTIME']['runner']['path'],
        python=values['CUSTODY_RUNTIME']['python'],files=list(files.values()),limits=values['CAPS'],protocol=protocol_pin,
        profile=values['PROFILE'],module_pins=module_pins,input_authority=[],Source_components=source_components)
    assert set(plan) == set(values['PLAN_FIELDS']) and len(plan) == 15
    assert len(protocol) == 7
    assert not PROTOCOL.exists() and not PREPARATION.exists() and not plan_path.exists()
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
    plan_path.parent.mkdir(exist_ok=True)
    write(PROTOCOL,protocol_body); write(plan_path,js(plan))
    result = dict(schema='Root-ledger-normal-mode-controls-study-preparation-v1',status='PREPARED_METADATA_NO_GRANT_NO_EXECUTION',
        acceptance=pin(acceptance_path),protocol=pin(PROTOCOL),plan=pin(plan_path),Source_guard_count=len(files),
        scientific_imports_or_calls=0,data_bodies_read_or_hashed=False,
        scope='Eight-role six-group ledger normal-mode controls only; all43 normal searches charged in one cold case; no production inventory/donor/holdout intake, old bank rerun or target search.')
    write(PREPARATION,js(result))
    print(json.dumps(pin(PREPARATION)))


if __name__ == '__main__':
    main()
