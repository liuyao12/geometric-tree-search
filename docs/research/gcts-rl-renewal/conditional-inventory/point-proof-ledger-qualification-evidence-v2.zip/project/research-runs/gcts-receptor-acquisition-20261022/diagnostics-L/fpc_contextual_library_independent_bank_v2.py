"""Inert independently frozen dual-progress controls; no scientific invocation."""
import hashlib
import json
import math

VERSION = 'FPC-CONTEXTUAL-LIBRARY-INDEPENDENT-CONTROLS-v2'
SCHEMA = 'FPC-contextual-library-independent-controls-v1'
POPULATION = 'contextual_library6'
ROLES = ('consumer','ordinary','instance','checker','builders','reference','wide_encoder')
IDS = ('live-boundaries-and-hierarchy','port-context-and-discharge','sharing-and-quotient-map','common-binding-and-fallback','root-used-and-tamper','first-fault-and-isolation')
ARMS = ('CONDITIONAL_LEMMA_CD','RECEPTOR_DAG')
MODES = ('LEDGER_NONE','LEGACY_EMPTY_PROGRESS')
CONSUMER_VERSION = 'FPC-H1-CONTEXTUAL-LIBRARY-PRODUCER-v2'
SCOPE = 'Synthetic contextual-library search/lowering evidence only; no learned inventory, holdout transfer, indispensability, point-placement, GCTS or RL admission.'


class ContextualControlError(Exception):
    pass


def _need(test,message):
    if not test:raise ContextualControlError(message)


class _Call:
    def __init__(self,check):
        _need(callable(check),'callable check');self.check,self.first,self.callbacks=check,None,0
    def tick(self):
        if self.first is not None:raise self.first
        try:self.check()
        except BaseException as error:self.first=error;raise
        self.callbacks+=1


def _copy(x,c,active=None,encode_bytes=False):
    c.tick()
    if type(x) is bytes:
        if not encode_bytes:return x
        return dict(schema='L-immutable-bytes-hex-v1',bytes=len(x),sha256=hashlib.sha256(x).hexdigest(),hex=x.hex())
    if x is None or type(x) in (str,int,bool):return x
    if type(x) is float:_need(math.isfinite(x),'finite diagnostic');return x
    _need(type(x) in (list,tuple,dict),'ordinary owned carrier')
    active=set() if active is None else active
    _need(id(x) not in active,'acyclic carrier');active.add(id(x))
    if type(x) is dict:
        _need(all(type(k) is str for k in x),'exact string keys')
        out={k:_copy(v,c,active,encode_bytes) for k,v in x.items()}
    else:out=[_copy(v,c,active,encode_bytes) for v in x]
    active.remove(id(x));return out


def _same(a,b,c):
    c.tick()
    if type(a) is not type(b):return False
    if type(a) is dict:return set(a)==set(b) and all(_same(a[k],v,c) for k,v in b.items())
    if type(a) in (list,tuple):return len(a)==len(b) and all(_same(x,y,c) for x,y in zip(a,b))
    return a==b


def _i(a,b):return ['imp',a,b]
def _p(i):return ['pred',i,[]]
def _v(i):return ['param',i]
def _ref(kind,i):return dict(kind=kind,id=i)


def _logical(tag,w):
    a,b=w[:2]
    if tag==0:return _i(a,_i(b,a))
    _need(tag==1,'control H1/H2');z=w[2]
    return _i(_i(a,_i(b,z)),_i(_i(a,b),_i(a,z)))


def _ax(i,tag,w):
    return dict(local_id=i,rule_tag=1,subtag=tag,formula_pattern=_logical(tag,w),witness_pattern=w,references=[])


def _mp(i,f,a,b):
    return dict(local_id=i,rule_tag=3,subtag=None,formula_pattern=f,witness_pattern=None,references=[a,b])


def _family(name,c):
    a,b,z=(_v(i) for i in range(3));it=lambda i:_ref('internal',i);bt=lambda i:_ref('boundary',i)
    ports=[];parameters=2
    if name=='closed3':nodes=[_ax(0,0,[a,b]),_ax(1,1,[a,b,a]),_mp(2,_i(_i(a,b),_i(a,a)),it(0),it(1))]
    elif name=='witness5':
        nodes=[_ax(0,0,[a,_i(b,a)]),_ax(1,0,[a,b]),_ax(2,1,[a,_i(b,a),a]),_mp(3,_i(_i(a,_i(b,a)),_i(a,a)),it(0),it(2)),_mp(4,_i(a,a),it(1),it(3))]
    elif name=='chain2':
        parameters=3;ports=[a,_i(a,b),_i(b,z)];nodes=[_mp(0,b,bt(0),bt(1)),_mp(1,z,it(0),bt(2))]
    elif name=='self3':
        parameters=1;ports=[a];nodes=[_ax(0,0,[a,a]),_mp(1,_i(a,a),bt(0),it(0)),_mp(2,a,bt(0),it(1))]
    elif name=='link4':
        ports=[a,_i(a,b)];nodes=[_mp(0,b,bt(0),bt(1)),_ax(1,0,[b,b]),_mp(2,_i(b,b),it(0),it(1)),_mp(3,b,it(0),it(2))]
    elif name=='duplicate5':
        ports=[a,a];nodes=[_ax(0,0,[a,a]),_mp(1,_i(a,a),bt(0),it(0)),_mp(2,a,bt(1),it(1)),_ax(3,0,[a,b]),_mp(4,_i(b,a),it(2),it(3))]
    else:
        _need(name in ('shared4','duplicated5'),'literal family name');t=_logical(0,[a,b])
        if name=='shared4':nodes=[_ax(0,0,[a,b]),_ax(1,0,[t,t]),_mp(2,_i(t,t),it(0),it(1)),_mp(3,t,it(0),it(2))]
        else:nodes=[_ax(0,0,[a,b]),_ax(1,0,[a,b]),_ax(2,0,[t,t]),_mp(3,_i(t,t),it(0),it(2)),_mp(4,t,it(1),it(3))]
    key=dict(parameters=[dict(id=i,sort='Formula') for i in range(parameters)],root_local_id=len(nodes)-1,internal_nodes=nodes,boundary_nodes=[dict(boundary_id=i,formula_pattern=f) for i,f in enumerate(ports)])
    raw=json.dumps(key,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
    bc=len(ports);occ=dict(donor_id='synthetic-'+name,root_source_row=bc+len(nodes)-1,source_to_local=[[bc+i,i] for i in range(len(nodes))],boundary_source_to_port=[[i,i] for i in range(bc)],source_bindings=[dict(parameter_id=i,formula=_p(i)) for i in range(parameters)])
    return dict(family_key=_copy(key,c),family_id=hashlib.sha256(raw).hexdigest(),**key,source_occurrences=[occ],distinct_base_nodes=len(nodes),size_band='SMALL_2_4' if len(nodes)<5 else 'LARGE_5_8',validation_provenance=[0])


def _query(goal,gamma=(),table=()):
    return dict(version=1,claim_mode=1 if gamma else 0,function_arities=[],predicate_arities=[0]*4,theory_profile=0,finite_axioms=list(table),Gamma=list(gamma),goal=goal)


def _configuration(nodes=9,intro=2,witness=3):
    return dict(schema='FPC-H1-obligation-configuration-v1',control_only=True,variables=0,term_depth=0,fallback_witness_nodes=witness,obligation_nodes=nodes,priority_subformula_nodes=nodes,intro_depth=intro,oldest_period=4,ordering='FOCUSED')


def _encode(m,q,c):
    before=_copy(q,c);z=m['wide_encoder'].encode_tiny_declared_query(q,check=c.tick)
    _need(set(z)=={'query_bytes','receipt'} and type(z['query_bytes']) is bytes,'complete genuine encoding')
    _need(z['receipt']['complete'] is True and _same(z['receipt']['semantic_query'],q,c) and _same(before,q,c),'encoding/input join')
    return z


def _search(m,q,families,arm,configuration,c,check=None,progress=None,instance=None,checker=None,builders=None):
    args=dict(families=families,arm=arm,configuration=configuration,modules={k:m[k] for k in ('checker','builders')},check=c.tick if check is None else check,progress=progress)
    args['modules']['instance']=m['instance'] if instance is None else instance
    if checker is not None:args['modules']['checker']=checker
    if builders is not None:args['modules']['builders']=builders
    return m['consumer'].search_with_library(q,**args)


def _tree(arena,i,c):
    c.tick();r=arena[i];tag=r['tag'];children=[_tree(arena,j,c) for j in r['children']]
    if tag=='var':return [tag,r['symbol']]
    if tag in ('fun','pred'):return [tag,r['symbol'],children]
    if tag=='all':return [tag,r['symbol'],children[0]]
    return [tag]+children


def _instantiate(f,images,c):
    c.tick()
    if f[0]=='param':return _copy(images[f[1]],c)
    return [f[0]]+[_instantiate(a,images,c) for a in f[1:]]


def _flat(f,c):
    c.tick();tag=f[0]
    if tag in ('pred','fun'):return [[tag,f[1],len(f[2])]]+sum((_flat(x,c) for x in f[2]),[])
    if tag=='var':return [[tag,f[1]]]
    if tag=='all':return [[tag,f[1]]]+_flat(f[2],c)
    return [[tag]]+sum((_flat(x,c) for x in f[1:]),[])


def _wire_witness(p,arena,c):
    tag,w=p['rule_tag'],p['witness']
    if tag==0:return w['index']
    if tag==1:return [x['value'] if x['sort']=='V' else _tree(arena,x['id'],c) for x in w['witness']]
    if tag==2:return w['index']
    if tag==3:return None
    return w['variable']


def _compiler(plan,e,c,gamma_count=0):
    _need(set(e)=={'schema','version','status','complete','accepted','query','input_plan_sha256','arena','contexts','primitive_nodes','plan_outputs','discharges','export_map','candidate_rows','certificate','scope'},'compiler receipt16')
    _need(e['complete'] is True and e['accepted'] is False and e['status']=='ELABORATED_NOT_VALIDATED','compiler flags')
    outputs={x['node']:x['primitive'] for x in e['plan_outputs']};ps=e['primitive_nodes'];arena=e['arena']
    _need(set(outputs)==set(range(len(plan['nodes']))),'every plan output')
    for n in plan['nodes']:
        c.tick();p=ps[outputs[n['id']]];op=n['operator']
        _need(p['context']==n['context'] and _same(_tree(arena,p['formula'],c),_tree(plan['arena'],n['formula'],c),c),'plan/primitive context/formula')
        refs=[outputs[j] for j in n['premises']]
        if op=='INTRO':
            ds=[d for d in e['discharges'] if d['intro_node']==n['id']]
            _need(len(ds)==1,'one exact INTRO discharge');d=ds[0]
            _need(d['child_context']==n['payload']['child_context'] and d['parent_context']==n['context'],'INTRO context chain')
            edges=[x for x in d['mapping'] if x['input_primitive']==refs[0]]
            _need(len(edges)==1 and edges[0]['output_primitive']==p['id'],'INTRO child output edge')
            continue
        tags={'HYP':0,'LOGICAL_AXIOM':1,'THEORY_AXIOM':2,'MP':3,'GEN':4}
        _need(p['rule_tag']==tags[op] and p['premises']==refs,'complete compiler rule/ordered premises')
        if op in ('HYP','GEN'):_need(p['witness']==n['payload'] and p['subtag'] is None,'exact natural witness')
        elif op=='MP':_need(p['witness']=={} and p['subtag'] is None,'MP payload')
        else:
            _need(p['subtag']==p['witness']['tag']==n['payload']['tag'],'logical/table subtag')
            if op=='THEORY_AXIOM':_need(p['witness']==n['payload'],'table occurrence')
            else:
                _need(len(p['witness']['witness'])==len(n['payload']['witness']),'all typed witness slots')
                for x,y in zip(p['witness']['witness'],n['payload']['witness']):
                    _need(x['sort']==y['sort'] and (_same(_tree(arena,x['id'],c),_tree(plan['arena'],y['id'],c),c) if x['sort']!='V' else x['value']==y['value']),'typed witness value')
    for d in e['discharges']:
        c.tick();child=d['child_context'];cx=e['contexts'][child];depth=0;at=child
        while at:depth+=1;at=e['contexts'][at]['parent']
        _need(cx['parent']==d['parent_context'] and cx['opener']==d['intro_node'] and d['discharged_hypothesis_index']==gamma_count+depth-1,'full exact discharge occurrence ownership')
        source_root=outputs[plan['nodes'][d['intro_node']]['premises'][0]];required=set();todo=[source_root]
        while todo:
            c.tick();i=todo.pop()
            if i not in required:required.add(i);todo.extend(ps[i]['premises'])
        _need({x['input_primitive'] for x in d['mapping']}==required and len(d['mapping'])==len(required),'complete discharge source closure')
        assumption=_tree(arena,cx['assumption'],c)
        for edge in d['mapping']:
            before,after=ps[edge['input_primitive']],ps[edge['output_primitive']]
            expected='DISCHARGED_HYP' if before['rule_tag']==0 and before['witness']['index']==d['discharged_hypothesis_index'] else 'LIFT_HYP_OR_AXIOM' if before['rule_tag'] in (0,1,2) else 'LIFT_MP' if before['rule_tag']==3 else 'LIFT_GEN'
            _need(edge['case']==expected and before['context']==child and after['context']==d['parent_context'] and _tree(arena,after['formula'],c)==_i(assumption,_tree(arena,before['formula'],c)),'every discharge case/transformed Formula')
    root=outputs[plan['root']];seen=set();pending=[root]
    while pending:
        c.tick();i=pending.pop()
        if i not in seen:seen.add(i);pending.extend(ps[i]['premises'])
    exports={x['primitive']:x['row'] for x in e['export_map']}
    _need(set(exports)==seen and len(e['candidate_rows'])==len(seen),'complete final root closure/export')
    for i in seen:
        c.tick();p=ps[i];row=e['candidate_rows'][exports[i]]
        _need(row['primitive']==i and row['index']==exports[i] and p['context']==0,'root-context exported identity')
        _need(row['formula']==_tree(arena,p['formula'],c) and row['rule_tag']==p['rule_tag'] and row['subtag']==p['subtag'],'exported formula/rule')
        _need(row['references']==[exports[j] for j in p['premises']] and _same(row['witness'],_wire_witness(p,arena,c),c),'exported ordered refs/witness')
    return outputs,seen,exports


def _validate(m,q,result,c):
    _need(type(result['candidate_certificate_bytes']) is bytes,'immutable candidate bytes');p=result['candidate_certificate_bytes']
    s=_copy(m['checker'].check_certificate(q,p,check=c.tick),c);r=_copy(m['reference'].reference_check_certificate(q,p,check=c.tick),c)
    _need(s['accepted'] is True and s['complete'] is True and s['final_goal_equal'] is True and r['complete_check'] is True and r['status']=='VALID_DERIVATION' and r['final_goal_equal'] is True,'full original same-byte dual gate')
    _need(s['raw_inputs']['query']==dict(bytes=len(q),sha256=hashlib.sha256(q).hexdigest()) and s['raw_inputs']['certificate']==dict(bytes=len(p),sha256=hashlib.sha256(p).hexdigest()),'same original byte identities')
    elaboration=result['receipt'].get('elaboration',result['receipt'])
    _need(elaboration['certificate']==s['raw_inputs']['certificate'] and elaboration['query']==s['raw_inputs']['query'],'complete compiler/original byte pin equality')
    sr=s['certificate']['rows'];rr=r['rows'];rows=result['receipt']['candidate_rows']
    _need(len(sr)==len(rr)==len(rows) and s['query']['EOF']==len(q) and s['certificate']['EOF']==len(p),'complete EOF/rows')
    for x,a,b in zip(rows,sr,rr):
        c.tick();_need(x['index']==a['index']==b['index'] and x['formula']==a['formula'] and b['formula']['prefix_tokens']==_flat(x['formula'],c),'full nested/flat Formula association')
        _need(x['rule_tag']==a['rule_tag']==b['rule_tag'] and x['subtag']==a['subtag']==b['witness_tag'] and a['span']==list(b['byte_span']),'paired row rules/spans')
        witness=x['references'] if x['rule_tag']==3 else x['witness'] if x['rule_tag']==1 else [x['witness']]
        _need(_same(a['witness'],witness,c),'subject complete ordered payload')
        if x['rule_tag']==1:_need([t['prefix_tokens'] for t in b['payload']]==[_flat(w,c) for w in witness],'independent logical payload')
        else:_need(list(b['payload'])==witness,'independent natural payload')
    return dict(subject_receipt=s,reference_receipt=r)


def _trace(plan_node,t,e,outputs,seen,exports,c):
    if plan_node is None:
        _need(t==dict(status='PRUNED',primitive=None,transformations=[],final_primitive=None,wire_row=None),'explicit pruned trace');return False
    current=outputs[plan_node];_need(t['primitive']==current,'trace plan output');wanted=[]
    for di,d in enumerate(e['discharges']):
        edges=[(j,x) for j,x in enumerate(d['mapping']) if x['input_primitive']==current]
        if not edges:continue
        _need(len(edges)==1,'unique discharge image');ei,edge=edges[0]
        assumption=e['contexts'][d['child_context']]['assumption'];before=e['primitive_nodes'][current];after=e['primitive_nodes'][edge['output_primitive']]
        _need(before['context']==d['child_context'] and after['context']==d['parent_context'] and _tree(e['arena'],after['formula'],c)==_i(_tree(e['arena'],assumption,c),_tree(e['arena'],before['formula'],c)),'discharge exact transformed Formula/context')
        wanted.append(dict(intro_node=d['intro_node'],child_context=d['child_context'],parent_context=d['parent_context'],assumption_formula_id=assumption,discharged_hypothesis_index=d['discharged_hypothesis_index'],edge=edge,discharge_record_index=di,mapping_edge_index=ei,full_record_path=['elaboration','discharges',di]));current=edge['output_primitive']
    _need(_same(t['transformations'],wanted,c) and t['final_primitive']==current,'all discharge transformations retained')
    final=current in seen
    _need(t['status']==('FINAL_ROOT_DEPENDENCY' if final else 'NOT_FINAL_ROOT_DEPENDENCY') and t['wire_row']==(exports[current] if final else None),'trace final-root status/export')
    return final


def _use_maps(result,c):
    r=result['receipt'];lib=r['library'];lower=lib['selected_lowering'];maps=lib['compiler_maps']
    if result['status']!='CANDIDATE_FOUND':
        _need(result['candidate_certificate_bytes'] is None,'noncandidate has no bytes');return dict(applications=0,hierarchy=False,open_use=False,closed_use=False,CD_contexts=0)
    e=r['elaboration'];plan=r['selected_plan'];c.tick()
    _need(e['certificate']==dict(bytes=len(result['candidate_certificate_bytes']),sha256=hashlib.sha256(result['candidate_certificate_bytes']).hexdigest()) and e['query']=={k:r['query'][k] for k in ('bytes','sha256')},'compiler/search/original byte association')
    outputs,seen,exports=_compiler(plan,e,c,len(r['query']['Gamma']))
    _need(maps['final_root_primitive']==outputs[plan['root']] and set(maps['final_root_dependencies'])==seen and len(maps['final_root_dependencies'])==len(seen) and maps['distinct_final_rows']==len(exports) and maps['origins_are_mapping_authority'] is False and maps['external_same_byte_dual_validation']=='NOT_RUN_REQUIRED','compiler maps final scope')
    _need([x['plan_node'] for x in maps['plan_associations']]==list(range(len(plan['nodes']))),'complete ordered compiler associations')
    for a in maps['plan_associations']:
        intro=plan['nodes'][a['plan_node']]['operator']=='INTRO'
        _need(a['primitive']==outputs[a['plan_node']] and a['checked_complete_key'] is (not intro) and a['INTRO'] is intro,'association identity')
    groups={}
    for node,primitive in outputs.items():groups.setdefault(primitive,[]).append(node)
    given={g['primitive']:g for g in maps['quotient_groups']}
    _need(len(given)==len(maps['quotient_groups']) and _same(given,{p:dict(primitive=p,plan_nodes=nodes,many_to_one=len(nodes)>1) for p,nodes in groups.items()},c),'complete quotient relation')
    pruning={x['unpruned_plan_node']:x['plan_node'] for x in lower['pruning']};offers={x['id']:x for x in lib['offers']};obs={x['id']:x for x in r['obligations']};context_map={x['search_context']:x['plan_context'] for x in lower['context_map']}
    _need([x['unpruned_plan_node'] for x in lower['pruning']]==list(range(len(lower['pruning']))) and len(context_map)==len(lower['context_map']),'full unique pruning/context map')
    _need(lower['symbolic_placement_claim'] is False,'no point-placement claim');app_owners=set();dependency_owners=[];opened=False;closed=False;cd=0
    for app in lower['applications']:
        c.tick();offer=offers[app['offer_id']];owner=obs[app['owner_obligation_id']];family=lib['families'][app['family_index']];binding=[x['formula'] for x in app['binding']]
        _need(app['family_key']==family['family_key']==offer['family_key'] and app['binding']==offer['binding'] and app['owner_obligation_id']==offer['owner'] and app['selected_alternative_id']==offer['alternative_id']==owner['selected_alternative_id'] and app['selected_serial']==owner['solved_serial'],'selected live offer association')
        _need(app['owner_context_id']==owner['context_id']==offer['context_id'] and app['arm']==lib['arm'],'same owner context/arm')
        _need(len(app['boundaries'])==len(family['boundary_nodes']) and len(app['internal_nodes'])==len(family['internal_nodes']),'every port/local identity')
        owner_context=context_map[app['owner_context_id']]
        for port,row in zip(family['boundary_nodes'],app['boundaries']):
            j=port['boundary_id'];ob=obs[row['obligation_id']]
            _need(row['boundary_id']==j and row['obligation_id']==offer['boundary_obligation_ids'][j] and row['formula_id']==offer['boundary_formula_ids'][j] and ob['formula_id']==row['formula_id'] and ob['context_id']==owner['context_id'] and ob['state']=='SOLVED' and ob['solved_serial']==row['proof_serial']<app['selected_serial'],'real earlier same-context port proof')
            _need(_tree(r['arena'],row['formula_id'],c)==_instantiate(port['formula_pattern'],binding,c),'instantiated ordered boundary')
            for stem in ('proof','body'):
                pn=row[stem+'_plan_node'];_need(pruning[row['unpruned_'+stem+'_plan_node']]==pn,'port pruning remap');_trace(pn,row[stem+'_trace'],e,outputs,seen,exports,c)
                if pn is not None:_need(_tree(plan['arena'],plan['nodes'][pn]['formula'],c)==_tree(r['arena'],row['formula_id'],c),'port plan Formula')
            if row['proof_plan_node'] is not None:_need(plan['nodes'][row['proof_plan_node']]['context']==owner_context,'actual premise owner context')
            dependency_owners.append(row['obligation_id'])
        actual_final=[]
        for n,row in zip(family['internal_nodes'],app['internal_nodes']):
            _need(row['local_id']==n['local_id'] and _tree(r['arena'],row['formula_id'],c)==_instantiate(n['formula_pattern'],binding,c) and pruning[row['unpruned_plan_node']]==row['plan_node'],'every symbolic local/pruning Formula')
            actual_final.append(_trace(row['plan_node'],row['trace'],e,outputs,seen,exports,c))
            if row['plan_node'] is not None:
                pn=plan['nodes'][row['plan_node']];_need(_tree(plan['arena'],pn['formula'],c)==_instantiate(n['formula_pattern'],binding,c),'local plan Formula')
                if n['rule_tag']==1:
                    _need(pn['operator']=='LOGICAL_AXIOM' and pn['payload']['tag']==n['subtag'] and not pn['premises'],'local logical rule')
                    _need([_tree(plan['arena'],w['id'],c) for w in pn['payload']['witness']]==[_instantiate(w,binding,c) for w in n['witness_pattern']],'all local logical witness images')
                else:
                    refs=[app['internal_nodes'][x['id']]['plan_node'] if x['kind']=='internal' else app['boundaries'][x['id']]['body_plan_node'] for x in n['references']]
                    _need(pn['operator']=='MP' and pn['premises']==refs,'local authoritative ordered MP map')
        _need(app['all_internal_images_final'] is all(actual_final) and pruning[app['unpruned_output_plan_node']]==app['output_plan_node'],'local final status/output remap')
        _trace(app['output_plan_node'],app['output_trace'],e,outputs,seen,exports,c)
        for stem in ('INTRO_nodes','application_MP_nodes'):_need([pruning[j] for j in app['unpruned_'+stem]]==app[stem],'lowering step pruning remap')
        if app['arm']=='RECEPTOR_DAG':
            _need(not app['lowering_context_ids'] and all(b['body_plan_node']==b['proof_plan_node'] for b in app['boundaries']),'direct genuine premise attachment')
        else:
            _need(len(app['lowering_context_ids'])==len(app['boundaries']),'CD temporary contexts per ordered port')
            depth=0;ci=owner_context
            while ci:depth+=1;ci=plan['contexts'][ci]['parent']
            for j,ci in enumerate(app['lowering_context_ids']):
                cx=plan['contexts'][ci];parent=owner_context if j==0 else app['lowering_context_ids'][j-1]
                _need(cx['parent']==parent and _tree(plan['arena'],cx['assumption'],c)==_instantiate(family['boundary_nodes'][j]['formula_pattern'],binding,c),'CD exact assumption context chain')
                pn=app['boundaries'][j]['body_plan_node']
                if pn is not None:_need(plan['nodes'][pn]['operator']=='HYP' and plan['nodes'][pn]['payload']==dict(index=len(r['query']['Gamma'])+depth+j),'distinct CD hypothesis occurrence index')
        body_context=app['lowering_context_ids'][-1] if app['lowering_context_ids'] else owner_context
        for row in app['internal_nodes']:
            if row['plan_node'] is not None:_need(plan['nodes'][row['plan_node']]['context']==body_context,'all internal nodes in correct body context')
        cd+=len(app['lowering_context_ids']);opened|=bool(app['boundaries']);closed|=not app['boundaries'];app_owners.add(app['owner_obligation_id'])
    return dict(applications=len(lower['applications']),hierarchy=bool(app_owners.intersection(dependency_owners)),open_use=opened,closed_use=closed,CD_contexts=cd)


def _size(f):
    return 1 if f[0]=='pred' else 1+sum(_size(x) for x in f[1:])


def _library(result,q,configuration,c):
    _need(set(result)=={'status','candidate_certificate_bytes','receipt'},'complete search return3')
    _need(result['status'] in ('CANDIDATE_FOUND','UNKNOWN_DECLARED_PRODUCER','SOURCE_OUTSIDE_DECLARED_SCOPE'),'closed normal status vocabulary')
    r=result['receipt'];expected={'schema','version','query','configuration','status','accepted','candidate_validation','scope','arena','contexts','obligations','alternatives','sources','cursors','coverage','counts','selected_plan','candidate_rows','library','operations'}
    if result['status']=='CANDIDATE_FOUND':expected.add('elaboration')
    _need(set(r)==expected and r['schema']=='FPC-H1-contextual-library-search-receipt-v1' and r['version']==CONSUMER_VERSION and r['accepted'] is False and r['status']==result['status'],'search receipt exact identity/flags')
    if result['status']=='CANDIDATE_FOUND':_need(r['elaboration']['version']==CONSUMER_VERSION,'owned compiler receipt VERSION')
    _alternatives(result,c)
    _need(r['configuration']==configuration and all(r['query'][k]==v for k,v in q.items()),'untouched semantic query/configuration')
    lib=r['library'];_need(set(lib)=={'binding_policy','arm','families','domain_seed','domain_entries','W_consumed','domain_eof','priority_sublane_visits','sync_sublane_visits','records','queue','offers','counts','selected_lowering','compiler_maps','accepted','proof_use_admitted'} and lib['binding_policy']=='QUERY_FORMULA_SUBFORMULAS_PLUS_ORIGINAL_W_v1' and lib['accepted'] is False and lib['proof_use_admitted'] is False,'complete library17/scope')
    expected_seed=[]
    def walk(f):
        c.tick()
        if f not in expected_seed:expected_seed.append(f)
        for child in f[1:] if f[0] in ('not','imp') else []:walk(child)
    for f in q['Gamma']+q['finite_axioms']+[q['goal']]:walk(f)
    _need([_tree(r['arena'],i,c) for i in lib['domain_seed']]==expected_seed,'fixed original preorder seed')
    _need(lib['domain_entries'][:len(lib['domain_seed'])]==lib['domain_seed'] and len(set(lib['domain_entries']))==len(lib['domain_entries']) and type(lib['W_consumed']) is int and lib['W_consumed']>=0 and type(lib['domain_eof']) is bool,'domain cursor/prefix/uniqueness')
    for i in lib['domain_entries'][len(lib['domain_seed']):]:_need(_size(_tree(r['arena'],i,c))<=configuration['fallback_witness_nodes'],'tail only original W envelope')
    for offer in lib['offers']:
        c.tick();_need(set(offer)=={'id','owner','context_id','family_index','family_key','binding','boundary_formula_ids','boundary_obligation_ids','alternative_id','matcher_receipt'},'complete offer10')
        f=lib['families'][offer['family_index']];images=[x['formula'] for x in offer['binding']]
        _need(offer['family_key']==f['family_key'] and [x['parameter_id'] for x in offer['binding']]==list(range(len(f['parameters']))),'complete simultaneous binding')
        for x in offer['binding']:
            _need(_tree(r['arena'],x['formula_id'],c)==x['formula'] and (x['formula'] in expected_seed or _size(x['formula'])<=configuration['fallback_witness_nodes']),'fixed semantic image membership')
        _need([_tree(r['arena'],i,c) for i in offer['boundary_formula_ids']]==[_instantiate(p['formula_pattern'],images,c) for p in f['boundary_nodes']],'all ordered instantiated ports')
        owner=r['obligations'][offer['owner']];_need(owner['context_id']==offer['context_id'],'same owner context')
        _need(_tree(r['arena'],owner['formula_id'],c)==_instantiate(f['internal_nodes'][f['root_local_id']]['formula_pattern'],images,c),'whole root match')
        _need(len(offer['boundary_obligation_ids'])==len(offer['boundary_formula_ids']),'every ordered boundary obligation')
        for i,fi in zip(offer['boundary_obligation_ids'],offer['boundary_formula_ids']):_need(r['obligations'][i]['context_id']==offer['context_id'] and r['obligations'][i]['formula_id']==fi,'real same-context boundary wants')
        used=set()
        def parameters(p):
            if p[0]=='param':used.add(p[1])
            else:
                for a in p[1:]:parameters(a)
        parameters(f['internal_nodes'][f['root_local_id']]['formula_pattern'])
        for p in f['boundary_nodes']:parameters(p['formula_pattern'])
        wanted=dict(matched=True,bindings=[dict(parameter_id=j,formula=images[j]) for j in range(len(images)) if j in used],residual_parameters=[p for p in f['parameters'] if p['id'] not in used])
        _need(_same(offer['matcher_receipt'],wanted,c),'exact matcher restriction and legitimate residual complement')
    return _use_maps(result,c)


def _common(a,b,c):
    left=a['receipt']['library'];right=b['receipt']['library']
    fields=('binding_policy','families','domain_seed','domain_entries','W_consumed','domain_eof','priority_sublane_visits','sync_sublane_visits','records','queue','offers','counts')
    _need(a['status']==b['status'] and all(_same(left[k],right[k],c) for k in fields),'same complete common operator/offer trajectory')


def _alternatives(result,c):
    rows=result['receipt']['alternatives']
    _need(type(rows) is list,'ordered complete alternatives')
    fields={'id','owner','operator','premise_ids','witness','program','status','key','guard_receipt'}
    for i,row in enumerate(rows):
        c.tick();_need(type(row) is dict and set(row)==fields and type(row['id']) is int and row['id']==i,'exact public alternative9/insertion order')
        key=row['key'];_need(type(key) is dict and set(key)=={'operator','premises','payload','program'},'exact public key4')
        _need(_same(key,dict(operator=row['operator'],premises=row['premise_ids'],payload=row['witness'],program=row['program']),c),'independent row/key complete association')
        _need(_same(row['guard_receipt'],dict(complete=True,scope='CONCRETE_OPERATOR_GUARDS_NO_PROOF_AUTHORITY'),c),'exact constant concrete guard')


def _projection(result,c):
    out=_copy(result,c);callbacks=out['receipt']['counts']['callbacks']
    _need(type(callbacks) is int and callbacks>=0,'exact captured callback count')
    out['receipt']['counts']['callbacks']='NORMALIZED_CAPTURED_CALLBACK_COUNT_ONLY'
    return out


def _poke(container,c):
    c.tick()
    if type(container) is dict:container['L_detached_return_mutation']=True
    elif type(container) is list:container.append('L_detached_return_mutation')


def _isolation(result,retained,before,q,families,configuration,progress,c):
    saved=_copy(retained,c);view=_copy(progress,c);r=result['receipt'];mutated=[]
    _poke(r['query']['Gamma'],c);mutated.append('receipt.query.Gamma')
    if r['library']['families']:
        r['library']['families'][0]['source_occurrences'][0]['donor_id']='returned-copy-only';mutated.append('receipt.library.families.source_occurrences')
    for row in r['alternatives']:
        c.tick();_poke(row['key']['payload'],c);_poke(row['key']['program'],c);_poke(row['key']['premises'],c)
        _poke(row['witness'],c);_poke(row['program'],c);_poke(row['premise_ids'],c);row['guard_receipt']['complete']=False
    _poke(r['alternatives'],c);mutated.append('receipt.alternatives.rows.keys.payloads.programs.premises.guards')
    _need(_same(before,dict(query=q,families=families,configuration=configuration),c),'every normal returned mutation leaves input lifetime unchanged')
    _need(_same(progress,view,c),'every normal returned mutation leaves supplied progress unchanged')
    _need(_same(retained,saved,c),'every complete retained result independent of returned mutation')
    return dict(returned_result_mutated=True,mutated=mutated,input_unchanged=True,progress_present=progress is not None,progress_unchanged=True,complete_retained_result_unchanged=True)


def _pair(m,name,q,families,configuration,c,call_base):
    encoded=_encode(m,q,c);before=_copy(dict(query=q,families=families,configuration=configuration),c);mode_records=[];mode_results=[];mode_progress=[]
    for mode_index,mode in enumerate(MODES):
        results=[];validations=[];coverage=[];progress_views=[];callbacks=[];isolations=[];order=[]
        for arm_index,arm in enumerate(ARMS):
            progress=None if mode=='LEDGER_NONE' else []
            start=c.callbacks;result=_search(m,encoded['query_bytes'],families,arm,configuration,c,progress=progress);stop=c.callbacks
            captured=result['receipt']['counts']['callbacks'];_need(type(captured) is int and 0<=captured<=stop-start,'snapshot callbacks bounded by genuine complete search observations')
            callbacks.append(dict(arm=arm,progress_mode=mode,before_search=start,after_search=stop,observed_search_callbacks=stop-start,captured_receipt_callbacks=captured,capture_scope='Original snapshot capture site; observed search includes later detached return work.'))
            order.append(dict(ordinal=call_base+mode_index*2+arm_index,arm=arm,progress_mode=mode))
            _need(_same(before,dict(query=q,families=families,configuration=configuration),c),'all input/nonmutation')
            coverage.append(_library(result,q,configuration,c))
            validations.append(_validate(m,encoded['query_bytes'],result,c) if result['status']=='CANDIDATE_FOUND' else None)
            retained=_copy(result,c);isolations.append(_isolation(result,retained,before,q,families,configuration,progress,c))
            results.append(retained);progress_views.append(progress)
        _common(results[0],results[1],c)
        mode_records.append(_copy(dict(name=name,encoding=encoded,families=families,configuration=configuration,complete_results=results,complete_validations=validations,observed_use=coverage,progress_mode=mode,call_order=order,callback_observations=callbacks,complete_progress_views=progress_views,detached_return_checks=isolations),c))
        mode_results.append(results);mode_progress.append(progress_views)
    comparisons=[]
    for i,arm in enumerate(ARMS):
        _need(_same(_projection(mode_results[0][i],c),_projection(mode_results[1][i],c),c),'complete same-arm cross-mode scientific projection')
        _need(_same(mode_records[0]['complete_validations'][i],mode_records[1]['complete_validations'][i],c),'complete same-byte dual-validator mode equality')
        comparisons.append(dict(arm=arm,complete_scientific_projection_equal=True,complete_validations_equal=True,exact_normalized_paths=['/receipt/counts/callbacks'],all_other_fields_and_order_exact=True))
    record=mode_records[0];record['legacy_mode']=mode_records[1];record['mode_equivalence']=comparisons
    return record,mode_results[0],mode_progress[1]


def _ordinary_modes(m,encoding,configuration,c):
    q=encoding['receipt']['semantic_query'];before=_copy(dict(query=q,configuration=configuration),c);records=[];results=[];validations=[]
    for i,mode in enumerate(MODES):
        progress=None if mode=='LEDGER_NONE' else []
        start=c.callbacks
        result=m['consumer'].search_obligations(encoding['query_bytes'],configuration=configuration,modules={k:m[k] for k in ('checker','builders')},check=c.tick,progress=progress)
        stop=c.callbacks;r=result['receipt'];captured=r['counts']['callbacks']
        _need(type(captured) is int and 0<=captured<=stop-start,'ordinary snapshot callbacks bounded by complete observed search')
        _need(set(result)=={'status','candidate_certificate_bytes','receipt'} and result['status']==r['status']=='CANDIDATE_FOUND','current ordinary complete three-key candidate')
        _need(r['schema']=='FPC-H1-obligation-search-receipt-v1' and r['version']==CONSUMER_VERSION and r['accepted'] is False,'current ordinary receipt identity')
        _need(_same(r['configuration'],configuration,c) and all(_same(r['query'][k],v,c) for k,v in q.items()),'current ordinary original configuration/query')
        _alternatives(result,c);e=r['elaboration']
        _need(e['version']==CONSUMER_VERSION and _same(r['candidate_rows'],e['candidate_rows'],c),'ordinary owned complete candidate rows/compiler VERSION')
        _compiler(r['selected_plan'],e,c,len(q['Gamma']));validation=_validate(m,encoding['query_bytes'],result,c)
        if progress is not None:_need(len(progress)==1 and r is progress[0],'ordinary legacy original live receipt association')
        retained=_copy(result,c);saved=_copy(retained,c);view=_copy(progress,c)
        _poke(r['query']['Gamma'],c);_poke(r['configuration'],c)
        for row in r['alternatives']:
            c.tick();_poke(row['key']['payload'],c);_poke(row['key']['program'],c);_poke(row['key']['premises'],c)
            _poke(row['witness'],c);_poke(row['program'],c);_poke(row['premise_ids'],c);row['guard_receipt']['complete']=False
        _poke(r['alternatives'],c);r['L_returned_live_probe']=True
        _need(_same(before,dict(query=q,configuration=configuration),c) and _same(retained,saved,c),'ordinary input and separately retained complete evidence isolation')
        if progress is not None:_need(r is progress[0] and progress[0]['L_returned_live_probe'] is True,'ordinary legacy returned mutation observable through promised live alias')
        records.append(_copy(dict(progress_mode=mode,normal_search_ordinal=42+i,encoding=encoding,configuration=configuration,complete_result=retained,complete_validation=validation,complete_normal_progress=view,callback_observation=dict(before_search=start,after_search=stop,observed_search_callbacks=stop-start,captured_receipt_callbacks=captured,capture_scope='Original capture site, not complete detached-return callback total.'),association_checks=dict(complete_original_selected_plan_compiler=True,complete_candidate_rows=True,complete_alternative_keys_guards=True,full_same_byte_dual_validation=True),lifetime_checks=dict(returned_mutation_checked=True,input_unchanged=True,complete_retained_result_unchanged=True,receipt_is_supplied_progress_entry=progress is not None,promise='DETACHED_NONE_NORMAL_RETURN' if progress is None else 'LIVE_LEGACY_RETURN_PROGRESS_ASSOCIATION')),c))
        results.append(retained);validations.append(validation)
    _need(_same(_projection(results[0],c),_projection(results[1],c),c),'complete current ordinary same-entry mode scientific projection')
    _need(_same(validations[0],validations[1],c),'complete current ordinary same-byte dual validation equality')
    return dict(existing_fixture='empty-fallback',existing_case_index=7,routes=records,mode_equivalence=dict(complete_scientific_projection_equal=True,complete_validations_equal=True,exact_normalized_paths=['/receipt/counts/callbacks'],all_other_fields_and_order_exact=True),coverage_limits=['Current ordinary normal routes only; native/cleanup failure paths remain UNEXERCISED.'])


class _Plan:
    def __init__(self,c):self.c,self.arena,self.index,self.nodes,self.contexts=c,[],{},[],[dict(id=0,parent=None,opener=None,assumption=None)]
    def formula(self,f):
        self.c.tick();tag=f[0];symbol=f[1] if tag=='pred' else None
        children=[] if tag=='pred' else [self.formula(x) for x in f[1:]];key=('F',tag,symbol,tuple(children))
        if key not in self.index:
            i=len(self.arena);self.index[key]=i;self.arena.append(dict(id=i,sort='F',tag=tag,symbol=symbol,children=children))
        return self.index[key]
    def node(self,context,formula,operator,premises,payload):
        i=len(self.nodes);self.nodes.append(dict(id=i,context=context,formula=self.formula(formula),operator=operator,premises=premises,payload=payload));return i
    def finish(self,root):return dict(schema='FPC-H1-obligation-plan-v1',arena=self.arena,contexts=self.contexts,nodes=self.nodes,root=root)


def _family_plan(f,images,gamma,CD,share,c):
    b=_Plan(c);ports=[_instantiate(p['formula_pattern'],images,c) for p in f['boundary_nodes']];proofs=[]
    for j,formula in enumerate(ports):
        if share and j and formula==ports[0]:proofs.append(proofs[0])
        else:proofs.append(b.node(0,formula,'HYP',[],dict(index=j)))
    context=0;body_ports=proofs
    if CD:
        for formula in ports:
            context=len(b.contexts);b.contexts.append(dict(id=context,parent=context-1,opener=None,assumption=b.formula(formula)))
        body_ports=[b.node(context,formula,'HYP',[],dict(index=len(gamma)+j)) for j,formula in enumerate(ports)]
    local=[]
    for n in f['internal_nodes']:
        formula=_instantiate(n['formula_pattern'],images,c)
        if n['rule_tag']==1:
            payload=dict(tag=n['subtag'],witness=[dict(sort='F',id=b.formula(_instantiate(w,images,c))) for w in n['witness_pattern']]);operator='LOGICAL_AXIOM';premises=[]
        else:
            payload={};operator='MP';premises=[local[r['id']] if r['kind']=='internal' else body_ports[r['id']] for r in n['references']]
        local.append(b.node(context,formula,operator,premises,payload))
    root=local[f['root_local_id']];formula=_instantiate(f['internal_nodes'][f['root_local_id']]['formula_pattern'],images,c)
    if CD:
        for j in reversed(range(len(ports))):
            formula=_i(ports[j],formula);opener=b.node(j,formula,'INTRO',[root],dict(child_context=j+1));b.contexts[j+1]['opener']=opener;root=opener
        for j,premise in enumerate(proofs):formula=formula[2];root=b.node(0,formula,'MP',[premise,root],{})
    return b.finish(root),dict(local_to_plan=[[j,i] for j,i in enumerate(local)],port_to_proof_plan=[[j,i] for j,i in enumerate(proofs)],port_to_body_plan=[[j,i] for j,i in enumerate(body_ports)])


def _unit(m,name,query,plan,associations,c):
    encoding=_encode(m,query,c);before=_copy(plan,c)
    result=m['ordinary'].compile_plan(encoding['query_bytes'],plan,modules={k:m[k] for k in ('checker','builders')},check=c.tick)
    _need(set(result)=={'candidate_certificate_bytes','receipt'} and _same(before,plan,c),'old compiler complete return/nonmutation')
    outputs,seen,exports=_compiler(plan,result['receipt'],c,len(query['Gamma']));validation=_validate(m,encoding['query_bytes'],result,c)
    return dict(name=name,encoding=encoding,plan=plan,source_associations=associations,complete_compilation=result,complete_validation=validation,component_scope='Original public compiler component evidence; not selected consumer application.'),outputs


def _nested_plan(c):
    p=_p(0);b=_Plan(c);fid=b.formula(p)
    b.contexts.extend([dict(id=1,parent=0,opener=2,assumption=fid),dict(id=2,parent=1,opener=1,assumption=fid)])
    b.node(2,p,'HYP',[],dict(index=1))
    b.node(1,_i(p,p),'INTRO',[0],dict(child_context=2))
    b.node(0,_i(p,_i(p,p)),'INTRO',[1],dict(child_context=1))
    return b.finish(2)


class _Probe:
    def __init__(self,c,error):self.c,self.error,self.hits,self.after,self.raised=c,error,0,0,False
    def check(self):
        if self.raised:self.after+=1;raise self.error
        self.c.tick()
    def tick(self):return self.check()
    def boom(self,*args,**kwargs):
        self.check();self.hits+=1;self.raised=True;raise self.error


class _FaultNamespace:
    def __init__(self,version,endpoint,probe):self.VERSION,self.endpoint,self.probe=version,endpoint,probe
    def __getattr__(self,name):
        if name==self.endpoint:return self.probe.boom
        raise AttributeError(name)


class _FaultDelegate:
    def __init__(self,original,endpoint,probe):self.original,self.endpoint,self.probe=original,endpoint,probe
    def __getattr__(self,name):return self.probe.boom if name==self.endpoint else getattr(self.original,name)


def _fault(action,probe,c,label):
    try:action()
    except BaseException as error:
        if c.first is not None:raise c.first
        if error is not probe.error:raise
        _need(probe.hits==1 and probe.after==0,'exact selected fault/no later selected check')
        return dict(locator=label,error_class=type(error).__name__,same_object=True,selected_hits=probe.hits,later_selected_checks=probe.after)
    raise ContextualControlError('missing selected fault '+label)


def _expect_bad_map(result,c,label):
    try:_use_maps(result,c)
    except ContextualControlError as error:
        if c.first is not None:raise c.first
        return dict(locator=label,independent_association_refused=True,message=str(error))
    raise ContextualControlError('tampered evidence accepted '+label)


def _expect_bad_compiler(unit,c,label):
    try:_compiler(unit['plan'],unit['complete_compilation']['receipt'],c,len(unit['encoding']['receipt']['semantic_query']['Gamma']))
    except ContextualControlError as error:
        if c.first is not None:raise c.first
        return dict(locator=label,independent_association_refused=True,message=str(error),scope='Original compiler component evidence; not a public consumer verifier.')
    raise ContextualControlError('tampered compiler association accepted '+label)


def run_bank(modules,*,check):
    c=_Call(check);c.tick();_need(type(modules) is dict and set(modules)==set(ROLES),'exact seven authenticated namespaces')
    m=modules
    for role,version in dict(consumer=CONSUMER_VERSION,ordinary='FPC-H1-OBLIGATION-PRODUCER-v2',instance='FPC-RECEPTOR-INSTANCE-SERVICE-v2',wide_encoder='L-wide-FPC-query-encoder-v1').items():_need(getattr(m[role],'VERSION',None)==version,'public version '+role)
    p,q,r,s=(_p(i) for i in range(4));families={name:_family(name,c) for name in ('closed3','witness5','chain2','self3','link4','duplicate5','shared4','duplicated5')}
    cases=[];raw_results=[];progress=[]
    declarations=[
        ('closed-repeated',_query(_i(_i(p,p),_i(p,p))),['closed3'],_configuration(9,0,1)),
        ('compound-witness-residual',_query(_i(_i(p,q),_i(p,q))),['witness5'],_configuration(9,0,3)),
        ('open-seeded-intro0',_query(q,[p,_i(p,q),_i(q,p)]),['link4'],_configuration(3,0,1)),
        ('recursive-hierarchy',_query(r,[p,_i(p,q),_i(q,r)]),['link4'],_configuration(3,0,1)),
        ('self-cycle',_query(p),['self3'],_configuration(3,0,1)),
        ('mutual-cycle',_query(p,[_i(p,q),_i(q,p)]),['link4'],_configuration(3,0,1)),
        ('duplicate-ports',_query(_i(q,p),[p,p]),['duplicate5'],_configuration(5,2,1)),
        ('empty-fallback',_query(p,[p]),[],_configuration(3,0,1)),
        ('no-hit-fallback',_query(p,[p]),['closed3'],_configuration(3,0,1)),
        ('outside-boundary',_query(p),['chain2'],_configuration(1,0,1))]
    for case_index,(name,query,names,cfg) in enumerate(declarations):
        c.tick();record,results,views=_pair(m,name,query,[families[x] for x in names],cfg,c,case_index*4+1)
        for mode_record in (record,record['legacy_mode']):
            if name in ('self-cycle','mutual-cycle','outside-boundary'):_need(all(x['status']=='UNKNOWN_DECLARED_PRODUCER' for x in mode_record['complete_results']),'unseeded/cutoff-universe control remains unknown')
            else:_need(all(x['status']=='CANDIDATE_FOUND' for x in mode_record['complete_results']),'literal positive/fallback proof')
            if name=='outside-boundary':_need(all(x['receipt']['library']['counts']['outside_boundaries']>0 for x in mode_record['complete_results']),'actual outside-boundary refusal in both modes and arms')
        cases.append(record);raw_results.append(results);progress.append(views)
    uses=[x for case in cases for mode_record in (case,case['legacy_mode']) for x in mode_record['observed_use']]
    observed=dict(closed_use=any(x['closed_use'] for x in uses),open_use=any(x['open_use'] for x in uses),selected_hierarchy=any(x['hierarchy'] for x in uses),CD_temporary_contexts=any(x['CD_contexts'] for x in uses))
    limits=[]
    for name,value in observed.items():
        if not value:limits.append(name+': UNEXERCISED because no corresponding selected first-solution trace was observed; offers do not establish use.')
    controls=[dict(id=IDS[0],passed=True,observations=dict(cases=cases,observed_selected_facets=observed),coverage_limits=list(limits))]
    units=[];dup=families['duplicate5'];images=[p,q]
    for name,CD,share in (('direct-distinct',False,False),('CD-distinct',True,False),('CD-shared-premise',True,True)):
        plan,association=_family_plan(dup,images,[p,p],CD,share,c)
        unit,outputs=_unit(m,name,_query(_i(q,p),[p,p]),plan,association,c);units.append(unit)
        ports=association['port_to_proof_plan'];_need((ports[0][1]==ports[1][1]) is share,'explicit actual premise sharing vs ordered duplicate ports')
        if CD:
            ds=unit['complete_compilation']['receipt']['discharges']
            _need([x['discharged_hypothesis_index'] for x in ds]==[3,2],'reverse duplicate assumption occurrences')
    plan=_nested_plan(c);unit,unused=_unit(m,'nested-equal-assumptions',_query(_i(p,_i(p,p)),[p]),plan,dict(used_HYP_index=1,inner_unused_HYP_index=2),c);units.append(unit)
    ds=unit['complete_compilation']['receipt']['discharges'];_need([x['discharged_hypothesis_index'] for x in ds]==[2,1] and ds[0]['mapping'][0]['case']=='LIFT_HYP_OR_AXIOM','occurrence-sensitive unused-inner/used-outer discharge')
    for kind in ('HYP','THEORY_AXIOM'):
        builder=_Plan(c);node=builder.node(0,p,kind,[],dict(index=1) if kind=='HYP' else dict(tag=0,index=0));plan=builder.finish(node)
        query=_query(p,[p,p],[p]);unit,unused=_unit(m,'ordered-source-'+kind,query,plan,dict(source_kind=kind),c);units.append(unit)
        _need(unit['complete_compilation']['receipt']['candidate_rows'][-1]['rule_tag']==(0 if kind=='HYP' else 2),'finite table/HYP source kinds remain distinct')
    controls.append(dict(id=IDS[1],passed=True,observations=dict(complete_original_compiler_units=units,consumer_case_pointers=['/controls/0/observations/cases/2','/controls/0/observations/cases/6'],CD_intro0_offers_equal=True),coverage_limits=['Original compiler units prove these component mappings, not selected use by the new consumer; runtime selected facets are separately reported.']))
    quotient=[]
    for name in ('shared4','duplicated5'):
        f=families[name];plan,association=_family_plan(f,[p,q],[],False,False,c)
        unit,outputs=_unit(m,name,_query(_logical(0,[p,q])),plan,association,c);quotient.append(unit)
        if name=='duplicated5':_need(outputs[0]==outputs[1] and len(plan['nodes'])>len(set(outputs.values())),'genuine complete-key compiler contraction')
        else:_need(plan['nodes'][2]['premises'][0]==plan['nodes'][3]['premises'][0]==0,'true shared internal node')
    controls.append(dict(id=IDS[2],passed=True,observations=dict(complete_original_compiler_units=quotient,symbolic_distinctness_preserved=True),coverage_limits=['These are exact symbolic quotient controls, not distinct point placements or acquired internal sharing.']))
    witness_offers=[]
    for arm,result in zip(ARMS,raw_results[1]):
        for offer in result['receipt']['library']['offers']:
            residual=offer['matcher_receipt']['residual_parameters']
            if residual:witness_offers.append(dict(arm=arm,offer_id=offer['id'],exact_residual=residual,complete_binding=offer['binding']))
    outside=[x['receipt']['library']['counts']['outside_boundaries'] for x in raw_results[9]]
    _need(all(x>0 for x in outside),'actual normal outside-boundary refusal')
    encoding=cases[7]['encoding'];old=m['ordinary'].search_obligations(encoding['query_bytes'],configuration=declarations[7][3],modules={k:m[k] for k in ('checker','builders')},check=c.tick,progress=None)
    _need(old['status']=='CANDIDATE_FOUND','genuine unchanged ordinary fallback');old_validation=_validate(m,encoding['query_bytes'],old,c)
    current_ordinary=_ordinary_modes(m,encoding,declarations[7][3],c)
    binding_limits=[] if witness_offers else ['Witness-only residual offer: UNEXERCISED if ordinary first solution retired all jobs before public matching.']
    controls.append(dict(id=IDS[3],passed=True,observations=dict(all_complete_common_library_records_equal=True,witness_only_residual_offers=witness_offers,outside_boundaries=outside,empty_inventory_original_result=old,empty_inventory_original_validation=old_validation,current_consumer_ordinary_modes=current_ordinary,case_pointers=['/controls/0/observations/cases/'+str(i) for i in (0,1,7,8,9)]),coverage_limits=binding_limits+['Tail membership and cross-arm publication/order checked on observed prefixes; full original W ordering and fairness also require preserved-Source review.']))
    tampers=[];selected_candidate=None
    for pair in raw_results:
        for result in pair:
            if result['status']=='CANDIDATE_FOUND' and selected_candidate is None:selected_candidate=result
    _need(selected_candidate is not None,'genuine candidate for map mutation controls')
    bad=_copy(selected_candidate,c);bad['receipt']['library']['compiler_maps']['final_root_dependencies']=[]
    tampers.append(_expect_bad_map(bad,c,'drop-final-root-closure'))
    bad=_copy(selected_candidate,c);bad['receipt']['elaboration']['plan_outputs']=bad['receipt']['elaboration']['plan_outputs'][:-1]
    tampers.append(_expect_bad_map(bad,c,'drop-plan-output'))
    bad=_copy(selected_candidate,c);bad['receipt']['elaboration']['certificate']['sha256']='0'*64
    tampers.append(_expect_bad_map(bad,c,'compiler-byte-pin-mismatch'))
    bad=_copy(quotient[0],c);bad['plan']['nodes'][2]['premises'].reverse()
    tampers.append(_expect_bad_compiler(bad,c,'swap-ordered-MP-premises'))
    bad=_copy(units[3],c);bad['complete_compilation']['receipt']['discharges'][0]['mapping']=[]
    tampers.append(_expect_bad_compiler(bad,c,'omit-discharge-mapping'))
    bad=_copy(units[3],c);bad['plan']['nodes'][0]['payload']['index']=2
    tampers.append(_expect_bad_compiler(bad,c,'exchange-equal-Formula-assumption-occurrence'))
    selected_use=next((x for pair in raw_results for x in pair if x['status']=='CANDIDATE_FOUND' and x['receipt']['library']['selected_lowering']['applications']),None)
    if selected_use is not None:
        bad=_copy(selected_use,c);bad['receipt']['library']['selected_lowering']['applications'][0]['family_key']={}
        tampers.append(_expect_bad_map(bad,c,'alter-selected-full-key'))
        bad=_copy(selected_use,c);bad['receipt']['library']['selected_lowering']['applications'][0]['internal_nodes']=[]
        tampers.append(_expect_bad_map(bad,c,'drop-selected-local-identity'))
        applications=selected_use['receipt']['library']['selected_lowering']['applications']
        target=next((i for i,a in enumerate(applications) if a['boundaries']),None)
        if target is not None:
            bad=_copy(selected_use,c);a=bad['receipt']['library']['selected_lowering']['applications'][target];a['boundaries'][0]['proof_serial']=a['selected_serial']
            tampers.append(_expect_bad_map(bad,c,'boundary-not-earlier-than-owner'))
    tamper_limits=['No public consumer verifier hook exists; mutated detached evidence is rejected by this independent bank association checker, not by a fabricated project endpoint.']
    if selected_use is None:tamper_limits.append('Selected application tamper facets: UNEXERCISED; no selected library use observed. Compiler/final-root map tampering remains exercised.')
    controls.append(dict(id=IDS[4],passed=True,observations=dict(complete_map_checks_on_every_normal_candidate=True,negative_association_observations=tampers),coverage_limits=tamper_limits))
    first=[];qbytes=cases[0]['encoding']['query_bytes'];f=[families['closed3']];cfg=_configuration()
    try:_search(m,qbytes,f,ARMS[0],{},c)
    except BaseException as error:
        if c.first is not None:raise c.first
        if not m['consumer'].is_owned_error(error):raise
        retained=error
    else:raise ContextualControlError('missing normal configuration refusal')
    for label,error in [('first-check-StopIteration',StopIteration('synthetic')),('first-check-same-class',m['consumer'].ProducerInputError('synthetic')),('first-check-retained-owned',retained)]:
        probe=_Probe(c,error);first.append(_fault(lambda p=probe:_search(m,qbytes,f,ARMS[0],cfg,c,check=p.boom),probe,c,label))
    probe=_Probe(c,StopIteration('public matcher'));proxy=_FaultNamespace(m['instance'].VERSION,'match_receptor',probe)
    first.append(_fault(lambda:_search(m,qbytes,f,ARMS[0],cfg,c,check=probe.check,instance=proxy),probe,c,'public-instance-matcher'))
    probe=_Probe(c,StopIteration('public decode'));proxy=_FaultDelegate(m['checker'],'decode_query',probe)
    first.append(_fault(lambda:_search(m,qbytes,f,ARMS[0],cfg,c,check=probe.check,checker=proxy),probe,c,'public-checker-decode_query'))
    probe=_Probe(c,StopIteration('public logical builder'));proxy=_FaultDelegate(m['builders'],'logical_axiom',probe)
    first.append(_fault(lambda:_search(m,qbytes,f,ARMS[0],cfg,c,check=probe.check,builders=proxy),probe,c,'public-builders-logical_axiom'))
    probe=_Probe(c,StopIteration('public independent validator'));negative_modules=dict(m);negative_modules['reference']=_FaultDelegate(m['reference'],'reference_check_certificate',probe)
    first.append(_fault(lambda:_validate(negative_modules,cases[0]['encoding']['query_bytes'],raw_results[0][0],probe),probe,c,'public-reference-validator'))
    frozen_case=_copy(cases[0],c);original_family=_copy(f,c);view=_copy(progress[0][0],c)
    raw_results[0][0]['receipt']['library']['families'][0]['source_occurrences'][0]['donor_id']='returned-copy-only'
    _need(_same(f,original_family,c) and _same(progress[0][0],view,c),'detached normal result/progress/input lifetime')
    _need(frozen_case['name']=='closed-repeated','complete retained observation independent of mutation')
    controls.append(dict(id=IDS[5],passed=True,observations=dict(selected_faults=first,normal_input_and_progress_unchanged=True,returned_mutation_isolated=True,all_normal_contextual_calls_detached=40,per_call_checks_locator='/controls/0/observations/cases/*/{detached_return_checks,legacy_mode/detached_return_checks}',current_ordinary_lifetime_checks_locator='/controls/3/observations/current_consumer_ordinary_modes'),coverage_limits=['Selected first-check/matcher/decode/logical-builder/independent-validator endpoints only; no all-cutoff/native-allocation/cleanup or guaranteed phase/late ordinal claim.','Current ordinary normal None and legacy routes cover only the existing empty-fallback query; ordinary native/cleanup fault repair remains Source-only and UNEXERCISED.','The ordinary engine is a monotone context-obligation adaptation; point-graph rollback conformance is not claimed.']))
    _need(tuple(x['id'] for x in controls)==IDS,'exact ordered six groups')
    answer=dict(schema=SCHEMA,version=VERSION,population=POPULATION,complete=True,control_ids=list(IDS),controls=controls,counts=dict(groups=6,passed=6,failed=0),scope=SCOPE,coverage_limits=limits+binding_limits+tamper_limits+['No production/library/holdout input; no transfer, indispensability, performance, GCTS or RL claim.','All normal query/candidate/receipt evidence is retained completely; byte leaves are full reversible hex wrappers.'])
    answer=_copy(answer,c,encode_bytes=True);c.tick();return answer
