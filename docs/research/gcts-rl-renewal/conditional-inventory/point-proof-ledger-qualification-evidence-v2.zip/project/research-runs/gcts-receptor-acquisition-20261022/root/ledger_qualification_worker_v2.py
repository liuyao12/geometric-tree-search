"""Inert ledger normal-mode whole-caller Source; no production data intake."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'Root-FPC-ledger-normal-mode-qualification-worker-v2'
EXPERIMENT = 'contextual-ledger-normal-mode-qualification-v2'
CASE = 'ledger-normal-mode-controls-v2-case-0'
PROFILE = 'fpc-ledger-normal-mode-six-group-whole-v2'
PROTOCOL_SCHEMA = 'Root-FPC-contextual-ledger-controls-protocol-v2'
MODULE_ROLES = ('checker','builders','reference','instance','ordinary','consumer','wide_encoder','bank')
BANK_ROLES = ('consumer','ordinary','instance','checker','builders','reference','wide_encoder')
CONTROL_IDS = ('live-boundaries-and-hierarchy','port-context-and-discharge','sharing-and-quotient-map','common-binding-and-fallback','root-used-and-tamper','first-fault-and-isolation')
POSITIVE_FIELDS = ('contextual6_qualification','scientific_result')
MODULE_VERSIONS = {'checker':'FPC-H1-BYTE-CHECKER-v1','builders':'FPC-H1-AST-BUILDERS-v1','reference':'FPC-H1-independent-flat-reference-v2','instance':'FPC-RECEPTOR-INSTANCE-SERVICE-v2','ordinary':'FPC-H1-OBLIGATION-PRODUCER-v2','consumer':'FPC-H1-CONTEXTUAL-LIBRARY-PRODUCER-v2','wide_encoder':'L-wide-FPC-query-encoder-v1','bank':'FPC-CONTEXTUAL-LIBRARY-INDEPENDENT-CONTROLS-v3'}
PUBLIC_ENTRIES = {'checker':('decode_query','decode_certificate','check_certificate'),'builders':('logical_axiom','pa_induction'),'reference':('reference_check_certificate',),'instance':('match_receptor',),'ordinary':('compile_plan','search_obligations'),'consumer':('search_with_library','search_obligations','is_owned_error'),'wide_encoder':('encode_tiny_declared_query',),'bank':('run_bank',)}
CAPS = {'custody_seconds': 210,
 'log_bytes': 4194304,
 'memory_bytes': 1073741824,
 'observer_fallback_seconds': 225,
 'physical_bytes': 134217728,
 'positive_seconds': 180,
 'reserved_outer_bytes': 9437184,
 'result_bytes': 50331648,
 'root_callbacks': 400000000,
 'work_seconds': 160}
CUSTODY_RUNTIME = {'runner': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py',
            'bytes': 12973,
            'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'},
 'observer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py',
              'bytes': 10113,
              'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'},
 'python': {'bytes': 18058560,
            'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
            'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}}
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
PLAN_FIELDS = ('schema',
 'case_id',
 'stage',
 'experiment',
 'actual_dir',
 'worker_path',
 'runner_path',
 'python',
 'files',
 'limits',
 'protocol',
 'profile',
 'module_pins',
 'input_authority',
 'Source_components')

class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""

def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}

def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body

def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)

def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module

def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))

def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True

def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer

def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')

def _natural(value):
    return type(value) is int and value >= 0

def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())

def _same(left, right, check):
    """Checked exact JSON-image association; list/tuple denote one array image."""
    stack = [(left, right)]
    while stack:
        check()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                check()
                stack.append((a[index], b[index]))
        elif ak is dict or bk is dict:
            if not (ak is dict and bk is dict and len(a) == len(b)):
                return False
            for key in a:
                check()
                if type(key) is not str or key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if not _checked_byte_equal(a, b, check):
                return False
        elif a is None or ak is bool or ak is int or ak is float:
            if ak is float and (not math.isfinite(a) or not math.isfinite(b)):
                raise ValueError('finite exact JSON-image equality required')
            if a != b:
                return False
        else:
            raise ValueError('ordinary exact JSON-image equality required')
    return True

def _read_original(row, check):
    expected = pin_fields(row)
    path = Path(expected['path'])
    check()
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete declared original required')
    stream, primary, chunks = None, None, []
    try:
        check()
        stream = path.open('rb')
        offset, digest = 0, hashlib.sha256()
        while offset < expected['bytes']:
            check()
            chunk = stream.read(min(65536, expected['bytes'] - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('entire declared original read required')
            check()
            digest.update(chunk)
            chunks.append(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'' or digest.hexdigest() != expected['sha256']:
            raise ValueError('original full raw length/hash/EOF association required')
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    answer = b''.join(chunks)
    check()
    return answer

def _bank_complete(value, check):
    _validate_json_image(value, check)
    _keys(value, ('schema','version','population','complete','control_ids','controls','counts','scope','coverage_limits'), check)
    if (value['schema'] != 'FPC-contextual-library-independent-controls-v1'
            or value['version'] != MODULE_VERSIONS['bank'] or value['population'] != 'contextual_library6'
            or value['complete'] is not True or not _same(value['control_ids'], list(CONTROL_IDS), check)
            or type(value['controls']) is not list or len(value['controls']) != 6
            or not _same(value['counts'], dict(groups=6,passed=6,failed=0), check)
            or type(value['scope']) is not str or not value['scope']
            or type(value['coverage_limits']) is not list):
        raise ValueError('one complete exact current six-group bank return required')
    for index,row in enumerate(value['controls']):
        check(); _keys(row, ('id','passed','observations','coverage_limits'), check)
        if (row['id'] != CONTROL_IDS[index] or row['passed'] is not True
                or type(row['observations']) is not dict or not row['observations']
                or type(row['coverage_limits']) is not list):
            raise ValueError('complete ordered group with exactdict observations required')


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.implementation.name == 'cpython'
            and sys.version.split()[0] == '3.12.14' and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start) and 0 <= root_start <= time.monotonic()):
        raise ValueError('exact isolated owned child and inherited genuine parent start required')
    began = root_start
    study = Path(__file__).resolve().parents[1]
    directory,plan_path = Path(actual_dir),Path(plan_path)
    plan_pin = raw_pin(plan_path)
    plan_body = plan_path.read_bytes()
    if byte_identity(plan_body) != {k:plan_pin[k] for k in ('bytes','sha256')}:
        raise ValueError('stable entire plan bytes required')
    plan = json.loads(plan_body)
    if type(plan) is not dict or set(plan) != set(PLAN_FIELDS):
        raise ValueError('exact fifteen-field plan required')
    if (plan['schema'] != 'proof-search-case-once-plan-v1' or plan['case_id'] != CASE
            or plan['experiment'] != EXPERIMENT or plan['stage'] != 'qualification' or plan['profile'] != PROFILE
            or directory != study/'actual'/CASE or plan['actual_dir'] != str(directory)
            or not directory.is_absolute() or directory.resolve() != directory or directory.is_symlink()
            or not directory.is_dir() or plan_path.parent != study/'root'/'plans'
            or Path(plan['worker_path']) != Path(__file__).resolve() or plan['input_authority'] != []):
        raise ValueError('one exact controls-only case; no production/holdout input authority')
    if (type(plan['limits']) is not dict or set(plan['limits']) != set(CAPS)
            or any(type(plan['limits'][k]) is not int or plan['limits'][k] != v for k,v in CAPS.items())):
        raise ValueError('all ten original ceilings unchanged')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'],CAPS['physical_bytes']))
    consumed = json.loads((directory/'CONSUMED.json').read_bytes())
    if (consumed['schema'] != 'proof-search-case-consumed-v1' or consumed['plan_sha256'] != plan_pin['sha256']
            or consumed['case_id'] != CASE or type(consumed['uses']) is not int or consumed['uses'] != 1):
        raise ValueError('fresh exact once consumption required')
    state = dict(stage='PIN_INTAKE',callbacks=0,first_fault=None,first_fault_monotonic_ns=None,stages=[],versions={})
    primary = None
    guards,modules,bindings = [],{},[]
    projection = None
    positives = {name:None for name in POSITIVE_FIELDS}
    committed_bytes,provisional,output_rejection = 0,[],None
    source_unchanged = False

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        error = None
        if state['callbacks'] > CAPS['root_callbacks']:
            error = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began >= CAPS['work_seconds']:
            error = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            error = RootBudget('whole Python high-water ceiling')
        if error is not None:
            state['first_fault'] = error
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            raise error

    def policy_check():
        check()
        if sys.get_int_max_str_digits() != POLICY_BINDING[1]:
            raise ValueError('original native integer policy drift')

    def stage(name, operation):
        policy_check(); state['stage'] = name
        row = dict(name=name,began=time.monotonic()-began,status='STARTED')
        state['stages'].append(row)
        value = operation()
        policy_check(); row.update(status='COMPLETED',seconds=time.monotonic()-began-row['began'])
        return value

    def verify_files(cooperative):
        for row in guards:
            if cooperative: check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed declared Source/metadata: '+row['path'])

    def canonical(value):
        _validate_json_image(value,check); policy_check()
        body = (json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))+'\n').encode('ascii')
        policy_check()
        return body

    def decide_size(body, name):
        nonlocal output_rejection
        policy_check()
        prospective = committed_bytes+len(body)
        if prospective > CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection = dict(component=name,exact_attempt_bytes=len(body),committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective,cap_bytes=CAPS['result_bytes'])
            error = RootBudget('bank body plus ENTIRE result exceeds shared48MiB')
            state['first_fault'] = error
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            raise error

    def export(name, body):
        nonlocal committed_bytes
        if type(body) is not bytes:
            raise ValueError('complete immutable artifact bytes required')
        decide_size(body,name)
        progress = dict(basename=name,phase='BEFORE_WRITE',readback_complete=False)
        provisional.append(progress)
        expected = _digest(body,policy_check)
        actual = _write_bank_and_readback(directory/name,body,policy_check,progress)
        if not _same(actual,expected,check):
            raise ValueError('entire original bank readback required')
        committed_bytes += len(body)
        return dict(path=name,bytes=actual['bytes'],sha256=actual['sha256'])

    def stable():
        for role,name,entry in bindings:
            check()
            if (getattr(modules[role],name) is not entry or type(modules[role].VERSION) is not str
                    or modules[role].VERSION != MODULE_VERSIONS[role]):
                raise ValueError('exact public namespace identity changed')
        if projection is not None:
            _keys(projection,BANK_ROLES,check)
            for role in BANK_ROLES:
                check()
                if projection[role] is not modules[role]:
                    raise ValueError('exact public bank projection changed')

    def retire():
        for name in POSITIVE_FIELDS:
            positives[name] = None

    try:
        check(); _keys(plan['module_pins'],MODULE_ROLES,check)
        if type(plan['files']) is not list or not plan['files'] or type(plan['Source_components']) is not list or not plan['Source_components']:
            raise ValueError('explicit Source/metadata closure required')
        guards = [pin_fields(row) for row in plan['files']]
        by_path = {row['path']:row for row in guards}
        if len(by_path) != len(guards):
            raise ValueError('unique guard paths required')
        for row in guards:
            check()
            if '/actual/' in row['path'] or row['path'].endswith('.bin'):
                raise ValueError('no data body in controls-only Source guards')
        required = list(plan['module_pins'].values())+list(CUSTODY_RUNTIME.values())+list(plan['Source_components'])+[plan['protocol']]
        for row in required:
            check(); row = pin_fields(row)
            if by_path.get(row['path']) != row:
                raise ValueError('every used Source/runtime/metadata body explicitly guarded')
        if (pin_fields(plan['python']) != CUSTODY_RUNTIME['python']
                or raw_pin(Path(sys.executable).resolve()) != CUSTODY_RUNTIME['python']
                or plan['runner_path'] != CUSTODY_RUNTIME['runner']['path']
                or by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())):
            raise ValueError('exact pinned runtime/current worker/custody required')
        verify_files(True); policy_check()
        protocol = json.loads(_read_original(pin_fields(plan['protocol']),policy_check))
        _keys(protocol,('schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'),check)
        expected_population = [dict(population='contextual_library6',control_ids=list(CONTROL_IDS),groups=6,bank_role='bank',
            subject_role=['consumer'],scope='Synthetic genuine-byte ledger normal-mode controls only; forty contextual and three ordinary searches in six groups; no learned inventory, target evaluation, GCTS or RL admission.')]
        expected_metadata = dict(profile=PROFILE,input_authority=[],Source_components=plan['Source_components'],reference_integer_policy=list(POLICY_BINDING))
        if (protocol['schema'] != PROTOCOL_SCHEMA or protocol['experiment'] != EXPERIMENT
                or not _same(protocol['limits'],CAPS,check) or not _same(protocol['module_pins'],plan['module_pins'],check)
                or not _same(protocol['control_populations'],expected_population,check)
                or not _same(protocol['job_recipes'],[dict(case_id=CASE,stage='qualification')],check)
                or not _same(protocol['metadata'],expected_metadata,check)):
            raise ValueError('exact prospective controls-only protocol required')
        for role in MODULE_ROLES:
            row = pin_fields(plan['module_pins'][role])
            modules[role] = stage('IMPORT '+role,lambda role=role,row=row:load_exact(row,'_ledger_normal_mode_controls_'+role+'_once_v1',check))
            if type(modules[role].VERSION) is not str or modules[role].VERSION != MODULE_VERSIONS[role]:
                raise ValueError('exact role VERSION required')
            state['versions'][role] = modules[role].VERSION
            for name in PUBLIC_ENTRIES[role]:
                check(); entry = getattr(modules[role],name)
                if not callable(entry):
                    raise ValueError('genuine original public callable required')
                bindings.append((role,name,entry))
        projection = {role:modules[role] for role in BANK_ROLES}
        bank = stage('LEDGER NORMAL MODE CONTEXTUAL6',lambda:modules['bank'].run_bank(projection,check=check))
        stable(); _bank_complete(bank,check)
        bank_ref = stage('EXPORT COMPLETE LEDGER NORMAL MODE CONTEXTUAL6',lambda:export('ledger-normal-mode-bank.json',canonical(bank)))
        positives['contextual6_qualification'] = dict(complete_return_artifact=bank_ref,control_ids=list(CONTROL_IDS),counts=bank['counts'],coverage_limits=bank['coverage_limits'])
        positives['scientific_result'] = dict(schema='FPC-contextual-ledger-normal-mode-control-observation-v1',accepted=False,qualification_admitted=False,
            research_proof_admitted=False,scoped_bank_groups=6,original_return_preserved=True,original_query_certificate_hex_bodies_preserved=True,
            production_inventory_loaded=False,holdout_loaded=False,holdout_searched=False,new_research_targets=0,GCTS_RL_claim=False,
            scope='Finite synthetic normal-mode qualification only. Forty contextual calls and three ordinary calls reuse the original ten paired cases and fallback facet. Complete original observations, both modes and dual validations remain authoritative; no target-transfer or universal correctness claim.',
            prior_qualification_rerun=False,positive_body_bytes_before_result=committed_bytes)
        bank = bank_ref = protocol = None
        stable(); verify_files(True); policy_check()
    except BaseException as error:
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        source_unchanged = False
        try:
            verify_files(primary is None); source_unchanged = bool(guards)
        except BaseException as error:
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None:
            retire()
    bank = bank_ref = protocol = projection = None
    bindings.clear(); modules.clear()

    def receipt():
        value = dict(schema='FPC-contextual-ledger-normal-mode-whole-qualification-receipt-v1',case_id=CASE,stage='qualification',worker_version=VERSION,
            status='LEDGER_NORMAL_MODE_CONTROLS_CANDIDATE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',accepted=False,qualification_admitted=False,
            proof_admitted=False,candidate_complete=primary is None,stages=state['stages'],callbacks=state['callbacks'],elapsed_seconds=time.monotonic()-began,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,source_unchanged=source_unchanged,native_peak_bytes=0,
            native_transport=dict(closed=True,all_reaped=True,native_exit_code=0,native_high_water_bytes=0,subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS'),
            component_versions=state['versions'],error=None if primary is None else dict(type=type(primary).__name__,message=str(primary),traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,first_fault_monotonic_ns=state['first_fault_monotonic_ns'],output_rejection=output_rejection,
            provisional_artifacts=provisional,STOP=None if primary is None else 'STOP_WHOLE_NOT_ADMITTED',
            scope='Exactly six independent synthetic ledger normal-mode groups; all43 declared normal searches and full existing facets are charged in one cold case. No production seven-family intake, target search, GCTS/RL advantage or scientific proof admission.')
        for name in POSITIVE_FIELDS:
            value[name] = positives[name] if primary is None else None
        return value

    try:
        if primary is None:
            body = canonical(receipt()); decide_size(body,'ENTIRE_RESULT_JSON'); policy_check()
        else:
            body = serialize(receipt(),CAPS['result_bytes'])
    except BaseException as error:
        if primary is None:
            primary = state['first_fault'] if state['first_fault'] is not None else error
        retire(); body = serialize(receipt(),CAPS['result_bytes'])
    output = directory/('result.json' if primary is None else 'failure.json')
    if primary is None:
        progress = dict(phase='BEFORE_WRITE',readback_complete=False)
        try:
            _write_bank_and_readback(output,body,policy_check,progress)
            source_unchanged = False; verify_files(True); source_unchanged = bool(guards); policy_check()
        except BaseException as error:
            if progress['phase'] in ('BEFORE_WRITE','WRITING_PARTIAL'):
                primary = state['first_fault'] if state['first_fault'] is not None else error
                retire(); body = serialize(receipt(),CAPS['result_bytes']); output = directory/'failure.json'; write_body(output,body)
            else:
                raise
    else:
        write_body(output,body)
    body = None
    header = dict(schema='proof-search-case-worker-header-v1',case_id=CASE,status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'],seconds=time.monotonic()-began,python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0,source_unchanged=source_unchanged,native_closed_and_reaped=True,first_Root_fault=state['first_fault'] is not None,
        result=raw_pin(output),native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json',serialize(header,CAPS['log_bytes']))
    print(json.dumps(dict(case_id=CASE,status=header['status'],callbacks=state['callbacks'],seconds=time.monotonic()-began)))
    return 0 if primary is None and source_unchanged and time.monotonic()-began < CAPS['positive_seconds'] and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes'] else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: ledger_qualification_worker_v2.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1],sys.argv[2],float(sys.argv[3])))
