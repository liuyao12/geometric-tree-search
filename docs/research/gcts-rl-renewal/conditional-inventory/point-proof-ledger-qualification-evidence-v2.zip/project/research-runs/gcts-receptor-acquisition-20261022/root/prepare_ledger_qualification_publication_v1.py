"""Administrative finite-controls/math report and full raw archive; no scientific calls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
STAGE = ROOT / 'publication-ledger-qualification-v2'
PAYLOAD = P2 / 'publication-payload-ledger-qualification-v2'
PRIOR = ROOT / 'publication-ledger-modes-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-ledger-qualification-summary-v2.json', 'point-proof-ledger-qualification-evidence-v2.zip')
ADMISSION = dict(path=str(ROOT/'ledger-bank3-v2case0-Root-complete-whole-admission-v1.json'), bytes=24883,
    sha256='561754d177d207f7046563ffe762ed2d13f6843db130df66d920f718718e41ee')
MATH = dict(path=str(ROOT/'finite-pair-marking-Root-mathematical-note-adoption-v1.json'), bytes=3153,
    sha256='6f63dc67a209eaeff36f601b3a64d17f0ec082429f243a09f07d4773512bb6a0')
SOURCE_REVIEW = STUDY/'diagnostics-L/prepare-ledger-qualification-publication-v1-independent-Source-review-v1.json'


def raw(path):
    p = Path(path)
    assert p.is_absolute() and p.resolve() == p and p.is_file() and not p.is_symlink()
    assert '.partial' not in p.name and p.name not in ('index.html', '.gcts-active')
    return p.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def main():
    assert pin(ADMISSION['path']) == ADMISSION and pin(MATH['path']) == MATH
    admission = json.loads(raw(ADMISSION['path']))
    mathematics = json.loads(raw(MATH['path']))
    assert admission['status'] == 'FINITE_LEDGER_NORMAL_MODE_CONTROLS_ADMITTED'
    assert admission['case_id'] == 'ledger-normal-mode-controls-v2-case-0'
    assert admission['qualification_admitted'] is True and admission['resources_and_custody_accepted'] is True
    assert admission['new_research_proofs_admitted'] == 0 and admission['GCTS_RL_claim'] is False
    assert admission['holdout_loaded'] is False and admission['production_inventory_loaded'] is False
    review_ref = admission['complete_C_review']
    assert pin(review_ref['path']) == review_ref
    review = json.loads(raw(review_ref['path']))
    assert review['schema'] == 'C-ledger-bank3-v2case0-complete-whole-actual-review-v2'
    assert review['complete_review'] is True and review['blockers'] == []
    assert review['decision']['eligible_for_Root_exact_finite_controls_qualification'] is True
    assert mathematics['mathematical_analysis_accepted'] is True
    assert mathematics['agent_derived_reasoning'] is True and mathematics['machine_checked'] is False
    assert mathematics['experimental_engine_discovery'] is False and mathematics['new_automated_theorem_count'] == 0
    math_review_ref = mathematics['independent_mathematical_review']
    assert pin(math_review_ref['path']) == math_review_ref
    math_review = json.loads(raw(math_review_ref['path']))
    assert math_review['review_passed'] is True and math_review['blockers'] == []
    plan_ref = admission['plan']
    assert pin(plan_ref['path']) == plan_ref
    plan = json.loads(raw(plan_ref['path']))
    assert plan['case_id'] == admission['case_id'] and len(plan['files']) == 65 and plan['input_authority'] == []
    assert review['current_guard_closure']['pins'] == plan['files']
    assert len(admission['raw_case_and_observer_files']) == 11
    assert admission['raw_case_and_observer_files'] == review['all_owned_files']
    source_review = json.loads(raw(SOURCE_REVIEW))
    assert source_review['review_passed'] is True and source_review['blockers'] == []
    assert source_review['Source'] == pin(Path(__file__).resolve())
    auth = ROOT/'full-evidence-archive-direct-user-publication-authorization-v1.json'
    assert json.loads(raw(auth))['direct_human_answer'] == 'Approve publishing the full archive'
    members, external = {}, []

    def include(path, role, expected=None):
        p = Path(path)
        body = raw(p)
        ref = dict(path=str(p), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {k: expected[k] for k in ('path', 'bytes', 'sha256')}
        if not p.is_relative_to(REPO):
            assert ref == plan['python']
            assert not external or external == [dict(**ref, supplied_separately=True)]
            if not external:
                external.append(dict(**ref, supplied_separately=True))
            return
        assert not any(part in ('.git', '.aws', '.ssh') for part in p.parts)
        name = 'project/' + p.relative_to(REPO).as_posix()
        if name in members:
            assert members[name]['ref'] == ref
        else:
            members[name] = dict(role=role, ref=ref, body=body)

    for ref in plan['files']:
        include(ref['path'], 'current-qualified-case-guard', ref)
    for ref in admission['raw_case_and_observer_files']:
        include(ref['path'], 'complete-qualified-case-or-observer', ref)
    include(ADMISSION['path'], 'Root-complete-finite-qualification', ADMISSION)
    include(review_ref['path'], 'C-complete-whole-actual-review', review_ref)
    include(admission['preserved_C_predecessor_review']['path'], 'immutable-C-review-predecessor',
            admission['preserved_C_predecessor_review'])
    for ref in admission['supporting_C_records']:
        include(ref['path'], 'C-complete-supporting-actual-or-prospective-audit', ref)
    for key in ('plan', 'Root_raw_actual_audit', 'Root_once_acceptance', 'grant', 'complete_C_prospective_review'):
        ref = admission[key]
        include(ref['path'], 'explicit-current-qualification-authority-or-audit', ref)
    include(MATH['path'], 'agent-derived-mathematical-note-adoption', MATH)
    for key in ('proof_JSON', 'proof_HTML_fragment', 'independent_mathematical_review', 'abstract_diagram_HTML'):
        ref = mathematics[key]
        include(ref['path'], 'agent-derived-math-proof-review-or-illustration', ref)
    pub_handoff_path = STUDY/'implementation-B/ledger-qualification-publication-and-verifier-Source-handoff-v2.json'
    pub = json.loads(raw(pub_handoff_path))
    assert pub['publisher'] == pin(ROOT/'publish_ledger_qualification_api_v2.py')
    assert pub['verifier'] == pin(ROOT/'verify_ledger_qualification_live_v2.py')
    include(pub_handoff_path, 'administrative-publication-Source-handoff')
    for ref in pub['packet']:
        include(ref['path'], 'administrative-publication-Source-packet', ref)
    extras = [auth, ROOT/'ledger-normal-mode-controls-study-preparation-v2.json',
        ROOT/'ledger-bank3-metadata-preparation-Root-once-authority-v1.json',
        ROOT/'ledger-bank3-prospective-Root-passive-audit-v1.json',
        ROOT/'ledger-qualification-publication-Source-CONTRACT-v2.json',
        ROOT/'publish_ledger_qualification_api_v2.py', ROOT/'verify_ledger_qualification_live_v2.py',
        STUDY/'diagnostics-L/ledger-qualification-publication-and-verifier-independent-Source-review-v2.json',
        Path(__file__).resolve(), SOURCE_REVIEW, PRIOR/NAMES[0],
        PRIOR/'point-proof-ledger-modes-summary-v1.json',
        ROOT/'ledger-modes-live-publication-Root-disposition-v1.json']
    for path in extras:
        include(path, 'explicit-current-review-authority-or-administration')
    prior_archive = PRIOR/'point-proof-ledger-modes-evidence-v1.zip'
    assert pin(prior_archive)['bytes'] == 16599661
    assert pin(prior_archive)['sha256'] == '3f95d32b2a97f663db1a745c750598c6b2ab7493dcdc36526da8637070e2d670'
    include(prior_archive, 'unchanged-opaque-prior-full-archive')
    catalog = dict(schema='Root-ledger-qualification-evidence-catalog-v2',
        issued_utc=datetime.now(timezone.utc).isoformat(), Root_admission=ADMISSION,
        mathematical_note_adoption=MATH, direct_user_archive_authorization=pin(auth),
        members=[dict(member=name, role=value['role'], **value['ref']) for name, value in sorted(members.items())],
        external_runtime=external, prior_archive=pin(prior_archive), scientific_replay=False,
        scope='Current65guard selected closure except separately supplied D90, all11 complete owned qualified files, full current reviews/authority and separately agent-derived mathematics. Prior full archive opaque and unchanged. No recursive historical/private-consumer-packet closure or new research theorem/performance/GCTS/RL claim.')
    assert not STAGE.exists() and not PAYLOAD.exists()
    STAGE.mkdir(); PAYLOAD.mkdir()
    archive = STAGE/NAMES[2]
    catalog_body = js(catalog)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in [('catalog.json', catalog_body)] + [(name, value['body']) for name, value in sorted(members.items())]:
            info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0)); info.external_attr = 0o100644 << 16
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(archive) as bundle:
        assert set(bundle.namelist()) == set(members) | {'catalog.json'} and len(bundle.namelist()) == len(members) + 1
        assert bundle.read('catalog.json') == catalog_body
        for name, value in members.items():
            assert bundle.read(name) == value['body']
    elapsed = admission['observed_lifecycle']['saved_observer_elapsed_seconds']
    peak = admission['qualified_whole_memory_bound']
    counts = admission['observed_counts']
    assert counts['normal_search_returns'] == 43 and counts['complete_same_original_byte_dual_pairs'] == 39
    assert counts['mode_comparisons'] == 21 and counts['positive_mode_comparisons'] == 15
    assert peak == 451756032 and elapsed == 38.52815512500001
    groups = ''.join('<tr><td>'+html.escape(row['id'])+'</td><td>Passed finite declared controls</td></tr>'
                     for row in admission['group_assessments'])
    summary = dict(schema='public-ledger-qualification-and-mathematical-analysis-v2',
        status='FINITE_LEDGER_NORMAL_MODE_CONTROLS_ADMITTED', case_id=admission['case_id'],
        qualification_admitted=True, resources_and_custody_accepted=True,
        new_research_proofs_admitted=0, GCTS_RL_claim=False, proof_family_transfer_admitted=False,
        performance_or_memory_improvement_claim=False, observed_counts=counts,
        selected_facet_findings=admission['selected_facet_findings'],
        group_assessments=admission['group_assessments'], comparison=admission['comparison'],
        observed_lifecycle=admission['observed_lifecycle'], qualified_whole_memory_bound=peak,
        whole_output=admission['whole_output'], Root_admission=ADMISSION, complete_C_review=review_ref,
        mathematical_analysis=dict(agent_derived=True, experimental_engine_discovery=False,
            machine_checked=False, automated_discovery_credit=False, adoption=MATH,
            scope='Finite translated pair exclusions have exact equality-marking representations. Higher-order fixed-state limitation and conditional same-context solution-preservation, not existence/universality/experimental benefit.'),
        archive=dict(name=NAMES[2], **{k: pin(archive)[k] for k in ('bytes', 'sha256')}, entries=len(members)+1),
        scope=admission['scope'], limits=admission['scientific_and_interpretive_limits'],
        history='Old assertion case and three target memory failures remain permanent unchanged negatives; their missing mismatch leaf/value and historical timing comparability are not recovered.')
    section = r'''<style>.qualification-current{border-top:6px solid #176b70}.qualification-current .fact{color:#176b70}.qualification-current .result-table{width:100%;border-collapse:collapse}.qualification-current .result-table td,.qualification-current .result-table th{padding:10px;border-bottom:1px solid #d5dfdf;text-align:left}.qualification-current .table-scroll{overflow-x:auto}.qualification-current code{overflow-wrap:anywhere}.qualification-current .caption{font-size:14px}.marking-analysis-current{border-top:6px solid #a16a23}</style>
<section class="panel qualification-current" id="ledger-qualification-current"><p class="status">Current outcome · finite normal-mode controls · 26 October 2026 UTC</p>
<h1>The finite storage controls pass.</h1>
<p>The corrected independent test completed in a new, separately reviewed once case. Complete external review accepted the six declared groups on the current storage implementation. Both original proof validators remain required, and the full original evidence is retained.</p>
<div class="grid"><article class="card"><h3>Control groups</h3><span class="fact">\(6/6\)</span><p>Finite declared controls accepted with the coverage gaps below.</p></article><article class="card"><h3>Normal searches</h3><span class="fact">\(43\)</span><p>Contextual calls \(40\), original ordinary \(1\), current ordinary \(2\).</p></article><article class="card"><h3>Complete dual checks</h3><span class="fact">\(39\)</span><p>Same original bytes checked by both original validators, including compiler component controls.</p></article><article class="card"><h3>New research proofs</h3><span class="fact">\(0\)</span><p>This qualifies machinery; it supplies no new research theorem or family-transfer result.</p></article><article class="card"><h3>Saved observer time</h3><span class="fact">\('''+f'{elapsed:.2f}'+r'''\,\mathrm{s}\)</span><p>Whole finite workflow observation, not a proof-search speed comparison.</p></article><article class="card"><h3>Conservative whole peak</h3><span class="fact">\('''+f'{peak/1048576:.2f}'+r'''\,\mathrm{MiB}\)</span><p>Includes the recorded parent, child, observer and reserves under the unchanged \(1\,\mathrm{GiB}\) limit.</p></article></div>
<h2>What the comparison now establishes</h2>
<p>All \(21\) complete mode comparisons matched their required scientific projections. In all \(15\) positive comparisons the original checking durations differed. Every actual duration remains saved. Only <code>subject_receipt.cost.elapsed_seconds</code> is normalized in temporary validator-comparison copies; the existing search-receipt callback-count exception remains separate. All other scientific fields, original candidate bytes, reference receipts, cost callback counts and exact cost scopes agree as required.</p>
<p>The complete bank contains \(28\) contextual candidate returns and \(12\) bounded <em>unknown</em> returns. Together with \(3\) ordinary candidate returns and \(8\) compiler component checks, it retains the canonical \(39\) complete validator pairs. Repeated progress or group copies do not count as additional searches or checks.</p>
<div class="table-scroll"><table class="result-table"><thead><tr><th>Group</th><th>Accepted scope</th></tr></thead><tbody>'''+groups+r'''</tbody></table></div>
<h2>The important paths still not selected</h2>
<div class="notice"><strong>Open-lemma use, selected hierarchy and temporary conditional contexts remain unexercised.</strong> The run observed \(8\) selected closed applications with \(32\) local images. Original compiler controls cover discharge and ordered ports, but those component checks do not establish selected open or hierarchical consumer use. No public consumer verifier hook or universal native/cleanup fault coverage is claimed.</div>
<p>The original failed qualification and the three earlier target memory failures stay negative. This complete success does not recover their missing payloads, identify the earlier actual mismatch, establish a storage or speed improvement, or promise that the target search will fit. The current engine remains an ordinary symbolic adaptation; geometric GCTS marking/incidence/generation/rollback and trained RL benefit remain unestablished.</p>
<h2>What comes next</h2><p>The next scientific test is practical use of the same acquired families on the unchanged frozen target in separately reviewed new cases. The marking analysis below gives a precise representation and soundness boundary for the geometric part of the program. Its proof was written by agents through mathematical reasoning and receives no automated-search credit.</p>
<p><a href="point-proof-ledger-qualification-summary-v2.json">Exact result, counts and limitations</a> · <a href="point-proof-ledger-qualification-evidence-v2.zip">Full approved evidence archive</a> · <a href="#pair-marking-offset-title">See the constructed point markings</a> · <a href="point-proof-discovered-proofs-v1.html">Earlier automatically found training proofs</a></p>
<p class="caption">The archive retains all \(11\) current case/observer files, the full \(65\)-guard selected closure except separately identified D90 Python, all complete reviews and the agent-derived mathematical sources. It includes the prior full archive unchanged. Raw proof transport, logs and local provenance paths are included under the user's full-archive approval.</p></section>
<section class="panel marking-analysis-current" id="pair-markings-analysis-current"><p class="status">Mathematical analysis · agent-derived reasoning</p>
<p><strong>Representation result with a clear limit.</strong> Any finite list of forbidden translated pairs has an exact finite equality-marking encoding under the stated assumptions. A genuinely higher-order exclusion cannot always be represented on unchanged fixed tile states. These are elementary mathematical arguments, reviewed by a separate agent and Root; they are not experimental engine discoveries or machine-checked proofs.</p>
'''
    for key in ('abstract_diagram_HTML', 'proof_HTML_fragment'):
        ref = mathematics[key]
        assert pin(ref['path']) == ref
        section += raw(ref['path']).decode()
    section += r'''<p class="caption">For an already-marked input model, extend the argument with a disjoint namespace of new channels. No current learned exclusion list is certified by this mathematical note.</p></section>
<p class="notice"><strong>Historical milestones below.</strong> Their dated “current” labels describe their own checkpoints. The completed v2 finite qualification above supersedes the earlier unqualified-status label; all earlier failed cases remain negative.</p>'''
    baseline = raw(PRIOR/NAMES[0])
    assert len(baseline) == 95607 and hashlib.sha256(baseline).hexdigest() == 'c512aa4be48a20fd6002266aad86b769ef1468dd57ec368e92631b45db46a14d'
    page = baseline.decode(); assert page.count('<body><main>') == 1
    old_title = '<title>Ledger storage qualification: comparison assertion and timing diagnosis</title>'
    new_title = '<title>Finite storage controls pass; exact pair markings and higher-order limits</title>'
    assert page.count(old_title) == 1
    page = page.replace('<body><main>', '<body><main>'+section, 1).replace(old_title, new_title, 1)
    assert page.replace('<body><main>'+section, '<body><main>', 1).replace(new_title, old_title, 1).encode() == baseline
    rows = []
    for name, body in zip(NAMES, (page.encode(), js(summary), raw(archive))):
        if name != NAMES[2]:
            write(STAGE/name, body)
        write(PAYLOAD/name, body)
        rows.append(dict(path=PREFIX+name, root_source=str(STAGE/name), publisher_source=str(PAYLOAD/name),
            bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
            git_blob_sha1=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()))
    staging = dict(schema='Root-ledger-qualification-three-path-staging-v2', scientific_execution=False,
        disposition=ADMISSION, mathematical_note_adoption=MATH, baseline=pin(PRIOR/NAMES[0]),
        direct_user_archive_authorization=pin(auth), files=rows, archive_entries=len(members)+1,
        archive_members_verified=True, external_runtime=external,
        scope='Exact finite qualification plus separately agent-derived mathematics. Existing report/summary/full archive only, soleP2. No new research theorem, practical transfer, performance or GCTS/RL claim.')
    write(STAGE/'P2-staging.json', js(staging))
    print(json.dumps(pin(STAGE/'P2-staging.json')))


if __name__ == '__main__':
    main()
