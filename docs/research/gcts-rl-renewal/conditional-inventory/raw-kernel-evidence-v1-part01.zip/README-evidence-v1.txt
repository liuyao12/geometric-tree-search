Full raw first-order checking-kernel evidence archive.

Download ALL listed ordinary ZIP volumes and extract them into one directory.
The volumes partition the original file paths; no original file is omitted or
split. Each volume contains the full file manifest, including SHA256 hashes.
The public manifest also records each volume's bytes and SHA256. Volumes stay
below repository single-file limits. This is the complete prepublication cut.

Main experiments: attempt-v2/qualify (17 fixtures,13accept4reject),
attempt-v2/research (geometry verified; arithmetic UNKNOWN at1M gate cap),
attempt-v3/research (same arithmetic proof/bounds verified with2M cap).
Original v1 experiments and both arithmetic UNKNOWN outcomes remain intact.
The arithmetic and geometry seven-line proofs were found automatically in the
prior fixed-palette study, then reused here. No new proof search/RL was run.
Qualification fixture proofs are hand-supplied unit tests, not discoveries.

Logical syntax/rules are checked inside NAND, with no external logical-zero
or producer-admission catalogue. The theory/goal AST closure and signature
are problem data pinned before witness encoding. Other syntax/proof/task data
remain free. Every completed witness additionally passed two independent
procedural logical checks and the independent physical ribbon checker.

Scientific Sources are in source/ and reference/. The v1 compiler is the eager
baseline; v2 lazily emits consumed fields, preserving the predicate; v3 changes
only its construction ceiling. The resource-cap peer reviews and1,024-input
tiny equivalence test are in reference/ and review/. Runtime observations,
Source guards, frozen circuits, raw logical data and tile certificates are saved.

To reproduce, copy source/, reference/, upstream/ and the observer scripts to a
fresh directory. Use the recorded Python3.12 runtime (stdlib only). Run
observe_kernel_v2.py qualify, observe_kernel_v2.py research, then
observe_kernel_v3.py research. Observer runtime paths may need adapting on a
different host; no scientific Source edit is required. Outputs use exclusive
writes: do not run over this evidence directory. The larger arithmetic run used
about1.58GB peak native memory and a2M gate cap. Literal large grids are not
expanded; their literal checks remain UNKNOWN, separate from ribbon verification.

The user explicitly approved publishing Source snapshots, raw certificates,
execution logs and local filesystem paths to the existing public GitHub Pages
site. Only task-owned evidence is included. Retired materials work is absent.

Archive cut excludes package/ and publication/: generated archive/index outputs
cannot recursively include themselves; later Git/Pages/TLS/live-UI receipts stay
in the local publication supplement. The broader research goal remains ACTIVE.
