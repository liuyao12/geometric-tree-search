"""Fresh, bounded once custodian for a separately declared proof-search case.

Only the child imports research code. This is not an old qualification runner,
an adversarial sandbox, or an adoption of any old evidence accounting predicate.
"""
from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import threading
import time


def pin(path):
    body = Path(path).read_bytes()
    return {'path': str(Path(path).resolve()), 'bytes': len(body),
            'sha256': hashlib.sha256(body).hexdigest()}


def check_pins(rows):
    for row in rows:
        actual = pin(row['path'])
        if actual != {k: row[k] for k in ('path', 'bytes', 'sha256')}:
            raise ValueError('changed declared file: ' + row['path'])


def serialize_complete(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       allow_nan=False, indent=2) + '\n').encode()
    if len(body) > cap:
        raise ValueError('complete metadata exceeds its declared cap')
    return body


def write_complete(path, value, cap):
    body = serialize_complete(value, cap)
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def run(plan_path, grant_path):
    began = time.monotonic()
    if '.partial' in Path(plan_path).name or '.partial' in Path(grant_path).name:
        raise ValueError('no partial declaration may be parsed')
    plan_bytes = Path(plan_path).read_bytes()
    grant_bytes = Path(grant_path).read_bytes()
    plan, grant = json.loads(plan_bytes), json.loads(grant_bytes)
    if plan['schema'] != 'proof-search-case-once-plan-v1':
        raise ValueError('exact new case plan required')
    if not (grant.get('authorized') is True and type(grant.get('uses')) is int
            and grant['uses'] == 1
            and grant.get('plan_sha256') == hashlib.sha256(plan_bytes).hexdigest()
            and grant.get('runner_sha256') == pin(__file__)['sha256']
            and grant.get('review_passed') is True):
        raise ValueError('fresh exact reviewed Root grant required')
    limits = plan['limits']
    if not (limits['positive_seconds'] == 180 and limits['custody_seconds'] == 210
            and limits['memory_bytes'] == 1073741824
            and limits['physical_bytes'] == 134217728
            and limits['reserved_outer_bytes'] == 9437184
            and limits['log_bytes'] == 4194304
            and limits['root_callbacks'] == 400000000
            and 0 < limits['work_seconds'] <= 160
            and 0 < limits['result_bytes'] <= 50331648):
        raise ValueError('unchanged outer ceilings and explicit inner bounds')
    files = plan['files']
    check_pins(files)
    if pin(sys.executable) != plan['python']:
        raise ValueError('exact isolated Python runtime required')
    directory = Path(plan['actual_dir'])
    directory.mkdir(parents=True, exist_ok=False)
    consumed = directory / 'CONSUMED.json'
    with consumed.open('x') as stream:
        json.dump({'schema': 'proof-search-case-consumed-v1',
                   'plan_sha256': hashlib.sha256(plan_bytes).hexdigest(),
                   'grant_sha256': hashlib.sha256(grant_bytes).hexdigest(),
                   'case_id': plan['case_id'], 'uses': 1}, stream, sort_keys=True)
        stream.write('\n')
    paths = {label: directory / (label + '.bin') for label in ('stdout', 'stderr')}
    log_state = {label: {'bytes': 0, 'stored': 0, 'overflow': False, 'eof': False}
                 for label in paths}
    stop = threading.Event()
    process = None
    threads = []
    errors = []
    exit_seconds = None
    reason = None

    def drain(label, source):
        state = log_state[label]
        try:
            with paths[label].open('xb') as output:
                while True:
                    body = source.read(65536)
                    if not body:
                        state['eof'] = True
                        break
                    state['bytes'] += len(body)
                    room = max(0, limits['log_bytes'] - state['stored'])
                    if len(body) > room:
                        state['overflow'] = True
                        stop.set()
                    kept = body[:room]
                    output.write(kept)
                    state['stored'] += len(kept)
        except BaseException as error:
            errors.append(type(error).__name__ + ': ' + str(error))
            stop.set()

    def kill_group():
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    try:
        command = [sys.executable, '-I', '-S', '-B', plan['worker_path'],
                   str(Path(plan_path).resolve()), str(directory), str(began)]
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
            close_fds=True, cwd=str(directory), env={
                'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'PYTHONHASHSEED': '0'})
        write_complete(directory/'owned-child.json', {
            'schema': 'Root-owned-child-group-v1', 'case_id': plan['case_id'],
            'parent_pid': os.getpid(), 'child_pid': process.pid,
            'child_pgid': process.pid,
            'plan_sha256': hashlib.sha256(plan_bytes).hexdigest()}, 4194304)
        for label in paths:
            thread = threading.Thread(target=drain,
                args=(label, getattr(process, label)), daemon=True)
            threads.append(thread)
            thread.start()
        while process.poll() is None:
            elapsed = time.monotonic() - began
            stored = sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())
            if stop.is_set():
                reason = 'log_or_drain_failure'
            elif stored > limits['physical_bytes'] - limits['reserved_outer_bytes']:
                reason = 'aggregate_physical_output_limit'
            elif elapsed >= limits['positive_seconds']:
                reason = 'positive_completion_deadline'
            if reason is not None:
                kill_group()
                break
            time.sleep(.05)
        process.wait(timeout=max(.01, limits['custody_seconds']-(time.monotonic()-began)))
        exit_seconds = time.monotonic() - began
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
        reason = reason or 'outer_process_or_wait_failure'
        kill_group()
        if process is not None:
            try:
                process.wait(timeout=5)
            except BaseException as second:
                errors.append(type(second).__name__ + ': ' + str(second))
    finally:
        # A persistent Native child inherits this exact child group. Even when
        # Python exits first, kill leftovers before accepting a terminal case.
        kill_group()
        for thread in threads:
            thread.join(timeout=max(.01, limits['custody_seconds']-(time.monotonic()-began)))
        try:
            check_pins(files)
            sources_unchanged = True
        except BaseException as error:
            sources_unchanged = False
            errors.append(type(error).__name__ + ': ' + str(error))
    result_path = directory / 'result.json'
    result_pin = pin(result_path) if result_path.is_file() else None
    header_path = directory / 'worker-header.json'
    header = None
    header_valid = False
    if header_path.is_file() and header_path.stat().st_size <= 4194304:
        try:
            header = json.loads(header_path.read_bytes())
            header_valid = (header['schema'] == 'proof-search-case-worker-header-v1'
                and header['case_id'] == plan['case_id'] and header['status'] == 'COMPLETE'
                and header['result'] == result_pin and header['source_unchanged'] is True
                and header['native_closed_and_reaped'] is True
                and header['first_Root_fault'] is False
                and type(header['callbacks']) is int
                and header['callbacks'] <= limits['root_callbacks']
                and type(header['python_peak_after_output_bytes']) is int
                and type(header['native_peak_bytes']) is int)
        except (ValueError, KeyError, TypeError):
            header_valid = False
    child_peak = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    parent_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    combined_peak_bound = (parent_peak + max(child_peak, header['python_peak_after_output_bytes'])
                           + header['native_peak_bytes']) if header_valid else None
    final_stored = sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())
    receipt = {'schema': 'proof-search-case-terminal-v1', 'case_id': plan['case_id'],
        'process_exit_code': process.returncode if process is not None else None,
        'known_exit_seconds': exit_seconds, 'outer_seconds': time.monotonic()-began,
        'reason': reason, 'errors': errors, 'logs': log_state,
        'sources_unchanged': sources_unchanged, 'result': result_pin,
        'header': header, 'header_valid': header_valid,
        'child_usage': {'ru_maxrss': child_peak},
        'parent_usage': {'ru_maxrss': parent_peak},
        'conservative_combined_peak_bytes': combined_peak_bound,
        'stored_bytes_before_terminal_receipt': final_stored,
        'rss_unit': 'bytes on Darwin only',
        'threads_terminal': all(not thread.is_alive() for thread in threads),
        'qualification': 'PENDING_COMPLETE_RESULT_AND_INDEPENDENT_SCIENTIFIC_REVIEW',
        'old_qualification_reused': False}
    # The small final custodian output has a 4 MiB whole-body cap. Reserve
    # another 9 MiB conservatively for its final materialization, within the
    # unchanged 1 GiB ceiling; do not equate a pre-output RSS sample with EOF.
    receipt['memory_terminal_output_reserve_bytes'] = 9437184
    final_custody_seconds = time.monotonic()-began
    receipt['final_custody_gate_seconds'] = final_custody_seconds
    receipt['final_custody_gate_passed'] = final_custody_seconds <= limits['custody_seconds']
    if not receipt['final_custody_gate_passed']:
        receipt['reason'] = receipt['reason'] or 'late_final_custody_gate'
    # Materialize the complete bounded receipt once before the peak sample,
    # without creating a stored first copy. Only the final version is written.
    warmup_body = serialize_complete(receipt, 4194304)
    del warmup_body
    final_parent_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    combined_peak_bound = (final_parent_peak + max(child_peak, header['python_peak_after_output_bytes'])
                           + header['native_peak_bytes'] + 9437184) if header_valid else None
    receipt['parent_usage']['ru_maxrss'] = final_parent_peak
    receipt['conservative_combined_peak_bytes'] = combined_peak_bound
    receipt['final_custody_gate_seconds'] = time.monotonic()-began
    receipt['final_custody_gate_passed'] = receipt['final_custody_gate_seconds'] <= limits['custody_seconds']
    if not receipt['final_custody_gate_passed']:
        receipt['reason'] = receipt['reason'] or 'late_final_custody_gate'
    write_complete(directory/'terminal.json', receipt, 4194304)
    output = json.dumps(receipt, sort_keys=True)
    final_return_seconds = time.monotonic()-began
    print(output)
    return 0 if (reason is None and not errors and sources_unchanged
                 and process is not None and process.returncode == 0
                 and exit_seconds <= limits['positive_seconds']
                 and receipt['threads_terminal'] and result_pin is not None
                 and header_valid and combined_peak_bound < limits['memory_bytes']
                 and final_stored <= limits['physical_bytes']-limits['reserved_outer_bytes']
                 and receipt['final_custody_gate_passed']
                 and final_return_seconds <= limits['custody_seconds']
                 and all(s['eof'] and not s['overflow'] for s in log_state.values())) else 2


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: run_case_once_v2.py PLAN GRANT')
    raise SystemExit(run(sys.argv[1], sys.argv[2]))
