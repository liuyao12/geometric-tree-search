"""Separate bounded observer for one fresh nonhostile research case.

The child custodian owns its Python/Native process group and ordinary180/210
gates. This process enforces the225-second fallback independently of Root's
tool polling. It is a reproducible experiment custodian, not a security sandbox.
"""
from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import sys
import threading
import time


def complete_json(path, cap):
    if '.partial' in path.name or not path.is_file() or path.stat().st_size > cap:
        raise ValueError('complete bounded JSON file required')
    return json.loads(path.read_bytes())


def write_complete(path, value):
    body=(json.dumps(value,sort_keys=True,allow_nan=False,indent=2)+'\n').encode()
    if len(body)>1048576:
        raise ValueError('observer whole receipt exceeds1MiB; no truncation')
    temp=path.with_name(path.name+'.partial')
    with temp.open('xb') as f:
        f.write(body);f.flush();os.fsync(f.fileno())
    temp.replace(path)


def run(plan_path, grant_path):
    began=time.monotonic()
    if sys.platform!='darwin':
        raise ValueError('declared Darwin RSS units required')
    plan_path=Path(plan_path).resolve();grant_path=Path(grant_path).resolve()
    plan=complete_json(plan_path,4194304)
    grant=complete_json(grant_path,4194304)
    plan_sha=hashlib.sha256(plan_path.read_bytes()).hexdigest()
    if not (plan['schema']=='proof-search-case-once-plan-v1'
            and plan['limits']['observer_fallback_seconds']==225
            and grant['authorized'] is True and grant['review_passed'] is True
            and type(grant['uses']) is int and grant['uses']==1
            and grant['plan_sha256']==plan_sha):
        raise ValueError('exact new once grant/plan and225fallback required')
    directory=Path(plan['actual_dir'])
    observed=Path(str(directory)+'.observer')
    observed.mkdir(parents=True,exist_ok=False)
    # Two1MiB logs plus a1MiB observer receipt fit inside the unchanged9MiB
    # outer allowance together with the custodian's4MiB terminal receipt.
    logs={name:dict(bytes=0,stored=0,overflow=False,eof=False)
          for name in ('stdout','stderr')}
    stop=threading.Event();errors=[];threads=[];process=None
    reason=None;owner=None;fallback_seconds=None;known_exit_seconds=None

    def drain(name,pipe):
        state=logs[name]
        try:
            with (observed/(name+'.bin')).open('xb') as f:
                while True:
                    body=pipe.read(65536)
                    if not body:
                        state['eof']=True;break
                    state['bytes']+=len(body)
                    room=max(0,1048576-state['stored'])
                    if len(body)>room:
                        state['overflow']=True;stop.set()
                    kept=body[:room];f.write(kept);state['stored']+=len(kept)
        except BaseException as e:
            errors.append(type(e).__name__+': '+str(e));stop.set()

    def read_owner():
        candidate=directory/'owned-child.json'
        if not candidate.is_file():
            return None
        value=complete_json(candidate,4194304)
        if not (value['schema']=='Root-owned-child-group-v1'
                and value['case_id']==plan['case_id']
                and value['plan_sha256']==plan_sha
                and value['parent_pid']==process.pid
                and type(value['child_pid']) is int and value['child_pid']>1
                and value['child_pgid']==value['child_pid']
                and value['child_pid'] not in (os.getpid(),process.pid,os.getpgrp())):
            raise ValueError('fresh exact owned child-group receipt required')
        return value

    def terminate_owned():
        nonlocal owner
        if owner is None:
            try:owner=read_owner()
            except BaseException as e:errors.append(type(e).__name__+': '+str(e))
        if owner is not None:
            try:os.killpg(owner['child_pgid'],signal.SIGKILL)
            except ProcessLookupError:pass
        else:
            errors.append('Owned child receipt unavailable: child cleanup is unconfirmed; no admission')
        if process is not None and process.poll() is None:
            process.kill()

    def stored_bytes():
        return sum(p.stat().st_size for folder in (directory,observed) if folder.exists()
                   for p in folder.rglob('*') if p.is_file())

    try:
        process=subprocess.Popen([sys.executable,'-I','-S','-B',plan['runner_path'],
            str(plan_path),str(grant_path)],stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,
            close_fds=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','PYTHONHASHSEED':'0'})
        for name in logs:
            t=threading.Thread(target=drain,args=(name,getattr(process,name)),daemon=True)
            threads.append(t);t.start()
        while process.poll() is None:
            if owner is None:owner=read_owner()
            elapsed=time.monotonic()-began
            if stop.is_set():reason='observer_log_or_drain_failure'
            elif stored_bytes()>plan['limits']['physical_bytes']:
                reason='whole_observer_and_case_physical_limit'
            elif elapsed>=225:
                reason='external225fallback';fallback_seconds=elapsed
            if reason is not None:
                terminate_owned();break
            time.sleep(.05)
        process.wait(timeout=5)
        known_exit_seconds=time.monotonic()-began
    except BaseException as e:
        errors.append(type(e).__name__+': '+str(e));reason=reason or 'observer_failure'
        terminate_owned()
        if process is not None:
            try:process.wait(timeout=5)
            except BaseException as second:errors.append(type(second).__name__+': '+str(second))
    finally:
        for t in threads:t.join(timeout=2)
    if owner is None and process is not None:
        try:owner=read_owner()
        except BaseException as e:errors.append(type(e).__name__+': '+str(e))
    terminal=None
    try:terminal=complete_json(directory/'terminal.json',4194304)
    except BaseException as e:errors.append(type(e).__name__+': '+str(e))
    if process is not None and process.returncode!=0:
        # Also close a known group after an abnormal parent exit. The current
        # nonhostile Source and fresh receipt are the declared ownership trust.
        terminate_owned()
    peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    combined=(terminal.get('conservative_combined_peak_bytes') if terminal else None)
    total_peak=combined+peak+9437184 if type(combined) is int else None
    before_receipt=stored_bytes()
    accepted=bool(reason is None and not errors and process is not None
        and process.returncode==0 and known_exit_seconds is not None
        and known_exit_seconds<=210 and owner is not None
        and all(not t.is_alive() for t in threads)
        and all(x['eof'] and not x['overflow'] for x in logs.values())
        and terminal and terminal['header_valid'] is True
        and type(total_peak) is int and total_peak<plan['limits']['memory_bytes']
        and before_receipt+1048576<=plan['limits']['physical_bytes'])
    receipt=dict(schema='Root-case-external-observer-v1',case_id=plan['case_id'],
        parent_exit_code=process.returncode if process is not None else None,
        known_parent_exit_seconds=known_exit_seconds,elapsed_seconds=time.monotonic()-began,
        reason=reason,errors=errors,logs=logs,owned_child=owner,
        fallback_trigger_seconds=fallback_seconds,observer_peak_before_receipt_bytes=peak,
        conservative_whole_peak_bytes=total_peak,final_output_memory_reserve_bytes=9437184,
        stored_bytes_before_observer_receipt=before_receipt,
        receipt_allowance_bytes=1048576,resource_candidate_before_receipt=accepted,
        resource_candidate_accepted=False,
        scientific_qualification='PENDING_COMPLETE_RESULT_AND_INDEPENDENT_REVIEW',
        watchdog_scope='Separate process with225second fallback trigger and bounded cleanup; '
                       'not an OS real-time guarantee or adversarial sandbox.',
        partial_files_parsed=False)
    write_complete(observed/'observer.json',receipt)
    # Include output allocation in the final independent memory/time gate.
    final_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    final_total=combined+final_peak+9437184 if type(combined) is int else None
    final_gate_seconds=time.monotonic()-began
    final_ok=bool(accepted and final_total<plan['limits']['memory_bytes']
                  and time.monotonic()-began<=210
                  and stored_bytes()<=plan['limits']['physical_bytes'])
    receipt.update(final_observer_peak_bytes=final_peak,
        final_conservative_whole_peak_bytes=final_total,
        final_observer_gate_seconds=final_gate_seconds,
        resource_candidate_accepted=final_ok)
    write_complete(observed/'observer.json',receipt)
    summary=json.dumps(dict(case_id=plan['case_id'],resource_candidate_accepted=final_ok,
        parent_exit_code=receipt['parent_exit_code'],reason=reason,
        seconds=time.monotonic()-began,conservative_whole_peak_bytes=final_total))
    return_gate=bool(final_ok and time.monotonic()-began<=210
                    and stored_bytes()<=plan['limits']['physical_bytes'])
    print(summary)
    return 0 if return_gate else 2


if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('usage: observe_case_once_v1.py PLAN GRANT')
    raise SystemExit(run(sys.argv[1],sys.argv[2]))
