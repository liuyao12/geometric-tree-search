"""Exact metadata preflight and one-use grants; no scientific calls/imports."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
R=B/'root'
def pin(p):
    p=Path(p).resolve();body=p.read_bytes()
    assert '.partial' not in p.name
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def save(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
offer_path=R/'prospective-whole-offer-v2.json'
offer=json.loads(offer_path.read_bytes())
for row in offer['files']+offer['plans']+[offer['protocol']]:assert pin(row['path'])==row
assert len(offer['files'])==39 and len(offer['plans'])==3
assert json.loads((R/'monitor-race-negative-and-retired-grants-v1.json').read_bytes())['all_v1_grants_remaining']==0
# Review filenames are supplied by Root after their complete receipts are read.
import sys
reviews=[pin(B/'review-C/typed-scientific-composition-Source-review-v1.json')]
reviews += [pin(p) for p in sys.argv[1:]]
assert len(reviews)==3
preflight=dict(schema='Root-compact-pilot-preflight-v2',offer=pin(offer_path),protocol=offer['protocol'],
    reviews=reviews,review_passed=True,status='AUTHORIZED_THREE_FRESH_BOUNDED_CASE_ATTEMPTS_NOT_RESULTS',
    old_grants_remaining=0,new_uses=3,all_prior_grants_retired=True,
    source_delta='Single-stat regular-file census skips only vanished paths; no scientific Source, grammar, quota or schedule changes.',
    no_prefix_adoption=True,resource_fit='UNMEASURED; actual whole gates required.',
    goal_status='active',partial_files_parsed=False)
save(R/'Root-preflight-v2.json',preflight)
for row in offer['plans']:
    p=json.loads(Path(row['path']).read_bytes());assert not Path(p['actual_dir']).exists()
    g=dict(schema='Root-fresh-case-grant-v2',authorized=True,uses=1,no_retry=True,
        case_id=p['case_id'],actual_dir=p['actual_dir'],plan_sha256=row['sha256'],
        runner_sha256=pin(p['runner_path'])['sha256'],observer_sha256=pin(p['observer_path'])['sha256'],
        review_passed=True,reviews=reviews,root_preflight=pin(R/'Root-preflight-v2.json'),old_grants_reused=False)
    save(R/('grant-'+p['case_id']+'-v2.json'),g)
print(json.dumps(dict(preflight=pin(R/'Root-preflight-v2.json'),new_grants=3,new_actuals=0)))
