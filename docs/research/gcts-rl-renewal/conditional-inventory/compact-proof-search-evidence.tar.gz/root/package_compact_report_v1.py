"""Package complete saved task-owned bytes only; no scientific imports/replay."""
from pathlib import Path
import hashlib,io,json,shutil,tarfile
B=Path(__file__).resolve().parent.parent
OLD=B.parent/'gcts-proof-search-pilot-20261020'
D=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
def digest(body):return hashlib.sha256(body).hexdigest()
def pin(p):
    body=p.read_bytes();return dict(file=p.name,bytes=len(body),sha256=digest(body))
for source,target in [('review-C/typed-compact-actual-scientific-review-v1.json','compact-proof-search-review-C.json'),('verification-L/typed-compact-resource-custody-review-v1.json','compact-proof-search-review-L.json')]:
    shutil.copyfile(B/source,D/target)
paths={p for p in B.rglob('*') if p.is_file() and p.name not in ('archive-scan-v1.json','Root-final-milestone-v1.json') and 'publication-C' not in p.relative_to(B).parts}
offer=json.loads((B/'root/prospective-whole-offer-v2.json').read_bytes());omitted=[]
for row in offer['files']:
    p=Path(row['path'])
    if p==Path(offer['python']['path']):omitted.append(dict(pin=row,reason='Trusted pinned isolated CPython runtime; binary not redistributed. Research Sources and fixed Native assets included.'))
    else:paths.add(p)
records=[];partials=[];bodies=[]
for p in sorted(paths):
    assert not p.is_symlink()
    if p.is_relative_to(B):name=p.relative_to(B).as_posix()
    elif p.is_relative_to(OLD):name='dependencies/previous-stage/'+p.relative_to(OLD).as_posix()
    else:raise ValueError('undeclared archive path '+str(p))
    raw=p.read_bytes();row=dict(file=name,bytes=len(raw),sha256=digest(raw))
    if '.partial' in p.name:partials.append(row)
    else:records.append(row);bodies.append((name,raw))
manifest=dict(schema='compact-proof-search-complete-evidence-archive-v1',files=records,omitted_trusted_runtime=omitted,partial_raw_metadata_only=partials,scientific_calls=0,new_compact_attempts=4,first_attempt_monitor_failure=True,subsequent_resource_complete_attempts=3,complete_scientific_comparisons=0,recipient_arms_reached=0,recipient_arms_unreached=18,reproduction='Exact frozen files include original and corrected custodian Sources, all negative preimages/reviews and all complete actual records. Consumed/retired grants are historical only. Reproduction requires fresh reviewed paths/plans/grants; never reuse these authorizations.',external_dependency_mapping='dependencies/previous-stage maps the declared D5 Source/input/Native paths preserved in historical plans. Runtime binary is pinned but not redistributed.')
mraw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
archive=D/'compact-proof-search-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
    for name,raw in bodies+[('MANIFEST.json',mraw)]:
        item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0;tf.addfile(item,io.BytesIO(raw))
with tarfile.open(archive,'r:gz') as tf:
    assert len(tf.getmembers())==len(records)+1
    for row in records:
        raw=tf.extractfile(row['file']).read();assert len(raw)==row['bytes'] and digest(raw)==row['sha256']
    assert tf.extractfile('MANIFEST.json').read()==mraw
scan=dict(schema='compact-complete-archive-byte-scan-v1',archive=pin(archive),members=len(records)+1,payload_bytes=sum(r['bytes'] for r in records),all_members_byte_checked=True,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
(B/'root/archive-scan-v1.json').write_text(json.dumps(scan,indent=2,sort_keys=True)+'\n')
owned=[p for p in sorted(D.glob('compact-proof-search*')) if p.name!='compact-proof-search-manifest.json']+[D/'reader.html']
public=dict(schema='compact-proof-search-publication-manifest-v1',source_parent_commit='f39a6c8fa76927a1e7c90699781cd36562831f95',files=[pin(p) for p in owned],archive_scan=scan,conclusion='Three new compact case processes fit the fixed whole resource gates but stop at Native ground-cluster admission unknown. All18recipientarmsunreached, noGCTS/RLadvantage.',reader_change=json.loads((B/'root/reader-publication-delta-v1.json').read_bytes()),counts='42 complete scan-v2 actual+observer files,14 per job;11 separate files preserve the first compact monitor failure. Three new case grants consumed, all v1 grants consumed/retired, zero remaining.')
(D/'compact-proof-search-manifest.json').write_text(json.dumps(public,indent=2,sort_keys=True)+'\n')
print(json.dumps(scan))
