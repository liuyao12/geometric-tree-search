"""Freeze metadata and ASTs only; no scientific module is imported or called."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

B=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-compact-proof-pilot-20261020')
OLD=B.parent/'gcts-proof-search-pilot-20261020'
RUNTIME=B/'runtime'
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
NATIVE=OLD/'implementation-B/recovered/and-support'

def pin(p):
    p=p.resolve();assert '.partial' not in p.name
    body=p.read_bytes()
    return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def save(p,d):
    with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')

api_path=B/'implementation-B/API-v2.json'
api=json.loads(api_path.read_bytes())
lh_path=B/'verification-L/handoff-v1.json'
lh=json.loads(lh_path.read_bytes())
entry=Path(api['entry']['path']);assert pin(entry)==api['entry']==lh['integration_source']
model=Path(api['compact_module']['path']);assert pin(model)==api['compact_module']
reference=Path(lh['source']['path']);assert pin(reference)==lh['source']
for source in (model,reference):
    destination=RUNTIME/source.name
    assert destination.is_file(),'offered runtime Source must already exist'
    assert destination.read_bytes()==source.read_bytes()
corpus=OLD/'corpus-L/pilot-inputs-v2.json'
assert pin(corpus)['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
doc=json.loads(corpus.read_bytes())
assert [s['length'] for s in doc['tests']]==[14,13,14]
old_api=json.loads((OLD/'implementation-B/API-v2.json').read_bytes())
tree=ast.parse(entry.read_bytes(),filename=str(entry))
limit_node=next(n.value for n in tree.body if isinstance(n,ast.Assign)
    and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(limit_node,ast.Call) and isinstance(limit_node.func,ast.Name) and limit_node.func.id=='dict'
scientific_limits={k.arg:ast.literal_eval(k.value) for k in limit_node.keywords}
assert scientific_limits==old_api['limits']
native=dict(template_path=str(NATIVE/'fixed-native-inputs/proof-boundary-001.json'),
    micro_path=str(NATIVE/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),
    executable_path=str(NATIVE/'Native-runtime/boundary-oracle-v2'))
root_sources=[B/'root'/name for name in ['observe_case_once_v2.py','run_case_once_v3.py',
    'case_worker_v1.py','independent_countermodel_v1.py']]
sources=sorted(RUNTIME.glob('*.py'))+[entry]+root_sources
checks=[]
for p in sources:
    parsed=ast.parse(p.read_bytes(),filename=str(p));compile(parsed,str(p),'exec')
    checks.append(dict(path=str(p),AST_and_unused_compile=True))
files=sources+[api_path,lh_path,corpus,PYTHON,NATIVE/'Native-runtime/boundary_oracle.cpp']
files+=[Path(p) for p in native.values()]
rows=[pin(p) for p in sorted(set(files))]
limits=dict(positive_seconds=180,custody_seconds=210,observer_fallback_seconds=225,
    work_seconds=160,memory_bytes=1073741824,physical_bytes=134217728,
    reserved_outer_bytes=9437184,log_bytes=4194304,root_callbacks=400000000,
    result_bytes=50331648)
protocol=dict(schema='compact-proof-pilot-protocol-v1',input=pin(corpus),
    prior_monitor_race='One v1 actual failed in the physical-file census; its consumed grant and both unused v1 grants are retired. No prefix is adopted.',
    live_census='Single stat per path; skip only FileNotFoundError. Other errors reject. Final positive census after owned-worker exit. Non-atomic live census is not a continuous OS peak proof.',
    same_three_donors_and_three_cases=True,case_order=[s['id'] for s in doc['tests']],
    same_six_arms_and_schedules=True,primitive_bounds=[14,13,14],scientific_limits=scientific_limits,
    limits=limits,previous_experiment='All three D5 memory refusals and consumed grants remain unchanged.',
    execution='Three fresh serial cold jobs; all donors, diagnostics, setup and six arms per job. All eighteen outcomes and all whole gates required for complete comparison.',
    acquisition='No supplied proof/library/marking; same conventional donor discovery, Native/Host gates, frozen propositional family mining and bounded grounding.',
    representation='Only exact point/dependency/evidence storage and verified overlay change; full literal values/keys/domains/metadata preserved by independent verifier.',
    search_time='Same cooperative2second local budget, checked between operations; actual Graph/audit work can overshoot. Report actual search and whole-arm time.',
    observer='Separate independent process triggers225second fallback with bounded cleanup; normal admission still requires180positive/210custody, whole memory and stored bytes including observer.',
    costs='Cold training/shared setup physically repeated once per case; all six arms share setup. Report needed acquisition per method without a free learned library.',
    scope='New Native/point pilot. No old G0/G1/full physical Wang/RL acceptance, no guaranteed fit.',
    partial_rule='All.partial raw length/hash only, never parsed/admitted.',new_grants=0,new_actuals=0)
protocol_path=B/'root/protocol-v2.json';save(protocol_path,protocol)
plans=[]
for case in doc['tests']:
    case_id=case['id'];actual=B/'actual'/(case_id+'-scan-v2')
    plan=dict(schema='proof-search-case-once-plan-v1',experiment='compact-proof-pilot-scan-v2',
        case_id=case_id,actual_dir=str(actual),runtime_dir=str(RUNTIME),
        runner_path=str(B/'root/run_case_once_v3.py'),observer_path=str(B/'root/observe_case_once_v2.py'),
        worker_path=str(B/'root/case_worker_v1.py'),entry_path=str(entry),
        control_path=str(B/'root/independent_countermodel_v1.py'),input_path=str(corpus),
        modules=api['roles'],native=native,python=pin(PYTHON),files=rows,
        limits=limits,experiment_limits=scientific_limits,protocol=pin(protocol_path),
        authority='No execution from this plan. Exact reviewed fresh Root once grant required.',
        trusted_runtime='Pinned isolated CPython binary/bundled stdlib and fixed declared research code; nonhostile research runtime, no security-sandbox/wholeOS proof.',
        old_qualifications='No old grant/cohort/failed gate is adopted or rescued.')
    path=B/'root'/('plan-'+case_id+'-v2.json');save(path,plan);plans.append(pin(path))
offer=dict(schema='compact-proof-pilot-whole-offer-v1',plans=plans,files=rows,
    protocol=pin(protocol_path),python=pin(PYTHON),source_AST_checks=checks,
    expected_case_jobs=3,expected_test_arms=18,new_scientific_calls=0,new_actuals=0,new_grants=0,
    old_grants_remaining=0,resource_fit='UNMEASURED. Complete actual admission required; no predicted positive fit.',
    readiness='PENDING_EXACT_WHOLE_OFFER_REVIEWS_AND_ROOT_ONCE_GRANTS')
save(B/'root/prospective-whole-offer-v2.json',offer)
print(json.dumps(dict(plans=plans,files=len(rows),AST_checks=len(checks),actuals=0,grants=0)))
