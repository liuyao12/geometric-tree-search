"""Independent, streaming original-value audit for the primitive pilot only.

No original Model is constructed.  Expected domains/keys/merged assignments are
derived from the frozen constructor specification, independently of segmented
storage.  Callback checks stay outside generators.  Nothing runs on import.
"""
import json

VERSION = 'compact-original-point-reference-verifier-v1'
CATALOG_SCHEMA = 'quantified-initial-binder-syntax-catalog-v1'
COMPILER_VERSION = 'quantified-initial-binder-receptors-v1'
TERM_POLICY = 'TARGET_FREE_SUBTERMS_UNION_ALL_INITIAL_BINDER_VARIABLES_V1'
ROOT_CONTEXT = 'CLOSED_THEORY_AXIOMS_NO_OPEN_ROOT_ASSUMPTIONS'
_OWNER = object()
_MISSING = object()


class ReferenceMismatch(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def _require(ok, message, check):
    check()
    if not ok:
        raise ReferenceMismatch(message, _OWNER)


def _same(a, b):
    stack = [(a, b)]
    while stack:
        left, right = stack.pop()
        if type(left) is not type(right):
            return False
        if type(right) in (list, tuple):
            if len(left) != len(right):
                return False
            stack.extend(zip(left, right))
        elif type(right) is dict:
            if set(left) != set(right):
                return False
            stack.extend((left[k], right[k]) for k in right)
        elif left != right:
            return False
    return True


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf8')


def _key(value):
    return type(value) is tuple and len(value) == 4 and all(type(v) is int for v in value)


def _point(value):
    return type(value) is tuple and len(value) == 2 and all(type(v) is int for v in value)


def _assignment(slot, command_channel, value):
    word = _json(value)
    x = 4 * slot + int(command_channel)
    result = [((x, 100 + offset), value) for offset, value in enumerate(word)]
    result.append(((x, 100 + len(word)), 256))
    return result


def _domain(spec, compiled, slot):
    catalog = compiled['catalog']
    formulas = [spec['target']] if slot + 1 == spec['length'] else catalog['basis']
    rows = []
    for formula in formulas:
        for name in sorted(spec['theory']['axioms']):
            rows.append(dict(rule='axiom', formula=formula, name=name))
        for variable in catalog['variables']:
            for source in range(slot):
                rows.append(dict(rule='generalize', formula=formula,
                                 variable=variable, source=source))
        for antecedent in range(slot):
            for implication in range(slot):
                rows.append(dict(rule='mp', formula=formula,
                                 antecedent=antecedent, implication=implication))
        for rule in ('refl', 'tautology'):
            rows.append(dict(rule=rule, formula=formula))
    for scheme in catalog['schemes']:
        if slot + 1 < spec['length'] or _same(scheme['formula'], spec['target']):
            rows.append(scheme)
    rows.sort(key=lambda command: (command['rule'], _json(command['formula']), _json(command)))
    return rows


def _attempts(spec, compiled, slot, choice, command, tautologies, schemes):
    # One command and its bounded guard variants, never the complete model.
    formula = command['formula']; rule = command['rule']
    result = [((slot, 0, choice, 0), [], 'command')]
    if rule == 'mp':
        for variant, implication in enumerate(compiled['basis']):
            if implication[0] == 'imp' and _same(implication[2], formula):
                requirements = [(command['antecedent'], implication[1]),
                                (command['implication'], implication)]
                result.append(((slot, 1, choice, variant), requirements, 'guard'))
        return result
    requirements = []
    if rule == 'axiom':
        valid = _same(spec['theory']['axioms'][command['name']], formula)
    elif rule == 'refl':
        valid = formula[0] == 'eq' and _same(formula[1], formula[2])
    elif rule == 'tautology':
        valid = _json(formula) in tautologies
    elif rule == 'generalize':
        valid = formula[0] == 'all' and formula[1] == command['variable']
        if valid:
            requirements = [(command['source'], formula[2])]
    else:
        valid = _json(command) in schemes
    if valid:
        result.append(((slot, 1, choice, 0), requirements, 'guard'))
    return result


def _merged(slot, command, requirements):
    entries = _assignment(slot, True, command) + _assignment(slot, False, command['formula'])
    entries.append(((4 * slot + 2, 90), 0))
    for source, formula in requirements:
        entries.extend(_assignment(source, False, formula))
    result = {}
    for point, value in entries:
        if point in result and result[point] != value:
            return None
        result[point] = value
    return tuple(sorted(result.items()))


def _pairs(actual, expected, check):
    check()
    iterator = iter(actual)
    for ordinal, wanted in enumerate(expected):
        if ordinal % 128 == 0:
            check()
        pair = next(iterator, _MISSING)
        if not (pair is not _MISSING and type(pair) is tuple and len(pair) == 2
                and _point(pair[0]) and type(pair[1]) is int and pair == wanted):
            _require(False, 'full original ordered point/value sequence', check)
    _require(next(iterator, _MISSING) is _MISSING, 'no extra point/value support', check)


def _support_intervals(spec, compiled, domains, key):
    slot, role, choice, variant = key
    command = domains[slot][choice]
    requirements = []
    if role == 1 and command['rule'] == 'mp':
        implication = compiled['basis'][variant]
        requirements = [(command['antecedent'], implication[1]),
                        (command['implication'], implication)]
    elif role == 1 and command['rule'] == 'generalize':
        requirements = [(command['source'], command['formula'][2])]
    intervals = {(4 * slot, role, 1),
                 (4 * slot + 1, 100, len(_json(command)) + 1),
                 (4 * slot, 100, len(_json(command['formula'])) + 1),
                 (4 * slot + 2, 90, 1)}
    for source, formula in requirements:
        intervals.add((4 * source, 100, len(_json(formula)) + 1))
    return tuple(sorted(intervals))


def _lookup(dependencies, point, expected, check):
    check()
    actual = dependencies.get(point, _MISSING)
    if not expected:
        _require(actual is _MISSING, 'missing dependency point retains exact default', check)
        return
    _require(actual is not _MISSING and len(actual) == len(expected),
             'dependency lookup exact cardinality', check)
    seen = set()
    for ordinal, key in enumerate(actual):
        if ordinal % 256 == 0:
            check()
        if not (_key(key) and key in expected and key not in seen):
            _require(False, 'dependency lookup no spurious/duplicate edge', check)
        seen.add(key)
    _require(seen == expected, 'dependency lookup every expected edge', check)
    # A fresh traversal must not consume an iterator retained by a previous call.
    _require(set(actual) == expected and set(dependencies.get(point, ())) == expected,
             'repeatable dependency set and lookup', check)


def verify_compact_reference(spec, compiled, inventory, model, *, check):
    check()
    _require(type(spec['length']) is int and spec['length'] > 0,
             'positive exact row count', check)
    catalog = compiled['catalog']
    _require(compiled['status'] == 'complete' and catalog['schema'] == CATALOG_SCHEMA
             and catalog['producer_version'] == COMPILER_VERSION
             and catalog['term_policy'] == TERM_POLICY
             and catalog['root_context'] == ROOT_CONTEXT and type(catalog['rounds']) is int
             and catalog['rounds'] == 2, 'unchanged admitted compiler profile', check)
    _require(_same(compiled['basis'], catalog['basis'])
             and _same(compiled['variables'], catalog['variables']), 'catalog input joins', check)
    empty_inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
    _require(_same(inventory, empty_inventory) and _same(model.spec, spec)
             and _same(model.compiled, compiled) and _same(model.inventory, inventory),
             'caller-authoritative exact input and primitive inventory', check)
    _require(type(model.arity) is int and model.arity == 0 and model.interfaces == []
             and model.mode == {} and model.mode_names == {} and model.families_enabled is False
             and model.required_interface_arity == 0
             and model.arity_policy == 'EXPLICIT_COVERS_ALL_ADMITTED_INTERFACES',
             'unchanged explicit zero-arity family-disabled adapter', check)
    roots = {(4 * slot, role): 0 for slot in range(spec['length']) for role in (0, 1)}
    _require(all(_point(p) for p in model.align_cache) and set(model.align_cache) == set(roots),
             'all original C/G roots and no extras', check)
    _require(type(model.domains) is list and len(model.domains) == spec['length'],
             'all original command domains', check)
    _require(type(model.cache) is dict and type(model.metadata) is dict
             and type(model.conflicts) is list, 'original candidate/metadata carriers', check)
    tautologies = {_json(formula) for formula in compiled['tautologies']}
    schemes = {_json(command) for command in compiled['admitted_schemes']}
    cache_keys = iter(model.cache); metadata_keys = iter(model.metadata)
    conflict_index = 0; accepted = attempted = point_pairs = 0
    for slot in range(spec['length']):
        check(); rows = _domain(spec, compiled, slot)
        _require(_same(model.domains[slot], rows), 'whole original ordered domain', check)
        alignment_position = [0, 0]
        previous_command = None
        for choice, command in enumerate(rows):
            check()
            current_command = _json(command)
            _require(current_command != previous_command, 'unique original commands', check)
            previous_command = current_command
            for key, requirements, kind in _attempts(spec, compiled, slot, choice, command, tautologies, schemes):
                check(); attempted += 1
                merged = _merged(slot, command, requirements)
                if merged is None:
                    wanted = dict(key=key, reason='internally unequal markings')
                    _require(conflict_index < len(model.conflicts)
                             and _same(model.conflicts[conflict_index], wanted),
                             'complete original internal-conflict sequence', check)
                    conflict_index += 1
                    continue
                actual_key = next(cache_keys, _MISSING); metadata_key = next(metadata_keys, _MISSING)
                _require(_key(actual_key) and _key(metadata_key)
                         and actual_key == metadata_key == key,
                         'every original ordered accepted key and no replacement', check)
                tile = model.placement(key)
                _require(tile is model.cache[key] and _key(tile.key) and tile.key == key,
                         'placement lookup is actual cache owner', check)
                _pairs(tile.occupancy, (((4 * slot, key[1]), 12),), check)
                _pairs(tile.marks, merged, check)
                _require(type(tile.vertices) is tuple and tile.vertices == (),
                         'original empty decorative vertices', check)
                wanted = dict(slot=slot, kind=kind, command=command, requirements=requirements)
                _require(_same(model.metadata[key], wanted), 'all original metadata', check)
                p = (4 * slot, key[1]); keys = model.alignments(p); index = alignment_position[key[1]]
                _require(type(keys) is tuple and index < len(keys) and _key(keys[index])
                         and keys[index] == key and keys is model.align_cache[p],
                         'complete ordered alignment incidence', check)
                alignment_position[key[1]] += 1; accepted += 1
                point_pairs += 1 + len(merged)
        for role in (0, 1):
            _require(len(model.alignments((4 * slot, role))) == alignment_position[role],
                     'no spurious root alignment', check)
    _require(next(cache_keys, _MISSING) is _MISSING and next(metadata_keys, _MISSING) is _MISSING
             and conflict_index == len(model.conflicts), 'no extra candidate/metadata/conflict', check)
    state = model.initial()
    _require(_same(state.totals, {}) and _same(state.marks, dict(_assignment(spec['length'] - 1, False, spec['target'])))
             and all(_point(p) and type(v) is int for p, v in state.roots.items())
             and all(_point(p) and type(v) is int for p, v in state.generations.items())
             and all(_point(p) and type(v) is int for p, v in state.marks.items())
             and _same(state.roots, roots) and _same(state.generations, roots)
             and type(state.allowed_points) is frozenset and state.allowed_points == frozenset(roots)
             and all(_point(p) for p in state.allowed_points)
             and type(state.selected) is set and state.selected == set()
             and _same(state.order, []) and _same(state.tile_generations, []),
             'complete original initial boundary/generation/rollback state', check)
    # Compact group references only.  Membership sets are owned by the model.
    terms = model.dependencies.reference_audit_terms(); groups = {}; by_x = {}
    _require(type(terms) is tuple, 'finite immutable outer group audit', check)
    memberships = 0
    for term in terms:
        check()
        _require(type(term) is tuple and len(term) == 4
                 and all(type(v) is int for v in term[:3]) and term[2] > 0
                 and type(term[3]) is frozenset and len(term[3]) > 0,
                 'literal nonempty immutable support interval group', check)
        interval = term[:3]; keys = term[3]
        _require(interval not in groups, 'unique grouped support interval', check)
        groups[interval] = keys; by_x.setdefault(interval[0], []).append(interval)
        for key in keys:
            check()
            _require(_key(key) and key in model.cache
                     and interval in _support_intervals(spec, compiled, model.domains, key),
                     'no spurious grouped dependency membership', check)
            memberships += 1
    expected_memberships = 0
    for key in model.cache:
        check()
        for interval in _support_intervals(spec, compiled, model.domains, key):
            _require(interval in groups and key in groups[interval],
                     'every original grouped dependency membership', check)
            expected_memberships += 1
    _require(expected_memberships == memberships, 'bidirectional dependency population', check)
    index = model.dependencies.reference_audit_lookup_index()
    wanted_index = tuple((x, tuple(sorted(intervals))) for x, intervals in sorted(by_x.items()))
    _require(_same(index, wanted_index), 'complete actual lookup-selector index', check)
    lookup_points = 0
    for x, intervals in wanted_index:
        boundaries = sorted({v for _, start, size in intervals for v in (start, start + size)})
        probes = {boundaries[0] - 1, boundaries[-1]}
        for left, right in zip(boundaries, boundaries[1:]):
            probes.add(left); probes.add(right - 1)
        for y in sorted(probes):
            check(); expected = set()
            for interval in intervals:
                if interval[1] <= y < interval[1] + interval[2]:
                    expected.update(groups[interval])
            _lookup(model.dependencies, (x, y), expected, check); lookup_points += 1
    for x in range(-1, 4 * spec['length'] + 3):
        if x not in by_x:
            _lookup(model.dependencies, (x, 100), set(), check); lookup_points += 1
    check()
    return dict(schema='compact-original-reference-audit-v1', complete=True,
                attempted_placements=attempted, accepted_placements=accepted,
                internal_conflicts=conflict_index, exact_t_and_m_pairs_compared=point_pairs,
                dependency_groups=len(groups), dependency_memberships=memberships,
                lookup_partition_probes=lookup_points,
                lookup_scope='Complete literal group/index join plus interval-class representatives; pinned get Source uses only x and half-open interval membership, so representatives and the Source argument cover every integer point.',
                storage_scope='One independently expanded placement and one expected dependency union at a time; compact outer interval references only. No old Model, byte reverse dictionary, hash equality or scientific proof oracle.')


def verify_marked_extension(base, marked, packet, *, check):
    """Independent storage join; existing certificate checker owns soundness."""
    check(); extra = {}; by_key = {}; initial_marks = {}
    for certificate in packet['certificates']:
        check(); auxiliary = certificate['auxiliary']; key = auxiliary['placement']; point = auxiliary['point']
        _require(_key(key) and key in base.cache and _point(point) and point[0] == -100
                 and point not in extra and base.dependencies.get(point, _MISSING) is _MISSING
                 and point not in base.initial().marks,
                 'exact fresh auxiliary point and original candidate', check)
        _require(type(auxiliary['placement_value']) is int and type(auxiliary['initial_value']) is int,
                 'exact assigned auxiliary values', check)
        extra[point] = {key}; initial_marks[point] = auxiliary['initial_value']
        by_key.setdefault(key, []).insert(0, (point, auxiliary['placement_value']))
    _require(tuple(marked.cache) == tuple(base.cache)
             and marked.dependencies.base is base.dependencies
             and _same(marked.dependencies.extra, extra)
             and _same(marked.initial_auxiliary, initial_marks),
             'same complete base universe and exact auxiliary dependency map', check)
    for name in ('align_cache', 'metadata', 'domains', 'spec', 'compiled', 'inventory'):
        _require(getattr(marked, name) is getattr(base, name), 'preserved base owner: ' + name, check)
    for key in base.cache:
        check(); original = base.placement(key); tile = marked.placement(key)
        if key not in by_key:
            _require(tile is original, 'unchanged overlay placement owner', check)
            continue
        _require(_key(tile.key) and tile.key == key and tile.vertices == original.vertices,
                 'same overlay key and vertices', check)
        _pairs(tile.occupancy, tuple(original.occupancy), check)
        _pairs(tile.marks, tuple(by_key[key]) + tuple(original.marks), check)
    expected = base.initial(); expected.marks.update(initial_marks); actual = marked.initial()
    for name in ('totals', 'marks', 'generations', 'roots', 'selected', 'order', 'tile_generations', 'allowed_points'):
        _require(_same(getattr(actual, name), getattr(expected, name)),
                 'exact overlay initial state: ' + name, check)
    for point, keys in extra.items():
        _lookup(marked.dependencies, point, keys, check)
    check()
    return dict(schema='compact-marked-extension-reference-v1', complete=True,
                changed_placements=len(by_key), auxiliary_points=len(extra),
                scope='Exact point-value/storage extension of the already reference-verified base. Proved redundancy is owned by the separate unchanged marking-certificate verifier; no new proof rule or pruning certificate here.')


class _ModelView:
    def __init__(self, base, **changes):
        self.base = base
        self.__dict__.update(changes)
    def __getattr__(self, name):
        return getattr(self.base, name)
    def placement(self, key):
        return self.cache[key]
    def alignments(self, point):
        return self.align_cache[point]


class _DependencyView:
    def __init__(self, base, terms=None, index=None, point=None, replacement=None):
        self.base = base; self.terms = terms; self.index = index
        self.point = point; self.replacement = replacement
    def reference_audit_terms(self):
        return self.base.reference_audit_terms() if self.terms is None else self.terms
    def reference_audit_lookup_index(self):
        return self.base.reference_audit_lookup_index() if self.index is None else self.index
    def get(self, point, default=()):
        if point == self.point:
            return self.replacement if self.replacement else default
        return self.base.get(point, default)


def _tiny_inputs():
    p = ['pred', 'P', []]; q = ['pred', 'Q', []]; implication = ['imp', p, q]
    spec = dict(id='synthetic-storage-reference-only', title='Synthetic exact storage control',
                theory=dict(functions={}, predicates={'P': 0, 'Q': 0},
                            axioms={'p': p, 'pq': implication}, schemas=[]),
                target=q, length=3, instantiation_rounds=2)
    catalog = dict(schema=CATALOG_SCHEMA, producer_version=COMPILER_VERSION,
                   term_policy=TERM_POLICY, root_context=ROOT_CONTEXT, rounds=2,
                   basis=[implication, p, q], variables=[], schemes=[])
    compiled = dict(status='complete', catalog=catalog, basis=catalog['basis'],
                    variables=[], tautologies=[], admitted_schemes=[])
    inventory = dict(status='native_accepted', definitions=[], interfaces=[], native_blocks=[])
    return spec, compiled, inventory


def run_reference_diagnostics(compact_module, *, check):
    check(); spec, compiled, inventory = _tiny_inputs()
    model = compact_module.Model(spec, compiled, inventory, arity=0, families=False, check=check)
    positive = verify_compact_reference(spec, compiled, inventory, model, check=check)
    results = [dict(id='full-synthetic-reference', status='PASSED')]

    def reject(name, view):
        check(); caught = None
        try:
            verify_compact_reference(spec, compiled, inventory, view, check=check)
        except BaseException as error:
            check()
            if type(error) is not ReferenceMismatch or error.owner is not _OWNER:
                raise
            caught = error
        _require(caught is not None, 'negative control must reject: ' + name, check)
        results.append(dict(id=name, status='PASSED'))

    key = next(iter(model.cache)); tile = model.placement(key); marks = tuple(tile.marks)
    zero_index = next(i for i, pair in enumerate(marks) if pair[1] == 0)
    end_index = next(i for i, pair in enumerate(marks) if pair[1] == 256)
    for name, changed in [('missing-assigned-zero', marks[:zero_index] + marks[zero_index + 1:]),
                          ('terminator-256-to-zero', marks[:end_index] + ((marks[end_index][0], 0),) + marks[end_index + 1:]),
                          ('extra-missing-point-zero', marks + (((999, 999), 0),)),
                          ('bool-int-value-alias', marks[:zero_index] + ((marks[zero_index][0], False),) + marks[zero_index + 1:])]:
        cache = dict(model.cache); cache[key] = type(tile)(tile.key, tile.occupancy, changed, tile.vertices)
        reject(name, _ModelView(model, cache=cache))
    cache = dict(model.cache); cache[key] = type(tile)(tile.key, ((tile.occupancy[0][0], 11),), tile.marks, tile.vertices)
    reject('wrong-unit-occupancy', _ModelView(model, cache=cache))
    cache = dict(model.cache); del cache[key]
    reject('missing-original-key', _ModelView(model, cache=cache))
    metadata = dict(model.metadata); metadata[key] = dict(metadata[key], requirements=[(0, spec['target'])])
    reject('changed-original-metadata', _ModelView(model, metadata=metadata))
    domains = list(model.domains); domains[0] = domains[0][:-1]
    reject('truncated-original-domain', _ModelView(model, domains=domains))
    alignments = dict(model.align_cache); root = tile.occupancy[0][0]; alignments[root] = alignments[root][1:]
    reject('missing-alignment', _ModelView(model, align_cache=alignments))
    terms = model.dependencies.reference_audit_terms(); first = terms[0]
    wrong_keys = frozenset(set(first[3]) | {(999, 0, 0, 0)})
    reject('spurious-dependency-key', _ModelView(model, dependencies=_DependencyView(
        model.dependencies, terms=((first[0], first[1], first[2], wrong_keys),) + terms[1:])))
    reduced = first[3] - {next(iter(first[3]))}
    altered = ((first[0], first[1], first[2], frozenset(reduced)),) + terms[1:] if reduced else terms[1:]
    reject('missing-dependency-edge', _ModelView(model, dependencies=_DependencyView(model.dependencies, terms=altered)))
    reject('duplicate-dependency-group', _ModelView(model, dependencies=_DependencyView(model.dependencies, terms=terms + (first,))))
    reject('missing-lookup-selector', _ModelView(model, dependencies=_DependencyView(model.dependencies, index=())))
    point = (first[0], first[1])
    reject('wrong-lookup-result', _ModelView(model, dependencies=_DependencyView(model.dependencies, point=point, replacement=frozenset())))
    _require(positive['internal_conflicts'] > 0, 'tiny repeated-source overlap actually exercises merge conflict', check)
    results.append(dict(id='overlapping-word-merge-conflict', status='PASSED'))
    packet = dict(certificates=[dict(auxiliary=dict(placement=key, point=(-100, 0),
                                                   placement_value=0, initial_value=1))])
    marked = compact_module.MarkedModel(model, packet, None)
    overlay = verify_marked_extension(model, marked, packet, check=check)
    _require(model.initial().legal(tile) and not marked.initial().legal(marked.placement(key)),
             'fresh mark-only zero/one disagreement changes ordinary legality', check)
    results.append(dict(id='fresh-overlay-storage-and-legality', status='PASSED'))
    bad_dependencies = compact_module.OverlayDependencies(model.dependencies, {})
    caught = None
    try:
        verify_marked_extension(model, _ModelView(marked, dependencies=bad_dependencies), packet, check=check)
    except BaseException as error:
        check()
        if type(error) is not ReferenceMismatch or error.owner is not _OWNER:
            raise
        caught = error
    _require(caught is not None, 'missing auxiliary dependency must reject', check)
    results.append(dict(id='missing-overlay-dependency', status='PASSED'))
    bad_dependencies = compact_module.OverlayDependencies(model.dependencies, {(-100, 0): set(model.cache)})
    caught = None
    try:
        verify_marked_extension(model, _ModelView(marked, dependencies=bad_dependencies), packet, check=check)
    except BaseException as error:
        check()
        if type(error) is not ReferenceMismatch or error.owner is not _OWNER:
            raise
        caught = error
    _require(caught is not None, 'spurious auxiliary dependency must reject', check)
    results.append(dict(id='spurious-overlay-dependency', status='PASSED'))
    for error_type in (RuntimeError, ValueError, StopIteration):
        sentinel = error_type('external reference callback identity')
        def external():
            check()
            raise sentinel
        caught = None
        try:
            verify_compact_reference(spec, compiled, inventory, model, check=external)
        except BaseException as error:
            check(); caught = error
        _require(caught is sentinel, 'foreign callback identity', check)
        results.append(dict(id='foreign-' + error_type.__name__, status='PASSED'))
    check()
    return dict(schema='compact-reference-tiny-diagnostics-v1', complete=True,
                controls=results, positive=positive, overlay=overlay,
                scope='Synthetic structural storage/correspondence controls only; the literal complete status labels are constructor inputs, not Native logical admissions. No proof, acquired lemma, target route, resource acceptance or all-old-diagnostics claim.')
