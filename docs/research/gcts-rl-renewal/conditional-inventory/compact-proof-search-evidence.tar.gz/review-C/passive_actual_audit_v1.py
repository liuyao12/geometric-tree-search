"""Reviewer-owned complete saved-JSON audit. No research imports or replay."""
import collections
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parents[1]
R = D / 'root'
OUT = D / 'review-C' / 'typed-compact-actual-scientific-review-v1.json'
CASES = ('pilot-fork-join-positive', 'pilot-quantifier-equality-positive',
         'pilot-fork-join-missing-Pa')
CONTROL_IDS = '''full-synthetic-reference missing-assigned-zero terminator-256-to-zero extra-missing-point-zero bool-int-value-alias wrong-unit-occupancy bool-int-point-alias missing-original-key changed-original-metadata truncated-original-domain missing-alignment spurious-alignment missing-distant-receptor-value spurious-dependency-key missing-dependency-edge duplicate-dependency-group dependency-upper-bound-off-by-one missing-lookup-selector wrong-lookup-result spurious-lookup-edge consumed-dependency-iterator overlapping-word-merge-conflict fresh-overlay-storage-and-legality missing-overlay-dependency spurious-overlay-dependency foreign-RuntimeError foreign-ValueError foreign-StopIteration'''.split()
checks = []


def check(label, condition):
    checks.append({'id': label, 'passed': bool(condition)})


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def load(path):
    path = Path(path)
    if '.partial' in path.name:
        raise RuntimeError('Partial parsing is prohibited')
    return json.loads(path.read_bytes())


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False).encode()).hexdigest()


def pinned(row):
    return pin(row['path']) == row


external = load(R / 'external-tool-observer-v2.json')
observations = {row['case_id']: row for row in external['cases']}
check('three-known-tool-exits-and-no-remaining-grants',
      external['new_complete_tool_exits'] == 3 and external['new_grants_consumed'] == 3
      and external['remaining_grants'] == 0 and not external['partial_files_parsed'])
input_path = Path(load(R / ('plan-' + CASES[0] + '-v2.json'))['input_path'])
inputs = load(input_path)
raw_files = []
case_rows = []
all_donor_rows = []
all_library_values = []
all_native_counts = collections.Counter()
source_rows = {}

for case_id in CASES:
    actual = D / 'actual' / (case_id + '-scan-v2')
    observer_dir = actual.with_name(actual.name + '.observer')
    plan_path = R / ('plan-' + case_id + '-v2.json')
    grant_path = R / ('grant-' + case_id + '-v2.json')
    plan, grant = load(plan_path), load(grant_path)
    consumed = load(actual / 'CONSUMED.json')
    owned = load(actual / 'owned-child.json')
    header = load(actual / 'worker-header.json')
    terminal = load(actual / 'terminal.json')
    observer = load(observer_dir / 'observer.json')
    result_pin = pin(actual / 'result.json')
    result = load(actual / 'result.json')
    science = result['scientific_result']
    case = science['tests'][0]
    queries = result['native_queries']
    transport = result['native_transport']
    seen = []
    for directory in (actual, observer_dir):
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                seen.append(pin(path))
    raw_files.extend(seen)
    check(case_id + ':14-complete-files-no-partial',
          len(seen) == 14 and not any('.partial' in row['path'] for row in seen))
    check(case_id + ':plan-grant-consumption-exact',
          plan['case_id'] == grant['case_id'] == consumed['case_id'] == case_id
          and plan['actual_dir'] == grant['actual_dir'] == str(actual)
          and consumed['plan_sha256'] == grant['plan_sha256'] == pin(plan_path)['sha256']
          and consumed['grant_sha256'] == pin(grant_path)['sha256']
          and consumed['uses'] == grant['uses'] == 1 and grant['no_retry']
          and grant['authorized'] and not grant['old_grants_reused'])
    for row in plan['files']:
        source_rows[row['path']] = row
    check(case_id + ':all-source-runtime-input-pins-current', all(pinned(row) for row in plan['files']))
    check(case_id + ':grant-reviewed-closure', all(pinned(row) for row in grant['reviews'])
          and pinned(grant['root_preflight'])
          and grant['runner_sha256'] == pin(plan['runner_path'])['sha256']
          and grant['observer_sha256'] == pin(plan['observer_path'])['sha256'])
    check(case_id + ':complete-header-result-terminal-exact',
          header == terminal['header'] and header['result'] == terminal['result'] == result_pin
          and result_pin == observations[case_id]['result']
          and result['case_id'] == header['case_id'] == terminal['case_id'] == case_id
          and result['status'] == header['status'] == 'COMPLETE'
          and result['error'] is None and not result['first_Root_fault']
          and not header['first_Root_fault'] and header['native_closed_and_reaped']
          and result['source_unchanged'] and header['source_unchanged']
          and terminal['sources_unchanged'] and not result['old_qualification_reused']
          and not result['full_physical_Wang_claim'])
    check(case_id + ':known-owned-worker-observer-and-tool-exits',
          terminal['process_exit_code'] == observer['parent_exit_code'] == observations[case_id]['tool_exit'] == 0
          and terminal['errors'] == observer['errors'] == []
          and terminal['reason'] is observer['reason'] is None
          and terminal['threads_terminal'] and observer['owned_child'] == owned
          and owned['plan_sha256'] == consumed['plan_sha256']
          and owned['case_id'] == case_id and owned['child_pid'] == owned['child_pgid']
          and observer == observations[case_id]['independent_observer'])
    limits = plan['limits']
    check(case_id + ':saved-resource-gates',
          terminal['header_valid'] and terminal['final_custody_gate_passed']
          and terminal['known_exit_seconds'] < limits['positive_seconds']
          and terminal['final_custody_gate_seconds'] < limits['custody_seconds']
          and observer['final_observer_gate_seconds'] < limits['observer_fallback_seconds']
          and observer['resource_candidate_accepted'] and observer['fallback_trigger_seconds'] is None
          and observer['final_conservative_whole_peak_bytes'] < limits['memory_bytes']
          and result_pin['bytes'] < limits['result_bytes']
          and result['callbacks'] == header['callbacks'] < limits['root_callbacks']
          and sum(row['bytes'] for row in seen) + limits['reserved_outer_bytes'] < limits['physical_bytes'])
    check(case_id + ':all-four-log-streams-complete-and-bounded',
          all(row['eof'] and not row['overflow'] for row in terminal['logs'].values())
          and all(row['eof'] and not row['overflow'] for row in observer['logs'].values())
          and pin(actual / 'stdout.bin')['bytes'] == terminal['logs']['stdout']['stored']
          and pin(actual / 'stderr.bin')['bytes'] == terminal['logs']['stderr']['stored']
          and pin(observer_dir / 'stdout.bin')['bytes'] == observer['logs']['stdout']['stored']
          and pin(observer_dir / 'stderr.bin')['bytes'] == observer['logs']['stderr']['stored'])
    check(case_id + ':scientific-incomplete-before-every-arm',
          science['inputs'] == inputs and science['limits'] == plan['experiment_limits']
          and science['selected_case_id'] == case_id and science['complete'] is False
          and science['status'] == 'GROUND_CLUSTER_ADMISSION_INCOMPLETE'
          and len(science['tests']) == 1 and case['arms'] == []
          and science['resource_accepted'] is False and science['library_frozen_before_tests'])
    selected_spec = next(row for row in inputs['tests'] if row['id'] == case_id)
    check(case_id + ':exact-selected-theorem-statement', case['spec'] == selected_spec)
    check(case_id + ':native-full-records-transport',
          queries == science['native_records'] and len(queries) == transport['complete_records']
          and transport['closed'] and transport['all_reaped']
          and transport['native_exit_code'] == transport['wait4_status'] == 0
          and transport['cleanup_errors'] == [] and transport['stdout_eof']
          and transport['stderr_complete'] and transport['same_owned_process_group']
          and transport['parent_pid'] == transport['native_pgid'] == owned['child_pid']
          and len(transport['request_stages']) == len(queries)
          and [q['id'] for q in queries] == list(range(len(queries))))
    for q, stage in zip(queries, transport['request_stages']):
        check(case_id + ':native-request-record-' + str(q['id']),
              canonical_hash(q['request']) == q['request_sha256']
              and stage['record_id'] == stage['ordinal'] == q['id']
              and stage['stage'] == 'COMPLETED' and stage['purpose'] == q['purpose']
              and stage['limit'] == plan['experiment_limits']['native_steps']
              and all(stage[k] == q[k] for k in ('request_sha256','input_sha256','output_sha256')))
    check(case_id + ':last-native-raw-bytes-join',
          pin(actual / 'native/input.bin')['sha256'] == queries[-1]['input_sha256']
          and pin(actual / 'native/output.bin')['sha256'] == queries[-1]['output_sha256']
          and pin(actual / 'native/boundary-oracle')['sha256'] == pin(plan['native']['executable_path'])['sha256'])
    native_counts = collections.Counter(q['result']['status'] for q in queries)
    all_native_counts.update(native_counts)
    donors = []
    check(case_id + ':all-three-cold-donors-and-library',
          len(science['training']) == len(science['library']) == 3
          and [entry['spec'] for entry in science['training']] == inputs['training'])
    for entry, family in zip(science['training'], science['library']):
        proof = entry['search']['proof']
        essential = entry['essential_proof']
        whole_q, essential_q = queries[entry['native_query']], queries[entry['essential_native_query']]
        check(case_id + ':accepted-discovered-donor-' + entry['spec']['id'],
              entry['acquired'] and entry['search']['root_restored'] and entry['search']['trace']
              and entry['host_check']['accepted'] and entry['essential_host_check']['accepted']
              and entry['region']['complete'] and entry['region']['decoded_rows'] == len(proof)
              and entry['reference_check']['complete']
              and entry['family'] == family['id'] and family['dependencies'] == []
              and family['provenance']['native_query'] == entry['essential_native_query']
              and family['provenance']['training_id'] == entry['spec']['id']
              and all(command['rule'] != 'block' for command in proof + essential)
              and all(command in entry['domains'][i] for i, command in enumerate(proof))
              and whole_q['result']['status'] == essential_q['result']['status'] == 'accepted'
              and whole_q['request']['proof'] == proof and essential_q['request']['proof'] == essential
              and all(q['request']['target'] == entry['spec']['target']
                      and q['request']['theory'] == entry['spec']['theory']
                      and q['request']['blocks'] == [] for q in (whole_q, essential_q)))
        donor = {'id': entry['spec']['id'], 'proof_rows': len(proof), 'essential_rows': len(essential),
                 'whole_native_query': whole_q['id'], 'essential_native_query': essential_q['id'],
                 'family': family['id'], 'primitive_rules': [c['rule'] for c in essential],
                 'search_seconds': entry['search']['seconds']}
        donors.append(donor)
        all_donor_rows.append(donor)
    all_library_values.append(science['library'])
    model = case['model']
    keys = [tuple(row['key']) for row in model['placements']]
    keyset = set(keys)
    sequences, segments, payloads = model['sequences'], model['segments'], model['payloads']
    check(case_id + ':full-literal-index-tables-structural-joins',
          len(keys) == len(keyset) == case['reference_check']['accepted_placements'] == case['indexed_model_check']['placements']
          and len(model['conflicts']) == case['reference_check']['internal_conflicts']
          and len(keys) + len(model['conflicts']) == case['reference_check']['attempted_placements']
          and len(model['domains']) == selected_spec['length']
          and len(payloads) == case['indexed_model_check']['payloads']
          and len(segments) == case['indexed_model_check']['segments']
          and len(sequences) == case['indexed_model_check']['sequences']
          and all(type(row) is list and len(row) == 3
                  and all(type(i) is int for i in row) and 0 <= row[2] < len(payloads) for row in segments)
          and all(type(seq) is list and all(type(i) is int and 0 <= i < len(segments) for i in seq) for seq in sequences)
          and all(type(p) is str and len(p) % 4 == 0 and set(p) <= set('0123456789abcdef') for p in payloads)
          and all(type(p['marking_sequence']) is int and 0 <= p['marking_sequence'] < len(sequences)
                  and type(p['command_reference']) is list and len(p['command_reference']) == 2
                  and all(type(i) is int for i in p['command_reference'])
                  and 0 <= p['command_reference'][0] < len(model['domains'])
                  and 0 <= p['command_reference'][1] < len(model['domains'][p['command_reference'][0]]) for p in model['placements'])
          and case['reference_check']['complete'] and case['indexed_model_check']['complete'])
    alignment = {tuple(row['point']): row['keys'] for row in model['alignments']}
    check(case_id + ':complete-root-alignment-census',
          len(alignment) == len(model['alignments']) == 2 * selected_spec['length']
          and set(alignment) == {tuple(row[0]) for row in model['initial']['roots']}
          and all(tuple(key) in keyset for values in alignment.values() for key in values))
    marking = case['markings']
    certificates = marking['certificates']
    check(case_id + ':12-complete-certified-auxiliary-extensions',
          len(certificates) == 12 and case['marking_certificate_check']['complete']
          and case['marking_certificate_check']['certificates'] == 12
          and case['marked_extension_check']['complete']
          and case['marked_extension_check']['auxiliary_points'] == 12
          and case['marked_extension_check']['changed_placements'] == 12
          and marking['complete_proposal_prefix'] and marking['stopped'] == 'certificate_limit')
    for i, cert in enumerate(certificates):
        check(case_id + ':certificate-saved-full-domain-and-fresh-point-' + str(i),
              cert['id'] == i and len(cert['trial']) == 1
              and cert['auxiliary'] == {'initial_value': 1, 'placement': cert['trial'][0],
                                        'placement_value': 0, 'point': [-100, i]}
              and tuple(cert['trial'][0]) in keyset
              and [w['key'] for w in cert['all_candidates']] == alignment[tuple(cert['exhausted_root'])]
              and all(w['witness']['kind'] == 'marking'
                      and w['witness']['assigned_owner'] == cert['trial'][0]
                      and type(w['witness']['assigned_value']) is int
                      and type(w['witness']['candidate_value']) is int
                      and w['witness']['assigned_value'] != w['witness']['candidate_value'] for w in cert['all_candidates'])
              and all(segment[0] != -100 for segment in segments)
              and all(point[0][0] != -100 for point in model['initial']['marks']))
    refdiag, tiny = science['compact_reference_diagnostics'], science['diagnostics']
    check(case_id + ':all28-reference-controls-returned',
          refdiag['complete'] and [c['id'] for c in refdiag['controls']] == CONTROL_IDS
          and all(c['status'] == 'PASSED' for c in refdiag['controls'])
          and refdiag['positive']['complete'] and refdiag['overlay']['complete'])
    check(case_id + ':original-tiny-controls-returned',
          tiny['status'] == 'complete' and len(tiny['base_solutions']) == 2
          and tiny['base_solutions'] == tiny['marked_solutions']
          and tiny['callback_identity_propagated'] and tiny['global_dead_forced_generation_controls']
          and tiny['incomplete_certificate_rejected'] and tiny['marked_extension_check']['complete']
          and len(tiny['full_domain_audits']) == 9
          and all(row['complete'] for row in tiny['full_domain_audits']))
    clusters = case['clusters']
    groundq = queries[clusters['admission_query']]
    check(case_id + ':full-ground-library-unknown-not-admitted',
          clusters['status'] == 'unknown_cluster_admission' and clusters['usable'] == []
          and clusters['admission_query'] == len(queries) - 1
          and groundq['purpose'] == 'pilot_ground_cluster_admission'
          and groundq['result']['status'] == 'unknown_step_budget'
          and groundq['result']['micro_steps'] == 1000000000
          and groundq['request']['blocks'] == [item['definition'] for item in clusters['instances']]
          and groundq['request']['theory'] == selected_spec['theory']
          and groundq['request']['target'] == ['imp', ['bot'], ['bot']]
          and all(item['family'] in {f['id'] for f in science['library']}
                  and all(c['rule'] != 'block' for c in item['definition']['proof']) for item in clusters['instances'])
          and sum(q['result']['status'] == 'unknown_step_budget' for q in queries) == 1)
    external_model = result['independent_external_controls']
    check(case_id + ':independent-fixed-negative-control-returned',
          external_model['manual_model'] and external_model['machine_evaluated']
          and not external_model['supplied_to_proof_search']
          and external_model['base'] == {'goal_truth': False, 'premise_truths': [True, True, True]}
          and external_model['S_true']['goal_truth']
          and external_model['removed_premise_restored']['premise_truths'][-1] is False)
    case_rows.append({
        'case_id': case_id, 'result': result_pin, 'plan': pin(plan_path), 'grant': pin(grant_path),
        'successful_actual_file_count_including_observer': len(seen),
        'worker_status': result['status'], 'scientific_complete': science['complete'],
        'scientific_status': science['status'], 'recipient_arms_reached': len(case['arms']),
        'native_query_count': len(queries), 'native_query_status_counts': dict(native_counts),
        'donors': donors, 'reference_check': case['reference_check'],
        'indexed_model_check': case['indexed_model_check'],
        'marking_certificate_check': case['marking_certificate_check'],
        'marked_extension_check': case['marked_extension_check'],
        'marking_proposals': len(marking['proposals']), 'marking_work': marking['work'],
        'certificate_exhausted_roots': sorted({tuple(c['exhausted_root']) for c in certificates}),
        'certificate_full_candidate_witness_count': sum(len(c['all_candidates']) for c in certificates),
        'ground_specialization_count': len(clusters['instances']),
        'ground_family_counts': dict(collections.Counter(c['family'] for c in clusters['instances'])),
        'ground_admission_query': groundq['id'], 'ground_admission_result': groundq['result'],
        'ground_native_query_seconds': groundq['seconds'],
        'ground_binding_work_raw': clusters['binding_work'],
        'reference_controls_passed': len(refdiag['controls']), 'tiny_domain_audits': len(tiny['full_domain_audits']),
        'timings': {'training_and_acquisition_seconds': science['training_and_acquisition_seconds'],
                    'compile_model_and_reference_seconds': case['compile_and_model_seconds'],
                    'indexed_model_and_check_seconds': case['indexed_model_seconds'],
                    'marking_and_certificate_check_seconds': marking['compile_and_verification_seconds'],
                    'ground_specialization_and_admission_seconds': clusters['specialization_and_admission_seconds'],
                    'full_shared_setup_seconds': case['full_shared_setup_seconds'],
                    'scientific_seconds': science['seconds'],
                    'worker_header_seconds': header['seconds'],
                    'known_worker_exit_seconds': terminal['known_exit_seconds'],
                    'parent_final_gate_seconds': terminal['final_custody_gate_seconds'],
                    'observer_final_gate_seconds': observer['final_observer_gate_seconds']},
        'resource_evidence': {'root_callbacks_at_result_boundary': result['callbacks'],
                              'python_peak_after_output_bytes': header['python_peak_after_output_bytes'],
                              'native_peak_bytes': result['native_peak_bytes'],
                              'parent_conservative_peak_bytes': terminal['conservative_combined_peak_bytes'],
                              'observer_final_conservative_whole_peak_bytes': observer['final_conservative_whole_peak_bytes'],
                              'actual_and_observer_complete_stored_bytes': sum(row['bytes'] for row in seen),
                              'complete_stored_plus_same_outer_reserve_bytes': sum(row['bytes'] for row in seen) + limits['reserved_outer_bytes'],
                              'outer_resource_candidate_accepted': observer['resource_candidate_accepted'],
                              'tool_session': observations[case_id]['session'], 'tool_exit': observations[case_id]['tool_exit']}
    })

check('all-three-identical-acquired-family-libraries', all(value == all_library_values[0] for value in all_library_values))
check('42-exact-successful-actual-files', len(raw_files) == 42)
check('nine-donor-occurrences-three-unique-proofs-3-5-5',
      len(all_donor_rows) == 9 and all([r['proof_rows'] for r in case['donors']] == [3,5,5] for case in case_rows))
failed = [row['id'] for row in checks if not row['passed']]
metadata_paths = [R / 'external-tool-observer-v2.json', R / 'passive-actual-assessment-v1.json',
                  R / 'prospective-whole-offer-v2.json', R / 'protocol-v2.json', input_path,
                  D / 'review-C/typed-scientific-composition-Source-review-v1.json',
                  D / 'review-C/typed-scanner-successor-preflight-review-v1.json',
                  D / 'review-C/monitor-race-negative-review-v1.json',
                  R / 'monitor-race-negative-and-retired-grants-v1.json']
review = {
    'schema': 'typed-compact-actual-scientific-review-v1',
    'reviewer_identity': '/root/recovered_batch_review', 'review_passed': not failed,
    'review_scope': 'Passive complete saved-result, provenance, population and scientific-interpretation review; no semantic replay.',
    'scientific_component_calls': 0, 'scientific_imports': 0, 'partial_files_parsed': False,
    'actual_execution_authorized': False, 'new_grants_issued': 0,
    'successful_actual_raw_file_count': len(raw_files), 'successful_actual_raw_files': raw_files,
    'metadata_pins': [pin(path) for path in metadata_paths],
    'current_source_runtime_and_input_pins': list(source_rows.values()),
    'case_results': case_rows,
    'aggregate_census': {'case_jobs_with_complete_records': 3, 'donor_occurrences': 9,
                         'distinct_elementary_donor_proofs': 3, 'whole_and_essential_native_accepted_donor_requests': 18,
                         'native_queries': sum(all_native_counts.values()), 'native_status_counts': dict(all_native_counts),
                         'target_certificates': 36, 'proposed_ground_instances': sum(c['ground_specialization_count'] for c in case_rows),
                         'accepted_ground_libraries': 0, 'recipient_search_arms_reached': 0,
                         'recipient_search_arms_preregistered': 18, 'reference_control_occurrences': 84},
    'findings': [
        'All three fresh scan-v2 processes returned complete records and have saved resource-candidate gates plus Root-reported final tool exit0/EOF. The scientific comparison remains incomplete: each stopped at the preregistered ground-cluster admission gate before every recipient arm.',
        'Each cold job actually searched the same three elementary nullary propositional donors, with 3/5/5 primitive rows. Complete searched proofs, essential proofs, traces, exact theory/target requests, Host receipts and eighteen accepted Native whole/essential requests are retained. Nine occurrences are three distinct elementary proofs, not nine new theorems or proofs of the larger recipients.',
        'The full target segmented models, original-reference checks, indexed-wire/actual-owner joins and marked-overlay checks returned. These are finite runtime observations for the exact corpus and pinned Sources, not a mechanized all-input equivalence proof.',
        'Each target has twelve certified unary dead-extension exclusions with the full original exhausted-root candidate list and differing-value witnesses. In these runs all exhausted roots are the first-row guard. The actual recipient GCTS graph/search did not run, so graph removals, forced propagation, search speed or proof discovery from these markings were not measured.',
        'The 7/11/7 ground proposals are primitive expansions instantiated from the actually acquired families, but each batch Native validation returned unknown_step_budget at exactly one billion microsteps. Unknown is neither rejection nor acceptance. No usable ground library, recipient-context receptor applicability, expansion use or cluster speed benefit is established.',
        'All twenty-eight independent compact-reference controls and the original Tiny mechanism controls returned in each job. The Tiny result preserves both solutions and reports complete-domain/rollback/scheduler and auxiliary-marking controls; this does not substitute for the absent recipient comparison.',
        'The manually supplied singleton countermodel was evaluated independently and was not passed to proof search. It concerns the missing-premise control only; no recipient UNSAT proof or automated model-discovery claim follows.',
        'compile_and_model_seconds includes Native compilation/admission work, compact Model construction and the full independent reference check. It must not be presented as Model construction time alone. Local two-second search quotas are cooperative; no recipient search-time outcome exists.',
        'Saved binding_work is 20003 against a 20000 proposal-work threshold. The reviewed Source increments stop-check counters while unwinding recursive proposal loops; every unification call is guarded before work exceeds the threshold. Preserve the raw counter and this cooperative-count scope; no hidden cap increase or claim that the raw counter is at most20000.',
        'The earlier no-scan-v2 monitor race and all D5 memory failures remain separate immutable negative results. This fresh successful process/setup evidence does not rescue an older grant, full VM cohort, G0 gate or G1 qualification; G1 remains unadopted.',
        'Resource success applies to the actually completed setup/control work and complete returned artifacts, not to the absent six-arm workload. Repeated cold runs support a representation-feasibility observation for these target models; they provide no paired runtime or memory speedup estimate.',
        'No reinforcement learning, physical Wang interpreter acceptance, general theorem-search advantage, complete comparison or proof of either larger positive target was demonstrated by this actual.'
    ],
    'passive_audit_limits': [
        'Research verification/decoding functions were never called by this reviewer. Literal saved table indices, request hashes, exact corpus/proof/request joins, output hashes and complete populations were checked; value correspondence and certificate validity rely on the returned independently authored runtime verifier receipts and previously reviewed Source argument.',
        'Only the last Native input/output binary files remain physically in each directory; every request and its binary hashes and complete Native response are retained in the JSON record. Earlier request binaries were not recreated.',
        'Root tool session exits are recorded by the complete external-tool-observer metadata and parent message. No session was relaunched or scientifically replayed.',
        'Live filesystem scans are sampled and non-atomic; the narrow disappeared-file fix and a final closed-process census support this nonhostile finite resource review, not an OS/adversarial resource theorem.'
    ],
    'checks': checks, 'failed_checks': failed,
    'tools_stopped_after_freeze': True,
    'overall_comparison_complete': False, 'search_advantage_demonstrated': False,
    'old_negative_results_changed': False
}
OUT.write_text(json.dumps(review, indent=2, sort_keys=True, ensure_ascii=False) + '\n')
print(json.dumps({'review': pin(OUT), 'checks': len(checks), 'failed': failed,
                  'cases': [{'id': c['case_id'], 'witnesses': c['certificate_full_candidate_witness_count'],
                             'files': c['successful_actual_file_count_including_observer'],
                             'resource': c['resource_evidence']} for c in case_rows],
                  'census': review['aggregate_census']}, indent=2))
