"""Source-only point-row adapter, not a proof-search engine or admission gate.

Inputs must be immutable for the call and complete, wellformed parsed outputs
of the exact pinned FPC query/certificate parser. This module does not parse
bytes or establish that precondition. The caller supplies the exact reviewed
builders module under whole-job custody; VERSION is not raw provenance.

A rule family computes its conclusion intrinsically. MP and GEN premise
agreement is left to exact formula-valued marks, including remote ports.
The point checker assumes inventory membership from the constructor below;
its private generic kernel is not an arbitrary-tile proof verifier.
"""
VERSION = "FPC-H1-POINT-ROWS-v1"


class PointFamilyRefusal(ValueError):
    """Completed inventory-membership refusal; never a resource wrapper."""


class _Call:
    def __init__(self, check):
        self.check = check
        self.fault = None
        self.callbacks = 0

    def tick(self):
        if self.fault is not None:
            raise self.fault
        self.callbacks += 1
        try:
            self.check()
        except BaseException as error:
            self.fault = error
            raise

    def need(self, condition, reason):
        self.tick()
        if not condition:
            raise PointFamilyRefusal(reason)

    def helper(self, function, *args):
        self.tick()
        try:
            result = function(*args, check=self.tick)
        except BaseException:
            if self.fault is not None:
                raise self.fault
            raise
        self.tick()
        return result


def _freeze(value, call):
    """Finite acyclic parsed-tree precondition; exact scalar types, no bool."""
    pending, output = [(False, value)], []
    while pending:
        call.tick()
        rebuild, item = pending.pop()
        if rebuild:
            count = item
            children = tuple(output[-count:]) if count else ()
            if count:
                del output[-count:]
            output.append(children)
        elif type(item) in (tuple, list):
            pending.append((True, len(item)))
            for child in reversed(item):
                call.tick()
                pending.append((False, child))
        else:
            call.need(type(item) in (str, int) or item is None, "parsed scalar carrier")
            output.append(item)
    call.need(len(output) == 1, "one frozen parsed value")
    return output[0]


def _same(left, right, call):
    pending = [(left, right)]
    while pending:
        call.tick()
        a, b = pending.pop()
        if type(a) is not type(b):
            return False
        if type(a) is tuple:
            if len(a) != len(b):
                return False
            for position in range(len(a)):
                call.tick()
                pending.append((a[position], b[position]))
        elif a != b:
            return False
    return True


def _natural(value, call):
    call.need(type(value) is int and value >= 0, "strict natural index")
    return value


def _member(row, index, rows, query, builders, gamma_fv, call):
    """Construct a member of one primitive rule family, in local coordinates.

    Wellformed formula/term syntax is a parser/catalog precondition. No earlier
    row's logical validity is assumed. Only MP chooses a free family parameter
    from an earlier declared formula; its other required formula is a mark.
    """
    call.need(type(row) is dict and row.get("index") == index
              and type(row.get("index")) is int, "exact ordered row index")
    tag = _natural(row["rule_tag"], call)
    call.need(tag <= 4, "primitive rule family")
    witness = row["witness"]
    call.need(type(witness) in (tuple, list), "ordered witness vector")
    formula = _freeze(row["formula"], call)
    subtag = row.get("subtag")
    expected, incoming, refs = None, [], []
    if tag == 0:
        call.need(subtag is None and len(witness) == 1, "HYP payload")
        number = _natural(witness[0], call)
        call.need(number < len(query["Gamma"]), "HYP index")
        expected = _freeze(query["Gamma"][number], call)
    elif tag == 1:
        call.need(type(subtag) is int and 0 <= subtag < 8, "logical family tag")
        expected = _freeze(call.helper(builders.logical_axiom, subtag, list(witness)), call)
    elif tag == 2:
        call.need(type(subtag) is int and 0 <= subtag <= 3, "theory family tag")
        profile = query["theory_profile"]
        call.need(type(profile) is int and profile == (0, 1, 1, 2)[subtag], "fixed theory profile")
        if subtag == 2:
            call.need(len(witness) == 3, "induction payload")
            expected = _freeze(call.helper(builders.pa_induction,
                witness[0], witness[1], list(witness[2])), call)
        else:
            call.need(len(witness) == 1, "theory-table payload")
            number = _natural(witness[0], call)
            table = (query["finite_axioms"] if subtag == 0 else
                     (builders.PA_AXIOMS if subtag == 1 else builders.INCIDENCE_AXIOMS))
            call.need(number < len(table), "theory-table index")
            expected = _freeze(table[number], call)
    elif tag == 3:
        call.need(subtag is None and len(witness) == 2, "MP payload")
        refs = [_natural(witness[0], call), _natural(witness[1], call)]
        for reference in refs:
            call.need(reference < index, "strictly earlier MP reference")
        antecedent = _freeze(rows[refs[0]]["formula"], call)
        # No comparison with the implication row here: mark agreement does it.
        expected = formula
        incoming = [antecedent, ("imp", antecedent, formula)]
    else:
        call.need(subtag is None and len(witness) == 2, "GEN payload")
        refs = [_natural(witness[0], call)]
        variable = _natural(witness[1], call)
        call.need(refs[0] < index, "strictly earlier GEN reference")
        call.need(variable not in gamma_fv, "GEN full-Gamma freshness")
        call.need(type(formula) is tuple and len(formula) == 3
                  and formula[0] == "all" and formula[1] == variable,
                  "GEN family conclusion constructor")
        expected = formula
        incoming = [formula[2]]
    # This is inventory membership, not an extra geometric legality predicate.
    call.need(_same(formula, expected, call), "declared row equals intrinsic family conclusion")
    marks = {(0, 1): expected}
    for reference, premise in zip(refs, incoming):
        call.tick()
        point = (reference - index, 1)
        if point in marks:
            call.need(_same(marks[point], premise, call), "internally consistent marking function")
        else:
            marks[point] = premise
    return dict(family=tag, subtag=subtag, witness=_freeze(witness, call),
        conclusion=expected, references=tuple(refs),
        t=(((0, 0), 1),), m=tuple(sorted(marks.items())),
        translation=(index, 0))


def _point_check(tiles, count, goal, call):
    """Only exact point totals and assigned-value agreement after membership.

    Exterior row cells have fixed occupancy one and exterior formula ports
    have a distinct fixed sentinel. Those are exact symbolic boundary fields;
    no geometric intersection, proof inference or drawing predicate is used.
    """
    totals, values, reasons = {}, {(count - 1, 1): goal}, []
    for number, tile in enumerate(tiles):
        call.tick()
        dx, dy = tile["translation"]
        for (x, y), value in tile["t"]:
            call.tick()
            point = (x + dx, y + dy)
            outside = point[1] != 0 or not 0 <= point[0] < count
            previous = totals.get(point, 1 if outside else 0)
            totals[point] = previous + value
            if totals[point] > 1:
                reasons.append(dict(kind="T_OVER_CAPACITY", point=point, tile=number))
        for (x, y), value in tile["m"]:
            call.tick()
            point = (x + dx, y + dy)
            outside = point[1] != 1 or not 0 <= point[0] < count
            if outside and point not in values:
                values[point] = ("OUTSIDE_FORMULA_DOMAIN",)
            if point in values and not _same(values[point], value, call):
                reasons.append(dict(kind="M_VALUE_DISAGREEMENT", point=point,
                    tile=number, assigned=values[point], proposed=value))
            else:
                values[point] = value
    for row in range(count):
        call.tick()
        if totals.get((row, 0), 0) != 1:
            reasons.append(dict(kind="T_REQUIRED_NOT_ONE", point=(row, 0)))
    call.tick()
    return dict(point_compatible=not reasons, mismatches=reasons,
        t_totals=tuple(sorted(totals.items())), m_values=tuple(sorted(values.items())))


def check_rows_as_points(query, certificate, *, builders, check):
    """Construct verified inventory members, then check exact point agreement.

    Returns a provisional point-model observation, never FPC proof admission.
    Raises membership/helper errors on completed invalid families, and preserves
    first callback fault identity. All helpers and output work must remain in a
    separately reviewed bounded once job. No module was called in authoring.
    """
    call = _Call(check)
    call.tick()
    call.need(type(query) is dict and type(certificate) is dict, "parsed carriers")
    rows = certificate["rows"]
    call.need(type(rows) in (tuple, list) and len(rows) > 0, "nonempty full row vector")
    call.need(type(certificate["row_count"]) is int
              and certificate["row_count"] == len(rows), "exact full row count")
    gamma_fv = set()
    for formula in query["Gamma"]:
        call.tick()
        gamma_fv.update(call.helper(builders.formula_free_variables, formula))
    tiles = []
    for index, row in enumerate(rows):
        call.tick()
        tiles.append(_member(row, index, rows, query, builders, gamma_fv, call))
    goal = _freeze(query["goal"], call)
    result = _point_check(tiles, len(rows), goal, call)
    result.update(schema="FPC-H1-point-row-observation-v1", complete=True,
        row_count=len(rows), tiles=tiles,
        point_domain="integer row coordinate times cell/port channel; translations only",
        target=tuple((k, 0) for k in range(len(rows))),
        boundary=dict(final_goal_port=(len(rows) - 1, 1), final_goal_value=goal,
            exterior_t=1, exterior_m=("OUTSIDE_FORMULA_DOMAIN",)),
        inventory_scope="Fixed five primitive rule families with typed parameters; not one fixed finite Wang palette",
        search_engine=False, GCTS_conformance=False, proof_admitted=False,
        scope="Parser wellformedness and pinned inventory construction are preconditions. "
              "This provisional point observation is not a replacement for current same-byte dual validation.")
    call.tick()
    result["callbacks"] = call.callbacks
    return result
