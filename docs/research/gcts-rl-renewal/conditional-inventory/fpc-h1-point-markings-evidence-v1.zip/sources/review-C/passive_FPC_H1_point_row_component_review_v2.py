"""Independent point-row Source/math review, no imported adapter or semantic call."""
import ast
import hashlib
import json
from pathlib import Path
F = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
C, R, B = F/'review-C', F/'root', F/'implementation-B'
seen = {}
def need(v,m):
    if not v: raise ValueError(m)
def pin(p):
    p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_file() and not p.is_symlink(),'canonical Source')
    b=p.read_bytes();q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    need(str(p) not in seen or seen[str(p)]==q,'stable raw identity');seen[str(p)]=q;return q
def verify(q):need(pin(q['path'])==q,'full declared raw pin')
contract_pin=pin(R/'fpc-h1-point-row-reduction-contract-v1.json')
need((contract_pin['bytes'],contract_pin['sha256'])==(8538,'3d56003ac1538232926a7b36b584423ba75d0ecfcda87a27f98e61f71d5fed99'),'exact offered contract')
contract=json.loads(Path(contract_pin['path']).read_bytes())
for q in [contract['Source'],contract['Source_predecessor'],contract['successor'],contract['dependencies']['builders']]:verify(q)
source_pin=contract['Source'];old_pin=contract['Source_predecessor']
source=Path(source_pin['path']).read_text();old=Path(old_pin['path']).read_text()
need((source_pin['bytes'],source_pin['sha256'])==(10972,'57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'),'exact adapter')
replacements=[('VERSION = "FPC-H1-POINT-ROWS-v1"','VERSION = "FPC-H1-POINT-ROWS-v2"'),
('    result.update(schema="FPC-H1-point-row-observation-v1", complete=True,',
 '    target = []\n    for k in range(len(rows)):\n        call.tick()\n        target.append((k, 0))\n    result.update(schema="FPC-H1-point-row-observation-v1", complete=True,'),
('        target=tuple((k, 0) for k in range(len(rows))),','        target=tuple(target),')]
t=old
for before,after in replacements:need(t.count(before)==1,'unique delta');t=t.replace(before,after,1)
need(t==source,'full forward successor')
for before,after in reversed(replacements):need(t.count(after)==1,'unique inverse');t=t.replace(after,before,1)
need(t==old,'full predecessor inverse')
old_tree,new_tree=ast.parse(old),ast.parse(source)
compile(new_tree,source_pin['path'],'exec') # Unused object.
defs=lambda tree:{n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=defs(old_tree),defs(new_tree)
need(a.keys()==b.keys() and [n for n in a if a[n]!=b[n]]==['check_rows_as_points'],'only public target-loop function changes')
need(not any(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(new_tree)),'no adapter imports')
checker_pin=pin(B/'fpc_h1_byte_checker_v1.py')
need(checker_pin['sha256']=='140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7','exact parsed carrier Source')
master_pins=[pin(Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')),
 pin(Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-batch-20261020/publisher-recovery-6338a77/docs/basic-tiling-algorithm.md'))]
checks=[
dict(id='exact-full-Source-contract-and-narrow-successor',passed=True,finding='Read all255lines/full8538B contract and exact successor record; independent AST/unused compile only. Full v2 inverse restores10901B/91f1 predecessor. Only VERSION and public target construction change, with a genuine callback per target row; observation schema staysv1. Adapter imports nothing; exact helper/parser bodies are contextual Source, not invoked.'),
dict(id='paired-parser-and-pinned-builder-preconditions',passed=True,finding='Input means the complete wellformed decode_query(Q) and decode_certificate(C,Q) outputs for the SAME immutable query bytes/signature, not arbitrary independently parsed trees. Source performs no byte/EOF/arity parser work and assumes this joint precondition plus exact immutable reviewed builders. Parsed row_count/index/rule_tag/subtag/witness carriers match pinned checker Source. Whole actual custody must establish pairing, raw identities and input/namespace immutability; VERSION or this adapter alone cannot do so.'),
dict(id='intrinsic-membership-and-declared-conclusion-binding',passed=True,finding='HYP checks fixedGamma index; logical families call exact guarded builder; theory subtag must match finite/PA/PA-induction/incidence profile, table indices remain scoped, and induction calls exact parameter/capture builder. Declared formula must equal intrinsic conclusion. MP/GEN only require their local family form/strict backward refs/fullGamma side condition; no prior logical validity is silently assumed. Coincident MP reference ports must be a consistent marking function.'),
dict(id='MP-GEN-premise-equalities-are-point-marking-only',passed=True,finding=r'MP chooses free family parameter \(A\) from one earlier declared row and requests \(A\) and \(A\to B\) at its two negative-offset ports; it never compares the implication row intrinsically. GEN requests its declared conclusion body at one earlier port and checks the full fixed \(\Gamma\) freshness condition; equality with the source is only marking agreement. Every row writes its conclusion at its own port. Missing is unconstrained, assigned formula values use exact structural equality without alpha conversion, and mark-only remote ports are checked regardless of frontier membership.'),
dict(id='finite-frame-forward-correspondence',passed=True,finding=r'For any wellformed primitive-valid paired certificate, choose one verified family member at each row translation. Unit \(t\) covers every cell in \(Q=\{(k,0):0\le k<n\}\); primitive premise validity makes every requested \(m\) value equal the earlier outgoing value, and final proof goal equals the boundary at \((n-1,1)\). Intrinsic conclusion binding prevents substituting a computed axiom for a wrong declared row. This is a manual conditional correspondence argument, not a generated certificate/tiling or formal theorem.'),
dict(id='finite-frame-reverse-correspondence-and-exterior',passed=True,finding=r'For a complete exact frame tiled by VERIFIED catalog members, unit nonnegative occupancy gives exactly one row placement per required cell and prevents exterior placements against fixed exterior occupancy1. Negative offsets point strictly earlier; exterior formula sentinels cannot equal a wellformed core formula. Reading rows by coordinate, membership supplies axioms/guards while mark agreement supplies the exact MP/GEN premises. The goal boundary supplies the final equality. Thus the conditional inverse yields primitive rows under fixed query/context. The private kernel accepts only the constructed inventory precondition; arbitrary user point-data pieces are not a proof verifier.'),
dict(id='translation-and-placement-identity-scope',passed=True,finding='Public entry checks the canonical translation(index,0) compiled from a given row vector. Returned original witnesses/references are absolute row audit data; local m offsets are relative. A later arbitrary-translation catalog/solver must derive or remap references from relative ports at the chosen row, and retain distinct family/subtag/witness/type identities even when point values coincide. This Source does not expose a general tile enumerator, arbitrary-tiling decoder, transformed witness transport or deduplication equivalence theorem. Rotations/reflections are not permitted.'),
dict(id='first-fault-whole-observation-and-master-boundaries',passed=True,finding='Per-call first callback BaseException is latched and re-raised before helper errors; no same-class normalization or logical failure wrapper is used. Uncaught faults yield no completed prefix, while complete point_compatible false is an observation with mismatch reasons. All target points are checked and final target serialization has per-row callbacks. Inputs/outputs/helpers remain future charged work. Five unbounded parametric families/long-range formula marks are neither a fixed finite Wang palette nor a graph/search/learner. No complete candidate incidence, master dead/forced/generation scheduler, rollback or runtime qualification is implemented or claimed.'),
]
for q in list(seen.values()):verify(q)
receipt=dict(schema='F-C-FPC-H1-point-row-adapter-component-Source-review-v2',review_passed=True,
 status='PASS_CONDITIONAL_PARAMETRIC_POINT_REDUCTION_SOURCE_ONLY',component_only=True,
 contract=contract_pin,Source=source_pin,predecessor=old_pin,successor_record=contract['successor'],
 builders=contract['dependencies']['builders'],parser_Source=checker_pin,masters=master_pins,
 checks=checks,failures=[],exact_successor_inverse=True,
 required_future_bindings=['Complete paired same-byte parser outputs, exact pinned immutable builders/inputs and whole custody.',
 'Independent intrinsic-membership/point-kernel/control qualification and same immutable query/certificate accepted by both original validators inside a future reviewed actual.',
 'Any actual candidate catalog/transform transport/master graph/scheduler/rollback implementation is a separate Source/plan review; no arbitrary tiles are admitted by the private kernel.',
 'Finite Wang logical-verifier machine/lowering/palette correspondence remains separate.'],
 proof_admitted=False,formal_soundness_or_completeness_proved=False,execution_or_grant_authority=False,
 reviewed_raw_pins=sorted(seen.values(),key=lambda q:q['path']),review_program=pin(Path(__file__)),
 operations=dict(subject_adapter_builder_parser_checker_reference_or_semantic_calls=0,
 query_AST_proof_tile_or_expected_output_generation=0,scientific_imports=0,ast_literal_eval=0,
 partial_parses=0,browser_network_Git_process_probes=0,Root_Publisher_or_frozen_Source_mutations=0,
 primary_reader_index_gcts_active_access=0),tools_idle_after_receipt=True)
out=C/'typed-FPC-H1-point-row-adapter-component-Source-review-v2.json'
with out.open('x',encoding='utf-8') as s:json.dump(receipt,s,indent=2,ensure_ascii=False,allow_nan=False);s.write('\n')
print(json.dumps(dict(review=pin(out),program=pin(Path(__file__)),checks=len(checks),failures=0)))
