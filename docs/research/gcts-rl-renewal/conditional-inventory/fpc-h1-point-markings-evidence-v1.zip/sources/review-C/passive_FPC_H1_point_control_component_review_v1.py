"""C-only raw/AST/complete-metadata review; never imports a subject module."""
import ast
import hashlib
import json
from pathlib import Path

F = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021')
C = F / 'review-C'
L = F / 'diagnostics-L'
R = F / 'root'
B = F / 'implementation-B'

def pin(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def require_pin(path, size, digest):
    found = pin(path)
    assert (found['bytes'], found['sha256']) == (size, digest), found
    return found

handoff = require_pin(L / 'fpc-h1-point-row-independent-controls-handoff-v1.json', 3778, '5d84b624f783098adcef10b9dcc95a981edca05f780f44c9c8e6cc684645cbbf')
bank = require_pin(L / 'fpc_h1_point_row_independent_controls_v1.py', 18065, 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e')
public_api = require_pin(R / 'fpc-h1-point-row-public-API-v1.json', 6466, 'ea09e64353a43ebdb9a67150e8e77d2e2f608b3dbca0268eef75ad25123c1ebf')
adapter = require_pin(R / 'fpc_h1_point_rows_v2.py', 10972, '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f')
contract = require_pin(R / 'fpc-h1-point-row-reduction-contract-v1.json', 8538, '3d56003ac1538232926a7b36b584423ba75d0ecfcda87a27f98e61f71d5fed99')
prior = require_pin(C / 'typed-FPC-H1-point-row-adapter-component-Source-review-v2.json', 11616, '52c064358631db36ee656c2b860d308a9b7f790f72c307c9d969ebd6b373dafe')
builders = require_pin(B / 'fpc_h1_ast_and_builders_v1.py', 11348, 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32')
offer = json.loads(Path(handoff['path']).read_text())
files = []
for declared in offer['files']:
    assert pin(Path(declared['path'])) == declared
    files.append(declared)
api = json.loads((L / 'fpc-h1-point-row-independent-controls-API-v1.json').read_text())
manual = json.loads((L / 'fpc-h1-point-row-independent-controls-manual-v1.json').read_text())
static = json.loads((L / 'fpc-h1-point-row-independent-controls-static-v1.json').read_text())
public = json.loads(Path(public_api['path']).read_text())
assert public['Source'] == adapter and public['contract'] == contract
assert public['component_review'] == prior and api['Source'] == bank
assert offer['Root_executable_unread_expected_rawpin'] == adapter
assert offer['builder_role_pin'] == builders
source = Path(bank['path']).read_text()
tree = ast.parse(source, filename=bank['path'])
compile(tree, bank['path'], 'exec')  # Code object is unused; no eval/exec/import.
assignments = {node.targets[0].id: node.value for node in tree.body
               if isinstance(node, ast.Assign) and len(node.targets) == 1
               and isinstance(node.targets[0], ast.Name)}
ids_node = assignments['CONTROL_IDS']
assert isinstance(ids_node, ast.Tuple)
assert all(isinstance(node, ast.Constant) and type(node.value) is str for node in ids_node.elts)
ids = [node.value for node in ids_node.elts]
assert len(ids) == len(set(ids)) == 20
assert ids == offer['CONTROL_IDS'] == api['return']['control_ids']
fixtures_node = assignments['FIXTURES']
assert isinstance(fixtures_node, ast.Tuple) and len(fixtures_node.elts) == 15
fixture_ids = []
for node in fixtures_node.elts:
    assert isinstance(node, ast.Dict)
    pairs = {key.value: value for key, value in zip(node.keys, node.values)
             if isinstance(key, ast.Constant)}
    assert isinstance(pairs['id'], ast.Constant)
    fixture_ids.append(pairs['id'].value)
assert fixture_ids == ids[:15]
imports = [node for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))]
assert all(isinstance(node, ast.Import) for node in imports)
assert [name.name for node in imports for name in node.names] == ['copy', 'json']
assert offer['counts'] == {'fixture_groups': 15, 'fault_groups': 5, 'total_groups': 20}
assert api['return']['counts'] == {'groups': 20, 'passed': 20, 'failed': 0}

checks = [
    {'id': 'exact-complete-offer-and-public-API-Source', 'passed': True,
     'finding': 'Read complete 328-line bank, all handoff/API/manual/static documents, current 255-line adapter and relevant pinned builder definitions. Rehashed exact named bodies; AST and unused compile only. Twenty unique Source IDs agree with both offer and API, with fifteen fixture IDs first. No subject imported or called.'},
    {'id': 'current-canonical-embedding-and-production-preconditions', 'passed': True,
     'finding': 'Public API accurately narrows the earlier adapter contract to complete same-query parser outputs and immutable pinned builders. Handwritten semantic test projections are explicitly allowed without claiming parser/EOF provenance. Unit occupancy already applies per row; relative marks translate, while original absolute witness/reference audit fields require remapping for independently placed prototypes. Five parametric families are not a fixed finite Wang palette or search engine.'},
    {'id': 'six-positive-and-three-mark-conflict-literals', 'passed': True,
     'finding': 'Manual Source reasoning supports the six positive groups (HYP/MP, GEN, repeated source, remote offset, Q3, finite table) and three point conflicts. Wrong MP conclusion requests the wrong implication at (1,1); wrong final goal conflicts at (2,1); wrong GEN body conflicts at source (0,1). These inputs remain wellformed semantic projections. Repeated source writes number three and remote GEN retains local (-3,1); neither adds extra occupancy. Expected formulas/points are independent authored literals, not outputs computed here.'},
    {'id': 'six-local-membership-refusal-literals', 'passed': True,
     'finding': 'Full unused Gamma free variable blocks GEN; wrong HYP/logical declaration cannot be replaced by computed conclusion; finite profile cannot select PA table family; current-row MP reference is not strict backward; coincident MP ports would require a finite formula equal its own implication and must fail local consistency. Q3 subtag5/witness order and finite table subtag0 match exact builder/adapter Source. No additional rule or proof admission is introduced.'},
    {'id': 'observation-carrier-and-immutable-semantic-inputs', 'passed': True,
     'finding': 'Each fixture is independently deep-copied. Complete observations require schema, exact bool status, row count, callback int, final boundary, unit local t, declared conclusions and canonical translations. Positive totals/goal marks and selected repeated/remote port properties are checked; mismatch controls require exact kind and authored point. Complete return, local refusal and intentional fault paths compare input canonical snapshots. Tuple/list normalization is only carrier normalization; exact JSON numbers remain typed where asserted.'},
    {'id': 'five-first-fault-groups-and-foreign-escape', 'passed': True,
     'finding': 'Bank outer callback faults are latched in _Call before any classification. Unexpected identities bare re-raise; intentional E is accepted only by object identity, and a later F cannot be silently passed. Groups cover entry RuntimeError, exact public refusal class, StopIteration, one baseline-derived later callback and a retained genuine previous refusal. Retained instance attributes are compared after reuse. Adapter first-fault identity is independently visible in Source; these five recipes do not constitute an every-callback sweep.'},
    {'id': 'whole-bank-return-and-scope-gaps', 'passed': True,
     'finding': 'Complete20 return occurs only after exact ordered population equality, with a final genuine callback; failures escape without a passing prefix. No scientific imports, hidden theorem targets, old certificate/result adoption or private arbitrary-piece injection exists. API/manual openly omit parser/EOF, exhaustive schemas/PA induction, candidate graph/dead-forced-generation scheduling, rollback, learned marks, finite palette, theorem and resource/fit claims. Source-only PASS authorizes no call or actual.'}
]

receipt = {
    'schema': 'F-C-FPC-H1-point-row-independent-controls-and-API-Source-review-v1',
    'review_passed': True,
    'status': 'PASS_COMPONENT_SOURCE_ONLY_ALL20_UNRUN',
    'component_only': True,
    'handoff': handoff, 'control_Source': bank, 'public_API': public_api,
    'adapter_Source': adapter, 'contract': contract, 'prior_adapter_review': prior,
    'builders_Source': builders, 'offer_files': files,
    'control_ids': ids, 'counts': {'positive_point': 6, 'mark_conflict': 3,
        'local_refusal': 6, 'fault': 5, 'total': 20},
    'checks': checks, 'failures': [],
    'coverage_notes': [
        'Retained-refusal group snapshots vars(error), not BaseException.args or traceback/context/cause. Current adapter Source does not mutate these, but this test must not be reported as exhaustive exception-object immutability.',
        'Observation checks sample required point/card fields; they do not independently compare every returned tile field or all target coordinates, and no arbitrary missing/overlap tile is injected.',
        'Canonical source refs are not a placement-invariant prototype API. A later catalog/solver needs explicit transport and separate tests.',
        'Future exact bounded worker/protocol/closure/once resource and complete actual review are still needed; this PASS does not qualify an existing runtime or admit a proof.'
    ],
    'execution_or_grant_authority': False, 'proof_admitted': False,
    'review_program': pin(Path(__file__)),
    'operations': {'subject_or_scientific_imports_calls': 0, 'semantic_fixture_or_expected_output_execution': 0,
        'query_certificate_or_palette_generation': 0, 'ast_literal_eval': 0, 'partial_parses': 0,
        'browser_network_Git_process_probes': 0, 'Root_Publisher_or_frozen_Source_mutations': 0},
    'tools_idle_after_receipt': True
}
out = C / 'typed-FPC-H1-point-row-independent-controls-and-API-Source-review-v1.json'
payload = (json.dumps(receipt, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
with out.open('xb') as handle:
    handle.write(payload)
print(json.dumps(pin(out)))
