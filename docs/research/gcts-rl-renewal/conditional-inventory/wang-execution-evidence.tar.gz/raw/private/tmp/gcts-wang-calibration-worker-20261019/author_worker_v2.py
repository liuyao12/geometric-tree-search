"""Inert raw/AST/ordinary metadata author. Does not import or call subjects."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-wang-calibration-worker-20261019')
oldpath=D/'qualify_wang_calibration_worker_v1.py'
newpath=D/'qualify_wang_calibration_worker_v2.py'

def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def save(name,value):
    path=D/name
    with path.open('xb')as out:out.write(json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(path)

old=oldpath.read_text()
assert pin(oldpath)['sha256']=='adaa61bdcd3f8f42fbd83c1d0afd59e6bd7cb71c356be93b0267908f6cca3a55'
helper='''def bind_original_case(s,instance,machine,case):
    # Literal input/frame binding for SAT AND exhausted decisions, before search.
    s.check()
    need(type(instance)is dict and type(instance['palette'])is dict and
         type(instance['palette']['machine'])is dict and
         canonical(instance['palette']['machine'])==canonical(machine),
         'instance full palette machine is exact original machine')
    word=case['initial_word'];steps=case['steps'];width=len(word);height=steps+1
    need(type(word)is list and type(instance['initial_word'])is list and
         canonical(instance['initial_word'])==canonical(word),'instance full original initial word')
    expected_dimensions=dict(machine_steps=steps,tape_width=width,board_width=width+2,board_height=height)
    for name,wanted in expected_dimensions.items():
        s.check();need(type(wanted)is int and type(instance[name])is int and instance[name]==wanted,
                       'strict original case dimension '+name)
    constructors=instance['palette']['color_constructors'];need(type(constructors)is list,'full verified palette constructors')
    color_ids={}
    for index,value in enumerate(constructors):
        s.check();key=canonical(value);need(key not in color_ids,'unique full literal palette color constructor')
        color_ids[key]=index
    def color(value):
        s.check();key=canonical(value);need(key in color_ids,'original boundary constructor present in full verified palette')
        return color_ids[key]
    north=[color(['side','left','run'])]+[color(['cell',cell])for cell in word]+[color(['side','right','run'])]
    south=[color(['side','left','done'])]+[color(['stop'])]*width+[color(['side','right','done'])]
    east=[color(['exterior','right'])]*height;west=[color(['exterior','left'])]*height
    boundary=[north,east,south,west]
    need(type(instance['boundary_NESW'])is list and canonical(instance['boundary_NESW'])==canonical(boundary),
         'full boundary NESW bound to original word and exact time/acceptance frame')
    pins=[]
    for y in range(height):
        s.check();pins.append([[-1,2*y],'edge',west[y]])
        pins.append([[2*(width+2)-1,2*y],'edge',east[y]])
    for x in range(width+2):
        s.check();pins.append([[2*x,-1],'edge',north[x]])
        pins.append([[2*x,2*height-1],'edge',south[x]])
    need(type(instance['fixed_background_marks'])is list and
         canonical(instance['fixed_background_marks'])==canonical(pins),
         'complete ordered exterior pin list bound to original case')
    s.check()
    return dict(status='EXACT_ORIGINAL_CASE_AND_BOUNDARY_BOUND',original_case=clone(case),
        original_machine=clone(machine),expected_dimensions=expected_dimensions,
        expected_boundary_NESW=boundary,expected_fixed_background_marks=pins,
        full_canonical_comparisons=True,mathematical_authority=False)


'''
new=old.replace("VERSION = 'complete-wang-calibration-worker-v1'","VERSION = 'complete-wang-calibration-worker-v2'")
assert new!=old
anchor='def calibrate(s,inputs):\n'
assert new.count(anchor)==1
new=new.replace(anchor,helper+anchor)
a="        palette=projected['palette'];audit=palette_check(s,palette)\n"
b="        palette=projected['palette']\n        need(type(palette['machine'])is dict and canonical(palette['machine'])==canonical(machine),\n             'complete machine-only palette exact original machine')\n        audit=palette_check(s,palette)\n"
assert new.count(a)==1;new=new.replace(a,b)
a="        observations=[];result,restoration=invoke_search(s,instance,observations,keep_first=base is None)\n"
b="        input_binding=bind_original_case(s,instance,machine,case)\n"+a
assert new.count(a)==1;new=new.replace(a,b)
a="            search=result,verification=verification,reference_after_search=reference,observations=observations,\n"
b="            input_binding=input_binding,\n"+a
assert new.count(a)==1;new=new.replace(a,b)
with newpath.open('x')as out:out.write(new)
oldt=ast.parse(old,filename=str(oldpath));newt=ast.parse(new,filename=str(newpath));compile(newt,str(newpath),'exec')
def defs(tree):return {n.name:ast.dump(n,include_attributes=False)for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a=defs(oldt);b=defs(newt)
assert set(b)==set(a)|{'bind_original_case'}
retained=[name for name in a if name!='calibrate']
assert all(a[name]==b[name]for name in retained)
# Reverse exact introduced spans, not scientific execution or a generated witness.
reverse=new.replace(helper,'').replace("VERSION = 'complete-wang-calibration-worker-v2'","VERSION = 'complete-wang-calibration-worker-v1'")
reverse=reverse.replace("        palette=projected['palette']\n        need(type(palette['machine'])is dict and canonical(palette['machine'])==canonical(machine),\n             'complete machine-only palette exact original machine')\n        audit=palette_check(s,palette)\n","        palette=projected['palette'];audit=palette_check(s,palette)\n")
reverse=reverse.replace('        input_binding=bind_original_case(s,instance,machine,case)\n','').replace('            input_binding=input_binding,\n','')
assert reverse==old
for name,left,right in [('worker-v1-to-v2.patch',old,new),('worker-v2-to-v1.patch',new,old)]:
    with(D/name).open('x')as out:out.write(''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='worker.py',tofile='worker.py')))
common=dict(author_identity='/root/conventional_library',cohort_owner_identity='/root',source_only=True,subject_imports=0,
    component_calls=0,fixture_calls=0,scientific_acceptance=False,actual_execution_authorized=False)
prior=json.loads((D/'handoff-v1.json').read_bytes())
api=save('API-v2.json',dict(schema='complete-wang-calibration-worker-API-v2',**common,Source=pin(newpath),parent_API=prior['API'],
    entry='python3.12 -I -S -B worker.py once-plan.json; main(plan_path)',version='complete-wang-calibration-worker-v2',
    unchanged_protocol='All V1 plan/result/header/payload schemas, full680cases/30groups55variants, seven roles, component/callback caps and expanded/stored accounting remain. Root must replace worker Source descriptor and expected VERSION only.',
    new_presearch_guard='bind_original_case(s,instance,machine,case): original full machine, full initial word, strict-int original dimensions, complete original-word NESW boundary constructor IDs, exact full ordered exterior pin list. No simulation, proof route or new search input.',
    retained_per_case='row.input_binding: status EXACT_ORIGINAL_CASE_AND_BOUNDARY_BOUND; original_case,original_machine,expected_dimensions,expected_boundary_NESW,expected_fixed_background_marks,full_canonical_comparisons:true,mathematical_authority:false.',
    existing_profile=prior['profile'],components=prior['components'],input=prior['input']))
contract=save('Source-contract-v2.json',dict(schema='complete-wang-calibration-worker-Source-contract-v2',**common,
    Source=pin(newpath),API=api,parent_Source=prior['Source'],parent_contract=prior['Source_contract'],
    delta=['VERSION v2','new worker-only literal input/frame guard','compile_palette.machine canonical join before complete palette check',
           'call new binding guard before every normal search','retain full per-row binding evidence'],
    type_scope='Downstream compiler objects are explicit ordinary JSON projections. Canonical full bytes distinguish bool/int/float/string/order and presence; dimensions additionally require exact builtin int. Tuple-to-array normalization remains declared, not a Python type identity claim.',
    color_scope='Constructor IDs selected by full canonical constructor bytes in the complete independently verified machine palette; dictionary collisions still require complete bytes equality. No hash-only identity or trimming.',
    boundary_scope='Original case supplies full word and exact time. Worker constructs standard run/done/stop/exterior words and complete ordered exterior edge pins; no machine evolution consulted. Search/oracle retain independent full target/origin/point/pin audits.',
    errors='Mismatch fails before search; no positive calibration or untileability claim. Existing error/latch/limits intact. Added guards/copies/checkpoints are charged inside same180/210/1GiB/128MiB; no fit claim.',
    ancestry='Same Library author of compiler/search/verifier/worker; this is author Source argument, not an independent own certificate. V1 negative/preserved Source not executed or repaired in place.',
    remaining='All new guards and680+55 cohort remain unexecuted; exact Root declaration/runtime/plan and C distinct Source review pending. No grant.'))
audit=save('author-static-audit-v2.json',dict(schema='complete-wang-worker-author-static-audit-v2',**common,
    Source=pin(newpath),unused_compiles=1,AST_retained_definition_count=len(retained),AST_retained_definitions=retained,
    exact_reverse_restores_full_V1=True,patches=[pin(D/'worker-v1-to-v2.patch'),pin(D/'worker-v2-to-v1.patch')],
    reviewed_addition='Full new helper and three call/evidence insertions read as Source; no branch or diagnostic run.',
    target_calls=0,author_Source=pin(__file__)))
h=save('handoff-v2.json',dict(schema='complete-wang-calibration-worker-handoff-v2',**common,Source=pin(newpath),API=api,
    Source_contract=contract,author_static_audit=audit,parent_handoff=pin(D/'handoff-v1.json'),profile=prior['profile'],
    components=prior['components'],input=prior['input'],status='SOURCE_ONLY_INACTIVE_NO_GRANT',tools_stopped_after_handoff=True))
print(json.dumps(dict(Source=pin(newpath),API=api,handoff=h,retained_definitions=len(retained)),sort_keys=True))
