"""Raw/AST-only independent oracle audit; no subject imports or invocation."""
import ast
import hashlib
import json
from pathlib import Path

D=Path('/private/tmp/gcts-wang-snapshot-oracle-20261019')
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
def pin(path):
    path=Path(path);raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
source=D/'wang_snapshot_oracle_v1.py'
api_path=D/'API-v1.json'
api=json.loads(api_path.read_bytes())
check('oracle exact offered Source pin',pin(source)==dict(path=str(source),bytes=12476,sha256='f77f395b1e8b3731dc8fc64deb6cd82c970009e088b91776a18b2e547af97369'))
check('oracle exact offered API pin',pin(api_path)==dict(path=str(api_path),bytes=3153,sha256='4867d0754a8f49ffbe5d1a01b41bba360cd7fe190abe65ee871549c990caafb2'))
check('API Source literal descriptor',api['Source']==pin(source))
check('same exact snapshot ABI',pin(api['snapshot_API']['path'])==api['snapshot_API'])
text=source.read_text();tree=ast.parse(text,str(source));compile(tree,str(source),'exec')
check('no subject imports or generators',not any(isinstance(n,(ast.Import,ast.ImportFrom,ast.Yield,ast.YieldFrom,ast.Await))for n in ast.walk(tree)))
check('no eval/exec/loader call',not any(isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in('eval','exec','__import__')for n in ast.walk(tree)))
for name,fragment in {
    'exact class before owner read':'return type(error)is SnapshotLimit and error._owner is _OWNER',
    'module owner token, explicitly not per-call':'_OWNER = object()',
    'full origin by tile cross product':'for pi,(ox,oy) in enumerate(origins):\n        w.step();at_origin=[]\n        for tid in range(size):',
    'all mark dependencies independent of active status':'m_dependencies.setdefault(p,[]).append(cid)',
    'physical and excluded-active sets separate':'is_active=legal and cid not in excluded',
    'dead before forced before branch':"if dead:kind='DEAD';point=min(dead)\n    elif forced:kind='FORCED';point=min(forced)",
    'strict complete expected field equality':"_need(_same(snapshot[field],value,w),'full independent snapshot mismatch: '+field)",
    'initial and root context empty':"_need(not chosen and not exclusions and trail==0,'complete initial/root-restored context')",
    'direct final callback':'w.step();check()',
    'no exclusion soundness claim':'exclusion_soundness_certified=False',
    'no fractional/mixed generation claim':'general_fractional_or_mixed_generation_engine_qualified=False',
}.items():check(name,fragment in text)
check('oracle does not catch or normalize external errors',not any(isinstance(n,ast.ExceptHandler)for n in ast.walk(tree)))
result=dict(schema='finite-wang-independent-oracle-static-audit-v1',reviewer_identity='/root/conventional_control_review',source_only=True,scientific_calls=0,component_calls=0,subject_imports=0,fixture_calls=0,simulations=0,actual_execution_authorized=False,unused_compiles=1,Source=pin(source),API=pin(api_path),checks=checks,check_count=len(checks),mismatch_count=sum(not c['passed']for c in checks),owner_scope='Module-private exact-class owner token; not a per-invocation token. External callback faults must be latched separately by Root before module-own-limit classification. No callback is caught inside this oracle.',exclusion_scope='Recomputes physical candidates and subtracts the declared context exclusions. Does not establish their exhausted-child proof; trail length is bounded and retained, not independently reconstructed as an operation log.')
out=C/'oracle-Source-static-audit-v1.json'
with out.open('xb')as f:f.write((json.dumps(result,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(dict(audit=pin(out),checks=len(checks),mismatches=result['mismatch_count']),sort_keys=True))
