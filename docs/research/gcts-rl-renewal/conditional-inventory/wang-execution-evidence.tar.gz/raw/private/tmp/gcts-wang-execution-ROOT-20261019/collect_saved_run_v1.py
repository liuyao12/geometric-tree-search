"""Passive post-terminal metadata projection only; no target/checker execution."""
from pathlib import Path
import hashlib
import json

D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=p.resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,v):
    p=D/name
    with p.open('xb')as f:f.write(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n')
    return pin(p)

def main():
    pp=D/'plan-authorized-v3.json';plan=json.loads(pp.read_bytes());actual=Path(plan['actual_directory'])
    terminal_path=D/'plan-authorized-v3-terminal-observation/terminal.json'
    terminal=json.loads(terminal_path.read_bytes());runner=json.loads((actual/'runner-receipt.json').read_bytes())
    assert terminal['plan']==runner['plan']==pin(pp)
    assert runner['worker_reaped'] and runner['owned_group_absent'] and runner['regular_logs_closed']
    assert runner['post_child_raw_custody']['checked'] and runner['post_child_raw_custody']['completed_before_deadline']
    assert runner['whole_log_custody']['stable'] and runner['whole_log_custody']['complete']
    assert runner['whole_log_custody']['completed_before_deadline']
    assert runner['final_physical_ledger']['enumeration_complete'] and runner['final_physical_ledger']['completed_before_deadline']
    assert terminal['terminal_observed_ns']<runner['overall_deadline_ns']
    positive=terminal['terminal_gate_passed'] and runner['resource_candidate_accepted'] and runner['finite_encoding_candidate']
    s=dict(schema='ROOT-finite-wang-calibration-closure-v1',classification='PROGRESS',goal_status='active',
      root_resource_candidate_accepted=positive,whole_frozen_calibration_completed=positive,
      invocation_id=plan['invocation_id'],plan=pin(pp),terminal=pin(terminal_path),runner=pin(actual/'runner-receipt.json'),
      limits=plan['limits'],elapsed_seconds=(terminal['terminal_observed_ns']-runner['began_ns'])/1e9,
      worker_peak_bytes=runner['worker_wait4_usage']['ru_maxrss'],worker_exit_code=runner['worker_exit_code'],
      worker_reaped=runner['worker_reaped'],owned_group_absent=runner['owned_group_absent'],
      stored_logical_bytes=runner.get('logical_result_bytes'),expanded_logical_bytes=runner.get('expanded_logical_result_bytes'),
      physical_with_reserve_bytes=runner['final_physical_ledger']['conservative_bytes'],
      worker_memory_scope='Darwin standalone worker highwater; parent/observer not included; not full-pipeline fit.',
      proof_search_calls=0,new_theorems=0,fixed_FOL_palette_qualified=False,full_pipeline_qualified=False,
      gcts_rl_advantage_established=False,learned_markings=False,trained_RL=False,
      no_target_execution_in_projection=True,
      earlier_whole_six_root_workload='PRESERVED_FAILED; fresh finite encoding calibration does not repair or replace it.',
      remaining=['Fixed full FOL machine/table/codec/palette and unknown-certificate grammar/search',
      'Full Hilbert source/context translation and arithmetic theorem benchmarks with matched controls',
      'Certified learned markings, receptor-family lemma transfer and trained RL contribution tests',
      'Generic mixed-generation/shared-support/fractional GCTS conformance',
      'Practical region tiling, unmarked Turtle/A2 and exact Penrose work',
      'Original complete production workload and full cold-pipeline qualification'])
    if positive:
        p=actual/'canonical-wang-calibration.json';packet=json.loads(p.read_bytes());payload=json.loads((actual/'result.json').read_bytes())
        header=json.loads((actual/'worker-receipt.json').read_bytes());q=payload['qualification']
        assert len(packet['rows'])==len(q['rows'])==680 and len(packet['palettes'])==4
        assert len(packet['diagnostics'])==30 and sum(len(v['variants'])for v in packet['diagnostics'])==55
        assert [v['id']for v in packet['rows']]==q['case_ids']
        s.update(packet=pin(p),result=pin(actual/'result.json'),header=pin(actual/'worker-receipt.json'),
          complete_cases=len(packet['rows']),found_tilings=sum(r['status']=='FINITE_EXACT_TILING'for r in packet['rows']),
          finite_exhausted=sum(r['status']=='FINITE_EXHAUSTED'for r in packet['rows']),
          diagnostic_groups=30,diagnostic_variants=55,
          graph_states_checked=sum(r['graph_states_checked']for r in packet['rows']),
          full_value_restoration_comparisons=sum(v['full_value_restoration_compared']for r in packet['rows']for v in r['observations']),
          palette_rows=[dict(id=v['id'],tiles=len(v['palette']['tiles']),colors=len(v['palette']['color_constructors']))for v in packet['palettes']],
          calls_started=header['call_started'],calls_completed=header['call_completed'],calls_raised=header['call_raised'],
          q_root_check_calls=q['root_check_calls'],q_root_check_calls_scope=q['root_check_calls_scope'],
          header_root_check_calls=header['root_check_calls'],header_root_check_calls_scope=header['snapshot_cutoff_scope'],
          oracle_work=q['oracle_work'],oracle_work_unavailable_calls=q['oracle_work_unavailable_calls'],oracle_work_scope=q['oracle_work_scope'],
          main_successful_work=dict(
            compiler=sum(r['compiler_problem']['fields']['attempted_work']for r in packet['rows'])+sum(v['compile_palette_fields']['attempted_work']for v in packet['palettes']),
            search=sum(r['search']['counts']['work']for r in packet['rows']),
            positive_verifier=sum(r['verification']['counts']['work']for r in packet['rows']if r['verification']),
            post_search_reference=sum(r['reference_after_search']['counts']['work']for r in packet['rows']),
            palette_verifier=sum(v['check']['counts']['work']for v in packet['palette_checks'])),
          work_scope='Main680 plus four full palettes where stated; diagnostics not fabricated into unavailable totals. Different component units, not Arena work or comparable CPU steps.',
          search_events={k:sum(r['search']['counts'].get('metric_events_'+k,0)for r in packet['rows'])for k in('census','forced','branch','rollback','rollback_census','parent_context_exclusion')},
          rows=[dict(id=r['id'],machine_id=r['original_case']['machine_id'],width=len(r['original_case']['initial_word']),
              steps=r['original_case']['steps'],status=r['status'],graph_states_checked=r['graph_states_checked'],root_restored=r['root_restored'])for r in packet['rows']],
          snapshot_scope=packet['snapshot_lifecycle'])
    else:
        f=actual/'worker-failure.json';s['failure']=json.loads(f.read_bytes())if f.exists()else None
        s['primary_failure']=runner['primary_failure']
    print(json.dumps(dict(summary=save('ROOT-calibration-closure-v1.json',s),positive=positive),sort_keys=True))

if __name__=='__main__':main()
