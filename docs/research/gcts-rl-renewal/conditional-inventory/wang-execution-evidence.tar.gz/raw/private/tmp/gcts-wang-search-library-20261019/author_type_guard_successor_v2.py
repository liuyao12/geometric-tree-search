"""Metadata-only V2 Source authoring. No subject import or invocation."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

DIRECTORY = Path('/private/tmp/gcts-wang-search-library-20261019')


def pin(path):
    raw = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def save(name, value):
    path = DIRECTORY / name
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b'\n'
    with path.open('xb') as out:
        out.write(raw)
    return pin(path)


def main():
    old_api = json.loads((DIRECTORY/'API-v1.json').read_bytes())
    old_contract = json.loads((DIRECTORY/'Source-contract-v1.json').read_bytes())
    checks, current, parents, patches = [], {}, {}, {}
    roles = (
        ('search', 'wang_point_search', 'finite-wang-complete-point-search', 'SearchLimit', 'w'),
        ('verifier', 'wang_history_verifier', 'finite-wang-global-history-verifier', 'VerificationLimit', 'budget'),
    )
    for role, stem, label, error, owner in roles:
        parent = DIRECTORY/(stem+'_v1.py')
        output = DIRECTORY/(stem+'_v2.py')
        old = parent.read_text()
        before = 'if error._owner is not '+owner+'.owner:'
        after = 'if type(error) is not '+error+' or error._owner is not '+owner+'.owner:'
        if old.count(before) != 1 or old.count("VERSION = '"+label+"-v1'") != 1:
            raise ValueError('exact version/owner delta missing')
        new = old.replace(before, after).replace("VERSION = '"+label+"-v1'", "VERSION = '"+label+"-v2'")
        restored = new.replace(after, before).replace("VERSION = '"+label+"-v2'", "VERSION = '"+label+"-v1'")
        if restored != old or ast.dump(ast.parse(restored), include_attributes=False) != ast.dump(ast.parse(old), include_attributes=False):
            raise ValueError('whole inverse failed')
        parsed = ast.parse(new, filename=str(output))
        compile(parsed, str(output), 'exec')  # unused code object only
        with output.open('xb') as out:
            out.write(new.encode())
        current[role], parents[role] = pin(output), pin(parent)
        checks.append(dict(name=role+' exact class short-circuit plus VERSION only; whole raw/AST inverse', passed=True))
        for direction, a, b in [('forward', old, new), ('inverse', new, old)]:
            path = DIRECTORY/(stem+'-'+direction+'-v2.patch')
            raw = ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True),
                          fromfile='a/source.py', tofile='b/source.py')).encode()
            with path.open('xb') as out:
                out.write(raw)
            patches[role+'_'+direction] = pin(path)
    common = dict(author_identity='/root/conventional_library', cohort_owner_identity='/root', source_only=True,
                  scientific_calls=0, component_calls=0, compiler_calls=0, verifier_calls=0, search_calls=0,
                  fixture_calls=0, subject_imports=0, scientific_acceptance=False,
                  actual_execution_authorized=False, runtime_qualified=False)
    negative = save('author-detected-V1-limitation-v1.json', dict(schema='finite-wang-V1-author-detected-limitation-v1', **common,
        parent_handoff=pin(DIRECTORY/'handoff-v1.json'), Sources=parents,
        status='SUPERSEDED_BEFORE_ANY_EXECUTION',
        finding='The typed exception handlers inspected _owner on subclasses. An external callback subclass could customize attribute access and mask its original error. No such invocation/test was performed.',
        resolution='V2 checks exact class with short-circuit before owner attribute access. No algorithm, counters, graph, verifier semantics, data schema or snapshot ABI change. V1 preserved immutable.'))
    old_api['Sources'] = current
    old_api['search']['version'] = 'finite-wang-complete-point-search-v2'
    old_api['verifier']['version'] = 'finite-wang-global-history-verifier-v2'
    old_api['metadata_revision'] = 2
    old_api['predecessor_API'] = pin(DIRECTORY/'API-v1.json')
    old_api['exception_origin_correction'] = negative
    api = save('API-v2.json', old_api)
    old_contract['Sources'] = current
    old_contract['API'] = api
    old_contract['metadata_revision'] = 2
    old_contract['predecessor_contract'] = pin(DIRECTORY/'Source-contract-v1.json')
    old_contract['exception_origin_correction'] = negative
    contract = save('Source-contract-v2.json', old_contract)
    audit = save('author-static-audit-v2.json', dict(schema='finite-wang-V2-author-static-audit-v1', **common,
        Sources=current, parents=parents, checks=checks, check_count=len(checks),
        previous_author_audit=pin(DIRECTORY/'author-static-audit-v1.json'),
        additional_unused_compiles=2, total_unused_compiles_across_preflight_and_packets=6,
        raw_AST_inverse_verified=True, text_patches=patches, actual_patch_executions=0,
        limitation='Author Source-only exact delta confirmation, not an independent Source pass or executed exception fixture.'))
    handoff = save('handoff-v2.json', dict(schema='finite-wang-search-and-verification-handoff-v1', **common,
        metadata_revision=2, Sources=current, API=api, Source_contract=contract,
        snapshot_API=pin(DIRECTORY/'snapshot-API-v1.json'), author_static_audit=audit,
        author_Source=pin(__file__), previous_handoff=pin(DIRECTORY/'handoff-v1.json'),
        V1_limitation=negative, compiler=old_api['compiler'], current_master=old_contract['current_master'],
        status='UNEXECUTED_INACTIVE_PENDING_DISTINCT_REVIEW_AND_BOUNDED_QUALIFICATION', tools_stopped_after_handoff=True))
    print(json.dumps(dict(Sources=current, API=api, handoff=handoff, subject_calls=0), sort_keys=True))


if __name__ == '__main__':
    main()
