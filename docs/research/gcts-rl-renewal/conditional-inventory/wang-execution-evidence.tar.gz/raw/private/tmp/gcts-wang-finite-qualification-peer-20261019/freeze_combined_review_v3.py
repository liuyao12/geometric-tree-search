"""Final raw/AST/ordinary-metadata successor audit. Never imports a subject."""
import ast
import hashlib
import json
from pathlib import Path
import sys
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(name,value):
    p=C/name
    with p.open('xb')as f:f.write((json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
    return pin(p)
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def rawpin(name,p):check(name,pin(p['path'])==p)
parent_path=C/'typed-combined-Source-prospective-review-v2-negative.json'
parent=json.loads(parent_path.read_bytes())
# Preserve the original negative; remove one stale draft-PASS sentence in a
# corrected negative successor before handoff. Both gates remain false.
corrected=json.loads(parent_path.read_bytes())
corrected['limitations']=[v for v in corrected['limitations']if not v.startswith('This V2 combined PASS')]
corrected['limitations'].append('V2 is a negative combined metadata verdict: W1 Source repair resolved, but parser attribution M1 prevents adoption of this exact V2 subject. No grant or execution was authorized.')
corrected['reviewer_metadata_correction']=dict(prior_record=pin(parent_path),scope='One stale draft-PASS sentence was inconsistent with the literal false review gate. Removed in this preserved metadata successor before handoff; no target/input/Source/check finding changed.')
negative_pin=write('typed-combined-Source-prospective-review-v2-negative-final.json',corrected)
offer=json.loads((D/'Source-only-offer-v3.json').read_bytes())
plan=json.loads((D/'plan-false-v3.json').read_bytes())
subject={k:v for k,v in plan.items()if k!='authorization'}
check('V3 exact offered whole plan pin',pin(D/'plan-false-v3.json')==dict(path=str(D/'plan-false-v3.json'),bytes=3306,sha256='243754dc073127d0d6c2bb0f50d288e72d438b6af7da4379ff7e512765b1227d'))
check('nine-field literal whole subject',len(subject)==9 and len(plan)==10 and subject==offer['subject'])
check('whole canonical V3 subject SHA',hashlib.sha256(canonical(subject)).hexdigest()==offer['subject_sha256']=='f4645eacc562a732bfcd07bdda38a8a994ae936c43e112c40e7c4fda16ac0b3a')
check('all seven exact Sources unchanged',subject['sources']==parent['Sources']==offer['sources'])
for role,p in subject['sources'].items():rawpin('current whole Source '+role,p)
for key in('python','declaration','runtime_closure'):rawpin('current '+key,subject[key])
for item in subject['inputs']:rawpin('complete original input '+item['id'],item['pin'])
rawpin('current false authorization',plan['authorization'])
auth=json.loads(Path(plan['authorization']['path']).read_bytes())
check('exact seven-field false/max0/no-review authority',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['schema']=='ROOT-wang-encoding-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['subject_sha256']==offer['subject_sha256']and auth['review']is None)
declaration=json.loads(Path(subject['declaration']['path']).read_bytes())
closure=json.loads(Path(subject['runtime_closure']['path']).read_bytes())
inputs=json.loads(Path(subject['inputs'][0]['pin']['path']).read_bytes())
check('whole declaration content unchanged',Path(subject['declaration']['path']).read_bytes()==Path(parent['declaration']['path']).read_bytes())
check('all caps/interpreter/full inputs unchanged',all(subject[k]==parent['subject'][k]for k in('schema','limits','python','inputs','sources')))
check('exact complete original680/30/55 declaration',declaration['case_ids']==[r['id']for r in inputs['cases']]and len(declaration['case_ids'])==680 and declaration['machine_ids']==[r['id']for r in inputs['machines']]and declaration['diagnostics']==inputs['diagnostics']and len(declaration['diagnostics'])==30 and sum(len(d['variants'])for d in declaration['diagnostics'])==55)
check('declaration subject input and limits joins',declaration['inputs']==subject['inputs']and declaration['limits']==subject['limits'])
check('full current closure joins',closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['sources']==subject['sources']and closure['python']==subject['python']and closure['declaration']==subject['declaration'])
parser=closure['AST_parser']
check('explicit pinned parser executable',parser['executable']==str(Path(sys.executable).resolve())==subject['python']['path'])
check('explicit actual pinned parser version',parser['version']==sys.version and sys.version_info[:2]==(3,12))
check('explicit AST profile distinct from raw identity',parser['policy']=="ast.dump(ast.parse(raw),include_attributes=False), UTF-8 sha256; informational structural census distinct from raw Source identity")
check('seven complete unique census roles',len(closure['direct_import_census'])==7 and {r['role']for r in closure['direct_import_census']}==set(subject['sources']))
new_ast={}
for row in closure['direct_import_census']:
    role=row['role'];source=Path(subject['sources'][role]['path'])
    tree=ast.parse(source.read_bytes());imports=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
        elif isinstance(n,ast.ImportFrom):imports.append(n.module)
    digest=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()
    check(role+' exact pinned-parser AST/import/descriptor census',row['source']==subject['sources'][role]and row['direct_imports']==sorted(set(imports))and row['AST_sha256']==digest)
    new_ast[role]=digest
for i,p in enumerate(closure['stdlib_files']):rawpin('complete declared stdlib '+str(i),p)
old_closure=json.loads(Path(parent['runtime_closure']['path']).read_bytes())
normalized=json.loads(json.dumps(old_closure))
normalized['declaration']=subject['declaration'];normalized['AST_parser']=parser
for row in normalized['direct_import_census']:row['AST_sha256']=new_ast[row['role']]
check('closure delta only parser attribution/fingerprints and declaration path',normalized==closure)
old_plan=json.loads(Path(parent['false_plan']['path']).read_bytes())
normalized_subject={k:v for k,v in old_plan.items()if k!='authorization'}
for key in('invocation_id','actual_directory','declaration','runtime_closure'):normalized_subject[key]=subject[key]
check('subject delta only fresh identifiers and metadata descriptors',normalized_subject==subject)
check('new exact fresh invocation and directory',subject['invocation_id']=='complete-wang-calibration-680-v3'and subject['actual_directory']==str(D/'actual-complete-680-v3'))
for label,path in [('actual',Path(subject['actual_directory'])),('false observer',D/'plan-false-v3-terminal-observation'),('future authorized observer',D/'plan-authorized-v3-terminal-observation'),('authorized plan',D/'plan-authorized-v3.json')]:check('fresh absent '+label,not path.exists())
check('prior V1 and V2 actual paths remain absent',not(D/'actual-complete-680-v1').exists()and not(D/'actual-complete-680-v2').exists())
rawpin('preserved V2 false-plan bytes',parent['false_plan'])
rawpin('preserved V2 unattributed closure',parent['runtime_closure'])
rawpin('preserved V1 negative',parent['genuine_prior_review_reuse']['V1_combined_negative'])
audit_pin=write('combined-v3-metadata-static-audit.json',dict(schema='wang-combined-v3-metadata-static-audit-v1',source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,checks=checks,check_count=len(checks),mismatch_count=0,parser=parser,unused_compiles=0,scope='Fresh raw/AST/ordinary metadata checks. Same seven compiled-unused Source objects were reviewed/compiled under prior exact Source tuple; no repeated compile or target call needed.'))
record=json.loads(json.dumps(corrected))
record.update(review_passed=True,subject=subject,subject_sha256=offer['subject_sha256'],Sources=subject['sources'],false_plan=pin(D/'plan-false-v3.json'),offer=pin(D/'Source-only-offer-v3.json'),declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],input=subject['inputs'],findings=[],mismatch_count=0,current_static_checks=checks,current_static_check_count=len(checks),current_static_audit=audit_pin,unused_compiles=0,reused_unchanged_Source_unused_compiles=7,
    corrected_negative_ancestry=negative_pin,
    review_phase='FINAL COMBINED SOURCE/OUTER/FALSE PROSPECTIVE V3; NO EXECUTION AUTHORITY',
    parser=parser,
    final_action='Root may separately adopt these exact limited scopes and author one fresh max-one true grant. Review grants no execution. Exact auth-only final delta/freshness plus all-peer idle barrier still precede any Root-owned actual. Saved-data review begins only after authoritative terminal/cohort release.',tools_stopped_after_handoff=True)
record['genuine_prior_review_reuse']['V2_combined_negative']=negative_pin
record['genuine_prior_review_reuse']['V2_raw_static_results']=dict(checks=90,passed=83,unattributed_AST_mismatches=7,scope='All current Source/code repairs and whole-byte input/cap joins passed in V2. Only metadata parser fingerprints failed; each of those seven is freshly rechecked and matches in V3.')
record['resolved_findings'].append(dict(id='M1',parent_negative=negative_pin,resolution='V3 explicitly attributes the exact pinned Python3.12.14 parser and policy; all seven recomputed AST fingerprints now match. This informational census remains distinct from raw Source identity. No target Source, case, variant or cap changed.'))
record['limitations']=[v for v in record['limitations']if not v.startswith('V2 is a negative combined metadata verdict')]
record['limitations'].append('This combined V3 Source/prospective PASS resolves W1 for workerV2 and M1 for closureV3 only. It supersedes their pending-review status for this exact subject while preserving all V1/V2 negative artifacts and all historical runtime failures. Components/cohort remain unexecuted; no proof/runtime qualification or actual permission is inherited.')
record['reviewer_metadata_correction']['corrected_record']=negative_pin
out=write('typed-combined-Source-prospective-review-v3.json',record)
print(json.dumps(dict(receipt=out,review_passed=True,metadata_checks=len(checks),mismatch_count=0,negative=negative_pin,subject_sha256=record['subject_sha256'],component_calls=0),sort_keys=True))
