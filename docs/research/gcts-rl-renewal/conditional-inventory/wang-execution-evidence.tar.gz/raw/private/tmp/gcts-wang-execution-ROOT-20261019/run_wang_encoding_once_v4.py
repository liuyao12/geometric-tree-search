"""One Root-owned complete finite Wang calibration; inherited bounded cleanup."""
import time
NOW=time.monotonic_ns
BEGAN=NOW()
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

VERSION='wang-encoding-once-runner-v4'
PLAN_SCHEMA='ROOT-wang-encoding-qualification-plan-v1'
PLAN_FIELDS=frozenset(('schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'))
SOURCE_ROLES=frozenset(('worker','compiler','search','verifier','oracle','runner','observer'))
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
    result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,
    stderr_bytes=4194304,worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608,observer_bytes=1048576)
_METADATA_BYTES=0
CLEANUP_EVENT_LIMIT=32
CLEANUP_POLL_LIMIT=2048


def error_information(error):
    """Best-effort bounded metadata; never rethrow while preserving a primary."""
    try:
        number=getattr(error,'errno',None)
        return dict(type=type(error).__name__,message=str(error)[:512],
                    errno=number if type(number)is int else None)
    except BaseException:
        return dict(type='UNAVAILABLE',message='error metadata unavailable',errno=None)



def need(value,message):
    if not value:raise ValueError(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf8')


def descriptor(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin,cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap,'bounded exact descriptor')
    p=Path(pin['path']);need(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),
                            'canonical regular input/Source')
    raw=p.read_bytes();need(descriptor(p,raw)==pin,'complete raw descriptor equality');return raw


def save_new(path,value):
    global _METADATA_BYTES
    raw=canonical(value)+b'\n';need(_METADATA_BYTES+len(raw)<=8388608,'aggregate outer metadata within8MiB')
    _METADATA_BYTES+=len(raw)
    fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return descriptor(path,raw)


def contains(value,wanted):
    if value==wanted:return True
    if type(value)is dict:return any(contains(v,wanted)for v in value.values())
    if type(value)is list:return any(contains(v,wanted)for v in value)
    return False


def group_absent(pgid):
    try:os.killpg(pgid,0)
    except ProcessLookupError:return True
    return False


def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='wang-encoding-calibration-candidate-v1' and
         q['status']=='COMPLETE_FINITE_CALIBRATION_CANDIDATE','finite calibration outcome')
    need(q['outputs']==outputs and len(outputs)==1,'one complete calibration output join')
    for key in('case_ids','machine_ids','diagnostic_ids'):
        ids=declaration[key]
        need(type(ids)is list and ids and all(type(v)is str and v for v in ids)and
             len(ids)==len(set(ids)),'nonempty exact unique declared '+key)
    need(q['case_ids']==declaration['case_ids'] and len(q['rows'])==len(q['case_ids']) and
         [r['id']for r in q['rows']]==q['case_ids'],'entire prospectively fixed case domain')
    need(q['machine_ids']==declaration['machine_ids'] and type(q['full_palettes_verified'])is int and q['full_palettes_verified']==len(q['machine_ids']),
         'complete machine-only palettes independently checked')
    for row in q['rows']:
        need(row['status']in('FINITE_EXACT_TILING','FINITE_EXHAUSTED')and row['independent_TM_agreement']is True,
             'complete finite decision and independent whole-TM agreement')
        need(row['graph_census_complete']is True and type(row['graph_audit_mismatches'])is int and row['graph_audit_mismatches']==0 and
             type(row['graph_states_checked'])is int and row['graph_states_checked']>0,
             'all offered states independently enumerated')
        need((row['status']=='FINITE_EXACT_TILING')is row['complete_point_certificate_verified'],
             'full exact tiling verification when a witness is found')
    need(q['diagnostic_ids']==declaration['diagnostic_ids'] and
         type(q['diagnostics_passed'])is int and q['diagnostics_passed']==len(q['diagnostic_ids']),'all declared refusal/fault/rollback diagnostics')
    need(type(q['diagnostics'])is list and [v['id']for v in q['diagnostics']]==q['diagnostic_ids'],
         'all complete actual diagnostic rows in declared order')
    for row,declared in zip(q['diagnostics'],declaration['diagnostics']):
        variants=row['variants']
        need(type(variants)is list and [v['id']for v in variants]==[v['id']for v in declared['variants']],
             'every prospectively declared diagnostic variant in exact order')
        for v,d in zip(variants,declared['variants']):
            need(v['expected']==d['expected']and v['reached']is True and v['expectation_satisfied']is True and
                 v['foreign_fault_misclassified']is False,'actual individual variant reach and expected disposition')
            need(type(v['check_calls_before'])is int and type(v['check_calls_after'])is int and
                 0<=v['check_calls_before']<=v['check_calls_after']<=400000000,
                 'strict individual variant checkpoint observations')
        need(row['status']=='PASSED'and row['reached']is True and row['expectation_satisfied']is True and
             row['foreign_fault_misclassified']is False,'actual reached diagnostic and no foreign-fault normalization')
        need(type(row['check_calls_before'])is int and type(row['check_calls_after'])is int and
             0<=row['check_calls_before']<=row['check_calls_after']<=400000000,
             'worker-owned cumulative diagnostic checkpoint observations')
    need(q['all_palettes_invariant_across_instances']is True and q['foreign_faults_preserved_exactly']is True,
         'whole palette identity and external fault ownership')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,
         'declared invocation-total checkpoint ceiling')
    for field in('compiler_calls','search_calls','verifier_calls','oracle_calls'):
        need(type(q[field])is int and q[field]>0,'strict positive actual API census')
    for field in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified',
                 'gcts_rl_advantage_established','learned_markings','trained_RL'):
        need(q[field]is False,'finite encoding calibration scope only')


def main(plan_path):
    need(sys.platform=='darwin','Darwin ru_maxrss bytes')
    p=Path(plan_path).resolve();raw=p.read_bytes();need(len(raw)<=16777216,'finite plan');plan=json.loads(raw)
    need(type(plan)is dict and set(plan)==PLAN_FIELDS and plan['schema']==PLAN_SCHEMA,'exact ten-field plan')
    need(plan['limits']==LIMITS,'original180/210/1GiB/128MiB outer limits')
    need(type(plan['sources'])is dict and set(plan['sources'])==SOURCE_ROLES and
         descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['runner'],'exact runner Source')
    checked(plan['python'],67108864)
    for value in plan['sources'].values():checked(value)
    declaration=json.loads(checked(plan['declaration']));closure=json.loads(checked(plan['runtime_closure']))
    need(declaration['schema']=='ROOT-wang-encoding-qualification-declaration-v1'and
         declaration['limits']==LIMITS and declaration['full_pipeline_qualified']is False,
         'declared full finite calibration profile')
    need(plan['inputs']==declaration['inputs'] and len(plan['inputs'])==1,'one complete literal calibration preimage')
    need(closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and
         closure['python']==plan['python']and closure['sources']==plan['sources']and
         closure['declaration']==plan['declaration'],'exact runtime closure')
    for value in closure['stdlib_files']:checked(value)
    for item in plan['inputs']:checked(item['pin'],134217728)
    subject={k:v for k,v in plan.items()if k!='authorization'}
    subject_sha=hashlib.sha256(canonical(subject)).hexdigest()
    auth=json.loads(checked(plan['authorization']))
    need(set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations',
                     'subject_sha256','review','scope'}and
         auth['schema']=='ROOT-wang-encoding-authorization-v1'and auth['author_identity']=='/root'and
         auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and
         auth['maximum_actual_invocations']==1 and auth['subject_sha256']==subject_sha,
         'exact Root max-one complete-subject grant')
    review=json.loads(checked(auth['review']))
    need(review['schema']=='wang-encoding-Source-prospective-review-v1'and
         review['reviewer_identity']=='/root/conventional_control_review'and
         review['review_passed']is True and review['source_only']is True and
         type(review['component_calls'])is int and review['component_calls']==0 and
         review['actual_execution_authorized']is False and
         review['subject']==subject and review['subject_sha256']==subject_sha,
         'exact Source/outer/prospective review by a separate author')
    for value in plan['sources'].values():need(contains(review,value),'Source pin in review')
    actual=Path(plan['actual_directory'])
    need(actual.is_absolute()and actual==actual.resolve()and actual.parent.is_dir(),'fresh canonical actual location')
    actual.mkdir(mode=0o700);work=BEGAN+180000000000;overall=BEGAN+210000000000
    consumed=save_new(actual/'CONSUMED.json',dict(schema='wang-encoding-qualification-consumed-v1',
        invocation_id=plan['invocation_id'],plan=descriptor(p,raw),subject_sha256=subject_sha,
        maximum_worker_launches=1,consumed_before_Popen=True,began_ns=BEGAN,
        work_deadline_ns=work,overall_deadline_ns=overall))
    result=dict(schema='wang-encoding-qualification-once-receipt-v1',version=VERSION,
        invocation_id=plan['invocation_id'],profile='complete-finite-wang-calibration',plan=descriptor(p,raw),
        authorization=plan['authorization'],subject_sha256=subject_sha,consumed_marker=consumed,
        began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,limits=LIMITS,
        worker_launch_attempts=0,worker_pid=None,owned_pgid=None,worker_reaped=False,
        owned_group_absent=False,regular_logs_closed=False,resource_candidate_accepted=False,
        finite_encoding_candidate=False,full_pipeline_qualified=False,scientific_acceptance=False,
        mathematical_proof_accepted=False,Native_calls=0,Model_calls=0,inverse_calls=0,
        Reader_calls=0,FOL_proof_search_calls=0,proof_checker_calls=0,
        compiler_calls=None,search_calls=None,verifier_calls=None,oracle_calls=None,errors=[],signals=[])
    process=None;reaped=False;status=None;usage=None;group_seen_absent=False;group_reappeared=False
    accepted=False;receipt_written=False;primary_error=None
    log_handles={'stdout':None,'stderr':None}
    log_observations={name:dict(opened=False,close_attempts=0,closed=False)
                      for name in('stdout','stderr')}
    cleanup=dict(attempted=False,events=[],event_limit=CLEANUP_EVENT_LIMIT,
                 poll_limit=CLEANUP_POLL_LIMIT,
                 dropped_events=0,counts={},error_summaries={},diagnostics_incomplete=False,
                 group_state='NOT_OBSERVED',completed_before_deadline=False)
    result.update(log_close_observations=log_observations,cleanup=cleanup,finalization_errors=[],
                  post_child_raw_custody=dict(checked=False,completed_before_deadline=False),
                  whole_log_custody=dict(stable=False,complete=False),
                  primary_failure=None,
                  closed_ns_scope='Early wait4/status and parent-close snapshot; raw/log/ledger/receipt work follows. Full closure requires external terminal join.')
    def information(error):
        value=error_information(error)
        if value['type']=='UNAVAILABLE':
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
        return value
    def note(operation,outcome,error=None):
        # Diagnostics cannot decide process state or interrupt an independent reap.
        try:
            key=operation+':'+outcome
            cleanup['counts'][key]=cleanup['counts'].get(key,0)+1
            event=dict(operation=operation,outcome=outcome,observed_ns=NOW(),
                       worker_pid=process.pid if process is not None else None)
            if error is not None:
                event['error']=information(error)
                summary=cleanup['error_summaries'].get(operation)
                if summary is None:
                    cleanup['error_summaries'][operation]=dict(count=1,first=event,last=event)
                else:
                    summary['count']+=1;summary['last']=event
            if len(cleanup['events'])<CLEANUP_EVENT_LIMIT:cleanup['events'].append(event)
            else:
                cleanup['events'][-1]=event;cleanup['dropped_events']+=1
        except BaseException:
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
    def owned_group_absent():
        nonlocal group_seen_absent,group_reappeared
        absent=group_absent(process.pid)
        if not absent and group_seen_absent:group_reappeared=True
        need(absent or not group_seen_absent,'owned group reappeared; no unverified signal')
        group_seen_absent=group_seen_absent or absent;return absent
    def reap():
        nonlocal reaped,status,usage
        if reaped:return True
        got,st,ru=os.wait4(process.pid,os.WNOHANG)
        if got:
            status=st;usage=ru;reaped=True;process.returncode=os.waitstatus_to_exitcode(st)
            result['worker_terminal_observed_ns']=NOW()
        return reaped
    def open_log(name):
        handle=(actual/(name+'.bin')).open('xb');log_handles[name]=handle
        log_observations[name].update(opened=True,opened_ns=NOW())
        return handle
    def close_logs(strict):
        first=None
        for name in('stdout','stderr'):
            handle=log_handles[name]
            if handle is None:continue
            if not handle.closed:
                try:log_observations[name]['close_attempts']+=1
                except BaseException as error:
                    if first is None:first=error
                    note('log_metadata_'+name,'ERROR',error)
                try:
                    handle.close()
                except BaseException as error:
                    if first is None:first=error
                    note('log_close_'+name,'ERROR',error)
                else:
                    note('log_close_'+name,'CLOSED'if handle.closed else'UNKNOWN')
                    if not handle.closed and first is None:first=ValueError('log close did not close '+name)
                    try:
                        log_observations[name].update(closed=handle.closed,closed_ns=NOW())
                    except BaseException as error:
                        if first is None:first=error
                        note('log_metadata_'+name,'ERROR',error)
            # A close that raised does not acquire a successful-close timestamp.
            try:log_observations[name]['closed']=handle.closed
            except BaseException as error:
                if first is None:first=error
                note('log_metadata_'+name,'ERROR',error)
        result['regular_logs_closed']=all(log_handles[name]is not None and
            log_handles[name].closed for name in('stdout','stderr'))
        if strict and first is not None:raise first
    def cleanup_child():
        # Every OS operation is individually guarded, with the original absolute cap.
        last_state='NOT_OBSERVED';cycles=0;complete=False;completed_ns=None
        try:cleanup.update(attempted=True,started_ns=NOW())
        except BaseException as error:note('cleanup_metadata','ERROR',error)
        def reap_step():
            if NOW()>=overall:return False
            if reaped:
                note('wait4','CACHED_REAPED');return True
            try:
                done=reap();note('wait4','REAPED'if done else'RUNNING');return done
            except BaseException as error:
                note('wait4','ERROR',error);return False
        def probe_step():
            nonlocal last_state
            if NOW()>=overall:return 'DEADLINE'
            try:
                absent=owned_group_absent()
                last_state='ABSENT'if absent else'PRESENT'
                note('group_probe',last_state)
            except PermissionError as error:
                last_state='PERMISSION_DENIED';note('group_probe',last_state,error)
            except BaseException as error:
                last_state='REAPPEARED'if group_reappeared else'ERROR'
                note('group_probe',last_state,error)
            try:cleanup['group_state']=last_state
            except BaseException as error:note('cleanup_metadata','ERROR',error)
            return last_state
        def send_step(sig,label):
            # A previous PRESENT result is never reused as signal authority.
            if NOW()>=overall or group_seen_absent or group_reappeared:return False
            if probe_step()!='PRESENT' or NOW()>=overall:return False
            try:
                os.killpg(process.pid,sig)
            except BaseException as error:
                note(label,'ERROR',error);return False
            # Sending succeeded even if its diagnostic append subsequently fails.
            try:result['signals'].append(dict(signal=sig,sent_ns=NOW()))
            except BaseException:
                try:cleanup['diagnostics_incomplete']=True
                except BaseException:pass
            note(label,'SENT');return True
        def pause():
            remaining=(overall-NOW())/1e9
            if remaining>0:
                try:time.sleep(min(.02,remaining))
                except BaseException as error:note('cleanup_sleep','ERROR',error)
        reap_step();state=probe_step()
        sent=False
        if state!='ABSENT':sent=send_step(signal.SIGTERM,'signal_TERM')
        if sent:
            until=min(overall,NOW()+1000000000)
            while NOW()<until and cycles<CLEANUP_POLL_LIMIT:
                cycles+=1
                reap_step();state=probe_step()
                if state=='ABSENT':break
                pause()
        if sent and state!='ABSENT':send_step(signal.SIGKILL,'signal_KILL')
        while NOW()<overall and cycles<CLEANUP_POLL_LIMIT:
            cycles+=1
            reap_step();state=probe_step()
            if reaped and state=='ABSENT'and not group_reappeared:
                completed_ns=NOW();complete=completed_ns<overall
                break
            pause()
        result['owned_group_absent']=last_state=='ABSENT'and not group_reappeared
        try:
            cleanup.update(ended_ns=NOW(),group_seen_absent=group_seen_absent,
                group_reappeared=group_reappeared,poll_cycles=cycles,
                completed_before_deadline=complete,completed_ns=completed_ns)
        except BaseException as error:note('cleanup_metadata','ERROR',error)
    def positive():need(NOW()<work,'complete positive result/header/bytes/known-exit before180')
    try:
        positive()
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(p)]
        environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8',
                     'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        out=open_log('stdout');err=open_log('stderr')
        result['worker_launch_attempts']=1
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
            start_new_session=True,env=environment,cwd=str(actual))
        result.update(worker_pid=process.pid,owned_pgid=process.pid,command=command)
        while not reap():
            positive()
            for name in('stdout','stderr'):
                need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'bounded worker '+name)
            time.sleep(.02)
        close_logs(True)
        need(process.returncode==0,'worker normal exit0');positive()
        need(owned_group_absent(),'owned group absent');result['owned_group_absent']=True
        wp=actual/'worker-receipt.json';wraw=wp.read_bytes();positive()
        need(len(wraw)<=4194304,'bounded complete worker receipt');w=json.loads(wraw)
        need(w['schema']=='wang-encoding-qualification-worker-receipt-v1' and
             w['invocation_id']==plan['invocation_id']and w['plan']==descriptor(p,raw) and
             w['began_ns']==BEGAN and w['work_deadline_ns']==work and
             w['overall_deadline_ns']==overall and w['positive_worker_completed_ns']<work and
             w['finite_encoding_candidate']is True,'whole exact positive worker header')
        payload=json.loads(checked(w['result'],134217728));positive()
        need(payload['schema']=='wang-encoding-qualification-result-v1' and
             payload['plan']==descriptor(p,raw)and payload['invocation_id']==plan['invocation_id'] and
             payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure'],
             'complete result subject')
        q=payload['qualification']
        validate_qualification(q,plan,declaration,w['outputs'])
        need(payload['outputs']==w['outputs']and payload['denied_events']==[]and
             all(type(payload[k])is int and payload[k]==0 for k in
                 ('Native_calls','Model_calls','inverse_calls','Reader_calls','proof_checker_calls','opaque_program_decodes')),
             'only the declared compiler/search/verifier runtime')
        for field in('compiler_calls','search_calls','verifier_calls','oracle_calls'):
            need(payload[field]==q[field],'complete actual call census')
            result[field]=q[field]
        for k in('full_pipeline_qualified','scientific_acceptance','mathematical_proof_accepted'):
            need(payload[k]is False and w[k]is False,'no mathematical or production authority')
        output_bytes=0
        for pin in w['outputs']:
            op=Path(pin['path']);need(op.parent==actual and op.name.startswith('canonical-')and op.suffix=='.json',
                                      'canonical output in owned actual directory')
            body=checked(pin,134217728);need(body.endswith(b'\n'),'complete LF output');output_bytes+=len(body);positive()
        need(output_bytes==payload['canonical_logical_bytes'] and
             w['logical_result_bytes']==output_bytes+w['result']['bytes']<=134217728 and
             w['outer_metadata_reservation']==9437184,'complete logical ledger')
        need(type(w['expanded_logical_result_bytes'])is int and
             w['expanded_logical_result_bytes']==payload['expanded_logical_result_bytes']and
             w['logical_result_bytes']<=w['expanded_logical_result_bytes']<=134217728,
             'full expanded logical packet plus result within original128MiB')
        positive();result['positive_result_read_completed_ns']=NOW()
        need(usage.ru_maxrss<=1073741824,'finite encoding worker highwater within1GiB')
        for name in('stdout','stderr'):
            need((actual/(name+'.bin')).stat().st_size<=LIMITS[name+'_bytes'],'complete bounded worker '+name)
        total=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
        need(total+9437184<=134217728,'all physical files plus outer9MiB reserves')
        checked(plan['python'],67108864)
        for pin in plan['sources'].values():checked(pin)
        checked(plan['declaration']);checked(plan['runtime_closure']);checked(plan['inputs'][0]['pin'],134217728)
        for pin in closure['stdlib_files']:checked(pin)
        for item in plan['inputs']:checked(item['pin'],134217728)
        need(NOW()<overall,'later custody/resource checks before210')
        custody_completed=NOW()
        result['post_child_raw_custody']=dict(checked=True,completed_ns=custody_completed,
            completed_before_deadline=custody_completed<overall,scope='positive complete raw closure')
        need(cleanup['diagnostics_incomplete']is False,'complete bounded log/cleanup observations')
        result.update(worker_receipt=descriptor(wp,wraw),result=w['result'],outputs=w['outputs'],
            physical_before_runner_receipt=total,conservative_physical_bytes=total+9437184,
            logical_result_bytes=w['logical_result_bytes'],expanded_logical_result_bytes=w['expanded_logical_result_bytes'],worker_peak_bytes=usage.ru_maxrss,
            memory_scope='Standalone worker peak only; no Native, not full production sum or fit.',
            resource_candidate_accepted=True,finite_encoding_candidate=True)
        accepted=True
    except BaseException as error:
        primary_error=error;accepted=False
        try:
            info=information(error);result['primary_failure']=info;result['errors'].append(info)
        except BaseException as collection_error:
            try:cleanup['diagnostics_incomplete']=True
            except BaseException:pass
            note('primary_diagnostic','ERROR',collection_error)
        if process is not None:
            try:cleanup_child()
            except BaseException as error:
                # Non-OS infrastructure/metadata failure remains a failed closure.
                note('cleanup_infrastructure','ERROR',error)
        result['resource_candidate_accepted']=False;result['finite_encoding_candidate']=False
    finally:
        def finalize_result():
            nonlocal accepted,receipt_written,primary_error
            def finalization_error(operation,error):
                nonlocal accepted,primary_error
                accepted=False
                if primary_error is None:primary_error=error
                try:
                    result['resource_candidate_accepted']=False;result['finite_encoding_candidate']=False
                    if result['primary_failure']is None:result['primary_failure']=information(primary_error)
                    result['finalization_errors'].append(dict(operation=operation,error=information(error),
                                                              observed_ns=NOW()))
                except BaseException as collection_error:
                    try:cleanup['diagnostics_incomplete']=True
                    except BaseException:pass
                    note('finalization_diagnostic','ERROR',collection_error)
            try:close_logs(True)
            except BaseException as error:finalization_error('close_logs',error)
            try:
                result['worker_reaped']=reaped
                if reaped:
                    result['worker_exit_code']=process.returncode;result['worker_wait4_status']=status
                    result['worker_wait4_usage']={k:getattr(usage,k)for k in('ru_utime','ru_stime','ru_maxrss','ru_minflt','ru_majflt')}
                result['closed_ns']=NOW()
            except BaseException as error:finalization_error('record_wait4_and_close_time',error)
            # A negative trial needs its own complete, same-window raw-custody checks.
            if not accepted and process is not None and reaped and result['owned_group_absent']and not group_reappeared:
                try:
                    need(NOW()<overall,'negative raw custody begins before210')
                    pins=[(plan['python'],67108864)]+[(v,16777216)for v in plan['sources'].values()]
                    pins.extend((v,16777216)for v in(plan['declaration'],plan['runtime_closure']))
                    pins.extend((v,16777216)for v in closure['stdlib_files'])
                    pins.extend((v['pin'],134217728)for v in plan['inputs'])
                    for pin,cap in pins:
                        need(NOW()<overall,'negative raw custody work before210');checked(pin,cap)
                        need(NOW()<overall,'negative whole preimage read before210')
                    custody_completed=NOW()
                    result['post_child_raw_custody']=dict(checked=True,completed_ns=custody_completed,
                        completed_before_deadline=custody_completed<overall,scope='negative complete raw closure')
                except BaseException as error:finalization_error('negative_raw_custody',error)
            stable=reaped and result['owned_group_absent']and not group_reappeared
            if stable:
                all_logs=True
                for name in('stdout','stderr'):
                    try:
                        need(NOW()<overall,'whole stable logs read before210')
                        f=actual/(name+'.bin')
                        need(f.is_file(),'whole stable log exists')
                        need(f.stat().st_size<=LIMITS[name+'_bytes'],'bounded final whole '+name)
                        result[name]=descriptor(f,f.read_bytes())
                        need(NOW()<overall,'whole stable log read completed before210')
                    except BaseException as error:
                        all_logs=False;finalization_error('whole_log_'+name,error)
                log_completed=NOW()
                result['whole_log_custody']=dict(stable=True,complete=all_logs,completed_ns=log_completed,
                    completed_before_deadline=all_logs and log_completed<overall,
                    scope='known wait4 exit and owned group absence; parent close is separate')
            else:
                result['whole_log_custody']=dict(stable=False,complete=False,
                    reason='worker/group closure unavailable; no whole stable descriptors claimed')
                for name in('stdout','stderr'):
                    try:
                        f=actual/(name+'.bin')
                        if f.exists():result[name+'_provisional_stat']=dict(bytes=f.stat().st_size,stable=False,complete=False)
                    except BaseException as error:finalization_error('provisional_log_stat_'+name,error)
            try:
                need(NOW()<overall,'final physical ledger before210')
                total=sum(f.stat().st_size for f in actual.iterdir()if f.is_file())
                ledger_completed=NOW()
                result['final_physical_ledger']=dict(enumeration_complete=True,before_receipt_bytes=total,
                    conservative_bytes=total+9437184,within_original_cap=total+9437184<=134217728,
                    completed_ns=ledger_completed,completed_before_deadline=ledger_completed<overall,
                    stable_writer_quiescence=stable)
            except BaseException as error:finalization_error('final_physical_ledger',error)
            try:
                save_new(actual/'runner-receipt.json',result);receipt_written=True
            except BaseException as error:
                finalization_error('save_runner_receipt',error)
                # No O_EXCL retry/overwrite. External observer owns missing-receipt failure.
                try:
                    sys.stderr.write(json.dumps(dict(schema='wang-encoding-runner-finalization-failure-v1',
                        primary=information(primary_error)if primary_error is not None else None,
                        finalization=information(error)),sort_keys=True)+'\n');sys.stderr.flush()
                except BaseException:pass
            if NOW()>=overall:
                accepted=False
                try:save_new(actual/'POST_RECEIPT_DEADLINE_FAILURE.json',dict(admitted=False))
                except BaseException:pass
        try:finalize_result()
        except BaseException as error:
            accepted=False
            if primary_error is None:primary_error=error
            try:
                result['resource_candidate_accepted']=False;result['finite_encoding_candidate']=False
                sys.stderr.write(json.dumps(dict(schema='wang-encoding-runner-finalization-failure-v1',
                    primary=information(primary_error),finalization=information(error)),
                    sort_keys=True)+'\n');sys.stderr.flush()
            except BaseException:pass
    try:
        print(json.dumps(dict(actual=str(actual),resource_candidate_accepted=result['resource_candidate_accepted'],
                             finite_encoding_candidate=result['finite_encoding_candidate'])))
    except BaseException as error:
        accepted=False
        if primary_error is None:primary_error=error
        try:
            sys.stderr.write(json.dumps(dict(schema='wang-encoding-runner-output-failure-v1',
                primary=information(primary_error),output=information(error)),sort_keys=True)+'\n')
        except BaseException:pass
    return 0 if accepted and receipt_written and NOW()<overall else 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
