"""Ordinary declaration/Source metadata author only; never imports a subject."""
from pathlib import Path
import ast
import hashlib
import json
import sys

D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
SOURCES={
'worker':Path('/private/tmp/gcts-wang-calibration-worker-20261019/qualify_wang_calibration_worker_v2.py'),
'compiler':Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py'),
'search':Path('/private/tmp/gcts-wang-search-library-20261019/wang_point_search_v2.py'),
'verifier':Path('/private/tmp/gcts-wang-search-library-20261019/wang_history_verifier_v2.py'),
'oracle':Path('/private/tmp/gcts-wang-snapshot-oracle-20261019/wang_snapshot_oracle_v1.py'),
'runner':D/'run_wang_encoding_once_v5.py','observer':D/'observe_wang_encoding_once_v1.py'}
LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,
result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,
worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
COMPONENT_LIMITS={
'compiler':dict(work=400000000,symbols=16,states=16,tiles=100000,colors=100000,cells=1024,dimension=64),
'search':dict(work=400000000,cells=1024,tiles=100000,colors=100000,candidates=1000000,data_depth=64,decisions=100000,trace_rows=100000,snapshot_items=10000000),
'verifier':dict(work=400000000,cells=1024,tiles=100000,colors=100000,symbols=16,states=16,data_depth=64,history_cells=1024),
'oracle':dict(work=400000000,points=1024,candidates=1000000,mark_points=4096,placements=1024,exclusions=1000000,trail_entries=10000000,metadata_entries=1024)}

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=p.resolve();raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    p=D/name;raw=json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n'
    with p.open('xb')as f:f.write(raw)
    return pin(p)

def main():
    sources={k:pin(v)for k,v in SOURCES.items()};inputs=json.loads((D/'cohort-inputs-v1.json').read_bytes())
    input_entries=[dict(id='complete-four-machine-680-case-55-variant-bank',pin=pin(D/'cohort-inputs-v1.json'))]
    declaration=dict(schema='ROOT-wang-encoding-qualification-declaration-v1',author_identity='/root',
      limits=LIMITS,component_limits=COMPONENT_LIMITS,checkpoint_limit=400000000,inputs=input_entries,
      case_ids=[v['id']for v in inputs['cases']],machine_ids=[v['id']for v in inputs['machines']],
      diagnostic_ids=[v['id']for v in inputs['diagnostics']],diagnostics=inputs['diagnostics'],
      exact_case_count=680,exact_diagnostic_groups=30,exact_diagnostic_variants=55,
      full_pipeline_qualified=False,actual_execution_authorized=False,
      target='Complete finite Wang encoding calibration; original whole input, no supplied answers/certificates; search first, bounded global TM reference afterward.',
      source_contract='Integer unit-center translation-only framed Wang specialization. Complete palette checked before any witness, equality across every compiler instance. No learned marking, RL, fractional/shared-positive-support or mixed-generation qualification.',
      operation_units='Root400m is a cumulative invocation-wide checkpoint ceiling, not old Arena work or a CPU-step budget. Four private per-call400m semantic work limits have different component definitions. Oracle callback cadence1024; its actual audit_work is retained and summed independently. Report actual observed per-component costs with cutoff/lowerbound/unavailable status; never compare these units as old Arena/Adapter work.',
      snapshot_lifecycle='Full detached state and reconstructed census retained through full typed/value audit. Full root/branch baselines retained through exact restoration comparison. Intermediate values may then release; every offered state has a receipt. No reconstructable full-state archive or hash-only mathematical acceptance.',
      resource_scope='Positive complete worker result/header/output read and known exit before original180s from runner Source entry; all custody, memory/log/output/ledger/group and external terminal join before210s. Observer225s is failure fallback only. Darwin worker highwater1GiB; logical and physical128MiB;9MiB outer+observer reservation. Parent metadata read cap128MiB is a fresh calibration format, different from old helper private1MiB; parent allocations not covered by worker HWM.',
      finite_fault_coverage='55 predeclared variants only. Initial callback BaseException, compiler same-class limit, selected owned work/caps, literal corruptions, persistent callback mutation and normal root restoration. No claim of every exception class, search/verifier sameclass/subclass, or all placement/rollback interruption sites.',
      no_rescue='One fresh actual maximum. Whole680+55 required. UNKNOWN/unreached diagnostic/resource failure prevents candidate admission. No consumed helper retry, smaller bank, higher caps, failed-prefix or later-custody rescue.',
      forbidden_calls=dict(Native=0,Model=0,inverse=0,Reader=0,proof_checker=0,opaque_decode=0),
      private_verifier_API=['_Budget','_palette','_machine','_configuration','_global_transition'],
      implementation_ancestry='Compiler/search/verifier share Library author; separate global replay is implementation separation. B independent snapshot census and C independent Source review do not certify all kernel soundness.',
      preserved_earlier_outcome='Original whole six-root production evidence workload remains failed at its old work ceiling; this fresh mathematical calibration neither replaces nor repairs it.')
    dp=save('declaration-v3.json',declaration)
    previous=json.loads(Path('/private/tmp/gcts-cleanup-isolation-ROOT-20261019/runtime-closure-cleanup-isolation-v1.json').read_bytes())
    stdlib={v['path']:pin(Path(v['path']))for v in previous['stdlib_files']}
    base=PYTHON.parent.parent/'lib/python3.12'
    for rel in('importlib/__init__.py','importlib/util.py','importlib/_abc.py','importlib/machinery.py'):
        pp=base/rel
        if pp.is_file():stdlib[str(pp)]=pin(pp)
    census=[]
    for role,p in SOURCES.items():
        raw=p.read_bytes();tree=ast.parse(raw)
        imported=[]
        for n in ast.walk(tree):
            if isinstance(n,ast.Import):imported.extend(x.name for x in n.names)
            elif isinstance(n,ast.ImportFrom):imported.append(n.module)
        census.append(dict(role=role,source=sources[role],direct_imports=sorted(set(imported)),AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
    closure=dict(schema='ROOT-wang-encoding-runtime-closure-v1',python=pin(PYTHON),sources=sources,declaration=dp,
      stdlib_files=sorted(stdlib.values(),key=lambda x:x['path']),direct_import_census=census,AST_parser=dict(executable=str(Path(sys.executable).resolve()),version=sys.version,policy="ast.dump(ast.parse(raw),include_attributes=False), UTF-8 sha256; informational structural census distinct from raw Source identity"),
      runtime_trust='Pinned interpreter/direct Source entry files; builtin/frozen/transitive stdlib and OS loader trusted. Exclusive owner/read-only callbacks assumed; Source/callable checks do not form a hostile-code sandbox or universal loader seal.',
      source_only=True,actual_execution_authorized=False)
    cp=save('runtime-closure-v3.json',closure)
    subject=dict(schema='ROOT-wang-encoding-qualification-plan-v1',invocation_id='complete-wang-calibration-680-v3',
      actual_directory=str(D/'actual-complete-680-v3'),python=pin(PYTHON),sources=sources,inputs=input_entries,
      limits=LIMITS,declaration=dp,runtime_closure=cp)
    digest=hashlib.sha256(canonical(subject)).hexdigest()
    ap=save('authorization-false-v3.json',dict(schema='ROOT-wang-encoding-authorization-v1',author_identity='/root',
      actual_execution_authorized=False,maximum_actual_invocations=0,subject_sha256=digest,review=None,
      scope='Source-only prospective offer; no actual permission.'))
    plan=dict(subject,authorization=ap)
    pp=save('plan-false-v3.json',plan)
    save('Source-only-offer-v3.json',dict(schema='ROOT-wang-prospective-offer-v1',subject=subject,subject_sha256=digest,
      false_plan=pp,sources=sources,component_calls=0,actual_execution_authorized=False))
    print(json.dumps(dict(plan=pp,subject_sha256=digest,actual_directory_absent=not Path(subject['actual_directory']).exists()),sort_keys=True))

if __name__=='__main__':main()
