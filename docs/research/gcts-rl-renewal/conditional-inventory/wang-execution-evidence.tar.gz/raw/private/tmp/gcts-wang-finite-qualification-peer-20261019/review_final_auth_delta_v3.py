"""Narrow ordinary metadata/raw-pin check only. No target imports or calls."""
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def rawpin(name,p):check(name,pin(p['path'])==p)
false_path=D/'plan-false-v3.json';true_path=D/'plan-authorized-v3.json'
false=json.loads(false_path.read_bytes());true=json.loads(true_path.read_bytes())
subject={k:v for k,v in true.items()if k!='authorization'}
check('authorized plan exact offered pin',pin(true_path)==dict(path=str(true_path),bytes=3305,sha256='51c512edcce6f6f52ba60868199ea2664fa0d965deda7dd1542f875cc63010de'))
check('false exact preserved pin',pin(false_path)==dict(path=str(false_path),bytes=3306,sha256='243754dc073127d0d6c2bb0f50d288e72d438b6af7da4379ff7e512765b1227d'))
check('only authorization descriptor changed',set(false)==set(true)and [k for k in false if false[k]!=true[k]]==['authorization'])
check('literal complete nine-field subject unchanged',len(subject)==9 and subject=={k:v for k,v in false.items()if k!='authorization'})
digest=hashlib.sha256(canonical(subject)).hexdigest()
check('exact current subject digest',digest=='f4645eacc562a732bfcd07bdda38a8a994ae936c43e112c40e7c4fda16ac0b3a')
rawpin('new true authorization descriptor',true['authorization'])
check('authorization exact offered pin',true['authorization']==dict(path=str(D/'authorization-true-v3.json'),bytes=745,sha256='2115ff3457ebf74a81ed7efbb1f8dad630268e30fc28f7f18cdde1987bda4056'))
auth=json.loads(Path(true['authorization']['path']).read_bytes())
check('exact seven-field Root true maxone subject authorization',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['schema']=='ROOT-wang-encoding-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==digest)
rawpin('current exact combined review',auth['review'])
check('auth binds final reviewed receipt',auth['review']==dict(path=str(C/'typed-combined-Source-prospective-review-v3-final.json'),bytes=35058,sha256='b6f31d31751ef65e364713d2475472307ba27f9e533d14d6116a873856dd815a'))
review=json.loads(Path(auth['review']['path']).read_bytes())
check('review exact runtime ABI/subject',review['schema']=='wang-encoding-Source-prospective-review-v1'and review['reviewer_identity']=='/root/conventional_control_review'and review['review_passed']is True and review['source_only']is True and type(review['component_calls'])is int and review['component_calls']==0 and review['actual_execution_authorized']is False and review['subject']==subject and review['subject_sha256']==digest and review['Sources']==subject['sources'])
adoption_path=D/'ROOT-Source-adoption-v1.json'
check('Root adoption exact offered pin',pin(adoption_path)==dict(path=str(adoption_path),bytes=4365,sha256='60edaec03276f2de5e96291571fa9b7784371acdce2afb950580271993388dc6'))
adoption=json.loads(adoption_path.read_bytes())
check('Root adoption current subject/receipt/maxone/non-authority',adoption['review']==auth['review']and adoption['subject_sha256']==digest and adoption['maximum_future_actuals']==1 and adoption['component_calls']==0 and adoption['full_pipeline_qualified']is False and adoption['mathematical_proof_accepted']is False)
check('Root adopts exact limitation/counter metadata',adoption['scopes']==review['limitations']and adoption['counter_scope']==review['counter_scope_clarification'])
for role,p in subject['sources'].items():rawpin('current unchanged whole Source '+role,p)
for key in('python','declaration','runtime_closure'):rawpin('current unchanged '+key,subject[key])
for item in subject['inputs']:rawpin('current whole original input '+item['id'],item['pin'])
closure=json.loads(Path(subject['runtime_closure']['path']).read_bytes())
for i,p in enumerate(closure['stdlib_files']):rawpin('current declared stdlib '+str(i),p)
check('unchanged whole runtime closure and declaration joins',closure['sources']==subject['sources']and closure['declaration']==subject['declaration']and closure['python']==subject['python'])
old_auth=json.loads(Path(false['authorization']['path']).read_bytes())
check('false authorization remains false/max0/empty-review',old_auth['actual_execution_authorized']is False and old_auth['maximum_actual_invocations']==0 and old_auth['review']is None and old_auth['subject_sha256']==digest)
actual=Path(subject['actual_directory']);observer=true_path.parent/(true_path.stem+'-terminal-observation')
check('fresh exact actual absent',not actual.exists())
check('fresh exact authorized observer absent',not observer.exists())
check('no consumed actual/observer marker',not(actual/'CONSUMED.json').exists()and not(observer/'CONSUMED.json').exists())
check('prior V1/V2 unexecuted paths remain absent',not(D/'actual-complete-680-v1').exists()and not(D/'actual-complete-680-v2').exists())
record=dict(schema='wang-encoding-final-grant-delta-review-v1',reviewer_identity='/root/conventional_control_review',final_grant_delta_review_passed=True,source_only=True,metadata_only=True,scientific_calls=0,component_calls=0,subject_imports=0,fixture_calls=0,simulations=0,actual_execution_authorized=False,
    subject=subject,subject_sha256=digest,false_plan=pin(false_path),authorized_plan=pin(true_path),authorization=true['authorization'],Root_scope_adoption=pin(adoption_path),combined_review=auth['review'],Sources=subject['sources'],checks=checks,check_count=len(checks),mismatch_count=0,
    freshness=dict(actual_directory=str(actual),actual_absent=True,authorized_observer_directory=str(observer),observer_absent=True,consumed_markers_absent=True,scope='Point-in-time filesystem metadata before handoff, not an OS process probe or a perpetual freshness seal.'),
    scope='Auth-descriptor-only change from exact reviewed false V3 subject. Root alone issued true/maxone. This review verifies saved metadata and does not delegate or independently issue execution authority.',
    retained_limits=dict(limits=subject['limits'],case_count=680,diagnostic_groups=30,diagnostic_variants=55,scope='One complete finite Wang mathematical calibration, all original inputs/Sources/caps, trusted exclusive owner loading and unchanged finite/fault/snapshot/counter limitations. No old retry, whole production qualification, proof/GCTS/RL/performance authority.'),
    boundary='Root must independently save/inspect its all-peer-stopped and fresh-path barrier before the one actual. No target is launched here. Reviewer tools stop after this receipt; later review is saved-data-only after authoritative terminal/cohort release.',
    preserved_negatives=[pin(C/'typed-combined-Source-prospective-review-v1-negative.json'),pin(C/'typed-combined-Source-prospective-review-v2-negative-final.json')],tools_stopped_after_handoff=True)
out=C/'typed-final-grant-delta-review-v3.json'
with out.open('xb')as f:f.write((json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(dict(receipt=pin(out),final_grant_delta_review_passed=True,checks=len(checks),mismatches=0,subject_sha256=digest,component_calls=0),sort_keys=True))
