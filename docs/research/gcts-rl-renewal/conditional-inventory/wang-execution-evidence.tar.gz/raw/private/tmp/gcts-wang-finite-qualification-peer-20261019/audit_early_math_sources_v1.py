"""Reviewer raw/AST/literal audit. Never imports or calls a subject module."""
import ast
import difflib
import hashlib
import itertools
import json
from pathlib import Path

C = Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
L = Path('/private/tmp/gcts-wang-search-library-20261019')
R = Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
checks = []

def check(name, ok):
    checks.append(dict(name=name, passed=bool(ok)))
    if not ok:
        raise ValueError(name)

def pin(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))

def verify_descriptor(name, descriptor):
    check(name, pin(descriptor['path']) == descriptor)

handoff = json.loads((L/'handoff-v2.json').read_bytes())
check('handoff exact offered pin', pin(L/'handoff-v2.json')['sha256'] == 'b9148c6c68e059bd638768325bba61197cbefb9170386a2d1d050a67bbb5a73d' and pin(L/'handoff-v2.json')['bytes'] == 2978)
for name, value in handoff.items():
    if type(value) is dict and set(value) == {'path', 'sha256', 'bytes'}:
        verify_descriptor('handoff descriptor '+name, value)
for name, descriptor in handoff['Sources'].items():
    verify_descriptor('current Source '+name, descriptor)

source_facts = {}
for role, stem, label, exception, owner in (
    ('search', 'wang_point_search', 'finite-wang-complete-point-search', 'SearchLimit', 'w'),
    ('verifier', 'wang_history_verifier', 'finite-wang-global-history-verifier', 'VerificationLimit', 'budget'),
):
    new_path = L/(stem+'_v2.py')
    old_path = L/(stem+'_v1.py')
    new, old = new_path.read_text(), old_path.read_text()
    before = 'if error._owner is not '+owner+'.owner:'
    after = 'if type(error) is not '+exception+' or error._owner is not '+owner+'.owner:'
    check(role+' one exact current owner short-circuit', new.count(after) == 1)
    check(role+' inert forward whole text', old.replace(before, after).replace("VERSION = '"+label+"-v1'", "VERSION = '"+label+"-v2'") == new)
    restored = new.replace(after, before).replace("VERSION = '"+label+"-v2'", "VERSION = '"+label+"-v1'")
    check(role+' inert reverse whole text', restored == old)
    check(role+' reverse AST exact', ast.dump(ast.parse(restored), include_attributes=False) == ast.dump(ast.parse(old), include_attributes=False))
    tree = ast.parse(new, str(new_path))
    compile(tree, str(new_path), 'exec')  # UNUSED code object; never execute.
    check(role+' no import or generator syntax', not any(isinstance(n, (ast.Import, ast.ImportFrom, ast.Yield, ast.YieldFrom, ast.Await)) for n in ast.walk(tree)))
    check(role+' no eval or exec call', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('eval', 'exec', '__import__') for n in ast.walk(tree)))
    for direction, left, right in [('forward', old, new), ('inverse', new, old)]:
        expected = ''.join(difflib.unified_diff(left.splitlines(True), right.splitlines(True), fromfile='a/source.py', tofile='b/source.py'))
        check(role+' declared '+direction+' patch exact', (L/(stem+'-'+direction+'-v2.patch')).read_text() == expected)
    source_facts[role] = dict(Source=pin(new_path), parent=pin(old_path), top_level_definitions=[n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))], imports=[], generator_nodes=0)

search = (L/'wang_point_search_v2.py').read_text()
verifier = (L/'wang_history_verifier_v2.py').read_text()
for name, fragment in {
    'full candidate cross product': "for point_index, (x, y) in enumerate(model['origins']):\n            self.dep_t[point_index] = set()\n            for tile_id, four in enumerate(model['edges']):",
    'mark-only dependencies': "self.dep_m.setdefault((mx, my), set()).add(cid)",
    'dead precedes forced precedes branch': "if dead:\n            return 'DEAD', min(dead), ()\n        if forced:",
    'generation-first branch key': 'frontier.append((0, degree, point))',
    'root full domain checks': "tuple(sorted(domain)) != self.initial_domains[point]",
    'context-local exclusion trailed': "self.trail.append(('exclude', cid, None))\n        self.excluded.add(cid)",
    'post-rollback exact scheduler check': "restored_options != frame['options']",
    'final external check before result': "w.step('successful_return_check')",
}.items():
    check('Source '+name, fragment in search)
undo = next(n for n in ast.walk(ast.parse(search)) if isinstance(n, ast.FunctionDef) and n.name == 'undo')
check('critical rollback has no external check, observer, quota step, or bound call', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ('step', 'bound', 'check', 'observe', 'notify') for n in ast.walk(undo)))
for name, fragment in {
    'full color set equality': 'if seen != expected_colors:',
    'full schema set equality': 'if observed != expected:',
    'no duplicate schema or tile omission': 'if signature not in expected or signature in observed:',
    'whole edges separate from point union': "budget.tick('raw_four_edge_checks')",
    'whole TM distinct routine': 'def _global_transition(tape, head, state, machine, budget):',
    'acceptance cannot be step-padded': 'acceptance cannot be padded with fictitious machine steps',
    'exact final accepting state': 'if state != machine[4]:',
    'final external completion check': "budget.tick('successful_completion')",
}.items():
    check('Source '+name, fragment in verifier)
global_transition = next(n for n in ast.walk(ast.parse(verifier)) if isinstance(n, ast.FunctionDef) and n.name == '_global_transition')
check('whole TM routine never calls local schema reconstruction', not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('_project_neighborhood', '_expected_palette') for n in ast.walk(global_transition)))

input_path = R/'cohort-inputs-v1.json'
input_pin = pin(input_path)
check('input exact offered pin', input_pin['sha256'] == '60ced7c79f91fd475ef88e90cace3ce5fffe15b0c8450d4b3e934d3764ffb80e' and input_pin['bytes'] == 232943)
bank = json.loads(input_path.read_bytes())
machines, cases, diagnostics = bank['machines'], bank['cases'], bank['diagnostics']
check('exact four declared machine IDs', [m['id'] for m in machines] == ['right_scan', 'left_write', 'undefined_halt', 'initial_accept'])
check('680 unique case IDs', len(cases) == len({v['id'] for v in cases}) == bank['case_count'] == 680)
check('34 words and five exact horizons stated', bank['word_count_per_machine'] == 34 and bank['word_widths'] == [1, 2, 3] and bank['exact_steps'] == [0, 1, 2, 3, 4])
check('no stored answer or witness top-level field', not any(k in bank for k in ('answers', 'certificates', 'traces', 'solutions', 'expected_results')))
check('no mathematical/runtime authority in input', bank['fixed_FOL_checker'] is False and bank['mathematical_proof_accepted'] is False and bank['actual_execution_authorized'] is False)
coverage = []
for item in machines:
    mid, machine = item['id'], item['machine']
    check(mid+' exact machine fields', set(machine) == {'alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions'})
    check(mid+' exact positive finite ID declarations', all(type(machine[k]) is int for k in ('alphabet_size', 'state_count', 'blank', 'initial', 'accepting')) and machine['alphabet_size'] == machine['state_count'] == 2)
    check(mid+' transition domains unique', len({tuple(row[:2]) for row in machine['transitions']}) == len(machine['transitions']))
    check(mid+' no accepting outgoing transition', all(row[0] != machine['accepting'] for row in machine['transitions']))
    offered = [c for c in cases if c['machine_id'] == mid]
    expected = []
    for width in (1, 2, 3):
        for symbols in itertools.product((0, 1), repeat=width):
            for head in range(width):
                word = [['head', machine['initial'], symbol] if i == head else ['plain', symbol] for i, symbol in enumerate(symbols)]
                for steps in (0, 1, 2, 3, 4):
                    expected.append((json.dumps(word, separators=(',', ':')), steps))
    actual = [(json.dumps(c['initial_word'], separators=(',', ':')), c['steps']) for c in offered]
    check(mid+' literal complete 170-case product; no simulation', len(offered) == 170 and actual == expected)
    check(mid+' every case only ID, full word and horizon', all(set(c) == {'id', 'machine_id', 'initial_word', 'steps'} for c in offered))
    coverage.append(dict(machine_id=mid, cases=len(offered), words=len({v[0] for v in actual})))
check('all three movement literals present', {row[4] for m in machines for row in m['machine']['transitions']} == {-1, 0, 1})
check('blank and nonblank write literals present', {row[3] for m in machines for row in m['machine']['transitions']} == {0, 1})
check('initial-accept empty transition declaration', machines[3]['machine']['initial'] == machines[3]['machine']['accepting'] and machines[3]['machine']['transitions'] == [])
check('30 unique diagnostic groups', len(diagnostics) == len({d['id'] for d in diagnostics}) == 30)
check('55 diagnostic variants', sum(len(d['variants']) for d in diagnostics) == 55)
check('variant IDs unique within group', all(len({v['id'] for v in d['variants']}) == len(d['variants']) for d in diagnostics))
author_tree = ast.parse((R/'build_input_cohort_v1.py').read_text())
check('input author only ordinary stdlib imports', all((isinstance(n, ast.Import) and all(a.name in {'copy', 'hashlib', 'itertools', 'json'} for a in n.names)) or (isinstance(n, ast.ImportFrom) and n.module == 'pathlib') for n in author_tree.body if isinstance(n, (ast.Import, ast.ImportFrom))))

report = dict(schema='finite-wang-early-independent-static-audit-v1', reviewer_identity='/root/conventional_control_review', source_only=True, scientific_calls=0, component_calls=0, subject_imports=0, fixture_calls=0, compiler_calls=0, search_calls=0, verifier_calls=0, simulations=0, actual_execution_authorized=False, unused_compiles=2, inert_whole_text_directions=4, checks=checks, check_count=len(checks), mismatch_count=sum(not v['passed'] for v in checks), handoff=pin(L/'handoff-v2.json'), Sources=source_facts, input=input_pin, input_author=pin(R/'build_input_cohort_v1.py'), literal_coverage=coverage, diagnostic_ids=[d['id'] for d in diagnostics], diagnostic_variants=sum(len(d['variants']) for d in diagnostics))
out = C/'early-math-Source-static-audit-v1.json'
with out.open('xb') as f:
    f.write((json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)+'\n').encode())
print(json.dumps(dict(audit=pin(out), checks=len(checks), mismatches=report['mismatch_count']), sort_keys=True))
