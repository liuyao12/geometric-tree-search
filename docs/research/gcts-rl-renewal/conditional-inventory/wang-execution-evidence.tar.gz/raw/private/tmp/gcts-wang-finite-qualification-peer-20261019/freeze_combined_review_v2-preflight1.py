"""Reviewer stdlib raw/AST/literal audit only; no subject module execution."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
W=Path('/private/tmp/gcts-wang-calibration-worker-20261019')
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def rawpin(name,p):check(name,pin(p['path'])==p)
def literal(node):
    try:return ast.literal_eval(node)
    except (ValueError,TypeError):
        if isinstance(node,ast.Call)and isinstance(node.func,ast.Name):
            if node.func.id=='dict'and not node.args and all(k.arg is not None for k in node.keywords):
                return {k.arg:literal(k.value)for k in node.keywords}
            if node.func.id=='frozenset'and len(node.args)==1 and not node.keywords:
                return frozenset(literal(node.args[0]))
        raise ValueError('not a permitted literal AST carrier')
def constants(tree):
    return {n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
offer=json.loads((D/'Source-only-offer-v2.json').read_bytes())
plan=json.loads((D/'plan-false-v2.json').read_bytes())
subject={k:v for k,v in plan.items()if k!='authorization'}
check('false V2 exact offered pin',pin(D/'plan-false-v2.json')==dict(path=str(D/'plan-false-v2.json'),bytes=3306,sha256='89fb4b76b95ef3ed13586dd3f6ff0aeecb147b19538af317300046701a133db0'))
check('ten plan/nine complete subject fields',len(plan)==10 and len(subject)==9 and set(plan)=={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization'})
check('subject exactly equals offer',subject==offer['subject'])
check('whole canonical subject SHA',hashlib.sha256(canonical(subject)).hexdigest()==offer['subject_sha256']=='7ad5ca239e61c0ddd5e8021cd363d57b69c9db4a19db467435f2fb07c828a78b')
check('seven exact Source roles',set(subject['sources'])=={'compiler','search','verifier','oracle','worker','runner','observer'}and offer['sources']==subject['sources'])
trees={};texts={}
for role,p in subject['sources'].items():
    rawpin('current whole Source '+role,p)
    text=Path(p['path']).read_text();tree=ast.parse(text,p['path'])
    compile(tree,p['path'],'exec')  # UNUSED code object only.
    trees[role]=tree;texts[role]=text
for key in('python','declaration','runtime_closure'):rawpin('current whole '+key,subject[key])
for item in subject['inputs']:rawpin('current whole input '+item['id'],item['pin'])
rawpin('false authorization',plan['authorization'])
declaration=json.loads(Path(subject['declaration']['path']).read_bytes())
closure=json.loads(Path(subject['runtime_closure']['path']).read_bytes())
inputs=json.loads(Path(subject['inputs'][0]['pin']['path']).read_bytes())
auth=json.loads(Path(plan['authorization']['path']).read_bytes())
check('false maxzero exact seven-field authorization',set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review']is None and auth['author_identity']=='/root'and auth['subject_sha256']==offer['subject_sha256'])
wc=constants(trees['worker']);rc=constants(trees['runner'])
check('worker/outer literal limits equal exact subject',literal(wc['OUTER_LIMITS'])==literal(rc['LIMITS'])==subject['limits'])
check('worker component limits exact declaration',literal(wc['COMPONENT_LIMITS'])==declaration['component_limits'])
check('400m invocation checkpoint limit literal',literal(wc['CHECKPOINT_LIMIT'])==declaration['checkpoint_limit']==400000000)
check('four private400m limits explicit',all(v['work']==400000000 for v in declaration['component_limits'].values()))
check('declaration input+limits exact',declaration['limits']==subject['limits']and declaration['inputs']==subject['inputs'])
check('unchanged original680cases/30groups55variants',declaration['case_ids']==[v['id']for v in inputs['cases']]and len(declaration['case_ids'])==680 and declaration['machine_ids']==[v['id']for v in inputs['machines']]and declaration['diagnostics']==inputs['diagnostics']and len(declaration['diagnostics'])==30 and sum(len(v['variants'])for v in declaration['diagnostics'])==55)
check('exact diagnostic group order',declaration['diagnostic_ids']==[v['id']for v in inputs['diagnostics']])
check('closure schema/current full subject joins',closure['schema']=='ROOT-wang-encoding-runtime-closure-v1'and closure['sources']==subject['sources']and closure['declaration']==subject['declaration']and closure['python']==subject['python'])
for index,p in enumerate(closure['stdlib_files']):rawpin('current declared stdlib '+str(index),p)
check('whole Source census seven unique roles',len(closure['direct_import_census'])==7 and {r['role']for r in closure['direct_import_census']}==set(subject['sources']))
for row in closure['direct_import_census']:
    role=row['role'];tree=trees[role];imports=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
        elif isinstance(n,ast.ImportFrom):imports.append(n.module)
    check(role+' exact whole AST/direct-import census',row['source']==subject['sources'][role]and row['direct_imports']==sorted(set(imports))and row['AST_sha256']==hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest())
check('worker hardcoded math Source SHA/size pins',all((subject['sources'][role]['sha256'],subject['sources'][role]['bytes'])==value for role,value in literal(wc['SOURCE_PINS']).items()))
check('worker original full input hard pin',literal(wc['INPUT_SHA'])==subject['inputs'][0]['pin']['sha256']and literal(wc['INPUT_BYTES'])==subject['inputs'][0]['pin']['bytes']==232943)
handoff=json.loads((W/'handoff-v2.json').read_bytes())
check('frozen V2 handoff exact',pin(W/'handoff-v2.json')==dict(path=str(W/'handoff-v2.json'),bytes=2793,sha256='e7dc8e8f689af810277f24538e155c17887e8a8a21341b2766f5613f588ddfae'))
for key,p in handoff.items():
    if type(p)is dict and set(p)=={'path','bytes','sha256'}:rawpin('worker handoff '+key,p)
check('handoff current four components',all(p==subject['sources'][role]for role,p in handoff['components'].items())and handoff['Source']==subject['sources']['worker'])
old_path=W/'qualify_wang_calibration_worker_v1.py';old=old_path.read_text();new=texts['worker']
start=new.index('\ndef bind_original_case(');end=new.index('\ndef calibrate(',start)
guard_block=new[start:end]
restored=new[:start]+new[end:]
restored=restored.replace("VERSION = 'complete-wang-calibration-worker-v2'","VERSION = 'complete-wang-calibration-worker-v1'")
new_palette="""palette=projected['palette']
        need(type(palette['machine'])is dict and canonical(palette['machine'])==canonical(machine),
             'complete machine-only palette exact original machine')
        audit=palette_check(s,palette)"""
restored=restored.replace(new_palette,"palette=projected['palette'];audit=palette_check(s,palette)")
restored=restored.replace('        input_binding=bind_original_case(s,instance,machine,case)\n','').replace('            input_binding=input_binding,\n','')
# The added function block owns one of the two existing top-level blank lines.
if restored!=old and restored.replace('    s.active=None\n\n\n\ndef calibrate','    s.active=None\n\n\ndef calibrate')==old:
    restored=restored.replace('    s.active=None\n\n\n\ndef calibrate','    s.active=None\n\ndef calibrate')
check('V2 reverse whole text exact V1',restored==old)
check('V2 reverse AST exact V1',ast.dump(ast.parse(restored),include_attributes=False)==ast.dump(ast.parse(old),include_attributes=False))
old_defs={n.name:ast.dump(n,include_attributes=False)for n in ast.parse(old).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_defs={n.name:ast.dump(n,include_attributes=False)for n in trees['worker'].body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
unchanged=[k for k in old_defs if k!='calibrate']
check('all retained worker definitions AST exact',all(old_defs[k]==new_defs[k]for k in unchanged))
for direction,left,right in [('forward',old,new),('inverse',new,old)]:
    expected=''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='a/source.py',tofile='b/source.py'))
    # Author patches use different pathname labels; compare all body hunks.
    path=W/('worker-v1-to-v2.patch'if direction=='forward'else'worker-v2-to-v1.patch')
    actual=path.read_text()
    check('V2 inert '+direction+' patch full body','\n'.join(actual.splitlines()[2:])=='\n'.join(expected.splitlines()[2:]))
calibrate=new[new.index('def calibrate('):new.index('\ndef main(',new.index('def calibrate('))]
check('new literal guard precedes every normal search',calibrate.count('bind_original_case(')==1 and calibrate.index('input_binding=bind_original_case')<calibrate.index('invoke_search('))
for label,fragment in {
    'full machine exact original':"canonical(instance['palette']['machine'])==canonical(machine)",
    'full word exact original':"canonical(instance['initial_word'])==canonical(word)",
    'all four original dimensions':"expected_dimensions=dict(machine_steps=steps,tape_width=width,board_width=width+2,board_height=height)",
    'exact typed dimensions':"type(wanted)is int and type(instance[name])is int and instance[name]==wanted",
    'full semantic color keys':'key=canonical(value);need(key not in color_ids',
    'complete original run/done/stop/exterior frame':"boundary=[north,east,south,west]",
    'literal whole NESW comparison':"canonical(instance['boundary_NESW'])==canonical(boundary)",
    'complete literal ordered pin comparison':"canonical(instance['fixed_background_marks'])==canonical(pins)",
    'full per-case evidence retained':'input_binding=input_binding,',
}.items():check('W1 repair '+label,fragment in new)
check('V2 input bank exactly unchanged from V1',subject['inputs']==json.loads((D/'plan-false-v1.json').read_bytes())['inputs'])
check('V2 declaration whole content unchanged',Path(subject['declaration']['path']).read_bytes()==(D/'declaration-v1.json').read_bytes())
check('six other Source descriptors unchanged',all(p==json.loads((D/'plan-false-v1.json').read_bytes())['sources'][role]for role,p in subject['sources'].items()if role!='worker'))
check('fresh V2 invocation',subject['invocation_id']=='complete-wang-calibration-680-v2')
for name,path in [('actual',Path(subject['actual_directory'])),('false observer',D/'plan-false-v2-terminal-observation'),('future authorized observer',D/'plan-authorized-v2-terminal-observation'),('authorized plan',D/'plan-authorized-v2.json')]:check('fresh absent '+name,not path.exists())
negative=json.loads((C/'typed-combined-Source-prospective-review-v1-negative.json').read_bytes())
rawpin('preserved V1 exact false plan',negative['false_plan'])
for role,p in negative['Sources'].items():rawpin('preserved V1 whole Source '+role,p)

early=json.loads((C/'typed-mathematical-components-early-Source-review-v1.json').read_bytes())
manual=list(early['manual_Source_assessment'])+[
    dict(id='W1_RESOLVED',source='worker V2 bind_original_case/calibrate',finding='The original-machine palette join and per-case complete word/exact-int time/dimensions/NESW/exterior-pin joins run before every normal search. Expected semantic colors come from the complete independently verified machine palette. Current finite input cases are not reclassified by these guards; mismatch aborts, and full evidence is retained for every completed row. V1 blocker is resolved at Source level, not claimed tested.'),
    dict(id='W2',source='worker Session.call/reference_after_search/calibrate',finding='Whole caller arguments are canonical-compared around component calls; all original compiler returns remain retained through the positive boundary. Four machine-only palettes are independently checked before any search, and every instance palette is whole-value identical to its machine palette. Reference transitions occur strictly after that case search; exhausted negatives cannot bypass the complete palette/original-case bindings.'),
    dict(id='W3',source='worker observer_for',finding='Each offered snapshot is fully compared by the separately authored oracle before its receipt is made. Full canonical census baselines, including trail length, support branch-parent and initial/ROOT_RESTORED equality. Full intermediate values may release after audit; archived state receipts are size/hash/reason/cost observations and cannot reconstruct all states.'),
    dict(id='W4',source='worker diagnostics/Session.check/call',finding='All55 variants require exact expected classes or private-owner UNKNOWN, actual reach, counters and expected disposition. Planned sentinel callbacks first run the genuine Root check; first genuine Root failure dominates expected-negative logic. Compiler same-class sentinel requires identity. Oracle module-owner classification is behind fault_gate. The frozen bank still does not qualify every class or later placement/rollback site.'),
    dict(id='W5',source='worker write_json/main; outer V5 positive path',finding='Complete canonical packet/output and result receive stored and reconstructed-expanded byte ledgers including each LF. Expanded compiler_problem references replace exact complete subtrees with a full shared palette bank retained; no dropped mathematical field. Header-expanded must equal payload expanded-canonical bytes plus full result bytes; both128MiB bounds and physical+9MiB reservation remain hard admission gates.'),
    dict(id='W6',source='worker Session.load/guard/main',finding='Only the four pinned mathematical modules load in the isolated worker after a denylist audit hook. Current Source files/origins/function-code/default identities are checked around component calls; raw stdlib/input closure is checked at intake/end. This is trusted exclusive-owner loading with an initial loader/pyc/globals/OS trust boundary, not a hostile-code or universal callable-integrity seal.'),
    dict(id='O3',source='runner V5 main/finalization; observer V1',finding='Exact nine-field subject plus one authorization descriptor; seven Sources; one create-only marker before worker Popen. Result/header/output whole reads and known exit require original180, followed by custody/resource/log/receipt/external-terminal closure before210;225 observer timeout grants no success. Cached wait4, separate permission-aware probes, freshly justified signals, no reappearance signaling, true parent closes, stable whole logs and first-error/incomplete diagnostics retain the reviewed cleanup scope.'),
    dict(id='O4',source='runner validate_qualification/main',finding='Positive joins require every680 case and each declared30group/55variant in order, strict integer counts, reached expectations, whole TM agreement, complete point verification for witnesses and all offered graph audits. Native/Model/inverse/Reader/proofchecker/opaque decode remain zero; Wang search/compiler/verifier/oracle calls are explicitly positive and are not mislabeled no component execution.'),
]
record=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/conventional_control_review',author_identities=['/root','/root/conventional_library','/root/benchmark_design'],cohort_owner_identity='/root',review_passed=True,source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,compiler_calls=0,search_calls=0,verifier_calls=0,oracle_calls=0,Native_calls=0,Model_calls=0,actual_execution_authorized=False,mathematical_proof_admitted=False,runtime_qualified=False,full_pipeline_qualified=False,
    subject=subject,subject_sha256=offer['subject_sha256'],Sources=subject['sources'],false_plan=pin(D/'plan-false-v2.json'),offer=pin(D/'Source-only-offer-v2.json'),declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],input=subject['inputs'],current_master=early['current_master'],worker_handoff=pin(W/'handoff-v2.json'),
    findings=[],mismatch_count=0,current_static_checks=checks,current_static_check_count=len(checks),unused_compiles=7,current_worker_inert_patch_directions=2,unchanged_worker_definition_AST_count=len(unchanged),
    genuine_prior_review_reuse=dict(early_component_review=pin(C/'typed-mathematical-components-early-Source-review-v1.json'),early_static_checks=early['static_check_count'],V1_combined_negative=pin(C/'typed-combined-Source-prospective-review-v1-negative.json'),scope='All seven current Sources have been raw-read across the prior component/V1/outer reviews plus current V2 delta. Unchanged Source reasoning is explicitly reused; no claim of a new independent author or fresh runtime test.'),
    resolved_findings=[dict(id='W1',parent_negative=pin(C/'typed-combined-Source-prospective-review-v1-negative.json'),resolution='Full original machine/word/exact-time/dimensions and semantic NESW/pin binding now precedes every normal search, with full row evidence. No case/budget or mathematical algorithm changed.')],
    manual_Source_assessment=manual,
    literal_input_scope=early['literal_input_review'],finite_fault_coverage_limit=early['frozen_fault_coverage_limit'],
    clock_resource_scope=dict(worker_positive_seconds=180,outer_seconds=210,observer_failure_fallback_seconds=225,worker_highwater_bytes=1073741824,stored_logical_bytes=134217728,expanded_logical_bytes=134217728,physical_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576,reservation_bytes=9437184,scope='Runner measured Source-entry epoch excludes interpreter/observer prelude. Worker HWM is not whole parent+worker aggregate RAM. Positive whole result/header/output read and known exit180; later full custody/resource/terminal210; unchanged caps, no fit or hard per-callback-latency guarantee.'),
    operation_accounting_scope='Root400m is invocation-total callback/checkpoint count, not old Arena/Adapter work or CPU seconds. Four per-call component400m definitions differ; oracle uses cadence1024 and exported audit_work is summed with unavailable calls kept explicit. Rollback attempts are monotone and not refunded; cleanup can exceed a component quota with no accepted return. Result counters have stated serialization cutoff and header counters a later pre-receipt cutoff; neither is claimed the final instruction count.',
    snapshot_retention_scope='Actual full typed/value state audits and full-value branch/root restoration pairing; intermediate state values may then release. Every offered state archives a receipt, not a reconstructable all-state archive. Complete compiler objects retained through the positive boundary. No hash-only acceptance.',
    limitations=early['limits_and_authority']+["This V2 combined PASS is Source/prospective scope only. It supersedes the early note's pending-combined-review status and V1 W1 blocker for this exact subject, while all Sources/input/callback limits remain unexecuted at this review. It does not supersede preserved historical failures, qualify the whole production workload, authorize a worker, or replace Root's exact fresh max-one grant and final auth-only delta/freshness barrier.","The worker uses five explicitly declared private verifier seams (_Budget/_palette/_machine/_configuration/_global_transition). This fixed Source coupling is reviewed; it is not a stable public independent kernel API or an independent theorem proof.","Search/verifier/worker/compiler share the Library author; B oracle is separately authored. One reviewer covers Source, outer and prospective scopes, with historical protocol/control authorship overlap disclosed. No implied multiple independent reviewer identities.","Current V5 outer expanded ABI is authoritative. Worker V1 contract's V4 outer reference is retained superseded parent context, not the binding for this current subject."],
    ancestry_disclosure=early['ancestry_disclosure'],
    final_action='Root may separately adopt these exact limited scopes and author a max-one true grant. This receipt grants no execution. Reviewer tools stop before any timed actual; saved-data review requires authoritative terminal/cohort release.',tools_stopped_after_handoff=True)
audit_out=C/'combined-v2-static-audit.json'
with audit_out.open('xb')as f:f.write((json.dumps(dict(schema='wang-combined-v2-static-audit-v1',checks=checks,check_count=len(checks),mismatch_count=0,component_calls=0,source_only=True,unused_compiles=7),sort_keys=True,indent=2)+'\n').encode())
record['current_static_audit']=pin(audit_out)
out=C/'typed-combined-Source-prospective-review-v2.json'
with out.open('xb')as f:f.write((json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(dict(receipt=pin(out),review_passed=True,current_checks=len(checks),reused_early_checks=early['static_check_count'],mismatch_count=0,subject_sha256=record['subject_sha256'],component_calls=0),sort_keys=True))
