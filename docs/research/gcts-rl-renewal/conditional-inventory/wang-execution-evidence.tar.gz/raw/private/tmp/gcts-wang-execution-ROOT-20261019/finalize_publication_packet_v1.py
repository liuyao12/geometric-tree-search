"""Freeze a passive publication/evidence snapshot after peer saved-data audit."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019');O=D/'publication-staging-v1'
def pin(p):
 r=p.read_bytes();return dict(path=str(p),bytes=len(r),sha256=hashlib.sha256(r).hexdigest())
shutil.copyfile('/private/tmp/gcts-wang-finite-qualification-peer-20261019/typed-saved-calibration-review-v2.json',O/'wang-execution-data-review.json')
roots=[D]+[Path('/private/tmp')/v for v in('gcts-wang-spacetime-library-20261019','gcts-wang-search-library-20261019','gcts-wang-snapshot-oracle-20261019','gcts-wang-calibration-worker-20261019','gcts-wang-finite-qualification-peer-20261019','gcts-fixed-fol-checker-design-20261019','gcts-fixed-fol-checker-peer-20261019','gcts-fixed-fol-design-note-20261019')]
files=set()
for root in roots:
 for p in root.rglob('*'):
  if p.is_file()and not p.is_symlink()and not any(x.startswith('publication-staging')for x in p.parts)and '__pycache__'not in p.parts:files.add(p)
for n in('serialized_kernel.py','fol_checker.tree','boundary_syntax.tree','logic.py','proof_boundary.py','tree_machine.py'):files.add(Path('/private/tmp/gcts-semantic-family-next-audit-20261018')/n)
mapping=[dict(source=pin(p),member='raw/'+str(p).lstrip('/'))for p in sorted(files)]
a=O/'wang-execution-evidence.tar.gz'
with a.open('wb')as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as z:
  with tarfile.open(fileobj=z,mode='w')as t:
   def add(n,b):
    i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
   for v in mapping:
    p=Path(v['source']['path']);assert pin(p)==v['source'];add(v['member'],p.read_bytes())
   add('PATH-MAP.json',json.dumps(mapping,sort_keys=True,indent=2).encode()+b'\n')
   add('README.txt',b'Closed negative research record. No target replay or grant authority. PATH-MAP.json maps whole raw Sources/metadata to original pins. Python binary and trusted stdlib loader not redistributed. No complete witness/state/positive result can be recovered from failure counters.\n')
manifest=dict(schema='wang-negative-publication-manifest-v2',goal_status='active',archive=pin(a),archive_raw_files=len(mapping),archive_raw_bytes=sum(v['source']['bytes']for v in mapping),files=[pin(p)for p in sorted(O.iterdir())if p.is_file()and p.name not in('wang-execution-manifest.json','wang-execution-review.json')],detached_publication_review='wang-execution-review.json excluded to avoid circular pinning; review binds this manifest',scope='Passive Source/design/closed negative only; no target invocation, complete witness, theorem, advantage or runtime component qualification.')
(O/'wang-execution-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(archive=pin(a),raw_files=len(mapping),raw_bytes=manifest['archive_raw_bytes'],manifest=pin(O/'wang-execution-manifest.json')),sort_keys=True))
