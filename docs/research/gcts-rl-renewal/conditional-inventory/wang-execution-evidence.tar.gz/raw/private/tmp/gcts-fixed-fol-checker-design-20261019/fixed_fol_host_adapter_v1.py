"""UNEXECUTED narrow adapter; logic lives only in the pinned existing checker.

The owner loads/authenticates the exact module and guards its callables/code.
This host boundary is not a single-tape machine or a fixed Wang palette.
"""
VERSION = 'fixed-fol-existing-host-checker-adapter-v1'
PROTOCOL = 'gcts-fol-1'
CHECKER_SOURCE = {
    'path':'/private/tmp/gcts-semantic-family-next-audit-20261018/serialized_kernel.py',
    'bytes':13977,
    'sha256':'045cdba67ead9f12e91c702736fa09a5ae4d9796aea86831d65b245031a261f4'}


def check_certificate(payload, *, checker_module, expected_problem_sha256,
                      max_work, max_bytes, check, source_guard):
    """A future granted owner may delegate one complete immutable byte input.

The external expected hash binds protocol/theory/target; never take it from
the proposed proof. The original module.check creates a fresh Checker each
time, so a prior request's block registry cannot leak into this request.
Every parser/substitution/rule/induction decision remains in that module.
"""
    if type(payload) is not bytes:
        raise ValueError('complete immutable certificate bytes required')
    if (type(expected_problem_sha256) is not str or len(expected_problem_sha256)!=64
            or any(c not in '0123456789abcdef' for c in expected_problem_sha256)):
        raise ValueError('external frozen problem digest required')
    if (type(max_work) is not int or max_work<=0 or
            type(max_bytes) is not int or max_bytes<=0):
        raise ValueError('explicit positive exact-int budgets required')
    if not callable(check) or not callable(source_guard):
        raise ValueError('owner resource/Source guards required')
    source_guard();check()
    if (checker_module.PROTOCOL!=PROTOCOL or
            checker_module.__file__!=CHECKER_SOURCE['path'] or
            not callable(checker_module.check)):
        raise ValueError('exact authenticated current host checker required')
    # Authentication is the owner's whole-Source/code-binding obligation,
    # not a claim that matching this path/protocol alone establishes identity.
    result=checker_module.check(payload,max_work=max_work,max_bytes=max_bytes,
        expected_problem_sha256=expected_problem_sha256)
    source_guard();check()
    if type(result) is not dict or result.get('status') not in (
            'accepted','rejected','unknown_resource_budget'):
        raise ValueError('original checker disposition required')
    accepted=result['status']=='accepted'
    if accepted and result.get('problem_sha256')!=expected_problem_sha256:
        raise ValueError('accepted exact externally pinned problem join')
    return dict(schema='fixed-fol-host-delegation-candidate-v1',
        version=VERSION,checker_source=dict(CHECKER_SOURCE),result=result,
        host_certificate_accepted=accepted,
        scope='Certificate validity relative to exactly declared closed axioms and enabled schema; not proof discovery or truth of an unpinned theory.',
        Native_accepted=False,TM_correspondence_established=False,
        fixed_Wang_palette_established=False,full_pipeline_qualified=False,
        actual_execution_authorized=False)
