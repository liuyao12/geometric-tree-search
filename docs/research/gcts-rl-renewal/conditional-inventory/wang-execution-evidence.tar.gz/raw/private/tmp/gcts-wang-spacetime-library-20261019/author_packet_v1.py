"""Raw/AST/ordinary metadata authoring only. Never loads or calls compiler."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

DIRECTORY = Path('/private/tmp/gcts-wang-spacetime-library-20261019')
PUBLISHER = Path('/private/tmp/gcts-split-controls-publish-20261015')
SOURCE = DIRECTORY / 'wang_spacetime_compiler_v1.py'


def pin(path):
    raw = Path(path).read_bytes()
    return dict(path=str(Path(path).resolve()), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def save(name, value):
    path = DIRECTORY / name
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(raw)
    return pin(path)


def main():
    checks = []

    def need(test, name):
        if not test:
            raise ValueError(name)
        checks.append(dict(name=name, passed=True))

    raw = SOURCE.read_bytes()
    tree = ast.parse(raw, filename=str(SOURCE))
    compile(tree, str(SOURCE), 'exec')  # Unused code object: no module evaluation.
    definitions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    need(not any(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(tree)), 'compiler has no imports')
    need(not any(isinstance(n, (ast.Yield, ast.YieldFrom, ast.AsyncFunctionDef, ast.Await)) for n in ast.walk(tree)), 'nongenerator direct callback and compiler paths')
    need(not any(isinstance(n, ast.ExceptHandler) for n in ast.walk(tree)), 'no callback exception conversion/catch')
    need(all(not isinstance(n, ast.Expr) or isinstance(n.value, ast.Constant) for n in tree.body), 'no top-level subject invocation')
    expected = {'DeclarationError', 'CompileLimit', '_Work', '_integer', '_machine', '_machine_record',
                '_configuration', '_local_update', '_palette', 'compile_palette', 'compile_finite_problem'}
    need(set(definitions) == expected, 'exact finite compiler/API definitions')
    source_text = raw.decode()
    for text, name in [
        ("if q == accepting:", 'accepting-state outgoing transitions rejected'),
        ("if (q, read) in table:", 'deterministic duplicate domains rejected'),
        ("if len(heads) > 1:", 'multihead neighborhood unavailable'),
        ("if transition is None:", 'halting neighborhood unavailable'),
        ("(move == -1 and left == WALL) or (move == 1 and right == WALL)", 'head-centered wall escape excluded'),
        ("return ('head', next_q, center[1])", 'incoming head preserves destination symbol'),
        ("('pair', center, right), ('cell', output), ('pair', left, center)", 'overlapping-pair step schema'),
        ("('seen', 1), ('stop',), ('seen', 0)", 'accepting collector exact zero-to-one'),
        ("('side', 'left', 'done'), ('exterior', 'left')", 'left collector frame exact colors'),
        ("('side', 'right', 'done'), ('seen', 1)", 'right collector frame exact colors'),
        ("palette = _palette(owned, work)", 'full machine-only palette retained for every instance'),
        ("if heads != 1:", 'complete initial word has one head'),
        ("if cell[1] != initial:", 'initial head in declared initial state'),
        ("type(steps) is not int or steps < 0", 'exact nonnegative time, bool rejected'),
        ("_configuration(initial_word, owned, work) != copied", 'typed full initial carrier revalidation'),
        ("admissible_origins=required.copy()", 'finite origin list equals all required centers'),
        ("all_root_generations=0", 'all finite point obligations activate at generation zero'),
        ("mathematical_authority=False, executed_source_qualified=False", 'candidate labels have no authority'),
    ]:
        need(text in source_text, name)
    master = subprocess.run(['/usr/bin/git', '-C', str(PUBLISHER), 'show',
                             'HEAD:docs/basic-tiling-algorithm.md'], check=True, capture_output=True).stdout
    need(len(master) == 36240 and hashlib.sha256(master).hexdigest() ==
         'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4', 'fully read current master exact raw pin')
    master_path = DIRECTORY / 'basic-tiling-algorithm-current.md'
    with master_path.open('xb') as stream:
        stream.write(master)
    head = subprocess.run(['/usr/bin/git', '-C', str(PUBLISHER), 'rev-parse', 'HEAD'],
                          check=True, capture_output=True).stdout.decode().strip()
    source_lines = {name: dict(start=node.lineno, end=node.end_lineno) for name, node in definitions.items()}
    common = dict(author_identity='/root/conventional_library', cohort_owner_identity='/root', source_only=True,
                  scientific_calls=0, compiler_calls=0, fixture_calls=0, subject_imports=0,
                  mathematical_authority=False, scientific_acceptance=False,
                  actual_execution_authorized=False, runtime_qualified=False)
    primary = save('primary-source-check-v1.json', dict(schema='wang-spacetime-primary-source-check-v1', **common,
        references=[
            dict(title='Jeandel and Vanier, Slopes of Tilings', url='https://www.lacl.fr/pvanier/rech/preprint-slopes.pdf',
                 checked='Full author-hosted paper text via web; Section2.3/Figure3, PDFpage4.',
                 supported_scope='The authors present a finite Wang computation rectangle with input and accepting/halting boundary conditions.',
                 limitation='Not the exact pair/frame schemas or Python Source here; our construction has its own informal argument. No local primary PDF raw-byte pin is claimed.'),
            dict(title='Wang, Proving Theorems by Pattern Recognition II (1961)',
                 url='https://www.nokia.com/bell-labs/publications-and-media/publications/proving-theorems-by-pattern-recognition-ii/',
                 checked='Original publisher title/date and original abstract excerpt.',
                 supported_scope='Historical machine theorem-proving/predicate-calculus context only.',
                 limitation='Not cited as a checked implementation or complete FOL palette; full paper was not fetched here.')],
        construction_status='Original explicit specialization of the finite computation-tableau method, informally argued and unexecuted. No claim from aperiodicity.'))
    example = save('illustrative-machine-v1.json', dict(schema='literal-illustrative-machine-not-a-result-v1', **common,
        machine=dict(alphabet_size=2, state_count=3, blank=0, initial=0, accepting=2,
                     transitions=[[0, 0, 2, 0, 0], [0, 1, 1, 0, 1], [1, 0, 2, 0, -1]]),
        interpretation='Illustrative symbols0blank/1mark; states0initial/2accepting. Three literal rules exhibit stationary/right/left movement. No run is supplied or evaluated.',
        literal_tile_examples=[
            dict(kind='step schema', old_triple=[['plain', 0], ['head', 0, 1], ['plain', 0]],
                 NESW=[['cell', ['head', 0, 1]], ['pair', ['head', 0, 1], ['plain', 0]],
                       ['cell', ['plain', 0]], ['pair', ['plain', 0], ['head', 0, 1]]]),
            dict(kind='accept collector schema', NESW=[['cell', ['head', 2, 0]], ['seen', 1], ['stop'], ['seen', 0]])],
        limitation='Manually transcribed symbolic schema instances, not a compiler output, tiling, target theorem, proof route, or execution test.'))
    api = save('API-v1.json', dict(schema='finite-framed-wang-compiler-API-v1', **common,
        Source=pin(SOURCE), VERSION='finite-framed-wang-spacetime-compiler-v1',
        public_entries=['compile_palette(machine, *, check, limits)',
                        'compile_finite_problem(machine, initial_word, steps, *, check, limits)'],
        machine_fields=['alphabet_size', 'state_count', 'blank', 'initial', 'accepting', 'transitions'],
        transitions='Literal exactlist rows [q,s,q_next,s_write,d] with exactint IDs; d in {-1,0,1}; unique domain; no accepting outgoing transition.',
        initial_word="Exactlist of exacttuple ('plain',symbol) or ('head',state,symbol); exactly one head with declared initialstate. Complete word including padding is pinned.",
        limits=['work', 'symbols', 'states', 'tiles', 'colors', 'cells', 'dimension'],
        ownership='Exclusive input ownership; callbacks read-only. Current typed declarations revalidated before return. No mutation/caching/theorem authority.',
        callbacks='Direct check calls propagate exact exception object; no catches/generators. Cooperative checks are not preemption or elapsed-time guarantees.',
        results='Only PALETTE_CANDIDATE or FINITE_PROBLEM_CANDIDATE complete ordinary records; not acceptance/tiling/native_accepted.',
        failures='DeclarationError or own CompileLimit(reason,attempted_work), no returned partial palette/problem; external exception unchanged.',
        pins='Future caller must freeze compiler+machine+compiled palette+instance+master/engine epochs and independently verify them. No grant or runtime contract is supplied here.',
        source_lines=source_lines))
    contract = save('Source-contract-v1.json', dict(schema='finite-framed-wang-Source-contract-v1', **common,
        Source=pin(SOURCE), API=api, specification=pin(DIRECTORY/'encoding-spec-v1.html'), primary_sources=primary,
        master=pin(master_path), publisher_commit=head,
        published_baseline=pin(PUBLISHER/'docs/research/gcts-rl-renewal/conditional-inventory/universal-wang.html'),
        theorem='For valid pinned C0 widthW and exactH>=0, a (W+2) by (H+1) framed tiling exists iff the machine has an in-strip H-step run from C0 to its accepting state. Informal proof in HTML, not machine checked.',
        palette_scope='Machine-only uniform finite compiler; same full palette for every initialword/horizon. For future theorem instances one actual full checker machine/palette must be frozen once, not changed per theorem.',
        point_semantics='Integer centers at2Z2; t(center)=1; four edge midpoint marks, exactint colors including0; all board/frame centers Q and origins; no other transforms. Boundary backgroundm only, no exterior t contribution.',
        conformance='Representation correspondence argued only. No current GCTS candidate graph/scheduler/rollback/verifier implementation is changed or qualified. Future complete alltile-ID×allorigins enumeration, all markdependencies and globalDEAD/FORCED/earliestgeneration/rollback required.',
        closed_loopholes=['pinned complete initialoneheadword', 'headcenter wallescape unavailable', 'reject/accept halts cannot step',
                          'no headless acceptance', 'collector has exact0to1 once', 'no postcollector row',
                          'no erasing/filler/rotation/wildcard tiles', 'all frame/cell targetpoints required'],
        gaps=['Compiler never invoked, no serialized generated palette.', 'No full FOL kernel/table/codec or checker-machine correspondence.',
              'No fixed universal checker palette, unknown-certificate single-board grammar implementation or lemma macrointerface.',
              'No independent compiler checker, point search/verifier/runtime qualification, cost/learning/control experiment.',
              'Finite accepting-history construction is not seedless-plane/aperiodicity/selfassembly theorem.'],
        ancestry='Library authored prior point/Model/search/cold/evidence/Arena/composer components. This is new author Source/spec, not an independent certification of own Sources or the published prose.',
        production_status='INACTIVE_SOURCE_ONLY_UNEXECUTED_NO_GRANT'))
    audit = save('author-static-audit-v1.json', dict(schema='wang-spacetime-author-static-audit-v1', **common,
        Source=pin(SOURCE), checks=checks, check_count=len(checks), unused_compiles=1,
        source_lines=source_lines, no_subject_execution=True,
        limitations='Raw pattern/AST confirmations plus unused compile are author checks, not runtime/independent correctness proof or exhaustive mathematical verification. No palette/count/result was obtained by execution.'))
    handoff = save('handoff-v1.json', dict(schema='wang-spacetime-Source-handoff-v1', **common,
        Source=pin(SOURCE), API=api, Source_contract=contract, specification=pin(DIRECTORY/'encoding-spec-v1.html'),
        literal_illustration=example, primary_source_check=primary, author_static_audit=audit,
        author_Source=pin(__file__), current_master=pin(master_path),
        status='INACTIVE_UNEXECUTED_SOURCE_ONLY_NO_GRANT', tools_stopped_after_handoff=True))
    print(json.dumps(dict(Source=pin(SOURCE), handoff=handoff, checks=len(checks), compiler_calls=0), sort_keys=True))


if __name__ == '__main__':
    main()
