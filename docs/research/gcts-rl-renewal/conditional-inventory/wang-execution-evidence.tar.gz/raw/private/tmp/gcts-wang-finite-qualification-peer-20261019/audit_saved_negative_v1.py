"""Saved ordinary JSON/raw-byte audit only; no subject imports, calls or probes."""
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
A=D/'actual-complete-680-v3';O=D/'plan-authorized-v3-terminal-observation'
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def rawpin(name,p):check(name,pin(p['path'])==p)
plan_path=D/'plan-authorized-v3.json';plan=load(plan_path);pp=pin(plan_path)
delta=load(C/'typed-final-grant-delta-review-v3.json')
subject={k:v for k,v in plan.items()if k!='authorization'}
check('authorized plan exact reviewed delta',pp==delta['authorized_plan']and subject==delta['subject']and hashlib.sha256(canonical(subject)).hexdigest()==delta['subject_sha256'])
rawpin('combined Source/prospective review',delta['combined_review'])
rawpin('Root scope adoption',delta['Root_scope_adoption'])
rawpin('Root true maxone authorization',plan['authorization'])
auth=load(plan['authorization']['path'])
check('true grant exact current reviewed subject/maxone',auth['subject_sha256']==delta['subject_sha256']and auth['review']==delta['combined_review']and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1)
for role,p in plan['sources'].items():rawpin('current whole Source '+role,p)
for key in('python','declaration','runtime_closure'):rawpin('current '+key,plan[key])
for row in plan['inputs']:rawpin('complete original input '+row['id'],row['pin'])
runtime=load(plan['runtime_closure']['path'])
for i,p in enumerate(runtime['stdlib_files']):rawpin('current declared stdlib '+str(i),p)
check('runtime full current Source/Python/declaration binding',runtime['sources']==plan['sources']and runtime['declaration']==plan['declaration']and runtime['python']==plan['python'])
check('exact six actual files/no successful or partial packet',{p.name for p in A.iterdir()}=={'CONSUMED.json','WORKER_CONSUMED.json','worker-failure.json','runner-receipt.json','stdout.bin','stderr.bin'})
check('exact four observer files',{p.name for p in O.iterdir()}=={'CONSUMED.json','terminal.json','stdout.bin','stderr.bin'})
inventory=dict(actual=[pin(p)for p in sorted(A.iterdir())],observer=[pin(p)for p in sorted(O.iterdir())])
r=load(A/'runner-receipt.json');f=load(A/'worker-failure.json');t=load(O/'terminal.json')
consumed=load(A/'CONSUMED.json');worker=load(A/'WORKER_CONSUMED.json');obs=load(O/'CONSUMED.json')
root_path=D/'ROOT-calibration-closure-v1.json';root=load(root_path)
check('Root closure exact offered bytes',pin(root_path)==dict(path=str(root_path),bytes=6706,sha256='48825464a341493b311e1d7a5c081b7d911e86828dda2014fe589a5d4d19b4e2'))
check('Root literal failure projection exact full JSON',root['failure']==f)
rawpin('Root runner projection pin',root['runner']);rawpin('Root terminal projection pin',root['terminal'])
check('all six saved plan bindings',all(v['plan']==pp for v in(r,f,t,consumed,worker,obs)))
check('single consumed maxone marker before worker Popen',consumed['maximum_worker_launches']==1 and consumed['consumed_before_Popen']is True and consumed['invocation_id']==plan['invocation_id']and consumed['subject_sha256']==delta['subject_sha256'])
rawpin('runner consumed marker full pin',r['consumed_marker'])
check('one worker and one observer launch',r['worker_launch_attempts']==worker['maximum_invocations']==obs['maximum_runner_launches']==1)
check('exact source-entry work/overall epochs',consumed['began_ns']==r['began_ns']and consumed['work_deadline_ns']==r['work_deadline_ns']==r['began_ns']+180000000000 and consumed['overall_deadline_ns']==r['overall_deadline_ns']==r['began_ns']+210000000000)
check('PID/parent/owned-group joins',worker['pid']==r['worker_pid']==r['owned_pgid']==59895 and worker['ppid']==t['runner_pid']==59894)
check('observer/worker start epoch ordering',obs['observer_started_ns']==t['observer_started_ns']<=r['began_ns']<=worker['worker_entry_ns']<r['work_deadline_ns'])
check('exact worker command',r['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(plan_path)])
check('exact observer runner command',t['command']==[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(plan_path)])
check('known negative worker and runner exits',r['worker_wait4_status']==15 and r['worker_exit_code']==-15 and t['runner_exit_code']==2)
check('saved cleanup closure true/no reappearance/errors',r['worker_reaped']is True and r['owned_group_absent']is True and r['regular_logs_closed']is True and r['cleanup']['completed_before_deadline']is True and r['cleanup']['diagnostics_incomplete']is False and r['cleanup']['group_state']=='ABSENT'and r['cleanup']['group_seen_absent']is True and r['cleanup']['group_reappeared']is False and r['cleanup']['error_summaries']=={}and r['finalization_errors']==[])
check('all cleanup events bounded',len(r['cleanup']['events'])<=r['cleanup']['event_limit']==32 and r['cleanup']['dropped_events']==0 and r['cleanup']['poll_cycles']<=r['cleanup']['poll_limit']==2048)
check('one TERM/no KILL',len(r['signals'])==1 and r['signals'][0]['signal']==15 and r['cleanup']['counts']['signal_TERM:SENT']==1 and 'signal_KILL:SENT'not in r['cleanup']['counts'])
events=r['cleanup']['events'];term_index=next(i for i,e in enumerate(events)if e['operation']=='signal_TERM')
check('saved immediate fresh PRESENT before TERM',events[term_index-1]['operation']=='group_probe'and events[term_index-1]['outcome']=='PRESENT'and events[term_index-1]['observed_ns']<=events[term_index]['observed_ns'])
check('no saved ABSENT before signal',not any(e['operation']=='group_probe'and e['outcome']=='ABSENT'for e in events[:term_index]))
check('known late worker terminal after180 but before210',r['work_deadline_ns']<=r['worker_terminal_observed_ns']<r['overall_deadline_ns'])
check('exact parent primary deadline retained',r['primary_failure']=={'errno':None,'message':'complete positive result/header/bytes/known-exit before180','type':'ValueError'}and r['errors'][0]==r['primary_failure'])
check('exact worker selfdeadline retained separately',f['first_available_fault']=={'message':'original absolute180s work deadline','type':'PolicyFailure'}and f['status']=='FAILED_OR_UNFINISHED'and f['stage']=='COMPLETE_CASE')
check('parent counters unavailable not zero-filled',all(r[k]is None for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')))
for name in('stdout','stderr'):
    rawpin('whole stable '+name,r[name])
    check('parent actually closed '+name,r['log_close_observations'][name]['opened']is True and r['log_close_observations'][name]['closed']is True and r['log_close_observations'][name]['close_attempts']==1)
    check('bounded '+name,r[name]['bytes']<=plan['limits'][name+'_bytes'])
check('stable whole-log custody before210',r['whole_log_custody']['stable']is True and r['whole_log_custody']['complete']is True and r['whole_log_custody']['completed_before_deadline']is True and r['whole_log_custody']['completed_ns']<r['overall_deadline_ns'])
check('negative complete raw custody before210',r['post_child_raw_custody']['checked']is True and r['post_child_raw_custody']['completed_before_deadline']is True and r['post_child_raw_custody']['completed_ns']<r['overall_deadline_ns'])
before=sum(p.stat().st_size for p in A.iterdir()if p.name!='runner-receipt.json')
ledger=r['final_physical_ledger']
check('whole exact before-receipt ledger',ledger['enumeration_complete']is True and ledger['stable_writer_quiescence']is True and ledger['before_receipt_bytes']==before==3915)
check('unchanged9MiB reservation ledger before210',ledger['conservative_bytes']==before+9437184==root['physical_with_reserve_bytes']==9441099 and ledger['conservative_bytes']<=plan['limits']['result_bytes']and ledger['within_original_cap']is True and ledger['completed_before_deadline']is True and ledger['completed_ns']<r['overall_deadline_ns'])
check('outer/observer metadata actual bytes fit reserves',pin(A/'runner-receipt.json')['bytes']<=8388608 and sum(p.stat().st_size for p in O.iterdir())<=1048576)
elapsed_ns=t['terminal_observed_ns']-r['began_ns'];observer_ns=t['terminal_observed_ns']-t['observer_started_ns']
check('exact terminal clock math',elapsed_ns==180084231000 and elapsed_ns/1e9==t['runner_clock_elapsed_seconds']==root['elapsed_seconds']==180.084231 and observer_ns/1e9==t['observed_instrument_elapsed_seconds']==180.116255291)
check('negative external terminal before210',r['work_deadline_ns']<=t['terminal_observed_ns']<r['overall_deadline_ns']and t['terminal_gate_passed']is False and t['ROOT_resource_accepted']is False)
rawpin('terminal full runner receipt pin',t['runner_receipt'])
check('worker HWM exact known diagnostic bytes',type(r['worker_wait4_usage']['ru_maxrss'])is int and r['worker_wait4_usage']['ru_maxrss']==root['worker_peak_bytes']==56262656)
check('Root negative aggregate/status projections',root['plan']==pp and root['worker_exit_code']==r['worker_exit_code']and root['worker_reaped']==r['worker_reaped']and root['owned_group_absent']==r['owned_group_absent']and root['primary_failure']==r['primary_failure']and root['whole_frozen_calibration_completed']is False and root['root_resource_candidate_accepted']is False and root['stored_logical_bytes']is None and root['expanded_logical_bytes']is None)
inputs=load(plan['inputs'][0]['pin']['path']);ids=[v['id']for v in inputs['cases']]
check('63 exact original prefix IDs',len(f['completed_case_ids'])==63 and f['completed_case_ids']==ids[:63])
check('active64th originalcase',f['active_row']==ids[63]=='right_scan-w3-s000-p2-h3')
check('no recorded qualification diagnostics/output',f['diagnostic_prefix']==[]and f['outputs']==[])
started=f['call_started'];completed=f['call_completed'];raised=f['call_raised']
for key,value in started.items():
    check('strict started counter '+key,type(value)is int and value>=0)
    check('started/completed/raised balance '+key,value==completed.get(key,0)+raised.get(key,0))
check('64 compiler finite returns and4 full palette returns',started['compiler.compile_finite_problem']==completed['compiler.compile_finite_problem']==64 and started['compiler.compile_palette']==completed['compiler.compile_palette']==4)
check('64search starts63returns1raised',started['search.search']==64 and completed['search.search']==63 and raised['search.search']==1)
check('8930 completed oracle calls at cutoff',started['oracle.audit_snapshot']==completed['oracle.audit_snapshot']==8930)
check('9 verifier public returns at cutoff',started['verifier.verify']==completed['verifier.verify']==9)
for role,key in [('compiler','compiler_calls'),('search','search_calls'),('verifier','verifier_calls'),('oracle','oracle_calls')]:check('actual instrumented '+role+' prefix sum',f[key]==sum(n for k,n in started.items()if k.startswith(role+'.')))
check('recorded Root checkpoint cutoff within budget',type(f['root_check_calls'])is int and f['root_check_calls']==83174413<400000000)
check('absent success/result/expanded/witness data not zero',all(not(A/name).exists()for name in('result.json','worker-receipt.json','canonical-wang-calibration.json'))and 'oracle_work'not in f and 'rows'not in f)
for record_name,record in [('worker',f),('runner',r),('terminal',t)]:
    check(record_name+' explicit no positive authority',record['full_pipeline_qualified']is False and record['scientific_acceptance']is False and record['mathematical_proof_accepted']is False)
check('worker and runner no finite admission',f['finite_encoding_candidate']is False and r['finite_encoding_candidate']is False and r['resource_candidate_accepted']is False)
check('forbidden component counters retained zero',all(type(f[k])is int and f[k]==0 for k in('Native_calls','Model_calls','Reader_calls','inverse_calls','proof_checker_calls')))
release1=D/'ROOT-actual-retirement-release-v1.json';release2=D/'ROOT-actual-retirement-release-v2.json'
release=load(release2)
check('retired one actual no remaining use',release['actual_invocations']==1 and release['remaining_actual_invocations']==0 and release['consumed_grant_retired']is True and release['positive_result_accepted']is False)
check('administrative postterminal release scope',release['released_ns']>t['terminal_observed_ns']and release['clock']['executable']==plan['python']['path']and 'not an original210s custody observation' in release['clock']['scope'])
check('release preserves prior unattributed timestamp',release['supersedes_administrative_clock_only']['path']==str(release1)and release['supersedes_administrative_clock_only']['bytes']==pin(release1)['bytes']and release['supersedes_administrative_clock_only']['sha256']==pin(release1)['sha256'])
audit_path=C/'saved-negative-static-audit-v1.json'
audit=dict(schema='wang-saved-negative-static-audit-v1',saved_data_only=True,scientific_calls=0,component_calls=0,subject_imports=0,process_probes=0,replays=0,checks=checks,check_count=len(checks),mismatch_count=0,actual_inventory=inventory,root_closure=pin(root_path),release_v1=pin(release1),release_v2=pin(release2),Sources=plan['sources'],input=plan['inputs'])
with audit_path.open('xb')as out:out.write((json.dumps(audit,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
record=dict(schema='finite-wang-saved-negative-evidence-review-v1',reviewer_identity='/root/conventional_control_review',saved_review_passed=True,saved_data_only=True,scientific_calls=0,component_calls=0,subject_imports=0,simulations=0,replays=0,process_probes=0,opaque_decodes=0,actual_execution_authorized=False,mathematical_proof_admitted=False,finite_calibration_completed=False,full_pipeline_qualified=False,current_source_qualification=False,
    status='NEGATIVE_DEADLINE_RUN; SAVED_EVIDENCE_AND_CUSTODY_CONSISTENT',mismatch_count=0,check_count=len(checks),audit=pin(audit_path),authorized_plan=pp,subject_sha256=delta['subject_sha256'],grant=plan['authorization'],combined_Source_review=delta['combined_review'],final_grant_delta_review=pin(C/'typed-final-grant-delta-review-v3.json'),root_closure=pin(root_path),runner=pin(A/'runner-receipt.json'),worker_failure=pin(A/'worker-failure.json'),terminal=pin(O/'terminal.json'),retirement_release=pin(release2),Sources=plan['sources'],input=plan['inputs'],limits=plan['limits'],
    outcome=dict(actuals=1,worker_pid=59895,runner_pid=59894,worker_wait4_status=15,worker_exit_code=-15,runner_exit_code=2,parent_primary=r['primary_failure'],worker_reported_fault=f['first_available_fault'],TERM_sent=1,KILL_sent=0,worker_reaped=True,saved_group_absent=True,parent_logs_closed=True,raw_log_ledger_custody_before210=True,terminal_elapsed_from_runner_epoch_seconds=elapsed_ns/1e9,observer_main_seconds=observer_ns/1e9,worker_peak_bytes=56262656,worker_peak_MiB=53.65625,peak_scope='Known Darwin standalone worker lifetime highwater, excluding parent/observer. Below numerical cap is diagnostic; deadline failure means no resource admission.',physical_with_reservation_bytes=9441099,stored_logical_bytes=None,expanded_logical_bytes=None,positive_header_present=False,result_present=False,full_packet_present=False),
    recorded_prefix=dict(complete_case_ID_count=63,active_case=f['active_row'],case_count_required=680,not_completed=617,normal_cases_not_started=616,diagnostic_group_records=0,diagnostic_variant_records=0,full_palette_compile_returns=4,compiler_finite_returns=64,search_starts=64,search_returns=63,search_raised=1,oracle_audit_returns=8930,public_verifier_returns=9,root_checkpoint_cutoff=83174413,call_started=started,call_completed=completed,call_raised=raised,instrumented_role_starts={k:f[k]for k in('compiler_calls','search_calls','verifier_calls','oracle_calls')},scope='Worker-reported detached failure prefix only.63 IDs and recorded call maps are not resource-admitted cases, accepted proofs or all680 outcomes. Full per-case search results, witness packets and per-state receipts were transient and are not in this retained failure packet.'),
    counter_and_timing_limits=['Counter maps are recorded prefixes at failure serialization, not all internal function calls or CPU instructions. Root83174413 is a cutoff; later writer/termination costs are outside it. Returned9 public verifier calls do not retain nine witness packets or imply nine admitted proofs.',
        '8930 is recorded successful oracle audit calls at the failure cutoff. No exported oracle_work total or individual snapshot/census receipt list survived in this failure record; unavailable is not zero. No reconstructable all-state archive or mathematical acceptance by hashes.',
        'Literal stage COMPLETE_CASE and map64search starts/63returns/1raised support a Source-backed location within the64th normal search. No component/phase durations or relative timing breakdown were retained; do not attribute the wall limit among compiler/search/oracle/guards or infer a causal bottleneck.',
        'Parent180deadline and worker selfdeadline are separately retained. No exact relative failure instant is claimed. Saved TERM/wait4/group/log closure establishes a negative terminal, not a late positive rescue. closed_ns is an early wait4/parent-close snapshot; full closure uses later raw/log/ledger plus external terminal.'],
    administrative_clock_correction=dict(original=pin(release1),corrected=pin(release2),scope='Original released_ns was unattributed to the pinned epoch and excluded from every resource/window join. V2 is an explicitly current postterminal administrative timestamp, not a backdated210s closure or rescue. Original run closure remains the saved runner and external terminal epochs.'),
    retained_scope=['All680cases plus55variants remain required; this one retired grant cannot be retried or rescued by the63-ID prefix. No complete finite calibration, component conformance qualification, all-exception coverage, fixed FOL checker/palette, theorem, generic GCTS, learned marking, trained RL, production fit or performance advantage is established.',
        'The actual executed compiler/search/verifier/oracle functions with positive counts; zero scientific_calls/component_calls in this review describe only the passive audit, not zero executions in the failed actual. Native/Model/Reader/inverse/proofchecker counters are retained zero.',
        'Prelaunch Source-review statements that components were unexecuted are historical. Their Source/prospective arguments remain ancestry; the current prefix ran and failed whole calibration. No runtime qualification is inherited.',
        'Same Library author/compiler/search/verifier/worker and separately authored B oracle; this reviewer covers current Source/outer/plan/saved scopes with historical protocol/control overlap disclosed. Trusted interpreter/Source loader/OS and exclusive ownership limitations remain.',
        'No current process probe was performed by this reviewer. Reaping, group absence and stable logs are joined from the owned saved runner/terminal observations and Root authoritative release.'],
    tools_stopped_after_handoff=True)
out_path=C/'typed-saved-calibration-review-v1.json'
with out_path.open('xb')as out:out.write((json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(dict(receipt=pin(out_path),saved_review_passed=True,checks=len(checks),mismatch_count=0,outcome='NEGATIVE_DEADLINE',component_calls=0),sort_keys=True))
