"""Metadata author: raw/AST/ordinary JSON and unused compile only.

Never imports, evaluates, calls, probes or simulates either authored subject.
"""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path('/private/tmp/gcts-wang-search-library-20261019')
PUBLISHER = Path('/private/tmp/gcts-split-controls-publish-20261015')
COMPILER = Path('/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py')


def descriptor(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(path=str(path), sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))


def write(name, value):
    path = HERE / name
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(raw)
    return descriptor(path)


def main():
    checks = []

    def require(value, title):
        if not value:
            raise ValueError(title)
        checks.append(dict(name=title, passed=True))

    sources = {}
    trees = {}
    lines = {}
    for role, filename in [('search', 'wang_point_search_v1.py'), ('verifier', 'wang_history_verifier_v1.py')]:
        path = HERE / filename
        text = path.read_text()
        tree = ast.parse(text, filename=str(path))
        compile(tree, str(path), 'exec')  # Unused code object; not module evaluation.
        sources[role], trees[role] = text, tree
        lines[role] = {n.name: dict(start=n.lineno, end=n.end_lineno) for n in tree.body
                       if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        require(not any(isinstance(n, (ast.Import, ast.ImportFrom)) for n in ast.walk(tree)), role + ': no component or standard-library imports')
        require(not any(isinstance(n, (ast.Yield, ast.YieldFrom, ast.AsyncFunctionDef, ast.Await)) for n in ast.walk(tree)), role + ': no generator callback wrapper')
        require(all(not isinstance(n, ast.Expr) or isinstance(n.value, ast.Constant) for n in tree.body), role + ': no top-level invocation')
        # Remaining generator expressions contain only closed literal validators
        # and builtin indexing/sorting, never an external callback/charged helper.
        for node in ast.walk(tree):
            if isinstance(node, ast.GeneratorExp):
                calls = [c for c in ast.walk(node) if isinstance(c, ast.Call)]
                require(not any(isinstance(c.func, ast.Attribute) and c.func.attr in
                    ('step', 'tick', 'cap', 'bound', 'check', 'observe', 'notify') for c in calls),
                    role + ': generator at line' + str(node.lineno) + ' has no callback/checkpoint call')
    raw_compiler = descriptor(COMPILER)
    require(raw_compiler['sha256'] == '92a8c49bd9be346faf9e6472c588140d3844c4e52c1f0a18fef24409e7ff20ba'
            and raw_compiler['bytes'] == 13084, 'compilerV1 whole immutable raw source unchanged')
    search, verifier = sources['search'], sources['verifier']
    patterns = [
        (search, 'for point_index, (x, y) in enumerate(model[\'origins\']):', 'all finite origins enumerated'),
        (search, 'for tile_id, four in enumerate(model[\'edges\']):', 'all palette IDs at every origin'),
        (search, "self.dep_m.setdefault((mx, my), set()).add(cid)", 'all four mark-only dependencies indexed'),
        (search, 'self.reverse[cid] = point', 'explicit reverse incidence'),
        (search, "if dead:\n            return 'DEAD'", 'global DEAD before forced'),
        (search, "if forced:\n            point = min(forced)", 'global FORCED before branching'),
        (search, 'point = min(frontier)[2]', 'generation first tuple ordering'),
        (search, "self.generations[cid] = 1", 'explicit root0 yields placed generation1'),
        (search, 'for candidate in sorted(affected):', 'only complete dependency-affected candidates updated'),
        (search, 'self.undo(frame[\'checkpoint\'])', 'exact parent trail rollback before exclusion'),
        (search, "restored_options != frame['options']", 'restored global decision/full alternatives checked'),
        (search, "self.exclude_failed_child(frame['chosen'])", 'proved-dead child exclusion is parent-scoped'),
        (search, "self.excluded.remove(key)", 'ancestor rollback restores exclusions'),
        (search, "self.w.charge('rollback_operations')", 'cleanup work monotone without callbacks'),
        (search, 'graph.root_check()', 'success/exhaustion requires charged root restoration'),
        (search, 'graph.notify(\'ROOT_RESTORED\')', 'full final restored-root observer offered'),
        (search, 'if error._owner is not w.owner:', 'same-class caller fault not normalized'),
        (search, 'self.observe(packet)', 'observer consumes detached public data directly'),
        (search, 'self.verify_complete_points()', 'whole target and marking checks precede candidate return'),
        (verifier, 'def _project_neighborhood(', 'separate palette schema reconstruction'),
        (verifier, 'if observed != expected:', 'full palette completeness checked independently of witness'),
        (verifier, 'if seen != expected_colors:', 'full injective exact color alphabet checked'),
        (verifier, 'def _global_transition(', 'separate whole-tape transition implementation'),
        (verifier, 'destination < 0 or destination >= len(tape)', 'whole replay rejects wall escape'),
        (verifier, "if state == machine[4]:", 'whole replay rejects postaccept padding'),
        (verifier, "if old == accepting or (old, read) in rules:", 'accepting halt and determinism declarations checked'),
        (verifier, "if head is not None or cell[1] != machine[3]:", 'unique declared initial head checked'),
        (verifier, "if state != machine[4]:", 'actual final state must accept'),
        (verifier, "_obj(row, ('tile_id', 'origin'))", 'rotation/scale/unknown certificate fields rejected'),
        (verifier, 'xy in board', 'duplicate occupancy rejected'),
        (verifier, 'point in point_values and point_values[point] != code', 'explicit assigned0 is not absent'),
        (verifier, 'raw_four_edge_checks', 'raw board edge check independent of point union'),
        (verifier, 'if error._owner is not budget.owner:', 'verifier same-class caller fault remains exact'),
    ]
    for text, pattern, title in patterns:
        require(pattern in text, title)
    require('_local_update' not in verifier and '_Graph' not in verifier, 'verifier does not reference compiler/update/search internals')
    global_fn = next(n for n in trees['verifier'].body if isinstance(n, ast.FunctionDef) and n.name == '_global_transition')
    require(not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in
                    ('_project_neighborhood', '_expected_palette', '_palette') for n in ast.walk(global_fn)),
            'whole global transition independent of local palette reconstruction')
    master = subprocess.run(['/usr/bin/git', '-C', str(PUBLISHER), 'show',
                             'HEAD:docs/basic-tiling-algorithm.md'], capture_output=True, check=True).stdout
    require(len(master) == 36240 and hashlib.sha256(master).hexdigest() ==
        'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4', 'fully reread current master exact raw pin')
    with (HERE/'basic-tiling-algorithm-current.md').open('xb') as stream:
        stream.write(master)
    shared = dict(author_identity='/root/conventional_library', cohort_owner_identity='/root',
                  source_only=True, scientific_calls=0, component_calls=0, compiler_calls=0,
                  verifier_calls=0, search_calls=0, fixture_calls=0, subject_imports=0,
                  scientific_acceptance=False, actual_execution_authorized=False, runtime_qualified=False)
    pins = dict(search=descriptor(HERE/'wang_point_search_v1.py'), verifier=descriptor(HERE/'wang_history_verifier_v1.py'))
    search_counter_keys = {'work', 'operations'}
    for node in ast.walk(trees['search']):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr in ('step', 'charge') and node.args
                and isinstance(node.args[0], ast.Constant) and type(node.args[0].value) is str):
            search_counter_keys.add(node.args[0].value)
    api = write('API-v1.json', dict(schema='finite-wang-search-and-verification-API-v1', **shared,
        Sources=pins, compiler=raw_compiler, snapshot_API=descriptor(HERE/'snapshot-API-v1.json'),
        input='Complete ordinary JSON projection of compilerV1 instance candidate. Normalize every tuple to arrays losslessly inside a future granted wrapper. Both modules reject custom types, tuple inputs, floats, lone surrogates and cycles.',
        search=dict(entry='search(instance, *, check, limits, observe=None)',
                    version='finite-wang-complete-point-search-v1',
                    limits=['work','cells','tiles','colors','candidates','data_depth','decisions','trace_rows','snapshot_items'],
                    outcomes=['TILING_CANDIDATE','FINITE_EXHAUSTED','UNKNOWN'],
                    certificate="{schema:'finite-wang-placement-certificate-v1',placements:[{tile_id:exactint,origin:[x,y]}...]}",
                    semantics='All-palette-ID by all finite-origin base universe; incrementally remove candidates affected by occupied center/all four changed midpoint dependencies. No candidate sampling/dedup/RL/learned markings.',
                    scheduler='Complete global degree0 before global singleton; otherwise minimum(generation,degree,pointindex), every root0. Candidate IDs ascend deterministically. A completely failed child permits only its exact parent-context trailed exclusion; then return to full global census. Every other base alternative remains.',
                    rollback='All occupancy, marks/refcounts, placedgeneration, active/forward/reverse and parent-context exclusions trailed. Static candidate/dependency universe unchanged. Unknown/foreign interruption attempts callback-free rollback, never returns a certificate. Positive/exhausted normal return requires charged complete root verification and final callback.',
                    observing='Full detached sorted point/candidate/mark/dependency/scheduler snapshots; see separately frozen ABI. Observer supplies no policy/pruning. Own quotas can stop before a snapshot; no invented complete census.'),
        snapshot_counters=dict(required=['work'], optional_operation_keys=sorted(search_counter_keys-{'work'}),
                               optional_metric_keys=['metric_events_'+name for name in
                                   ('census','forced','branch','rollback','rollback_census','parent_context_exclusion')],
                               format='Detached flat dict of nonnegative exactints; keys appear only when reached. Metric keys are observation counts, not additional quota units. Work is not a sum of all mixed counter keys. No timestamps or live aliases.'),
        verifier=dict(entry='verify(instance, certificate, *, check, limits)',
                      version='finite-wang-global-history-verifier-v1',
                      limits=['work','cells','tiles','colors','symbols','states','data_depth','history_cells'],
                      outcomes=['VALID_FINITE_ACCEPTING_TILING','UNKNOWN'],
                      malformed='InvalidCertificate raises; own work/cardinality cap yields UNKNOWN without partial acceptance.',
                      checks='Independently reconstruct entire expected palette schemas/color set, strict t/m fields and all boundary/target data before witness; do complete raw edge and independent point-union checks; replay each global single-tape write/move/state step and require exact accepting final state.',
                      independence='No imports or callable reuse from compiler/search; whole global transition also does not call the verifier local schema constructor. Same author and mathematical specification remain shared.'),
        ownership='Exclusive ordinary inputs, read-only external callbacks, no private-object mutation/reflection/reentrancy. Owned input copies; detached observer output. A caller exception object (including StopIteration or the public own-limit class with another owner) propagates unchanged. Root external fault latch remains required in its future wrapper.',
        limits='All keys mandatory, positive exactints, data_depth<=128. Operation counts are a new finite Source profile, not CPU-step/microstep/time units. Named checks/candidate/dependency/input/history work charged. Builtin bounded allocations/copy/sort time and all observers/serialization remain charged wall/RAM by the future outer profile.',
        cleanup='Rollback increments attempted-work counters but deliberately has no callbacks/cap-raising inside critical restoration. Thus own-quota UNKNOWN cleanup can exceed private operation bound, is reported honestly and never admitted. If cleanup itself fails while a caller exception is active, original identity wins and no output is admitted; universal OOM restoration is not claimed.',
        Source_lines=lines))
    contract = write('Source-contract-v1.json', dict(schema='finite-wang-search-and-verification-Source-contract-v1', **shared,
        Sources=pins, compiler=raw_compiler, API=api, snapshot_API=descriptor(HERE/'snapshot-API-v1.json'),
        current_master=descriptor(HERE/'basic-tiling-algorithm-current.md'),
        point_model='Specialized finite integer unit-center square-Wang scope: one tile per required origin, one assigned edge color at each midpoint, translations only, no geometry predicate. All board/frame centers are required generation0 roots; every placed tile generation1. Color0 is assigned, not missing.',
        verification_boundaries='Search structural point checks do not certify machine semantics. Separate verifier validates the full palette regardless of witness and independently replays whole configurations. Root must bind unchanged full compiler input/palette/instance/Source epochs and accept only a current verifier positive within all future external resource/custody gates.',
        semantic_policies='Complete palette preserved; no theorem-specific machine/table/palette pruning or learned restrictions. Exhaustion refers only to this finite board/model. UNKNOWN gives no untileability/nonacceptance/non-theorem evidence.',
        ancestry='Same Library author wrote original compiler and both new implementations, along with older Model/point/cold/evidence/Arena/composer ancestors. Separate files and independent global replay are implementation separation, not distinct authorship or a new independently certified kernel. Root/Control and separate census author provide future external scrutiny.',
        remaining_gaps=['No component/compiler/search/verifier/fixture call or runtime qualification.',
                        'Need complete finite calibration, independent exhaustive domain census at every offered state, branch/forced/dead priority and exact rollback/fault tests under fresh once-grant.',
                        'Need adversarial full-palette/instance/certificate perturbations and accepting/rejecting/escape/head/padding checks, without using a supplied target proof route.',
                        'Only unit-center finite Wang model; no fractional occupancy, multi-frontier shared-positive-support placement, dynamic generation/unbounded growth qualification.',
                        'No fixed FOL checker/machine/palette, theorem-search system, RL/learned marks, universality or performance claim.'],
        production_status='INACTIVE_SOURCE_ONLY_UNEXECUTED_NO_GRANT'))
    audit = write('author-static-audit-v1.json', dict(schema='finite-wang-author-static-audit-v1', **shared,
        Sources=pins, checks=checks, check_count=len(checks),
        unused_compiles_in_packet_author=2, prior_unused_preflight_compiles=2,
        actual_inert_patch_executions=0, Source_lines=lines,
        limitations='Author raw/AST confirmations only, not an independent Source certificate, runtime case or mathematical formalization. No generated compiler output or simulation has been inspected.'))
    handoff = write('handoff-v1.json', dict(schema='finite-wang-search-and-verification-handoff-v1', **shared,
        Sources=pins, API=api, Source_contract=contract, snapshot_API=descriptor(HERE/'snapshot-API-v1.json'),
        author_static_audit=audit, author_Source=descriptor(__file__),
        current_master=descriptor(HERE/'basic-tiling-algorithm-current.md'), compiler=raw_compiler,
        parent_compiler_handoff=descriptor('/private/tmp/gcts-wang-spacetime-library-20261019/handoff-v1.json'),
        status='UNEXECUTED_INACTIVE_PENDING_DISTINCT_REVIEW_AND_BOUNDED_QUALIFICATION', tools_stopped_after_handoff=True))
    print(json.dumps(dict(Sources=pins, API=api, handoff=handoff, checks=len(checks), subject_calls=0), sort_keys=True))


if __name__ == '__main__':
    main()
