"""Freeze the offered V1 raw-metadata/Source coupling negative; no targets run."""
import ast
import hashlib
import json
from pathlib import Path
C=Path('/private/tmp/gcts-wang-finite-qualification-peer-20261019')
D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
W=Path('/private/tmp/gcts-wang-calibration-worker-20261019')
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def pin(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
checks=[]
def check(name,ok):
    checks.append(dict(name=name,passed=bool(ok)))
    if not ok:raise ValueError(name)
def rawpin(name,p):check(name,pin(p['path'])==p)
offer=json.loads((D/'Source-only-offer-v1.json').read_bytes())
plan=json.loads((D/'plan-false-v1.json').read_bytes())
subject={k:v for k,v in plan.items()if k!='authorization'}
check('offered whole false plan pin',pin(D/'plan-false-v1.json')==dict(path=str(D/'plan-false-v1.json'),bytes=3306,sha256='2a712b0efcf9e3d68269b326606c5e4ed3f88f482e8e9f086045ce8fd5084132'))
check('ten plan fields/nine subject fields',len(plan)==10 and len(subject)==9)
check('literal subject matches offer',subject==offer['subject'])
check('canonical complete subject digest',hashlib.sha256(canonical(subject)).hexdigest()==offer['subject_sha256']=='5832f4ce08fb72c4c42d34412c2516cc8b4550a352e26a34e3e1bd97a2744e93')
check('all seven exact Source roles',set(subject['sources'])=={'worker','compiler','search','verifier','oracle','runner','observer'})
for role,p in subject['sources'].items():rawpin('whole current Source '+role,p)
for key in('python','declaration','runtime_closure'):rawpin('whole '+key,subject[key])
for item in subject['inputs']:rawpin('whole input '+item['id'],item['pin'])
rawpin('false authorization',plan['authorization'])
declaration=json.loads(Path(subject['declaration']['path']).read_bytes())
closure=json.loads(Path(subject['runtime_closure']['path']).read_bytes())
inputs=json.loads(Path(subject['inputs'][0]['pin']['path']).read_bytes())
auth=json.loads(Path(plan['authorization']['path']).read_bytes())
check('false/maxzero/no review',auth['actual_execution_authorized']is False and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==0 and auth['review']is None and auth['subject_sha256']==offer['subject_sha256'])
check('declaration original limits',declaration['limits']==subject['limits'])
check('declaration whole input',declaration['inputs']==subject['inputs'])
check('closure exact current Source/Python/declaration',closure['sources']==subject['sources']and closure['python']==subject['python']and closure['declaration']==subject['declaration'])
for index,p in enumerate(closure['stdlib_files']):rawpin('declared stdlib preimage '+str(index),p)
check('complete case order declaration',declaration['case_ids']==[v['id']for v in inputs['cases']]and len(declaration['case_ids'])==680)
check('complete machine order declaration',declaration['machine_ids']==[v['id']for v in inputs['machines']]and len(declaration['machine_ids'])==4)
check('complete diagnostic contents declaration',declaration['diagnostics']==inputs['diagnostics']and declaration['diagnostic_ids']==[v['id']for v in inputs['diagnostics']])
check('same 30 groups/55 variants',len(declaration['diagnostics'])==30 and sum(len(v['variants'])for v in declaration['diagnostics'])==55)
check('fresh actual directory absent',not Path(subject['actual_directory']).exists())
check('false observer path absent',not (D/'plan-false-v1-terminal-observation').exists())
check('no authorized V1 plan/grant metadata yet',not (D/'plan-authorized-v1.json').exists()and not (D/'authorization-true-v1.json').exists())
for role in('worker','runner','observer'):
    source=Path(subject['sources'][role]['path'])
    compile(ast.parse(source.read_bytes(),str(source)),str(source),'exec')  # UNUSED.
    check(role+' unused compile only',True)
finding=dict(id='W1',severity='BLOCKING_BEFORE_ACTUAL',scope='Full original machine/case-to-instance coupling for every searched case, including exhausted negatives',
    Source=subject['sources']['worker'],location='calibrate, palette_check; search._model and positive verifier boundary split',
    evidence='The worker checks a compiled instance palette against the compiled machine palette and compares its finite Boolean outcome with a post-search original-machine reference. It does not explicitly join palette.machine to the original machine, or instance.initial_word/machine_steps/tape_width/board dimensions and boundary semantic words to the original complete case before search. Search/oracle check supplied geometric boundary consistency; the public verifier independently binds semantic initial/acceptance boundaries only when a tiling witness is found.',
    implication='A Boolean SAT/UNSAT agreement does not establish that an exhausted graph was the exact original problem. Source reasoning about the compiler is useful ancestry but does not replace this missing explicit calibration acceptance join.',
    required_correction='On a preserved successor, bind the exact full original machine, complete normalized word, exact horizon and dimensions, and derive/compare the entire NESW word from the independently verified semantic color map and original word/horizon/run/done/stop/exterior frame before every search. Existing search/oracle full target/origin/pin checks can then join those fixed words. Keep all680+55, all current component Sources/caps and the same negative-history scope; no new case or actual is required for the repair.',
    parent_acknowledgment='Root independently found the same boundary seam and requested one V2 repair covering the full join before actual; V1 remains immutable/unexecuted.')
record=dict(schema='wang-encoding-Source-prospective-review-v1',reviewer_identity='/root/conventional_control_review',author_identities=['/root','/root/conventional_library','/root/benchmark_design'],review_passed=False,source_only=True,component_calls=0,scientific_calls=0,subject_imports=0,fixture_calls=0,simulations=0,actual_execution_authorized=False,mathematical_proof_admitted=False,full_pipeline_qualified=False,
    subject=subject,subject_sha256=offer['subject_sha256'],Sources=subject['sources'],false_plan=pin(D/'plan-false-v1.json'),offer=pin(D/'Source-only-offer-v1.json'),worker_handoff=pin(W/'handoff-v1.json'),declaration=subject['declaration'],runtime_closure=subject['runtime_closure'],input=subject['inputs'],
    findings=[finding],finding_count=1,raw_static_metadata_checks=checks,raw_static_metadata_check_count=len(checks),raw_static_metadata_mismatch_count=0,semantic_coupling_mismatch_count=1,unused_compiles=3,
    prior_early_component_review=pin(C/'typed-mathematical-components-early-Source-review-v1.json'),
    other_review_results='Complete worker, final V5 outer, unchanged observer and metadata-author Source read. No other concrete blocking finding identified in the bounded offered scope. Full seven-source prospective acceptance is withheld, not inferred from raw pin or compile checks.',
    snapshot_scope='Full detached snapshot and independently reconstructed census are held through actual full typed/value audit; root and branch baselines through full-value restoration pairing. Intermediate values may then release. Archived reason/size/hash/audit-work receipts do not reconstruct every state and are not hash-only mathematical acceptance.',
    retained_limits_and_trust=['Original worker positive result/header/output reading and known exit before180 monotonic seconds; later outer custody/resource/terminal before210,225 observer fallback only. Worker1GiB and stored/expanded/physical128MiB with9MiB reservation are unchanged.',
        'Complete frozen680cases/30groups55variants only. No every-exception, sameclass/subclass search/verifier fault or every placement/rollback fault coverage claim.',
        'Same Library author/compiler/search/verifier/worker; B oracle separately authored. This reviewer authored historical protocol/control ancestors, not these mathematical components. Independent implementation/census scrutiny is not a separately certified kernel.',
        'Raw-pinned trusted interpreter/SourceFileLoader with postload origin/function/code/default identity checks, exclusive owner/read-only callbacks. No initial compiled-object/pyc/default-content or hostile OS/global integrity seal.',
        'Compiler public CompileLimit lacks private owner; exact planned sentinel and genuine first-Root-fault latch remain required. Search/verifier limits are per-call; oracle token is module-private and external Root faults must dominate classification.',
        'Finite integer unit-center, all generation0 roots, no mixed/fractional/shared-support/unbounded qualification, fixed FOL checker/palette, proof authority, learned marking, RL or speed/production-fit claim.'],
    current_outcome='V1 OFFER NEGATIVE; NO ACTUAL OR TRUE GRANT. PRESERVE V1 AND REVIEW FRESH V2 SUBJECT BEFORE ANY GRANT.',tools_stopped_after_handoff=True)
out=C/'typed-combined-Source-prospective-review-v1-negative.json'
with out.open('xb')as f:f.write((json.dumps(record,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps(dict(receipt=pin(out),review_passed=False,findings=1,raw_static_checks=len(checks),actual_execution_authorized=False),sort_keys=True))
