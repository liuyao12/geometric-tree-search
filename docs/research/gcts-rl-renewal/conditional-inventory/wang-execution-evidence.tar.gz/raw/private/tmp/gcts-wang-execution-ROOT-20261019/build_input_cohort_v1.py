"""Author complete literal input data only; no compiler, simulator or solver."""
from pathlib import Path
import copy
import hashlib
import itertools
import json

D=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')


def main():
    machines=[
        dict(id='right_scan',machine=dict(alphabet_size=2,state_count=2,blank=0,initial=0,accepting=1,
            transitions=[[0,0,1,0,0],[0,1,0,1,1]])),
        dict(id='left_write',machine=dict(alphabet_size=2,state_count=2,blank=0,initial=0,accepting=1,
            transitions=[[0,0,1,1,-1],[0,1,1,0,0]])),
        dict(id='undefined_halt',machine=dict(alphabet_size=2,state_count=2,blank=0,initial=0,accepting=1,
            transitions=[])),
        dict(id='initial_accept',machine=dict(alphabet_size=2,state_count=2,blank=0,initial=1,accepting=1,
            transitions=[])),
    ]
    cases=[]
    for item in machines:
        for width in (1,2,3):
            for symbols in itertools.product((0,1),repeat=width):
                for head in range(width):
                    word=[['head',item['machine']['initial'],s]if i==head else['plain',s]
                          for i,s in enumerate(symbols)]
                    for steps in (0,1,2,3,4):
                        case_id=item['id']+'-w'+str(width)+'-s'+''.join(map(str,symbols))+'-p'+str(head)+'-h'+str(steps)
                        cases.append(dict(id=case_id,machine_id=item['id'],initial_word=copy.deepcopy(word),steps=steps))
    assert len(cases)==len({v['id']for v in cases})==680
    for item in machines:assert sum(c['machine_id']==item['id']for c in cases)==170
    base=copy.deepcopy(machines[0]['machine'])
    def palette_variant(name,machine):
        return dict(id=name,operation='compile_palette',machine=machine,expected='DeclarationError')
    def finite_variant(name,word,steps=0):
        return dict(id=name,operation='compile_finite_problem',machine=copy.deepcopy(base),
                    initial_word=word,steps=steps,expected='DeclarationError')
    def altered(path,value):
        m=copy.deepcopy(base);here=m
        for key in path[:-1]:here=here[key]
        here[path[-1]]=value;return m
    diagnostics=[]
    def group(name,variants,expectation):
        diagnostics.append(dict(id=name,variants=variants,expectation=expectation))
    group('D01',[palette_variant('duplicate',dict(base,transitions=base['transitions']+[base['transitions'][0]]))],
          'Duplicate transition domains rejected, no candidate returned.')
    group('D02',[palette_variant('accept_outgoing',dict(base,transitions=base['transitions']+[[1,0,1,0,0]]))],
          'Accepting state outgoing rule rejected.')
    group('D03',[palette_variant('move_'+name,altered(['transitions',0,4],v))for name,v in
                [('bool',True),('low',-2),('high',2),('float',1.0)]], 'Displacement is an exact integer in its declared range.')
    group('D04',[palette_variant(name,altered(path,value))for name,path,value in [
        ('state_high',['transitions',0,0],2),('read_high',['transitions',0,1],2),
        ('next_high',['transitions',0,2],2),('write_high',['transitions',0,3],2),
        ('blank_low',['blank'],-1),('initial_high',['initial'],2)]], 'All declared IDs obey exact finite ranges.')
    group('D05',[palette_variant('short_row',dict(base,transitions=[[0,0,1,0]])),
                 palette_variant('extra_field',dict(base,unexpected=0))], 'Exact machine and transition shapes required.')
    group('I01',[finite_variant('empty',[])], 'Empty words rejected.')
    group('I02',[finite_variant('headless',[['plain',0]])], 'Exactly one initial head required.')
    group('I03',[finite_variant('two_heads',[['head',0,0],['head',0,1]])], 'Multiple initial heads rejected.')
    group('I04',[finite_variant('wrong_state',[['head',1,0]])], 'Initial head must match declared initial state.')
    group('I05',[finite_variant('bool_symbol',[['head',0,False]]),
                 finite_variant('bool_state',[['head',False,0]]),
                 finite_variant('bad_tag',[['other',0]])], 'Explicit cell codec and exact integer IDs required.')
    group('I06',[finite_variant('negative_time',[['head',0,0]],-1),
                 finite_variant('boolean_time',[['head',0,0]],False)], 'Exact nonnegative step count required.')
    for group_id,recipes,expectation in [
        ('A01',['north_word_mismatch'],'Changed boundary is checked against the original complete word; not a general non-tiling claim.'),
        ('A02',['south_stop_mismatch','exterior_pin_mismatch'],'Original full boundary/frame is required.'),
        ('A03',['remove_required_center','duplicate_required_center','extra_admissible_origin'],'Every exact board center/origin is checked.'),
        ('A04',['remove_assigned_zero_mark','boolean_zero_mark'],'Assigned zero is a value, not absent or bool.'),
        ('A05',['reverse_edge_order','rotation_field','wrong_mark_channel'],'No rotations/reflections or alternate point channels.'),
    ]:
        group(group_id,[dict(id=r,operation='mutate_actual_compiled_instance',recipe=r,
               expected='INDEPENDENT_INSTANCE_OR_PALETTE_REJECTION')for r in recipes],expectation)
    group('L01',[dict(id='work_one',operation='compile_palette',machine=copy.deepcopy(base),
              limit_overrides=dict(work=1),expected='OWN_COMPILE_LIMIT_NO_RETURNED_CANDIDATE')],
          'Own compilation budget is unfinished, not a mathematical rejection.')
    group('L02',[dict(id=key+'_one',operation='compile_finite_problem',machine=copy.deepcopy(base),
              initial_word=[['head',0,0]],steps=0,limit_overrides={key:1},
              expected='OWN_COMPILE_LIMIT_NO_RETURNED_CANDIDATE')for key in('symbols','states','tiles','colors','dimension','cells')],
          'Every selected own finite bound is exercised; no partial candidate.')
    group('L03',[dict(id=name,operation='compile_palette',machine=copy.deepcopy(base),
              malformed_limits=recipe,expected='DeclarationError')for name,recipe in
              [('zero','zero_work'),('bool','boolean_work'),('unknown','extra_key')]], 'Exact positive finite limit dictionary required.')
    group('U01',[dict(id='persistent_machine_change',operation='compile_with_mutating_callback',
              machine=copy.deepcopy(base),at_callback=20,path=['blank'],replacement=1,
              expected='DeclarationError')],
          'Deliberate read-only-contract violation, persistent final machine reconciliation only; no hostile mutation seal.')
    for fid,role,where,sentinel in [
        ('F01','compiler','check','foreign_base_exception'),('F02','compiler','check','foreign_compile_limit'),
        ('F03','search','check','foreign_base_exception'),('F04','verifier','check','foreign_base_exception'),
        ('F05','search','observe','foreign_base_exception'),('F06','oracle','check','foreign_base_exception')]:
        group(fid,[dict(id='exact_foreign_identity',operation='inject_external_fault',role=role,
              callback=where,at_callback=1,sentinel=sentinel,expected='EXACT_FOREIGN_OBJECT_PROPAGATED')],
              'External faults preserve identity and cannot become expected own-resource outcomes; Root policy faults dominate.')
    for fid,role in [('F07','search'),('F08','verifier'),('F09','oracle')]:
        group(fid,[dict(id='own_work_one',operation='exercise_owned_work_limit',role=role,
              limit_overrides=dict(work=1),expected='OWNED_RESOURCE_NO_ACCEPTANCE')],
              'Private owner discrimination; no resource unknown becomes tiling/non-tiling acceptance.')
    group('R01',[dict(id='every_completed_case_root',operation='compare_every_root_restoration',
              expected='EXACT_FULL_ROOT_STATE_EQUALITY')],
          'Full point/mark/incidence/generation/exclusion rollback is checked, excluding monotone counters.')
    record=dict(schema='ROOT-wang-complete-finite-calibration-inputs-v1',machines=machines,cases=cases,
        diagnostics=diagnostics,word_widths=[1,2,3],exact_steps=[0,1,2,3,4],
        word_count_per_machine=34,case_count=680,
        codec='JSON array cell literals are converted once to exact tuples for the compiler; all compiler tuples are losslessly JSON-projected for point search/verifiers.',
        answer_policy='No stored solver answer, TM trace or placement certificate. Search runs first; a separate bounded whole-TM reference is consulted afterward, never as a proposal.',
        palette_policy='Complete machine-only palette on every call; full structural comparison and separate palette verification. No statement or reachable-state trimming. All originals/compiler objects retained through positive boundary.',
        fixed_FOL_checker=False,mathematical_proof_accepted=False,actual_execution_authorized=False,
        scope='Complete only for these four machines and finite bounds. Not all machines, all bounds, unknown-proof search, fixed FOL Wang palette, or a replacement for the failed whole production workload.')
    p=D/'cohort-inputs-v1.json'
    raw=(json.dumps(record,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with p.open('xb')as f:f.write(raw)
    print(json.dumps(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),cases=680,
        diagnostic_groups=len(diagnostics),diagnostic_variants=sum(len(d['variants'])for d in diagnostics)),sort_keys=True))


if __name__=='__main__':main()
