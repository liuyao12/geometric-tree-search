"""Unexecuted Source: specialized finite unit-center Wang point search.

No compiler/verifier imports. All roots have generation zero. No learned marks,
RL, geometric legality test, candidate sampling, or machine-history shortcut.
Input is the ordinary JSON projection of the complete compiler problem record.
"""

VERSION = 'finite-wang-complete-point-search-v1'
SNAPSHOT_SCHEMA = 'finite-wang-complete-graph-snapshot-v1'
LIMIT_KEYS = ('work', 'cells', 'tiles', 'colors', 'candidates', 'data_depth',
              'decisions', 'trace_rows', 'snapshot_items')
INSTANCE_KEYS = ('schema', 'version', 'status', 'palette', 'initial_word', 'machine_steps',
                 'tape_width', 'board_width', 'board_height', 'boundary_NESW',
                 'required_centers', 'admissible_origins', 'fixed_background_marks',
                 'candidate_universe', 'all_root_generations', 'attempted_work',
                 'mathematical_authority', 'executed_source_qualified')


class InputError(Exception):
    pass


class SearchLimit(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason = reason
        self._owner = owner
        super().__init__(reason)


class _Work:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict
                or any(type(key) is not str for key in limits) or set(limits) != set(LIMIT_KEYS)):
            raise InputError('explicit check and exact finite limits required')
        for name in LIMIT_KEYS:
            if type(name) is not str or type(limits[name]) is not int or limits[name] < 1:
                raise InputError('positive exact-int limits required')
        if limits['data_depth'] > 128:
            raise InputError('Source recursive input-depth profile is at most128')
        self.check = check
        self.limits = dict(limits)
        self.owner = object()
        self.counts = {'work': 0}
        check()

    def charge(self, kind):
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1

    def step(self, kind='operations'):
        self.charge(kind)
        if self.counts['work'] > self.limits['work']:
            raise SearchLimit('work', owner=self.owner)
        self.check()

    def bound(self, name, value):
        self.step('bound_checks')
        if value > self.limits[name]:
            raise SearchLimit(name, owner=self.owner)


def _object(value, keys):
    if type(value) is not dict or any(type(k) is not str for k in value) or set(value) != set(keys):
        raise InputError('exact object fields required')


def _int(value, low=0, high=None):
    if type(value) is not int or value < low or (high is not None and value >= high):
        raise InputError('exact integer outside domain')
    return value


def _array(value, size=None):
    if type(value) is not list or (size is not None and len(value) != size):
        raise InputError('ordinary array shape required')
    return value


def _copy(value, w, depth=0, active=None):
    w.step('input_nodes')
    w.bound('data_depth', depth)
    kind = type(value)
    if value is None or kind in (bool, int):
        return value
    if kind is str:
        for character in value:
            w.step('input_characters')
            if 0xD800 <= ord(character) <= 0xDFFF:
                raise InputError('Unicode scalar strings only')
        return value
    if kind in (list, dict):
        if active is None:
            active = set()
        identity = id(value)
        if identity in active:
            raise InputError('cyclic caller container')
        active.add(identity)
        try:
            if kind is list:
                return [_copy(item, w, depth + 1, active) for item in value]
            result = {}
            for key, item in value.items():
                if type(key) is not str:
                    raise InputError('exact string keys required')
                result[_copy(key, w, depth + 1, active)] = _copy(item, w, depth + 1, active)
            return result
        finally:
            active.remove(identity)
    raise InputError('strict ordinary JSON subset; normalize compiler tuples before this boundary')


def _term(value, w):
    w.step('color_terms')
    if type(value) in (str, int):
        return (type(value).__name__, value)
    items = []
    for item in _array(value):
        items.append(_term(item, w))
    return ('array', tuple(items))


def _point(value):
    return tuple(_int(n) for n in _array(value, 2))


def _model(value, w):
    p = _copy(value, w)
    _object(p, INSTANCE_KEYS)
    if (p['schema'] != 'finite-framed-wang-instance-v1'
            or p['version'] != 'finite-framed-wang-spacetime-compiler-v1'
            or p['status'] != 'FINITE_PROBLEM_CANDIDATE'
            or p['mathematical_authority'] is not False or p['executed_source_qualified'] is not False):
        raise InputError('exact untrusted compiler candidate schema required')
    width = _int(p['board_width'], 3)
    height = _int(p['board_height'], 1)
    if width != _int(p['tape_width'], 1) + 2 or height != _int(p['machine_steps']) + 1:
        raise InputError('finite rectangle dimensions disagree')
    if type(p['all_root_generations']) is not int or p['all_root_generations'] != 0:
        raise InputError('all finite roots must have generation zero')
    _int(p['attempted_work'])
    if p['candidate_universe'] != 'every palette tile ID at every admissible origin; no rotations/reflections':
        raise InputError('complete candidate convention required')
    w.bound('cells', width * height)
    origins = []
    for y in range(height):
        for x in range(width):
            w.step('target_cells')
            origins.append((2 * x, 2 * y))
    required = tuple(_point(x) for x in _array(p['required_centers'], len(origins)))
    admitted = tuple(_point(x) for x in _array(p['admissible_origins'], len(origins)))
    if required != tuple(origins) or admitted != required:
        raise InputError('all and only row-major board centers must be required/origins')
    palette = p['palette']
    _object(palette, ('schema', 'version', 'machine', 'color_constructors', 'tiles',
                      'transformations', 'point_profile', 'edge_order', 'mathematical_authority'))
    if (palette['schema'] != 'finite-framed-wang-spacetime-v1'
            or palette['version'] != p['version'] or palette['transformations'] != 'translations_only_2Z2'
            or palette['point_profile'] != 'integer-center-midpoint-translation-only-v1'
            or palette['edge_order'] != 'NESW' or palette['mathematical_authority'] is not False):
        raise InputError('exact translation-only center/midpoint palette required')
    colors = _array(palette['color_constructors'])
    w.bound('colors', len(colors))
    if not colors:
        raise InputError('nonempty finite colors required')
    terms = set()
    for color in colors:
        term = _term(color, w)
        if term in terms:
            raise InputError('duplicate literal color constructor')
        terms.add(term)
    tiles = _array(palette['tiles'])
    w.bound('tiles', len(tiles))
    if not tiles:
        raise InputError('nonempty full palette required')
    edges = []
    for index, tile in enumerate(tiles):
        w.step('palette_tiles')
        _object(tile, ('id', 'kind', 'origin', 'edges_NESW', 't', 'm'))
        if _int(tile['id']) != index or type(tile['kind']) is not str:
            raise InputError('unique ordered palette identities required')
        _array(tile['origin'])
        four = tuple(_int(c, 0, len(colors)) for c in _array(tile['edges_NESW'], 4))
        occupancy = _array(tile['t'], 1)
        _array(occupancy[0], 2)
        if _point(occupancy[0][0]) != (0, 0) or type(occupancy[0][1]) is not int or occupancy[0][1] != 1:
            raise InputError('exact unit-center occupancy only')
        marks = _array(tile['m'], 4)
        for offset, entry, code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), marks, four):
            w.step('palette_markings')
            _array(entry, 3)
            xy = tuple(_int(n, -1, 2) for n in _array(entry[0], 2))
            if xy != offset or entry[1] != 'edge' or _int(entry[2], 0, len(colors)) != code:
                raise InputError('all four ordered assigned midpoint values required')
        edges.append(four)
    w.bound('candidates', len(origins) * len(edges))
    boundary = _array(p['boundary_NESW'], 4)
    for side, length in zip(boundary, (width, height, width, height)):
        for code in _array(side, length):
            w.step('boundary_values')
            _int(code, 0, len(colors))
    expected_pins = {}
    for y in range(height):
        expected_pins[-1, 2 * y] = boundary[3][y]
        expected_pins[2 * width - 1, 2 * y] = boundary[1][y]
    for x in range(width):
        expected_pins[2 * x, -1] = boundary[0][x]
        expected_pins[2 * x, 2 * height - 1] = boundary[2][x]
    pins = {}
    for row in _array(p['fixed_background_marks'], len(expected_pins)):
        w.step('fixed_marks')
        _array(row, 3)
        xy = tuple(_int(n, -1) for n in _array(row[0], 2))
        code = _int(row[2], 0, len(colors))
        if row[1] != 'edge' or xy in pins or xy not in expected_pins or expected_pins[xy] != code:
            raise InputError('exact complete exterior boundary section required')
        pins[xy] = code
    return dict(origins=tuple(origins), edges=tuple(edges), pins=pins,
                width=width, height=height, palette_ids=tuple(range(len(edges))))


class _Graph:
    def __init__(self, model, w, observe):
        self.model, self.w, self.observe = model, w, observe
        self.occ = [None] * len(model['origins'])
        self.marks = {point: (code, 1) for point, code in model['pins'].items()}
        self.generations = {}
        self.excluded = set()
        self.domains = [set() for point in self.occ]
        self.candidates, self.cmarks, self.dep_t, self.dep_m = [], [], {}, {}
        self.active, self.reverse = [], []
        self.trail, self.trace = [], []
        self.branch_choices = 0
        for point_index, (x, y) in enumerate(model['origins']):
            self.dep_t[point_index] = set()
            for tile_id, four in enumerate(model['edges']):
                w.step('candidate_construction')
                cid = len(self.candidates)
                self.candidates.append((point_index, tile_id))
                marks = tuple((x + dx, y + dy, code) for (dx, dy), code in
                              zip(((0, -1), (1, 0), (0, 1), (-1, 0)), four))
                self.cmarks.append(marks)
                self.dep_t[point_index].add(cid)
                for mx, my, code in marks:
                    w.step('mark_dependency_construction')
                    self.dep_m.setdefault((mx, my), set()).add(cid)
                self.active.append(False)
                self.reverse.append(None)
        for cid in range(len(self.candidates)):
            if self.legal(cid):
                point = self.candidates[cid][0]
                self.active[cid] = True
                self.domains[point].add(cid)
                self.reverse[cid] = point
        self.initial_domains = tuple(tuple(sorted(domain)) for domain in self.domains)

    def legal(self, cid):
        self.w.step('candidate_legality')
        point, tile = self.candidates[cid]
        if self.occ[point] is not None or cid in self.excluded:
            return False
        for mx, my, code in self.cmarks[cid]:
            self.w.step('mark_comparisons')
            existing = self.marks.get((mx, my))
            if existing is not None and existing[0] != code:
                return False
        return True

    def event(self, kind, **values):
        self.w.bound('trace_rows', len(self.trace) + 1)
        self.trace.append(dict(kind=kind, **values))
        key = 'metric_events_' + kind
        self.w.counts[key] = self.w.counts.get(key, 0) + 1

    def snapshot(self, reason):
        """Detached full graph; no internal list/set/dict is handed to observer."""
        w = self.w
        items = 0

        def item():
            nonlocal items
            items += 1
            w.bound('snapshot_items', items)
        points, candidates, marks, forward, reverse, deps = [], [], [], [], [], []
        for i, xy in enumerate(self.model['origins']):
            item()
            points.append([i, list(xy), 0 if self.occ[i] is None else 1, 0])
            forward.append([i, sorted(self.domains[i])])
            for cid in self.domains[i]:
                item()
        for cid, (point, tile) in enumerate(self.candidates):
            item()
            candidates.append([cid, point, tile, self.active[cid]])
            reverse.append([cid, [] if self.reverse[cid] is None else [self.reverse[cid]]])
        for xy in sorted(self.marks):
            item()
            code, count = self.marks[xy]
            marks.append([list(xy), code, count, xy in self.model['pins']])
        for point in range(len(self.occ)):
            item()
            row = sorted(self.dep_t[point])
            for cid in row:
                item()
            deps.append(['t', point, row])
        for xy in sorted(self.dep_m):
            item()
            row = sorted(self.dep_m[xy])
            for cid in row:
                item()
            deps.append(['m', list(xy), row])
        chosen, boundary, excluded = [], [], []
        for cid in sorted(self.generations):
            item()
            point, tile = self.candidates[cid]
            chosen.append([cid, point, tile, self.generations[cid]])
        for point, code in sorted(self.model['pins'].items()):
            item()
            boundary.append([list(point), code])
        for cid in sorted(self.excluded):
            item()
            excluded.append(cid)
        decision, point, options = self.choose()
        return dict(schema=SNAPSHOT_SCHEMA, reason=reason, points=points, candidates=candidates,
                    chosen=chosen, marks=marks, forward=forward, reverse=reverse,
                    dependencies=deps, boundary=boundary, exclusions=excluded,
                    scheduler=dict(kind=decision, point=point, options=list(options)),
                    trail_length=len(self.trail), work=dict(w.counts), authority=False)

    def notify(self, reason):
        if self.observe is not None:
            packet = self.snapshot(reason)
            self.w.step('observer_calls')
            self.observe(packet)  # Direct foreign errors propagate without conversion.

    def choose(self):
        frontier, dead, forced = [], [], []
        for point, occupied in enumerate(self.occ):
            self.w.step('global_census_points')
            if occupied is None:
                degree = len(self.domains[point])
                frontier.append((0, degree, point))
                if degree == 0:
                    dead.append(point)
                elif degree == 1:
                    forced.append(point)
        if dead:
            return 'DEAD', min(dead), ()
        if forced:
            point = min(forced)
            return 'FORCED', point, tuple(sorted(self.domains[point]))
        if not frontier:
            return 'COMPLETE', None, ()
        point = min(frontier)[2]  # Generation first; all explicit finite roots are0.
        return 'BRANCH', point, tuple(sorted(self.domains[point]))

    def place(self, cid, kind):
        if not self.active[cid] or not self.legal(cid):
            raise InputError('graph selected a nonmember candidate')
        point, tile = self.candidates[cid]
        self.w.step('placements')
        self.trail.append(('occ', point, self.occ[point]))
        self.occ[point] = tile
        self.trail.append(('generation', cid, None))
        self.generations[cid] = 1  #1+min(root generation0) on its singleton t-support.
        affected = set(self.dep_t[point])
        for mx, my, code in self.cmarks[cid]:
            self.w.step('mark_assignments')
            xy = (mx, my)
            old = self.marks.get(xy)
            self.trail.append(('mark', xy, old))
            self.marks[xy] = (code, 1 if old is None else old[1] + 1)
            for dependent in self.dep_m[xy]:
                self.w.step('affected_dependencies')
                affected.add(dependent)
        removed, occupancy_removed, mark_removed = [], [], []
        for candidate in sorted(affected):
            if self.active[candidate] and not self.legal(candidate):
                self.w.step('candidate_removals')
                origin = self.candidates[candidate][0]
                self.trail.append(('active', candidate, True))
                self.active[candidate] = False
                self.reverse[candidate] = None
                self.domains[origin].remove(candidate)
                removed.append(candidate)
                (occupancy_removed if origin == point else mark_removed).append(candidate)
        self.event(kind, candidate=cid, point=point, tile_id=tile, generation=1,
                   removed=removed, removed_occupancy=occupancy_removed, removed_mark=mark_removed)

    def branch_place(self, cid, kind):
        self.w.bound('decisions', self.branch_choices + 1)
        self.branch_choices += 1
        self.place(cid, kind)

    def exclude_failed_child(self, cid):
        # Only a completely DEAD/exhausted child reaches this operation.
        # This parent-context exclusion is itself trailed and never global.
        if not self.active[cid] or not self.legal(cid):
            raise InputError('failed child did not restore its exact legal parent')
        self.w.step('proved_child_exclusions')
        point = self.candidates[cid][0]
        self.trail.append(('exclude', cid, None))
        self.excluded.add(cid)
        self.trail.append(('active', cid, True))
        self.active[cid] = False
        self.reverse[cid] = None
        self.domains[point].remove(cid)
        self.event('parent_context_exclusion', candidate=cid, point=point)

    def undo(self, checkpoint):
        # Callback-free critical rollback; attempted work is still monotone.
        # A success must recheck the total work/deadline after this cleanup.
        while len(self.trail) > checkpoint:
            self.w.charge('rollback_operations')
            kind, key, old = self.trail.pop()
            if kind == 'active':
                point = self.candidates[key][0]
                self.active[key] = old
                self.reverse[key] = point
                self.domains[point].add(key)
            elif kind == 'mark':
                if old is None:
                    del self.marks[key]
                else:
                    self.marks[key] = old
            elif kind == 'generation':
                del self.generations[key]
            elif kind == 'exclude':
                self.excluded.remove(key)
            elif kind == 'occ':
                self.occ[key] = old
            else:
                raise InputError('invalid owned rollback opcode')

    def verify_complete_points(self):
        section = {xy: code for xy, code in self.model['pins'].items()}
        for point, tile in enumerate(self.occ):
            self.w.step('whole_target_verification')
            if tile is None:
                raise InputError('unfilled target in candidate solution')
            x, y = self.model['origins'][point]
            for (dx, dy), code in zip(((0, -1), (1, 0), (0, 1), (-1, 0)), self.model['edges'][tile]):
                self.w.step('whole_mark_verification')
                xy = (x + dx, y + dy)
                if xy in section and section[xy] != code:
                    raise InputError('whole point marking conflict')
                section[xy] = code

    def root_check(self):
        for point, domain in enumerate(self.domains):
            self.w.step('root_restoration_checks')
            if self.occ[point] is not None or tuple(sorted(domain)) != self.initial_domains[point]:
                raise InputError('root occupancy/domain restoration failure')
        if self.generations or self.excluded or self.trail or self.marks != {p: (c, 1) for p, c in self.model['pins'].items()}:
            raise InputError('root generation/mark restoration failure')
        for cid, active in enumerate(self.active):
            self.w.step('root_reverse_checks')
            point = self.candidates[cid][0]
            expected = cid in self.domains[point]
            if active is not expected or self.reverse[cid] != (point if expected else None):
                raise InputError('root reverse restoration failure')

    def run(self):
        stack = []
        self.notify('INITIAL')
        while True:
            self.notify('STATE')
            decision, point, options = self.choose()
            self.event('census', decision=decision, point=point, options=list(options))
            if decision == 'COMPLETE':
                self.verify_complete_points()
                placements = []
                for index, tile in enumerate(self.occ):
                    self.w.step('certificate_rows')
                    placements.append(dict(tile_id=tile, origin=list(self.model['origins'][index])))
                return dict(status='TILING_CANDIDATE', certificate=dict(
                    schema='finite-wang-placement-certificate-v1', placements=placements))
            if decision == 'FORCED':
                self.place(options[0], 'forced')
                continue
            if decision == 'BRANCH':
                frame = dict(checkpoint=len(self.trail), point=point, options=options, chosen=options[0])
                stack.append(frame)
                self.branch_place(options[0], 'branch')
                continue
            # A known global dead point is handled before any forced/branch move.
            if stack:
                frame = stack.pop()
                self.undo(frame['checkpoint'])
                self.event('rollback', checkpoint=frame['checkpoint'], point=frame['point'])
                self.notify('ROLLBACK')
                restored_decision, restored_point, restored_options = self.choose()
                self.event('rollback_census', decision=restored_decision, point=restored_point,
                           options=list(restored_options))
                if (restored_decision != 'BRANCH' or restored_point != frame['point']
                        or restored_options != frame['options']):
                    raise InputError('restored global decision differs from exact parent')
                self.exclude_failed_child(frame['chosen'])
                # Re-enter complete global DEAD/FORCED/earliest-generation
                # selection; all other original parent alternatives remain.
                continue
            else:
                return dict(status='FINITE_EXHAUSTED', certificate=None)


def _error_cleanup(graph):
    if graph is not None:
        try:
            graph.undo(0)
        except BaseException:
            # No returned success; preserve an already active caller exception.
            pass


def search(instance, *, check, limits, observe=None):
    """Source-only API: no production/test invocation has been performed.

    Only an own per-call quota produces UNKNOWN; caller exceptions are exact.
    Observe consumes detached data, supplies no choices/pruning, and may refuse.
    """
    w = _Work(check, limits)
    graph = None
    if observe is not None and not callable(observe):
        raise InputError('observe must be callable or None')
    try:
        model = _model(instance, w)
        graph = _Graph(model, w, observe)
        result = graph.run()
        graph.undo(0)
        graph.root_check()
        graph.notify('ROOT_RESTORED')
        w.step('successful_return_check')
        result.update(version=VERSION, scope='SPECIALIZED_FINITE_UNIT_CENTER_WANG',
                      root_restored=True, counts=dict(w.counts), trace=graph.trace,
                      independent_output_verification_required=True, learned_marks=False, RL=False)
        return result
    except SearchLimit as error:
        if error._owner is not w.owner:
            _error_cleanup(graph)
            raise
        _error_cleanup(graph)
        return dict(status='UNKNOWN', reason=error.reason, version=VERSION,
                    counts=dict(w.counts), trace=[] if graph is None else graph.trace,
                    certificate=None, root_restoration='cleanup attempted; not rechecked after quota',
                    independent_output_verification_required=True)
    except BaseException:
        _error_cleanup(graph)
        raise
