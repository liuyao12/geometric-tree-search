"""Raw/AST/ordinary metadata freeze; never loads or invokes any subject."""
import ast
import hashlib
import json
from pathlib import Path

DIRECTORY=Path('/private/tmp/gcts-wang-calibration-worker-20261019')
ROOT=Path('/private/tmp/gcts-wang-execution-ROOT-20261019')
WORKER=DIRECTORY/'qualify_wang_calibration_worker_v1.py'


def pin(path):
    path=Path(path).resolve();raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def save(name,value):
    path=DIRECTORY/name;raw=json.dumps(value,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False).encode()+b'\n'
    with path.open('xb')as stream:stream.write(raw)
    return pin(path)


def main():
    raw=WORKER.read_bytes();tree=ast.parse(raw,filename=str(WORKER));compile(tree,str(WORKER),'exec')
    text=raw.decode();checks=[]
    def require(ok,name):
        if not ok:raise ValueError(name)
        checks.append(dict(name=name,passed=True))
    def inert_literal(node):
        if isinstance(node,ast.Dict):
            return {inert_literal(k):inert_literal(v)for k,v in zip(node.keys,node.values)}
        if isinstance(node,ast.Call)and isinstance(node.func,ast.Name)and node.func.id=='dict'and not node.args:
            if any(k.arg is None for k in node.keywords):raise ValueError('no metadata keyword expansion')
            return {k.arg:inert_literal(k.value)for k in node.keywords}
        return ast.literal_eval(node)
    assignments={n.targets[0].id:inert_literal(n.value)for n in tree.body if isinstance(n,ast.Assign)
        and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and n.targets[0].id in
        ('VERSION','SOURCE_ROLES','SOURCE_PINS','INPUT_SHA','INPUT_BYTES','OUTER_LIMITS','COMPONENT_LIMITS',
         'CHECKPOINT_LIMIT','RESERVE_BYTES','FORBIDDEN_EVENTS')}
    capsule=pin(ROOT/'cohort-inputs-v1.json');inputs=json.loads((ROOT/'cohort-inputs-v1.json').read_bytes())
    require(capsule['sha256']==assignments['INPUT_SHA']and capsule['bytes']==assignments['INPUT_BYTES'],'exact complete680case/55variant raw capsule')
    require(len(inputs['cases'])==680 and len(inputs['diagnostics'])==30 and
            sum(len(g['variants'])for g in inputs['diagnostics'])==55,'full original corpus and every diagnostic variant')
    require(set(assignments['SOURCE_ROLES'])=={'worker','compiler','search','verifier','oracle','runner','observer'},'all seven current Source roles')
    paths=dict(compiler='/private/tmp/gcts-wang-spacetime-library-20261019/wang_spacetime_compiler_v1.py',
        search='/private/tmp/gcts-wang-search-library-20261019/wang_point_search_v2.py',
        verifier='/private/tmp/gcts-wang-search-library-20261019/wang_history_verifier_v2.py',
        oracle='/private/tmp/gcts-wang-snapshot-oracle-20261019/wang_snapshot_oracle_v1.py')
    components={role:pin(path)for role,path in paths.items()}
    for role,descriptor in components.items():
        require((descriptor['sha256'],descriptor['bytes'])==tuple(assignments['SOURCE_PINS'][role]),role+' exact immutable raw Source pin')
    patterns=[
        ('self.first_fault is not None:raise self.first_fault','first real Root fault latch dominates diagnosis'),
        ("s.stage='DIAGNOSTIC'",'explicit diagnostic prefix/stage'),
        ("need(variant_count==55 and len(s.diagnostics)==30",'no missing variant passes'),
        ("need(len(s.rows)==inputs['case_count']==680",'all complete declared cases retained'),
        ("reference=reference_after_search(s,machine",'reference consulted after search'),
        ("module.search(instance,check=callback",'no TM reference passed into search'),
        ("lambda:v._palette(palette,budget)",'full palette private seam directly completed, no expected-error inference'),
        ("lambda:v._global_transition(tape,head,state,parsed,budget)",'whole TM replay uses pinned independent global implementation'),
        ("s.retained.append(original)",'all original compiler objects remain reachable'),
        ("need(body==branches.pop()",'failed-child restoration full value comparison'),
        ("body==initial",'full initial/restored root equality'),
        ("snapshot=dict(bytes=len(packet)",'every offered snapshot receipt with actual full audit'),
        ("error is sentinel",'foreign planned object exact identity'),
        ("if type(error)is oracle.SnapshotLimit and self.own_oracle_limit(error)",'Root latch precedes actual own-oracle classification'),
        ("self.raised[key]=",'raised calls counted separately from normal returns'),
        ("expanded=output['bytes']+s.expanded_subtree_delta+result['bytes']",'exact full logical subtree expansion ledger'),
        ("0<expanded<=134217728",'unchanged full expanded cap'),
        ("positive_worker_completed_ns=NOW()",'positive header cutoff measured before header serialization'),
        ("s.stage='HEADER_WRITE'",'entire header write inside same work deadline'),
        ("closure=True",'failure metadata only may use original210closure'),
    ]
    for pattern,name in patterns:require(pattern in text,name)
    require(not any(isinstance(n,(ast.Yield,ast.YieldFrom,ast.AsyncFunctionDef,ast.Await))for n in ast.walk(tree)),
            'no worker generator wrapper around foreign callbacks')
    imports=[]
    for node in tree.body:
        if isinstance(node,ast.Import):imports.extend(a.name for a in node.names)
        elif isinstance(node,ast.ImportFrom):imports.append(node.module)
    require(imports==['time','hashlib','importlib.util','json','os','pathlib','sys','types'],'only declared standard-library imports at Source entry')
    for name in('Native','Model','Reader','inverse','proof_checker'):
        require(name not in assignments['SOURCE_ROLES'],name+' not an executable component role')
    common=dict(author_identity='/root/conventional_library',cohort_owner_identity='/root',source_only=True,
        component_calls=0,compiler_calls=0,search_calls=0,verifier_calls=0,oracle_calls=0,fixture_calls=0,
        subject_imports=0,scientific_acceptance=False,actual_execution_authorized=False)
    profile=save('component-limits-v1.json',dict(schema='complete-wang-worker-component-limits-v1',**common,
        component_limits=assignments['COMPONENT_LIMITS'],checkpoint_limit=assignments['CHECKPOINT_LIMIT'],
        limits=assignments['OUTER_LIMITS'],outer_metadata_reservation=assignments['RESERVE_BYTES'],
        scope='Private per-call component work limits and invocation-total Root callback-count ceiling are different profiles/units from each other and from earlier Arena/Adapter work. All wall/copy/guard/serialization costs remain inside original180/210. No fit claim.'))
    api=save('API-v1.json',dict(schema='complete-wang-calibration-worker-API-v1',**common,
        Source=pin(WORKER),entry='python3.12 -I -S -B worker.py once-plan.json; main(plan_path)',
        plan_schema='ROOT-wang-encoding-qualification-plan-v1',source_roles=assignments['SOURCE_ROLES'],
        declaration_required_additions=dict(component_limits=assignments['COMPONENT_LIMITS'],checkpoint_limit=assignments['CHECKPOINT_LIMIT']),
        input=capsule,components=components,profile=profile,
        outputs=['canonical-wang-calibration.json','result.json','worker-receipt.json'],
        complete_packet='All inputs, four full palettes plus compile_palette wrapper metadata,680 losslessly palette-shared full compiler problems, complete search traces/certificates/counts, whole post-search TM references, all snapshot receipts and all30groups/55actual diagnostic rows.',
        snapshot_lifecycle='Full snapshot and complete independent census retained through actual full audit; complete root/branch baselines held through actual full canonical value equality; then intermediate values released. Every offered receipt retained. Not all-state value archival or reconstructability, and hashes do not substitute for checks.',
        qualification_schema='wang-encoding-calibration-candidate-v1',qualification_status='COMPLETE_FINITE_CALIBRATION_CANDIDATE only if all680 complete and all55 controls reached/passed; any normal UNKNOWN makes calibration false.',
        variant_fields=['id','expected','status','reached','expectation_satisfied','foreign_fault_misclassified',
            'actual_outcome','actual_class','actual_reason','own_resource','exact_foreign_identity',
            'check_calls_before','check_calls_after','role','callback','stage','details','returned','error','declaration'],
        header_schema='wang-encoding-qualification-worker-receipt-v1',result_schema='wang-encoding-qualification-result-v1',
        byte_coupling='payload.canonical_logical_bytes=stored main packet bytes; header.logical_result_bytes=main+result. payload.expanded_canonical_packet_bytes=main+exact full compiler-problem subtree byte deltas; header.expanded_logical_result_bytes=expanded_canonical_packet_bytes+result.bytes. Both <=128MiB; physical all actualfiles+9MiB<=128MiB. Root final outer must join these exact fields.',
        counter_coupling='q compiler/search/verifier/oracle_calls are counts of started declared entries, including listed private/constructor/classifier seams. call_completed counts normal returns only; call_raised counts exceptions. oracle_work sums actual exported successful audit_work plus owned-limit attempted_work; oracle_work_unavailable_calls explicitly excludes foreign faults without a counter. Distinct from Root checkpoints.',
        checkpoint_cutoffs='q.root_check_calls before result serialization; header root_check_calls before header serialization/final callbacks/known exit. Neither is terminal total. Same invocation ceiling through last callback. No callbacks after work-stop except failure metadata closure without subject calls.',
        failures='Bounded worker-failure.json metadata with started/returned/raised actual counters, completed row IDs and compact diagnostic prefix. On metadata failure a small UNAVAILABLE marker is attempted; primary first Root fault wins. Pre-session malformed intake may have only outer error evidence. No partial proof, resumption, retry, or false acceptance.'))
    contract=save('Source-contract-v1.json',dict(schema='complete-wang-calibration-worker-Source-contract-v1',**common,
        Source=pin(WORKER),API=api,profile=profile,components=components,input=capsule,
        parent_outer_reference=pin(ROOT/'run_wang_encoding_once_v4.py'),
        public_calls=['compiler.compile_palette','compiler.compile_finite_problem','search.search','verifier.verify','oracle.audit_snapshot','oracle.is_own_limit'],
        explicitly_declared_private_calls=['verifier._Budget(check,limits)','verifier._palette(raw,budget)',
            'verifier._machine(raw,budget)','verifier._configuration(tape,head,state,budget)',
            'verifier._global_transition(tape,head,state,parsed_machine,budget)'],
        constructor_fixture='compiler.CompileLimit(planned_foreign,0) is a separately counted Source constructor solely for F02 exact identity; no forged private tokens.',
        argument_scope='Complete canonical input guards around declared calls; tuple/array normalization is explicit JSON projection. Operational private verifier budget counters are permitted side effects; parsed whole-machine table is dynamically projected/re-read for transition guards. U01 alone permits exactly its declared persistent owned carrier mutation and checks the exact expected changed whole argument; original input capsule unaffected.',
        guard_scope='All seven raw scientific/control Source descriptors and recursively walked owned callable/code/default identities checked around target calls; full stdlib runtime descriptors intake/final. Not a hostile process, mutable-default-content, dynamic-loader, OS, closure-cell or arbitrary concurrent mutation seal.',
        reference_scope='Uses independently authored-from-search verifier whole-machine entries only AFTER each search result; no reference answer/history is supplied to search. Reference InvalidCertificate from a typed global transition is retained as finite nonacceptance/escape/halting for exactH. No infinite nonhalting or FOL claim.',
        fault_scope='First genuine Root clock/count/Source/argument-policy fault latched; rethrown before every diagnostic expected-error interpretation. F03/F04 test only declared initial BaseException path; no expanded fault bank or universal exception coverage. Oracle owner module-wide; search/verifier owner per call; compiler legacy own-limit provenance is exact Source/class/limits/context, no private token.',
        ancestry='Library authored compiler/search/verifier and worker, plus older point/Model/evidence components. B independently authored snapshot census. All current records are author-static Source argument, not an independent own Source certificate. Root owns outer/plans; C must review full seven-Source/prospective coupling.',
        remaining_gaps=['No worker or component import/call/fixture/simulation executed.',
            'No current runtime/dependency closure, prospective plan, current independent full-Source review or max-one grant produced here.',
            'All original compiler objects retained live can itself be memory expensive; full guard/JSON/census/rollback costs may exceed180/1GiB. No measured cost or fit prediction.',
            'Only finite authored machines/bounds; no fixed FOL checker/palette, Native proof, production pipeline, learned marks/RL or performance advantage.'],
        production_status='FROZEN_UNEXECUTED_PENDING_FULL_REVIEW_AND_EXACT_ROOT_GRANT'))
    audit=save('author-static-audit-v1.json',dict(schema='complete-wang-worker-author-static-audit-v1',**common,
        Source=pin(WORKER),checks=checks,check_count=len(checks),unused_compiles=4,
        target_imports=0,target_calls=0,Source_imports=imports,
        limits='Raw patterns/AST/unused compile do not prove algorithm/diagnostic outcomes or replace the distinct peer. No test pass is claimed.'))
    handoff=save('handoff-v1.json',dict(schema='complete-wang-calibration-worker-handoff-v1',**common,
        Source=pin(WORKER),API=api,Source_contract=contract,profile=profile,author_static_audit=audit,
        author_Source=pin(__file__),input=capsule,components=components,
        snapshot_oracle_handoff=pin('/private/tmp/gcts-wang-snapshot-oracle-20261019/handoff-v1.json'),
        status='SOURCE_ONLY_INACTIVE_NO_GRANT',tools_stopped_after_handoff=True))
    print(json.dumps(dict(Source=pin(WORKER),API=api,profile=profile,handoff=handoff,checks=len(checks),component_calls=0),sort_keys=True))


if __name__=='__main__':
    main()
