"""UNEXECUTED independent finite unit-center point/mark snapshot census.

No compiler, local update, search, verifier, solver, fixture or loader imports.
Declared parent exclusions are subtracted, never certified sound by this audit.
"""
VERSION = 'independent-finite-wang-snapshot-oracle-v1'
CALLBACK_CADENCE = 1024
_OWNER = object()
LIMIT_KEYS = ('work','points','candidates','mark_points','placements',
              'exclusions','trail_entries','metadata_entries')
SNAPSHOT_KEYS = ('schema','reason','points','candidates','chosen','marks','forward',
    'reverse','dependencies','boundary','exclusions','scheduler','trail_length','work','authority')
OFFSETS = ((0,-1),(1,0),(0,1),(-1,0))


class SnapshotDataError(ValueError):
    pass


class SnapshotLimit(RuntimeError):
    def __init__(self,reason,attempted_work,*,_owner=None):
        self.reason=reason;self.attempted_work=attempted_work;self._owner=_owner
        super().__init__(reason)


def is_own_limit(error):
    return type(error)is SnapshotLimit and error._owner is _OWNER


def _need(ok,reason):
    if not ok:raise SnapshotDataError(reason)


class _Work:
    def __init__(self,check,limits):
        _need(callable(check),'explicit external check')
        _need(type(limits)is dict and all(type(k)is str for k in limits) and
              set(limits)==set(LIMIT_KEYS),'all exact private limits')
        for value in limits.values():
            _need(type(value)is int and value>0,'positive exact-int private limit')
        self.check=check;self.limits=dict(limits);self.work=0
        check()
    def step(self):
        self.work+=1
        if self.work>self.limits['work']:
            raise SnapshotLimit('work',self.work,_owner=_OWNER)
        if self.work%CALLBACK_CADENCE==0:
            self.check()  # Direct call preserves every exact foreign object.
    def bound(self,key,value):
        self.step()
        if value>self.limits[key]:raise SnapshotLimit(key,self.work,_owner=_OWNER)


def _integer(value,reason,low=0):
    _need(type(value)is int and value>=low,reason);return value


def _point(value):
    _need(type(value)is list and len(value)==2,'literal two-int point')
    _need(all(type(x)is int for x in value),'exact integer point coordinates')
    return (value[0],value[1])


def _same(left,right,w):
    """Full exact typed structures, no digest or bool/int equality shortcut."""
    pending=[(left,right)]
    while pending:
        w.step();a,b=pending.pop()
        if type(a)is not type(b):return False
        kind=type(a)
        if kind is list:
            if len(a)!=len(b):return False
            for i in range(len(a)):pending.append((a[i],b[i]))
        elif kind is dict:
            if len(a)!=len(b) or set(a)!=set(b) or any(type(k)is not str for k in a):return False
            for key in a:pending.append((a[key],b[key]))
        elif kind in(str,int,bool) or a is None:
            if a!=b:return False
        else:return False
    return True


def audit_snapshot(instance,snapshot,*,check,limits):
    """Finite schema already validated separately; no F/TM semantics imported.

    Owner retains complete input/snapshot/result and sums audit work across
    calls. Exclusive input ownership and read-only external callbacks required.
    """
    w=_Work(check,limits)
    _need(type(instance)is dict and instance.get('schema')=='finite-framed-wang-instance-v1',
          'validated finite framed instance required')
    _need(type(snapshot)is dict and len(snapshot)==len(SNAPSHOT_KEYS) and
          set(snapshot)==set(SNAPSHOT_KEYS),'exact snapshot fields')
    _need(snapshot['schema']=='finite-wang-complete-graph-snapshot-v1' and
          snapshot['authority']is False,'exact inactive snapshot schema')
    _need(snapshot['reason']in ('INITIAL','STATE','ROLLBACK','ROOT_RESTORED'),'snapshot reason')
    width=_integer(instance['board_width'],'positive board width',1)
    height=_integer(instance['board_height'],'positive board height',1)
    w.bound('points',width*height)
    _need(type(instance['all_root_generations'])is int and instance['all_root_generations']==0,
          'unit-center generation-zero profile only')
    _need(type(instance['required_centers'])is list and type(instance['admissible_origins'])is list,
          'literal complete points/origins')
    origins=[]
    for y in range(height):
        for x in range(width):w.step();origins.append((2*x,2*y))
    origin_rows=[[x,y]for x,y in origins]
    _need(_same(instance['required_centers'],origin_rows,w) and
          _same(instance['admissible_origins'],origin_rows,w),'full row-major required origins')
    palette=instance['palette']
    _need(type(palette)is dict and palette['transformations']=='translations_only_2Z2' and
          palette['point_profile']=='integer-center-midpoint-translation-only-v1' and
          palette['edge_order']=='NESW','exact point/translation profile')
    tiles=palette['tiles'];colors=palette['color_constructors']
    _need(type(tiles)is list and bool(tiles) and type(colors)is list and bool(colors),
          'full nonempty literal palette')
    size=len(tiles);universe=len(origins)*size;w.bound('candidates',universe)
    tile_marks=[]
    for tid,tile in enumerate(tiles):
        w.step();_need(type(tile)is dict and type(tile['id'])is int and tile['id']==tid,
                     'every distinct ordered palette ID')
        _need(_same(tile['t'],[[[0,0],1]],w),'unit-center t only; fractional profile unsupported')
        edges=tile['edges_NESW'];_need(type(edges)is list and len(edges)==4,'four exact edge values')
        expected=[];local=[]
        for (dx,dy),color in zip(OFFSETS,edges):
            w.step();_integer(color,'exact nonnegative color ID')
            _need(color<len(colors),'color inside declared full palette')
            expected.append([[dx,dy],'edge',color]);local.append((dx,dy,color))
        _need(_same(tile['m'],expected,w),'every assigned midpoint, including color zero')
        tile_marks.append(local)

    boundary={}
    fixed=instance['fixed_background_marks']
    _need(type(fixed)is list,'complete fixed boundary section')
    for row in fixed:
        w.step();_need(type(row)is list and len(row)==3 and row[1]=='edge','literal boundary marking')
        p=_point(row[0]);color=_integer(row[2],'fixed color ID')
        _need(color<len(colors) and p not in boundary,'unique fixed midpoint/color')
        boundary[p]=color;w.bound('mark_points',len(boundary))
    words=instance['boundary_NESW']
    _need(type(words)is list and len(words)==4,'full boundary words')
    declared={}
    for side,word in enumerate(words):
        w.step();length=width if side in(0,2)else height
        _need(type(word)is list and len(word)==length,'exact boundary word length')
        for index,color in enumerate(word):
            w.step();_integer(color,'boundary word color');_need(color<len(colors),'boundary color range')
            p=((2*index,-1)if side==0 else(2*width-1,2*index)if side==1 else
               (2*index,2*height-1)if side==2 else(-1,2*index))
            _need(p not in declared,'nonduplicate exterior midpoint');declared[p]=color
    _need(boundary==declared,'all boundary midpoint pins exactly retained')

    raw_chosen=snapshot['chosen'];_need(type(raw_chosen)is list,'chosen rows')
    w.bound('placements',len(raw_chosen));_need(len(raw_chosen)<=len(origins),'at most one per point')
    chosen=[];chosen_ids=set();occupied=[0]*len(origins)
    marks={p:[color,1,True]for p,color in boundary.items()}
    for row in raw_chosen:
        w.step();_need(type(row)is list and len(row)==4,'chosen exact row')
        cid=_integer(row[0],'chosen candidate ID');_need(cid<universe and cid not in chosen_ids,'unique chosen ID')
        pi,tid=divmod(cid,size)
        _need(_same(row,[cid,pi,tid,1],w),'chosen ID,origin,tile,generation1 join')
        _need(occupied[pi]==0,'chosen positive-t overlap forbidden');occupied[pi]=1
        chosen_ids.add(cid);chosen.append([cid,pi,tid,1]);ox,oy=origins[pi]
        for dx,dy,color in tile_marks[tid]:
            w.step();p=(ox+dx,oy+dy)
            if p in marks:
                _need(marks[p][0]==color,'chosen marking disagreement');marks[p][1]+=1
            else:marks[p]=[color,1,False]
            w.bound('mark_points',len(marks))
    chosen.sort()
    _need(_same(raw_chosen,chosen,w),'sorted complete chosen rows')

    exclusions=snapshot['exclusions'];_need(type(exclusions)is list,'declared current-context exclusions')
    w.bound('exclusions',len(exclusions));excluded=set();last=-1
    for cid in exclusions:
        w.step();_integer(cid,'excluded candidate ID')
        _need(last<cid<universe and cid not in chosen_ids,'sorted unique in-range nonchosen exclusion')
        excluded.add(cid);last=cid
    # Exclusions can persist while another choice fills their point. Membership
    # in today's physical set is not required and does not prove failure sound.
    physical=[];active=[];candidate_rows=[];forward=[[]for p in origins]
    reverse=[];m_dependencies={};t_dependencies=[]
    for pi,(ox,oy) in enumerate(origins):
        w.step();at_origin=[]
        for tid in range(size):
            w.step();cid=pi*size+tid;at_origin.append(cid);legal=occupied[pi]==0
            for dx,dy,color in tile_marks[tid]:
                w.step();p=(ox+dx,oy+dy)
                m_dependencies.setdefault(p,[]).append(cid)
                if p in marks and marks[p][0]!=color:legal=False
            if legal:physical.append(cid)
            is_active=legal and cid not in excluded
            candidate_rows.append([cid,pi,tid,is_active])
            reverse.append([cid,[pi]if is_active else []])
            if is_active:active.append(cid);forward[pi].append(cid)
        t_dependencies.append(['t',pi,at_origin])
    w.bound('mark_points',len(m_dependencies))
    dependencies=t_dependencies
    for p in sorted(m_dependencies):
        w.step();dependencies.append(['m',[p[0],p[1]],m_dependencies[p]])
    frontier=[pi for pi,total in enumerate(occupied)if total==0]
    dead=[pi for pi in frontier if not forward[pi]]
    forced=[pi for pi in frontier if len(forward[pi])==1]
    if dead:kind='DEAD';point=min(dead)
    elif forced:kind='FORCED';point=min(forced)
    elif frontier:kind='BRANCH';point=min(frontier,key=lambda pi:(0,len(forward[pi]),pi))
    else:kind='COMPLETE';point=None
    scheduler=dict(kind=kind,point=point,options=[]if point is None else list(forward[point]))
    expected=dict(points=[[pi,[x,y],occupied[pi],0]for pi,(x,y)in enumerate(origins)],
        candidates=candidate_rows,chosen=chosen,
        marks=[[[p[0],p[1]],value[0],value[1],value[2]]for p,value in sorted(marks.items())],
        forward=[[pi,options]for pi,options in enumerate(forward)],reverse=reverse,
        dependencies=dependencies,boundary=[[[p[0],p[1]],color]for p,color in sorted(boundary.items())],
        exclusions=list(exclusions),scheduler=scheduler)
    for field,value in expected.items():
        _need(_same(snapshot[field],value,w),'full independent snapshot mismatch: '+field)
    trail=_integer(snapshot['trail_length'],'nonnegative trail length');w.bound('trail_entries',trail)
    diagnostic=snapshot['work'];_need(type(diagnostic)is dict,'passive ordinary work counters')
    w.bound('metadata_entries',len(diagnostic))
    for key,value in diagnostic.items():
        w.step();_need(type(key)is str,'counter name');_integer(value,'nonnegative exact-int counter')
    if snapshot['reason']in('INITIAL','ROOT_RESTORED'):
        _need(not chosen and not exclusions and trail==0,'complete initial/root-restored context')
    expected['trail_length']=trail
    w.step();check()
    return dict(schema='independent-finite-wang-snapshot-audit-v1',version=VERSION,
        status='EXACT_FINITE_POINT_CENSUS_MATCH',census=expected,
        physically_legal_candidates=physical,active_candidates=active,
        frontier=frontier,audit_work=w.work,
        exclusion_scope='Declared current-parent exclusions subtracted only; their exhausted-child proof and rollback soundness are NOT established by this snapshot census.',
        rollback_scope='Full census/trail returned for owner full-value paired restoration checks. Reason/work history excluded; no digest-only acceptance.',
        authority=False,exclusion_soundness_certified=False,formal_kernel_certified=False,
        general_fractional_or_mixed_generation_engine_qualified=False,
        actual_execution_authorized=False)
