"""Root static review of the new proposal delta; never imports/evaluates it."""
import ast,hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
S=Path('/private/tmp/gcts-recursive-receptor-source-20261019')
P=Path('/private/tmp/gcts-and-support-point-source-20261018/semantic_inventory_search_v2.py')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def callables(p):
 out={}
 def visit(nodes,path=''):
  for n in nodes:
   if isinstance(n,(ast.ClassDef,ast.FunctionDef)):
    key=path+n.name;out[key]=ast.dump(n,include_attributes=False);visit(n.body,key+'.')
 visit(ast.parse(p.read_bytes()).body);return out
expected={'recursive_receptor_planner_v1.py':('66335c8cd72196c8527a91e61fd9bc6e70932e0bdb2623555b30f2be1e4e7e35',29433),
 'semantic_inventory_search_v3.py':('a52c21a856b35addd83e4fa468ba74f880ce98e2582134bb2c6e2a71118e81d7',20098)}
checks=[]
for file,(sha,count) in expected.items():
 p=S/file;b=p.read_bytes();assert (hashlib.sha256(b).hexdigest(),len(b))==(sha,count)
 compile(b,str(p),'exec');checks.append(dict(check=file+' exact raw identity and compile without evaluation',passed=True))
parent=callables(P);new=callables(S/'semantic_inventory_search_v3.py')
for k in ['_SupportDeadline','_ProjectionStop','_literal','_complete_rows','_support_choice','_support_choice.charge','search.support_check','search.review']:
 assert parent[k]==new[k];checks.append(dict(check='retained parent callable '+k,passed=True))
planner=ast.parse((S/'recursive_receptor_planner_v1.py').read_bytes())
imports=[]
for n in planner.body:
 if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
 elif isinstance(n,ast.ImportFrom):imports.append(n.module)
assert set(imports)=={'collections','json','math'}
checks.append(dict(check='planner imports only declared stdlib modules',passed=True))
manual=[
 'Logical expansion uses only current actual guard keys and complete C/G/all-input candidate rows; no case ID, preferred family or supplied target route.',
 'Ordered requirements retain actual strict-earlier source rows and literal formulas; one assigned producer row must satisfy every repeated demand consistently.',
 'Distinct member-key union counts a shared producer once; ordered ports remain separate. Final validator reconstructs whole packet, ancestry, height, members and ports.',
 'Admission requires complete compiler and full Native-admitted inventory at setup. Existing family level remains Native nesting; planner_depth is distinct.',
 'Point adapter calls graph.decision and requires the genuine branch/point before expanding anything. It does not select an alternative frontier point.',
 'Every proposed new member is checked against current state legality and all positive occupancy incidences in the graph; unchanged aggregate validates full t/m union.',
 'Only plans closed relative to justified selected rows become items. Open/depth/row-bound branches supply no fact credit or pruning authority.',
 'The first unchanged Join pool is retained in order and extras are appended. The original deferred None choice, arbitrary sampled items and base alternatives remain available.',
 'Existing vector, FIXED scores and optional shared support ordering consume the enlarged pool; no new scoring authority or logical proof acceptance is added.',
 'Visit retains global dead/forced/empty handling and single-key child copy/place/Graph.update, original base fallback, backtracking and initial state/graph restoration.',
 'Setup/proposal work uses the original search clock. Its own deadline gives UNKNOWN; other exceptions propagate. Planner own quota discards operative items when complete custody/validation cannot finish.',
 'Planner uses copied assignment maps. Before/after state and full forward/reverse graph snapshots detect mutation on completed calls; arbitrary hostile callback mutation is outside the protected callback premise.',
 'Per-call work/shape/key/aggregate bounds describe a bounded prefix, not exhaustive proof or impossibility evidence. Sorting/serialization are wall-clock bracketed, not formally individually metered Python operations.',
 'Fresh packet/known-row reconstruction shares helper code with proposal generation; it is not independent mathematical proof certification. Ordinary placement and fresh final Native acceptance remain required.',
 'Legacy remains the default proposal mode. Added imports/metadata/version/guard overhead mean no claim of byte-identical historical outputs or equal historical timing.',
 'Current driver/cold/once closure does not activate this Source. New authenticated Source closure, mode binding, resource qualification and actual final mathematical checks remain required.',
 'Root integrated and reviewed earlier components; this review covers the new Library-authored delta, not a new independent certificate of inherited Native/compiler/Model/search/helper soundness.',
 'No runtime test, scientific import/evaluation, solver, Native, Model, compiler, oracle, search, codec or proof replay was performed for this review.'
]
out=dict(review_script_correction='Initial assertion expected an unused hashlib import present in an earlier draft. Exact frozen Source imports collections/json/math only. Corrected the review assertion; no scientific Source changed.',schema='ROOT-recursive-receptor-delta-static-review-v1',reviewer='/root',author='/root/conventional_library',source_only=True,
 source_review_passed=True,blocking_findings=[],checks=checks,manual_observations=manual,
 sources=[pin(S/f) for f in expected],parent=pin(P),master=pin(Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')),
 scientific_calls=0,scientific_imports=0,runtime_qualified=False,actual_executions=0,
 conformance='Advice-only optional proposer, full graph scheduler/base fallback retained; runtime and complete proof validity require future charged qualification.',
 limitation='Static reasoning and compile-without-evaluation do not establish useful nonempty proposals, improved runtime, completeness, new theorems, learned RL or a GCTS-specific advantage.')
p=D/'ROOT-recursive-source-review-v1.json';assert not p.exists();p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(pin(p)))
