"""Retained JSON arithmetic only; no project imports or Native/program decoding."""
from pathlib import Path
import hashlib
import json
from collections import Counter

O=Path('/private/tmp/gcts-grouped-certification-analysis-20261019')
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
P=Path('/private/tmp/gcts-inventory-certification-plans-ROOT-20261018-v1')
G=R/'.gcts-active/inventory-certification-progress-20261018'
O.mkdir(exist_ok=True)
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(value):return hashlib.sha256(canon(value)).hexdigest()
def pin(path):
 p=Path(path).resolve();h=hashlib.sha256();size=0
 with p.open('rb')as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b);size+=len(b)
 return dict(path=str(p),sha256=h.hexdigest(),bytes=size)
def load(path):return json.loads(Path(path).read_bytes())
def save(name,value):
 p=O/name;p.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
checks=[]
def check(label,condition):
 checks.append(dict(check=label,passed=bool(condition)))
 if not condition:raise AssertionError(label)

idx=load(P/'authorized-index-v1.json')
check('exact admitted authorized20 index',pin(P/'authorized-index-v1.json')['sha256']=='419adfa495ea3f1a90be681deb3de25c0d4cf309b1d99437c01bdc2b343fb512' and len(idx['schedule'])==20)
check('exact Root admission',pin(G/'ROOT-actual-admission-v1.json')['sha256']=='3652461f48873a7e669a18d458d5a255779300abbf2af15b8d2f217a5f2e5efc')
check('exact live final',pin(G/'ROOT-live-final-v1.json')['sha256']=='6c0da6d12487e87bab9a7bcdc8b55ec1de9f41a3a77f2ed68cb834d4aa28472c')
samples=[];rows=[]
for row in idx['schedule']:
 a=Path(row['actual_directory']);header=load(a/'worker-receipt.json')
 check(row['invocation_id']+' exact rawresult pin',pin(a/'result.json')==header['result'])
 d=load(a/'result.json');records=d['records']
 baselines=[x for x in records if x['purpose']=='first_order_theory_admission']
 check(row['invocation_id']+' one exact emptyblocks admission',len(baselines)==1 and baselines[0]['id']==0 and baselines[0]['result']['status']=='accepted' and baselines[0]['request']['blocks']==[])
 baseline=baselines[0];registry=[x for x in records if x['purpose'] in ('check_generated_lemma_definitions','check_generated_lemma_definition_closure')]
 check(row['invocation_id']+' registry stage present',bool(registry))
 context={k:v for k,v in baseline['request'].items() if k!='blocks'}
 for q in [baseline]+registry:
  check(row['invocation_id']+' exact request hash '+str(q['id']),q['request_sha256']==sha(q['request']))
  check(row['invocation_id']+' same fulltheory protocol rootproof and target '+str(q['id']),{k:v for k,v in q['request'].items() if k!='blocks'}==context)
 registered=d['outputs']['register'];total=len(registered['definitions'])
 accepted=[x for x in registry if x['result']['status']=='accepted'];failed=[x for x in registry if x['result']['status']!='accepted']
 check(row['invocation_id']+' stopped at first nonaccepted request',not failed or len(failed)==1 and failed[0] is registry[-1])
 T=baseline['result']['micro_steps'];success_steps=sum(x['result']['micro_steps']for x in accepted);used=sum(x['result']['micro_steps']for x in registry)
 cert=registered.get('certification')
 if row['inventory_certification_mode']=='dependency_closures':
  check(row['invocation_id']+' all issued closures singleton',all(len(x['request']['blocks'])==1 for x in registry))
  check(row['invocation_id']+' retained complete planned root denominator',len(cert['planned_requests'])==total)
  check(row['invocation_id']+' literal recipe receipts join counters',len(cert['receipts'])==len(registry) and cert['aggregate_consumed_micro_steps']==used)
  planned_max=max((len(x['names'])for x in cert['planned_requests']),default=0)
  covered=len(cert['accepted_definition_names']);pending=total-len(registry)
 else:
  check(row['invocation_id']+' bulk includes every original definition',len(registry)==1 and len(registry[0]['request']['blocks'])==total)
  planned_max=None;covered=total if not failed else 0;pending=0
 out=dict(invocation_id=row['invocation_id'],receiver_id=row['receiver_id'],mode=row['mode'],certification_mode=row['inventory_certification_mode'],raw_result=header['result'],worker_receipt=pin(a/'worker-receipt.json'),theory_sha256=sha(context['theory']),empty_request_sha256=baseline['request_sha256'],empty_query_id=baseline['id'],empty_request_canonical_bytes=len(canon(baseline['request'])),empty_request_steps=T,empty_request_host_seconds=baseline['seconds'],empty_request_cpp_seconds=baseline['result']['seconds'],registry_query_ids=[x['id']for x in registry],registry_request_steps=[x['result']['micro_steps']for x in registry],registry_request_statuses=[x['result']['status']for x in registry],registry_request_block_counts=[len(x['request']['blocks'])for x in registry],registry_total_steps=used,registry_accepted_query_count=len(accepted),registry_accepted_query_steps=success_steps,registry_accepted_definition_count=covered,total_original_definitions=total,never_issued_original_roots=pending,not_qualified_original_definitions=total-covered,planned_max_closure_definitions=planned_max,registry_host_seconds=sum(x['seconds']for x in registry),registry_cpp_seconds=sum(x['result']['seconds']for x in registry),registry_host_minus_cpp_seconds_reference=sum(x['seconds']-x['result']['seconds']for x in registry),registry_stage_seconds=next(x['returned_monotonic']-x['started_monotonic']for x in d['stage_intervals']if x['stage']=='register'),last_status=registry[-1]['result']['status'],last_state=registry[-1]['result']['state'],last_physical_head=registry[-1]['result']['physical_head'])
 if cert is not None:
  out['accepted_prefix_empty_multiple_reference']=len(accepted)*T
  out['accepted_prefix_steps_minus_empty_multiple_reference']=success_steps-len(accepted)*T
  out['accepted_prefix_extra_empty_references_vs_one']=max(0,len(accepted)-1)*T
  out['issued_extra_empty_references_vs_one']=max(0,len(registry)-1)*T
  out['full_inventory_empty_multiple_reference']=total*T
  out['accepted_prefix_minmax_steps']=[min(x['result']['micro_steps']for x in accepted),max(x['result']['micro_steps']for x in accepted)] if accepted else None
 rows.append(out)
 samples.append(dict(invocation_id=row['invocation_id'],raw_result=header['result'],baseline=baseline,registration_records=registry,retained_certification=cert))

case_rows=[]
for cid in dict.fromkeys(x['receiver_id']for x in rows):
 rr=[x for x in rows if x['receiver_id']==cid];b=[x for x in rr if x['certification_mode']=='bulk'];s=[x for x in rr if x['certification_mode']=='dependency_closures']
 check(cid+' four original method by certification slots',len(rr)==4 and len(b)==len(s)==2)
 check(cid+' deterministic baseline wholepreimage and counter all4',len({(x['empty_request_sha256'],x['empty_request_steps'])for x in rr})==1)
 for mode,aa in [('bulk',b),('dependency_closures',s)]:
  check(cid+' fixedsymbolic literal requests and deterministic counters '+mode,len({tuple(x['registry_request_steps'])for x in aa})==1)
  samples_a=next(x for x in samples if x['invocation_id']==aa[0]['invocation_id'])
  samples_b=next(x for x in samples if x['invocation_id']==aa[1]['invocation_id'])
  check(cid+' exact paired request preimages '+mode,[q['request']for q in samples_a['registration_records']]==[q['request']for q in samples_b['registration_records']])
 cb=b[0];cs=s[0]
 case_rows.append(dict(receiver_id=cid,total_definitions=cb['total_original_definitions'],empty_request_steps=cb['empty_request_steps'],empty_request_canonical_bytes=cb['empty_request_canonical_bytes'],bulk_steps=cb['registry_total_steps'],bulk_status=cb['last_status'],single_total_steps=cs['registry_total_steps'],single_status=cs['last_status'],single_accepted_definitions=cs['registry_accepted_definition_count'],single_issued_requests=len(cs['registry_query_ids']),single_unqualified_definitions=cs['not_qualified_original_definitions'],single_never_issued_roots=cs['never_issued_original_roots'],planned_max_closure_definitions=cs['planned_max_closure_definitions'],issued_max_closure_definitions=max(cs['registry_request_block_counts']),single_successful_prefix_steps=cs['registry_accepted_query_steps'],accepted_prefix_extra_empty_reference_vs_one=cs['accepted_prefix_extra_empty_references_vs_one'],accepted_prefix_steps_minus_empty_reference=cs['accepted_prefix_steps_minus_empty_multiple_reference'],full_inventory_empty_reference=cs['full_inventory_empty_multiple_reference'],bulk_minus_single_steps_only_comparable_if_bothcomplete=cb['registry_total_steps']-cs['registry_total_steps'] if cb['last_status']==cs['last_status']=='accepted' else None,sample_invocations=[x['invocation_id']for x in rr]))
sample_pin=save('saved-request-samples-v1.json',dict(schema='grouped-certification-retained-request-samples-v1',saved_data_only=True,scientific_calls=0,scientific_acceptance=False,rows=samples))
cost_pin=save('saved-cost-decomposition-v1.json',dict(schema='grouped-certification-saved-cost-decomposition-v1',saved_data_only=True,scientific_calls=0,scientific_acceptance=False,rows=rows,cases=case_rows,baseline_scope='Exactly measured full-theory empty-block trivial-root admission, not an isolated Native phase. All baseline multiples and differences are arithmetic references, never lower/upper bounds or savings predictions. Host-minus-CPP duration is an arithmetic timing difference, not a semantic phase decomposition.'))
audit_pin=save('retained-analysis-audit-v1.json',dict(schema='grouped-certification-retained-analysis-audit-v1',source_only=True,saved_data_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,reviewer_identity='/root/conventional_control_review',check_count=len(checks),mismatch_count=0,checks=checks,index=pin(P/'authorized-index-v1.json'),Root_admission=pin(G/'ROOT-actual-admission-v1.json'),Root_live_final=pin(G/'ROOT-live-final-v1.json'),samples=sample_pin,costs=cost_pin,analysis_Source=pin(Path(__file__))))
print(json.dumps(dict(cases=case_rows,check_count=len(checks),samples=sample_pin,costs=cost_pin,audit=audit_pin),indent=2))
