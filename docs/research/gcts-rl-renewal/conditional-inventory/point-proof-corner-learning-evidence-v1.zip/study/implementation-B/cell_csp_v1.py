"""Independent finite unit-anchor CSP.  Inert until a reviewed once invocation.

No point-engine, compiler, learner or checker imports/calls.  Literal maps are
exported as exact seed unaries and sparse cell-pair allowed-row bitmasks.
The controller is forward checking, not arc consistency.  There is no IO/CLI.
"""

import copy
import hashlib
import json


VERSION = "FINITE-UNIT-CELL-CSP-v1"
MODEL_SCHEMA = "GCTS-finite-point-instance-v1"
SPEC_SCHEMA = "GCTS-unit-cell-csp-spec-v1"
STATE_SCHEMA = "GCTS-unit-cell-normalized-state-v1"
RESULT_SCHEMA = "GCTS-unit-cell-csp-solve-result-v1"
CERTIFICATE_SCHEMA = "GCTS-unit-cell-csp-certificate-v1"
_POLICY = (("empty", "GLOBAL_LEX_POINT"), ("forced", "GLOBAL_LEX_POINT"),
           ("branch", "MIN_GENERATION_DOMAIN_POINT"), ("value", "LEX_ID"),
           ("generation", "ALL_REQUIRED_ROOT_0"))
_MODEL = "CSP_MODEL_INVALID"
_PROFILE = "CSP_PROFILE_UNSUPPORTED"
_SPEC = "CSP_SPEC_INVALID"
_OP = "CSP_OPERATION_INVALID"
_LIMIT = "CSP_NODE_LIMIT_INVALID"
_CALLBACK = "CSP_CALLBACK_INVALID"


class CSPError(ValueError):
    """Owned data/operation refusal; message is one fixed public code."""


class CSPBudgetExceeded(RuntimeError):
    """Cooperative interruption, never an UNSAT certificate."""


def _require(ok, code):
    if not ok:
        raise CSPError(code)


def _record(value, fields, code):
    _require(type(value) is dict and set(value) == set(fields), code)


def _point(value, code):
    _require(type(value) is list and len(value) == 2
             and all(type(v) is int for v in value), code)
    return tuple(value)


def _literal(value, code):
    _require(type(value) is str, code)
    return value


def _exact_equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return (set(left) == set(right)
                and all(_exact_equal(left[k], right[k]) for k in right))
    if type(left) is list:
        return (len(left) == len(right)
                and all(_exact_equal(a, b) for a, b in zip(left, right)))
    return left == right


def _canonical_bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def _digest(value):
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _model(model):
    """Independent complete raw-schema validation, before unit restriction."""
    _record(model, ("schema", "capacity", "required", "placements", "seeds"), _MODEL)
    _require(type(model["schema"]) is str and model["schema"] == MODEL_SCHEMA, _MODEL)
    cap = model["capacity"]
    _require(type(cap) is int and cap > 0, _MODEL)
    _require(type(model["required"]) is list, _MODEL)
    required = set()
    for row in model["required"]:
        point = _point(row, _MODEL)
        _require(point not in required, _MODEL)
        required.add(point)
    _require(type(model["placements"]) is list, _MODEL)
    placements = {}
    for row in model["placements"]:
        _record(row, ("id", "type", "translation", "t", "m"), _MODEL)
        pid = _literal(row["id"], _MODEL)
        _literal(row["type"], _MODEL)
        _require(pid not in placements, _MODEL)
        translation = _point(row["translation"], _MODEL)
        _require(type(row["t"]) is list and row["t"], _MODEL)
        positive = {}
        for term in row["t"]:
            _require(type(term) is list and len(term) == 3, _MODEL)
            point = _point(term[:2], _MODEL)
            units = term[2]
            _require(type(units) is int and 0 < units <= cap and point not in positive, _MODEL)
            positive[point] = units
        _require(type(row["m"]) is list, _MODEL)
        marking = {}
        for term in row["m"]:
            _require(type(term) is list and len(term) == 4, _MODEL)
            point = _point(term[:2], _MODEL)
            channel = _literal(term[2], _MODEL)
            value = _literal(term[3], _MODEL)
            slot = point + (channel,)
            _require(slot not in marking, _MODEL)
            marking[slot] = value
        placements[pid] = {
            "id": pid, "type": row["type"], "translation": list(translation),
            "t": [[p[0], p[1], positive[p]] for p in sorted(positive)],
            "m": [[s[0], s[1], s[2], marking[s]] for s in sorted(marking)],
        }
    _require(type(model["seeds"]) is list, _MODEL)
    seeds, seen = [], set()
    for pid in model["seeds"]:
        _literal(pid, _MODEL)
        _require(pid in placements and pid not in seen, _MODEL)
        seeds.append(pid)
        seen.add(pid)
    for pid, row in placements.items():
        _require(pid in seen or any(tuple(t[:2]) in required for t in row["t"]), _MODEL)
    totals, marking = {}, {}
    for pid in seeds:
        for x, y, units in placements[pid]["t"]:
            point = (x, y)
            totals[point] = totals.get(point, 0) + units
            _require(totals[point] <= cap, _MODEL)
        for x, y, channel, value in placements[pid]["m"]:
            slot = (x, y, channel)
            _require(slot not in marking or marking[slot] == value, _MODEL)
            marking[slot] = value
    return {
        "schema": MODEL_SCHEMA, "capacity": cap,
        "required": [list(p) for p in sorted(required)],
        "placements": [placements[pid] for pid in sorted(placements)], "seeds": seeds,
    }


def _build_spec(model):
    """Build from a privately normalized model; never call public entries."""
    _require(model["capacity"] == 1
             and all(len(row["t"]) == 1 and row["t"][0][2] == 1
                     for row in model["placements"]), _PROFILE)
    placements = {row["id"]: row for row in model["placements"]}
    anchors = {pid: tuple(row["t"][0][:2]) for pid, row in placements.items()}
    seeds = set(model["seeds"])
    occupied = {anchors[pid] for pid in seeds}
    points = sorted(set(tuple(p) for p in model["required"]) - occupied)
    domains = {point: [] for point in points}
    preprocessed = []
    for pid in sorted(placements):
        point = anchors[pid]
        if pid in seeds:
            preprocessed.append({"id": pid, "anchor": list(point), "reason": "SEED_SELECTED"})
        elif point in occupied:
            preprocessed.append({"id": pid, "anchor": list(point), "reason": "SEED_ANCHOR_OCCUPIED"})
        else:
            domains[point].append(pid)
    maps = {pid: {tuple(r[:3]): r[3] for r in row["m"]}
            for pid, row in placements.items()}
    unaries = []
    for pid in sorted(pid for domain in domains.values() for pid in domain):
        conflicts = []
        for seed in sorted(seeds):
            slots = sorted(s for s, value in maps[pid].items()
                           if s in maps[seed] and maps[seed][s] != value)
            if slots:
                conflicts.append({"seed": seed, "slots": [list(s) for s in slots]})
        unaries.append({"id": pid, "allowed": not conflicts, "seed_conflicts": conflicts})
    # A slot index preserves absence as unconstrained and discovers all distant
    # contacts. Only non-universal cell pairs acquire a rowmask table.
    slots = {}
    for point in points:
        for index, pid in enumerate(domains[point]):
            bit = 1 << index
            for slot, value in maps[pid].items():
                groups = slots.setdefault(slot, {}).setdefault(point, {})
                groups[value] = groups.get(value, 0) | bit
    tables = {}
    for slot in sorted(slots):
        groups = slots[slot]
        incident = sorted(groups)
        for i, left in enumerate(incident):
            for right in incident[i + 1:]:
                for value, left_bits in groups[left].items():
                    bad = 0
                    for other_value, right_bits in groups[right].items():
                        if value != other_value:
                            bad |= right_bits
                    if not bad:
                        continue
                    key = (left, right)
                    if key not in tables:
                        tables[key] = [(1 << len(domains[right])) - 1] * len(domains[left])
                    bits = left_bits
                    while bits:
                        low = bits & -bits
                        tables[key][low.bit_length() - 1] &= ~bad
                        bits -= low
    binary = []
    for (left, right), masks in sorted(tables.items()):
        full = (1 << len(domains[right])) - 1
        if any(mask != full for mask in masks):
            binary.append({"left": list(left), "right": list(right), "allowed_rows": masks})
    return {
        "schema": SPEC_SCHEMA, "model": model,
        "variables": [{"point": list(p), "generation": 0, "domain": domains[p]} for p in points],
        "unaries": unaries, "binary": binary, "preprocessed": preprocessed,
        "policy": dict(_POLICY),
    }


def export_unit_cell_csp(model):
    """Pure detached export of the complete explicit unit-anchor universe."""
    return _build_spec(_model(model))


def _checked_spec(spec):
    _record(spec, ("schema", "model", "variables", "unaries", "binary", "preprocessed", "policy"), _SPEC)
    try:
        expected = _build_spec(_model(spec["model"]))
    except CSPError:
        raise CSPError(_SPEC) from None
    _require(_exact_equal(spec, expected), _SPEC)
    return expected


class CellCSP:
    """Reference forward checking with delta-trail restoration and proof tree."""

    def __init__(self, csp_spec, audit=None, budget=None):
        _require(audit is None or callable(audit), _CALLBACK)
        _require(budget is None or callable(budget), _CALLBACK)
        self._spec = _checked_spec(csp_spec)
        self._model = self._spec["model"]
        self._model_sha = _digest(self._model)
        self._spec_sha = _digest(self._spec)
        self._audit, self._budget = audit, budget
        self._in_callback = False
        self._solving = False
        self._placements = {p["id"]: p for p in self._model["placements"]}
        self._anchors = {pid: tuple(row["t"][0][:2]) for pid, row in self._placements.items()}
        self._points = tuple(tuple(v["point"]) for v in self._spec["variables"])
        self._domains = {tuple(v["point"]): tuple(v["domain"]) for v in self._spec["variables"]}
        self._rank = {p: {pid: i for i, pid in enumerate(ids)} for p, ids in self._domains.items()}
        self._owners = {pid: p for p, ids in self._domains.items() for pid in ids}
        self._relations = {(tuple(r["left"]), tuple(r["right"])): tuple(r["allowed_rows"])
                           for r in self._spec["binary"]}
        self._neighbors = {p: set() for p in self._points}
        for left, right in self._relations:
            self._neighbors[left].add(right)
            self._neighbors[right].add(left)
        self._neighbors = {p: tuple(sorted(q)) for p, q in self._neighbors.items()}
        allowed = {r["id"] for r in self._spec["unaries"] if r["allowed"]}
        self._physical = {p: frozenset(pid for pid in ids if pid in allowed)
                          for p, ids in self._domains.items()}
        self._eligible = dict(self._physical)
        self._selected = list(self._model["seeds"])
        self._selected_ids = {pid: True for pid in self._selected}
        self._assigned = {}
        self._excluded = {}
        self._trail = []
        self._boundaries = {0}
        nseed = len(self._selected)
        self._counts = {
            "attempts": nseed, "accepted_base_placements": nseed,
            "seed_placements": nseed, "forced_placements": 0,
            "branch_decisions": 0, "backtracks": 0,
            "candidate_removals": {r: 0 for r in
                                   ("SELECTED", "EXCLUDED", "CAPACITY", "MARKING", "NO_FRONTIER")},
            "max_frontier_points": 0, "max_active_candidates": 0, "max_edges": 0,
        }
        self._measure(frozenset())
        self._guard()
        self._emit("INITIALIZED", {})

    @property
    def spec(self):
        return copy.deepcopy(self._spec)

    @property
    def metrics(self):
        result = copy.deepcopy(self._counts)
        active = self._active()
        result.update({"final_frontier_points": len(self._eligible),
                       "final_active_candidates": len(active), "final_edges": len(active)})
        return result

    def _active(self):
        return frozenset(pid for ids in self._eligible.values() for pid in ids)

    def snapshot(self):
        active = sorted(self._active())
        return {
            "schema": STATE_SCHEMA, "selected": list(self._selected),
            "assigned": [{"point": list(p), "id": self._assigned[p]} for p in sorted(self._assigned)],
            "excluded": [{"id": pid, "reason": self._excluded[pid]} for pid in sorted(self._excluded)],
            "physical_domains": [{"point": list(p), "candidates": sorted(self._physical[p])}
                                 for p in sorted(self._physical)],
            "eligible_domains": [{"point": list(p), "generation": 0,
                                  "candidates": sorted(self._eligible[p])} for p in sorted(self._eligible)],
            "active_candidates": active,
            "forward_incidence": [[p[0], p[1], pid, 1] for p in sorted(self._eligible)
                                  for pid in sorted(self._eligible[p])],
            "reverse_incidence": [{"id": pid, "points": [[self._owners[pid][0],
                                                          self._owners[pid][1], 1]]} for pid in active],
        }

    def checkpoint(self):
        return len(self._trail)

    def _entry(self):
        _require(not self._in_callback and not self._solving, _OP)

    def _guard(self):
        if self._budget is None:
            return
        self._in_callback = True
        try:
            result = self._budget()
        finally:
            self._in_callback = False
        if result is False:
            raise CSPBudgetExceeded("CSP_BUDGET_REFUSED")
        _require(result is None or result is True, _CALLBACK)

    def _emit(self, kind, data):
        if self._audit is None:
            return
        self._in_callback = True
        try:
            self._audit(self, {"kind": kind, "data": copy.deepcopy(data)})
        finally:
            self._in_callback = False

    def _set(self, name, key, value):
        table = getattr(self, name)
        existed = key in table
        old = table.get(key)
        if existed and old == value:
            return
        table[key] = value
        self._trail.append(("map", name, key, existed, old, True, value))

    def _delete(self, name, key):
        table = getattr(self, name)
        if key in table:
            old = table.pop(key)
            self._trail.append(("map", name, key, True, old, False, None))

    def _append_selected(self, pid):
        self._selected.append(pid)
        self._trail.append(("append", "_selected", None, False, None, True, pid))

    def _undo(self, checkpoint):
        while len(self._trail) > checkpoint:
            kind, name, key, existed, old, unused_exists, unused_new = self._trail.pop()
            table = getattr(self, name)
            if kind == "append":
                table.pop()
            elif existed:
                table[key] = old
            else:
                del table[key]
        self._boundaries = {c for c in self._boundaries if c <= checkpoint}

    def _redo(self, deltas):
        for delta in deltas:
            kind, name, key, unused_exists, unused_old, exists, value = delta
            table = getattr(self, name)
            if kind == "append":
                table.append(value)
            elif exists:
                table[key] = value
            else:
                del table[key]
            self._trail.append(delta)

    def _measure(self, old_active):
        active = self._active()
        for pid in old_active - active:
            if pid in self._selected_ids:
                reason = "SELECTED"
            elif pid in self._excluded:
                reason = "EXCLUDED"
            elif self._anchors[pid] in self._assigned:
                reason = "CAPACITY"
            elif pid not in self._physical.get(self._owners[pid], frozenset()):
                reason = "MARKING"
            else:
                reason = "NO_FRONTIER"
            self._counts["candidate_removals"][reason] += 1
        for key, value in (("max_frontier_points", len(self._eligible)),
                           ("max_active_candidates", len(active)), ("max_edges", len(active))):
            self._counts[key] = max(self._counts[key], value)

    def _check_id_reason(self, pid, reason):
        _literal(pid, _OP)
        _literal(reason, _OP)
        _require(pid in self._placements, _OP)

    def _allowed_with(self, point, pid, other):
        if point < other:
            rows = self._relations[(point, other)]
            mask = rows[self._rank[point][pid]]
            return frozenset(other_id for index, other_id in enumerate(self._domains[other])
                             if mask & (1 << index))
        rows = self._relations[(other, point)]
        bit = 1 << self._rank[point][pid]
        return frozenset(other_id for index, other_id in enumerate(self._domains[other])
                         if rows[index] & bit)

    def _place(self, pid, reason, forced=False):
        self._check_id_reason(pid, reason)
        self._counts["attempts"] += 1
        self._guard()
        point = self._owners.get(pid)
        _require(pid not in self._selected_ids and pid not in self._excluded
                 and point in self._physical and pid in self._physical[point], _OP)
        cp = len(self._trail)
        active = self._active()
        try:
            self._set("_selected_ids", pid, True)
            self._append_selected(pid)
            self._set("_assigned", point, pid)
            self._delete("_physical", point)
            self._delete("_eligible", point)
            for other in self._neighbors[point]:
                if other not in self._physical:
                    continue
                allowed = self._physical[other] & self._allowed_with(point, pid, other)
                self._set("_physical", other, allowed)
                self._set("_eligible", other, frozenset(p for p in allowed if p not in self._excluded))
            self._boundaries.add(len(self._trail))
            self._counts["accepted_base_placements"] += 1
            if forced:
                self._counts["forced_placements"] += 1
            self._measure(active)
            self._emit("PLACED", {"id": pid, "reason": reason, "generation": 1})
        except BaseException:
            self._undo(cp)
            raise

    def place(self, placement_id, reason):
        self._entry()
        self._place(placement_id, reason)

    def _exclude(self, pid, reason):
        self._check_id_reason(pid, reason)
        self._guard()
        _require(pid not in self._selected_ids and pid not in self._excluded, _OP)
        cp = len(self._trail)
        active = self._active()
        try:
            self._set("_excluded", pid, reason)
            point = self._owners.get(pid)
            if point in self._eligible:
                self._set("_eligible", point, self._eligible[point] - {pid})
            self._boundaries.add(len(self._trail))
            self._measure(active)
            self._emit("EXCLUDED", {"id": pid, "reason": reason})
        except BaseException:
            self._undo(cp)
            raise

    def exclude(self, placement_id, reason):
        self._entry()
        self._exclude(placement_id, reason)

    def rollback(self, checkpoint):
        self._entry()
        _require(type(checkpoint) is int and checkpoint in self._boundaries, _OP)
        self._guard()
        deltas = self._trail[checkpoint:]
        boundaries = set(self._boundaries)
        self._undo(checkpoint)
        try:
            self._emit("ROLLED_BACK", {"restored_state_sha256": _digest(self.snapshot())})
        except BaseException:
            self._redo(deltas)
            self._boundaries = boundaries
            raise

    def _decision(self):
        self._guard()
        points = sorted(self._eligible)
        if not points:
            choice = {"kind": "SOLUTION", "point": None, "candidates": []}
        else:
            empty = [p for p in points if not self._eligible[p]]
            forced = [p for p in points if len(self._eligible[p]) == 1]
            if empty:
                point, kind = empty[0], "DEAD"
            elif forced:
                point, kind = forced[0], "FORCED"
            else:
                point = min(points, key=lambda p: (0, len(self._eligible[p]), p))
                kind = "BRANCH"
            choice = {"kind": kind, "point": list(point), "candidates": sorted(self._eligible[point])}
        self._emit("DECISION", choice)
        return choice

    def decision(self):
        self._entry()
        return self._decision()

    def _domain_digest(self):
        return _digest([{"point": list(p), "generation": 0, "candidates": sorted(self._eligible[p])}
                        for p in sorted(self._eligible)])

    def _whole_solution(self, context):
        if len(set(self._selected)) != len(self._selected):
            return False
        if not set(self._model["seeds"]).issubset(self._selected):
            return False
        if self._selected[:len(context["selected"])] != context["selected"]:
            return False
        if any(self._excluded.get(row["id"]) != row["reason"]
               for row in context["excluded"]):
            return False
        totals, marking = {}, {}
        for pid in self._selected:
            if pid not in self._placements or pid in self._excluded:
                return False
            row = self._placements[pid]
            for x, y, units in row["t"]:
                point = (x, y)
                totals[point] = totals.get(point, 0) + units
                if totals[point] > 1:
                    return False
            for x, y, channel, value in row["m"]:
                slot = (x, y, channel)
                if slot in marking and marking[slot] != value:
                    return False
                marking[slot] = value
        return all(totals.get(tuple(p), 0) == 1 for p in self._model["required"])

    def _certificate(self, kind, context, root=None):
        solution = None
        if kind == "SAT":
            solution = [{"point": list(p), "id": self._assigned[p]} for p in sorted(self._assigned)]
        return {"schema": CERTIFICATE_SCHEMA, "kind": kind,
                "model_sha256": self._model_sha, "spec_sha256": self._spec_sha,
                "entry": copy.deepcopy(context), "root": root, "solution": solution}

    def _result_payload(self, status, reason, nodes, context, entry, certificate):
        metrics = self.metrics
        metrics["nodes"] = nodes
        return {"schema": RESULT_SCHEMA, "status": status, "reason": reason,
                "nodes": nodes, "selected": list(self._selected),
                "context": copy.deepcopy(context), "solution_verified": status == "FINITE_EXACT_SOLUTION",
                "metrics": metrics, "certificate": certificate,
                "model_sha256": self._model_sha, "spec_sha256": self._spec_sha,
                "entry": copy.deepcopy(entry), "final": self.snapshot()}

    def _result(self, status, reason, nodes, context, entry, certificate):
        self._emit("SOLVE_RESULT", {"status": status, "nodes": nodes, "reason": reason})
        return self._result_payload(status, reason, nodes, context, entry, certificate)

    def solve(self, node_limit=100000):
        self._entry()
        _require(type(node_limit) is int and node_limit >= 0, _LIMIT)
        cp = len(self._trail)
        entry = self.snapshot()
        context = {"selected": list(self._selected), "excluded": [
            {"id": pid, "reason": self._excluded[pid]} for pid in sorted(self._excluded)]}
        nodes = 0
        stack = []
        holder = {"root": None}
        hole = (holder, "root")
        self._solving = True
        try:
            try:
                while True:
                    if nodes >= node_limit:
                        self._undo(cp)
                        cert = self._certificate("INCOMPLETE", context)
                        return self._result("UNKNOWN", "NODE_LIMIT", nodes, context, entry, cert)
                    choice = self._decision()
                    nodes += 1
                    digest = self._domain_digest()
                    if choice["kind"] == "SOLUTION":
                        _require(self._whole_solution(context), _OP)
                        cert = self._certificate("SAT", context)
                        return self._result("FINITE_EXACT_SOLUTION", "SOLUTION", nodes, context, entry, cert)
                    if choice["kind"] == "DEAD":
                        hole[0][hole[1]] = {"kind": "DEAD", "domains_sha256": digest,
                                           "point": choice["point"]}
                        if not stack:
                            self._undo(cp)
                            cert = self._certificate("UNSAT", context, holder["root"])
                            return self._result("EXHAUSTED_FINITE_SEARCH", "EXHAUSTED", nodes, context, entry, cert)
                        parent, failed, hole = stack.pop()
                        self._undo(parent)
                        self._emit("ROLLED_BACK", {"restored_state_sha256": _digest(self.snapshot())})
                        self._exclude(failed, "EXHAUSTED_CHILD")
                        self._counts["backtracks"] += 1
                        continue
                    pid = choice["candidates"][0]
                    if choice["kind"] == "BRANCH":
                        proof = {"kind": "BRANCH", "domains_sha256": digest,
                                 "point": choice["point"], "candidates": choice["candidates"],
                                 "id": pid, "child": None, "remainder": None}
                        hole[0][hole[1]] = proof
                        stack.append((len(self._trail), pid, (proof, "remainder")))
                        hole = (proof, "child")
                        self._counts["branch_decisions"] += 1
                        self._place(pid, "BRANCH")
                    else:
                        proof = {"kind": "FORCED", "domains_sha256": digest,
                                 "point": choice["point"], "id": pid, "child": None}
                        hole[0][hole[1]] = proof
                        hole = (proof, "child")
                        self._place(pid, "FORCED", forced=True)
            except CSPBudgetExceeded:
                self._undo(cp)
                cert = self._certificate("INCOMPLETE", context)
                try:
                    return self._result("UNKNOWN", "EXTERNAL_BUDGET", nodes, context, entry, cert)
                except CSPBudgetExceeded:
                    return self._result_payload("UNKNOWN", "EXTERNAL_BUDGET", nodes, context, entry, cert)
        except BaseException:
            self._undo(cp)
            raise
        finally:
            self._solving = False
