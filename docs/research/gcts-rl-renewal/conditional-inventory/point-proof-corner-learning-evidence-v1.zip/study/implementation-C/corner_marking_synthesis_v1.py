"""Pure four-corner label-driven synthesis; no colors, witnesses, I/O or search engine.

Root-authorized inert Source. Values expand to literal strings "0" and "1";
missing components remain absent. Physical y increases downward.
"""

VERSION = "GCTS-corner-marking-synthesis-v1"
_FRAME = ((-1, -1), (-1, 1), (1, -1), (1, 1))
_OFFSETS = ((1, 0), (0, 1), (1, 1), (-1, 1))
_STATUSES = ("BASE_CONFLICT", "LOCAL_NEGATIVE", "LOCAL_POSITIVE", "UNKNOWN")
_METRICS = (
    "initial_channels", "initial_assigned_components", "candidate_union_tests",
    "wellformed_rejections", "unsafe_contact_rejections", "accepted_merges",
    "slot_pair_comparisons", "distinct_contact_checks", "budget_callbacks",
    "final_channels", "final_assigned_components",
)


class CornerCatalogueError(ValueError):
    """Malformed supplied label data; args contains exactly one public code."""


class CornerMarkingError(ValueError):
    """Malformed partial marking; args contains exactly one public code."""


class CornerBudgetExceeded(RuntimeError):
    """Only this callback exception becomes a batch budget-stop result."""


def _keys(value, names):
    return (type(value) is dict and all(type(k) is str for k in value)
            and set(value) == set(names))


def _tile_ids(value):
    if (type(value) is not list or len(value) != 33
            or any(type(v) is not str or not v for v in value)
            or len(set(value)) != 33 or value != sorted(value)):
        raise CornerCatalogueError("CORNER_INPUT_SHAPE")
    return tuple(value)


def _label_shape(value, ids):
    if not _keys(value, ("a", "b", "d", "status", "proof_id")):
        raise CornerCatalogueError("CORNER_INPUT_SHAPE")
    if (type(value["a"]) is not str or value["a"] not in ids
            or type(value["b"]) is not str or value["b"] not in ids
            or type(value["d"]) is not list or len(value["d"]) != 2
            or any(type(v) is not int for v in value["d"])
            or type(value["status"]) is not str
            or value["status"] not in _STATUSES
            or (value["proof_id"] is not None
                and type(value["proof_id"]) is not str)):
        raise CornerCatalogueError("CORNER_INPUT_SHAPE")


def _association(label):
    status, proof = label["status"], label["proof_id"]
    d = tuple(label["d"])
    return ((proof is None if status == "UNKNOWN" else
             type(proof) is str and bool(proof))
            and (status != "LOCAL_NEGATIVE" or d in _OFFSETS[2:])
            and (status != "BASE_CONFLICT" or d in _OFFSETS[:2]))


def _catalogue(value):
    if not _keys(value, ("schema", "system_sha256", "tile_ids", "labels")):
        raise CornerCatalogueError("CORNER_INPUT_SHAPE")
    if (type(value["schema"]) is not str
            or value["schema"] != "GCTS-four-corner-checked-label-catalogue-v1"
            or type(value["system_sha256"]) is not str
            or len(value["system_sha256"]) != 64
            or any(c not in "0123456789abcdef" for c in value["system_sha256"])
            or type(value["labels"]) is not list):
        raise CornerCatalogueError("CORNER_INPUT_SHAPE")
    ids = _tile_ids(value["tile_ids"])
    for label in value["labels"]:
        _label_shape(label, ids)
    if len(value["labels"]) != 4356:
        raise CornerCatalogueError("CORNER_CATALOGUE_COVERAGE")
    for rank, label in enumerate(value["labels"]):
        di, rem = divmod(rank, 1089)
        ai, bi = divmod(rem, 33)
        if (tuple(label["d"]) != _OFFSETS[di]
                or label["a"] != ids[ai] or label["b"] != ids[bi]):
            raise CornerCatalogueError("CORNER_CATALOGUE_COVERAGE")
    if any(not _association(label) for label in value["labels"]):
        raise CornerCatalogueError("CORNER_LABEL_ASSOCIATION")
    labels = {}
    required = []
    for rank, label in enumerate(value["labels"]):
        labels[rank] = (label["status"], label["proof_id"])
        if label["status"] == "LOCAL_NEGATIVE":
            required.append(rank)
    return {"ids": ids, "system": value["system_sha256"],
            "labels": labels, "required": tuple(required)}


def _budget_arg(budget):
    if budget is not None and not callable(budget):
        raise TypeError("budget must be callable or None")


def _new_metrics():
    return {name: 0 for name in _METRICS}


def _tick(metrics, budget):
    if budget is not None:
        metrics["budget_callbacks"] += 1
        budget()


def _indices(bits):
    result = []
    while bits:
        low = bits & -bits
        result.append(low.bit_length() - 1)
        bits ^= low
    return tuple(result)


def _bit_key(bits):
    return (_indices(bits[0]), _indices(bits[1]))


def _orient(bits):
    flipped = (bits[1], bits[0])
    return min((bits, flipped), key=_bit_key)


def _canonical_cached(channels):
    result = [(_orient(bits), contacts) for bits, contacts in channels]
    result.sort(key=lambda item: _bit_key(item[0]))
    return result


def _contact(ai, bi, q, r):
    d = ((q[0] - r[0]) // 2, (q[1] - r[1]) // 2)
    if d == (0, 0):
        if ai == bi:
            raise RuntimeError("internal contradictory prototype slot")
        return (4, min(ai, bi), max(ai, bi))
    if d not in _OFFSETS:
        ai, bi, d = bi, ai, (-d[0], -d[1])
    return (_OFFSETS.index(d), ai, bi)


def _scan_channels(channels, metrics, budget):
    _tick(metrics, budget)
    contacts = set()
    for zeros, ones in channels:
        if zeros & ones:
            raise RuntimeError("internal contradictory prototype slot")
        for zi in _indices(zeros):
            ai, qi = divmod(zi, 4)
            for oi in _indices(ones):
                bi, ri = divmod(oi, 4)
                metrics["slot_pair_comparisons"] += 1
                if metrics["slot_pair_comparisons"] % 1024 == 0:
                    _tick(metrics, budget)
                contacts.add(_contact(ai, bi, _FRAME[qi], _FRAME[ri]))
    _tick(metrics, budget)
    return frozenset(contacts)


def _pair_id(rank):
    return "CORNER_PAIR:" + str(rank)


def _contact_record(ctx, contact):
    di, ai, bi = contact
    if di == 4:
        return {"label_id": None, "a": ctx["ids"][ai], "b": ctx["ids"][bi],
                "d": [0, 0], "status": "CAPACITY_ONLY", "proof_id": None}
    rank = di * 1089 + ai * 33 + bi
    status, proof = ctx["labels"][rank]
    return {"label_id": _pair_id(rank), "a": ctx["ids"][ai],
            "b": ctx["ids"][bi], "d": list(_OFFSETS[di]),
            "status": status, "proof_id": proof}


def _assess(ctx, contacts, required, metrics, budget):
    _tick(metrics, budget)
    records, allowed, unsafe = [], [], []
    present = set()
    for contact in sorted(contacts):
        metrics["distinct_contact_checks"] += 1
        record = _contact_record(ctx, contact)
        records.append(record)
        if record["status"] in ("BASE_CONFLICT", "LOCAL_NEGATIVE", "CAPACITY_ONLY"):
            allowed.append(record)
        else:
            unsafe.append(record)
        if contact[0] != 4:
            present.add(contact[0] * 1089 + contact[1] * 33 + contact[2])
    missing = [_pair_id(rank) for rank in required if rank not in present]
    _tick(metrics, budget)
    return records, allowed, missing, unsafe


def _rows(ctx, bits):
    return [[ctx["ids"][index // 4], *_FRAME[index % 4]]
            for index in _indices(bits)]


def _encoded_channel(ctx, bits, channel_id):
    return {"id": channel_id, "zeros": _rows(ctx, bits[0]),
            "ones": _rows(ctx, bits[1])}


def _encoded_marking(ctx, channels):
    return {"schema": "GCTS-four-corner-partial-binary-marking-v1",
            "system_sha256": ctx["system"],
            "channels": [_encoded_channel(ctx, bits, "LEARNED_CORNER:" + str(i))
                         for i, bits in enumerate(channels)]}


def _fragment_bits(ai, bi, d):
    shared = [q for q in _FRAME
              if (q[0] - 2 * d[0], q[1] - 2 * d[1]) in _FRAME]
    if len(shared) != 1:
        raise RuntimeError("internal non-diagonal dedicated fragment")
    q = shared[0]
    r = (q[0] - 2 * d[0], q[1] - 2 * d[1])
    return (1 << (ai * 4 + _FRAME.index(q)),
            1 << (bi * 4 + _FRAME.index(r)))


def _dedicated_cache(ctx, metrics, budget):
    channels = []
    for rank in ctx["required"]:
        _tick(metrics, budget)
        di, rem = divmod(rank, 1089)
        ai, bi = divmod(rem, 33)
        bits = _fragment_bits(ai, bi, _OFFSETS[di])
        contacts = _scan_channels([bits], metrics, budget)
        if contacts != frozenset(((di, ai, bi),)):
            raise RuntimeError("dedicated contact reconstruction mismatch")
        metrics["distinct_contact_checks"] += 1
        metrics["initial_channels"] += 1
        metrics["initial_assigned_components"] += 2
        channels.append((bits, contacts))
    return _canonical_cached(channels)


def _snapshot(ctx, channels, metrics, budget, rescan=False):
    contacts = frozenset().union(*(c for _, c in channels))
    bits = [b for b, _ in channels]
    if rescan:
        actual = _scan_channels(bits, metrics, budget)
        if actual != contacts:
            raise RuntimeError("current bits and contact cache disagree")
    records, allowed, missing, unsafe = _assess(
        ctx, contacts, ctx["required"], metrics, budget)
    if missing or unsafe:
        raise RuntimeError("internal feasible-checkpoint invariant failed")
    if records != allowed:
        raise RuntimeError("internal allowed-contact cover mismatch")
    return {"marking": _encoded_marking(ctx, bits), "contact_cover": records}


def _result(ctx, checkpoint, status, metrics):
    copied = dict(metrics)
    if checkpoint is None:
        marking, cover = None, []
        copied["final_channels"] = 0
        copied["final_assigned_components"] = 0
    else:
        marking, cover = checkpoint["marking"], checkpoint["contact_cover"]
        copied["final_channels"] = len(marking["channels"])
        copied["final_assigned_components"] = sum(
            len(c["zeros"]) + len(c["ones"]) for c in marking["channels"])
    return {"schema": "GCTS-four-corner-learner-result-v1",
            "system_sha256": ctx["system"], "status": status,
            "marking": marking, "contact_cover": cover,
            "required_negative_ids": [_pair_id(r) for r in ctx["required"]],
            "metrics": copied}


def _run(catalogue, budget, merge):
    ctx = _catalogue(catalogue)
    _budget_arg(budget)
    metrics = _new_metrics()
    checkpoint = None
    try:
        _tick(metrics, budget)
        channels = _dedicated_cache(ctx, metrics, budget)
        checkpoint = _snapshot(ctx, channels, metrics, budget)
        status = "NO_NONBASE_NEGATIVES" if not ctx["required"] else "FEASIBLE_DEDICATED"
        if merge and ctx["required"]:
            while len(channels) > 1:
                accepted = None
                for i in range(len(channels)):
                    if accepted is not None:
                        break
                    for j in range(i + 1, len(channels)):
                        if accepted is not None:
                            break
                        for flip in (0, 1):
                            _tick(metrics, budget)
                            metrics["candidate_union_tests"] += 1
                            az, ao = channels[i][0]
                            bz, bo = channels[j][0]
                            if flip:
                                bz, bo = bo, bz
                            bits = (az | bz, ao | bo)
                            if bits[0] & bits[1]:
                                metrics["wellformed_rejections"] += 1
                                continue
                            bits = _orient(bits)
                            contacts = _scan_channels([bits], metrics, budget)
                            _, _, _, unsafe = _assess(ctx, contacts, (), metrics, budget)
                            if unsafe:
                                metrics["unsafe_contact_rejections"] += 1
                                continue
                            proposal = [item for k, item in enumerate(channels)
                                        if k not in (i, j)]
                            proposal.append((bits, contacts))
                            proposal = _canonical_cached(proposal)
                            checked = _snapshot(ctx, proposal, metrics, budget)
                            accepted = (proposal, checked)
                            break
                if accepted is None:
                    break
                channels, checkpoint = accepted
                metrics["accepted_merges"] += 1
            status = "FEASIBLE_GREEDY_FIXED_POINT"
        checkpoint = _snapshot(ctx, channels, metrics, budget, rescan=True)
        _tick(metrics, budget)
        return _result(ctx, checkpoint, status, metrics)
    except CornerBudgetExceeded:
        status = "NO_TEMPLATE_BUDGET_STOP" if checkpoint is None else "FEASIBLE_BUDGET_STOP"
        return _result(ctx, checkpoint, status, metrics)


def dedicated_corner_marking(catalogue, *, budget=None):
    """Return the exact one-channel-per-nonbase-negative representation control."""
    return _run(catalogue, budget, False)


def synthesize_corner_marking(catalogue, *, budget=None):
    """First-fit, two-flip channel merging; no global minimum claim."""
    return _run(catalogue, budget, True)


def _marking_bits(ctx, marking):
    if not _keys(marking, ("schema", "system_sha256", "channels")):
        raise CornerMarkingError("CORNER_MAP_SHAPE")
    if (type(marking["schema"]) is not str
            or marking["schema"] != "GCTS-four-corner-partial-binary-marking-v1"
            or type(marking["system_sha256"]) is not str
            or marking["system_sha256"] != ctx["system"]
            or type(marking["channels"]) is not list):
        raise CornerMarkingError("CORNER_MAP_SHAPE")
    bits_list = []
    for i, channel in enumerate(marking["channels"]):
        if (not _keys(channel, ("id", "zeros", "ones"))
                or type(channel["id"]) is not str
                or channel["id"] != "LEARNED_CORNER:" + str(i)):
            raise CornerMarkingError("CORNER_MAP_SHAPE")
        fields = []
        for name in ("zeros", "ones"):
            rows = channel[name]
            if type(rows) is not list:
                raise CornerMarkingError("CORNER_MAP_SHAPE")
            positions = []
            for row in rows:
                if (type(row) is not list or len(row) != 3
                        or type(row[0]) is not str or row[0] not in ctx["ids"]
                        or type(row[1]) is not int or type(row[2]) is not int
                        or (row[1], row[2]) not in _FRAME):
                    raise CornerMarkingError("CORNER_MAP_SHAPE")
                positions.append(ctx["ids"].index(row[0]) * 4
                                 + _FRAME.index((row[1], row[2])))
            if positions != sorted(positions) or len(set(positions)) != len(positions):
                raise CornerMarkingError("CORNER_MAP_SHAPE")
            fields.append(sum(1 << position for position in positions))
        bits_list.append(tuple(fields))
    if any(z & o for z, o in bits_list):
        raise CornerMarkingError("CORNER_MAP_CONFLICT")
    return bits_list


def audit_corner_marking(catalogue, marking, *, budget=None):
    """Reconstruct complete conflicts and required coverage; does not prove labels."""
    ctx = _catalogue(catalogue)
    bits = _marking_bits(ctx, marking)
    _budget_arg(budget)
    metrics = _new_metrics()
    _tick(metrics, budget)
    contacts = _scan_channels(bits, metrics, budget)
    records, allowed, missing, unsafe = _assess(
        ctx, contacts, ctx["required"], metrics, budget)
    metrics["final_channels"] = len(bits)
    metrics["final_assigned_components"] = sum(z.bit_count() + o.bit_count() for z, o in bits)
    _tick(metrics, budget)
    return {"schema": "GCTS-four-corner-marking-audit-v1",
            "system_sha256": ctx["system"], "wellformed": True,
            "induced_contacts": records, "allowed_contact_cover": allowed,
            "missing_required_negatives": missing, "uncertified_conflicts": unsafe,
            "metrics": dict(metrics)}


def new_corner_fragment(tile_ids, label, *, budget=None):
    """One diagonal label only; exact local contact, detached output, no batch rebuild."""
    ids = _tile_ids(tile_ids)
    _label_shape(label, ids)
    if (label["status"] != "LOCAL_NEGATIVE"
            or tuple(label["d"]) not in _OFFSETS[2:] or not _association(label)):
        raise CornerCatalogueError("CORNER_FRAGMENT_LABEL")
    _budget_arg(budget)
    ai, bi = ids.index(label["a"]), ids.index(label["b"])
    di = _OFFSETS.index(tuple(label["d"]))
    rank = di * 1089 + ai * 33 + bi
    ctx = {"ids": ids, "labels": {rank: (label["status"], label["proof_id"])}}
    copied_label = {"a": label["a"], "b": label["b"], "d": list(label["d"]),
                    "status": label["status"], "proof_id": label["proof_id"]}
    metrics = _new_metrics()
    _tick(metrics, budget)
    _tick(metrics, budget)
    bits = _fragment_bits(ai, bi, _OFFSETS[di])
    contacts = _scan_channels([bits], metrics, budget)
    if contacts != frozenset(((di, ai, bi),)):
        raise RuntimeError("dedicated fragment contact reconstruction mismatch")
    metrics["distinct_contact_checks"] += 1
    metrics["initial_channels"] = metrics["final_channels"] = 1
    metrics["initial_assigned_components"] = metrics["final_assigned_components"] = 2
    record = _contact_record(ctx, (di, ai, bi))
    _tick(metrics, budget)
    return {"schema": "GCTS-four-corner-new-fragment-v1",
            "status": "SINGLE_LABEL_FRAGMENT_CONSTRUCTED", "label_id": _pair_id(rank),
            "label": copied_label,
            "channel": _encoded_channel(ctx, bits, "LEARNED_CORNER:PAIR:" + str(rank)),
            "induced_contacts": [record], "metrics": dict(metrics)}
