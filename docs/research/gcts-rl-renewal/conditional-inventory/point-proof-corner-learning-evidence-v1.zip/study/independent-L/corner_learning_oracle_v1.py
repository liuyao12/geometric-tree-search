"""Independent finite unit-point, rectangle and four-corner evidence checks.

Source-only until an independently authorized once. No IO, CLI, producer import,
producer solver replay, persistent cache or hidden model. Qualification is the
only function that calls explicitly supplied producer APIs. Certificate-only
(None events) and full-event profiles are distinct; digest traces do not claim
serialized full states. All geometry uses positive y DOWN.
"""
import copy
import hashlib
import json

VERSION = 'GCTS-CORNER-LEARNING-INDEPENDENT-ORACLE-v1'
D = ((1, 0), (0, 1), (1, 1), (-1, 1))
F = ((-1, -1), (-1, 1), (1, -1), (1, 1))
DIR = (('N', 0, -1), ('E', 1, 0), ('S', 0, 1), ('W', -1, 0))
POLICY = {'empty': 'GLOBAL_LEX_POINT', 'forced': 'GLOBAL_LEX_POINT',
          'branch': 'MIN_GENERATION_DOMAIN_POINT', 'value': 'LEX_ID',
          'generation': 'ALL_REQUIRED_ROOT_0'}
METRICS = ('nodes', 'attempts', 'accepted_base_placements', 'seed_placements',
           'forced_placements', 'branch_decisions', 'backtracks',
           'candidate_removals', 'max_frontier_points', 'max_active_candidates',
           'max_edges', 'final_frontier_points', 'final_active_candidates', 'final_edges')
CMETRICS = ('initial_channels', 'initial_assigned_components', 'candidate_union_tests',
            'wellformed_rejections', 'unsafe_contact_rejections', 'accepted_merges',
            'slot_pair_comparisons', 'distinct_contact_checks', 'budget_callbacks',
            'final_channels', 'final_assigned_components')


class OracleError(ValueError):
    """Owned invalid evidence or callback shape; no producer exception wrapper."""


class OracleBudgetExceeded(RuntimeError):
    """An unresolved check, never a negative certificate."""


def _need(ok, message='INVALID_EVIDENCE'):
    if not ok:
        raise OracleError(message)


def _record(x, keys):
    _need(type(x) is dict and set(x) == set(keys))


def _int(x, minimum=0):
    _need(type(x) is int and x >= minimum)
    return x


def _str(x):
    _need(type(x) is str)
    return x


def _point(x):
    _need(type(x) is list and len(x) == 2 and all(type(v) is int for v in x))
    return tuple(x)


def _same(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return set(a) == set(b) and all(_same(a[k], b[k]) for k in a)
    if type(a) in (list, tuple):
        return len(a) == len(b) and all(_same(x, y) for x, y in zip(a, b))
    return a == b


def _eq(a, b):
    _need(_same(a, b))


def _tick(budget):
    if budget is None:
        return
    if not callable(budget):
        raise OracleError('INVALID_CALLBACK')
    value = budget()
    if value is False:
        raise OracleBudgetExceeded('BUDGET')
    if value is not None and value is not True:
        raise OracleError('INVALID_CALLBACK')


def canonical_sha256(value):
    """Canonical public hash: ASCII compact sorted JSON plus one newline."""
    return hashlib.sha256((json.dumps(value, ensure_ascii=True, sort_keys=True,
                                     separators=(',', ':'), allow_nan=False) + '\n').encode()).hexdigest()


def _verified(**fields):
    return dict(status='VERIFIED', **fields)


def validate_palette(palette, *, budget=None):
    """Check raw wire identity; supplied colors, not parsed names, are authority."""
    _tick(budget)
    _need(type(palette) is list and len(palette) == 33)
    ids = []
    for row in palette:
        _tick(budget)
        _record(row, ('id', 'N', 'E', 'S', 'W'))
        for key in row:
            _str(row[key])
        _need(bool(row['id']))
        ids.append(row['id'])
    _need(ids == sorted(set(ids)) and len(ids) == 33)
    expected = []
    for a in ('#', '0', '1'):
        for b in ('#', '0', '1'):
            for c in ('#', '0', '1'):
                out = '#' if b == '#' else ('1' if (a == '1') != (c == '1') else '0')
                expected.append({'id': 'C:'+a+':'+b+':'+c, 'N': 'S:'+b,
                                 'E': 'P:'+b+':'+c, 'S': 'S:'+out, 'W': 'P:'+a+':'+b})
    for v in ('#', '0', '1'):
        expected.append({'id': 'I:'+v, 'N': 'I:'+v, 'E': 'ROW:TOP', 'S': 'S:'+v, 'W': 'ROW:TOP'})
        expected.append({'id': 'O:'+v, 'N': 'S:'+v, 'E': 'ROW:BOT', 'S': 'O:'+v, 'W': 'ROW:BOT'})
    _eq(palette, sorted(expected, key=lambda r: r['id']))
    return _verified(palette=copy.deepcopy(palette), palette_sha256=canonical_sha256(palette))


def _palette(palette, budget):
    data = validate_palette(palette, budget=budget)['palette']
    return {r['id']: r for r in data}


def _compatible_tiles(a, b, delta):
    dx, dy = delta
    if (dx, dy) == (1, 0):
        return a['E'] == b['W']
    if (dx, dy) == (-1, 0):
        return a['W'] == b['E']
    if (dx, dy) == (0, 1):
        return a['S'] == b['N']
    if (dx, dy) == (0, -1):
        return a['N'] == b['S']
    return True


def local_pair_check(palette, a, b, d, *, budget=None):
    """Direct all-palette free-box support certificate, no search routine."""
    tiles = _palette(palette, budget)
    delta = _point(d)
    _need(delta in D and a in tiles and b in tiles)
    lo = (min(0, delta[0]), 0)
    hi = (max(0, delta[0]), delta[1])
    cells = [(x, y) for x in range(lo[0], hi[0] + 1)
             for y in range(lo[1], hi[1] + 1)]
    fixed = {(0, 0): a, delta: b}
    cert = {'schema': 'GCTS-free-box-direct-support-certificate-v1',
            'palette_sha256': canonical_sha256(palette), 'a': a, 'b': b,
            'd': list(delta), 'cells': [list(p) for p in sorted(cells)],
            'seed_cells': [{'point': list(p), 'tile': fixed[p]} for p in sorted(fixed)],
            'direct_edge_compatible': _compatible_tiles(tiles[a], tiles[b], delta),
            'supports': [], 'assignment': None}
    if not cert['direct_edge_compatible']:
        status = 'BASE_CONFLICT'
    else:
        assignment = dict(fixed)
        for p in sorted(set(cells) - set(fixed)):
            alternatives = []
            supported = []
            for tid in sorted(tiles):
                _tick(budget)
                failed = []
                for q in sorted(fixed):
                    dd = (q[0] - p[0], q[1] - p[1])
                    if not _compatible_tiles(tiles[tid], tiles[fixed[q]], dd):
                        failed.append(list(q))
                alternatives.append({'id': tid, 'failed_seed_cells': failed})
                if not failed:
                    supported.append(tid)
            cert['supports'].append({'point': list(p), 'candidates': supported,
                                     'all_alternatives': alternatives})
            if supported:
                assignment[p] = supported[0]
        status = ('LOCAL_POSITIVE' if len(assignment) == len(cells) else 'LOCAL_NEGATIVE')
        if status == 'LOCAL_POSITIVE':
            # The two missing diagonal corners are not adjacent to each other.
            for p in cells:
                for q in cells:
                    _need(_compatible_tiles(tiles[assignment[p]], tiles[assignment[q]],
                                            (q[0] - p[0], q[1] - p[1])))
            cert['assignment'] = [{'point': list(p), 'tile': assignment[p]} for p in sorted(cells)]
    _tick(budget)
    return {'status': status, 'certificate': cert,
            'certificate_sha256': canonical_sha256(cert)}


def _model(raw, budget=None, unit=True):
    _tick(budget)
    _record(raw, ('schema', 'capacity', 'required', 'placements', 'seeds'))
    _eq(raw['schema'], 'GCTS-finite-point-instance-v1')
    cap = _int(raw['capacity'], 1)
    _need(type(raw['required']) is list and type(raw['placements']) is list
          and type(raw['seeds']) is list)
    req = [_point(p) for p in raw['required']]
    _need(len(req) == len(set(req)))
    rows = {}
    for r in raw['placements']:
        _tick(budget)
        _record(r, ('id', 'type', 'translation', 't', 'm'))
        pid = _str(r['id'])
        _str(r['type'])
        _point(r['translation'])
        _need(pid not in rows and type(r['t']) is list and bool(r['t']) and type(r['m']) is list)
        t, m = {}, {}
        for term in r['t']:
            _need(type(term) is list and len(term) == 3)
            p = _point(term[:2])
            u = _int(term[2], 1)
            _need(u <= cap and p not in t)
            t[p] = u
        for term in r['m']:
            _need(type(term) is list and len(term) == 4)
            p = _point(term[:2])
            slot = p + (_str(term[2]),)
            _str(term[3])
            _need(slot not in m)
            m[slot] = term[3]
        rows[pid] = {'id': pid, 'type': r['type'], 'translation': list(r['translation']),
                     't': [[*p, t[p]] for p in sorted(t)],
                     'm': [[*s, m[s]] for s in sorted(m)]}
    seeds = list(raw['seeds'])
    _need(all(type(i) is str and i in rows for i in seeds) and len(seeds) == len(set(seeds)))
    for pid, r in rows.items():
        _need(pid in seeds or any(tuple(t[:2]) in req for t in r['t']))
    canon = {'schema': raw['schema'], 'capacity': cap, 'required': [list(p) for p in sorted(req)],
             'placements': [rows[i] for i in sorted(rows)], 'seeds': seeds}
    _selected(canon, seeds)
    if unit:
        _need(cap == 1 and all(len(r['t']) == 1 and r['t'][0][2] == 1 for r in rows.values()))
        _need(all(i in seeds or tuple(r['t'][0][:2]) in req for i, r in rows.items()))
    return canon


def _selected(model, selected):
    _need(type(selected) is list and all(type(i) is str for i in selected)
          and len(selected) == len(set(selected)))
    rows = {r['id']: r for r in model['placements']}
    _need(all(i in rows for i in selected))
    totals, marks = {}, {}
    for pid in selected:
        for x, y, u in rows[pid]['t']:
            p = (x, y)
            totals[p] = totals.get(p, 0) + u
            _need(totals[p] <= model['capacity'])
        for x, y, ch, v in rows[pid]['m']:
            s = (x, y, ch)
            _need(s not in marks or marks[s][0] == v)
            marks[s] = (v, marks.get(s, (v, 0))[1] + 1)
    return totals, marks


def _context(model, selected, excluded):
    _need(type(excluded) is list)
    rows = {r['id']: r for r in model['placements']}
    _need(type(selected) is list and selected[:len(model['seeds'])] == model['seeds'])
    _selected(model, selected)
    ids = []
    for r in excluded:
        _record(r, ('id', 'reason'))
        _str(r['id']); _str(r['reason'])
        _need(r['id'] in rows and r['id'] not in selected)
        ids.append(r['id'])
    _need(ids == sorted(set(ids)))
    return {'selected': list(selected), 'excluded': copy.deepcopy(excluded)}


def _state(model, context, budget=None):
    selected, excluded = context['selected'], context['excluded']
    _context(model, selected, excluded)
    totals, marks = _selected(model, selected)
    rows = {r['id']: r for r in model['placements']}
    seeds = set(model['seeds'])
    seeded = {tuple(rows[i]['t'][0][:2]) for i in seeds}
    free = sorted(set(map(tuple, model['required'])) - seeded)
    ban = {r['id'] for r in excluded}
    assigned = {tuple(rows[i]['t'][0][:2]): i for i in selected if i not in seeds}
    by_anchor = {}
    for r in model['placements']:
        by_anchor.setdefault(tuple(r['t'][0][:2]), []).append(r)
    physical, eligible = [], []
    for p in free:
        _tick(budget)
        if p in assigned:
            continue
        ids = []
        for r in by_anchor.get(p, []):
            if r['id'] in selected:
                continue
            if totals.get(p, 0) + 1 > 1:
                continue
            if all((x, y, ch) not in marks or marks[(x, y, ch)][0] == v
                   for x, y, ch, v in r['m']):
                ids.append(r['id'])
        physical.append({'point': list(p), 'candidates': ids})
        eligible.append({'point': list(p), 'generation': 0,
                         'candidates': [i for i in ids if i not in ban]})
    reverse = sorted((i, r['point']) for r in eligible for i in r['candidates'])
    return {'schema': 'GCTS-unit-cell-normalized-state-v1', 'selected': list(selected),
            'assigned': [{'point': list(p), 'id': assigned[p]} for p in sorted(assigned)],
            'excluded': copy.deepcopy(excluded), 'physical_domains': physical,
            'eligible_domains': eligible, 'active_candidates': sorted(i for i, _ in reverse),
            'forward_incidence': [[*r['point'], i, 1] for r in eligible for i in r['candidates']],
            'reverse_incidence': [{'id': i, 'points': [[*p, 1]]} for i, p in reverse]}


def _decision(state):
    rows = state['eligible_domains']
    if not rows:
        return {'kind': 'SOLUTION', 'point': None, 'candidates': []}
    empty = [r for r in rows if not r['candidates']]
    forced = [r for r in rows if len(r['candidates']) == 1]
    if empty:
        r = min(empty, key=lambda r: r['point']); kind = 'DEAD'
    elif forced:
        r = min(forced, key=lambda r: r['point']); kind = 'FORCED'
    else:
        r = min(rows, key=lambda r: (r['generation'], len(r['candidates']), r['point'])); kind = 'BRANCH'
    return {'kind': kind, 'point': copy.deepcopy(r['point']), 'candidates': list(r['candidates'])}


def _export(model, budget=None):
    rows = {r['id']: r for r in model['placements']}
    seeds = set(model['seeds'])
    seeded = {tuple(rows[i]['t'][0][:2]) for i in seeds}
    free = sorted(set(map(tuple, model['required'])) - seeded)
    variables = [{'point': list(p), 'generation': 0,
                  'domain': [r['id'] for r in model['placements']
                             if r['id'] not in seeds and tuple(r['t'][0][:2]) == p]} for p in free]
    pre = [{'id': r['id'], 'anchor': r['t'][0][:2],
            'reason': 'SEED_SELECTED' if r['id'] in seeds else 'SEED_ANCHOR_OCCUPIED'}
           for r in model['placements'] if tuple(r['t'][0][:2]) in seeded]
    maps = {i: {tuple(t[:3]): t[3] for t in r['m']} for i, r in rows.items()}
    unaries = []
    point_of = {}
    for var in variables:
        for pid in var['domain']:
            _tick(budget)
            point_of[pid] = tuple(var['point'])
            conflicts = []
            for sid in model['seeds']:
                slots = [list(s) for s in sorted(maps[pid].keys() & maps[sid].keys())
                         if maps[pid][s] != maps[sid][s]]
                if slots:
                    conflicts.append({'seed': sid, 'slots': slots})
            unaries.append({'id': pid, 'allowed': not conflicts,
                            'seed_conflicts': sorted(conflicts, key=lambda r: r['seed'])})
    slots = {}
    for pid in point_of:
        for slot, value in maps[pid].items():
            slots.setdefault(slot, []).append((pid, value))
    forbidden = {}
    for entries in slots.values():
        _tick(budget)
        for ai, av in entries:
            for bi, bv in entries:
                if point_of[ai] < point_of[bi] and av != bv:
                    forbidden.setdefault((point_of[ai], point_of[bi]), set()).add((ai, bi))
    domains = {tuple(v['point']): v['domain'] for v in variables}
    binary = []
    for (p, q), bad in sorted(forbidden.items()):
        _tick(budget)
        binary.append({'left': list(p), 'right': list(q),
                       'allowed_rows': [sum(1 << j for j, b in enumerate(domains[q]) if (a, b) not in bad)
                                        for a in domains[p]]})
    return {'schema': 'GCTS-unit-cell-csp-spec-v1', 'model': copy.deepcopy(model),
            'variables': variables, 'unaries': sorted(unaries, key=lambda r: r['id']),
            'binary': binary, 'preprocessed': pre, 'policy': dict(POLICY)}


def verify_unit_cell_export(raw_model, sparse_spec, *, budget=None):
    model = _model(raw_model, budget)
    expected = _export(model, budget)
    _eq(sparse_spec, expected)
    return _verified(model_sha256=canonical_sha256(model), spec_sha256=canonical_sha256(expected),
                     variables=len(expected['variables']), binary_pairs=len(expected['binary']))


def verify_normalized_state(raw_model, sparse_spec, state, *, budget=None):
    # Every state fact below comes from raw literals, not the producer masks.
    # Complete export equivalence is a separate entry/final certificate check.
    model = _model(raw_model, budget)
    _record(sparse_spec, ('schema', 'model', 'variables', 'unaries', 'binary', 'preprocessed', 'policy'))
    _eq(sparse_spec['schema'], 'GCTS-unit-cell-csp-spec-v1')
    _eq(sparse_spec['model'], model)
    _need(type(state) is dict and 'selected' in state and 'excluded' in state)
    expected = _state(model, _context(model, state['selected'], state['excluded']), budget)
    _eq(state, expected)
    return _verified(normalized_state=expected, state_sha256=canonical_sha256(expected),
                     domains_sha256=canonical_sha256(expected['eligible_domains']),
                     spec_scope='MODEL_ASSOCIATION_HERE_FULL_MASKS_IN_EXPORT_AND_CERTIFICATE_CHECKS')


def verify_point_snapshot(raw_model, snapshot, event=None, *, budget=None):
    """Check public native13; no private trail reconstruction is claimed."""
    model = _model(raw_model, budget)
    _record(snapshot, ('schema', 'selected', 'excluded', 'totals', 'markings',
                      'point_generations', 'tile_generations', 'frontier', 'candidate_rows',
                      'active_candidates', 'forward_incidence', 'reverse_incidence', 'trail_size'))
    _eq(snapshot['schema'], 'GCTS-finite-point-snapshot-v1')
    ctx = _context(model, snapshot['selected'], snapshot['excluded'])
    state = _state(model, ctx, budget)
    totals, marks = _selected(model, ctx['selected'])
    rows = model['placements']
    points = set(map(tuple, model['required'])) | {tuple(t[:2]) for r in rows for t in r['t']}
    _eq(snapshot['totals'], [[*p, totals.get(p, 0)] for p in sorted(points)])
    _eq(snapshot['markings'], [[*s, marks[s][0], marks[s][1]] for s in sorted(marks)])
    generations = set(map(tuple, model['required'])) | {tuple(t[:2]) for r in rows
                    if r['id'] in ctx['selected'] for t in r['t']}
    _eq(snapshot['point_generations'], [[*p, 0] for p in sorted(generations)])
    _eq(snapshot['tile_generations'], [[i, 0 if i in model['seeds'] else 1] for i in ctx['selected']])
    _eq(snapshot['frontier'], state['eligible_domains'])
    _eq(snapshot['active_candidates'], state['active_candidates'])
    _eq(snapshot['forward_incidence'], state['forward_incidence'])
    _eq(snapshot['reverse_incidence'], state['reverse_incidence'])
    active = set(state['active_candidates']); selected = set(ctx['selected'])
    excluded = {r['id'] for r in ctx['excluded']}
    candidate = []
    for r in rows:
        _tick(budget)
        cap = [t[:2] for t in r['t'] if totals.get(tuple(t[:2]), 0) + t[2] > 1]
        conflict = [m[:3] for m in r['m'] if tuple(m[:3]) in marks and marks[tuple(m[:3])][0] != m[3]]
        candidate.append({'id': r['id'], 'selected': r['id'] in selected,
                          'excluded': r['id'] in excluded,
                          'legal': r['id'] not in selected and not cap and not conflict,
                          'active': r['id'] in active, 'capacity_conflicts': cap,
                          'marking_conflicts': conflict})
    _eq(snapshot['candidate_rows'], candidate)
    _int(snapshot['trail_size'])
    if event is not None:
        _event(model, state, event, budget)
    return _verified(normalized_state=state,
                     receipt={'schema': 'GCTS-independent-point-snapshot-check-v1',
                              'model_sha256': canonical_sha256(model),
                              'snapshot_sha256': canonical_sha256(snapshot),
                              'state_sha256': canonical_sha256(state),
                              'domains_sha256': canonical_sha256(state['eligible_domains']),
                              'candidate_rows': len(rows), 'trail_scope': 'NONNEGATIVE_PUBLIC_METADATA_ONLY'})


def _event(model, state, event, budget=None):
    _tick(budget)
    _record(event, ('kind', 'data'))
    kind, data = event['kind'], event['data']
    _need(type(kind) is str and type(data) is dict)
    if kind == 'INITIALIZED':
        _eq(data, {})
        _eq(state, _state(model, {'selected': model['seeds'], 'excluded': []}, budget))
    elif kind == 'DECISION':
        _eq(data, _decision(state))
    elif kind == 'PLACED':
        _record(data, ('id', 'reason', 'generation'))
        _str(data['reason']); _eq(data['generation'], 1)
        _need(bool(state['selected']) and state['selected'][-1] == data['id'])
    elif kind == 'EXCLUDED':
        _record(data, ('id', 'reason'))
        _need({'id': data['id'], 'reason': data['reason']} in state['excluded'])
    elif kind == 'ROLLED_BACK':
        # Native point checkpoint is an opaque reachable trail token.
        if set(data) == {'checkpoint'}:
            _int(data['checkpoint'])
        else:
            _record(data, ('restored_state_sha256',))
            _eq(data['restored_state_sha256'], canonical_sha256(state))
    elif kind == 'SOLVE_RESULT':
        _record(data, ('status', 'nodes', 'reason'))
        _int(data['nodes']); _str(data['reason'])
        _need(data['status'] in ('FINITE_EXACT_SOLUTION', 'EXHAUSTED_FINITE_SEARCH', 'UNKNOWN'))
        if data['status'] == 'FINITE_EXACT_SOLUTION':
            _need(not state['eligible_domains'])
    else:
        raise OracleError('INVALID_EVIDENCE')


def verify_local_model(palette, a, b, d, raw_model, *, budget=None):
    tiles = _palette(palette, budget)
    check = local_pair_check(palette, a, b, d, budget=budget)
    _need(check['status'] != 'BASE_CONFLICT')
    model = _model(raw_model, budget)
    cells = [tuple(p) for p in check['certificate']['cells']]
    _eq(model['required'], [[2*x, 2*y] for x, y in sorted(cells)])
    _need(len(model['placements']) == len(cells)*33 and len(model['seeds']) == 2)
    found = {}
    for row in model['placements']:
        p = tuple(row['translation'])
        _eq(row['t'], [[*p, 1]])
        _need(p[0] % 2 == 0 and p[1] % 2 == 0)
        cell = (p[0]//2, p[1]//2)
        _need(cell in cells)
        matched = []
        for tid, tile in tiles.items():
            if row['type'] == json.dumps(['WANG', tid], ensure_ascii=True, separators=(',', ':')):
                matched.append(tid)
        _need(len(matched) == 1)
        tid = matched[0]
        _eq(row['m'], sorted([[p[0]+dx, p[1]+dy, 'WANG', tiles[tid][di]] for di, dx, dy in DIR]))
        _need((cell, tid) not in found)
        found[cell, tid] = row['id']
    _eq(set(found), {(p, tid) for p in cells for tid in tiles})
    _eq(model['seeds'], [found[((0, 0), a)], found[(tuple(d), b)]])
    return _verified(model_sha256=canonical_sha256(model), direct_check=check)


def _metrics_check(metrics, state, nodes=None):
    keys = METRICS if nodes is not None else METRICS[1:]
    _record(metrics, keys)
    for key in keys:
        if key == 'candidate_removals':
            _record(metrics[key], ('SELECTED', 'EXCLUDED', 'CAPACITY', 'MARKING', 'NO_FRONTIER'))
            for v in metrics[key].values():
                _int(v)
        else:
            _int(metrics[key])
    if nodes is not None:
        _eq(metrics['nodes'], nodes)
    _eq(metrics['final_frontier_points'], len(state['eligible_domains']))
    _eq(metrics['final_active_candidates'], len(state['active_candidates']))
    _eq(metrics['final_edges'], len(state['forward_incidence']))
    for end, high in (('final_frontier_points', 'max_frontier_points'),
                      ('final_active_candidates', 'max_active_candidates'), ('final_edges', 'max_edges')):
        _need(metrics[high] >= metrics[end])


def _whole(model, selected, excluded):
    ctx = _context(model, selected, excluded)
    totals, _ = _selected(model, ctx['selected'])
    _need(all(totals.get(tuple(p), 0) == 1 for p in model['required']))


def verify_point_result(raw_model, result, *, budget=None):
    """Whole SAT / unresolved envelope check; native exhaustion is not a proof."""
    model = _model(raw_model, budget)
    _record(result, ('schema', 'status', 'reason', 'nodes', 'selected', 'context',
                     'model', 'solution_verified', 'metrics'))
    _eq(result['schema'], 'GCTS-finite-point-solve-result-v1')
    _eq(result['model'], model)
    _record(result['context'], ('selected', 'excluded'))
    ctx = _context(model, result['context']['selected'], result['context']['excluded'])
    _int(result['nodes'])
    status = result['status']
    _need(status in ('FINITE_EXACT_SOLUTION', 'EXHAUSTED_FINITE_SEARCH', 'UNKNOWN'))
    if status == 'FINITE_EXACT_SOLUTION':
        _eq(result['reason'], 'SOLUTION'); _eq(result['solution_verified'], True)
        _need(result['selected'][:len(ctx['selected'])] == ctx['selected'])
        _whole(model, result['selected'], ctx['excluded'])
    else:
        _eq(result['solution_verified'], False)
        _eq(result['selected'], ctx['selected'])
        _need(result['reason'] in (('EXHAUSTED',) if status == 'EXHAUSTED_FINITE_SEARCH'
                                  else ('NODE_LIMIT', 'EXTERNAL_BUDGET')))
    state = _state(model, {'selected': result['selected'], 'excluded': ctx['excluded']}, budget)
    _metrics_check(result['metrics'], state)
    return _verified(model_sha256=canonical_sha256(model), status_checked=status,
                     scope='WHOLE_SAT_OR_RETURN_ENVELOPE_NATIVE_EXHAUSTION_REQUIRES_SEPARATE_UNSAT_CERTIFICATE')


def _proof(model, root, entry, budget):
    pending = [(root, copy.deepcopy(entry))]
    count = 0
    while pending:
        _tick(budget)
        node, ctx = pending.pop()
        _need(type(node) is dict and type(node.get('kind')) is str)
        state = _state(model, ctx, budget)
        choice = _decision(state)
        _eq(node.get('domains_sha256'), canonical_sha256(state['eligible_domains']))
        kind = node['kind']
        count += 1
        if kind == 'DEAD':
            _record(node, ('kind', 'domains_sha256', 'point'))
            _eq(choice['kind'], 'DEAD'); _eq(node['point'], choice['point'])
        elif kind == 'FORCED':
            _record(node, ('kind', 'domains_sha256', 'point', 'id', 'child'))
            _eq(choice['kind'], 'FORCED'); _eq(node['point'], choice['point'])
            _eq(node['id'], choice['candidates'][0])
            child = {'selected': ctx['selected'] + [node['id']], 'excluded': copy.deepcopy(ctx['excluded'])}
            pending.append((node['child'], child))
        elif kind == 'BRANCH':
            _record(node, ('kind', 'domains_sha256', 'point', 'candidates', 'id', 'child', 'remainder'))
            _eq(choice['kind'], 'BRANCH'); _eq(node['point'], choice['point'])
            _eq(node['candidates'], choice['candidates']); _eq(node['id'], choice['candidates'][0])
            pid = node['id']
            child = {'selected': ctx['selected'] + [pid], 'excluded': copy.deepcopy(ctx['excluded'])}
            rest = {'selected': list(ctx['selected']),
                    'excluded': sorted(ctx['excluded'] + [{'id': pid, 'reason': 'EXHAUSTED_CHILD'}],
                                       key=lambda r: r['id'])}
            pending.append((node['remainder'], rest)); pending.append((node['child'], child))
        else:
            raise OracleError('INVALID_EVIDENCE')
    return count


def _events(model, events, budget):
    _need(type(events) is list and bool(events))
    previous = None
    history = []
    for seq, ev in enumerate(events):
        _tick(budget)
        _record(ev, ('seq', 'kind', 'data', 'snapshot', 'domains_sha256', 'state_sha256'))
        _eq(ev['seq'], seq)
        state = ev['snapshot']
        _need(type(state) is dict and 'selected' in state and 'excluded' in state)
        _eq(state, _state(model, _context(model, state['selected'], state['excluded']), budget))
        _eq(ev['state_sha256'], canonical_sha256(state))
        _eq(ev['domains_sha256'], canonical_sha256(state['eligible_domains']))
        _event(model, state, {'kind': ev['kind'], 'data': ev['data']}, budget)
        if previous is None:
            _eq(ev['kind'], 'INITIALIZED')
        elif ev['kind'] == 'PLACED':
            pid = ev['data']['id']
            _need(any(pid in r['candidates'] for r in previous['eligible_domains']))
            _eq(state['selected'], previous['selected'] + [pid])
            _eq(state['excluded'], previous['excluded'])
        elif ev['kind'] == 'EXCLUDED':
            _eq(state['selected'], previous['selected'])
            _eq(state['excluded'], sorted(previous['excluded'] + [ev['data']], key=lambda r: r['id']))
        elif ev['kind'] in ('DECISION',):
            _eq(state, previous)
        elif ev['kind'] == 'ROLLED_BACK':
            _need(any(_same(state, old) for old in history))
        elif ev['kind'] == 'SOLVE_RESULT':
            if ev['data']['status'] == 'FINITE_EXACT_SOLUTION':
                _whole(model, state['selected'], state['excluded'])
        elif ev['kind'] == 'INITIALIZED':
            raise OracleError('INVALID_EVIDENCE')
        previous = copy.deepcopy(state)
        history.append(previous)
    return previous


def verify_unit_cell_result(raw_model, sparse_spec, result, normalized_events, budget=None):
    """B6 disposition. None events = certificate+entry/final profile only.

    A full event list additionally checks all normalized state/event/hash bodies.
    Neither profile reruns a solver. INCOMPLETE can verify only as unresolved.
    """
    mh = sh = kind = None
    try:
        _tick(budget)
        model = _model(raw_model, budget)
        mh = canonical_sha256(model)
        spec = _export(model, budget)
        _eq(sparse_spec, spec)
        sh = canonical_sha256(spec)
        _record(result, ('schema', 'status', 'reason', 'nodes', 'selected', 'context',
                         'solution_verified', 'metrics', 'certificate', 'model_sha256',
                         'spec_sha256', 'entry', 'final'))
        _eq(result['schema'], 'GCTS-unit-cell-csp-solve-result-v1')
        _eq(result['model_sha256'], mh); _eq(result['spec_sha256'], sh)
        _record(result['context'], ('selected', 'excluded'))
        entry = _context(model, result['context']['selected'], result['context']['excluded'])
        _eq(result['entry'], _state(model, entry, budget))
        final = result['final']
        _need(type(final) is dict and 'selected' in final and 'excluded' in final)
        _eq(final, _state(model, _context(model, final['selected'], final['excluded']), budget))
        _eq(result['selected'], final['selected'])
        _int(result['nodes']); _metrics_check(result['metrics'], final, result['nodes'])
        cert = result['certificate']
        _record(cert, ('schema', 'kind', 'model_sha256', 'spec_sha256', 'entry', 'root', 'solution'))
        _eq(cert['schema'], 'GCTS-unit-cell-csp-certificate-v1')
        _eq(cert['model_sha256'], mh); _eq(cert['spec_sha256'], sh); _eq(cert['entry'], entry)
        _need(cert['kind'] in ('SAT', 'UNSAT', 'INCOMPLETE')); kind = cert['kind']
        if kind == 'SAT':
            _eq(result['status'], 'FINITE_EXACT_SOLUTION'); _eq(result['reason'], 'SOLUTION')
            _eq(result['solution_verified'], True); _eq(cert['root'], None)
            _need(final['selected'][:len(entry['selected'])] == entry['selected'])
            _eq(final['excluded'], entry['excluded'])
            _whole(model, final['selected'], entry['excluded'])
            _eq(cert['solution'], final['assigned'])
        elif kind == 'UNSAT':
            _eq(result['status'], 'EXHAUSTED_FINITE_SEARCH'); _eq(result['reason'], 'EXHAUSTED')
            _eq(result['solution_verified'], False); _eq(cert['solution'], None)
            _eq(final, result['entry'])
            _proof(model, cert['root'], entry, budget)
        else:
            _eq(result['status'], 'UNKNOWN'); _eq(result['solution_verified'], False)
            _need(result['reason'] in ('NODE_LIMIT', 'EXTERNAL_BUDGET'))
            _eq(cert['root'], None); _eq(cert['solution'], None); _eq(final, result['entry'])
        if normalized_events is not None:
            end = _events(model, normalized_events, budget)
            if normalized_events[-1]['kind'] == 'SOLVE_RESULT':
                _eq(end, final)
            else:
                _need(kind == 'INCOMPLETE' and result['reason'] == 'EXTERNAL_BUDGET')
            notifications = [r for r in normalized_events if r['kind'] == 'SOLVE_RESULT']
            if notifications:
                _eq(notifications[-1]['data'], {'status': result['status'], 'nodes': result['nodes'],
                                                 'reason': result['reason']})
            else:
                _need(kind == 'INCOMPLETE' and result['reason'] == 'EXTERNAL_BUDGET')
        _tick(budget)
        status, reason = 'VERIFIED', 'COMPLETE_VALID'
    except OracleBudgetExceeded:
        status, reason = 'UNKNOWN', 'BUDGET'
    except OracleError as exc:
        status, reason = 'REJECTED', ('INVALID_CALLBACK' if str(exc) == 'INVALID_CALLBACK' else 'INVALID_EVIDENCE')
    return {'schema': 'GCTS-unit-cell-csp-certificate-check-v1', 'status': status,
            'model_sha256': mh, 'spec_sha256': sh, 'kind': kind, 'reason': reason}


def _catalogue(catalogue, budget=None):
    _record(catalogue, ('schema', 'system_sha256', 'tile_ids', 'labels'))
    _eq(catalogue['schema'], 'GCTS-four-corner-checked-label-catalogue-v1')
    sha = catalogue['system_sha256']
    _need(type(sha) is str and len(sha) == 64 and all(c in '0123456789abcdef' for c in sha))
    ids = catalogue['tile_ids']
    _need(type(ids) is list and len(ids) == 33 and all(type(i) is str and i for i in ids)
          and ids == sorted(set(ids)))
    _need(type(catalogue['labels']) is list and len(catalogue['labels']) == 4356)
    lookup = {}
    for n, row in enumerate(catalogue['labels']):
        _tick(budget)
        _record(row, ('a', 'b', 'd', 'status', 'proof_id'))
        di, rest = divmod(n, 1089); ai, bi = divmod(rest, 33)
        _eq([row['a'], row['b'], row['d']], [ids[ai], ids[bi], list(D[di])])
        _need(row['status'] in ('BASE_CONFLICT', 'LOCAL_NEGATIVE', 'LOCAL_POSITIVE', 'UNKNOWN'))
        if row['status'] == 'UNKNOWN':
            _eq(row['proof_id'], None)
        else:
            _need(type(row['proof_id']) is str and bool(row['proof_id']))
        if row['status'] == 'BASE_CONFLICT':
            _need(di < 2)
        if row['status'] == 'LOCAL_NEGATIVE':
            _need(di >= 2)
        lookup[(row['a'], row['b'], tuple(row['d']))] = dict(label_id='CORNER_PAIR:'+str(n), **copy.deepcopy(row))
    return ids, lookup


def _channels(tile_ids, marking, system_sha256=None, fragments=False):
    _record(marking, ('schema', 'system_sha256', 'channels'))
    _eq(marking['schema'], 'GCTS-four-corner-partial-binary-marking-v1')
    sha = marking['system_sha256']
    _need(type(sha) is str and len(sha) == 64 and all(c in '0123456789abcdef' for c in sha))
    if system_sha256 is not None:
        _eq(sha, system_sha256)
    _need(type(marking['channels']) is list)
    channels = []
    names = set()
    for n, ch in enumerate(marking['channels']):
        _record(ch, ('id', 'zeros', 'ones'))
        _str(ch['id']); _need(ch['id'] not in names)
        if not fragments:
            _eq(ch['id'], 'LEARNED_CORNER:'+str(n))
        else:
            _need(ch['id'].startswith('LEARNED_CORNER:'))
        names.add(ch['id'])
        sides = []
        for side in ('zeros', 'ones'):
            _need(type(ch[side]) is list)
            values = []
            for row in ch[side]:
                _need(type(row) is list and len(row) == 3 and type(row[0]) is str and row[0] in tile_ids)
                _need(all(type(v) is int for v in row[1:]) and tuple(row[1:]) in F)
                values.append(tuple(row))
            _need(values == sorted(set(values)))
            sides.append(values)
        _need(not (set(sides[0]) & set(sides[1])))
        channels.append((ch['id'], sides[0], sides[1]))
    return channels


def _contact_keys(channels, budget=None):
    found = set()
    for _name, zeros, ones in channels:
        for a, ax, ay in zeros:
            for b, bx, by in ones:
                _tick(budget)
                dx, dy = (ax-bx)//2, (ay-by)//2
                if dx == 0 and dy == 0:
                    _need(a != b)
                    aa, bb = sorted((a, b)); found.add((aa, bb, (0, 0)))
                elif (dx, dy) in D:
                    found.add((a, b, (dx, dy)))
                else:
                    _need((-dx, -dy) in D)
                    found.add((b, a, (-dx, -dy)))
    return found


def reconstruct_corner_contacts(catalogue, marking, *, budget=None):
    ids, lookup = _catalogue(catalogue, budget)
    channels = _channels(ids, marking, catalogue['system_sha256'])
    found = _contact_keys(channels, budget)
    nonzero = [copy.deepcopy(r) for key, r in lookup.items() if key in found]
    zeros = [{'label_id': None, 'a': a, 'b': b, 'd': [0, 0],
              'status': 'CAPACITY_ONLY', 'proof_id': None}
             for a in ids for b in ids if a < b and (a, b, (0, 0)) in found]
    cover = nonzero + zeros
    required = [r['label_id'] for r in lookup.values() if r['status'] == 'LOCAL_NEGATIVE']
    missing = [i for i in required if not any(r['label_id'] == i for r in cover)]
    unsafe = [r for r in cover if r['status'] in ('LOCAL_POSITIVE', 'UNKNOWN')]
    return _verified(induced_contacts=cover, required_negative_ids=required,
                     missing_required_negatives=missing, uncertified_conflicts=unsafe,
                     channels=len(channels), assigned_components=sum(len(z)+len(o) for _, z, o in channels))


def verify_corner_fragment(tile_ids, label, fragment, *, budget=None):
    _need(type(tile_ids) is list and len(tile_ids) == 33 and tile_ids == sorted(set(tile_ids)))
    _record(label, ('a', 'b', 'd', 'status', 'proof_id'))
    _need(label['a'] in tile_ids and label['b'] in tile_ids and tuple(label['d']) in D[2:]
          and label['status'] == 'LOCAL_NEGATIVE' and type(label['proof_id']) is str and label['proof_id'])
    rank = D.index(tuple(label['d']))*1089 + tile_ids.index(label['a'])*33 + tile_ids.index(label['b'])
    _record(fragment, ('schema', 'status', 'label_id', 'label', 'channel', 'induced_contacts', 'metrics'))
    _eq(fragment['schema'], 'GCTS-four-corner-new-fragment-v1')
    _eq(fragment['status'], 'SINGLE_LABEL_FRAGMENT_CONSTRUCTED')
    _eq(fragment['label_id'], 'CORNER_PAIR:'+str(rank)); _eq(fragment['label'], label)
    dx, dy = label['d']
    q = next(p for p in F if (p[0]-2*dx, p[1]-2*dy) in F)
    expected = {'id': 'LEARNED_CORNER:PAIR:'+str(rank),
                'zeros': [[label['a'], *q]], 'ones': [[label['b'], q[0]-2*dx, q[1]-2*dy]]}
    _eq(fragment['channel'], expected)
    _eq(_contact_keys([(expected['id'], [tuple(r) for r in expected['zeros']],
                        [tuple(r) for r in expected['ones']])], budget),
        {(label['a'], label['b'], tuple(label['d']))})
    _eq(fragment['induced_contacts'], [dict(label_id='CORNER_PAIR:'+str(rank), **copy.deepcopy(label))])
    _record(fragment['metrics'], CMETRICS)
    for key, value in fragment['metrics'].items():
        _int(value)
        if key in ('initial_channels', 'final_channels', 'slot_pair_comparisons', 'distinct_contact_checks'):
            _eq(value, 1)
        elif key in ('initial_assigned_components', 'final_assigned_components'):
            _eq(value, 2)
        elif key != 'budget_callbacks':
            _eq(value, 0)
    _tick(budget)
    return _verified(fragment_sha256=canonical_sha256(fragment))


def verify_corner_result(catalogue, result, *, budget=None):
    ids, lookup = _catalogue(catalogue, budget)
    _record(result, ('schema', 'system_sha256', 'status', 'marking', 'contact_cover',
                     'required_negative_ids', 'metrics'))
    _eq(result['schema'], 'GCTS-four-corner-learner-result-v1')
    _eq(result['system_sha256'], catalogue['system_sha256'])
    required = [r['label_id'] for r in lookup.values() if r['status'] == 'LOCAL_NEGATIVE']
    _eq(result['required_negative_ids'], required)
    _record(result['metrics'], CMETRICS)
    for v in result['metrics'].values():
        _int(v)
    status = result['status']
    _need(status in ('NO_NONBASE_NEGATIVES', 'FEASIBLE_DEDICATED', 'FEASIBLE_GREEDY_FIXED_POINT',
                     'FEASIBLE_BUDGET_STOP', 'NO_TEMPLATE_BUDGET_STOP'))
    if status == 'NO_TEMPLATE_BUDGET_STOP':
        _eq(result['marking'], None); _eq(result['contact_cover'], [])
        _eq(result['metrics']['final_channels'], 0); _eq(result['metrics']['final_assigned_components'], 0)
        return _verified(activation_allowed=False, reason='UNRESOLVED_NO_TEMPLATE')
    checked = reconstruct_corner_contacts(catalogue, result['marking'], budget=budget)
    parsed = _channels(ids, result['marking'], catalogue['system_sha256'])
    keys = [(tuple(z), tuple(o)) for _ch, z, o in parsed]
    _need(keys == sorted(keys) and all(key <= (key[1], key[0]) for key in keys))
    _eq(result['metrics']['initial_channels'], len(required))
    _eq(result['metrics']['initial_assigned_components'], 2*len(required))
    _eq(result['metrics']['accepted_merges'], len(required)-checked['channels'])
    _need(checked['assigned_components'] <= 2*len(required))
    _eq(checked['missing_required_negatives'], []); _eq(checked['uncertified_conflicts'], [])
    _eq(result['contact_cover'], checked['induced_contacts'])
    _eq(result['metrics']['final_channels'], checked['channels'])
    _eq(result['metrics']['final_assigned_components'], checked['assigned_components'])
    if status == 'NO_NONBASE_NEGATIVES':
        _eq(required, []); _eq(result['marking']['channels'], [])
    if status == 'FEASIBLE_DEDICATED':
        _eq(checked['channels'], len(required)); _eq(checked['assigned_components'], 2*len(required))
        singleton_keys = []
        for ch in parsed:
            _need(len(ch[1]) == len(ch[2]) == 1)
            contacts = _contact_keys([ch], budget)
            _need(len(contacts) == 1)
            singleton_keys.extend(lookup[k]['label_id'] for k in contacts if k in lookup)
        _eq(sorted(singleton_keys), sorted(required))
    # Safety can be checked with UNKNOWN present, but activation must be withheld.
    resolved = all(r['status'] != 'UNKNOWN' for r in lookup.values())
    return _verified(activation_allowed=resolved, contacts=checked, result_sha256=canonical_sha256(result))


def verify_corner_audit(catalogue, marking, audit, *, budget=None):
    checked = reconstruct_corner_contacts(catalogue, marking, budget=budget)
    _record(audit, ('schema', 'system_sha256', 'wellformed', 'induced_contacts',
                    'allowed_contact_cover', 'missing_required_negatives', 'uncertified_conflicts', 'metrics'))
    _eq(audit['schema'], 'GCTS-four-corner-marking-audit-v1')
    _eq(audit['system_sha256'], catalogue['system_sha256']); _eq(audit['wellformed'], True)
    _eq(audit['induced_contacts'], checked['induced_contacts'])
    _eq(audit['allowed_contact_cover'], [r for r in checked['induced_contacts']
                                       if r['status'] in ('BASE_CONFLICT', 'LOCAL_NEGATIVE', 'CAPACITY_ONLY')])
    _eq(audit['missing_required_negatives'], checked['missing_required_negatives'])
    _eq(audit['uncertified_conflicts'], checked['uncertified_conflicts'])
    _record(audit['metrics'], CMETRICS)
    for v in audit['metrics'].values():
        _int(v)
    for key in ('initial_channels', 'initial_assigned_components', 'candidate_union_tests',
                'wellformed_rejections', 'unsafe_contact_rejections', 'accepted_merges'):
        _eq(audit['metrics'][key], 0)
    chs = _channels(catalogue['tile_ids'], marking, catalogue['system_sha256'])
    _eq(audit['metrics']['slot_pair_comparisons'], sum(len(z)*len(o) for _, z, o in chs))
    _eq(audit['metrics']['distinct_contact_checks'], len(checked['induced_contacts']))
    _eq(audit['metrics']['final_channels'], checked['channels'])
    _eq(audit['metrics']['final_assigned_components'], checked['assigned_components'])
    return _verified(contacts=checked)


def verify_corner_augmentation(base, aug, marking, *, budget=None):
    b = _model(base, budget); a = _model(aug, budget)
    _eq([a[k] for k in ('schema', 'capacity', 'required', 'seeds')],
        [b[k] for k in ('schema', 'capacity', 'required', 'seeds')])
    _eq([r['id'] for r in a['placements']], [r['id'] for r in b['placements']])
    types = {}
    ordinary = {}
    for r in b['placements']:
        try:
            value = json.loads(r['type'])
        except (ValueError, TypeError) as exc:
            raise OracleError('INVALID_EVIDENCE') from exc
        _need(type(value) is list and len(value) == 2)
        if value[0] == 'WANG':
            _need(type(value[1]) is str)
            ordinary[r['id']] = value[1]; types[value[1]] = True
        else:
            _need(value[0] == 'COLLAR' and r['id'] in b['seeds'])
    ids = sorted(types)
    _need(len(ids) == 33)
    channels = _channels(ids, marking)
    added = {i: [] for i in ids}
    for ch, zeros, ones in channels:
        for value, side in (('0', zeros), ('1', ones)):
            for tid, x, y in side:
                added[tid].append((x, y, ch, value))
    count = 0
    for old, new in zip(b['placements'], a['placements']):
        _tick(budget)
        for k in ('id', 'type', 'translation', 't'):
            _eq(new[k], old[k])
        expected = copy.deepcopy(old['m'])
        if old['id'] in ordinary:
            _need(all(m[2] not in {c[0] for c in channels} for m in old['m']))
            tx, ty = old['translation']
            _eq(old['t'], [[tx, ty, 1]])
            for x, y, ch, value in added[ordinary[old['id']]]:
                expected.append([tx+x, ty+y, ch, value]); count += 1
        _eq(new['m'], sorted(expected))
    return _verified(base_sha256=canonical_sha256(b), augmented_sha256=canonical_sha256(a),
                     added_components=count, channels=len(channels))


def _q_model(domains, conflicts=(), extra_required=()):
    """Future tiny qualification literals; never used to generate label truth."""
    rows = []
    for p, ids in domains:
        for pid in ids:
            rows.append({'id': pid, 'type': pid, 'translation': list(p),
                         't': [[*p, 1]], 'm': []})
    lookup = {r['id']: r for r in rows}
    for n, (a, b) in enumerate(conflicts):
        ch = 'QUALIFICATION_PAIR:'+str(n)
        lookup[a]['m'].append([100, 100, ch, '0'])
        lookup[b]['m'].append([100, 100, ch, '1'])
    return {'schema': 'GCTS-finite-point-instance-v1', 'capacity': 1,
            'required': [list(p) for p, _ in domains] + [list(p) for p in extra_required],
            'placements': rows, 'seeds': []}


def _q_models():
    q = {}
    q['Q01'] = _q_model([])
    seed = _q_model([((0, 0), ['s', 'seed_alt']), ((2, 0), ['bad', 'good', 'missing'])])
    sm = {r['id']: r for r in seed['placements']}
    for pid, v in (('s', '0'), ('bad', '1'), ('good', '0')):
        sm[pid]['m'] = [[101, 103, 'SEED_REMOTE', v]]
    seed['seeds'] = ['s']; q['Q02'] = seed
    q['Q03'] = _q_model([((0, 0), ['a'])], extra_required=[(2, 0)])
    q['Q04'] = _q_model([((0, 0), ['a0', 'a1']), ((2, 0), ['b'])])
    q['Q05'] = _q_model([((0, 0), ['a0', 'a1']), ((2, 0), ['b0', 'b1']),
                         ((4, 0), ['c0', 'c1'])], [('a1', 'c0')])
    q['Q06'] = _q_model([((0, 0), ['a0', 'a1']), ((2, 0), ['b0', 'b1'])],
                        [('a0', 'b0'), ('a0', 'b1')])
    q['Q07'] = _q_model([((0, 0), ['a0', 'a1']), ((2, 0), ['b0', 'b1'])])
    unequal = [(a+v, b+v) for a, b in (('a', 'b'), ('a', 'c'), ('b', 'c')) for v in ('0', '1')]
    q['Q08'] = _q_model([((0, 0), ['a0', 'a1']), ((2, 0), ['b0', 'b1']),
                         ((4, 0), ['c0', 'c1'])], unequal)
    q['Q09'] = _q_model([((0, 0), ['a0', 'a1'])])
    q['Q10'] = copy.deepcopy(q['Q06'])
    q['Q11'] = _q_model([((0, 0), ['a'])])
    q['Q12'] = copy.deepcopy(q['Q09']); q['Q13'] = copy.deepcopy(q['Q07'])
    return q


class _QualificationCallbackError(RuntimeError):
    """Unrelated callback exception; must never turn into UNKNOWN."""


def _q_collector(model, mode, budget, refusal=None):
    events, native, failed = [], [], []
    def collect(controller, event):
        _tick(budget)
        raw_snapshot = controller.snapshot()
        if mode == 'POINT':
            state = verify_point_snapshot(model, raw_snapshot, event, budget=budget)['normalized_state']
        else:
            # The independently reconstructed export is not a producer getter.
            state = verify_normalized_state(model, _export(_model(model, budget), budget),
                                            raw_snapshot, budget=budget)['normalized_state']
            _event(_model(model, budget), state, event, budget)
        if refusal is not None:
            try:
                refusal(event)
            except BaseException:
                failed.append({'event': copy.deepcopy(event), 'snapshot': copy.deepcopy(raw_snapshot),
                               'normalized_state': copy.deepcopy(state)})
                raise
        data = copy.deepcopy(event['data'])
        if event['kind'] == 'ROLLED_BACK':
            data = {'restored_state_sha256': canonical_sha256(state)}
        normalized = {'seq': len(events), 'kind': event['kind'], 'data': data,
                      'snapshot': copy.deepcopy(state),
                      'domains_sha256': canonical_sha256(state['eligible_domains']),
                      'state_sha256': canonical_sha256(state)}
        events.append(normalized)
        native.append({'event': copy.deepcopy(event), 'snapshot': copy.deepcopy(raw_snapshot)})
    return collect, events, native, failed


def _q_snapshot(model, mode, controller, budget):
    raw = controller.snapshot()
    if mode == 'POINT':
        checked = verify_point_snapshot(model, raw, budget=budget)
    else:
        checked = verify_normalized_state(model, _export(_model(model, budget), budget), raw, budget=budget)
    return raw, checked['normalized_state']


def _q_pair(qid, model, point_api, b_api, budget):
    model = _model(model, budget)
    spec = b_api.export_unit_cell_csp(copy.deepcopy(model))
    verify_unit_cell_export(model, spec, budget=budget)
    records = []
    for mode, api in (('POINT', point_api), ('CSP', b_api)):
        _tick(budget)
        owned = api.BudgetExceeded if mode == 'POINT' else api.CSPBudgetExceeded
        def refusal(event):
            if qid == 'Q11' and event['kind'] == 'SOLVE_RESULT':
                raise owned('QUALIFICATION_FINAL_REFUSAL')
            if qid == 'Q12' and event['kind'] == 'PLACED':
                raise _QualificationCallbackError('QUALIFICATION_UNRELATED')
        audit, events, native, failed = _q_collector(model, mode, budget, refusal)
        controller = (api.Engine(copy.deepcopy(model), audit=audit, budget=budget) if mode == 'POINT'
                      else api.CellCSP(copy.deepcopy(spec), audit=audit, budget=budget))
        cp = controller.checkpoint()
        entry_raw, entry = _q_snapshot(model, mode, controller, budget)
        manual = []
        if qid == 'Q07':
            controller.place('a0', 'ENTRY_SELECTED'); controller.exclude('b0', 'ENTRY_BANNED')
            cp = controller.checkpoint()
            entry_raw, entry = _q_snapshot(model, mode, controller, budget)
        result = None
        if qid == 'Q12':
            try:
                controller.place('a0', 'CALLBACK_FAILURE')
            except _QualificationCallbackError as exc:
                _eq(str(exc), 'QUALIFICATION_UNRELATED')
            else:
                raise OracleError('QUALIFICATION_EXPECTED_EXCEPTION')
            _eq(_q_snapshot(model, mode, controller, budget)[1], entry)
        elif qid == 'Q13':
            controller.exclude('a0', 'MANUAL_BAN')
            cp1 = controller.checkpoint()
            manual.append(_q_snapshot(model, mode, controller, budget)[1])
            _need(any('a0' in r['candidates'] for r in manual[-1]['physical_domains']))
            _need(all('a0' not in r['candidates'] for r in manual[-1]['eligible_domains']))
            controller.place('a1', 'MANUAL_SELECT'); cp2 = controller.checkpoint()
            state2 = _q_snapshot(model, mode, controller, budget)[1]; manual.append(state2)
            controller.exclude('b0', 'NESTED_BAN'); manual.append(_q_snapshot(model, mode, controller, budget)[1])
            controller.rollback(cp2); _eq(_q_snapshot(model, mode, controller, budget)[1], state2)
            controller.rollback(cp1); _eq(_q_snapshot(model, mode, controller, budget)[1], manual[0])
            controller.rollback(cp); _eq(_q_snapshot(model, mode, controller, budget)[1], entry)
        else:
            limit = 0 if qid == 'Q09' else (1 if qid in ('Q01', 'Q10') else 100)
            result = controller.solve(node_limit=limit)
            final_raw, final = _q_snapshot(model, mode, controller, budget)
            if mode == 'POINT':
                verify_point_result(model, result, budget=budget)
            else:
                checked = verify_unit_cell_result(model, spec, result, events, budget=budget)
                _eq(checked['status'], 'VERIFIED')
            if qid in ('Q09', 'Q10', 'Q11'):
                _eq(result['status'], 'UNKNOWN'); _eq(final, entry)
                _eq(final['excluded'], entry['excluded'])
            elif qid in ('Q03', 'Q08'):
                _eq(result['status'], 'EXHAUSTED_FINITE_SEARCH'); _eq(final, entry)
            else:
                _eq(result['status'], 'FINITE_EXACT_SOLUTION')
            if qid == 'Q03':
                _eq(next(e['data']['point'] for e in events if e['kind'] == 'DECISION'), [2, 0])
            if qid == 'Q04':
                first = next(e['data'] for e in events if e['kind'] == 'DECISION')
                _eq(first['kind'], 'FORCED'); _eq(first['point'], [2, 0])
            if qid == 'Q05':
                first = next(e['data'] for e in events if e['kind'] == 'DECISION')
                _eq(first, {'kind': 'BRANCH', 'point': [0, 0], 'candidates': ['a0', 'a1']})
            if qid == 'Q06':
                bans = [e for e in events if e['kind'] == 'EXCLUDED']
                _need(any(e['data'] == {'id': 'a0', 'reason': 'EXHAUSTED_CHILD'} for e in bans))
            if result['status'] == 'FINITE_EXACT_SOLUTION':
                controller.rollback(cp); _eq(_q_snapshot(model, mode, controller, budget)[1], entry)
        final_raw, final = _q_snapshot(model, mode, controller, budget)
        _eq(final, entry)
        _events(model, events, budget)
        records.append({'id': qid, 'mode': mode, 'model': copy.deepcopy(model), 'spec': copy.deepcopy(spec),
                        'entry_native': entry_raw, 'entry': entry, 'result': copy.deepcopy(result),
                        'events': copy.deepcopy(events), 'native_events': native, 'failed_callbacks': failed,
                        'manual_states': manual, 'final_native': final_raw, 'final': final,
                        'metrics': copy.deepcopy(controller.metrics)})
    a, b = records
    _eq(a['events'], b['events'])
    if a['result'] is not None:
        for field in ('status', 'reason', 'nodes', 'selected', 'context', 'solution_verified'):
            _eq(a['result'][field], b['result'][field])
        metrics = dict(a['result']['metrics'], nodes=a['result']['nodes'])
        _eq(metrics, b['result']['metrics'])
    _eq(a['metrics'], b['metrics'])
    return records


def _expect_refusal(call, error, code):
    try:
        call()
    except error as exc:
        _eq(exc.args, (code,))
        return {'status': 'EXPECTED_REJECTION', 'error': type(exc).__name__, 'args': list(exc.args)}
    raise OracleError('QUALIFICATION_EXPECTED_REJECTION')


def _q_b_negatives(models, paired, b_api, budget):
    negatives = []
    base = copy.deepcopy(models['Q02'])
    variants = []
    v = copy.deepcopy(base); v['extra'] = None; variants.append(v)
    v = copy.deepcopy(base); v['capacity'] = True; variants.append(v)
    v = copy.deepcopy(base); v['required'].append(list(v['required'][0])); variants.append(v)
    v = copy.deepcopy(base); v['placements'].append(copy.deepcopy(v['placements'][0])); variants.append(v)
    v = copy.deepcopy(base); next(r for r in v['placements'] if r['m'])['m'][0][3] = 0; variants.append(v)
    v = copy.deepcopy(base); r = next(r for r in v['placements'] if r['m']); r['m'].append(list(r['m'][0])); variants.append(v)
    v = copy.deepcopy(base); v['seeds'].append('unknown'); variants.append(v)
    v = copy.deepcopy(base); r = next(r for r in v['placements'] if r['id'] == 'bad'); r['t'] = [[4, 0, 1]]; v['seeds'].append('bad'); variants.append(v)
    v = copy.deepcopy(base); next(r for r in v['placements'] if r['id'] == 'missing')['t'] = [[8, 0, 1]]; variants.append(v)
    v = _q_model([((0, 0), ['a'])]); v['capacity'] = 2; variants.append(v)
    v = _q_model([((0, 0), ['a'])]); v['required'].append([2, 0]); v['placements'][0]['t'].append([2, 0, 1]); variants.append(v)
    v = copy.deepcopy(base); v['placements'][0]['translation'][0] = True; variants.append(v)
    for n, v in enumerate(variants):
        _tick(budget)
        code = 'CSP_PROFILE_UNSUPPORTED' if n in (9, 10) else 'CSP_MODEL_INVALID'
        receipt = _expect_refusal(lambda v=v: b_api.export_unit_cell_csp(v), b_api.CSPError, code)
        negatives.append({'id': 'B_EXPORT_'+str(n+1), 'input': v, 'receipt': receipt})
    specs = []
    s2 = _export(_model(models['Q02'], budget), budget)
    s5 = _export(_model(models['Q05'], budget), budget)
    s6 = _export(_model(models['Q06'], budget), budget)
    v = copy.deepcopy(s2); del v['policy']; specs.append(v)
    v = copy.deepcopy(s5); v['variables'].reverse(); specs.append(v)
    v = copy.deepcopy(s5); v['variables'][0]['domain'].pop(); specs.append(v)
    v = copy.deepcopy(s2); v['unaries'][0]['allowed'] = not v['unaries'][0]['allowed']; specs.append(v)
    v = copy.deepcopy(s6); v['binary'].pop(); specs.append(v)
    v = copy.deepcopy(s5); v['binary'].append({'left': [0, 0], 'right': [2, 0], 'allowed_rows': [3, 3]}); specs.append(v)
    v = copy.deepcopy(s6); v['binary'][0]['allowed_rows'][0] ^= 1; specs.append(v)
    v = copy.deepcopy(s2); v['preprocessed'][0]['reason'] = 'WRONG'; specs.append(v)
    for n, v in enumerate(specs):
        _tick(budget)
        receipt = _expect_refusal(lambda v=v: b_api.CellCSP(v), b_api.CSPError, 'CSP_SPEC_INVALID')
        negatives.append({'id': 'B_SPEC_'+str(n+1), 'input': v, 'receipt': receipt})
    good = _export(_model(models['Q07'], budget), budget)
    operations = []
    operations.append(lambda: b_api.CellCSP(good, budget=0))
    def numeric_budget():
        obj = b_api.CellCSP(good, budget=lambda: 0)
        return obj.decision()
    operations.append(numeric_budget)
    operations.append(lambda: b_api.CellCSP(good).solve(node_limit=True))
    operations.append(lambda: b_api.CellCSP(good).place('unknown', 'TEST'))
    operations.append(lambda: b_api.CellCSP(good).rollback(-1))
    def reenter():
        def audit(obj, event):
            if event['kind'] == 'INITIALIZED':
                obj.exclude('a0', 'REENTER')
        return b_api.CellCSP(good, audit=audit)
    operations.append(reenter)
    codes = ['CSP_CALLBACK_INVALID', 'CSP_CALLBACK_INVALID', 'CSP_NODE_LIMIT_INVALID',
             'CSP_OPERATION_INVALID', 'CSP_OPERATION_INVALID', 'CSP_OPERATION_INVALID']
    for n, (call, code) in enumerate(zip(operations, codes)):
        _tick(budget)
        negatives.append({'id': 'B_OPERATION_'+str(n+1),
                          'receipt': _expect_refusal(call, b_api.CSPError, code)})
    by_id = {(r['id'], r['mode']): r for r in paired}
    sat = by_id['Q07', 'CSP']; unsat = by_id['Q08', 'CSP']
    for n in range(6):
        _tick(budget)
        source = sat if n < 3 else unsat
        forged = copy.deepcopy(source['result'])
        if n < 2:
            selected = ['a1', 'b1'] if n == 0 else ['a0', 'b0']
            context = {'selected': selected, 'excluded': []}
            final = _state(source['model'], context, budget)
            forged['selected'] = selected; forged['final'] = final
            forged['certificate']['solution'] = final['assigned']
        elif n == 2:
            forged['certificate']['solution'].pop()
        elif n == 3:
            root = forged['certificate']['root']
            _eq(root['kind'], 'BRANCH'); del root['remainder']
        elif n == 4:
            pending = [forged['certificate']['root']]
            while pending:
                node = pending.pop()
                if node['kind'] == 'DEAD':
                    node['point'] = [0, 0]; break
                if node['kind'] == 'FORCED':
                    pending.append(node['child'])
                else:
                    pending.extend((node['child'], node['remainder']))
            else:
                raise OracleError('QUALIFICATION_NO_DEAD')
        else:
            h = forged['certificate']['root']['domains_sha256']
            forged['certificate']['root']['domains_sha256'] = ('0' if h[0] != '0' else '1') + h[1:]
        checked = verify_unit_cell_result(source['model'], source['spec'], forged, None, budget=budget)
        _eq(checked['status'], 'REJECTED')
        negatives.append({'id': 'B_FORGERY_'+str(n+1), 'result': forged, 'receipt': checked})
    _eq(len(negatives), 32)
    return negatives


def _q_catalogue(negatives=()):
    ids = ['QUAL_TYPE:'+str(n).zfill(2) for n in range(33)]
    rows = []
    for d in D:
        for a in ids:
            for b in ids:
                key = (a, b, d)
                rows.append({'a': a, 'b': b, 'd': list(d),
                             'status': 'LOCAL_NEGATIVE' if key in negatives else 'LOCAL_POSITIVE',
                             'proof_id': 'SYNTHETIC_API_ONLY:'+str(len(rows))})
    return {'schema': 'GCTS-four-corner-checked-label-catalogue-v1',
            'system_sha256': '0'*64, 'tile_ids': ids, 'labels': rows}


def _q_c_controls(c_api, budget):
    """Synthetic representation/API controls, not raw-palette label evidence."""
    out = []
    empty = _q_catalogue()
    ids = empty['tile_ids']
    same = _q_catalogue(((ids[0], ids[0], D[2]),))
    pair = _q_catalogue(((ids[0], ids[1], D[2]), (ids[2], ids[3], D[3])))
    for name, cat in (('C01_EMPTY', empty), ('C02_SAME_TYPE', same), ('C03_UNSAFE_MERGE', pair)):
        _tick(budget)
        before = copy.deepcopy(cat)
        results = []
        for method in (c_api.dedicated_corner_marking, c_api.synthesize_corner_marking):
            observed_callbacks = [0]
            def counted_budget():
                observed_callbacks[0] += 1
                _tick(budget)
            result = method(cat, budget=counted_budget)
            _eq(result['metrics']['budget_callbacks'], observed_callbacks[0])
            receipt = verify_corner_result(cat, result, budget=budget)
            _eq(receipt['activation_allowed'], True)
            audit = c_api.audit_corner_marking(cat, result['marking'], budget=budget)
            verify_corner_audit(cat, result['marking'], audit, budget=budget)
            _eq(cat, before)
            expected_channels = 0 if name == 'C01_EMPTY' else (1 if name == 'C02_SAME_TYPE' else 2)
            _eq(len(result['marking']['channels']), expected_channels)
            results.append({'result': copy.deepcopy(result), 'audit': copy.deepcopy(audit), 'receipt': receipt})
        # Mutating a returned detached map cannot affect input or another call.
        detached = copy.deepcopy(results[0]['result'])
        detached['marking']['channels'].append({'id': 'LOCAL_MUTATION', 'zeros': [], 'ones': []})
        _eq(cat, before)
        _need(not _same(detached, results[0]['result']))
        out.append({'id': name, 'catalogue': cat, 'calls': results})
    label = copy.deepcopy(same['labels'][2178])
    fragment = c_api.new_corner_fragment(ids, label, budget=budget)
    verify_corner_fragment(ids, label, fragment, budget=budget)
    _eq(fragment['label'], label)
    fragment['label']['proof_id'] = 'DETACHED_MUTATION'
    _eq(label['proof_id'], same['labels'][2178]['proof_id'])
    # Retain a fresh local copy of the pre-mutation full fragment without a second producer call.
    fragment['label']['proof_id'] = label['proof_id']
    out.append({'id': 'C04_FRAGMENT_SAME_TYPE', 'label': label, 'fragment': fragment})
    unsafe = {'schema': 'GCTS-four-corner-partial-binary-marking-v1', 'system_sha256': '0'*64,
              'channels': [{'id': 'LEARNED_CORNER:0', 'zeros': [[ids[0], 1, 1]],
                            'ones': [[ids[1], -1, -1]]}]}
    audit = c_api.audit_corner_marking(empty, unsafe, budget=budget)
    verify_corner_audit(empty, unsafe, audit, budget=budget)
    _eq(len(audit['uncertified_conflicts']), 1)
    out.append({'id': 'C05_UNSAFE_AUDIT', 'marking': unsafe, 'audit': audit})
    capacity = copy.deepcopy(unsafe); capacity['channels'][0]['ones'][0][1:] = [1, 1]
    audit = c_api.audit_corner_marking(empty, capacity, budget=budget)
    verify_corner_audit(empty, capacity, audit, budget=budget)
    _eq(audit['uncertified_conflicts'], [])
    _eq(audit['induced_contacts'], [{'label_id': None, 'a': ids[0], 'b': ids[1], 'd': [0, 0],
                                     'status': 'CAPACITY_ONLY', 'proof_id': None}])
    out.append({'id': 'C06_CAPACITY_ONLY', 'marking': capacity, 'audit': audit})
    malformed = []
    v = copy.deepcopy(empty); v['extra'] = 1
    malformed.append(('EXTRA', lambda v=v: c_api.dedicated_corner_marking(v), c_api.CornerCatalogueError, 'CORNER_INPUT_SHAPE', v))
    v = copy.deepcopy(empty); v['labels'].pop()
    malformed.append(('COVERAGE', lambda v=v: c_api.dedicated_corner_marking(v), c_api.CornerCatalogueError, 'CORNER_CATALOGUE_COVERAGE', v))
    v = copy.deepcopy(empty); v['labels'][0]['status'] = 'UNKNOWN'
    malformed.append(('PROOF', lambda v=v: c_api.dedicated_corner_marking(v), c_api.CornerCatalogueError, 'CORNER_LABEL_ASSOCIATION', v))
    v = copy.deepcopy(empty); v['labels'][0]['status'] = 'LOCAL_NEGATIVE'
    malformed.append(('AXIAL_NEGATIVE', lambda v=v: c_api.dedicated_corner_marking(v), c_api.CornerCatalogueError, 'CORNER_LABEL_ASSOCIATION', v))
    v = copy.deepcopy(label); v['status'] = 'LOCAL_POSITIVE'
    malformed.append(('FRAGMENT', lambda v=v: c_api.new_corner_fragment(ids, v), c_api.CornerCatalogueError, 'CORNER_FRAGMENT_LABEL', v))
    v = copy.deepcopy(unsafe); v['channels'][0]['zeros'][0][1] = True
    malformed.append(('BOOL_CORNER', lambda v=v: c_api.audit_corner_marking(empty, v), c_api.CornerMarkingError, 'CORNER_MAP_SHAPE', v))
    v = copy.deepcopy(unsafe); v['channels'][0]['ones'] = copy.deepcopy(v['channels'][0]['zeros'])
    malformed.append(('MAP_CONFLICT', lambda v=v: c_api.audit_corner_marking(empty, v), c_api.CornerMarkingError, 'CORNER_MAP_CONFLICT', v))
    malformed.append(('BUDGET_TYPE', lambda: c_api.new_corner_fragment(ids, label, budget=0), TypeError,
                      'budget must be callable or None', {'budget_literal': 0}))
    for name, call, error, code, data in malformed:
        _tick(budget)
        out.append({'id': 'C_REJECT_'+name, 'input': data,
                    'receipt': _expect_refusal(call, error, code)})
    def stop():
        raise c_api.CornerBudgetExceeded('QUALIFICATION_STOP')
    stopped = c_api.dedicated_corner_marking(pair, budget=stop)
    verify_corner_result(pair, stopped, budget=budget)
    _eq(stopped['status'], 'NO_TEMPLATE_BUDGET_STOP')
    out.append({'id': 'C15_BATCH_BUDGET_STOP', 'result': stopped})
    for name, call in (
        ('FRAGMENT', lambda: c_api.new_corner_fragment(ids, label, budget=stop)),
        ('AUDIT', lambda: c_api.audit_corner_marking(empty, unsafe, budget=stop))):
        receipt = _expect_refusal(call, c_api.CornerBudgetExceeded, 'QUALIFICATION_STOP')
        out.append({'id': 'C_BUDGET_PROPAGATE_'+name, 'receipt': receipt})
    def unrelated():
        raise _QualificationCallbackError('QUALIFICATION_UNRELATED')
    receipt = _expect_refusal(lambda: c_api.synthesize_corner_marking(pair, budget=unrelated),
                              _QualificationCallbackError, 'QUALIFICATION_UNRELATED')
    out.append({'id': 'C18_UNRELATED_PROPAGATES', 'receipt': receipt})
    # A later refusal must retain a completely feasible checkpoint, never a partial map.
    complete_count = out[2]['calls'][1]['result']['metrics']['budget_callbacks']
    _need(complete_count > 2)
    calls = [0]
    def stop_after_checkpoint():
        calls[0] += 1
        # Refuse the final public callback of the same completed synthetic call.
        # A complete safe checkpoint already exists, without a private hook.
        _tick(budget)
        if calls[0] >= complete_count:
            raise c_api.CornerBudgetExceeded('QUALIFICATION_STOP')
    partial = c_api.synthesize_corner_marking(pair, budget=stop_after_checkpoint)
    check = verify_corner_result(pair, partial, budget=budget)
    _eq(partial['status'], 'FEASIBLE_BUDGET_STOP')
    _eq(partial['marking'], out[2]['calls'][1]['result']['marking'])
    out.append({'id': 'C19_LATE_FEASIBLE_CHECKPOINT', 'result': partial, 'receipt': check,
                'observed_callback_invocations': calls[0]})
    _eq(len(out), 19)
    return out


def qualify_public_apis(palette, point_api, B_api, C_api, *, budget=None):
    """Execute ONLY inside a later authorized once; retain complete finite evidence.

    Public APIs are passed as objects. The oracle never imports them. There are
    thirteen paired controls (26 records), 22 normal solve calls, 32 B refusals
    or forged checks, and 19 C controls. Negative operation controls include one
    refused boolean solve; none is an extra admitted solve outcome. C synthetic
    labels certify API behavior only, not the experimental palette or a theorem.
    """
    _tick(budget)
    palette_receipt = validate_palette(palette, budget=budget)
    models = _q_models()
    paired = []
    for qid, model in models.items():
        paired.extend(_q_pair(qid, model, point_api, B_api, budget))
    negatives = _q_b_negatives(models, paired, B_api, budget)
    corner = _q_c_controls(C_api, budget)
    _tick(budget)
    return _verified(schema='GCTS-corner-learning-public-API-qualification-v1',
                     palette_receipt=palette_receipt, paired_controls=paired,
                     B_negative_controls=negatives, C_controls=corner,
                     counts={'paired_controls': 13, 'paired_records': 26, 'normal_solve_calls': 22,
                             'B_negative_controls': 32, 'C_controls': 19},
                     scope='FINITE_SYNTHETIC_PUBLIC_API_QUALIFICATION_NOT_REAL_LABELS_OR_BENCHMARK')
