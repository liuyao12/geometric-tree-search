"""Administrative exact-byte evidence packaging; no scientific imports/calls.
Only run after Root freezes final reader/results/content admission/local UI.
The resulting assembly receipt is not independent package/content admission.
"""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import zipfile

Y=Path('/private/tmp/gcts-receptor-family-generation-20261028-v1')
OWN=Path('/private/tmp/gcts-B-Y-package-v1')
PROVISIONAL=OWN/'Y-provisional-evidence-inventory-v1.json'
OUTPUT=OWN/'complete-evidence-v1'
NAME='receptor-family-proof-search-evidence-v1.zip'
CAP=67108864
ROOT_STAGE=Y/'root/publication-receptor-family-proof-search-v1'
PAYLOAD_NAMES={'receptor-family-proof-search-v1.html','receptor-family-proof-search-results-v1.json'}
EXCLUDED_DIRS={Y/'publisher-receptor-family-proof-search-payload',Y/'root/publication-receptor-family-proof-search-api-v1',Y/'root/receptor-family-proof-search-live-TLS-verification-v1'}

def stable(path):
    assert path.is_absolute() and path.resolve()==path and not path.is_symlink()
    a=path.stat();assert stat.S_ISREG(a.st_mode)
    data=path.read_bytes();b=path.stat()
    assert len(data)==a.st_size==b.st_size and (a.st_ino,a.st_mtime_ns)==(b.st_ino,b.st_mtime_ns)
    return data

def pin(path,data=None):
    if data is None:data=stable(path)
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def pretty(value):
    return (json.dumps(value,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')

def write_new(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb')as f:f.write(data)
    assert stable(path)==data
    return pin(path,data)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--final-inputs',required=True);args=ap.parse_args()
    config_path=Path(args.final_inputs);cfg=json.loads(stable(config_path))
    assert set(cfg)=={'schema','final_inputs','added_peer_dirs','Root_content_adoption'} and cfg['schema']=='Y-final-evidence-package-inputs-v1'
    assert type(cfg['final_inputs'])is list and len(cfg['final_inputs'])>=6 and type(cfg['added_peer_dirs'])is list
    required={Path(r['path']):r for r in cfg['final_inputs']};assert len(required)==len(cfg['final_inputs'])
    for path,ref in required.items():assert pin(path)==ref
    for n in PAYLOAD_NAMES:assert ROOT_STAGE/n in required
    assert type(cfg['Root_content_adoption'])is dict and Path(cfg['Root_content_adoption']['path'])in required and required[Path(cfg['Root_content_adoption']['path'])]==cfg['Root_content_adoption'],'Exact Root final content adoption input required'
    provisional=json.loads(stable(PROVISIONAL));origins={};reasons={};member_override={};excluded=[]
    def add(path,reason,member=None):
        path=Path(path);assert path.resolve()==path
        origins[path]=True;reasons.setdefault(path,set()).add(reason)
        if member is not None:
            assert path not in member_override or member_override[path]==member
            member_override[path]=member
    # Preserve already-frozen external closure; changed nonoperative Y drafts keep
    # their provisional snapshot as an explicitly historical second origin.
    for row in provisional['originals']:
        p=Path(row['original']['path'])
        if pin(p)!=row['original']:
            old=Path(row['staged']['path']);assert pin(old)==row['staged']
            add(old,'Superseded preliminary snapshot of '+str(p),'provisional-snapshots/'+row['member'])
        else:add(p,'Inherited exact provisional input')
    def skip(p):
        if p.suffix.lower()=='.zip':return 'Generated/old ZIP body excluded; no recursive archives.'
        if any(p==d or d in p.parents for d in EXCLUDED_DIRS):return 'Future publisher twins/API/TLS bodies/captures outside archive cut.'
        if ROOT_STAGE in p.parents and p not in required:return 'Only exact final HTML/JSON admitted from Root payload staging; no recursive ZIP/twin.'
        return None
    for p in sorted(Y.rglob('*')):
        if not p.is_file():continue
        why=skip(p)
        if why:excluded.append({'path':str(p),'reason':why});continue
        add(p,'Complete final eligible Y original tree')
    for directory in [Path(p)for p in provisional['external_peer_directories']+cfg['added_peer_dirs']]:
        assert directory.is_dir() and str(directory).startswith('/private/tmp/')
        for p in sorted(directory.rglob('*')):
            if p.is_file():
                assert p.suffix.lower()!='.zip','No hidden peer archive import'
                add(p,'Complete current independent review/support directory')
    for p in required:add(p,'Exact frozen final Root/L content/UI input')
    for p in (Path(__file__),config_path,PROVISIONAL,OWN/'Y-provisional-complete-evidence-staging-handoff-v1.json',OWN/'Y-independent-final-content-package-audit-checklist-v1.json'):
        add(p,'Administrative assembly planning Source/data, not scientific evidence','package-authoring/'+p.name)
    # Exact currently operative closed-role body guards and both whole attempts.
    plan=json.loads(stable(Y/'root/study-once-plan-002.json'))
    for group in ('sources','metadata'):
        for ref in plan[group].values():
            p=Path(ref['path']);assert pin(p)==ref;assert p in origins
    for n,count in (('001',197),('002',203)):
        physical=list((Y/('actual/study-'+n)).iterdir());assert len(physical)==count and all(p in origins for p in physical)
    assert not OUTPUT.exists();OUTPUT.mkdir();staging=OUTPUT/'originals';staging.mkdir()
    entries=[];names=set()
    for path in sorted(origins,key=str):
        data=stable(path)
        if path in required:assert pin(path,data)==required[path]
        name=member_override.get(path)
        if name is None:name='Y/'+str(path.relative_to(Y)) if Y in path.parents else 'external/'+str(path.relative_to('/private/tmp'))
        assert name not in names and not name.startswith('/')and all(x not in ('','.','..')for x in name.split('/'));names.add(name)
        dest=staging/name;write_new(dest,data)
        entries.append({'original':pin(path,data),'member':name,'reasons':sorted(reasons[path])})
    manifest={'schema':'Y-complete-self-excluding-original-evidence-manifest-v1','originals':entries,'original_count':len(entries),'original_bytes':sum(e['original']['bytes']for e in entries),'special_members':['MANIFEST.json','README.txt'],'manifest_and_README_excluded_from_original_count':True,'attempts':{'001':'Permanently UNADMITTED original failed postguard attempt; all197physical files/costs retained.','002':'Sole primary admitted full cohort; all203physical files retained; no best-run subset.'},'current_operational_sources':plan['sources'],'current_metadata':plan['metadata'],'final_inputs':cfg['final_inputs'],'archive_cut':'All original bytes enumerated before archive creation. Generated ZIP, later package peer/adoption/publication/TLS/live authorities/callers/receipts and publisher duplicate twins remain outside this immutable self-excluding archive. Exact final Root HTML/JSON and available local UI evidence are included. Historical Source/draft variants are provenance, not current runtime roles.','exclusions':[x for x in provisional['explicit_exclusions']+excluded if Path(x['path'])not in origins],'runtime':'D90 is raw-pinned in plans and ABIs, not vendored. Exact344byte authenticated bootstrap is included. Six original W donor compressed files included; no recursive old archive/cohort import.','assembly_is_not_independent_admission':True}
    mraw=pretty(manifest)
    readme=('Y receptor-family proof-search complete evidence archive\n\n'
            'Extract this single ordinary DEFLATE ZIP normally. MANIFEST.json maps every original absolute source path to its unique safe member, byte length and SHA256. Every original body is preserved unchanged, including inner gzip files.\n\n'
            'Study001 is permanently UNADMITTED: its original process failed post-data guards and saved no observer terminal. All its197physical files and costs remain. Study002 is the sole primary whole admitted cohort, not a selected best-result subset. Its203physical originals remain.\n\n'
            'Source variants, authoring notes and earlier reader/QA snapshots are provenance; only exact roles in the current plan are operative. The new finite Y universe is not unrestricted FOL/PA/Hilbert completeness or an old W/X universe speed comparison. UNKNOWN is not nonprovability, and this archive makes no RL-advantage claim.\n\n'
            'Current14Sources/44metadata, immutable master, exact344byte bootstrap, six raw W donors, complete independent review/support/proof-transcription originals, final reader/results and local UI evidence are included. D90 binary is pinned but not vendored. Old evidence archives and unrelated old cohorts are not recursively imported.\n\n'
            'The cut precedes this ZIP, independent package adoption and all future publication/TLS/live receipts. Those later records are kept separately to avoid circular hashes. MANIFEST.json and README.txt are the only generated special members and are excluded from original-file totals. Assembly verification is not independent content/package admission.\n').encode('ascii')
    write_new(OUTPUT/'MANIFEST.json',mraw);write_new(OUTPUT/'README.txt',readme)
    zip_path=OUTPUT/NAME
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=False)as z:
        for name,data in [('MANIFEST.json',mraw),('README.txt',readme)]+[(e['member'],stable(staging/e['member']))for e in entries]:
            zi=zipfile.ZipInfo(name,(2026,10,28,0,0,0));zi.create_system=3;zi.external_attr=0o100644<<16
            z.writestr(zi,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    assert zip_path.stat().st_size<=CAP
    with zipfile.ZipFile(zip_path)as z:
        infos=z.infolist();assert len(infos)==len(entries)+2 and len({x.filename for x in infos})==len(infos)and z.testzip()is None
        assert z.read('MANIFEST.json')==mraw and z.read('README.txt')==readme
        for e in entries:
            data=z.read(e['member']);assert len(data)==e['original']['bytes']and hashlib.sha256(data).hexdigest()==e['original']['sha256'];assert data==stable(Path(e['original']['path']))==stable(staging/e['member'])
    receipt={'schema':'Y-complete-evidence-assembly-and-whole-readback-v1','status':'ASSEMBLED_BYTES_VERIFIED_PENDING_INDEPENDENT_PACKAGE_ADOPTION','ZIP':pin(zip_path),'manifest':pin(OUTPUT/'MANIFEST.json'),'README':pin(OUTPUT/'README.txt'),'input_contract':pin(config_path),'original_count':len(entries),'original_bytes':manifest['original_bytes'],'ZIP_member_count':len(entries)+2,'all_ZIP_CRC_and_every_member_origin_staging_byte_hash_readback':True,'whole001_and002':{'001':197,'002':203},'Source_roles':14,'metadata_roles':44,'future_publication_or_TLS_calls':0,'scientific_subject_calls':0,'self_admission':False,'next':'Independent L package/raw-origin audit and Root adoption; Root may then copy exactZIP into reviewed payload twins and separately authorize publisher/TLS.'}
    result=write_new(OUTPUT/'complete-evidence-assembly-readback-v1.json',pretty(receipt))
    print(json.dumps({'receipt':result,'ZIP':receipt['ZIP'],'manifest':receipt['manifest'],'original_count':len(entries),'ZIP_member_count':len(entries)+2},sort_keys=True))

if __name__=='__main__':main()
