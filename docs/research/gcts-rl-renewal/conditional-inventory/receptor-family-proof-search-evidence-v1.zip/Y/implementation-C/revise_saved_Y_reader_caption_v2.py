"""Presentation-only successor; exact saved-data/JS caption substitution, no replay."""
from pathlib import Path
import hashlib
import json

OWN = Path('/private/tmp/gcts-receptor-family-generation-20261028-v1/implementation-C')
source = OWN / 'Y-reader-generated-v1.html'
target = OWN / 'Y-reader-generated-v2.html'
old = source.read_text()
assert hashlib.sha256(old.encode()).hexdigest() == 'bfb301c88ca84423a627ce8302292f9c938c25315f34e0a6d9fed17dca41116b'
changes = [
    ("(member?'Cluster member':'External receptor')", "(member?'Cluster member':'Other proof row')"),
    ('other rows form its interface or padding.', 'other proof rows may supply external premises or serve as padding.'),
]
new = old
for before, after in changes:
    assert new.count(before) == 1
    new = new.replace(before, after, 1)
back = new
for before, after in reversed(changes):
    back = back.replace(after, before, 1)
assert back == old
assert not target.exists()
target.write_text(new)
assert target.read_text() == new


def pin(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


receipt = {'schema': 'Y-reader-caption-Source2-presentation-successor-v1',
           'status': 'PRESENTATION_ONLY_COMPLETE', 'previous': pin(source), 'current': pin(target),
           'builder': pin(Path(__file__)), 'exact_inverse': True,
           'changes': [{'old': a, 'new': b} for a, b in changes],
           'unchanged_reader_data': pin(OWN / 'Y-reader-data-v1.json'),
           'unchanged_results': pin(OWN / 'Y-public-results-draft-v1.json'),
           'scope': 'Nonmember means other proof row; only actual recorded proposal members are highlighted. No extra receptor status inferred, no scientific data or algorithm change.',
           'project_scientific_calls': 0, 'network_calls': 0}
report = OWN / 'Y-reader-caption-successor-v2.json'
assert not report.exists()
report.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
print(json.dumps({'HTML': pin(target), 'receipt': pin(report)}, sort_keys=True))
