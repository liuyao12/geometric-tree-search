"""Inert Y regression/transfer experiment. No loader, IO, or target proof scripts.

The separate owned runner supplies pinned modules, metadata and six raw donors.
Only _read_donors/_Native are reused from admitted X; X.run is never invoked.
"""
import gzip
import hashlib
import io
import json
import time

VERSION = 'Y-RECEPTOR-FAMILY-EXPERIMENT-v1'


def _need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def _raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _sha(value):
    return hashlib.sha256(_raw(value)).hexdigest()


def _copy(value):
    return json.loads(_raw(value))


def _complete(receipt, reason):
    _need(receipt['status'] == 'COMPLETE' and receipt['value'] is not None, reason)
    return receipt['value']


def _summary(attempt):
    out = {k: v for k, v in attempt.items() if k != 'result'}
    if 'result' in attempt:
        result = attempt['result']
        out['result_ref'] = attempt['ref']
        out['statistics'] = result.get('stats', result.get('costs'))
        out['result_metadata'] = {k: result[k] for k in ('reason', 'event_extent', 'state_hashes') if k in result}
        if 'heuristic' in result:
            out['guidance_statistics'] = result['heuristic']['stats']
    return out


def run(modules, context, emit, budget, call):
    """One closed cohort. Unexpected exceptions invalidate the whole attempt."""
    started = time.perf_counter()
    _need(type(context) is dict and set(context) == {'plan', 'sources', 'metadata', 'donor_stored'},
          'exact injected context')
    names = ('cases', 'design', 'experiment_limits', 'donor_manifest', 'donor_admission')
    cases, design, limits, donor_manifest, donor_admission = (json.loads(context['metadata'][k]) for k in names)
    _need(len(cases) == 15 and len(design['train']) == 3 and len(design['heldout']) == 12
          and len(design['training_episode_order']) == 6 and set(cases) == set(design['train'] + design['heldout']),
          'all fixed regression inputs')
    _need(design['generation_profile'] == {'ui_rounds': 2, 'bridge_arity': 2, 'max_tautology_atoms': 12}
          and design['training_search_seconds'] == 1 and design['evaluation_search_seconds_per_lane'] == 2,
          'prospective finite profile and search windows')
    _need(len(context['metadata']['cases']) == design['cases']['bytes']
          and hashlib.sha256(context['metadata']['cases']).hexdigest() == design['cases']['sha256'],
          'exact frozen assertion bytes')
    input_image = _raw(cases)

    def charge(units):
        _need(type(units) is int and units >= 0, 'logical charge units')
        budget()

    def transform(role, name, *args, **kwargs):
        kwargs.setdefault('charge', charge)
        return call(role, name, *args, **kwargs)

    donors, donor_join = call('native_bridge', '_read_donors', context, donor_manifest, donor_admission, budget)
    donor_image = _raw(donors)
    emit('original-six-donor-associations', {'donors': donors, 'joins': donor_join, 'admission': donor_admission})
    before = time.perf_counter()
    program = call('tree_machine', 'Compiler', context['sources']['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    program_ref = emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - before
    native = call('native_bridge', '_Native', context['sources'], limits, program, emit, budget, call)
    bank_return = transform('inventory', 'build_bank', donors, limits['bank'])
    bank = _complete(bank_return, 'complete unchanged primitive bank')
    _need(len(bank['donors']) == 6 and len(bank['lemmas']) == 4, 'same acquired information')
    bank_check = transform('bank_verifier', 'verify_bank', donors, bank, limits=limits['bank_verifier'])
    _need(bank_check['status'] == 'VERIFIED', 'complete bank provenance reconstruction')
    bank_native = []
    for i, lemma in enumerate(bank['lemmas']):
        theory = dict(_copy(lemma['signature']), axioms=_copy(lemma['required_axioms']))
        bank_native.append(native.check('bank-lemma-' + str(i), {'theory': theory, 'goal': lemma['goal']}, lemma['proof']))
    bank_ref = emit('current-bank-and-native-checks', {'result': bank_return, 'audit': bank_check, 'native': bank_native})
    bank_image = _raw(bank)
    mined = transform('inventory', 'mine_patterns', bank, limits['mine'])
    patterns = _complete(mined, 'complete automatic mining')
    pattern_image = _raw(patterns)
    pattern_ref = emit('current-mined-patterns', mined)

    zero_checks = []
    def logical_check(theory, proof, target, checker_limits):
        """Host B8 only; large zero batches never enter the byte/C1 parser."""
        budget()
        _need(_raw(checker_limits) == _raw(limits['zero_checker']), 'separate closed zero-schema B8 limits')
        before = time.perf_counter()
        receipt = call('fol_checker', 'check', theory, proof, target, checker_limits)
        record = {'theory': theory, 'proof': proof, 'target': target, 'limits': checker_limits,
                  'receipt': receipt, 'seconds': time.perf_counter() - before,
                  'scope': 'Independent semantic audit of every emitted zero; not a searched target proof or C1 run.'}
        ref = emit('zero-schema-batch-' + str(len(zero_checks)), record)
        zero_checks.append({'ref': ref, 'lines': len(proof), 'status': receipt['status'], 'seconds': record['seconds']})
        return receipt

    qualification_records, qualification_checks = [], []
    def qualification_emit(name, record):
        identity = 'catalogue-qualification-' + name.replace('_', '-')
        ref = emit(identity, record)
        qualification_records.append({'id': name, 'ref': ref})
        for item in record['native_certificates']:
            _need(set(item) == {'label', 'problem', 'proof'}, 'qualified native extraction')
            qualification_checks.append({'case': name, 'label': item['label'],
                'check': native.check(identity + '-' + item['label'].replace('_', '-'), item['problem'], item['proof'])})
    qualification = call('catalogue_audit', 'qualify', modules['compiler'], modules['xengine'],
                         logical_check, qualification_emit)
    _need(qualification['status'] == 'PASS'
          and len(qualification_records) == design['qualification_records']
          and len(qualification_checks) == design['qualification_native_requests'], 'complete new-generator qualification')
    qualification_ref = emit('complete-new-catalogue-qualification', {'result': qualification,
                             'records': qualification_records, 'native_checks': qualification_checks})

    # Bounded in-memory current-wire checkpoints. No historical model cache or IO.
    packed_total = 0
    prepared = {}
    preparation_summaries = []
    for identity in design['train'] + design['heldout']:
        budget()
        given = cases[identity]
        before = time.perf_counter()
        item = {'id': identity, 'original': given, 'slots': design['slots'][identity],
                'status': 'UNKNOWN_EXTENSION'}
        extension = transform('inventory', 'extend_theory', given['theory'], bank, limits['extend'])
        item['extension'] = extension
        if extension['status'] == 'COMPLETE':
            application = extension['value']
            audit = transform('bank_verifier', 'verify_extension', given['theory'], bank, application,
                              limits=limits['bank_verifier'])
            _need(audit['status'] == 'VERIFIED', 'same eligible extension independently checked')
            problem = {'theory': application['theory'], 'goal': given['goal'], 'profile': design['generation_profile']}
            item.update(application=application, extension_audit=audit, problem=problem, status='UNKNOWN_BUILD')
            t = time.perf_counter()
            built = call('compiler', 'build_basis', problem['theory'], problem['goal'], problem['profile'], limits['basis'])
            item.update(build_seconds=time.perf_counter() - t,
                        build_ref=emit(identity + '-whole-build', built),
                        build_status=built['status'], build_reason=built['reason'],
                        build_costs=built['costs'], build_optimization=built['optimization'])
            if built['status'] == 'COMPLETE':
                compiled, generation = built['compiled'], built['generation']
                _need(generation is not None and generation['profile'] == problem['profile'], 'complete Y generation metadata')
                core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
                _need(_sha(core) == generation['compiled_core_sha256'], 'actual semantic-core generation binding')
                t = time.perf_counter()
                audit = call('catalogue_audit', 'verify_compiled', problem, compiled, generation, limits=limits['audit'])
                item.update(catalogue_audit=audit, catalogue_audit_seconds=time.perf_counter() - t,
                            generation=generation, status='UNKNOWN_AUDIT')
                _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid catalogue aborts whole study')
                if audit['status'] == 'VERIFIED':
                    t = time.perf_counter()
                    semantic = call('catalogue_audit', 'verify_zero_schemas', problem, compiled, logical_check,
                                    limits['zero_checker'], limits=limits['audit'])
                    item.update(zero_audit=semantic, zero_audit_seconds=time.perf_counter() - t)
                    _need(semantic['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid zero schema aborts whole study')
                    if semantic['status'] == 'VERIFIED':
                        t = time.perf_counter(); raw = _raw(compiled); packed = None
                        item['status'] = 'UNKNOWN_CHECKPOINT'
                        if len(raw) <= limits['checkpoint']['max_raw_bytes']:
                            packed = gzip.compress(raw, mtime=0)
                            if (len(packed) <= limits['checkpoint']['max_packed_bytes']
                                    and packed_total + len(packed) <= limits['checkpoint']['max_total_packed_bytes']):
                                packed_total += len(packed)
                                item['_packed'] = packed
                                item['checkpoint'] = {'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                                    'packed_bytes': len(packed), 'packed_sha256': hashlib.sha256(packed).hexdigest(),
                                    'problem_sha256': _sha(problem), 'generation_sha256': _sha(generation)}
                                item['status'] = 'COMPLETE'
                        item['checkpoint_seconds'] = time.perf_counter() - t
                        del raw, packed
                del compiled, core
            else:
                _need(built['status'] == 'UNKNOWN' and built['compiled'] is None and built['generation'] is None,
                      'no partial generator prefix')
            del built
        else:
            _need(extension['status'] == 'UNKNOWN' and extension['value'] is None, 'owned extension refusal only')
        item['preparation_seconds'] = time.perf_counter() - before
        summary = {k: v for k, v in item.items() if k != '_packed'}
        item['preparation_ref'] = emit(identity + '-whole-preparation', summary)
        prepared[identity] = item
        preparation_summaries.append(dict(summary, preparation_ref=item['preparation_ref']))
        budget()
    _need(len(prepared) == 15, 'all compile/audit attempts before any training')

    def restore(item):
        if item['status'] != 'COMPLETE': return None, 0.0
        t = time.perf_counter(); budget(); expected = item['checkpoint']; packed = item['_packed']
        _need(len(packed) == expected['packed_bytes'] and hashlib.sha256(packed).hexdigest() == expected['packed_sha256']
              and _sha(item['problem']) == expected['problem_sha256']
              and _sha(item['generation']) == expected['generation_sha256'], 'immutable current checkpoint scope')
        with gzip.GzipFile(fileobj=io.BytesIO(packed), mode='rb') as stream:
            raw = stream.read(expected['raw_bytes'] + 1)
        _need(len(raw) == expected['raw_bytes'] and hashlib.sha256(raw).hexdigest() == expected['raw_sha256'],
              'full bounded checkpoint decode')
        compiled = json.loads(raw); budget()
        return compiled, time.perf_counter() - t

    def positive(identity, item, proof):
        coarse = native.check(identity + '-coarse', item['problem'], proof)
        t = time.perf_counter()
        lower = transform('inventory', 'lower_proof', item['original']['theory'], bank, item['application'], proof, limits['lower'])
        result = {'coarse_proof': proof, 'coarse_check': coarse, 'lowering': lower,
                  'lowering_seconds': time.perf_counter() - t, 'verified': False, 'original_status': 'UNKNOWN_LOWERING'}
        if lower['status'] == 'COMPLETE':
            value = lower['value']
            audit = transform('bank_verifier', 'verify_lowering', item['original']['theory'], bank,
                              item['application'], proof, value, limits=limits['bank_verifier'])
            result['lowering_audit'] = audit
            _need(audit['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid lowering aborts whole study')
            if audit['status'] == 'VERIFIED':
                _need(value['theory'] == item['original']['theory']
                      and value['goal'] == item['original']['goal'], 'exact original target binding')
                original = native.check(identity + '-original', item['original'], value['proof'])
                result.update(verified=True, original_status='VERIFIED', original_proof=value['proof'],
                              original_check=original)
            else:
                result['original_status'] = 'UNKNOWN_LOWERING_AUDIT'
        else:
            _need(lower['status'] == 'UNKNOWN' and lower['value'] is None, 'owned expansion refusal only')
        result['ref'] = emit(identity + '-whole-positive', result)
        return result

    def point(identity, item, compiled, mode, seed, state, wall, load_seconds):
        row = {'id': identity, 'mode': mode, 'seed': seed, 'status': 'NOT_RUN_' + item['status'],
               'verified': False, 'original_status': 'NO_CERTIFICATE',
               'preparation_ref': item['preparation_ref'], 'checkpoint_load_seconds': load_seconds}
        if compiled is None: return row
        state_before = _raw(state); factory = planner = None; t = time.perf_counter()
        if mode != 'lex':
            config = _copy(limits['planner'])
            if mode != 'train': config['epsilon'] = 0
            planner, factory = call('policy', 'make_proposer', compiled, item['slots'], patterns,
                                   modules['inventory'], state, mode, seed, config)
            _need(factory['status'] in ('COMPLETE', 'UNKNOWN')
                  and (factory['status'] == 'COMPLETE' or planner is None), 'owned optional planner refusal')
        answer = call('xengine', 'solve', compiled, item['slots'], dict(limits['point'], wall_seconds=wall),
                      propose=planner, proposal_limits=limits['proposal'])
        elapsed = time.perf_counter() - t
        summary = call('policy', 'summarize', planner) if planner is not None else None
        _need(answer['status'] in ('SAT', 'UNSAT', 'UNKNOWN') and _raw(state) == state_before,
              'honest point result and immutable policy')
        if answer['entry_state'] is not None:
            _need(_raw(answer['entry_state']) == _raw(answer['restored_state'])
                  and _sha(answer['entry_state']) == answer['state_hashes']['entry']
                  == answer['state_hashes']['restored'], 'full point state restoration')
        _need(answer['stats']['trail_writes'] == answer['stats']['trail_undos'], 'whole trail cleanup')
        row.update(status=answer['status'], result=answer, search_seconds=elapsed, factory=factory, summary=summary)
        if answer['status'] == 'SAT':
            selected = call('catalogue_audit', 'verify_selection', item['problem'], compiled, item['slots'],
                            answer['selected'], limits=limits['audit'])
            _need(selected['status'] in ('VERIFIED', 'UNKNOWN'), 'invalid selection aborts whole study')
            decoded = call('compiler', 'decode', compiled, item['slots'], answer['selected'], limits['decode'])
            row.update(selection_audit=selected, decoded=decoded)
            _need(decoded['status'] in ('UNVERIFIED_CERTIFICATE', 'UNKNOWN'), 'invalid decode aborts whole study')
            if decoded['status'] == 'UNKNOWN':
                _need(decoded['proof'] is None and decoded['target'] is None, 'no decoded prefix')
                row['original_status'] = 'UNKNOWN_DECODE'
            else:
                _need(_raw(decoded['target']) == _raw(item['problem']['goal']), 'decoded target binding')
                if selected['status'] == 'UNKNOWN':
                    row['original_status'] = 'UNKNOWN_SELECTION_AUDIT'
                else:
                    _need(_raw(decoded['proof']) == _raw(selected['proof']), 'independent selected/decode agreement')
                    row['positive'] = positive(identity, item, decoded['proof'])
                    row['verified'] = row['positive']['verified']
                    row['original_status'] = row['positive']['original_status']
        _need(_sha(compiled) == item['checkpoint']['raw_sha256'], 'unchanged actual shared catalogue')
        row['ref'] = emit(identity + '-full-point', row)
        return row

    initial = call('policy', 'initial_state', patterns, limits['policy'])
    state = _complete(initial, 'initial policy')
    initial_state = _copy(state); training = []
    for index, case_id in enumerate(design['training_episode_order']):
        budget(); item = prepared[case_id]; compiled, load_seconds = restore(item)
        identity = 'training-' + str(index) + '-' + case_id; old_state = _copy(state)
        row = point(identity, item, compiled, 'train', 1000 + index, state, 1, load_seconds)
        update = None
        policy_eligible = (row.get('status') != 'SAT' or row['verified']
                           or row.get('positive', {}).get('lowering', {}).get('status') == 'UNKNOWN')
        if row.get('summary') is not None and policy_eligible:
            update = call('policy', 'update_policy', state, identity, row['result'], row['summary'], row['verified'], limits['policy'])
            _need(_raw(state) == _raw(old_state), 'functional training update')
            if update['status'] == 'COMPLETE': state = update['value']['state']
            else: _need(update['status'] == 'UNKNOWN' and update['value'] is None, 'owned update refusal')
        update_scope = ('NO_POLICY_SUMMARY_NO_UPDATE' if row.get('summary') is None else
                        'CURRENT_POLICY_API' if policy_eligible else 'UNKNOWN_ASSURANCE_NO_POLICY_UPDATE')
        record = {'episode': index, 'case_id': case_id, 'attempt': _summary(row), 'state_before': old_state,
                  'update': update, 'state_after': _copy(state),
                  'update_scope': update_scope}
        record['ref'] = emit(identity + '-whole-episode', record); training.append(record)
        del compiled
    frozen = _copy(state); frozen_sha = _sha(frozen)
    emit('frozen-heldout-policy', {'state': frozen, 'sha256': frozen_sha})
    evaluation = []
    for index, case_id in enumerate(design['heldout']):
        budget(); item = prepared[case_id]; compiled, load_seconds = restore(item); lanes = {}
        for lane, mode in (('POINT_LEX', 'lex'), ('POINT_UNIFORM_CLUSTERS', 'uniform'), ('POINT_LEARNED_CLUSTERS', 'trained')):
            identity = case_id + '-' + lane.lower().replace('_', '-')
            lanes[lane] = _summary(point(identity, item, compiled, mode, 2000 + index, frozen, 2, load_seconds))
            _need(_sha(frozen) == frozen_sha, 'heldout policy frozen')
        identity = case_id + '-same-inventory-shared-dag'
        control = {'id': identity, 'status': 'NOT_RUN_' + item['status'], 'verified': False, 'original_status': 'NO_CERTIFICATE',
                   'preparation_ref': item['preparation_ref'], 'checkpoint_load_seconds': load_seconds}
        if compiled is not None:
            t = time.perf_counter()
            answer = call('catalogue_audit', 'backward_dag', item['problem'], compiled, item['slots'], limits['control'])
            control.update(status=answer['status'], result=answer, search_seconds=time.perf_counter() - t)
            _need(answer['status'] in ('DERIVABLE', 'NOT_DERIVABLE', 'UNKNOWN'), 'finite shared-inventory control')
            if answer['status'] == 'DERIVABLE':
                _need(len(answer['proof']) <= item['slots'], 'bounded DAG certificate')
                control['positive'] = positive(identity, item, answer['proof'])
                control['verified'] = control['positive']['verified']
                control['original_status'] = control['positive']['original_status']
            _need(_sha(compiled) == item['checkpoint']['raw_sha256'], 'control preserves actual shared catalogue')
        control['ref'] = emit(identity + '-full-control', control)
        lanes['SAME_INVENTORY_SHARED_DAG'] = _summary(control)
        record = {'id': case_id, 'original': item['original'], 'slots': item['slots'], 'lanes': lanes,
                  'preparation_ref': item['preparation_ref'], 'shared_checkpoint_load_seconds': load_seconds,
                  'frozen_policy_sha256': frozen_sha}
        record['ref'] = emit(case_id + '-whole-heldout', record); evaluation.append(record)
        del compiled
    _need(len(training) == 6 and len(evaluation) == 12 and _raw(cases) == input_image
          and _raw(donors) == donor_image and _raw(bank) == bank_image and _raw(patterns) == pattern_image
          and _sha(program) == native.identity['program'] and _sha(frozen) == frozen_sha, 'whole cohort postguards')
    return {'schema': 'Y-receptor-family-experiment-v1', 'version': VERSION, 'status': 'COMPLETE',
            'design': design, 'limits': limits, 'historical_acquisition_seconds': donor_admission['acquisition_seconds'],
            'donor_custody': donor_join, 'native_program': program_ref,
            'native_preparation_seconds': native_preparation_seconds, 'bank_ref': bank_ref, 'patterns_ref': pattern_ref,
            'qualification': qualification, 'qualification_ref': qualification_ref,
            'qualification_checks': qualification_checks, 'zero_schema_checks': zero_checks,
            'preparations': preparation_summaries, 'checkpoint_total_packed_bytes': packed_total,
            'initial_policy': initial_state, 'training': training, 'frozen_policy': frozen, 'evaluation': evaluation,
            'native_memo': {'requests': native.requests, 'request_count': len(native.requests), 'hits': native.hits,
                            'executions': len(native.cache), 'execution_seconds': native.execution_seconds},
            'seconds': time.perf_counter() - started,
            'scope': 'Fixed X assertion regressions, not globally unseen problems. New explicitly declared finite '
                     'goal/receptor witness language; no old W/X universe equivalence or direct speedup claim. '
                     'Same new certified catalogue/bank/per-case bound for lex/uniform/frozen-policy/DAG lanes. '
                     'Fresh policy, six training attempts, all48 heldout lane positions including NOT_RUN and UNKNOWN. '
                     'Four shared native-verified donor lemmas; no target proof script/answer inputs. '
                     'Large B8 zero batches are separate from searched64-line coarse/original C1+B certificates. '
                     'DAG certificates may be shorter than the row bound; padded certificates are derived overlays, '
                     'not searched point placements. No atomic macro, RL benefit, superiority, unrestrictedFOL/PA/Hilbert, '
                     'fixed literal Wang palette or novelty claim from orchestration.'}
