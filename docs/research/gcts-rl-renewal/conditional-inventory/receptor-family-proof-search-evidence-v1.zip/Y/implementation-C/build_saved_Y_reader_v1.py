"""Presentation only: stdlib reads of saved study002. No scientific imports/replay."""
from pathlib import Path
import collections
import gzip
import hashlib
import json

ROOT = Path('/private/tmp/gcts-receptor-family-generation-20261028-v1')
OWN = ROOT / 'implementation-C'
ACTUAL = ROOT / 'actual/study-002'
TEMPLATE = ROOT / 'root/receptor-family-reader-template-v1.html'
ADMISSION = ROOT / 'root/Root-study002-complete-scientific-admission-v1.json'


def raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def pin(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


used = {}


def artifact(ref):
    stored = ref['stored']
    path = Path(stored['path'])
    assert path.parent == ACTUAL
    body = path.read_bytes()
    assert len(body) == stored['bytes'] and hashlib.sha256(body).hexdigest() == stored['sha256']
    decoded = gzip.decompress(body) if ref['encoding'] == 'gzip-json' else body
    assert len(decoded) == ref['raw_bytes'] and hashlib.sha256(decoded).hexdigest() == ref['raw_sha256']
    value = json.loads(decoded)
    assert raw(value) == decoded
    used[path.name] = ref
    return value


def write(name, value):
    path = OWN / name
    assert not path.exists(), str(path)
    body = value.encode('utf-8') if isinstance(value, str) else raw(value)
    path.write_bytes(body)
    assert path.read_bytes() == body
    return pin(path)


worker_path = ACTUAL / 'worker-result.json.gz'
worker_bytes = gzip.decompress(worker_path.read_bytes())
worker = json.loads(worker_bytes)
assert worker['status'] == 'COMPLETE' and raw(worker) == worker_bytes
E = worker['experiment']
admission = json.loads(ADMISSION.read_bytes())
assert admission['status'].startswith('ADMITTED')
assert len(E['evaluation']) == 12 and len(E['training']) == 6 and len(E['preparations']) == 15
bank_record = artifact(E['bank_ref'])
bank = bank_record['result']['value']
patterns = artifact(E['patterns_ref'])['value']['patterns']
assert len(bank['lemmas']) == 4 and len(patterns) == 63
pattern_by_id = {p['id']: p for p in patterns}
preps = {p['id']: p for p in E['preparations']}


def cluster(full):
    result = full.get('result', {})
    guide = result.get('heuristic')
    if not guide or not full.get('summary'):
        return None
    selected = set(result.get('selected') or [])
    executed = guide['stats']['executed_packet_ids']
    bindings = full['summary']['packet_bindings']
    for event in guide['trace']['records']:
        packets = event['offered'] + ([event['carried']] if event['carried'] else [])
        for packet in packets:
            identity = packet['id']
            valid = [v for v in event['validations'] if v['packet_id'] == identity and v['status'] == 'VALID']
            if (identity == event['chosen_packet'] and valid and executed.get(identity, 0)
                    and set(packet['members']) <= selected and identity in bindings):
                binding = bindings[identity]
                return {'packet': packet, 'binding': binding,
                        'pattern': pattern_by_id[binding['pattern_id']],
                        'rows': sorted(int(s.split(':')[0][1:]) for s in packet['members']),
                        'preferred_placements': guide['stats']['preferred_placements'],
                        'packet_preferred_placements': executed[identity],
                        'forced_placements': result['stats']['forced_placements'],
                        'validation': valid,
                        'chosen_event': {k: event[k] for k in ('seq', 'cause', 'chosen_candidate', 'chosen_packet')},
                        'chosen_state_sha256': hashlib.sha256(raw(event['state'])).hexdigest(),
                        'guide_trace_extent': {k: v for k, v in guide['trace'].items() if k != 'records'},
                        'source': full.get('source_ref'),
                        'scope': 'Recorded validated chosen packet with completed preferred-placement credit; its members occur in the final selected proof. Counts include failed branches and do not assert that every final member was placed by this packet. Full actual trace remains in the source artifact.'}
    return None


positive_count = 0
actual_bindings = 0


def lane(summary):
    global positive_count, actual_bindings
    full = artifact(summary['ref']) if summary.get('ref') else summary
    result = full.get('result', {})
    guide = result.get('heuristic', {}).get('stats', {})
    out = {'status': full['status'], 'original_status': full['original_status'],
           'verified': full['verified'], 'seconds': full.get('search_seconds'),
           'reason': result.get('reason'), 'statistics': result.get('stats', result.get('costs')),
           'preferred_placements': guide.get('preferred_placements'),
           'preparation_ref': full['preparation_ref'], 'source_ref': summary.get('ref'),
           'selection': result.get('selected'), 'tiles': [],
           'coarse_proof': [], 'primitive_proof': [],
           'checkpoint_load_seconds': full['checkpoint_load_seconds'],
           'event_extent': result.get('event_extent'), 'state_hashes': result.get('state_hashes')}
    if not full['verified']:
        assert full['original_status'] != 'VERIFIED'
        return out
    positive = full['positive']
    assert positive['verified'] and positive['original_status'] == 'VERIFIED'
    assert positive['coarse_check']['status'] == positive['original_check']['status'] == 'VERIFIED'
    assert positive['lowering']['status'] == 'COMPLETE'
    assert positive['lowering_audit']['status'] == 'VERIFIED'
    coarse = positive['coarse_proof']
    primitive = positive['original_proof']
    lower = positive['lowering']['value']
    assert primitive == lower['proof']
    if 'selection_audit' in full:
        audit = full['selection_audit']
        assert audit['status'] == 'VERIFIED' and audit['proof'] == coarse == full['decoded']['proof']
        tiles = sorted(audit['details']['candidate_bindings'], key=lambda t: int(t['t'][0].split(':')[1]))
        assert len(tiles) == len(coarse) and {t['id'] for t in tiles} == set(result['selected'])
        for i, tile in enumerate(tiles):
            assert tile['t'] == ['slot:' + str(i)]
            assert json.loads(dict(tile['m'])['out:' + str(i)]) == coarse[i]['formula']
        out['tiles'] = tiles
        actual_bindings += len(tiles)
        out['tile_scope'] = 'ACTUAL_SELECTED_POINT_CANDIDATE_BINDINGS'
    else:
        assert full['status'] == 'DERIVABLE'
        out['tile_scope'] = 'CERTIFICATE_OVERLAY_NOT_POINT_PLACEMENTS'
    out.update(coarse_proof=coarse, primitive_proof=primitive,
               coarse_check=positive['coarse_check'], primitive_check=positive['original_check'],
               lowering={k: v for k, v in lower.items() if k not in ('proof', 'theory', 'goal')},
               lowering_audit=positive['lowering_audit'], positive_ref=positive.get('ref'))
    full['source_ref'] = summary.get('ref')
    out['cluster'] = cluster(full)
    positive_count += 1
    return out


def case_record(identity, original, lanes, preparation, training=False):
    return {'id': identity, 'problem': original, 'slots': preparation['slots'],
            'is_training': training,
            'lemma_bindings': preparation['application']['lemma_bindings'],
            'extended_theory': preparation['application']['theory'],
            'build_status': preparation['build_status'],
            'build_seconds': preparation['build_seconds'],
            'preparation_seconds': preparation['preparation_seconds'],
            'build_costs': preparation['build_costs'],
            'build_optimization': preparation['build_optimization'],
            'preparation_ref': preparation['preparation_ref'], 'build_ref': preparation['build_ref'],
            'lanes': lanes}


cases = [case_record(row['id'], row['original'], {k: lane(v) for k, v in row['lanes'].items()}, preps[row['id']])
         for row in E['evaluation']]
episodes, training_cases = [], []
for row in E['training']:
    a = row['attempt']; u = row['update']; value = u['value'] if u and u['status'] == 'COMPLETE' else None
    identity = 'training-' + str(row['episode']) + '-' + row['case_id']
    display_lane = lane(a)
    training_cases.append(case_record(identity, preps[row['case_id']]['original'],
                                     {'POINT_LEARNED_CLUSTERS': display_lane}, preps[row['case_id']], True))
    episodes.append({'id': identity, 'case_id': row['case_id'], 'episode': row['episode'],
                     'status': a['status'], 'original_status': a['original_status'],
                     'preferred_placements': a.get('guidance_statistics', {}).get('preferred_placements', 0),
                     'reward': value['episode']['reward'] if value else None,
                     'changed_estimates': value['changed_estimates'] if value else None,
                     'updates': value['episode']['updates'] if value else [],
                     'seconds': a.get('search_seconds'), 'update_scope': row['update_scope'],
                     'state_before': {k: row['state_before'][k] for k in ('values', 'counts')},
                     'state_after': {k: row['state_after'][k] for k in ('values', 'counts')},
                     'source_ref': row['ref']})

assert positive_count == 18 and actual_bindings == 72
counts = collections.Counter(v['status'] for c in cases for v in c['lanes'].values())
assert counts == {'SAT': 6, 'UNSAT': 3, 'UNKNOWN': 29, 'DERIVABLE': 6, 'NOT_DERIVABLE': 4}
credits = sum(sum(v.values()) for v in E['frozen_policy']['counts'].values())
assert credits == 17 and sum(len(v) for v in E['frozen_policy']['counts'].values()) == 4

lemmas = json.loads(raw(bank['lemmas']))
labels = {'arith-add-zero-at-successor-control': 'Addition at zero after a successor',
          'arith-right-one-control': 'Addition of one',
          'incidence-typing-specialized-line-control': 'Incidence typing at the named line',
          'incidence-distinct-lines-common-points-control': 'Common points on distinct lines'}
for lemma in lemmas:
    lemma['label'] = labels.get(lemma['representative_donor'], lemma['representative_donor'])

costs = dict(admission['costs_and_fairness']['component_sums_not_time_partition'])
failed_path = ROOT / 'actual/study-001/worker-result.json.gz'
failed_result = json.loads(gzip.decompress(failed_path.read_bytes()))
costs['failed001_experiment_seconds_unadmitted'] = failed_result['experiment']['seconds']
costs['failed001_timing_scope'] = 'Saved worker experiment field only; original CLI failed and no observer terminal exists. Not an admitted whole-lifetime wall or pooled outcome.'
data = {'schema': 'Y-saved-reader-data-v1',
        'findings': [
            'All 15 target catalogues and their complete independent audits finished. Raw build calls totaled %.3f seconds; preparation, including extension and independent catalogue/zero-schema checks, totaled %.3f seconds. These are different cost scopes.' % (costs['build_seconds_sum'], costs['15_preparation_seconds_sum']),
            'Seven distinct heldout assertions have checked original-theory proofs: two were proved by point search and six by the shared-DAG control, with one overlap. The capture-sensitive specialization is a point-search success; the control timed out on it.',
            'Each point strategy has 2 SAT, 1 finite-catalogue UNSAT and 9 UNKNOWN outcomes. The control has 6 DERIVABLE, 4 finite-catalogue NOT_DERIVABLE and 2 UNKNOWN outcomes. All 48 heldout positions and six individual training attempts remain visible.',
            'The four acquired lemmas generated 63 formula-erased inference shapes. Six successful training episodes produced 17 completed preferred-placement credits across four context/shape arms. The learned ranking changed choices, but added no solved heldout assertion.'
        ],
        'assessment': [
            'The new grammar makes catalogue construction tractable on all preserved assertions, under a changed finite language and some changed row bounds. It is not a lossless optimization or a direct speed comparison with X or W.',
            'GCTS produced actual selected tiles and checked proofs for nested typing and capture-sensitive incidence specialization. The five additional heldout composition goals were proved by the shared-DAG control, not by GCTS. Flat row/reference assignment remains the dominant search difficulty.',
            'Guidance reduces the recorded capture search tree, but its matching overhead makes lexical point search faster on that solved case. Uniform and trained capture trajectories are identical. Learned ranking adds a backtrack on nested typing compared with uniform ranking; there is no demonstrated learned heldout advantage.',
            'All six training episodes succeed. The values/counts truly update, but terminal rewards do not distinguish successful from unsuccessful patterns. Placement credit can include branches later rolled back. Long-search retained traces are prefixes, not full invented histories.',
            'Study001 failed a mandatory input postguard and remains permanently unadmitted. Its complete evidence and costs are retained separately in the archive; none of its outcomes are pooled here. The archive is a prepublication evidence cut; later publication and live-verification receipts cannot include themselves.'
        ],
        'inventory': {'lemmas': lemmas, 'patterns': patterns, 'bank_ref': E['bank_ref'], 'patterns_ref': E['patterns_ref']},
        'training': {'episodes': episodes, 'cases': training_cases, 'initial_policy': E['initial_policy'],
                     'frozen_policy': E['frozen_policy'], 'preferred_placement_credits': credits,
                     'distinct_context_arms': 4, 'scope': 'Six individual current-run episodes; values/counts, not neural weights. Heldout policy is frozen.'},
        'cases': cases,
        'provenance': {'science_admission': pin(ADMISSION), 'admission_status': admission['status'],
                       'worker': pin(worker_path), 'worker_raw_bytes': len(worker_bytes),
                       'worker_raw_sha256': hashlib.sha256(worker_bytes).hexdigest(),
                       'template': pin(TEMPLATE), 'design': E['design'], 'limits': E['limits'],
                       'cost_components_not_a_partition': costs, 'failed001': admission['failed001'],
                       'failed001_worker_cost_source': pin(failed_path),
                       'archive_cut': 'Prepublication full evidence; later publisher/TLS/browser receipts retained separately.',
                       'native_memo': {k: v for k, v in E['native_memo'].items() if k != 'requests'},
                       'qualification_ref': E['qualification_ref'], 'qualification': E['qualification'],
                       'scope': 'Saved study002 only. No project imports, scientific replay or proof synthesis. Root will integrate publication/archive metadata.'}}

# Own clarified sister fragment. The frozen Root template and argument remain untouched.
future = (ROOT / 'root/future-growing-proof-obligations-v1.html').read_text()
future = future.replace('Each site has a unique parent.', 'Every non-root site has a unique parent; the root has none and depth \\(0\\).')
future = future.replace('A zero-premise witness has no children;', 'Exclude a rule if any prescribed premise child lies outside \\(V_D\\); sites at depth \\(D\\) therefore admit only zero-premise rules. A zero-premise witness has no children;')
future = future.replace('Activate the root and every new point of positive support.', 'Begin with only the root active. Every selected placement must meet the active frontier; activate new sites exactly from its positive support. Unused sites of \\(V_D\\) are not required. Activation, generation and the complete frontier/candidate graph must roll back exactly.')
future = future.replace('A partial proof cluster would have full occupancy on completed interior sites and half occupancy at its root and unfinished receptors.', 'For a finite connected rooted rule patch, viewed without its incoming parent half or root seed, completed interior sites have full occupancy and the patch root and unfinished receptors have half occupancy. An arbitrary disconnected collection may have several boundary roots and does not have this single-root interface.')
future = future.replace('It covers the activated proof patch,', 'For an executable bounded model, declare a finite formula/rule-witness inventory; completeness is relative to that inventory and depth bound. It covers the activated proof patch,')
future_ref = write('future-growing-proof-obligations-v2.html', future)

template = TEMPLATE.read_text()
assert template.count('__RESEARCH_DATA__') == 1
template = template.replace('<th>Compile</th>', '<th>Preparation / raw build</th>')
template = template.replace("+secs(r.build_seconds)+'</td>'", "+secs(r.preparation_seconds)+' / '+secs(r.build_seconds)+'</td>'")
template = template.replace('Actual policy updates and final weights', 'Actual policy updates and final values/counts')
old_default = "const positive=[...D.cases,...D.training.cases].find(r=>Object.values(r.lanes).some(l=>l.primitive_proof?.length));"
new_default = "const positive=D.cases.find(r=>r.id==='heldout-incidence-capture-sensitive-specialization');"
assert old_default in template
template = template.replace(old_default, new_default)
template = template.replace('<footer>', future + '\n<footer>', 1)
template = template.replace("'Actual validated coarse cluster: '", "'Recorded validated coarse cluster: '")
template = template.replace('The strip shows recorded proposal members present in this final proof;', 'The strip shows recorded proposal members present in this final proof; membership alone does not mean every member was guided by that packet;')
data_ref = write('Y-reader-data-v1.json', data)
public = {'schema': 'Y-public-results-draft-v1', 'status': admission['status'],
          'reader': data, 'all_outcome_counts': dict(counts), 'all_positive_occurrences': positive_count,
          'actual_point_candidate_bindings': actual_bindings,
          'preparation_records': [{k: p[k] for k in ('id', 'status', 'slots', 'preparation_seconds', 'build_seconds', 'build_status', 'build_reason', 'build_costs', 'build_optimization', 'build_ref', 'preparation_ref')} for p in E['preparations']],
          'root_admission': pin(ADMISSION), 'artifact_readbacks': list(used.values()),
          'future_fragment': future_ref, 'scope': 'Reader projection only; all complete original artifacts remain in the approved full archive. Root publication/archive integration pending.'}
results_ref = write('Y-public-results-draft-v1.json', public)
html = template.replace('__RESEARCH_DATA__', raw(data).decode().replace('<', '\\u003c'))
html_ref = write('Y-reader-generated-v1.html', html)
assert html_ref['bytes'] <= 1048576 and results_ref['bytes'] <= 8388608
faithful = {'schema': 'Y-reader-faithful-field-report-v1', 'status': 'SAVED_DATA_PRESENTATION_COMPLETE_READY_FOR_INDEPENDENT_CONTENT_REVIEW',
            'outputs': [data_ref, results_ref, html_ref, future_ref],
            'builder': pin(Path(__file__)), 'template_unchanged': pin(TEMPLATE), 'science_admission': pin(ADMISSION),
            'coverage': {'heldout_cases': 12, 'heldout_lanes': 48, 'individual_training_episodes': 6,
                         'verified_positive_occurrences': positive_count, 'coarse_and_original_proof_pairs': 18,
                         'actual_point_candidate_bindings': actual_bindings, 'bank': 4, 'patterns': 63,
                         'credits': credits, 'populated_context_arms': 4},
            'joins': 'Every consumed artifact full stored/raw extent/SHA/canonicalJSON readback. Positive proof/decode/selected binding and lower checks joined as data; no new logical validation or replay. No proof displayed for unverified result. Actual point tiles from saved L candidate_bindings; control/primitive rows explicitly certificate overlays.',
            'presentation_changes': ['Preparation and raw build times separated', 'Policy values/counts label', 'Default capture-sensitive actual GCTS uniform point view', 'Clarified unimplemented future fragment depth/frontier/connected-rooted premises', 'Cluster final-membership is distinguished from causal execution'],
            'scientific_project_calls': 0, 'network_calls': 0}
report_ref = write('Y-reader-faithful-field-report-v1.json', faithful)
print(json.dumps({'outputs': faithful['outputs'], 'faithful_report': report_ref}, sort_keys=True))
