"""Independent Y finite goal/receptor catalogue, row certificates and DAG control.

No IO or project imports. Injected producers/checkers are called only inside
qualify/verify_zero_schemas by a separately authorized future owned caller.
"""
import collections
import hashlib
import itertools
import json
import math
import time

VERSION = 'Y-INDEPENDENT-RECEPTOR-CATALOGUE-AUDIT-v1'
VERIFY_LIMITS = dict(wall_seconds=30, max_work=1000000000, max_depth=128, max_candidates=100000)
SEARCH_LIMITS = dict(wall_seconds=2, max_states=20000, max_transitions=500000, max_work=1000000000)
BUILD_LIMITS = dict(wall_seconds=5,max_work=100000000,max_basis=10000,max_instances=10000,max_depth=128,max_cache_entries=100000,max_interned=100000)
ENGINE_LIMITS = dict(wall_seconds=2,max_nodes=50000,max_operations=20000000,max_definitions=10000,max_virtual_members=100000,max_events=100000)
CHECKER_LIMITS = dict(max_proof_lines=10000,max_operations=100000000,max_depth=128)
PRODUCT_CAP = 20000
SCOPE = ('Independent literal reconstruction of the declared Y goal-dependent finite language, '
         'complete virtual row/ref/mark bindings, and bounded shared-fact DAG DFS. '
         'New universe, no W-equivalence or unrestricted negative. Selected/control proofs '
         'require actual native C1 plus independent B; all-zero host batches are separate. '
         'Exactly n coarse rows versus at-most n shared facts; padding is a derived certificate, '
         'not an observed point search or equality of primitive expansion bounds.')
ZERO_FIELDS = {
    'axiom': {'rule','formula','name'}, 'tautology': {'rule','formula'},
    'refl': {'rule','formula'}, 'instantiate': {'rule','formula','universal','term'},
    'distribute': {'rule','formula','variable','antecedent','consequent'},
    'eq_subst': {'rule','formula','variable','template','left','right'},
}

class InputError(ValueError):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise InputError(message)


class _Meter:
    def __init__(self, limits, defaults):
        self.start = time.perf_counter()
        limits = dict(defaults) if limits is None else limits
        _fields(limits, set(defaults))
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60
              and math.isfinite(wall), 'wall limit')
        _need(all(type(v) is int and 0 <= v <= 1000000000000
                  for k, v in limits.items() if k != 'wall_seconds'),
              'integer limits')
        self.limits = dict(limits)
        self.work = 0

    def tick(self, n=1):
        if n > self.limits['max_work'] - self.work:
            raise BudgetExceeded('WORK')
        self.work += n
        if time.perf_counter() - self.start > self.limits['wall_seconds']:
            raise BudgetExceeded('WALL')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Own input copy, validation, indexing, search and proof/detached-return construction included. Caller JSON serialization tail excluded. Cooperative, not an OS quota.'}


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys)
          and all(type(k) is str for k in x) and set(x) == set(keys),
          'record fields')


def _copy(x,m,depth=0):
    m.tick()
    if depth>m.limits.get('max_depth',128):raise BudgetExceeded('DEPTH')
    if x is None or type(x)is bool:return x
    if type(x)is int:
        m.tick(x.bit_length()+1);return x
    if type(x)is float:
        _need(math.isfinite(x),'finite JSON');return x
    if type(x)is str:m.tick(len(x));return x
    if type(x)is list:
        m.tick(len(x));return [_copy(y,m,depth+1) for y in x]
    _need(type(x)is dict,'native JSON');m.tick(len(x))
    _need(all(type(k)is str for k in x),'native JSON keys')
    for k in x:m.tick(len(k))
    return {k:_copy(v,m,depth+1) for k,v in x.items()}


def _bound(x,m,depth=0):
    m.tick()
    if depth>m.limits.get('max_depth',128):raise BudgetExceeded('DEPTH')
    if x is None or type(x)is bool:width=5
    elif type(x)is int:width=max(3,x.bit_length()+2)
    elif type(x)is float:_need(math.isfinite(x),'finite JSON');width=128
    elif type(x)is str:width=2+12*len(x)
    elif type(x)is list:
        m.tick(len(x));width=2+len(x)+sum(_bound(v,m,depth+1) for v in x)
    else:
        _need(type(x)is dict,'native JSON');m.tick(len(x));width=2+2*len(x)
        for key,value in x.items():
            _need(type(key)is str,'JSON key');width+=_bound(key,m,depth+1)+_bound(value,m,depth+1)
    m.tick(width if type(x)not in (list,dict) else 2+2*len(x))
    return width


def _key(x,m):
    upper=_bound(x,m);m.tick(upper)
    try:text=json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
    except (ValueError,OverflowError) as error:raise BudgetExceeded('SERIALIZATION_LIMIT') from error
    _need(len(text)<=upper,'canonical width invariant');return text


def _same(a,b,m):
    pending=[(a,b)]
    while pending:
        m.tick();x,y=pending.pop()
        if type(x)is not type(y):return False
        if type(x)is dict:
            if len(x)!=len(y):return False
            m.tick(2*len(x))
            if set(x)!=set(y):return False
            pending.extend((v,y[k]) for k,v in x.items())
        elif type(x)is list:
            if len(x)!=len(y):return False
            m.tick(len(x));pending.extend(zip(x,y))
        else:
            if type(x)is str:m.tick(len(x)+len(y))
            if x!=y:return False
    return True


def _name(s):
    return type(s)is str and 1<=len(s)<=64 and all(32<=ord(c)<=126 for c in s)


def _slots(slots):
    _need(type(slots)is int and 1<=slots<=64,'slots')



# Independent literal-AST reconstruction of the declared Y finite language.
def _term(t, theory, m, terms=None, names=None, depth=0):
    m.tick()
    if depth>m.limits.get('max_depth',128):raise BudgetExceeded('DEPTH')
    _need(type(t)is list and 1<=len(t)<=3 and type(t[0])is str,'term')
    if t[0]=='var':
        _need(len(t)==2 and _name(t[1]),'variable')
        if names is not None:names.add(t[1])
        free={t[1]}
    else:
        _need(t[0]=='fun' and len(t)==3 and _name(t[1]) and type(t[2])is list,'function term')
        _need(t[1]in theory['functions'] and theory['functions'][t[1]]==len(t[2]),'function arity')
        m.tick(len(t[2]));free=set()
        for child in t[2]:free.update(_term(child,theory,m,terms,names,depth+1))
    if terms is not None:terms[_key(t,m)]=_copy(t,m)
    return free


def _formula(f,theory,m,forms=None,terms=None,names=None,depth=0):
    m.tick()
    if depth>m.limits.get('max_depth',128):raise BudgetExceeded('DEPTH')
    _need(type(f)is list and 1<=len(f)<=3 and type(f[0])is str,'formula')
    tag=f[0]
    if tag=='bot':_need(len(f)==1,'bot');free=set()
    elif tag=='eq':
        _need(len(f)==3,'eq');free=_term(f[1],theory,m,terms,names,depth+1)|_term(f[2],theory,m,terms,names,depth+1)
    elif tag=='pred':
        _need(len(f)==3 and _name(f[1]) and type(f[2])is list,'predicate')
        _need(f[1]in theory['predicates'] and theory['predicates'][f[1]]==len(f[2]),'predicate arity')
        m.tick(len(f[2]));free=set()
        for child in f[2]:free.update(_term(child,theory,m,terms,names,depth+1))
    elif tag=='all':
        _need(len(f)==3 and _name(f[1]),'binder')
        if names is not None:names.add(f[1])
        free=_formula(f[2],theory,m,forms,terms,names,depth+1)-{f[1]}
    elif tag=='not':
        _need(len(f)==2,'not');free=_formula(f[1],theory,m,forms,terms,names,depth+1)
    else:
        _need(tag in ('and','or','imp') and len(f)==3,'binary formula')
        free=_formula(f[1],theory,m,forms,terms,names,depth+1)|_formula(f[2],theory,m,forms,terms,names,depth+1)
    if forms is not None:forms[_key(f,m)]=_copy(f,m)
    return free


def _problem(problem,m):
    _fields(problem,{'theory','goal','profile'})
    p=_copy(problem,m);t=p['theory'];_fields(t,{'functions','predicates','axioms'})
    for space in ('functions','predicates'):
        _need(type(t[space])is dict,'signature');m.tick(len(t[space]))
        for name,arity in t[space].items():_need(_name(name) and type(arity)is int and arity>=0,'signature item')
    _need(type(t['axioms'])is dict,'axioms');m.tick(len(t['axioms']))
    forms,terms,names={},{},set()
    for name,f in t['axioms'].items():
        _need(_name(name),'axiom name');_need(not _formula(f,t,m,forms,terms,names),'closed theory')
    _formula(p['goal'],t,m,forms,terms,names)  # Open goals allowed by actual public language.
    _fields(p['profile'],{'ui_rounds','bridge_arity','max_tautology_atoms'})
    for key,cap in (('ui_rounds',8),('bridge_arity',2),('max_tautology_atoms',16)):
        _need(type(p['profile'][key])is int and 0<=p['profile'][key]<=cap,'profile')
    for name in names:
        value=['var',name];terms[_key(value,m)]=value
    return p,forms,terms,names


def _fv_term(t,m):
    m.tick()
    if t[0]=='var':return {t[1]}
    result=set()
    for child in t[2]:result.update(_fv_term(child,m))
    return result


def _fv(f,m):
    m.tick();tag=f[0]
    if tag=='eq':return _fv_term(f[1],m)|_fv_term(f[2],m)
    if tag=='pred':
        result=set()
        for t in f[2]:result.update(_fv_term(t,m))
        return result
    if tag=='all':return _fv(f[2],m)-{f[1]}
    if tag=='not':return _fv(f[1],m)
    if tag in ('and','or','imp'):return _fv(f[1],m)|_fv(f[2],m)
    return set()


def _names(f,m):
    result=set();pending=[f]
    while pending:
        m.tick();x=pending.pop()
        if type(x)is not list or not x:continue
        if x[0]=='var':result.add(x[1])
        elif x[0]=='all':result.add(x[1]);pending.append(x[2])
        elif x[0]in ('fun','pred'):m.tick(len(x[2]));pending.extend(x[2])
        else:m.tick(len(x)-1);pending.extend(x[1:])
    return result


def _sterm(t,var,replacement,m):
    m.tick()
    if t[0]=='var':return _copy(replacement if t[1]==var else t,m)
    m.tick(len(t[2]));return ['fun',t[1],[_sterm(x,var,replacement,m) for x in t[2]]]


def _rename(f,var,new,m):
    m.tick();tag=f[0]
    if tag=='eq':return ['eq',_sterm(f[1],var,['var',new],m),_sterm(f[2],var,['var',new],m)]
    if tag=='pred':return ['pred',f[1],[_sterm(t,var,['var',new],m) for t in f[2]]]
    if tag=='all':return _copy(f,m) if f[1]==var else ['all',f[1],_rename(f[2],var,new,m)]
    if tag=='not':return ['not',_rename(f[1],var,new,m)]
    if tag in ('and','or','imp'):return [tag,_rename(f[1],var,new,m),_rename(f[2],var,new,m)]
    return ['bot']


def _subst(f,var,replacement,m):
    m.tick();tag=f[0]
    if var not in _fv(f,m):return _copy(f,m)
    if tag=='eq':return ['eq',_sterm(f[1],var,replacement,m),_sterm(f[2],var,replacement,m)]
    if tag=='pred':return ['pred',f[1],[_sterm(t,var,replacement,m) for t in f[2]]]
    if tag=='all':
        bound,body=f[1],f[2]
        if bound==var:return _copy(f,m)
        if bound in _fv_term(replacement,m):
            forbidden=_names(body,m)|_fv_term(replacement,m)|{var,bound};i=0
            while 'fresh'+str(i)in forbidden:m.tick();i+=1
            fresh='fresh'+str(i);body=_rename(body,bound,fresh,m);bound=fresh
        return ['all',bound,_subst(body,var,replacement,m)]
    if tag=='not':return ['not',_subst(f[1],var,replacement,m)]
    return [tag,_subst(f[1],var,replacement,m),_subst(f[2],var,replacement,m)]


def _closure(value,dest,m):
    pending=[value]
    while pending:
        m.tick();f=pending.pop();key=_key(f,m)
        if key in dest:continue
        if len(dest)>=m.limits.get('max_candidates',100000):raise BudgetExceeded('FORMULAS')
        dest[key]=_copy(f,m)
        children=[f[2]] if f[0]=='all' else [f[1]] if f[0]=='not' else f[1:] if f[0]in ('and','or','imp') else []
        m.tick(len(children));pending.extend(children)


def _term_paths(t,m):
    m.tick();yield ()
    if t[0]=='fun':
        for i,child in enumerate(t[2]):
            for tail in _term_paths(child,m):yield (2,i)+tail


def _templates(atom,hole,m):
    roots=[(1,),(2,)] if atom[0]=='eq' else [(2,i) for i in range(len(atom[2]))]
    for root in roots:
        term=atom
        for index in root:term=term[index]
        for path in _term_paths(term,m):
            out=_copy(atom,m);target=out;indices=root+path
            for index in indices[:-1]:target=target[index]
            target[indices[-1]]=['var',hole];yield out


def _atoms(f,m):
    out={};pending=[f]
    while pending:
        m.tick();x=pending.pop()
        if x[0]=='bot':continue
        if x[0]=='not':pending.append(x[1])
        elif x[0]in ('and','or','imp'):pending.extend(x[1:])
        else:out[_key(x,m)]=x
    return out


def _vectors(target,premises,m):
    atomkeys=sorted(_atoms(target,m));n=len(atomkeys)
    _need(n<=16,'truth universe');assignments=1<<n
    m.tick(assignments*(n+1));mask=(1<<assignments)-1
    atomvalues={key:(mask//((1<<(1<<i))+1))<<(1<<i) for i,key in enumerate(atomkeys)}
    cache={}
    def value(f):
        m.tick();key=_key(f,m)
        if key in cache:return cache[key]
        tag=f[0]
        if tag=='bot':answer=0
        elif tag=='not':answer=mask^value(f[1])
        elif tag=='and':answer=value(f[1])&value(f[2])
        elif tag=='or':answer=value(f[1])|value(f[2])
        elif tag=='imp':answer=(mask^value(f[1]))|value(f[2])
        else:answer=atomvalues[key]
        cache[key]=answer;return answer
    return mask,value(target),{key:value(f) for key,f in premises.items()}


def _ordered(values,m):
    m.tick(len(values)*max(1,len(values).bit_length())+len(values));return sorted(values)


def _regenerate(problem,m):
    p,C,T,_=_problem(problem,m);m.tick(2*len(C));C0=dict(C);F=dict(C);Z={};stages=[];core_stages=[]
    def zero(line):
        key=_key(line,m)
        if key not in Z:
            if len(Z)>=m.limits.get('max_candidates',100000):raise BudgetExceeded('INSTANCES')
            m.tick();Z[key]=_copy(line,m);_closure(line['formula'],F,m)
    def stage(label):
        m.tick();stages.append({'stage':label,'formula_count':len(F),'core_count':len(C),'instance_count':len(Z)})
    for name in _ordered(p['theory']['axioms'],m):zero({'rule':'axiom','name':name,'formula':p['theory']['axioms'][name]})
    stage('INPUT');core_stages.append(('INPUT',tuple(_ordered(C,m))))
    for r in range(p['profile']['ui_rounds']):
        m.tick(len(C)*max(1,len(C).bit_length()));snapshot=[C[key] for key in _ordered(C,m)]
        for universal in snapshot:
            if universal[0]!='all':continue
            for key in _ordered(T,m):
                m.tick();term=T[key];instance=_subst(universal[2],universal[1],term,m)
                zero({'rule':'instantiate','formula':['imp',universal,instance],'universal':universal,'term':term})
                _closure(instance,C,m);_closure(instance,F,m)
        label='UI'+str(r+1);stage(label);core_stages.append((label,tuple(_ordered(C,m))))
    G0={};_closure(p['goal'],G0,m);m.tick(len(G0));G=dict(G0)
    for key in _ordered(G0,m):
        f=G0[key]
        if f[0]!='imp':continue
        pending=[f[2]]
        while pending:
            m.tick();child=pending.pop();new=['imp',f[1],child];G[_key(new,m)]=new
            if child[0]=='not':pending.append(child[1])
            elif child[0]in ('and','or','imp'):pending.extend(child[1:])
    for f in G.values():_closure(f,F,m)
    names=set()
    for f in C.values():names.update(_names(f,m))
    i=0
    while '__y_hole'+str(i)in names:m.tick();i+=1
    hole='__y_hole'+str(i);templates={}
    for atom in C0.values():
        if atom[0]in ('eq','pred'):
            for template in _templates(atom,hole,m):templates[_key(template,m)]=template
    for key in _ordered(T,m):zero({'rule':'refl','formula':['eq',T[key],T[key]]})
    m.tick(len(C)*max(1,len(C).bit_length()));equations=[C[key] for key in _ordered(C,m) if C[key][0]=='eq']
    for key in _ordered(templates,m):
        template=templates[key]
        for eq in equations:
            left=_subst(template,hole,eq[1],m);right=_subst(template,hole,eq[2],m)
            if _key(left,m)in C and _key(right,m)in C:
                zero({'rule':'eq_subst','formula':['imp',eq,['imp',left,right]],'variable':hole,'template':template,'left':eq[1],'right':eq[2]})
    stage('EQUALITY')
    for f in C.values():
        if f[0]=='all' and f[2][0]=='imp':
            var=f[1];a,b=f[2][1:]
            if var not in _fv(a,m):zero({'rule':'distribute','formula':['imp',f,['imp',a,['all',var,b]]],'variable':var,'antecedent':a,'consequent':b})
    stage('DISTRIBUTION');m.tick(len(C)+len(G));merged=dict(C);merged.update(G)
    P={key:f for key,f in merged.items() if f[0]!='all'}
    for key in _ordered(G,m):
        target=G[key];atoms=set(_atoms(target,m))
        if len(atoms)>p['profile']['max_tautology_atoms']:continue
        eligible={k:P[k] for k in _ordered(P,m) if set(_atoms(P[k],m)).issubset(atoms)}
        mask,wanted,vectors=_vectors(target,eligible,m);keys=tuple(eligible);m.tick(len(keys))
        for arity in range(p['profile']['bridge_arity']+1):
            for chosen in itertools.combinations_with_replacement(keys,arity):
                m.tick();support=mask
                for premise in chosen:support&=vectors[premise]
                if support&(mask^wanted):continue
                result=_copy(target,m)
                for premise in reversed(chosen):result=['imp',_copy(P[premise],m),result]
                zero({'rule':'tautology','formula':result})
    stage('PROPOSITIONAL');stage('EXPORT')
    colors=_ordered(F,m);index={key:i for i,key in enumerate(colors)}
    m.tick(len(F)+len(Z)*max(1,len(Z).bit_length()));forms=[F[key] for key in colors];lines=[Z[key] for key in _ordered(Z,m)]
    zero_rows=[{'id':'i'+str(i),'rule':line['rule'],'formula_id':index[_key(line['formula'],m)],'line':line} for i,line in enumerate(lines)]
    mp=[];gen=[]
    for i,f in enumerate(forms):
        m.tick()
        if f[0]=='imp':mp.append([i,index[_key(f[1],m)],index[_key(f[2],m)]])
        if f[0]=='all':gen.append([i,index[_key(f[2],m)],f[1]])
    m.tick(2*len(T)+len(names)+len(templates)+len(C)+len(G)+len(P)+sum(len(keys) for label,keys in core_stages))
    basis={'instantiation_terms':[T[key] for key in _ordered(T,m)],'terms':[T[key] for key in _ordered(T,m)],'variables':_ordered(names,m),'formulas':forms,'colors':colors,'templates':[templates[key] for key in _ordered(templates,m)],'hole':hole,'stages':stages}
    generation={'core_stages':[{'stage':label,'formula_ids':_ordered([index[key] for key in keys],m)} for label,keys in core_stages],
                'core_assertions':_ordered([index[key] for key in C],m),'goal_receptors':_ordered([index[key] for key in G],m),'bridge_premises':_ordered([index[key] for key in P],m)}
    return {'problem':p,'basis':basis,'zero':zero_rows,'mp':mp,'gen':gen,'goal':index[_key(p['goal'],m)],'generation':generation}

def _prepare(problem,compiled,m):
    p,_,_,_=_problem(problem,m)
    _fields(compiled,{'schema','version','theory','goal','goal_id','profile','logical_basis','zero_instances','mp_index','gen_index','costs','scope'})
    c=_copy(compiled,m)
    _need(c['schema']=='V-interned-Hilbert8-basis-v1' and c['version']=='V-INTERNED-FINITE-HILBERT8-v1','structural carrier identity')
    for key in ('theory','goal','profile'):_need(_same(p[key],c[key],m),'problem binding')
    b=c['logical_basis'];_fields(b,{'instantiation_terms','terms','variables','formulas','colors','templates','hole','stages'})
    for key in ('instantiation_terms','terms','formulas','templates'):
        _need(type(b[key])is list,'basis list');m.tick(len(b[key]))
        if len(b[key])>m.limits.get('max_candidates',100000):raise BudgetExceeded('BASIS')
        images=[_key(x,m) for x in b[key]];m.tick(len(images)*max(1,len(images).bit_length()))
        _need(images==sorted(set(images)),'canonical basis list')
    for term in b['terms']:_term(term,p['theory'],m)
    for term in b['instantiation_terms']:_term(term,p['theory'],m)
    for f in b['formulas']:_formula(f,p['theory'],m)
    # Template hole is intentionally not in the declared signature: it is a variable.
    for f in b['templates']:_formula(f,p['theory'],m)
    forms=b['formulas'];colors=[_key(f,m) for f in forms];m.tick(len(colors))
    _need(_same(colors,b['colors'],m),'full literal colors');index={v:i for i,v in enumerate(colors)}
    goal=_key(p['goal'],m);_need(goal in index and type(c['goal_id'])is int and c['goal_id']==index[goal],'goal ID')
    _need(type(b['variables'])is list,'variables');m.tick(len(b['variables']))
    _need(all(_name(v) for v in b['variables']) and b['variables']==sorted(set(b['variables'])),'variables order')
    _need(_name(b['hole']) and b['hole'].startswith('__y_hole'),'Y template hole')
    zero=c['zero_instances'];_need(type(zero)is list,'zero list');m.tick(len(zero))
    if len(zero)>m.limits.get('max_candidates',100000):raise BudgetExceeded('INSTANCES')
    byid={};previous=None
    for i,row in enumerate(zero):
        m.tick();_fields(row,{'id','rule','formula_id','line'})
        _need(type(row['id'])is str and row['id']=='i'+str(i) and type(row['rule'])is str and row['rule']in ZERO_FIELDS,'zero ID/rule')
        line=row['line'];_fields(line,ZERO_FIELDS[row['rule']]);_need(line['rule']==row['rule'],'line rule')
        _formula(line['formula'],p['theory'],m)
        image=_key(line,m);_need(previous is None or previous<image,'canonical full-payload zero order');previous=image
        color=_key(line['formula'],m)
        _need(color in index and type(row['formula_id'])is int and row['formula_id']==index[color],'zero formula binding')
        if row['rule']=='axiom':
            _need(type(line['name'])is str and line['name']in p['theory']['axioms'] and _same(line['formula'],p['theory']['axioms'][line['name']],m),'actual supplied axiom')
        byid[row['id']]=row
    labels=['INPUT']+['UI'+str(i+1) for i in range(p['profile']['ui_rounds'])]+['EQUALITY','DISTRIBUTION','PROPOSITIONAL','EXPORT']
    _need(type(b['stages'])is list and len(b['stages'])==len(labels),'stage list');oldf=oldi=oldc=0
    for label,row in zip(labels,b['stages']):
        _fields(row,{'stage','formula_count','core_count','instance_count'})
        _need(row['stage']==label and all(type(row[k])is int for k in ('formula_count','core_count','instance_count')) and oldf<=row['formula_count']<=len(forms) and oldi<=row['instance_count']<=len(zero) and oldc<=row['core_count']<=len(forms),'stage counters')
        oldf,oldi,oldc=row['formula_count'],row['instance_count'],row['core_count']
    _need(oldf==len(forms) and oldi==len(zero),'complete export stage')
    mp=[];gen=[]
    for fi,f in enumerate(forms):
        m.tick()
        if f[0]=='imp':
            a,bkey=_key(f[1],m),_key(f[2],m);_need(a in index and bkey in index,'full subformula closure');mp.append([fi,index[a],index[bkey]])
        if f[0]=='all':
            body=_key(f[2],m);_need(body in index,'full body closure');gen.append([fi,index[body],f[1]])
    _need(_same(c['mp_index'],mp,m) and _same(c['gen_index'],gen,m),'complete MP/GEN indices')
    _fields(c['costs'],{'work','seconds','terms','formulas','instances','candidates','cache_hits','cache_misses','canonical_serializations','substitution_calls'})
    for key,v in c['costs'].items():
        _need(type(v)in (int,float) and math.isfinite(v) and v>=0 if key=='seconds' else type(v)is int and v>=0,'cost types')
    _need(c['costs']['formulas']==len(forms) and c['costs']['instances']==len(zero) and c['costs']['candidates']==0,'complete cost census')
    return {'problem':p,'compiled':c,'forms':forms,'colors':colors,'goal':c['goal_id'],'zero':byid,'mp':{r[0]:r for r in mp},'gen':{r[0]:r for r in gen}}


def _receipt(status,reason,proof,details,m):
    return {'schema':'Y-independent-receptor-audit-result-v1','version':VERSION,'status':status,'reason':reason,'proof':proof,'details':details,'costs':m.costs(),'scope':SCOPE}


def verify_compiled(problem,compiled,generation,*,limits=None):
    m=_Meter(limits,VERIFY_LIMITS)
    try:
        data=_prepare(problem,compiled,m);expected=_regenerate(problem,m);c=data['compiled']
        for key,value in [('logical_basis',expected['basis']),('zero_instances',expected['zero']),('mp_index',expected['mp']),('gen_index',expected['gen']),('goal_id',expected['goal'])]:
            _need(_same(c[key],value,m),'independent complete Y generation: '+key)
        _fields(generation,{'schema','version','profile','compiled_core_sha256','core_stages','core_assertions','goal_receptors','bridge_premises','scope'})
        _need(generation['schema']=='Y-goal-receptor-universe-v1' and generation['version']=='Y-GOAL-RECEPTOR-FAMILY-v1' and _same(generation['profile'],data['problem']['profile'],m),'generation identity/profile')
        for key,value in expected['generation'].items():_need(_same(generation[key],value,m),'generation '+key)
        m.tick(len(c));semantic={k:v for k,v in c.items() if k not in ('costs','scope')}
        core_sha=_sha(semantic,m);_need(type(generation['compiled_core_sha256'])is str and generation['compiled_core_sha256']==core_sha,'semantic core SHA')
        m.tick();return _receipt('VERIFIED',None,None,{'formulas':len(data['forms']),'zero_instances':len(data['zero']),'mp_producers':len(data['mp']),'gen_producers':len(data['gen']),'compiled_core_sha256':core_sha,'logical_generation':'INDEPENDENT_COMPLETE_LITERAL_Y_RECONSTRUCTION'},m)
    except InputError as error:return _receipt('REJECTED',str(error),None,None,m)
    except BudgetExceeded as error:return _receipt('UNKNOWN',str(error),None,None,m)


def verify_zero_schemas(problem,compiled,logical_check,checker_limits,*,limits=None):
    m=_Meter(limits,VERIFY_LIMITS)
    try:
        data=_prepare(problem,compiled,m)
        _fields(checker_limits,{'max_proof_lines','max_operations','max_depth'})
        _need(all(type(v)is int and v>=0 for v in checker_limits.values()),'checker limits')
        if not data['zero']:
            return _receipt('VERIFIED',None,None,{'checker_calls':0,'lines':0,'checker':None,'scope':'Empty zero set, vacuous per-schema audit; not an empty native proof.'},m)
        m.tick(len(data['zero']));lines=[_copy(r['line'],m) for r in data['compiled']['zero_instances']]
        target=_copy(lines[-1]['formula'],m);theory=_copy(data['problem']['theory'],m);climits=_copy(checker_limits,m)
        receipt=logical_check(theory,lines,target,climits)
        _need(type(receipt)is dict and type(receipt.get('status'))is str,'checker receipt')
        status=receipt['status'];_need(status in ('VERIFIED','REJECTED','UNKNOWN_BUDGET'),'checker status')
        result='VERIFIED' if status=='VERIFIED' else 'UNKNOWN' if status=='UNKNOWN_BUDGET' else 'REJECTED'
        m.tick();return _receipt(result,None if result=='VERIFIED' else 'HOST_SCHEMA_'+status,None,{'checker_calls':1,'lines':len(lines),'proof_sha256':_sha(lines,m),'target':target,'checker':_copy(receipt,m),'checker_limits':climits,'scope':'Every actual zero full payload checked in one host B8 batch; no C1 batch, selected whole proofs checked separately.'},m)
    except InputError as error:return _receipt('REJECTED',str(error),None,None,m)
    except BudgetExceeded as error:return _receipt('UNKNOWN',str(error),None,None,m)


def _wire(value,m):
    text=_key(value,m);m.tick(len(text)+1);return (text+'\n').encode('ascii')


def _sha(value,m):
    return hashlib.sha256(_wire(value,m)).hexdigest()



def _nat(text):
    _need(type(text) is str and len(text) > 0 and len(text) <= 20
          and text.isascii() and text.isdigit()
          and (len(text) == 1 or text[0] != '0'), 'canonical index')
    return int(text)


def _virtual(cid, slots, data, m):
    m.tick()
    _need(type(cid) is str and len(cid) <= 128, 'candidate ID')
    fields = cid.split(':')
    _need(len(fields) >= 2 and fields[0].startswith('r'), 'candidate ID shape')
    slot = _nat(fields[0][1:])
    _need(slot < slots, 'candidate row')
    marks = {}
    if len(fields) == 2:
        _need(fields[1] in data['zero'], 'zero witness ID')
        record = data['zero'][fields[1]]
        output = record['formula_id']
        line = record['line']
        instance = record['id']
        canonical = 'r' + str(slot) + ':' + instance
    elif len(fields) == 5 and fields[1] == 'mp':
        fi, a, b = (_nat(s) for s in fields[2:])
        _need(fi in data['mp'] and a < slot and b < slot, 'MP prior refs')
        _, antecedent, output = data['mp'][fi]
        for point, value in [(a, antecedent), (b, fi)]:
            _need(point not in marks or marks[point] == value,
                  'internal coincident receptor conflict')
            marks[point] = value
        line = {'rule': 'mp', 'formula': data['forms'][output],
                'antecedent': a, 'implication': b}
        instance = None
        canonical = 'r%d:mp:%d:%d:%d' % (slot, fi, a, b)
    elif len(fields) == 4 and fields[1] == 'gen':
        fi, source = (_nat(s) for s in fields[2:])
        _need(fi in data['gen'] and source < slot, 'GEN prior ref')
        _, body, variable = data['gen'][fi]
        output = fi
        marks[source] = body
        line = {'rule': 'generalize', 'formula': data['forms'][fi],
                'source': source, 'variable': variable}
        instance = None
        canonical = 'r%d:gen:%d:%d' % (slot, fi, source)
    else:
        raise InputError('candidate ID family')
    _need(cid == canonical, 'canonical candidate ID')
    marks[slot] = output
    _need(slot != slots - 1 or output == data['goal'], 'last target filter')
    binding = {'id': cid, 't': ['slot:' + str(slot)],
               'm': [['out:' + str(point), data['colors'][value]]
                     for point, value in sorted(marks.items(),
                         key=lambda pair: 'out:' + str(pair[0]))]}
    return slot, marks, line, instance, binding


def _selection(data, slots, selected, m):
    _slots(slots)
    _need(type(selected) is list and len(selected) == slots
          and all(type(cid) is str for cid in selected)
          and len(set(selected)) == slots, 'selected exact coverage shape')
    rows = {}
    assigned = {}
    bindings = []
    for cid in selected:
        slot, marks, line, instance, binding = _virtual(cid, slots, data, m)
        _need(slot not in rows, 'duplicate occupied row')
        rows[slot] = (line, instance)
        for point, value in marks.items():
            m.tick()
            _need(point not in assigned or assigned[point] == value,
                  'whole selected marking conflict')
            assigned[point] = value
        bindings.append(binding)
    _need(set(rows) == set(range(slots)), 'all row roots covered')
    proof = []
    for slot in range(slots):
        m.tick()
        line = rows[slot][0]
        if line['rule'] == 'mp':
            a, b = line['antecedent'], line['implication']
            implication = proof[b]['formula']
            _need(type(implication) is list and len(implication) == 3
                  and implication[0] == 'imp'
                  and _same(implication[1], proof[a]['formula'], m)
                  and _same(implication[2], line['formula'], m), 'actual MP')
        elif line['rule'] == 'generalize':
            _need(_same(line['formula'], ['all', line['variable'],
                       proof[line['source']]['formula']], m), 'actual GEN')
        proof.append(_copy(line, m))
    _need(_same(proof[-1]['formula'], data['problem']['goal'], m), 'final goal')
    return proof, sorted(bindings, key=lambda row: row['id'])


def verify_selection(problem, compiled, slots, selected, *, limits=None):
    m = _Meter(limits, VERIFY_LIMITS)
    try:
        _slots(slots)
        data = _prepare(problem, compiled, m)
        proof, bindings = _selection(data, slots, selected, m)
        m.tick()
        return _receipt('VERIFIED', None, proof,
                        {'slots': slots, 'candidate_bindings': bindings}, m)
    except InputError as error:
        return _receipt('REJECTED', str(error), None, None, m)
    except BudgetExceeded as error:
        return _receipt('UNKNOWN', str(error), None, None, m)


def _producers(data, m):
    m.tick(len(data['forms']))
    result = [[] for _ in data['forms']]
    for iid, record in data['zero'].items():
        m.tick()
        result[record['formula_id']].append(('zero', iid, ()))
    for fi, antecedent, consequent in data['compiled']['mp_index']:
        m.tick()
        result[consequent].append(('mp', fi, (antecedent, fi)))
    for fi, body, variable in data['compiled']['gen_index']:
        m.tick()
        result[fi].append(('gen', fi, (body,)))
    # Deterministic complete preference only; no producer is removed.
    for rows in result:
        m.tick(len(rows))
        rows.sort(key=lambda row: (len(row[2]), str(row[0]), str(row[1])))
    return result


def _acyclic(chosen, m):
    done = set()
    active = set()
    def visit(fact):
        m.tick()
        if fact in active:
            return False
        if fact in done or fact not in chosen:
            return True
        active.add(fact)
        for premise in chosen[fact][2]:
            if not visit(premise):
                return False
        active.remove(fact)
        done.add(fact)
        return True
    return all(visit(fact) for fact in chosen)


def _proof_from_dag(data, chosen, slots, m):
    proof = []
    indices = {}
    def emit(fact):
        m.tick()
        if fact in indices:
            return indices[fact]
        kind, identity, premises = chosen[fact]
        refs = [emit(p) for p in premises]
        if kind == 'zero':
            line = _copy(data['zero'][identity]['line'], m)
        elif kind == 'mp':
            line = {'rule': 'mp', 'formula': _copy(data['forms'][fact], m),
                    'antecedent': refs[0], 'implication': refs[1]}
        else:
            line = {'rule': 'generalize', 'formula': _copy(data['forms'][fact], m),
                    'source': refs[0], 'variable': data['gen'][identity][2]}
        indices[fact] = len(proof)
        proof.append(line)
        return indices[fact]
    emit(data['goal'])
    _need(1 <= len(proof) <= slots and len(proof) == len(chosen),
          'complete reachable DAG size')
    # At-most bound to exact-row certificate: repeat first zero, shift refs.
    padding = slots - len(proof)
    _need(proof[0]['rule'] in ZERO_FIELDS, 'DAG begins with zero witness')
    padded = [_copy(proof[0], m) for _ in range(padding)]
    for original in proof:
        line = _copy(original, m)
        if line['rule'] == 'mp':
            line['antecedent'] += padding
            line['implication'] += padding
        if line['rule'] == 'generalize':
            line['source'] += padding
        padded.append(line)
    return proof, padded


def backward_dag(problem, compiled, slots, limits=None):
    m = _Meter(limits, SEARCH_LIMITS)
    states = transitions = 0
    try:
        _slots(slots)
        data = _prepare(problem, compiled, m)
        producers = _producers(data, m)
        goal = data['goal']
        # Depth is at most slots<=64; each recursive frame owns one branch.
        # Producers are tried lazily, so pending siblings cannot grow the heap.
        def visit(chosen, pending):
            nonlocal states, transitions
            m.tick()
            if states >= m.limits['max_states']:
                raise BudgetExceeded('STATES')
            states += 1
            if not pending:
                return chosen
            fact, rest = pending[0], pending[1:]
            if fact in chosen:
                return visit(chosen, rest)
            if len(chosen) >= slots:
                return None
            for producer in producers[fact]:
                m.tick()
                if transitions >= m.limits['max_transitions']:
                    raise BudgetExceeded('TRANSITIONS')
                transitions += 1
                m.tick(len(chosen) + len(rest) + len(producer[2]) + 1)
                branch = dict(chosen)
                branch[fact] = producer
                if not _acyclic(branch, m):
                    continue
                missing = []
                seen = set(branch)
                for prerequisite in producer[2] + rest:
                    m.tick()
                    if prerequisite not in seen:
                        seen.add(prerequisite)
                        missing.append(prerequisite)
                if len(branch) + len(missing) > slots:
                    continue
                found = visit(branch, tuple(missing))
                if found is not None:
                    return found
            return None
        found = visit({}, (goal,))
        if found is not None:
            proof, padded = _proof_from_dag(data, found, slots, m)
            details = {'states': states, 'transitions': transitions,
                       'distinct_facts': len(found), 'slots': slots,
                       'padded_proof': padded, 'exhaustive': False,
                       'shortest': False}
            m.tick()
            return _receipt('DERIVABLE', None, proof, details, m)
        m.tick()
        return _receipt('NOT_DERIVABLE', 'FINITE_BASIS_LINE_BOUND', None,
                        {'states': states, 'transitions': transitions,
                         'slots': slots, 'exhaustive': True, 'shortest': False}, m)
    except InputError as error:
        return _receipt('REJECTED', str(error), None,
                        {'states': states, 'transitions': transitions}, m)
    except BudgetExceeded as error:
        return _receipt('UNKNOWN', str(error), None,
                        {'states': states, 'transitions': transitions,
                         'exhaustive': False}, m)

def _model(compiled, slots, m):
    _need(type(slots) is int and 1 <= slots <= 64, 'slots')
    # Full logical catalogue validation belongs to separately injected L core.
    colors = compiled['logical_basis']['colors']
    m.tick(len(colors) + len(compiled['zero_instances']))
    return {'slots': slots, 'colors': list(colors), 'goal_id': compiled['goal_id'],
            'zero': [[r['id'], r['formula_id']] for r in compiled['zero_instances']],
            'mp_index': _copy(compiled['mp_index'], m),
            'gen_index': _copy(compiled['gen_index'], m)}


def _graph(compiled, slots, m):
    model = _model(compiled, slots, m)
    forms = compiled['logical_basis']['formulas']
    zero = {r['id']: r for r in compiled['zero_instances']}
    families = []
    candidates = {}
    steps = {}
    for row in range(slots):
        for iid, output in model['zero']:
            m.tick()
            if row == slots - 1 and output != model['goal_id']:
                continue
            prefix = 'r%d:%s' % (row, iid)
            if len(families)>=10000:
                raise BudgetExceeded('FAMILIES')
            families.append([prefix, 'zero', row, output, None, None])
        for fi, antecedent, output in model['mp_index']:
            m.tick()
            if row != slots - 1 or output == model['goal_id']:
                if len(families)>=10000:
                    raise BudgetExceeded('FAMILIES')
                families.append(['r%d:mp:%d:' % (row, fi), 'mp', row,
                                 output, antecedent, fi])
        for fi, body, variable in model['gen_index']:
            m.tick()
            if row != slots - 1 or fi == model['goal_id']:
                if len(families)>=10000:
                    raise BudgetExceeded('FAMILIES')
                families.append(['r%d:gen:%d:' % (row, fi), 'gen', row,
                                 fi, body, None])
    m.tick(len(families))
    families.sort(key=lambda f: f[0])
    byrow = [[] for _ in range(slots)]
    deps = [[] for _ in range(slots)]
    reverse = []
    for k, family in enumerate(families):
        m.tick()
        prefix, kind, row, output, left, right = family
        byrow[row].append(k)
        points = [row] if kind == 'zero' else list(range(row + 1))
        m.tick(len(points))
        reverse.append(points)
        for point in points:
            deps[point].append(k)
        if kind == 'zero':
            options = [(prefix, {}, zero[prefix.split(':')[1]]['line'],
                        prefix.split(':')[1])]
        elif kind == 'gen':
            variable = next(v for fi, body, v in model['gen_index'] if fi == output)
            options = ((prefix + str(a), {a: left},
                       {'rule': 'generalize', 'formula': forms[output],
                        'source': a, 'variable': variable}, None)
                       for a in range(row))
        else:
            options = ((prefix + '%d:%d' % (a, b), {a: left, b: right},
                       {'rule': 'mp', 'formula': forms[output],
                        'antecedent': a, 'implication': b}, None)
                       for a in range(row) for b in range(row)
                       if a != b or left == right)
        for cid, marks, line, instance in options:
            m.tick()
            if len(candidates) >= 100000:
                raise BudgetExceeded('MEMBERS')
            marks[row] = output
            _need(cid not in candidates, 'candidate identity collision')
            candidates[cid] = (row, marks, k)
            steps[cid] = {'slot': row, 'line': line, 'instance': instance}
    domain = [[] for _ in range(slots)]
    raw = []
    for cid in sorted(candidates):
        m.tick()
        row, marks, family = candidates[cid]
        domain[row].append(cid)
        raw.append({'id': cid, 't': ['slot:' + str(row)],
                    'm': [[point, model['colors'][value]] for point, value in
                          sorted(('out:' + str(q), v) for q, v in marks.items())]})
    definitions = []
    for iid, output in model['zero']:
        definitions.append([iid,'zero',output,None,None])
    for fi,a,out in model['mp_index']:
        definitions.append(['mp:'+str(fi)+':','mp',out,a,fi])
    for fi,body,var in model['gen_index']:
        definitions.append(['gen:'+str(fi)+':','gen',fi,body,None])
    m.tick(len(definitions))
    definitions.sort(key=lambda d:d[0])
    goal_definitions=[k for k,d in enumerate(definitions) if d[2]==model['goal_id']]
    compressed={
        'schema':'W-complete-implicit-row-family-index-v1',
        'definitions':definitions,
        'row_definition_set':[0]*(slots-1)+[1],
        'definition_sets':[{'range':[0,len(definitions)]},{'indices':goal_definitions}],
        'definition_reverse_row_set':[int(d[2]==model['goal_id']) for d in definitions],
        'reverse_row_sets':[{'range':[0,slots-1]},{'range':[0,slots]}],
        'nonzero_definitions':[k for k,d in enumerate(definitions) if d[1]!='zero'],
        'marking_dependencies':{
            'later_rows':'nonzero static row definitions',
            'own_row':'all static row definitions',
            'reverse':'own row plus all earlier row indices for nonzero definitions; own row only for zero'},
        'member_incidence':'Canonical member ID gives own row and one unit t edge. Definition plus earlier ref fields gives exact m support. Reference products omit inconsistent coincident refs. These are descriptors of every virtual member, not one candidate per definition.'}
    return {'model': model, 'families': families, 'compressed':compressed, 'byrow': byrow,
            'deps': deps, 'reverse': reverse, 'candidates': candidates,
            'steps': steps, 'domain': domain,
            'raw_model': {'required': ['slot:' + str(q) for q in range(slots)],
                          'candidates': raw}}


def _solutions(graph, m):
    count = 1
    for domain in graph['domain']:
        m.tick()
        count *= len(domain)
        if count > PRODUCT_CAP:
            raise BudgetExceeded('TINY_PRODUCT')
    m.tick(count * max(1, graph['model']['slots']))
    result = []
    for selected in itertools.product(*graph['domain']):
        assigned = {}
        compatible = True
        for cid in selected:
            m.tick()
            for point, value in graph['candidates'][cid][1].items():
                m.tick()
                if point in assigned and assigned[point] != value:
                    compatible = False
                    break
                assigned[point] = value
            if not compatible:
                break
        if compatible:
            result.append(tuple(sorted(selected)))
    return count, result


def _core(state):
    return {k: state[k] for k in ('occupied', 'selected', 'values', 'refs', 'excluded')}


def _state(graph, state, m, solutions=None):
    _fields(state, {'schema','occupied','selected','values','refs','excluded',
                    'required','frontier','root_generations','degrees','aggregates'})
    _need(state['schema']=='W-aggregate-unit-point-state-v1','state schema')
    n = graph['model']['slots']
    for key in ('occupied', 'selected', 'values', 'refs'):
        _need(type(state[key]) is list and len(state[key]) == n, 'state row array')
    _need(all(type(v) is bool for v in state['occupied']), 'occupied bool')
    _need(all(v is None or type(v) is str for v in state['selected']), 'selected type')
    _need(all(v is None or type(v) is int and 0 <= v < len(graph['model']['colors'])
              for v in state['values']), 'values IDs')
    _need(all(type(v) is int and v >= 0 for v in state['refs']), 'refs type')
    excluded = state['excluded']
    _need(type(excluded) is list and all(type(cid) is str for cid in excluded)
          and excluded == sorted(set(excluded))
          and all(cid in graph['candidates'] for cid in excluded), 'excluded')
    expected_values = [None] * n
    expected_refs = [0] * n
    selected_ids = []
    for row, cid in enumerate(state['selected']):
        m.tick()
        _need(state['occupied'][row] == (cid is not None), 'occupied/selected')
        if cid is None:
            continue
        _need(cid in graph['candidates'] and graph['candidates'][cid][0] == row
              and cid not in excluded, 'selected actual member/root')
        selected_ids.append(cid)
        for point, value in graph['candidates'][cid][1].items():
            m.tick()
            _need(expected_values[point] is None or expected_values[point] == value,
                  'selected actual m conflict')
            expected_values[point] = value
            expected_refs[point] += 1
    _need(_same(state['values'], expected_values, m)
          and _same(state['refs'], expected_refs, m), 'whole assigned values/refcounts')
    # Complete physical legality independently visits every virtual candidate.
    legal = [[] for _ in range(n)]
    family_counts = [0] * len(graph['families'])
    for cid, (row, marks, k) in graph['candidates'].items():
        m.tick()
        if state['occupied'][row] or cid in excluded:
            continue
        if all(expected_values[p] is None or expected_values[p] == value
               for p, value in marks.items()):
            legal[row].append(cid)
            family_counts[k] += 1
    for domain in legal:
        m.tick(len(domain))
        domain.sort()
    aggregates=[]
    definitions=graph['compressed']['definitions']
    for row in range(n):
        m.tick()
        if state['occupied'][row]:
            aggregates.append(None)
            continue
        hist=collections.Counter(v for v in expected_values[:row] if v is not None)
        u=sum(v is None for v in expected_values[:row])
        fixed=graph['model']['goal_id'] if row==n-1 else expected_values[row]
        allowed=[d for d in definitions if fixed is None or d[2]==fixed]
        if row==n-1 and expected_values[row] is not None and expected_values[row]!=fixed:
            allowed=[]
        zero=K=D=S=Q=Kg=weighted=0
        for suffix,kind,out,a,b in allowed:
            m.tick()
            if kind=='zero':zero+=1
            elif kind=='mp':
                K+=1;D+=int(a!=b);S+=hist[a]+hist[b];Q+=hist[a]*hist[b]
            else:
                Kg+=1;weighted+=hist[a]
        mp=K*u*u-D*u+S*u+Q
        gen=Kg*u+weighted
        raw_excluded=0
        for cid in excluded:
            r,marks,k=graph['candidates'][cid]
            if r==row and all(expected_values[p] is None or expected_values[p]==v
                              for p,v in marks.items()):raw_excluded+=1
        degree=zero+mp+gen-raw_excluded
        _need(degree==len(legal[row]),'aggregate algebra agrees with every actual member')
        aggregates.append([u,[[fid,count] for fid,count in sorted(hist.items())],
                           fixed,zero,[K,D,S,Q,mp],[Kg,weighted,gen],raw_excluded,degree])
    expected={
        'required':['slot:'+str(q) for q in range(n)],
        'frontier':['slot:'+str(q) for q in range(n) if not state['occupied'][q]],
        'root_generations':[0]*n,'degrees':[len(domain) for domain in legal],
        'aggregates':aggregates}
    for key, value in expected.items():
        _need(_same(state[key], value, m), 'full graph ' + key)
    if solutions is not None:
        selected_set = set(selected_ids)
        for cid in excluded:
            m.tick(len(solutions))
            _need(not any(selected_set.union([cid]).issubset(sol) for sol in solutions),
                  'excluded member has actual full completion in this context')
    return {'status': 'VERIFIED', 'state_sha256': _sha(state, m),
            'core_sha256': _sha(_core(state), m),
            'legal_ids': legal, 'selected': sorted(selected_ids),
            'scope': 'All materialized members, factors, values/refcounts and both graph/dependency directions; optional full tiny completion exclusion proof.'}


def _event(graph, event, state, receipt, previous, m):
    _fields(event, {'seq', 'kind', 'data'})
    _need(type(event['seq']) is int and event['seq'] >= 0
          and type(event['kind']) is str, 'event types')
    kind, data = event['kind'], event['data']
    if previous is None:
        _need(kind == 'ENTRY' and event['seq'] == 0, 'first entry event')
        _fields(data, set())
        _need(not any(state['occupied']) and not any(state['refs'])
              and not state['excluded'], 'empty entry')
        return
    old = previous['state']
    legal = previous['audit']['legal_ids']
    if kind == 'DEAD':
        _fields(data, {'row', 'generation'})
        q = data['row']
        _need(type(q) is int and 0 <= q < len(legal) and not state['occupied'][q]
              and type(data['generation']) is int and data['generation'] == 0
              and not receipt['legal_ids'][q] and _same(old,state,m), 'actual global dead')
    elif kind == 'BRANCH':
        _fields(data, {'row', 'generation', 'degree', 'first_candidate', 'order'})
        frontier = [q for q in range(len(legal)) if not old['occupied'][q]]
        _need(frontier and all(len(legal[q]) >= 2 for q in frontier),
              'branch before global dead/forced')
        q = min(frontier, key=lambda r: (len(legal[r]), 'slot:' + str(r)))
        _need(type(data['row']) is int and data['row'] == q
              and type(data['generation']) is int and data['generation'] == 0
              and type(data['degree']) is int and data['degree'] == len(legal[q])
              and data['first_candidate'] == legal[q][0]
              and data['order'] == 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'
              and _same(old, state, m), 'complete MRV lexical branch')
    elif kind == 'PLACED':
        _fields(data, {'candidate', 'row', 'forced', 'root_generation', 'tile_generation'})
        q, cid = data['row'], data['candidate']
        _need(type(q) is int and 0 <= q < len(legal) and type(data['forced']) is bool
              and cid in legal[q] and state['selected'][q] == cid
              and type(data['root_generation']) is int and data['root_generation'] == 0
              and type(data['tile_generation']) is int and data['tile_generation'] == 1,
              'placed actual legal unit member')
        if data['forced']:
            frontier = [r for r in range(len(legal)) if not old['occupied'][r]]
            _need(all(legal[r] for r in frontier), 'forced before later dead')
            singles = [r for r in frontier if len(legal[r]) == 1]
            _need(singles and q == min(singles, key=lambda r: 'slot:' + str(r)),
                  'global forced lexical root')
        else:
            _need(cid == legal[q][0], 'complete lexical branch continuation')
        expected_selected = list(old['selected'])
        expected_selected[q] = cid
        _need(_same(expected_selected, state['selected'], m)
              and _same(old['excluded'], state['excluded'], m), 'one placement')
    elif kind == 'EXCLUDED':
        _fields(data, {'candidate', 'parent_core_sha256'})
        cid = data['candidate']
        _need(type(cid) is str and cid in graph['candidates']
              and data['parent_core_sha256'] == previous['audit']['core_sha256'],
              'exclusion exact parent')
        for key in ('occupied', 'selected', 'values', 'refs'):
            _need(_same(old[key], state[key], m), 'exclusion changes only exclusions')
        _need(cid not in old['excluded'] and state['excluded'] == sorted(old['excluded'] + [cid]),
              'one scoped exclusion')
    elif kind == 'ROLLBACK':
        _fields(data, {'reason', 'target', 'undone', 'before_core_sha256',
                       'after_core_sha256', 'expected_parent_core_sha256'})
        _need(data['reason'] == 'FAILED_CHILD'
              and data['before_core_sha256'] == previous['audit']['core_sha256']
              and data['after_core_sha256'] == receipt['core_sha256']
              and data['expected_parent_core_sha256'] == receipt['core_sha256'],
              'actual failed-child core restoration')
    elif kind == 'SOLUTION':
        _fields(data, {'selected'})
        _need(all(state['occupied']) and data['selected'] == receipt['selected']
              and _same(old,state,m),
              'whole actual solution event')
    else:
        raise InputError('unexpected event kind')


def _certificate(graph, selected, indexed, m):
    n = graph['model']['slots']
    totals = [0] * n
    values = [None] * n
    refs = [0] * n
    for cid in selected:
        _need(cid in graph['candidates'], 'certificate member')
        row, marks, family = graph['candidates'][cid]
        totals[row] += 1
        for point, value in marks.items():
            _need(values[point] is None or values[point] == value, 'certificate m')
            values[point] = value
            refs[point] += 1
    _need(totals == [1] * n and all(v is not None for v in values), 'whole t/m')
    if indexed:
        return {'selected': sorted(selected), 'totals': totals,
                'markings': [[q, graph['model']['colors'][values[q]], refs[q]] for q in range(n)],
                'generations': [[cid, 1] for cid in sorted(selected)]}
    return {'selected': sorted(selected),
            'totals': [['slot:' + str(q), 1] for q in range(n)],
            'markings': [['out:' + str(q), graph['model']['colors'][values[q]], refs[q]] for q in sorted(range(n), key=lambda q: 'out:' + str(q))],
            'generations': [[cid, 1] for cid in sorted(selected)]}


def _result(graph, result, observations, m, solutions=None, expected_version=None):
    _fields(result, {'schema', 'version', 'status', 'reason', 'model', 'families',
                     'model_sha256', 'selected', 'certificate', 'stats', 'events',
                     'event_extent', 'entry_state', 'restored_state', 'state_hashes',
                     'rollback_records', 'scope'})
    _need(type(result['schema']) is str and result['schema']=='W-aggregate-unit-point-result-v1'
          and type(result['version']) is str and result['version']==expected_version,
          'current result wire/version')
    _need(type(result['status']) is str and result['status'] in ('SAT','UNSAT','UNKNOWN'),
          'status')
    prepared = result['entry_state'] is not None
    if prepared:
        _need(_same(result['model'],graph['model'],m)
              and _same(result['families'],graph['compressed'],m)
              and result['model_sha256']==_sha(graph['model'],m),
              'prepared complete model/families')
    else:
        _need(result['status']=='UNKNOWN' and result['families'] is None,
              'no fabricated partial family graph')
        if result['model'] is None:
            _need(result['model_sha256'] is None,'point-model preparation refusal')
        else:
            _need(_same(result['model'],graph['model'],m)
                  and result['model_sha256']==_sha(graph['model'],m),
                  'complete point model before state-constructor refusal')
    if solutions is not None:
        _need(result['status']==('SAT' if solutions else 'UNSAT'),'tiny exhaustive outcome')
    if result['status']=='SAT':
        selected=result['selected']
        _need(type(selected) is list and selected==sorted(set(selected)),'selected shape')
        if solutions is not None:
            _need(tuple(selected) in solutions,'full tiny solution membership')
        _need(_same(result['certificate'],_certificate(graph,selected,True,m),m),
              'exact actual point certificate')
    else:
        _need(result['selected'] is None and result['certificate'] is None,
              'no false certificate')
    hashes=result['state_hashes']
    _fields(hashes,{'entry','restored'})
    if prepared:
        entry=result['entry_state']
        _state(graph,entry,m)
        _need(not any(entry['occupied']) and not any(entry['refs'])
              and all(v is None for v in entry['values']) and not entry['excluded'],
              'actual empty initial state')
        _need(result['restored_state'] is not None,'prepared restoration exists')
        _state(graph,result['restored_state'],m)
        _need(_same(entry,result['restored_state'],m)
              and hashes['entry']==_sha(entry,m)
              and hashes['restored']==_sha(result['restored_state'],m),'full restoration')
        if observations:
            _need(_same(entry,observations[0]['state'],m),'entry/first observation join')
    else:
        _need(result['restored_state'] is None
              and _same(hashes,{'entry':None,'restored':None},m)
              and not observations,'preparation-refused scope')
    extent=result['event_extent']
    _fields(extent,{'count','retained','JSONL_bytes','SHA256','evaluation_complete'})
    events=result['events']
    _need(type(events) is list,'events list')
    observed=[row['event'] for row in observations]
    _need(_same(events[:len(observed)],observed,m),'all actual observer bodies joined')
    tail=len(events)-len(observed)
    _need(tail>=0 and (tail==0 if result['status']!='UNKNOWN' else tail<=1),
          'only budget-refused last event can lack an observer image')
    for number,event in enumerate(events):
        _fields(event,{'seq','kind','data'})
        _need(type(event['seq']) is int and event['seq']==number
              and type(event['kind']) is str and type(event['data']) is dict,
              'full retained event wire')
    _need(all(type(v) is int and v>=0 for v in
              [extent['count'],extent['retained'],extent['JSONL_bytes']]),'event extent ints')
    stream=b''.join(_wire(event,m) for event in events)
    _need(extent['count']==extent['retained']==len(events)
          and extent['JSONL_bytes']==len(stream)
          and extent['SHA256']==hashlib.sha256(stream).hexdigest()
          and type(extent['evaluation_complete']) is bool
          and extent['evaluation_complete']==(result['status']!='UNKNOWN'),'full event extent')
    stat=result['stats']
    integer_keys={'operations','nodes','definitions','families','virtual_members','dependency_links',
                  'row_refreshes','member_probes','placements','forced_placements','branch_decisions',
                  'backtracks','scoped_exclusions','trail_writes','trail_undos','max_trail',
                  'cleanup_undos','observations','events'}
    _fields(stat,integer_keys.union({'cleanup_seconds','elapsed_seconds'}))
    _need(all(type(stat[k]) is int and stat[k]>=0 for k in integer_keys),'stats integers')
    _need(all(type(stat[k]) in (int,float) and math.isfinite(stat[k]) and stat[k]>=0
              for k in ('cleanup_seconds','elapsed_seconds')),'stats clocks')
    _need(stat['events']==len(events) and len(observed)<=stat['observations']<=len(events),
          'actual observer/event census')
    if result['status']!='UNKNOWN':
        _need(stat['observations']==len(observed),'normal complete observations')
    if prepared:
        _need(stat['definitions']==len(graph['compressed']['definitions'])
              and stat['families']==len(graph['families'])
              and stat['virtual_members']==len(graph['candidates'])
              and stat['dependency_links']==sum(len(v) for v in graph['deps']),
              'complete graph cardinalities, one dependency relation')
    records=result['rollback_records']
    _need(type(records) is list,'rollback records')
    undone=0
    final=None
    for record in records:
        m.tick()
        reason=record['reason']
        extra='expected_parent_core_sha256' if reason=='FAILED_CHILD' else 'full_restored_sha256'
        _fields(record,{'reason','target','undone','before_core_sha256','after_core_sha256',extra})
        _need(reason in ('FAILED_CHILD','FINAL_MANDATORY_CLEANUP')
              and type(record['target']) is type(record['undone']) is int
              and record['target']>=0 and record['undone']>=0,'rollback types')
        undone+=record['undone']
        if reason=='FAILED_CHILD':
            _need(record['after_core_sha256']==record['expected_parent_core_sha256']
                  and any(e['kind']=='ROLLBACK' and _same(e['data'],record,m) for e in events),
                  'failed child retained record association')
        else:
            _need(final is None and record is records[-1] and record['target']==0,
                  'one last whole cleanup')
            final=record
    _need(undone==stat['trail_undos'] and stat['trail_writes']==stat['trail_undos'],
          'actual all-write rollback conservation')
    if prepared:
        _need(final is not None and final['undone']==stat['cleanup_undos']
              and final['full_restored_sha256']==hashes['restored']
              and final['after_core_sha256']==_sha(_core(result['restored_state']),m),
              'final cleanup scope')
    return {'status':'VERIFIED','observations':len(observed),'emitted_events':len(events),
            'unobserved_tail_events':tail,'undo_entries':undone,'scope':SCOPE}


def _run(indexed, compiled, slots, graph, m, solutions=None, limits=None, mutate=False):
    observations = []
    def observe(event, state):
        m.tick()
        receipt = _state(graph, state, m, solutions)
        _event(graph, event, state, receipt, observations[-1] if observations else None, m)
        _need(event['seq'] == len(observations), 'complete observation sequence')
        observations.append({'event':_copy(event,m),'state':_copy(state,m),'audit':receipt})
        if mutate:
            event.clear()
            state['selected'].append('FOREIGN_MUTATION')
        return False
    result = indexed.solve(compiled, slots, dict(ENGINE_LIMITS) if limits is None else limits,
                           observe=observe)
    receipt = _nohook_result(graph, result, observations, m, solutions)
    return result, observations, receipt



def _nohook_result(graph,result,observations,m,solutions=None):
    _need(type(result)is dict and 'heuristic'in result and len(result)==18,'X full result')
    _need(result['schema']=='X-cluster-guided-unit-point-result-v1' and result['version']=='X-CLUSTER-GUIDED-UNIT-PROOF-POINT-SEARCH-v1','X result identity')
    h=result['heuristic'];_fields(h,{'schema','limits','stats','trace','scope'})
    _need(h['schema']=='X-validated-cluster-guide-v1','guide identity')
    _fields(h['limits'],{'max_calls','max_packets','max_members','max_records'})
    _need(all(type(v)is int and v>=0 for v in h['limits'].values()),'guide caps')
    stats=h['stats'];_fields(stats,{'calls','offered_packets','valid_packets','rejected_packets','continuation_tests','continuation_uses','preferred_placements','max_covered','limit_skips','callback_seconds','validation_seconds','executed_packet_ids'})
    for key,v in stats.items():
        if key=='executed_packet_ids':_need(type(v)is dict and not v,'no packet credit')
        elif key=='max_covered':_need(type(v)is int and 0<=v<=graph['model']['slots'],'max covered')
        else:_need(type(v)in (int,float) and type(v)is not bool and v==0,'nohook zero guidance')
    if result['status']!='UNKNOWN':
        _need(stats['max_covered']==max((sum(row['state']['occupied']) for row in observations),default=0),'complete nohook coverage')
    trace=h['trace'];_fields(trace,{'count','retained','JSONL_bytes','SHA256','records'})
    _need(_same(trace,{'count':0,'retained':0,'JSONL_bytes':0,'SHA256':hashlib.sha256(b'').hexdigest(),'records':[]},m),'nohook no guide trace')
    m.tick(len(result));projected={k:v for k,v in result.items() if k!='heuristic'}
    projected['schema']='W-aggregate-unit-point-result-v1';projected['version']='W-AGGREGATE-UNIT-PROOF-POINT-SEARCH-v1'
    receipt=_result(graph,projected,observations,m,solutions,'W-AGGREGATE-UNIT-PROOF-POINT-SEARCH-v1')
    receipt['adapter']='ONLY schema/version/drop separately audited nohook heuristic; full original18 preserved.'
    return receipt


def _tiny_cases():
    P=['pred','P',[]];Q=['pred','Q',[]];x=['var','x'];a=['fun','a',[]]
    px=['pred','P',[x]];pa=['pred','P',[a]]
    base={'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}
    specs=[('EMPTY',{},Q,2,0,0),('GIVEN',{'p':P},P,2,1,1),
           ('ALIASES',{'p':P,'alias':P},P,2,4,4),
           ('MP',{'p':P,'pq':['imp',P,Q]},Q,3,8,2),
           ('CYCLE',{'pq':['imp',P,Q],'qp':['imp',Q,P]},P,3,8,0)]
    out=[]
    for name,axioms,goal,n,product,solutions in specs:
        out.append((name,{'theory':{'functions':{},'predicates':{'P':0,'Q':0},'axioms':axioms},'goal':goal,'profile':dict(base)},n,product,solutions))
    out.append(('UI',{'theory':{'functions':{'a':0},'predicates':{'P':1},'axioms':{'u':['all','x',px]}},'goal':pa,'profile':dict(base,ui_rounds=1)},3,60,2))
    out.append(('GEN',{'theory':{'functions':{},'predicates':{'P':0},'axioms':{'p':P}},'goal':['all','x',P],'profile':dict(base)},2,2,1))
    return out


def _schema_cases():
    x=['var','x'];y=['var','y'];z=['var','fresh0'];a=['fun','a',[]];b=['fun','b',[]]
    capture=['all','fresh0',['all','x',['all','y',['pred','R',[x,y,z]]]]]
    P=['pred','P',[]];Q=['pred','Q',[]]
    return [
      ('CAPTURE',{'theory':{'functions':{},'predicates':{'R':3},'axioms':{'u':capture}},'goal':capture,'profile':{'ui_rounds':2,'bridge_arity':0,'max_tautology_atoms':4}}),
      ('EQSUB',{'theory':{'functions':{'a':0,'b':0},'predicates':{'P':1},'axioms':{'e':['eq',a,b],'p':['pred','P',[a]]}},'goal':['pred','P',[b]],'profile':{'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}}),
      ('CONJUNCTION',{'theory':{'functions':{},'predicates':{'P':0,'Q':0},'axioms':{'p':P,'q':Q}},'goal':['and',P,Q],'profile':{'ui_rounds':0,'bridge_arity':2,'max_tautology_atoms':4}})]


def _compiled_case(generator,logical_check,name,problem,m,counts):
    original=_sha(problem,m)
    built=generator.build_basis(problem['theory'],problem['goal'],problem['profile'],dict(BUILD_LIMITS));counts['build_basis']+=1
    _need(type(built)is dict and built['status']=='COMPLETE' and built['compiled']is not None,'tiny complete generator')
    whole=verify_compiled(problem,built['compiled'],built['generation']);counts['verify_compiled']+=1
    _need(whole['status']=='VERIFIED','independent whole Y catalogue')
    schemas=verify_zero_schemas(problem,built['compiled'],logical_check,dict(CHECKER_LIMITS));counts['verify_zero_schemas']+=1
    _need(schemas['status']=='VERIFIED','all actual zero schemas')
    counts['host_schema_calls']+=schemas['details']['checker_calls']
    _need(_sha(problem,m)==original,'input purity')
    return {'case':name,'problem':_copy(problem,m),'basis_return':built,'catalogue_audit':whole,'zero_schema_audit':schemas,'native_certificates':[]}


def qualify(generator,engine,logical_check,emit):
    """Closed ten-input Source recipe; future owned caller supplies all producers."""
    m=_Meter({'wall_seconds':60,'max_work':1000000000,'max_depth':128,'max_candidates':100000},VERIFY_LIMITS)
    counts={'build_basis':0,'materialize':0,'decode':0,'engine_solve':0,'host_schema_calls':0,'verify_compiled':0,'verify_zero_schemas':0,'verify_selection':0,'backward_dag':0,'native_certificates':0,'observations':0,'emits':0}
    retained={}
    for name,problem,slots,expected_product,expected_solutions in _tiny_cases():
        record=_compiled_case(generator,logical_check,name,problem,m,counts);compiled=record['basis_return']['compiled']
        graph=_graph(compiled,slots,m);product,solutions=_solutions(graph,m)
        _need(product==expected_product and len(solutions)==expected_solutions,'independent complete tiny product/solutions')
        materialized=generator.materialize(compiled,slots,{'wall_seconds':2,'max_work':20000000,'max_depth':128,'max_candidates':100000});counts['materialize']+=1
        _need(materialized['status']=='COMPLETE','tiny full materialization');bundle=materialized['bundle']
        _need(_same(bundle['model']['required'],graph['raw_model']['required'],m) and len(bundle['model']['candidates'])==len(graph['candidates']) and _same({r['id']:r for r in bundle['model']['candidates']},{r['id']:r for r in graph['raw_model']['candidates']},m) and _same(bundle['steps'],graph['steps'],m),'every explicit candidate/step')
        point,observations,audit=_run(engine,compiled,slots,graph,m,solutions,mutate=name=='GIVEN');counts['engine_solve']+=1;counts['observations']+=len(observations)
        selection=None;decoded=None
        if point['status']=='SAT':
            selection=verify_selection(problem,compiled,slots,point['selected']);counts['verify_selection']+=1
            _need(selection['status']=='VERIFIED','actual tiny point proof')
            decoded=generator.decode(compiled,slots,point['selected'],{'wall_seconds':2,'max_work':20000000,'max_depth':128,'max_candidates':64});counts['decode']+=1
            _need(decoded['status']=='UNVERIFIED_CERTIFICATE' and _same(decoded['proof'],selection['proof'],m) and _same(decoded['target'],problem['goal'],m),'all actual selected decoder lines')
            record['native_certificates'].append({'label':name+'-point','problem':_copy(problem,m),'proof':_copy(selection['proof'],m)})
        control=backward_dag(problem,compiled,slots);counts['backward_dag']+=1
        _need(control['status']==('DERIVABLE' if solutions else 'NOT_DERIVABLE'),'shared-DAG complete tiny equality')
        if solutions:
            proof=control['proof'];padded=control['details']['padded_proof']
            _need(1<=len(proof)<=slots and len(padded)==slots,'shared fact/row bound')
            padded_ids=[]
            for row,line in enumerate(padded):
                matches=[cid for cid in graph['domain'][row] if _same(graph['steps'][cid]['line'],line,m)]
                _need(matches,'control padding has an actual virtual row');padded_ids.append(matches[0])
            _need(tuple(sorted(padded_ids))in solutions,'control padded proof is an actual complete tiling')
            control['details']['padded_candidate_ids']=sorted(padded_ids)
            checked,_=_selection(_prepare(problem,compiled,m),slots,padded_ids,m)
            _need(_same(checked,padded,m),'control actual mark/earlier-ref certificate')
            record['native_certificates'].append({'label':name+'-control','problem':_copy(problem,m),'proof':_copy(proof,m)})
        if name=='GIVEN':
            _need(all(v is None for v in observations[0]['state']['values']) and any(0 in r['state']['values'] for r in observations),'assigned0 versus absent')
        if name=='ALIASES':_need(observations[0]['state']['degrees']==[2,2],'duplicate conclusion witnesses retained')
        if name=='CYCLE':_need(any(r['event']['kind']=='ROLLBACK' for r in observations) and any(r['event']['kind']=='EXCLUDED' for r in observations),'actual failed child scoped undo')
        record.update(slots=slots,materialized=materialized,product=product,full_solution_ID_sets=[list(s) for s in solutions],point=point,observations=observations,graph_audit=audit,selection=selection,decoded=decoded,control=control)
        counts['native_certificates']+=len(record['native_certificates']);counts['emits']+=1;emit(name,record)
        retained[name]=(problem,compiled,record['basis_return']['generation'],graph,record)
    for name,problem in _schema_cases():
        record=_compiled_case(generator,logical_check,name,problem,m,counts);c=record['basis_return']['compiled']
        if name=='CAPTURE':
            _need(any(r['rule']=='instantiate' and 'fresh1' in _key(r['line'],m) for r in c['zero_instances']),'actual capture-avoidance fresh1 witness')
        if name=='EQSUB':_need(any(r['rule']=='eq_subst' for r in c['zero_instances']),'atomic-input accepted EqSub')
        if name=='CONJUNCTION':
            goal=problem['goal'];wanted=['imp',problem['theory']['axioms']['p'],['imp',problem['theory']['axioms']['q'],goal]]
            _need(any(r['rule']=='tautology' and _same(r['line']['formula'],wanted,m) for r in c['zero_instances']),'actual two-premise conjunction bridge')
        counts['emits']+=1;emit(name,record)
    # Forgery controls are detached data derived from retained tiny returns, no new search.
    problem,c,g,graph,record=retained['UI'];mutations=[]
    bad=_copy(c,m);bad['logical_basis']['colors'][0]='FORGED';answer=verify_compiled(problem,bad,g);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','color mutation');mutations.append({'kind':'COLOR','receipt':answer})
    bad=_copy(c,m);bad['mp_index']=[];answer=verify_compiled(problem,bad,g);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','MP universe mutation');mutations.append({'kind':'MP_INDEX','receipt':answer})
    bad=_copy(c,m);bad['zero_instances'].pop();bad['costs']['instances']-=1
    for stage in bad['logical_basis']['stages']:stage['instance_count']=min(stage['instance_count'],len(bad['zero_instances']))
    answer=verify_compiled(problem,bad,g);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','complete zero omission');mutations.append({'kind':'OMITTED_ZERO','receipt':answer})
    bad=_copy(c,m);extra=_copy(bad['zero_instances'][-1],m);extra['id']='i'+str(len(bad['zero_instances']));bad['zero_instances'].append(extra);bad['costs']['instances']+=1
    answer=verify_compiled(problem,bad,g);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','extra zero alias');mutations.append({'kind':'EXTRA_ZERO','receipt':answer})
    badg=_copy(g,m);badg['core_assertions']=[];answer=verify_compiled(problem,c,badg);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','manifest mutation');mutations.append({'kind':'CORE_MANIFEST','receipt':answer})
    bad=_copy(c,m);bad['zero_instances'][0]['line']['formula']=_copy(problem['goal'],m)
    # This changes a full zero payload while keeping all supplied input values detached.
    answer=verify_compiled(problem,bad,g);counts['verify_compiled']+=1;_need(answer['status']=='REJECTED','zero payload mutation');mutations.append({'kind':'ZERO_PAYLOAD','receipt':answer})
    invalid=list(record['point']['selected']);position=next(i for i,cid in enumerate(invalid) if cid.startswith('r2:mp:'));parts=invalid[position].split(':');parts[3]='2';invalid[position]=':'.join(parts);answer=verify_selection(problem,c,3,invalid);counts['verify_selection']+=1;_need(answer['status']=='REJECTED','nonprior ref mutation');mutations.append({'kind':'SELECTED_PRIOR_REF','receipt':answer})
    forged=_copy(record['point']['entry_state'],m);forged['values'][0]=0
    try:_state(graph,forged,m);raise InputError('forged unselected marking accepted')
    except InputError as error:_need(str(error)!='forged unselected marking accepted','graph forgery refused');mutations.append({'kind':'ABSENT_AS_ASSIGNED_ZERO','reason':str(error)})
    counts['emits']+=1;emit('MUTATIONS',{'case':'MUTATIONS','mutations':mutations,'native_certificates':[]})
    # Independent and producer-owned exhaustion return UNKNOWN with no complete prefix.
    qlimits=dict(VERIFY_LIMITS,max_work=0);audit=verify_compiled(problem,c,g,limits=qlimits);_need(audit['status']=='UNKNOWN' and audit['proof']is None,'own audit refusal');counts['verify_compiled']+=1
    control=backward_dag(problem,c,3,dict(SEARCH_LIMITS,max_states=0));counts['backward_dag']+=1;_need(control['status']=='UNKNOWN' and control['proof']is None,'control states refusal')
    refusal=generator.build_basis(problem['theory'],problem['goal'],problem['profile'],dict(BUILD_LIMITS,max_work=0));counts['build_basis']+=1
    _need(refusal['status']=='UNKNOWN' and refusal['compiled']is None and refusal['generation']is None,'generation no partial prefix')
    stops=[]
    for key in ('max_nodes','max_operations'):
        limits=dict(ENGINE_LIMITS);limits[key]=0
        answer,seen,receipt=_run(engine,c,3,graph,m,None,limits=limits);counts['engine_solve']+=1;counts['observations']+=len(seen)
        _need(answer['status']=='UNKNOWN' and answer['selected']is None and answer['certificate']is None,'engine owned refusal')
        stops.append({'limit':key,'result':answer,'observations':seen,'audit':receipt})
    counts['emits']+=1;emit('RESOURCES',{'case':'RESOURCES','audit':audit,'control':control,'generation':refusal,'point':stops,'native_certificates':[]})
    class ForeignFailure(Exception):pass
    def throwing(event,state):raise ForeignFailure('owned qualification callback')
    escaped=False
    try:
        counts['engine_solve']+=1;engine.solve(c,3,dict(ENGINE_LIMITS),observe=throwing)
    except ForeignFailure:escaped=True
    _need(escaped,'foreign callback propagates after Source-defined cleanup')
    counts['emits']+=1;emit('FOREIGN',{'case':'FOREIGN','escaped':True,'post_exception_state':None,'scope':'No post-throw state invented; cleanup Source-reviewed.','native_certificates':[]})
    _need(counts['build_basis']==11 and counts['materialize']==7 and counts['decode']==5 and counts['engine_solve']==10 and counts['host_schema_calls']==9 and counts['native_certificates']==10 and counts['emits']==13,'closed subject-call/native/emit census')
    return {'schema':'Y-independent-receptor-qualification-result-v1','version':VERSION,'status':'PASS','counts':counts,'tiny_products':83,'tiny_solutions':10,'scope':SCOPE,'costs':m.costs()}
