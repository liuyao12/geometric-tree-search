"""Y bounded goal/receptor Hilbert8 catalogue. Inert Source only.

New declared witness universe; no teacher proofs, search, project imports or IO.
Core assertions, input contexts and goal receptors are fixed separately from
emitted schema syntax. Resource refusal never exports a partial catalogue.
"""
import json
import hashlib
import math
import time
from collections import OrderedDict

# VERSION is the intentionally unchanged public compiled wire, not Source identity.
IMPLEMENTATION_VERSION = 'Y-GOAL-RECEPTOR-FAMILY-v1'
VERSION = 'V-INTERNED-FINITE-HILBERT8-v1'
COMPAT_VERSION = 'U-FINITE-HILBERT8-BASIS-v1'
_SCOPE = ('Y NEW finite goal/receptor family universe, not the W/U catalogue. '
          'V compiled and U explicit identity literals are structural carriers only. '
          'Finite unit/root0 proof rows; no unrestricted FOL/PA/Hilbert, fixed literal '
          'Wang palette, RL benefit or comparative speed claim. Every chosen proof '
          'requires actual unchanged C1 plus independent B; UNKNOWN is not failure.')


class InputError(ValueError):
    pass


class _Stop(Exception):
    pass


def _fields(value, names):
    if (type(value) is not dict or len(value) != len(names) or
            any(type(k) is not str for k in value) or set(value) != set(names)):
        raise InputError('FIELDS')


def _limits(value, basis=True):
    caps = {'max_work': 1000000000, 'max_depth': 128}
    if basis:
        caps.update(max_basis=100000, max_instances=100000,
                    max_interned=1000000, max_cache_entries=1000000)
    else:
        caps['max_candidates'] = 1000000
    _fields(value, tuple(caps) + ('wall_seconds',))
    wall = value['wall_seconds']
    if type(wall) not in (int, float) or not 0 < wall <= 60 or not math.isfinite(wall):
        raise InputError('WALL')
    for key, maximum in caps.items():
        if type(value[key]) is not int or not 0 <= value[key] <= maximum:
            raise InputError('LIMIT_INTEGER')
    return dict(value)


class _Meter:
    def __init__(self, limits, started):
        self.limits, self.started = limits, started
        self.work = 0
        self.terms = self.formulas = self.instances = self.candidates = 0
        self.cache_hits = self.cache_misses = 0
        self.canonical_serializations = self.substitution_calls = 0
        self.cache_entries = self.cache_peak_entries = self.cache_evictions = 0
        self.interned_nodes = self.peak_interned_nodes = 0
        self.transient_nodes_discarded = self.equality_probes = 0
        self.bridge_tests = self.bridge_rejections = 0

    def tick(self, units=1, depth=0):
        if depth > self.limits['max_depth']:
            raise _Stop('DEPTH_LIMIT')
        if units > self.limits['max_work'] - self.work:
            raise _Stop('WORK_LIMIT')
        self.work += units
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            raise _Stop('WALL_LIMIT')

    def costs(self):
        return {k: getattr(self, k) for k in ('work', 'terms', 'formulas', 'instances',
                'candidates', 'cache_hits', 'cache_misses', 'canonical_serializations',
                'substitution_calls')} | {'seconds': time.perf_counter() - self.started}


    def optimization(self):
        return {'implementation_version': IMPLEMENTATION_VERSION,
                'cache_capacity': self.limits['max_cache_entries'],
                **{k: getattr(self, k) for k in ('cache_entries', 'cache_peak_entries',
                   'cache_evictions', 'interned_nodes', 'peak_interned_nodes',
                   'transient_nodes_discarded', 'equality_probes',
                   'bridge_tests', 'bridge_rejections')}}


def _name(value, meter):
    meter.tick()
    if type(value) is not str or not 1 <= len(value) <= 64:
        raise InputError('NAME')
    meter.tick(len(value))
    if any(ord(c) < 32 or ord(c) > 126 for c in value):
        raise InputError('NAME_ASCII')
    return value


def _signature(value, meter):
    if type(value) is not dict:
        raise InputError('SIGNATURE')
    meter.tick(len(value) * (2 + max(1, len(value).bit_length())))
    result = {}
    for key, arity in value.items():
        _name(key, meter)
        if type(arity) is not int or arity < 0:
            raise InputError('ARITY')
        result[key] = arity
    meter.tick(len(result) * max(1, len(result).bit_length()))
    return {key: result[key] for key in sorted(result)}


def _copy(value, meter, depth=0):
    meter.tick(1, depth)
    if type(value) is str:
        meter.tick(2 + 12 * len(value), depth)
        return value
    if value is None or type(value) is bool:
        meter.tick(4, depth); return value
    if type(value) is int:
        meter.tick(2 + (value.bit_length() * 30103) // 100000, depth)
        return value
    if type(value) is float:
        if not math.isfinite(value): raise InputError('NONFINITE')
        meter.tick(128, depth); return value
    if type(value) in (tuple, list):
        meter.tick(len(value) + 1, depth)
        return [_copy(x, meter, depth + 1) for x in value]
    if type(value) is dict:
        meter.tick(2 * len(value) + 1, depth)
        if any(type(k) is not str for k in value): raise InputError('NON_JSON_KEY')
        return {_copy(k, meter, depth + 1): _copy(v, meter, depth + 1)
                for k, v in value.items()}
    raise InputError('NON_JSON')


class _Pool:
    """Structural hash-consing plus bounded, immutable auxiliary memo values."""
    def __init__(self, meter):
        self.m = meter
        self.nodes, self.colors, self.depths, self.intern = [], [], [], {}
        self.memo = OrderedDict()
        self.transient = False

    def quote(self, text):
        self.m.tick(2 + 12 * len(text))
        return json.dumps(text, ensure_ascii=True, separators=(',', ':'))

    def node(self, row):
        self.m.tick()
        if row in self.intern:
            self.m.cache_hits += 1
            return self.intern[row]
        self.m.cache_misses += 1
        if len(self.nodes) >= self.m.limits['max_interned']:
            raise _Stop('INTERNED_LIMIT')
        tag = row[0]
        if tag in ('var', 'bot'): children = ()
        elif tag in ('fun', 'pred'): children = row[2]
        elif tag == 'all': children = (row[2],)
        else: children = row[1:]
        height = 1 + max((self.depths[i] for i in children), default=0)
        self.m.tick(len(children) + 1, height)
        if tag in ('var', 'all'):
            pieces = [self.quote(tag), self.quote(row[1])]
            if tag == 'all': pieces.append(self.colors[row[2]])
        elif tag in ('fun', 'pred'):
            args = row[2]
            self.m.tick(sum(len(self.colors[i]) + 1 for i in args))
            pieces = [self.quote(tag), self.quote(row[1]),
                      '[' + ','.join(self.colors[i] for i in args) + ']']
        elif tag == 'bot':
            pieces = [self.quote(tag)]
        else:
            pieces = [self.quote(tag)] + [self.colors[i] for i in row[1:]]
        self.m.tick(2 + sum(len(p) + 1 for p in pieces))
        color = '[' + ','.join(pieces) + ']'
        # Reserve cleanup work before a transient node can be retained.
        if self.transient: self.m.tick()
        index = len(self.nodes)
        self.nodes.append(row); self.colors.append(color); self.depths.append(height); self.intern[row] = index
        self.m.canonical_serializations += 1
        self.m.interned_nodes = len(self.nodes)
        self.m.peak_interned_nodes = max(self.m.peak_interned_nodes, len(self.nodes))
        return index

    def cached(self, key, compute):
        self.m.tick()
        if key in self.memo:
            self.m.cache_hits += 1
            self.memo.move_to_end(key)
            return self.memo[key]
        self.m.cache_misses += 1
        result = compute()
        capacity = self.m.limits['max_cache_entries']
        # During a probe, memo keys/values must never capture temporary IDs.
        if self.transient or capacity == 0: return result
        while len(self.memo) >= capacity:
            self.m.tick()
            self.memo.popitem(last=False); self.m.cache_evictions += 1
        self.memo[key] = result
        self.m.cache_entries = len(self.memo)
        self.m.cache_peak_entries = max(self.m.cache_peak_entries, len(self.memo))
        return result

    def equality_pair(self, template, hole, left, right, allowed):
        """Read-only memo, rollback-only scratch nodes; return old allowed IDs."""
        self.m.tick(); self.m.equality_probes += 1
        checkpoint = len(self.nodes)
        self.transient = True
        try:
            a = self.subst(template, hole, left)
            if a not in allowed: return None
            b = self.subst(template, hole, right)
            return (a, b) if b in allowed else None
        finally:
            # Each deletion was reserved before allocation; cleanup cannot Stop.
            for row in reversed(self.nodes[checkpoint:]): del self.intern[row]
            removed = len(self.nodes) - checkpoint
            del self.nodes[checkpoint:]; del self.colors[checkpoint:]; del self.depths[checkpoint:]
            self.m.transient_nodes_discarded += removed
            self.m.interned_nodes = checkpoint
            self.transient = False

    def ordered(self, ids):
        self.m.tick(len(ids) * max(1, len(ids).bit_length()))
        return sorted(ids, key=self.colors.__getitem__)

    def children(self, index):
        row = self.nodes[index]
        if row[0] == 'all': return (row[2],)
        if row[0] == 'not': return (row[1],)
        if row[0] in ('and', 'or', 'imp'): return row[1:]
        return ()

    def native(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag in ('var', 'bot'): return row
            if tag in ('fun', 'pred'):
                return (tag, row[1], tuple(self.native(i) for i in row[2]))
            if tag == 'all': return (tag, row[1], self.native(row[2]))
            return (tag,) + tuple(self.native(i) for i in row[1:])
        return self.cached(('native', index), make)

    def names(self, index, bound=False):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'var': return frozenset((row[1],))
            if tag == 'bot': return frozenset()
            if tag in ('fun', 'pred'):
                ids = row[2]
            elif tag == 'all':
                names = self.names(row[2], bound)
                return names | {row[1]} if bound else names - {row[1]}
            else:
                ids = row[1:]
            names = set()
            for i in ids: names.update(self.names(i, bound))
            return frozenset(names)
        return self.cached(('names', index, bound), make)

    def terms(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            result = {index} if tag in ('var', 'fun') else set()
            if tag in ('fun', 'pred'): children = row[2]
            elif tag == 'all': children = (row[2],)
            elif tag in ('var', 'bot'): children = ()
            else: children = row[1:]
            for child in children: result.update(self.terms(child))
            self.m.tick(len(result))
            return frozenset(result)
        return self.cached(('terms', index), make)

    def subst(self, index, variable, replacement):
        self.m.substitution_calls += 1
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'var': return replacement if row[1] == variable else index
            if tag == 'bot': return index
            if tag in ('fun', 'pred'):
                return self.node((tag, row[1], tuple(self.subst(i, variable, replacement) for i in row[2])))
            if tag == 'all':
                name, body = row[1], row[2]
                if name == variable or variable not in self.names(body): return index
                free_replacement = self.names(replacement)
                if name in free_replacement:
                    occupied = self.names(body, True) | free_replacement | {variable, name}
                    number = 0; fresh = 'fresh0'
                    while fresh in occupied:
                        self.m.tick(); number += 1; fresh = 'fresh' + str(number)
                    body = self.subst(body, name, self.node(('var', fresh)))
                    name = fresh
                return self.node(('all', name, self.subst(body, variable, replacement)))
            return self.node((tag,) + tuple(self.subst(i, variable, replacement) for i in row[1:]))
        return self.cached(('subst', index, variable, replacement), make)

    def contexts(self, index, hole):
        def make():
            row = self.nodes[index]; tag = row[0]; result = set()
            if tag in ('var', 'fun'):
                result.add(hole)
                if tag == 'fun':
                    for j, child in enumerate(row[2]):
                        for changed in self.contexts(child, hole):
                            args = list(row[2]); self.m.tick(len(args)); args[j] = changed
                            result.add(self.node(('fun', row[1], tuple(args))))
            elif tag == 'pred':
                for j, child in enumerate(row[2]):
                    for changed in self.contexts(child, hole):
                        args = list(row[2]); self.m.tick(len(args)); args[j] = changed
                        result.add(self.node(('pred', row[1], tuple(args))))
            elif tag == 'all':
                for changed in self.contexts(row[2], hole):
                    result.add(self.node(('all', row[1], changed)))
            elif tag != 'bot':
                for j, child in enumerate(row[1:], 1):
                    for changed in self.contexts(child, hole):
                        args = list(row); self.m.tick(len(args)); args[j] = changed
                        result.add(self.node(tuple(args)))
            self.m.tick(len(result))
            return tuple(self.ordered(result))
        return self.cached(('contexts', index, hole), make)

    def atoms(self, index):
        def make():
            row = self.nodes[index]; tag = row[0]
            if tag == 'bot': return frozenset()
            if tag not in ('not', 'and', 'or', 'imp'): return frozenset((index,))
            result = set()
            for child in row[1:]: result.update(self.atoms(child))
            self.m.tick(len(result))
            return frozenset(result)
        return self.cached(('atoms', index), make)

    def pattern(self, count, position):
        def make():
            assignments = 1 << count; run = 1 << position
            self.m.tick(assignments)
            block = (1 << run) - 1; result = 0
            for start in range(run, assignments, run * 2):
                self.m.tick(max(1, (assignments + 63) // 64))
                result |= block << start
            return result
        return self.cached(('pattern', count, position), make)

    def truth_bits(self, index, atoms):
        def make():
            row = self.nodes[index]; tag = row[0]; assignments = 1 << len(atoms)
            self.m.tick(max(1, (assignments + 63) // 64))
            full = (1 << assignments) - 1
            if tag == 'bot': return 0
            if tag == 'not': return self.truth_bits(row[1], atoms) ^ full
            if tag in ('and', 'or', 'imp'):
                left, right = self.truth_bits(row[1], atoms), self.truth_bits(row[2], atoms)
                if tag == 'and': return left & right
                if tag == 'or': return left | right
                return (left ^ full) | right
            self.m.tick(len(atoms))
            return self.pattern(len(atoms), atoms.index(index))
        return self.cached(('truth_bits', index, atoms), make)

    def tautology(self, index, maximum):
        def make():
            atoms = self.atoms(index)
            if len(atoms) > maximum: return False
            atoms = tuple(self.ordered(atoms))
            self.m.tick(max(1, ((1 << len(atoms)) + 63) // 64))
            return self.truth_bits(index, atoms) == (1 << (1 << len(atoms))) - 1
        return self.cached(('tautology', index, maximum), make)

    def bridge_tautology(self, antecedent, goal, maximum, middle=None):
        """Exact truth of a=>g or a=>(b=>g), without a bridge AST/vector."""
        self.m.tick(); self.m.bridge_tests += 1
        parts = [self.atoms(antecedent), self.atoms(goal)]
        if middle is not None: parts.append(self.atoms(middle))
        self.m.tick(sum(len(p) for p in parts))
        atoms = frozenset().union(*parts)
        if len(atoms) > maximum:
            self.m.bridge_rejections += 1
            return False
        atoms = tuple(self.ordered(atoms))
        self.m.tick(max(1, ((1 << len(atoms)) + 63) // 64))
        full = (1 << (1 << len(atoms))) - 1
        value = (self.truth_bits(antecedent, atoms) ^ full) | self.truth_bits(goal, atoms)
        if middle is not None: value |= self.truth_bits(middle, atoms) ^ full
        accepted = value == full
        if not accepted: self.m.bridge_rejections += 1
        return accepted

    def line_color(self, line):
        parts = []
        ast_fields = {'formula', 'universal', 'term', 'template', 'left', 'right', 'antecedent', 'consequent'}
        for key in sorted(line):
            value = self.colors[line[key]] if key in ast_fields else self.quote(line[key])
            self.m.tick(len(value)); parts.append(self.quote(key) + ':' + value)
        self.m.tick(sum(len(x) + 1 for x in parts) + 2)
        return '{' + ','.join(parts) + '}'

    def line_native(self, line):
        ast_fields = {'formula', 'universal', 'term', 'template', 'left', 'right', 'antecedent', 'consequent'}
        return {k: self.native(v) if k in ast_fields else v for k, v in line.items()}


def _term(value, functions, pool, depth=1):
    pool.m.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('TERM')
    if value[0] == 'var' and len(value) == 2:
        return pool.node(('var', _name(value[1], pool.m)))
    if value[0] != 'fun' or len(value) != 3:
        raise InputError('TERM_SHAPE')
    name = _name(value[1], pool.m)
    if type(value[2]) is not list or name not in functions or len(value[2]) != functions[name]:
        raise InputError('FUNCTION_ARITY')
    pool.m.tick(len(value[2]), depth)
    return pool.node(('fun', name, tuple(_term(x, functions, pool, depth + 1) for x in value[2])))


def _formula(value, functions, predicates, pool, depth=1):
    pool.m.tick(1, depth)
    if type(value) is not list or not value or type(value[0]) is not str:
        raise InputError('FORMULA')
    tag = value[0]
    if tag == 'bot' and len(value) == 1: return pool.node(('bot',))
    if tag == 'eq' and len(value) == 3:
        return pool.node(('eq', _term(value[1], functions, pool, depth + 1),
                          _term(value[2], functions, pool, depth + 1)))
    if tag == 'pred' and len(value) == 3:
        name = _name(value[1], pool.m)
        if type(value[2]) is not list or name not in predicates or len(value[2]) != predicates[name]:
            raise InputError('PREDICATE_ARITY')
        pool.m.tick(len(value[2]), depth)
        return pool.node(('pred', name, tuple(_term(x, functions, pool, depth + 1) for x in value[2])))
    if tag == 'all' and len(value) == 3:
        return pool.node(('all', _name(value[1], pool.m),
                          _formula(value[2], functions, predicates, pool, depth + 1)))
    if tag == 'not' and len(value) == 2:
        return pool.node(('not', _formula(value[1], functions, predicates, pool, depth + 1)))
    if tag in ('and', 'or', 'imp') and len(value) == 3:
        return pool.node((tag, _formula(value[1], functions, predicates, pool, depth + 1),
                          _formula(value[2], functions, predicates, pool, depth + 1)))
    raise InputError('FORMULA_SHAPE')


def _add_formula(index, formulas, pool):
    pending = [index]
    while pending:
        pool.m.tick(); current = pending.pop()
        if current in formulas: continue
        if len(formulas) >= pool.m.limits['max_basis']: raise _Stop('BASIS_LIMIT')
        formulas.add(current); pool.m.formulas = len(formulas)
        pending.extend(pool.children(current))


def _zero(line, records, formulas, pool):
    key = pool.line_color(line)
    if key in records: return
    if len(records) >= pool.m.limits['max_instances']: raise _Stop('INSTANCE_LIMIT')
    _add_formula(line['formula'], formulas, pool)
    records[key] = line; pool.m.instances = len(records)


def _inputs(theory, goal, profile, pool):
    _fields(profile, ('ui_rounds', 'bridge_arity', 'max_tautology_atoms'))
    for key, maximum in (('ui_rounds', 8), ('bridge_arity', 2), ('max_tautology_atoms', 16)):
        if type(profile[key]) is not int or not 0 <= profile[key] <= maximum: raise InputError('PROFILE')
    _fields(theory, ('functions', 'predicates', 'axioms'))
    functions, predicates = _signature(theory['functions'], pool.m), _signature(theory['predicates'], pool.m)
    if type(theory['axioms']) is not dict: raise InputError('AXIOMS')
    pool.m.tick(len(theory['axioms']))
    axioms = {}
    for name, value in theory['axioms'].items():
        _name(name, pool.m); index = _formula(value, functions, predicates, pool)
        if pool.names(index): raise InputError('OPEN_THEORY_AXIOM')
        axioms[name] = index
    goal = _formula(goal, functions, predicates, pool)
    pool.m.tick(len(axioms) * max(1, len(axioms).bit_length()))
    return {'functions': functions, 'predicates': predicates,
            'axioms': {k: axioms[k] for k in sorted(axioms)}}, goal, dict(profile)


def _formula_set(index, pool, propositional=False):
    """Finite literal formula closure; optionally stop at ALL atoms."""
    pending, found = [index], set()
    while pending:
        pool.m.tick(); current = pending.pop()
        if current in found:
            continue
        found.add(current)
        if not propositional or pool.nodes[current][0] != 'all':
            pending.extend(pool.children(current))
    return found


def _catalogue(theory, goal, profile, pool):
    # C is assertions, G is goal receptors, F is emitted formula syntax.
    # F-only UI/bridge/distribution syntax never feeds C or the fixed parameters.
    formulas, core, zero = set(), set(), {}
    pool.m.tick(len(theory['axioms']) + 1)
    for index in tuple(theory['axioms'].values()) + (goal,):
        _add_formula(index, formulas, pool)
        found = _formula_set(index, pool); pool.m.tick(len(found)); core.update(found)
    pool.m.tick(len(core)); input_core = frozenset(core)
    original_goals = _formula_set(goal, pool)
    terms0, input_variables = set(), set()
    for index in pool.ordered(input_core):
        ts = pool.terms(index); ns = pool.names(index, True)
        pool.m.tick(len(ts) + len(ns)); terms0.update(ts); input_variables.update(ns)
    pool.m.tick(len(input_variables) * max(1, len(input_variables).bit_length()))
    for name in sorted(input_variables):
        terms0.add(pool.node(('var', name)))
    terms = pool.ordered(terms0); pool.m.terms = len(terms)
    for name, index in theory['axioms'].items():
        _zero({'rule': 'axiom', 'formula': index, 'name': name}, zero, formulas, pool)
    snapshots = [('INPUT', tuple(pool.ordered(core)))]
    stages = [{'stage': 'INPUT', 'formula_count': len(formulas),
               'core_count': len(core), 'instance_count': len(zero)}]
    for number in range(profile['ui_rounds']):
        snapshot = pool.ordered(core)
        for universal in snapshot:
            row = pool.nodes[universal]; pool.m.tick()
            if row[0] != 'all':
                continue
            for term in terms:
                instance = pool.subst(row[2], row[1], term)
                found = _formula_set(instance, pool)
                pool.m.tick(len(found)); core.update(found)
                out = pool.node(('imp', universal, instance))
                _zero({'rule': 'instantiate', 'formula': out,
                       'universal': universal, 'term': term}, zero, formulas, pool)
        label = 'UI' + str(number + 1)
        snapshots.append((label, tuple(pool.ordered(core))))
        stages.append({'stage': label, 'formula_count': len(formulas),
                       'core_count': len(core), 'instance_count': len(zero)})
    pool.m.tick(len(original_goals)); goals = set(original_goals)
    for index in pool.ordered(original_goals):
        row = pool.nodes[index]; pool.m.tick()
        if row[0] == 'imp':
            for target in pool.ordered(_formula_set(row[2], pool, True)):
                receptor = pool.node(('imp', row[1], target))
                goals.add(receptor); _add_formula(receptor, formulas, pool)
    variables = set()
    for index in pool.ordered(core):
        names = pool.names(index, True); pool.m.tick(len(names)); variables.update(names)
    number = 0; hole = '__y_hole0'
    while hole in variables:
        pool.m.tick(); number += 1; hole = '__y_hole' + str(number)
    hole_id = pool.node(('var', hole)); templates = set()
    for index in pool.ordered(input_core):
        if pool.nodes[index][0] in ('eq', 'pred'):
            found = pool.contexts(index, hole_id)
            pool.m.tick(len(found)); templates.update(found)
    for term in terms:
        _zero({'rule': 'refl', 'formula': pool.node(('eq', term, term))},
              zero, formulas, pool)
    pool.m.tick(len(core)); allowed = frozenset(core)
    equalities = [index for index in pool.ordered(core) if pool.nodes[index][0] == 'eq']
    for template in pool.ordered(templates):
        for equality in equalities:
            left, right = pool.nodes[equality][1:]
            pair = pool.equality_pair(template, hole, left, right, allowed)
            if pair is not None:
                a, b = pair
                out = pool.node(('imp', equality, pool.node(('imp', a, b))))
                _zero({'rule': 'eq_subst', 'formula': out, 'variable': hole,
                       'template': template, 'left': left, 'right': right},
                      zero, formulas, pool)
    stages.append({'stage': 'EQUALITY', 'formula_count': len(formulas),
                   'core_count': len(core), 'instance_count': len(zero)})
    for universal in pool.ordered(core):
        row = pool.nodes[universal]; pool.m.tick()
        if row[0] != 'all' or pool.nodes[row[2]][0] != 'imp':
            continue
        variable = row[1]; p, q = pool.nodes[row[2]][1:]
        if variable not in pool.names(p):
            all_q = pool.node(('all', variable, q))
            out = pool.node(('imp', universal, pool.node(('imp', p, all_q))))
            _zero({'rule': 'distribute', 'formula': out, 'variable': variable,
                   'antecedent': p, 'consequent': q}, zero, formulas, pool)
    stages.append({'stage': 'DISTRIBUTION', 'formula_count': len(formulas),
                   'core_count': len(core), 'instance_count': len(zero)})
    pool.m.tick(len(core) + len(goals))
    premises = pool.ordered({i for i in core | goals if pool.nodes[i][0] != 'all'})
    for target in pool.ordered(goals):
        atoms = pool.atoms(target)
        if len(atoms) > profile['max_tautology_atoms']:
            continue  # A semantic profile bound, never a negative search result.
        eligible = []
        for premise in premises:
            pa = pool.atoms(premise); pool.m.tick(len(pa) + 1)
            if pa.issubset(atoms):
                eligible.append(premise)
        if pool.tautology(target, profile['max_tautology_atoms']):
            _zero({'rule': 'tautology', 'formula': target}, zero, formulas, pool)
        if profile['bridge_arity'] >= 1:
            for a in eligible:
                if pool.bridge_tautology(a, target, profile['max_tautology_atoms']):
                    out = pool.node(('imp', a, target))
                    _zero({'rule': 'tautology', 'formula': out}, zero, formulas, pool)
        if profile['bridge_arity'] >= 2:
            for i, a in enumerate(eligible):
                for j in range(i, len(eligible)):
                    b = eligible[j]
                    if pool.bridge_tautology(a, target, profile['max_tautology_atoms'], b):
                        out = pool.node(('imp', a, pool.node(('imp', b, target))))
                        _zero({'rule': 'tautology', 'formula': out}, zero, formulas, pool)
    stages.append({'stage': 'PROPOSITIONAL', 'formula_count': len(formulas),
                   'core_count': len(core), 'instance_count': len(zero)})
    ordered = pool.ordered(formulas)
    pool.m.tick(len(ordered)); ids = {index: i for i, index in enumerate(ordered)}
    records = []
    pool.m.tick(len(zero) * max(1, len(zero).bit_length()))
    for i, key in enumerate(sorted(zero)):
        line = zero[key]
        records.append({'id': 'i' + str(i), 'rule': line['rule'],
                        'formula_id': ids[line['formula']], 'line': pool.line_native(line)})
    mp, gen = [], []
    for i, index in enumerate(ordered):
        row = pool.nodes[index]; pool.m.tick()
        if row[0] == 'imp' and row[1] in ids and row[2] in ids:
            mp.append([i, ids[row[1]], ids[row[2]]])
        if row[0] == 'all' and row[2] in ids:
            gen.append([i, ids[row[2]], row[1]])
    stages.append({'stage': 'EXPORT', 'formula_count': len(formulas),
                   'core_count': len(core), 'instance_count': len(zero)})
    pool.m.tick(len(variables) * max(1, len(variables).bit_length()))
    basis = {'instantiation_terms': [pool.native(i) for i in terms],
             'terms': [pool.native(i) for i in terms], 'variables': sorted(variables),
             'formulas': [pool.native(i) for i in ordered],
             'colors': [pool.colors[i] for i in ordered],
             'templates': [pool.native(i) for i in pool.ordered(templates)],
             'hole': hole, 'stages': stages}
    count = sum(len(row) for name, row in snapshots) + len(core) + len(goals) + len(premises)
    pool.m.tick(count * (2 + max(1, len(ordered).bit_length())))
    generation = {'schema': 'Y-goal-receptor-universe-v1',
                  'version': IMPLEMENTATION_VERSION, 'profile': dict(profile),
                  'compiled_core_sha256': None,
                  'core_stages': [{'stage': name, 'formula_ids': sorted(ids[i] for i in row)}
                                  for name, row in snapshots],
                  'core_assertions': sorted(ids[i] for i in core),
                  'goal_receptors': sorted(ids[i] for i in goals),
                  'bridge_premises': sorted(ids[i] for i in premises), 'scope': _SCOPE}
    return basis, records, mp, gen, ids[goal], generation


def build_basis(theory, goal, profile, limits):
    started = time.perf_counter(); limits = _limits(limits); meter = _Meter(limits, started)
    try:
        meter.tick(); pool = _Pool(meter)
        theory, goal, profile = _inputs(theory, goal, profile, pool)
        basis, records, mp, gen, goal_id, generation = _catalogue(theory, goal, profile, pool)
        meter.tick(len(theory['axioms']))
        exported_theory = {'functions': theory['functions'], 'predicates': theory['predicates'],
                           'axioms': {k: pool.native(v) for k, v in theory['axioms'].items()}}
        compiled = _copy({'schema': 'V-interned-Hilbert8-basis-v1', 'version': VERSION,
                         'theory': exported_theory, 'goal': pool.native(goal), 'goal_id': goal_id,
                         'profile': profile, 'logical_basis': basis, 'zero_instances': records,
                         'mp_index': mp, 'gen_index': gen, 'costs': None, 'scope': _SCOPE}, meter)
        generation = _copy(generation, meter)
        semantic = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
        bound = _copy(semantic, meter); meter.tick(1)
        try:
            encoded = (json.dumps(bound, sort_keys=True, ensure_ascii=True,
                                 separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        except (ValueError, OverflowError) as error:
            raise _Stop('SERIALIZATION_LIMIT') from error
        generation['compiled_core_sha256'] = hashlib.sha256(encoded).hexdigest()
        meter.tick(); costs = meter.costs(); compiled['costs'] = dict(costs)
        return {'schema': 'Y-goal-receptor-basis-result-v1', 'version': IMPLEMENTATION_VERSION,
                'status': 'COMPLETE', 'reason': None, 'compiled': compiled, 'costs': costs,
                'optimization': meter.optimization(), 'generation': generation}
    except _Stop as error:
        return {'schema': 'Y-goal-receptor-basis-result-v1', 'version': IMPLEMENTATION_VERSION,
                'status': 'UNKNOWN', 'reason': str(error), 'compiled': None, 'costs': meter.costs(),
                'optimization': meter.optimization(), 'generation': None}


def _compiled(value):
    if (type(value) is not dict or value.get('schema') != 'V-interned-Hilbert8-basis-v1'
            or value.get('version') != VERSION or value.get('scope') != _SCOPE): raise InputError('COMPILED')
    return value['logical_basis'], value['zero_instances']


def _row(compiled, slot, kind, first, second=None, third=None, indexes=None):
    """Trusted complete Y catalogue to one structural U virtual candidate."""
    basis, zero = _compiled(compiled); forms, colors = basis['formulas'], basis['colors']
    if indexes is None:
        indexes = ({r[0]: r[1:] for r in compiled['mp_index']}, {r[0]: r[1:] for r in compiled['gen_index']})
    if kind == 'zero':
        if not 0 <= first < len(zero): raise InputError('INSTANCE')
        record = zero[first]; out = record['formula_id']; line = record['line']; instance = record['id']
        cid = 'r' + str(slot) + ':' + instance; uses = ()
    elif kind == 'mp':
        table = indexes[0]
        if first not in table or type(second) is not int or type(third) is not int or not 0 <= second < slot or not 0 <= third < slot:
            raise InputError('MP_REFERENCE')
        a, out = table[first]; instance = None
        line = {'rule': 'mp', 'formula': forms[out], 'antecedent': second, 'implication': third}
        cid = 'r' + str(slot) + ':mp:' + str(first) + ':' + str(second) + ':' + str(third)
        uses = ((second, a), (third, first))
    elif kind == 'gen':
        table = indexes[1]
        if first not in table or type(second) is not int or not 0 <= second < slot: raise InputError('GEN_REFERENCE')
        body, variable = table[first]; out = first; instance = None
        line = {'rule': 'generalize', 'formula': forms[out], 'source': second, 'variable': variable}
        cid = 'r' + str(slot) + ':gen:' + str(first) + ':' + str(second); uses = ((second, body),)
    else: raise InputError('ROW_KIND')
    marks = {'out:' + str(slot): colors[out]}
    for source, formula_id in uses:
        p, v = 'out:' + str(source), colors[formula_id]
        if p in marks and marks[p] != v: return None
        marks[p] = v
    candidate = {'id': cid, 't': ['slot:' + str(slot)], 'm': [[p, marks[p]] for p in sorted(marks)]}
    return candidate, {'slot': slot, 'line': line, 'instance': instance}, out


def materialize(compiled, slots, limits):
    started = time.perf_counter(); limits = _limits(limits, False); meter = _Meter(limits, started)
    if type(slots) is not int or not 1 <= slots <= 64: raise InputError('SLOTS')
    basis, zero = _compiled(compiled)
    meter.terms, meter.formulas, meter.instances = len(basis['terms']), len(basis['formulas']), len(zero)
    candidates, steps = [], {}
    try:
        meter.tick(len(compiled['mp_index']) + len(compiled['gen_index']))
        indexes = ({r[0]: r[1:] for r in compiled['mp_index']}, {r[0]: r[1:] for r in compiled['gen_index']})
        def add(row):
            meter.tick()
            if row is None: return
            candidate, step, out = row
            if step['slot'] == slots - 1 and out != compiled['goal_id']: return
            if len(candidates) >= limits['max_candidates']: raise _Stop('CANDIDATE_LIMIT')
            candidates.append(candidate); steps[candidate['id']] = step; meter.candidates = len(candidates)
        for slot in range(slots):
            for i in range(len(zero)): add(_row(compiled, slot, 'zero', i, indexes=indexes))
            for fi in range(len(basis['formulas'])):
                meter.tick()
                if fi in indexes[0]:
                    for antecedent in range(slot):
                        for implication in range(slot): add(_row(compiled, slot, 'mp', fi, antecedent, implication, indexes))
                if fi in indexes[1]:
                    for source in range(slot): add(_row(compiled, slot, 'gen', fi, source, indexes=indexes))
        old_basis = {k: v for k, v in basis.items() if k != 'colors'}
        old_zero = [{k: v for k, v in row.items() if k != 'formula_id'} for row in zero]
        bundle = _copy({'schema': 'U-finite-Hilbert8-point-model-v1', 'version': COMPAT_VERSION,
                        'theory': compiled['theory'], 'goal': compiled['goal'], 'slots': slots,
                        'profile': compiled['profile'], 'basis': old_basis, 'instances': old_zero,
                        'model': {'required': ['slot:' + str(i) for i in range(slots)], 'candidates': candidates},
                        'steps': steps, 'costs': None, 'scope': _SCOPE}, meter)
        meter.tick(); costs = meter.costs(); bundle['costs'] = {k: costs[k] for k in ('work', 'seconds', 'terms', 'formulas', 'instances', 'candidates')}
        return {'schema': 'V-Hilbert8-explicit-row-result-v1', 'version': VERSION,
                'status': 'COMPLETE', 'reason': None, 'bundle': bundle, 'costs': costs}
    except _Stop as error:
        return {'schema': 'V-Hilbert8-explicit-row-result-v1', 'version': VERSION,
                'status': 'UNKNOWN', 'reason': str(error), 'bundle': None, 'costs': meter.costs()}


def decode(compiled, slots, selected, limits):
    started = time.perf_counter(); limits = _limits(limits, False); meter = _Meter(limits, started)
    try:
        meter.tick(); _compiled(compiled)
        if type(slots) is not int or not 1 <= slots <= 64:
            raise InputError('SLOTS')
        if type(selected) is not list or len(selected) != slots:
            raise InputError('SELECTED')
        meter.tick(len(selected))
        if any(type(s) is not str for s in selected) or len(set(selected)) != slots:
            raise InputError('SELECTED')
        meter.tick(len(compiled['mp_index']) + len(compiled['gen_index']))
        indexes = ({r[0]: r[1:] for r in compiled['mp_index']},
                   {r[0]: r[1:] for r in compiled['gen_index']})
        rows = {}
        for cid in selected:
            if meter.candidates >= limits['max_candidates']:
                raise _Stop('CANDIDATE_LIMIT')
            meter.tick(len(cid) + 1)
            if len(cid) > 128:
                raise InputError('ID')
            fields = cid.split(':')
            try:
                if len(fields) < 2 or not fields[0].startswith('r'):
                    raise InputError('ID')
                slot = int(fields[0][1:])
                if not 0 <= slot < slots or slot in rows:
                    raise InputError('ROW')
                if len(fields) == 2 and fields[1].startswith('i'):
                    row = _row(compiled, slot, 'zero', int(fields[1][1:]), indexes=indexes)
                elif len(fields) == 5 and fields[1] == 'mp':
                    row = _row(compiled, slot, 'mp', int(fields[2]), int(fields[3]), int(fields[4]), indexes)
                elif len(fields) == 4 and fields[1] == 'gen':
                    row = _row(compiled, slot, 'gen', int(fields[2]), int(fields[3]), indexes=indexes)
                else:
                    raise InputError('ID')
            except ValueError as error:
                raise InputError('ID') from error
            if row is None or row[0]['id'] != cid:
                raise InputError('NONCANONICAL_OR_CONFLICTING_ID')
            if slot == slots - 1 and row[2] != compiled['goal_id']:
                raise InputError('FINAL_GOAL')
            rows[slot] = row[1]['line']; meter.candidates += 1
        proof = _copy([rows[i] for i in range(slots)], meter)
        target = _copy(compiled['goal'], meter)
        meter.tick()
        return {'status': 'UNVERIFIED_CERTIFICATE', 'proof': proof,
                'target': target, 'costs': meter.costs()}
    except _Stop as error:
        return {'status': 'UNKNOWN', 'reason': str(error), 'proof': None,
                'target': None, 'costs': meter.costs()}
