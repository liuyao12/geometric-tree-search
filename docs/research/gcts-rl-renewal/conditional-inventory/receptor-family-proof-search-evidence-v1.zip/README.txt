Y receptor-family proof-search complete evidence archive

Extract this single ordinary DEFLATE ZIP normally. MANIFEST.json maps every original absolute source path to its unique safe member, byte length and SHA256. Every original body is preserved unchanged, including inner gzip files.

Study001 is permanently UNADMITTED: its original process failed post-data guards and saved no observer terminal. All its197physical files and costs remain. Study002 is the sole primary whole admitted cohort, not a selected best-result subset. Its203physical originals remain.

Source variants, authoring notes and earlier reader/QA snapshots are provenance; only exact roles in the current plan are operative. The new finite Y universe is not unrestricted FOL/PA/Hilbert completeness or an old W/X universe speed comparison. UNKNOWN is not nonprovability, and this archive makes no RL-advantage claim.

Current14Sources/44metadata, immutable master, exact344byte bootstrap, six raw W donors, complete independent review/support/proof-transcription originals, final reader/results and local UI evidence are included. D90 binary is pinned but not vendored. Old evidence archives and unrelated old cohorts are not recursively imported.

The cut precedes this ZIP, independent package adoption and all future publication/TLS/live receipts. Those later records are kept separately to avoid circular hashes. MANIFEST.json and README.txt are the only generated special members and are excluded from original-file totals. Assembly verification is not independent content/package admission.
