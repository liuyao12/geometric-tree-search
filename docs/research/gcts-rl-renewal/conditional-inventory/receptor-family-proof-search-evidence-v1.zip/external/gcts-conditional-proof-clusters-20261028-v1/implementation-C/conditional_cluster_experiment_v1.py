"""Closed X experiment, inert until invoked by the separately owned once runner.

No IO, loader, target proof scripts, or hidden historical verification cache.
Injected modules are the exact retained Source closure. All generated positive
certificates pass the unchanged native C1 and independent FOL checker.
"""
import gzip
import hashlib
import io
import json
import time

VERSION = 'X-CONDITIONAL-CLUSTER-EXPERIMENT-v1'
REQUIRED_METADATA = ('cases', 'design', 'experiment_limits', 'donor_manifest', 'donor_admission')


def _need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def _raw(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _sha(value):
    return hashlib.sha256(_raw(value)).hexdigest()


def _copy(value):
    return json.loads(_raw(value))


def _complete(receipt, reason):
    _need(receipt['status'] == 'COMPLETE' and receipt['value'] is not None, reason)
    return receipt['value']


def _attempt_summary(row):
    """Full result lives in its artifact, never multiplied into the final JSON."""
    value = {k: v for k, v in row.items() if k != 'result'}
    if 'result' in row:
        answer = row['result']
        value['result_ref'] = row['ref']
        value['result_metadata'] = {k: answer[k] for k in
            ('reason', 'stats', 'event_extent', 'state_hashes') if k in answer}
        if 'heuristic' in answer:
            value['guidance_statistics'] = answer['heuristic']['stats']
    return value


class _Native:
    """Current-run exact-certificate memo; full byte keys, no answer caching."""
    def __init__(self, sources, limits, program, emit, budget, call):
        self.limits, self.program = limits, program
        self.emit, self.budget, self.call = emit, budget, call
        roles = ('tree_machine', 'codec', 'carrier', 'fol_checker', 'real_parser')
        self.identity = {'sources': {k: hashlib.sha256(sources[k]).hexdigest() for k in roles},
                         'program': _sha(program), 'limits': {k: limits[k] for k in
                         ('native', 'codec', 'carrier', 'checker')}}
        self.cache, self.requests, self.hits, self.execution_seconds = {}, [], 0, 0.0

    def check(self, identity, problem, proof):
        self.budget()
        started = time.perf_counter()
        key = _raw({'identity': self.identity, 'theory': problem['theory'],
                    'goal': problem['goal'], 'proof': proof})
        _need(len(self.requests) < 192, 'closed native request cap')
        if key in self.cache:
            self.hits += 1
            answer = dict(self.cache[key], cache_hit=True,
                          lookup_seconds=time.perf_counter() - started)
            self.requests.append(dict(answer, request_id=identity))
            return answer
        theory, limits, call = problem['theory'], self.limits, self.call
        encoding = call('codec', 'encode', proof, limits['codec'])
        _need(encoding['status'] == 'COMPLETE', 'complete proof-byte encoding')
        stream = bytes.fromhex(encoding['stream_hex'])
        decoding = call('codec', 'decode', stream, limits['codec'])
        _need(decoding['status'] == 'COMPLETE' and _raw(decoding['proof']) == _raw(proof),
              'complete exact independent proof-byte roundtrip')
        carrier = call('carrier', 'build_carrier', self.program, dict(theory, schemas=[]),
                       problem['goal'], len(stream), limits['carrier'], budget=self.budget)
        _need(carrier.get('value') is not None, 'complete native carrier')
        nodes = [list(n) for n in carrier['value']['nodes']]
        for row in carrier['value']['byte_rows']:
            nodes[row['node_index']][0] = stream[row['byte_index']]
        choice = call('carrier', 'verify_carrier_choice', carrier, nodes,
                      carrier['value']['input_node'], budget=self.budget)
        _need(choice['status'] == 'VERIFIED' and choice['byte_values'] == list(stream),
              'exact whole native carrier choice')
        initial_nodes = _copy(nodes)
        heap = call('tree_machine', 'Heap', nodes, limit=limits['native']['max_heap_nodes'])
        native = call('tree_machine', 'run', self.program, heap, carrier['value']['input_node'],
                      limit=limits['native']['max_steps'], keep=limits['native']['max_trace_records'])
        independent = call('fol_checker', 'check', theory, decoding['proof'],
                           problem['goal'], limits['checker'])
        accepted = (native.get('status') == 'accepted' and type(native.get('value')) is int
                    and native['value'] == 1 and independent['status'] == 'VERIFIED')
        elapsed = time.perf_counter() - started
        record = {'status': 'VERIFIED' if accepted else 'UNADMITTED_CHECKER_OUTCOME',
                  'theory': theory, 'goal': problem['goal'], 'proof': proof,
                  'encoding': encoding, 'decoding': decoding, 'carrier': carrier,
                  'initial_nodes': initial_nodes, 'choice': choice, 'native': native,
                  'final_heap': heap.nodes, 'independent': independent, 'seconds': elapsed}
        ref = self.emit(identity + '-whole-proof-check', record)
        _need(accepted, 'native C1 and independent B must both verify the entire proof')
        answer = {'status': 'VERIFIED', 'key_sha256': hashlib.sha256(key).hexdigest(),
                  'cache_hit': False, 'lookup_seconds': 0.0, 'receipt_ref': ref,
                  'first_execution_seconds': elapsed, 'proof_lines': len(proof),
                  'proof_bytes': len(stream), 'native_steps': native.get('steps')}
        self.execution_seconds += elapsed
        self.cache[key] = answer
        self.requests.append(dict(answer, request_id=identity))
        return answer


def _read_donors(context, manifest, admission, budget):
    _need(set(admission) == {'schema', 'status', 'source_admission', 'acquisition_seconds', 'donors'}
          and admission['schema'] == 'X-six-W-donor-passive-custody-v1'
          and admission['status'] == 'ADMITTED_SIX_W_DONOR_CUSTODY', 'passive admitted donor custody')
    _need(type(admission['acquisition_seconds']) in (int, float)
          and admission['acquisition_seconds'] > 0, 'historical acquisition cost retained')
    _need(admission['source_admission'] == {
        'path': '/private/tmp/gcts-scalable-proof-search-20261028-v1/root/Root-study002-complete-scientific-admission-v1.json',
        'bytes': 6808, 'sha256': '9d6b41e46607c3f513c222f0c97a122bd9a920c6c118bb2bfc826b457127189c'},
        'exact historical whole-cohort admission identity')
    expected = {r['id']: r for r in admission['donors']}
    _need(len(expected) == len(manifest['donors']) == len(context['donor_stored']) == 6,
          'six complete donor identities')
    projected, raw_join = [], []
    for row in manifest['donors']:
        budget()
        identity, ref = row['id'], row['source_ref']
        stored = context['donor_stored'][identity]
        _need(type(stored) is bytes and len(stored) == ref['bytes']
              and hashlib.sha256(stored).hexdigest() == ref['sha256'], 'whole compressed donor')
        _need(type(row['uncompressed_bytes']) is int and 0 < row['uncompressed_bytes'] <= 67108864,
              'bounded whole donor raw extent')
        with gzip.GzipFile(fileobj=io.BytesIO(stored), mode='rb') as file:
            raw = file.read(row['uncompressed_bytes'] + 1)
        _need(len(raw) == row['uncompressed_bytes']
              and hashlib.sha256(raw).hexdigest() == row['uncompressed_sha256'], 'whole decoded donor')
        data = json.loads(raw)
        _need(sorted(data) == row['keys'] and data['status'] == 'VERIFIED'
              and data['native']['status'] == 'accepted' and type(data['native']['value']) is int
              and data['native']['value'] == 1 and data['independent']['status'] == 'VERIFIED',
              'historical complete native/B receipt, provenance only')
        wanted = expected[identity]
        _need(set(wanted) == {'id', 'source_ref', 'theory_sha256', 'goal_sha256', 'proof_sha256'}
              and _raw(wanted['source_ref']) == _raw(ref)
              and all(wanted[k + '_sha256'] == _sha(data[k]) for k in ('theory', 'goal', 'proof')),
              'passive original-case donor association')
        projected.append({'id': identity, 'source_ref': ref, 'theory': data['theory'],
                          'goal': data['goal'], 'proof': data['proof']})
        raw_join.append({'id': identity, 'source_ref': ref,
                         'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                         'association': wanted})
    _need({x['id'] for x in projected} == set(expected), 'no donor omissions')
    return projected, raw_join


def _bank_controls(donors, bank, limits, invoke, emit, native):
    """Authored data controls, separate from all target proof search."""
    results = []

    def rejected(name, function, *args):
        before = _raw(args)
        receipt = invoke('bank_verifier', function, *args, limits=limits['bank_verifier'])
        _need(_raw(args) == before and receipt['status'] == 'REJECTED', 'isolated ' + name)
        ref = emit('bank-control-' + name, {'inputs': args, 'receipt': receipt})
        results.append({'id': name, 'status': receipt['status'], 'ref': ref})

    changed = _copy(donors)
    changed[0]['source_ref']['sha256'] = '0' * 64
    rejected('donor-association', 'verify_bank', changed, bank)
    for name in ('goal', 'required-axiom', 'arity', 'free-variable', 'name-collision'):
        changed = _copy(bank)
        lemma = changed['lemmas'][0]
        if name == 'goal': lemma['goal'] = ['bot']
        elif name == 'required-axiom':
            key = sorted(lemma['required_axioms'])[0]
            lemma['required_axioms'][key] = ['bot']
        elif name == 'arity':
            namespace = next(k for k in ('functions', 'predicates') if lemma['signature'][k])
            key = sorted(lemma['signature'][namespace])[0]
            lemma['signature'][namespace][key] += 1
        elif name == 'free-variable': lemma['goal'] = ['eq', ['var', 'unbound'], ['var', 'unbound']]
        else: lemma['name'] = changed['lemmas'][1]['name']
        rejected(name, 'verify_bank', donors, changed)
    changed = _copy(donors)
    first = next(line for line in changed[0]['proof'] if line['rule'] == 'axiom')
    original = first['name']; reserved = bank['lemmas'][0]['name']
    first['name'] = reserved
    changed[0]['theory']['axioms'][reserved] = changed[0]['theory']['axioms'].pop(original)
    rejected('primitive-namespace', 'verify_bank', changed, bank)

    # One direct lemma per variant: compatible extension, exact/below expansion
    # cap, full splice map, then generic repeated lemma/MP/GEN composition.
    for index, lemma in enumerate(bank['lemmas']):
        identity = 'lemma-' + str(index)
        theory = dict(_copy(lemma['signature']), axioms=_copy(lemma['required_axioms']))
        app_result = invoke('inventory', 'extend_theory', theory, bank, limits['extend'])
        application = _complete(app_result, 'control extension complete')
        verified = invoke('bank_verifier', 'verify_extension', theory, bank, application,
                          limits=limits['bank_verifier'])
        _need(verified['status'] == 'VERIFIED', 'independent control extension')
        direct = [{'rule': 'axiom', 'name': lemma['name'], 'formula': lemma['goal']}]
        lower_result = invoke('inventory', 'lower_proof', theory, bank, application, direct, limits['lower'])
        lowered = _complete(lower_result, 'direct lemma lowering')
        lower_check = invoke('bank_verifier', 'verify_lowering', theory, bank, application,
                             direct, lowered, limits=limits['bank_verifier'])
        _need(lower_check['status'] == 'VERIFIED', 'direct complete lowering map')
        tight = dict(limits['lower'], max_primitive_lines=len(lowered['proof']))
        exact = invoke('inventory', 'lower_proof', theory, bank, application, direct, tight)
        _need(exact['status'] == 'COMPLETE' and _raw(exact['value']) == _raw(lowered), 'exact expansion cap')
        below = invoke('inventory', 'lower_proof', theory, bank, application, direct,
                       dict(tight, max_primitive_lines=len(lowered['proof']) - 1))
        _need(below['status'] == 'UNKNOWN' and below['value'] is None, 'below cap no partial proof')
        problem = {'theory': theory, 'goal': lemma['goal']}
        bank_check = native.check('bank-' + identity, problem, lemma['proof'])
        formula = lemma['goal']
        coarse = direct + _copy(direct) + [
            {'rule': 'tautology', 'formula': ['imp', formula, formula]},
            {'rule': 'mp', 'antecedent': 1, 'implication': 2, 'formula': formula},
            {'rule': 'generalize', 'source': 3, 'variable': 'clusterControl',
             'formula': ['all', 'clusterControl', formula]}]
        composite = invoke('inventory', 'lower_proof', theory, bank, application, coarse, limits['lower'])
        composite_value = _complete(composite, 'generic MP/GEN lowering control')
        composite_check = invoke('bank_verifier', 'verify_lowering', theory, bank, application,
                                 coarse, composite_value, limits=limits['bank_verifier'])
        _need(composite_check['status'] == 'VERIFIED', 'generic MP/GEN lowering map')
        coarse_native = native.check('bank-' + identity + '-composite-coarse',
            {'theory': application['theory'], 'goal': coarse[-1]['formula']}, coarse)
        original_native = native.check('bank-' + identity + '-composite-original',
            {'theory': theory, 'goal': composite_value['goal']}, composite_value['proof'])
        positive = {'theory': theory, 'extension': app_result, 'extension_check': verified,
                    'direct': direct, 'lowering': lower_result, 'lowering_check': lower_check,
                    'exact_cap': exact, 'below_cap': below, 'primitive_check': bank_check,
                    'composite': coarse, 'composite_lowering': composite,
                    'composite_check': composite_check, 'coarse_native': coarse_native,
                    'original_native': original_native}
        results.append({'id': identity, 'status': 'VERIFIED',
                        'ref': emit('bank-control-' + identity + '-positive', positive)})
        if index == 0:
            zero = invoke('inventory', 'lower_proof', theory, bank, application, direct,
                          dict(limits['lower'], max_work=0))
            _need(zero['status'] == 'UNKNOWN' and zero['value'] is None, 'lowering work preflight')
            results.append({'id': 'lower-zero-work', 'status': 'UNKNOWN',
                            'ref': emit('bank-control-lower-zero-work', zero)})
            altered = _copy(application); altered['bank_sha256'] = '0' * 64
            rejected('stale-bank', 'verify_extension', theory, bank, altered)
            altered = _copy(application); altered['theory']['axioms'][lemma['name']] = ['bot']
            rejected('extension-formula', 'verify_extension', theory, bank, altered)
            altered = _copy(lowered); altered['goal'] = ['bot']
            rejected('changed-lowered-goal', 'verify_lowering', theory, bank, application, direct, altered)
            altered = _copy(lowered)
            # The direct pruned bank may itself have one row; use a definitely
            # out-of-range reference, independently of observed proof size.
            altered['coarse_to_primitive'][0] = 64
            rejected('splice-offset', 'verify_lowering', theory, bank, application, direct, altered)
            altered = _copy(composite_value); altered['proof'][-1]['source'] = 64
            rejected('forward-reference', 'verify_lowering', theory, bank, application, coarse, altered)
            altered_theory = _copy(theory)
            key = sorted(altered_theory['axioms'])[0]; altered_theory['axioms'][key] = ['bot']
            rejected('changed-original-theory', 'verify_lowering', altered_theory, bank, application, direct, lowered)
            altered = _copy(composite_value); altered['proof'][-1]['formula'][1] = 'differentBinder'
            rejected('false-bound-sharing', 'verify_lowering', theory, bank, application, coarse, altered)
    for role, function, args, cap in (
        ('inventory', 'build_bank', (donors,), limits['bank']),
        ('inventory', 'mine_patterns', (bank,), limits['mine'])):
        result = invoke(role, function, *args, dict(cap, max_work=0))
        _need(result['status'] == 'UNKNOWN' and result['value'] is None, 'owned work refusal no partial value')
        results.append({'id': function + '-zero-work', 'status': 'UNKNOWN',
                        'ref': emit('bank-control-' + function.replace('_', '-') + '-zero-work', result)})
    sentinel = RuntimeError('X controlled foreign charge sentinel')
    def fail_charge(units):
        raise sentinel
    try:
        invoke('inventory', 'build_bank', donors, limits['bank'], charge=fail_charge)
    except RuntimeError as error:
        _need(error is sentinel, 'foreign charge identity propagates')
    else:
        raise RuntimeError('foreign charge was hidden')
    results.append({'id': 'foreign-charge', 'status': 'PROPAGATED_IDENTICAL_SENTINEL'})
    return results


def run(modules, context, emit, budget, call):
    """Run the entire prospective cohort; exceptions invalidate the whole run."""
    started = time.perf_counter()
    _need(type(context) is dict and set(context) == {'plan', 'sources', 'metadata', 'donor_stored'},
          'closed experiment context')
    metadata = context['metadata']
    _need(all(k in metadata for k in REQUIRED_METADATA), 'complete metadata roles')
    cases, design, limits, manifest, admission = (json.loads(metadata[k]) for k in REQUIRED_METADATA)
    _need(len(metadata['cases']) == design['cases']['bytes']
          and hashlib.sha256(metadata['cases']).hexdigest() == design['cases']['sha256'],
          'exact prospective assertion bytes')
    _need(len(cases) == 15 and len(design['train']) == 3 and len(design['heldout']) == 12
          and len(design['training_episode_order']) == 6 and design['training_search_seconds'] == 1
          and design['evaluation_search_seconds_per_lane'] == 2
          and set(cases) == set(design['train'] + design['heldout']), 'closed input-only cohort')
    _need(design['lanes'] == ['POINT_LEX', 'POINT_UNIFORM_CLUSTERS', 'POINT_LEARNED_CLUSTERS',
                             'SAME_INVENTORY_SHARED_DAG'], 'four same-information lanes')
    case_image = _raw(cases)
    def charge(units):
        _need(type(units) is int and units >= 0, 'nonnegative owned charge')
        budget()
    def invoke(role, name, *args, **kwargs):
        if role in ('inventory', 'bank_verifier'):
            kwargs.setdefault('charge', charge)
        return call(role, name, *args, **kwargs)
    donors, donor_join = _read_donors(context, manifest, admission, budget)
    donor_image = _raw(donors)
    emit('six-historical-donor-projections', {'donors': donors, 'joins': donor_join,
         'admission': admission, 'fresh_native_memo': True})
    prepare = time.perf_counter()
    program = call('tree_machine', 'Compiler', context['sources']['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    program_ref = emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - prepare
    native = _Native(context['sources'], limits, program, emit, budget, call)
    bank_result = invoke('inventory', 'build_bank', donors, limits['bank'])
    bank = _complete(bank_result, 'complete six-donor bank')
    _need(len(bank['donors']) == 6 and len(bank['lemmas']) == 4, 'six donors and four distinct scoped lemmas')
    bank_check = invoke('bank_verifier', 'verify_bank', donors, bank, limits=limits['bank_verifier'])
    _need(bank_check['status'] == 'VERIFIED', 'independent whole bank reconstruction')
    emit('complete-lemma-bank', {'result': bank_result, 'independent': bank_check})
    bank_image = _raw(bank)
    controls = _bank_controls(donors, bank, limits, invoke, emit, native)
    _need(_raw(donors) == donor_image and _raw(bank) == bank_image, 'all bank controls preserve originals')
    patterns_result = invoke('inventory', 'mine_patterns', bank, limits['mine'])
    patterns = _complete(patterns_result, 'complete automatic donor DAG mining')
    emit('automatically-mined-patterns', patterns_result)
    qualification_checks, qualification_records = [], []
    def qualification_emit(name, data):
        identity = 'guidance-qualification-' + name.replace('_', '-')
        ref = emit(identity, data)
        qualification_records.append({'id': name, 'ref': ref})
        selected = []
        if name.startswith('NOHOOK-'):
            selected = [(lane, data[lane]['selection']) for lane in ('point', 'baseline')]
        elif name.startswith('PROPOSAL-') or name.startswith('ZERO-'):
            selected = [('point', data['run']['selection'])]
        for lane, selection in selected:
            if selection is not None:
                proof = selection['proof']
                qualification_checks.append({'id': name, 'lane': lane,
                    'check': native.check(identity + '-' + lane, data['problem'], proof)})
    qualification = call('xqualifier', 'qualify', modules['compiler'], modules['xengine'],
        modules['engine'], modules['independent'], modules['graph_audit'], qualification_emit)
    _need(qualification['status'] == 'PASS' and len(qualification_records) == 24
          and len(qualification_checks) == 23, 'complete guidance qualification and all native positives')
    emit('complete-guidance-qualification', {'result': qualification, 'records': qualification_records,
                                            'native_checks': qualification_checks})
    initial = call('policy', 'initial_state', patterns, limits['policy'])
    state = _complete(initial, 'initial policy state')
    initial_state = _copy(state)
    emit('initial-policy-state', initial)
    prepared_cases = {}

    def prepare_case(identity):
        if identity in prepared_cases:
            return prepared_cases[identity]
        budget()
        given = cases[identity]
        t = time.perf_counter()
        extension = invoke('inventory', 'extend_theory', given['theory'], bank, limits['extend'])
        item = {'id': identity, 'original': given, 'slots': design['slots'][identity],
                'extension': extension, 'status': 'UNKNOWN_EXTENSION'}
        if extension['status'] == 'COMPLETE':
            application = extension['value']
            check = invoke('bank_verifier', 'verify_extension', given['theory'], bank, application,
                           limits=limits['bank_verifier'])
            _need(check['status'] == 'VERIFIED', 'independent target extension')
            problem = {'theory': application['theory'], 'goal': given['goal'],
                       'profile': design['generation_profile']}
            before = time.perf_counter()
            built = call('compiler', 'build_basis', problem['theory'], problem['goal'],
                         problem['profile'], limits['basis'])
            item.update(application=application, extension_check=check, problem=problem,
                        build=built, build_seconds=time.perf_counter() - before,
                        status='UNKNOWN_BUILD')
            item['build_ref'] = emit(identity + '-complete-build', built)
            if built['status'] == 'COMPLETE':
                compiled = built['compiled']
                audit = call('independent', 'verify_compiled', problem, compiled,
                             limits=limits['independent'])
                _need(audit['status'] == 'VERIFIED', 'whole shared compiled catalogue')
                item.update(status='COMPLETE', compiled=compiled, compiled_sha256=_sha(compiled),
                            compiled_audit=audit)
            else:
                _need(built['status'] == 'UNKNOWN' and built['compiled'] is None,
                      'no incomplete catalogue prefix')
        else:
            _need(extension['status'] == 'UNKNOWN' and extension['value'] is None,
                  'no incomplete extension prefix')
        item['preparation_seconds'] = time.perf_counter() - t
        saved = {k: v for k, v in item.items() if k not in ('compiled', 'build')}
        if 'build' in item:
            saved['build'] = {k: item['build'][k] for k in ('status', 'reason', 'costs', 'optimization')}
        item['preparation_ref'] = emit(identity + '-shared-preparation', saved)
        prepared_cases[identity] = item
        return item

    def positive(identity, item, proof):
        coarse_check = native.check(identity + '-coarse', item['problem'], proof)
        before = time.perf_counter()
        lower = invoke('inventory', 'lower_proof', item['original']['theory'], bank,
                       item['application'], proof, limits['lower'])
        answer = {'coarse_proof': proof, 'coarse_check': coarse_check, 'lowering': lower,
                  'lowering_seconds': time.perf_counter() - before,
                  'original_status': 'UNKNOWN_LOWERING', 'verified': False}
        if lower['status'] == 'COMPLETE':
            value = lower['value']
            audit = invoke('bank_verifier', 'verify_lowering', item['original']['theory'], bank,
                           item['application'], proof, value, limits=limits['bank_verifier'])
            _need(audit['status'] == 'VERIFIED', 'independent full original-theory lowering')
            _need(_raw(value['theory']) == _raw(item['original']['theory'])
                  and _raw(value['goal']) == _raw(item['original']['goal']), 'exact original target')
            checked = native.check(identity + '-original', item['original'], value['proof'])
            answer.update(original_status='VERIFIED', verified=True, lowering_audit=audit,
                          original_check=checked, original_proof=value['proof'])
        else:
            _need(lower['status'] == 'UNKNOWN' and lower['value'] is None,
                  'owned lowering refusal only; logical rejection is not an episode')
        answer['ref'] = emit(identity + '-whole-positive-transformation', answer)
        return answer

    def point_run(identity, item, mode, seed, policy_state, wall):
        row = {'id': identity, 'mode': mode, 'seed': seed, 'status': item['status'],
               'preparation_ref': item['preparation_ref'], 'verified': False}
        if item['status'] != 'COMPLETE':
            row['status'] = 'NOT_RUN_' + item['status']
            return row
        compiled, slots = item['compiled'], item['slots']
        policy_before = _raw(policy_state)
        planner, factory = None, None
        before = time.perf_counter()
        if mode != 'lex':
            config = _copy(limits['planner'])
            if mode != 'train': config['epsilon'] = 0
            planner, factory = call('policy', 'make_proposer', compiled, slots, patterns,
                                   modules['inventory'], policy_state, mode, seed, config)
            _need(factory['status'] in ('COMPLETE', 'UNKNOWN')
                  and (factory['status'] == 'COMPLETE' or planner is None), 'optional factory refusal')
        answer = call('xengine', 'solve', compiled, slots, dict(limits['point'], wall_seconds=wall),
                      propose=planner, proposal_limits=limits['proposal'])
        elapsed = time.perf_counter() - before
        _need(answer['status'] in ('SAT', 'UNSAT', 'UNKNOWN'), 'explicit complete point status')
        if answer['entry_state'] is not None:
            _need(_raw(answer['entry_state']) == _raw(answer['restored_state'])
                  and _sha(answer['entry_state']) == answer['state_hashes']['entry']
                  == answer['state_hashes']['restored'], 'full point restoration')
        _need(answer['stats']['trail_writes'] == answer['stats']['trail_undos'], 'mandatory trail cleanup')
        summary = call('policy', 'summarize', planner) if planner is not None else None
        _need(_raw(policy_state) == policy_before and _sha(compiled) == item['compiled_sha256'],
              'search preserves frozen policy and shared compiled input')
        row.update(status=answer['status'], result=answer, search_seconds=elapsed,
                   factory=factory, summary=summary)
        if answer['status'] == 'SAT':
            audit = call('independent', 'verify_selection', item['problem'], compiled, slots,
                         answer['selected'], limits=limits['independent'])
            _need(audit['status'] == 'VERIFIED', 'complete selected coarse tiling')
            decoded = call('compiler', 'decode', compiled, slots, answer['selected'])
            _need(decoded['status'] == 'UNVERIFIED_CERTIFICATE'
                  and _raw(decoded['proof']) == _raw(audit['proof']), 'independent coarse proof equality')
            row.update(selection_audit=audit, decoded=decoded,
                       positive=positive(identity, item, decoded['proof']))
            row['verified'] = row['positive']['verified']
        row['ref'] = emit(identity + '-full-point-attempt', row)
        return row

    training = []
    for episode_index, case_id in enumerate(design['training_episode_order']):
        budget()
        identity = 'training-' + str(episode_index) + '-' + case_id
        item = prepare_case(case_id)
        state_before = _copy(state)
        row = point_run(identity, item, 'train', 1000 + episode_index, state, 1)
        update = None
        if row.get('summary') is not None:
            update = call('policy', 'update_policy', state, identity, row['result'], row['summary'],
                          row['verified'], limits['policy'])
            _need(_raw(state) == _raw(state_before), 'functional policy update preserves input')
            if update['status'] == 'COMPLETE':
                state = update['value']['state']
            else:
                _need(update['status'] == 'UNKNOWN' and update['value'] is None, 'owned update refusal')
        record = {'episode': episode_index, 'case_id': case_id, 'attempt': _attempt_summary(row),
                  'state_before': state_before, 'update': update, 'state_after': _copy(state)}
        record['ref'] = emit(identity + '-complete-episode', record)
        training.append(record)
    frozen_policy = _copy(state)
    frozen_sha = _sha(state)
    for item in prepared_cases.values():
        if item['status'] == 'COMPLETE':
            _need(_sha(item['compiled']) == item['compiled_sha256'], 'training compiled postguard')
            item['compiled'] = None; item['build'] = None; item['compiled_released'] = True
    emit('frozen-heldout-policy', {'state': state, 'sha256': frozen_sha,
                                 'training_episodes': len(training)})
    evaluation = []
    for case_index, case_id in enumerate(design['heldout']):
        budget()
        item = prepare_case(case_id)
        lanes = {}
        for lane, mode in (('POINT_LEX', 'lex'), ('POINT_UNIFORM_CLUSTERS', 'uniform'),
                           ('POINT_LEARNED_CLUSTERS', 'trained')):
            identity = case_id + '-' + lane.lower().replace('_', '-')
            lanes[lane] = _attempt_summary(point_run(identity, item, mode, 2000 + case_index, frozen_policy, 2))
            _need(_sha(frozen_policy) == frozen_sha, 'no heldout policy update')
        identity = case_id + '-same-inventory-shared-dag'
        control = {'id': identity, 'status': 'NOT_RUN_' + item['status'], 'verified': False,
                   'preparation_ref': item['preparation_ref']}
        if item['status'] == 'COMPLETE':
            before = time.perf_counter()
            answer = call('independent', 'backward_dag', item['problem'], item['compiled'],
                          item['slots'], limits['control'])
            control.update(status=answer['status'], result=answer, search_seconds=time.perf_counter() - before)
            _need(answer['status'] in ('DERIVABLE', 'NOT_DERIVABLE', 'UNKNOWN'), 'finite control status')
            if answer['status'] == 'DERIVABLE':
                control['positive'] = positive(identity, item, answer['proof'])
                control['verified'] = control['positive']['verified']
            _need(_sha(item['compiled']) == item['compiled_sha256'], 'control preserves shared compiled universe')
        control['ref'] = emit(identity + '-full-control-attempt', control)
        lanes['SAME_INVENTORY_SHARED_DAG'] = _attempt_summary(control)
        record = {'id': case_id, 'original': item['original'], 'slots': item['slots'],
                  'preparation_ref': item['preparation_ref'], 'lanes': lanes,
                  'frozen_policy_sha256': frozen_sha}
        record['ref'] = emit(case_id + '-whole-heldout-case', record)
        evaluation.append(record)
        if item['status'] == 'COMPLETE':
            _need(_sha(item['compiled']) == item['compiled_sha256'], 'heldout compiled postguard')
            item['compiled'] = None; item['build'] = None; item['compiled_released'] = True
    _need(len(training) == 6 and len(evaluation) == 12 and len(prepared_cases) == 15
          and _raw(cases) == case_image and _raw(donors) == donor_image
          and _raw(bank) == bank_image and _sha(frozen_policy) == frozen_sha, 'whole-cohort and input postguards')
    _need(_sha(program) == native.identity['program']
          and all(item['status'] != 'COMPLETE' or item.get('compiled_released') is True
                  for item in prepared_cases.values()), 'all retained compiled/native input postguards')
    return {'schema': 'X-conditional-cluster-experiment-v1', 'version': VERSION, 'status': 'COMPLETE',
            'limits': limits, 'design': design, 'donor_custody': donor_join,
            'historical_acquisition_seconds': admission['acquisition_seconds'],
            'native_program': program_ref, 'native_preparation_seconds': native_preparation_seconds,
            'bank': bank_result, 'bank_check': bank_check, 'bank_controls': controls,
            'patterns': patterns_result, 'qualification': qualification,
            'qualification_checks': qualification_checks, 'initial_policy': initial_state,
            'training': training, 'frozen_policy': frozen_policy, 'evaluation': evaluation,
            'native_memo': {'requests': native.requests, 'request_count': len(native.requests),
                            'hits': native.hits, 'executions': len(native.cache),
                            'execution_seconds': native.execution_seconds,
                            'scope': 'Empty at entry; exact full current theory/goal/proof/kernel identity only.'},
            'seconds': time.perf_counter() - started,
            'scope': 'Six historical primitive certificates/four scoped lemmas; acquired information and costs disclosed. '
                     'Six arithmetic training episodes, twelve heldouts/four same-inventory coarse lanes. '
                     'Automatically mined bounded donor DAG patterns and episodic contextual bandit; validated '
                     'individual ordering/continuations with mandatory scheduler and complete base fallback, no atomic macro. '
                     'Coarse line bounds are not primitive-equivalent; every claimed positive also needs <=64-line '
                     'original-theory native C1+B verification. All incomplete builds/searches/lowerings retained. '
                     'No RL benefit, GCTS superiority, novel theorem, full PA/Hilbert or universal literal Wang claim.'}
