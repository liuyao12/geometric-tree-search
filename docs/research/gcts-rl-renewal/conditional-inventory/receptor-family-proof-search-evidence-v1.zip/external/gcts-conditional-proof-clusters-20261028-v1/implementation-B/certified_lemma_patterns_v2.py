"""Inert certified-lemma transformations and donor-DAG cluster proposals.

No project imports, IO, proof/solver execution or module-body scientific calls.
COMPLETE is a data-transformation outcome, not a logical validity certificate.
Root must independently check donors/bank/lowering and final original-theory
native C1+B proofs. Proposal lists never define base candidate completeness.
"""
import hashlib
import itertools
import json
import math
import re
import time
from types import MappingProxyType

VERSION = 'X-CERTIFIED-LEMMA-PATTERNS-v1'
RULES = frozenset(('axiom', 'tautology', 'refl', 'instantiate', 'distribute',
                   'eq_subst', 'mp', 'generalize'))
RESULT_SCHEMA = 'X-lemma-pattern-result-v1'
BANK_SCHEMA = 'X-certified-primitive-lemma-bank-v1'
PATTERN_SCHEMA = 'X-donor-DAG-patterns-v1'


class InputError(ValueError):
    pass


class _Stop(Exception):
    pass


def _need(ok, reason):
    if not ok:
        raise InputError(reason)


def _fields(value, fields):
    _need(type(value) is dict and len(value) == len(fields)
          and all(type(k) is str for k in value) and set(value) == set(fields), 'FIELDS')


class _Meter:
    def __init__(self, limits, kind, charge):
        self.start = time.perf_counter()
        caps = {'max_work': 1000000000, 'max_depth': 128}
        extra = {'bank': {'max_donors': 64, 'max_lines': 64},
                 'extend': {'max_lemmas': 1024},
                 'lower': {'max_primitive_lines': 64},
                 'mine': {'max_patterns': 10000, 'max_subsets': 10000000},
                 'prepare': {'max_patterns': 10000, 'max_definitions': 1000000},
                 'propose': {'max_packets': 256, 'max_alignments': 1000000,
                             'max_matches': 1000000}}
        caps.update(extra[kind]); _fields(limits, tuple(caps) + ('wall_seconds',))
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60 and math.isfinite(wall), 'WALL')
        for key, maximum in caps.items():
            _need(type(limits[key]) is int and 0 <= limits[key] <= maximum, 'LIMIT_INTEGER')
        _need(charge is None or callable(charge), 'CHARGE')
        self.limits, self.charge, self.work = dict(limits), charge, 0

    def tick(self, n=1, depth=0):
        if depth > self.limits['max_depth']:
            raise _Stop('DEPTH')
        if n > self.limits['max_work'] - self.work:
            raise _Stop('WORK')
        self.work += n
        if self.charge is not None:
            self.charge(n)
        if time.perf_counter() - self.start >= self.limits['wall_seconds']:
            raise _Stop('WALL')

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Own validation/copy/hash/construction and caller charge callbacks; '
                         'cooperative logical work/wall, not hard OS time/RAM; '
                         'caller serialization and module load excluded.'}


def _clone(value, m, depth=0):
    m.tick(1, depth)
    if value is None or type(value) is bool:
        m.tick(4, depth)  # Together with entry: reserve null/false wire bytes.
        return value
    if type(value) is int:
        _need(value.bit_length() <= 256, 'INTEGER')
        m.tick(79, depth)  # Signed 256-bit decimal needs at most 79 bytes.
        return value
    if type(value) is float:
        _need(math.isfinite(value), 'FINITE')
        m.tick(128, depth)  # Conservative finite binary64 JSON spelling.
        return value
    if type(value) is str:
        m.tick(2 + 12 * len(value), depth)
        return value
    if type(value) is list:
        m.tick(len(value) + 1, depth)  # Brackets and commas before allocation.
        return [_clone(v, m, depth + 1) for v in value]
    _need(type(value) is dict, 'JSON')
    m.tick(2 * len(value) + 1, depth)  # Keys/values punctuation and key scan.
    _need(all(type(k) is str for k in value), 'JSON')
    return {_clone(k, m, depth + 1): _clone(v, m, depth + 1) for k, v in value.items()}


def _wire(value, m):
    copied = _clone(value, m)
    # _clone reserves every scalar plus container punctuation before raw growth.
    m.tick(1)  # Final LF, completing the conservative full canonical wire bound.
    raw = (json.dumps(copied, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
    return raw


def _digest(value, m):
    return hashlib.sha256(_wire(value, m)).hexdigest()


def _done(value, m, reason=None):
    copied = _clone(value, m)
    costs = m.costs()
    if type(copied) is dict and copied.get('schema') == BANK_SCHEMA:
        copied['costs'] = dict(costs)
    return {'schema': RESULT_SCHEMA, 'status': 'COMPLETE', 'reason': reason,
            'value': copied, 'costs': costs}


def _unknown(error, m):
    return {'schema': RESULT_SCHEMA, 'status': 'UNKNOWN', 'reason': str(error),
            'value': None, 'costs': m.costs()}


def _name(x, m):
    m.tick()
    _need(type(x) is str and 1 <= len(x) <= 64, 'NAME')
    m.tick(len(x))
    _need(all(32 <= ord(c) <= 126 for c in x), 'NAME_ASCII')
    return x


def _signature(x, m):
    _need(type(x) is dict, 'SIGNATURE')
    m.tick(len(x) * (2 + max(1, len(x).bit_length())))
    result = {}
    for name, arity in x.items():
        _name(name, m)
        _need(type(arity) is int and arity >= 0, 'ARITY')
        result[name] = arity
    m.tick(len(result))
    return {k: result[k] for k in sorted(result)}


def _term(x, theory, used, m, depth=1):
    m.tick(1, depth)
    _need(type(x) is list and x and type(x[0]) is str, 'TERM')
    if x[0] == 'var' and len(x) == 2:
        return {_name(x[1], m)}
    _need(x[0] == 'fun' and len(x) == 3 and type(x[2]) is list, 'TERM_SHAPE')
    name = _name(x[1], m); m.tick(len(x[2]))
    _need(name in theory['functions'] and len(x[2]) == theory['functions'][name], 'FUNCTION_ARITY')
    used['functions'][name] = len(x[2]); free = set()
    for child in x[2]:
        free.update(_term(child, theory, used, m, depth + 1))
    return free


def _formula(x, theory, used, m, depth=1):
    m.tick(1, depth)
    _need(type(x) is list and x and type(x[0]) is str, 'FORMULA')
    tag = x[0]
    if tag == 'bot' and len(x) == 1:
        return set()
    if tag == 'eq' and len(x) == 3:
        return _term(x[1], theory, used, m, depth + 1) | _term(x[2], theory, used, m, depth + 1)
    if tag == 'pred' and len(x) == 3 and type(x[2]) is list:
        name = _name(x[1], m); m.tick(len(x[2]))
        _need(name in theory['predicates'] and len(x[2]) == theory['predicates'][name], 'PREDICATE_ARITY')
        used['predicates'][name] = len(x[2]); free = set()
        for child in x[2]:
            free.update(_term(child, theory, used, m, depth + 1))
        return free
    if tag == 'all' and len(x) == 3:
        return _formula(x[2], theory, used, m, depth + 1) - {_name(x[1], m)}
    if tag == 'not' and len(x) == 2:
        return _formula(x[1], theory, used, m, depth + 1)
    if tag in ('and', 'or', 'imp') and len(x) == 3:
        return _formula(x[1], theory, used, m, depth + 1) | _formula(x[2], theory, used, m, depth + 1)
    raise InputError('FORMULA_SHAPE')


def _theory(x, m):
    _fields(x, ('functions', 'predicates', 'axioms'))
    out = {'functions': _signature(x['functions'], m),
           'predicates': _signature(x['predicates'], m), 'axioms': {}}
    _need(type(x['axioms']) is dict, 'AXIOMS')
    m.tick(len(x['axioms']) * (2 + max(1, len(x['axioms']).bit_length())))
    _need(all(type(k) is str for k in x['axioms']), 'AXIOMS')
    for name in sorted(x['axioms']):
        _name(name, m)
        _need(not _formula(x['axioms'][name], out, {'functions': {}, 'predicates': {}}, m),
              'CLOSED_THEORY_AXIOM')
        out['axioms'][name] = _clone(x['axioms'][name], m)
    return out


def _refs(line):
    if line['rule'] == 'mp':
        return ('antecedent', 'implication')
    if line['rule'] == 'generalize':
        return ('source',)
    return ()


def _proof(proof, theory, m, cap=64):
    _need(type(proof) is list and proof, 'PROOF')
    if len(proof) > cap:
        raise _Stop('PROOF_LINES')
    used = {'functions': {}, 'predicates': {}}
    fields = {'axiom': ('name',), 'tautology': (), 'refl': (),
              'instantiate': ('universal', 'term'),
              'distribute': ('variable', 'antecedent', 'consequent'),
              'eq_subst': ('variable', 'template', 'left', 'right'),
              'mp': ('antecedent', 'implication'), 'generalize': ('source', 'variable')}
    terms = {'instantiate': ('term',), 'eq_subst': ('left', 'right')}
    formulas = {'instantiate': ('universal',), 'distribute': ('antecedent', 'consequent'),
                'eq_subst': ('template',)}
    for i, line in enumerate(proof):
        m.tick(); _need(type(line) is dict and type(line.get('rule')) is str
                        and line['rule'] in RULES, 'RULE')
        rule = line['rule']; _fields(line, ('rule', 'formula') + fields[rule])
        _formula(line['formula'], theory, used, m)
        for key in _refs(line):
            _need(type(line[key]) is int and 0 <= line[key] < i, 'STRICT_PRIOR')
        for key in terms.get(rule, ()):
            _term(line[key], theory, used, m)
        for key in formulas.get(rule, ()):
            _formula(line[key], theory, used, m)
        if 'variable' in line:
            _name(line['variable'], m)
        if rule == 'axiom':
            _name(line['name'], m)
            _need(line['name'] in theory['axioms']
                  and _wire(line['formula'], m) == _wire(theory['axioms'][line['name']], m),
                  'EXACT_NAMED_AXIOM')
    for kind in used:
        m.tick(len(used[kind]) * (2 + max(1, len(used[kind]).bit_length())))
    return {k: {name: used[k][name] for name in sorted(used[k])} for k in used}


def _reachable(proof, root, m):
    pending, seen = [root], set()
    while pending:
        m.tick(); i = pending.pop()
        if i in seen:
            continue
        seen.add(i)
        pending.extend(proof[i][key] for key in _refs(proof[i]))
    m.tick(len(seen))
    return sorted(seen)


def _normalize(proof, m, cap=64):
    keep = _reachable(proof, len(proof) - 1, m)
    emitted, origins, remap, seen = [], [], {}, {}
    for i in keep:
        line = _clone(proof[i], m)
        for key in _refs(line):
            line[key] = remap[line[key]]
        color = _wire(line['formula'], m)
        if color in seen:
            remap[i] = seen[color]
        else:
            if len(emitted) >= cap:
                raise _Stop('PRIMITIVE_LINES')
            remap[i] = len(emitted); seen[color] = len(emitted)
            emitted.append(line); origins.append(i)
    final = _reachable(emitted, remap[len(proof) - 1], m)
    new = {old: i for i, old in enumerate(final)}
    output = []
    for old in final:
        line = _clone(emitted[old], m)
        for key in _refs(line):
            line[key] = new[line[key]]
        output.append(line)
    mapping = [new.get(remap.get(i)) for i in range(len(proof))]
    return output, mapping, [origins[i] for i in final]


def _variant(goal, signature, axioms):
    return {'goal': goal, 'signature': signature, 'required_axioms': axioms}


def _bank_core(bank):
    return {k: bank[k] for k in ('schema', 'version', 'donors', 'lemmas')}


def _check_bank(bank, m):
    _fields(bank, ('schema', 'version', 'donors', 'lemmas', 'bank_sha256', 'costs'))
    _need(bank['schema'] == BANK_SCHEMA and bank['version'] == VERSION, 'BANK_VERSION')
    _need(type(bank['donors']) is list and type(bank['lemmas']) is list, 'BANK_ARRAYS')
    _need(bank['bank_sha256'] == _digest(_bank_core(bank), m), 'BANK_IDENTITY')
    donors, groups = {}, {}
    for donor in bank['donors']:
        _fields(donor, ('id', 'source_ref', 'theory', 'goal', 'proof', 'required_axioms',
                        'signature', 'original_proof_sha256', 'original_line_count', 'source_rows'))
        _need(type(donor['id']) is str and donor['id'] and donor['id'] not in donors, 'DONOR_ID')
        theory = _theory(donor['theory'], m); used = _proof(donor['proof'], theory, m)
        _need(_wire(donor['proof'][-1]['formula'], m) == _wire(donor['goal'], m)
              and not _formula(donor['goal'], theory, {'functions': {}, 'predicates': {}}, m),
              'CLOSED_DONOR_GOAL')
        names = sorted({line['name'] for line in donor['proof'] if line['rule'] == 'axiom'})
        _need(not any(re.fullmatch('[0-9a-f]{64}', name) for name in names), 'PRIMITIVE_DONORS_ONLY')
        required = {name: theory['axioms'][name] for name in names}
        _need(_wire(used, m) == _wire(donor['signature'], m)
              and _wire(required, m) == _wire(donor['required_axioms'], m), 'DONOR_REQUIREMENTS')
        _need(_reachable(donor['proof'], len(donor['proof']) - 1, m) == list(range(len(donor['proof']))),
              'NORMALIZED_DONOR')
        origins = donor['source_rows']; count = donor['original_line_count']
        _need(type(count) is int and 1 <= count <= 64 and type(origins) is list
              and len(origins) == len(donor['proof'])
              and all(type(i) is int and 0 <= i < count for i in origins)
              and origins == sorted(set(origins)), 'DONOR_SOURCE_ROWS')
        _need(type(donor['original_proof_sha256']) is str
              and re.fullmatch('[0-9a-f]{64}', donor['original_proof_sha256']), 'DONOR_PROOF_DIGEST')
        source = donor['source_ref']; _fields(source, ('path', 'bytes', 'sha256'))
        _need(type(source['path']) is str and source['path'].startswith('/')
              and type(source['bytes']) is int and source['bytes'] >= 0
              and type(source['sha256']) is str and re.fullmatch('[0-9a-f]{64}', source['sha256']), 'SOURCE_REF')
        key = _digest(_variant(donor['goal'], used, required), m)
        if key in groups:
            first = groups[key][0]
            _need(_wire(_variant(donor['goal'], used, required), m)
                  == _wire(_variant(first['goal'], first['signature'], first['required_axioms']), m),
                  'DIGEST_COLLISION')
        donors[donor['id']] = donor; groups.setdefault(key, []).append(donor)
    _need(list(donors) == sorted(donors), 'DONOR_ORDER')
    seen = []
    for lemma in bank['lemmas']:
        _fields(lemma, ('id', 'name', 'goal', 'signature', 'required_axioms', 'proof',
                        'donor_ids', 'representative_donor'))
        key = _digest(_variant(lemma['goal'], lemma['signature'], lemma['required_axioms']), m)
        _need(lemma['id'] == lemma['name'] == key and key not in seen and key in groups, 'LEMMA_ID')
        group = groups[key]
        _need(_wire(_variant(lemma['goal'], lemma['signature'], lemma['required_axioms']), m)
              == _wire(_variant(group[0]['goal'], group[0]['signature'], group[0]['required_axioms']), m),
              'DIGEST_COLLISION')
        scored = [(len(d['proof']), _wire(d['proof'], m), d['id'], d) for d in group]
        representative = min(scored, key=lambda x: x[:3])[3]
        _need(lemma['donor_ids'] == sorted(d['id'] for d in group)
              and lemma['representative_donor'] == representative['id']
              and _wire(lemma['proof'], m) == _wire(representative['proof'], m), 'LEMMA_PROVENANCE')
        seen.append(key)
    _need(seen == sorted(groups), 'LEMMA_ORDER_AND_COVERAGE')
    return bank


def build_bank(donors, limits, *, charge=None):
    m = _Meter(limits, 'bank', charge)
    try:
        _need(type(donors) is list and donors, 'DONORS')
        if len(donors) > limits['max_donors']:
            raise _Stop('DONORS')
        records, variants, donor_ids = [], {}, set()
        for donor in donors:
            m.tick(); _fields(donor, ('id', 'source_ref', 'theory', 'goal', 'proof'))
            _need(type(donor['id']) is str and donor['id'] and donor['id'] not in donor_ids, 'DONOR_ID')
            donor_ids.add(donor['id']); source = donor['source_ref']
            _fields(source, ('path', 'bytes', 'sha256'))
            _need(type(source['path']) is str and source['path'].startswith('/')
                  and type(source['bytes']) is int and source['bytes'] >= 0
                  and type(source['sha256']) is str and re.fullmatch('[0-9a-f]{64}', source['sha256']),
                  'SOURCE_REF')
            theory = _theory(donor['theory'], m)
            _proof(donor['proof'], theory, m, limits['max_lines'])
            _need(_wire(donor['proof'][-1]['formula'], m) == _wire(donor['goal'], m)
                  and not _formula(donor['goal'], theory, {'functions': {}, 'predicates': {}}, m),
                  'CLOSED_DONOR_GOAL')
            proof, mapping, origins = _normalize(donor['proof'], m, limits['max_lines'])
            signature = _proof(proof, theory, m, limits['max_lines'])
            names = sorted({line['name'] for line in proof if line['rule'] == 'axiom'})
            _need(not any(re.fullmatch('[0-9a-f]{64}', name) for name in names),
                  'PRIMITIVE_DONORS_ONLY')
            required = {name: theory['axioms'][name] for name in names}
            record = {'id': donor['id'], 'source_ref': _clone(source, m), 'theory': theory,
                      'goal': _clone(donor['goal'], m), 'proof': proof,
                      'required_axioms': _clone(required, m), 'signature': signature,
                      'original_proof_sha256': _digest(donor['proof'], m),
                      'original_line_count': len(donor['proof']), 'source_rows': origins}
            records.append(record)
            core = _variant(record['goal'], signature, required); key = _digest(core, m)
            if key in variants:
                _need(_wire(variants[key]['core'], m) == _wire(core, m), 'DIGEST_COLLISION')
            else:
                variants[key] = {'core': core, 'records': []}
            variants[key]['records'].append(record)
        lemmas = []
        for key in sorted(variants):
            group = variants[key]['records']
            scored = [(len(r['proof']), _wire(r['proof'], m), r['id'], r) for r in group]
            m.tick(len(scored)); representative = min(scored, key=lambda x: x[:3])[3]
            core = variants[key]['core']
            lemmas.append({'id': key, 'name': key, 'goal': core['goal'],
                           'signature': core['signature'], 'required_axioms': core['required_axioms'],
                           'proof': representative['proof'], 'donor_ids': sorted(r['id'] for r in group),
                           'representative_donor': representative['id']})
        records.sort(key=lambda r: r['id'])
        bank = {'schema': BANK_SCHEMA, 'version': VERSION, 'donors': records,
                'lemmas': lemmas, 'bank_sha256': None, 'costs': None}
        bank['bank_sha256'] = _digest(_bank_core(bank), m)
        return _done(bank, m)
    except _Stop as error:
        return _unknown(error, m)


def _apply(theory, bank, m):
    theory = _theory(theory, m); _check_bank(bank, m)
    extended = _clone(theory, m); bindings, inactive = [], []
    for lemma in bank['lemmas']:
        m.tick(); reason = None
        for kind in ('functions', 'predicates'):
            for name, arity in lemma['signature'][kind].items():
                m.tick()
                if theory[kind].get(name) != arity:
                    reason = 'SIGNATURE'
        for name, formula in lemma['required_axioms'].items():
            m.tick()
            if name not in theory['axioms'] or _wire(theory['axioms'][name], m) != _wire(formula, m):
                reason = 'REQUIRED_AXIOM'
        if reason is not None:
            inactive.append({'lemma_id': lemma['id'], 'reason': reason})
            continue
        _need(lemma['name'] not in extended['axioms'], 'LEMMA_NAME_COLLISION')
        extended['axioms'][lemma['name']] = _clone(lemma['goal'], m)
        bindings.append({'name': lemma['name'], 'lemma_id': lemma['id']})
    return {'original_theory_sha256': _digest(theory, m), 'bank_sha256': bank['bank_sha256'],
            'theory': extended, 'lemma_bindings': bindings, 'inapplicable': inactive}


def extend_theory(theory, bank, limits, *, charge=None):
    m = _Meter(limits, 'extend', charge)
    try:
        _check_bank(bank, m)
        if len(bank['lemmas']) > limits['max_lemmas']:
            raise _Stop('LEMMAS')
        return _done(_apply(theory, bank, m), m)
    except _Stop as error:
        return _unknown(error, m)


def lower_proof(theory, bank, application, coarse_proof, limits, *, charge=None):
    m = _Meter(limits, 'lower', charge)
    try:
        original = _theory(theory, m)
        expected = _apply(original, bank, m)
        _need(_wire(application, m) == _wire(expected, m), 'APPLICATION_BINDING')
        _proof(coarse_proof, application['theory'], m)
        goal = coarse_proof[-1]['formula']
        _need(not _formula(goal, original, {'functions': {}, 'predicates': {}}, m), 'CLOSED_GOAL')
        keep = _reachable(coarse_proof, len(coarse_proof) - 1, m)
        byname = {x['name']: x for x in bank['lemmas']}
        enabled = {x['name'] for x in application['lemma_bindings']}
        emitted, facts, coarse_map, cache, expansions = [], {}, {}, {}, []
        def append(line):
            color = _wire(line['formula'], m)
            if color in facts:
                return facts[color]
            if len(emitted) >= limits['max_primitive_lines']:
                raise _Stop('PRIMITIVE_LINES')
            m.tick(); index = len(emitted)
            emitted.append(_clone(line, m)); facts[color] = index
            return index
        for row in keep:
            line = coarse_proof[row]; m.tick()
            if line['rule'] == 'axiom' and line['name'] in enabled:
                lemma = byname[line['name']]
                _need(_wire(line['formula'], m) == _wire(lemma['goal'], m), 'LEMMA_FORMULA')
                reused = lemma['id'] in cache
                if reused:
                    local = cache[lemma['id']]
                else:
                    local = []
                    for native in lemma['proof']:
                        copied = _clone(native, m)
                        for key in _refs(copied):
                            copied[key] = local[copied[key]]
                        local.append(append(copied))
                    cache[lemma['id']] = local
                coarse_map[row] = local[-1]
                expansions.append({'coarse_row': row, 'lemma_id': lemma['id'],
                                   'primitive_rows': list(local), 'reused': reused})
            else:
                copied = _clone(line, m)
                for key in _refs(copied):
                    copied[key] = coarse_map[copied[key]]
                coarse_map[row] = append(copied)
        final = _reachable(emitted, coarse_map[len(coarse_proof) - 1], m)
        rebase = {old: i for i, old in enumerate(final)}
        proof = []
        for old in final:
            copied = _clone(emitted[old], m)
            for key in _refs(copied):
                copied[key] = rebase[copied[key]]
            proof.append(copied)
        mapping = [rebase.get(coarse_map.get(i)) for i in range(len(coarse_proof))]
        for expansion in expansions:
            expansion['primitive_rows'] = [rebase.get(i) for i in expansion['primitive_rows']]
        _need(proof and _wire(proof[-1]['formula'], m) == _wire(goal, m)
              and mapping[-1] == len(proof) - 1, 'FINAL_GOAL_LAST')
        _proof(proof, original, m, limits['max_primitive_lines'])
        return _done({'theory': original, 'goal': goal, 'proof': proof,
                      'coarse_to_primitive': mapping, 'coarse_dependency_rows': keep,
                      'lemma_expansions': expansions}, m)
    except _Stop as error:
        return _unknown(error, m)


def _ports(line):
    return [line[key] for key in _refs(line)]


def mine_patterns(bank, limits, *, charge=None):
    m = _Meter(limits, 'mine', charge)
    try:
        _check_bank(bank, m)
        patterns, subsets = {}, 0
        for donor in bank['donors']:
            proof = donor['proof']; _proof(proof, donor['theory'], m)
            for size in range(1, min(4, len(proof)) + 1):
                for chosen in itertools.combinations(range(len(proof)), size):
                    if subsets >= limits['max_subsets']:
                        raise _Stop('SUBSETS')
                    subsets += 1; m.tick(size)
                    chosen_set = set(chosen); local = {old: i for i, old in enumerate(chosen)}
                    pending, connected = [chosen[-1]], set()
                    while pending:
                        m.tick(); old = pending.pop()
                        if old in connected:
                            continue
                        connected.add(old)
                        pending.extend(p for p in _ports(proof[old]) if p in chosen_set)
                    if connected != chosen_set:
                        continue
                    external = sorted({p for old in chosen for p in _ports(proof[old]) if p not in local})
                    eid = {old: i for i, old in enumerate(external)}
                    edges, receptors = [], []
                    for old in chosen:
                        for port, source in enumerate(_ports(proof[old])):
                            m.tick()
                            target = edges if source in local else receptors
                            target.append([local[old], port, local[source] if source in local else eid[source]])
                    core = {'nodes': [proof[i]['rule'] for i in chosen],
                            'edges': edges, 'receptors': receptors, 'root': size - 1}
                    key = _digest(core, m)
                    if key not in patterns:
                        if len(patterns) >= limits['max_patterns']:
                            raise _Stop('PATTERNS')
                        patterns[key] = dict(core, id=key, occurrences=[])
                    else:
                        _need(_wire({k: patterns[key][k] for k in core}, m) == _wire(core, m),
                              'PATTERN_DIGEST_COLLISION')
                    patterns[key]['occurrences'].append({'donor_id': donor['id'], 'lines': list(chosen)})
        m.tick(len(patterns) * (2 + max(1, len(patterns).bit_length())))
        value = {'schema': PATTERN_SCHEMA, 'version': VERSION,
                 'patterns': [patterns[k] for k in sorted(patterns)]}
        value['pattern_sha256'] = _digest(value, m)
        return _done(value, m)
    except _Stop as error:
        return _unknown(error, m)


def _check_patterns(value, m):
    _fields(value, ('schema', 'version', 'patterns', 'pattern_sha256'))
    _need(value['schema'] == PATTERN_SCHEMA and value['version'] == VERSION
          and type(value['patterns']) is list, 'PATTERN_VERSION')
    _need(value['pattern_sha256'] == _digest({k: value[k] for k in ('schema', 'version', 'patterns')}, m),
          'PATTERN_SET_IDENTITY')
    seen = set()
    for p in value['patterns']:
        _fields(p, ('id', 'nodes', 'edges', 'receptors', 'root', 'occurrences'))
        _need(type(p['nodes']) is list and 1 <= len(p['nodes']) <= 4
              and all(type(x) is str and x in RULES for x in p['nodes'])
              and type(p['root']) is int and p['root'] == len(p['nodes']) - 1, 'PATTERN_NODES')
        core = {k: p[k] for k in ('nodes', 'edges', 'receptors', 'root')}
        _need(p['id'] == _digest(core, m) and p['id'] not in seen, 'PATTERN_ID')
        seen.add(p['id']); occupied = set(); external = set()
        for kind in ('edges', 'receptors'):
            _need(type(p[kind]) is list, 'PATTERN_LINKS')
            for edge in p[kind]:
                m.tick(); _need(type(edge) is list and len(edge) == 3
                                and all(type(x) is int and x >= 0 for x in edge), 'PATTERN_EDGE')
                node, port, source = edge
                _need(node < len(p['nodes']) and (node, port) not in occupied, 'PATTERN_PORT')
                expected = 2 if p['nodes'][node] == 'mp' else 1 if p['nodes'][node] == 'generalize' else 0
                _need(port < expected, 'PATTERN_PORT_ARITY'); occupied.add((node, port))
                if kind == 'edges':
                    _need(source < node, 'PATTERN_PRIOR')
                else:
                    external.add(source)
        for node, label in enumerate(p['nodes']):
            ports = 2 if label == 'mp' else 1 if label == 'generalize' else 0
            _need(all((node, port) in occupied for port in range(ports)), 'PATTERN_COMPLETE_PORTS')
        _need(external == set(range(len(external))), 'PATTERN_RECEPTOR_IDS')
        reach, pending = set(), [p['root']]
        while pending:
            node = pending.pop(); m.tick()
            if node not in reach:
                reach.add(node); pending.extend(e[2] for e in p['edges'] if e[0] == node)
        _need(len(reach) == len(p['nodes']), 'PATTERN_CONNECTED')
        _need(type(p['occurrences']) is list and p['occurrences'], 'PATTERN_PROVENANCE')
        for occurrence in p['occurrences']:
            _fields(occurrence, ('donor_id', 'lines'))
            lines = occurrence['lines']
            _need(type(occurrence['donor_id']) is str and occurrence['donor_id']
                  and type(lines) is list and len(lines) == len(p['nodes'])
                  and all(type(i) is int and 0 <= i < 64 for i in lines)
                  and lines == sorted(set(lines)), 'PATTERN_OCCURRENCE')
    return value


def _freeze(value, m, depth=0):
    m.tick(1, depth)
    if type(value) is dict:
        return MappingProxyType({k: _freeze(v, m, depth + 1) for k, v in value.items()})
    if type(value) is list:
        return tuple(_freeze(v, m, depth + 1) for v in value)
    return value


class PreparedMatcher:
    __slots__ = ('_data', '_costs')

    def __init__(self, data, meter):
        object.__setattr__(self, '_data', _freeze(data, meter))
        object.__setattr__(self, '_costs', MappingProxyType(meter.costs()))

    def __setattr__(self, key, value):
        raise AttributeError('immutable prepared matcher')

    @property
    def model_sha256(self):
        return self._data['model_sha256']

    @property
    def compiled_sha256(self):
        return self._data['compiled_sha256']

    @property
    def pattern_sha256(self):
        return self._data['pattern_sha256']

    @property
    def preparation_costs(self):
        return dict(self._costs)


def prepare_matcher(compiled, slots, patterns, limits, *, charge=None):
    m = _Meter(limits, 'prepare', charge)
    try:
        _need(type(slots) is int and 1 <= slots <= 64, 'SLOTS')
        _fields(compiled, ('schema', 'version', 'theory', 'goal', 'goal_id', 'profile',
                          'logical_basis', 'zero_instances', 'mp_index', 'gen_index', 'costs', 'scope'))
        _need(compiled['schema'] == 'V-interned-Hilbert8-basis-v1'
              and compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'COMPILED_VERSION')
        _check_patterns(patterns, m)
        if len(patterns['patterns']) > limits['max_patterns']:
            raise _Stop('PATTERNS')
        colors = compiled['logical_basis']['colors']
        _need(type(colors) is list, 'COLORS')
        m.tick(len(colors))
        _need(all(type(x) is str for x in colors)
              and type(compiled['goal_id']) is int and 0 <= compiled['goal_id'] < len(colors), 'COLORS')
        m.tick(3 * len(compiled['zero_instances']))
        model = {'slots': slots, 'colors': colors, 'goal_id': compiled['goal_id'],
                 'zero': [[x['id'], x['formula_id']] for x in compiled['zero_instances']],
                 'mp_index': compiled['mp_index'], 'gen_index': compiled['gen_index']}
        definitions = []
        def add(label, output, left, right, suffix, kind):
            _need(type(output) is int and 0 <= output < len(colors)
                  and all(x is None or type(x) is int and 0 <= x < len(colors)
                          for x in (left, right)), 'DEFINITION_IDS')
            if len(definitions) >= limits['max_definitions']:
                raise _Stop('DEFINITIONS')
            m.tick(); definitions.append([label, output, left, right, suffix, kind])
        for i, row in enumerate(compiled['zero_instances']):
            _need(row['id'] == 'i' + str(i), 'ZERO_ID')
            _need(row['rule'] in RULES and row['rule'] not in ('mp', 'generalize'), 'ZERO_RULE')
            add(row['rule'], row['formula_id'], None, None, row['id'], 'zero')
        for head, antecedent, output in compiled['mp_index']:
            add('mp', output, antecedent, head, 'mp:' + str(head) + ':', 'mp')
        for head, body, variable in compiled['gen_index']:
            add('generalize', head, body, None, 'gen:' + str(head) + ':', 'gen')
        m.tick(len(definitions) * max(1, len(definitions).bit_length()))
        definitions.sort(key=lambda x: x[4]); index = {}
        for i, d in enumerate(definitions):
            m.tick(); index.setdefault(d[0], {}).setdefault(d[1], []).append(i)
        m.tick(len(patterns['patterns']))
        data = _clone({'slots': slots, 'goal_id': compiled['goal_id'],
                       'colors': colors, 'definitions': definitions,
                       'patterns': {x['id']: x for x in patterns['patterns']},
                       'model_sha256': _digest(model, m),
                       'compiled_sha256': _digest(compiled, m),
                       'pattern_sha256': patterns['pattern_sha256']}, m)
        # Internal numeric maps are frozen separately; JSON keys never coerce IDs.
        data['index'] = index
        m.tick(len(definitions) + len(patterns['patterns']))
        prepared = PreparedMatcher(data, m)
        receipt = _done({'model_sha256': data['model_sha256'],
                         'compiled_sha256': data['compiled_sha256'],
                         'pattern_sha256': data['pattern_sha256'],
                         'slots': slots, 'definitions': len(definitions),
                         'patterns': len(patterns['patterns'])}, m)
        object.__setattr__(prepared, '_costs', MappingProxyType(dict(receipt['costs'])))
        return prepared, receipt
    except _Stop as error:
        return None, _unknown(error, m)


def _snapshot(state, slots, colors, m):
    _fields(state, ('occupied', 'selected', 'values', 'refs', 'excluded', 'schema',
                    'required', 'frontier', 'root_generations', 'degrees', 'aggregates'))
    _need(state['schema'] == 'W-aggregate-unit-point-state-v1', 'STATE_SCHEMA')
    m.tick(10 * slots)
    for key in ('occupied', 'selected', 'values', 'refs', 'root_generations', 'degrees', 'aggregates'):
        _need(type(state[key]) is list and len(state[key]) == slots, 'STATE_ARRAY')
    _need(all(type(x) is bool for x in state['occupied']), 'OCCUPIED')
    _need(all(x is None or type(x) is str for x in state['selected']), 'SELECTED')
    _need(all(x is None or type(x) is int and 0 <= x < len(colors) for x in state['values']), 'VALUES')
    _need(all(type(x) is int and x >= 0 for x in state['refs']), 'REFS')
    _need(type(state['excluded']) is list, 'EXCLUDED')
    m.tick(len(state['excluded']) *
           (slots + 3 + max(1, len(state['excluded']).bit_length())))
    _need(all(type(x) is str for x in state['excluded'])
          and state['excluded'] == sorted(set(state['excluded'])), 'EXCLUDED')
    _need(all(type(x) is int and x >= 0 for x in state['degrees']), 'DEGREES')
    for row in range(slots):
        m.tick()
        _need(state['occupied'][row] == (state['selected'][row] is not None)
              and (state['values'][row] is None) == (state['refs'][row] == 0)
              and (not state['occupied'][row] or state['values'][row] is not None)
              and state['selected'][row] not in state['excluded'], 'STATE_BINDINGS')
        _need(state['aggregates'][row] is None if state['occupied'][row]
              else type(state['aggregates'][row]) is list and len(state['aggregates'][row]) == 8,
              'AGGREGATE_SHAPE')
    _need(state['required'] == ['slot:' + str(i) for i in range(slots)]
          and state['frontier'] == ['slot:' + str(i) for i in range(slots) if not state['occupied'][i]]
          and all(type(x) is int and x == 0 for x in state['root_generations']), 'ROOTS')
    return _clone(state, m)


def _bounded(m, name, limit):
    value = getattr(m, name, 0)
    if value >= m.limits[limit]:
        raise _Stop(name.upper())
    m.tick(); setattr(m, name, value + 1)


def _alignments(anchor, size, mode, m):
    def front():
        yield from itertools.combinations(range(anchor), size - 1)
    def late():
        for row in itertools.combinations(range(anchor - 1, -1, -1), size - 1):
            yield tuple(reversed(row))
    if mode == 'front':
        source = front()
    elif mode == 'late':
        source = late()
    else:
        def mixed():
            seen = set()
            for a, b in itertools.zip_longest(front(), late()):
                for row in (a, b):
                    if row is not None and row not in seen:
                        m.tick(); seen.add(row); yield row
        source = mixed()
    for row in source:
        _bounded(m, 'alignments', 'max_alignments')
        yield row + (anchor,)


def _row_choices(maximum, mode):
    if mode == 'front':
        yield from range(maximum)
    elif mode == 'late':
        yield from range(maximum - 1, -1, -1)
    else:
        for low in range((maximum + 1) // 2):
            yield low
            high = maximum - 1 - low
            if high != low:
                yield high


def _candidate(definition, row, references):
    label, output, left, right, suffix, kind = definition
    marks = {row: output}
    if kind == 'zero':
        cid = 'r' + str(row) + ':' + suffix
    elif kind == 'gen':
        source = references[0]
        if not 0 <= source < row:
            return None
        marks[source] = left
        cid = 'r' + str(row) + ':' + suffix + str(source)
    else:
        a, b = references
        if not 0 <= a < row or not 0 <= b < row or a == b and left != right:
            return None
        marks[a] = left; marks[b] = right
        cid = 'r' + str(row) + ':' + suffix + str(a) + ':' + str(b)
    return cid, marks


def _try_alignment(data, pattern, rows, state, mode, m):
    size = len(rows); ports = {}
    for node, port, source in pattern['edges']:
        ports[(node, port)] = ('node', source)
    for node, port, source in pattern['receptors']:
        ports[(node, port)] = ('external', source)
    outputs = [None] * size
    outputs[-1] = data['goal_id'] if rows[-1] == data['slots'] - 1 else state['values'][rows[-1]]
    m.tick(len(state['excluded'])); excluded = set(state['excluded'])
    member_rows = set(rows)
    def finish(chosen, external_values):
        external_ids = sorted(external_values); bounds = {}
        for node, port, source in pattern['receptors']:
            bounds[source] = min(bounds.get(source, rows[node]), rows[node])
        def bind(at, assigned, used):
            if at == len(external_ids):
                members, union = [], {}
                for node in range(size - 1, -1, -1):
                    definition = data['definitions'][chosen[node]]
                    refs = []
                    count = 2 if definition[5] == 'mp' else 1 if definition[5] == 'gen' else 0
                    for port in range(count):
                        kind, source = ports[(node, port)]
                        refs.append(rows[source] if kind == 'node' else assigned[source])
                    m.tick(); concrete = _candidate(definition, rows[node], refs)
                    if concrete is None:
                        return None
                    cid, marks = concrete
                    if cid in excluded or state['occupied'][rows[node]] and state['selected'][rows[node]] != cid:
                        return None
                    for point, value in marks.items():
                        m.tick()
                        if state['values'][point] is not None and state['values'][point] != value:
                            return None
                        if point in union and union[point] != value:
                            return None
                        union[point] = value
                    members.append(cid)
                receptors = [{'id': key, 'row': assigned[key], 'formula_id': external_values[key],
                               'selected_id': state['selected'][assigned[key]]} for key in external_ids]
                return members, receptors
            key = external_ids[at]; value = external_values[key]
            for row in _row_choices(bounds[key], mode):
                m.tick()
                if row in used or row in member_rows:
                    continue
                if state['values'][row] is not None and state['values'][row] != value:
                    continue
                changed = dict(assigned); changed[key] = row
                result = bind(at + 1, changed, used | {row})
                if result is not None:
                    return result
            return None
        return bind(0, {}, set())
    def choose(node, known, chosen, external):
        if node < 0:
            return finish(chosen, external)
        output = known[node]
        if output is None:
            return None
        if state['values'][rows[node]] is not None and state['values'][rows[node]] != output:
            return None
        label = pattern['nodes'][node]
        for did in data['index'].get(label, {}).get(output, ()):
            _bounded(m, 'matches', 'max_matches')
            definition = data['definitions'][did]
            operands = () if definition[5] == 'zero' else (definition[2],) if definition[5] == 'gen' else definition[2:4]
            next_known, next_external, next_chosen = list(known), dict(external), list(chosen)
            possible = True
            for port, value in enumerate(operands):
                kind, source = ports[(node, port)]
                if kind == 'node':
                    if next_known[source] is not None and next_known[source] != value:
                        possible = False; break
                    next_known[source] = value
                else:
                    if source in next_external and next_external[source] != value:
                        possible = False; break
                    next_external[source] = value
            if not possible:
                continue
            next_chosen[node] = did
            result = choose(node - 1, next_known, next_chosen, next_external)
            if result is not None:
                return result
        return None
    return choose(size - 1, outputs, [None] * size, {})


def propose_clusters(prepared, request, pattern_order, limits, *, charge=None):
    m = _Meter(limits, 'propose', charge)
    try:
        _need(type(prepared) is PreparedMatcher, 'PREPARED')
        data = prepared._data; _fields(request, ('row', 'state'))
        row = request['row']
        _need(type(row) is int and 0 <= row < data['slots'], 'ROW')
        state = _snapshot(request['state'], data['slots'], data['colors'], m)
        _need(type(pattern_order) is list and all(type(x) is str and x in data['patterns'] for x in pattern_order)
              and len(set(pattern_order)) == len(pattern_order), 'PATTERN_ORDER')
        packets, records, seen = [], [], set()
        fixed = data['goal_id'] if row == data['slots'] - 1 else state['values'][row]
        stopped = limits['max_packets'] == 0
        if fixed is not None and not state['occupied'][row] and not stopped:
            for pid in pattern_order:
                pattern = data['patterns'][pid]
                if len(pattern['nodes']) > row + 1:
                    continue
                for mode in ('front', 'late', 'mixed'):
                    for rows in _alignments(row, len(pattern['nodes']), mode, m):
                        matched = _try_alignment(data, pattern, rows, state, mode, m)
                        if matched is None:
                            continue
                        members, receptors = matched; identity = tuple(members)
                        if identity not in seen:
                            core = {'pattern_id': pid, 'rows': list(rows), 'members': members,
                                    'receptors': receptors, 'mode': mode}
                            key = _digest(core, m); seen.add(identity)
                            records.append(dict(core, id=key)); packets.append({'id': key, 'members': list(members)})
                        break  # First compatible match per pattern and mode only.
                    if len(packets) >= limits['max_packets']:
                        stopped = True; break
                if stopped:
                    break
        return _done({'packets': packets, 'records': records,
                      'enumeration_scope': 'FIRST_MATCH_PER_PATTERN_AND_MODE',
                      'bounded_stop': stopped}, m)
    except _Stop as error:
        return _unknown(error, m)
