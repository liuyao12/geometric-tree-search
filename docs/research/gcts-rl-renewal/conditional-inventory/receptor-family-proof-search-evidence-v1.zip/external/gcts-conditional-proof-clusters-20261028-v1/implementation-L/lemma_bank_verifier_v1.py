"""Independent X bank/extension/lowering data verifier; no logical prover or IO.

VERIFIED certifies the disclosed deterministic transformation and associations.
Primitive logical truth and original-theory lowered certificates require the
separately bound native C1 and independent B checks. No project imports/calls.
"""
import hashlib
import json
import math
import time

VERSION = 'X-INDEPENDENT-LEMMA-BANK-VERIFIER-v1'
BANK_VERSION = 'X-CERTIFIED-LEMMA-PATTERNS-v1'
BANK_SCHEMA = 'X-certified-primitive-lemma-bank-v1'
SCOPE = 'Complete exact bank/pruning/extension/splice associations; not a replacement for native C1 plus independent B original-theory logical verification.'
FIELDS = {
    'axiom': ('rule', 'formula', 'name'),
    'mp': ('rule', 'formula', 'antecedent', 'implication'),
    'generalize': ('rule', 'formula', 'source', 'variable'),
    'instantiate': ('rule', 'formula', 'universal', 'term'),
    'distribute': ('rule', 'formula', 'variable', 'antecedent', 'consequent'),
    'eq_subst': ('rule', 'formula', 'variable', 'template', 'left', 'right'),
    'refl': ('rule', 'formula'),
    'tautology': ('rule', 'formula'),
}


class _Invalid(Exception):
    pass


class _Stop(Exception):
    pass


class _Meter:
    def __init__(self, limits, charge):
        self.start = time.perf_counter()
        self.work = 0
        self.charge = charge
        if limits is None:
            limits = {'wall_seconds': 15, 'max_work': 100000000, 'max_depth': 128, 'max_lines': 64}
        _fields(limits, ('wall_seconds', 'max_work', 'max_depth', 'max_lines'))
        wall = limits['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60 and math.isfinite(wall), 'LIMITS')
        for k, maximum in (('max_work', 1000000000), ('max_depth', 128), ('max_lines', 64)):
            _need(type(limits[k]) is int and 0 <= limits[k] <= maximum, 'LIMITS')
        _need(charge is None or callable(charge), 'CHARGE')
        self.wall = wall
        self.maximum = limits['max_work']
        self.depth = limits['max_depth']
        self.lines = limits['max_lines']
        self.tick()

    def tick(self, units=1):
        if self.work + units > self.maximum or time.perf_counter() - self.start > self.wall:
            raise _Stop('RESOURCE_LIMIT')
        if self.charge is not None:
            self.charge(units)
        self.work += units

    def costs(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Complete input validation, copies, canonical hashes, transformation reconstruction and output preparation; no logical kernel or caller serialization.'}


def _need(ok, reason):
    if not ok:
        raise _Invalid(reason)


def _fields(value, fields):
    _need(type(value) is dict and len(value) == len(fields), 'FIELDS')
    _need(all(type(k) is str for k in value) and set(value) == set(fields), 'FIELDS')


def _name(value, meter):
    _need(type(value) is str and len(value) > 0, 'NAME')
    meter.tick(len(value))
    return value


def _hex(value, length=64):
    return type(value) is str and len(value) == length and all(c in '0123456789abcdef' for c in value)


def _clone(value, meter, depth=0):
    meter.tick()
    if depth > meter.depth:
        raise _Stop('DEPTH_LIMIT')
    kind = type(value)
    if kind is str:
        meter.tick(len(value))
        return value
    if value is None or kind in (bool, int):
        if kind is int:
            meter.tick(max(1, value.bit_length()))
        return value
    if kind is float:
        _need(math.isfinite(value), 'JSON_FLOAT')
        return value
    if kind is list:
        meter.tick(len(value))
        return [_clone(v, meter, depth + 1) for v in value]
    if kind is dict:
        meter.tick(len(value))
        _need(all(type(k) is str for k in value), 'JSON_KEYS')
        return {_clone(k, meter, depth + 1): _clone(v, meter, depth + 1) for k, v in value.items()}
    raise _Invalid('JSON_TYPE')


def _bound(value, meter, depth=0):
    meter.tick()
    if depth > meter.depth:
        raise _Stop('DEPTH_LIMIT')
    kind = type(value)
    if kind is str:
        meter.tick(len(value))
        return 2 + 12 * len(value)
    if value is None:
        return 4
    if kind is bool:
        return 5
    if kind is int:
        meter.tick(max(1, value.bit_length()))
        return 2 + max(1, value.bit_length())
    if kind is float:
        _need(math.isfinite(value), 'JSON_FLOAT')
        return 32
    if kind is list:
        meter.tick(len(value))
        return 2 + len(value) + sum(_bound(v, meter, depth + 1) for v in value)
    if kind is dict:
        meter.tick(len(value))
        _need(all(type(k) is str for k in value), 'JSON_KEYS')
        return 2 + 2 * len(value) + sum(_bound(k, meter, depth + 1) + _bound(v, meter, depth + 1) for k, v in value.items())
    raise _Invalid('JSON_TYPE')


def _image(value, meter):
    upper = _bound(value, meter) + 1
    meter.tick(upper)
    raw = (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
    _need(len(raw) <= upper, 'INTERNAL_JSON_BOUND')
    return raw


def _digest(value, meter):
    raw = _image(value, meter)
    meter.tick(len(raw))
    return hashlib.sha256(raw).hexdigest()


def _same(a, b, meter):
    return _image(a, meter) == _image(b, meter)


def _costs(value, meter):
    _fields(value, ('work', 'seconds', 'scope'))
    _need(type(value['work']) is int and value['work'] >= 0, 'COSTS')
    seconds = value['seconds']
    _need(type(seconds) in (int, float) and 0 <= seconds and (type(seconds) is int or math.isfinite(seconds)), 'COSTS')
    _name(value['scope'], meter)


def _term(value, signature, used, meter, depth=0):
    meter.tick()
    if depth > meter.depth:
        raise _Stop('DEPTH_LIMIT')
    _need(type(value) is list and 1 <= len(value) <= 3 and type(value[0]) is str, 'TERM')
    if value[0] == 'var':
        _need(len(value) == 2, 'TERM')
        return {_name(value[1], meter)}
    _need(value[0] == 'fun' and len(value) == 3 and type(value[2]) is list, 'TERM')
    symbol = _name(value[1], meter)
    _need(symbol in signature['functions'] and signature['functions'][symbol] == len(value[2]), 'FUNCTION_ARITY')
    used['functions'][symbol] = len(value[2])
    meter.tick(len(value[2]))
    free = set()
    for child in value[2]:
        free.update(_term(child, signature, used, meter, depth + 1))
    return free


def _formula(value, signature, used, meter, depth=0):
    meter.tick()
    if depth > meter.depth:
        raise _Stop('DEPTH_LIMIT')
    _need(type(value) is list and 1 <= len(value) <= 3 and type(value[0]) is str, 'FORMULA')
    tag = value[0]
    if tag == 'bot':
        _need(len(value) == 1, 'FORMULA')
        return set()
    if tag == 'eq':
        _need(len(value) == 3, 'FORMULA')
        return _term(value[1], signature, used, meter, depth + 1) | _term(value[2], signature, used, meter, depth + 1)
    if tag == 'pred':
        _need(len(value) == 3 and type(value[2]) is list, 'FORMULA')
        symbol = _name(value[1], meter)
        _need(symbol in signature['predicates'] and signature['predicates'][symbol] == len(value[2]), 'PREDICATE_ARITY')
        used['predicates'][symbol] = len(value[2])
        meter.tick(len(value[2]))
        free = set()
        for child in value[2]:
            free.update(_term(child, signature, used, meter, depth + 1))
        return free
    if tag == 'all':
        _need(len(value) == 3, 'FORMULA')
        variable = _name(value[1], meter)
        return _formula(value[2], signature, used, meter, depth + 1) - {variable}
    if tag == 'not':
        _need(len(value) == 2, 'FORMULA')
        return _formula(value[1], signature, used, meter, depth + 1)
    _need(tag in ('and', 'or', 'imp') and len(value) == 3, 'FORMULA')
    return _formula(value[1], signature, used, meter, depth + 1) | _formula(value[2], signature, used, meter, depth + 1)


def _signature(value, meter):
    _fields(value, ('functions', 'predicates'))
    for namespace in ('functions', 'predicates'):
        values = value[namespace]
        _need(type(values) is dict, 'SIGNATURE')
        meter.tick(len(values))
        for name, arity in values.items():
            _name(name, meter)
            _need(type(arity) is int and arity >= 0, 'ARITY')
    return _clone(value, meter)


def _theory(value, meter):
    _fields(value, ('functions', 'predicates', 'axioms'))
    signature = _signature({'functions': value['functions'], 'predicates': value['predicates']}, meter)
    _need(type(value['axioms']) is dict, 'AXIOMS')
    meter.tick(len(value['axioms']))
    for name, formula in value['axioms'].items():
        _name(name, meter)
        _need(not _formula(formula, signature, {'functions': {}, 'predicates': {}}, meter), 'OPEN_AXIOM')
    return _clone(value, meter)


def _refs(line):
    if line['rule'] == 'mp':
        return (line['antecedent'], line['implication'])
    if line['rule'] == 'generalize':
        return (line['source'],)
    return ()


def _proof(value, theory, meter, primitive=False):
    _need(type(value) is list and len(value) > 0, 'PROOF')
    if len(value) > meter.lines:
        raise _Stop('LINE_LIMIT')
    meter.tick(len(value))
    used = {'functions': {}, 'predicates': {}}
    for i, line in enumerate(value):
        _need(type(line) is dict and type(line.get('rule')) is str and line['rule'] in FIELDS, 'RULE')
        rule = line['rule']
        _fields(line, FIELDS[rule])
        _formula(line['formula'], theory, used, meter)
        for ref in _refs(line):
            _need(type(ref) is int and 0 <= ref < i, 'PRIOR_REFERENCE')
        if rule == 'axiom':
            name = _name(line['name'], meter)
            _need(not primitive or not _hex(name), 'NESTED_INVENTORY')
            _need(name in theory['axioms'] and _same(line['formula'], theory['axioms'][name], meter), 'AXIOM_BINDING')
        if rule in ('generalize', 'distribute', 'eq_subst'):
            _name(line['variable'], meter)
        if rule == 'instantiate':
            _formula(line['universal'], theory, used, meter)
            _term(line['term'], theory, used, meter)
        if rule == 'distribute':
            _formula(line['antecedent'], theory, used, meter)
            _formula(line['consequent'], theory, used, meter)
        if rule == 'eq_subst':
            _formula(line['template'], theory, used, meter)
            _term(line['left'], theory, used, meter)
            _term(line['right'], theory, used, meter)
    return _clone(value, meter), used


def _ancestry(proof, goal_row, meter):
    pending = [goal_row]
    reached = set()
    while pending:
        meter.tick()
        row = pending.pop()
        if row in reached:
            continue
        reached.add(row)
        refs = _refs(proof[row])
        meter.tick(len(refs))
        pending.extend(refs)
    meter.tick(len(reached) * max(1, len(reached).bit_length()))
    return sorted(reached)


def _remap(line, mapping, meter):
    out = _clone(line, meter)
    if out['rule'] == 'mp':
        out['antecedent'] = mapping[out['antecedent']]
        out['implication'] = mapping[out['implication']]
    elif out['rule'] == 'generalize':
        out['source'] = mapping[out['source']]
    return out


def _prune(proof, goal_row, meter):
    rows = _ancestry(proof, goal_row, meter)
    meter.tick(len(rows))
    mapping = {old: new for new, old in enumerate(rows)}
    out = [_remap(proof[old], mapping, meter) for old in rows]
    return out, rows, mapping


def _normalize(proof, meter):
    rows = _ancestry(proof, len(proof) - 1, meter)
    seen = {}
    mapping = {}
    source = []
    out = []
    for old in rows:
        key = _image(proof[old]['formula'], meter)
        if key not in seen:
            meter.tick()
            seen[key] = len(out)
            out.append(_remap(proof[old], mapping, meter))
            source.append(old)
        mapping[old] = seen[key]
    final, kept, _ = _prune(out, mapping[len(proof) - 1], meter)
    return final, [source[i] for i in kept]


def _source(value, meter):
    _fields(value, ('path', 'bytes', 'sha256'))
    _name(value['path'], meter)
    _need(type(value['bytes']) is int and value['bytes'] >= 0 and _hex(value['sha256']), 'SOURCE_REF')
    return _clone(value, meter)


def _donors(values, meter):
    _need(type(values) is list and len(values) <= 64, 'DONORS')
    meter.tick(len(values))
    out = []
    seen = set()
    for value in values:
        _fields(value, ('id', 'source_ref', 'theory', 'goal', 'proof'))
        name = _name(value['id'], meter)
        _need(name not in seen, 'DUPLICATE_DONOR')
        seen.add(name)
        theory = _theory(value['theory'], meter)
        proof, _ = _proof(value['proof'], theory, meter)
        _need(not _formula(value['goal'], theory, {'functions': {}, 'predicates': {}}, meter), 'OPEN_GOAL')
        _need(_same(proof[-1]['formula'], value['goal'], meter), 'GOAL')
        proof, source_rows = _normalize(proof, meter)
        _, used = _proof(proof, theory, meter, True)
        required = {}
        for line in proof:
            if line['rule'] == 'axiom':
                required[line['name']] = _clone(line['formula'], meter)
        out.append({'id': name, 'source_ref': _source(value['source_ref'], meter), 'theory': theory,
                    'goal': _clone(value['goal'], meter), 'proof': proof, 'required_axioms': required,
                    'signature': used, 'original_proof_sha256': _digest(value['proof'], meter),
                    'original_line_count': len(value['proof']), 'source_rows': source_rows})
    meter.tick(len(out) * max(1, len(out).bit_length()))
    return sorted(out, key=lambda row: row['id'])


def _lemmas(donors, meter):
    groups = {}
    for donor in donors:
        core = {'goal': donor['goal'], 'signature': donor['signature'], 'required_axioms': donor['required_axioms']}
        key = _digest(core, meter)
        if key in groups:
            _need(_same(groups[key][0], core, meter), 'DIGEST_COLLISION')
        else:
            groups[key] = (core, [])
        groups[key][1].append(donor)
    out = []
    for key in sorted(groups):
        core, group = groups[key]
        ordered = sorted(group, key=lambda row: (len(row['proof']), _image(row['proof'], meter), row['id']))
        representative = ordered[0]
        meter.tick(len(group))
        out.append({'id': key, 'name': key, 'goal': _clone(core['goal'], meter),
                    'signature': _clone(core['signature'], meter), 'required_axioms': _clone(core['required_axioms'], meter),
                    'proof': _clone(representative['proof'], meter), 'donor_ids': sorted(row['id'] for row in group),
                    'representative_donor': representative['id']})
    return out


def _bank(value, meter):
    _fields(value, ('schema', 'version', 'donors', 'lemmas', 'bank_sha256', 'costs'))
    _need(type(value['schema']) is str and type(value['version']) is str and value['schema'] == BANK_SCHEMA and value['version'] == BANK_VERSION, 'BANK_VERSION')
    _costs(value['costs'], meter)
    rows = value['donors']
    _need(type(rows) is list and len(rows) <= 64, 'DONORS')
    raw = []
    for row in rows:
        _fields(row, ('id', 'source_ref', 'theory', 'goal', 'proof', 'required_axioms', 'signature', 'original_proof_sha256', 'original_line_count', 'source_rows'))
        _name(row['id'], meter)
        _source(row['source_ref'], meter)
        theory = _theory(row['theory'], meter)
        proof, used = _proof(row['proof'], theory, meter, True)
        _need(not _formula(row['goal'], theory, {'functions': {}, 'predicates': {}}, meter), 'OPEN_GOAL')
        _need(_same(proof[-1]['formula'], row['goal'], meter), 'GOAL')
        normalized, _ = _normalize(proof, meter)
        _need(_same(proof, normalized, meter), 'NOT_NORMALIZED')
        required = {line['name']: line['formula'] for line in proof if line['rule'] == 'axiom'}
        _need(_same(required, row['required_axioms'], meter) and _same(used, row['signature'], meter), 'DONOR_REQUIREMENTS')
        _need(_hex(row['original_proof_sha256']) and type(row['original_line_count']) is int and len(proof) <= row['original_line_count'] <= meter.lines, 'DONOR_ORIGINAL')
        indices = row['source_rows']
        _need(type(indices) is list and len(indices) == len(proof), 'SOURCE_ROWS')
        _need(all(type(i) is int and 0 <= i < row['original_line_count'] for i in indices) and indices == sorted(set(indices)), 'SOURCE_ROWS')
        raw.append(_clone(row, meter))
    _need([row['id'] for row in raw] == sorted(set(row['id'] for row in raw)), 'DONOR_ORDER')
    expected = _lemmas(raw, meter)
    _need(_same(value['lemmas'], expected, meter), 'LEMMA_BINDING')
    core = {k: value[k] for k in ('schema', 'version', 'donors', 'lemmas')}
    _need(_hex(value['bank_sha256']) and value['bank_sha256'] == _digest(core, meter), 'BANK_HASH')
    return expected


def _extension(theory, bank, application, meter):
    theory = _theory(theory, meter)
    lemmas = _bank(bank, meter)
    _fields(application, ('original_theory_sha256', 'bank_sha256', 'theory', 'lemma_bindings', 'inapplicable'))
    extended = _clone(theory, meter)
    bindings = []
    inapplicable = []
    for lemma in lemmas:
        reason = None
        for name, formula in lemma['required_axioms'].items():
            if name not in theory['axioms'] or not _same(theory['axioms'][name], formula, meter):
                reason = 'REQUIRED_AXIOM'
                break
        if reason is None:
            for space in ('functions', 'predicates'):
                if any(theory[space].get(name) != arity for name, arity in lemma['signature'][space].items()):
                    reason = 'SIGNATURE'
                    break
        if reason is not None:
            inapplicable.append({'lemma_id': lemma['id'], 'reason': reason})
        else:
            _need(lemma['name'] not in theory['axioms'], 'NAME_COLLISION')
            meter.tick()
            extended['axioms'][lemma['name']] = _clone(lemma['goal'], meter)
            bindings.append({'name': lemma['name'], 'lemma_id': lemma['id']})
    expected = {'original_theory_sha256': _digest(theory, meter), 'bank_sha256': bank['bank_sha256'],
                'theory': extended, 'lemma_bindings': bindings, 'inapplicable': inapplicable}
    _need(_same(application, expected, meter), 'EXTENSION_BINDING')
    return extended, {row['name']: row['lemma_id'] for row in bindings}, lemmas


def _lower(theory, bank, application, coarse, lowering, meter):
    extended, bindings, lemmas = _extension(theory, bank, application, meter)
    coarse, _ = _proof(coarse, extended, meter)
    used_coarse = _ancestry(coarse, len(coarse) - 1, meter)
    lemma_by_id = {row['id']: row for row in lemmas}
    out = []
    formulas = {}
    coarse_map = {}
    cache = {}
    expansions = []

    def append(line, mapping):
        key = _image(line['formula'], meter)
        if key in formulas:
            return formulas[key]
        if len(out) >= meter.lines:
            raise _Stop('EXPANSION_LIMIT')
        meter.tick()
        mapped = _remap(line, mapping, meter)
        row = len(out)
        out.append(mapped)
        formulas[key] = row
        return row

    for old in used_coarse:
        line = coarse[old]
        if line['rule'] == 'axiom' and line['name'] in bindings:
            lid = bindings[line['name']]
            _need(_same(line['formula'], lemma_by_id[lid]['goal'], meter), 'LEMMA_FORMULA')
            reused = lid in cache
            if not reused:
                local = {}
                for j, primitive in enumerate(lemma_by_id[lid]['proof']):
                    local[j] = append(primitive, local)
                cache[lid] = [local[j] for j in range(len(local))]
            primitive_rows = cache[lid]
            coarse_map[old] = primitive_rows[-1]
            expansions.append({'coarse_row': old, 'lemma_id': lid, 'primitive_rows': list(primitive_rows), 'reused': reused})
        else:
            coarse_map[old] = append(line, coarse_map)
    final, _, final_map = _prune(out, coarse_map[len(coarse) - 1], meter)
    mapped = [final_map.get(coarse_map[i]) if i in coarse_map else None for i in range(len(coarse))]
    for expansion in expansions:
        expansion['primitive_rows'] = [final_map.get(row) for row in expansion['primitive_rows']]
    expected = {'theory': _clone(theory, meter), 'goal': _clone(coarse[-1]['formula'], meter), 'proof': final,
                'coarse_to_primitive': mapped, 'coarse_dependency_rows': used_coarse, 'lemma_expansions': expansions}
    _need(_same(lowering, expected, meter), 'LOWERING_BINDING')
    _proof(final, theory, meter)
    _need(mapped[-1] == len(final) - 1 and _same(final[-1]['formula'], coarse[-1]['formula'], meter), 'FINAL_GOAL')
    return {'coarse_lines': len(coarse), 'coarse_dependency_rows': used_coarse, 'primitive_lines': len(final),
            'lemma_expansions': len(expansions), 'proof_sha256': _digest(final, meter)}


def _run(kind, operation, limits, charge):
    meter = None
    try:
        meter = _Meter(limits, charge)
        details = operation(meter)
        meter.tick()
        status, reason = 'VERIFIED', kind
    except _Invalid as exc:
        status, reason, details = 'REJECTED', str(exc), None
    except _Stop as exc:
        status, reason, details = 'UNKNOWN', str(exc), None
    costs = meter.costs() if meter is not None else {'work': 0, 'seconds': 0.0, 'scope': 'Limits rejected before validation.'}
    return {'schema': 'X-independent-lemma-bank-check-v1', 'version': VERSION, 'status': status,
            'reason': reason, 'details': details, 'costs': costs, 'scope': SCOPE}


def verify_bank(donors, bank, *, limits=None, charge=None):
    """Bind the entire bank to the supplied raw donor projections; no file IO."""
    def check(meter):
        expected_donors = _donors(donors, meter)
        _bank(bank, meter)
        _need(_same(bank['donors'], expected_donors, meter), 'RAW_DONOR_BINDING')
        return {'donors': len(expected_donors), 'lemmas': len(bank['lemmas']), 'bank_sha256': bank['bank_sha256'],
                'raw_custody_scope': 'source_ref values compared; caller must independently bind actual raw files and admitted native receipts.'}
    return _run('WHOLE_BANK_TRANSFORMATION', check, limits, charge)


def verify_extension(theory, bank, application, *, limits=None, charge=None):
    """Check exact dependency/signature eligibility and complete extended theory."""
    def check(meter):
        _, bindings, _ = _extension(theory, bank, application, meter)
        return {'eligible': len(bindings), 'inapplicable': len(application['inapplicable']),
                'extended_theory_sha256': _digest(application['theory'], meter)}
    return _run('WHOLE_EXTENSION_TRANSFORMATION', check, limits, charge)


def verify_lowering(theory, bank, application, coarse_proof, lowering, *, limits=None, charge=None):
    """Reconstruct the complete primitive splice, maps, reuse and final pruning."""
    def check(meter):
        return _lower(theory, bank, application, coarse_proof, lowering, meter)
    return _run('WHOLE_LOWERING_TRANSFORMATION', check, limits, charge)
