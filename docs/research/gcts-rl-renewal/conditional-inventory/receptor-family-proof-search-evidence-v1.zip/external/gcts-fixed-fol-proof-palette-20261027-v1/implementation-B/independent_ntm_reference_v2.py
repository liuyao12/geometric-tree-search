"""Independent full global NTM configuration sets on a fixed finite interval.

No compiler/project imports, CA rules, tile enumeration, IO, callbacks or CLI.
This is a bounded reference control, not a universal-machine or proof claim.
"""

VERSION = 'GCTS-INDEPENDENT-FINITE-NTM-REFERENCE-v2'
SCHEMA = 'GCTS-independent-finite-NTM-simulation-v2'
_SCOPE = ('Independent bounded whole-configuration NTM enumeration only. '
          'No local-CA/tile, GCTS benchmark, proof, universality or fixed-palette claim. '
          'Unknown/rejected prefixes are diagnostic and not complete results.')


class _Invalid(Exception):
    pass


class _Limit(Exception):
    pass


class _Budget:
    def __init__(self, limits):
        self.limits = dict(limits)
        self.operations = 0
        self.by_kind = {}
        self.counts = {'completed_layers': 0, 'retained_configuration_rows': 0,
                       'transition_rows': 0, 'effective_transition_rows': 0,
                       'folded_accept_identities': 0, 'configurations_processed': 0,
                       'transition_checks': 0, 'off_interval_moves': 0,
                       'duplicate_successors': 0, 'implicit_accept_successors': 0,
                       'prefix_acceptance_seen': False}

    def visit(self, kind, units=1):
        if units > self.limits['max_operations'] - self.operations:
            raise _Limit('OPERATION_LIMIT')
        self.operations += units
        self.by_kind[kind] = self.by_kind.get(kind, 0) + units

    def keep(self):
        if self.counts['retained_configuration_rows'] >= self.limits['max_configurations']:
            raise _Limit('CONFIGURATION_LIMIT')
        self.counts['retained_configuration_rows'] += 1


def _limits(value):
    names = ('max_operations', 'max_configurations')
    if type(value) is not dict or len(value) != 2:
        raise _Invalid('INVALID_LIMITS')
    if any(type(key) is not str for key in value) or set(value) != set(names):
        raise _Invalid('INVALID_LIMITS')
    if any(type(value[key]) is not int or value[key] < 1 for key in names):
        raise _Invalid('INVALID_LIMITS')
    return {key: value[key] for key in names}


def _name(value, budget):
    budget.visit('grammar')
    if type(value) is not str:
        raise _Invalid('NAME_TYPE')
    budget.visit('characters', len(value))
    return value


def _fields(value, names, budget):
    budget.visit('grammar')
    if type(value) is not dict:
        raise _Invalid('RECORD_TYPE')
    for key in value:
        _name(key, budget)
    if len(value) != len(names) or any(key not in value for key in names):
        raise _Invalid('RECORD_FIELDS')


def _names(value, budget, allow_empty=False):
    budget.visit('grammar')
    if type(value) is not list or (not allow_empty and not value):
        raise _Invalid('NONEMPTY_NAME_ARRAY')
    result, seen = [], set()
    for item in value:
        name = _name(item, budget)
        if name in seen:
            raise _Invalid('DUPLICATE_NAME')
        seen.add(name)
        result.append(name)
    return result, seen


def _machine(value, budget):
    _fields(value, ('states', 'alphabet', 'transitions', 'start', 'accept'), budget)
    states, state_set = _names(value['states'], budget)
    alphabet, alphabet_set = _names(value['alphabet'], budget)
    start = _name(value['start'], budget)
    accept, accept_set = _names(value['accept'], budget, allow_empty=True)
    if start not in state_set or not accept_set <= state_set:
        raise _Invalid('START_OR_ACCEPT_STATE')
    if type(value['transitions']) is not list:
        raise _Invalid('TRANSITION_ARRAY')
    original, effective, seen = [], [], set()
    for raw in value['transitions']:
        budget.visit('grammar')
        if type(raw) is not list or len(raw) != 5:
            raise _Invalid('TRANSITION_ROW')
        q, read = _name(raw[0], budget), _name(raw[1], budget)
        next_state, write = _name(raw[2], budget), _name(raw[3], budget)
        move = raw[4]
        if (q not in state_set or next_state not in state_set or
                read not in alphabet_set or write not in alphabet_set):
            raise _Invalid('TRANSITION_SYMBOL_OR_STATE')
        if type(move) is not int or move not in (-1, 0, 1):
            raise _Invalid('TRANSITION_MOVE')
        row = (q, read, next_state, write, move)
        if row in seen:
            raise _Invalid('DUPLICATE_TRANSITION')
        seen.add(row)
        original.append(list(row))
        budget.counts['transition_rows'] += 1
        if q in accept_set:
            if next_state != q or write != read or move != 0:
                raise _Invalid('NONIDENTITY_ACCEPT_OUTGOING')
            budget.counts['folded_accept_identities'] += 1
        else:
            effective.append(row)
            budget.counts['effective_transition_rows'] += 1
    detached = {'states': states, 'alphabet': alphabet, 'transitions': original,
                'start': start, 'accept': accept}
    return detached, state_set, alphabet_set, effective


def _initial(value, states, alphabet, budget):
    _fields(value, ('state', 'head', 'tape'), budget)
    state = _name(value['state'], budget)
    if state not in states:
        raise _Invalid('INITIAL_STATE')
    tape = value['tape']
    if type(tape) is not list or not tape:
        raise _Invalid('NONEMPTY_INTERIOR_TAPE')
    symbols = []
    for symbol in tape:
        symbol = _name(symbol, budget)
        if symbol not in alphabet:
            raise _Invalid('INITIAL_TAPE_SYMBOL')
        symbols.append(symbol)
    head = value['head']
    if type(head) is not int or not 0 <= head < len(symbols):
        raise _Invalid('INITIAL_HEAD')
    return (state, head, tuple(symbols))


def _configuration(value):
    return {'state': value[0], 'head': value[1], 'tape': list(value[2])}


def _insert(value, seen, discovery, accept, budget):
    budget.visit('unique_insertion', len(value[2]) + 3)
    if value in seen:
        budget.counts['duplicate_successors'] += 1
        return
    budget.keep()
    seen.add(value)
    discovery.append(value)
    if value[0] in accept:
        budget.counts['prefix_acceptance_seen'] = True


def _layer(step, configurations, tape_length, accept, budget):
    count = len(configurations)
    budget.visit('canonical_order', count * max(1, count.bit_length()) * (tape_length + 2))
    ordered = sorted(configurations)
    budget.visit('snapshot_rows', count * (tape_length + 3))
    row = {'step': step, 'configurations': [_configuration(c) for c in ordered],
           'count': count, 'accepting_count': sum(c[0] in accept for c in ordered)}
    budget.counts['completed_layers'] += 1
    return row, ordered


def _receipt(budget, status, reason, snapshot, layers, partial, partial_step):
    complete = status == 'COMPLETE'
    witness = None
    if complete:
        for layer in layers:
            if layer['accepting_count']:
                for config in layer['configurations']:
                    if config['state'] in snapshot['machine']['accept']:
                        witness = {'first_step': layer['step'], 'configuration': {
                            'state': config['state'], 'head': config['head'],
                            'tape': list(config['tape'])}}
                        break
                break
    return {'schema': SCHEMA, 'status': status, 'reason': reason, 'input': snapshot,
            'limits': None if budget is None else dict(budget.limits),
            'layers': layers, 'partial_layer': (None if partial is None else {
                'step': partial_step, 'configurations': [_configuration(c) for c in partial],
                'count': len(partial), 'complete': False, 'order': 'DISCOVERY_DIAGNOSTIC'}),
            'complete': complete, 'steps_completed': len(layers) - 1,
            'acceptance': {'ever': None if not complete else witness is not None,
                           'at_requested_step': None if not complete else bool(layers[-1]['accepting_count']),
                           'witness': witness},
            'counts': {} if budget is None else dict(budget.counts),
            'costs': {'operations': 0 if budget is None else budget.operations,
                      'by_kind': {} if budget is None else dict(budget.by_kind)}, 'scope': _SCOPE}


def simulate(machine, initial, steps, limits):
    """Enumerate all bounded global layers. No partial-layer completeness claim."""
    budget, snapshot = None, None
    layers, partial, partial_step = [], None, None
    try:
        budget = _Budget(_limits(limits))
        normalized, states, alphabet, effective = _machine(machine, budget)
        first = _initial(initial, states, alphabet, budget)
        budget.visit('grammar')
        if type(steps) is not int or steps < 0:
            raise _Invalid('STEPS_TYPE_OR_RANGE')
        snapshot = {'machine': normalized, 'initial': _configuration(first), 'steps': steps,
                    'effective_transitions': [list(row) for row in effective]}
        index = {}
        for q, symbol, qnext, write, move in effective:
            budget.visit('transition_preparation')
            index.setdefault((q, symbol), []).append((qnext, write, move))
        accept = set(normalized['accept'])
        width = len(first[2])
        partial, partial_step = [], 0
        initial_set = set()
        _insert(first, initial_set, partial, accept, budget)
        row, current = _layer(0, initial_set, width, accept, budget)
        layers.append(row)
        partial = None
        for step in range(1, steps + 1):
            budget.visit('layer')
            seen, partial, partial_step = set(), [], step
            for state, head, tape in current:
                budget.visit('configuration')
                budget.counts['configurations_processed'] += 1
                if state in accept:
                    budget.counts['implicit_accept_successors'] += 1
                    budget.visit('implicit_accept')
                    _insert((state, head, tape), seen, partial, accept, budget)
                    continue
                for qnext, write, move in index.get((state, tape[head]), ()):
                    budget.visit('transition')
                    budget.counts['transition_checks'] += 1
                    destination = head + move
                    if destination < 0 or destination >= width:
                        budget.counts['off_interval_moves'] += 1
                        continue
                    budget.visit('tape_copy', width)
                    changed = list(tape)
                    changed[head] = write
                    _insert((qnext, destination, tuple(changed)), seen, partial, accept, budget)
            row, current = _layer(step, seen, width, accept, budget)
            layers.append(row)
            partial = None
        return _receipt(budget, 'COMPLETE', 'ALL_EXACT_LAYERS_ENUMERATED', snapshot,
                        layers, None, None)
    except _Invalid as error:
        return _receipt(budget, 'REJECTED', str(error), snapshot, layers, partial, partial_step)
    except _Limit as error:
        return _receipt(budget, 'UNKNOWN_BUDGET', str(error), snapshot, layers, partial, partial_step)
    except MemoryError:
        return _receipt(budget, 'UNKNOWN_BUDGET', 'HOST_MEMORY_LIMIT', snapshot,
                        layers, partial, partial_step)
