"""Administrative provisional Y evidence census/copy, never a scientific caller.
No ZIP creation. Final Root reader/admission/UI and independent package review
remain required. Original bytes are copied unchanged into a fresh staging tree.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import time
import zlib

Y=Path('/private/tmp/gcts-receptor-family-generation-20261028-v1')
OWN=Path('/private/tmp/gcts-B-Y-package-v1')
STAGE=OWN/'staged-originals-v1'
PEER_DIRS=[Path('/private/tmp')/name for name in (
 'gcts-B-Y-catalogue-audit-Source-peer-v1','gcts-B-Y001-passive-review-v1',
 'gcts-B-Y002-passive-review-v1','gcts-B-Y-publication-Source-peer-v1',
 'gcts-L-Y-generator-Source-peer-v1','gcts-L-Y-experiment-Source-peer-v1',
 'gcts-L-Y-study002-mathematical-review-v1')]
FUTURE_DIRS={Y/'root/publication-receptor-family-proof-search-v1',
 Y/'publisher-receptor-family-proof-search-payload',Y/'root/publication-receptor-family-proof-search-api-v1',
 Y/'root/receptor-family-proof-search-live-TLS-verification-v1'}
started=time.time_ns();included={};excluded={};expected={};json_sources=[]
def body(path):
 assert path.is_absolute() and not path.is_symlink()
 before=path.stat();assert stat.S_ISREG(before.st_mode)
 raw=path.read_bytes();after=path.stat()
 assert len(raw)==before.st_size==after.st_size and (before.st_ino,before.st_mtime_ns)==(after.st_ino,after.st_mtime_ns)
 return raw
def ref(path,raw=None):
 if raw is None:raw=body(path)
 return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def add(path,why,pin=None,scan=False):
 path=Path(path)
 if pin is not None:
  old=expected.get(path);assert old is None or old==pin;expected[path]=pin
 included.setdefault(path,set()).add(why)
 if scan and path.suffix=='.json' and path not in json_sources:json_sources.append(path)
def refs(value):
 if type(value)is dict:
  if set(('path','bytes','sha256'))<=set(value) and type(value['path'])is str and type(value['bytes'])is int and type(value['sha256'])is str:yield {k:value[k]for k in ('path','bytes','sha256')}
  for v in value.values():yield from refs(v)
 elif type(value)is list:
  for v in value:yield from refs(v)
def excluded_reason(path):
 if any(path==x or x in path.parents for x in FUTURE_DIRS):return 'Future web payload twins/publication/TLS outputs outside this provisional original-evidence cut.'
 if path.suffix.lower()in ('.zip','.7z','.tar','.xz'):return 'No recursive old archive or generated package included.'
 return None
for path in sorted(Y.rglob('*')):
 if not path.is_file():continue
 why=excluded_reason(path)
 if why:excluded[str(path)]=why;continue
 add(path,'Y original tree snapshot',scan='/actual/'not in str(path))
for directory in PEER_DIRS:
 assert directory.is_dir()
 for path in sorted(directory.rglob('*')):
  if path.is_file():add(path,'Complete current external Y independent-review directory',scan=True)
for number in ('001','002'):
 plan=json.loads(body(Y/('root/study-once-plan-'+number+'.json')))
 for group in ('sources','metadata'):
  for role,pin in plan[group].items():
   path=Path(pin['path'])
   if role=='master'and not str(path).startswith('/private/tmp/'):
    excluded[str(path)]='Historical repository master read path; exact21657/c132 body archived via immutable Y master copy. Repository/cloud placeholder not reread.';continue
   add(path,'Exact '+number+' '+group+' role '+role,pin,scan=group=='metadata')
 add(Path(plan['bootstrap']['path']),'Exact authenticated344byte bootstrap',plan['bootstrap'])
 excluded[plan['python']['path']]='Runtime binary pinned in plans/ABIs; not vendored or executed.'
 manifest=json.loads(body(Path(plan['metadata']['donor_manifest']['path'])))
 for donor in manifest['donors']:add(Path(donor['source_ref']['path']),'Exact one of six allowed raw W donor proof inputs',donor['source_ref'])
# Bounded direct Source/ABI/preservation ancestors and complete peer support refs.
# This does not crawl old actuals/archives or recurse entire historical projects.
original_json=list(json_sources)
for path in original_json:
 try:value=json.loads(body(path))
 except (UnicodeError,json.JSONDecodeError):continue
 for pin in refs(value):
  dep=Path(pin['path'])
  if dep in included:expected.setdefault(dep,pin);continue
  if not str(dep).startswith('/private/tmp/'):
   excluded.setdefault(str(dep),'External runtime/repository path pinned only; protected/broad repository reads forbidden.');continue
  why=excluded_reason(dep)
  if why:excluded[str(dep)]=why;continue
  if '/actual/'in str(dep):
   excluded.setdefault(str(dep),'Historical actual outside both Y attempts and exact six donor inputs; no recursive old cohort.');continue
  if not dep.is_file():excluded.setdefault(str(dep),'Historical exact ref unavailable; not reconstructed.');continue
  add(dep,'Direct immutable Source/API/peer/provenance ref from '+str(path),pin)
# One exact metadata support hop for explicitly included external peer receipts.
for path in list(included):
 if path.suffix!='.json'or str(path).startswith(str(Y))or path in original_json:continue
 try:value=json.loads(body(path))
 except (UnicodeError,json.JSONDecodeError):continue
 for pin in refs(value):
  dep=Path(pin['path'])
  if dep in included:expected.setdefault(dep,pin);continue
  if str(dep).startswith('/private/tmp/')and '/actual/'not in str(dep)and dep.is_file()and not excluded_reason(dep):add(dep,'Exact support/Source ref of included external metadata',pin)
  else:excluded.setdefault(str(dep),'Beyond bounded source/support closure; old actual/archive/runtime/repository not recursively imported.')
# Freeze the administrative packager Source itself before manifest/catalogue.
add(Path(__file__),'Administrative package inventory/copy Source; no scientific imports or ZIP creation')
assert not STAGE.exists();STAGE.mkdir()
rows=[];names=set();compressed=0
for path in sorted(included,key=str):
 raw=body(path);pin=ref(path,raw)
 if path in expected:assert pin==expected[path],(str(path),pin,expected[path])
 if str(path).startswith(str(Y)+'/'):name='Y/'+str(path.relative_to(Y))
 else:assert str(path).startswith('/private/tmp/');name='external/'+str(path.relative_to('/private/tmp'))
 assert name not in names and not name.startswith('/')and all(x not in ('','.','..')for x in name.split('/'));names.add(name)
 dest=STAGE/name;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb')as f:f.write(raw)
 assert body(dest)==raw
 co=zlib.compressobj(6,zlib.DEFLATED,-15);size=0
 for i in range(0,len(raw),65536):size+=len(co.compress(raw[i:i+65536]))
 size+=len(co.flush());compressed+=size
 rows.append({'original':pin,'member':name,'staged':ref(dest,raw),'reasons':sorted(included[path]),'DEFLATE6_estimate_bytes':size})
assert len(rows)==len(names)
name_overhead=sum(30+46+2*len(r['member'].encode())for r in rows)+22
out={'schema':'Y-provisional-complete-evidence-inventory-v1','status':'PROVISIONAL_PRECOPY_NO_ZIP_NOT_SELF_ADMITTED','enumeration_started_unix_ns':started,'completed_unix_ns':time.time_ns(),'staging':str(STAGE),'originals':rows,'original_count':len(rows),'original_bytes':sum(r['original']['bytes']for r in rows),'DEFLATE6_payload_estimate_bytes':compressed,'estimated_ZIP_local_central_overhead_bytes':name_overhead,'estimated_ZIP_before_manifest_README_and_future_inputs_bytes':compressed+name_overhead,'archive_cap_bytes':67108864,'recommended_manifest_README_future_input_reserve_bytes':4194304,'explicit_exclusions':[{'path':k,'reason':v}for k,v in sorted(excluded.items())],'external_peer_directories':[str(p)for p in PEER_DIRS],'both_attempts':{'study001':'All197physical originals permanently UNADMITTED; no scientific promotion.','study002':'All203physical originals primary admitted cohort; all records not a selected prefix.'},'pending_before_finalcut':['Root final reader/results exact bytes','Root local UI QA originals/receipts','Root final scientific/content adoption','Root approved final package cut/census and independent content/package review'],'cut':'Future payload twins, package outputs/catalogue itself and publication/TLS/live authorities/captures/receipts excluded to avoid circular self-reference. All current scientific plans/A6/consumption/outer captures/adoptions andSource variants included. New metadata after this provisional enumeration requires a fresh final staging/inventory revision.','subject_calls':0,'ZIP_files_created':0}
p=OWN/'Y-provisional-evidence-inventory-v1.json';p.write_bytes((json.dumps(out,sort_keys=True,indent=2)+'\n').encode());print(json.dumps({'inventory':ref(p),'original_count':out['original_count'],'original_bytes':out['original_bytes'],'estimated_ZIP_bytes_before_manifest_and_future':compressed+name_overhead,'exclusion_count':len(excluded)},sort_keys=True))
