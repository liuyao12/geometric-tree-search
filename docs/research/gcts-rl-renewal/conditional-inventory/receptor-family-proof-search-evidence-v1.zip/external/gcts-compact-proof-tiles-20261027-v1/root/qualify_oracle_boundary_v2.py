"""INERT independent finite oracle/boundary regression qualification.

316 primary controls, with separately counted native/preparation support. No IO
or project imports. Only a future reviewed caller may invoke qualify. Diagnostic
programs and GIVEN formula literals are authored controls, never discovered
mathematical proofs. Actual C1 is not compiled or invoked here.
"""
import hashlib
import json

VERSION = 'R-INDEPENDENT-ORACLE-BOUNDARY-QUALIFICATION-v2'
EXPECTED = {'observer_calls': 280, 'boundary_calls': 36, 'native_runs': 271,
            'native_heaps': 271, 'native_validations': 0, 'compilations': 11,
            'declarations': 11, 'carrier_builds': 12, 'codec_calls': 0,
            'emissions': 328, 'primary_controls': 316}


class QualificationError(Exception):
    pass


class _ForeignSentinel(Exception):
    pass


def _need(ok, text):
    if not ok:
        raise QualificationError(text)


def _image(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _copy(value):
    return json.loads(_image(value))


def _sha(value):
    return hashlib.sha256(_image(value).encode('ascii')).hexdigest()


def _observer_limits(**change):
    limits = {'max_operations': 20000000, 'max_steps': 1000000,
              'max_heap_nodes': 200000, 'max_frames': 10000,
              'max_trace_records': 64, 'max_dependencies': 16384,
              'max_input_items': 5000000, 'max_milliseconds': 60000}
    limits.update(change)
    return limits


def _boundary_limits(**change):
    limits = {'max_operations': 1000000, 'max_depth': 64, 'max_nodes': 100000,
              'max_name_bytes': 128, 'max_output_bytes': 16384,
              'max_byte_count': 16384}
    limits.update(change)
    return limits


def _carrier_limits():
    return {'max_operations': 20000000, 'max_nodes': 200000,
            'max_stream_bytes': 16384, 'max_selected_cells': 2000000,
            'max_physical_cells': 2001000}


def _diagnostics():
    navigate = '    rows = head(tail(tail(input)))\n    row = head(rows)\n'
    return {
      'watch': 'def main(input):\n' + navigate + '    byte = head(row)\n    return atom_eq(byte, 255)\n',
      'alias': 'def main(input):\n' + navigate + '    alias = cons(7, tail(row))\n    return False\n',
      'zero': 'def main(input):\n    return False\n',
      'true': 'def main(input):\n    return True\n',
      'other': 'def main(input):\n    rows = head(tail(tail(input)))\n    return head(rows)\n',
      'fault-succ': 'def main(input):\n    return byte_succ(255)\n',
      'fault-head': 'def main(input):\n    return head(0)\n',
      'fault-tail': 'def main(input):\n    return tail(0)\n',
      'fault-not': 'def main(input):\n    return not 2\n',
      'fault-branch': 'def main(input):\n    if 2:\n        return True\n    return False\n',
      'opcodes': '''def main(input):
    a = 0
    b = 1
    c = 127
    d = 128
    e = 254
    f = 255
    n = None
    pair = cons(a, n)
    copied = pair
    if not is_pair(copied):
        return False
    if not atom_eq(head(copied), a) or not atom_eq(tail(copied), n):
        return False
    if not atom_eq(byte_succ(c), d) or not atom_eq(byte_succ(e), f):
        return False
    if is_pair(a) or atom_eq(pair, pair):
        return False
    result = outer(b)
    if not result or not atom_eq(c, 127) or not atom_eq(e, 254):
        return False
    while not atom_eq(a, b):
        a = byte_succ(a)
    return atom_eq(a, b)
def outer(x):
    keep = 128
    result = inner(x)
    return result and atom_eq(keep, 128)
def inner(x):
    return not not x
'''}


def _formula_cases():
    x = ['var', 'x']
    y = ['var', 'y']
    q = ['pred', 'Q', []]
    return [
      ('bot', ['bot'], [48]),
      ('eq', ['eq', x, x], [49, 32, 120, 0, 32, 120, 0]),
      ('pred-empty', q, [50, 81, 0, 65]),
      ('pred-arg', ['pred', 'P', [x]], [50, 80, 0, 64, 32, 120, 0, 65]),
      ('constant', ['eq', ['fun', 'c', []], x], [49, 33, 99, 0, 65, 32, 120, 0]),
      ('nested-terms', ['eq', ['fun', 'f', [x, ['fun', 'c', []]]], y],
       [49, 33, 102, 0, 64, 32, 120, 0, 64, 33, 99, 0, 65, 65, 32, 121, 0]),
      ('not', ['not', q], [51, 50, 81, 0, 65]),
      ('and', ['and', ['bot'], ['bot']], [52, 48, 48]),
      ('or', ['or', ['bot'], ['bot']], [53, 48, 48]),
      ('imp', ['imp', ['bot'], ['bot']], [54, 48, 48]),
      ('all', ['all', 'x', ['pred', 'P', [x]]], [55, 120, 0, 50, 80, 0, 64, 32, 120, 0, 65]),
      ('ascii-nesting', ['all', ' !~', ['all', 'x', ['eq', ['var', ' !~'], x]]],
       [55, 32, 33, 126, 0, 55, 120, 0, 49, 32, 32, 33, 126, 0, 32, 120, 0])]


def _choose(carrier, values):
    c = carrier['value']
    _need(len(values) == c['byte_count'], 'complete byte choice')
    nodes = _copy(c['nodes'])
    for row, value in zip(c['byte_rows'], values, strict=True):
        _need(type(value) is int and 0 <= value <= 255, 'byte type')
        nodes[row['node_index']][0] = value
    return nodes


def qualify(native_vm, carrier, oracle, boundary, emit):
    """Return COMPLETE_PASS after all316 primary cases, else propagate failure.

    The eleven fixed diagnostic Sources use native_vm.Compiler, not the compact
    NTM compiler. Twelve direct formal wire expectations avoid any proof line
    or skeleton. The actual C1 program is not an argument or invoked here.
    emit(record) stores each full record under its safe unique record['id'] and
    may return an opaque caller-owned reference; no filesystem operations here.
    """
    compiler = native_vm.Compiler
    observer = oracle
    _need(callable(compiler) and callable(emit), 'caller compiler/emitter')
    counts = {name: 0 for name in EXPECTED}
    refs = []
    prepared = {}
    theory = {'functions': {}, 'predicates': {}, 'axioms': {}, 'schemas': []}
    goal = ['bot']

    def call(name, fn, *args, **kwargs):
        counts[name] += 1
        return fn(*args, **kwargs)

    def record(label, kind, data, checks):
        fullid = 'oracle-qualification-' + label
        _need(all(c.isascii() and (c.isalnum() or c in '.-') for c in fullid), 'safe emit label')
        payload = {'schema': 'R-oracle-boundary-qualification-case-v1', 'id': fullid,
                   'kind': kind, 'data': data, 'checks': checks,
                   'passed': all(type(v) is bool and v for v in checks.values())}
        counts['emissions'] += 1
        ref = emit(payload)
        refs.append({'id': fullid, 'reference': ref})
        _need(payload['passed'], 'qualification assertion: ' + fullid)
        return payload

    def prepare(label, p, size, source):
        c = call('carrier_builds', carrier.build_carrier, p, _copy(theory), _copy(goal), size, _carrier_limits())
        row = record('prepare-' + label, 'PREPARATION',
                     {'program': p, 'diagnostic_Source': source, 'carrier': c,
                      'known_theory': theory, 'known_goal': goal,
                      'input_role': 'input_node'},
                     {'byte_count': c['value']['byte_count'] == size,
                      'current_carrier_version': c['value']['version'] == 'RAW-PROOF-BYTE-CARRIER-MIN8-v2'})
        prepared[label] = {'program': p, 'carrier': c, 'reference': refs[-1]}
        return row

    def pair(label, prepared_id, values, expected, limits=None):
        item = prepared[prepared_id]
        p, c = item['program'], item['carrier']
        before = _sha([p, c, values])
        selected = _choose(c, values)
        heap = call('native_heaps', native_vm.Heap, selected, limit=200000)
        native = call('native_runs', native_vm.run, p, heap, c['value']['input_node'], limit=1000000, keep=100000)
        lim = _observer_limits() if limits is None else limits
        observed = call('observer_calls', observer.observe, p, c, list(values), lim)
        counts['primary_controls'] += 1
        normal = 'value' in native
        binding = {'program_sha256': _sha(p), 'carrier_value_sha256': _sha(c['value']),
                   'theory_sha256': _sha(c['value']['known']['theory']),
                   'goal_sha256': _sha(c['value']['known']['target']),
                   'byte_count': len(values), 'boundary_version': 'R-GIVEN-GOAL-WIRE-BOUNDARY-v1',
                   'carrier_version': 'RAW-PROOF-BYTE-CARRIER-MIN8-v2',
                   'oracle_version': 'R-BYTE-DEPENDENCY-TREE-VM-v1'}
        ovm = observed['vm'] if type(observed.get('vm')) is dict else {}
        cut = observed.get('cut')
        native_ordinary = _copy(native)
        observed_ordinary = _copy(ovm)
        native_ordinary.pop('seconds', None)
        observed_ordinary.pop('seconds', None)
        native_ordinary['trace'] = native_ordinary['trace'][:lim['max_trace_records']]
        if expected == 'ACCEPTED':
            native_category = (native.get('status') == 'accepted'
                               and type(native.get('value')) is int and native['value'] == 1)
        elif expected == 'CERTIFIED_REJECTION':
            native_category = (native.get('status') == 'rejected'
                               and type(native.get('value')) is int and native['value'] == 0)
        elif expected == 'NORMAL_OTHER_RETURN':
            native_category = (native.get('status') == 'rejected'
                               and type(native.get('value')) is int
                               and native['value'] == c['value']['byte_rows'][0]['node_id']
                               and native['value'] > 256)
        elif expected == 'UNKNOWN_FAULT':
            native_category = (native.get('status') == 'rejected' and 'value' not in native
                               and type(native.get('reason')) is str
                               and native['reason'].startswith('invalid data operation: ')
                               and type(native.get('function')) is str
                               and type(native.get('pc')) is int and native['pc'] >= 0)
        else:
            native_category = False
        checks = {'status': observed['status'] == expected,
                  'independent_native_expected_category': native_category,
                  'whole_ordinary_VM_receipt_except_seconds_and_trace_prefix':
                      _image(native_ordinary) == _image(observed_ordinary),
                  'full_actual_context_binding': _image(observed['binding']) == _image(binding),
                  'native_and_observer_no_input_mutation': before == _sha([p, c, values]),
                  'full_final_heap': _image(heap.nodes) == _image(observed['final_heap']),
                  'event_hash': native['event_sha256'] == ovm.get('event_sha256'),
                  'steps': native['steps'] == ovm.get('steps'),
                  'profile': native['profile'] == ovm.get('profile'),
                  'peak_frames': native['peak_frames'] == ovm.get('peak_frames'),
                  'trace_prefix': ovm.get('trace', []) == native['trace'][:lim['max_trace_records']]}
        if normal:
            checks['normal_value'] = ovm.get('value') == native['value']
            checks['full_event_extent'] = observed['trace_extent']['total_events'] == native['steps']
        else:
            checks['fault_no_value'] = 'value' not in ovm
        if expected == 'CERTIFIED_REJECTION':
            checks['certified_cut'] = native.get('value') == 0 and observed['cut'] is not None and observed['cut']['value'] == 0
            checks['literal_values'] = type(cut) is dict and cut.get('literals') == sorted([[r['byte_index'], values[r['byte_index']]] for r in observed['dependencies']])
            checks['cut_full_context_and_hash'] = type(cut) is dict and cut.get('schema') == 'R-certified-byte-rejection-cut-v1' and _image(cut.get('binding')) == _image(binding) and cut.get('trace_sha256') == native['event_sha256'] and type(cut.get('value')) is int
        else:
            checks['no_cut'] = observed['cut'] is None
        if prepared_id == 'watch' or prepared_id == 'unread':
            checks['one_HEAD_dependency'] = len(observed['dependencies']) == 1 and observed['dependencies'][0]['byte_index'] == 0 and observed['dependencies'][0]['head_reads'] == 1 and observed['dependencies'][0]['cons_alias_consults'] == 0
        if prepared_id == 'alias':
            checks['HIT_or_MISS_tail_watch'] = len(observed['dependencies']) == 1 and observed['dependencies'][0]['byte_index'] == 0 and observed['dependencies'][0]['cons_alias_consults'] == 1 and observed['dependencies'][0]['head_reads'] == 0
            checks['heap_HIT_or_MISS_extent'] = len(observed['final_heap']) == len(selected) + int(values[0] != 7)
        if prepared_id == 'opcodes':
            checks['all13_executed'] = {r[2] for r in native['trace']} == {'const', 'move', 'cons', 'head', 'tail', 'pair', 'atom', 'succ', 'not', 'branch', 'jump', 'call', 'return'}
            checks['nested_frames'] = native['peak_frames'] >= 2
        if prepared_id == 'zero':
            checks['empty_cut'] = observed['dependencies'] == [] and type(cut) is dict and cut.get('literals') == []
        if limits is not None and lim['max_trace_records'] in (0, 1):
            checks['prefix_does_not_truncate_evaluator'] = observed['trace_extent']['complete_prefix'] is False and observed['trace_extent']['total_events'] > len(ovm.get('trace', []))
        record(label, 'NATIVE_OBSERVER_PAIR',
               {'preparation': item['reference'], 'byte_values': values, 'observer_limits': lim,
                'native': native, 'native_final_heap': _copy(heap.nodes), 'observer': observed}, checks)
        return observed

    diagnostics = _diagnostics()
    for label, source in diagnostics.items():
        compiled = call('compilations', compiler, source)
        p = call('declarations', compiled.declaration)
        prepare(label, p, 1, source)
    prepare('unread', prepared['watch']['program'], 2, None)

    for value in range(256):
        pair('byte-' + str(value).zfill(3), 'watch', [value], 'ACCEPTED' if value == 255 else 'CERTIFIED_REJECTION')
    pair('cons-HIT', 'alias', [7], 'CERTIFIED_REJECTION')
    pair('cons-MISS', 'alias', [8], 'CERTIFIED_REJECTION')
    first = pair('unread-a', 'unread', [5, 0], 'CERTIFIED_REJECTION')
    second = pair('unread-b', 'unread', [5, 255], 'CERTIFIED_REJECTION')
    _need(first['vm']['event_sha256'] == second['vm']['event_sha256'] and first['cut']['literals'] == second['cut']['literals'] == [[0, 5]], 'agreeing unread completion sample')
    pair('empty-watch-cut', 'zero', [123], 'CERTIFIED_REJECTION')
    pair('normal-true', 'true', [123], 'ACCEPTED')
    pair('normal-data-node', 'other', [123], 'NORMAL_OTHER_RETURN')
    pair('all-opcodes', 'opcodes', [123], 'ACCEPTED')
    for name in ('fault-succ', 'fault-head', 'fault-tail', 'fault-not', 'fault-branch'):
        pair(name, name, [123], 'UNKNOWN_FAULT')
    pair('trace-zero', 'watch', [5], 'CERTIFIED_REJECTION', _observer_limits(max_trace_records=0))
    pair('trace-one', 'watch', [5], 'CERTIFIED_REJECTION', _observer_limits(max_trace_records=1))
    limited = [('operations', 'watch', [5], {'max_operations': 0}),
               ('steps', 'watch', [5], {'max_steps': 0}),
               ('input', 'watch', [5], {'max_input_items': 0}),
               ('initial-heap', 'watch', [5], {'max_heap_nodes': 0}),
               ('dependency', 'watch', [5], {'max_dependencies': 0}),
               ('frames', 'opcodes', [123], {'max_frames': 0}),
               ('runtime-heap', 'alias', [8], {'max_heap_nodes': len(prepared['alias']['carrier']['value']['nodes'])}),
               ('time', 'watch', [5], {'max_milliseconds': 0})]
    for label, item_id, values, changes in limited:
        item = prepared[item_id];limits = _observer_limits(**changes)
        answer = call('observer_calls', observer.observe, item['program'], item['carrier'], values, limits)
        counts['primary_controls'] += 1
        record('refusal-' + label, 'OWNED_OBSERVER_REFUSAL',
               {'preparation': item['reference'], 'byte_values': values, 'limits': limits, 'observer': answer},
               {'UNKNOWN_not_negative': answer['status'] == 'UNKNOWN_BUDGET' and answer['cut'] is None})

    def foreign():
        raise _ForeignSentinel('independent qualification foreign callback')

    for label, fn, args, kwargs, counter in [
            ('observer-foreign', observer.observe,
             (prepared['watch']['program'], prepared['watch']['carrier'], [5], _observer_limits()), {'budget': foreign}, 'observer_calls')]:
        caught = None
        returned = None
        try:
            returned = call(counter, fn, *args, **kwargs)
        except _ForeignSentinel as error:
            caught = {'type': type(error).__name__, 'message': str(error)}
        counts['primary_controls'] += 1
        record(label, 'FOREIGN_CALLBACK_PROPAGATION', {'exception': caught, 'unexpected_return': returned}, {'exact_foreign_exception': caught is not None})

    def boundary_case(label, formula, size, limits, expected_status, expected_wire=None, descriptor=None):
        before = None if descriptor is not None else _sha(formula)
        answer = call('boundary_calls', boundary.encode_goal_boundary, formula, size, limits)
        counts['primary_controls'] += 1
        checks = {'expected_status': answer['status'] == expected_status}
        if descriptor is None:
            checks['no_input_mutation'] = before == _sha(formula)
        if expected_status == 'COMPLETE':
            start = size - len(expected_wire) - 1
            fixed = [[0, 1], [1, 16]] + [[start + i, b] for i, b in enumerate(expected_wire)] + [[size - 1, 17]]
            checks['full_formal_goal_wire'] = answer['goal_wire_hex'] == bytes(expected_wire).hex()
            checks['exact_given_boundary_only'] = answer['fixed_bytes'] == fixed and start >= 3 and all(i != 2 for i, _ in fixed)
            checks['minimum'] = answer['minimum_stream_bytes'] == len(expected_wire) + 4
        else:
            checks['no_partial_boundary'] = answer['fixed_bytes'] == [] and answer['goal_wire_hex'] is None
        if expected_status == 'EMPTY_CAPACITY':
            checks['minimum_retained'] = answer['minimum_stream_bytes'] == len(expected_wire) + 4
        record('boundary-' + label, 'GIVEN_FORMULA_ONLY_BOUNDARY',
               {'given_formula': descriptor if descriptor is not None else formula,
                'byte_count': size, 'limits': limits, 'formal_expected_wire': expected_wire,
                'boundary': answer}, checks)

    formulas = _formula_cases()
    for name, formula, expected_wire in formulas:
        minimum = len(expected_wire) + 4
        boundary_case(name + '-exact', formula, minimum, _boundary_limits(), 'COMPLETE', expected_wire)
        boundary_case(name + '-short', formula, minimum - 1, _boundary_limits(), 'EMPTY_CAPACITY', expected_wire)
    malformed = [('tag', ['unknown'], None), ('empty-name', ['pred', '', []], None),
                 ('nonascii', ['pred', '\x7f', []], None),
                 ('tuple', ('bot',), {'python_type': 'tuple', 'items': ['bot']})]
    cyclic = ['not', None]
    cyclic[1] = cyclic
    malformed.append(('cycle', cyclic, {'python_graph': 'node0=list', 'items': ['not', {'ref': 'node0'}]}))
    for name, formula, descriptor in malformed:
        boundary_case('bad-' + name, formula, 64, _boundary_limits(), 'REJECTED_INPUT', descriptor=descriptor)
    for label, formula, changes in [('operations', ['bot'], {'max_operations': 0}),
            ('depth', ['all', 'x', ['bot']], {'max_depth': 0}),
            ('nodes', ['bot'], {'max_nodes': 0}),
            ('name', ['pred', 'Q', []], {'max_name_bytes': 0}),
            ('output', ['bot'], {'max_output_bytes': 0}),
            ('capacity', ['bot'], {'max_byte_count': 0})]:
        boundary_case('refusal-' + label, formula, 64, _boundary_limits(**changes), 'UNKNOWN_BUDGET')
    caught = None
    returned = None
    try:
        returned = call('boundary_calls', boundary.encode_goal_boundary, ['bot'], 5, _boundary_limits(), budget=foreign)
    except _ForeignSentinel as error:
        caught = {'type': type(error).__name__, 'message': str(error)}
    counts['primary_controls'] += 1
    record('boundary-foreign', 'FOREIGN_CALLBACK_PROPAGATION', {'given_formula': ['bot'], 'byte_count': 5, 'exception': caught, 'unexpected_return': returned}, {'exact_foreign_exception': caught is not None})
    _need(counts == EXPECTED, 'closed complete qualification call census')
    return {'schema': 'R-independent-oracle-boundary-qualification-v1',
            'status': 'COMPLETE_PASS', 'counts': dict(counts), 'emissions': refs,
            'scope': 'Authored finite regression qualification only. No discovered proof, Source-independent logical truth, Wang/physical FOL acceptance or complete proof search. Actual C1 is neither compiled nor invoked by this module; toy1 returns are generic VM tests, not proofs.'}
