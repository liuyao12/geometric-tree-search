"""Inert bounded unknown-byte proof search experiment; no supplied proof bodies.

The caller binds authenticated modules and a freshly compiled fixed C1 program.
Failure cuts come only from complete native zero returns. The point lane is a
native-oracle constraint-generation adaptation, not a literal Wang tableau.
"""
import hashlib
import json
import time

VERSION = 'R-UNKNOWN-BYTE-PROOF-SEARCH-v2'


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                    separators=(',', ':')).encode('ascii')).hexdigest()


def goal_cases():
    # Only signatures, GIVEN closed axioms and desired formulas occur here.
    x, y, n = ['var', 'x'], ['var', 'y'], ['var', 'n']
    zero = ['fun', '0', []]
    one = ['fun', 'S', [zero]]
    two = ['fun', 'S', [one]]
    base = {'functions': {'0': 0, 'S': 1, 'add': 2},
            'predicates': {'P': 0}, 'axioms': {}}
    p = ['pred', 'P', []]
    cases = [
        {'id': 'raw-reflexivity', 'family': 'logic', 'theory': base,
         'goal': ['eq', x, x], 'raw_only': True},
        {'id': 'raw-propositional-identity', 'family': 'logic', 'theory': base,
         'goal': ['imp', p, p], 'raw_only': True},
        {'id': 'inventory-successor-reflexivity', 'family': 'logic', 'theory': base,
         'goal': ['eq', ['fun', 'S', [x]], ['fun', 'S', [x]]], 'raw_only': False},
        {'id': 'equality-symmetry', 'family': 'logic', 'theory': base,
         'goal': ['imp', ['eq', x, y], ['eq', y, x]], 'raw_only': False}]
    a, b = ['var', 'a'], ['var', 'b']
    arithmetic = {'functions': base['functions'], 'predicates': {}, 'axioms': {
        'add-zero': ['all', 'a', ['eq', ['fun', 'add', [a, zero]], a]],
        'add-successor': ['all', 'a', ['all', 'b', ['eq',
            ['fun', 'add', [a, ['fun', 'S', [b]]]],
            ['fun', 'S', [['fun', 'add', [a, b]]]]]]]}}
    cases.extend([
        {'id': 'addition-one-plus-one', 'family': 'arithmetic-fragment',
         'theory': arithmetic, 'goal': ['eq', ['fun', 'add', [one, one]], two],
         'raw_only': False},
        {'id': 'addition-right-one', 'family': 'arithmetic-fragment',
         'theory': arithmetic, 'goal': ['all', 'n', ['eq',
            ['fun', 'add', [n, one]], ['fun', 'S', [n]]]], 'raw_only': False}])
    A, B, l, m = [['var', v] for v in ('A', 'B', 'l', 'm')]
    def pred(name, *terms):
        return ['pred', name, list(terms)]
    def conjunction(formulas):
        result = formulas[-1]
        for f in reversed(formulas[:-1]):
            result = ['and', f, result]
        return result
    guards = [pred('Point', A), pred('Point', B), pred('Line', l), pred('Line', m)]
    incidence = [pred('On', A, l), pred('On', B, l), pred('On', A, m), pred('On', B, m)]
    axiom = ['imp', conjunction(guards + [['not', ['eq', A, B]]] + incidence), ['eq', l, m]]
    for variable in reversed(('A', 'B', 'l', 'm')):
        axiom = ['all', variable, axiom]
    geometry = {'functions': {}, 'predicates': {'Point': 1, 'Line': 1, 'On': 2},
                'axioms': {'two-points-determine-at-most-one-line': axiom}}
    cases.append({'id': 'distinct-lines-common-points-coincide',
        'family': 'Hilbert-incidence-fragment', 'theory': geometry,
        'goal': ['imp', conjunction(guards + [['not', ['eq', l, m]]] + incidence),
                 ['eq', A, B]], 'raw_only': False})
    return cases


def direct_byte_solve(byte_count, fixed, cuts, preference, max_operations=20000000):
    """Simple conventional finite-domain control; same cuts and hints.

    Logical scan/copy operations are reserved before owned work. This control
    is not an optimized SAT/ATP baseline or an OS hard resource bound.
    """
    started = time.perf_counter()
    operations = scans = nodes = 0
    status, result = 'UNKNOWN', None
    class Exhausted(Exception):
        pass
    def charge(units):
        nonlocal operations
        if units > max_operations - operations:
            raise Exhausted()
        operations += units
    try:
        charge(byte_count + len(fixed))
        domains = [(1 << 256) - 1 for _ in range(byte_count)]
        for i, value in fixed:
            domains[i] = 1 << value
        frames = []
        while True:
            charge(1)
            nodes += 1
            dead, changed = False, True
            while changed and not dead:
                changed = False
                for cut in cuts:
                    charge(len(cut) + 1)
                    scans += 1
                    remaining, satisfied = [], False
                    for i, value in cut:
                        bit = 1 << value
                        if not domains[i] & bit:
                            satisfied = True
                            break
                        if domains[i] != bit:
                            remaining.append((i, bit))
                    if satisfied:
                        continue
                    if not remaining:
                        dead = True
                        break
                    if len(remaining) == 1:
                        i, bit = remaining[0]
                        domains[i] &= ~bit
                        changed = True
            charge(byte_count + 1)
            dead = dead or any(mask == 0 for mask in domains)
            if dead:
                if not frames:
                    status = 'UNSAT'
                    break
                domains, i, bit = frames.pop()
                domains[i] &= ~bit
                continue
            charge(byte_count)
            branch = next((i for i, mask in enumerate(domains) if mask.bit_count() > 1), None)
            if branch is None:
                charge(byte_count + 1)
                result = [mask.bit_length() - 1 for mask in domains]
                status = 'SAT'
                break
            mask = domains[branch]
            preferred = None if preference is None else preference[branch]
            bit = (1 << preferred) if preferred is not None and mask & (1 << preferred) else mask & -mask
            charge(byte_count + 1)
            frames.append((list(domains), branch, bit))
            domains[branch] = bit
    except Exhausted:
        status, result = 'UNKNOWN', None
    return {'status': status, 'byte_values': result, 'operations': operations,
            'clause_scans': scans, 'nodes': nodes,
            'seconds': time.perf_counter() - started}


def run(modules, program, emit, limits):
    """Closed seven-goal cohort, both lanes; all limits supplied prospectively.

    emit(name,data) durably records complete objects. Caller caps file/byte/time
    use and propagates failures. No negative is inferred from any UNKNOWN.
    """
    engine, oracle, boundary = (modules[k] for k in ('engine', 'oracle', 'boundary'))
    carrier, codec, checker, proposer = (modules[k] for k in ('carrier', 'codec', 'checker', 'proposer'))
    inventory = []
    results = []
    callback_receipts = []
    for case in goal_cases():
        case_id, theory, goal = case['id'], case['theory'], case['goal']
        theory_id = sha(theory)
        compatible_inventory = [{k: e[k] for k in ('id', 'formula', 'proof')}
                                for e in inventory if e['theory_sha256'] == theory_id]
        generation_started = time.perf_counter()
        generation = {'status': 'RAW_ONLY', 'proposal': None, 'seconds': None}
        proposal_bytes = None
        if not case['raw_only']:
            def tautology(formula):
                answer = checker.check(theory, [{'rule': 'tautology', 'formula': formula}],
                                       formula, limits['checker'])
                callback_receipts.append({'case': case_id, 'formula': formula, 'receipt': answer})
                return answer['status']
            try:
                stream = proposer.propose(theory, goal, compatible_inventory,
                                          limits['proposer'], tautology_test=tautology)
                proposal = next(stream, None)
                if proposal is not None:
                    generation.update(status='UNVERIFIED_PROPOSAL', proposal=proposal)
                    encoded = codec.encode(proposal['proof'], limits['codec'])
                    emit(case_id + '-proposal-encoding', encoded)
                    if encoded['status'] == 'COMPLETE':
                        proposal_bytes = list(bytes.fromhex(encoded['stream_hex']))
                    else:
                        generation['status'] = 'UNKNOWN_ENCODING'
                else:
                    generation['status'] = 'NO_PROPOSAL_IN_BOUNDED_CATALOG'
            except proposer.ProposalBudgetExceeded as error:
                generation.update(status='UNKNOWN_PROPOSAL_BUDGET', reason=str(error))
        generation['seconds'] = time.perf_counter() - generation_started
        emit(case_id + '-input-and-proposal', {'input': case, 'generation': generation,
                                              'inventory_ids': [e['id'] for e in compatible_inventory]})
        probe = boundary.encode_goal_boundary(goal, 0, limits['boundary'])
        if proposal_bytes is None:
            # Pure given-goal encoder reports minimum even at capacity zero.
            count = probe['minimum_stream_bytes']
            if type(count) is not int:
                results.append({'case': case_id, 'family': case['family'], 'theory': theory, 'goal': goal, 'generation': generation, 'lanes': [], 'status': 'UNKNOWN_BOUNDARY', 'probe': probe})
                continue
        else:
            count = len(proposal_bytes)
        if count > limits['max_byte_count']:
            results.append({'case': case_id, 'family': case['family'], 'theory': theory, 'goal': goal, 'generation': generation, 'lanes': [], 'status': 'UNKNOWN_BYTE_CAPACITY', 'count': count})
            continue
        given = boundary.encode_goal_boundary(goal, count, limits['boundary'])
        if given['status'] != 'COMPLETE':
            results.append({'case': case_id, 'family': case['family'], 'theory': theory, 'goal': goal, 'generation': generation, 'lanes': [], 'status': 'UNKNOWN_BOUNDARY', 'boundary': given})
            continue
        fixed = given['fixed_bytes']
        if proposal_bytes is not None and any(proposal_bytes[i] != v for i, v in fixed):
            raise AssertionError('generated target bytes violate accepted-language boundary')
        native_theory = dict(theory, schemas=[])
        carrier_data = carrier.build_carrier(program, native_theory, goal, count, limits['carrier'])
        emit(case_id + '-given-boundary-and-carrier', {'boundary': given, 'carrier': carrier_data})
        binding = {'program_sha256': sha(program), 'theory_sha256': sha(native_theory),
                   'goal_sha256': sha(goal), 'byte_count': count,
                   'boundary_version': given['version']}
        lane_results = []
        for lane in ('point-markings', 'conventional-clauses'):
            cuts, accepted = [], None
            lane_status = 'UNKNOWN_ATTEMPT_CAP'
            started = time.perf_counter()
            attempts = []
            for attempt in range(limits['max_attempts_per_lane']):
                prefix = case_id + '-' + lane + '-' + str(attempt)
                if lane == 'point-markings':
                    model = engine.make_byte_model(count, fixed, {'binding': binding, 'cuts': cuts}, limits['point'])
                    emit(prefix + '-model', model)
                    if model['status'] != 'COMPLETE':
                        lane_status = 'UNKNOWN_MODEL'; break
                    preference = None if proposal_bytes is None else [[group, proposal_bytes[i]]
                        for i, group in enumerate(model['byte_group_ids'])]
                    solution = engine.solve(model['model'], limits['point'], preference)
                    emit(prefix + '-solve', solution)
                    if solution['status'] != 'SAT':
                        lane_status = 'BOUNDED_CAPACITY_EXHAUSTED' if solution['status'] == 'UNSAT' else 'UNKNOWN_SOLVER'
                        break
                    selected = dict(solution['solution'])
                    values = [selected[group] for group in model['byte_group_ids']]
                else:
                    solution = direct_byte_solve(count, fixed, cuts, proposal_bytes,
                                                limits['direct_max_operations'])
                    emit(prefix + '-solve', solution)
                    if solution['status'] != 'SAT':
                        lane_status = 'BOUNDED_CAPACITY_EXHAUSTED' if solution['status'] == 'UNSAT' else 'UNKNOWN_SOLVER'
                        break
                    values = solution['byte_values']
                observed = oracle.observe(program, carrier_data, values, limits['oracle'])
                emit(prefix + '-observation', observed)
                attempts.append({'index': attempt, 'status': observed['status'],
                    'byte_sha256': hashlib.sha256(bytes(values)).hexdigest(),
                    'native_steps': None if observed['vm'] is None else observed['vm']['steps'],
                    'watched_indices': [d['byte_index'] for d in observed['dependencies']]})
                if observed['status'] == 'ACCEPTED':
                    decoded = codec.decode(bytes(values), limits['codec'])
                    emit(prefix + '-independent-decode', decoded)
                    if decoded['status'] != 'COMPLETE':
                        if decoded['status'] == 'REJECTED':
                            raise AssertionError('native accepted but independent decoder rejected')
                        lane_status = 'UNKNOWN_INDEPENDENT_DECODER'
                        break
                    checked = checker.check(theory, decoded['proof'], goal, limits['checker'])
                    emit(prefix + '-independent-check', checked)
                    if checked['status'] != 'VERIFIED':
                        if checked['status'] == 'REJECTED':
                            raise AssertionError('native/independent whole-proof disagreement')
                        lane_status = 'UNKNOWN_INDEPENDENT_CHECKER'
                        break
                    accepted = {'proof': decoded['proof'], 'stream_hex': bytes(values).hex(),
                                'checker': checked,
                                'origin': ('RAW_BYTE_SEARCH' if proposal_bytes is None else
                                    generation['proposal']['origin'] if values == proposal_bytes else 'PROPOSAL_GUIDED_BYTE_SEARCH'),
                                'matched_proposal': proposal_bytes is not None and values == proposal_bytes,
                                'proposal_origin': None if proposal_bytes is None else generation['proposal']['origin']}
                    lane_status = 'DISCOVERED_AND_INDEPENDENTLY_VERIFIED'
                    break
                if observed['status'] == 'CERTIFIED_REJECTION' and observed['cut'] is not None:
                    if any(observed['binding'][key] != value for key, value in binding.items()):
                        raise AssertionError('cut context mismatch')
                    # Keep all watched literals; the builder handles fixed ones.
                    cuts.append(observed['cut']['literals'])
                else:
                    lane_status = 'UNKNOWN_ORACLE'; break
            lane_result = {'lane': lane, 'status': lane_status, 'attempts': attempts,
                'certified_cuts': cuts, 'accepted': accepted, 'seconds': time.perf_counter() - started}
            emit(case_id + '-' + lane + '-result', lane_result)
            lane_results.append(lane_result)
        result = {'case': case_id, 'family': case['family'], 'theory': theory,
                  'goal': goal, 'byte_count': count, 'given_fixed_bytes': fixed,
                  'generation': generation, 'lanes': lane_results}
        results.append(result)
        # Only independently checked point-lane discoveries enter inventory.
        accepted = lane_results[0]['accepted']
        if accepted is not None:
            inventory.append({'id': case_id, 'formula': goal, 'proof': accepted['proof'],
                              'theory_sha256': theory_id})
    emit('proposal-tautology-callbacks', callback_receipts)
    output = {'version': VERSION, 'results': results, 'inventory': inventory,
        'scope': 'Finite byte-capacity native-oracle search; exact point-marking adaptation versus simple conventional clause control. No trained RL, literal fixed universal Wang proof tableau, cold corona learner, full Peano arithmetic, full Hilbert geometry or competitive ATP superiority.'}
    emit('proof-search-results', output)
    return output
