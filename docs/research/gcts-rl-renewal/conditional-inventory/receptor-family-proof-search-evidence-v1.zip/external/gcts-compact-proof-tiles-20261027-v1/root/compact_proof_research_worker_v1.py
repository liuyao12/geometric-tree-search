"""Owned inert once worker. New authority required; never a replay of Q.

Source and data are read/authenticated before module execution. Each public
entry is recorded with a prospective call cap. Large complete JSON bodies are
gzip stored; the raw and stored identities are both recorded.
"""
import argparse
import gzip
import hashlib
import json
import os
import pathlib
import re
import resource
import sys
import time
import types

ROOT = pathlib.Path('/private/tmp/gcts-compact-proof-tiles-20261027-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
COHORT = 'R-COMPACT-WANG-POINT-CUT-AND-UNKNOWN-PROOF-SEARCH-v1'
ROLE_NAMES = ('worker', 'observer', 'tree_machine', 'codec', 'fol_checker',
              'carrier', 'real_parser', 'engine', 'oracle', 'boundary',
              'proposer', 'search', 'point_qualification',
              'oracle_qualification', 'compact', 'ntm_reference')
CALL_CAPS = {
    'tree_machine.Compiler': 32, 'tree_machine.declaration': 32, 'tree_machine.validate': 64,
    'tree_machine.Heap': 500, 'tree_machine.run': 400,
    'codec.encode': 32, 'codec.decode': 32,
    'fol_checker.check': 10032, 'carrier.build_carrier': 64,
    'carrier.verify_carrier_choice': 400,
    'engine.make_byte_model': 256, 'engine.solve': 256,
    'oracle.observe': 400, 'boundary.encode_goal_boundary': 80,
    'proposer.propose': 5, 'search.run': 1,
    'point_qualification.qualify': 1, 'oracle_qualification.qualify': 1,
    'compact.compile_palette': 32, 'ntm_reference.successors': 128,
    'ntm_reference.validate_machine': 32,
    'ntm_reference.simulate': 32,
}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(reference, maximum):
    require(type(reference) is dict and set(reference) == {'path', 'bytes', 'sha256'}, 'rawref fields')
    p = pathlib.Path(reference['path'])
    require(p.is_absolute() and not p.is_symlink() and p.is_file(), 'regular absolute Source/data')
    require(type(reference['bytes']) is int and 0 <= reference['bytes'] <= maximum, 'body bound')
    require(p.stat().st_size == reference['bytes'], 'body size before read')
    raw = p.read_bytes()
    require(ref(p, raw) == reference, 'complete raw association')
    return raw


class CountedModule:
    def __init__(self, role, module, ledger, budget):
        self.role, self.module, self.ledger, self.budget = role, module, ledger, budget

    def __getattr__(self, name):
        value = getattr(self.module, name)
        key = self.role + '.' + name
        if key not in CALL_CAPS:
            # Constants/exception types and data are available; unknown callable
            # entries are forbidden so newly discovered APIs need a new cohort.
            require(not callable(value) or isinstance(value, type) and issubclass(value, Exception),
                    'undeclared callable ' + key)
            return value
        def called(*args, **kwargs):
            self.budget()
            count = self.ledger.get(key, 0) + 1
            require(count <= CALL_CAPS[key], 'public call cap ' + key)
            self.ledger[key] = count
            result = value(*args, **kwargs)
            if key == 'tree_machine.Compiler':
                original = result.declaration
                def declaration():
                    self.budget()
                    label = 'tree_machine.declaration'
                    n = self.ledger.get(label, 0) + 1
                    require(n <= CALL_CAPS[label], 'public call cap ' + label)
                    self.ledger[label] = n
                    return original()
                result.declaration = declaration
            return result
        return called


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--result', required=True)
    args = parser.parse_args()
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'D90 isolated worker')
    plan_path = pathlib.Path(args.plan)
    plan_raw = plan_path.read_bytes()
    plan = json.loads(plan_raw)
    require(plan['cohort'] == COHORT and set(plan['sources']) == set(ROLE_NAMES), 'closed current cohort')
    directory = pathlib.Path(plan['actual_dir'])
    require(directory == ROOT / 'actual' / plan['case_id'] and directory.is_dir(), 'owned actual directory')
    require(pathlib.Path(args.result) == directory / 'worker-result.json', 'owned result path')
    require((directory / 'CONSUMED.json').is_file(), 'Root once consumed before worker')
    require(plan['sources']['worker']['path'] == __file__, 'authenticated worker address')
    retained = {role: read_ref(reference, 1048576) for role, reference in plan['sources'].items()}
    metadata = {role: read_ref(reference, 1048576) for role, reference in plan['metadata'].items()}
    limits = json.loads(metadata['experiment_limits'])
    ledger, artifacts = {}, []
    callbacks = 0
    total_stored = 0
    def budget():
        nonlocal callbacks
        callbacks += 1
        require(time.monotonic() - started <= plan['limits']['worker_seconds'], 'worker wall window')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= plan['limits']['child_rss_bytes'], 'worker observed RSS')
    def write(name, value):
        nonlocal total_stored
        budget()
        require(type(name) is str and re.fullmatch('[A-Za-z0-9][A-Za-z0-9.-]*', name), 'safe artifact name')
        require(len(artifacts) < plan['limits']['max_output_files'] - 16, 'artifact file count')
        raw = encode(value)
        require(len(raw) <= plan['limits']['model_raw_bytes'], 'complete raw JSON ceiling')
        compressed = len(raw) > 65536 and name != 'worker-result'
        stored = gzip.compress(raw, compresslevel=6, mtime=0) if compressed else raw
        require(len(stored) <= plan['limits']['body_bytes'], 'stored body ceiling')
        require(total_stored + len(stored) <= plan['limits']['total_output_bytes'] - 8388608, 'whole stored bytes')
        p = directory / (name + ('.json.gz' if compressed else '.json'))
        with p.open('xb') as handle:
            handle.write(stored); handle.flush(); os.fsync(handle.fileno())
        require(p.read_bytes() == stored, 'complete stored body readback')
        require((gzip.decompress(stored) if compressed else stored) == raw, 'complete decoded body identity')
        artifact = {'name': name, 'stored': ref(p, stored),
                    'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                    'encoding': 'gzip-json' if compressed else 'json'}
        artifacts.append(artifact)
        total_stored += len(stored)
        return artifact
    modules = {}
    for role in ROLE_NAMES:
        if role in ('worker', 'observer', 'real_parser'):
            continue
        budget()
        module = types.ModuleType('R_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(retained[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = CountedModule(role, module, ledger, budget)
    compiler = modules['tree_machine'].Compiler(retained['real_parser'].decode('utf-8'))
    program = compiler.declaration()
    modules['tree_machine'].validate(program)
    write('fixed-C1-fresh-program', program)
    point_result = modules['point_qualification'].qualify(
        modules['engine'], modules['compact'], modules['ntm_reference'],
        lambda name, data: write('point-qualification-' + name, data))
    oracle_result = modules['oracle_qualification'].qualify(
        modules['tree_machine'], modules['carrier'], modules['oracle'], modules['boundary'],
        lambda record: write(record['id'], record))
    search_modules = {'engine': modules['engine'], 'oracle': modules['oracle'],
        'boundary': modules['boundary'], 'carrier': modules['carrier'],
        'codec': modules['codec'], 'checker': modules['fol_checker'], 'proposer': modules['proposer']}
    search_result = modules['search'].run(search_modules, program, write, limits)
    budget()
    result = {'schema': 'R-complete-research-worker-result-v1', 'case_id': plan['case_id'],
        'qualification': {'point_compact': point_result, 'oracle_boundary': oracle_result},
        'research': search_result, 'public_calls': dict(ledger), 'public_call_caps': CALL_CAPS,
        'artifacts': list(artifacts), 'total_stored_bytes': total_stored,
        'scope': 'Whole new bounded cohort. UNKNOWN search outcomes retained. Qualification failure propagates; no accepted prefix admitted.'}
    result_artifact = write('worker-result', result)
    require(result_artifact['encoding'] == 'json', 'result must be ordinary JSON for transport')
    for role, reference in plan['sources'].items():
        require(read_ref(reference, 1048576) == retained[role], 'post Source guard')
    for role, reference in plan['metadata'].items():
        require(read_ref(reference, 1048576) == metadata[role], 'post metadata guard')
    budget()
    terminal = {'schema': 'GCTS-raw-proof-worker-terminal-v1',
        'status': 'COMPLETE_COMPONENT_CONTROLS_RESULT_WRITTEN', 'case_id': plan['case_id'],
        'plan': ref(plan_path, plan_raw), 'result': result_artifact['stored'], 'public_calls': dict(ledger),
        'post_readback_costs': {'elapsed_main_entry_seconds': time.monotonic() - started,
            'self_lifetime_highwater_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'worker_budget_callbacks': callbacks},
        'unmeasured_tail': 'Final terminal encoding/flush/shutdown after sampled costs; outer observer owns wait/EOF and records fresh-child lifetime RSS.'}
    sys.stdout.buffer.write(encode(terminal)); sys.stdout.buffer.flush()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
