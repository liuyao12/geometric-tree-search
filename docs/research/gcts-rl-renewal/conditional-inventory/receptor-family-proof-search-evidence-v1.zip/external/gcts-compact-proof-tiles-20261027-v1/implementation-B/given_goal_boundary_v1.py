"""INERT pure encoder of GIVEN target formula boundary bytes, never a proof.

Only accepted-language redundant prefix/suffix positions are fixed. No rule
code, earlier formula, proof line or proof skeleton is an input or output.
"""
VERSION = 'R-GIVEN-GOAL-WIRE-BOUNDARY-v1'
SCHEMA = 'R-given-goal-wire-boundary-v1'
LIMIT_KEYS = ('max_operations', 'max_depth', 'max_nodes', 'max_name_bytes',
              'max_output_bytes', 'max_byte_count')


class _Input(Exception):
    pass


class _Limit(Exception):
    pass


def _need(ok, reason):
    if not ok:
        raise _Input(reason)


class _Meter:
    def __init__(self, limits, budget):
        _need(type(limits) is dict and len(limits) == len(LIMIT_KEYS)
              and all(type(k) is str for k in limits) and set(limits) == set(LIMIT_KEYS)
              and all(type(v) is int and v >= 0 for v in limits.values()), 'LIMITS')
        _need(budget is None or callable(budget), 'BUDGET_TYPE')
        self.limits = dict(limits)
        self.budget = budget
        self.notify = False
        self.operations = self.callbacks = self.nodes = self.depth = 0
        self.output = bytearray()

    def charge(self, n=1):
        if n > self.limits['max_operations'] - self.operations:
            raise _Limit('OPERATION_LIMIT')
        self.operations += n
        if self.notify and self.budget is not None:
            self.callbacks += 1
            self.budget()

    def put(self, byte):
        self.charge()
        if len(self.output) >= self.limits['max_output_bytes']:
            raise _Limit('OUTPUT_LIMIT')
        self.output.append(byte)

    def name(self, value):
        _need(type(value) is str and bool(value), 'NAME_TYPE')
        if len(value) > self.limits['max_name_bytes']:
            raise _Limit('NAME_LIMIT')
        self.charge(len(value))
        _need(all(32 <= ord(c) <= 126 for c in value), 'ASCII_NAME')
        for c in value:
            self.put(ord(c))
        self.put(0)


def _copy_goal(goal, meter):
    holder = [None]
    active = set()
    todo = [('visit', goal, holder, 0)]
    while todo:
        op, x, parent, key = todo.pop()
        if op == 'leave':
            active.remove(x)
            continue
        meter.charge()
        if type(x) is list:
            _need(id(x) not in active, 'CYCLIC_GOAL')
            meter.charge(len(x))
            copied = [None] * len(x)
            parent[key] = copied
            active.add(id(x))
            todo.append(('leave', id(x), None, None))
            for i in range(len(x) - 1, -1, -1):
                todo.append(('visit', x[i], copied, i))
        else:
            _need(type(x) is str, 'GOAL_NATIVE_TYPE')
            meter.charge(len(x))
            parent[key] = x
    return holder[0]


def _shape(x, size):
    _need(type(x) is list and len(x) == size, 'AST_SHAPE')


def _goal_bytes(goal, meter):
    active = set()
    todo = [('formula', goal, 0)]
    while todo:
        kind, x, depth = todo.pop()
        if kind == 'leave':
            active.remove(x)
            continue
        if kind == 'byte':
            meter.put(x)
            continue
        meter.charge()
        if depth > meter.limits['max_depth']:
            raise _Limit('DEPTH_LIMIT')
        if meter.nodes >= meter.limits['max_nodes']:
            raise _Limit('NODE_LIMIT')
        meter.nodes += 1
        meter.depth = max(meter.depth, depth)
        _need(type(x) is list and bool(x) and type(x[0]) is str, 'AST_NODE')
        _need(id(x) not in active, 'CYCLIC_GOAL')
        active.add(id(x))
        todo.append(('leave', id(x), depth))
        tag = x[0]
        if kind == 'term':
            if tag == 'var':
                _shape(x, 2)
                meter.put(32)
                meter.name(x[1])
            elif tag == 'fun':
                _shape(x, 3)
                _need(type(x[2]) is list, 'TERM_ARGUMENTS')
                meter.put(33)
                meter.name(x[1])
                meter.charge(2 * len(x[2]) + 1)
                todo.append(('byte', 65, depth))
                for arg in reversed(x[2]):
                    todo.append(('term', arg, depth + 1))
                    todo.append(('byte', 64, depth))
            else:
                raise _Input('TERM_TAG')
        elif tag == 'bot':
            _shape(x, 1)
            meter.put(48)
        elif tag == 'eq':
            _shape(x, 3)
            meter.put(49)
            meter.charge(2)
            todo.append(('term', x[2], depth + 1))
            todo.append(('term', x[1], depth + 1))
        elif tag == 'pred':
            _shape(x, 3)
            _need(type(x[2]) is list, 'PRED_ARGUMENTS')
            meter.put(50)
            meter.name(x[1])
            meter.charge(2 * len(x[2]) + 1)
            todo.append(('byte', 65, depth))
            for arg in reversed(x[2]):
                todo.append(('term', arg, depth + 1))
                todo.append(('byte', 64, depth))
        elif tag == 'not':
            _shape(x, 2)
            meter.put(51)
            meter.charge()
            todo.append(('formula', x[1], depth + 1))
        elif tag in ('and', 'or', 'imp'):
            _shape(x, 3)
            meter.put({'and': 52, 'or': 53, 'imp': 54}[tag])
            meter.charge(2)
            todo.append(('formula', x[2], depth + 1))
            todo.append(('formula', x[1], depth + 1))
        elif tag == 'all':
            _shape(x, 3)
            meter.put(55)
            meter.name(x[1])
            meter.charge()
            todo.append(('formula', x[2], depth + 1))
        else:
            raise _Input('FORMULA_TAG')


def encode_goal_boundary(goal, byte_count, limits, *, budget=None):
    """Return redundant positions only; this function never constructs a proof."""
    meter = None
    fixed = []
    wire = None
    minimum = None
    count = None
    try:
        meter = _Meter(limits, budget)
        _need(type(byte_count) is int and byte_count >= 0, 'BYTE_COUNT')
        count = byte_count
        if count > meter.limits['max_byte_count']:
            raise _Limit('BYTE_COUNT_LIMIT')
        copied = _copy_goal(goal, meter)
        meter.notify = True
        meter.charge()
        _goal_bytes(copied, meter)
        minimum = len(meter.output) + 4
        if count < minimum:
            status, reason = 'EMPTY_CAPACITY', 'INSUFFICIENT_BOUNDARY_ROOM'
        else:
            meter.charge(3 * len(meter.output) + 12)
            start = count - 1 - len(meter.output)
            _need(start >= 3, 'BOUNDARY_OVERLAP')
            fixed = [[0, 1], [1, 16]]
            fixed.extend([start + i, value] for i, value in enumerate(meter.output))
            fixed.append([count - 1, 17])
            wire = meter.output.hex()
            status, reason = 'COMPLETE', 'GIVEN_GOAL_ACCEPTED_LANGUAGE_BOUNDARY'
    except _Input as error:
        status, reason = 'REJECTED_INPUT', str(error)
        fixed, wire, minimum = [], None, None
    except _Limit as error:
        status, reason = 'UNKNOWN_BUDGET', str(error)
        fixed, wire, minimum = [], None, None
    return {'schema': SCHEMA, 'version': VERSION, 'status': status, 'reason': reason,
            'goal_wire_hex': wire, 'byte_count': count,
            'minimum_stream_bytes': minimum, 'fixed_bytes': fixed,
            'resources': {'operations': 0 if meter is None else meter.operations,
                          'budget_callbacks': 0 if meter is None else meter.callbacks,
                          'nodes': 0 if meter is None else meter.nodes,
                          'max_depth_seen': 0 if meter is None else meter.depth,
                          'output_bytes': 0 if meter is None else len(meter.output),
                          'limits': None if meter is None else dict(meter.limits)},
            'scope': 'Known formula only. COMPLETE fixes no rule or earlier formula; all other slots have full256 domain. EMPTY_CAPACITY is only this byte-length lower bound, not logical unprovability. No signature or proof validity checking; no proof AST/skeleton.'}
