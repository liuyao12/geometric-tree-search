"""INERT dependency observer for the unchanged thirteen-op tree VM.

No project imports or proof-specific instruction. A future caller authenticates
and validates the fixed Compiler declaration and canonical L carrier2. No call
or test is made by this module body. Only complete normal zero can emit a cut.
"""
import hashlib
import json
import time

VERSION = 'R-BYTE-DEPENDENCY-TREE-VM-v1'
SCHEMA = 'R-byte-dependency-tree-observation-v1'
BOUNDARY_VERSION = 'R-GIVEN-GOAL-WIRE-BOUNDARY-v1'
CARRIER_VERSION = 'RAW-PROOF-BYTE-CARRIER-MIN8-v2'
NIL = 256
LIMIT_KEYS = ('max_operations', 'max_steps', 'max_heap_nodes', 'max_frames',
              'max_trace_records', 'max_dependencies', 'max_input_items',
              'max_milliseconds')
WIDTHS = {'const': 3, 'move': 3, 'cons': 4, 'head': 3, 'tail': 3,
          'pair': 3, 'atom': 4, 'succ': 3, 'not': 3, 'branch': 4,
          'jump': 2, 'call': 4, 'return': 2}


class _Input(Exception):
    pass


class _Limit(Exception):
    pass


class _Fault(Exception):
    pass


def _need(ok, reason):
    if not ok:
        raise _Input(reason)


def _fields(value, keys):
    _need(type(value) is dict and len(value) == len(keys)
          and all(type(k) is str for k in value) and set(value) == set(keys),
          'EXACT_FIELDS')


def _integer(value, lower, upper):
    return type(value) is int and lower <= value < upper


class _Meter:
    def __init__(self, limits, budget):
        _fields(limits, LIMIT_KEYS)
        _need(all(type(v) is int and v >= 0 for v in limits.values()), 'LIMIT_TYPES')
        _need(budget is None or callable(budget), 'BUDGET_TYPE')
        self.limits = dict(limits)
        self.budget = budget
        self.notify = False
        self.operations = 0
        self.callbacks = 0
        self.items = 0
        self.started = time.perf_counter()
        self.stage = 'snapshot'

    def charge(self, units=1):
        if units > self.limits['max_operations'] - self.operations:
            raise _Limit('OPERATION_LIMIT')
        self.operations += units
        if (time.perf_counter() - self.started) * 1000 > self.limits['max_milliseconds']:
            raise _Limit('TIME_LIMIT')
        if self.notify and self.budget is not None:
            self.callbacks += 1
            self.budget()

    def input_charge(self, units):
        if units > self.limits['max_input_items'] - self.items:
            raise _Limit('INPUT_ITEM_LIMIT')
        self.charge(units)
        self.items += units


def _snapshot(value, meter):
    """Copy plain JSON-shaped data without any user callback or object protocol."""
    holder = [None]
    active = set()
    todo = [('visit', value, holder, 0)]
    while todo:
        op, value, parent, key = todo.pop()
        if op == 'leave':
            active.remove(value)
            continue
        meter.input_charge(1)
        if type(value) in (dict, list, tuple):
            identity = id(value)
            _need(identity not in active, 'CYCLIC_INPUT')
            meter.input_charge(len(value))
            active.add(identity)
            todo.append(('leave', identity, None, None))
            if type(value) is dict:
                out = {}
                parent[key] = out
                for k, v in reversed(list(value.items())):
                    _need(type(k) is str, 'OBJECT_KEY_TYPE')
                    meter.input_charge(len(k))
                    todo.append(('visit', v, out, k))
            else:
                out = [None] * len(value)
                parent[key] = out
                for i in range(len(value) - 1, -1, -1):
                    todo.append(('visit', value[i], out, i))
        else:
            _need(value is None or type(value) in (str, int, bool), 'INPUT_PRIMITIVE')
            if type(value) is str:
                meter.input_charge(len(value))
            parent[key] = value
    return holder[0]


def _digest(value, meter):
    digest = hashlib.sha256()
    encoder = json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                               separators=(',', ':'), allow_nan=False)
    for part in encoder.iterencode(value):
        meter.charge(len(part))
        digest.update(part.encode('ascii'))
    return digest.hexdigest()


def _program(program, meter):
    _fields(program, ('atom_max', 'nil', 'nodes', 'constants', 'functions'))
    _need(type(program['atom_max']) is int and program['atom_max'] == NIL
          and type(program['nil']) is int and program['nil'] == NIL, 'PROGRAM_HEADER')
    _heap(program['nodes'], meter)
    bound = 257 + len(program['nodes'])
    _need(type(program['constants']) is list, 'CONSTANTS')
    for value in program['constants']:
        meter.charge()
        _need(_integer(value, 0, bound), 'CONSTANT_NODE')
    functions = program['functions']
    _need(type(functions) is list and bool(functions), 'FUNCTIONS')
    names = set()
    for f in functions:
        meter.charge()
        _fields(f, ('name', 'arity', 'registers', 'code'))
        _need(type(f['name']) is str and f['name'] not in names, 'FUNCTION_NAME')
        names.add(f['name'])
        _need(_integer(f['registers'], 1, 10000000)
              and _integer(f['arity'], 0, f['registers'] + 1)
              and type(f['code']) is list and bool(f['code']), 'FUNCTION_SHAPE')
    _need(functions[0]['name'] == 'main' and functions[0]['arity'] == 1, 'MAIN')
    for f in functions:
        n = f['registers']
        code = f['code']
        for ins in code:
            meter.charge()
            _need(type(ins) is list and bool(ins) and type(ins[0]) is str
                  and ins[0] in WIDTHS and len(ins) == WIDTHS[ins[0]], 'OPCODE')
            op, a = ins[0], ins[1:]
            if op == 'const':
                ok = _integer(a[0], 0, n) and _integer(a[1], 0, len(program['constants']))
            elif op == 'jump':
                ok = _integer(a[0], 0, len(code))
            elif op == 'branch':
                ok = _integer(a[0], 0, n) and all(_integer(x, 0, len(code)) for x in a[1:])
            elif op == 'call':
                ok = (_integer(a[0], 0, n) and _integer(a[1], 0, len(functions))
                      and type(a[2]) is list)
                if ok:
                    meter.charge(len(a[2]))
                    ok = (len(a[2]) == functions[a[1]]['arity']
                          and all(_integer(x, 0, n) for x in a[2]))
            else:
                ok = all(_integer(x, 0, n) for x in a)
            _need(ok, 'OPERAND')


def _heap(nodes, meter):
    _need(type(nodes) is list, 'HEAP_LIST')
    if len(nodes) > meter.limits['max_heap_nodes']:
        raise _Limit('HEAP_LIMIT')
    index = {}
    for i, row in enumerate(nodes):
        meter.charge()
        _need(type(row) is list and len(row) == 2
              and all(_integer(v, 0, 257 + i) for v in row), 'HEAP_EARLIER_CHILD')
        pair = (row[0], row[1])
        _need(pair not in index, 'HEAP_DUPLICATE_PAIR')
        index[pair] = 257 + i
    return index


def _proper(nodes, root, expected, meter):
    for value in expected:
        meter.charge()
        _need(_integer(root, 257, 257 + len(nodes)), 'PROPER_LIST')
        row = nodes[root - 257]
        _need(row[0] == value, 'PROPER_LIST_HEAD')
        root = row[1]
    _need(root == NIL, 'PROPER_LIST_END')


def _carrier(program, carrier, values, meter):
    _fields(carrier, ('schema', 'value', 'cost'))
    _need(carrier['schema'] == 'L-raw-proof-byte-carrier-v1', 'CARRIER_SCHEMA')
    c = carrier['value']
    _fields(c, ('version', 'program_sha256', 'known', 'nodes', 'input_node',
                'theory_node', 'target_node', 'stream_node', 'program_prefix_nodes',
                'trusted_prefix_nodes', 'trusted_prefix_sha256', 'byte_count',
                'marker_ids', 'byte_rows', 'fresh_marker_attempts', 'binding'))
    _need(c['version'] == CARRIER_VERSION, 'CARRIER_VERSION')
    _need(type(values) is list and type(c['byte_count']) is int
          and c['byte_count'] >= 0 and len(values) == c['byte_count'], 'COMPLETE_BYTES')
    for value in values:
        meter.charge()
        _need(_integer(value, 0, 256), 'BYTE_TYPE')
    nodes = c['nodes']
    _heap(nodes, meter)
    _need(type(c['program_prefix_nodes']) is int
          and c['program_prefix_nodes'] == len(program['nodes'])
          and type(c['trusted_prefix_nodes']) is int
          and len(program['nodes']) <= c['trusted_prefix_nodes'] <= len(nodes), 'PREFIX_COUNTS')
    meter.charge(len(program['nodes']) + c['trusted_prefix_nodes'])
    _need(nodes[:len(program['nodes'])] == program['nodes'], 'PROGRAM_PREFIX')
    _need(c['program_sha256'] == _digest(program, meter)
          and c['trusted_prefix_sha256'] == _digest(nodes[:c['trusted_prefix_nodes']], meter), 'PREFIX_HASH')
    _fields(c['known'], ('theory', 'target', 'theory_sha256', 'target_sha256'))
    _need(c['known']['theory_sha256'] == _digest(c['known']['theory'], meter)
          and c['known']['target_sha256'] == _digest(c['known']['target'], meter), 'KNOWN_HASH')
    _need(type(c['marker_ids']) is list and type(c['byte_rows']) is list
          and len(c['marker_ids']) == len(c['byte_rows']) == len(values), 'ROW_COUNTS')
    marker_to_index = {}
    row_to_index = {}
    row_ids = []
    for i, (marker, row) in enumerate(zip(c['marker_ids'], c['byte_rows'], strict=True)):
        meter.charge()
        _fields(row, ('byte_index', 'node_id', 'node_index', 'marker_id', 'head_placeholder', 'domain'))
        _fields(row['domain'], ('minimum', 'maximum', 'all_values_allowed'))
        _need(_integer(marker, 257 + c['trusted_prefix_nodes'], 257 + len(nodes))
              and marker not in marker_to_index and nodes[marker - 257][0] == NIL, 'PRIVATE_MARKER')
        _need(type(row['byte_index']) is int and row['byte_index'] == i
              and _integer(row['node_id'], 257 + c['trusted_prefix_nodes'], 257 + len(nodes))
              and type(row['node_index']) is int and row['node_index'] == row['node_id'] - 257
              and type(row['marker_id']) is int and row['marker_id'] == marker
              and type(row['head_placeholder']) is int and row['head_placeholder'] == 0,
              'BYTE_ROW')
        _need(type(row['domain']['minimum']) is int and row['domain']['minimum'] == 0
              and type(row['domain']['maximum']) is int and row['domain']['maximum'] == 255
              and row['domain']['all_values_allowed'] is True, 'FULL_256_DOMAIN')
        _need(row['node_id'] not in row_to_index
              and nodes[row['node_index']] == [0, marker], 'UNIQUE_PRIVATE_ROW')
        marker_to_index[marker] = i
        row_to_index[row['node_id']] = i
        row_ids.append(row['node_id'])
    for i, (a, b) in enumerate(nodes):
        meter.charge()
        if 257 + i not in row_to_index:
            _need(not (b in marker_to_index and 0 <= a <= 255), 'FIXED_PAIR_BYTE_ALIAS')
    _proper(nodes, c['stream_node'], row_ids, meter)
    _proper(nodes, c['input_node'], [c['theory_node'], c['target_node'], c['stream_node']], meter)
    _need(_integer(c['theory_node'], 257, 257 + c['trusted_prefix_nodes'])
          and _integer(c['target_node'], 257, 257 + c['trusted_prefix_nodes']), 'KNOWN_ROOT_PREFIX')
    meter.charge(len(nodes))
    chosen = [[a, b] for a, b in nodes]
    for node, i in row_to_index.items():
        chosen[node - 257][0] = values[i]
    index = _heap(chosen, meter)
    binding = {'program_sha256': c['program_sha256'],
               'carrier_value_sha256': _digest(c, meter),
               'theory_sha256': c['known']['theory_sha256'],
               'goal_sha256': c['known']['target_sha256'],
               'byte_count': len(values), 'boundary_version': BOUNDARY_VERSION,
               'carrier_version': CARRIER_VERSION, 'oracle_version': VERSION}
    return chosen, index, row_to_index, marker_to_index, c['input_node'], binding


def observe(program, carrier, byte_values, limits, *, budget=None):
    """Execute a fully concrete choice; never decode or propose a proof AST."""
    meter = None
    binding = None
    values = None
    nodes = None
    native = None
    dependencies = []
    dep_index = {}
    trace = []
    digest = hashlib.sha256()
    total_events = 0
    peak = 0
    status = reason = None
    vm_started = None
    step = 0
    profile = {}

    def watch(i, kind):
        if i not in dep_index:
            if len(dependencies) >= meter.limits['max_dependencies']:
                raise _Limit('DEPENDENCY_LIMIT')
            meter.charge()
            dep_index[i] = len(dependencies)
            dependencies.append({'byte_index': i, 'value': values[i], 'first_step': step,
                                 'head_reads': 0, 'cons_alias_consults': 0})
        row = dependencies[dep_index[i]]
        row[kind] += 1

    def event_done(event):
        nonlocal total_events, digest
        following = digest.copy()
        encoder = json.JSONEncoder(separators=(',', ':'))
        for part in encoder.iterencode(event):
            meter.charge(len(part))
            following.update(part.encode())
        meter.charge()
        following.update(b'\n')
        if len(trace) < meter.limits['max_trace_records']:
            meter.charge()
            trace.append(event)
        digest = following
        total_events += 1

    def ordinary(vm_status, steps, **extras):
        return dict(status=vm_status, steps=steps, event_sha256=digest.hexdigest(),
                    profile=dict(profile), peak_frames=peak,
                    heap_nodes=len(nodes), trace=trace,
                    seconds=time.perf_counter() - vm_started, **extras)

    try:
        meter = _Meter(limits, budget)
        frozen = _snapshot([program, carrier, byte_values], meter)
        program, carrier, values = frozen
        meter.notify = True
        meter.stage = 'validation'
        meter.charge()
        _program(program, meter)
        nodes, index, by_row, by_marker, input_node, binding = _carrier(program, carrier, values, meter)
        meter.stage = 'evaluation'
        functions = program['functions']
        fn = pc = 0
        meter.charge(functions[0]['registers'])
        registers = [NIL] * functions[0]['registers']
        registers[0] = input_node
        frames = []
        vm_started = time.perf_counter()
        while step < meter.limits['max_steps']:
            meter.charge()
            code = functions[fn]['code']
            if not 0 <= pc < len(code):
                raise _Fault('instruction pointer outside code')
            instruction = code[pc]
            op, a = instruction[0], instruction[1:]
            event = [fn, pc, op]
            pc += 1
            if op == 'const':
                registers[a[0]] = program['constants'][a[1]]
                event.append(registers[a[0]])
            elif op == 'move':
                registers[a[0]] = registers[a[1]]
                event.append(registers[a[0]])
            elif op == 'cons':
                left, right = registers[a[1]], registers[a[2]]
                # A MISS matters too: another completion may hit its private row.
                if right in by_marker:
                    watch(by_marker[right], 'cons_alias_consults')
                if not all(_integer(v, 0, 257 + len(nodes)) for v in (left, right)):
                    raise _Fault('cons children must be existing nodes or atoms')
                pair = (left, right)
                if pair not in index:
                    if len(nodes) >= meter.limits['max_heap_nodes']:
                        raise _Limit('HEAP_LIMIT')
                    meter.charge()
                    index[pair] = 257 + len(nodes)
                    nodes.append([left, right])
                registers[a[0]] = index[pair]
                event.append(registers[a[0]])
            elif op in ('head', 'tail'):
                x = registers[a[1]]
                if not _integer(x, 257, 257 + len(nodes)):
                    raise _Fault(op + ' requires a cons node')
                if op == 'head' and x in by_row:
                    watch(by_row[x], 'head_reads')
                registers[a[0]] = nodes[x - 257][0 if op == 'head' else 1]
                event.append(registers[a[0]])
            elif op == 'pair':
                registers[a[0]] = int(registers[a[1]] > NIL)
                event.append(registers[a[0]])
            elif op == 'atom':
                registers[a[0]] = int(registers[a[1]] <= NIL and registers[a[2]] <= NIL
                                      and registers[a[1]] == registers[a[2]])
                event.append(registers[a[0]])
            elif op == 'succ':
                v = registers[a[1]]
                if not 0 <= v < 255:
                    raise _Fault('byte successor requires a byte below 255')
                registers[a[0]] = v + 1
                event.append(registers[a[0]])
            elif op == 'not':
                v = registers[a[1]]
                if v not in (0, 1):
                    raise _Fault('Boolean branch value required')
                registers[a[0]] = 1 - v
                event.append(registers[a[0]])
            elif op == 'branch':
                v = registers[a[0]]
                if v not in (0, 1):
                    raise _Fault('Boolean branch value required')
                pc = a[1 + v]
                event.append(v)
            elif op == 'jump':
                pc = a[0]
            elif op == 'call':
                target = functions[a[1]]
                if len(frames) >= meter.limits['max_frames']:
                    raise _Limit('FRAME_LIMIT')
                meter.charge(target['registers'] + len(a[2]) + 1)
                args = [registers[i] for i in a[2]]
                frames.append((fn, pc, registers, a[0]))
                peak = max(peak, len(frames))
                fn, pc = a[1], 0
                registers = args + [NIL] * (target['registers'] - len(args))
                profile[target['name']] = profile.get(target['name'], 0) + 1
                event.append(args)
            elif op == 'return':
                value = registers[a[0]]
                event.append(value)
                if not frames:
                    event_done(event)
                    native = ordinary('accepted' if value == 1 else 'rejected', step + 1, value=value)
                    status = 'ACCEPTED' if value == 1 else 'CERTIFIED_REJECTION' if value == 0 else 'NORMAL_OTHER_RETURN'
                    reason = 'COMPLETE_NORMAL_RETURN'
                    break
                fn, pc, registers, destination = frames.pop()
                registers[destination] = value
            event_done(event)
            peak = max(peak, len(frames))
            step += 1
        else:
            native = ordinary('unknown_step_budget', meter.limits['max_steps'])
            status, reason = 'UNKNOWN_BUDGET', 'STEP_LIMIT'
    except _Input as error:
        status, reason = 'REJECTED_INPUT', str(error)
    except _Limit as error:
        status, reason = 'UNKNOWN_BUDGET', str(error)
        if vm_started is not None:
            vm_status = 'unknown_heap_budget' if reason == 'HEAP_LIMIT' else 'unknown_step_budget'
            native = ordinary(vm_status, step, reason=reason)
    except _Fault as error:
        status, reason = 'UNKNOWN_FAULT', str(error)
        native = ordinary('rejected', step + 1, reason='invalid data operation: ' + str(error),
                          function=functions[fn]['name'], pc=pc - 1)
    cut = None
    if meter is not None:
        try:
            meter.stage = 'receipt'
            meter.charge(len(dependencies) * max(1, len(dependencies).bit_length())
                         + len(profile) + len(dependencies) + 24)
        except _Limit as error:
            status, reason = 'UNKNOWN_BUDGET', str(error)
    if status == 'CERTIFIED_REJECTION':
        cut = {'schema': 'R-certified-byte-rejection-cut-v1', 'binding': dict(binding),
               'literals': [[r['byte_index'], r['value']]
                            for r in sorted(dependencies, key=lambda r: r['byte_index'])],
               'value': 0, 'trace_sha256': digest.hexdigest()}
    return {'schema': SCHEMA, 'version': VERSION, 'status': status, 'reason': reason,
            'binding': binding, 'byte_values': values, 'vm': native,
            'final_heap': nodes, 'dependencies': dependencies, 'cut': cut,
            'trace_extent': {'total_events': total_events, 'retained_events': len(trace),
                             'complete_prefix': total_events == len(trace),
                             'full_event_sha256': digest.hexdigest()},
            'resources': {'stage': None if meter is None else meter.stage,
                          'operations': 0 if meter is None else meter.operations,
                          'budget_callbacks': 0 if meter is None else meter.callbacks,
                          'elapsed_milliseconds': None if meter is None else (time.perf_counter() - meter.started) * 1000,
                          'initial_heap_nodes': None if binding is None else len(carrier['value']['nodes']),
                          'peak_frames': peak, 'input_items': 0 if meter is None else meter.items,
                          'limits': None if meter is None else dict(meter.limits)},
            'scope': 'Only full normal zero certifies a context-bound rejection. Native faults and all resource refusals are not negatives. Canonical carrier generation and retained fixed-program authentication are caller obligations; no proof decoding or physical/Wang execution.'}
