"""Closed W scalable worker and owned observer. Inert until a fresh exact once grant.

Only pinned retained Source bytes execute. All outcomes and complete proof
checks are retained. The supervisor owns one child, its streams and wait4;
timeouts/refusals never become mathematical negatives. No network or Git.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import types

ROOT = Path('/private/tmp/gcts-scalable-proof-search-20261028-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
ROLES = {'runner', 'compiler', 'engine', 'independent', 'graph_audit', 'reference', 'explicit',
         'tree_machine', 'codec', 'carrier', 'fol_checker', 'real_parser', 'vengine'}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def raw_ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(ref, maximum=1048576):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'raw ref')
    path = Path(ref['path'])
    require(path.is_absolute() and not path.is_symlink(), 'regular absolute path')
    require(type(ref['bytes']) is int and 0 <= ref['bytes'] <= maximum, 'raw length bound')
    with path.open('rb') as f:
        data = f.read(ref['bytes'] + 1)
    require(raw_ref(path, data) == ref, 'whole raw association')
    return data


def put(path, raw):
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    require(path.read_bytes() == raw, 'whole written bytes')
    return raw_ref(path, raw)


def check_authority(raw, plan_path, plan_raw, plan):
    authority = json.loads(raw)
    expected = {'schema': 'W-scalable-first-order-proof-once-authority-v1', 'uses': 1,
                'authorized': True, 'plan': raw_ref(plan_path, plan_raw),
                'runner': plan['sources']['runner'], 'python': plan['python']}
    require(type(authority) is dict and len(authority) == 6
            and type(authority.get('uses')) is int
            and type(authority.get('authorized')) is bool
            and authority == expected, 'exact typed Root once')
    return expected


def load_plan(path):
    raw = Path(path).read_bytes()
    plan = json.loads(raw)
    require(set(plan) == {'schema', 'sources', 'metadata', 'python', 'bootstrap',
                          'actual_dir', 'limits'}, 'exact plan')
    require(plan['schema'] == 'W-scalable-first-order-proof-once-plan-v1', 'plan schema')
    require(set(plan['sources']) == ROLES, 'closed Source roles')
    require(Path(plan['actual_dir']) == ROOT / 'actual' / 'study-002', 'owned output')
    require(plan['sources']['runner']['path'] == __file__, 'runner location')
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'isolated D90')
    require(plan['limits'] == {'worker_seconds': 360, 'observer_seconds': 390,
            'rss_bytes': 1073741824, 'file_bytes': 67108864,
            'total_bytes': 536870912, 'max_files': 384,
            'stream_bytes': 1048576}, 'fixed process and artifact profile')
    retained = {k: read_ref(v) for k, v in plan['sources'].items()}
    metadata = {k: read_ref(v) for k, v in plan['metadata'].items()}
    read_ref(plan['python'], 33554432)
    read_ref(plan['bootstrap'])
    return plan, raw, retained, metadata


def proof_ancestry(proof, axioms, budget):
    """Goal-dependent axiom names, from actual checked proof references only."""
    started = time.perf_counter()
    require(type(proof) is list and proof, 'checked whole proof for ancestry')
    seen, names, pending = set(), set(), [len(proof) - 1]
    while pending:
        budget()
        index = pending.pop()
        if index in seen: continue
        require(type(index) is int and 0 <= index < len(proof), 'ancestry line')
        seen.add(index); line = proof[index]; rule = line['rule']
        if rule == 'axiom':
            require(type(line['name']) is str and line['name'] in axioms, 'ancestry theory axiom')
            names.add(line['name'])
        elif rule in ('mp', 'generalize'):
            fields = ('antecedent', 'implication') if rule == 'mp' else ('source',)
            for field in fields:
                source = line[field]
                require(type(source) is int and 0 <= source < index, 'ancestry strict prior')
                pending.append(source)
        else:
            require(rule in ('tautology', 'refl', 'instantiate', 'distribute', 'eq_subst'),
                    'ancestry eight rules')
    return {'last_line': len(proof) - 1, 'reachable_lines': sorted(seen),
            'axiom_names': sorted(names), 'used_axiom_count': len(names),
            'seconds': time.perf_counter() - started}


def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    marker_path = directory / 'CONSUMED.json'
    marker_raw = marker_path.read_bytes()
    marker = json.loads(marker_raw)
    authority_raw = read_ref(marker['authority'])
    check_authority(authority_raw, plan_path, plan_raw, plan)
    consume_raw = read_ref(marker['consumed'])
    require(json.loads(consume_raw) == {'authority': marker['authority'],
            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}, 'worker once joins')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 360, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        require(type(name) is str and name and name.isascii()
                and all(c.isalnum() or c in '-.' for c in name), 'artifact name')
        require(len(artifacts) < 376, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 67108864, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(len(stored) <= 67108864 and total_bytes <= 503316480,
                'whole artifact stored cap')
        ref = put(directory / (name + ('.json.gz' if compressed else '.json')), stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('W_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 512, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    limits = json.loads(metadata['experiment_limits'])
    cases = json.loads(metadata['cases'])
    calibrations = json.loads(metadata['calibrations'])
    profile = json.loads(metadata['profile'])
    design = json.loads(metadata['design'])
    expected_qualification_checks = design['expected_qualification_checks']
    require(type(expected_qualification_checks) is int and 0 <= expected_qualification_checks <= 128,
            'prospective native qualification census')
    bridge_qualification = json.loads(metadata['bridge_result'])
    bridge_admission = json.loads(metadata['bridge_admission'])
    require(bridge_admission['status'] == 'ADMITTED_COMPLETE_TINY_QUALIFICATION'
            and bridge_admission['worker_result'] == plan['metadata']['bridge_result'],
            'exact previously admitted bridge result')
    require(bridge_qualification['status'] == 'COMPLETE'
            and len(bridge_qualification['records']) == 20, 'whole saved bridge cohort')
    bridge_records = bridge_qualification['records']

    tm = modules['tree_machine']
    cold = time.perf_counter()
    program = call('tree_machine', 'Compiler', sources['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - cold

    def checked_proof(case_id, lane, problem, proof):
        t = time.perf_counter()
        theory = problem['theory']
        encode = call('codec', 'encode', proof, limits['codec'])
        require(encode['status'] == 'COMPLETE', 'proof codec encode')
        stream = bytes.fromhex(encode['stream_hex'])
        decode = call('codec', 'decode', stream, limits['codec'])
        require(decode['status'] == 'COMPLETE' and decode['proof'] == proof,
                'exact independent byte roundtrip')
        carrier = call('carrier', 'build_carrier', program, dict(theory, schemas=[]),
                       problem['goal'], len(stream), limits['carrier'], budget=budget)
        nodes = [list(n) for n in carrier['value']['nodes']]
        for row in carrier['value']['byte_rows']:
            nodes[row['node_index']][0] = stream[row['byte_index']]
        choice = call('carrier', 'verify_carrier_choice', carrier, nodes,
                      carrier['value']['input_node'], budget=budget)
        require(choice['status'] == 'VERIFIED' and choice['byte_values'] == list(stream),
                'whole chosen byte carrier')
        heap = call('tree_machine', 'Heap', nodes, limit=limits['native']['max_heap_nodes'])
        native = call('tree_machine', 'run', program, heap, carrier['value']['input_node'],
                      limit=limits['native']['max_steps'], keep=limits['native']['max_trace_records'])
        independent = call('fol_checker', 'check', theory, decode['proof'],
                           problem['goal'], limits['checker'])
        accepted = (native.get('status') == 'accepted' and type(native.get('value')) is int
                    and native['value'] == 1 and independent['status'] == 'VERIFIED')
        record = {'status': 'VERIFIED' if accepted else 'UNADMITTED_CHECKER_OUTCOME',
                  'theory': theory, 'goal': problem['goal'], 'proof': proof,
                  'encoding': encode, 'decoding': decode, 'carrier': carrier,
                  'initial_nodes': nodes, 'choice': choice, 'native': native,
                  'final_heap': heap.nodes, 'independent': independent,
                  'seconds': time.perf_counter() - t}
        emit(case_id + '-' + lane + '-whole-proof-check', record)
        require(accepted, 'all accepted proofs independently checked')
        return {'status': record['status'], 'seconds': record['seconds'],
                'proof_lines': len(proof), 'proof_bytes': len(stream),
                'native_steps': native.get('steps'), 'independent': independent}

    qualification_checks = []
    def qualification_emit(name, data):
        identity = 'qualification-' + name.replace('_', '-')
        emit(identity, data)
        proofs = []
        if 'core_selection' in data and data['core_selection'] is not None:
            proofs.append(('point', data['core_selection']['proof']))
        if 'reference_selection' in data and data['reference_selection'] is not None:
            proofs.append(('reference', data['reference_selection']['proof']))
        if 'explicit_selection' in data and data['explicit_selection'] is not None:
            proofs.append(('explicit', data['explicit_selection']['proof']))
        if 'backward' in data and data['backward']['status'] == 'DERIVABLE':
            proofs.append(('control', data['backward']['proof']))
        if name == 'SHARED-DAG':
            for control in data['controls']:
                if control['result']['status'] == 'DERIVABLE':
                    proofs.append(('control-' + str(control['slots']), control['result']['proof']))
        for lane, proof in proofs:
            require(type(proof) is list and proof, 'complete qualification proof')
            qualification_checks.append({'id': identity, 'lane': lane,
                'check': checked_proof(identity, lane, data['problem'], proof),
                'goal_ancestry': proof_ancestry(proof, data['problem']['theory']['axioms'], budget)})
    qualification = call('graph_audit', 'qualify', modules['compiler'], modules['reference'],
                         modules['engine'], modules['vengine'], modules['explicit'], modules['independent'],
                         qualification_emit)
    emit('whole-indexed-point-qualification', qualification)
    require(qualification['status'] == 'PASS' and len(qualification_checks) == expected_qualification_checks,
            'whole prospective qualification and native-check census')
    rows = []
    for name in design['order']:
        given = (calibrations if name in calibrations else cases)[name]
        problem = dict(given, profile=profile)
        slots = design['slots'][name]
        input_image = raw_json(problem)
        emit(name + '-input', dict(problem, slots=slots))
        before = time.perf_counter()
        built = call('compiler', 'build_basis', problem['theory'], problem['goal'],
                     profile, limits['basis'])
        build_seconds = time.perf_counter() - before
        require(raw_json(problem) == input_image, 'compiler preserves frozen input')
        emit(name + '-full-build', built)
        row = {'id': name, 'problem': problem, 'slots': slots,
               'build_status': built['status'], 'build_seconds': build_seconds,
               'build_costs': built['costs'], 'build_optimization': built['optimization'],
               'point': {'status': 'NOT_RUN_INCOMPLETE_BUILD'},
               'control': {'status': 'NOT_RUN_INCOMPLETE_BUILD'}}
        if built['status'] != 'COMPLETE':
            require(built['status'] == 'UNKNOWN' and built['compiled'] is None,
                    'no partial compiled universe on refusal')
            row['build_reason'] = built['reason']
            rows.append(row)
            continue
        compiled = built['compiled']
        before = time.perf_counter()
        verified = call('independent', 'verify_compiled', problem, compiled,
                        limits=limits['independent'])
        audit_seconds = time.perf_counter() - before
        emit(name + '-independent-compiled', verified)
        row['compiled_audit'] = verified
        row['compiled_audit_seconds'] = audit_seconds
        require(verified['status'] == 'VERIFIED', 'whole independent compiled binding')
        before = time.perf_counter()
        answer = call('engine', 'solve', compiled, slots, limits['point'])
        point_seconds = time.perf_counter() - before
        emit(name + '-point-full-result', answer)
        if answer['entry_state'] is not None:
            require(answer['entry_state'] == answer['restored_state'], 'full indexed final restoration')
            require(hashlib.sha256(raw_json(answer['entry_state'])).hexdigest()
                    == answer['state_hashes']['entry'] == answer['state_hashes']['restored'],
                    'full indexed entry/restored hashes')
        require(answer['stats']['trail_writes'] == answer['stats']['trail_undos'],
                'complete actual mandatory trail cleanup')
        point = {'status': answer['status'], 'reason': answer['reason'],
                 'seconds': point_seconds, 'pipeline_seconds': build_seconds + point_seconds,
                 'statistics': answer['stats'], 'event_extent': answer['event_extent'],
                 'proof': None, 'check': None, 'goal_ancestry': None,
                 'tiles': [], 'selection_audit_seconds': 0}
        if answer['status'] == 'SAT':
            before = time.perf_counter()
            selected = call('independent', 'verify_selection', problem, compiled, slots,
                            answer['selected'], limits=limits['independent'])
            point['selection_audit_seconds'] = time.perf_counter() - before
            emit(name + '-point-selection-audit', selected)
            require(selected['status'] == 'VERIFIED', 'independent selected derivation')
            decoded = call('compiler', 'decode', compiled, slots, answer['selected'])
            emit(name + '-point-decoded-certificate', decoded)
            require(decoded['status'] == 'UNVERIFIED_CERTIFICATE'
                    and decoded['proof'] == selected['proof'], 'exact independent proof agreement')
            point['proof'] = decoded['proof']
            point['check'] = checked_proof(name, 'point', problem, decoded['proof'])
            point['goal_ancestry'] = proof_ancestry(decoded['proof'], problem['theory']['axioms'], budget)
            point['tiles'] = selected['details']['candidate_bindings']
        before = time.perf_counter()
        control = call('independent', 'backward_dag', problem, compiled, slots, limits['control'])
        control_seconds = time.perf_counter() - before
        emit(name + '-control-full-result', control)
        control_summary = {'status': control['status'], 'reason': control['reason'],
                           'seconds': control_seconds,
                           'pipeline_seconds': build_seconds + control_seconds,
                           'proof': control['proof'], 'details': control['details'],
                           'costs': control['costs'], 'check': None, 'goal_ancestry': None}
        if control['status'] == 'DERIVABLE':
            require(type(control['proof']) is list and control['proof'], 'control proof explicit')
            control_summary['check'] = checked_proof(name, 'control', problem, control['proof'])
            control_summary['goal_ancestry'] = proof_ancestry(control['proof'], problem['theory']['axioms'], budget)
        for lane in (point, control_summary):
            lane['checked_total_seconds'] = (lane['pipeline_seconds'] + audit_seconds
                + lane.get('selection_audit_seconds', 0)
                + (0 if lane['check'] is None else lane['check']['seconds'])
                + (0 if lane['goal_ancestry'] is None else lane['goal_ancestry']['seconds']))
        row.update(basis_counts={k: len(compiled['logical_basis'][k]) for k in
                                 ('instantiation_terms', 'terms', 'variables', 'formulas', 'templates')},
                   instance_count=len(compiled['zero_instances']), point=point, control=control_summary)
        require(raw_json(problem) == input_image, 'all lanes preserve frozen input')
        rows.append(row)
        emit(name + '-whole-case-result', row)
    require(len(rows) == 8, 'all prospective cases observed once')
    result = {'schema': 'W-scalable-first-order-proof-search-study-v1', 'status': 'COMPLETE',
              'results': rows, 'profile': profile, 'limits': limits,
              'qualification': qualification, 'qualification_checks': qualification_checks,
              'bridge_records': bridge_records,
              'native_preparation_seconds': native_preparation_seconds,
              'outer_public_calls': dict(calls), 'artifacts': list(artifacts),
              'scope': 'Eight unchanged U assertion-only cases and line bounds. Complete interned '
                       'logical catalogue with bounded LRU/scratch compiler, aggregate exact indexed point graph and shared-fact '
                       'backward DAG control. Main preparation failures are UNKNOWN. All chosen '
                       'whole proofs checked by actual unchanged native C1 and independent B. '
                       'No RL, unrestricted PA/Hilbert/FOL completeness, fixed universal literal '
                       'Wang palette or superiority claim. Tiny qualification compares full '
                       'V/U projection, old V engine, explicit domains/every observed transition. Main graph '
                       'integrity relies on Source review, tiny qualification, full entry/restored '
                       'images and independently checked final proofs, not exhaustive main histories. '
                       'Pipeline excludes separately retained common native initialization, '
                       'qualification, output serialization; checked_total adds compiled audit, '
                       'selection audit where applicable, certificate verification and goal ancestry. Work '
                       'counters differ by implementation and cannot establish speed ratios. Automatic '
                       'goal ancestry reports only actual dependency-reachable axiom names; '
                       'no teacher path or minimum-proof assertion is supplied.'}
    result_ref = emit('worker-result', result)
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'post plan guard')
    require(marker_path.read_bytes() == marker_raw, 'post marker guard')
    require(read_ref(marker['authority']) == authority_raw, 'post authority guard')
    require(read_ref(marker['consumed']) == consume_raw, 'post consumed guard')
    budget()
    sys.stdout.buffer.write(raw_json({'status': 'COMPLETE', 'result': result_ref,
        'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
        'elapsed_seconds': time.perf_counter() - started,
        'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
    sys.stdout.buffer.flush()
    return 0


def observer(plan_path, authority_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    authority_raw = Path(authority_path).read_bytes()
    check_authority(authority_raw, plan_path, plan_raw, plan)
    directory = Path(plan['actual_dir'])
    require(not directory.exists() and not directory.is_symlink(), 'fresh output directory')
    consumed = Path(str(authority_path) + '.CONSUMED.json')
    consume_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'})
    put(consumed, consume_raw)
    directory.mkdir(parents=True)
    marker_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                           'consumed': raw_ref(consumed, consume_raw)})
    put(directory / 'CONSUMED.json', marker_raw)
    command = [PYTHON, '-I', '-S', '-B', plan['bootstrap']['path'],
               plan['sources']['runner']['path'], str(len(sources['runner'])),
               plan['sources']['runner']['sha256'], '--mode', 'worker', '--plan', str(plan_path)]
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    observed_bytes = {'stdout': 0, 'stderr': 0}
    eof = {'stdout': False, 'stderr': False}
    child = selector = None
    wait_status = usage = None
    failure = cleanup_deadline = None
    cleanup_errors = []
    sent = 0
    group_gone = False

    def kill_owned():
        if child is not None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'stage': 'killpg', 'type': type(error).__name__,
                                       'errno': error.errno})

    def fault(reason):
        nonlocal failure, cleanup_deadline
        if failure is None:
            failure = reason
            cleanup_deadline = time.perf_counter() + 5
            kill_owned()

    def observe_wait_and_group():
        nonlocal wait_status, usage, group_gone
        if child is None:
            return
        if wait_status is None:
            pid, status, ru = os.wait4(child.pid, os.WNOHANG)
            if pid:
                wait_status, usage = status, ru
                child.returncode = os.waitstatus_to_exitcode(status)
        if wait_status is not None:
            try:
                os.killpg(child.pid, 0)
                group_gone = False
            except ProcessLookupError:
                group_gone = True

    def pump_events():
        nonlocal sent
        for key, _ in selector.select(timeout=0.05):
            if key.data == 'stdin':
                if failure is not None:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    continue
                try:
                    count = os.write(key.fileobj.fileno(), sources['runner'][sent:sent + 65536])
                    sent += count
                    if sent == len(sources['runner']):
                        selector.unregister(key.fileobj); key.fileobj.close()
                except BrokenPipeError:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    fault('INCOMPLETE_STDIN_BROKEN_PIPE')
                continue
            block = os.read(key.fileobj.fileno(), 65536)
            if not block:
                eof[key.data] = True
                selector.unregister(key.fileobj); key.fileobj.close()
            else:
                observed_bytes[key.data] += len(block)
                room = max(0, 1048576 - len(captured[key.data]))
                captured[key.data].extend(block[:room])
                if observed_bytes[key.data] > 1048576:
                    fault('STREAM_CAP_PREFIX_RETAINED')

    try:
        # Every post-spawn setup operation is protected. Retained Source stdin
        # is written nonblocking under the same observer deadline as capture.
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, cwd=ROOT / 'root', start_new_session=True)
        selector = selectors.DefaultSelector()
        for name, stream, mode in [('stdin', child.stdin, selectors.EVENT_WRITE),
                                  ('stdout', child.stdout, selectors.EVENT_READ),
                                  ('stderr', child.stderr, selectors.EVENT_READ)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, mode, name)
        while True:
            if failure is None and time.perf_counter() - started >= 390:
                fault('OBSERVER_WALL_TIMEOUT')
            if cleanup_deadline is not None and time.perf_counter() >= cleanup_deadline:
                break
            pump_events()
            observe_wait_and_group()
            if wait_status is not None and all(eof.values()) and group_gone:
                break
            if wait_status is not None and not group_gone:
                fault('OWNED_DESCENDANT_GROUP_REMAINS')
    except BaseException as error:
        fault('OBSERVER_HOST_' + type(error).__name__)
    finally:
        confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
        if child is not None and not confirmed:
            fault('UNCONFIRMED_OWNED_PROCESS_OR_STREAM')
            # No blocking wait is used, even after SIGKILL. Any unconfirmed
            # ownership is explicit evidence and cannot be admitted COMPLETE.
            while time.perf_counter() < cleanup_deadline:
                try:
                    if selector is not None:
                        pump_events()
                    else:
                        time.sleep(0.01)
                    observe_wait_and_group()
                    if wait_status is not None and all(eof.values()) and group_gone:
                        break
                except BaseException as error:
                    cleanup_errors.append({'stage': 'bounded-cleanup', 'type': type(error).__name__})
                    break
        if selector is not None:
            selector.close()
        if child is not None:
            for stream in (child.stdin, child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
    streams = {k: put(directory / (k + '.bin'), bytes(v)) for k, v in captured.items()}
    terminal = None
    confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
    if (confirmed and child.returncode == 0 and not failure and not captured['stderr']
            and sent == len(sources['runner'])):
        terminal = json.loads(captured['stdout'])
        require(terminal['status'] == 'COMPLETE', 'whole worker terminal')
        read_ref(terminal['result']['stored'], 67108864)
    files, total = [], 0
    for p in sorted(directory.iterdir()):
        require(p.is_file() and not p.is_symlink(), 'closed regular output')
        raw = p.read_bytes(); total += len(raw)
        require(len(raw) <= 67108864 and total <= 536870912, 'whole readback ceilings')
        files.append(raw_ref(p, raw))
    require(len(files) <= 383, 'whole output count')
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'observer post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'observer post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'observer post plan guard')
    require(Path(authority_path).read_bytes() == authority_raw, 'observer post authority guard')
    require(consumed.read_bytes() == consume_raw, 'observer post consumed guard')
    require((directory / 'CONSUMED.json').read_bytes() == marker_raw, 'observer post marker guard')
    outcome = {'schema': 'W-owned-scalable-first-order-observer-result-v1',
               'status': 'COMPLETE' if terminal is not None else 'UNADMITTED',
               'child_pid': None if child is None else child.pid, 'command': command,
               'returncode': None if child is None else child.returncode,
               'failure': failure, 'cleanup_errors': cleanup_errors,
               'wait_confirmed': wait_status is not None, 'both_streams_EOF': all(eof.values()),
               'group_gone': group_gone, 'stdin_bytes_sent': sent,
               'observed_stream_bytes': observed_bytes, 'retained_streams_complete':
                   {k: observed_bytes[k] == len(captured[k]) for k in captured},
               'streams': streams, 'worker_terminal': terminal, 'files': files,
               'stored_bytes': total, 'wait4_peak_bytes': None if usage is None else usage.ru_maxrss,
               'whole_observer_seconds': time.perf_counter() - started,
               'scope': 'One fresh child. wait4 lifetime RSS on Darwin; no hard RAM quota. '
                        'Owned nonblocking wait/drain with390s sampled deadline and5s cleanup. '
                        'OS spawn, final readback/serialization tail are not an OS hard whole-lifetime '
                        'quota. Unconfirmed process, streams or group forbid COMPLETE.'}
    receipt = put(directory / 'observer-result.json', raw_json(outcome))
    sys.stdout.buffer.write(raw_json({'status': outcome['status'], 'receipt': receipt}))
    sys.stdout.buffer.flush()
    return 0 if terminal is not None else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('worker', 'observer'), required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority')
    args = parser.parse_args()
    if args.mode == 'worker':
        require(args.authority is None, 'worker has no authority path')
        return worker(args.plan)
    require(args.authority is not None, 'observer needs once authority')
    return observer(args.plan, args.authority)


if __name__ == '__main__':
    raise SystemExit(main())
