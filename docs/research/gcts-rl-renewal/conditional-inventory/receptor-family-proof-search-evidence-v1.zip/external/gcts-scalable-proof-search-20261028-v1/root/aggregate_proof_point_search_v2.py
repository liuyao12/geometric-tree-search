"""Complete implicit proof-row graph, exact sparse aggregate degrees.

No project imports or module-body subject calls. All virtual U member IDs
remain; only their bookkeeping representation changes. Kernel checking is external.
"""
import hashlib
import json
import math
import time

VERSION = 'W-AGGREGATE-UNIT-PROOF-POINT-SEARCH-v1'

class InputError(ValueError):
    pass

class _Stop(Exception):
    def __init__(self, owner, reason):
        self.owner, self.reason = owner, reason

def _need(ok, reason):
    if not ok:
        raise InputError(reason)

def _wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')

def _hash(value):
    return hashlib.sha256(_wire(value)).hexdigest()

class _Meter:
    def __init__(self, limits):
        _need(type(limits) is dict and set(limits)=={'wall_seconds','max_nodes','max_operations','max_definitions','max_virtual_members','max_events'},'limits exact6')
        w=limits['wall_seconds']
        _need(type(w)in(int,float) and 0<w<=60 and math.isfinite(w),'wall')
        _need(all(type(v)is int and 0<=v<=10**12 for k,v in limits.items()if k!='wall_seconds'),'integer limits')
        self.limits=dict(limits);self.start=time.perf_counter()
        self.stats={k:0 for k in ('operations','nodes','definitions','families','virtual_members','dependency_links','row_refreshes','member_probes','placements','forced_placements','branch_decisions','backtracks','scoped_exclusions','trail_writes','trail_undos','max_trail','cleanup_undos','observations','events')}
    def tick(self,n=1):
        if n>self.limits['max_operations']-self.stats['operations']:
            raise _Stop(self,'MAX_OPERATIONS')
        self.stats['operations']+=n
        if time.perf_counter()-self.start>=self.limits['wall_seconds']:
            raise _Stop(self,'WALL_SECONDS')
    def node(self):
        self.tick()
        if self.stats['nodes']>=self.limits['max_nodes']:
            raise _Stop(self,'MAX_NODES')
        self.stats['nodes']+=1

def _point_model(compiled,n,m):
    _need(type(compiled)is dict and compiled.get('schema')=='V-interned-Hilbert8-basis-v1' and compiled.get('version')=='V-INTERNED-FINITE-HILBERT8-v1','compiled identity')
    _need(type(n)is int and 1<=n<=64,'slots')
    colors=compiled['logical_basis']['colors']
    _need(type(colors)is list and all(type(c)is str for c in colors),'literal colors')
    m.tick(sum(len(c)+1 for c in colors))
    _need(colors==sorted(set(colors)),'unique ordered colors')
    def fid(x):
        _need(type(x)is int and 0<=x<len(colors),'formula ID');return x
    zero=[]
    for i,r in enumerate(compiled['zero_instances']):
        m.tick();_need(type(r)is dict and r.get('id')=='i'+str(i),'zero identity')
        zero.append([r['id'],fid(r['formula_id'])])
    mp=[];gen=[]
    for r in compiled['mp_index']:
        m.tick();_need(type(r)is list and len(r)==3,'MP triple');mp.append([fid(v)for v in r])
    for r in compiled['gen_index']:
        m.tick();_need(type(r)is list and len(r)==3 and type(r[2])is str,'GEN triple');gen.append([fid(r[0]),fid(r[1]),r[2]])
    _need([r[0]for r in mp]==sorted(set(r[0]for r in mp)) and [r[0]for r in gen]==sorted(set(r[0]for r in gen)),'unique ordered index heads')
    return dict(slots=n,colors=list(colors),goal_id=fid(compiled['goal_id']),zero=zero,mp_index=mp,gen_index=gen)

class _Group:
    """Immutable after index preparation: no row-by-formula caches."""
    def __init__(self):
        self.zero=self.K=self.D=self.G=0
        self.left={};self.body={}
    def add(self,kind,out,left,right):
        if kind=='zero':self.zero+=1
        elif kind=='gen':
            self.G+=1;self.body[left]=self.body.get(left,0)+1
        else:
            self.K+=1;self.D+=int(left!=right);self.left[left]=self.left.get(left,0)+1

class _State:
    def __init__(self,model,m):
        self.model,self.m=model,m;self.n=model['slots'];n=self.n
        self.occupied=[False]*n;self.selected=[None]*n;self.values=[None]*n;self.refs=[0]*n
        self.bans=[{}for _ in range(n)];self.trail=[]
        predicted=len(model['zero'])+len(model['mp_index'])+len(model['gen_index'])
        if predicted>m.limits['max_definitions']:raise _Stop(m,'MAX_DEFINITIONS')
        definitions=[]
        for iid,out in model['zero']:m.tick();definitions.append((iid,'zero',out,None,None))
        for head,a,out in model['mp_index']:m.tick();definitions.append(('mp:'+str(head)+':','mp',out,a,head))
        for head,body,var in model['gen_index']:m.tick();definitions.append(('gen:'+str(head)+':','gen',head,body,None))
        m.tick(len(definitions)*max(1,len(definitions).bit_length()))
        self.definitions=tuple(sorted(definitions))
        self.by_suffix={};self.by_out={};self.mp={r[0]:(r[1],r[2])for r in model['mp_index']}
        self.group=_Group();self.groups={};self.empty=_Group()
        for d,(suffix,kind,out,left,right)in enumerate(self.definitions):
            m.tick();_need(suffix not in self.by_suffix,'disjoint definitions');self.by_suffix[suffix]=d
            self.by_out.setdefault(out,[]).append(d)
            self.group.add(kind,out,left,right)
            if out not in self.groups:self.groups[out]=_Group()
            self.groups[out].add(kind,out,left,right)
        self.all_indices=tuple(range(len(self.definitions)))
        self.by_out={out:tuple(ds)for out,ds in self.by_out.items()}
        self.goal_indices=self.by_out.get(model['goal_id'],())
        self.lex_refs=[tuple(sorted(range(i),key=str))for i in range(n)]
        self.lex_mp_refs=[tuple(sorted(range(i),key=lambda x:str(x)+':'))for i in range(n)]
        self.summaries=[self.summary(i)for i in range(n)]
        self.degrees=[s[7]for s in self.summaries]
        m.stats['definitions']=len(self.definitions)
        m.stats['families']=(n-1)*len(self.definitions)+len(self.goal_indices)
        all_nonzero=self.group.K+self.group.G
        goal_group=self.groups.get(model['goal_id'],self.empty)
        m.stats['dependency_links']=(n-1)*self.group.zero+all_nonzero*(n-1)*n//2+goal_group.zero+n*(goal_group.K+goal_group.G)
        m.stats['virtual_members']=sum(self.degrees)
        if m.stats['virtual_members']>m.limits['max_virtual_members']:
            raise _Stop(m,'MAX_VIRTUAL_MEMBERS')

    def graph(self):
        return {'schema':'W-complete-implicit-row-family-index-v1',
            'definitions':[list(d)for d in self.definitions],
            'row_definition_set':[0]*(self.n-1)+[1],
            'definition_sets':[{'range':[0,len(self.definitions)]},{'indices':list(self.goal_indices)}],
            'definition_reverse_row_set':[int(d[2]==self.model['goal_id'])for d in self.definitions],
            'reverse_row_sets':[{'range':[0,self.n-1]},{'range':[0,self.n]}],
            'nonzero_definitions':[i for i,d in enumerate(self.definitions)if d[1]!='zero'],
            'marking_dependencies':{'own_row':'all static row definitions','later_rows':'nonzero static row definitions','reverse':'own row plus all earlier row indices for nonzero definitions; own row only for zero'},
            'member_incidence':'Canonical member ID gives own row and one unit t edge. Definition plus earlier ref fields gives exact m support. Reference products omit inconsistent coincident refs. These are descriptors of every virtual member, not one candidate per definition.'}

    def put(self,array,key,value):
        self.m.tick()
        if array[key]==value:return
        self.trail.append(('array',array,key,array[key]));array[key]=value
        self.wrote()
    def wrote(self):
        self.m.stats['trail_writes']+=1;self.m.stats['max_trail']=max(self.m.stats['max_trail'],len(self.trail))
    def compatible(self,p,f):return self.values[p]is None or self.values[p]==f
    def parse(self,cid):
        self.m.tick();_need(type(cid)is str and len(cid)<=128,'member string')
        parts=cid.split(':');_need(len(parts)>=2 and parts[0].startswith('r'),'member row')
        row=int(parts[0][1:]);_need(0<=row<self.n,'row range')
        if len(parts)==2:suffix=parts[1];a=b=None
        elif len(parts)==4 and parts[1]=='gen':suffix=':'.join(parts[1:3])+':';a=int(parts[3]);b=None
        elif len(parts)==5 and parts[1]=='mp':suffix=':'.join(parts[1:3])+':';a=int(parts[3]);b=int(parts[4])
        else:raise InputError('member shape')
        _need(suffix in self.by_suffix,'member definition');d=self.by_suffix[suffix]
        expected='r'+str(row)+':'+suffix+(''if a is None else str(a)+(''if b is None else ':'+str(b)))
        _need(cid==expected and (row!=self.n-1 or self.definitions[d][2]==self.model['goal_id']),'canonical static member')
        return row,d,a,b
    def marks(self,member):
        row,d,a,b=member;suffix,kind,out,left,right=self.definitions[d]
        values={row:out}
        if kind!='zero':
            _need(type(a)is int and 0<=a<row,'strict earlier source');values[a]=left
        if kind=='mp':
            _need(type(b)is int and 0<=b<row,'strict earlier implication')
            if b in values and values[b]!=right:return None
            values[b]=right
        return values
    def raw_legal(self,member):
        row=member[0]
        if self.occupied[row]:return False
        marks=self.marks(member)
        return marks is not None and all(self.compatible(p,f)for p,f in marks.items())
    def forbidden(self,cid,member):
        return cid in self.bans[member[0]].get(member[1],())
    def summary(self,row):
        self.m.tick()
        if self.occupied[row]:return None
        hist={};u=0
        for value in self.values[:row]:
            self.m.tick()
            if value is None:u+=1
            else:hist[value]=hist.get(value,0)+1
        out=self.model['goal_id']if row==self.n-1 else self.values[row]
        if row==self.n-1 and not self.compatible(row,out):g=self.empty
        else:g=self.group if out is None else self.groups.get(out,self.empty)
        S=Q=weighted=0
        for f,count in hist.items():
            self.m.tick();edge=self.mp.get(f);enabled=g is not self.empty and edge is not None and (out is None or edge[1]==out)
            S+=count*(g.left.get(f,0)+int(enabled))
            if enabled:Q+=count*hist.get(edge[0],0)
            weighted+=count*g.body.get(f,0)
        mp_count=g.K*u*u-g.D*u+u*S+Q;gen_count=g.G*u+weighted
        excluded=0
        for ds in self.bans[row].values():
            for cid in ds:
                self.m.tick()
                if self.raw_legal(self.parse(cid)):excluded+=1
        degree=g.zero+mp_count+gen_count-excluded
        _need(degree>=0,'nonnegative complete aggregate degree')
        return (u,tuple(sorted(hist.items())),out,g.zero,(g.K,g.D,S,Q,mp_count),(g.G,weighted,gen_count),excluded,degree)
    def refresh(self,rows):
        for row in sorted(rows):
            self.m.tick();self.m.stats['row_refreshes']+=1
            summary=self.summary(row);self.put(self.summaries,row,summary)
            self.put(self.degrees,row,0 if summary is None else summary[7])
    def first(self,row):
        _need(not self.occupied[row] and self.degrees[row]>0,'nonempty frontier')
        summary=self.summaries[row];u=summary[0];hist=dict(summary[1]);out=summary[2]
        indices=self.all_indices if out is None else self.by_out.get(out,())
        for d in indices:
            self.m.tick();suffix,kind,output,left,right=self.definitions[d]
            prefix='r'+str(row)+':'+suffix;banned=self.bans[row].get(d,())
            if kind=='zero':
                if prefix not in banned:return prefix
                continue
            count=u+hist.get(left,0)
            if kind=='mp':count=count*(u+hist.get(right,0))-(u if left!=right else 0)
            if count==0:continue
            aa=self.lex_refs[row]if kind=='gen'else self.lex_mp_refs[row]
            for a in aa:
                if not self.compatible(a,left):continue
                for b in ((None,)if kind=='gen'else self.lex_refs[row]):
                    self.m.tick();self.m.stats['member_probes']+=1
                    if b is not None and (not self.compatible(b,right)or a==b and left!=right):continue
                    cid=prefix+str(a)+(''if b is None else ':'+str(b))
                    if cid not in banned:return cid
        raise RuntimeError('complete nonempty row has no first member')
    def place(self,cid):
        member=self.parse(cid);row=member[0]
        _need(self.raw_legal(member)and not self.forbidden(cid,member),'legal chosen member')
        self.put(self.occupied,row,True);self.put(self.selected,row,cid);dirty={row}
        for p,f in self.marks(member).items():
            self.m.tick()
            if self.values[p]is None:
                self.put(self.values,p,f);dirty.update(range(p,self.n))
            else:_need(self.values[p]==f,'literal agreement')
            self.put(self.refs,p,self.refs[p]+1)
        self.refresh(dirty);self.m.stats['placements']+=1
    def exclude(self,cid):
        row,d,a,b=self.parse(cid);groups=self.bans[row]
        if d not in groups:
            self.m.tick();self.trail.append(('dict_new',groups,d,None));groups[d]=set();self.wrote()
        _need(cid not in groups[d],'new scoped ban')
        self.m.tick();self.trail.append(('set_new',groups[d],cid,None));groups[d].add(cid);self.wrote()
        self.refresh((row,));self.m.stats['scoped_exclusions']+=1
    def core(self):
        return dict(occupied=list(self.occupied),selected=list(self.selected),values=list(self.values),refs=list(self.refs),excluded=sorted(cid for row in self.bans for group in row.values()for cid in group))
    def snapshot(self):
        s=self.core();s.update(schema='W-aggregate-unit-point-state-v1',required=['slot:'+str(i)for i in range(self.n)],frontier=['slot:'+str(i)for i in range(self.n)if not self.occupied[i]],root_generations=[0]*self.n,degrees=list(self.degrees),aggregates=[None if x is None else [x[0],[list(p)for p in x[1]],x[2],x[3],list(x[4]),list(x[5]),x[6],x[7]]for x in self.summaries]);return s
    def undo(self,target,cleanup=False):
        count=0
        while len(self.trail)>target:
            kind,container,key,old=self.trail.pop()
            if kind=='array':container[key]=old
            elif kind=='set_new':container.remove(key)
            else:del container[key]
            count+=1;self.m.stats['trail_undos']+=1
            if cleanup:self.m.stats['cleanup_undos']+=1
        return count


def solve(compiled, slots, limits, *, observe=None):
    """Exact virtual-member search. Caller must freeze the logical catalogue."""
    m = _Meter(limits)
    _need(observe is None or callable(observe), 'observer callable')
    state = model = entry = restored = None
    model_hash = entry_hash = restored_hash = None
    selected = certificate = None
    status, reason, fatal = 'UNKNOWN', 'PREPARATION_INCOMPLETE', None
    events, rollbacks, stack = [], [], []
    digest = hashlib.sha256(); event_bytes = 0

    def emit(kind, data):
        nonlocal event_bytes
        m.tick()
        event = dict(seq=m.stats['events'], kind=kind, data=data)
        raw = _wire(event); m.tick(len(raw)); digest.update(raw); event_bytes += len(raw)
        m.stats['events'] += 1
        if len(events) < m.limits['max_events']:
            events.append(event)
        if observe is not None:
            snapshot = state.snapshot()
            detached = json.loads(_wire(snapshot)); m.tick(len(_wire(snapshot)))
            m.stats['observations'] += 1
            observe(json.loads(raw), detached)
            m.tick()

    try:
        model = _point_model(compiled, slots, m)
        model_hash = _hash(model); m.tick(len(_wire(model)))
        state = _State(model, m)
        entry = state.snapshot(); entry_hash = _hash(entry); m.tick(len(_wire(entry)))
        emit('ENTRY', {})
        while True:
            m.node()
            frontier = [i for i in range(slots) if not state.occupied[i]]
            ordered = sorted(frontier, key=lambda i: 'slot:' + str(i))
            dead = next((i for i in ordered if state.degrees[i] == 0), None)
            if dead is not None:
                emit('DEAD', {'row': dead, 'generation': 0})
                if not stack:
                    status, reason = 'UNSAT', 'COMPLETE_VIRTUAL_UNIVERSE_EXHAUSTED'
                    break
                target, child, parent_hash = stack.pop()
                before = _hash(state.core()); writes = state.undo(target)
                after = _hash(state.core())
                _need(after == parent_hash, 'complete parent core restored')
                record = dict(reason='FAILED_CHILD', target=target, undone=writes,
                              before_core_sha256=before, after_core_sha256=after,
                              expected_parent_core_sha256=parent_hash)
                rollbacks.append(record); m.stats['backtracks'] += 1
                emit('ROLLBACK', record)
                state.exclude(child)
                emit('EXCLUDED', {'candidate': child, 'parent_core_sha256': parent_hash})
                continue
            if not frontier:
                chosen = sorted(x for x in state.selected if x is not None)
                totals, marks, refs = [0] * slots, {}, {}
                for cid in chosen:
                    m.tick(); member = state.parse(cid); totals[member[0]] += 1
                    for p, v in state.marks(member).items():
                        _need(p not in marks or marks[p] == v, 'whole selected m')
                        marks[p] = v; refs[p] = refs.get(p, 0) + 1
                _need(totals == [1] * slots and all(marks[i] == state.values[i]
                      and refs[i] == state.refs[i] for i in range(slots)), 'whole selected t/m/refcounts')
                selected = chosen
                certificate = dict(selected=chosen, totals=totals,
                    markings=[[i, model['colors'][marks[i]], refs[i]] for i in range(slots)],
                    generations=[[cid, 1] for cid in chosen])
                emit('SOLUTION', {'selected': chosen})
                status, reason = 'SAT', 'EXACT_FINITE_POINT_AND_LITERAL_MARKINGS'
                break
            forced = next((i for i in ordered if state.degrees[i] == 1), None)
            if forced is not None:
                cid = state.first(forced); state.place(cid)
                m.stats['forced_placements'] += 1
                emit('PLACED', {'candidate': cid, 'row': forced, 'forced': True,
                                'root_generation': 0, 'tile_generation': 1})
                continue
            row = min(frontier, key=lambda i: (state.degrees[i], 'slot:' + str(i)))
            cid = state.first(row)
            parent_hash = _hash(state.core())
            emit('BRANCH', {'row': row, 'generation': 0, 'degree': state.degrees[row],
                            'first_candidate': cid, 'order': 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'})
            stack.append((len(state.trail), cid, parent_hash))
            m.stats['branch_decisions'] += 1
            state.place(cid)
            emit('PLACED', {'candidate': cid, 'row': row, 'forced': False,
                            'root_generation': 0, 'tile_generation': 1})
    except BaseException as error:
        if type(error) is _Stop and error.owner is m:
            reason = error.reason
        else:
            fatal = error
        status, selected, certificate = 'UNKNOWN', None, None
    finally:
        cleanup_start = time.perf_counter()
        if state is not None:
            before = _hash(state.core()); undone = state.undo(0, cleanup=True)
            restored = state.snapshot(); restored_hash = _hash(restored)
            rollbacks.append(dict(reason='FINAL_MANDATORY_CLEANUP', target=0, undone=undone,
                before_core_sha256=before, after_core_sha256=_hash(state.core()),
                full_restored_sha256=restored_hash))
            if entry is not None and restored != entry:
                fatal = RuntimeError('full indexed state restoration failed')
        m.stats['cleanup_seconds'] = time.perf_counter() - cleanup_start
    if fatal is not None:
        raise fatal
    m.stats['elapsed_seconds'] = time.perf_counter() - m.start
    return dict(schema='W-aggregate-unit-point-result-v1', version=VERSION,
        status=status, reason=reason, model=model,
        families=None if state is None else state.graph(),
        model_sha256=model_hash, selected=selected, certificate=certificate,
        stats=m.stats, events=events,
        event_extent=dict(count=m.stats['events'], retained=len(events), JSONL_bytes=event_bytes,
                          SHA256=digest.hexdigest(), evaluation_complete=status in ('SAT', 'UNSAT')),
        entry_state=entry, restored_state=restored,
        state_hashes=dict(entry=entry_hash, restored=restored_hash), rollback_records=rollbacks,
        scope='Exact finite anchored unit all-root0 aggregate point adaptation. Complete virtual '
              'candidate identity counts, not sampled families. Native proof validity separate. '
              'No fractional/shared-support/growing geometry, unrestricted FOL, RL or Wang claim. '
              'Per-rollback hashes cover core values; full row aggregates appear in entry/restored and '
              'tiny observer snapshots only. Cleanup/final observation/serialization can exceed '
              'cooperative search wall; outer owned-process quotas required separately.')
