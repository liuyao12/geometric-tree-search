"""Inert independent tiny exhaustive virtual-graph qualification.

All producers/checker are injected only by a future owned once. No project
imports, IO, module-body fixtures or subject calls. Public audit_state assumes
an independently verified COMPLETE compiled catalogue; it checks point graphs,
not native schema truth. Main benchmarks need not retain full tiny snapshots.
"""
import hashlib
import collections
import itertools
import json
import math
import time

VERSION = 'W-INDEPENDENT-AGGREGATE-GRAPH-QUALIFICATION-v1'
AUDIT_LIMITS = dict(wall_seconds=15, max_work=20000000)
ENGINE_LIMITS = dict(wall_seconds=2, max_nodes=50000,
                     max_operations=20000000, max_definitions=10000,
                     max_virtual_members=100000, max_events=100000)
BUILD_LIMITS = dict(wall_seconds=2, max_work=20000000, max_basis=10000,
                    max_instances=10000, max_depth=128,
                    max_cache_entries=100000, max_interned=100000)
ROW_LIMITS = dict(wall_seconds=2, max_work=20000000,
                  max_candidates=100000, max_depth=128)
PRODUCT_CAP = 20000
SCOPE = ('Independent complete tiny explicit candidate universe, every retained '
         'observer image and finite full-tiling enumeration. Native logical '
         'basis/schema truth is Source-reviewed; whole proofs still need actual '
         'native C1 and independent B. No post-throw state or full main history '
         'is fabricated. No unrestricted FOL or performance claim.')


class AuditError(ValueError):
    pass


class AuditBudget(Exception):
    pass


def _need(ok, message):
    if not ok:
        raise AuditError(message)


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys)
          and all(type(k) is str for k in x) and set(x) == set(keys), 'fields')


class _Meter:
    def __init__(self, limits=None, wall=15, work=20000000):
        self.start = time.perf_counter()
        limits = dict(wall_seconds=wall, max_work=work) if limits is None else limits
        _fields(limits, {'wall_seconds', 'max_work'})
        w = limits['wall_seconds']
        _need(type(w) in (int, float) and 0 < w <= 60 and math.isfinite(w), 'wall')
        _need(type(limits['max_work']) is int and 0 <= limits['max_work'] <= 1000000000,
              'work limit')
        self.wall = w
        self.maximum = limits['max_work']
        self.work = 0

    def tick(self, n=1):
        if n > self.maximum - self.work:
            raise AuditBudget('WORK')
        self.work += n
        if time.perf_counter() - self.start > self.wall:
            raise AuditBudget('WALL')


def _weight(value, m, depth=0):
    m.tick()
    if depth > 128:
        raise AuditBudget('DEPTH')
    if value is None or type(value) is bool:
        return 5
    if type(value) is int:
        _need(value.bit_length() <= 256, 'bounded integer wire')
        return 80
    if type(value) is float:
        _need(math.isfinite(value), 'finite wire')
        return 32
    if type(value) is str:
        m.tick(len(value))
        return 2 + 12 * len(value)
    if type(value) is list:
        m.tick(len(value))
        return 2 + sum(1 + _weight(v, m, depth + 1) for v in value)
    _need(type(value) is dict and all(type(k) is str for k in value), 'native wire')
    m.tick(len(value))
    return 2 + sum(2 + _weight(k, m, depth + 1) + _weight(v, m, depth + 1)
                   for k, v in value.items())


def _wire(value, m):
    upper = _weight(value, m)
    m.tick(upper)
    if upper > 16000000:
        raise AuditBudget('WIRE')
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _same(a, b, m):
    return _wire(a, m) == _wire(b, m)


def _sha(value, m):
    return hashlib.sha256(_wire(value, m)).hexdigest()


def _clone(value, m):
    return json.loads(_wire(value, m))


def _model(compiled, slots, m):
    _need(type(slots) is int and 1 <= slots <= 64, 'slots')
    # Full logical catalogue validation belongs to separately injected L core.
    colors = compiled['logical_basis']['colors']
    m.tick(len(colors) + len(compiled['zero_instances']))
    return {'slots': slots, 'colors': list(colors), 'goal_id': compiled['goal_id'],
            'zero': [[r['id'], r['formula_id']] for r in compiled['zero_instances']],
            'mp_index': _clone(compiled['mp_index'], m),
            'gen_index': _clone(compiled['gen_index'], m)}


def _graph(compiled, slots, m):
    model = _model(compiled, slots, m)
    forms = compiled['logical_basis']['formulas']
    zero = {r['id']: r for r in compiled['zero_instances']}
    families = []
    candidates = {}
    steps = {}
    for row in range(slots):
        for iid, output in model['zero']:
            m.tick()
            if row == slots - 1 and output != model['goal_id']:
                continue
            prefix = 'r%d:%s' % (row, iid)
            if len(families)>=10000:
                raise AuditBudget('FAMILIES')
            families.append([prefix, 'zero', row, output, None, None])
        for fi, antecedent, output in model['mp_index']:
            m.tick()
            if row != slots - 1 or output == model['goal_id']:
                if len(families)>=10000:
                    raise AuditBudget('FAMILIES')
                families.append(['r%d:mp:%d:' % (row, fi), 'mp', row,
                                 output, antecedent, fi])
        for fi, body, variable in model['gen_index']:
            m.tick()
            if row != slots - 1 or fi == model['goal_id']:
                if len(families)>=10000:
                    raise AuditBudget('FAMILIES')
                families.append(['r%d:gen:%d:' % (row, fi), 'gen', row,
                                 fi, body, None])
    m.tick(len(families))
    families.sort(key=lambda f: f[0])
    byrow = [[] for _ in range(slots)]
    deps = [[] for _ in range(slots)]
    reverse = []
    for k, family in enumerate(families):
        m.tick()
        prefix, kind, row, output, left, right = family
        byrow[row].append(k)
        points = [row] if kind == 'zero' else list(range(row + 1))
        m.tick(len(points))
        reverse.append(points)
        for point in points:
            deps[point].append(k)
        if kind == 'zero':
            options = [(prefix, {}, zero[prefix.split(':')[1]]['line'],
                        prefix.split(':')[1])]
        elif kind == 'gen':
            variable = next(v for fi, body, v in model['gen_index'] if fi == output)
            options = ((prefix + str(a), {a: left},
                       {'rule': 'generalize', 'formula': forms[output],
                        'source': a, 'variable': variable}, None)
                       for a in range(row))
        else:
            options = ((prefix + '%d:%d' % (a, b), {a: left, b: right},
                       {'rule': 'mp', 'formula': forms[output],
                        'antecedent': a, 'implication': b}, None)
                       for a in range(row) for b in range(row)
                       if a != b or left == right)
        for cid, marks, line, instance in options:
            m.tick()
            if len(candidates) >= 100000:
                raise AuditBudget('MEMBERS')
            marks[row] = output
            _need(cid not in candidates, 'candidate identity collision')
            candidates[cid] = (row, marks, k)
            steps[cid] = {'slot': row, 'line': line, 'instance': instance}
    domain = [[] for _ in range(slots)]
    raw = []
    for cid in sorted(candidates):
        m.tick()
        row, marks, family = candidates[cid]
        domain[row].append(cid)
        raw.append({'id': cid, 't': ['slot:' + str(row)],
                    'm': [[point, model['colors'][value]] for point, value in
                          sorted(('out:' + str(q), v) for q, v in marks.items())]})
    definitions = []
    for iid, output in model['zero']:
        definitions.append([iid,'zero',output,None,None])
    for fi,a,out in model['mp_index']:
        definitions.append(['mp:'+str(fi)+':','mp',out,a,fi])
    for fi,body,var in model['gen_index']:
        definitions.append(['gen:'+str(fi)+':','gen',fi,body,None])
    m.tick(len(definitions))
    definitions.sort(key=lambda d:d[0])
    goal_definitions=[k for k,d in enumerate(definitions) if d[2]==model['goal_id']]
    compressed={
        'schema':'W-complete-implicit-row-family-index-v1',
        'definitions':definitions,
        'row_definition_set':[0]*(slots-1)+[1],
        'definition_sets':[{'range':[0,len(definitions)]},{'indices':goal_definitions}],
        'definition_reverse_row_set':[int(d[2]==model['goal_id']) for d in definitions],
        'reverse_row_sets':[{'range':[0,slots-1]},{'range':[0,slots]}],
        'nonzero_definitions':[k for k,d in enumerate(definitions) if d[1]!='zero'],
        'marking_dependencies':{
            'later_rows':'nonzero static row definitions',
            'own_row':'all static row definitions',
            'reverse':'own row plus all earlier row indices for nonzero definitions; own row only for zero'},
        'member_incidence':'Canonical member ID gives own row and one unit t edge. Definition plus earlier ref fields gives exact m support. Reference products omit inconsistent coincident refs. These are descriptors of every virtual member, not one candidate per definition.'}
    return {'model': model, 'families': families, 'compressed':compressed, 'byrow': byrow,
            'deps': deps, 'reverse': reverse, 'candidates': candidates,
            'steps': steps, 'domain': domain,
            'raw_model': {'required': ['slot:' + str(q) for q in range(slots)],
                          'candidates': raw}}


def _solutions(graph, m):
    count = 1
    for domain in graph['domain']:
        m.tick()
        count *= len(domain)
        if count > PRODUCT_CAP:
            raise AuditBudget('TINY_PRODUCT')
    m.tick(count * max(1, graph['model']['slots']))
    result = []
    for selected in itertools.product(*graph['domain']):
        assigned = {}
        compatible = True
        for cid in selected:
            m.tick()
            for point, value in graph['candidates'][cid][1].items():
                m.tick()
                if point in assigned and assigned[point] != value:
                    compatible = False
                    break
                assigned[point] = value
            if not compatible:
                break
        if compatible:
            result.append(tuple(sorted(selected)))
    return count, result


def _core(state):
    return {k: state[k] for k in ('occupied', 'selected', 'values', 'refs', 'excluded')}


def _state(graph, state, m, solutions=None):
    _fields(state, {'schema','occupied','selected','values','refs','excluded',
                    'required','frontier','root_generations','degrees','aggregates'})
    _need(state['schema']=='W-aggregate-unit-point-state-v1','state schema')
    n = graph['model']['slots']
    for key in ('occupied', 'selected', 'values', 'refs'):
        _need(type(state[key]) is list and len(state[key]) == n, 'state row array')
    _need(all(type(v) is bool for v in state['occupied']), 'occupied bool')
    _need(all(v is None or type(v) is str for v in state['selected']), 'selected type')
    _need(all(v is None or type(v) is int and 0 <= v < len(graph['model']['colors'])
              for v in state['values']), 'values IDs')
    _need(all(type(v) is int and v >= 0 for v in state['refs']), 'refs type')
    excluded = state['excluded']
    _need(type(excluded) is list and all(type(cid) is str for cid in excluded)
          and excluded == sorted(set(excluded))
          and all(cid in graph['candidates'] for cid in excluded), 'excluded')
    expected_values = [None] * n
    expected_refs = [0] * n
    selected_ids = []
    for row, cid in enumerate(state['selected']):
        m.tick()
        _need(state['occupied'][row] == (cid is not None), 'occupied/selected')
        if cid is None:
            continue
        _need(cid in graph['candidates'] and graph['candidates'][cid][0] == row
              and cid not in excluded, 'selected actual member/root')
        selected_ids.append(cid)
        for point, value in graph['candidates'][cid][1].items():
            m.tick()
            _need(expected_values[point] is None or expected_values[point] == value,
                  'selected actual m conflict')
            expected_values[point] = value
            expected_refs[point] += 1
    _need(_same(state['values'], expected_values, m)
          and _same(state['refs'], expected_refs, m), 'whole assigned values/refcounts')
    # Complete physical legality independently visits every virtual candidate.
    legal = [[] for _ in range(n)]
    family_counts = [0] * len(graph['families'])
    for cid, (row, marks, k) in graph['candidates'].items():
        m.tick()
        if state['occupied'][row] or cid in excluded:
            continue
        if all(expected_values[p] is None or expected_values[p] == value
               for p, value in marks.items()):
            legal[row].append(cid)
            family_counts[k] += 1
    for domain in legal:
        m.tick(len(domain))
        domain.sort()
    aggregates=[]
    definitions=graph['compressed']['definitions']
    for row in range(n):
        m.tick()
        if state['occupied'][row]:
            aggregates.append(None)
            continue
        hist=collections.Counter(v for v in expected_values[:row] if v is not None)
        u=sum(v is None for v in expected_values[:row])
        fixed=graph['model']['goal_id'] if row==n-1 else expected_values[row]
        allowed=[d for d in definitions if fixed is None or d[2]==fixed]
        if row==n-1 and expected_values[row] is not None and expected_values[row]!=fixed:
            allowed=[]
        zero=K=D=S=Q=Kg=weighted=0
        for suffix,kind,out,a,b in allowed:
            m.tick()
            if kind=='zero':zero+=1
            elif kind=='mp':
                K+=1;D+=int(a!=b);S+=hist[a]+hist[b];Q+=hist[a]*hist[b]
            else:
                Kg+=1;weighted+=hist[a]
        mp=K*u*u-D*u+S*u+Q
        gen=Kg*u+weighted
        raw_excluded=0
        for cid in excluded:
            r,marks,k=graph['candidates'][cid]
            if r==row and all(expected_values[p] is None or expected_values[p]==v
                              for p,v in marks.items()):raw_excluded+=1
        degree=zero+mp+gen-raw_excluded
        _need(degree==len(legal[row]),'aggregate algebra agrees with every actual member')
        aggregates.append([u,[[fid,count] for fid,count in sorted(hist.items())],
                           fixed,zero,[K,D,S,Q,mp],[Kg,weighted,gen],raw_excluded,degree])
    expected={
        'required':['slot:'+str(q) for q in range(n)],
        'frontier':['slot:'+str(q) for q in range(n) if not state['occupied'][q]],
        'root_generations':[0]*n,'degrees':[len(domain) for domain in legal],
        'aggregates':aggregates}
    for key, value in expected.items():
        _need(_same(state[key], value, m), 'full graph ' + key)
    if solutions is not None:
        selected_set = set(selected_ids)
        for cid in excluded:
            m.tick(len(solutions))
            _need(not any(selected_set.union([cid]).issubset(sol) for sol in solutions),
                  'excluded member has actual full completion in this context')
    return {'status': 'VERIFIED', 'state_sha256': _sha(state, m),
            'core_sha256': _sha(_core(state), m),
            'legal_ids': legal, 'selected': sorted(selected_ids),
            'scope': 'All materialized members, factors, values/refcounts and both graph/dependency directions; optional full tiny completion exclusion proof.'}


def audit_state(compiled, slots, state, *, limits=None):
    m = _Meter(limits)
    try:
        graph = _graph(compiled, slots, m)
        result = _state(graph, state, m)
        result['work'] = m.work
        result['seconds'] = time.perf_counter() - m.start
        return result
    except AuditError as error:
        return {'status': 'REJECTED', 'reason': str(error), 'scope': SCOPE}
    except AuditBudget as error:
        return {'status': 'UNKNOWN', 'reason': str(error), 'scope': SCOPE}


def _event(graph, event, state, receipt, previous, m):
    _fields(event, {'seq', 'kind', 'data'})
    _need(type(event['seq']) is int and event['seq'] >= 0
          and type(event['kind']) is str, 'event types')
    kind, data = event['kind'], event['data']
    if previous is None:
        _need(kind == 'ENTRY' and event['seq'] == 0, 'first entry event')
        _fields(data, set())
        _need(not any(state['occupied']) and not any(state['refs'])
              and not state['excluded'], 'empty entry')
        return
    old = previous['state']
    legal = previous['audit']['legal_ids']
    if kind == 'DEAD':
        _fields(data, {'row', 'generation'})
        q = data['row']
        _need(type(q) is int and 0 <= q < len(legal) and not state['occupied'][q]
              and type(data['generation']) is int and data['generation'] == 0
              and not receipt['legal_ids'][q] and _same(old,state,m), 'actual global dead')
    elif kind == 'BRANCH':
        _fields(data, {'row', 'generation', 'degree', 'first_candidate', 'order'})
        frontier = [q for q in range(len(legal)) if not old['occupied'][q]]
        _need(frontier and all(len(legal[q]) >= 2 for q in frontier),
              'branch before global dead/forced')
        q = min(frontier, key=lambda r: (len(legal[r]), 'slot:' + str(r)))
        _need(type(data['row']) is int and data['row'] == q
              and type(data['generation']) is int and data['generation'] == 0
              and type(data['degree']) is int and data['degree'] == len(legal[q])
              and data['first_candidate'] == legal[q][0]
              and data['order'] == 'COMPLETE_U_LEXICAL_VIRTUAL_MEMBERS'
              and _same(old, state, m), 'complete MRV lexical branch')
    elif kind == 'PLACED':
        _fields(data, {'candidate', 'row', 'forced', 'root_generation', 'tile_generation'})
        q, cid = data['row'], data['candidate']
        _need(type(q) is int and 0 <= q < len(legal) and type(data['forced']) is bool
              and cid in legal[q] and state['selected'][q] == cid
              and type(data['root_generation']) is int and data['root_generation'] == 0
              and type(data['tile_generation']) is int and data['tile_generation'] == 1,
              'placed actual legal unit member')
        if data['forced']:
            frontier = [r for r in range(len(legal)) if not old['occupied'][r]]
            _need(all(legal[r] for r in frontier), 'forced before later dead')
            singles = [r for r in frontier if len(legal[r]) == 1]
            _need(singles and q == min(singles, key=lambda r: 'slot:' + str(r)),
                  'global forced lexical root')
        else:
            _need(cid == legal[q][0], 'complete lexical branch continuation')
        expected_selected = list(old['selected'])
        expected_selected[q] = cid
        _need(_same(expected_selected, state['selected'], m)
              and _same(old['excluded'], state['excluded'], m), 'one placement')
    elif kind == 'EXCLUDED':
        _fields(data, {'candidate', 'parent_core_sha256'})
        cid = data['candidate']
        _need(type(cid) is str and cid in graph['candidates']
              and data['parent_core_sha256'] == previous['audit']['core_sha256'],
              'exclusion exact parent')
        for key in ('occupied', 'selected', 'values', 'refs'):
            _need(_same(old[key], state[key], m), 'exclusion changes only exclusions')
        _need(cid not in old['excluded'] and state['excluded'] == sorted(old['excluded'] + [cid]),
              'one scoped exclusion')
    elif kind == 'ROLLBACK':
        _fields(data, {'reason', 'target', 'undone', 'before_core_sha256',
                       'after_core_sha256', 'expected_parent_core_sha256'})
        _need(data['reason'] == 'FAILED_CHILD'
              and data['before_core_sha256'] == previous['audit']['core_sha256']
              and data['after_core_sha256'] == receipt['core_sha256']
              and data['expected_parent_core_sha256'] == receipt['core_sha256'],
              'actual failed-child core restoration')
    elif kind == 'SOLUTION':
        _fields(data, {'selected'})
        _need(all(state['occupied']) and data['selected'] == receipt['selected']
              and _same(old,state,m),
              'whole actual solution event')
    else:
        raise AuditError('unexpected event kind')


def _certificate(graph, selected, indexed, m):
    n = graph['model']['slots']
    totals = [0] * n
    values = [None] * n
    refs = [0] * n
    for cid in selected:
        _need(cid in graph['candidates'], 'certificate member')
        row, marks, family = graph['candidates'][cid]
        totals[row] += 1
        for point, value in marks.items():
            _need(values[point] is None or values[point] == value, 'certificate m')
            values[point] = value
            refs[point] += 1
    _need(totals == [1] * n and all(v is not None for v in values), 'whole t/m')
    if indexed:
        return {'selected': sorted(selected), 'totals': totals,
                'markings': [[q, graph['model']['colors'][values[q]], refs[q]] for q in range(n)],
                'generations': [[cid, 1] for cid in sorted(selected)]}
    return {'selected': sorted(selected),
            'totals': [['slot:' + str(q), 1] for q in range(n)],
            'markings': [['out:' + str(q), graph['model']['colors'][values[q]], refs[q]] for q in range(n)],
            'generations': [[cid, 1] for cid in sorted(selected)]}


def _result(graph, result, observations, m, solutions=None, expected_version=None):
    _fields(result, {'schema', 'version', 'status', 'reason', 'model', 'families',
                     'model_sha256', 'selected', 'certificate', 'stats', 'events',
                     'event_extent', 'entry_state', 'restored_state', 'state_hashes',
                     'rollback_records', 'scope'})
    _need(type(result['schema']) is str and result['schema']=='W-aggregate-unit-point-result-v1'
          and type(result['version']) is str and result['version']==expected_version,
          'current result wire/version')
    _need(type(result['status']) is str and result['status'] in ('SAT','UNSAT','UNKNOWN'),
          'status')
    prepared = result['entry_state'] is not None
    if prepared:
        _need(_same(result['model'],graph['model'],m)
              and _same(result['families'],graph['compressed'],m)
              and result['model_sha256']==_sha(graph['model'],m),
              'prepared complete model/families')
    else:
        _need(result['status']=='UNKNOWN' and result['families'] is None,
              'no fabricated partial family graph')
        if result['model'] is None:
            _need(result['model_sha256'] is None,'point-model preparation refusal')
        else:
            _need(_same(result['model'],graph['model'],m)
                  and result['model_sha256']==_sha(graph['model'],m),
                  'complete point model before state-constructor refusal')
    if solutions is not None:
        _need(result['status']==('SAT' if solutions else 'UNSAT'),'tiny exhaustive outcome')
    if result['status']=='SAT':
        selected=result['selected']
        _need(type(selected) is list and selected==sorted(set(selected)),'selected shape')
        if solutions is not None:
            _need(tuple(selected) in solutions,'full tiny solution membership')
        _need(_same(result['certificate'],_certificate(graph,selected,True,m),m),
              'exact actual point certificate')
    else:
        _need(result['selected'] is None and result['certificate'] is None,
              'no false certificate')
    hashes=result['state_hashes']
    _fields(hashes,{'entry','restored'})
    if prepared:
        entry=result['entry_state']
        _state(graph,entry,m)
        _need(not any(entry['occupied']) and not any(entry['refs'])
              and all(v is None for v in entry['values']) and not entry['excluded'],
              'actual empty initial state')
        _need(result['restored_state'] is not None,'prepared restoration exists')
        _state(graph,result['restored_state'],m)
        _need(_same(entry,result['restored_state'],m)
              and hashes['entry']==_sha(entry,m)
              and hashes['restored']==_sha(result['restored_state'],m),'full restoration')
        if observations:
            _need(_same(entry,observations[0]['state'],m),'entry/first observation join')
    else:
        _need(result['restored_state'] is None
              and _same(hashes,{'entry':None,'restored':None},m)
              and not observations,'preparation-refused scope')
    extent=result['event_extent']
    _fields(extent,{'count','retained','JSONL_bytes','SHA256','evaluation_complete'})
    events=result['events']
    _need(type(events) is list,'events list')
    observed=[row['event'] for row in observations]
    _need(_same(events[:len(observed)],observed,m),'all actual observer bodies joined')
    tail=len(events)-len(observed)
    _need(tail>=0 and (tail==0 if result['status']!='UNKNOWN' else tail<=1),
          'only budget-refused last event can lack an observer image')
    for number,event in enumerate(events):
        _fields(event,{'seq','kind','data'})
        _need(type(event['seq']) is int and event['seq']==number
              and type(event['kind']) is str and type(event['data']) is dict,
              'full retained event wire')
    _need(all(type(v) is int and v>=0 for v in
              [extent['count'],extent['retained'],extent['JSONL_bytes']]),'event extent ints')
    stream=b''.join(_wire(event,m) for event in events)
    _need(extent['count']==extent['retained']==len(events)
          and extent['JSONL_bytes']==len(stream)
          and extent['SHA256']==hashlib.sha256(stream).hexdigest()
          and type(extent['evaluation_complete']) is bool
          and extent['evaluation_complete']==(result['status']!='UNKNOWN'),'full event extent')
    stat=result['stats']
    integer_keys={'operations','nodes','definitions','families','virtual_members','dependency_links',
                  'row_refreshes','member_probes','placements','forced_placements','branch_decisions',
                  'backtracks','scoped_exclusions','trail_writes','trail_undos','max_trail',
                  'cleanup_undos','observations','events'}
    _fields(stat,integer_keys.union({'cleanup_seconds','elapsed_seconds'}))
    _need(all(type(stat[k]) is int and stat[k]>=0 for k in integer_keys),'stats integers')
    _need(all(type(stat[k]) in (int,float) and math.isfinite(stat[k]) and stat[k]>=0
              for k in ('cleanup_seconds','elapsed_seconds')),'stats clocks')
    _need(stat['events']==len(events) and len(observed)<=stat['observations']<=len(events),
          'actual observer/event census')
    if result['status']!='UNKNOWN':
        _need(stat['observations']==len(observed),'normal complete observations')
    if prepared:
        _need(stat['definitions']==len(graph['compressed']['definitions'])
              and stat['families']==len(graph['families'])
              and stat['virtual_members']==len(graph['candidates'])
              and stat['dependency_links']==sum(len(v) for v in graph['deps']),
              'complete graph cardinalities, one dependency relation')
    records=result['rollback_records']
    _need(type(records) is list,'rollback records')
    undone=0
    final=None
    for record in records:
        m.tick()
        reason=record['reason']
        extra='expected_parent_core_sha256' if reason=='FAILED_CHILD' else 'full_restored_sha256'
        _fields(record,{'reason','target','undone','before_core_sha256','after_core_sha256',extra})
        _need(reason in ('FAILED_CHILD','FINAL_MANDATORY_CLEANUP')
              and type(record['target']) is type(record['undone']) is int
              and record['target']>=0 and record['undone']>=0,'rollback types')
        undone+=record['undone']
        if reason=='FAILED_CHILD':
            _need(record['after_core_sha256']==record['expected_parent_core_sha256']
                  and any(e['kind']=='ROLLBACK' and _same(e['data'],record,m) for e in events),
                  'failed child retained record association')
        else:
            _need(final is None and record is records[-1] and record['target']==0,
                  'one last whole cleanup')
            final=record
    _need(undone==stat['trail_undos'] and stat['trail_writes']==stat['trail_undos'],
          'actual all-write rollback conservation')
    if prepared:
        _need(final is not None and final['undone']==stat['cleanup_undos']
              and final['full_restored_sha256']==hashes['restored']
              and final['after_core_sha256']==_sha(_core(result['restored_state']),m),
              'final cleanup scope')
    return {'status':'VERIFIED','observations':len(observed),'emitted_events':len(events),
            'unobserved_tail_events':tail,'undo_entries':undone,'scope':SCOPE}


def _run(indexed, compiled, slots, graph, m, solutions=None, limits=None, mutate=False):
    observations = []
    def observe(event, state):
        m.tick()
        receipt = _state(graph, state, m, solutions)
        _event(graph, event, state, receipt, observations[-1] if observations else None, m)
        _need(event['seq'] == len(observations), 'complete observation sequence')
        observations.append({'event':_clone(event,m),'state':_clone(state,m),'audit':receipt})
        if mutate:
            event.clear()
            state['selected'].append('FOREIGN_MUTATION')
        return False
    result = indexed.solve(compiled, slots, dict(ENGINE_LIMITS) if limits is None else limits,
                           observe=observe)
    receipt = _result(graph, result, observations, m, solutions, indexed.VERSION)
    return result, observations, receipt


def _cases():
    p=['pred','P',[]]; q=['pred','Q',[]]
    return [
        ('GIVEN',{'p':p},p,(1,2,3)),
        ('MP',{'p':p,'pq':['imp',p,q]},q,(1,2,3)),
        ('GEN',{'p':p},['all','x',p],(1,2,3)),
        ('LATE-DEAD',{'p':p},q,(2,)),
        ('UNSEEDED-CYCLE',{'pq':['imp',p,q],'qp':['imp',q,p]},p,(1,2,3)),
        ('ZERO-WITNESS-ALIASES',{'a':p,'b':p},p,(1,2))]


def _projection(compiled):
    return {k:compiled[k] for k in ('schema','version','theory','goal','goal_id',
             'profile','logical_basis','zero_instances','mp_index','gen_index')}


def _optimization(result,capacity):
    _fields(result,{'schema','version','status','reason','compiled','costs','optimization'})
    o=result['optimization']
    _fields(o,{'implementation_version','cache_capacity','cache_entries','cache_peak_entries',
               'cache_evictions','interned_nodes','peak_interned_nodes',
               'transient_nodes_discarded','equality_probes','bridge_tests','bridge_rejections'})
    _need(o['implementation_version']=='W-SCALABLE-FINITE-HILBERT8-v1','implementation identity')
    _need(all(type(v) is int and v>=0 for k,v in o.items() if k!='implementation_version'),
          'optimization counters')
    _need(o['cache_capacity']==capacity and o['cache_entries']<=capacity
          and o['cache_peak_entries']<=capacity,'bounded LRU state')
    if capacity==0:
        _need(o['cache_entries']==o['cache_peak_entries']==o['cache_evictions']==0,
              'cache0 means no retained auxiliary memo')
    return o


def _reference_result(graph,result,m,solutions=None):
    _need(result['schema']=='V-indexed-unit-point-result-v1'
          and _same(result['model'],graph['model'],m)
          and _same(result['families'],graph['families'],m)
          and result['model_sha256']==_sha(graph['model'],m),'V complete reference model')
    _need(result['status'] in ('SAT','UNSAT'),'V tiny comparison completed')
    if solutions is not None:
        _need(result['status']==('SAT' if solutions else 'UNSAT'),'V exhaustive tiny outcome')
    _need(_same(result['entry_state'],result['restored_state'],m)
          and result['state_hashes']=={'entry':_sha(result['entry_state'],m),
                                      'restored':_sha(result['restored_state'],m)},
          'V actual full return restoration')
    _need(sum(r['undone'] for r in result['rollback_records'])
          ==result['stats']['trail_writes']==result['stats']['trail_undos'],
          'V complete trail conservation')
    events=result['events'];stream=b''.join(_wire(e,m) for e in events)
    extent=result['event_extent']
    _need(extent['count']==extent['retained']==len(events)
          and extent['JSONL_bytes']==len(stream)
          and extent['SHA256']==hashlib.sha256(stream).hexdigest()
          and result['stats']['observations']==0,'V retained full event bytes, no observer claim')
    if result['status']=='SAT':
        if solutions is not None:
            _need(tuple(result['selected']) in solutions,'V complete selected tiling')
        _need(_same(result['certificate'],_certificate(graph,result['selected'],True,m),m),
              'V actual t/m certificate')
    else:
        _need(result['selected'] is None and result['certificate'] is None,'V no false proof')
    return {'status':'VERIFIED','scope':'One V result/certificate and full returned restoration/events only; no V intermediate observer images.'}


def _build_pair(basis,reference,problem,slots,m,counts):
    built=basis.build_basis(problem['theory'],problem['goal'],problem['profile'],dict(BUILD_LIMITS))
    counts['basis_build']+=1
    _optimization(built,BUILD_LIMITS['max_cache_entries'])
    old=reference.build_basis(problem['theory'],problem['goal'],problem['profile'],dict(BUILD_LIMITS))
    counts['reference_build']+=1
    _need(built['status']==old['status']=='COMPLETE','both complete tiny bases')
    _need(_same(_projection(built['compiled']),_projection(old['compiled']),m),
          'entire unchanged V logical projection')
    materialized=basis.materialize(built['compiled'],slots,dict(ROW_LIMITS))
    counts['basis_materialize']+=1
    previous=reference.materialize(old['compiled'],slots,dict(ROW_LIMITS))
    counts['reference_materialize']+=1
    _need(materialized['status']==previous['status']=='COMPLETE','both complete materializations')
    graph=_graph(built['compiled'],slots,m)
    for answer in (materialized,previous):
        bundle=answer['bundle']
        _need(_same(bundle['model']['required'],graph['raw_model']['required'],m)
              and len(bundle['model']['candidates'])==len(graph['candidates'])
              and _same({c['id']:c for c in bundle['model']['candidates']},
                        {c['id']:c for c in graph['raw_model']['candidates']},m)
              and _same(bundle['steps'],graph['steps'],m),'complete explicit members/steps')
    return built,old,materialized,previous,graph


def _compare_case(basis,reference,indexed,vengine,explicit,checker,problem,slots,
                  name,m,counts,exhaustive=True):
    input_sha=_sha(problem,m)
    built,old,materialized,previous,graph=_build_pair(basis,reference,problem,slots,m,counts)
    compiled=built['compiled'];core=checker.verify_compiled(problem,compiled)
    counts['core_compiled']+=1
    _need(core['status']=='VERIFIED','whole supplied catalogue verified')
    if exhaustive:
        product,solutions=_solutions(graph,m)
        wlimits=dict(ENGINE_LIMITS)
    else:
        product=solutions=None
        wlimits=dict(ENGINE_LIMITS,wall_seconds=10,max_operations=100000000)
    point,observations,audit=_run(indexed,compiled,slots,graph,m,solutions,limits=wlimits)
    counts['indexed_solve']+=1;counts['observations']+=len(observations)
    oldlimits=dict(wall_seconds=wlimits['wall_seconds'],max_nodes=50000,
                   max_operations=wlimits['max_operations'],max_families=10000,
                   max_virtual_members=100000,max_events=100000)
    vpoint=vengine.solve(old['compiled'],slots,oldlimits)
    counts['vengine_solve']+=1
    vaudit=_reference_result(graph,vpoint,m,solutions)
    simple=explicit.solve(graph['raw_model'],{'wall_seconds':wlimits['wall_seconds'],
                                             'max_nodes':50000,'max_events':100000})
    counts['explicit_solve']+=1
    _need(point['status']==vpoint['status']==simple['status'],'three complete point outcomes')
    _need(point['status'] in ('SAT','UNSAT'),'ordinary controls complete')
    _need(_same(simple['entry_state'],simple['restored_state'],m),'S actual restoration')
    if point['status']=='SAT':
        if solutions is not None:
            _need(tuple(sorted(simple['selected'])) in solutions,'S whole solution membership')
        _need(_same(simple['certificate'],_certificate(graph,simple['selected'],False,m),m),
              'S actual complete certificate')
        selection=checker.verify_selection(problem,compiled,slots,point['selected'])
        reference_selection=checker.verify_selection(problem,old['compiled'],slots,vpoint['selected'])
        explicit_selection=checker.verify_selection(problem,compiled,slots,simple['selected'])
        counts['core_selection']+=3
        _need(selection['status']==reference_selection['status']==explicit_selection['status']=='VERIFIED',
              'all three actual selected native proofs')
    else:
        selection=reference_selection=explicit_selection=None
        _need(simple['selected'] is None and simple['certificate'] is None,'S no false certificate')
    backward=checker.backward_dag(problem,compiled,slots);counts['core_backward']+=1
    _need(backward['status']==('DERIVABLE' if point['status']=='SAT' else 'NOT_DERIVABLE'),
          'same-catalogue complete control matches finite tiny outcome')
    _need(_sha(problem,m)==input_sha,'producer input purity')
    if name=='LATE-DEAD':
        _need(observations[0]['state']['degrees']==[1,0]
              and [r['event']['kind'] for r in observations]==['ENTRY','DEAD'],'global dead before singleton')
    if name=='GIVEN' and slots==2:
        _need(all(v is None for v in observations[0]['state']['values'])
              and any(0 in r['state']['values'] for r in observations),'ID0 versus missing')
    if name=='ZERO-WITNESS-ALIASES' and slots==1:
        _need(observations[0]['state']['degrees']==[2],'distinct witness identity count')
    if name=='UNSEEDED-CYCLE' and slots==3:
        _need(any(r['event']['kind']=='ROLLBACK' for r in observations)
              and any(r['event']['kind']=='EXCLUDED' for r in observations),'real failed child scope')
    if not exhaustive:
        _need(len(graph['candidates'])==2013 and point['status']=='SAT','complete multidigit regression')
        last='r11:mp:'
        candidates=[r['event']['data']['candidate'] for r in observations
                    if r['event']['kind']=='PLACED'
                    and r['event']['data']['candidate'].startswith(last)]
        refs=[int(cid.split(':')[3]) for cid in candidates]
        _need(0 in refs and 10 in refs and refs.index(10)>refs.index(0)
              and 1 not in refs[:refs.index(10)],'actual delimiter-sensitive10 before1 after0 failures')
    return {'case':name,'slots':slots,'problem':problem,'basis_return':built,
            'reference_basis':old,'materialized':materialized,'reference_materialized':previous,
            'product':product,'full_solution_ID_sets':None if solutions is None else[list(s)for s in solutions],
            'product_scope':'COMPLETE_CARTESIAN' if exhaustive else 'NOT_ENUMERATED_MULTIDIGIT',
            'indexed':point,'observations':observations,'graph_audit':audit,
            'reference':vpoint,'reference_audit':vaudit,'explicit':simple,
            'core_compiled':core,'core_selection':selection,'reference_selection':reference_selection,
            'explicit_selection':explicit_selection,'backward':backward},graph


def _compiler_only(basis,reference,checker,emit,m,counts):
    a=['fun','a',[]];b=['fun','b',[]];x=['var','x']
    P=lambda t:['pred','P',[t]]
    # Closed supplied axioms; the goal may be open. No proof sequence is input.
    eqtheory={'functions':{'a':0,'b':0},'predicates':{'P':1,'T':1},'axioms':{
        'E':['eq',a,b],'Pa':P(a),'Ta':['pred','T',[a]],
        'UP':['all','x',P(x)],'UXEq':['all','x',['eq',x,a]]}}
    eqgoal=['and',['imp',P(b),['all','y',P(a)]],
                   ['imp',['all','fresh0',P(x)],['all','x',P(a)]]]
    prop=['pred','P',[]];qx=['pred','Q',[x]]
    dtheory={'functions':{},'predicates':{'P':0,'Q':1},'axioms':{
        'U':['all','x',['imp',prop,qx]],'P':prop}}
    dgoal=['all','x',qx]
    for label,theory,goal in [('EQ-SUB',eqtheory,eqgoal),('DISTRIBUTION-BRIDGES',dtheory,dgoal)]:
        profile={'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}
        old=reference.build_basis(theory,goal,profile,dict(BUILD_LIMITS));counts['reference_build']+=1
        _need(old['status']=='COMPLETE','V compiler-only reference complete')
        oldmat=reference.materialize(old['compiled'],3,dict(ROW_LIMITS));counts['reference_materialize']+=1
        _need(oldmat['status']=='COMPLETE','V compiler-only row projection')
        variants=[]
        for capacity in (0,1,100000):
            limits=dict(BUILD_LIMITS,max_cache_entries=capacity)
            result=basis.build_basis(theory,goal,profile,limits);counts['basis_build']+=1
            opt=_optimization(result,capacity)
            _need(result['status']=='COMPLETE' and _same(_projection(result['compiled']),_projection(old['compiled']),m),
                  'LRU capacity cannot remove any logical witness')
            if capacity==1:_need(opt['cache_evictions']>0,'actual LRU eviction path exercised')
            core=checker.verify_compiled({'theory':theory,'goal':goal,'profile':profile},result['compiled'])
            counts['core_compiled']+=1;_need(core['status']=='VERIFIED','compiler-only complete record')
            materialized=basis.materialize(result['compiled'],3,dict(ROW_LIMITS));counts['basis_materialize']+=1
            _need(materialized['status']=='COMPLETE'
                  and _same(materialized['bundle']['model'],oldmat['bundle']['model'],m)
                  and _same(materialized['bundle']['steps'],oldmat['bundle']['steps'],m),
                  'all earlier-reference explicit projection')
            variants.append({'capacity':capacity,'return':result,'core':core,'materialized':materialized})
        if label=='EQ-SUB':
            _need(all(v['return']['optimization']['equality_probes']>0
                      and v['return']['optimization']['transient_nodes_discarded']>0 for v in variants),
                  'accepted/rejected scratch probes executed')
            witnesses=[z['line'] for z in old['compiled']['zero_instances'] if z['rule']=='eq_subst']
            _need(any(z['formula']==['imp',['eq',a,b],['imp',P(a),P(b)]] for z in witnesses),
                  'accepted simple equality schema included')
            _need(any(z['formula']==['imp',['eq',x,a],
                         ['imp',['all','fresh0',P(x)],['all','x',P(a)]]] for z in witnesses),
                  'accepted capture-avoiding fresh0 schema included')
            _need(not any(z['left']==a and z['right']==b
                          and z['template'][0]=='pred' and z['template'][1]=='T' for z in witnesses),
                  'missing T(b) rejects its equality context')
            _need(any(t[0]=='all' for t in old['compiled']['logical_basis']['templates']),
                  'quantifier-hygiene template domain present')
        else:
            _need(any(z['rule']=='distribute' for z in old['compiled']['zero_instances']),
                  'native distribution witness included')
        extra=[]
        if label=='DISTRIBUTION-BRIDGES':
            q=['pred','Q',[]]
            theory2={'functions':{},'predicates':{'P':0,'Q':0},'axioms':{'P':prop,'Q':q}}
            for arity in (1,2):
                profile2={'ui_rounds':0,'bridge_arity':arity,'max_tautology_atoms':4}
                v=reference.build_basis(theory2,prop,profile2,dict(BUILD_LIMITS));counts['reference_build']+=1
                result=basis.build_basis(theory2,prop,profile2,dict(BUILD_LIMITS));counts['basis_build']+=1
                opt=_optimization(result,100000)
                _need(v['status']==result['status']=='COMPLETE'
                      and _same(_projection(v['compiled']),_projection(result['compiled']),m),
                      'complete one/two antecedent bridge projection')
                _need(opt['bridge_tests']>0 and opt['bridge_rejections']>0,'accepted/false bridge tests')
                taut=[z['line']['formula'] for z in result['compiled']['zero_instances'] if z['rule']=='tautology']
                _need(['imp',prop,prop] in taut and ['imp',q,prop] not in taut,'one antecedent bridge truth')
                if arity==2:
                    _need(['imp',prop,['imp',q,prop]] in taut
                          and ['imp',q,['imp',q,prop]] not in taut,'two antecedent bridge truth')
                core=checker.verify_compiled({'theory':theory2,'goal':prop,'profile':profile2},result['compiled'])
                counts['core_compiled']+=1;_need(core['status']=='VERIFIED','bridge full record')
                vm=reference.materialize(v['compiled'],2,dict(ROW_LIMITS));counts['reference_materialize']+=1
                wm=basis.materialize(result['compiled'],2,dict(ROW_LIMITS));counts['basis_materialize']+=1
                _need(vm['status']==wm['status']=='COMPLETE'
                      and _same(vm['bundle']['model'],wm['bundle']['model'],m)
                      and _same(vm['bundle']['steps'],wm['bundle']['steps'],m),'bridge row projection')
                extra.append({'arity':arity,'reference':v,'return':result,'core':core,
                              'reference_materialized':vm,'materialized':wm})
        emit('COMPILER-ONLY-'+label,{'problem':{'theory':theory,'goal':goal,'profile':profile},
             'reference':old,'reference_materialized':oldmat,'variants':variants,'bridge_controls':extra,
             'scope':'Complete compiler projection only; no searched proof and no main theorem answer.'})
        counts['emitted']+=1


def qualify(basis,reference,indexed,vengine,explicit,checker,emit):
    m=_Meter(wall=60,work=1000000000)
    _need(callable(emit),'emit callable')
    profile={'ui_rounds':0,'bridge_arity':0,'max_tautology_atoms':4}
    counts={'basis_build':0,'basis_materialize':0,'reference_build':0,'reference_materialize':0,
            'indexed_solve':0,'vengine_solve':0,'explicit_solve':0,'core_compiled':0,
            'core_selection':0,'core_backward':0,'emitted':0,'observations':0}
    retained={}
    for name,axioms,goal,rows in _cases():
        predicates={k:0 for k in ('P','Q') if k=='P' or name in ('MP','UNSEEDED-CYCLE','LATE-DEAD')}
        problem={'theory':{'functions':{},'predicates':predicates,'axioms':axioms},
                 'goal':goal,'profile':dict(profile)}
        for slots in rows:
            record,graph=_compare_case(basis,reference,indexed,vengine,explicit,checker,
                                       problem,slots,name,m,counts)
            emit(name+'-'+str(slots),record);counts['emitted']+=1
            retained[(name,slots)]=(record,graph)
    given,graph=retained[('GIVEN',2)];compiled=given['basis_return']['compiled']
    for field in ('max_nodes','max_operations','max_definitions','max_virtual_members'):
        limits=dict(ENGINE_LIMITS);limits[field]=0
        stopped,seen,audit=_run(indexed,compiled,2,graph,m,limits=limits)
        counts['indexed_solve']+=1;counts['observations']+=len(seen)
        _need(stopped['status']=='UNKNOWN','owned refusal stays UNKNOWN')
        emit('REFUSAL-'+field.replace('_','-'),{'limit':limits,'result':stopped,'observations':seen,'audit':audit})
        counts['emitted']+=1
    solutions=[tuple(s) for s in given['full_solution_ID_sets']]
    mutated,seen,audit=_run(indexed,compiled,2,graph,m,solutions,mutate=True)
    counts['indexed_solve']+=1;counts['observations']+=len(seen)
    emit('CALLBACK-FALSE-MUTATION',{'result':mutated,'observations':seen,'audit':audit});counts['emitted']+=1
    class ForeignObserverError(Exception):
        pass
    before=[]
    def throwing(event,state):
        audit=_state(graph,state,m,solutions)
        _event(graph,event,state,audit,before[-1] if before else None,m)
        before.append({'event':_clone(event,m),'state':_clone(state,m),'audit':audit})
        if event['kind']=='PLACED':raise ForeignObserverError('after actual placement')
        return False
    propagated=False
    try:
        counts['indexed_solve']+=1
        indexed.solve(compiled,2,dict(ENGINE_LIMITS),observe=throwing)
    except ForeignObserverError:propagated=True
    _need(propagated and len(before)>=2 and before[-1]['event']['kind']=='PLACED','foreign propagation')
    counts['observations']+=len(before)
    emit('CALLBACK-FOREIGN',{'propagated':True,'before_throw':before,'post_exception_state':None,
                           'cleanup_scope':'Full Source trail coverage only; no returned postexception image.'})
    counts['emitted']+=1
    p=['pred','P',[]];q=['pred','Q',[]];r=['pred','R',[]];g=['pred','G',[]]
    problem={'theory':{'functions':{},'predicates':{'P':0,'Q':0,'R':0,'G':0},'axioms':{
        'p':p,'pq':['imp',p,q],'pr':['imp',p,r],'qrg':['imp',q,['imp',r,g]]}},
        'goal':g,'profile':dict(profile)}
    built=basis.build_basis(problem['theory'],g,profile,dict(BUILD_LIMITS));counts['basis_build']+=1
    _optimization(built,100000);_need(built['status']=='COMPLETE','shared catalogue')
    check=checker.verify_compiled(problem,built['compiled']);counts['core_compiled']+=1
    _need(check['status']=='VERIFIED','shared input record')
    shared=[]
    for slots in (7,8):
        result=checker.backward_dag(problem,built['compiled'],slots);counts['core_backward']+=1
        _need(result['status']==('NOT_DERIVABLE' if slots==7 else'DERIVABLE'),'shared exact bound')
        shared.append({'slots':slots,'result':result})
    emit('SHARED-DAG',{'problem':problem,'basis_return':built,'compiled_check':check,'controls':shared})
    counts['emitted']+=1
    base,graph=retained[('MP',3)];problem=base['problem'];compiled=base['basis_return']['compiled'];negative=[]
    for kind in ('missing-MP','zero-bool-ID','wrong-color'):
        bad=_clone(compiled,m)
        if kind=='missing-MP':bad['mp_index']=bad['mp_index'][1:]
        elif kind=='zero-bool-ID':bad['zero_instances'][0]['formula_id']=False
        else:bad['logical_basis']['colors'][0]='FORGED'
        result=checker.verify_compiled(problem,bad);counts['core_compiled']+=1
        _need(result['status']=='REJECTED','isolated catalogue negative')
        negative.append({'mutation':kind,'input':bad,'receipt':result})
    forged=_clone(base['observations'][0]['state'],m);forged['degrees'][0]+=1
    result=audit_state(compiled,3,forged);_need(result['status']=='REJECTED','degree forgery')
    negative.append({'mutation':'one-degree','input':forged,'receipt':result})
    bad_coefficient=_clone(base['observations'][0]['state'],m)
    bad_coefficient['aggregates'][0][4][2]+=1
    result=audit_state(compiled,3,bad_coefficient)
    _need(result['status']=='REJECTED','one aggregate coefficient forgery')
    negative.append({'mutation':'one-MP-S-coefficient','input':bad_coefficient,'receipt':result})
    emit('DATA-NEGATIVES',{'controls':negative});counts['emitted']+=1
    axioms={'r':r,'rp':['imp',r,p],'pq':['imp',p,q]}
    m.tick(110)
    for i in range(110):axioms['r-alias-%03d'%i]=r
    problem={'theory':{'functions':{},'predicates':{'P':0,'Q':0,'R':0},'axioms':axioms},
             'goal':q,'profile':dict(profile)}
    record,graph=_compare_case(basis,reference,indexed,vengine,explicit,checker,
                               problem,12,'MULTIDIGIT',m,counts,exhaustive=False)
    emit('MULTIDIGIT',record);counts['emitted']+=1
    _compiler_only(basis,reference,checker,emit,m,counts)
    expected={'basis_build':25,'basis_materialize':24,'reference_build':20,
              'reference_materialize':20,'indexed_solve':22,'vengine_solve':16,
              'explicit_solve':16,'core_compiled':28,'core_selection':27,
              'core_backward':18,'emitted':26}
    _need(all(counts[k]==v for k,v in expected.items()),'closed complete call/record census')
    return {'status':'PASS','version':VERSION,'counts':counts,
            'seconds':time.perf_counter()-m.start,'work':m.work,'scope':SCOPE}
