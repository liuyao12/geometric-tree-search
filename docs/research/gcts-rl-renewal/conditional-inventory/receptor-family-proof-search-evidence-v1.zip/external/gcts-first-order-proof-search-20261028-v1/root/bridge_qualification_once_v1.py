"""Closed U worker and owned observer. Inert until a fresh exact once grant.

Only pinned retained Source bytes execute. All outcomes and complete proof
checks are retained. The supervisor owns one child, its streams and wait4;
timeouts/refusals never become mathematical negatives. No network or Git.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import types

ROOT = Path('/private/tmp/gcts-first-order-proof-search-20261028-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
ROLES = {'runner', 'bridge'}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def raw_ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(ref, maximum=1048576):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'raw ref')
    path = Path(ref['path'])
    require(path.is_absolute() and not path.is_symlink(), 'regular absolute path')
    require(type(ref['bytes']) is int and 0 <= ref['bytes'] <= maximum, 'raw length bound')
    with path.open('rb') as f:
        data = f.read(ref['bytes'] + 1)
    require(raw_ref(path, data) == ref, 'whole raw association')
    return data


def put(path, raw):
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    require(path.read_bytes() == raw, 'whole written bytes')
    return raw_ref(path, raw)


def check_authority(raw, plan_path, plan_raw, plan):
    authority = json.loads(raw)
    expected = {'schema': 'U-bridge-qualification-once-authority-v1', 'uses': 1,
                'authorized': True, 'plan': raw_ref(plan_path, plan_raw),
                'runner': plan['sources']['runner'], 'python': plan['python']}
    require(type(authority) is dict and len(authority) == 6
            and type(authority.get('uses')) is int
            and type(authority.get('authorized')) is bool
            and authority == expected, 'exact typed Root once')
    return expected


def load_plan(path):
    raw = Path(path).read_bytes()
    plan = json.loads(raw)
    require(set(plan) == {'schema', 'sources', 'metadata', 'python', 'bootstrap',
                          'actual_dir', 'limits'}, 'exact plan')
    require(plan['schema'] == 'U-bridge-qualification-once-plan-v1', 'plan schema')
    require(set(plan['sources']) == ROLES, 'closed Source roles')
    require(Path(plan['actual_dir']) == ROOT / 'actual' / 'bridge-001', 'owned output')
    require(plan['sources']['runner']['path'] == __file__, 'runner location')
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'isolated D90')
    require(plan['limits'] == {'worker_seconds': 210, 'observer_seconds': 240,
            'rss_bytes': 1073741824, 'file_bytes': 33554432,
            'total_bytes': 536870912, 'max_files': 384,
            'stream_bytes': 1048576}, 'fixed process and artifact profile')
    retained = {k: read_ref(v) for k, v in plan['sources'].items()}
    metadata = {k: read_ref(v) for k, v in plan['metadata'].items()}
    read_ref(plan['python'], 33554432)
    read_ref(plan['bootstrap'])
    return plan, raw, retained, metadata


def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    marker_path = directory / 'CONSUMED.json'
    marker_raw = marker_path.read_bytes()
    marker = json.loads(marker_raw)
    authority_raw = read_ref(marker['authority'])
    check_authority(authority_raw, plan_path, plan_raw, plan)
    consume_raw = read_ref(marker['consumed'])
    require(json.loads(consume_raw) == {'authority': marker['authority'],
            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}, 'worker once joins')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 210, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        require(type(name) is str and name and name.isascii()
                and all(c.isalnum() or c in '-.' for c in name), 'artifact name')
        require(len(artifacts) < 376, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 33554432, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(len(stored) <= 33554432 and total_bytes <= 503316480,
                'whole artifact stored cap')
        ref = put(directory / (name + ('.json.gz' if compressed else '.json')), stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('U_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 512, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    controls = json.loads(metadata['bridge_controls'])

    # These literal structural controls are frozen before this worker exists.
    # No lowerer, machine simulator or Wang compiler is called in this milestone.
    bridge_records = []
    base = controls['normal'][0]['input']
    clone = lambda x: json.loads(json.dumps(x))
    def bridge_record(identity, inp, lim, expected_status, expected_reason=None,
                      expected_machine=None, callback=None):
        before = clone(inp)
        answer = call('bridge', 'expand_physical', inp, lim, budget=callback)
        require(answer['status'] == expected_status and answer['reason'] == expected_reason,
                'bridge exact prospective outcome ' + identity)
        if expected_status == 'COMPLETE':
            require(answer['machine'] == expected_machine, 'entire expected strict machine')
            require(answer['counts']['emitted_transitions'] == len(expected_machine['transitions'])
                    == answer['counts']['predicted_transitions'], 'whole transition count')
            require(answer['machine_sha256'] == hashlib.sha256(raw_json(expected_machine)).hexdigest(),
                    'whole machine hash')
            require(answer['source_sha256'] == hashlib.sha256(raw_json(before)).hexdigest(),
                    'whole detached input hash')
            require([r['index'] for r in answer['state_map']] == list(range(len(before['rows'])))
                    and [r['id'] for r in answer['state_map']] == expected_machine['states']
                    and [r['name'] for r in answer['state_map']] == before['names'], 'state mapping')
            require(answer['machine']['alphabet'] is not inp['alphabet']
                    and answer['machine']['states'] is not inp['names'], 'fresh output lists')
        else:
            require(answer['machine'] is None and answer['machine_sha256'] is None
                    and answer['state_map'] is None, 'no partial refused model')
        record = {'id': identity, 'input_before': before, 'limits': lim,
                  'input_after': clone(inp), 'answer': answer}
        bridge_records.append(record)
        return answer

    for row in controls['normal']:
        bridge_record(row['id'], clone(row['input']), clone(controls['limits']),
                      'COMPLETE', expected_machine=row['expected_machine'])
    for identity, recipe, reason in controls['malformed']:
        inp, lim = clone(base), clone(controls['limits'])
        if identity == 'extra-field': inp['extra'] = 0
        elif identity == 'float-state': inp['start'] = 3.0
        elif identity == 'bool-move': inp['rows'][3][1]['x'][2] = True
        elif identity == 'default-target': inp['rows'][3][0][0] = 0
        elif identity == 'unknown-read': inp['rows'][3][1]['z'] = inp['rows'][3][1].pop('x')
        elif identity == 'unknown-write': inp['rows'][3][1]['x'][1] = 'z'
        elif identity == 'accept-outgoing': inp['rows'][0] = [None, {}]
        elif identity == 'receipt-count': inp['construction_receipt']['transition_choices'] = 3
        elif identity == 'duplicate-symbol': inp['alphabet'] = ['B', 'B']
        elif identity == 'bool-limit': lim['max_states'] = True
        else: raise RuntimeError('undeclared bridge malformed recipe')
        bridge_record(identity, inp, lim, 'REJECTED', reason)
    for key, value, reason in controls['resource']:
        lim = clone(controls['limits']); lim[key] = value
        bridge_record(key, clone(base), lim, 'UNKNOWN_BUDGET', reason)
    class Sentinel(Exception):
        pass
    def foreign():
        raise Sentinel('unique owned bridge callback')
    try:
        call('bridge', 'expand_physical', clone(base), clone(controls['limits']), budget=foreign)
    except Sentinel as error:
        bridge_records.append({'id': 'foreign-callback', 'status': 'EXPECTED_SENTINEL',
                               'message': str(error)})
    else:
        raise RuntimeError('bridge swallowed foreign callback')
    detached = clone(base)
    def mutation():
        detached['rows'].clear()
    changed = bridge_record('mutation-callback', detached, clone(controls['limits']),
                           'COMPLETE', expected_machine=controls['normal'][0]['expected_machine'],
                           callback=mutation)
    require(not detached['rows'] and changed['counts']['budget_callbacks'] > 0,
            'detached mutation and actual callbacks')
    false_answer = bridge_record('false-callback', clone(base), clone(controls['limits']),
                                'COMPLETE', expected_machine=controls['normal'][0]['expected_machine'],
                                callback=lambda: False)
    require(false_answer['counts']['budget_callbacks'] > 0, 'false result ignored by contract')
    require(len(bridge_records) == controls['planned_calls'] == 20, 'whole bridge cohort')
    emit('bridge-whole-qualification', {'status': 'PASS', 'records': bridge_records})

    result_ref = emit('worker-result', {'schema': 'U-bridge-qualification-study-v1', 'status': 'COMPLETE', 'records': bridge_records, 'artifacts': list(artifacts), 'outer_public_calls': dict(calls), 'scope': 'Twenty prefrozen tiny structural bridge controls. No full C1 physical table, NTM simulation, Wang construction or FOL proof search.'})
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'post plan guard')
    require(marker_path.read_bytes() == marker_raw, 'post marker guard')
    require(read_ref(marker['authority']) == authority_raw, 'post authority guard')
    require(read_ref(marker['consumed']) == consume_raw, 'post consumed guard')
    budget()
    sys.stdout.buffer.write(raw_json({'status': 'COMPLETE', 'result': result_ref,
        'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
        'elapsed_seconds': time.perf_counter() - started,
        'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
    sys.stdout.buffer.flush()
    return 0


def observer(plan_path, authority_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    authority_raw = Path(authority_path).read_bytes()
    check_authority(authority_raw, plan_path, plan_raw, plan)
    directory = Path(plan['actual_dir'])
    require(not directory.exists() and not directory.is_symlink(), 'fresh output directory')
    consumed = Path(str(authority_path) + '.CONSUMED.json')
    consume_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'})
    put(consumed, consume_raw)
    directory.mkdir(parents=True)
    marker_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                           'consumed': raw_ref(consumed, consume_raw)})
    put(directory / 'CONSUMED.json', marker_raw)
    command = [PYTHON, '-I', '-S', '-B', plan['bootstrap']['path'],
               plan['sources']['runner']['path'], str(len(sources['runner'])),
               plan['sources']['runner']['sha256'], '--mode', 'worker', '--plan', str(plan_path)]
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    observed_bytes = {'stdout': 0, 'stderr': 0}
    eof = {'stdout': False, 'stderr': False}
    child = selector = None
    wait_status = usage = None
    failure = cleanup_deadline = None
    cleanup_errors = []
    sent = 0
    group_gone = False

    def kill_owned():
        if child is not None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'stage': 'killpg', 'type': type(error).__name__,
                                       'errno': error.errno})

    def fault(reason):
        nonlocal failure, cleanup_deadline
        if failure is None:
            failure = reason
            cleanup_deadline = time.perf_counter() + 5
            kill_owned()

    def observe_wait_and_group():
        nonlocal wait_status, usage, group_gone
        if child is None:
            return
        if wait_status is None:
            pid, status, ru = os.wait4(child.pid, os.WNOHANG)
            if pid:
                wait_status, usage = status, ru
                child.returncode = os.waitstatus_to_exitcode(status)
        if wait_status is not None:
            try:
                os.killpg(child.pid, 0)
                group_gone = False
            except ProcessLookupError:
                group_gone = True

    def pump_events():
        nonlocal sent
        for key, _ in selector.select(timeout=0.05):
            if key.data == 'stdin':
                if failure is not None:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    continue
                try:
                    count = os.write(key.fileobj.fileno(), sources['runner'][sent:sent + 65536])
                    sent += count
                    if sent == len(sources['runner']):
                        selector.unregister(key.fileobj); key.fileobj.close()
                except BrokenPipeError:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    fault('INCOMPLETE_STDIN_BROKEN_PIPE')
                continue
            block = os.read(key.fileobj.fileno(), 65536)
            if not block:
                eof[key.data] = True
                selector.unregister(key.fileobj); key.fileobj.close()
            else:
                observed_bytes[key.data] += len(block)
                room = max(0, 1048576 - len(captured[key.data]))
                captured[key.data].extend(block[:room])
                if observed_bytes[key.data] > 1048576:
                    fault('STREAM_CAP_PREFIX_RETAINED')

    try:
        # Every post-spawn setup operation is protected. Retained Source stdin
        # is written nonblocking under the same observer deadline as capture.
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, cwd=ROOT / 'root', start_new_session=True)
        selector = selectors.DefaultSelector()
        for name, stream, mode in [('stdin', child.stdin, selectors.EVENT_WRITE),
                                  ('stdout', child.stdout, selectors.EVENT_READ),
                                  ('stderr', child.stderr, selectors.EVENT_READ)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, mode, name)
        while True:
            if failure is None and time.perf_counter() - started >= 240:
                fault('OBSERVER_WALL_TIMEOUT')
            if cleanup_deadline is not None and time.perf_counter() >= cleanup_deadline:
                break
            pump_events()
            observe_wait_and_group()
            if wait_status is not None and all(eof.values()) and group_gone:
                break
            if wait_status is not None and not group_gone:
                fault('OWNED_DESCENDANT_GROUP_REMAINS')
    except BaseException as error:
        fault('OBSERVER_HOST_' + type(error).__name__)
    finally:
        confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
        if child is not None and not confirmed:
            fault('UNCONFIRMED_OWNED_PROCESS_OR_STREAM')
            # No blocking wait is used, even after SIGKILL. Any unconfirmed
            # ownership is explicit evidence and cannot be admitted COMPLETE.
            while time.perf_counter() < cleanup_deadline:
                try:
                    if selector is not None:
                        pump_events()
                    else:
                        time.sleep(0.01)
                    observe_wait_and_group()
                    if wait_status is not None and all(eof.values()) and group_gone:
                        break
                except BaseException as error:
                    cleanup_errors.append({'stage': 'bounded-cleanup', 'type': type(error).__name__})
                    break
        if selector is not None:
            selector.close()
        if child is not None:
            for stream in (child.stdin, child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
    streams = {k: put(directory / (k + '.bin'), bytes(v)) for k, v in captured.items()}
    terminal = None
    confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
    if (confirmed and child.returncode == 0 and not failure and not captured['stderr']
            and sent == len(sources['runner'])):
        terminal = json.loads(captured['stdout'])
        require(terminal['status'] == 'COMPLETE', 'whole worker terminal')
        read_ref(terminal['result']['stored'], 33554432)
    files, total = [], 0
    for p in sorted(directory.iterdir()):
        require(p.is_file() and not p.is_symlink(), 'closed regular output')
        raw = p.read_bytes(); total += len(raw)
        require(len(raw) <= 33554432 and total <= 536870912, 'whole readback ceilings')
        files.append(raw_ref(p, raw))
    require(len(files) <= 383, 'whole output count')
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'observer post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'observer post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'observer post plan guard')
    require(Path(authority_path).read_bytes() == authority_raw, 'observer post authority guard')
    require(consumed.read_bytes() == consume_raw, 'observer post consumed guard')
    require((directory / 'CONSUMED.json').read_bytes() == marker_raw, 'observer post marker guard')
    outcome = {'schema': 'U-bridge-owned-observer-result-v1',
               'status': 'COMPLETE' if terminal is not None else 'UNADMITTED',
               'child_pid': None if child is None else child.pid, 'command': command,
               'returncode': None if child is None else child.returncode,
               'failure': failure, 'cleanup_errors': cleanup_errors,
               'wait_confirmed': wait_status is not None, 'both_streams_EOF': all(eof.values()),
               'group_gone': group_gone, 'stdin_bytes_sent': sent,
               'observed_stream_bytes': observed_bytes, 'retained_streams_complete':
                   {k: observed_bytes[k] == len(captured[k]) for k in captured},
               'streams': streams, 'worker_terminal': terminal, 'files': files,
               'stored_bytes': total, 'wait4_peak_bytes': None if usage is None else usage.ru_maxrss,
               'whole_observer_seconds': time.perf_counter() - started,
               'scope': 'One fresh child. wait4 lifetime RSS on Darwin; no hard RAM quota. '
                        'Owned nonblocking wait/drain with240s sampled deadline and5s cleanup. '
                        'OS spawn, final readback/serialization tail are not an OS hard whole-lifetime '
                        'quota. Unconfirmed process, streams or group forbid COMPLETE.'}
    receipt = put(directory / 'observer-result.json', raw_json(outcome))
    sys.stdout.buffer.write(raw_json({'status': outcome['status'], 'receipt': receipt}))
    sys.stdout.buffer.flush()
    return 0 if terminal is not None else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('worker', 'observer'), required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority')
    args = parser.parse_args()
    if args.mode == 'worker':
        require(args.authority is None, 'worker has no authority path')
        return worker(args.plan)
    require(args.authority is not None, 'observer needs once authority')
    return observer(args.plan, args.authority)


if __name__ == '__main__':
    raise SystemExit(main())
