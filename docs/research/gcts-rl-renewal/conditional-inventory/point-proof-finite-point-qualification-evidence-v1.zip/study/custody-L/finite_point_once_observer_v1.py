"""Inert one-worker custody Source; invocation requires separate Root authority.

This module imports only the standard library.  Scientific result bytes are
opaque.  A normal receipt is conditional on the final terminal record AND this
process exiting zero.  Files left by any failed/aborted invocation are evidence,
never an admitted scientific envelope.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import stat
import subprocess
import sys
import threading
import time


STUDY = Path(__file__).resolve().parent.parent
ROOT = STUDY / "root"
ACTUAL = STUDY / "actual"
ROLE_PATHS = {
    "observer": STUDY / "custody-L/finite_point_once_observer_v1.py",
    "worker": STUDY / "independent-C/finite_point_qualification_v1.py",
    "engine": STUDY / "implementation-B/finite_point_engine_v1.py",
    "oracle": STUDY / "independent-C/finite_point_independent_v1.py",
}
PYTHON = {
    "path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
    "bytes": 18058560,
    "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840",
}
LIMITS = {
    "worker_seconds": 60,
    "custody_seconds": 90,
    "observer_seconds": 120,
    "memory_bytes": 536870912,
    "result_bytes": 8388608,
    "log_bytes": 1048576,
    "observer_reserve_bytes": 9437184,
}
CHUNK = 65536
METADATA_CAP = 131072
TERMINAL_CAP = 16384


class Refusal(Exception):
    pass


def require(condition, message):
    if not condition:
        raise Refusal(message)


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate administrative JSON key")
            result[key] = value
        return result

    def nonfinite(_value):
        raise Refusal("nonfinite administrative JSON constant")

    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=nonfinite)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)
            + "\n").encode("utf-8")


def rawpin(path, raw):
    return {"path": str(path), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def absolute_path(value):
    require(type(value) is str and value != "", "path must be exact string")
    path = Path(value)
    require(path.is_absolute() and str(path) == value
            and all(p not in (".", "..") for p in path.parts),
            "path must be canonical absolute spelling")
    return path


def nonsymlink_chain(path):
    for item in (path, *path.parents):
        require(not item.is_symlink(), "symlink path component")


def regular(path):
    nonsymlink_chain(path)
    info = path.stat(follow_symlinks=False)
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1,
            "expected single-link regular file")
    return info


def administrative_path(value):
    path = absolute_path(value)
    require(path.is_relative_to(ROOT) and path.suffix == ".json"
            and all(not p.startswith(".") for p in path.relative_to(ROOT).parts),
            "administrative input must be new-study/root nonhidden JSON")
    regular(path)
    return path


def small_read(path, cap):
    before = regular(path)
    require(before.st_size <= cap, "administrative extent exceeds bound")
    with path.open("rb") as handle:
        raw = handle.read(cap + 1)
    after = regular(path)
    require(len(raw) <= cap and len(raw) == before.st_size == after.st_size
            and (before.st_dev, before.st_ino, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_mtime_ns),
            "administrative read changed or incomplete")
    return raw


def pin_shape(value, expected_path=None, maximum=None):
    require(type(value) is dict and set(value) == {"path", "bytes", "sha256"},
            "rawpin exact fields")
    path = absolute_path(value["path"])
    require(type(value["bytes"]) is int and value["bytes"] >= 0,
            "rawpin byte count must be nonnegative exact integer")
    require(type(value["sha256"]) is str
            and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]) is not None,
            "rawpin SHA256 must be lowercase hex")
    if expected_path is not None:
        require(path == expected_path, "Source role path mismatch")
    if maximum is not None:
        require(0 < value["bytes"] <= maximum, "Source extent outside bound")
    return path


def observe_guard(expected):
    result = {"expected": expected, "matched": False, "complete": False}
    try:
        path = absolute_path(expected["path"])
        before = regular(path)
        digest = hashlib.sha256()
        count = 0
        ceiling = expected["bytes"] + 1
        with path.open("rb") as handle:
            while count < ceiling:
                data = handle.read(min(CHUNK, ceiling - count))
                if not data:
                    result["complete"] = True
                    break
                digest.update(data)
                count += len(data)
        after = regular(path)
        result.update({"observed_bytes": count,
                       "stat_bytes": after.st_size,
                       "sha256": digest.hexdigest() if result["complete"] else None})
        stable = ((before.st_dev, before.st_ino, before.st_size,
                   before.st_mtime_ns) == (after.st_dev, after.st_ino,
                                          after.st_size, after.st_mtime_ns))
        result["matched"] = (result["complete"] and stable
                             and count == expected["bytes"] == after.st_size
                             and digest.hexdigest() == expected["sha256"])
    except Exception as error:
        result["error"] = type(error).__name__ + ": " + str(error)[:1024]
    return result


def write_new(path, raw, cap):
    require(len(raw) <= cap, "metadata output exceeds bound")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "wb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    require(small_read(path, cap) == raw, "exclusive output full readback mismatch")
    return rawpin(path, raw)


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def rss_bytes(usage):
    # D90 is the reviewed Darwin interpreter; Darwin ru_maxrss is bytes.
    return int(usage.ru_maxrss)


def usage_record(who, label, started):
    usage = resource.getrusage(who)
    return {"label": label, "elapsed_seconds": time.monotonic() - started,
            "ru_maxrss_raw": usage.ru_maxrss,
            "ru_maxrss_units": "bytes on required Darwin platform",
            "high_water_bytes": rss_bytes(usage),
            "user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime}


def no_prior_children():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    require(all(value == 0 for value in usage),
            "fresh supervisor must have no prior waited-child usage")
    return list(usage)


def kill_group(process, sig):
    if process is None:
        return
    try:
        os.killpg(process.pid, sig)
    except ProcessLookupError:
        pass


def group_exists(process):
    try:
        os.killpg(process.pid, 0)
        return True
    except ProcessLookupError:
        return False


class Capture:
    def __init__(self, directory, limit, issue):
        self.lock = threading.Lock()
        self.limit = limit
        self.total_seen = 0
        self.total_written = 0
        self.issue = issue
        self.rows = {}
        self.handles = {}
        for name in ("stdout", "stderr"):
            path = directory / (name + ".bin")
            self.rows[name] = {"path": str(path), "seen_bytes": 0,
                               "written_bytes": 0, "EOF": False,
                               "sha256_state": hashlib.sha256(), "error": None}

    def open_logs(self):
        for name, row in self.rows.items():
            self.handles[name] = Path(row["path"]).open("xb")

    def drain(self, name, pipe):
        row = self.rows[name]
        handle = self.handles[name]
        try:
            while True:
                data = pipe.read(CHUNK)
                if not data:
                    row["EOF"] = True
                    break
                with self.lock:
                    row["seen_bytes"] += len(data)
                    self.total_seen += len(data)
                    keep = data[:max(0, self.limit - self.total_written)]
                    handle.write(keep)
                    row["sha256_state"].update(keep)
                    row["written_bytes"] += len(keep)
                    self.total_written += len(keep)
                    overflow = self.total_seen > self.limit
                if overflow:
                    self.issue("LOG_LIMIT", "combined full stdout/stderr cap exceeded")
            handle.flush()
            os.fsync(handle.fileno())
        except Exception as error:
            row["error"] = type(error).__name__ + ": " + str(error)[:1024]
            self.issue("LOG_DRAIN", row["error"])
        finally:
            handle.close()
            pipe.close()

    def readback(self):
        results = {}
        for name, row in self.rows.items():
            expected = {"path": row["path"], "bytes": row["written_bytes"],
                        "sha256": row["sha256_state"].hexdigest()}
            checked = observe_guard(expected)
            full = (row["EOF"] and row["error"] is None
                    and row["seen_bytes"] == row["written_bytes"]
                    and checked["matched"])
            results[name] = {"rawpin": expected, "complete_full_log": full,
                             "seen_bytes": row["seen_bytes"],
                             "captured_bytes": row["written_bytes"],
                             "EOF": row["EOF"], "error": row["error"],
                             "readback": checked}
            if not full:
                self.issue("INCOMPLETE_LOG", name)
        return results


def result_readback(path, cap):
    if not path.exists():
        return None
    before = regular(path)
    require(before.st_size <= cap, "result exceeds byte allowance")
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(CHUNK)
            if not chunk:
                break
            count += len(chunk)
            require(count <= cap, "result changed beyond byte allowance")
            digest.update(chunk)
    after = regular(path)
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            and count == after.st_size, "result changed during complete readback")
    return {"path": str(path), "bytes": count, "sha256": digest.hexdigest()}


def runtime_flags():
    require(sys.platform == "darwin" and sys.implementation.name == "cpython"
            and sys.version_info[:3] == (3, 12, 14), "required D90 Darwin CPython")
    require(__debug__ and sys.flags.optimize == 0 and sys.flags.isolated == 1
            and sys.flags.ignore_environment == 1 and sys.flags.no_site == 1
            and sys.flags.no_user_site == 1 and sys.dont_write_bytecode
            and sys.flags.safe_path, "require -I -S -B with assertions enabled")
    require(Path(sys.executable).resolve() == Path(PYTHON["path"]),
            "wrong executing interpreter path")
    return {"version": sys.version, "platform": sys.platform,
            "executable": sys.executable, "isolated": sys.flags.isolated,
            "no_site": sys.flags.no_site, "no_user_site": sys.flags.no_user_site,
            "dont_write_bytecode": sys.dont_write_bytecode,
            "assertions_enabled": __debug__, "optimize": sys.flags.optimize,
            "safe_path": sys.flags.safe_path}


def preflight(plan_arg, authority_arg):
    flags = runtime_flags()
    plan_path = administrative_path(plan_arg)
    authority_path = administrative_path(authority_arg)
    require(plan_path != authority_path, "plan and authority must differ")
    plan_raw = small_read(plan_path, 65536)
    authority_raw = small_read(authority_path, 16384)
    plan, authority = strict_json(plan_raw), strict_json(authority_raw)
    require(type(plan) is dict and set(plan) == {
        "schema", "case_id", "actual_dir", "python", "sources", "limits"},
        "plan exact six fields")
    require(plan["schema"] == "GCTS-finite-point-once-plan-v1"
            and type(plan["case_id"]) is str
            and re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"]),
            "plan schema/case identity")
    directory = absolute_path(plan["actual_dir"])
    require(directory == ACTUAL / plan["case_id"], "fresh direct actual child required")
    nonsymlink_chain(directory)
    require(not directory.exists(), "actual directory already exists")
    pin_shape(plan["python"], Path(PYTHON["path"]))
    require(plan["python"] == PYTHON, "exact D90 rawpin required")
    require(type(plan["sources"]) is dict and set(plan["sources"]) == set(ROLE_PATHS),
            "exact four Source roles")
    for role, path in ROLE_PATHS.items():
        pin_shape(plan["sources"][role], path, 2097152)
    require(type(plan["limits"]) is dict and set(plan["limits"]) == set(LIMITS)
            and all(type(plan["limits"][key]) is int
                    and plan["limits"][key] == value
                    for key, value in LIMITS.items()), "exact seven fixed limits")
    require(type(authority) is dict and set(authority) == {
        "schema", "authorized", "uses", "case_id", "plan", "observer"},
        "authority exact six fields")
    require(authority["schema"] == "Root-finite-point-once-authority-v1"
            and authority["authorized"] is True
            and type(authority["uses"]) is int and authority["uses"] == 1
            and authority["case_id"] == plan["case_id"], "once authority values")
    pin_shape(authority["plan"], plan_path)
    pin_shape(authority["observer"], ROLE_PATHS["observer"], 2097152)
    require(authority["plan"] == rawpin(plan_path, plan_raw)
            and authority["observer"] == plan["sources"]["observer"],
            "authority must bind exact whole plan and observer")
    guards = dict(plan["sources"])
    guards.update({"python": PYTHON, "plan": rawpin(plan_path, plan_raw),
                   "authority": rawpin(authority_path, authority_raw)})
    pre = {name: observe_guard(value) for name, value in guards.items()}
    require(all(row["matched"] for row in pre.values()), "fresh complete pre guards")
    return plan_path, authority_path, plan, guards, pre, flags


def supervise(plan_arg, authority_arg):
    started = time.monotonic()
    stopped = threading.Event()
    shared = {"process": None}
    issues, issue_lock = [], threading.Lock()
    observations = []

    def issue(code, detail):
        with issue_lock:
            if not any(row["code"] == code for row in issues):
                issues.append({"code": code, "detail": str(detail)[:2048],
                               "elapsed_seconds": time.monotonic() - started})

    def sample(label):
        row = usage_record(resource.RUSAGE_SELF, label, started)
        observations.append(row)
        return row

    def watchdog():
        if not stopped.wait(max(0, LIMITS["observer_seconds"] - (time.monotonic() - started))):
            try:
                kill_group(shared["process"], signal.SIGKILL)
            finally:
                # Last-resort fail closed: no normal terminal/exit-zero admission.
                os._exit(124)

    watcher = threading.Thread(target=watchdog, name="observer-deadline", daemon=True)
    watcher.start()
    process, capture, threads = None, None, []
    try:
        sample("observer_start")
        prior_children = no_prior_children()
        plan_path, authority_path, plan, guards, pre, flags = preflight(plan_arg, authority_arg)
        sample("after_preflight")
        require(time.monotonic() - started < LIMITS["custody_seconds"], "preflight custody refusal")
        nonsymlink_chain(ACTUAL)
        if not ACTUAL.exists():
            ACTUAL.mkdir(mode=0o700)
        require(ACTUAL.is_dir(), "actual parent must be directory")
        directory = Path(plan["actual_dir"])
        directory.mkdir(mode=0o700)
        consume = {"schema": "Root-finite-point-once-consumed-v1", "uses": 1,
                   "case_id": plan["case_id"], "plan": guards["plan"],
                   "authority": guards["authority"], "sources": plan["sources"],
                   "python": PYTHON, "scientific_execution_started_at_consume": False}
        consume_raw = encode(consume)
        marker = Path(str(authority_path) + ".CONSUMED.json")
        root_consumed = write_new(marker, consume_raw, METADATA_CAP)
        fsync_directory(marker.parent)
        actual_consumed = write_new(directory / "CONSUMED.json", consume_raw, METADATA_CAP)
        fsync_directory(directory)
        launched = None
        waited = None
        child_reaped = False
        group_gone = False
        result = None
        logs, post = {}, {}
        child_observation = None
        command = [PYTHON["path"], "-I", "-S", "-B",
                   plan["sources"]["worker"]["path"], "--plan", str(plan_path),
                   "--result", str(directory / "worker-result.json")]
        try:
            capture = Capture(directory, LIMITS["log_bytes"], issue)
            capture.open_logs()
            sample("before_child_launch")
            require(observations[-1]["high_water_bytes"] + LIMITS["observer_reserve_bytes"]
                    <= LIMITS["memory_bytes"], "observer cooperative memory refusal")
            require(time.monotonic() - started < LIMITS["custody_seconds"], "prelaunch custody refusal")
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       cwd=str(STUDY), close_fds=True, start_new_session=True,
                                       env={"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"})
            shared["process"] = process
            launched = time.monotonic()
            for name, pipe in (("stdout", process.stdout), ("stderr", process.stderr)):
                thread = threading.Thread(target=capture.drain, args=(name, pipe),
                                          name="drain-" + name, daemon=True)
                thread.start()
                threads.append(thread)
            while process.poll() is None:
                now = time.monotonic()
                if now - launched >= LIMITS["worker_seconds"]:
                    issue("WORKER_TIMEOUT", "hard owned-group work deadline")
                if now - started >= LIMITS["custody_seconds"]:
                    issue("CUSTODY_TIMEOUT", "custody deadline")
                current = rss_bytes(resource.getrusage(resource.RUSAGE_SELF))
                if current + LIMITS["observer_reserve_bytes"] > LIMITS["memory_bytes"]:
                    issue("OBSERVER_MEMORY", "self observed highwater plus reserve exceeds ceiling")
                candidate = directory / "worker-result.json"
                if candidate.exists():
                    info = candidate.stat(follow_symlinks=False)
                    if not stat.S_ISREG(info.st_mode) or info.st_size > LIMITS["result_bytes"]:
                        issue("RESULT_LIMIT", "result type/extent refusal")
                if issues:
                    kill_group(process, signal.SIGTERM)
                    break
                time.sleep(0.02)
        except BaseException as error:
            issue("LAUNCH_OR_MONITOR", type(error).__name__ + ": " + str(error))
        finally:
            if process is not None:
                try:
                    if process.poll() is None:
                        kill_group(process, signal.SIGTERM)
                        try:
                            process.wait(timeout=max(0.01, min(1.0, started + 90 - time.monotonic())))
                        except subprocess.TimeoutExpired:
                            kill_group(process, signal.SIGKILL)
                    # Kill any pipe-holding descendant in the owned group too.
                    if group_exists(process):
                        kill_group(process, signal.SIGKILL)
                    process.wait(timeout=max(0.01, started + 90 - time.monotonic()))
                    waited = time.monotonic()
                    child_reaped = True
                    group_gone = not group_exists(process)
                    if not group_gone:
                        issue("GROUP_REMAINS", "owned process group remains after KILL/wait")
                except BaseException as error:
                    issue("TERMINATION_WAIT", type(error).__name__ + ": " + str(error))
                    kill_group(process, signal.SIGKILL)
                child_observation = usage_record(resource.RUSAGE_CHILDREN, "after_owned_child_wait", started)
            for thread in threads:
                thread.join(timeout=max(0, started + 90 - time.monotonic()))
                if thread.is_alive():
                    issue("DRAIN_JOIN", "drain thread did not finish before custody deadline")
            sample("after_wait_and_drain_joins")
        if launched is not None and waited is not None and waited - launched > LIMITS["worker_seconds"]:
            issue("WORKER_OBSERVED_TIME_LIMIT", "complete launch-to-wait observation exceeds work ceiling")
        if process is None:
            issue("NO_CHILD", "one worker was not launched")
            if capture is not None:
                for handle in capture.handles.values():
                    handle.close()
        elif process.returncode != 0:
            issue("WORKER_EXIT", "worker return code " + str(process.returncode))
        if capture is not None and all(not thread.is_alive() for thread in threads):
            try:
                # Close any handle whose drain never started after a launch failure.
                for handle in capture.handles.values():
                    if not handle.closed:
                        handle.flush()
                        os.fsync(handle.fileno())
                        handle.close()
                if process is not None:
                    for pipe in (process.stdout, process.stderr):
                        if pipe is not None and not pipe.closed:
                            pipe.close()
                logs = capture.readback()
            except Exception as error:
                issue("LOG_READBACK", type(error).__name__ + ": " + str(error))
        try:
            result = result_readback(directory / "worker-result.json", LIMITS["result_bytes"])
            if result is None or result["bytes"] == 0:
                issue("NO_COMPLETE_RESULT", "missing or empty worker result")
        except Exception as error:
            issue("RESULT_READBACK", type(error).__name__ + ": " + str(error))
        allowed = {"CONSUMED.json", "stdout.bin", "stderr.bin", "worker-result.json"}
        if any(path.name not in allowed or not path.is_file() or path.is_symlink()
               for path in directory.iterdir()):
            issue("UNEXPECTED_OUTPUT", "nondeclared/nonregular worker output")
        sample("after_complete_output_readbacks")
        post = {name: observe_guard(value) for name, value in guards.items()}
        if not all(row["matched"] for row in post.values()):
            issue("POST_GUARD", "one or more complete Source/plan/authority guards changed")
        sample("after_complete_post_guards")
        record = {"schema": "GCTS-finite-point-once-observer-custody-v1",
                  "case_id": plan["case_id"], "plan": guards["plan"],
                  "authority": guards["authority"], "root_consumed": root_consumed,
                  "actual_consumed": actual_consumed, "runtime_flags": flags,
                  "limits": LIMITS, "pre_guards": pre, "post_guards": post,
                  "command": command, "child_pid": None if process is None else process.pid,
                  "child_returncode": None if process is None else process.returncode,
                  "child_launch_elapsed_seconds": None if launched is None else launched - started,
                  "child_wait_elapsed_seconds": None if waited is None else waited - started,
                  "observed_launch_to_wait_seconds": None if waited is None or launched is None else waited - launched,
                  "child_reaped": child_reaped, "owned_group_gone": group_gone,
                  "drain_threads_joined": all(not thread.is_alive() for thread in threads),
                  "logs": logs, "unadmitted_worker_artifact": result,
                  "failures": issues, "prior_waited_child_usage": prior_children,
                  "self_observations": observations, "child_observation": child_observation,
                  "admitted_result": None,
                  "scope": "Custody evidence only; scientific result opaque. No file alone is admission.",
                  "memory_semantics": "Observed lifetime child highwater + late self highwater + declared reserve. Not exact simultaneous/process-tree memory or a hard OS cap.",
                  "tail": "Final metadata serialization/write/readback/shutdown after last capture is unmeasured; reserve is an allowance, not a proved bound."}
        encode(record)  # Include one full serialization before a late highwater sample.
        sample("after_custody_record_initial_serialization")
        custody_pin = write_new(directory / "observer-receipt.json", encode(record), METADATA_CAP)
        fsync_directory(directory)
        late = sample("after_custody_receipt_write_and_full_readback")
        child_peak = 0 if child_observation is None else child_observation["high_water_bytes"]
        combined = child_peak + late["high_water_bytes"] + LIMITS["observer_reserve_bytes"]
        if combined > LIMITS["memory_bytes"]:
            issue("COMBINED_OBSERVED_MEMORY", "child+self lifetime observations plus reserve exceed ceiling")
        if time.monotonic() - started >= LIMITS["custody_seconds"]:
            issue("LATE_CUSTODY_TIMEOUT", "late readback/custody exceeded deadline")
        if not child_reaped or not group_gone or not all(not thread.is_alive() for thread in threads):
            issue("INCOMPLETE_CLEANUP", "wait/group/drains incomplete")
        terminal = {"schema": "GCTS-finite-point-once-observer-terminal-v1",
                    "case_id": plan["case_id"], "custody_receipt": custody_pin,
                    "status": "NORMAL_CANDIDATE_AWAITING_EXIT" if not issues else "FAILED_UNADMITTED",
                    "failures": issues, "admitted_result": None,
                    "conditional_result": result if not issues else None,
                    "child_lifetime_high_water": child_observation,
                    "late_observer_high_water": late,
                    "declared_reserve_bytes": LIMITS["observer_reserve_bytes"],
                    "conservative_observed_sum_plus_reserve_bytes": combined,
                    "observed_sum_within_memory_ceiling": combined <= LIMITS["memory_bytes"],
                    "not_exact_simultaneous_or_process_tree_peak": True,
                    "unmeasured_tail": record["tail"],
                    "admission_condition": "Requires complete matching outer terminal stdout, observer exit0, full receipt/readback/guards and observed-resource gates; files alone never admit scientific evidence."}
        terminal_pin = write_new(directory / "observer-terminal.json", encode(terminal), METADATA_CAP)
        fsync_directory(directory)
        final_self = usage_record(resource.RUSAGE_SELF, "after_terminal_write_and_readback", started)
        final_sum = child_peak + final_self["high_water_bytes"] + LIMITS["observer_reserve_bytes"]
        if final_sum > LIMITS["memory_bytes"]:
            issue("FINAL_OBSERVED_MEMORY", "late terminal readback observed sum refusal")
        if time.monotonic() - started >= LIMITS["custody_seconds"]:
            issue("FINAL_CUSTODY_TIMEOUT", "terminal readback exceeded custody deadline")
        outer = {"schema": "GCTS-finite-point-once-observer-outer-terminal-v1",
                 "case_id": plan["case_id"], "status": "NORMAL_WORKER_RETURN" if not issues else "FAILED_UNADMITTED",
                 "observer_exit_required": 0 if not issues else 2,
                 "custody_receipt": custody_pin, "terminal_receipt": terminal_pin,
                 "admitted_result": result if not issues else None, "failures": issues,
                 "child_lifetime_high_water_bytes": child_peak,
                 "late_observer_high_water": final_self,
                 "declared_reserve_bytes": LIMITS["observer_reserve_bytes"],
                 "conservative_observed_sum_plus_reserve_bytes": final_sum,
                 "observed_sum_within_memory_ceiling": final_sum <= LIMITS["memory_bytes"],
                 "elapsed_through_last_observation_seconds": time.monotonic() - started,
                 "unmeasured_tail": "Outer terminal serialization/stdout flush/interpreter shutdown; declared reserve is not a proved bound. No exact process-tree peak claim.",
                 "scientific_admission": False}
        outer_raw = encode(outer)
        require(len(outer_raw) <= TERMINAL_CAP, "outer terminal extent refusal")
        sys.stdout.buffer.write(outer_raw)
        sys.stdout.buffer.flush()
        return 0 if not issues else 2
    finally:
        if process is not None and process.poll() is None:
            kill_group(process, signal.SIGKILL)
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
        stopped.set()
        watcher.join(timeout=1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--authority", required=True)
    args = parser.parse_args()
    try:
        return supervise(args.plan, args.authority)
    except BaseException as error:
        failure = {"schema": "GCTS-finite-point-once-observer-abort-v1",
                   "status": "FAILED_UNADMITTED", "admitted_result": None,
                   "error": type(error).__name__ + ": " + str(error)[:2048],
                   "scope": "No successful outer-terminal/exit-zero join; consumed authority, if present, remains spent."}
        sys.stderr.buffer.write(encode(failure))
        sys.stderr.buffer.flush()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
