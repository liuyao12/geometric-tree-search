"""Inert Source for a separately authorized bounded finite-point qualification.

Importing this file imports no project module and runs no control. Only main()
can authenticate the strict plan and load the exact-pinned engine and oracle.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import sys
import time
import traceback
import types


VERSION = "GCTS-finite-point-qualification-v2"
PLAN_SCHEMA = "GCTS-finite-point-once-plan-v1"
RESULT_SCHEMA = "GCTS-finite-point-qualification-result-v1"
PYTHON = {"path": "/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
          "bytes": 18058560,
          "sha256": "d90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840"}
LIMITS = {"worker_seconds": 60, "custody_seconds": 90, "observer_seconds": 120,
          "memory_bytes": 536870912, "result_bytes": 8388608,
          "log_bytes": 1048576, "observer_reserve_bytes": 9437184}
MAX_AUDITS = 2000
MAX_SUBSET_OPTIONAL = 12
EXPECTED_COUNTS = {"direct_models": 15, "Wang_models": 11, "engine_instances": 33,
                   "controls": 33, "solve_calls": 31, "invalid_models": 19,
                   "invalid_Wang_inputs": 9, "synthetic_selectors": 5,
                   "independent_subsets_examined": 515,
                   "contextual_solve_controls": 1, "context_invalid_forgeries": 3}


class QualificationError(RuntimeError):
    """Fail the complete qualification; no partial evidence is admitted."""


def _need(condition, message):
    if not condition:
        raise QualificationError(message)


def _copy(value):
    return json.loads(json.dumps(value, allow_nan=False, separators=(",", ":")))


def _no_duplicate_object(pairs):
    result = {}
    for key, value in pairs:
        _need(key not in result, "duplicate JSON object key")
        result[key] = value
    return result


def _read_json(path):
    raw = path.read_bytes()
    _need(len(raw) <= 65536, "administrative plan size")
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=_no_duplicate_object,
                       parse_constant=lambda unused: (_ for _ in ()).throw(
                           QualificationError("nonfinite JSON")))
    return value, {"path": str(path), "bytes": len(raw),
                   "sha256": hashlib.sha256(raw).hexdigest()}


def _pin_shape(pin):
    _need(type(pin) is dict and set(pin) == {"path", "bytes", "sha256"}, "rawpin shape")
    _need(type(pin["path"]) is str and Path(pin["path"]).is_absolute(), "rawpin absolute path")
    _need(type(pin["bytes"]) is int and pin["bytes"] >= 0, "rawpin byte count")
    _need(type(pin["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", pin["sha256"]),
          "rawpin digest")


def _canonical_path(value, label, kind):
    _need(type(value) is str, label + " path string")
    path = Path(value)
    _need(path.is_absolute() and str(path) == value and os.path.normpath(value) == value,
          label + " canonical absolute path")
    for ancestor in (path, *path.parents):
        _need(not ancestor.is_symlink(), label + " nonsymlink ancestor chain")
    _need(str(path.resolve(strict=False)) == value, label + " resolved canonical path")
    if kind == "file":
        _need(path.is_file(), label + " regular file")
    elif kind == "directory":
        _need(path.is_dir(), label + " directory")
    elif kind == "newfile":
        _need(not path.exists() and path.parent.is_dir(), label + " fresh file with owned parent")
    else:
        raise QualificationError("unknown canonical path kind")
    return path


def _check_pin(pin):
    _pin_shape(pin)
    path = _canonical_path(pin["path"], "pinned Source/runtime", "file")
    data = path.read_bytes()
    _need(len(data) == pin["bytes"] and hashlib.sha256(data).hexdigest() == pin["sha256"],
          "current rawpin mismatch: " + pin["path"])
    return data


def _authenticate(plan_path, result_path):
    _canonical_path(str(plan_path), "plan", "file")
    _canonical_path(str(result_path), "result", "newfile")
    study = Path(__file__).resolve().parent.parent
    _need(plan_path.is_relative_to(study / "root") and plan_path.suffix == ".json" and
          all(not part.startswith(".") for part in plan_path.relative_to(study).parts) and
          plan_path.is_file(), "owned regular administrative plan")
    for path in (plan_path, *plan_path.parents):
        _need(not path.is_symlink(), "nonsymlink administrative path")
    plan, plan_pin = _read_json(plan_path)
    _need(type(plan) is dict and set(plan) == {
        "schema", "case_id", "actual_dir", "python", "sources", "limits"}, "strict plan fields")
    _need(plan["schema"] == PLAN_SCHEMA, "plan schema")
    _need(type(plan["case_id"]) is str and
          re.fullmatch("[a-z0-9][a-z0-9_-]{0,63}", plan["case_id"]), "case ID")
    actual = study / "actual" / plan["case_id"]
    _canonical_path(str(actual), "owned actual", "directory")
    _need(plan["actual_dir"] == str(actual) and result_path == actual / "worker-result.json",
          "owned actual/result association")
    _need(actual.is_dir() and not result_path.exists(), "fresh owned result")
    _pin_shape(plan["python"])
    _need(plan["python"] == PYTHON and type(plan["limits"]) is dict and
          set(plan["limits"]) == set(LIMITS) and
          all(type(plan["limits"][key]) is int and plan["limits"][key] == value
              for key, value in LIMITS.items()), "runtime or exact limits")
    _need(sys.executable == PYTHON["path"] and sys.platform == "darwin" and
          sys.flags.isolated == 1 and sys.flags.no_site == 1 and
          sys.flags.dont_write_bytecode == 1 and sys.flags.optimize == 0,
          "D90 isolated assertions-enabled invocation")
    _need(type(plan["sources"]) is dict and set(plan["sources"]) == {
        "observer", "worker", "engine", "oracle"}, "four exact source roles")
    expected_paths = {
        "observer": study / "custody-L" / "finite_point_once_observer_v2.py",
        "worker": Path(__file__).resolve(),
        "engine": study / "implementation-B" / "finite_point_engine_v1.py",
        "oracle": study / "independent-C" / "finite_point_independent_v2.py"}
    for role, path in expected_paths.items():
        _pin_shape(plan["sources"][role])
        _need(plan["sources"][role]["path"] == str(path), "source role path")
        _need(0 < plan["sources"][role]["bytes"] <= 2097152, "source extent")
        _check_pin(plan["sources"][role])
    _check_pin(PYTHON)
    return plan, plan_pin


def _load(pin, name):
    """Future main only: compile and execute these exact authenticated bytes."""
    authenticated = _check_pin(pin)
    code = compile(authenticated, pin["path"], "exec", dont_inherit=True, optimize=0)
    module = types.ModuleType(name)
    module.__file__ = pin["path"]
    module.__package__ = ""
    module.__loader__ = None
    module.__spec__ = None
    module.__cached__ = None
    sys.modules[name] = module
    exec(code, module.__dict__)
    return module


def _placement(identity, support, markings=None, kind=None, translation=None):
    return {"id": identity, "type": kind if kind is not None else identity,
            "translation": translation if translation is not None else [0, 0],
            "t": support, "m": markings if markings is not None else []}


def _model(required, placements, capacity=1, seeds=None):
    return {"schema": "GCTS-finite-point-instance-v1", "capacity": capacity,
            "required": required, "placements": placements,
            "seeds": seeds if seeds is not None else []}


def _point_controls():
    """New Source-literal controls, constructed only in the later actual."""
    return [
        ("empty", _model([], [])),
        ("untouched-dead", _model([[0, 0]], [])),
        ("pocket-dead-before-forced", _model([[0, 0], [1, 0], [2, 0]], [
            _placement("A", [[0, 0, 1]]), _placement("B", [[2, 0, 1]])])),
        ("one-forced", _model([[0, 0]], [_placement("A", [[0, 0, 1]])])),
        ("duplicate-decoration-identities", _model([[0, 0]], [
            _placement("A", [[0, 0, 1]], kind="same"),
            _placement("B", [[0, 0, 1]], kind="same")])),
        ("fractional-completion", _model([[0, 0]], [
            _placement("A", [[0, 0, 1]]), _placement("B", [[0, 0, 1]])], capacity=2)),
        ("fractional-unfillable-residual", _model([[0, 0]], [
            _placement("A", [[0, 0, 1]])], capacity=2)),
        ("shared-forced-once", _model([[0, 0], [2, 0]], [
            _placement("A", [[0, 0, 1], [2, 0, 1]])])),
        ("outside-Q-positive-capacity", _model([[0, 0]], [
            _placement("S", [[99, 99, 1]]),
            _placement("A", [[0, 0, 1], [99, 99, 1]]),
            _placement("B", [[0, 0, 1]])], seeds=["S"])),
        ("literal-zero-absent-and-channel", _model([[0, 0]], [
            _placement("S", [[99, 99, 1]], [[1000, -1000, "c", "0"]]),
            _placement("A", [[0, 0, 1]], [[1000, -1000, "c", "0"]]),
            _placement("B", [[0, 0, 1]], [[1000, -1000, "c", "1"]]),
            _placement("C", [[0, 0, 1]]),
            _placement("D", [[0, 0, 1]], [[1000, -1000, "other", "1"]])], seeds=["S"])),
        ("distant-m-removes-shared-everywhere", _model([[0, 0], [1, 0], [2, 0]], [
            _placement("A", [[0, 0, 1]], [[1000, 1000, "c", "0"]]),
            _placement("B", [[1, 0, 1], [2, 0, 1]], [[1000, 1000, "c", "1"]]),
            _placement("C", [[1, 0, 1]]), _placement("D", [[2, 0, 1]])])),
        ("mark-reference-counts", _model([[0, 0], [1, 0]], [
            _placement("S", [[9, 9, 1]], [[100, 100, "c", "0"]]),
            _placement("A", [[0, 0, 1]], [[100, 100, "c", "0"]]),
            _placement("B", [[1, 0, 1]], [[100, 100, "c", "0"]])], seeds=["S"])),
        ("failed-first-branch-then-success", _model([[0, 0], [1, 0]], [
            _placement("A", [[0, 0, 1]], [[100, 100, "c", "0"]]),
            _placement("B", [[0, 0, 1]], [[100, 100, "c", "1"]]),
            _placement("C", [[1, 0, 1]], [[100, 100, "c", "1"]]),
            _placement("D", [[1, 0, 1]], [[100, 100, "c", "1"]])])),
        ("seed-exact", _model([[0, 0]], [_placement("S", [[0, 0, 1]])], seeds=["S"])),
        ("nested-fractional-rollback", _model([[0, 0], [1, 0]], [
            _placement("A", [[0, 0, 1], [1, 0, 1]]),
            _placement("B", [[0, 0, 1], [1, 0, 1]]),
            _placement("C", [[0, 0, 1], [1, 0, 1]])], capacity=3))
    ]


def _wang_controls():
    single = [{"id": "U", "N": "a", "E": "a", "S": "a", "W": "a"}]
    duplicate = single + [{"id": "V", "N": "a", "E": "a", "S": "a", "W": "a"}]
    return [
        {"name": "Wang-empty", "palette": [], "region": [], "boundary": None},
        {"name": "Wang-free", "palette": single, "region": [[-1, -1], [0, -1]], "boundary": None},
        {"name": "Wang-fixed", "palette": single, "region": [[0, 0], [1, 0]], "boundary": "all-a"},
        {"name": "Wang-fixed-contradiction", "palette": single, "region": [[0, 0]],
         "boundary": [[0, 0, "N", "b"]]},
        {"name": "Wang-disconnected", "palette": single, "region": [[0, 0], [3, 0]], "boundary": "all-a"},
        {"name": "Wang-concave", "palette": single, "region": [[0, 0], [1, 0], [0, 1]], "boundary": "all-a"},
        {"name": "Wang-holey", "palette": single,
         "region": [[0, 0], [1, 0], [2, 0], [0, 1], [2, 1], [0, 2], [1, 2], [2, 2]],
         "boundary": "all-a"},
        {"name": "Wang-decoration-identities", "palette": duplicate, "region": [[0, 0]], "boundary": None},
        {"name": "Wang-empty-palette-dead", "palette": [], "region": [[0, 0]], "boundary": None},
        {"name": "Wang-interior-mismatch", "palette": [
            {"id": "X", "N": "v", "E": "a", "S": "v", "W": "b"}],
         "region": [[0, 0], [1, 0]], "boundary": None},
        {"name": "Wang-alternating-labels", "palette": [
            {"id": "X", "N": "v", "E": "a", "S": "v", "W": "b"},
            {"id": "Y", "N": "v", "E": "b", "S": "v", "W": "a"}],
         "region": [[0, 0], [1, 0]], "boundary": None}
    ]


def _full_boundary(region, color):
    cells = {tuple(p) for p in region}
    directions = [("N", (0, -1)), ("E", (1, 0)), ("S", (0, 1)), ("W", (-1, 0))]
    return [[x, y, name, color] for x, y in sorted(cells) for name, (dx, dy) in directions
            if (x + dx, y + dy) not in cells]


def _invalid_models():
    base = _model([[0, 0]], [_placement("A", [[0, 0, 1]])])
    cases = []

    def add(name, mutate):
        value = _copy(base)
        mutate(value)
        cases.append((name, value))

    add("boolean-capacity", lambda m: m.update(capacity=True))
    add("zero-capacity", lambda m: m.update(capacity=0))
    add("extra-model-field", lambda m: m.update(extra=0))
    add("missing-model-field", lambda m: m.pop("capacity"))
    add("duplicate-required", lambda m: m["required"].append([0, 0]))
    add("boolean-coordinate", lambda m: m["required"].__setitem__(0, [True, 0]))
    add("duplicate-ID", lambda m: m["placements"].append(_copy(m["placements"][0])))
    add("empty-support", lambda m: m["placements"][0].update(t=[]))
    add("zero-weight", lambda m: m["placements"][0].update(t=[[0, 0, 0]]))
    add("excessive-weight", lambda m: m["placements"][0].update(t=[[0, 0, 2]]))
    add("boolean-weight", lambda m: m["placements"][0].update(t=[[0, 0, True]]))
    add("duplicate-support", lambda m: m["placements"][0].update(t=[[0, 0, 1], [0, 0, 1]]))
    add("duplicate-mark-slot", lambda m: m["placements"][0].update(
        m=[[9, 9, "c", "0"], [9, 9, "c", "0"]]))
    add("numeric-zero-not-literal", lambda m: m["placements"][0].update(m=[[9, 9, "c", 0]]))
    add("unknown-seed", lambda m: m.update(seeds=["missing"]))
    add("duplicate-seed", lambda m: m.update(seeds=["A", "A"]))
    add("ordinary-outside-Q", lambda m: m["placements"][0].update(t=[[9, 9, 1]]))
    cases.append(("seed-capacity-conflict", _model([[0, 0]], [
        _placement("S", [[0, 0, 1]]), _placement("T", [[0, 0, 1]])], seeds=["S", "T"])))
    cases.append(("seed-mark-conflict", _model([[0, 0]], [
        _placement("S", [[0, 0, 1]], [[9, 9, "c", "0"]]),
        _placement("T", [[1, 0, 1]], [[9, 9, "c", "1"]])], seeds=["S", "T"])))
    return cases


def _synthetic_selectors():
    return [
        {"name": "synthetic-late-dead-before-early-forced", "rows": [
            {"point": [0, 0], "generation": 0, "candidates": ["A"]},
            {"point": [9, 0], "generation": 9, "candidates": []}]},
        {"name": "synthetic-late-forced-before-early-branch", "rows": [
            {"point": [0, 0], "generation": 0, "candidates": ["A", "B", "C"]},
            {"point": [9, 0], "generation": 9, "candidates": ["D"]}]},
        {"name": "synthetic-generation-before-degree", "rows": [
            {"point": [0, 0], "generation": 1, "candidates": ["A", "B", "C"]},
            {"point": [9, 0], "generation": 2, "candidates": ["D", "E"]}]},
        {"name": "synthetic-equal-generation-degree-tie", "rows": [
            {"point": [0, 0], "generation": 1, "candidates": ["A", "B", "C"]},
            {"point": [9, 0], "generation": 1, "candidates": ["D", "E"]}]},
        {"name": "synthetic-empty-solution", "rows": []}
    ]


def _invalid_wang():
    one = {"id": "U", "N": "a", "E": "a", "S": "a", "W": "a"}
    return [
        ("duplicate-palette-ID", [one, _copy(one)], [[0, 0]], None),
        ("duplicate-region", [one], [[0, 0], [0, 0]], None),
        ("nonexposed-boundary", [one], [[0, 0], [1, 0]], [[0, 0, "E", "a"]]),
        ("duplicate-boundary", [one], [[0, 0]], [[0, 0, "N", "a"], [0, 0, "N", "a"]]),
        ("numeric-color", [{**one, "N": 0}], [[0, 0]], None),
        ("boolean-region", [one], [[True, 0]], None),
        ("missing-palette-field", [{"id": "U", "N": "a", "E": "a", "S": "a"}], [[0, 0]], None),
        ("invalid-direction", [one], [[0, 0]], [[0, 0, "NE", "a"]]),
        ("nonregion-boundary", [one], [[0, 0]], [[1, 0, "E", "a"]])
    ]


class _Run:
    def __init__(self, engine, oracle, began):
        self.engine_module = engine
        self.oracle = oracle
        self.began = began
        self.budget_calls = 0
        self.audit_count = 0
        self.instances = 0
        self.controls = []

    def budget(self):
        self.budget_calls += 1
        elapsed = time.monotonic() - self.began
        highwater = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        _need(elapsed < LIMITS["worker_seconds"], "worker cooperative elapsed limit")
        _need(highwater + LIMITS["observer_reserve_bytes"] <= LIMITS["memory_bytes"],
              "worker cooperative self highwater plus declared reserve")

    def instance(self, name, model, exhaustive, budget_override=None, result_budget_refusal=False):
        self.budget()
        record = {"name": name, "raw_model": _copy(model), "audits": [],
                  "exhaustive": exhaustive, "actions": []}
        phase = {"value": "constructor"}
        previous = {"metrics": None}
        result_refusals = []

        def audit(engine, event):
            self.budget()
            self.audit_count += 1
            _need(self.audit_count <= MAX_AUDITS, "complete audit extent cap")
            _need(type(event) is dict and set(event) == {"kind", "data"}, "audit event shape")
            snapshot = engine.snapshot()
            check = self.oracle.verify_snapshot(model, snapshot)
            self.oracle.verify_dependencies(model, engine.dependencies)
            metrics = engine.metrics
            self.oracle.verify_metrics(metrics, snapshot, previous["metrics"])
            previous["metrics"] = _copy(metrics)
            kind, data = event["kind"], event["data"]
            fields = {"INITIALIZED": set(), "PLACED": {"id", "reason", "generation"},
                      "EXCLUDED": {"id", "reason"}, "ROLLED_BACK": {"checkpoint"},
                      "DECISION": {"kind", "point", "candidates"},
                      "SOLVE_RESULT": {"status", "nodes", "reason"}}
            _need(kind in fields and type(data) is dict and set(data) == fields[kind], "audit event data")
            if kind == "DECISION":
                self.oracle._same(data, check["decision"], "audited reference decision")
            elif kind == "PLACED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and
                      type(data["generation"]) is int and snapshot["selected"][-1] == data["id"],
                      "placed event")
                _need([data["id"], data["generation"]] in snapshot["tile_generations"], "placed generation")
            elif kind == "EXCLUDED":
                _need(type(data["id"]) is str and type(data["reason"]) is str and
                      {"id": data["id"], "reason": data["reason"]} in snapshot["excluded"], "excluded event")
            elif kind == "ROLLED_BACK":
                _need(type(data["checkpoint"]) is int and data["checkpoint"] == snapshot["trail_size"],
                      "rollback event exact index")
            elif kind == "SOLVE_RESULT":
                _need(type(data["nodes"]) is int and data["nodes"] >= 0 and
                      data["status"] in ("FINITE_EXACT_SOLUTION", "EXHAUSTED_FINITE_SEARCH", "UNKNOWN") and
                      data["reason"] in ("SOLUTION", "EXHAUSTED", "NODE_LIMIT", "EXTERNAL_BUDGET"),
                      "solve event fields")
            if phase["value"] in ("solve", "unknown", "result-audit-refusal"):
                assumed = set(phase.get("assumed_entry_exclusions", []))
                generated_view = {"selected": snapshot["selected"],
                                  "excluded": [row for row in snapshot["excluded"] if row["id"] not in assumed]}
                contextual_solutions = [solution for solution in exhaustive["solutions"]
                                        if not assumed & set(solution)]
                exclusion_check = self.oracle.verify_contextual_exclusions(generated_view, contextual_solutions)
                exclusion_check["assumed_entry_exclusions"] = sorted(assumed)
                exclusion_check["assumption_scope"] = "ASSUMED_ENTRY_BANS_NOT_GLOBAL_NOGOODS"
            else:
                exclusion_check = None
            record["audits"].append({"event": _copy(event), "phase": phase["value"],
                                      "snapshot": snapshot, "metrics": metrics, "independent": check,
                                      "search_exclusion_check": exclusion_check})
            if result_budget_refusal and kind == "SOLVE_RESULT":
                result_refusals.append(data["status"])
                raise self.engine_module.BudgetExceeded("intentional Source-literal result-audit budget refusal")

        engine = self.engine_module.Engine(model, audit=audit,
                                           budget=budget_override if budget_override is not None else self.budget)
        self.instances += 1
        self.oracle._same(model, record["raw_model"], "caller raw model unchanged")
        self.oracle._same(engine.model, self.oracle.canonical_model(model), "canonical engine model")
        record["dependencies"] = engine.dependencies
        record["dependency_check"] = self.oracle.verify_dependencies(model, record["dependencies"])
        _need(len(record["audits"]) == 1 and record["audits"][0]["event"]["kind"] == "INITIALIZED",
              "complete initial audit")
        return engine, record, phase, result_refusals

    def solve_control(self, name, model, wang=None):
        self.budget()
        exhaustive = self.oracle.exhaustive_solutions(model, MAX_SUBSET_OPTIONAL, self.budget)
        engine, record, phase, unused_refusals = self.instance(name, model, exhaustive)
        entry = engine.snapshot()
        checkpoint = engine.checkpoint()
        _need(type(checkpoint) is int and checkpoint == entry["trail_size"], "entry checkpoint")
        phase["value"] = "solve"
        result = engine.solve(node_limit=100000)
        final = engine.snapshot()
        record["result"] = result
        record["result_check"] = self.oracle.verify_solve_result(model, result, entry, final, exhaustive)
        record["entry"] = entry
        record["final"] = final
        if wang is not None:
            palette, region, boundary = wang
            direct = self.oracle.exhaustive_wang_solutions(palette, region, boundary, budget=self.budget)
            inverse = [self.oracle.verify_wang_solution(palette, region, boundary, model, solution)["assignment"]
                       for solution in exhaustive["solutions"]]
            key = lambda value: json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
            self.oracle._same(sorted(inverse, key=key), sorted(direct["solutions"], key=key),
                              "all point subsets versus direct Wang assignments")
            record["Wang"] = {"palette": palette, "region": region, "boundary": boundary,
                               "compiler_check": self.oracle.verify_wang_compilation(palette, region, boundary, model),
                               "direct_exhaustive": direct, "all_point_inverses": inverse}
            if result["status"] == "FINITE_EXACT_SOLUTION":
                record["Wang"]["returned_inverse"] = self.oracle.verify_wang_solution(
                    palette, region, boundary, model, result["selected"])
        phase["value"] = "explicit-final-rollback"
        _need(engine.rollback(checkpoint) is None, "rollback return")
        self.oracle._same(engine.snapshot(), entry, "whole solve rollback including exclusions and trail")
        record["restored"] = engine.snapshot()
        record["final_metrics"] = engine.metrics
        record["rollback_exact"] = True
        self.controls.append(record)
        return record

    def manual_rollback(self, model):
        exhaustive = self.oracle.exhaustive_solutions(model, MAX_SUBSET_OPTIONAL, self.budget)
        engine, record, phase, unused = self.instance("manual-nested-place-exclude-rollback", model, exhaustive)
        phase["value"] = "manual-contextual-exclusions-not-proved-nogoods"
        initial = engine.snapshot()
        outer = engine.checkpoint()
        _need(engine.place("A", "manual-positive-fraction") is None, "place return")
        after_a = engine.snapshot()
        inner = engine.checkpoint()
        engine.place("B", "manual-second-fraction")
        engine.exclude("C", "manual-branch-local-only")
        dead = engine.decision()
        self.oracle._same(dead, self.oracle.reference_decision(engine.snapshot()["frontier"]), "manual dead decision")
        _need(dead["kind"] == "DEAD", "excluded fractional residual becomes dead")
        engine.rollback(inner)
        self.oracle._same(engine.snapshot(), after_a, "nested exact rollback")
        engine.rollback(outer)
        self.oracle._same(engine.snapshot(), initial, "outer exact rollback")
        record["actions"] = ["checkpoint outer", "place A", "checkpoint inner", "place B", "exclude C",
                             "decision DEAD", "rollback inner", "rollback outer"]
        record["states"] = {"initial": initial, "after_A": after_a, "restored": engine.snapshot()}
        record["nested_and_outer_exact"] = True
        self.controls.append(record)

    def unknown_control(self, model, node_limit, external=False, result_refusal=False):
        exhaustive = self.oracle.exhaustive_solutions(model, MAX_SUBSET_OPTIONAL, self.budget)
        gate = {"refuse": False}

        def external_budget():
            self.budget()
            return False if gate["refuse"] else None

        name = ("UNKNOWN-result-audit-refusal" if result_refusal else
                "UNKNOWN-external-budget" if external else "UNKNOWN-node-limit-" + str(node_limit))
        engine, record, phase, refusals = self.instance(
            name, model, exhaustive, external_budget if external else None, result_refusal)
        entry = engine.snapshot()
        phase["value"] = "result-audit-refusal" if result_refusal else "unknown"
        gate["refuse"] = external
        result = engine.solve(node_limit=node_limit)
        final = engine.snapshot()
        record["entry"] = entry
        record["final"] = final
        record["result"] = result
        record["result_check"] = self.oracle.verify_solve_result(model, result, entry, final, exhaustive, True)
        _need(result["reason"] == ("EXTERNAL_BUDGET" if external or result_refusal else "NODE_LIMIT"),
              "precise refusal reason")
        if node_limit == 0 and not external and not result_refusal:
            _need(result["nodes"] == 0 and not any(a["event"]["kind"] == "DECISION" for a in record["audits"]),
                  "node zero without decisions")
        if node_limit == 1 and not external and not result_refusal:
            _need(any(a["event"]["kind"] == "PLACED" for a in record["audits"]),
                  "partial branch UNKNOWN control actually entered child")
        if result_refusal:
            _need(refusals == ["FINITE_EXACT_SOLUTION", "UNKNOWN"], "both result-audit refusals retained")
            record["attempted_result_refusals"] = list(refusals)
            record["attempted_positive_event_admitted"] = False
        record["unknown_no_exhaustion_no_exclusion_exact_restoration"] = True
        self.controls.append(record)

    def detached_and_error_controls(self, model):
        exhaustive = self.oracle.exhaustive_solutions(model, MAX_SUBSET_OPTIONAL, self.budget)
        engine, record, phase, unused = self.instance("detached-inspections-and-operation-errors", model, exhaustive)
        phase["value"] = "manual-errors"
        original = engine.snapshot()
        for attribute in ("model", "dependencies", "metrics"):
            before = getattr(engine, attribute)
            throwaway = getattr(engine, attribute)
            throwaway.clear()
            self.oracle._same(getattr(engine, attribute), before, "detached " + attribute)
        throwaway = engine.snapshot()
        throwaway["selected"].append("not-real")
        self.oracle._same(engine.snapshot(), original, "detached snapshot")
        operations = [("unknown-placement", lambda: engine.place("missing", "bad")),
                      ("unknown-exclusion", lambda: engine.exclude("missing", "bad")),
                      ("boolean-checkpoint", lambda: engine.rollback(True)),
                      ("out-of-range-checkpoint", lambda: engine.rollback(10**9)),
                      ("nonstring-reason", lambda: engine.place("A", 0))]
        errors = []
        for name, operation in operations:
            self.budget()
            before = engine.snapshot()
            try:
                operation()
            except self.engine_module.EngineError as error:
                errors.append({"name": name, "exception": type(error).__name__, "message": str(error)})
            else:
                raise QualificationError("operation error not rejected: " + name)
            self.oracle._same(engine.snapshot(), before, "failed operation snapshot unchanged")
        checkpoint = engine.checkpoint()
        engine.place("A", "manual one-use error setup")
        for name, operation in (
                ("selected-placement", lambda: engine.place("A", "bad")),
                ("selected-exclusion", lambda: engine.exclude("A", "bad")),
                ("capacity-illegal-alternative", lambda: engine.place("B", "bad"))):
            self.budget()
            before = engine.snapshot()
            try:
                operation()
            except self.engine_module.EngineError as error:
                errors.append({"name": name, "exception": type(error).__name__, "message": str(error)})
            else:
                raise QualificationError("operation error not rejected: " + name)
            self.oracle._same(engine.snapshot(), before, "selected/illegal error state unchanged")
        engine.rollback(checkpoint)
        self.oracle._same(engine.snapshot(), original, "error setup rollback")
        record["operation_errors"] = errors
        record["initial"] = original
        record["final"] = engine.snapshot()
        record["detached_inspections"] = True
        self.controls.append(record)


    def contextual_control(self):
        model = _model([[0, 0], [1, 0], [2, 0]], [
            _placement("A", [[0, 0, 1]]), _placement("B", [[0, 0, 1]]),
            _placement("C", [[1, 0, 1]]), _placement("D", [[1, 0, 1]]),
            _placement("E", [[2, 0, 1]]), _placement("F", [[2, 0, 1]])])
        exhaustive = self.oracle.exhaustive_solutions(model, MAX_SUBSET_OPTIONAL, self.budget)
        _need(exhaustive["subsets_examined"] == 64 and len(exhaustive["solutions"]) == 8,
              "context model complete global enumeration")
        engine, record, phase, unused = self.instance("contextual-entry-selection-and-assumed-exclusion", model, exhaustive)
        root = engine.snapshot()
        root_checkpoint = engine.checkpoint()
        phase["value"] = "manual-entry-assumptions-not-proved-nogoods"
        engine.place("A", "ASSUMED_ENTRY_SELECTION")
        engine.exclude("C", "ASSUMED_ENTRY_EXCLUSION")
        entry = engine.snapshot()
        entry_checkpoint = engine.checkpoint()
        phase["assumed_entry_exclusions"] = ["C"]
        phase["value"] = "solve"
        result = engine.solve(node_limit=100000)
        final = engine.snapshot()
        record["result_check"] = self.oracle.verify_solve_result(model, result, entry, final, exhaustive)
        _need(record["result_check"]["exact_solution_count"] == 2, "two contextual solutions")
        _need(result["status"] == "FINITE_EXACT_SOLUTION", "contextual solve positive")
        record.update(root=root, entry=entry, final=final, result=result,
                      assumed_entry_exclusions=[{"id": "C", "reason": "ASSUMED_ENTRY_EXCLUSION"}],
                      assumption_claim="Declared solve-entry restriction only; never a global redundancy/nogood proof")
        forgeries = []
        for name, identities, expected_error in (
                ("drops-preselection", ["B", "D", "E"], "solution drops entry selection"),
                ("uses-excluded-ID", ["A", "C", "E"], "solution uses entry exclusion"),
                ("violates-both", ["B", "C", "E"], "solution drops entry selection")):
            self.budget()
            forged = _copy(result)
            forged["selected"] = identities
            global_snapshot = _copy(final)
            global_snapshot["selected"] = list(identities)
            global_snapshot["tile_generations"] = [[identity, 1] for identity in identities]
            global_snapshot["excluded"] = [row for row in final["excluded"] if row["id"] not in identities]
            excluded = {row["id"] for row in global_snapshot["excluded"]}
            for row in global_snapshot["candidate_rows"]:
                row["selected"] = row["id"] in identities
                row["excluded"] = row["id"] in excluded
            # These types have identical per-cell coverage and no markings.
            # Full sums, conflict diagnostics, roots and completed graph remain
            # unchanged; the independent raw snapshot check confirms every field.
            global_point = self.oracle.verify_solution(model, identities)
            _need(global_point["selected"] in exhaustive["solutions"], "forgery globally exact")
            global_state = self.oracle.verify_snapshot(model, global_snapshot)
            self.oracle.verify_metrics(forged["metrics"], global_snapshot)
            try:
                self.oracle.verify_solve_result(model, forged, entry, global_snapshot, exhaustive)
            except self.oracle.IndependentError as error:
                _need(str(error) == expected_error, "forgery rejected for intended context violation")
                rejection = {"type": type(error).__name__, "message": str(error)}
            else:
                raise QualificationError("context-invalid global witness accepted: " + name)
            forgeries.append({"name": name, "synthetic_verifier_control_not_engine_return": True,
                              "forged_result": forged, "globally_valid_snapshot": global_snapshot,
                              "global_solution_check": global_point, "global_snapshot_check": global_state,
                              "context_rejection": rejection})
        record["context_forgeries"] = forgeries
        phase["value"] = "explicit-context-rollback"
        engine.rollback(entry_checkpoint)
        self.oracle._same(engine.snapshot(), entry, "exact contextual solve-entry rollback")
        record["restored_entry"] = engine.snapshot()
        engine.rollback(root_checkpoint)
        self.oracle._same(engine.snapshot(), root, "exact original root rollback")
        record["restored_root"] = engine.snapshot()
        record["final_metrics"] = engine.metrics
        record["context_and_root_rollback_exact"] = True
        self.controls.append(record)


def _qualification(engine_module, oracle, began):
    run = _Run(engine_module, oracle, began)
    _need(engine_module.VERSION == "GCTS-FINITE-POINT-ENGINE-v1" and
          oracle.VERSION == "GCTS-finite-point-independent-v2", "public module versions")
    direct = _point_controls()
    records = {}
    for name, model in direct:
        records[name] = run.solve_control(name, model)
    first_pocket_decision = next(a["event"]["data"] for a in records["pocket-dead-before-forced"]["audits"]
                                 if a["event"]["kind"] == "DECISION")
    _need(first_pocket_decision["kind"] == "DEAD",
          "global untouched dead before forced")
    shared = records["shared-forced-once"]
    _need(shared["result"]["selected"] == ["A"] and shared["result"]["metrics"]["forced_placements"] == 1,
          "one shared forced placement")
    residual = records["fractional-unfillable-residual"]
    _need(residual["result"]["status"] == "EXHAUSTED_FINITE_SEARCH" and
          any(a["event"]["kind"] == "PLACED" for a in residual["audits"]), "fractional residual exercised")
    failed = records["failed-first-branch-then-success"]
    placed = [a["event"]["data"]["id"] for a in failed["audits"] if a["event"]["kind"] == "PLACED"]
    _need(placed[0] == "A" and "B" in failed["result"]["selected"] and
          failed["result"]["metrics"]["backtracks"] >= 1 and
          any(a["event"]["kind"] == "EXCLUDED" and a["event"]["data"]["id"] == "A" for a in failed["audits"]) and
          failed["restored"]["excluded"] == [], "failed-first branch then successful alternative and exclusion undo")
    distant = records["distant-m-removes-shared-everywhere"]
    initial_b = [row for row in distant["entry"]["candidate_rows"] if row["id"] == "B"][0]
    after_a = next(a["snapshot"] for a in distant["audits"]
                   if a["event"]["kind"] == "PLACED" and a["event"]["data"]["id"] == "A")
    _need(initial_b["active"] and not any(edge[2] == "B" for edge in after_a["forward_incidence"]) and
          [row for row in after_a["candidate_rows"] if row["id"] == "B"][0]["marking_conflicts"] == [[1000, 1000, "c"]],
          "distant mark removed both shared edges")
    run.manual_rollback(dict(direct)["nested-fractional-rollback"])
    run.detached_and_error_controls(dict(direct)["duplicate-decoration-identities"])
    run.unknown_control(dict(direct)["failed-first-branch-then-success"], 0)
    run.unknown_control(dict(direct)["failed-first-branch-then-success"], 1)
    run.unknown_control(dict(direct)["failed-first-branch-then-success"], 100000, external=True)
    run.unknown_control(dict(direct)["one-forced"], 100000, result_refusal=True)
    run.contextual_control()
    for fixture in _wang_controls():
        run.budget()
        boundary = (_full_boundary(fixture["region"], "a")
                    if fixture["boundary"] == "all-a" else fixture["boundary"])
        palette, region = _copy(fixture["palette"]), _copy(fixture["region"])
        before = _copy([palette, region, boundary])
        model = engine_module.compile_wang(palette, region, boundary)
        oracle._same([palette, region, boundary], before, "compiler caller inputs unchanged")
        oracle.verify_wang_compilation(palette, region, boundary, model)
        run.solve_control(fixture["name"], model, (palette, region, boundary))
    invalid = []
    for name, model in _invalid_models():
        run.budget()
        outcomes = []
        for role, call, error_type in (
                ("independent", lambda: oracle.validate_model(model), oracle.IndependentError),
                ("engine", lambda: engine_module.Engine(model, budget=run.budget), engine_module.ModelError)):
            try:
                call()
            except error_type as error:
                outcomes.append({"role": role, "exception": type(error).__name__, "message": str(error)})
            else:
                raise QualificationError("invalid model accepted: " + name + "/" + role)
        invalid.append({"name": name, "raw_model": model, "rejections": outcomes})
    invalid_wang = []
    for name, palette, region, boundary in _invalid_wang():
        run.budget()
        outcomes = []
        for role, call, error_type in (
                ("independent", lambda: oracle.validate_wang(palette, region, boundary), oracle.IndependentError),
                ("compiler", lambda: engine_module.compile_wang(palette, region, boundary), engine_module.ModelError)):
            try:
                call()
            except error_type as error:
                outcomes.append({"role": role, "exception": type(error).__name__, "message": str(error)})
            else:
                raise QualificationError("invalid Wang input accepted: " + name + "/" + role)
        invalid_wang.append({"name": name, "palette": palette, "region": region, "boundary": boundary,
                             "rejections": outcomes})
    selectors = []
    for case in _synthetic_selectors():
        run.budget()
        expected = oracle.reference_decision(case["rows"])
        actual = engine_module.reference_decision(case["rows"])
        oracle._same(actual, expected, "synthetic selector")
        selectors.append({**case, "expected": expected, "actual": actual,
                          "scope": "SYNTHETIC_NOT_REACHABLE_UNEQUAL_GENERATION_GROWTH"})
    actual_counts = {"direct_models": len(direct), "Wang_models": len(_wang_controls()),
                     "engine_instances": run.instances, "controls": len(run.controls),
                     "solve_calls": sum("result" in record for record in run.controls),
                     "invalid_models": len(invalid), "invalid_Wang_inputs": len(invalid_wang),
                     "synthetic_selectors": len(selectors),
                     "independent_subsets_examined": sum(record["exhaustive"]["subsets_examined"]
                                                         for record in run.controls),
                     "contextual_solve_controls": sum("context_forgeries" in record for record in run.controls),
                     "context_invalid_forgeries": sum(len(record.get("context_forgeries", [])) for record in run.controls)}
    oracle._same(actual_counts, EXPECTED_COUNTS, "complete fixed control census")
    return run, invalid, invalid_wang, selectors


def main():
    began = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", required=True)
    parser.add_argument("--result", required=True)
    args = parser.parse_args()
    plan_path = _canonical_path(args.plan, "plan CLI", "file")
    result_path = _canonical_path(args.result, "result CLI", "newfile")
    plan, plan_pin = _authenticate(plan_path, result_path)
    oracle = _load(plan["sources"]["oracle"], "gcts_independent_exact_pinned")
    engine = _load(plan["sources"]["engine"], "gcts_engine_exact_pinned")
    run, invalid, invalid_wang, selectors = _qualification(engine, oracle, began)
    run.budget()
    envelope = {
        "schema": RESULT_SCHEMA, "status": "FINITE_POINT_QUALIFICATION_PASS",
        "scope": "NEW_TINY_FINITE_ALL_ROOT_POINT_CONTROLS_ONLY",
        "sources": plan["sources"], "plan": plan_pin, "limits": plan["limits"],
        "costs": {"worker_elapsed_seconds_before_serialization": time.monotonic() - began,
                  "worker_self_lifetime_highwater_bytes_before_serialization": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  "budget_callbacks_before_serialization": run.budget_calls,
                  "memory_scope": "Darwin RUSAGE_SELF lifetime maximum; cooperative checks, not a hard cap or exact process-tree measurement"},
        "counts": {"engine_instances": run.instances, "stable_audits": run.audit_count,
                   "controls": len(run.controls), "invalid_models": len(invalid),
                   "invalid_Wang_inputs": len(invalid_wang),
                   "synthetic_selectors": len(selectors), "fixed_recipe": EXPECTED_COUNTS},
        "controls": {"valid": run.controls, "invalid_models": invalid,
                     "invalid_Wang_inputs": invalid_wang, "synthetic_selectors": selectors},
        "coverage": ["complete raw t/m/Q/generation/candidate/graph/dependency recomputation at every stable event",
                     "independent complete tiny subset solution sets and whole solution verification",
                     "free/fixed/partial/concave/holey/disconnected Wang collar and inverse assignments",
                     "shared forced, fractional residual, distant mark-only, literal zero versus missing",
                     "dead then forced then generation selector, nested/failed-child/UNKNOWN exact rollback"],
        "limitations": ["All finite Q are generation-zero roots; unequal-generation selector controls are synthetic.",
                        "No infinite growth/fairness, Turtle/Penrose geometric faithfulness, learned markings, RL clusters, FOL palette or theorem discovery.",
                        "No performance or memory improvement comparison; all source-authored controls are new tiny deterministic cases.",
                        "Counters are cumulative; semantic snapshots including opaque trail index roll back exactly.",
                        "Costs precede serialization/readback; observer supplies separate late custody observations and declared tail reserve."]}
    run.budget()
    raw = json.dumps(envelope, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
    _need(len(raw) <= LIMITS["result_bytes"], "whole qualification result extent")
    run.budget()
    for pin in plan["sources"].values():
        _check_pin(pin)
    _check_pin(PYTHON)
    _need(_read_json(plan_path)[1] == plan_pin, "plan unchanged after qualification")
    with result_path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    run.budget()
    saved = result_path.read_bytes()
    _need(saved == raw, "whole qualification result readback")
    run.budget()
    print(json.dumps({"schema": "GCTS-finite-point-worker-terminal-v1", "status": envelope["status"],
                      "bytes": len(saved), "sha256": hashlib.sha256(saved).hexdigest()}, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(json.dumps({"schema": "GCTS-finite-point-worker-error-v1", "type": type(error).__name__,
                          "error": str(error), "normal_result_admitted": False}), file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        raise SystemExit(2)
