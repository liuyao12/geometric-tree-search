GCTS proof normalization and cluster-preference pilot, milestone T

This is the complete pre-publication scientific snapshot: all original run
files, source modules, APIs, inputs, original outcomes, native proof checks,
qualification controls, raw/gzip artifacts, independent reviews and supporting
data audits. MANIFEST.json maps every original entry to its absolute origin,
length and SHA256. Local paths are included with the user's explicit consent.

The HTML notebook and public results JSON are published separately beside this
archive. Sources and raw outputs here are their scientific evidence. Temporary
presentation drafts and duplicate payload directories are omitted. Subsequent
publication/API/TLS records cannot be included without circularity and are kept
as a separate local completion snapshot.

The original batch authority is permanently spent; do not overwrite its output.
The batch driver pins absolute paths and uses exclusive output directories. A
new reproduction requires fresh paths and output locations. Individual pure
verifier/checker APIs are documented in the included ABI files. Source-based
proof checking can be reproduced independently; the Python runtime executable
is identified by its exact pin but is not redistributed. Original runtime was
Python 3.12 on Darwin; reported timings and RSS are local observations.

This is a small GIVEN/MP symbolic point-tile study. Normalization preserves
bounded proof existence, not every original tiling. The actual trained policy
changed weights but showed no evaluation benefit. Neither a fixed universal
Wang palette nor full first-order mathematics search is claimed.
