"""Passive closed-record joins only; no project imports, solver/checker replay."""
from pathlib import Path
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
import re
import stat

T=Path('/private/tmp/gcts-proof-normalization-20261028-v1')
A=T/'actual/study-001'; R=T/'root'; OUT=T/'implementation-B/actual-review-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()+b'\n'
def read(p):
    p=Path(p);a=p.stat();assert stat.S_ISREG(a.st_mode)and a.st_nlink==1 and not p.is_symlink()and p.resolve()==p
    b=p.read_bytes();c=p.stat();assert(a.st_dev,a.st_ino,a.st_mtime_ns,a.st_size)==(c.st_dev,c.st_ino,c.st_mtime_ns,c.st_size)and len(b)==a.st_size;return b
def pin(p):
    b=read(p);return{'path':str(p),'bytes':len(b),'sha256':sha(b)}
def checked(r):
    assert set(r)=={'path','bytes','sha256'}and type(r['bytes'])is int
    b=read(r['path']);assert len(b)==r['bytes']and sha(b)==r['sha256'];return b
def parse(b):
    def pairs(rows):
        d={}
        for k,v in rows:assert k not in d;d[k]=v
        return d
    return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def get(p):return parse(read(p))
def value_count(v):
    count=0;stack=[v]
    while stack:
        x=stack.pop();count+=1
        assert type(x)in(dict,list,str,int,float,bool,type(None))
        if type(x)is float:assert math.isfinite(x)
        if type(x)is list:stack.extend(x)
        if type(x)is dict:
            assert all(type(k)is str for k in x);stack.extend(x.values())
    return count
def artifact(ref):
    assert set(ref)=={'name','stored','encoding','raw_bytes','raw_sha256'}
    assert Path(ref['stored']['path']).parent==A
    b=checked(ref['stored']);raw=gzip.decompress(b)if ref['encoding']=='gzip-json'else b
    assert ref['encoding']in('json','gzip-json')and len(raw)==ref['raw_bytes']and sha(raw)==ref['raw_sha256']
    assert len(raw)<=33554432 and len(b)<=33554432
    d=parse(raw);assert wire(d)==raw
    return d

transport_path=R/'study-001-original-tool-whole-transport-adoption-v1.json'
transport=get(transport_path)
assert transport['original_tool']=={'exit_code':0,'initial_chunk':'ab2d16','intermediate':'ab3de7','session':98326,'terminal_chunk':'ab5ae6'}
worker=artifact(transport['worker_result']);observer=parse(checked(transport['observer']))
assert transport['worker_result']['stored']['sha256']=='a16dc69367a1ee968752d5ee36c52e17fc966a00704fbce43995a8f9382d3647'
assert transport['observer']['sha256']=='d7fe0b3a86d3f8f310386844c61072f81cb4d7f79fc33ebf9d3c8eb0a4298bf8'
physical=[pin(p)for p in sorted(A.iterdir())]
assert len(physical)==273 and sum(p['bytes']for p in physical)==4168005
assert len(observer['files'])==272 and sum(p['bytes']for p in observer['files'])==observer['stored_bytes']==4103401
assert {p['path']for p in observer['files']}|{str(A/'observer-result.json')}=={p['path']for p in physical}
for p in observer['files']:checked(p)
assert observer['status']=='COMPLETE'and observer['returncode']==0 and observer['failure']is None and observer['cleanup_errors']==[]
assert observer['wait_confirmed']and observer['both_streams_EOF']and observer['group_gone']and observer['stdin_bytes_sent']==31725
assert observer['retained_streams_complete']=={'stdout':True,'stderr':True}
stdout=parse(read(A/'stdout.bin'));assert read(A/'stderr.bin')==checked(transport['outer_stderr'])==b''
assert stdout==observer['worker_terminal']and stdout['status']=='COMPLETE'and stdout['result']==transport['worker_result']
outer=parse(checked(transport['outer_stdout']));assert outer['status']=='COMPLETE'and outer['receipt']==transport['observer']
assert stdout['elapsed_seconds']==transport['worker_seconds']==24.49041150000994
assert observer['whole_observer_seconds']==transport['observer_seconds']==24.604902624996612 and observer['wait4_peak_bytes']==80412672
assert observer['observed_stream_bytes']=={'stdout':len(read(A/'stdout.bin')),'stderr':0}
plan_path=R/'study-once-plan-001.json';plan=get(plan_path)
assert stdout['plan']==pin(plan_path)and stdout['public_calls']==worker['outer_public_calls']
adoption=get(R/'Root-current-Source-adoption-v1.json');assert adoption['sources']==plan['sources']and adoption['metadata']==plan['metadata']and adoption['plan']==pin(plan_path)
guards=[]
for k in ['sources','metadata']:
    for role,ref in plan[k].items():checked(ref);guards.append({'kind':k,'role':role,**ref})
checked(plan['python']);checked(plan['bootstrap'])
authority_path=R/'study-once-authority-001.json';authority=get(authority_path);consume_path=Path(str(authority_path)+'.CONSUMED.json');consume=get(consume_path)
assert authority=={'schema':'T-normalization-proof-once-authority-v1','uses':1,'authorized':True,'plan':pin(plan_path),'runner':plan['sources']['runner'],'python':plan['python']}
assert type(authority['uses'])is int and type(authority['authorized'])is bool
assert consume=={'authority':pin(authority_path),'plan':pin(plan_path),'status':'SPENT'}
assert get(A/'CONSUMED.json')=={'authority':pin(authority_path),'consumed':pin(consume_path)}
assert observer['command']==[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],'31725',plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(plan_path)]

refs=worker['artifacts']+[transport['worker_result']]
assert len(refs)==269 and len({r['name']for r in refs})==269
data={r['name']:artifact(r)for r in refs}; reference={r['name']:r for r in refs}
assert sum(r['raw_bytes']for r in refs)==27118191
assert {r['stored']['path']for r in refs}=={p['path']for p in physical}-{str(A/x)for x in ['CONSUMED.json','stdout.bin','stderr.bin','observer-result.json']}
artifact_census=[{'reference':r,'native_value_count':value_count(data[r['name']])}for r in refs]
assert worker==data['worker-result']and worker['qualification']==data['whole-qualification']

# Join supplied point certificates/states against their exact saved candidate rows.
# No unseen assignment, transition, branch or proof is generated/evaluated.
graph_count=graph_edges=mark_assignments=candidate_rows=0
def selected_rows(model, ids):
    by={c['id']:c for c in model['candidates']};totals=Counter();values={};counts=Counter()
    assert type(ids)is list and len(ids)==len(set(ids))
    for identity in ids:
        c=by[identity]
        for point in c['t']:totals[point]+=1
        for point,value in c['m']:
            assert point not in values or values[point]==value
            values[point]=value;counts[point]+=1
    return {'selected':sorted(ids),'totals':[[p,totals[p]]for p in model['required']],
            'markings':[[p,values[p],counts[p]]for p in sorted(values)],
            'generations':[[identity,1]for identity in sorted(ids)]}
def initial_graph(model,state):
    global graph_count,graph_edges
    required=model['required'];by={c['id']:c for c in model['candidates']}
    domains={p:[]for p in required}
    for identity in sorted(by):
        c=by[identity];assert len(c['t'])==1 and c['t'][0]in domains
        domains[c['t'][0]].append(identity)
    forward=[[p,i,1]for p in required for i in domains[p]]
    reverse=[[i,by[i]['t'][0],1]for i in sorted(by)]
    assert state=={'schema':'S-structural-unit-point-state-v1','selected':[],
       'totals':[[p,0]for p in required],'markings':[],'domains':[[p,domains[p]]for p in required],
       'excluded':[],'forward_incidence':forward,'reverse_incidence':reverse,'generations':[[p,0]for p in required]}
    graph_count+=1;graph_edges+=len(forward)
def raw_solve(model,result,node_cap):
    global candidate_rows,mark_assignments
    assert set(result)=={'schema','version','status','reason','selected','certificate','stats','events','event_extent','model_sha256','entry_state','restored_state','state_hashes','rollback_records','scope'}
    assert result['schema']=='S-structural-unit-point-result-v1'and result['version']=='S-STRUCTURAL-UNIT-POINT-SEARCH-v1'
    # The frozen engine ABI hashes canonical row order, not input row order.
    normalized={'required':model['required'],'candidates':[
        {'id':c['id'],'t':c['t'],'m':sorted(c['m'],key=lambda x:x[0])}
        for c in sorted(model['candidates'],key=lambda x:x['id'])]}
    assert result['model_sha256']==sha(wire(normalized))
    ids={c['id']for c in model['candidates']};assert len(ids)==len(model['candidates'])
    for c in model['candidates']:
        assert set(c)=={'id','t','m'}and len(c['m'])==len({p for p,v in c['m']})
        assert all(type(p)is str and type(v)is str for p,v in c['m'])
    s=result['stats'];assert len(s)==29
    assert all(type(v)is int and v>=0 for k,v in s.items()if k!='elapsed_seconds')and type(s['elapsed_seconds'])is float and s['elapsed_seconds']>=0
    assert s['candidates']==s['initial_edges']==len(ids)and s['required_points']==len(model['required'])
    assert s['mark_assignments']==s['dependency_links']==sum(len(c['m'])for c in model['candidates'])
    assert s['mark_points']==len({p for c in model['candidates']for p,v in c['m']})
    assert s['trail_writes']==s['trail_undos']==s['cleanup_operations']and s['nodes']<=node_cap
    candidate_rows+=len(ids);mark_assignments+=s['mark_assignments']
    assert result['entry_state']is not None
    initial_graph(model,result['entry_state']);assert result['state_hashes']['entry']==sha(wire(result['entry_state']))
    if result['restored_state']is not None:
        initial_graph(model,result['restored_state']);assert result['restored_state']==result['entry_state']
        assert result['state_hashes']['restored']==result['state_hashes']['entry']
    else:
        assert result['status']=='UNKNOWN'and result['state_hashes']['restored']is None
    events=result['events'];extent=result['event_extent']
    assert len(events)==extent['retained']==s['retained_events']and extent['count']==s['events']and len(events)<=64
    assert extent['retained_complete']==(len(events)==extent['count'])and extent['evaluation_complete']==(result['status']!='UNKNOWN')
    retained_raw=b''.join(wire(e)for e in events)
    assert extent['JSONL_bytes']>=len(retained_raw)and re.fullmatch('[0-9a-f]{64}',extent['SHA256'])
    if extent['retained_complete']:assert extent['JSONL_bytes']==len(retained_raw)and extent['SHA256']==sha(retained_raw)
    roll=result['rollback_records'];failed=[r for r in roll if r['reason']=='COMPLETE_FAILED_CHILD']
    assert len(failed)==s['backtracks']==s['scoped_exclusions']==s['candidate_eliminations_exclusion']
    assert len(roll)==len(failed)+1 and roll[-1]['reason']=='FINAL_MANDATORY_CLEANUP'
    assert sum(r['undone']for r in roll)==s['trail_undos']
    for r in roll:
        assert set(r)=={'reason','candidate','from_trail','to_trail','undone','expected_sha256','restored_sha256','equal'}
        assert r['from_trail']>=r['to_trail']>=0 and r['undone']==r['from_trail']-r['to_trail']
        if r['reason']=='COMPLETE_FAILED_CHILD':assert r['candidate']in ids and r['equal']is True and r['expected_sha256']==r['restored_sha256']
    last=roll[-1];assert last['candidate']is None and last['to_trail']==0 and last['expected_sha256']==result['state_hashes']['entry']
    if result['restored_state']is None:assert last['equal']is None and last['restored_sha256']is None
    else:assert last['equal']is True and last['restored_sha256']==result['state_hashes']['entry']
    fidx=0;events_by_kind=Counter()
    for j,e in enumerate(events):
        assert set(e)=={'seq','kind','data'}and e['seq']==j;events_by_kind[e['kind']]+=1;d=e['data']
        if e['kind']=='BRANCH':
            assert d['point']in model['required']and d['generation']==0 and d['legal']==sorted(d['legal'])and len(d['legal'])>=2
            assert set(d['ordering'])==set(d['legal'])and len(d['ordering'])==len(d['legal'])and all(i in ids for i in d['legal'])
        elif e['kind']=='PLACED':
            assert d['candidate']in ids and type(d['forced'])is bool and d['root_generation']==0 and d['tile_generation']==1
            assert next(c['t'][0]for c in model['candidates']if c['id']==d['candidate'])==d['point']
        elif e['kind']=='DEAD':assert d['point']in model['required']and d['generation']==0
        elif e['kind']=='ROLLBACK':
            assert d==failed[fidx];fidx+=1
            if j+1<len(events):assert events[j+1]['kind']=='EXCLUDED'and events[j+1]['data']['candidate']==d['candidate']and events[j+1]['data']['parent_sha256']==d['restored_sha256']
        elif e['kind']=='EXCLUDED':assert j>0 and events[j-1]['kind']=='ROLLBACK'
        elif e['kind']=='SOLUTION':assert d['selected']==result['selected']
        else:raise AssertionError(e['kind'])
    assert events_by_kind['BRANCH']<=s['branch_decisions']and events_by_kind['ROLLBACK']<=s['backtracks']
    if extent['retained_complete']:
        assert events_by_kind['BRANCH']==s['branch_decisions']and events_by_kind['ROLLBACK']==s['backtracks']
        assert sum(e['kind']=='PLACED'and e['data']['forced']for e in events)==s['forced_placements']
    if result['status']=='SAT':
        cert=selected_rows(model,result['selected']);assert cert==result['certificate']and all(v==1 for p,v in cert['totals'])
    else:assert result['status']in('UNSAT','UNKNOWN')and result['selected']is None and result['certificate']is None
    return {'status':result['status'],'model_SHA256':result['model_sha256'],'stats':s,'retained_events':len(events),'event_extent':extent,
            'retained_event_kinds':dict(events_by_kind),'entry_SHA256':result['state_hashes']['entry'],'restored_SHA256':result['state_hashes']['restored'],
            'rollback_records':len(roll),'complete_ordered_rollback_SHA256':sha(wire(roll)),'all_supplied_graphs_and_saved_counters_joined':True}

qualification=worker['qualification'];assert qualification['status']=='PASS'and qualification['counts']=={'BFS':6,'compile':15,'decode':12,'solve':15}
qrows=[];qby={};allq=[]
for ref in qualification['records']:
    q=artifact(ref['reference']);assert q==data[ref['reference']['name']]and q['id']==ref['id']
    bundle=q['bundle'];model=bundle['model'];result=q['result'];problem=q['problem'];lane=q['lane']
    assert bundle['lane']==lane and bundle['hypotheses']==problem['hypotheses']and bundle['goal']==problem['goal']and bundle['slots']==problem['maxlines']
    assert q['independent_universe']['status']=='VERIFIED'and q['independent_universe']['candidates']==len(model['candidates'])
    audit=raw_solve(model,result,5000)
    domain_counts=Counter(c['t'][0]for c in model['candidates']);assignments=math.prod(domain_counts[p]for p in model['required'])
    ex=q['exhaustive'];assert ex['status']=='COMPLETE'and ex['assignments']==assignments
    assert len({tuple(x)for x in ex['solutions']})==len(ex['solutions'])
    for solution in ex['solutions']:assert all(v==1 for p,v in selected_rows(model,solution)['totals'])
    assert (result['status']=='SAT')==bool(ex['solutions'])
    if result['status']=='SAT':
        assert result['selected']in ex['solutions']and q['decoded']['status']=='UNVERIFIED_CERTIFICATE'
        proof=[bundle['steps'][i]['line']for i in sorted(result['selected'],key=lambda x:bundle['steps'][x]['slot'])]
        assert q['decoded']['proof']==proof==q['independent_selected']['proof']and q['independent_selected']['status']=='VERIFIED'
    else:assert q['decoded']is None and q['independent_selected']is None
    core=ref['id'].rsplit('-',2)[0]if lane.startswith('EXPANDED')else ref['id'].removesuffix('-S-REFERENCE')
    core=ref['id'].removesuffix('-'+lane.replace('_','-'))
    qby.setdefault(core,{})[lane]=q;allq.append(q)
    qrows.append({'id':q['id'],'lane':lane,'saved_assignments':assignments,'saved_solutions':len(ex['solutions']),'raw_result':audit,'reference':ref['reference']})
assert len(qrows)==15 and len(qby)==5
for core,triple in qby.items():
    assert set(triple)=={'S_REFERENCE','EXPANDED_OFF','EXPANDED_ON'}
    assert len({bool(x['exhaustive']['solutions'])for x in triple.values()})==1
    base,off,on=[triple[k]['bundle']for k in ['S_REFERENCE','EXPANDED_OFF','EXPANDED_ON']]
    assert off['steps']==on['steps']and off['model']['required']==on['model']['required']==base['model']['required']
    assert [c['id']for c in off['model']['candidates']]==[c['id']for c in on['model']['candidates']]
    assert off['model']['candidates'][:len(base['model']['candidates'])]==base['model']['candidates']
    for x,y in zip(off['model']['candidates'],on['model']['candidates'],strict=True):assert x['id']==y['id']and x['t']==y['t']and x['m']==[m for m in y['m']if m[0].startswith('out:')]
last=allq[-1];negatives=last['data_only_controls'];assert [x['kind']for x in negatives]==['phase','name-order','real-duplicate','PAD-reference']
negative_rows=[]
for x,prefix in zip(negatives,['nf:phase:','nf:hyp:','nf:unique:','nf:use:'],strict=True):
    assert x['OFF']['status']=='VERIFIED'and x['ON']['status']=='REJECTED'and x['ON']['proof']is None
    triple=qby[x['problem_id']];selected_rows(triple['EXPANDED_OFF']['bundle']['model'],x['selected'])
    by={c['id']:c for c in triple['EXPANDED_ON']['bundle']['model']['candidates']};values=defaultdict(set)
    for identity in x['selected']:
        for p,v in by[identity]['m']:values[p].add(v)
    conflicts=sorted(p for p,v in values.items()if len(v)>1)
    assert conflicts and all(p.startswith(prefix)for p in conflicts)
    negative_rows.append({'kind':x['kind'],'selected':x['selected'],'saved_OFF':'VERIFIED','saved_ON':'REJECTED','actual_literal_conflict_points':conflicts})
missing=last['missing_mark_control'];assert missing['independent_rejection']['status']=='REJECTED'
original=qby['derived-three']['EXPANDED_ON']['bundle'];forged=missing['forged_bundle']
assert {k:v for k,v in original.items()if k!='model'}=={k:v for k,v in forged.items()if k!='model'}
assert original['model']['required']==forged['model']['required']and len(original['model']['candidates'])==len(forged['model']['candidates'])
removed=[]
for x,y in zip(original['model']['candidates'],forged['model']['candidates'],strict=True):
    assert x['id']==y['id']and x['t']==y['t'];assert all(m in x['m']for m in y['m'])
    removed.extend({'id':x['id'],'mark':m}for m in x['m']if m not in y['m'])
assert len(removed)==1 and removed[0]['mark'][0].startswith('nf:')
bfs=[q['bounded_BFS']for q in allq if 'bounded_BFS'in q];assert len(bfs)==5
assert [x['status']for x in bfs]==['DERIVABLE','DERIVABLE','DERIVABLE','DERIVABLE','NOT_DERIVABLE']
assert [x['shortest_lines']for x in bfs]==[1,1,1,3,None]
budget=last['BFS_budget_control'];assert budget['status']=='UNKNOWN'and budget['proof']is None and budget['shortest_lines']is None and budget['reason']=='max_states'

points=[(r['id'],r['case'],r['result'])for r in worker['training']]
for r in worker['results']:
    for lane in r['execution_order']:points.append(('eval-'+r['id'],r['id'],r['lanes'][lane]))
assert len(points)==34 and len(worker['training'])==9 and len(worker['results'])==5
point_rows=[]
for identity,case,row in points:
    bundle=artifact(row['bundle']);answer=artifact(row['solve']);lane=row['lane'];mode=lane if lane in('S_REFERENCE','EXPANDED_OFF')else'EXPANDED_ON'
    assert bundle['lane']==mode and row['status']==answer['status']and row['stats']==answer['stats']and row['reason']==answer['reason']
    assert row['search_seconds_inclusive']>=answer['stats']['elapsed_seconds']and row['audit_and_storage_seconds']>=0
    audit=raw_solve(bundle['model'],answer,50000)
    stem=identity+'-'+lane.replace('_','-')
    ua=data[stem+'-universe-audit'];sa=data[stem+'-state-audit']
    assert ua['status']=='VERIFIED'and ua['candidates']==len(bundle['model']['candidates'])and sa['status']=='VERIFIED'and sa['certificate']==answer['certificate']
    if answer['status']=='SAT':
        proof=[bundle['steps'][i]['line']for i in sorted(answer['selected'],key=lambda x:bundle['steps'][x]['slot'])]
        selection=data[stem+'-selection-audit'];assert selection['status']=='VERIFIED'and selection['proof']==row['proof']==proof
        assert row['selected']==answer['selected']and row['checking']['status']=='VERIFIED'
    else:assert row['proof']is None and 'checking'not in row
    point_rows.append({'id':identity,'case':case,'lane':lane,'bundle':row['bundle'],'solve':row['solve'],'universe_audit':reference[stem+'-universe-audit'],'state_audit':reference[stem+'-state-audit'],'result':audit})
assert Counter(x['result']['status']for x in point_rows)=={'SAT':22,'UNSAT':9,'UNKNOWN':3}
expected_calls={'carrier.build_carrier':28,'carrier.verify_carrier_choice':28,'clusters.instantiate':19,'clusters.make_order':19,'clusters.mine_families':1,'clusters.new_policy':2,'clusters.update_policy':9,'codec.decode':28,'codec.encode':28,'engine.solve':34,'fol_checker.check':28,'independent.bounded_bfs':5,'independent.qualify':1,'independent.verify_bundle':34,'independent.verify_selection':22,'normalizer.compile_problem':34,'normalizer.decode_selected':22,'state_audit.mp_closure':5,'tree_machine.Compiler':1,'tree_machine.Heap':28,'tree_machine.run':28,'tree_machine.validate':1}
assert worker['outer_public_calls']==expected_calls
summary={'qualification_statuses':dict(Counter(x['raw_result']['status']for x in qrows)),'qualification_assignment_count':sum(x['saved_assignments']for x in qrows),'qualification_saved_witnesses':sum(x['saved_solutions']for x in qrows),'main_point_statuses':dict(Counter(x['result']['status']for x in point_rows)),
 'main_aggregate_stats':{k:sum(x['result']['stats'][k]for x in point_rows)for k in ['nodes','forced_placements','branch_decisions','backtracks','scoped_exclusions','trail_writes','trail_undos','events','retained_events','ordering_calls']},
 'all49_graph_images':graph_count,'all49_forward_edges_checked':graph_edges,'all49_candidate_rows':candidate_rows,'all49_model_mark_assignments':mark_assignments,
 'main_complete_event_hashes_recomputed':sum(x['result']['event_extent']['retained_complete']for x in point_rows),
 'main_rollback_records':sum(x['result']['rollback_records']for x in point_rows),'main_complete_restored_images':sum(x['result']['restored_SHA256']is not None for x in point_rows),
 'all269_native_JSON_values_traversed':sum(x['native_value_count']for x in artifact_census)}
OUT.mkdir(parents=True,exist_ok=True)
support={'schema':'B-T-complete-saved-qualification-rawgraph-support-v1','Root_transport':pin(transport_path),'current_plan':pin(plan_path),'all273physicalpins':physical,'all269artifact_raw_census':artifact_census,'all27current_Source_metadata_runtime_bootstrap_guards':guards+[{'kind':'runtime',**plan['python']},{'kind':'bootstrap',**plan['bootstrap']}],
 'qualification15':qrows,'four_layer_negative_data_joins':negative_rows,'missing_literal':removed,'BFS_budget':budget,'main34':point_rows,'outer_public_calls':expected_calls,'counters':summary,
 'data_boundary':'Only saved row/field/hash/count/graph-incidence/mark-value aggregation. No unsaved assignment enumeration, solver/search/checker/decoder invocation, intermediate-state reconstruction or proof reclassification. Tiny exhaustive completeness and full unretained traversal remain authenticated in-actual assertions from reviewed Sources.'}
sp=OUT/'complete-saved-qualification-and-rawgraph-support-v1.json';sb=json.dumps(support,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n'
with sp.open('xb')as f:f.write(sb)
assert sp.read_bytes()==sb
review={'schema':'B-T-complete-independent-saved-qualification-and-rawgraph-review-v1','decision':'PASS_COMPLETE_ASSIGNED_SAVED_COHORT','blockers':[],'Root_original_transport':pin(transport_path),'observer':transport['observer'],'worker_result':transport['worker_result'],'full_support':pin(sp),'counters':summary,
 'whole_scope':['All273originals/269complete raw/gzip/canonicalstrictJSON bodies and all12Sources/13metadata/D90/bootstrap/plan/A6/consume/marker/outer/ownedexit/wait/EOF/group/caps joined. Scientific once is permanently spent.',
 'All15qualificationrecords,15compile/solve,12decode and6BFS;12SAT/3UNSAT,91savedexaminedassignments/39savedwitnesses. Every saved witness selection joins its exactcandidate t/m rows; full productcounts agree. No assignments were re-enumerated. Original/OFF/ON existence agrees on all5tinyinputs.',
 'Four actualOFF-valid/ON-rejected selections isolatephase/nameorder/realduplicate/PADreference conflicts in their corresponding literalpointprefix. Fullone-mark-deletedforgedbundle differs byexactlyone nf assignment and isrejected. BFS1/1/1/3 shortestline receipts andderivedtwo boundednegative retained;zero-state cap remainsUNKNOWN/no proof.',
 'All34main bundle/modelhashes/counts/29counters/entrygraphs andall31suppliedrestoredgraphs joined. Both incidence directions anddomains enumerate every modelcandidate edge;markdependencies include every outsideQ mark. All22SATcertificates aggregate exactselected t/m/refcounts/generations and match independently savedraw-state/selection receipts.',
 'All retained events and every complete rollbacklist inspected in order. Fullprefix hashes recomputed onlywhenall events retained;otherextent hashes are authenticatedsavedcommitments,not inventedtail. Everyfailedchild iscontext-scoped by matchedrollback/excludedparent hash. Trailwrites==undos and fullundocounts match everyrecord.',
 'The3wallUNKNOWN records retainentry butno restoredimage/hash; mandatorycleanuprecord hasnullobservation/equality whileactualundocounts are retained. This is not promoted to a freshrestorationcertificate. UNSAT is onlyauthenticated finite-source exhaustion over verifieduniverse; clippedevents are not an independent wholeproof tree.',
 'All22outerpubliccallcounts match34pointarms/9updates/25evalpoint/5BFS/5closure and28nativebridges; qualification nested15reference/compile/solve12decode6BFS remainsseparatelydeclared. No successfulprefixonly audit.',
 'Complementary L reviews alltraining/policy/fullproposal arithmetic/equalinventory; C reviews all28native+B certificates. This receipt binds their currentartifact references butdoesnotreplace those fullscopeadmissions. No generalGCTS/RLbenefit,fixedliteralWang,FOL/PA/Hilbert ormathematicalunprovability claim.'],
 'operations':{'subject_Project_calls':0,'scientific_replays':0,'Source_or_actual_edits':0,'network_calls':0,'allowed':'StdlibstrictJSON/gzip/fullhash/data-traversal/declared-row/field/count/incidence/value joins only.'},'once_state':'PERMANENTLY_SPENT_NO_RERUN','terminal_state':'TOOLS_TERMINAL_IDLE','audit_Source':pin(Path(__file__))}
rp=OUT/'complete-independent-saved-qualification-and-rawgraph-review-v1.json';rb=json.dumps(review,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode()+b'\n'
with rp.open('xb')as f:f.write(rb)
assert rp.read_bytes()==rb
print(json.dumps({'review':pin(rp),'support':pin(sp),'counters':summary},sort_keys=True))
