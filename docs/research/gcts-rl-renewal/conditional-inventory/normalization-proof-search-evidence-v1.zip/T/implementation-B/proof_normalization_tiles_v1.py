"""Three finite GIVEN/MP point-family compilations; no proof search or hints.

The injected, separately authenticated S compiler supplies the complete original
universe. This module adds PADDING aliases and optional literal normalization
marks. Decoding is representation-only and never certifies a proof.
"""
import json
import math
import time

VERSION = 'T-PROOF-NORMALIZATION-TILES-v1'
SCHEMA = 'T-finite-normalization-proof-model-v1'
REFERENCE_VERSION = 'S-STRUCTURAL-PROOF-TILES-v2'
LANES = ('S_REFERENCE', 'EXPANDED_OFF', 'EXPANDED_ON')
LAYERS = ('phase', 'hypothesis_order', 'unique_real_formula', 'padding_use')
BUNDLE_FIELDS = ('schema', 'version', 'lane', 'reference_version', 'hypotheses',
                 'goal', 'slots', 'formula_catalog', 'model', 'steps',
                 'compilation', 'normalization', 'scope')


class InputError(Exception):
    pass


class BudgetExceeded(Exception):
    pass


def _fields(value, names):
    if type(value) is not dict or len(value) != len(names) or set(value) != set(names):
        raise InputError('exact field set')


class _Budget:
    def __init__(self, limits):
        self.start = time.perf_counter()
        _fields(limits, ('wall_seconds', 'max_candidates', 'max_work', 'max_depth'))
        wall = limits['wall_seconds']
        if (type(wall) not in (int, float) or not 0 < wall <= 60
                or not math.isfinite(wall)):
            raise InputError('wall_seconds finite positive at most60')
        for name, ceiling in (('max_candidates', 10000000),
                              ('max_work', 100000000), ('max_depth', 128)):
            if type(limits[name]) is not int or not 0 <= limits[name] <= ceiling:
                raise InputError('bounded nonnegative integer ' + name)
        self.limits = dict(limits)
        self.work = 0

    def tick(self, amount=1):
        self.work += amount
        if self.work > self.limits['max_work']:
            raise BudgetExceeded('compilation work')
        elapsed = time.perf_counter() - self.start
        if elapsed >= self.limits['wall_seconds']:
            raise BudgetExceeded('inclusive wall')
        return elapsed


def _clone(value, budget, active=None, depth=0):
    """Fresh mutable JSON containers, with a conservative ASCII wire precharge."""
    budget.tick()
    if depth > budget.limits['max_depth']:
        raise BudgetExceeded('detached JSON depth')
    if type(value) is str:
        budget.tick(2 + 12 * len(value))
        return value
    if value is None or type(value) is bool:
        budget.tick(5)
        return value
    if type(value) is int:
        budget.tick(1)
        if not -1000000000 <= value <= 1000000000:
            raise InputError('bounded JSON metadata integer')
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise InputError('finite JSON metadata float')
        budget.tick(32)
        return value
    if type(value) not in (list, dict):
        raise InputError('native JSON data only')
    if active is None:
        active = set()
    identity = id(value)
    if identity in active:
        raise InputError('cyclic JSON input')
    active.add(identity)
    try:
        budget.tick(2 + 2 * len(value))
        if type(value) is list:
            return [_clone(x, budget, active, depth + 1) for x in value]
        result = {}
        for key, item in value.items():
            if type(key) is not str:
                raise InputError('native string JSON key')
            _clone(key, budget, active, depth + 1)
            result[key] = _clone(item, budget, active, depth + 1)
        return result
    finally:
        active.remove(identity)


def _canonical(value, budget):
    detached = _clone(value, budget)
    result = json.dumps(detached, sort_keys=True, separators=(',', ':'),
                        ensure_ascii=True, allow_nan=False)
    budget.tick(len(result))
    return result


def _reference_bundle(reference, hypotheses, goal, slots, budget):
    if (getattr(reference, 'VERSION', None) != REFERENCE_VERSION
            or not callable(getattr(reference, 'compile_problem', None))):
        raise InputError('authenticated S compiler interface required')
    copied_hypotheses = _clone(hypotheses, budget)
    copied_goal = _clone(goal, budget)
    elapsed = budget.tick()
    limits = dict(budget.limits)
    limits['wall_seconds'] -= elapsed
    limits['max_work'] = min(10000000, limits['max_work'] - budget.work)
    try:
        base = reference.compile_problem(copied_hypotheses, copied_goal,
                                         slots, limits)
    except reference.InputError as error:
        raise InputError('S reference: ' + str(error)) from error
    except reference.BudgetExceeded as error:
        raise BudgetExceeded('S reference: ' + str(error)) from error
    _fields(base, ('schema', 'version', 'hypotheses', 'goal', 'slots',
                   'formula_catalog', 'model', 'steps', 'compilation', 'scope'))
    if (base['schema'] != 'S-finite-structural-proof-model-v1'
            or base['version'] != REFERENCE_VERSION or base['slots'] != slots):
        raise InputError('S reference bundle identity')
    work = base['compilation']['work']
    if type(work) is not int or not 0 <= work <= limits['max_work']:
        raise InputError('S reference work receipt')
    budget.tick(work)
    return _clone(base, budget), work


def _put(marks, point, value, budget):
    budget.tick(1 + len(point) + len(value))
    if point in marks and marks[point] != value:
        raise InputError('internally contradictory normalization marks')
    marks[point] = value


def _augment(candidate, record, slots, ranks, formula_indices, budget):
    marks = {}
    for point, value in candidate['m']:
        _put(marks, point, value, budget)
    slot, family, line = record['slot'], record['family'], record['line']
    phase = {'PADDING': 0, 'GIVEN': 1, 'MP': 2}[family]
    real = family != 'PADDING'
    formula_index = formula_indices[_canonical(line['formula'], budget)]
    for other in range(slots):
        budget.tick()
        if other == slot:
            continue
        i, j = min(slot, other), max(slot, other)
        pair = str(i) + ':' + str(j) + ':'
        for threshold in (1, 2):
            budget.tick()
            if slot < other and phase >= threshold:
                _put(marks, 'nf:phase:' + pair + str(threshold), '1', budget)
            elif slot > other and phase < threshold:
                _put(marks, 'nf:phase:' + pair + str(threshold), '0', budget)
        if family == 'GIVEN':
            rank = ranks[line['name']]
            for threshold in range(1, len(ranks)):
                budget.tick()
                if slot < other and rank >= threshold:
                    _put(marks, 'nf:hyp:' + pair + str(threshold), '1', budget)
                elif slot > other and rank < threshold:
                    _put(marks, 'nf:hyp:' + pair + str(threshold), '0', budget)
        if real:
            _put(marks, 'nf:unique:' + pair + str(formula_index),
                 '0' if slot < other else '1', budget)
    _put(marks, 'nf:use:' + str(slot), '1' if real else '0', budget)
    if family == 'MP':
        for ref in (line['antecedent'], line['implication']):
            _put(marks, 'nf:use:' + str(ref), '1', budget)
    budget.tick(len(marks) * max(1, len(marks).bit_length()))
    return {'id': candidate['id'], 't': candidate['t'],
            'm': [[point, marks[point]] for point in sorted(marks)]}


def compile_problem(hypotheses, goal, slots, limits, *, lane, reference):
    """Compile a complete finite lane, or raise without returning a partial model."""
    budget = _Budget(limits)
    budget.tick()
    if type(lane) is not str or lane not in LANES:
        raise InputError('explicit normalization lane')
    base, reference_work = _reference_bundle(reference, hypotheses, goal,
                                              slots, budget)
    steps = {}
    for identity, record in base['steps'].items():
        budget.tick()
        family = 'GIVEN' if record['line']['rule'] == 'axiom' else 'MP'
        steps[identity] = {'slot': record['slot'], 'family': family,
                           'line': record['line']}
    candidates = base['model']['candidates']
    names = sorted(base['hypotheses'])
    padding_name = names[0] if names and lane != 'S_REFERENCE' else None
    if padding_name is not None:
        formula = base['hypotheses'][padding_name]
        output_value = _canonical(formula, budget)
        for slot in range(slots - 1):
            budget.tick()
            if len(candidates) >= budget.limits['max_candidates']:
                raise BudgetExceeded('expanded candidate universe')
            identity = 'r' + str(slot) + ':pad'
            if identity in steps:
                raise InputError('padding identity collision')
            candidates.append({'id': identity, 't': ['slot:' + str(slot)],
                               'm': [['out:' + str(slot), output_value]]})
            steps[identity] = {'slot': slot, 'family': 'PADDING',
                               'line': {'rule': 'axiom', 'name': padding_name,
                                        'formula': formula}}
    enabled = lane == 'EXPANDED_ON'
    if enabled:
        ranks = {name: rank for rank, name in enumerate(names)}
        formula_indices = {_canonical(f, budget): i
                           for i, f in enumerate(base['formula_catalog'])}
        candidates = [_augment(c, steps[c['id']], slots, ranks,
                                formula_indices, budget) for c in candidates]
    budget.tick(len(candidates))
    mark_count = 0
    for candidate in candidates:
        budget.tick()
        mark_count += len(candidate['m'])
    result = {'schema': SCHEMA, 'version': VERSION, 'lane': lane,
              'reference_version': REFERENCE_VERSION,
              'hypotheses': base['hypotheses'], 'goal': base['goal'],
              'slots': slots, 'formula_catalog': base['formula_catalog'],
              'model': {'required': base['model']['required'],
                        'candidates': candidates}, 'steps': steps,
              'compilation': {'work': 0, 'reference_work': reference_work,
                              'candidates': len(candidates),
                              'mark_assignments': mark_count, 'wall_seconds': 0,
                              'scope': 'Inclusive input copying, unchanged S '
                              'compilation, inventory, marking construction and '
                              'detached return. Cooperative work/wall/depth; '
                              'caller serialization and tail excluded.'},
              'normalization': {'enabled': enabled,
                                'layers': list(LAYERS) if enabled else [],
                                'padding_hypothesis': padding_name,
                                'proof_scope': 'Bounded proof existence only; '
                                'not preservation of every original tiling.'},
              'scope': 'Finite anchored unit point-family adaptation, all roots '
              'generation0. No solver, proof proposal, learned marking, RL, '
              'literal universal Wang palette or general FOL completeness.'}
    detached = _clone(result, budget)
    elapsed = budget.tick()
    detached['compilation']['work'] = budget.work
    detached['compilation']['wall_seconds'] = elapsed
    return detached


def decode_selected(bundle, selected, limits):
    """Decode only; a checker must independently verify the entire certificate."""
    budget = _Budget(limits)
    data = _clone(bundle, budget)
    ids = _clone(selected, budget)
    _fields(data, BUNDLE_FIELDS)
    if (data['schema'] != SCHEMA or data['version'] != VERSION
            or data['lane'] not in LANES
            or data['reference_version'] != REFERENCE_VERSION):
        raise InputError('bundle identity')
    if (type(data['slots']) is not int or not 1 <= data['slots'] <= 32
            or type(data['steps']) is not dict):
        raise InputError('bundle slots/steps')
    if type(ids) is not list or any(type(x) is not str for x in ids):
        raise InputError('selected native string IDs')
    if len(ids) != data['slots'] or len(set(ids)) != len(ids):
        raise InputError('one distinct candidate per slot')
    rows = {}
    for identity in ids:
        budget.tick()
        if identity not in data['steps']:
            raise InputError('unknown selected candidate')
        record = data['steps'][identity]
        _fields(record, ('slot', 'family', 'line'))
        slot = record['slot']
        if (type(slot) is not int or not 0 <= slot < data['slots']
                or slot in rows or record['family'] not in ('PADDING', 'GIVEN', 'MP')):
            raise InputError('selected slot/family')
        rows[slot] = record['line']
    if set(rows) != set(range(data['slots'])):
        raise InputError('missing selected slot')
    result = _clone({'status': 'UNVERIFIED_CERTIFICATE',
                     'proof': [rows[i] for i in range(data['slots'])],
                     'target': data['goal'], 'lane': data['lane']}, budget)
    budget.tick()
    return result
