"""Inert independent T universe/proof verifier and exact bounded fact-set BFS.

No project imports, IO, model/demo calls or module-body scientific execution.
"""
import collections
import itertools
import json
import math
import time

VERSION = 'T-INDEPENDENT-NORMALIZATION-v1'
LANES = ('S_REFERENCE', 'EXPANDED_OFF', 'EXPANDED_ON')
VERIFY_LIMITS = {'wall_seconds': 10, 'max_work': 100000000,
                 'max_candidates': 50000, 'max_depth': 128}
BFS_LIMITS = {'wall_seconds': 2, 'max_states': 20000,
              'max_transitions': 500000, 'max_work': 20000000}


class CheckError(Exception):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, why):
    if not ok:
        raise CheckError(why)


def _fields(x, keys):
    _need(type(x) is dict and len(x) == len(keys) and all(type(k) is str for k in x) and set(x) == set(keys), 'exact fields')


class _Budget:
    def __init__(self, limits, defaults):
        self.start = time.perf_counter()
        src = defaults if limits is None else limits
        _fields(src, defaults)
        wall = src['wall_seconds']
        _need(type(wall) in (int, float) and 0 < wall <= 60,
              'positive finite nonbool wall at most60')
        for k in src:
            if k != 'wall_seconds':
                _need(type(src[k]) is int and 0 <= src[k] <= 100000000, 'exact bounded integer cap')
        if 'max_depth' in src:
            _need(src['max_depth'] <= 128, 'depth cap at most128')
        self.limits = dict(src)
        self.work = 0

    def tick(self, amount=1):
        if self.work + amount > self.limits['max_work']:
            raise BudgetExceeded('logical work ceiling')
        if time.perf_counter() - self.start >= self.limits['wall_seconds']:
            raise BudgetExceeded('cooperative wall ceiling')
        self.work += amount

    def cap(self, size, key):
        self.tick()
        if size > self.limits[key]:
            raise BudgetExceeded(key)

    def cost(self):
        return {'work': self.work, 'seconds': time.perf_counter() - self.start,
                'scope': 'Preparation, construction and certificate checks included; '
                         'caller serialization/tail excluded. Cooperative, not an OS quota.'}


def _image(x, b):
    def weight(y, active, depth):
        b.tick()
        if depth > 144:
            raise BudgetExceeded('JSON envelope depth')
        if type(y) is str:
            b.tick(12 * len(y)); return 2 + 12 * len(y)
        if y is None or type(y) is bool:
            return 5
        if type(y) is int:
            b.tick(y.bit_length()); return 3 + y.bit_length()
        if type(y) is float:
            _need(math.isfinite(y), 'finite JSON'); return 32
        _need(type(y) in (list, dict) and id(y) not in active, 'native acyclic JSON')
        active.add(id(y)); b.tick(len(y)); n = 2
        try:
            for key, val in (enumerate(y) if type(y) is list else y.items()):
                if type(y) is dict:
                    _need(type(key) is str, 'native object key'); n += weight(key, active, depth + 1)
                n += 2 + weight(val, active, depth + 1)
        finally:
            active.remove(id(y))
        return n
    upper = weight(x, set(), 0)
    if upper > 67108864:
        raise BudgetExceeded('canonical image64MiB')
    b.tick(upper)
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


def _same(x, y, b, why):
    # Full structural streaming equality: no giant duplicate serialization buffer.
    def visit(a, c, aa, cc, depth):
        b.tick(); _need(type(a) is type(c), why)
        if depth > 144: raise BudgetExceeded('comparison envelope depth')
        if type(a) is str:
            b.tick(len(a)+len(c)); _need(a==c,why); return
        if a is None or type(a) in (bool,int,float):
            if type(a) is int: b.tick(a.bit_length()+c.bit_length())
            if type(a) is float: _need(math.isfinite(a) and math.isfinite(c),why)
            _need(a==c,why); return
        _need(type(a) in (list,dict) and len(a)==len(c)
              and id(a) not in aa and id(c) not in cc,why)
        b.tick(len(a)+len(c));aa.add(id(a));cc.add(id(c))
        try:
            if type(a) is list:
                for u,v in zip(a,c,strict=True):visit(u,v,aa,cc,depth+1)
            else:
                _need(all(type(k) is str for k in a) and all(type(k) is str for k in c),why)
                b.tick(sum(map(len,a))+sum(map(len,c)));_need(a.keys()==c.keys(),why)
                for k in a:visit(a[k],c[k],aa,cc,depth+1)
        finally:
            aa.remove(id(a));cc.remove(id(c))
    visit(x,y,set(),set(),0)


def _problem(p, b):
    _fields(p, ('hypotheses', 'goal', 'maxlines'))
    h, n = p['hypotheses'], p['maxlines']
    _need(type(h) is dict and len(h) <= 256 and type(n) is int and 1 <= n <= 32,
          'bounded named hypotheses and exact lines1..32')
    catalog = {}
    def name(s):
        _need(type(s) is str and 1 <= len(s) <= 64 and all(32 <= ord(c) <= 126 for c in s),
              'printable ASCII name1..64'); b.tick(12 * len(s))
    def formula(f, active, depth):
        b.tick()
        if depth > b.limits.get('max_depth', 128):
            raise BudgetExceeded('formula depth')
        _need(type(f) is list and len(f) == 3 and type(f[0]) is str and id(f) not in active, 'finite formula AST')
        active.add(id(f))
        try:
            if f[0] == 'pred':
                name(f[1]); _need(type(f[2]) is list and not f[2], 'zeroarity atom')
                out = ['pred', f[1], []]
            else:
                _need(f[0] == 'imp', 'only pred0/imp')
                out = ['imp', formula(f[1], active, depth + 1), formula(f[2], active, depth + 1)]
            key = _image(out, b); catalog[key] = out
            return out
        finally:
            active.remove(id(f))
    b.tick(len(h)); normal = {}
    for k in h:
        name(k)
    for k in sorted(h):
        normal[k] = formula(h[k], set(), 0)
    goal = formula(p['goal'], set(), 0)
    return {'hypotheses': normal, 'goal': goal, 'maxlines': n}, [catalog[k] for k in sorted(catalog)]


def _universe(p, catalog, lane, b):
    n = p['maxlines']; names = sorted(p['hypotheses']); rows, steps = [], {}
    wire = lambda f: _image(f, b)
    def add(i, cid, line, family, marks):
        if i == n - 1 and wire(line['formula']) != wire(p['goal']):
            return
        mm = {}
        for q, val in marks:
            if q in mm and mm[q] != val:
                return
            mm[q] = val
        b.cap(len(rows) + 1, 'max_candidates')
        rows.append({'id': cid, 't': ['slot:' + str(i)], 'm': [[q, mm[q]] for q in sorted(mm)]})
        steps[cid] = {'slot': i, 'family': family, 'line': line}
    for i in range(n):
        for j, name in enumerate(names):
            f = p['hypotheses'][name]; add(i, 'r'+str(i)+':h'+str(j),
                {'rule':'axiom','name':name,'formula':f}, 'GIVEN', [('out:'+str(i),wire(f))])
        for j, f in enumerate(catalog):
            if f[0] != 'imp':
                continue
            for a in range(i):
                for c in range(i):
                    b.tick(); add(i, 'r'+str(i)+':mp'+str(j)+':'+str(a)+':'+str(c),
                        {'rule':'mp','formula':f[2],'antecedent':a,'implication':c}, 'MP',
                        [('out:'+str(i),wire(f[2])),('out:'+str(a),wire(f[1])),('out:'+str(c),wire(f))])
    if lane != 'S_REFERENCE' and names:
        for i in range(n - 1):
            add(i, 'r'+str(i)+':pad', {'rule':'axiom','name':names[0],
                'formula':p['hypotheses'][names[0]]}, 'PADDING',
                [('out:'+str(i),wire(p['hypotheses'][names[0]]))])
    if lane == 'EXPANDED_ON':
        fi = {wire(f): j for j, f in enumerate(catalog)}
        for row in rows:
            st = steps[row['id']]; i, fam, line = st['slot'], st['family'], st['line']
            phase = {'PADDING':0,'GIVEN':1,'MP':2}[fam]; marks = dict(row['m'])
            output_index=None if fam=='PADDING' else fi[wire(line['formula'])]
            rank=names.index(line['name']) if fam=='GIVEN' else None
            def mark(q, val):
                b.tick(len(q) + 2); _need(q not in marks or marks[q] == val, 'internal new-mark consistency'); marks[q] = val
            mark('nf:use:'+str(i), '0' if fam == 'PADDING' else '1')
            if fam == 'MP':
                for ref in (line['antecedent'],line['implication']): mark('nf:use:'+str(ref),'1')
            for other in range(n):
                if other == i:
                    continue
                left, right = min(i,other), max(i,other)
                for c in (1,2):
                    if i < other and phase >= c: mark('nf:phase:'+str(left)+':'+str(right)+':'+str(c),'1')
                    if i > other and phase < c: mark('nf:phase:'+str(left)+':'+str(right)+':'+str(c),'0')
                if fam == 'GIVEN':
                    for c in range(1,len(names)):
                        if i < other and rank >= c: mark('nf:hyp:'+str(left)+':'+str(right)+':'+str(c),'1')
                        if i > other and rank < c: mark('nf:hyp:'+str(left)+':'+str(right)+':'+str(c),'0')
                if fam != 'PADDING':
                    mark('nf:unique:'+str(left)+':'+str(right)+':'+str(output_index), '0' if i < other else '1')
            row['m'] = [[q,marks[q]] for q in sorted(marks)]
    return {'required':['slot:'+str(i) for i in range(n)],'candidates':rows}, steps


def _bundle(problem, bundle, b):
    p, cat = _problem(problem,b)
    _fields(bundle, ('schema','version','lane','reference_version','hypotheses','goal','slots',
        'formula_catalog','model','steps','compilation','normalization','scope'))
    lane = bundle['lane']; _need(lane in LANES and bundle['version']=='T-PROOF-NORMALIZATION-TILES-v1'
        and bundle['schema']=='T-finite-normalization-proof-model-v1'
        and bundle['reference_version']=='S-STRUCTURAL-PROOF-TILES-v2','current bundle identity')
    model, steps = _universe(p,cat,lane,b)
    _same(bundle['hypotheses'],p['hypotheses'],b,'all hypotheses'); _same(bundle['goal'],p['goal'],b,'goal')
    _need(type(bundle['slots']) is int and bundle['slots']==p['maxlines'],'exact slots')
    _same(bundle['formula_catalog'],cat,b,'entire catalogue'); _same(bundle['model'],model,b,'entire t/m universe')
    _same(bundle['steps'],steps,b,'all tagged step records')
    meta = bundle['normalization']; _fields(meta, ('enabled','layers','padding_hypothesis','proof_scope'))
    _need(meta['enabled'] is (lane=='EXPANDED_ON'),'normalization enabled')
    _same(meta['layers'],['phase','hypothesis_order','unique_real_formula','padding_use'] if lane=='EXPANDED_ON' else [],b,'exact active layers')
    _same(meta['padding_hypothesis'],next(iter(p['hypotheses']),None) if lane!='S_REFERENCE' else None,b,'fixed padding hypothesis')
    costs=bundle['compilation'];_fields(costs,('work','reference_work','candidates','mark_assignments','wall_seconds','scope'))
    _need(all(type(costs[k]) is int and costs[k]>=0 for k in ('work','reference_work','candidates','mark_assignments')),'typed costs')
    _need(costs['candidates']==len(model['candidates']) and costs['mark_assignments']==sum(len(c['m']) for c in model['candidates']),'actual complete counts')
    _need((type(costs['wall_seconds']) is int or type(costs['wall_seconds']) is float and math.isfinite(costs['wall_seconds'])) and costs['wall_seconds']>=0
          and all(type(x) is str for x in (bundle['scope'],costs['scope'],meta['proof_scope'])),'typed scope/clock')
    return p,model,steps


def _flat(p, lines, b):
    known=[]
    for i,line in enumerate(lines):
        b.tick()
        if line['rule']=='axiom':
            _fields(line,('rule','name','formula')); _need(line['name'] in p['hypotheses'],'named GIVEN')
            _same(line['formula'],p['hypotheses'][line['name']],b,'exact GIVEN')
        else:
            _fields(line,('rule','formula','antecedent','implication'));a,c=line['antecedent'],line['implication']
            _need(line['rule']=='mp' and type(a) is int and type(c) is int and 0<=a<i and 0<=c<i,'earlier MP refs')
            _same(known[c],['imp',known[a],line['formula']],b,'exact MP')
        known.append(line['formula'])
    _need(0<len(lines)<=p['maxlines'],'proof line bound'); _same(known[-1],p['goal'],b,'last goal')


def _selected(p, model, steps, ids, b):
    byid={c['id']:c for c in model['candidates']}
    _need(type(ids) is list and all(type(i) is str for i in ids) and len(ids)==len(set(ids))==p['maxlines'],'unique whole selection')
    totals={q:0 for q in model['required']}; marks={}; lines={}
    for cid in ids:
        b.tick(); _need(cid in byid,'current candidate'); c=byid[cid]; totals[c['t'][0]]+=1
        for q,val in c['m']:
            b.tick(); _need(q not in marks or marks[q]==val,'actual global literal m equality'); marks[q]=val
        lines[steps[cid]['slot']]=steps[cid]['line']
    _need(all(t==1 for t in totals.values()) and len(lines)==p['maxlines'],'whole unit t target')
    flat=[lines[i] for i in range(p['maxlines'])]; _flat(p,flat,b)
    return flat


def _verify(problem,bundle,selected,limits):
    b=None
    try:
        b=_Budget(limits,VERIFY_LIMITS); p,model,steps=_bundle(problem,bundle,b)
        flat=None if selected is None else _selected(p,model,steps,selected,b);b.tick()
        return {'status':'VERIFIED','version':VERSION,'proof':flat,'candidates':len(model['candidates']),'costs':b.cost(),'reason':None}
    except (CheckError,BudgetExceeded) as e:
        return {'status':'UNKNOWN' if isinstance(e,BudgetExceeded) else 'REJECTED','version':VERSION,
                'proof':None,'candidates':None,'costs':None if b is None else b.cost(),'reason':str(e)}


def verify_bundle(problem,bundle,*,limits=None):
    return _verify(problem,bundle,None,limits)


def verify_selection(problem,bundle,selected,*,limits=None):
    if selected is None:
        return {'status':'REJECTED','version':VERSION,'proof':None,'candidates':None,'costs':None,'reason':'selection required'}
    return _verify(problem,bundle,selected,limits)


def bounded_bfs(problem,limits=None):
    b=None; visits=arcs=0
    try:
        b=_Budget(limits,BFS_LIMITS); p,cat=_problem(problem,b)
        keys=[_image(f,b) for f in cat]; index={s:i for i,s in enumerate(keys)}
        givens=[(index[_image(f,b)],name) for name,f in p['hypotheses'].items()]
        rules=[(index[_image(f[1],b)],i,index[_image(f[2],b)]) for i,f in enumerate(cat) if f[0]=='imp']
        goal=index[_image(p['goal'],b)]; b.cap(1,'max_states')
        parents={0:None}; queue=collections.deque([(0,0)]);found=None
        while queue and found is None:
            mask,depth=queue.popleft();visits+=1;b.tick()
            if depth==p['maxlines']:
                continue
            options=[]
            for f,name in givens:
                b.tick()
                if not mask>>f&1: options.append((f,('GIVEN',name)))
            for a,i,c in rules:
                b.tick()
                if mask>>a&1 and mask>>i&1 and not mask>>c&1:options.append((c,('MP',a,i)))
            b.tick(len(options))
            for f,why in options:
                b.cap(arcs+1,'max_transitions');arcs+=1;new=mask|(1<<f)
                if new in parents:
                    continue
                b.cap(len(parents)+1,'max_states');b.tick()
                parents[new]=(mask,f,why);queue.append((new,depth+1))
                if f==goal:
                    found=new;break
        lines=None
        if found is not None:
            path=[];cur=found
            while cur:
                b.tick();prev,f,why=parents[cur];path.append((f,why));cur=prev
            lines=[];refs={}
            for f,why in reversed(path):
                b.tick()
                line={'rule':'axiom','name':why[1],'formula':cat[f]} if why[0]=='GIVEN' else {
                    'rule':'mp','antecedent':refs[why[1]],'implication':refs[why[2]],'formula':cat[f]}
                refs[f]=len(lines);lines.append(line)
            _flat(p,lines,b)
        b.tick()
        return {'schema':'T-exact-bounded-fact-set-BFS-v1','status':'DERIVABLE' if lines is not None else 'NOT_DERIVABLE',
            'proof':lines,'shortest_lines':None if lines is None else len(lines),'counts':{'states':len(parents),'expanded':visits,'transitions':arcs},
            'costs':b.cost(),'reason':None,'scope':'Exact bounded GIVEN/MP distinct-fact BFS from EMPTY set. Every new GIVEN/MP fact costs1line; hypotheses are not free. Shortest proof or complete bounded exhaustion. No tile/RL attribution.'}
    except (CheckError,BudgetExceeded) as e:
        return {'schema':'T-exact-bounded-fact-set-BFS-v1','status':'UNKNOWN' if isinstance(e,BudgetExceeded) else 'REJECTED',
            'proof':None,'shortest_lines':None,'counts':{'expanded':visits,'transitions':arcs},
            'costs':None if b is None else b.cost(),'reason':str(e),'scope':'No partial negative or admitted certificate on refusal.'}


def _brute(model, b):
    roots=model['required']; choices={p:[] for p in roots}
    for row in model['candidates']: choices[row['t'][0]].append(row)
    count=1
    for p in roots:
        count*=len(choices[p])
        if count>10000: raise BudgetExceeded('tiny assignment product10000')
    solutions=[]
    for rows in itertools.product(*(choices[p] for p in roots)):
        b.tick(); marks={};ok=True
        for row in rows:
            for q,v in row['m']:
                b.tick()
                if q in marks and marks[q]!=v: ok=False;break
                marks[q]=v
            if not ok:break
        if ok: solutions.append(sorted(row['id'] for row in rows))
    return {'status':'COMPLETE','assignments':count,'solutions':solutions}


def qualify(normalizer,reference,engine,emit=None):
    """Five tiny inputs, three exact lanes, no authoring-time execution."""
    _need(emit is None or callable(emit),'optional full-record emitter')
    caps=dict(VERIFY_LIMITS);caps['wall_seconds']=15;b=_Budget(caps,VERIFY_LIMITS)
    p,q=['pred','P',[]],['pred','Q',[]]
    problems=[('given-one',{'hypotheses':{'a':p,'b':q},'goal':p,'maxlines':1}),
              ('given-Q-three',{'hypotheses':{'a':p,'b':q},'goal':q,'maxlines':3}),
              ('given-P-three',{'hypotheses':{'a':p,'b':q},'goal':p,'maxlines':3}),
              ('derived-three',{'hypotheses':{'a':p,'b':['imp',p,q]},'goal':q,'maxlines':3}),
              ('derived-two',{'hypotheses':{'a':p,'b':['imp',p,q]},'goal':q,'maxlines':2})]
    cl={'wall_seconds':2,'max_candidates':50000,'max_work':100000000,'max_depth':128}
    sl={'wall_seconds':2,'max_nodes':5000,'max_events':64}
    records=[];counts={'compile':0,'solve':0,'decode':0,'BFS':0};kept={}
    for name,problem in problems:
        truth=[]
        for lane in LANES:
            b.tick();bundle=normalizer.compile_problem(problem['hypotheses'],problem['goal'],problem['maxlines'],cl,lane=lane,reference=reference);counts['compile']+=1
            audit=verify_bundle(problem,bundle);_need(audit['status']=='VERIFIED','complete independent normalization universe')
            exhaustive=_brute(bundle['model'],b)
            result=engine.solve(bundle['model'],sl);counts['solve']+=1
            _need(result['status']==('SAT' if exhaustive['solutions'] else 'UNSAT'),'tiny full point truth')
            selected=None;decoded=None
            if result['status']=='SAT':
                _need(result['selected'] in exhaustive['solutions'],'actual full tiny witness member')
                selected=verify_selection(problem,bundle,result['selected']);_need(selected['status']=='VERIFIED','full selected proof/marks')
                decoded=normalizer.decode_selected(bundle,result['selected'],cl);counts['decode']+=1
                _same(decoded,{'status':'UNVERIFIED_CERTIFICATE','proof':selected['proof'],'target':problem['goal'],'lane':lane},b,'actual decoder full fields')
            else:_need(result['selected'] is None and result['certificate'] is None,'tiny no false UNSAT witness')
            truth.append(bool(exhaustive['solutions']));kept[(name,lane)]=bundle
            record={'id':name+'-'+lane.replace('_','-'),'problem':problem,'lane':lane,'bundle':bundle,'result':result,'independent_universe':audit,'independent_selected':selected,'decoded':decoded,'exhaustive':exhaustive}
            records.append(record)
        _need(len(set(truth))==1,'old/off/on existence equivalence, not tiling identity')
        search=bounded_bfs(problem);counts['BFS']+=1
        _need(search['status']==('DERIVABLE' if truth[0] else 'NOT_DERIVABLE'),'exact bounded BFS equivalence')
        if truth[0]:_need(search['shortest_lines']==(3 if name=='derived-three' else 1),'GIVEN costs1 and MP new facts cost1')
        records[-1]['bounded_BFS']=search
    controls=[]
    selections=[('phase','given-Q-three',['r0:h0','r1:pad','r2:h1']),
                ('name-order','given-P-three',['r0:pad','r1:h1','r2:h0']),
                ('real-duplicate','given-Q-three',['r0:h0','r1:h0','r2:h1'])]
    derived=kept[('derived-three','EXPANDED_ON')]
    mp=next(cid for cid,st in derived['steps'].items() if st['slot']==2 and st['family']=='MP' and st['line']['antecedent']==0 and st['line']['implication']==1)
    selections.append(('PAD-reference','derived-three',['r0:pad','r1:h1',mp]))
    for kind,name,ids in selections:
        problem=next(pr for nm,pr in problems if nm==name)
        off=verify_selection(problem,kept[(name,'EXPANDED_OFF')],ids)
        on=verify_selection(problem,kept[(name,'EXPANDED_ON')],ids)
        _need(off['status']=='VERIFIED' and on['status']=='REJECTED','isolated actual m-normalization counterexample')
        controls.append({'kind':kind,'problem_id':name,'selected':ids,'OFF':off,'ON':on})
    forged=json.loads(_image(derived,b));victim=forged['model']['candidates'][0]
    victim['m'].pop(next(i for i,row in enumerate(victim['m']) if row[0].startswith('nf:')))
    rejected=verify_bundle(next(pr for nm,pr in problems if nm=='derived-three'),forged)
    _need(rejected['status']=='REJECTED','missing literal cannot claim full normalized universe')
    records[-1]['data_only_controls']=controls
    records[-1]['missing_mark_control']={'forged_bundle':forged,'independent_rejection':rejected}
    stopcaps=dict(BFS_LIMITS);stopcaps['max_states']=0
    stopped=bounded_bfs(problems[-1][1],stopcaps);counts['BFS']+=1
    _need(stopped['status']=='UNKNOWN' and stopped['proof'] is None,'zero state cap is UNKNOWN not bounded negative')
    records[-1]['BFS_budget_control']=stopped
    calls=[]
    for record in records:
        b.tick();calls.append({'id':record['id'],'reference':record if emit is None else emit(record['id'],record)})
    _need(counts=={'compile':15,'solve':15,'decode':12,'BFS':6},'closed tiny qualification call census')
    b.tick()
    return {'status':'PASS','version':VERSION,'records':calls,'counts':counts,'costs':b.cost(),
            'scope':'Complete tiny old/off/on existence checks and actual literal-layer/flat-proof negatives. No subject call occurred before a fresh Root execution authority.'}
