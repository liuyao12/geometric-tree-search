"""Closed T worker and owned observer. Inert until a fresh exact once grant.

Only pinned retained Source bytes execute. All outcomes and complete proof
checks are retained. The supervisor owns one child, its streams and wait4;
timeouts/refusals never become mathematical negatives. No network or Git.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time
import types

ROOT = Path('/private/tmp/gcts-proof-normalization-20261028-v1')
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
ROLES = {'runner', 'reference', 'normalizer', 'engine', 'independent', 'state_audit',
         'clusters', 'tree_machine', 'codec', 'carrier', 'fol_checker', 'real_parser'}


def require(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def raw_json(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def raw_ref(path, raw):
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def read_ref(ref, maximum=1048576):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'raw ref')
    path = Path(ref['path'])
    require(path.is_absolute() and not path.is_symlink(), 'regular absolute path')
    require(type(ref['bytes']) is int and 0 <= ref['bytes'] <= maximum, 'raw length bound')
    with path.open('rb') as f:
        data = f.read(ref['bytes'] + 1)
    require(raw_ref(path, data) == ref, 'whole raw association')
    return data


def put(path, raw):
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    require(path.read_bytes() == raw, 'whole written bytes')
    return raw_ref(path, raw)


def check_authority(raw, plan_path, plan_raw, plan):
    authority = json.loads(raw)
    expected = {'schema': 'T-normalization-proof-once-authority-v1', 'uses': 1,
                'authorized': True, 'plan': raw_ref(plan_path, plan_raw),
                'runner': plan['sources']['runner'], 'python': plan['python']}
    require(type(authority) is dict and len(authority) == 6
            and type(authority.get('uses')) is int
            and type(authority.get('authorized')) is bool
            and authority == expected, 'exact typed Root once')
    return expected


def load_plan(path):
    raw = Path(path).read_bytes()
    plan = json.loads(raw)
    require(set(plan) == {'schema', 'sources', 'metadata', 'python', 'bootstrap',
                          'actual_dir', 'limits'}, 'exact plan')
    require(plan['schema'] == 'T-normalization-proof-once-plan-v1', 'plan schema')
    require(set(plan['sources']) == ROLES, 'closed Source roles')
    require(Path(plan['actual_dir']) == ROOT / 'actual' / 'study-001', 'owned output')
    require(plan['sources']['runner']['path'] == __file__, 'runner location')
    require(sys.executable == PYTHON and sys.flags.isolated and sys.flags.no_site
            and sys.dont_write_bytecode, 'isolated D90')
    require(plan['limits'] == {'worker_seconds': 210, 'observer_seconds': 240,
            'rss_bytes': 1073741824, 'file_bytes': 33554432,
            'total_bytes': 536870912, 'max_files': 384,
            'stream_bytes': 1048576}, 'fixed process and artifact profile')
    retained = {k: read_ref(v) for k, v in plan['sources'].items()}
    metadata = {k: read_ref(v) for k, v in plan['metadata'].items()}
    read_ref(plan['python'], 33554432)
    read_ref(plan['bootstrap'])
    return plan, raw, retained, metadata


def worker(plan_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    directory = Path(plan['actual_dir'])
    marker_path = directory / 'CONSUMED.json'
    marker_raw = marker_path.read_bytes()
    marker = json.loads(marker_raw)
    authority_raw = read_ref(marker['authority'])
    check_authority(authority_raw, plan_path, plan_raw, plan)
    consume_raw = read_ref(marker['consumed'])
    require(json.loads(consume_raw) == {'authority': marker['authority'],
            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'}, 'worker once joins')
    artifacts, total_bytes, calls = [], 0, {}

    def budget():
        require(time.perf_counter() - started < 210, 'whole worker sampled wall')
        require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss <= 1073741824,
                'whole worker sampled RSS bytes on Darwin')

    def emit(name, data):
        nonlocal total_bytes
        budget()
        if type(name) is str:
            name = name.replace('_', '-')
        require(type(name) is str and name and all(c.isalnum() or c in '-.'
                for c in name) and name.isascii(), 'artifact name')
        require(len(artifacts) < 376, 'artifact count')
        raw = raw_json(data)
        require(len(raw) <= 33554432, 'full artifact raw cap')
        compressed = len(raw) > 65536
        stored = gzip.compress(raw, mtime=0) if compressed else raw
        total_bytes += len(stored)
        require(len(stored) <= 33554432 and total_bytes <= 503316480,
                'whole artifact stored cap')
        ref = put(directory / (name + ('.json.gz' if compressed else '.json')), stored)
        require((gzip.decompress(stored) if compressed else stored) == raw,
                'lossless complete artifact')
        answer = {'name': name, 'stored': ref, 'encoding': 'gzip-json' if compressed else 'json',
                  'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}
        artifacts.append(answer)
        return answer

    modules = {}
    for role in sorted(ROLES - {'runner', 'real_parser'}):
        budget()
        module = types.ModuleType('T_' + role)
        module.__file__ = plan['sources'][role]['path']
        exec(compile(sources[role], module.__file__, 'exec', dont_inherit=True), module.__dict__)
        modules[role] = module

    def call(role, name, *args, **kwargs):
        budget()
        key = role + '.' + name
        calls[key] = calls.get(key, 0) + 1
        require(calls[key] <= 512, 'public outer entry cap')
        value = getattr(modules[role], name)(*args, **kwargs)
        budget()
        return value

    limits = json.loads(metadata['experiment_limits'])
    cases = json.loads(metadata['cases'])
    design = json.loads(metadata['benchmark_design'])
    seeds = json.loads(metadata['seeds'])
    require(set(cases) == set(design['split']['train'] + design['split']['eval']), 'complete frozen split')
    require(not set(design['split']['train']).intersection(design['split']['eval']), 'disjoint case IDs')
    tm = modules['tree_machine']
    cold = time.perf_counter()
    program = call('tree_machine', 'Compiler', sources['real_parser'].decode('utf-8')).declaration()
    call('tree_machine', 'validate', program)
    emit('fixed-native-program', program)
    native_preparation_seconds = time.perf_counter() - cold
    qualification = call('independent', 'qualify', modules['normalizer'], modules['reference'],
                         modules['engine'], lambda name, data: emit('qualification-' + name, data))
    emit('whole-qualification', qualification)
    require(qualification['status'] == 'PASS', 'complete qualification gate')

    def checked_proof(case_id, lane, problem, proof):
        t = time.perf_counter()
        atoms = set()
        def collect(f):
            if f[0] == 'pred':
                atoms.add(f[1])
            else:
                collect(f[1]); collect(f[2])
        for f in list(problem['hypotheses'].values()) + [problem['goal']]:
            collect(f)
        theory = {'functions': {}, 'predicates': {a: 0 for a in sorted(atoms)},
                  'axioms': problem['hypotheses']}
        encode = call('codec', 'encode', proof, limits['codec'])
        require(encode['status'] == 'COMPLETE', 'proof codec encode')
        stream = bytes.fromhex(encode['stream_hex'])
        decode = call('codec', 'decode', stream, limits['codec'])
        require(decode['status'] == 'COMPLETE' and decode['proof'] == proof,
                'exact independent byte roundtrip')
        carrier = call('carrier', 'build_carrier', program, dict(theory, schemas=[]),
                       problem['goal'], len(stream), limits['carrier'], budget=budget)
        nodes = [list(n) for n in carrier['value']['nodes']]
        for row in carrier['value']['byte_rows']:
            nodes[row['node_index']][0] = stream[row['byte_index']]
        choice = call('carrier', 'verify_carrier_choice', carrier, nodes,
                      carrier['value']['input_node'], budget=budget)
        require(choice['status'] == 'VERIFIED' and choice['byte_values'] == list(stream),
                'whole chosen byte carrier')
        heap = call('tree_machine', 'Heap', nodes, limit=limits['native']['max_heap_nodes'])
        native = call('tree_machine', 'run', program, heap, carrier['value']['input_node'],
                      limit=limits['native']['max_steps'], keep=limits['native']['max_trace_records'])
        independent = call('fol_checker', 'check', theory, decode['proof'],
                           problem['goal'], limits['checker'])
        accepted = (native.get('status') == 'accepted' and type(native.get('value')) is int
                    and native['value'] == 1 and independent['status'] == 'VERIFIED')
        record = {'status': 'VERIFIED' if accepted else 'UNADMITTED_CHECKER_OUTCOME',
                  'theory': theory, 'goal': problem['goal'], 'proof': proof,
                  'encoding': encode, 'decoding': decode, 'carrier': carrier,
                  'initial_nodes': nodes, 'choice': choice, 'native': native,
                  'final_heap': heap.nodes, 'independent': independent,
                  'seconds': time.perf_counter() - t}
        emit(case_id + '-' + lane + '-whole-proof-check', record)
        require(accepted, 'all accepted proofs independently checked')
        return {'status': record['status'], 'seconds': record['seconds'],
                'proof_lines': len(proof), 'proof_bytes': len(stream),
                'native_steps': native.get('steps'), 'independent': independent}

    mining_started = time.perf_counter()
    library = call('clusters', 'mine_families', seeds['proofs'])
    require(library['status'] == 'COMPLETE', 'complete bounded family mining')
    emit('mined-cluster-library', library)
    mining_seconds = time.perf_counter() - mining_started
    policy = call('clusters', 'new_policy', limits['policy_seed'])
    emit('initial-policy', policy)

    def point_run(identity, problem, lane, weights_policy, episode_seed, wall):
        t = time.perf_counter()
        result = {'lane': lane, 'status': 'UNKNOWN_COMPILATION', 'proof': None}
        bundle = answer = proposal = trace = None
        mode = lane if lane in ('S_REFERENCE', 'EXPANDED_OFF') else 'EXPANDED_ON'
        try:
            bundle = call('normalizer', 'compile_problem', problem['hypotheses'],
                          problem['goal'], problem['maxlines'],
                          dict(limits['compilation'], wall_seconds=wall),
                          lane=mode, reference=modules['reference'])
            order = None
            if lane.startswith('ON_CLUSTER'):
                remaining = wall - (time.perf_counter() - t)
                if remaining > 0:
                    proposal = call('clusters', 'instantiate', library, bundle,
                                    wall_seconds=remaining, max_instances=limits['max_instances'])
                    order, trace = call('clusters', 'make_order', proposal, weights_policy,
                                        episode_seed)
            remaining = wall - (time.perf_counter() - t)
            if remaining > 0:
                answer = call('engine', 'solve', bundle['model'],
                              dict(limits['point'], wall_seconds=remaining), order=order)
                result.update(status=answer['status'], stats=answer['stats'], reason=answer['reason'])
            else:
                result['reason'] = 'inclusive compilation/proposal wall'
        except (modules['normalizer'].BudgetExceeded, modules['reference'].BudgetExceeded) as error:
            result['reason'] = str(error)
        result['search_seconds_inclusive'] = time.perf_counter() - t
        audit_started = time.perf_counter()
        if bundle is not None:
            result['bundle'] = emit(identity + '-' + lane + '-complete-model', bundle)
            audited = call('independent', 'verify_bundle', problem, bundle,
                           limits=limits['independent'])
            require(audited['status'] == 'VERIFIED', 'complete independently reconstructed universe')
            emit(identity + '-' + lane + '-universe-audit', audited)
            result['candidates'] = len(bundle['model']['candidates'])
            result['mark_assignments'] = sum(len(c['m']) for c in bundle['model']['candidates'])
        if lane.startswith('ON_CLUSTER') and trace is None:
            _, trace = call('clusters', 'make_order', None, weights_policy, episode_seed)
        if proposal is not None:
            result['proposal'] = emit(identity + '-' + lane + '-complete-proposal', proposal)
            result['proposal_summary'] = {k: proposal[k] for k in
                ('status', 'inventory_sha256', 'truncated', 'costs')}
            result['proposal_summary']['instances'] = len(proposal['instances'])
        if trace is not None:
            result['policy_trace'] = emit(identity + '-' + lane + '-policy-trace', trace)
            result['policy_summary'] = {'calls': trace['calls'], 'complete': trace['complete'],
                'recorded_decisions': len(trace['decisions']),
                'distinct_projected_choice_calls': sum(len(set(d['projected_ids'])) >= 2
                    for d in trace['decisions']),
                'multiple_instance_calls': sum(len(d['eligible']) >= 2 for d in trace['decisions'])}
        if answer is not None:
            result['solve'] = emit(identity + '-' + lane + '-complete-solve', answer)
            meter = modules['state_audit']._Meter(limits['state_audit'], None)
            raw_audit = modules['state_audit']._native_result(bundle['model'], answer, meter)
            emit(identity + '-' + lane + '-state-audit', {'status': 'VERIFIED',
                'certificate': raw_audit, 'costs': meter.costs(),
                'scope': 'All supplied state graphs/hash associations, retained events and rollback records. '
                         'Clipped event prefix is not an independent exhaustion proof; UNKNOWN may lack final observation.'})
            if answer['status'] == 'SAT':
                verified = call('independent', 'verify_selection', problem, bundle,
                                answer['selected'], limits=limits['independent'])
                require(verified['status'] == 'VERIFIED', 'independent whole tiling and flat proof')
                emit(identity + '-' + lane + '-selection-audit', verified)
                decoded = call('normalizer', 'decode_selected', bundle, answer['selected'],
                               dict(limits['compilation'], wall_seconds=10))
                require(decoded['proof'] == verified['proof'], 'independent native proof agreement')
                result['proof'] = decoded['proof']
                result['selected'] = answer['selected']
        result['audit_and_storage_seconds'] = time.perf_counter() - audit_started
        if result['proof'] is not None:
            result['checking'] = checked_proof(identity, lane, problem, result['proof'])
        return result, trace

    training_started = time.perf_counter()
    training = []
    for epoch in range(limits['training_passes']):
        for name in design['split']['train']:
            identity = 'train-' + str(epoch) + '-' + name
            result, trace = point_run(identity, cases[name], 'ON_CLUSTER_RL', policy,
                                      limits['policy_seed'] + len(training), limits['train_wall_seconds'])
            reward = 1.0 if result.get('checking', {}).get('status') == 'VERIFIED' else -1.0
            update = call('clusters', 'update_policy', policy, trace, reward,
                          learning_rate=limits['learning_rate'])
            row = {'id': identity, 'case': name, 'result': result, 'reward': reward, 'update': update}
            emit(identity + '-episode', row)
            training.append(row)
    training_seconds = time.perf_counter() - training_started
    frozen = json.loads(raw_json(policy))
    emit('frozen-learned-policy', frozen)
    untrained = call('clusters', 'new_policy', limits['policy_seed'])
    output = []
    lane_names = ['S_REFERENCE', 'EXPANDED_OFF', 'EXPANDED_ON', 'ON_CLUSTER_RANDOM', 'ON_CLUSTER_RL']
    for case_index, name in enumerate(design['split']['eval']):
        problem = cases[name]
        lanes = {}
        offset = case_index % len(lane_names)
        execution_order = lane_names[offset:] + lane_names[:offset]
        for lane_index, lane in enumerate(execution_order):
            lane_policy = frozen if lane == 'ON_CLUSTER_RL' else untrained
            result, _ = point_run('eval-' + name, problem, lane, lane_policy,
                                  limits['evaluation_seed'] + case_index,
                                  limits['lane_wall_seconds'])
            lanes[lane] = result
        require(policy == frozen, 'evaluation must not train or mutate learned policy')
        control_started = time.perf_counter()
        control = call('independent', 'bounded_bfs', problem,
                       dict(limits['bfs'], wall_seconds=limits['lane_wall_seconds']))
        control['search_seconds_inclusive'] = time.perf_counter() - control_started
        if control.get('proof') is not None:
            require(len(control['proof']) <= problem['maxlines'], 'same proof bound')
            control['checking'] = checked_proof('eval-' + name, 'BFS', problem, control['proof'])
        emit('eval-' + name + '-BFS', control)
        closure_started = time.perf_counter()
        closure = call('state_audit', 'mp_closure', problem,
                       wall_seconds=limits['lane_wall_seconds'])
        closure['search_seconds_inclusive'] = time.perf_counter() - closure_started
        if closure.get('proof') is not None:
            closure['checking'] = checked_proof('eval-' + name, 'CLOSURE', problem, closure['proof'])
        emit('eval-' + name + '-CLOSURE', closure)
        proposal_summaries = [lanes[l].get('proposal_summary', {})
                              for l in ('ON_CLUSTER_RANDOM', 'ON_CLUSTER_RL')]
        same_inventory = (all(p.get('status') == 'COMPLETE' for p in proposal_summaries)
                          and proposal_summaries[0]['inventory_sha256'] ==
                              proposal_summaries[1]['inventory_sha256'])
        row = {'id': name, 'problem': problem, 'execution_order': execution_order,
               'policy_comparison_equal_inventory': same_inventory,
               'lanes': lanes, 'BFS': control, 'closure': closure}
        emit('eval-' + name + '-result', row)
        output.append(row)
    result = {'schema': 'T-normalization-and-cluster-policy-study-v1', 'results': output,
              'training': training, 'frozen_policy': frozen, 'library': library,
              'qualification': qualification, 'native_preparation_seconds': native_preparation_seconds,
              'mining_seconds': mining_seconds, 'training_seconds': training_seconds,
              'seed_acquisition': {k: seeds[k] for k in ('origin', 'seed_cohort_search_seconds',
                                                        'seed_cohort_check_seconds')},
              'outer_public_calls': calls, 'artifacts': list(artifacts),
              'scope': 'Finite GIVEN/MP proof search. Normalization preserves bounded proof existence, '
                       'not individual tilings. Cluster-derived ordering with complete base fallback; '
                       'no transactional macro. RL is a bounded pilot, frozen before evaluation. '
                       'All successes require actual native C1 and independent B. '
                       'Search includes compilation/proposals; audit, storage, checking, mining, '
                       'training and inherited seed acquisition are separately retained costs. '
                       'Not a fixed finite Wang palette, full FOL/PA/Hilbert or superiority claim.'}
    result_ref = emit('worker-result', result)
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'post plan guard')
    require(marker_path.read_bytes() == marker_raw, 'post marker guard')
    require(read_ref(marker['authority']) == authority_raw, 'post authority guard')
    require(read_ref(marker['consumed']) == consume_raw, 'post consumed guard')
    budget()
    sys.stdout.buffer.write(raw_json({'status': 'COMPLETE', 'result': result_ref,
        'plan': raw_ref(plan_path, plan_raw), 'public_calls': calls,
        'elapsed_seconds': time.perf_counter() - started,
        'self_lifetime_peak_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}))
    sys.stdout.buffer.flush()
    return 0


def observer(plan_path, authority_path):
    started = time.perf_counter()
    plan, plan_raw, sources, metadata = load_plan(plan_path)
    authority_raw = Path(authority_path).read_bytes()
    check_authority(authority_raw, plan_path, plan_raw, plan)
    directory = Path(plan['actual_dir'])
    require(not directory.exists() and not directory.is_symlink(), 'fresh output directory')
    consumed = Path(str(authority_path) + '.CONSUMED.json')
    consume_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                            'plan': raw_ref(plan_path, plan_raw), 'status': 'SPENT'})
    put(consumed, consume_raw)
    directory.mkdir(parents=True)
    marker_raw = raw_json({'authority': raw_ref(authority_path, authority_raw),
                           'consumed': raw_ref(consumed, consume_raw)})
    put(directory / 'CONSUMED.json', marker_raw)
    command = [PYTHON, '-I', '-S', '-B', plan['bootstrap']['path'],
               plan['sources']['runner']['path'], str(len(sources['runner'])),
               plan['sources']['runner']['sha256'], '--mode', 'worker', '--plan', str(plan_path)]
    captured = {'stdout': bytearray(), 'stderr': bytearray()}
    observed_bytes = {'stdout': 0, 'stderr': 0}
    eof = {'stdout': False, 'stderr': False}
    child = selector = None
    wait_status = usage = None
    failure = cleanup_deadline = None
    cleanup_errors = []
    sent = 0
    group_gone = False

    def kill_owned():
        if child is not None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as error:
                cleanup_errors.append({'stage': 'killpg', 'type': type(error).__name__,
                                       'errno': error.errno})

    def fault(reason):
        nonlocal failure, cleanup_deadline
        if failure is None:
            failure = reason
            cleanup_deadline = time.perf_counter() + 5
            kill_owned()

    def observe_wait_and_group():
        nonlocal wait_status, usage, group_gone
        if child is None:
            return
        if wait_status is None:
            pid, status, ru = os.wait4(child.pid, os.WNOHANG)
            if pid:
                wait_status, usage = status, ru
                child.returncode = os.waitstatus_to_exitcode(status)
        if wait_status is not None:
            try:
                os.killpg(child.pid, 0)
                group_gone = False
            except ProcessLookupError:
                group_gone = True

    def pump_events():
        nonlocal sent
        for key, _ in selector.select(timeout=0.05):
            if key.data == 'stdin':
                if failure is not None:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    continue
                try:
                    count = os.write(key.fileobj.fileno(), sources['runner'][sent:sent + 65536])
                    sent += count
                    if sent == len(sources['runner']):
                        selector.unregister(key.fileobj); key.fileobj.close()
                except BrokenPipeError:
                    selector.unregister(key.fileobj); key.fileobj.close()
                    fault('INCOMPLETE_STDIN_BROKEN_PIPE')
                continue
            block = os.read(key.fileobj.fileno(), 65536)
            if not block:
                eof[key.data] = True
                selector.unregister(key.fileobj); key.fileobj.close()
            else:
                observed_bytes[key.data] += len(block)
                room = max(0, 1048576 - len(captured[key.data]))
                captured[key.data].extend(block[:room])
                if observed_bytes[key.data] > 1048576:
                    fault('STREAM_CAP_PREFIX_RETAINED')

    try:
        # Every post-spawn setup operation is protected. Retained Source stdin
        # is written nonblocking under the same observer deadline as capture.
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, cwd=ROOT / 'root', start_new_session=True)
        selector = selectors.DefaultSelector()
        for name, stream, mode in [('stdin', child.stdin, selectors.EVENT_WRITE),
                                  ('stdout', child.stdout, selectors.EVENT_READ),
                                  ('stderr', child.stderr, selectors.EVENT_READ)]:
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, mode, name)
        while True:
            if failure is None and time.perf_counter() - started >= 240:
                fault('OBSERVER_WALL_TIMEOUT')
            if cleanup_deadline is not None and time.perf_counter() >= cleanup_deadline:
                break
            pump_events()
            observe_wait_and_group()
            if wait_status is not None and all(eof.values()) and group_gone:
                break
            if wait_status is not None and not group_gone:
                fault('OWNED_DESCENDANT_GROUP_REMAINS')
    except BaseException as error:
        fault('OBSERVER_HOST_' + type(error).__name__)
    finally:
        confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
        if child is not None and not confirmed:
            fault('UNCONFIRMED_OWNED_PROCESS_OR_STREAM')
            # No blocking wait is used, even after SIGKILL. Any unconfirmed
            # ownership is explicit evidence and cannot be admitted COMPLETE.
            while time.perf_counter() < cleanup_deadline:
                try:
                    if selector is not None:
                        pump_events()
                    else:
                        time.sleep(0.01)
                    observe_wait_and_group()
                    if wait_status is not None and all(eof.values()) and group_gone:
                        break
                except BaseException as error:
                    cleanup_errors.append({'stage': 'bounded-cleanup', 'type': type(error).__name__})
                    break
        if selector is not None:
            selector.close()
        if child is not None:
            for stream in (child.stdin, child.stdout, child.stderr):
                if stream is not None:
                    stream.close()
    streams = {k: put(directory / (k + '.bin'), bytes(v)) for k, v in captured.items()}
    terminal = None
    confirmed = child is not None and wait_status is not None and all(eof.values()) and group_gone
    if (confirmed and child.returncode == 0 and not failure and not captured['stderr']
            and sent == len(sources['runner'])):
        terminal = json.loads(captured['stdout'])
        require(terminal['status'] == 'COMPLETE', 'whole worker terminal')
        read_ref(terminal['result']['stored'], 33554432)
    files, total = [], 0
    for p in sorted(directory.iterdir()):
        require(p.is_file() and not p.is_symlink(), 'closed regular output')
        raw = p.read_bytes(); total += len(raw)
        require(len(raw) <= 33554432 and total <= 536870912, 'whole readback ceilings')
        files.append(raw_ref(p, raw))
    require(len(files) <= 383, 'whole output count')
    for role, ref in plan['sources'].items():
        require(read_ref(ref) == sources[role], 'observer post Source guard')
    for role, ref in plan['metadata'].items():
        require(read_ref(ref) == metadata[role], 'observer post data guard')
    read_ref(plan['python'], 33554432); read_ref(plan['bootstrap'])
    require(Path(plan_path).read_bytes() == plan_raw, 'observer post plan guard')
    require(Path(authority_path).read_bytes() == authority_raw, 'observer post authority guard')
    require(consumed.read_bytes() == consume_raw, 'observer post consumed guard')
    require((directory / 'CONSUMED.json').read_bytes() == marker_raw, 'observer post marker guard')
    outcome = {'schema': 'T-owned-observer-result-v1',
               'status': 'COMPLETE' if terminal is not None else 'UNADMITTED',
               'child_pid': None if child is None else child.pid, 'command': command,
               'returncode': None if child is None else child.returncode,
               'failure': failure, 'cleanup_errors': cleanup_errors,
               'wait_confirmed': wait_status is not None, 'both_streams_EOF': all(eof.values()),
               'group_gone': group_gone, 'stdin_bytes_sent': sent,
               'observed_stream_bytes': observed_bytes, 'retained_streams_complete':
                   {k: observed_bytes[k] == len(captured[k]) for k in captured},
               'streams': streams, 'worker_terminal': terminal, 'files': files,
               'stored_bytes': total, 'wait4_peak_bytes': None if usage is None else usage.ru_maxrss,
               'whole_observer_seconds': time.perf_counter() - started,
               'scope': 'One fresh child. wait4 lifetime RSS on Darwin; no hard RAM quota. '
                        'Owned nonblocking wait/drain with240s sampled deadline and5s cleanup. '
                        'OS spawn, final readback/serialization tail are not an OS hard whole-lifetime '
                        'quota. Unconfirmed process, streams or group forbid COMPLETE.'}
    receipt = put(directory / 'observer-result.json', raw_json(outcome))
    sys.stdout.buffer.write(raw_json({'status': outcome['status'], 'receipt': receipt}))
    sys.stdout.buffer.flush()
    return 0 if terminal is not None else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=('worker', 'observer'), required=True)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority')
    args = parser.parse_args()
    if args.mode == 'worker':
        require(args.authority is None, 'worker has no authority path')
        return worker(args.plan)
    require(args.authority is not None, 'observer needs once authority')
    return observer(args.plan, args.authority)


if __name__ == '__main__':
    raise SystemExit(main())
