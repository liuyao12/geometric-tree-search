"""Administrative byte-only archive construction; no project execution."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('/private/tmp/gcts-proof-normalization-20261028-v1')
plan=json.loads((ROOT/'root/study-once-plan-001.json').read_text())
stage=ROOT/'root/publication-normalization-proof-search-v1';stage.mkdir(exist_ok=True)
zip_path=stage/'normalization-proof-search-evidence-v1.zip'
excluded=('root/report-draft/','root/publication-normalization-proof-search-v1/','publisher-normalization-proof-search-payload/','root/publication-normalization-proof-search-api-v1/','root/normalization-proof-search-live-TLS-verification-v1/')
entries={}
def add(name,p):
 p=Path(p);assert p.is_file() and not p.is_symlink() and name not in entries
 b=p.read_bytes();assert len(b)<=33554432
 entries[name]=(b,{'entry':name,'origin':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
for p in sorted(ROOT.rglob('*')):
 if p.is_file():
  rel=p.relative_to(ROOT).as_posix()
  if not rel.startswith(excluded):add('T/'+rel,p)
for label,d in [('cluster-Source-peer',Path('/private/tmp/gcts-L-T-cluster-ranker-peer-v1')),('policy-saved-review',Path('/private/tmp/gcts-L-T-whole-saved-policy-study001-review-v1'))]:
 for p in sorted(d.rglob('*')):
  if p.is_file():add('external/'+label+'/'+p.relative_to(d).as_posix(),p)
for role,v in plan['sources'].items():
 p=Path(v['path'])
 if not p.is_relative_to(ROOT):add('dependencies/sources/'+role+'/'+p.name,p)
for role,v in plan['metadata'].items():
 p=Path(v['path'])
 if not p.is_relative_to(ROOT):add('dependencies/metadata/'+role+'/'+p.name,p)
add('dependencies/authenticated-source-bootstrap-v1.py',plan['bootstrap']['path'])
add('seed-evidence/S-worker-result.json.gz','/private/tmp/gcts-proof-structure-20261028-v1/actual/study-001/worker-result.json.gz')
add('seed-evidence/S-full-evidence.zip','/private/tmp/gcts-proof-structure-20261028-v1/root/publication-structural-proof-search-v1/structural-proof-search-evidence-v1.zip')
manifest={'schema':'T-complete-scientific-evidence-manifest-v1','files':[v[1] for _,v in sorted(entries.items())],'runtime':plan['python'],'omitted':'Runtime executable and standard library; temporary presentation drafts and payload twins. All273 original scientific files are included. Publication/live verification occurs after this snapshot and is stored separately to avoid archive self-reference.','goal':'ACTIVE','scientific_once':'PERMANENTLY_SPENT'}
manifest_raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
readme=b'''GCTS proof normalization and cluster-preference pilot, milestone T\n\nThis is the complete pre-publication scientific snapshot: all original run\nfiles, source modules, APIs, inputs, original outcomes, native proof checks,\nqualification controls, raw/gzip artifacts, independent reviews and supporting\ndata audits. MANIFEST.json maps every original entry to its absolute origin,\nlength and SHA256. Local paths are included with the user's explicit consent.\n\nThe HTML notebook and public results JSON are published separately beside this\narchive. Sources and raw outputs here are their scientific evidence. Temporary\npresentation drafts and duplicate payload directories are omitted. Subsequent\npublication/API/TLS records cannot be included without circularity and are kept\nas a separate local completion snapshot.\n\nThe original batch authority is permanently spent; do not overwrite its output.\nThe batch driver pins absolute paths and uses exclusive output directories. A\nnew reproduction requires fresh paths and output locations. Individual pure\nverifier/checker APIs are documented in the included ABI files. Source-based\nproof checking can be reproduced independently; the Python runtime executable\nis identified by its exact pin but is not redistributed. Original runtime was\nPython 3.12 on Darwin; reported timings and RSS are local observations.\n\nThis is a small GIVEN/MP symbolic point-tile study. Normalization preserves\nbounded proof existence, not every original tiling. The actual trained policy\nchanged weights but showed no evaluation benefit. Neither a fixed universal\nWang palette nor full first-order mathematics search is claimed.\n'''
def write(z,name,b):
 info=zipfile.ZipInfo(name,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
 z.writestr(info,b,compresslevel=9)
assert not zip_path.exists()
with zipfile.ZipFile(zip_path,'x') as z:
 for name,(b,_) in sorted(entries.items()):write(z,name,b)
 write(z,'MANIFEST.json',manifest_raw);write(z,'README.txt',readme)
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)|{'MANIFEST.json','README.txt'}
 for name,(b,v) in entries.items():assert z.read(name)==b and hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
 assert z.read('MANIFEST.json')==manifest_raw and z.read('README.txt')==readme
raw=zip_path.read_bytes();assert len(raw)<=33554432
record={'schema':'Root-T-evidence-package-v1','status':'ALL_ORIGINAL_BYTES_AND_ZIP_ENTRIES_VERIFIED','archive':{'path':str(zip_path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'entries':len(entries)+2,'origin_files':len(entries),'origin_bytes':sum(len(x[0]) for x in entries.values()),'manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'science_originals':273,'scope':'Scientific snapshot before publication. No project function or new experiment executed.'}
p=ROOT/'root/evidence-package-v1.json';p.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record))
