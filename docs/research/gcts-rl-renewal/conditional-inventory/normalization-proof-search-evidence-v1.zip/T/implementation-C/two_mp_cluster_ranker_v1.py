"""Verified-seed two-MP families and a small stochastic preference learner.

Static pairs are internally valid base placements, not transactions or claims
about the other member's current legality. Only one currently legal base ID is
preferred; the engine retains its complete suffix. No scientific calls at load.
"""
import hashlib
import json
import math
import time

VERSION = 'T-TWO-MP-CLUSTER-RANKER-v1'
FEATURES = ('antecedent_link', 'first_slot', 'root_slot', 'gap',
            'boundary_reuse', 'root_formula_bytes')
MAX_WORK = 5000000
MAX_CALLS = 4096
MAX_TRACE_BYTES = 4194304


class InputError(Exception):
    pass


class BudgetExceeded(Exception):
    pass


def _need(ok, why):
    if not ok:
        raise InputError(why)


def _json(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _sha(x):
    return hashlib.sha256(_json(x).encode('ascii')).hexdigest()


def _copy(x):
    return json.loads(_json(x))


def _number(x):
    return (type(x) in (int, float) and -1000000 <= x <= 1000000
            and math.isfinite(x))


def _pattern(kind):
    a, b, c = ['meta', 'A'], ['meta', 'B'], ['meta', 'C']
    imp = lambda x, y: ['imp', x, y]
    if kind == 'ANTECEDENT':
        return {'root': c, 'prerequisites': [a, imp(a, b), imp(b, c)],
                'expansion': [{'out': b, 'antecedent': 'p0', 'implication': 'p1'},
                              {'out': c, 'antecedent': 'm0', 'implication': 'p2'}]}
    return {'root': c, 'prerequisites': [a, imp(a, imp(b, c)), b],
            'expansion': [{'out': imp(b, c), 'antecedent': 'p0', 'implication': 'p1'},
                          {'out': c, 'antecedent': 'p2', 'implication': 'm0'}]}


def mine_families(seed_records, *, budget=None):
    started = time.perf_counter()
    _need(type(seed_records) is list and len(seed_records) <= 32, 'seed list')
    families, sources = {}, []
    for record in seed_records:
        if budget is not None:
            budget()
        proof, check = record['proof'], record['checking']
        _need(check['status'] == 'VERIFIED' and check['native_status'] == 'accepted'
              and type(check['native_value']) is int and check['native_value'] == 1
              and check['independent']['status'] == 'VERIFIED', 'verified seed only')
        _need(type(proof) is list and 1 <= len(proof) <= 64, 'seed proof size')
        for i, line in enumerate(proof):
            if budget is not None:
                budget()
            if line['rule'] == 'axiom':
                _need(line['name'] in record['hypotheses']
                      and _json(line['formula']) == _json(record['hypotheses'][line['name']]),
                      'seed given')
            else:
                _need(line['rule'] == 'mp', 'seed MP fragment')
                a, b = line['antecedent'], line['implication']
                _need(type(a) is int and type(b) is int and 0 <= a < i and 0 <= b < i,
                      'seed prior references')
                _need(_json(proof[b]['formula']) == _json(['imp', proof[a]['formula'], line['formula']]),
                      'seed MP relation')
                for kind, first in [('ANTECEDENT', a), ('IMPLICATION', b)]:
                    if proof[first]['rule'] != 'mp':
                        continue
                    if kind not in families:
                        pattern = _pattern(kind)
                        families[kind] = {'id': _sha(pattern), 'link': kind,
                                          'pattern': pattern, 'occurrences': []}
                    families[kind]['occurrences'].append(
                        {'seed': record['id'], 'first': first, 'root': i})
        _need(_json(proof[-1]['formula']) == _json(record['goal']), 'seed target')
        sources.append({'id': record['id'], 'proof_sha256': _sha(proof)})
    body = {'families': [families[k] for k in sorted(families)], 'sources': sources}
    return dict(body, schema='T-two-MP-library-v1', status='COMPLETE',
                library_sha256=_sha(body), costs={'seconds': time.perf_counter() - started},
                scope='Mined MP-link roles generalized to formula metavariables; no theorem truth or new rule.')


def new_policy(seed=0):
    _need(type(seed) is int and 0 <= seed < 2 ** 64, 'policy seed')
    return {'schema': 'T-cluster-ranker-policy-v1', 'seed': seed,
            'weights': [0.0] * 6, 'baseline': 0.0, 'updates': 0}


def instantiate(library, bundle, wall_seconds=1.0, max_instances=256, *, budget=None):
    started, work = time.perf_counter(), 0
    _need(_number(wall_seconds) and 0 < wall_seconds <= 60, 'proposal wall')
    _need(type(max_instances) is int and 0 <= max_instances <= 4096, 'instance cap')
    _need(library['status'] == 'COMPLETE', 'complete library')
    model = bundle['model']
    model_hash = _sha(model)
    result = {'schema': 'T-two-MP-proposal-v1', 'status': 'UNKNOWN_BUDGET',
              'library_sha256': library['library_sha256'], 'model_sha256': model_hash,
              'max_instances': max_instances, 'instances': [], 'truncated': None,
              'inventory_sha256': None, 'reason': None, 'costs': {}}

    def tick(amount=1):
        nonlocal work
        if work + amount > MAX_WORK or time.perf_counter() - started >= wall_seconds:
            raise BudgetExceeded('proposal work/wall')
        work += amount
        if budget is not None:
            budget()

    try:
        candidates = model['candidates']
        _need(type(candidates) is list and len(candidates) <= 100000, 'candidate list')
        cs, ms, index = {}, {}, {}
        for candidate in candidates:
            tick()
            _need(type(candidate) is dict and len(candidate) == 3
                  and set(candidate) == {'id', 't', 'm'}, 'candidate fields')
            identity = candidate['id']
            _need(type(identity) is str and identity not in cs and type(candidate['t']) is list
                  and len(candidate['t']) == 1 and candidate['t'][0] in model['required'], 'unit identity')
            marks = {}
            for point, value in candidate['m']:
                tick()
                _need(type(point) is str and type(value) is str and point not in marks, 'literal marks')
                marks[point] = value
            cs[identity], ms[identity] = candidate, marks
            step = bundle['steps'][identity]
            if step['line']['rule'] == 'mp':
                key = (step['slot'], _json(step['line']['formula']))
                index.setdefault(key, []).append(identity)
        for values in index.values():
            values.sort()
        families = {f['link']: f for f in library['families']}
        instances, stop = [], False
        denominator = max(1, bundle['slots'] - 1)
        max_formula = max([1] + [len(_json(f)) for f in bundle['formula_catalog']])
        for second in sorted(cs):
            s2 = bundle['steps'][second]
            if s2['line']['rule'] != 'mp':
                continue
            for kind in sorted(families):
                reference = s2['line']['antecedent' if kind == 'ANTECEDENT' else 'implication']
                wanted = ms[second]['out:' + str(reference)]
                for first in index.get((reference, wanted), []):
                    tick()
                    s1 = bundle['steps'][first]
                    if cs[first]['t'][0] == cs[second]['t'][0]:
                        continue
                    merged = dict(ms[first])
                    tick(len(ms[second]))
                    if any(p in merged and merged[p] != v for p, v in ms[second].items()):
                        continue
                    merged.update(ms[second])
                    if len(instances) == max_instances:
                        stop = True
                        break
                    external = [s1['line']['antecedent'], s1['line']['implication'],
                                s2['line']['implication' if kind == 'ANTECEDENT' else 'antecedent']]
                    features = [float(kind == 'ANTECEDENT'), s1['slot'] / denominator,
                                s2['slot'] / denominator, (s2['slot'] - s1['slot']) / denominator,
                                (3 - len(set(external))) / 2,
                                len(_json(s2['line']['formula'])) / max_formula]
                    members = [first, second]
                    instances.append({'id': _sha([families[kind]['id'], members]),
                                      'family': families[kind]['id'], 'members': members,
                                      'points': [cs[first]['t'][0], cs[second]['t'][0]],
                                      'features': features,
                                      'union': {'t': sorted([cs[first]['t'][0], cs[second]['t'][0]]),
                                                'm': [[p, merged[p]] for p in sorted(merged)]}})
                if stop:
                    break
            if stop:
                break
        body = {'library_sha256': library['library_sha256'], 'model_sha256': model_hash,
                'max_instances': max_instances, 'instances': instances, 'truncated': stop}
        fingerprint = _sha(body)
        tick()
        result.update(body, status='COMPLETE', inventory_sha256=fingerprint)
    except BudgetExceeded as error:
        result['reason'] = str(error)
    result['costs'] = {'work': work, 'seconds': time.perf_counter() - started}
    return result


def make_order(proposal, policy, episode_seed, *, budget=None):
    _need(type(episode_seed) is int and 0 <= episode_seed < 2 ** 64, 'episode seed')
    weights = list(policy['weights'])
    _need(len(weights) == 6 and all(_number(w) and -4 <= w <= 4 for w in weights), 'weights')
    source = _copy(proposal) if proposal is not None else None
    active = source is not None and source['status'] == 'COMPLETE'
    trace = {'schema': 'T-cluster-ranker-trace-v1', 'policy_before': _copy(policy),
             'episode_seed': episode_seed, 'inventory_sha256': None if not active else source['inventory_sha256'],
             'calls': 0, 'fallbacks': 0, 'decisions': [], 'score_sum': [0.0] * 6,
             'complete': True, 'reason': None if active else 'NO_COMPLETE_PROPOSAL',
             'recorded_bytes': 0, 'seconds': 0.0}

    def order(point, legal_ids):
        started = time.perf_counter()
        def finish(value):
            trace['seconds'] += time.perf_counter() - started
            return value
        if budget is not None:
            budget()
        call_index = trace['calls']
        trace['calls'] += 1
        _need(type(point) is str and type(legal_ids) is list
              and all(type(x) is str for x in legal_ids)
              and legal_ids == sorted(set(legal_ids)), 'detached complete legal domain')
        if not trace['complete']:
            trace['fallbacks'] += 1
            return finish(None)
        legal = set(legal_ids)
        eligible = []
        if active:
            for instance in source['instances']:
                for p, identity in zip(instance['points'], instance['members']):
                    if p == point and identity in legal:
                        eligible.append((instance, identity))
        row = {'index': call_index, 'point': point, 'legal_ids': list(legal_ids),
               'eligible': [x['id'] for x, _ in eligible],
               'projected_ids': [identity for _, identity in eligible],
               'probabilities': [], 'features': [list(x['features']) for x, _ in eligible],
               'sampling': None, 'chosen': None, 'preference': None}
        gradient = [0.0] * 6
        if eligible:
            scores = [sum(w * f for w, f in zip(weights, x['features'])) for x, _ in eligible]
            maximum = max(scores)
            exps = [math.exp(s - maximum) for s in scores]
            total = sum(exps)
            probabilities = [v / total for v in exps]
            key = {'seed': episode_seed, 'call': call_index, 'point': point,
                   'legal_sha256': _sha(legal_ids), 'inventory': source['inventory_sha256']}
            digest = hashlib.sha256(_json(key).encode('ascii')).digest()
            integer = int.from_bytes(digest[:8], 'big') >> 11
            uniform = integer / 9007199254740992
            cumulative, chosen = 0.0, len(eligible) - 1
            for i, probability in enumerate(probabilities):
                cumulative += probability
                if uniform < cumulative:
                    chosen = i
                    break
            expected = [sum(p * x['features'][j] for p, (x, _) in zip(probabilities, eligible)) for j in range(6)]
            gradient = [eligible[chosen][0]['features'][j] - expected[j] for j in range(6)]
            row.update(probabilities=probabilities,
                       sampling={'key': key, 'sha256': digest.hex(), 'integer53': integer, 'uniform': uniform},
                       chosen=eligible[chosen][0]['id'], preference=eligible[chosen][1])
        size = len(_json(row))
        if call_index >= MAX_CALLS or trace['recorded_bytes'] + size > MAX_TRACE_BYTES:
            trace.update(complete=False, reason='TRACE_CAP_FALLBACK_ONLY')
            trace['fallbacks'] += 1
            return finish(None)
        trace['recorded_bytes'] += size
        trace['decisions'].append(row)
        trace['score_sum'] = [a + b for a, b in zip(trace['score_sum'], gradient)]
        if row['preference'] is None:
            trace['fallbacks'] += 1
            return finish(None)
        return finish([row['preference']])
    return order, trace


def update_policy(policy, trace, reward, learning_rate=0.05, *, budget=None):
    started = time.perf_counter()
    if budget is not None:
        budget()
    _need(_number(reward) and -1 <= reward <= 1 and _number(learning_rate)
          and 0 < learning_rate <= 1, 'reward/learning rate')
    before = _copy(policy)
    _need(_json(before) == _json(trace['policy_before']), 'same episode policy')
    choices = sum(bool(d['eligible']) for d in trace['decisions'])
    applied = trace['complete'] and choices > 0
    advantage = reward - before['baseline']
    if applied:
        policy['weights'] = [max(-4.0, min(4.0, w + learning_rate * advantage * g))
                             for w, g in zip(before['weights'], trace['score_sum'])]
        policy['baseline'] = 0.9 * before['baseline'] + 0.1 * reward
        policy['updates'] += 1
    return {'schema': 'T-cluster-ranker-update-v1', 'applied': applied,
            'before': before, 'after': _copy(policy), 'reward': reward,
            'learning_rate': learning_rate, 'advantage': advantage,
            'score_sum': list(trace['score_sum']), 'choice_calls': choices,
            'nonzero_weight_change': before['weights'] != policy['weights'],
            'seconds': time.perf_counter() - started,
            'scope': 'Projected score-SUM REINFORCE; reward is caller-bound verified success/resource outcome, never a logical negative.'}
