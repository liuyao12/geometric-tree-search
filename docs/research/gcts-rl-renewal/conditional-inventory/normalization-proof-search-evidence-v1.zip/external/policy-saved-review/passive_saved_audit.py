"""Read saved T bytes/data only. Never imports or calls any subject module."""
import json,gzip,hashlib,pathlib,stat,math,collections
T=pathlib.Path('/private/tmp/gcts-proof-normalization-20261028-v1');A=T/'actual/study-001'
OUT=pathlib.Path('/private/tmp/gcts-L-T-whole-saved-policy-study001-review-v1')
def image(v): return json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def sha(v): return hashlib.sha256(image(v)).hexdigest()
def digest(b): return hashlib.sha256(b).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  assert k not in d,('duplicate JSON key',k)
  d[k]=v
 return d
def parse(b): return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(AssertionError(x)))
def pin(p):
 p=pathlib.Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and p.resolve()==p
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def read(p): return parse(pathlib.Path(p).read_bytes())
def matchref(r):
 assert set(r)=={'path','bytes','sha256'} and type(r['bytes']) is int and r['bytes']>=0 and type(r['sha256']) is str and len(r['sha256'])==64
 assert pin(r['path'])==r,r
 return r
cache={};artifact_census={}
def artifact(r):
 assert set(r)=={'encoding','name','raw_bytes','raw_sha256','stored'}
 p=r['stored']['path'];assert pathlib.Path(p).parent==A
 matchref(r['stored']);b=pathlib.Path(p).read_bytes()
 assert r['encoding'] in ('json','gzip-json')
 raw=gzip.decompress(b) if r['encoding']=='gzip-json' else b
 assert len(raw)==r['raw_bytes'] and digest(raw)==r['raw_sha256']
 x=parse(raw);assert raw==image(x)+b'\n',p
 if p in artifact_census: assert artifact_census[p]==r
 artifact_census[p]=r;cache[p]=x;return x
obs=read(A/'observer-result.json');wt=obs['worker_terminal'];r=artifact(wt['result'])
for ar in r['artifacts']:artifact(ar)
assert len(r['artifacts'])==268 and len(artifact_census)==269
files=sorted(A.iterdir());assert len(files)==273
filepins=[pin(p) for p in files];idx={p['path']:p for p in filepins}
assert len(obs['files'])==272 and {p['path'] for p in obs['files']}==set(idx)-{str(A/'observer-result.json')}
for f in obs['files']: assert idx[f['path']]==f
assert sum(x['bytes'] for x in obs['files'])==obs['stored_bytes']==4103401
assert sum(x['bytes'] for x in filepins)==4168005
assert sum(x['raw_bytes'] for x in artifact_census.values())==27118191
assert set(idx)-set(artifact_census)=={str(A/n) for n in ['CONSUMED.json','stdout.bin','stderr.bin','observer-result.json']}
assert obs['status']=='COMPLETE' and obs['returncode']==0 and obs['failure'] is None and obs['cleanup_errors']==[]
assert all(obs[k] is True for k in ['both_streams_EOF','group_gone','wait_confirmed'])
assert all(obs['retained_streams_complete'].values())
for v in obs['streams'].values():matchref(v)
assert (A/'stderr.bin').read_bytes()==b'' and parse((A/'stdout.bin').read_bytes())==wt
plan=read(T/'root/study-once-plan-001.json');auth=read(T/'root/study-once-authority-001.json');spent=read(T/'root/study-once-authority-001.json.CONSUMED.json')
guards=[]
for x in [plan['python'],plan['bootstrap'],*plan['sources'].values(),*plan['metadata'].values()]:guards.append(matchref(x))
assert len(plan['sources'])==12 and len(plan['metadata'])==13
assert auth=={'schema':'T-normalization-proof-once-authority-v1','authorized':True,'uses':1,'plan':pin(T/'root/study-once-plan-001.json'),'python':plan['python'],'runner':plan['sources']['runner']}
assert spent=={'authority':pin(T/'root/study-once-authority-001.json'),'plan':pin(T/'root/study-once-plan-001.json'),'status':'SPENT'}
assert read(A/'CONSUMED.json')=={'authority':pin(T/'root/study-once-authority-001.json'),'consumed':pin(T/'root/study-once-authority-001.json.CONSUMED.json')}
assert plan['actual_dir']==str(A) and wt['plan']==pin(T/'root/study-once-plan-001.json')
assert plan['limits']=={'file_bytes':33554432,'max_files':384,'observer_seconds':240,'rss_bytes':1073741824,'stream_bytes':1048576,'total_bytes':536870912,'worker_seconds':210}
assert wt['status']=='COMPLETE' and wt['elapsed_seconds']<210 and obs['whole_observer_seconds']<240
assert wt['self_lifetime_peak_bytes']<1073741824 and obs['wait4_peak_bytes']<1073741824
assert obs['stdin_bytes_sent']==plan['sources']['runner']['bytes']
caller=read(T/'root/study-001-prospective-caller-v1.json');roottransport=read(T/'root/study-001-original-tool-whole-transport-adoption-v1.json')
for k in ['outer_stdout','outer_stderr']:matchref(roottransport[k])
assert parse(pathlib.Path(roottransport['outer_stdout']['path']).read_bytes())=={'status':'COMPLETE','receipt':pin(A/'observer-result.json')}
assert pathlib.Path(roottransport['outer_stderr']['path']).read_bytes()==b''
assert roottransport['original_tool']=={'exit_code':0,'initial_chunk':'ab2d16','intermediate':'ab3de7','session':98326,'terminal_chunk':'ab5ae6'}
assert caller['plan']==wt['plan'] and caller['runner']==plan['sources']['runner'] and caller['bootstrap']==plan['bootstrap']
assert obs['command']==[plan['python']['path'],'-I','-S','-B',plan['bootstrap']['path'],plan['sources']['runner']['path'],str(plan['sources']['runner']['bytes']),plan['sources']['runner']['sha256'],'--mode','worker','--plan',str(T/'root/study-once-plan-001.json')]
assert max(f['bytes'] for f in filepins)<33554432 and sum(f['bytes'] for f in filepins)<536870912
assert len(filepins)<384 and sum(obs['observed_stream_bytes'].values())<1048576
cases=read(plan['metadata']['cases']['path']);design=read(plan['metadata']['benchmark_design']['path']);limits=read(plan['metadata']['experiment_limits']['path'])
lib=read(A/'mined-cluster-library.json');assert lib==r['library'];assert lib['library_sha256']==sha({'families':lib['families'],'sources':lib['sources']})
assert len(lib['families'])==2 and set(f['link'] for f in lib['families'])=={'ANTECEDENT','IMPLICATION'}
families={f['id']:f for f in lib['families']}
for f in lib['families']: assert f['id']==sha(f['pattern'])
seeds=read(plan['metadata']['seeds']['path']);seedidx={x['id']:x for x in seeds['proofs']}
for s in lib['sources']: assert s['proof_sha256']==sha(seedidx[s['id']]['proof'])
for f in lib['families']:
 for o in f['occurrences']:
  proof=seedidx[o['seed']]['proof'];f1=proof[o['first']];f2=proof[o['root']]
  assert f1['rule']==f2['rule']=='mp' and o['first']<o['root']
  assert f2['antecedent' if f['link']=='ANTECEDENT' else 'implication']==o['first']
assert len(r['training'])==9 and len(r['results'])==5
qual=read(A/'whole-qualification.json');assert qual==r['qualification'] and qual['status']=='PASS' and qual['counts']=={'BFS':6,'compile':15,'decode':12,'solve':15}
for qr in qual['records']:artifact(qr['reference'])
# Literal saved-data proof checks, not closure/search or producer replay.
def proof_data(problem,proof):
 assert type(proof) is list and 1<=len(proof)<=problem['maxlines']
 for n,line in enumerate(proof):
  f=line['formula']
  if line['rule']=='axiom': assert set(line)=={'rule','name','formula'} and problem['hypotheses'][line['name']]==f
  else:
   assert set(line)=={'rule','antecedent','implication','formula'} and line['rule']=='mp'
   a,b=line['antecedent'],line['implication'];assert type(a) is type(b) is int and 0<=a<n and 0<=b<n
   assert proof[b]['formula']==['imp',proof[a]['formula'],f]
 assert proof[-1]['formula']==problem['goal']
# Saved proposal rows and every policy decision arithmetic.
proposal_reports=[];trace_reports=[];point_reports=[];bfs_reports=[];training_reports=[];eval_reports=[]
traces={};props={};solves={};bundles={};all_float_errors=[]
def close(a,b):
 e=abs(a-b);all_float_errors.append(e);assert math.isclose(a,b,rel_tol=2e-13,abs_tol=2e-14),(a,b,e)
def floatlist(a,b):
 assert len(a)==len(b)
 for x,y in zip(a,b):close(x,y)
def inspect_proposal(identity,row,bundle):
 prop=artifact(row['proposal']);assert prop['status']=='COMPLETE'
 assert prop['model_sha256']==sha(bundle['model']) and prop['library_sha256']==lib['library_sha256'] and prop['max_instances']==256
 body={k:prop[k] for k in ['library_sha256','model_sha256','max_instances','instances','truncated']}
 assert prop['inventory_sha256']==sha(body);assert len(prop['instances'])<=256
 ci={x['id']:x for x in bundle['model']['candidates']};seen=set()
 D=max(1,bundle['slots']-1);M=max([1]+[len(image(x)) for x in bundle['formula_catalog']])
 for ins in prop['instances']:
  assert set(ins)=={'id','family','members','points','features','union'}
  assert ins['id'] not in seen;seen.add(ins['id']);assert ins['id']==sha([ins['family'],ins['members']])
  f=families[ins['family']];one,two=ins['members'];c1,c2=ci[one],ci[two];s1,s2=bundle['steps'][one],bundle['steps'][two]
  assert s1['family']==s2['family']=='MP';l1,l2=s1['line'],s2['line'];assert s1['slot']<s2['slot']
  ref=l2['antecedent' if f['link']=='ANTECEDENT' else 'implication'];assert ref==s1['slot']
  assert dict(c2['m'])['out:'+str(ref)]==image(l1['formula']).decode('ascii')
  assert ins['points']==[c1['t'][0],c2['t'][0]] and c1['t'][0]!=c2['t'][0]
  union={}
  for p,v in c1['m']+c2['m']:
   assert p not in union or union[p]==v;union[p]=v
  assert ins['union']=={'t':sorted(c1['t']+c2['t']),'m':[[p,v] for p,v in sorted(union.items())]}
  feat=[float(f['link']=='ANTECEDENT'),s1['slot']/D,s2['slot']/D,(s2['slot']-s1['slot'])/D,(3-len({l1['antecedent'],l1['implication'],l2['implication'] if f['link']=='ANTECEDENT' else l2['antecedent']}))/2,len(image(l2['formula']))/M]
  floatlist(ins['features'],feat)
 report={'id':identity,'reference':row['proposal'],'instances':len(prop['instances']),'truncated':prop['truncated'],'inventory_sha256':prop['inventory_sha256'],'model_sha256':prop['model_sha256'],'all_literal_unions_and_features_verified':True}
 proposal_reports.append(report);props[identity]=prop;return prop

def inspect_trace(identity,row,prop,solve):
 tr=artifact(row['policy_trace']);w=tr['policy_before']['weights'];assert tr['inventory_sha256']==prop['inventory_sha256']
 assert tr['complete'] is True and tr['reason'] is None and tr['calls']==len(tr['decisions'])==row['stats']['ordering_calls']
 score=[0.0]*6;falls=0;size=0;nonempty=multi=distinct=changed=0;prefitems=0;branch_by_seq=[]
 for n,d in enumerate(tr['decisions']):
  assert set(d)=={'index','point','legal_ids','eligible','projected_ids','probabilities','features','sampling','chosen','preference'} and d['index']==n
  assert d['legal_ids']==sorted(set(d['legal_ids'])) and d['legal_ids']
  eligible=[];projected=[];features=[]
  for i in prop['instances']:
   for p,cid in zip(i['points'],i['members']):
    if p==d['point'] and cid in d['legal_ids']:eligible.append(i['id']);projected.append(cid);features.append(i['features'])
  assert d['eligible']==eligible and d['projected_ids']==projected and d['features']==features
  if eligible:
   nonempty+=1;multi+=len(eligible)>=2;distinct+=len(set(projected))>=2
   logits=[sum(x*y for x,y in zip(w,f)) for f in features];top=max(logits);exps=[math.exp(x-top) for x in logits];den=sum(exps);prob=[x/den for x in exps]
   floatlist(d['probabilities'],prob)
   key={'seed':tr['episode_seed'],'call':n,'point':d['point'],'legal_sha256':sha(d['legal_ids']),'inventory':prop['inventory_sha256']}
   h=sha(key);integer=int.from_bytes(bytes.fromhex(h)[:8],'big')>>11;u=integer/9007199254740992
   assert d['sampling']=={'key':key,'sha256':h,'integer53':integer,'uniform':u}
   acc=0.0;chosen=len(prob)-1
   for j,p in enumerate(prob):
    acc+=p
    if u<acc:chosen=j;break
   assert d['chosen']==eligible[chosen] and d['preference']==projected[chosen]
   expected=[sum(p*f[k] for p,f in zip(prob,features)) for k in range(6)]
   for k in range(6):score[k]+=features[chosen][k]-expected[k]
   changed+=d['preference']!=d['legal_ids'][0];prefitems+=1
  else:
   falls+=1;assert d['probabilities']==d['features']==[] and d['sampling'] is None and d['chosen'] is None and d['preference'] is None
  size+=len(image(d));order=([d['preference']] if d['preference'] else [])+[cid for cid in d['legal_ids'] if cid!=d['preference']]
  branch_by_seq.append({'point':d['point'],'legal':d['legal_ids'],'ordering':order})
 assert size==tr['recorded_bytes'] and falls==tr['fallbacks'];floatlist(score,tr['score_sum'])
 assert changed==row['stats']['ordering_changed_first'] and prefitems==row['stats']['ordering_prefix_items']
 retained=[ev['data'] for ev in solve['events'] if ev['kind']=='BRANCH'];assert len(retained)<=len(branch_by_seq)
 for a,b in zip(retained,branch_by_seq):
  assert a['point']==b['point'] and a['legal']==b['legal'] and a['ordering']==b['ordering']
 assert row['policy_summary']=={'calls':tr['calls'],'complete':True,'distinct_projected_choice_calls':distinct,'multiple_instance_calls':multi,'recorded_decisions':len(tr['decisions'])}
 report={'id':identity,'reference':row['policy_trace'],'calls':tr['calls'],'choice_calls':nonempty,'multiple_instance_calls':multi,'distinct_projected_choice_calls':distinct,'fallbacks':falls,'score_sum':score,'recorded_bytes':size,'retained_engine_branches_joined':len(retained),'sampling_probabilities_gradients_all_verified':True,'episode_seed':tr['episode_seed'],'policy_before':tr['policy_before']}
 trace_reports.append(report);traces[identity]=tr;return tr

def inspect_point(identity,problem,row):
 bundle=artifact(row['bundle']);solve=artifact(row['solve']);bundles[identity]=bundle;solves[identity]=solve
 assert bundle['hypotheses']==problem['hypotheses'] and bundle['goal']==problem['goal'] and bundle['slots']==problem['maxlines']
 assert row['status']==solve['status'] and row['reason']==solve['reason'] and row['stats']==solve['stats']
 model=bundle['model'];ci={x['id']:x for x in model['candidates']};assert len(ci)==len(model['candidates'])==row['candidates']
 assert len(model['required'])==problem['maxlines'] and set(ci)==set(bundle['steps'])
 marks=0
 for c in model['candidates']:
  assert set(c)=={'id','t','m'} and len(c['t'])==1 and c['t'][0] in model['required'] and type(c['id']) is str
  assert len(dict(c['m']))==len(c['m']);assert all(type(p) is type(v) is str for p,v in c['m']);marks+=len(c['m'])
 assert marks==row['mark_assignments']
 normalized={'required':model['required'],'candidates':[{'id':c['id'],'t':c['t'],'m':sorted(c['m'])} for c in sorted(model['candidates'],key=lambda c:c['id'])]}
 assert solve['model_sha256']==digest(image(normalized)+b'\n')
 assert row['selected']==solve['selected'] if 'selected' in row else solve['selected'] is None
 if row['status']=='SAT':
  assert len(set(row['selected']))==len(row['selected']);tot=collections.Counter();mm={};rc=collections.Counter()
  for cid in row['selected']:
   c=ci[cid];tot.update(c['t'])
   for p,v in c['m']:assert p not in mm or mm[p]==v;mm[p]=v;rc[p]+=1
  assert dict(tot)==dict.fromkeys(model['required'],1)
  cert=solve['certificate'];assert cert=={'selected':row['selected'],'totals':[[p,1] for p in model['required']],'markings':[[p,mm[p],rc[p]] for p in sorted(mm)],'generations':[[p,1] for p in row['selected']]}
  proof_data(problem,row['proof']);assert row['checking']['status']==row['checking']['independent']['status']=='VERIFIED'
  selected_by_slot=sorted((bundle['steps'][cid]['slot'],bundle['steps'][cid]['line']) for cid in row['selected'])
  assert [x[1] for x in selected_by_slot]==row['proof']
 else:
  assert solve['selected'] is solve['certificate'] is None and row.get('proof') is None and row.get('checking') is None
 assert solve['stats']['trail_writes']==solve['stats']['trail_undos'] and solve['stats']['cleanup_operations']==solve['stats']['trail_undos']
 if row['status']!='UNKNOWN':assert solve['entry_state']==solve['restored_state']
 else:assert row['reason'] in ('WALL_SECONDS','MAX_NODES')
 events=solve['events'];assert [e['seq'] for e in events]==list(range(len(events)))
 assert len(events)==solve['event_extent']['retained']==row['stats']['retained_events']
 if solve['event_extent']['retained_complete']:
  raw=b''.join(image(e)+b'\n' for e in events);assert len(raw)==solve['event_extent']['JSONL_bytes'] and digest(raw)==solve['event_extent']['SHA256']
 # Every saved independent audit is byte-joined; B supplies full independent graph/universe interpretation.
 prefix=pathlib.Path(row['bundle']['stored']['path']).name.split('-complete-model')[0]
 audits={}
 for suffix in ['universe-audit','state-audit','selection-audit']:
  p=A/(prefix+'-'+suffix+'.json')
  if p.exists():x=read(p);assert x['status']=='VERIFIED';audits[suffix]=pin(p)
 assert 'universe-audit' in audits and 'state-audit' in audits
 if row['status']=='SAT':assert 'selection-audit' in audits
 point_reports.append({'id':identity,'lane':row['lane'],'status':row['status'],'reason':row['reason'],'bundle':row['bundle'],'solve':row['solve'],'candidates':len(ci),'mark_assignments':marks,'literal_selected_cover_and_proof_verified':row['status']=='SAT','audits':audits,'search_seconds_inclusive':row['search_seconds_inclusive'],'audit_and_storage_seconds':row['audit_and_storage_seconds'],'proof_check_seconds':row.get('checking',{}).get('seconds',0),'stats':row['stats'],'final_observation_present':solve['restored_state'] is not None,'retained_events':len(events),'event_extent':solve['event_extent']})
 if 'proposal' in row:
  prop=inspect_proposal(identity,row,bundle);inspect_trace(identity,row,prop,solve)
 return bundle,solve

initial=read(A/'initial-policy.json');policy=initial
assert initial=={'schema':'T-cluster-ranker-policy-v1','seed':104729,'weights':[0.0]*6,'baseline':0.0,'updates':0}
training_cases=['train-derived-fork','train-shared-antecedent','train-curried-return']
for i,ep in enumerate(r['training']):
 assert ep['case']==training_cases[i%3] and ep['id']=='train-'+str(i//3)+'-'+ep['case']
 assert read(A/(ep['id']+'-episode.json'))==ep
 inspect_point(ep['id'],cases[ep['case']],ep['result']);tr=traces[ep['id']];up=ep['update']
 assert tr['episode_seed']==104729+i and tr['policy_before']==policy==up['before']
 assert ep['reward']==up['reward']==1.0 and ep['result']['status']=='SAT'
 choices=sum(bool(d['eligible']) for d in tr['decisions']);assert up['choice_calls']==choices and up['applied'] is True
 adv=1.0-policy['baseline'];close(up['advantage'],adv);assert up['learning_rate']==.05;floatlist(up['score_sum'],tr['score_sum'])
 weights=[max(-4.0,min(4.0,w+.05*adv*g)) for w,g in zip(policy['weights'],tr['score_sum'])]
 after=dict(policy);after.update(weights=weights,baseline=.9*policy['baseline']+.1,updates=policy['updates']+1)
 floatlist(up['after']['weights'],weights);close(up['after']['baseline'],after['baseline']);assert up['after']['updates']==after['updates']
 assert up['nonzero_weight_change']==(up['before']['weights']!=up['after']['weights'])
 training_reports.append({'id':ep['id'],'reward':ep['reward'],'status':ep['result']['status'],'update':up,'trace_reference':ep['result']['policy_trace'],'policy_summary':ep['result']['policy_summary']})
 policy=up['after']
assert policy==r['frozen_policy']==read(A/'frozen-learned-policy.json')
close(policy['baseline'],1-.9**9)
lanes=['S_REFERENCE','EXPANDED_OFF','EXPANDED_ON','ON_CLUSTER_RANDOM','ON_CLUSTER_RL'];evalnames=['eval-shared-implication','eval-delayed-shared','eval-tight-shared-implication','eval-missing-branch','eval-deep-shared-implication']
comparisons=[]
for n,ep in enumerate(r['results']):
 assert ep['id']==evalnames[n] and ep['problem']==cases[ep['id']]
 assert read(A/('eval-'+ep['id']+'-result.json'))==ep
 assert ep['execution_order']==lanes[n:]+lanes[:n] and set(ep['lanes'])==set(lanes)
 for lane,row in ep['lanes'].items():inspect_point(ep['id']+'/'+lane,ep['problem'],row)
 rid=ep['id']+'/ON_CLUSTER_RANDOM';lid=ep['id']+'/ON_CLUSTER_RL';p0,p1=props[rid],props[lid];t0,t1=traces[rid],traces[lid]
 assert {k:v for k,v in p0.items() if k!='costs'}=={k:v for k,v in p1.items() if k!='costs'} and ep['policy_comparison_equal_inventory'] is True
 assert t0['episode_seed']==t1['episode_seed']==130363+n
 assert t1['policy_before']==policy and t0['policy_before']==initial
 assert len(t0['decisions'])==len(t1['decisions'])
 keys=['index','point','legal_ids','eligible','projected_ids','features','sampling','chosen','preference']
 context_equal=chosen_equal=preference_equal=prob_equal=eligiblecalls=distinct=0;diffprobs=[]
 for a,b in zip(t0['decisions'],t1['decisions']):
  context_equal+=all(a[k]==b[k] for k in ['index','point','legal_ids','eligible','projected_ids','features','sampling'])
  chosen_equal+=a['chosen']==b['chosen'];preference_equal+=a['preference']==b['preference'];prob_equal+=a['probabilities']==b['probabilities']
  eligiblecalls+=bool(a['eligible']);distinct+=len(set(a['projected_ids']))>=2
  diffprobs.extend(abs(x-y) for x,y in zip(a['probabilities'],b['probabilities']))
 stat0={k:v for k,v in ep['lanes']['ON_CLUSTER_RANDOM']['stats'].items() if k!='elapsed_seconds'};stat1={k:v for k,v in ep['lanes']['ON_CLUSTER_RL']['stats'].items() if k!='elapsed_seconds'}
 comparisons.append({'id':ep['id'],'full_proposal_body_equal_except_costs':True,'instances':len(p0['instances']),'truncated':p0['truncated'],'inventory_sha256':p0['inventory_sha256'],'calls_each':len(t0['decisions']),'eligible_calls_each':eligiblecalls,'distinct_projected_choice_calls_each':distinct,'full_context_and_SHA_sampling_equal_calls':context_equal,'sampled_instance_ID_equal_calls_including_null':chosen_equal,'projected_base_preference_equal_calls_including_null':preference_equal,'exact_probability_array_equal_calls':prob_equal,'max_probability_difference':max(diffprobs,default=0),'selected_equal':ep['lanes']['ON_CLUSTER_RANDOM'].get('selected')==ep['lanes']['ON_CLUSTER_RL'].get('selected'),'proof_equal':ep['lanes']['ON_CLUSTER_RANDOM'].get('proof')==ep['lanes']['ON_CLUSTER_RL'].get('proof'),'all_nontime_stats_equal':stat0==stat1,'retained_engine_events_equal':solves[rid]['events']==solves[lid]['events'],'random_trace':ep['lanes']['ON_CLUSTER_RANDOM']['policy_trace'],'RL_trace':ep['lanes']['ON_CLUSTER_RL']['policy_trace'],'random_search_seconds':ep['lanes']['ON_CLUSTER_RANDOM']['search_seconds_inclusive'],'RL_search_seconds':ep['lanes']['ON_CLUSTER_RL']['search_seconds_inclusive']})
 for kind,key in [('BFS','BFS'),('CLOSURE','closure')]:
  obj=ep[key];assert read(A/('eval-'+ep['id']+'-'+kind+'.json'))==obj
  if obj['proof'] is not None:proof_data(ep['problem'],obj['proof']);assert obj['checking']['status']=='VERIFIED'
  else:assert obj.get('checking') is None
  assert obj['status'] in ('DERIVABLE','NOT_DERIVABLE','UNKNOWN_BOUND')
  if kind=='BFS' and obj['status']=='DERIVABLE':assert obj['shortest_lines']==len(obj['proof'])
  if obj['status']=='UNKNOWN_BOUND':assert obj['proof'] is None and obj['within_line_bound'] is False
  bfs_reports.append({'id':ep['id'],'kind':kind,'status':obj['status'],'search_seconds_inclusive':obj['search_seconds_inclusive'],'proof_lines':len(obj['proof']) if obj['proof'] else None,'check_seconds':obj.get('checking',{}).get('seconds',0),'counts':obj.get('counts'),'costs':obj.get('costs'),'scope':obj['scope']})
 eval_reports.append({'id':ep['id'],'execution_order':ep['execution_order'],'outcomes':{k:v['status'] for k,v in ep['lanes'].items()},'BFS':ep['BFS']['status'],'closure':ep['closure']['status']})
assert len(point_reports)==34 and len(proposal_reports)==len(trace_reports)==19 and len(bfs_reports)==10
assert collections.Counter(x['status'] for x in point_reports)=={'SAT':22,'UNSAT':9,'UNKNOWN':3}
expectedcalls={'carrier.build_carrier':28,'carrier.verify_carrier_choice':28,'clusters.instantiate':19,'clusters.make_order':19,'clusters.mine_families':1,'clusters.new_policy':2,'clusters.update_policy':9,'codec.decode':28,'codec.encode':28,'engine.solve':34,'fol_checker.check':28,'independent.bounded_bfs':5,'independent.qualify':1,'independent.verify_bundle':34,'independent.verify_selection':22,'normalizer.compile_problem':34,'normalizer.decode_selected':22,'state_audit.mp_closure':5,'tree_machine.Compiler':1,'tree_machine.Heap':28,'tree_machine.run':28,'tree_machine.validate':1}
assert wt['public_calls']==r['outer_public_calls']==expectedcalls
support={'schema':'L-T-complete-saved-data-policy-support-v1','scope':'Passive standard-library raw JSON/gzip/hash/math and literal saved-row joins only. No subject imports/functions, search, producer/checker/helper replay, native VM or qualification invocation. No newly generated scientific case.','whole_transport':{'file_census':filepins,'artifact_census':list(artifact_census.values()),'stored_bytes':4168005,'decoded_raw_bytes':27118191,'guards':guards,'observer':pin(A/'observer-result.json'),'worker_result':wt['result'],'original_terminal_association':pin(T/'root/study-001-original-tool-whole-transport-adoption-v1.json'),'authoritative_original_tool_exit':'Root retained tool adoption: initial ab2d16, session98326, intermediate ab3de7, final ab5ae6 exit0; own saved-capture/body join, no new OS observation.','authority':pin(T/'root/study-once-authority-001.json'),'spent':pin(T/'root/study-once-authority-001.json.CONSUMED.json'),'worker_seconds':wt['elapsed_seconds'],'observer_seconds':obs['whole_observer_seconds'],'worker_self_lifetime_peak_bytes':wt['self_lifetime_peak_bytes'],'wait4_child_lifetime_peak_bytes':obs['wait4_peak_bytes'],'memory_scope':'Separate lifetime observations; not simultaneous sum, process tree or hard OS cap.'},'public_calls':expectedcalls,'qualification_association':{'status':qual['status'],'records':len(qual['records']),'counts':qual['counts'],'scope':'Raw joins only; full qualifier semantics independently reviewed by B.'},'library':lib,'library_seed_metadata':plan['metadata']['seeds'],'training':training_reports,'frozen_policy':policy,'all_point_results':point_reports,'all_proposals':proposal_reports,'all_policy_traces':trace_reports,'evaluation':eval_reports,'random_vs_RL_full_comparisons':comparisons,'BFS_and_closure':bfs_reports,'float_arithmetic_tolerance':{'relative':2e-13,'absolute':2e-14,'maximum_observed_absolute_difference':max(all_float_errors,default=0)},'limits':limits,'seed_acquisition':r['seed_acquisition'],'phase_costs':{'mining_seconds':r['mining_seconds'],'training_seconds':r['training_seconds'],'native_preparation_seconds':r['native_preparation_seconds']},'gaps':['Full state/universe/qualification checks are B complementary lane, not silently repeated as producer calls. This lane directly verifies all selected literal covers and supplied proof lines.','Native carrier/codec/C1/B inner joins are C complementary lane; all 28 containing artifacts fully hashed here.','UNSAT or bounded BFS negative is supported by accepted Source/control path plus stored results; no independent exhaustive negative proof tree is newly reconstructed in this audit.','Engine event bodies may be prefixes; policy callback decisions are complete for all 19 policy episodes. UNKNOWN remains unknown and may omit final observation.','Small fixed pilot, one seed stream; no variance/generalization/speed-superiority, RL-benefit or transactional-macro claim.']}
p=OUT/'complete-saved-data-policy-support-v1.json';p.write_bytes(json.dumps(support,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False).encode('ascii')+b'\n')
print(json.dumps({'support':pin(p),'comparisons':comparisons,'training_totals':{k:sum(x[k] for x in trace_reports[:9]) for k in ['calls','choice_calls','multiple_instance_calls','distinct_projected_choice_calls']},'eval_totals':{k:sum(x[k] for x in comparisons) for k in ['calls_each','eligible_calls_each','distinct_projected_choice_calls_each','full_context_and_SHA_sampling_equal_calls','sampled_instance_ID_equal_calls_including_null','projected_base_preference_equal_calls_including_null','exact_probability_array_equal_calls']},'float_error':max(all_float_errors,default=0)},indent=2))
