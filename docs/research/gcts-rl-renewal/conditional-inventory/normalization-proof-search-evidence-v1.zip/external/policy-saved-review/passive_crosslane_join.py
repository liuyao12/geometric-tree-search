"""Passive cross-lane saved-data joins only; no project import/function."""
import json,gzip,pathlib,hashlib
T=pathlib.Path('/private/tmp/gcts-proof-normalization-20261028-v1');A=T/'actual/study-001';O=pathlib.Path('/private/tmp/gcts-L-T-whole-saved-policy-study001-review-v1')
def img(v):return json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def sh(v):return hashlib.sha256(img(v)).hexdigest()
def readref(r):
 b=pathlib.Path(r['stored']['path']).read_bytes();return json.loads(gzip.decompress(b) if r['encoding']=='gzip-json' else b)
r=json.loads(gzip.decompress((A/'worker-result.json.gz').read_bytes()));reports=[]
for ep in r['results']:
 bs={k:readref(v['bundle']) for k,v in ep['lanes'].items()}
 off,on=bs['EXPANDED_OFF'],bs['EXPANDED_ON'];assert off['steps']==on['steps'];a,b=off['model'],on['model'];assert a['required']==b['required']
 assert len(a['candidates'])==len(b['candidates'])
 for x,y in zip(a['candidates'],b['candidates']):
  assert x['id']==y['id'] and x['t']==y['t'];assert x['m']==[m for m in y['m'] if not m[0].startswith('nf:')]
 for lane in ['ON_CLUSTER_RANDOM','ON_CLUSTER_RL']:
  assert bs[lane]['model']==on['model'] and bs[lane]['steps']==on['steps'] and bs[lane]['formula_catalog']==on['formula_catalog']
 reports.append({'id':ep['id'],'OFF_ON_exact_same_ordered_candidate_ids_t_and_step_lines':True,'ON_removing_only_nf_marks_equals_entire_OFF_model':True,'all_three_ON_lane_models_steps_catalogues_equal':True,'OFF_model_sha256_no_LF':sh(a),'ON_model_sha256_no_LF':sh(b),'OFF_candidates':len(a['candidates']),'OFF_marks':sum(len(c['m']) for c in a['candidates']),'ON_marks':sum(len(c['m']) for c in b['candidates'])})
p=O/'complete-crosslane-model-join-v1.json';p.write_bytes(json.dumps({'schema':'L-T-passive-crosslane-join-v1','reports':reports},sort_keys=True,indent=2).encode()+b'\n')
print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'proposal_instances':19*256,'full_policy_rows':sum(len(readref(e['result']['policy_trace'])['decisions']) for e in r['training'])+sum(len(readref(ep['lanes'][lane]['policy_trace'])['decisions']) for ep in r['results'] for lane in ['ON_CLUSTER_RANDOM','ON_CLUSTER_RL'])},indent=2))
