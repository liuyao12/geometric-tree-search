Structural transfer diagnostic study.

The manifest maps original task paths to literal whole bytes in objects/SHA256. All nine once-only runs and native records are retained, plus raw JSON and report projections. Never reuse consumed actual directories/grants. A new execution needs new frozen inputs/reviews/Root maxone grants.

Python and full Z3 are external pinned runtime dependencies. Native checker source/binary, fixed program/microcode and actual data are included. Bundled standard library, platform and loader remain trusted. No bounded profile-positive proof; three diagonal native proofs are diagnostic outside memory profile. Earlier memory analysis concerns a preceding cohort.

This evidence does not establish general GCTS or RL advantage, heldout generalization, full first-order completeness, a universal primitive Wang palette, induction, full Hilbert geometry or plane tiling.
