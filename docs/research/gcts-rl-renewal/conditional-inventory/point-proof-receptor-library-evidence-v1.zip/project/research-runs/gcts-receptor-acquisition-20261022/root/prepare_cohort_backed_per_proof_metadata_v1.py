"""Administrative metadata only. No research module is imported or called."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
EXPERIMENT = 'signed-propositional-cohort-proof-benchmark-v1'
PREFIX = 'cohort-backed-per-proof-'
ACTIVE = ('checker', 'builders', 'reference', 'tiny_encoder',
          'nonwrapper_selector', 'signed_compiler', 'signed_producer', 'point_adapter')


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2
accept_path = Path(sys.argv[1]).resolve()
accept = read(accept_path)
assert accept['accepted_component_Source'] is True
for ref in accept['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    verify(accept[key])
source_authority = ROOT / (PREFIX + 'Root-caller-Source-authorship-v1.json')
assert pin(source_authority)['sha256'] == '9fe391774e7dff5082131836c62655d916e869476ece434aea37b384508d79df'
assert read(source_authority)['caller_Source_authorship_authorized'] is True
input_authority = ROOT / (PREFIX + 'input-authority-v1.json')
assert pin(input_authority)['sha256'] == '6c0c25d3163411efc666bdc147df41213b26725f6fe9368b9ad53c10f0b48b44'
inputs_authority = read(input_authority)
assert inputs_authority['experiment'] == EXPERIMENT
assert inputs_authority['slots'] == ['donor0', 'donor1', 'holdout0']
assert inputs_authority['donor_index_mapping'] == {'0': 'donor0', '1': 'donor1'}
binding = ROOT / (PREFIX + 'Root-contract-binding-v1.json')
requirements = STUDY / 'diagnostics-L' / (PREFIX + 'independent-pre-Source-expectations-v1.json')
offer_path = STUDY / 'implementation-B' / (PREFIX + 'CONTRACT-offer-v1.json')
offer = read(offer_path)
assert pin(offer_path)['sha256'] == '710b8662be70a92cb284ef9b24e5656468ba8729a2eeb9c2613eba0888556983'
descriptor_path = ROOT / 'original-bank-cohort-descriptor-v1.json'
disposition_path = ROOT / 'original-bank-cohort-Root-complete-whole-disposition-v1.json'
review_path = STUDY / 'review-C' / 'typed-original-bank-cohort-complete-whole-actual-review-v1.json'
for path, expected in ((descriptor_path, inputs_authority['admitted_descriptor']),
                       (disposition_path, inputs_authority['cohort_admission'])):
    assert pin(path) == expected
descriptor, disposition, cohort_review = map(read, (descriptor_path, disposition_path, review_path))
assert disposition['cohort_admitted'] is True and cohort_review['review_passed'] is True
assert descriptor['cohort_id'] == 'signed-propositional-original-bank-cohort-v1'
old_path = ROOT / 'plans' / 'signed-propositional-original-bank-cohort-qualification-v1-qualify-0.json'
assert pin(old_path)['sha256'] == 'e94e0281cb6fc4f0badec35599debeb31ec62ce0890aa7c53520ce82dbec8f22'
old = read(old_path)
assert len(old['files']) == 474
assert old['required_upstream_ids'] == []
roles = descriptor['covered_runtime_roles']
modules = {row['role']: row['rawpin'] for row in roles}
assert len(roles) == len(modules) == 38 and modules == old['module_pins']
active_roles = [{'role': role, 'rawpin': modules[role]} for role in ACTIVE]
assert active_roles == offer['interfaces']['active_cold_import_order']
populations = {row['population']: {key: row[key] for key in
    ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
    for row in descriptor['control_populations']}
assert len(populations) == 17 and populations == old['control_populations']
assert sum(row['groups'] for row in populations.values()) == 229
assert descriptor['limits'] == old['limits'] == inputs_authority['limits']
assert len(old['limits']) == 10 and old['limits']['result_bytes'] == 50331648
custody = descriptor['custody_runtime']
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
raw_inputs = {}
for row in descriptor['raw_inputs']:
    key, ref = row['plan_key'], row['rawpin']
    assert key not in raw_inputs and old[key] == ref
    verify(ref)
    raw_inputs[key] = ref
assert len(raw_inputs) == 8
guards = {}


def guard(ref):
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    assert ref['path'] not in guards or guards[ref['path']] == ref
    guards[ref['path']] = ref


for ref in old['files']:
    guard(ref)
for ref in accept['component_reviews'].values():
    guard(ref)
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    guard(accept[key])
for path in (accept_path, Path(__file__), old_path, source_authority, input_authority,
             binding, requirements, offer_path, descriptor_path, disposition_path, review_path,
             ROOT / (PREFIX + 'Root-independent-expectations-adoption-v1.json'),
             ROOT / 'issue_cohort_backed_per_proof_grant_v1.py',
             ROOT / 'census_cohort_backed_per_proof_case_v1.py'):
    guard(pin(path))
for ref in accept.get('additional_current_guards', []):
    guard(ref)
recipes = [dict(case_id=EXPERIMENT + '-donor-' + str(i), stage='acquire',
                donor_index=i, input_slot='donor' + str(i)) for i in range(2)]
assert [row['case_id'] for row in recipes] == inputs_authority['case_ids']
app_path = ROOT / (PREFIX + 'applicability-v1.json')
protocol_path = ROOT / (PREFIX + 'whole-protocol-v1.json')
closure_path = ROOT / (PREFIX + 'Source-closure-v1.json')
preparation_path = ROOT / (PREFIX + 'study-preparation-v1.json')
fresh = [app_path, protocol_path, closure_path, preparation_path]
for recipe in recipes:
    case = recipe['case_id']
    actual = STUDY / 'actual' / case
    fresh.extend((actual, Path(str(actual) + '.observer'), ROOT / 'plans' / (case + '.json'),
                  ROOT / 'grants' / (case + '.json'), ROOT / (PREFIX + 'donor-' +
                  str(recipe['donor_index']) + '-grant-proposal-v1.json')))
assert len(fresh) == 14
assert all(not path.exists() and not path.is_symlink() for path in fresh)
app_value = dict(schema='Root-FPC-cohort-per-proof-applicability-v1',
    cohort_id=descriptor['cohort_id'], descriptor=pin(descriptor_path),
    Root_disposition=pin(disposition_path), C_review=pin(review_path),
    covered_runtime_roles=roles, control_populations=descriptor['control_populations'],
    raw_inputs=descriptor['raw_inputs'], active_runtime_roles=active_roles,
    custody_runtime=custody, environment=descriptor['environment'],
    reference_integer_policy=['FPC-original-json-integer-policy-v1', 4300],
    limits=old['limits'], input_authority=pin(input_authority),
    contract_pins=[pin(offer_path), pin(binding), pin(requirements), pin(source_authority)],
    caller_pins=dict(worker=accept['worker'], API=accept['worker_API'],
                     offer=accept['worker_offer'], handoff=accept['worker_handoff']),
    accepted=False, qualification_rerun=False)
assert len(app_value) == 18
app = emit(app_path, app_value)
guard(app)
metadata = dict(cohort_descriptor=pin(descriptor_path), cohort_disposition=pin(disposition_path),
    cohort_C_review=pin(review_path), cohort_applicability=app, input_authority=pin(input_authority),
    search_configuration=inputs_authority['configuration'])
assert len(metadata) == 6
protocol = emit(protocol_path, dict(schema='Root-FPC-cohort-backed-per-proof-protocol-v1',
    experiment=EXPERIMENT, limits=old['limits'], module_pins=modules,
    control_populations=populations, job_recipes=recipes, metadata=metadata))
guard(protocol)
files = [guards[path] for path in sorted(guards)]
plans = []
for recipe in recipes:
    value = dict(old, **recipe, experiment=EXPERIMENT,
        actual_dir=str(STUDY / 'actual' / recipe['case_id']),
        worker_path=accept['worker']['path'], protocol=protocol, files=files,
        module_pins=modules, control_populations=populations, **metadata)
    value.update(raw_inputs)
    plans.append(emit(ROOT / 'plans' / (recipe['case_id'] + '.json'), value))
closure = emit(closure_path, dict(schema='Root-cohort-backed-per-proof-closed-Source-v1',
    status='PROSPECTIVE_NOT_EXECUTION_AUTHORITY', plans=plans, protocol=protocol,
    applicability=app, files=files, original474_guard_floor_preserved=True,
    covered_roles=38, active_cold_roles=8, control_scopes=17, admitted_control_groups=229,
    cohort_qualification_rerun=False, scientific_calls=0))
proposals = []
for recipe, plan in zip(recipes, plans, strict=True):
    case = recipe['case_id']
    grant_path = ROOT / 'grants' / (case + '.json')
    proposals.append(emit(ROOT / (PREFIX + 'donor-' + str(recipe['donor_index']) + '-grant-proposal-v1.json'),
        dict(schema='Root-cohort-backed-per-proof-once-proposal-v1', authorized=False,
        review_passed=False, uses=1, **recipe, plan_sha256=plan['sha256'],
        runner_sha256=custody['runner']['sha256'], observer_sha256=custody['observer']['sha256'],
        plan=plan, protocol=protocol, closure=closure, applicability=app,
        component_acceptance=pin(accept_path), component_reviews=accept['component_reviews'],
        prospective_grant_path=str(grant_path),
        prospective_command=[custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'],
                             plan['path'], str(grant_path)],
        required_before_grant=['Complete independent whole Source/protocol/plan review',
            'Root exact current raw guards/storage/tools-idle and fresh case observation',
            'Separate exact one-use true grant; donor1 also requires fresh donor0 Root/C whole admission'],
        execution_authority=False)))
print(json.dumps(emit(preparation_path, dict(schema='Root-cohort-backed-per-proof-preparation-v1',
    status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW', metadata_builder=pin(Path(__file__)),
    component_acceptance=pin(accept_path), worker=accept['worker'], protocol=protocol,
    applicability=app, recipes=recipes, plans=plans, closure=closure, proposals=proposals,
    shared_guards=len(files), original474_guard_floor_preserved=True, covered_roles=38,
    active_cold_roles=8, control_populations=17, admitted_groups=229,
    qualification_rerun=False, combined_query_certificate_entire_result_bytes=50331648,
    ten_caps_unchanged=True, all_proposals_false=True, scientific_calls=0, goal_complete=False)), indent=2))
