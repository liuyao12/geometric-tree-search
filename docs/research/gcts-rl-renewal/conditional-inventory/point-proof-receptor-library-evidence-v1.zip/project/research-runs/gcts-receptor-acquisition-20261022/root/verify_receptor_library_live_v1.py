"""Administrative read-only normal-TLS verification of three payloads and the unchanged retained proof reader."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = 'https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-receptor-library-actual-review-v1.json',
         'point-proof-receptor-library-evidence-v1.zip')
parser = argparse.ArgumentParser()
parser.add_argument('--commit', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}', args.commit)
out = Path(args.output)
assert out.parent == ROOT and not out.exists()
out.mkdir()
staging = json.loads((ROOT / 'publication-receptor-library-v1/P2-staging.json').read_bytes())
assert staging['scientific_execution'] is False
assert [row['path'] for row in staging['files']] == [PREFIX + name for name in NAMES]
refs = [dict(name=Path(row['path']).name, bytes=row['bytes'], sha256=row['sha256'], kind='CURRENT') for row in staging['files']]
refs.append(dict(name='point-proof-discovered-proofs-v1.html', bytes=20103,
                 sha256='9ab271e50144b917b2313be54228165a595dc27a419abd462a098293f8f05a02', kind='UNCHANGED_READER'))
assert len(refs) == 4
results = []
for ref in refs:
    target = out / ref['name']
    url = BASE + ref['name'] + '?v=' + args.commit
    proc = subprocess.run(['curl', '--fail', '--show-error', '--silent', '--location',
        '--proto', '=https', '--proto-redir', '=https', '--tlsv1.2', '--connect-timeout', '15',
        '--max-time', '45', '--output', str(target), url],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode:
        with (out / 'curl-failure.json').open('x') as stream:
            json.dump(dict(url=url, returncode=proc.returncode,
                stderr=proc.stderr.decode(errors='replace')), stream, indent=2)
            stream.write('\n')
        raise RuntimeError('Read-only HTTPS verification failed; no insecure fallback')
    body = target.read_bytes()
    assert dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()) == {
        k: ref[k] for k in ('bytes', 'sha256')}, ref['name']
    results.append(dict(**ref, url=url, match=True))
    print(ref['name'] + ': MATCH', flush=True)
with (out / 'verification.json').open('x') as stream:
    json.dump(dict(schema='Root-receptor-library-live-TLS-verification-v1',
        commit=args.commit, all_four_match=True, normal_TLS=True, certificate_bypass=False,
        files=results, scientific_calls=0), stream, indent=2)
    stream.write('\n')
