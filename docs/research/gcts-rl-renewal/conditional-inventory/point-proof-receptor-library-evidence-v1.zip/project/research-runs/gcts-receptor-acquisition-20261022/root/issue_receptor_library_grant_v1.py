"""Administrative issuance only, after Root's fresh whole/idle observations.

No donor binary is read/hashed here. Root/C metadata authenticates its pin;
the separately measured worker owns all four actual donor-body reads/checks.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
PREFIX = 'receptor-library-'
EXPERIMENT = 'two-admitted-donor-receptor-library-feasibility-v1'
CASE = EXPERIMENT + '-extract-0'
ACTIVE = ('checker', 'builders', 'reference', 'tiny_encoder', 'extractor', 'instance', 'receptor_bank')
APPLICABILITY_FIELDS = ('schema', 'cohort_id', 'descriptor', 'Root_disposition', 'C_review',
    'covered_runtime_roles', 'control_populations', 'raw_inputs', 'active_runtime_roles',
    'custody_runtime', 'environment', 'reference_integer_policy', 'limits',
    'donor_pair_authority', 'contract_pins', 'caller_pins', 'accepted', 'qualification_rerun')
METADATA_FIELDS = ('cohort_descriptor', 'cohort_disposition', 'cohort_C_review',
    'library_applicability', 'donor_pair_authority', 'donor_inputs', 'extraction_configuration')


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode())
    return pin(path)


def data_pin_shape(ref, expected_path):
    """No donor body filesystem access: exact metadata shape/path association."""
    assert type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['path']) is str and ref['path'] == str(expected_path)
    assert type(ref['bytes']) is int and ref['bytes'] > 0
    assert type(ref['sha256']) is str and len(ref['sha256']) == 64
    assert all(ch in '0123456789abcdef' for ch in ref['sha256'])


assert len(sys.argv) == 1
prep_path = ROOT / (PREFIX + 'study-preparation-v1.json')
accept_path = ROOT / (PREFIX + 'Root-whole-prospective-acceptance-v1.json')
prep, accept = read(prep_path), read(accept_path)
assert accept['accepted_prospective_metadata'] is True and accept['preparation'] == pin(prep_path)
for key in ('preparation', 'whole_review', 'component_acceptance'):
    verify(accept[key])
assert read(accept['whole_review']['path'])['review_passed'] is True
components = read(accept['component_acceptance']['path'])
assert components['accepted_component_Source'] is True
assert prep['component_acceptance'] == accept['component_acceptance']
for ref in components['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff', 'bank',
            'bank_component_acceptance', 'Source2_component_acceptance'):
    verify(components[key])
for key in ('protocol', 'closure', 'applicability', 'guard_list'):
    verify(prep[key])
assert len(prep['plans']) == len(prep['proposals']) == len(prep['recipes']) == 1
plan_ref, proposal_ref = prep['plans'][0], prep['proposals'][0]
verify(plan_ref)
verify(proposal_ref)
plan, proposal = read(plan_ref['path']), read(proposal_ref['path'])
protocol, closure, app = [read(prep[key]['path']) for key in ('protocol', 'closure', 'applicability')]
recipe = dict(case_id=CASE, stage='extract')
assert protocol['schema'] == 'Root-FPC-receptor-library-feasibility-protocol-v1'
assert protocol['job_recipes'] == prep['recipes'] == [recipe]
assert all(plan[key] == value and proposal[key] == value for key, value in recipe.items())
assert plan['experiment'] == EXPERIMENT and plan['required_upstream_ids'] == []
assert all(key not in plan for key in ('donor_index', 'input_slot', 'cohort_applicability',
                                     'input_authority', 'search_configuration', 'target_index', 'arm'))
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses']) is int and proposal['uses'] == 1
assert proposal['plan'] == plan_ref and proposal['closure'] == prep['closure']
assert closure['plans'] == prep['plans']
assert plan['protocol'] == closure['protocol'] == proposal['protocol'] == prep['protocol']
assert plan['library_applicability'] == closure['applicability'] == proposal['applicability'] == prep['applicability']
assert set(protocol['metadata']) == set(METADATA_FIELDS)
for key, ref in protocol['metadata'].items():
    assert plan[key] == ref
assert plan['files'] == closure['files'] and len(plan['files']) == prep['shared_guards']
assert plan['module_pins'] == protocol['module_pins'] == components['module_pins']
assert len(plan['module_pins']) == 41
assert plan['control_populations'] == protocol['control_populations']
assert len(plan['control_populations']) == 18
assert plan['limits'] == protocol['limits'] == app['limits'] and len(plan['limits']) == 10
assert app['schema'] == 'Root-FPC-receptor-library-applicability-v1'
assert set(app) == set(APPLICABILITY_FIELDS) and len(app) == 18
assert app['accepted'] is False and app['qualification_rerun'] is False
assert app['cohort_id'] == 'signed-propositional-original-bank-cohort-v1'
assert app['descriptor'] == plan['cohort_descriptor']
assert app['Root_disposition'] == plan['cohort_disposition'] and app['C_review'] == plan['cohort_C_review']
assert app['donor_pair_authority'] == plan['donor_pair_authority']
assert app['contract_pins'] == components['effective_contract'] == proposal['effective_contract']
assert app['caller_pins'] == dict(worker=components['worker'], API=components['worker_API'],
                                 offer=components['worker_offer'], handoff=components['worker_handoff'])
for ref in app['contract_pins']:
    verify(ref)
for key in ('cohort_descriptor', 'cohort_disposition', 'cohort_C_review', 'donor_pair_authority'):
    verify(plan[key])
descriptor = read(plan['cohort_descriptor']['path'])
assert read(plan['cohort_disposition']['path'])['cohort_admitted'] is True
assert read(plan['cohort_C_review']['path'])['review_passed'] is True
assert descriptor['covered_runtime_roles'] == app['covered_runtime_roles']
assert descriptor['control_populations'] == app['control_populations']
assert descriptor['raw_inputs'] == app['raw_inputs']
assert descriptor['limits'] == plan['limits'] and descriptor['custody_runtime'] == app['custody_runtime']
assert app['environment'] == descriptor['environment']
assert app['reference_integer_policy'] == ['FPC-original-json-integer-policy-v1', 4300]
original_modules = {row['role']: row['rawpin'] for row in descriptor['covered_runtime_roles']}
assert len(original_modules) == 38
assert {key: plan['module_pins'][key] for key in original_modules} == original_modules
assert list(plan['module_pins'])[38:] == ['extractor', 'instance', 'receptor_bank']
assert app['active_runtime_roles'] == [dict(role=role, rawpin=plan['module_pins'][role]) for role in ACTIVE]
prior_populations = {row['population']: {key: row[key] for key in
    ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
    for row in descriptor['control_populations']}
assert len(prior_populations) == 17 and sum(row['groups'] for row in prior_populations.values()) == 229
assert {key: plan['control_populations'][key] for key in prior_populations} == prior_populations
bank_accept = read(components['bank_component_acceptance']['path'])
source2_accept = read(components['Source2_component_acceptance']['path'])
assert bank_accept['accepted_component_Source'] is True
assert source2_accept['Source2_component_accepted'] is True
assert bank_accept['bank'] == components['bank'] == plan['module_pins']['receptor_bank']
verify(bank_accept['API'])
bank_api = read(bank_accept['API']['path'])
assert plan['control_populations']['receptor-DAG8'] == dict(groups=8, bank_role='receptor_bank',
    subject_role=['extractor', 'instance'], scope=bank_api['scope'], control_ids=bank_api['control_ids'])
assert plan['extraction_configuration'] == dict(schema='FPC-propositional-receptor-extraction-v1',
    min_nodes=2, max_nodes=8, per_donor_quota=2, library_quota=4,
    max_distinct_boundary_nodes=4, policy='ordered-ancestor-growth-v1')

pair = read(plan['donor_pair_authority']['path'])
assert pair['schema'] == 'Root-cohort-backed-two-donor-complete-disposition-v1'
assert pair['status'] == 'TWO_DISTINCT_FRESH_ORDINARY_PROOFS_ADMITTED'
assert pair['selected_queries_distinct'] is True
assert pair['complete_inputs_configuration_selection_equal'] is True
donor_inputs = plan['donor_inputs']
assert len(donor_inputs) == len(pair['admissions']) == 2
old_plans = []
for index, row in enumerate(donor_inputs):
    assert set(row) == {'donor_id', 'Root_admission', 'C_actual_review', 'query', 'certificate'}
    assert row['donor_id'] == 'donor' + str(index) and row['Root_admission'] == pair['admissions'][index]
    verify(row['Root_admission'])
    verify(row['C_actual_review'])
    admission, review = read(row['Root_admission']['path']), read(row['C_actual_review']['path'])
    old_case = 'signed-propositional-cohort-proof-benchmark-v1-donor-' + str(index)
    assert admission['schema'] == 'Root-FPC-cohort-backed-donor-admission-v1'
    assert admission['proof_admitted'] is True and admission['resources_and_custody_accepted'] is True
    assert admission['fresh_whole_original_byte_dual_gate'] is True
    assert admission['case_id'] == review['case_id'] == old_case
    assert admission['donor_index'] == review['donor_index'] == index
    assert admission['input_slot'] == review['input_slot'] == row['donor_id']
    assert review['schema'] == 'C-cohort-backed-per-proof-donor-complete-whole-actual-review-v1'
    assert review['review_passed'] is True and admission['C_actual_review'] == row['C_actual_review']
    assert row['query'] == admission['query'] == review['subjects']['original_query']
    assert row['certificate'] == admission['certificate'] == review['subjects']['original_certificate']
    for key, name in (('query', 'query.bin'), ('certificate', 'certificate.bin')):
        data_pin_shape(row[key], STUDY / 'actual' / old_case / name)
    assert admission['plan'] == review['subjects']['plan']
    verify(admission['plan'])
    old_plans.append(read(admission['plan']['path']))
assert len(old_plans[0]['files']) == 524 and old_plans[0]['files'] == old_plans[1]['files']
assert all(ref in plan['files'] for ref in old_plans[0]['files'])
data_paths = {row[key]['path'] for row in donor_inputs for key in ('query', 'certificate')}
assert len(data_paths) == 4
assert all(ref['path'] not in data_paths and '/actual/' not in ref['path'] for ref in plan['files'])
assert proposal['component_acceptance'] == accept['component_acceptance']
assert proposal['component_reviews'] == components['component_reviews']
assert proposal['bank_component_acceptance'] == components['bank_component_acceptance']
assert proposal['Source2_component_acceptance'] == components['Source2_component_acceptance']
guard_list = read(prep['guard_list']['path'])
assert guard_list['excludes_own_pin'] is True
assert guard_list['files'] == [ref for ref in plan['files'] if ref != prep['guard_list']]
assert all(ref in plan['files'] for ref in descriptor['source_closure'])
assert pin(Path(__file__)) in plan['files']
for ref in plan['files']:
    verify(ref)

case_path = ROOT / (PREFIX + 'extract-0-Root-case-prospective-acceptance-v1.json')
barrier_path = ROOT / (PREFIX + 'extract-0-all-tools-idle-barrier-v1.json')
absent = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'),
          Path(proposal['prospective_grant_path']), case_path, barrier_path]
assert all(not path.exists() and not path.is_symlink() for path in absent)
now = datetime.now(timezone.utc).isoformat()
case = emit(case_path, dict(schema='Root-receptor-library-case-prospective-acceptance-v1',
    issued_utc=now, accepted=True, **recipe, plan=plan_ref, closure=prep['closure'],
    proposal=proposal_ref, applicability=prep['applicability'],
    Root_whole_acceptance=pin(accept_path), whole_review=accept['whole_review'],
    metadata_issuer=pin(Path(__file__)), guards_current=len(plan['files']),
    donor_pair_authority=plan['donor_pair_authority'], donor_body_reads=0,
    absent_paths=[str(path) for path in absent], scientific_calls=0))
barrier = emit(barrier_path, dict(schema='Root-receptor-library-tools-idle-barrier-v1',
    issued_utc=now, case_id=CASE, acceptance=case,
    observation='Root freshly observes B/L/C complete/tools idle and every own command session terminal '
        'before issuer invocation. During this measured actual only the owned observer exec is polled.',
    scope='Current task tools, not exclusive OS ownership; Source cannot observe peer tool state. '
        'Root supplies the actual fresh observation, no security-sandbox or real-time guarantee.',
    guards_rehashed=len(plan['files']), fresh_absence_checks=5, donor_body_reads=0))
grant = {key: proposal[key] for key in ('uses', 'case_id', 'stage', 'plan_sha256',
    'runner_sha256', 'observer_sha256', 'plan', 'protocol', 'closure', 'applicability',
    'component_acceptance', 'component_reviews', 'bank_component_acceptance',
    'Source2_component_acceptance', 'effective_contract')}
grant.update(schema='Root-receptor-library-once-grant-v1', authorized=True, review_passed=True,
    issued_utc=now, whole_review=accept['whole_review'], case_proposal=proposal_ref,
    Root_prospective_acceptance=case, all_tools_idle_barrier=barrier,
    donor_pair_authority=plan['donor_pair_authority'],
    scope='One exact bounded extraction/library-feasibility case. Current8 scoped controls plus one '
        'extraction and every selected source occurrence; old229 provenance is not rerun. '
        'Actual owns all four original donor-body reads/hashes and all original-byte validations. '
        'All selected entries/costs/full views and original caps required; no earlier prefix, '
        'new proof/holdout, policy change or automatic library admission.')
grant_pin = emit(Path(proposal['prospective_grant_path']), grant)
print(json.dumps(dict(grant=grant_pin, acceptance=case, barrier=barrier,
                      command=proposal['prospective_command'])))
