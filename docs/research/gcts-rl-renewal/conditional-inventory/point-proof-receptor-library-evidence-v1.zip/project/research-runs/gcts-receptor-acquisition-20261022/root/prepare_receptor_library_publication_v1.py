"""Administrative packaging/display of one externally admitted saved actual.

No scientific module, inference checker, search, encoder, or extractor is called.
All archive members come from explicit frozen guards/census/metadata paths.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020' / 'publisher-recovery-6338a77'
CASE = 'two-admitted-donor-receptor-library-feasibility-v1-extract-0'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
DEST = ROOT / 'publication-receptor-library-v1'
PAYLOAD = P2 / 'publication-payload-receptor-library-v1'
NAMES = ('point-proof-parallel-progress-v1.html',
         'point-proof-receptor-library-actual-review-v1.json',
         'point-proof-receptor-library-evidence-v1.zip')


def raw(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    return path.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def read(path):
    return json.loads(raw(path))


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def emit(path, body):
    with path.open('xb') as stream:
        stream.write(body)


admission_path = ROOT / 'receptor-library-extract-0-Root-complete-whole-admission-v1.json'
admission = read(admission_path)
assert admission['finite_inventory_admitted'] is True and admission['case_id'] == CASE
review_path = STUDY / 'review-C' / 'typed-receptor-library-extract-0-complete-whole-actual-review-v1.json'
assert admission['complete_C_review'] == pin(review_path)
assert read(review_path)['review_passed'] is True
result_path = STUDY / 'actual' / CASE / 'result.json'
assert admission['result'] == pin(result_path)
result = read(result_path)
assert result['status'] == 'LIBRARY_FEASIBILITY_CANDIDATE'
assert result['accepted'] is False and result['library_admitted'] is False
assert result['dag8_qualification']['counts'] == dict(groups=8, passed=8, failed=0)
families, instances = result['extraction_result']['families'], result['instance_results']
assert len(families) == len(instances) == 4
assert [len(f['internal_nodes']) for f in families] == [2, 3, 2, 3]
assert [len(f['boundary_nodes']) for f in families] == [1, 0, 1, 0]
assert [len(x['service_result']['expansion_rows']) for x in instances] == [3, 3, 3, 3]
display_path = STUDY / 'diagnostics-L' / 'receptor-library-extract-0-display-assessment-v1.json'
display_ref = pin(display_path)
plan_path = ROOT / 'plans' / (CASE + '.json')
plan = read(plan_path)
census_path = ROOT / 'receptor-library-extract-0-terminal-raw-census-v1.json'
census = read(census_path)
assert census['partial_count'] == 0 and census['file_count'] == 22
assert len(plan['files']) == 601
assert not DEST.exists() and not PAYLOAD.exists()
DEST.mkdir()
PAYLOAD.mkdir()

members = {}
external = []


def include(path, role, expected=None):
    path = Path(path)
    body = raw(path)
    ref = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    if expected is not None:
        assert ref == {key: expected[key] for key in ('path', 'bytes', 'sha256')}
    try:
        name = 'project/' + path.relative_to(REPO).as_posix()
    except ValueError:
        assert ref == plan['python'], 'Only the explicitly pinned external Python is omitted'
        external.append(dict(role=role, **ref, supplied_separately=True))
        return
    if name in members:
        assert members[name]['ref'] == ref
    else:
        members[name] = dict(ref=ref, role=role, body=body)


for ref in plan['files']:
    include(ref['path'], 'closed-project-Source-or-metadata', ref)
for ref in census['files']:
    include(ref['path'], 'complete-new-actual', ref)
extra = [admission_path, review_path, display_path, result_path, plan_path, census_path,
    ROOT / 'receptor-library-study-preparation-v1.json',
    ROOT / 'receptor-library-Source-closure-v1.json',
    ROOT / 'receptor-library-extract-0-grant-proposal-v1.json',
    ROOT / 'receptor-library-Root-whole-prospective-acceptance-v1.json',
    ROOT / 'receptor-library-extract-0-Root-case-prospective-acceptance-v1.json',
    ROOT / 'receptor-library-extract-0-all-tools-idle-barrier-v1.json',
    ROOT / 'receptor-library-prepared-metadata-Root-passive-audit-v1.json',
    ROOT / 'receptor-library-extract-0-Root-passive-whole-audit-v1.json',
    ROOT / 'grants' / (CASE + '.json'), Path(__file__).resolve(),
    ROOT / 'publish_receptor_library_api_v1.py', ROOT / 'verify_receptor_library_live_v1.py',
    ROOT / 'receptor-library-publication-scripts-Source-handoff-v1.json',
    ROOT / 'receptor-library-publication-scripts-static-v1.json',
    ROOT / 'receptor-library-publication-scripts-manual-v1.json']
for path in extra:
    include(path, 'explicit-current-provenance-or-publication-Source')
prior_path = ROOT / 'publication-discovered-proofs-v1' / 'point-proof-discovered-proofs-evidence-v1.zip'
prior = pin(prior_path)
assert prior['bytes'] == 6049185 and prior['sha256'] == 'abfc83b79937cb6c223253d73761a20e29d8162bf494258fdf7426daa47ac099'
include(prior_path, 'unchanged-previously-published-complete-donor-and-cohort-archive')
catalog = dict(schema='Root-receptor-library-publication-catalog-v1',
    issued_utc=datetime.now(timezone.utc).isoformat(), case_id=CASE,
    Root_admission=pin(admission_path), complete_C_review=pin(review_path),
    saved_result=pin(result_path), display_assessment=display_ref,
    members=[dict(member=name, role=row['role'], **row['ref']) for name, row in sorted(members.items())],
    external_runtime=external, scientific_replay=False,
    scope='Complete new case, all project members of the601 guards, explicit current provenance, and nested prior complete public donor/cohort evidence. External pinned Python is recorded and must be supplied separately. Raw bytes preserved; no scientific code is imported or replayed.')
archive = DEST / NAMES[2]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, body in [('catalog.json', json_bytes(catalog))] + [(n, x['body']) for n, x in sorted(members.items())]:
        info = zipfile.ZipInfo(name, (2026, 10, 24, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(members) | {'catalog.json'}
    for name, row in members.items():
        assert bundle.read(name) == row['body']
emit(DEST / NAMES[1], raw(review_path))

table_rows = []
for index, family in enumerate(families):
    occurrence = family['source_occurrences'][0]
    source = ','.join(str(pair[0]) for pair in occurrence['source_to_local'])
    table_rows.append('<tr><td>\\(F_{'+str(index)+'}\\)</td><td>'+html.escape(occurrence['donor_id'])+
        '</td><td>\\('+str(len(family['internal_nodes']))+'\\)</td><td>\\('+str(len(family['boundary_nodes']))+
        '\\)</td><td>\\('+str(len(family['parameters']))+'\\)</td><td>\\('+source+'\\)</td><td>\\(3\\)</td></tr>')

panel = r'''<section class="panel" id="receptor-library-current">
<p class="status">Current result · finite inventory admitted · 24 October 2026 UTC</p>
<h1>Four automatically acquired proof families</h1>
<p>The complete extraction attempt passed independent whole-evidence review. It acquired four distinct family keys from the two automatically found baseline proofs. Every selected source occurrence was expanded and checked by both original validators, and its physical rows were mapped back to the source. All eight scoped independent test groups passed. Root admitted this small finite inventory; the saved worker's candidate flags remain unchanged.</p>
<div class="grid"><article class="card"><h3>Acquired</h3><span class="fact">\(4\)</span><p>Distinct family keys, with one selected source occurrence each. Both donor proofs contributed.</p></article><article class="card"><h3>Checked</h3><span class="fact">\(4\)</span><p>Standalone instance proofs, each with three physical rows, including any boundary hypothesis.</p></article><article class="card"><h3>Whole attempt</h3><span class="fact">\(45.233\,\mathrm{s}\)</span><p>Saved observer elapsed time, including setup, tests, extraction, checking, output and custody.</p></article></div>
<p>The conservative whole peak was \(375095296\,\mathrm{bytes}\). Original and instance byte artifacts plus the entire result used \(23868512\,\mathrm{bytes}\) of the shared \(50331648\,\mathrm{bytes}\) allowance. All \(22\) actual files were retained, totaling \(23875659\,\mathrm{bytes}\), with no partial files. Earlier donor acquisition and infrastructure qualification costs remain separately reported below; this attempt does not repeat them.</p>
<table><thead><tr><th>Family</th><th>Donor</th><th>Internal rows</th><th>Boundary ports</th><th>Formula parameters</th><th>Original internal source rows</th><th>Expanded rows</th></tr></thead><tbody>TABLE_ROWS</tbody></table>
<p>The conditional families use source row \(2\) as boundary port \(0\); the other families contain that row internally. Every selected root is source row \(3\). Equal-looking formulas never collapse distinct source occurrences.</p>
<h2>Read the actual three-row instances</h2>
<p>For a readable display, define aliases for the negations of the two original donor goals:</p>
\[\begin{aligned}
D_0&=\neg\bigl(\neg(P_0\to P_1)\to(P_1\to P_0)\bigr),\\
D_1&=\neg\bigl(P_0\to(P_1\to(P_1\to(P_2\to(P_2\to P_0))))\bigr).
\end{aligned}\]
<p>For each donor index \(i\), the following aliases abbreviate complete saved formulas:</p>
\[U_i=D_i\to((D_i\to D_i)\to D_i),\qquad
V_i=(D_i\to(D_i\to D_i))\to(D_i\to D_i).\]
<div class="family-visual">
<div class="fragment"><h3>Conditional families \(F_0,F_2\)</h3><div class="tile-line">
<div class="symbol-tile boundary"><span>Wire row \(0\) · hypothesis</span><div>\(U_i\to V_i\)</div><small>boundary · source row \(2\)</small></div>
<div class="symbol-tile axiom"><span>Wire row \(1\) · axiom H1</span><div>\(U_i\)</div><small>internal · source row \(0\)</small></div>
<div class="symbol-tile inference"><span>Wire row \(2\) · modus ponens</span><div>\(V_i\)</div><small>uses rows \((1,0)\) · source \(3\)</small></div>
</div><p>Assume the displayed implication. Axiom H1 supplies its antecedent. Modus ponens gives its consequent. The boundary row was an H2 axiom in the donor; this standalone conditional proof treats it as its explicit hypothesis.</p></div>
<div class="fragment"><h3>Closed families \(F_1,F_3\)</h3><div class="tile-line">
<div class="symbol-tile axiom"><span>Wire row \(0\) · axiom H1</span><div>\(U_i\)</div><small>internal · source row \(0\)</small></div>
<div class="symbol-tile axiom"><span>Wire row \(1\) · axiom H2</span><div>\(U_i\to V_i\)</div><small>internal · source row \(2\)</small></div>
<div class="symbol-tile inference"><span>Wire row \(2\) · modus ponens</span><div>\(V_i\)</div><small>uses rows \((0,1)\) · source \(3\)</small></div>
</div><p>Axiom H1 gives the antecedent and axiom H2 gives the implication. Modus ponens yields the displayed conclusion without boundary assumptions.</p></div></div>
<p class="caption">Fixed-orientation cells show the actual serialized row order. Colors distinguish boundary assumptions, axioms and inference; these display colors are not learned GCTS constraints or a compiled finite Wang palette. The aliases are independently associated with the saved trees. They are display abbreviations, not additional learned parameters: the four stored keys retain their distinct atom-based patterns.</p>
<div class="notice"><strong>What this establishes.</strong> Deterministic acquisition, parameterized representation and checked standalone source instances now work together. The inventory contains only two- and three-node fragments, as the policy analysis predicted. No use on a fresh target, larger internally shared cluster, hierarchical theorem inventory, learned marking, RL result or GCTS speedup is established.</div>
<p><strong>Next experiment.</strong> Compare ordinary conditional-lemma reuse and receptor-family reuse on the same frozen fresh target, with the same acquired information, primitive fallback, a final checked use map, and all construction and validation costs. A broader fragment-selection policy is a separate prospective experiment.</p>
<p><a href="point-proof-receptor-library-actual-review-v1.json">Complete independent whole-actual review</a> · <a href="point-proof-receptor-library-evidence-v1.zip">Complete case and pinned project evidence</a> · <a href="point-proof-discovered-proofs-v1.html">Read the original full donor proofs</a></p>
<p class="caption">The archive preserves raw case files, project Source guards, complete reviewed provenance and the unchanged earlier public donor/cohort archive. The external pinned Python runtime is identified and must be supplied separately. This report packages existing admitted evidence without scientific replay.</p>
</section><p class="notice"><strong>Historical Source milestone below.</strong> Its unrun labels describe the earlier pre-execution state. The admitted finite-inventory observation above is current.</p>
'''.replace('TABLE_ROWS', ''.join(table_rows))
base_path = ROOT / 'publication-receptor-Source2-bank-v1' / NAMES[0]
base = raw(base_path)
assert len(base) == 27109 and hashlib.sha256(base).hexdigest() == '3606fe66e2a781e6692d7a10da2902e817ed0af74b0d6e65963e5d4519343c80'
anchor = b'<body><main>'
assert base.count(anchor) == 1
emit(DEST / NAMES[0], base.replace(anchor, anchor + panel.encode()))
files = []
for name in NAMES:
    body = raw(DEST / name)
    emit(PAYLOAD / name, body)
    files.append(dict(path=PREFIX+name, root_source=str(DEST/name),
        publisher_source=str(PAYLOAD/name), bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
        git_blob_sha1=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()))
staging = dict(schema='Root-receptor-library-publication-staging-v1', scientific_execution=False,
    files=files, Root_admission=pin(admission_path), complete_C_review=pin(review_path),
    catalog_member='catalog.json', archive_project_members=len(members), external_runtime=external,
    display_assessment=display_ref, packaging_Source=pin(Path(__file__).resolve()),
    previous_HTML=pin(base_path), historical_HTML_preserved_as_exact_suffix=True)
emit(DEST / 'P2-staging.json', json_bytes(staging))
print(json.dumps(dict(staging=pin(DEST/'P2-staging.json'), files=files,
    archive_members=len(members)+1, scientific_calls=0)))
