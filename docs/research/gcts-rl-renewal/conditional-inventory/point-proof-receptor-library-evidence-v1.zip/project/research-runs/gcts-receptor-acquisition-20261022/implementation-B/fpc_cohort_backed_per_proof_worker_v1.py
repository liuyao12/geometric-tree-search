"""Cohort-backed cold ordinary per-proof once caller; Source authorship only.

Only the future separately reviewed once process may import the eight active
subjects. Covered38/229 provenance never supplies old scientific outputs.
Every original selected query and candidate goes unchanged to both validators.
No search, compiler, selector or certificate is executed by authoring this file.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-cohort-backed-per-proof-worker-v1'
EXPERIMENT = 'signed-propositional-cohort-proof-benchmark-v1'
PROTOCOL_SCHEMA = 'Root-FPC-cohort-backed-per-proof-protocol-v1'
MODULE_ROLES = ('checker', 'builders', 'reference', 'baseline_search', 'codec', 'baseline_bank', 'producer', 'obligation_bank', 'point_adapter', 'point_bank', 'intro_bank', 'regression_bank', 'explicit_kernel', 'explicit_oracle', 'explicit_bank', 'provider', 'tiny_oracle', 'tiny_encoder', 'tiny_bank', 'controller', 'frame_oracle', 'controller_bank', 'conclusion_index_bank', 'legacy_provider', 'fixed_slot_bank', 'matched_point_controller', 'csp_controller', 'matched_controller_bank', 'selector', 'selector_bank', 'nonwrapper_selector', 'nonwrapper_selector_bank', 'signed_compiler', 'signed_producer', 'signed_bank', 'occurrence_bank', 'evidence_codec', 'evidence_codec_bank')
ACTIVE_ROLES = ('checker', 'builders', 'reference', 'tiny_encoder', 'nonwrapper_selector', 'signed_compiler', 'signed_producer', 'point_adapter')
CONTROL_IDS = {'baseline56': ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 'obligation47': ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 'intro_integration1': ('producer-INTRO-local-HYP-dual-export',), 'point20': ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 'regression2': ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 'point-kernel13': ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 'point-kernel-safety3': ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 'tiny-full-provider10': ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 'full-frame-controller10': ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 'constructor-index14': ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 'fixed-free-slot8': ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 'matched-controller8': ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'), 'selector6': ('selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'), 'nonwrapper_selector6': ('literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'), 'signed_propositional8_successor_v2': ('compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'), 'occurrence_diagnostics9': ('unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'), 'lossless_evidence_codec8_v1': ('original-value-inverse-and221-paths', 'typed-scalars-and-integer-domain', 'canonical-sharing-order-and-occurrences', 'malformed-carriers-and-reference-refusals', 'owned-snapshot-and-public-lifecycle', 'first-callback-writer-and-retained-error', 'streamed-whole-and-path-readback', 'callable-intake-policy-and-session-isolation')}
CAPS = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210, 'observer_fallback_seconds': 225, 'memory_bytes': 1073741824, 'physical_bytes': 134217728, 'result_bytes': 50331648, 'log_bytes': 4194304, 'reserved_outer_bytes': 9437184, 'root_callbacks': 400000000}
COHORT_ID = 'signed-propositional-original-bank-cohort-v1'
COVERED_RUNTIME_ROLES = [{'role': 'checker', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py', 'bytes': 31557, 'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'}}, {'role': 'builders', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py', 'bytes': 11348, 'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'}}, {'role': 'reference', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py', 'bytes': 24681, 'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'}}, {'role': 'baseline_search', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_uniform_search_v1.py', 'bytes': 54407, 'sha256': '53467e578ad7b512ae66e8e03cd85dadba1ded39b9ab0012c17e7e8f170a0902'}}, {'role': 'codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_declared_query_codec_v1.py', 'bytes': 14061, 'sha256': '4c6366b1a3728608cedfd86f0c78ca38ffb9d65ffc1907b926fc5f5446ad0ab4'}}, {'role': 'baseline_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_search_controls_v2.py', 'bytes': 35231, 'sha256': 'f0c2be3c99e866aea7a62dc012c6ec96be64c6a0f9b8619a82626d04603946af'}}, {'role': 'producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_obligation_producer_v2.py', 'bytes': 105517, 'sha256': 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1'}}, {'role': 'obligation_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_independent_controls_v2.py', 'bytes': 51653, 'sha256': '309fa0c9d5c068266faf96ff2f61f3ff15874cf24b0065bc83d216fa10152280'}}, {'role': 'point_adapter', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/fpc_h1_point_rows_v2.py', 'bytes': 10972, 'sha256': '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'}}, {'role': 'point_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_point_row_independent_controls_v1.py', 'bytes': 18065, 'sha256': 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e'}}, {'role': 'intro_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_intro_integration_control_v1.py', 'bytes': 10141, 'sha256': '5390689c124393bed3ea8a19c84a1e43bb81d956945dbcebc5712b97892d90c2'}}, {'role': 'regression_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_two_defect_regressions_v1.py', 'bytes': 13618, 'sha256': '2a20fd644b8370d1f6b8f07921075c72b227dc280d9502c9259ac6ed9eb41c7b'}}, {'role': 'explicit_kernel', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/explicit_point_kernel_v2.py', 'bytes': 29002, 'sha256': '158174c8445997bedf5b17785840eb7a89dcd4d46098fcdfb35a84e2fef3849c'}}, {'role': 'explicit_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_literal_oracle_v1.py', 'bytes': 18338, 'sha256': 'ff34af27a491da3571fc02227333ca3ce048a8d7c6d49cb780d3b1c9ba14a995'}}, {'role': 'explicit_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_independent_controls_v1.py', 'bytes': 40853, 'sha256': 'eedf82a42ebae7f4133f2ee1781e33205980769f8164bd278641761e6d1a1029'}}, {'role': 'provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v6.py', 'bytes': 67637, 'sha256': '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048'}}, {'role': 'tiny_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_reference_v1.py', 'bytes': 14647, 'sha256': 'bcf281fc7e19bf8c08a5b33456a6bb2eeebb33b2034f203f1540820e5e4eff9b'}}, {'role': 'tiny_encoder', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py', 'bytes': 9018, 'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'}}, {'role': 'tiny_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_controls_v1.py', 'bytes': 30645, 'sha256': 'dadc7d7cad94fd80dbfe381e9d59f56c1af20d90149f292b9bd70ebe657442f7'}}, {'role': 'controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v1.py', 'bytes': 27604, 'sha256': 'e9198683dc830e0080fefde997e81adbcf5963c2671688b491c99bfde3ea9d61'}}, {'role': 'frame_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_frame_completion_reference_v1.py', 'bytes': 3981, 'sha256': 'e4d6f452cbda35b530fb469c10a2441bc694b523df8e46de74c96c4ab074de99'}}, {'role': 'controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/full_frame_controller_independent_controls_v2.py', 'bytes': 45831, 'sha256': '41d964fb0075cd034d64ccb98d078c6290e71d09d14ca2bc7ec004d343348f79'}}, {'role': 'conclusion_index_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/conclusion_index_independent_controls_v2.py', 'bytes': 29220, 'sha256': '3afd0cbd5c43419f7f8d23e46ef015cfd2232b2325a354e984535ccd14ad1ac5'}}, {'role': 'legacy_provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v4.py', 'bytes': 58026, 'sha256': '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'}}, {'role': 'fixed_slot_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/fixed_free_slot_independent_controls_v2.py', 'bytes': 27942, 'sha256': '8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03'}}, {'role': 'matched_point_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v3.py', 'bytes': 37990, 'sha256': '16acece30e3420a1097989c8d580d0c9cf103488ac5b3a151d3ff2fc64285fac'}}, {'role': 'csp_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_row_csp_controller_v2.py', 'bytes': 39011, 'sha256': 'c9ec1b7a54d18b6d04056cb38039434bf287711cf6f430d38c14a0a97988d59a'}}, {'role': 'matched_controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/matched_row_controller_independent_controls_v2.py', 'bytes': 62115, 'sha256': '4de67bf9eb06235b39b6bcb43a5775e9e11897620775db41a558ca55f661b13d'}}, {'role': 'selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/two_donor_input_selector_v1.py', 'bytes': 11525, 'sha256': 'a29b4ca1008b355006431584f05da9b391d22532602e7e54f14291477ef2e668'}}, {'role': 'selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/two_donor_input_selector_independent_controls_v1.py', 'bytes': 22672, 'sha256': '384aebcf362ff55da28e6bf4eec10360f50a354ad324f6423e7fdb0d3883bbf8'}}, {'role': 'nonwrapper_selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/nonwrapper_two_donor_input_selector_v1.py', 'bytes': 14767, 'sha256': '79e3faa7a63f908e94410b980c21c3e368d1672c4c318af4c822ad8462b25d83'}}, {'role': 'nonwrapper_selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/nonwrapper_selector_independent_controls_v1.py', 'bytes': 30254, 'sha256': 'a9f440295a9a9753d0983b62df056755df5adc1e88daf1c6895ce1d83a54fe2d'}}, {'role': 'signed_compiler', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_compiler_v3.py', 'bytes': 45796, 'sha256': 'e904a88fc7896f4a941ab2d4f3f37ee2af005369be30b959263a4dd5f55eda0d'}}, {'role': 'signed_producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_producer_v3.py', 'bytes': 26771, 'sha256': '3996ab4f37243c4c2ef59e27f1a2b24539414a63795de2441d938553297ee251'}}, {'role': 'signed_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/signed_propositional_independent_controls_v2.py', 'bytes': 47641, 'sha256': '1c6ec1eeea6e031cb8fd62c957f4f69f090b3b26c70c762e48c26ce3c4ce4693'}}, {'role': 'occurrence_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/occurrence_diagnostic_independent_controls_v2.py', 'bytes': 51261, 'sha256': '372f069194c488ad0067f17593636f03db9f1f820059f471491fcd12a683e6a7'}}, {'role': 'evidence_codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_lossless_evidence_codec_v3.py', 'bytes': 50486, 'sha256': '4a06aad019c6a2215ba8802e798d350190168bbda62b19d50ee6e0ff573b8143'}}, {'role': 'evidence_codec_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/lossless_evidence_independent_controls_v2.py', 'bytes': 40507, 'sha256': '1aa84e604dc5d44d43f7fa65ba76d87c2b58ee6858f2ee45a93dbdf1f12136f4'}}]
ACTIVE_RUNTIME_ROLES = [{'role': 'checker', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py', 'bytes': 31557, 'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'}}, {'role': 'builders', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py', 'bytes': 11348, 'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'}}, {'role': 'reference', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py', 'bytes': 24681, 'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'}}, {'role': 'tiny_encoder', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py', 'bytes': 9018, 'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'}}, {'role': 'nonwrapper_selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/nonwrapper_two_donor_input_selector_v1.py', 'bytes': 14767, 'sha256': '79e3faa7a63f908e94410b980c21c3e368d1672c4c318af4c822ad8462b25d83'}}, {'role': 'signed_compiler', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_compiler_v3.py', 'bytes': 45796, 'sha256': 'e904a88fc7896f4a941ab2d4f3f37ee2af005369be30b959263a4dd5f55eda0d'}}, {'role': 'signed_producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_producer_v3.py', 'bytes': 26771, 'sha256': '3996ab4f37243c4c2ef59e27f1a2b24539414a63795de2441d938553297ee251'}}, {'role': 'point_adapter', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/fpc_h1_point_rows_v2.py', 'bytes': 10972, 'sha256': '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'}}]
CONTROL_POPULATIONS = [{'population': 'baseline56', 'control_ids': ['codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'], 'groups': 56, 'bank_role': 'baseline_bank', 'subject_role': 'baseline_search', 'scope': 'Unchanged original56 codec/builders/old search expectations only. Fresh controls, never claims about the new producer.'}, {'population': 'obligation47', 'control_ids': ['search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'], 'groups': 47, 'bank_role': 'obligation_bank', 'subject_role': 'producer', 'scope': 'Additive new synthetic query/guard/compiler/product/fault coverage with full separate current receipts.'}, {'population': 'intro_integration1', 'control_ids': ['producer-INTRO-local-HYP-dual-export'], 'groups': 1, 'bank_role': 'intro_bank', 'subject_role': 'producer', 'scope': 'Synthetic search-only discovery of current-context INTRO/localHYP and primitive compiler/dual validation integration; not a six-goal theorem.'}, {'population': 'point20', 'control_ids': ['point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'], 'groups': 20, 'bank_role': 'point_bank', 'subject_role': 'point_adapter', 'scope': 'Current parametric point-row representation only, no parser or search/graph qualification.'}, {'population': 'regression2', 'control_ids': ['refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'], 'groups': 2, 'bank_role': 'regression_bank', 'subject_role': 'producer', 'scope': 'Exact malformed ownership and public-phase first-StopIteration regressions only; cleanup remains Source/whole custody authority.'}, {'population': 'point-kernel13', 'control_ids': ['global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'], 'groups': 13, 'bank_role': 'explicit_bank', 'subject_role': 'explicit_kernel', 'scope': 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'}, {'population': 'point-kernel-safety3', 'control_ids': ['normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'], 'groups': 3, 'bank_role': 'explicit_bank', 'subject_role': 'explicit_kernel', 'scope': 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'}, {'population': 'tiny-full-provider10', 'control_ids': ['duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'], 'groups': 10, 'bank_role': 'tiny_bank', 'subject_role': 'provider', 'scope': 'Restricted profile0,b<=3,n<=4 full-row membership; not all-FPC runtime qualification. Current provider subject is5; only the original explicitly scoped facets are tested.'}, {'population': 'full-frame-controller10', 'control_ids': ['protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'], 'groups': 10, 'bank_role': 'controller_bank', 'subject_role': 'controller', 'scope': 'Protocol stubs/schedule/intake plus separately identified real tiny positive/empty/reuse facets; no theorem discovery authority. Current provider subject is5; only the original explicitly scoped facets are tested.'}, {'population': 'constructor-index14', 'control_ids': ['shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'], 'groups': 14, 'bank_role': 'conclusion_index_bank', 'subject_role': 'legacy_provider', 'scope': 'New separately scoped necessary-predicate54 literal cases across10 groups, helper faults, Source-bound public fault/poison, original tiny full-identity/order/remainder/SINGLE EOF and new generic empty single-row b5. Not a public full-profile inventory equivalence, scheduler, cleanup, practical benefit or proof-admission qualification. Original26 declarations remain distinct and unchanged. Subject is separately imported exact provider4, never current6.'}, {'population': 'fixed-free-slot8', 'control_ids': ['rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'], 'groups': 8, 'bank_role': 'fixed_slot_bank', 'subject_role': 'provider', 'scope': 'Independent private rigid equation/typed-slot plus public tiny full identity/order/EOF/remainder/fault controls; legacy4 only common literal-set/order comparison. No all26 or full-profile/large-E2/cleanup/performance authority.'}, {'population': 'matched-controller8', 'control_ids': ['protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'], 'groups': 8, 'bank_role': 'matched_controller_bank', 'subject_role': 'csp_controller', 'scope': 'Five independent protocol groups and three real provider6 facets for BOTH matched_point_controller and csp_controller; same49field observation and common14phase clock. Oracle complete tiny sets, driver first exports only. No all-profile equivalence or cleanup/fault-sweep proof.'}, {'population': 'selector6', 'control_ids': ['selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'], 'groups': 6, 'bank_role': 'selector_bank', 'subject_role': 'selector', 'scope': 'Fresh independent input-only prefix/Boolean/pattern/slot/fault qualification. No proof/query-byte/producer authority; STOP branch runtime coverage remains explicit. Original192 scope objects unchanged.'}, {'population': 'nonwrapper_selector6', 'control_ids': ['literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'], 'groups': 6, 'bank_role': 'nonwrapper_selector_bank', 'subject_role': 'nonwrapper_selector', 'scope': 'New selector public endpoint controls only; selected control slots are not research input authority.'}, {'population': 'signed_propositional8_successor_v2', 'control_ids': ['compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'], 'groups': 8, 'bank_role': 'signed_bank', 'subject_role': 'signed_producer', 'scope': 'Exact original8 semantic obligations/IDs on explicit compiler Source3 publicVERSION2, producer Source3 VERSION2 and signed-bank2. No retargeting/admission/retry of failed legacy1.'}, {'population': 'occurrence_diagnostics9', 'control_ids': ['unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'], 'groups': 9, 'bank_role': 'occurrence_bank', 'subject_role': 'signed_producer/signed_compiler', 'scope': 'Nine additional independently authored occurrence/mathematical/diagnostic groups; Source2 bank VERSION1/98 fixed direct call locators. Complete only after all facets, no research proof or legacy-prefix authority.'}, {'population': 'lossless_evidence_codec8_v1', 'control_ids': ['original-value-inverse-and221-paths', 'typed-scalars-and-integer-domain', 'canonical-sharing-order-and-occurrences', 'malformed-carriers-and-reference-refusals', 'owned-snapshot-and-public-lifecycle', 'first-callback-writer-and-retained-error', 'streamed-whole-and-path-readback', 'callable-intake-policy-and-session-isolation'], 'groups': 8, 'bank_role': 'evidence_codec_bank', 'subject_role': 'evidence_codec', 'scope': 'Complete codec-only synthetic transport controls; not original221 scientific observations or proof admission. Full genuine observations retained separately.'}]
SCIENTIFIC_RAW_INPUTS = [{'rawpin': {'bytes': 8614, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/first-fixed-verifier-target-declarations-v1.json', 'sha256': 'c6ae5f616b61e85f4b5cbd2b1e7619c047f42d83afd725e277475292cd904b0a'}, 'role': 'six_declarations', 'scope': 'Exact original six public statements; no known proof, hint, lemma or certificate', 'plan_key': 'declarations'}, {'rawpin': {'bytes': 7910, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/first-fixed-verifier-search-targets-v3.json', 'sha256': '2e7cc31d6e72107d3811cf6a980ec261e0122c8736d4520db9cea119317eb54d'}, 'role': 'target_authority_reference', 'scope': 'Historical public input/six-field declaration authority Source context only. Does not authorize this new point-study actual; fresh Root protocol required.', 'plan_key': 'target_authority'}, {'rawpin': {'bytes': 15516, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/point-proof-independent-raw-models-v1.json', 'sha256': '18851c3488152f3743a61eacafc12322c94c48f98038cccf01bd95482793225a'}, 'role': 'explicit_raw13', 'scope': 'Declared literal model inputs only; no prior output', 'plan_key': 'explicit_raw_models'}, {'rawpin': {'bytes': 16186, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny-full-provider-inputs-and-expectations-v1.json', 'sha256': 'bd3cefe3f86700f0909d605bcac480e4c0f941dafc529716f68b20350699d708'}, 'role': 'tiny_seven_declarations', 'scope': 'New independent literals, not old result/accepting proof intake', 'plan_key': 'tiny_provider_declarations'}, {'role': 'conclusion_index_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/conclusion-index-control-literal-data-v1.json', 'bytes': 13490, 'sha256': 'b23d97e5bce2c28e288742d9173787905e0b18ce804cde7a1dc39e3db20695e2'}, 'scope': 'Independent literal14-group/54-white-box-case declaration input only. Not the unchanged26 semantic declarations, a target proof, accepting output or prior qualification.', 'plan_key': 'conclusion_index_fixtures'}, {'role': 'fixed_free_slot_fixtures', 'plan_key': 'fixed_free_slot_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/fixed-free-output-independent-equation-declarations-v1.json', 'bytes': 36196, 'sha256': '9b2d64e844900e3a5741e0792690bbf58f36ba2a3667d96ef9159d5d9911661a'}, 'scope': 'Complete pre-implementation independent26 equation/coverage declarations; new bank consumes exact value. Not a prior result, target proof or runtime generated fixture.'}, {'role': 'matched_controller_fixtures', 'plan_key': 'matched_controller_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/matched-row-CSP-point-independent-declarations-v1.json', 'bytes': 20281, 'sha256': '71078f5a170cda30c3f7b2d6a699e9c260793f6c8d591316076f6bb86c3ee898'}}, {'role': 'nonwrapper_selector_fixtures', 'plan_key': 'nonwrapper_selector_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/nonwrapper-selector-independent-literal-expectations-v1.json', 'bytes': 24228, 'sha256': '08770968af3ed99206e48c2b8d93be6471c5b730f96a091bf1ea688465c12082'}, 'scope': 'Fresh immutable independent literal selector controls; Source/provenance only, no old selected input or proof.'}]
CUSTODY_RUNTIME = {'runner': {'bytes': 12973, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py', 'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'}, 'observer': {'bytes': 10113, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py', 'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'}, 'python': {'bytes': 18058560, 'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'sha256': 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'}}
ENVIRONMENT = {'platform': 'darwin', 'python_implementation': 'cpython', 'python_version': '3.12.14', 'flags': ['-I', '-S', '-B']}
POLICY_RULE = 'BIND_EFFECTIVE_REFERENCE_AFTER_GENUINE_CHECK_AND_REQUIRE_STABLE_NORMAL_EXPORT_GATES'
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
QUALIFIER_CALLER_PINS = {'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_original_bank_cohort_qualification_worker_v2.py', 'bytes': 109375, 'sha256': '0eb50870aa2393ebd7ab3592080b7947f7ede8817daa15d5a89f90b9e08fce61'}, 'API': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-API-v2.json', 'bytes': 53978, 'sha256': 'cc86695071689bd29ae47b306fafb9ad3e191575e0d2386e9811e94069f47fe1'}, 'offer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-dependency-offer-v2-r2.json', 'bytes': 111150, 'sha256': 'b2f42b217a475c78a7699cee24a77c2df8a03fa10aee1bb72c0f60f896d0fa87'}, 'handoff': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-Source-handoff-v2-r2.json', 'bytes': 8027, 'sha256': 'e19da899dbabde85a0afec5d4bd05d294a377db7709c48347871760018b5caf7'}}
QUALIFIER_CONTRACT_PINS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/cohort-original-bank-files-and-per-proof-CONTRACT-offer-v2.json', 'bytes': 27923, 'sha256': 'a440259e7a05998958ef83e2af87e355d3ad46e4781113e52e8c4b2c83c15470'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-Root-concrete-contract-and-Source-authorship-v2.json', 'bytes': 10668, 'sha256': 'd108b11dd228ddfbaf107cd6d812c78af4d8e448ac5abfd63559d30709946a1d'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/complete-cohort-per-proof-independent-acceptance-requirements-v2.json', 'bytes': 15660, 'sha256': 'b5411a696fd5650a0b11611a00bde1f9de803f7fe82e72ab8af59c8de4d732a6'}]
DESCRIPTOR_FIELDS = ('schema', 'cohort_id', 'covered_runtime_roles', 'control_populations', 'raw_inputs', 'qualification_caller_pins', 'qualifier_contract_pins', 'custody_runtime', 'source_closure', 'environment', 'limits', 'output_limits', 'policy_rule')
CONFIGURATION = {'schema': 'FPC-H1-signed-propositional-configuration-v1', 'principal_order': 'FIRST_DECOMPOSABLE_OCCURRENCE', 'split_order': 'NEGATIVE_ANTECEDENT_FIRST', 'memoization': 'NONE', 'trace_limit': 0}
SLOTS = ('donor0', 'donor1', 'holdout0')
QUERY_FIELDS = ('version', 'claim_mode', 'function_arities', 'predicate_arities', 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
QUERY_FIXED_FIELDS = {'version': 1, 'claim_mode': 0, 'function_arities': [], 'predicate_arities': [0, 0, 0], 'theory_profile': 0, 'finite_axioms': [], 'Gamma': []}
PREFIX_FIELDS = ('rank', 'tokens', 'expanded_nodes', 'depth', 'atom_count', 'atom_occurrences', 'not_count', 'truth_values', 'tautology', 'proper_tautologies', 'single_axiom_subtags', 'whole_donor_matches', 'eligible', 'reason')
PREFIX_REASONS = ('NOT_TAUTOLOGY', 'PROPER_TAUTOLOGY', 'SINGLE_AXIOM', 'WHOLE_DONOR_INSTANCE', 'SELECTED')
PRODUCER_RECEIPT_FIELDS = ('schema', 'version', 'status', 'accepted', 'query', 'configuration', 'scope', 'analytic', 'reconstruction', 'candidate_validation')
ENCODER_RECEIPT_FIELDS = ('schema', 'version', 'complete', 'semantic_query', 'query_identity', 'limits', 'expanded_nodes', 'scope')
SEARCH_DIAGNOSTIC_FIELDS = ('schema', 'snapshot_available', 'phase', 'phase_in_progress', 'completed_atomic_steps', 'states_started', 'closed_branches', 'split_nodes', 'active_stack_depth', 'active_entry_count', 'pending_child_count', 'retained_closed_rule_nodes', 'primitive_rows_emitted', 'compiler_emitter_instances', 'observed_through_atomic_step')
SEARCH_DIAGNOSTIC_SCHEMA = 'FPC-H1-signed-propositional-diagnostics-v1'
COMPILER_DIAGNOSTIC_FIELDS = ('schema', 'snapshot_available', 'phase', 'phase_in_progress', 'active_control_index', 'active_fixture_index', 'compiler_invocation_index', 'observed_through_callback', 'phase_enter_monotonic_ns', 'construction_completed_ns', 'export_reachability_completed_ns', 'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created', 'emitter_instances', 'reachable_rows', 'export_rows_committed', 'expanded_headers_committed', 'wire_bytes_committed', 'active_encode_role')
COMPILER_DIAGNOSTIC_INITIAL = {'schema': 'FPC-H1-signed-compiler-diagnostics-v1', 'snapshot_available': False, 'phase': None, 'phase_in_progress': False, 'active_control_index': None, 'active_fixture_index': None, 'compiler_invocation_index': 0, 'observed_through_callback': 0, 'phase_enter_monotonic_ns': None, 'construction_completed_ns': None, 'export_reachability_completed_ns': None, 'export_encoding_completed_ns': None, 'formula_dag_nodes': None, 'ir_rows_created': None, 'emitter_instances': None, 'reachable_rows': None, 'export_rows_committed': 0, 'expanded_headers_committed': 0, 'wire_bytes_committed': 0, 'active_encode_role': None}
COMPILER_DIAGNOSTIC_SCHEMA = 'FPC-H1-signed-compiler-diagnostics-v1'
COMPILER_OPTIONAL_COUNTS = ('active_control_index', 'active_fixture_index', 'phase_enter_monotonic_ns', 'construction_completed_ns', 'export_reachability_completed_ns', 'export_encoding_completed_ns', 'formula_dag_nodes', 'ir_rows_created', 'emitter_instances', 'reachable_rows')
COMPILER_REQUIRED_COUNTS = ('compiler_invocation_index', 'observed_through_callback', 'export_rows_committed', 'expanded_headers_committed', 'wire_bytes_committed')
ACTIVE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1', 'builders': 'FPC-H1-AST-BUILDERS-v1', 'reference': 'FPC-H1-independent-flat-reference-v2', 'tiny_encoder': 'L-tiny-FPC-query-encoder-v1', 'nonwrapper_selector': 'FPC-NONWRAPPER-TWO-DONOR-INPUT-SELECTOR-v1', 'signed_compiler': 'FPC-H1-SIGNED-COMPILER-v2', 'signed_producer': 'FPC-H1-SIGNED-PROPOSITIONAL-PRODUCER-v2', 'point_adapter': 'FPC-H1-POINT-ROWS-v2'}
METADATA_PINS = {'cohort_descriptor': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-descriptor-v1.json', 'bytes': 183415, 'sha256': '6fc9c3d4c55c916182a86b08c185449bd7fbbfaf0f421f3fe0aad7b793eb9414'}, 'cohort_disposition': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-Root-complete-whole-disposition-v1.json', 'bytes': 6530, 'sha256': 'b07a9b5b8f09e183a15423ff82b5971bb5a42e0c5c0206f77a4ea2302a4e80de'}, 'cohort_C_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-original-bank-cohort-complete-whole-actual-review-v1.json', 'bytes': 24339, 'sha256': '8eedade128c051165b884e21646ec9d1257d73ca81b889d9abaf4b4df9a335f3'}, 'input_authority': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-input-authority-v1.json', 'bytes': 11909, 'sha256': '6c0c25d3163411efc666bdc147df41213b26725f6fe9368b9ad53c10f0b48b44'}}
CONTRACT_PINS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/cohort-backed-per-proof-CONTRACT-offer-v1.json', 'bytes': 35585, 'sha256': '710b8662be70a92cb284ef9b24e5656468ba8729a2eeb9c2613eba0888556983'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-Root-contract-binding-v1.json', 'bytes': 6848, 'sha256': 'cde2074573f01542ac29ebec458e0ea635bb1fa41c5f5e4d8faaf8d35a58ad7f'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/cohort-backed-per-proof-independent-pre-Source-expectations-v1.json', 'bytes': 18267, 'sha256': '503451fcdd3fc4b9250d0490af431b650d494484212389b76572fb8a77155ec6'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-Root-caller-Source-authorship-v1.json', 'bytes': 5984, 'sha256': '9fe391774e7dff5082131836c62655d916e869476ece434aea37b384508d79df'}]
APPLICABILITY_FIELDS = ('schema', 'cohort_id', 'descriptor', 'Root_disposition', 'C_review', 'covered_runtime_roles', 'control_populations', 'raw_inputs', 'active_runtime_roles', 'custody_runtime', 'environment', 'reference_integer_policy', 'limits', 'input_authority', 'contract_pins', 'caller_pins', 'accepted', 'qualification_rerun')
PROTOCOL_METADATA_FIELDS = ('cohort_descriptor', 'cohort_disposition', 'cohort_C_review', 'cohort_applicability', 'input_authority', 'search_configuration')
RECIPES = [{'case_id': 'signed-propositional-cohort-proof-benchmark-v1-donor-0', 'stage': 'acquire', 'donor_index': 0, 'input_slot': 'donor0'}, {'case_id': 'signed-propositional-cohort-proof-benchmark-v1-donor-1', 'stage': 'acquire', 'donor_index': 1, 'input_slot': 'donor1'}]


class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""


def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)


def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module


def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))


def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True


def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer


def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')


def _natural(value):
    return type(value) is int and value >= 0


def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())


def _compiler_snapshot(sink):
    # At most one fixed20 scalar checkpoint; no algorithm, getter or callback.
    if type(sink) is not dict or len(sink) != 20:
        return None
    for key in sink:
        if type(key) is not str:
            return None
    if set(sink) != set(COMPILER_DIAGNOSTIC_FIELDS):
        return None
    if (type(sink['schema']) is not str or sink['schema'] != COMPILER_DIAGNOSTIC_SCHEMA
            or type(sink['snapshot_available']) is not bool
            or sink['snapshot_available'] is not True
            or type(sink['phase_in_progress']) is not bool
            or type(sink['phase']) is not str
            or sink['phase'] not in ('INTAKE', 'CONSTRUCT', 'EXPORT_REACHABLE',
                                     'EXPORT_ENCODE', 'FINALIZE', 'FINAL')):
        return None
    for key in COMPILER_OPTIONAL_COUNTS:
        item = sink[key]
        if item is not None and not _natural(item):
            return None
    for key in COMPILER_REQUIRED_COUNTS:
        if not _natural(sink[key]):
            return None
    role = sink['active_encode_role']
    if role is not None and (type(role) is not str or role not in
                            ('CONCLUSION', 'LOGICAL_WITNESS', 'OTHER_WIRE')):
        return None
    return {key: sink[key] for key in COMPILER_DIAGNOSTIC_FIELDS}


def _search_snapshot(sink):
    # At most one fixed15 scalar checkpoint; never queried after unwind.
    if type(sink) is not dict or len(sink) != 15:
        return None
    for key in sink:
        if type(key) is not str:
            return None
    if set(sink) != set(SEARCH_DIAGNOSTIC_FIELDS):
        return None
    if (type(sink['schema']) is not str or sink['schema'] != SEARCH_DIAGNOSTIC_SCHEMA
            or type(sink['snapshot_available']) is not bool
            or sink['snapshot_available'] is not True
            or type(sink['phase_in_progress']) is not bool
            or type(sink['phase']) is not str
            or sink['phase'] not in ('INTAKE', 'SEARCH', 'RECONSTRUCT', 'FINAL')):
        return None
    for key in SEARCH_DIAGNOSTIC_FIELDS[4:]:
        if not _natural(sink[key]):
            return None
    return {key: sink[key] for key in SEARCH_DIAGNOSTIC_FIELDS}


def _validate_selection(value, equal, check):
    _keys(value, ('schema', 'program_id', 'status', 'complete', 'slots', 'prefixes', 'scope'), check)
    if (value['schema'] != 'nonwrapper-two-donor-input-selection-v1'
            or value['program_id'] != ACTIVE_VERSIONS['nonwrapper_selector']
            or value['complete'] is not True or type(value['scope']) is not str):
        raise ValueError('complete unchanged selector public return required')
    if value['status'] != 'SELECTED':
        raise ValueError('STOP_ACQUISITION: selector did not return SELECTED')
    _keys(value['slots'], SLOTS, check)
    _keys(value['prefixes'], SLOTS, check)
    for slot in SLOTS:
        check()
        selected = value['slots'][slot]
        _keys(selected, ('query', 'inspection'), check)
        _keys(selected['query'], QUERY_FIELDS, check)
        q = selected['query']
        for key, literal in QUERY_FIXED_FIELDS.items():
            if not equal(q[key], literal):
                raise ValueError('input authority fixed semantic field mismatch: ' + key)
        if type(selected['inspection']) is not dict:
            raise ValueError('complete selector inspection required')
        prefix = value['prefixes'][slot]
        _keys(prefix, ('stage', 'status', 'records', 'exhausted'), check)
        if (prefix['stage'] != slot or prefix['status'] != 'SELECTED'
                or prefix['exhausted'] is not False or type(prefix['records']) is not list
                or not prefix['records']):
            raise ValueError('full inclusive winning selector prefix required')
        for index, row in enumerate(prefix['records']):
            check()
            _keys(row, PREFIX_FIELDS, check)
            if (type(row['rank']) is not int or row['rank'] != index
                    or type(row['eligible']) is not bool
                    or row['eligible'] is not (index == len(prefix['records']) - 1)
                    or type(row['reason']) is not str
                    or row['reason'] not in PREFIX_REASONS
                    or (row['reason'] == 'SELECTED') is not row['eligible']):
                raise ValueError('exact ordered first-winner prefix carrier required')
    if equal(value['slots']['donor0']['query'], value['slots']['donor1']['query']):
        raise ValueError('two distinct donor semantic inputs required')


def _validate_search(value, declaration, query_identity, configuration, equal, check):
    _keys(value, ('status', 'candidate_certificate_bytes', 'receipt'), check)
    if type(value['status']) is not str or value['status'] != 'CANDIDATE_FOUND':
        # Includes reserved UNKNOWN_RECONSTRUCTION; no replacement or recovery.
        raise ValueError('STOP_ACQUISITION: normal producer did not return CANDIDATE_FOUND')
    if type(value['candidate_certificate_bytes']) is not bytes or not value['candidate_certificate_bytes']:
        raise ValueError('original complete nonempty candidate bytes required')
    receipt = value['receipt']
    _keys(receipt, PRODUCER_RECEIPT_FIELDS, check)
    if (receipt['schema'] != 'FPC-H1-signed-propositional-receipt-v1'
            or type(receipt['version']) is not int or receipt['version'] != 1
            or receipt['status'] != value['status'] or receipt['accepted'] is not False
            or receipt['candidate_validation'] != 'NOT_RUN_EXTERNAL_DUAL_GATE_REQUIRED'):
        raise ValueError('complete unadmitted public producer receipt required')
    identity = receipt['query']
    _keys(identity, ('query_hex', 'bytes', 'sha256') + QUERY_FIELDS, check)
    for key in QUERY_FIELDS:
        check()
        if not equal(identity[key], declaration[key]):
            raise ValueError('full producer semantic query association required')
    for key in ('query_hex', 'bytes', 'sha256'):
        check()
        if not equal(identity[key], query_identity[key]):
            raise ValueError('original producer query byte identity required')
    if not equal(receipt['configuration'], configuration):
        raise ValueError('full fixed producer configuration association required')
    _keys(receipt['scope'], ('supported', 'reason', 'path'), check)
    if not equal(receipt['scope'], dict(supported=True, reason=None, path=[])):
        raise ValueError('supported unchanged ordinary propositional scope required')
    _keys(receipt['analytic'], ('closed', 'open_leaf', 'counters'), check)
    if receipt['analytic']['closed'] is not True or receipt['analytic']['open_leaf'] is not None:
        raise ValueError('complete closed analytic candidate observation required')
    counters = receipt['analytic']['counters']
    _keys(counters, SEARCH_DIAGNOSTIC_FIELDS[4:-1], check)
    for key in SEARCH_DIAGNOSTIC_FIELDS[4:-1]:
        check()
        if not _natural(counters[key]):
            raise ValueError('exact nonnegative public analytic counter required')
    reconstruction = receipt['reconstruction']
    _keys(reconstruction, ('complete', 'reason', 'primitive_rows', 'emitter_version'), check)
    if (reconstruction['complete'] is not True or reconstruction['reason'] is not None
            or not _natural(reconstruction['primitive_rows']) or reconstruction['primitive_rows'] == 0
            or reconstruction['emitter_version'] != 'FPC-H1-SIGNED-PRIMITIVE-EMITTERS-v1'
            or counters['primitive_rows_emitted'] != reconstruction['primitive_rows']):
        raise ValueError('complete public primitive reconstruction association required')


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.implementation.name == 'cpython'
            and sys.version.split()[0] == '3.12.14'
            and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
            and os.getpid() == os.getpgrp() and type(root_start) is float
            and math.isfinite(root_start) and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated owned pinned Darwin child and genuine parent start required')
    began = root_start
    directory, plan_path = Path(actual_dir), Path(plan_path)
    study = Path(__file__).resolve().parents[1]
    plan_pin = raw_pin(plan_path)
    plan_bytes = plan_path.read_bytes()
    if byte_identity(plan_bytes) != {key: plan_pin[key] for key in ('bytes', 'sha256')}:
        raise ValueError('stable complete plan required')
    plan = json.loads(plan_bytes)
    del plan_bytes
    if not (plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['experiment'] == EXPERIMENT and plan['stage'] == 'acquire'
            and type(plan['donor_index']) is int and plan['donor_index'] in (0, 1)
            and plan['input_slot'] == SLOTS[plan['donor_index']]
            and plan['case_id'] == EXPERIMENT + '-donor-' + str(plan['donor_index'])
            and plan['required_upstream_ids'] == []
            and not any(key in plan for key in ('target_index', 'target_id', 'arm',
                'query', 'certificate', 'proof', 'tree', 'library', 'frame', 'lemma'))
            and directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and directory == study / 'actual' / plan['case_id']
            and plan['actual_dir'] == str(directory)
            and plan_path.parent == study / 'root' / 'plans'
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('fresh exact once donor case and owned paths required')
    if not (type(plan['limits']) is dict and set(plan['limits']) == set(CAPS)
            and all(type(plan['limits'][key]) is int and plan['limits'][key] == value
                    for key, value in CAPS.items())):
        raise ValueError('all ten original exact caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory / 'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == plan['case_id']
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('exact fresh once consumption required')
    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None,
                 first_fault_monotonic_ns=None, stages=[], versions={})
    primary, guards, source_unchanged = None, [], False
    qualification = input_freeze = search_result = subject_receipt = reference_receipt = None
    point_receipt = scientific = None
    selection = selection_frozen = configuration = configuration_frozen = None
    declarations = encoded_slots = module_projection = projection_items = None
    queries = frozen_inputs = None
    candidate = producer_result = frozen_query = None
    search_diagnostics = compiler_diagnostics = None
    work_snapshots = None
    reference_integer_policy = None
    modules = {}
    committed_bytes = 0
    output_rejection = None
    provisional = []
    normal_status = None

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic() - began >= CAPS['work_seconds']:
            fault = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python whole high-water ceiling')
        if fault is not None:
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            state['first_fault'] = fault
            raise fault

    def policy_check():
        check()
        current = sys.get_int_max_str_digits()
        if type(current) is not int or current != POLICY_BINDING[1]:
            raise ValueError('admitted native effective integer policy drift')
        return current

    def stage(name, operation):
        policy_check()
        state['stage'] = name
        row = dict(name=name, began=time.monotonic() - began, status='STARTED')
        state['stages'].append(row)
        answer = operation()
        policy_check()
        row.update(status='COMPLETED', seconds=time.monotonic() - began - row['began'])
        return answer

    def verify_files(cooperative):
        # Original noncooperative guard path remains permitted after first E.
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed closed Source/input: ' + row['path'])

    def canonical(value):
        # Immutable caller-owned JSON-image snapshots, not scientific re-encoding.
        _validate_json_image(value, check)
        policy_check()
        body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                           separators=(',', ':')) + '\n').encode('ascii')
        policy_check()
        return body

    def equal(left, right):
        return _checked_byte_equal(canonical(left), canonical(right), check)

    def stable_inputs():
        policy_check()
        if not _checked_byte_equal(canonical(selection), selection_frozen, check):
            raise ValueError('full selector output mutated during normal use')
        if configuration is not None and not _checked_byte_equal(
                canonical(configuration), configuration_frozen, check):
            raise ValueError('fixed caller configuration mutated during normal use')
        if encoded_slots is not None:
            if not _checked_byte_equal(canonical(encoded_slots), frozen_inputs, check):
                raise ValueError('full encoded/decode input observations mutated')
        if module_projection is not None:
            _keys(module_projection, ('checker', 'builders', 'compiler'), check)
            for key, value in projection_items:
                check()
                if module_projection[key] is not value:
                    raise ValueError('exact original module projection mutated')

    def decide_size(body, component):
        nonlocal output_rejection
        policy_check()
        size = len(body)
        prospective = committed_bytes + size
        if prospective > CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection = dict(schema='FPC-cohort-proof-output-rejection-v1',
                    component=component, exact_attempt_bytes=size,
                    committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective, cap_bytes=CAPS['result_bytes'])
            fault = RootBudget('selected original Q plus C plus ENTIRE result exceeds shared48MiB')
            # The size-decision object is the first Root fault, but it is not
            # a check() resource-decision timestamp: that field remains None.
            state['first_fault'] = fault
            raise fault

    def export_original(name, body):
        nonlocal committed_bytes
        if type(body) is not bytes:
            raise ValueError('original immutable binary body required')
        decide_size(body, name)
        record = dict(basename=name, phase='BEFORE_WRITE', readback_complete=False)
        provisional.append(record)
        expected = _digest(body, policy_check)
        actual = _write_bank_and_readback(directory / name, body, policy_check, record)
        if not equal(actual, expected):
            raise ValueError('full original-byte hash/readback identity required')
        committed_bytes += len(body)
        return dict(type='bytes', file=name, bytes=actual['bytes'], sha256=actual['sha256'])

    def retire_positive_references():
        nonlocal qualification, input_freeze, search_result, subject_receipt, reference_receipt
        nonlocal point_receipt, scientific, selection, selection_frozen, configuration
        nonlocal configuration_frozen, declarations, encoded_slots, queries, frozen_inputs
        nonlocal candidate, producer_result, frozen_query, module_projection, projection_items
        qualification = input_freeze = search_result = subject_receipt = reference_receipt = None
        point_receipt = scientific = selection = selection_frozen = configuration = None
        configuration_frozen = declarations = encoded_slots = queries = frozen_inputs = None
        candidate = producer_result = frozen_query = module_projection = projection_items = None

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed complete guard list required')
        guards = [pin_fields(row) for row in plan['files']]
        by_path = {row['path']: row for row in guards}
        if len(by_path) != len(guards):
            raise ValueError('unique complete guarded paths required')
        for row in guards:
            check()
            if '/actual/' in row['path'] or row['path'].endswith('.bin'):
                raise ValueError('closed guards are Source/input metadata, never old scientific bodies')
        _keys(plan['module_pins'], MODULE_ROLES, check)
        module_pins = {role: pin_fields(plan['module_pins'][role]) for role in MODULE_ROLES}
        roles = [dict(role=role, rawpin=module_pins[role]) for role in MODULE_ROLES]
        for role, row in zip(MODULE_ROLES, COVERED_RUNTIME_ROLES):
            check()
            if module_pins[role] != row['rawpin'] or by_path.get(row['rawpin']['path']) != row['rawpin']:
                raise ValueError('all exact38 covered namespace pins required')
        for key, expected in METADATA_PINS.items():
            check()
            if pin_fields(plan[key]) != expected or by_path.get(expected['path']) != expected:
                raise ValueError('exact guarded admitted/input authority metadata required: ' + key)
        applicability_pin = pin_fields(plan['cohort_applicability'])
        if by_path.get(applicability_pin['path']) != applicability_pin:
            raise ValueError('guarded new applicability record required')
        for row in SCIENTIFIC_RAW_INPUTS:
            check()
            if pin_fields(plan[row['plan_key']]) != row['rawpin'] or by_path.get(row['rawpin']['path']) != row['rawpin']:
                raise ValueError('unchanged full guarded raw8 objects required')
        if (pin_fields(plan['python']) != CUSTODY_RUNTIME['python']
                or raw_pin(Path(sys.executable).resolve()) != CUSTODY_RUNTIME['python']
                or by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())
                or Path(plan['runner_path']) != Path(CUSTODY_RUNTIME['runner']['path'])):
            raise ValueError('exact current caller/pinned runtime and original custodian required')
        for row in CUSTODY_RUNTIME.values():
            check()
            if by_path.get(row['path']) != row:
                raise ValueError('guarded original custody/runtime body required')
        protocol_pin = pin_fields(plan['protocol'])
        if by_path.get(protocol_pin['path']) != protocol_pin:
            raise ValueError('guarded current protocol required')
        verify_files(True)
        # Binding happens only after a genuine normal resource callback.
        policy_check()
        reference_integer_policy = [POLICY_BINDING[0], policy_check()]
        descriptor = json.loads(Path(plan['cohort_descriptor']['path']).read_bytes())
        disposition = json.loads(Path(plan['cohort_disposition']['path']).read_bytes())
        peer_review = json.loads(Path(plan['cohort_C_review']['path']).read_bytes())
        input_authority = json.loads(Path(plan['input_authority']['path']).read_bytes())
        applicability = json.loads(Path(applicability_pin['path']).read_bytes())
        protocol = json.loads(Path(protocol_pin['path']).read_bytes())
        _keys(descriptor, DESCRIPTOR_FIELDS, check)
        for key, expected in (
                ('covered_runtime_roles', COVERED_RUNTIME_ROLES),
                ('control_populations', CONTROL_POPULATIONS),
                ('raw_inputs', SCIENTIFIC_RAW_INPUTS), ('environment', ENVIRONMENT),
                ('custody_runtime', CUSTODY_RUNTIME), ('limits', CAPS),
                ('qualification_caller_pins', QUALIFIER_CALLER_PINS),
                ('qualifier_contract_pins', QUALIFIER_CONTRACT_PINS)):
            if not equal(descriptor[key], expected):
                raise ValueError('exact admitted descriptor field required: ' + key)
        if (descriptor['schema'] != 'FPC-original-bank-cohort-descriptor-v1'
                or descriptor['cohort_id'] != COHORT_ID or descriptor['policy_rule'] != POLICY_RULE):
            raise ValueError('exact admitted descriptor identity/policy required')
        for row in descriptor['source_closure']:
            check()
            ref = pin_fields(row)
            if '/actual/' in ref['path'] or by_path.get(ref['path']) != ref:
                raise ValueError('entire admitted semantic Source closure must remain guarded')
        if (disposition['schema'] != 'Root-original-bank-cohort-complete-whole-disposition-v1'
                or disposition['status'] != 'ADMITTED_EXACT_FINITE_INFRASTRUCTURE_COHORT229'
                or disposition['cohort_admitted'] is not True
                or disposition['cohort_id'] != COHORT_ID
                or not equal(disposition['descriptor'], METADATA_PINS['cohort_descriptor'])
                or not equal(disposition['complete_C_review'], METADATA_PINS['cohort_C_review'])
                or not equal(disposition['recorded_policy_binding'], reference_integer_policy)
                or peer_review['review_passed'] is not True or peer_review['blockers'] != []):
            raise ValueError('complete separate external Root/C cohort gate required')
        if (input_authority['schema'] != 'Root-FPC-cohort-backed-input-authority-v1'
                or input_authority['experiment'] != EXPERIMENT):
            raise ValueError('exact separately frozen input-only authority required')
        _keys(applicability, APPLICABILITY_FIELDS, check)
        expected_applicability = dict(schema='Root-FPC-cohort-per-proof-applicability-v1',
            cohort_id=COHORT_ID, descriptor=METADATA_PINS['cohort_descriptor'],
            Root_disposition=METADATA_PINS['cohort_disposition'], C_review=METADATA_PINS['cohort_C_review'],
            covered_runtime_roles=COVERED_RUNTIME_ROLES, control_populations=CONTROL_POPULATIONS,
            raw_inputs=SCIENTIFIC_RAW_INPUTS, active_runtime_roles=ACTIVE_RUNTIME_ROLES,
            custody_runtime=CUSTODY_RUNTIME, environment=ENVIRONMENT,
            reference_integer_policy=reference_integer_policy, limits=CAPS,
            input_authority=METADATA_PINS['input_authority'], contract_pins=CONTRACT_PINS,
            caller_pins=applicability['caller_pins'], accepted=False, qualification_rerun=False)
        if not equal(applicability, expected_applicability):
            raise ValueError('exact complete18-field applicability join required')
        _keys(applicability['caller_pins'], ('worker', 'API', 'offer', 'handoff'), check)
        for key in ('worker', 'API', 'offer', 'handoff'):
            check()
            row = pin_fields(applicability['caller_pins'][key])
            if by_path.get(row['path']) != row:
                raise ValueError('all four new separately reviewed caller pins must be guarded')
        if applicability['caller_pins']['worker'] != raw_pin(Path(__file__).resolve()):
            raise ValueError('new applicability binds this exact reviewed caller')
        expected_populations = {}
        for row in CONTROL_POPULATIONS:
            check()
            expected_populations[row['population']] = {key: value for key, value in row.items() if key != 'population'}
        if not equal(plan['control_populations'], expected_populations):
            raise ValueError('complete old17 scope objects and229 pairs required')
        if not equal(plan['search_configuration'], CONFIGURATION):
            raise ValueError('one exact common ordinary configuration required')
        _keys(protocol, ('schema', 'experiment', 'limits', 'module_pins',
                         'control_populations', 'job_recipes', 'metadata'), check)
        if (protocol['schema'] != PROTOCOL_SCHEMA or protocol['experiment'] != EXPERIMENT
                or not equal(protocol['limits'], CAPS)
                or not equal(protocol['module_pins'], plan['module_pins'])
                or not equal(protocol['control_populations'], expected_populations)
                or not equal(protocol['job_recipes'], RECIPES)):
            raise ValueError('exact two-recipe current protocol required')
        metadata = protocol['metadata']
        _keys(metadata, PROTOCOL_METADATA_FIELDS, check)
        for key in PROTOCOL_METADATA_FIELDS:
            if not equal(metadata[key], plan[key]):
                raise ValueError('exact new protocol/plan metadata join required: ' + key)
        qualification = dict(schema='FPC-cohort-backed-applicability-observation-v1',
            complete=True, accepted=False, cohort_id=COHORT_ID, applicability=applicability,
            descriptor=descriptor, external_Root_disposition=METADATA_PINS['cohort_disposition'],
            complete_C_review=METADATA_PINS['cohort_C_review'],
            qualification_rerun=False, groups=229, populations=17, runtime_roles=38,
            qualification_cost_reported_once=disposition['metrics'])
        for role in ACTIVE_ROLES:
            check()
            modules[role] = stage('IMPORT ' + role, lambda role=role: load_exact(
                module_pins[role], 'owned_cohort_proof_' + role + '_v1', check))
            if (type(modules[role].VERSION) is not str
                    or modules[role].VERSION != ACTIVE_VERSIONS[role]):
                raise ValueError('exact original active public VERSION required: ' + role)
            state['versions'][role] = modules[role].VERSION
        if (modules['signed_producer'].DIAGNOSTIC_FIELDS != SEARCH_DIAGNOSTIC_FIELDS
                or modules['signed_compiler'].COMPILER_DIAGNOSTIC_FIELDS != COMPILER_DIAGNOSTIC_FIELDS):
            raise ValueError('exact public15/20 diagnostic field bindings required')
        verify_files(True)
        selection = stage('SELECT_INPUTS', lambda: modules['nonwrapper_selector'].select_inputs(check=check))
        _validate_selection(selection, equal, check)
        selection_frozen = canonical(selection)
        queries, encoded_slots = {}, {}
        for slot in SLOTS:
            check()
            declaration = selection['slots'][slot]['query']
            encoded = stage('ENCODE ' + slot, lambda declaration=declaration:
                modules['tiny_encoder'].encode_tiny_declared_query(declaration, check=check))
            _keys(encoded, ('query_bytes', 'receipt'), check)
            raw = encoded['query_bytes']
            if type(raw) is not bytes or not raw:
                raise ValueError('exact original tiny query bytes required')
            er = encoded['receipt']
            _keys(er, ENCODER_RECEIPT_FIELDS, check)
            identity = _digest(raw, check)
            if (er['schema'] != 'independent-tiny-FPC-query-encoding-v1'
                    or er['version'] != ACTIVE_VERSIONS['tiny_encoder'] or er['complete'] is not True
                    or not equal(er['query_identity'], identity)
                    or not equal(er['semantic_query'], declaration)):
                raise ValueError('full original encoder semantic/byte association required')
            decoded = stage('DECODE ' + slot,
                lambda raw=raw: modules['checker'].decode_query(raw, check=check))
            if type(decoded) is not dict or type(decoded.get('EOF')) is not int or decoded['EOF'] != len(raw):
                raise ValueError('complete original query strict EOF required')
            for key in QUERY_FIELDS:
                check()
                if not equal(decoded[key], declaration[key]):
                    raise ValueError('all8 original decoded query fields required: ' + key)
            queries[slot] = raw
            encoded_slots[slot] = dict(declaration=declaration, inspection=selection['slots'][slot]['inspection'],
                encoder_receipt=er, decoded_query=decoded, query_hex=raw.hex(),
                query_identity=identity, EOF=decoded['EOF'])
            if not _checked_byte_equal(canonical(selection), selection_frozen, check):
                raise ValueError('complete selector snapshot stable after every input use')
        if _checked_byte_equal(queries['donor0'], queries['donor1'], check):
            raise ValueError('distinct original donor query byte identities required')
        frozen_inputs = canonical(encoded_slots)
        configuration = dict(CONFIGURATION)
        configuration_frozen = canonical(configuration)
        input_freeze = dict(schema='FPC-cohort-proof-input-freeze-v1',
            selection=selection, slots=encoded_slots, configuration=configuration,
            input_authority=METADATA_PINS['input_authority'],
            selected_slot=plan['input_slot'], donor_index=plan['donor_index'],
            snapshot_semantics='Owned immutable complete canonical JSON-image bytes; no scientific re-encoding',
            selection_snapshot_identity=_digest(selection_frozen, check),
            all3_snapshot_identity=_digest(frozen_inputs, check),
            configuration_snapshot_identity=_digest(configuration_frozen, check),
            holdout_searched=False)
        stable_inputs()
        frozen_query = queries[plan['input_slot']]
        query_artifact = stage('EXPORT ORIGINAL_QUERY', lambda: export_original('query.bin', frozen_query))
        search_diagnostics = dict.fromkeys(SEARCH_DIAGNOSTIC_FIELDS)
        search_diagnostics.update(schema=SEARCH_DIAGNOSTIC_SCHEMA, snapshot_available=False,
                                  phase_in_progress=False)
        compiler_diagnostics = dict(COMPILER_DIAGNOSTIC_INITIAL)
        module_projection = dict(checker=modules['checker'], builders=modules['builders'],
                                 compiler=modules['signed_compiler'])
        projection_items = tuple(module_projection.items())
        verify_files(True)
        producer_result = stage('SEARCH_PROPOSITIONAL', lambda:
            modules['signed_producer'].search_propositional(frozen_query,
                configuration=configuration, modules=module_projection, check=check,
                diagnostics=search_diagnostics, compiler_diagnostics=compiler_diagnostics))
        normal_status = (producer_result.get('status') if type(producer_result) is dict
                         and type(producer_result.get('status')) is str else None)
        _validate_search(producer_result, selection['slots'][plan['input_slot']]['query'],
            dict(encoded_slots[plan['input_slot']]['query_identity'], query_hex=frozen_query.hex()),
            configuration, equal, check)
        stable_inputs()
        candidate = producer_result['candidate_certificate_bytes']
        subject_receipt = stage('SUBJECT_FULL_VALIDATION', lambda:
            modules['checker'].check_certificate(frozen_query, candidate, check=check))
        if (type(subject_receipt) is not dict
                or subject_receipt.get('schema') != 'FPC-H1-finite-byte-check-receipt-v1'
                or subject_receipt.get('version') != ACTIVE_VERSIONS['checker']
                or subject_receipt.get('status') != 'VALID_DERIVATION'
                or any(subject_receipt.get(key) is not True for key in
                    ('complete', 'accepted', 'syntax_complete', 'derivation_complete',
                     'final_goal_equal', 'no_prefix_authority'))):
            raise ValueError('full original subject VALID_DERIVATION required')
        if (not equal(subject_receipt['raw_inputs']['query'], _digest(frozen_query, check))
                or not equal(subject_receipt['raw_inputs']['certificate'], _digest(candidate, check))
                or subject_receipt['query']['EOF'] != len(frozen_query)
                or subject_receipt['certificate']['EOF'] != len(candidate)):
            raise ValueError('subject identical original bytes and strict EOF required')
        for key in QUERY_FIELDS:
            if not equal(subject_receipt['query'][key], selection['slots'][plan['input_slot']]['query'][key]):
                raise ValueError('subject full original query association required')
        stable_inputs()
        reference_receipt = stage('REFERENCE_FULL_VALIDATION', lambda:
            modules['reference'].reference_check_certificate(frozen_query, candidate, check=check))
        if (type(reference_receipt) is not dict or reference_receipt.get('schema') != ACTIVE_VERSIONS['reference']
                or reference_receipt.get('status') != 'VALID_DERIVATION'
                or reference_receipt.get('complete_check') is not True
                or reference_receipt.get('final_goal_equal') is not True
                or type(reference_receipt.get('query')) is not dict
                or type(reference_receipt.get('rows')) is not list):
            raise ValueError('full independent original-byte VALID_DERIVATION required')
        rows = subject_receipt['certificate']['rows']
        count = subject_receipt['certificate']['row_count']
        if (type(count) is not int or count <= 0 or len(rows) != count
                or len(reference_receipt['rows']) != count
                or producer_result['receipt']['reconstruction']['primitive_rows'] != count):
            raise ValueError('same complete primitive row count required')
        stable_inputs()
        subject_frozen = canonical(subject_receipt)
        point_receipt = stage('NONADMITTING_POINT_REDUCTION', lambda:
            modules['point_adapter'].check_rows_as_points(subject_receipt['query'],
                subject_receipt['certificate'], builders=modules['builders'], check=check))
        if (type(point_receipt) is not dict or point_receipt.get('schema') != 'FPC-H1-point-row-observation-v1'
                or point_receipt.get('complete') is not True or point_receipt.get('point_compatible') is not True
                or point_receipt.get('mismatches') != [] or type(point_receipt.get('row_count')) is not int
                or point_receipt['row_count'] != count
                or any(point_receipt.get(key) is not False for key in
                       ('proof_admitted', 'search_engine', 'GCTS_conformance'))):
            raise ValueError('complete exact explicitly nonadmitting point observation required')
        if not _checked_byte_equal(canonical(subject_receipt), subject_frozen, check):
            raise ValueError('point reduction cannot mutate original subject validator view')
        del subject_frozen
        stable_inputs()
        certificate_artifact = stage('EXPORT ORIGINAL_CERTIFICATE',
            lambda: export_original('certificate.bin', candidate))
        search_result = dict(status=producer_result['status'],
            candidate_certificate_bytes=certificate_artifact, receipt=producer_result['receipt'])
        scientific = dict(schema='FPC-cohort-backed-donor-candidate-v1', accepted=False,
            proof_admitted=False, donor_index=plan['donor_index'], input_slot=plan['input_slot'],
            query=query_artifact, certificate=certificate_artifact, primitive_rows=count,
            all3_inputs_frozen=True, fresh_full_same_original_byte_dual_validation=True,
            point_reduction_nonadmitting=True, cohort_id=COHORT_ID, qualification_rerun=False,
            holdout_searched=False, extraction_authorized=False, learned_inventory=False,
            GCTS_RL_claim=False, selected_query_certificate_committed_bytes=committed_bytes,
            cost_scope='Parent start through full cold guards/imports/selection/all3 encodings/search/'
                       'internal reconstruction/dual validators/point/export/retirement and outer custody; '
                       'only actual public compiler stats exposed; external whole admission pending')
        stable_inputs()
        verify_files(True)
        policy_check()
        source_unchanged = True
    except BaseException as error:
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            verify_files(primary is None)
            source_unchanged = True
        except BaseException as error:
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None:
            retire_positive_references()

    # One callback-free typed copy per already-published public sink, once only.
    try:
        work_snapshots = dict(schema='FPC-cohort-proof-work-snapshots-v1',
            search=_search_snapshot(search_diagnostics), compiler=_compiler_snapshot(compiler_diagnostics))
    except BaseException as error:
        if primary is None:
            primary = state['first_fault'] if state['first_fault'] is not None else error
    if primary is not None:
        retire_positive_references()
    # Normal reference retirement remains charged by the following final check.
    candidate = producer_result = queries = frozen_query = selection_frozen = frozen_inputs = None
    configuration_frozen = module_projection = projection_items = None
    modules.clear()

    def receipt():
        return dict(schema='FPC-cohort-backed-per-proof-whole-worker-v1', case_id=plan['case_id'],
            stage='acquire', donor_index=plan['donor_index'], input_slot=plan['input_slot'],
            worker_version=VERSION, status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'], elapsed_seconds=time.monotonic() - began,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            source_unchanged=source_unchanged, native_peak_bytes=0, native_requests_started=0,
            native_queries=[], native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0, scope='VACUOUS_NO_NATIVE_SUBPROCESS'),
            guard_compilations=[], work_snapshots=work_snapshots,
            qualification_complete=False, proof_admitted=False, candidate_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            input_freeze=input_freeze if primary is None else None,
            search_result=search_result if primary is None else None,
            subject_receipt=subject_receipt if primary is None else None,
            reference_receipt=reference_receipt if primary is None else None,
            point_receipt=point_receipt if primary is None else None,
            scientific_result=scientific if primary is None else None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,
            first_fault_monotonic_ns=state['first_fault_monotonic_ns'], output_rejection=output_rejection,
            normal_producer_status=normal_status, component_versions=state['versions'],
            provisional_artifacts=provisional, cohort_id=COHORT_ID,
            cohort_qualification_reused=True, old_scientific_result_reused=False,
            acquisition_status='CANDIDATE_PENDING_EXTERNAL_WHOLE_ADMISSION' if primary is None else 'STOP_ACQUISITION',
            scope='Fresh ordinary shared acquisition only. Current exact finite229 cohort provenance reused; '
                  'no qualification rerun, private compiler receipt, old scientific result, holdout search, '
                  'family extraction or GCTS/RL claim. Separate complete Root/C proof/resource/custody '
                  'admission of donor0 precedes any donor1 grant; two distinct donors or STOP.')

    try:
        if primary is None:
            policy_check()
            value = receipt()
            _validate_json_image(value, check)
            policy_check()
            body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                               separators=(',', ':')) + '\n').encode('ascii')
            policy_check()
            decide_size(body, 'ENTIRE_RESULT_JSON')
            del value
            policy_check()
        else:
            body = serialize(receipt(), CAPS['result_bytes'])
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        retire_positive_references()
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory / ('result.json' if primary is None else 'failure.json')
    if primary is None:
        # Exclusive publication/readback is still on the normal work clock.
        # A fault before publication can rebuild seven-null failure. After the
        # complete result is published, later rejection is unadmitted raw custody.
        progress = dict(phase='BEFORE_WRITE', readback_complete=False)
        try:
            _write_bank_and_readback(result_path, body, policy_check, progress)
            policy_check()
        except BaseException as error:
            if progress['phase'] == 'BEFORE_WRITE' or progress['phase'] == 'WRITING_PARTIAL':
                primary = state['first_fault'] if state['first_fault'] is not None else error
                retire_positive_references()
                body = serialize(receipt(), CAPS['result_bytes'])
                result_path = directory / 'failure.json'
                write_body(result_path, body)
            else:
                raise
    else:
        write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=plan['case_id'],
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic() - began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory / 'worker-header.json', serialize(header, CAPS['log_bytes']))
    print(json.dumps(dict(case_id=plan['case_id'], status=header['status'],
                          callbacks=state['callbacks'], seconds=time.monotonic() - began)))
    return 0 if (primary is None and source_unchanged
        and time.monotonic() - began < CAPS['positive_seconds']
        and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_cohort_backed_per_proof_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
