"""Opaque raw census only, after the owned actual handle is terminal."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
EXPERIMENT = 'signed-propositional-cohort-proof-benchmark-v1'
assert len(sys.argv) == 2 and sys.argv[1] in ('0', '1')
index = int(sys.argv[1])
case = EXPERIMENT + '-donor-' + str(index)
actual = STUDY / 'actual' / case
folders = (actual, Path(str(actual) + '.observer'))
rows = []
for folder in folders:
    assert folder.is_dir() and not folder.is_symlink()
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink()
        if not path.is_file():
            continue
        body = path.read_bytes()
        rows.append(dict(path=str(path.resolve()), bytes=len(body),
                         sha256=hashlib.sha256(body).hexdigest(),
                         partial='.partial' in path.name))
assert rows
value = dict(schema='Root-cohort-backed-per-proof-terminal-raw-census-v1',
    case_id=case, files=rows, file_count=len(rows),
    physical_bytes=sum(row['bytes'] for row in rows),
    partial_count=sum(row['partial'] for row in rows),
    partials_parsed=False, scientific_calls=0,
    scope='Complete opaque raw byte/length/hash census, no parsing/replay/admission of any body.')
target = ROOT / ('cohort-backed-per-proof-donor-' + str(index) + '-terminal-raw-census-v1.json')
with target.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(path=str(target), files=len(rows), physical_bytes=value['physical_bytes'])))
