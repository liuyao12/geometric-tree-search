"""Bounded receptor extraction/instance once caller; inert Source authorship.

Only a separately granted cold process imports seven pinned namespaces and reads
the two specifically admitted original byte pairs. No Source authorship call,
donor graph, search, holdout, private compiler receipt or library is supplied.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'FPC-receptor-extraction-library-worker-v1'
EXPERIMENT = 'two-admitted-donor-receptor-library-feasibility-v1'
PROTOCOL_SCHEMA = 'Root-FPC-receptor-library-feasibility-protocol-v1'
MODULE_ROLES = ('checker', 'builders', 'reference', 'baseline_search', 'codec', 'baseline_bank', 'producer', 'obligation_bank', 'point_adapter', 'point_bank', 'intro_bank', 'regression_bank', 'explicit_kernel', 'explicit_oracle', 'explicit_bank', 'provider', 'tiny_oracle', 'tiny_encoder', 'tiny_bank', 'controller', 'frame_oracle', 'controller_bank', 'conclusion_index_bank', 'legacy_provider', 'fixed_slot_bank', 'matched_point_controller', 'csp_controller', 'matched_controller_bank', 'selector', 'selector_bank', 'nonwrapper_selector', 'nonwrapper_selector_bank', 'signed_compiler', 'signed_producer', 'signed_bank', 'occurrence_bank', 'evidence_codec', 'evidence_codec_bank', 'extractor', 'instance', 'receptor_bank')
ACTIVE_ROLES = ('checker', 'builders', 'reference', 'tiny_encoder', 'extractor', 'instance', 'receptor_bank')
CONTROL_IDS = {'baseline56': ('codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'), 'obligation47': ('search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'), 'intro_integration1': ('producer-INTRO-local-HYP-dual-export',), 'point20': ('point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'), 'regression2': ('refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'), 'point-kernel13': ('global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'), 'point-kernel-safety3': ('normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'), 'tiny-full-provider10': ('duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'), 'full-frame-controller10': ('protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'), 'constructor-index14': ('shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'), 'fixed-free-slot8': ('rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'), 'matched-controller8': ('protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'), 'selector6': ('selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'), 'nonwrapper_selector6': ('literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'), 'signed_propositional8_successor_v2': ('compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'), 'occurrence_diagnostics9': ('unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'), 'lossless_evidence_codec8_v1': ('original-value-inverse-and221-paths', 'typed-scalars-and-integer-domain', 'canonical-sharing-order-and-occurrences', 'malformed-carriers-and-reference-refusals', 'owned-snapshot-and-public-lifecycle', 'first-callback-writer-and-retained-error', 'streamed-whole-and-path-readback', 'callable-intake-policy-and-session-isolation'), 'receptor-DAG8': ('DAG-shared-versus-unfolded', 'DAG-equal-boundary-occurrences', 'DAG-rooted-growth-and-quota', 'DAG-ordered-canonical-key', 'DAG-Formula-alias-binding', 'DAG-ordered-MP-equations', 'DAG-direct-wire-and-final-used-map', 'DAG-first-fault-and-fallback')}
CAPS = {'work_seconds': 160, 'positive_seconds': 180, 'custody_seconds': 210, 'observer_fallback_seconds': 225, 'memory_bytes': 1073741824, 'physical_bytes': 134217728, 'result_bytes': 50331648, 'log_bytes': 4194304, 'reserved_outer_bytes': 9437184, 'root_callbacks': 400000000}
COHORT_ID = 'signed-propositional-original-bank-cohort-v1'
COVERED_RUNTIME_ROLES = [{'role': 'checker', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py', 'bytes': 31557, 'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'}}, {'role': 'builders', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py', 'bytes': 11348, 'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'}}, {'role': 'reference', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py', 'bytes': 24681, 'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'}}, {'role': 'baseline_search', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_uniform_search_v1.py', 'bytes': 54407, 'sha256': '53467e578ad7b512ae66e8e03cd85dadba1ded39b9ab0012c17e7e8f170a0902'}}, {'role': 'codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_declared_query_codec_v1.py', 'bytes': 14061, 'sha256': '4c6366b1a3728608cedfd86f0c78ca38ffb9d65ffc1907b926fc5f5446ad0ab4'}}, {'role': 'baseline_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_search_controls_v2.py', 'bytes': 35231, 'sha256': 'f0c2be3c99e866aea7a62dc012c6ec96be64c6a0f9b8619a82626d04603946af'}}, {'role': 'producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_obligation_producer_v2.py', 'bytes': 105517, 'sha256': 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1'}}, {'role': 'obligation_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_independent_controls_v2.py', 'bytes': 51653, 'sha256': '309fa0c9d5c068266faf96ff2f61f3ff15874cf24b0065bc83d216fa10152280'}}, {'role': 'point_adapter', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/fpc_h1_point_rows_v2.py', 'bytes': 10972, 'sha256': '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'}}, {'role': 'point_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_point_row_independent_controls_v1.py', 'bytes': 18065, 'sha256': 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e'}}, {'role': 'intro_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_intro_integration_control_v1.py', 'bytes': 10141, 'sha256': '5390689c124393bed3ea8a19c84a1e43bb81d956945dbcebc5712b97892d90c2'}}, {'role': 'regression_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_two_defect_regressions_v1.py', 'bytes': 13618, 'sha256': '2a20fd644b8370d1f6b8f07921075c72b227dc280d9502c9259ac6ed9eb41c7b'}}, {'role': 'explicit_kernel', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/explicit_point_kernel_v2.py', 'bytes': 29002, 'sha256': '158174c8445997bedf5b17785840eb7a89dcd4d46098fcdfb35a84e2fef3849c'}}, {'role': 'explicit_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_literal_oracle_v1.py', 'bytes': 18338, 'sha256': 'ff34af27a491da3571fc02227333ca3ce048a8d7c6d49cb780d3b1c9ba14a995'}}, {'role': 'explicit_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_independent_controls_v1.py', 'bytes': 40853, 'sha256': 'eedf82a42ebae7f4133f2ee1781e33205980769f8164bd278641761e6d1a1029'}}, {'role': 'provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v6.py', 'bytes': 67637, 'sha256': '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048'}}, {'role': 'tiny_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_reference_v1.py', 'bytes': 14647, 'sha256': 'bcf281fc7e19bf8c08a5b33456a6bb2eeebb33b2034f203f1540820e5e4eff9b'}}, {'role': 'tiny_encoder', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py', 'bytes': 9018, 'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'}}, {'role': 'tiny_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_controls_v1.py', 'bytes': 30645, 'sha256': 'dadc7d7cad94fd80dbfe381e9d59f56c1af20d90149f292b9bd70ebe657442f7'}}, {'role': 'controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v1.py', 'bytes': 27604, 'sha256': 'e9198683dc830e0080fefde997e81adbcf5963c2671688b491c99bfde3ea9d61'}}, {'role': 'frame_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_frame_completion_reference_v1.py', 'bytes': 3981, 'sha256': 'e4d6f452cbda35b530fb469c10a2441bc694b523df8e46de74c96c4ab074de99'}}, {'role': 'controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/full_frame_controller_independent_controls_v2.py', 'bytes': 45831, 'sha256': '41d964fb0075cd034d64ccb98d078c6290e71d09d14ca2bc7ec004d343348f79'}}, {'role': 'conclusion_index_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/conclusion_index_independent_controls_v2.py', 'bytes': 29220, 'sha256': '3afd0cbd5c43419f7f8d23e46ef015cfd2232b2325a354e984535ccd14ad1ac5'}}, {'role': 'legacy_provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v4.py', 'bytes': 58026, 'sha256': '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'}}, {'role': 'fixed_slot_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/fixed_free_slot_independent_controls_v2.py', 'bytes': 27942, 'sha256': '8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03'}}, {'role': 'matched_point_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v3.py', 'bytes': 37990, 'sha256': '16acece30e3420a1097989c8d580d0c9cf103488ac5b3a151d3ff2fc64285fac'}}, {'role': 'csp_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_row_csp_controller_v2.py', 'bytes': 39011, 'sha256': 'c9ec1b7a54d18b6d04056cb38039434bf287711cf6f430d38c14a0a97988d59a'}}, {'role': 'matched_controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/matched_row_controller_independent_controls_v2.py', 'bytes': 62115, 'sha256': '4de67bf9eb06235b39b6bcb43a5775e9e11897620775db41a558ca55f661b13d'}}, {'role': 'selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/two_donor_input_selector_v1.py', 'bytes': 11525, 'sha256': 'a29b4ca1008b355006431584f05da9b391d22532602e7e54f14291477ef2e668'}}, {'role': 'selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/two_donor_input_selector_independent_controls_v1.py', 'bytes': 22672, 'sha256': '384aebcf362ff55da28e6bf4eec10360f50a354ad324f6423e7fdb0d3883bbf8'}}, {'role': 'nonwrapper_selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/nonwrapper_two_donor_input_selector_v1.py', 'bytes': 14767, 'sha256': '79e3faa7a63f908e94410b980c21c3e368d1672c4c318af4c822ad8462b25d83'}}, {'role': 'nonwrapper_selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/nonwrapper_selector_independent_controls_v1.py', 'bytes': 30254, 'sha256': 'a9f440295a9a9753d0983b62df056755df5adc1e88daf1c6895ce1d83a54fe2d'}}, {'role': 'signed_compiler', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_compiler_v3.py', 'bytes': 45796, 'sha256': 'e904a88fc7896f4a941ab2d4f3f37ee2af005369be30b959263a4dd5f55eda0d'}}, {'role': 'signed_producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_producer_v3.py', 'bytes': 26771, 'sha256': '3996ab4f37243c4c2ef59e27f1a2b24539414a63795de2441d938553297ee251'}}, {'role': 'signed_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/signed_propositional_independent_controls_v2.py', 'bytes': 47641, 'sha256': '1c6ec1eeea6e031cb8fd62c957f4f69f090b3b26c70c762e48c26ce3c4ce4693'}}, {'role': 'occurrence_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/occurrence_diagnostic_independent_controls_v2.py', 'bytes': 51261, 'sha256': '372f069194c488ad0067f17593636f03db9f1f820059f471491fcd12a683e6a7'}}, {'role': 'evidence_codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_lossless_evidence_codec_v3.py', 'bytes': 50486, 'sha256': '4a06aad019c6a2215ba8802e798d350190168bbda62b19d50ee6e0ff573b8143'}}, {'role': 'evidence_codec_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/lossless_evidence_independent_controls_v2.py', 'bytes': 40507, 'sha256': '1aa84e604dc5d44d43f7fa65ba76d87c2b58ee6858f2ee45a93dbdf1f12136f4'}}]
CONTROL_POPULATIONS = [{'population': 'baseline56', 'control_ids': ['codec-hi-and-exists-literal', 'codec-pa-no-profile-payload', 'codec-metadata-query-invariance', 'codec-shadowed-binder-preserved', 'codec-bool-mode-refused', 'codec-open-theorem-refused', 'codec-signature-mismatch-refused', 'codec-binder-order-refused', 'codec-extra-proof-field-refused', 'codec-retained-fault-identity', 'product-two-by-three', 'product-three-binary-slots', 'product-closed-empty', 'product-zero-arity', 'product-open-request-not-eof', 'product-staggered-arrivals', 'product-known-empty-dominates-open', 'match-formula-meta', 'match-consistent-repeat', 'match-conflicting-repeat', 'match-rigid-binder', 'match-no-alpha-renaming', 'match-term-meta', 'match-sort-conflict', 'match-variable-meta', 'match-rigid-arity-conflict', 'builder-H1-literal', 'builder-H2-literal', 'builder-H3-literal', 'builder-Q1-literal', 'builder-Q2-literal', 'builder-Q3-literal', 'builder-E1-literal', 'builder-E2-literal', 'builder-Q1-capture-refused', 'builder-Q3-free-variable-refused', 'builder-E2-capture-refused', 'builder-induction-full-parameters-refused', 'search-antecedent-first-closure', 'search-implication-first-closure', 'search-duplicate-source-aliases', 'search-cyclic-demand-no-fact', 'search-long-source-witness-not-fact', 'search-shared-DAG-export', 'search-late-GEN', 'search-full-Gamma-GEN-refusal', 'search-source-variable-outside-grammar', 'search-source-depth-outside-grammar', 'search-priority-record-invariants', 'search-cutoff-live-prefix-no-exhaustion', 'fault-product-first-ValueError', 'fault-matcher-first-StopIteration', 'fault-search-retained-owned-codec', 'fault-search-later-RuntimeError', 'fault-final-validator-first-identity', 'fault-builder-public-class-identity'], 'groups': 56, 'bank_role': 'baseline_bank', 'subject_role': 'baseline_search', 'scope': 'Unchanged original56 codec/builders/old search expectations only. Fresh controls, never claims about the new producer.'}, {'population': 'obligation47', 'control_ids': ['search-context-Gamma-present', 'search-context-Gamma-absent', 'search-context-theory-present', 'search-context-theory-absent', 'search-cycle-without-seed', 'search-premise-source-first', 'search-premise-implication-first', 'search-premise-duplicate-source', 'search-shared-context-diamond', 'guard-UI-capture-binder', 'guard-UI-closed-term-no-capture', 'guard-UI-shadowed-target-ID', 'guard-GEN-unused-Gamma-variable', 'guard-GEN-full-Gamma-clear', 'guard-GEN-unused-local-variable', 'guard-induction-wrong-profile', 'guard-induction-wrong-parameters', 'guard-induction-parameter-closure', 'compile-intro-identity', 'compile-intro-root-hypothesis', 'compile-intro-MP', 'compile-intro-GEN', 'compile-nested-equal-assumptions', 'compile-intro-finite-table', 'compile-intro-logical-axiom', 'compile-intro-PA-table', 'compile-intro-incidence-table', 'compile-intro-induction', 'compile-full-FPC-deep-term', 'compile-full-FPC-large-formula', 'refuse-MP-premise-order', 'refuse-rigid-binder-HYP', 'refuse-GEN-unused-root', 'refuse-GEN-unused-local', 'refuse-context-opener', 'refuse-forward-premise', 'refuse-duplicate-arena-row', 'product-diagonal-2x2', 'product-open-WAIT-growth', 'product-closed-empty-open-other', 'product-zero-arity', 'fault-search-first-RuntimeError', 'fault-guard-StopIteration', 'fault-compile-same-public-class', 'fault-retained-owned-through-guard', 'fault-late-compile-first-before-second', 'fault-dual-validators'], 'groups': 47, 'bank_role': 'obligation_bank', 'subject_role': 'producer', 'scope': 'Additive new synthetic query/guard/compiler/product/fault coverage with full separate current receipts.'}, {'population': 'intro_integration1', 'control_ids': ['producer-INTRO-local-HYP-dual-export'], 'groups': 1, 'bank_role': 'intro_bank', 'subject_role': 'producer', 'scope': 'Synthetic search-only discovery of current-context INTRO/localHYP and primitive compiler/dual validation integration; not a six-goal theorem.'}, {'population': 'point20', 'control_ids': ['point-HYP-MP-agreement', 'point-wrong-MP-mark-conflict', 'point-final-goal-boundary-conflict', 'point-GEN-agreement', 'point-GEN-source-mark-conflict', 'point-GEN-unused-Gamma-refusal', 'point-HYP-declared-conclusion-refusal', 'point-LOGICAL-declared-conclusion-refusal', 'point-THEORY-profile-refusal', 'point-MP-forward-reference-refusal', 'point-MP-coincident-port-refusal', 'point-repeated-remote-port-agreement', 'point-long-range-mark-only-agreement', 'point-LOGICAL-Q3-agreement', 'point-THEORY-finite-agreement', 'point-first-RuntimeError-identity', 'point-first-public-refusal-class-identity', 'point-first-StopIteration-identity', 'point-later-first-fault-and-immutability', 'point-retained-family-refusal-identity'], 'groups': 20, 'bank_role': 'point_bank', 'subject_role': 'point_adapter', 'scope': 'Current parametric point-row representation only, no parser or search/graph qualification.'}, {'population': 'regression2', 'control_ids': ['refuse-extra-INTRO-reused-owned-context', 'constructor-StopIteration-first-fault-and-owned-cleanup'], 'groups': 2, 'bank_role': 'regression_bank', 'subject_role': 'producer', 'scope': 'Exact malformed ownership and public-phase first-StopIteration regressions only; cleanup remains Source/whole custody authority.'}, {'population': 'point-kernel13', 'control_ids': ['global-dead-before-forced', 'global-forced-before-earlier-branch', 'generation-before-degree', 'remote-mark-only-zero-is-assigned', 'remote-conflict-dead-before-other-force', 'shared-fractional-placement-once', 'distinct-inventory-identical-point-functions', 'rollback-parent-exclusion', 'mark-reference-count-rollback', 'generation-minimum-rollback', 'outside-support-global-legality', 'lazy-prefix-not-singleton', 'frame-boundary-growth'], 'groups': 13, 'bank_role': 'explicit_bank', 'subject_role': 'explicit_kernel', 'scope': 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'}, {'population': 'point-kernel-safety3', 'control_ids': ['normal-refusal-and-input-ownership', 'checkpoint-path-and-cursor-ownership', 'first-fault-and-retained-owned-identity'], 'groups': 3, 'bank_role': 'explicit_bank', 'subject_role': 'explicit_kernel', 'scope': 'Generic explicit graph13 or safety3 only; not full logical provider/controller proof validation.'}, {'population': 'tiny-full-provider10', 'control_ids': ['duplicate-HYP-table-full-domain', 'GEN-full-formula-valued-identities', 'MP-full-formula-valued-identities', 'E1-singleton-requires-full-EOF', 'full-Gamma-outside-envelope-blocks-GEN', 'full-Gamma-unblocked-GEN-counterpart', 'out-of-envelope-goal-stays-boundary', 'remote-ports-rebind-retained-parent', 'initial-inspection-not-tried-remainder', 'inventory-first-fault-no-prefix'], 'groups': 10, 'bank_role': 'tiny_bank', 'subject_role': 'provider', 'scope': 'Restricted profile0,b<=3,n<=4 full-row membership; not all-FPC runtime qualification. Current provider subject is5; only the original explicitly scoped facets are tested.'}, {'population': 'full-frame-controller10', 'control_ids': ['protocol-dead-before-forced', 'protocol-no-forcing-unresolved', 'protocol-global-single-before-earlier-branch', 'protocol-parent-offer-remainder', 'protocol-fuel-not-child-failure', 'protocol-first-fault-no-normal-result', 'real-tiny-candidate-frame-agreement', 'real-tiny-empty-frame-agreement', 'dovetail-first-prefix-budget-restarts', 'public-strict-int-and-input-identity'], 'groups': 10, 'bank_role': 'controller_bank', 'subject_role': 'controller', 'scope': 'Protocol stubs/schedule/intake plus separately identified real tiny positive/empty/reuse facets; no theorem discovery authority. Current provider subject is5; only the original explicitly scoped facets are tested.'}, {'population': 'constructor-index14', 'control_ids': ['shape-H1-ancestor-descendant', 'shape-H2-ancestor-descendant', 'shape-H3-ancestor-descendant', 'shape-Q1-ancestor-descendant', 'shape-Q2-ancestor-descendant', 'shape-Q3-ancestor-descendant', 'shape-E1-ancestor-descendant', 'shape-E2-ancestor-descendant', 'shape-induction-empty-prefix-core', 'shape-induction-nonempty-prefix-core', 'helper-first-fault-identities', 'public-cursor-first-fault-poison', 'public-tiny-identities-order-remainders', 'public-incompatible-shape-EOF'], 'groups': 14, 'bank_role': 'conclusion_index_bank', 'subject_role': 'legacy_provider', 'scope': 'New separately scoped necessary-predicate54 literal cases across10 groups, helper faults, Source-bound public fault/poison, original tiny full-identity/order/remainder/SINGLE EOF and new generic empty single-row b5. Not a public full-profile inventory equivalence, scheduler, cleanup, practical benefit or proof-admission qualification. Original26 declarations remain distinct and unchanged. Subject is separately imported exact provider4, never current6.'}, {'population': 'fixed-free-slot8', 'control_ids': ['rigid-visible-logical-equations', 'Q1-free-terms-public-order-EOF', 'E2-free-body-binder-forward-aliases', 'induction-prefix-singleton-forward', 'MP-fixed-B-reset-unfilled-reference-order', 'GEN-full-Gamma-unfilled-reference-domain', 'absent-output-typed-slots-source-aliases', 'restriction-first-fault-parent-remainder'], 'groups': 8, 'bank_role': 'fixed_slot_bank', 'subject_role': 'provider', 'scope': 'Independent private rigid equation/typed-slot plus public tiny full identity/order/EOF/remainder/fault controls; legacy4 only common literal-set/order comparison. No all26 or full-profile/large-E2/cleanup/performance authority.'}, {'population': 'matched-controller8', 'control_ids': ['protocol-global-dead-before-singleton', 'protocol-unresolved-row-ties-no-MRV', 'protocol-remote-dependency-and-exact-undo', 'protocol-owned-offer-remainder-backtrack', 'protocol-phase-fuel-first-fault-and-diagnostics', 'real-duplicate-identities-and-empty-EOF', 'real-E1-two-row-Cartesian-reuse', 'real-full-Gamma-remote-contradictions'], 'groups': 8, 'bank_role': 'matched_controller_bank', 'subject_role': 'csp_controller', 'scope': 'Five independent protocol groups and three real provider6 facets for BOTH matched_point_controller and csp_controller; same49field observation and common14phase clock. Oracle complete tiny sets, driver first exports only. No all-profile equivalence or cleanup/fault-sweep proof.'}, {'population': 'selector6', 'control_ids': ['selector-tree-order', 'selector-atom-renaming', 'selector-Boolean-eligibility', 'selector-single-axiom-exclusion', 'selector-distinct-prefix-and-stop', 'selector-envelope-and-first-fault'], 'groups': 6, 'bank_role': 'selector_bank', 'subject_role': 'selector', 'scope': 'Fresh independent input-only prefix/Boolean/pattern/slot/fault qualification. No proof/query-byte/producer authority; STOP branch runtime coverage remains explicit. Original192 scope objects unchanged.'}, {'population': 'nonwrapper_selector6', 'control_ids': ['literal-helper-facts', 'canonical-occurrence-and-copying', 'malformed-envelope-owned-refusals', 'complete-ordered-winning-prefixes', 'first-and-retained-callback-identity', 'fresh-call-and-slot-isolation'], 'groups': 6, 'bank_role': 'nonwrapper_selector_bank', 'subject_role': 'nonwrapper_selector', 'scope': 'New selector public endpoint controls only; selected control slots are not research input authority.'}, {'population': 'signed_propositional8_successor_v2', 'control_ids': ['compiler-signed-rules-and-source-occurrences', 'strict-invalid-tree-refusals', 'search-closed-rule-counts-and-primitive-validation', 'total-countermodels-and-second-split-branch', 'malformed-unsupported-mode-and-EOF', 'configuration-module-and-owned-refusals', 'normal-FINAL-counts-and-owned-snapshot-isolation', 'first-retained-fault-and-stale-diagnostic-identity'], 'groups': 8, 'bank_role': 'signed_bank', 'subject_role': 'signed_producer', 'scope': 'Exact original8 semantic obligations/IDs on explicit compiler Source3 publicVERSION2, producer Source3 VERSION2 and signed-bank2. No retargeting/admission/retry of failed legacy1.'}, {'population': 'occurrence_diagnostics9', 'control_ids': ['unused-LOCAL-root-and-both-split-branches', 'equal-LOCAL-used-outer-unused-inner', 'shared-original-source-boundary', 'ordered-Gamma-and-finite-table-aliases', 'LOCAL-equal-to-surviving-root-Gamma', 'nested-composite-LOCAL-substitution', 'exact-diagnostic-intake-refusals', 'normal-FINAL-transport-and-no-compiler-paths', 'first-callback-retained-and-malformed-sink-identity'], 'groups': 9, 'bank_role': 'occurrence_bank', 'subject_role': 'signed_producer/signed_compiler', 'scope': 'Nine additional independently authored occurrence/mathematical/diagnostic groups; Source2 bank VERSION1/98 fixed direct call locators. Complete only after all facets, no research proof or legacy-prefix authority.'}, {'population': 'lossless_evidence_codec8_v1', 'control_ids': ['original-value-inverse-and221-paths', 'typed-scalars-and-integer-domain', 'canonical-sharing-order-and-occurrences', 'malformed-carriers-and-reference-refusals', 'owned-snapshot-and-public-lifecycle', 'first-callback-writer-and-retained-error', 'streamed-whole-and-path-readback', 'callable-intake-policy-and-session-isolation'], 'groups': 8, 'bank_role': 'evidence_codec_bank', 'subject_role': 'evidence_codec', 'scope': 'Complete codec-only synthetic transport controls; not original221 scientific observations or proof admission. Full genuine observations retained separately.'}]
SCIENTIFIC_RAW_INPUTS = [{'rawpin': {'bytes': 8614, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/first-fixed-verifier-target-declarations-v1.json', 'sha256': 'c6ae5f616b61e85f4b5cbd2b1e7619c047f42d83afd725e277475292cd904b0a'}, 'role': 'six_declarations', 'scope': 'Exact original six public statements; no known proof, hint, lemma or certificate', 'plan_key': 'declarations'}, {'rawpin': {'bytes': 7910, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/first-fixed-verifier-search-targets-v3.json', 'sha256': '2e7cc31d6e72107d3811cf6a980ec261e0122c8736d4520db9cea119317eb54d'}, 'role': 'target_authority_reference', 'scope': 'Historical public input/six-field declaration authority Source context only. Does not authorize this new point-study actual; fresh Root protocol required.', 'plan_key': 'target_authority'}, {'rawpin': {'bytes': 15516, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/point-proof-independent-raw-models-v1.json', 'sha256': '18851c3488152f3743a61eacafc12322c94c48f98038cccf01bd95482793225a'}, 'role': 'explicit_raw13', 'scope': 'Declared literal model inputs only; no prior output', 'plan_key': 'explicit_raw_models'}, {'rawpin': {'bytes': 16186, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny-full-provider-inputs-and-expectations-v1.json', 'sha256': 'bd3cefe3f86700f0909d605bcac480e4c0f941dafc529716f68b20350699d708'}, 'role': 'tiny_seven_declarations', 'scope': 'New independent literals, not old result/accepting proof intake', 'plan_key': 'tiny_provider_declarations'}, {'role': 'conclusion_index_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/conclusion-index-control-literal-data-v1.json', 'bytes': 13490, 'sha256': 'b23d97e5bce2c28e288742d9173787905e0b18ce804cde7a1dc39e3db20695e2'}, 'scope': 'Independent literal14-group/54-white-box-case declaration input only. Not the unchanged26 semantic declarations, a target proof, accepting output or prior qualification.', 'plan_key': 'conclusion_index_fixtures'}, {'role': 'fixed_free_slot_fixtures', 'plan_key': 'fixed_free_slot_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/fixed-free-output-independent-equation-declarations-v1.json', 'bytes': 36196, 'sha256': '9b2d64e844900e3a5741e0792690bbf58f36ba2a3667d96ef9159d5d9911661a'}, 'scope': 'Complete pre-implementation independent26 equation/coverage declarations; new bank consumes exact value. Not a prior result, target proof or runtime generated fixture.'}, {'role': 'matched_controller_fixtures', 'plan_key': 'matched_controller_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/matched-row-CSP-point-independent-declarations-v1.json', 'bytes': 20281, 'sha256': '71078f5a170cda30c3f7b2d6a699e9c260793f6c8d591316076f6bb86c3ee898'}}, {'role': 'nonwrapper_selector_fixtures', 'plan_key': 'nonwrapper_selector_fixtures', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/nonwrapper-selector-independent-literal-expectations-v1.json', 'bytes': 24228, 'sha256': '08770968af3ed99206e48c2b8d93be6471c5b730f96a091bf1ea688465c12082'}, 'scope': 'Fresh immutable independent literal selector controls; Source/provenance only, no old selected input or proof.'}]
CUSTODY_RUNTIME = {'runner': {'bytes': 12973, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/run_conditional_once_v1.py', 'sha256': '98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'}, 'observer': {'bytes': 10113, 'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021/root/observe_conditional_once_v1.py', 'sha256': '24804c7d4558d8df511942d9e6b2e4d8d2cfd88ce7df6f5b5f775f87d0c20ca9'}, 'python': {'bytes': 18058560, 'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'sha256': 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'}}
ENVIRONMENT = {'platform': 'darwin', 'python_implementation': 'cpython', 'python_version': '3.12.14', 'flags': ['-I', '-S', '-B']}
POLICY_RULE = 'BIND_EFFECTIVE_REFERENCE_AFTER_GENUINE_CHECK_AND_REQUIRE_STABLE_NORMAL_EXPORT_GATES'
POLICY_BINDING = ('FPC-original-json-integer-policy-v1', 4300)
QUALIFIER_CALLER_PINS = {'worker': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_original_bank_cohort_qualification_worker_v2.py', 'bytes': 109375, 'sha256': '0eb50870aa2393ebd7ab3592080b7947f7ede8817daa15d5a89f90b9e08fce61'}, 'API': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-API-v2.json', 'bytes': 53978, 'sha256': 'cc86695071689bd29ae47b306fafb9ad3e191575e0d2386e9811e94069f47fe1'}, 'offer': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-dependency-offer-v2-r2.json', 'bytes': 111150, 'sha256': 'b2f42b217a475c78a7699cee24a77c2df8a03fa10aee1bb72c0f60f896d0fa87'}, 'handoff': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/original-bank-cohort-qualification-worker-Source-handoff-v2-r2.json', 'bytes': 8027, 'sha256': 'e19da899dbabde85a0afec5d4bd05d294a377db7709c48347871760018b5caf7'}}
QUALIFIER_CONTRACT_PINS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/cohort-original-bank-files-and-per-proof-CONTRACT-offer-v2.json', 'bytes': 27923, 'sha256': 'a440259e7a05998958ef83e2af87e355d3ad46e4781113e52e8c4b2c83c15470'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-Root-concrete-contract-and-Source-authorship-v2.json', 'bytes': 10668, 'sha256': 'd108b11dd228ddfbaf107cd6d812c78af4d8e448ac5abfd63559d30709946a1d'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/complete-cohort-per-proof-independent-acceptance-requirements-v2.json', 'bytes': 15660, 'sha256': 'b5411a696fd5650a0b11611a00bde1f9de803f7fe82e72ab8af59c8de4d732a6'}]
DESCRIPTOR_FIELDS = ('schema', 'cohort_id', 'covered_runtime_roles', 'control_populations', 'raw_inputs', 'qualification_caller_pins', 'qualifier_contract_pins', 'custody_runtime', 'source_closure', 'environment', 'limits', 'output_limits', 'policy_rule')
QUERY_FIELDS = ('version', 'claim_mode', 'function_arities', 'predicate_arities', 'theory_profile', 'finite_axioms', 'Gamma', 'goal')
ALL_RUNTIME_ROLES = [{'role': 'checker', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py', 'bytes': 31557, 'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'}}, {'role': 'builders', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py', 'bytes': 11348, 'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'}}, {'role': 'reference', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py', 'bytes': 24681, 'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'}}, {'role': 'baseline_search', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_uniform_search_v1.py', 'bytes': 54407, 'sha256': '53467e578ad7b512ae66e8e03cd85dadba1ded39b9ab0012c17e7e8f170a0902'}}, {'role': 'codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_declared_query_codec_v1.py', 'bytes': 14061, 'sha256': '4c6366b1a3728608cedfd86f0c78ca38ffb9d65ffc1907b926fc5f5446ad0ab4'}}, {'role': 'baseline_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_search_controls_v2.py', 'bytes': 35231, 'sha256': 'f0c2be3c99e866aea7a62dc012c6ec96be64c6a0f9b8619a82626d04603946af'}}, {'role': 'producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_obligation_producer_v2.py', 'bytes': 105517, 'sha256': 'fa135ec9e84cdb84b0be506d74a1f167e619b7ac82fcb6a1d8b8782c738523d1'}}, {'role': 'obligation_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_independent_controls_v2.py', 'bytes': 51653, 'sha256': '309fa0c9d5c068266faf96ff2f61f3ff15874cf24b0065bc83d216fa10152280'}}, {'role': 'point_adapter', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/root/fpc_h1_point_rows_v2.py', 'bytes': 10972, 'sha256': '57eac1681fbb9e3a6494109a1b9ca43cbfa4d5bfc25ce87954537ae801acf32f'}}, {'role': 'point_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_point_row_independent_controls_v1.py', 'bytes': 18065, 'sha256': 'd49e554bc24fba8539224b7f4099e2f089639f36245a9ed4e47fc2753e7d387e'}}, {'role': 'intro_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_intro_integration_control_v1.py', 'bytes': 10141, 'sha256': '5390689c124393bed3ea8a19c84a1e43bb81d956945dbcebc5712b97892d90c2'}}, {'role': 'regression_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_obligation_two_defect_regressions_v1.py', 'bytes': 13618, 'sha256': '2a20fd644b8370d1f6b8f07921075c72b227dc280d9502c9259ac6ed9eb41c7b'}}, {'role': 'explicit_kernel', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/explicit_point_kernel_v2.py', 'bytes': 29002, 'sha256': '158174c8445997bedf5b17785840eb7a89dcd4d46098fcdfb35a84e2fef3849c'}}, {'role': 'explicit_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_literal_oracle_v1.py', 'bytes': 18338, 'sha256': 'ff34af27a491da3571fc02227333ca3ce048a8d7c6d49cb780d3b1c9ba14a995'}}, {'role': 'explicit_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/explicit_point_independent_controls_v1.py', 'bytes': 40853, 'sha256': 'eedf82a42ebae7f4133f2ee1781e33205980769f8164bd278641761e6d1a1029'}}, {'role': 'provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v6.py', 'bytes': 67637, 'sha256': '39da5195f815da0cceddd11b4d4b25671a50e926ca1885ccc3add6cd99a8d048'}}, {'role': 'tiny_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_reference_v1.py', 'bytes': 14647, 'sha256': 'bcf281fc7e19bf8c08a5b33456a6bb2eeebb33b2034f203f1540820e5e4eff9b'}}, {'role': 'tiny_encoder', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py', 'bytes': 9018, 'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'}}, {'role': 'tiny_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_provider_controls_v1.py', 'bytes': 30645, 'sha256': 'dadc7d7cad94fd80dbfe381e9d59f56c1af20d90149f292b9bd70ebe657442f7'}}, {'role': 'controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v1.py', 'bytes': 27604, 'sha256': 'e9198683dc830e0080fefde997e81adbcf5963c2671688b491c99bfde3ea9d61'}}, {'role': 'frame_oracle', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_frame_completion_reference_v1.py', 'bytes': 3981, 'sha256': 'e4d6f452cbda35b530fb469c10a2441bc694b523df8e46de74c96c4ab074de99'}}, {'role': 'controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/full_frame_controller_independent_controls_v2.py', 'bytes': 45831, 'sha256': '41d964fb0075cd034d64ccb98d078c6290e71d09d14ca2bc7ec004d343348f79'}}, {'role': 'conclusion_index_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/conclusion_index_independent_controls_v2.py', 'bytes': 29220, 'sha256': '3afd0cbd5c43419f7f8d23e46ef015cfd2232b2325a354e984535ccd14ad1ac5'}}, {'role': 'legacy_provider', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_full_frame_inventory_v4.py', 'bytes': 58026, 'sha256': '7fc9ebe143513fa86e726c78832cdbb91589fbd9e8a5d2b21eb3183a5fbf5fd2'}}, {'role': 'fixed_slot_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/fixed_free_slot_independent_controls_v2.py', 'bytes': 27942, 'sha256': '8a7b33c8729d6c9f40c9354058bbbef24568e885ec8bccf6d12fae04bdf8be03'}}, {'role': 'matched_point_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/root/fpc_point_frame_controller_v3.py', 'bytes': 37990, 'sha256': '16acece30e3420a1097989c8d580d0c9cf103488ac5b3a151d3ff2fc64285fac'}}, {'role': 'csp_controller', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/implementation-B/fpc_row_csp_controller_v2.py', 'bytes': 39011, 'sha256': 'c9ec1b7a54d18b6d04056cb38039434bf287711cf6f430d38c14a0a97988d59a'}}, {'role': 'matched_controller_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/matched_row_controller_independent_controls_v2.py', 'bytes': 62115, 'sha256': '4de67bf9eb06235b39b6bcb43a5775e9e11897620775db41a558ca55f661b13d'}}, {'role': 'selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/two_donor_input_selector_v1.py', 'bytes': 11525, 'sha256': 'a29b4ca1008b355006431584f05da9b391d22532602e7e54f14291477ef2e668'}}, {'role': 'selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/two_donor_input_selector_independent_controls_v1.py', 'bytes': 22672, 'sha256': '384aebcf362ff55da28e6bf4eec10360f50a354ad324f6423e7fdb0d3883bbf8'}}, {'role': 'nonwrapper_selector', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/nonwrapper_two_donor_input_selector_v1.py', 'bytes': 14767, 'sha256': '79e3faa7a63f908e94410b980c21c3e368d1672c4c318af4c822ad8462b25d83'}}, {'role': 'nonwrapper_selector_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/nonwrapper_selector_independent_controls_v1.py', 'bytes': 30254, 'sha256': 'a9f440295a9a9753d0983b62df056755df5adc1e88daf1c6895ce1d83a54fe2d'}}, {'role': 'signed_compiler', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_compiler_v3.py', 'bytes': 45796, 'sha256': 'e904a88fc7896f4a941ab2d4f3f37ee2af005369be30b959263a4dd5f55eda0d'}}, {'role': 'signed_producer', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_h1_signed_producer_v3.py', 'bytes': 26771, 'sha256': '3996ab4f37243c4c2ef59e27f1a2b24539414a63795de2441d938553297ee251'}}, {'role': 'signed_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/signed_propositional_independent_controls_v2.py', 'bytes': 47641, 'sha256': '1c6ec1eeea6e031cb8fd62c957f4f69f090b3b26c70c762e48c26ce3c4ce4693'}}, {'role': 'occurrence_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/occurrence_diagnostic_independent_controls_v2.py', 'bytes': 51261, 'sha256': '372f069194c488ad0067f17593636f03db9f1f820059f471491fcd12a683e6a7'}}, {'role': 'evidence_codec', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_lossless_evidence_codec_v3.py', 'bytes': 50486, 'sha256': '4a06aad019c6a2215ba8802e798d350190168bbda62b19d50ee6e0ff573b8143'}}, {'role': 'evidence_codec_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/lossless_evidence_independent_controls_v2.py', 'bytes': 40507, 'sha256': '1aa84e604dc5d44d43f7fa65ba76d87c2b58ee6858f2ee45a93dbdf1f12136f4'}}, {'role': 'extractor', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_family_extractor_v2.py', 'bytes': 49786, 'sha256': 'ceb2ddcff515434f362960cd72acb20dd76f9af3c95a912489545b5e0eeaa734'}}, {'role': 'instance', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_instance_service_v2.py', 'bytes': 46609, 'sha256': '7b7ca98d3e3dd2e48680d5f499594a8ec7322753bf7a6e8511d5cc667526fae9'}}, {'role': 'receptor_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/fpc_receptor_dag_independent_bank_v1.py', 'bytes': 53547, 'sha256': 'ee823c3ca2ac18c238cd510a940a4489c427c8bda053555ed34a5c803dc1e4d7'}}]
ACTIVE_RUNTIME_ROLES = [{'role': 'checker', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_byte_checker_v1.py', 'bytes': 31557, 'sha256': '140a9c4b7a6a18c4c20aa4294a0f3fa90f65fe319adbf47a22125170f32b2ef7'}}, {'role': 'builders', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/implementation-B/fpc_h1_ast_and_builders_v1.py', 'bytes': 11348, 'sha256': 'a42aa71f1e5482a1e1d9637290b4c7f8b52f366d86f7234a86cb11420171ed32'}}, {'role': 'reference', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-fixed-wang-compiler-20261021/diagnostics-L/fpc_h1_independent_reference_v2.py', 'bytes': 24681, 'sha256': 'ecda2a10feb69e5aed6ae34dc6c2123dbbc3297ab5c0a431861d628e9cd4334a'}}, {'role': 'tiny_encoder', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-point-proof-search-20261022/diagnostics-L/tiny_fpc_query_encoder_v1.py', 'bytes': 9018, 'sha256': '154615acacc813239d6cf005c82aa37fce96e631098f6408a8798a981a08455d'}}, {'role': 'extractor', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_family_extractor_v2.py', 'bytes': 49786, 'sha256': 'ceb2ddcff515434f362960cd72acb20dd76f9af3c95a912489545b5e0eeaa734'}}, {'role': 'instance', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/fpc_receptor_instance_service_v2.py', 'bytes': 46609, 'sha256': '7b7ca98d3e3dd2e48680d5f499594a8ec7322753bf7a6e8511d5cc667526fae9'}}, {'role': 'receptor_bank', 'rawpin': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/fpc_receptor_dag_independent_bank_v1.py', 'bytes': 53547, 'sha256': 'ee823c3ca2ac18c238cd510a940a4489c427c8bda053555ed34a5c803dc1e4d7'}}]
ACTIVE_VERSIONS = {'checker': 'FPC-H1-BYTE-CHECKER-v1', 'builders': 'FPC-H1-AST-BUILDERS-v1', 'reference': 'FPC-H1-independent-flat-reference-v2', 'tiny_encoder': 'L-tiny-FPC-query-encoder-v1', 'extractor': 'FPC-RECEPTOR-FAMILY-EXTRACTOR-v2', 'instance': 'FPC-RECEPTOR-INSTANCE-SERVICE-v2', 'receptor_bank': 'FPC-RECEPTOR-DAG-INDEPENDENT-BANK-v1'}
CONFIGURATION = {'schema': 'FPC-propositional-receptor-extraction-v1', 'min_nodes': 2, 'max_nodes': 8, 'per_donor_quota': 2, 'library_quota': 4, 'max_distinct_boundary_nodes': 4, 'policy': 'ordered-ancestor-growth-v1'}
CONTRACT_PINS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-CONTRACT-offer-v1.json', 'bytes': 27835, 'sha256': 'bc65b1e8ee828da33713ef504465311fb6afc0626cd5db7614fc4148de01d2f7'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-entry-ABI-addendum-v1.json', 'bytes': 2132, 'sha256': '8d14f4a641560d1371b8c99d05a8d80fd251730c7ab82d97833a4b7ca126d49f'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-admission-flag-addendum-v1.json', 'bytes': 2008, 'sha256': 'ac9a2a2b5004d0230574a33319df02f7c659c1f6ff261b098178468f6e93dfea'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-library-Root-effective-contract-and-caller-Source-authorship-v1.json', 'bytes': 5687, 'sha256': '1173ecd8432c7dbdae5107153960d550a44e6532e466c54936d57a6883cf1722'}]
METADATA_PINS = {'cohort_descriptor': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-descriptor-v1.json', 'bytes': 183415, 'sha256': '6fc9c3d4c55c916182a86b08c185449bd7fbbfaf0f421f3fe0aad7b793eb9414'}, 'cohort_disposition': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/original-bank-cohort-Root-complete-whole-disposition-v1.json', 'bytes': 6530, 'sha256': 'b07a9b5b8f09e183a15423ff82b5971bb5a42e0c5c0206f77a4ea2302a4e80de'}, 'cohort_C_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-original-bank-cohort-complete-whole-actual-review-v1.json', 'bytes': 24339, 'sha256': '8eedade128c051165b884e21646ec9d1257d73ca81b889d9abaf4b4df9a335f3'}, 'donor_pair_authority': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-two-donor-Root-complete-disposition-v1.json', 'bytes': 3447, 'sha256': '9769265b35a0381585270a7f59ea2365a394a80513dfcf3fd7c308f1e0bdf99d'}}
REQUIRED_METADATA_GUARDS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-CONTRACT-offer-v1.json', 'bytes': 27835, 'sha256': 'bc65b1e8ee828da33713ef504465311fb6afc0626cd5db7614fc4148de01d2f7'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-entry-ABI-addendum-v1.json', 'bytes': 2132, 'sha256': '8d14f4a641560d1371b8c99d05a8d80fd251730c7ab82d97833a4b7ca126d49f'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-library-bounded-caller-admission-flag-addendum-v1.json', 'bytes': 2008, 'sha256': 'ac9a2a2b5004d0230574a33319df02f7c659c1f6ff261b098178468f6e93dfea'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-library-Root-effective-contract-and-caller-Source-authorship-v1.json', 'bytes': 5687, 'sha256': '1173ecd8432c7dbdae5107153960d550a44e6532e466c54936d57a6883cf1722'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-family-Source2-Root-component-and-bank-Source-acceptance-v1.json', 'bytes': 7603, 'sha256': '9d316fdd9d782da4390e1985a491a85d97cfb15d1ae36e20f367ab7522995670'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/receptor-DAG8-bank-Root-component-acceptance-v1.json', 'bytes': 6650, 'sha256': '9fc3166351286d9e275dfd874b3b03aed64ef3276043cc76acfc9dead452c5ef'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-receptor-DAG8-independent-bank-complete-component-Source-review-v1.json', 'bytes': 11987, 'sha256': 'e0a99570d6f136c88fa6438b88d47850cc6209d8fc305ee90bae21bb30abaed2'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-two-admitted-donor-receptor-extractor-instance-complete-successor-Source-review-v2.json', 'bytes': 13307, 'sha256': '8f762d2787bd307115b28f60b57032164ca7d408f32361c1ebb12d9549179412'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-family-and-instance-API-v2.json', 'bytes': 27122, 'sha256': '74f10ef380e7a86c145d18e3e27f12aefedbaeebf55f2bf7853fded14275a917'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/implementation-B/receptor-family-and-instance-Source-handoff-v2.json', 'bytes': 10772, 'sha256': '3181a5a4dac2431bcc2188a4e79874b31c0958f61ece09a24a1419b924f38016'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/receptor-DAG-independent-bank-API-v1.json', 'bytes': 8356, 'sha256': '9a70d7fbca6a38a4e1993f834017e765ef5fc3cb888cda50da7f135b72b300d2'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/receptor-DAG-independent-bank-Source-handoff-v1.json', 'bytes': 3826, 'sha256': '23d0661f2057d1368bae2b491211c36e4b3828e233b4a36d231235490604bbe7'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/diagnostics-L/receptor-DAG-independent-bank-coverage-v1.json', 'bytes': 7457, 'sha256': '7804258ba16bf8ad200bd3d768e01ec99216568ae6f1f8f4871a1d459fde5607'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/plans/signed-propositional-cohort-proof-benchmark-v1-donor-0.json', 'bytes': 195083, 'sha256': '7539fe80fbf50c353dcc655b867cdd0ae73a4d4a4784549326f63b3fb85e03f1'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json', 'bytes': 8205, 'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-0-complete-whole-actual-review-v1.json', 'bytes': 16253, 'sha256': '7f02e115b155bb9331dd9625714226d60aaef29e021c13873f7f780409e28ba9'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-1-Root-complete-whole-admission-v1.json', 'bytes': 9272, 'sha256': '0c0ad2007f61f476d0230da74ba377602543e844cc53ba25fc895f0a49ac5feb'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-1-complete-whole-actual-review-v1.json', 'bytes': 17983, 'sha256': '8408d8731fb620ededc0b30206d4685ec409794406fec59ceb318ce633034b25'}]
GUARD_FLOOR_PLAN_PIN = {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/plans/signed-propositional-cohort-proof-benchmark-v1-donor-0.json', 'bytes': 195083, 'sha256': '7539fe80fbf50c353dcc655b867cdd0ae73a4d4a4784549326f63b3fb85e03f1'}
DONOR_ADMISSION_PINS = [{'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json', 'bytes': 8205, 'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'}, {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-1-Root-complete-whole-admission-v1.json', 'bytes': 9272, 'sha256': '0c0ad2007f61f476d0230da74ba377602543e844cc53ba25fc895f0a49ac5feb'}]
DONOR_INPUTS = [{'donor_id': 'donor0', 'Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-0-Root-complete-whole-admission-v1.json', 'bytes': 8205, 'sha256': '5e43a84fb44d32dc78aba88456d73524b94eb5895e3b591b5abdddbafb6d3570'}, 'C_actual_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-0-complete-whole-actual-review-v1.json', 'bytes': 16253, 'sha256': '7f02e115b155bb9331dd9625714226d60aaef29e021c13873f7f780409e28ba9'}, 'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/query.bin', 'bytes': 30, 'sha256': '353d584927c405f1350729890920dee7265f03f3af148855e171c4cc52e77169'}, 'certificate': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-0/certificate.bin', 'bytes': 104490, 'sha256': 'c91a47c2ff3ec42a13db73f84f0b7b373205a3b766025b664c21dfb2027e83c1'}}, {'donor_id': 'donor1', 'Root_admission': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/root/cohort-backed-per-proof-donor-1-Root-complete-whole-admission-v1.json', 'bytes': 9272, 'sha256': '0c0ad2007f61f476d0230da74ba377602543e844cc53ba25fc895f0a49ac5feb'}, 'C_actual_review': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/review-C/typed-cohort-backed-per-proof-donor-1-complete-whole-actual-review-v1.json', 'bytes': 17983, 'sha256': '8408d8731fb620ededc0b30206d4685ec409794406fec59ceb318ce633034b25'}, 'query': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-1/query.bin', 'bytes': 37, 'sha256': 'de00382d25dc4a96696ce98fc7bfa95c87ef9c8a51440390fa0e4cb6d3c063b5'}, 'certificate': {'path': '/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-receptor-acquisition-20261022/actual/signed-propositional-cohort-proof-benchmark-v1-donor-1/certificate.bin', 'bytes': 262088, 'sha256': 'fbe1f4429a6023c25e951d3edba81b3dc57c25a9c8743909bc81ade043b80e1b'}}]
APPLICABILITY_FIELDS = ('schema', 'cohort_id', 'descriptor', 'Root_disposition', 'C_review', 'covered_runtime_roles', 'control_populations', 'raw_inputs', 'active_runtime_roles', 'custody_runtime', 'environment', 'reference_integer_policy', 'limits', 'donor_pair_authority', 'contract_pins', 'caller_pins', 'accepted', 'qualification_rerun')
PROTOCOL_METADATA_FIELDS = ('cohort_descriptor', 'cohort_disposition', 'cohort_C_review', 'library_applicability', 'donor_pair_authority', 'donor_inputs', 'extraction_configuration')
RECIPES = [{'case_id': 'two-admitted-donor-receptor-library-feasibility-v1-extract-0', 'stage': 'extract'}]
BANK_FIELDS = ('schema', 'version', 'population', 'complete', 'control_ids', 'controls', 'counts', 'scope', 'coverage_limits')
BANK_SCOPE = 'Independent synthetic public DAG extraction/instance controls; no donor, library, final-use or GCTS/RL admission.'
BANK_COVERAGE_LIMITS = ['All original DAG8 declarations remain; schematic property graphs are not passed as valid certificates.', 'Shared/large supplied families test service support, not acquisition by the unchanged first-two policy.', 'Final used-expansion, primitive fallback, scheduler transactions, overlap reward and all-cutoff cleanup are UNEXERCISED future-consumer/Source obligations.', 'No forced digest collision, all-subgraph census, real donor extraction, holdout, performance or whole-admission claim.']
NEW_BANK_POPULATION = {'population': 'receptor-DAG8', 'control_ids': ['DAG-shared-versus-unfolded', 'DAG-equal-boundary-occurrences', 'DAG-rooted-growth-and-quota', 'DAG-ordered-canonical-key', 'DAG-Formula-alias-binding', 'DAG-ordered-MP-equations', 'DAG-direct-wire-and-final-used-map', 'DAG-first-fault-and-fallback'], 'groups': 8, 'bank_role': 'receptor_bank', 'subject_role': ['extractor', 'instance'], 'scope': 'Independent synthetic public DAG extraction/instance controls; no donor, library, final-use or GCTS/RL admission.'}
PROJECTION_FIELDS = {'bank': ('extractor', 'instance', 'checker', 'builders', 'reference', 'tiny_encoder'), 'service': ('checker', 'builders', 'reference')}
PUBLIC_ENDPOINTS = {'checker': ('VERSION', 'check_certificate', 'decode_query'), 'builders': ('VERSION', 'logical_axiom'), 'reference': ('VERSION', 'reference_check_certificate'), 'tiny_encoder': ('VERSION', 'encode_tiny_declared_query'), 'extractor': ('VERSION', 'extract_families', 'FamilyInputError', 'is_owned_error'), 'instance': ('VERSION', 'compile_instance', 'match_receptor', 'FamilyInputError', 'is_owned_error'), 'receptor_bank': ('VERSION', 'run_bank')}
COVERAGE_FIELDS = ('policy', 'exhaustive_connected_subgraphs', 'root_order', 'growth', 'min_nodes', 'max_nodes', 'max_distinct_boundary_nodes', 'per_donor_quota', 'library_quota', 'donors', 'selected_occurrences', 'distinct_keys', 'represented_donors', 'library_gate', 'source_occurrence_instance_gate', 'sharing_or_multiscale_coverage_claim')
DONOR_COVERAGE_FIELDS = ('donor_id', 'reachable_rows', 'roots_visited', 'candidate_prefixes_examined', 'eligible_prefixes', 'duplicate_keys_ignored', 'selected_distinct_keys', 'quota_reached', 'reachable_root_scan_exhausted', 'unsupported_prefixes', 'boundary_limit_prefixes')
DONOR_COVERAGE_COUNTS = ('reachable_rows', 'roots_visited', 'candidate_prefixes_examined', 'eligible_prefixes', 'duplicate_keys_ignored', 'selected_distinct_keys', 'unsupported_prefixes', 'boundary_limit_prefixes')
INSTANCE_FIELDS = ('schema', 'complete', 'accepted', 'context_query_identity', 'binding', 'expansion_rows', 'family_to_wire_rows', 'boundary_query_bytes', 'boundary_certificate_bytes', 'subject_receipt', 'reference_receipt')


class RootBudget(RuntimeError):
    """Genuine whole-caller resource or complete-output ceiling."""

def raw_pin(path):
    path = Path(path)
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete ordinary raw body required')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw identity required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}

def byte_identity(body):
    if type(body) is not bytes:
        raise ValueError('exact immutable bytes required')
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())

def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')
    if len(body) > cap:
        raise RootBudget('complete output ceiling; no truncation or prefix authority')
    return body

def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive new complete output required')
    temporary = path.with_name(path.name + '.partial')
    stream = None
    primary = None
    try:
        stream = temporary.open('xb')
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    temporary.replace(path)

def load_exact(row, name, check):
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact new module and unused owned import name required')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if (Path(module.__file__).resolve() != Path(row['path'])
            or raw_pin(row['path']) != pin_fields(row)):
        raise ValueError('stable exact imported Source origin required')
    return module

def _validate_json_image(value, check):
    """Validate only; no copied tree, coercion, memo cache or codec-private API."""
    active = set()
    stack = [('node', value, None, 0)]
    while stack:
        check()
        action, item, keys, index = stack.pop()
        if action == 'node':
            kind = type(item)
            if item is None or kind is bool or kind is int or kind is str:
                continue
            if kind is float:
                if not math.isfinite(item):
                    raise ValueError('finite original JSON-image float required')
                continue
            if not (kind is list or kind is tuple or kind is dict):
                raise ValueError('exact original JSON-image type required')
            identity = id(item)
            if identity in active:
                raise ValueError('active original JSON-image cycle refused')
            active.add(identity)
            if kind is dict:
                keys = []
                for key in item:
                    check()
                    if type(key) is not str:
                        raise ValueError('all exactstr keys required before lookup')
                    keys.append(key)
                stack.append(('object', item, keys, 0))
            else:
                stack.append(('array', item, None, 0))
        elif index == len(item):
            active.remove(id(item))
        else:
            # The node/edge checkpoint above precedes each child lookup.
            stack.append((action, item, keys, index + 1))
            child = item[keys[index]] if action == 'object' else item[index]
            stack.append(('node', child, None, 0))

def _checked_byte_equal(left, right, check):
    if len(left) != len(right):
        return False
    for offset in range(0, len(left), 65536):
        check()
        if left[offset:offset + 65536] != right[offset:offset + 65536]:
            return False
    return True

def _write_bank_and_readback(path, body, check, progress):
    """New positive IO only. Close cannot replace an earlier actual E."""
    temporary = path.with_name(path.name + '.partial')
    check()
    if path.exists():
        raise ValueError('exclusive new bank artifact required')
    stream = None
    primary = None
    try:
        check()
        stream = temporary.open('xb')
        progress['phase'] = 'WRITING_PARTIAL'
        offset = 0
        while offset < len(body):
            check()
            chunk = body[offset:offset + 65536]
            written = stream.write(chunk)
            if type(written) is not int or not 0 < written <= len(chunk):
                raise ValueError('complete bounded bank write required')
            offset += written
        check()
        stream.flush()
        check()
        os.fsync(stream.fileno())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    temporary.replace(path)
    progress['phase'] = 'PUBLISHED_PROVISIONAL'
    stream = None
    primary = None
    try:
        check()
        stream = path.open('rb')
        digest = hashlib.sha256()
        offset = 0
        while offset < len(body):
            check()
            chunk = stream.read(min(65536, len(body) - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('complete original bank readback required')
            check()
            if chunk != body[offset:offset + len(chunk)]:
                raise ValueError('exact original bank readback mismatch')
            check()
            digest.update(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'':
            raise ValueError('original bank readback strict EOF required')
        answer = dict(bytes=offset, sha256=digest.hexdigest())
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    progress['phase'] = 'READBACK_COMPLETE'
    progress['readback_complete'] = True
    return answer

def _keys(value, names, check):
    check()
    if type(value) is not dict or len(value) != len(names):
        raise ValueError('exact plain object carrier required')
    for key in value:
        check()
        if type(key) is not str:
            raise ValueError('exactstr keys required before membership or lookup')
    if set(value) != set(names):
        raise ValueError('exact public object fields required')

def _natural(value):
    return type(value) is int and value >= 0

def _digest(body, check):
    if type(body) is not bytes:
        raise ValueError('original immutable byte body required')
    digest = hashlib.sha256()
    for offset in range(0, len(body), 65536):
        check()
        digest.update(body[offset:offset + 65536])
    check()
    return dict(bytes=len(body), sha256=digest.hexdigest())


def _same(left, right, check):
    """Checked exact JSON-image association; list/tuple denote one array image."""
    stack = [(left, right)]
    while stack:
        check()
        a, b = stack.pop()
        ak, bk = type(a), type(b)
        aa, ba = ak is list or ak is tuple, bk is list or bk is tuple
        if aa or ba:
            if not (aa and ba and len(a) == len(b)):
                return False
            for index in range(len(a) - 1, -1, -1):
                check()
                stack.append((a[index], b[index]))
        elif ak is dict or bk is dict:
            if not (ak is dict and bk is dict and len(a) == len(b)):
                return False
            for key in a:
                check()
                if type(key) is not str or key not in b:
                    return False
                stack.append((a[key], b[key]))
        elif ak is not bk:
            return False
        elif ak is str or ak is bytes:
            if not _checked_byte_equal(a, b, check):
                return False
        elif a is None or ak is bool or ak is int or ak is float:
            if ak is float and (not math.isfinite(a) or not math.isfinite(b)):
                raise ValueError('finite exact JSON-image equality required')
            if a != b:
                return False
        else:
            raise ValueError('ordinary exact JSON-image equality required')
    return True


def _read_original(row, check):
    expected = pin_fields(row)
    path = Path(expected['path'])
    check()
    if (not path.is_absolute() or path.is_symlink() or path.resolve() != path
            or not path.is_file() or '.partial' in path.name):
        raise ValueError('canonical complete declared original required')
    stream, primary, chunks = None, None, []
    try:
        check()
        stream = path.open('rb')
        offset, digest = 0, hashlib.sha256()
        while offset < expected['bytes']:
            check()
            chunk = stream.read(min(65536, expected['bytes'] - offset))
            if type(chunk) is not bytes or not chunk:
                raise ValueError('entire declared original read required')
            check()
            digest.update(chunk)
            chunks.append(chunk)
            offset += len(chunk)
        check()
        if stream.read(1) != b'' or digest.hexdigest() != expected['sha256']:
            raise ValueError('original full raw length/hash/EOF association required')
    except BaseException as error:
        primary = error
        raise
    finally:
        if stream is not None:
            try:
                stream.close()
            except BaseException:
                if primary is None:
                    raise
    check()
    answer = b''.join(chunks)
    check()
    return answer


def _bank_complete(value, check):
    _validate_json_image(value, check)
    _keys(value, BANK_FIELDS, check)
    if (value['schema'] != 'FPC-receptor-DAG-independent-controls-v1'
            or value['version'] != ACTIVE_VERSIONS['receptor_bank']
            or value['population'] != 'receptor-DAG8' or value['complete'] is not True
            or not _same(value['control_ids'], CONTROL_IDS['receptor-DAG8'], check)
            or not _same(value['scope'], BANK_SCOPE, check)
            or not _same(value['coverage_limits'], BANK_COVERAGE_LIMITS, check)):
        raise ValueError('complete exact current public DAG8 bank return required')
    _keys(value['counts'], ('groups', 'passed', 'failed'), check)
    for key, expected in (('groups', 8), ('passed', 8), ('failed', 0)):
        check()
        if type(value['counts'][key]) is not int or value['counts'][key] != expected:
            raise ValueError('exact current scoped DAG8 counts required')
    if type(value['controls']) is not list or len(value['controls']) != 8:
        raise ValueError('all eight complete scoped rows required')
    for identifier, row in zip(CONTROL_IDS['receptor-DAG8'], value['controls']):
        _keys(row, ('id', 'passed', 'observations', 'coverage_limits'), check)
        if row['id'] != identifier or row['passed'] is not True:
            raise ValueError('exact ordered successful public-scope bank row required')


def _extraction_complete(value, donors, configuration, check):
    _validate_json_image(value, check)
    _keys(value, ('schema', 'status', 'complete', 'accepted', 'donor_validation', 'families', 'selection_coverage'), check)
    if (value['schema'] != 'FPC-propositional-receptor-library-candidate-v1'
            or value['complete'] is not True or value['accepted'] is not False
            or type(value['status']) is not str):
        raise ValueError('exact complete unadmitted extractor return required')
    if value['status'] != 'LIBRARY_CANDIDATE':
        raise ValueError('STOP_NO_USABLE_LIBRARY: no reduced-library recovery')
    views, families, coverage = value['donor_validation'], value['families'], value['selection_coverage']
    if type(views) is not list or len(views) != 2 or type(families) is not list or not 2 <= len(families) <= 4:
        raise ValueError('both donor views and complete bounded family set required')
    for index, (view, donor) in enumerate(zip(views, donors)):
        _keys(view, ('validation_index', 'donor_id', 'query_identity', 'certificate_identity', 'provenance', 'subject_receipt', 'reference_receipt'), check)
        if (type(view['validation_index']) is not int or view['validation_index'] != index
                or view['donor_id'] != donor['donor_id'] or not _same(view['provenance'], donor['provenance'], check)
                or not _same(view['query_identity'], _digest(donor['query_bytes'], check), check)
                or not _same(view['certificate_identity'], _digest(donor['certificate_bytes'], check), check)):
            raise ValueError('exact complete frozen donor-to-validation association required')
        subject, reference = view['subject_receipt'], view['reference_receipt']
        if (subject['accepted'] is not True or subject['complete'] is not True
                or subject['status'] != 'VALID_DERIVATION' or subject['final_goal_equal'] is not True
                or reference['status'] != 'VALID_DERIVATION' or reference['complete_check'] is not True
                or reference['final_goal_equal'] is not True
                or subject['query']['EOF'] != len(donor['query_bytes'])
                or subject['certificate']['EOF'] != len(donor['certificate_bytes'])
                or len(subject['certificate']['rows']) != len(reference['rows'])):
            raise ValueError('fresh complete original dual views required')
    _keys(coverage, COVERAGE_FIELDS, check)
    for key in ('min_nodes', 'max_nodes', 'max_distinct_boundary_nodes', 'per_donor_quota', 'library_quota'):
        check()
        if type(coverage[key]) is not int or coverage[key] != configuration[key]:
            raise ValueError('unchanged exact extraction limits required')
    if (coverage['policy'] != configuration['policy'] or coverage['exhaustive_connected_subgraphs'] is not False
            or coverage['root_order'] != 'increasing-source-row'
            or coverage['growth'] != 'least-current-external-predecessor'
            or coverage['library_gate'] is not True or coverage['sharing_or_multiscale_coverage_claim'] is not False
            or coverage['source_occurrence_instance_gate'] != 'NOT_RUN_EXTERNAL_INSTANCE_CALLER_REQUIRED'
            or not _same(coverage['represented_donors'], ('donor0', 'donor1'), check)
            or type(coverage['distinct_keys']) is not int or coverage['distinct_keys'] != len(families)):
        raise ValueError('full two-donor unchanged policy coverage required')
    counts = dict(donor0=0, donor1=0)
    for index, family in enumerate(families):
        check()
        for earlier in families[:index]:
            check()
            if _same(family['family_key'], earlier['family_key'], check):
                raise ValueError('distinct full structural keys required, not hash labels')
        for occurrence in family['source_occurrences']:
            check()
            label = occurrence['donor_id']
            if type(label) is not str or label not in counts:
                raise ValueError('every selected source occurrence has actual donor label')
            counts[label] += 1
        for validation_index in family['validation_provenance']:
            check()
            if not _natural(validation_index) or validation_index >= 2:
                raise ValueError('strict owning donor validation index required')
        expected_indices = []
        for view_index, view in enumerate(views):
            present = False
            for occurrence in family['source_occurrences']:
                check()
                if occurrence['donor_id'] == view['donor_id']:
                    present = True
            if present:
                expected_indices.append(view_index)
        if not _same(expected_indices, family['validation_provenance'], check):
            raise ValueError('family provenance indices and selected donors must agree')
    total = counts['donor0'] + counts['donor1']
    if (not 1 <= counts['donor0'] <= 2 or not 1 <= counts['donor1'] <= 2
            or type(coverage['selected_occurrences']) is not int or coverage['selected_occurrences'] != total):
        raise ValueError('every selected bounded source occurrence required')
    if type(coverage['donors']) is not list or len(coverage['donors']) != 2:
        raise ValueError('both complete donor coverage records required')
    for index,row in enumerate(coverage['donors']):
        _keys(row,DONOR_COVERAGE_FIELDS,check)
        label='donor'+str(index)
        if (row['donor_id'] != label or row['selected_distinct_keys'] != counts[label]
                or type(row['quota_reached']) is not bool or row['quota_reached'] is not (counts[label] == 2)
                or type(row['reachable_root_scan_exhausted']) is not bool):
            raise ValueError('exact owning donor coverage and quota flags required')
        for key in DONOR_COVERAGE_COUNTS:
            check()
            if not _natural(row[key]):
                raise ValueError('strict nonnegative complete donor coverage counters required')
    return total


def _backproject(family, occurrence, result, donor, check):
    _keys(result, INSTANCE_FIELDS, check)
    if (result['schema'] != 'FPC-receptor-instance-candidate-v1'
            or result['complete'] is not True or result['accepted'] is not False):
        raise ValueError('complete explicitly unadmitted instance required')
    source_subject, source_reference = donor['subject_receipt'], donor['reference_receipt']
    subject, reference = result['subject_receipt'], result['reference_receipt']
    if (subject['accepted'] is not True or subject['complete'] is not True
            or subject['status'] != 'VALID_DERIVATION' or reference['complete_check'] is not True
            or reference['status'] != 'VALID_DERIVATION' or not subject['final_goal_equal'] is True
            or reference['final_goal_equal'] is not True):
        raise ValueError('both complete fresh original instance views required')
    if not _same(result['binding'], occurrence['source_bindings'], check):
        raise ValueError('stored complete source binding must be used unchanged')
    for name in QUERY_FIELDS:
        check()
        if not _same(result['context_query_identity'][name], source_subject['query'][name], check):
            raise ValueError('all original donor context semantics retained')
    rows, nodes, ports = result['expansion_rows'], family['internal_nodes'], family['boundary_nodes']
    if not 2 <= len(nodes) <= 8 or len(ports) > 4:
        raise ValueError('fixed original family internal and boundary bounds required')
    count, boundary_count = len(nodes) + len(ports), len(ports)
    if (len(rows) != count or subject['certificate']['row_count'] != count
            or len(subject['certificate']['rows']) != count or len(reference['rows']) != count):
        raise ValueError('complete noncontracted physical instance rows required')
    maps = result['family_to_wire_rows']
    _keys(maps, ('boundary_to_wire', 'internal_to_wire'), check)
    if (not _same(maps['boundary_to_wire'], [[i,i] for i in range(boundary_count)], check)
            or not _same(maps['internal_to_wire'], [[i,boundary_count+i] for i in range(len(nodes))], check)):
        raise ValueError('complete canonical source identity to wire maps required')
    source_to_wire, selected_sources = {}, []
    for name, expected_count, shift in (('boundary_source_to_port', boundary_count, 0), ('source_to_local', len(nodes), boundary_count)):
        mapping = occurrence[name]
        if len(mapping) != expected_count:
            raise ValueError('complete chosen source occurrence map required')
        for index, pair in enumerate(mapping):
            check()
            if (not (type(pair) is list or type(pair) is tuple) or len(pair) != 2
                    or not _natural(pair[0]) or type(pair[1]) is not int or pair[1] != index
                    or pair[0] >= len(source_reference['rows']) or pair[0] in source_to_wire):
                raise ValueError('strict distinct source occurrence map required')
            source_to_wire[pair[0]] = shift + index
            if name == 'source_to_local':
                selected_sources.append(pair[0])
    checks, gamma = [], []
    for name, kind, shift in (('boundary_source_to_port','boundary',0), ('source_to_local','internal',boundary_count)):
        for source_index, local_index in occurrence[name]:
            check()
            wire_index = shift + local_index
            old = source_subject['certificate']['rows'][source_index]
            flat_old = source_reference['rows'][source_index]
            emitted, actual, flat = rows[wire_index], subject['certificate']['rows'][wire_index], reference['rows'][wire_index]
            _keys(emitted,('wire_index','origin_kind','origin_id','formula','rule_tag','subtag','witness','references'),check)
            if (emitted['origin_kind'] != kind or emitted['origin_id'] != local_index
                    or emitted['wire_index'] != wire_index or actual['index'] != wire_index or flat['index'] != wire_index
                    or old['index'] != source_index or flat_old['index'] != source_index
                    or not _same(emitted['formula'], old['formula'], check)
                    or not _same(actual['formula'], old['formula'], check)
                    or not _same(flat['formula']['prefix_tokens'], flat_old['formula']['prefix_tokens'], check)):
                raise ValueError('every physical original formula and identity backprojects in both views')
            if kind == 'boundary':
                gamma.append(old['formula'])
                if (actual['rule_tag'] != 0 or actual['subtag'] is not None
                        or not _same(actual['witness'], [local_index], check)
                        or flat['rule_tag'] != 0 or flat['witness_tag'] is not None
                        or not _same(flat['payload'], [local_index], check)):
                    raise ValueError('distinct boundary occurrence is its exact standalone HYP port')
            else:
                if (actual['rule_tag'] != old['rule_tag'] or actual['subtag'] != old['subtag']
                        or flat['rule_tag'] != flat_old['rule_tag'] or flat['witness_tag'] != flat_old['witness_tag']):
                    raise ValueError('original selected primitive tag/subtag backprojection required')
                if old['rule_tag'] == 1:
                    if (type(old['subtag']) is not int or not 0 <= old['subtag'] <= 2
                            or not _same(actual['witness'], old['witness'], check) or len(flat['payload']) != len(flat_old['payload'])):
                        raise ValueError('complete original logical witnesses required')
                    for current, original in zip(flat['payload'], flat_old['payload']):
                        check()
                        if not _same(current['prefix_tokens'], original['prefix_tokens'], check):
                            raise ValueError('independent ordered logical witness backprojection required')
                elif old['rule_tag'] == 3:
                    if not _same(old['witness'], flat_old['payload'], check):
                        raise ValueError('ordered original MP references join both source views')
                    expected = []
                    for original_reference in old['witness']:
                        check()
                        if not _natural(original_reference) or original_reference not in source_to_wire:
                            raise ValueError('all actual source MP ports covered by chosen full map')
                        expected.append(source_to_wire[original_reference])
                    if (not _same(actual['witness'], expected, check) or not _same(flat['payload'], expected, check)
                            or not _same(emitted['references'], expected, check) or not _same(emitted['witness'], expected, check)):
                        raise ValueError('translate original ordered MP source indices to exact emitted wire refs')
                else:
                    raise ValueError('only original H1/H2/H3 or MP selected internal rows')
            checks.append(dict(source_row=source_index,wire_row=wire_index,origin_kind=kind,origin_id=local_index,
                original_row_span=old['span'], independent_original_row_span=flat_old['byte_span'],
                emitted_row_span=actual['span'],independent_emitted_row_span=flat['byte_span']))
    root_source = occurrence['root_source_row']
    for key in ('version','function_arities','predicate_arities'):
        check()
        if not _same(subject['query'][key],source_subject['query'][key],check):
            raise ValueError('exact original signature and version in boundary query required')
    if (not selected_sources or root_source != selected_sources[-1]
            or source_to_wire[root_source] != count-1 or not _same(subject['query']['goal'], source_subject['certificate']['rows'][root_source]['formula'], check)
            or not _same(subject['query']['Gamma'], gamma, check)
            or subject['query']['claim_mode'] != 1 or subject['query']['theory_profile'] != 0
            or subject['query']['finite_axioms'] != []):
        raise ValueError('exact standalone boundary context and mapped source root required')
    return dict(schema='FPC-receptor-source-occurrence-backprojection-v1',complete=True,accepted=False,
        source_root_row=root_source,source_to_wire_rows=sorted(source_to_wire.items()),physical_rows=checks,
        meaning='Standalone boundary consequence/source occurrence only; no original theorem or final-used-map admission.')


def main(plan_path, actual_dir, root_start):
    if not (sys.platform == 'darwin' and sys.implementation.name == 'cpython'
            and sys.version.split()[0] == '3.12.14'
            and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
            and os.getpid() == os.getpgrp() and type(root_start) is float
            and math.isfinite(root_start) and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated owned pinned Darwin child and genuine parent start required')
    began = root_start
    directory, plan_path = Path(actual_dir), Path(plan_path)
    study = Path(__file__).resolve().parents[1]
    plan_pin = raw_pin(plan_path)
    plan_bytes = plan_path.read_bytes()
    if byte_identity(plan_bytes) != {key: plan_pin[key] for key in ('bytes','sha256')}:
        raise ValueError('stable complete plan required')
    plan = json.loads(plan_bytes)
    del plan_bytes
    if not (plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['experiment'] == EXPERIMENT and plan['stage'] == 'extract'
            and plan['case_id'] == EXPERIMENT + '-extract-0'
            and plan.get('required_upstream_ids', []) == []
            and not any(key in plan for key in ('donor_index','input_slot','target_index','target_id','arm',
                'query','certificate','proof','tree','library','frame','lemma','search_configuration'))
            and directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and directory == study / 'actual' / plan['case_id'] and plan['actual_dir'] == str(directory)
            and plan_path.parent == study / 'root' / 'plans'
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('exact new owned library once case required')
    if not (type(plan['limits']) is dict and set(plan['limits']) == set(CAPS)
            and all(type(plan['limits'][key]) is int and plan['limits'][key] == value for key,value in CAPS.items())):
        raise ValueError('all ten original exact caps required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'],CAPS['physical_bytes']))
    consumed = json.loads((directory / 'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256'] and consumed['case_id'] == plan['case_id']
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('exact one-use fresh consumption required')
    state = dict(stage='PIN_INTAKE',callbacks=0,first_fault=None,first_fault_monotonic_ns=None,stages=[],versions={})
    primary, guards, source_unchanged = None, [], False
    cohort = input_freeze = qualification = extraction = instances = library = scientific = None
    modules, projections, originals, donors, metadata_rows = {}, {}, [], [], []
    configuration = configuration_frozen = input_frozen = None
    service_result = saved_service = family_frozen = None
    committed_bytes, output_rejection, normal_status = 0, None, None
    provisional = []

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic() - began >= CAPS['work_seconds']:
            fault = RootBudget('absolute whole-work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python whole high-water ceiling')
        if fault is not None:
            state['first_fault_monotonic_ns'] = time.monotonic_ns()
            state['first_fault'] = fault
            raise fault

    def policy_check():
        check()
        current = sys.get_int_max_str_digits()
        if type(current) is not int or current != POLICY_BINDING[1]:
            raise ValueError('admitted native effective integer policy drift')
        return current

    def stage(name, operation):
        policy_check()
        state['stage'] = name
        row = dict(name=name,began=time.monotonic()-began,status='STARTED')
        state['stages'].append(row)
        answer = operation()
        policy_check()
        row.update(status='COMPLETED',seconds=time.monotonic()-began-row['began'])
        return answer

    def verify_files(cooperative):
        # Original Source-only noncooperative guard path remains allowed after E.
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed closed Source or metadata: '+row['path'])

    def canonical(value):
        _validate_json_image(value,check)
        policy_check()
        body = (json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(',',':'))+'\n').encode('ascii')
        policy_check()
        return body

    def equal(left,right):
        return _same(left,right,check)

    def metadata(row):
        ref = pin_fields(row)
        if by_path.get(ref['path']) != ref:
            raise ValueError('explicit exact guarded metadata required')
        body = _read_original(ref,policy_check)
        policy_check()
        value = json.loads(body)
        policy_check()
        return value

    def stable():
        policy_check()
        if input_frozen is not None and not _checked_byte_equal(canonical(input_freeze),input_frozen,check):
            raise ValueError('full owned input metadata freeze mutated')
        if configuration is not None and not _checked_byte_equal(canonical(configuration),configuration_frozen,check):
            raise ValueError('fixed extraction configuration mutated')
        for role,function_name,function in public_bindings:
            check()
            if getattr(modules[role],function_name) is not function:
                raise ValueError('exact original public callable identity changed')
        for name,projection in projections.items():
            _keys(projection, PROJECTION_FIELDS[name],check)
            for role in PROJECTION_FIELDS[name]:
                check()
                if projection[role] is not modules[role]:
                    raise ValueError('exact public namespace projection changed')
        for index,donor in enumerate(donors):
            check()
            if (donor['query_bytes'] is not originals[index][0]
                    or donor['certificate_bytes'] is not originals[index][1]
                    or not equal(donor['provenance'],input_freeze['donors'][index]['provenance'])):
                raise ValueError('frozen original donor pair/provenance changed')

    def decide_size(body,component):
        nonlocal output_rejection
        policy_check()
        size, prospective = len(body), committed_bytes+len(body)
        if prospective > CAPS['result_bytes']:
            if output_rejection is None:
                output_rejection = dict(schema='FPC-receptor-library-output-rejection-v1',component=component,
                    exact_attempt_bytes=size,committed_positive_bytes_before=committed_bytes,
                    prospective_positive_bytes=prospective,cap_bytes=CAPS['result_bytes'])
            fault = RootBudget('all original and instance bytes plus ENTIRE result exceed shared48MiB')
            state['first_fault'] = fault
            raise fault

    def export_original(name,body):
        nonlocal committed_bytes
        if type(body) is not bytes:
            raise ValueError('exact immutable original body required')
        decide_size(body,name)
        progress = dict(basename=name,phase='BEFORE_WRITE',readback_complete=False)
        provisional.append(progress)
        expected = _digest(body,policy_check)
        actual = _write_bank_and_readback(directory/name,body,policy_check,progress)
        if not equal(actual,expected):
            raise ValueError('entire original-byte artifact association required')
        committed_bytes += len(body)
        return dict(schema='FPC-receptor-original-bytes-artifact-ref-v1',path=name,
                    bytes=actual['bytes'],sha256=actual['sha256'])

    def retire_positive_references():
        nonlocal cohort,input_freeze,qualification,extraction,instances,library,scientific
        nonlocal originals,donors,service_result,saved_service,family_frozen,configuration,configuration_frozen,input_frozen
        cohort=input_freeze=qualification=extraction=instances=library=scientific=None
        originals=donors=[]
        service_result=saved_service=family_frozen=configuration=configuration_frozen=input_frozen=None

    public_bindings = []
    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed complete guard list required')
        guards = [pin_fields(row) for row in plan['files']]
        by_path = {row['path']:row for row in guards}
        if len(by_path) != len(guards):
            raise ValueError('unique complete guarded paths required')
        for row in guards:
            check()
            if '/actual/' in row['path'] or row['path'].endswith('.bin'):
                raise ValueError('scientific donor bodies are separate data, never Sourceguards')
        _keys(plan['module_pins'],MODULE_ROLES,check)
        module_pins = {role:pin_fields(plan['module_pins'][role]) for role in MODULE_ROLES}
        for row in ALL_RUNTIME_ROLES:
            check()
            if module_pins[row['role']] != row['rawpin'] or by_path.get(row['rawpin']['path']) != row['rawpin']:
                raise ValueError('all original38 plus current new3 exact pins required')
        for key,expected in METADATA_PINS.items():
            check()
            if pin_fields(plan[key]) != expected or by_path.get(expected['path']) != expected:
                raise ValueError('exact guarded current metadata required: '+key)
        for row in REQUIRED_METADATA_GUARDS:
            check()
            if by_path.get(row['path']) != row:
                raise ValueError('explicit current contract/component/bank metadata guard required')
        for row in SCIENTIFIC_RAW_INPUTS:
            check()
            if pin_fields(plan[row['plan_key']]) != row['rawpin'] or by_path.get(row['rawpin']['path']) != row['rawpin']:
                raise ValueError('all original raw8 objects retained as guarded provenance only')
        for row in CUSTODY_RUNTIME.values():
            check()
            if by_path.get(row['path']) != row:
                raise ValueError('exact original custody/runtime required')
        if (pin_fields(plan['python']) != CUSTODY_RUNTIME['python']
                or raw_pin(Path(sys.executable).resolve()) != CUSTODY_RUNTIME['python']
                or by_path.get(str(Path(__file__).resolve())) != raw_pin(Path(__file__).resolve())
                or Path(plan['runner_path']) != Path(CUSTODY_RUNTIME['runner']['path'])):
            raise ValueError('exact pinned child/custody and reviewed caller required')
        applicability_pin,protocol_pin = pin_fields(plan['library_applicability']),pin_fields(plan['protocol'])
        if by_path.get(applicability_pin['path']) != applicability_pin or by_path.get(protocol_pin['path']) != protocol_pin:
            raise ValueError('new guarded applicability and protocol required')
        verify_files(True)
        reference_integer_policy = [POLICY_BINDING[0],policy_check()]
        floor = metadata(GUARD_FLOOR_PLAN_PIN)
        if type(floor['files']) is not list or len(floor['files']) != 524:
            raise ValueError('exact original524 Sourceguard floor required')
        for row in floor['files']:
            check()
            ref = pin_fields(row)
            if '/actual/' in ref['path'] or by_path.get(ref['path']) != ref:
                raise ValueError('every old524 closed Sourceguard row must remain exact')
        floor = None
        descriptor = metadata(plan['cohort_descriptor'])
        disposition = metadata(plan['cohort_disposition'])
        peer_review = metadata(plan['cohort_C_review'])
        authority = metadata(plan['donor_pair_authority'])
        applicability,protocol = metadata(applicability_pin),metadata(protocol_pin)
        _keys(descriptor,DESCRIPTOR_FIELDS,check)
        for key,expected in (('covered_runtime_roles',COVERED_RUNTIME_ROLES),('control_populations',CONTROL_POPULATIONS),
                ('raw_inputs',SCIENTIFIC_RAW_INPUTS),('environment',ENVIRONMENT),('custody_runtime',CUSTODY_RUNTIME),
                ('limits',CAPS),('qualification_caller_pins',QUALIFIER_CALLER_PINS),('qualifier_contract_pins',QUALIFIER_CONTRACT_PINS)):
            if not equal(descriptor[key],expected):
                raise ValueError('exact admitted finite cohort descriptor field required: '+key)
        if (descriptor['schema'] != 'FPC-original-bank-cohort-descriptor-v1'
                or descriptor['cohort_id'] != COHORT_ID or descriptor['policy_rule'] != POLICY_RULE):
            raise ValueError('original admitted descriptor identity/policy required')
        for row in descriptor['source_closure']:
            check()
            ref=pin_fields(row)
            if '/actual/' in ref['path'] or by_path.get(ref['path']) != ref:
                raise ValueError('full admitted descriptor Source closure retained')
        if (disposition['schema'] != 'Root-original-bank-cohort-complete-whole-disposition-v1'
                or disposition['status'] != 'ADMITTED_EXACT_FINITE_INFRASTRUCTURE_COHORT229'
                or disposition['cohort_admitted'] is not True or disposition['cohort_id'] != COHORT_ID
                or not equal(disposition['descriptor'],METADATA_PINS['cohort_descriptor'])
                or not equal(disposition['complete_C_review'],METADATA_PINS['cohort_C_review'])
                or not equal(disposition['recorded_policy_binding'],reference_integer_policy)
                or peer_review['review_passed'] is not True or peer_review['blockers'] != []):
            raise ValueError('separate complete original229 Root/C cohort admission required')
        if (authority['schema'] != 'Root-cohort-backed-two-donor-complete-disposition-v1'
                or authority['status'] != 'TWO_DISTINCT_FRESH_ORDINARY_PROOFS_ADMITTED'
                or not equal(authority['admissions'],DONOR_ADMISSION_PINS)
                or authority['complete_inputs_configuration_selection_equal'] is not True
                or authority['selected_queries_distinct'] is not True):
            raise ValueError('exact already-admitted original pair authority required')
        _keys(applicability,APPLICABILITY_FIELDS,check)
        expected_app = dict(schema='Root-FPC-receptor-library-applicability-v1',cohort_id=COHORT_ID,
            descriptor=METADATA_PINS['cohort_descriptor'],Root_disposition=METADATA_PINS['cohort_disposition'],
            C_review=METADATA_PINS['cohort_C_review'],covered_runtime_roles=COVERED_RUNTIME_ROLES,
            control_populations=CONTROL_POPULATIONS,raw_inputs=SCIENTIFIC_RAW_INPUTS,
            active_runtime_roles=ACTIVE_RUNTIME_ROLES,custody_runtime=CUSTODY_RUNTIME,environment=ENVIRONMENT,
            reference_integer_policy=reference_integer_policy,limits=CAPS,
            donor_pair_authority=METADATA_PINS['donor_pair_authority'],contract_pins=CONTRACT_PINS,
            caller_pins=applicability['caller_pins'],accepted=False,qualification_rerun=False)
        if not equal(applicability,expected_app):
            raise ValueError('strict18-field new caller applicability association required')
        _keys(applicability['caller_pins'],('worker','API','offer','handoff'),check)
        for row in applicability['caller_pins'].values():
            check()
            ref=pin_fields(row)
            if by_path.get(ref['path']) != ref:
                raise ValueError('all four separately reviewed current caller pins must be guarded')
        if applicability['caller_pins']['worker'] != raw_pin(Path(__file__).resolve()):
            raise ValueError('applicability must name this exact new caller')
        expected_populations = {}
        for row in CONTROL_POPULATIONS+[NEW_BANK_POPULATION]:
            check()
            expected_populations[row['population']] = {key:value for key,value in row.items() if key != 'population'}
        if not equal(plan['control_populations'],expected_populations):
            raise ValueError('exact old17 scoped objects plus separate current DAG8 object required')
        if not equal(plan['donor_inputs'],DONOR_INPUTS) or not equal(plan['extraction_configuration'],CONFIGURATION):
            raise ValueError('exact fixed already-admitted pair and unchanged extraction configuration required')
        _keys(protocol,('schema','experiment','limits','module_pins','control_populations','job_recipes','metadata'),check)
        if (protocol['schema'] != PROTOCOL_SCHEMA or protocol['experiment'] != EXPERIMENT
                or not equal(protocol['limits'],CAPS) or not equal(protocol['module_pins'],plan['module_pins'])
                or not equal(protocol['control_populations'],expected_populations)
                or not equal(protocol['job_recipes'],RECIPES)):
            raise ValueError('exact new one-recipe common protocol required')
        _keys(protocol['metadata'],PROTOCOL_METADATA_FIELDS,check)
        for key in PROTOCOL_METADATA_FIELDS:
            if not equal(protocol['metadata'][key],plan[key]):
                raise ValueError('exact protocol/plan metadata join required: '+key)
        cohort = dict(schema='FPC-receptor-library-cohort-provenance-v1',complete=True,accepted=False,
            cohort_id=COHORT_ID,descriptor=descriptor,applicability=applicability,
            original_Root_disposition=METADATA_PINS['cohort_disposition'],original_C_review=METADATA_PINS['cohort_C_review'],
            qualification_rerun=False,prior_groups=229,prior_populations=17,covered_runtime_roles=38,
            qualification_cost_reported_once=disposition['metrics'],donor_pair_authority=METADATA_PINS['donor_pair_authority'],
            acquisition_observer_seconds=authority['observer_elapsed_seconds'])
        for role in ACTIVE_ROLES:
            modules[role] = stage('IMPORT '+role,lambda role=role:load_exact(module_pins[role],'owned_receptor_library_'+role+'_v1',check))
            if type(modules[role].VERSION) is not str or modules[role].VERSION != ACTIVE_VERSIONS[role]:
                raise ValueError('exact current active public VERSION required: '+role)
            state['versions'][role]=modules[role].VERSION
        for role,names in PUBLIC_ENDPOINTS.items():
            for name in names:
                check()
                public_bindings.append((role,name,getattr(modules[role],name)))
        projections['bank']={role:modules[role] for role in PROJECTION_FIELDS['bank']}
        projections['service']={role:modules[role] for role in PROJECTION_FIELDS['service']}
        verify_files(True)
        stable()
        qualification = stage('QUALIFY RECEPTOR_DAG8',lambda:modules['receptor_bank'].run_bank(projections['bank'],check=check))
        _bank_complete(qualification,check)
        stable()
        input_freeze = dict(schema='FPC-receptor-library-input-freeze-v1',donor_pair_authority=METADATA_PINS['donor_pair_authority'],
            donors=[],configuration=dict(CONFIGURATION),no_input_selection=True,holdout_loaded=False)
        for index,record in enumerate(DONOR_INPUTS):
            check()
            root_admission,review = metadata(record['Root_admission']),metadata(record['C_actual_review'])
            if (root_admission['schema'] != 'Root-FPC-cohort-backed-donor-admission-v1'
                    or type(root_admission['donor_index']) is not int or root_admission['donor_index'] != index
                    or root_admission['proof_admitted'] is not True or root_admission['resources_and_custody_accepted'] is not True
                    or root_admission['fresh_whole_original_byte_dual_gate'] is not True
                    or not equal(root_admission['C_actual_review'],record['C_actual_review'])
                    or not equal(root_admission['complete_C_review'],record['C_actual_review'])
                    or not equal(root_admission['query'],record['query']) or not equal(root_admission['certificate'],record['certificate'])
                    or review['schema'] != 'C-cohort-backed-per-proof-donor-complete-whole-actual-review-v1'
                    or type(review['donor_index']) is not int or review['donor_index'] != index
                    or review['review_passed'] is not True or review['blockers'] != []
                    or not equal(review['subjects']['original_query'],record['query'])
                    or not equal(review['subjects']['original_certificate'],record['certificate'])
                    or not equal(root_admission['plan'],review['subjects']['plan'])):
                raise ValueError('complete current separate original-byte Root/C donor admission required')
            query = stage('LOAD ORIGINAL QUERY '+str(index),lambda record=record:_read_original(record['query'],policy_check))
            certificate = stage('LOAD ORIGINAL CERTIFICATE '+str(index),lambda record=record:_read_original(record['certificate'],policy_check))
            originals.append((query,certificate))
            provenance = dict(schema='FPC-receptor-donor-provenance-v1',Root_admission=record['Root_admission'],
                C_actual_review=record['C_actual_review'],query=_digest(query,check),certificate=_digest(certificate,check),
                module_pins={role:module_pins[role] for role in ('checker','builders','reference')})
            donors.append(dict(donor_id=record['donor_id'],query_bytes=query,certificate_bytes=certificate,provenance=provenance))
            query_ref=stage('EXPORT ORIGINAL QUERY '+str(index),lambda query=query,index=index:export_original('donor-'+str(index)+'-query.bin',query))
            certificate_ref=stage('EXPORT ORIGINAL CERTIFICATE '+str(index),lambda certificate=certificate,index=index:export_original('donor-'+str(index)+'-certificate.bin',certificate))
            input_freeze['donors'].append(dict(donor_id=record['donor_id'],provenance=provenance,
                query=query_ref,certificate=certificate_ref,Root_admission=record['Root_admission'],C_actual_review=record['C_actual_review'],
                prior_ordinary_acquisition_metrics=root_admission['metrics']))
        if _checked_byte_equal(originals[0][0],originals[1][0],check):
            raise ValueError('two distinct admitted original query byte identities required')
        configuration=dict(CONFIGURATION)
        configuration_frozen=canonical(configuration)
        input_frozen=canonical(input_freeze)
        stable()
        extraction=stage('EXTRACT ONCE',lambda:modules['extractor'].extract_families(donors,modules=projections['service'],configuration=configuration,check=check))
        if type(extraction) is dict and type(extraction.get('status')) is str:
            normal_status=extraction['status']
        stable()
        occurrence_count=_extraction_complete(extraction,donors,configuration,check)
        instances=[]
        for family_index,family in enumerate(extraction['families']):
            for occurrence_index,occurrence in enumerate(family['source_occurrences']):
                check()
                donor_index=0 if occurrence['donor_id']=='donor0' else 1
                family_frozen=canonical(family)
                service_result=stage('COMPILE OCCURRENCE '+str(family_index)+':'+str(occurrence_index),
                    lambda family=family,occurrence=occurrence,donor_index=donor_index:modules['instance'].compile_instance(
                        originals[donor_index][0],family,occurrence['source_bindings'],
                        encoder=modules['tiny_encoder'].encode_tiny_declared_query,modules=projections['service'],check=check))
                stable()
                if not _checked_byte_equal(canonical(family),family_frozen,check):
                    raise ValueError('full selected family and occurrence metadata mutated')
                backprojection=stage('BACKPROJECT OCCURRENCE '+str(family_index)+':'+str(occurrence_index),
                    lambda family=family,occurrence=occurrence,service_result=service_result,donor_index=donor_index:
                        _backproject(family,occurrence,service_result,extraction['donor_validation'][donor_index],check))
                context_identity=service_result['context_query_identity']
                for key,value in _digest(originals[donor_index][0],check).items():
                    check()
                    if not equal(context_identity[key],value):
                        raise ValueError('exact original context raw identity retained')
                if context_identity['query_hex'] != originals[donor_index][0].hex():
                    raise ValueError('original context full byte image retained')
                artifact_index=len(instances)
                q=service_result['boundary_query_bytes']; certificate=service_result['boundary_certificate_bytes']
                if type(q) is not bytes or type(certificate) is not bytes:
                    raise ValueError('two exact immutable instance byte leaves required')
                q_ref=stage('EXPORT INSTANCE QUERY '+str(artifact_index),lambda q=q,artifact_index=artifact_index:export_original('instance-'+str(artifact_index)+'-query.bin',q))
                c_ref=stage('EXPORT INSTANCE CERTIFICATE '+str(artifact_index),lambda certificate=certificate,artifact_index=artifact_index:export_original('instance-'+str(artifact_index)+'-certificate.bin',certificate))
                for name,body in (('query',q),('certificate',certificate)):
                    check()
                    if not equal(service_result['subject_receipt']['raw_inputs'][name],_digest(body,check)):
                        raise ValueError('exported identical instance bytes join complete original subject input')
                saved_service=dict(service_result)
                saved_service['boundary_query_bytes']=q_ref
                saved_service['boundary_certificate_bytes']=c_ref
                _validate_json_image(saved_service,check)
                instances.append(dict(family_index=family_index,source_occurrence_index=occurrence_index,
                    donor_validation_index=donor_index,source_occurrence=occurrence,
                    service_result=saved_service,backprojection=backprojection))
                service_result=saved_service=family_frozen=q=certificate=backprojection=None
        if len(instances) != occurrence_count:
            raise ValueError('every selected occurrence must complete before any library candidate')
        library=dict(schema='FPC-receptor-library-feasibility-candidate-v1',accepted=False,
            family_indices=list(range(len(extraction['families']))),instance_indices=list(range(len(instances))),
            all_selected_source_occurrences_checked=True,library_admitted=False,
            evidence_reference='extraction_result.families plus instance_results; complete structural keys authoritative')
        scientific=dict(schema='FPC-receptor-library-feasibility-observation-v1',accepted=False,proof_admitted=False,
            library_admitted=False,prior_cohort_groups=229,prior_cohort_rerun=False,new_public_scoped_groups=8,
            extraction_calls=1,source_occurrence_instance_calls=len(instances),new_research_proofs=0,
            holdout_loaded=False,holdout_searched=False,used_expansion_validated=False,
            final_consumer_fallback_and_transactions='UNEXERCISED',acquired_internal_sharing_claim=False,
            learned_inventory=False,GCTS_RL_claim=False,positive_body_bytes_before_result=committed_bytes,
            costs='Entire inherited parent-start cold setup, DAG8, data loading, extraction, all instance/dual/backprojection/export/readback/retirement/custody costs. Prior229 qualification and ordinary acquisition reported separately.')
        stable()
        for index,record in enumerate(DONOR_INPUTS):
            for offset,name in enumerate(('query','certificate')):
                current=_read_original(record[name],policy_check)
                if not _checked_byte_equal(current,originals[index][offset],check):
                    raise ValueError('final exact admitted original input unchanged check required')
        current=None
        verify_files(True)
        policy_check()
    except BaseException as error:
        primary=state['first_fault'] if state['first_fault'] is not None else error
    finally:
        source_unchanged=False
        try:
            verify_files(primary is None)
            source_unchanged=bool(guards)
        except BaseException as error:
            if primary is None:
                primary=state['first_fault'] if state['first_fault'] is not None else error
        if primary is not None:
            retire_positive_references()
    originals=donors=[]
    service_result=saved_service=family_frozen=configuration=configuration_frozen=input_frozen=None
    query=certificate=q=family=occurrence=backprojection=None
    public_bindings.clear()
    projections.clear()
    modules.clear()

    def receipt():
        return dict(schema='FPC-receptor-library-feasibility-receipt-v1',case_id=plan['case_id'],stage='extract',
            worker_version=VERSION,status='LIBRARY_FEASIBILITY_CANDIDATE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            accepted=False,library_admitted=False,proof_admitted=False,candidate_complete=primary is None,
            qualification_complete=False,prior_qualification_rerun=False,stages=state['stages'],callbacks=state['callbacks'],
            elapsed_seconds=time.monotonic()-began,python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            source_unchanged=source_unchanged,native_peak_bytes=0,native_requests_started=0,native_queries=[],
            native_transport=dict(closed=True,all_reaped=True,native_exit_code=0,native_high_water_bytes=0,
                subprocesses_started=0,scope='VACUOUS_NO_NATIVE_SUBPROCESS'),guard_compilations=[],
            cohort_provenance=cohort if primary is None else None,input_freeze=input_freeze if primary is None else None,
            dag8_qualification=qualification if primary is None else None,extraction_result=extraction if primary is None else None,
            instance_results=instances if primary is None else None,library_candidate=library if primary is None else None,
            scientific_result=scientific if primary is None else None,
            error=None if primary is None else dict(type=type(primary).__name__,message=str(primary),traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,first_fault_monotonic_ns=state['first_fault_monotonic_ns'],
            output_rejection=output_rejection,normal_extraction_status=normal_status,component_versions=state['versions'],
            provisional_artifacts=provisional,cohort_id=COHORT_ID,old_result_body_reused=False,
            STOP=None if primary is None else 'STOP_WHOLE_NOT_ADMITTED',
            scope='Finite extraction and standalone instance feasibility only. Original229 provenance unchanged/no rerun; current8 public facets only, future final-use/fallback/transactions unexercised. Current ordered policy may only acquire size2/3 families. No holdout, new proof, useful-transfer, shared/multiscale or GCTS/RL advantage claim. External Root/C complete whole gate only.')

    try:
        if primary is None:
            policy_check()
            value=receipt()
            body=canonical(value)
            decide_size(body,'ENTIRE_RESULT_JSON')
            del value
            policy_check()
        else:
            body=serialize(receipt(),CAPS['result_bytes'])
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault']=error
            primary=state['first_fault'] if state['first_fault'] is not None else error
        retire_positive_references()
        body=serialize(receipt(),CAPS['result_bytes'])
    result_path=directory/('result.json' if primary is None else 'failure.json')
    if primary is None:
        progress=dict(phase='BEFORE_WRITE',readback_complete=False)
        try:
            _write_bank_and_readback(result_path,body,policy_check,progress)
            policy_check()
        except BaseException as error:
            if progress['phase']=='BEFORE_WRITE' or progress['phase']=='WRITING_PARTIAL':
                primary=state['first_fault'] if state['first_fault'] is not None else error
                retire_positive_references()
                body=serialize(receipt(),CAPS['result_bytes'])
                result_path=directory/'failure.json'
                write_body(result_path,body)
            else:
                raise
    else:
        write_body(result_path,body)
    del body
    result_pin=raw_pin(result_path)
    header=dict(schema='proof-search-case-worker-header-v1',case_id=plan['case_id'],
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',callbacks=state['callbacks'],seconds=time.monotonic()-began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,native_peak_bytes=0,
        source_unchanged=source_unchanged,native_closed_and_reaped=True,first_Root_fault=state['first_fault'] is not None,
        result=result_pin,native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json',serialize(header,CAPS['log_bytes']))
    print(json.dumps(dict(case_id=plan['case_id'],status=header['status'],callbacks=state['callbacks'],seconds=time.monotonic()-began)))
    return 0 if (primary is None and source_unchanged and time.monotonic()-began<CAPS['positive_seconds']
        and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss<CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fpc_receptor_extraction_library_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1],sys.argv[2],float(sys.argv[3])))
