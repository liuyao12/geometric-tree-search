"""Administrative metadata only; uninvoked Source, no scientific imports/calls.

The four donor-body pins are joined from Root/C metadata, never read or hashed
here. Their actual reads/hashes/semantic checks belong to the measured worker.
"""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
EXPERIMENT = 'two-admitted-donor-receptor-library-feasibility-v1'
CASE = EXPERIMENT + '-extract-0'
PREFIX = 'receptor-library-'
ACTIVE = ('checker', 'builders', 'reference', 'tiny_encoder',
          'extractor', 'instance', 'receptor_bank')
CONFIGURATION = dict(schema='FPC-propositional-receptor-extraction-v1', min_nodes=2,
    max_nodes=8, per_donor_quota=2, library_quota=4,
    max_distinct_boundary_nodes=4, policy='ordered-ancestor-growth-v1')
AUTHORITY_SHA = '1173ecd8432c7dbdae5107153960d550a44e6532e466c54936d57a6883cf1722'
PAIR_SHA = '9769265b35a0381585270a7f59ea2365a394a80513dfcf3fd7c308f1e0bdf99d'
FLOOR_PLAN_SHA = '7539fe80fbf50c353dcc655b867cdd0ae73a4d4a4784549326f63b3fb85e03f1'
PEER_PLAN_SHA = '4acf71399172e399d49c9bb3725408df4e3721157be3be9939f364f4e6b3e698'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path
    assert path.is_file() and not path.is_symlink() and '.partial' not in path.name
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode())
    return pin(path)


def data_pin_shape(ref, expected_path):
    """Metadata association only: do not stat/read/hash/parse the donor body."""
    assert type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}
    assert type(ref['path']) is str and ref['path'] == str(expected_path)
    assert expected_path.is_absolute()
    assert type(ref['bytes']) is int and ref['bytes'] > 0
    assert type(ref['sha256']) is str and len(ref['sha256']) == 64
    assert all(ch in '0123456789abcdef' for ch in ref['sha256'])


assert len(sys.argv) == 2
accept_path = Path(sys.argv[1]).resolve()
accept = read(accept_path)
assert accept['accepted_component_Source'] is True
assert type(accept['component_reviews']) is dict and accept['component_reviews']
for ref in accept['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff'):
    verify(accept[key])

authority_path = ROOT / 'receptor-library-Root-effective-contract-and-caller-Source-authorship-v1.json'
assert pin(authority_path)['sha256'] == AUTHORITY_SHA
authority = read(authority_path)
assert authority['paper_semantics_adopted'] is True
assert authority['caller_Source_authorship_authorized'] is True
contract_paths = [STUDY / 'implementation-B' / name for name in (
    'receptor-library-bounded-caller-CONTRACT-offer-v1.json',
    'receptor-library-bounded-caller-entry-ABI-addendum-v1.json',
    'receptor-library-bounded-caller-admission-flag-addendum-v1.json')]
contract_pins = [pin(path) for path in contract_paths] + [pin(authority_path)]
assert contract_pins[:3] == authority['effective_contract']
assert accept['effective_contract'] == contract_pins
offer = read(contract_paths[0])
assert offer['calls_and_configuration']['configuration'] == CONFIGURATION
assert offer['proposed_identity']['experiment'] == EXPERIMENT

bank_accept_path = ROOT / 'receptor-DAG8-bank-Root-component-acceptance-v1.json'
source2_accept_path = ROOT / 'receptor-family-Source2-Root-component-and-bank-Source-acceptance-v1.json'
assert accept['bank_component_acceptance'] == pin(bank_accept_path)
assert accept['Source2_component_acceptance'] == pin(source2_accept_path)
bank_accept, source2_accept = read(bank_accept_path), read(source2_accept_path)
assert bank_accept['accepted_component_Source'] is True
assert source2_accept['Source2_component_accepted'] is True
verify(bank_accept['component_review'])
assert read(bank_accept['component_review']['path'])['review_passed'] is True
verify(source2_accept['C_complete_component_review'])
assert read(source2_accept['C_complete_component_review']['path'])['review_passed'] is True
assert accept['bank'] == bank_accept['bank']
for ref in bank_accept['packet']:
    verify(ref)
bank_api = read(bank_accept['API']['path'])
assert bank_api['entry'] == 'run_bank(modules, *, check)'
assert bank_api['VERSION'] == 'FPC-RECEPTOR-DAG-INDEPENDENT-BANK-v1'
assert bank_api['return_schema'] == 'FPC-receptor-DAG-independent-controls-v1'
assert bank_api['population'] == 'receptor-DAG8'
assert len(bank_api['control_ids']) == len(set(bank_api['control_ids'])) == 8

pair_path = ROOT / 'cohort-backed-per-proof-two-donor-Root-complete-disposition-v1.json'
assert pin(pair_path)['sha256'] == PAIR_SHA
assert offer['donor_intake']['pair_authority'] == pin(pair_path)
pair = read(pair_path)
assert pair['schema'] == 'Root-cohort-backed-two-donor-complete-disposition-v1'
assert pair['status'] == 'TWO_DISTINCT_FRESH_ORDINARY_PROOFS_ADMITTED'
assert pair['complete_inputs_configuration_selection_equal'] is True
assert pair['selected_queries_distinct'] is True and pair['holdout_searched'] is False
assert len(pair['admissions']) == 2
donor_inputs, donor_metadata_paths, old_plans = [], [], []
for index, admission_ref in enumerate(pair['admissions']):
    verify(admission_ref)
    admission = read(admission_ref['path'])
    old_case = 'signed-propositional-cohort-proof-benchmark-v1-donor-' + str(index)
    assert admission['schema'] == 'Root-FPC-cohort-backed-donor-admission-v1'
    assert admission['case_id'] == old_case and admission['donor_index'] == index
    assert admission['input_slot'] == 'donor' + str(index)
    assert admission['proof_admitted'] is True
    assert admission['resources_and_custody_accepted'] is True
    assert admission['fresh_whole_original_byte_dual_gate'] is True
    verify(admission['C_actual_review'])
    review = read(admission['C_actual_review']['path'])
    assert review['schema'] == 'C-cohort-backed-per-proof-donor-complete-whole-actual-review-v1'
    assert review['review_passed'] is True and review['case_id'] == old_case
    assert review['donor_index'] == index and review['input_slot'] == admission['input_slot']
    assert review['subjects']['original_query'] == admission['query']
    assert review['subjects']['original_certificate'] == admission['certificate']
    assert review['subjects']['plan'] == admission['plan']
    for key, name in (('query', 'query.bin'), ('certificate', 'certificate.bin')):
        data_pin_shape(admission[key], STUDY / 'actual' / old_case / name)
    verify(admission['plan'])
    old_plans.append(read(admission['plan']['path']))
    donor_metadata_paths.extend((Path(admission_ref['path']),
                                 Path(admission['C_actual_review']['path']),
                                 Path(admission['plan']['path'])))
    donor_inputs.append(dict(donor_id='donor' + str(index), Root_admission=admission_ref,
        C_actual_review=admission['C_actual_review'], query=admission['query'],
        certificate=admission['certificate']))
assert pair['admissions'] == offer['donor_intake']['Root_admissions']
assert donor_inputs[0]['query'] != donor_inputs[1]['query']
assert pin(donor_metadata_paths[2])['sha256'] == FLOOR_PLAN_SHA
assert pin(donor_metadata_paths[5])['sha256'] == PEER_PLAN_SHA
old = old_plans[0]
assert len(old['files']) == 524 and old['files'] == old_plans[1]['files']
assert old['required_upstream_ids'] == []

descriptor_path = ROOT / 'original-bank-cohort-descriptor-v1.json'
disposition_path = ROOT / 'original-bank-cohort-Root-complete-whole-disposition-v1.json'
review_path = STUDY / 'review-C' / 'typed-original-bank-cohort-complete-whole-actual-review-v1.json'
assert old['cohort_descriptor'] == pin(descriptor_path)
assert old['cohort_disposition'] == pin(disposition_path)
assert old['cohort_C_review'] == pin(review_path)
descriptor, disposition, cohort_review = map(read, (descriptor_path, disposition_path, review_path))
assert descriptor['cohort_id'] == 'signed-propositional-original-bank-cohort-v1'
assert disposition['cohort_admitted'] is True and cohort_review['review_passed'] is True
roles = descriptor['covered_runtime_roles']
original_modules = {row['role']: row['rawpin'] for row in roles}
assert len(roles) == len(original_modules) == 38 and original_modules == old['module_pins']
modules = dict(old['module_pins'])
modules.update(extractor=source2_accept['current']['extractor'],
               instance=source2_accept['current']['instance_service'], receptor_bank=bank_accept['bank'])
assert len(modules) == 41 and list(modules)[:38] == list(old['module_pins'])
assert list(modules)[38:] == ['extractor', 'instance', 'receptor_bank']
assert accept['module_pins'] == modules
active_roles = [dict(role=role, rawpin=modules[role]) for role in ACTIVE]
assert [row['role'] for row in active_roles] == offer['namespaces']['active_import_order']
populations = {row['population']: {key: row[key] for key in
    ('control_ids', 'groups', 'bank_role', 'subject_role', 'scope')}
    for row in descriptor['control_populations']}
assert len(populations) == 17 and populations == old['control_populations']
assert sum(row['groups'] for row in populations.values()) == 229
populations['receptor-DAG8'] = dict(control_ids=bank_api['control_ids'], groups=8,
    bank_role='receptor_bank', subject_role=['extractor', 'instance'], scope=bank_api['scope'])
assert len(populations) == 18
assert descriptor['limits'] == old['limits'] == offer['resources_and_cost']['ten_caps']
assert len(old['limits']) == 10 and old['limits']['result_bytes'] == 50331648
custody = descriptor['custody_runtime']
assert custody['python'] == old['python'] and custody['runner']['path'] == old['runner_path']
raw_inputs = {}
for row in descriptor['raw_inputs']:
    key, ref = row['plan_key'], row['rawpin']
    assert key not in raw_inputs and old[key] == ref
    verify(ref)
    raw_inputs[key] = ref
assert len(raw_inputs) == 8
guards = {}


def guard(ref):
    verify(ref)
    assert '/actual/' not in ref['path'] and not ref['path'].endswith('.bin')
    assert ref['path'] not in guards or guards[ref['path']] == ref
    guards[ref['path']] = ref


for ref in old['files']:
    guard(ref)
for ref in accept['component_reviews'].values():
    guard(ref)
for key in ('worker', 'worker_API', 'worker_offer', 'worker_handoff', 'bank',
            'bank_component_acceptance', 'Source2_component_acceptance'):
    guard(accept[key])
for ref in modules.values():
    guard(ref)
for ref in bank_accept['packet']:
    guard(ref)
guard(bank_accept['handoff'])
guard(bank_accept['component_review'])
for ref in source2_accept['current'].values():
    guard(ref)
guard(source2_accept['handoff'])
guard(source2_accept['C_complete_component_review'])
for path in [accept_path, Path(__file__), authority_path, pair_path, descriptor_path,
             disposition_path, review_path, ROOT / 'issue_receptor_library_grant_v1.py',
             ROOT / 'census_receptor_library_case_v1.py'] + contract_paths + donor_metadata_paths:
    guard(pin(path))
for ref in accept.get('additional_current_guards', []):
    guard(ref)
data_paths = {row[key]['path'] for row in donor_inputs for key in ('query', 'certificate')}
assert len(data_paths) == 4 and not data_paths.intersection(guards)
recipe = dict(case_id=CASE, stage='extract')
app_path = ROOT / (PREFIX + 'applicability-v1.json')
protocol_path = ROOT / (PREFIX + 'whole-protocol-v1.json')
closure_path = ROOT / (PREFIX + 'Source-closure-v1.json')
guard_list_path = ROOT / (PREFIX + 'guard-list-v1.json')
preparation_path = ROOT / (PREFIX + 'study-preparation-v1.json')
plan_path = ROOT / 'plans' / (CASE + '.json')
proposal_path = ROOT / (PREFIX + 'extract-0-grant-proposal-v1.json')
actual = STUDY / 'actual' / CASE
grant_path = ROOT / 'grants' / (CASE + '.json')
fresh = [app_path, protocol_path, closure_path, guard_list_path, preparation_path,
         plan_path, proposal_path, actual, Path(str(actual) + '.observer'), grant_path]
assert len(fresh) == 10
assert all(not path.exists() and not path.is_symlink() for path in fresh)
app_value = dict(schema='Root-FPC-receptor-library-applicability-v1',
    cohort_id=descriptor['cohort_id'], descriptor=pin(descriptor_path),
    Root_disposition=pin(disposition_path), C_review=pin(review_path),
    covered_runtime_roles=roles, control_populations=descriptor['control_populations'],
    raw_inputs=descriptor['raw_inputs'], active_runtime_roles=active_roles,
    custody_runtime=custody, environment=descriptor['environment'],
    reference_integer_policy=['FPC-original-json-integer-policy-v1', 4300],
    limits=old['limits'], donor_pair_authority=pin(pair_path), contract_pins=contract_pins,
    caller_pins=dict(worker=accept['worker'], API=accept['worker_API'],
                     offer=accept['worker_offer'], handoff=accept['worker_handoff']),
    accepted=False, qualification_rerun=False)
assert len(app_value) == 18
app = emit(app_path, app_value)
guard(app)
metadata = dict(cohort_descriptor=pin(descriptor_path), cohort_disposition=pin(disposition_path),
    cohort_C_review=pin(review_path), library_applicability=app,
    donor_pair_authority=pin(pair_path), donor_inputs=donor_inputs,
    extraction_configuration=CONFIGURATION)
assert len(metadata) == 7
protocol = emit(protocol_path, dict(schema='Root-FPC-receptor-library-feasibility-protocol-v1',
    experiment=EXPERIMENT, limits=old['limits'], module_pins=modules,
    control_populations=populations, job_recipes=[recipe], metadata=metadata))
guard(protocol)
guard_list = emit(guard_list_path, dict(schema='Root-receptor-library-guard-list-v1',
    files=[guards[path] for path in sorted(guards)], excludes_own_pin=True,
    original524_guard_floor_preserved=True, donor_data_are_not_Sourceguards=True))
guard(guard_list)
files = [guards[path] for path in sorted(guards)]
base = {key: value for key, value in old.items() if key not in
        ('donor_index', 'input_slot', 'cohort_applicability', 'input_authority', 'search_configuration')}
value = dict(base, **recipe, experiment=EXPERIMENT, actual_dir=str(actual),
    worker_path=accept['worker']['path'], protocol=protocol, files=files,
    module_pins=modules, control_populations=populations, **metadata)
value.update(raw_inputs)
plan = emit(plan_path, value)
closure = emit(closure_path, dict(schema='Root-receptor-library-closed-Source-v1',
    status='PROSPECTIVE_NOT_EXECUTION_AUTHORITY', plans=[plan], protocol=protocol,
    applicability=app, guard_list=guard_list, files=files,
    original524_guard_floor_preserved=True, covered_roles=38, declared_roles=41,
    active_cold_roles=7, prior_control_scopes=17, prior_admitted_groups=229,
    current_control_scopes=1, current_bank_groups=8, cohort_qualification_rerun=False,
    donor_inputs=donor_inputs, donor_body_reads=0, scientific_calls=0))
proposal = emit(proposal_path, dict(schema='Root-receptor-library-once-proposal-v1',
    authorized=False, review_passed=False, uses=1, **recipe, plan_sha256=plan['sha256'],
    runner_sha256=custody['runner']['sha256'], observer_sha256=custody['observer']['sha256'],
    plan=plan, protocol=protocol, closure=closure, applicability=app,
    component_acceptance=pin(accept_path), component_reviews=accept['component_reviews'],
    bank_component_acceptance=accept['bank_component_acceptance'],
    Source2_component_acceptance=accept['Source2_component_acceptance'],
    effective_contract=contract_pins, prospective_grant_path=str(grant_path),
    prospective_command=[custody['python']['path'], '-I', '-S', '-B', custody['observer']['path'],
                         plan['path'], str(grant_path)],
    required_before_grant=['Complete independent whole Source/protocol/plan review',
        'Root current Source guards/storage/fresh case absence and actual tools-idle observation',
        'Separate exact one-use true grant; no plan/Source review alone permits execution'],
    execution_authority=False))
print(json.dumps(emit(preparation_path, dict(schema='Root-receptor-library-preparation-v1',
    status='PROSPECTIVE_REQUIRES_WHOLE_REVIEW', metadata_builder=pin(Path(__file__)),
    component_acceptance=pin(accept_path), worker=accept['worker'], protocol=protocol,
    applicability=app, guard_list=guard_list, recipes=[recipe], plans=[plan], closure=closure,
    proposals=[proposal], shared_guards=len(files), original524_guard_floor_preserved=True,
    covered_roles=38, declared_roles=41, active_cold_roles=7,
    prior_control_populations=17, prior_admitted_groups=229,
    current_control_populations=1, current_bank_groups=8, qualification_rerun=False,
    combined_four_donor_and_boundary_bodies_entire_result_bytes=50331648,
    ten_caps_unchanged=True, all_proposals_false=True, donor_body_reads=0,
    scientific_calls=0, goal_complete=False)), indent=2))
