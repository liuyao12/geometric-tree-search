"""Independent DAG8 public controls. Authored before service implementation intake.

Unexecuted Source: fixture bytes/families are constructed only in a future
reviewed bounded run. Synthetic provenance is explicitly NOT an admission.
Group success covers exercised public facets, never the retained future-use
and scheduler obligations listed in coverage_limits.
"""
import hashlib
import json
import math

VERSION = 'FPC-RECEPTOR-DAG-INDEPENDENT-BANK-v1'
RETURN_SCHEMA = 'FPC-receptor-DAG-independent-controls-v1'
POPULATION = 'receptor-DAG8'
MODULE_KEYS = ('extractor', 'instance', 'checker', 'builders', 'reference', 'tiny_encoder')
CONTROL_IDS = (
    'DAG-shared-versus-unfolded',
    'DAG-equal-boundary-occurrences',
    'DAG-rooted-growth-and-quota',
    'DAG-ordered-canonical-key',
    'DAG-Formula-alias-binding',
    'DAG-ordered-MP-equations',
    'DAG-direct-wire-and-final-used-map',
    'DAG-first-fault-and-fallback',
)
PUBLIC_CALL_COUNTS = (4, 2, 18, 8, 7, 8, 1, 21)
CONFIGURATION = {
    'schema': 'FPC-propositional-receptor-extraction-v1',
    'min_nodes': 2, 'max_nodes': 8, 'per_donor_quota': 2,
    'library_quota': 4, 'max_distinct_boundary_nodes': 4,
    'policy': 'ordered-ancestor-growth-v1',
}
SCOPE = 'Independent synthetic public DAG extraction/instance controls; no donor, library, final-use or GCTS/RL admission.'
LIMITS = (
    'All original DAG8 declarations remain; schematic property graphs are not passed as valid certificates.',
    'Shared/large supplied families test service support, not acquisition by the unchanged first-two policy.',
    'Final used-expansion, primitive fallback, scheduler transactions, overlap reward and all-cutoff cleanup are UNEXERCISED future-consumer/Source obligations.',
    'No forced digest collision, all-subgraph census, real donor extraction, holdout, performance or whole-admission claim.',
)
KEY_FIELDS = ('parameters', 'root_local_id', 'internal_nodes', 'boundary_nodes')
INSTANCE_FIELDS = ('schema', 'complete', 'accepted', 'context_query_identity', 'binding',
                   'expansion_rows', 'family_to_wire_rows', 'boundary_query_bytes',
                   'boundary_certificate_bytes', 'subject_receipt', 'reference_receipt')
EXTRACT_FIELDS = ('schema', 'status', 'complete', 'accepted', 'donor_validation',
                  'families', 'selection_coverage')
ROW_FIELDS = ('wire_index', 'origin_kind', 'origin_id', 'formula', 'rule_tag',
              'subtag', 'witness', 'references')


class ReceptorDAGControlError(Exception):
    pass


class _Call:
    def __init__(self, check):
        if not callable(check):
            raise ReceptorDAGControlError('check must be callable')
        self.check = check
        self.first = None
        self.calls = []
        self.callbacks = 0

    def tick(self):
        self.raise_first()
        try:
            self.callbacks += 1
            self.check()
        except BaseException as error:
            self.first = error
            raise

    def raise_first(self):
        if self.first is not None:
            raise self.first

    def need(self, condition, message):
        self.raise_first()
        if not condition:
            raise ReceptorDAGControlError(message)

    def locate(self, group, facet, endpoint):
        self.tick()
        self.calls.append({'ordinal': len(self.calls), 'group': group,
                           'facet': facet, 'endpoint': endpoint})


def _copy(value, c, evidence=False):
    """Fresh strict image; byte evidence is complete reversible hex, not a hash."""
    box = [None]
    active = set()
    stack = [('value', value, box, 0)]
    while stack:
        c.tick()
        kind, v, parent, key = stack.pop()
        if kind == 'leave':
            active.remove(v)
            continue
        t = type(v)
        if v is None or t in (bool, int, str):
            parent[key] = v
        elif t is float:
            c.need(math.isfinite(v), 'nonfinite evidence')
            parent[key] = v
        elif t is bytes:
            if evidence:
                parent[key] = {'schema': 'L-immutable-bytes-hex-v1', 'bytes': len(v),
                               'sha256': hashlib.sha256(v).hexdigest(), 'hex': v.hex()}
            else:
                parent[key] = v
        elif t in (list, tuple, dict):
            c.need(id(v) not in active, 'cyclic carrier')
            active.add(id(v))
            stack.append(('leave', id(v), None, None))
            if t is dict:
                out = {}
                parent[key] = out
                items = list(v.items())
                for k, child in reversed(items):
                    c.tick()
                    c.need(type(k) is str, 'non-string evidence key')
                    stack.append(('value', child, out, k))
            else:
                out = [None] * len(v)
                parent[key] = out
                for i in range(len(v) - 1, -1, -1):
                    stack.append(('value', v[i], out, i))
        else:
            c.need(False, 'foreign carrier')
    return box[0]


def _same(a, b, c):
    pending = [(a, b)]
    while pending:
        c.tick()
        x, y = pending.pop()
        if type(x) is not type(y):
            return False
        if type(x) is dict:
            if set(x) != set(y):
                return False
            pending.extend((x[k], y[k]) for k in x)
        elif type(x) in (list, tuple):
            if len(x) != len(y):
                return False
            pending.extend(zip(x, y))
        elif x != y:
            return False
    return True


def _fields(value, fields, c, label):
    c.need(type(value) is dict and set(value) == set(fields), label + ' fields')


def _canonical(value, c):
    c.tick()
    result = json.dumps(value, sort_keys=True, separators=(',', ':'),
                        ensure_ascii=True, allow_nan=False).encode('ascii')
    c.tick()
    return result


def _pred(index):
    return ['pred', index, []]


def _imp(a, b):
    return ['imp', a, b]


def _param(index):
    return ['param', index]


def _schema(tag, args):
    a, b = args[:2]
    if tag == 0:
        return _imp(a, _imp(b, a))
    if tag == 1:
        d = args[2]
        return _imp(_imp(a, _imp(b, d)), _imp(_imp(a, b), _imp(a, d)))
    if tag == 2:
        return _imp(_imp(['not', b], ['not', a]), _imp(a, b))
    raise ReceptorDAGControlError('literal logical tag')


def _ref(kind, index):
    return {'kind': kind, 'id': index}


def _logical(index, tag, witnesses):
    return {'local_id': index, 'rule_tag': 1, 'subtag': tag,
            'formula_pattern': _schema(tag, witnesses), 'witness_pattern': witnesses,
            'references': []}


def _mp(index, formula, left, right):
    return {'local_id': index, 'rule_tag': 3, 'subtag': None,
            'formula_pattern': formula, 'witness_pattern': None,
            'references': [left, right]}


def _rekey(family, c):
    family['family_key'] = {k: _copy(family[k], c) for k in KEY_FIELDS}
    family['family_id'] = hashlib.sha256(_canonical(family['family_key'], c)).hexdigest()
    return family


def _family(boundaries, nodes, parameters, c):
    """Authored valid pattern, with openly synthetic non-authoritative provenance."""
    n = len(nodes)
    b = len(boundaries)
    f = {'parameters': [{'id': i, 'sort': 'Formula'} for i in range(parameters)],
         'root_local_id': n - 1, 'internal_nodes': nodes,
         'boundary_nodes': [{'boundary_id': i, 'formula_pattern': v}
                            for i, v in enumerate(boundaries)],
         'source_occurrences': [{'donor_id': 'CONTROL_ONLY_SUPPLIED_PATTERN',
                                 'root_source_row': b + n - 1,
                                 'source_to_local': [[b + i, i] for i in range(n)],
                                 'boundary_source_to_port': [[i, i] for i in range(b)],
                                 'source_bindings': [{'parameter_id': i, 'formula': _pred(i)}
                                                     for i in range(parameters)]}],
         'distinct_base_nodes': n, 'size_band': 'SMALL_2_4' if n <= 4 else 'LARGE_5_8',
         'validation_provenance': [0]}
    return _rekey(f, c)


def _shared(c):
    p = _param(0)
    a = _schema(0, [p, p])
    return _family([], [_logical(0, 0, [p, p]), _logical(1, 0, [a, a]),
                       _mp(2, _imp(a, a), _ref('internal', 0), _ref('internal', 1)),
                       _mp(3, a, _ref('internal', 0), _ref('internal', 2))], 1, c)


def _unfolded(c):
    p, q = _param(0), _param(1)
    a, b = _schema(0, [p, p]), _schema(0, [q, q])
    return _family([], [_logical(0, 0, [p, p]), _logical(1, 0, [q, q]),
                       _logical(2, 0, [b, a]),
                       _mp(3, _imp(a, b), _ref('internal', 1), _ref('internal', 2)),
                       _mp(4, b, _ref('internal', 0), _ref('internal', 3))], 2, c)


def _literal_sharing(c, unfolded=False):
    p, q, z = _param(0), _param(1), _param(2)
    a = _schema(0, [p, p])
    boundaries = [_imp(a, q), _imp(a, _imp(q, z))]
    if unfolded:
        nodes = [_logical(0, 0, [p, p]), _logical(1, 0, [p, p]),
                 _mp(2, q, _ref('internal', 0), _ref('boundary', 0)),
                 _mp(3, _imp(q, z), _ref('internal', 1), _ref('boundary', 1)),
                 _mp(4, z, _ref('internal', 2), _ref('internal', 3))]
        sources = [2, 3, 4, 7, 9]
    else:
        nodes = [_logical(0, 0, [p, p]),
                 _mp(1, q, _ref('internal', 0), _ref('boundary', 0)),
                 _mp(2, _imp(q, z), _ref('internal', 0), _ref('boundary', 1)),
                 _mp(3, z, _ref('internal', 1), _ref('internal', 2))]
        sources = [2, 4, 7, 9]
    f = _family(boundaries, nodes, 3, c)
    f['source_occurrences'][0]['root_source_row'] = 9
    f['source_occurrences'][0]['source_to_local'] = [[v, i] for i, v in enumerate(sources)]
    return f


def _parameter_order(c):
    b, a, z = _param(0), _param(1), _param(2)
    ca = _imp(z, a)
    nodes = [_logical(0, 0, [a, z]),
             _mp(1, ca, _ref('boundary', 1), _ref('internal', 0)),
             _logical(2, 0, [ca, b]),
             _mp(3, _imp(b, ca), _ref('internal', 1), _ref('internal', 2)),
             _mp(4, ca, _ref('boundary', 0), _ref('internal', 3))]
    return _family([b, a], nodes, 3, c)


def _not_alias(c):
    p, q = _param(0), _param(1)
    return _family([_imp(p, ['not', q]), p, _imp(['not', q], p)],
                   [_mp(0, ['not', q], _ref('boundary', 1), _ref('boundary', 0)),
                    _mp(1, p, _ref('internal', 0), _ref('boundary', 2))], 2, c)


def _mp_equations(c):
    p, q = _param(0), _param(1)
    return _family([p, _imp(p, q), _imp(q, q)],
                   [_mp(0, q, _ref('boundary', 0), _ref('boundary', 1)),
                    _mp(1, q, _ref('internal', 0), _ref('boundary', 2))], 2, c)


def _boundary_family(c, duplicate=False):
    p, q = _param(0), _param(1)
    if duplicate:
        return _family([p, p, _imp(p, _imp(p, p))],
                       [_mp(0, _imp(p, p), _ref('boundary', 0), _ref('boundary', 2)),
                        _mp(1, p, _ref('boundary', 1), _ref('internal', 0))], 1, c)
    return _family([p, q, _imp(p, _imp(q, p))],
                   [_mp(0, _imp(q, p), _ref('boundary', 0), _ref('boundary', 2)),
                    _mp(1, p, _ref('boundary', 1), _ref('internal', 0))], 2, c)


def _repeated_boundary(c):
    p = _param(0)
    return _family([p, _imp(p, _imp(p, p))],
                   [_mp(0, _imp(p, p), _ref('boundary', 0), _ref('boundary', 1)),
                    _mp(1, p, _ref('boundary', 0), _ref('internal', 0))], 1, c)


def _six_rows(c):
    p, q = _param(0), _param(1)
    return _family([p, q], [_logical(0, 0, [p, q]),
                           _mp(1, _imp(q, p), _ref('boundary', 0), _ref('internal', 0)),
                           _mp(2, p, _ref('boundary', 1), _ref('internal', 1)),
                           _mp(3, _imp(q, p), _ref('internal', 2), _ref('internal', 0))], 2, c)


def _invalid_shape_cases(c):
    p = _param(0)
    a = _schema(0, [p, p])
    single = _family([], [_logical(0, 0, [p, p])], 1, c)
    nodes = [_logical(0, 0, [p, p]), _logical(1, 0, [a, a]),
             _mp(2, _imp(a, a), _ref('internal', 0), _ref('internal', 1)),
             _mp(3, a, _ref('internal', 0), _ref('internal', 2)),
             _mp(4, _imp(a, a), _ref('internal', 3), _ref('internal', 1)),
             _mp(5, a, _ref('internal', 3), _ref('internal', 4)),
             _mp(6, _imp(a, a), _ref('internal', 5), _ref('internal', 1)),
             _mp(7, a, _ref('internal', 5), _ref('internal', 6)),
             _mp(8, _imp(a, a), _ref('internal', 7), _ref('internal', 1))]
    large = _family([], nodes, 1, c)
    disconnected = _family([], [_logical(0, 0, [p, p]), _logical(1, 0, [p, p]),
        _logical(2, 0, [a, a]), _mp(3, _imp(a, a), _ref('internal', 1), _ref('internal', 2))], 1, c)
    v = [_param(i) for i in range(5)]
    boundaries = [v[0]] + [_imp(v[i], v[i + 1]) for i in range(4)]
    many_ports = _family(boundaries,
        [_mp(i, v[i + 1], _ref('boundary', 0) if i == 0 else _ref('internal', i - 1),
             _ref('boundary', i + 1)) for i in range(4)], 5, c)
    return [('size-one', single), ('size-nine', large),
            ('disconnected-internal', disconnected), ('five-boundaries', many_ports)]


def _bindings(*images):
    return [{'parameter_id': i, 'formula': v} for i, v in enumerate(images)]


def _instantiate(pattern, images, c):
    c.tick()
    if pattern[0] == 'param':
        return _copy(images[pattern[1]], c)
    if pattern[0] == 'not':
        return ['not', _instantiate(pattern[1], images, c)]
    c.need(pattern[0] == 'imp', 'literal pattern constructor')
    return _imp(_instantiate(pattern[1], images, c), _instantiate(pattern[2], images, c))


def _declaration(goal):
    return {'version': 1, 'claim_mode': 0, 'function_arities': [],
            'predicate_arities': [0, 0, 0], 'theory_profile': 0,
            'finite_axioms': [], 'Gamma': [], 'goal': goal}


def _nat(value, out, c):
    c.need(type(value) is int and value >= 0, 'literal natural')
    while True:
        c.tick()
        byte = value & 127
        value >>= 7
        out.append(byte | (128 if value else 0))
        if not value:
            return


def _formula(formula, out, c):
    stack = [formula]
    while stack:
        c.tick()
        f = stack.pop()
        if f[0] == 'pred':
            c.need(f[2] == [], 'fixture nullary predicate')
            _nat(0, out, c)
            _nat(f[1], out, c)
            _nat(0, out, c)
        elif f[0] == 'not':
            _nat(2, out, c)
            stack.append(f[1])
        elif f[0] == 'imp':
            _nat(3, out, c)
            stack.extend((f[2], f[1]))
        else:
            c.need(False, 'fixture formula constructor')


def _certificate(rows, c):
    out = bytearray(b'FPP1')
    _nat(len(rows), out, c)
    for formula, tag, payload in rows:
        c.tick()
        _formula(formula, out, c)
        _nat(tag, out, c)
        if tag == 1:
            _nat(payload[0], out, c)
            for witness in payload[1:]:
                _formula(witness, out, c)
        elif tag == 0:
            _nat(payload[0], out, c)
        elif tag == 3:
            _nat(payload[0], out, c)
            _nat(payload[1], out, c)
        else:
            c.need(False, 'fixture rule constructor')
    c.tick()
    return bytes(out)


def _encode(modules, goal, c, group, facet, declaration=None):
    c.locate(group, facet, 'tiny_encoder.encode_tiny_declared_query')
    declared = _declaration(goal) if declaration is None else declaration
    saved = _copy(declared, c)
    result = modules['tiny_encoder'].encode_tiny_declared_query(declared, check=c.tick)
    _fields(result, ('query_bytes', 'receipt'), c, 'encoder')
    c.need(type(result['query_bytes']) is bytes, 'query bytes')
    c.need(_same(declared, saved, c), 'encoder mutated declaration')
    c.locate(group, facet + '-decode', 'checker.decode_query')
    decoded = modules['checker'].decode_query(result['query_bytes'], check=c.tick)
    c.need(all(k in decoded for k in saved), 'decoded semantic fields')
    for k in saved:
        c.need(_same(decoded[k], saved[k], c), 'query semantic roundtrip ' + k)
    return result['query_bytes']


def _provenance(query, certificate, c):
    empty = hashlib.sha256(b'').hexdigest()
    pin = {'path': '/CONTROL_ONLY_NOT_AN_ADMISSION', 'bytes': 0, 'sha256': empty}
    return {'schema': 'FPC-receptor-donor-provenance-v1',
            'Root_admission': _copy(pin, c), 'C_actual_review': _copy(pin, c),
            'query': {'bytes': len(query), 'sha256': hashlib.sha256(query).hexdigest()},
            'certificate': {'bytes': len(certificate), 'sha256': hashlib.sha256(certificate).hexdigest()},
            'module_pins': {k: _copy(pin, c) for k in ('checker', 'builders', 'reference')}}


def _donors(modules, c, shifted=False):
    donors = []
    for index in range(2):
        p = _pred(index)
        a = _schema(0, [p, p])
        offset = 1 if shifted else 0
        rows = ([(a, 1, [0, p, p])] if shifted else [])
        rows += [(a, 1, [0, p, p]), (_schema(0, [a, a]), 1, [0, a, a]),
                 (_imp(a, a), 3, [offset, offset + 1]),
                 (a, 3, [offset, offset + 2])]
        query = _encode(modules, a, c, CONTROL_IDS[2 if not shifted else 3],
                        ('shifted-' if shifted else '') + 'donor-' + str(index))
        certificate = _certificate(rows, c)
        donors.append({'donor_id': 'CONTROL_ONLY_DONOR_' + str(index),
                       'query_bytes': query, 'certificate_bytes': certificate,
                       'provenance': _provenance(query, certificate, c)})
    return donors


def _unsupported_donors(modules, c):
    donors = []
    for i in range(2):
        p = _pred(i)
        declared = _declaration(p)
        declared['claim_mode'] = 1
        declared['Gamma'] = [p, _imp(p, p)]
        query = _encode(modules, p, c, CONTROL_IDS[2], 'unsupported-HYP-donor-' + str(i), declared)
        certificate = _certificate([(p, 0, [0]), (_imp(p, p), 0, [1]), (p, 3, [0, 1])], c)
        donors.append({'donor_id': 'CONTROL_ONLY_UNSUPPORTED_' + str(i),
                       'query_bytes': query, 'certificate_bytes': certificate,
                       'provenance': _provenance(query, certificate, c)})
    return donors


def _compile(modules, context, family, bindings, c, group, facet):
    before = _copy([family, bindings], c)
    c.locate(group, facet, 'instance.compile_instance')
    result = modules['instance'].compile_instance(
        context, family, bindings, encoder=modules['tiny_encoder'].encode_tiny_declared_query,
        modules={k: modules[k] for k in ('checker', 'builders', 'reference')}, check=c.tick)
    _fields(result, INSTANCE_FIELDS, c, 'instance')
    c.need(result['schema'] == 'FPC-receptor-instance-candidate-v1' and
           result['complete'] is True and result['accepted'] is False, 'instance flags')
    c.need(_same([family, bindings], before, c), 'compile mutated inputs')
    c.need(type(result['boundary_query_bytes']) is bytes and
           type(result['boundary_certificate_bytes']) is bytes, 'instance immutable bytes')
    c.need(result['subject_receipt']['status'] == 'VALID_DERIVATION' and
           result['reference_receipt']['status'] == 'VALID_DERIVATION', 'paired valid statuses')
    c.need(result['subject_receipt']['complete'] is True and
           result['reference_receipt']['complete_check'] is True and
           result['subject_receipt']['final_goal_equal'] is True and
           result['reference_receipt']['final_goal_equal'] is True, 'paired complete goals')
    _fields(result['context_query_identity'], ('query_hex', 'bytes', 'sha256', 'version',
            'claim_mode', 'function_arities', 'predicate_arities', 'theory_profile',
            'finite_axioms', 'Gamma', 'goal'), c, 'context query identity')
    c.need(result['context_query_identity']['query_hex'] == context.hex() and
           result['context_query_identity']['bytes'] == len(context) and
           result['context_query_identity']['sha256'] == hashlib.sha256(context).hexdigest(),
           'complete original context bytes')
    b, n = len(family['boundary_nodes']), len(family['internal_nodes'])
    expected = {'boundary_to_wire': [[i, i] for i in range(b)],
                'internal_to_wire': [[i, b + i] for i in range(n)]}
    c.need(_same(result['family_to_wire_rows'], expected, c), 'physical maps')
    rows = result['expansion_rows']
    c.need(type(rows) is list and len(rows) == b + n, 'all physical rows')
    images = [v['formula'] for v in bindings]
    for i, row in enumerate(rows):
        c.tick()
        _fields(row, ROW_FIELDS, c, 'physical row')
        c.need(type(row['wire_index']) is int and row['wire_index'] == i, 'physical index')
        c.need(row['origin_kind'] == ('boundary' if i < b else 'internal') and
               type(row['origin_id']) is int and row['origin_id'] == (i if i < b else i - b),
               'physical origin')
        if i < b:
            c.need(row['rule_tag'] == 0 and row['subtag'] is None and
                   row['witness'] == [i] and row['references'] == [], 'boundary HYP occurrence')
            expected_formula = _instantiate(family['boundary_nodes'][i]['formula_pattern'], images, c)
        else:
            node = family['internal_nodes'][i - b]
            expected_formula = _instantiate(node['formula_pattern'], images, c)
            c.need(row['rule_tag'] == node['rule_tag'] and row['subtag'] == node['subtag'],
                   'original primitive rule and subtag')
            if node['rule_tag'] == 1:
                expected_witness = [_instantiate(v, images, c) for v in node['witness_pattern']]
                c.need(_same(row['witness'], expected_witness, c) and row['references'] == [],
                       'ordered logical witnesses')
            else:
                refs = [(v['id'] if v['kind'] == 'boundary' else b + v['id'])
                        for v in node['references']]
                c.need(row['witness'] == refs and row['references'] == refs, 'ordered MP remapping')
        c.need(_same(row['formula'], expected_formula, c), 'every expanded Formula image')
    c.need(result['subject_receipt']['certificate']['row_count'] == b + n,
           'subject full row count')
    return result


def _extract(modules, donors, c, group, facet, usable=True):
    saved = _copy(donors, c)
    config = _copy(CONFIGURATION, c)
    c.locate(group, facet, 'extractor.extract_families')
    result = modules['extractor'].extract_families(
        donors, modules={k: modules[k] for k in ('checker', 'builders', 'reference')},
        configuration=config, check=c.tick)
    _fields(result, EXTRACT_FIELDS, c, 'extractor')
    c.need(result['schema'] == 'FPC-propositional-receptor-library-candidate-v1' and
           result['status'] == ('LIBRARY_CANDIDATE' if usable else 'NO_USABLE_LIBRARY') and
           result['complete'] is True and
           result['accepted'] is False, 'extraction flags')
    c.need(_same(donors, saved, c) and _same(config, CONFIGURATION, c), 'extractor input stability')
    validation = result['donor_validation']
    c.need(type(validation) is list and len(validation) == 2, 'complete ordered donor checks')
    for i, record in enumerate(validation):
        c.tick()
        _fields(record, ('validation_index', 'donor_id', 'query_identity', 'certificate_identity',
                         'provenance', 'subject_receipt', 'reference_receipt'), c, 'donor validation')
        c.need(type(record['validation_index']) is int and record['validation_index'] == i and
               record['donor_id'] == donors[i]['donor_id'] and
               _same(record['provenance'], donors[i]['provenance'], c), 'donor validation association')
        for field, source in (('query_identity', 'query_bytes'), ('certificate_identity', 'certificate_bytes')):
            raw = donors[i][source]
            c.need(record[field] == {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
                   'original donor byte identity')
        c.need(record['subject_receipt']['status'] == 'VALID_DERIVATION' and
               record['reference_receipt']['status'] == 'VALID_DERIVATION' and
               record['subject_receipt']['complete'] is True and
               record['reference_receipt']['complete_check'] is True, 'actual full donor validations')
    coverage = result['selection_coverage']
    _fields(coverage, ('policy', 'exhaustive_connected_subgraphs', 'root_order', 'growth',
                      'min_nodes', 'max_nodes', 'max_distinct_boundary_nodes', 'per_donor_quota',
                      'library_quota', 'donors', 'selected_occurrences', 'distinct_keys',
                      'represented_donors', 'library_gate', 'source_occurrence_instance_gate',
                      'sharing_or_multiscale_coverage_claim'), c, 'selection coverage')
    c.need(coverage['root_order'] == 'increasing-source-row' and
           coverage['growth'] == 'least-current-external-predecessor' and
           coverage['source_occurrence_instance_gate'] == 'NOT_RUN_EXTERNAL_INSTANCE_CALLER_REQUIRED' and
           coverage['sharing_or_multiscale_coverage_claim'] is False and
           coverage['represented_donors'] == ([v['donor_id'] for v in donors] if usable else []),
           'declared policy coverage')
    for key in CONFIGURATION:
        if key != 'schema':
            c.need(coverage[key] == CONFIGURATION[key], 'fixed policy value ' + key)
    c.need(type(result['families']) is list and len(result['families']) == (2 if usable else 0),
           'normal selected family count')
    for f in result['families']:
        _fields(f, ('family_key', 'family_id', 'parameters', 'root_local_id', 'internal_nodes',
                    'boundary_nodes', 'source_occurrences', 'distinct_base_nodes', 'size_band',
                    'validation_provenance'), c, 'family')
        c.need(_same(f['family_key'], {k: f[k] for k in KEY_FIELDS}, c) and
               f['family_id'] == hashlib.sha256(_canonical(f['family_key'], c)).hexdigest(),
               'full family key and display identity')
    return result


def _match(modules, family, inputs, output, c, group, facet):
    saved = _copy([family, inputs, output], c)
    c.locate(group, facet, 'instance.match_receptor')
    result = modules['instance'].match_receptor(family, input_formulas=inputs,
                                               output_formula=output, check=c.tick)
    _fields(result, ('matched', 'bindings', 'residual_parameters'), c, 'match')
    c.need(type(result['matched']) is bool, 'matched bool')
    c.need(_same([family, inputs, output], saved, c), 'match mutated inputs')
    return result


def _refusal(service, operation, c, group, facet, observations, tracked=()):
    saved = _copy(tracked, c)
    c.locate(group, facet, 'owned refusal public endpoint')
    try:
        operation(c.tick)
    except BaseException as error:
        c.raise_first()
        if not service.is_owned_error(error):
            raise
        c.need(type(error.code) is str and error.code in
               ('INVALID_INPUT', 'INVALID_FAMILY', 'UNSUPPORTED_SCOPE', 'INVALID_INSTANCE'),
               'public refusal code')
        c.need(type(error.path) is tuple and all(type(x) is str or
               (type(x) is int and x >= 0) for x in error.path), 'public refusal path')
        c.need(_same(_copy(tracked, c), saved, c), 'normal refusal mutated input')
        observations.append({'facet': facet, 'code': error.code, 'path': list(error.path),
                             'args': list(error.args)})
        return error
    c.need(False, 'expected owned refusal ' + facet)


def _row(identifier, observations, limits, c):
    return {'id': identifier, 'passed': True, 'observations': _copy(observations, c, True),
            'coverage_limits': list(limits)}


class _FaultNamespace:
    """Negative-only delegate; never patches an authentic module or returns fake data."""
    def __init__(self, base, target, error, state, c):
        self.base = base
        self.target = target
        self.error = error
        self.state = state
        self.c = c

    def __getattr__(self, name):
        value = getattr(self.base, name)
        if not callable(value) or isinstance(value, type):
            return value
        def guarded(*args, **kwargs):
            if self.state['thrown']:
                self.state['later_helpers'] += 1
                raise RuntimeError('CONTROL_ONLY_FORBIDDEN_LATER_HELPER')
            if name != self.target:
                return value(*args, **kwargs)
            self.state['target_entries'] += 1
            check = kwargs.get('check')
            self.c.need(callable(check), 'dependency forwarded genuine check')
            check()
            self.state['thrown'] = True
            self.state['callbacks_at_throw'] = self.c.callbacks
            raise self.error
        return guarded


def _dependency_fault(modules, context, family, donors, endpoint, role, target, error, c, obs):
    state = {'thrown': False, 'target_entries': 0, 'later_helpers': 0,
             'callbacks_at_throw': None}
    projection = {k: modules[k] for k in ('checker', 'builders', 'reference')}
    encoder = modules['tiny_encoder'].encode_tiny_declared_query
    if role == 'encoder':
        def encoder(*args, **kwargs):
            if state['thrown']:
                state['later_helpers'] += 1
                raise RuntimeError('CONTROL_ONLY_FORBIDDEN_LATER_ENCODER')
            state['target_entries'] += 1
            c.need(callable(kwargs.get('check')), 'encoder genuine check keyword')
            kwargs['check']()
            state['thrown'] = True
            state['callbacks_at_throw'] = c.callbacks
            raise error
    else:
        projection[role] = _FaultNamespace(modules[role], target, error, state, c)
    c.locate(CONTROL_IDS[7], endpoint + '-' + role + '-' + target,
             'throw-only public dependency')
    try:
        if endpoint == 'compile':
            modules['instance'].compile_instance(context, family, _bindings(_pred(0)),
                encoder=encoder, modules=projection, check=c.tick)
        else:
            modules['extractor'].extract_families(donors, modules=projection,
                configuration=_copy(CONFIGURATION, c), check=c.tick)
    except BaseException as caught:
        c.raise_first()
        if caught is not error:
            raise
        c.need(state['target_entries'] == 1 and state['thrown'] and
               state['later_helpers'] == 0 and c.callbacks == state['callbacks_at_throw'],
               'nonvacuous dependency first-E/no-later-work')
        obs.append({'endpoint': endpoint, 'dependency_role': role, 'method': target,
                    'same_object': True, 'target_entries': state['target_entries'],
                    'postfault_callbacks': 0, 'postfault_proxy_helpers': 0,
                    'error_type': type(error).__name__, 'args': list(error.args),
                    'code': getattr(error, 'code', None),
                    'path': list(error.path) if hasattr(error, 'path') else None})
    else:
        c.need(False, 'dependency fault did not escape')


def run_bank(modules, *, check):
    c = _Call(check)
    try:
        c.tick()
        _fields(modules, MODULE_KEYS, c, 'modules')
        projection_fields = {
            'extractor': ('VERSION', 'extract_families', 'FamilyInputError', 'is_owned_error'),
            'instance': ('VERSION', 'match_receptor', 'compile_instance', 'FamilyInputError', 'is_owned_error'),
            'checker': ('VERSION', 'decode_query', 'check_certificate'),
            'builders': ('VERSION', 'logical_axiom'),
            'reference': ('VERSION', 'reference_check_certificate'),
            'tiny_encoder': ('VERSION', 'encode_tiny_declared_query'),
        }
        namespace_snapshot = [(modules[role], field, getattr(modules[role], field))
                              for role in MODULE_KEYS for field in projection_fields[role]]
        c.need(modules['extractor'].VERSION == 'FPC-RECEPTOR-FAMILY-EXTRACTOR-v2',
               'extractor VERSION')
        c.need(modules['instance'].VERSION == 'FPC-RECEPTOR-INSTANCE-SERVICE-v2',
               'instance VERSION')
        context = _encode(modules, _pred(0), c, CONTROL_IDS[0], 'context-only-no-proof')
        controls = []

        shared, unfolded = _shared(c), _unfolded(c)
        literal_shared, literal_unfolded = _literal_sharing(c), _literal_sharing(c, True)
        one = _compile(modules, context, literal_shared, _bindings(_pred(0), _pred(1), _pred(2)), c,
                       CONTROL_IDS[0], 'shared-four')
        two = _compile(modules, context, literal_unfolded, _bindings(_pred(0), _pred(1), _pred(2)), c,
                       CONTROL_IDS[0], 'unfolded-five')
        c.need(len(one['expansion_rows']) == 6 and len(two['expansion_rows']) == 7,
               'shared versus unfolded counts')
        c.need(one['expansion_rows'][3]['references'] == [2, 0] and
               one['expansion_rows'][4]['references'] == [2, 1], 'shared physical fan-out')
        c.need(two['expansion_rows'][2]['formula'] == two['expansion_rows'][3]['formula'] and
               two['expansion_rows'][2]['witness'] == two['expansion_rows'][3]['witness'] and
               two['expansion_rows'][2]['wire_index'] != two['expansion_rows'][3]['wire_index'],
               'distinct equal-content nodes survive')
        c.need(not _same(literal_shared['family_key'], literal_unfolded['family_key'], c),
               'different incidence keys')
        controls.append(_row(CONTROL_IDS[0], [one, two],
            ['Original sourceIDs2/4/7/9 and2/3/4/7/9 incidence receives independently authored valid Formula/rule assignments; shape alone is not a checked certificate.',
             'Supplied shared shape is service support; unchanged extraction does not acquire it.'], c))

        dup, repeated = _boundary_family(c, True), _repeated_boundary(c)
        dr = _compile(modules, context, dup, _bindings(_pred(0)), c,
                      CONTROL_IDS[1], 'distinct-equal-Gamma-ports')
        rr = _compile(modules, context, repeated, _bindings(_pred(0)), c,
                      CONTROL_IDS[1], 'repeated-one-port')
        c.need(dr['subject_receipt']['query']['Gamma'][0:2] == [_pred(0), _pred(0)],
               'duplicate Gamma occurrences')
        c.need(len(dr['expansion_rows']) == 5 and len(rr['expansion_rows']) == 4,
               'distinct boundary count')
        controls.append(_row(CONTROL_IDS[1], [dr, rr],
            ['The exact two-port schematic graph remains a declaration; the valid public analog uses three versus two ports.'], c))

        donors = _donors(modules, c)
        extracted = _extract(modules, donors, c, CONTROL_IDS[2], 'two-genuine-synthetic-pairs')
        coverage = extracted['selection_coverage']
        c.need(coverage['selected_occurrences'] == 4 and coverage['distinct_keys'] == 2 and
               coverage['library_gate'] is True and coverage['exhaustive_connected_subgraphs'] is False,
               'quota and merge')
        c.need([f['distinct_base_nodes'] for f in extracted['families']] == [2, 3],
               'conditional size2/3 policy')
        for i, record in enumerate(coverage['donors']):
            c.tick()
            expected = {'reachable_rows': 4, 'roots_visited': 3, 'candidate_prefixes_examined': 2,
                        'eligible_prefixes': 2, 'duplicate_keys_ignored': 0,
                        'selected_distinct_keys': 2, 'quota_reached': True,
                        'reachable_root_scan_exhausted': False, 'unsupported_prefixes': 0,
                        'boundary_limit_prefixes': 0, 'donor_id': donors[i]['donor_id']}
            c.need(_same(record, expected, c), 'literal extraction coverage')
        for f in extracted['families']:
            c.tick()
            c.need(len(f['source_occurrences']) == 2 and f['validation_provenance'] == [0, 1],
                   'both donor representatives')
            c.need(type(f['distinct_base_nodes']) is int and f['size_band'] == 'SMALL_2_4',
                   'honest selected size metadata')
        source_instances = []
        for fi, f in enumerate(extracted['families']):
            for oi, occurrence in enumerate(f['source_occurrences']):
                expected_map = [[0, 0], [2, 1]] if fi == 0 else [[0, 0], [1, 1], [2, 2]]
                c.need(occurrence['donor_id'] == donors[oi]['donor_id'] and
                       occurrence['root_source_row'] == 2 and
                       occurrence['source_to_local'] == expected_map and
                       occurrence['boundary_source_to_port'] == ([[1, 0]] if fi == 0 else []) and
                       occurrence['source_bindings'] == _bindings(_pred(oi)),
                       'first reachable MP literal source mapping')
                result = _compile(modules, donors[oi]['query_bytes'], f, occurrence['source_bindings'],
                                  c, CONTROL_IDS[2], 'selected-source-' + str(fi) + '-' + str(oi))
                source_instances.append(result)
        unsupported = _unsupported_donors(modules, c)
        no_library = _extract(modules, unsupported, c, CONTROL_IDS[2], 'unsupported-internal-normal-STOP',
                              usable=False)
        nc = no_library['selection_coverage']
        c.need(nc['library_gate'] is False and nc['selected_occurrences'] == 0 and nc['distinct_keys'] == 0,
               'no usable library is unadmitted STOP')
        for i, record in enumerate(nc['donors']):
            expected = {'donor_id': unsupported[i]['donor_id'], 'reachable_rows': 3,
                        'roots_visited': 3, 'candidate_prefixes_examined': 2,
                        'eligible_prefixes': 0, 'duplicate_keys_ignored': 0,
                        'selected_distinct_keys': 0, 'quota_reached': False,
                        'reachable_root_scan_exhausted': True, 'unsupported_prefixes': 2,
                        'boundary_limit_prefixes': 0}
            c.need(_same(record, expected, c), 'unsupported prefix exact coverage')
        shape_refusals = []
        for label, malformed_family in _invalid_shape_cases(c):
            inputs = [_pred(0)] * len(malformed_family['boundary_nodes'])
            _refusal(modules['instance'], lambda check, f=malformed_family, v=inputs:
                modules['instance'].match_receptor(f, input_formulas=v, output_formula=None,
                                                   check=check), c, CONTROL_IDS[2], label,
                shape_refusals, tracked=[malformed_family, inputs])
        controls.append(_row(CONTROL_IDS[2], [extracted] + source_instances + [no_library] + shape_refusals,
            ['Control provenance is transparently synthetic/non-admitting; both Q/C pairs are genuinely checked.',
             'Service size1/9, disconnected and boundary5 refusals are exercised; original least-predecessor prefix literal and later-prefix boundary recovery remain declarative/Source obligations because the current closed pure quota cannot reach those positive cases.',
             'Normal NO_USABLE_LIBRARY is exercised by genuinely valid HYP/MP consequences, whose HYP-containing candidate prefixes are unsupported; no replacement or exhaustive nonexistence claim.'], c))

        shifted = _donors(modules, c, True)
        renamed = _extract(modules, shifted, c, CONTROL_IDS[3], 'order-preserving-source-renaming')
        c.need(_same([f['family_key'] for f in extracted['families']],
                     [f['family_key'] for f in renamed['families']], c), 'key ignores source shift')
        for old, new in zip(extracted['families'], renamed['families']):
            c.tick()
            c.need(old['family_id'] == new['family_id'], 'canonical display digest')
            for x, y in zip(old['source_occurrences'], new['source_occurrences']):
                c.need(y['root_source_row'] == x['root_source_row'] + 1 and
                       y['source_to_local'] == [[s + 1, local] for s, local in x['source_to_local']],
                       'source order normalization provenance')
        wrong = _shared(c)
        wrong['parameters'][0]['id'] = True
        obs = [renamed]
        order_family = _parameter_order(c)
        matched_order = _match(modules, order_family, [_pred(1), _pred(0)],
            _imp(_pred(2), _pred(0)), c, CONTROL_IDS[3], 'boundary-B-A-then-C-parameter-order')
        c.need(matched_order == {'matched': True, 'bindings': _bindings(_pred(1), _pred(0), _pred(2)),
                               'residual_parameters': []}, 'literal B A C parameter order')
        obs += [matched_order, _compile(modules, context, order_family,
            _bindings(_pred(1), _pred(0), _pred(2)), c, CONTROL_IDS[3], 'B-A-C-whole-instance')]
        _refusal(modules['instance'], lambda check: modules['instance'].match_receptor(
            wrong, input_formulas=[], output_formula=None, check=check), c,
            CONTROL_IDS[3], 'strict-parameter-ID', obs, tracked=[wrong])
        controls.append(_row(CONTROL_IDS[3], obs,
            ['B/A/C traversal is exercised through a valid supplied logical/MP family; the original standalone not(C) schematic is not presented as an accepting graph.',
             'Full-key digest-collision equality remains a Source obligation; no forced collision hook exists.',
             'No equivalence under arbitrary independent-row permutation is claimed.'], c))

        obs = []
        partial = _match(modules, unfolded, [], None, c, CONTROL_IDS[4], 'residual-no-default')
        c.need(partial == {'matched': True, 'bindings': [],
                           'residual_parameters': unfolded['parameters']}, 'all residual parameters')
        obs.append(partial)
        for label, bad in [('missing', []), ('extra', _bindings(_pred(0), _pred(1), _pred(2))),
                           ('duplicate', [{'parameter_id': 0, 'formula': _pred(0)},
                                          {'parameter_id': 0, 'formula': _pred(0)}]),
                           ('wrong-sort', [{'parameter_id': 0, 'formula': 3},
                                           {'parameter_id': 1, 'formula': _pred(1)}])]:
            _refusal(modules['instance'], lambda check, v=bad: modules['instance'].compile_instance(
                context, unfolded, v, encoder=modules['tiny_encoder'].encode_tiny_declared_query,
                modules={k: modules[k] for k in ('checker', 'builders', 'reference')}, check=check),
                c, CONTROL_IDS[4], label + '-binding', obs, tracked=[unfolded, bad])
        quantified = ['all', 7, _pred(2)]
        qr = _compile(modules, context, unfolded, _bindings(quantified, quantified), c,
                      CONTROL_IDS[4], 'whole-quantified-image-alias')
        c.need(qr['expansion_rows'][0]['formula'] == _schema(0, [quantified, quantified]) and
               qr['expansion_rows'][1]['formula'] == qr['expansion_rows'][0]['formula'],
               'whole image no recursive substitution')
        obs.append(qr)
        alias_not = _compile(modules, context, _not_alias(c), _bindings(_pred(1), _pred(1)),
                             c, CONTROL_IDS[4], 'literal-imp-not-alias-image')
        c.need(alias_not['subject_receipt']['query']['Gamma'][0] ==
               _imp(_pred(1), ['not', _pred(1)]), 'original imp-not alias literal')
        obs.append(alias_not)
        controls.append(_row(CONTROL_IDS[4], obs,
            ['The original imp(F0,not(F1)) alias equation is exercised as a boundary Formula of a valid relative proof, not a claimed closed theorem.'], c))

        f = _mp_equations(c)
        p, q = _pred(0), _pred(1)
        good_inputs = [p, _imp(p, q), _imp(q, q)]
        obs = []
        good = _match(modules, f, good_inputs, q, c, CONTROL_IDS[5], 'ordered-equations-positive')
        c.need(good == {'matched': True, 'bindings': _bindings(p, q), 'residual_parameters': []},
               'complete ordered match')
        obs.append(good)
        for label, inputs, output in [('wrong-antecedent', [q, good_inputs[1], good_inputs[2]], q),
                                       ('wrong-output', good_inputs, p),
                                       ('swapped-ports', [good_inputs[1], p, good_inputs[2]], q)]:
            value = _match(modules, f, inputs, output, c, CONTROL_IDS[5], label)
            c.need(value == {'matched': False, 'bindings': [], 'residual_parameters': f['parameters']},
                   'normal mismatch clears bindings')
            obs.append(value)
        bad_ref = _copy(f, c)
        bad_ref['internal_nodes'][0]['references'][0] = _ref('internal', 1)
        _rekey(bad_ref, c)
        _refusal(modules['instance'], lambda check: modules['instance'].match_receptor(
            bad_ref, input_formulas=good_inputs, output_formula=q, check=check), c,
            CONTROL_IDS[5], 'forward-reference', obs, tracked=[bad_ref, good_inputs])
        _refusal(modules['instance'], lambda check: modules['instance'].match_receptor(
            f, input_formulas=good_inputs[:-1], output_formula=q, check=check), c,
            CONTROL_IDS[5], 'unfilled-boundary', obs, tracked=[f, good_inputs])
        for tag, witnesses, count in [(1, [_param(0), _param(1), _param(2)], 3),
                                       (2, [_param(1), _param(0)], 2)]:
            ax = _logical(0, tag, witnesses)
            premise, conclusion = ax['formula_pattern'][1:]
            lf = _family([premise], [ax, _mp(1, conclusion, _ref('boundary', 0),
                                            _ref('internal', 0))], count, c)
            obs.append(_compile(modules, context, lf,
                       _bindings(*[_pred(i) for i in range(count)]), c, CONTROL_IDS[5],
                       'logical-subtag-' + str(tag)))
        controls.append(_row(CONTROL_IDS[5], obs,
            ['All three original one-MP semantic tuples are constrained at the public interface of a valid two-MP family with an additional explicit relative premise.',
             'Logical H1/H2/H3 reconstruct positively through real instance compilation and both original checkers; no fake builder receipt.'], c))

        six = _compile(modules, context, _six_rows(c), _bindings(p, q), c,
                       CONTROL_IDS[6], 'literal-two-boundary-four-internal-map')
        c.need(six['family_to_wire_rows'] == {'boundary_to_wire': [[0, 0], [1, 1]],
                   'internal_to_wire': [[0, 2], [1, 3], [2, 4], [3, 5]]}, 'literal six-row map')
        c.need(six['expansion_rows'][-1]['references'] == [4, 2], 'repeated original reference')
        c.need(six['context_query_identity']['goal'] == _pred(0) and
               six['subject_receipt']['query']['goal'] == _imp(q, p), 'boundary is not context theorem')
        controls.append(_row(CONTROL_IDS[6], [six],
            ['UNEXERCISED: final theorem used-map, genuine earlier-frame boundary placement, member/envelope/Gamma consumer guards, overlapping instance accounting and final root reachability. No consumer exists in this public API.'], c))

        obs = []
        service = modules['instance']
        malformed = _shared(c)
        malformed.pop('family_key')
        retained = _refusal(service, lambda check: service.match_receptor(
            malformed, input_formulas=[], output_formula=None, check=check), c,
            CONTROL_IDS[7], 'obtain-retained-owned-error', obs, tracked=[malformed])
        retained_extract = _refusal(modules['extractor'], lambda check:
            modules['extractor'].extract_families([donors[0], donors[0]],
                modules={k: modules[k] for k in ('checker', 'builders', 'reference')},
                configuration=_copy(CONFIGURATION, c), check=check), c,
            CONTROL_IDS[7], 'obtain-retained-extractor-owned-error', obs, tracked=donors)
        for endpoint in ('match', 'compile', 'extract'):
            for fault_label in ('runtime', 'stopiteration', 'unowned-same-class', 'retained-owned'):
                if fault_label == 'runtime':
                    error = RuntimeError('CONTROL_ONLY_FIRST_E')
                elif fault_label == 'stopiteration':
                    error = StopIteration('CONTROL_ONLY_FIRST_E')
                elif fault_label == 'unowned-same-class':
                    owner = modules['extractor'] if endpoint == 'extract' else service
                    error = owner.FamilyInputError('CONTROL_ONLY_UNOWNED')
                    c.need(owner.is_owned_error(error) is False, 'public construction unowned')
                else:
                    error = retained_extract if endpoint == 'extract' else retained
                seen = [0]
                prior = (error.args, getattr(error, 'code', None), getattr(error, 'path', None))
                def fault_check():
                    c.tick()
                    seen[0] += 1
                    if seen[0] > 1:
                        raise RuntimeError('CONTROL_ONLY_FORBIDDEN_LATER_F')
                    raise error
                c.locate(CONTROL_IDS[7], endpoint + '-' + fault_label, 'public first callback')
                try:
                    if endpoint == 'match':
                        service.match_receptor(shared, input_formulas=[], output_formula=None,
                                               check=fault_check)
                    elif endpoint == 'compile':
                        service.compile_instance(context, shared, _bindings(p),
                            encoder=modules['tiny_encoder'].encode_tiny_declared_query,
                            modules={k: modules[k] for k in ('checker', 'builders', 'reference')},
                            check=fault_check)
                    else:
                        modules['extractor'].extract_families(donors,
                            modules={k: modules[k] for k in ('checker', 'builders', 'reference')},
                            configuration=_copy(CONFIGURATION, c), check=fault_check)
                except BaseException as caught:
                    c.raise_first()
                    if caught is not error:
                        raise
                    c.need(seen == [1] and (error.args, getattr(error, 'code', None),
                           getattr(error, 'path', None)) == prior, 'first fault identity/lifetime')
                    obs.append({'endpoint': endpoint, 'fault': fault_label,
                                'same_object': True, 'callbacks': seen[0],
                                'code': getattr(error, 'code', None),
                                'path': list(error.path) if hasattr(error, 'path') else None})
                else:
                    c.need(False, 'first fault did not escape')
        dependency_cases = [
            ('compile', 'encoder', 'encode_tiny_declared_query', RuntimeError('CONTROL_ENCODER_E')),
            ('compile', 'builders', 'logical_axiom', StopIteration('CONTROL_BUILDER_E')),
            ('compile', 'checker', 'check_certificate', service.FamilyInputError('CONTROL_UNOWNED_E')),
            ('compile', 'reference', 'reference_check_certificate', retained),
            ('extract', 'builders', 'logical_axiom', StopIteration('CONTROL_EXTRACT_BUILDER_E')),
            ('extract', 'checker', 'check_certificate',
             modules['extractor'].FamilyInputError('CONTROL_EXTRACT_UNOWNED_E')),
            ('extract', 'reference', 'reference_check_certificate', retained_extract),
        ]
        for endpoint, role, target, error in dependency_cases:
            _dependency_fault(modules, context, shared, donors, endpoint, role, target, error, c, obs)
        controls.append(_row(CONTROL_IDS[7], obs,
            ['First public callback and seven throw-only public dependency paths are intentionally faulted; no private late ordinal or all-cutoff cleanup test.',
             'Negative-only delegate namespaces never return fake VALID data and do not modify authentic namespaces. Internal private helper/native allocation fault sites remain Source obligations.',
             'UNEXERCISED: future consumer fallback/nonpruning, full scheduler/mark/refcount/generation rollback, learned hypotheses and reward/overlap accounting remain the original obligations.'], c))

        c.need([r['id'] for r in controls] == list(CONTROL_IDS), 'exact ordered eight groups')
        actual_counts = [0] * 8
        for entry in c.calls:
            c.tick()
            actual_counts[CONTROL_IDS.index(entry['group'])] += 1
        c.need(actual_counts == list(PUBLIC_CALL_COUNTS) and len(c.calls) == 69,
               'exact finite public call locator census')
        for namespace, field, original in namespace_snapshot:
            c.tick()
            c.need(getattr(namespace, field) is original, 'authentic namespace projection mutated')
        result = {'schema': RETURN_SCHEMA, 'version': VERSION, 'population': POPULATION,
                  'complete': True, 'control_ids': list(CONTROL_IDS), 'controls': controls,
                  'counts': {'groups': 8, 'passed': 8, 'failed': 0}, 'scope': SCOPE,
                  'coverage_limits': list(LIMITS)}
        result['controls'][-1]['observations'].append({'complete_public_call_census': _copy(c.calls, c)})
        result = _copy(result, c, True)
        c.tick()
        return result
    except BaseException:
        c.raise_first()
        raise
