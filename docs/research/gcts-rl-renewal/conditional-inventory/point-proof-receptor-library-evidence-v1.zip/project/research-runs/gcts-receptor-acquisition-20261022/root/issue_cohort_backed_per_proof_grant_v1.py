"""Metadata-only issuance of one new cold donor case after fresh Root idle observation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
PREFIX = 'cohort-backed-per-proof-'
EXPERIMENT = 'signed-propositional-cohort-proof-benchmark-v1'


def read(path):
    return json.loads(Path(path).read_bytes())


def pin(path):
    path = Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def verify(ref):
    assert pin(ref['path']) == ref


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode())
    return pin(path)


assert len(sys.argv) == 2 and sys.argv[1] in ('0', '1')
index = int(sys.argv[1])
case_id = EXPERIMENT + '-donor-' + str(index)
prep_path = ROOT / (PREFIX + 'study-preparation-v1.json')
accept_path = ROOT / (PREFIX + 'Root-whole-prospective-acceptance-v1.json')
prep, accept = read(prep_path), read(accept_path)
assert accept['accepted_prospective_metadata'] is True and accept['preparation'] == pin(prep_path)
for key in ('preparation', 'whole_review', 'component_acceptance'):
    verify(accept[key])
assert read(accept['whole_review']['path'])['review_passed'] is True
components = read(accept['component_acceptance']['path'])
assert components['accepted_component_Source'] is True
for ref in components['component_reviews'].values():
    verify(ref)
    assert read(ref['path'])['review_passed'] is True
for key in ('protocol', 'closure', 'applicability'):
    verify(prep[key])
assert len(prep['plans']) == len(prep['proposals']) == len(prep['recipes']) == 2
for ref in prep['plans'] + prep['proposals']:
    verify(ref)
plan_ref, proposal_ref = prep['plans'][index], prep['proposals'][index]
plan, proposal = read(plan_ref['path']), read(proposal_ref['path'])
protocol, closure, app = [read(prep[key]['path']) for key in ('protocol', 'closure', 'applicability')]
recipes = [dict(case_id=EXPERIMENT + '-donor-' + str(i), stage='acquire',
                donor_index=i, input_slot='donor' + str(i)) for i in range(2)]
assert protocol['job_recipes'] == prep['recipes'] == recipes
assert all(plan[key] == value and proposal[key] == value for key, value in recipes[index].items())
assert plan['experiment'] == EXPERIMENT and plan['required_upstream_ids'] == []
assert proposal['authorized'] is False and proposal['review_passed'] is False
assert type(proposal['uses']) is int and proposal['uses'] == 1
assert proposal['plan'] == plan_ref and proposal['closure'] == prep['closure']
assert closure['plans'] == prep['plans']
assert plan['protocol'] == closure['protocol'] == proposal['protocol'] == prep['protocol']
assert plan['cohort_applicability'] == closure['applicability'] == proposal['applicability'] == prep['applicability']
for key, ref in protocol['metadata'].items():
    assert plan[key] == ref
assert plan['files'] == closure['files'] and len(plan['files']) == prep['shared_guards']
assert plan['module_pins'] == protocol['module_pins'] and len(plan['module_pins']) == 38
assert plan['control_populations'] == protocol['control_populations'] and len(plan['control_populations']) == 17
assert sum(row['groups'] for row in plan['control_populations'].values()) == 229
assert plan['limits'] == protocol['limits'] == app['limits'] and len(plan['limits']) == 10
assert app['accepted'] is False and app['qualification_rerun'] is False
assert app['cohort_id'] == 'signed-propositional-original-bank-cohort-v1'
assert app['descriptor'] == plan['cohort_descriptor']
assert app['Root_disposition'] == plan['cohort_disposition']
assert app['C_review'] == plan['cohort_C_review'] and app['input_authority'] == plan['input_authority']
descriptor = read(plan['cohort_descriptor']['path'])
assert all(ref in plan['files'] for ref in descriptor['source_closure'])
assert descriptor['covered_runtime_roles'] == app['covered_runtime_roles']
assert descriptor['control_populations'] == app['control_populations']
assert descriptor['raw_inputs'] == app['raw_inputs']
assert proposal['component_acceptance'] == accept['component_acceptance']
assert proposal['component_reviews'] == components['component_reviews']
for ref in plan['files']:
    verify(ref)
upstream = None
if index == 1:
    # This parent-side admission index is never put in donor1's scientific plan.
    donor_path = ROOT / (PREFIX + 'donor-0-Root-complete-whole-admission-v1.json')
    donor = read(donor_path)
    assert donor['schema'] == 'Root-FPC-cohort-backed-donor-admission-v1'
    assert donor['case_id'] == recipes[0]['case_id'] and donor['plan'] == prep['plans'][0]
    assert donor['proof_admitted'] is True and donor['resources_and_custody_accepted'] is True
    assert donor['fresh_whole_original_byte_dual_gate'] is True
    assert donor['cohort_applicability'] == prep['applicability']
    assert donor['input_authority'] == plan['input_authority']
    for key in ('C_actual_review', 'query', 'certificate'):
        verify(donor[key])
    assert read(donor['C_actual_review']['path'])['review_passed'] is True
    upstream = pin(donor_path)
absent = [Path(plan['actual_dir']), Path(plan['actual_dir'] + '.observer'),
          Path(proposal['prospective_grant_path'])]
assert all(not path.exists() and not path.is_symlink() for path in absent)
now = datetime.now(timezone.utc).isoformat()
case = emit(ROOT / (PREFIX + 'donor-' + str(index) + '-Root-case-prospective-acceptance-v1.json'), dict(
    schema='Root-cohort-backed-per-proof-case-prospective-acceptance-v1', issued_utc=now,
    accepted=True, case_id=case_id, donor_index=index, plan=plan_ref,
    closure=prep['closure'], proposal=proposal_ref, applicability=prep['applicability'],
    Root_whole_acceptance=pin(accept_path), whole_review=accept['whole_review'],
    metadata_issuer=pin(Path(__file__)), guards_current=len(plan['files']),
    upstream_admission_parent_only=upstream,
    absent_paths=[str(path) for path in absent], scientific_calls=0))
barrier = emit(ROOT / (PREFIX + 'donor-' + str(index) + '-all-tools-idle-barrier-v1.json'), dict(
    schema='Root-cohort-backed-per-proof-tools-idle-barrier-v1', issued_utc=now,
    case_id=case_id, acceptance=case,
    observation='Root freshly observes B/L/C complete/tools idle and every own command session terminal '
        'before issuer invocation. During this measured actual only the owned observer exec is polled.',
    scope='Current task tools, not exclusive OS ownership; Source cannot observe peer tool state. '
        'Root supplies the actual fresh observation, no security-sandbox or real-time guarantee.',
    guards_rehashed=len(plan['files']), fresh_absence_checks=3))
grant = {key: proposal[key] for key in ('uses', 'case_id', 'donor_index', 'input_slot',
    'plan_sha256', 'runner_sha256', 'observer_sha256', 'plan', 'protocol', 'closure',
    'applicability', 'component_acceptance', 'component_reviews')}
grant.update(schema='Root-cohort-backed-per-proof-once-grant-v1', authorized=True,
    review_passed=True, issued_utc=now, whole_review=accept['whole_review'],
    case_proposal=proposal_ref, Root_prospective_acceptance=case,
    all_tools_idle_barrier=barrier, upstream_admission_parent_only=upstream,
    scope='One exact fresh cold ordinary signed-propositional donor candidate case. '
        'No replay/replacement/old proof uptake or extraction/holdout. Complete original-byte '
        'paired validators, resources, outputs and independent Root/C whole admission required; '
        'donor1 may run only after the exact new donor0 admission, never via scientific input uptake.')
grant_pin = emit(Path(proposal['prospective_grant_path']), grant)
print(json.dumps(dict(grant=grant_pin, acceptance=case, barrier=barrier,
                      command=proposal['prospective_command'])))
