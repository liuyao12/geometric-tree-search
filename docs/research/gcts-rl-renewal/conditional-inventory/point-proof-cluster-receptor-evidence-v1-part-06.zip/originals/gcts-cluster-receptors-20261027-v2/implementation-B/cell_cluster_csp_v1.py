"""Independent finite unit-anchor CSP.  Inert until a reviewed once invocation.

No point-engine, compiler, learner or checker imports/calls.  Literal maps are
exported as exact seed unaries and sparse cell-pair allowed-row bitmasks.
The controller is forward checking, not arc consistency.  There is no IO/CLI.
"""

import copy
import hashlib
import math
import json


VERSION = "FINITE-UNIT-CELL-CLUSTER-CSP-v1"
MODEL_SCHEMA = "GCTS-finite-point-instance-v1"
SPEC_SCHEMA = "GCTS-unit-cell-csp-spec-v1"
STATE_SCHEMA = "GCTS-unit-cell-normalized-state-v1"
RESULT_SCHEMA = "GCTS-unit-cell-csp-solve-result-v1"
CERTIFICATE_SCHEMA = "GCTS-unit-cell-csp-certificate-v1"
_POLICY = (("empty", "GLOBAL_LEX_POINT"), ("forced", "GLOBAL_LEX_POINT"),
           ("branch", "MIN_GENERATION_DOMAIN_POINT"), ("value", "LEX_ID"),
           ("generation", "ALL_REQUIRED_ROOT_0"))
_MODEL = "CSP_MODEL_INVALID"
_PROFILE = "CSP_PROFILE_UNSUPPORTED"
_SPEC = "CSP_SPEC_INVALID"
_OP = "CSP_OPERATION_INVALID"
_LIMIT = "CSP_NODE_LIMIT_INVALID"
_CALLBACK = "CSP_CALLBACK_INVALID"


CLUSTER_VALUE_POLICY = "VALIDATED_CLUSTER_PREFERENCE_THEN_COMPLETE_LEX"
CLUSTER_OBSERVATION_SCHEMA = "GCTS-cluster-receptor-observation-v1"
CLUSTER_PACKET_SCHEMA = "GCTS-concrete-cluster-proposals-v1"
CLUSTER_RECEIPT_SCHEMA = "GCTS-cluster-proposal-receipt-v1"


class _ClusterJSONError(ValueError):
    """Private structural-copy refusal, never a search exclusion."""


def _cluster_hash(value):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(",", ":"), allow_nan=False) + "\n").encode()
    return hashlib.sha256(body).hexdigest()


def _cluster_json_copy(value):
    """Copy plain JSON only; never invoke producer-defined copying methods."""
    active = set()
    def visit(item, depth):
        if depth > 64:
            raise _ClusterJSONError()
        kind = type(item)
        if item is None or kind in (bool, int, str):
            return item
        if kind is float:
            if not math.isfinite(item):
                raise _ClusterJSONError()
            return item
        if kind not in (list, dict) or id(item) in active:
            raise _ClusterJSONError()
        active.add(id(item))
        try:
            if kind is list:
                return [visit(v, depth + 1) for v in item]
            if any(type(k) is not str for k in item):
                raise _ClusterJSONError()
            return {k: visit(v, depth + 1) for k, v in item.items()}
        finally:
            active.remove(id(item))
    return visit(value, 0)


def _cluster_bitset(ids, active, order_sha):
    bits = bytearray((len(ids) + 7) // 8)
    for i, pid in enumerate(ids):
        if pid in active:
            bits[i // 8] |= 1 << (i % 8)
    return {"encoding": "LSB0_HEX", "id_order_sha256": order_sha,
            "universe_size": len(ids), "hex": bytes(bits).hex()}


class CSPError(ValueError):
    """Owned data/operation refusal; message is one fixed public code."""


class CSPBudgetExceeded(RuntimeError):
    """Cooperative interruption, never an UNSAT certificate."""


def _require(ok, code):
    if not ok:
        raise CSPError(code)


def _record(value, fields, code):
    _require(type(value) is dict and set(value) == set(fields), code)


def _point(value, code):
    _require(type(value) is list and len(value) == 2
             and all(type(v) is int for v in value), code)
    return tuple(value)


def _literal(value, code):
    _require(type(value) is str, code)
    return value


def _exact_equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return (set(left) == set(right)
                and all(_exact_equal(left[k], right[k]) for k in right))
    if type(left) is list:
        return (len(left) == len(right)
                and all(_exact_equal(a, b) for a, b in zip(left, right)))
    return left == right


def _canonical_bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def _digest(value):
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _model(model):
    """Independent complete raw-schema validation, before unit restriction."""
    _record(model, ("schema", "capacity", "required", "placements", "seeds"), _MODEL)
    _require(type(model["schema"]) is str and model["schema"] == MODEL_SCHEMA, _MODEL)
    cap = model["capacity"]
    _require(type(cap) is int and cap > 0, _MODEL)
    _require(type(model["required"]) is list, _MODEL)
    required = set()
    for row in model["required"]:
        point = _point(row, _MODEL)
        _require(point not in required, _MODEL)
        required.add(point)
    _require(type(model["placements"]) is list, _MODEL)
    placements = {}
    for row in model["placements"]:
        _record(row, ("id", "type", "translation", "t", "m"), _MODEL)
        pid = _literal(row["id"], _MODEL)
        _literal(row["type"], _MODEL)
        _require(pid not in placements, _MODEL)
        translation = _point(row["translation"], _MODEL)
        _require(type(row["t"]) is list and row["t"], _MODEL)
        positive = {}
        for term in row["t"]:
            _require(type(term) is list and len(term) == 3, _MODEL)
            point = _point(term[:2], _MODEL)
            units = term[2]
            _require(type(units) is int and 0 < units <= cap and point not in positive, _MODEL)
            positive[point] = units
        _require(type(row["m"]) is list, _MODEL)
        marking = {}
        for term in row["m"]:
            _require(type(term) is list and len(term) == 4, _MODEL)
            point = _point(term[:2], _MODEL)
            channel = _literal(term[2], _MODEL)
            value = _literal(term[3], _MODEL)
            slot = point + (channel,)
            _require(slot not in marking, _MODEL)
            marking[slot] = value
        placements[pid] = {
            "id": pid, "type": row["type"], "translation": list(translation),
            "t": [[p[0], p[1], positive[p]] for p in sorted(positive)],
            "m": [[s[0], s[1], s[2], marking[s]] for s in sorted(marking)],
        }
    _require(type(model["seeds"]) is list, _MODEL)
    seeds, seen = [], set()
    for pid in model["seeds"]:
        _literal(pid, _MODEL)
        _require(pid in placements and pid not in seen, _MODEL)
        seeds.append(pid)
        seen.add(pid)
    for pid, row in placements.items():
        _require(pid in seen or any(tuple(t[:2]) in required for t in row["t"]), _MODEL)
    totals, marking = {}, {}
    for pid in seeds:
        for x, y, units in placements[pid]["t"]:
            point = (x, y)
            totals[point] = totals.get(point, 0) + units
            _require(totals[point] <= cap, _MODEL)
        for x, y, channel, value in placements[pid]["m"]:
            slot = (x, y, channel)
            _require(slot not in marking or marking[slot] == value, _MODEL)
            marking[slot] = value
    return {
        "schema": MODEL_SCHEMA, "capacity": cap,
        "required": [list(p) for p in sorted(required)],
        "placements": [placements[pid] for pid in sorted(placements)], "seeds": seeds,
    }


def _build_spec(model, value_policy="LEX_ID"):
    """Build from a privately normalized model; never call public entries."""
    _require(type(value_policy) is str and value_policy in ("LEX_ID", CLUSTER_VALUE_POLICY), _SPEC)
    _require(model["capacity"] == 1
             and all(len(row["t"]) == 1 and row["t"][0][2] == 1
                     for row in model["placements"]), _PROFILE)
    placements = {row["id"]: row for row in model["placements"]}
    anchors = {pid: tuple(row["t"][0][:2]) for pid, row in placements.items()}
    seeds = set(model["seeds"])
    occupied = {anchors[pid] for pid in seeds}
    points = sorted(set(tuple(p) for p in model["required"]) - occupied)
    domains = {point: [] for point in points}
    preprocessed = []
    for pid in sorted(placements):
        point = anchors[pid]
        if pid in seeds:
            preprocessed.append({"id": pid, "anchor": list(point), "reason": "SEED_SELECTED"})
        elif point in occupied:
            preprocessed.append({"id": pid, "anchor": list(point), "reason": "SEED_ANCHOR_OCCUPIED"})
        else:
            domains[point].append(pid)
    maps = {pid: {tuple(r[:3]): r[3] for r in row["m"]}
            for pid, row in placements.items()}
    unaries = []
    for pid in sorted(pid for domain in domains.values() for pid in domain):
        conflicts = []
        for seed in sorted(seeds):
            slots = sorted(s for s, value in maps[pid].items()
                           if s in maps[seed] and maps[seed][s] != value)
            if slots:
                conflicts.append({"seed": seed, "slots": [list(s) for s in slots]})
        unaries.append({"id": pid, "allowed": not conflicts, "seed_conflicts": conflicts})
    # A slot index preserves absence as unconstrained and discovers all distant
    # contacts. Only non-universal cell pairs acquire a rowmask table.
    slots = {}
    for point in points:
        for index, pid in enumerate(domains[point]):
            bit = 1 << index
            for slot, value in maps[pid].items():
                groups = slots.setdefault(slot, {}).setdefault(point, {})
                groups[value] = groups.get(value, 0) | bit
    tables = {}
    for slot in sorted(slots):
        groups = slots[slot]
        incident = sorted(groups)
        for i, left in enumerate(incident):
            for right in incident[i + 1:]:
                for value, left_bits in groups[left].items():
                    bad = 0
                    for other_value, right_bits in groups[right].items():
                        if value != other_value:
                            bad |= right_bits
                    if not bad:
                        continue
                    key = (left, right)
                    if key not in tables:
                        tables[key] = [(1 << len(domains[right])) - 1] * len(domains[left])
                    bits = left_bits
                    while bits:
                        low = bits & -bits
                        tables[key][low.bit_length() - 1] &= ~bad
                        bits -= low
    binary = []
    for (left, right), masks in sorted(tables.items()):
        full = (1 << len(domains[right])) - 1
        if any(mask != full for mask in masks):
            binary.append({"left": list(left), "right": list(right), "allowed_rows": masks})
    return {
        "schema": SPEC_SCHEMA, "model": model,
        "variables": [{"point": list(p), "generation": 0, "domain": domains[p]} for p in points],
        "unaries": unaries, "binary": binary, "preprocessed": preprocessed,
        "policy": dict(_POLICY, value=value_policy),
    }


def export_unit_cell_csp(model, *, value_policy="LEX_ID"):
    """Pure detached export of the complete explicit unit-anchor universe."""
    return _build_spec(_model(model), value_policy)


def _checked_spec(spec):
    _record(spec, ("schema", "model", "variables", "unaries", "binary", "preprocessed", "policy"), _SPEC)
    _record(spec["policy"], dict(_POLICY), _SPEC)
    try:
        expected = _build_spec(_model(spec["model"]), spec["policy"]["value"])
    except CSPError:
        raise CSPError(_SPEC) from None
    _require(_exact_equal(spec, expected), _SPEC)
    return expected


class CellCSP:
    """Reference forward checking with delta-trail restoration and proof tree."""

    def __init__(self, csp_spec, audit=None, budget=None, *, proposer=None,
                 proposal_audit=None, inventory_version="BASE", marking_version="MODEL"):
        _require(audit is None or callable(audit), _CALLBACK)
        _require(budget is None or callable(budget), _CALLBACK)
        _require(proposer is None or callable(proposer), _CALLBACK)
        self._spec = _checked_spec(csp_spec)
        _require(self._spec["policy"]["value"] ==
                 ("LEX_ID" if proposer is None else CLUSTER_VALUE_POLICY), _SPEC)
        self._model = self._spec["model"]
        self._model_sha = _digest(self._model)
        self._spec_sha = _digest(self._spec)
        self._audit, self._budget = audit, budget
        self._in_callback = False
        self._solving = False
        self._cluster_setup(proposer, proposal_audit, inventory_version, marking_version)
        self._placements = {p["id"]: p for p in self._model["placements"]}
        self._anchors = {pid: tuple(row["t"][0][:2]) for pid, row in self._placements.items()}
        self._points = tuple(tuple(v["point"]) for v in self._spec["variables"])
        self._domains = {tuple(v["point"]): tuple(v["domain"]) for v in self._spec["variables"]}
        self._rank = {p: {pid: i for i, pid in enumerate(ids)} for p, ids in self._domains.items()}
        self._owners = {pid: p for p, ids in self._domains.items() for pid in ids}
        self._relations = {(tuple(r["left"]), tuple(r["right"])): tuple(r["allowed_rows"])
                           for r in self._spec["binary"]}
        self._neighbors = {p: set() for p in self._points}
        for left, right in self._relations:
            self._neighbors[left].add(right)
            self._neighbors[right].add(left)
        self._neighbors = {p: tuple(sorted(q)) for p, q in self._neighbors.items()}
        allowed = {r["id"] for r in self._spec["unaries"] if r["allowed"]}
        self._physical = {p: frozenset(pid for pid in ids if pid in allowed)
                          for p, ids in self._domains.items()}
        self._eligible = dict(self._physical)
        self._selected = list(self._model["seeds"])
        self._selected_ids = {pid: True for pid in self._selected}
        self._assigned = {}
        self._excluded = {}
        self._trail = []
        self._boundaries = {0}
        nseed = len(self._selected)
        self._counts = {
            "attempts": nseed, "accepted_base_placements": nseed,
            "seed_placements": nseed, "forced_placements": 0,
            "branch_decisions": 0, "backtracks": 0,
            "candidate_removals": {r: 0 for r in
                                   ("SELECTED", "EXCLUDED", "CAPACITY", "MARKING", "NO_FRONTIER")},
            "max_frontier_points": 0, "max_active_candidates": 0, "max_edges": 0,
        }
        self._measure(frozenset())
        self._guard()
        self._emit("INITIALIZED", {})


    def _cluster_setup(self, proposer, proposal_audit, inventory_version, marking_version):
        if ((proposer is not None and not callable(proposer))
                or (proposal_audit is not None and not callable(proposal_audit))
                or (proposer is None and proposal_audit is not None)
                or type(inventory_version) is not str or not inventory_version
                or type(marking_version) is not str or not marking_version):
            raise self._cluster_error("invalid cluster callback/version configuration")
        self._proposer, self._proposal_audit = proposer, proposal_audit
        self._inventory_version, self._marking_version = inventory_version, marking_version
        self._cluster_model_sha = _cluster_hash(self._model)
        self._cluster_ids = tuple(row["id"] for row in self._model["placements"])
        self._cluster_order_sha = _cluster_hash(list(self._cluster_ids))
        self._proposal_records = []
        self._proposal_counts = {key: 0 for key in (
            "branch_observations", "proposer_calls", "packets_rejected",
            "clusters_proposed", "clusters_accepted", "clusters_rejected",
            "joint_members_checked", "joint_t_terms_checked", "joint_m_terms_checked",
            "branch_order_changes", "proposal_audit_calls")}

    @property
    def value_policy(self):
        return "LEX_ID" if self._proposer is None else CLUSTER_VALUE_POLICY

    @property
    def proposal_evidence(self):
        return copy.deepcopy(self._proposal_records)

    @property
    def proposal_metrics(self):
        return dict(self._proposal_counts)

    def _cluster_observation(self, choice):
        point = tuple(choice["point"])
        return {"schema": CLUSTER_OBSERVATION_SCHEMA,
                "model_sha256": self._cluster_model_sha,
                "inventory_version": self._inventory_version,
                "marking_version": self._marking_version,
                "value_policy": self.value_policy,
                "selected": list(self._selected), "excluded": sorted(self._excluded),
                "point": list(point), "generation": self._cluster_generation(point),
                "incident_domain": self._cluster_incident(point),
                "active_bitset": _cluster_bitset(self._cluster_ids, self._cluster_active(),
                                                 self._cluster_order_sha)}

    def _cluster_check(self, raw_cluster, index, seen, incident, active):
        self._guard()
        row = {"index": index, "raw_cluster": raw_cluster, "id": None,
               "shared_ids": [], "new_ids": [], "incident_ids": [],
               "accepted": False, "rejection": None}
        def reject(code):
            row["rejection"] = code
            return row
        if (type(raw_cluster) is not dict or set(raw_cluster) !=
                {"id", "inventory_version", "marking_version", "members"}):
            return reject("CLUSTER_SHAPE")
        cid = raw_cluster["id"]
        if type(cid) is not str or not cid or cid in seen:
            return reject("CLUSTER_ID")
        seen.add(cid)
        row["id"] = cid
        if (type(raw_cluster["inventory_version"]) is not str
                or type(raw_cluster["marking_version"]) is not str
                or raw_cluster["inventory_version"] != self._inventory_version
                or raw_cluster["marking_version"] != self._marking_version):
            return reject("CLUSTER_VERSION")
        members = raw_cluster["members"]
        if (type(members) is not list or not 1 <= len(members) <= 256
                or any(type(pid) is not str for pid in members)
                or len(set(members)) != len(members)):
            return reject("CLUSTER_MEMBERS")
        if any(pid not in self._placements for pid in members):
            return reject("UNKNOWN_MEMBER")
        row["shared_ids"] = [pid for pid in members if pid in self._selected_ids]
        row["new_ids"] = [pid for pid in members if pid not in self._selected_ids]
        row["incident_ids"] = [pid for pid in row["new_ids"] if pid in incident]
        if any(pid in self._excluded for pid in members):
            return reject("EXCLUDED_MEMBER")
        if any(pid not in active for pid in row["new_ids"]):
            return reject("INACTIVE_MEMBER")
        union = list(self._selected) + row["new_ids"]
        totals = {}
        for pid in union:
            self._guard()
            self._proposal_counts["joint_members_checked"] += 1
            for x, y, units in self._placements[pid]["t"]:
                self._proposal_counts["joint_t_terms_checked"] += 1
                if self._proposal_counts["joint_t_terms_checked"] % 64 == 0:
                    self._guard()
                p = (x, y)
                totals[p] = totals.get(p, 0) + units
                if totals[p] > self._model["capacity"]:
                    return reject("CAPACITY_CONFLICT")
        marks = {}
        for pid in union:
            self._guard()
            for x, y, channel, value in self._placements[pid]["m"]:
                self._proposal_counts["joint_m_terms_checked"] += 1
                if self._proposal_counts["joint_m_terms_checked"] % 64 == 0:
                    self._guard()
                slot = (x, y, channel)
                if slot in marks and marks[slot] != value:
                    return reject("MARKING_CONFLICT")
                marks[slot] = value
        if not row["incident_ids"]:
            return reject("NO_INCIDENT_MEMBER")
        row["accepted"] = True
        return row

    def _cluster_packet_order(self, packet, receipt, observation_sha, lexical):
        if packet is None:
            return lexical
        rejection = None
        if (type(packet) is not dict or set(packet) !=
                {"schema", "observation_sha256", "clusters"}
                or type(packet["schema"]) is not str
                or packet["schema"] != CLUSTER_PACKET_SCHEMA
                or type(packet["observation_sha256"]) is not str
                or type(packet["clusters"]) is not list):
            rejection = "PACKET_SHAPE"
        elif packet["observation_sha256"] != observation_sha:
            rejection = "PACKET_BINDING"
        elif len(packet["clusters"]) > 64:
            rejection = "PACKET_SIZE"
        if rejection:
            receipt["packet_rejection"] = rejection
            self._proposal_counts["packets_rejected"] += 1
            return lexical
        ordered, ranked, seen = [], set(), set()
        incident, active = set(lexical), self._cluster_active()
        for index, cluster in enumerate(packet["clusters"]):
            self._proposal_counts["clusters_proposed"] += 1
            row = self._cluster_check(cluster, index, seen, incident, active)
            receipt["clusters"].append(row)
            key = "clusters_accepted" if row["accepted"] else "clusters_rejected"
            self._proposal_counts[key] += 1
            if row["accepted"]:
                for pid in row["incident_ids"]:
                    if pid not in ranked:
                        ordered.append(pid)
                        ranked.add(pid)
        ordered.extend(pid for pid in lexical if pid not in ranked)
        return ordered

    def _cluster_order(self, choice):
        if self._proposer is None or choice["kind"] != "BRANCH":
            return choice
        self._guard()
        observation = self._cluster_observation(choice)
        before = _cluster_hash(observation)
        lexical = list(choice["candidates"])
        receipt = {"schema": CLUSTER_RECEIPT_SCHEMA,
                   "index": len(self._proposal_records), "status": "PENDING",
                   "observation": observation, "observation_sha256": before,
                   "raw_packet": None, "packet_rejection": None, "clusters": [],
                   "ordered_candidates": lexical,
                   "logical_before_sha256": before, "logical_after_sha256": None,
                   "value_policy": self.value_policy,
                   "counters": self.proposal_metrics, "error_type": None}
        self._proposal_records.append(receipt)
        self._proposal_counts["branch_observations"] += 1
        try:
            self._proposal_counts["proposer_calls"] += 1
            receipt["counters"] = self.proposal_metrics
            self._in_callback = True
            try:
                raw_packet = self._proposer(copy.deepcopy(observation))
            finally:
                self._in_callback = False
        except BaseException as error:
            receipt["status"] = "PROPOSER_EXCEPTION"
            receipt["error_type"] = type(error).__name__
            receipt["logical_after_sha256"] = _cluster_hash(self._cluster_observation(choice))
            receipt["counters"] = self.proposal_metrics
            raise
        try:
            try:
                packet = _cluster_json_copy(raw_packet)
            except _ClusterJSONError:
                receipt["packet_rejection"] = "NON_JSON_PACKET"
                self._proposal_counts["packets_rejected"] += 1
                ordered = lexical
            else:
                receipt["raw_packet"] = packet
                ordered = self._cluster_packet_order(packet, receipt, before, lexical)
            self._guard()
            after = _cluster_hash(self._cluster_observation(choice))
            if after != before:
                raise self._cluster_error("cluster callback changed logical state", operation=True)
            if ordered != lexical:
                self._proposal_counts["branch_order_changes"] += 1
            receipt["ordered_candidates"] = list(ordered)
            receipt["logical_after_sha256"] = after
            receipt["status"] = "VALIDATED"
            receipt["counters"] = self.proposal_metrics
            if self._proposal_audit is not None:
                self._proposal_counts["proposal_audit_calls"] += 1
                self._in_callback = True
                try:
                    self._proposal_audit(copy.deepcopy(receipt))
                finally:
                    self._in_callback = False
            return dict(choice, candidates=ordered)
        except BaseException as error:
            receipt["status"] = "INTERRUPTED"
            receipt["error_type"] = type(error).__name__
            receipt["logical_after_sha256"] = _cluster_hash(self._cluster_observation(choice))
            receipt["counters"] = self.proposal_metrics
            raise


    def _cluster_error(self, message, operation=False):
        return CSPError(_OP if operation else _CALLBACK)

    def _cluster_active(self):
        return self._active()

    def _cluster_incident(self, point):
        return sorted(self._eligible.get(point, ()))

    def _cluster_generation(self, point):
        return 0

    @property
    def spec(self):
        return copy.deepcopy(self._spec)

    @property
    def metrics(self):
        result = copy.deepcopy(self._counts)
        active = self._active()
        result.update({"final_frontier_points": len(self._eligible),
                       "final_active_candidates": len(active), "final_edges": len(active)})
        return result

    def _active(self):
        return frozenset(pid for ids in self._eligible.values() for pid in ids)

    def snapshot(self):
        active = sorted(self._active())
        return {
            "schema": STATE_SCHEMA, "selected": list(self._selected),
            "assigned": [{"point": list(p), "id": self._assigned[p]} for p in sorted(self._assigned)],
            "excluded": [{"id": pid, "reason": self._excluded[pid]} for pid in sorted(self._excluded)],
            "physical_domains": [{"point": list(p), "candidates": sorted(self._physical[p])}
                                 for p in sorted(self._physical)],
            "eligible_domains": [{"point": list(p), "generation": 0,
                                  "candidates": sorted(self._eligible[p])} for p in sorted(self._eligible)],
            "active_candidates": active,
            "forward_incidence": [[p[0], p[1], pid, 1] for p in sorted(self._eligible)
                                  for pid in sorted(self._eligible[p])],
            "reverse_incidence": [{"id": pid, "points": [[self._owners[pid][0],
                                                          self._owners[pid][1], 1]]} for pid in active],
        }

    def checkpoint(self):
        return len(self._trail)

    def _entry(self):
        _require(not self._in_callback and not self._solving, _OP)

    def _guard(self):
        if self._budget is None:
            return
        self._in_callback = True
        try:
            result = self._budget()
        finally:
            self._in_callback = False
        if result is False:
            raise CSPBudgetExceeded("CSP_BUDGET_REFUSED")
        _require(result is None or result is True, _CALLBACK)

    def _emit(self, kind, data):
        if self._audit is None:
            return
        self._in_callback = True
        try:
            self._audit(self, {"kind": kind, "data": copy.deepcopy(data)})
        finally:
            self._in_callback = False

    def _set(self, name, key, value):
        table = getattr(self, name)
        existed = key in table
        old = table.get(key)
        if existed and old == value:
            return
        table[key] = value
        self._trail.append(("map", name, key, existed, old, True, value))

    def _delete(self, name, key):
        table = getattr(self, name)
        if key in table:
            old = table.pop(key)
            self._trail.append(("map", name, key, True, old, False, None))

    def _append_selected(self, pid):
        self._selected.append(pid)
        self._trail.append(("append", "_selected", None, False, None, True, pid))

    def _undo(self, checkpoint):
        while len(self._trail) > checkpoint:
            kind, name, key, existed, old, unused_exists, unused_new = self._trail.pop()
            table = getattr(self, name)
            if kind == "append":
                table.pop()
            elif existed:
                table[key] = old
            else:
                del table[key]
        self._boundaries = {c for c in self._boundaries if c <= checkpoint}

    def _redo(self, deltas):
        for delta in deltas:
            kind, name, key, unused_exists, unused_old, exists, value = delta
            table = getattr(self, name)
            if kind == "append":
                table.append(value)
            elif exists:
                table[key] = value
            else:
                del table[key]
            self._trail.append(delta)

    def _measure(self, old_active):
        active = self._active()
        for pid in old_active - active:
            if pid in self._selected_ids:
                reason = "SELECTED"
            elif pid in self._excluded:
                reason = "EXCLUDED"
            elif self._anchors[pid] in self._assigned:
                reason = "CAPACITY"
            elif pid not in self._physical.get(self._owners[pid], frozenset()):
                reason = "MARKING"
            else:
                reason = "NO_FRONTIER"
            self._counts["candidate_removals"][reason] += 1
        for key, value in (("max_frontier_points", len(self._eligible)),
                           ("max_active_candidates", len(active)), ("max_edges", len(active))):
            self._counts[key] = max(self._counts[key], value)

    def _check_id_reason(self, pid, reason):
        _literal(pid, _OP)
        _literal(reason, _OP)
        _require(pid in self._placements, _OP)

    def _allowed_with(self, point, pid, other):
        if point < other:
            rows = self._relations[(point, other)]
            mask = rows[self._rank[point][pid]]
            return frozenset(other_id for index, other_id in enumerate(self._domains[other])
                             if mask & (1 << index))
        rows = self._relations[(other, point)]
        bit = 1 << self._rank[point][pid]
        return frozenset(other_id for index, other_id in enumerate(self._domains[other])
                         if rows[index] & bit)

    def _place(self, pid, reason, forced=False):
        self._check_id_reason(pid, reason)
        self._counts["attempts"] += 1
        self._guard()
        point = self._owners.get(pid)
        _require(pid not in self._selected_ids and pid not in self._excluded
                 and point in self._physical and pid in self._physical[point], _OP)
        cp = len(self._trail)
        active = self._active()
        try:
            self._set("_selected_ids", pid, True)
            self._append_selected(pid)
            self._set("_assigned", point, pid)
            self._delete("_physical", point)
            self._delete("_eligible", point)
            for other in self._neighbors[point]:
                if other not in self._physical:
                    continue
                allowed = self._physical[other] & self._allowed_with(point, pid, other)
                self._set("_physical", other, allowed)
                self._set("_eligible", other, frozenset(p for p in allowed if p not in self._excluded))
            self._boundaries.add(len(self._trail))
            self._counts["accepted_base_placements"] += 1
            if forced:
                self._counts["forced_placements"] += 1
            self._measure(active)
            self._emit("PLACED", {"id": pid, "reason": reason, "generation": 1})
        except BaseException:
            self._undo(cp)
            raise

    def place(self, placement_id, reason):
        self._entry()
        self._place(placement_id, reason)

    def _exclude(self, pid, reason):
        self._check_id_reason(pid, reason)
        self._guard()
        _require(pid not in self._selected_ids and pid not in self._excluded, _OP)
        cp = len(self._trail)
        active = self._active()
        try:
            self._set("_excluded", pid, reason)
            point = self._owners.get(pid)
            if point in self._eligible:
                self._set("_eligible", point, self._eligible[point] - {pid})
            self._boundaries.add(len(self._trail))
            self._measure(active)
            self._emit("EXCLUDED", {"id": pid, "reason": reason})
        except BaseException:
            self._undo(cp)
            raise

    def exclude(self, placement_id, reason):
        self._entry()
        self._exclude(placement_id, reason)

    def rollback(self, checkpoint):
        self._entry()
        _require(type(checkpoint) is int and checkpoint in self._boundaries, _OP)
        self._guard()
        deltas = self._trail[checkpoint:]
        boundaries = set(self._boundaries)
        self._undo(checkpoint)
        try:
            self._emit("ROLLED_BACK", {"restored_state_sha256": _digest(self.snapshot())})
        except BaseException:
            self._redo(deltas)
            self._boundaries = boundaries
            raise

    def _decision(self):
        self._guard()
        points = sorted(self._eligible)
        if not points:
            choice = {"kind": "SOLUTION", "point": None, "candidates": []}
        else:
            empty = [p for p in points if not self._eligible[p]]
            forced = [p for p in points if len(self._eligible[p]) == 1]
            if empty:
                point, kind = empty[0], "DEAD"
            elif forced:
                point, kind = forced[0], "FORCED"
            else:
                point = min(points, key=lambda p: (0, len(self._eligible[p]), p))
                kind = "BRANCH"
            choice = {"kind": kind, "point": list(point), "candidates": sorted(self._eligible[point])}
        choice = self._cluster_order(choice)
        self._emit("DECISION", choice)
        return choice

    def decision(self):
        self._entry()
        return self._decision()

    def _domain_digest(self):
        return _digest([{"point": list(p), "generation": 0, "candidates": sorted(self._eligible[p])}
                        for p in sorted(self._eligible)])

    def _whole_solution(self, context):
        if len(set(self._selected)) != len(self._selected):
            return False
        if not set(self._model["seeds"]).issubset(self._selected):
            return False
        if self._selected[:len(context["selected"])] != context["selected"]:
            return False
        if any(self._excluded.get(row["id"]) != row["reason"]
               for row in context["excluded"]):
            return False
        totals, marking = {}, {}
        for pid in self._selected:
            if pid not in self._placements or pid in self._excluded:
                return False
            row = self._placements[pid]
            for x, y, units in row["t"]:
                point = (x, y)
                totals[point] = totals.get(point, 0) + units
                if totals[point] > 1:
                    return False
            for x, y, channel, value in row["m"]:
                slot = (x, y, channel)
                if slot in marking and marking[slot] != value:
                    return False
                marking[slot] = value
        return all(totals.get(tuple(p), 0) == 1 for p in self._model["required"])

    def _certificate(self, kind, context, root=None):
        solution = None
        if kind == "SAT":
            solution = [{"point": list(p), "id": self._assigned[p]} for p in sorted(self._assigned)]
        return {"schema": CERTIFICATE_SCHEMA, "kind": kind,
                "model_sha256": self._model_sha, "spec_sha256": self._spec_sha,
                "entry": copy.deepcopy(context), "root": root, "solution": solution}

    def _result_payload(self, status, reason, nodes, context, entry, certificate):
        metrics = self.metrics
        metrics["nodes"] = nodes
        return {"schema": RESULT_SCHEMA, "status": status, "reason": reason,
                "nodes": nodes, "selected": list(self._selected),
                "context": copy.deepcopy(context), "solution_verified": status == "FINITE_EXACT_SOLUTION",
                "metrics": metrics, "certificate": certificate,
                "model_sha256": self._model_sha, "spec_sha256": self._spec_sha,
                "entry": copy.deepcopy(entry), "final": self.snapshot()}

    def _result(self, status, reason, nodes, context, entry, certificate):
        self._emit("SOLVE_RESULT", {"status": status, "nodes": nodes, "reason": reason})
        return self._result_payload(status, reason, nodes, context, entry, certificate)

    def solve(self, node_limit=100000):
        self._entry()
        _require(type(node_limit) is int and node_limit >= 0, _LIMIT)
        cp = len(self._trail)
        entry = self.snapshot()
        context = {"selected": list(self._selected), "excluded": [
            {"id": pid, "reason": self._excluded[pid]} for pid in sorted(self._excluded)]}
        nodes = 0
        stack = []
        holder = {"root": None}
        hole = (holder, "root")
        self._solving = True
        try:
            try:
                while True:
                    if nodes >= node_limit:
                        self._undo(cp)
                        cert = self._certificate("INCOMPLETE", context)
                        return self._result("UNKNOWN", "NODE_LIMIT", nodes, context, entry, cert)
                    choice = self._decision()
                    nodes += 1
                    digest = self._domain_digest()
                    if choice["kind"] == "SOLUTION":
                        _require(self._whole_solution(context), _OP)
                        cert = self._certificate("SAT", context)
                        return self._result("FINITE_EXACT_SOLUTION", "SOLUTION", nodes, context, entry, cert)
                    if choice["kind"] == "DEAD":
                        hole[0][hole[1]] = {"kind": "DEAD", "domains_sha256": digest,
                                           "point": choice["point"]}
                        if not stack:
                            self._undo(cp)
                            cert = self._certificate("UNSAT", context, holder["root"])
                            return self._result("EXHAUSTED_FINITE_SEARCH", "EXHAUSTED", nodes, context, entry, cert)
                        parent, failed, hole = stack.pop()
                        self._undo(parent)
                        self._emit("ROLLED_BACK", {"restored_state_sha256": _digest(self.snapshot())})
                        self._exclude(failed, "EXHAUSTED_CHILD")
                        self._counts["backtracks"] += 1
                        continue
                    pid = choice["candidates"][0]
                    if choice["kind"] == "BRANCH":
                        proof = {"kind": "BRANCH", "domains_sha256": digest,
                                 "point": choice["point"], "candidates": choice["candidates"],
                                 "id": pid, "child": None, "remainder": None}
                        hole[0][hole[1]] = proof
                        stack.append((len(self._trail), pid, (proof, "remainder")))
                        hole = (proof, "child")
                        self._counts["branch_decisions"] += 1
                        self._place(pid, "BRANCH")
                    else:
                        proof = {"kind": "FORCED", "domains_sha256": digest,
                                 "point": choice["point"], "id": pid, "child": None}
                        hole[0][hole[1]] = proof
                        hole = (proof, "child")
                        self._place(pid, "FORCED", forced=True)
            except CSPBudgetExceeded:
                self._undo(cp)
                cert = self._certificate("INCOMPLETE", context)
                try:
                    return self._result("UNKNOWN", "EXTERNAL_BUDGET", nodes, context, entry, cert)
                except CSPBudgetExceeded:
                    return self._result_payload("UNKNOWN", "EXTERNAL_BUDGET", nodes, context, entry, cert)
        except BaseException:
            self._undo(cp)
            raise
        finally:
            self._solving = False
