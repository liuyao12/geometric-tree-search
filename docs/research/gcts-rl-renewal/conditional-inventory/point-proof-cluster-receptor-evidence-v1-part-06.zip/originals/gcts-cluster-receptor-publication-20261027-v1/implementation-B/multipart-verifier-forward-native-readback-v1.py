"""Read-only complete-body normal-TLS verifier for the exact ten published files.

No automatic retry, project scientific imports, archive decoding or proof checks.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import ssl
import stat
import sys
import urllib.parse
import urllib.request

SELF = Path(__file__).resolve()
ROOT = Path("/private/tmp/gcts-cluster-receptor-publication-20261027-v1/root")
PUB = ROOT / "publication-cluster-receptor-multipart-api-v1/terminal.json"
OUT = ROOT / "cluster-receptor-multipart-live-TLS-verification-v1"
ORIGIN = "https://liuyao12.github.io"
PREFIX = "/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/"
NAMES = ("point-proof-parallel-progress-v1.html",
         "point-proof-cluster-receptor-summary-v1.json",
         "point-proof-cluster-receptor-evidence-v1.zip",
         "point-proof-cluster-receptor-evidence-v1-part-02.zip",
         "point-proof-cluster-receptor-evidence-v1-part-03.zip",
         "point-proof-cluster-receptor-evidence-v1-part-04.zip",
         "point-proof-cluster-receptor-evidence-v1-part-05.zip",
         "point-proof-cluster-receptor-evidence-v1-part-06.zip",
         "point-proof-cluster-receptor-evidence-v1-part-07.zip",
         "point-proof-cluster-receptor-evidence-v1-part-08.zip")
CAP = 67108864


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def parse(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, "duplicate JSON key")
            out[key] = value
        return out

    def nonfinite(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def read(path):
    need(path.is_absolute() and all(not p.is_symlink() for p in (path, *path.parents)),
         "absolute nonsymlink input")
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= CAP,
         "bounded regular input")
    with path.open("rb") as f:
        raw = f.read(CAP + 1)
    after = path.stat(follow_symlinks=False)
    need(len(raw) == before.st_size == after.st_size and len(raw) <= CAP
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), "changed or incomplete input")
    return raw


def write(path, raw):
    need(len(raw) <= CAP, "output extent")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    need(read(path) == raw, "full output readback")
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


class OnlyPagesHTTPS(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        p = urllib.parse.urlsplit(newurl)
        need(p.scheme == "https" and p.netloc == "liuyao12.github.io",
             "redirect outside same HTTPS Pages origin refused")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def verify():
    need(SELF == Path("/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B/verify_cluster_receptor_multipart_live_v1.py")
         and __debug__ and sys.flags.isolated and sys.flags.no_site
         and sys.dont_write_bytecode and sys.flags.optimize == 0, "fixed inert verifier with -I -S -B")
    need(not OUT.exists() and not OUT.is_symlink(), "fresh read-only verification directory")
    publication_raw = read(PUB)
    p = parse(publication_raw)
    need(p["schema"] == "Root-cluster-receptor-multipart-P2-publication-terminal-v1"
         and p["status"] == "EXACT_TEN_PATHS_COMMITTED_LIVE_CHECK_PENDING"
         and re.fullmatch("[0-9a-f]{40}", p["commit"]) is not None
         and len(p["files"]) == 10, "complete publication receipt required")
    OUT.mkdir(mode=0o700)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
             urllib.request.HTTPSHandler(context=ssl.create_default_context()), OnlyPagesHTTPS())
    rows = []
    for expected, name in zip(p["files"], NAMES, strict=True):
        need(expected["path"] == "docs/research/gcts-rl-renewal/conditional-inventory/" + name,
             "exact ten targets")
        local = read(Path(expected["root_source"]))
        need(len(local) == expected["bytes"] and hashlib.sha256(local).hexdigest() == expected["sha256"],
             "complete local published payload pin")
        url = ORIGIN + PREFIX + name + "?v=" + p["commit"]
        request = urllib.request.Request(url, headers={"User-Agent": "GCTS-evidence-live-verifier/1"})
        with opener.open(request, timeout=45) as response:
            final_url = response.geturl()
            parts = urllib.parse.urlsplit(final_url)
            need(response.status == 200 and parts.scheme == "https"
                 and parts.netloc == "liuyao12.github.io", "normal same-origin HTTPS200 required")
            raw = response.read(CAP + 1)
            content_type = response.headers.get("Content-Type")
        saved = write(OUT / name, raw)
        need(raw == local and saved["bytes"] == expected["bytes"]
             and saved["sha256"] == expected["sha256"], "complete live/local raw bytes mismatch")
        rows.append({"url": url, "final_url": final_url, "http_status": 200,
                     "content_type": content_type, "full_body": saved, "complete_raw_equality": True})
    need(read(PUB) == publication_raw, "publication receipt postguard")
    result = {"schema": "Root-cluster-receptor-multipart-complete-live-TLS-bodies-v1",
              "status": "ALL_TEN_COMPLETE_LIVE_BODIES_MATCH", "commit": p["commit"],
              "files": rows, "normal_TLS_certificate_and_hostname_validation": True,
              "automatic_retries": 0, "scientific_execution": False,
              "scope": "Complete HTTPS raw-body equality only; browser visual/math QA remains separate."}
    write(OUT / "verification.json", encode(result))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.parse_args()
    try:
        result = verify()
        sys.stdout.buffer.write(encode(result))
        sys.stdout.buffer.flush()
        return 0
    except BaseException as error:
        sys.stderr.buffer.write(encode({"status": "LIVE_VERIFICATION_INCOMPLETE",
            "error": type(error).__name__ + ": " + str(error)[:2048],
            "automatic_retry": False, "scope": "Read-only; no publication mutation or scientific inference."}))
        sys.stderr.buffer.flush()
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
