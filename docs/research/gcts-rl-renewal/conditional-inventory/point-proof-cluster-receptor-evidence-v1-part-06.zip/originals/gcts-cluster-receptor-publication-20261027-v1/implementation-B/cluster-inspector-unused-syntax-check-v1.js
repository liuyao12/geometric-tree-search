
  (() => {
    'use strict';
    const root = document.getElementById('cr-inspector');
    if (!root) return;
    const byId = id => root.querySelector('#' + id);
    const sampleSelect = byId('cr-sample-select');
    const layerSelect = byId('cr-layer-select');
    const status = byId('cr-status');
    const canvas = byId('cr-canvas');
    const facts = byId('cr-facts');
    const valuesList = byId('cr-values');
    const membersList = byId('cr-members');
    const rawView = byId('cr-raw');
    const ns = 'http://www.w3.org/2000/svg';
    const exact = (value, keys) => value !== null && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join('|') === [...keys].sort().join('|');
    const strings = value => Array.isArray(value) && value.every(x => typeof x === 'string') && new Set(value).size === value.length;
    const point = value => Array.isArray(value) && value.length === 2 && value.every(Number.isSafeInteger);
    const hex64 = value => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value);
    function shape(sample) {
      if (!exact(sample, ['id','label','engine','strategy','observation','cluster','placement_rows','actual_placed_id','kernel_status','reused_from_call','source_ref'])) return false;
      if (![sample.id,sample.label,sample.engine,sample.strategy,sample.kernel_status].every(x => typeof x === 'string') || !sample.id) return false;
      if (!(sample.actual_placed_id === null || typeof sample.actual_placed_id === 'string')) return false;
      if (!(sample.reused_from_call === null || (Number.isSafeInteger(sample.reused_from_call) && sample.reused_from_call >= 0))) return false;
      const o = sample.observation, c = sample.cluster, ref = sample.source_ref;
      if (!exact(o,['schema','model_sha256','inventory_version','marking_version','value_policy','selected','excluded','point','generation','incident_domain','active_bitset'])) return false;
      if (o.schema !== 'GCTS-cluster-receptor-observation-v1' || !hex64(o.model_sha256) || !point(o.point) || !Number.isSafeInteger(o.generation) || o.generation < 0) return false;
      if (![o.inventory_version,o.marking_version,o.value_policy].every(x => typeof x === 'string') || !strings(o.selected) || !strings(o.excluded) || !strings(o.incident_domain)) return false;
      if (!exact(o.active_bitset,['encoding','id_order_sha256','universe_size','hex']) || o.active_bitset.encoding !== 'LSB0_HEX' || !hex64(o.active_bitset.id_order_sha256) || !Number.isSafeInteger(o.active_bitset.universe_size) || o.active_bitset.universe_size < 0 || typeof o.active_bitset.hex !== 'string' || !/^[0-9a-f]*$/.test(o.active_bitset.hex) || o.active_bitset.hex.length !== 2*Math.ceil(o.active_bitset.universe_size/8)) return false;
      if (o.active_bitset.universe_size%8 && parseInt(o.active_bitset.hex.slice(-2),16) >= 2**(o.active_bitset.universe_size%8)) return false;
      if (!exact(c,['id','inventory_version','marking_version','members']) || ![c.id,c.inventory_version,c.marking_version].every(x => typeof x === 'string') || !strings(c.members)) return false;
      if (!exact(ref,['path','bytes','sha256']) || typeof ref.path !== 'string' || !Number.isSafeInteger(ref.bytes) || ref.bytes < 0 || !hex64(ref.sha256)) return false;
      if (!Array.isArray(sample.placement_rows)) return false;
      const ids = new Set();
      for (const row of sample.placement_rows) {
        if (!exact(row,['id','type','translation','t','m']) || typeof row.id !== 'string' || typeof row.type !== 'string' || ids.has(row.id) || !point(row.translation)) return false;
        ids.add(row.id);
        if (!Array.isArray(row.t) || row.t.length !== 1 || !Array.isArray(row.t[0]) || row.t[0].length !== 3 || !point(row.t[0].slice(0,2)) || row.t[0][2] !== 1) return false;
        if (!Array.isArray(row.m) || !row.m.every(term => Array.isArray(term) && term.length === 4 && point(term.slice(0,2)) && typeof term[2] === 'string' && typeof term[3] === 'string')) return false;
      }
      const union = new Set([...o.selected,...c.members]);
      return ids.size === union.size && [...union].every(id => ids.has(id));
    }
    function element(tag, text, className) {
      const node = document.createElement(tag);
      if (text !== undefined) node.textContent = text;
      if (className) node.className = className;
      return node;
    }
    function svgElement(tag, attrs, parent, title) {
      const node = document.createElementNS(ns,tag);
      for (const [key,value] of Object.entries(attrs || {})) node.setAttribute(key,String(value));
      if (title) { const t = document.createElementNS(ns,'title'); t.textContent = title; node.appendChild(t); }
      if (parent) parent.appendChild(node);
      return node;
    }
    function color(layer) {
      let hash = 0;
      for (let i=0;i<layer.length;i++) hash = (hash*31 + layer.charCodeAt(i)) >>> 0;
      return `hsl(${hash%360} 68% 35%)`;
    }
    function codeLine(parent, label, value) {
      const p = element('p'); p.appendChild(document.createTextNode(label + ' '));
      p.appendChild(element('code',value)); parent.appendChild(p);
    }
    let samples = [];
    try {
      const data = JSON.parse(byId('cr-example-data').textContent);
      if (!exact(data,['schema','samples']) || data.schema !== 'Root-cluster-receptor-visual-records-v1' || !Array.isArray(data.samples)) throw new Error('schema');
      const ids = new Set();
      for (const sample of data.samples) {
        if (!shape(sample) || ids.has(sample.id)) throw new Error('sample');
        ids.add(sample.id); samples.push(sample);
      }
    } catch (_) {
      status.textContent = 'Saved example data are unavailable or outside this display format. No scientific outcome is inferred.';
      return;
    }
    if (!samples.length) return;
    sampleSelect.replaceChildren(...samples.map(s => { const option=element('option',s.label); option.value=s.id; return option; }));
    sampleSelect.disabled = false;
    function current() { return samples.find(s => s.id === sampleSelect.value) || samples[0]; }
    function render() {
      const sample=current(), layer=layerSelect.value;
      if (window.MathJax && window.MathJax.typesetClear) window.MathJax.typesetClear([facts]);
      canvas.replaceChildren(); facts.replaceChildren(); valuesList.replaceChildren(); membersList.replaceChildren();
      status.textContent = `${sample.label} — saved ${sample.engine} / ${sample.strategy}; kernel record: ${sample.kernel_status}. Proposed members are not an execution log.`;
      const selected=new Set(sample.observation.selected), proposed=new Set(sample.cluster.members);
      const rows=new Map(sample.placement_rows.map(row => [row.id,row]));
      const layerTerms=[];
      for (const row of rows.values()) for (const term of row.m) if (term[2] === layer) layerTerms.push({row,term});
      const literals=[...new Set(layerTerms.map(x=>x.term[3]))].sort();
      const valueCode=new Map(literals.map((value,i)=>[value,'V'+(i+1)]));
      const hue=color(layer);
      literals.forEach(value => {
        const li=element('li'); const swatch=element('span',undefined,'cr-swatch'); swatch.style.background=hue; swatch.setAttribute('aria-hidden','true');
        li.append(swatch,document.createTextNode(valueCode.get(value)+': '),element('code',JSON.stringify(value))); valuesList.appendChild(li);
      });
      if (!literals.length) valuesList.appendChild(element('li','No assignment in this channel for the displayed union.'));
      codeLine(facts,'Cluster:',JSON.stringify(sample.cluster.id));
      codeLine(facts,'Inventory:',sample.cluster.inventory_version);
      codeLine(facts,'Marking version:',sample.cluster.marking_version);
      codeLine(facts,'Reuse origin:',sample.reused_from_call === null ? 'fresh proposal' : String(sample.reused_from_call));
      const coordinate=element('p'); coordinate.textContent=`Scheduled branch point: \\((${sample.observation.point[0]},${sample.observation.point[1]})\\).`; facts.appendChild(coordinate);
      codeLine(facts,'Observed next placement:',sample.actual_placed_id === null ? 'not supplied / not observed' : JSON.stringify(sample.actual_placed_id));
      if (sample.actual_placed_id !== null && !rows.has(sample.actual_placed_id)) facts.appendChild(element('p','The observed next placement is outside the displayed proposal union; its geometry is not invented.','cr-caption'));
      const coords=sample.placement_rows.flatMap(row=>row.t.map(t=>t.slice(0,2))).concat(layerTerms.map(x=>x.term.slice(0,2)),[sample.observation.point]);
      let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
      for (const [x,y] of coords) {minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
      minX-=1.5;maxX+=1.5;minY-=1.5;maxY+=1.5;
      const scale=Math.min(58,880/Math.max(1,maxX-minX),580/Math.max(1,maxY-minY));
      const width=Math.max(320,(maxX-minX)*scale+30),height=Math.max(240,(maxY-minY)*scale+30);
      const px=x=>15+(x-minX)*scale,py=y=>15+(y-minY)*scale;
      const svg=svgElement('svg',{viewBox:`0 0 ${width} ${height}`,role:'img','aria-label':'Fixed-orientation saved tile anchors and literal marking positions'});
      const desc=svgElement('desc',{},svg); desc.textContent='Selected placements are gray, proposed members blue, shared members amber, and only the supplied observed next placement green. Markers and links show the chosen literal channel at its stored point coordinates. No legality is inferred from square overlap.';
      const tiles=svgElement('g',{},svg),links=svgElement('g',{},svg),marks=svgElement('g',{},svg),top=svgElement('g',{},svg);
      for (const row of rows.values()) {
        const [x,y]=row.t[0],shared=selected.has(row.id)&&proposed.has(row.id),isNew=proposed.has(row.id)&&!selected.has(row.id),actual=row.id===sample.actual_placed_id;
        const stroke=actual?'#087746':shared?'#9c6500':isNew?'#0072b5':'#7b8996';
        const fill=shared?'#f8edcf':isNew?'#d8efff':'#dce2e7';
        const group=svgElement('g',{tabindex:'0'},tiles,JSON.stringify(row.id));
        group.setAttribute('aria-label',JSON.stringify(row.id)+(actual?' observed next placement':shared?' shared selected member':isNew?' proposed new member':' already selected'));
        svgElement('rect',{x:px(x-1),y:py(y-1),width:2*scale,height:2*scale,fill,'fill-opacity':.6,stroke,'stroke-width':actual?4:shared||isNew?2:1,'stroke-dasharray':shared?'5 3':'none'},group);
        svgElement('circle',{cx:px(x),cy:py(y),r:3,fill:'#172333'},group);
        if (proposed.has(row.id)) {const text=svgElement('text',{x:px(x),y:py(y)-8,'text-anchor':'middle','font-size':12,fill:stroke},group);text.textContent='P'+(sample.cluster.members.indexOf(row.id)+1)+(actual?' NEXT':'');}
      }
      const slots=new Map();
      for (const {row,term} of layerTerms) {
        const [x,y,,value]=term,[ax,ay]=row.t[0];
        svgElement('line',{x1:px(ax),y1:py(ay),x2:px(x),y2:py(y),stroke:hue,'stroke-width':1,'stroke-opacity':.5,'stroke-dasharray':'3 3'},links,JSON.stringify(row.id)+' '+JSON.stringify(term));
        const key=JSON.stringify([x,y]); if (!slots.has(key)) slots.set(key,{x,y,values:new Set(),owners:[]});
        const slot=slots.get(key); slot.values.add(valueCode.get(value)); slot.owners.push(JSON.stringify(row.id));
      }
      for (const slot of slots.values()) {
        const label=[...slot.values].sort().join('/');
        const group=svgElement('g',{tabindex:'0'},marks,label+'; '+slot.owners.join('; '));
        svgElement('circle',{cx:px(slot.x),cy:py(slot.y),r:5,fill:hue,stroke:'#fff','stroke-width':1},group);
        const text=svgElement('text',{x:px(slot.x)+7,y:py(slot.y)-6,'font-family':'monospace','font-size':11,fill:hue},group);text.textContent=label;
      }
      const [bx,by]=sample.observation.point;
      svgElement('path',{d:`M${px(bx)-7} ${py(by)-7}L${px(bx)+7} ${py(by)+7}M${px(bx)-7} ${py(by)+7}L${px(bx)+7} ${py(by)-7}`,stroke:'#a52635','stroke-width':2.5,fill:'none'},top,'Actual scheduled branch point');
      canvas.appendChild(svg);
      const order=[...sample.observation.selected,...sample.cluster.members.filter(id=>!selected.has(id))];
      for (const id of order) {
        const row=rows.get(id),li=element('li');
        const flags=[selected.has(id)?'selected':'current new',proposed.has(id)?'proposal member':'background'];
        if (selected.has(id)&&proposed.has(id)) flags.push('shared, counted once');
        if (id===sample.actual_placed_id) flags.push('observed next placement');
        li.appendChild(element('code',JSON.stringify(id))); li.appendChild(document.createTextNode(' — '+flags.join('; ')));
        const source=element('div',undefined,'cr-caption'); source.append(document.createTextNode('Type / translation / positive support: '),element('code',JSON.stringify([row.type,row.translation,row.t])));li.appendChild(source);membersList.appendChild(li);
      }
      rawView.textContent=JSON.stringify(sample,null,2);
      if (window.MathJax && window.MathJax.typesetPromise) window.MathJax.typesetPromise([facts]).catch(()=>{});
    }
    function chooseSample() {
      const sample=current(); const layers=[...new Set(sample.placement_rows.flatMap(row=>row.m.map(t=>t[2])))].sort();
      layerSelect.replaceChildren(...(layers.length?layers:['']).map(layer=>{const option=element('option',layers.length?JSON.stringify(layer):'No assigned marking channel');option.value=layer;return option;}));
      layerSelect.disabled=!layers.length;render();
    }
    sampleSelect.addEventListener('change',chooseSample);
    layerSelect.addEventListener('change',render);
    chooseSample();
  })();
  