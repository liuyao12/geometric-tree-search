"""Root passive prospective plans; no scientific imports/calls or grants.
Prepare all34 immutable templates and the two independent acquisition plans.
Later materialization requires every prescribed current Root seal.
"""
from pathlib import Path
import hashlib
import json
import sys

STUDY=Path(__file__).resolve().parents[1]
PROTOCOL=STUDY/'root/protocol-v1.json'
CLOSURE=STUDY/'root/main-source-closure-v1.json'
PROTOCOL_SHA='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422'
CLOSURE_SHA='bcdb2ea7f67be78eb1d01882cefed5ab55e4a9aad3bb49fc4b99b7b91bf19a88'
FIELDS={'stage_id','stage','resource_admitted','stage_complete','plan','result','header',
        'terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}

def pin(path):
    path=Path(path).resolve()
    assert '.partial' not in path.name
    body=path.read_bytes()
    return dict(path=str(path),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())

def read(path):
    path=Path(path)
    assert '.partial' not in path.name and not path.is_symlink()
    return json.loads(path.read_bytes())

def write(path,value):
    path=Path(path)
    body=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    with path.open('xb') as stream:stream.write(body)
    return pin(path)

def add_unique(rows,row):
    for prior in rows:
        if prior['path']==row['path']:
            assert prior==row
            return
    rows.append(dict(row))

def declarations():
    assert pin(PROTOCOL)['sha256']==PROTOCOL_SHA
    assert pin(CLOSURE)['sha256']==CLOSURE_SHA
    protocol,closure=read(PROTOCOL),read(CLOSURE)
    assert protocol['schema']=='D21-Root-conditional-family-protocol-v1'
    assert protocol['experiment']=='D21-conditional-family-selector-v1'
    assert closure['schema']=='D21-Root-main-active-source-closure-v1'
    assert closure['protocol']==pin(PROTOCOL)
    assert len(closure['common_source'])==closure['common_source_count']==47
    assert len(closure['runtime_module_paths'])==closure['runtime_modules']==35
    for row in closure['common_source']:assert pin(row['path'])==row
    assert set(closure['role_mapping'])=={'compiler','model','points','symbolic','miner','host'}
    return protocol,closure

def make_template(recipe,protocol,closure):
    stage=recipe['stage'];identity=recipe['stage_id']
    phase=protocol['phase_inputs'][stage]
    assert pin(phase['path'])==phase
    files=[dict(v) for v in closure['common_source']]
    add_unique(files,phase)
    assert len(files)==48
    return dict(schema='proof-search-case-once-template-v1',
        case_id=identity,stage=stage,experiment=protocol['experiment'],
        actual_dir=str(STUDY/'actual'/identity),
        entry_path=closure['entry_path'],worker_path=closure['worker_path'],
        runner_path=closure['runner_path'],runtime_dir=closure['runtime_dir'],
        input_path=phase['path'],protocol=pin(PROTOCOL),
        modules=closure['role_mapping'],native=closure['native'],python=closure['python'],
        limits=protocol['limits'],experiment_limits=protocol['experiment_limits'],
        required_upstream_ids=recipe['required_upstream_ids'],upstream_receipts=[],
        files=files,Root_recipe=dict(recipe),
        scope='Exact prospective full phase recipe and active execution Source closure. No grant. Template cannot execute. Future required seals are mandatory; no shortened library/policy or historical adoption.')

def materialize(identity,protocol,closure):
    matches=[r for r in protocol['job_recipes'] if r['stage_id']==identity]
    assert len(matches)==1
    recipe=matches[0];path=STUDY/'root/templates'/(identity+'-v1.json')
    template=read(path)
    assert template==make_template(recipe,protocol,closure)
    assert not Path(template['actual_dir']).exists()
    assert not Path(template['actual_dir']+'.observer').exists()
    result=dict(template)
    result['schema']='proof-search-case-once-plan-v1'
    result['files']=[dict(v) for v in template['files']]
    add_unique(result['files'],pin(path))
    envelopes=[]
    for expected in recipe['required_upstream_ids']:
        seal_path=STUDY/'root/seals'/(expected+'-v1.json')
        envelope=read(seal_path)
        assert type(envelope) is dict and set(envelope)==FIELDS
        assert envelope['stage_id']==expected
        assert envelope['stage']==('acquire' if expected.startswith('acquire-') else 'train')
        assert envelope['resource_admitted'] is True and envelope['stage_complete'] is True
        assert envelope['prior_cost_receipts']==[]
        assert type(envelope['export_sha256']) is str and len(envelope['export_sha256'])==64
        directory=STUDY/'actual'/expected
        exact_paths=dict(plan=STUDY/'root/plans'/(expected+'-v1.json'),
            result=directory/'result.json',header=directory/'worker-header.json',
            terminal=directory/'terminal.json',observer=STUDY/'actual'/(expected+'.observer')/'observer.json')
        for key,target in exact_paths.items():
            assert envelope[key]==pin(target)
            add_unique(result['files'],envelope[key])
        # The exact strict envelope is the child intake authority. Root's
        # separate admission/C-review record stays outside child Source reads.
        current_pin=pin(seal_path)
        add_unique(result['files'],current_pin)
        envelopes.append(current_pin)
    result['upstream_receipts']=envelopes
    result['template']=pin(path)
    result['scope']='Fresh exact one-use whole plan only, requiring independent exact prospective review and Root grant. Every prescribed current predecessor is sealed; no prefix salvage or historical adoption.'
    return write(STUDY/'root/plans'/(identity+'-v1.json'),result)

def main(mode,identity=None):
    protocol,closure=declarations()
    if mode=='prepare':
        assert identity is None
        (STUDY/'root/templates').mkdir(exist_ok=False)
        (STUDY/'root/plans').mkdir(exist_ok=False)
        templates=[]
        for recipe in protocol['job_recipes']:
            target=STUDY/'root/templates'/(recipe['stage_id']+'-v1.json')
            templates.append(write(target,make_template(recipe,protocol,closure)))
        assert len(templates)==34
        initial=[materialize('acquire-'+str(i),protocol,closure) for i in range(2)]
        manifest=dict(schema='D21-Root-prospective-main-template-family-v1',
            protocol=pin(PROTOCOL),Source_closure=pin(CLOSURE),
            materializer=pin(__file__),templates=templates,initial_acquisition_plans=initial,
            whole_jobs=34,evaluation_slots=192,grants=0,scientific_calls=0,
            future='Train/evaluation plans cannot materialize until all prescribed current seals exist; each materialized plan still needs an exact independent review and one-use Root grant.')
        out=write(STUDY/'root/materialized-main-templates-v1.json',manifest)
        print(json.dumps(dict(manifest=out,templates=34,initial_plans=initial)))
    elif mode=='materialize':
        assert type(identity) is str
        answer=materialize(identity,protocol,closure)
        print(json.dumps(dict(plan=answer,grants=0,scientific_calls=0)))
    else:
        raise ValueError('prepare or materialize only')

if __name__=='__main__':
    assert len(sys.argv) in (2,3)
    main(sys.argv[1],sys.argv[2] if len(sys.argv)==3 else None)
