from pathlib import Path
import json,hashlib
S=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
R=S.parents[1]
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(rel):return json.loads((S/rel).read_bytes())
selected={};omitted={}
def add(p,role):
 p=Path(p);row=pin(p);assert p==p.resolve() and not p.is_symlink()
 runtime=p.name in ('python','python3','python3.12','code.bin') or p.name.startswith('boundary-oracle')
 if runtime:
  omitted.setdefault(str(p),dict(row,role='runtime_pin_only',reason='Executable or generated Native table: identity retained; body omitted.'))
  return
 member=p.relative_to(S).as_posix() if p.is_relative_to(S) else 'external-source/'+p.relative_to(R).as_posix()
 assert member not in ('.','') and not member.startswith('/') and '..' not in Path(member).parts
 if str(p) in selected:assert {k:selected[str(p)][k] for k in row}==row;return
 selected[str(p)]=dict(row,archive_path=member,role=role)
cores={'root/protocol-v1.json':'protocol','publication/conditional-main-data-v2.json':'reader_data','review-C/typed-open-first-training-reader-data-review-v1.json':'reader_data_review','publication/conditional-main.html':'reader_html','root/conditional-main-report-state-v2.json':'population_state','implementation-B/package_conditional_main_evidence_v2.py':'package_source'}
for rel,role in cores.items():add(S/rel,role)
for row in read('root/main-source-closure-v1.json')['common_source']:add(row['path'],'active_source_or_fixed_input')
for row in read('root/protocol-v1.json')['phase_inputs'].values():add(row['path'],'public_phase_input')
for row in read('root/materialized-main-templates-v1.json')['templates']:add(row['path'],'prescribed_job_template')
for row in read('publication/conditional-main-data-v2.json')['input_pins']:add(row['path'],'complete_projector_input')
for stage,creview in [('acquire-0','typed-initial-acquire-0-actual-review-v1.json'),('acquire-1','typed-initial-acquire-1-actual-review-v1.json'),('train-0','typed-first-training-actual-review-v1.json')]:
 for folder in ('plans','grants','admission','seals','sealing-requests'):add(S/'root'/folder/(stage+'-v1.json'),'current_'+folder)
 for row in read('root/plans/'+stage+'-v1.json')['files']:add(row['path'],'current_plan_guard')
 actual=read('review-C/'+creview)
 for row in actual['complete_actual_file_census']:add(row['path'],'complete_actual_census')
 add(S/'review-C'/creview,'independent_actual_review')
 add(actual['review_program']['path'],'passive_review_source') if 'review_program' in actual else None
extra='''root/main-source-closure-v1.json
root/materialize_conditional_plans_v1.py
root/materialized-main-templates-v1.json
root/materializer-Source-offer-v1.json
root/materializer-D19-D21-v1.patch
root/custody-Source-raw-copies-v1.json
root/worker-D19-D21-v1.patch
root/runtime-raw-copies-v1.json
root/phase-input-raw-copies-v1.json
root/passive-custody-authoring-negative-v1.json
root/before-initial-acquisitions-barrier-v1.json
root/before-acquire-1-barrier-v1.json
root/before-train-0-barrier-v1.json
root/whole-prospective-initial-plan-offer-v1.json
root/both-initial-acquisition-actuals-for-review-v1.json
root/both-acquisition-seals-validation-v1.json
root/positive-acquisition-sealer-requests-offer-v1.json
root/whole-first-training-plan-offer-v1.json
root/first-training-actual-offer-v1.json
root/positive-first-training-sealer-request-offer-v1.json
root/first-training-reader-request-offer-v1.json
root/conditional-main-reader-request-v2.json
root/HTML-open-snapshot-label-copy-v1.json
root/local-reader-browser-QA-v1.json
root/conditional-main-parent-insertion-v1.html
root/publication-authority-v1.json
implementation-B/handoff-v1.json
implementation-B/API-v1.json
implementation-B/dependency-closure-v1.json
implementation-B/AST-delta-v1.json
implementation-B/manual-conformance-v1.json
implementation-B/D19-v19-to-D21-v20.patch
implementation-B/admit_conditional_stage_v1.py
implementation-B/admit_conditional_stage_v2.py
implementation-B/passive-stage-sealing-handoff-v1.json
implementation-B/passive-stage-sealing-handoff-v2.json
implementation-B/passive-stage-sealing-executable-API-v1.json
implementation-B/passive-stage-sealing-executable-API-v2.json
implementation-B/passive-stage-sealing-manual-v1.json
implementation-B/passive-stage-sealing-manual-v2.json
implementation-B/passive-stage-sealing-static-audit-v1.json
implementation-B/passive-stage-sealing-static-audit-v2.json
implementation-B/passive-stage-sealing-AST-delta-v2.json
implementation-B/D21-passive-stage-admission-v1-to-v2.patch
implementation-B/typed-main-reader-projector-Source-negative-v1.json
implementation-B/typed-main-reader-projector-Source-review-v2.json
implementation-B/packager-handoff-v1.json
implementation-B/packager-handoff-v2.json
implementation-B/package_conditional_main_evidence_v1.py
implementation-B/packager-API-v1.json
implementation-B/packager-API-v2.json
implementation-B/packager-manual-conformance-v1.json
implementation-B/packager-manual-conformance-v2.json
implementation-B/packager-static-audit-v1.json
implementation-B/packager-static-audit-v2.json
review-C/typed-protocol-input-runtime-metadata-component-review-v1.json
review-C/typed-whole-prospective-initial-acquisition-Source-plan-review-v1.json
review-C/typed-passive-stage-sealing-component-Source-negative-v1.json
review-C/typed-passive-stage-sealing-component-Source-review-v2.json
review-C/typed-positive-acquisition-sealer-requests-review-v1.json
review-C/typed-first-training-whole-prospective-Source-plan-review-v1.json
review-C/typed-positive-first-training-sealer-request-review-v1.json
review-C/typed-open-first-training-population-reader-request-review-v1.json
'''.splitlines()
extra += ['root/local-reader-interaction-QA-v2.json','root/build_explicit_publication_inventory_v1.py','review-C/passive_initial_acquisitions_review_v1.py','review-C/passive_first_training_review_v1.py']
for rel in extra:add(S/rel,'explicit_current_source_or_audit_metadata')
for version in (1,2):
 for row in read(f'implementation-B/packager-handoff-v{version}.json')['files']:add(row['path'],'packager_source_or_metadata')
for version in (1,2):
 offer=read(f'diagnostics-L/reader-source-handoff-v{version}.json');add(S/f'diagnostics-L/reader-source-handoff-v{version}.json','reader_source_offer')
 for row in offer['files']:add(row['path'],'reader_source_or_metadata')
for rel in ('diagnostics-L/typed-main-driver-and-passive-sealing-design-Source-review-v1.json','diagnostics-L/typed-worker-active-closure-and-materializer-Source-review-v1.json','diagnostics-L/typed-worker-active-closure-and-materializer-Source-review-v2.json'):add(S/rel,'independent_source_review')
# Caller supplies exactly the newly frozen C packager Source PASS/negative path list.
import sys
for rel in sys.argv[1:]:add(S/rel,'packager_source_review')
assert set(selected).isdisjoint(omitted)
inventory=dict(schema='D21-explicit-main-publication-inventory-v1',files=sorted(selected.values(),key=lambda r:r['archive_path']),omitted_runtime=sorted(omitted.values(),key=lambda r:r['path']),scope='Explicit current OPEN three-job milestone allowlist. All34 templates and all three physical phase inputs retained; only3actuals admitted,31jobs pending. Includes complete current actuals, active Source/fixed program inputs, guards, receipts, preserved Source negatives and report. No directory scan, recursive pin chasing, historical actual/result/policy adoption or scientific calls. Executable/generatedtables bodies omitted with exact identities. Later inventory/request/archive/install/live reviews remain outside this snapshot.',scientific_calls=0)
p=S/'root/conditional-main-publication-inventory-v1.json'
with p.open('x') as f:json.dump(inventory,f,sort_keys=True,indent=2);f.write('\n')
request=dict(schema='D21-passive-raw-package-request-v1',protocol=pin(S/'root/protocol-v1.json'),inventory=pin(p),reader_data=pin(S/'publication/conditional-main-data-v2.json'),reader_data_review=pin(S/'review-C/typed-open-first-training-reader-data-review-v1.json'),external_sources=[{k:r[k] for k in ('path','bytes','sha256')} for r in selected.values() if not Path(r['path']).is_relative_to(S)],publication_authorized=True,scientific_calls=0)
q=S/'root/conditional-main-packaging-request-v1.json'
with q.open('x') as f:json.dump(request,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(inventory=pin(p),request=pin(q),selected=len(selected),omitted_runtime=len(omitted),externals=len(request['external_sources']))))
