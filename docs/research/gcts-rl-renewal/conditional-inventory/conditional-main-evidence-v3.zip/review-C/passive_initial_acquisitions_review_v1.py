"""C-only raw/complete-saved-JSON review. Never imports or invokes subject code."""
from pathlib import Path
import collections,hashlib,json
D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021');C=D/'review-C';R=D/'root'
SEEN={}
def pin(p):
 p=Path(p);assert p.is_file() and not p.is_symlink() and p==p.resolve();b=p.read_bytes();v=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());SEEN[str(p)]=v;return v
def load(p):
 assert '.partial' not in Path(p).name;pin(p);return json.loads(Path(p).read_bytes())
def verify(p):assert pin(p['path'])==p
def wire(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(v):return hashlib.sha256(wire(v)).hexdigest()
def strip_time(v):
 if isinstance(v,dict):return {k:strip_time(x) for k,x in v.items() if k!='base_compile_seconds'}
 if isinstance(v,list):return [strip_time(x) for x in v]
 return v
OFFER_PIN=pin(R/'both-initial-acquisition-actuals-for-review-v1.json');assert OFFER_PIN['sha256']=='f536997b564775f1545976de5163cbd3d22daccbadf0593226bac0ae533147bb'
offer=load(OFFER_PIN['path']);verify(offer['whole_prospective_review']);assert load(offer['whole_prospective_review']['path'])['review_passed'] is True
verify(offer['sealer_Source']);verify(offer['sealer_API']);assert offer['Root_admissions']==offer['sealer_invocations']==0
BANKS={'numeric':23,'word':48,'graph':22,'encoding':40,'principal':53,'matched_symbolic':13,'conditional_numeric':57,'conditional_semantic':18,'native_batch':6,'guard_resolver':17,'guard_differential':2}
reviews=[]
for case_no,case in enumerate(offer['cases']):
 identity='acquire-'+str(case_no);assert case['stage_id']==identity
 comp=case['components'];plan=load(comp['plan']['path']);worker=load(comp['result']['path']);header=load(comp['header']['path']);terminal=load(comp['terminal']['path']);observer=load(comp['observer']['path']);science=worker['scientific_result'];actual=D/'actual'/identity
 for p in comp.values():verify(p)
 assert len(plan['files'])==49 and plan['stage']=='acquire' and plan['case_id']==identity and plan['upstream_receipts']==plan['required_upstream_ids']==[]
 for p in plan['files']:verify(p)
 document=load(plan['input_path']);protocol=load(plan['protocol']['path']);descriptor=plan['Root_recipe'];spec=document['donors'][case_no]
 assert descriptor==protocol['job_recipes'][case_no] and descriptor['donor_ids']==[spec['id']]
 grant=load(case['grant']['path']);verify(case['grant']);consumed=load(actual/'CONSUMED.json');owner=load(actual/'owned-child.json')
 assert grant['authorized'] is grant['review_passed'] is True and type(grant['uses']) is int and grant['uses']==1
 assert grant['plan_sha256']==comp['plan']['sha256'] and grant['runner_sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'
 assert grant['prospective_review']==offer['whole_prospective_review'];verify(grant['serial_barrier'])
 assert consumed['plan_sha256']==comp['plan']['sha256'] and consumed['grant_sha256']==case['grant']['sha256'] and consumed['case_id']==identity
 assert worker['status']==header['status']=='COMPLETE' and worker['error'] is None and worker['first_Root_fault'] is header['first_Root_fault'] is False
 assert worker['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
 assert worker['case_id']==header['case_id']==terminal['case_id']==observer['case_id']==identity and worker['stage']=='acquire'
 assert header['result']==terminal['result']==comp['result'] and terminal['header']==header and terminal['header_valid'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
 assert terminal['process_exit_code']==observer['parent_exit_code']==0 and terminal['reason'] is observer['reason'] is None and terminal['errors']==observer['errors']==[]
 assert observer['resource_candidate_accepted'] is True and observer['fallback_trigger_seconds'] is None
 assert terminal['known_exit_seconds']<=180 and terminal['final_custody_gate_seconds']<=210 and observer['final_observer_gate_seconds']<=210
 assert observer['final_conservative_whole_peak_bytes']<1073741824 and observer['final_conservative_whole_peak_bytes']==case['whole_peak_bytes']
 assert observer['elapsed_seconds']==case['observer_sample_seconds'] and worker['callbacks']<=400000000
 assert comp['result']['bytes']<=50331648 and terminal['memory_terminal_output_reserve_bytes']==observer['final_output_memory_reserve_bytes']==9437184
 assert terminal['stored_bytes_before_terminal_receipt']<=134217728 and observer['stored_bytes_before_observer_receipt']+observer['receipt_allowance_bytes']<=134217728
 for outer in (terminal,observer):
  for log in outer['logs'].values():assert log['eof'] is True and log['overflow'] is False and log['bytes']==log['stored']<=4194304
 expected_census=sorted([pin(p) for directory in (actual,D/'actual'/(identity+'.observer')) for p in directory.rglob('*') if p.is_file()],key=lambda p:p['path'])
 assert expected_census==case['complete_actual_file_census'] and len(expected_census)==14 and sum(p['bytes'] for p in expected_census)==case['physical_bytes']<134217728
 assert not any('.partial' in Path(p['path']).name for p in expected_census)
 assert load(D/'actual'/(identity+'.observer')/'stdout.bin')==terminal
 assert worker['work_snapshots']==[] and all(x['status']=='COMPLETED' for x in worker['stages'])
 transport=worker['native_transport'];queries=worker['native_queries'];assert worker['native_requests_started']==len(queries)==transport['complete_records']==50
 assert transport['closed'] is transport['all_reaped'] is transport['constructor_completed'] is True and transport['native_exit_code']==0 and transport['cleanup_errors']==[]
 assert transport['parent_pid']==transport['parent_pgid']==owner['child_pid']==owner['child_pgid']==transport['native_pgid']
 assert observer['owned_child']==owner and owner['plan_sha256']==comp['plan']['sha256'] and header['native_closed_and_reaped'] is True
 assert transport['native_high_water_bytes']==worker['native_peak_bytes']==header['native_peak_bytes']
 assert len(transport['request_stages'])==50 and collections.Counter(q['result']['status'] for q in queries)=={'accepted':25,'rejected':25}
 for i,(q,stage) in enumerate(zip(queries,transport['request_stages'],strict=True)):
  assert type(q['id']) is int and q['id']==i==stage['ordinal']==stage['record_id'] and stage['stage']=='COMPLETED' and type(stage['limit']) is int and stage['limit']==1000000000
  assert q['request_sha256']==digest(q['request']) and all(q[k]==stage[k] for k in ('purpose','request_sha256','input_sha256','output_sha256'))
  assert q['request']['protocol']=='gcts-fol-1' and q['request']['blocks']==[] and q['query_target']=='fixed_assertion' and q['result']['micro_steps']<=1000000000
 assert pin(actual/'native/input.bin')['sha256']==queries[-1]['input_sha256'] and pin(actual/'native/output.bin')['sha256']==queries[-1]['output_sha256']
 assert pin(actual/'native/boundary-oracle')['sha256']=='2b6bf8bb09a4e03d0cb1b4595dea1fe6d4432aa93d8f7eed72c30077fd9941a4'
 assert pin(actual/'native/code.bin')['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
 worker_peak=max(worker['python_peak_bytes'],header['python_peak_after_output_bytes'],terminal['child_usage']['ru_maxrss'])
 combined=worker_peak+worker['native_peak_bytes']+terminal['parent_usage']['ru_maxrss']+9437184
 assert combined==terminal['conservative_combined_peak_bytes'] and combined+observer['final_observer_peak_bytes']+9437184==observer['final_conservative_whole_peak_bytes']
 assert science['stage_id']==identity and science['stage']=='acquire' and science['status']=='FRESH_DONOR_ACQUISITION_COMPLETE'
 assert science['qualified'] is science['stage_complete'] is science['job_record_complete'] is science['all_profile_fragments_accepted'] is True and science['resource_admitted'] is False
 assert science['inputs']==document and science['limits']==plan['experiment_limits'] and science['native_records']==queries
 assert science['format_check']['complete'] is True and science['format_check']['statement_ids']==[x['id'] for x in document['donors']]
 costs=science['cumulative_costs'];assert costs['receipts']==costs['stage_ids']==[] and costs['whole_seconds']==0.0 and costs['maximum_prior_whole_peak_bytes']==0 and costs['current_whole_seconds'] is None
 assert costs['current_entry_seconds']==costs['upstream_plus_current_entry_seconds']==science['seconds']
 controls=science['controls'];bank_counts={};bank_ids={}
 for name,count in BANKS.items():
  bank=controls[name];rows=bank['controls'];assert bank['complete'] is True and len(rows)==count and len({r['id'] for r in rows})==count
  assert all(row.get('passed') is True or row.get('status')=='PASSED' for row in rows)
  bank_counts[name]=count;bank_ids[name]=[r['id'] for r in rows]
 calibration=controls['reference_setup_calibration'];assert calibration['complete'] is calibration['full_model_value_unchanged'] is True and calibration['status']=='PASSED' and calibration['control_count']==1
 assert {k:v for k,v in calibration['original'].items() if k not in calibration['omitted_from_comparison']}=={k:v for k,v in calibration['production'].items() if k not in calibration['omitted_from_comparison']}
 inherited=controls['inherited'];assert inherited['base_solutions']==inherited['marked_solutions'] and len(inherited['base_solutions'])==2 and len(inherited['full_domain_audits'])==9
 assert inherited['callback_identity_propagated'] is inherited['global_dead_forced_generation_controls'] is inherited['incomplete_certificate_rejected'] is True
 assert controls['conditional_corpus'] is controls['corpus'] is None
 assert controls['conditional_corpus_status']=='NOT_REQUESTED_FOR_THIS_PHASE'
 record=science['records'][0];assert len(science['records'])==1 and record['spec']==spec
 search=record['search'];proof=search['proof'];pc=record['proof_check'];model=record['model'];assert len(proof)==spec['length']==7 and search['metrics']['attempts']==7 and search['root_restored'] is True and search['cluster_ordering'] is False
 assert pc['status']=='HOST_REGION_NATIVE_ACCEPTED' and pc['host_check']['accepted'] is pc['native_proof_accepted'] is pc['region']['complete'] is True
 assert pc['host_check']['target']==spec['target'] and pc['host_check']['rows']==7 and pc['region']['decoded_rows']==7 and pc['region']['required_points']==pc['region']['selected_placements']==14
 def owned(q):assert q==queries[q['id']];return q['id']
 def accepted(q,rows,target,theory):
  owned(q);assert q['result']['status']=='accepted' and q['request']==dict(protocol='gcts-fol-1',theory=theory,blocks=[],proof=rows,target=target);return q['id']
 proof_id=accepted(pc['native_record'],proof,spec['target'],spec['theory']);assert pc['native_limit']==1000000000
 assert record['reference_check']['complete'] is record['word_model_check']['complete'] is record['guard_acquisition_check']['complete'] is True
 assert record['word_reference_differential']['performed_on_this_model'] is False
 assert model['word_terminator']==256 and model['arity']==0 and model['mode_ids']=={} and len(model['domains'])==7
 assert len(set(model['word_dictionary']))==len(model['word_dictionary'])==record['word_model_check']['dictionary_words']==record['reference_check']['distinct_complete_words']
 assert model['word_dictionary'][0]==wire(spec['target']).hex() and [[24,100],0] in model['initial']['marks']
 placements={tuple(v['key']):v for v in model['placements']};assert len(placements)==len(model['placements'])==record['word_model_check']['placements']==record['reference_check']['accepted_placements']
 assert len(search['placements'])==14 and len({tuple(k) for k in search['placements']})==14
 for row,command in enumerate(proof):
  ck,gk=search['placements'][2*row:2*row+2];assert ck[:2]==[row,0] and gk[:2]==[row,1] and ck[2]==gk[2] and model['domains'][row][ck[2]]==command
  for key in (ck,gk):assert tuple(key) in placements and placements[tuple(key)]['command_reference']==[row,ck[2]]
 for placement in model['placements']:
  for point,value in placement['marks']:
   if point[1]==100:assert type(value) is int and 0<=value<len(model['word_dictionary'])
 candidates=record['candidates'];assert len(candidates)==8 and candidates[0]['proof']==proof and candidates[0]['ancestry']==list(range(7))
 profile=[];candidate_rows=[]
 for ordinal,candidate in enumerate(candidates):
  assert candidate['ordinal']==ordinal
  ancestry=candidate['ancestry'];assert ancestry==sorted(set(ancestry)) and all(type(x) is int and 0<=x<7 for x in ancestry)
  if ordinal:assert candidate['source_row']==ordinal-1 and ancestry[-1]==ordinal-1
  assert len(candidate['proof'])==len(ancestry)
  for local,source_row in enumerate(ancestry):
   original=proof[source_row];actual_command=candidate['proof'][local]
   assert {k:v for k,v in original.items() if k not in ('antecedent','implication')}=={k:v for k,v in actual_command.items() if k not in ('antecedent','implication')}
   for ref in ('antecedent','implication'):
    if ref in original:assert original[ref] in ancestry and actual_command[ref]==ancestry.index(original[ref])
  eligible=all(c['rule'] in ('axiom','mp') for c in candidate['proof']) and any(c['rule']=='mp' for c in candidate['proof'])
  assert candidate['profile_eligible'] is eligible
  if eligible:
   assert candidate['eligible'] is True and candidate['native_resolution']=='accepted' and candidate['host_check']['accepted'] is True
   qid=accepted(candidate['native_record'],candidate['proof'],candidate['target'],spec['theory']);profile.append(candidate)
  else:
   assert candidate['eligible'] is False and candidate['native_resolution']=='OUTSIDE_DECLARED_PROFILE' and candidate['native_record'] is None;qid=None
  candidate_rows.append(dict(ordinal=ordinal,ancestry=ancestry,profile_eligible=eligible,native_query=qid))
 assert [c['ordinal'] for c in profile]==[0,5,6,7] and len(science['certificates'])==4
 resolution=record['fragment_resolution'];assert resolution['complete'] is resolution['all_profile_fragments_accepted'] is True and resolution['unresolved']==[] and resolution['profile_eligible_count']==resolution['native_accepted_count']==4
 for c,cert in zip(profile,science['certificates'],strict=True):
  assert cert['provenance']['candidate_ordinal']==c['ordinal'] and cert['spec']==spec and cert['full_donor_proof']==proof and cert['full_donor_check']==pc and cert['native_limit']==1000000000
  for key in ('proof','target','native_record','families','principal_check'):assert cert[key]==c[key]
  principal=cert['families']['principal'];typ=principal['certificate']['typing'];ind=cert['principal_check']['independent'];assert cert['principal_check']['complete'] is ind['complete'] is True
  for key in ('parameters','graph','row_formulas','premises','conclusion'):assert ind[key]==typ[key]
  assert ind['template']==principal['template'] and ind['concrete_arguments']==principal['certificate']['donor_arguments'] and ind['port_aliases']==principal['certificate']['port_occurrences']
  assert principal['certificate']['request_sha256']==digest(cert['native_record']['request'])
 pairing=science['pairing'];assert pairing['no_principal_coalescence'] is True and pairing['raw_certificates']==4 and pairing['paired_units']==len(pairing['units'])==3
 groups={}
 for i,cert in enumerate(science['certificates']):groups.setdefault(cert['families']['atom']['id'],[]).append(i)
 assert len(groups)==3
 for unit in pairing['units']:
  uid=unit['paired_unit_id'];members=groups[uid];assert [m['certificate_ordinal'] for m in unit['members']]==members
  for mode in ('atom','principal'):
   wrapper=next(v for v in science['libraries'][mode] if v['id']==uid);origin=members[0];inner=science['certificates'][origin]['families'][mode]
   assert wrapper['structural_family']==inner and wrapper['source_certificate_ordinal']==origin and wrapper['paired_unit_id']==uid and wrapper['structural_id']==inner['id']
   for key,value in inner.items():assert wrapper[key]==(uid if key=='id' else value)
   assert unit['wrapper_checks'][mode]['complete'] is True
 assert any(sum(c['rule']=='mp' for c in f['template']['proof'])>=2 for f in science['libraries']['principal'])
 exported=science['export'];assert exported['qualified'] is True and exported['stage_id']==identity and exported['stage']=='acquire' and exported['acquisition_document']==document and exported['donor_ids']==[spec['id']]
 for key in ('certificates','libraries','pairing','donor_outcomes'):assert exported[key]==science[key]
 assert exported['donor_outcomes'][0]['whole_native_accepted'] is True and exported['donor_outcomes'][0]['record_sha256']==digest(record)
 assert exported['donor_evidence']==[dict(spec=spec,search=dict(status=search['status'],proof=proof),proof_check=pc,candidates=candidates,fragment_resolution=resolution,full_record_sha256=digest(record))]
 used=set([proof_id]+[c['native_record']['id'] for c in profile]);guard_member_count=0
 def ledger(e):
  nonlocal_dummy=None
  assert e['complete'] is True and e['status']=='complete' and e['active_query'] is None and type(e['unresolved']) is int and e['unresolved']==0 and e['resolved']==len(e['members'])
  for q in e['query_records']:used.add(owned(q))
  for batch in e['batches']:
   q=queries[batch['query_id']];assert q==e['query_records'][batch['query_record_ordinal']] and batch['status']==q['result']['status']
   assert q['request']['proof']==[m['command'] for m in e['members'][batch['start']:batch['stop']]] and q['request']['target']==q['request']['proof'][-1]['formula']
   if batch['status']=='rejected' and batch['stop']-batch['start']>1:
    children=[b for b in e['batches'] if b['parent']==batch['index']];assert len(children)==2 and children[0]['start']==batch['start'] and children[0]['stop']==children[1]['start'] and children[1]['stop']==batch['stop']
  for i,m in enumerate(e['members']):
   q=queries[m['native_query']];assert m['ordinal']==i and q['request']['proof'][m['native_row']]==m['command'] and m['status']==q['result']['status']
   assert m['command']['rule'] in ('tautology','instantiate','eq_subst')
   if m['status']=='rejected':assert m['resolution_kind']=='singleton_rejection' and len(q['request']['proof'])==1
 assert len(worker['guard_compilations'])==3
 for e in worker['guard_compilations']:ledger(e);guard_member_count+=len(e['members'])
 assert record['compiler']['guard_evidence']==worker['guard_compilations'][2]
 for diff,e in zip(controls['guard_differential']['controls'],worker['guard_compilations'][:2],strict=True):
  assert diff['batch_compiled']['guard_evidence']==e and strip_time(diff['original_model'])==strip_time(diff['batch_model'])
  assert diff['old_reference']['complete'] is diff['batch_reference']['complete'] is diff['old_owner_check']['complete'] is diff['batch_owner_check']['complete'] is True
  for key in ('basis','variables','tautologies','admitted_schemes'):assert diff['old_compiled'][key]==diff['batch_compiled'][key]
  for q in diff['old_owned_records']:used.add(owned(q))
 for row in controls['native_batch']['controls']:
  q=row['native_record'];used.add(owned(q));assert q['result']['status']==row['expected_native_status']
 assert used==set(range(50))
 checks=[dict(id='exact-once-Source-and-custody',passed=True,finding='Both grant and consumed identity, current49 Source/phase/template guards, fixed owned process group, complete headers/terminal/observer/logs and14-file current census join. No Source mutation, Root fault, transport/close failure or retry evidence.'),dict(id='original-outer-resource-gates',passed=True,finding='Original160/180/210/225 and1GiB/128MiB/48MiB/4MiB/9MiB bounds retained. Final conservative peak reconciles Python post-output/waited-child, Native, parent/observer and both reserves. Observer sample is distinct from final-gate/worker/tool clocks; nested clocks are not added.'),dict(id='all-fresh-controls-and-format',passed=True,finding='All299 named rows across11banks plus1setup differential returned complete/PASSED, with separate inherited9full-domain audits. Whole source-prescribed acquisition format and2public donor input structures are complete; training-only corpus bank was correctly not requested. These are fresh current receipts, not old pass adoption.'),dict(id='all50-owned-Native-records',passed=True,finding='Every current request/result and transport stage id/purpose/digest/input/output/limit joins the owned stream.25accepted and25rejected records are preserved; all six adversarial Native checks, old/batch differential queries, three compiler ledgers and donor/fragment proofs exactly cover50 IDs. Rejected compiler/control queries are not certificate acceptances.'),dict(id='whole-donor-and-finite-word-region',passed=True,finding='One fresh conventional S0 seven-row proof and fourteen placements match the current specification, original model catalog and fresh Host/full finite word-point/Native blocks=[] receipts. Full reference and indexed-word receipts remain complete; assigned boundary wordID0 and terminator256 are retained. No pointwise-byte identity or universal physical Wang claim.'),dict(id='all-candidate-certificates-and-independent-typing',passed=True,finding='All eight full/ancestor occurrences and supplied ancestry/reference projections are retained. Every one of four profile candidates is Host/current-Native accepted; the remaining four are explicitly outside profile. Production and independent finite typing fields, concrete arguments/aliases, exact certificates, wrappers and three shared atom-class paired units join literally. No fresh ancestry, unifier, remapper, miner or checker was run by C.'),dict(id='export-and-scope',passed=True,finding='The whole current donor evidence/certificates/paired libraries and post-annotation record digest match the qualified export exactly. This is acquisition qualification only, not a Root seal, policy/training episode, learned/GCTS benefit or new theorem claim. All future stages require fresh exact current sealed prerequisites and plan reviews.')]
 review=dict(schema='D21-C-conditional-stage-actual-review-v1',review_passed=True,resource_admitted=True,scientific_qualified=True,stage_complete=True,stage_id=identity,stage='acquire',protocol=plan['protocol'],**comp,export_sha256=digest(exported),input_pins=sorted(plan['files'],key=lambda p:p['path']),complete_actual_file_census=expected_census,Root_admission_issued=False,whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],grant=case['grant'],consumed=pin(actual/'CONSUMED.json'),owned_child=pin(actual/'owned-child.json'),serial_barrier=grant['serial_barrier'],actual_offer=OFFER_PIN,prospective_review=offer['whole_prospective_review'],checks=checks,failures=[],candidate_literal_joins=candidate_rows,counts=dict(donors=1,whole_conventional_proofs=1,whole_proof_rows=7,declared_candidate_occurrences=8,accepted_profile_certificates=4,paired_units=3,principal_structures=pairing['principal_structures'],named_control_rows=299,setup_control=1,inherited_full_domain_audits=9,Native_requests=50,Native_accepted_records=25,Native_rejected_records=25,guard_compilations=3,guard_members=guard_member_count,real_training_episodes=0,policy_exports=0),costs=dict(observer_sample_seconds=observer['elapsed_seconds'],observer_final_gate_seconds=observer['final_observer_gate_seconds'],worker_seconds=worker['elapsed_seconds'],entry_seconds=science['seconds'],physical_postterminal_bytes=sum(p['bytes'] for p in expected_census),python_peak_with_postoutput_and_waited_child=worker_peak,Native_peak=worker['native_peak_bytes'],parent_peak=terminal['parent_usage']['ru_maxrss'],observer_peak=observer['final_observer_peak_bytes'],each_output_reserve=9437184,scope='Unique current cold observer sample once; all setup/control/check/output/custody costs charged. Nested elapsed samples overlap and are not summed.'),bank_counts=bank_counts,bank_ID_sequences_sha256=digest(bank_ids),scope='Independent passive complete saved JSON/raw Source/custody/library evidence review. Source soundness and actual Host/Native/typing/model receipts are joined, not replayed. Root alone may admit/seal after a separate exact request. No historical scientific export adoption, scientific helper/checker/Graph/State/numeric/RNG/Native/control replay, partial intake or future actual/grant authority.',helper_invocations=0,scientific_imports=0,scientific_calls=0,subject_replays=0,partial_files_parsed=0,grants_issued=0,tools_idle_after_freeze=True,review_program=pin(Path(__file__).resolve()))
 reviews.append(review)
for v in list(SEEN.values()):assert pin(v['path'])==v
for review in reviews:
 out=C/('typed-initial-'+review['stage_id']+'-actual-review-v1.json')
 with out.open('xb') as f:f.write((json.dumps(review,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode())
 print(json.dumps(pin(out)))
