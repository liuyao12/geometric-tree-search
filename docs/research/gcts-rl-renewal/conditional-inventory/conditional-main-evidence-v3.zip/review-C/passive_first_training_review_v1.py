"""C-only raw/complete saved JSON joins. No subject imports or helper replay."""
from pathlib import Path
import collections, hashlib, json, math

D=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
R=D/'root'; C=D/'review-C'; SEEN={}
def pin(path):
 p=Path(path); assert p==p.resolve() and p.is_file() and not p.is_symlink()
 b=p.read_bytes(); v=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()); SEEN[str(p)]=v; return v
def verify(v): assert pin(v['path'])==v
def object_pairs(pairs):
 out={}
 for k,v in pairs: assert k not in out; out[k]=v
 return out
def load(path):
 assert '.partial' not in Path(path).name; pin(path)
 return json.loads(Path(path).read_bytes(),object_pairs_hook=object_pairs,
                   parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
def wire(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def same(a,b): return wire(a)==wire(b)
def digest(value): return hashlib.sha256(wire(value)).hexdigest()
def number(value): return type(value) in (int,float) and math.isfinite(value)
def typed_vector(value,size): assert type(value) is list and len(value)==size and all(number(v) for v in value)

offer_pin=pin(R/'first-training-actual-offer-v1.json')
assert offer_pin['sha256']=='66fd568882dc0b608eef45bd9d6824c1eb8db21a4d05846b5ca54f463197c502'
offer=load(offer_pin['path']); assert offer['stage_id']=='train-0' and offer['Root_admission_issued'] is False and offer['actual_invocations']==1
components={k:offer[k] for k in ('plan','result','header','terminal','observer')}
for p in components.values(): verify(p)
plan=load(components['plan']['path']); worker=load(components['result']['path']); header=load(components['header']['path'])
terminal=load(components['terminal']['path']); observer=load(components['observer']['path']); science=worker['scientific_result']
for p in plan['files']: verify(p)
assert len(plan['files'])==61 and len({p['path'] for p in plan['files']})==61
assert plan['case_id']=='train-0' and plan['stage']=='train' and plan['required_upstream_ids']==['acquire-0','acquire-1']
protocol=load(plan['protocol']['path']); document=load(plan['input_path']); descriptor=plan['Root_recipe']
assert descriptor==protocol['job_recipes'][2] and descriptor['manifest_indices']==[0,1] and descriptor['pass_index']==0
assert descriptor['episodes']==document['protocol']['shards'][0]['episodes']
verify(offer['prospective_review']); prospective=load(offer['prospective_review']['path'])
assert prospective['review_passed'] is True and prospective['failures']==[]
verify(offer['grant']); grant=load(offer['grant']['path']); verify(offer['barrier']); barrier=load(offer['barrier']['path'])
assert grant['authorized'] is grant['review_passed'] is True and type(grant['uses']) is int and grant['uses']==1
assert grant['plan_sha256']==components['plan']['sha256'] and grant['runner_sha256']=='98c55321bb87a8c04b2c6d56b357aba9c3a8f5fc98660474ae3ac1c9d00b0aca'
assert grant['prospective_review']==offer['prospective_review'] and grant['serial_barrier']==offer['barrier']
actual=D/'actual/train-0'; consumed=load(actual/'CONSUMED.json'); owner=load(actual/'owned-child.json')
assert consumed['case_id']=='train-0' and consumed['plan_sha256']==components['plan']['sha256'] and consumed['grant_sha256']==offer['grant']['sha256']
assert worker['status']==header['status']=='COMPLETE' and worker['error'] is None
assert worker['first_Root_fault'] is header['first_Root_fault'] is False
assert worker['source_unchanged'] is header['source_unchanged'] is terminal['sources_unchanged'] is True
assert worker['stage']=='train' and worker['case_id']==header['case_id']==terminal['case_id']==observer['case_id']=='train-0'
assert header['result']==terminal['result']==components['result'] and terminal['header']==header
assert terminal['header_valid'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
assert terminal['process_exit_code']==observer['parent_exit_code']==0 and terminal['reason'] is observer['reason'] is None
assert terminal['errors']==observer['errors']==[] and observer['resource_candidate_accepted'] is True and observer['fallback_trigger_seconds'] is None
assert terminal['known_exit_seconds']<=180 and terminal['final_custody_gate_seconds']<=210 and observer['final_observer_gate_seconds']<=210
assert 0<=worker['callbacks']<=400000000 and components['result']['bytes']<=50331648
assert terminal['stored_bytes_before_terminal_receipt']<=134217728 and observer['stored_bytes_before_observer_receipt']+observer['receipt_allowance_bytes']<=134217728
assert terminal['memory_terminal_output_reserve_bytes']==observer['final_output_memory_reserve_bytes']==9437184
for outer in (terminal,observer):
 for log in outer['logs'].values(): assert log['eof'] is True and log['overflow'] is False and log['bytes']==log['stored']<=4194304
census=sorted([pin(p) for directory in (actual,D/'actual/train-0.observer') for p in directory.rglob('*') if p.is_file()],key=lambda p:p['path'])
assert census==offer['complete_actual_file_census'] and len(census)==14 and not any('.partial' in Path(p['path']).name for p in census)
physical=sum(p['bytes'] for p in census); assert physical<134217728
assert load(D/'actual/train-0.observer/stdout.bin')==terminal
transport=worker['native_transport']; queries=worker['native_queries']
assert worker['native_requests_started']==len(queries)==transport['complete_records']==27
assert transport['closed'] is transport['all_reaped'] is transport['constructor_completed'] is True and transport['native_exit_code']==0 and transport['cleanup_errors']==[]
assert transport['parent_pid']==transport['parent_pgid']==owner['child_pid']==owner['child_pgid']==transport['native_pgid']
assert observer['owned_child']==owner and owner['plan_sha256']==components['plan']['sha256'] and header['native_closed_and_reaped'] is True
assert worker['native_peak_bytes']==header['native_peak_bytes']==transport['native_high_water_bytes']
assert len(transport['request_stages'])==len(queries) and collections.Counter(q['result']['status'] for q in queries)=={'accepted':5,'rejected':22}
for i,(q,stage) in enumerate(zip(queries,transport['request_stages'],strict=True)):
 assert type(q['id']) is int and q['id']==i==stage['ordinal']==stage['record_id'] and stage['stage']=='COMPLETED'
 assert stage['limit']==1000000000 and q['request_sha256']==digest(q['request'])
 assert all(q[k]==stage[k] for k in ('purpose','request_sha256','input_sha256','output_sha256'))
 assert q['request']['protocol']=='gcts-fol-1' and q['request']['blocks']==[] and q['query_target']=='fixed_assertion' and q['result']['micro_steps']<=1000000000
assert pin(actual/'native/input.bin')['sha256']==queries[-1]['input_sha256'] and pin(actual/'native/output.bin')['sha256']==queries[-1]['output_sha256']
assert pin(actual/'native/boundary-oracle')['sha256']=='2b6bf8bb09a4e03d0cb1b4595dea1fe6d4432aa93d8f7eed72c30077fd9941a4'
assert pin(actual/'native/code.bin')['sha256']=='97f0b600cffd83552c4e0f0c4fb1f5d26cfdb76e3e74b267bbaebeddc836e7ed'
python_peak=max(worker['python_peak_bytes'],header['python_peak_after_output_bytes'],terminal['child_usage']['ru_maxrss'])
combined=python_peak+worker['native_peak_bytes']+terminal['parent_usage']['ru_maxrss']+9437184
assert combined==terminal['conservative_combined_peak_bytes']
assert combined+observer['final_observer_peak_bytes']+9437184==observer['final_conservative_whole_peak_bytes']==394412032<1073741824
assert all(stage['status']=='COMPLETED' for stage in worker['stages'])
assert science['stage_id']=='train-0' and science['stage']=='train' and science['status']=='CONDITIONAL_TRAIN_SHARD_COMPLETE'
assert science['stage_complete'] is science['job_record_complete'] is True and science['resource_admitted'] is False
assert science['inputs']==document and science['limits']==plan['experiment_limits'] and science['native_records']==queries
assert science['format_check']['complete'] is True and science['format_check']['phase']=='training'
assert science['format_check']['statement_ids']==[v['id'] for v in document['training']]
assert all(v['structure']['category']=='ACYCLIC_SINGLE_PRODUCER' for v in science['format_check']['input_structures'])

# Fresh, complete direct predecessor evidence: no old run or shorter inventory.
receipts=[]; exports=[]; upstream_pins=[]
for i,p in enumerate(plan['upstream_receipts']):
 verify(p); seal=load(p['path']); admission_pin=pin(R/'admission'/('acquire-'+str(i)+'-v1.json')); admission=load(admission_pin['path'])
 assert seal['stage_id']==admission['stage_id']=='acquire-'+str(i) and seal['stage']==admission['stage']=='acquire'
 assert admission['seal']==p and admission['protocol']==plan['protocol'] and admission['prior_admissions']==[]
 assert all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete'))
 assert len(seal)==13 and seal['prior_cost_receipts']==[] and seal['resource_admitted'] is seal['stage_complete'] is True
 for key in components: verify(seal[key]); assert seal[key]==admission[key]
 prior=load(seal['result']['path']); pr=load(admission['C_actual_review']['path']); verify(admission['C_actual_review'])
 assert pr['review_passed'] is pr['resource_admitted'] is pr['scientific_qualified'] is pr['stage_complete'] is True
 assert all(pr[k]==seal[k] for k in components) and prior['scientific_result']['stage_complete'] is True
 exported=prior['scientific_result']['export']; assert exported['qualified'] is True and digest(exported)==seal['export_sha256']==pr['export_sha256']
 assert seal['whole_seconds']==load(seal['observer']['path'])['elapsed_seconds']==pr['whole_seconds']
 receipts.append(seal); exports.append(exported); upstream_pins.extend([admission_pin,p,admission['C_actual_review']])
costs=science['cumulative_costs']; prior_seconds=0.0
for receipt in receipts: prior_seconds+=receipt['whole_seconds']
assert same(costs['receipts'],receipts) and costs['stage_ids']==['acquire-0','acquire-1'] and same(costs['whole_seconds'],prior_seconds)
assert costs['maximum_prior_whole_peak_bytes']==max(v['whole_peak_bytes'] for v in receipts) and costs['current_whole_seconds'] is None
assert same(costs['current_entry_seconds'],science['seconds']) and same(costs['upstream_plus_current_entry_seconds'],prior_seconds+science['seconds'])
acq=science['acquisition_check']; assert acq['complete'] is True and len(acq['donor_exports'])==2
certificates=[cert for exported in exports for cert in exported['certificates']]
for i,(old,check) in enumerate(zip(exports,acq['donor_exports'],strict=True)):
 assert check['complete'] is check['qualified'] is True and check['donors']==1 and check['certificates']==4 and check['pairing']==old['pairing']
 source_queries=load(receipts[i]['result']['path'])['native_queries']
 for evidence in check['Native_evidence']:
  q=source_queries[evidence['query']]
  assert q['result']['status']=='accepted' and q['request_sha256']==evidence['request_sha256'] and digest(q['result'])==evidence['result_sha256']
 assert {r['query'] for r in check['Native_evidence']}=={45,46,47,48,49}
groups={}
for ordinal,cert in enumerate(certificates): groups.setdefault(cert['families']['atom']['id'],[]).append(ordinal)
pairing=acq['pairing']; assert pairing['no_principal_coalescence'] is True and pairing['raw_certificates']==8 and pairing['paired_units']==5 and pairing['principal_structures']==4
assert len(pairing['units'])==len(groups)==len(science['library'])==5 and science['library']==acq['libraries']['principal']
for unit in pairing['units']:
 uid=unit['paired_unit_id']; indices=groups[uid]; assert [m['certificate_ordinal'] for m in unit['members']]==indices
 for mode in ('atom','principal'):
  wrapper=next(v for v in acq['libraries'][mode] if v['id']==uid); origin=indices[0]; inner=certificates[origin]['families'][mode]
  assert wrapper['structural_family']==inner and wrapper['source_certificate_ordinal']==origin and wrapper['paired_unit_id']==uid and wrapper['structural_id']==inner['id']
  assert all(wrapper[k]==(uid if k=='id' else v) for k,v in inner.items()) and unit['wrapper_checks'][mode]['complete'] is True
assert len({f['structural_id'] for f in science['library']})==4
library_ids={f['id'] for f in science['library']}

# Full current control populations; arithmetic/reference correctness is not replayed.
BANKS={'numeric':23,'word':48,'graph':22,'encoding':40,'principal':53,'matched_symbolic':13,'conditional_numeric':57,'conditional_semantic':18,'conditional_corpus':31}
control_IDs={}
for name,count in BANKS.items():
 bank=science['controls'][name]; rows=bank['controls']; assert bank['complete'] is True and len(rows)==count and len({v['id'] for v in rows})==count
 assert all(v.get('passed') is True or v.get('status')=='PASSED' for v in rows); control_IDs[name]=[v['id'] for v in rows]
assert sum(BANKS.values())==305 and science['controls']['conditional_corpus_status']=='COMPLETE_TRAINING_ONLY_CONTROLS'
assert all(science['controls'][name] is None for name in ('corpus','native_batch','guard_resolver','guard_differential','reference_setup_calibration'))
inherited=science['controls']['inherited']; assert inherited['base_solutions']==inherited['marked_solutions'] and len(inherited['full_domain_audits'])==9
assert inherited['callback_identity_propagated'] is inherited['global_dead_forced_generation_controls'] is inherited['incomplete_certificate_rejected'] is True

used_native=set(); guard_count=0
def owned(q): assert q==queries[q['id']]; used_native.add(q['id']); return q['id']
def accepted(q,spec,proof):
 owned(q); assert q['result']['status']=='accepted' and q['request']==dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=[],proof=proof,target=spec['target'])
def guard_ledger(e):
 assert e['complete'] is True and e['status']=='complete' and e['active_query'] is None and type(e['unresolved']) is int and e['unresolved']==0 and e['resolved']==len(e['members'])
 for q in e['query_records']: owned(q)
 for batch in e['batches']:
  q=queries[batch['query_id']]; assert q==e['query_records'][batch['query_record_ordinal']] and batch['status']==q['result']['status']
  assert q['request']['proof']==[m['command'] for m in e['members'][batch['start']:batch['stop']]] and q['request']['target']==q['request']['proof'][-1]['formula']
  if batch['status']=='rejected' and batch['stop']-batch['start']>1:
   children=[b for b in e['batches'] if b['parent']==batch['index']]; assert len(children)==2 and children[0]['start']==batch['start'] and children[0]['stop']==children[1]['start'] and children[1]['stop']==batch['stop']
 for ordinal,m in enumerate(e['members']):
  q=queries[m['native_query']]; assert m['ordinal']==ordinal and q['request']['proof'][m['native_row']]==m['command'] and m['status']==q['result']['status']
  assert m['command']['rule'] in ('tautology','instantiate','eq_subst')
  if m['status']=='rejected': assert m['resolution_kind']=='singleton_rejection' and len(q['request']['proof'])==1
assert len(worker['guard_compilations'])==2
for ledger in worker['guard_compilations']: guard_ledger(ledger); guard_count+=len(ledger['members'])

# The following is only a literal stack/catalog projection of saved events.
# It does not call or simulate the scientific State, Graph, guards or checker.
snapshot_keys=[]
for s in worker['work_snapshots']:
 assert set(s)=={'callbacks','elapsed_seconds'} and type(s['callbacks']) is int and type(s['elapsed_seconds']) is float and math.isfinite(s['elapsed_seconds'])
 assert 0<=s['callbacks']<=worker['callbacks'] and 0<=s['elapsed_seconds']<=worker['elapsed_seconds']
 snapshot_keys.append((s['callbacks'],s['elapsed_seconds'].hex()))
assert len(snapshot_keys)==len(set(snapshot_keys))==475 and all(a[0]<b[0] and a[1]!=b[1] for a,b in zip(snapshot_keys,snapshot_keys[1:]))
snapshot_cursor=0; episode_rows=[]; raw_pool_count=raw_packet_count=group_count=0; all_orders=0; unfinished=[]
def consume(sample):
 global snapshot_cursor
 assert (sample['callbacks'],sample['elapsed_seconds'].hex())==snapshot_keys[snapshot_cursor]
 ordinal=snapshot_cursor; snapshot_cursor+=1; return ordinal
def four_tiers(keys,prefix,command_of,preferred):
 tiers=[[],[],[],[]]; formulas=[c['formula'] for c in prefix]
 for key in keys: tiers[2*int(command_of(key)['formula'] in formulas)+int(key not in preferred)].append(key)
 return [key for tier in tiers for key in tier]

def episode_join(case,record):
 global raw_pool_count,raw_packet_count,group_count,all_orders
 spec=case['spec']; model=case['model']; domains=model['domains']; engine=record['engine']; sr=record['search']; trace=sr['trace']; decisions=sr['selector_decisions']
 stack=[]; contexts={}; placements={tuple(p['key']):p for p in model['placements']}; ordered_count=0; current_prefix={}
 for index,event in enumerate(trace):
  kind=event['event']
  if kind=='decision':
   if engine=='symbolic':
    prefix=[domains[row][key[0]] for row,key in enumerate(stack)]; assert event['row']==len(prefix) and type(event['ordering_complete']) is bool
    if event['ordering_complete']:
     old=event['original_candidates']; new=event['ordered_candidates']; assert sorted(old)==sorted(new)
     preferred=[key for key in old if domains[len(prefix)][key[0]]==event['preferred_command']]
     assert new==four_tiers(old,prefix,lambda key:domains[len(prefix)][key[0]],preferred); ordered_count+=1
    else:
     assert event['ordered_candidates'] is None and sr['status']=='unknown_search_budget' and trace[-1]['event']=='cutoff'
     assert not any(e['event'] in ('decision','extend') for e in trace[index+1:])
     unfinished.append(dict(global_ordinal=record['descriptor']['global_ordinal'],trace_index=index,row=event['row'],proposal_present=event['proposal'] is not None,original_candidate_count=len(event['original_candidates'])))
   else:
    prefix=[]
    for row in range(len(domains)):
     ck=[k for k in stack if k[0]==row and k[1]==0]; gk=[k for k in stack if k[0]==row and k[1]==1]
     if not ck or not gk: break
     assert len(ck)==len(gk)==1 and ck[0][2]==gk[0][2]; prefix.append(domains[row][ck[0][2]])
    assert event['ordinal']==index and event['kind'] in ('branch','forced','dead','empty')
    if event['kind']=='forced': assert len(event['original_alternatives'])==1
   contexts[index]=dict(prefix=prefix,event=event)
  elif kind=='order':
   ctx=contexts[event['decision']]; old=ctx['event']['original_alternatives']; new=event['alternatives']; prefix=ctx['prefix']
   assert engine=='point' and sorted(old)==sorted(new)
   expected=old if ctx['event']['kind']=='forced' else four_tiers(old,prefix,lambda k:domains[k[0]][k[2]],event['preferred'])
   assert new==expected; ordered_count+=1
  elif kind=='extend':
   node=trace[event['decision']]; assert engine=='symbolic' and node['event']=='decision' and node['ordering_complete'] is True and node['row']==len(stack)
   assert [event['skeleton'],event['variant']] in node['ordered_candidates']; stack.append([event['skeleton'],event['variant']])
  elif kind=='place':
   assert engine=='point' and tuple(event['key']) in placements; stack.append(event['key'])
  elif kind=='return':
   assert stack; key=stack.pop(); assert (key==event['key'] if engine=='point' else key[0]==event['skeleton'])
 assert sr['root_restored'] is True
 if sr['status']!='unknown_search_budget': assert stack==[]
 assert sr['metrics']['attempts']==sum(e['event']==('place' if engine=='point' else 'extend') for e in trace)<=600
 all_orders+=ordered_count; consumed_continuations=set(); joined=[]
 for ordinal,decision in enumerate(decisions):
  assert type(decision['ordinal']) is int and decision['ordinal']==ordinal; snapshot_index=consume(decision['snapshot'])
  node=decision['context']['trace_decision']; ctx=contexts[node]; prefix=ctx['prefix']; event=ctx['event']; action=decision['action']
  assert decision['context']['engine']==engine and decision['context']['prefix']==prefix and decision['attempts']<=sr['metrics']['attempts']
  dimension=8 if decision['head']=='gate' else 12; typed_vector(action['weights'],dimension)
  assert action['mode']=='learned' and number(action['draw']) and 0<=action['draw']<1 and type(action['choice']) is int
  assert len(action['features'])==len(action['probabilities']) and 0<=action['choice']<len(action['features'])
  assert all(number(p) and 0<=p<=1 for p in action['probabilities'])
  for vector in action['features']: typed_vector(vector,dimension)
  if decision['head']=='continuation': assert ordinal in consumed_continuations; continue
  assert decision['head']=='gate' and decision['pool_ordinal'] is None and action['features']==[decision['context']['gate_features'],[0.0]*8]
  old=event['original_candidates'] if engine=='symbolic' else event['original_alternatives']
  assert decision['context']['original_candidate_count']==len(old) and decision['context']['selected_point']==(None if engine=='symbolic' else event['point'])
  if engine=='symbolic': proposal=event['proposal']
  else:
   ps=[e['proposal'] for e in trace if e['event']=='conditional_proposal' and e['decision']==node]; assert len(ps)<=1; proposal=ps[0] if ps else None
  if proposal is None:
   assert ordinal==len(decisions)-1 and action['choice']==0 and sr['status']=='unknown_search_budget' and trace[-1]['event']=='cutoff'
   joined.append(dict(gate=ordinal,trace_index=node,status='INTERRUPTED_POOL_NOT_RETURNED')); continue
  assert proposal['gate_decision']==ordinal
  if action['choice']==1:
   assert proposal['status']=='POOL_NOT_REQUESTED_GATE_ABSTAIN' and proposal['pool'] is proposal['grouping'] is proposal['continuation_decision'] is None
   joined.append(dict(gate=ordinal,trace_index=node,status=proposal['status'])); continue
  continuation_index=proposal['continuation_decision']; assert continuation_index==ordinal+1 and continuation_index<len(decisions)
  continuation=decisions[continuation_index]; assert continuation['head']=='continuation' and continuation['context']['trace_decision']==node
  assert continuation['context']['gate_decision']==ordinal and continuation['context']['prefix']==prefix
  assert continuation['pool_ordinal']==sum(d['head']=='continuation' for d in decisions[:ordinal]); consumed_continuations.add(continuation_index)
  pool=proposal['pool']; grouping=proposal['grouping']; assert proposal['status']=='COMPLETE_DECLARED_BOUNDED_POOL'
  assert pool['complete'] is True and pool['termination'] in ('declared_occurrences_exhausted','packet_quota','work_prefix')
  assert same(grouping,continuation['context']['grouping']) and same(grouping['features'],continuation['action']['features'])
  packets=pool['packets']; groups=grouping['groups']; aliases=[]; signatures=set()
  assert len(packets)<=16 and grouping['abstain_index']==len(groups) and len(grouping['features'])==len(groups)+1
  for group in groups:
   indices=group['raw_packet_ordinals']; aliases.extend(indices); assert group['representative_packet_ordinal'] in indices
   representative=packets[group['representative_packet_ordinal']]; signature=wire([representative['members'],representative['commands']]); assert signature not in signatures; signatures.add(signature)
   for raw in indices: assert type(raw) is int and 0<=raw<len(packets) and wire([packets[raw]['members'],packets[raw]['commands']])==signature
   assert group['minimum_incremental_validation_checks']==min(packets[raw]['incremental_validation_checks'] for raw in indices)
  assert sorted(aliases)==list(range(len(packets))) and grouping['raw_packet_count']==len(packets) and grouping['executable_continuation_count']==len(groups)
  for packet in packets:
   commands=packet['commands']; assert packet['family'] in library_ids and commands and packet['prefix_rows']==len(prefix)
   assert packet['checked_primitive_proof']==prefix+commands and packet['host_check']['accepted'] is True
   assert packet['host_check']['rows']==len(prefix)+len(commands) and packet['host_check']['target']==packet['result_formula']
   assert len(packet['members'])==2*len(commands)
   for offset,command in enumerate(commands):
    ck,gk=packet['members'][2*offset:2*offset+2]; row=len(prefix)+offset
    assert ck[:2]==[row,0] and gk[:2]==[row,1] and ck[2]==gk[2] and domains[row][ck[2]]==command
    assert tuple(ck) in placements and tuple(gk) in placements
   for source in packet['source_binding']:
    assert (source['formula']==prefix[source['row']]['formula'] and 0<=source['row']<len(prefix)) if source['kind']=='prefix' else (source['kind']=='axiom' and source['formula']==spec['theory']['axioms'][source['name']])
  choice=continuation['action']['choice']; assert 0<=choice<=len(groups) and proposal['selected_group']==(choice if choice<len(groups) else None)
  raw_pool_count+=1; raw_packet_count+=len(packets); group_count+=len(groups)
  joined.append(dict(gate=ordinal,trace_index=node,status=proposal['status'],raw_packets=len(packets),groups=len(groups),selected_group=proposal['selected_group'],snapshot_index=snapshot_index))
 terminal_snapshot_index=consume(record['terminal_snapshot'])
 assert record['execution_status']=='SEARCH_RETURNED' and record['selection']=='learned'
 assert record['certified_markings'] is (engine=='point') and record['problem_defining_word_structure_marks'] is True
 assert record['cluster_ordering'] is True and sr['cluster_ordering'] is True
 if engine=='point':
  assert len(sr['domain_audits'])==2 and all(a['complete'] is True for a in sr['domain_audits'])
  ds=[e for e in trace if e['event']=='decision'][:2]
  for audit,event in zip(sr['domain_audits'],ds,strict=True): assert audit['decision']==[event['kind'],event['point'],event['original_alternatives']]
 pc=record['proof_check']; proof=sr['proof']
 if proof is None:
  assert sr['status']=='unknown_search_budget' and pc['status']=='NO_PROOF_CANDIDATE' and pc['native_proof_accepted'] is False
  assert pc['host_check'] is pc['region'] is pc['native_record'] is None and sr['placements']==[]
 else:
  assert pc['status']=='HOST_REGION_NATIVE_ACCEPTED' and pc['host_check']['accepted'] is pc['native_proof_accepted'] is pc['region']['complete'] is True
  assert len(proof)==spec['length']==pc['host_check']['rows']==pc['region']['decoded_rows']
  assert pc['host_check']['target']==spec['target'] and pc['region']['required_points']==pc['region']['selected_placements']==2*len(proof)
  assert pc['native_limit']==1000000000; accepted(pc['native_record'],spec,proof)
  assert len(sr['placements'])==2*len(proof) and len({tuple(k) for k in sr['placements']})==len(sr['placements'])
  command_keys={k[0]:k for k in sr['placements'] if k[1]==0}; guard_keys={k[0]:k for k in sr['placements'] if k[1]==1}
  for row,command in enumerate(proof):
   ck,gk=command_keys[row],guard_keys[row]; assert ck[2]==gk[2] and domains[row][ck[2]]==command and tuple(ck) in placements and tuple(gk) in placements
 episode=record['episode']; assert episode['decisions']==decisions
 assert episode['terminal']==dict(snapshot=record['terminal_snapshot'],attempts=sr['metrics']['attempts'],native_proof_accepted=pc['native_proof_accepted'],proof_status=pc['status'],search_status=sr['status'])
 for field in ('engine','index','global_ordinal','problem_id','seed'): assert episode[field]==record['descriptor'][field]
 update=record['policy_update']; assert update['episode']==episode and len(update['decision_returns'])==len(decisions)
 for d,r in zip(decisions,update['decision_returns'],strict=True):
  assert r['ordinal']==d['ordinal'] and r['head']==d['head'] and r['preupdate_baseline']==update['heads'][d['head']]['preupdate']['baseline']
  assert r['components']['native_acceptance']==float(pc['native_proof_accepted']) and all(number(v) for v in r['components'].values())
  assert all(r['components'][name]>=0 for name in ('remaining_attempts','remaining_callbacks','remaining_elapsed'))
  typed_vector(r['score_gradient'],8 if d['head']=='gate' else 12)
  assert number(r['advantage']) and number(r['return_to_go'])
 return dict(descriptor=record['descriptor'],search_status=sr['status'],proof_status=pc['status'],proof_rows=0 if proof is None else len(proof),native_query=None if pc['native_record'] is None else pc['native_record']['id'],attempts=sr['metrics']['attempts'],attempt_unit=sr['attempt_unit'],decisions=len(decisions),gate_decisions=sum(d['head']=='gate' for d in decisions),continuation_decisions=sum(d['head']=='continuation' for d in decisions),ordered_candidate_lists=ordered_count,terminal_snapshot_index=terminal_snapshot_index,trace_sha256=digest(trace),decisions_sha256=digest(decisions),pool_joins=joined)

assert len(science['records'])==2 and len(science['episode_bindings'])==4 and science['prior_policy_check'] is None
for case_index,case in enumerate(science['records']):
 assert case['spec']==document['training'][case_index] and len(case['episodes'])==2
 model=case['model']; spec=case['spec']; reference=case['reference_check']; word_check=case['word_model_check']; guard_check=case['guard_acquisition_check']
 assert reference['complete'] is word_check['complete'] is guard_check['complete'] is True
 assert case['compiler']['guard_evidence']==worker['guard_compilations'][case_index]
 assert case['word_reference_differential']['performed_on_this_model'] is False
 assert model['word_terminator']==256 and model['arity']==0 and model['mode_ids']=={} and len(model['domains'])==spec['length']
 assert len(set(model['word_dictionary']))==len(model['word_dictionary'])==word_check['dictionary_words']==reference['distinct_complete_words']
 assert model['word_dictionary'][0]==wire(spec['target']).hex() and [[4*(spec['length']-1),100],0] in model['initial']['marks']
 assert len(model['placements'])==word_check['placements']==reference['accepted_placements']
 marking=case['marking']; assert marking['marking_certificate_check']['complete'] is marking['marked_extension_check']['complete'] is True
 assert len(marking['markings']['certificates'])==marking['marking_certificate_check']['certificates']==12
 assert marking['marked_extension_check']['auxiliary_points']==12 and marking['marked_extension_check']['changed_placements']==12
 assert all(number(marking[k]) and marking[k]>=0 for k in ('construction_seconds','certificate_verification_seconds','overlay_construction_seconds','extension_verification_seconds','seconds'))
 for offset,record in enumerate(case['episodes']):
  global_index=2*case_index+offset; expected=descriptor['episodes'][global_index]
  assert record['descriptor']==expected and record['engine']==('symbolic','point')[offset]
  episode_rows.append(episode_join(case,record))
  binding=science['episode_bindings'][global_index]
  assert all(binding[k]==expected[k] for k in ('engine','index','global_ordinal','problem_id','seed')) and binding['stage_id']=='train-0'
  for key,value in (('episode_sha256',record['episode']),('search_sha256',record['search']),('proof_check_sha256',record['proof_check']),('selector_decisions_sha256',record['episode']['decisions']),('record_sha256',record)):
   assert binding[key]==digest(value)
  assert binding['provenance_scope']=='ROOT_ADMITTED_ACTUAL_STAGE_RECORD'
assert snapshot_cursor==len(snapshot_keys) and used_native==set(range(27))
assert len(unfinished)==1 and unfinished[0]['global_ordinal']==2 and unfinished[0]['proposal_present'] is False and unfinished[0]['original_candidate_count']==0
for engine in ('symbolic','point'):
 policy=science['policies'][engine]; assert policy['engine']==engine and policy['episodes']==len(policy['history'])==2
 check=science['policy_checks'][engine]; assert check['complete'] is True and check['episodes']==2
 heads={head:dict(weights=[0.0]*dimension,baseline=0.0) for head,dimension in (('gate',8),('continuation',12))}
 actual_records=[case['episodes'][0 if engine=='symbolic' else 1] for case in science['records']]
 for index,(update,record) in enumerate(zip(policy['history'],actual_records,strict=True)):
  assert update==record['policy_update'] and update['episode']['index']==index
  for head,dimension in (('gate',8),('continuation',12)):
   h=update['heads'][head]; assert same(h['preupdate'],heads[head]) and h['decisions']==sum(d['head']==head for d in update['episode']['decisions'])
   for d in update['episode']['decisions']:
    if d['head']==head: assert same(d['action']['weights'],heads[head]['weights'])
   typed_vector(h['postupdate']['weights'],dimension); typed_vector(h['summed_advantage_gradient'],dimension)
   assert number(h['postupdate']['baseline'])
  heads={head:update['heads'][head]['postupdate'] for head in ('gate','continuation')}
 assert same(heads,policy['heads']) and check['decisions']==sum(len(v['episode']['decisions']) for v in actual_records)
exported=science['export']; assert exported['qualified'] is True and exported['stage']=='train' and exported['stage_id']=='train-0'
assert exported['training_document']==document and exported['training_document_sha256']==digest(document)
assert exported['policies']==science['policies'] and exported['episode_bindings']==science['episode_bindings'] and exported['cost_receipts']==receipts
assert exported['library_sha256']==digest(science['library']) and exported['acquisition_exports']==[digest(v) for v in exports] and exported['prior_policy_export_sha256'] is None
assert sum(r['proof_rows']>0 for r in episode_rows)==3 and sum(r['search_status']=='unknown_search_budget' for r in episode_rows)==1
checks=[
 dict(id='once-current-61-guards-and-complete-custody',passed=True,finding='Exact prospective plan, one-use Root grant/consumption, current61 Source/input/upstream guards, owned child group and complete terminal/header/log/observer14-file census all join. No Source change, Root fault, close error, partial or retry evidence.'),
 dict(id='original-resource-and-nonoverlapping-cost-authorities',passed=True,finding='Original160/180/210/225,1GiB/128MiB/48MiB/4MiB gates and both9MiB reserves retained. Final conservative peak reconciles waited/post-output Python, Native, parent and observer. Current whole cost uses observer sample; two direct acquisition samples are accumulated once in their Source order, not Python sum(). Nested entry/search/final/setup clocks are not added as disjoint costs.'),
 dict(id='fresh-both-donor-library-reconstruction',passed=True,finding='Both exact current Root admissions/seals/C reviews and full exported Native proof evidence join. All8 certificate occurrences yield5 shared atom-class units and4 principal structural IDs; principal coalescence is not used. Fresh in-actual Host/ancestry/production+independent typing/wrapper receipts and literal library forwarding remain complete. Native certificates are reused only from these admitted fresh acquisitions, never relabeled as fresh current requests.'),
 dict(id='all-current-controls-and-production-models',passed=True,finding='All305 named current training controls across9banks and separate inherited9 domain audits are complete/passed. Acquisition-only Native/resolver/differential banks correctly remain unrequested. Both production models have completev3 reference, exact indexed words/ID0/terminator256, guard evidence and12 soundness-owned auxiliary certificates each. This is finite aligned word/point semantics, not universal physical Wang support.'),
 dict(id='owned-Native-stream-and-all-final-proof-gates',passed=True,finding='All27 current Native starts/records/stages/request digests/program output identities and budgets join:5accepted(2 theory admissions+3final proofs),22expected compiler rejections,0UNKNOWN. Both complete compiler member/range/singleton maps and all3fresh final Host/full finite-region/Native blocks=[] proofs cover the entire owned stream. The other episode is bounded local symbolic UNKNOWN with no proof candidate; whole stage remains complete.'),
 dict(id='all-live-decisions-pools-tiers-and-snapshots',passed=True,finding='Every471 gate/continuation decision and4terminal samples consume all475 genuine Root snapshot copies in order. All completed raw pools, exact executable grouping/aliases/guard variants, actual prefix/axiom receptors, original catalog command/guard members, context Host receipts and saved choices join. Candidate lists preserve full multiplicity and stable novelty-first tiers; point forced lists remain exact. No Graph, State, guard, feature-rank, RNG or numeric policy replay was run.'),
 dict(id='unfinished-symbolic-suffix-and-rollback',passed=True,finding='Exactly one unfinished symbolic decision follows297 extensions in episode2 at trace881,row10. Its original candidates are empty and proposal isNone; there is no selector action tied to this carrier or later extension. The final owned local cutoff and root-restored Source receipt are retained. Other three traces unwind their literal stacks fully; both point episodes have the first2complete domain/scheduler audits. No whole-failure prefix salvage or unlogged pool/action fabrication.'),
 dict(id='four-prescribed-episodes-history-update-and-export',passed=True,finding='Manifest cases0/1 run symbolic then point with global ordinals0..3 and prescribed seeds0/10000/1/10001. Each separate engine starts zero8/12 heads, records two actual episodes, retains exact pre/post update and per-head EMA continuity, terminal work/acceptance provenance, full record/search/decision hashes and final qualified policy bundle. In-actual independent57numeric and18semantic controls plus policy checks own arithmetic/RNG verification; C compares the saved carriers without replay. Three accepted proof occurrences and one unsolved observation do not establish useful learning, advantage, held-out performance or a new theorem.')]
review=dict(schema='D21-C-conditional-stage-actual-review-v1',stage_id='train-0',stage='train',review_passed=True,resource_admitted=True,scientific_qualified=True,stage_complete=True,**components,protocol=plan['protocol'],export_sha256=digest(exported),input_pins=sorted(plan['files'],key=lambda p:p['path']),complete_actual_file_census=census,partial_files_parsed=0,Root_admission_issued=False,whole_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],grant=offer['grant'],consumed=pin(actual/'CONSUMED.json'),owned_child=pin(actual/'owned-child.json'),serial_barrier=offer['barrier'],actual_offer=offer_pin,prospective_review=offer['prospective_review'],upstream_external_review_pins=upstream_pins,checks=checks,failures=[],episode_literal_joins=episode_rows,unfinished_carriers=unfinished,counts=dict(cases=2,prescribed_episodes=4,accepted_final_proofs=3,accepted_proof_rows=29,bounded_UNKNOWN_episodes=1,selector_decisions=471,Root_snapshots=475,complete_raw_pools=raw_pool_count,raw_packets=raw_packet_count,executable_groups=group_count,ordered_candidate_lists=all_orders,named_control_rows=305,inherited_domain_audits=9,point_domain_audits=4,marking_certificates=24,Native_requests=27,Native_accepted=5,Native_rejected=22,Native_UNKNOWN=0,guard_compilations=2,guard_members=guard_count,library_units=5,principal_structures=4,engine_policy_exports=2),bank_counts=BANKS,bank_ID_sequences_sha256=digest(control_IDs),costs=dict(observer_sample_seconds=observer['elapsed_seconds'],observer_final_gate_seconds=observer['final_observer_gate_seconds'],worker_seconds=worker['elapsed_seconds'],entry_seconds=science['seconds'],physical_postterminal_bytes=physical,python_peak_with_postoutput_and_waited_child=python_peak,Native_peak=worker['native_peak_bytes'],parent_peak=terminal['parent_usage']['ru_maxrss'],observer_peak=observer['final_observer_peak_bytes'],each_output_reserve=9437184,direct_upstream_observer_seconds=prior_seconds,current_plus_unique_upstream_observer_seconds=prior_seconds+observer['elapsed_seconds'],scope='Unique direct actual samples once; nested clocks overlap. Return-to-go proxy ends after final proof checks and excludes later update/export/output/custody only from the reward proxy, while all remain charged in complete whole-job costs.'),scope='Independent passive raw Source/current complete saved JSON/owned evidence review only. No scientific, checker, compiler, Graph/State, ancestor, miner/unifier, control, feature, numeric/RNG or helper replay/import. C issues no Root admission, seal, grant, future plan authority, performance or learning-benefit claim.',scientific_imports=0,scientific_calls=0,helper_invocations=0,subject_replays=0,grants_issued=0,tools_idle_after_freeze=True,review_program=pin(Path(__file__).resolve()))
for v in list(SEEN.values()): assert pin(v['path'])==v
out=C/'typed-first-training-actual-review-v1.json'
with out.open('xb') as f: f.write((json.dumps(review,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps(pin(out)))
