"""C-owned raw/complete-JSON request review; never imports or invokes subject code."""
import copy
import hashlib
import json
from pathlib import Path
from collections import Counter

STUDY = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-conditional-selector-main-20261021')
ROOT = STUDY/'root'
OUT = STUDY/'review-C/typed-open-third-training-population-reader-request-review-v1.json'
checked = {}
def wire(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def need(v, msg):
    if not v: raise ValueError(msg)
def pin(p):
    p = Path(p)
    need(p.is_absolute() and p.resolve()==p and not p.is_symlink() and p.is_file(), 'ordinary canonical file')
    need('.partial' not in p.name, 'no partial intake')
    b=p.read_bytes()
    q=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    if str(p) in checked: need(checked[str(p)]==q,'stable repeated pin')
    checked[str(p)]=q
    return q
def verify(q):
    need(type(q) is dict and set(q)=={'path','bytes','sha256'},'exact pin carrier')
    need(type(q['bytes']) is int and q['bytes']>=0 and pin(q['path'])==q,'current raw pin')
    return q
def unique(rows):
    d={}
    for k,v in rows:
        need(k not in d,'duplicate JSON key');d[k]=v
    return d
def load(q):
    if isinstance(q,(str,Path)): q=pin(q)
    verify(q)
    return json.loads(Path(q['path']).read_bytes(),object_pairs_hook=unique,parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)))
def same(a,b): return wire(a)==wire(b)
def passed(r):
    need(r['review_passed'] is True and r['failures']==[] and r['checks'] and all(c['passed'] is True for c in r['checks']), 'complete prior C PASS')

request_pin=pin(ROOT/'conditional-main-reader-request-v3.json')
state_pin=pin(ROOT/'conditional-main-report-state-v3.json')
need(request_pin['bytes']==938 and request_pin['sha256']=='868624dd9d0fd81b2e3f2c158ba057fc5a878444710bbdbbba3da866bd3b0b78','offered request')
need(state_pin['bytes']==11107 and state_pin['sha256']=='3e812c63d527ebd5f19bbe35d09124cffb8e10a188b86e8e79208030c7dbff68','offered state')
request=load(request_pin); state=load(state_pin)
need(set(request)=={'schema','report_version','protocol','population','template'} and request['schema']=='D21-passive-main-reader-request-v3' and type(request['report_version']) is int and request['report_version']==3,'exact N3 request')
need(request['population']==state_pin and state['schema']=='D21-Root-main-report-state-v3' and type(state['report_version']) is int and state['report_version']==3 and state['closed'] is False and state['C_review'] is None,'open same-N state')
protocol_pin=verify(request['protocol']); protocol=load(protocol_pin)
need(protocol_pin['sha256']=='c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422' and state['protocol']==protocol_pin,'fixed exact protocol')
source_review_pin=pin(STUDY/'review-C/typed-reusable-compact-reader-Source-review-v4.json')
need(source_review_pin['sha256']=='d24c1c62b7725012f367af0cfb41a470306a30dd234aac141b6ce8ce53f3b4af','current Source PASS')
source_review=load(source_review_pin);passed(source_review)
source_pin=pin(STUDY/'diagnostics-L/project_conditional_main_reader_v4.py')
api_pin=pin(STUDY/'diagnostics-L/reader-API-v4.json')
template_pin=verify(request['template'])
need(source_pin['sha256']=='81838f929750cc78f5a3b5f9562f83449fdfa21d6459f855a91c37eb2f3c9da9' and api_pin['sha256']=='21f4278959f8698adfdaf983c1cf0255bdfc054e785582ce8043c368cf306e51' and template_pin['sha256']=='80ac1e2822809a6b6a99f27e0780f60c96bac9126cffedc91ed6eb3bffd5a122','reviewed v4 bodies')
for q in protocol['phase_inputs'].values():load(q)
recipes=protocol['job_recipes'];need(len(recipes)==34 and len(state['jobs'])==34,'full recipe count')
need([x['stage_id'] for x in recipes]==[x['stage_id'] for x in state['jobs']],'full original recipe order')
need(len({x['stage_id'] for x in state['jobs']})==34,'unique rows')
status=Counter(x['status'] for x in state['jobs']);need(status=={'QUALIFIED':5,'PENDING':29},'five qualified29pending')
current=[];proofs=[];episodes=[];bundles=[];previous_policies=None;total_seconds=0.0
seal_fields={'stage_id','stage','resource_admitted','stage_complete','plan','result','header','terminal','observer','export_sha256','whole_seconds','whole_peak_bytes','prior_cost_receipts'}
for i,(recipe,row) in enumerate(zip(recipes,state['jobs'],strict=True)):
    identity=recipe['stage_id']
    need(row['stage']==recipe['stage'] and row['blocking_stage_ids']==[] and isinstance(row['reason'],str) and row['reason'],'state identity/reason')
    if i>=5:
        need(row['status']=='PENDING' and row['admission'] is None,'no later admission')
        need(not (STUDY/'actual'/identity).exists() and not (STUDY/'actual'/(identity+'.observer')).exists(),'pending actuals remain absent')
        continue
    need(row['status']=='QUALIFIED','current five positive')
    admission=load(row['admission']);seal_pin=pin(ROOT/'seals'/(identity+'-v1.json'));seal=load(seal_pin)
    need(admission['schema']=='D21-Root-conditional-stage-admission-v1' and admission['stage_id']==identity and admission['stage']==recipe['stage'] and admission['protocol']==protocol_pin,'current Root identity')
    need(all(admission[k] is True for k in ('admitted','resource_admitted','scientific_qualified','stage_complete')),'four literal Root gates')
    need(set(seal)==seal_fields and seal['stage_id']==identity and seal['stage']==recipe['stage'] and seal['resource_admitted'] is True and seal['stage_complete'] is True and seal['prior_cost_receipts']==[],'strict direct13fieldseal')
    for k in seal_fields-{'prior_cost_receipts'}:need(same(seal[k],admission[k]),'same seal/admission direct field '+k)
    plan=load(admission['plan']);need(plan['case_id']==identity and plan['stage']==recipe['stage'] and same(plan['Root_recipe'],recipe) and plan['protocol']==protocol_pin,'exact current plan/recipe')
    review=load(admission['C_actual_review']);passed(review)
    need(review['schema']=='D21-C-conditional-stage-actual-review-v1' and review['Root_admission_issued'] is False and type(review['partial_files_parsed']) is int and review['partial_files_parsed']==0,'independent current C scope')
    for k in ('plan','result','header','terminal','observer'):
        verify(admission[k]);need(review[k]==admission[k],'C/admission component equality '+k)
    need(all(review[k] is True for k in ('resource_admitted','scientific_qualified','stage_complete')),'independent stage gates')
    need(same(review['input_pins'],sorted(plan['files'],key=lambda q:q['path'])),'C exact guard set')
    for q in plan['files']:verify(q)
    census=review['complete_actual_file_census']
    for q in census:verify(q)
    actual_paths=sorted(str(p) for root in (STUDY/'actual'/identity,STUDY/'actual'/(identity+'.observer')) for p in root.rglob('*') if p.is_file())
    need(sorted(q['path'] for q in census)==actual_paths and len(census)==14,'current complete14census')
    need(admission['complete_actual_file_census']==census,'Root exact census')
    packet=load(admission['result']);science=packet['scientific_result'];observer=load(admission['observer'])
    need(packet['status']=='COMPLETE' and packet['error'] is None and packet['source_unchanged'] is True and science['stage_id']==identity and science['stage_complete'] is True and science['job_record_complete'] is True,'complete current science')
    need(same(science['native_records'],packet['native_queries']),'owned complete current Native stream')
    need(hashlib.sha256(wire(science['export'])).hexdigest()==admission['export_sha256']==review['export_sha256'],'canonical admitted export')
    need(admission['whole_seconds']==observer['elapsed_seconds']==review['whole_seconds'] and admission['whole_peak_bytes']==observer['final_conservative_whole_peak_bytes']==review['whole_peak_bytes'],'literal observer sample/peak')
    total_seconds+=admission['whole_seconds']
    need(admission['prior_admissions']==[x['admission'] for x in current if x['stage_id'] in recipe['required_upstream_ids']],'all ordered required predecessors')
    current.append(dict(stage_id=identity,admission=row['admission'],seal=seal_pin,C_actual_review=admission['C_actual_review'],result=admission['result']))
    for ci,case in enumerate(science['records']):
        if recipe['stage']=='acquire': rows=[('S0',case)]
        else: rows=[(e['engine']+'-learned',e) for e in case['episodes']]
        for method,record in rows:
            if recipe['stage']=='train':episodes.append(copy.deepcopy(record['descriptor']))
            gate=record['proof_check'];search=record['search']
            if gate['status']!='HOST_REGION_NATIVE_ACCEPTED':
                need(gate['native_proof_accepted'] is False and recipe['stage']=='train' and identity=='train-0' and record['descriptor']['global_ordinal']==2,'only known symbolic UNKNOWN')
                continue
            proof=search['proof'];spec=case['spec'];model=case['model'];q=gate['native_record']
            need(gate['native_proof_accepted'] is True and gate['host_check']['accepted'] is True and gate['region']['complete'] is True,'current proof gates')
            need(q['result']['status']=='accepted' and q['request']['blocks']==[] and same(q['request']['proof'],proof) and same(q['request']['theory'],spec['theory']) and same(q['request']['target'],spec['target']) and sum(same(q,x) for x in packet['native_queries'])==1,'unique current Native authority')
            need(len(proof)==spec['length'] and len(search['placements'])==2*len(proof),'full row/card bound')
            lookup={tuple(t['key']):t for t in model['placements']};need(len(lookup)==len(model['placements']),'unique catalog')
            selected=search['placements'];need(len({tuple(k) for k in selected})==len(selected),'distinct cards')
            need(type(model['word_terminator']) is int and model['word_terminator']==256,'whole-word terminator')
            for key in selected:
                need(type(key) is list and len(key)==4 and all(type(v) is int for v in key),'strict key')
                t=lookup[tuple(key)];rowid,index=t['command_reference'];need(same(model['domains'][rowid][index],proof[rowid]),'literal selected card command')
                for point,value in t['marks']:
                    if point[1]==100:
                        need(type(value) is int and 0<=value<len(model['word_dictionary']),'word ID includingzero')
                        json.loads(bytes.fromhex(model['word_dictionary'][value]).decode('utf-8'),object_pairs_hook=unique)
            proofs.append(dict(stage_id=identity,problem_id=spec['id'],method=method,proof_rows=len(proof),base_cards=len(selected),native_query=q.get('query_id',q.get('query'))))
    if recipe['stage']=='train':
        need(same(science['policies'],science['export']['policies']),'same live/export policies')
        for engine in ('symbolic','point'):
            policy=science['policies'][engine]
            need(policy['engine']==engine and policy['episodes']==2*(i-1) and len(policy['history'])==2*(i-1),'history2/4/6 perengine')
            if previous_policies is not None:need(same(policy['history'][:len(previous_policies[engine]['history'])],previous_policies[engine]['history']),'immutable policy history prefix')
        bundles.append(dict(stage_id=identity,export_sha256=admission['export_sha256'],episodes_per_engine=science['policies']['symbolic']['episodes']))
        previous_policies=science['policies']
expected_episodes=[e for r in recipes if r['stage']=='train' for e in r['episodes']]
need(len(expected_episodes)==32 and same(episodes,expected_episodes[:12]),'all12prescribed returned descriptors')
eval_slots=[dict(stage_id=r['stage_id'],method=m) for r in recipes if r['stage']=='evaluate' for m in r['method_order']]
need(len(eval_slots)==192 and len(set(x['stage_id'] for x in eval_slots))==24,'all192evaluation slots')
need(len(proofs)==13 and sum(x['proof_rows'] for x in proofs)==123 and sum(x['base_cards'] for x in proofs)==246,'13proofs123rows246cards')
for name in ('conditional-main-data-v3.json','conditional-main-report-v3.html'):
    need(not (STUDY/'publication'/name).exists(),'intended exclusive output absent')
for q in tuple(checked.values()):need(pin(q['path'])==q,'final current input stability')
counts=dict(planned_jobs=34,qualified_jobs=5,pending_jobs=29,failed_jobs=0,dependent_unavailable_jobs=0,awaiting_review_jobs=0,training_episode_slots=32,training_returned=12,training_pending=20,training_accepted_proofs=11,training_bounded_UNKNOWN=1,complete_real_training_episodes_per_engine=6,evaluation_slots=192,evaluation_returned=0,evaluation_pending=192,current_policy_bundles=3,eligible_proof_occurrences=13,eligible_proof_rows=123,eligible_base_cards=246)
checks=[
('exact-open-disposition-and-request','Exact canonical N3 request and full34row state match the original protocol order. Five QUALIFIED,29PENDING; no failed/unavailable or invented future packet. Open C_review null is allowed; the full state digest excludes only C_review.'),
('five-current-Root-admissions-and-independent-evidence','All five current Root admissions, strict13field seals, exact independent C actual receipts, five components, complete14file censuses, source guards and canonical exports join by current raw equality. Train2 newly issued outputs match all independent gates without C issuing an admission.'),
('complete32-and192-populations','Twelve original S-then-P descriptors are returned,20 training slots and all192 evaluation slots remain pending. The one earlier symbolic UNKNOWN remains a qualified unsolved training observation. Later jobs have no actual or observer directory.'),
('eligible-proof-policy-and-renderer-path-compatibility','Current saved field paths support13 accepted proof occurrences/123 primitive rows/246 base command-guard cards:2 S0 donor proofs plus11 training proofs. Full Host/word-region/current owned Native blocks-empty checks, catalog keys and whole-word payloads join. Three policy bundles preserve2/4/6 episodes per engine and immutable history prefixes; no numeric/RNG replay.'),
('reviewed-v4-Source-and-numbered-output-scope','The full v4 Source/template/API PASS is reused by exact raw equality. Request and state use stable schema3 with report_version3. Complete packet locators retain diagnostic references; output JSON and HTML are absent and exclusive. No projector/helper/JavaScript/scientific invocation.'),
('cost-attribution-and-open-study-limit','All five direct observer elapsed samples are accumulated once in recipe order; nested search/setup/final/custody clocks are not added. Train1 supplied-goal utility controls are disclosed. No completed32episode learner, evaluation result, comparative benefit, heldout performance, RL/GCTS/SOTA advantage or new theorem is claimed.')]
receipt=dict(schema='D21-C-main-report-population-review-v1',review_passed=True,report_version=3,protocol=protocol_pin,population=state_pin,request=request_pin,population_disposition_sha256=hashlib.sha256(wire({k:v for k,v in state.items() if k!='C_review'})).hexdigest(),disposition_rows_sha256=hashlib.sha256(wire(state['jobs'])).hexdigest(),closed=False,reader_Source=source_pin,reader_API=api_pin,reader_template=template_pin,reader_Source_review=source_review_pin,counts=counts,current_admissions=current,eligible_proof_literal_counts=proofs,current_policy_bundles=bundles,training_descriptor_sha256=hashlib.sha256(wire(expected_episodes)).hexdigest(),evaluation_slot_descriptors_sha256=hashlib.sha256(wire(eval_slots)).hexdigest(),decided_unique_observer_sample_seconds=total_seconds,checked_unique_current_pin_count=len(checked),checked_current_pins_sha256=hashlib.sha256(wire(sorted(checked.values(),key=lambda q:q['path']))).hexdigest(),checks=[dict(id=k,passed=True,finding=v) for k,v in checks],failures=[],partial_files_parsed=0,projector_invocations=0,helper_invocations=0,scientific_calls=0,Root_admission_issued=False,scope='Prospective exact N3 passive reader request/population compatibility only. No output/browser/archive/installation review, future actual execution approval or Root admission. Prior scientific reviews are reused only by current exact raw equality.',review_program=pin(Path(__file__).resolve()))
with OUT.open('xb') as f:f.write(json.dumps(receipt,sort_keys=True,ensure_ascii=False,indent=2,allow_nan=False).encode()+b'\n')
print(json.dumps(pin(OUT)))
