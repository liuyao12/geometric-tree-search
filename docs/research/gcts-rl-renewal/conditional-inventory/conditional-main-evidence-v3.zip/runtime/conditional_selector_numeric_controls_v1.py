"""Independent D19 numeric controls, UNRUN until a reviewed Root actual.

The literal trajectories below are synthetic arithmetic inputs.  They contain no
corpus theorem, proof route, learned policy, or actual evaluation statement.
Passing them is not evidence that a live context, pool, clock or Native outcome
has the provenance asserted by a scientific trajectory.
"""
import copy
import math

VERSION = 'D19-conditional-selector-numeric-controls-v1'
_OWNER = object()


class ControlError(Exception):
    """An ordinary public instance has no local ownership token."""
    pass


def is_owned_error(error):
    return type(error) is ControlError and getattr(error, '_numeric_control_owner', None) is _OWNER


def _need(condition, message, check):
    check()
    if not condition:
        error = ControlError(message)
        error._numeric_control_owner = _OWNER
        raise error


def _equal(actual, expected, check, tolerance=1e-12):
    """Independent finite comparison; a bool never aliases a number."""
    check()
    if type(expected) in (int, float):
        if type(actual) not in (int, float):
            return False
        try:
            if not math.isfinite(actual) or not math.isfinite(expected):
                return False
        except OverflowError:
            return False
        return abs(actual-expected) <= tolerance
    if type(actual) is not type(expected):
        return False
    if type(expected) is list:
        if len(actual) != len(expected):
            return False
        for a, b in zip(actual, expected):
            if not _equal(a, b, check, tolerance):
                return False
        return True
    if type(expected) is dict:
        if set(actual) != set(expected):
            return False
        for key in expected:
            if not _equal(actual[key], expected[key], check, tolerance):
                return False
        return True
    return actual == expected


class _LiteralRNG:
    def __init__(self, values):
        self.values = list(values)
        self.calls = 0

    def random(self):
        if self.calls >= len(self.values):
            raise RuntimeError('numeric control RNG consumed beyond its literal stream')
        value = self.values[self.calls]
        self.calls += 1
        return value


def _basis(dimension, coordinate, check):
    result = []
    for index in range(dimension):
        check()
        result.append(1.0 if index == coordinate else 0.0)
    return result


def _action(head, draw, choice, check, *, sole=False):
    dimension = 8 if head == 'gate' else 12
    rows = [_basis(dimension, 0, check)]
    if not sole:
        rows.append(_basis(dimension, 7, check))
    return dict(mode='learned', weights=[0.0]*dimension, features=rows,
                probabilities=[1.0] if sole else [0.5, 0.5],
                draw=draw, choice=choice)


def _decision(ordinal, head, draw, choice, callbacks, seconds, attempts,
              check, *, sole=False):
    return dict(ordinal=ordinal, head=head,
        action=_action(head, draw, choice, check, sole=sole),
        snapshot=dict(callbacks=callbacks, elapsed_seconds=seconds), attempts=attempts,
        context={'synthetic_control': True}, pool_ordinal=None if head == 'gate' else ordinal)


def _episode(decisions, check, *, index=0, engine='symbolic', callbacks=0,
             seconds=0.0, attempts=0, accepted=True):
    check()
    return dict(schema='conditional-episode-v1', engine=engine, index=index,
        global_ordinal=2*index+(1 if engine == 'point' else 0),
        problem_id='numeric-case-'+str(index % 8),
        seed=(10000 if engine == 'point' else 0)+index, decisions=decisions,
        terminal=dict(snapshot=dict(callbacks=callbacks, elapsed_seconds=seconds),
            attempts=attempts, native_proof_accepted=accepted,
            proof_status='HOST_REGION_NATIVE_ACCEPTED' if accepted else 'NO_PROOF_CANDIDATE',
            search_status='SYNTHETIC_CONTROL'))


def _head(weights, baseline):
    return dict(weights=weights, baseline=baseline)


def run_numeric_controls(selector, *, check):
    """Run the finite independent bank only inside a fresh reviewed Root actual.

    No Source import, file access, checker call or learned-policy adoption occurs.
    Each call to the supplied callback is allowed to escape with its identity.
    """
    completed_ticks = 0

    def tick():
        nonlocal completed_ticks
        check()
        completed_ticks += 1

    rows = []

    def record(control_id, expected, observed, *, scope='synthetic numeric arithmetic'):
        _need(_equal(observed, expected, tick), control_id+' literal expected outcome', tick)
        rows.append(dict(id=control_id, passed=True, expected=expected, observed=observed, scope=scope))

    def refusal(control_id, operation, mutation):
        try:
            operation()
        except BaseException as error:
            tick()
            if not selector.is_owned_error(error):
                raise
            rows.append(dict(id=control_id, passed=True, mutation=mutation,
                expected='SELECTOR_OWNED_REFUSAL', observed=dict(type=type(error).__name__, message=str(error))))
        else:
            _need(False, control_id+' must refuse', tick)

    ids = ['numeric-case-0','numeric-case-1','numeric-case-2','numeric-case-3',
           'numeric-case-4','numeric-case-5','numeric-case-6','numeric-case-7']
    symbolic = selector.initial_policy('symbolic', check=tick)
    point = selector.initial_policy('point', check=tick)
    initial_heads = dict(gate=_head([0.0]*8, 0.0), continuation=_head([0.0]*12, 0.0))
    for engine, policy in (('symbolic', symbolic), ('point', point)):
        tick()
        expected = dict(schema='conditional-family-selector-v1', engine=engine,
                        episodes=0, heads=copy.deepcopy(initial_heads), history=[])
        record('initial-'+engine, expected, policy)

    record('zero-logits-equal', [0.5,0.5],
           selector.softmax([0.0,0.0], [[1.0,0.0],[0.0,1.0]], check=tick))
    record('nonuniform-stable-large-logits', [0.7310585786300049,0.2689414213699951],
           selector.softmax([1000.0,999.0], [[1.0,0.0],[0.0,1.0]], check=tick))

    no_draw = _LiteralRNG([])
    fixed = selector.choose('fixed', [0.0], [[1.0],[0.0]], no_draw, check=tick)
    record('fixed-first-no-draw', dict(choice=0, draw=None, probabilities=[1.0,0.0], calls=0),
           dict(choice=fixed['choice'], draw=fixed['draw'], probabilities=fixed['probabilities'], calls=no_draw.calls))
    only = selector.choose('fixed', [0.0], [[0.0]], no_draw, check=tick)
    record('fixed-sole-abstain', dict(choice=0,draw=None,probabilities=[1.0],calls=0),
           dict(choice=only['choice'],draw=only['draw'],probabilities=only['probabilities'],calls=no_draw.calls))

    duplicate_features = [[1.0],[1.0],[0.0]]
    uniform = selector.choose('uniform',[0.0],duplicate_features,_LiteralRNG([0.5]),check=tick)
    learned = selector.choose('learned',[0.0],duplicate_features,_LiteralRNG([0.5]),check=tick)
    expected_prior = dict(probabilities=[0.3333333333333333]*3, draw=0.5, choice=1,
                          features=duplicate_features)
    record('uniform-keeps-duplicate-actions',expected_prior,
           {key:uniform[key] for key in expected_prior})
    record('zero-learned-equals-uniform',expected_prior,
           {key:learned[key] for key in expected_prior})
    near_end = selector.choose('uniform',[0.0],duplicate_features,
                               _LiteralRNG([0.9999999999999999]),check=tick)
    record('unit-endpoint-last-action',2,near_end['choice'])

    weights = [0.0]; features = [[1.0],[0.0]]
    isolated = selector.choose('fixed',weights,features,no_draw,check=tick)
    weights[0] = 9.0; features[0][0] = 9.0
    record('returned-action-owns-recorded-vectors',dict(weights=[0.0],features=[[1.0],[0.0]]),
           dict(weights=isolated['weights'],features=isolated['features']))

    empty = _episode([],tick,accepted=False,callbacks=400000000,seconds=180.0,attempts=600)
    empty_update = selector.update_policy(symbolic,empty,check=tick)
    record('no-decisions-no-head-update',dict(heads=initial_heads,episodes=1,decision_returns=[]),
        dict(heads=empty_update['heads'],episodes=empty_update['episodes'],
             decision_returns=empty_update['history'][0]['decision_returns']))

    sole = _episode([_decision(0,'gate',0.8444218515250481,0,0,0.0,0,tick,sole=True)],tick)
    sole_update = selector.update_policy(symbolic,sole,check=tick)
    record('sole-action-zero-score-gradient',dict(
        weights=[0.0]*8,baseline=0.09999999999999998,gradient=[0.0]*8,other=initial_heads['continuation']),
        dict(weights=sole_update['heads']['gate']['weights'],baseline=sole_update['heads']['gate']['baseline'],
             gradient=sole_update['history'][0]['decision_returns'][0]['score_gradient'],
             other=sole_update['heads']['continuation']))

    accepted = _episode([_decision(0,'gate',0.8444218515250481,1,0,0.0,0,tick)],tick)
    one = selector.update_policy(symbolic,accepted,check=tick)
    gate_weights = [-0.025,0.0,0.0,0.0,0.0,0.0,0.0,0.025]
    score_gradient = [-0.5,0.0,0.0,0.0,0.0,0.0,0.0,0.5]
    record('accepted-synthetic-second-action-gradient',dict(weights=gate_weights,baseline=0.09999999999999998,
        return_to_go=1.0,score_gradient=score_gradient,other=initial_heads['continuation']),
        dict(weights=one['heads']['gate']['weights'],baseline=one['heads']['gate']['baseline'],
             return_to_go=one['history'][0]['decision_returns'][0]['return_to_go'],
             score_gradient=one['history'][0]['decision_returns'][0]['score_gradient'],
             other=one['heads']['continuation']))

    gate_abstain = copy.deepcopy(accepted)
    gate_abstain['decisions'][0]['action']['features'][1] = [0.0]*8
    gate_abstain_update = selector.update_policy(symbolic,gate_abstain,check=tick)
    record('prepool-zero-vector-ABSTAIN-gradient',dict(
        weights=[-0.025,0.0,0.0,0.0,0.0,0.0,0.0,0.0],baseline=0.09999999999999998,
        gradient=[-0.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0]),dict(
        weights=gate_abstain_update['heads']['gate']['weights'],
        baseline=gate_abstain_update['heads']['gate']['baseline'],
        gradient=gate_abstain_update['history'][0]['decision_returns'][0]['score_gradient']))

    unknown_episode = copy.deepcopy(accepted)
    unknown_episode['terminal']['native_proof_accepted'] = False
    unknown_episode['terminal']['proof_status'] = 'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN'
    unknown_update = selector.update_policy(symbolic,unknown_episode,check=tick)
    record('Native-UNKNOWN-is-not-success',dict(heads=initial_heads,return_to_go=0.0,advantage=0.0),
        dict(heads=unknown_update['heads'],
             return_to_go=unknown_update['history'][0]['decision_returns'][0]['return_to_go'],
             advantage=unknown_update['history'][0]['decision_returns'][0]['advantage']))

    repeated = _episode([
        _decision(0,'gate',0.8444218515250481,1,0,0.0,0,tick),
        _decision(1,'gate',0.7579544029403025,1,200000000,90.0,300,tick)],tick,
        callbacks=400000000,seconds=180.0,attempts=600)
    repeated_update = selector.update_policy(symbolic,repeated,check=tick)
    record('two-decision-return-to-go-SUM',dict(
        weights=[0.0625,0.0,0.0,0.0,0.0,0.0,0.0,-0.0625],baseline=-0.12499999999999997,
        gradient=[1.25,0.0,0.0,0.0,0.0,0.0,0.0,-1.25],returns=[-2.0,-0.5],mean_return=-1.25),
        dict(weights=repeated_update['heads']['gate']['weights'],baseline=repeated_update['heads']['gate']['baseline'],
             gradient=repeated_update['history'][0]['heads']['gate']['summed_advantage_gradient'],
             returns=[r['return_to_go'] for r in repeated_update['history'][0]['decision_returns']],
             mean_return=repeated_update['history'][0]['heads']['gate']['mean_return']))

    separate = copy.deepcopy(repeated)
    separate['decisions'][1] = _decision(1,'continuation',0.7579544029403025,1,200000000,90.0,300,tick)
    separate_update = selector.update_policy(symbolic,separate,check=tick)
    record('head-separate-gradients-and-EMA',dict(
        gate=_head([0.05,0.0,0.0,0.0,0.0,0.0,0.0,-0.05],-0.19999999999999996),
        continuation=_head([0.0125,0.0,0.0,0.0,0.0,0.0,0.0,-0.0125,0.0,0.0,0.0,0.0],
                           -0.04999999999999999)),separate_update['heads'])

    prior = copy.deepcopy(symbolic)
    prior['heads']['gate']['baseline'] = 0.5
    baseline_episode = copy.deepcopy(accepted)
    baseline_episode['terminal']['native_proof_accepted'] = False
    baseline_episode['terminal']['proof_status'] = 'NO_PROOF_CANDIDATE'
    baseline_update = selector.update_policy(prior,baseline_episode,check=tick)
    record('pre-episode-EMA-baseline',dict(
        weights=[0.0125,0.0,0.0,0.0,0.0,0.0,0.0,-0.0125],baseline=0.45,
        preupdate_baseline=0.5,advantage=-0.5),dict(
        weights=baseline_update['heads']['gate']['weights'],baseline=baseline_update['heads']['gate']['baseline'],
        preupdate_baseline=baseline_update['history'][0]['decision_returns'][0]['preupdate_baseline'],
        advantage=baseline_update['history'][0]['decision_returns'][0]['advantage']))
    prior['heads']['continuation']['baseline'] = -0.75
    inactive = selector.update_policy(prior,baseline_episode,check=tick)
    record('inactive-head-baseline-preserved',_head([0.0]*12,-0.75),inactive['heads']['continuation'])

    verified = selector.verify_policy(one,ids,'symbolic',check=tick)
    record('zero-origin-numeric-replay',dict(complete=True,engine='symbolic',episodes=1,decisions=1,
           nonzero_weight_updates=2),{key:verified[key] for key in (
               'complete','engine','episodes','decisions','nonzero_weight_updates')})
    point_episode = _episode([],tick,engine='point',accepted=False)
    point_one = selector.update_policy(point,point_episode,check=tick)
    point_receipt = selector.verify_policy(point_one,ids,'point',check=tick)
    record('point-separate-schedule-replay',dict(complete=True,engine='point',episodes=1,decisions=0),
           {key:point_receipt[key] for key in ('complete','engine','episodes','decisions')})

    prefix16 = copy.deepcopy(symbolic)
    for index in range(16):
        tick()
        prefix16 = selector.update_policy(prefix16,_episode([],tick,index=index,accepted=False),check=tick)
    prefix_receipt = selector.verify_policy(prefix16,ids,'symbolic',check=tick)
    record('sixteen-episode-boundary',dict(episodes=16,decisions=0,nonzero_weight_updates=0),
           {key:prefix_receipt[key] for key in ('episodes','decisions','nonzero_weight_updates')})

    # Each malformed input has its own literal reason, without treating arbitrary
    # exceptions as successful negative controls.
    malformed_vectors = [
        ('empty-action-pool',[0.0],[], 'no action rows'),
        ('mismatched-vector-dimension',[0.0,0.0],[[1.0]], 'row dimension differs'),
        ('bool-weight',[False],[[1.0]], 'bool is not a numeric weight'),
        ('bool-feature',[0.0],[[True]], 'bool is not a numeric feature'),
        ('huge-int-weight',[10**1000],[[1.0]], 'unrepresentable finite-int normalization'),
        ('nan-weight',[float('nan')],[[1.0]], 'nonfinite weight'),
        ('overflowing-logit',[1e308],[[1e308]], 'finite operands producing nonfinite logit')]
    for control_id, bad_weights, bad_features, reason in malformed_vectors:
        tick()
        refusal(control_id,lambda w=bad_weights,f=bad_features:selector.softmax(w,f,check=tick),reason)
    refusal('bool-rng-draw',lambda:selector.choose('uniform',[0.0],[[1.0]],_LiteralRNG([False]),check=tick),
            'draw has exact bool type')
    refusal('unit-upper-rng-draw',lambda:selector.choose('uniform',[0.0],[[1.0]],_LiteralRNG([1.0]),check=tick),
            'unit interval upper endpoint is excluded')
    refusal('undeclared-selection-mode',lambda:selector.choose('novel',[0.0],[[1.0]],no_draw,check=tick),
            'unknown preference mode')
    refusal('undeclared-engine',lambda:selector.initial_policy('joint',check=tick),'unknown engine')

    action_weight_bool = copy.deepcopy(accepted)
    action_weight_bool['decisions'][0]['action']['weights'][0] = False
    probability_bool = copy.deepcopy(sole)
    probability_bool['decisions'][0]['action']['probabilities'][0] = True
    wrong_stream = copy.deepcopy(accepted)
    wrong_stream['decisions'][0]['action']['draw'] = 0.13436424411240122
    wrong_stream['decisions'][0]['action']['choice'] = 0
    wrong_choice = copy.deepcopy(accepted)
    wrong_choice['decisions'][0]['action']['choice'] = 0
    boolean_choice = copy.deepcopy(accepted)
    boolean_choice['decisions'][0]['action']['choice'] = True
    backwards_callbacks = copy.deepcopy(repeated)
    backwards_callbacks['decisions'][1]['snapshot']['callbacks'] = 0
    backwards_time = copy.deepcopy(repeated)
    backwards_time['decisions'][0]['snapshot']['elapsed_seconds'] = 91.0
    terminal_before_decision = copy.deepcopy(repeated)
    terminal_before_decision['terminal']['attempts'] = 299
    contradictory_native = copy.deepcopy(accepted)
    contradictory_native['terminal']['proof_status'] = 'NO_PROOF_CANDIDATE'
    bad_context = copy.deepcopy(accepted)
    bad_context['decisions'][0]['context'] = []
    bad_head = copy.deepcopy(accepted)
    bad_head['decisions'][0]['head'] = 'shared'
    episode_cases = [
        ('recorded-bool-weight',action_weight_bool,'bool alias in recorded preupdate weights'),
        ('recorded-bool-probability',probability_bool,'bool alias in recorded probability'),
        ('seed-correct-other-stream-draw',wrong_stream,'seed0 paired with internally consistent seed1 draw'),
        ('draw-choice-mismatch',wrong_choice,'literal draw and selected action disagree'),
        ('bool-choice',boolean_choice,'bool alias for action index'),
        ('nonincreasing-callbacks',backwards_callbacks,'distinct decisions require increasing Root callbacks'),
        ('backwards-time',backwards_time,'decision time decreases'),
        ('terminal-before-decision',terminal_before_decision,'terminal primitive count precedes decision'),
        ('contradictory-Native-outcome',contradictory_native,'accepted flag contradicts proof status'),
        ('malformed-context',bad_context,'context is not a dictionary'),
        ('undeclared-head',bad_head,'shared head is not a declared independent head')]
    for control_id, episode, reason in episode_cases:
        tick()
        refusal(control_id,lambda e=episode:selector.update_policy(symbolic,e,check=tick),reason)
    refusal('seventeenth-episode',lambda:selector.update_policy(prefix16,
            _episode([],tick,index=16,accepted=False),check=tick),'fixed sixteen-episode profile exhausted')
    overlong = copy.deepcopy(prefix16)
    overlong['episodes'] = 17; overlong['history'].append(copy.deepcopy(overlong['history'][0]))
    refusal('overlong-policy-carrier',lambda:selector.verify_policy(overlong,ids,'symbolic',check=tick),
            'complete policy history beyond fixed declared profile')

    wrong_seed = copy.deepcopy(point_one)
    wrong_seed['history'][0]['episode']['seed'] = 0
    wrong_ordinal = copy.deepcopy(point_one)
    wrong_ordinal['history'][0]['episode']['global_ordinal'] = 0
    wrong_problem = copy.deepcopy(one)
    wrong_problem['history'][0]['episode']['problem_id'] = 'other-problem'
    bool_history = copy.deepcopy(one)
    bool_history['history'][0]['decision_returns'][0]['score_gradient'][1] = False
    tampered_weight = copy.deepcopy(one)
    tampered_weight['heads']['gate']['weights'][0] = 0.0
    tampered_reward = copy.deepcopy(one)
    tampered_reward['history'][0]['decision_returns'][0]['return_to_go'] = 0.0
    replay_cases = [
        ('wrong-point-seed',wrong_seed,'point','point seed must start at10000'),
        ('wrong-global-ordinal',wrong_ordinal,'point','point ordinal must be odd'),
        ('wrong-training-problem',wrong_problem,'symbolic','problem must follow manifest position'),
        ('boolean-history-gradient',bool_history,'symbolic','bool must not alias numeric replay zero'),
        ('changed-final-weight',tampered_weight,'symbolic','final weights must equal complete replay'),
        ('changed-recorded-return',tampered_reward,'symbolic','stored return must equal per-decision cost arithmetic')]
    for control_id, policy, engine, reason in replay_cases:
        tick()
        refusal(control_id,lambda p=policy,e=engine:selector.verify_policy(p,ids,e,check=tick),reason)
    refusal('unexplained-nonzero-origin',lambda:selector.verify_policy(prior,ids,'symbolic',check=tick),
            'one-step prebaseline control is not an admitted zero-origin history')

    # Inject at a nested callback, after one successful callback, rather than
    # letting malformed numeric data masquerade as a foreign-exception test.
    foreign_errors = [RuntimeError('foreign numeric control RuntimeError'),
                      ValueError('foreign numeric control ValueError'),
                      StopIteration('foreign numeric control StopIteration'),
                      selector.Invalid('public unowned selector exception')]
    for index, sentinel in enumerate(foreign_errors):
        tick(); calls = 0
        def throwing_check():
            nonlocal calls
            tick(); calls += 1
            if calls == 7:
                raise sentinel
        try:
            selector.update_policy(symbolic,accepted,check=throwing_check)
        except BaseException as error:
            tick()
            if error is not sentinel:
                raise
            _need(not selector.is_owned_error(error),
                  'nested foreign exact identity '+str(index),tick)
        else:
            _need(False,'nested foreign callback must escape '+str(index),tick)
        rows.append(dict(id='foreign-identity-'+str(index),passed=True,
            expected='EXACT_FOREIGN_IDENTITY',observed=dict(type=type(sentinel).__name__,callback_ordinal=7)))

    _need(len(rows) == 57, 'fixed complete numeric control population', tick)
    return dict(schema=VERSION, complete=True, control_count=len(rows), controls=rows,
        control_checkpoints=completed_ticks,
        finite_bounds=dict(max_head_dimension=12,max_actions=3,max_decisions_per_literal_episode=2,
                           max_policy_episodes=16,max_problem_ids=8,max_foreign_callback_ordinal=7),
        scope=('Independent synthetic numeric/format/schedule controls execute only inside a fresh reviewed Root actual. '
               'Literal expected vectors cover nonuniform logits, SUM of per-decision return-to-go gradients, '
               'pre-episode per-head EMA, ABSTAIN actions, exact seeded draws and typed malformed carriers. '
               'They do not verify live pool/context/Root snapshot/Native ownership, scientific proofs, '
               'policy utility, memory fit or corpus generalization. control_checkpoints counts completed '
               'local tick calls, not every Root callback in the full job.'))
