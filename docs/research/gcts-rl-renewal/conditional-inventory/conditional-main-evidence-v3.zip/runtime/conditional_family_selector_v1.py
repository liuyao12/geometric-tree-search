"""D19 two-head conditional preference policy. Source-only until Root actual.

No theorem authority lives here. Numeric replay verifies arithmetic against
Root-admitted trajectory records; it cannot reconstruct live State ownership.
"""
import copy
import math
import random

VERSION = 'conditional-family-selector-v1'
GATE_FEATURES = ('bias', 'prefix_fraction', 'unique_prefix_fraction',
                 'repeated_prefix_fraction', 'candidate_fraction',
                 'point_command_role', 'point_guard_role', 'symbolic_row_role')
CONTINUATION_FEATURES = ('packet_bias', 'command_fraction',
    'prefix_receptor_fraction', 'repeated_emitted_fraction',
    'changes_novelty_order', 'target_conclusion',
    'incremental_validation_fraction', 'abstain_bias',
    'abstain_prefix_fraction', 'abstain_mean_repeated_fraction',
    'abstain_shared_validation_fraction', 'abstain_distinct_first_fraction')
DIMENSIONS = dict(gate=8, continuation=12)
LEARNING_RATE = 0.05
BASELINE_DECAY = 0.9
NORMALIZERS = dict(attempts=600, callbacks=400000000, elapsed_seconds=180.0)
_OWNER = object()


class Invalid(Exception):
    """Public construction is unowned; only local _fail assigns ownership."""
    pass


def _fail(message):
    error = Invalid(message)
    error._conditional_selector_owner = _OWNER
    raise error


def is_owned_error(error):
    return type(error) is Invalid and getattr(error, '_conditional_selector_owner', None) is _OWNER


def _need(condition, message):
    if not condition:
        _fail(message)


def _number(value):
    if type(value) not in (float, int):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _vectors(weights, features, check):
    check()
    _need(type(weights) is list and len(weights) > 0 and all(_number(v) for v in weights),
          'finite exact numeric weight vector; bool is not a weight')
    _need(type(features) is list and len(features) > 0, 'nonempty action feature pool')
    for row in features:
        check()
        _need(type(row) is list and len(row) == len(weights) and all(_number(v) for v in row),
              'finite exact action vectors with unchanged multiplicity')


def _same(left, right, check):
    check()
    if _number(left) and _number(right):
        return left == right
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        if set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key],right[key],check):
                return False
        return True
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a,b in zip(left,right):
            if not _same(a,b,check):
                return False
        return True
    return left == right


def softmax(weights, features, *, check):
    _vectors(weights, features, check)
    scores = []
    for row in features:
        score = 0.0
        for weight, value in zip(weights, row):
            check(); score += weight * value
        _need(math.isfinite(score), 'finite logits')
        scores.append(score)
    maximum = max(scores); scaled = []
    for score in scores:
        check(); scaled.append(math.exp(score-maximum))
    total = sum(scaled)
    _need(math.isfinite(total) and total > 0, 'finite positive normalization')
    probabilities = []
    for value in scaled:
        check(); probabilities.append(value/total)
    return probabilities


def choose(mode, weights, features, rng, *, check):
    """Uniform and all-zero learned use exactly the same prior and draw rule."""
    _vectors(weights, features, check)
    _need(mode in ('fixed', 'uniform', 'learned'), 'declared selector mode')
    if mode == 'fixed':
        probabilities = [1.0] + [0.0]*(len(features)-1)
        draw = None; choice = 0
    else:
        probabilities = ([1.0/len(features)]*len(features) if mode == 'uniform'
                         else softmax(weights, features, check=check))
        check(); draw = rng.random(); check()
        _need(type(draw) is float and math.isfinite(draw) and 0.0 <= draw < 1.0,
              'exact finite unit-interval RNG draw')
        accumulated = 0.0; choice = len(features)-1
        for index, probability in enumerate(probabilities):
            check(); accumulated += probability
            if draw < accumulated:
                choice = index; break
    return dict(mode=mode, weights=list(weights), features=copy.deepcopy(features),
                probabilities=probabilities, draw=draw, choice=choice)


def initial_policy(engine, *, check):
    check(); _need(engine in ('symbolic', 'point'), 'separate declared engine policy')
    return dict(schema=VERSION, engine=engine, episodes=0,
        heads={head:dict(weights=[0.0]*dimension, baseline=0.0)
               for head, dimension in DIMENSIONS.items()}, history=[])


def _snapshot(value, check):
    check()
    _need(type(value) is dict and set(value) == {'callbacks','elapsed_seconds'}
          and type(value['callbacks']) is int and 0 <= value['callbacks'] <= NORMALIZERS['callbacks']
          and _number(value['elapsed_seconds']) and 0 <= value['elapsed_seconds'] <= NORMALIZERS['elapsed_seconds'],
          'genuine Root snapshot carrier; actual provenance joined outside numeric replay')


def _action(action, weights, dimension, check):
    check()
    _need(type(action) is dict and set(action) == {'mode','weights','features','probabilities','draw','choice'}
          and action['mode'] == 'learned' and action['weights'] == weights,
          'exact learned preupdate action record')
    _vectors(action['weights'], action['features'], check)
    _vectors(weights, action['features'], check)
    _need(len(weights) == dimension, 'head dimension')
    expected = softmax(weights, action['features'], check=check)
    _need(type(action['probabilities']) is list and all(_number(v) for v in action['probabilities'])
          and action['probabilities'] == expected,
          'exact preupdate action probabilities')
    draw = action['draw']; choice = action['choice']
    _need(type(draw) is float and math.isfinite(draw) and 0 <= draw < 1
          and type(choice) is int and 0 <= choice < len(expected), 'exact sampled action')
    cumulative = 0.0; selected = len(expected)-1
    for index, probability in enumerate(expected):
        check(); cumulative += probability
        if draw < cumulative:
            selected = index; break
    _need(choice == selected, 'recorded draw-to-choice correspondence')


def _update(policy, episode, check):
    check()
    _need(type(episode) is dict and set(episode) == {'schema','engine','index','global_ordinal',
          'problem_id','seed','decisions','terminal'} and episode['schema'] == 'conditional-episode-v1'
          and episode['engine'] == policy['engine'] and type(episode['index']) is int
          and episode['index'] == policy['episodes'] and policy['episodes'] < 16
          and type(episode['global_ordinal']) is int
          and episode['global_ordinal'] >= 0 and type(episode['problem_id']) is str
          and type(episode['seed']) is int and type(episode['decisions']) is list,
          'ordered complete episode carrier')
    terminal = episode['terminal']
    _need(type(terminal) is dict and set(terminal) == {'snapshot','attempts','native_proof_accepted',
          'proof_status','search_status'} and type(terminal['native_proof_accepted']) is bool
          and type(terminal['attempts']) is int and 0 <= terminal['attempts'] <= NORMALIZERS['attempts']
          and type(terminal['proof_status']) is str and type(terminal['search_status']) is str,
          'complete terminal outcome and search costs')
    _need(terminal['proof_status'] in ('HOST_REGION_NATIVE_ACCEPTED','NO_PROOF_CANDIDATE',
                                    'HOST_REGION_ACCEPTED_NATIVE_UNKNOWN')
          and terminal['native_proof_accepted'] is (terminal['proof_status'] == 'HOST_REGION_NATIVE_ACCEPTED'),
          'Native acceptance separate from bounded unresolved outcome')
    _snapshot(terminal['snapshot'], check)
    gradients = {head:[0.0]*dimension for head, dimension in DIMENSIONS.items()}
    returns = {head:[] for head in DIMENSIONS}; rows = []
    prior_callbacks = -1; prior_time = -1.0; prior_attempts = 0
    rng = random.Random(episode['seed'])
    for ordinal, decision in enumerate(episode['decisions']):
        check()
        _need(type(decision) is dict and set(decision) == {'ordinal','head','action','snapshot',
              'attempts','context','pool_ordinal'} and type(decision['ordinal']) is int
              and decision['ordinal'] == ordinal and decision['head'] in DIMENSIONS
              and type(decision['attempts']) is int and 0 <= decision['attempts'] <= terminal['attempts']
              and type(decision['context']) is dict
              and (decision['pool_ordinal'] is None or type(decision['pool_ordinal']) is int),
              'ordered inspectable head decision with current context')
        snapshot = decision['snapshot']; _snapshot(snapshot, check)
        _need(prior_callbacks < snapshot['callbacks'] <= terminal['snapshot']['callbacks']
              and prior_time <= snapshot['elapsed_seconds'] <= terminal['snapshot']['elapsed_seconds']
              and prior_attempts <= decision['attempts'], 'monotone actual cost snapshots/attempts')
        prior_callbacks = snapshot['callbacks']; prior_time = snapshot['elapsed_seconds']
        prior_attempts = decision['attempts']
        head = decision['head']; before = policy['heads'][head]
        action = decision['action']; _action(action, before['weights'], DIMENSIONS[head], check)
        check(); _need(action['draw'] == rng.random(), 'exact per-episode seed-to-decision draw stream')
        components = dict(native_acceptance=float(terminal['native_proof_accepted']),
            remaining_attempts=(terminal['attempts']-decision['attempts'])/float(NORMALIZERS['attempts']),
            remaining_callbacks=(terminal['snapshot']['callbacks']-snapshot['callbacks'])/float(NORMALIZERS['callbacks']),
            remaining_elapsed=(terminal['snapshot']['elapsed_seconds']-snapshot['elapsed_seconds'])/NORMALIZERS['elapsed_seconds'])
        value = (components['native_acceptance']-components['remaining_attempts']
                 -components['remaining_callbacks']-components['remaining_elapsed'])
        _need(math.isfinite(value), 'finite return-to-go utility proxy')
        advantage = value-before['baseline']; features = action['features']; probabilities = action['probabilities']
        score_gradient = []
        for coordinate in range(DIMENSIONS[head]):
            check(); expectation = 0.0
            for probability, vector in zip(probabilities, features):
                check(); expectation += probability*vector[coordinate]
            entry = features[action['choice']][coordinate]-expectation
            score_gradient.append(entry)
            gradients[head][coordinate] += advantage*entry
        returns[head].append(value)
        rows.append(dict(ordinal=ordinal, head=head, components=components, return_to_go=value,
            preupdate_baseline=before['baseline'], advantage=advantage, score_gradient=score_gradient))
    following = copy.deepcopy(policy['heads']); updates = {}
    for head, dimension in DIMENSIONS.items():
        check(); before = policy['heads'][head]; after = following[head]
        for coordinate in range(dimension):
            check(); after['weights'][coordinate] += LEARNING_RATE*gradients[head][coordinate]
            _need(math.isfinite(after['weights'][coordinate]), 'finite sum-gradient update')
        if returns[head]:
            mean_return = sum(returns[head])/len(returns[head])
            after['baseline'] = BASELINE_DECAY*before['baseline']+(1-BASELINE_DECAY)*mean_return
        else:
            mean_return = None
        updates[head] = dict(preupdate=copy.deepcopy(before), summed_advantage_gradient=gradients[head],
            decisions=len(returns[head]), mean_return=mean_return, postupdate=copy.deepcopy(after),
            nonzero_weight_updates=sum(a != b for a,b in zip(before['weights'],after['weights'])))
    return following, dict(episode=copy.deepcopy(episode), decision_returns=rows, heads=updates,
        reward_scope='Per-decision sampled future primitive attempts plus genuine Root callback/time deltas, ending after Host/full-region/Native. Update/export/output/custody after terminal excluded here and charged in full phase totals. Unknown is unsolved, not a false theorem. No counterfactual cost credit.')


def update_policy(policy, episode, *, check):
    _validate_policy_carrier(policy, check)
    heads, record = _update(policy, episode, check)
    result = copy.deepcopy(policy); result['heads'] = heads
    result['episodes'] += 1; result['history'].append(record)
    check(); return result


def _validate_policy_carrier(policy, check):
    check()
    _need(type(policy) is dict and set(policy) == {'schema','engine','episodes','heads','history'}
          and policy['schema'] == VERSION and policy['engine'] in ('symbolic','point')
          and type(policy['episodes']) is int and 0 <= policy['episodes'] <= 16
          and type(policy['heads']) is dict and set(policy['heads']) == set(DIMENSIONS)
          and type(policy['history']) is list and len(policy['history']) == policy['episodes'],
          'exact current two-head policy carrier')
    for head, dimension in DIMENSIONS.items():
        check(); row = policy['heads'][head]
        _need(type(row) is dict and set(row) == {'weights','baseline'}
              and type(row['weights']) is list and len(row['weights']) == dimension
              and all(_number(v) for v in row['weights']) and _number(row['baseline']),
              'finite typed head parameters and baseline')


def verify_policy(policy, problem_ids, engine, *, check):
    """Exact numeric replay from zero; live-record provenance remains Root-owned."""
    _validate_policy_carrier(policy, check)
    _need(engine == policy['engine'] and type(problem_ids) is list and len(problem_ids) == 8
          and all(type(value) is str for value in problem_ids), 'fixed eight-case engine manifest')
    replay = initial_policy(engine, check=check)
    for index, expected in enumerate(policy['history']):
        check(); episode = expected['episode']
        _need(episode['problem_id'] == problem_ids[index % 8]
              and episode['global_ordinal'] == 2*index+(engine == 'point')
              and episode['seed'] == (10000 if engine == 'point' else 0)+index,
              'fixed engine index/global ordinal/RNG schedule')
        replay = update_policy(replay, episode, check=check)
        _need(_same(replay['history'][-1],expected,check), 'full per-decision return and summed gradient replay')
    _need(_same(replay,policy,check), 'complete policy weights/EMA/history from zero')
    return dict(complete=True, engine=engine, episodes=policy['episodes'],
        decisions=sum(len(row['episode']['decisions']) for row in policy['history']),
        nonzero_weight_updates=sum(sum(head['nonzero_weight_updates'] for head in row['heads'].values())
                                   for row in policy['history']),
        scope='Arithmetic and declared schedule only; actual context/pool/Root snapshots and Native outcomes require exact admitted stage record joins.')
