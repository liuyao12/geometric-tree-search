"""Independent, hand-authored D19 adapter controls; Root-actual calls only.

These tiny command/formula carriers are synthetic controls, not donor proofs,
held-out statements, search routes, or theorem licences. No scientific imports,
file access, model/State/Graph construction, RNG, proof checking or Native calls.
The three subject functions only order/describe already supplied carriers.
"""
import copy

_OWNER = object()
CONTROL_IDS = (
    'novelty-before-repeated-hint', 'candidate-multiplicity-preserved',
    'empty-order-no-command-read', 'gate-command-role', 'gate-guard-role',
    'gate-symbolic-no-point-read', 'gate-id-and-future-metadata-independent',
    'full-sequence-guard-and-future-quotient', 'duplicate-frequency-no-prior',
    'family-labels-not-features', 'different-future-same-first-degeneracy',
    'empty-pool-only-abstain', 'symbolic-groups-no-point-interface',
    'floating-contrast-rank-diagnostic', 'foreign-order-RuntimeError',
    'foreign-gate-StopIteration', 'foreign-groups-ValueError',
    'foreign-rank-public-control-error')


class SemanticMismatch(ValueError):
    def __init__(self, message, owner=None):
        super().__init__(message)
        self.owner = owner


def is_owned_error(error):
    return type(error) is SemanticMismatch and error.owner is _OWNER


def _need(condition, message):
    if not condition:
        raise SemanticMismatch(message, _OWNER)


class _ReadOnlyFields:
    """Absence of point methods is an intentional symbolic-interface sentinel."""
    __slots__ = ('_fields',)

    def __init__(self, **fields):
        object.__setattr__(self, '_fields', fields)

    def __getattr__(self, name):
        if name in self._fields:
            return self._fields[name]
        raise AssertionError('forbidden model/point/state field: '+name)


def run_conditional_semantic_controls(pilot_module, *, check):
    """Source-authored expectations; every call occurs inside a Root actual."""
    check()
    results = []
    P, Q, R = ['pred', 'control_p', []], ['pred', 'control_q', []], ['pred', 'control_r', []]
    p = dict(rule='axiom', name='control_p', formula=P)
    q = dict(rule='axiom', name='control_q', formula=Q)
    r = dict(rule='axiom', name='control_r', formula=R)
    prefix = [p]
    def record(identity, **evidence):
        check()
        results.append(dict(id=identity, status='PASSED', **evidence))
    def command(key):
        return {0:p, 1:q, 2:r, 3:p}[key]
    keys = [0, 1, 2, 3]
    ordered, ordinary = pilot_module._conditional_novelty_order(keys, prefix, command, [0, 2], check)
    _need(ordered == [2, 1, 0, 3] and ordinary == [1, 2, 0, 3], 'novelty must dominate hint priority')
    _need(keys == [0, 1, 2, 3] and prefix == [p], 'ordering inputs remain unchanged')
    record(CONTROL_IDS[0], ordered=ordered, ordinary=ordinary)
    repeated_keys = [0, 1, 1, 2, 0]
    ordered, ordinary = pilot_module._conditional_novelty_order(repeated_keys, prefix, command, [0, 2], check)
    _need(ordered == [2, 1, 1, 0, 0] and ordinary == [1, 1, 2, 0, 0], 'stable full multiplicity')
    record(CONTROL_IDS[1], ordered=ordered, ordinary=ordinary)
    def forbidden_command(key):
        raise AssertionError('empty order must not inspect a command')
    _need(pilot_module._conditional_novelty_order([], prefix, forbidden_command, [], check) == ([], []), 'empty original domain')
    record(CONTROL_IDS[2])

    gate_prefix = [p, copy.deepcopy(p), q]
    gate_model = _ReadOnlyFields(spec=dict(length=8))
    expected = [1.0, 3/8, 2/3, 1/3, 4/5, 1.0, 0.0, 0.0]
    values, context = pilot_module._conditional_gate_context('point', gate_prefix, gate_model, (7, 0), 4, 9, check)
    _need(values == expected and context['original_candidate_count'] == 4 and context['selected_point'] == (7, 0), 'causal command-role features')
    record(CONTROL_IDS[3], features=values)
    values, _ = pilot_module._conditional_gate_context('point', gate_prefix, gate_model, (7, 1), 4, 9, check)
    _need(values == expected[:5]+[0.0, 1.0, 0.0], 'causal guard-role features')
    record(CONTROL_IDS[4], features=values)
    values, _ = pilot_module._conditional_gate_context('symbolic', gate_prefix, gate_model, None, 4, 9, check)
    _need(values == expected[:5]+[0.0, 0.0, 1.0], 'symbolic gate may read spec length only')
    record(CONTROL_IDS[5], features=values, forbidden_point_fields_unavailable=True)
    renamed_model = _ReadOnlyFields(spec=dict(length=8, id='control_renamed',
        title='irrelevant label', target=R, future_pool='must not be a feature'))
    renamed, _ = pilot_module._conditional_gate_context('symbolic', gate_prefix, renamed_model, None, 4, 9, check)
    _need(renamed == values, 'labels, target and future metadata cannot alter pre-pool features')
    record(CONTROL_IDS[6], features=renamed)

    kc, g0, g1 = (1, 0, 0, 0), (1, 1, 0, 0), (1, 1, 0, 1)
    kd, gd0, gd1 = (2, 0, 1, 0), (2, 1, 1, 0), (2, 1, 1, 1)
    def packet(commands, members, cost, family):
        return dict(commands=copy.deepcopy(commands), members=list(members), pending=list(members),
            result_formula=copy.deepcopy(commands[-1]['formula']), incremental_validation_checks=cost,
            family=family, source_binding=[dict(kind='control', name=family)])
    first = packet([q], [kc, g0], 9, 'control_family_a')
    alias = packet([q], [kc, g0], 3, 'control_family_alias')
    guard = packet([q], [kc, g1], 5, 'control_family_guard')
    future = packet([q, r], [kc, g0, kd, gd0], 7, 'control_family_future')
    pool = dict(complete=True, packets=[first, alias, guard, future], validation_checks=15)
    saved_pool = copy.deepcopy(pool)
    model = _ReadOnlyFields(spec=dict(length=8, target=R), metadata={
        kc:dict(command=q), g0:dict(command=q), g1:dict(command=q),
        kd:dict(command=r), gd0:dict(command=r), gd1:dict(command=r)})
    limits = dict(cluster_binding_work=20)
    groups = pilot_module._conditional_groups(pool, prefix, model, [g1, g0], 'point', check, limits)
    expected_features = [
        [1.0, 1/8, 0.0, 0.0, 1.0, 0.0, 3/20]+[0.0]*5,
        [1.0, 1/8, 0.0, 0.0, 0.0, 0.0, 5/20]+[0.0]*5,
        [1.0, 2/8, 0.0, 0.0, 1.0, 1.0, 7/20]+[0.0]*5,
        [0.0]*7+[1.0, 1/8, 0.0, 15/20, 2/3]]
    _need(groups['features'] == expected_features and groups['abstain_index'] == 3, 'independent literal action features')
    _need([v['raw_packet_ordinals'] for v in groups['groups']] == [[0, 1], [2], [3]], 'merge aliases only; retain guards and future members')
    _need(groups['raw_packet_count'] == 4 and groups['executable_continuation_count'] == 3, 'raw and quotient counts differ honestly')
    _need(pool == saved_pool, 'policy quotient must not delete or mutate raw packets')
    record(CONTROL_IDS[7], grouping=groups, raw_packet_count=4)
    more = copy.deepcopy(pool)
    more['packets'].append(copy.deepcopy(alias))
    added = pilot_module._conditional_groups(more, prefix, model, [g1, g0], 'point', check, limits)
    _need(added['features'] == groups['features'] and added['executable_continuation_count'] == 3 and added['raw_packet_count'] == 5,
          'duplicate aliases must not create a family-frequency action prior')
    record(CONTROL_IDS[8], fixed_shared_cost=True, raw_packet_count=5, grouped_actions=3)
    labels = copy.deepcopy(pool)
    for ordinal, value in enumerate(labels['packets']):
        check(); value['family'] = 'changed_control_label_'+str(ordinal); value['source_binding'] = []
    labelled = pilot_module._conditional_groups(labels, prefix, model, [g1, g0], 'point', check, limits)
    _need(labelled['features'] == groups['features'], 'family/provenance labels cannot become features')
    record(CONTROL_IDS[9])
    alternative_future = packet([q, r], [kc, g0, kd, gd1], 7, 'control_other_future_guard')
    degenerate = dict(complete=True, packets=[future, alternative_future], validation_checks=15)
    same_first = pilot_module._conditional_groups(degenerate, prefix, model, [g0], 'point', check, limits)
    _need(same_first['executable_continuation_count'] == 2 and same_first['distinct_first_primitive_preferences'] == 1,
          'different future guards are distinct actions but one immediate nomination')
    _need(same_first['features'][0] == same_first['features'][1] and same_first['distinct_feature_vectors'] == 2
          and same_first['action_contrast_rank'] == 1, 'feature degeneracy is observable, not successful family learning')
    record(CONTROL_IDS[10], grouping=same_first)
    empty = pilot_module._conditional_groups(dict(complete=True, packets=[], validation_checks=0),
        prefix, model, [g0], 'point', check, limits)
    _need(empty['groups'] == [] and empty['abstain_index'] == 0 and empty['features'] == [[0.0]*7+[1.0, 1/8, 0.0, 0.0, 0.0]]
          and empty['action_contrast_rank'] == 0, 'empty complete pool has exactly one ABSTAIN action')
    record(CONTROL_IDS[11], features=empty['features'])

    symbolic_model = _ReadOnlyFields(spec=dict(length=8, target=R), domains=[[], [q, p]])
    symbolic = pilot_module._conditional_groups(pool, prefix, symbolic_model, [(1, 0), (0, 1), (0, 0)],
        'symbolic', check, limits)
    _need([v['first_primitive_preferences'] for v in symbolic['groups']] == [[(0, 0)], [(0, 1)], [(0, 0)]],
          'symbolic guard variants and ordinary domain rows are the sole preference interface')
    record(CONTROL_IDS[12], forbidden_point_fields_unavailable=True, grouping=symbolic)
    rank2 = pilot_module._conditional_feature_rank([[1.0, 0.0], [0.0, 1.0], [0.0, 0.0]], check)
    rank0 = pilot_module._conditional_feature_rank([[2.0, 3.0], [2.0, 3.0]], check)
    _need(rank2 == 2 and rank0 == 0, 'small floating action-contrast rank diagnostic')
    record(CONTROL_IDS[13], rank2=rank2, rank0=rank0, scope='Diagnostic only; no learning or conditioning theorem.')

    sentinels = [RuntimeError('foreign control'), StopIteration('foreign control'),
                 ValueError('foreign control'), SemanticMismatch('foreign public control error')]
    def invoke(which, callback):
        if which == 0:
            return pilot_module._conditional_novelty_order(keys, prefix, command, [2], callback)
        if which == 1:
            return pilot_module._conditional_gate_context('symbolic', gate_prefix, gate_model, None, 4, 9, callback)
        if which == 2:
            return pilot_module._conditional_groups(pool, prefix, model, [g1, g0], 'point', callback, limits)
        return pilot_module._conditional_feature_rank([[1.0, 0.0], [0.0, 1.0], [0.0, 0.0]], callback)
    for which, sentinel in enumerate(sentinels):
        check(); ticks = [0]
        def interrupt():
            check(); ticks[0] += 1
            if ticks[0] == 3:
                raise sentinel
        caught = None
        try:
            invoke(which, interrupt)
        except BaseException as error:
            check()
            if error is not sentinel:
                raise
            caught = error
        check()
        _need(caught is sentinel, 'exact nested foreign callback identity must escape')
        record(CONTROL_IDS[14+which], exact_identity_preserved=True, callback_ordinal=3)
    _need(tuple(value['id'] for value in results) == CONTROL_IDS, 'all eighteen declared controls retained')
    check()
    return dict(schema='D19-independent-conditional-semantic-controls-v2', complete=True,
        count=18, controls=results,
        scope='Hand-authored synthetic adapter/permutation/group/feature/interface and callback controls only. '
              'No donor/search route, Native/Host proof licence, live-cost provenance, actual policy usefulness, '
              'full Graph conformance, timing equality or resource fit is established.')
