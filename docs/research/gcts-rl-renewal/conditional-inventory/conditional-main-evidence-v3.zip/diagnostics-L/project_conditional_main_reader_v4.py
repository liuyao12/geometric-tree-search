"""Root-invoked passive D21 reader projection; never execute research code.

The explicit current Root report-state manifest supplies population disposition.
Only complete current Root-admitted records can supply accepted proofs/policies.
No directory discovery, classifier, numeric/RNG, Graph or proof replay occurs.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

STUDY = Path(__file__).resolve().parents[1]
PROTOCOL_SHA = 'c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422'
GATES = ('admitted', 'resource_admitted', 'scientific_qualified', 'stage_complete')
STATES = ('PENDING', 'AWAITING_REVIEW', 'QUALIFIED', 'FAILED', 'UNAVAILABLE_REQUIRED_STAGE')
TEMPLATE_SHA = '80ac1e2822809a6b6a99f27e0780f60c96bac9126cffedc91ed6eb3bffd5a122'
DATA_TOKEN = '@@D21_DATA_FILENAME@@'
ARCHIVE_TOKEN = '@@D21_ARCHIVE_FILENAME@@'
MANIFEST_TOKEN = '@@D21_MANIFEST_FILENAME@@'


def need(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                      allow_nan=False).encode('utf-8')


def same(left, right):
    return canonical(left) == canonical(right)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def nonfinite(value):
    raise ValueError('nonfinite JSON constant: ' + value)


class Saved:
    def __init__(self):
        self.inputs = {}

    def pin(self, path):
        path = Path(path)
        need(path.is_absolute() and path == path.resolve() and path.is_file()
             and not path.is_symlink() and path.is_relative_to(STUDY),
             'ordinary canonical current D21 file only')
        need('.partial' not in path.name, 'partial bodies are never opened')
        body = path.read_bytes()
        row = dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        need(str(path) not in self.inputs or self.inputs[str(path)] == row, 'input changed')
        self.inputs[str(path)] = row
        return row

    def load(self, row, expected=None):
        need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}
             and type(row['path']) is str and type(row['bytes']) is int
             and row['bytes'] >= 0 and type(row['sha256']) is str,
             'strict complete raw pin')
        if expected is not None:
            need(row['path'] == str(Path(expected).resolve()), 'exact current path')
        need(self.pin(row['path']) == row, 'declared raw pin changed')
        body = Path(row['path']).read_bytes()
        need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256'],
             'stable pinned complete JSON')
        return json.loads(body, object_pairs_hook=unique_object, parse_constant=nonfinite)

    def stable(self):
        for row in tuple(self.inputs.values()):
            need(self.pin(row['path']) == row, 'final raw stability')


def current_job(saved, protocol_pin, recipe, state):
    identity = recipe['stage_id']
    base = dict(stage_id=identity, stage=recipe['stage'], state=state['status'],
                reason=state['reason'], blocking_stage_ids=state['blocking_stage_ids'],
                required_upstream_ids=recipe['required_upstream_ids'], admission_source=None,
                admission=None, packet_source=None, complete_record_returned=False,
                observer_sample_seconds=None, observer_final_gate_seconds=None,
                whole_peak_bytes=None, worker_status=None, error=None, Native_started=None,
                callbacks=None)
    if state['status'] not in ('QUALIFIED', 'FAILED'):
        need(state['admission'] is None, 'undecided/unavailable job has no invented admission')
        return base, None, None
    admission_path = STUDY/'root/admission'/(identity+'-v1.json')
    admission = saved.load(state['admission'], admission_path)
    need(admission['schema'] == 'D21-Root-conditional-stage-admission-v1'
         and admission['stage_id'] == identity and admission['stage'] == recipe['stage']
         and admission['protocol'] == protocol_pin, 'exact current Root stage admission')
    need(all(type(admission[key]) is bool for key in GATES), 'four typed Root gates')
    eligible = state['status'] == 'QUALIFIED'
    need((all(admission[key] for key in GATES) if eligible
          else admission['admitted'] is False and not all(admission[key] for key in GATES)),
         'Root state equals complete qualification gates')
    plan = saved.load(admission['plan'], STUDY/'root/plans'/(identity+'-v1.json'))
    need(plan['case_id'] == identity and plan['stage'] == recipe['stage']
         and same(plan['Root_recipe'], recipe) and plan['protocol'] == protocol_pin,
         'current exact plan/recipe/protocol')
    directory = STUDY/'actual'/identity
    for key, target in [('header', directory/'worker-header.json'),
                        ('terminal', directory/'terminal.json'),
                        ('observer', STUDY/'actual'/(identity+'.observer')/'observer.json')]:
        saved.load(admission[key], target)
    review_pin = admission['C_actual_review']
    need(Path(review_pin['path']).is_relative_to(STUDY/'review-C'), 'current independent review')
    review = saved.load(review_pin)
    need(review['review_passed'] is True and review['plan'] == admission['plan'],
         'exact independently reviewed current plan')
    for key in ('header', 'terminal', 'observer'):
        need(review[key] == admission[key], 'same independent raw component')
    active = 'result' if admission.get('result') is not None else 'failure'
    packet_pin = admission[active]
    packet = saved.load(packet_pin, directory/(active+'.json'))
    need(review.get(active) == packet_pin, 'review binds active complete result/failure')
    science = packet.get('scientific_result')
    if eligible:
        need(active == 'result' and packet['status'] == 'COMPLETE' and packet['error'] is None
             and packet['source_unchanged'] is True and type(science) is dict
             and science['stage_complete'] is True and science['job_record_complete'] is True,
             'only complete admitted science supplies accepted artifacts')
        need(all(review[key] is True for key in GATES[1:]), 'independent positive stage gates')
        need(science['stage_id'] == identity and science['stage'] == recipe['stage'],
             'current returned scientific identity')
        need(same(science['native_records'], packet['native_queries']), 'same owned Native stream')
    observer = saved.load(admission['observer'])
    need(admission['whole_seconds'] == observer['elapsed_seconds']
         and admission['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'],
         'cost sample and peak exactly forwarded, including null')
    base.update(admission_source=state['admission'], admission=admission, packet_source=packet_pin,
                complete_record_returned=type(science) is dict,
                observer_sample_seconds=admission['whole_seconds'],
                observer_final_gate_seconds=observer.get('final_observer_gate_seconds'),
                whole_peak_bytes=admission['whole_peak_bytes'], worker_status=packet['status'],
                error=packet['error'], Native_started=packet['native_requests_started'],
                callbacks=packet['callbacks'])
    # An unqualified complete packet remains diagnostic; it supplies no proof/policy here.
    return base, science if eligible else None, packet if eligible else None


def accepted_proof_view(job, packet, case, record, method):
    gate = record['proof_check']; search = record['search']
    if gate['status'] != 'HOST_REGION_NATIVE_ACCEPTED':
        need(gate['native_proof_accepted'] is False, 'no accepted label for an unresolved proof')
        return None
    proof = search['proof']; spec = case['spec']; model = case['model']
    need(job['state'] == 'QUALIFIED' and all(job['admission'][k] for k in GATES)
         and type(proof) is list and gate['native_proof_accepted'] is True
         and gate['host_check']['accepted'] is True and gate['region']['complete'] is True,
         'current whole-stage/Host/full-region/Native proof gates')
    query = gate['native_record']
    need(query['result']['status'] == 'accepted' and query['request']['blocks'] == []
         and same(query['request']['proof'], proof)
         and same(query['request']['target'], spec['target'])
         and same(query['request']['theory'], spec['theory'])
         and sum(same(q, query) for q in packet['native_queries']) == 1,
         'unique current owned exact accepted blocks-empty proof request')
    need(len(proof) == spec['length'], 'original primitive row bound')
    selected = search['placements']
    need(len(selected) == len(proof)*2, 'complete command/guard selected pair per row')
    lookup = {tuple(row['key']): row for row in model['placements']}
    need(len(lookup) == len(model['placements']), 'unique original encoded candidate keys')
    tiles = []; word_ids = set(); seen = set()
    for key in selected:
        need(type(key) is list and len(key) == 4 and all(type(v) is int for v in key)
             and tuple(key) not in seen, 'distinct strict selected key')
        seen.add(tuple(key)); tile = copy.deepcopy(lookup[tuple(key)])
        row, index = tile['command_reference']
        need(same(model['domains'][row][index], proof[row]), 'saved card-to-primitive command')
        for point, value in tile['marks']:
            if point[1] == 100:
                need(type(value) is int and 0 <= value < len(model['word_dictionary']),
                     'strict whole-word ID; zero is a value, not absence')
                word_ids.add(value)
        tiles.append(tile)
    need(type(model['word_terminator']) is int and model['word_terminator'] == 256,
         'complete word terminator')
    words = {}
    for identity in sorted(word_ids):
        raw = model['word_dictionary'][identity]
        words[str(identity)] = dict(hex=raw, literal=json.loads(bytes.fromhex(raw).decode('utf-8'),
                                    object_pairs_hook=unique_object, parse_constant=nonfinite))
    return dict(id=spec['id'], stage_id=job['stage_id'], method=method, title=spec['title'],
                spec=spec, target=spec['target'], proof=proof, tiles=tiles, words=words,
                word_terminator=256, proof_check=gate, source=job['packet_source'],
                admitted_proof=True, marking_evidence=case.get('marking'),
                attribution=('Conventional symbolic S0 donor discovery; checked through the finite word-point region, Host and fresh Native. No point-search or RL discovery attribution.'
                             if job['stage'] == 'acquire' else
                             'Current admitted '+method+' record. Discovery method and selector mode are explicit; this individual certificate is not a comparative utility claim.'),
                scope='Exact saved primitive rows and base problem-defining command/guard cards. Translation-only aligned complete-word adaptation. Saved auxiliary certificate evidence is separate; no learned mark is invented on a base card.')


def search_summary(record, packet_pin, search_locator):
    search = record['search']; references = {}
    for field in ('trace', 'selector_decisions'):
        present = field in search
        value = search.get(field)
        need(not present or type(value) is list, 'saved diagnostic array carrier')
        references[field] = dict(present=present, rows=len(value) if present else None,
            canonical_sha256=hashlib.sha256(canonical(value)).hexdigest() if present else None,
            locator=search_locator+[field] if present else None)
    return dict(returned=True, search_status=search['status'],
                proof_status=record['proof_check']['status'],
                native_proof_observed=record['proof_check']['native_proof_accepted'],
                metrics=copy.deepcopy(search.get('metrics', {})),
                attempt_unit=search.get('attempt_unit'),
                selector_decisions=references['selector_decisions']['rows'],
                trace_reference=dict(packet_source=packet_pin, search_locator=search_locator,
                    arrays=references,
                    canonical_encoding='UTF-8 json.dumps(sort_keys=True,separators=(comma,colon),ensure_ascii=False,allow_nan=False)',
                    scope='Exact literal references to complete current saved arrays in the raw evidence ZIP. Missing instrumentation is null, not zero. Hashes/counts do not reconstruct decisions, full pools, preferred placements or completed clusters.'),
                full_arm_seconds=record.get('full_arm_seconds'),
                search_seconds=search.get('seconds'), terminal_snapshot=record.get('terminal_snapshot'),
                root_restored=search.get('root_restored'),
                cost_scope=record.get('cost_scope'), selection=record.get('selection'), seed=record.get('seed'))


def project(request_path):
    saved = Saved(); request_path = Path(request_path)
    prefix = 'conditional-main-reader-request-v'; suffix = '.json'
    need(request_path.parent == STUDY/'root' and request_path.name.startswith(prefix)
         and request_path.name.endswith(suffix), 'explicit canonical current numbered Root request')
    number = request_path.name[len(prefix):-len(suffix)]
    need(number.isascii() and number.isdecimal() and len(number) <= 6,
         'bounded ASCII decimal report version')
    version = int(number)
    need(3 <= version <= 999999 and str(version) == number,
         'fresh canonical report version, no aliases or old v1/v2 paths')
    request_pin = saved.pin(request_path); request = saved.load(request_pin)
    need(set(request) == {'schema', 'report_version', 'protocol', 'population', 'template'}
         and request['schema'] == 'D21-passive-main-reader-request-v3'
         and type(request['report_version']) is int and request['report_version'] == version,
         'reviewed numbered reader request ABI')
    template_pin = request['template']; template_path = STUDY/'diagnostics-L/conditional-main-v4.html'
    need(type(template_pin) is dict and set(template_pin) == {'path', 'bytes', 'sha256'}
         and template_pin['path'] == str(template_path) and type(template_pin['bytes']) is int
         and template_pin['sha256'] == TEMPLATE_SHA and saved.pin(template_path) == template_pin,
         'exact frozen reviewed reader template')
    template_body = template_path.read_bytes()
    need(hashlib.sha256(template_body).hexdigest() == TEMPLATE_SHA, 'stable template bytes')
    template_text = template_body.decode('utf-8')
    need(template_text.count(DATA_TOKEN) == 2 and template_text.count(ARCHIVE_TOKEN) == 1
         and template_text.count(MANIFEST_TOKEN) == 1, 'exact reviewed data/archive/manifest token counts')
    data_name = 'conditional-main-data-v'+number+'.json'
    html_name = 'conditional-main-report-v'+number+'.html'
    archive_name = 'conditional-main-evidence-v'+number+'.zip'
    manifest_name = 'conditional-main-manifest-v'+number+'.json'
    protocol = saved.load(request['protocol'], STUDY/'root/protocol-v1.json')
    need(request['protocol']['sha256'] == PROTOCOL_SHA
         and protocol['schema'] == 'D21-Root-conditional-family-protocol-v1', 'fixed D21 protocol')
    state = saved.load(request['population'], STUDY/'root'/('conditional-main-report-state-v'+number+'.json'))
    need(state['schema'] == 'D21-Root-main-report-state-v3'
         and type(state['report_version']) is int and state['report_version'] == version
         and state['protocol'] == request['protocol'] and type(state['closed']) is bool
         and type(state['as_of']) is str, 'explicit Root population authority')
    recipes = protocol['job_recipes']; need(len(recipes) == len(state['jobs']) == 34, 'full34 jobs')
    rows = {row['stage_id']: row for row in state['jobs']}
    need(len(rows) == 34 and set(rows) == {r['stage_id'] for r in recipes}, 'exact recipe identities')
    if state.get('C_review') is not None:
        need(Path(state['C_review']['path']).is_relative_to(STUDY/'review-C'), 'current population peer review')
        review = saved.load(state['C_review'])
        disposition = {key:value for key,value in state.items() if key != 'C_review'}
        disposition_sha256 = hashlib.sha256(canonical(disposition)).hexdigest()
        need(review['schema'] == 'D21-C-main-report-population-review-v1'
             and same(review['protocol'], request['protocol'])
             and review['population_disposition_sha256'] == disposition_sha256
             and review['review_passed'] is True,
             'typed population review binds exact protocol and full disposition')
        need(type(review['checks']) is list and len(review['checks']) > 0
             and all(type(item) is dict and item.get('passed') is True for item in review['checks'])
             and type(review['failures']) is list and review['failures'] == [],
             'population review has nonempty all-passed checks and no failures')
    if state['closed']:
        need(state.get('C_review') is not None, 'closed population needs independent review')
    documents = {phase: saved.load(pin) for phase, pin in protocol['phase_inputs'].items()}
    jobs = []; training = []; evaluation = []; proofs = []; inventory = []; policies = []
    for recipe in recipes:
        identity = recipe['stage_id']; row = rows[identity]
        need(set(row) == {'stage_id', 'stage', 'status', 'admission', 'blocking_stage_ids', 'reason'}
             and row['stage'] == recipe['stage'] and row['status'] in STATES
             and type(row['reason']) is str and type(row['blocking_stage_ids']) is list,
             'typed complete Root status row')
        need(all(type(x) is str and x in recipe['required_upstream_ids'] for x in row['blocking_stage_ids'])
             and len(set(row['blocking_stage_ids'])) == len(row['blocking_stage_ids']), 'declared blocking predecessors')
        if row['status'] == 'UNAVAILABLE_REQUIRED_STAGE':
            need(row['blocking_stage_ids'] and row['reason'], 'unavailable is explicit, not inferred from absence')
        else:
            need(not row['blocking_stage_ids'], 'only dependency-unavailable has blockers')
        if state['closed']:
            need(row['status'] not in ('PENDING', 'AWAITING_REVIEW'), 'closed manifest has no pending state')
        job, science, packet = current_job(saved, request['protocol'], recipe, row); jobs.append(job)
        if science is not None:
            need(same(science['inputs'], documents[recipe['stage']]), 'current physical input document')
        if recipe['stage'] == 'acquire' and science is not None:
            need(len(science['records']) == 1, 'one current donor per cold acquisition')
            case = science['records'][0]
            need(same(case['spec'], documents['acquire']['donors'][recipe['donor_indices'][0]]), 'declared donor')
            view = accepted_proof_view(job, packet, case, case, 'S0')
            need(view is not None, 'admitted acquisition has accepted whole donor certificate')
            proofs.append(view)
            inventory.append(dict(stage_id=identity, donor_id=case['spec']['id'], source=job['packet_source'],
                                  libraries=copy.deepcopy(science['libraries']),
                                  certificates=copy.deepcopy(science['certificates']),
                                  pairing=copy.deepcopy(science['pairing']),
                                  scope='Per-export admitted units and aliases only. Equal IDs across exports are a literal census, not an admitted merged inventory or new deduplication.'))
        if recipe['stage'] == 'train':
            actual = {}
            if science is not None:
                for case_index, case in enumerate(science['records']):
                    for episode_index, record in enumerate(case['episodes']):
                        ordinal = record['descriptor']['global_ordinal']
                        need(ordinal not in actual, 'one returned episode per global ordinal')
                        actual[ordinal] = (case, record, case_index, episode_index)
                need(set(actual) == {d['global_ordinal'] for d in recipe['episodes']}, 'all four admitted episodes')
                export = science['export']
                need(export['stage_id'] == identity and export['stage'] == 'train'
                     and export['qualified'] is True and same(export['policies'], science['policies']),
                     'only current admitted policy bundle')
                policies.append(dict(stage_id=identity, source=job['packet_source'],
                    heads={e:copy.deepcopy(p['heads']) for e,p in export['policies'].items()},
                    episodes={e:p['episodes'] for e,p in export['policies'].items()},
                    history_counts={e:len(p['history']) for e,p in export['policies'].items()},
                    bundle_sha256=hashlib.sha256(canonical(export)).hexdigest(),
                    policy_checks=copy.deepcopy(science['policy_checks']), admitted=True))
            for descriptor in recipe['episodes']:
                item = dict(stage_id=identity, descriptor=descriptor, state=row['status'], returned=False,
                            admitted_proof=False, proof_view_index=None, search_status=None, proof_status=None)
                if descriptor['global_ordinal'] in actual:
                    case, record, case_index, episode_index = actual[descriptor['global_ordinal']]
                    need(same(record['descriptor'], descriptor), 'exact current episode descriptor')
                    locator = ['scientific_result', 'records', case_index, 'episodes', episode_index, 'search']
                    item.update(search_summary(record, job['packet_source'], locator))
                    view = accepted_proof_view(job, packet, case, record, descriptor['engine']+'-learned')
                    if view is not None:
                        item.update(admitted_proof=True, proof_view_index=len(proofs)); proofs.append(view)
                training.append(item)
        if recipe['stage'] == 'evaluate':
            arms = {}; case = None
            if science is not None:
                need(len(science['records']) == 1 and science['policies_updated'] is False, 'one frozen-policy case')
                case = science['records'][0]
                need(case['spec']['id'] == recipe['case_id']
                     and [a['id'] for a in case['arms']] == recipe['method_order'], 'all eight original ordered methods')
                arms = {a['id']:a for a in case['arms']}; need(len(arms) == 8, 'distinct eight-arm records')
            for index, method in enumerate(recipe['method_order']):
                item = dict(stage_id=identity, case_id=recipe['case_id'], order_label=recipe['order_label'],
                            stratum=recipe['stratum'], method=method, source_index=index,
                            rng_seeds=recipe['rng_seeds'], state=row['status'], returned=False,
                            admitted_proof=False, proof_view_index=None, search_status=None, proof_status=None)
                if method in arms:
                    record = arms[method]
                    locator = ['scientific_result', 'records', 0, 'arms', index, 'search']
                    item.update(search_summary(record, job['packet_source'], locator))
                    view = accepted_proof_view(job, packet, case, record, method)
                    if view is not None:
                        item.update(admitted_proof=True, proof_view_index=len(proofs)); proofs.append(view)
                evaluation.append(item)
    need(len(training) == 32 and len(evaluation) == 192, 'full32/192 denominators')
    seconds = 0.0
    for job in jobs:
        if job['observer_sample_seconds'] is not None:
            seconds += job['observer_sample_seconds']
    summary = dict(planned_jobs=34, job_states={key:sum(j['state'] == key for j in jobs) for key in STATES},
                   training_episode_slots=32, training_records_returned=sum(t['returned'] for t in training),
                   evaluation_slots=192, evaluation_records_returned=sum(e['returned'] for e in evaluation),
                   evaluation_proofs_admitted=sum(e['admitted_proof'] for e in evaluation),
                   evaluation_search_unknown=sum(e['returned'] and e['search_status'] == 'unknown_search_budget' for e in evaluation),
                   admitted_proof_occurrences=len(proofs), admitted_policy_bundles=len(policies),
                   unavailable_is_not_UNKNOWN=True)
    output = dict(schema='D21-passive-conditional-main-reader-v3', report_version=version, as_of=state['as_of'], closed=state['closed'],
        protocol_source=request['protocol'], population_source=request['population'], request_source=request_pin,
        rendering=dict(template_source=template_pin, data_filename=data_name, html_filename=html_name,
                       archive_filename=archive_name, manifest_filename=manifest_name),
        summary=summary, jobs=jobs, training=training, evaluation=evaluation, proofs=proofs,
        inventory=inventory, policies=policies, documents=documents,
        decided_unique_observer_sample_seconds=seconds,
        cost_scope='Unique decided cold jobs counted once, including whole failures when their observer sample exists. Pending/awaiting costs stay unavailable. Observer samples are not tool end-to-end. Setup, marking, entry, selector, search, proof-check and custody brackets overlap and are not summed as separate phases. Per-arm clocks are marginal shared-setup measurements, not standalone solver cost.',
        scope='Current complete saved JSON and exact Root/C raw pins only. No new admission, proof/family inference, policy arithmetic, RNG, classifier, search, Graph, compiler or Native replay. Fixed/uniform/learned comparisons must use eligible current records, common inventory/marking and within-engine units. Public authored input-structure holdouts are not blind or proof-DAG-disjoint. Domain results never feed the main learner.',
        open_gaps=['physical universal Wang encoding','whole-plane coverage','induction-based Peano arithmetic','full Hilbert geometry','Turtle/Penrose generality','learned utility/external prover comparison'],
        scientific_imports=0, scientific_calls=0, partial_files_parsed=0)
    saved.stable(); output['input_pins'] = sorted(saved.inputs.values(), key=lambda p:p['path'])
    destination = STUDY/'publication'/data_name
    html_destination = STUDY/'publication'/html_name
    need(destination.parent.is_dir() and not destination.parent.is_symlink()
         and destination.parent == destination.parent.resolve(),
         'Root creates the canonical current publication directory separately')
    need(not destination.exists() and not html_destination.exists(),
         'both fresh report artifacts require exclusive non-overwriting creation')
    html_body = (template_text.replace(DATA_TOKEN, data_name).replace(ARCHIVE_TOKEN, archive_name)
                 .replace(MANIFEST_TOKEN, manifest_name).encode('utf-8'))
    data_body = (json.dumps(output, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+'\n').encode()
    with destination.open('xb') as stream:
        stream.write(data_body)
    with html_destination.open('xb') as stream:
        stream.write(html_body)
    artifacts = []
    for path in (destination, html_destination):
        body = path.read_bytes()
        artifacts.append(dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest()))
    saved.stable()
    print(json.dumps(dict(report_version=version, artifacts=artifacts)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    project(Path(parser.parse_args().request))
