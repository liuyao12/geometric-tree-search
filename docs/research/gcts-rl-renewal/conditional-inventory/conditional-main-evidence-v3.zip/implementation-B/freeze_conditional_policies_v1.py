"""Root-only passive final-policy chain audit, never a new policy export."""
import argparse
from pathlib import Path
import conditional_passive_phase_support_v1 as support

VERSION = 'D21-passive-final-policy-freeze-v1'


def main(request_path):
    base = support.base; io = base.Inputs(); study = support.STUDY
    request_path = Path(request_path)
    support.need(request_path == study / 'root/final-policy-freeze-request-v1.json', 'fixed fresh Root request')
    request_pin = base.rawpin(request_path); request = io.load(request_pin)
    support.need(set(request) == {'schema', 'protocol', 'upstream', 'C_policy_review'}
                 and request['schema'] == 'D21-passive-final-policy-freeze-request-v1', 'strict audit request')
    helper = base.rawpin(Path(__file__).resolve()); io.verify(helper)
    protocol = support.protocol_gate(io, request['protocol'])
    receipts, exports, joins, context = support.chain_join(io, request['protocol'], protocol, request['upstream'])
    bundle = support.final_bundle_join(protocol, request['upstream'], receipts, exports, context)
    support.need(Path(request['C_policy_review']['path']).is_relative_to(study / 'review-C'), 'independent current final policy review')
    review = io.load(request['C_policy_review']); support.passed_review(review)
    support.need(review['schema'] == 'D21-C-final-policy-freeze-review-v1'
        and support.same(review['protocol'], request['protocol'])
        and review['predecessor_pairs_sha256'] == bundle['predecessor_pairs_sha256']
        and support.same(review['final_train_result'], bundle['final_train_result'])
        and review['final_policy_export_sha256'] == bundle['final_policy_export_sha256']
        and support.same(review['bundle'], bundle), 'independent exact complete ten-stage policy audit')
    seconds = 0.0
    for receipt in receipts:
        seconds += receipt['whole_seconds']
    output = dict(schema='D21-Root-final-policy-freeze-v1', audit_only=True, audit_complete=True,
        protocol=request['protocol'], predecessors=request['upstream'], required_stage_ids=support.PREDECESSORS,
        bundle=bundle, C_policy_review=request['C_policy_review'], request=request_pin, helper=helper,
        literal_provenance=joins, unique_predecessor_observer_seconds=seconds,
        cost_scope='Ten current direct observer samples once each. Audit/output overhead and D20 qualification remain distinct; no overlapping entry/arm clock addition or tool end-to-end claim.',
        scope='Current train7 export remains the sole worker policy payload. This Root audit adds no child guard/input, scientific qualification, policy update/export or stage seal. Exact numeric/RNG/reward/checker verification remains inside admitted actuals.',
        scientific_imports=0, scientific_calls=0, numeric_RNG_Graph_checker_replays=0, partial_files_parsed=0)
    target = study / 'root/final-policy-freeze-v1.json'
    support.need(not target.exists(), 'exclusive immutable final audit')
    io.stable()
    with target.open('xb') as stream:
        stream.write(base.canonical(output) + b'\n')
    print(base.canonical(base.rawpin(target)).decode('utf-8'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    main(Path(parser.parse_args().request).resolve())
