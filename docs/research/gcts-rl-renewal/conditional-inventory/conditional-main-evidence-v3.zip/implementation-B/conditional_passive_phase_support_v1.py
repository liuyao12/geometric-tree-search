"""D21 passive literal provenance support; no research or numeric replay.

Imported only by future Root passive authors after exact Source/request review.
The reviewed D21 v2 helper supplies raw/custody/proposal primitives only.
"""
from pathlib import Path
import admit_conditional_stage_v2 as base

VERSION = 'D21-passive-final-and-evaluation-support-v1'
STUDY = Path(__file__).resolve().parents[1]
PROTOCOL_SHA = 'c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422'
BASE_SHA = 'bc54a888d14222b038477776f10f71416e913282b72b628dc78a6183f5b6be20'
PREDECESSORS = ['acquire-0', 'acquire-1'] + ['train-' + str(i) for i in range(8)]
METHODS = ['S0', 'SF', 'SU', 'SR', 'P0', 'PF', 'PU', 'PR']
COMPONENTS = ('plan', 'result', 'header', 'terminal', 'observer')
need, same, digest = base.need, base.same, base.digest


def protocol_gate(io, pin):
    need(Path(base.__file__).resolve() == STUDY / 'implementation-B/admit_conditional_stage_v2.py'
         and base.rawpin(Path(base.__file__).resolve())['sha256'] == BASE_SHA,
         'exact reviewed D21 passive base, never an old generic sealer')
    io.verify(base.rawpin(Path(__file__).resolve()))
    io.verify(base.rawpin(Path(base.__file__).resolve()))
    need(pin['path'] == str(STUDY / 'root/protocol-v1.json') and pin['sha256'] == PROTOCOL_SHA,
         'exact frozen current protocol')
    protocol = io.load(pin)
    need(protocol['schema'] == 'D21-Root-conditional-family-protocol-v1'
         and protocol['experiment'] == 'D21-conditional-family-selector-v1'
         and same(protocol['limits'], base.CAPS) and same(protocol['experiment_limits'], base.LOCAL)
         and protocol['entry']['sha256'] == base.ENTRY_SHA and protocol['methods'] == METHODS
         and protocol['engines'] == ['symbolic', 'point'], 'unchanged Source/caps/methods')
    io.verify(protocol['entry'])
    recipes = protocol['job_recipes']
    need(type(recipes) is list and len(recipes) == 34
         and [r['stage_id'] for r in recipes[:10]] == PREDECESSORS
         and [r['stage'] for r in recipes[:10]] == ['acquire'] * 2 + ['train'] * 8
         and all(r['stage'] == 'evaluate' and r['required_upstream_ids'] == PREDECESSORS
                 for r in recipes[10:]) and len({r['stage_id'] for r in recipes}) == 34,
         'all prescribed two/eight/twenty-four stages')
    return protocol


def passed_review(review):
    need(review['review_passed'] is True and type(review['checks']) is list and review['checks']
         and all(type(row) is dict and row.get('passed') is True for row in review['checks'])
         and type(review['failures']) is list and review['failures'] == [],
         'nonempty all-passed independent receipt')


def controls_join(science, stage):
    controls = science['controls']
    required = ('numeric', 'word', 'graph', 'encoding', 'principal', 'matched_symbolic',
                'conditional_numeric', 'conditional_semantic')
    for name in required:
        need(controls[name]['complete'] is True, 'complete applicable control bank ' + name)
    need(controls['inherited']['status'] == 'complete', 'complete inherited diagnostics')
    if stage == 'train':
        need(controls['conditional_corpus_status'] == 'COMPLETE_TRAINING_ONLY_CONTROLS'
             and controls['conditional_corpus']['complete'] is True, 'complete training-only controls')
    else:
        need(controls['conditional_corpus'] is None
             and controls['conditional_corpus_status'] == 'NOT_REQUESTED_FOR_THIS_PHASE',
             'no evaluation/training-input leakage through corpus controls')
    if stage == 'acquire':
        for name in ('guard_resolver', 'guard_differential', 'native_batch', 'reference_setup_calibration'):
            need(controls[name]['complete'] is True, 'fresh acquisition-only control ' + name)


def whole_stage(io, protocol_pin, protocol, components, review_pin, identity):
    """Read only explicitly pinned complete bodies; no admission or execution."""
    need(set(components) == set(COMPONENTS), 'five complete custody component pins')
    plan = io.load(components['plan']); recipe = next(r for r in protocol['job_recipes'] if r['stage_id'] == identity)
    stage = recipe['stage']; actual = STUDY / 'actual' / identity
    paths = dict(plan=STUDY / 'root/plans' / (identity + '-v1.json'), result=actual / 'result.json',
                 header=actual / 'worker-header.json', terminal=actual / 'terminal.json',
                 observer=STUDY / 'actual' / (identity + '.observer') / 'observer.json')
    need(all(components[name]['path'] == str(paths[name]) for name in COMPONENTS)
         and plan['case_id'] == identity and plan['stage'] == stage and plan['actual_dir'] == str(actual)
         and plan['experiment'] == protocol['experiment'] and same(plan['protocol'], protocol_pin)
         and same(plan['Root_recipe'], recipe) and plan['required_upstream_ids'] == recipe['required_upstream_ids']
         and same(plan['limits'], base.CAPS) and same(plan['experiment_limits'], base.LOCAL)
         and plan['entry_path'] == protocol['entry']['path'], 'exact current plan/recipe/paths/caps')
    guards = plan['files']
    need(type(guards) is list and len({r['path'] for r in guards}) == len(guards)
         and protocol['entry'] in guards and protocol['phase_inputs'][stage] in guards
         and plan['input_path'] == protocol['phase_inputs'][stage]['path'], 'complete unique current Source guards')
    for row in guards:
        io.verify(row)
    document = io.load(protocol['phase_inputs'][stage])
    worker, header, terminal, observer = [io.load(components[name]) for name in ('result', 'header', 'terminal', 'observer')]
    science = worker['scientific_result']
    need(worker['case_id'] == header['case_id'] == terminal['case_id'] == observer['case_id'] == identity
         and worker['stage'] == stage and worker['status'] == header['status'] == 'COMPLETE'
         and worker['source_unchanged'] is header['source_unchanged'] is True
         and worker['first_Root_fault'] is header['first_Root_fault'] is False
         and worker['error'] is None and type(science) is dict
         and science['stage_id'] == identity and science['stage'] == stage
         and science['stage_complete'] is science['job_record_complete'] is True
         and science['resource_admitted'] is False and same(science['inputs'], document)
         and same(science['limits'], base.LOCAL), 'complete live science, never whole-prefix salvage')
    need(header['native_closed_and_reaped'] is True and same(header['result'], components['result'])
         and terminal['process_exit_code'] == observer['parent_exit_code'] == 0
         and terminal['header_valid'] is terminal['sources_unchanged'] is terminal['threads_terminal'] is True
         and terminal['final_custody_gate_passed'] is observer['resource_candidate_accepted'] is True
         and terminal['errors'] == observer['errors'] == [] and terminal['reason'] is observer['reason'] is None
         and same(terminal['header'], header) and same(terminal['result'], components['result'])
         and base.finite(terminal['known_exit_seconds']) and terminal['known_exit_seconds'] <= base.CAPS['positive_seconds']
         and base.finite(terminal['final_custody_gate_seconds']) and terminal['final_custody_gate_seconds'] <= base.CAPS['custody_seconds']
         and base.finite(observer['final_observer_gate_seconds']) and observer['final_observer_gate_seconds'] <= base.CAPS['custody_seconds']
         and base.finite(observer['elapsed_seconds']) and observer['fallback_trigger_seconds'] is None
         and observer['owned_child']['plan_sha256'] == components['plan']['sha256']
         and terminal['memory_terminal_output_reserve_bytes'] == observer['final_output_memory_reserve_bytes'] == base.CAPS['reserved_outer_bytes']
         and components['result']['bytes'] <= base.CAPS['result_bytes']
         and terminal['stored_bytes_before_terminal_receipt'] <= base.CAPS['physical_bytes']
         and observer['stored_bytes_before_observer_receipt'] + observer['receipt_allowance_bytes'] <= base.CAPS['physical_bytes']
         and base.integer(observer['final_conservative_whole_peak_bytes'])
         and observer['final_conservative_whole_peak_bytes'] < base.CAPS['memory_bytes'], 'original complete custody/resource gates')
    for owner in (terminal, observer):
        for log in owner['logs'].values():
            need(log['eof'] is True and log['overflow'] is False and base.integer(log['bytes'])
                 and log['bytes'] == log['stored'] <= base.CAPS['log_bytes'], 'complete bounded logs')
    need(Path(review_pin['path']).is_relative_to(STUDY / 'review-C'), 'current independent actual review')
    review = io.load(review_pin); passed_review(review)
    returned = science['export']; need(type(returned) is dict, 'complete actual returned export/summary')
    need(review['schema'] == 'D21-C-conditional-stage-actual-review-v1'
         and review['stage_id'] == identity and review['stage'] == stage
         and all(review[key] is True for key in ('resource_admitted', 'scientific_qualified', 'stage_complete'))
         and same(review['protocol'], protocol_pin) and all(same(review[k], components[k]) for k in COMPONENTS)
         and review['export_sha256'] == digest(returned)
         and same(sorted(review['input_pins'], key=lambda r:r['path']), sorted(guards, key=lambda r:r['path']))
         and review['Root_admission_issued'] is False and type(review['partial_files_parsed']) is int
         and review['partial_files_parsed'] == 0 and same(review['whole_seconds'], observer['elapsed_seconds'])
         and review['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'], 'exact current C actual ABI')
    census = review['complete_actual_file_census']
    need(type(census) is list and census == sorted(census, key=lambda r:r['path'])
         and len({r['path'] for r in census}) == len(census), 'canonical complete actual file census')
    for row in census:
        p = io.verify(row)
        need(p.is_relative_to(actual) or p.is_relative_to(paths['observer'].parent), 'current actual/observer census only')
    need(all(components[k] in census for k in ('result', 'header', 'terminal', 'observer')), 'all core actual files in census')
    queries = base.native_records(worker)
    need(same(science['native_records'], queries), 'owned Native complete stream')
    controls_join(science, stage)
    return dict(plan=plan, recipe=recipe, document=document, worker=worker, science=science,
                header=header, terminal=terminal, observer=observer, review=review, census=census, queries=queries)


def direct_costs(science, receipts):
    seconds = 0.0
    for receipt in receipts:
        seconds += receipt['whole_seconds']
    costs = science['cumulative_costs']
    need(same(costs['receipts'], receipts) and costs['stage_ids'] == [r['stage_id'] for r in receipts]
         and same(costs['whole_seconds'], seconds)
         and costs['maximum_prior_whole_peak_bytes'] == max((r['whole_peak_bytes'] for r in receipts), default=0),
         'ordered direct observer cost fold, each predecessor once')
    return seconds


def chain_join(io, protocol_pin, protocol, upstream):
    need(type(upstream) is list and len(upstream) == 10, 'exact full ten-stage chain')
    receipts = []; exports = []; joins = []; final_context = None
    for position, (identity, pair) in enumerate(zip(PREDECESSORS, upstream)):
        need(type(pair) is dict and set(pair) == {'admission', 'seal'}, 'explicit current predecessor pair')
        need(pair['admission']['path'] == str(STUDY / 'root/admission' / (identity + '-v1.json'))
             and pair['seal']['path'] == str(STUDY / 'root/seals' / (identity + '-v1.json')), 'fixed current pair paths')
        admission = io.load(pair['admission']); seal = io.load(pair['seal'])
        stage = 'acquire' if position < 2 else 'train'
        need(admission['schema'] == 'D21-Root-conditional-stage-admission-v1'
             and admission['stage_id'] == seal['stage_id'] == identity and admission['stage'] == seal['stage'] == stage
             and all(admission[k] is True for k in ('admitted', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
             and same(admission['protocol'], protocol_pin) and same(admission['seal'], pair['seal'])
             and set(seal) == base.ENVELOPE and seal['resource_admitted'] is seal['stage_complete'] is True
             and seal['prior_cost_receipts'] == [], 'current whole qualified direct seal only')
        components = {name:seal[name] for name in COMPONENTS}
        need(all(same(admission[name], components[name]) for name in COMPONENTS), 'admission/seal custody identity')
        context = whole_stage(io, protocol_pin, protocol, components, admission['C_actual_review'], identity)
        science, observer = context['science'], context['observer']; exported = science['export']
        need(exported['stage_id'] == identity and exported['stage'] == stage and exported['qualified'] is True
             and admission['export_sha256'] == seal['export_sha256'] == digest(exported)
             and same(admission['whole_seconds'], seal['whole_seconds'])
             and same(seal['whole_seconds'], observer['elapsed_seconds'])
             and admission['whole_peak_bytes'] == seal['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'],
             'sealed full qualified actual bundle and direct cost')
        expected = [] if stage == 'acquire' else PREDECESSORS[:position]
        need(context['recipe']['required_upstream_ids'] == expected
             and same(context['plan']['upstream_receipts'], [p['seal'] for p in upstream[:position]] if stage == 'train' else []),
             'each stage consumed every prescribed earlier seal')
        direct_costs(science, receipts if stage == 'train' else [])
        if stage == 'acquire':
            join = base.acquisition_join(science, context['queries'], context['recipe'])
        else:
            join = base.training_join(science, context['document'], context['recipe'], exports[:2],
                exports[-1] if position > 2 else None, receipts, context['worker'], context['queries'])
        joins.append(dict(stage_id=identity, actual_review=admission['C_actual_review'], literal_join=join))
        receipts.append(seal); exports.append(exported)
        if position == 9:
            final_context = context
    return receipts, exports, joins, final_context


def final_bundle_join(protocol, upstream, receipts, exports, context):
    final = exports[-1]; science = context['science']; policies = final['policies']
    need(final['stage_id'] == 'train-7' and final['qualified'] is True
         and final['prior_policy_export_sha256'] == receipts[-2]['export_sha256']
         and same(final['cost_receipts'], receipts[:-1]) and same(final['policies'], science['policies'])
         and final['acquisition_exports'] == [digest(v) for v in exports[:2]]
         and set(policies) == {'symbolic', 'point'} and len(final['episode_bindings']) == 32,
         'final complete train7 bundle, not a new export')
    for prior in exports[2:]:
        need(prior['library_sha256'] == final['library_sha256']
             and prior['training_document_sha256'] == final['training_document_sha256']
             and same(prior['training_document'], final['training_document'])
             and same(prior['acquisition_exports'], final['acquisition_exports']),
             'unchanged paired fresh acquisitions/library/training document through every policy stage')
    declared = [row for recipe in protocol['job_recipes'][2:10] for row in recipe['episodes']]
    for ordinal, (binding, descriptor) in enumerate(zip(final['episode_bindings'], declared)):
        need(binding['global_ordinal'] == ordinal and all(same(binding[k], descriptor[k]) for k in descriptor)
             and binding['stage_id'] == 'train-' + str(ordinal // 4), 'all thirty-two prescribed binding identities')
        history = policies[binding['engine']]['history'][binding['index']]
        need(binding['episode_sha256'] == digest(history['episode'])
             and binding['selector_decisions_sha256'] == digest(history['episode']['decisions']), 'exact final history/binding link')
    for engine in ('symbolic', 'point'):
        policy = policies[engine]
        need(policy['engine'] == engine and policy['episodes'] == len(policy['history']) == 16
             and science['policy_checks'][engine]['complete'] is True
             and same(policy['heads'], {name:policy['history'][-1]['heads'][name]['postupdate'] for name in ('gate', 'continuation')}),
             'both sixteen-episode actual-verified final heads')
    return dict(final_train_result=receipts[-1]['result'], final_policy_export_sha256=digest(final),
                policies_sha256=digest(policies), episode_bindings_sha256=digest(final['episode_bindings']),
                predecessor_pairs_sha256=digest(upstream), engines=['symbolic', 'point'],
                acquisition_export_sha256=[digest(v) for v in exports[:2]],
                library_sha256=final['library_sha256'], training_document_sha256=final['training_document_sha256'],
                entry_sha256=protocol['entry']['sha256'],
                history_sha256={engine:digest(policies[engine]['history']) for engine in ('symbolic', 'point')},
                heads_sha256={engine:digest(policies[engine]['heads']) for engine in ('symbolic', 'point')},
                episodes_per_engine=16, global_bindings=32,
                scope='Passive literal chain audit only; numeric/RNG/reward/State identity verification belongs to admitted actuals and C reviews.')


def frozen_audit(io, pin, protocol_pin, upstream, bundle):
    need(pin['path'] == str(STUDY / 'root/final-policy-freeze-v1.json'), 'fixed Root final-policy audit path')
    audit = io.load(pin)
    need(audit['schema'] == 'D21-Root-final-policy-freeze-v1' and audit['audit_complete'] is True
         and audit['audit_only'] is True and same(audit['protocol'], protocol_pin)
         and audit['required_stage_ids'] == PREDECESSORS
         and same(audit['predecessors'], upstream) and same(audit['bundle'], bundle), 'current exact full-chain freeze audit')
    need(audit['helper']['path'] == str(STUDY / 'implementation-B/freeze_conditional_policies_v1.py')
         and audit['request']['path'] == str(STUDY / 'root/final-policy-freeze-request-v1.json')
         and Path(audit['C_policy_review']['path']).is_relative_to(STUDY / 'review-C'), 'current audit author/request/review paths')
    io.verify(audit['helper']); request = io.load(audit['request'])
    need(request['schema'] == 'D21-passive-final-policy-freeze-request-v1'
         and same(request['protocol'], protocol_pin) and same(request['upstream'], upstream)
         and same(request['C_policy_review'], audit['C_policy_review']), 'frozen audit uses exact original request')
    review = io.load(audit['C_policy_review']); passed_review(review)
    need(review['schema'] == 'D21-C-final-policy-freeze-review-v1'
         and same(review['protocol'], protocol_pin)
         and review['predecessor_pairs_sha256'] == digest(upstream)
         and review['final_policy_export_sha256'] == bundle['final_policy_export_sha256']
         and same(review['final_train_result'], bundle['final_train_result'])
         and same(review['bundle'], bundle), 'independent exact final-policy chain review')
    return audit
