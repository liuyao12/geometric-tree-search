"""Root passive positive eight-arm evaluation admission; no evaluation seal.

This checks literal current saved evidence. It never runs a learner, RNG,
scientific checker, compiler, Graph, miner, model, or proof reconstruction.
"""
import argparse
from pathlib import Path
import conditional_passive_phase_support_v1 as support

VERSION = 'D21-passive-eight-method-evaluation-admission-v1'


def permutation(left, right):
    return sorted(support.base.canonical(v) for v in left) == sorted(support.base.canonical(v) for v in right)


def fallback_join(search, engine, conditional):
    base = support.base; trace = search['trace']; ordered = {}; decisions = {}
    support.need(search['root_restored'] is True
        and search['attempt_unit'] == ('primitive proof-row extension' if engine == 'symbolic' else 'primitive point placement'),
        'exact root rollback and within-engine attempt units')
    for ordinal, event in enumerate(trace):
        if event['event'] == 'decision':
            decisions[ordinal] = event
            if engine == 'symbolic':
                if conditional and event['ordering_complete'] is False:
                    support.need(event['ordered_candidates'] is None and search['status'] == 'unknown_search_budget'
                        and trace[-1]['event'] == 'cutoff'
                        and not any(e['event'] in ('decision', 'extend') for e in trace[ordinal+1:]),
                        'final unfinished carrier never admits an extension')
                else:
                    support.need(permutation(event['ordered_candidates'], event['original_candidates']),
                        'full symbolic original candidate/guard multiplicity')
                    ordered[ordinal] = event['ordered_candidates']
        elif event['event'] == 'order':
            support.need(engine == 'point' and event['decision'] in decisions
                and event['decision'] not in ordered, 'one saved point ordering at the same Graph decision')
            decision = decisions[event['decision']]
            support.need(permutation(event['alternatives'], decision['original_alternatives']), 'full original point fallback multiplicity')
            if decision['kind'] == 'forced':
                support.need(support.same(event['alternatives'], decision['original_alternatives']), 'forced alternatives unchanged')
            ordered[event['decision']] = event['alternatives']
        elif event['event'] in ('extend', 'place'):
            node = event['decision']; support.need(node in ordered, 'placement only after saved complete ordering')
            key = [event['skeleton'], event['variant']] if engine == 'symbolic' else event['key']
            support.need(any(support.same(key, value) for value in ordered[node]), 'actual primitive extension in original complete alternatives')
    if engine == 'point':
        audits = search['domain_audits']
        support.need(type(audits) is list and len(audits) <= base.LOCAL['domain_audits']
                     and all(row['complete'] is True for row in audits), 'all returned full domain/incidence/scheduler audits')
    return dict(decisions=len(decisions), completed_orderings=len(ordered),
                scope='Literal fallback permutation/member and returned audit checks, never Graph/guard/novelty replay.')


def selected_proof_join(case, record, queries):
    base = support.base; base.proof_join(case['spec'], record, queries)
    proof = record['search']['proof']
    if proof is None:
        support.need(record['proof_check']['status'] == 'NO_PROOF_CANDIDATE', 'local bounded/exhausted result is not proof')
        return False
    keys = record['search']['placements']; model = case['model']; receipt = record['proof_check']['region']
    support.need(len(proof) == case['spec']['length'] and len(keys) == 2 * len(proof)
        and len({base.canonical(key) for key in keys}) == len(keys)
        and receipt['selected_placements'] == len(keys) and receipt['decoded_rows'] == len(proof),
        'whole primitive proof/full-region placement counts')
    catalog = {base.canonical(row['key']):row for row in model['placements']}
    support.need(len(catalog) == len(model['placements']), 'unique literal original model keys')
    for row, command in enumerate(proof):
        selected = [key for key in keys if key[0] == row]
        commands = [key for key in selected if key[1] == 0]; guards = [key for key in selected if key[1] == 1]
        support.need(len(commands) == len(guards) == 1 and commands[0][2] == guards[0][2]
            and all(base.canonical(key) in catalog for key in selected)
            and support.same(model['domains'][row][commands[0][2]], command)
            and all(support.same(catalog[base.canonical(key)]['command_reference'], [row, key[2]]) for key in selected)
            and command['rule'] not in ('block', 'assumption'), 'exact returned primitive command/guard owner projection')
    return True


def evaluation_join(context, protocol, receipts, exports):
    base = support.base; science = context['science']; recipe = context['recipe']; document = context['document']
    final = exports[-1]; policies = final['policies']; summary = science['export']
    support.need(science['status'] == 'EVALUATION_EIGHT_METHOD_RECORD' and science['all_eight_searched'] is True
        and science['policies_updated'] is False and science['evaluation_seed'] == recipe['order_label']
        and len(science['records']) == 1 and science['policy_check']['complete'] is True
        and science['policy_check']['shards'] == 8 and science['policy_check']['episodes'] == 32
        and science['acquisition_check']['complete'] is True
        and final['library_sha256'] == support.digest(science['library']), 'whole eight-method frozen-policy evaluation')
    for engine in ('symbolic', 'point'):
        support.need(science['policy_check']['policies'][engine]['complete'] is True, 'in-actual verified frozen engine policy')
    case = science['records'][0]; spec = case['spec']
    matches = [s for s in document['evaluation'] if s['id'] == recipe['case_id']]
    support.need(len(matches) == 1 and support.same(spec, matches[0])
        and document['protocol']['arm_order'][spec['id']][str(recipe['order_label'])] == recipe['method_order']
        and support.same(document['protocol']['rng_seeds'][spec['id']][str(recipe['order_label'])], recipe['rng_seeds'])
        and recipe['order_label'] in document['protocol']['evaluation_seeds']
        and [arm['id'] for arm in case['arms']] == recipe['method_order']
        and len(case['arms']) == 8 and set(recipe['method_order']) == set(support.METHODS),
        'original case/order/RNG labels and all eight exact slots')
    support.need(case['reference_check']['complete'] is case['word_model_check']['complete'] is True
        and case['guard_acquisition_check']['complete'] is True and case['model']['arity'] == 0
        and type(case['model']['word_terminator']) is int and case['model']['word_terminator'] == 256
        and case['marking']['marking_certificate_check']['complete'] is True
        and case['marking']['marked_extension_check']['complete'] is True
        and case['diagnostic_ground_registry'] is None, 'fresh full word/guard/marked model receipt gates')
    snapshots = base.SnapshotJoin(context['worker']['work_snapshots']); joined = []; accepted = []
    for record in case['arms']:
        method = record['id']; engine = 'symbolic' if method[0] == 'S' else 'point'
        mode = {'0':'none', 'F':'fixed', 'U':'uniform', 'R':'learned'}[method[1]]
        support.need(record['engine'] == engine and record['selection'] == mode
            and record['seed'] == recipe['rng_seeds'][engine] and record['execution_status'] == 'SEARCH_RETURNED'
            and record['certified_markings'] is (engine == 'point')
            and record['problem_defining_word_structure_marks'] is True
            and record['cluster_ordering'] is (mode != 'none'), 'matched original method and shared marking scope')
        search = record['search']; decisions = search.get('selector_decisions', [])
        for decision in decisions:
            head = decision['head']; action = decision['action']
            support.need(head in ('gate', 'continuation') and action['mode'] == mode
                and support.same(action['weights'], policies[engine]['heads'][head]['weights']),
                'each actual action uses exact frozen head without update')
        if mode == 'none':
            support.need(decisions == [] and search['cluster_ordering'] is False, 'no-library control has no selector actions')
            snapshots.consume(record['terminal_snapshot']); selector = []
        else:
            selector = base.decisions_join(case, record, snapshots)
        fallback = fallback_join(search, engine, mode != 'none')
        is_accepted = selected_proof_join(case, record, context['queries'])
        if is_accepted:
            accepted.append(method)
        joined.append(dict(method=method, engine=engine, selection=mode, selector=selector,
            fallback=fallback, proof_accepted=is_accepted, search_status=search['status'], proof_status=record['proof_check']['status']))
    expected_summary = dict(schema=final['schema'], stage='evaluate', stage_id=science['stage_id'],
        case_id=spec['id'], seed=recipe['order_label'], library_sha256=support.digest(science['library']),
        final_policy_export_sha256=support.digest(final), acquisition_exports=[support.digest(v) for v in exports[:2]],
        outcomes=[dict(id=arm['id'], search_status=arm['search']['status'], proof_status=arm['proof_check']['status']) for arm in case['arms']])
    support.need(support.same(summary, expected_summary), 'exact actual eight-outcome summary, never a qualified policy export')
    support.direct_costs(science, receipts)
    return dict(arms=joined, accepted_methods=accepted, returned_summary_sha256=support.digest(summary),
        returned_summary_scope='Exact science.export evaluation outcome summary; not a learned policy, new inference or upstream seal.',
        frozen_policy_heads_sha256=support.digest({e:policies[e]['heads'] for e in ('symbolic', 'point')}),
        used_snapshot_ordinals=snapshots.used,
        unused_snapshot_count=len(context['worker']['work_snapshots'])-len(snapshots.used),
        scope='Current whole eight-arm literal record/pool/context/fallback/Native/proof/snapshot provenance. Unused genuine snapshots and final owned-cutoff unfinished carriers do not admit prefixes. No scientific or numeric/RNG replay.')


def main(request_path):
    base = support.base; io = base.Inputs(); study = support.STUDY
    request_path = Path(request_path); request_pin = base.rawpin(request_path); request = io.load(request_pin)
    support.need(request_path.is_relative_to(study / 'root')
        and set(request) == {'schema', 'protocol', 'plan', 'result', 'header', 'terminal', 'observer',
                             'C_actual_review', 'upstream', 'policy_freeze'}
        and request['schema'] == 'D21-passive-evaluation-admission-request-v1', 'strict fresh evaluation request')
    helper = base.rawpin(Path(__file__).resolve()); io.verify(helper)
    protocol = support.protocol_gate(io, request['protocol'])
    components = {name:request[name] for name in support.COMPONENTS}
    plan = io.load(request['plan']); identity = plan['case_id']
    support.need(plan['stage'] == 'evaluate', 'evaluation only, no policy export/seal')
    context = support.whole_stage(io, request['protocol'], protocol, components, request['C_actual_review'], identity)
    receipts, exports, predecessor_joins, final = support.chain_join(io, request['protocol'], protocol, request['upstream'])
    bundle = support.final_bundle_join(protocol, request['upstream'], receipts, exports, final)
    support.frozen_audit(io, request['policy_freeze'], request['protocol'], request['upstream'], bundle)
    support.need(context['recipe']['required_upstream_ids'] == support.PREDECESSORS
        and support.same(context['plan']['upstream_receipts'], [row['seal'] for row in request['upstream']]),
        'unchanged worker consumes all ten original current seals, not audit as child input')
    joined = evaluation_join(context, protocol, receipts, exports)
    observer = context['observer']; target = study / 'root/admission' / (identity + '-v1.json')
    admission = dict(schema='D21-Root-conditional-stage-admission-v1', stage_id=identity, stage='evaluate',
        admitted=True, resource_admitted=True, scientific_qualified=True, stage_complete=True,
        **components, protocol=request['protocol'], C_actual_review=request['C_actual_review'],
        request=request_pin, helper=helper, policy_freeze=request['policy_freeze'],
        prior_admissions=[row['admission'] for row in request['upstream']],
        whole_seconds=observer['elapsed_seconds'], whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
        complete_actual_file_census=context['census'], literal_provenance=joined,
        scientific_imports=0, scientific_calls=0, numeric_RNG_Graph_checker_replays=0, partial_files_parsed=0,
        scope='Complete independently reviewed eight-arm stage only. Bounded no-proof search remains unsolved; final Native UNKNOWN or any whole failure refuses admission. No evaluation seal or qualified policy export; no prefix salvage. Observer clock is a sample, not tool end-to-end.')
    support.need(not target.exists(), 'exclusive positive Root admission')
    io.stable(); target.parent.mkdir(exist_ok=True)
    with target.open('xb') as stream:
        stream.write(base.canonical(admission) + b'\n')
    print(base.canonical(base.rawpin(target)).decode('utf-8'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    main(Path(parser.parse_args().request).resolve())
