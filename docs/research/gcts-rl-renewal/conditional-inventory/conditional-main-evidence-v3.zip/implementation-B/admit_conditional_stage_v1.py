"""Prospective D21 Root-only passive stage admission; never replay research.

Only complete saved JSON, raw pins and literal record/receipt joins are read.
The exact current protocol/plans and independent C actual review remain gates.
This fresh author is not the unreviewed D19 generic sealer or execution authority.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

VERSION = 'D21-passive-conditional-stage-admission-v1'
STUDY = Path(__file__).resolve().parents[1]
PIN = {'path', 'bytes', 'sha256'}
ENVELOPE = {'stage_id', 'stage', 'resource_admitted', 'stage_complete', 'plan',
            'result', 'header', 'terminal', 'observer', 'export_sha256',
            'whole_seconds', 'whole_peak_bytes', 'prior_cost_receipts'}
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
            observer_fallback_seconds=225, root_callbacks=400000000,
            memory_bytes=1073741824, physical_bytes=134217728,
            reserved_outer_bytes=9437184, result_bytes=50331648, log_bytes=4194304)
LOCAL = dict(search_attempts=600, search_seconds=2.0, compile_queries=512,
             native_steps=1000000000, marking_proposals=48, marking_certificates=12,
             marking_work=200000, cluster_instances=12, cluster_binding_work=20000,
             cluster_proposals=16, domain_audits=2)
ENTRY_SHA = 'f866615a8fd0b33837fa24148c652c0700bea7365d9b626ca83ef688ec2bd7e9'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def same(left, right):
    return canonical(left) == canonical(right)


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def finite(value):
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value) and value >= 0
    except OverflowError:
        return False


def rawpin(path):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and not path.is_symlink()
         and path == path.resolve(), 'canonical current ordinary file')
    h = hashlib.sha256(); size = 0
    with path.open('rb') as stream:
        for body in iter(lambda: stream.read(1048576), b''):
            size += len(body); h.update(body)
    return dict(path=str(path), bytes=size, sha256=h.hexdigest())


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'duplicate JSON object key')
        value[key] = item
    return value


def reject_constant(value):
    raise ValueError('nonfinite JSON constant: ' + value)


class Inputs:
    def __init__(self):
        self.pins = {}

    def verify(self, row):
        need(type(row) is dict and set(row) == PIN and type(row['path']) is str
             and integer(row['bytes']) and type(row['sha256']) is str
             and len(row['sha256']) == 64, 'strict raw pin')
        need(rawpin(row['path']) == row, 'current raw bytes changed')
        previous = self.pins.setdefault(row['path'], row)
        need(same(previous, row), 'one current identity cannot have two raw pins')
        return Path(row['path'])

    def load(self, row):
        path = self.verify(row)
        need('.partial' not in path.name, 'partial bytes are never parsed')
        body = path.read_bytes()
        need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256'],
             'complete JSON bytes must match the exact pin')
        return json.loads(body, object_pairs_hook=unique_object, parse_constant=reject_constant)

    def stable(self):
        for row in self.pins.values():
            need(rawpin(row['path']) == row, 'an input changed before admission output')


def expected_upstream(stage, identity):
    if stage == 'acquire':
        need(identity in ('acquire-0', 'acquire-1'), 'two fresh acquisition IDs')
        return []
    need(stage == 'train' and identity in ['train-' + str(i) for i in range(8)],
         'this author admits acquisition or training only')
    return ['acquire-0', 'acquire-1'] + ['train-' + str(i) for i in range(int(identity[-1]))]


def snapshot_key(value):
    need(type(value) is dict and set(value) == {'callbacks', 'elapsed_seconds'}
         and integer(value['callbacks']) and value['callbacks'] <= CAPS['root_callbacks']
         and type(value['elapsed_seconds']) is float and finite(value['elapsed_seconds']),
         'exact Root snapshot carrier')
    return value['callbacks'], value['elapsed_seconds'].hex()


class SnapshotJoin:
    def __init__(self, values):
        need(type(values) is list, 'complete Root snapshot ledger')
        self.values = [snapshot_key(v) for v in values]
        need(len(set(self.values)) == len(self.values), 'unique genuine Root samples')
        self.cursor = 0; self.used = []

    def consume(self, value):
        key = snapshot_key(value)
        while self.cursor < len(self.values) and self.values[self.cursor] != key:
            self.cursor += 1
        need(self.cursor < len(self.values), 'decision/terminal sample must join in worker order')
        self.used.append(self.cursor); self.cursor += 1


def native_records(worker):
    rows = worker['native_queries']; transport = worker['native_transport']
    need(type(rows) is list and integer(worker['native_requests_started'])
         and worker['native_requests_started'] == len(rows) <= 512
         and transport['closed'] is transport['all_reaped'] is True
         and transport['native_exit_code'] == 0 and transport['cleanup_errors'] == []
         and transport['complete_records'] == len(rows), 'closed complete owned Native stream')
    stages = transport['request_stages']
    need(type(stages) is list and len(stages) == len(rows), 'every started query completed')
    for index, (row, owned) in enumerate(zip(rows, stages)):
        need(type(row['id']) is int and row['id'] == index
             and type(owned['record_id']) is int and owned['record_id'] == index
             and owned['ordinal'] == index and owned['stage'] == 'COMPLETED'
             and type(owned['limit']) is int and owned['limit'] == LOCAL['native_steps']
             and row['request_sha256'] == digest(row['request'])
             and all(same(row[k], owned[k]) for k in
                     ('purpose', 'request_sha256', 'input_sha256', 'output_sha256')),
             'exact request/result/transport membership, no Native execution')
    return rows


def accepted_query(query, spec, proof, target, queries):
    need(type(query) is dict and type(query['id']) is int and 0 <= query['id'] < len(queries)
         and same(query, queries[query['id']]) and query['result']['status'] == 'accepted'
         and same(query['request'], dict(protocol='gcts-fol-1', theory=spec['theory'],
                                        blocks=[], proof=proof, target=target)),
         'accepted exact current owned flat primitive request')


def proof_join(spec, record, queries):
    search = record['search']; proof = record['proof_check']
    if search['proof'] is None:
        need(proof['status'] == 'NO_PROOF_CANDIDATE' and proof['native_proof_accepted'] is False
             and proof['host_check'] is proof['region'] is proof['native_record'] is None,
             'unsolved search is not proof acceptance')
        return
    need(proof['status'] == 'HOST_REGION_NATIVE_ACCEPTED' and proof['native_proof_accepted'] is True
         and proof['host_check']['accepted'] is True and proof['region']['complete'] is True
         and same(proof['host_check']['target'], spec['target'])
         and proof['host_check']['rows'] == len(search['proof'])
         and type(proof['native_limit']) is int and proof['native_limit'] == LOCAL['native_steps'],
         'fresh final Host/full-region/Native receipts, no unresolved proof adoption')
    accepted_query(proof['native_record'], spec, search['proof'], spec['target'], queries)


def acquisition_join(science, queries, descriptor):
    exported = science['export']; rows = science['records']
    need(len(rows) == 1 and same(science['qualified'], True)
         and same(exported['acquisition_document'], science['inputs']), 'one complete fresh donor')
    record = rows[0]; spec = record['spec']; proof_join(spec, record, queries)
    need(exported['donor_ids'] == descriptor['donor_ids'] == [spec['id']], 'exact donor recipe')
    for key in ('certificates', 'libraries', 'pairing', 'donor_outcomes'):
        need(same(exported[key], science[key]), 'export/live acquisition ' + key)
    outcome = exported['donor_outcomes'][0]
    need(outcome['whole_native_accepted'] is True and outcome['record_sha256'] == digest(record),
         'post-annotation full donor record digest')
    projection = dict(spec=spec, search=dict(status=record['search']['status'], proof=record['search']['proof']),
                      proof_check=record['proof_check'], candidates=record['candidates'],
                      fragment_resolution=record['fragment_resolution'], full_record_sha256=digest(record))
    need(same(exported['donor_evidence'], [projection]), 'full literal donor evidence projection')
    candidates = record['candidates']; profile = []
    need(len(candidates) == len(record['search']['proof']) + 1, 'all declared full/ancestor occurrence rows')
    for index, candidate in enumerate(candidates):
        need(type(candidate['ordinal']) is int and candidate['ordinal'] == index, 'exact candidate order')
        # Only inspect the literal rule profile. Do not remap/reprove/re-mine it.
        eligible = (all(c['rule'] in ('axiom', 'mp') for c in candidate['proof'])
                    and any(c['rule'] == 'mp' for c in candidate['proof']))
        need(candidate['profile_eligible'] is eligible, 'profile cannot be relabeled after UNKNOWN')
        if eligible:
            need(candidate['eligible'] is True and candidate['native_resolution'] == 'accepted'
                 and candidate['host_check']['accepted'] is True, 'every profile must resolve accepted')
            accepted_query(candidate['native_record'], spec, candidate['proof'], candidate['target'], queries)
            profile.append(candidate)
        else:
            need(candidate['eligible'] is False and candidate['native_resolution'] == 'OUTSIDE_DECLARED_PROFILE',
                 'literal non-profile row remains nonauthority')
    resolution = record['fragment_resolution']
    need(resolution['complete'] is resolution['all_profile_fragments_accepted'] is True
         and resolution['unresolved'] == [] and resolution['profile_eligible_count'] == len(profile)
         and resolution['native_accepted_count'] == len(profile)
         and len(exported['certificates']) == len(profile), 'no shorter qualified library')
    for candidate, cert in zip(profile, exported['certificates']):
        need(cert['provenance']['candidate_ordinal'] == candidate['ordinal']
             and all(same(cert[k], candidate[k]) for k in ('proof', 'target', 'native_record', 'families', 'principal_check'))
             and same(cert['spec'], spec) and same(cert['full_donor_proof'], record['search']['proof'])
             and same(cert['full_donor_check'], record['proof_check']), 'certificate/live candidate literal join')
    return dict(donors=1, profile_certificates=len(profile), scope='Literal current evidence; no ancestry/typing/checker replay.')


def trace_contexts(case, search, engine):
    """Literal stack/catalog projection, never Graph/State/guard replay."""
    domains = case['model']['domains']; stack = []; contexts = {}; trace = search['trace']
    for index, event in enumerate(trace):
        kind = event['event']
        if kind == 'decision':
            if engine == 'symbolic':
                prefix = [domains[row][key[0]] for row, key in enumerate(stack)]
                need(event['row'] == len(prefix) and type(event['ordering_complete']) is bool,
                     'symbolic row and durable order carrier')
                if event['ordering_complete'] is False:
                    need(event['ordered_candidates'] is None and search['status'] == 'unknown_search_budget'
                         and trace[-1]['event'] == 'cutoff'
                         and not any(e['event'] in ('decision', 'extend') for e in trace[index + 1:]),
                         'unfinished carrier only at owned cutoff suffix, no current extension/prefix admission')
            else:
                prefix = []
                for slot in range(len(domains)):
                    commands = [k for k in stack if k[0] == slot and k[1] == 0]
                    guards = [k for k in stack if k[0] == slot and k[1] == 1]
                    if not commands or not guards:
                        break
                    need(len(commands) == len(guards) == 1 and commands[0][2] == guards[0][2],
                         'literal paired completed prefix keys')
                    prefix.append(domains[slot][commands[0][2]])
            contexts[index] = dict(prefix=prefix, event=event)
        elif engine == 'symbolic' and kind == 'extend':
            decision = trace[event['decision']]
            need(decision['event'] == 'decision' and decision['ordering_complete'] is True
                 and decision['row'] == len(stack), 'extend only after complete symbolic ordering')
            stack.append((event['skeleton'], event['variant']))
        elif engine == 'point' and kind == 'place':
            stack.append(event['key'])
        elif kind == 'return':
            need(stack, 'return has one literal active extension')
            last = stack.pop()
            need(same(last, event['key']) if engine == 'point' else last[0] == event['skeleton'],
                 'literal LIFO return key')
    return contexts


def proposal_join(proposal, gate, continuation, context, case):
    need(proposal['gate_decision'] == gate['ordinal'], 'proposal/gate ordinal')
    if gate['action']['choice'] == 1:
        need(proposal['status'] == 'POOL_NOT_REQUESTED_GATE_ABSTAIN'
             and proposal['pool'] is proposal['grouping'] is proposal['continuation_decision'] is None
             and continuation is None, 'prepool ABSTAIN requests no pool')
        return
    need(continuation is not None and proposal['status'] == 'COMPLETE_DECLARED_BOUNDED_POOL'
         and proposal['continuation_decision'] == continuation['ordinal'], 'returned complete continuation/pool pair')
    pool = proposal['pool']; grouping = proposal['grouping']
    need(pool['complete'] is True and pool['termination'] in
         ('declared_occurrences_exhausted', 'packet_quota', 'work_prefix')
         and same(grouping, continuation['context']['grouping'])
         and same(grouping['features'], continuation['action']['features'])
         and same(continuation['context']['prefix'], context['prefix'])
         and continuation['context']['gate_decision'] == gate['ordinal'], 'literal full rawpool/group/action join')
    packets = pool['packets']; groups = grouping['groups']; aliases = []; signatures = set()
    for group in groups:
        aliases.extend(group['raw_packet_ordinals'])
        need(group['representative_packet_ordinal'] in group['raw_packet_ordinals'], 'actual representative provenance')
        representative = packets[group['representative_packet_ordinal']]
        signature = canonical([representative['members'], representative['commands']])
        need(signature not in signatures, 'distinct executable classes, never a family-frequency prior')
        signatures.add(signature)
        for ordinal in group['raw_packet_ordinals']:
            need(type(ordinal) is int and 0 <= ordinal < len(packets)
                 and canonical([packets[ordinal]['members'], packets[ordinal]['commands']]) == signature,
                 'literal full continuation equivalence, guard variants remain distinct')
    need(same(sorted(aliases), list(range(len(packets))))
         and grouping['raw_packet_count'] == len(packets)
         and grouping['executable_continuation_count'] == len(groups), 'all raw packet aliases retained exactly once')
    for packet in packets:
        commands = packet['commands']; proof = packet['checked_primitive_proof']
        need(packet['prefix_rows'] == len(context['prefix'])
             and same(proof, context['prefix'] + commands) and packet['host_check']['accepted'] is True
             and packet['host_check']['rows'] == len(proof)
             and same(packet['host_check']['target'], packet['result_formula']), 'literal actual-context Host packet')
        need(len(packet['members']) == 2 * len(commands), 'full primitive command/guard members')
        for offset, command in enumerate(commands):
            key, guard = packet['members'][2 * offset:2 * offset + 2]
            row = len(context['prefix']) + offset
            need(same(key[:2], [row, 0]) and same(guard[:2], [row, 1])
                 and key[2] == guard[2] and same(case['model']['domains'][row][key[2]], command),
                 'exact existing literal command/guard keys, not a new inference')
        for source in packet['source_binding']:
            if source['kind'] == 'prefix':
                need(type(source['row']) is int and 0 <= source['row'] < len(context['prefix'])
                     and same(source['formula'], context['prefix'][source['row']]['formula']), 'literal actual receptor row')
            else:
                need(source['kind'] == 'axiom' and same(source['formula'], case['spec']['theory']['axioms'][source['name']]),
                     'literal named axiom occurrence')
    choice = continuation['action']['choice']
    need(type(choice) is int and 0 <= choice <= len(groups)
         and proposal['selected_group'] == (choice if choice < len(groups) else None),
         'actual group choice or paid late ABSTAIN')


def decisions_join(case, record, snapshots):
    search = record['search']; engine = record['engine']; decisions = search['selector_decisions']
    contexts = trace_contexts(case, search, engine); consumed = set(); joined = []
    for index, decision in enumerate(decisions):
        need(type(decision['ordinal']) is int and decision['ordinal'] == index, 'ordered actual decisions')
        snapshots.consume(decision['snapshot'])
        node = decision['context']['trace_decision']; context = contexts[node]; event = context['event']
        need(decision['context']['engine'] == engine and same(decision['context']['prefix'], context['prefix']),
             'decision actual engine/chronological prefix')
        if decision['head'] == 'continuation':
            need(index in consumed, 'continuation must already join its saved gate/rawpool')
            continue
        need(decision['head'] == 'gate', 'declared conditional head')
        need(decision['pool_ordinal'] is None, 'gate has no consumed pool ordinal')
        expected_count = len(event['original_candidates'] if engine == 'symbolic' else event['original_alternatives'])
        need(decision['context']['original_candidate_count'] == expected_count
             and same(decision['context']['selected_point'], None if engine == 'symbolic' else event['point'])
             and same(decision['action']['features'], [decision['context']['gate_features'], [0.0] * 8]),
             'causal gate literal candidates/features')
        if engine == 'symbolic':
            proposal = event['proposal']
        else:
            proposals = [e['proposal'] for e in search['trace']
                         if e['event'] == 'conditional_proposal' and e['decision'] == node]
            need(len(proposals) <= 1, 'one returned proposal per point decision')
            proposal = proposals[0] if proposals else None
        if proposal is None:
            need(index == len(decisions) - 1 and decision['action']['choice'] == 0
                 and search['status'] == 'unknown_search_budget' and search['trace'][-1]['event'] == 'cutoff',
                 'only a final interrupted PROPOSE gate, never an inferred/selected incomplete pool')
            joined.append(dict(gate=index, trace_decision=node, status='INTERRUPTED_POOL_NOT_RETURNED'))
            continue
        continuation = None
        if proposal['continuation_decision'] is not None:
            ordinal = proposal['continuation_decision']
            need(type(ordinal) is int and ordinal == index + 1 and ordinal < len(decisions),
                 'continuation immediately follows its actual gate')
            continuation = decisions[ordinal]
            need(continuation['head'] == 'continuation' and continuation['context']['trace_decision'] == node,
                 'same-carrier continuation trace ordinal')
            need(type(continuation['pool_ordinal']) is int
                 and continuation['pool_ordinal'] == sum(d['head'] == 'continuation' for d in decisions[:index]),
                 'same chronological returned-pool ordinal')
            consumed.add(ordinal)
        proposal_join(proposal, decision, continuation, context, case)
        joined.append(dict(gate=index, trace_decision=node, status=proposal['status']))
    snapshots.consume(record['terminal_snapshot'])
    return joined


def training_join(science, document, descriptor, acquisitions, previous, receipts, worker, queries):
    exported = science['export']; policies = science['policies']; bindings = science['episode_bindings']
    index = int(science['stage_id'][-1]); shard = document['protocol']['shards'][index]
    need(shard['stage_id'] == descriptor['stage_id'] and shard['pass'] == descriptor['pass_index']
         and same(shard['manifest_indices'], descriptor['manifest_indices'])
         and same(shard['episodes'], descriptor['episodes']) and same(science['inputs'], document)
         and same(exported['training_document'], document) and same(exported['policies'], policies)
         and same(exported['episode_bindings'], bindings) and same(exported['cost_receipts'], receipts)
         and exported['training_document_sha256'] == digest(document)
         and exported['library_sha256'] == digest(science['library'])
         and exported['acquisition_exports'] == [digest(e) for e in acquisitions]
         and exported['prior_policy_export_sha256'] == (None if previous is None else digest(previous)),
         'complete current export/document/inventory/prior bundle bindings')
    need(len(science['records']) == 2 and len(bindings) == 4 * (index + 1), 'all two cases/four prescribed episodes')
    if previous is not None:
        need(same(bindings[:4 * index], previous['episode_bindings']), 'old binding prefix preserved exactly')
    snapshots = SnapshotJoin(worker['work_snapshots']); joins = []
    for engine in ('symbolic', 'point'):
        policy = policies[engine]
        need(policy['engine'] == engine and type(policy['episodes']) is int
             and policy['episodes'] == len(policy['history']) == 2 * (index + 1)
             and science['policy_checks'][engine]['complete'] is True, 'complete in-actual verified engine policy')
        if previous is not None:
            need(same(policy['history'][:2 * index], previous['policies'][engine]['history']), 'literal previous policy history')
        heads = (previous['policies'][engine]['heads'] if previous is not None else
                 {name: dict(weights=[0.0] * dimension, baseline=0.0)
                  for name, dimension in (('gate', 8), ('continuation', 12))})
        for update in policy['history'][2 * index:]:
            for head in ('gate', 'continuation'):
                need(same(update['heads'][head]['preupdate'], heads[head]), 'literal preupdate head continuation')
                for action in update['episode']['decisions']:
                    if action['head'] == head:
                        need(same(action['action']['weights'], heads[head]['weights']), 'actual pre-episode action weights')
            heads = {name: update['heads'][name]['postupdate'] for name in ('gate', 'continuation')}
        need(same(heads, policy['heads']), 'exported final heads equal final actual update')
    for position, case in enumerate(science['records']):
        need(same(case['spec'], document['training'][shard['manifest_indices'][position]])
             and len(case['episodes']) == 2, 'exact declared model case and S/P order')
        for offset, record in enumerate(case['episodes']):
            declared = shard['episodes'][2 * position + offset]; engine = ('symbolic', 'point')[offset]
            need(same(record['descriptor'], declared) and declared['engine'] == engine
                 and record['engine'] == engine and record['selection'] == 'learned', 'exact actual episode descriptor')
            episode = record['episode']; search = record['search']; proof = record['proof_check']
            need(all(same(episode[k], declared[k]) for k in
                     ('engine', 'index', 'global_ordinal', 'problem_id', 'seed'))
                 and same(episode['decisions'], search['selector_decisions'])
                 and same(episode['terminal'], dict(snapshot=record['terminal_snapshot'],
                    attempts=search['metrics'].get('attempts', 0), native_proof_accepted=proof['native_proof_accepted'],
                    proof_status=proof['status'], search_status=search['status'])), 'live search/episode terminal equality')
            proof_join(case['spec'], record, queries)
            history = policies[engine]['history'][declared['index']]
            need(same(record['policy_update'], history) and same(history['episode'], episode),
                 'literal actual update/history link, no arithmetic replay')
            binding = bindings[declared['global_ordinal']]
            for key in ('engine', 'index', 'global_ordinal', 'problem_id', 'seed'):
                need(same(binding[key], declared[key]), 'global prescribed episode binding')
            need(binding['stage_id'] == science['stage_id']
                 and binding['episode_sha256'] == digest(episode)
                 and binding['search_sha256'] == digest(search)
                 and binding['proof_check_sha256'] == digest(proof)
                 and binding['selector_decisions_sha256'] == digest(episode['decisions'])
                 and binding['record_sha256'] == digest(record)
                 and binding['provenance_scope'] == 'ROOT_ADMITTED_ACTUAL_STAGE_RECORD', 'full literal record/hash join')
            joins.append(dict(descriptor=declared, decisions=decisions_join(case, record, snapshots)))
    return dict(episodes=joins, used_snapshot_ordinals=snapshots.used,
                unused_snapshot_count=len(worker['work_snapshots']) - len(snapshots.used),
                scope='Literal live record/pool/trace/history/sample joins only; mathematical verification belongs to the actual.')


def main(request_path):
    io = Inputs(); request_path = Path(request_path)
    helper_pin = rawpin(Path(__file__).resolve()); io.verify(helper_pin)
    need(request_path.is_relative_to(STUDY / 'root'), 'Root-owned fresh request')
    request_pin = rawpin(request_path); request = io.load(request_pin)
    need(set(request) == {'schema', 'protocol', 'plan', 'result', 'header', 'terminal', 'observer',
                         'C_actual_review', 'upstream'}
         and request['schema'] == 'D21-passive-stage-admission-request-v1', 'fresh strict passive request schema')
    need(Path(request['protocol']['path']).is_relative_to(STUDY / 'root')
         and Path(request['plan']['path']).parent == STUDY / 'root' / 'plans'
         and Path(request['C_actual_review']['path']).is_relative_to(STUDY / 'review-C'), 'current Root/C component scope')
    components = {name: request[name] for name in ('plan', 'result', 'header', 'terminal', 'observer')}
    protocol = io.load(request['protocol']); plan = io.load(components['plan'])
    stage, identity = plan['stage'], plan['case_id']; expected = expected_upstream(stage, identity)
    need(protocol['schema'] == 'D21-Root-conditional-family-protocol-v1'
         and protocol['experiment'] == plan['experiment'] == 'D21-conditional-family-selector-v1'
         and same(protocol['limits'], CAPS) and same(protocol['experiment_limits'], LOCAL)
         and same(plan['limits'], CAPS) and same(plan['experiment_limits'], LOCAL)
         and same(plan['protocol'], request['protocol'])
         and protocol['entry']['sha256'] == ENTRY_SHA and protocol['entry']['path'] == plan['entry_path'],
         'exact current D21 protocol/entry/original caps')
    need(protocol['methods'] == ['S0', 'SF', 'SU', 'SR', 'P0', 'PF', 'PU', 'PR']
         and protocol['engines'] == ['symbolic', 'point']
         and same(protocol['population'], dict(evaluation_cases=12, evaluation_jobs=24,
             evaluation_methods=8, evaluation_slots=192, independent_acquisition_jobs=2,
             training_cases=8, training_episodes_per_engine=16, training_episodes_total=32,
             training_jobs=8, whole_jobs=34)), 'same full population and matched methods')
    io.verify(protocol['entry'])
    recipes = protocol['job_recipes']; need(type(recipes) is list and len(recipes) == 34, 'unshortened34 job population')
    recipe_map = {r['stage_id']: r for r in recipes}
    need(len(recipe_map) == 34 and sum(r['stage'] == 'acquire' for r in recipes) == 2
         and sum(r['stage'] == 'train' for r in recipes) == 8
         and sum(r['stage'] == 'evaluate' for r in recipes) == 24, 'fixed phase population')
    descriptor = recipe_map[identity]
    need(descriptor['stage'] == stage and descriptor['required_upstream_ids'] == expected
         and plan['required_upstream_ids'] == expected and same(plan['Root_recipe'], descriptor),
         'one exact current recipe')
    actual = STUDY / 'actual' / identity
    need(plan['actual_dir'] == str(actual) and components['result']['path'] == str(actual / 'result.json')
         and components['header']['path'] == str(actual / 'worker-header.json')
         and components['terminal']['path'] == str(actual / 'terminal.json')
         and components['observer']['path'] == str(STUDY / 'actual' / (identity + '.observer') / 'observer.json'),
         'fresh fixed phase/custody paths')
    guards = plan['files']; need(type(guards) is list and len({r['path'] for r in guards}) == len(guards), 'unique Source guards')
    for row in guards:
        io.verify(row)
    need(protocol['entry'] in guards and protocol['phase_inputs'][stage] in guards
         and protocol['phase_inputs'][stage]['path'] == plan['input_path'], 'guarded entry/exact current physical phase input')
    document = io.load(next(r for r in guards if r['path'] == plan['input_path']))
    worker = io.load(components['result']); header = io.load(components['header'])
    terminal = io.load(components['terminal']); observer = io.load(components['observer'])
    review = io.load(request['C_actual_review']); science = worker['scientific_result']
    need(worker['case_id'] == identity and worker['stage'] == stage and worker['status'] == 'COMPLETE'
         and worker['source_unchanged'] is True and worker['first_Root_fault'] is False
         and worker['error'] is None
         and science['stage_id'] == identity and science['stage'] == stage
         and science['stage_complete'] is science['job_record_complete'] is True
         and science['resource_admitted'] is False and type(science['export']) is dict
         and science['export'].get('qualified') is True and same(science['inputs'], document)
         and science['export']['stage'] == stage and science['export']['stage_id'] == identity,
         'whole complete qualified stage, never salvage')
    need(header['status'] == 'COMPLETE' and header['source_unchanged'] is True
         and header['first_Root_fault'] is False and header['native_closed_and_reaped'] is True
         and same(header['result'], components['result'])
         and terminal['process_exit_code'] == 0 and terminal['header_valid'] is True
         and terminal['sources_unchanged'] is terminal['threads_terminal'] is terminal['final_custody_gate_passed'] is True
         and terminal['errors'] == [] and same(terminal['header'], header) and same(terminal['result'], components['result'])
         and finite(terminal['known_exit_seconds']) and terminal['known_exit_seconds'] <= CAPS['positive_seconds']
         and finite(terminal['final_custody_gate_seconds']) and terminal['final_custody_gate_seconds'] <= CAPS['custody_seconds']
         and observer['parent_exit_code'] == 0 and observer['resource_candidate_accepted'] is True
         and observer['errors'] == [] and finite(observer['elapsed_seconds'])
         and finite(observer['final_observer_gate_seconds'])
         and observer['final_observer_gate_seconds'] <= CAPS['observer_fallback_seconds']
         and terminal['memory_terminal_output_reserve_bytes'] == CAPS['reserved_outer_bytes']
         and observer['final_output_memory_reserve_bytes'] == CAPS['reserved_outer_bytes']
         and components['result']['bytes'] <= CAPS['result_bytes']
         and terminal['stored_bytes_before_terminal_receipt'] <= CAPS['physical_bytes']
         and observer['stored_bytes_before_observer_receipt'] + observer['receipt_allowance_bytes'] <= CAPS['physical_bytes']
         and integer(observer['final_conservative_whole_peak_bytes'])
         and observer['final_conservative_whole_peak_bytes'] <= CAPS['memory_bytes'], 'original custody gates and exact output bodies')
    for owner in (terminal, observer):
        for log in owner['logs'].values():
            need(log['eof'] is True and log['overflow'] is False and integer(log['bytes'])
                 and log['bytes'] == log['stored'] <= CAPS['log_bytes'], 'complete bounded custody logs')
    export_sha = digest(science['export'])
    need(review['schema'] == 'D21-C-conditional-stage-actual-review-v1'
         and review['stage_id'] == identity and review['stage'] == stage
         and all(review[k] is True for k in ('review_passed', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
         and all(same(review[k], components[k]) for k in components)
         and same(review['protocol'], request['protocol']) and review['export_sha256'] == export_sha
         and same(sorted(review['input_pins'], key=lambda r: r['path']), sorted(guards, key=lambda r: r['path']))
         and review['failures'] == [] and type(review['checks']) is list and review['checks']
         and all(c['passed'] is True for c in review['checks']) and review['Root_admission_issued'] is False
         and type(review['partial_files_parsed']) is int and review['partial_files_parsed'] == 0
         and same(review['whole_seconds'], observer['elapsed_seconds'])
         and review['whole_peak_bytes'] == observer['final_conservative_whole_peak_bytes'], 'independent exact current C actual receipt')
    census = review['complete_actual_file_census']
    need(type(census) is list and len({r['path'] for r in census}) == len(census)
         and census == sorted(census, key=lambda r: r['path']), 'canonical complete actual/observer census')
    for row in census:
        p = io.verify(row)
        need(p.is_relative_to(actual) or p.is_relative_to(STUDY / 'actual' / (identity + '.observer')),
             'census cannot read unrelated study/private files')
    need(all(components[k] in census for k in ('result', 'header', 'terminal', 'observer')), 'core files in actual census')
    upstream = request['upstream']; need(type(upstream) is list and len(upstream) == len(expected), 'all required fresh predecessors')
    receipts = []; exports = []; prior_admissions = []
    for identity_before, row in zip(expected, upstream):
        need(type(row) is dict and set(row) == {'admission', 'seal'}, 'explicit upstream pair only')
        admission = io.load(row['admission']); seal = io.load(row['seal'])
        need(Path(row['admission']['path']) == STUDY / 'root' / 'admission' / (identity_before + '-v1.json')
             and Path(row['seal']['path']) == STUDY / 'root' / 'seals' / (identity_before + '-v1.json')
             and admission['schema'] == 'D21-Root-conditional-stage-admission-v1'
             and admission['stage_id'] == seal['stage_id'] == identity_before
             and admission['stage'] == seal['stage'] == ('acquire' if identity_before.startswith('acquire-') else 'train')
             and all(admission[k] is True for k in ('admitted', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
             and same(admission['protocol'], request['protocol']) and same(admission['seal'], row['seal'])
             and set(seal) == ENVELOPE and seal['resource_admitted'] is seal['stage_complete'] is True
             and seal['prior_cost_receipts'] == [], 'current direct admitted predecessor, no historical adoption')
        for name in components:
            need(same(seal[name], admission[name]), 'upstream exact custody components')
            io.verify(seal[name])
        prior_science = io.load(seal['result'])['scientific_result']; prior = prior_science['export']
        need(type(prior) is dict and digest(prior) == seal['export_sha256'] == admission['export_sha256'], 'exact sealed predecessor export')
        need(prior_science['stage_complete'] is prior_science['job_record_complete'] is True
             and prior['qualified'] is True and prior['stage_id'] == identity_before,
             'whole complete unshortened predecessor')
        del prior_science
        need(Path(admission['C_actual_review']['path']).is_relative_to(STUDY / 'review-C'), 'fresh prior independent review path')
        prior_review = io.load(admission['C_actual_review'])
        need(prior_review['schema'] == 'D21-C-conditional-stage-actual-review-v1'
             and prior_review['stage_id'] == identity_before
             and all(prior_review[k] is True for k in ('review_passed', 'resource_admitted', 'scientific_qualified', 'stage_complete'))
             and all(same(prior_review[k], seal[k]) for k in components)
             and prior_review['export_sha256'] == seal['export_sha256'], 'fresh independently reviewed predecessor')
        prior_observer = io.load(seal['observer'])
        need(same(prior_review['whole_seconds'], seal['whole_seconds'])
             and same(seal['whole_seconds'], prior_observer['elapsed_seconds'])
             and prior_review['whole_peak_bytes'] == seal['whole_peak_bytes'] == prior_observer['final_conservative_whole_peak_bytes'],
             'each direct prior cost belongs to its own observer')
        receipts.append(seal); exports.append(prior); prior_admissions.append(row['admission'])
    need(same(plan['upstream_receipts'], [r['seal'] for r in upstream])
         and same(science['cumulative_costs']['receipts'], receipts)
         and science['cumulative_costs']['stage_ids'] == expected
         and same(science['cumulative_costs']['whole_seconds'], sum((r['whole_seconds'] for r in receipts), 0.0)),
         'current intake and once-counted direct cost receipts')
    queries = native_records(worker)
    need(same(science['native_records'], queries), 'full returned Native evidence is owned stream')
    if stage == 'acquire':
        joined = acquisition_join(science, queries, descriptor)
    else:
        need(len(exports) >= 2 and same(science['export']['acquisition_exports'], [digest(v) for v in exports[:2]]),
             'both fresh acquisition exports')
        joined = training_join(science, document, descriptor, exports[:2], exports[-1] if len(exports) > 2 else None,
                               receipts, worker, queries)
    envelope = dict(stage_id=identity, stage=stage, resource_admitted=True, stage_complete=True,
        **components, export_sha256=export_sha, whole_seconds=observer['elapsed_seconds'],
        whole_peak_bytes=observer['final_conservative_whole_peak_bytes'], prior_cost_receipts=[])
    need(set(envelope) == ENVELOPE, 'strict unchanged thirteen-field envelope')
    out = STUDY / 'root' / 'admission' / (identity + '-v1.json'); seal_path = STUDY / 'root' / 'seals' / (identity + '-v1.json')
    seal_body = canonical(envelope) + b'\n'
    seal_pin = dict(path=str(seal_path), bytes=len(seal_body), sha256=hashlib.sha256(seal_body).hexdigest())
    admission = dict(schema='D21-Root-conditional-stage-admission-v1', stage_id=identity, stage=stage,
        admitted=True, resource_admitted=True, scientific_qualified=True, stage_complete=True,
        **components, protocol=request['protocol'], C_actual_review=request['C_actual_review'],
        request=request_pin, helper=helper_pin, seal=seal_pin,
        export_sha256=export_sha, whole_seconds=envelope['whole_seconds'], whole_peak_bytes=envelope['whole_peak_bytes'],
        prior_admissions=prior_admissions, complete_actual_file_census=census, literal_provenance=joined,
        scientific_imports=0, scientific_calls=0, numeric_RNG_Graph_checker_replays=0, partial_files_parsed=0,
        scope='Fresh complete whole stage after exact C actual review and raw/literal joins. No replay, partial or failed-stage salvage. Observer cost is a sampled clock, not tool end-to-end.')
    need(not out.exists() and not seal_path.exists(), 'exclusive Root admission/seal outputs')
    io.stable()
    out.parent.mkdir(exist_ok=True); seal_path.parent.mkdir(exist_ok=True)
    with out.open('xb') as stream:
        stream.write(canonical(admission) + b'\n')
    with seal_path.open('xb') as stream:
        stream.write(seal_body)
    print(json.dumps(dict(admission=rawpin(out), seal=rawpin(seal_path)), sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    main(Path(parser.parse_args().request).resolve())
