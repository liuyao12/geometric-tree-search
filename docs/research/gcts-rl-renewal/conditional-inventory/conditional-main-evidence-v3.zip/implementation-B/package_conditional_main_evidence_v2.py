"""Root-only explicit-allowlist D21 OPEN milestone evidence ZIP.

No research imports, result reconstruction, directory scan, recursive pin chase,
partial JSON intake, extraction, admission, installation or publication occurs.
Exact Source and final request/inventory reviews precede any Root invocation.
"""
import argparse
import binascii
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

VERSION = 'D21-open-main-explicit-evidence-packager-v2'
STUDY = Path(__file__).resolve().parents[1]
REPOSITORY = STUDY.parents[1]
PROTOCOL_SHA = 'c04ff4523941d5552b6ffee42f73d8a5c189191ea1004b82fc28d0122b3e7422'
RESERVED = {'snapshot-manifest.json', 'publication-inventory.json', 'packaging-request.json'}
CORE_ROLES = {'protocol', 'reader_data', 'reader_data_review', 'reader_html', 'population_state', 'package_source'}


def need(value, message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                       allow_nan=False) + '\n').encode('utf-8')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def same(left, right):
    return canonical(left) == canonical(right)


def ordinary(path):
    path = Path(path)
    need(path.is_absolute() and path.is_file() and not path.is_symlink() and path == path.resolve(),
         'canonical current ordinary file only')
    need(not any(p in ('.git', '.aws', '.env', '.gcts-active', '__pycache__') for p in path.parts),
         'private/cache/Git paths forbidden')
    return path


def rawpin(path):
    path = ordinary(path); size = 0; h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            size += len(chunk); h.update(chunk)
    return dict(path=str(path), bytes=size, sha256=h.hexdigest())


def strict_pin(row):
    need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}
         and type(row['path']) is str and type(row['bytes']) is int and row['bytes'] >= 0
         and type(row['sha256']) is str and len(row['sha256']) == 64, 'strict explicit raw pin')
    need(rawpin(row['path']) == row, 'current raw body differs')
    return Path(row['path'])


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, 'duplicate JSON key')
        value[key] = item
    return value


def reject_constant(value):
    raise ValueError('nonfinite JSON constant: ' + value)


def read_complete(row):
    path = strict_pin(row)
    need('.partial' not in path.name, 'partial bodies are opaque, never JSON intake')
    body = path.read_bytes()
    need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256'], 'stable complete JSON')
    return json.loads(body, object_pairs_hook=unique_object, parse_constant=reject_constant)


def safe(name):
    need(type(name) is str and name and not any(c in name for c in ('\\', '\x00', ':')),
         'portable relative member name')
    p = PurePosixPath(name)
    need(bool(p.parts) and not p.is_absolute() and str(p) == name and all(x not in ('', '.', '..') for x in p.parts),
         'no member traversal or path alias')
    return name


def raw_projection(row):
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def runtime_identity(path):
    return (path.name in ('python', 'python3', 'python3.12', 'code.bin')
            or path.name.startswith('boundary-oracle'))


def main(request_path):
    request_path = ordinary(request_path)
    need(request_path == STUDY / 'root/conditional-main-packaging-request-v1.json', 'fixed current Root request')
    request_pin = rawpin(request_path); request = read_complete(request_pin)
    need(set(request) == {'schema', 'protocol', 'inventory', 'reader_data', 'reader_data_review',
                         'external_sources', 'publication_authorized', 'scientific_calls'}
         and request['schema'] == 'D21-passive-raw-package-request-v1'
         and request['publication_authorized'] is True and type(request['scientific_calls']) is int
         and request['scientific_calls'] == 0, 'Root passive open-snapshot authorization')
    need(request['protocol']['path'] == str(STUDY / 'root/protocol-v1.json')
         and request['protocol']['sha256'] == PROTOCOL_SHA, 'exact current D21 protocol pin')
    protocol = read_complete(request['protocol'])
    need(protocol['schema'] == 'D21-Root-conditional-family-protocol-v1'
         and protocol['experiment'] == 'D21-conditional-family-selector-v1', 'current main protocol')
    need(request['inventory']['path'] == str(STUDY / 'root/conditional-main-publication-inventory-v1.json')
         and request['reader_data']['path'] == str(STUDY / 'publication/conditional-main-data-v2.json')
         and Path(request['reader_data_review']['path']).is_relative_to(STUDY / 'review-C'), 'fixed current inputs')
    inventory = read_complete(request['inventory']); data = read_complete(request['reader_data'])
    review = read_complete(request['reader_data_review'])
    need(review['schema'] == 'D21-C-main-reader-data-review-v1'
         and same(review['protocol'], request['protocol']) and same(review['data'], request['reader_data'])
         and review['review_passed'] is True and type(review['checks']) is list and review['checks']
         and all(type(row) is dict and row.get('passed') is True for row in review['checks'])
         and type(review['failures']) is list and review['failures'] == [], 'exact current independent reader-data review')
    need(data['schema'] == 'D21-passive-conditional-main-reader-v2' and data['closed'] is False
         and same(data['protocol_source'], request['protocol']) and type(data['as_of']) is str
         and len(data['jobs']) == 34 and len(data['training']) == 32 and len(data['evaluation']) == 192
         and data['summary']['planned_jobs'] == 34 and data['summary']['training_episode_slots'] == 32
         and data['summary']['evaluation_slots'] == 192, 'reviewed OPEN milestone, full unchanged population')
    need(inventory['schema'] == 'D21-explicit-main-publication-inventory-v1'
         and type(inventory['files']) is list and type(inventory['omitted_runtime']) is list,
         'explicit allowlist only, no discovery')
    externals = request['external_sources']; need(type(externals) is list, 'explicit external Source pins')
    external_map = {}
    for row in externals:
        p = strict_pin(row)
        need(p.is_relative_to(REPOSITORY) and not p.is_relative_to(STUDY)
             and 'actual' not in p.relative_to(REPOSITORY).parts
             and 'publication' not in p.relative_to(REPOSITORY).parts
             and row['path'] not in external_map and not runtime_identity(p),
             'only declared repository Source bodies outside the task, never earlier actual/archive/runtime bodies')
        external_map[row['path']] = row
    selected = {}; omitted = {}; members = set(); roles = {}
    for row in inventory['omitted_runtime']:
        need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256', 'role', 'reason'}
             and type(row['role']) is str and type(row['reason']) is str and row['reason'], 'explicit reasoned runtime omission')
        p = strict_pin(raw_projection(row))
        need(runtime_identity(p) and row['path'] not in omitted, 'unique executable/generated-table pin-only identity')
        omitted[row['path']] = row
    for row in inventory['files']:
        need(type(row) is dict and set(row) == {'path', 'bytes', 'sha256', 'archive_path', 'role'}
             and type(row['role']) is str and row['role'], 'exact selected allowlist row')
        path = strict_pin(raw_projection(row)); member = safe(row['archive_path'])
        need(row['path'] not in selected and row['path'] not in omitted and not runtime_identity(path)
             and member not in members | RESERVED, 'unique selected body/member, disjoint runtime omissions')
        need(path.is_relative_to(STUDY) or same(raw_projection(row), external_map.get(row['path'])), 'explicit current task or allowed external Source only')
        need(path not in (request_path, Path(request['inventory']['path']))
             and not path.name.endswith(('.zip', '.tar', '.tar.gz', '.tgz'))
             and path.name != 'conditional-main-manifest.json', 'no request/inventory/output/archive selfcycle')
        selected[row['path']] = dict(row, opaque_partial='.partial' in path.name)
        members.add(member); roles.setdefault(row['role'], []).append(row)
    need(set(selected).isdisjoint(omitted), 'selected and omitted sets cannot contradict')
    need({p for p in selected if not Path(p).is_relative_to(STUDY)} == set(external_map), 'all and only declared external Source bodies')
    need(CORE_ROLES <= set(roles) and all(len(roles[r]) == 1 for r in CORE_ROLES), 'one full current core body for each role')
    for key in ('protocol', 'reader_data', 'reader_data_review'):
        need(same(raw_projection(roles[key][0]), request[key]), 'core role must match request ' + key)
    need(same(raw_projection(roles['population_state'][0]), data['population_source'])
         and roles['reader_html'][0]['path'] == str(STUDY / 'publication/conditional-main.html')
         and same(raw_projection(roles['package_source'][0]), rawpin(Path(__file__).resolve())), 'current population, standalone HTML and packager Source bodies')
    # Flat coverage comparisons only. Never open files by following nested data.
    for row in data['input_pins']:
        current = selected.get(row['path'], omitted.get(row['path']))
        need(current is not None and same(raw_projection(current), row), 'all current projection input pins explicitly retained or pin-only')
    rows = sorted(selected.values(), key=lambda row: row['archive_path'])
    rows.extend([dict(request_pin, archive_path='packaging-request.json', role='packaging_request', opaque_partial=False),
                 dict(request['inventory'], archive_path='publication-inventory.json', role='publication_inventory', opaque_partial=False)])
    rows.sort(key=lambda row: row['archive_path'])
    snapshot = dict(schema='D21-open-main-evidence-snapshot-v1', milestone='OPEN_STUDY_MILESTONE',
        study_closed=False, as_of=data['as_of'], protocol=request['protocol'], reader_data=request['reader_data'],
        reader_data_review=request['reader_data_review'], inventory=request['inventory'], request=request_pin,
        population_summary=data['summary'], planned_population=dict(jobs=34, training_episodes=32, evaluation_slots=192),
        files=rows, omitted_runtime=[omitted[p] for p in sorted(omitted)],
        scope='Raw current OPEN milestone only. Summary copied from exact reviewed projection; no fabricated success, closure, counts, proof, policy, admission or scientific inference. Opaque partial bytes never qualify. Later archive/install/live receipts are outside this snapshot.',
        scientific_imports=0, scientific_calls=0, partial_files_parsed=0)
    body = encoded(snapshot); output = STUDY / 'publication'
    archive = output / 'conditional-main-evidence.zip'; manifest = output / 'conditional-main-manifest.json'
    need(output.is_dir() and output == output.resolve()
         and not archive.exists() and not manifest.exists(), 'canonical Root directory and exclusive immutable outputs')
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as bundle:
        def info(name):
            z = zipfile.ZipInfo(safe(name), date_time=(1980, 1, 1, 0, 0, 0)); z.create_system = 3
            z.external_attr = (stat.S_IFREG | 0o644) << 16; z.compress_type = zipfile.ZIP_DEFLATED
            z.extra = b''; z.comment = b''
            return z
        bundle.writestr(info('snapshot-manifest.json'), body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        for row in rows:
            size = 0; h = hashlib.sha256()
            with ordinary(row['path']).open('rb') as source, bundle.open(info(row['archive_path']), 'w') as target:
                for chunk in iter(lambda: source.read(1048576), b''):
                    size += len(chunk); h.update(chunk); target.write(chunk)
            need((size, h.hexdigest()) == (row['bytes'], row['sha256']), 'input changed during streamed raw copy')
    expected = {row['archive_path']: (row['bytes'], row['sha256']) for row in rows}
    expected['snapshot-manifest.json'] = (len(body), hashlib.sha256(body).hexdigest()); seen = set()
    with zipfile.ZipFile(archive, 'r') as bundle:
        for member in bundle.infolist():
            name = safe(member.filename)
            need(name in expected and name not in seen and not member.is_dir()
                 and stat.S_IFMT(member.external_attr >> 16) == stat.S_IFREG
                 and member.date_time == (1980, 1, 1, 0, 0, 0), 'all and only deterministic ordinary declared members')
            size = 0; h = hashlib.sha256(); crc = 0
            with bundle.open(member) as source:
                for chunk in iter(lambda: source.read(1048576), b''):
                    size += len(chunk); h.update(chunk); crc = binascii.crc32(chunk, crc)
            need((size, h.hexdigest()) == expected[name] and crc == member.CRC, 'full member raw SHA256/length/CRC readback')
            seen.add(name)
    need(seen == set(expected), 'complete exact ZIP census')
    for row in rows + list(omitted.values()):
        strict_pin(raw_projection(row))
    # These metadata inputs are explicitly selected above, not recursively found.
    for row in (request_pin, request['inventory'], request['protocol'], request['reader_data'], request['reader_data_review']):
        strict_pin(row)
    result = dict(snapshot, archive=rawpin(archive), all_members_raw_verified=True,
        raw_member_count=len(rows), regular_members_including_snapshot=len(seen),
        raw_uncompressed_bytes=sum(row['bytes'] for row in rows),
        embedded_snapshot=dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest()))
    with manifest.open('xb') as stream:
        stream.write(encoded(result))
    print(json.dumps(dict(archive=rawpin(archive), manifest=rawpin(manifest)), sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True)
    main(Path(parser.parse_args().request).resolve())
