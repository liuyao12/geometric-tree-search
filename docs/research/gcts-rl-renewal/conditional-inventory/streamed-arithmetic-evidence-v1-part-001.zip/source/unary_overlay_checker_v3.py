"""Independent data-only checker for a certificate-guided unary extra layer.

No overlay, E4, C3, native kernel, model helper or driver imports. Normalizes
models independently, derives the fixed-CID residual context, checks complete
saved raw/C3 scope/hash associations and prior clean LABEL-phase custody, then
checks the exact literal overlay/control structure. Physical authenticity of
supplied file/process objects remains an explicit external prerequisite.
"""
import hashlib
import json
import math
import time

VERSION='Independent-scoped-unary-overlay-checker-v3'
SCALAR_BUFFER_BYTES=64*1024*1024
GUARD='learned:unary:guard:v1'
MODEL_FIELDS={'schema','version','capacity','roots','seed','inventory','pair_nogoods','unary_nogoods'}


class _Reject(Exception):pass
class _Budget(Exception):pass


def _require(ok,why):
    if not ok:raise _Reject(why)


def _hash_string(x):
    return type(x) is str and len(x)==64 and all(c in '0123456789abcdef' for c in x)


class _CanonicalKey:
    """Native string ordering, exactly as sorted-key JSON, with charged comparisons."""
    __slots__=('value','reader')
    def __init__(self,value,reader):self.value=value;self.reader=reader
    def __lt__(self,other):
        r=self.reader;units=1+len(self.value)+len(other.value)
        r.metrics['equal_sort_comparisons']+=1
        r.metrics['equal_sort_literal_units']+=units
        r.step(units)
        return self.value<other.value


class _Reader:
    def __init__(self,work,wall):
        _require(type(work) is int and 0<=work<=1000000000,'CHECKER_WORK_LIMIT')
        _require(type(wall) in (int,float) and math.isfinite(wall) and 0<wall<=120,'CHECKER_WALL_LIMIT')
        self.work=0;self.limit=work;self.deadline=time.perf_counter()+wall
        self.metrics={k:0 for k in ('encode_calls','encode_work','encoded_bytes',
            'sha_calls','sha_work','hashed_bytes','equal_calls','equal_work',
            'equal_pairs','equal_literal_units','equal_sort_comparisons',
            'equal_sort_literal_units','equal_nonascii_scalar_pairs','equal_float_pairs',
            'stream_validation_work','stream_nodes','stream_fragments','stream_bytes',
            'stream_string_characters','stream_exact_string_bytes','stream_int_digit_steps',
            'stream_float_reserve_units','stream_scalar_work','stream_scalar_fragments',
            'stream_scalar_bytes','stream_scalar_allocation_units','stream_max_scalar_bytes',
            'stream_key_sort_work','stream_key_sort_comparisons','stream_key_sort_literal_units')}
    def step(self,n=1):
        self.work+=n
        if self.work>self.limit:raise _Budget('CHECKER_MAX_WORK')
        if time.perf_counter()>=self.deadline:raise _Budget('CHECKER_WALL_SECONDS')
    def scan(self,value):
        def members(d):
            for k,v in d.items():
                _require(type(k) is str,'STRING_JSON_KEY');yield k;yield v
        stack=[(iter((value,)),0,None)];active=set();bound=1
        while stack:
            self.step();it,depth,identity=stack[-1]
            try:x=next(it)
            except StopIteration:
                stack.pop()
                if identity is not None:active.remove(identity)
                continue
            if depth>256:raise _Budget('CHECKER_JSON_DEPTH')
            if type(x) is str:self.step(len(x));bound+=4+12*len(x)
            elif type(x) is int:
                _require(x.bit_length()<=256,'JSON_INTEGER_BITS');bound+=84
            elif x is None or type(x) is bool:bound+=8
            elif type(x) is float:_require(math.isfinite(x),'FINITE_JSON_FLOAT');bound+=132
            elif type(x) in (list,dict):
                identity=id(x);_require(identity not in active,'JSON_CYCLE')
                active.add(identity)
                stack.append((iter(x) if type(x) is list else members(x),depth+1,identity));bound+=4
            else:raise _Reject('NATIVE_JSON_ONLY')
        return bound
    def encode(self,value):
        before=self.work;self.metrics['encode_calls']+=1
        try:
            self.step();reserve=self.scan(value);self.step(reserve)
            raw=(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
            _require(len(raw)<=reserve,'CANONICAL_BYTE_BOUND')
            self.step();self.metrics['encoded_bytes']+=len(raw)
            return raw
        finally:self.metrics['encode_work']+=self.work-before
    def sha(self,value):
        before=self.work;self.metrics['sha_calls']+=1
        try:
            self.step();validation_start=self.work
            try:self.scan(value)
            finally:self.metrics['stream_validation_work']+=self.work-validation_start
            h=hashlib.sha256();self.step()
            for fragment in self._canonical_fragments(value):
                n=len(fragment);self.step(n+1)
                h.update(fragment)
                self.step()
                self.metrics['stream_fragments']+=1
                self.metrics['stream_bytes']+=n;self.metrics['hashed_bytes']+=n
            self.step();digest=h.hexdigest();self.step()
            return digest
        finally:self.metrics['sha_work']+=self.work-before
    def _stream_keys(self,value):
        before=self.work;comparisons=self.metrics['equal_sort_comparisons']
        units=self.metrics['equal_sort_literal_units']
        try:return self._keys(value)
        finally:
            self.metrics['stream_key_sort_work']+=self.work-before
            self.metrics['stream_key_sort_comparisons']+=self.metrics['equal_sort_comparisons']-comparisons
            self.metrics['stream_key_sort_literal_units']+=self.metrics['equal_sort_literal_units']-units
    def _string_length(self,value):
        self.step()
        if len(value)+2>SCALAR_BUFFER_BYTES:raise _Budget('CHECKER_SCALAR_BUFFER_BYTES')
        n=2
        for character in value:
            self.step();self.metrics['stream_string_characters']+=1
            code=ord(character)
            if code in (34,92,8,9,10,12,13):n+=2
            elif 32<=code<=126:n+=1
            elif code<=65535:n+=6
            else:n+=12
            if n>SCALAR_BUFFER_BYTES:raise _Budget('CHECKER_SCALAR_BUFFER_BYTES')
        self.metrics['stream_exact_string_bytes']+=n
        return n
    def _scalar_fragment(self,value):
        before=self.work
        try:
            self.step()
            if value is None:raw=b'null'
            elif type(value) is bool:raw=b'true' if value else b'false'
            else:
                if type(value) is str:
                    n=self._string_length(value);reserve=n
                elif type(value) is int:
                    _require(value.bit_length()<=256,'JSON_INTEGER_BITS')
                    self.step(1+value.bit_length())
                    v=abs(value);n=1+int(value<0)
                    while v>=10:
                        self.step();self.metrics['stream_int_digit_steps']+=1
                        v//=10;n+=1
                    _require(n<=84,'STREAM_INTEGER_BUFFER_BOUND');reserve=n
                elif type(value) is float:
                    _require(math.isfinite(value),'FINITE_JSON_FLOAT')
                    reserve=132;n=None;self.metrics['stream_float_reserve_units']+=reserve
                else:raise _Reject('STREAM_NATIVE_SCALAR_ONLY')
                if reserve>SCALAR_BUFFER_BYTES:raise _Budget('CHECKER_SCALAR_BUFFER_BYTES')
                # Charge the bounded ASCII string buffer before its C encoder.
                self.step(reserve);self.metrics['stream_scalar_allocation_units']+=reserve
                text=json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
                self.step()
                if n is None:
                    n=len(text);_require(n<=reserve,'STREAM_FLOAT_BUFFER_BOUND')
                else:_require(len(text)==n,'STREAM_EXACT_SCALAR_LENGTH')
                # The second output representation is a bounded ASCII byte buffer.
                self.step(n);self.metrics['stream_scalar_allocation_units']+=n
                raw=text.encode('ascii');self.step()
                _require(len(raw)==n,'STREAM_ASCII_FRAGMENT_LENGTH')
            n=len(raw)
            if n>SCALAR_BUFFER_BYTES:raise _Budget('CHECKER_SCALAR_BUFFER_BYTES')
            self.metrics['stream_scalar_fragments']+=1;self.metrics['stream_scalar_bytes']+=n
            self.metrics['stream_max_scalar_bytes']=max(self.metrics['stream_max_scalar_bytes'],n)
            self.step();return raw
        finally:self.metrics['stream_scalar_work']+=self.work-before
    def _array_parts(self,value):
        yield 'bytes',b'['
        for index,member in enumerate(value):
            if index:yield 'bytes',b','
            yield 'value',member
        yield 'bytes',b']'
    def _object_parts(self,value):
        yield 'bytes',b'{'
        for index,key in enumerate(self._stream_keys(value)):
            if index:yield 'bytes',b','
            yield 'value',key
            yield 'bytes',b':'
            yield 'value',value[key]
        yield 'bytes',b'}'
    def _canonical_fragments(self,value):
        # scan() has already validated the entire finite native object graph.
        # Frames retain container iterators and native-sorted key lists only;
        # no compound JSON wire or all-descendants action list is allocated.
        stack=[iter((('value',value),))]
        while stack:
            self.step()
            try:kind,member=next(stack[-1])
            except StopIteration:stack.pop();continue
            if kind=='bytes':yield member
            else:
                self.metrics['stream_nodes']+=1
                if type(member) is list:stack.append(self._array_parts(member))
                elif type(member) is dict:stack.append(self._object_parts(member))
                else:yield self._scalar_fragment(member)
        yield b'\n'
    def _keys(self,value):
        # The native-key order matters even when two distinct Python strings
        # have identical ensure_ascii encodings (astral/surrogate spellings).
        self.step(1+2*len(value))
        keys=sorted(value,key=lambda k:_CanonicalKey(k,self))
        self.step();return keys
    def _dict_pairs(self,a,b):
        aa=self._keys(a);bb=self._keys(b)
        for ka,kb in zip(aa,bb):
            yield ka,kb
            yield a[ka],b[kb]
    def equal(self,a,b,why):
        before=self.work;self.metrics['equal_calls']+=1
        try:
            self.step()
            # Validate both complete trees first, including a mismatching or
            # later-unvisited branch. Shared acyclic subobjects are allowed.
            self.scan(a);self.scan(b)
            stack=[iter(((a,b),))];matched=True
            while stack:
                self.step()
                try:x,y=next(stack[-1])
                except StopIteration:stack.pop();continue
                self.metrics['equal_pairs']+=1
                if type(x) is not type(y):matched=False;continue
                if x is None:continue
                if type(x) is list:
                    if len(x)!=len(y):matched=False
                    else:stack.append(iter(zip(x,y)))
                elif type(x) is dict:
                    if len(x)!=len(y):matched=False
                    else:stack.append(self._dict_pairs(x,y))
                elif type(x) is str:
                    units=1+len(x)+len(y);self.step(units)
                    self.metrics['equal_literal_units']+=units
                    if x.isascii() and y.isascii():same=x==y
                    else:
                        self.metrics['equal_nonascii_scalar_pairs']+=1
                        same=self.encode(x)==self.encode(y)
                    if not same:matched=False
                elif type(x) is float:
                    self.metrics['equal_float_pairs']+=1
                    if self.encode(x)!=self.encode(y):matched=False
                else:
                    # Only native bool/int remain after complete validation.
                    units=1+(x.bit_length()+y.bit_length() if type(x) is int else 1)
                    self.step(units);self.metrics['equal_literal_units']+=units
                    if x!=y:matched=False
            self.step();_require(matched,why)
        finally:self.metrics['equal_work']+=self.work-before


def _fields(value,names,why):
    _require(type(value) is dict and set(value)==set(names),why)


def _nat(x,lo=0):
    return type(x) is int and x>=lo and x.bit_length()<=256


def _model(value,r):
    _fields(value,MODEL_FIELDS,'V3_MODEL_FIELDS')
    _require(value['schema']=='Z-growing-point-model-v3' and type(value['version']) is str and bool(value['version']),'V3_MODEL_VERSION')
    c=value['capacity'];_require(_nat(c,1),'MODEL_CAPACITY')
    def rows(x,marks=False,seed=False):
        _require(type(x) is list,'MODEL_ROWS_LIST');out={}
        for pair in x:
            r.step();_require(type(pair) is list and len(pair)==2 and type(pair[0]) is str and pair[0] not in out,'DISTINCT_MODEL_POINT')
            p,v=pair
            _require(type(v) is str if marks else _nat(v,0 if seed else 1) and v<=c,'MODEL_LITERAL_OR_UNITS')
            out[p]=v
        return [[p,out[p]] for p in sorted(out)]
    roots=value['roots'];_require(type(roots) is list and all(type(p) is str for p in roots) and len(roots)==len(set(roots)),'MODEL_ROOTS')
    _fields(value['seed'],{'t','m'},'MODEL_SEED')
    _fields(value['inventory'],{'kind','placements'},'MODEL_INVENTORY')
    _require(value['inventory']['kind']=='EXPLICIT' and type(value['inventory']['placements']) is list,'EXPLICIT_ONLY')
    inventory={}
    for x in value['inventory']['placements']:
        r.step();_fields(x,{'id','t','m'},'MODEL_PLACEMENT')
        cid=x['id'];_require(type(cid) is str and bool(cid) and cid not in inventory,'DISTINCT_NONEMPTY_CID')
        t=rows(x['t']);_require(bool(t),'NONEMPTY_POSITIVE_SUPPORT')
        inventory[cid]=dict(id=cid,t=t,m=rows(x['m'],marks=True))
    pairs=value['pair_nogoods'];unary=value['unary_nogoods']
    _require(type(pairs) is list,'PAIR_LIST')
    for pair in pairs:
        r.step();_require(type(pair) is list and len(pair)==2 and all(type(c) is str and c in inventory for c in pair) and pair[0]<pair[1],'CANONICAL_PAIR')
    _require(pairs==sorted(pairs) and len({tuple(p) for p in pairs})==len(pairs),'CANONICAL_PAIRS')
    _require(type(unary) is list and all(type(c) is str and c in inventory for c in unary)
             and unary==sorted(set(unary)),'CANONICAL_UNARY_LIST')
    return dict(schema=value['schema'],version=value['version'],capacity=c,roots=sorted(roots),
                seed=dict(t=rows(value['seed']['t'],seed=True),m=rows(value['seed']['m'],marks=True)),
                inventory=dict(kind='EXPLICIT',placements=[inventory[c] for c in sorted(inventory)]),
                pair_nogoods=[list(p) for p in pairs],unary_nogoods=list(unary))


def _reference(value):
    _require(type(value) is dict and {'path','bytes','sha256'}<=value.keys(),'EVIDENCE_REFERENCE')
    _require(type(value['path']) is str and bool(value['path']) and not value['path'].startswith('/')
             and '..' not in value['path'].split('/') and _nat(value['bytes']) and _hash_string(value['sha256']), 'LOCAL_HASHED_REFERENCE')
    _require(value.get('complete_json',True) is True,'COMPLETE_EVIDENCE_CAPTURE')
    return {k:value[k] for k in ('path','bytes','sha256')}


def _custody(provenance,query_binding_hashes,r):
    """Data associations only: supplied process/file objects are not authenticated."""
    _require(provenance['schema']=='Unary-overlay-provenance-v1'
             and provenance['mode']=='FRESH_FIXED_CID_LABEL_PHASE','FRESH_LABEL_PROVENANCE')
    protocol=provenance['protocol']['value'];pref=_reference(provenance['protocol']['ref'])
    _require(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    raw_protocol=r.encode(protocol)
    r.equal(dict(bytes=len(raw_protocol),sha256=hashlib.sha256(raw_protocol).hexdigest()),
            {k:pref[k] for k in ('bytes','sha256')},'CANONICAL_PROTOCOL_BYTES')
    supplied_sources=provenance['sources'];_fields(supplied_sources,{'engine','semantic','driver'},'SOURCE_ROLES')
    frozen={ref['path']:_reference(ref) for ref in protocol['files']}
    for role,source in supplied_sources.items():
        r.step();sref=_reference(source);_require(sref['path'] in frozen,'SOURCE_IN_FROZEN_PROTOCOL')
        r.equal(sref,frozen[sref['path']],'EXACT_SOURCE_PIN:'+role)
    _require(type(provenance['engine_version']) is str and bool(provenance['engine_version'])
             and type(provenance['semantic_version']) is str and bool(provenance['semantic_version']),'DECLARED_CHECKER_ENGINE_VERSIONS')
    phase=provenance['label_phase'];s,i,o,result=[phase[k] for k in ('started','invocation','observer','result')]
    _require(all(_nat(v['pid'],1) for v in (s,i,o)) and s['pid']==i['pid']==o['pid'],'LABEL_PID_ASSOCIATION')
    _require(s['phase']==i['phase']==o['phase']=='label','LABEL_PHASE_ASSOCIATION')
    r.equal(_reference(s['protocol']),pref,'LABEL_STARTED_PROTOCOL')
    _require(o['status']=='TERMINAL' and _nat(o['native_exit_code']) and o['native_exit_code']==0
             and i['status']=='COMPLETE' and i['error_type'] is None,'PRIOR_LABEL_NATIVE_CLEAN')
    _require(all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
             and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==protocol['status'],'PRIOR_LABEL_SOURCE_POSTCHECK')
    _require(type(result['status']) is str and bool(result['status']) and i['scientific_status']==result['status'],'LABEL_RESULT_STATUS_ASSOCIATION')
    result_ref=_reference(phase['result_ref']);r.equal(_reference(i['result']),result_ref,'LABEL_INVOCATION_RESULT_REF')
    _require(i['result'].get('complete_json',False) is True,'LABEL_RESULT_COMPLETE_CAPTURE')
    encoded=r.encode(result);r.equal(dict(bytes=len(encoded),sha256=hashlib.sha256(encoded).hexdigest()),
        {k:result_ref[k] for k in ('bytes','sha256')},'CANONICAL_LABEL_RESULT_BYTES')
    r.equal(_reference(o['log']),_reference(phase['log_ref']),'LABEL_LOG_ASSOCIATION')
    _require(type(result['query_bindings']) is list,'LABEL_RESULT_QUERY_BINDINGS')
    admitted={r.sha(b) for b in result['query_bindings']}
    _require(set(query_binding_hashes)<=admitted,'QUERIES_BOUND_TO_PRIOR_CLEAN_LABEL_RESULT')
    _require(type(protocol['runtime']) is dict and _hash_string(protocol['runtime']['executable']['sha256']),'PINNED_RUNTIME_DECLARATION')
    return dict(protocol_ref=pref,sources={k:_reference(v) for k,v in supplied_sources.items()},
                label_result_ref=result_ref,label_log_ref=_reference(phase['log_ref']),pid=o['pid'],
                declared_runtime=protocol['runtime'],physical_authenticity='EXTERNAL_DRIVER_GATE_REQUIRED')


def _fixed(base,cid,fixed,r):
    rows=base['inventory']['placements'];found=[x for x in rows if x['id']==cid]
    _require(len(found)==1,'FIXED_CID_OCCURS_EXACTLY_ONCE')
    tile=found[0];totals=dict(base['seed']['t']);marks=dict(base['seed']['m'])
    for p,n in tile['t']:
        r.step();totals[p]=totals.get(p,0)+n;_require(totals[p]<=base['capacity'],'FIXED_CID_SEED_CAPACITY')
    for p,v in tile['m']:
        r.step();_require(p not in marks or marks[p]==v,'FIXED_CID_SEED_MARK_COMPATIBILITY');marks[p]=v
    expected=dict(base,version=fixed['version'],roots=sorted(set(base['roots'])|{p for p,n in tile['t']}),
        seed=dict(t=[[p,totals[p]] for p in sorted(totals)],m=[[p,marks[p]] for p in sorted(marks)]),
        inventory=dict(kind='EXPLICIT',placements=[x for x in rows if x['id']!=cid]))
    r.equal(fixed,expected,'EXACT_FIXED_CID_RESIDUAL_CONTEXT')
    return dict(cid=cid,residual_candidates=len(rows)-1,fixed_model_sha256=r.sha(fixed))


def _query(base,packet,scope,provenance,r):
    _require(type(packet) is dict,'QUERY_PACKET');cid=packet['cid'];label=packet['label']
    _require(type(cid) is str and label in ('NEGATIVE','POSITIVE','UNKNOWN') and type(label) is str,'QUERY_CID_AND_LABEL')
    _require(packet['scope_sha256']==scope,'QUERY_ORIGINAL_SCOPE')
    fixed=_model(packet['fixed_model'],r);association=_fixed(base,cid,fixed,r)
    raw=packet['raw_result'];c=packet['semantic_receipt'];binding=packet['binding']
    _fields(binding,{'schema','cid','label','scope_sha256','base_model_sha256','fixed_model_sha256',
                    'raw_result_sha256','semantic_receipt_sha256','native_receipt_sha256','native_proof_sha256','evidence_refs'},'QUERY_BINDING_FIELDS')
    expected=dict(schema='Unary-fixed-query-binding-v1',cid=cid,label=label,scope_sha256=scope,
        base_model_sha256=scope,fixed_model_sha256=association['fixed_model_sha256'],
        raw_result_sha256=r.sha(raw),semantic_receipt_sha256=r.sha(c),
        native_receipt_sha256=r.sha(packet['native_receipt']) if label=='POSITIVE' else None,
        native_proof_sha256=r.sha(packet['native_proof']) if label=='POSITIVE' else None,
        evidence_refs=binding['evidence_refs'])
    r.equal(binding,expected,'FULL_QUERY_OBJECT_BINDING')
    refs=binding['evidence_refs'];_require(type(refs) is dict and {'model','raw','semantic'}<=refs.keys(),'QUERY_EVIDENCE_REFS')
    for reference in refs.values():_reference(reference)
    _require(raw['version']==provenance['engine_version'] and c['version']==provenance['semantic_version'],'PINNED_METHOD_VERSION_ASSOCIATION')
    _require(raw['model_sha256']==association['fixed_model_sha256'] or
             (label=='UNKNOWN' and raw['model_sha256'] is None),'RAW_FIXED_MODEL_HASH')
    if label=='UNKNOWN':
        _require(c['status']=='UNKNOWN' and c['bounded_absence'] is False,'UNKNOWN_IS_NEVER_A_NEGATIVE')
    else:
        status='UNSAT' if label=='NEGATIVE' else 'SAT'
        _require(raw['status']==status and c['status']=='VERIFIED' and c['run_status']==status,'ADMITTED_QUERY_STATUS')
        _require(c['bounded_absence'] is (label=='NEGATIVE') and c['event_coverage']=='COMPLETE','EXACT_NEGATIVE_SCOPE')
        _require(c['claim']==('SEMANTIC_COMPLETE_FINITE_EXHAUSTION' if label=='NEGATIVE' else 'SEMANTIC_COMPLETE_SAT_CERTIFICATE'),'EXACT_QUERY_CLAIM')
        _require(c['model_sha256']==association['fixed_model_sha256'],'SCOPED_C3_MODEL_HASH')
        events=raw['events'];extent=raw['event_extent']
        _require(type(events) is list and _nat(extent['total']) and _nat(extent['retained'])
                 and extent['total']==extent['retained']==len(events),'COMPLETE_QUERY_EVENT_PAYLOAD')
        h=hashlib.sha256()
        for i,e in enumerate(events):
            r.step();_require(_nat(e['seq']) and e['seq']==i,'QUERY_EVENT_SEQUENCE');h.update(r.encode(e))
        _require(h.hexdigest()==extent['sha256']==c['event_sha256'],'EXACT_RAW_AND_C3_EVENT_HASH')
        r.equal(c['counts']['decision_events_checked'],len(events),'C3_COMPLETE_EVENT_COUNT')
        _require(bool(events) and events[0]['kind']=='READY' and events[-1]['kind']==('EXHAUSTED' if label=='NEGATIVE' else 'SOLUTION'),'QUERY_TERMINAL_BINDING')
        for name in ('entry','final','restored'):
            _require(raw[name+'_state'] is not None,'COMPLETE_QUERY_ENDPOINT')
            _require(r.sha(raw[name+'_state'])==raw['state_hashes'][name],'QUERY_ENDPOINT_HASH')
        r.equal(raw['entry_state'],raw['restored_state'],'QUERY_RESTORATION_BYTES')
        if label=='NEGATIVE':
            _require(raw['reason']=='EXHAUSTED_DECLARED_FINITE_INVENTORY' and raw['selected']==[] and raw['certificate'] is None,'EXACT_FINITE_EXHAUSTION_OUTPUT')
        else:
            _require(raw['reason']=='FINITE_ACTIVE_OBLIGATIONS_EXACT' and type(packet['native_receipt']) is dict
                     and packet['native_receipt']['status']=='VERIFIED' and type(packet['native_proof']) is list,'POSITIVE_REQUIRES_NATIVE_PROOF_AND_RECEIPT')
            _require({'native_receipt','native_proof'}<=refs.keys(),'NATIVE_POSITIVE_EVIDENCE_REFS')
    return dict(cid=cid,label=label,binding_sha256=r.sha(binding),fixed_context=association,
                evidence_refs=refs,semantic_status=c['status'],native_truth='EXTERNAL_NATIVE_GATE' if label=='POSITIVE' else 'NOT_A_NATIVE_NONPROVABILITY_CLAIM')


def verify(base_model,marked_model,control_model,synthesis,query_packets,provenance,*,
           guard_point=GUARD,max_work=1000000000,wall_seconds=120):
    started=time.perf_counter();r=None
    try:
        r=_Reader(max_work,wall_seconds)
        for value in (base_model,marked_model,control_model,synthesis,query_packets,provenance):r.scan(value)
        base,marked,control=[_model(x,r) for x in (base_model,marked_model,control_model)]
        _require(base['pair_nogoods']==base['unary_nogoods']==[],'UNFILTERED_ORIGINAL_MODEL')
        scope=r.sha(base);ids=[x['id'] for x in base['inventory']['placements']]
        _require(type(guard_point) is str and bool(guard_point) and synthesis['guard_point']==guard_point,'PRESCRIBED_GUARD_POINT')
        points=set(base['roots'])
        for k in ('t','m'):
            for p,v in base['seed'][k]:r.step();points.add(p)
        for row in base['inventory']['placements']:
            for k in ('t','m'):
                for p,v in row[k]:r.step();points.add(p)
        _require(guard_point not in points,'GUARD_FRESH_FROM_ALL_T_M_SEED_ROOT_DOMAINS')
        _require(synthesis['status']=='SOLVED' and synthesis['scope_sha256']==scope,'SYNTHESIS_ORIGINAL_SCOPE')
        r.equal(synthesis['candidate_ids'],ids,'SYNTHESIS_ACTUAL_CIDS')
        labels=synthesis['labels'];_require(type(labels) is list and type(query_packets) is list and len(labels)==len(query_packets),'ALL_LABEL_PACKETS_PRESENT')
        proofs=[_query(base,p,scope,provenance,r) for p in query_packets]
        resolved={}
        for label,proof in zip(labels,proofs):
            _fields(label,{'cid','status','scope_sha256','certificate_binding_sha256'},'LEARNER_LABEL_FIELDS')
            r.equal(label,dict(cid=proof['cid'],status=proof['label'],scope_sha256=scope,
                              certificate_binding_sha256=proof['binding_sha256']),'LEARNER_TO_FRESH_QUERY_BINDING')
            if label['status']!='UNKNOWN':
                _require(label['cid'] not in resolved or resolved[label['cid']]==label['status'],'CONTRADICTORY_RESOLVED_LABELS')
                resolved[label['cid']]=label['status']
        forbidden=sorted(c for c,label in resolved.items() if label=='NEGATIVE')
        forbidden_set=set(forbidden)
        extra_seed=[[guard_point,'0']] if forbidden else []
        extra=[dict(id=c,m=[[guard_point,'1']]) for c in forbidden]
        for key,wanted in [('forbidden_cids',forbidden),('extra_seed_m',extra_seed),('extra_assignments',extra)]:
            r.equal(synthesis[key],wanted,'MINIMAL_EXACT_SPARSE_OVERLAY:'+key)
        em=dict(base,version=marked['version'],seed=dict(t=base['seed']['t'],m=sorted(base['seed']['m']+extra_seed)),
            inventory=dict(kind='EXPLICIT',placements=[dict(id=x['id'],t=x['t'],
                m=sorted(x['m']+([[guard_point,'1']] if x['id'] in forbidden_set else []))) for x in base['inventory']['placements']]))
        ec=dict(base,version=control['version'],unary_nogoods=forbidden)
        r.equal(marked,em,'ONLY_DECLARED_EXTRA_MARKING_LAYER_ADDED')
        r.equal(control,ec,'ONLY_ORDINARY_UNARY_FILTER_ADDED')
        custody=_custody(provenance,[p['binding_sha256'] for p in proofs],r)
        # base is the same independently normalized immutable value hashed as scope.
        model_bindings=dict(base=scope,marked=r.sha(marked),control=r.sha(control))
        r.step(1+len(r.metrics))
        return dict(schema='Scoped-unary-overlay-admission-v1',version=VERSION,
            status='VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION',scope_sha256=scope,guard_point=guard_point,
            forbidden_cids=forbidden,negative_cids=len(forbidden),unresolved_labels=sum(x['status']=='UNKNOWN' for x in labels),
            additional_seed_assignments=len(extra_seed),additional_cid_assignments=len(extra),query_bindings=proofs,
            model_bindings=model_bindings,custody=custody,
            preservation_basis='SCOPED_FIXED_CID_EXHAUSTIONS' if forbidden else 'EMPTY_ADDITIONAL_LAYER_IDENTITY',
            point_constraint_equivalence='Fresh guard seed0 and exactly forbidden CID1 reject exactly the ordinary unary list, without changing old t/m data.',
            proof_obligations=[
                'External driver authenticates physical model/raw/C3/native file bytes against evidence refs and the supplied prior LABEL process receipts.',
                'Pinned reviewed E4/C3 actually executed these objects, with clean native exit/source/runtime postchecks; this pure checker cannot authenticate execution from JSON alone.',
                'C3 complete finite fixed-CID UNSAT is sound for its exact full inventory; any original cover containing the CID induces a residual cover, contradiction.',
                'For POSITIVE labels the external decoder/carrier/native checker binds the fresh fixed-CID union to its original statement and proof; native proof truth is not checked here.'],
            scope='Finite explicit original model only; certificate-guided unary adaptation, not complete pair-corona learning, full subset enumeration, geometry transfer or unrestricted mathematical nonprovability.',
            work=r.work,seconds=time.perf_counter()-started,comparison_metrics=dict(r.metrics),
            comparison_metrics_scope='Additive counters; encode/sha/equal work intervals overlap and must not be summed. Work-meter v3 is not numerically interchangeable with v1/v2. Shared equal_sort counters include stream key sorts; stream_key_sort counters identify that subset. Stream stages overlap sha_work.')
    except _Budget as e:return dict(status='UNKNOWN',reason=str(e),work=0 if r is None else r.work,activation_admitted=False,comparison_metrics={} if r is None else dict(r.metrics))
    except (MemoryError,RecursionError,OverflowError) as e:return dict(status='UNKNOWN',reason='HOST_RESOURCE:'+type(e).__name__,activation_admitted=False,comparison_metrics={} if r is None else dict(r.metrics))
    except (_Reject,KeyError,TypeError,ValueError,IndexError,AttributeError) as e:return dict(status='REJECTED',reason=str(e),activation_admitted=False,comparison_metrics={} if r is None else dict(r.metrics))
