"""Prospective private U3 equality/streamed-SHA qualification, inert Source.

No engine, model, compiler, native kernel, old proof or label is called/read.
Root supplies pinned modules after freeze. Expected digests come only from
independent standard-library canonical JSON bytes, never the checker under test.
"""
import hashlib
import json
import time

VERSION = 'Streamed-canonical-qualification-v1'
INPUT = 'input/streamed-hash-qualification-v1.json'
EQUALITY_INPUT = 'input/overlay-equality-qualification-v1.json'


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def hash_result(ctx, value, *, zero_work=False):
    """One private hash call; persist its whole return before expected checks."""
    U = ctx.mods['U']
    limits = ctx.limits['U']
    need(limits == dict(max_work=1000000000, wall_seconds=120.0), 'UNCHANGED_U3_QUALIFICATION_LIMITS')
    reader = U._Reader(0 if zero_work else limits['max_work'], limits['wall_seconds'])
    started = time.perf_counter()
    digest = None
    try:
        digest = reader.sha(value)
        status, reason = 'HASHED', None
    except U._Reject as error:
        status, reason = 'REJECTED', str(error)
    except U._Budget as error:
        status, reason = 'UNKNOWN', str(error)
    return dict(status=status, reason=reason, digest=digest, work=reader.work,
                seconds=time.perf_counter() - started, metrics=dict(reader.metrics),
                scope='PRIVATE_STREAM_SHA_ONLY_NOT_PUBLIC_ACTIVATION_ADMISSION')


def valid_hash(ctx, identifier, specification, value):
    # The unmodified stdlib serializer supplies the complete independent bytes.
    # This intentionally materializes only the prospectively tiny corpus.
    wire = canonical(value)
    expected = hashlib.sha256(wire).hexdigest()
    answer = hash_result(ctx, value)
    record = dict(id=identifier, declaration=specification,
                  reference_wire=wire.decode('ascii'), reference_bytes=len(wire),
                  reference_sha256=expected, actual=answer)
    ref = ctx.save('data/qualify/stream-sha/' + identifier + '.json', record)
    need(answer['status'] == 'HASHED' and type(answer['digest']) is str
         and answer['digest'] == expected, 'EXACT_CANONICAL_STREAM_SHA:' + identifier)
    return dict(id=identifier, status='QUALIFIED', receipt=ref,
                reference_sha256=expected, reference_bytes=len(wire))


def numeric_value(recipe):
    """Explicit finite native scalar corpus; no proof-related construction."""
    values = dict(NULL=None, FALSE=False, TRUE=True, INT_ZERO=0, INT_ONE=1,
                  INT_NEGATIVE_ONE=-1, INT_MAX_256=(1 << 256) - 1,
                  INT_MIN_256=-((1 << 256) - 1), FLOAT_POSITIVE_ZERO=0.0,
                  FLOAT_NEGATIVE_ZERO=-0.0, FLOAT_ONE=1.0, FLOAT_NEGATIVE_ONE=-1.0,
                  FLOAT_MAX= float.fromhex('0x1.fffffffffffffp+1023'),
                  FLOAT_MIN_FINITE=-float.fromhex('0x1.fffffffffffffp+1023'),
                  FLOAT_MIN_SUBNORMAL=float.fromhex('0x0.0000000000001p-1022'),
                  FLOAT_MIN_NORMAL=float.fromhex('0x1.0000000000000p-1022'),
                  FLOAT_BELOW_ONE=float.fromhex('0x1.fffffffffffffp-1'),
                  FLOAT_ABOVE_ONE=float.fromhex('0x1.0000000000001p+0'),
                  FLOAT_EXP_SMALL=1e-7, FLOAT_EXP_LARGE=1e21)
    need(type(recipe) is str and recipe in values, 'DECLARED_NATIVE_SCALAR_RECIPE')
    return values[recipe]


def run(ctx):
    """Root freezes all files/runtime before supplying this data-only context."""
    started = time.perf_counter()
    spec = ctx.read(INPUT)
    need(spec['schema'] == 'Streamed-canonical-SHA-qualification-v1'
         and spec['status'] == 'DECLARED_NOT_RUN', 'DECLARED_STREAMED_HASH_INPUT')
    J = ctx.mods['J']
    equality = J.equality_qualification(ctx)
    equality_ref = ctx.save('data/qualify/equality-summary.json', equality)
    need(equality['status'] == 'QUALIFIED_CANONICAL_EQUALITY_PRIMITIVE'
         and len(equality['cases']) == 28 and len(equality['refusals']) == 8,
         'UNCHANGED_28_PLUS_8_PRIVATE_EQUALITY_GATE')
    originals = ctx.read(EQUALITY_INPUT)
    pairs = originals['valid_pairs'] + originals['recipes']
    need(len(pairs) == len({x['id'] for x in pairs}) == spec['comparison_pairs'] == 28,
         'ALL_DECLARED_COMPARISON_PAIRS_HASHED')
    rows = []
    for pair in pairs:
        left, right = (J.equality_recipe(pair) if 'recipe' in pair
                       else (pair['left'], pair['right']))
        for side, value in (('left', left), ('right', right)):
            rows.append(valid_hash(ctx, pair['id'] + '-' + side,
                                   dict(source=EQUALITY_INPUT, pair_id=pair['id'], operand=side), value))
    byte_range = spec['byte_codepoint_range']
    need(byte_range == dict(first=0, last=255), 'COMPLETE_BYTE_CODEPOINT_CORPUS')
    for codepoint in range(byte_range['first'], byte_range['last'] + 1):
        rows.append(valid_hash(ctx, 'byte-%03d' % codepoint,
                               dict(recipe='BYTE_CODEPOINT', codepoints=[codepoint]), chr(codepoint)))
    boundaries = spec['boundary_codepoints']
    need(type(boundaries) is list and all(type(x) is int and 0 <= x <= 0x10FFFF for x in boundaries)
         and boundaries == sorted(set(boundaries)), 'UNIQUE_NATIVE_UNICODE_BOUNDARIES')
    for codepoint in boundaries:
        rows.append(valid_hash(ctx, 'boundary-%06X' % codepoint,
                               dict(recipe='BOUNDARY_CODEPOINT', codepoints=[codepoint]), chr(codepoint)))
    for sequence in spec['string_sequences']:
        points = sequence['codepoints']
        need(type(points) is list and all(type(x) is int and 0 <= x <= 0x10FFFF for x in points),
             'NATIVE_STRING_SEQUENCE_CODEPOINTS')
        rows.append(valid_hash(ctx, sequence['id'], sequence, ''.join(chr(x) for x in points)))
    for scalar in spec['native_scalars']:
        rows.append(valid_hash(ctx, scalar['id'], scalar, numeric_value(scalar['recipe'])))
    need(len(rows) == len({x['id'] for x in rows}), 'UNIQUE_ALL_STREAM_HASH_CASE_IDS')
    declarations = {x['id']: x for x in originals['refusals']}
    controls = []
    need(len(spec['hash_refusals']) == len(declarations) == 8
         and {x['source_id'] for x in spec['hash_refusals']} == set(declarations), 'ENTIRE_EIGHT_HASH_REFUSAL_CORPUS')
    for control in spec['hash_refusals']:
        declaration = declarations[control['source_id']]
        left, right = J.equality_recipe(declaration)
        side = control['operand']
        need(side in ('left', 'right'), 'DECLARED_INVALID_HASH_OPERAND')
        value = left if side == 'left' else right
        answer = hash_result(ctx, value, zero_work=declaration['recipe'] == 'ZERO_WORK')
        ref = ctx.save('data/qualify/stream-sha-controls/' + control['id'] + '.json',
            dict(id=control['id'], declaration=declaration, operand=side, actual=answer,
                 scope='Invalid/resource recipe only; invalid object itself is not lossy-serialized as evidence.'))
        expected = declaration['expected']
        need(answer['digest'] is None and (answer['status'] in ('REJECTED', 'UNKNOWN')
             if expected == 'NO_ACCEPTANCE' else answer['status'] == expected),
             'NO_HASH_FROM_INVALID_OR_RESOURCE_CONTROL:' + control['id'])
        controls.append(dict(id=control['id'], status=answer['status'], reason=answer['reason'], receipt=ref))
    return dict(schema='Streamed-checker-qualification-v1', version=VERSION, status='QUALIFIED',
                equality_qualification=equality_ref, hash_cases=rows, hash_controls=controls,
                counts=dict(equal_valid=28, equal_refusals=8,
                            equality_private_calls=equality['private_primitive_calls'],
                            pair_hash_calls=2 * len(pairs), byte_codepoint_hash_calls=256,
                            boundary_hash_calls=len(boundaries), sequence_hash_calls=len(spec['string_sequences']),
                            scalar_hash_calls=len(spec['native_scalars']),
                            successful_hash_calls=len(rows), hash_refusal_calls=len(controls)),
                module_seconds=time.perf_counter() - started,
                scope='Fresh private U3 equality/streamed-SHA qualification only. No engine, model, theorem proof, native kernel, failure label or public activation is constructed or called; prior exact E4/logical qualification admission is a separate driver gate.')
