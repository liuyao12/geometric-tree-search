# Independent streamed checker and warm-driver Source closure

Status: `PASS_SOURCE_REVIEW_BEFORE_FREEZE`. No remaining blocker was found.
This is Source/metadata review, not an executed qualification, activation,
search result, native proof or performance measurement. No scientific module
was imported or called and no SHA/equality test was executed.

I read U3's complete body/API and complete U2 delta, the complete warm phase
body/API, the common worker/observer, prospective plan, and the final narrow
loaded-method/runtime and warm-control-scope corrections. The copied normative
master remains the exact already-read point-model reference, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

| Held file | Bytes | SHA256 |
| --- | ---: | --- |
| `source/unary_overlay_checker_v3.py` | 30333 | `9ffc23073a41ccfbc81bd4c39fb892b2f11212cbdaff37155bc2db73aef85ff6` |
| `source/streamed_phases_v1.py` | 24255 | `b1a7055fefc2306cef2d8ebb99afd0197a1e401af9f46fbf65f38a5e723390dc` |
| `source/run_streamed_arithmetic_v1.py` | 20601 | `53e4fc42f666ed28aa1b69d1039e575e321fee85d8c7ebb4d9e99745ae8ddc11` |
| `plan/overlay-checker-v3-API-v1.md` | 8037 | `5adca224ac0c2fe8ca81d133b74ed7fc1b2f1d46513d13f7a79142b0302ea426` |
| `plan/streamed-phases-API-v1.md` | 10247 | `b9451048c517c048aeb5e6c7f4d7ff400c229f78f47ddd464e7c8fac9313c90a` |
| `plan/streamed-experiment-v1.json` | 3724 | `c9119ffe7ac6e85411e32a7495c98eceac4a7b926536a1d61a5d31fe953d310d` |

K3 is authored by this reviewer, so its own authoring is not counted as an
independent peer vote. Root separately read its full body and final buffer
control. Its held closure pins are Source 9,948 bytes /
`bdf8bae6ffe724cdfdc79b706207edad43b4ca6e4ca506066f3bc24a224d2d12`,
input 3,542 bytes /
`86f17c93983c815dc70be81a041cf617d28760974d49ec500217a42f27996fcb`,
API 7,571 bytes /
`da224cc7d7f319095ee9b93c31bdcee136723ca7f2f5b2c38ac3d2a9e38ca70e`.
Its declared corpus is unchanged \(28+8\) private equality calls, \(361\)
valid-reference SHA calls and \(9\) SHA refusal controls, not observed outcomes.

## Canonical stream equivalence and bounds

Let \(W(x)\) be the preceding sorted-key, `ensure_ascii=True`, compact,
`allow_nan=False` JSON encoded as ASCII plus exactly one LF. For stable finite
native JSON that completes within U3's resource envelope, Source inspection
supports

\[
 \operatorname{concat}(\operatorname{fragments}_3(x))=W(x),
 \qquad
 \operatorname{sha}_3(x)=\operatorname{SHA256}(W(x)).
\]

The argument is structural. Arrays retain ordered members and exact brackets/
commas. Objects retain Python-native sorted key/value order, braces, commas and
colons. The unchanged metered key sorter preserves Unicode/surrogate aliases,
duplicate escaped keys and their native ordering; it does not normalize keys.
Scalars use the same standard-library JSON spelling. The stream appends one LF
after the complete root, and SHA receives every fragment in that order.

The exact pre-encoder string-length computation matches those spellings:
quote/backslash and the five named control escapes use two bytes, printable
ASCII through codepoint \(126\) uses one, other BMP codepoints use six and
astral codepoints use twelve, plus both quotes. DEL \(127\) correctly takes
the six-byte path. Literal surrogate pairs and single astral characters retain
the old escaped-byte relation. Integer decimal length handles zero/sign through
bounded division under the existing \(256\)-bit input guard. Floats retain the
bounded standard-library spelling, finite-only check and signed-zero distinction.
Null/Boolean static fragments are exact.

Entire native graphs are validated before any stream hashing, including later
invalid branches, finite floats, key types, depth, ancestor cycles and shared
acyclic values. List/object traversal holds iterators and native-sorted key
lists, rather than an all-descendants work list or compound wire. The scalar
ceiling is an explicit resource bound: oversized values return UNKNOWN, not a
logical rejection or narrowed candidate universe. A lower-bound guard rejects
an already oversized native string before character encoding; otherwise exact
escaped length is computed before scalar JSON/ASCII buffers are allocated.
Both buffer allocations are charged and checked. This bounds each output
representation, not total Python RSS; live input, key lists and previous
fragments may coexist. The independent owned process guard remains necessary.

Every fragment is charged before hash update and checked afterward. Scalar
C encoders and final digest operations also have post-operation checks. A
validation or budget exception cannot return a digest or activate a marking.
Partial stream-byte metrics describe work already performed, not a usable
partial certificate. K3's oversized **root** string specifically requires zero
scalar allocations/fragments and hashed bytes, with no huge reference wire or
huge input serialized into its evidence.

AST comparison confirms U3 changes only Reader initialization/SHA and adds its
stream helpers. Reader equality, full validation, bounded encode and native
key sort remain unchanged. Every top-level logical gate helper retains its
body. Public `verify` changes explanatory metric scope/version only. The
model/fixed-CID/query/raw/C/native/event/endpoint/sparse overlay/control/prior
LABEL custody obligations therefore remain intact. Numeric work/wall caps
remain one billion and \(120\) seconds; stream stages and shared key-sort
counters are explicitly overlapping and not cross-version equal-cost units.

## Warm evidence and current Source identity

The prior resolver authenticates every manifest member and the exact prior
physical file set before scientific data reuse, rejecting symlinks/traversal.
Projected **new** refs use `prior/v2/`; original inline protocol/query/binding/
LABEL provenance strings and hashes are not rewritten. Old and current
protocols retain distinct roles: genuine old LABEL PID/native-zero custody
justifies the retained scoped failure, while the new ADMIT process/protocol
authenticates U3's new execution.

The old frozen file set, actual five phase IDs/PIDs/native exits, result/log/
protocol refs, guards and postchecks are joined. Original LEARN stays UNKNOWN;
no activated old model or target evaluation/fixed-union proof is admitted.
Preparation is joined to the original declaration, full RF/profile/bridge/
catalogue/model/universe receipts, native ZERO payload hashes and complete
one-line native checks. The original query objects are bound to their actual
physical file hashes and finite C-verified UNSAT; labels/synthesis/candidate
scope and original provenance are checked without rerunning an old helper.

The final reuse gate closes the distinction between authenticated old methods
and currently loaded methods. All fourteen unchanged roles
`E,C,M,N,B,D,J,F,R,A,Q,L,T,O` require `__file__` at the exact expected current-root
path, with no symlink, and physical Source bytes identical to their originally
qualified prior frozen entries. Entire current/old runtime declarations match,
including binary, version and flags. New U3/H/K are explicitly excluded from
that equality and instead have current Source review/qualification/freeze.
This justifies reusing engine/native/carrier qualification without pretending
the new private hash corpus requalified E4.

The manifest's lack of an old target proof and known output-path exclusions
are enforced; no old selected target proof is supplied to search. All prior
Root/publication and scientific namespaces remain immutable.

## Activation, fresh search and process scope

ADMIT performs a real new U3 public call on the exact retained candidate and
authentic old failure/provenance. It saves the actual return before its gate,
checks all three model hashes, then executes the five actual-packet corruption/
resource controls. They must all apply and pass before activated files are
written. The final one-line scope correction truthfully labels these as new
U3 calls on **prior** data, not new failure discovery, synthesis or a fabricated
successful LABEL process. A refused/failed gate preserves its artifacts and
prevents activation.

EVALUATE requires the new actual ADMIT process admission, reauthenticates all
prior bytes, checks admitted model refs/hashes and runs fresh BASE/MARKS/FILTER.
Complete candidate identities, mandatory original logical marks, exact point
rules, scheduler, rollback, engine/checker caps and primitive fallback are
preserved. D.engine saves raw outcomes before independent semantic checking;
D.decode uses the original complete prepared catalogue, matches both M/N
projections and freshly checks B for every returned positive. UNKNOWN cannot
become bounded absence. Semantic event/endpoints assurance is not reported as
observed intermediate-map equality.

The common driver retains immutable Source/input/review/runtime/master freeze,
isolated no-site/no-bytecode children, exact prior phase/PID/status/result/log
admission, owned CPU/wall/sampled-RSS guards, exclusive captures, native wait
status and final Source checks. Three new phases are explicit; no new LABEL or
LEARN process is invented. Metadata authentication hashing is separately
outer-guarded and timed, rather than silently charged to U3's meter.

This is warm reuse of preparation/failure/unactivated candidate, with zero new
failure labels or synthesis calls claimed. Old preparation/acquisition/learning
costs and new authentication/U3/control/search/native-assurance costs have
separate overlapping scopes. No cold speed claim, new target proof, RL gain,
unbounded nonprovability or uniform Wang palette is established by this review.

Only Source, static metadata and AST comparisons were inspected; this note
contains no compiler/model/engine/checker/kernel/learner execution, transition
replay, benchmark or proof input. All actual outcomes remain prospective until
Root's freeze and owned run.
