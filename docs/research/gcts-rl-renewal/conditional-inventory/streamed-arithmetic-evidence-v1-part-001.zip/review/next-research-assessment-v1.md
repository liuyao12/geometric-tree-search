# Research assessment and next experiment

The streamed checker removed an actual admission bottleneck: the reused overlay
passed U3 within its unchanged work ceiling, then passed all five activation
controls. That is useful assurance engineering. It has not yet produced useful
arithmetic proof search. All three fresh eight-slot searches ended with raw and
semantic `UNKNOWN`; none supplied an arithmetic-target proof or a finite
nonexistence certificate.

| Fresh lane | Raw stop | Search seconds | Nodes | Semantic seconds | Engine plus assurance seconds |
|---|---|---:|---:|---:|---:|
| BASE | `WALL_SECONDS` | 120.929 | 2781 | 140.482 | 266.616 |
| MARKS | `WALL_SECONDS` | 121.063 | 2638 | 135.000 | 261.283 |
| FILTER | `WALL_SECONDS` | 121.092 | 2719 | 142.907 | 269.244 |

These are actual saved intervals, not repeat estimates. Each semantic receipt
says `RAW_UNKNOWN_PREFIX_NO_ABSENCE`, even though its emitted-event payload is
complete. U3 admission took 60.040 seconds, controls 140.658 seconds and warm
authentication 6.010 seconds, separately from the lane costs. Fixed lane order,
different stopped prefixes and overlapping measurement scopes preclude a speed
conclusion from the small node differences.

The single unary exclusion of a bad GEN owner is weak information. It preserves
the original inventory and mandatory logical markings, but does not organize
the remaining proof choices. No RL was used and no distinctive GCTS advantage
has been demonstrated. These outcomes do not identify whether the limiting
factor was the finite formula/slot scope, search ordering, useful-lemma scarcity
or runtime overhead; a wall-limited prefix cannot settle those alternatives.
The two readable native proofs remain reused qualification examples, not proofs
of the arithmetic target. The representation remains a finite generated
formula/CID palette, not one finite universal Wang tile set.

## Proposed next experiment

Use the same seen arithmetic target as a declared diagnostic, retain the full
RF catalogue and eight-slot semantics, and freeze a bounded conventional
forward/shared-fact baseline alongside GCTS before execution. Neither method
receives a target derivation or historical proof. Record preparation, search,
proposal checking and final native verification separately. Keep the complete
point frontier, global dead/forced priority, generation ordering, rollback and
primitive fallback unchanged.

First add **certified grammar reachability and slot-rank pruning**. From every
admitted native ZERO and the complete MP/GEN catalogue, compute the least
forward-closed formula set. Independently check the complete producer census
and closure certificate. A formula outside that set is impossible in this
finite grammar. Also compute a necessary earliest-slot bound, for example
native ZERO rank \(1\), GEN rank \(1+r(s)\), and MP rank
\(1+\max(r(a),r(i))\), minimizing over all its producers. An unintroduced
formula of rank greater than \(j+1\) cannot be introduced at zero-based slot
\(j\). These are derived constraints on the original complete grammar, not
manual producer removal. PAD and duplicate facts require their original
semantics. Do not treat backward goal relevance as an all-solution-preserving
filter: a valid padded proof may contain unused facts.

Then test **informative receptor and lemma families**, rather than another
single forbidden owner. Learn from newly completed, scoped failure queries and
short native-checked subderivations found by search. A receptor should describe
the available premise formulas, required conclusion, remaining slots and
relevant shared-reference/mark interface. A reusable cluster must instantiate
that interface, retain its hypotheses and expand to admitted primitive rows;
every instantiated native derivation must pass the kernel. A discovered example
alone does not certify an unrestricted schematic family. Failed-context clauses
also need a preservation proof before becoming literal marking constraints.

The critical comparison is matched information: give an ordinary nogood/filter
control exactly the same certified failures, and a conventional lemma-enabled
search exactly the same admitted lemma instances. Charge acquisition and
validation to both, retain the complete fallback, and use common declared
search budgets with distinct observer/resource accounting. A later separately
frozen target family can test transfer; this seen-target diagnostic cannot.
RL should wait until this baseline can find native-checked target proofs and
the proposed actions have an independently verified interface.

The experiment would count as proof-search progress if it finds an original
native-checked target proof, or a complete finite refutation, and establishes
which certified constraints or reusable lemmas changed completed work relative
to the matched controls. If all arms remain UNKNOWN, or literal markings only
repeat the conventional filter's effect at greater cost, retain that result and
do not call it an algorithmic advantage.

Evidence read for this note: `data/admit/result.json`,
`data/evaluate/result.json`, the three referenced saved semantic receipts, and
`run/evaluate/invocation.json` / `observer.json`. This was a passive assessment:
no engine, compiler, checker, learner, native kernel or proof search was imported
or executed; no frozen input or Source was changed.
