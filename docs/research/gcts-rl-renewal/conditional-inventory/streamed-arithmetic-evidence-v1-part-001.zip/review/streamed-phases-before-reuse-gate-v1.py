"""Explicit warm admission and fresh evaluation; inert until Root's freeze.

Only stdlib imports. Prior V2 files and genuine LABEL provenance are read-only.
No compiler, label search, learner, old target proof or strategy is rerun/read
as a new search input. New U3 execution has separate current-root custody.
"""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import time

VERSION = 'Streamed-arithmetic-warm-phases-v1'
MANIFEST = 'input/prior-evidence-v1.json'
PREFIX = 'prior/v2/'
PROTOCOL = 'protocol/frozen-protocol-v1.json'
GUARD = 'learned:unary:guard:v1'
CAPTURE = 134217728


def need(ok,why):
    if not ok:
        raise ValueError(why)


def same(a,b,why):
    need(digest(a)==digest(b),why)


def digest(value):
    """Metadata/content SHA, canonical stdlib JSON+LF, without a giant wire copy.

    This is data authentication, not the U3 checker or its work meter. Root's
    owned outer guards bound this preparation; its elapsed cost is retained.
    """
    h=hashlib.sha256();count=0
    encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
    for text in encoder.iterencode(value):
        raw=text.encode('ascii');count+=len(raw)
        need(count<CAPTURE,'METADATA_CANONICAL_CAPTURE_BOUND')
        h.update(raw)
    h.update(b'\n')
    return h.hexdigest()


def relative(name):
    need(type(name) is str and name and '\\' not in name and '\0' not in name,'RELATIVE_TEXT')
    p=PurePosixPath(name)
    need(not p.is_absolute() and p.as_posix()==name and all(x not in ('','.','..') for x in p.parts),'CANONICAL_RELATIVE_PATH')
    return name


def path(ctx,name):
    out=ctx.root
    for part in PurePosixPath(relative(name)).parts:
        out=out/part;need(not out.is_symlink(),'NO_INPUT_SYMLINK')
    need(out.resolve().is_relative_to(ctx.root.resolve()),'INPUT_CONTAINMENT')
    return out


def pin(p):
    h=hashlib.sha256();size=0
    with p.open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):
            h.update(part);size+=len(part)
    return dict(bytes=size,sha256=h.hexdigest())


def ref(ctx,name):
    return dict(path=name,**pin(path(ctx,name)))


def logical_hash(ctx,name):
    p=path(ctx,name);h=hashlib.sha256()
    with (gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb')) as stream:
        for part in iter(lambda:stream.read(1048576),b''):h.update(part)
    return h.hexdigest()


class Prior:
    """Resolve original relative refs ONLY under the separately pinned prior root."""
    def __init__(self,ctx):
        self.ctx=ctx;self.manifest=ctx.read(MANIFEST)
        m=self.manifest
        need(m['schema']=='Streamed-arithmetic-prior-evidence-v1' and m['namespace']=='prior/v2','PRIOR_MANIFEST_SCOPE')
        need(type(m['target_proofs']) is int and m['target_proofs']==0,'NO_PRIOR_TARGET_PROOF_INPUT')
        entries=m['files'];need(type(entries) is list and entries,'FULL_PRIOR_FILE_LIST')
        self.entries={relative(x['path']):x for x in entries}
        need(len(self.entries)==len(entries) and [x['path'] for x in entries]==sorted(self.entries),'SORTED_UNIQUE_PRIOR_FILES')
        # Authenticate EVERY physical manifest member before any old data helper
        # or new scientific method can consume its content.
        for name,entry in self.entries.items():
            need(type(entry['bytes']) is int and entry['bytes']>=0,'PRIOR_NATIVE_BYTE_COUNT')
            need(pin(path(ctx,PREFIX+name))=={k:entry[k] for k in ('bytes','sha256')},'EVERY_PRIOR_BYTE:'+name)
        actual=set()
        for p in path(ctx,'prior/v2').rglob('*'):
            need(not p.is_symlink(),'NO_PRIOR_TREE_SYMLINK')
            if p.is_file():actual.add(p.relative_to(path(ctx,'prior/v2')).as_posix())
        need(actual==set(self.entries),'EXACT_PHYSICAL_PRIOR_FILE_SET')

    def project(self,original):
        name=relative(original['path'])
        need(name in self.entries,'ORIGINAL_REF_IN_PRIOR_MANIFEST:'+name)
        need(original.get('complete_json',True) is True,'PRIOR_COMPLETE_CAPTURE')
        same({k:original[k] for k in ('bytes','sha256')},
             {k:self.entries[name][k] for k in ('bytes','sha256')},'EXACT_ORIGINAL_REF:'+name)
        return dict(original,path=PREFIX+name)

    def read(self,name):
        need(name in self.entries,'PRIOR_OBJECT_LISTED:'+name)
        return self.ctx.read(PREFIX+name)

    def readref(self,original):
        projected=self.project(original)
        return self.ctx.read(projected['path'])

    def refs(self,value):
        if type(value) is dict:
            if {'path','bytes','sha256'}<=set(value) and not value['path'].startswith('/'):
                self.project(value)
            for child in value.values():self.refs(child)
        elif type(value) is list:
            for child in value:self.refs(child)


def authenticate(ctx,prior):
    protocol=prior.read(PROTOCOL)
    need(protocol['schema']=='Quantified-marking-transfer-protocol-v1'
         and protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','ORIGINAL_V2_FROZEN_PROTOCOL')
    old_proto_ref=prior.entries[PROTOCOL]
    need(old_proto_ref['sha256']==prior.manifest['protocol_sha256']==digest(protocol),'EXACT_ORIGINAL_PROTOCOL_BYTES')
    admission=prior.read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','ORIGINAL_SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    names.update(n for n in prior.entries if n.split('/')[0] in ('source','reference','input','plan'))
    for entry in admission['reviewed']:prior.project(entry);names.add(entry['path'])
    actual=[dict(path=n,bytes=prior.entries[n]['bytes'],sha256=prior.entries[n]['sha256']) for n in sorted(names)]
    same(actual,protocol['files'],'ENTIRE_ORIGINAL_FROZEN_FILE_SET')
    for entry in (protocol['master'],protocol['runtime']['executable']):
        need(Path(entry['path']).is_absolute(),'ORIGINAL_EXTERNAL_PIN_PATH')
        same(pin(Path(entry['path'])),{k:entry[k] for k in ('bytes','sha256')},'ORIGINAL_CURRENT_MASTER_RUNTIME')
    same(pin(path(ctx,'reference/basic-tiling-algorithm.md')),
         {k:protocol['master'][k] for k in ('bytes','sha256')},'SAME_NORMATIVE_MASTER')
    statuses=dict(qualify='QUALIFIED',prepare='PREPARED',acquire='ACQUIRED_PROPOSAL',label='LABELLED',learn='UNKNOWN')
    phases=[];results={}
    for name,expected in statuses.items():
        s,i,o=[prior.read('run/'+name+'/'+k+'.json') for k in ('started','invocation','observer')]
        result=prior.read('data/'+name+'/result.json')
        need(s['phase']==i['phase']==o['phase']==name and all(type(v['pid']) is int and v['pid']>0 for v in (s,i,o))
             and s['pid']==i['pid']==o['pid'],'ORIGINAL_PHASE_PID:'+name)
        need(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
             and i['status']=='COMPLETE' and i['error_type'] is None,'ORIGINAL_NATIVE_CLEAN:'+name)
        need(all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
             and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==protocol['status'],'ORIGINAL_GUARDS:'+name)
        same(s['protocol'],dict(path=PROTOCOL,bytes=old_proto_ref['bytes'],sha256=old_proto_ref['sha256']),'ORIGINAL_STARTED_PROTOCOL')
        need(i['result']['path']=='data/'+name+'/result.json' and i['result']['complete_json'] is True,'ORIGINAL_PHASE_RESULT_PATH')
        prior.project(i['result']);need(o['log']['path']=='run/'+name+'/stdout.log','ORIGINAL_OWNED_LOG_PATH');prior.project(o['log'])
        need(i['scientific_status']==result['status']==expected,'ORIGINAL_SCIENTIFIC_STATUS:'+name)
        prior.refs(result);results[name]=result
        phases.append(dict(name=name,pid=o['pid'],native_exit_code=0,scientific_status=expected,
            scientific_admitted=name!='learn',result=prior.project(i['result']),log=prior.project(o['log']),
            worker_seconds=i['seconds'],observer_seconds=o['seconds']))
    need(not any(n.startswith(('data/evaluate/','run/evaluate/','data/label/fixed-union-native/')) for n in prior.entries),'NO_PRIOR_TARGET_PROOF_OR_EVALUATION')
    need(results['learn']['status']=='UNKNOWN' and results['label']['native_verified'] is False
         and all(x['status']=='NEGATIVE' for x in results['label']['labels']),'PRIOR_FAILURE_ONLY_NO_TARGET_WITNESS')
    need(not any(n in prior.entries for n in ('data/learn/marked-model.json.gz','data/learn/control-model.json.gz')),'PRIOR_OVERLAY_UNACTIVATED')
    current=ctx.read(PROTOCOL)
    need(current['schema']=='Streamed-arithmetic-protocol-v1' and current['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','SEPARATE_CURRENT_EXECUTION_PROTOCOL')
    receipt=dict(schema='Streamed-arithmetic-prior-authentication-v1',status='AUTHENTICATED_PRIOR_V2_WARM_INPUT',
        namespace='prior/v2',manifest=ref(ctx,MANIFEST),physical_files=len(prior.entries),
        prior_protocol=prior.project(dict(path=PROTOCOL,bytes=old_proto_ref['bytes'],sha256=old_proto_ref['sha256'])),
        current_protocol=ref(ctx,PROTOCOL),original_protocol_sha256=old_proto_ref['sha256'],phases=phases,
        prior_target_proofs=0,prior_overlay_activated=False,
        scope='Prior LABEL is genuine old execution, not a new LABEL phase. No compiler, label search, learner or old proof is rerun as search input.')
    return results,receipt


def load_warm(ctx,prior,results):
    p=results['prepare'];r=p['refs'];prepared=prior.readref(r['prepared']);base=prior.readref(r['model'])
    declared=prior.readref(r['declaration']);same(declared,ctx.read('input/arithmetic-declaration-v1.json'),'SAME_SEEN_ARITHMETIC_DECLARATION')
    same(prepared['binding'],p['prepared_binding'],'PRIOR_COMPLETE_PREPARED_BINDING')
    same(prepared['statement'],declared['problem'],'UNCHANGED_ORIGINAL_STATEMENT')
    need(digest(base)==p['scope_sha256'],'ORIGINAL_ENGINE_MODEL_SCOPE')
    back={k:base[k] for k in ('capacity','roots','seed','inventory')}
    same(back,{k:prepared['model'][k] for k in back},'WARM_MODEL_CIDS_T_M_IDENTICAL')
    need(base['schema']=='Z-growing-point-model-v3' and base['pair_nogoods']==base['unary_nogoods']==[]
         and base['version']==prepared['model']['version']+':engine-v4','ORIGINAL_EXACT_SCHEMA_MIGRATION')
    rf=prior.readref(r['rf_receipt']);q=prior.readref(r['bridge_receipt']);n=prior.readref(r['model_receipt'])
    compiled=prior.readref(r['compiled']);generation=prior.readref(r['generation']);bridge=prior.readref(r['bridge'])
    need(rf['status']==q['status']==n['status']=='VERIFIED','ORIGINAL_FULL_PROFILE_BRIDGE_MODEL_GATES')
    need(rf['declaration_sha256']==digest(declared) and rf['compiled_core_sha256']==generation['compiled_core_sha256']
         ==digest({k:v for k,v in compiled.items() if k not in ('costs','scope')}),'PRIOR_COMPLETE_RF_HASH_BINDINGS')
    same(bridge['catalogue'],prepared['catalogue'],'PRIOR_COMPLETE_BRIDGE_CATALOGUE')
    same(q['bindings'],bridge['bindings'],'PRIOR_BRIDGE_ADMISSION_BINDINGS')
    need(n['catalogue_sha256']==bridge['bindings']['catalogue_sha256']
         and n['original_statement_sha256']==digest(declared['problem']),'PRIOR_ORIGINAL_THEORY_GOAL_BINDINGS')
    same(n['census'],prepared['census'],'PRIOR_ALL_ROW_CENSUS')
    need(n['model_sha256']==digest(prepared['model']) and n['universe_sha256']==digest(prepared['universe'])
         and n['catalogue_sha256']==digest(prepared['catalogue']),'PRIOR_FULL_MODEL_UNIVERSE_HASHES')
    zeros=prior.readref(r['zero_native_receipts']);need(len(zeros)==len(compiled['zero_instances'])==p['ZERO_checks']==prepared['census']['zero_definitions'],'EVERY_PRIOR_ZERO_RECEIPT')
    for source,z in zip(compiled['zero_instances'],zeros):
        need(source['id']==z['id'] and source['formula_id']==z['formula_id'] and digest(source['line'])==z['native_line_sha256']
             and z['receipt']['status']=='VERIFIED' and z['receipt']['checked_lines']==1,'PRIOR_NATIVE_ZERO_PAYLOAD_GATE')
    label=results['label'];packet=prior.readref(label['query_packets_ref']);synthesis=prior.readref(results['learn']['refs']['synthesis'])
    overlay=prior.readref(results['learn']['refs']['overlay']);provenance=prior.readref(results['learn']['refs']['provenance'])
    binding=packet['binding'];scope=digest(base)
    need(packet['label']=='NEGATIVE' and packet['scope_sha256']==binding['scope_sha256']==binding['base_model_sha256']==scope,'GENUINE_SCOPED_PRIOR_FAILURE')
    need(binding['raw_result_sha256']==digest(packet['raw_result']) and binding['semantic_receipt_sha256']==digest(packet['semantic_receipt'])
         and binding['fixed_model_sha256']==digest(packet['fixed_model']),'ORIGINAL_PACKET_CONTENT_HASHES')
    for field,key in (('raw_result_sha256','raw'),('semantic_receipt_sha256','semantic'),('fixed_model_sha256','model')):
        projected=prior.project(binding['evidence_refs'][key])
        need(binding[field]==logical_hash(ctx,projected['path']),'ORIGINAL_QUERY_OBJECT_TO_ACTUAL_FILE:'+key)
    raw,c=packet['raw_result'],packet['semantic_receipt']
    need(raw['status']=='UNSAT' and raw['reason']=='EXHAUSTED_DECLARED_FINITE_INVENTORY'
         and raw['selected']==[] and raw['certificate'] is None and c['status']=='VERIFIED'
         and c['run_status']=='UNSAT' and c['bounded_absence'] is True
         and c['claim']=='SEMANTIC_COMPLETE_FINITE_EXHAUSTION' and c['event_coverage']=='COMPLETE','PRIOR_CERTIFIED_FINITE_FAILURE_ONLY')
    same(label['query_bindings'],[binding],'OLD_LABEL_BINDING_ARRAY');same(label['labels'],synthesis['labels'],'OLD_LABELS_NOT_RELEARNED')
    need(label['labels'][0]['certificate_binding_sha256']==digest(binding),'OLD_TYPED_LABEL_CERTIFICATE_BINDING')
    prior.refs(binding['evidence_refs']);prior.refs(provenance)
    same(provenance['label_phase']['result'],label,'GENUINE_ORIGINAL_LABEL_RESULT')
    same(provenance['protocol']['value'],prior.read(PROTOCOL),'GENUINE_INLINE_OLD_PROTOCOL_UNCHANGED')
    same(provenance['label_phase']['started'],prior.read('run/label/started.json'),'GENUINE_OLD_LABEL_STARTED')
    same(provenance['label_phase']['invocation'],prior.read('run/label/invocation.json'),'GENUINE_OLD_LABEL_INVOCATION')
    same(provenance['label_phase']['observer'],prior.read('run/label/observer.json'),'GENUINE_OLD_LABEL_OBSERVER')
    need(synthesis['status']=='SOLVED' and overlay['status']=='CONSTRUCTED_UNVERIFIED_OVERLAY'
         and synthesis['scope_sha256']==overlay['scope_sha256']==scope,'UNCHANGED_UNACTIVATED_CANDIDATE')
    old_admission=prior.readref(results['learn']['refs']['overlay_receipt'])
    need(old_admission['status']=='UNKNOWN' and old_admission.get('activation_admitted') is False,'ORIGINAL_V2_REFUSAL_PRESERVED')
    same(synthesis['forbidden_cids'],overlay['forbidden_cids'],'EXACT_CANDIDATE_CONSTRAINT')
    need(len(base['inventory']['placements'])==prepared['census']['rows'],'FULL_WARM_INVENTORY')
    return prepared,base,synthesis,overlay,packet,provenance


def save(ctx,name,value,refs,key):
    result=ctx.save(name,value);need(result.get('complete_json') is True,'COMPLETE_NEW_ARTIFACT');refs[key]=result
    return result


def admit(ctx):
    start=time.perf_counter();prior=Prior(ctx);results,authentication=authenticate(ctx,prior)
    prepared,base,synthesis,overlay,packet,provenance=load_warm(ctx,prior,results)
    authentication_seconds=time.perf_counter()-start;refs={};costs=dict(prior_authentication_seconds=authentication_seconds)
    save(ctx,'data/admit/prior-authentication.json',authentication,refs,'prior_authentication')
    save(ctx,'data/admit/original-v2-provenance.json.gz',provenance,refs,'original_provenance')
    # No path/hash in this genuine original object is rewritten to pretend
    # that the current run produced its LABEL. U3 execution is new and distinct.
    start=time.perf_counter()
    u=ctx.mods['U'].verify(base,overlay['marked_model'],overlay['control_model'],synthesis,[packet],provenance,
                         guard_point=GUARD,**ctx.limits['U'])
    costs['new_U3_admission_seconds']=time.perf_counter()-start
    save(ctx,'data/admit/overlay-admission.json.gz',u,refs,'overlay_receipt')
    ctx.mods['D'].gate(u,{'VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION'},'new_U3_warm_overlay_admission',refs)
    same(u['model_bindings'],dict(base=digest(base),marked=digest(overlay['marked_model']),
                                 control=digest(overlay['control_model'])),'NEW_U3_EXACT_MODEL_BINDINGS')
    start=time.perf_counter()
    controls=ctx.mods['D'].activation_controls(ctx,base,overlay,synthesis,packet,provenance)
    costs['new_activation_controls_seconds']=time.perf_counter()-start
    save(ctx,'data/admit/activation-controls.json',controls,refs,'activation_controls')
    need(controls['status']=='PASS_ACTUAL_QUERY_ACTIVATION_CONTROLS' and controls['applied']==len(controls['controls'])==5,'ALL_FIVE_REAL_PROVENANCE_CONTROLS_BEFORE_ACTIVATION')
    for key,model in (('base_model',base),('marked_model',overlay['marked_model']),('control_model',overlay['control_model'])):
        save(ctx,'data/admit/'+key.replace('_','-')+'.json.gz',model,refs,key)
    reused=dict(prepared=prior.project(results['prepare']['refs']['prepared']),
        synthesis=prior.project(results['learn']['refs']['synthesis']),overlay=prior.project(results['learn']['refs']['overlay']),
        packet=prior.project(results['label']['query_packets_ref']))
    return dict(status='OVERLAY_ADMITTED',refs=refs,reused_refs=reused,scope_sha256=digest(base),
        model_bindings=u['model_bindings'],preservation_status=u['status'],preservation_basis=u['preservation_basis'],
        prior_manifest=ref(ctx,MANIFEST),namespace='prior/v2',costs=costs,
        prior_phase_costs=authentication['phases'],comparison_metrics=u.get('comparison_metrics'),
        warm_reuse=True,new_failure_labels=0,new_synthesis_calls=0,old_target_proofs_used=0,
        scope='New U3 admission of exact authenticated V2 failure/candidate, not new failure discovery or marking learning. New activation follows public success and all five controls.')


def evaluate(ctx):
    admitted=ctx.read('data/admit/result.json')
    need(admitted['status']=='OVERLAY_ADMITTED','CURRENT_U3_ADMISSION_REQUIRED')
    prior=Prior(ctx)  # reauthenticate retained bytes before fresh searches
    prepared_ref=admitted['reused_refs']['prepared']
    need(prepared_ref['path'].startswith(PREFIX),'PREPARED_ORIGINAL_NAMESPACE')
    prepared=prior.readref(dict(prepared_ref,path=prepared_ref['path'][len(PREFIX):]))
    refs=admitted['refs'];models=[]
    for lane,key in (('BASE','base_model'),('MARKS','marked_model'),('FILTER','control_model')):
        record=refs[key];same(pin(path(ctx,record['path'])),{k:record[k] for k in ('bytes','sha256')},'ADMITTED_MODEL_FILE_BYTES')
        model=ctx.read(record['path']);binding_key={'BASE':'base','MARKS':'marked','FILTER':'control'}[lane]
        need(digest(model)==admitted['model_bindings'][binding_key],'ADMITTED_LANE_MODEL_SCOPE');models.append((lane,model))
    rows=[];summary_refs={};D=ctx.mods['D']
    for lane,model in models:
        same([r['id'] for r in model['inventory']['placements']],
             [r['id'] for r in models[0][1]['inventory']['placements']],'FULL_IDENTICAL_LANE_PALETTE')
        run,seconds=D.engine(ctx,'evaluate-'+lane.lower(),model)
        raw,c=run['raw'],run['semantic']
        record=dict(lane=lane,raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],refs=run['refs'],
            model_sha256=digest(model),stats=raw['stats'],costs=dict(engine_and_C_seconds=seconds),native_status='NOT_APPLICABLE',
            admitted_status='UNKNOWN',bounded_absence=False)
        if raw['status']=='SAT' and c['status']=='VERIFIED':
            need(c['run_status']=='SAT','POSITIVE_SEMANTIC_BINDING')
            try:decoded=D.decode(ctx,prepared,raw['selected'],'data/evaluate/'+lane.lower()+'-native')
            except D.StopPhase as error:
                record.update(native_status=error.status,native_reason=error.reason,native_refs=error.refs)
                if error.status=='REJECTED':record['admitted_status']='REJECTED_NATIVE_PROOF'
            else:
                record.update(native_status='VERIFIED',admitted_status='VERIFIED_NATIVE_POSITIVE',native_refs=decoded['refs'],native_proof_lines=len(decoded['proof']))
                record['costs'].update(decoded['costs'])
        elif raw['status']=='UNSAT' and c['status']=='VERIFIED':
            need(c['run_status']=='UNSAT' and c['bounded_absence'] is True and c['claim']=='SEMANTIC_COMPLETE_FINITE_EXHAUSTION','ONLY_COMPLETE_BOUNDED_EXHAUSTION')
            record.update(admitted_status='VERIFIED_BOUNDED_EXHAUSTION',bounded_absence=True)
        else:
            if c['status']=='REJECTED':record['admitted_status']='REJECTED_ASSURANCE'
            need(c.get('bounded_absence') is False,'UNKNOWN_OR_REJECTION_IS_NOT_ABSENCE')
        save(ctx,'data/evaluate/'+lane.lower()+'-summary.json.gz',record,summary_refs,lane);rows.append(record)
    return dict(status='EVALUATED',lanes=rows,refs=summary_refs,lane_order=[x[0] for x in models],
        complete_native_positives=sum(r['admitted_status']=='VERIFIED_NATIVE_POSITIVE' for r in rows),
        finite_exhaustions=sum(r['bounded_absence'] for r in rows),unresolved=sum(r['admitted_status']=='UNKNOWN' for r in rows),
        rejected_assurance=sum(r['admitted_status'].startswith('REJECTED') for r in rows),warm_reuse=True,
        scope='Fresh matched BASE/MARKS/FILTER searches under unchanged E/C limits, grammar, scheduler and primitive fallback. Prior preparation/failure/synthesis costs are explicitly warm and excluded from new-search timing; new authentication/U3/controls/assurance costs are separate. No cold speed, RL, universality or new-failure claim.')


def run(phase,ctx):
    need(phase in ('admit','evaluate'),'KNOWN_STREAMED_PHASE');started=time.perf_counter()
    try:result=admit(ctx) if phase=='admit' else evaluate(ctx)
    except ctx.mods['D'].StopPhase as error:
        result=dict(status=error.status,stopped_stage=error.stage,reason=error.reason,refs=error.refs,
                    scope='Unadmitted partial stage; no activation or retry follows.')
    result.update(schema='Streamed-arithmetic-'+phase+'-result-v1',version=VERSION,phase=phase,
                  module_seconds=time.perf_counter()-started)
    return result
