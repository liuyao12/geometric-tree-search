"""Passive streamed-run custody/data audit; no scientific helper imports or replay.

SOURCE ONLY until Root reviews this file and actual phases have ended.
PASS means exact saved evidence and explicit scopes, not research completion.
"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL='protocol/frozen-protocol-v1.json'
OUTPUT='review/passive-streamed-outcomes-v1.json'
PHASES=('qualify','admit','evaluate')
PREFIX='prior/v2/'
PROJECTION=('statement','proof','slots','slot_to_native','native_to_slot',
    'reference_mapping','proof_dag','selected','selected_sha256','original_statement_sha256','scope')
LEDGER={}
CHECKS=0
PROOFS=[]


def need(ok, why):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),
                       allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a,b,why):
    need(wire(a)==wire(b),why)


def local(name):
    need(type(name) is str and name and not Path(name).is_absolute()
         and '..' not in Path(name).parts,'LOCAL_REFERENCE')
    path=ROOT
    for part in Path(name).parts:
        path=path/part
        need(not path.is_symlink(),'NO_REFERENCE_SYMLINK')
    need(path.resolve().is_relative_to(ROOT),'REFERENCE_CONTAINMENT')
    return path


def filepin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def reference(name):
    value=dict(path=name,**filepin(local(name)))
    if name in LEDGER:
        same(value,LEDGER[name],'UNCHANGED_DURING_AUDIT:'+name)
    LEDGER[name]=value
    return value


def logical_pin(name):
    path=local(name);h=hashlib.sha256();size=0
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def exact(ref):
    actual=reference(ref['path'])
    need(type(ref['bytes']) is int and ref['bytes']>=0,'NATIVE_FILE_SIZE')
    same(actual,{k:ref[k] for k in actual},'PHYSICAL_REF:'+ref['path'])
    if 'complete_json' in ref:
        need(ref['complete_json'] is True,'COMPLETE_REFERENCED_JSON')
        need(logical_pin(ref['path'])['bytes']==ref['logical_json_bytes'],'LOGICAL_CAPTURE_SIZE')


def read(name,ref=None):
    reference(name)
    if ref is not None:
        exact(ref)
    path=local(name)
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        raw=stream.read(134217729)
    need(len(raw)<=134217728,'SAVED_JSON_READ_BOUND')
    return json.loads(raw)


def readref(ref):
    return read(ref['path'],ref)


def allrefs(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=set(value) and not value['path'].startswith('/'):
            exact(value)
        for v in value.values():allrefs(v)
    elif type(value) is list:
        for v in value:allrefs(v)


def normal(model):
    value=json.loads(wire(model));value['roots'].sort()
    for k in ('t','m'):value['seed'][k].sort()
    for row in value['inventory']['placements']:
        row['t'].sort();row['m'].sort()
    value['inventory']['placements'].sort(key=lambda r:r['id'])
    value['pair_nogoods'].sort();value['unary_nogoods'].sort()
    return value


def environment():
    p=read(PROTOCOL);need(p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():names.add(path.relative_to(ROOT).as_posix())
    for ref in admission['reviewed']:exact(ref);names.add(ref['path'])
    same([reference(n) for n in sorted(names)],p['files'],'EXACT_FROZEN_FILE_SET')
    for ref in (p['master'],p['runtime']['executable']):
        same(filepin(Path(ref['path'])),{k:ref[k] for k in ('bytes','sha256')},'CURRENT_MASTER_RUNTIME_BINARY')
    executable=Path(sys.executable).resolve()
    actual=dict(executable=dict(path=str(executable),**filepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    same(actual,p['runtime'],'PINNED_AUDIT_RUNTIME')
    return p,dict(file_count=len(names),exact_set=True,current_runtime=p['runtime'],current_master=p['master'])


def process(name,p):
    paths=dict(started='run/'+name+'/started.json',invocation='run/'+name+'/invocation.json',
        observer='run/'+name+'/observer.json',result='data/'+name+'/result.json')
    values={};parse_errors={}
    for key,path in paths.items():
        if local(path).exists():
            try:values[key]=read(path)
            except (ValueError,UnicodeError,EOFError) as error:
                need(key=='result','MALFORMED_PROCESS_RECEIPT')
                parse_errors[key]=type(error).__name__+':'+str(error)
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    clean=False
    if s is not None:
        need(s['phase']==name and type(s['pid']) is int and s['pid']>0,'STARTED_PHASE_PID')
        same(s['protocol'],reference(PROTOCOL),'STARTED_FROZEN_PROTOCOL')
    for v in (i,o):
        if v is not None:need(v['phase']==name,'ACTUAL_PHASE_ASSOCIATION')
    if s is not None and i is not None and o is not None:
        need(type(i['pid']) is int and type(o['pid']) is int and s['pid']==i['pid']==o['pid'],'ACTUAL_PID_ASSOCIATION')
        exact(o['log']);need(o['log']['path']=='run/'+name+'/stdout.log','OWNED_LOG_PATH')
        if i.get('result') is not None:
            exact(i['result']);need(i['result']['path']==paths['result'],'EXACT_RESULT_PATH')
            need(result is not None and i['scientific_status']==result['status'],'SCIENTIFIC_STATUS_ASSOCIATION')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None and i.get('result') is not None
            and result is not None and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==p['status'])
    if result is not None:allrefs(result)
    return dict(name=name,process_status='CLEAN_RECORDED_PHASE' if clean else
        ('NOT_RUN' if not values and not parse_errors else 'FAILED_OR_INCOMPLETE_PROCESS'),
        native_exit_code=None if o is None else o.get('native_exit_code'),scientific_status=None if result is None else result['status'],
        process_clean=clean,scientific_admitted=clean and result['status']==p['admitted_statuses'][name],
        pid=None if o is None else o.get('pid'),parse_errors=parse_errors,
        refs={k:reference(path) for k,path in paths.items() if local(path).exists()},
        costs=dict(worker_seconds=None if i is None else i.get('seconds'),observer_seconds=None if o is None else o.get('seconds'),
            worker_maxrss=None if i is None else i.get('maxrss'),worker_maxrss_units=None if i is None else i.get('maxrss_units'),
            sampled_peak_rss_bytes=None if o is None else o.get('peak_observed_rss_bytes'))),result


def raw_join(model,raw,c):
    normalized=normal(model);binding=sha(normalized)
    need(raw['model_sha256']==binding or raw['status']=='UNKNOWN' and raw['model_sha256'] is None,'RAW_MODEL_HASH')
    for endpoint in ('entry','final','restored'):
        value=raw[endpoint+'_state'];digest=raw['state_hashes'][endpoint]
        need(digest is None if value is None else sha(value)==digest,'ENDPOINT_BYTE_HASH')
    if raw['entry_state'] is not None:same(raw['entry_state'],raw['restored_state'],'EXACT_ENDPOINT_RESTORATION')
    total=raw['event_extent']['total'];retained=len(raw['events']);h=hashlib.sha256()
    need(raw['event_extent']['retained']==retained<=total,'EVENT_PREFIX_CENSUS')
    for j,e in enumerate(raw['events']):
        need(type(e['seq']) is int and e['seq']==j,'EVENT_SEQUENCE');h.update(wire(e))
    if retained==total:need(h.hexdigest()==raw['event_extent']['sha256'],'FULL_EVENT_STREAM_HASH')
    admitted='UNKNOWN'
    if c['status']=='VERIFIED':
        need(raw['status'] in ('SAT','UNSAT') and c['run_status']==raw['status'] and c['event_coverage']=='COMPLETE'
             and retained==total==c['counts']['decision_events_checked'],'COMPLETE_SEMANTIC_ASSOCIATION')
        need(c['model_sha256']==binding and c['event_sha256']==raw['event_extent']['sha256'],'C_SCOPE_HASHES')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'SCOPED_ABSENCE_BOOL')
        need(c['claim']==('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status']=='SAT'
             else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'),'EXACT_SEMANTIC_CLAIM')
        admitted='POINT_SAT' if raw['status']=='SAT' else 'BOUNDED_EXHAUSTION'
        if raw['status']=='SAT':
            selected=raw['selected'];need(selected==sorted(set(selected)),'EXACT_SELECTED_IDS')
            byid={r['id']:r for r in normalized['inventory']['placements']}
            same(raw['certificate']['placements'],[byid[x] for x in selected],'WHOLE_SELECTED_POINT_ROWS')
        else:need(raw['selected']==[] and raw['certificate'] is None,'NO_UNSAT_PROOF_CERTIFICATE')
    else:
        need(c['bounded_absence'] is False,'UNADMITTED_C_NEVER_ABSENCE')
        if c['status']=='REJECTED':admitted='REJECTED_ASSURANCE'
    if raw['status']=='UNKNOWN':
        need(raw['selected']==[] and raw['certificate'] is None and raw['final_state'] is None,'UNKNOWN_NO_COMMITTED_CERTIFICATE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c.get('reason'),point_admission=admitted,bounded_absence=c['bounded_absence'],
        model_sha256=binding,event_payload_coverage='COMPLETE_EMITTED_PAYLOAD' if retained==total else 'RETAINED_PREFIX',
        semantic_certificate_scope=c.get('claim') if c['status']=='VERIFIED' else 'NO_COMPLETE_PROOF_OR_REFUTATION',
        events_retained=retained,events_emitted=total,stats=raw['stats'],
        scope='Saved semantic receipt and full endpoint/event byte association, not a new replay or observed intermediate producer graph.')


def engine(refs):
    model=readref(refs['model']);raw=readref(refs['raw']);c=readref(refs['semantic'])
    answer=raw_join(model,raw,c);answer['refs']=refs
    return answer,raw


def native_projection(refs,statement,selected,identifier,role):
    mk='adapter_decoded' if 'adapter_decoded' in refs else 'decoded'
    nk='independent_decoded';bk='native_receipt' if 'native_receipt' in refs else 'native'
    m=readref(refs[mk]);n=readref(refs[nk]);b=readref(refs[bk])
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE','BOTH_NATIVE_DECODERS')
    for key in PROJECTION:same(m[key],n[key],'TWO_DECODER_CONTENT:'+key)
    same(m['statement'],statement,'ORIGINAL_NATIVE_STATEMENT');same(m['selected'],sorted(selected),'ACTUAL_SELECTED_PROJECTION')
    need(m['selected_sha256']==sha(sorted(selected)) and m['original_statement_sha256']==sha(statement),'NATIVE_BINDING_HASHES')
    need(b['status']=='VERIFIED' and type(b['checked_lines']) is int and b['checked_lines']==len(m['proof']),'COMPLETE_NATIVE_RECEIPT')
    need(m['proof'] and m['proof'][-1]['formula']==statement['goal'],'UNCHANGED_PROOF_GOAL')
    if 'native_proof' in refs:same(readref(refs['native_proof']),m['proof'],'SAVED_WHOLE_PROOF_BYTES')
    if 'projection' in refs:
        projection=readref(refs['projection'])
        need(projection['adapter_decoded_sha256']==sha(m) and projection['independent_decoded_sha256']==sha(n),'PROJECTION_RECEIPT_CONTENT')
    record=dict(id=identifier,role=role,lines=len(m['proof']),statement_sha256=sha(statement),
        selected_sha256=sha(sorted(selected)),proof_sha256=sha(m['proof']),
        proof_ref=refs['native_proof'] if 'native_proof' in refs else dict(refs[mk],pointer='/proof'),
        native_ref=refs[bk],decoder_refs={mk:refs[mk],nk:refs[nk]},
        rules=dict(Counter(line['rule'] for line in m['proof'])),refs=refs,
        scope='Native receipt/context and exact stored decoder/proof joins only; no native kernel rerun.')
    PROOFS.append(record)
    return record


def prior_ref(original,entries):
    name=original['path']
    need(type(name) is str and not name.startswith('/') and name in entries,'PRIOR_REFERENCE_NAMESPACE')
    same({k:original[k] for k in ('bytes','sha256')},{k:entries[name][k] for k in ('bytes','sha256')},'PRIOR_ORIGINAL_REF_BYTES')
    projected=dict(original,path=PREFIX+name);exact(projected);return projected


def project_refs(value,entries):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=set(value):return prior_ref(value,entries)
        return {k:project_refs(v,entries) for k,v in value.items()}
    if type(value) is list:return [project_refs(v,entries) for v in value]
    return value


def original_graph_receipts(row,entries):
    refs=project_refs(row['refs'],entries);info,raw=engine(refs)
    observations=readref(refs['observations']);trace=readref(refs['full_graphs']);paired=readref(refs['paired_graphs'])
    need(info['point_admission'] in ('POINT_SAT','BOUNDED_EXHAUSTION')
         and trace['status']==paired['status']=='VERIFIED','ORIGINAL_COMPLETE_TINY_ASSURANCE')
    need(len(observations)==len(raw['events'])==trace['counts']['observations_checked']
         ==paired['events_checked']==len(paired['comparisons'])==row['actual_snapshots'],'ALL_ORIGINAL_OBSERVATIONS_BOUND')
    need(trace['model_sha256']==info['model_sha256'] and trace['run_status']==raw['status'],'ORIGINAL_T_MODEL_RESULT')
    for observation,event,comparison in zip(observations,raw['events'],paired['comparisons']):
        same(observation['event'],event,'SAVED_ACTUAL_EVENT_ORDER')
        need(comparison['equal'] is True and comparison['seq']==event['seq']
             and comparison['kind']==event['kind'] and comparison['actual_sha256']
             ==comparison['reconstructed_sha256']==sha(observation['state']),'SAVED_C_TO_ACTUAL_MAP_ASSOCIATION')
    oracle=readref(project_refs(row.get('oracle',row['refs'].get('oracle')),entries))
    need(oracle['status']=='EXHAUSTED' and oracle['subsets_coverage']=='COMPLETE'
         and oracle['model_sha256']==info['model_sha256'] and oracle['exists'] is (raw['status']=='SAT'),
         'ORIGINAL_TINY_SUBSET_ENUMERATION_ASSOCIATION')
    need(row['raw_status']==raw['status'] and row['semantic_status']==row['full_graph_status']
         ==row['paired_graph_status']=='VERIFIED' and row['engine_calls']==1,'ORIGINAL_ROW_STATUS_CENSUS')
    return len(observations)


def prior_evidence(current_protocol):
    manifest=read('input/prior-evidence-v1.json')
    need(manifest['schema']=='Streamed-arithmetic-prior-evidence-v1' and manifest['namespace']=='prior/v2'
         and type(manifest['target_proofs']) is int and manifest['target_proofs']==0,'EXPLICIT_WARM_NAMESPACE_NO_TARGET_PROOF')
    entries={r['path']:r for r in manifest['files']}
    need(len(entries)==len(manifest['files'])==388,'FULL_388_MEMBER_PRIOR_MANIFEST')
    for entry in manifest['files']:exact(dict(entry,path=PREFIX+entry['path']))
    actual={p.relative_to(ROOT/'prior/v2').as_posix() for p in (ROOT/'prior/v2').rglob('*') if p.is_file()}
    need(actual==set(entries),'EXACT_PRIOR_PHYSICAL_FILE_SET')
    old=read(PREFIX+PROTOCOL);need(sha(old)==manifest['protocol_sha256'],'OLD_PROTOCOL_HASH')
    same(old['runtime'],current_protocol['runtime'],'SAME_CURRENT_AND_PRIOR_RUNTIME')
    same(old['master'],current_protocol['master'],'SAME_CURRENT_AND_PRIOR_MASTER')
    original_admission=read(PREFIX+'review/root-source-admission-v1.json')
    need(original_admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','OLD_SOURCE_ADMISSION')
    names={n for n in entries if n.split('/')[0] in ('source','reference','input','plan')}
    names.add('review/root-source-admission-v1.json')
    for r in original_admission['reviewed']:prior_ref(r,entries);names.add(r['path'])
    same([dict(path=n,bytes=entries[n]['bytes'],sha256=entries[n]['sha256']) for n in sorted(names)],old['files'],'OLD_EXACT_FROZEN_SET')
    expected=dict(qualify='QUALIFIED',prepare='PREPARED',acquire='ACQUIRED_PROPOSAL',label='LABELLED',learn='UNKNOWN')
    phases=[];results={}
    for name,status in expected.items():
        s,i,o=[read(PREFIX+'run/'+name+'/'+k+'.json') for k in ('started','invocation','observer')]
        result=read(PREFIX+'data/'+name+'/result.json')
        need(s['phase']==i['phase']==o['phase']==name and type(s['pid']) is int
             and s['pid']==i['pid']==o['pid'],'PRIOR_REAL_PHASE_PID')
        need(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
             and i['status']=='COMPLETE' and i['error_type'] is None,'PRIOR_REAL_NATIVE_ZERO')
        need(all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
             and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==old['status'],'PRIOR_SOURCE_GUARDS')
        need(i['result']['path']=='data/'+name+'/result.json' and i['result']['complete_json'] is True
             and o['log']['path']=='run/'+name+'/stdout.log','PRIOR_EXACT_RESULT_LOG_PATHS')
        prior_ref(i['result'],entries);prior_ref(o['log'],entries)
        same(s['protocol'],dict(path=PROTOCOL,bytes=entries[PROTOCOL]['bytes'],sha256=entries[PROTOCOL]['sha256']),'PRIOR_STARTED_PROTOCOL')
        need(result['status']==i['scientific_status']==status,'PRIOR_SCIENCE_STATUS_NOT_PROMOTED')
        project_refs(result,entries);results[name]=result
        phases.append(dict(name=name,pid=o['pid'],native_exit_code=0,scientific_status=status,
            scientific_admitted=name!='learn',process_clean=True,
            refs=dict(started=reference(PREFIX+'run/'+name+'/started.json'),
                invocation=reference(PREFIX+'run/'+name+'/invocation.json'),
                observer=reference(PREFIX+'run/'+name+'/observer.json'),
                result=prior_ref(i['result'],entries),log=prior_ref(o['log'],entries)),
            worker_seconds=i['seconds'],observer_seconds=o['seconds']))
    need(not any(n.startswith(('data/evaluate/','run/evaluate/','data/label/fixed-union-native/')) for n in entries),'NO_PRIOR_TARGET_PROOF_OR_EVALUATION')
    q=results['qualify'];need(q['status']=='QUALIFIED' and len(q['cases'])==20 and len(q['logical'])==2
        and q['counts']['actual_tiny_snapshots']+q['counts']['actual_logical_snapshots']==176,'REUSED_PRIOR_ENGINE_QUALIFICATION_SCOPE')
    declarations=read(PREFIX+'input/qualification-cases-v1.json')['cases']
    need([c['id'] for c in q['cases']]==[c['id'] for c in declarations],'ALL_TWENTY_ORIGINAL_CASE_DECLARATIONS')
    graphs=sum(original_graph_receipts(row,entries) for row in q['cases'])
    controls=Counter()
    need(len(q['controls'])==9,'ALL_NINE_ORIGINAL_ENGINE_CONTROLS')
    for row in q['controls']:
        if row['id']=='max-nodes-zero':
            info,raw=engine(project_refs(row['refs'],entries));need(info['point_admission']=='UNKNOWN'
                and raw['status']=='UNKNOWN','ORIGINAL_ZERO_NODE_RESOURCE_REFUSAL');controls['UNKNOWN']+=1
        else:
            receipt=readref(project_refs(row['receipt'],entries));need(receipt['status']=='REJECTED','ORIGINAL_INVALID_INPUT_REFUSAL')
            controls['REJECTED']+=1
    for case in q['logical']:
        graphs+=original_graph_receipts(dict(case['engine'],refs=case['engine']['refs'],oracle=case['refs']['oracle']),entries)
        refs=project_refs(case['refs'],entries);engine_refs=project_refs(case['engine']['refs'],entries)
        p=readref(refs['prepared']);model=readref(engine_refs['model']);raw=readref(engine_refs['raw']);c=readref(engine_refs['semantic'])
        need(raw_join(model,raw,c)['point_admission']=='POINT_SAT','REUSED_QUALIFIER_POSITIVE_SOURCE')
        native_projection(refs,p['statement'],raw['selected'],'prior-qual-'+case['id'],'REUSED_PRIOR_QUALIFICATION')
    need(graphs==176,'ALL_176_ORIGINAL_ACTUAL_MAP_ASSOCIATIONS')
    prepare=results['prepare'];r=project_refs(prepare['refs'],entries)
    p=readref(r['prepared']);model=readref(r['model']);n=readref(r['model_receipt']);rf=readref(r['rf_receipt'])
    comp=readref(r['compiled']);gen=readref(r['generation']);bridge=readref(r['bridge']);bcheck=readref(r['bridge_receipt'])
    need(n['status']==rf['status']==bcheck['status']=='VERIFIED','OLD_PROFILE_AND_COMPLETE_MODEL_ADMISSION')
    need(rf['compiled_core_sha256']==gen['compiled_core_sha256']==sha({k:v for k,v in comp.items() if k not in ('costs','scope')}),'OLD_FULL_RF_CORE')
    same(n['census'],p['census'],'REUSED_FULL_CENSUS');same(p['binding'],prepare['prepared_binding'],'REUSED_PREPARED_BINDING')
    need(len(p['universe'])==49736 and p['census']['formulas']==488 and p['census']['zero_definitions']==245
         and p['census']['mp_definitions']==426 and p['census']['gen_definitions']==2,'REUSED_FULL_FORMULA_CID_PALETTE')
    need(n['model_sha256']==sha(p['model']) and n['universe_sha256']==sha(p['universe'])
         and n['catalogue_sha256']==sha(p['catalogue'])==bridge['bindings']['catalogue_sha256'],'REUSED_FULL_MODEL_UNIVERSE_HASHES')
    same(bcheck['bindings'],bridge['bindings'],'OLD_BRIDGE_CHECK_BINDINGS')
    same(comp['logical_basis']['formulas'],p['catalogue']['formulas'],'ALL_ORIGINAL_FORMULAS')
    zeros=readref(r['zero_native_receipts']);need(len(zeros)==len(comp['zero_instances'])==245,'ALL_PRIOR_ZERO_RECORDS')
    for z,receipt in zip(comp['zero_instances'],zeros):
        need(z['id']==receipt['id'] and z['formula_id']==receipt['formula_id'] and sha(z['line'])==receipt['native_line_sha256']
             and receipt['receipt']['status']=='VERIFIED' and receipt['receipt']['checked_lines']==1,'OLD_NATIVE_ZERO_PAYLOAD_JOIN')
    for key in ('capacity','roots','seed','inventory'):same(model[key],p['model'][key],'REUSED_LITERAL_MIGRATION:'+key)
    need(sha(model)==prepare['scope_sha256'],'REUSED_BASE_SCOPE')
    old_refusal=readref(project_refs(results['learn']['refs']['overlay_receipt'],entries))
    need(old_refusal['status']=='UNKNOWN' and old_refusal.get('activation_admitted') is False,'OLD_U2_REFUSAL_PRESERVED')
    return dict(manifest=reference('input/prior-evidence-v1.json'),namespace='prior/v2',physical_files=388,
        protocol=reference(PREFIX+PROTOCOL),phases=phases,reused_actual_graphs=graphs,
        reused_qualification=dict(tiny_cases=20,logical_cases=2,engine_controls=dict(controls)),
        reused_qualification_only=True,old_target_proofs_used=0,old_overlay_refusal=old_refusal,
        census=p['census'],all_prior_native_ZERO=245,cost_scope='Historical warm inputs; these are not new compilation, labels or synthesis.'),dict(
        entries=entries,protocol=old,results=results,prepared_ref=r['prepared'],base=model,
        statement=p['statement'],catalogue=p['catalogue'],binding=p['binding'])


def qualification(result):
    spec=read('input/streamed-hash-qualification-v1.json');eqspec=read('input/overlay-equality-qualification-v1.json')
    equality=readref(result['equality_qualification'])
    need(equality['status']=='QUALIFIED_CANONICAL_EQUALITY_PRIMITIVE' and len(equality['cases'])==28
         and len(equality['refusals'])==8,'CURRENT_EQUALITY_QUALIFICATION')
    for declared,row in zip(eqspec['valid_pairs']+eqspec['recipes'],equality['cases']):
        saved=readref(row['receipt']);same(saved['declaration'],declared,'EQUALITY_DECLARATION')
        a=saved['reference']['left_wire'].encode('ascii');b=saved['reference']['right_wire'].encode('ascii')
        need(hashlib.sha256(a).hexdigest()==saved['reference']['left_sha256']
             and hashlib.sha256(b).hexdigest()==saved['reference']['right_sha256'],'SAVED_REFERENCE_WIRE_DIGESTS')
        need(saved['reference']['relation'] is (a==b),'SAVED_CANONICAL_RELATION')
        actual=saved['actual'];need(actual['status']=='ACCEPTED_EQUAL' if a==b else
            actual['status']=='REJECTED' and actual['reason']=='DIFFERENTIAL_MISMATCH:'+declared['id'],'PRIVATE_EQUALITY_RESULT')
    equal_refusals=Counter()
    for declared,row in zip(eqspec['refusals'],equality['refusals']):
        saved=readref(row['receipt']);same(saved['declaration'],declared,'EQUALITY_REFUSAL_DECLARATION')
        actual=saved['actual'];need(actual['status'] in ('REJECTED','UNKNOWN') if declared['expected']=='NO_ACCEPTANCE'
            else actual['status']==declared['expected'],'EQUALITY_REFUSAL')
        equal_refusals[actual['status']]+=1
    pairs=eqspec['valid_pairs']+eqspec['recipes']
    expected_ids=[r['id']+'-'+side for r in pairs for side in ('left','right')]
    expected_ids+=['byte-%03d'%i for i in range(256)]
    expected_ids+=['boundary-%06X'%i for i in spec['boundary_codepoints']]
    expected_ids+=[r['id'] for r in spec['string_sequences']]+[r['id'] for r in spec['native_scalars']]
    need([r['id'] for r in result['hash_cases']]==expected_ids and len(expected_ids)==361,'ALL_361_DECLARED_HASHES')
    for row in result['hash_cases']:
        saved=readref(row['receipt']);raw=saved['reference_wire'].encode('ascii');expected=hashlib.sha256(raw).hexdigest()
        need(saved['reference_bytes']==len(raw) and saved['reference_sha256']==expected
             ==saved['actual']['digest']==row['reference_sha256'] and saved['actual']['status']=='HASHED','EXACT_SAVED_CANONICAL_SHA')
    expected_controls=[r['id'] for r in spec['hash_refusals']]+[spec['oversized_scalar_refusal']['id']]
    need([r['id'] for r in result['hash_controls']]==expected_controls and len(expected_controls)==9,'ALL_NINE_HASH_REFUSALS')
    hash_refusals=Counter();refusal_declarations={r['id']:r for r in eqspec['refusals']}
    control_declarations={r['id']:r for r in spec['hash_refusals']}
    for row in result['hash_controls']:
        saved=readref(row['receipt']);actual=saved['actual']
        need(actual['digest'] is None and actual['status'] in ('REJECTED','UNKNOWN'),'NO_HASH_FROM_REFUSAL')
        if row['id']==spec['oversized_scalar_refusal']['id']:
            same(saved['declaration'],spec['oversized_scalar_refusal'],'EXACT_OVERSIZE_DECLARATION')
            need(actual['status']=='UNKNOWN' and actual['reason']=='CHECKER_SCALAR_BUFFER_BYTES','SCALAR_BUFFER_REFUSAL')
            for key in ('stream_scalar_allocation_units','stream_scalar_fragments','stream_fragments','hashed_bytes'):
                need(type(actual['metrics'][key]) is int and actual['metrics'][key]==0,'REFUSE_BEFORE_SCALAR_ENCODING_OR_HASH')
        else:
            control=control_declarations[row['id']];declaration=refusal_declarations[control['source_id']]
            same(saved['declaration'],declaration,'HASH_REFUSAL_DECLARATION');need(saved['operand']==control['operand'],'HASH_REFUSAL_OPERAND')
            need(actual['status'] in ('REJECTED','UNKNOWN') if declaration['expected']=='NO_ACCEPTANCE'
                 else actual['status']==declaration['expected'],'HASH_REFUSAL_EXPECTATION')
        need(saved['id']==row['id'] and row['status']==actual['status'] and row['reason']==actual['reason'],'HASH_REFUSAL_RESULT_ASSOCIATION')
        hash_refusals[actual['status']]+=1
    need(result['counts']['successful_hash_calls']==361 and result['counts']['hash_refusal_calls']==9,'HASH_CENSUS_FIELDS')
    return dict(status='AUDITED_CURRENT_PRIVATE_HASH_QUALIFICATION',successful_hashes=361,hash_refusals=dict(hash_refusals),
        equality_valid=28,equality_refusals=dict(equal_refusals),new_engine_calls=0,new_actual_graph_observations=0,
        scope='Saved independent canonical-reference bytes and private U3 outputs only; no qualifier reexecution or new engine qualification.')


def admitted_overlay(result,record,context,current_protocol):
    refs=dict(result.get('refs',{})) if result is not None else {}
    fallback={'prior_authentication':'data/admit/prior-authentication.json','overlay_receipt':'data/admit/overlay-admission.json.gz',
              'original_provenance':'data/admit/original-v2-provenance.json.gz','activation_controls':'data/admit/activation-controls.json'}
    for key,name in fallback.items():
        if key not in refs and local(name).exists():refs[key]=reference(name)
    answer=dict(status='NOT_RUN' if result is None else result['status'],activation_admitted=False,refs=refs,controls=[])
    if result is not None:
        answer.update(costs=result.get('costs'),module_seconds=result.get('module_seconds'),
            prior_phase_costs=result.get('prior_phase_costs'),preservation_basis=result.get('preservation_basis'))
    if 'prior_authentication' in refs:
        auth=readref(refs['prior_authentication']);need(auth['status']=='AUTHENTICATED_PRIOR_V2_WARM_INPUT'
            and auth['physical_files']==388 and auth['namespace']=='prior/v2','CURRENT_AUTHENTICATION_SCOPE')
        same(auth['current_protocol'],reference(PROTOCOL),'CURRENT_AUTH_EXECUTION_PROTOCOL')
        same(auth['prior_protocol'],reference(PREFIX+PROTOCOL),'GENUINE_OLD_LABEL_PROTOCOL')
        need(auth['runtime_reuse']=='IDENTICAL_FLAGS_VERSION_AND_BINARY' and len(auth['reused_modules'])==14,'ALL_REUSED_ROLES')
        expected=set('E C M N B D J F R A Q L T O'.split())
        need({r['role'] for r in auth['reused_modules']}==expected,'EXACT_REUSED_ROLE_SET')
        for row in auth['reused_modules']:
            exact(row['current_source']);exact(row['qualified_prior_source'])
            same({k:row['current_source'][k] for k in ('bytes','sha256')},
                 {k:row['qualified_prior_source'][k] for k in ('bytes','sha256')},'FRESH_REUSED_SOURCE_IS_QUALIFIED_BYTES')
    if 'overlay_receipt' not in refs:return answer
    u=readref(refs['overlay_receipt']);answer.update(overlay_admission_status=u['status'],overlay_receipt=refs['overlay_receipt'],
        reason=u.get('reason'),work=u.get('work'),checker_seconds=u.get('seconds'),comparison_metrics=u.get('comparison_metrics'))
    entries=context['entries'];old=context['results'];base=context['base']
    synth=readref(project_refs(old['learn']['refs']['synthesis'],entries))
    overlay=readref(project_refs(old['learn']['refs']['overlay'],entries))
    packet=readref(project_refs(old['label']['query_packets_ref'],entries))
    prior_prov=readref(project_refs(old['learn']['refs']['provenance'],entries))
    if 'original_provenance' in refs:same(readref(refs['original_provenance']),prior_prov,'UNCHANGED_GENUINE_ORIGINAL_PROVENANCE')
    same(prior_prov['label_phase']['result'],old['label'],'NO_FABRICATED_CURRENT_LABEL')
    same(prior_prov['protocol']['value'],context['protocol'],'OLD_INLINE_PROTOCOL_UNCHANGED')
    binding=packet['binding'];raw=packet['raw_result'];c=packet['semantic_receipt']
    need(packet['label']=='NEGATIVE' and raw_join(packet['fixed_model'],raw,c)['point_admission']=='BOUNDED_EXHAUSTION','RETAINED_SCOPED_FINITE_NEGATIVE')
    need(sha(raw)==binding['raw_result_sha256']==logical_pin(project_refs(binding['evidence_refs']['raw'],entries)['path'])['sha256']
         and sha(c)==binding['semantic_receipt_sha256'] and sha(packet['fixed_model'])==binding['fixed_model_sha256'],'OLD_PACKET_HASH_AND_ACTUAL_RAW_FILE')
    for key,field in (('semantic','semantic_receipt_sha256'),('model','fixed_model_sha256')):
        need(binding[field]==logical_pin(project_refs(binding['evidence_refs'][key],entries)['path'])['sha256'],'OLD_PACKET_TO_ORIGINAL_SAVED_'+key)
    same(synth['labels'],old['label']['labels'],'NO_NEW_LABEL_OR_SYNTHESIS')
    guard=synth['guard_point'];forbidden=set(synth['forbidden_cids']);marked=overlay['marked_model'];control=overlay['control_model']
    need(len(base['inventory']['placements'])==len(marked['inventory']['placements'])==len(control['inventory']['placements'])==49736,'ALL_ORIGINAL_ROWS_RETAINED')
    points=set(base['roots'])
    for key in ('t','m'):points.update(p for p,v in base['seed'][key])
    for original,m,f in zip(base['inventory']['placements'],marked['inventory']['placements'],control['inventory']['placements']):
        points.update(p for p,v in original['t']+original['m']);same(original,f,'CONTROL_OLD_T_M')
        same(m,dict(original,m=sorted(original['m']+([[guard,'1']] if original['id'] in forbidden else []))),'EXACT_SPARSE_MARK_ONLY_LAYER')
    need(guard not in points,'FRESH_EXTRA_GUARD_SUPPORT')
    for key in ('schema','capacity','roots'):
        same(base[key],marked[key],'MARKED_FIXED_MODEL_FIELD:'+key);same(base[key],control[key],'CONTROL_FIXED_MODEL_FIELD:'+key)
    need(marked['version']==base['version']+':certified-unary-overlay-v1'
         and control['version']==base['version']+':ordinary-unary-filter-v1','DECLARED_OVERLAY_VERSION_SUFFIXES')
    same(marked['seed'],dict(t=base['seed']['t'],m=sorted(base['seed']['m']+([[guard,'0']] if forbidden else []))),'PRESERVED_OLD_SEED_MARKINGS')
    same(control['seed'],base['seed'],'CONTROL_OLD_SEED')
    need(control['unary_nogoods']==sorted(forbidden) and control['pair_nogoods']==marked['pair_nogoods']==marked['unary_nogoods']==[],'MATCHED_LITERAL_AND_ORDINARY_FILTER')
    expected_bindings=dict(base=sha(normal(base)),marked=sha(normal(marked)),control=sha(normal(control)))
    if u['status']=='VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION':
        same(u['model_bindings'],expected_bindings,'NEW_U3_EXACT_BOUND_MODELS')
        need(u['work']<=current_protocol['limits']['scientific']['overlay']['max_work'],'U3_WITHIN_UNCHANGED_WORK_CAP')
        same(u['custody']['protocol_ref'],{k:context['entries'][PROTOCOL][k] for k in ('path','bytes','sha256')},'U3_CUSTODY_IS_GENUINE_OLD_PROTOCOL')
        need(u['custody']['pid']==prior_prov['label_phase']['observer']['pid'],'U3_OLD_LABEL_PID')
    else:need(not record['scientific_admitted'],'U3_REFUSAL_CANNOT_ACTIVATE')
    if 'activation_controls' in refs:
        controls=readref(refs['activation_controls']);specs=read('input/overlay-equality-qualification-v1.json')['public_after_label_mutants']
        need(controls['status']=='PASS_ACTUAL_QUERY_ACTIVATION_CONTROLS' and controls['applied']==len(controls['controls'])==5,'ALL_FIVE_CURRENT_CONTROLS')
        for spec,row in zip(specs,controls['controls']):
            need(spec['id']==row['id'],'DECLARED_MUTANT_ID');receipt=readref(row['receipt']);inputs=readref(row['input'])
            need(receipt['status']==spec['expected'] and receipt['reason']==spec['expected_reason']
                 and receipt.get('activation_admitted') is False,'ONLY_REJECTED_OR_UNKNOWN_MUTANTS')
            same(inputs['provenance'],prior_prov,'MUTANTS_KEEP_AUTHENTIC_OLD_PROVENANCE')
            answer['controls'].append(dict(id=row['id'],status=receipt['status'],reason=receipt['reason'],refs=dict(input=row['input'],receipt=row['receipt'])))
    if record['scientific_admitted']:
        need(result['status']=='OVERLAY_ADMITTED' and u['status']=='VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION'
             and len(answer['controls'])==5,'ALL_GATES_BEFORE_CURRENT_ACTIVATION')
        for key,value in (('base_model',base),('marked_model',marked),('control_model',control)):
            same(readref(refs[key]),value,'CURRENT_ADMITTED_MODEL_FILE:'+key)
        need(result['warm_reuse'] is True and result['new_failure_labels']==result['new_synthesis_calls']==result['old_target_proofs_used']==0,'NO_NEW_DISCOVERY_OR_OLD_TARGET_WITNESS')
        answer.update(activation_admitted=True,model_bindings=expected_bindings)
    answer.update(forbidden_cids=sorted(forbidden),full_inventory=49736,warm_reuse=True,new_failure_labels=0,new_synthesis_calls=0,
        scope='New U3 execution on genuine authenticated old V2 evidence; old LABEL and current admission remain separate namespaces.')
    return answer


def evaluation(result,admission,context):
    need(admission['activation_admitted'] is True,'NO_FRESH_EVALUATION_BEFORE_ADMISSION');rows=[]
    for item in result['lanes']:
        info,raw=engine(item['refs']);lane=item['lane'];key={'BASE':'base','MARKS':'marked','FILTER':'control'}[lane]
        need(info['model_sha256']==item['model_sha256']==admission['model_bindings'][key],'EXACT_FRESH_LANE_CONTEXT')
        need(item['raw_status']==info['raw_status'] and item['semantic_status']==info['semantic_status'],'LANE_STATUS_ASSOCIATION')
        if item['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
            need(info['point_admission']=='POINT_SAT','NATIVE_PROOF_REQUIRES_COMPLETE_POINT_SAT')
            for ref in item['native_refs'].values():need(not ref['path'].startswith(PREFIX),'FRESH_NATIVE_EVIDENCE_NOT_REUSED_PROOF')
            native_projection(item['native_refs'],context['statement'],raw['selected'],'arith-'+lane,'EVALUATION')
        elif item['admitted_status']=='VERIFIED_BOUNDED_EXHAUSTION':
            need(info['point_admission']=='BOUNDED_EXHAUSTION' and item['bounded_absence'] is True,'ONLY_SCOPED_FINITE_EXHAUSTION')
        else:need(item['bounded_absence'] is False,'UNKNOWN_OR_REJECTED_LANE_NEVER_ABSENCE')
        rows.append(dict(lane=lane,**info,admitted_status=item['admitted_status'],native_status=item['native_status'],
            native_refs=item.get('native_refs'),costs=item['costs']))
    need([r['lane'] for r in rows]==result['lane_order']==['BASE','MARKS','FILTER'],'ALL_THREE_FRESH_MATCHED_LANES')
    return dict(status=result['status'],lanes=rows,warm_reuse=True,new_failure_labels=0,new_synthesis_calls=0,
        scope='Fresh E/C attempts and fresh original M/N/B positive proof gates. Complete emitted payload is not a complete search certificate when raw/C is UNKNOWN.')


def main():
    protocol,frozen=environment();need(protocol['schema']=='Streamed-arithmetic-protocol-v1','CURRENT_PROTOCOL_SCHEMA')
    prior,context=prior_evidence(protocol);phases=[];results={}
    for name in PHASES:
        record,result=process(name,protocol);phases.append(record);results[name]=result
    admitted={r['name']:r['scientific_admitted'] for r in phases}
    qual=dict(status='NOT_RUN_OR_NOT_ADMITTED',new_engine_calls=0)
    if admitted['qualify']:qual=qualification(results['qualify'])
    admission=admitted_overlay(results['admit'],next(r for r in phases if r['name']=='admit'),context,protocol)
    evaluated=dict(status='NOT_RUN_OR_NOT_ADMITTED',lanes=[])
    if admitted['evaluate']:evaluated=evaluation(results['evaluate'],admission,context)
    physical=[]
    for folder in ('data','run','prior/v2'):
        if (ROOT/folder).exists():
            for p in sorted((ROOT/folder).rglob('*')):
                if p.is_file():physical.append(dict(path=p.relative_to(ROOT).as_posix(),**filepin(p)))
    for r in list(LEDGER.values()):same(filepin(local(r['path'])),{k:r[k] for k in ('bytes','sha256')},'FINAL_ALL_REFERENCED_BYTES_UNCHANGED')
    output=dict(schema='Streamed-arithmetic-passive-audit-v1',status='PASS_SAVED_STREAMED_OUTCOMES_WITH_EXPLICIT_SCOPES',
        check_count=CHECKS,protocol=reference(PROTOCOL),frozen=frozen,prior=prior,phases=phases,qualification=qual,
        admission=admission,evaluation=evaluated,native_proofs=PROOFS,
        reused_qualification_native_proof_outputs=sum(r['role']=='REUSED_PRIOR_QUALIFICATION' for r in PROOFS),
        fresh_arithmetic_native_proof_outputs=sum(r['role']=='EVALUATION' for r in PROOFS),
        physical_files=physical,artifact_pins=[LEDGER[k] for k in sorted(LEDGER)],
        scope='Passive saved-file/process/hash/census/native-projection associations only. No compiler, model, labeler, learner, engine, checker, qualification recipe or native helper imported or replayed. Prior qualification and labels are warm historical evidence; only current evaluation may supply fresh target proofs. PASS is evidence-scope consistency, not goal completion, cold speed, RL advantage or a uniform universal Wang palette. Archive CRC/publication remains a separate gate.')
    with local(OUTPUT).open('xb') as stream:stream.write(wire(output))
    print(json.dumps(dict(status=output['status'],checks=CHECKS,receipt=reference(OUTPUT),
        phases=[dict(name=r['name'],status=r['scientific_status'],admitted=r['scientific_admitted']) for r in phases])))


if __name__=='__main__':
    main()


