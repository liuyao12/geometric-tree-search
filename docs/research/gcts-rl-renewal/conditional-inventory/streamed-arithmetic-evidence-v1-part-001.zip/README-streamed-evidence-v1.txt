Streamed arithmetic certificate admission and fresh bounded searches.

Download EVERY streamed-arithmetic-evidence-v1-part-NNN.zip together with
streamed-arithmetic-evidence-manifest-v1.json and extract into one directory.
Every independent volume is at most 44 MiB and contains the same complete
ARCHIVE-file-manifest-v1.json. Every original current-run path present at the
cut is physically stored once, including the 388 prior/v2 originals. Equal
bytes at distinct paths are stored separately; no alias table or remote file
substitutes for original current bytes. All member sizes/SHA256, CRCs, exact
path sets and physical volume hashes are verified before commit preparation.

All Source/input/reference/plan/review files, actual raw events/endpoints,
UNKNOWN/refusal outcomes, genuine native qualification receipts, logs, current
report data, publication tools/planning, local paths, original renderer snapshot
and changed predecessor-reader backlink asset are included. Only generated
package/ outputs are excluded from their own input cut. Index/commit/push/Pages/
live receipts created after the cut are later custody files, not claimed inside
their own prior archive. Prior/v2 is a complete physical copied evidence set;
its original relative references still resolve under that namespace. Other
predecessor archives remain separately linked, not silently counted as current
physical members. Full current evidence and local paths/logs are user-approved
for this existing public destination; no new audience is created.

Serve the extracted directory and open report/streamed-arithmetic-v1.html.
The current passive audit/process receipts distinguish new qualification,
admission and evaluation from historical preparation/failure/synthesis. Only
exactly native-admitted records may appear as proofs, with explicit roles;
prior qualification proofs are not arithmetic target proofs. UNKNOWN prefixes,
complete emitted payloads and bounded exhaustion are separate scopes. Read
actual statuses, not a workflow word such as EVALUATED as proof success.

This run uses warm prior/v2 model/failure/candidate evidence and a separately
qualified streamed SHA implementation, preserving old canonical bytes and all
validation gates. It claims no new failure label or synthesis discovery. The
actual three fresh arithmetic lanes returned raw/semantic UNKNOWN at their
unchanged wall limits, with no target proof. A verified marking-admission gate
is progress in assurance, not a proof-search or speed advantage. Historical
and new authentication/admission/search/verification costs retain separate
overlapping scopes; implementation work counters are not interchangeable.
No RL gain, full PA/FOL completeness, geometric transfer or fixed universal
Wang palette is established. The larger research program remains ACTIVE.
