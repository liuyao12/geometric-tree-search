# Independent quantified/shared bridge and compact model checkers

Status: `SOURCE_ONLY_NOT_EXECUTED`. Only direct Source reading, byte hashing and
Python AST parsing have been performed. No scientific module import, model
construction, proof decoding, kernel call, search or test has been run.

These checkers use the standard library only. Neither imports an RF compiler,
RF-profile checker, model adapter, search engine, control or native proof kernel.
The current master is `docs/basic-tiling-algorithm.md`, 21,657 bytes, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

## Source closure

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `source/shared_fact_checker_v2.py` | 34595 | `ae85c6bb9a123c6e7924cc7720f6adc8304029ea7a07843cc467100ab288b1c3` |
| `source/rf_shared_bridge_checker_v1.py` | 19638 | `72c2f518b1cedbc2c30f8438cdc347ea0a47a1f343e1b14899c1ba2584af9647` |
| `review/checkers-diff-v1.patch` | 30030 | `79e07a7d1d82bffdb056edbfdda45fc23bd699f6fa5e69d0610b70c6498caa83` |

The compact checker is independently adapted from the previously qualified
`gcts-proof-dag-search-20261103-v1/reference/shared_fact_checker_v1.py`, 34,073
bytes, SHA256 `d550bbd3b4a773cef2a9c54cd7850c0b6587fd46263c6e43365b62e44c44a48e`.
The patch contains the full baseline difference and the whole new RF bridge
checker. The prior file remains unchanged. The new bridge checker is not an
adaptation importing the bridge producer.

## Admission chain and scope

The research driver must join separately saved receipts and exact input hashes:

1. The unchanged independent RF-profile checker `R.verify(declaration, compiled,
   generation)` establishes the complete declared finite RF profile, including
   original term/template retention, UI rounds and capture exclusions. A valid
   individual ZERO is insufficient evidence of this profile's completeness.
2. Every RF ZERO receives its own native logical-admission gate under the exact
   original theory. The bridge/model modules do not establish that truth.
3. The bridge checker below establishes the whole literal RF-to-shared mapping
   on those exact declaration, compiled and generation bytes.
4. The compact checker `verify_model` establishes the whole finite point
   reduction for the exact bridge catalogue and prepared packet.
5. A search result needs its own applicable graph/semantic assurance. A positive
   result is independently decoded by this checker, compared with the adapter's
   decoding on all semantic fields, then checked by the native proof kernel.

No receipt from a different statement, catalogue, RF profile, variable pool,
slot bound or model version can discharge these obligations. This API does not
accept an unverified receipt string as a substitute for the separately bound RF
or native gate. It also does not execute those external gates.

The existing `verify_basis` and three-argument `verify` entry points remain
**ground pred0/imp subformula/assumption-only interfaces** for compatibility.
They return `UNKNOWN: INDEPENDENT_BASIS_PROFILE_NOT_IMPLEMENTED` for an RF
catalogue. This study must call `verify_model`, not either ground-profile entry
point, on its RF catalogue. The generic model checker retains quantifiers,
equality, arbitrary declared function/predicate arities, literal variable names,
and all original primitive ZERO, MP and GEN definitions. It performs no
ground-Horn conversion, alpha-renaming, proof-guided thinning or target-proof
import.

## Whole RF bridge verification

```python
import rf_shared_bridge_checker_v1 as Y

receipt = Y.verify(
    declaration, compiled, generation, slots, bridge_packet,
    max_items=500_000_000,
    max_work=1_000_000_000,
    wall_seconds=120.0,
)
```

`Y.VERSION` is `Independent-RF-shared-bridge-checker-v1`.
Inputs are native JSON values. The checker independently validates the original
statement/signature/closed assumptions and the full RF carrier's literal
registry, indices and native payload syntax. From the declared statement and
declared terms it reconstructs the original variable-name pool and the exact
fresh `__rf_hole` convention, retaining this hole in the shared variable pool.
All generated formula and primitive payload names must lie in that pool.

The bridge packet has exactly these fields:

```text
schema, status, catalogue, mapping, bindings, census, limits, timings, admission
```

Its schema/status must be `RF-shared-catalogue-bridge-v1` /
`CATALOGUE_UNVERIFIED`. An upstream `UNKNOWN` is not promoted.

The reconstruction compares every mathematical field using typed canonical JSON:

- Every sorted RF formula is retained. RF formula index \(i\) becomes shared ID
  \(i+1\), with no omissions, merges or reordering.
- Every original RF ZERO ID/payload/output is retained unchanged; only the
  catalogue's ZERO array is lexically sorted by the existing ID. Native logical
  validity remains external.
- Scanning every formula independently reconstructs all structural RF MP and
  GEN indices, checks those complete original indices, and converts all of them
  to the shared positive IDs. Shared MP sorts by antecedent/implication/output;
  GEN sorts by source/output/variable. Closed assumptions make the native GEN
  side condition uniform; native proof truth remains a separate check.
- The exact shared profile is `RF_FROZEN_SHARED_V1`, with the original RF profile,
  declared slot bound, whole variable pool, `allow_gen=True`,
  `LITERAL_SORTED_CANONICAL_JSON_V1`, and
  `RF_COMPLETE_COMPILED_NATIVE_ZERO_V1`.
- `mapping.formula_ids`, `mapping.zero_ids`, all catalogue content, provenance,
  all five bindings and all census fields are reconstructed and compared.
- The RF generation packet must bind the exact compiled core and retain its
  original profile/scope with empty `core_stages`, `core_assertions`,
  `goal_receptors` and `bridge_premises`. It does not authorize a new subset.

All hashes use compact sorted-key, `ensure_ascii=True` JSON plus one LF. The RF
compiled-core hash excludes only `costs` and `scope`. RF formula colors alone
are compact JSON **without** that LF, matching the original carrier ABI.

Bridge limits are exactly seven keys with these ceilings:

```text
max_formulas=1024, max_zero_definitions=8000, max_definitions=8000,
max_slots=16, max_items=500000000, max_depth=128, wall_seconds=120.0
```

`max_definitions` counts all ZERO, MP and GEN definitions. The bridge has no
row-generation limit because it generates no slot rows. A claimed complete
packet outside its declared mathematical size limits is rejected. Work, depth,
integer-size, memory or wall limits in the independent checker yield `UNKNOWN`.
Packet timing/items fields are shape-checked provenance, not independently
certified producer performance or resource consumption.

On success, the receipt includes:

```text
status=VERIFIED
reason=COMPLETE_LITERAL_RF_TO_SHARED_MAPPING
checker=Independent-RF-shared-bridge-checker-v1
bindings, census, external_obligations, scope, checker_costs
```

The claim is conditional on the separately bound full RF-profile/native gates;
it is not a full first-order completeness claim or an RF-profile regeneration.

## Compact finite model verification

```python
import shared_fact_checker_v2 as N

receipt = N.verify_model(catalogue, prepared, **checker_limits)
decoded = N.decode(prepared, selected_cids, **checker_limits)
```

The checker kwargs are `max_items=500_000_000`, `max_work=1_000_000_000`,
`wall_seconds=120.0` by default. `N.VERSION` is
`Independent-shared-fact-checker-v2`.

The catalogue remains `Shared-fact-finite-catalogue-v1`. The prepared schema is
`Shared-fact-prepared-v2`; its status is `PREPARED_UNVERIFIED`. Its fields remain
`statement`, `catalogue`, `binding`, `definitions`, `model`, `universe`, `census`,
`limits`, `timings` and `admission` in addition to schema/status.

For a slot \(i\), the required center, active receptor and formula receptor are
the literal strings `q:<i>`, `a:<i>` and `f:<i>`. Their decimal suffixes have no
LF. A candidate ID is compact canonical JSON plus LF:

```text
[slot, kind, definition_id, refs]
```

The candidate scope is bound once by the exact prepared binding and model
version. A compact CID or point string is not globally meaningful across models.
The scope preimage is:

```text
{
  schema: Shared-fact-point-scope-v2,
  catalogue: {schema,statement,formulas,zeros,mp,gen,profile},
  slots: L,
  allow_padding: true,
  point_version: DAG-slot-ports-v2,
  candidate_version: DAG-candidate-v2
}
```

The model remains the six-field `Z-growing-point-model-v1` ABI, with version
`Shared-fact-slots-active-formula-v2:<scope>`, capacity one, all `q:` roots, no
seed t-values and the final active/goal formula seed marks. It has no additional
pair-filter field. Any later engine-schema wrapper requires its own explicit
literal association; it must not silently alter this prepared model.

The checker independently reconstructs all catalogue structural MP/GEN, all
ZERO and PAD owners at every slot, every strictly prior GEN reference, and every
ordered pair of strictly prior MP references. It merges all receptor marks and
omits exactly self-conflicting MP rows. All own/premise marks, CIDs, definitions,
roots, seed marks, full rows, binding and census must agree exactly. There is no
producer shortlist, proof-path restriction or omitted compatible row.

For \(L\) slots, let \(Z,M,G\) count ZERO, MP and GEN definitions. The complete
row census is checked before expected rows are allocated:

\[
R=L(Z+1)+M\sum_{i=0}^{L-1}(i^2-i)+G\sum_{i=0}^{L-1}i.
\]

The subtraction accounts for MP's distinct literal antecedent/implication FIDs
when both references name the same slot. All arithmetic uses native integers.
All mathematical comparisons use typed canonical JSON, preventing Boolean or
floating-point impostors for integer IDs, capacities or counts.

Prepared limits have exactly seven keys and these ceilings:

```text
max_formulas=1024, max_rows=250000, max_slots=16,
max_zero_definitions=8000, max_items=500000000,
max_depth=128, wall_seconds=120.0
```

The generic model success receipt has `status=VERIFIED`, reason
`COMPLETE_FINITE_SHARED_FACT_POINT_REDUCTION`, scope, catalogue/statement/model/
universe hashes, full census and row counts by kind. Its native-logical-validity
field explicitly says `NOT_RUN_BY_THIS_MODULE`.

## Independent selected-to-native projection

`N.decode` first rechecks the catalogue and complete prepared model. It requires
exactly one selected owner per required slot, literal membership in the full
universe, every seed/global mark agreement, active strictly prior references,
and the unchanged final goal. PAD owners are removed only from the native line
sequence; all slot-to-native and native-to-slot maps are retained. MP/GEN
references are remapped through these exact maps. ZERO native payloads and all
output ASTs remain unchanged.

Success is **`UNVERIFIED_NATIVE_CERTIFICATE`**, never `VERIFIED`. Its independent
schema is `Independent-shared-fact-decoded-v2`. The driver must compare semantic
fields with the adapter's `Shared-fact-native-decoding-v2` result, allowing only
the explicitly different schema/version/cost and explanatory text fields. The semantic
fields are the original statement, proof, slots, both slot maps,
`reference_mapping`, `proof_dag`, sorted selected CIDs/selected hash, statement
hash and scope. A fresh native proof-kernel receipt under the exact original
statement remains mandatory.

## Resources and result interpretation

Both checkers validate native JSON, finite floats in metadata, native integer
fields, bounded integer bit length and nested input depth. They meter inside
traversals. Canonical serialization is preceded by an iterative scan counting
full literal string/key lengths and a conservative ASCII serialization-size
charge. Repeated comparisons/hash scans are charged again. Work is a cooperative
implementation counter, not CPU instructions, bytes of resident memory or a
cross-method timing unit. The process supervisor still needs its own hard limits.

Malformed or inconsistent complete data yields `REJECTED`; incomplete upstream
packets, unavailable independent coverage or cooperative/resource stops yield
`UNKNOWN`. Neither permits narrowing a catalogue or row universe to fit a cap.
`UNKNOWN` is not a bounded absence proof. Successful point reduction/projection
does not certify search scheduler conformance, physical rollback bookkeeping,
native logical validity, unbounded proof completeness, universal Wang encoding,
marking-learning usefulness or comparative proof-search performance.
