# Unary control and existing logical markings

SOURCE ONLY; not imported or run. The exact qualified E3/C2/T2 Sources are
preserved under `reference/`. The complete current adapter difference is
`review/unary-engine-adaptation-v1.patch`.

The E4 entry point is unchanged:

```python
solve(model, limits, *, enumerate_incident=None, order=None, audit=None)
```

It requires `Z-growing-point-model-v3`: the old six fields plus mandatory
`pair_nogoods` and `unary_nogoods`. The latter is a strictly sorted unique list
of known literal EXPLICIT CIDs. Nonempty unary constraints are rejected for
provider inventories. All original logical marking values and literal zeros
are retained; additional learned markings must use separately validated fresh
support. Every placement remains in the inventory even if a declared unary
filter makes it ineligible. No shortlist becomes the universe.

The engine's unary set is immutable model-bound data. `_legal` checks it through
the same eligibility/forward/reverse graph; there is no dynamic selection or
new rollback state. The final positive certificate separately scans the
literal unary list against reconstructed selected IDs. Pair semantics, exact
rollback, generations, global dead/forced order and primitive fallback are
unchanged. The result version is `IP-GROWING-POINT-SEARCH-v4`; result, snapshot,
event and count-stat field sets remain unchanged. Work includes the new checks.

C3 independently normalizes the v3 model and excludes unary CIDs from its own
incremental graph. T3 deliberately scans the original literal unary list on
every complete re-enumeration. Both separately reject a final forbidden CID.
Their calls retain the preceding APIs; both require E4/version-v3 EXPLICIT
models. C3 keeps the lexical-order profile, complete events and exact serialized
entry/final/restored checkpoints. Sparse or absent actual intermediate-map
observations are not promoted to producer-bookkeeping assurance. T3 is used on
actual snapshots in tiny qualification; it is not called on fabricated graphs.

`tiny_assignment_oracle_v2.enumerate_model` independently checks every subset
of a small v3 inventory, including ordinary literal marks and unary/pair
constraints. Its `EXHAUSTED` result has an actual complete subset table and
Boolean existence. Refusals return `UNKNOWN` with no absence claim. This is only
for tiny qualification, never enumeration of the large arithmetic inventory.

These filters are declared problem constraints until the separate scoped
fixed-CID exhaustion and overlay-equivalence gate proves them redundant.
No engine/checker itself learns or certifies their redundancy. The supplied
preservation argument uses exact context projection; no old proof, known bad
CID or expected learned assignment is embedded in these adapters.

Twenty prospective qualification cases migrate all seventeen preceding models
with an empty unary list and add immutable-unary forcing, unary/pair/marking
rollback and finite unary exhaustion. Malformed/missing/unknown/repeated unary
lists, unknown/resource outcomes and semantic/actual-graph mutations require
fresh controls. Actual runtime qualification and a successful arithmetic proof
are not established by this Source document.
