# V2 qualification and truthful activation boundary

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. The current copied
master `reference/basic-tiling-algorithm.md` was read before editing; its exact
SHA256 is `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
No scientific Source was imported or called, and no test, compilation, model,
classification, proof or search result has been produced by this author.

The owned Sources/data are `source/qualification_phase_v2.py`,
`input/overlay-equality-qualification-v1.json`, this API and
`review/qualification-v1-to-v2.patch`. The exact baseline is the preserved
`reference/qualification_phase_v1.py`, 19,308 bytes, SHA256
`5604c9eea1c7d5c20962b91a2c93faac7d41cc496b6ee6410780a6e9e1754ed6`.
All v1 experiments and artifacts remain immutable, including their independent
overlay-admission UNKNOWN and blocked evaluation. No v1 label, selected proof,
native receipt or learned assignment is a new-run input.

## Retained qualification API

The entry point is `run(ctx)`. Root supplies the same `ctx.root`, `ctx.mods`,
`ctx.limits`, `ctx.read`, `ctx.save`, `ctx.sha`, `ctx.wire` and `ctx.engine`
interfaces as the v1 worker. Module key `U` now resolves the independently
reviewed U2 checker; key `K` resolves this v2 Source. All other module contracts
and scientific model/search caps remain unchanged.

The complete twenty literal tiny point fixtures and two logical qualifiers
are rerun fresh. Their actual E/C/T/paired-graph/oracle checks, all native ZERO
checks, full RF/profile/bridge/model gates, two native decoders and whole B
checks are retained unchanged. The nine preexisting malformed/resource/event/
actual-graph controls are retained. No candidate universe is narrowed and no
old scientific result is reused. PAD inventory versus selected-PAD coverage
remains explicit; the minimum-slot qualifiers need not select PAD.

The phase result retains schema `Quantified-marking-qualification-v1` and
`status='QUALIFIED'`, with version `Quantified-marking-qualification-phase-v2`.
It adds `equality_qualification` and `counts.private_equality_calls`. The
prospective private primitive census is twenty-eight valid-pair checks and
eight malformed/resource controls. Their outputs never enter the arithmetic
learner or search model.

## Equality differential qualification

U2's pinned private API is `_Reader(max_work, wall_seconds)` and
`reader.equal(left, right, reason)`. Equality returns `None`, inequality raises
the existing `_Reject` with the supplied reason, and resources raise the
existing `_Budget`. This is a private qualification interface, not a replacement
for public overlay validation. The full public `verify` API remains separate.

The independent reference relation for valid native JSON is computed after
freeze with Python's standard library:

```python
(json.dumps(value, sort_keys=True, ensure_ascii=True,
            separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
```

The test does not use U2 serialization or comparison to choose its expected
answer. It compares the two independent reference byte strings. A match must
be accepted by U2; a mismatch must raise exactly the test's named mismatch
reason, rather than an unrelated malformed-input or resource refusal.

Cases cover null, distinct bool/int/float kinds, positive versus negative float
zero, finite floats, string literals versus numbers, dictionary insertion
order, list ordering, empty list versus dictionary, nested data and explicit
mark `0` versus absent data. String escape/control-character cases remain
literal data, never a special wildcard.

`eq11-dict-insertion` uses `ASCII_INSERTION_ORDER` to construct its two
dictionaries at runtime. Their insertion orders differ before canonical
serialization; sorting the static declaration file cannot erase this coverage.

Unicode recipes are essential because JSON parsing can erase the native
Python distinction being tested. They construct the astral scalar with
`chr(0x1F600)` and a literal surrogate-pair string with
`chr(0xD83D)+chr(0xDE00)`. These distinct native strings have the same escaped
canonical JSON. Recipes test values, dictionary keys, insertion order, native
key sorting relative to `chr(0xE000)`, swapped values on colliding escaped keys,
and different native keysets with duplicate escaped-key sequences. The reference
preserves `json.dumps(sort_keys=True)` native string ordering; it does not sort
by escaped keys or assume native keysets suffice.

Each saved valid-case receipt contains its static declaration/recipe, both
reference wire strings and hashes, expected relation, actual primitive status,
reason, charged work and elapsed time. Recipes and wire strings preserve
duplicate escaped-key behavior without attempting to store that dictionary as
an ordinary JSON object whose parser would collapse the duplicate keys.
Shared valid subtrees are compared against deep copies; sharing is not a cycle.

Malformed controls include a nonstring dictionary key, hidden NaN/infinity,
tuple, overwide integer and cyclic array. Deep and zero-work cases exercise
explicit refusal. The ordinary frozen U2 limits are used, with only the
prospectively declared zero-work control lowering `max_work` to zero. An invalid
input must not be treated merely as a valid unequal pair: a `_Reject` carrying
the test's mismatch marker fails qualification. Cyclic non-JSON input must
never be accepted; either typed rejection or resource UNKNOWN is recorded.

Invalid objects are represented by the fully specified recipe and returned
status, not serialized into evidence through a lossy or invalid JSON encoding.
No template-search or theorem claim follows from these differential checks.

## Public checker qualification without fabricated custody

No positive public U2 call is made using invented LABEL receipts in the
QUALIFY worker. Its private relation is tested there; genuine full public
success can only occur later from a fresh complete LABEL worker in this run.
Root owns the prospective `H.learn` integration and phase protocol.

The intended gate order within real LEARN is:

1. Authenticate actual completed prior LABEL PID/native exit, source/runtime,
   protocol, results/logs and physical evidence refs.
2. Synthesize and structurally construct the candidate overlay from those
   fresh labels, preserving all original data and the complete inventory.
3. Require U2's public conditional VERIFIED result on those actual objects.
4. Execute the declared public mutants/refusal against copies of that actual
   packet/provenance, saving full inputs and outputs before assertions.
5. Only after these gates succeed write the admitted activation models and
   return LEARN's admitted status. EVALUATE remains prerequisite-gated.

The input declares the exact ordered mutation IDs:
`u2-malformed-mark-literal`, `u2-wrong-scope`, `u2-unknown-as-negative`,
`u2-corrupt-restoration`, `u2-public-zero-work`. The first four must be rejected;
the last must remain UNKNOWN with no activation. Unknown-as-negative and
restoration mutants rebuild ordinary object/binding hashes, so rejection must
reach the specific semantic gate (`ADMITTED_QUERY_STATUS` or
`QUERY_RESTORATION_BYTES`) before authentic original LABEL custody later rejects
the forged association. Root's H implementation owns these full-packet recipes
and their exact observations.

If no negative or complete original packet exists, corresponding controls must
be explicitly NOT_APPLICABLE, never supported with a fabricated failure or
positive process receipt. Public private/resource/negative control claims must
remain distinct from the actual full public success. No successful run is
presumed in this Source plan. Any resource refusal or failed required gate
preserves its evidence and prevents activation; there is no retry/cap raise.

The unchanged one-billion-work and 120-second U2 caps are Source resource
guards, not a speed comparison with U1. Fresh v2 arithmetic uses the same full
grammar, scheduler and model bounds as v1, without reusing its labels or proof.
This prospective qualification establishes no arithmetic theorem, RL gain,
uniform Wang palette, geometric marking transfer or performance advantage.
