# Private streamed-checker qualification

Status: `SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE`. No scientific import,
helper, equality/hash test, engine, model, proof, compiler, kernel or learner
has been invoked. Only Source authoring, AST parsing and static JSON parsing
were performed. Prior namespaces remain immutable. The normative master is
the unchanged `reference/basic-tiling-algorithm.md`, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`,
whose exact text was already read in full for this program.

Held files:

| File | Bytes | SHA256 |
| --- | ---: | --- |
| `source/streamed_qualification_v1.py` | 9948 | `bdf8bae6ffe724cdfdc79b706207edad43b4ca6e4ca506066f3bc24a224d2d12` |
| `input/streamed-hash-qualification-v1.json` | 3542 | `86f17c93983c815dc70be81a041cf617d28760974d49ec500217a42f27996fcb` |

The pre-buffer-control drafts are preserved in `review/` with
`before-buffer-v1` filenames. The Source-only delta is
`review/streamed-qualification-buffer-v1.patch`.

## Caller and subject

`run(ctx)` returns one JSON-compatible qualification result. Root owns exact
Source/input/runtime freeze, prerequisite admission, exclusive bounded saving
and the actual native process. No work occurs at module import.

Required context:

- `ctx.mods['U']`: the newly reviewed U3 module, with
  `_Reader(max_work, wall_seconds)`, `reader.sha(value)`, `reader.equal(...)`,
  `_Reject`, `_Budget` and the additive `reader.metrics` dictionary.
- `ctx.mods['J']`: exact unchanged `qualification_phase_v2.py`. Only
  `equality_qualification(ctx)` and `equality_recipe(spec)` are called. `J.run`
  and every engine/logical-qualification helper are **not** called.
- `ctx.limits['U']`: exactly `max_work=1000000000`, `wall_seconds=120.0`.
- `ctx.read(relative)` and exclusive `ctx.save(relative,value)` returning
  exact physical refs. Root binds the frozen context and output captures.

The unchanged E4/native/carrier/model Sources and their prior exact native
qualification are authenticated by a separate driver gate and prior evidence
manifest. This module makes no new E4 conformance or theorem-search claim from
hash tests, and does not read old proofs, selected sets, failure CIDs, label
packets, learned markings or prepared model outcomes as qualification inputs.

## Equality and independent reference bytes

The first operation is the unchanged J private equality gate: twenty-eight
valid pairs and eight invalid/resource controls. It uses U3 under `ctx.mods['U']`
and saves its same primitive records. Its returned aggregate is saved as
`data/qualify/equality-summary.json` before requiring the complete gate.

Both operands of all twenty-eight valid pairs are then hashed. Runtime recipes
preserve actual ASCII/Unicode insertion orders, astral versus literal surrogate
strings, duplicate escaped-key collisions, native Python key ordering, shared
acyclic references, signed-zero floats, native type differences and nesting.
There is no JSON parse roundtrip that erases those distinctions before hashing.

Expected bytes are independently materialized with the standard library:

```python
(json.dumps(value, sort_keys=True, ensure_ascii=True,
            separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
```

Expected SHA256 comes from `hashlib.sha256` of those complete bytes. Neither
U3's serializer nor its hash chooses the expected answer. Materialization here
is deliberately limited to the prospectively tiny reference corpus, not the
large arithmetic objects whose hashing motivated U3. No expected digest is
supplied by an old research outcome.

## Streamed SHA corpus and refusals

The static input independently declares:

- Both operands of the existing \(28\) valid pairs: \(56\) hash calls.
- Every codepoint from \(0\) through \(255\), inclusive: \(256\) calls. This
  includes all ASCII control characters, quoting/backslash, DEL and Latin-1;
  the upper half is correctly described as byte codepoints rather than ASCII.
- \(24\) separately named boundaries spanning ASCII/BMP transitions, line
  separators, surrogate endpoints, the first astral value and maximum codepoint.
- \(5\) string sequences mixing escapes, minimum/maximum surrogate pairs,
  lone surrogates and Unicode boundaries.
- \(20\) native scalar recipes: null/Boolean, bounded positive/negative
  integers through \(256\) bits, both float zeros, finite normal/subnormal
  extremes, adjacent-to-one values and exponent-format examples.

The prospective successful-hash census is therefore \(361\). This is a
declared call count, not an observed result. Every actual return and complete
independent reference wire/digest is saved under `data/qualify/stream-sha/`
before equality with the expected digest is asserted. The original recipe and
reference wire string retain surrogate/key-collision evidence without storing
a lossy parsed duplicate-key dictionary as the evidence itself.

All eight preceding refusal recipes also exercise `reader.sha`. The selected
operand is the actual invalid one: hidden infinity uses the right operand;
zero work, depth, nonstring key, hidden NaN, tuple, overwide integer and cycle
use the left. Zero work alone prospectively lowers the ordinary work bound.
No reference wire is manufactured for an invalid object. Only recipe, actual
return/reason, work/time/metrics and ref are saved under
`data/qualify/stream-sha-controls/`. Every such control must return REJECTED or
UNKNOWN as declared and must return no hash. Cycle follows the unchanged
`NO_ACCEPTANCE` control profile. No malformed input may become an accepted hash.

One additional prospective refusal constructs an ASCII input string of
\(64\) MiB plus one character. U3's declared scalar-output buffer ceiling is
\(64\) MiB, including JSON quotes, so this cannot be encoded within that
bound. The qualifier saves only the recipe and actual status/metrics: it never
serializes the huge input or computes a huge reference wire. The private hash
must return UNKNOWN with no digest and reason `CHECKER_SCALAR_BUFFER_BYTES`.
The native integer metrics `stream_scalar_allocation_units`,
`stream_scalar_fragments`, `stream_fragments` and `hashed_bytes` must all be zero,
confirming the specific pre-encoder refusal path. Input construction and
validation costs remain part of the actual qualification process; they are
not presented as a zero-cost check. This makes nine SHA refusal controls.

## Result and limits

Success has schema `Streamed-checker-qualification-v1`, version
`Streamed-canonical-qualification-v1`, status `QUALIFIED`, equality-summary ref,
all hash-case/control refs, explicit component counts and measured module time.
It records \(36\) equality-primitive calls, \(361\) successful hash calls and
\(9\) hash refusal calls only if all prospective gates actually complete.
It does not call public U3.verify with fabricated process/provenance objects.
The real public success gate belongs to a separate phase with authenticated
prior actual LABEL provenance.

Any incorrect, malformed or nonconclusive required subject result is retained
before the qualifier raises; Root must preserve that failed attempt and may
not silently retry or raise a cap. Private work/time/metrics are not benchmark
equivalents to U1/U2 implementation counters, nor is this corpus a proof for
all JSON trees. The Source-level stream equivalence argument and full unchanged
gate review remain separate. Only fresh actual arithmetic evaluation can supply
a new admitted target proof or a meaningful comparison; none is established by
this Source handoff.
