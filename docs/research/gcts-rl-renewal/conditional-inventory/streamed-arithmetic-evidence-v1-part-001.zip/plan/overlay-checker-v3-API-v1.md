# U3: bounded canonical hashing for a warm arithmetic attempt

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No scientific module
has been imported or called; no SHA/equality qualification, public checker,
engine, decoder or kernel has been run by this author. Only Source authoring
and AST parsing are authorized. All v1/v2 Sources and data remain immutable.

Owned Source: `source/unary_overlay_checker_v3.py`. Exact local U2 baseline is
`source/unary_overlay_checker_v2.py`, 24,617 bytes, SHA-256
`5ec69d08fe14f1e64c8e2b5575caf8ff9dcfe1874db5a750ff3a8159762be778`.
Complete delta: `review/unary-overlay-checker-v2-to-v3.patch`. The normative
local master remains the byte-identical 21,657-byte point-model reference,
SHA-256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.

## ABI, limits and gates

The public `verify` signature, admission schema, model/label/packet/provenance
schemas and statuses remain exactly those documented for U2. `VERSION` is
`Independent-scoped-unary-overlay-checker-v3`. The default and maximum remain
one billion work units and \(120\) seconds. `_Reader(work,wall).sha(value)`
still returns a lowercase SHA-256 hex string or raises `_Reject`/`_Budget`.
`_Reader.equal` is unchanged, including complete native JSON validation,
strict scalar types, Unicode/surrogate and sorted-key collision behavior.

All model, fixed-context, raw/C3/native label, original-scope, event/endpoint,
sparse overlay/control and actual clean prior LABEL custody gates retain
their U2 helper bodies. The independently normalized immutable base scope is
still locally reused for the final base binding. No cross-object hash cache,
goal/CID pattern, narrowed inventory or gate deletion is introduced.

U3 adds a per-scalar **canonical output** ceiling of 64 MiB, declared as
`SCALAR_BUFFER_BYTES`. Exceeding it raises `_Budget` with
`CHECKER_SCALAR_BUFFER_BYTES`, hence public UNKNOWN with no activation. It is
not a logical rejection. Each string/byte representation is bounded; this is
not a claim that total Python/C allocator RSS equals that output bound.
Native input objects, sorted key lists, two scalar representations and a
previous yielded fragment can coexist. Root's independent process memory
guard and observed high-water RSS remain necessary.

## Canonical stream and scalar bounds

SHA first validates the **entire** finite native JSON object graph with the
unchanged iterative scan: native strings/keys only, finite floats, bounded
integers, depth guard, ancestor-cycle rejection and shared acyclic objects.
No partial digest is returned when validation or a resource guard fails.

It then walks container iterators without recursive serialization or an
all-descendants action list. Arrays emit brackets, commas and members in
order. Objects emit braces and their key/value sequence in the same metered
native string-key order as `json.dumps(sort_keys=True)`. Keys are not merged
or sorted by escaped text. Scalars use the unchanged `ensure_ascii=True`,
compact, `allow_nan=False` JSON spelling. Exactly one final LF is emitted.
SHA receives each bounded byte fragment immediately; no whole compound JSON
wire is constructed.

Before a string's C encoder runs, an exact visit counts its escaped ASCII
length, including two surrounding quotes. For each native code point:

| Character class | Output bytes |
|---|---:|
| Quote, backslash, backspace, tab, LF, form feed, CR | \(2\) |
| Other printable ASCII from \(32\) through \(126\) | \(1\) |
| Other BMP code point, including an explicit surrogate | \(6\) |
| Astral code point | \(12\) |

A generic lower-bound check can refuse immediately when the native string
length plus its quotes already exceeds the scalar ceiling. Otherwise,
each visit and exact output allocation is charged **before** `json.dumps`;
the actual result length must equal the counted length. Creating the ASCII
byte representation is separately charged before encoding, followed by a
length assertion and wall check. This preserves the astral-scalar versus
literal surrogate-pair equivalence without restricting valid strings to ASCII.

Native integers retain the 256-bit admission bound. Exact decimal length is
computed through bounded integer division, with sign handling, before the
scalar encoder; the result must fit the existing 84-byte bound. Finite floats
reserve the existing 132-byte scalar bound before C encoding, then charge and
check their actual ASCII output length. Signed zero remains distinct. Null
and booleans emit their fixed canonical byte literals. Every scalar output
obeys the explicit buffer ceiling.

Every emitted hash byte is charged before `hashlib.update`, and a cooperative
wall/work check follows that C operation. Scalar JSON/ASCII encoders and the
final digest likewise have post-operation checks. The existing `encode` method
remains U2's bounded whole-wire encoder for its remaining small protocol,
result and scalar uses; SHA no longer calls it on compound values.

For accepted JSON within the resource envelope, the intended identity is:

\[
 \operatorname{sha}_{3}(x)
 =\operatorname{SHA256}\!\left(
   \operatorname{wire}_{2}(x)\right).
\]

This is a structural argument: scalar spellings are identical, ordered list
members and native-sorted object key/value sequences retain all punctuation,
and the same final LF is included. Incremental hashing hashes the
concatenation. Unicode escaped-key collisions remain duplicated in their
native-sorted sequence, just as in the old wire. This Source argument is not
an executed differential qualification receipt.

## Additive diagnostic metrics

U2's `comparison_metrics` fields remain. New fields are
`stream_validation_work`, `stream_nodes`, `stream_fragments`, `stream_bytes`,
`stream_string_characters`, `stream_exact_string_bytes`,
`stream_int_digit_steps`, `stream_float_reserve_units`, `stream_scalar_work`,
`stream_scalar_fragments`, `stream_scalar_bytes`,
`stream_scalar_allocation_units`, `stream_max_scalar_bytes`,
`stream_key_sort_work`, `stream_key_sort_comparisons`, and
`stream_key_sort_literal_units`.

`sha_work` includes validation, traversal, scalar preparation, sorting and hash
updates. `hashed_bytes`/`stream_bytes` count bytes actually fed to SHA, including
LF. The inherited `equal_sort_*` counters are **shared helper totals**, because
the unchanged metered `_keys` helper is now also used by the stream. The new
`stream_key_sort_*` counters identify that subset. Work intervals overlap and
must not be summed. Work units are not numerically interchangeable with v1/v2
despite the same numeric ceiling; full wall, memory and assurance costs matter.

## Warm provenance and prospective execution

This new experiment has three owned phases: qualify, admit, evaluate. Root's
declaration explicitly permits warm reuse of the complete prepared basis,
actual scoped negative and unactivated synthesis from v2. The 388 original
copied files and `input/prior-evidence-v1.json` authenticate that history.
There is no prior arithmetic-target proof to import, no new acquisition/label
claim, and no fabricated current LABEL process.

The warm driver must authenticate copied physical bytes under `prior/v2`
while preserving the inline original v2 protocol, source refs and genuine
LABEL native-zero process records. U3's unchanged pure custody check evaluates
those supplied old objects; physical namespace resolution remains the external
driver's explicit obligation. New-root admission separately authenticates the
actual U3 process and Source/runtime/protocol. Only genuine public U3 success
and the declared controls may permit fresh BASE/MARKS/FILTER evaluation on the
same full point model.

Oracle owns K3's independent canonical-reference SHA corpus and refusal
controls; Recovery owns the warm phase driver. Neither private corpus nor
Source inspection is a substitute for actual public admission. No new label,
learning, target proof, performance gain, RL, universal Wang search or geometry
transfer is established by this Source-only handoff.
