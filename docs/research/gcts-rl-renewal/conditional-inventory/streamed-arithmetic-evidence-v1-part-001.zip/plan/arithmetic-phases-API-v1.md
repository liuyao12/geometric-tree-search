# Quantified arithmetic phase module

Status: `SOURCE_ONLY_NOT_EXECUTED`. The complete Source has been read and AST
parsed. No scientific imports, helper calls, model construction, tests, proof
decoding or search have been performed by its author.

`source/arithmetic_phases_v1.py` exports `run(phase, ctx)` for exactly `prepare`,
`acquire`, `label`, `learn`, `evaluate`. It has standard-library imports only and
does no work at import. The common driver owns prospective freeze, prerequisite
process admission, physical source/runtime/guard custody, per-phase isolated
processes and exclusive bounded JSON persistence. Only the common driver writes
`data/<phase>/result.json` from the returned value.

The consumed declaration is exactly `input/arithmetic-declaration-v1.json`.
Its original finite closed theory and quantified goal are compiled fresh. The
slot bound must be the declared eight. No proof, witness, selected placement,
old bank or expected learned marking is read.

## Caller ABI

`ctx` supplies `root` (Path), `mods`, `limits`, `read(name)`, `save(name,value)`,
`sha(value)`, `wire(value)`, `engine(name,model,actual=False,max_nodes=None)` and
`make_provenance(label_result)`. Module roles are `F` original RF compiler, `R`
complete independent RF profile checker, `B` native kernel, `A` full RF bridge,
`Q` independent bridge checker, `M` compact adapter, `N` independent compact
checker, `E/C/T/O` engine/assurance qualification roles, and `L/U` sparse learner
and independent scoped overlay checker. The arithmetic module never calls the
ground-only `N.verify_basis` or three-argument `N.verify` on RF.

Saved refs contain `path,bytes,sha256,complete_json=True`. On subsequent phases,
the module checks physical bytes against prior saved refs before loading JSON;
the common driver's prerequisite admission separately binds each prior result,
actual process PID/native exit/guards and frozen protocol. The module does not
claim that a supplied JSON object alone authenticates native execution.

`ctx.engine` must save the model, complete available raw return, actual
observations and C result before exposing admission decisions. Arithmetic uses
`actual=False`: it claims complete semantic event/endpoints assurance when C
verifies, and no observed intermediate internal-map assurance. Qualification is
the separate module's responsibility.

The common limits exactly match the module's declared `rf`, `bridge`, `model`,
`checker`, `native` and `overlay` groups. Engine/C limits are caller-owned:
engine work \(10^{11}\), \(100000\) nodes, \(400000\) events,
\(200000\) rollback rows and \(120\) seconds; C items \(10^9\),
work \(5\cdot10^{11}\) and \(300\) seconds. Native B limits are depth
\(256\), \(10^7\) operations and \(4096\) proof lines. Output capture is
at most \(128\) MiB logical JSON; no cap is raised after observing an outcome.

## Phases and artifacts

All returned schemas are `QMT-<phase>-result-v1`, version
`QMT-arithmetic-phases-v1`, with `phase` and measured `module_seconds`.

- `prepare` returns `PREPARED` only after the complete unchanged RF compilation,
  full R reconstruction, every ZERO's fresh one-line native B admission, entire
  A/Q bridge, and complete M/N model reconstruction. It saves declaration,
  compiled, generation, bridge, prepared packet, all receipts and exact engine
  migration under `data/prepare/`. The migration adds only schema-v3/declared
  version plus empty ordinary unary/pair lists. All original CIDs, t/m values,
  mandatory logical marks, roots and seed rows remain. The complete pre-migration
  prepared packet is retained for decoding. `scope_sha256` binds the normalized
  migrated model; `prepared_binding` binds the original prepared reduction.
- `acquire` calls one original-model engine attempt with `max_nodes=1`. The first
  actual `PLACED` event's CID is the proposal. Raw UNKNOWN is permitted here and
  is not a failure label. If no such event exists, the phase returns UNKNOWN.
  Success is `ACQUIRED_PROPOSAL`; the actual event/raw refs are retained.
- `label` makes one fresh full fixed-CID extension query. It adds the CID's whole
  t/m contribution to the original seed, unions its positive support into roots,
  removes that CID exactly once and retains every other candidate. There is no
  acquisition-prefix seed or branch exclusion. Complete raw UNSAT and C finite
  exhaustion yield NEGATIVE. SAT and C VERIFIED require independently matching
  M/N decoding of the residual selection union the fixed CID under the original
  prepared statement, followed by fresh whole native B admission, before
  POSITIVE. C UNKNOWN yields UNKNOWN and no pruning. Success `LABELLED` includes
  actual learner labels and full `query_bindings` for prior-phase provenance.
- `learn` requires actual prior clean LABEL custody through
  `ctx.make_provenance`. It gives only the full actual CID list, saved labels,
  scope/evidence hashes and prescribed guard location to L. It saves synthesis
  before admission, structurally applies it once, then calls U on the complete
  query packet and actual process provenance. Only
  `VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION` permits `LEARNED_CERTIFIED`.
  Initial/UNKNOWN/POSITIVE labels can produce an empty identity layer; no seed
  zero or restriction is invented when no NEGATIVE exists.
- `evaluate` uses the admitted full-inventory BASE, MARKS and FILTER models in
  fixed warm-process order, one fresh engine attempt each. Every C-verified SAT
  is M/N-decoded against the original prepared model and freshly B-checked.
  Complete C-verified UNSAT is only finite bounded absence. Raw or assurance
  UNKNOWN remains UNKNOWN. All lane model hashes bind the U receipt; candidate
  IDs/counts remain complete and unchanged. `EVALUATED` means all three positions
  were attempted and recorded, not that all three yielded positive proofs.

## Projection, statuses and scope

The reusable `decode(ctx,prepared,selected,prefix)` saves both decoder returns
before gates; compares the original statement, complete proof, slot records,
slot-to-native/native-to-slot maps, reference map, DAG, sorted selected CIDs and
hash, statement hash and scope; saves the proof; then freshly checks B under the
unchanged original theory/goal. Its success is `VERIFIED_NATIVE_PROOF`.

Every fixed-query binding follows `Unary-fixed-query-binding-v1`, including
complete canonical model/raw/C/native hashes and physical evidence refs. Labels
bind the entire binding's hash. A fixed-query SAT with C VERIFIED but an UNKNOWN
or rejected native decoding/check cannot be relabeled UNKNOWN for U, because
U's UNKNOWN-label profile requires C UNKNOWN. This module preserves all returns
and stops LABEL with UNKNOWN/REJECTED instead; it never fabricates a C receipt or
reruns the query. Native/decoder refusals in evaluation remain recorded lane
refusals, without a positive or absence admission.

Helper UNKNOWN returns and RF `BasisLimit` become phase UNKNOWN with retained
refs and no partial activation. Inconsistent/invalid helper returns become
REJECTED or an owned native exception; the common supervisor preserves the
attempt and guards. Missing artifacts, physical/hash mismatches and impossible
projection associations raise and must not be hidden as successful science.

Per-helper timings exclude serialization; `engine_and_C_seconds` includes the
common engine wrapper and its persistence. `module_seconds` and the external
native observer include remaining work; they are overlapping scopes, not values
to sum blindly. No pure engine timing is inferred from wrapper time. If a phase
stops, absent component timings are unrecorded, not zero. All phase, acquisition,
label, learning, assurance, compile and prior setup costs must remain visible.

The claim is finite certificate-guided unary adaptation over mandatory logical
markings. It is not a learned spatial prototype, complete pair-corona catalogue,
RL study, new theorem, full PA/first-order completeness, universal fixed Wang
palette, heldout transfer or a comparative performance advantage.
