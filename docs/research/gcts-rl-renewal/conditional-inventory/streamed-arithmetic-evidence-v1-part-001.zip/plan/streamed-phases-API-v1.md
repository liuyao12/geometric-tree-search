# Warm prior-evidence admission and fresh streamed arithmetic evaluation

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. The complete local
master `reference/basic-tiling-algorithm.md` was read before editing; it remains
21,657 bytes, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
No scientific module has been imported or called. No compiler, learner, model,
label search, admission, evaluation, native check or test has been executed.
Prior roots remain immutable.

Owned Source is `source/streamed_phases_v1.py`; its full new-Source patch is
`review/streamed-phases-v1.patch`. Root owns the new common worker/observer and
the prospective protocol. Oracle owns new hash qualification; Report owns U3.

## Entry point and current execution

`run(phase, ctx)` accepts `admit` or `evaluate`. The caller provides the same
`ctx.root,read,save,mods,limits` interfaces as the preceding reviewed common
worker. Module `D` is the unchanged `arithmetic_phases_v2.py`; `U` is the newly
reviewed U3 checker. E/C/M/N/B are supplied through the unchanged D helpers.

The result schemas are `Streamed-arithmetic-admit-result-v1` and
`Streamed-arithmetic-evaluate-result-v1`, with phase/version/elapsed metadata.
Successful statuses are `OVERLAY_ADMITTED` and `EVALUATED`. A D `StopPhase`
resource/refusal remains UNKNOWN/REJECTED with saved refs and no activation.
An integrity, custody or required-control assertion fails the owned worker;
it is not converted into a proof or a fabricated successful receipt.

The common worker must first admit current QUALIFY, freeze all current Sources,
input/prior manifest, runtime, master and limits, and preserve actual current
started/invocation/observer records. Current protocol schema is
`Streamed-arithmetic-protocol-v1`. The module deliberately does not call
`ctx.make_provenance`: there is no new LABEL phase in this run.

## Two roots and two protocols

`input/prior-evidence-v1.json` declares the exact read-only namespace
`prior/v2`, original protocol SHA256, source root description and full physical
file list. Its current manifest contains 388 original files. Every member is
byte/hash authenticated before old data are consumed by a scientific helper.
The actual prior-tree file set must equal the manifest, with no symlinks or
path traversal. Equal bytes at distinct paths remain separate physical inputs.

An original relative ref such as `data/label/query-packet.json.gz` is resolved
only as `prior/v2/data/label/query-packet.json.gz` for external file custody.
The module projects file refs into this namespace when returning **new** refs.
It does not rewrite the original protocol, query, binding or provenance object.
In particular, U3 receives the genuine old inline protocol and original LABEL
receipts, with their original relative strings and hashes unchanged.

New `data/admit/original-v2-provenance.json.gz` is a physical copy of that
original object. Its internal relative refs still resolve under `prior/v2`,
not the new root. `data/admit/prior-authentication.json` supplies the explicit
namespace and projected refs. Any report/checker must retain that distinction:
the old LABEL PID/protocol authenticates the retained label, while the new
ADMIT PID/protocol authenticates the new U3 execution. Neither replaces the
other. U3's returned old-custody refs have the same original-root interpretation.

## Prior authentication gate

The module checks the original V2 frozen protocol, exact original Source/input/
reference/plan/review file set, Source admission, current bytes of the pinned
runtime and master, and the unchanged copied master. Five original phases must
have matching actual phase/PID, native integer exit zero, complete invocation
result refs, exact result/log pins, clean guards and frozen postchecks.
QUALIFY/PREPARE/ACQUIRE/LABEL keep their actual admitted statuses; LEARN remains
its actual scientific UNKNOWN despite native zero. Old evaluation or activated
model files are forbidden. The retained label is negative with no native target
proof, and no old fixed-union/evaluation proof is supplied to search.

The current loaded `E,C,M,N,B,D,J` roles and the additional unchanged
`F,R,A,Q,L,T,O` roles must have `__file__` at their exact expected current-root
path, with symlinks excluded. Each current file must be byte-identical to its
originally frozen prior Source entry. The authentication receipt records all
fourteen current/prior role refs. U3, the new phase Source H and new qualifier
K are intentionally excluded: those are new separately reviewed/qualified
code. This gate is necessary because the current hash qualifier does not rerun
the whole engine/native-decoder qualification. Current and original runtime
declarations must also match completely, including flags, version and binary,
rather than merely both referring to an existing executable file.

All original relative refs in the results and provenance must be manifest
members with matching bytes/hashes. The loaded preparation is joined to its
original declaration, full RF core/generation receipt, bridge/catalogue receipt,
generic complete model receipt, all native ZERO payload hashes and one-line
VERIFIED native receipts. The entire prepared model/universe/catalogue and
schema migration hashes are checked; CIDs, positive support and old seed/
formula/activity markings are preserved.

The retained query packet's canonical fixed-model, raw and C objects are joined
to the original binding and independently streamed logical file hashes. The
negative requires complete raw finite UNSAT and C VERIFIED finite exhaustion.
Learner labels and certificate-binding hashes must match. The saved synthesis
and constructed overlay must retain the original scope and CID constraint;
the old U2 UNKNOWN/nonactivation is checked and preserved.

These are byte/data/process associations, not a rerun of the old R, B, compiler,
model checker, search, labeler or learner. Their historical trusted methods are
the authenticated frozen Sources and clean prior execution. The retained prior
qualification proofs remain old qualification evidence, never target-search
inputs. The root manifest's `target_proofs=0` and the known absence of original
fixed-union/evaluation outputs are enforced.

## New admission and control gate

ADMIT calls U3's unchanged public `verify` signature on the exact retained base,
constructed marked/control models, synthesis, query packet and original
provenance. The one-billion-work and 120-second U limit is unchanged. No old
UNKNOWN is promoted by editing its status; a new successful U3 receipt is
required and saved before its gate. The three returned model bindings must
match the exact retained models.

Only after public success does unchanged `D.activation_controls` run all five
prospectively declared tests against these actual objects. Their inputs and
receipts are saved under the helper's existing `data/learn/controls/` paths in
the **new** root. This path is an artifact location, not a claim that a new
LABEL/LEARN process existed. All five must actually apply and pass before
activation; NOT_APPLICABLE does not satisfy this gate for the retained negative.
No fabricated process receipt is used for a positive control.

After those gates, current-root admitted models are saved as
`data/admit/base-model.json.gz`, `marked-model.json.gz` and
`control-model.json.gz`. The result carries exact refs, old prepared/synthesis/
overlay/query refs projected under `prior/v2`, three model hashes, namespace,
prior manifest, old phase costs, new authentication/U3/control costs, U3
comparison metrics and explicit zero new failure-label/synthesis/proof-input
counts. The original unactivated candidate is not silently relabeled as an
old successful admission.

## Fresh evaluation

EVALUATE requires the current admitted result through the common worker's
actual-process prerequisites. It reauthenticates every retained prior file,
loads the original prepared packet, verifies current admitted model-file bytes
and hashes, then executes fresh BASE, MARKS and FILTER through `D.engine`.
All lanes retain the same complete CID inventory, E/C limits, scheduler,
generations, rollback and lexical primitive fallback. Only the admitted literal
extra layer versus matching ordinary unary list distinguishes the models.
No old selected prefix, old proof, learner state or search cache is supplied.

Every actual SAT with C VERIFIED passes through unchanged `D.decode`, which
checks both original M/N projections and a new native B proof. Refused decoding
or assurance remains unresolved/rejected. Actual complete C-verified UNSAT is
a finite bounded exhaustion. Resource UNKNOWN is never a negative claim.
The lane result field layout matches the preceding D evaluator, with actual
raw/semantic/native statuses, stats, refs, costs, admission and exact lane order.

`EVALUATED` means the three prospective attempts have been recorded, not that
the arithmetic theorem was proved or one method outperformed another.

## Costs, limits and reporting

Metadata authentication uses standard-library streaming canonical JSON SHA and
file hashing, without a giant composite wire allocation or any scientific
helper. Its serialization semantics are the existing sorted-key ASCII compact
JSON plus final LF. Full-object authentication is capped by the existing
128-MiB capture size and owned outer wall/CPU/RSS guards; its elapsed cost is
separate from U3's declared meter. It is not a claim of equal work units or a
new proof checker. Root's new protocol and actual process supervision still
govern the entire worker.

This is explicitly **WARM REUSE** of V2 compilation/preparation, certified
failure and unactivated synthesis/application. Those historical costs remain
available in the old phase records and new authentication receipt; their
worker/helper intervals overlap. New authentication, U3, controls, fresh
search, decoding and assurance costs must also be reported. No cold-trial,
fresh-label-discovery, new marking-learning, arithmetic-target proof, speedup,
RL, geometric prototype or universal finite Wang claim is established by this
Source-only implementation. All actual outcomes remain to be observed after
Root's review and freeze.
