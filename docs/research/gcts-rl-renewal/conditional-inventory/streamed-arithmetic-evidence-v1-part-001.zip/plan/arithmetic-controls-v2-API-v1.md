# Fresh arithmetic attempt and activation controls

The common driver is `source/run_quantified_transfer_v2.py`. Its limits,
six phases, prerequisite/native-process gate and Context ABI are unchanged.
Only module paths for U, K and H and the provenance driver reference change.
The frozen protocol path/schema stay compatible with the preceding API; a
different root, file set and exact protocol hash identify this fresh attempt.
The governing prospective declaration is `experimental-protocol-v2.json`.

`source/arithmetic_phases_v2.py` retains the complete original arithmetic
pipeline. Its only scientific additions are the version label and
`activation_controls`, called after actual U2 success and model-binding joins,
before any admitted marked/control model file is saved. No old proof, label,
selected CID, marking or prepared universe is read as a scientific input.

The input is `input/overlay-equality-qualification-v1.json`, with an exact
ordered public mutation list. Every mutation uses this new run's actual base,
candidate overlay, synthesis, fresh fixed-CID packet and genuine prior LABEL
provenance. Only changed paths are copied; full mutated input and checker
output are saved separately before assertions. These are deliberately
inauthentic control objects, never training labels or authenticated evidence.

| Control | Required outcome | Specific gate |
|---|---|---|
| `u2-malformed-mark-literal` | REJECTED | `MODEL_LITERAL_OR_UNITS` |
| `u2-wrong-scope` | REJECTED | `QUERY_ORIGINAL_SCOPE` |
| `u2-unknown-as-negative` | REJECTED | `ADMITTED_QUERY_STATUS` |
| `u2-corrupt-restoration` | REJECTED | `QUERY_RESTORATION_BYTES` |
| `u2-public-zero-work` | UNKNOWN | `CHECKER_MAX_WORK` |

The UNKNOWN mutation updates the semantic-object hash, packet binding and
learner binding hash, so it must reject the purported negative's status rather
than merely an obsolete object hash. The restoration mutation changes the
actual endpoint, updates that endpoint hash and the whole raw/binding/learner
hashes, and must still reject restoration disagreement. Neither mutation
rewrites the real prior process records or pretends the changed query was
executed. Their specified gates precede custody checking. Negative-only and
conclusive-only controls become `NOT_APPLICABLE_LABEL_PROFILE` if the actual
fresh query does not provide that profile. This does not invent a label.

The aggregate `data/learn/activation-controls.json` is saved with status
`PASS_ACTUAL_QUERY_ACTIVATION_CONTROLS`; the learned phase result binds it in
`refs.activation_controls` and reports its elapsed cost separately. Any failed
control stops the owned phase without activation. Primitive differential tests
in K2 are a separate qualification gate; they never fabricate a public positive
provenance fixture.

All existing declarations of finite logical scope, complete candidate
inventory, literal zero versus absence, immutable learned marking, ordinary
filter control and independent native proof extraction remain unchanged.
These controls establish neither an arithmetic target proof nor useful
pruning until the actual evaluation returns and its native proof gates pass.
