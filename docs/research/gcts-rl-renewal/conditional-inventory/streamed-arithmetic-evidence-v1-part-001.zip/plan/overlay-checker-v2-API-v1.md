# Unary overlay checker v2: equivalent structural comparison

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No checker, engine,
learner, compiler or other scientific module has been imported or called. Only
the new Source's Python AST has been parsed. Version 1 files and experiments
remain unchanged; no v1 labels or proof outputs are new scientific inputs.

Owned Source: `source/unary_overlay_checker_v2.py`. Immutable baseline:
`reference/unary_overlay_checker_v1.py`, 20,252 bytes, SHA-256
`e66c1cae5bc7930d5b2477104807699e755c7d14c87d5e4fcca185b4c73658c3`.
The complete baseline-to-v2 diff is `review/unary-overlay-checker-v2.patch`.
The unchanged model, packet and provenance API is documented in
`plan/overlay-API-v1.md`; this document describes only the implementation delta.
The exact local normative master was read in full; it remains the point-model
contract, not evidence that an unexecuted checker has passed qualification.

## Public ABI and retained gates

```python
verify(base_model, marked_model, control_model, synthesis,
       query_packets, provenance, *,
       guard_point='learned:unary:guard:v1',
       max_work=1000000000, wall_seconds=120)
```

`VERSION` becomes `Independent-scoped-unary-overlay-checker-v2`. Admission
schema remains `Scoped-unary-overlay-admission-v1`. Existing statuses remain
`VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION`, `UNKNOWN` and `REJECTED`; refusal
never activates an overlay. Work ceiling/default stays one billion, wall
ceiling/default stays \(120\) seconds, and the native JSON depth guard remains
\(256\). No larger limit, formula/CID specialization or reduced universe is
introduced.

All original normalization, original-model filter restrictions, fresh-port,
fixed-CID full residual, label and native-positive, complete raw/C3 event and
endpoint, original scope/hash, sparse synthesis, exact marked/control and
prior-clean-LABEL provenance gates remain in the same helper bodies. The only
non-reader computational change reuses the already-computed normalized base
scope for the final base model binding. No authenticity obligation is removed:
this pure checker still cannot authenticate physical execution from JSON.

## Structural equality

The private qualification interface stays:

```python
r = _Reader(max_work, wall_seconds)
r.equal(a, b, reason)  # None on equality; _Reject or _Budget otherwise
```

Each equality call first scans **both complete trees**, even if their roots or
an early member differ. This retains native-only JSON validation and rejects
non-string object keys, nonfinite floats, oversized native integers and Python
subclasses/non-JSON objects. The scanner now explicitly detects an ancestor
cycle as `REJECTED/JSON_CYCLE` instead of traversing it until a resource guard;
cycles have no finite canonical JSON representation. Repeated references to a
shared acyclic value are accepted and compared as repeated JSON values. Depth
or cooperative work/wall exhaustion remains UNKNOWN.

Comparison then uses an iterative stack of iterators:

- Types must be identical. In particular, `bool`, `int` and `float` are
  distinct. `None`, native booleans and bounded integers compare directly.
- Lists retain their order and length.
- Every dictionary is sorted in **native Python string-key order**, matching
  `json.dumps(sort_keys=True)`. Corresponding key and value pairs are compared
  in that order. This is not a dictionary-keyset normalization or lookup-based
  approximation.
- ASCII strings may compare directly only when both strings are ASCII.
  Non-ASCII strings compare their bounded canonical scalar JSON bytes.
- Finite floats compare canonical scalar JSON bytes, retaining the difference
  between `-0.0` and `0.0` as well as integer/float distinctions.

For accepted acyclic native JSON values, the comparison relation is exactly
the former relation:

\[
 \operatorname{equal}_{2}(a,b)
 \iff \operatorname{wire}_{1}(a)=\operatorname{wire}_{1}(b).
\]

Here `wire` is unchanged sorted-key, `ensure_ascii=True`, compact-separator,
`allow_nan=False` JSON, encoded as ASCII with one final LF. The equivalence
argument is structural induction: scalar rules compare the same canonical
scalar text; list delimiters preserve the ordered element sequence; object
delimiters preserve the native-sorted sequence of canonical key/value pairs.
Container boundaries and lengths are retained.

The Unicode corner is deliberate. An astral Python scalar and a literal UTF-16
surrogate-pair string can have identical `ensure_ascii` bytes while differing
as Python strings. Distinct native object keys can likewise serialize to the
same escaped key; their native sorting can reorder them relative to BMP keys.
The non-ASCII scalar fallback and native-sorted key/value sequence preserve
these cases without merging keys, restricting the domain to ASCII, or claiming
native string equality is always canonical byte equality.

## Canonical encoding, hashing and resource accounting

`encode` and `sha` preserve the exact bytes/digests. Encoding still validates
and reserves a conservative byte bound **before allocation**, then verifies
the actual bound. Both encoding and SHA now perform a final cooperative
work/wall check after their potentially long C-level operations. SHA traversal
bytes are explicitly charged. Equality scans, iterator visits, literal
comparisons, native sort comparisons and scalar fallback encodings are charged;
the large composite objects are no longer serialized twice merely to compare
them. Native-sort comparison metering charges inspected string lengths; it
does not silently use an unmetered full dictionary sort.

No broad mutable-object hash cache is used. `_model` independently creates the
normalized base containers; its scalar leaves are immutable native values.
The subsequent fixed-context and expected-overlay constructors read those
containers without modifying them. Therefore the first `scope=r.sha(base)`
is also the exact final base-model binding; marked/control hashes are computed
fresh. This is a local immutable-value reuse, not a cross-scope cache.

All returned statuses add `comparison_metrics`. Its stable integer fields are
`encode_calls`, `encode_work`, `encoded_bytes`, `sha_calls`, `sha_work`,
`hashed_bytes`, `equal_calls`, `equal_work`, `equal_pairs`,
`equal_literal_units`, `equal_sort_comparisons`, `equal_sort_literal_units`,
`equal_nonascii_scalar_pairs`, and `equal_float_pairs`. Successful admission
adds `comparison_metrics_scope`. These intervals **overlap**: SHA includes
encoding and equality may include scalar encoding. They must not be summed.
Version-2 charged-work units are not numerically interchangeable with v1
units, despite the unchanged numeric cap. Wall/memory and the complete
acquisition/labeling/admission/evaluation costs still matter.

## Prospective qualification and limits of this Source handoff

Recovery owns the fresh qualification implementation. It can compare the
private equality primitive against independently constructed canonical JSON
bytes only after Root reviews and freezes the Sources. Suggested cases cover
native type differences, signed float zero, nested key/list ordering, control
and non-ASCII strings, astral/surrogate spellings and key collisions/order,
invalid types/keys/nonfinite floats/cycles, shared acyclic values, depth, work
and wall refusals. This is qualification of the comparison primitive, not a
forged positive public overlay/provenance receipt.

The public positive admission must be obtained from the new, fresh clean LABEL
phase and its scoped packet. Six new phases use the original full grammar and
prospective input/caps. Neither a successful public admission, target proof,
runtime improvement, learned-pruning advantage nor geometry/RL transfer is
established by this Source-only handoff.
