# Compact shared-fact adapter and complete RF bridge

These Sources are unexecuted. This document specifies data transformations and
their external admission gates; it records no prepared instance, search result,
proved theorem, learned marking or performance result. No previous proof,
selected placement, imported lemma or target derivation is an input.

The master reference was read before editing: the current
`docs/basic-tiling-algorithm.md`, 21,657 bytes, SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
The exact adapter baseline is
`gcts-proof-dag-search-20261103-v1/source/shared_fact_model_v1.py`, 22,422 bytes,
SHA256 `455fadf33dea5150b5e35fde599a8edb59c1adac1041d2214a44156a97b6e32e`.
The companion patch contains its complete diff and the entire new bridge.

## Public calls and successful packets

`source/rf_shared_bridge_v1.py` exports
`bridge(declaration, compiled, generation, slots, limits=None)`.
It returns a native JSON object. Success has
`schema='RF-shared-catalogue-bridge-v1'` and
`status='CATALOGUE_UNVERIFIED'`, with:

- `catalogue`: the complete `Shared-fact-finite-catalogue-v1` representation.
- `mapping.formula_ids`: every pair `[rf_id, shared_id]` in original order,
  with the shared ID exactly one greater than the zero-based RF ID.
- `mapping.zero_ids`: every `[original_id, original_id]`, sorted by the literal
  existing RF identity. Sorting does not rename the ZERO definition.
- `bindings`: `original_statement_sha256`, `declaration_sha256`,
  `rf_compiled_core_sha256`, `rf_generation_sha256`, `catalogue_sha256`.
- `census`: `formulas`, `zeros`, `mp`, `gen`, `slots`.
- `limits`, `timings.{seconds,items}` and an explicit external-admission notice.

`source/shared_fact_model_v2.py` exports
`prepare(catalogue, slots, limits=None)` and
`decode(prepared, selected, limits=None)`. Preparation success has
`schema='Shared-fact-prepared-v2'`, `status='PREPARED_UNVERIFIED'` and the
original `statement`, full `catalogue`, `binding`, `definitions`, `model`,
`universe`, `census`, `limits`, `timings`, `admission` fields. Decoding success has
`schema='Shared-fact-native-decoding-v2'`,
`status='UNVERIFIED_NATIVE_CERTIFICATE'`; it includes the original statement,
native `proof`, `slots`, `slot_to_native`, `native_to_slot`, `reference_mapping`,
`proof_dag`, sorted `selected` and its hash, statement hash, scope and elapsed
time. Neither success label establishes logical validity.

All canonical hashes in these Sources use ASCII JSON, `sort_keys=True`,
`separators=(',', ':')`, `ensure_ascii=True`, `allow_nan=False`, followed by
exactly one LF. Hashes refer to canonical data, not arbitrary file serialization.
The driver must separately preserve exact input/output file-byte references.

## Complete RF representation bridge

The input declaration must have literal nonempty `id` and `problem`; `problem`
has exactly `theory` and `goal`. It may contain other prospective declaration
metadata. Top-level proof/witness/bank fields named `proof`, `target_proof`,
`witness`, `selected`, `bank`, `control_proof` are rejected. A declared `slots`
field, if present, must equal the explicit argument. Legacy depth metadata is
never substituted for the shared proof-slot bound.

The compiled carrier must have exactly the existing RF fields
`schema,version,theory,goal,goal_id,profile,logical_basis,zero_instances,mp_index,gen_index,costs,scope`
and the unchanged RF schema/version
`V-interned-Hilbert8-basis-v1` / `V-INTERNED-FINITE-HILBERT8-v1`.
The declaration's statement must equal its complete `theory` and `goal`.
All literal formulas and sorted color strings are copied, in their original
order. Colors equal the canonical formula JSON without its final LF. The full
sorted distinct RF variable pool is copied, including its declared fresh
`hole`; there is no variable, formula, native payload or definition thinning.

Each original ZERO record must be exactly `id,rule,formula_id,line`, with its
original consecutive RF identity `i0`, `i1`, and so on, and a native line whose
rule/output match that record. The bridge preserves its full native payload,
then sorts output ZERO records lexically by their unchanged IDs. It does not
replace an `instantiate`, `eq_subst` or other primitive with a new axiom.

The bridge independently enumerates the structural indexes from all formulas
and requires exact equality with the supplied RF indexes. RF
`[implication,antecedent,output]` MP records become shared
`{antecedent,implication,output}` with each ID increased by one. RF
`[universal,body,variable]` GEN records become
`{source,output,variable}` similarly. Every existing record is retained.
Shared MP order is `(antecedent,implication,output)` and GEN order is
`(source,output,variable)`.

The generation carrier has exactly
`schema,version,profile,compiled_core_sha256,core_stages,core_assertions,goal_receptors,bridge_premises,scope`,
with `Y-goal-receptor-universe-v1` / `Y-GOAL-RECEPTOR-FAMILY-v1`.
Its core hash binds the original compiled object after removing only `costs`
and `scope`; its profile equals the compiled profile. All four auxiliary lists
must be empty. No bridge premises, added assertions or imported lemmas are
accepted by this profile.

The resulting catalogue profile is exactly:

```text
kind: RF_FROZEN_SHARED_V1
slots: supplied positive integer
formula_universe_version: LITERAL_SORTED_CANONICAL_JSON_V1
zero_instance_profile: RF_COMPLETE_COMPILED_NATIVE_ZERO_V1
variables: entire original RF variable list
allow_gen: true
rf_profile: entire original compiled profile
```

Its provenance contains the original case ID, this bridge's version,
declaration/core/generation/profile hashes and a literal no-thinning scope
statement. The bridge's `compiler` provenance field identifies a representation
bridge, not a new logical compiler or proof search.

## Compact layout and model binding

The adapter retains the exact seven logical catalogue fields in the scope
preimage: `schema,statement,formulas,zeros,mp,gen,profile`. Provenance is excluded
from that logical preimage but remains covered by `catalogue_sha256`.
The preimage is:

```text
schema: Shared-fact-point-scope-v2
catalogue: the seven logical fields
slots: supplied integer
allow_padding: true
point_version: DAG-slot-ports-v2
candidate_version: DAG-candidate-v2
```

The binding fields remain
`scope,scope_preimage,slots,goal_id,catalogue_sha256,original_statement_sha256`.
The model still has exactly six fields:
`schema,version,capacity,roots,seed,inventory`, with
`schema='Z-growing-point-model-v1'`, capacity one, EXPLICIT inventory and
`version='Shared-fact-slots-active-formula-v2:'+scope`.

The model-local ports are `q:<slot>` (owner/positive point), `a:<slot>` (active
literal mark), `f:<slot>` (formula literal mark). Slots are zero-based ordinary
decimal integers. Candidate IDs are the canonical JSON plus one LF of
`[slot,kind,definition_id,refs]`. The internal `point(kind,scope,slot)` and
`row(scope,...)` signatures retain the old scope argument for call compatibility;
the compact names do not repeat it. Kinds remain `ZERO`, `MP`, `GEN`, `PAD`.

These names are local to the bound model. They are not globally unique theorem
or placement IDs. A caller must retain the whole binding/model/universe and
must not union candidates, marks or selected IDs from different scopes.
The decoder regenerates and compares the entire prepared content before using
these compact IDs. Independent model admission and driver source/file custody
remain necessary; an isolated CID does not carry a scope certificate.

Root owns any subsequent migration to its engine model-v3 with mandatory empty
`pair_nogoods` and `unary_nogoods`. This adapter neither emits nor accepts that
engine migration as its own six-field prepared packet. The driver must bind
the exact migration, preserve this original prepared packet for decoding, and
qualify its unchanged proof semantics separately.

## All rows, padding and proof interpretation

For every slot the inventory includes every native ZERO and one PAD. For each
MP definition at slot \(i\), it includes every ordered earlier reference pair
\((j,k)\), except pairs whose demands assign contradictory literal values to
the same receptor. GEN includes every earlier reference. No target-specific
ordering, selected witness, formula preference or reachability filter narrows
this inventory.

With \(L\) slots and \(Z,M,G\) respective definition counts, the adapter checks
the complete census before materialization:

\[
N_{\mathrm{potential}}=L(Z+1)+M\sum_{i=0}^{L-1}i^2+
G\sum_{i=0}^{L-1}i,
\qquad
N_{\mathrm{rows}}=N_{\mathrm{potential}}-M\sum_{i=0}^{L-1}i.
\]

The last term removes the contradictory same-reference MP tuples. The actual
generated count and conflict count must equal these formulas. Exceeding the
row cap refuses the complete preparation; it never truncates the universe.

Each selected owner contributes one positive unit at its slot center. Active
owners assign literal active value `1` and their positive formula ID; PAD
assigns both literal values `0`. An MP/GEN receptor demands the exact active
formula at its earlier slot. Literal `0` is assigned data, never a wildcard.
Every slot center is a root, and the seed pins the last slot active and equal
to the original goal. The model therefore requires one owner per slot while
allowing inactive padding elsewhere.

The decoder checks the complete selected point/mark certificate, removes PAD,
retains each remaining native line payload and remaps its earlier references
to the active native line indices. It retains the original statement, final
goal, all selected lines and a line/slot/DAG mapping. It does not compress a
proof or prove that unused active lines are necessary. \(L\) is a bound on
available proof slots, not the prior binary proof-tree height; shared earlier
facts may have several consumers. A fresh eight-slot case must not be described
as the old height-four search or as reuse of an old proof.

Compact renaming preserves this row/decoding semantics under its binding. It
does not assert identical old/new serialized traces or timing. In particular,
decimal port ordering at ten or more slots need not match old JSON port-name
ordering; a new frozen instance uses the same new layout in every compared lane.

## Resource refusals and external logical gates

Adapter default ceilings are `max_formulas=1024`, `max_rows=250000`,
`max_slots=16`, `max_zero_definitions=8000`, `max_items=500000000`,
`max_depth=128`, `wall_seconds=120.0`. Bridge ceilings are
`max_formulas=1024`, `max_zero_definitions=8000`, `max_definitions=8000`
(total ZERO plus MP plus GEN), `max_slots=16`, `max_items=500000000`,
`max_depth=128`, `wall_seconds=120.0`. Overrides may only lower ceilings.
These are cooperative Source work/wall/resource guards, not equal-cost solver
budgets; serialization and hashing are not instruction-level CPU accounting.
The caller still needs owned wall/CPU/RSS guards and separate measured stages.

Malformed input gives bridge/preparer `REJECTED_INPUT` or decoder `REJECTED`.
Resource/depth/memory refusal gives `UNKNOWN` without an admitted partial
catalogue/model. A zero or malformed bound is malformed input; a structurally
valid instance above a declared size ceiling is a resource refusal. Bool/float
IDs, slots, signature arities or references do not pass native integer checks.
Bridge success is only a representation result; native JSON syntax and exact
index equality do not prove ZERO-rule validity or finite-profile completeness.

Required independent gates are separate and all remain caller-owned:

1. Unchanged RF compiler output, prospectively frozen original declaration and
   finite-profile bounds, plus complete RF-profile reconstruction by the
   existing independent RF checker.
2. Native B checks for every ZERO line in the original closed theory.
3. Independent complete bridge reconstruction and generic shared-model
   reconstruction, checking every admitted formula/definition/reference row.
   The ground-Horn-only basis gate must not be applied as if it verified RF.
4. Exact engine migration, whole point-frontier/search certificate assurance,
   and native B verification of every returned complete decoded proof.
5. Separate solution-preservation evidence for any learned literal marking,
   unary filter, pair filter or receptor-cluster mechanism introduced later.

Suggested unchanged independent APIs are
`rf_shared_bridge_checker_v1.verify(declaration,compiled,generation,slots,packet,...)`
and generic `shared_fact_checker_v2.verify_model(catalogue,prepared,...)` /
`decode(prepared,selected,...)`; their independently authored Source and receipts
must be joined by the driver. A failed or unknown gate cannot be promoted by a
different representation's success.

This is a finite generated formula/CID palette for a frozen first-order
fragment. It is not a single finite universal Wang tile set, a proof of full PA
or Hilbert geometry, or evidence for a learned/RL performance advantage.
