# Scoped unary extra-marking layer

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No E4/C3/T3, native
kernel, learner, checker, helper or scientific Source was imported or executed.
Only authoring/static parsing is authorized in this task. Prior roots remain
immutable. The exact prior local normative master was read, \(21{,}657\) bytes,
SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`;
Root has now supplied the same reference in this new root.

Owned Sources:

- `source/unary_overlay_v1.py`: sparse synthesis and structural application.
- `source/unary_overlay_checker_v1.py`: independent data-only association and
  conditional-preservation checker; imports no overlay or scientific helper.

Both use standard-library `hashlib`, `json`, `math`, `time` only, strict native
types and cooperative work/wall guards. Defaults/ceilings are one billion
declared work units and \(120\) seconds. There is no sixteen-CID cap, subset
enumeration, exponential template search, geometry predicate or runtime CID
classifier in the marked lane.

## Model and scope

Exact model schema is `Z-growing-point-model-v3`, with precisely:
`schema,version,capacity,roots,seed,inventory,pair_nogoods,unary_nogoods`.
The inventory is EXPLICIT; every row has `id,t,m`. Positive contributions use
native integer units \(u_c\), capacity \(C\), and normalized master values
\(t_c=u_c/C\). Markings are arbitrary existing mandatory literal strings,
including formula ports and seed markings. Missing rows are unconstrained;
stored `"0"`, `""` or `"*"` are assigned literals.

The original model has both ordinary filter lists empty. The driver migrates
the original prepared point model by adding the v3 schema/empty lists and its
declared `:engine-v4` version label, without changing CIDs or positive/marking
data. `scope_sha256` is the canonical normalized migrated original model hash:
sorted-key ASCII JSON, compact separators, final LF. Roots, inventory IDs and
point rows are normalized in literal order. Every label and query binds this
whole original scope, not merely a formula or a local branch.

The prescribed fresh point is `learned:unary:guard:v1`. Its absence must be
checked against **all** original positive support, marking support, seed rows
(including zero units) and explicit roots. It is marking-only and never added
to positive support or roots. Its location is prescribed; it is not learned
geometry or a reusable prototype marking.

## Sparse learner

```python
synthesize(candidate_ids, labels, scope_sha256,
           guard_point='learned:unary:guard:v1', *,
           max_work=1000000000, wall_seconds=120)
```

`candidate_ids` is the full sorted unique list of actual compact CIDs. A label
has exactly:

```text
{cid, status: NEGATIVE|POSITIVE|UNKNOWN,
 scope_sha256, certificate_binding_sha256}
```

No formula, expected CID/color, old discovered proof or oracle solution is an
input. UNKNOWN supplies no constraint. A positive CID stays absent under the
minimum-component objective. Each admitted negative CID requires exactly one
additional assigned component: literal `"1"` at the guard, against prescribed
seed literal `"0"`. Contradictory resolved labels are rejected.

`SOLVED` output schema `Sparse-unary-overlay-synthesis-v1` contains `labels`,
`candidate_ids`, `scope_sha256`, `guard_point`, sorted `forbidden_cids`,
`extra_seed_m`, sparse `extra_assignments:[{id,m}]`, counters and scope. With no
NEGATIVE, both additional row arrays are empty: the initial, all-UNKNOWN and
pure-positive cases truly have no extra assignments. With negatives,
`extra_seed_m=[[guard,"0"]]` and only forbidden CIDs get `[[guard,"1"]]`.
Counters distinguish seed assignments, per-CID assignments and absent CIDs.
This is separable exact constraint synthesis, not enumeration of \(3^N\)
templates. Label truth is explicitly not checked by the learner.

```python
apply(base_model, synthesis, *, max_work=1000000000, wall_seconds=120)
```

Returns `CONSTRUCTED_UNVERIFIED_OVERLAY` with `marked_model` and `control_model`.
All old positive/marking data survive; the marked model adds only the sparse
guard layer, and retains empty filter lists. The ordinary control keeps all
old markings and adds exactly `forbidden_cids` to `unary_nogoods`. Pair lists
stay empty. Version labels append `:certified-unary-overlay-v1` and
`:ordinary-unary-filter-v1`. This is structural construction, not scientific
activation admission. It does not perform another synthesis run.

## Fresh fixed-CID query

Proposal acquisition can return UNKNOWN. Its first actual PLACED CID is only a
proposal; no failed-prefix inference is allowed. The driver launches a fresh
original-model fixed-CID extension query before labeling it.

The independent checker reconstructs the fixed context: locate the CID once,
add its **whole** positive contribution to original seed totals, union its
**whole** mandatory markings with original seed markings, remove precisely
that CID from the residual inventory, and keep every other row unchanged.
Roots are original roots union the chosen positive support. Old zero seed rows
remain; they do not independently become roots. Capacity overflow or a seed
mark disagreement is outside this fixed-query recipe and is rejected. The
first actual placement is compatible with the initial seed under the intended
proposal flow. The checker does not rely on that assertion instead of checking.

Seed marking unions retain agreement values; they do not pretend that the
original selected tile's physical marking-reference counts survive a new
query's initialization. This distinction does not alter cover existence.

Recommended fixed version is
`base.version+':fixed-cid:'+sha([cid])`, using canonical JSON/LF. The checker
permits a supplied version label only because the **whole** normalized fixed
model hash binds it to raw/C3 evidence. No other unbound model-field change is
allowed.

## Independent checker call and packet ABI

```python
verify(base_model, marked_model, control_model, synthesis,
       query_packets, provenance, *,
       guard_point='learned:unary:guard:v1',
       max_work=1000000000, wall_seconds=120)
```

There is one query packet in label order per learner label:

```text
{cid, label:NEGATIVE|POSITIVE|UNKNOWN, scope_sha256,
 fixed_model, raw_result, semantic_receipt, binding,
 native_receipt?, native_proof?}
```

`binding` has exactly:

```text
schema: Unary-fixed-query-binding-v1
cid, label, scope_sha256, base_model_sha256, fixed_model_sha256
raw_result_sha256, semantic_receipt_sha256
native_receipt_sha256, native_proof_sha256
evidence_refs: {model:ref,raw:ref,semantic:ref,native_receipt?:ref,native_proof?:ref}
```

The hashes refer to canonical normalized base/fixed models and complete
canonical raw/C3/native objects, not just status fields. Native hashes are null
unless label is POSITIVE. Every ref contains relative `path`, native `bytes`
and lowercase hexadecimal `sha256`, with complete capture when declared.
Compressed physical artifact hashes differ from canonical-object hashes; the
driver must verify both associations while reading actual saved objects.
The learner's `certificate_binding_sha256` is the hash of this entire binding.

A NEGATIVE requires raw complete UNSAT, exact finite-inventory reason, empty
solution output, and independent C3 `VERIFIED` with `run_status=UNSAT`, finite
exhaustion claim, complete events and `bounded_absence=true`. The checker binds
raw/C3 versions to declared pinned methods, normal model hashes, complete event
payload/hash/count, endpoints/restoration and the entire binding. UNKNOWN can
never pass as NEGATIVE. UNKNOWN labels require a C3 UNKNOWN/no-absence receipt;
even raw UNSAT or SAT without its completed assurance remains unresolved.

For generic POSITIVE support the raw query must be complete SAT and C3
VERIFIED; a fresh native proof and VERIFIED native receipt must also be present
and hashed. The external driver still binds its decoded fixed-CID union to the
original statement and checks native validity. Positives never cause pruning.
The current driver need not feed any POSITIVE label or old proof to the learner.

## Prior LABEL-phase provenance

The `learn` worker can bind a prior completed clean `label` worker, avoiding a
circular claim about its own not-yet-known exit. The exact provenance object:

```text
schema: Unary-overlay-provenance-v1
mode: FRESH_FIXED_CID_LABEL_PHASE
engine_version, semantic_version
protocol: {value:<frozen protocol JSON>, ref:<plain canonical JSON/LF ref>}
sources: {engine:ref,semantic:ref,driver:ref}
label_phase: {
  started:<actual JSON>, invocation:<actual JSON>, observer:<actual JSON>,
  result:<actual plain canonical JSON/LF result>, result_ref:ref, log_ref:ref
}
```

Protocol has `status=FROZEN_BEFORE_SCIENTIFIC_IMPORTS`, `files` and pinned
`runtime.executable`. Source refs must equal entries in `protocol.files`.
Started has `phase,pid,protocol:ref`; invocation has `phase,pid,status=COMPLETE`,
`error_type=null`, `result:ref` with `complete_json=true`, `scientific_status`,
`frozen_postcheck,postcheck_error`; observer has matching phase/PID, TERMINAL,
native integer exit zero, null guard/observer/reap/postcheck errors, the same
frozen postcheck and `log:ref`. Phase is exactly `label`.

`label_phase.result.query_bindings` contains the full binding objects for the
fresh label queries. Every packet binding must occur there canonically; a
phase can include bindings for several scopes. Result status must match the
invocation's scientific status. Canonical result/protocol byte lengths and
hashes and log-ref association are checked. The caller supplies actual objects
read from byte-pinned files, never invented process receipts.

## Admission and conditional preservation

Successful status is `VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION`. It reports
normal model bindings, all query/evidence bindings, prior-label custody joins,
forbidden/unknown counts, separate additional seed/CID counters, point-constraint
equivalence and explicit external proof obligations. If no NEGATIVE exists,
`preservation_basis=EMPTY_ADDITIONAL_LAYER_IDENTITY`; neither a guard seed nor a
pruning rule is invented. Work/time/memory refusal is UNKNOWN and admits no
activation; malformed, contradictory or unscoped evidence is REJECTED.

The supplied metatheory is conditional: a complete scoped fixed-CID UNSAT
certificate rules out that CID in every original exact cover, because any such
cover would induce a residual fixed-query cover. A fresh guard seed zero and
exactly those CID components one reject precisely the same CID list as the
ordinary unary filter, while all old mandatory data remain unchanged. The
empty-label case is the identity. No enumeration of original subsets is needed.

The pure checker **does not authenticate physical execution from JSON**. Root's
driver must verify physical source/runtime/protocol/artifact bytes and actual
started/invocation/observer/native-exit receipts, freshly execute the reviewed
C3 on the same query, and enforce phase ordering and final source postchecks.
Status, method hashes or a claimed process object alone are not a replacement.
These obligations are returned, rather than hidden behind an unconditional
preservation claim. Native truth and decoder/carrier joins remain external.

This is a finite certificate-guided unary adaptation over mandatory proof
markings, not the master browser demonstration's complete neighboring-pair
corona learning loop. One selected CID is not a complete pair catalogue, no
unresolved label becomes negative, no geometric prototype is transferred, and
no unbounded mathematical nonprovability, RL gain or search advantage follows.
