# Passive streamed-arithmetic reader

Source-only until Root reviews and executes
`publication/build_streamed_report_v1.py`. It imports only standard-library
modules, never scientific helpers. Its adaptation baseline is the unbuilt v2
reader, 53,633 bytes, SHA-256
`02fd8b1a2b04b0a9a1c44f60245015853b93a5ae51c7a2ef3a4c4551153e1048`.
No v1/v2 Source or data is changed.

Run only after reviewed saved-data admission, with the pinned isolated runtime:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/build_streamed_report_v1.py
```

## Current and prior namespaces

The current root derives from `__file__`. Its three phases are `qualify`,
`admit`, `evaluate`; protocol path remains `protocol/frozen-protocol-v1.json`,
with schema `Streamed-arithmetic-protocol-v1`. Exact current frozen file set,
review refs, runtime flags/version/binary and current master are checked.
Actual clean native processes and scientific phase admission remain distinct.
A nonnull exact invocation result ref is mandatory for admission.

`input/prior-evidence-v1.json` identifies the immutable `prior/v2` namespace.
Every original physical member's bytes/hash and the exact namespace file set
are checked. Original relative references are resolved there; original object
contents are not rewritten. Five original process records retain their actual
PIDs, protocol, statuses, costs and native exits. The v2 UNKNOWN overlay result
stays UNKNOWN/nonactivated; its missing evaluation is not filled in.

Current U3's returned custody references describe the original v2 LABEL and
continue to resolve under `prior/v2`. They do not authenticate a fabricated new
LABEL. The current ADMIT PID/protocol authenticates a separate U3 call, control
gate and model activation. The UI shows these two PIDs/protocol scopes apart.

JSON reads are bounded to 128 MiB per decompressed artifact. Relative paths
reject traversal and symlinks; runtime/master absolute pins stay outside the
relative artifact ledger. Passive canonical metadata hashes use the standard
library's incremental JSON encoder, not the scientific U3 checker. Raw engine
JSON is removed from the cache after projection to avoid retaining all large
lane payloads concurrently. No state, graph, native logic or synthesis is
replayed.

## Single saved-data gate

Required local audit:

```text
review/passive-streamed-outcomes-v1.json
schema: Streamed-arithmetic-passive-audit-v1
status: PASS_SAVED_STREAMED_OUTCOMES_WITH_EXPLICIT_SCOPES
```

Its current protocol must match exactly. Current phase PID/native exit/science/
process-clean/admission fields are joined to `audit.phases`; original phase
PID/native exit/science/admission fields join `audit.prior.phases`. Every
displayed proof joins `audit.native_proofs` by ID and role, line count, original
statement/selection/proof hashes and proof/native references. Ref comparison
uses path, bytes, SHA-256 and optional JSON pointer. Audit PASS means saved-data
associations passed, never assumed successful proof search.

Missing/UNKNOWN/failed stages stay explicit. No active layer is displayed until
current admission, all five actual applied controls and exact model hashes are
admitted. A constructed prior candidate is not an old successful activation.

## Reader data

Output `report/streamed-arithmetic-data-v1.json.gz` is deterministic gzip of
canonical ASCII JSON plus LF. Schema is `Streamed-arithmetic-reader-data-v1`,
status `PASS_PASSIVE_SAVED_DATA_PROJECTION`. Main fields:

- `phases`: current three process/scientific records, worker/observer intervals,
  actual native high-water RSS, refs and admission booleans.
- `history`: exact prior namespace/manifest/file count/protocol, original five
  processes, prior physical/logical qualification counts, original U2 resource
  refusal and explicit zero new labels/synthesis/old-target-proof inputs.
- `declaration`, `prepare`, `label`: unchanged seen arithmetic statement,
  reused full RF/model census and native ZERO history, reused scoped finite
  negative with witness/coverage/binding and original namespace. These are not
  new compilation or label discoveries.
- `authentication`, `authentication_ref`: actual current warm-authentication
  receipt when available, with separate current and original protocols.
- `learning_candidate`, `learning`: actual current U3 output/metrics and the
  reused candidate. `learning` is populated only after current U3, five control
  and exact model-binding gates; otherwise the candidate remains unactivated.
- `public_controls`: current calls on deliberately mutated copies of the
  authenticated old query/provenance, never learner labels or genuine mutant
  executions. Partial controls remain partial.
- `qualification`: current SHA corpus/refusal records plus the current rerun
  of the previously declared private equality corpus. No new physical engine
  graph or native-proof qualification is inferred.
- `lanes`: only actual admitted fresh BASE/MARKS/FILTER records in fixed order,
  with raw/semantic/native/UNKNOWN scopes, costs, statistics and first/last
  retained event samples. Samples do not reconstruct omitted suffixes.
- `proofs`: reused prior qualifiers and any actual newly searched/native-checked
  evaluation proofs; original ASTs, literal selected rows, slots, earlier refs,
  statement identity and complete native checks are preserved.
- `saved_data_audits`, `protocol`, `provenance`, `scope`, `costs_scope`.

Proof IDs align with the audit:

| ID | Role |
|---|---|
| `prior-qual-<logical case id>` | `REUSED_PRIOR_QUALIFICATION` |
| `arith-BASE`, `arith-MARKS`, `arith-FILTER` | `EVALUATION` |

Each includes `audit_id`, `line_count`, statement/selection hashes, proof/native
refs and actual engine assurance. Reused proof references point under
`prior/v2`; a decoded packet can carry pointer `/proof`. No old arithmetic
target proof exists or is read as search input. New proof display requires an
actual C-verified SAT, exact actual selection, both M/N projections and whole
native B check. A found target proof is prioritized. Unresolved current lanes have explicit
no-proof choices that clear the diagram and proof rows; prior qualifiers remain
separate choices labeled reused, not new or arithmetic-target results.

Huge universes/full raw streams and repeated candidate lists stay in the full
physical archive, not duplicated into public reader data. There are no
individual download copies or separate evidence HTML.

## Outputs, visuals and publication

All output files use exclusive creation:

- `report/streamed-arithmetic-v1.html`.
- `report/streamed-arithmetic-data-v1.json.gz`.
- `report/build-receipt-v1.json`, schema
  `Streamed-arithmetic-passive-build-v1`, status
  `PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`.

The archive-only build receipt retains `outputs:{main,data}`, renderer Source,
protocol, phases, artifact pins and scope. Main anchors are `#reader` and
`#evidence`; there is one marker before the evidence section:

```html
<!-- STREAMED_ARITHMETIC_ARCHIVE_LINK -->
```

Root/Oracle own marker-only archive insertion, original-render preservation,
final UI, archive and deployment. Archive names are
`streamed-arithmetic-evidence-v1-part-NNN.zip` and
`streamed-arithmetic-evidence-manifest-v1.json`; prior navigation/backlink is
the published `quantified-markings-v1.html` in the existing destination.

The reader retains serialized MathJax typesetting, original/literal names,
display-only qualifier aliases, fixed proof-table widths and overflow handling,
orange activity/purple formula/blue-red guard layers, actual remote references,
proof-line/slot buttons and empty-proof clearing. Phase high-water RSS comes
from native worker measurements, not the possibly missed polling sample.
Prior and current costs remain separately visible; overlapping intervals and
v3/v2 work counters must not be summed or treated as equal units. No cold speed,
distinctive GCTS/RL advantage, new theorem, full PA/induction, geometric transfer
or universal finite Wang proof search follows merely from admission or pruning.
