# Streamed arithmetic publication preparation

Source-only handoff: `publication/package_streamed_v1.py`, 37,486 bytes, SHA256 `6616e32444215554d88e63b0b5f3e1728a799dfe71e59d594fd961332149c728`. Root must read the complete Source and peer review before invoking it. No import, build, package, Git/network action or scientific call was performed by its author; syntax parsing and saved metadata reads only.

The immutable adaptation baseline is V2 `publication/package_quantified_v2.py`, 35,316 bytes, SHA256 `e5afa2c7f8b6d7d457b746a92813db0b59a321b2cf03efdeba5d0676cd92ab85`. The full and compact zero-context patches both contain every textual change, not selected subsets.

## Commands and order

Use the protocol's pinned executable and flags:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_streamed_v1.py --prepare-links
```

This verifies saved gates, preserves `publication/rendered-before-archive-links-v1.html`, writes the README and fills only `<!-- STREAMED_ARITHMETIC_ARCHIVE_LINK -->` through its generated end marker. A volume-count fixed point is saved in `publication/archive-plan-v1.json`; a differing prior plan is retained. No network/Git action occurs here. Afterward, Root must run final UI on these exact postlink bytes and write the final admission below.

Root must fetch the current official `main` into the existing isolated bare repository before the next command. Then:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_streamed_v1.py EXPECTED_REMOTE_MAIN_SHA
```

The optional final argument is a reviewed expected SHA. When omitted, Root intentionally accepts the official main discovered by this invocation. The tool performs an official GitHub GET of `git/ref/heads/main`, checks a supplied SHA if present, and rechecks that remote base immediately before local commit preparation. No fixed parent is assumed, and the tool never fetches, pushes or updates a branch. A missing local commit or changed remote stops it.

## Exact final UI and admission skeletons

`publication/local-ui-v1.json` must minimally contain the following; replace illustrative pins with actual postlink observations. Additional screenshot/observation fields are allowed.

```json
{
  "status":"PASS_LOCAL_UI",
  "source":{"path":"report/streamed-arithmetic-v1.html","bytes":0,"sha256":"ACTUAL_POSTLINK_SHA256"},
  "math_errors":0,
  "body_overflow":false,
  "fatal":"",
  "console":[]
}
```

The actual byte size must be a native integer; zero is only a placeholder. Root's separate final file is `publication/root-publication-admission-v1.json`. Its enforced status is shown below. Every relative `{path,bytes,sha256}` reference anywhere inside it is checked. These exact ten paths must occur; additional reviewed references are allowed. `schema` and `scope` are documentary fields.

```json
{
  "schema":"Root-streamed-publication-admission-v1",
  "status":"PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES",
  "reviewed":[
    {"path":"protocol/frozen-protocol-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"report/streamed-arithmetic-v1.html","bytes":0,"sha256":"ACTUAL_POSTLINK_SHA256"},
    {"path":"report/streamed-arithmetic-data-v1.json.gz","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"publication/build_streamed_report_v1.py","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"publication/package_streamed_v1.py","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"review/passive-streamed-outcomes-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"publication/local-ui-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"report/build-receipt-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"review/root-passive-publication-admission-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"},
    {"path":"input/prior-evidence-v1.json","bytes":0,"sha256":"ACTUAL_SHA256"}
  ],
  "scope":"Reviewed publication bytes; warm certificate admission and explicit search UNKNOWN, not a target-proof or speed claim."
}
```

The before-build Root admission remains separate and must retain schema `Root-passive-publication-admission-v1` / status `PASS_SOURCE_READ_AND_SAVED_DATA_AUDIT_BEFORE_BUILD`. Final UI/admission must be regenerated if link replanning changes HTML bytes.

## Enforced saved-data scope

The protocol is exactly 11,384 bytes / `c655acf4b9d29baed447591fcdda37d4c5bca51fbe38685b8a67878c0742487a`, schema `Streamed-arithmetic-protocol-v1`, status `FROZEN_BEFORE_SCIENTIFIC_IMPORTS`. The complete dynamic frozen file set, current runtime/isolation and current master/reference bytes must match. All three current process positions are joined by phase/PID/protocol/log/result/native exit/postcheck; scientific admission follows actual status plus clean process, not a workflow name alone.

Required passive products:

- `review/passive-streamed-outcomes-v1.json`: `Streamed-arithmetic-passive-audit-v1` / `PASS_SAVED_STREAMED_OUTCOMES_WITH_EXPLICIT_SCOPES`;
- `report/build-receipt-v1.json`: `Streamed-arithmetic-passive-build-v1` / `PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD`;
- public data: `Streamed-arithmetic-reader-data-v1` / `PASS_PASSIVE_SAVED_DATA_PROJECTION`.

Report phases, activation and the entire native proof collection must match the audit. Proof roles, statement/selection hashes, saved whole proof (`/proof` pointer supported), line counts and native receipts are bound. Prior qualification proofs stay `REUSED_PRIOR_QUALIFICATION`. The actual three fresh lanes returned raw/semantic `UNKNOWN` at their wall limits, with no target proof. Complete emitted prefix bytes are not completed proof/refutation certificates. No new failure label or synthesis, cold speed comparison, RL gain or universal Wang proof search is claimed; the broader program remains ACTIVE.

All 388 sorted unique paths from `input/prior-evidence-v1.json` must physically exist byte-exact under `prior/v2`, with no extra physical path. Other predecessor archives remain separately linked.

## Archive, Git and outputs

Every original current-run file present at the cut is physically stored exactly once under its own relative path, including equal-byte copies, all 388 prior files, Sources, raw UNKNOWN data, logs, local paths, reviews and publication Sources. Before cutting, the predecessor backlink is materialized at `publication/previous-report-with-backlink-v1.html`, so its bytes are also archived. Only generated `package/` outputs are excluded; index/prepared/push/Pages/live receipts created later are explicitly postcut custody.

Each ZIP is at most 44 MiB and strictly below 50 MiB. Every volume includes the complete `ARCHIVE-file-manifest-v1.json`. All members, CRCs, sizes, SHA256, exact path sets and physical coverage are read back and checked. Cut bytes/set are rechecked before Git. No alias deduplication or remote reference substitutes for originals. A changed final volume count refuses preparation before a cut; Root must replan and renew UI/admission.

Destination prefix is `docs/research/gcts-rl-renewal/conditional-inventory/`. Only `quantified-markings-v1.html` may be modified, with one backlink. Additions are main/data, `streamed-arithmetic-evidence-manifest-v1.json`, and `streamed-arithmetic-evidence-v1-part-NNN.zip`. Existing new-path collisions refuse. The isolated bare Git is `/private/tmp/gcts-history-publication-20261102-v1.git`, index `publication/index-v1`; no primary checkout/index is touched. Exact sole parent/tree/name-status diff must contain only these assets. No push is performed.

Success writes `publication/prepared-v1.json`, status `PREPARED_TASK_ASSETS_ONLY`, with base/tree/commit, all asset pins/URLs/blobs, archive verification/readiness and `pushed:false`. Existing `package/`, prepared receipt or isolated index refuses a retry over earlier bytes. Root separately owns push, official remote/Pages checks, full live-body/volume-byte verification and mirroring.
