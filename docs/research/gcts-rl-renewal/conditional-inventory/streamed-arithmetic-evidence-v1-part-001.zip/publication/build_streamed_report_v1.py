"""Passive QMT saved-data reader. Never import scientific modules or replay.

Read frozen protocol/file/process pins and actual completed/refused phase
outputs. A missing/stopped phase is displayed, not replaced with a proof.
Root reviews Source before executing this assembler/renderer.
"""
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'report'
PROTOCOL='protocol/frozen-protocol-v1.json'
PHASES=['qualify','admit','evaluate']
SEMANTIC=['statement','proof','slots','slot_to_native','native_to_slot','reference_mapping',
          'proof_dag','selected','selected_sha256','original_statement_sha256','scope']
LEDGER={};CACHE={};PRIOR={};BOUND=134217728
PREFIX='prior/v2/'


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def sha(x):
    h=hashlib.sha256();n=0
    for text in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(x):
        raw=text.encode('ascii');n+=len(raw);need(n<BOUND,'PASSIVE_METADATA_HASH_BOUND');h.update(raw)
    h.update(b'\n');return h.hexdigest()
def same(a,b,why):need(wire(a)==wire(b),why)


def bytepin(p):
    h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
    return dict(bytes=n,sha256=h.hexdigest())


def local(name):
    need(type(name) is str and bool(name),'RELATIVE_PATH');p=Path(name)
    need(not p.is_absolute() and '..' not in p.parts,'ROOT_PATH')
    out=ROOT
    for part in p.parts:out=out/part;need(not out.is_symlink(),'NO_SYMLINK')
    need(out.resolve().is_relative_to(ROOT),'ROOT_CONTAINMENT');return out


def pin(name):
    value=dict(path=name,**bytepin(local(name)));LEDGER[name]=value;return value


def read(name,reference=None):
    value=pin(name)
    if reference is not None:
        same(value,{k:reference[k] for k in ('path','bytes','sha256')},'EXACT_SAVED_BYTES:'+name)
        need(reference.get('complete_json',True) is True,'COMPLETE_SAVED_JSON')
    if name not in CACHE:
        p=local(name)
        with gzip.open(p,'rb') if p.suffix=='.gz' else p.open('rb') as f:b=f.read(BOUND+1)
        need(len(b)<=BOUND,'JSON_READ_BOUND');CACHE[name]=json.loads(b)
    return CACHE[name]


def projected(ref,prefix=''):
    if not prefix:return ref
    need(prefix==PREFIX and ref['path'] in PRIOR,'EXACT_PRIOR_REFERENCE')
    same({k:ref[k] for k in ('bytes','sha256')},{k:PRIOR[ref['path']][k] for k in ('bytes','sha256')},'PRIOR_MANIFEST_REFERENCE')
    return dict(ref,path=prefix+ref['path'])


def checked(ref,prefix=''):return read(projected(ref,prefix)['path'],projected(ref,prefix))


def refs_in(value,prefix=''):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=value.keys():
            r=projected(value,prefix)
            same(pin(r['path']),{k:r[k] for k in ('path','bytes','sha256')},'ALL_SAVED_REF_BYTES')
            need(r.get('complete_json',True) is True,'ALL_CAPTURE_REFS_COMPLETE')
        else:
            for v in value.values():refs_in(v,prefix)
    elif type(value) is list:
        for v in value:refs_in(v,prefix)


def project_refs(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=value.keys():return projected(value,PREFIX)
        return {k:project_refs(v) for k,v in value.items()}
    if type(value) is list:return [project_refs(v) for v in value]
    return value


def environment():
    p=read(PROTOCOL);need(p['schema']=='Streamed-arithmetic-protocol-v1' and p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_PROTOCOL')
    a=read('review/root-source-admission-v1.json');need(a['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix!='.pyc' and '__pycache__' not in path.parts,'NO_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for ref in a['reviewed']:
        same(pin(ref['path']),{k:ref[k] for k in ('path','bytes','sha256')},'REVIEW_PIN');names.add(ref['path'])
    same([pin(n) for n in sorted(names)],p['files'],'EXACT_FROZEN_SET')
    executable=Path(sys.executable).resolve()
    runtime=dict(executable=dict(path=str(executable),**bytepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    need(sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'ISOLATED_PINNED_RUNTIME')
    same(runtime,p['runtime'],'CURRENT_RUNTIME')
    master=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
    same(dict(path=str(master),**bytepin(master)),p['master'],'CURRENT_MASTER')
    return p,dict(runtime=runtime,master=p['master'],frozen_files=len(names))


def phase(name,protocol,prefix=''):
    paths=dict(result=prefix+'data/'+name+'/result.json',started=prefix+'run/'+name+'/started.json',
        invocation=prefix+'run/'+name+'/invocation.json',observer=prefix+'run/'+name+'/observer.json')
    values={k:read(n) for k,n in paths.items() if local(n).exists()}
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    state='NOT_RUN' if not values else 'IN_PROGRESS_OR_INCOMPLETE';clean=False
    protocol_ref=pin(prefix+PROTOCOL)
    expected_protocol=dict(protocol_ref,path=PROTOCOL)
    if s is not None:same(s['protocol'],expected_protocol,'STARTED_PROTOCOL');need(s['phase']==name,'STARTED_PHASE')
    if i is not None:need(i['phase']==name,'INVOCATION_PHASE')
    if o is not None:
        need(o['phase']==name,'OBSERVER_PHASE')
        same(projected(o['log'],prefix),pin(prefix+'run/'+name+'/stdout.log'),'OWNED_LOG_BYTES')
        state='FAILED_OR_STOPPED_PROCESS'
    if s is not None and i is not None and o is not None:
        need(all(type(x['pid']) is int and x['pid']>0 for x in (s,i,o)) and s['pid']==i['pid']==o['pid'],'PHASE_PID')
        if i.get('result') is not None:
            same(checked(i['result'],prefix),result,'EXACT_PHASE_RESULT_BYTES')
            need(i['scientific_status']==result['status'],'INVOCATION_SCIENCE_STATUS')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None and i.get('result') is not None
            and result is not None and i.get('scientific_status')==result['status']
            and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==protocol['status'])
        state='CLEAN_RECORDED_PHASE' if clean else 'FAILED_OR_STOPPED_PROCESS'
    if result is not None:refs_in(result,prefix)
    record=dict(name=name,namespace=prefix or 'CURRENT_ROOT',process_status=state,
        pid=None if o is None else o['pid'],native_exit_code=None if o is None else o['native_exit_code'],
        process_clean=clean,scientific_status=None if result is None else result['status'],
        worker_seconds=None if i is None else i['seconds'],observer_seconds=None if o is None else o['seconds'],
        worker_highwater_rss_bytes=None if i is None else i['maxrss']*(1 if i['maxrss_units']=='bytes' else 1024),
        guard_reason=None if o is None else o['guard_reason'],error=None if i is None else i['error_type'],
        protocol_ref=protocol_ref,refs={k:pin(n) for k,n in paths.items() if k in values})
    record['admitted']=clean and result is not None and result['status']==protocol['admitted_statuses'][name]
    return record,result


def event_sample(raw):
    events=raw.get('events',[]);indices=sorted(set(range(min(12,len(events))))|set(range(max(0,len(events)-12),len(events))))
    out=[]
    for index in indices:
        e=json.loads(wire(events[index]))
        if e['kind']=='BRANCH':
            d=e['data'];e['data']=dict(generation=d['generation'],legal_count=len(d['legal']),
                order_count=len(d['order']),first_candidate=d['order'][0])
        out.append(e)
    return dict(records=out,retained_payload_rows=len(events),emitted_total=raw['event_extent']['total'],
                scope='First/last retained event sample; last retained is not an omitted suffix. Full original domains and payloads remain in the archive.')


def engine_summary(refs):
    raw=checked(refs['raw']);CACHE.pop(refs['raw']['path'],None);c=checked(refs['semantic'])
    if c['status']=='VERIFIED':
        need(raw['status']==c['run_status'] and c['event_coverage']=='COMPLETE','SEMANTIC_RAW_JOIN')
        same(c['event_sha256'],raw['event_extent']['sha256'],'SEMANTIC_EVENT_BINDING')
        same(c['model_sha256'],raw['model_sha256'],'SEMANTIC_MODEL_BINDING')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'EXACT_ABSENCE_SCOPE')
    else:need(c['bounded_absence'] is False,'NO_UNKNOWN_ABSENCE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c['reason'],bounded_absence=c['bounded_absence'],stats=raw['stats'],
        event_extent=raw['event_extent'],rollback_extent=raw['rollback_extent'],sample=event_sample(raw),
        selected=raw['selected'],refs=refs,producer_intermediate_bookkeeping='NOT_OBSERVED_IN_LARGE_RUN')


def proof_record(identifier,kind,label,m,n,b,model,refs,catalogue,aliases):
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE' and b['status']=='VERIFIED','ONLY_ADMITTED_PROOFS')
    for k in SEMANTIC:same(m[k],n[k],'TWO_NATIVE_PROJECTIONS:'+k)
    same(b['checked_lines'],len(m['proof']),'WHOLE_NATIVE_PROOF_COUNT')
    same(sha(m['statement']),m['original_statement_sha256'],'PROOF_ORIGINAL_STATEMENT')
    byid={x['id']:x for x in model['inventory']['placements']}
    need(all(cid in byid for cid in m['selected']),'SELECTED_LITERAL_ROWS')
    proof_ref=refs.get('native_proof')
    if proof_ref is None:proof_ref=dict(refs['decoded'],pointer='/proof')
    native_ref=refs.get('native_receipt',refs.get('native'))
    need(native_ref is not None,'EXACT_NATIVE_RECEIPT_REFERENCE')
    return dict(id=identifier,audit_id=identifier,role='QUALIFICATION' if kind=='QUALIFICATION' else 'EVALUATION',
        kind=kind,label=label,statement=m['statement'],proof=m['proof'],slots=m['slots'],
        line_count=len(m['proof']),statement_sha256=m['original_statement_sha256'],selected_sha256=m['selected_sha256'],
        proof_ref=proof_ref,native_ref=native_ref,
        native_to_slot=m['native_to_slot'],slot_to_native=m['slot_to_native'],reference_mapping=m['reference_mapping'],
        proof_dag=m['proof_dag'],selected_rows=[byid[c] for c in m['selected']],
        native_status=b['status'],aliases=aliases,scope=m['scope'],refs=refs,
        formula_lookup={str(x['formula_id']):catalogue['formulas'][x['formula_id']-1]
                        for x in m['slots'] if x['formula_id']>0})


def synthesis_projection(s):
    # The complete CID list stays in the original artifact; no candidate is
    # removed from the scientific model or replaced in its evidence.
    return {k:v for k,v in s.items() if k!='candidate_ids'}


def positive_engine(refs,selected):
    raw=checked(refs['raw']);CACHE.pop(refs['raw']['path'],None);c=checked(refs['semantic'])
    need(raw['status']=='SAT' and c['status']=='VERIFIED' and c['run_status']=='SAT'
        and c['claim']=='SEMANTIC_COMPLETE_SAT_CERTIFICATE' and c['event_coverage']=='COMPLETE'
        and c['bounded_absence'] is False,'ONLY_ACTUAL_SEMANTIC_POSITIVES')
    same(c['model_sha256'],raw['model_sha256'],'POSITIVE_ENGINE_MODEL_BINDING')
    same(c['event_sha256'],raw['event_extent']['sha256'],'POSITIVE_ENGINE_EVENT_BINDING')
    same(selected,raw['selected'],'ACTUAL_SELECTED_NATIVE_PROOF')
    return dict(raw_status=raw['status'],semantic_status=c['status'],claim=c['claim'],
                model_sha256=c['model_sha256'],event_sha256=c['event_sha256'])


def equality_projection(q):
    e=checked(q['equality_qualification']) if 'path' in q['equality_qualification'] else q['equality_qualification'];need(e['status']=='QUALIFIED_CANONICAL_EQUALITY_PRIMITIVE','PRIVATE_EQUALITY_QUALIFIED')
    declared=read('input/overlay-equality-qualification-v1.json')
    cases=[];refusals=[]
    same([r['id'] for r in e['cases']],[r['id'] for r in declared['valid_pairs']+declared['recipes']],'EXACT_PRIVATE_EQUALITY_CASES')
    same([r['id'] for r in e['refusals']],[r['id'] for r in declared['refusals']],'EXACT_PRIVATE_EQUALITY_REFUSALS')
    for row in e['cases']:
        value=checked(row['receipt']);same(value['id'],row['id'],'SAVED_EQUALITY_ID')
        same(value['reference']['relation'],row['relation'],'SAVED_EQUALITY_RELATION')
        cases.append(dict(id=row['id'],reference=value['reference'],actual=value['actual'],ref=row['receipt']))
    for row in e['refusals']:
        value=checked(row['receipt']);same(value['declaration']['id'],row['id'],'SAVED_REFUSAL_ID')
        same(value['actual']['status'],row['status'],'SAVED_REFUSAL_STATUS')
        refusals.append(dict(id=row['id'],actual=value['actual'],ref=row['receipt']))
    same(e['private_primitive_calls'],len(cases)+len(refusals),'PRIVATE_CALL_CENSUS')
    return dict(status=e['status'],cases=cases,refusals=refusals,private_primitive_calls=e['private_primitive_calls'],
        public_positive_calls=e['public_positive_calls'],scope=e['scope'])


def control_projection(result):
    declared=read('input/overlay-equality-qualification-v1.json')['public_after_label_mutants']
    aggregate=None
    if result is not None and 'activation_controls' in result.get('refs',{}):
        aggregate=checked(result['refs']['activation_controls'])
        refs_in(aggregate)
        same([r['id'] for r in aggregate['controls']],[r['id'] for r in declared],'EXACT_PUBLIC_CONTROL_IDS')
    rows=[]
    byid={} if aggregate is None else {r['id']:r for r in aggregate['controls']}
    for spec in declared:
        row=byid.get(spec['id']);path='data/learn/controls/'+spec['id']+'-receipt.json'
        if row is not None and row['status']=='NOT_APPLICABLE_LABEL_PROFILE':
            rows.append(dict(row,expected=spec['expected'],expected_reason=spec['expected_reason']));continue
        ref=row.get('receipt') if row is not None else pin(path) if local(path).exists() else None
        if ref is None:continue
        value=checked(ref)
        if row is not None:
            same(value['status'],row['status'],'PUBLIC_CONTROL_STATUS_JOIN')
            same(value.get('reason'),row.get('reason'),'PUBLIC_CONTROL_REASON_JOIN')
        rows.append(dict(id=spec['id'],status=value['status'],reason=value.get('reason'),
            expected=spec['expected'],expected_reason=spec['expected_reason'],
            activation_admitted=value.get('activation_admitted'),work=value.get('work'),
            comparison_metrics=value.get('comparison_metrics'),ref=ref,
            call_seconds=None if row is None else row.get('call_seconds')))
    return dict(status=None if aggregate is None else aggregate['status'],rows=rows,
        scope='Current U3 calls on deliberately mutated copies of authenticated prior V2 query objects; never new labels or authentic executions of those mutants.')


def prior_history():
    manifest=read('input/prior-evidence-v1.json')
    need(manifest['schema']=='Streamed-arithmetic-prior-evidence-v1' and manifest['namespace']=='prior/v2','EXACT_PRIOR_NAMESPACE')
    same(manifest['target_proofs'],0,'NO_PRIOR_TARGET_PROOF_INPUT')
    names=[]
    for ref in manifest['files']:
        need(ref['path'] not in PRIOR,'DISTINCT_PRIOR_MEMBER');PRIOR[ref['path']]=ref;names.append(ref['path'])
        checked_ref=projected(ref,PREFIX);same(pin(checked_ref['path']),{k:checked_ref[k] for k in ('path','bytes','sha256')},'EVERY_PRIOR_FILE_BYTE_PIN')
    actual=[]
    for p in local(PREFIX).rglob('*'):
        need(not p.is_symlink(),'NO_PRIOR_SYMLINK')
        if p.is_file():actual.append(p.relative_to(local(PREFIX)).as_posix())
    same(sorted(actual),sorted(names),'EXACT_PRIOR_PHYSICAL_FILE_SET')
    need(not any(n.startswith(('data/evaluate/','run/evaluate/','data/label/fixed-union-native/')) for n in names),'NO_REUSED_TARGET_PROOF')
    old=checked(PRIOR[PROTOCOL],PREFIX);same(pin(PREFIX+PROTOCOL)['sha256'],manifest['protocol_sha256'],'ORIGINAL_V2_PROTOCOL')
    phases=[];results={}
    for name in ('qualify','prepare','acquire','label','learn'):
        record,value=phase(name,old,PREFIX);need(record['process_clean'],'CLEAN_RETAINED_V2_PROCESS')
        phases.append(record);results[name]=value
    need(results['learn']['status']=='UNKNOWN' and not phases[-1]['admitted'],'PRESERVE_V2_SCIENTIFIC_REFUSAL')
    p=results['prepare'];prepared=checked(p['refs']['prepared'],PREFIX);base=checked(p['refs']['model'],PREFIX)
    same(prepared['statement'],read('input/arithmetic-declaration-v1.json')['problem'],'SAME_SEEN_ARITHMETIC_STATEMENT')
    same(sha(base),p['scope_sha256'],'RETAINED_BASE_SCOPE')
    s=checked(results['learn']['refs']['synthesis'],PREFIX);o=checked(results['learn']['refs']['overlay'],PREFIX)
    old_u=checked(results['learn']['refs']['overlay_receipt'],PREFIX)
    need(s['status']=='SOLVED' and o['status']=='CONSTRUCTED_UNVERIFIED_OVERLAY'
        and old_u['status']=='UNKNOWN' and old_u.get('activation_admitted') is False,'AUTHENTIC_UNACTIVATED_V2_CANDIDATE')
    l=results['label'];packet=checked(l['query_packets_ref'],PREFIX);binding=packet['binding'];c=packet['semantic_receipt']
    need(packet['label']=='NEGATIVE' and c['status']=='VERIFIED' and c['bounded_absence'] is True
        and c['event_coverage']=='COMPLETE' and c['claim']=='SEMANTIC_COMPLETE_FINITE_EXHAUSTION','RETAINED_CERTIFIED_NEGATIVE_ONLY')
    same(sha(packet['raw_result']),binding['raw_result_sha256'],'PRIOR_RAW_QUERY_OBJECT')
    same(sha(c),binding['semantic_receipt_sha256'],'PRIOR_QUERY_RECEIPT_OBJECT')
    same(sha(packet['fixed_model']),binding['fixed_model_sha256'],'PRIOR_FIXED_MODEL_OBJECT')
    same(s['labels'],l['labels'],'REUSED_LABELS_NOT_RELEARNED')
    label_info=dict(cid=packet['cid'],label=packet['label'],scope_sha256=packet['scope_sha256'],
        semantic_status=c['status'],semantic_reason=c['reason'],bounded_absence=c['bounded_absence'],
        binding=binding,binding_namespace='prior/v2',refs=project_refs(l['refs']),costs=l['costs'],
        dead_context_witnesses=c.get('dead_context_witnesses',[]),dead_witness_coverage=c.get('dead_witness_coverage'),
        event_extent=packet['raw_result']['event_extent'],role='REUSED_PRIOR_FAILURE_NOT_NEW_LABEL')
    CACHE.pop(PREFIX+l['query_packets_ref']['path'],None)
    proofs=[];q=results['qualify']
    for item in q['logical']:
        refs=project_refs(item['refs']);ep=project_refs(item['engine']['refs']);pr=checked(refs['prepared'])
        m=checked(refs['decoded']);n=checked(refs['independent_decoded']);b=checked(refs['native'])
        assurance=positive_engine(ep,m['selected'])
        proof=proof_record('prior-qual-'+item['id'],'QUALIFICATION','Reused prior qualification · '+item['id'],m,n,b,pr['model'],refs,pr['catalogue'],{'qqualx':'x','qqualP':'P','qqualQ':'Q'})
        proof.update(role='REUSED_PRIOR_QUALIFICATION',reused=True,namespace='prior/v2',engine_assurance=assurance,engine_refs=ep)
        proofs.append(proof)
    prepare_info=dict(case_id=p['case_id'],slots=p['slots'],scope_sha256=p['scope_sha256'],
        census=p['census'],ZERO_checks=p['ZERO_checks'],costs=p['costs'],refs=project_refs(p['refs']),warm_reused=True,
        mandatory_mark_rows=sum(len(r['m']) for r in base['inventory']['placements']),seed_mark_rows=len(base['seed']['m']))
    history=dict(namespace='prior/v2',manifest=pin('input/prior-evidence-v1.json'),physical_files=len(names),
        protocol=pin(PREFIX+PROTOCOL),phases=phases,prior_qualification_counts=q['counts'],
        old_overlay_admission=old_u,old_overlay_ref=projected(results['learn']['refs']['overlay_receipt'],PREFIX),
        prior_target_proofs=0,prior_overlay_activated=False,new_labels=0,new_synthesis_calls=0,
        scope='Historical V2 preparation, failure and unactivated synthesis; five actual old native processes, not current executions.')
    return history,prepared,base,s,o,label_info,proofs,prepare_info


def streamed_qualification(result):
    equality=equality_projection(result);cases=[];controls=[]
    for row in result['hash_cases']:
        v=checked(row['receipt']);same(v['id'],row['id'],'CURRENT_HASH_CASE_ID')
        same(v['actual']['digest'],v['reference_sha256'],'SAVED_HASH_REFERENCE_JOIN')
        same(v['reference_sha256'],row['reference_sha256'],'HASH_SUMMARY_REFERENCE_JOIN')
        cases.append(dict(id=row['id'],status=v['actual']['status'],reference_sha256=v['reference_sha256'],
            reference_bytes=v['reference_bytes'],actual=v['actual'],ref=row['receipt']))
    for row in result['hash_controls']:
        v=checked(row['receipt']);same(v['id'],row['id'],'CURRENT_HASH_CONTROL_ID')
        same(v['actual']['status'],row['status'],'HASH_CONTROL_STATUS_JOIN')
        need(v['actual']['digest'] is None,'REFUSAL_HAS_NO_DIGEST')
        controls.append(dict(id=row['id'],actual=v['actual'],ref=row['receipt']))
    same(result['counts']['successful_hash_calls'],len(cases),'ACTUAL_HASH_CALL_CENSUS')
    same(result['counts']['hash_refusal_calls'],len(controls),'ACTUAL_HASH_CONTROL_CENSUS')
    return dict(counts=result['counts'],equality=equality,hash_cases=cases,hash_controls=controls,scope=result['scope'])


def assemble():
    protocol,external=environment();phases=[];results={}
    for name in PHASES:
        record,value=phase(name,protocol);phases.append(record);results[name]=value
    admitted={p['name']:p['admitted'] for p in phases}
    history,prepared,base,synthesis,overlay,label_info,proofs,prepare_info=prior_history()
    declaration=read('input/arithmetic-declaration-v1.json')
    aliases={declaration['names'][k]:v for k,v in dict(S='S',add='add',x='x',zero='0').items()}
    qualification=streamed_qualification(results['qualify']) if admitted['qualify'] else None
    a=results['admit'];ar={} if a is None else a.get('refs',{})
    uref=ar.get('overlay_receipt')
    if uref is None and local('data/admit/overlay-admission.json.gz').exists():uref=pin('data/admit/overlay-admission.json.gz')
    u=None if uref is None else checked(uref)
    authref=ar.get('prior_authentication')
    if authref is None and local('data/admit/prior-authentication.json').exists():authref=pin('data/admit/prior-authentication.json')
    authentication=None if authref is None else checked(authref)
    if authentication is not None:
        need(authentication['namespace']=='prior/v2' and authentication['status']=='AUTHENTICATED_PRIOR_V2_WARM_INPUT','WARM_AUTHENTICATION_NAMESPACE')
        same(authentication['current_protocol'],pin(PROTOCOL),'AUTHENTICATION_CURRENT_PROTOCOL')
        same(authentication['prior_protocol'],history['protocol'],'AUTHENTICATION_PRIOR_PROTOCOL')
    controls=control_projection(a)
    candidate=dict(synthesis=synthesis_projection(synthesis),overlay_status=overlay['status'],admission=u,
        activated=admitted['admit'],scientific_status=None if a is None else a['status'],
        stopped_stage=None if a is None else a.get('stopped_stage'),reason=None if a is None else a.get('reason'),
        frozen_checker_max_work=protocol['limits']['scientific']['overlay']['max_work'],
        comparison_metrics=None if u is None else u.get('comparison_metrics'),custody_namespace='prior/v2',
        reused=True,old_admission=history['old_overlay_admission'])
    learning=None;lanes=[]
    if admitted['admit']:
        need(u['status']=='VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION'
            and u['version']=='Independent-scoped-unary-overlay-checker-v3','ACTUAL_CURRENT_U3_ADMISSION')
        need(controls['status']=='PASS_ACTUAL_QUERY_ACTIVATION_CONTROLS' and len(controls['rows'])==5,'ALL_ACTUAL_CONTROLS_BEFORE_ACTIVATION')
        for row in controls['rows']:
            same(row['status'],row['expected'],'ACTUAL_CONTROL_EXPECTED_STATUS')
            same(row['reason'],row['expected_reason'],'ACTUAL_CONTROL_EXPECTED_REASON')
            need(row['activation_admitted'] is False,'MUTANTS_NEVER_ACTIVATE')
        marked=checked(ar['marked_model']);control=checked(ar['control_model']);current_base=checked(ar['base_model'])
        same(current_base,base,'UNCHANGED_WARM_BASE')
        same(u['model_bindings'],dict(base=sha(base),marked=sha(marked),control=sha(control)),'CURRENT_ADMITTED_MODELS')
        same(u['model_bindings'],a['model_bindings'],'ADMIT_RESULT_MODEL_BINDINGS')
        for key in ('new_failure_labels','new_synthesis_calls','old_target_proofs_used'):same(a[key],0,'EXPLICIT_WARM_ZERO:'+key)
        learning=dict(synthesis=synthesis_projection(synthesis),admission=u,costs=a['costs'],refs=ar,
            preservation_basis=a['preservation_basis'],custody_namespace='prior/v2',reused=True)
    if admitted['evaluate']:
        need(admitted['admit'],'EVALUATE_REQUIRES_CURRENT_ADMISSION')
        e=results['evaluate'];same([x['lane'] for x in e['lanes']],['BASE','MARKS','FILTER'],'ACTUAL_FIXED_LANE_ORDER')
        for item in e['lanes']:
            run=engine_summary(item['refs']);run.update(lane=item['lane'],admitted_status=item['admitted_status'],
                native_status=item['native_status'],native_proof_lines=item.get('native_proof_lines'),costs=item['costs'])
            lanes.append(run)
            if item['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
                refs=item['native_refs'];m=checked(refs['adapter_decoded']);n=checked(refs['independent_decoded']);b=checked(refs['native_receipt'])
                assurance=positive_engine(item['refs'],m['selected'])
                same(checked(refs['native_proof']),m['proof'],'NEW_SAVED_WHOLE_NATIVE_PROOF')
                model=checked(item['refs']['model'])
                proof=proof_record('arith-'+item['lane'],'ARITHMETIC','New arithmetic evaluation · '+item['lane'],m,n,b,model,refs,prepared['catalogue'],aliases)
                same(proof['statement'],declaration['problem'],'UNCHANGED_TARGET_STATEMENT')
                proof.update(reused=False,namespace='CURRENT_ROOT',engine_assurance=assurance,engine_refs=item['refs'])
                proofs.append(proof)
    audit_path='review/passive-streamed-outcomes-v1.json';audit=read(audit_path)
    need(audit['schema']=='Streamed-arithmetic-passive-audit-v1'
        and audit['status']=='PASS_SAVED_STREAMED_OUTCOMES_WITH_EXPLICIT_SCOPES','SAVED_DATA_AUDIT')
    same(audit['protocol'],pin(PROTOCOL),'SAVED_AUDIT_CURRENT_PROTOCOL')
    current_audit={x['name']:x for x in audit['phases']}
    same(sorted(current_audit),sorted(PHASES),'EXACT_AUDITED_CURRENT_PHASES')
    for p in phases:
        a=current_audit[p['name']]
        for key in ('pid','native_exit_code','scientific_status','process_clean'):same(p[key],a[key],'CURRENT_PHASE_AUDIT_JOIN:'+key)
        same(p['admitted'],a['scientific_admitted'],'CURRENT_SCIENTIFIC_ADMISSION_JOIN')
    prior_audit={x['name']:x for x in audit['prior']['phases']}
    same(sorted(prior_audit),sorted(p['name'] for p in history['phases']),'EXACT_AUDITED_PRIOR_PHASES')
    for p in history['phases']:
        a=prior_audit[p['name']]
        for key in ('pid','native_exit_code','scientific_status'):same(p[key],a[key],'PRIOR_PHASE_AUDIT_JOIN:'+key)
        same(p['admitted'],a['scientific_admitted'],'PRIOR_SCIENTIFIC_ADMISSION_JOIN')
    native_audit={x['id']:x for x in audit['native_proofs']}
    need(len(native_audit)==len(audit['native_proofs']),'DISTINCT_AUDITED_PROOF_IDS')
    for proof in proofs:
        need(proof['audit_id'] in native_audit,'DISPLAYED_PROOF_IS_IN_INDEPENDENT_AUDIT');a=native_audit[proof['audit_id']]
        for key in ('role','statement_sha256','selected_sha256'):same(proof[key],a[key],'NATIVE_PROOF_AUDIT_JOIN:'+key)
        same(proof['line_count'],a['lines'],'AUDITED_PROOF_LINE_COUNT')
        same(sha(proof['proof']),a['proof_sha256'],'AUDITED_EXACT_NATIVE_PROOF')
        for key in ('proof_ref','native_ref'):
            same({k:proof[key].get(k) for k in ('path','bytes','sha256','pointer')},
                 {k:a[key].get(k) for k in ('path','bytes','sha256','pointer')},'AUDITED_PROOF_REFERENCE:'+key)
    return dict(schema='Streamed-arithmetic-reader-data-v1',status='PASS_PASSIVE_SAVED_DATA_PROJECTION',
        run_root=ROOT.name,phases=phases,declaration=declaration,prepare=prepare_info,history=history,
        acquisition=None,label=label_info,learning_candidate=candidate,learning=learning,
        authentication=authentication,authentication_ref=authref,public_controls=controls,lanes=lanes,
        qualification=qualification,proofs=proofs,evaluation_preflight=None,
        saved_data_audits=[dict(status=audit['status'],ref=pin(audit_path))],protocol=pin(PROTOCOL),
        provenance=dict(external=external,artifact_pins=list(LEDGER.values())),
        costs_scope='Explicit warm reuse: retain prior preparation/label/synthesis costs and add current authentication/U3/controls/engine/native assurance. Worker/helper intervals overlap; no cold speed comparison.',
        scope='New private hash/equality qualification, current U3 admission and fresh matched eight-slot arithmetic searches; full original RF grammar and mandatory markings retained. Prior failure/synthesis reused without new labels or learner calls. No RL, fixed finite Wang proof search, full PA/induction, new theorem or superiority claim.')


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Streamed arithmetic proof search</title><style>
:root{--ink:#18343b;--muted:#5d7179;--line:#dbe3df;--green:#167c70;--purple:#8059ad;--orange:#ba7730;--red:#bc4e48}*{box-sizing:border-box}body{margin:0;background:#f4f6f2;color:var(--ink);font:16px/1.6 system-ui,-apple-system,sans-serif}main{max-width:1190px;margin:auto;padding:35px 24px 70px}nav{display:flex;gap:18px;flex-wrap:wrap;font-size:13px}a{color:var(--green)}h1{font-size:clamp(35px,5.7vw,66px);line-height:1.07;letter-spacing:-.045em;margin:35px 0 20px}h2{font-size:26px;letter-spacing:-.025em;margin:0 0 12px}.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:11px;color:var(--green)}.lede{font-size:19px;color:var(--muted);max-width:930px}section{margin:30px 0}.panel{background:#fff;border:1px solid var(--line);padding:23px;border-radius:15px;min-width:0}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.muted,small{color:var(--muted)}.note{border-left:4px solid var(--green);padding:12px 15px;background:#edf6f1;border-radius:0 8px 8px 0}.warning{border-color:var(--orange);background:#fff8ec}.tag{display:inline-block;background:#edf2ee;padding:3px 7px;border-radius:6px;font-size:11px;margin:2px;overflow-wrap:anywhere}.good{color:#28724e}.bad{color:var(--red)}.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:13px 0}select,button{font:inherit;font-size:13px;padding:8px 11px;border:1px solid #c5d4cc;border-radius:8px;background:white;max-width:100%}.scroll,.math{max-width:100%;overflow:auto}.math{display:block;padding:3px 0}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px 8px;text-align:left;vertical-align:top;border-bottom:1px solid var(--line);overflow-wrap:anywhere}th{font-size:11px;color:var(--muted);white-space:nowrap}.proof{table-layout:fixed}.proof th:nth-child(1){width:5%}.proof th:nth-child(2){width:43%}.proof th:nth-child(3){width:31%}.proof th:nth-child(4){width:21%}.active{background:#eef6ef}code,pre{font:12px/1.5 ui-monospace,monospace}pre{background:#eff3ef;border-radius:8px;padding:13px;max-width:100%;overflow:auto}details{margin:12px 0}summary{font-size:13px;color:var(--muted);cursor:pointer}.cards{display:flex;gap:10px;flex-wrap:wrap}.tile code{overflow-wrap:anywhere;white-space:normal}.tile{flex:1;min-width:135px;border:2px solid var(--green);border-radius:2px;padding:12px;background:#fafdf8}.stripe{height:13px;border-radius:2px;margin:7px 0}.port{background:var(--purple)}.guard0{background:#3e72b5}.guard1{background:#c85845}.proposed{border-style:dashed;background:repeating-linear-gradient(135deg,#fff,#fff 8px,#f1eee8 8px,#f1eee8 16px)}.absent{background:repeating-linear-gradient(135deg,#fff,#fff 4px,#dfe6e0 4px,#dfe6e0 8px)}.diagram{overflow:auto;border:1px solid var(--line);background:#fafdf8;border-radius:12px}.diagram svg{display:block;width:100%;height:auto;min-width:560px}#fatal{white-space:pre-wrap;color:var(--red)}mjx-container{max-width:100%}mjx-container[display=true]{overflow:auto}@media(max-width:800px){main{padding:24px 13px}.panel{padding:17px}.grid{grid-template-columns:1fr}.proof{min-width:680px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="quantified-markings-v1.html">Previous published quantified-marking attempt</a><a href="#phases">Actual phases</a><a href="#reader">Proof reader</a><a href="#overlay">Extra layer</a><a href="#assessment">Assessment</a></nav><p class="eyebrow">GCTS research · explicit warm reuse · current U3 execution</p><h1>Arithmetic proof search<br>with streamed assurance</h1><p class="lede">This attempt reuses an authenticated finite failure and its unactivated marking candidate. A new bounded streaming checker and its controls precede fresh matched point-proof searches. The full grammar and mandatory logical markings stay fixed.</p><div id="fatal"></div><div id="outcome" class="note"></div>
<section class="panel"><h2>The declared arithmetic statement</h2><div id="target"></div><p class="muted">This is a seen addition-zero/equality-congruence statement under a fresh namespace, with a prospective finite slot bound. It is not full Peano arithmetic or induction, and this representation is not a fixed finite universal Wang palette.</p><div id="basis"></div></section>
<section class="panel"><h2>Reused history and separate current admission</h2><div id="warm-auth"></div><div id="history-table" class="scroll"></div><div id="old-diagnostic"></div></section>
<section id="phases" class="panel"><h2>Three current phases</h2><div id="phase-table" class="scroll"></div><p class="muted">Scientific status, process completion and native proof admission are distinct. A missing/stopped phase does not borrow evidence from another run. UNKNOWN is never a negative label.</p></section>
<section id="reader" class="panel"><p class="eyebrow">Actual independently decoded, native-checked certificates</p><h2>Formula and English, line by line</h2><div class="controls"><select id="proof-select"></select><label><input id="literal" type="checkbox"> Literal symbol names</label></div><div id="proof-scope"></div><div id="proof-goal"></div><div id="slots" class="diagram"></div><div id="proof-table" class="scroll"></div><details><summary>Exact original proof and slot/reference maps</summary><pre id="proof-json"></pre></details><p class="muted">Each card is an anchored proof-slot owner with point markings, not a conventional geometric tile. Orange represents active-line values, purple formula IDs, and blue/red any extra guard assignment. Remote connectors are actual earlier-slot receptors. A proof line is the decoded logical assertion; it is not a NAND row or a universal Wang-grid row.</p></section>
<section id="overlay" class="panel"><h2>The extra marking layer</h2><div id="overlay-status"></div><div id="guard-cards" class="cards"></div><div id="label-detail"></div><p>The guard site and its two literal colors were prescribed in v2. This run reuses the exact v2 label and unactivated synthesis; it does not rerun the labeler or learner. Only current U3 admission and all five controls permit activation. No reusable geometric prototype is inferred.</p><details><summary>Actual label, synthesis and conditional admission</summary><pre id="overlay-json"></pre></details></section>
<section class="panel"><h2>Matched searches, including unresolved outcomes</h2><div id="lanes" class="scroll"></div><details><summary>Retained event samples and exact assurance scope</summary><div id="samples"></div></details><p class="muted">Large runs retain semantic events and serialized endpoints; intermediate producer maps were not observed. The prior tiny qualification retains historical actual maps; current private SHA qualification observes no new engine graphs. Placed-event counts include failed-branch placements; final selected counts are separate. Complete elimination-reason counters are unavailable.</p></section>
<section class="panel"><h2>Checker qualification and accounting</h2><div id="checker-metrics"></div><div id="public-controls" class="scroll"></div><p class="muted">These new controls mutate copies of the authenticated prior v2 query. They are not new labels, executed mutant-query evidence or fabricated successful provenance. Primitive equality qualification is separate from full overlay admission.</p></section>
<section id="assessment" class="grid"><div class="panel"><h2>What can be concluded</h2><div id="assessment-data"></div><p>The ordinary unary filter is a matched control for the same forbidden-CID information. Only actual admitted layer and evaluation records support a pruning comparison; missing or refused phases supply no outcome. This study does not establish a distinct GCTS advantage, reinforcement learning, a new theorem, held-out transfer or geometric prototype learning.</p><p>Fixed-CID exhaustion is a finite scoped claim. It does not prove the mathematical goal false or unprovable without these formula and slot bounds.</p></div><div class="panel"><h2>Cost and evidence scope</h2><div id="costs"></div><p>Worker, observer and helper intervals overlap; they are not added as independent costs. The fixed warm lane order is not a comparative performance benchmark. Acquisition, labeling, assurance, activation controls and all evaluation costs count. The v3 work meter is not numerically interchangeable with v1/v2; a passed gate or one fewer branch alone is not a speed claim.</p></div></section>
<!-- STREAMED_ARITHMETIC_ARCHIVE_LINK -->
<section id="evidence" class="panel"><h2>Qualification and exact provenance</h2><div id="qualification"></div><details><summary>Current streamed-SHA corpus and refusal results</summary><div id="hash-table" class="scroll"></div></details><details><summary>Actual private equality qualification: valid pairs and refusals</summary><div id="equality-table" class="scroll"></div></details><details><summary>Protocol, artifact pins and scope</summary><pre id="provenance"></pre></details><p><a href="streamed-arithmetic-data-v1.json.gz">Download the readable data</a>. Full original Sources, raw records, refusals and logs are retained in the approved archive.</p></section>
</main><script>
'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+x+'\\)</span>';let D,P,A={},literal=false,selectedLine=null,mathQueue=Promise.resolve();const num=x=>x==null?'not recorded':Number(x).toLocaleString(undefined,{maximumFractionDigits:4});
function typeset(el){mathQueue=mathQueue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math error: '+e.message;});}
async function load(){const r=await fetch('streamed-arithmetic-data-v1.json.gz');if(!r.ok)throw Error('Data HTTP '+r.status);const b=new Uint8Array(await r.arrayBuffer());if(b[0]===31&&b[1]===139)return JSON.parse(await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).text());return JSON.parse(new TextDecoder().decode(b));}
function symbol(x){return literal?x:(A[x]??x);}function term(a){if(a[0]==='var')return tex(symbol(a[1]));const name=symbol(a[1]);if(!a[2].length)return name==='0'?'0':'\\operatorname{'+tex(name)+'}';return (name==='S'?'S':'\\operatorname{'+tex(name)+'}')+'('+a[2].map(term).join(',')+')';}
function formula(a){switch(a[0]){case'pred':return '\\operatorname{'+tex(symbol(a[1]))+'}'+(a[2].length?'('+a[2].map(term).join(',')+')':'');case'eq':return term(a[1])+'='+term(a[2]);case'imp':return '('+formula(a[1])+'\\Rightarrow '+formula(a[2])+')';case'and':case'or':return '('+formula(a[1])+(a[0]==='and'?'\\land ':'\\lor ')+formula(a[2])+')';case'not':return '\\neg '+formula(a[1]);case'all':return '\\forall '+tex(symbol(a[1]))+'\\,('+formula(a[2])+')';case'bot':return '\\bot';default:return '\\text{'+tex(JSON.stringify(a))+'}';}}
function reason(line){const n=x=>Number(x)+1;switch(line.rule){case'axiom':return 'Use the named hypothesis '+line.name+'.';case'refl':return 'A term equals itself.';case'instantiate':return 'Use universal instantiation at the recorded term; the displayed implication is the native schema.';case'eq_subst':return 'Use equality substitution in the recorded formula context.';case'distribute':return 'Use the quantified distribution schema with its checked side conditions.';case'tautology':return 'Use a propositional tautology.';case'mp':return 'From line '+n(line.antecedent)+' and its implication on line '+n(line.implication)+', infer the consequent.';case'generalize':return 'Generalize line '+n(line.source)+' over '+symbol(line.variable)+' under the closed hypothesis context.';default:return line.rule;}}
function refs(line){return line.rule==='mp'?[line.antecedent,line.implication]:line.rule==='generalize'?[line.source]:[];}
function slotDiagram(){if(!P)return '';const ss=P.slots,w=Math.max(600,ss.length*112),h=205,row=new Map(P.selected_rows.map(r=>[r.id,r]));let s='<svg viewBox="0 0 '+w+' '+h+'" role="img" aria-label="Actual selected slot owners and remote marking receptors"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto"><path d="M0,0 L6,3 L0,6" fill="#ad9cc5"/></marker></defs>';for(const x of ss){const token=JSON.parse(x.cid);for(const earlier of token[3]){const x1=55+x.slot*112,x2=55+earlier*112;s+='<path d="M'+x1+',105 Q'+((x1+x2)/2)+','+(15+Math.abs(x1-x2)%50)+' '+x2+',105" fill="none" stroke="#b8a5d0" stroke-width="1.5" marker-end="url(#arrow)"/>';}}for(const x of ss){const xx=9+x.slot*112,selected=selectedLine!==null&&x.native_line_index_or_null===selectedLine,m=row.get(x.cid),extra=m.m.find(([p,v])=>p==='learned:unary:guard:v1');s+='<g data-slot="'+x.slot+'"><rect x="'+xx+'" y="105" width="94" height="89" rx="2" fill="'+(selected?'#e9f5ec':'#fafff7')+'" stroke="'+(selected?'#167c70':'#93afa0')+'" stroke-width="2"/><text x="'+(xx+8)+'" y="122" font-size="12">slot '+x.slot+' · '+JSON.parse(x.cid)[1]+'</text><rect x="'+(xx+8)+'" y="131" width="78" height="10" fill="'+(x.active?'#c18943':'#dde2d9')+'"/><rect x="'+(xx+8)+'" y="147" width="78" height="10" fill="#b39acb"/><text x="'+(xx+8)+'" y="174" font-size="10">active '+x.active+'; FID '+x.formula_id+'</text><rect x="'+(xx+8)+'" y="181" width="78" height="5" fill="'+(extra?(extra[1]==='0'?'#3e72b5':'#c85845'):'#e8ece5')+'"/></g>';}return s+'</svg>';}
function renderProof(){const id=$('proof-select').value;P=D.proofs.find(p=>p.id===id);selectedLine=null;if(!P){$('proof-scope').innerHTML='<p class="note warning">No native-admitted proof is attached to this selected record. Reused prior qualifiers are separate choices.</p>';$('proof-goal').innerHTML='';$('proof-table').innerHTML='';$('slots').innerHTML='';$('proof-json').textContent='';return;}A=P.aliases;literal=$('literal').checked;$('proof-scope').innerHTML='<p class="note '+(P.kind==='QUALIFICATION'?'warning':'')+'"><b>'+esc(P.kind==='QUALIFICATION'?'REUSED PRIOR QUALIFICATION — not new and not the arithmetic target':'New current arithmetic-target proof')+'</b> · '+esc(P.label)+' · '+P.proof.length+' native-checked lines, '+P.slots.length+' slots.</p>';$('proof-goal').innerHTML=math(formula(P.statement.goal))+'<details><summary>Exact hypothesis context and display symbol map</summary><pre>'+esc(JSON.stringify({theory:P.statement.theory,display_aliases:P.aliases},null,2))+'</pre></details>';$('proof-table').innerHTML='<table class="proof"><thead><tr><th>Line</th><th>Decoded assertion</th><th>English meaning</th><th>Rule / references</th></tr></thead><tbody>'+P.proof.map((l,i)=>'<tr id="line-'+i+'"><td><button data-line="'+i+'">'+(i+1)+'</button></td><td>'+math(formula(l.formula))+'</td><td>'+esc(reason(l))+'</td><td><code>'+esc(l.rule)+'</code><br>'+refs(l).map(x=>'line '+(x+1)).join(', ')+'<br>slot '+P.native_to_slot[i]+'</td></tr>').join('')+'</tbody></table>';$('slots').innerHTML=slotDiagram();const choose=i=>{selectedLine=i;for(const tr of $('proof-table').querySelectorAll('tbody tr'))tr.classList.toggle('active',tr.id==='line-'+i);$('slots').innerHTML=slotDiagram();bindSlots();};const bindSlots=()=>{for(const g of $('slots').querySelectorAll('[data-slot]'))g.onclick=()=>{const i=P.slots.find(x=>x.slot===+g.dataset.slot).native_line_index_or_null;choose(i);};};for(const b of $('proof-table').querySelectorAll('[data-line]'))b.onclick=()=>choose(+b.dataset.line);bindSlots();$('proof-json').textContent=JSON.stringify({proof:P.proof,slots:P.slots,reference_mapping:P.reference_mapping,proof_dag:P.proof_dag},null,2);typeset($('reader'));}
function renderOverlay(){
 const l=D.learning,c=D.learning_candidate,lab=D.label;let placement=null;
 if(lab){try{placement=JSON.parse(lab.cid);}catch(e){placement=null;}}
 const u=l?.admission??c?.admission;
 if(l){$('overlay-status').innerHTML='<p class="note"><b>Extra layer admitted.</b> '+esc(l.admission.status)+'. Forbidden CIDs: '+l.synthesis.forbidden_cids.length+'. '+(l.synthesis.forbidden_cids.length?'Only the certified list receives rejecting guard assignments.':'The extra layer is the empty identity; no pruning is claimed.')+'</p>';}
 else if(c){$('overlay-status').innerHTML='<p class="note warning"><b>NOT ACTIVATED.</b> Reused v2 synthesis: '+esc(c.synthesis.status)+'; construction: '+esc(c.overlay_status??'not reached')+'. Independent checker: <b>'+esc(u?.status??'not reached')+'</b>'+(u?.reason?' / '+esc(u.reason):'')+'. '+(u?.work==null?'':'Charged work '+num(u.work)+'; frozen ceiling '+num(c.frozen_checker_max_work)+'. ')+(c.stopped_stage?'Stopped stage: '+esc(c.stopped_stage)+'. ':'')+'All required process, checker and control gates must be admitted before use.</p>';}
 else{$('overlay-status').innerHTML='<p class="note warning">No admitted learned overlay is available; no missing phase is treated as an empty successful result.</p>';}
 const syn=l?l.synthesis:c?.synthesis;
 let cards='<div class="tile">Effective additional layer<div class="stripe '+(l&&syn.forbidden_cids.length?'guard0':'absent')+'"></div><b>'+(l?(syn.forbidden_cids.length?'Installed guard layer':'Empty additional identity'):'Baseline unchanged')+'</b></div>';
 if(syn?.status==='SOLVED'&&syn.forbidden_cids.length){cards+='<div class="tile '+(l?'':'proposed')+'">'+(l?'Activated':'PROPOSED ONLY')+' seed guard<div class="stripe guard0"></div><code>"0"</code>'+(l?'':'<br><span class="tag">NOT ACTIVATED</span>')+'</div>'+syn.extra_assignments.map(x=>'<div class="tile '+(l?'':'proposed')+'">'+(l?'Activated':'PROPOSED ONLY')+' CID guard<div class="stripe guard1"></div><code>'+esc(x.id)+'</code><br>literal <code>"1"</code>'+(l?'':'<br><span class="tag">NOT ACTIVATED</span>')+'</div>').join('');}
 $('guard-cards').innerHTML=cards;
 const dead=lab?.dead_context_witnesses?.[0]?.context_preimage.dead_point;
 $('label-detail').innerHTML=lab?'<p>Reused v2 fixed-CID label: <b>'+esc(lab.label)+'</b>; semantic check '+esc(lab.semantic_status)+'. '+(lab.bounded_absence?'Complete scoped finite exhaustion excludes this placement, not the mathematical statement.':'No negative claim follows from this record.')+'</p><code>'+esc(lab.cid)+'</code>'+(dead?'<p>Actual fixed-context dead point: <code>'+esc(dead)+'</code>. '+(placement&&placement[1]==='GEN'&&placement[3].length===1&&placement[3][0]===0?'This CID requests a generalization source in slot 0. The complete query has no eligible owner at its recorded dead point. This is a finite proof-slot constraint, not a new arithmetic theorem.':'The dead context belongs only to the complete fixed-CID query.')+'</p>':''):'<p class="muted">No admitted fixed-CID label is recorded.</p>';
 $('overlay-json').textContent=JSON.stringify({label:D.label,candidate:D.learning_candidate,admitted_learning:D.learning,evaluation_preflight:D.evaluation_preflight},null,2);
}
function phaseTable(rows){return '<table><thead><tr><th>Phase / PID</th><th>Scientific status</th><th>Process / native exit</th><th>Worker / observed seconds</th></tr></thead><tbody>'+rows.map(p=>'<tr><td>'+esc(p.name)+' / '+esc(p.pid??'none')+'</td><td>'+esc(p.scientific_status??'not run')+'</td><td>'+esc(p.process_status)+' / '+esc(p.native_exit_code??'no worker')+'</td><td>'+num(p.worker_seconds)+' / '+num(p.observer_seconds)+'</td></tr>').join('')+'</tbody></table>';}
function renderChecker(){
 const u=D.learning?.admission??D.learning_candidate?.admission,m=u?.comparison_metrics;
 $('checker-metrics').innerHTML=m?'<p>Actual current U3 output: <b>'+esc(u.status)+'</b>; '+(u.work==null?'work not recorded':num(u.work)+' charged work')+'. Intervals overlap and must not be added.</p><table><thead><tr><th>Operation</th><th>Calls / fragments</th><th>Charged interval work</th><th>Bytes / visits</th></tr></thead><tbody><tr><td>Small canonical encode</td><td>'+num(m.encode_calls)+'</td><td>'+num(m.encode_work)+'</td><td>'+num(m.encoded_bytes)+' bytes</td></tr><tr><td>Streamed SHA</td><td>'+num(m.sha_calls)+'</td><td>'+num(m.sha_work)+'</td><td>'+num(m.hashed_bytes)+' bytes</td></tr><tr><td>Structural equality</td><td>'+num(m.equal_calls)+'</td><td>'+num(m.equal_work)+'</td><td>'+num(m.equal_pairs)+' pairs</td></tr><tr><td>Stream validation</td><td>included in SHA</td><td>'+num(m.stream_validation_work)+'</td><td>'+num(m.stream_nodes)+' value nodes</td></tr><tr><td>Scalar fragments</td><td>'+num(m.stream_scalar_fragments)+'</td><td>'+num(m.stream_scalar_work)+'</td><td>largest '+num(m.stream_max_scalar_bytes)+' bytes</td></tr></tbody></table><p class="muted">No compound SHA wire is allocated. Scalar output buffers remain bounded. V3 charged units are not comparable numerically to v1/v2, and a passed gate is not a proof-search speed advantage.</p>':'<p class="muted">No current U3 metrics are available for this snapshot.</p>';
 const rows=D.public_controls.rows;
 $('public-controls').innerHTML=rows.length?'<h3>Current public activation controls</h3><p>'+esc(D.public_controls.status??'Partial records; no aggregate admission')+'</p><table><thead><tr><th>Control</th><th>Actual status</th><th>Reason</th><th>Required status</th><th>Work</th></tr></thead><tbody>'+rows.map(x=>'<tr><td><code>'+esc(x.id)+'</code></td><td>'+esc(x.status)+'</td><td><code>'+esc(x.reason??'not applicable')+'</code></td><td>'+esc(x.expected)+'</td><td>'+num(x.work)+'</td></tr>').join('')+'</tbody></table>':'<p class="muted">No current public activation control results are recorded.</p>';
 const q=D.qualification,e=q?.equality;
 $('equality-table').innerHTML=e?'<p>'+e.cases.length+' valid-pair checks and '+e.refusals.length+' malformed/resource controls, run now on the previously declared corpus. These are private primitive calls, not new physical graph qualification.</p><table><thead><tr><th>Case</th><th>Saved reference</th><th>Actual status</th><th>Reason</th></tr></thead><tbody>'+e.cases.map(x=>'<tr><td><code>'+esc(x.id)+'</code></td><td>'+(x.reference.relation?'equal':'unequal')+'</td><td>'+esc(x.actual.status)+'</td><td><code>'+esc(x.actual.reason??'none')+'</code></td></tr>').join('')+e.refusals.map(x=>'<tr><td><code>'+esc(x.id)+'</code></td><td>invalid/resource</td><td>'+esc(x.actual.status)+'</td><td><code>'+esc(x.actual.reason??'none')+'</code></td></tr>').join('')+'</tbody></table>':'<p class="muted">No admitted current equality qualification.</p>';
 $('hash-table').innerHTML=q?'<p>'+q.hash_cases.length+' canonical-reference SHA checks and '+q.hash_controls.length+' refusal cases.</p><table><thead><tr><th>Hash case</th><th>Actual status</th><th>Reference bytes</th><th>Charged work</th></tr></thead><tbody>'+q.hash_cases.map(x=>'<tr><td><code>'+esc(x.id)+'</code></td><td>'+esc(x.status)+'</td><td>'+num(x.reference_bytes)+'</td><td>'+num(x.actual.work)+'</td></tr>').join('')+q.hash_controls.map(x=>'<tr><td><code>'+esc(x.id)+'</code></td><td>'+esc(x.actual.status)+' / '+esc(x.actual.reason)+'</td><td>no digest</td><td>'+num(x.actual.work)+'</td></tr>').join('')+'</tbody></table>':'<p class="muted">No admitted current hash qualification.</p>';
}
function init(){
 const targetProofs=D.proofs.filter(p=>p.kind==='ARITHMETIC'),last=D.phases.filter(p=>p.scientific_status!==null).at(-1);
 let outcome=targetProofs.length?'<b>'+targetProofs.length+' new native-checked arithmetic certificate record(s).</b> They concern the same seen statement, not separate new theorems. ':'<b>No admitted new arithmetic-target proof is recorded.</b> ';
 outcome+=D.learning?'Current U3 admission and controls permit the reused extra layer. ':'The reused candidate is not activated in this run. ';
 outcome+=(last?'Latest current scientific phase: '+esc(last.name)+' / '+esc(last.scientific_status)+'. ':'')+(targetProofs.length?'Inspect the new certificates below.':'Any proof shown below is explicitly reused prior qualification evidence.');
 $('outcome').innerHTML=outcome;
 A=Object.fromEntries(Object.entries(D.declaration.names).map(([k,v])=>[v,({S:'S',add:'add',x:'x',zero:'0'})[k]]));
 $('target').innerHTML='<p>Hypothesis '+math(formula(D.declaration.problem.theory.axioms[Object.keys(D.declaration.problem.theory.axioms)[0]]))+'</p><p>Goal '+math(formula(D.declaration.problem.goal))+'</p>';
 $('basis').innerHTML='<p><b>Warm reused preparation:</b> '+D.prepare.census.formulas+' formulas, '+D.prepare.census.rows+' complete candidate rows, '+D.prepare.slots+' slots and '+D.prepare.ZERO_checks+' prior native ZERO checks. No formula thinning, new compilation or old target proof is supplied.</p>';
 const priorLabel=D.history.phases.find(x=>x.name==='label'),currentAdmit=D.phases.find(x=>x.name==='admit');
 $('warm-auth').innerHTML='<p class="note">The '+D.history.physical_files+' original files under <code>prior/v2</code> retain their own protocol and five actual processes. Current phases use a separate protocol. <b>New labels: 0; new synthesis calls: 0; old target proofs used: 0.</b></p><p>Original LABEL PID <code>'+esc(priorLabel?.pid??'not recorded')+'</code>; current ADMIT PID <code>'+esc(currentAdmit?.pid??'not started')+'</code>. Old inline U3 custody references continue to resolve under <code>prior/v2</code>; they are not rewritten as current executions.</p>';
 $('history-table').innerHTML='<h3>Historical V2 processes</h3>'+phaseTable(D.history.phases);
 $('old-diagnostic').innerHTML='<p>Preserved V2 overlay result: <b>'+esc(D.history.old_overlay_admission.status)+' / '+esc(D.history.old_overlay_admission.reason)+'</b>; '+num(D.history.old_overlay_admission.work)+' old charged work. It remained unactivated and had no evaluation. Current U3 results are separate records.</p>';
 $('phase-table').innerHTML=phaseTable(D.phases);
 const unresolved=D.lanes.filter(x=>x.admitted_status!=='VERIFIED_NATIVE_POSITIVE');
 $('proof-select').innerHTML=D.proofs.map(p=>'<option value="'+esc(p.id)+'">'+esc(p.label)+'</option>').join('')+unresolved.map(x=>'<option value="no-proof-'+esc(x.lane)+'">New '+esc(x.lane)+' · '+esc(x.raw_status)+' / '+esc(x.semantic_status)+' · no admitted proof</option>').join('');
 if(targetProofs.length)$('proof-select').value=targetProofs[0].id;else if(unresolved.length)$('proof-select').value='no-proof-'+unresolved[0].lane;renderProof();$('proof-select').onchange=renderProof;$('literal').onchange=renderProof;renderOverlay();renderChecker();
 $('lanes').innerHTML=D.lanes.length?'<table><thead><tr><th>Fresh lane</th><th>Raw / semantic</th><th>Native admission</th><th>Placed / final selected</th><th>Branches / backtracks</th><th>Work</th></tr></thead><tbody>'+D.lanes.map(x=>'<tr><td>'+x.lane+'</td><td>'+esc(x.raw_status)+' / '+esc(x.semantic_status)+'</td><td>'+esc(x.admitted_status)+'<br><code>'+esc(x.reason)+'</code></td><td>'+x.stats.placements+' / '+x.selected.length+'</td><td>'+x.stats.branches+' / '+x.stats.backtracks+'</td><td>'+num(x.stats.work)+'</td></tr>').join('')+'</tbody></table>':'<p class="muted">No admitted current evaluation phase. Missing searches are not zero-cost results.</p>';
 $('samples').innerHTML=D.lanes.map(x=>'<details><summary>'+esc(x.lane)+' · '+x.sample.retained_payload_rows+' retained of '+x.sample.emitted_total+' emitted events</summary><p>'+esc(x.sample.scope)+'</p><pre>'+esc(JSON.stringify(x.sample.records,null,2))+'</pre></details>').join('');
 $('assessment-data').innerHTML='<p>'+esc(D.scope)+'</p><p>'+D.phases.filter(x=>x.admitted).length+' current phase records scientifically admitted; '+targetProofs.length+' new target-positive certificate records. '+(D.lanes.length&&D.lanes.every(x=>x.admitted_status==='UNKNOWN')?'All recorded fresh lanes are unresolved: no target proof or finite absence is certified. Complete retained event payloads can certify a decision prefix without completing the search. ':'')+'The matched ordinary filter encodes the same forbidden CID information as the literal guard. The total admission/control and search/assurance costs provide no practical advantage evidence merely from a passed gate or a branch difference.</p>';
 const costRows=(title,rows)=>'<h3>'+title+'</h3>'+rows.map(p=>'<p><b>'+p.name+'</b>: '+num(p.worker_seconds)+' s worker; '+num(p.observer_seconds)+' s observed; native high-water RSS '+(p.worker_highwater_rss_bytes==null?'not recorded':num(p.worker_highwater_rss_bytes/1048576)+' MiB')+'.</p>').join('');
 $('costs').innerHTML=costRows('Current processes',D.phases)+(D.learning?'<details><summary>Current authentication, U3 and control helper costs</summary><pre>'+esc(JSON.stringify(D.learning.costs,null,2))+'</pre></details>':'')+'<details><summary>Reused prior process costs remain part of acquisition history</summary>'+costRows('Original V2 processes',D.history.phases)+'</details><p>'+esc(D.costs_scope)+'</p>';
 $('qualification').innerHTML=D.qualification?'<p>Current private qualification: '+D.qualification.hash_cases.length+' valid SHA calls, '+D.qualification.hash_controls.length+' SHA refusals, '+D.qualification.equality.cases.length+' equality pairs and '+D.qualification.equality.refusals.length+' equality refusals. <b>No new engine, physical graph or native-proof qualification is claimed.</b></p>':'<p class="muted">Current private qualification not admitted.</p>';
 $('qualification').innerHTML+='<p>Reused prior qualification: '+D.history.prior_qualification_counts.tiny_cases+' tiny models, '+D.history.prior_qualification_counts.logical_cases+' logical qualifiers and '+(D.history.prior_qualification_counts.actual_tiny_snapshots+D.history.prior_qualification_counts.actual_logical_snapshots)+' actual graph observations, all historical. Its two proofs are labeled reused above.</p>';
 $('provenance').textContent=JSON.stringify({run_root:D.run_root,current_protocol:D.protocol,current_phases:D.phases,prior_protocol:D.history.protocol,prior_namespace:D.history.namespace,authentication:D.authentication,saved_data_audits:D.saved_data_audits,scope:D.scope,artifact_pins:D.provenance.artifact_pins},null,2);typeset(document.querySelector('main'));
}
load().then(x=>{D=x;init();}).catch(e=>{$('fatal').textContent='Actual saved data could not be loaded: '+e.message;});
</script></body></html>'''


def write(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(value)
    return dict(path=path.relative_to(ROOT).as_posix(),**bytepin(path))


def build():
    data=assemble();j=write('streamed-arithmetic-data-v1.json.gz',gzip.compress(wire(data),mtime=0))
    h=write('streamed-arithmetic-v1.html',PAGE.encode('utf-8'))
    receipt=dict(schema='Streamed-arithmetic-passive-build-v1',status='PASS_PASSIVE_SAVED_DATA_AND_REPORT_BUILD',
        outputs=dict(main=h,data=j),renderer_source=dict(path=Path(__file__).relative_to(ROOT).as_posix(),**bytepin(Path(__file__))),
        protocol=data['protocol'],phases=data['phases'],artifact_pins=list(LEDGER.values()),
        scope='Passive saved-data/hash/projection only. No scientific helper imports, native kernel, model construction, transition or rerun.')
    return write('build-receipt-v1.json',wire(receipt))


if __name__=='__main__':print(json.dumps(build(),sort_keys=True))
