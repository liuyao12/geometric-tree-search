# One-shot live byte verification

Held Source: `publication/verify_streamed_live_v1.py`, 5,739 bytes, SHA256 `f2483875038b974ad9c5515025d171244c70a5a2bf4c3554febf05f2e0406c83`. Syntax parsed only; no import, download, archive check or scientific call executed by the author.

Root must first independently confirm the official remote commit/tree/sole parent and successful Pages deployment for `publication/prepared-v1.json`'s commit. This verifier certifies bytes, not that separate deployment observation or scientific validity. After Source review:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/verify_streamed_live_v1.py
```

Input is the future prepared receipt only; no outcome or asset hash is invented. The script creates `publication/live/` exclusively and refuses an existing attempt. Every prepared task asset is downloaded exactly once from its exact existing-public GitHub Pages URL with `?commit=<prepared SHA>`, HTTPS certificate verification, HTTP/1.1, identity encoding and a 60-second socket-operation timeout. It follows no redirects and performs no retry. Every physical body is limited to strictly below 50 MiB. A failing response is retained; interruption/resource failures retain the bounded captured body prefix. A failed attempt is not overwritten or silently rerun.

Before importing the reviewed passive packager, it requires its exact 37,486 bytes/SHA256 `6616e32444215554d88e63b0b5f3e1728a799dfe71e59d594fd961332149c728`. Only that packager's stdlib helpers and `verify_archive` are used; no scientific engine/model/checker is imported or replayed. All live bodies must match the prepared size/SHA256. The manifest/part set and readiness must match the prepared receipt, and all volumes must pass complete original member coverage, exact member sets, sizes/SHA256 and every CRC. Archive verification must exactly equal the prepared archive verification result.

Output `publication/live/receipt-v1.json` has status `PASS_ALL_PREPARED_LIVE_BYTES_AND_ARCHIVE_ORIGINALS` only after every asset and original archive member passes. It binds prepared/verifier Source pins, commit, individual URLs/status/headers/body hashes, archive verification and elapsed seconds. Otherwise status is `FAILED_LIVE_BYTE_VERIFICATION`, an error is retained, and process exit is nonzero. No new publication assets, Git mutation, retry or scientific claim is made. The Source/API can be included in the imminent archive; live bodies/receipts are postcut custody.
