"""One-shot passive public-byte verification; no scientific imports or retry."""
import hashlib
import http.client
import importlib.util
import json
from pathlib import Path
import ssl
import time

ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 50 * 1024 * 1024 - 1
PACKAGER_SHA = '6616e32444215554d88e63b0b5f3e1728a799dfe71e59d594fd961332149c728'
STATUS = 'PASS_ALL_PREPARED_LIVE_BYTES_AND_ARCHIVE_ORIGINALS'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def pin(path):
    value = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(value),
                sha256=hashlib.sha256(value).hexdigest())


def main():
    prepared_path = ROOT / 'publication/prepared-v1.json'
    source = ROOT / 'publication/package_streamed_v1.py'
    need(not source.is_symlink() and source.stat().st_size == 37486
         and pin(source)['sha256'] == PACKAGER_SHA, 'EXACT_REVIEWED_PASSIVE_PACKAGER')
    spec = importlib.util.spec_from_file_location('reviewed_passive_archive', source)
    package = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(package)  # Reviewed passive archive functions only.
    need(not prepared_path.is_symlink() and prepared_path.stat().st_size < 16 * 1024 * 1024,
         'BOUNDED_PHYSICAL_PREPARED_RECEIPT')
    prepared = json.loads(prepared_path.read_bytes())
    commit, assets = prepared['commit'], prepared['assets']
    need(prepared['status'] == 'PREPARED_TASK_ASSETS_ONLY' and type(commit) is str
         and len(commit) == 40 and all(c in '0123456789abcdef' for c in commit), 'PREPARED_COMMIT')
    need(type(assets) is list and 4 < len(assets) < 1000, 'BOUNDED_PREPARED_ASSETS')
    out = ROOT / 'publication/live'
    out.mkdir()  # Exclusive first attempt; no retry or overwrite.
    started = time.monotonic()
    receipt = dict(status='FAILED_LIVE_BYTE_VERIFICATION', commit=commit,
        prepared=pin(prepared_path), source=pin(Path(__file__).resolve()), assets=[],
        scope='Live bytes/archive originals only; official Pages commit success is checked separately by Root.')
    try:
        seen = set()
        fixed = {package.MAIN, package.DATA, package.OLD, package.MANIFEST}
        for asset in assets:
            name = asset['path'].removeprefix(package.PREFIX)
            is_part = (name.startswith(package.PART_STEM) and name.endswith('.zip')
                       and len(name[len(package.PART_STEM):-4]) == 3
                       and name[len(package.PART_STEM):-4].isdigit())
            need(asset['path'] == package.PREFIX + name and '/' not in name
                 and name not in seen and (name in fixed or is_part), 'EXACT_TASK_ASSET_PATH')
            need(asset['url'] == package.BASE_URL + asset['path'] and type(asset['bytes']) is int
                 and 0 <= asset['bytes'] <= MAX_BYTES, 'PREPARED_URL_AND_PHYSICAL_BOUND')
            seen.add(name)
            item = dict(path=asset['path'], url=asset['url'] + '?commit=' + commit,
                        body='publication/live/' + name, status='FAILED', bytes=0)
            receipt['assets'].append(item)
            connection = http.client.HTTPSConnection('liuyao12.github.io', timeout=60,
                                                     context=ssl.create_default_context())
            try:
                connection.request('GET', '/' + asset['path'] + '?commit=' + commit,
                    headers={'Accept-Encoding': 'identity', 'User-Agent': 'GCTS-passive-byte-verifier/1'})
                response = connection.getresponse()
                item['http_status'] = response.status
                item['headers'] = response.getheaders()
                digest = hashlib.sha256()
                with (out / name).open('xb') as stream:
                    while True:
                        block = response.read1(min(1048576, MAX_BYTES - item['bytes'] + 1))
                        if not block:
                            break
                        need(item['bytes'] + len(block) <= MAX_BYTES, 'PHYSICAL_DOWNLOAD_BOUND')
                        stream.write(block)
                        digest.update(block)
                        item['bytes'] += len(block)
                item['sha256'] = digest.hexdigest()
                need(response.status == 200 and response.length in (None, 0)
                     and response.getheader('Content-Encoding', 'identity') == 'identity', 'COMPLETE_HTTP_200_IDENTITY')
                need(item['bytes'] == asset['bytes'] and item['sha256'] == asset['sha256'], 'EXACT_LIVE_BODY_BYTES')
                item['status'] = 'PASS'
            finally:
                connection.close()
        manifest = json.loads((out / package.MANIFEST).read_bytes())
        need(seen == fixed | {part['name'] for part in manifest['parts']}, 'EVERY_PREPARED_ASSET_AND_VOLUME')
        need(package.wire(manifest['readiness']) == package.wire(prepared['readiness']), 'MANIFEST_PREPARED_READINESS')
        receipt['archive'] = package.verify_archive(out, manifest)
        need(package.wire(receipt['archive']) == package.wire(prepared['archive_verification']), 'SAME_ORIGINALS_AND_ARCHIVE_CHECK')
        receipt['status'] = STATUS
    except BaseException as error:
        receipt['error'] = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - started
        with (out / 'receipt-v1.json').open('xb') as stream:
            stream.write(package.wire(receipt))
        print(json.dumps(dict(status=receipt['status'], assets=len(receipt['assets']),
                              receipt='publication/live/receipt-v1.json')), flush=True)


if __name__ == '__main__':
    main()
