"""Sparse unary extra-mark synthesis and structural application; stdlib only.

The learner receives CID labels and scope/evidence bindings, never expected
colors, target proofs, old discovered proofs or exhaustive solution tables.
It does not check label truth. The independent checker and driver must admit
fresh scoped C3 exhaustion before any negative assignment is activated.
"""
import hashlib
import json
import math
import time

VERSION='Sparse-certified-unary-overlay-v1'
GUARD='learned:unary:guard:v1'


class _Bad(Exception):pass
class _Stop(Exception):pass


def _need(ok,why):
    if not ok:raise _Bad(why)


def _sha_string(s):
    return type(s) is str and len(s)==64 and all(c in '0123456789abcdef' for c in s)


class _Meter:
    def __init__(self,work,wall):
        _need(type(work) is int and 0<=work<=1000000000,'WORK_LIMIT')
        _need(type(wall) in (int,float) and math.isfinite(wall) and 0<wall<=120,'WALL_LIMIT')
        self.work=0;self.limit=work;self.deadline=time.perf_counter()+wall
    def tick(self,n=1):
        self.work+=n
        if self.work>self.limit:raise _Stop('MAX_WORK')
        if time.perf_counter()>=self.deadline:raise _Stop('WALL_SECONDS')
    def scan(self,x,depth=0):
        self.tick()
        if depth>128:raise _Stop('JSON_DEPTH')
        if type(x) is str:self.tick(len(x))
        elif type(x) is int:
            _need(x.bit_length()<=256,'INTEGER_BITS');self.tick(x.bit_length())
        elif x is None or type(x) is bool:pass
        elif type(x) is float:_need(math.isfinite(x),'FINITE_JSON_FLOAT')
        elif type(x) is list:
            for y in x:self.scan(y,depth+1)
        elif type(x) is dict:
            for k,v in x.items():
                _need(type(k) is str,'STRING_KEY');self.scan(k,depth+1);self.scan(v,depth+1)
        else:raise _Bad('NATIVE_JSON_ONLY')


def _wire(x):
    return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def synthesize(candidate_ids,labels,scope_sha256,guard_point=GUARD,*,max_work=1000000000,wall_seconds=120):
    """Linear sparse exact synthesis over resolved unary labels, not 3**N search.

    Initial/UNKNOWN-only/POSITIVE-only outputs have no extra seed or CID rows.
    Each proved-negative CID requires one guard value '1' against seed '0'.
    Minimize assigned CID components, then the unique declared nonseed color.
    The driver/checker, not this learner, authenticates certificate bindings.
    """
    start=time.perf_counter();meter=None
    try:
        meter=_Meter(max_work,wall_seconds)
        for x in (candidate_ids,labels,scope_sha256,guard_point):meter.scan(x)
        _need(type(candidate_ids) is list and all(type(c) is str and c for c in candidate_ids)
              and candidate_ids==sorted(set(candidate_ids)),'CANONICAL_UNIQUE_CID_LIST')
        _need(_sha_string(scope_sha256),'ORIGINAL_MODEL_SCOPE_SHA256')
        _need(type(guard_point) is str and bool(guard_point),'GUARD_POINT')
        _need(type(labels) is list,'LABEL_LIST')
        pool=set(candidate_ids);resolved={};counts=dict(POSITIVE=0,NEGATIVE=0,UNKNOWN=0)
        for label in labels:
            meter.tick()
            _need(type(label) is dict and set(label)=={'cid','status','scope_sha256','certificate_binding_sha256'},'LABEL_FIELDS')
            _need(type(label['cid']) is str and label['cid'] in pool,'LABEL_CID')
            _need(label['scope_sha256']==scope_sha256 and _sha_string(label['certificate_binding_sha256']),'LABEL_SCOPE_AND_BINDING')
            status=label['status'];_need(type(status) is str and status in counts,'LABEL_STATUS')
            counts[status]+=1
            if status!='UNKNOWN':
                _need(label['cid'] not in resolved or resolved[label['cid']]==status,'CONTRADICTORY_RESOLVED_LABELS')
                resolved[label['cid']]=status
        forbidden=sorted(c for c,s in resolved.items() if s=='NEGATIVE')
        assignments=[dict(id=c,m=[[guard_point,'1']]) for c in forbidden]
        output=dict(schema='Sparse-unary-overlay-synthesis-v1',version=VERSION,status='SOLVED',
            scope_sha256=scope_sha256,guard_point=guard_point,candidate_ids=list(candidate_ids),
            labels=json.loads(_wire(labels)),forbidden_cids=forbidden,
            extra_seed_m=[[guard_point,'0']] if forbidden else [],extra_assignments=assignments,
            counters=dict(label_records=counts,distinct_resolved_cids=len(resolved),
                          seed_assignments=1 if forbidden else 0,per_cid_assignments=len(forbidden),
                          absent_cids=len(candidate_ids)-len(forbidden)),
            objective='Minimum assigned per-CID components satisfying resolved unary labels; '
                      'absence for every unconstrained/positive CID; seed0 and rejecting color1 prescribed.',
            label_truth='NOT_CHECKED_BY_LEARNER; require independent scoped evidence admission before activation.')
        meter.scan(output);meter.tick(len(_wire(output)));output.update(work=meter.work,seconds=time.perf_counter()-start)
        return output
    except _Stop as e:return dict(status='UNKNOWN',reason=str(e),extra_seed_m=None,extra_assignments=None,work=0 if meter is None else meter.work)
    except (MemoryError,RecursionError,OverflowError) as e:return dict(status='UNKNOWN',reason='HOST_RESOURCE:'+type(e).__name__,extra_seed_m=None,extra_assignments=None)
    except (_Bad,KeyError,TypeError,ValueError,IndexError) as e:return dict(status='REJECTED',reason=str(e),extra_seed_m=None,extra_assignments=None)


def _model(model,meter):
    fields={'schema','version','capacity','roots','seed','inventory','pair_nogoods','unary_nogoods'}
    _need(type(model) is dict and set(model)==fields and model['schema']=='Z-growing-point-model-v3','MODEL_V3_FIELDS')
    _need(type(model['version']) is str and bool(model['version']),'MODEL_VERSION')
    c=model['capacity'];_need(type(c) is int and c>0 and c.bit_length()<=256,'CAPACITY')
    def rows(value,mark=False,seed=False):
        _need(type(value) is list,'ROWS_LIST');out={}
        for pair in value:
            meter.tick();_need(type(pair) is list and len(pair)==2 and type(pair[0]) is str and pair[0] not in out,'POINT_ROW')
            p,v=pair
            if mark:_need(type(v) is str,'MARK_LITERAL')
            else:_need(type(v) is int and (0 if seed else 1)<=v<=c and v.bit_length()<=256,'INTEGER_UNITS')
            out[p]=v
        return [[p,out[p]] for p in sorted(out)]
    _need(type(model['roots']) is list and all(type(p) is str for p in model['roots'])
          and len(model['roots'])==len(set(model['roots'])),'ROOTS')
    _need(type(model['seed']) is dict and set(model['seed'])=={'t','m'},'SEED')
    _need(type(model['inventory']) is dict and set(model['inventory'])=={'kind','placements'}
          and model['inventory']['kind']=='EXPLICIT' and type(model['inventory']['placements']) is list,'EXPLICIT_INVENTORY')
    r={}
    for raw in model['inventory']['placements']:
        meter.tick();_need(type(raw) is dict and set(raw)=={'id','t','m'},'PLACEMENT_FIELDS')
        cid=raw['id'];_need(type(cid) is str and bool(cid) and cid not in r,'UNIQUE_CID')
        t=rows(raw['t']);_need(bool(t),'POSITIVE_SUPPORT')
        r[cid]=dict(id=cid,t=t,m=rows(raw['m'],mark=True))
    _need(type(model['pair_nogoods']) is list and model['pair_nogoods']==[]
          and type(model['unary_nogoods']) is list and model['unary_nogoods']==[],'UNFILTERED_BASELINE_REQUIRED')
    return dict(schema=model['schema'],version=model['version'],capacity=c,roots=sorted(model['roots']),
                seed=dict(t=rows(model['seed']['t'],seed=True),m=rows(model['seed']['m'],mark=True)),
                inventory=dict(kind='EXPLICIT',placements=[r[k] for k in sorted(r)]),pair_nogoods=[],unary_nogoods=[])


def apply(base_model,synthesis,*,max_work=1000000000,wall_seconds=120):
    """Structural construction only. Never authenticates a negative label."""
    meter=None
    try:
        meter=_Meter(max_work,wall_seconds);meter.scan(base_model);meter.scan(synthesis)
        base=_model(base_model,meter)
        _need(synthesis['status']=='SOLVED','SOLVED_SYNTHESIS')
        _need(hashlib.sha256(_wire(base)).hexdigest()==synthesis['scope_sha256'],'EXACT_ORIGINAL_MODEL_SCOPE')
        ids=[r['id'] for r in base['inventory']['placements']]
        pool=set(ids)
        _need(synthesis['candidate_ids']==ids,'ACTUAL_INVENTORY_IDENTITIES')
        # Structural label-profile validation; do not run a second synthesis call.
        resolved={}
        for label in synthesis['labels']:
            meter.tick()
            _need(type(label) is dict and set(label)=={'cid','status','scope_sha256','certificate_binding_sha256'},'LABEL_FIELDS')
            _need(type(label['cid']) is str and label['cid'] in pool and label['scope_sha256']==synthesis['scope_sha256']
                  and _sha_string(label['certificate_binding_sha256']),'LABEL_SCOPE_AND_BINDING')
            _need(label['status'] in ('NEGATIVE','POSITIVE','UNKNOWN'),'LABEL_STATUS')
            if label['status']!='UNKNOWN':
                _need(label['cid'] not in resolved or resolved[label['cid']]==label['status'],'CONTRADICTORY_LABELS')
                resolved[label['cid']]=label['status']
        forbidden=sorted(c for c,s in resolved.items() if s=='NEGATIVE')
        guard=synthesis['guard_point'];_need(type(guard) is str and bool(guard),'GUARD_POINT')
        expected=dict(forbidden_cids=forbidden,extra_seed_m=[[guard,'0']] if forbidden else [],
                      extra_assignments=[dict(id=c,m=[[guard,'1']]) for c in forbidden])
        for k,v in expected.items():_need(_wire(synthesis[k])==_wire(v),'EXACT_SPARSE_PROFILE:'+k)
        guard=synthesis['guard_point'];points=set(base['roots'])
        for k in ('t','m'):points.update(p for p,v in base['seed'][k])
        for r in base['inventory']['placements']:
            for k in ('t','m'):points.update(p for p,v in r[k])
        _need(guard not in points,'FRESH_GUARD_DISJOINT_FROM_ALL_ORIGINAL_DOMAINS')
        marked=json.loads(_wire(base));control=json.loads(_wire(base))
        marked['version']+=':certified-unary-overlay-v1';control['version']+=':ordinary-unary-filter-v1'
        marked['seed']['m']=sorted(marked['seed']['m']+synthesis['extra_seed_m'])
        additions={r['id']:r['m'] for r in synthesis['extra_assignments']}
        for r in marked['inventory']['placements']:
            r['m']=sorted(r['m']+additions.get(r['id'],[]))
        control['unary_nogoods']=list(synthesis['forbidden_cids'])
        result=dict(status='CONSTRUCTED_UNVERIFIED_OVERLAY',marked_model=marked,control_model=control,
                    guard_point=guard,scope_sha256=synthesis['scope_sha256'],forbidden_cids=synthesis['forbidden_cids'],
                    warning='Structural construction only; independent scoped exhaustion/process admission required.')
        meter.scan(result);return result
    except _Stop as e:return dict(status='UNKNOWN',reason=str(e))
    except (MemoryError,RecursionError,OverflowError) as e:return dict(status='UNKNOWN',reason='HOST_RESOURCE:'+type(e).__name__)
    except (_Bad,KeyError,TypeError,ValueError,IndexError) as e:return dict(status='REJECTED',reason=str(e))
