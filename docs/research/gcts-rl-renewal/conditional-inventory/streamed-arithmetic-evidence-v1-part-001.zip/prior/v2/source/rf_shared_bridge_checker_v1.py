"""Independent complete RF-carrier to shared-catalogue mapping checker.

Standard library only. No compiler, adapter, model checker, engine or native
kernel import. RF profile generation and native ZERO truth are separate exact
receipt gates; this module verifies the entire literal bridge, not that profile.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-RF-shared-bridge-checker-v1'
CAPS = dict(max_formulas=1024, max_zero_definitions=8000,
            max_definitions=8000, max_slots=16, max_items=500000000,
            max_depth=128, wall_seconds=120.0)
SCOPE = ('All original RF formulas, native ZERO payloads and structural MP/GEN; '
         'no proof, witness, imported lemma or thinning.')


class Invalid(Exception):
    pass


class Resource(Exception):
    pass


def require(ok, reason):
    if not ok:
        raise Invalid(reason)


def nat(value, minimum=0):
    return type(value) is int and value >= minimum and value.bit_length() <= 256


def fields(value, names, reason):
    require(type(value) is dict and set(value) == set(names), reason)


def name(value):
    require(type(value) is str and bool(value), 'NONEMPTY_LITERAL_NAME')
    return value


class Meter:
    def __init__(self, items, work, seconds):
        require(nat(items, 1) and nat(work, 1), 'CHECKER_INTEGER_LIMITS')
        require(type(seconds) in (int, float) and math.isfinite(seconds)
                and 0 < seconds <= 120, 'CHECKER_WALL_LIMIT')
        self.item_limit, self.work_limit = items, work
        self.items = self.work = 0
        self.started = time.perf_counter()
        self.deadline = self.started + seconds

    def tick(self, n=1):
        self.work += n
        if self.work > self.work_limit:
            raise Resource('CHECKER_MAX_WORK')
        if time.perf_counter() >= self.deadline:
            raise Resource('CHECKER_WALL_SECONDS')

    def scan(self, value):
        def members(mapping):
            for key, item in mapping.items():
                require(type(key) is str, 'NATIVE_STRING_JSON_KEYS')
                yield key
                yield item
        pending = [(iter((value,)), 0)]
        bound = 1
        while pending:
            self.tick()
            iterator, depth = pending[-1]
            try:
                item = next(iterator)
            except StopIteration:
                pending.pop()
                continue
            if depth > 128:
                raise Resource('CHECKER_JSON_DEPTH')
            cost = 1
            if type(item) is str:
                cost += len(item)
                bound += 4 + 12 * len(item)
            elif type(item) is int:
                if item.bit_length() > 256:
                    raise Resource('CHECKER_INTEGER_BITS')
                bound += 84
            elif item is None or type(item) is bool:
                bound += 8
            elif type(item) is float:
                require(math.isfinite(item), 'FINITE_NATIVE_JSON_NUMBER')
                bound += 132
            elif type(item) is list:
                bound += 4
                pending.append((iter(item), depth + 1))
            elif type(item) is dict:
                bound += 4
                pending.append((members(item), depth + 1))
            else:
                raise Invalid('NATIVE_JSON_ONLY')
            self.items += cost
            if self.items > self.item_limit:
                raise Resource('CHECKER_MAX_ITEMS')
            self.tick(cost)
        return bound

    def wire(self, value):
        self.tick(self.scan(value))
        result = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                             separators=(',', ':'), allow_nan=False) + '\n')
        self.tick()
        return result

    def same(self, actual, expected, reason):
        require(self.wire(actual) == self.wire(expected), reason)

    def sha(self, value):
        result = hashlib.sha256(self.wire(value).encode('ascii')).hexdigest()
        self.tick()
        return result

    def counters(self):
        return dict(items=self.items, work=self.work,
                    seconds=time.perf_counter() - self.started)


def signature(value, meter):
    require(type(value) is dict, 'SIGNATURE_OBJECT')
    for symbol, arity in value.items():
        meter.tick(1 + len(symbol))
        name(symbol)
        require(nat(arity), 'SIGNATURE_NATIVE_ARITY')
    return value


def syntax(value, mode, functions, predicates, meter, depth=0):
    """Return all variable names and free names; literal syntax, no alpha map."""
    meter.tick()
    if depth > 128:
        raise Resource('CHECKER_AST_DEPTH')
    require(type(value) is list and bool(value), 'LITERAL_AST_ARRAY')
    tag = value[0]
    if mode == 'term':
        if tag == 'var':
            require(len(value) == 2, 'VARIABLE_FIELDS')
            variable = name(value[1])
            return {variable}, {variable}
        require(tag == 'fun' and len(value) == 3 and type(value[2]) is list,
                'FUNCTION_TERM_FIELDS')
        symbol = name(value[1])
        require(symbol in functions and functions[symbol] == len(value[2]),
                'FUNCTION_TERM_ARITY')
        children, child_mode = value[2], 'term'
    elif tag == 'bot':
        require(len(value) == 1, 'BOT_FIELDS')
        return set(), set()
    elif tag == 'pred':
        require(len(value) == 3 and type(value[2]) is list, 'PREDICATE_FIELDS')
        symbol = name(value[1])
        require(symbol in predicates and predicates[symbol] == len(value[2]),
                'PREDICATE_ARITY')
        children, child_mode = value[2], 'term'
    elif tag == 'eq':
        require(len(value) == 3, 'EQUALITY_FIELDS')
        children, child_mode = value[1:], 'term'
    elif tag == 'all':
        require(len(value) == 3, 'UNIVERSAL_FIELDS')
        variable = name(value[1])
        all_names, free_names = syntax(value[2], 'form', functions, predicates,
                                      meter, depth + 1)
        return all_names | {variable}, free_names - {variable}
    elif tag == 'not':
        require(len(value) == 2, 'NEGATION_FIELDS')
        children, child_mode = value[1:], 'form'
    else:
        require(tag in ('imp', 'and', 'or') and len(value) == 3,
                'BINARY_FORMULA_FIELDS')
        children, child_mode = value[1:], 'form'
    all_names, free_names = set(), set()
    for child in children:
        a, f = syntax(child, child_mode, functions, predicates, meter, depth + 1)
        all_names.update(a)
        free_names.update(f)
    return all_names, free_names


def native_payload(line, functions, predicates, meter):
    """Syntax only; no native validity or free-for proof is claimed here."""
    require(type(line) is dict, 'NATIVE_ZERO_LINE')
    rule = line.get('rule')
    layouts = dict(axiom={'rule', 'name', 'formula'},
                   tautology={'rule', 'formula'}, refl={'rule', 'formula'},
                   instantiate={'rule', 'formula', 'universal', 'term'},
                   distribute={'rule', 'formula', 'variable', 'antecedent', 'consequent'},
                   eq_subst={'rule', 'formula', 'variable', 'template', 'left', 'right'})
    require(type(rule) is str and rule in layouts, 'PRIMITIVE_ZERO_RULE')
    fields(line, layouts[rule], 'NATIVE_ZERO_PAYLOAD_FIELDS')
    names = syntax(line['formula'], 'form', functions, predicates, meter)[0]
    if rule == 'axiom':
        name(line['name'])
    if rule == 'instantiate':
        names |= syntax(line['universal'], 'form', functions, predicates, meter)[0]
        names |= syntax(line['term'], 'term', functions, predicates, meter)[0]
    if rule == 'distribute':
        names.add(name(line['variable']))
        names |= syntax(line['antecedent'], 'form', functions, predicates, meter)[0]
        names |= syntax(line['consequent'], 'form', functions, predicates, meter)[0]
    if rule == 'eq_subst':
        names.add(name(line['variable']))
        names |= syntax(line['template'], 'form', functions, predicates, meter)[0]
        names |= syntax(line['left'], 'term', functions, predicates, meter)[0]
        names |= syntax(line['right'], 'term', functions, predicates, meter)[0]
    return names


def reconstruct(declaration, compiled, generation, slots, packet, meter):
    require(type(declaration) is dict and {'id', 'problem'} <= set(declaration),
            'ORIGINAL_DECLARATION_FIELDS')
    require(not ({'proof', 'proofs', 'target_proof', 'selected', 'witness',
                  'bank', 'control_proof'} & set(declaration)), 'NO_PROOF_OR_BANK_INPUT')
    case_id = name(declaration['id'])
    if 'slots' in declaration:
        require(nat(declaration['slots'], 1) and declaration['slots'] == slots,
                'ORIGINAL_DECLARED_SHARED_SLOT_BOUND')
    problem = declaration['problem']
    fields(problem, {'theory', 'goal'}, 'ORIGINAL_STATEMENT_FIELDS')
    theory = problem['theory']
    fields(theory, {'functions', 'predicates', 'axioms'}, 'ORIGINAL_THEORY_FIELDS')
    functions = signature(theory['functions'], meter)
    predicates = signature(theory['predicates'], meter)
    require(type(theory['axioms']) is dict, 'ORIGINAL_AXIOMS')
    original_names = set()
    for key in sorted(theory['axioms']):
        meter.tick()
        name(key)
        names, free = syntax(theory['axioms'][key], 'form', functions, predicates, meter)
        require(not free, 'CLOSED_ORIGINAL_GAMMA')
        original_names.update(names)
    original_names.update(syntax(problem['goal'], 'form', functions, predicates, meter)[0])
    require(type(declaration.get('terms', [])) is list, 'DECLARED_TERMS_LIST')
    for value in declaration.get('terms', []):
        original_names.update(syntax(value, 'term', functions, predicates, meter)[0])
    fields(compiled, {'schema', 'version', 'theory', 'goal', 'goal_id', 'profile',
                      'logical_basis', 'zero_instances', 'mp_index', 'gen_index',
                      'costs', 'scope'}, 'RF_COMPILED_FIELDS')
    require(compiled['schema'] == 'V-interned-Hilbert8-basis-v1' and
            compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'RF_CARRIER_VERSION')
    meter.same(dict(theory=compiled['theory'], goal=compiled['goal']), problem,
               'UNCHANGED_ORIGINAL_STATEMENT')
    require(type(compiled['profile']) is dict and type(compiled['costs']) is dict
            and type(compiled['scope']) is str, 'RF_METADATA_SHAPES')
    lb = compiled['logical_basis']
    fields(lb, {'instantiation_terms', 'terms', 'variables', 'formulas', 'colors',
                'templates', 'hole', 'stages'}, 'RF_LOGICAL_BASIS_FIELDS')
    expected_hole = '__rf_hole'
    while expected_hole in original_names:
        meter.tick()
        expected_hole += '_'
    require(lb['hole'] == expected_hole, 'ORIGINAL_FRESH_HOLE')
    expected_variables = sorted(original_names | {expected_hole})
    meter.same(lb['variables'], expected_variables, 'ENTIRE_RF_VARIABLE_POOL_INCLUDING_HOLE')
    forms = lb['formulas']
    require(type(forms) is list and bool(forms), 'ENTIRE_RF_FORMULA_ARRAY')
    if len(forms) > CAPS['max_formulas']:
        raise Resource('BRIDGE_MAX_FORMULAS')
    keys = []
    for form in forms:
        names, _ = syntax(form, 'form', functions, predicates, meter)
        require(names <= set(expected_variables), 'RF_FORMULA_VARIABLE_POOL')
        keys.append(meter.wire(form))
    require(keys == sorted(set(keys)), 'SORTED_UNIQUE_RF_FORMULA_REGISTRY')
    meter.same(lb['colors'], [key[:-1] for key in keys], 'ENTIRE_LITERAL_RF_COLOR_REGISTRY')
    ids = {key: index for index, key in enumerate(keys)}
    goal_key = meter.wire(problem['goal'])
    require(goal_key in ids and nat(compiled['goal_id']) and
            compiled['goal_id'] == ids[goal_key], 'ORIGINAL_ZERO_BASED_GOAL_ID')
    for form in theory['axioms'].values():
        require(meter.wire(form) in ids, 'ORIGINAL_AXIOM_IN_REGISTRY')
    raw_zeros = compiled['zero_instances']
    require(type(raw_zeros) is list, 'RF_ZERO_ARRAY')
    if len(raw_zeros) > CAPS['max_zero_definitions']:
        raise Resource('BRIDGE_MAX_ZEROS')
    zero_by_id = {}
    for index, zero in enumerate(raw_zeros):
        meter.tick()
        fields(zero, {'id', 'rule', 'formula_id', 'line'}, 'RF_ZERO_FIELDS')
        require(zero['id'] == 'i' + str(index), 'ORIGINAL_RF_ZERO_ID')
        require(nat(zero['formula_id']) and zero['formula_id'] < len(forms),
                'ZERO_NATIVE_FORMULA_INDEX')
        line = zero['line']
        names = native_payload(line, functions, predicates, meter)
        require(names <= set(expected_variables), 'NATIVE_PAYLOAD_VARIABLE_POOL')
        require(zero['rule'] == line['rule'], 'UNCHANGED_NATIVE_RULE')
        meter.same(line['formula'], forms[zero['formula_id']], 'ZERO_ORIGINAL_OUTPUT')
        zero_by_id[zero['id']] = dict(id=zero['id'], native=line)
    rf_mp, rf_gen, mp, gen = [], [], [], []
    for index, form in enumerate(forms):
        meter.tick()
        if form[0] == 'imp':
            a, b = meter.wire(form[1]), meter.wire(form[2])
            require(a in ids and b in ids, 'RF_IMPLICATION_SUBFORMULA_CLOSURE')
            left, right = ids[a], ids[b]
            rf_mp.append([index, left, right])
            mp.append(dict(antecedent=left + 1, implication=index + 1, output=right + 1))
        elif form[0] == 'all':
            body = meter.wire(form[2])
            require(body in ids, 'RF_UNIVERSAL_BODY_CLOSURE')
            source = ids[body]
            rf_gen.append([index, source, form[1]])
            gen.append(dict(source=source + 1, output=index + 1, variable=form[1]))
    meter.same(compiled['mp_index'], rf_mp, 'ENTIRE_RF_STRUCTURAL_MP_INDEX')
    meter.same(compiled['gen_index'], rf_gen, 'ENTIRE_RF_STRUCTURAL_GEN_INDEX')
    mp.sort(key=lambda row: (row['antecedent'], row['implication'], row['output']))
    gen.sort(key=lambda row: (row['source'], row['output'], row['variable']))
    compiled_core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
    core_sha = meter.sha(compiled_core)
    fields(generation, {'schema', 'version', 'profile', 'compiled_core_sha256',
                        'core_stages', 'core_assertions', 'goal_receptors',
                        'bridge_premises', 'scope'}, 'RF_GENERATION_FIELDS')
    require(generation['schema'] == 'Y-goal-receptor-universe-v1' and
            generation['version'] == 'Y-GOAL-RECEPTOR-FAMILY-v1', 'RF_GENERATION_VERSION')
    meter.same(generation['profile'], compiled['profile'], 'RF_GENERATION_PROFILE')
    require(generation['compiled_core_sha256'] == core_sha, 'RF_GENERATION_CORE_BINDING')
    for key in ('core_stages', 'core_assertions', 'goal_receptors', 'bridge_premises'):
        meter.same(generation[key], [], 'RF_UNTHINNED_GENERATION_' + key)
    require(generation['scope'] == compiled['scope'], 'RF_GENERATION_SCOPE')
    fields(packet, {'schema', 'status', 'catalogue', 'mapping', 'bindings', 'census',
                    'limits', 'timings', 'admission'}, 'BRIDGE_PACKET_FIELDS')
    require(packet['schema'] == 'RF-shared-catalogue-bridge-v1' and
            packet['status'] == 'CATALOGUE_UNVERIFIED', 'BRIDGE_PACKET_STATUS')
    limits = packet['limits']
    fields(limits, CAPS, 'BRIDGE_LIMIT_FIELDS')
    for key, cap in CAPS.items():
        value = limits[key]
        if key == 'wall_seconds':
            require(type(value) in (int, float) and math.isfinite(value)
                    and 0 < value <= cap, 'BRIDGE_WALL_LIMIT')
        else:
            require(nat(value, 1) and value <= cap, 'BRIDGE_INTEGER_LIMIT_' + key)
    require(nat(slots, 1) and slots <= limits['max_slots'], 'BRIDGE_SLOT_BOUND')
    require(len(forms) <= limits['max_formulas'] and len(raw_zeros) <= limits['max_zero_definitions']
            and len(raw_zeros) + len(mp) + len(gen) <= limits['max_definitions'],
            'CLAIMED_COMPLETE_BRIDGE_LIMITS')
    declaration_sha = meter.sha(declaration)
    generation_sha = meter.sha(generation)
    profile = dict(kind='RF_FROZEN_SHARED_V1', slots=slots,
                   formula_universe_version='LITERAL_SORTED_CANONICAL_JSON_V1',
                   zero_instance_profile='RF_COMPLETE_COMPILED_NATIVE_ZERO_V1',
                   variables=lb['variables'], allow_gen=True, rf_profile=compiled['profile'])
    provenance = dict(case_id=case_id, compiler='RF-shared-catalogue-bridge-v1',
                      declaration_sha256=declaration_sha, rf_compiled_core_sha256=core_sha,
                      rf_generation_sha256=generation_sha,
                      rf_profile_sha256=meter.sha(compiled['profile']), scope=SCOPE)
    catalogue = dict(schema='Shared-fact-finite-catalogue-v1', statement=problem,
                     formulas=forms, zeros=[zero_by_id[z] for z in sorted(zero_by_id)],
                     mp=mp, gen=gen, profile=profile, provenance=provenance)
    mapping = dict(formula_ids=[[i, i + 1] for i in range(len(forms))],
                   zero_ids=[[z, z] for z in sorted(zero_by_id)])
    bindings = dict(original_statement_sha256=meter.sha(problem),
                    declaration_sha256=declaration_sha, rf_compiled_core_sha256=core_sha,
                    rf_generation_sha256=generation_sha, catalogue_sha256=meter.sha(catalogue))
    census = dict(formulas=len(forms), zeros=len(raw_zeros), mp=len(mp), gen=len(gen), slots=slots)
    for key, expected in (('catalogue', catalogue), ('mapping', mapping),
                          ('bindings', bindings), ('census', census)):
        meter.same(packet[key], expected, 'ENTIRE_BRIDGE_' + key.upper())
    fields(packet['timings'], {'seconds', 'items'}, 'BRIDGE_TIMING_FIELDS')
    require(type(packet['timings']['seconds']) in (int, float)
            and math.isfinite(packet['timings']['seconds']) and packet['timings']['seconds'] >= 0
            and nat(packet['timings']['items']), 'BRIDGE_TIMING_TYPES')
    require(type(packet['admission']) is str and bool(packet['admission']), 'BRIDGE_ADMISSION_SCOPE')
    meter.tick()
    return dict(status='VERIFIED', reason='COMPLETE_LITERAL_RF_TO_SHARED_MAPPING',
                bindings=bindings, census=census,
                external_obligations='Exact separately bound full RF profile receipt, native validity '
                                     'of every ZERO, compact-model verification and final native proof.',
                scope='All original RF formulas and native payloads, exact 0-to-1 IDs, full original '
                      'variable pool including fresh hole, and every structural MP/GEN. No RF profile '
                      'generation or native logical truth is proved by this mapping checker.')


def verify(declaration, compiled, generation, slots, packet, *, max_items=500000000,
           max_work=1000000000, wall_seconds=120.0):
    meter = None
    try:
        meter = Meter(max_items, max_work, wall_seconds)
        for value in (declaration, compiled, generation, slots, packet):
            meter.scan(value)
        if type(packet) is dict and packet.get('status') == 'UNKNOWN':
            raise Resource('UPSTREAM_BRIDGE_NOT_COMPLETE')
        result = reconstruct(declaration, compiled, generation, slots, packet, meter)
        meter.tick()
    except (Resource, MemoryError, RecursionError, OverflowError) as error:
        result = dict(status='UNKNOWN', reason=type(error).__name__ + ':' + str(error))
    except (Invalid, KeyError, TypeError, ValueError, IndexError) as error:
        result = dict(status='REJECTED', reason=type(error).__name__ + ':' + str(error))
    result.update(checker=VERSION, checker_costs={} if meter is None else meter.counters())
    return result
