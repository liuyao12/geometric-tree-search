"""Independent exhaustive tiny v3 point-assignment oracle.

Only stdlib imports. No engine/checker/learner/model-helper calls, incremental
graph, scheduler, supplied witness or training labels. Generic enumerate_model() qualifies frozen tiny E4 models only.
No full arithmetic-inventory subset enumeration is claimed.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-tiny-v3-assignment-oracle-v2'


class _Malformed(Exception):
    pass


class _Limit(Exception):
    pass


def _require(ok, reason):
    if not ok:
        raise _Malformed(reason)


class _Meter:
    def __init__(self, work, wall):
        self.work = 0
        self.limit = work
        self.deadline = time.perf_counter() + wall
        self.bytes_reserved = 0

    def tick(self, n=1):
        self.work += n
        if self.work > self.limit:
            raise _Limit('MAX_WORK')
        if time.perf_counter() >= self.deadline:
            raise _Limit('WALL_SECONDS')

    def scan(self, value):
        def members(d):
            for k,v in d.items():
                _require(type(k) is str, 'STRING_DICTIONARY_KEY')
                yield k
                yield v
        stack = [(iter((value,)), 0)]
        bound = 1
        while stack:
            self.tick()
            it, depth = stack[-1]
            try:
                x = next(it)
            except StopIteration:
                stack.pop()
                continue
            if depth > 64:
                raise _Limit('JSON_DEPTH')
            if type(x) is str:
                self.tick(len(x))
                bound += 4 + 12 * len(x)
            elif type(x) is int:
                _require(x.bit_length() <= 256, 'INTEGER_BITS')
                self.tick(x.bit_length())
                bound += 84
            elif x is None or type(x) is bool:
                bound += 8
            elif type(x) is list:
                bound += 4
                stack.append((iter(x), depth + 1))
            elif type(x) is dict:
                bound += 4
                stack.append((members(x), depth + 1))
            else:
                raise _Malformed('NATIVE_JSON_ONLY')
        return bound

    def reserve(self, value):
        bound = self.scan(value)
        self.tick(bound)
        self.bytes_reserved += bound

    def sha(self, value):
        self.reserve(value)
        raw = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        self.tick()
        return hashlib.sha256(raw).hexdigest()


def _fields(value, names):
    _require(type(value) is dict and set(value) == set(names),
             'EXACT_FIELDS:' + ','.join(sorted(names)))


def _rows(value, capacity, meter, marking=False, seed=False):
    _require(type(value) is list, 'POINT_ROWS_LIST')
    out = {}
    for row in value:
        meter.tick()
        _require(type(row) is list and len(row) == 2 and type(row[0]) is str
                 and row[0] not in out, 'DISTINCT_LITERAL_POINT_ROW')
        p,v = row
        if marking:
            _require(type(v) is str, 'LITERAL_MARKING_VALUE')
        else:
            _require(type(v) is int and (0 if seed else 1) <= v <= capacity
                     and v.bit_length() <= 256, 'EXACT_CAPACITY_UNITS')
        out[p] = v
    meter.tick(len(out) * max(1, len(out).bit_length()))
    return [[p,out[p]] for p in sorted(out)]


def _normalize(model, max_candidates, meter):
    _fields(model, {'schema','version','capacity','roots','seed','inventory','pair_nogoods','unary_nogoods'})
    _require(model['schema'] == 'Z-growing-point-model-v3'
             and type(model['version']) is str and bool(model['version']), 'MODEL_VERSION')
    c = model['capacity']
    _require(type(c) is int and c >= 1 and c.bit_length() <= 256, 'CAPACITY')
    roots = model['roots']
    _require(type(roots) is list and all(type(p) is str for p in roots)
             and len(roots) == len(set(roots)), 'DISTINCT_LITERAL_ROOTS')
    _fields(model['seed'], {'t','m'})
    seed = dict(t=_rows(model['seed']['t'],c,meter,seed=True),
                m=_rows(model['seed']['m'],c,meter,marking=True))
    _fields(model['inventory'], {'kind','placements'})
    raw = model['inventory']['placements']
    _require(model['inventory']['kind'] == 'EXPLICIT' and type(raw) is list, 'EXPLICIT_ONLY')
    if len(raw) > max_candidates:
        raise _Limit('MAX_CANDIDATES')
    rows = {}
    for r in raw:
        meter.tick()
        _fields(r, {'id','t','m'})
        cid = r['id']
        _require(type(cid) is str and bool(cid) and cid not in rows, 'UNIQUE_NONEMPTY_CID')
        t = _rows(r['t'],c,meter)
        _require(bool(t), 'POSITIVE_SUPPORT_REQUIRED')
        rows[cid] = dict(id=cid,t=t,m=_rows(r['m'],c,meter,marking=True))
    meter.tick(len(rows) * max(1,len(rows).bit_length()))
    pairs = _canonical_pairs(model['pair_nogoods'],set(rows),meter)
    unary = model['unary_nogoods']
    _require(type(unary) is list and all(type(c) is str and c in rows for c in unary), 'KNOWN_UNARY_CIDS')
    _require(unary == sorted(set(unary)), 'SORTED_UNIQUE_UNARY_CIDS')
    meter.tick(1+len(unary))
    return dict(schema=model['schema'],version=model['version'],capacity=c,roots=sorted(roots),
                seed=seed,inventory=dict(kind='EXPLICIT',placements=[rows[x] for x in sorted(rows)]),
                pair_nogoods=pairs,unary_nogoods=list(unary))


def _canonical_pairs(value, ids, meter):
    _require(type(value) is list, 'PAIR_NOGOODS_LIST')
    pairs = []
    for pair in value:
        meter.tick()
        _require(type(pair) is list and len(pair)==2 and all(type(x) is str for x in pair)
                 and pair[0] < pair[1] and all(x in ids for x in pair), 'CANONICAL_TWO_DISTINCT_CIDS')
        pairs.append(list(pair))
    _require(pairs == sorted(pairs) and len({tuple(x) for x in pairs}) == len(pairs),
             'CANONICAL_UNIQUE_SORTED_PAIR_LIST')
    return pairs


def _sums(model, chosen, meter):
    meter.tick(1+len(model['seed']['t'])+len(model['roots']))
    t = dict(model['seed']['t'])
    active = set(model['roots']) | {p for p,n in model['seed']['t'] if n > 0}
    rows = model['inventory']['placements']
    for i in chosen:
        for p,n in rows[i]['t']:
            meter.tick()
            t[p] = t.get(p,0) + n
            active.add(p)
    return t,active,all(n <= model['capacity'] for n in t.values())


def _literal_marks(model, chosen, meter, export=False):
    groups = {}
    for p,v in model['seed']['m']:
        meter.tick(1+len(p)+len(v))
        groups[p] = {v:1}
    rows = model['inventory']['placements']
    for i in chosen:
        for p,v in rows[i]['m']:
            meter.tick(1+len(p)+len(v))
            at = groups.setdefault(p,{})
            at[v] = at.get(v,0) + 1
    compatible = all(len(at)==1 for at in groups.values())
    if not export:
        return compatible
    return compatible,[[p,[[v,n] for v,n in sorted(groups[p].items())]] for p in sorted(groups)]


def _pair_free(pair_indices, chosen, meter):
    meter.tick(1+len(chosen))
    selected = set(chosen)
    answer = True
    for i,j in pair_indices:
        meter.tick()
        if i in selected and j in selected:
            answer = False
    return answer


def _reachable(model, chosen, meter):
    meter.tick(1+len(model['roots'])+len(model['seed']['t']))
    reached = set(model['roots']) | {p for p,n in model['seed']['t'] if n > 0}
    rows = model['inventory']['placements']
    pending = list(chosen)
    while pending:
        rest = []
        for i in pending:
            meter.tick(1+len(rows[i]['t']))
            if any(p in reached for p,n in rows[i]['t']):
                reached.update(p for p,n in rows[i]['t'])
            else:
                rest.append(i)
        if len(rest) == len(pending):
            return False
        pending = rest
    return True


def enumerate_model(model, *, max_candidates=16, max_subsets=65536,
                    wall_seconds=10, max_work=10000000):
    """Generic complete tiny v3 assignment enumerator for qualification.

    Ordinary seed/per-CID literal markings and canonical pair_nogoods are
    allowed. No engine/checker/model helper or expected solution is an argument.
    Unary and binary filters are declared constraints, not proved redundant here.
    EXHAUSTED means every subset was checked; UNKNOWN never decides absence.
    """
    started = time.perf_counter()
    meter = None
    normalized = None
    binding = None
    ids = []
    total = None
    states = []
    solutions = []
    counts = dict(subsets_checked=0,capacity_legal_subsets=0,legal_partial_subsets=0,
                  reachable_legal_partial_subsets=0,candidate_extensions_checked=0,
                  domain_states_checked=0)

    def finish(status,reason):
        return dict(schema='Finite-point-assignment-enumeration-v1',oracle=VERSION,
                    status=status,reason=reason,exists=bool(solutions) if status=='EXHAUSTED' else None,
                    witness_exists=bool(solutions),seconds=time.perf_counter()-started,
                    work=0 if meter is None else meter.work,
                    evidence_byte_reservation=0 if meter is None else meter.bytes_reserved,
                    model=normalized,model_sha256=binding,candidate_ids=ids,subsets_total=total,
                    subsets_coverage='COMPLETE' if total is not None and counts['subsets_checked']==total else 'PREFIX',
                    counts=counts,solutions=solutions,subsets=states,
                    scope='Complete fixed finite v3 EXPLICIT assignment existence with positive-support '
                          'root reachability and exact growing active coverage. No scheduler, generation, '
                          'rollback, geometric, native proof or infinite-domain claim.')

    try:
        for name,v,lo,hi in [('max_candidates',max_candidates,0,16),
                             ('max_subsets',max_subsets,0,65536),
                             ('max_work',max_work,0,1000000000)]:
            _require(type(v) is int and lo <= v <= hi, 'LIMIT_' + name)
        _require(type(wall_seconds) in (int,float) and math.isfinite(wall_seconds)
                 and 0 < wall_seconds <= 60, 'LIMIT_wall_seconds')
        meter = _Meter(max_work,wall_seconds)
        meter.scan(model)
        normalized = _normalize(model,max_candidates,meter)
        binding = meter.sha(normalized)
        rows = normalized['inventory']['placements']
        ids = [r['id'] for r in rows]
        index = {cid:i for i,cid in enumerate(ids)}
        weights = [dict(r['t']) for r in rows]
        pairs = [(index[a],index[b]) for a,b in normalized['pair_nogoods']]
        forbidden = {index[c] for c in normalized['unary_nogoods']}
        total = 1 << len(ids)
        for mask in range(total):
            meter.tick()
            if counts['subsets_checked'] >= max_subsets:
                raise _Limit('MAX_SUBSETS')
            chosen = [i for i in range(len(ids)) if mask & (1 << i)]
            selected = set(chosen)
            t,active,cap_ok = _sums(normalized,chosen,meter)
            mark_ok,mark_state = _literal_marks(normalized,chosen,meter,export=True)
            pair_ok = _pair_free(pairs,chosen,meter)
            attached = _reachable(normalized,chosen,meter)
            meter.tick(1+len(forbidden))
            unary_ok = not (selected & forbidden)
            legal = cap_ok and mark_ok and pair_ok and unary_ok
            exact = legal and attached and all(t.get(p,0)==normalized['capacity'] for p in active)
            state = dict(mask=mask,selected=[ids[i] for i in chosen],capacity_legal=cap_ok,
                         literal_mark_compatible=mark_ok,pair_nogood_free=pair_ok,unary_nogood_free=unary_ok,
                         literal_mark_state=mark_state,legal_partial=legal,root_reachable=attached,
                         totals=[[p,t[p]] for p in sorted(t)],active_points=sorted(active),
                         solution=exact,eligible=None,domains=None,edges=None)
            if cap_ok:
                counts['capacity_legal_subsets'] += 1
                counts['legal_partial_subsets'] += legal
                counts['reachable_legal_partial_subsets'] += legal and attached
                counts['domain_states_checked'] += 1
                eligible = []
                for i,cid in enumerate(ids):
                    meter.tick()
                    if i in selected:
                        continue
                    counts['candidate_extensions_checked'] += 1
                    capacity_ok = True
                    for p,n in rows[i]['t']:
                        meter.tick()
                        if t.get(p,0)+n > normalized['capacity']:
                            capacity_ok = False
                    marking_ok = _literal_marks(normalized,chosen+[i],meter)
                    nogood_ok = _pair_free(pairs,chosen+[i],meter)
                    meter.tick()
                    unary_free = not ((selected | {i}) & forbidden)
                    if capacity_ok and marking_ok and nogood_ok and unary_free:
                        eligible.append(cid)
                domains,edges = [],[]
                for p in sorted(p for p in active if t.get(p,0) < normalized['capacity']):
                    incident = []
                    for cid in eligible:
                        meter.tick()
                        i = index[cid]
                        if p in weights[i]:
                            incident.append(cid)
                            edges.append([p,cid,weights[i][p]])
                    domains.append([p,incident])
                state.update(eligible=eligible,domains=domains,edges=edges)
            if exact:
                solution = dict(mask=mask,selected=list(state['selected']))
                meter.reserve(solution)
                solutions.append(solution)
            meter.reserve(state)
            states.append(state)
            counts['subsets_checked'] += 1
        meter.tick()
        return finish('EXHAUSTED','COMPLETE_FINITE_POINT_ASSIGNMENT_ENUMERATION')
    except _Limit as error:
        return finish('UNKNOWN',str(error))
    except (MemoryError,RecursionError,OverflowError) as error:
        return finish('UNKNOWN','HOST_RESOURCE:' + type(error).__name__)
    except (_Malformed,KeyError,TypeError,ValueError,IndexError,AttributeError) as error:
        return finish('REJECTED','MALFORMED_MODEL_OR_LIMIT:' + str(error))
