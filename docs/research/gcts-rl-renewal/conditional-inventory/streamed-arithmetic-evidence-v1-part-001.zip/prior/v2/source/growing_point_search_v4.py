"""Finite growing point obligations; inert Source, no project dependencies.

An eager provider enumerates all potential contacts; an indexed provider may
return the complete current t/m-compatible contact set. Unseen completeness is
an external Source/qualification obligation, never proved by a complete flag.
Forward-monotone incompatibility plus trailed discovery/exhaustion makes the
indexed omission safe. Selection and branch exclusions stay in the base engine.

Version4 admits explicit unary and binary incompatibilities as conventional
filter controls. They are model-bound input, not learned or proof-justified
by this engine. Literal markings retain their existing separate point machinery.
"""
import hashlib
import json
import math
import time
from types import MappingProxyType

VERSION = 'IP-GROWING-POINT-SEARCH-v4'
INDEXED_ABI = 'IP-CURRENT-TM-INCIDENT-v1'


class InputError(ValueError):
    pass


class InventoryError(ValueError):
    pass


class OrderingError(ValueError):
    pass


class InvariantError(RuntimeError):
    pass


class _Stop(Exception):
    pass


def _need(condition, message, error=InputError):
    if not condition:
        raise error(message)


def _integer(value, minimum=0):
    return type(value) is int and value >= minimum and value.bit_length() <= 256


def _limits(value):
    names = ('wall_seconds', 'max_work', 'max_nodes', 'max_events',
             'max_rollback_records', 'max_candidates', 'max_points')
    _need(type(value) is dict and len(value) == len(names)
          and set(value) == set(names), 'exact limits7')
    seconds = value['wall_seconds']
    _need(type(seconds) in (int, float) and 0 < seconds <= 3600
          and math.isfinite(seconds), 'finite positive wall_seconds <=3600')
    for name in names[1:]:
        minimum = 1 if name in ('max_work', 'max_candidates', 'max_points') else 0
        _need(_integer(value[name], minimum), 'bounded exact integer limit: ' + name)
    return {name: value[name] for name in names}


class _Meter:
    def __init__(self, limits, started):
        self.limits = limits
        self.started = started
        self.work = 0
        self.nodes = 0
        self.reason = None

    def stop(self, reason):
        self.reason = reason
        raise _Stop(reason)

    def tick(self, amount=1):
        _need(_integer(amount), 'charge exact nonnegative integer')
        if self.reason is not None:
            raise _Stop(self.reason)
        if time.perf_counter() - self.started >= self.limits['wall_seconds']:
            self.stop('WALL_SECONDS')
        if amount > self.limits['max_work'] - self.work:
            self.stop('MAX_WORK')
        self.work += amount

    def node(self):
        self.tick()
        if self.nodes >= self.limits['max_nodes']:
            self.stop('MAX_NODES')
        self.nodes += 1


def _charge(meter, amount=1):
    if meter is not None:
        meter.tick(amount)


def _fields(value, names, meter, error=InputError):
    _need(type(value) is dict, 'exact dictionary', error)
    _charge(meter, 2 + len(value))
    _need(len(value) == len(names) and all(type(k) is str for k in value)
          and set(value) == set(names), 'exact dictionary fields', error)


def _string(value, meter, nonempty=False, error=InputError):
    _need(type(value) is str, 'literal string', error)
    _charge(meter, 2 + 12 * len(value))
    _need(not nonempty or bool(value), 'nonempty string', error)
    return value


def _rows(value, capacity, marking, meter, error=InputError, seed=False):
    _need(type(value) is list, 'point rows list', error)
    _charge(meter, 2 + 2 * len(value))
    rows, seen = [], set()
    for row in value:
        _need(type(row) is list and len(row) == 2, 'point row2', error)
        point = _string(row[0], meter, error=error)
        _need(point not in seen, 'duplicate point row', error)
        seen.add(point)
        if marking:
            item = _string(row[1], meter, error=error)
        else:
            item = row[1]
            _need(_integer(item, 0 if seed else 1) and item <= capacity,
                  'exact capacity units', error)
            _charge(meter, 3 + item.bit_length())
        rows.append([point, item])
    _charge(meter, len(rows) * (1 + len(rows).bit_length()))
    rows.sort(key=lambda row: row[0])
    return rows


def _placement(value, capacity, meter, error=InputError):
    _fields(value, ('id', 't', 'm'), meter, error)
    cid = _string(value['id'], meter, True, error)
    t = _rows(value['t'], capacity, False, meter, error)
    _need(bool(t), 'nonempty positive support', error)
    marks = _rows(value['m'], capacity, True, meter, error)
    return {'id': cid, 't': t, 'm': marks}


def _model(value, meter):
    _fields(value, ('schema', 'version', 'capacity', 'roots', 'seed', 'inventory',
                    'pair_nogoods', 'unary_nogoods'), meter)
    _need(value['schema'] == 'Z-growing-point-model-v3', 'model schema')
    version = _string(value['version'], meter, True)
    capacity = value['capacity']
    _need(_integer(capacity, 1), 'positive exact capacity')
    _need(type(value['roots']) is list, 'root point list')
    _charge(meter, 2 + len(value['roots']))
    roots, seen = [], set()
    for p in value['roots']:
        p = _string(p, meter)
        _need(p not in seen, 'duplicate root')
        roots.append(p)
        seen.add(p)
    _charge(meter, len(roots) * (1 + len(roots).bit_length()))
    roots.sort()
    _fields(value['seed'], ('t', 'm'), meter)
    seed = {'t': _rows(value['seed']['t'], capacity, False, meter, seed=True),
            'm': _rows(value['seed']['m'], capacity, True, meter)}
    inventory = value['inventory']
    _need(type(inventory) is dict, 'inventory dictionary')
    _charge(meter, 2 + len(inventory))
    if inventory.get('kind') == 'EXPLICIT':
        _fields(inventory, ('kind', 'placements'), meter)
        _need(type(inventory['placements']) is list, 'explicit placement list')
        _charge(meter, 2 + len(inventory['placements']))
        if len(inventory['placements']) > meter.limits['max_candidates']:
            meter.stop('MAX_CANDIDATES')
        placements, ids = [], set()
        for value_row in inventory['placements']:
            row = _placement(value_row, capacity, meter)
            _need(row['id'] not in ids, 'duplicate explicit placement ID')
            ids.add(row['id'])
            placements.append(row)
        _charge(meter, len(placements) * (1 + len(placements).bit_length()))
        placements.sort(key=lambda row: row['id'])
        inventory = {'kind': 'EXPLICIT', 'placements': placements}
    else:
        _fields(inventory, ('kind', 'identity'), meter)
        _need(inventory['kind'] == 'CERTIFIED_INCIDENT', 'declared inventory kind')
        inventory = {'kind': 'CERTIFIED_INCIDENT',
                     'identity': _string(inventory['identity'], meter, True)}
    pairs = value['pair_nogoods']
    _need(type(pairs) is list, 'mandatory pair_nogoods list')
    _charge(meter, 2 + len(pairs))
    _need(inventory['kind'] == 'EXPLICIT' or not pairs,
          'nonempty pair_nogoods require EXPLICIT inventory')
    pair_nogoods, previous = [], None
    for pair in pairs:
        _need(type(pair) is list and len(pair) == 2, 'pair_nogood2')
        left = _string(pair[0], meter, True)
        right = _string(pair[1], meter, True)
        _charge(meter, 3 + len(left) + len(right))
        _need(left < right and left in ids and right in ids,
              'distinct sorted known explicit pair IDs')
        key = (left, right)
        _need(previous is None or previous < key, 'sorted unique pair_nogoods')
        previous = key
        pair_nogoods.append([left, right])
    unary = value['unary_nogoods']
    _need(type(unary) is list, 'mandatory unary_nogoods list')
    _charge(meter, 2 + len(unary))
    _need(inventory['kind'] == 'EXPLICIT' or not unary,
          'nonempty unary_nogoods require EXPLICIT inventory')
    unary_nogoods, previous = [], None
    for item in unary:
        cid = _string(item, meter, True)
        _need(cid in ids and (previous is None or previous < cid),
              'sorted unique known unary CID')
        unary_nogoods.append(cid)
        previous = cid
    return {'schema': 'Z-growing-point-model-v3', 'version': version,
            'capacity': capacity, 'roots': roots, 'seed': seed, 'inventory': inventory,
            'pair_nogoods': pair_nogoods, 'unary_nogoods': unary_nogoods}


def _bound(value, meter):
    """Reserve a conservative complete canonical-byte bound BEFORE dumps."""
    if value is None or type(value) is bool:
        amount = 5
    elif type(value) is int:
        amount = 3 + value.bit_length()
    elif type(value) is float:
        _need(math.isfinite(value), 'finite metadata float')
        amount = 32
    elif type(value) is str:
        amount = 2 + 12 * len(value)
    elif type(value) is list:
        _charge(meter, 2 + len(value))
        for item in value:
            _bound(item, meter)
        return
    elif type(value) is dict:
        _charge(meter, 2 + 2 * len(value))
        for key, item in value.items():
            _bound(key, meter)
            _bound(item, meter)
        return
    else:
        raise InvariantError('non-JSON internal value')
    _charge(meter, amount)


def _wire(value, meter=None):
    _charge(meter, 1)  # final LF
    _bound(value, meter)
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _digest(value, meter=None):
    return hashlib.sha256(_wire(value, meter)).hexdigest()


def _stats():
    names = ('placements', 'forced', 'branches', 'dead_ends', 'backtracks',
             'exclusions', 'legality_checks', 'candidate_registrations',
             'provider_calls', 'provider_rows', 'edge_additions', 'edge_removals',
             'dependency_links', 'peak_frontier', 'peak_Q', 'peak_candidates',
             'peak_edges', 'peak_trail', 'events_total', 'rollbacks_total',
             'rollback_edits', 'audit_calls', 'ordering_calls')
    return {name: 0 for name in names}


class _State:
    def __init__(self, model, meter, provider, stats):
        self.model = model
        self.meter = meter
        self.provider = provider
        self.stats = stats
        self.capacity = model['capacity']
        declared = None if provider is None else getattr(provider, 'incident_query_abi', None)
        _need(declared is None or type(declared) is str and declared == INDEXED_ABI,
              'supported provider incident_query_abi')
        _need(declared is None or model['inventory']['kind'] == 'CERTIFIED_INCIDENT',
              'indexed provider requires certified incident inventory')
        self.indexed = declared is not None
        self.query_records = []
        self.query_count = 0
        self.query_hash = hashlib.sha256()
        self.index_costs = {'query_attempts': 0, 'query_work': 0,
                            'query_seconds': 0.0, 'receipt_work': 0,
                            'potential_contacts': 0, 'returned_contacts': 0,
                            'context_values': 0}
        self.placements = {}
        self.tdep = {}
        self.mdep = {}
        self.totals = {}
        self.Q = {}
        self.selected = {}
        self.marks = {}
        self.excluded = set()
        self.eligible = set()
        self.domains = {}
        self.reverse = {}
        self.loaded = set()
        self.trail = []
        self.edges = 0
        # Immutable model-bound dependency index; no branch-local state here.
        pair_neighbors = {}
        meter.tick(1 + len(model['pair_nogoods']))
        for left, right in model['pair_nogoods']:
            meter.tick(2)
            pair_neighbors.setdefault(left, []).append(right)
            pair_neighbors.setdefault(right, []).append(left)
        immutable_neighbors = {}
        for cid, neighbors in pair_neighbors.items():
            meter.tick(1 + len(neighbors) * (1 + len(neighbors).bit_length()))
            immutable_neighbors[cid] = tuple(sorted(neighbors))
        self.pair_neighbors = MappingProxyType(immutable_neighbors)
        meter.tick(1 + len(model['unary_nogoods']))
        self.unary_nogoods = frozenset(model['unary_nogoods'])
        self.rollbacks = []
        self.rollback_hash = hashlib.sha256()
        self.rollback_count = 0

    def _map(self, mapping, key, value):
        self.meter.tick()
        existed = key in mapping
        old = mapping.get(key)
        if existed and old == value:
            return
        self.trail.append(('map', mapping, key, existed, old))
        mapping[key] = value
        self.stats['peak_trail'] = max(self.stats['peak_trail'], len(self.trail))

    def _delete(self, mapping, key):
        if key in mapping:
            self.meter.tick()
            self.trail.append(('map', mapping, key, True, mapping[key]))
            del mapping[key]
            self.stats['peak_trail'] = max(self.stats['peak_trail'], len(self.trail))

    def _set(self, target, key, present):
        if (key in target) == present:
            return
        self.meter.tick()
        self.trail.append(('set', target, key, not present))
        if present:
            target.add(key)
        else:
            target.remove(key)
        self.stats['peak_trail'] = max(self.stats['peak_trail'], len(self.trail))

    def _bucket(self, index, point):
        if point not in index:
            self._map(index, point, set())
        return index[point]

    def _edge(self, point, cid, present):
        domain = self.domains[point]
        if (cid in domain) == present:
            return
        self._set(domain, cid, present)
        reverse = self._bucket(self.reverse, cid)
        self._set(reverse, point, present)
        self.meter.tick()
        self.trail.append(('edges', self.edges))
        self.edges += 1 if present else -1
        self.stats['edge_additions' if present else 'edge_removals'] += 1
        self.stats['peak_edges'] = max(self.stats['peak_edges'], self.edges)
        self.stats['peak_trail'] = max(self.stats['peak_trail'], len(self.trail))
        if not reverse:
            self._delete(self.reverse, cid)

    def _compatible(self, row):
        # Pure t/m predicate. Callers reserve work before traversing supports.
        for point, units in row['t']:
            if self.totals.get(point, 0) + units > self.capacity:
                return False
        for point, value in row['m']:
            if point in self.marks and self.marks[point][0] != value:
                return False
        return True

    def _legal(self, row):
        self.stats['legality_checks'] += 1
        self.meter.tick(1 + len(row['t']) + len(row['m']))
        if row['id'] in self.selected or row['id'] in self.excluded:
            return False
        self.meter.tick()
        if row['id'] in self.unary_nogoods:
            return False
        neighbors = self.pair_neighbors.get(row['id'], ())
        self.meter.tick(len(neighbors))
        if any(cid in self.selected for cid in neighbors):
            return False
        return self._compatible(row)

    def _refresh(self, cid):
        legal = self._legal(self.placements[cid])
        if legal == (cid in self.eligible):
            return
        self._set(self.eligible, cid, legal)
        for point, units in self.placements[cid]['t']:
            if point in self.domains:
                self._edge(point, cid, legal)

    def _register(self, row):
        cid = row['id']
        if cid in self.placements:
            self.meter.tick(1 + len(row['t']) + len(row['m']))
            _need(self.placements[cid] == row, 'provider changed placement identity', InventoryError)
            return
        if len(self.placements) >= self.meter.limits['max_candidates']:
            self.meter.stop('MAX_CANDIDATES')
        self.meter.tick(1 + len(row['t']) + len(row['m']))
        if self.model['inventory']['kind'] == 'CERTIFIED_INCIDENT':
            _need(all(p not in self.loaded for p, units in row['t']),
                  'new CID touches previously exhausted point', InventoryError)
        self._map(self.placements, cid, row)
        for point, units in row['t']:
            self._set(self._bucket(self.tdep, point), cid, True)
            self.stats['dependency_links'] += 1
        for point, value in row['m']:
            self._set(self._bucket(self.mdep, point), cid, True)
            self.stats['dependency_links'] += 1
        self.stats['candidate_registrations'] += 1
        self.stats['peak_candidates'] = max(self.stats['peak_candidates'], len(self.placements))
        self._refresh(cid)

    def _indexed_reply(self, point):
        """Validate a complete context-compatible query, before certifying load.

        The provider's unseen completeness is an external Source/qualification
        obligation. A true flag/count is not itself a proof of that obligation.
        """
        meter = self.meter
        before_work, before_time = meter.work, time.perf_counter()
        self.index_costs['query_attempts'] += 1
        try:
            count = len(self.totals) + len(self.marks)
            meter.tick(2 + count * (1 + count.bit_length()))
            query = {'schema': 'IP-current-tm-incident-query-v1',
                     'inventory_identity': self.model['inventory']['identity'],
                     'point': point, 'capacity': self.capacity,
                     'totals': [[p, n] for p, n in sorted(self.totals.items())],
                     'marks': [[p, v] for p, (v, n) in sorted(self.marks.items())]}
            encoded_query = _wire(query, meter)
            expected_hash = hashlib.sha256(encoded_query).hexdigest()
            # Callback receives a detached copy; retained query cannot be mutated.
            reply = self.provider(json.loads(encoded_query), meter.tick)
            meter.tick()  # swallowed owned refusal stays sticky
            _fields(reply, ('point', 'context_sha256', 'complete', 'placements',
                            'certificate'), meter, InventoryError)
            _need(_string(reply['point'], meter, error=InventoryError) == point,
                  'indexed response point binding', InventoryError)
            _need(_string(reply['context_sha256'], meter, error=InventoryError)
                  == expected_hash, 'indexed response context binding', InventoryError)
            _need(reply['complete'] is True and type(reply['placements']) is list,
                  'complete indexed response', InventoryError)
            cert = reply['certificate']
            _fields(cert, ('scope', 'potential_count', 'compatible_count'), meter,
                    InventoryError)
            _need(type(cert['scope']) is str
                  and cert['scope'] == 'COMPLETE_CURRENT_TM_COMPATIBLE_INCIDENT_SET'
                  and _integer(cert['potential_count'])
                  and _integer(cert['compatible_count'])
                  and cert['compatible_count'] == len(reply['placements'])
                  and cert['potential_count'] >= cert['compatible_count'],
                  'indexed exact contact-count certificate', InventoryError)
            meter.tick(2 + len(reply['placements']))
            if len(reply['placements']) > meter.limits['max_candidates']:
                meter.stop('MAX_CANDIDATES')
            rows, seen = [], set()
            for value in reply['placements']:
                row = _placement(value, self.capacity, meter, InventoryError)
                meter.tick(1 + len(row['t']) + len(row['m']))
                _need(row['id'] not in seen
                      and any(p == point for p, units in row['t'])
                      and self._compatible(row),
                      'unique incident globally t/m-compatible row', InventoryError)
                seen.add(row['id'])
                rows.append(row)
            normalized = {'point': point, 'context_sha256': expected_hash,
                          'complete': True, 'placements': rows,
                          'certificate': {'scope': cert['scope'],
                                          'potential_count': cert['potential_count'],
                                          'compatible_count': cert['compatible_count']}}
            self.index_costs['potential_contacts'] += cert['potential_count']
            self.index_costs['returned_contacts'] += len(rows)
            self.index_costs['context_values'] += count
        finally:
            self.index_costs['query_work'] += meter.work - before_work
            self.index_costs['query_seconds'] += time.perf_counter() - before_time
        record = {'query': query, 'reply': normalized}
        before_receipt = meter.work
        try:
            encoded = _wire(record, meter)
        finally:
            self.index_costs['receipt_work'] += meter.work - before_receipt
        self.query_hash.update(encoded)
        self.query_count += 1
        if len(self.query_records) < meter.limits['max_events']:
            self.query_records.append(record)
        return rows

    def provider_evidence(self):
        mode = ('EXPLICIT' if self.model['inventory']['kind'] == 'EXPLICIT' else
                'INDEXED_CURRENT_TM_COMPATIBLE' if self.indexed else
                'EAGER_ALL_POTENTIAL')
        return {'mode': mode, 'total': self.query_count,
                'retained': len(self.query_records),
                'sha256': self.query_hash.hexdigest(),
                'scope': 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES',
                'records': list(self.query_records), 'costs': dict(self.index_costs)}

    def _load(self, point):
        if point in self.loaded:
            return
        if self.model['inventory']['kind'] == 'CERTIFIED_INCIDENT':
            self.stats['provider_calls'] += 1
            self.meter.tick()
            if self.indexed:
                rows = self._indexed_reply(point)
                seen = set()
                for row in rows:
                    self.meter.tick(1 + len(row['t']))
                    seen.add(row['id'])
                    self.stats['provider_rows'] += 1
                    self._register(row)
                known = set()
                self.meter.tick(1 + len(self.tdep.get(point, ())))
                for cid in self.tdep.get(point, ()):
                    row = self.placements[cid]
                    self.meter.tick(1 + len(row['t']) + len(row['m']))
                    if self._compatible(row):
                        known.add(cid)
                _need(seen == known, 'indexed provider omitted known compatible contact',
                      InventoryError)
            else:
                reply = self.provider(point, self.meter.tick)
                self.meter.tick()  # refusal remains sticky if callback swallowed it
                _fields(reply, ('point', 'complete', 'placements'), self.meter, InventoryError)
                response_point = _string(reply['point'], self.meter, error=InventoryError)
                _need(response_point == point
                      and reply['complete'] is True and type(reply['placements']) is list,
                      'complete state-independent incident response', InventoryError)
                count = len(reply['placements'])
                self.meter.tick(2 + count)
                seen = set()
                for value in reply['placements']:
                    row = _placement(value, self.capacity, self.meter, InventoryError)
                    self.meter.tick(1 + len(row['t']))
                    _need(any(p == point for p, units in row['t']) and row['id'] not in seen,
                          'unique incident placement required', InventoryError)
                    seen.add(row['id'])
                    self.stats['provider_rows'] += 1
                    self._register(row)
                self.meter.tick(1 + len(seen) + len(self.tdep.get(point, ())))
                _need(seen == self.tdep.get(point, set()),
                      'provider omitted already known incident placement', InventoryError)
        self._set(self.loaded, point, True)
        self.meter.tick(1 + len(self.tdep.get(point, ())))
        for cid in self.tdep.get(point, ()):
            if cid in self.eligible:
                self._edge(point, cid, True)

    def _point(self, point, generation):
        if point not in self.totals:
            self._map(self.totals, point, 0)
        if point not in self.Q:
            if len(self.Q) >= self.meter.limits['max_points']:
                self.meter.stop('MAX_POINTS')
            self._map(self.Q, point, generation)
        elif generation < self.Q[point]:
            self._map(self.Q, point, generation)
        self.stats['peak_Q'] = max(self.stats['peak_Q'], len(self.Q))

    def _sync_point(self, point):
        if self.totals.get(point, 0) == self.capacity:
            if point in self.domains:
                self.meter.tick(1 + len(self.domains[point]))
                for cid in list(self.domains[point]):
                    self._edge(point, cid, False)
                self._delete(self.domains, point)
        else:
            if point not in self.domains:
                self._map(self.domains, point, set())
            self._load(point)
        self.stats['peak_frontier'] = max(self.stats['peak_frontier'], len(self.domains))

    def initialize(self):
        for point, units in self.model['seed']['t']:
            self._map(self.totals, point, units)
            if units:
                self._point(point, 0)
        for point in self.model['roots']:
            self._point(point, 0)
        for point, value in self.model['seed']['m']:
            self._map(self.marks, point, (value, 1))
        if self.model['inventory']['kind'] == 'EXPLICIT':
            for row in self.model['inventory']['placements']:
                self._register(row)
        self.meter.tick(1 + len(self.Q))
        for point in sorted(self.Q):
            self._sync_point(point)
        self.trail.clear()  # complete immutable entry context, no search deltas yet

    def place(self, cid):
        _need(cid in self.eligible, 'chosen candidate is not globally eligible', InvariantError)
        row = self.placements[cid]
        self.meter.tick(1 + len(row['t']))
        generations = [self.Q[p] for p, units in row['t'] if p in self.Q]
        _need(bool(generations), 'placement must touch active frontier', InvariantError)
        generation = 1 + min(generations)
        self._map(self.selected, cid, generation)
        for point, units in row['t']:
            self._map(self.totals, point, self.totals.get(point, 0) + units)
            self._point(point, generation)
        for point, value in row['m']:
            old = self.marks.get(point)
            _need(old is None or old[0] == value, 'selected marking mismatch', InvariantError)
            self._map(self.marks, point, (value, 1 if old is None else old[1] + 1))
        affected = set()
        for point, units in row['t']:
            bucket = self.tdep.get(point, ())
            self.meter.tick(1 + len(bucket))
            affected.update(bucket)
        for point, value in row['m']:
            bucket = self.mdep.get(point, ())
            self.meter.tick(1 + len(bucket))
            affected.update(bucket)
        neighbors = self.pair_neighbors.get(cid, ())
        self.meter.tick(len(neighbors))
        affected.update(neighbors)
        self.meter.tick(len(affected) * (1 + len(affected).bit_length()))
        for other in sorted(affected):
            self._refresh(other)
        for point, units in row['t']:
            self._sync_point(point)
        self.stats['placements'] += 1
        return generation

    def exclude(self, cid):
        _need(cid in self.placements and cid not in self.selected,
              'failed child exclusion context', InvariantError)
        self._set(self.excluded, cid, True)
        self._refresh(cid)
        self.stats['exclusions'] += 1

    def undo(self, checkpoint, reason):
        """Uninterruptible inverse deltas; never execute callbacks during unwind."""
        _need(0 <= checkpoint <= len(self.trail), 'trail checkpoint', InvariantError)
        before, selected_before = len(self.trail), len(self.selected)
        while len(self.trail) > checkpoint:
            record = self.trail.pop()
            if record[0] == 'map':
                _, mapping, key, existed, old = record
                if existed:
                    mapping[key] = old
                else:
                    del mapping[key]
            elif record[0] == 'set':
                _, target, key, present = record
                if present:
                    target.add(key)
                else:
                    target.remove(key)
            else:
                _need(record[0] == 'edges', 'known inverse delta', InvariantError)
                self.edges = record[1]
        row = {'reason': reason, 'from_trail': before, 'to_trail': checkpoint,
               'undone': before - checkpoint, 'selected_before': selected_before,
               'selected_after': len(self.selected)}
        encoded = _wire(row)
        self.rollback_hash.update(encoded)
        self.rollback_count += 1
        if len(self.rollbacks) < self.meter.limits['max_rollback_records']:
            self.rollbacks.append(row)
        self.stats['rollbacks_total'] += 1
        self.stats['rollback_edits'] += before - checkpoint

    def snapshot(self, meter):
        # All arrays are fresh; strings/integers are immutable. No internal set/map escapes.
        _charge(meter, 2 + len(self.tdep) + len(self.mdep))
        counts = (len(self.Q) + len(self.selected) + len(self.marks) + len(self.excluded)
                  + len(self.eligible) + len(self.domains) + len(self.placements)
                  + len(self.loaded) + self.edges + len(self.totals)
                  + sum(len(ids) for ids in self.tdep.values())
                  + sum(len(ids) for ids in self.mdep.values()))
        _charge(meter, 2 + counts * (1 + counts.bit_length()))
        q = [[p, self.Q[p]] for p in sorted(self.Q)]
        domains = [[p, sorted(self.domains[p])] for p in sorted(self.domains)]
        forward, reverse = [], []
        # t-unit lookup does not assume unit supports or identical fractional contributions.
        weights = {}
        for cid in sorted(self.placements):
            row = self.placements[cid]
            _charge(meter, 1 + len(row['t']) + len(row['m']))
            weights[cid] = dict(row['t'])
        for point, ids in domains:
            for cid in ids:
                forward.append([point, cid, weights[cid][point]])
        for cid in sorted(self.reverse):
            reverse.append([cid, [[p, weights[cid][p]] for p in sorted(self.reverse[cid])]])
        placements = []
        for cid in sorted(self.placements):
            row = self.placements[cid]
            placements.append({'id': cid, 't': [[p, n] for p, n in row['t']],
                               'm': [[p, v] for p, v in row['m']]})
        return {'Q': q, 'totals': [[p, n] for p, n in sorted(self.totals.items())],
                'selected': [[cid, self.selected[cid]] for cid in sorted(self.selected)],
                'marks': [[p, v, n] for p, (v, n) in sorted(self.marks.items())],
                'excluded': sorted(self.excluded), 'eligible': sorted(self.eligible),
                'domains': domains, 'forward': forward, 'reverse': reverse,
                'placements': placements, 'loaded': sorted(self.loaded),
                'dependencies': {'t': [[p, sorted(ids)] for p, ids in sorted(self.tdep.items())],
                                 'm': [[p, sorted(ids)] for p, ids in sorted(self.mdep.items())]},
                'edge_count': self.edges}

    def certificate(self):
        meter = self.meter
        meter.tick(2 + len(self.model['roots']) + len(self.model['seed']['t'])
                   + len(self.model['seed']['m']))
        totals, marks, points = {}, {}, set(self.model['roots'])
        for point, units in self.model['seed']['t']:
            totals[point] = units
            if units:
                points.add(point)
        for point, value in self.model['seed']['m']:
            marks[point] = (value, 1)
        chosen = []
        meter.tick(1 + len(self.selected))
        for cid in sorted(self.selected):
            row = self.placements[cid]
            meter.tick(1 + len(row['t']) + len(row['m']))
            chosen.append({'id': cid, 't': [[p, n] for p, n in row['t']],
                           'm': [[p, v] for p, v in row['m']]})
            for point, units in row['t']:
                points.add(point)
                totals[point] = totals.get(point, 0) + units
            for point, value in row['m']:
                old = marks.get(point)
                _need(old is None or old[0] == value, 'certificate m disagreement', InvariantError)
                marks[point] = (value, 1 if old is None else old[1] + 1)
        # Recheck the declared pairs directly, independently of the neighbor
        # index and incremental eligibility, before emitting a positive result.
        meter.tick(1 + len(chosen) + len(self.model['pair_nogoods']))
        chosen_ids = {row['id'] for row in chosen}
        for forbidden in self.model['unary_nogoods']:
            meter.tick()
            _need(forbidden not in chosen_ids, 'certificate unary_nogood disagreement', InvariantError)
        for left, right in self.model['pair_nogoods']:
            meter.tick(2)
            _need(not (left in chosen_ids and right in chosen_ids),
                  'certificate pair_nogood disagreement', InvariantError)
        meter.tick(1 + len(points) + len(marks))
        _need(points == set(self.Q) and all(totals.get(p, 0) == self.capacity for p in points)
              and all(self.totals.get(p, 0) == totals.get(p, 0) for p in points)
              and marks == self.marks, 'independently summed exact active target', InvariantError)
        seed = {'t': [[p, n] for p, n in self.model['seed']['t']],
                'm': [[p, v] for p, v in self.model['seed']['m']]}
        out = {'capacity': self.capacity, 'roots': list(self.model['roots']), 'seed': seed,
               'placements': chosen, 'totals': [[p, totals.get(p, 0)] for p in sorted(points)],
               'marks': [[p, v, n] for p, (v, n) in sorted(marks.items())]}
        _wire(out, meter)
        return out


class _Events:
    def __init__(self, state, meter, stats, audit):
        self.state, self.meter, self.stats, self.audit = state, meter, stats, audit
        self.records = []
        self.count = 0
        self.digest = hashlib.sha256()

    def emit(self, kind, point=None, candidate=None, data=None):
        record = {'seq': self.count, 'kind': kind, 'point': point,
                  'candidate': candidate, 'data': {} if data is None else data}
        encoded = _wire(record, self.meter)
        self.digest.update(encoded)
        self.count += 1
        self.stats['events_total'] += 1
        if len(self.records) < self.meter.limits['max_events']:
            self.records.append(record)
        if self.audit is not None:
            snapshot = self.state.snapshot(self.meter)
            _wire(snapshot, self.meter)
            self.stats['audit_calls'] += 1
            self.audit(json.loads(encoded), snapshot, self.meter.tick)
            self.meter.tick()


def _ordered(state, point, model_sha, order):
    meter = state.meter
    domain = state.domains[point]
    meter.tick(1 + len(domain) * (1 + len(domain).bit_length()))
    legal = sorted(domain)
    if order is None:
        return legal
    meter.tick(2 + len(state.selected) + len(state.excluded))
    request = {'schema': 'Z-candidate-order-request-v1', 'model_sha256': model_sha,
               'point': point, 'generation': state.Q[point], 'legal': list(legal),
               'selected': sorted(state.selected), 'excluded': sorted(state.excluded)}
    _wire(request, meter)
    state.stats['ordering_calls'] += 1
    preferred = order(request, meter.tick)
    meter.tick()
    _need(type(preferred) is list, 'preference list', OrderingError)
    meter.tick(1 + len(preferred))
    out, seen = [], set()
    for cid in preferred:
        _string(cid, meter, True, OrderingError)
        _need(cid in domain and cid not in seen, 'unique current legal preference', OrderingError)
        out.append(cid)
        seen.add(cid)
    for cid in legal:
        if cid not in seen:
            out.append(cid)
    return out


def _search(state, events, model_sha, order):
    stack = []
    meter = state.meter
    events.emit('READY')
    while True:
        meter.node()
        meter.tick(1 + len(state.domains))
        # Both scans range over the WHOLE frontier, before any branch ordering.
        dead = [p for p, ids in state.domains.items() if not ids]
        if dead:
            point = min(dead, key=lambda p: (state.Q[p], p))
            state.stats['dead_ends'] += 1
            events.emit('DEAD', point, data={'generation': state.Q[point]})
            if not stack:
                events.emit('EXHAUSTED')
                return 'UNSAT', 'EXHAUSTED_DECLARED_FINITE_INVENTORY'
            checkpoint, cid = stack.pop()
            state.undo(checkpoint, 'FAILED_CHILD')
            state.stats['backtracks'] += 1
            meter.tick()
            state.exclude(cid)
            events.emit('EXCLUDE', candidate=cid)
            continue
        meter.tick(1 + len(state.domains))
        forced = [p for p, ids in state.domains.items() if len(ids) == 1]
        if forced:
            point = min(forced, key=lambda p: (state.Q[p], p))
            cid = next(iter(state.domains[point]))
            state.stats['forced'] += 1
            events.emit('FORCED', point, cid, {'generation': state.Q[point]})
            generation = state.place(cid)
            events.emit('PLACED', point, cid, {'generation': generation, 'forced': True})
            continue
        if not state.domains:
            events.emit('SOLUTION')
            return 'SAT', 'FINITE_ACTIVE_OBLIGATIONS_EXACT'
        meter.tick(1 + len(state.domains))
        point = min(state.domains, key=lambda p: (state.Q[p], len(state.domains[p]), p))
        ordered = _ordered(state, point, model_sha, order)
        state.stats['branches'] += 1
        meter.tick(1 + len(ordered))
        events.emit('BRANCH', point, data={'generation': state.Q[point],
                    'legal': sorted(state.domains[point]), 'order': list(ordered)})
        cid = ordered[0]
        stack.append((len(state.trail), cid))
        generation = state.place(cid)
        events.emit('PLACED', point, cid, {'generation': generation, 'forced': False})


def _extent(total, records, digest):
    return {'total': total, 'retained': len(records), 'sha256': digest.hexdigest(),
            'scope': 'BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH'}


def solve(model, limits, *, enumerate_incident=None, order=None, audit=None):
    """Solve one finite declared growing inventory; never mutate caller JSON."""
    started = time.perf_counter()
    limits = _limits(limits)
    meter = _Meter(limits, started)
    stats = _stats()
    state = events = normalized = None
    model_sha = entry = final = restored = certificate = None
    entry_sha = final_sha = restored_sha = None
    status, reason, selected = 'UNKNOWN', None, []
    cleanup_seconds = 0.0
    try:
        meter.tick(1 + len(limits))
        normalized = _model(model, meter)
        if normalized['inventory']['kind'] == 'EXPLICIT':
            _need(enumerate_incident is None, 'explicit inventory has no provider')
        else:
            _need(callable(enumerate_incident), 'certified incident provider required')
        _need(order is None or callable(order), 'optional ordering callback')
        _need(audit is None or callable(audit), 'optional audit callback')
        model_sha = _digest(normalized, meter)
        state = _State(normalized, meter, enumerate_incident, stats)
        state.initialize()
        candidate_entry = state.snapshot(meter)
        candidate_sha = _digest(candidate_entry, meter)
        entry, entry_sha = candidate_entry, candidate_sha
        events = _Events(state, meter, stats, audit)
        status, reason = _search(state, events, model_sha, order)
        candidate_final = state.snapshot(meter)
        candidate_final_sha = _digest(candidate_final, meter)
        if status == 'SAT':
            certificate = state.certificate()
            meter.tick(1 + len(state.selected))
            selected = sorted(state.selected)
        meter.tick()
        final, final_sha = candidate_final, candidate_final_sha
    except _Stop as error:
        status, reason = 'UNKNOWN', str(error)
        selected, certificate, final, final_sha = [], None, None, None
    finally:
        # This restoration also executes before any foreign/checked exception escapes.
        if entry is not None:
            cleanup_started = time.perf_counter()
            state.undo(0, 'FINAL_RESTORE')
            restored = state.snapshot(None)
            restored_sha = _digest(restored)
            _need(restored_sha == entry_sha and restored == entry,
                  'full entry state restoration', InvariantError)
            cleanup_seconds = time.perf_counter() - cleanup_started
    if events is None:
        records, event_extent = [], _extent(0, [], hashlib.sha256())
    else:
        records = events.records
        event_extent = _extent(events.count, records, events.digest)
    if state is None:
        rollbacks, rollback_extent = [], _extent(0, [], hashlib.sha256())
    else:
        rollbacks = state.rollbacks
        rollback_extent = _extent(state.rollback_count, rollbacks, state.rollback_hash)
    stats.update({'work': meter.work, 'nodes': meter.nodes,
                  'elapsed_seconds': time.perf_counter() - started,
                  'cleanup_seconds': cleanup_seconds})
    return {'schema': 'Z-growing-point-search-result-v1', 'version': VERSION,
            'status': status, 'reason': reason, 'model_sha256': model_sha,
            'selected': selected, 'certificate': certificate,
            'entry_state': entry, 'final_state': final, 'restored_state': restored,
            'state_hashes': {'entry': entry_sha, 'final': final_sha, 'restored': restored_sha},
            'events': records, 'event_extent': event_extent,
            'rollback_records': rollbacks, 'rollback_extent': rollback_extent,
            'stats': stats, 'limits': limits,
            'provider_evidence': (state.provider_evidence() if state is not None else
                {'mode': 'UNINITIALIZED', 'total': 0, 'retained': 0,
                 'sha256': hashlib.sha256().hexdigest(),
                 'scope': 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES',
                 'records': [], 'costs': {'query_attempts': 0, 'query_work': 0,
                 'query_seconds': 0.0, 'receipt_work': 0, 'potential_contacts': 0,
                 'returned_contacts': 0, 'context_values': 0}})}
