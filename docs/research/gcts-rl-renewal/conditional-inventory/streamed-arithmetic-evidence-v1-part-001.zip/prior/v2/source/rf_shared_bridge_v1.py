"""Full RF finite carrier to generic shared-fact catalogue, data transformation.

No compiler, model adapter, native kernel, checker, search, previous proof or
witness is imported or called. Complete RF-profile admission and every native
ZERO check are external gates; CATALOGUE_UNVERIFIED is not their substitute.
"""
import copy
import hashlib
import json
import math
import time

VERSION = 'RF-shared-catalogue-bridge-v1'
DEFAULT_LIMITS = dict(max_formulas=1024, max_zero_definitions=8000,
    max_definitions=8000, max_slots=16, max_items=500000000,
    max_depth=128, wall_seconds=120.0)
SCOPE = 'All original RF formulas, native ZERO payloads and structural MP/GEN; no proof, witness, imported lemma or thinning.'


class Refusal(Exception):
    pass


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def integer(value, low=0):
    return type(value) is int and value >= low and value.bit_length() <= 256


def fields(value, keys, reason):
    need(type(value) is dict and set(value) == set(keys), reason)


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')


def limits_value(value):
    out = dict(DEFAULT_LIMITS)
    if value is not None:
        need(type(value) is dict and set(value) <= set(out), 'BRIDGE_LIMIT_FIELDS')
        out.update(value)
    for key, v in out.items():
        if key == 'wall_seconds':
            need(type(v) in (float, int) and math.isfinite(v) and 0 < v <= DEFAULT_LIMITS[key], 'BRIDGE_WALL_LIMIT')
        else:
            need(integer(v, 1) and v <= DEFAULT_LIMITS[key], 'BRIDGE_LIMIT:'+key)
    return out


class Meter:
    def __init__(self, limits):
        self.limits = limits
        self.items = 0
        self.started = time.perf_counter()

    def tick(self, n=1):
        self.items += n
        if self.items > self.limits['max_items']:
            raise Refusal('BRIDGE_ITEM_BOUND')
        if time.perf_counter()-self.started > self.limits['wall_seconds']:
            raise Refusal('BRIDGE_WALL_BOUND')

    def scan(self, value, depth=0):
        self.tick()
        if depth > self.limits['max_depth']:
            raise Refusal('BRIDGE_JSON_DEPTH')
        if type(value) is str:
            self.tick(len(value))
        elif type(value) is list:
            for x in value:
                self.scan(x, depth+1)
        elif type(value) is dict:
            for k, v in value.items():
                need(type(k) is str, 'NATIVE_STRING_KEYS')
                self.scan(k, depth+1)
                self.scan(v, depth+1)
        elif type(value) is int:
            need(value.bit_length() <= 256, 'NATIVE_INTEGER_BITS')
        else:
            need(value is None or type(value) is bool or
                 type(value) is float and math.isfinite(value), 'FINITE_NATIVE_JSON')

    def sha(self, value):
        self.scan(value)
        raw = canonical(value)
        self.tick(len(raw))
        result = hashlib.sha256(raw).hexdigest()
        self.tick()
        return result


def bridge(declaration, compiled, generation, slots, limits=None):
    """Map every admitted RF entry; never compile, select or search a proof.

    RF formula IDs are zero based; shared IDs are exactly one larger. Native
    ZERO IDs/payloads are unchanged and only lexically reordered for the ABI.
    Root must separately admit the original RF profile and native ZERO truth.
    """
    started = time.perf_counter()
    meter = None
    census = {}
    try:
        effective = limits_value(limits)
        meter = Meter(effective)
        for value in (declaration, compiled, generation):
            meter.scan(value)
        need(type(declaration) is dict and {'id', 'problem'} <= set(declaration), 'ORIGINAL_DECLARATION')
        need(type(declaration['id']) is str and declaration['id'], 'DECLARATION_ID')
        need(not {'proof', 'target_proof', 'witness', 'selected', 'bank', 'control_proof'} & set(declaration), 'NO_SUPPLIED_PROOF_OR_BANK')
        fields(declaration['problem'], ('theory', 'goal'), 'ORIGINAL_PROBLEM_FIELDS')
        need(integer(slots, 1), 'SHARED_PROOF_SLOT_BOUND')
        if slots > effective['max_slots']:
            raise Refusal('BRIDGE_SLOT_BOUND')
        if 'slots' in declaration:
            need(type(declaration['slots']) is int and declaration['slots'] == slots, 'DECLARED_SHARED_SLOT_BOUND')
        fields(compiled, ('schema', 'version', 'theory', 'goal', 'goal_id', 'profile',
                         'logical_basis', 'zero_instances', 'mp_index', 'gen_index',
                         'costs', 'scope'), 'RF_COMPILED_FIELDS')
        need(compiled['schema'] == 'V-interned-Hilbert8-basis-v1' and
             compiled['version'] == 'V-INTERNED-FINITE-HILBERT8-v1', 'RF_COMPILED_ABI')
        statement = declaration['problem']
        need(canonical(statement) == canonical(dict(theory=compiled['theory'], goal=compiled['goal'])), 'UNCHANGED_ORIGINAL_STATEMENT')
        need(type(compiled['profile']) is dict, 'RF_PROFILE_OBJECT')
        lb = compiled['logical_basis']
        need(type(lb) is dict and {'formulas', 'colors', 'variables', 'hole'} <= set(lb), 'RF_LOGICAL_BASIS')
        forms, colors, variables = lb['formulas'], lb['colors'], lb['variables']
        need(type(forms) is list and forms and type(colors) is list and
             all(type(c) is str for c in colors), 'RF_LITERAL_REGISTRY')
        if len(forms) > effective['max_formulas']:
            raise Refusal('BRIDGE_FORMULA_BOUND')
        keys = []
        for f in forms:
            meter.tick()
            need(type(f) is list and f and type(f[0]) is str, 'RF_FORMULA_AST')
            keys.append(canonical(f)[:-1].decode('ascii'))
        need(colors == sorted(set(colors)) and colors == keys, 'EXACT_ALL_SORTED_RF_FORMULAS_AND_COLORS')
        need(type(variables) is list and all(type(v) is str and v for v in variables)
             and variables == sorted(set(variables)), 'FULL_SORTED_VARIABLE_POOL')
        need(type(lb['hole']) is str and lb['hole'] in variables, 'FRESH_HOLE_INCLUDED_IN_VARIABLE_POOL')
        ids = {key: i for i, key in enumerate(keys)}
        goal_key = canonical(compiled['goal'])[:-1].decode('ascii')
        need(goal_key in ids and integer(compiled['goal_id']) and compiled['goal_id'] == ids[goal_key], 'RF_GOAL_ID')
        zeros = compiled['zero_instances']
        need(type(zeros) is list, 'RF_ZERO_LIST')
        if len(zeros) > effective['max_zero_definitions']:
            raise Refusal('BRIDGE_ZERO_BOUND')
        output_zeros = []
        for i, zero in enumerate(zeros):
            meter.tick()
            fields(zero, ('id', 'rule', 'formula_id', 'line'), 'RF_ZERO_FIELDS')
            need(zero['id'] == 'i'+str(i) and integer(zero['formula_id']) and
                 zero['formula_id'] < len(forms), 'ALL_RF_ZERO_IDENTITIES')
            need(type(zero['line']) is dict and type(zero['rule']) is str and
                 zero['line'].get('rule') == zero['rule'] and 'formula' in zero['line'], 'RF_NATIVE_ZERO_PAYLOAD')
            need(canonical(zero['line']['formula']) == canonical(forms[zero['formula_id']]), 'RF_ZERO_OUTPUT_BINDING')
            output_zeros.append(dict(id=zero['id'], native=copy.deepcopy(zero['line'])))
        output_zeros.sort(key=lambda r: r['id'])
        rf_mp, rf_gen, mp, gen = [], [], [], []
        for i, f in enumerate(forms):
            meter.tick()
            if f[0] == 'imp':
                need(len(f) == 3, 'RF_IMPLICATION_ARITY')
                a, b = (ids[canonical(child)[:-1].decode('ascii')] for child in f[1:])
                rf_mp.append([i, a, b])
                mp.append(dict(antecedent=a+1, implication=i+1, output=b+1))
            elif f[0] == 'all':
                need(len(f) == 3 and type(f[1]) is str and f[1] in variables, 'RF_UNIVERSAL_BINDER')
                body = ids[canonical(f[2])[:-1].decode('ascii')]
                rf_gen.append([i, body, f[1]])
                gen.append(dict(source=body+1, output=i+1, variable=f[1]))
        need(canonical(rf_mp) == canonical(compiled['mp_index']) and
             canonical(rf_gen) == canonical(compiled['gen_index']), 'COMPLETE_ALL_STRUCTURAL_RF_MP_GEN')
        if len(zeros)+len(mp)+len(gen) > effective['max_definitions']:
            raise Refusal('BRIDGE_DEFINITION_BOUND')
        mp.sort(key=lambda d: (d['antecedent'], d['implication'], d['output']))
        gen.sort(key=lambda d: (d['source'], d['output'], d['variable']))
        core = {k: v for k, v in compiled.items() if k not in ('costs', 'scope')}
        core_sha = meter.sha(core)
        fields(generation, ('schema', 'version', 'profile', 'compiled_core_sha256',
                            'core_stages', 'core_assertions', 'goal_receptors',
                            'bridge_premises', 'scope'), 'RF_GENERATION_FIELDS')
        need(generation['schema'] == 'Y-goal-receptor-universe-v1' and
             generation['version'] == 'Y-GOAL-RECEPTOR-FAMILY-v1', 'RF_GENERATION_ABI')
        need(generation['compiled_core_sha256'] == core_sha and
             canonical(generation['profile']) == canonical(compiled['profile']), 'RF_GENERATION_CORE_PROFILE_BINDING')
        for k in ('core_stages', 'core_assertions', 'goal_receptors', 'bridge_premises'):
            need(generation[k] == [], 'RF_NO_ADDED_BRIDGE_OR_LEMMA:'+k)
        declaration_sha = meter.sha(declaration)
        generation_sha = meter.sha(generation)
        profile = dict(kind='RF_FROZEN_SHARED_V1', slots=slots,
            formula_universe_version='LITERAL_SORTED_CANONICAL_JSON_V1',
            zero_instance_profile='RF_COMPLETE_COMPILED_NATIVE_ZERO_V1',
            variables=copy.deepcopy(variables), allow_gen=True,
            rf_profile=copy.deepcopy(compiled['profile']))
        catalogue = dict(schema='Shared-fact-finite-catalogue-v1',
            statement=copy.deepcopy(statement), formulas=copy.deepcopy(forms),
            zeros=output_zeros, mp=mp, gen=gen, profile=profile,
            provenance=dict(case_id=declaration['id'], compiler=VERSION,
                declaration_sha256=declaration_sha, rf_compiled_core_sha256=core_sha,
                rf_generation_sha256=generation_sha, rf_profile_sha256=meter.sha(compiled['profile']),
                scope=SCOPE))
        mapping = dict(formula_ids=[[i, i+1] for i in range(len(forms))],
                       zero_ids=[[z['id'], z['id']] for z in output_zeros])
        bindings = dict(original_statement_sha256=meter.sha(statement),
            declaration_sha256=declaration_sha, rf_compiled_core_sha256=core_sha,
            rf_generation_sha256=generation_sha, catalogue_sha256=meter.sha(catalogue))
        census = dict(formulas=len(forms), zeros=len(zeros), mp=len(mp), gen=len(gen), slots=slots)
        result = dict(schema='RF-shared-catalogue-bridge-v1', status='CATALOGUE_UNVERIFIED',
            catalogue=catalogue, mapping=mapping, bindings=bindings, census=census,
            limits=effective, timings=dict(seconds=time.perf_counter()-started, items=meter.items),
            admission='Exact full RF representation bridge only. Independent RF-profile reconstruction, all native ZERO checks, shared-model admission and final native proof checking remain external.')
        meter.scan(mapping)
        meter.tick()
        result['timings'] = dict(seconds=time.perf_counter()-started, items=meter.items)
        return result
    except (Refusal, MemoryError, RecursionError, OverflowError) as error:
        return dict(schema='RF-shared-catalogue-bridge-v1', status='UNKNOWN', reason=str(error) or type(error).__name__,
            catalogue=None, census=census, seconds=time.perf_counter()-started,
            items=0 if meter is None else meter.items)
    except (ValueError, TypeError, KeyError, IndexError, AttributeError) as error:
        return dict(schema='RF-shared-catalogue-bridge-v1', status='REJECTED_INPUT', reason=str(error),
            catalogue=None, census=census, seconds=time.perf_counter()-started,
            items=0 if meter is None else meter.items)
