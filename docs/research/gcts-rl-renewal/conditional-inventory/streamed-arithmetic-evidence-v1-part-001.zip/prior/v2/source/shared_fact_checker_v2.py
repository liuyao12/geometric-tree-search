"""Independent finite shared-fact basis/model/mapping checker.

Standard library only.  This module does not import an adapter, search engine,
native proof kernel or control.  Native logical admission of ZERO payloads and
the decoded proof is deliberately outside this module.  Its ground-Horn basis
coverage claim is limited to the explicitly declared subformula/assumption/MP
profile, never unrestricted first-order completeness.
"""
import copy
import hashlib
import json
import math
import time

VERSION = 'Independent-shared-fact-checker-v2'


class Rejected(Exception):
    pass


class Bound(Exception):
    pass


def need(ok, reason):
    if not ok:
        raise Rejected(reason)


def integer(value, low=0):
    return type(value) is int and low <= value and value.bit_length() <= 256


def fields(value, names, reason):
    need(type(value) is dict and set(value) == set(names), reason)


def text(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False) + '\n'


class Meter:
    def __init__(self, max_items, max_work, wall_seconds):
        need(integer(max_items, 1) and integer(max_work, 1), 'CHECKER_INTEGER_LIMITS')
        need(type(wall_seconds) in (int, float) and math.isfinite(wall_seconds)
             and wall_seconds > 0, 'CHECKER_WALL_LIMIT')
        self.max_items, self.max_work = max_items, max_work
        self.start = time.perf_counter()
        self.deadline = self.start + wall_seconds
        self.items = self.work = 0

    def tick(self, amount=1):
        self.work += amount
        if self.work > self.max_work:
            raise Bound('CHECKER_MAX_WORK')
        if time.perf_counter() >= self.deadline:
            raise Bound('CHECKER_WALL_SECONDS')

    def scan(self, value):
        def entries(mapping):
            for key, item in mapping.items():
                need(type(key) is str, 'JSON_STRING_KEYS')
                yield key
                yield item
        todo = [(iter((value,)), 0)]
        bound = 1
        while todo:
            self.tick()
            iterator, depth = todo[-1]
            try:
                v = next(iterator)
            except StopIteration:
                todo.pop()
                continue
            if depth > 128:
                raise Bound('CHECKER_JSON_DEPTH')
            units = 1
            if v is None or type(v) is bool:
                bound += 8
            elif type(v) is int:
                if v.bit_length() > 256:
                    raise Bound('CHECKER_INTEGER_BITS')
                bound += 84
            elif type(v) is float:
                need(math.isfinite(v), 'JSON_FINITE_FLOAT')
                bound += 132
            elif type(v) is str:
                units += len(v)
                bound += 4 + 12 * len(v)
            elif type(v) is list:
                bound += 4
                todo.append((iter(v), depth + 1))
            elif type(v) is dict:
                bound += 4
                todo.append((entries(v), depth + 1))
            else:
                raise Rejected('NON_NATIVE_JSON')
            self.items += units
            if self.items > self.max_items:
                raise Bound('CHECKER_MAX_ITEMS')
            self.tick(units)
        return bound

    def wire(self, value):
        self.tick(self.scan(value))
        raw = text(value)
        self.tick()
        return raw

    def same(self, a, b, reason):
        need(self.wire(a) == self.wire(b), reason)

    def sha(self, value):
        return hashlib.sha256(self.wire(value).encode('ascii')).hexdigest()

    def counters(self):
        return dict(items=self.items, work=self.work,
                    seconds=time.perf_counter() - self.start)


def name(value):
    need(type(value) is str and bool(value), 'NONEMPTY_NAME')
    return value


def signature(value, meter):
    need(type(value) is dict, 'SIGNATURE_RECORD')
    for key, arity in value.items():
        meter.tick(1 + len(key))
        name(key)
        need(integer(arity), 'SIGNATURE_ARITY')
    return value


def term(value, functions, meter, depth=0):
    meter.tick()
    if depth > 128:
        raise Bound('CHECKER_AST_DEPTH')
    need(type(value) is list and bool(value), 'TERM_ARRAY')
    if value[0] == 'var':
        need(len(value) == 2, 'VARIABLE_TERM_FIELDS')
        return {name(value[1])}
    need(value[0] == 'fun' and len(value) == 3, 'FUNCTION_TERM_FIELDS')
    symbol = name(value[1])
    need(type(value[2]) is list and symbol in functions
         and functions[symbol] == len(value[2]), 'FUNCTION_ARITY')
    free = set()
    for arg in value[2]:
        free.update(term(arg, functions, meter, depth + 1))
    return free


def formula(value, functions, predicates, meter, depth=0):
    meter.tick()
    if depth > 128:
        raise Bound('CHECKER_AST_DEPTH')
    need(type(value) is list and bool(value), 'FORMULA_ARRAY')
    tag = value[0]
    if tag == 'bot':
        need(len(value) == 1, 'BOT_FIELDS')
        return set()
    if tag == 'pred':
        need(len(value) == 3, 'PREDICATE_FIELDS')
        symbol = name(value[1])
        need(type(value[2]) is list and symbol in predicates
             and predicates[symbol] == len(value[2]), 'PREDICATE_ARITY')
        free = set()
        for arg in value[2]:
            free.update(term(arg, functions, meter, depth + 1))
        return free
    if tag == 'eq':
        need(len(value) == 3, 'EQUALITY_FIELDS')
        return term(value[1], functions, meter, depth + 1) | term(value[2], functions, meter, depth + 1)
    if tag == 'all':
        need(len(value) == 3, 'UNIVERSAL_FIELDS')
        variable = name(value[1])
        return formula(value[2], functions, predicates, meter, depth + 1) - {variable}
    if tag == 'not':
        need(len(value) == 2, 'NEGATION_FIELDS')
        return formula(value[1], functions, predicates, meter, depth + 1)
    need(tag in ('imp', 'and', 'or') and len(value) == 3, 'BINARY_FORMULA_FIELDS')
    return (formula(value[1], functions, predicates, meter, depth + 1)
            | formula(value[2], functions, predicates, meter, depth + 1))


def statement(value, meter):
    fields(value, ('theory', 'goal'), 'STATEMENT_FIELDS')
    theory = value['theory']
    fields(theory, ('functions', 'predicates', 'axioms'), 'THEORY_FIELDS')
    functions = signature(theory['functions'], meter)
    predicates = signature(theory['predicates'], meter)
    need(type(theory['axioms']) is dict, 'AXIOM_RECORD')
    for key, ast in theory['axioms'].items():
        name(key)
        need(not formula(ast, functions, predicates, meter), 'OPEN_ASSUMPTION_CONTEXT')
    formula(value['goal'], functions, predicates, meter)
    return functions, predicates


def all_variable_names(ast, meter):
    """Binder names as well as free leaves; no alpha-equivalence quotient."""
    meter.tick()
    tag = ast[0]
    if tag == 'var':
        return {ast[1]}
    if tag in ('fun', 'pred'):
        children = ast[2]
    elif tag == 'all':
        return {ast[1]} | all_variable_names(ast[2], meter)
    elif tag == 'not':
        children = [ast[1]]
    elif tag == 'bot':
        children = []
    else:
        children = ast[1:]
    result = set()
    for child in children:
        result.update(all_variable_names(child, meter))
    return result


def primitive(line, functions, predicates, meter):
    need(type(line) is dict, 'PRIMITIVE_RECORD')
    rule = line.get('rule')
    expected = {
        'axiom': ('rule', 'formula', 'name'),
        'tautology': ('rule', 'formula'),
        'refl': ('rule', 'formula'),
        'instantiate': ('rule', 'formula', 'universal', 'term'),
        'distribute': ('rule', 'formula', 'variable', 'antecedent', 'consequent'),
        'eq_subst': ('rule', 'formula', 'variable', 'template', 'left', 'right')}
    need(type(rule) is str and rule in expected, 'ZERO_MUST_BE_PRIMITIVE_RULE')
    fields(line, expected[rule], 'PRIMITIVE_FIELDS')
    formula(line['formula'], functions, predicates, meter)
    if rule == 'axiom':
        name(line['name'])
    elif rule == 'instantiate':
        formula(line['universal'], functions, predicates, meter)
        term(line['term'], functions, meter)
    elif rule == 'distribute':
        name(line['variable'])
        formula(line['antecedent'], functions, predicates, meter)
        formula(line['consequent'], functions, predicates, meter)
    elif rule == 'eq_subst':
        name(line['variable'])
        formula(line['template'], functions, predicates, meter)
        term(line['left'], functions, meter)
        term(line['right'], functions, meter)


def catalogue(value, meter):
    """Check literal syntax and reconstruct ALL structural MP/GEN definitions.

    Completeness of a richer ZERO/formula generation profile is not inferred
    from this operation.  The ground-Horn verifier below supplies that part.
    """
    fields(value, ('schema', 'statement', 'formulas', 'zeros', 'mp', 'gen',
                   'profile', 'provenance'), 'CATALOGUE_FIELDS')
    need(value['schema'] == 'Shared-fact-finite-catalogue-v1', 'CATALOGUE_SCHEMA')
    need(type(value['provenance']) is dict, 'PROVENANCE_DICTIONARY')
    functions, predicates = statement(value['statement'], meter)
    forms = value['formulas']
    need(type(forms) is list and bool(forms), 'FORMULA_REGISTRY')
    keys = []
    for ast in forms:
        formula(ast, functions, predicates, meter)
        keys.append(meter.wire(ast))
    need(keys == sorted(set(keys)), 'CANONICAL_COMPLETE_LITERAL_REGISTRY')
    ids = {key: i + 1 for i, key in enumerate(keys)}
    goal_key = meter.wire(value['statement']['goal'])
    need(goal_key in ids, 'GOAL_IN_REGISTRY')
    need(all(meter.wire(f) in ids for f in value['statement']['theory']['axioms'].values()),
         'ALL_ASSUMPTIONS_IN_REGISTRY')
    profile = value['profile']
    required = {'kind', 'formula_universe_version', 'zero_instance_profile',
                'variables', 'allow_gen'}
    need(type(profile) is dict and required <= set(profile), 'CATALOGUE_PROFILE_FIELDS')
    name(profile['kind']);name(profile['zero_instance_profile'])
    need(profile['formula_universe_version'] == 'LITERAL_SORTED_CANONICAL_JSON_V1',
         'FORMULA_ID_VERSION')
    variables = profile['variables']
    need(type(variables) is list and all(type(v) is str and v for v in variables)
         and len(set(variables)) == len(variables), 'DECLARED_VARIABLE_POOL')
    need(type(profile['allow_gen']) is bool, 'GEN_PROFILE_BOOLEAN')
    need(integer(profile.get('slots'), 1), 'PROFILE_SLOT_BOUND')
    for ast in forms:
        need(all_variable_names(ast, meter) <= set(variables), 'FORMULA_VARIABLES_IN_DECLARED_POOL')
    need(type(value['zeros']) is list, 'ZERO_ARRAY')
    zero_ids = set()
    for zero in value['zeros']:
        meter.tick()
        fields(zero, ('id', 'native'), 'ZERO_FIELDS')
        zid = name(zero['id'])
        need(zid not in zero_ids, 'DUPLICATE_ZERO_ID')
        zero_ids.add(zid)
        primitive(zero['native'], functions, predicates, meter)
        need(meter.wire(zero['native']['formula']) in ids, 'ZERO_OUTPUT_IN_REGISTRY')
    need([z['id'] for z in value['zeros']] == sorted(zero_ids), 'SORTED_UNIQUE_ZERO_IDS')
    expected_mp, expected_gen = [], []
    for output_id, ast in enumerate(forms, 1):
        meter.tick()
        if ast[0] == 'imp':
            left, right = meter.wire(ast[1]), meter.wire(ast[2])
            if left in ids and right in ids:
                expected_mp.append(dict(antecedent=ids[left], implication=output_id,
                                        output=ids[right]))
        if profile['allow_gen'] and ast[0] == 'all' and ast[1] in variables:
            body = meter.wire(ast[2])
            if body in ids:
                expected_gen.append(dict(source=ids[body], output=output_id,
                                         variable=ast[1]))
    expected_mp.sort(key=lambda r: (r['antecedent'], r['implication'], r['output']))
    expected_gen.sort(key=lambda r: (r['source'], r['output'], r['variable']))
    meter.same(value['mp'], expected_mp, 'COMPLETE_STRUCTURAL_MP_CATALOGUE')
    meter.same(value['gen'], expected_gen, 'COMPLETE_STRUCTURAL_GEN_CATALOGUE')
    return dict(formulas=forms, ids=ids, goal_id=ids[goal_key],
                mp=expected_mp, gen=expected_gen)


def horn_subformulas(ast, found, meter):
    meter.tick()
    need(type(ast) is list and bool(ast), 'GROUND_HORN_FORMULA_ARRAY')
    if ast[0] == 'pred':
        need(len(ast) == 3 and type(ast[1]) is str and type(ast[2]) is list
             and not ast[2], 'GROUND_HORN_ATOM')
    else:
        need(ast[0] == 'imp' and len(ast) == 3, 'GROUND_HORN_PRED0_OR_IMP_ONLY')
        horn_subformulas(ast[1], found, meter)
        horn_subformulas(ast[2], found, meter)
    found[meter.wire(ast)] = ast


def ground_basis(case, value, info, meter):
    need(type(case) is dict and {'id', 'statement', 'profile'} <= set(case), 'DECLARED_CASE_FIELDS')
    need('schema' not in case or case['schema'] == 'Shared-fact-proof-case-v1', 'DECLARED_CASE_SCHEMA')
    need(not {'proof', 'target_proof', 'witness', 'selected', 'bank', 'control_proof'} & set(case),
         'NO_SUPPLIED_PROOF_OR_BANK')
    name(case.get('id'))
    meter.same(case.get('statement'), value['statement'], 'UNCHANGED_DECLARED_STATEMENT')
    profile = value['profile']
    if profile['kind'] != 'GROUND_HORN_SUBFORMULAS_V1':
        raise Bound('INDEPENDENT_BASIS_PROFILE_NOT_IMPLEMENTED')
    need(profile['zero_instance_profile'] == 'ASSUMPTIONS_ONLY'
         and profile['variables'] == [] and profile['allow_gen'] is False,
         'GROUND_HORN_PROFILE')
    need(type(case['profile']) is dict and case['profile'].get('kind') == 'GROUND_HORN_SUBFORMULAS_V1',
         'DECLARED_GROUND_PROFILE')
    expected_profile = dict(case['profile'])
    for key, expected in dict(formula_universe_version='LITERAL_SORTED_CANONICAL_JSON_V1',
        zero_instance_profile='ASSUMPTIONS_ONLY', variables=[], allow_gen=False).items():
        if key in expected_profile:
            meter.same(expected_profile[key], expected, 'DECLARED_GROUND_PROFILE_DEFAULT')
        expected_profile[key] = expected
    meter.same(profile, expected_profile, 'ENTIRE_DECLARED_GROUND_PROFILE')
    expected_provenance = dict(case_id=case['id'], compiler='Ground-Horn-subformula-compiler-v1',
        declaration_sha256=meter.sha(case),
        scope='All literal assumption/goal subformulas, every named assumption ZERO and every structural MP. No proof path, search, target witness, GEN or other native schema was supplied.')
    meter.same(value['provenance'], expected_provenance, 'DECLARED_CASE_CATALOGUE_PROVENANCE')
    theory = case['statement']['theory']
    need(theory['functions'] == {} and all(v == 0 and type(v) is int
         for v in theory['predicates'].values()), 'GROUND_HORN_SIGNATURE')
    found = {}
    for ast in list(theory['axioms'].values()) + [case['statement']['goal']]:
        horn_subformulas(ast, found, meter)
    expected_formulas = [found[k] for k in sorted(found)]
    meter.same(value['formulas'], expected_formulas, 'ENTIRE_GROUND_HORN_SUBFORMULA_BASIS')
    expected_zeros = [dict(id='Z%06d' % i,
        native=dict(rule='axiom', formula=theory['axioms'][key], name=key))
        for i, key in enumerate(sorted(theory['axioms']))]
    meter.same(value['zeros'], expected_zeros, 'ENTIRE_NAMED_ASSUMPTION_ZERO_CATALOGUE')
    need(not value['gen'], 'NO_GROUND_HORN_GEN')
    return dict(status='VERIFIED', formulas=len(expected_formulas),
                zero_definitions=len(expected_zeros), mp_definitions=len(info['mp']),
                gen_definitions=0,
                scope='Complete declared ground pred0/imp subformula, named assumption ZERO and structural MP basis only; no full first-order completeness or native ZERO truth claim.')


def point(namespace, scope, slot, meter):
    meter.tick()
    prefixes = {'DAG-slot-center-v2': 'q:', 'DAG-slot-active-v2': 'a:',
                'DAG-slot-formula-v2': 'f:'}
    need(namespace in prefixes, 'COMPACT_PORT_NAMESPACE')
    return prefixes[namespace] + str(slot)


def reconstruct(value, slots, info, meter):
    need(integer(slots, 1), 'POSITIVE_SLOT_BOUND')
    need(type(value['profile'].get('slots')) is int
         and value['profile']['slots'] == slots, 'DECLARED_SLOT_BOUND')
    logical = {k: value[k] for k in ('schema', 'statement', 'formulas', 'zeros',
                                    'mp', 'gen', 'profile')}
    scope_preimage = dict(schema='Shared-fact-point-scope-v2', catalogue=logical,
        slots=slots, allow_padding=True, point_version='DAG-slot-ports-v2',
        candidate_version='DAG-candidate-v2')
    scope = meter.sha(scope_preimage)
    centers, active, formula_ports = [], [], []
    for i in range(slots):
        meter.tick()
        centers.append(point('DAG-slot-center-v2', scope, i, meter))
        active.append(point('DAG-slot-active-v2', scope, i, meter))
        formula_ports.append(point('DAG-slot-formula-v2', scope, i, meter))
    definitions = []
    for zero in value['zeros']:
        output = info['ids'][meter.wire(zero['native']['formula'])]
        definitions.append(dict(id=zero['id'], kind='ZERO', output=output,
            premises=[], native=zero['native'], variable=None))
    for mp in info['mp']:
        definitions.append(dict(id='mp:' + str(mp['implication']), kind='MP',
            output=mp['output'], premises=[mp['antecedent'], mp['implication']],
            native=None, variable=None))
    for gen in info['gen']:
        definitions.append(dict(id='gen:' + str(gen['output']), kind='GEN',
            output=gen['output'], premises=[gen['source']], native=None,
            variable=gen['variable']))
    definitions.append(dict(id='pad', kind='PAD', output=0, premises=[],
                            native=None, variable=None))
    rows, candidates = [], {}
    attempted = emitted = conflicts = 0
    by_kind = dict(ZERO=0, MP=0, GEN=0, PAD=0)

    def emit(slot, definition, refs):
        nonlocal attempted, emitted, conflicts
        meter.tick(1 + len(refs))
        attempted += 1
        own_active = '0' if definition['kind'] == 'PAD' else '1'
        marks = {active[slot]: own_active,
                 formula_ports[slot]: str(definition['output'])}
        for earlier, fid in zip(refs, definition['premises']):
            need(integer(earlier) and earlier < slot, 'INDEPENDENT_STRICT_PRIOR_REFERENCE')
            for port, mark in ((active[earlier], '1'),
                               (formula_ports[earlier], str(fid))):
                if port in marks and marks[port] != mark:
                    conflicts += 1
                    return
                marks[port] = mark
        cid = meter.wire([slot, definition['kind'], definition['id'], refs])
        need(cid not in candidates, 'INDEPENDENT_DUPLICATE_CID')
        row = dict(id=cid, t=[[centers[slot], 1]],
                   m=[[p, v] for p, v in sorted(marks.items())])
        meter.tick(1 + len(marks))
        rows.append(row)
        candidates[cid] = dict(slot=slot, definition=definition, refs=list(refs), row=row)
        emitted += 1
        by_kind[definition['kind']] += 1

    for i in range(slots):
        for definition in definitions:
            arity = len(definition['premises'])
            if arity == 0:
                emit(i, definition, [])
            elif arity == 1:
                for j in range(i):
                    emit(i, definition, [j])
            else:
                need(arity == 2, 'INDEPENDENT_RULE_ARITY')
                for j in range(i):
                    for k in range(i):
                        emit(i, definition, [j, k])
    rows.sort(key=lambda r: r['id'])
    binding = dict(scope=scope, scope_preimage=scope_preimage, slots=slots,
        goal_id=info['goal_id'], catalogue_sha256=meter.sha(value),
        original_statement_sha256=meter.sha(value['statement']))
    model = dict(schema='Z-growing-point-model-v1',
        version='Shared-fact-slots-active-formula-v2:' + scope, capacity=1,
        roots=sorted(centers), seed=dict(t=[], m=sorted([
            [active[-1], '1'], [formula_ports[-1], str(info['goal_id'])]])),
        inventory=dict(kind='EXPLICIT', placements=rows))
    return dict(binding=binding, model=model, universe=rows,
        definitions=definitions, candidates=candidates, centers=centers,
        active=active, formula_ports=formula_ports,
        enumeration=dict(attempted=attempted, emitted=emitted,
                         self_conflicts=conflicts, by_kind=by_kind))


def prepared_model(value, prepared, info, meter):
    need(type(prepared) is dict, 'PREPARED_RECORD')
    if prepared.get('status') == 'UNKNOWN':
        raise Bound('PREPARATION_NOT_COMPLETE')
    fields(prepared, ('schema', 'status', 'statement', 'catalogue', 'binding',
        'definitions', 'model', 'universe', 'census', 'limits', 'timings',
        'admission'), 'PREPARED_FIELDS')
    need(prepared['schema'] == 'Shared-fact-prepared-v2'
         and prepared['status'] == 'PREPARED_UNVERIFIED', 'PREPARED_STATUS')
    meter.same(prepared['catalogue'], value, 'EXACT_PREPARED_CATALOGUE')
    meter.same(prepared['statement'], value['statement'], 'EXACT_PREPARED_STATEMENT')
    need(type(prepared['binding']) is dict, 'PREPARED_BINDING')
    slots = prepared['binding'].get('slots')
    limits = prepared['limits']
    ceilings = dict(max_formulas=1024, max_rows=250000, max_slots=16,
        max_zero_definitions=8000, max_items=500000000, max_depth=128, wall_seconds=120.0)
    fields(limits, ceilings, 'PREPARATION_LIMIT_FIELDS')
    for key, cap in ceilings.items():
        v = limits[key]
        if key == 'wall_seconds':
            need(type(v) in (int, float) and math.isfinite(v) and 0 < v <= cap,
                 'PREPARATION_WALL_LIMIT')
        else:
            need(integer(v, 1) and v <= cap, 'PREPARATION_INTEGER_LIMIT')
    need(integer(slots, 1) and slots <= limits['max_slots'], 'PREPARED_SLOT_CAP')
    need(len(value['formulas']) <= limits['max_formulas']
         and len(value['zeros']) <= limits['max_zero_definitions'], 'PREPARED_BASIS_CAPS')
    # Structural MP uses a formula and its strictly larger implication, so a
    # single prior slot cannot supply both.  Check the census BEFORE allocating
    # the expected universe; never turn an over-cap universe into a shortlist.
    need(all(d['antecedent'] != d['implication'] for d in info['mp']), 'FINITE_MP_DISTINCT_INPUTS')
    sums = slots * (slots - 1) // 2
    squares = slots * (slots - 1) * (2 * slots - 1) // 6
    expected_rows = (slots * (len(value['zeros']) + 1)
                     + (squares - sums) * len(info['mp']) + sums * len(info['gen']))
    need(expected_rows <= limits['max_rows'], 'CLAIMED_PREPARED_FULL_UNIVERSE_CAP')
    built = reconstruct(value, slots, info, meter)
    meter.same(prepared['binding'], built['binding'], 'EXACT_SCOPE_AND_STATEMENT_BINDING')
    meter.same(prepared['model'], built['model'], 'ENTIRE_EXPLICIT_POINT_MODEL')
    meter.same(prepared['universe'], built['universe'], 'ENTIRE_COMPLETE_CANDIDATE_UNIVERSE')
    definitions = dict(zeros=[], mp=[], gen=[], pad=dict(id='pad', active=0, formula_id=0))
    for definition in built['definitions']:
        meter.tick()
        kind = definition['kind']
        if kind == 'ZERO':
            definitions['zeros'].append(dict(id=definition['id'], output=definition['output'],
                                             native=definition['native']))
        elif kind == 'MP':
            definitions['mp'].append(dict(id=definition['id'],
                antecedent=definition['premises'][0], implication=definition['premises'][1],
                output=definition['output']))
        elif kind == 'GEN':
            definitions['gen'].append(dict(id=definition['id'], source=definition['premises'][0],
                output=definition['output'], variable=definition['variable']))
    meter.same(prepared['definitions'], definitions, 'ENTIRE_PRIMITIVE_DEFINITION_TABLE')
    enumeration = built['enumeration']
    census = dict(formulas=len(value['formulas']), zero_definitions=len(value['zeros']),
        mp_definitions=len(info['mp']), gen_definitions=len(info['gen']), slots=slots,
        potential_rows=enumeration['attempted'], self_conflicting_rows=enumeration['self_conflicts'],
        rows=enumeration['emitted'], points_required=slots, mark_only_ports=2 * slots)
    meter.same(prepared['census'], census, 'EXACT_FULL_ENUMERATION_CENSUS')
    need(census['formulas'] <= limits['max_formulas'] and census['rows'] <= limits['max_rows']
         and slots <= limits['max_slots'] and census['zero_definitions'] <= limits['max_zero_definitions'],
         'COMPLETE_PREPARED_INVENTORY_WITHIN_DECLARED_LIMITS')
    fields(prepared['timings'], ('seconds', 'items'), 'PREPARATION_TIMING_FIELDS')
    need(type(prepared['timings']['seconds']) in (int, float)
         and math.isfinite(prepared['timings']['seconds']) and prepared['timings']['seconds'] >= 0
         and integer(prepared['timings']['items']), 'NONNEGATIVE_PREPARATION_METRICS')
    need(type(prepared['admission']) is str and bool(prepared['admission']), 'ADMISSION_SCOPE_TEXT')
    return built, census


def selected_certificate(value, built, selected, meter):
    """Exact point consistency plus primitive/native reference projection only."""
    need(type(selected) is list and all(type(cid) is str for cid in selected),
         'SELECTED_CID_ARRAY')
    need(len(set(selected)) == len(selected), 'DUPLICATE_SELECTED_CID')
    slots = built['binding']['slots']
    need(len(selected) == slots, 'EXACT_ONE_OWNER_PER_REQUIRED_SLOT')
    owners, marks = {}, dict(built['model']['seed']['m'])
    for cid in selected:
        meter.tick()
        need(cid in built['candidates'], 'SELECTED_OUTSIDE_COMPLETE_UNIVERSE')
        candidate = built['candidates'][cid]
        slot = candidate['slot']
        need(slot not in owners, 'DUPLICATE_SELECTED_SLOT_OWNER')
        owners[slot] = (cid, candidate)
        for p, v in candidate['row']['m']:
            meter.tick()
            need(p not in marks or marks[p] == v, 'SELECTED_GLOBAL_MARK_DISAGREEMENT')
            marks[p] = v
    need(set(owners) == set(range(slots)), 'ALL_EXPLICIT_ROOTS_FILLED')
    slot_to_native, native_to_slot = [None] * slots, []
    for slot in range(slots):
        meter.tick()
        if owners[slot][1]['definition']['kind'] != 'PAD':
            slot_to_native[slot] = len(native_to_slot)
            native_to_slot.append(slot)
    proof, slot_rows, references, dag, edges = [], [], [], [], []
    for slot in range(slots):
        meter.tick()
        cid, candidate = owners[slot]
        definition = candidate['definition']
        kind, output, refs = definition['kind'], definition['output'], candidate['refs']
        index = slot_to_native[slot]
        slot_rows.append(dict(slot=slot, cid=cid, active=int(kind != 'PAD'),
                              formula_id=output, native_line_index_or_null=index))
        if kind == 'PAD':
            need(output == 0 and marks[built['active'][slot]] == '0'
                 and marks[built['formula_ports'][slot]] == '0', 'PAD_ASSIGNED_ZERO')
            continue
        need(index == len(proof) and 1 <= output <= len(value['formulas']),
             'ACTIVE_OUTPUT_FORMULA_ID')
        dependencies = []
        for earlier in refs:
            mapped = slot_to_native[earlier]
            need(earlier < slot and type(mapped) is int and mapped < index,
                 'READ_MUST_BE_ACTIVE_STRICT_PRIOR_NATIVE_LINE')
            dependencies.append(mapped)
        if kind == 'ZERO':
            line = copy.deepcopy(definition['native'])
        elif kind == 'MP':
            need(len(dependencies) == 2, 'DECODE_MP_REFERENCE_ARITY')
            line = dict(rule='mp', formula=copy.deepcopy(value['formulas'][output - 1]),
                antecedent=dependencies[0], implication=dependencies[1])
        else:
            need(kind == 'GEN' and len(dependencies) == 1, 'DECODE_RULE')
            line = dict(rule='generalize', formula=copy.deepcopy(value['formulas'][output - 1]),
                source=dependencies[0], variable=definition['variable'])
        meter.same(line['formula'], value['formulas'][output - 1], 'NATIVE_OUTPUT_FORMULA_BINDING')
        proof.append(line)
        if refs:
            ref_fields = ('antecedent', 'implication') if kind == 'MP' else ('source',)
            references.append(dict(slot=slot, native_line=index, rule=line['rule'],
                slot_references=dict(zip(ref_fields, refs)),
                native_references=dict(zip(ref_fields, dependencies))))
            edges.extend(dict(premise=prior, conclusion=index, field=field)
                         for field, prior in zip(ref_fields, dependencies))
        dag.append(dict(line=index, slot=slot, formula_id=output))
    need(slot_to_native[-1] is not None and bool(proof), 'LAST_SLOT_ACTIVE')
    meter.same(proof[-1]['formula'], value['statement']['goal'], 'UNCHANGED_FINAL_GOAL')
    return dict(status='UNVERIFIED_NATIVE_CERTIFICATE', schema='Independent-shared-fact-decoded-v2',
        version=VERSION, statement=copy.deepcopy(value['statement']), proof=proof,
        slots=slot_rows, slot_to_native=slot_to_native, native_to_slot=native_to_slot,
        reference_mapping=references, proof_dag=dict(nodes=dag, edges=edges),
        selected=sorted(selected),
        selected_sha256=meter.sha(sorted(selected)),
        original_statement_sha256=built['binding']['original_statement_sha256'],
        scope=built['binding']['scope'],
        logical_validity='NOT_RUN_BY_THIS_MODULE',
        point_scope='Exact one owner/unit at every explicit slot, full seed/global m agreement, strict-prior active receptors and literal native projection. Native ZERO and whole-proof truth require a separate kernel receipt.')


def run_checked(operation, values, max_items, max_work, wall_seconds):
    meter = None
    try:
        meter = Meter(max_items, max_work, wall_seconds)
        for value in values:
            meter.scan(value)
        result = operation(meter)
        meter.tick()
        return dict(result, checker=VERSION, checker_costs=meter.counters())
    except Bound as error:
        return dict(status='UNKNOWN', reason=str(error), checker=VERSION,
                    checker_costs={} if meter is None else meter.counters())
    except (MemoryError, RecursionError, OverflowError) as error:
        return dict(status='UNKNOWN', reason='CHECKER_RESOURCE:' + type(error).__name__,
                    checker=VERSION, checker_costs={} if meter is None else meter.counters())
    except (Rejected, KeyError, IndexError, TypeError, ValueError) as error:
        return dict(status='REJECTED', reason=str(error), checker=VERSION,
                    checker_costs={} if meter is None else meter.counters())


def verify_basis(case, value, *, max_items=500000000, max_work=1000000000,
                 wall_seconds=120.0):
    """Independently enumerate the declared complete ground-Horn basis."""
    def operation(meter):
        info = catalogue(value, meter)
        receipt = ground_basis(case, value, info, meter)
        return dict(receipt, catalogue_sha256=meter.sha(value),
                    original_statement_sha256=meter.sha(value['statement']),
                    native_zero_validity='SEPARATE_EXTERNAL_NATIVE_KERNEL_GATE')
    return run_checked(operation, (case, value), max_items, max_work, wall_seconds)


def verify_model(value, prepared, *, max_items=500000000, max_work=1000000000,
                 wall_seconds=120.0):
    """Reconstruct all bounded rows; generic formula/ZERO admission is external."""
    def operation(meter):
        info = catalogue(value, meter)
        built, census = prepared_model(value, prepared, info, meter)
        return dict(status='VERIFIED', reason='COMPLETE_FINITE_SHARED_FACT_POINT_REDUCTION',
            scope=built['binding']['scope'], catalogue_sha256=meter.sha(value),
            original_statement_sha256=built['binding']['original_statement_sha256'],
            model_sha256=meter.sha(built['model']), universe_sha256=meter.sha(built['universe']),
            census=census, row_counts_by_kind=built['enumeration']['by_kind'],
            generic_basis_scope='Supplied literal finite formula/ZERO catalogue with complete structural MP and enabled GEN. Formula/ZERO-profile coverage beyond the ground-Horn verifier and native ZERO truth are separate obligations.',
            native_logical_validity='NOT_RUN_BY_THIS_MODULE')
    return run_checked(operation, (value, prepared), max_items, max_work, wall_seconds)


def verify(case, value, prepared, *, max_items=500000000, max_work=1000000000,
           wall_seconds=120.0):
    """Join independent whole ground basis and complete bounded point model."""
    def operation(meter):
        info = catalogue(value, meter)
        basis = ground_basis(case, value, info, meter)
        built, census = prepared_model(value, prepared, info, meter)
        return dict(status='VERIFIED', reason='COMPLETE_GROUND_BASIS_AND_SHARED_FACT_MODEL',
            basis=basis, scope=built['binding']['scope'], catalogue_sha256=meter.sha(value),
            original_statement_sha256=built['binding']['original_statement_sha256'],
            model_sha256=meter.sha(built['model']), universe_sha256=meter.sha(built['universe']),
            census=census, row_counts_by_kind=built['enumeration']['by_kind'],
            native_zero_validity='SEPARATE_EXTERNAL_NATIVE_KERNEL_GATE',
            trace_and_native_proof_validity='NOT_RUN_BY_THIS_MODULE')
    return run_checked(operation, (case, value, prepared), max_items, max_work, wall_seconds)


def decode(prepared, selected, *, max_items=500000000, max_work=1000000000,
           wall_seconds=120.0):
    """Independently project a complete selected assignment to a native proof.

    This rechecks catalogue structure and the entire prepared model, but does
    not by itself claim a generation-profile or native logical validity gate.
    """
    def operation(meter):
        need(type(prepared) is dict and 'catalogue' in prepared, 'DECODER_PREPARED_CATALOGUE')
        value = prepared['catalogue']
        info = catalogue(value, meter)
        built, census = prepared_model(value, prepared, info, meter)
        return dict(selected_certificate(value, built, selected, meter), census=census)
    return run_checked(operation, (prepared, selected), max_items, max_work, wall_seconds)

