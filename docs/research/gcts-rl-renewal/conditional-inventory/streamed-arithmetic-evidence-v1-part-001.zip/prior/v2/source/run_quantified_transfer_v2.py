"""Single-attempt, frozen-source quantified marking research driver.

No scientific module is imported before immutable protocol admission. Every
phase has an owned native process and exclusive outputs. Prefixes, refusals,
unknowns and native failures are retained, never silently replayed.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
PROTOCOL = 'protocol/frozen-protocol-v1.json'
PHASES = ['qualify', 'prepare', 'acquire', 'label', 'learn', 'evaluate']
ADMITTED = dict(qualify='QUALIFIED', prepare='PREPARED', acquire='ACQUIRED_PROPOSAL',
                label='LABELLED', learn='LEARNED_CERTIFIED', evaluate='EVALUATED')
CAPTURE_BYTES = 134217728
GUARDS = dict(wall_seconds=1200.0, cpu_seconds=900, rss_bytes=2147483648)
LIMITS = dict(
    engine=dict(wall_seconds=120.0, max_work=100000000000, max_nodes=100000,
                max_events=400000, max_rollback_records=200000,
                max_candidates=250000, max_points=128),
    semantic=dict(max_items=1000000000, max_work=500000000000, wall_seconds=300.0),
    trace=dict(max_items=1000000000, wall_seconds=120.0),
    oracle=dict(max_candidates=16, max_subsets=65536, max_work=1000000000, wall_seconds=60.0),
    native=dict(max_depth=256, max_operations=10000000, max_proof_lines=4096),
    rf=dict(max_items=100000000, max_work=1000000000, wall_seconds=30.0),
    bridge=dict(max_formulas=1024, max_zero_definitions=8000, max_definitions=8000,
                max_slots=16, max_items=500000000, max_depth=128, wall_seconds=120.0),
    model=dict(max_formulas=1024, max_rows=250000, max_slots=16,
               max_zero_definitions=8000, max_items=500000000, max_depth=128, wall_seconds=120.0),
    checker=dict(max_items=500000000, max_work=1000000000, wall_seconds=120.0),
    overlay=dict(max_work=1000000000, wall_seconds=120.0))
MODULES = dict(E='source/growing_point_search_v4.py', C='source/semantic_event_checker_v3.py',
    T='source/frontier_trace_checker_v3.py', O='source/tiny_assignment_oracle_v2.py',
    F='reference/finite_basis_v1.py', R='reference/rf_catalogue_checker_v1.py',
    B='reference/independent_fol_checker_v1.py', A='source/rf_shared_bridge_v1.py',
    Q='source/rf_shared_bridge_checker_v1.py', M='source/shared_fact_model_v2.py',
    N='source/shared_fact_checker_v2.py', L='source/unary_overlay_v1.py',
    U='source/unary_overlay_checker_v2.py', H='source/arithmetic_phases_v2.py',
    K='source/qualification_phase_v2.py')


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def local(name):
    need(type(name) is str and not Path(name).is_absolute(), 'RELATIVE_TASK_PATH')
    p = (ROOT / name).resolve()
    need(p.is_relative_to(ROOT), 'TASK_PATH_ESCAPE')
    return p


def pin(path):
    h, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            size += len(part)
            h.update(part)
    return dict(bytes=size, sha256=h.hexdigest())


def ref(name):
    return dict(path=name, **pin(local(name)))


def read(name):
    path = local(name)
    with (gzip.open(path, 'rt', encoding='ascii') if path.suffix == '.gz'
          else path.open('r', encoding='ascii')) as stream:
        return json.load(stream)


def save(name, value):
    path = local(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    count, complete = 0, True
    with path.open('xb') as raw:
        out = gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) if path.suffix == '.gz' else raw
        try:
            for part in json.JSONEncoder(sort_keys=True, ensure_ascii=True,
                    separators=(',', ':'), allow_nan=False).iterencode(value):
                part = part.encode('ascii')
                if count + len(part) >= CAPTURE_BYTES:
                    out.write(part[:CAPTURE_BYTES-count])
                    count, complete = CAPTURE_BYTES, False
                    break
                out.write(part)
                count += len(part)
            if complete:
                out.write(b'\n')
                count += 1
        finally:
            if out is not raw:
                out.close()
    result = dict(path=name, **pin(path), logical_json_bytes=count, complete_json=complete)
    if not complete:
        with local(name + '.capture-refusal.json').open('x') as stream:
            json.dump(dict(status='UNKNOWN_CAPTURE', prefix=result), stream)
        raise RuntimeError('UNKNOWN_CAPTURE:' + name)
    return result


def runtime():
    path = Path(sys.executable).resolve()
    return dict(executable=dict(path=str(path), **pin(path)), version=sys.version,
                isolated=sys.flags.isolated, no_site=sys.flags.no_site,
                dont_write_bytecode=sys.dont_write_bytecode)


def scientific_files():
    names = set()
    for folder in ('source', 'reference', 'input', 'plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(), 'NO_SOURCE_SYMLINK')
            if path.is_file():
                need(path.suffix != '.pyc' and '__pycache__' not in path.parts, 'NO_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    admission = read('review/root-source-admission-v1.json')
    need(admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'ROOT_SOURCE_ADMISSION')
    names.add('review/root-source-admission-v1.json')
    for item in admission['reviewed']:
        need(pin(local(item['path'])) == {k: item[k] for k in ('bytes','sha256')}, 'REVIEW_PIN')
        names.add(item['path'])
    return [ref(name) for name in sorted(names)]


def protocol_limits():
    return dict(scientific=LIMITS, guards=GUARDS, capture_bytes=CAPTURE_BYTES)


def freeze():
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
         'ISOLATED_NO_SITE_NO_BYTECODE')
    need(not local(PROTOCOL).exists(), 'PRESERVE_FIRST_FREEZE')
    need(pin(local('reference/basic-tiling-algorithm.md'))['sha256'] ==
         'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9', 'PINNED_MASTER')
    need(pin(MASTER) == pin(local('reference/basic-tiling-algorithm.md')), 'CURRENT_MASTER_COPY')
    return save(PROTOCOL, dict(schema='Quantified-marking-transfer-protocol-v1',
        status='FROZEN_BEFORE_SCIENTIFIC_IMPORTS', files=scientific_files(),
        runtime=runtime(), limits=protocol_limits(), phases=PHASES,
        admitted_statuses=ADMITTED, master=dict(path=str(MASTER), **pin(MASTER)),
        frozen_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        scope='Full RF quantified arithmetic in eight shared proof slots; certificate-guided extra unary layer; matched ordinary filter. Finite model, no RL or performance superiority claim.'))


def unchanged():
    protocol = read(PROTOCOL)
    need(protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_STATUS')
    need(protocol['files'] == scientific_files(), 'FROZEN_SOURCE_INPUT_REVIEW_SET')
    need(protocol['runtime'] == runtime() and protocol['limits'] == protocol_limits(), 'FROZEN_RUNTIME_LIMITS')
    need(protocol['phases'] == PHASES and protocol['admitted_statuses'] == ADMITTED, 'FROZEN_PHASES')
    need(pin(MASTER) == {k: protocol['master'][k] for k in ('bytes','sha256')}, 'MASTER_UNCHANGED')
    return protocol


def admitted(phase):
    result = read('data/' + phase + '/result.json')
    invocation = read('run/' + phase + '/invocation.json')
    observer = read('run/' + phase + '/observer.json')
    started = read('run/' + phase + '/started.json')
    need(result['status'] == ADMITTED[phase], 'PRIOR_SCIENTIFIC_ADMISSION:' + phase)
    need(started['phase'] == invocation['phase'] == observer['phase'] == phase, 'PRIOR_PHASE_ASSOCIATION')
    need(all(type(item['pid']) is int and item['pid'] > 0 for item in (started,invocation,observer)), 'PRIOR_NATIVE_PIDS')
    need(invocation['scientific_status'] == result['status'], 'PRIOR_SCIENTIFIC_STATUS_JOIN')
    need(invocation['status'] == 'COMPLETE' and invocation['error_type'] is None, 'PRIOR_INVOCATION_CLEAN')
    need(observer['status'] == 'TERMINAL' and type(observer['native_exit_code']) is int
         and observer['native_exit_code'] == 0, 'PRIOR_ACTUAL_NATIVE_EXIT')
    need(started['pid'] == invocation['pid'] == observer['pid'], 'PRIOR_PID_ASSOCIATION')
    need(all(observer[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
         and invocation['postcheck_error'] is None, 'PRIOR_GUARDS_CLEAN')
    need(observer['frozen_postcheck'] == invocation['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS',
         'PRIOR_SOURCE_POSTCHECK')
    need(started['protocol'] == ref(PROTOCOL), 'PRIOR_PROTOCOL_REF')
    need({k: invocation['result'][k] for k in ('path','bytes','sha256')} == ref('data/' + phase + '/result.json')
         and invocation['result']['complete_json'] is True, 'PRIOR_RESULT_BYTES')
    need(observer['log'] == ref('run/' + phase + '/stdout.log'), 'PRIOR_LOG_BYTES')
    return result


def modules():
    unchanged()
    result = {}
    for key, name in MODULES.items():
        spec = importlib.util.spec_from_file_location('qmt_' + key, local(name))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result[key] = module
    return result


def paired_graphs(C, model, raw, observations):
    meter = C.Meter(items=LIMITS['semantic']['max_items'], work=LIMITS['semantic']['max_work'],
                    seconds=LIMITS['semantic']['wall_seconds'])
    try:
        for value in (model, raw, observations):
            meter.scan(value, input_items=True)
        reader = C.Reader(model, raw, meter)
        need(len(observations) == len(raw['events']) == raw['event_extent']['total'], 'COMPLETE_ACTUAL_CALLBACKS')
        rows = []
        for index, observed in enumerate(observations):
            meter.same(observed['event'], raw['events'][index], 'OBSERVED_EVENT')
            reader.event(observed['event'], index)
            reconstructed = reader.snapshot()
            meter.same(reconstructed, observed['state'], 'RECONSTRUCTED_EQUALS_ACTUAL_GRAPH')
            rows.append(dict(seq=index, kind=observed['event']['kind'], actual_sha256=meter.sha(observed['state']),
                             reconstructed_sha256=meter.sha(reconstructed), equal=True))
        if raw['status'] == 'UNKNOWN':
            return dict(status='UNKNOWN', reason='RESOURCE_PREFIX_ONLY', comparisons=rows,
                        events_checked=len(rows), bounded_absence=False)
        meter.same(reader.snapshot(), raw['final_state'], 'ACTUAL_FINAL_GRAPH')
        meter.tick()
        return dict(status='VERIFIED', events_checked=len(rows), comparisons=rows,
                    items=meter.items, work=meter.work, scope='Actual callback maps, independently replayed C graph; T separately re-enumerates.')
    except (C.Incomplete, C.Budget) as error:
        return dict(status='UNKNOWN', reason=str(error), bounded_absence=False)


class Context:
    root = ROOT
    read = staticmethod(read)
    save = staticmethod(save)
    sha = staticmethod(sha)
    wire = staticmethod(wire)

    def __init__(self, mods):
        self.mods = mods
        self.limits = dict(LIMITS)
        for key, group in dict(E='engine', C='semantic', T='trace', O='oracle', B='native',
                              R='rf', A='bridge', M='model', N='checker', Q='checker', L='overlay', U='overlay').items():
            self.limits[key] = LIMITS[group]

    def engine(self, name, model, actual=False, max_nodes=None):
        prefix, observations = 'data/engine/' + name, []
        point = dict(LIMITS['engine'])
        if max_nodes is not None:
            need(type(max_nodes) is int and 0 <= max_nodes <= point['max_nodes'], 'NODE_OVERRIDE_ONLY_LOWER')
            point['max_nodes'] = max_nodes
        refs = dict(model=save(prefix + '/model.json.gz', model))
        def audit(event, state, charge):
            if len(observations) >= point['max_events']:
                charge(point['max_work'] + 1)
            charge(1)
            observations.append(dict(event=event, state=state))
        started = time.perf_counter()
        raw = self.mods['E'].solve(model, point, audit=audit if actual else None, order=None)
        engine_seconds = time.perf_counter() - started
        refs['raw'] = save(prefix + '/raw.json.gz', raw)
        refs['observations'] = save(prefix + '/observations.json.gz', observations)
        started = time.perf_counter()
        semantic = self.mods['C'].verify_explicit_events(model, raw, **LIMITS['semantic'])
        semantic_seconds = time.perf_counter() - started
        refs['semantic'] = save(prefix + '/semantic.json.gz', semantic)
        result = dict(raw=raw, semantic=semantic, observations=observations, refs=refs)
        if actual:
            trace = self.mods['T'].verify(model, model['inventory']['placements'], observations, raw, **LIMITS['trace'])
            refs['full_graphs'] = save(prefix + '/full-graphs.json.gz', trace)
            graphs = paired_graphs(self.mods['C'], model, raw, observations)
            refs['paired_graphs'] = save(prefix + '/paired-graphs.json.gz', graphs)
            result.update(trace=trace, graphs=graphs)
        save(prefix + '/attempt.json', dict(engine_calls=1, engine_seconds=engine_seconds,
            semantic_seconds=semantic_seconds, raw_status=raw['status'], semantic_status=semantic['status'],
            actual_snapshots=len(observations), raw_stats=raw['stats'], refs=refs,
            scope='Large arithmetic uses semantic events and serialized endpoints; only actual=True captures intermediate producer graphs.'))
        print(json.dumps(dict(stage=prefix, raw=raw['status'], semantic=semantic['status'], seconds=engine_seconds)), flush=True)
        return result

    def make_provenance(self, label_result):
        need(wire(admitted('label')) == wire(label_result), 'AUTHENTIC_PRIOR_LABEL_RESULT')
        # Authenticate every physical packet reference before U reads supplied objects.
        for binding in label_result['query_bindings']:
            for evidence in binding['evidence_refs'].values():
                need(ref(evidence['path']) == {k: evidence[k] for k in ('path','bytes','sha256')}, 'PHYSICAL_QUERY_REFERENCE')
        return dict(schema='Unary-overlay-provenance-v1', mode='FRESH_FIXED_CID_LABEL_PHASE',
            engine_version=self.mods['E'].VERSION, semantic_version=self.mods['C'].VERSION,
            protocol=dict(value=unchanged(), ref=ref(PROTOCOL)),
            sources=dict(engine=ref(MODULES['E']), semantic=ref(MODULES['C']), driver=ref('source/run_quantified_transfer_v2.py')),
            label_phase=dict(started=read('run/label/started.json'), invocation=read('run/label/invocation.json'),
                observer=read('run/label/observer.json'), result=label_result,
                result_ref=ref('data/label/result.json'), log_ref=ref('run/label/stdout.log')))


def prerequisites(phase):
    for previous in PHASES[:PHASES.index(phase)]:
        admitted(previous)


def worker(phase):
    unchanged()
    prerequisites(phase)
    save('run/' + phase + '/started.json', dict(phase=phase, pid=os.getpid(), protocol=ref(PROTOCOL)))
    started, result, result_ref = time.perf_counter(), None, None
    try:
        ctx = Context(modules())
        result = ctx.mods['K'].run(ctx) if phase == 'qualify' else ctx.mods['H'].run(phase, ctx)
        result_ref = save('data/' + phase + '/result.json', result)
    finally:
        error, post_error = sys.exc_info()[0], None
        try:
            postcheck = unchanged()['status']
        except Exception as failure:
            postcheck, post_error = 'FAILED', str(failure)
        save('run/' + phase + '/invocation.json', dict(status='ERROR' if error or post_error else 'COMPLETE',
            phase=phase, pid=os.getpid(), scientific_status=result.get('status') if result else None,
            result=result_ref, seconds=time.perf_counter()-started, error_type=error.__name__ if error else None,
            frozen_postcheck=postcheck, postcheck_error=post_error,
            maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            maxrss_units='bytes' if sys.platform == 'darwin' else 'KiB'))
        if post_error and error is None:
            raise RuntimeError('FROZEN_POSTCHECK:' + post_error)


def supervise(phase):
    unchanged()
    prerequisites(phase)
    for name in ('started.json','invocation.json','observer.json','stdout.log'):
        need(not local('run/' + phase + '/' + name).exists(), 'PRESERVE_FIRST_ATTEMPT')
    need(not local('data/' + phase + '/result.json').exists(), 'PRESERVE_FIRST_RESULT')
    path = local('run/' + phase + '/stdout.log')
    path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    child = code = reason = error_text = reap_error = None
    peak, samples = 0, []
    def cpu_guard():
        resource.setrlimit(resource.RLIMIT_CPU, (GUARDS['cpu_seconds'], GUARDS['cpu_seconds']+1))
    with path.open('xb') as output:
        try:
            child = subprocess.Popen([sys.executable, '-I','-S','-B',str(Path(__file__).resolve()),'_worker',phase],
                cwd=ROOT, env={'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1'},
                stdout=output, stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=cpu_guard)
            while child.poll() is None:
                probe = subprocess.run(['/bin/ps','-o','rss=','-p',str(child.pid)], capture_output=True, text=True, timeout=5)
                if probe.returncode == 0 and probe.stdout.strip():
                    rss = int(probe.stdout.strip())*1024
                    if rss > peak:
                        peak = rss
                        samples.append(dict(seconds=time.perf_counter()-started, rss_bytes=rss))
                    if rss > GUARDS['rss_bytes']:
                        reason = 'RSS_POLL_BOUND'
                        break
                elif child.poll() is None:
                    reason = 'RSS_PROBE_FAILED'
                    break
                if time.perf_counter()-started > GUARDS['wall_seconds']:
                    reason = 'WALL_BOUND'
                    break
                time.sleep(.2)
        except BaseException as error:
            reason, error_text = 'OBSERVER_ERROR:' + type(error).__name__, str(error)
        finally:
            if child is not None:
                if reason and child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    except OSError as error:
                        error_text = str(error)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try:
                            os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        except OSError as error:
                            error_text = str(error)
                    except OSError as error:
                        error_text = 'TERM_WAIT_ERROR:' + str(error)
                try:
                    code = child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    reap_error = 'NATIVE_EXIT_UNOBSERVED'
                except OSError as error:
                    reap_error = 'NATIVE_WAIT_ERROR:' + str(error)
    post_error = None
    try:
        postcheck = unchanged()['status']
    except Exception as error:
        postcheck, post_error = 'FAILED', str(error)
    result = dict(status='TERMINAL' if code is not None else 'UNADMITTED_PROCESS', phase=phase,
        pid=child.pid if child else None, native_exit_code=code, guard_reason=reason,
        observer_error=error_text, reap_error=reap_error, seconds=time.perf_counter()-started,
        peak_observed_rss_bytes=peak, rss_samples=samples, log=ref('run/' + phase + '/stdout.log'),
        frozen_postcheck=postcheck, postcheck_error=post_error,
        scope='One owned process with native wait status; RSS is sampled, not a hard allocation limit. No silent replay.')
    save('run/' + phase + '/observer.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('freeze','run','_worker'))
    parser.add_argument('phase', nargs='?', choices=PHASES)
    args = parser.parse_args()
    need((args.command == 'freeze') == (args.phase is None), 'COMMAND_PHASE')
    answer = freeze() if args.command == 'freeze' else supervise(args.phase) if args.command == 'run' else worker(args.phase)
    print(json.dumps(answer, sort_keys=True), flush=True)
    if args.command == 'run' and not (answer['status'] == 'TERMINAL'
            and type(answer['native_exit_code']) is int and answer['native_exit_code'] == 0
            and all(answer[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and answer['frozen_postcheck'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS'):
        raise SystemExit(1)
