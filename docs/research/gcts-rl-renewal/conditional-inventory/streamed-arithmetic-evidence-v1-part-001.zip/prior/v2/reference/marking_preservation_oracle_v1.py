"""Independent exhaustive finite-inventory marking preservation oracle.

Only stdlib imports. No engine/checker/learner/model-helper calls, incremental
graph, scheduler, supplied witness or training labels. Preservation verify()
must run after the learned model/control freeze; its outputs never train the
pilot. Generic enumerate_model() separately qualifies frozen tiny E3 models.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-finite-marking-preservation-oracle-v1'


class _Malformed(Exception):
    pass


class _Limit(Exception):
    pass


def _require(ok, reason):
    if not ok:
        raise _Malformed(reason)


class _Meter:
    def __init__(self, work, wall):
        self.work = 0
        self.limit = work
        self.deadline = time.perf_counter() + wall
        self.bytes_reserved = 0

    def tick(self, n=1):
        self.work += n
        if self.work > self.limit:
            raise _Limit('MAX_WORK')
        if time.perf_counter() >= self.deadline:
            raise _Limit('WALL_SECONDS')

    def scan(self, value):
        def members(d):
            for k,v in d.items():
                _require(type(k) is str, 'STRING_DICTIONARY_KEY')
                yield k
                yield v
        stack = [(iter((value,)), 0)]
        bound = 1
        while stack:
            self.tick()
            it, depth = stack[-1]
            try:
                x = next(it)
            except StopIteration:
                stack.pop()
                continue
            if depth > 64:
                raise _Limit('JSON_DEPTH')
            if type(x) is str:
                self.tick(len(x))
                bound += 4 + 12 * len(x)
            elif type(x) is int:
                _require(x.bit_length() <= 256, 'INTEGER_BITS')
                self.tick(x.bit_length())
                bound += 84
            elif x is None or type(x) is bool:
                bound += 8
            elif type(x) is list:
                bound += 4
                stack.append((iter(x), depth + 1))
            elif type(x) is dict:
                bound += 4
                stack.append((members(x), depth + 1))
            else:
                raise _Malformed('NATIVE_JSON_ONLY')
        return bound

    def reserve(self, value):
        bound = self.scan(value)
        self.tick(bound)
        self.bytes_reserved += bound

    def sha(self, value):
        self.reserve(value)
        raw = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        self.tick()
        return hashlib.sha256(raw).hexdigest()


def _fields(value, names):
    _require(type(value) is dict and set(value) == set(names),
             'EXACT_FIELDS:' + ','.join(sorted(names)))


def _rows(value, capacity, meter, marking=False, seed=False):
    _require(type(value) is list, 'POINT_ROWS_LIST')
    out = {}
    for row in value:
        meter.tick()
        _require(type(row) is list and len(row) == 2 and type(row[0]) is str
                 and row[0] not in out, 'DISTINCT_LITERAL_POINT_ROW')
        p,v = row
        if marking:
            _require(type(v) is str, 'LITERAL_MARKING_VALUE')
        else:
            _require(type(v) is int and (0 if seed else 1) <= v <= capacity
                     and v.bit_length() <= 256, 'EXACT_CAPACITY_UNITS')
        out[p] = v
    meter.tick(len(out) * max(1, len(out).bit_length()))
    return [[p,out[p]] for p in sorted(out)]


def _normalize(model, max_candidates, meter):
    _fields(model, {'schema','version','capacity','roots','seed','inventory','pair_nogoods'})
    _require(model['schema'] == 'Z-growing-point-model-v2'
             and type(model['version']) is str and bool(model['version']), 'MODEL_VERSION')
    c = model['capacity']
    _require(type(c) is int and c >= 1 and c.bit_length() <= 256, 'CAPACITY')
    roots = model['roots']
    _require(type(roots) is list and all(type(p) is str for p in roots)
             and len(roots) == len(set(roots)), 'DISTINCT_LITERAL_ROOTS')
    _fields(model['seed'], {'t','m'})
    seed = dict(t=_rows(model['seed']['t'],c,meter,seed=True),
                m=_rows(model['seed']['m'],c,meter,marking=True))
    _fields(model['inventory'], {'kind','placements'})
    raw = model['inventory']['placements']
    _require(model['inventory']['kind'] == 'EXPLICIT' and type(raw) is list, 'EXPLICIT_ONLY')
    if len(raw) > max_candidates:
        raise _Limit('MAX_CANDIDATES')
    rows = {}
    for r in raw:
        meter.tick()
        _fields(r, {'id','t','m'})
        cid = r['id']
        _require(type(cid) is str and bool(cid) and cid not in rows, 'UNIQUE_NONEMPTY_CID')
        t = _rows(r['t'],c,meter)
        _require(bool(t), 'POSITIVE_SUPPORT_REQUIRED')
        rows[cid] = dict(id=cid,t=t,m=_rows(r['m'],c,meter,marking=True))
    meter.tick(len(rows) * max(1,len(rows).bit_length()))
    pairs = _canonical_pairs(model['pair_nogoods'],set(rows),meter)
    return dict(schema=model['schema'],version=model['version'],capacity=c,roots=sorted(roots),
                seed=seed,inventory=dict(kind='EXPLICIT',placements=[rows[x] for x in sorted(rows)]),
                pair_nogoods=pairs)


def _canonical_pairs(value, ids, meter):
    _require(type(value) is list, 'PAIR_NOGOODS_LIST')
    pairs = []
    for pair in value:
        meter.tick()
        _require(type(pair) is list and len(pair)==2 and all(type(x) is str for x in pair)
                 and pair[0] < pair[1] and all(x in ids for x in pair), 'CANONICAL_TWO_DISTINCT_CIDS')
        pairs.append(list(pair))
    _require(pairs == sorted(pairs) and len({tuple(x) for x in pairs}) == len(pairs),
             'CANONICAL_UNIQUE_SORTED_PAIR_LIST')
    return pairs


def _sums(model, chosen, meter):
    meter.tick(1+len(model['seed']['t'])+len(model['roots']))
    t = dict(model['seed']['t'])
    active = set(model['roots']) | {p for p,n in model['seed']['t'] if n > 0}
    rows = model['inventory']['placements']
    for i in chosen:
        for p,n in rows[i]['t']:
            meter.tick()
            t[p] = t.get(p,0) + n
            active.add(p)
    return t,active,all(n <= model['capacity'] for n in t.values())


def _literal_marks(model, chosen, meter, export=False):
    groups = {}
    for p,v in model['seed']['m']:
        meter.tick(1+len(p)+len(v))
        groups[p] = {v:1}
    rows = model['inventory']['placements']
    for i in chosen:
        for p,v in rows[i]['m']:
            meter.tick(1+len(p)+len(v))
            at = groups.setdefault(p,{})
            at[v] = at.get(v,0) + 1
    compatible = all(len(at)==1 for at in groups.values())
    if not export:
        return compatible
    return compatible,[[p,[[v,n] for v,n in sorted(groups[p].items())]] for p in sorted(groups)]


def _pair_free(pair_indices, chosen, meter):
    meter.tick(1+len(chosen))
    selected = set(chosen)
    answer = True
    for i,j in pair_indices:
        meter.tick()
        if i in selected and j in selected:
            answer = False
    return answer


def _reachable(model, chosen, meter):
    meter.tick(1+len(model['roots'])+len(model['seed']['t']))
    reached = set(model['roots']) | {p for p,n in model['seed']['t'] if n > 0}
    rows = model['inventory']['placements']
    pending = list(chosen)
    while pending:
        rest = []
        for i in pending:
            meter.tick(1+len(rows[i]['t']))
            if any(p in reached for p,n in rows[i]['t']):
                reached.update(p for p,n in rows[i]['t'])
            else:
                rest.append(i)
        if len(rest) == len(pending):
            return False
        pending = rest
    return True


def verify(base_model, marked_model, pair_nogoods, *, max_candidates=16,
           max_subsets=65536, wall_seconds=10, max_work=10000000):
    """VERIFIED means complete finite subset/solution/domain preservation.

    Every base-capacity-legal subset is checked, including unreachable subsets.
    Mark/direct eligibility means that adjoining the unselected CID preserves
    capacity and the entire selected-family constraint. Thus an already-invalid
    marked/direct family has no eligible extension. Reachability is used only
    for exact-cover solution membership, not for that stronger pointwise test.
    """
    started = time.perf_counter()
    meter = None
    evidence = dict(subsets=[],base_solutions=[],marked_solutions=[],direct_solutions=[],
                    meeting_pairs=[],nogood_extensions=[])
    counts = dict(subsets_checked=0,base_capacity_legal_subsets=0,reachable_capacity_legal_subsets=0,
                  eligibility_states_checked=0,candidate_extensions_checked=0,
                  marking_checks=0,pair_constraint_checks=0,pair_catalog_tests=0,
                  marking_equivalence_failures=0,eligibility_equivalence_failures=0,
                  domain_equivalence_failures=0,edge_equivalence_failures=0)
    bindings = {}
    normalized = None
    ids = []
    total = None
    phase = 'INPUT'

    def finish(status, reason, **extra):
        return dict(schema='Finite-marking-preservation-receipt-v1',oracle=VERSION,
                    status=status,reason=reason,seconds=time.perf_counter()-started,
                    work=0 if meter is None else meter.work,
                    evidence_byte_reservation=0 if meter is None else meter.bytes_reserved,
                    counts=counts,bindings=bindings,candidate_ids=ids,subsets_total=total,
                    phase=phase,
                    subsets_coverage='COMPLETE' if total is not None and counts['subsets_checked']==total else 'PREFIX',
                    meeting_pair_coverage='COMPLETE' if phase in ('NOGOOD_EXTENSIONS','COMPLETE') else 'PREFIX',
                    nogood_extension_coverage='COMPLETE' if phase=='COMPLETE' else 'PREFIX',
                    models=normalized,evidence=evidence,
                    scope='Exact anchored finite EXPLICIT inventory only. No geometry/symmetry transfer, '
                          'scheduler/generation/rollback conformance, native logical truth or infinite extension.',
                    acquisition='POST_LEARNER_AND_MODEL_FREEZE_ONLY; outputs must not train the learner; '
                                'driver enforces timing/provenance externally.',**extra)

    try:
        for name,v,lo,hi in [('max_candidates',max_candidates,0,16),
                             ('max_subsets',max_subsets,0,65536),
                             ('max_work',max_work,0,1000000000)]:
            _require(type(v) is int and lo <= v <= hi, 'LIMIT_' + name)
        _require(type(wall_seconds) in (int,float) and math.isfinite(wall_seconds)
                 and 0 < wall_seconds <= 60, 'LIMIT_wall_seconds')
        meter = _Meter(max_work,wall_seconds)
        for value in (base_model,marked_model,pair_nogoods):
            meter.scan(value)
        base = _normalize(base_model,max_candidates,meter)
        marked = _normalize(marked_model,max_candidates,meter)
        _require(base['pair_nogoods'] == marked['pair_nogoods'] == [], 'PILOT_MODEL_PAIRS_MUST_BE_EMPTY')
        _require(base['seed']['m'] == [] and all(r['m'] == [] for r in base['inventory']['placements']),
                 'BASE_MARKINGS_MUST_BE_EMPTY')
        _require(marked['seed']['m'] == [], 'MARKED_SEED_MARKINGS_MUST_STAY_EMPTY')
        _require(base['capacity'] == marked['capacity'] and base['roots'] == marked['roots']
                 and base['seed']['t'] == marked['seed']['t']
                 and [(r['id'],r['t']) for r in base['inventory']['placements']]
                     == [(r['id'],r['t']) for r in marked['inventory']['placements']],
                 'ONLY_PER_CID_MARKINGS_MAY_CHANGE')
        rows = base['inventory']['placements']
        ids = [r['id'] for r in rows]
        pairs = _canonical_pairs(pair_nogoods,set(ids),meter)
        normalized = dict(base=base,marked=marked,pair_nogoods=pairs)
        bindings = dict(base_model_sha256=meter.sha(base),marked_model_sha256=meter.sha(marked),
                        pair_nogoods_sha256=meter.sha(pairs),canonical_encoding='SORTED_ASCII_JSON_PLUS_LF')
        capacity = base['capacity']
        weights = [dict(r['t']) for r in rows]
        pair_indices = [(ids.index(a),ids.index(b)) for a,b in pairs]
        total = 1 << len(ids)
        phase = 'SUBSETS'

        def totals(chosen):
            return _sums(base,chosen,meter)

        def marks(chosen, export=False):
            counts['marking_checks'] += 1
            return _literal_marks(marked,chosen,meter,export=export)

        def pair_free(chosen):
            counts['pair_constraint_checks'] += 1
            return _pair_free(pair_indices,chosen,meter)

        def reachable(chosen):
            return _reachable(base,chosen,meter)

        for mask in range(total):
            meter.tick()
            if counts['subsets_checked'] >= max_subsets:
                raise _Limit('MAX_SUBSETS')
            chosen = [i for i in range(len(ids)) if mask & (1 << i)]
            t,active,cap_legal = totals(chosen)
            mark_ok,mark_state = marks(chosen,export=True)
            direct_ok = pair_free(chosen)
            attached = reachable(chosen)
            exact = cap_legal and attached and all(t.get(p,0)==capacity for p in active)
            subset = dict(mask=mask,selected=[ids[i] for i in chosen],base_capacity_legal=cap_legal,
                          totals=[[p,t[p]] for p in sorted(t)],active_points=sorted(active),
                          root_reachable=attached,literal_mark_compatible=mark_ok,
                          literal_mark_state=mark_state,pair_nogood_free=direct_ok,
                          base_solution=exact,marked_solution=exact and mark_ok,
                          direct_solution=exact and direct_ok,
                          base_eligible=None,marked_eligible=None,direct_eligible=None,
                          marked_domains=None,direct_domains=None,marked_edges=None,direct_edges=None)
            if cap_legal:
                counts['base_capacity_legal_subsets'] += 1
                counts['reachable_capacity_legal_subsets'] += attached
                counts['eligibility_states_checked'] += 1
                counts['marking_equivalence_failures'] += mark_ok != direct_ok
                base_eligible,me,de = [],[],[]
                chosen_set = set(chosen)
                for i,cid in enumerate(ids):
                    meter.tick()
                    if i in chosen_set:
                        continue
                    counts['candidate_extensions_checked'] += 1
                    capacity_ok = True
                    for p,n in rows[i]['t']:
                        meter.tick()
                        if t.get(p,0)+n > capacity:
                            capacity_ok = False
                    # Whole-family tests are deliberately recomputed independently.
                    marked_ok = marks(chosen+[i])
                    filtered_ok = pair_free(chosen+[i])
                    if capacity_ok:
                        base_eligible.append(cid)
                        if marked_ok:
                            me.append(cid)
                        if filtered_ok:
                            de.append(cid)
                counts['eligibility_equivalence_failures'] += me != de
                frontier = sorted(p for p in active if t.get(p,0) < capacity)
                md,dd,m_edges,d_edges = [],[],[],[]
                for p in frontier:
                    meter.tick()
                    mc,dc = [],[]
                    for cid in me:
                        meter.tick()
                        i = ids.index(cid)
                        if p in weights[i]:
                            mc.append(cid)
                            m_edges.append([p,cid,weights[i][p]])
                    for cid in de:
                        meter.tick()
                        i = ids.index(cid)
                        if p in weights[i]:
                            dc.append(cid)
                            d_edges.append([p,cid,weights[i][p]])
                    md.append([p,mc])
                    dd.append([p,dc])
                counts['domain_equivalence_failures'] += md != dd
                counts['edge_equivalence_failures'] += m_edges != d_edges
                subset.update(base_eligible=base_eligible,marked_eligible=me,direct_eligible=de,
                              marked_domains=md,direct_domains=dd,marked_edges=m_edges,direct_edges=d_edges)
            for field,out in [('base_solution','base_solutions'),('marked_solution','marked_solutions'),
                              ('direct_solution','direct_solutions')]:
                if subset[field]:
                    solution = dict(mask=mask,selected=list(subset['selected']))
                    meter.reserve(solution)
                    evidence[out].append(solution)
            meter.reserve(subset)
            evidence['subsets'].append(subset)
            counts['subsets_checked'] += 1

        # Independent complete meeting-pair catalogue: no learned marking/filter.
        phase = 'PAIR_CATALOG'
        for i in range(len(ids)):
            for j in range(i+1,len(ids)):
                meter.tick()
                counts['pair_catalog_tests'] += 1
                _,_,legal = totals([i,j])
                meeting = set(weights[i]) & set(weights[j])
                if not legal or not meeting:
                    continue
                pair_mask = (1 << i) | (1 << j)
                extensions = []
                for solution in evidence['base_solutions']:
                    meter.tick()
                    if solution['mask'] & pair_mask == pair_mask:
                        extensions.append(solution['mask'])
                entry = dict(pair=[ids[i],ids[j]],meeting_points=sorted(meeting),
                             extension_status='POSITIVE' if extensions else 'NEGATIVE',
                             base_solution_masks=extensions)
                meter.reserve(entry)
                evidence['meeting_pairs'].append(entry)
        invalid_ng = 0
        phase = 'NOGOOD_EXTENSIONS'
        for pair,(i,j) in zip(pairs,pair_indices):
            pair_mask = (1 << i) | (1 << j)
            extensions = []
            for solution in evidence['base_solutions']:
                meter.tick()
                if solution['mask'] & pair_mask == pair_mask:
                    extensions.append(solution['mask'])
            invalid_ng += bool(extensions)
            entry = dict(pair=pair,base_solution_masks=extensions,absent_from_all_base_covers=not extensions)
            meter.reserve(entry)
            evidence['nogood_extensions'].append(entry)
        sets_equal = (evidence['base_solutions'] == evidence['marked_solutions']
                      == evidence['direct_solutions'])
        failures = sum(counts[k] for k in ('marking_equivalence_failures','eligibility_equivalence_failures',
                                         'domain_equivalence_failures','edge_equivalence_failures'))
        verdict = dict(solution_sets_equal=sets_equal,every_nogood_absent_from_original_covers=invalid_ng==0,
                       literal_marking_equals_pair_filter_every_capacity_legal_subset=failures==0,
                       original_solutions=len(evidence['base_solutions']),
                       marked_solutions=len(evidence['marked_solutions']),
                       direct_solutions=len(evidence['direct_solutions']),
                       meeting_pair_catalogue_complete=True,nogood_pairs_with_original_cover=invalid_ng)
        meter.tick()
        phase = 'COMPLETE'
        return finish('VERIFIED' if sets_equal and invalid_ng==0 and failures==0 else 'REJECTED',
                      'COMPLETE_FINITE_PRESERVATION' if sets_equal and invalid_ng==0 and failures==0
                      else 'COMPLETE_ENUMERATION_COUNTEREXAMPLE',verdict=verdict)
    except _Limit as error:
        return finish('UNKNOWN',str(error),verdict=None)
    except (MemoryError,RecursionError,OverflowError) as error:
        return finish('UNKNOWN','HOST_RESOURCE:' + type(error).__name__,verdict=None)
    except (_Malformed,KeyError,TypeError,ValueError,IndexError,AttributeError) as error:
        return finish('REJECTED','MALFORMED_OR_OUT_OF_PROFILE:' + str(error),verdict=None)


def enumerate_model(model, *, max_candidates=16, max_subsets=65536,
                    wall_seconds=10, max_work=10000000):
    """Generic complete tiny v2 assignment enumerator for qualification.

    Ordinary seed/per-CID literal markings and canonical pair_nogoods are
    allowed. The same independent point-assignment primitives underlie verify;
    no engine/checker/model helper or expected solution is an argument.
    EXHAUSTED means every subset was checked; UNKNOWN never decides absence.
    """
    started = time.perf_counter()
    meter = None
    normalized = None
    binding = None
    ids = []
    total = None
    states = []
    solutions = []
    counts = dict(subsets_checked=0,capacity_legal_subsets=0,legal_partial_subsets=0,
                  reachable_legal_partial_subsets=0,candidate_extensions_checked=0,
                  domain_states_checked=0)

    def finish(status,reason):
        return dict(schema='Finite-point-assignment-enumeration-v1',oracle=VERSION,
                    status=status,reason=reason,exists=bool(solutions) if status=='EXHAUSTED' else None,
                    witness_exists=bool(solutions),seconds=time.perf_counter()-started,
                    work=0 if meter is None else meter.work,
                    evidence_byte_reservation=0 if meter is None else meter.bytes_reserved,
                    model=normalized,model_sha256=binding,candidate_ids=ids,subsets_total=total,
                    subsets_coverage='COMPLETE' if total is not None and counts['subsets_checked']==total else 'PREFIX',
                    counts=counts,solutions=solutions,subsets=states,
                    scope='Complete fixed finite v2 EXPLICIT assignment existence with positive-support '
                          'root reachability and exact growing active coverage. No scheduler, generation, '
                          'rollback, geometric, native proof or infinite-domain claim.')

    try:
        for name,v,lo,hi in [('max_candidates',max_candidates,0,16),
                             ('max_subsets',max_subsets,0,65536),
                             ('max_work',max_work,0,1000000000)]:
            _require(type(v) is int and lo <= v <= hi, 'LIMIT_' + name)
        _require(type(wall_seconds) in (int,float) and math.isfinite(wall_seconds)
                 and 0 < wall_seconds <= 60, 'LIMIT_wall_seconds')
        meter = _Meter(max_work,wall_seconds)
        meter.scan(model)
        normalized = _normalize(model,max_candidates,meter)
        binding = meter.sha(normalized)
        rows = normalized['inventory']['placements']
        ids = [r['id'] for r in rows]
        index = {cid:i for i,cid in enumerate(ids)}
        weights = [dict(r['t']) for r in rows]
        pairs = [(index[a],index[b]) for a,b in normalized['pair_nogoods']]
        total = 1 << len(ids)
        for mask in range(total):
            meter.tick()
            if counts['subsets_checked'] >= max_subsets:
                raise _Limit('MAX_SUBSETS')
            chosen = [i for i in range(len(ids)) if mask & (1 << i)]
            selected = set(chosen)
            t,active,cap_ok = _sums(normalized,chosen,meter)
            mark_ok,mark_state = _literal_marks(normalized,chosen,meter,export=True)
            pair_ok = _pair_free(pairs,chosen,meter)
            attached = _reachable(normalized,chosen,meter)
            legal = cap_ok and mark_ok and pair_ok
            exact = legal and attached and all(t.get(p,0)==normalized['capacity'] for p in active)
            state = dict(mask=mask,selected=[ids[i] for i in chosen],capacity_legal=cap_ok,
                         literal_mark_compatible=mark_ok,pair_nogood_free=pair_ok,
                         literal_mark_state=mark_state,legal_partial=legal,root_reachable=attached,
                         totals=[[p,t[p]] for p in sorted(t)],active_points=sorted(active),
                         solution=exact,eligible=None,domains=None,edges=None)
            if cap_ok:
                counts['capacity_legal_subsets'] += 1
                counts['legal_partial_subsets'] += legal
                counts['reachable_legal_partial_subsets'] += legal and attached
                counts['domain_states_checked'] += 1
                eligible = []
                for i,cid in enumerate(ids):
                    meter.tick()
                    if i in selected:
                        continue
                    counts['candidate_extensions_checked'] += 1
                    capacity_ok = True
                    for p,n in rows[i]['t']:
                        meter.tick()
                        if t.get(p,0)+n > normalized['capacity']:
                            capacity_ok = False
                    marking_ok = _literal_marks(normalized,chosen+[i],meter)
                    nogood_ok = _pair_free(pairs,chosen+[i],meter)
                    if capacity_ok and marking_ok and nogood_ok:
                        eligible.append(cid)
                domains,edges = [],[]
                for p in sorted(p for p in active if t.get(p,0) < normalized['capacity']):
                    incident = []
                    for cid in eligible:
                        meter.tick()
                        i = index[cid]
                        if p in weights[i]:
                            incident.append(cid)
                            edges.append([p,cid,weights[i][p]])
                    domains.append([p,incident])
                state.update(eligible=eligible,domains=domains,edges=edges)
            if exact:
                solution = dict(mask=mask,selected=list(state['selected']))
                meter.reserve(solution)
                solutions.append(solution)
            meter.reserve(state)
            states.append(state)
            counts['subsets_checked'] += 1
        meter.tick()
        return finish('EXHAUSTED','COMPLETE_FINITE_POINT_ASSIGNMENT_ENUMERATION')
    except _Limit as error:
        return finish('UNKNOWN',str(error))
    except (MemoryError,RecursionError,OverflowError) as error:
        return finish('UNKNOWN','HOST_RESOURCE:' + type(error).__name__)
    except (_Malformed,KeyError,TypeError,ValueError,IndexError,AttributeError) as error:
        return finish('REJECTED','MALFORMED_MODEL_OR_LIMIT:' + str(error))
