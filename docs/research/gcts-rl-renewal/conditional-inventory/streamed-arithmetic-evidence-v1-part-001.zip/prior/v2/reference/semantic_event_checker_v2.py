"""Independent explicit-inventory semantic event certificate reader.

No engine/provider/model-helper imports. Actual serialized endpoints are checked;
intermediate graphs are reconstructed, never supplied as producer observations.
Lexical order, complete explicit universe, IP v3 / model v2 pair-filter ABI.
Declared ordinary pair nogoods are separate from literal marking agreement;
their redundancy or learned provenance must be verified by an external gate.
Native logical truth and execution/source custody are separate gates.
"""
import hashlib
import json
import math
import time

VERSION = 'Independent-explicit-semantic-event-checker-v2'
ENGINE = 'IP-GROWING-POINT-SEARCH-v3'
EXTENT_SCOPE = 'BOUNDED_PREFIX_COMPLETE_EMITTED_STREAM_HASH'
QUERY_SCOPE = 'BOUNDED_PREFIX_OF_COMPLETED_VALIDATED_INDEX_QUERIES'
RESULT_FIELDS = {'schema', 'version', 'status', 'reason', 'model_sha256',
                 'selected', 'certificate', 'entry_state', 'final_state',
                 'restored_state', 'state_hashes', 'events', 'event_extent',
                 'rollback_records', 'rollback_extent', 'stats', 'limits',
                 'provider_evidence'}
SNAP_FIELDS = {'Q', 'totals', 'selected', 'marks', 'excluded', 'eligible',
               'domains', 'forward', 'reverse', 'placements', 'loaded',
               'dependencies', 'edge_count'}
COUNT_STATS = {'placements', 'forced', 'branches', 'dead_ends', 'backtracks',
               'exclusions', 'legality_checks', 'candidate_registrations',
               'provider_calls', 'provider_rows', 'edge_additions',
               'edge_removals', 'dependency_links', 'peak_frontier', 'peak_Q',
               'peak_candidates', 'peak_edges', 'peak_trail', 'events_total',
               'rollbacks_total', 'rollback_edits', 'audit_calls',
               'ordering_calls', 'work', 'nodes'}


class Rejected(Exception):
    pass


class Incomplete(Exception):
    pass


class Budget(Exception):
    pass


def require(ok, reason):
    if not ok:
        raise Rejected(reason)


def nat(value, minimum=0):
    return type(value) is int and value >= minimum and value.bit_length() <= 256


def fields(value, expected, reason):
    require(type(value) is dict and set(value) == set(expected), reason)


def digest_string(value):
    return type(value) is str and len(value) == 64 and all(
        c in '0123456789abcdef' for c in value)


class Meter:
    """Items bound input/storage; work also charges repeated scans and strings."""
    def __init__(self, items, work, seconds):
        require(nat(items, 1) and nat(work, 1), 'CHECKER_INTEGER_LIMITS')
        require(type(seconds) in (int, float) and math.isfinite(seconds)
                and seconds > 0, 'CHECKER_WALL_LIMIT')
        self.item_limit = items
        self.work_limit = work
        self.deadline = time.perf_counter() + seconds
        self.items = 0
        self.work = 0

    def tick(self, n=1):
        self.work += n
        if self.work > self.work_limit:
            raise Budget('CHECKER_MAX_WORK')
        if time.perf_counter() >= self.deadline:
            raise Budget('CHECKER_WALL_SECONDS')

    def store(self, n=1):
        self.items += n
        self.tick(n)
        if self.items > self.item_limit:
            raise Budget('CHECKER_MAX_ITEMS')

    @staticmethod
    def dict_values(value):
        for key, item in value.items():
            require(type(key) is str, 'NONSTRING_JSON_KEY')
            yield key
            yield item

    def scan(self, value, *, input_items=False):
        # Iterator stack avoids allocating one pending entry per wide container.
        stack = [(iter((value,)), 0)]
        bound = 1  # terminal LF; conservative ensure_ascii serialization bound
        while stack:
            self.tick()
            it, depth = stack[-1]
            try:
                item = next(it)
            except StopIteration:
                stack.pop()
                continue
            if depth > 256:
                raise Budget('CHECKER_JSON_DEPTH')
            amount = 1
            if type(item) is str:
                amount += len(item)
                bound += 4 + 12 * len(item)
            elif type(item) is int:
                require(item.bit_length() <= 256, 'JSON_INTEGER_BITS')
                bound += 84
            elif item is None or type(item) is bool:
                bound += 8
            elif type(item) is float:
                require(math.isfinite(item), 'NONFINITE_JSON_NUMBER')
                bound += 132
            elif type(item) is list:
                bound += 4
                stack.append((iter(item), depth + 1))
            elif type(item) is dict:
                bound += 4
                stack.append((self.dict_values(item), depth + 1))
            else:
                raise Rejected('NON_NATIVE_JSON')
            if input_items:
                self.store(amount)
            else:
                self.tick(amount)
        return bound

    def wire(self, value):
        # Precharge the recursive literal size before serialization allocation.
        bound = self.scan(value)
        self.tick(bound)
        data = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                           separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        require(len(data) <= bound, 'INDEPENDENT_JSON_BOUND')
        self.tick()
        return data

    def sha(self, value):
        answer = hashlib.sha256(self.wire(value)).hexdigest()
        self.tick()
        return answer

    def same(self, actual, expected, reason):
        require(self.wire(actual) == self.wire(expected), reason)

    def sorted(self, values):
        out = []
        for value in values:
            self.tick(1 + (len(value) if type(value) is str else 1))
            out.append(value)
        # Conservative comparison allowance; literal lengths charged again.
        levels = max(1, len(out).bit_length())
        self.tick(levels * (len(out) + sum(len(v) for v in out
                                           if type(v) is str)))
        return sorted(out)


class Reader:
    def __init__(self, model, result, meter):
        self.m = meter
        self.r = result
        self.counts = dict(decision_events_checked=0, semantic_states_reconstructed=0,
                           endpoint_snapshots_checked=0, placements_replayed=0,
                           forced=0, branches=0, dead=0, exclusions=0,
                           solutions=0, exhausted=0, independent_legality_checks=0,
                           independent_edge_edits=0, independent_undo_edits=0,
                           rollback_metadata_rows_checked=0)
        self.failures = []
        self.dead_witnesses = []
        self.expected_rollbacks = []
        self.frames = []
        self.pending = None
        self.failed = None
        self.terminal = None
        self.root_dead = None
        self.trail = []
        self.model = self.normalize_model(model)
        self.model_sha = self.m.sha(self.model)
        self.rows = {}
        for row in self.model['inventory']['placements']:
            self.m.tick()
            self.rows[row['id']] = row
        self.ids = self.m.sorted(self.rows)
        neighbors = {}
        for left, right in self.model['pair_nogoods']:
            self.m.store(2)
            neighbors.setdefault(left, set()).add(right)
            neighbors.setdefault(right, set()).add(left)
        self.pair_neighbors = {}
        for cid in self.m.sorted(neighbors):
            self.pair_neighbors[cid] = tuple(self.m.sorted(neighbors[cid]))
        self.tdep = {}
        self.mdep = {}
        for cid in self.ids:
            row = self.rows[cid]
            for p, units in row['t']:
                self.m.store()
                self.tdep.setdefault(p, set()).add(cid)
            for p, value in row['m']:
                self.m.store()
                self.mdep.setdefault(p, set()).add(cid)
        self.T = {}
        for p, value in self.model['seed']['t']:
            self.m.tick()
            self.T[p] = value
        self.Q = {}
        for p, value in self.T.items():
            self.m.tick()
            if value:
                self.Q[p] = 0
        for p in self.model['roots']:
            self.m.tick()
            self.Q[p] = 0
            self.T.setdefault(p, 0)
        self.M = {}
        for p, value in self.model['seed']['m']:
            self.m.tick()
            self.M[p] = (value, 1)
        self.selected = {}
        self.excluded = set()
        self.eligible = set()
        self.domains = {}
        self.reverse = {}
        self.loaded = set()
        self.edge_count = 0
        self.m.store(len(self.T) + len(self.Q) + len(self.M))
        self.validate_result()
        for cid in self.ids:
            self.refresh(cid)
        for p in self.m.sorted(self.Q):
            self.sync_point(p)
        self.trail.clear()
        self.entry = self.snapshot()
        self.counts['semantic_states_reconstructed'] = 1

    def point_rows(self, value, *, marking=False, seed=False):
        require(type(value) is list, 'POINT_ROWS_LIST')
        seen = set()
        pairs = {}
        for pair in value:
            self.m.tick()
            require(type(pair) is list and len(pair) == 2 and
                    type(pair[0]) is str and pair[0] not in seen, 'POINT_ROW')
            p, v = pair
            seen.add(p)
            if marking:
                require(type(v) is str, 'LITERAL_MARK_VALUE')
            else:
                require(nat(v, 0 if seed else 1) and v <= self.capacity,
                        'NATIVE_CAPACITY_UNITS')
            self.m.store()
            pairs[p] = v
        return [[p, pairs[p]] for p in self.m.sorted(pairs)]

    def normalize_model(self, value):
        fields(value, {'schema', 'version', 'capacity', 'roots', 'seed',
                       'inventory', 'pair_nogoods'}, 'MODEL_FIELDS')
        require(value['schema'] == 'Z-growing-point-model-v2' and
                type(value['version']) is str and bool(value['version']), 'MODEL_VERSION')
        self.capacity = value['capacity']
        require(nat(self.capacity, 1), 'NATIVE_CAPACITY')
        require(type(value['roots']) is list, 'ROOTS_LIST')
        seen = set()
        for p in value['roots']:
            self.m.tick()
            require(type(p) is str and p not in seen, 'LITERAL_UNIQUE_ROOT')
            seen.add(p)
        roots = self.m.sorted(seen)
        fields(value['seed'], {'t', 'm'}, 'SEED_FIELDS')
        seed = dict(t=self.point_rows(value['seed']['t'], seed=True),
                    m=self.point_rows(value['seed']['m'], marking=True))
        inv = value['inventory']
        require(type(inv) is dict, 'INVENTORY_OBJECT')
        if inv.get('kind') != 'EXPLICIT':
            raise Incomplete('UNSUPPORTED_NONEXPLICIT_INVENTORY')
        fields(inv, {'kind', 'placements'}, 'EXPLICIT_FIELDS')
        require(type(inv['placements']) is list, 'EXPLICIT_PLACEMENTS_LIST')
        rows = {}
        for raw in inv['placements']:
            self.m.tick()
            fields(raw, {'id', 't', 'm'}, 'PLACEMENT_FIELDS')
            cid = raw['id']
            require(type(cid) is str and bool(cid) and cid not in rows,
                    'UNIQUE_LITERAL_CID')
            t = self.point_rows(raw['t'])
            require(bool(t), 'EMPTY_POSITIVE_SUPPORT')
            rows[cid] = dict(id=cid, t=t,
                             m=self.point_rows(raw['m'], marking=True))
            self.m.store()
        raw_pairs = value['pair_nogoods']
        require(type(raw_pairs) is list, 'PAIR_NOGOODS_LIST')
        pairs = []
        previous = None
        for pair in raw_pairs:
            self.m.tick()
            require(type(pair) is list and len(pair) == 2 and
                    all(type(c) is str and bool(c) for c in pair),
                    'TWO_LITERAL_PAIR_CIDS')
            left, right = pair
            require(left < right and left in rows and right in rows,
                    'SORTED_DISTINCT_KNOWN_PAIR_CIDS')
            key = (left, right)
            require(previous is None or previous < key,
                    'LEX_SORTED_UNIQUE_PAIR_NOGOODS')
            previous = key
            self.m.store()
            pairs.append([left, right])
        return dict(schema=value['schema'], version=value['version'],
                    capacity=self.capacity, roots=roots, seed=seed,
                    pair_nogoods=pairs,
                    inventory=dict(kind='EXPLICIT', placements=[rows[c]
                                   for c in self.m.sorted(rows)]))

    def extent(self, records, value, name):
        fields(value, {'total', 'retained', 'sha256', 'scope'}, name + '_EXTENT_FIELDS')
        require(nat(value['total']) and nat(value['retained']) and
                value['retained'] == len(records) <= value['total'] and
                value['scope'] == EXTENT_SCOPE and digest_string(value['sha256']),
                name + '_EXTENT')
        complete = value['total'] == len(records)
        if complete:
            h = hashlib.sha256()
            for row in records:
                self.m.tick()
                h.update(self.m.wire(row))
            require(h.hexdigest() == value['sha256'], name + '_STREAM_HASH')
        return complete

    def validate_result(self):
        r = self.r
        fields(r, RESULT_FIELDS, 'RESULT_FIELDS')
        require(r['schema'] == 'Z-growing-point-search-result-v1' and
                r['version'] == ENGINE, 'RESULT_VERSION')
        require(type(r['status']) is str and r['status'] in ('SAT', 'UNSAT', 'UNKNOWN'),
                'RESULT_STATUS')
        require(r['reason'] is None or type(r['reason']) is str, 'RESULT_REASON')
        if r['model_sha256'] is not None:
            require(r['model_sha256'] == self.model_sha, 'NORMALIZED_MODEL_HASH')
        elif r['status'] != 'UNKNOWN':
            raise Rejected('MISSING_COMPLETE_MODEL_HASH')
        require(type(r['events']) is list and type(r['rollback_records']) is list
                and type(r['selected']) is list, 'RESULT_ARRAYS')
        self.events_complete = self.extent(r['events'], r['event_extent'], 'EVENT')
        self.rollbacks_complete = self.extent(r['rollback_records'], r['rollback_extent'],
                                               'ROLLBACK')
        for row in r['rollback_records']:
            self.check_rollback_shape(row)
        fields(r['state_hashes'], {'entry', 'final', 'restored'}, 'STATE_HASH_FIELDS')
        for name in ('entry', 'final', 'restored'):
            self.m.tick()
            value, digest = r[name + '_state'], r['state_hashes'][name]
            if value is None:
                require(digest is None, 'NULL_STATE_HASH_' + name)
            else:
                fields(value, SNAP_FIELDS, 'ENDPOINT_FIELDS_' + name)
                require(digest == self.m.sha(value), 'ENDPOINT_HASH_' + name)
        limits = r['limits']
        fields(limits, {'wall_seconds', 'max_work', 'max_nodes', 'max_events',
                        'max_rollback_records', 'max_candidates', 'max_points'}, 'LIMITS_FIELDS')
        require(type(limits['wall_seconds']) in (int, float) and
                math.isfinite(limits['wall_seconds']) and
                0 < limits['wall_seconds'] <= 3600, 'ENGINE_WALL_LIMIT')
        for k in limits:
            self.m.tick()
            if k != 'wall_seconds':
                require(nat(limits[k], 1 if k in ('max_work', 'max_candidates', 'max_points')
                            else 0), 'ENGINE_INTEGER_LIMIT_' + k)
        require(len(r['events']) == min(r['event_extent']['total'], limits['max_events']),
                'EVENT_RETENTION_RULE')
        require(len(r['rollback_records']) == min(r['rollback_extent']['total'],
                limits['max_rollback_records']), 'ROLLBACK_RETENTION_RULE')
        stats = r['stats']
        fields(stats, COUNT_STATS | {'elapsed_seconds', 'cleanup_seconds'}, 'STATS_FIELDS')
        for k in COUNT_STATS:
            self.m.tick()
            require(nat(stats[k]), 'NATIVE_STAT_' + k)
        for k in ('elapsed_seconds', 'cleanup_seconds'):
            require(type(stats[k]) in (int, float) and math.isfinite(stats[k]) and
                    stats[k] >= 0, 'FINITE_TIMING_' + k)
        require(stats['events_total'] == r['event_extent']['total'] and
                stats['rollbacks_total'] == r['rollback_extent']['total'], 'EXTENT_STAT_TOTALS')
        require(stats['ordering_calls'] == 0, 'UNSUPPORTED_ORDER_CALLBACK')
        total = r['event_extent']['total']
        require((stats['audit_calls'] in (0, total)) if r['status'] != 'UNKNOWN'
                else stats['audit_calls'] <= total, 'REPORTED_AUDIT_CALL_COVERAGE')
        pe = r['provider_evidence']
        fields(pe, {'mode', 'total', 'retained', 'sha256', 'scope', 'records', 'costs'},
               'PROVIDER_EVIDENCE_FIELDS')
        require(pe['mode'] == 'EXPLICIT' or (r['status'] == 'UNKNOWN' and
                pe['mode'] == 'UNINITIALIZED'), 'NO_PROVIDER_PROFILE')
        self.m.same({k: pe[k] for k in ('total', 'retained', 'sha256', 'scope', 'records')},
                    dict(total=0, retained=0, sha256=hashlib.sha256().hexdigest(),
                         scope=QUERY_SCOPE, records=[]), 'EXPLICIT_QUERY_EVIDENCE_EMPTY')
        costs = pe['costs']
        keys = {'query_attempts', 'query_work', 'query_seconds', 'receipt_work',
                'potential_contacts', 'returned_contacts', 'context_values'}
        fields(costs, keys, 'PROVIDER_COST_FIELDS')
        for k in keys:
            self.m.tick()
            if k == 'query_seconds':
                require(type(costs[k]) in (int, float) and math.isfinite(costs[k])
                        and costs[k] == 0, 'ZERO_PROVIDER_SECONDS')
            else:
                require(nat(costs[k]) and costs[k] == 0, 'ZERO_PROVIDER_COST_' + k)

    def put(self, mapping, key, value):
        self.m.tick()
        had = key in mapping
        old = mapping.get(key)
        if had and old == value:
            return
        self.m.store()
        self.trail.append(('map', mapping, key, had, old))
        mapping[key] = value

    def delete(self, mapping, key):
        self.m.tick()
        if key in mapping:
            self.m.store()
            self.trail.append(('map', mapping, key, True, mapping[key]))
            del mapping[key]

    def membership(self, container, key, present):
        self.m.tick()
        was = key in container
        if was != present:
            self.m.store()
            self.trail.append(('set', container, key, was))
            if present:
                container.add(key)
            else:
                container.remove(key)

    def edge(self, p, cid, present):
        self.m.tick()
        was = cid in self.domains[p]
        if was == present:
            return
        if present and cid not in self.reverse:
            self.put(self.reverse, cid, set())
        self.membership(self.domains[p], cid, present)
        self.membership(self.reverse[cid], p, present)
        if not self.reverse[cid]:
            self.delete(self.reverse, cid)
        self.m.store()
        self.trail.append(('edges', self.edge_count))
        self.edge_count += 1 if present else -1
        self.counts['independent_edge_edits'] += 1

    def undo(self, checkpoint):
        require(nat(checkpoint) and checkpoint <= len(self.trail), 'INDEPENDENT_FRAME_CHECKPOINT')
        while len(self.trail) > checkpoint:
            self.m.tick()
            edit = self.trail.pop()
            if edit[0] == 'map':
                _, mapping, key, had, old = edit
                if had:
                    mapping[key] = old
                else:
                    del mapping[key]
            elif edit[0] == 'set':
                _, container, key, was = edit
                if was:
                    container.add(key)
                else:
                    container.remove(key)
            else:
                self.edge_count = edit[1]
            self.counts['independent_undo_edits'] += 1

    def legal(self, cid):
        self.counts['independent_legality_checks'] += 1
        self.m.tick()
        if cid in self.selected or cid in self.excluded:
            return False
        for other in self.pair_neighbors.get(cid, ()):
            self.m.tick()
            if other in self.selected:
                return False
        row = self.rows[cid]
        for p, units in row['t']:
            self.m.tick()
            if self.T.get(p, 0) + units > self.capacity:
                return False
        for p, value in row['m']:
            self.m.tick()
            if p in self.M and self.M[p][0] != value:
                return False
        return True

    def refresh(self, cid):
        ok = self.legal(cid)
        if ok == (cid in self.eligible):
            return
        self.membership(self.eligible, cid, ok)
        for p, units in self.rows[cid]['t']:
            self.m.tick()
            if p in self.domains:
                self.edge(p, cid, ok)

    def sync_point(self, p):
        self.m.tick()
        if self.T[p] == self.capacity:
            if p in self.domains:
                for cid in self.m.sorted(self.domains[p]):
                    self.edge(p, cid, False)
                self.delete(self.domains, p)
            return
        if p not in self.domains:
            self.put(self.domains, p, set())
            for cid in self.m.sorted(self.tdep.get(p, ())):
                if cid in self.eligible:
                    self.edge(p, cid, True)
        self.membership(self.loaded, p, True)

    def place(self, cid):
        require(cid in self.rows and cid in self.eligible and self.legal(cid),
                'GLOBAL_PLACEMENT_LEGALITY')
        row = self.rows[cid]
        generation = None
        for p, units in row['t']:
            self.m.tick()
            if p in self.Q:
                generation = self.Q[p] if generation is None else min(generation, self.Q[p])
        require(generation is not None, 'DISCONNECTED_NONROOT_PLACEMENT')
        generation += 1
        self.put(self.selected, cid, generation)
        affected = {cid}
        for other in self.pair_neighbors.get(cid, ()):
            self.m.tick()
            affected.add(other)
        for p, units in row['t']:
            self.m.tick()
            value = self.T.get(p, 0) + units
            require(value <= self.capacity, 'OVER_CAPACITY')
            self.put(self.T, p, value)
            self.put(self.Q, p, min(self.Q.get(p, generation), generation))
            for other in self.tdep.get(p, ()):
                self.m.tick()
                affected.add(other)
        for p, value in row['m']:
            self.m.tick()
            old = self.M.get(p)
            require(old is None or old[0] == value, 'SELECTED_MARK_CONFLICT')
            self.put(self.M, p, (value, 1 if old is None else old[1] + 1))
            for other in self.mdep.get(p, ()):
                self.m.tick()
                affected.add(other)
        for other in self.m.sorted(affected):
            self.refresh(other)
        for p, units in row['t']:
            self.sync_point(p)
        self.counts['placements_replayed'] += 1
        self.counts['semantic_states_reconstructed'] += 1
        return generation

    def decision(self):
        dead = forced = branch = None
        for p, ids in self.domains.items():
            self.m.tick(1 + len(p))
            degree = len(ids)
            if degree == 0:
                key = (self.Q[p], p)
                if dead is None or key < dead:
                    dead = key
            elif degree == 1:
                key = (self.Q[p], p)
                if forced is None or key < forced:
                    forced = key
            else:
                key = (self.Q[p], degree, p)
                if branch is None or key < branch:
                    branch = key
        if dead is not None:
            return 'DEAD', dead[-1]
        if forced is not None:
            return 'FORCED', forced[-1]
        if branch is not None:
            return 'BRANCH', branch[-1]
        return 'SOLUTION', None

    def snapshot(self):
        # Only actual entry/final/restored endpoint comparisons consume this.
        domains = []
        forward = []
        reverse = []
        for p in self.m.sorted(self.domains):
            ids = self.m.sorted(self.domains[p])
            domains.append([p, ids])
            for cid in ids:
                self.m.tick()
                units = None
                for q, n in self.rows[cid]['t']:
                    self.m.tick()
                    if q == p:
                        units = n
                        break
                require(units is not None, 'INDEPENDENT_EDGE_SUPPORT')
                forward.append([p, cid, units])
        for cid in self.m.sorted(self.reverse):
            weights = {}
            for p, n in self.rows[cid]['t']:
                self.m.tick()
                weights[p] = n
            reverse.append([cid, [[p, weights[p]] for p in self.m.sorted(self.reverse[cid])]])
        self.m.store(len(forward) + len(domains) + len(reverse))
        return dict(Q=[[p, self.Q[p]] for p in self.m.sorted(self.Q)],
                    totals=[[p, self.T[p]] for p in self.m.sorted(self.T)],
                    selected=[[c, self.selected[c]] for c in self.m.sorted(self.selected)],
                    marks=[[p, self.M[p][0], self.M[p][1]] for p in self.m.sorted(self.M)],
                    excluded=self.m.sorted(self.excluded), eligible=self.m.sorted(self.eligible),
                    domains=domains, forward=forward, reverse=reverse,
                    placements=[self.rows[c] for c in self.ids], loaded=self.m.sorted(self.loaded),
                    dependencies=dict(t=[[p, self.m.sorted(self.tdep[p])]
                                         for p in self.m.sorted(self.tdep)],
                                      m=[[p, self.m.sorted(self.mdep[p])]
                                         for p in self.m.sorted(self.mdep)]),
                    edge_count=self.edge_count)

    def endpoint(self, name, expected):
        actual = self.r[name + '_state']
        if actual is None:
            raise Incomplete('MISSING_COMPLETE_' + name.upper() + '_ENDPOINT')
        self.m.same(actual, expected, 'ACTUAL_ENDPOINT_' + name.upper())
        self.counts['endpoint_snapshots_checked'] += 1

    def event(self, value, seq):
        fields(value, {'seq', 'kind', 'point', 'candidate', 'data'}, 'EVENT_FIELDS')
        require(nat(value['seq']) and value['seq'] == seq, 'CONSECUTIVE_EVENT_SEQUENCE')
        kind, point, cid, data = (value[k] for k in ('kind', 'point', 'candidate', 'data'))
        require(type(kind) is str and (point is None or type(point) is str) and
                (cid is None or type(cid) is str) and type(data) is dict, 'EVENT_LITERAL_TYPES')
        require(self.terminal is None, 'EVENT_AFTER_TERMINAL')
        if seq == 0:
            require(kind == 'READY' and point is None and cid is None, 'INITIAL_READY')
            self.m.same(data, {}, 'READY_DATA')
        elif kind == 'READY':
            raise Rejected('DUPLICATE_READY')
        elif kind == 'PLACED':
            require(self.pending is not None and self.failed is None, 'PLACED_WITHOUT_PENDING')
            p, c, forced = self.pending
            require(point == p and cid == c, 'PENDING_PLACEMENT_ID')
            generation = self.place(c)
            self.m.same(data, dict(generation=generation, forced=forced), 'PLACED_DATA')
            self.pending = None
        elif kind == 'EXCLUDE':
            require(self.pending is None and self.failed is not None and bool(self.frames),
                    'PHANTOM_OR_UNKNOWN_EXCLUSION')
            frame = self.frames[-1]
            require(self.failed['branch_event'] == frame['branch_event'] and
                    point is None and cid == frame['candidate'], 'FAILED_FRAME_BINDING')
            self.m.same(data, {}, 'EXCLUDE_DATA')
            before = len(self.selected)
            self.undo(frame['checkpoint'])
            require(len(self.selected) == frame['selected_count'] and cid not in self.selected
                    and cid not in self.excluded and self.legal(cid), 'RESTORED_PARENT_CONTEXT')
            self.m.store()
            self.expected_rollbacks.append(dict(reason='FAILED_CHILD', selected_before=before,
                                                selected_after=len(self.selected)))
            self.m.store()
            self.failures.append(dict(candidate=cid, branch_event=frame['branch_event'],
                                      dead_event=self.failed['dead_event'], exclude_event=seq,
                                      parent_selected_count=len(self.selected),
                                      parent_excluded_count=len(self.excluded),
                                      context_scope='MODEL_AND_COMPLETE_EVENT_PREFIX_TO_BRANCH'))
            self.frames.pop()
            self.membership(self.excluded, cid, True)
            self.refresh(cid)
            self.failed = None
            self.counts['exclusions'] += 1
            self.counts['semantic_states_reconstructed'] += 1
        elif kind == 'EXHAUSTED':
            require(self.pending is None and self.failed is not None and not self.frames and
                    self.failed['branch_event'] is None and point is None and cid is None,
                    'UNJUSTIFIED_ROOT_EXHAUSTION')
            self.m.same(data, {}, 'EXHAUSTED_DATA')
            self.root_dead = self.failed['dead_event']
            self.terminal = 'UNSAT'
            self.counts['exhausted'] += 1
        else:
            require(self.pending is None and self.failed is None, 'MISSING_PLACED_OR_EXCLUDE')
            expected, p = self.decision()
            require(kind == expected and point == p, 'INDEPENDENT_GLOBAL_SCHEDULER')
            if kind == 'DEAD':
                require(cid is None, 'DEAD_CID')
                self.m.same(data, dict(generation=self.Q[p]), 'DEAD_GENERATION')
                self.failed = dict(branch_event=self.frames[-1]['branch_event']
                                   if self.frames else None, dead_event=seq)
                self.counts['dead'] += 1
                if len(self.dead_witnesses) < 16:
                    context = dict(schema='Independent-semantic-dead-context-v1',
                                   model_sha256=self.model_sha, dead_point=p,
                                   generation=self.Q[p],
                                   selected=[[c, self.selected[c]]
                                             for c in self.m.sorted(self.selected)],
                                   excluded=self.m.sorted(self.excluded),
                                   Q=[[q, self.Q[q]] for q in self.m.sorted(self.Q)])
                    witness = dict(dead_event=seq, context_preimage=context,
                                   semantic_context_sha256=self.m.sha(context),
                                   legal_incident_count=0,
                                   all_incident_count=len(self.tdep.get(p, ())),
                                   scope='SEMANTIC_CONTEXT_NOT_PRODUCER_GRAPH',
                                   reuse='NOT_STANDALONE_CONSTRAINT; requires model, complete '
                                         'verified trace and exclusion provenance')
                    self.m.scan(witness, input_items=True)
                    self.dead_witnesses.append(witness)
            elif kind == 'FORCED':
                c = next(iter(self.domains[p]))
                require(cid == c, 'FORCED_UNIQUE_CID')
                self.m.same(data, dict(generation=self.Q[p]), 'FORCED_GENERATION')
                self.pending = (p, c, True)
                self.counts['forced'] += 1
            elif kind == 'BRANCH':
                require(cid is None, 'BRANCH_CID_NULL')
                legal = self.m.sorted(self.domains[p])
                self.m.same(data, dict(generation=self.Q[p], legal=legal, order=legal),
                            'COMPLETE_LEXICAL_BRANCH_DOMAIN_AND_ORDER')
                self.m.store()
                self.frames.append(dict(checkpoint=len(self.trail), candidate=legal[0],
                                        branch_event=seq, selected_count=len(self.selected)))
                self.pending = (p, legal[0], False)
                self.counts['branches'] += 1
            else:
                require(kind == 'SOLUTION' and cid is None, 'SOLUTION_FORMAT')
                self.m.same(data, {}, 'SOLUTION_DATA')
                self.terminal = 'SAT'
                self.counts['solutions'] += 1
        self.counts['decision_events_checked'] += 1

    def certificate(self):
        for left, right in self.model['pair_nogoods']:
            self.m.tick()
            require(not (left in self.selected and right in self.selected),
                    'DECLARED_PAIR_FILTER_SATISFIED')
        for p in self.Q:
            self.m.tick()
            require(self.T[p] == self.capacity, 'ACTIVE_TARGET_NOT_EXACT')
        return dict(capacity=self.capacity, roots=self.model['roots'], seed=self.model['seed'],
                    placements=[self.rows[c] for c in self.m.sorted(self.selected)],
                    totals=[[p, self.T[p]] for p in self.m.sorted(self.Q)],
                    marks=[[p, self.M[p][0], self.M[p][1]] for p in self.m.sorted(self.M)])

    def rollback_metadata(self):
        expected = self.expected_rollbacks + [dict(reason='FINAL_RESTORE',
                         selected_before=len(self.selected), selected_after=0)]
        require(self.r['rollback_extent']['total'] == len(expected),
                'ROLLBACK_TOTAL_FROM_SEMANTIC_EVENTS')
        undone_sum = 0
        for i, row in enumerate(self.r['rollback_records']):
            self.m.tick()
            self.check_rollback_shape(row)
            self.m.same({k: row[k] for k in expected[i]}, expected[i],
                        'ROLLBACK_PARENT_SELECTED_ASSOCIATION')
            if row['reason'] == 'FINAL_RESTORE':
                require(i == len(expected) - 1 and row['to_trail'] == 0,
                        'FINAL_RESTORE_METADATA')
            undone_sum += row['undone']
            self.counts['rollback_metadata_rows_checked'] += 1
        if self.rollbacks_complete:
            require(self.r['stats']['rollback_edits'] == undone_sum,
                    'FULL_ROLLBACK_EDIT_SUM')

    def check_rollback_shape(self, row):
        self.m.tick()
        fields(row, {'reason', 'from_trail', 'to_trail', 'undone',
                     'selected_before', 'selected_after'}, 'ROLLBACK_METADATA_FIELDS')
        require(row['reason'] in ('FAILED_CHILD', 'FINAL_RESTORE') and
                type(row['reason']) is str and all(nat(row[k]) for k in row
                if k != 'reason'), 'ROLLBACK_METADATA_NATIVE_TYPES')
        require(row['from_trail'] >= row['to_trail'] and
                row['undone'] == row['from_trail'] - row['to_trail'], 'ROLLBACK_ARITHMETIC')

    def run(self):
        if self.r['entry_state'] is None:
            raise Incomplete('NO_COMPLETE_ENTRY_CHECKPOINT')
        self.endpoint('entry', self.entry)
        self.endpoint('restored', self.entry)
        for i, event in enumerate(self.r['events']):
            self.m.tick()
            self.event(event, i)
        if self.r['status'] == 'UNKNOWN':
            require(self.r['selected'] == [] and self.r['certificate'] is None and
                    self.r['final_state'] is None, 'UNKNOWN_HAS_NO_COMMITTED_SOLUTION')
            raise Incomplete('RAW_UNKNOWN_PREFIX_NO_ABSENCE')
        if not self.events_complete:
            raise Incomplete('TRUNCATED_EVENT_STREAM')
        require(self.terminal == self.r['status'] and self.pending is None,
                'MISSING_OR_MISMATCHED_TERMINAL')
        self.endpoint('final', self.snapshot())
        if self.terminal == 'SAT':
            require(self.failed is None and
                    self.r['reason'] == 'FINITE_ACTIVE_OBLIGATIONS_EXACT', 'SAT_REASON')
            self.m.same(self.r['selected'], self.m.sorted(self.selected), 'SAT_SELECTED_EXACT')
            self.m.same(self.r['certificate'], self.certificate(), 'SAT_CERTIFICATE_EXACT')
        else:
            require(not self.frames and self.failed is not None and self.r['reason'] ==
                    'EXHAUSTED_DECLARED_FINITE_INVENTORY' and self.r['selected'] == []
                    and self.r['certificate'] is None, 'UNSAT_DECLARED_SCOPE')
        self.rollback_metadata()
        stats = self.r['stats']
        dependency_links = 0
        for row in self.rows.values():
            self.m.tick()
            dependency_links += len(row['t']) + len(row['m'])
        joins = dict(placements=self.counts['placements_replayed'], forced=self.counts['forced'],
                     branches=self.counts['branches'], dead_ends=self.counts['dead'],
                     backtracks=self.counts['exclusions'], exclusions=self.counts['exclusions'],
                     nodes=self.counts['forced'] + self.counts['branches'] +
                     self.counts['dead'] + self.counts['solutions'],
                     candidate_registrations=len(self.rows), provider_calls=0, provider_rows=0,
                     dependency_links=dependency_links)
        for k, n in joins.items():
            require(stats[k] == n, 'SEMANTIC_STAT_' + k)
        return dict(status='VERIFIED', reason='COMPLETE_EXPLICIT_SEMANTIC_EVENT_CERTIFICATE',
                    run_status=self.terminal,
                    claim='SEMANTIC_COMPLETE_SAT_CERTIFICATE' if self.terminal == 'SAT'
                    else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION',
                    bounded_absence=self.terminal == 'UNSAT', counts=dict(self.counts),
                    model_sha256=self.model_sha, event_sha256=self.r['event_extent']['sha256'],
                    event_coverage='COMPLETE',
                    rollback_metadata_coverage='COMPLETE' if self.rollbacks_complete else 'PREFIX',
                    reported_audit_calls=stats['audit_calls'],
                    failure_provenance=self.failures, root_dead_event=self.root_dead,
                    dead_context_witnesses=self.dead_witnesses,
                    dead_witness_coverage=dict(limit=16, retained=len(self.dead_witnesses),
                                               total=self.counts['dead'],
                                               unshown=self.counts['dead']-len(self.dead_witnesses)),
                    domains='INDEPENDENTLY_RECONSTRUCTED_COMPLETE',
                    pair_nogood_count=len(self.model['pair_nogoods']),
                    pair_filter_scope='DECLARED_ORDINARY_FILTER_NOT_MARKING_AGREEMENT',
                    producer_intermediate_bookkeeping='NOT_CHECKED',
                    endpoint_scope='ACTUAL_SERIALIZED_ENTRY_FINAL_RESTORED_ENDPOINTS',
                    native_validity='SEPARATE_KERNEL_GATE',
                    process_admission='SEPARATE_NATIVE_EXIT_AND_SOURCE_CUSTODY_GATE',
                    scope='Fixed complete explicit point inventory, declared ordinary pair-nogood '
                          'filter and lexical ordering. Pair redundancy is not proved here. '
                          'Finite active obligations only; no unrestricted logical, geometric '
                          'or infinite-tiling conclusion. Rollback instruction counts are not inferred.')


def verify_explicit_events(model, result, *, max_items, max_work, wall_seconds):
    """Read IP v3 result; never execute a producer or mutate input JSON."""
    started = time.perf_counter()
    meter = None
    reader = None
    try:
        meter = Meter(max_items, max_work, wall_seconds)
        meter.scan(model, input_items=True)
        meter.scan(result, input_items=True)
        reader = Reader(model, result, meter)
        answer = reader.run()
        meter.tick()
    except Rejected as error:
        answer = dict(status='REJECTED', reason=str(error), bounded_absence=False)
    except (Incomplete, Budget) as error:
        answer = dict(status='UNKNOWN', reason=str(error), bounded_absence=False,
                      verified_prefix_only=True)
    except (MemoryError, RecursionError, OverflowError) as error:
        answer = dict(status='UNKNOWN', reason='CHECKER_RESOURCE_' + type(error).__name__,
                      bounded_absence=False, verified_prefix_only=True)
    except (KeyError, TypeError, ValueError, IndexError) as error:
        answer = dict(status='REJECTED', reason='MALFORMED_INPUT:' + type(error).__name__
                      + ':' + str(error), bounded_absence=False)
    if reader is not None:
        answer.setdefault('counts', dict(reader.counts))
        answer.setdefault('producer_intermediate_bookkeeping', 'NOT_CHECKED')
        answer.setdefault('run_status', reader.r['status'])
        answer.setdefault('event_coverage', 'COMPLETE' if reader.events_complete else 'PREFIX')
        answer.setdefault('rollback_metadata_coverage', 'COMPLETE'
                          if reader.rollbacks_complete else 'PREFIX')
    answer.setdefault('counts', {})
    answer.update(version=VERSION, seconds=time.perf_counter() - started,
                  items=0 if meter is None else meter.items,
                  work=0 if meter is None else meter.work)
    return answer
