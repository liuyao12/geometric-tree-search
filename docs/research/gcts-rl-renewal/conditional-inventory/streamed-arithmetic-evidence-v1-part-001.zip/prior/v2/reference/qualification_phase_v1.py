"""Prospective qualification orchestration; inert until Root's frozen worker.

Imports stdlib only. No model/proof/search is constructed at module import.
run(ctx) uses freshly loaded, pinned modules supplied by the owning driver.
No arithmetic target, old proof, learned marking or witness is an input here.
"""
import copy
import hashlib
import json
import time

VERSION = 'Quantified-marking-qualification-phase-v1'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def limits(ctx, role):
    value = ctx.limits[role]
    need(type(value) is dict, 'DECLARED_LIMITS:' + role)
    return dict(value)


def stage(ctx, path, operation):
    started = time.perf_counter()
    value = operation()
    seconds = time.perf_counter() - started
    reference = ctx.save(path, value)
    return value, reference, dict(seconds=seconds)


def matches(ctx, value, subset):
    if type(subset) is dict:
        return type(value) is dict and all(
            k in value and matches(ctx, value[k], v) for k, v in subset.items())
    return ctx.wire(value) == ctx.wire(subset)


def required_observations(ctx, case, observations):
    checks = []
    for request in case['expected'].get('required_observations', []):
        need(request['position'] in ('FIRST_DECISION', 'ANY'), 'OBSERVATION_POSITION')
        source = ([x for x in observations if x['event']['kind'] != 'READY'][:1]
                  if request['position'] == 'FIRST_DECISION' else observations)
        for observed in source:
            if not matches(ctx, observed['event'], request['event']):
                continue
            state = observed['state']
            included = all(all(any(ctx.wire(x) == ctx.wire(y) for y in state[k])
                               for x in wanted)
                           for k, wanted in request.get('snapshot_contains', {}).items())
            omitted = all(all(x not in [y[0] if type(y) is list else y
                                        for y in state[k]] for x in wanted)
                          for k, wanted in request.get('snapshot_omits', {}).items())
            if included and omitted:
                checks.append(dict(request=request, seq=observed['event']['seq']))
                break
        else:
            raise ValueError('MISSING_REQUIRED_OBSERVATION:' + case['id'])
    return checks


def complete_engine(ctx, name, model):
    packet = ctx.engine(name[5:] if name.startswith('data/') else name, model, actual=True)
    raw, semantic, observations, refs = [packet[k] for k in
                                         ('raw', 'semantic', 'observations', 'refs')]
    full = ctx.read(refs['full_graphs']['path'])
    paired = ctx.read(refs['paired_graphs']['path'])
    need(raw['status'] in ('SAT', 'UNSAT'), 'DEFINITE_TINY_ENGINE_RESULT:' + name)
    need(semantic['status'] == full['status'] == paired['status'] == 'VERIFIED',
         'SEMANTIC_AND_ACTUAL_GRAPH_GATES:' + name)
    need(full['counts']['observations_checked'] == len(observations)
         == len(raw['events']) == raw['event_extent']['total'], 'ALL_TINY_ACTUAL_SNAPSHOTS')
    return packet, dict(raw_status=raw['status'], semantic_status=semantic['status'],
        full_graph_status=full['status'], paired_graph_status=paired['status'],
        actual_snapshots=len(observations), engine_calls=1, metrics=raw['stats'], refs=refs)


def oracle(ctx, name, model):
    # Refuse the tiny-oracle scope explicitly; never shorten the inventory.
    n = len(model['inventory']['placements'])
    if n > limits(ctx, 'O')['max_candidates']:
        value = dict(status='NOT_APPLICABLE_SIZE_SCOPE', candidates=n,
                     reason='Complete model exceeds the frozen tiny-subset scope; no rows removed.')
        return value, ctx.save(name + '/oracle-not-applicable.json', value), dict(seconds=0.0)
    return stage(ctx, name + '/subsets.json.gz', lambda:
        ctx.mods['O'].enumerate_model(model, **limits(ctx, 'O')))


def malformed_controls(ctx, model):
    rows = []
    ids = sorted(x['id'] for x in model['inventory']['placements'])
    need(len(ids) >= 2, 'MALFORMED_UNARY_FIXTURE_IDENTITIES')
    for kind in ('missing', 'wrong_type', 'unknown', 'repeated', 'unsorted', 'provider_nonempty'):
        bad = copy.deepcopy(model)
        if kind == 'missing':
            del bad['unary_nogoods']
        elif kind == 'wrong_type':
            bad['unary_nogoods'] = ids[0]
        elif kind == 'unknown':
            bad['unary_nogoods'] = ['QUALIFICATION_UNKNOWN_CID']
        elif kind == 'repeated':
            bad['unary_nogoods'] = [ids[0], ids[0]]
        elif kind == 'unsorted':
            bad['unary_nogoods'] = [ids[1], ids[0]]
        else:
            bad['inventory'] = dict(kind='CERTIFIED_INCIDENT', identity='INVALID_NONEMPTY_UNARY')
            bad['unary_nogoods'] = [ids[0]]
        prefix = 'data/qualify/controls/unary-' + kind
        inp = ctx.save(prefix + '-input.json', bad)
        try:
            unexpected = ctx.mods['E'].solve(bad, limits(ctx, 'E'))
        except ctx.mods['E'].InputError as error:
            answer = dict(status='REJECTED', reason=str(error), expected_exception='InputError')
        else:
            ctx.save(prefix + '-unexpected-result.json.gz', unexpected)
            raise ValueError('MALFORMED_UNARY_ACCEPTED:' + kind)
        rows.append(dict(id='unary-' + kind, input=inp,
                         receipt=ctx.save(prefix + '-receipt.json', answer)))
    return rows


def event_hash(ctx, events):
    digest = hashlib.sha256()
    for event in events:
        digest.update(ctx.wire(event))
    return digest.hexdigest()


def refusal_controls(ctx, model, actual):
    rows = malformed_controls(ctx, model)
    unknown = ctx.engine('qualify/controls/max-nodes-zero', model,
                         actual=False, max_nodes=0)
    need(unknown['raw']['status'] == unknown['semantic']['status'] == 'UNKNOWN'
         and unknown['semantic']['bounded_absence'] is False, 'UNKNOWN_IS_NOT_ABSENCE')
    rows.append(dict(id='max-nodes-zero', refs=unknown['refs'], status='UNKNOWN'))
    bad = copy.deepcopy(actual['raw'])
    forced = next(e for e in bad['events'] if e['kind'] == 'FORCED')
    forbidden = model['unary_nogoods'][0]
    forced['candidate'] = forbidden
    bad['event_extent']['sha256'] = event_hash(ctx, bad['events'])
    inp = ctx.save('data/qualify/controls/forbidden-forced-input.json.gz', bad)
    answer, ref, cost = stage(ctx, 'data/qualify/controls/forbidden-forced-check.json',
        lambda: ctx.mods['C'].verify_explicit_events(model, bad, **limits(ctx, 'C')))
    need(answer['status'] == 'REJECTED' and answer['bounded_absence'] is False,
         'FORBIDDEN_FORCED_MUTATION_REJECTED')
    rows.append(dict(id='forbidden-forced-event', input=inp, receipt=ref, cost=cost))
    observations = copy.deepcopy(actual['observations'])
    observed = next(x for x in observations if x['event']['kind'] == 'FORCED')
    snapshot = observed['state']
    tile = next(x for x in model['inventory']['placements'] if x['id'] == forbidden)
    need(len(tile['t']) == 1 and tile['t'][0][0] == observed['event']['point'],
         'SELF_CONSISTENT_UNARY_GRAPH_MUTANT_ANCHOR')
    p, units = tile['t'][0]
    need(forbidden not in snapshot['eligible'], 'FORBIDDEN_ABSENT_FROM_ACTUAL_GRAPH')
    snapshot['eligible'] = sorted(snapshot['eligible'] + [forbidden])
    domain = next(x[1] for x in snapshot['domains'] if x[0] == p)
    domain.append(forbidden)
    domain.sort()
    snapshot['forward'].append([p, forbidden, units])
    snapshot['forward'].sort()
    snapshot['reverse'].append([forbidden, [[p, units]]])
    snapshot['reverse'].sort()
    snapshot['edge_count'] += 1
    inp = ctx.save('data/qualify/controls/forbidden-graph-input.json.gz', observations)
    answer, ref, cost = stage(ctx, 'data/qualify/controls/forbidden-graph-check.json',
        lambda: ctx.mods['T'].verify(model, model['inventory']['placements'], observations,
                                    actual['raw'], **limits(ctx, 'T')))
    need(answer['status'] == 'REJECTED', 'SELF_CONSISTENT_FORBIDDEN_GRAPH_REJECTED')
    rows.append(dict(id='forbidden-actual-graph', input=inp, receipt=ref, cost=cost))
    return rows


def ground_catalogue(ctx, declaration):
    """Generic complete named-assumption/subformula compiler for this fixture.

    The independent N.verify gate reconstructs this entire profile. No selected
    path or target proof is supplied; all MP and slot/reference rows survive.
    """
    statement = declaration['statement']
    theory = statement['theory']
    found = {}
    def visit(formula):
        need(type(formula) is list and formula, 'GROUND_FORMULA')
        if formula[0] == 'imp':
            need(len(formula) == 3, 'GROUND_IMP_ARITY')
            visit(formula[1])
            visit(formula[2])
        else:
            need(formula[0] == 'pred' and len(formula) == 3 and formula[2] == [], 'GROUND_PRED0')
        found[ctx.wire(formula)] = copy.deepcopy(formula)
    for f in list(theory['axioms'].values()) + [statement['goal']]:
        visit(f)
    formulas = [found[k] for k in sorted(found)]
    ids = {ctx.wire(f): i + 1 for i, f in enumerate(formulas)}
    mp = [dict(antecedent=ids[ctx.wire(f[1])], implication=i + 1,
               output=ids[ctx.wire(f[2])]) for i, f in enumerate(formulas) if f[0] == 'imp']
    mp.sort(key=lambda d: (d['antecedent'], d['implication'], d['output']))
    profile = dict(declaration['profile'], formula_universe_version='LITERAL_SORTED_CANONICAL_JSON_V1',
                   zero_instance_profile='ASSUMPTIONS_ONLY', variables=[], allow_gen=False)
    return dict(schema='Shared-fact-finite-catalogue-v1', statement=copy.deepcopy(statement),
        formulas=formulas, zeros=[dict(id='Z%06d' % i,
            native=dict(rule='axiom', formula=copy.deepcopy(theory['axioms'][name]), name=name))
            for i, name in enumerate(sorted(theory['axioms']))], mp=mp, gen=[], profile=profile,
        provenance=dict(case_id=declaration['id'], compiler='Ground-Horn-subformula-compiler-v1',
            declaration_sha256=ctx.sha(declaration),
            scope='All literal assumption/goal subformulas, every named assumption ZERO and every structural MP. No proof path, search, target witness, GEN or other native schema was supplied.'))


def logic_case(ctx, specification):
    declaration = specification['declaration']
    name = 'data/qualify/logic/' + declaration['id']
    refs, costs = {}, {}
    refs['declaration'] = ctx.save(name + '/declaration.json', declaration)
    if specification['kind'] == 'RF':
        started = time.perf_counter()
        try:
            compiled, generation = ctx.mods['F'].compile_case(declaration)
        except ctx.mods['F'].BasisLimit as error:
            ctx.save(name + '/compile-refusal.json', error.receipt())
            raise ValueError('QUALIFICATION_RF_REFUSAL:' + error.reason)
        costs['compile'] = dict(seconds=time.perf_counter() - started)
        refs['compiled'] = ctx.save(name + '/compiled.json.gz', compiled)
        refs['generation'] = ctx.save(name + '/generation.json', generation)
        r, refs['rf_profile'], costs['rf_profile'] = stage(ctx, name + '/rf-profile.json',
            lambda: ctx.mods['R'].verify(declaration, compiled, generation, **limits(ctx, 'R')))
        need(r['status'] == 'VERIFIED', 'WHOLE_RF_PROFILE')
        slots = declaration['slots']
        bridge, refs['bridge'], costs['bridge'] = stage(ctx, name + '/bridge.json.gz',
            lambda: ctx.mods['A'].bridge(declaration, compiled, generation, slots, limits(ctx, 'A')))
        need(bridge['status'] == 'CATALOGUE_UNVERIFIED', 'COMPLETE_RF_BRIDGE')
        q, refs['bridge_check'], costs['bridge_check'] = stage(ctx, name + '/bridge-check.json',
            lambda: ctx.mods['Q'].verify(declaration, compiled, generation, slots, bridge, **limits(ctx, 'Q')))
        need(q['status'] == 'VERIFIED', 'INDEPENDENT_COMPLETE_RF_BRIDGE')
        catalogue = bridge['catalogue']
    else:
        need(specification['kind'] == 'GROUND', 'DECLARED_LOGICAL_QUALIFICATION_KIND')
        slots = declaration['profile']['slots']
        catalogue = ground_catalogue(ctx, declaration)
    refs['catalogue'] = ctx.save(name + '/catalogue.json.gz', catalogue)
    native_zeros = []
    for zero in catalogue['zeros']:
        z, zref, cost = stage(ctx, name + '/zero-' + zero['id'] + '-native.json', lambda zero=zero:
            ctx.mods['B'].check(catalogue['statement']['theory'], [zero['native']],
                                zero['native']['formula'], limits(ctx, 'B')))
        need(z['status'] == 'VERIFIED', 'ALL_LOGICAL_ZEROS_NATIVE:' + zero['id'])
        native_zeros.append(dict(id=zero['id'], receipt=zref, cost=cost))
    prepared, refs['prepared'], costs['prepare'] = stage(ctx, name + '/prepared.json.gz',
        lambda: ctx.mods['M'].prepare(catalogue, slots, limits(ctx, 'M')))
    need(prepared['status'] == 'PREPARED_UNVERIFIED', 'COMPLETE_LOGICAL_POINT_UNIVERSE')
    n, refs['model_check'], costs['model_check'] = stage(ctx, name + '/model-check.json',
        lambda: ctx.mods['N'].verify_model(catalogue, prepared, **limits(ctx, 'N')))
    need(n['status'] == 'VERIFIED', 'INDEPENDENT_ALL_ROW_LOGICAL_MODEL')
    if specification['kind'] == 'GROUND':
        n, refs['basis_check'], costs['basis_check'] = stage(ctx, name + '/ground-basis-check.json',
            lambda: ctx.mods['N'].verify_basis(declaration, catalogue, **limits(ctx, 'N')))
        need(n['status'] == 'VERIFIED', 'COMPLETE_GROUND_QUALIFICATION_BASIS')
    pad_rows = [x for x in prepared['universe'] if json.loads(x['id'])[1] == 'PAD']
    need(len(pad_rows) == slots, 'ALL_PAD_ROWS_PRESENT')
    for row in pad_rows:
        need(len(row['m']) == 2 and all(value == '0' for point, value in row['m']), 'PAD_LITERAL_ZERO_ROWS')
    model = copy.deepcopy(prepared['model'])
    model.update(schema='Z-growing-point-model-v3', version=model['version'] + ':engine-v4',
                 pair_nogoods=[], unary_nogoods=[])
    actual, engine = complete_engine(ctx, name + '/search', model)
    need(actual['raw']['status'] == 'SAT', 'LOGICAL_QUALIFICATION_SEARCH_POSITIVE')
    o, refs['oracle'], costs['oracle'] = oracle(ctx, name, model)
    if o['status'] != 'NOT_APPLICABLE_SIZE_SCOPE':
        need(o['status'] == 'EXHAUSTED' and o['exists'] is True, 'LOGICAL_TINY_ORACLE')
        need(any(ctx.wire(sorted(s['selected'])) == ctx.wire(sorted(actual['raw']['selected']))
                 for s in o['solutions']), 'LOGICAL_SELECTED_IN_INDEPENDENT_COVERS')
    selected = actual['raw']['selected']
    m, refs['decoded'], costs['decode'] = stage(ctx, name + '/decoded.json',
        lambda: ctx.mods['M'].decode(prepared, selected, limits(ctx, 'M')))
    n, refs['independent_decoded'], costs['independent_decode'] = stage(ctx, name + '/independent-decoded.json',
        lambda: ctx.mods['N'].decode(prepared, selected, **limits(ctx, 'N')))
    need(m['status'] == n['status'] == 'UNVERIFIED_NATIVE_CERTIFICATE', 'BOTH_LOGICAL_DECODERS')
    for key in ('statement', 'proof', 'slots', 'slot_to_native', 'native_to_slot',
                'reference_mapping', 'proof_dag', 'selected', 'selected_sha256',
                'original_statement_sha256', 'scope'):
        need(ctx.wire(m[key]) == ctx.wire(n[key]), 'EXACT_TWO_DECODER_JOIN:' + key)
    b, refs['native'], costs['native'] = stage(ctx, name + '/native.json', lambda:
        ctx.mods['B'].check(m['statement']['theory'], m['proof'], m['statement']['goal'], limits(ctx, 'B')))
    need(b['status'] == 'VERIFIED', 'WHOLE_LOGICAL_NATIVE_PROOF')
    need(any(x['rule'] == specification['required_native_rule'] for x in m['proof']),
         'DECLARED_NATIVE_RULE_EXERCISED')
    return dict(id=declaration['id'], status='QUALIFIED', kind=specification['kind'], refs=refs,
        engine=engine, census=prepared['census'], native_zeros=native_zeros, costs=costs,
        native_lines=len(m['proof']), rules=[x['rule'] for x in m['proof']],
        oracle_status=o['status'], pad_inventory_rows=len(pad_rows),
        selected_pad_slots=sum(x is None for x in m['slot_to_native']),
        selected_pad_scope='Observed only; a minimum-slot MP fixture need not select PAD.',
        proof_scope='Searched fresh qualification statement, not the arithmetic study target or an imported proof.')


def run(ctx):
    """Run only after Root has frozen all Sources, inputs, bounds and runtime.

    ctx.root/mods/read/save/sha/wire/limits/engine are supplied by the owned
    driver. engine saves raw and actual callbacks before C/T/paired checks.
    The owning worker writes the returned phase result exactly once.
    """
    cases = ctx.read('input/qualification-cases-v1.json')['cases']
    need(len(cases) == len({x['id'] for x in cases}) == 20, 'TWENTY_DECLARED_TINY_CASES')
    rows, saved = [], {}
    for case in cases:
        name = 'data/qualify/cases/' + case['id']
        actual, row = complete_engine(ctx, name, case['model'])
        o, oref, ocost = oracle(ctx, name, case['model'])
        row.update(id=case['id'], oracle=oref, oracle_cost=ocost,
                   required_observations=required_observations(ctx, case, actual['observations']))
        ctx.save(name + '/qualification-observation-checks.json', row)
        need(actual['raw']['status'] == case['expected']['raw_status']
             and o['status'] == 'EXHAUSTED' and o['exists'] is case['expected']['exists']
             and o['exists'] is (actual['raw']['status'] == 'SAT'), 'TINY_EXISTENCE_AGREEMENT:' + case['id'])
        if actual['raw']['status'] == 'SAT':
            need(any(ctx.wire(sorted(x['selected'])) == ctx.wire(sorted(actual['raw']['selected']))
                     for x in o['solutions']), 'ACTUAL_SOLUTION_IN_ORACLE_COVERS:' + case['id'])
        if 'selected' in case['expected']:
            need(ctx.wire(actual['raw']['selected']) == ctx.wire(case['expected']['selected']), 'DECLARED_SELECTED_LITERAL_IDS')
        row['status'] = 'QUALIFIED'
        rows.append(row)
        saved[case['id']] = (case['model'], actual)
    model, actual = saved['uq01-immutable-unary-forced']
    controls = refusal_controls(ctx, model, actual)
    declarations = ctx.read('input/logic-qualification-declarations-v1.json')['cases']
    need(len(declarations) == len({x['declaration']['id'] for x in declarations}) == 2,
         'TWO_DECLARED_LOGICAL_QUALIFIERS')
    logical = [logic_case(ctx, x) for x in declarations]
    return dict(schema='Quantified-marking-qualification-v1', version=VERSION,
        status='QUALIFIED', qualification_version=VERSION, cases=rows, controls=controls, logical=logical,
        counts=dict(tiny_cases=len(rows), malformed_unary_calls=6, resource_engine_calls=1,
                    semantic_mutants=1, actual_graph_mutants=1, logical_cases=len(logical),
                    definite_engine_calls=len(rows) + len(logical),
                    actual_tiny_snapshots=sum(x['actual_snapshots'] for x in rows),
                    actual_logical_snapshots=sum(x['engine']['actual_snapshots'] for x in logical)),
        scope='Fresh fixed tiny-model and generic logical-adapter qualification. No target proof supplied, no learned layer activated, no arithmetic target solved or large subset enumeration claimed.')
