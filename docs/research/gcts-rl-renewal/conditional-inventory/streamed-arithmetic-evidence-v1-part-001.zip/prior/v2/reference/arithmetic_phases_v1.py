"""Fresh quantified arithmetic phases; inert until the reviewed driver calls run.

No scientific imports, previous proof/bank reads or search at module load.
The caller owns frozen-source/process custody and exclusive bounded persistence.
Every helper return is persisted before its admission gate. Only a complete
scoped fixed-CID exhaustion may supply a negative label.
"""
import copy
import hashlib
import time

VERSION = 'QMT-arithmetic-phases-v1'
DECLARATION = 'input/arithmetic-declaration-v1.json'
GUARD = 'learned:unary:guard:v1'

DEFAULTS = {
    'rf': dict(max_items=100000000, max_work=1000000000, wall_seconds=30.0),
    'bridge': dict(max_formulas=1024, max_zero_definitions=8000,
                   max_definitions=8000, max_slots=16, max_items=500000000,
                   max_depth=128, wall_seconds=120.0),
    'model': dict(max_formulas=1024, max_rows=250000, max_slots=16,
                  max_zero_definitions=8000, max_items=500000000,
                  max_depth=128, wall_seconds=120.0),
    'checker': dict(max_items=500000000, max_work=1000000000, wall_seconds=120.0),
    'native': dict(max_depth=256, max_operations=10000000, max_proof_lines=4096),
    'overlay': dict(max_work=1000000000, wall_seconds=120.0),
}
SEMANTIC_FIELDS = ('statement', 'proof', 'slots', 'slot_to_native',
                   'native_to_slot', 'reference_mapping', 'proof_dag',
                   'selected', 'selected_sha256', 'original_statement_sha256', 'scope')


class StopPhase(Exception):
    def __init__(self, status, stage, reason, refs):
        super().__init__(reason)
        self.status, self.stage, self.reason, self.refs = status, stage, reason, dict(refs)


def need(ok, reason):
    if not ok:
        raise AssertionError(reason)


def same(ctx, left, right, reason):
    need(ctx.wire(left) == ctx.wire(right), reason)


def limits(ctx, group):
    """Use the prospective group's complete configured value, never adapt a cap."""
    declared = ctx.limits.get(group, DEFAULTS.get(group))
    need(type(declared) is dict, 'PROSPECTIVE_LIMIT_GROUP:' + group)
    if group in DEFAULTS:
        same(ctx, declared, DEFAULTS[group], 'UNCHANGED_PROSPECTIVE_LIMITS:' + group)
    return copy.deepcopy(declared)


def saved(ctx, path, value, refs, key):
    reference = ctx.save(path, value)
    need(type(reference) is dict and {'path', 'bytes', 'sha256'} <= set(reference),
         'EXACT_SAVED_REFERENCE:' + path)
    need(reference.get('complete_json') is True, 'COMPLETE_SAVED_JSON:' + path)
    refs[key] = reference
    return reference


def read_ref(ctx, reference):
    """Authenticate previous-phase physical bytes, then load their JSON object."""
    need(type(reference) is dict and {'path', 'bytes', 'sha256'} <= set(reference)
         and reference.get('complete_json') is True, 'COMPLETE_PRIOR_ARTIFACT_REFERENCE')
    name = reference['path']
    need(type(name) is str and name and not name.startswith('/') and '..' not in name.split('/'),
         'LOCAL_PRIOR_ARTIFACT_PATH')
    path = ctx.root / name
    need(not path.is_symlink() and path.resolve().is_relative_to(ctx.root.resolve()), 'PRIOR_ARTIFACT_CONTAINMENT')
    digest, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1048576), b''):
            size += len(part)
            need(size <= 134217728, 'PRIOR_PHYSICAL_CAPTURE_BOUND')
            digest.update(part)
    need(type(reference['bytes']) is int and reference['bytes'] == size
         and reference['sha256'] == digest.hexdigest(), 'EXACT_PRIOR_ARTIFACT_BYTES')
    return ctx.read(name)


def call(ctx, path, fn, refs, key, *args, **kwargs):
    start = time.perf_counter()
    value = fn(*args, **kwargs)
    seconds = time.perf_counter() - start
    reference = saved(ctx, path, value, refs, key)
    return value, reference, seconds


def gate(value, accepted, stage, refs):
    need(type(value) is dict, 'HELPER_RESULT_OBJECT:' + stage)
    if value.get('status') not in accepted:
        status = value.get('status')
        unknown = type(status) is str and status.startswith('UNKNOWN')
        raise StopPhase('UNKNOWN' if unknown else 'REJECTED', stage,
                        str(value.get('reason', status)), refs)


def normal_model(model):
    """Literal independent normalization only; no engine/private helper call."""
    out = copy.deepcopy(model)
    out['roots'] = sorted(out['roots'])
    for channel in ('t', 'm'):
        out['seed'][channel] = sorted(out['seed'][channel])
    for row in out['inventory']['placements']:
        row['t'] = sorted(row['t'])
        row['m'] = sorted(row['m'])
    out['inventory']['placements'].sort(key=lambda row: row['id'])
    out['pair_nogoods'] = sorted(out['pair_nogoods'])
    out['unary_nogoods'] = sorted(out['unary_nogoods'])
    return out


def migrate(ctx, model):
    need(set(model) == {'schema', 'version', 'capacity', 'roots', 'seed', 'inventory'}
         and model['schema'] == 'Z-growing-point-model-v1', 'EXACT_PREPARED_MODEL_ABI')
    out = copy.deepcopy(model)
    out.update(schema='Z-growing-point-model-v3', version=model['version'] + ':engine-v4',
               pair_nogoods=[], unary_nogoods=[])
    out = normal_model(out)
    back = {k: out[k] for k in ('capacity', 'roots', 'seed', 'inventory')}
    same(ctx, back, {k: model[k] for k in back}, 'MIGRATION_PRESERVES_ALL_T_M_AND_CIDS')
    return out


def previous(ctx, phase, expected):
    value = ctx.read('data/' + phase + '/result.json')
    need(type(value) is dict and value['schema'] == 'QMT-' + phase + '-result-v1',
         'PRIOR_PHASE_SCHEMA:' + phase)
    if value['status'] != expected:
        raise StopPhase('UNKNOWN', 'prior_' + phase,
                        'PRIOR_PHASE_NOT_ADMITTED:' + str(value['status']), {})
    return value


def load_prepared(ctx):
    prior = previous(ctx, 'prepare', 'PREPARED')
    prepared = read_ref(ctx, prior['refs']['prepared'])
    model = read_ref(ctx, prior['refs']['model'])
    same(ctx, prepared['binding'], prior['prepared_binding'], 'PRIOR_ADMITTED_PREPARED_BINDING')
    same(ctx, ctx.sha(model), prior['scope_sha256'], 'PRIOR_ADMITTED_ENGINE_MODEL_SCOPE')
    expected = migrate(ctx, prepared['model'])
    same(ctx, model, expected, 'EXACT_CURRENT_PREPARED_ENGINE_MIGRATION')
    return prepared, model


def engine(ctx, name, model, *, max_nodes=None):
    start = time.perf_counter()
    answer = ctx.engine(name, model, actual=False, max_nodes=max_nodes)
    seconds = time.perf_counter() - start
    need(type(answer) is dict and {'raw', 'semantic', 'observations', 'refs'} <= set(answer),
         'ENGINE_RETURN_PACKET')
    need({'model', 'raw', 'semantic'} <= set(answer['refs']), 'RAW_BEFORE_ASSURANCE_REFS')
    need(type(answer['raw']) is dict and type(answer['semantic']) is dict, 'ENGINE_AND_C3_OBJECTS')
    return answer, seconds


def native(ctx, statement, proof, path, refs, key):
    value, reference, seconds = call(ctx, path, ctx.mods['B'].check, refs, key,
                                     statement['theory'], proof, statement['goal'], limits(ctx, 'native'))
    if value.get('status') == 'VERIFIED':
        need(type(value.get('checked_lines')) is int and value['checked_lines'] == len(proof),
             'NATIVE_WHOLE_CERTIFICATE_LINE_COUNT')
    return value, reference, seconds


def decode(ctx, prepared, selected, prefix):
    """Reusable exact original-catalogue projection and fresh whole native check."""
    refs, costs = {}, {}
    m, _, costs['adapter_decode_seconds'] = call(ctx, prefix + '/adapter-decoded.json.gz',
        ctx.mods['M'].decode, refs, 'adapter_decoded', prepared, selected, limits=limits(ctx, 'model'))
    gate(m, {'UNVERIFIED_NATIVE_CERTIFICATE'}, 'adapter_decode', refs)
    n, _, costs['independent_decode_seconds'] = call(ctx, prefix + '/independent-decoded.json.gz',
        ctx.mods['N'].decode, refs, 'independent_decoded', prepared, selected, **limits(ctx, 'checker'))
    gate(n, {'UNVERIFIED_NATIVE_CERTIFICATE'}, 'independent_decode', refs)
    for field in SEMANTIC_FIELDS:
        same(ctx, m[field], n[field], 'INDEPENDENT_NATIVE_PROJECTION:' + field)
    same(ctx, m['statement'], prepared['statement'], 'EXACT_ORIGINAL_NATIVE_STATEMENT')
    same(ctx, m['selected'], sorted(selected), 'EXACT_NATIVE_SELECTED_UNION')
    projection = dict(status='VERIFIED_LITERAL_PROJECTION', fields=list(SEMANTIC_FIELDS),
                      prepared_scope=prepared['binding']['scope'], selected_sha256=ctx.sha(sorted(selected)),
                      adapter_decoded_sha256=ctx.sha(m), independent_decoded_sha256=ctx.sha(n),
                      native_logical_validity='SEPARATE_FRESH_B_GATE')
    saved(ctx, prefix + '/projection.json.gz', projection, refs, 'projection')
    proof_ref = saved(ctx, prefix + '/native-proof.json.gz', m['proof'], refs, 'native_proof')
    b, b_ref, costs['native_seconds'] = native(ctx, prepared['statement'], m['proof'],
                                             prefix + '/native-receipt.json.gz', refs, 'native_receipt')
    gate(b, {'VERIFIED'}, 'native_whole_proof', refs)
    return dict(status='VERIFIED_NATIVE_PROOF', proof=m['proof'], native_receipt=b,
                decoded=m, refs=refs, native_proof_ref=proof_ref, native_receipt_ref=b_ref, costs=costs)


def prepare(ctx):
    refs, costs = {}, {}
    declaration = ctx.read(DECLARATION)
    need(type(declaration.get('slots')) is int and declaration['slots'] == 8,
         'FROZEN_EIGHT_SLOT_ARITHMETIC_CASE')
    need(not {'proof', 'proofs', 'target_proof', 'witness', 'selected', 'bank', 'control_proof'}
         & set(declaration), 'NO_PROOF_OR_BANK_INPUT')
    saved(ctx, 'data/prepare/declaration.json.gz', declaration, refs, 'declaration')
    start = time.perf_counter()
    try:
        compiled, generation = ctx.mods['F'].compile_case(declaration)
    except ctx.mods['F'].BasisLimit as error:
        saved(ctx, 'data/prepare/compiler-refusal.json.gz', error.receipt(), refs, 'compiler_refusal')
        raise StopPhase('UNKNOWN', 'full_RF_compile', str(error), refs)
    costs['compile_seconds'] = time.perf_counter() - start
    saved(ctx, 'data/prepare/compiled.json.gz', compiled, refs, 'compiled')
    saved(ctx, 'data/prepare/generation.json.gz', generation, refs, 'generation')
    r, _, costs['RF_independent_seconds'] = call(ctx, 'data/prepare/rf-receipt.json.gz',
        ctx.mods['R'].verify, refs, 'rf_receipt', declaration, compiled, generation, **limits(ctx, 'rf'))
    gate(r, {'VERIFIED'}, 'full_RF_independent_profile', refs)
    same(ctx, r['declaration_sha256'], ctx.sha(declaration), 'RF_ORIGINAL_DECLARATION_HASH')
    same(ctx, r['compiled_core_sha256'], generation['compiled_core_sha256'], 'RF_COMPLETE_CORE_HASH')
    zero_checks, zero_seconds = [], 0.0
    for zero in compiled['zero_instances']:
        start = time.perf_counter()
        b = ctx.mods['B'].check(compiled['theory'], [zero['line']], zero['line']['formula'], limits(ctx, 'native'))
        zero_seconds += time.perf_counter() - start
        record = dict(id=zero['id'], formula_id=zero['formula_id'],
                      native_line_sha256=ctx.sha(zero['line']), receipt=b)
        zero_checks.append(record)
        if b.get('status') != 'VERIFIED' or type(b.get('checked_lines')) is not int or b['checked_lines'] != 1:
            saved(ctx, 'data/prepare/zero-native-receipts.json.gz', zero_checks, refs, 'zero_native_receipts')
            gate(b, {'VERIFIED'}, 'native_every_ZERO', refs)
            need(False, 'NATIVE_ZERO_NOT_EXACT_ONE_LINE')
    costs['all_ZERO_native_seconds'] = zero_seconds
    saved(ctx, 'data/prepare/zero-native-receipts.json.gz', zero_checks, refs, 'zero_native_receipts')
    need(len(zero_checks) == len(compiled['zero_instances']), 'EVERY_ORIGINAL_ZERO_CHECKED')
    bridge, _, costs['bridge_seconds'] = call(ctx, 'data/prepare/bridge.json.gz',
        ctx.mods['A'].bridge, refs, 'bridge', declaration, compiled, generation,
        declaration['slots'], limits=limits(ctx, 'bridge'))
    gate(bridge, {'CATALOGUE_UNVERIFIED'}, 'full_RF_bridge', refs)
    q, _, costs['bridge_independent_seconds'] = call(ctx, 'data/prepare/bridge-receipt.json.gz',
        ctx.mods['Q'].verify, refs, 'bridge_receipt', declaration, compiled, generation,
        declaration['slots'], bridge, **limits(ctx, 'checker'))
    gate(q, {'VERIFIED'}, 'full_RF_bridge_independent', refs)
    same(ctx, q['bindings'], bridge['bindings'], 'EXACT_BRIDGE_ADMISSION_BINDINGS')
    prepared, _, costs['model_prepare_seconds'] = call(ctx, 'data/prepare/prepared.json.gz',
        ctx.mods['M'].prepare, refs, 'prepared', bridge['catalogue'], declaration['slots'],
        limits=limits(ctx, 'model'))
    gate(prepared, {'PREPARED_UNVERIFIED'}, 'complete_shared_model', refs)
    n, _, costs['model_independent_seconds'] = call(ctx, 'data/prepare/model-receipt.json.gz',
        ctx.mods['N'].verify_model, refs, 'model_receipt', bridge['catalogue'], prepared,
        **limits(ctx, 'checker'))
    gate(n, {'VERIFIED'}, 'complete_generic_shared_model_independent', refs)
    same(ctx, n['catalogue_sha256'], bridge['bindings']['catalogue_sha256'], 'FULL_BRIDGE_MODEL_CATALOGUE')
    same(ctx, n['original_statement_sha256'], ctx.sha(declaration['problem']), 'UNCHANGED_PROBLEM_BINDING')
    same(ctx, n['model_sha256'], ctx.sha(prepared['model']), 'EXACT_ADMITTED_PREPARED_MODEL')
    model = migrate(ctx, prepared['model'])
    saved(ctx, 'data/prepare/model.json.gz', model, refs, 'model')
    migration = dict(status='VERIFIED_LITERAL_SCHEMA_MIGRATION', prepared_model_sha256=ctx.sha(prepared['model']),
                     migrated_model_sha256=ctx.sha(model), changed_fields=['schema', 'version', 'pair_nogoods', 'unary_nogoods'],
                     proof_semantics='All original CIDs, roots, t/m contributions and mandatory seed marks retained.')
    saved(ctx, 'data/prepare/migration.json.gz', migration, refs, 'migration')
    return dict(status='PREPARED', case_id=declaration['id'], slots=declaration['slots'], refs=refs,
                costs=costs, scope_sha256=ctx.sha(model), prepared_binding=prepared['binding'],
                census=prepared['census'], ZERO_checks=len(zero_checks),
                admission='Full unchanged RF profile, every native ZERO, full RF bridge and complete generic compact point model admitted separately; no proof supplied or searched in this phase.')


def acquire(ctx):
    prepared, model = load_prepared(ctx)
    run, seconds = engine(ctx, 'acquire-original-node1', model, max_nodes=1)
    raw = run['raw']
    events = raw.get('events', [])
    placed = next((e for e in events if e.get('kind') == 'PLACED'), None)
    proposal = None if placed is None else placed['candidate']
    if proposal is not None:
        need(sum(row['id'] == proposal for row in model['inventory']['placements']) == 1,
             'ACTUAL_FIRST_PLACED_PROPOSAL_MEMBER')
    refs = dict(engine=run['refs'])
    saved(ctx, 'data/acquire/proposal.json.gz', dict(cid=proposal, event=placed,
        raw_sha256=ctx.sha(raw), scope_sha256=ctx.sha(model),
        label='NOT_A_FAILURE_LABEL', source='First actual PLACED event only; prefix UNKNOWN is allowed.'), refs, 'proposal')
    return dict(status='ACQUIRED_PROPOSAL' if proposal is not None else 'UNKNOWN',
                reason=None if proposal is not None else 'NO_ACTUAL_PLACED_PROPOSAL_IN_OWNED_PREFIX',
                cid=proposal, scope_sha256=ctx.sha(model), engine_status=raw['status'],
                semantic_status=run['semantic']['status'], refs=refs, costs=dict(engine_and_C_seconds=seconds),
                prepared_scope=prepared['binding']['scope'],
                admission='Proposal only. No prefix, dead context or UNKNOWN is a global failure label.')


def fixed_model(ctx, base, cid):
    rows = base['inventory']['placements']
    owners = [row for row in rows if row['id'] == cid]
    need(len(owners) == 1 and base['pair_nogoods'] == base['unary_nogoods'] == [], 'ONE_UNFILTERED_FIXED_CID')
    owner = owners[0]
    totals, marks = dict(base['seed']['t']), dict(base['seed']['m'])
    for p, value in owner['t']:
        totals[p] = totals.get(p, 0) + value
        need(totals[p] <= base['capacity'], 'FIXED_CID_CAPACITY_LEGAL')
    for p, value in owner['m']:
        need(p not in marks or marks[p] == value, 'FIXED_CID_MANDATORY_MARK_LEGAL')
        marks[p] = value
    out = copy.deepcopy(base)
    out['version'] += ':fixed-cid:' + ctx.sha([cid])
    out['roots'] = sorted(set(base['roots']) | {p for p, value in owner['t']})
    out['seed'] = dict(t=[[p, totals[p]] for p in sorted(totals)], m=[[p, marks[p]] for p in sorted(marks)])
    out['inventory']['placements'] = [copy.deepcopy(row) for row in rows if row['id'] != cid]
    need(len(out['inventory']['placements']) == len(rows) - 1, 'EXACT_FIXED_CID_REMOVAL')
    return normal_model(out)


def label(ctx):
    prepared, base = load_prepared(ctx)
    acquisition = previous(ctx, 'acquire', 'ACQUIRED_PROPOSAL')
    cid = acquisition['cid']
    same(ctx, acquisition['scope_sha256'], ctx.sha(base), 'FRESH_ACQUISITION_BASE_SCOPE')
    fixed = fixed_model(ctx, base, cid)
    run, seconds = engine(ctx, 'label-fixed-cid', fixed)
    raw, semantic = run['raw'], run['semantic']
    refs, costs = dict(engine=run['refs']), dict(engine_and_C_seconds=seconds)
    native_packet = None
    if raw['status'] == 'UNSAT' and semantic['status'] == 'VERIFIED':
        need(semantic['run_status'] == 'UNSAT' and semantic['bounded_absence'] is True
             and semantic['claim'] == 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'
             and semantic['event_coverage'] == 'COMPLETE', 'ONLY_FULL_FIXED_CONTEXT_EXHAUSTION_NEGATIVE')
        label_value = 'NEGATIVE'
    elif raw['status'] == 'SAT' and semantic['status'] == 'VERIFIED':
        need(semantic['run_status'] == 'SAT' and semantic['bounded_absence'] is False,
             'EXACT_FIXED_CID_POSITIVE_CLAIM')
        union = sorted(raw['selected'] + [cid])
        need(len(set(union)) == len(union), 'FIXED_CID_NOT_IN_RESIDUAL_SELECTION')
        # If decoding/native assurance refuses, retain all its raw returns and
        # stop LABEL. U's UNKNOWN-label profile requires a C UNKNOWN receipt;
        # never manufacture one from an otherwise verified C SAT certificate.
        try:
            native_packet = decode(ctx, prepared, union, 'data/label/fixed-union-native')
        except StopPhase as error:
            error.refs['engine'] = run['refs']
            raise
        refs['native'] = native_packet['refs']
        costs.update(native_packet['costs'])
        label_value = 'POSITIVE'
    else:
        gate(semantic, {'UNKNOWN'}, 'fixed_query_independent_semantics', refs)
        need(semantic.get('bounded_absence') is False, 'UNKNOWN_NEVER_NEGATIVE')
        label_value = 'UNKNOWN'
    evidence = {key: run['refs'][key] for key in ('model', 'raw', 'semantic')}
    if native_packet is not None:
        evidence.update(native_receipt=native_packet['native_receipt_ref'], native_proof=native_packet['native_proof_ref'])
    binding = dict(schema='Unary-fixed-query-binding-v1', cid=cid, label=label_value,
        scope_sha256=ctx.sha(base), base_model_sha256=ctx.sha(base), fixed_model_sha256=ctx.sha(fixed),
        raw_result_sha256=ctx.sha(raw), semantic_receipt_sha256=ctx.sha(semantic),
        native_receipt_sha256=None if native_packet is None else ctx.sha(native_packet['native_receipt']),
        native_proof_sha256=None if native_packet is None else ctx.sha(native_packet['proof']), evidence_refs=evidence)
    packet = dict(cid=cid, label=label_value, scope_sha256=ctx.sha(base), fixed_model=fixed,
                  raw_result=raw, semantic_receipt=semantic, binding=binding)
    if native_packet is not None:
        packet.update(native_receipt=native_packet['native_receipt'], native_proof=native_packet['proof'])
    saved(ctx, 'data/label/query-packet.json.gz', packet, refs, 'query_packet')
    learner_label = dict(cid=cid, status=label_value, scope_sha256=ctx.sha(base),
                         certificate_binding_sha256=ctx.sha(binding))
    saved(ctx, 'data/label/learner-labels.json.gz', [learner_label], refs, 'learner_labels')
    return dict(status='LABELLED', scope_sha256=ctx.sha(base), labels=[learner_label],
                query_bindings=[binding], query_packets_ref=refs['query_packet'], refs=refs, costs=costs,
                native_verified=label_value == 'POSITIVE',
                admission='Only a fresh complete fixed-CID extension query is labeled. NEGATIVE is bounded finite-inventory exhaustion, POSITIVE has original-union native proof, UNKNOWN never prunes.')


def learn(ctx):
    prepared, base = load_prepared(ctx)
    labelled = previous(ctx, 'label', 'LABELLED')
    same(ctx, labelled['scope_sha256'], ctx.sha(base), 'LABEL_SCOPE_FOR_LEARNING')
    packet = read_ref(ctx, labelled['query_packets_ref'])
    labels = read_ref(ctx, labelled['refs']['learner_labels'])
    same(ctx, labels, labelled['labels'], 'PRIOR_LABEL_RESULT_AND_LEARNER_ROWS')
    same(ctx, [packet['binding']], labelled['query_bindings'], 'PRIOR_LABEL_RESULT_AND_QUERY_BINDING')
    # This callback authenticates actual prior LABEL PID, native0, protocol,
    # Source/runtime guards and physical artifact bytes; pure U cannot do that.
    provenance = ctx.make_provenance(labelled)
    refs, costs = {}, {}
    saved(ctx, 'data/learn/provenance.json.gz', provenance, refs, 'provenance')
    ids = [row['id'] for row in base['inventory']['placements']]
    need(ids == sorted(set(ids)), 'FULL_ORIGINAL_CANDIDATE_ID_LIST')
    synthesis, _, costs['synthesis_seconds'] = call(ctx, 'data/learn/synthesis.json.gz',
        ctx.mods['L'].synthesize, refs, 'synthesis', ids, labels, ctx.sha(base), GUARD, **limits(ctx, 'overlay'))
    gate(synthesis, {'SOLVED'}, 'sparse_extra_marking_synthesis', refs)
    overlay, _, costs['overlay_construction_seconds'] = call(ctx, 'data/learn/overlay.json.gz',
        ctx.mods['L'].apply, refs, 'overlay', base, synthesis, **limits(ctx, 'overlay'))
    gate(overlay, {'CONSTRUCTED_UNVERIFIED_OVERLAY'}, 'structural_overlay_application', refs)
    u, _, costs['overlay_independent_seconds'] = call(ctx, 'data/learn/overlay-receipt.json.gz',
        ctx.mods['U'].verify, refs, 'overlay_receipt', base, overlay['marked_model'], overlay['control_model'],
        synthesis, [packet], provenance, guard_point=GUARD, **limits(ctx, 'overlay'))
    gate(u, {'VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION'}, 'scoped_overlay_independent_admission', refs)
    same(ctx, u['model_bindings'], dict(base=ctx.sha(base), marked=ctx.sha(overlay['marked_model']),
                                     control=ctx.sha(overlay['control_model'])), 'FULL_ADMITTED_LANE_MODELS')
    saved(ctx, 'data/learn/marked-model.json.gz', overlay['marked_model'], refs, 'marked_model')
    saved(ctx, 'data/learn/control-model.json.gz', overlay['control_model'], refs, 'control_model')
    return dict(status='LEARNED_CERTIFIED', scope_sha256=ctx.sha(base), labels=labels, refs=refs, costs=costs,
                forbidden_cids=synthesis['forbidden_cids'], counters=synthesis['counters'],
                preservation_status=u['status'], preservation_basis=u['preservation_basis'],
                admission='Conditional scoped unary preservation admitted with actual prior clean LABEL custody; all old mandatory markings retained. No new geometric law, pair-corona catalogue, RL, heldout transfer or speed advantage is claimed.')


def evaluate(ctx):
    prepared, base = load_prepared(ctx)
    learning = previous(ctx, 'learn', 'LEARNED_CERTIFIED')
    models = [('BASE', base), ('MARKS', read_ref(ctx, learning['refs']['marked_model'])),
              ('FILTER', read_ref(ctx, learning['refs']['control_model']))]
    overlay_receipt = read_ref(ctx, learning['refs']['overlay_receipt'])
    need(overlay_receipt['status'] == 'VERIFIED_CONDITIONAL_ON_SCOPED_EXHAUSTION', 'ADMITTED_EXTRA_LAYER_BEFORE_EVALUATION')
    same(ctx, learning['scope_sha256'], ctx.sha(base), 'EVALUATION_ORIGINAL_SCOPE')
    rows, refs = [], {}
    for lane, model in models:
        need(len(model['inventory']['placements']) == len(base['inventory']['placements']), 'NO_LANE_INVENTORY_THINNING')
        same(ctx, [x['id'] for x in model['inventory']['placements']],
             [x['id'] for x in base['inventory']['placements']], 'SAME_FULL_LANE_IDENTITIES')
        binding_key = {'BASE': 'base', 'MARKS': 'marked', 'FILTER': 'control'}[lane]
        same(ctx, ctx.sha(normal_model(model)), overlay_receipt['model_bindings'][binding_key], 'EXACT_FROZEN_ADMITTED_LANE_MODEL')
        run, seconds = engine(ctx, 'evaluate-' + lane.lower(), model)
        raw, semantic = run['raw'], run['semantic']
        record = dict(lane=lane, raw_status=raw['status'], reason=raw['reason'],
                      semantic_status=semantic['status'], refs=run['refs'],
                      model_sha256=ctx.sha(normal_model(model)), stats=raw['stats'],
                      costs=dict(engine_and_C_seconds=seconds), native_status='NOT_APPLICABLE',
                      admitted_status='UNKNOWN', bounded_absence=False)
        if raw['status'] == 'SAT' and semantic['status'] == 'VERIFIED':
            need(semantic['run_status'] == 'SAT', 'EVALUATION_POSITIVE_SEMANTIC_BINDING')
            try:
                projected = decode(ctx, prepared, raw['selected'], 'data/evaluate/' + lane.lower() + '-native')
            except StopPhase as error:
                record.update(native_status=error.status, native_reason=error.reason, native_refs=error.refs)
                if error.status == 'REJECTED':
                    record['admitted_status'] = 'REJECTED_NATIVE_PROOF'
            else:
                record.update(native_status='VERIFIED', admitted_status='VERIFIED_NATIVE_POSITIVE',
                              native_refs=projected['refs'], native_proof_lines=len(projected['proof']))
                record['costs'].update(projected['costs'])
        elif raw['status'] == 'UNSAT' and semantic['status'] == 'VERIFIED':
            need(semantic['run_status'] == 'UNSAT' and semantic['bounded_absence'] is True
                 and semantic['claim'] == 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION', 'EVALUATION_FINITE_ABSENCE_SCOPE')
            record.update(admitted_status='VERIFIED_BOUNDED_EXHAUSTION', bounded_absence=True)
        else:
            if semantic['status'] == 'REJECTED':
                record['admitted_status'] = 'REJECTED_ASSURANCE'
            need(semantic.get('bounded_absence') is False, 'UNADMITTED_EVALUATION_NEVER_ABSENCE')
        saved(ctx, 'data/evaluate/' + lane.lower() + '-summary.json.gz', record, refs, lane)
        rows.append(record)
    return dict(status='EVALUATED', lanes=rows, refs=refs, lane_order=[x[0] for x in models],
                complete_native_positives=sum(r['admitted_status'] == 'VERIFIED_NATIVE_POSITIVE' for r in rows),
                finite_exhaustions=sum(r['bounded_absence'] for r in rows),
                unresolved=sum(r['admitted_status'] == 'UNKNOWN' for r in rows),
                rejected_assurance=sum(r['admitted_status'].startswith('REJECTED') for r in rows),
                admission='Fixed warm-process order; exact same full inventory and logical marks, with only the admitted extra overlay versus equivalent ordinary unary control. All raw UNKNOWN/refusal outcomes retained. Compilation, acquisition, labeling, learning and assurance costs are separate; no speedup or new-theorem claim.')


def run(phase, ctx):
    need(phase in ('prepare', 'acquire', 'label', 'learn', 'evaluate'), 'KNOWN_ARITHMETIC_PHASE')
    started = time.perf_counter()
    try:
        result = {'prepare': prepare, 'acquire': acquire, 'label': label,
                  'learn': learn, 'evaluate': evaluate}[phase](ctx)
    except StopPhase as error:
        result = dict(status=error.status, stopped_stage=error.stage, reason=error.reason, refs=error.refs,
                      admission='No partial result is promoted; no retry, negative label or learned restriction follows from this refusal.')
    result.update(schema='QMT-' + phase + '-result-v1', version=VERSION, phase=phase,
                  module_seconds=time.perf_counter() - started)
    return result
