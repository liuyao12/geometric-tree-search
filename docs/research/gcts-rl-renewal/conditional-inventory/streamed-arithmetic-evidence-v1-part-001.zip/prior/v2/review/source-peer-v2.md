# Independent v2 Source peer closure

Status: `PASS_SOURCE_REVIEW_BEFORE_FREEZE`. No remaining blocker was found in
the held Sources and prospective input/API below. This is static review, not
qualification, an activation admission, a found proof or a performance result.
No scientific module was imported or called and no test was executed.

I read the complete U1/U2 bodies and APIs, the complete qualification bodies,
the full arithmetic v2 body and control declarations, the common-driver body
through its exact preserved baseline/diff, and the new experiment/control plans.
The current copied master was reread in full and retains SHA256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
AST and direct text comparisons were used only to inspect Source preservation.

| Held file | Bytes | SHA256 |
| --- | ---: | --- |
| `source/unary_overlay_checker_v2.py` | 24617 | `5ec69d08fe14f1e64c8e2b5575caf8ff9dcfe1874db5a750ff3a8159762be778` |
| `source/qualification_phase_v2.py` | 26228 | `dcb1ff94fb55fa7161da87485731f30af019cd2a346d9e7405ce90163899023f` |
| `source/arithmetic_phases_v2.py` | 33530 | `74ef9c3ed8e2ee443dc8cd14bae75b2b255f0f2c2e0ce3100ee448f51c28fac2` |
| `source/run_quantified_transfer_v2.py` | 21723 | `df4cb322e51b57877bbe40ff3f5f4c95c0c6b1413b5b99d0bc678e6650ae13a4` |
| `input/overlay-equality-qualification-v1.json` | 3958 | `ed86a62cd937c47c42a79a31fc97ad0a83f8b451de7e7a2dfe88c0d98b8331f9` |
| `plan/overlay-checker-v2-API-v1.md` | 7816 | `246f045108f9b5c976b2f632ce4a04d6168adf3cf66881e93eb38148a83d389e` |
| `plan/qualification-v2-API-v1.md` | 8234 | `78c1fa5bc47c592cfcb1e36da25add2c1f259d5b05729605fa71ee1fb4083dbb` |
| `plan/arithmetic-controls-v2-API-v1.md` | 3165 | `1e8c40ac6596c0db42fa2f53928340ac7e6638403fab1ee296166f69899374a6` |
| `plan/experimental-protocol-v2.json` | 3699 | `1176dae532e2031dd8146bd719801ed523ba81f4336e1cfa627e280d5649c198` |

The exact U1 baseline is `reference/unary_overlay_checker_v1.py`, 20,252 bytes,
SHA256 `e66c1cae5bc7930d5b2477104807699e755c7d14c87d5e4fcca185b4c73658c3`.
The complete diffs and pre-ASCII qualification drafts remain preserved. The
final ASCII closure was read directly: one two-line recipe branch constructs
opposite native insertion orders; eq11 now selects that recipe; four API lines
explain why static JSON sorting must not erase this coverage. Counts remain
twenty-eight valid comparisons and eight malformed/resource controls.

## Comparator relation and resources

For finite acyclic native JSON within the unchanged scalar/depth bounds, let
\(W\) be U1's sorted-key, ASCII-escaped compact JSON plus LF. When the operation
finishes within its guards, U2's structural relation satisfies

\[
 E_2(a,b)\quad\Longleftrightarrow\quad W(a)=W(b).
\]

This is a Source argument by structural induction, not an executed test:

- Both entire inputs are validated before comparison, including later or
  mismatching branches. Exact native types distinguish Boolean, integer and
  float nodes; finite scalar encodings of those kinds remain distinct. Null,
  Boolean and bounded integer comparisons agree with their canonical text.
- Ordered lists preserve length and element sequence. Objects preserve the
  native Python-sorted key/value sequence used by `json.dumps(sort_keys=True)`.
  The comparator does not normalize, merge or map differently spelled keys.
- Direct string comparison is used only when both strings are ASCII, where
  JSON escaping is injective. Other strings use canonical scalar bytes. This
  deliberately preserves astral-scalar versus literal-surrogate-pair aliases,
  escaped-key collisions and their native-sort ordering relative to BMP keys.
  Floats use canonical scalar bytes, retaining positive/negative zero and
  native numeric-type differences.
- Scalar delimiters, container delimiters, lengths and ordered key/value pairs
  preserve the canonical text relation. No full composite serialization is
  needed merely to compare an equal model.

The scanner admits shared acyclic subobjects, traversing each occurrence as
JSON would, and explicitly rejects an ancestor cycle. The latter is a disclosed
invalid-input behavior change: U1 would reach a depth/resource refusal on such
a nonfinite object graph. It is not a changed accepted finite-JSON domain.

The numeric work/wall caps remain one billion and \(120\) seconds. Full string
lengths, both input scans, iterator visits, bounded scalar encodings and native
sort comparisons are charged. Canonical encoding precharges its byte bound;
encoding and SHA check the meter again after the potentially long native
operation. The successful public path checks after its final model hashes.
Metrics are additive observations with overlapping intervals; U2 work units
are explicitly not interchangeable with U1 units. No equal-cost or speed claim
follows from retaining the same numeric cap.

Local reuse of the initial normalized base-scope hash is sound: `_model`
creates fresh normalized containers and native immutable scalar leaves; the
remaining helpers and expected-model constructors only read that base. They
do not mutate it or install a cross-model cache. Marked/control hashes remain
fresh canonical computations.

## Complete public gate inventory retained

The exact AST/text comparison confirms the original top-level gate helpers
are unchanged: `_model`, `_reference`, `_custody`, `_fixed`, `_query`, `_fields`,
`_nat` and supporting predicates. Outside the Reader implementation, public
`verify` changes only local base-hash reuse, final accounting and added metrics.
In particular all the following remain required:

1. Exact explicit v3 model fields, native integer capacity/units, literal
   marking strings, unique CIDs/points, canonical unary/pair lists and an
   originally unfiltered baseline. Missing markings and assigned zero remain
   different data.
2. A guard fresh from **all** original roots, seed rows, positive support and
   marking-only support, plus complete actual CID/synthesis scope binding.
3. Fixed CID exactly once; its entire t/m contribution moved into the original
   seed, its positive support added to roots, precisely its row removed, and
   every remaining original row retained.
4. Whole raw/C/native object hashes, source/version/model bindings, complete
   event extent and sequence hash, exact C claim/count/terminal status, endpoint
   hashes, entry/restored equality and correct finite exhaustion output. UNKNOWN
   cannot become a negative. POSITIVE retains its external native-proof gate.
5. Exact label-to-binding association and absence of contradictory resolved
   labels; minimal sparse negative assignments; entire marked model equal to
   original plus only the new layer; entire control equal to original plus only
   the same unary list.
6. Actual prior LABEL process metadata association: protocol/source/runtime
   refs, matching phase/PID, native zero, clean invocation/guards/postchecks,
   complete canonical result/log refs and membership of every query binding in
   that prior result. Pure U still explicitly delegates physical authenticity
   and native logical validity to the owned driver/native gates.

Thus no old logical gate is traded for a status/hash shortcut, partial domain,
shortlist, trusted expected answer or forged successful process receipt.

## Fresh qualification and activation integration

K2 retains the twenty actual E/C/T/paired-graph/oracle fixtures, two fresh
ground/RF logical qualifiers and nine original controls. Its original helpers
are unchanged; `run` only adds the independent private-equality qualification.
The new expected relation is computed by standard-library canonical JSON,
without calling U1 or U2 to choose expected answers. Valid mismatches must reach
the named mismatch reason; invalid native inputs cannot masquerade as ordinary
inequality. Signed zero, native kinds, hidden nonfinite values, depth, zero
work, cycles, shared subtrees, scalar Unicode aliases, escaped-key collisions
and native ASCII/Unicode insertion orders are all prospectively represented.
No public positive overlay/provenance object is manufactured in QUALIFY.

The common driver changes only U/K/H module paths and its exact provenance
driver reference. The full finite RF compiler/profile/carrier/model/native
gates, old mandatory markings, solver/semantic checker, scheduling, limits,
phase ordering, prerequisite PID/native-result/log/source custody, isolated
child invocation, capture and first-attempt guards are preserved. The new
root/protocol bytes identify a fresh attempt; no prior proof, prepared universe,
selected set, known failure CID, label packet or learned marking is an input.

H2's new activation controls are behind a real successful public U2 check using
this run's actual prior clean LABEL process, before activated model files are
written. The five IDs and expected reasons match the frozen input. Malformed
mark and wrong-scope cases target explicit early gates. UNKNOWN-as-negative
and corrupt-restoration cases rebuild ordinary object/state/binding/learner
hashes while retaining the authentic original prior provenance; their required
specific failures precede the later custody rejection of those inauthentic
test objects. All full mutant inputs and outputs are saved before assertions.
The zero-work public call must remain UNKNOWN with activation false. Unsupported
actual label profiles are explicitly not applicable, never fabricated.

The controls preserve the real base/overlay/packet objects by copying only
changed paths. They supply no new engine/native proof replay or training label.
Any failed or nonconclusive required gate prevents activation. Evaluation
continues to use complete BASE/MARKS/FILTER inventories and original mandatory
logical marks, with independent native projection/checking of every positive.

## Scope of this closure

Only Source/metadata/AST inspection and this new review note were performed.
No scientific import, helper call, model construction, equality test, engine
run, transition replay, theorem proof input or benchmark was executed/read as
an input by this reviewer. Prior experiment/archive roots remain untouched.
All actual results still require prospective Root freeze and fresh owned
execution. This Source closure claims neither successful activation nor an
arithmetic target proof, performance advantage, RL gain or universal palette.
