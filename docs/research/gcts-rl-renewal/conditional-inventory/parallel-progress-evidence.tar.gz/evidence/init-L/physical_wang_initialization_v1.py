"""UNEXECUTED Source: fixed-layout, translation-only Wang initialization.

The authenticated legacy compiler emits the entire fixed machine palette and
its literal PRE/ACTIVE/PAD/POST initializer tiles.  Only boundary markings
depend on the complete immutable program/public wire, capacities or horizon.
No proof, execution trace, host program decoder or certificate is an input.
Calling any function here requires a fresh separately reviewed Root actual.
"""

VERSION = 'sixteen-band-wang-initialization-v1'
BUILDER_VERSION = 'shared-sixteen-band-literal-builder-v2'
LEGACY_VERSION = 'finite-wang-unknown-certificate-initializer-v1'
RAW = ('B', '^', '0', '1', ':', ',', ';', '|', '!', '#')
WORKSPACE = ('PROGRAM', 'PUBLIC', 'CERTIFICATE', 'HEAP', 'REGISTERS',
             'FRAMES', 'FUNCTION', 'PC', 'DESTINATION', 'LEFT_VALUE',
             'RIGHT_VALUE', 'RETURN_VALUE', 'COUNT', 'TEMPORARY',
             'PARSER_STACK', 'OUTPUT')
ALPHABET = ('L', 'R', 'B', '^', '0', '1', ':', ',', ';', '|', '!', '#',
            '@B', '@^', '@0', '@1', '@:', '@,', '@;', '@|', '@!', '@#',
            'h:PROGRAM', 'h:PUBLIC', 'h:CERTIFICATE', 'h:HEAP',
            'h:REGISTERS', 'h:FRAMES', 'h:FUNCTION', 'h:PC',
            'h:DESTINATION', 'h:LEFT_VALUE', 'h:RIGHT_VALUE',
            'h:RETURN_VALUE', 'h:COUNT', 'h:TEMPORARY',
            'h:PARSER_STACK', 'h:OUTPUT')
HALTS = ('ACCEPT', 'REJECT', 'BOUND', 'MALFORMED')
LIMIT_KEYS = ('work', 'symbols', 'states', 'tiles', 'colors', 'cells', 'dimension')
RECORD_BANDS = (3, 4, 5, 14, 15)
_OWNER = object()


class DeclarationError(ValueError):
    def __init__(self, reason, *, owner=None):
        self.reason = reason
        self.owner = owner
        super().__init__(reason)


class ConstructionLimit(RuntimeError):
    def __init__(self, reason, *, owner=None):
        self.reason = reason
        self.owner = owner
        super().__init__(reason)


def is_owned_declaration(error):
    return type(error) is DeclarationError and error.owner is _OWNER


def is_owned_limit(error):
    return type(error) is ConstructionLimit and error.owner is _OWNER


def _need(ok, reason):
    if not ok:
        raise DeclarationError(reason, owner=_OWNER)


class _Work:
    def __init__(self, check, limits, state):
        self.check = check
        self.original_limits = limits
        self.state = state
        self.work = 0
        self.limits = {}
        _need(callable(check), 'explicit Root check callback required')
        check()
        _need(type(limits) is dict and len(limits) == len(LIMIT_KEYS),
              'exact construction limit dictionary required')
        for key in limits:
            _need(type(key) is str and key in LIMIT_KEYS, 'exact limit keys')
        for key in LIMIT_KEYS:
            value = limits[key]
            _need(type(value) is int and 0 < value <= 400000000,
                  'positive exact bounded construction limits')
            self.limits[key] = value
        self.step()

    def step(self):
        self.work += 1
        self.state['layout_adapter_work'] = self.work
        # A genuine Root fault is checked before a component budget sentinel.
        self.check()
        if self.work > self.limits['work']:
            raise ConstructionLimit('work', owner=_OWNER)

    def bound(self, key, amount):
        self.step()
        if amount > self.limits[key]:
            raise ConstructionLimit(key, owner=_OWNER)


def _integer(value, lower, upper, reason):
    _need(type(value) is int and lower <= value <= upper, reason)
    return value


def _bits(value, work, reason):
    _need(type(value) is str, reason)
    for bit in value:
        work.step()
        _need(bit == '0' or bit == '1', reason)
    # An empty/malformed *semantic* image is not host-filtered here.
    return value


def _machine(table, work, state):
    """Exact literal adapter, not provenance or program acceptance evidence."""
    _need(type(table) is dict, 'complete ordinary builder table required')
    _need(type(table.get('schema')) is str
          and table['schema'] == 'shared-physical-builder-table-v1'
          and type(table.get('version')) is str
          and table['version'] == BUILDER_VERSION, 'exact Builderv2 profile')
    symbols = table.get('alphabet')
    names = table.get('states')
    workspace = table.get('workspace')
    _need(type(symbols) is list and len(symbols) == len(ALPHABET),
          'complete fixed alphabet required')
    for index, symbol in enumerate(symbols):
        work.step()
        _need(type(symbol) is str and symbol == ALPHABET[index],
              'fixed physical alphabet order')
    _need(type(workspace) is list and len(workspace) == 16, 'all sixteen bands')
    for index, label in enumerate(workspace):
        work.step()
        _need(type(label) is str and label == WORKSPACE[index], 'fixed band order')
    _need(type(names) is list and len(names) > 4, 'complete working state names')
    work.bound('symbols', len(symbols))
    work.bound('states', len(names))
    name_copy = []
    seen_names = set()
    for index, name in enumerate(names):
        work.step()
        _need(type(name) is str and name and name not in seen_names,
              'distinct literal state names')
        if index < 4:
            _need(name == HALTS[index], 'exact four halts')
        seen_names.add(name)
        name_copy.append(name)
    _need(type(table.get('blank')) is str and table['blank'] == 'B', 'blank B')
    halts = table.get('halts')
    _need(type(halts) is dict and len(halts) == 4, 'complete halt map')
    for index, name in enumerate(HALTS):
        work.step()
        _need(type(halts.get(name)) is int and halts[name] == index,
              'exact halt identifiers')
    entries = table.get('entries')
    _need(type(entries) is dict and entries, 'complete working entry map')
    entry_copy = []
    for label, q in entries.items():
        work.step()
        _need(type(label) is str and label, 'literal entry name')
        _integer(q, 4, len(names) - 1, 'working entry identifier')
        entry_copy.append((label, q))
    _need('PROGRAM' in entries, 'joined PROGRAM entry required')
    entry_copy.sort()
    symbol_ids = {symbol: index for index, symbol in enumerate(ALPHABET)}
    rows = table.get('delta')
    _need(type(rows) is list, 'whole literal transition list required')
    _need(len(rows) == 38 * (len(names) - 4), 'all working transition slots')
    transitions = []
    state['adapted_transition_rows'] = transitions
    slots = set()
    state['adapted_transition_slots'] = slots
    for row in rows:
        state['active'] = dict(operation='machine-row', raw_row=row)
        work.step()
        _need(type(row) is list and len(row) == 5, 'exact literal transition row')
        q, read, target, write, move = row
        _integer(q, 4, len(names) - 1, 'no outgoing halt rows')
        _integer(target, 0, len(names) - 1, 'literal next state')
        _need(type(read) is str and read in symbol_ids, 'literal read symbol')
        _need(type(write) is str and write in symbol_ids, 'literal write symbol')
        _need(type(move) is int and move in (-1, 0, 1), 'unit literal motion')
        _need((q, read) not in slots, 'deterministic complete physical slots')
        slots.add((q, read))
        made = [q, symbol_ids[read], target, symbol_ids[write], move]
        transitions.append(made)
        state['active']['produced_row'] = made
        work.step()
    undefined = table.get('undefined')
    _need(type(undefined) is list and len(undefined) == 152,
          'all four undefined halt rows')
    missing = set()
    for row in undefined:
        work.step()
        _need(type(row) is list and len(row) == 2, 'literal undefined slot')
        q, read = row
        _integer(q, 0, 3, 'undefined slots only at halts')
        _need(type(read) is str and read in symbol_ids, 'undefined literal symbol')
        _need((q, read) not in missing, 'distinct undefined slots')
        missing.add((q, read))
    machine = dict(alphabet_size=38, state_count=len(names),
                   blank=symbol_ids['B'], initial=entries['PROGRAM'], accepting=0,
                   transitions=transitions)
    snapshot = (tuple(name_copy), tuple(entry_copy),
                tuple(tuple(row) for row in transitions), tuple(sorted(missing)))
    return machine, snapshot


def _layout(program, public, capacities, public_capacity, certificate_capacity,
            machine, steps, work, state):
    """Produce complete fixed cells and a single genuinely unknown interval."""
    _need(type(capacities) is tuple and len(capacities) == 16,
          'exact sixteen payload capacities')
    for capacity in capacities:
        _integer(capacity, 2, work.limits['dimension'], 'positive payload and tail room')
    _integer(public_capacity, len(public) + 1, capacities[1] - 2,
             'public semicolon/padding capacity and positive postcolon tail')
    _integer(certificate_capacity, 1, capacities[2] - 2,
             'free selector includes semicolon; fixed colon and positive tail')
    _integer(steps, 0, work.limits['dimension'], 'exact physical step horizon')
    _need(capacities[0] >= len(program) + 2,
          'PROGRAM immediate colon plus positive postcolon B tail')
    # Two sentinels and sixteen header/left-delimiter/fence triples.
    width = 2 + 48 + sum(capacities)
    work.bound('dimension', width + 2)
    work.bound('dimension', steps + 2)
    work.bound('cells', (width + 2) * (steps + 2))
    symbol_ids = {symbol: index for index, symbol in enumerate(ALPHABET)}
    prefix = []
    suffix = []
    bands = []
    state['fixed_prefix'] = prefix
    state['fixed_suffix'] = suffix
    state['band_rows'] = bands
    position = 0
    destination = prefix

    def emit(symbol, head=False):
        nonlocal position
        cell = (('head', machine['initial'], symbol_ids[symbol]) if head else
                ('plain', symbol_ids[symbol]))
        destination.append(cell)
        state['active'] = dict(operation='fixed-cell', position=position,
                               raw_symbol=symbol, produced_cell=cell)
        position += 1
        work.step()

    emit('L', True)
    free_start = None
    for band, capacity in enumerate(capacities):
        row = dict(band=band, name=WORKSPACE[band], header_cell=position)
        bands.append(row)
        emit('h:' + WORKSPACE[band])
        row['cursor_cell'] = position
        emit('@^')
        row['payload_start'] = position
        row['payload_cells'] = capacity
        if band == 0:
            for bit in program:
                emit(bit)
            row['colon_cell'] = position
            emit(':')
            for unused in range(capacity - len(program) - 1):
                emit('B')
        elif band == 1:
            for bit in public:
                emit(bit)
            emit(';')
            for unused in range(public_capacity - len(public) - 1):
                emit('B')
            row['colon_cell'] = position
            emit(':')
            for unused in range(capacity - public_capacity - 1):
                emit('B')
        elif band == 2:
            free_start = position
            row['selector_start'] = position
            row['selector_cells'] = certificate_capacity
            position += certificate_capacity
            destination = suffix
            row['colon_cell'] = position
            emit(':')
            for unused in range(capacity - certificate_capacity - 1):
                emit('B')
        else:
            emit(':' if band in RECORD_BANDS else '0')
            for unused in range(capacity - 1):
                emit('B')
        row['fence_cell'] = position
        emit('#')
    emit('R')
    _need(position == width and len(prefix) == free_start
          and len(prefix) + certificate_capacity + len(suffix) == width,
          'whole fixed layout accounting')
    return dict(schema='fixed-sixteen-band-boundary-layout-v1',
                fixed_prefix=prefix, fixed_suffix=suffix, band_rows=bands,
                payload_capacities=capacities, tape_width=width,
                certificate_start=free_start, certificate_capacity=certificate_capacity,
                public_wire_capacity=public_capacity, physical_steps=steps,
                program_bits=program, public_postfix_bits=public,
                cursor_symbol='@^', unique_TM_head_cell=0,
                free_language='(0|1)* ; B*',
                projected_wire_ends_at_fixed_colon=True)


def construct_initialized_problem(physical_table, program_bits, public_postfix_bits,
                                  payload_capacities, public_wire_capacity,
                                  certificate_capacity, steps, *, legacy, check, limits):
    """Future-actual constructor, not a certificate validator or witness.

    Root must authenticate the fresh fixed join/lowering and legacy Source,
    exact licensed complete program and three-root public wire, read-only
    callbacks/exclusive owners, common budget and final custody. Shape checks
    here cannot establish that provenance. No free certificate is supplied.
    """
    state = dict(version=VERSION, phase='ENTRY', complete=False, authority=False,
                 owners=dict(physical_table=physical_table, legacy=legacy,
                             program_bits=program_bits, public_bits=public_postfix_bits,
                             payload_capacities=payload_capacities, limits=limits,
                             check=check), active=None, problem=None, layout=None)
    try:
        work = _Work(check, limits, state)
        state['work_owner'] = work
        state['phase'] = 'FIXED_MACHINE_LITERAL_ADAPTER'
        machine, snapshot = _machine(physical_table, work, state)
        state['adapted_machine'] = machine
        program = _bits(program_bits, work, 'PROGRAM literal binary image')
        public = _bits(public_postfix_bits, work, 'PUBLIC literal postfix binary')
        state['phase'] = 'COMPLETE_FIXED_LAYOUT'
        layout = _layout(program, public, payload_capacities, public_wire_capacity,
                         certificate_capacity, machine, steps, work, state)
        state['layout'] = layout
        _need(getattr(legacy, 'VERSION', None) == LEGACY_VERSION,
              'authenticated legacy initializer profile required')
        compiler = legacy.compile_unknown_problem
        _need(callable(compiler), 'complete generic palette compiler required')
        state['legacy_compiler'] = compiler
        state['phase'] = 'WHOLE_GENERIC_PALETTE_AND_PROBLEM'
        # Only the machine+fixed wire enter its palette constructor. Public
        # bits/positions/capacities/time enter only the fixed problem boundary.
        problem = compiler(machine,
            dict(zero=ALPHABET.index('0'), one=ALPHABET.index('1'),
                 terminator=ALPHABET.index(';')),
            layout['fixed_prefix'], certificate_capacity, layout['fixed_suffix'],
            steps, check=check, limits=limits)
        state['problem'] = problem
        state['phase'] = 'DECLARATION_RECONCILIATION'
        unused, again = _machine(physical_table, work, state)
        _need(again == snapshot, 'fixed machine changed during construction')
        _need(legacy.compile_unknown_problem is compiler
              and getattr(legacy, 'VERSION', None) == LEGACY_VERSION,
              'legacy compiler binding changed during construction')
        for key in LIMIT_KEYS:
            work.step()
            _need(type(limits.get(key)) is int and limits[key] == work.limits[key],
                  'construction limits changed')
        _need(len(limits) == len(LIMIT_KEYS), 'construction limit keys changed')
        for key in limits:
            work.step()
            _need(type(key) is str and key in LIMIT_KEYS, 'construction key type changed')
        # Legacy work is charged by the SAME Root callback throughout. These
        # component counters are reported in addition, never as independent
        # permission to exceed the one cumulative Root/physical budget.
        legacy_work = problem.get('attempted_work') if type(problem) is dict else None
        _need(type(legacy_work) is int and legacy_work >= 0, 'literal legacy work receipt')
        work.step()
        if work.work + legacy_work > work.limits['work']:
            raise ConstructionLimit('combined layout and legacy work', owner=_OWNER)
        check()
        state['phase'] = 'COMPLETE_CANDIDATE'
        state['complete'] = True
        state['active'] = None
        return dict(schema='initialized-sixteen-band-wang-problem-candidate-v1',
                    version=VERSION, problem=problem, layout=layout,
                    raw_construction_owners=state,
                    attempted_layout_adapter_work=work.work,
                    attempted_legacy_work=legacy_work,
                    attempted_combined_work=work.work + legacy_work,
                    physical_initialization_Source_complete=True,
                    mathematical_authority=False, full_VM_qualified=False,
                    licensed_image_problem_correspondence_proved=False,
                    resource_fit_proved=False, G1_adopted=False)
    except BaseException as error:
        state['primary_error'] = error
        # Preserve the actual incomplete owner graph/traceback, never decode,
        # reconstruct, size, replay or serialize it while handling a fault.
        try:
            error.wang_initialization_construction_prefix = state
        except BaseException:
            pass
        raise
