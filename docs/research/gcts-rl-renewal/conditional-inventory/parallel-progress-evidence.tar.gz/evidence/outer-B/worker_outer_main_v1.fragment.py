# SOURCE ONLY complete outer entry; no plan/grant is authored by this Source.
_OUTER_WORKER_STATE=None

def _writer_pin(actual,receipt):
    need(receipt['complete']is True and receipt['stdlib_operations']is True and receipt['diagnostic_only']is False,'whole real stdlib output only')
    return dict(path=str(actual/receipt['name']),bytes=receipt['bytes'],sha256=receipt['sha256'])

def _writer_json(state,name,value,cap,kind):
    state['owners'].append(value);raw=canonical(value)+b'\n';state['owners'].append(raw)
    need(len(raw)<=cap,'complete bounded result/header JSON')
    position=0
    def producer():
        nonlocal position
        if position==len(raw):return None
        stop=min(position+65536,len(raw));chunk=raw[position:stop];position=stop;return(chunk,len(chunk))
    state['owners'].append(producer)
    receipt=state['writer'].write_record(name,producer,physical_limit=cap,expanded_limit=cap,kind=kind)
    state['owners'].append(receipt);return _writer_pin(state['s'].actual,receipt)

def _qualification_summary(s,output,evidence):
    counts=dict(compiler_calls=s.started.get('implicit.build_palette_query',0)+s.calls('selector'),search_calls=s.started.get('graph.search',0),verifier_calls=s.oracle_work,oracle_calls=s.oracle_work)
    small=s.rows[:4];large=s.rows[4];graphs=s.rows[5:]
    q=dict(schema='implicit-palette-graph-component-candidate-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',outputs=[output],case_ids=[r['id']for r in s.rows],rows=[dict(id=r['id'],complete=r['complete'])for r in s.rows],diagnostics=s.diagnostics,diagnostic_ids=[r['id']for r in s.diagnostics],profile_metrics=profile_metrics(s),
        batch_diagnostics=[dict(id=g['id'],subject=g['subject'],recipe=g['recipe'],status=g['status'],complete=g['complete'],variants=[dict(id=v['id'],status=v['status'],complete=v['complete'],expected=v['expected'])for v in g['variants']])for g in s.batch_diagnostics],batch_diagnostic_ids=[g['id']for g in s.batch_diagnostics],
        profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=PROFILE_QUERY_CHUNK,small_palettes=len(small),small_mask_queries=sum(len(r['queries'])for r in small),selected_small_witnesses=sum(r['selected_witnesses']for r in small),large_logical_tiles=large['total_count']['count'],graph_cases=len(graphs),graph_domain_checks=sum(r['domain_checks']for r in graphs),rollback_comparisons=sum(o['snapshot']['reason']=='AFTER_ROLLBACK'for r in graphs for o in r['observations']),palette_query_calls=s.calls('implicit'),root_check_calls=s.root_calls,
        root_check_calls_scope='Genuine Root.check cutoff before result/header; every later positive callback shares same400m ceiling. New store units and negative metadata gates are separate.',
        full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,gcts_rl_advantage_established=False,learned_pair_markings=False,trained_RL=False,complete_physical_VM=False,proof_discovery=False,evidence_parent=evidence,**counts)
    return q,counts


def main(plan_path):
    global _OUTER_WORKER_STATE
    state=dict(owners=[plan_path],s=None,writer=None,primary=None,secondaries=[],contract=None,negative_gate_calls=0,negative_summary=None)
    _OUTER_WORKER_STATE=state
    try:
        c=_contract(plan_path,'worker');state['contract']=c;plan=c['plan'];actual=Path(plan['actual_directory'])
        need(actual.is_dir()and actual==actual.resolve(),'runner-owned fresh actual directory')
        consumed=_oj(_op(actual/'CONSUMED.json',(actual/'CONSUMED.json').read_bytes()))
        need(consumed['schema']=='whole-owner-evidence-consumed-v1'and consumed['plan']==c['plan_pin']and consumed['invocation_id']==plan['invocation_id']and consumed['subject_sha256']==c['subject_sha256']and consumed['maximum_worker_launches']==1 and type(consumed['maximum_worker_launches'])is int and consumed['consumed_before_Popen']is True,'fresh consumed exact plan before worker launch')
        need(type(consumed['began_ns'])is int and consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'original absolute epochs')
        # Parent must publish the complete immutable launch receipt before any
        # worker writer census; no concurrent unleased parent metadata writer.
        launch_path=actual/'WORKER_LAUNCH.json';until=min(consumed['work_deadline_ns'],NOW()+1000000000)
        while not launch_path.exists():need(NOW()<until,'bounded parent launch handshake');time.sleep(.001)
        launch=_oj(_op(launch_path,launch_path.read_bytes()))
        need(launch['schema']=='whole-owner-worker-launch-v1'and launch['plan']==c['plan_pin']and launch['invocation_id']==plan['invocation_id']and launch['worker_pid']==os.getpid()and launch['worker_pgid']==os.getpid()and launch['runner_pid']==os.getppid()==consumed['runner_pid'],'exact parent-created new-session worker ownership')
        s=object.__new__(Session);state['s']=s;state['owners'].append(s)
        Session.__init__(s,plan,c['plan_pin'],consumed,actual)
        s.check();need(c['declaration']['component_limits']==COMPONENT_LIMITS and c['declaration']['profile_limits']==PROFILE_LIMITS and c['declaration']['checkpoint_limit']==CHECKPOINT_LIMIT and c['declaration']['profile_query_chunk']==128 and c['declaration']['profile_granularity']==PROFILE_GRANULARITY,'complete original component/private limits and scopes')
        def positive():s.check();return None
        def negative(primary):
            state['owners'].append(primary);state['negative_gate_calls']+=1
            need(NOW()<s.overall_deadline,'metadata-only negative closure before original210')
            need(primary is state['primary']or primary is s.first_fault,'exact retained primary, never public owner classification')
            return None
        def custody(phase,primary):
            if phase=='positive':s.guard();return None
            negative(primary)
            try:
                _complete_custody(c,lambda:negative(primary))
                need(callable_seal(sys.modules[__name__])==s.worker_function_seal,'negative complete worker function custody')
                for role,module in s.modules.items():need(module.__file__==plan['sources'][role]['path']and callable_seal(module)==s.seals[role],'negative module origin/code/default/closure custody')
            except BaseException as error:
                state['owners'].append(error)
                if s.first_fault is None:s.first_fault=error
                raise
            return None
        state['owners'].extend((positive,negative,custody))
        s.load('writer');writer_module=s.modules['writer']
        writer=object.__new__(writer_module.AggregateWriter);state['writer']=writer;state['owners'].append(writer)
        writer_module.AggregateWriter.__init__(writer,str(actual),check=positive,custody=custody,first_fault=lambda:s.first_fault,negative_gate=negative,clock=NOW,work_deadline_ns=s.work_deadline,overall_deadline_ns=s.overall_deadline)
        _writer_json(state,'WORKER_CONSUMED.json',dict(schema='whole-owner-worker-consumed-v1',plan=c['plan_pin'],pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576,'bulk')
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen in scientific worker'))
        state['owners'].append(audit);sys.addaudithook(audit)
        for role in('selector','implicit','graph','linked','cursor','schema'):s.load(role)
        raw_banks=[]
        for item in plan['inputs']:
            raw=_or(item['pin'],134217728);decoded=json.loads(raw);state['owners'].extend((raw,decoded))
            raw_banks.append(dict(role=item['role'],pin=item['pin'],raw_hex=raw.hex(),decoded=decoded))
        inputs=raw_banks[0]['decoded'];batch=raw_banks[1]['decoded'];state['owners'].append(raw_banks)
        need(inputs['schema']=='implicit-palette-inputs-v1'and batch['schema']=='implicit-batch-summary-diagnostics-v1','full original banks')
        case_ids=[r['id']for r in inputs['small_palettes']]+[inputs['large_palette']['id']]+[r['id']for r in inputs['graph_cases']]
        need(case_ids==c['declaration']['case_ids']and len(case_ids)==15 and [r['id']for r in inputs['diagnostics']]==c['declaration']['diagnostic_ids']and len(inputs['diagnostics'])==33 and batch['groups']==c['declaration']['batch_diagnostic_groups']and len(batch['groups'])==28 and sum(len(g['variants'])for g in batch['groups'])==55,'all15/33+28/55 literal population joins')
        manifest=dict(schema='immutable-whole-evidence-manifest-v1',invocation_id=plan['invocation_id'],plan=plan,declaration=c['declaration'],runtime_closure=c['closure'],source_pins=plan['sources'],python=plan['python'],stdlib_pins=c['closure']['stdlib_files'],outer_limits=plan['limits'],component_limits=c['declaration']['component_limits'],profile_limits=c['declaration']['profile_limits'],profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=128,predecessor_worker_sha256='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03',terminal_policy='CANDIDATE_ONLY_REQUIRES_ROOT_EXTERNAL_TERMINAL_ADMISSION',scope='Whole original evidence cohort only. Full subject owner closure/policy pins are bound in plan and runtime_closure. Additional owners are PIN_ONLY, no initialized physical VM or theorem claim.')
        state['owners'].append(manifest)
        evidence=run_owner_candidate(s,inputs,batch,raw_banks,manifest,store_limits=plan['store_limits'],writer=writer,physical_limit=plan['allocations']['canonical_bytes'],expanded_limit=plan['allocations']['canonical_bytes'])
        state['owners'].append(evidence);output=_writer_pin(actual,evidence['output']);s.output_pins.append(output)
        q,counts=_qualification_summary(s,output,{k:v for k,v in evidence.items()if k!='output'})
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        payload=dict(schema='whole-owner-evidence-result-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],subject_closure=plan['subject_closure'],policy=plan['policy'],qualification=q,outputs=[output],denied_events=s.denied,canonical_stored_bytes=output['bytes'],G1_canonical_logical_bytes=output['bytes'],gate_contract=_G1,old_G0_unfolding_charged=False,G1_adopted=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**counts,**zeros)
        result=_writer_json(state,'result.json',payload,plan['allocations']['result_bytes'],'result')
        s.guard();_complete_custody(c,s.check);_linked_final_custody(s)
        logical=output['bytes']+result['bytes'];need(logical<=134217728,'whole stored and proposed G1 logical bytes')
        header=dict(schema='whole-owner-evidence-worker-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=c['plan_pin'],began_ns=s.began,work_deadline_ns=s.work_deadline,overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,result=result,outputs=[output],stored_logical_result_bytes=logical,G1_logical_result_bytes=logical,gate_contract=_G1,old_G0_unfolding_charged=False,G1_adopted=False,outer_metadata_reservation=9437184,finite_encoding_candidate=True,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,root_check_calls_cutoff=s.root_calls,positive_worker_completed_ns=NOW(),writer_ledger=writer.ledger.snapshot(),**zeros)
        _writer_json(state,'worker-receipt.json',header,4194304,'header');s.guard();s.check()
        final=dict(schema='whole-owner-worker-final-stdout-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],root_check_calls=s.root_calls,negative_metadata_gate_calls=state['negative_gate_calls'],completed_ns=NOW(),G1_adopted=False,full_pipeline_qualified=False,mathematical_authority=False)
        state['owners'].append(final);print(json.dumps(final,sort_keys=True),flush=True)
        need(NOW()<s.work_deadline,'whole positive worker body and stdout before180');return 0
    except BaseException as error:
        state['owners'].append(error);s=state['s'];primary=s.first_fault if s is not None and getattr(s,'first_fault',None)is not None else error
        if s is not None and getattr(s,'first_fault',None)is None:
            try:s.first_fault=primary
            except BaseException as secondary:state['secondaries'].append(secondary)
        state['primary']=primary;state['owners'].append(primary)
        writer=state['writer']
        if writer is not None and hasattr(writer,'ledger')and s is not None:
            try:
                raw=canonical(_failure_summary_record(s,primary))+b'\n';state['owners'].append(raw)
                state['negative_summary']=writer.attempt_negative_summary(primary,raw)
            except BaseException as secondary:state['secondaries'].append(secondary)
        # No full-prefix serialization, partial parse/repair, retry, or second
        # output grants. Actual owner graphs remain alive through process exit.
        return 2

if __name__=='__main__':
    need(len(sys.argv)==2,'one new independently reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
