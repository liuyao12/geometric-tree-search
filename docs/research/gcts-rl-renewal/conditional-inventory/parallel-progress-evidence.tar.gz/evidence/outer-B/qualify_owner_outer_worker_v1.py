"""UNEXECUTED whole implicit-palette and finite point-graph calibration worker.

Only fresh reviewed once-run execution may load/call the three components.
No Native/FOL-kernel/Model/Reader/inverse/solver imports or calls. No hostile sandbox
claim: input ownership, Source/callable custody and finite external gates apply.
"""
import time
NOW = time.monotonic_ns
ENTRY_NS = NOW()
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import types

VERSION = 'whole-owner-complete-outer-worker-v1'
SOURCE_ROLES = ('worker','implicit','graph','selector','runner','observer','linked','schema','cursor','writer')
SOURCE_PINS = {}  # Exact whole-subject Source pins are bound by the reviewed plan.

OUTER_LIMITS = dict(work_seconds=180, overall_seconds=210, memory_bytes=1073741824,
    result_bytes=134217728, expanded_bytes=134217728, stdout_bytes=4194304,
    stderr_bytes=4194304, worker_receipt_bytes=4194304,
    runner_metadata_bytes=8388608, observer_bytes=1048576)
SELECTOR_LIMITS=dict(work=400000000,symbols=256,states=100000,tiles=100000,colors=100000,cells=100000,dimension=10000)
IMPLICIT_LIMITS = dict(work=400000000,symbols=256,states=100000,transitions=1000000,integer_bits=4096,data_items=2000000,data_depth=128,string_chars=1000000)
GRAPH_LIMITS = dict(work=400000000,sites=10000,pins=100000,dependencies=40000,frames=10000,choices=1000000,solutions=10000,events=1000000,snapshots=1000000,snapshot_items=2000000,selected_tiles=1000000,oracle_queries=1000000,integer_bits=4096,coordinate_abs=1000000,data_items=2000000,data_depth=128,string_chars=1000000)
COMPONENT_LIMITS={'selector':SELECTOR_LIMITS,'implicit':IMPLICIT_LIMITS,'graph':GRAPH_LIMITS}
PROFILE_LIMITS = dict(IMPLICIT_LIMITS, queries=1000000, receipt_items=2000000)
PROFILE_QUERY_CHUNK = 128
PROFILE_GRANULARITY = 'PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1'
PROFILE_METRIC_KEYS = ('profile_count','profile_attempted_work','profile_preparation_work',
    'profile_query_kernel_work','profile_overhead_work','profile_postpreparation_overhead_work',
    'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
    'attempted_queries','palette_attempted_work_known_total','palette_work_unavailable_count')

CHECKPOINT_LIMIT = 400000000
RESERVE_BYTES = 9437184
FORBIDDEN_EVENTS = ('subprocess.Popen','os.system','os.fork','os.posix_spawn','socket.connect','ctypes.dlopen')


class PolicyFailure(RuntimeError):
    pass


class PlannedForeign(BaseException):
    pass


def need(ok, message):
    if not ok:
        raise PolicyFailure(message)


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf8')


def clone(value):
    return json.loads(canonical(value))



def typed_value(value):
    """Strict typed literal carrier preserves dictionary order and tuple/list.

    Only called inside the once actual. Surrogatepass bytes preserve a lone
    surrogate pair versus an astral character, which JSON escapes can alias.
    """
    def visit(x,depth):
        need(depth<=128,'bounded typed argument guard depth')
        t=type(x)
        if x is None:return ['none']
        if t is bool:return ['bool',x]
        if t is int:return ['int',x]
        if t is float:return ['float_hex',x.hex()]
        if t is str:return ['str_utf8_surrogatepass_hex',x.encode('utf8','surrogatepass').hex()]
        if t is list:return ['list',[visit(y,depth+1)for y in x]]
        if t is tuple:return ['tuple',[visit(y,depth+1)for y in x]]
        need(t is dict,'ordinary typed argument carriers')
        return ['dict',[[visit(k,depth+1),visit(v,depth+1)]for k,v in x.items()]]
    return visit(value,0)


def argument_bytes(value):
    return json.dumps(typed_value(value),ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')


def descriptor(path, raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin, cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'} and type(pin['path'])is str and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and
         len(pin['sha256'])==64,'strict finite raw descriptor')
    path=Path(pin['path'])
    need(path.is_absolute()and path==path.resolve()and path.is_file()and not path.is_symlink(),'canonical regular raw input')
    raw=path.read_bytes();need(descriptor(path,raw)==pin,'complete raw hash/size/path join');return raw


def information(error):
    try:return dict(type=type(error).__name__,message=str(error)[:512])
    except BaseException:return dict(type='UNAVAILABLE',message='error metadata unavailable')


def callable_seal(module):
    """Complete named module/class bindings plus strongly held actual owners.
    The original function/code/default/closure checks remain; descriptor wrappers
    are recorded before any unwrapping. Equal function sets are insufficient.
    """
    rows=[];owners=[module];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name;owners.append(value)
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                seal=_recursive_function_owner_seal(value)
                rows.append((key,'function',id(value),seal.rows));owners.extend(seal.owners)
            elif type(value)is type and value.__module__==module.__name__:
                bases=value.__bases__;mro=value.__mro__;owners.extend((bases,mro));owners.extend(bases);owners.extend(mro)
                rows.append((key,'class',id(value),id(type(value)),id(bases),tuple(id(x)for x in bases),id(mro),tuple(id(x)for x in mro)))
                if id(value)in seen:continue
                seen.add(id(value));owned={}
                for child,item in sorted(vars(value).items()):
                    owners.append(item);kind=type(item);target=None;accessors=()
                    if kind in(staticmethod,classmethod):
                        target=item.__func__;owners.append(target);owned[child]=target
                    elif kind is property:
                        values=[]
                        for label,accessor in(('fget',item.fget),('fset',item.fset),('fdel',item.fdel)):
                            owners.append(accessor);values.append((label,id(accessor)))
                            if accessor is not None:owned[child+'.'+label]=accessor
                        accessors=tuple(values);owners.append(item.__doc__);target=item.__doc__
                    else:target=item;owned[child]=item
                    rows.append((key+'.'+child,'member',id(kind),id(item),id(target),accessors))
                pending.append((key+'.',owned))
    return _NamedOwnerSeal(tuple(sorted(rows)),tuple(owners))


# Future negative-only diagnostic path. No component, check, or Source replay.
FAILURE_SUMMARY_BYTES = 65536
FAILURE_SUMMARY_COUNTER_ROWS = 16
FAILURE_SUMMARY_DIRECTORY_ENTRIES = 64
FAILURE_SUMMARY_UINT_MAX = 9223372036854775807


def _summary_uint(value):
    return value if type(value) is int and 0 <= value <= FAILURE_SUMMARY_UINT_MAX else None


def _summary_text(value, maximum):
    if type(value) is not str:
        return dict(value=None, available=False, truncated=False)
    return dict(value=value[:maximum], available=True, truncated=len(value) > maximum)


def _summary_length(value):
    if type(value) not in (list, dict, tuple):
        return None
    return _summary_uint(len(value))


def _summary_counters(value):
    if type(value) is not dict:
        return dict(rows=[], total_entries=None, truncated=False, available=False)
    rows = []
    for label, count in value.items():
        if len(rows) == FAILURE_SUMMARY_COUNTER_ROWS:
            break
        rows.append([_summary_text(label, 48), _summary_uint(count)])
    return dict(rows=rows, total_entries=_summary_uint(len(value)),
                truncated=len(value) > len(rows), available=True)


def _failure_summary_record(s, primary):
    """Small new ordinary record; never str(error), clone(active), or prefix walk.

    All Session fields are owned plain carriers; external concurrent mutation is
    outside this protocol. Snapshot values are cutoff observations, not terminal
    totals. Failure to construct this record must leave the primary fault intact.
    """
    try:
        cutoff = _summary_uint(NOW())
    except BaseException:
        cutoff = None
    active = s.active if type(s.active) is dict else {}
    active_id = s.active if type(s.active) is str else active.get('id')
    last = s.rows[-1] if type(s.rows) is list and s.rows and type(s.rows[-1]) is dict else {}
    plan = s.plan if type(s.plan) is dict else {}
    plan_pin = s.plan_pin if type(s.plan_pin) is dict else {}
    try:
        fault_type = type(primary).__name__
    except BaseException:
        fault_type = None
    try:
        fault_args = BaseException.args.__get__(primary, BaseException)
        first_argument = fault_args[0] if type(fault_args) is tuple and fault_args else None
    except BaseException:
        first_argument = None
    return dict(
        schema='implicit-worker-failure-summary-v1', status='FAILED_OR_UNFINISHED',
        authority=False, mathematical_authority=False, resource_accepted=False,
        full_pipeline_qualified=False, no_failed_prefix_admission=True,
        invocation_id=_summary_text(plan.get('invocation_id'), 256),
        plan_sha256=_summary_text(plan_pin.get('sha256'), 64),
        stage=_summary_text(s.stage, 64), active_row_id=_summary_text(active_id, 96),
        active_row_stage=_summary_text(active.get('stage'), 64),
        first_available_fault=dict(type=_summary_text(fault_type, 128),
            literal_first_argument=_summary_text(first_argument, 256),
            origin='ROOT_FIRST_FAULT_LATCH' if s.first_fault is not None else 'CAUGHT_EXCEPTION',
            message_evaluated=False),
        snapshot_cutoff_ns=cutoff, clock_available=cutoff is not None,
        work_deadline_ns=_summary_uint(s.work_deadline),
        overall_deadline_ns=_summary_uint(s.overall_deadline),
        root_check_calls=_summary_uint(s.root_calls),
        call_started=_summary_counters(s.started),
        call_completed=_summary_counters(s.completed),
        call_raised=_summary_counters(s.raised),
        completed_case_count=_summary_length(s.rows),
        last_completed_case_id=_summary_text(last.get('id'), 96),
        component_progress_records=_summary_length(s.component_rows),
        diagnostic_records_retained=_summary_length(s.diagnostics),
        retained_call_receipts=_summary_length(s.retained),
        retained_output_descriptors=_summary_length(s.output_pins),
        counter_scope='Snapshot through cutoff; excludes later summary/bulk writes, cleanup and worker exit.',
        coverage='Scalar/capped metadata only; not a full prefix, mathematical outcome, bottleneck or completion certificate.')


def _write_failure_summary(s, summary):
    """One <=64KiB negative-only write, atomic name publication if it finishes.

    The parent may terminate at180s.210s is only the original negative-custody
    upper bound, never a guaranteed grace period. No success gate is consulted
    or changed here. No retries, overwrites, component calls, or Root.check.
    """
    raw = json.dumps(summary, sort_keys=True, separators=(',', ':'),
                     ensure_ascii=True, allow_nan=False).encode('ascii') + b'\n'
    if len(raw) > FAILURE_SUMMARY_BYTES:
        raise ValueError('bounded failure summary exceeded64KiB')
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary outside original210s custody')
    prior = 0
    entries = 0
    with os.scandir(s.actual) as directory:
        for item in directory:
            entries += 1
            if entries > FAILURE_SUMMARY_DIRECTORY_ENTRIES:
                raise ValueError('bounded failure directory census unavailable')
            record = item.stat(follow_symlinks=False)
            if record.st_mode & 0o170000 != 0o100000:
                raise ValueError('failure summary expects exclusive regular-file actual root')
            prior += record.st_size
    if prior + len(raw) + RESERVE_BYTES > OUTER_LIMITS['result_bytes']:
        raise ValueError('failure summary has no original physical budget remaining')
    path = s.actual / 'worker-failure-summary.json'
    temporary = s.actual / 'worker-failure-summary.json.partial'
    if path.exists() or temporary.exists():
        raise ValueError('failure summary cannot overwrite or retry')
    fd = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        output = os.fdopen(fd, 'wb')
    except BaseException:
        try:
            os.close(fd)
        except BaseException:
            pass
        raise
    with output:
        if output.write(raw) != len(raw):
            raise ValueError('failure summary short write')
        output.flush()
        os.fsync(output.fileno())
    if not NOW() < s.overall_deadline:
        raise ValueError('failure summary did not complete before210s custody')
    # Directory exclusive ownership is a prerequisite; no hostile-race seal.
    os.rename(temporary, path)
    completed = NOW()
    if not completed < s.overall_deadline:
        raise ValueError('failure summary publication observed after210s custody')
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                completed_ns=completed,
                diagnostic_only=True, complete_prefix=False)



class Session:
    def __init__(self,plan,plan_pin,consumed,actual):
        self.plan,self.plan_pin,self.actual=plan,plan_pin,actual
        self.began=consumed['began_ns'];self.work_deadline=consumed['work_deadline_ns']
        self.overall_deadline=consumed['overall_deadline_ns']
        self.root_calls=0;self.first_fault=None;self.stage='INTAKE';self.active=None
        self.started={};self.completed={};self.raised={};self.modules={};self.seals={};self.denied=[]
        self.oracle_work=0;self.oracle_work_unavailable=0;self.expanded_subtree_delta=0
        self.rows=[];self.diagnostics=[];self.malformed=[];self.component_rows=[];self.component_diagnostics=[];self.retained=[];self.output_pins=[]
        self.component_limits=clone(COMPONENT_LIMITS)
        self.profile_rows=[];self.profile_lifetimes=[];self.profile_owners=[];self.profile_accounting=[]
        self.profile_query_context=None
        self.palette_work_known_total=0;self.palette_work_unavailable_count=0
        self.palette_call_owners=[]
        self.batch_diagnostics=[];self.batch_diagnostic_progress=[];self.batch_diagnostic_owners=[]
        self.evidence=None
        self.evidence_scope=dict(case_id=None,profile_id=None,group_id=None,variant_id=None,origin='wrapper')
        self.evidence_runtime_owners=[]
        self.worker_function_seal=callable_seal(sys.modules[__name__])

    def check(self):
        self.root_calls+=1
        try:
            need(self.root_calls<=CHECKPOINT_LIMIT,'invocation-total400m Root callback limit')
            need(NOW()<self.work_deadline,'original absolute180s work deadline')
            if self.first_fault is not None:raise self.first_fault
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def policy(self,action):
        try:return action()
        except BaseException as error:
            if self.first_fault is None:self.first_fault=error
            raise

    def guard(self):
        def action():
            self.check()
            for role,pin in self.plan['sources'].items():
                checked(pin)
            need(callable_seal(sys.modules[__name__])==self.worker_function_seal,
                 'whole worker function/code/default/closure-owner binding')
            for role,module in self.modules.items():
                need(module.__file__==self.plan['sources'][role]['path'] and
                     callable_seal(module)==self.seals[role],'owned module origin/function/code/default binding')
            self.check()
        return self.policy(action)

    def fault_gate(self):
        if self.first_fault is not None:raise self.first_fault

    def _original_call(self,role,name,data,action,expected_after=None):
        self.guard();before=argument_bytes(data()if callable(data)else data)
        self.check();key=role+'.'+name;self.started[key]=self.started.get(key,0)+1
        try:
            value=action()
        except BaseException as error:
            self.raised[key]=self.raised.get(key,0)+1
            self.fault_gate()
            self.fault_gate()
            self.guard()
            expected=before if expected_after is None else argument_bytes(expected_after)
            self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments after refusal/fault'))
            raise
        self.fault_gate();self.guard()
        expected=before if expected_after is None else argument_bytes(expected_after)
        self.policy(lambda:need(argument_bytes(data()if callable(data)else data)==expected,'full literal call arguments unchanged'))
        self.completed[key]=self.completed.get(key,0)+1
        return value

    def call(self,role,name,data,action,expected_after=None):
        need(self.evidence is not None,'linked journal installed before subject calls')
        self.evidence_runtime_owners.append((data,action,expected_after))
        args=data() if callable(data) else data
        return _evidence_invoke(self,'CALL',role,name,args,
            lambda:self._original_call(role,name,data,action,expected_after),
            after=lambda:data() if callable(data) else data)

    def load(self,role):
        self.check();pin=self.plan['sources'][role];checked(pin)
        name='implicit_palette_actual_'+role
        spec=importlib.util.spec_from_file_location(name,pin['path'])
        need(spec is not None and spec.loader is not None,'exact Python Source loader')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        need(module.__file__==pin['path'],'exact loaded Source origin')
        self.modules[role]=module;self.seals[role]=callable_seal(module);self.guard()
        return module

    def calls(self,role):
        return sum(value for key,value in self.started.items()if key.startswith(role+'.'))

    def write_json(self,name,value,cap,closure=False):
        path=self.actual/name;temporary=self.actual/(name+'.partial')
        need(not path.exists()and not temporary.exists(),'never overwrite or retry a packet')
        digest=hashlib.sha256();size=0;parts=0
        fd=os.open(str(temporary),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as output:
            for part in json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).iterencode(value):
                raw=part.encode('utf8');size+=len(raw);need(size+1<=cap,'whole JSON packet cap')
                output.write(raw);digest.update(raw);parts+=1
                if parts%1024==0:
                    if closure:need(NOW()<self.overall_deadline,'failure metadata210 deadline')
                    else:self.check()
            output.write(b'\n');digest.update(b'\n');size+=1;output.flush();os.fsync(output.fileno())
        if closure:need(NOW()<self.overall_deadline,'failure metadata completed before210')
        else:self.check()
        os.rename(temporary,path)
        return dict(path=str(path),bytes=size,sha256=digest.hexdigest())



"""Actual-only independent literal oracles; no top-level subject operation."""

def immutable(x):
    if type(x) is list:
        return tuple(immutable(v) for v in x)
    if type(x) is tuple:
        return tuple(immutable(v) for v in x)
    return x


def literal_tiles(s, record):
    old = s.modules['selector']
    args = [record['machine'], record['wire']]
    limits = dict(SELECTOR_LIMITS)
    result = s.call('selector', 'compile_unknown_palette', dict(args=args, limits=limits),
        lambda: old.compile_unknown_palette(*args, check=s.check, limits=limits))
    palette = result['palette']
    tiles = []
    for tile in palette['tiles']:
        s.check()
        edges = tuple(palette['color_constructors'][n] for n in tile['edges_NESW'])
        identity = (tile['kind'], tile['origin'])
        tiles.append(dict(id=identity, kind=tile['kind'], origin=tile['origin'],
            edges_NESW=edges, t=[[[0, 0], 1]],
            m=[[[0, -1], 'edge', edges[0]], [[1, 0], 'edge', edges[1]],
               [[0, 1], 'edge', edges[2]], [[-1, 0], 'edge', edges[3]]]))
    need(len({v['id'] for v in tiles}) == len(tiles), 'distinct legacy semantic inventory identities')
    return palette, tiles


def tile_key(tile):
    need(type(tile) is dict and set(tile) == {'id','kind','origin','edges_NESW','t','m'},
         'exact semantic tile fields')
    need(tile['id'] == (tile['kind'], tile['origin']), 'semantic inventory identity')
    need(type(tile['edges_NESW']) is tuple and len(tile['edges_NESW']) == 4,
         'four immutable exact edge values')
    n,e,b,w = tile['edges_NESW']
    need(argument_bytes(tile['t']) == argument_bytes([[[0,0],1]]) and argument_bytes(tile['m']) == argument_bytes([
        [[0,-1],'edge',n], [[1,0],'edge',e], [[0,1],'edge',b], [[-1,0],'edge',w]]),
        'exact positive center and complete assigned point markings')
    return (tile['id'], tile['edges_NESW'])


def tile_bytes(tile):
    # Tile field insertion order is not inventory semantics. Full value types
    # and every declared field remain compared; code/typed-value order rules
    # from the earlier codec experiment are not silently applied to this API.
    return argument_bytes({k:tile[k]for k in sorted(tile)})


def account_palette_work(s,amount):
    """One cost observation, never an invocation or a callback.

    Missing constructor prefixes are unavailable, never zero. On an active
    failure this helper cannot replace the primary. Invalid accounting still
    independently latches a Root policy fault for the later fault gate.
    """
    try:
        if amount is None:
            s.palette_work_unavailable_count += 1
        else:
            need(type(amount)is int and amount>=0,'exact available palette private work')
            s.palette_work_known_total += amount
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
        # This function is metadata-only. The independent fault latch is
        # authoritative and is checked before any expected-fault admission.
    return None


def record_profile_accounting(s,profile_id,*,receipt=None,prefix=None,lifetime=None):
    """Retain one known/unknown cost row for one complete attempted scope.

    Call exactly once, including diagnostics. This is not an extra allowance;
    it observes already attempted cumulative work. The helper itself performs
    no check, Source replay, component operation or warmup. Its failure latches
    independently, so an expected diagnostic cannot launder missing accounting.
    """
    try:
        need(type(profile_id)is str,'literal profile accounting id')
        need(not any(row['id']==profile_id for row in s.profile_accounting),
             'one metric observation per attempted profile')
        source=receipt if type(receipt)is dict else prefix if type(prefix)is dict else {}
        live=lifetime if type(lifetime)is dict else {}
        amount=source.get('attempted_work')
        if amount is None and live.get('work')is not None:
            amount=live['work'].work
        preparation=source.get('preparation_attempted_work',live.get('preparation_work'))
        kernel=source.get('query_attempted_work',live.get('query_work'))
        counters={}
        for key in('attempted_queries','produced_receipt_count',
                   'preimage_completed_count','delivered_receipt_count'):
            value=source.get(key,live.get(key))
            need(value is None or type(value)is int and value>=0,
                 'exact available profile lifetime counter')
            counters[key]=value
        for value in(amount,preparation,kernel):
            need(value is None or type(value)is int and value>=0,
                 'exact available cumulative profile work')
        overhead=None if amount is None or kernel is None else amount-kernel
        post=None if overhead is None or preparation is None else overhead-preparation
        need(overhead is None or overhead>=0,'nonnegative total profile overhead')
        need(post is None or post>=0,'nonnegative postpreparation profile overhead')
        row=dict(id=profile_id,attempted_work=amount,preparation_work=preparation,
            query_kernel_work=kernel,overhead_work=overhead,
            postpreparation_overhead_work=post,private_work_available=amount is not None,
            complete=type(receipt)is dict,**counters)
        s.profile_accounting.append(row)
        account_palette_work(s,amount)
    except BaseException as accounting_error:
        if s.first_fault is None:s.first_fault=accounting_error
    return None


def profile_metrics(s):
    """Twelve exact fields. Work sums cover available observations only.

    Cost-unavailable observations remain explicitly counted; numeric sums do
    not assert private-work completeness. Never add per-query costs to totals.
    """
    # Expected-failed diagnostic profiles are retained and charged in the
    # all-palette known/unavailable totals below, but are not completed profiles.
    # Their different production/copy/delivery populations remain per-row data.
    rows=[row for row in s.profile_accounting if row['complete']]
    def total(key):
        result=0
        for row in rows:
            value=row[key]
            if value is not None:result+=value
        return result
    return dict(profile_count=len(rows),
        profile_attempted_work=total('attempted_work'),
        profile_preparation_work=total('preparation_work'),
        profile_query_kernel_work=total('query_kernel_work'),
        profile_overhead_work=total('overhead_work'),
        profile_postpreparation_overhead_work=total('postpreparation_overhead_work'),
        produced_receipt_count=total('produced_receipt_count'),
        preimage_completed_count=total('preimage_completed_count'),
        delivered_receipt_count=total('delivered_receipt_count'),
        attempted_queries=total('attempted_queries'),
        palette_attempted_work_known_total=s.palette_work_known_total,
        palette_work_unavailable_count=s.palette_work_unavailable_count)


def palette_call(s,name,args,limits=None,callback=None):
    """Unchanged standalone path, retained for builds/description/33 old tests."""
    bound=dict(IMPLICIT_LIMITS if limits is None else limits)
    callback=s.check if callback is None else callback
    owner=dict(operation=name,args=args,limits=bound,callback=callback,
               receipt=None,error=None)
    s.palette_call_owners.append(owner)
    try:
        receipt=s.call('implicit',name,dict(args=args,limits=bound),
            lambda:getattr(s.modules['implicit'],name)(*args,check=callback,limits=bound))
    except BaseException as error:
        owner['error']=error
        prefix=getattr(error,'implicit_palette_prefix',None)
        try:
            amount=prefix.get('attempted_work')if type(prefix)is dict else None
            account_palette_work(s,amount)
            s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
                completed=False,error=information(error),prefix=prefix))
        except BaseException as retention_error:
            if s.first_fault is None:s.first_fault=retention_error
        raise
    owner['receipt']=receipt
    account_palette_work(s,receipt.get('attempted_work')if type(receipt)is dict else None)
    s.fault_gate()
    s.retained.append(dict(role='implicit',operation=name,args=args,limits=bound,
        completed=True,receipt=receipt))
    return receipt


def function_owner_seal(value):
    return _recursive_function_owner_seal(value)


def bind_profile_query(s,query):
    context=s.profile_query_context
    need(type(context)is dict and context['query']is None,'one synchronous scoped query owner')
    context['query']=query
    context['query_seal']=function_owner_seal(query)
    context['owners'].append(query)


def _exact_implicit_limits(limits):
    return(type(limits)is dict and len(limits)==len(IMPLICIT_LIMITS) and
           all(type(key)is str and key in IMPLICIT_LIMITS and type(value)is int and
               value==IMPLICIT_LIMITS[key]for key,value in limits.items()))


def profile_query(s,name,args,limits=None,callback=None):
    """Local query guard inside a fully custodied profile, no file rehash.

    The active dispatcher is replaced by the exact L charged_check for every
    dynamic graph request, so every internal B tick also charges L's work.
    Restoration occurs on both return and fault; descriptor/profile preparation
    and reconciliation use the Root check instead of a stale graph callback.
    """
    context=s.profile_query_context
    need(type(context)is dict and context['query']is not None,'query has a live Root profile owner')
    # L owns an immutable descriptor copy; require the entire strict typed value.
    # Keep that copy alive through final custody, including a refused query.
    context['owners'].append(args)
    s.policy(lambda:need(args[0]is context['descriptor'] or
        argument_bytes(args[0])==argument_bytes(context['descriptor']),
        'full strict typed descriptor value within profile'))
    if limits is not None:need(_exact_implicit_limits(limits),'exact unchanged graph oracle limits')
    need(name in('count_query','select_query'),'declared local query operation')
    request=('count',args[1])if name=='count_query'else('select',args[1],args[2])
    before=argument_bytes(request)
    previous=context['check']
    selected_check=s.check if callback is None else callback
    need(callable(selected_check),'exact charged dynamic callback')
    # Keep the callback and every argument owner alive through final custody.
    context['owners'].append((selected_check,args,request,before))
    context['requests'].append(request)
    context['check']=selected_check
    key='implicit.profile_'+name
    s.started[key]=s.started.get(key,0)+1
    try:
        need(function_owner_seal(context['query'])==context['query_seal'],
             'scoped query function/code/default/closure owner unchanged')
        receipt=context['query'](request)
    except BaseException:
        s.raised[key]=s.raised.get(key,0)+1
        # Root independent faults dominate an otherwise expected graph fault.
        s.fault_gate()
        raise
    finally:
        context['check']=previous
    s.fault_gate()
    s.policy(lambda:need(argument_bytes(request)==before,'full local literal request unchanged'))
    need(function_owner_seal(context['query'])==context['query_seal'],
         'scoped query binding unchanged after delivery')
    s.completed[key]=s.completed.get(key,0)+1
    return receipt


def _ordinary_profile_lifetime(state):
    """One complete ordinary projection; raw owner aggregate remains retained."""
    keys=('schema','descriptor','limits','active','busy','active_query','attempted_queries',
          'produced_receipt_count','preimage_completed_count','delivered_receipt_count',
          'receipts','requests','expected_receipts','query_work','receipt_items',
          'preparation_work','stage','failed_stage','custody_entry_attempted',
          'custody_entry_completed','custody_exit_attempted','custody_exit_completed',
          'custody_cleanup_error','registered','authority')
    ordinary={key:state[key]for key in keys}
    work=state['work']
    ordinary['attempted_work']=None if work is None else work.work
    ordinary['data_items']=None if work is None else work.items
    fault=state['query_fault']
    ordinary['query_fault']=None if fault is None else information(fault)
    ordinary['body_result']=state['body_result']
    return ordinary


def profile_call(s,profile_id,desc,guard_data,body):
    """One Root complete Source/closure/argument boundary for one profile."""
    need(s.profile_query_context is None,'no nested or warm profile state')
    bound=dict(PROFILE_LIMITS)
    data=dict(descriptor=desc,data=guard_data,limits=bound,
              granularity=PROFILE_GRANULARITY)
    before=argument_bytes(data)
    owner_seal=function_owner_seal(body)
    registered=[]
    context=dict(id=profile_id,descriptor=desc,query=None,query_seal=None,
                 check=s.check,owners=[body,data,before],requests=[])
    s.profile_query_context=context
    s.profile_owners.append(context)
    def dispatcher():
        context['check']()
    def custody(which):
        def verify():
            need(which in('entry','exit'),'exact profile custody endpoint')
            s.guard()
            need(argument_bytes(data)==before,'full profile descriptor/declared input/limits unchanged')
            need(function_owner_seal(body)==owner_seal,
                 'full profile body function/code/default/closure owner unchanged')
            if context['query']is not None:
                need(function_owner_seal(context['query'])==context['query_seal'],
                     'full scoped query function/code/default/closure owner unchanged')
            s.check()
        s.policy(verify)
        return None
    def retain(state):
        need(not registered,'one complete raw profile lifetime registration')
        registered.append(state)
        s.profile_lifetimes.append(state)
        context['owners'].append(state)
        return None
    # Keep callbacks and their captured owners alive, including fault paths.
    event_hook=_profile_evidence(s,profile_id,'wrapper',dict(descriptor=desc,limits=bound,guard_data=guard_data))
    context['owners'].extend((dispatcher,custody,retain,registered,event_hook))
    key='implicit.with_profile';s.started[key]=s.started.get(key,0)+1
    try:
        receipt=s.modules['implicit'].with_profile(desc,body,check=dispatcher,
            limits=bound,custody=custody,retain=retain,evidence=event_hook)
    except BaseException as primary:
        context['owners'].append(primary)
        s.raised[key]=s.raised.get(key,0)+1
        prefix=getattr(primary,'implicit_palette_batch_prefix',None)
        lifetime=registered[0]if registered else None
        record_profile_accounting(s,profile_id,prefix=prefix,lifetime=lifetime)
        # Best-effort ordinary projection cannot mask the exact primary. The
        # raw lifetime remains in s.profile_lifetimes even if projection fails.
        try:
            s.profile_rows.append(dict(id=profile_id,complete=False,prefix=prefix,
                lifetime=None if lifetime is None else _ordinary_profile_lifetime(lifetime)))
        except BaseException as projection_error:
            if s.first_fault is None:s.first_fault=projection_error
        s.fault_gate()
        raise
    finally:
        s.profile_query_context=None
    record_profile_accounting(s,profile_id,receipt=receipt,lifetime=registered[0]if registered else None)
    s.fault_gate()
    need(len(registered)==1 and receipt['profile_closed']is True,'complete registered closed profile')
    count=receipt['attempted_queries']
    need(count==receipt['produced_receipt_count']==receipt['preimage_completed_count']==
         receipt['delivered_receipt_count']==len(receipt['receipts'])==
         len(receipt['attempted_requests'])==len(receipt['exact_receipt_preimages'])==
         len(context['requests']),'normal profile exact request/production/preimage/delivery populations')
    need(receipt['active_query']is None,'no active query at normal profile close')
    need(receipt['body_result']is None,'caller-owned profile consumer outputs kept separately')
    ordinary=_ordinary_profile_lifetime(registered[0])
    # The one ordinary lifetime stores every full raw receipt/request/preimage.
    # The component return repeats these same sequences. Store only its other
    # fields and explicit complete field bindings; retain the actual original
    # return object in owners and conservatively charge reconstructed duplicates
    # to the unchanged expanded-byte gate. No hash substitutes for any value.
    duplicate_keys=('receipts','attempted_requests','exact_receipt_preimages','body_result')
    metadata={key:value for key,value in receipt.items()if key not in duplicate_keys}
    bindings=dict(receipts=dict(field='receipts',container='list'),
        attempted_requests=dict(field='requests',container='tuple'),
        exact_receipt_preimages=dict(field='expected_receipts',container='tuple'),
        body_result=dict(field='body_result',container='identity'))
    row=dict(id=profile_id,complete=True,lifetime=ordinary,
        profile_return_metadata=metadata,profile_return_bindings=bindings,
        reconstruction_scope='Full return reconstructed from the same row lifetime; conservative expanded-byte bound.')
    full_row=dict(id=profile_id,complete=True,receipt=receipt,lifetime=ordinary)
    s.check()
    raw_full=canonical(full_row)
    raw_compact=canonical(row)
    s.check()
    delta=max(0,len(raw_full)-len(raw_compact))
    row['expanded_reconstruction_charge_bytes']=delta
    s.expanded_subtree_delta+=delta
    context['owners'].extend((receipt,ordinary,row))
    s.profile_rows.append(row)
    s.completed[key]=s.completed.get(key,0)+1
    return receipt['body_result']


def final_profile_custody(s):
    """Retain originals through final custody; no second ordinary projection."""
    s.guard()
    need(s.profile_query_context is None,'all normal profile dispatchers released')
    for context in s.profile_owners:
        s.check()
        need(type(context)is dict and context['check'].__self__ is s,
             'closed profile restored Root dispatcher owner')
        if context['query']is not None:
            need(function_owner_seal(context['query'])==context['query_seal'],
                 'scoped query owner retained through final custody')
    for row in s.profile_accounting:
        s.check()
        need(type(row['private_work_available'])is bool,'explicit private-cost availability')
    s.fault_gate()


def _original_qualify_small_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LITERAL_BUILD',input=record,queries=[])
    s.component_rows.append(progress)
    palette,tiles=literal_tiles(s,record)
    progress.update(legacy_palette=palette,semantic_tiles=tiles,stage='IMPLICIT_BUILD')
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    buckets={}
    keys={tile_key(tile):tile for tile in tiles}
    for tile in tiles:
        for bits in range(16):
            s.check()
            mask=tuple(tile['edges_NESW'][i]if bits&(1<<i)else None for i in range(4))
            buckets.setdefault(mask,[]).append(tile)
    zero_masks=[
        (0,None,None,None),
        (('not_a_palette_color',),None,None,None),
        (('cell',('plain',0)),('pair',('plain',1),('plain',0)),None,None),
        (('cell',('plain',0)),None,None,('pair',('plain',0),('plain',1))),
        (('cell',('wall',)),None,None,None),
        (('cell',('head',record['machine']['accepting'],0)),
         ('pair',('head',record['machine']['accepting'],0),('plain',0)),
         ('cell',('plain',0)),('pair',('plain',0),('head',record['machine']['accepting'],0))),
        (('cell',('head',0,0)),('pair',('head',0,0),('head',0,0)),
         None,('pair',('head',0,0),('head',0,0))),
    ]
    for mask in zero_masks:
        s.check()
        expected=[tile for tile in tiles if all(value is None or value==tile['edges_NESW'][i]
                                              for i,value in enumerate(mask))]
        need(not expected,'declared empty cross-splice really has no literal tile')
        buckets.setdefault(mask,[])
    progress.update(descriptor=desc,build=build,description=description,stage='QUERIES')
    queries=progress['queries']
    # Construct the entire original ordered request stream from independent
    # literal bucket populations. Counts never choose how many ranks to test.
    # Count then every rank per bucket, preserving original insertion order.
    pending=[]
    answers=[]
    scope_ordinal=0
    def flush():
        nonlocal scope_ordinal
        need(pending,'nonempty deterministic profile chunk')
        requests=tuple(pending)
        pending.clear()
        scope_ordinal+=1
        values=[]
        def body(query):
            bind_profile_query(s,query)
            for request in requests:
                s.check()
                if request[0]=='count':
                    value=profile_query(s,'count_query',[desc,request[1]])
                else:
                    value=profile_query(s,'select_query',[desc,request[1],request[2]])
                values.append(value)
            return None
        profile_call(s,record['id']+'-small-profile-'+str(scope_ordinal),desc,
            dict(record=record,ordered_requests=requests),body)
        need(len(values)==len(requests),'whole deterministic request chunk delivered')
        answers.extend(zip(requests,values))
    for mask,expected in buckets.items():
        s.check()
        pending.append(('count',mask))
        if len(pending)==PROFILE_QUERY_CHUNK:flush()
        for rank in range(len(expected)):
            s.check()
            pending.append(('select',mask,rank))
            if len(pending)==PROFILE_QUERY_CHUNK:flush()
    if pending:flush()
    # Verify all results only after retaining the complete unchanged stream.
    position=0;witnesses=0
    for query_index,(mask,expected)in enumerate(buckets.items()):
        s.check()
        request,q=answers[position];position+=1
        need(request==('count',mask)and type(q['count'])is int and q['count']==len(expected),
             'complete implicit degree equals independent literal projection bucket')
        found=[];costs=[]
        for rank in range(len(expected)):
            s.check()
            request,selected=answers[position];position+=1
            need(request==('select',mask,rank),'all independent ranks retain original query order')
            tile=selected['tile'];key=tile_key(tile)
            need(key in keys and tile_bytes(tile)==tile_bytes(keys[key]),
                 'full selected point tile equals independent original literal tile')
            need(all(value is None or tile['edges_NESW'][i]==value for i,value in enumerate(mask)),
                 'selected rank matches all assigned values together')
            found.append(tile);costs.append(selected['attempted_work']);witnesses+=1
        need(len({tile_key(tile)for tile in found})==len(found)and
             {tile_key(tile)for tile in found}=={tile_key(tile)for tile in expected},
             'every query unranking is a distinct exhaustive bijection')
        queries.append(dict(index=query_index,mask=mask,count=q['count'],
            count_attempted_work=q['attempted_work'],select_attempted_work=costs,
            selected_tiles=found,complete=True))
    need(position==len(answers),'entire unchanged query stream verified')
    need(witnesses==16*len(tiles),'exact sixteen full-inventory witness populations')
    if not hasattr(s,'literal_models'):s.literal_models={}
    s.literal_models[record['id']]=(palette,tiles,desc,buckets)
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,
        build=build,description=description,legacy_palette=palette,semantic_tiles=tiles,
        queries=queries,nonempty_mask_queries=sum(bool(value['count'])for value in queries),
        zero_mask_queries=sum(not value['count']for value in queries),
        selected_witnesses=witnesses,full_literal_tile_count=len(tiles),
        scope='All nonempty masks, all independent ranks, plus declared empty cross-splices; deterministic128-request custody scopes, not the full Cartesian cube of colors.')


def independent_membership(s, tile, record):
    """Direct old local-rule definition, deliberately not the factorized generator."""
    tile_key(tile)
    machine=record['machine'];b=machine['alphabet_size'];Q=machine['state_count']
    kind=tile['kind'];origin=tile['origin'];edges=tile['edges_NESW']
    # Large selected witnesses are joined to a focused independently specified
    # literal template in the actual input bank; step outputs use radius-one rule.
    if kind=='step':
        need(type(origin)is tuple and len(origin)==3,'complete step triple')
        l,c,r=origin
        def cell(v,wall=False):
            if wall and v==('wall',):return
            need(type(v)is tuple and v,'literal cell')
            if v[0]=='plain':need(len(v)==2 and type(v[1])is int and 0<=v[1]<b,'plain cell')
            else:need(v[0]=='head' and len(v)==3 and type(v[1])is int and 0<=v[1]<Q and type(v[2])is int and 0<=v[2]<b,'head cell')
        cell(l,True);cell(c);cell(r,True)
        heads=[(i,v)for i,v in enumerate(origin)if v[0]=='head']
        need(len(heads)<=1,'no multiple heads in a step tile')
        output=c
        if heads:
            position,head=heads[0]
            rows=[v for v in machine['transitions']if v[0]==head[1] and v[1]==head[2]]
            for unused in machine['transitions']:s.check()
            need(len(rows)==1,'large step uses a declared unique transition')
            _,_,n,w,d=rows[0]
            if position==1:
                need(not(d==-1 and l==('wall',))and not(d==1 and r==('wall',)), 'no crossed wall')
                output=('head',n,w)if d==0 else('plain',w)
            elif(position==0 and d==1)or(position==2 and d==-1):output=('head',n,c[1])
        need(edges==(('cell',c),('pair',c,r),('cell',output),('pair',l,c)),
             'independent complete radius-one step witness')
    else:
        need(type(origin)is tuple,'immutable non-step origin')
        def natural(v,n):
            need(type(v)is int and 0<=v<n,'strict bounded non-step index')
            return v
        def phase(pair):
            need(pair in(('PRE','PRE'),('PAD','POST'),('POST','POST')),'fixed phase pair')
        def h(p,f):return ('init_horizontal',p,f)
        if kind=='collect_plain':
            need(len(origin)==2,'plain collector origin');a,f=origin;natural(a,b);natural(f,2)
            wanted=(('cell',('plain',a)),('seen',f),('stop',),('seen',f))
        elif kind=='collect_accept':
            need(len(origin)==2,'accept collector origin');q,a=origin;natural(q,Q);natural(a,b)
            need(q==machine['accepting'],'accept-only collector')
            wanted=(('cell',('head',q,a)),('seen',1),('stop',),('seen',0))
        elif kind in('left_step_frame','right_step_frame'):
            need(len(origin)==1,'step frame origin');v=origin[0]
            need(type(v)is tuple and v and v[0]in('plain','head'),'frame complete cell')
            if v[0]=='plain':need(len(v)==2,'frame plain arity');natural(v[1],b)
            else:need(len(v)==3,'frame head arity');natural(v[1],Q);natural(v[2],b)
            wanted=((('side','left','run'),('pair',('wall',),v),('side','left','run'),('exterior','left'))
                if kind=='left_step_frame' else
                (('side','right','run'),('exterior','right'),('side','right','run'),('pair',v,('wall',))))
        elif kind=='left_accept_frame':
            need(origin==(),'left closing frame origin')
            wanted=(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))
        elif kind=='right_accept_frame':
            need(origin==(),'right closing frame origin')
            wanted=(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))
        elif kind=='init_fixed_plain':
            need(len(origin)==4,'fixed plain origin');p,n,a,f=origin;phase((p,n));natural(a,b);natural(f,2)
            wanted=(('init_north','plain',a),h(n,f),('cell',('plain',a)),h(p,f))
        elif kind=='init_fixed_head':
            need(len(origin)==3,'fixed head origin');p,n,a=origin;phase((p,n));natural(a,b)
            wanted=(('init_north','head',machine['initial'],a),h(n,1),('cell',('head',machine['initial'],a)),h(p,0))
        elif kind=='init_free_bit':
            need(len(origin)==3,'bit origin');p,a,f=origin;natural(f,2)
            need(p in('PRE','ACTIVE')and a in(record['wire']['zero'],record['wire']['one']),'free bit phases/symbol')
            wanted=(('init_north','free'),h('ACTIVE',f),('cell',('plain',a)),h(p,f))
        elif kind=='init_free_terminator':
            need(len(origin)==2,'terminator origin');p,f=origin;natural(f,2);need(p in('PRE','ACTIVE'),'terminator phase')
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',record['wire']['terminator'])),h(p,f))
        elif kind=='init_free_padding':
            need(len(origin)==1,'padding origin');f=origin[0];natural(f,2)
            wanted=(('init_north','free'),h('PAD',f),('cell',('plain',machine['blank'])),h('PAD',f))
        elif kind=='init_left_frame':
            need(origin==(),'left initializer frame origin')
            wanted=(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))
        else:
            need(kind=='init_right_frame'and origin==(),'right initializer frame origin')
            wanted=(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))
        need(edges==wanted,'independent complete non-step constructor witness')
    return True


def reference_tile(kind,origin,edges):
    n,e,b,w=edges
    return dict(id=(kind,origin),kind=kind,origin=origin,edges_NESW=edges,
        t=[[[0,0],1]],m=[[[0,-1],'edge',n],[[1,0],'edge',e],
                        [[0,1],'edge',b],[[-1,0],'edge',w]])


def _original_qualify_large_palette(s,record):
    s.active=record['id']
    progress=dict(id=record['id'],stage='LARGE_BUILD',input=record,samples=[],focused=[])
    s.component_rows.append(progress)
    build=palette_call(s,'build_palette_query',[record['machine'],record['wire']])
    desc=build['descriptor']
    description=palette_call(s,'describe',[desc])
    machine=record['machine'];wire=record['wire'];limits=dict(SELECTOR_LIMITS)
    legacy=s.call('selector','describe_unknown_palette_cardinality',
        dict(machine=machine,wire=wire,limits=limits),
        lambda:s.modules['selector'].describe_unknown_palette_cardinality(machine,wire,
            check=s.check,limits=limits))
    total_holder=[]
    def body(query):
        bind_profile_query(s,query)
        total=profile_query(s,'count_query',[desc,(None,None,None,None)])
        need(total['count']==legacy['counts']['total_tiles'] and total['count']>134217728,
             'complete implicit count agrees exact old Source formula; not a literal-byte fit')
        samples=progress['samples'];progress.update(descriptor=desc,build=build,description=description,legacy_cardinality=legacy,total=total,stage='LARGE_WITNESSES')
        for rank in(0,total['count']//2,total['count']-1):
            selected=profile_query(s,'select_query',[desc,(None,None,None,None),rank])
            independent_membership(s,selected['tile'],record)
            samples.append(dict(mask=(None,None,None,None),rank=rank,receipt=selected))
        focused=progress['focused']
        plain=('plain',0);wall=('wall',)
        # Every disjoint step family, including both allowable wall sides.
        triples=[(plain,plain,plain),(('head',0,0),plain,wall),
                 (wall,plain,('head',2,0)),(plain,('head',0,0),wall),
                 (wall,('head',1,0),wall),(wall,('head',2,0),plain)]
        for i,(l,c,r)in enumerate(triples):
            mask=(('cell',c),('pair',c,r),None,('pair',l,c))
            count=profile_query(s,'count_query',[desc,mask]);need(count['count']==1,'one complete step identity')
            selected=profile_query(s,'select_query',[desc,mask,0])
            need(selected['tile']['id']==('step',(l,c,r)),'focused disjoint step identity')
            independent_membership(s,selected['tile'],record)
            focused.append(dict(family='step-family-'+str(i),mask=mask,count_receipt=count,selected=selected))
        def h(p,f):return ('init_horizontal',p,f)
        initial=machine['initial'];accepting=machine['accepting'];a=machine['alphabet_size']-1
        cell=('head',accepting,a)
        recipes=[
            ('collect_plain',(a,0),(('cell',('plain',a)),('seen',0),('stop',),('seen',0))),
            ('collect_accept',(accepting,a),(('cell',cell),('seen',1),('stop',),('seen',0))),
            ('left_step_frame',(cell,),(('side','left','run'),('pair',wall,cell),('side','left','run'),('exterior','left'))),
            ('right_step_frame',(cell,),(('side','right','run'),('exterior','right'),('side','right','run'),('pair',cell,wall))),
            ('left_accept_frame',(),(('side','left','run'),('seen',0),('side','left','done'),('exterior','left'))),
            ('right_accept_frame',(),(('side','right','run'),('exterior','right'),('side','right','done'),('seen',1))),
            ('init_fixed_plain',('POST','POST',a,1),(('init_north','plain',a),h('POST',1),('cell',('plain',a)),h('POST',1))),
            ('init_fixed_head',('PAD','POST',a),(('init_north','head',initial,a),h('POST',1),('cell',('head',initial,a)),h('PAD',0))),
            ('init_free_bit',('ACTIVE',wire['one'],1),(('init_north','free'),h('ACTIVE',1),('cell',('plain',wire['one'])),h('ACTIVE',1))),
            ('init_free_terminator',('PRE',0),(('init_north','free'),h('PAD',0),('cell',('plain',wire['terminator'])),h('PRE',0))),
            ('init_free_padding',(1,),(('init_north','free'),h('PAD',1),('cell',('plain',machine['blank'])),h('PAD',1))),
            ('init_left_frame',(),(('init_north','frame','left'),h('PRE',0),('side','left','run'),('exterior','left'))),
            ('init_right_frame',(),(('init_north','frame','right'),('exterior','right'),('side','right','run'),h('POST',1))),
        ]
        for kind,origin,edges in recipes:
            expected=reference_tile(kind,origin,edges);independent_membership(s,expected,record)
            count=profile_query(s,'count_query',[desc,edges]);need(count['count']==1,'unique full non-step edge mask')
            selected=profile_query(s,'select_query',[desc,edges,0])
            need(tile_bytes(selected['tile'])==tile_bytes(expected),'complete independently specified non-step tile')
            focused.append(dict(family=kind,mask=edges,count_receipt=count,selected=selected))
        total_holder.append(total)
        return None
    profile_call(s,record['id']+'-large-profile',desc,
        dict(record=record,descriptor=desc),body)
    need(len(total_holder)==1,'one complete large total')
    total=total_holder[0];samples=progress['samples'];focused=progress['focused']
    s.oracle_work+=1
    return dict(id=record['id'],complete=True,input=record,descriptor=desc,build=build,
        description=description,legacy_cardinality=legacy,total_count=total,
        global_rank_samples=samples,focused_families=focused,
        fully_materialized=False,full_large_unranking_exhausted=False,
        scope='Exact full Source cardinality plus selected large membership and all family kinds. No full large palette enumeration, physical VM, theorem search or literal-output fit.')


OFFSETS=((0,-1),(1,0),(0,1),(-1,0))


def independent_graph_core(s,core,instance,tiles,buckets):
    points=instance['required_centers'];gens=instance['root_generations']
    if gens is None:gens=[0]*len(points)
    byid={t['id']:t for t in tiles}
    chosen={}
    for i,identity,edges,generation in core['chosen']:
        s.check();identity=immutable(identity)
        need(type(i)is int and 0<=i<len(points)and i not in chosen,'unique occupied required site')
        need(identity in byid and edges==byid[identity]['edges_NESW'] and generation==gens[i]+1,
             'whole chosen literal tile and root-derived tile generation')
        chosen[i]=identity
    expected_marks={}
    for p,ch,v in instance['fixed_background_marks']:
        s.check();expected_marks[(tuple(p),ch)]=[v,1,True]
    for i,identity in chosen.items():
        for side,(dx,dy)in enumerate(OFFSETS):
            s.check();p=(points[i][0]+dx,points[i][1]+dy);key=(p,'edge');v=byid[identity]['edges_NESW'][side]
            if key in expected_marks:
                need(expected_marks[key][0]==v,'independent whole point marking agreement')
                expected_marks[key][1]+=1
            else:expected_marks[key]=[v,1,False]
    rawmarks=[[list(p),ch,v,refs,fixed]for(p,ch),(v,refs,fixed)in sorted(expected_marks.items())]
    need(argument_bytes(core['marks'])==argument_bytes(rawmarks),'exact full mark values/refcounts/fixed ownership')
    need(len(core['points'])==len(points)and len(core['domains'])==len(points),'entire active finite target')
    exclusions={}
    for row in core['exclusions']:
        s.check();i=row['point'];identity=immutable(row['id'])
        need(type(i)is int and 0<=i<len(points)and identity in byid,'literal excluded candidate')
        need(identity not in exclusions.setdefault(i,[]),'distinct per-point exclusions')
        exclusions[i].append(identity)
        for p,parent_id in row['parent_support']:
            need(chosen.get(p)==immutable(parent_id),'exclusion only under its parent assumptions')
    degree=[];full_domains=[]
    for i,point in enumerate(points):
        s.check();need(core['points'][i]==[i,point,1 if i in chosen else 0,gens[i]],'exact point totals and generations')
        domain=core['domains'][i]
        if i in chosen:
            need(domain is None,'occupied site is absent from frontier');full_domains.append(None);continue
        mask=tuple(expected_marks.get(((point[0]+dx,point[1]+dy),'edge'),[None])[0]for dx,dy in OFFSETS)
        candidates=buckets.get(mask,[])
        physical={t['id']for t in candidates}
        matching=[identity for identity in exclusions.get(i,[])if identity in physical]
        available=[t['id']for t in candidates if t['id']not in matching]
        need(type(domain)is dict and domain['point']==i and domain['mask']==mask and
             type(domain['physical_count'])is int and domain['physical_count']==len(candidates)and
             immutable(domain['matching_exclusions'])==tuple(matching)and
             type(domain['degree'])is int and domain['degree']==len(available),
             'implicit incremental domain equals the complete independently indexed literal inventory')
        full_domains.append(available);degree.append((i,len(available)))
    zeros=[(i,n)for i,n in degree if n==0];ones=[(i,n)for i,n in degree if n==1]
    if zeros:decision=['DEAD',zeros[0][0],0]
    elif ones:decision=['FORCED',ones[0][0],1]
    elif not degree:decision=['COMPLETE',None,0]
    else:
        i,n=min(degree,key=lambda v:(gens[v[0]],v[1],v[0]));decision=['BRANCH',i,n]
    return decision,full_domains


def independent_all_solutions(s,instance,tiles,buckets):
    """Independent fixed-site-order literal point enumeration, not GCTS scheduling."""
    marks={(tuple(p),ch):v for p,ch,v in instance['fixed_background_marks']}
    points=instance['required_centers'];answers=[];chosen=[]
    def visit(i):
        s.check()
        if i==len(points):
            answers.append(tuple(chosen));need(len(answers)<=10000,'declared finite oracle answer cap');return
        p=points[i]
        mask=tuple(marks.get(((p[0]+dx,p[1]+dy),'edge'))for dx,dy in OFFSETS)
        for tile in buckets.get(mask,[]):
            s.check();trail=[]
            for side,(dx,dy)in enumerate(OFFSETS):
                key=((p[0]+dx,p[1]+dy),'edge')
                if key not in marks:marks[key]=tile['edges_NESW'][side];trail.append(key)
            chosen.append(tile['id']);visit(i+1);chosen.pop()
            for key in trail:del marks[key]
    visit(0);s.oracle_work+=1
    return answers


def graph_instance(s,case):
    if case['kind']=='literal':
        instance=clone(case['instance'])
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        return instance,None
    need(case['kind']=='unknown_board','declared graph instance construction')
    record=case['palette_record'];prefix=[immutable(x)for x in case['fixed_prefix']]
    suffix=[immutable(x)for x in case['fixed_suffix']];limits=dict(SELECTOR_LIMITS)
    args=[record['machine'],record['wire'],prefix,case['capacity'],suffix,case['steps']]
    old=s.call('selector','compile_unknown_problem',dict(args=args,limits=limits),
        lambda:s.modules['selector'].compile_unknown_problem(*args,check=s.check,limits=limits))
    colors=old['palette']['color_constructors']
    instance=dict(schema='finite-implicit-wang-point-instance-v1',
        required_centers=old['required_centers'],admissible_origins=old['admissible_origins'],
        fixed_background_marks=[[p,ch,colors[v]]for p,ch,v in old['fixed_background_marks']],root_generations=None)
    return instance,old


def _original_qualify_graph(s,case):
    s.active=case['id'];instance,old=graph_instance(s,case)
    progress=dict(id=case['id'],stage='REFERENCE',input=case,instance=instance,legacy_problem=old,observations=[])
    s.component_rows.append(progress)
    palette,tiles,desc,buckets=s.literal_models[case['palette_id']]
    reference=independent_all_solutions(s,instance,tiles,buckets)
    observations=progress['observations'];pending_restore=[];root_core=None;domain_checks=0
    progress.update(independent_solution_ids=reference,stage='GRAPH_SEARCH')
    class Facade:
        def count_query(self,descriptor,mask,*,check,limits):
            return profile_query(s,'count_query',[descriptor,mask],limits,check)
        def select_query(self,descriptor,mask,index,*,check,limits):
            return profile_query(s,'select_query',[descriptor,mask,index],limits,check)
    def _observe_core(snapshot):
        nonlocal root_core,domain_checks
        before=argument_bytes(snapshot);s.check()
        decision,domains=independent_graph_core(s,snapshot,instance,tiles,buckets)
        need(snapshot['scheduler']==decision,'global DEAD then FORCED then earliest generation')
        deps={}
        for i,p in enumerate(instance['required_centers']):
            for side,(dx,dy)in enumerate(OFFSETS):deps.setdefault((p[0]+dx,p[1]+dy),[]).append([i,side])
        need(snapshot['dependencies']==[[list(p),v]for p,v in sorted(deps.items())],
             'complete forward and reverse midpoint dependency incidence')
        for frame in snapshot['branch_stack']:
            independent_graph_core(s,frame['parent'],instance,tiles,buckets)
        core={k:snapshot[k]for k in('points','chosen','marks','domains','exclusions')}
        if snapshot['reason']=='BEFORE_ROLLBACK':
            need(snapshot['rollback_parent']is not None and not pending_restore,'one exact pending rollback checkpoint')
            independent_graph_core(s,snapshot['rollback_parent'],instance,tiles,buckets)
            pending_restore.append(argument_bytes(snapshot['rollback_parent']))
        if snapshot['reason']=='AFTER_ROLLBACK':
            need(len(pending_restore)==1 and argument_bytes(core)==pending_restore.pop() and
                 argument_bytes(core)==argument_bytes(snapshot['rollback_parent']),
                 'complete restored parent exactly equals its retained rollback checkpoint')
        if snapshot['reason']=='INITIAL':root_core=argument_bytes(core)
        if snapshot['reason']=='ROOT_RESTORED':need(argument_bytes(core)==root_core,'exact full initial state restored')
        domain_checks+=sum(d is not None for d in domains)
        observations.append(dict(snapshot=snapshot,independent_domains=domains,complete=True))
        need(argument_bytes(snapshot)==before,'read-only independent observer')
    def observe(snapshot):
        return _evidence_invoke(s,'OBSERVATION','graph','observe',snapshot,
            lambda:_observe_core(snapshot),after=lambda:snapshot)
    data=dict(instance=instance,descriptor=desc,limits=GRAPH_LIMITS,oracle_limits=IMPLICIT_LIMITS,mode=case['mode'])
    result_holder=[]
    def graph_body(query):
        bind_profile_query(s,query)
        result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
            check=s.check,limits=dict(GRAPH_LIMITS),oracle_limits=dict(IMPLICIT_LIMITS),observe=observe,mode=case['mode'])))
        return None
    profile_call(s,case['id']+'-graph-profile',desc,data,graph_body)
    need(len(result_holder)==1,'one complete graph consumer result')
    result=result_holder[0]
    progress.update(result=result,stage='GRAPH_RESULT')
    need(result['status']!='UNKNOWN_SEARCH_LIMIT'and result['root_restored']is True and
         result['final_observation_completed']is True,'whole graph case complete with observed exact restoration')
    need(not pending_restore,'all begun rollback comparisons completed')
    actual=[]
    for solution in result['solutions']:
        placements=solution['placements'];need(len(placements)==len(instance['required_centers']),'full finite target certificate')
        ids=[]
        for i,placement in enumerate(placements):
            need(placement['point']==i and placement['origin']==instance['required_centers'][i], 'ordered complete target')
            tile=placement['tile'];tile_key(tile)
            need(placement['id']==tile['id']and any(tile_bytes(tile)==tile_bytes(t)for t in tiles),
                 'every certificate tile is a complete literal inventory tile')
            ids.append(tile['id'])
        actual.append(tuple(ids))
    need(len(set(actual))==len(actual),'no duplicate whole tilings')
    if case['mode']=='all':
        need(result['exhaustive']is True and set(actual)==set(reference),'complete solution population equals independent point enumeration')
    elif reference:
        need(result['status']=='SOLUTION_FOUND'and len(actual)==1 and actual[0]in reference,'first solution independently valid')
    else:need(result['status']=='EXHAUSTED_NO_SOLUTION'and not actual and result['exhaustive']is True,'finite exhaustive negative independently agrees')
    decisions=[o['snapshot']['scheduler']for o in observations if o['snapshot']['reason']=='BEFORE_DECISION']
    if case['id']=='distant-DEAD-before-FORCED':need(decisions[0][0]=='DEAD'and not result['solutions'],'distant dead checked before sole placement')
    if case['id']=='distant-FORCED-before-BRANCH':need(decisions[0]==['FORCED',1,1],'distant forced checked before local choices')
    if case['id']=='earliest-before-lower-degree-TEST-VARIANT':need(decisions[0][0]=='BRANCH'and decisions[0][1]==0,'earlier root outranks lower later degree')
    if case['id']=='connected-failed-children-first':need(sum(e['kind']=='FAILED_CHILD_EXCLUDED'for e in result['journal'])>=3,'rank-shifting failed-child population actually reached')
    s.oracle_work+=1
    return dict(id=case['id'],complete=True,input=case,instance=instance,legacy_problem=old,
        result=result,observations=observations,independent_solution_ids=reference,
        independent_solution_count=len(reference),actual_solution_count=len(actual),domain_checks=domain_checks,
        scope='Complete finite singleton-center/four-midpoint point model; no physical FOL interpreter, remote extra tile marks, shared/fractional t support, RL or performance advantage.')


"""Prospective controlled refusals/faults, called only within the once actual."""

def _original_diagnostic(s,d,inputs):
    op=d['operation'];role=d['role'];expected=d['expected']
    bound=dict(IMPLICIT_LIMITS if role=='implicit'else GRAPH_LIMITS)
    calls=0;foreign=None;callback_trace=[]
    def callback():
        nonlocal calls
        calls+=1;s.check()
        if calls==d['expected_callback_count']:
            frame=sys._getframe(1)
            while frame is not None and len(callback_trace)<32:
                if frame.f_code.co_filename==s.plan['sources'][role]['path']:
                    callback_trace.append(dict(function=frame.f_code.co_name,line=frame.f_lineno))
                frame=frame.f_back
            raise foreign
    desc=immutable(inputs['minimal_descriptor']);mask=(None,None,None,None)
    kwargs={};extra=None
    if role=='implicit':
        name='count_query';args=[desc,mask]
        if op.startswith('build_')or op=='implicit_foreign_wire':
            name='build_palette_query';machine=clone(inputs['minimal_machine']);wire=clone(inputs['minimal_wire']);args=[machine,wire]
            if op=='build_bool_symbol':machine['alphabet_size']=True
            elif op=='build_duplicate_transition':machine['transitions']=[[0,0,1,0,0],[0,0,1,0,0]]
            elif op=='build_accept_outgoing':machine['transitions']=[[1,0,0,0,0]]
            elif op=='build_wire_blank':wire['one']=machine['blank']
            elif op=='build_initial_accept':machine['initial']=machine['accepting']
        elif op=='count_bool_mask':args[1]=(('cell',('plain',True)),None,None,None)
        elif op=='count_list_mask':args[1]=[None,None,None,None]
        elif op=='count_nested_none':args[1]=(('cell',None),None,None,None)
        elif op.startswith('select_')or op=='implicit_foreign_fill':
            name='select_query';args=[desc,mask,0]
            if op=='select_bool_index':args[2]=True
            elif op=='select_negative_index':args[2]=-1
            elif op=='select_past_end':
                extra=palette_call(s,'count_query',[desc,mask]);args[2]=extra['count']
        elif op=='count_invalid_descriptor':args[0]=('wrong',desc[1],desc[2])
        elif op=='implicit_work_limit':bound['work']=1
        elif op=='implicit_integer_limit':bound['integer_bits']=1
        elif op=='implicit_data_limit':bound['data_items']=1
        if expected=='FOREIGN':
            if op=='implicit_foreign_same_invalid':foreign=s.modules['implicit'].Invalid('foreign public invalid')
            elif op=='implicit_foreign_same_limit':foreign=s.modules['implicit'].Limit('foreign public limit',0)
            else:foreign=StopIteration('declared exact delegated StopIteration')
        action=lambda:palette_call(s,name,args,bound,callback if expected=='FOREIGN'else None)
    else:
        instance=clone(inputs['graph_cases'][0]['instance']);mode='first'
        for row in instance['fixed_background_marks']:row[2]=immutable(row[2])
        if op=='graph_empty_target':instance['required_centers']=[];instance['admissible_origins']=[]
        elif op=='graph_odd_center':instance['required_centers'][0][0]=1;instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_duplicate_center':instance['required_centers'].append(instance['required_centers'][0][:]);instance['admissible_origins']=clone(instance['required_centers'])
        elif op=='graph_origin_mismatch':instance['admissible_origins']=[]
        elif op=='graph_duplicate_pin':instance['fixed_background_marks'].append(instance['fixed_background_marks'][0])
        elif op=='graph_none_pin':instance['fixed_background_marks'][0][2]=None
        elif op=='graph_bool_generation':instance['root_generations']=[False,0]
        elif op=='graph_bad_mode':mode='not_a_mode'
        elif op=='graph_work_unknown':bound['work']=1
        if expected=='FOREIGN':
            if op=='graph_foreign_same_invalid':foreign=s.modules['graph'].DeclarationError('foreign public invalid')
            elif op=='graph_foreign_same_limit':foreign=s.modules['graph'].SearchLimit(object(),'foreign own-class owner mismatch')
            else:foreign=StopIteration('declared exact graph StopIteration')
        class Facade:
            def count_query(self,descriptor,query,*,check,limits):return profile_query(s,'count_query',[descriptor,query],limits,check)
            def select_query(self,descriptor,query,index,*,check,limits):return profile_query(s,'select_query',[descriptor,query,index],limits,check)
        data=dict(instance=instance,descriptor=desc,limits=bound,oracle_limits=IMPLICIT_LIMITS,mode=mode)
        result_holder=[]
        def graph_body(query):
            bind_profile_query(s,query)
            result_holder.append(s.call('graph','search',data,lambda:s.modules['graph'].search(instance,Facade(),desc,
                check=callback if expected=='FOREIGN'else s.check,limits=bound,oracle_limits=dict(IMPLICIT_LIMITS),mode=mode)))
            return None
        def graph_action():
            profile_call(s,d['id']+'-graph-diagnostic-profile',desc,data,graph_body)
            need(len(result_holder)==1,'one complete original graph diagnostic result')
            return result_holder[0]
        action=graph_action
    try:result=action()
    except BaseException as error:
        s.fault_gate()
        if expected=='FOREIGN':
            need(error is foreign and calls==d['expected_callback_count'],'exact delegated foreign object and declared site')
            if d['expected_callback_function']is not None:
                need(any(v['function']==d['expected_callback_function']for v in callback_trace),
                     'foreign reached the prospectively named subject function')
            if role=='implicit':
                for pred in('is_own_invalid','is_own_limit'):
                    need(s.call(role,pred,[],lambda pred=pred:getattr(s.modules[role],pred)(error))is False,'foreign public class not privately owned')
        elif role=='implicit':
            pred='is_own_invalid'if expected=='INVALID'else'is_own_limit'
            need(s.call(role,pred,[],lambda:getattr(s.modules[role],pred)(error))is True,'exact private owned refusal')
        else:need(expected=='INVALID'and type(error)is s.modules['graph'].DeclarationError,'exact graph declaration refusal')
        return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
            callback_trace=callback_trace,exact_foreign_identity=(error is foreign)if expected=='FOREIGN'else None,error=information(error),
            implicit_prefix=getattr(error,'implicit_palette_prefix',None),graph_prefix=getattr(error,'implicit_search_prefix',None),setup_receipt=extra)
    s.fault_gate()
    need(expected=='UNKNOWN'and role=='graph'and result['status']=='UNKNOWN_SEARCH_LIMIT'and
         result['exhaustive']is False and result['unfinished_prefix']['final_observation_completed']is False,
         'only declared own search quota becomes UNKNOWN, never zero/UNSAT')
    return dict(id=d['id'],operation=op,role=role,expected=expected,status='PASSED',callback_count=calls,
        exact_foreign_identity=None,result=result,setup_receipt=extra)


# Source-only diagnostic extension. No imports or top-level component calls.
# Root inserts this fragment before main in one freshly reviewed whole worker.


def _batch_diag_plain(s, value, owners, depth=0):
    """Full ordinary projection; nonliteral references are metadata, not replay."""
    s.check()
    need(depth <= 128, 'bounded diagnostic projection depth')
    kind = type(value)
    if value is None or kind in (str, int, bool):
        return value
    if kind is tuple:
        return dict(literal_type='tuple', items=[_batch_diag_plain(s, x, owners, depth + 1) for x in value])
    if kind is list:
        return [_batch_diag_plain(s, x, owners, depth + 1) for x in value]
    if kind is dict:
        need(all(type(k) is str for k in value), 'diagnostic ordinary string-key mapping')
        return {k: _batch_diag_plain(s, v, owners, depth + 1) for k, v in value.items()}
    position = None
    for i in range(len(owners)):
        s.check()
        if owners[i] is value:
            position = i
            break
    if position is None:
        position = len(owners)
        owners.append(value)
    name = type(value).__name__
    module = type(value).__module__
    return dict(nonliteral_reference=position,
                type_name=name[:160] if type(name) is str else None,
                type_module=module[:160] if type(module) is str else None,
                replayable=False, representation_evaluated=False)


def _batch_diag_immutable(s, value):
    s.check()
    if type(value) is list:
        copied = []
        for x in value:
            copied.append(_batch_diag_immutable(s, x))
        return tuple(copied)
    need(value is None or type(value) in (str, int, bool), 'original descriptor literal codec')
    return value


def _batch_diag_error(s, module, name):
    s.check()
    if name == 'RuntimeError':
        return RuntimeError('declared batch diagnostic RuntimeError')
    if name == 'ValueError':
        return ValueError('declared batch diagnostic ValueError')
    if name == 'StopIteration':
        return StopIteration('declared batch diagnostic StopIteration')
    if name == 'Invalid':
        return module.Invalid('foreign public Invalid without owner')
    if name == 'Limit':
        return module.Limit('foreign public Limit without owner', 0)
    need(False, 'literal diagnostic exception enum')


def _batch_diag_profile(s, desc, parameters, recipe, run_label, limits_override=None):
    """One Root boundary. Planned sentinels never enter Root's genuine latch."""
    m = s.modules['implicit']
    limits = dict(IMPLICIT_LIMITS)
    limits.update(queries=1000000, receipt_items=2000000)
    if limits_override is not None:
        limits.update(limits_override)
    mask = (None, None, None, None)
    requests = (('count', mask), ('select', mask, 0), ('count', (0, None, None, None)))
    owner = dict(label=run_label, recipe=recipe, parameters=parameters, descriptor=desc,
                 limits=limits, callbacks={}, errors=[], lifetimes=[], queries=[],
                 events=[], observed_receipts=[], checkpoint_after_first=None,
                 thrown=None, result=None, trigger_fired=False, foreign=None,
                 secondary=None, nonliteral_owners=[], profile_admitted=False,
                 custody_success=False)
    s.batch_diagnostic_owners.append(owner)
    if recipe in ('foreign-site', 'foreign-public-class'):
        owner['foreign'] = _batch_diag_error(s, m, parameters['exception'])
        owner['errors'].append(owner['foreign'])
    if recipe == 'closed-failure' or recipe == 'secondary-nonmasking':
        owner['foreign'] = _batch_diag_error(s, m, 'RuntimeError')
        owner['errors'].append(owner['foreign'])
    if recipe == 'secondary-nonmasking':
        owner['secondary'] = _batch_diag_error(s, m, parameters['secondary'])
        owner['errors'].append(owner['secondary'])
    baseline = argument_bytes(dict(descriptor=desc, limits=limits))

    def state_now():
        return owner['lifetimes'][0] if owner['lifetimes'] else None

    def fire():
        s.check()
        owner['trigger_fired'] = True
        raise owner['foreign']

    def check():
        # The real Root gate runs before even looking for a planned trigger.
        s.check()
        state = state_now()
        site = parameters.get('site')
        if recipe in ('foreign-site', 'foreign-public-class') and not owner['trigger_fired']:
            if site == 'entry' and state is None:
                fire()
            if state is not None:
                active = state['active_query']
                stage = state['stage']
                if site == 'preparation' and stage == 'VALIDATING_COMPLETE_DESCRIPTOR':
                    fire()
                if site == 'query-kernel' and active is not None and active['stage'] == 'INTERSECTING_FULL_PALETTE':
                    fire()
                if site == 'first-receipt-tree' and active is not None and active['stage'] == 'RETAINING_EXACT_RECEIPT':
                    frame = sys._getframe(1)
                    found = False
                    for unused in range(32):
                        if frame is None:
                            break
                        if frame.f_code.co_filename == s.plan['sources']['implicit']['path'] and frame.f_code.co_name == '_receipt_tree':
                            found = True
                            break
                        frame = frame.f_back
                    if found:
                        fire()
                if site == 'reconciliation' and stage == 'RECONCILING_FULL_RECEIPT_SEQUENCE':
                    frame = sys._getframe(1)
                    for unused in range(32):
                        if frame is None:
                            break
                        if frame.f_code.co_filename == s.plan['sources']['implicit']['path'] and frame.f_code.co_name == '_same_receipt_tree':
                            fire()
                        frame = frame.f_back
        if recipe == 'reentrant' and state is not None and state['active_query'] is not None and not owner['trigger_fired']:
            if state['active_query']['stage'] == 'INTERSECTING_FULL_PALETTE':
                owner['trigger_fired'] = True
                try:
                    owner['queries'][0](('count', mask))
                except BaseException as error:
                    owner['errors'].append(error)
                    owner['foreign'] = error
                    raise

    def custody(phase):
        # Integrity is real. Only after a successful guard may a planned refusal
        # be injected. It establishes refusal, never custody acceptance.
        s.guard()
        s.fault_gate()
        s.policy(lambda: need(argument_bytes(dict(descriptor=desc, limits=limits)) == baseline,
             'full diagnostic profile arguments at actual custody boundary'))
        owner['events'].append(phase)
        if recipe == 'foreign-site' and parameters['site'] == 'custody-' + phase:
            fire()
        if recipe == 'custody-return' and parameters['phase'] == phase:
            owner['trigger_fired'] = True
            return 1
        if recipe == 'secondary-nonmasking' and phase == 'exit':
            owner['trigger_fired'] = True
            raise owner['secondary']
        return None

    def retain(state):
        s.check()
        owner['lifetimes'].append(state)
        if recipe == 'foreign-site' and parameters['site'] == 'retain':
            fire()
        return None

    def body(query):
        s.check()
        owner['queries'].append(query)
        if recipe == 'foreign-site' and parameters['site'] == 'body':
            fire()
        if recipe in ('closed-failure', 'secondary-nonmasking'):
            raise owner['foreign']
        if recipe == 'swallowed-query':
            try:
                query(('unknown', mask))
            except BaseException as first:
                owner['errors'].append(first)
                owner['foreign'] = first
                try:
                    query(('count', mask))
                except BaseException as again:
                    owner['errors'].append(again)
                    need(again is first, 'swallowed query fault reappears by exact identity')
                else:
                    need(False, 'swallowed query cannot resume')
            else:
                need(False, 'declared invalid operation must fail')
            return 'body tried to swallow fault'
        active_requests = requests if recipe in ('ordered-positive', 'static-positive') else (('select', mask, 0),)
        if recipe == 'mutation-bool-int':
            active_requests = (('count', (0, None, None, None)),)
        if recipe in ('cumulative-baseline', 'work-cumulative', 'queries-cumulative', 'receipt-items-cumulative'):
            active_requests = (('count', mask), ('count', mask))
        for request in active_requests:
            receipt = query(request)
            owner['observed_receipts'].append(receipt)
            if owner['checkpoint_after_first'] is None:
                state = state_now()
                owner['checkpoint_after_first'] = dict(work=state['work'].work,
                    receipt_items=state['receipt_items'], delivered_receipt_count=state['delivered_receipt_count'])
        if recipe == 'mutation-bool-int':
            need(type(owner['observed_receipts'][0]['count']) is int and owner['observed_receipts'][0]['count'] == 0,
                 'exact assignedzero mask returns integerzero before alias mutation')
            owner['observed_receipts'][0]['count'] = False
        elif recipe == 'mutation-list-tuple':
            tile = owner['observed_receipts'][0]['tile']
            tile['t'] = tuple(tile['t'])
        elif recipe == 'mutation-absent-zero':
            if parameters['variant'] == 'absent':
                del owner['observed_receipts'][0]['authority']
            else:
                owner['observed_receipts'][0]['authority'] = 0
        return dict(ordered_requests=len(active_requests))

    event_hook=_profile_evidence(s,run_label,'diagnostic',dict(descriptor=desc,limits=limits,recipe=recipe,parameters=parameters))
    owner['callbacks'].update(state_now=state_now, fire=fire, check=check,
                              custody=custody, retain=retain, body=body)
    data = dict(descriptor=desc, limits=limits, recipe=recipe, parameters=parameters,
                requests=requests if recipe == 'static-positive' else None)
    try:
        if recipe == 'static-positive':
            result = s.call('implicit', 'batch_diagnostic_static', data,
                lambda: m.batch_query(desc, requests, check=check, limits=limits, custody=custody, retain=retain,evidence=event_hook))
        else:
            result = s.call('implicit', 'batch_diagnostic_profile', data,
                lambda: m.with_profile(desc, body, check=check, limits=limits, custody=custody, retain=retain,evidence=event_hook))
    except BaseException as error:
        owner['thrown'] = error
        owner['errors'].append(error)
        state = state_now()
        prefix = getattr(error, 'implicit_palette_batch_prefix', None)
        record_profile_accounting(s, run_label, prefix=prefix, lifetime=state)
        # Never classify an expected diagnostic while a genuine Root fault lives.
        s.fault_gate()
        owner['prefix'] = prefix
    else:
        owner['result'] = result
        record_profile_accounting(s, run_label, receipt=result, lifetime=state_now())
        s.fault_gate()
        owner['profile_admitted'] = True
        owner['custody_success'] = True
    s.fault_gate()
    return owner


def _batch_diag_closed(s, owner):
    s.fault_gate()
    need(len(owner['queries']) == 1, 'one saved scoped query')
    query = owner['queries'][0]
    before = argument_bytes(dict(limits=owner['limits'], descriptor=owner['descriptor']))
    try:
        s.call('implicit', 'batch_diagnostic_closed_query', [], lambda: query(('count', (None, None, None, None))))
    except BaseException as error:
        s.fault_gate()
        owner['errors'].append(error)
        module = s.modules['implicit']
        need(s.call('implicit', 'is_own_invalid', [], lambda: module.is_own_invalid(error)) is True,
             'closed scope refuses by private owned Invalid')
        need(error.reason == 'query outside active profile lifetime', 'exact closed lifetime reason')
    else:
        need(False, 'closed scope query must refuse')
    need(argument_bytes(dict(limits=owner['limits'], descriptor=owner['descriptor'])) == before,
         'closed query cannot mutate profile inputs')


def _batch_diag_owner_result(s, owner):
    s.fault_gate()
    state = owner['lifetimes'][0] if owner['lifetimes'] else None
    return dict(profile_admitted=owner['profile_admitted'], custody_success=owner['custody_success'],
        planned_trigger_fired=owner['trigger_fired'],
        exact_primary_identity=None if owner['foreign'] is None else owner['thrown'] is owner['foreign'],
        thrown=_batch_diag_plain(s,owner['thrown'],owner['nonliteral_owners']),
        events=owner['events'][:], checkpoint_after_first=owner['checkpoint_after_first'],
        reference_receipts=_batch_diag_plain(s,owner.get('reference_receipts',[]),owner['nonliteral_owners']),
        callback_references=_batch_diag_plain(s,owner['callbacks'],owner['nonliteral_owners']),
        work_object_scalars=None if state is None or state['work'] is None else
            dict(work=state['work'].work,items=state['work'].items,limits=dict(state['work'].limits)),
        produced_receipt_count=None if state is None else state['produced_receipt_count'],
        preimage_completed_count=None if state is None else state['preimage_completed_count'],
        delivered_receipt_count=None if state is None else state['delivered_receipt_count'],
        ordinary_lifetime_projection=_batch_diag_plain(s, state, owner['nonliteral_owners']),
        ordinary_prefix_projection=_batch_diag_plain(s, owner.get('prefix'), owner['nonliteral_owners']),
        result=_batch_diag_plain(s, owner['result'], owner['nonliteral_owners']),
        callbacks_and_nonliteral_owners_retained=True,
        nonliteral_projection_scope='Bounded type/reference metadata only; original objects retained, not reconstructed.')


def _batch_diag_summary(s, group, variant):
    """Pure scalar record-builder coverage; no writer or filesystem invocation."""
    p = variant['parameters']
    class Carrier:
        pass
    class Hostile(Exception):
        def __str__(self):
            raise RuntimeError('summary must not render exceptions')
    class Untouched:
        def __iter__(self):
            raise RuntimeError('summary must not traverse subject prefixes')
        def __str__(self):
            raise RuntimeError('summary must not render subject prefixes')
    fake = Carrier()
    fake.active = 'active'; fake.rows = []; fake.plan = {}; fake.plan_pin = {}
    fake.stage = 'SUMMARY_TEST'; fake.first_fault = None
    fake.work_deadline = 10; fake.overall_deadline = 20; fake.root_calls = 0
    fake.started = {}; fake.completed = {}; fake.raised = {}
    fake.component_rows = []; fake.diagnostics = []; fake.retained = []; fake.output_pins = []
    primary = Hostile('literal summary detail')
    owner = dict(fake=fake, primary=primary, constructors=[Carrier, Hostile, Untouched])
    s.batch_diagnostic_owners.append(owner)
    if group['recipe'] == 'summary-hostile':
        primary.subject_prefix = Untouched()
    elif group['recipe'] == 'summary-scalar':
        value = {'bool': True, 'negative': -1, 'huge': 1 << 200, 'unavailable': Untouched()}[p['value']]
        fake.root_calls = value; fake.work_deadline = value; fake.overall_deadline = value
    elif group['recipe'] == 'summary-counter-caps':
        fake.started = {('x' * 49 + str(i)): i for i in range(17)}
        fake.completed = {'bool': True, 'negative': -1, 'huge': 1 << 200, 'ok': 7}
        fake.raised = None
    elif group['recipe'] == 'summary-active-metadata':
        fake.first_fault = primary
        fake.stage = 's' * 65
        fake.plan = dict(invocation_id='i' * 257)
        fake.plan_pin = dict(sha256='h' * 65)
        fake.rows = [dict(id='l' * 97)]
        if p['active'] == 'string':
            fake.active = 'a' * 97
        else:
            fake.active = dict(id='a' * 97, stage='r' * 65, subject_prefix=Untouched())
        primary.args = (Untouched(),)
    else:
        need(False, 'literal scalar summary recipe')
    s.guard(); s.fault_gate()
    record = s.call('worker', 'failure_summary_record_diagnostic', dict(group=group['id'], variant=variant['id']),
                    lambda: _failure_summary_record(fake, primary))
    s.fault_gate()
    need(record['authority'] is False and record['mathematical_authority'] is False and
         record['resource_accepted'] is False and record['full_pipeline_qualified'] is False and
         record['no_failed_prefix_admission'] is True, 'scalar metadata has no proof or admission authority')
    need(record['first_available_fault']['message_evaluated'] is False, 'exception str never requested')
    if group['recipe'] == 'summary-hostile':
        need(record['first_available_fault']['literal_first_argument'] ==
             dict(value='literal summary detail', available=True, truncated=False), 'literal first arg survives without rendering')
    elif group['recipe'] == 'summary-scalar':
        need(record['root_check_calls'] is None and record['work_deadline_ns'] is None and
             record['overall_deadline_ns'] is None, 'bool negative huge unavailable are not fabricated counters')
    elif group['recipe'] == 'summary-counter-caps':
        counts = record['call_started']
        need(counts['available'] is True and counts['total_entries'] == 17 and counts['truncated'] is True and
             len(counts['rows']) == 16 and all(len(r[0]['value']) == 48 and r[0]['truncated'] is True for r in counts['rows']),
             'exact first16 capped labels retained with total/truncation metadata')
        need([r[1] for r in record['call_completed']['rows']] == [None, None, None, 7] and
             record['call_raised']['available'] is False, 'invalid counts unavailable, exact valid count remains')
    else:
        need(record['first_available_fault']['origin'] == 'ROOT_FIRST_FAULT_LATCH' and
             record['first_available_fault']['literal_first_argument']['available'] is False,
             'first-fault origin and unavailable nonstring argument')
        for key in ('invocation_id', 'plan_sha256', 'stage', 'active_row_id', 'last_completed_case_id'):
            need(record[key]['truncated'] is True, 'declared scalar text cap')
        if p['active'] == 'dict':
            need(record['active_row_stage']['truncated'] is True, 'dictionary active stage capped')
    owner['record'] = record
    return dict(id=variant['id'], status='PASSED', complete=True, expected=variant['expected'], record=record,
                writer_invoked=False, filesystem_persistence_tested=False)


def run_new_diagnostics(s, bank):
    """Separate predeclared diagnostic cohort; never edits old33 diagnostics."""
    need(type(bank) is dict and set(bank) == {'schema','status','original_bank','descriptor_from_original_id',
         'tuple_codec','groups','coverage_scope','source_only','actual_execution_authorized'}, 'exact new diagnostic bank keys')
    need(bank['schema'] == 'implicit-batch-summary-diagnostics-v1' and bank['source_only'] is True and
         bank['actual_execution_authorized'] is False, 'ordinary bank gives no execution authority')
    need(bank['descriptor_from_original_id'] == 'minimal_descriptor' and bank['tuple_codec'] == 'recursive-original-JSON-lists-to-exact-tuples-v1',
         'declared original descriptor codec')
    need(type(bank['groups']) is list and len(bank['groups']) == 28 and len({g['id'] for g in bank['groups']}) == 28,
         'complete declared 24batch plus4summary groups')
    need(bank['original_bank'] == s.plan['inputs'][0]['pin'], 'new literal bank pins the complete original input descriptor')
    need(argument_bytes(s.batch_original_inputs) == s.batch_original_inputs_preimage, 'unchanged entire original input bank')
    desc = _batch_diag_immutable(s, s.batch_original_inputs['minimal_descriptor'])
    if not hasattr(s, 'batch_diagnostic_owners'):
        s.batch_diagnostic_owners = []
    need(type(s.batch_diagnostics) is list and not s.batch_diagnostics, 'fresh separate batch diagnostic results')
    previous_active = s.active
    s.batch_diagnostic_progress = dict(stage='RUNNING', active_group=None, active_variant=None,
                                      completed_group_ids=[], groups=[])
    for group in bank['groups']:
        s.evidence_scope.update(group_id=group['id'],variant_id=None)
        group_event=s.policy(lambda:s.evidence.enter('DIAGNOSTIC_GROUP','worker',group['recipe'],group))
        s.check(); s.fault_gate()
        need(set(group) == {'id','subject','recipe','variants','source_reasoning'}, 'exact diagnostic group keys')
        progress = dict(id=group['id'], subject=group['subject'], recipe=group['recipe'],
                        stage='RUNNING', variants=[], active_runs=[])
        s.batch_diagnostic_progress['active_group'] = group['id']
        s.batch_diagnostic_progress['groups'].append(progress)
        for variant in group['variants']:
            s.evidence_scope['variant_id']=variant['id']
            variant_event=s.policy(lambda:s.evidence.enter('DIAGNOSTIC_VARIANT','worker',group['recipe'],variant))
            need(set(variant) == {'id','parameters','trigger','expected'}, 'exact diagnostic variant keys')
            s.batch_diagnostic_progress['active_variant'] = variant['id']
            s.active = variant['id']
            if group['subject'] == 'scalar-summary-builder':
                row = _batch_diag_summary(s, group, variant)
            else:
                recipe = group['recipe']; p = variant['parameters']; runs = []
                if recipe in ('work-cumulative', 'receipt-items-cumulative'):
                    baseline = _batch_diag_profile(s, desc, {}, 'cumulative-baseline', variant['id'] + ':baseline')
                    runs.append(baseline)
                    need(baseline['result'] is not None, 'full two-query calibration before derived cumulative quota')
                    point = baseline['checkpoint_after_first']
                    limit = {'work': point['work'] + 1} if recipe == 'work-cumulative' else {'receipt_items': point['receipt_items'] + 1}
                elif recipe == 'queries-cumulative':
                    limit = {'queries': 1}
                else:
                    limit = None
                owner = _batch_diag_profile(s, desc, p, recipe, variant['id'], limit)
                runs.append(owner)
                progress['active_runs'] = [_batch_diag_owner_result(s, x) for x in runs]
                s.fault_gate()
                error = owner['thrown']; module = s.modules['implicit']
                if recipe in ('ordered-positive', 'static-positive', 'closed-success'):
                    need(error is None and owner['result'] is not None, 'complete positive diagnostic profile')
                    state = owner['lifetimes'][0]
                    expected_count = 3 if recipe in ('ordered-positive', 'static-positive') else 1
                    need(state['produced_receipt_count'] == expected_count and state['preimage_completed_count'] == expected_count and
                         state['delivered_receipt_count'] == expected_count, 'positive produced/preimage/delivery census')
                    if expected_count == 3:
                        receipts = owner['result']['receipts']
                        need([r['count'] for r in receipts] == [190,190,0] and receipts[1]['tile']['kind'] == 'step',
                             'ordered complete palette counts, select tile and explicit assignedzero mask')
                        reference = []
                        for name, args in (('count_query',[desc,(None,None,None,None)]),
                                           ('select_query',[desc,(None,None,None,None),0]),
                                           ('count_query',[desc,(0,None,None,None)])):
                            s.check()
                            receipt = s.call('implicit', 'batch_diagnostic_reference_' + name, args,
                                lambda name=name,args=args: getattr(module,name)(*args,check=s.check,limits=dict(IMPLICIT_LIMITS)))
                            account_palette_work(s,receipt['attempted_work']); s.fault_gate()
                            reference.append(receipt)
                        owner['reference_receipts'] = reference
                        for actual, expected in zip(receipts,reference):
                            a={k:v for k,v in actual.items() if k!='attempted_work'}
                            e={k:v for k,v in expected.items() if k!='attempted_work'}
                            need(argument_bytes(a)==argument_bytes(e), 'full strict typed ordered batch equals standalone legacy semantic receipts')
                    if recipe == 'closed-success':
                        _batch_diag_closed(s, owner)
                elif recipe in ('foreign-site','foreign-public-class','closed-failure','secondary-nonmasking'):
                    need(error is owner['foreign'], 'exact planned foreign primary identity preserved')
                    if recipe == 'foreign-public-class':
                        for predicate in ('is_own_invalid','is_own_limit'):
                            need(s.call('implicit',predicate,[],lambda predicate=predicate:getattr(module,predicate)(error)) is False,
                                 'same public class without private ownership is foreign')
                    if p.get('site') == 'first-receipt-tree':
                        state=owner['lifetimes'][0]; active=state['active_query']
                        need(state['produced_receipt_count']==1 and state['preimage_completed_count']==0 and state['delivered_receipt_count']==0,
                             'raw receipt retained before first typed-copy callback fault')
                        need(not state['receipts'] and active['produced_receipt'] is not None and active['produced_receipt']['tile']['kind']=='step' and
                             active['produced_preimage'] is None and active['preimage_complete'] is False and active['delivered'] is False,
                             'complete raw select tile survives first receipt-tree failure')
                    if recipe=='closed-failure':
                        _batch_diag_closed(s,owner)
                    if recipe=='secondary-nonmasking':
                        state=owner['lifetimes'][0]
                        need(state['custody_cleanup_exception'] is owner['secondary'] and state['custody_exit_completed'] is False,
                             'secondary custody exception retained and cannot mask primary')
                else:
                    need(error is not None,'declared refusal occurred')
                    predicate='is_own_limit' if recipe in ('work-cumulative','queries-cumulative','receipt-items-cumulative') else 'is_own_invalid'
                    need(s.call('implicit',predicate,[],lambda:getattr(module,predicate)(error)) is True,'exact private-owned diagnostic refusal')
                    if recipe in ('work-cumulative','queries-cumulative','receipt-items-cumulative'):
                        reason={'work-cumulative':'work','queries-cumulative':'queries','receipt-items-cumulative':'receipt_items'}[recipe]
                        need(error.reason==reason,'declared cumulative unit refused')
                        state=owner['lifetimes'][0]
                        need(state['attempted_queries']==2 and state['delivered_receipt_count']==1,'quota remains cumulative after first completed query')
                    elif recipe=='swallowed-query' or recipe=='reentrant':
                        need(error is owner['foreign'] and owner['lifetimes'][0]['query_fault'] is error,
                             'exact first query fault survives swallowing or reentrancy')
                    elif recipe.startswith('mutation-'):
                        need(error.reason=='body changed exact query receipt','complete typed reconciliation detects mutation')
                    elif recipe=='custody-return':
                        need(error.reason=='custody callback must return None after verification','non-None custody return refuses')
                s.fault_gate()
                if error is not None:
                    need(owner['profile_admitted'] is False and owner['custody_success'] is False,
                         'expected sentinel establishes refusal only, no admitted profile/custody')
                row=dict(id=variant['id'],status='PASSED',complete=True,expected=variant['expected'],
                         runs=[_batch_diag_owner_result(s,x) for x in runs],
                         real_root_fault_gate_passed=True, inherited_outer_gates_unchanged=True)
            progress['variants'].append(row)
            s.policy(lambda:s.evidence.leave(variant_event,value=row))
        completed=dict(id=group['id'],subject=group['subject'],recipe=group['recipe'],status='PASSED',complete=True,variants=progress['variants'])
        progress['stage']='COMPLETE'
        progress['active_runs']=[]
        s.batch_diagnostics.append(completed)
        s.batch_diagnostic_progress['completed_group_ids'].append(group['id'])
        s.policy(lambda:s.evidence.leave(group_event,value=completed))
    s.batch_diagnostic_progress.update(stage='COMPLETE',active_group=None,active_variant=None)
    need(argument_bytes(s.batch_original_inputs)==s.batch_original_inputs_preimage,'old full bank unchanged after all new diagnostics')
    s.active = previous_active
    s.evidence_scope.update(group_id=None,variant_id=None)
    return s.batch_diagnostics


def qualify(s,inputs,batch_inputs):
    s.stage='FULL_SMALL_PALETTES';small=[]
    for record in inputs['small_palettes']:
        row=qualify_small_palette(s,record);small.append(row);s.rows.append(row)
    s.stage='LARGE_IMPLICIT_PALETTE'
    large=qualify_large_palette(s,inputs['large_palette']);s.rows.append(large)
    s.stage='COMPLETE_POINT_GRAPH';graphs=[]
    for case in inputs['graph_cases']:
        row=qualify_graph(s,case);graphs.append(row);s.rows.append(row)
    s.stage='DIAGNOSTICS'
    for d in inputs['diagnostics']:
        s.active=d['id'];s.diagnostics.append(diagnostic(s,d,inputs))
    s.stage='BATCH_DIAGNOSTICS'
    run_new_diagnostics(s,batch_inputs)
    final_profile_custody(s)
    return dict(schema='implicit-palette-graph-calibration-packet-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',
        inputs=inputs,small_palettes=small,large_palette=large,graphs=graphs,diagnostics=s.diagnostics,call_receipts=s.retained,
        call_started=s.started,call_completed=s.completed,call_raised=s.raised,root_callbacks=s.root_calls,
        batch_inputs=batch_inputs,profile_rows=s.profile_rows,profile_metrics=profile_metrics(s),
        profile_accounting=s.profile_accounting,
        batch_diagnostics=s.batch_diagnostics,batch_diagnostic_progress=s.batch_diagnostic_progress,
        full_VM_implemented=False,full_FOL_palette_qualified=False,proof_discovery=False,
        full_pipeline_qualified=False,mathematical_authority=False,
        scope='New full implicit representation and finite point-domain comparison. Full small nonempty masks plus declared zero cases; selected large membership; entire finite graph solutions and every observed domain. No literal expansion fit, old negative rescue, physical FOL VM, theorem/RL discovery or speed advantage.')


def qualify_small_palette(s,record):
    return _evidence_invoke(s,'CASE','worker','qualify_small_palette',record,
        lambda:_original_qualify_small_palette(s,record),case_id=record['id'])

def qualify_large_palette(s,record):
    return _evidence_invoke(s,'CASE','worker','qualify_large_palette',record,
        lambda:_original_qualify_large_palette(s,record),case_id=record['id'])

def qualify_graph(s,record):
    return _evidence_invoke(s,'CASE','worker','qualify_graph',record,
        lambda:_original_qualify_graph(s,record),case_id=record['id'])

def diagnostic(s,d,inputs):
    return _evidence_invoke(s,'LEGACY_DIAGNOSTIC',d['role'],d['operation'],d,
        lambda:_original_diagnostic(s,d,inputs),case_id=d['id'])

# Root integration functions are appended from a separate Source fragment.
# UNEXECUTED Root integration fragment for the complete original cohort.
# Appended verbatim to the successor worker Source by metadata authoring only.


class _NamedOwnerSeal:
    """Real retained owner graph; equality compares only exact scalar edge rows."""
    def __init__(self, rows, owners):
        self.rows=rows
        self.owners=owners
    def __eq__(self, other):
        return type(other)is _NamedOwnerSeal and self.rows==other.rows
    def __ne__(self, other):
        return not self.__eq__(other)


def _recursive_function_owner_seal(value):
    """Cycle-safe node traversal; EVERY named/slot edge occurrence is recorded.

    Nodes are visited once, edges are never deduplicated. Class member names,
    exact descriptor type/owner and accessor/target bindings remain explicit.
    Actual original objects are held strongly in _NamedOwnerSeal.owners; integer
    IDs alone never finance GC/rebinding or reconstruct executable custody.
    """
    need(type(value)is types.FunctionType,'owned synchronous callback function')
    pending=[value];seen=set();rows=[];owners=[value]
    def edge_owner(owner):
        owners.append(owner)
        if type(owner)is types.FunctionType or type(owner)is type:
            pending.append(owner)
        return id(owner)
    while pending:
        node=pending.pop();identity=id(node)
        if identity in seen:continue
        seen.add(identity);owners.append(node)
        if type(node)is types.FunctionType:
            code=node.__code__;defaults=node.__defaults__;kw=node.__kwdefaults__
            closure=node.__closure__;owners.extend((code,defaults,kw,closure))
            default_edges=[]
            if defaults is not None:
                need(type(defaults)is tuple,'exact function default tuple owner')
                for index,content in enumerate(defaults):
                    default_edges.append((index,edge_owner(content)))
            kw_edges=[]
            if kw is not None:
                need(type(kw)is dict and all(type(k)is str for k in kw),
                     'exact named keyword-default owners')
                for name,content in sorted(kw.items()):
                    kw_edges.append((name,edge_owner(content)))
            cells=[]
            if closure is not None:
                for index,cell in enumerate(closure):
                    owners.append(cell)
                    try:
                        content=cell.cell_contents
                    except ValueError:
                        cells.append((index,id(cell),False,None))
                    else:
                        cells.append((index,id(cell),True,edge_owner(content)))
            rows.append(('function',identity,id(code),id(defaults),id(kw),id(closure),
                         tuple(default_edges),tuple(kw_edges),tuple(cells)))
            continue
        need(type(node)is type,'only exact function/class owner nodes traversed')
        bases=node.__bases__;mro=node.__mro__
        owners.extend((bases,mro))
        base_edges=[]
        for index,base in enumerate(bases):
            base_edges.append((index,edge_owner(base)))
        mro_edges=[]
        for index,base in enumerate(mro):
            mro_edges.append((index,edge_owner(base)))
        members=[]
        namespace=vars(node)
        need(all(type(name)is str for name in namespace),'exact class member names')
        for name,member in sorted(namespace.items()):
            owners.append(member)
            kind=type(member);target=None;accessors=()
            if kind is staticmethod or kind is classmethod:
                target=edge_owner(member.__func__)
            elif kind is property:
                accessor_edges=[]
                for label,accessor in (('fget',member.fget),('fset',member.fset),('fdel',member.fdel)):
                    accessor_edges.append((label,edge_owner(accessor)))
                accessors=tuple(accessor_edges)
                owners.append(member.__doc__)
                target=id(member.__doc__)
            else:
                target=edge_owner(member)
            members.append((name,id(kind),id(member),target,accessors))
        rows.append(('class',identity,id(type(node)),id(bases),tuple(base_edges),
                     id(mro),tuple(mro_edges),tuple(members)))
    return _NamedOwnerSeal(tuple(sorted(rows)),tuple(owners))


# SOURCE ONLY complete original cohort integration; historical main refuses.
class _OwnerEvidence:
    """Explicit compatibility boundary: native values sealed once, event refs repeat.
    It does not answer queries or reconstruct executable identity.
    """
    def __init__(self,s,store):self.s=s;self.store=store;self.owner_runtime=[]
    def current_scope(self,scope=None):return self.store.scope(_evidence_scope(self.s)if scope is None else scope)
    def enter(self,kind,role,operation,arguments,scope=None):
        raw=(arguments,scope);self.owner_runtime.append(raw)
        sc=self.current_scope(scope);owner=self.store.owner(arguments,role='arguments-before',scope=sc,version=0,route=role+'.'+operation)
        return self.store.enter(kind,role,operation,sc,args_owner=owner)
    def leave(self,token,*,arguments=None,value=None,error=None):
        self.owner_runtime.append((arguments,value,error))
        kind,role,operation,sc,version=self.store.pending[token]
        args=self.store.owner(arguments,role='arguments-after',scope=sc,version=1,route=role+'.'+operation)
        val=None if error is not None and value is None else self.store.owner(value,role='result',scope=sc,version=1,route=role+'.'+operation)
        return self.store.leave(token,args_owner=args,value_owner=val,error=error)
    def snapshot(self,kind,role,operation,value,scope=None):
        self.owner_runtime.append((value,scope));sc=self.current_scope(scope)
        owner=self.store.owner(value,role='snapshot',scope=sc,route=role+'.'+operation)
        return self.store.snapshot(kind,role,operation,sc,owner)


def _evidence_scope(s):
    scope=dict(s.evidence_scope);context=s.profile_query_context
    if type(context)is dict:scope['profile_id']=context['id']
    return scope


def _evidence_invoke(s,kind,role,operation,args,action,after=None,case_id=None):
    previous=dict(s.evidence_scope)
    if case_id is not None:s.evidence_scope['case_id']=case_id
    s.evidence_runtime_owners.append((action,args,after));action_seal=function_owner_seal(action)
    token=s.policy(lambda:s.evidence.enter(kind,role,operation,args))
    try:value=action()
    except BaseException as error:
        s.evidence_runtime_owners.append(error)
        try:
            final_args=args if after is None else after()
            s.policy(lambda:s.evidence.leave(token,arguments=final_args,error=error))
            s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after fault'))
        except BaseException as secondary:
            s.evidence_runtime_owners.append(secondary)
            if s.first_fault is None:s.first_fault=secondary
        s.fault_gate();raise
    else:
        final_args=args if after is None else after()
        s.policy(lambda:s.evidence.leave(token,arguments=final_args,value=value))
        s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after return'))
        return value
    finally:s.evidence_scope=previous


def _profile_evidence(s,profile_id,origin,declared_arguments=None):
    scope=_evidence_scope(s);scope.update(profile_id=profile_id,origin=origin)
    tokens=[];queries=[];produced=[];preimages=[];registered=[]
    callback_owners=[scope,tokens,declared_arguments,queries,produced,preimages,registered]
    s.evidence_runtime_owners.append(callback_owners)
    def hook(stage,state,request,value,error):
        # Full ACTUAL state/receipt/preimage/Work/error owners are retained before
        # the first new sealing checkpoint. Serialized IDs never recreate them.
        callback_owners.append((state,request,value,error))
        def action():
            store=s.evidence.store;sc=store.scope(scope);work=state['work']
            counters=dict(stage=state['stage'],failed_stage=state['failed_stage'],attempted_queries=state['attempted_queries'],
                produced_receipt_count=state['produced_receipt_count'],preimage_completed_count=state['preimage_completed_count'],
                delivered_receipt_count=state['delivered_receipt_count'],attempted_work=None if work is None else work.work,
                data_items=None if work is None else work.items)
            if stage in('PROFILE_ENTER','QUERY_ENTER','CUSTODY_ENTER'):
                kind=stage[:-6];argument=declared_arguments if kind=='PROFILE'else request if kind=='QUERY'else value
                owner=store.owner(argument,role='arguments-before',scope=sc,version=0,route='implicit.'+kind.lower())
                token=store.enter(kind,'implicit',kind.lower(),sc,args_owner=owner);tokens.append((kind,token,owner))
                if kind=='QUERY':queries.append(dict(request=owner,receipt=None,preimage=None,registered=False))
            elif stage in('PROFILE_RETURN','PROFILE_RAISE','QUERY_RETURN','QUERY_RAISE','CUSTODY_RETURN','CUSTODY_RAISE'):
                kind=stage.rsplit('_',1)[0];need(tokens and tokens[-1][0]==kind,'exact component event nesting')
                unused,token,args=tokens[-1]
                if kind=='QUERY':
                    current=queries[-1];returned=current['receipt']
                    # A failed query still retains its exact active raw lifetime
                    # in the final failed profile view and all original owners.
                    if error is not None:
                        returned=store.owner(dict(active_query=state['active_query'],counters=counters),role='failed-query-lifetime',scope=sc,version=1,route='implicit.query')
                    store.leave(token,args_owner=args,value_owner=returned,error=error);queries.pop()
                elif kind=='PROFILE':
                    ordinary=_ordinary_profile_lifetime(state)
                    # Exactly one complete end-of-profile value capture. It is
                    # never copied into each QUERY event or reconciliation row.
                    final=dict(result=value,lifetime=ordinary)
                    owner=store.owner(final,role='profile-final-lifetime',scope=sc,version=1,route='implicit.with_profile')
                    store.leave(token,args_owner=args,value_owner=owner,error=error)
                else:
                    owner=store.owner(value,role='custody-result',scope=sc,version=1,route='implicit.custody')
                    store.leave(token,args_owner=args,value_owner=owner,error=error)
                tokens.pop()
            else:
                current=queries[-1]if queries else None
                if stage=='QUERY_REGISTERED':
                    need(current is not None,'registered query occurrence');current['registered']=True;registered.append(current['request'])
                elif stage=='QUERY_PRODUCED':
                    need(current is not None and current['receipt']is None,'one raw production per query')
                    current['receipt']=store.owner(value,role='raw-produced-receipt',scope=sc,version=state['attempted_queries'],route='implicit.query')
                    produced.append(current['receipt'])
                elif stage=='QUERY_PREIMAGE':
                    need(current is not None and current['preimage']is None,'one immutable preimage per query')
                    current['preimage']=store.owner(value,role='completed-typed-preimage',scope=sc,version=state['attempted_queries'],route='implicit.query')
                    preimages.append(current['preimage'])
                version=None
                if stage in('RECONCILE_VERSION','RECONCILE_RESULT'):
                    # Complete original typed before/after values, including
                    # negative changed values; no summary/digest stand-in.
                    version=store.owner(value,role='reconciliation-version',scope=sc,version=state['attempted_queries'],route='implicit.reconcile')
                payload=dict(stage=stage,request_owner=None if current is None else current['request'],
                    receipt_owner=None if current is None else current['receipt'],preimage_owner=None if current is None else current['preimage'],
                    version_owner=version,counters=counters)
                payload=tuple(payload[key]if key!='counters'else tuple(counters.values())for key in payload)
                owner=store.owner(payload,role='profile-state-reference',scope=sc,version=state['attempted_queries'],route='implicit.'+stage)
                store.snapshot('PROFILE_STATE','implicit',stage,sc,owner,version=state['attempted_queries'])
            return None
        return s.policy(action)
    callback_owners.append(hook)
    if not hasattr(s,'evidence_callback_seals'):s.evidence_callback_seals=[]
    s.evidence_callback_seals.append((hook,function_owner_seal(hook)));return hook


def _linked_raw_bank_verifier(s,bank):
    s.guard();raw=checked(bank['pin'],134217728)
    need(type(bank['raw_hex'])is str and raw.hex()==bank['raw_hex'],'full unchanged raw bank bytes')
    decoded=json.loads(raw)
    s.policy(lambda:need(argument_bytes(decoded)==argument_bytes(bank['decoded']),'independent full raw parser and strict bank join'))
    return None


def _linked_final_custody(s):
    final_profile_custody(s)
    for callback,seal in s.evidence_callback_seals:
        s.check();s.policy(lambda callback=callback,seal=seal:need(function_owner_seal(callback)==seal,'all original evidence callback owners through final custody'))
    for role in('linked','schema','cursor','writer'):need(role in s.modules,'complete new Source closure')
    s.guard();s.fault_gate();return None


def run_owner_candidate(s,inputs,batch_inputs,raw_banks,manifest,*,store_limits,writer,physical_limit,expanded_limit):
    """Full15/33+28/55 candidate only; Root outer once/admission remains separate."""
    need(s.evidence is None and not s.rows and not s.profile_rows and not s.batch_diagnostics,'fresh whole ordinary invocation')
    need(type(physical_limit)is int and 0<physical_limit<=134217728 and type(expanded_limit)is int and 0<expanded_limit<=134217728,'unchanged128MiB ceilings')
    need(manifest['outer_limits']==OUTER_LIMITS and manifest['component_limits']==COMPONENT_LIMITS and manifest['profile_limits']==PROFILE_LIMITS and manifest['profile_query_chunk']==128 and manifest['profile_granularity']==PROFILE_GRANULARITY,'unchanged complete limits and scopes')
    need(manifest['source_pins']==s.plan['sources']and manifest['predecessor_worker_sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03','new full Source closure/provenance')
    need(type(raw_banks)is list and len(raw_banks)==2 and argument_bytes(raw_banks[0]['decoded'])==argument_bytes(inputs)and argument_bytes(raw_banks[1]['decoded'])==argument_bytes(batch_inputs),'both full unchanged bank arguments')
    def retain(owner):s.evidence_runtime_owners.append(owner);return None
    linked=s.modules['linked'];cursor=s.modules['cursor'];schema=s.modules['schema']
    store=linked.Store(check=s.check,limits=store_limits,retain=retain)
    s.evidence=_OwnerEvidence(s,store)
    s.evidence_runtime_owners.extend((store,s.evidence,writer,retain,manifest,raw_banks,store_limits))
    for bank in raw_banks:_linked_raw_bank_verifier(s,bank)
    s.batch_original_inputs=inputs;s.batch_original_inputs_preimage=argument_bytes(inputs)
    packet=qualify(s,inputs,batch_inputs);_linked_final_custody(s)
    # Complete native packet retained; no eager clone/JSON/tree expansion here.
    catalog=linked.build_catalog(packet,store.work.step)
    store.close(packet=packet,manifest=manifest,raw_banks=raw_banks,catalog=catalog)
    def verify_bank(bank):return _linked_raw_bank_verifier(s,bank)
    def verify_custody():return _linked_final_custody(s)
    expected=dict(packet=packet,manifest=manifest,raw_banks=raw_banks,catalog=catalog,verify_raw_bank=verify_bank,verify_live_custody=verify_custody)
    state=dict(packet=packet,catalog=catalog,store=store,expected=expected,receipt=None,validation=None,document=None,wire=None,position=0,producer_calls=0,writer_result=None,error=None)
    s.evidence_runtime_owners.extend((state,verify_bank,verify_custody))
    def producer():
        # Writer must claim BOTH physical/logical aggregate leases before this
        # first full canonicalization/parser operation. No hidden warm store.
        s.check();state['producer_calls']+=1
        if state['wire']is None:
            state['receipt']=store.encode();state['wire']=state['receipt']['wire']
            document=cursor.parse(state['wire'],work=store.work,retain=retain);state['document']=document
            state['validation']=schema.validate_document(document,expected=expected,retain=retain)
            _linked_final_custody(s)
        wire=state['wire'];position=state['position']
        if position==len(wire):return None
        stop=min(position+65536,len(wire));chunk=wire[position:stop];state['position']=stop
        return(chunk,len(chunk))  # EXPLICIT changed/unadopted G1 unique wire charge.
    s.evidence_runtime_owners.append(producer)
    try:
        output=writer.write_record('canonical-complete-owner-evidence.gctsowners',producer,physical_limit=physical_limit,expanded_limit=expanded_limit,kind='bulk')
        state['writer_result']=output
        need(state['validation']is not None and state['position']==len(state['wire']),'whole complete evidence, never partial admission')
        _linked_final_custody(s);s.check()
        metadata={key:value for key,value in state['receipt'].items()if key!='wire'}
        return dict(schema='immutable-whole-owner-worker-candidate-v1',output=output,candidate_metadata=metadata,validation=state['validation'],store_final_metrics=store.work.metrics(),
            normal_cases=15,legacy_diagnostics=33,new_groups=28,new_variants=55,profile_metrics=profile_metrics(s),root_callbacks_at_return=s.root_calls,
            root_callbacks_in_packet_are_preencoding_cutoff=True,full_pipeline_qualified=False,G1_adopted=False,resource_accepted=False,runtime_qualified=False,mathematical_authority=False)
    except BaseException as error:
        state['error']=error;s.evidence_runtime_owners.append(error);s.fault_gate();raise


# SOURCE ONLY shared outer protocol, textually included in each executable Source.
_BASELINE_ROLES=('worker','implicit','graph','selector','runner','observer','linked','schema','cursor','writer')
_PLAN_FIELDS={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization','subject_closure','store_limits','allocations','runtime_signature','policy'}
_ORIGINAL_LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
_G1='PROPOSED_G1_IMMUTABLE_FULL_VALUES_ALL_OWNER_EVENT_TAPE_REFERENCES_V1'
_OUTER_RAW_OWNERS=[]
_OUTER_PREIMAGES={}

def _on(ok,message):
    if not ok:raise ValueError(message)

def _oc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _subject_bytes(value):return json.dumps(value,sort_keys=False,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _op(path,raw):return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def _or(pin,cap=16777216):
    _OUTER_RAW_OWNERS.append(pin)
    _on(type(pin)is dict and set(pin)=={'path','bytes','sha256'}and type(pin['path'])is str and type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and len(pin['sha256'])==64,'exact bounded raw pin')
    p=Path(pin['path']);_on(not p.name.endswith('.partial'),'partial content is never opened')
    _on(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),'canonical regular pinned file')
    raw=p.read_bytes()
    if _op(p,raw)!=pin:
        _OUTER_RAW_OWNERS.append(raw);_on(False,'full path/size/SHA256 Source and input custody')
    key=(pin['path'],pin['sha256']);_OUTER_PREIMAGES.setdefault(key,raw)
    return raw

def _oj(pin,cap=16777216):return json.loads(_or(pin,cap))
def _runtime_signature():
    return dict(version=sys.version,version_info=list(sys.version_info),implementation=sys.implementation.name,cache_tag=sys.implementation.cache_tag,platform=sys.platform,byteorder=sys.byteorder,isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)

def _complete_custody(contract,gate):
    plan=contract['plan'];gate();_or(plan['python'],67108864)
    for pin in plan['sources'].values():gate();_or(pin)
    for key in('declaration','runtime_closure','subject_closure','policy','authorization'):gate();_or(plan[key])
    for item in plan['inputs']:gate();_or(item['pin'],134217728)
    for pin in contract['closure']['stdlib_files']:gate();_or(pin)
    for owner in contract['subject']['owners'].values():gate();_or(owner['source'],134217728)
    gate();_on(_runtime_signature()==plan['runtime_signature'],'entire declared runtime signature retained')


def _contract(plan_path,own_role):
    raw=Path(plan_path).read_bytes();_OUTER_RAW_OWNERS.append(raw);_on(len(raw)<=16777216,'bounded plan')
    plan=json.loads(raw);_OUTER_RAW_OWNERS.append(plan);pin=_op(plan_path,raw)
    _on(type(plan)is dict and set(plan)==_PLAN_FIELDS and plan['schema']=='ROOT-whole-owner-evidence-plan-v1','exact new fifteen-field plan')
    _on(plan['limits']==_ORIGINAL_LIMITS and type(plan['sources'])is dict and set(plan['sources'])==set(_BASELINE_ROLES),'unchanged original caps and exact baseline roles')
    _on(_op(__file__,Path(__file__).read_bytes())==plan['sources'][own_role],'this exact executable Source role')
    _on(_runtime_signature()==plan['runtime_signature']and sys.platform=='darwin'and sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'exact isolated pinned Darwin runtime')
    _on(Path(sys.executable).resolve()==Path(plan['python']['path']),'actual interpreter path')
    declaration=_oj(plan['declaration']);closure=_oj(plan['runtime_closure']);subject=_oj(plan['subject_closure']);policy=_oj(plan['policy'])
    _on(declaration['schema']=='ROOT-whole-owner-evidence-declaration-v1'and closure['schema']=='ROOT-whole-owner-evidence-runtime-closure-v1','new exact declaration/closure identity')
    for key in('limits','store_limits','allocations','runtime_signature','inputs','policy','subject_closure'):_on(_subject_bytes(declaration[key])==_subject_bytes(plan[key]),'complete declaration binding '+key)
    _on(closure['python']==plan['python']and closure['sources']==plan['sources']and closure['declaration']==plan['declaration']and closure['subject_closure']==plan['subject_closure']and closure['runtime_signature']==plan['runtime_signature'],'complete runtime closure joins')
    _on(closure['complete_subject_owner_closure']==subject and closure['qualification_policy']==policy,'full literal subject owner map and policy embedded in runtime closure, not only public pins')
    _on(_subject_bytes(closure['sources'])==_subject_bytes(plan['sources'])and _subject_bytes(closure['python'])==_subject_bytes(plan['python']),'strict insertion-order Source/runtime bindings')
    _on(type(closure['stdlib_files'])is list and 0<len(closure['stdlib_files'])<=1024,'explicit complete stdlib/extension fingerprint list')
    keys=('work','nodes','references','roots','wire_bytes','record_bytes','depth','integer_bits','string_bytes','owners','events','key_items')
    _on(type(plan['store_limits'])is dict and set(plan['store_limits'])==set(keys)and all(type(x)is int and x>0 for x in plan['store_limits'].values()),'Root must declare complete finite new store limits; no inferred fit')
    _on(plan['store_limits']['wire_bytes']<=134217728,'unchanged complete wire cap')
    allocations=plan['allocations'];_on(type(allocations)is dict and set(allocations)=={'canonical_bytes','result_bytes'}and all(type(x)is int and 0<x<=134217728 for x in allocations.values()),'exact complete output leases')
    _on(allocations['canonical_bytes']+allocations['result_bytes']+9437184+3*4194304+65536<=134217728,'all leases inside original128MiB including reserve/log/header/summary; opaque prior bytes additionally checked by writer')
    _on(type(plan['inputs'])is list and len(plan['inputs'])==2 and plan['inputs'][0]['role']=='original-bank'and plan['inputs'][1]['role']=='new-diagnostic-bank','whole ordered two-bank input contract')
    _on(subject['schema']=='ROOT-complete-subject-owner-closure-v1'and subject['subject_kind']=='ORIGINAL_FULL_EVIDENCE_COHORT_ONLY','no silent full physical VM closure claim')
    _on(subject['baseline_sources']==plan['sources']and subject['executed_owner_roles']==list(_BASELINE_ROLES)and subject['adapter']is None,'exact executed baseline and no implicit VM adapter')
    _on(type(subject['owners'])is dict and 0<len(subject['owners'])<=4096 and set(subject['owners'])==set(subject['declared_owner_roles']),'complete exact extensible owner map')
    for role,owner in subject['owners'].items():
        _on(type(role)is str and role and type(owner)is dict and set(owner)=={'source','execution','depends_on'},'exact full-subject owner record')
        _on(type(owner['depends_on'])is list and all(x in subject['owners']for x in owner['depends_on']),'all declared owner dependencies exist')
        _on(owner['execution']==('BASELINE_EXECUTED'if role in _BASELINE_ROLES else'PIN_ONLY_NOT_EXECUTED'),'additional owners never falsely treated as executed')
        if role in _BASELINE_ROLES:_on(owner['source']==plan['sources'][role],'baseline owner raw pin join')
    _on(all(role in subject['owners']for role in _BASELINE_ROLES),'all baseline owners present')
    _on(sum(owner['source']['bytes']for owner in subject['owners'].values())<=134217728 and sum(pin['bytes']for pin in closure['stdlib_files'])<=134217728,'finite complete raw owner/stdlib preimage corpus; no hidden source cache')
    _on(policy['schema']=='ROOT-proposed-G1-qualification-policy-v1'and policy['author_identity']=='/root'and policy['purpose']=='UNADOPTED_G1_RESOURCE_EXPERIMENT_ONLY'and policy['gate_contract']==_G1,'explicit Root policy required; no local policy adoption')
    for obj in(policy,subject,declaration):
        _on(obj['G1_adopted']is False and obj['full_pipeline_qualified']is False,'all broader authority false')
    _on(policy['resource_admission']is False and policy['old_G0_claim']is False,'qualification candidate cannot adoptG1 or rescueG0')
    subject_plan={k:v for k,v in plan.items()if k!='authorization'};digest=hashlib.sha256(_subject_bytes(subject_plan)).hexdigest();auth=_oj(plan['authorization'])
    _on(set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['schema']=='ROOT-whole-owner-evidence-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==digest,'fresh exact-subject Root max-one grant required')
    review=_oj(auth['review'])
    _on(review['schema']=='whole-owner-complete-Source-prospective-review-v1'and review['reviewer_identity']=='/root/recovered_batch_review'and review['review_passed']is True and review['source_only']is True and review['component_calls']==0 and type(review['component_calls'])is int and review['actual_execution_authorized']is False and _subject_bytes(review['subject'])==_subject_bytes(subject_plan) and review['subject_sha256']==digest,'full exact independently reviewed subject; specific delta receipts alone insufficient')
    _on(review['full_inner_composition_passed']is True and review['full_outer_composition_passed']is True and review['whole_resource_bounds_passed']is True and review['G1_adopted']is False,'all missing full review/fit obligations block launch')
    contract=dict(plan=plan,plan_pin=pin,raw=raw,declaration=declaration,closure=closure,subject=subject,policy=policy,authorization=auth,review=review,subject_sha256=digest)
    _OUTER_RAW_OWNERS.append(contract);_complete_custody(contract,lambda:None);return contract


class _OuterMetadata:
    """Outer9MiB splits into runner8MiB and observer1MiB; no unleased writer."""
    def __init__(self,folder,cap,gate,external_bytes=None):self.folder=Path(folder);self.cap=cap;self.used=0;self.gate=gate;self.external_bytes=external_bytes;self.owners=[];self.names=set()
    def write(self,name,value):
        self.owners.append(value);self.gate();raw=_oc(value)+b'\n';self.owners.append(raw)
        _on(type(name)is str and name not in self.names and '/'not in name and not name.endswith('.partial'),'spent outer metadata name')
        self.names.add(name);outside=0 if self.external_bytes is None else self.external_bytes()
        _on(type(outside)is int and outside>=0 and self.used+len(raw)+outside<=self.cap,'aggregate original outer metadata reservation including captured logs')
        self.used+=len(raw);path=self.folder/name;fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as out:
            _on(out.write(raw)==len(raw),'complete once metadata write');out.flush();os.fsync(out.fileno())
        self.gate();return _op(path,raw)


class _OwnedChild:
    """Bounded pipe drains; cap overflow fails, never truncates a complete log.
    No hostile process/PID-race security claim beyond the owned exclusive run.
    """
    def __init__(self,folder,caps,gate,retainer,total_guard=None):
        self.folder=Path(folder);self.caps=dict(caps);self.gate=gate;self.total_guard=total_guard;self.process=None;self.logs={};self.sizes={name:0 for name in caps};self.selector=None;self.eof=set();self.reaped=False;self.status=None;self.usage=None;self.absent_seen=False;self.reappeared=False;self.owners=[retainer];self.events=[];self.secondary=[]
        retainer(self)
    def launch(self,command,environment,cwd):
        self.owners.extend((command,environment));self.gate()
        for name in self.caps:self.logs[name]=(self.folder/(name+'.bin')).open('xb')
        self.process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=environment,cwd=str(cwd))
        self.selector=selectors.DefaultSelector()
        for name in self.caps:
            stream=getattr(self.process,name);os.set_blocking(stream.fileno(),False);self.selector.register(stream,selectors.EVENT_READ,name)
        return self.process.pid
    def absent(self):
        _on(self.process is not None,'owned launch exists')
        try:os.killpg(self.process.pid,0);gone=False
        except ProcessLookupError:gone=True
        if self.absent_seen and not gone:self.reappeared=True;raise ValueError('owned group reappeared; no signal reuse')
        self.absent_seen=self.absent_seen or gone;return gone
    def reap(self):
        if self.reaped:return True
        got,status,usage=os.wait4(self.process.pid,os.WNOHANG)
        if got:self.reaped=True;self.status=status;self.usage=usage;self.process.returncode=os.waitstatus_to_exitcode(status)
        return self.reaped
    def drain(self,timeout=.02):
        self.gate()
        for key,mask in self.selector.select(timeout):
            self.gate();name=key.data;raw=os.read(key.fd,65536);self.owners.append(raw)
            if not raw:self.eof.add(name);self.selector.unregister(key.fileobj);key.fileobj.close();continue
            _on(self.sizes[name]+len(raw)<=self.caps[name],'whole bounded log overflow: failed qualification')
            if self.total_guard is not None:self.total_guard(len(raw))
            written=self.logs[name].write(raw);_on(type(written)is int and written==len(raw),'whole bounded log short write')
            self.sizes[name]+=written
        return self.reap()and len(self.eof)==len(self.caps)and self.absent()
    def close(self):
        for handle in self.logs.values():
            try:
                if not handle.closed:handle.flush();handle.close()
            except BaseException as error:self.secondary.append(error)
        if self.selector is not None:
            try:self.selector.close()
            except BaseException as error:self.secondary.append(error)
    def cleanup(self,deadline):
        if self.process is None:return False
        def note(kind,error=None):
            if len(self.events)<32:self.events.append(dict(kind=kind,time_ns=NOW(),error_type=None if error is None else type(error).__name__))
        polls=0
        for sig in(signal.SIGTERM,signal.SIGKILL):
            if NOW()>=deadline:break
            try:
                self.reap()
                if self.absent():break
                os.killpg(self.process.pid,sig);note('signal-'+str(sig))
            except BaseException as error:self.secondary.append(error);note('cleanup-error',error)
            stop=min(deadline,NOW()+1000000000)
            while NOW()<stop and polls<2048:
                polls+=1
                try:
                    self.reap()
                    if self.absent():break
                except BaseException as error:self.secondary.append(error);note('probe-error',error)
                time.sleep(min(.02,max(0,(stop-NOW())/1e9)))
        try:self.reap();complete=self.reaped and self.absent()and not self.reappeared
        except BaseException as error:self.secondary.append(error);complete=False
        self.close();return complete and NOW()<deadline

# SOURCE ONLY complete outer entry; no plan/grant is authored by this Source.
_OUTER_WORKER_STATE=None

def _writer_pin(actual,receipt):
    need(receipt['complete']is True and receipt['stdlib_operations']is True and receipt['diagnostic_only']is False,'whole real stdlib output only')
    return dict(path=str(actual/receipt['name']),bytes=receipt['bytes'],sha256=receipt['sha256'])

def _writer_json(state,name,value,cap,kind):
    state['owners'].append(value);raw=canonical(value)+b'\n';state['owners'].append(raw)
    need(len(raw)<=cap,'complete bounded result/header JSON')
    position=0
    def producer():
        nonlocal position
        if position==len(raw):return None
        stop=min(position+65536,len(raw));chunk=raw[position:stop];position=stop;return(chunk,len(chunk))
    state['owners'].append(producer)
    receipt=state['writer'].write_record(name,producer,physical_limit=cap,expanded_limit=cap,kind=kind)
    state['owners'].append(receipt);return _writer_pin(state['s'].actual,receipt)

def _qualification_summary(s,output,evidence):
    counts=dict(compiler_calls=s.started.get('implicit.build_palette_query',0)+s.calls('selector'),search_calls=s.started.get('graph.search',0),verifier_calls=s.oracle_work,oracle_calls=s.oracle_work)
    small=s.rows[:4];large=s.rows[4];graphs=s.rows[5:]
    q=dict(schema='implicit-palette-graph-component-candidate-v1',status='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE',outputs=[output],case_ids=[r['id']for r in s.rows],rows=[dict(id=r['id'],complete=r['complete'])for r in s.rows],diagnostics=s.diagnostics,diagnostic_ids=[r['id']for r in s.diagnostics],profile_metrics=profile_metrics(s),
        batch_diagnostics=[dict(id=g['id'],subject=g['subject'],recipe=g['recipe'],status=g['status'],complete=g['complete'],variants=[dict(id=v['id'],status=v['status'],complete=v['complete'],expected=v['expected'])for v in g['variants']])for g in s.batch_diagnostics],batch_diagnostic_ids=[g['id']for g in s.batch_diagnostics],
        profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=PROFILE_QUERY_CHUNK,small_palettes=len(small),small_mask_queries=sum(len(r['queries'])for r in small),selected_small_witnesses=sum(r['selected_witnesses']for r in small),large_logical_tiles=large['total_count']['count'],graph_cases=len(graphs),graph_domain_checks=sum(r['domain_checks']for r in graphs),rollback_comparisons=sum(o['snapshot']['reason']=='AFTER_ROLLBACK'for r in graphs for o in r['observations']),palette_query_calls=s.calls('implicit'),root_check_calls=s.root_calls,
        root_check_calls_scope='Genuine Root.check cutoff before result/header; every later positive callback shares same400m ceiling. New store units and negative metadata gates are separate.',
        full_pipeline_qualified=False,mathematical_proof_accepted=False,fixed_FOL_palette_qualified=False,gcts_rl_advantage_established=False,learned_pair_markings=False,trained_RL=False,complete_physical_VM=False,proof_discovery=False,evidence_parent=evidence,**counts)
    return q,counts


def main(plan_path):
    global _OUTER_WORKER_STATE
    state=dict(owners=[plan_path],s=None,writer=None,primary=None,secondaries=[],contract=None,negative_gate_calls=0,negative_summary=None)
    _OUTER_WORKER_STATE=state
    try:
        c=_contract(plan_path,'worker');state['contract']=c;plan=c['plan'];actual=Path(plan['actual_directory'])
        need(actual.is_dir()and actual==actual.resolve(),'runner-owned fresh actual directory')
        consumed=_oj(_op(actual/'CONSUMED.json',(actual/'CONSUMED.json').read_bytes()))
        need(consumed['schema']=='whole-owner-evidence-consumed-v1'and consumed['plan']==c['plan_pin']and consumed['invocation_id']==plan['invocation_id']and consumed['subject_sha256']==c['subject_sha256']and consumed['maximum_worker_launches']==1 and type(consumed['maximum_worker_launches'])is int and consumed['consumed_before_Popen']is True,'fresh consumed exact plan before worker launch')
        need(type(consumed['began_ns'])is int and consumed['work_deadline_ns']==consumed['began_ns']+180000000000 and consumed['overall_deadline_ns']==consumed['began_ns']+210000000000,'original absolute epochs')
        # Parent must publish the complete immutable launch receipt before any
        # worker writer census; no concurrent unleased parent metadata writer.
        launch_path=actual/'WORKER_LAUNCH.json';until=min(consumed['work_deadline_ns'],NOW()+1000000000)
        while not launch_path.exists():need(NOW()<until,'bounded parent launch handshake');time.sleep(.001)
        launch=_oj(_op(launch_path,launch_path.read_bytes()))
        need(launch['schema']=='whole-owner-worker-launch-v1'and launch['plan']==c['plan_pin']and launch['invocation_id']==plan['invocation_id']and launch['worker_pid']==os.getpid()and launch['worker_pgid']==os.getpid()and launch['runner_pid']==os.getppid()==consumed['runner_pid'],'exact parent-created new-session worker ownership')
        s=object.__new__(Session);state['s']=s;state['owners'].append(s)
        Session.__init__(s,plan,c['plan_pin'],consumed,actual)
        s.check();need(c['declaration']['component_limits']==COMPONENT_LIMITS and c['declaration']['profile_limits']==PROFILE_LIMITS and c['declaration']['checkpoint_limit']==CHECKPOINT_LIMIT and c['declaration']['profile_query_chunk']==128 and c['declaration']['profile_granularity']==PROFILE_GRANULARITY,'complete original component/private limits and scopes')
        def positive():s.check();return None
        def negative(primary):
            state['owners'].append(primary);state['negative_gate_calls']+=1
            need(NOW()<s.overall_deadline,'metadata-only negative closure before original210')
            need(primary is state['primary']or primary is s.first_fault,'exact retained primary, never public owner classification')
            return None
        def custody(phase,primary):
            if phase=='positive':s.guard();return None
            negative(primary)
            try:
                _complete_custody(c,lambda:negative(primary))
                need(callable_seal(sys.modules[__name__])==s.worker_function_seal,'negative complete worker function custody')
                for role,module in s.modules.items():need(module.__file__==plan['sources'][role]['path']and callable_seal(module)==s.seals[role],'negative module origin/code/default/closure custody')
            except BaseException as error:
                state['owners'].append(error)
                if s.first_fault is None:s.first_fault=error
                raise
            return None
        state['owners'].extend((positive,negative,custody))
        s.load('writer');writer_module=s.modules['writer']
        writer=object.__new__(writer_module.AggregateWriter);state['writer']=writer;state['owners'].append(writer)
        writer_module.AggregateWriter.__init__(writer,str(actual),check=positive,custody=custody,first_fault=lambda:s.first_fault,negative_gate=negative,clock=NOW,work_deadline_ns=s.work_deadline,overall_deadline_ns=s.overall_deadline)
        _writer_json(state,'WORKER_CONSUMED.json',dict(schema='whole-owner-worker-consumed-v1',plan=c['plan_pin'],pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,maximum_invocations=1),1048576,'bulk')
        def audit(event,args):
            if event in FORBIDDEN_EVENTS:s.denied.append(event);s.policy(lambda:need(False,'forbidden process/network/dlopen in scientific worker'))
        state['owners'].append(audit);sys.addaudithook(audit)
        for role in('selector','implicit','graph','linked','cursor','schema'):s.load(role)
        raw_banks=[]
        for item in plan['inputs']:
            raw=_or(item['pin'],134217728);decoded=json.loads(raw);state['owners'].extend((raw,decoded))
            raw_banks.append(dict(role=item['role'],pin=item['pin'],raw_hex=raw.hex(),decoded=decoded))
        inputs=raw_banks[0]['decoded'];batch=raw_banks[1]['decoded'];state['owners'].append(raw_banks)
        need(inputs['schema']=='implicit-palette-inputs-v1'and batch['schema']=='implicit-batch-summary-diagnostics-v1','full original banks')
        case_ids=[r['id']for r in inputs['small_palettes']]+[inputs['large_palette']['id']]+[r['id']for r in inputs['graph_cases']]
        need(case_ids==c['declaration']['case_ids']and len(case_ids)==15 and [r['id']for r in inputs['diagnostics']]==c['declaration']['diagnostic_ids']and len(inputs['diagnostics'])==33 and batch['groups']==c['declaration']['batch_diagnostic_groups']and len(batch['groups'])==28 and sum(len(g['variants'])for g in batch['groups'])==55,'all15/33+28/55 literal population joins')
        manifest=dict(schema='immutable-whole-evidence-manifest-v1',invocation_id=plan['invocation_id'],plan=plan,declaration=c['declaration'],runtime_closure=c['closure'],source_pins=plan['sources'],python=plan['python'],stdlib_pins=c['closure']['stdlib_files'],outer_limits=plan['limits'],component_limits=c['declaration']['component_limits'],profile_limits=c['declaration']['profile_limits'],profile_granularity=PROFILE_GRANULARITY,profile_query_chunk=128,predecessor_worker_sha256='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03',terminal_policy='CANDIDATE_ONLY_REQUIRES_ROOT_EXTERNAL_TERMINAL_ADMISSION',scope='Whole original evidence cohort only. Full subject owner closure/policy pins are bound in plan and runtime_closure. Additional owners are PIN_ONLY, no initialized physical VM or theorem claim.')
        state['owners'].append(manifest)
        evidence=run_owner_candidate(s,inputs,batch,raw_banks,manifest,store_limits=plan['store_limits'],writer=writer,physical_limit=plan['allocations']['canonical_bytes'],expanded_limit=plan['allocations']['canonical_bytes'])
        state['owners'].append(evidence);output=_writer_pin(actual,evidence['output']);s.output_pins.append(output)
        q,counts=_qualification_summary(s,output,{k:v for k,v in evidence.items()if k!='output'})
        zeros=dict(Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,opaque_program_decodes=0)
        payload=dict(schema='whole-owner-evidence-result-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],subject_closure=plan['subject_closure'],policy=plan['policy'],qualification=q,outputs=[output],denied_events=s.denied,canonical_stored_bytes=output['bytes'],G1_canonical_logical_bytes=output['bytes'],gate_contract=_G1,old_G0_unfolding_charged=False,G1_adopted=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,**counts,**zeros)
        result=_writer_json(state,'result.json',payload,plan['allocations']['result_bytes'],'result')
        s.guard();_complete_custody(c,s.check);_linked_final_custody(s)
        logical=output['bytes']+result['bytes'];need(logical<=134217728,'whole stored and proposed G1 logical bytes')
        header=dict(schema='whole-owner-evidence-worker-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=c['plan_pin'],began_ns=s.began,work_deadline_ns=s.work_deadline,overall_deadline_ns=s.overall_deadline,pid=os.getpid(),ppid=os.getppid(),worker_entry_ns=ENTRY_NS,result=result,outputs=[output],stored_logical_result_bytes=logical,G1_logical_result_bytes=logical,gate_contract=_G1,old_G0_unfolding_charged=False,G1_adopted=False,outer_metadata_reservation=9437184,finite_encoding_candidate=True,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,root_check_calls_cutoff=s.root_calls,positive_worker_completed_ns=NOW(),writer_ledger=writer.ledger.snapshot(),**zeros)
        _writer_json(state,'worker-receipt.json',header,4194304,'header');s.guard();s.check()
        final=dict(schema='whole-owner-worker-final-stdout-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],root_check_calls=s.root_calls,negative_metadata_gate_calls=state['negative_gate_calls'],completed_ns=NOW(),G1_adopted=False,full_pipeline_qualified=False,mathematical_authority=False)
        state['owners'].append(final);print(json.dumps(final,sort_keys=True),flush=True)
        need(NOW()<s.work_deadline,'whole positive worker body and stdout before180');return 0
    except BaseException as error:
        state['owners'].append(error);s=state['s'];primary=s.first_fault if s is not None and getattr(s,'first_fault',None)is not None else error
        if s is not None and getattr(s,'first_fault',None)is None:
            try:s.first_fault=primary
            except BaseException as secondary:state['secondaries'].append(secondary)
        state['primary']=primary;state['owners'].append(primary)
        writer=state['writer']
        if writer is not None and hasattr(writer,'ledger')and s is not None:
            try:
                raw=canonical(_failure_summary_record(s,primary))+b'\n';state['owners'].append(raw)
                state['negative_summary']=writer.attempt_negative_summary(primary,raw)
            except BaseException as secondary:state['secondaries'].append(secondary)
        # No full-prefix serialization, partial parse/repair, retry, or second
        # output grants. Actual owner graphs remain alive through process exit.
        return 2

if __name__=='__main__':
    need(len(sys.argv)==2,'one new independently reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
