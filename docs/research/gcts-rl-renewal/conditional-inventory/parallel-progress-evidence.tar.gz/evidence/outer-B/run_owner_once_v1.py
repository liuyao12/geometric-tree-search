"""SOURCE ONLY complete proposed owner-evidence once runner.
"""
import time
NOW=time.monotonic_ns
BEGAN=NOW()
import hashlib
import json
import os
from pathlib import Path
import signal
import selectors
import subprocess
import sys
VERSION='whole-owner-evidence-once-runner-v1'
# SOURCE ONLY shared outer protocol, textually included in each executable Source.
_BASELINE_ROLES=('worker','implicit','graph','selector','runner','observer','linked','schema','cursor','writer')
_PLAN_FIELDS={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization','subject_closure','store_limits','allocations','runtime_signature','policy'}
_ORIGINAL_LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
_G1='PROPOSED_G1_IMMUTABLE_FULL_VALUES_ALL_OWNER_EVENT_TAPE_REFERENCES_V1'
_OUTER_RAW_OWNERS=[]
_OUTER_PREIMAGES={}

def _on(ok,message):
    if not ok:raise ValueError(message)

def _oc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _subject_bytes(value):return json.dumps(value,sort_keys=False,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _op(path,raw):return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def _or(pin,cap=16777216):
    _OUTER_RAW_OWNERS.append(pin)
    _on(type(pin)is dict and set(pin)=={'path','bytes','sha256'}and type(pin['path'])is str and type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and len(pin['sha256'])==64,'exact bounded raw pin')
    p=Path(pin['path']);_on(not p.name.endswith('.partial'),'partial content is never opened')
    _on(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),'canonical regular pinned file')
    raw=p.read_bytes()
    if _op(p,raw)!=pin:
        _OUTER_RAW_OWNERS.append(raw);_on(False,'full path/size/SHA256 Source and input custody')
    key=(pin['path'],pin['sha256']);_OUTER_PREIMAGES.setdefault(key,raw)
    return raw

def _oj(pin,cap=16777216):return json.loads(_or(pin,cap))
def _runtime_signature():
    return dict(version=sys.version,version_info=list(sys.version_info),implementation=sys.implementation.name,cache_tag=sys.implementation.cache_tag,platform=sys.platform,byteorder=sys.byteorder,isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)

def _complete_custody(contract,gate):
    plan=contract['plan'];gate();_or(plan['python'],67108864)
    for pin in plan['sources'].values():gate();_or(pin)
    for key in('declaration','runtime_closure','subject_closure','policy','authorization'):gate();_or(plan[key])
    for item in plan['inputs']:gate();_or(item['pin'],134217728)
    for pin in contract['closure']['stdlib_files']:gate();_or(pin)
    for owner in contract['subject']['owners'].values():gate();_or(owner['source'],134217728)
    gate();_on(_runtime_signature()==plan['runtime_signature'],'entire declared runtime signature retained')


def _contract(plan_path,own_role):
    raw=Path(plan_path).read_bytes();_OUTER_RAW_OWNERS.append(raw);_on(len(raw)<=16777216,'bounded plan')
    plan=json.loads(raw);_OUTER_RAW_OWNERS.append(plan);pin=_op(plan_path,raw)
    _on(type(plan)is dict and set(plan)==_PLAN_FIELDS and plan['schema']=='ROOT-whole-owner-evidence-plan-v1','exact new fifteen-field plan')
    _on(plan['limits']==_ORIGINAL_LIMITS and type(plan['sources'])is dict and set(plan['sources'])==set(_BASELINE_ROLES),'unchanged original caps and exact baseline roles')
    _on(_op(__file__,Path(__file__).read_bytes())==plan['sources'][own_role],'this exact executable Source role')
    _on(_runtime_signature()==plan['runtime_signature']and sys.platform=='darwin'and sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'exact isolated pinned Darwin runtime')
    _on(Path(sys.executable).resolve()==Path(plan['python']['path']),'actual interpreter path')
    declaration=_oj(plan['declaration']);closure=_oj(plan['runtime_closure']);subject=_oj(plan['subject_closure']);policy=_oj(plan['policy'])
    _on(declaration['schema']=='ROOT-whole-owner-evidence-declaration-v1'and closure['schema']=='ROOT-whole-owner-evidence-runtime-closure-v1','new exact declaration/closure identity')
    for key in('limits','store_limits','allocations','runtime_signature','inputs','policy','subject_closure'):_on(_subject_bytes(declaration[key])==_subject_bytes(plan[key]),'complete declaration binding '+key)
    _on(closure['python']==plan['python']and closure['sources']==plan['sources']and closure['declaration']==plan['declaration']and closure['subject_closure']==plan['subject_closure']and closure['runtime_signature']==plan['runtime_signature'],'complete runtime closure joins')
    _on(closure['complete_subject_owner_closure']==subject and closure['qualification_policy']==policy,'full literal subject owner map and policy embedded in runtime closure, not only public pins')
    _on(_subject_bytes(closure['sources'])==_subject_bytes(plan['sources'])and _subject_bytes(closure['python'])==_subject_bytes(plan['python']),'strict insertion-order Source/runtime bindings')
    _on(type(closure['stdlib_files'])is list and 0<len(closure['stdlib_files'])<=1024,'explicit complete stdlib/extension fingerprint list')
    keys=('work','nodes','references','roots','wire_bytes','record_bytes','depth','integer_bits','string_bytes','owners','events','key_items')
    _on(type(plan['store_limits'])is dict and set(plan['store_limits'])==set(keys)and all(type(x)is int and x>0 for x in plan['store_limits'].values()),'Root must declare complete finite new store limits; no inferred fit')
    _on(plan['store_limits']['wire_bytes']<=134217728,'unchanged complete wire cap')
    allocations=plan['allocations'];_on(type(allocations)is dict and set(allocations)=={'canonical_bytes','result_bytes'}and all(type(x)is int and 0<x<=134217728 for x in allocations.values()),'exact complete output leases')
    _on(allocations['canonical_bytes']+allocations['result_bytes']+9437184+3*4194304+65536<=134217728,'all leases inside original128MiB including reserve/log/header/summary; opaque prior bytes additionally checked by writer')
    _on(type(plan['inputs'])is list and len(plan['inputs'])==2 and plan['inputs'][0]['role']=='original-bank'and plan['inputs'][1]['role']=='new-diagnostic-bank','whole ordered two-bank input contract')
    _on(subject['schema']=='ROOT-complete-subject-owner-closure-v1'and subject['subject_kind']=='ORIGINAL_FULL_EVIDENCE_COHORT_ONLY','no silent full physical VM closure claim')
    _on(subject['baseline_sources']==plan['sources']and subject['executed_owner_roles']==list(_BASELINE_ROLES)and subject['adapter']is None,'exact executed baseline and no implicit VM adapter')
    _on(type(subject['owners'])is dict and 0<len(subject['owners'])<=4096 and set(subject['owners'])==set(subject['declared_owner_roles']),'complete exact extensible owner map')
    for role,owner in subject['owners'].items():
        _on(type(role)is str and role and type(owner)is dict and set(owner)=={'source','execution','depends_on'},'exact full-subject owner record')
        _on(type(owner['depends_on'])is list and all(x in subject['owners']for x in owner['depends_on']),'all declared owner dependencies exist')
        _on(owner['execution']==('BASELINE_EXECUTED'if role in _BASELINE_ROLES else'PIN_ONLY_NOT_EXECUTED'),'additional owners never falsely treated as executed')
        if role in _BASELINE_ROLES:_on(owner['source']==plan['sources'][role],'baseline owner raw pin join')
    _on(all(role in subject['owners']for role in _BASELINE_ROLES),'all baseline owners present')
    _on(sum(owner['source']['bytes']for owner in subject['owners'].values())<=134217728 and sum(pin['bytes']for pin in closure['stdlib_files'])<=134217728,'finite complete raw owner/stdlib preimage corpus; no hidden source cache')
    _on(policy['schema']=='ROOT-proposed-G1-qualification-policy-v1'and policy['author_identity']=='/root'and policy['purpose']=='UNADOPTED_G1_RESOURCE_EXPERIMENT_ONLY'and policy['gate_contract']==_G1,'explicit Root policy required; no local policy adoption')
    for obj in(policy,subject,declaration):
        _on(obj['G1_adopted']is False and obj['full_pipeline_qualified']is False,'all broader authority false')
    _on(policy['resource_admission']is False and policy['old_G0_claim']is False,'qualification candidate cannot adoptG1 or rescueG0')
    subject_plan={k:v for k,v in plan.items()if k!='authorization'};digest=hashlib.sha256(_subject_bytes(subject_plan)).hexdigest();auth=_oj(plan['authorization'])
    _on(set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['schema']=='ROOT-whole-owner-evidence-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==digest,'fresh exact-subject Root max-one grant required')
    review=_oj(auth['review'])
    _on(review['schema']=='whole-owner-complete-Source-prospective-review-v1'and review['reviewer_identity']=='/root/recovered_batch_review'and review['review_passed']is True and review['source_only']is True and review['component_calls']==0 and type(review['component_calls'])is int and review['actual_execution_authorized']is False and _subject_bytes(review['subject'])==_subject_bytes(subject_plan) and review['subject_sha256']==digest,'full exact independently reviewed subject; specific delta receipts alone insufficient')
    _on(review['full_inner_composition_passed']is True and review['full_outer_composition_passed']is True and review['whole_resource_bounds_passed']is True and review['G1_adopted']is False,'all missing full review/fit obligations block launch')
    contract=dict(plan=plan,plan_pin=pin,raw=raw,declaration=declaration,closure=closure,subject=subject,policy=policy,authorization=auth,review=review,subject_sha256=digest)
    _OUTER_RAW_OWNERS.append(contract);_complete_custody(contract,lambda:None);return contract


class _OuterMetadata:
    """Outer9MiB splits into runner8MiB and observer1MiB; no unleased writer."""
    def __init__(self,folder,cap,gate,external_bytes=None):self.folder=Path(folder);self.cap=cap;self.used=0;self.gate=gate;self.external_bytes=external_bytes;self.owners=[];self.names=set()
    def write(self,name,value):
        self.owners.append(value);self.gate();raw=_oc(value)+b'\n';self.owners.append(raw)
        _on(type(name)is str and name not in self.names and '/'not in name and not name.endswith('.partial'),'spent outer metadata name')
        self.names.add(name);outside=0 if self.external_bytes is None else self.external_bytes()
        _on(type(outside)is int and outside>=0 and self.used+len(raw)+outside<=self.cap,'aggregate original outer metadata reservation including captured logs')
        self.used+=len(raw);path=self.folder/name;fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as out:
            _on(out.write(raw)==len(raw),'complete once metadata write');out.flush();os.fsync(out.fileno())
        self.gate();return _op(path,raw)


class _OwnedChild:
    """Bounded pipe drains; cap overflow fails, never truncates a complete log.
    No hostile process/PID-race security claim beyond the owned exclusive run.
    """
    def __init__(self,folder,caps,gate,retainer,total_guard=None):
        self.folder=Path(folder);self.caps=dict(caps);self.gate=gate;self.total_guard=total_guard;self.process=None;self.logs={};self.sizes={name:0 for name in caps};self.selector=None;self.eof=set();self.reaped=False;self.status=None;self.usage=None;self.absent_seen=False;self.reappeared=False;self.owners=[retainer];self.events=[];self.secondary=[]
        retainer(self)
    def launch(self,command,environment,cwd):
        self.owners.extend((command,environment));self.gate()
        for name in self.caps:self.logs[name]=(self.folder/(name+'.bin')).open('xb')
        self.process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=environment,cwd=str(cwd))
        self.selector=selectors.DefaultSelector()
        for name in self.caps:
            stream=getattr(self.process,name);os.set_blocking(stream.fileno(),False);self.selector.register(stream,selectors.EVENT_READ,name)
        return self.process.pid
    def absent(self):
        _on(self.process is not None,'owned launch exists')
        try:os.killpg(self.process.pid,0);gone=False
        except ProcessLookupError:gone=True
        if self.absent_seen and not gone:self.reappeared=True;raise ValueError('owned group reappeared; no signal reuse')
        self.absent_seen=self.absent_seen or gone;return gone
    def reap(self):
        if self.reaped:return True
        got,status,usage=os.wait4(self.process.pid,os.WNOHANG)
        if got:self.reaped=True;self.status=status;self.usage=usage;self.process.returncode=os.waitstatus_to_exitcode(status)
        return self.reaped
    def drain(self,timeout=.02):
        self.gate()
        for key,mask in self.selector.select(timeout):
            self.gate();name=key.data;raw=os.read(key.fd,65536);self.owners.append(raw)
            if not raw:self.eof.add(name);self.selector.unregister(key.fileobj);key.fileobj.close();continue
            _on(self.sizes[name]+len(raw)<=self.caps[name],'whole bounded log overflow: failed qualification')
            if self.total_guard is not None:self.total_guard(len(raw))
            written=self.logs[name].write(raw);_on(type(written)is int and written==len(raw),'whole bounded log short write')
            self.sizes[name]+=written
        return self.reap()and len(self.eof)==len(self.caps)and self.absent()
    def close(self):
        for handle in self.logs.values():
            try:
                if not handle.closed:handle.flush();handle.close()
            except BaseException as error:self.secondary.append(error)
        if self.selector is not None:
            try:self.selector.close()
            except BaseException as error:self.secondary.append(error)
    def cleanup(self,deadline):
        if self.process is None:return False
        def note(kind,error=None):
            if len(self.events)<32:self.events.append(dict(kind=kind,time_ns=NOW(),error_type=None if error is None else type(error).__name__))
        polls=0
        for sig in(signal.SIGTERM,signal.SIGKILL):
            if NOW()>=deadline:break
            try:
                self.reap()
                if self.absent():break
                os.killpg(self.process.pid,sig);note('signal-'+str(sig))
            except BaseException as error:self.secondary.append(error);note('cleanup-error',error)
            stop=min(deadline,NOW()+1000000000)
            while NOW()<stop and polls<2048:
                polls+=1
                try:
                    self.reap()
                    if self.absent():break
                except BaseException as error:self.secondary.append(error);note('probe-error',error)
                time.sleep(min(.02,max(0,(stop-NOW())/1e9)))
        try:self.reap();complete=self.reaped and self.absent()and not self.reappeared
        except BaseException as error:self.secondary.append(error);complete=False
        self.close();return complete and NOW()<deadline

need=_on
canonical=_oc
def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='implicit-palette-graph-component-candidate-v1'and
         q['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE','whole implicit palette/graph result')
    need(q['outputs']==outputs and len(outputs)==1,'one whole canonical packet')
    need(q['case_ids']==declaration['case_ids']and [r['id']for r in q['rows']]==declaration['case_ids']and
         len(q['rows'])==declaration['exact_cases']and len(set(q['case_ids']))==len(q['case_ids'])and
         all(r['complete']is True for r in q['rows']),'complete declared normal cohort')
    need(q['diagnostic_ids']==declaration['diagnostic_ids']and
         [r['id']for r in q['diagnostics']]==declaration['diagnostic_ids'],'complete diagnostic population')
    for row,expected in zip(q['diagnostics'],declaration['diagnostics']):
        need(row['status']=='PASSED'and row['operation']==expected['operation']and row['role']==expected['role']and
             row['expected']==expected['expected']and type(row['callback_count'])is int and
             row['callback_count']==expected['expected_callback_count'],'exact declared diagnostic class and reached site')
        need(row['exact_foreign_identity']is (True if expected['expected']=='FOREIGN'else None),'foreign identity field')
    groups=q['batch_diagnostics']
    expected_groups=declaration['batch_diagnostic_groups']
    need(type(groups)is list and len(groups)==len(expected_groups)and
         [g['id']for g in groups]==[g['id']for g in expected_groups],
         'entire separate batch/summary diagnostic group population')
    for group,expected_group in zip(groups,expected_groups):
        need(group['status']=='PASSED'and group['complete']is True and
             group['subject']==expected_group['subject']and
             group['recipe']==expected_group['recipe'],
             'complete exact new diagnostic group and recipe')
        need(type(group['variants'])is list and
             [v['id']for v in group['variants']]==[v['id']for v in expected_group['variants']],
             'every declared new variant in exact order')
        for variant,expected_variant in zip(group['variants'],expected_group['variants']):
            need(variant['status']=='PASSED'and variant['complete']is True and
                 canonical(variant['expected'])==canonical(expected_variant['expected']),
                 'complete new diagnostic variant; exact literal expectation preimage')
    metrics=q['profile_metrics']
    metric_keys=('profile_count','profile_attempted_work','profile_preparation_work',
        'profile_query_kernel_work','profile_overhead_work',
        'profile_postpreparation_overhead_work','produced_receipt_count',
        'preimage_completed_count','delivered_receipt_count','attempted_queries',
        'palette_attempted_work_known_total','palette_work_unavailable_count')
    need(type(metrics)is dict and set(metrics)==set(metric_keys)and
         all(type(metrics[k])is int and metrics[k]>=0 for k in metric_keys),
         'exact typed complete normal-scope profile metrics')
    need(metrics['profile_count']>0 and metrics['attempted_queries']>0 and
         metrics['produced_receipt_count']==metrics['preimage_completed_count']==
         metrics['delivered_receipt_count']==metrics['attempted_queries'],
         'all normal-scope requests produced, copied and delivered exactly once')
    need(metrics['profile_attempted_work']==metrics['profile_query_kernel_work']+
         metrics['profile_overhead_work']and metrics['profile_overhead_work']==
         metrics['profile_preparation_work']+metrics['profile_postpreparation_overhead_work'],
         'preparation and all profile overhead accounted exactly once')
    need(metrics['palette_attempted_work_known_total']>=metrics['profile_attempted_work']and
         metrics['profile_attempted_work']<=400000000,
         'normal profile private work bounded; other palette work is explicitly a known lower bound')
    need(q['small_palettes']==4 and q['graph_cases']==10,'whole original finite populations')
    for key in('small_mask_queries','selected_small_witnesses','graph_domain_checks','rollback_comparisons',
               'palette_query_calls','compiler_calls','search_calls','verifier_calls','oracle_calls'):
        need(type(q[key])is int and q[key]>0,'whole actual component work '+key)
    need(type(q['large_logical_tiles'])is int and q['large_logical_tiles']>134217728,'large mathematical universe; no literal-byte fit')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,'original cumulative callback ceiling')
    for key in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified',
               'gcts_rl_advantage_established','learned_pair_markings','trained_RL','complete_physical_VM','proof_discovery'):
        need(q[key]is False,'no broader authority')
# SOURCE ONLY exact once launch and bounded outer closure.
_RUNNER_STATE=None

def _runner_main(plan_path):
    global _RUNNER_STATE
    state=dict(owners=[plan_path],contract=None,child=None,metadata=None,primary=None,secondaries=[],receipt=None,actual=None)
    _RUNNER_STATE=state;accepted=False
    try:
        c=_contract(plan_path,'runner');state['contract']=c;plan=c['plan'];actual=Path(plan['actual_directory']);state['actual']=actual
        _on(actual.is_absolute()and actual==actual.resolve()and actual.parent.is_dir(),'fresh canonical actual directory')
        actual.mkdir(mode=0o700)  # Spent even if a later launch fails.
        work=BEGAN+180000000000;overall=BEGAN+210000000000
        def positive():_on(NOW()<work,'all positive runner operations before original180')
        def closure_gate():_on(NOW()<overall,'all runner metadata/cleanup within original210')
        meta=_OuterMetadata(actual,8388608,closure_gate);state['metadata']=meta;state['owners'].append(meta)
        consumed=meta.write('CONSUMED.json',dict(schema='whole-owner-evidence-consumed-v1',invocation_id=plan['invocation_id'],plan=c['plan_pin'],subject_sha256=c['subject_sha256'],maximum_worker_launches=1,consumed_before_Popen=True,began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,runner_pid=os.getpid()))
        result=dict(schema='whole-owner-evidence-runner-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=c['plan_pin'],authorization=plan['authorization'],declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],subject_closure=plan['subject_closure'],policy=plan['policy'],subject_sha256=c['subject_sha256'],consumed_marker=consumed,began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,limits=_ORIGINAL_LIMITS,worker_launch_attempts=0,worker_reaped=False,owned_group_absent=False,regular_logs_closed=False,whole_log_custody=False,raw_custody_complete=False,bounded_evidence_candidate=False,resource_checks_passed=False,resource_admission=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,G1_adopted=False,old_G0_unfolding_charged=False,Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,FOL_proof_search_calls=0,errors=[],secondary_error_types=[],outputs=[])
        state['receipt']=result;state['owners'].extend((positive,closure_gate,result))
        child=_OwnedChild(actual,dict(stdout=4194304,stderr=4194304),positive,state['owners'].append);state['child']=child
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(Path(plan_path).resolve())]
        environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        result['worker_launch_attempts']=1
        pid=child.launch(command,environment,actual)
        result.update(worker_pid=pid,owned_pgid=pid,command=command)
        meta.write('WORKER_LAUNCH.json',dict(schema='whole-owner-worker-launch-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],worker_pid=pid,worker_pgid=pid,runner_pid=os.getpid(),observed_ns=NOW()))
        while not child.drain():positive()
        worker_exit=NOW();child.close();positive()
        _on(child.reaped and child.process.returncode==0 and child.absent()and not child.reappeared and not child.secondary,'complete known worker exit/group/log closure')
        result.update(worker_reaped=True,owned_group_absent=True,regular_logs_closed=True,worker_exit_code=child.process.returncode,worker_terminal_observed_ns=worker_exit,worker_peak_bytes=child.usage.ru_maxrss)
        _on(child.usage.ru_maxrss<=1073741824,'worker Darwin highwater within original1GiB')
        logs={}
        for name in('stdout','stderr'):
            path=actual/(name+'.bin');raw=path.read_bytes();state['owners'].append(raw);positive()
            _on(len(raw)==child.sizes[name]<=4194304,'complete stable bounded log, never a truncated prefix');logs[name]=_op(path,raw)
        _on(logs['stdout']['bytes']>0,'complete final worker stdout record required')
        final_lines=(actual/'stdout.bin').read_bytes().splitlines();_on(len(final_lines)==1,'exact one complete worker terminal metadata line')
        final=json.loads(final_lines[0]);state['owners'].append(final)
        _on(final['schema']=='whole-owner-worker-final-stdout-v1'and final['plan']==c['plan_pin']and final['invocation_id']==plan['invocation_id']and type(final['root_check_calls'])is int and 0<final['root_check_calls']<=400000000 and final['completed_ns']<work and final['G1_adopted']is False and final['mathematical_authority']is False,'final genuine cumulative Root callback and subject join')
        wpath=actual/'worker-receipt.json';wraw=wpath.read_bytes();_on(len(wraw)<=4194304,'complete bounded worker header');w=json.loads(wraw);state['owners'].extend((wraw,w));positive()
        _on(w['schema']=='whole-owner-evidence-worker-receipt-v1'and w['plan']==c['plan_pin']and w['invocation_id']==plan['invocation_id']and w['began_ns']==BEGAN and w['work_deadline_ns']==work and w['overall_deadline_ns']==overall and w['pid']==pid and w['ppid']==os.getpid()and w['positive_worker_completed_ns']<work and w['finite_encoding_candidate']is True,'complete same-epoch worker header')
        payload=_oj(w['result'],134217728);positive()
        _on(payload['schema']=='whole-owner-evidence-result-v1'and payload['plan']==c['plan_pin']and payload['invocation_id']==plan['invocation_id']and payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure']and payload['subject_closure']==plan['subject_closure']and payload['policy']==plan['policy'],'complete result subject/closure/policy')
        outputs=w['outputs'];_on(payload['outputs']==outputs and len(outputs)==1,'one complete canonical owner evidence file')
        validate_qualification(payload['qualification'],plan,c['declaration'],outputs)
        parent=payload['qualification']['evidence_parent'];validation=parent['validation']
        _on(parent['schema']=='immutable-whole-owner-worker-candidate-v1'and validation['all24full_descendants_compared']is True and (validation['normal_cases'],validation['legacy_diagnostics'],validation['new_groups'],validation['new_variants'])==(15,33,28,55),'complete whole parent values/catalog/population checker output')
        for record in(parent,validation,payload,w):
            for key in('G1_adopted','full_pipeline_qualified','mathematical_proof_accepted','scientific_acceptance'):
                if key in record:_on(record[key]is False,'no wider authority')
        _on(payload['denied_events']==[]and all(type(payload[key])is int and payload[key]==0 for key in('Native_calls','Model_calls','inverse_calls','Reader_calls','FOL_kernel_calls','opaque_program_decodes')),'no undeclared execution lanes')
        output=outputs[0];op=Path(output['path'])
        _on(op.parent==actual and op.name=='canonical-complete-owner-evidence.gctsowners','exact complete canonical binary name')
        body=_or(output,134217728);positive();_on(body.startswith(b'GCTSOWN1\x00'),'complete binary magic (no replay/second subject checker call)')
        _on(payload['canonical_stored_bytes']==payload['G1_canonical_logical_bytes']==len(body)and w['stored_logical_result_bytes']==w['G1_logical_result_bytes']==len(body)+w['result']['bytes']<=134217728,'complete stored/proposed G1 logical ledger')
        for record in(payload,w):_on(record['gate_contract']==_G1 and record['old_G0_unfolding_charged']is False and record['G1_adopted']is False,'changed unadopted G1, never oldG0')
        ledger=w['writer_ledger'];_on(ledger['cap']==ledger['expanded_cap']==134217728 and ledger['outer_reserve']==9437184 and ledger['committed_physical_bytes']<=134217728 and ledger['committed_expanded_bytes']<=134217728 and ledger['physical_exact']is True and ledger['expanded_exact']is True,'whole shared aggregate writer ledger')
        # Header snapshot precedes its own completed write. Final raw census
        # includes the actual header bytes, all ordinary files and opaque partial
        # metadata, while the original9MiB outer reserve stays charged.
        entries=[]
        for f in actual.iterdir():
            st=f.lstat();_on(f.is_file()and not f.is_symlink()and st.st_nlink==1,'exclusive regular actual files')
            entries.append(dict(name=f.name,bytes=st.st_size,identity=[st.st_dev,st.st_ino]))
        _on(not any(row['name'].endswith('.partial')for row in entries),'positive cannot admit any unfinished writer')
        total=sum(row['bytes']for row in entries);_on(total+9437184<=134217728,'all actual worker files plus unchanged outer reserve')
        _complete_custody(c,positive);positive()
        result.update(worker_receipt=_op(wpath,wraw),result=w['result'],outputs=outputs,qualification_scope='Full original evidence cohort only; complete raw/source ownership, proposedG1 and terminal/resource checks remain candidate conditions, no physical VM/theorem/adoption.',writer_ledger=ledger,stored_logical_result_bytes=w['stored_logical_result_bytes'],G1_logical_result_bytes=w['G1_logical_result_bytes'],gate_contract=_G1,root_check_calls=final['root_check_calls'],negative_metadata_gate_calls=final['negative_metadata_gate_calls'],final_worker_stdout=final,whole_log_custody=True,logs=logs,actual_entries_before_runner_receipt=entries,physical_before_runner_receipt=total,conservative_physical_bytes=total+9437184,positive_result_read_completed_ns=NOW(),raw_custody_complete=True,bounded_evidence_candidate=True,resource_checks_passed=True,memory_scope='Original standalone worker wait4 highwater; no Native/full-production memory sum or speed claim.')
        accepted=True
    except BaseException as error:
        state['owners'].append(error);state['primary']=error;accepted=False
        result=state['receipt']
        if result is not None:
            result['errors'].append(dict(type_name=type(error).__name__,message_evaluated=False));result['bounded_evidence_candidate']=False;result['resource_checks_passed']=False
    finally:
        child=state['child'];c=state['contract'];meta=state['metadata'];result=state['receipt']
        if child is not None and child.process is not None:
            deadline=BEGAN+210000000000
            if not accepted:
                try:closed=child.cleanup(deadline)
                except BaseException as error:state['secondaries'].append(error);closed=False
                if result is not None:result.update(worker_reaped=child.reaped,owned_group_absent=closed,cleanup_events=child.events)
            else:child.close()
            if child.secondary:state['secondaries'].extend(child.secondary);accepted=False
            if result is not None and child.reaped:
                result['worker_exit_code']=child.process.returncode;result['worker_peak_bytes']=child.usage.ru_maxrss
        if c is not None and meta is not None and result is not None:
            try:
                _complete_custody(c,lambda:_on(NOW()<BEGAN+210000000000,'same-window final raw custody'))
                result['raw_custody_complete']=True
                result['secondary_error_types']=[type(x).__name__ for x in state['secondaries'][:32]]
                result['bounded_evidence_candidate']=accepted;result['resource_checks_passed']=accepted
                result['closed_ns']=NOW();result['outer_runner_metadata_bytes_before_receipt']=meta.used
                meta.write('runner-receipt.json',result)
            except BaseException as error:state['secondaries'].append(error);accepted=False
        # No receipt overwrite/retry or post-deadline success marker. Observer
        # requires exit0, a whole receipt and its own final terminal/custody gates.
    return 0 if accepted and NOW()<BEGAN+210000000000 else 2

if __name__=='__main__':
    _on(len(sys.argv)==2,'one new fully reviewed plan path');raise SystemExit(_runner_main(sys.argv[1]))
