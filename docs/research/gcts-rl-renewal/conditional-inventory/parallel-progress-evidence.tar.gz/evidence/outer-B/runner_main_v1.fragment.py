# SOURCE ONLY exact once launch and bounded outer closure.
_RUNNER_STATE=None

def _runner_main(plan_path):
    global _RUNNER_STATE
    state=dict(owners=[plan_path],contract=None,child=None,metadata=None,primary=None,secondaries=[],receipt=None,actual=None)
    _RUNNER_STATE=state;accepted=False
    try:
        c=_contract(plan_path,'runner');state['contract']=c;plan=c['plan'];actual=Path(plan['actual_directory']);state['actual']=actual
        _on(actual.is_absolute()and actual==actual.resolve()and actual.parent.is_dir(),'fresh canonical actual directory')
        actual.mkdir(mode=0o700)  # Spent even if a later launch fails.
        work=BEGAN+180000000000;overall=BEGAN+210000000000
        def positive():_on(NOW()<work,'all positive runner operations before original180')
        def closure_gate():_on(NOW()<overall,'all runner metadata/cleanup within original210')
        meta=_OuterMetadata(actual,8388608,closure_gate);state['metadata']=meta;state['owners'].append(meta)
        consumed=meta.write('CONSUMED.json',dict(schema='whole-owner-evidence-consumed-v1',invocation_id=plan['invocation_id'],plan=c['plan_pin'],subject_sha256=c['subject_sha256'],maximum_worker_launches=1,consumed_before_Popen=True,began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,runner_pid=os.getpid()))
        result=dict(schema='whole-owner-evidence-runner-receipt-v1',version=VERSION,invocation_id=plan['invocation_id'],plan=c['plan_pin'],authorization=plan['authorization'],declaration=plan['declaration'],runtime_closure=plan['runtime_closure'],subject_closure=plan['subject_closure'],policy=plan['policy'],subject_sha256=c['subject_sha256'],consumed_marker=consumed,began_ns=BEGAN,work_deadline_ns=work,overall_deadline_ns=overall,limits=_ORIGINAL_LIMITS,worker_launch_attempts=0,worker_reaped=False,owned_group_absent=False,regular_logs_closed=False,whole_log_custody=False,raw_custody_complete=False,bounded_evidence_candidate=False,resource_checks_passed=False,resource_admission=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,G1_adopted=False,old_G0_unfolding_charged=False,Native_calls=0,Model_calls=0,inverse_calls=0,Reader_calls=0,FOL_kernel_calls=0,FOL_proof_search_calls=0,errors=[],secondary_error_types=[],outputs=[])
        state['receipt']=result;state['owners'].extend((positive,closure_gate,result))
        child=_OwnedChild(actual,dict(stdout=4194304,stderr=4194304),positive,state['owners'].append);state['child']=child
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['worker']['path'],str(Path(plan_path).resolve())]
        environment={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        result['worker_launch_attempts']=1
        pid=child.launch(command,environment,actual)
        result.update(worker_pid=pid,owned_pgid=pid,command=command)
        meta.write('WORKER_LAUNCH.json',dict(schema='whole-owner-worker-launch-v1',plan=c['plan_pin'],invocation_id=plan['invocation_id'],worker_pid=pid,worker_pgid=pid,runner_pid=os.getpid(),observed_ns=NOW()))
        while not child.drain():positive()
        worker_exit=NOW();child.close();positive()
        _on(child.reaped and child.process.returncode==0 and child.absent()and not child.reappeared and not child.secondary,'complete known worker exit/group/log closure')
        result.update(worker_reaped=True,owned_group_absent=True,regular_logs_closed=True,worker_exit_code=child.process.returncode,worker_terminal_observed_ns=worker_exit,worker_peak_bytes=child.usage.ru_maxrss)
        _on(child.usage.ru_maxrss<=1073741824,'worker Darwin highwater within original1GiB')
        logs={}
        for name in('stdout','stderr'):
            path=actual/(name+'.bin');raw=path.read_bytes();state['owners'].append(raw);positive()
            _on(len(raw)==child.sizes[name]<=4194304,'complete stable bounded log, never a truncated prefix');logs[name]=_op(path,raw)
        _on(logs['stdout']['bytes']>0,'complete final worker stdout record required')
        final_lines=(actual/'stdout.bin').read_bytes().splitlines();_on(len(final_lines)==1,'exact one complete worker terminal metadata line')
        final=json.loads(final_lines[0]);state['owners'].append(final)
        _on(final['schema']=='whole-owner-worker-final-stdout-v1'and final['plan']==c['plan_pin']and final['invocation_id']==plan['invocation_id']and type(final['root_check_calls'])is int and 0<final['root_check_calls']<=400000000 and final['completed_ns']<work and final['G1_adopted']is False and final['mathematical_authority']is False,'final genuine cumulative Root callback and subject join')
        wpath=actual/'worker-receipt.json';wraw=wpath.read_bytes();_on(len(wraw)<=4194304,'complete bounded worker header');w=json.loads(wraw);state['owners'].extend((wraw,w));positive()
        _on(w['schema']=='whole-owner-evidence-worker-receipt-v1'and w['plan']==c['plan_pin']and w['invocation_id']==plan['invocation_id']and w['began_ns']==BEGAN and w['work_deadline_ns']==work and w['overall_deadline_ns']==overall and w['pid']==pid and w['ppid']==os.getpid()and w['positive_worker_completed_ns']<work and w['finite_encoding_candidate']is True,'complete same-epoch worker header')
        payload=_oj(w['result'],134217728);positive()
        _on(payload['schema']=='whole-owner-evidence-result-v1'and payload['plan']==c['plan_pin']and payload['invocation_id']==plan['invocation_id']and payload['declaration']==plan['declaration']and payload['runtime_closure']==plan['runtime_closure']and payload['subject_closure']==plan['subject_closure']and payload['policy']==plan['policy'],'complete result subject/closure/policy')
        outputs=w['outputs'];_on(payload['outputs']==outputs and len(outputs)==1,'one complete canonical owner evidence file')
        validate_qualification(payload['qualification'],plan,c['declaration'],outputs)
        parent=payload['qualification']['evidence_parent'];validation=parent['validation']
        _on(parent['schema']=='immutable-whole-owner-worker-candidate-v1'and validation['all24full_descendants_compared']is True and (validation['normal_cases'],validation['legacy_diagnostics'],validation['new_groups'],validation['new_variants'])==(15,33,28,55),'complete whole parent values/catalog/population checker output')
        for record in(parent,validation,payload,w):
            for key in('G1_adopted','full_pipeline_qualified','mathematical_proof_accepted','scientific_acceptance'):
                if key in record:_on(record[key]is False,'no wider authority')
        _on(payload['denied_events']==[]and all(type(payload[key])is int and payload[key]==0 for key in('Native_calls','Model_calls','inverse_calls','Reader_calls','FOL_kernel_calls','opaque_program_decodes')),'no undeclared execution lanes')
        output=outputs[0];op=Path(output['path'])
        _on(op.parent==actual and op.name=='canonical-complete-owner-evidence.gctsowners','exact complete canonical binary name')
        body=_or(output,134217728);positive();_on(body.startswith(b'GCTSOWN1\x00'),'complete binary magic (no replay/second subject checker call)')
        _on(payload['canonical_stored_bytes']==payload['G1_canonical_logical_bytes']==len(body)and w['stored_logical_result_bytes']==w['G1_logical_result_bytes']==len(body)+w['result']['bytes']<=134217728,'complete stored/proposed G1 logical ledger')
        for record in(payload,w):_on(record['gate_contract']==_G1 and record['old_G0_unfolding_charged']is False and record['G1_adopted']is False,'changed unadopted G1, never oldG0')
        ledger=w['writer_ledger'];_on(ledger['cap']==ledger['expanded_cap']==134217728 and ledger['outer_reserve']==9437184 and ledger['committed_physical_bytes']<=134217728 and ledger['committed_expanded_bytes']<=134217728 and ledger['physical_exact']is True and ledger['expanded_exact']is True,'whole shared aggregate writer ledger')
        # Header snapshot precedes its own completed write. Final raw census
        # includes the actual header bytes, all ordinary files and opaque partial
        # metadata, while the original9MiB outer reserve stays charged.
        entries=[]
        for f in actual.iterdir():
            st=f.lstat();_on(f.is_file()and not f.is_symlink()and st.st_nlink==1,'exclusive regular actual files')
            entries.append(dict(name=f.name,bytes=st.st_size,identity=[st.st_dev,st.st_ino]))
        _on(not any(row['name'].endswith('.partial')for row in entries),'positive cannot admit any unfinished writer')
        total=sum(row['bytes']for row in entries);_on(total+9437184<=134217728,'all actual worker files plus unchanged outer reserve')
        _complete_custody(c,positive);positive()
        result.update(worker_receipt=_op(wpath,wraw),result=w['result'],outputs=outputs,qualification_scope='Full original evidence cohort only; complete raw/source ownership, proposedG1 and terminal/resource checks remain candidate conditions, no physical VM/theorem/adoption.',writer_ledger=ledger,stored_logical_result_bytes=w['stored_logical_result_bytes'],G1_logical_result_bytes=w['G1_logical_result_bytes'],gate_contract=_G1,root_check_calls=final['root_check_calls'],negative_metadata_gate_calls=final['negative_metadata_gate_calls'],final_worker_stdout=final,whole_log_custody=True,logs=logs,actual_entries_before_runner_receipt=entries,physical_before_runner_receipt=total,conservative_physical_bytes=total+9437184,positive_result_read_completed_ns=NOW(),raw_custody_complete=True,bounded_evidence_candidate=True,resource_checks_passed=True,memory_scope='Original standalone worker wait4 highwater; no Native/full-production memory sum or speed claim.')
        accepted=True
    except BaseException as error:
        state['owners'].append(error);state['primary']=error;accepted=False
        result=state['receipt']
        if result is not None:
            result['errors'].append(dict(type_name=type(error).__name__,message_evaluated=False));result['bounded_evidence_candidate']=False;result['resource_checks_passed']=False
    finally:
        child=state['child'];c=state['contract'];meta=state['metadata'];result=state['receipt']
        if child is not None and child.process is not None:
            deadline=BEGAN+210000000000
            if not accepted:
                try:closed=child.cleanup(deadline)
                except BaseException as error:state['secondaries'].append(error);closed=False
                if result is not None:result.update(worker_reaped=child.reaped,owned_group_absent=closed,cleanup_events=child.events)
            else:child.close()
            if child.secondary:state['secondaries'].extend(child.secondary);accepted=False
            if result is not None and child.reaped:
                result['worker_exit_code']=child.process.returncode;result['worker_peak_bytes']=child.usage.ru_maxrss
        if c is not None and meta is not None and result is not None:
            try:
                _complete_custody(c,lambda:_on(NOW()<BEGAN+210000000000,'same-window final raw custody'))
                result['raw_custody_complete']=True
                result['secondary_error_types']=[type(x).__name__ for x in state['secondaries'][:32]]
                result['bounded_evidence_candidate']=accepted;result['resource_checks_passed']=accepted
                result['closed_ns']=NOW();result['outer_runner_metadata_bytes_before_receipt']=meta.used
                meta.write('runner-receipt.json',result)
            except BaseException as error:state['secondaries'].append(error);accepted=False
        # No receipt overwrite/retry or post-deadline success marker. Observer
        # requires exit0, a whole receipt and its own final terminal/custody gates.
    return 0 if accepted and NOW()<BEGAN+210000000000 else 2

if __name__=='__main__':
    _on(len(sys.argv)==2,'one new fully reviewed plan path');raise SystemExit(_runner_main(sys.argv[1]))
