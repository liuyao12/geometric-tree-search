# SOURCE ONLY external terminal observer; no scientific subject import or replay.
_OBSERVER_STATE=None

def _delegated_cleanup(c,runner_pid,deadline,owners):
    """Best-effort cleanup of the Source-bound runner's complete launch receipt.
    Missing/invalid markers never supply signal authority. Never positive evidence.
    """
    actual=Path(c['plan']['actual_directory']);events=[]
    launch_path=actual/'WORKER_LAUNCH.json';consumed_path=actual/'CONSUMED.json'
    if not launch_path.is_file()or not consumed_path.is_file():return dict(complete=False,reason='no complete owned launch witness',events=events)
    launch=_oj(_op(launch_path,launch_path.read_bytes()),1048576);consumed=_oj(_op(consumed_path,consumed_path.read_bytes()),1048576);owners.extend((launch,consumed))
    _on(launch['schema']=='whole-owner-worker-launch-v1'and launch['plan']==c['plan_pin']and launch['invocation_id']==c['plan']['invocation_id']and launch['runner_pid']==runner_pid==consumed['runner_pid']and consumed['plan']==c['plan_pin'],'exact delegated group ownership witness')
    pid=launch['worker_pid'];_on(type(pid)is int and pid>1 and launch['worker_pgid']==pid and pid!=runner_pid,'distinct Source-created worker session')
    absent=False
    for sig in(signal.SIGTERM,signal.SIGKILL):
        if NOW()>=deadline:break
        try:os.killpg(pid,0)
        except ProcessLookupError:absent=True;break
        os.killpg(pid,sig);events.append(dict(signal=sig,time_ns=NOW()))
        stop=min(deadline,NOW()+1000000000)
        while NOW()<stop:
            try:os.killpg(pid,0)
            except ProcessLookupError:absent=True;break
            time.sleep(min(.02,max(0,(stop-NOW())/1e9)))
        if absent:break
    return dict(complete=absent and NOW()<deadline,worker_pgid=pid,events=events,scope='Owned cooperative cleanup only; no PID-reuse/adversarial race security claim or qualification authority.')


def _observer_main(plan_path):
    global _OBSERVER_STATE
    state=dict(owners=[plan_path],contract=None,child=None,metadata=None,primary=None,secondaries=[],outcome=None,folder=None)
    _OBSERVER_STATE=state;accepted=False;external=BEGAN+225000000000
    def outer_gate():_on(NOW()<external,'original external225s terminal window')
    try:
        c=_contract(plan_path,'observer');state['contract']=c;plan=c['plan'];outer_gate()
        folder=Path(plan_path).resolve().parent/(Path(plan_path).stem+'-terminal-observation');folder.mkdir(mode=0o700);state['folder']=folder
        def external_bytes():return 0 if state['child']is None else sum(state['child'].sizes.values())
        meta=_OuterMetadata(folder,1048576,outer_gate,external_bytes=external_bytes);state['metadata']=meta;state['owners'].extend((meta,external_bytes))
        meta.write('CONSUMED.json',dict(schema='whole-owner-observer-consumed-v1',plan=c['plan_pin'],maximum_runner_launches=1,consumed_before_Popen=True,observer_began_ns=BEGAN,external_deadline_ns=external))
        outcome=dict(schema='whole-owner-evidence-terminal-observation-v1',version=VERSION,plan=c['plan_pin'],invocation_id=plan['invocation_id'],observer_began_ns=BEGAN,external_deadline_ns=external,runner_launch_attempts=0,terminal_candidate_gate_passed=False,resource_admission=False,G1_adopted=False,old_G0_unfolding_charged=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,errors=[],cleanup=None)
        state['outcome']=outcome
        def whole_observer_budget(additional):
            _on(type(additional)is int and additional>=0 and meta.used+external_bytes()+additional<=1048576,'observer files and complete logs inside reserved1MiB')
        child=_OwnedChild(folder,dict(stdout=4194304,stderr=4194304),outer_gate,state['owners'].append,total_guard=whole_observer_budget);state['child']=child
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(Path(plan_path).resolve())]
        env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        outcome['runner_launch_attempts']=1;pid=child.launch(command,env,Path(plan_path).resolve().parent);outcome['runner_pid']=pid
        while not child.drain():outer_gate()
        observed=NOW();child.close();outer_gate()
        _on(child.reaped and child.process.returncode==0 and child.absent()and not child.reappeared and not child.secondary,'complete known runner exit0/group/log closure')
        actual=Path(plan['actual_directory']);path=actual/'runner-receipt.json';raw=path.read_bytes();_on(len(raw)<=8388608,'whole bounded runner receipt');receipt=json.loads(raw);state['owners'].extend((raw,receipt));outer_gate()
        _on(receipt['schema']=='whole-owner-evidence-runner-receipt-v1'and receipt['plan']==c['plan_pin']and receipt['invocation_id']==plan['invocation_id']and receipt['authorization']==plan['authorization']and receipt['subject_closure']==plan['subject_closure']and receipt['policy']==plan['policy'],'whole exact terminal subject/closure/policy')
        _on(observed<receipt['overall_deadline_ns']==receipt['began_ns']+210000000000 and receipt['work_deadline_ns']==receipt['began_ns']+180000000000 and receipt['positive_result_read_completed_ns']<receipt['work_deadline_ns']and receipt['worker_terminal_observed_ns']<receipt['work_deadline_ns'],'same absolute180/210 and external225 window')
        _on(receipt['bounded_evidence_candidate']is True and receipt['resource_checks_passed']is True and receipt['worker_launch_attempts']==1 and type(receipt['worker_launch_attempts'])is int and receipt['worker_reaped']is True and receipt['owned_group_absent']is True and receipt['regular_logs_closed']is True and receipt['whole_log_custody']is True and receipt['raw_custody_complete']is True,'all complete worker resource/ownership gates')
        _on(receipt['worker_peak_bytes']<=1073741824 and child.usage.ru_maxrss<=1073741824 and receipt['conservative_physical_bytes']<=134217728 and receipt['stored_logical_result_bytes']<=134217728 and receipt['G1_logical_result_bytes']<=134217728,'unchanged separate HWM and byte gates; no full-production memory sum')
        _on(receipt['gate_contract']==_G1 and receipt['resource_admission']is False and receipt['G1_adopted']is False and receipt['old_G0_unfolding_charged']is False and receipt['scientific_acceptance']is False and receipt['full_pipeline_qualified']is False and receipt['mathematical_proof_accepted']is False,'candidate only under explicit unadopted changed gate')
        _on(receipt['Native_calls']==receipt['Model_calls']==receipt['inverse_calls']==receipt['Reader_calls']==receipt['FOL_kernel_calls']==receipt['FOL_proof_search_calls']==0,'no undeclared execution lanes')
        # Parent writes only bounded8MiB metadata after worker quiescence; this
        # observer's ALL metadata/logs stay within1MiB. The worker's unchanged
        #9MiB reserve covers their complete physical bytes, with no extra grace.
        _on(sum(f.stat().st_size for f in folder.iterdir()if f.is_file())<=1048576,'complete observer physical prefix bound')
        _complete_custody(c,outer_gate);outer_gate()
        outcome.update(runner_receipt=_op(path,raw),runner_exit_code=0,runner_terminal_observed_ns=observed,runner_peak_bytes=child.usage.ru_maxrss,root_check_calls=receipt['root_check_calls'],conservative_physical_bytes=receipt['conservative_physical_bytes'],stored_logical_result_bytes=receipt['stored_logical_result_bytes'],G1_logical_result_bytes=receipt['G1_logical_result_bytes'],terminal_candidate_gate_passed=True,scope='Complete original evidence cohort and terminal resource candidate only. G1 unadopted, oldG0 unchanged, no initialized physical VM, theorem discovery or GCTS/RL advantage.')
        accepted=True
    except BaseException as error:
        state['owners'].append(error);state['primary']=error;accepted=False
        if state['outcome']is not None:state['outcome']['errors'].append(dict(type_name=type(error).__name__,message_evaluated=False))
    finally:
        child=state['child'];c=state['contract'];outcome=state['outcome'];meta=state['metadata']
        if child is not None and child.process is not None:
            if not accepted:
                # Cleanup fits the SAME external epoch; no extra225+5s grace.
                try:
                    if c is not None:delegated=_delegated_cleanup(c,child.process.pid,external,state['owners'])
                    else:delegated=dict(complete=False)
                except BaseException as error:state['secondaries'].append(error);delegated=dict(complete=False)
                try:closed=child.cleanup(external)
                except BaseException as error:state['secondaries'].append(error);closed=False
                if outcome is not None:outcome['cleanup']=dict(runner_closed=closed,delegated=delegated,events=child.events)
            else:child.close()
            if child.secondary:state['secondaries'].extend(child.secondary);accepted=False
        if meta is not None and outcome is not None:
            try:
                outer_gate();outcome['terminal_candidate_gate_passed']=accepted;outcome['secondary_error_types']=[type(e).__name__ for e in state['secondaries'][:32]];outcome['observer_completed_ns']=NOW()
                meta.write('terminal.json',outcome)
            except BaseException as error:state['secondaries'].append(error);accepted=False
    return 0 if accepted and NOW()<external else 2

if __name__=='__main__':
    _on(len(sys.argv)==2,'one fully reviewed new once-plan path');raise SystemExit(_observer_main(sys.argv[1]))
