def callable_seal(module):
    """Complete named module/class bindings plus strongly held actual owners.
    The original function/code/default/closure checks remain; descriptor wrappers
    are recorded before any unwrapping. Equal function sets are insufficient.
    """
    rows=[];owners=[module];seen=set();pending=[('',vars(module))]
    while pending:
        prefix,values=pending.pop()
        for name,value in sorted(values.items()):
            key=prefix+name;owners.append(value)
            if type(value)is types.FunctionType and value.__module__==module.__name__:
                seal=_recursive_function_owner_seal(value)
                rows.append((key,'function',id(value),seal.rows));owners.extend(seal.owners)
            elif type(value)is type and value.__module__==module.__name__:
                bases=value.__bases__;mro=value.__mro__;owners.extend((bases,mro));owners.extend(bases);owners.extend(mro)
                rows.append((key,'class',id(value),id(type(value)),id(bases),tuple(id(x)for x in bases),id(mro),tuple(id(x)for x in mro)))
                if id(value)in seen:continue
                seen.add(id(value));owned={}
                for child,item in sorted(vars(value).items()):
                    owners.append(item);kind=type(item);target=None;accessors=()
                    if kind in(staticmethod,classmethod):
                        target=item.__func__;owners.append(target);owned[child]=target
                    elif kind is property:
                        values=[]
                        for label,accessor in(('fget',item.fget),('fset',item.fset),('fdel',item.fdel)):
                            owners.append(accessor);values.append((label,id(accessor)))
                            if accessor is not None:owned[child+'.'+label]=accessor
                        accessors=tuple(values);owners.append(item.__doc__);target=item.__doc__
                    else:target=item;owned[child]=item
                    rows.append((key+'.'+child,'member',id(kind),id(item),id(target),accessors))
                pending.append((key+'.',owned))
    return _NamedOwnerSeal(tuple(sorted(rows)),tuple(owners))
