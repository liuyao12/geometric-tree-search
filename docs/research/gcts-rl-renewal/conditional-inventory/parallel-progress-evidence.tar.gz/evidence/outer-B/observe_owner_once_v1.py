"""SOURCE ONLY complete proposed owner-evidence terminal observer.
"""
import time
NOW=time.monotonic_ns
BEGAN=NOW()
import hashlib
import json
import os
from pathlib import Path
import signal
import selectors
import subprocess
import sys
VERSION='whole-owner-evidence-terminal-observer-v1'
# SOURCE ONLY shared outer protocol, textually included in each executable Source.
_BASELINE_ROLES=('worker','implicit','graph','selector','runner','observer','linked','schema','cursor','writer')
_PLAN_FIELDS={'schema','invocation_id','actual_directory','python','sources','inputs','limits','declaration','runtime_closure','authorization','subject_closure','store_limits','allocations','runtime_signature','policy'}
_ORIGINAL_LIMITS=dict(work_seconds=180,overall_seconds=210,memory_bytes=1073741824,result_bytes=134217728,expanded_bytes=134217728,stdout_bytes=4194304,stderr_bytes=4194304,worker_receipt_bytes=4194304,runner_metadata_bytes=8388608,observer_bytes=1048576)
_G1='PROPOSED_G1_IMMUTABLE_FULL_VALUES_ALL_OWNER_EVENT_TAPE_REFERENCES_V1'
_OUTER_RAW_OWNERS=[]
_OUTER_PREIMAGES={}

def _on(ok,message):
    if not ok:raise ValueError(message)

def _oc(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _subject_bytes(value):return json.dumps(value,sort_keys=False,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _op(path,raw):return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def _or(pin,cap=16777216):
    _OUTER_RAW_OWNERS.append(pin)
    _on(type(pin)is dict and set(pin)=={'path','bytes','sha256'}and type(pin['path'])is str and type(pin['bytes'])is int and 0<=pin['bytes']<=cap and type(pin['sha256'])is str and len(pin['sha256'])==64,'exact bounded raw pin')
    p=Path(pin['path']);_on(not p.name.endswith('.partial'),'partial content is never opened')
    _on(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),'canonical regular pinned file')
    raw=p.read_bytes()
    if _op(p,raw)!=pin:
        _OUTER_RAW_OWNERS.append(raw);_on(False,'full path/size/SHA256 Source and input custody')
    key=(pin['path'],pin['sha256']);_OUTER_PREIMAGES.setdefault(key,raw)
    return raw

def _oj(pin,cap=16777216):return json.loads(_or(pin,cap))
def _runtime_signature():
    return dict(version=sys.version,version_info=list(sys.version_info),implementation=sys.implementation.name,cache_tag=sys.implementation.cache_tag,platform=sys.platform,byteorder=sys.byteorder,isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)

def _complete_custody(contract,gate):
    plan=contract['plan'];gate();_or(plan['python'],67108864)
    for pin in plan['sources'].values():gate();_or(pin)
    for key in('declaration','runtime_closure','subject_closure','policy','authorization'):gate();_or(plan[key])
    for item in plan['inputs']:gate();_or(item['pin'],134217728)
    for pin in contract['closure']['stdlib_files']:gate();_or(pin)
    for owner in contract['subject']['owners'].values():gate();_or(owner['source'],134217728)
    gate();_on(_runtime_signature()==plan['runtime_signature'],'entire declared runtime signature retained')


def _contract(plan_path,own_role):
    raw=Path(plan_path).read_bytes();_OUTER_RAW_OWNERS.append(raw);_on(len(raw)<=16777216,'bounded plan')
    plan=json.loads(raw);_OUTER_RAW_OWNERS.append(plan);pin=_op(plan_path,raw)
    _on(type(plan)is dict and set(plan)==_PLAN_FIELDS and plan['schema']=='ROOT-whole-owner-evidence-plan-v1','exact new fifteen-field plan')
    _on(plan['limits']==_ORIGINAL_LIMITS and type(plan['sources'])is dict and set(plan['sources'])==set(_BASELINE_ROLES),'unchanged original caps and exact baseline roles')
    _on(_op(__file__,Path(__file__).read_bytes())==plan['sources'][own_role],'this exact executable Source role')
    _on(_runtime_signature()==plan['runtime_signature']and sys.platform=='darwin'and sys.flags.isolated==1 and sys.flags.no_site==1 and sys.dont_write_bytecode is True,'exact isolated pinned Darwin runtime')
    _on(Path(sys.executable).resolve()==Path(plan['python']['path']),'actual interpreter path')
    declaration=_oj(plan['declaration']);closure=_oj(plan['runtime_closure']);subject=_oj(plan['subject_closure']);policy=_oj(plan['policy'])
    _on(declaration['schema']=='ROOT-whole-owner-evidence-declaration-v1'and closure['schema']=='ROOT-whole-owner-evidence-runtime-closure-v1','new exact declaration/closure identity')
    for key in('limits','store_limits','allocations','runtime_signature','inputs','policy','subject_closure'):_on(_subject_bytes(declaration[key])==_subject_bytes(plan[key]),'complete declaration binding '+key)
    _on(closure['python']==plan['python']and closure['sources']==plan['sources']and closure['declaration']==plan['declaration']and closure['subject_closure']==plan['subject_closure']and closure['runtime_signature']==plan['runtime_signature'],'complete runtime closure joins')
    _on(closure['complete_subject_owner_closure']==subject and closure['qualification_policy']==policy,'full literal subject owner map and policy embedded in runtime closure, not only public pins')
    _on(_subject_bytes(closure['sources'])==_subject_bytes(plan['sources'])and _subject_bytes(closure['python'])==_subject_bytes(plan['python']),'strict insertion-order Source/runtime bindings')
    _on(type(closure['stdlib_files'])is list and 0<len(closure['stdlib_files'])<=1024,'explicit complete stdlib/extension fingerprint list')
    keys=('work','nodes','references','roots','wire_bytes','record_bytes','depth','integer_bits','string_bytes','owners','events','key_items')
    _on(type(plan['store_limits'])is dict and set(plan['store_limits'])==set(keys)and all(type(x)is int and x>0 for x in plan['store_limits'].values()),'Root must declare complete finite new store limits; no inferred fit')
    _on(plan['store_limits']['wire_bytes']<=134217728,'unchanged complete wire cap')
    allocations=plan['allocations'];_on(type(allocations)is dict and set(allocations)=={'canonical_bytes','result_bytes'}and all(type(x)is int and 0<x<=134217728 for x in allocations.values()),'exact complete output leases')
    _on(allocations['canonical_bytes']+allocations['result_bytes']+9437184+3*4194304+65536<=134217728,'all leases inside original128MiB including reserve/log/header/summary; opaque prior bytes additionally checked by writer')
    _on(type(plan['inputs'])is list and len(plan['inputs'])==2 and plan['inputs'][0]['role']=='original-bank'and plan['inputs'][1]['role']=='new-diagnostic-bank','whole ordered two-bank input contract')
    _on(subject['schema']=='ROOT-complete-subject-owner-closure-v1'and subject['subject_kind']=='ORIGINAL_FULL_EVIDENCE_COHORT_ONLY','no silent full physical VM closure claim')
    _on(subject['baseline_sources']==plan['sources']and subject['executed_owner_roles']==list(_BASELINE_ROLES)and subject['adapter']is None,'exact executed baseline and no implicit VM adapter')
    _on(type(subject['owners'])is dict and 0<len(subject['owners'])<=4096 and set(subject['owners'])==set(subject['declared_owner_roles']),'complete exact extensible owner map')
    for role,owner in subject['owners'].items():
        _on(type(role)is str and role and type(owner)is dict and set(owner)=={'source','execution','depends_on'},'exact full-subject owner record')
        _on(type(owner['depends_on'])is list and all(x in subject['owners']for x in owner['depends_on']),'all declared owner dependencies exist')
        _on(owner['execution']==('BASELINE_EXECUTED'if role in _BASELINE_ROLES else'PIN_ONLY_NOT_EXECUTED'),'additional owners never falsely treated as executed')
        if role in _BASELINE_ROLES:_on(owner['source']==plan['sources'][role],'baseline owner raw pin join')
    _on(all(role in subject['owners']for role in _BASELINE_ROLES),'all baseline owners present')
    _on(sum(owner['source']['bytes']for owner in subject['owners'].values())<=134217728 and sum(pin['bytes']for pin in closure['stdlib_files'])<=134217728,'finite complete raw owner/stdlib preimage corpus; no hidden source cache')
    _on(policy['schema']=='ROOT-proposed-G1-qualification-policy-v1'and policy['author_identity']=='/root'and policy['purpose']=='UNADOPTED_G1_RESOURCE_EXPERIMENT_ONLY'and policy['gate_contract']==_G1,'explicit Root policy required; no local policy adoption')
    for obj in(policy,subject,declaration):
        _on(obj['G1_adopted']is False and obj['full_pipeline_qualified']is False,'all broader authority false')
    _on(policy['resource_admission']is False and policy['old_G0_claim']is False,'qualification candidate cannot adoptG1 or rescueG0')
    subject_plan={k:v for k,v in plan.items()if k!='authorization'};digest=hashlib.sha256(_subject_bytes(subject_plan)).hexdigest();auth=_oj(plan['authorization'])
    _on(set(auth)=={'schema','author_identity','actual_execution_authorized','maximum_actual_invocations','subject_sha256','review','scope'}and auth['schema']=='ROOT-whole-owner-evidence-authorization-v1'and auth['author_identity']=='/root'and auth['actual_execution_authorized']is True and type(auth['maximum_actual_invocations'])is int and auth['maximum_actual_invocations']==1 and auth['subject_sha256']==digest,'fresh exact-subject Root max-one grant required')
    review=_oj(auth['review'])
    _on(review['schema']=='whole-owner-complete-Source-prospective-review-v1'and review['reviewer_identity']=='/root/recovered_batch_review'and review['review_passed']is True and review['source_only']is True and review['component_calls']==0 and type(review['component_calls'])is int and review['actual_execution_authorized']is False and _subject_bytes(review['subject'])==_subject_bytes(subject_plan) and review['subject_sha256']==digest,'full exact independently reviewed subject; specific delta receipts alone insufficient')
    _on(review['full_inner_composition_passed']is True and review['full_outer_composition_passed']is True and review['whole_resource_bounds_passed']is True and review['G1_adopted']is False,'all missing full review/fit obligations block launch')
    contract=dict(plan=plan,plan_pin=pin,raw=raw,declaration=declaration,closure=closure,subject=subject,policy=policy,authorization=auth,review=review,subject_sha256=digest)
    _OUTER_RAW_OWNERS.append(contract);_complete_custody(contract,lambda:None);return contract


class _OuterMetadata:
    """Outer9MiB splits into runner8MiB and observer1MiB; no unleased writer."""
    def __init__(self,folder,cap,gate,external_bytes=None):self.folder=Path(folder);self.cap=cap;self.used=0;self.gate=gate;self.external_bytes=external_bytes;self.owners=[];self.names=set()
    def write(self,name,value):
        self.owners.append(value);self.gate();raw=_oc(value)+b'\n';self.owners.append(raw)
        _on(type(name)is str and name not in self.names and '/'not in name and not name.endswith('.partial'),'spent outer metadata name')
        self.names.add(name);outside=0 if self.external_bytes is None else self.external_bytes()
        _on(type(outside)is int and outside>=0 and self.used+len(raw)+outside<=self.cap,'aggregate original outer metadata reservation including captured logs')
        self.used+=len(raw);path=self.folder/name;fd=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb')as out:
            _on(out.write(raw)==len(raw),'complete once metadata write');out.flush();os.fsync(out.fileno())
        self.gate();return _op(path,raw)


class _OwnedChild:
    """Bounded pipe drains; cap overflow fails, never truncates a complete log.
    No hostile process/PID-race security claim beyond the owned exclusive run.
    """
    def __init__(self,folder,caps,gate,retainer,total_guard=None):
        self.folder=Path(folder);self.caps=dict(caps);self.gate=gate;self.total_guard=total_guard;self.process=None;self.logs={};self.sizes={name:0 for name in caps};self.selector=None;self.eof=set();self.reaped=False;self.status=None;self.usage=None;self.absent_seen=False;self.reappeared=False;self.owners=[retainer];self.events=[];self.secondary=[]
        retainer(self)
    def launch(self,command,environment,cwd):
        self.owners.extend((command,environment));self.gate()
        for name in self.caps:self.logs[name]=(self.folder/(name+'.bin')).open('xb')
        self.process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=environment,cwd=str(cwd))
        self.selector=selectors.DefaultSelector()
        for name in self.caps:
            stream=getattr(self.process,name);os.set_blocking(stream.fileno(),False);self.selector.register(stream,selectors.EVENT_READ,name)
        return self.process.pid
    def absent(self):
        _on(self.process is not None,'owned launch exists')
        try:os.killpg(self.process.pid,0);gone=False
        except ProcessLookupError:gone=True
        if self.absent_seen and not gone:self.reappeared=True;raise ValueError('owned group reappeared; no signal reuse')
        self.absent_seen=self.absent_seen or gone;return gone
    def reap(self):
        if self.reaped:return True
        got,status,usage=os.wait4(self.process.pid,os.WNOHANG)
        if got:self.reaped=True;self.status=status;self.usage=usage;self.process.returncode=os.waitstatus_to_exitcode(status)
        return self.reaped
    def drain(self,timeout=.02):
        self.gate()
        for key,mask in self.selector.select(timeout):
            self.gate();name=key.data;raw=os.read(key.fd,65536);self.owners.append(raw)
            if not raw:self.eof.add(name);self.selector.unregister(key.fileobj);key.fileobj.close();continue
            _on(self.sizes[name]+len(raw)<=self.caps[name],'whole bounded log overflow: failed qualification')
            if self.total_guard is not None:self.total_guard(len(raw))
            written=self.logs[name].write(raw);_on(type(written)is int and written==len(raw),'whole bounded log short write')
            self.sizes[name]+=written
        return self.reap()and len(self.eof)==len(self.caps)and self.absent()
    def close(self):
        for handle in self.logs.values():
            try:
                if not handle.closed:handle.flush();handle.close()
            except BaseException as error:self.secondary.append(error)
        if self.selector is not None:
            try:self.selector.close()
            except BaseException as error:self.secondary.append(error)
    def cleanup(self,deadline):
        if self.process is None:return False
        def note(kind,error=None):
            if len(self.events)<32:self.events.append(dict(kind=kind,time_ns=NOW(),error_type=None if error is None else type(error).__name__))
        polls=0
        for sig in(signal.SIGTERM,signal.SIGKILL):
            if NOW()>=deadline:break
            try:
                self.reap()
                if self.absent():break
                os.killpg(self.process.pid,sig);note('signal-'+str(sig))
            except BaseException as error:self.secondary.append(error);note('cleanup-error',error)
            stop=min(deadline,NOW()+1000000000)
            while NOW()<stop and polls<2048:
                polls+=1
                try:
                    self.reap()
                    if self.absent():break
                except BaseException as error:self.secondary.append(error);note('probe-error',error)
                time.sleep(min(.02,max(0,(stop-NOW())/1e9)))
        try:self.reap();complete=self.reaped and self.absent()and not self.reappeared
        except BaseException as error:self.secondary.append(error);complete=False
        self.close();return complete and NOW()<deadline

# SOURCE ONLY external terminal observer; no scientific subject import or replay.
_OBSERVER_STATE=None

def _delegated_cleanup(c,runner_pid,deadline,owners):
    """Best-effort cleanup of the Source-bound runner's complete launch receipt.
    Missing/invalid markers never supply signal authority. Never positive evidence.
    """
    actual=Path(c['plan']['actual_directory']);events=[]
    launch_path=actual/'WORKER_LAUNCH.json';consumed_path=actual/'CONSUMED.json'
    if not launch_path.is_file()or not consumed_path.is_file():return dict(complete=False,reason='no complete owned launch witness',events=events)
    launch=_oj(_op(launch_path,launch_path.read_bytes()),1048576);consumed=_oj(_op(consumed_path,consumed_path.read_bytes()),1048576);owners.extend((launch,consumed))
    _on(launch['schema']=='whole-owner-worker-launch-v1'and launch['plan']==c['plan_pin']and launch['invocation_id']==c['plan']['invocation_id']and launch['runner_pid']==runner_pid==consumed['runner_pid']and consumed['plan']==c['plan_pin'],'exact delegated group ownership witness')
    pid=launch['worker_pid'];_on(type(pid)is int and pid>1 and launch['worker_pgid']==pid and pid!=runner_pid,'distinct Source-created worker session')
    absent=False
    for sig in(signal.SIGTERM,signal.SIGKILL):
        if NOW()>=deadline:break
        try:os.killpg(pid,0)
        except ProcessLookupError:absent=True;break
        os.killpg(pid,sig);events.append(dict(signal=sig,time_ns=NOW()))
        stop=min(deadline,NOW()+1000000000)
        while NOW()<stop:
            try:os.killpg(pid,0)
            except ProcessLookupError:absent=True;break
            time.sleep(min(.02,max(0,(stop-NOW())/1e9)))
        if absent:break
    return dict(complete=absent and NOW()<deadline,worker_pgid=pid,events=events,scope='Owned cooperative cleanup only; no PID-reuse/adversarial race security claim or qualification authority.')


def _observer_main(plan_path):
    global _OBSERVER_STATE
    state=dict(owners=[plan_path],contract=None,child=None,metadata=None,primary=None,secondaries=[],outcome=None,folder=None)
    _OBSERVER_STATE=state;accepted=False;external=BEGAN+225000000000
    def outer_gate():_on(NOW()<external,'original external225s terminal window')
    try:
        c=_contract(plan_path,'observer');state['contract']=c;plan=c['plan'];outer_gate()
        folder=Path(plan_path).resolve().parent/(Path(plan_path).stem+'-terminal-observation');folder.mkdir(mode=0o700);state['folder']=folder
        def external_bytes():return 0 if state['child']is None else sum(state['child'].sizes.values())
        meta=_OuterMetadata(folder,1048576,outer_gate,external_bytes=external_bytes);state['metadata']=meta;state['owners'].extend((meta,external_bytes))
        meta.write('CONSUMED.json',dict(schema='whole-owner-observer-consumed-v1',plan=c['plan_pin'],maximum_runner_launches=1,consumed_before_Popen=True,observer_began_ns=BEGAN,external_deadline_ns=external))
        outcome=dict(schema='whole-owner-evidence-terminal-observation-v1',version=VERSION,plan=c['plan_pin'],invocation_id=plan['invocation_id'],observer_began_ns=BEGAN,external_deadline_ns=external,runner_launch_attempts=0,terminal_candidate_gate_passed=False,resource_admission=False,G1_adopted=False,old_G0_unfolding_charged=False,full_pipeline_qualified=False,scientific_acceptance=False,mathematical_proof_accepted=False,errors=[],cleanup=None)
        state['outcome']=outcome
        def whole_observer_budget(additional):
            _on(type(additional)is int and additional>=0 and meta.used+external_bytes()+additional<=1048576,'observer files and complete logs inside reserved1MiB')
        child=_OwnedChild(folder,dict(stdout=4194304,stderr=4194304),outer_gate,state['owners'].append,total_guard=whole_observer_budget);state['child']=child
        command=[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(Path(plan_path).resolve())]
        env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
        outcome['runner_launch_attempts']=1;pid=child.launch(command,env,Path(plan_path).resolve().parent);outcome['runner_pid']=pid
        while not child.drain():outer_gate()
        observed=NOW();child.close();outer_gate()
        _on(child.reaped and child.process.returncode==0 and child.absent()and not child.reappeared and not child.secondary,'complete known runner exit0/group/log closure')
        actual=Path(plan['actual_directory']);path=actual/'runner-receipt.json';raw=path.read_bytes();_on(len(raw)<=8388608,'whole bounded runner receipt');receipt=json.loads(raw);state['owners'].extend((raw,receipt));outer_gate()
        _on(receipt['schema']=='whole-owner-evidence-runner-receipt-v1'and receipt['plan']==c['plan_pin']and receipt['invocation_id']==plan['invocation_id']and receipt['authorization']==plan['authorization']and receipt['subject_closure']==plan['subject_closure']and receipt['policy']==plan['policy'],'whole exact terminal subject/closure/policy')
        _on(observed<receipt['overall_deadline_ns']==receipt['began_ns']+210000000000 and receipt['work_deadline_ns']==receipt['began_ns']+180000000000 and receipt['positive_result_read_completed_ns']<receipt['work_deadline_ns']and receipt['worker_terminal_observed_ns']<receipt['work_deadline_ns'],'same absolute180/210 and external225 window')
        _on(receipt['bounded_evidence_candidate']is True and receipt['resource_checks_passed']is True and receipt['worker_launch_attempts']==1 and type(receipt['worker_launch_attempts'])is int and receipt['worker_reaped']is True and receipt['owned_group_absent']is True and receipt['regular_logs_closed']is True and receipt['whole_log_custody']is True and receipt['raw_custody_complete']is True,'all complete worker resource/ownership gates')
        _on(receipt['worker_peak_bytes']<=1073741824 and child.usage.ru_maxrss<=1073741824 and receipt['conservative_physical_bytes']<=134217728 and receipt['stored_logical_result_bytes']<=134217728 and receipt['G1_logical_result_bytes']<=134217728,'unchanged separate HWM and byte gates; no full-production memory sum')
        _on(receipt['gate_contract']==_G1 and receipt['resource_admission']is False and receipt['G1_adopted']is False and receipt['old_G0_unfolding_charged']is False and receipt['scientific_acceptance']is False and receipt['full_pipeline_qualified']is False and receipt['mathematical_proof_accepted']is False,'candidate only under explicit unadopted changed gate')
        _on(receipt['Native_calls']==receipt['Model_calls']==receipt['inverse_calls']==receipt['Reader_calls']==receipt['FOL_kernel_calls']==receipt['FOL_proof_search_calls']==0,'no undeclared execution lanes')
        # Parent writes only bounded8MiB metadata after worker quiescence; this
        # observer's ALL metadata/logs stay within1MiB. The worker's unchanged
        #9MiB reserve covers their complete physical bytes, with no extra grace.
        _on(sum(f.stat().st_size for f in folder.iterdir()if f.is_file())<=1048576,'complete observer physical prefix bound')
        _complete_custody(c,outer_gate);outer_gate()
        outcome.update(runner_receipt=_op(path,raw),runner_exit_code=0,runner_terminal_observed_ns=observed,runner_peak_bytes=child.usage.ru_maxrss,root_check_calls=receipt['root_check_calls'],conservative_physical_bytes=receipt['conservative_physical_bytes'],stored_logical_result_bytes=receipt['stored_logical_result_bytes'],G1_logical_result_bytes=receipt['G1_logical_result_bytes'],terminal_candidate_gate_passed=True,scope='Complete original evidence cohort and terminal resource candidate only. G1 unadopted, oldG0 unchanged, no initialized physical VM, theorem discovery or GCTS/RL advantage.')
        accepted=True
    except BaseException as error:
        state['owners'].append(error);state['primary']=error;accepted=False
        if state['outcome']is not None:state['outcome']['errors'].append(dict(type_name=type(error).__name__,message_evaluated=False))
    finally:
        child=state['child'];c=state['contract'];outcome=state['outcome'];meta=state['metadata']
        if child is not None and child.process is not None:
            if not accepted:
                # Cleanup fits the SAME external epoch; no extra225+5s grace.
                try:
                    if c is not None:delegated=_delegated_cleanup(c,child.process.pid,external,state['owners'])
                    else:delegated=dict(complete=False)
                except BaseException as error:state['secondaries'].append(error);delegated=dict(complete=False)
                try:closed=child.cleanup(external)
                except BaseException as error:state['secondaries'].append(error);closed=False
                if outcome is not None:outcome['cleanup']=dict(runner_closed=closed,delegated=delegated,events=child.events)
            else:child.close()
            if child.secondary:state['secondaries'].extend(child.secondary);accepted=False
        if meta is not None and outcome is not None:
            try:
                outer_gate();outcome['terminal_candidate_gate_passed']=accepted;outcome['secondary_error_types']=[type(e).__name__ for e in state['secondaries'][:32]];outcome['observer_completed_ns']=NOW()
                meta.write('terminal.json',outcome)
            except BaseException as error:state['secondaries'].append(error);accepted=False
    return 0 if accepted and NOW()<external else 2

if __name__=='__main__':
    _on(len(sys.argv)==2,'one fully reviewed new once-plan path');raise SystemExit(_observer_main(sys.argv[1]))
