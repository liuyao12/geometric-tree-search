"""SOURCE ONLY: fresh incremental immutable full-value/event owner store.
No imports or top-level scientific calls. Root owns all runtime admission.
"""
VERSION='immutable-whole-evidence-owners-v1'
MAGIC=b'GCTSOWN1\x00'
GATE='PROPOSED_G1_IMMUTABLE_FULL_VALUES_ALL_OWNER_EVENT_TAPE_REFERENCES_V1'
INTERVAL=128
LIMIT_KEYS=('work','nodes','references','roots','wire_bytes','record_bytes','depth',
            'integer_bits','string_bytes','owners','events','key_items')
OWNER_FIELDS=('ordinal','role','scope_owner','version','source_route','value')
EVENT_FIELDS=('ordinal','phase','kind','role','operation','scope_owner','parent_entry','entry','args_owner','value_owner','error_owner','version','complete')
STATE_FIELDS=('stage','request_owner','receipt_owner','preimage_owner','version_owner','counters')
COUNTER_FIELDS=('stage','failed_stage','attempted_queries','produced_receipt_count','preimage_completed_count','delivered_receipt_count','attempted_work','data_items')
_PRIVATE=object()


class Invalid(Exception):
    def __init__(self,reason):
        self.reason=reason;self.owner=_PRIVATE;super().__init__(reason)


class Limit(Exception):
    def __init__(self,reason,work):
        self.reason=reason;self.work=work;self.owner=_PRIVATE;super().__init__(reason)


def need(ok,reason):
    if not ok:raise Invalid(reason)


class Work:
    """Invocation-lifetime cumulative NEW units, not original Root callback units.

    Every visited item/reference is charged. Complete processed byte totals are
    separate; each started KiB contributes a unit, with bounded64KiB byte gates.
    Original component/private/Root checks remain untouched in worker Source.
    """
    def __init__(self,check,limits):
        need(callable(check) and type(limits)is dict and set(limits)==set(LIMIT_KEYS),'exact owner limits/check')
        for x in limits.values():need(type(x)is int and x>0,'positive exact limits')
        self.check=check;self.limits=dict(limits);self.units=0;self.items=0
        self.bytes=0;self.references=0;self.checkpoints=0;self.since=0
    def gate(self):
        self.checkpoints+=1;self.since=0;self.check()
    def step(self,n=1):
        need(type(n)is int and n>=0,'exact internal units')
        remaining=max(1,n)
        while remaining:
            part=min(remaining,INTERVAL-self.since)
            self.units+=part;self.since+=part;remaining-=part
            if self.units>self.limits['work']:raise Limit('cumulative-new-store-work',self.units)
            if self.since==INTERVAL:self.gate()
    def bytework(self,n):
        need(type(n)is int and n>=0,'exact byte count')
        self.bytes+=n
        remaining=n
        while remaining:
            part=min(remaining,65536);self.step((part+1023)//1024)
            if part==65536:self.gate()
            remaining-=part
    def bound(self,key,n):
        self.step()
        if n>self.limits[key]:raise Limit(key,self.units)
    def visit(self,depth):
        self.items+=1;self.step();self.bound('depth',depth)
    def refs(self,n):
        self.references+=n;self.bound('references',self.references);self.step(n)
    def metrics(self):
        return dict(work_units=self.units,visited_items=self.items,processed_bytes=self.bytes,
            references=self.references,checkpoint_calls=self.checkpoints,checkpoint_interval=INTERVAL,
            units_are_original_Root_calls=False)


def uint(n):
    need(type(n)is int and n>=0,'nonnegative integer')
    out=bytearray()
    while True:
        b=n&127;n>>=7;out.append(b|(128 if n else 0))
        if not n:return bytes(out)


class Store:
    def __init__(self,*,check,limits,retain):
        self.raw_owners=[check,limits,retain];self.work=None
        self.nodes=[];self.records=[];self.index={};self.scalar_index={}
        self.immutable={}  # id -> (ACTUAL strongly held object,node); deep immutable only.
        self.tape=[];self.owners=[];self.events=[];self.stack=[];self.pending={};self.record_storage=0
        self.scopes={};self.closed=False;self.wire=None;self.control=None;self.error=None
        need(callable(retain) and retain(self)is None,'real Root store retention before first callback')
        self.work=Work(check,limits);self.work.gate()
    def _record(self,tag,payload,children):
        w=self.work
        if tag<=2:raw=bytes((tag,))
        elif tag==3:
            n=(abs(payload).bit_length()+7)//8;w.bound('integer_bits',abs(payload).bit_length())
            w.bound('record_bytes',n+16);w.bytework(n)
            raw=b'\x03'+bytes((payload<0,))+uint(n)+abs(payload).to_bytes(n,'big')
        elif tag==4:
            rawtext=payload.encode('ascii');w.bytework(len(rawtext));raw=b'\x04'+uint(len(rawtext))+rawtext
        elif tag==5:
            w.bound('string_bytes',4*len(payload));rawtext=payload.encode('utf8','surrogatepass')
            w.bytework(len(rawtext));raw=b'\x05'+uint(len(rawtext))+rawtext
        else:
            count=len(children)//2 if tag==8 else len(children)
            w.bound('record_bytes',1+len(uint(count))+len(children)*len(uint(max(1,len(self.nodes)))))
            raw=bytes((tag,))+uint(count)
            pieces=[raw]
            for child in children:w.step();pieces.append(uint(child))
            raw=b''.join(pieces)
        w.bound('record_bytes',len(raw));w.bytework(len(raw))
        return raw
    def _intern(self,tag,payload=None,children=()):
        w=self.work;w.refs(len(children))
        raw=self._record(tag,payload,children);old=self.index.get(raw)
        if old is not None:return old
        w.bound('nodes',len(self.nodes)+1)
        self.record_storage+=len(raw)+len(uint(len(raw)))
        w.bound('wire_bytes',self.record_storage+32)
        identity=len(self.nodes)+1
        self.records.append(raw);self.nodes.append((tag,payload,tuple(children)));self.index[raw]=identity
        return identity
    def _native(self,value):
        # Fresh memo for this instantaneous read-only capture. It preserves all
        # parent child occurrences; it never reuses a mutable value across calls.
        w=self.work;memo={};active=set()
        self.raw_owners.append(value)
        def visit(x,depth):
            w.visit(depth);kind=type(x)
            if x is None:key=(0,None)
            elif kind is bool:key=(2 if x else 1,None)
            elif kind is int:key=(3,x)
            elif kind is float:
                text=x.hex();need(text not in ('nan','inf','-inf'),'finite old-packet floats only');key=(4,text)
            elif kind is str:key=(5,x)
            else:key=None
            if key is not None:
                if kind is str:w.bytework(len(x.encode('utf8','surrogatepass')))
                elif kind is int:w.bytework((abs(x).bit_length()+7)//8)
                found=self.scalar_index.get(key)
                if found is None:
                    found=self._intern(key[0],key[1]);self.scalar_index[key]=found
                return found,True
            need(kind in (tuple,list,dict),'unsupported literal carrier')
            prior=self.immutable.get(id(x))
            if prior is not None:
                need(prior[0]is x,'immutable identity owner retained');return prior[1],True
            need(id(x)not in active,'cyclic literal carrier')
            if id(x)in memo:return memo[id(x)]
            active.add(id(x));self.raw_owners.append(x)
            children=[];all_immutable=kind is tuple
            if kind is dict:
                for k,v in x.items():
                    w.step();a,unused=visit(k,depth+1);b,unused=visit(v,depth+1);children.extend((a,b))
                tag=8
            else:
                for child in x:
                    childid,frozen=visit(child,depth+1);children.append(childid)
                    all_immutable=all_immutable and frozen
                tag=7 if kind is tuple else 6
            identity=self._intern(tag,None,tuple(children))
            active.remove(id(x));memo[id(x)]=(identity,all_immutable)
            if all_immutable:self.immutable[id(x)]=(x,identity)
            return identity,all_immutable
        result,unused=visit(value,0)
        return result
    def _commit(self,node,kind):
        self.work.bound('roots',len(self.tape)+1);self.tape.append((kind,node));return node
    def sequence(self,tag,children,kind='view'):
        need(tag in (6,7),'exact list/tuple tag');return self._commit(self._intern(tag,None,tuple(children)),kind)
    def mapping(self,fields,kind='view'):
        children=[]
        for key,node in fields:
            self.work.step();need(type(key)is str,'structural field name');children.extend((self._native(key),node))
        return self._commit(self._intern(8,None,tuple(children)),kind)
    def owner(self,value,*,role,scope=None,version=0,route='Root'):
        need(not self.closed,'store closed')
        # Preserve raw input before _native's first possible check/refusal.
        self.raw_owners.append(value)
        node=self._native(value);self._commit(node,'value')
        return self.owner_node(node,role=role,scope=scope,version=version,route=route)
    def owner_node(self,node,*,role,scope=None,version=0,route='Root'):
        self.work.bound('owners',len(self.owners)+1)
        need(type(node)is int and 1<=node<=len(self.nodes),'complete value node exists')
        need(type(role)is str and type(route)is str and type(version)is int and version>=0,'literal role/version/route')
        need(scope is None or type(scope)is int and 1<=scope<=len(self.owners),'earlier scope owner')
        ordinal=len(self.owners)+1
        fields=[('ordinal',self._native(ordinal)),('role',self._native(role)),
                ('scope_owner',self._native(scope)),('version',self._native(version)),
                ('source_route',self._native(route)),('value',node)]
        row=self._commit(self._intern(7,None,tuple(value for key,value in fields)),'owner-row')
        self.owners.append((row,node,role,scope,version,route))
        return ordinal
    def owner_value(self,ordinal):
        need(type(ordinal)is int and 1<=ordinal<=len(self.owners),'full owner reference')
        return self.owners[ordinal-1][1]
    def scope(self,value):
        need(type(value)is dict and tuple(value)==('case_id','profile_id','group_id','variant_id','origin'),'exact scope fields')
        key=tuple(value.values())
        for x in key:need(x is None or type(x)is str,'immutable scope scalars')
        old=self.scopes.get(key)
        if old is None:
            old=self.owner(value,role='scope',route='live Root scope');self.scopes[key]=old
        return old
    def _event(self,phase,kind,role,operation,scope,args_owner,value_owner,error,entry,version):
        need(not self.closed,'store closed')
        self.raw_owners.append(error)
        ordinal=len(self.events)+1
        # Placeholder is retained BEFORE any error metadata, sealing or check.
        pending=dict(ordinal=ordinal,complete=False,raw_error=error)
        self.events.append(pending)
        self.work.bound('events',ordinal)
        error_owner=None
        if error is not None:
            error_owner=self.owner(dict(type_name=type(error).__name__,type_module=type(error).__module__,
                runtime_reference=len(self.raw_owners)-1,replayable=False),role='error-metadata',scope=scope,version=version)
        for ref in (args_owner,value_owner,error_owner):
            if ref is not None:self.owner_value(ref)
        metadata=dict(ordinal=ordinal,phase=phase,kind=kind,role=role,operation=operation,
            scope_owner=scope,parent_entry=self.stack[-1]if self.stack else None,entry=entry,
            args_owner=args_owner,value_owner=value_owner,error_owner=error_owner,version=version,complete=True)
        root=self._commit(self._native(tuple(metadata.values())),'event-row')
        self.events[-1]=(root,metadata)
        return ordinal
    def enter(self,kind,role,operation,scope,args_owner=None,version=0):
        token=self._event('ENTER',kind,role,operation,scope,args_owner,None,None,None,version)
        self.stack.append(token);self.pending[token]=(kind,role,operation,scope,version);return token
    def leave(self,token,*,args_owner=None,value_owner=None,error=None):
        need(self.stack and self.stack[-1]==token and token in self.pending,'exact live exit/parent')
        kind,role,operation,scope,version=self.pending[token]
        result=self._event('RAISE'if error is not None else'RETURN',kind,role,operation,scope,args_owner,value_owner,error,token,version)
        self.stack.pop();del self.pending[token];return result
    def snapshot(self,kind,role,operation,scope,value_owner,version=0):
        return self._event('SNAPSHOT',kind,role,operation,scope,None,value_owner,None,None,version)
    def close(self,*,packet,manifest,raw_banks,catalog):
        need(not self.closed and not self.stack and not self.pending,'all occurrences closed')
        for event in self.events:need(type(event)is tuple,'no incomplete event admission')
        # These full views are built from complete native original values once,
        # with a fresh identity memo. Deep immutable preimages retain exact owners.
        packetnode=self._commit(self._native(packet),'packet')
        manifestnode=self._commit(self._native(manifest),'manifest')
        banksnode=self._commit(self._native(raw_banks),'raw-banks')
        catalognode=self._commit(self._native(catalog),'catalog')
        ownersnode=self.sequence(6,[row[0]for row in self.owners],'owners')
        eventsnode=self.sequence(6,[row[0]for row in self.events],'events')
        before=tuple(self.tape)
        taperows=[]
        for i,(kind,node)in enumerate(before):
            taperows.append(self._intern(7,None,(self._native(i+1),self._native(kind),node)))
        tapenode=self._intern(7,None,tuple(taperows))
        control=self.mapping([('schema',self._native(VERSION)),('gate_contract',self._native(GATE)),
            ('canonical_packet',packetnode),('manifest',manifestnode),('raw_banks',banksnode),
            ('catalog',catalognode),('columns',self._native(dict(owners=OWNER_FIELDS,events=EVENT_FIELDS,profile_state=STATE_FIELDS,counters=COUNTER_FIELDS))),('owners',ownersnode),('events',eventsnode),
            ('sealing_tape',tapenode),('G1_adopted',self._native(False)),
            ('runtime_qualified',self._native(False)),('mathematical_authority',self._native(False))],'control')
        # mapping committed exactly one final control root. The tape in that
        # root records all preceding roots and is independently crosschecked.
        need(self.tape[:-1]==list(before),'closed tape exact prefix')
        self.control=control;self.closed=True;self.work.gate();return control
    def encode(self):
        need(self.closed and self.control is not None,'complete closed parent')
        # Canonical normal form: increasing exact value-depth, then increasing
        # complete record bytes after child relabeling. No hash decides order.
        # Construction IDs stay runtime-owned; wire IDs are never live owners.
        w=self.work;w.gate();levels={};depths={}
        for i,(tag,payload,children)in enumerate(self.nodes,1):
            w.step();depth=0
            for child in children:w.step();depth=max(depth,depths[child]+1)
            w.bound('depth',depth)
            depths[i]=depth;levels.setdefault(depth,[]).append(i)
        labels={};ordered=[]
        def merge_sort(rows):
            width=1
            while width<len(rows):
                merged=[]
                for start in range(0,len(rows),2*width):
                    left=rows[start:start+width];right=rows[start+width:start+2*width];a=b=0
                    while a<len(left)and b<len(right):
                        w.bytework(len(left[a][0])+len(right[b][0]));w.step()
                        if left[a][0]<right[b][0]:merged.append(left[a]);a+=1
                        else:merged.append(right[b]);b+=1
                    merged.extend(left[a:]);merged.extend(right[b:])
                rows=merged;width*=2
            return rows
        for depth in sorted(levels):
            rows=[]
            for old in levels[depth]:
                tag,payload,children=self.nodes[old-1]
                raw=self._record(tag,payload,tuple(labels[c]for c in children));rows.append((raw,old))
            rows=merge_sort(rows)
            for raw,old in rows:w.step();labels[old]=len(ordered)+1;ordered.append(raw)
        self.wire_labels=labels;self.wire_records=ordered
        parts=[MAGIC,uint(len(ordered))];size=len(MAGIC)+len(parts[1])
        for raw in ordered:
            w.step();piece=uint(len(raw));size+=len(piece)+len(raw);w.bound('wire_bytes',size)
            parts.extend((piece,raw));w.bytework(len(raw))
        piece=uint(len(self.tape));parts.append(piece);size+=len(piece)
        for kind,root in self.tape:
            w.step();piece=uint(labels[root]);parts.append(piece);size+=len(piece);w.bound('wire_bytes',size)
        w.bound('wire_bytes',size)
        self.wire=b''.join(parts)  # complete bytes retained before final check.
        w.bytework(size);w.gate()
        return dict(schema='immutable-owner-wire-candidate-v1',wire=self.wire,stored_bytes=size,
            G1_unique_logical_bytes=size,gate_contract=GATE,metrics=w.metrics(),
            nodes=len(self.nodes),owners=len(self.owners),events=len(self.events),roots=len(self.tape),
            G1_adopted=False,runtime_qualified=False,resource_accepted=False,mathematical_authority=False)


# Complete catalog builder Source bound into linked role.
"""SOURCE ONLY complete producer catalog; independent checker reconstructs roles.
"""
TOP_FIELDS = ('schema','status','inputs','small_palettes','large_palette','graphs',
    'diagnostics','call_receipts','call_started','call_completed','call_raised',
    'root_callbacks','batch_inputs','profile_rows','profile_metrics',
    'profile_accounting','batch_diagnostics','batch_diagnostic_progress',
    'full_VM_implemented','full_FOL_palette_qualified','proof_discovery',
    'full_pipeline_qualified','mathematical_authority','scope')

def build_catalog(packet, check):
    """Producer catalog. Decoder builds/checks its own catalog independently.

    A subtree binding owns ALL descendants with original type/order, including
    dynamic map keys. It is not a summary or a promise to regenerate a value.
    """
    rows = []
    def add(path, role, case=None, profile=None, group=None, variant=None, run=None):
        check()
        rows.append(dict(ordinal=len(rows)+1,path=path,role=role,case=case,
                         profile=profile,group=group,variant=variant,run=run))
    for key in TOP_FIELDS:
        add((key,), 'predecessor-topfield')
    for i, case in enumerate(packet['small_palettes']):
        path=('small_palettes',i); cid=case['id']
        add(path,'normal-small',cid)
        for key in ('input','legacy_palette','semantic_tiles'):
            add(path+(key,), 'independent-'+key,cid)
        for j, unused in enumerate(case['queries']):
            add(path+('queries',j),'small-query-group',cid)
    add(('large_palette',),'normal-large',packet['large_palette']['id'])
    add(('large_palette','legacy_cardinality'),'independent-cardinality',packet['large_palette']['id'])
    for key in ('global_rank_samples','focused_families'):
        for i, unused in enumerate(packet['large_palette'][key]):
            add(('large_palette',key,i),'large-'+key,packet['large_palette']['id'])
    for i, case in enumerate(packet['graphs']):
        path=('graphs',i); cid=case['id']
        add(path,'normal-graph',cid)
        for key in ('input','instance','legacy_problem','independent_solution_ids'):
            add(path+(key,),'independent-'+key,cid)
        for j, unused in enumerate(case['observations']):
            add(path+('observations',j),'graph-observation',cid)
            add(path+('observations',j,'independent_domains'),'independent-domains',cid)
        for key in ('journal','query_journal','solutions'):
            for j, unused in enumerate(case['result'][key]):
                add(path+('result',key,j),'graph-'+key,cid)
    for i, row in enumerate(packet['diagnostics']):
        add(('diagnostics',i),'legacy-diagnostic',row['id'])
    for i, row in enumerate(packet['call_receipts']):
        add(('call_receipts',i),'standalone-call-receipt')
    for i, row in enumerate(packet['profile_rows']):
        add(('profile_rows',i),'wrapper-profile',profile=row['id'])
    for i, row in enumerate(packet['profile_accounting']):
        add(('profile_accounting',i),'profile-accounting',profile=row['id'])
    for i, group in enumerate(packet['batch_diagnostics']):
        path=('batch_diagnostics',i); gid=group['id']
        add(path,'new-diagnostic-group',group=gid)
        for j, variant in enumerate(group['variants']):
            vpath=path+('variants',j); vid=variant['id']
            add(vpath,'new-diagnostic-variant',group=gid,variant=vid)
            for k, unused in enumerate(variant.get('runs',[])):
                pid=vid+':baseline' if k==0 and group['recipe'] in ('work-cumulative','receipt-items-cumulative') else vid
                add(vpath+('runs',k),'new-diagnostic-profile',profile=pid,group=gid,variant=vid,run=k)
    add(('batch_diagnostic_progress',),'complete-progress-view')
    return rows
