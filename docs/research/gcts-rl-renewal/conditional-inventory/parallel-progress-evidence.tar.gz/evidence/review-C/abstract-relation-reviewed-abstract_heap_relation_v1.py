"""UNEXECUTED Source: finite canonical-heap and decoded-state certificates.

No physical decoder, execution, proof search, compiler, tile builder or semantic
BOOT is supplied here. These checks concern COMPLETE abstract immutable tuples.
Their use requires a fresh reviewed Root once, full input ownership and limits.
No import/call of this module has occurred. Native operations here are verifier
operations, never proposed primitives inside a Wang transition.
"""
VERSION='abstract-canonical-heap-relation-v1'
NIL=256
FIRST=257
LIMIT_KEYS=('work','nodes','references','state_values','frames')
_OWNER=object()


class Invalid(ValueError):
    def __init__(self,reason,*,owner=None):
        self.reason=reason
        self.owner=owner
        super().__init__(reason)


class Limit(RuntimeError):
    def __init__(self,reason,*,owner=None):
        self.reason=reason
        self.owner=owner
        super().__init__(reason)


def is_owned_invalid(error):
    return type(error)is Invalid and error.owner is _OWNER


def is_owned_limit(error):
    return type(error)is Limit and error.owner is _OWNER


def _need(condition,reason):
    if not condition:
        raise Invalid(reason,owner=_OWNER)


class _Work:
    def __init__(self,check,limits,owners):
        # Keep the actual raw objects before checking declarations or budgets.
        self.check=check
        self.raw_limits=limits
        self.owners=owners
        self.counts={key:0 for key in LIMIT_KEYS}
        self.limits=None
        self.phase='DECLARATIONS'
        self.heap_indexes=[]
        self.seen_images=set()
    def start(self):
        # Called only after the actual Work instance is retained by the entry.
        _need(callable(self.check),'explicit Root callback')
        self.check()
        limits=self.raw_limits
        _need(type(limits)is dict and all(type(key)is str for key in limits)
              and set(limits)==set(LIMIT_KEYS),
              'exact private limit keys')
        _need(all(type(value)is int and 0<value<=400000000
                  for value in limits.values()),'positive bounded private limits')
        self.limits=dict(limits)
        self.step()

    def step(self,kind=None):
        self.counts['work']+=1
        if kind is not None:
            self.counts[kind]+=1
        # Genuine Root faults take precedence over private-limit classification.
        self.check()
        if self.counts['work']>self.limits['work']:
            raise Limit('work',owner=_OWNER)
        if kind is not None and self.counts[kind]>self.limits[kind]:
            raise Limit(kind,owner=_OWNER)


def _attach(error,work,owners):
    # No callback, serializer, sizer, replay or exception replacement here.
    try:
        error.abstract_relation_prefix=dict(version=VERSION,work=work,
            owners=owners,complete=False,authority=False)
    except BaseException:
        pass


def _integer(value,low,high):
    return type(value)is int and low<=value<high


def _heap(work,nodes,label):
    _need(type(nodes)is tuple,label+' complete immutable heap tuple')
    index={}
    work.heap_indexes.append(index)
    for ordinal,pair in enumerate(nodes):
        work.step('nodes')
        _need(type(pair)is tuple and len(pair)==2,label+' exact pair')
        for child in pair:
            work.step('references')
            _need(_integer(child,0,FIRST+ordinal),label+' prior child reference')
        _need(pair not in index,label+' canonical distinct pair')
        index[pair]=FIRST+ordinal
    return index


def _image(mapping,reference):
    return reference if reference<FIRST else mapping[reference-FIRST]


def _embedding(work,source,target,mapping,seed_count):
    work.phase='COMPLETE_HEAPS'
    _heap(work,source,'source')
    _heap(work,target,'target')
    _need(type(mapping)is tuple and len(mapping)==len(source),
          'complete immutable node-image vector')
    _need(_integer(seed_count,0,min(len(source),len(target))+1),
          'declared seed prefix length')
    work.phase='COMPLETE_EMBEDDING'
    for ordinal,pair in enumerate(source):
        work.step('nodes')
        target_ref=mapping[ordinal]
        _need(_integer(target_ref,FIRST,FIRST+len(target)),
              'node image is an actual target pair')
        _need(target_ref not in work.seen_images,'injective complete image')
        work.seen_images.add(target_ref)
        if ordinal<seed_count:
            _need(target_ref==FIRST+ordinal and target[ordinal]==pair,
                  'exact original seed prefix and identity image')
        expected=[]
        for child in pair:
            work.step('references')
            expected.append(_image(mapping,child))
        _need(target[target_ref-FIRST]==tuple(expected),
              'both children commute with the full image')


def _shapes(work,shapes):
    _need(type(shapes)is tuple and len(shapes)>0,'complete function shape tuple')
    for shape in shapes:
        work.step('state_values')
        _need(type(shape)is tuple and len(shape)==3,'arity/register/code shape')
        arity,registers,code=shape
        _need(_integer(registers,1,10000000),'positive fixed-VM register count')
        _need(_integer(arity,0,registers+1),'arity at most registers')
        _need(type(code)is int and code>0,'nonempty code count')
    _need(shapes[0][0]==1,'one-input main shape')


def _vector(work,values,nodes,count,label):
    _need(type(values)is tuple and len(values)==count,label+' complete registers')
    for reference in values:
        work.step('state_values')
        _need(_integer(reference,0,FIRST+len(nodes)),label+' valid value reference')


def _control(work,function,pc,registers,nodes,shapes,label):
    work.step('state_values')
    _need(_integer(function,0,len(shapes)),label+' function index')
    # A return continuation can equal code length after a last-position CALL.
    # Such a state is not fetchable. This relation does not call it accepting.
    _need(_integer(pc,0,shapes[function][2]+1),label+' PC or one-past end')
    _vector(work,registers,nodes,shapes[function][1],label)


def _state(work,state,nodes,shapes,label):
    _need(type(state)is tuple and len(state)==4,label+' fn/pc/registers/frames')
    function,pc,registers,frames=state
    _control(work,function,pc,registers,nodes,shapes,label)
    _need(type(frames)is tuple,label+' complete bottom-to-top frame tuple')
    for frame in frames:
        work.step('frames')
        _need(type(frame)is tuple and len(frame)==4,label+' complete caller frame')
        fn,continuation,values,destination=frame
        _control(work,fn,continuation,values,nodes,shapes,label+'/frame')
        _need(_integer(destination,0,shapes[fn][1]),label+' saved destination')


def _vectors_correspond(work,left,right,mapping):
    _need(len(left)==len(right),'equal register-vector lengths')
    for source_ref,target_ref in zip(left,right):
        work.step('state_values')
        _need(_image(mapping,source_ref)==target_ref,'every value has its image')


def _finish(work,owners,kind):
    work.phase='COMPLETE_ABSTRACT_RELATION'
    work.step()
    return dict(schema='abstract-relation-certificate-check-v1',version=VERSION,
        relation=kind,valid=True,complete=True,owners=owners,
        private_counts=dict(work.counts),physical_trace_verified=False,
        program_validated=False,execution_verified=False,proof_checked=False,
        actual_authority=False)


def check_heap_embedding(source,target,mapping,*,seed_count,check,limits):
    """Check complete canonical immutable heaps and all source node images.

    Atoms0..256 map identically by definition. Extra target metadata is allowed.
    No cost, deadline, pointer-ID equality or finite-capacity equivalence follows.
    Exact original input owners are retained on success and available failure.
    """
    owners=dict(source=source,target=target,mapping=mapping,seed_count=seed_count,
        check=check,limits=limits)
    work=None
    try:
        work=_Work(check,limits,owners)
        work.start()
        _embedding(work,source,target,mapping,seed_count)
        return _finish(work,owners,'complete heap embedding')
    except BaseException as error:
        _attach(error,work,owners)
        raise


def check_decoded_state_relation(source,target,mapping,left,right,shapes,*,
                                 seed_count,check,limits):
    """Check one COMPLETE abstract macro-boundary relation, NOT a transition.

    left/right=(fnIndex,pc,registerTuple,bottomToTopFrameTuple), and each saved
    frame=(fnIndex,nextPC,registerTuple,destination). shapes is the complete
    (arity,nregs,ncode) tuple for the SAME separately bound immutable program.
    This function does not establish that shapes came from that program, that
    any decoded state came from tape/tiles, or that a transition occurred.
    Those obligations remain outside this finite abstract certificate check.
    """
    owners=dict(source=source,target=target,mapping=mapping,left=left,right=right,
        shapes=shapes,seed_count=seed_count,check=check,limits=limits)
    work=None
    try:
        work=_Work(check,limits,owners)
        work.start()
        _embedding(work,source,target,mapping,seed_count)
        work.phase='COMPLETE_STATES'
        _shapes(work,shapes)
        _state(work,left,source,shapes,'source')
        _state(work,right,target,shapes,'target')
        _need(left[0]==right[0] and left[1]==right[1],
              'same active function and next PC')
        _vectors_correspond(work,left[2],right[2],mapping)
        _need(len(left[3])==len(right[3]),'same complete frame depth')
        for a,b in zip(left[3],right[3]):
            work.step('frames')
            _need(a[0]==b[0] and a[1]==b[1] and a[3]==b[3],
                  'same saved function/continuation/destination')
            _vectors_correspond(work,a[2],b[2],mapping)
        return _finish(work,owners,'complete decoded abstract state relation')
    except BaseException as error:
        _attach(error,work,owners)
        raise
