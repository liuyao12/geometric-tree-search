"""Reviewer metadata/AST only; no research module is imported or executed."""
import ast
import hashlib
import json
from pathlib import Path

RUNS = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
BASE = RUNS / 'gcts-whole-linkage-20261020/schema-B'
OUT = RUNS / 'gcts-initialized-bridge-20261020/review-C'
OLD = RUNS / 'gcts-batch-20261020'
PYTHON = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
CHECKS = []

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

def check(name, condition):
    CHECKS.append({'check': name, 'passed': bool(condition)})
    assert condition, name

def write(name, value):
    path = OUT / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')
    return pin(path)

def read(path):
    assert '.partial' not in str(path)
    return json.loads(path.read_bytes())

def strict_json(a, b):
    return json.dumps(a, sort_keys=True, separators=(',', ':'), ensure_ascii=True) == json.dumps(b, sort_keys=True, separators=(',', ':'), ensure_ascii=True)

pins = {
    'store': ('immutable_event_store_v1.py', '898a687bcb81f1456a26978841a1e9710acf72a20a23c5bdfe39c18607d26843'),
    'cursor': ('cursor-v2/owner_cursor_v2.py', '93eb21f8bde51051cd5a7c913cd03732252bb5b6aa22cea2c42f5511e61323f0'),
    'checker': ('schema-v3/validate_owner_parent_v3.py', '923230b512dabb3eb57127e42d06cff88106887921fd598a0226ff2ad69b1701'),
    'worker': ('qualify_owner_batch_worker_v1.py', 'f6c28c149261274eaa133527c3bd3a306de47b45afa38e48daf5313436f0bacc'),
    'integration': ('worker_owner_integration_v1.fragment.py', 'd5f9ce95a12962f2b7ca013737410dc607e54c5c812cfa543ac9fcb41b8ca0fa'),
    'native_rules': ('native_schema_rules_v1.py', '8f696885ffb066b7229d42fecb6a2fc4ba4eb670657dc42ad08803e9182dfa0c'),
    'catalog': ('owner_catalog_v1.py', '6c20439614a07c9f5be6da67aa1da50bd20760a665526eeb81c1d6e4dc6750af'),
}
trees = {}
unused = []
source_pins = {}
for role, (relative, digest) in pins.items():
    path = BASE / relative
    source_pins[role] = pin(path)
    check('exact Source ' + role, source_pins[role]['sha256'] == digest)
    tree = ast.parse(path.read_bytes(), filename=str(path))
    trees[role] = tree
    unused.append(compile(tree, str(path), 'exec'))
    check('AST parsed and compiled without execution ' + role, True)
check('current Python pin', pin(PYTHON)['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933')
master = OLD / 'publisher/docs/basic-tiling-algorithm.md'
check('fully read master pin unchanged', pin(master)['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4')
check('whole worker exact integration suffix', (BASE / pins['worker'][0]).read_bytes().endswith((BASE / pins['integration'][0]).read_bytes()))
check('whole store exact catalog suffix', (BASE / pins['store'][0]).read_bytes().endswith((BASE / pins['catalog'][0]).read_bytes()))
check('whole checker exact native-rules suffix', (BASE / pins['checker'][0]).read_bytes().endswith((BASE / pins['native_rules'][0]).read_bytes()))

def functions(tree):
    result = {}
    def visit(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + child.name
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    result[name] = child
                visit(child, name + '.')
            else:
                visit(child, prefix)
    visit(tree)
    return result

predecessor = RUNS / 'gcts-linked-evidence-20261020/schema-B/custody-v2/qualify_linked_batch_worker_v2.py'
check('exact named-custody predecessor', pin(predecessor)['sha256'] == '463c2bb80ab5ee5bae2cb58fe635f82c45e812e997a2498dfb5da027632ca932')
prior_functions = functions(ast.parse(predecessor.read_bytes()))
matrix_rows = []
for role in ('store', 'cursor', 'checker', 'worker'):
    for name, node in functions(trees[role]).items():
        fingerprint = hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()
        inheritance = None
        if role == 'worker':
            prior = prior_functions.get(name)
            inheritance = 'NEW_FUNCTION' if prior is None else 'EXACT_AST_RETAINED' if ast.dump(prior, include_attributes=False) == ast.dump(node, include_attributes=False) else 'CHANGED_FUNCTION_REVIEWED_IN_FULL_CURRENT_CONTEXT'
        if role == 'store':
            group = 'CUMULATIVE_WORK_AND_ERRORS' if name.startswith(('Work.', 'Invalid.', 'Limit.')) or name in ('need', 'uint') else 'COMPLETE_CATALOG' if name.startswith('build_catalog') else 'VALUE_CAPTURE_CANONICALIZATION_OWNER_EVENT_TAPE'
        elif role == 'cursor':
            group = 'INDEPENDENT_WIRE_KEY_NORMAL_FORM_AND_FULL_NATIVE_CURSOR_CORRESPONDENCE'
        elif role == 'checker':
            group = 'LIVE_PROVENANCE_WITH_FROZEN_NEGATIVES' if name.startswith('_live') else 'NATIVE_PROFILE_POPULATION_CATALOG' if name in ('_profiles', '_profiles.request_value', '_packet_population', '_catalog', '_catalog.expect') else 'FULL_CURSOR_NATIVE_CONTROL_MANIFEST_AND_RECEIPT_PREDICATES'
        else:
            group = 'ORIGINAL_ENGINE_ORACLE_DIAGNOSTIC_AND_POLICY_CONTROL' if inheritance == 'EXACT_AST_RETAINED' else 'NEW_FULL_OWNER_CAPTURE_AND_JOIN'
            if name in ('callable_seal', 'Session.guard', '_linked_final_custody'):
                group = 'CALLABLE_CUSTODY_WITH_FROZEN_DESCRIPTOR_NEGATIVE'
        matrix_rows.append({'role': role, 'function': name, 'first_line': node.lineno, 'last_line': node.end_lineno, 'AST_sha256': fingerprint,
            'manual_review_group': group, 'predecessor_AST_status': inheritance,
            'review_scope': 'Literal Source/control/data/fault inspection in full selected composition; a coverage row is not a function soundness proof or a runtime PASS.'})
counts = {role: sum(row['role'] == role for row in matrix_rows) for role in ('store', 'cursor', 'checker', 'worker')}
check('complete nested function inventory', counts == {'store': 33, 'cursor': 22, 'checker': 24, 'worker': 120} and len(matrix_rows) == 199)
worker_status = {}
for row in matrix_rows:
    if row['role'] == 'worker':
        status = row['predecessor_AST_status']
        worker_status[status] = worker_status.get(status, 0) + 1
check('104 exact retained 6 changed 10 new worker functions', worker_status == {'EXACT_AST_RETAINED': 104, 'CHANGED_FUNCTION_REVIEWED_IN_FULL_CURRENT_CONTEXT': 6, 'NEW_FUNCTION': 10})

first_path = OLD / 'recovered/ROOT/implicit-inputs-v1.json'
second_path = OLD / 'diagnostics-L/new-diagnostic-bank-v1.json'
check('exact full first bank', pin(first_path)['sha256'] == '10fe60d005a2f586a76bf69ae30317b8dae538ba9f126714b9f71ffa474a89b4')
check('exact full second bank', pin(second_path)['sha256'] == '6e579fa58384188b5444606c87dbdee92a86f5771a983a36fbf6904192e669ab')
first, second = read(first_path), read(second_path)
preservation = read(BASE / 'complete-preservation-map-v1.json')
expected_catalog = {
    'normal_case_ids': [row['id'] for row in first['small_palettes']] + [first['large_palette']['id']] + [row['id'] for row in first['graph_cases']],
    'legacy_diagnostics': [{'index': i, 'id': row['id'], 'operation': row['operation'], 'expected': row['expected']} for i, row in enumerate(first['diagnostics'])],
    'new_groups': [{'index': i, 'id': row['id'], 'subject': row['subject'], 'recipe': row['recipe'], 'variants': [{'index': j, 'id': v['id'], 'parameters': v['parameters'], 'expected': v['expected']} for j, v in enumerate(row['variants'])]} for i, row in enumerate(second['groups'])],
}
check('EVERY literal population catalog row equals full saved bank declarations', strict_json(expected_catalog, preservation['exact_literal_population_catalog']))
check('population 15/33/28/55', len(expected_catalog['normal_case_ids']) == 15 and len(expected_catalog['legacy_diagnostics']) == 33 and len(expected_catalog['new_groups']) == 28 and sum(len(row['variants']) for row in expected_catalog['new_groups']) == 55)
top = ('schema','status','inputs','small_palettes','large_palette','graphs','diagnostics','call_receipts','call_started','call_completed','call_raised','root_callbacks','batch_inputs','profile_rows','profile_metrics','profile_accounting','batch_diagnostics','batch_diagnostic_progress','full_VM_implemented','full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified','mathematical_authority','scope')
check('24 full topfield mapping exact order/path', len(preservation['top_fields']) == 24 and all(row['ordinal'] == i + 1 and row['old_path'] == [key] and row['new_cursor_path'] == ['canonical_packet', key] for i, (key, row) in enumerate(zip(top, preservation['top_fields']))))
bank = read(BASE / 'diagnostic-bank-v1.json')
check('88 declarative recipes all retained', len(bank['recipes']) == 88 and len({row['id'] for row in bank['recipes']}) == 88 and bank['actual_execution_authorized'] is False)

matrix = write('selected-owner-complete-function-and-preservation-matrix-v1.json', {
    'schema': 'selected-owner-complete-function-and-preservation-matrix-v1', 'reviewer_identity': '/root/recovered_batch_review', 'source_only': True,
    'source_pins': source_pins, 'predecessor': pin(predecessor), 'function_counts': counts, 'worker_AST_comparison': worker_status,
    'functions': matrix_rows, 'complete_literal_population_catalog': expected_catalog,
    'all24_full_field_map': preservation['top_fields'], 'four_profile_return_bindings': preservation['four_profile_return_bindings'],
    'diagnostic_recipes': bank['recipes'], 'diagnostic_status': 'ALL_88_DECLARATIVE_UNRUN; preservation is not a runtime or sufficiency result.',
    'coverage_limit': 'The population-map central rows were checked in full by independent passive strict JSON comparison to both complete pinned saved banks. A prior truncated display is not asserted as a complete literal read. Every function row is an AST inventory plus manual grouped Source review, not mechanized verification.',
    'authority': {'research_imports': 0, 'component_calls': 0, 'fixtures': 0, 'probes': 0, 'partial_reads': 0, 'runtime_qualified': False, 'G1_adopted': False},
})

cutoff_path = RUNS / 'gcts-evidence-next-20261020/bounds-B/cutoff-metadata-v1.json'
cutoff = read(cutoff_path)
check('complete saved cutoff exact pin', pin(cutoff_path)['sha256'] == 'f3482f22b0c968914f51ee41887726660d25d1ca5c302be65792f2cf50dff439')
count = cutoff['call_completed']['implicit.profile_count_query']
select = cutoff['call_completed']['implicit.profile_select_query']
q = count + select
check('all original wrapper queries completed at saved cutoff', q == 44113 and count == cutoff['call_started']['implicit.profile_count_query'] and select == cutoff['call_started']['implicit.profile_select_query'] and not any(k in cutoff['call_raised'] for k in ('implicit.profile_count_query', 'implicit.profile_select_query')))
resource = write('typed-selected-owner-conditional-node-lower-bound-Source-review-v1.json', {
    'schema': 'typed-selected-owner-conditional-node-lower-bound-Source-review-v1', 'reviewer_identity': '/root/recovered_batch_review',
    'review_passed': True, 'status': 'PASS_ONLY_CONDITIONAL_DISTINCT_NODE_LOWER_BOUND', 'source_only': True,
    'source_pins': source_pins, 'author_resource_note': pin(BASE / 'full-cohort-resource-obligations-v1.json'), 'complete_saved_cutoff': pin(cutoff_path),
    'premises': ['A hypothetical successful complete selected producer path preserves the same full original semantic stream and all original query occurrences.', 'All original wrapper queries represented by the complete saved cutoff finish their query and reconciliation stages; new genuine faults may stop this path earlier but cannot remove mandatory occurrences from a claimed complete path.', 'The stated lower bound counts this exact implementation and full format. It is not asserted for every possible value/occurrence codec.'],
    'saved_count': {'completed_count_queries': count, 'completed_select_queries': select, 'Q': q, 'cutoff_status': cutoff['status'], 'no_saved_positive_admission': True},
    'manual_Source_count': [
        {'kind': 'distinct owner rows', 'per_query': 11, 'reason': 'arguments-before; raw receipt; completed typed preimage; four query-state reference values; two reconciliation-version values and two reconciliation-state reference values. QUERY_RETURN reuses its raw receipt owner.'},
        {'kind': 'distinct event rows', 'per_query': 8, 'reason': 'QUERY ENTER/RETURN, four query states and two reconciliation states.'},
        {'kind': 'ordered capture roots', 'per_query': 30, 'reason': 'Store.owner commits a full value and a distinct owner row, while every event commits one event row: 2*11+8.'},
        {'kind': 'distinct tape rows', 'per_query': 30, 'reason': 'close builds one exact three-tuple per prior capture root, each with a different positive ordinal.'},
        {'kind': 'distinct exact positive int nodes', 'per_query': 30, 'reason': 'The capture tape includes every exact integer from 1 through its length. Scalar interning can share existing equal values, but the node population still includes all those distinct integers.'},
    ],
    'disjointness': 'The counted owners are exact six-tuples, events thirteen-tuples, tape rows three-tuples, and ordinals exact integers. These four classes cannot share a node across classes; within a row class the different explicit ordinals prevent equality.',
    'formula_latex': '\\(N\\ge(11+8+30+30)Q=79\\cdot44113=3484927.\\)',
    'numeric': {'owner_rows': 11*q, 'event_rows': 8*q, 'capture_roots': 30*q, 'tape_rows': 30*q, 'distinct_positive_int_nodes': 30*q, 'distinct_DAG_nodes_lower': 79*q},
    'consequence': 'A node ceiling below this conditional lower bound cannot complete this exact format on the stated complete path. No concrete Store limits have been adopted.',
    'not_reviewed_or_proved': ['Optional graph observation/event/owner upper envelopes in the author note.', 'Whole new U/B/K work upper bounds or genuine Root callback fit.', 'Wire byte lower/upper bounds, Python object layout/RSS or 1GiB fit/infeasibility.', 'Whole schema correctness, G1 adoption, physical aggregate output closure, deadlines, qualification or theorem search.'],
    'old_copying_bound_scope': 'The previous conditional 403220376 copying-journal bound concerns the previous eight raw/five typed copies. It does not transfer as an operation bound to the batched immutable owner algorithm.',
    'no_partial_inference': 'No partial content or historical partial byte length is used for a new wire byte bound.',
    'authority': {'research_imports': 0, 'component_calls': 0, 'sizing_calls': 0, 'partial_reads': 0, 'new_grants': 0, 'actual_execution_authorized': False, 'G1_adopted': False, 'runtime_qualified': False, 'resource_accepted': False, 'mathematical_authority': False},
})

negatives = [pin(OUT / name) for name in ('typed-selected-owner-lifecycle-Source-negative-v1.json', 'typed-selected-module-descriptor-custody-Source-negative-v1.json')]
prior_names = (
    'typed-owner-provenance-Source-negative-v1.json', 'typed-tuple-key-cursor-resource-Source-negative-v1.json', 'typed-owner-route-shadow-Source-negative-v2.json',
    'typed-owner-route-v3-specific-Source-delta-review-v1.json', 'typed-owner-key-normal-form-v2-specific-Source-delta-review-v1.json')
prior_receipts = [pin(RUNS / 'gcts-whole-linkage-20261020/review-C' / name) for name in prior_names]
review = {
    'schema': 'typed-selected-complete-owner-composition-Source-review-v1', 'reviewer_identity': '/root/recovered_batch_review', 'source_only': True,
    'review_passed': False, 'status': 'COMPLETE_SELECTED_SOURCE_COVERAGE_WITH_BLOCKING_INDEPENDENT_LIFECYCLE_AND_CUSTODY_GAPS',
    'handoff': pin(BASE / 'handoff-v1.json'), 'sources': source_pins, 'master': pin(master), 'python': pin(PYTHON),
    'raw_custody': pin(OUT / 'selected-owner-Source-custody-v1.json'), 'coverage_matrix': matrix, 'conditional_node_bound_review': resource,
    'prior_lineage_preserved': prior_receipts, 'new_frozen_negatives': negatives,
    'full_scope_inspected': ['All four selected core Sources: store, independent cursor-v2, schema-v3 and complete worker; all 199 nested function definitions inventoried.', 'Complete native rules/catalog and exact integration suffix; all 24 original packet fields/descendants, both raw/decoded banks and all literal population declarations.', 'All 15 normal cases, 33 original diagnostics, 28 new groups/55 variants, failed profile lifetime/progress accounting, complete graph snapshots/catalog and all 88 unrun new-format recipes.', 'Cumulative Work, mutable capture versions, immutable cache/raw owners, event/owner scopes/routes/LIFO/call maps, query production/preimage/delivery/reconciliation, error metadata/private-origin scope and final real callback custody.'],
    'manual_findings': [
        {'topic': 'Full original data preservation', 'finding': 'The selected producer carries the full original native packet and both complete raw/decoded input banks; the strict cursor compares complete ordered descendants before and after verification callbacks. The complete catalog is reconstructed independently. The producer does not replace original proof/search/oracle outputs with summaries.'},
        {'topic': 'Strict value canonicalization', 'finding': 'Distinct scalar/list/tuple/dict tags, canonical exact finite floats, integer magnitudes, surrogatepass strings and all child edge occurrences are retained. Independent parsing checks canonical level/record order, prior children, minimal encodings, dictionary key equality, reachability and trailing data. This is a manual conditional correspondence argument, not a mechanized theorem.'},
        {'topic': 'Mutable and immutable ownership', 'finding': 'Each mutable capture has a fresh memo. Cross-call tuple reuse requires recursively exact immutability and retained actual owners. Every owner/event occurrence has its own ordinal even when complete value nodes share. Raw state/value/error owners and event placeholders are retained before new callbacks.'},
        {'topic': 'Cursor key correction', 'finding': 'Selected cursor-v2 removes the specifically reviewed nested native tuple hashing recurrence. Numeric key classes use exact rational equality and tuple key classes use child class IDs. Whole CPU/byte/RSS fit is not thereby established.'},
        {'topic': 'Provenance and query joins', 'finding': 'Selected schema-v3 fixes the previously reviewed route shadow and requires real earlier scope owners, owner role/scope/version/route joins, event LIFO/call maps, query registration, production/preimage typed equality and exact delivered owner. These do not discharge the separately frozen reconciliation/custody completeness negatives.'},
        {'topic': 'Reconciliation-to-final-receipt missing join', 'finding': 'The after-tree is only retained in reconciled state and compared to the original before-tree for its boolean equality result. It is not independently joined to the final mutated raw receipt in negative diagnostics.'},
        {'topic': 'Reconciliation occurrence conservation missing', 'finding': 'No final required-position assertion demands RECONCILE_VERSION and RECONCILE_RESULT exactly once per reconciled receipt in the correct phase/order. Coherent omission is not rejected by this predicate.'},
        {'topic': 'Custody phase occurrence conservation missing', 'finding': 'CUSTODY events are validated when present, but their entry/exit attempts and completions are not conserved against the corresponding final lifetime flags. Coherent omission of empty custody pairs can leave all counted calls/queries intact.'},
        {'topic': 'Whole module descriptor binding gap', 'finding': 'Session module seals erase staticmethod/classmethod wrappers before comparison. The strong named callback seal covers reachable callback-captured classes but does not constitute a complete loaded-module/class binding seal.'},
        {'topic': 'Fault ownership and counts', 'finding': 'Original private owner classifiers and genuine Root first-fault policy remain. New public Invalid/Limit annotations are explicitly not private-origin credentials; no new expected classifier relies on them. Actual exceptions/Work/callback owners remain separate from nonreplayable serialized IDs. Unknown failed constructor costs stay unavailable.'},
        {'topic': 'Original controls preserved', 'finding': '104 current worker functions have exact predecessor ASTs. The changed six and new ten definitions were reviewed in full context. Original graph/oracle/dynamic Root dispatcher and complete bank semantics remain preserved Source dependencies; that is not a new all-engine correctness proof or GCTS/RL performance result.'},
        {'topic': 'Changed evidence gate', 'finding': 'G1 charges unique complete canonical wire including occurrence metadata and banks. This is an explicit changed, unadopted independent predicate. It is not compression satisfying old G0 unfolding and cannot rescue historical negatives.'},
    ],
    'failed_checks': [
        'Independent post-reconciliation typed tree to final mutated raw receipt correspondence is missing.',
        'Independent per-position reconciliation pair occurrence/completeness/order conservation is missing.',
        'Independent custody entry/exit phase occurrence conservation against full lifetime flags is missing.',
        'Exact whole loaded-module descriptor binding is not enforced by the selected callable_seal.',
    ],
    'metadata_AST_checks': CHECKS, 'metadata_failed_checks': [],
    'additional_unrun_recipes_required': ['Coherently omitted reconciliation pairs, not merely malformed retained pairs.', 'A right reconciliation tree changed consistently with its boolean but inconsistent with final mutated raw receipt.', 'Coherently omitted custody entry/exit events with unchanged lifetime flags.', 'Loaded module plain/static/class descriptor replacement with the same function object.'],
    'unresolved_outer_and_resource_obligations': ['Fresh exact Root Source/runtime/stdlib/plan/declaration/epoch/grant/controller bindings; no outer offer has been qualified by this inner review.', 'Corrected complete independent lifecycle and callable module predicates, with separately frozen successor Source/reviews.', 'Aggregate physical/G1 logical output/header/result/log/failure-summary/reserve closure under original unchanged caps.', 'Whole new work/reference/node/wire/HWM/deadline upper bounds; the reviewed node lower bound is not fit.', 'Fresh complete reviewed once qualification only after all separate readiness requirements, never historical grant reuse or partial admission.'],
    'meaning': 'The complete selected composition has been assessed, and is not ready for whole evidence admission. A full source coverage matrix and specific positive manual findings do not override the explicit blocking predicates.',
    'authority': {'research_imports': 0, 'component_calls': 0, 'checker_calls': 0, 'fixture_calls': 0, 'generator_calls': 0, 'sizing_calls': 0, 'semantic_replays': 0, 'partial_content_reads': 0, 'new_actuals': 0, 'new_grants': 0, 'actual_execution_authorized': False, 'G1_adopted': False, 'runtime_qualified': False, 'resource_accepted': False, 'full_pipeline_qualified': False, 'proof_discovery': False, 'mathematical_authority': False},
}
result = write('typed-selected-complete-owner-composition-Source-review-v1.json', review)
print(json.dumps({'matrix': matrix, 'conditional_node_bound': resource, 'full_review': result, 'metadata_checks': len(CHECKS)}, sort_keys=True))
