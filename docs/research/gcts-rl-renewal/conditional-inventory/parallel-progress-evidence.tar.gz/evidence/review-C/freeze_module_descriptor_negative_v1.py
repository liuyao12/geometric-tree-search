"""Reviewer metadata only. Does not import or execute any research Source."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
OUT = ROOT / 'gcts-initialized-bridge-20261020/review-C'
SUBJECT = ROOT / 'gcts-whole-linkage-20261020/schema-B/qualify_owner_batch_worker_v1.py'

def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

assert pin(SUBJECT)['sha256'] == 'f6c28c149261274eaa133527c3bd3a306de47b45afa38e48daf5313436f0bacc'
raw = SUBJECT.read_bytes()
copy = OUT / 'selected-module-descriptor-negative-preimage-v1.py'
assert not copy.exists()
copy.write_bytes(raw)
receipt = {
    'schema': 'typed-selected-module-descriptor-custody-Source-negative-v1',
    'reviewer_identity': '/root/recovered_batch_review',
    'review_passed': False,
    'status': 'BLOCKING_EXACT_MODULE_DESCRIPTOR_BINDING_PREDICATE_GAP',
    'source_only': True,
    'subject': pin(SUBJECT),
    'independent_exact_raw_preimage': pin(copy),
    'earlier_custody_capture': pin(OUT / 'selected-owner-Source-custody-v1.json'),
    'scope': 'The exact module/class binding custody claimed by Session.guard; this is not a false-proof result, a measured execution failure, or a hostile introspection security claim.',
    'Source_paths': [
        {'function': 'callable_seal', 'lines': [108, 134], 'observation': 'Module-defined class traversal replaces exact staticmethod and classmethod objects by their __func__ before creating pending rows. It records neither descriptor type nor descriptor owner. Plain function, staticmethod(function) and classmethod(function) therefore take the identical underlying-function row at the same qualified member name.'},
        {'function': 'Session.__init__/load/guard', 'lines': [298, 367, 321, 325], 'observation': 'Worker and every loaded module use callable_seal for baseline and final module binding checks; complete Source byte checks do not detect in-memory descriptor replacement.'},
        {'function': '_recursive_function_owner_seal', 'lines': [1887, 1963], 'observation': 'The stronger named seal includes descriptor type/owner, class bases/MRO and every member edge, but starts only from exact callback functions and follows defaults/cells/functions/classes. A captured Session or module object is retained as an owner without walking its attributes or globals.'},
        {'function': '_linked_final_custody', 'lines': [2097, 2102], 'observation': 'Final evidence callback seals and the original profile seals do not replace the weak module seal. The function finishes with Session.guard.'},
    ],
    'manual_counterexample_recipe_unrun': [
        'Choose a module-defined class C and a class member f whose exact underlying function object is retained from vars(C)[name]. Begin after the real loader has recorded its baseline seal.',
        'Replace only that class member by staticmethod(the_same_f), or replace a staticmethod wrapper by classmethod(the_same_f). Do not change Source bytes, the class object, function object, code, defaults, closure tuple or closure contents.',
        'The old and new callable_seal traversal both place the same underlying f at the same qualified member key. Every recorded row is identical by direct inspection of the traversal.',
        'Descriptor binding semantics differ: a plain method binds an instance, staticmethod does not, and classmethod binds the class. The exact module-binding predicate should reject that change even if a subsequent call fails for some other reason.',
        'No callback, class mutation, module load, seal function, probe or hypothetical encoding was executed by this reviewer.',
    ],
    'why_existing_checks_do_not_discharge': [
        'Raw Source pin equality constrains file bytes, not the in-memory class descriptor object.',
        'The named callback seal is a valuable separately reviewed correction for classes reachable through captured function/class edges. It is not a complete traversal of Session.modules or loaded-module global bindings.',
        'Generic first-fault policy can retain a later TypeError or policy error, but does not make the stated exact module binding equality predicate injective.',
    ],
    'required_successor_obligation': 'Use a complete named descriptor-aware module baseline and final comparison (including all relevant aliases/owners), or explicitly restrict the component contract and require an outer exact module-binding verifier. A frozen successor requires a fresh independent Source delta review; this reviewer has not authored or applied a fix.',
    'unrun_diagnostics': [
        {'id': 'module-method-to-staticmethod-same-function', 'expected_contract': 'Exact module custody refuses, independently of later invocation behavior.'},
        {'id': 'module-staticmethod-to-classmethod-same-function', 'expected_contract': 'Exact module custody refuses with original underlying function retained.'},
        {'id': 'module-descriptor-unchanged-positive-control', 'expected_contract': 'Unchanged exact wrapper/function/binding accepted by custody alone, subject to all other gates.'},
        {'id': 'callback-captured-class-wrapper-control', 'expected_contract': 'Existing named seal must continue to detect the analogous reachable-class mutation.'},
    ],
    'authority': {'component_calls': 0, 'imports_of_research_Source': 0, 'mutation_probes': 0, 'partial_content_reads': 0, 'actual_execution_authorized': False, 'full_composition_pass': False, 'G1_adopted': False, 'runtime_qualified': False, 'resource_accepted': False, 'mathematical_authority': False},
}
path = OUT / 'typed-selected-module-descriptor-custody-Source-negative-v1.json'
assert not path.exists()
path.write_text(json.dumps(receipt, indent=2, ensure_ascii=True) + '\n')
print(json.dumps(pin(path), sort_keys=True))
