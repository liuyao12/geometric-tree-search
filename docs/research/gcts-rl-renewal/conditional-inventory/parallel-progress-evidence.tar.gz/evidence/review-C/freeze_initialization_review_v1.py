"""Independent metadata/AST only; no scientific Source imports or calls."""
import ast
import hashlib
import json
from pathlib import Path

RUNS = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
BASE = RUNS / 'gcts-initialized-bridge-20261020/init-L'
OUT = RUNS / 'gcts-initialized-bridge-20261020/review-C'
def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def read(path):
    assert '.partial' not in str(path)
    return json.loads(path.read_bytes())
handoff = BASE / 'handoff-v1.json'
manifest_path = BASE / 'freeze-manifest-v1.json'
assert pin(handoff)['sha256'] == 'dad1acffed871a3130b31fd5d055bd81fc90306e1496b2d66b5f31a81ae93232'
assert pin(manifest_path)['sha256'] == 'c393caabc154abea55fdb25161ed6fe5f45a81531761117d39fce36fee77a320'
manifest = read(manifest_path)
checks = []
for row in manifest['artifacts'] + manifest['dependencies']:
    actual = pin(Path(row['path']))
    assert actual == {key: row[key] for key in ('path', 'bytes', 'sha256')}, row['path']
    checks.append({'path': row['path'], 'exact_pin': True})
source = BASE / 'physical_wang_initialization_v1.py'
legacy = RUNS / 'gcts-batch-20261020/recovered/inherited-Source/wang_unknown_certificate_initializer_v1.py'
tree = ast.parse(source.read_bytes(), filename=str(source))
legacy_tree = ast.parse(legacy.read_bytes(), filename=str(legacy))
unused_code = compile(tree, str(source), 'exec')
unused_legacy_code = compile(legacy_tree, str(legacy), 'exec')
functions = []
def visit(node, prefix=''):
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.ClassDef)):
            name = prefix + child.name
            if isinstance(child, ast.FunctionDef):
                functions.append({'function': name, 'first_line': child.lineno, 'last_line': child.end_lineno})
            visit(child, name + '.')
        else:
            visit(child, prefix)
visit(tree)
assert len(functions) == 14
bank_path = BASE / 'declarative-whole-bank-v1.json'
bank = read(bank_path)
assert len(bank['groups']) == bank['group_count'] == 36
assert all(row['status'] == 'UNRUN' and row['source_reasoning_only'] is True for row in bank['groups'])
manual_path = BASE / 'manual-correspondence-v1.json'
manual = read(manual_path)
assert len(manual['literal_tile_patterns']) == 14 and len(manual['argument']) == 10
copy_dir = OUT / 'initialization-reviewed-Sources-v1'
assert not copy_dir.exists()
copy_dir.mkdir()
copies = []
for path in [handoff, manifest_path] + [Path(row['path']) for row in manifest['artifacts']] + [legacy]:
    target = copy_dir / path.name
    assert not target.exists()
    target.write_bytes(path.read_bytes())
    copies.append(pin(target))
review = {
    'schema': 'typed-physical-Wang-initialization-Source-review-v1', 'reviewer_identity': '/root/recovered_batch_review',
    'review_passed': True, 'status': 'CONDITIONAL_COMPLETE_LAYOUT_GENERIC_WANG_CONSTRUCTOR_SOURCE_PASS_ONLY', 'source_only': True,
    'handoff': pin(handoff), 'manifest': pin(manifest_path), 'source': pin(source), 'API': pin(BASE / 'API-v1.json'), 'manual': pin(manual_path), 'whole_unrun_bank': pin(bank_path),
    'direct_legacy_compiler': pin(legacy), 'all_manifest_pin_checks': checks, 'independent_exact_raw_copies': copies,
    'full_read_scope': ['All14 initializer functions, complete API/manual/handoff/manifest and all36 declarative unrun cohorts.', 'Complete preserved generic unknown-certificate compiler Source, including full local rule/palette/cardinality, selector phase tiles, frame/collector colors, problem boundary pins, all required/admissible points and final literal reconciliation.', 'Exact prior reviewed Builderv2 rewind/lower ABI, joined program/value parser initialization requirements and previously reviewed runtime/register/frame Source pins. No generation or simulation was used.'],
    'all_functions': functions, 'AST_parsed': True, 'unused_compile': True,
    'manual_findings': [
        {'topic': 'Full fixed literal adapter', 'finding': 'Exact ordered38-symbol alphabet/16workspace/4halts and every working read slot are checked. Count/domain/duplicate checks imply all38*(Q-4) working rows; all152 halt slots are undefined. The bijection to integer symbols preserves each next/read/write/move. Shape checks alone intentionally do not establish genuine fixed Source provenance.'},
        {'topic': 'All complete initial bands', 'finding': 'The layout fixes unique global L/R, sixteen ordered headers, one @^ cursor and one raw# fence per band. It initializes HEAP3/R4/FRAMES5/STACK14/OUTPUT15 as empty colon records and6..13 as canonical zero words, each with positive blank tail. A single actual TM head is at global L in the physical PROGRAM entry. The sixteen marked band cursors are plain TM cells.'},
        {'topic': 'Rewind compatibility', 'finding': 'Builder rewind accepts raw^ beneath the marked @^, preserves it and advances to the first payload. All PROGRAM/value entry rewinds therefore compose with the chosen initial cursor convention under the exact prior helper ABI.'},
        {'topic': 'Fixed program and public boundary', 'finding': 'PROGRAM is pinned entirely, followed immediately by colon and positive blank tail. PUBLIC pins all supplied bits, exactly one fixed semicolon and precolon blanks, then a fixed colon and positive postcolon tail. Binary shape validation does not decode or approve semantic program/public data.'},
        {'topic': 'Genuinely unknown certificate', 'finding': 'Exactly one contiguous interval is omitted from fixed prefix/suffix, with its following colon and entire later tape fixed. PRE/ACTIVE can emit only bits or one semicolon into PAD; PAD emits only blank, and only PAD can exit into fixed POST. Thus exactly binary-star semicolon blank-star of the interval length can occur, with no free head/cursor/header/colon/fence.'},
        {'topic': 'Full palette independence', 'finding': 'The actual preserved generic compiler is called with the complete adapted machine and fixed wire mapping. Program/public bits/capacities/horizon only enter boundary construction. Every generic step/initializer/frame/collector tile remains in the palette and is admissible at every required origin. No reachability or target-specific trim is introduced.'},
        {'topic': 'Full local spacetime argument', 'finding': 'Matching pair colors force adjacent step triples to overlap on identical cells. Vertical cell colors preserve configurations. From the single initial head, the partial radius-one update is a deterministic machine step and rejects wall-crossing/undefined-head transitions. Frame exterior colors force frames to the board sides. Distinct initializer/step/seen color constructors prevent row mixing.'},
        {'topic': 'Exact finite acceptance horizon', 'finding': 'The board has one initializer row, exactly T step rows and one collector row. The collector seen-chain starts0 and ends1; only an accepting head changes it. Collection emits stop and done side colors that cannot begin another row, so an earlier accepting prefix cannot fill a longer board. This is conditional finite machine-history correctness of the literal generic construction, not checker/proof soundness.'},
        {'topic': 'Exact point-model reduction', 'finding': 'A tile has t=1 only at its center. Allowed origins are all required even-coordinate board centers, so exact t requires one tile per center. Adjacent m overlaps are precisely shared edge midpoints and exact color equality; exterior midpoint pins impose the boundary. No corner or geometric/rotation predicate is needed. This supplies a finite translation-only point problem, not a qualified GCTS frontier scheduler.'},
        {'topic': 'Cardinality and dimensions', 'finding': 'The manual full retained tile formula agrees with the complete Source family counts. The layout width is50 plus the16 payload capacities, and board dimensions are W+2 by T+2. The generic triple-product generator is still potentially very expensive. No state/tile/color/work/byte/RSS fit is proved or inferred from the formula.'},
        {'topic': 'Raw failures and budgets', 'finding': 'Actual produced adapter rows/cells/layout/problem are retained in state; BaseException uses bare raise and best-effort nonmasking attachment. A failure in Work construction or legacy internals relies on retained actual traceback locals, as the API explicitly requires. Original legacy private-limit-before-callback order is unchanged; Root must check its genuine first-fault/clock before classifying any planned sentinel. Adapter+legacy private work is summed; both use the same cumulative Root callback.'},
    ],
    'important_scope_conditions': ['The table and legacy compiler must be genuine freshly constructed exact pinned dependency outputs; a shape-compatible malicious object has no authority.', 'Inputs are exclusively owned and callbacks read-only. Whole module/callback binding and first-fault custody are separate Root obligations.', 'The program and public data are exact literal pins only; compiled common-kernel Source/image, native/rawJSON and licensed theory/target correspondence are not established.', 'The generic finite history argument is manual and Source-conditional. There is no generated full table/palette, initialized control history, tiling or execution result in this milestone.', 'No full physical macro-step/initial BOOT/structural heap embedding or full accepted-language theorem follows from this constructor review.', 'Original15/33+28/55 cohort, previous negatives and unchanged limits remain; new36 cohorts are supplementary and entirely unrun.'],
    'all36_unrun_cohorts': [{'index': i, 'id': row['id'], 'level': row['level'], 'status': row['status']} for i, row in enumerate(bank['groups'])],
    'remaining': ['Fresh complete fixed join/lowering/palette construction and full component/whole-bank qualification only in a separately reviewed Root once.', 'Full source/image/public-license/native-domain attribution and all13physical opcode/BOOT/initialization accepted-language bridge.', 'Corrected inner evidence/lifecycle/module-custody predicates and complete outer/resource closure; current B selected composition remains negative.', 'A useful complete machine/palette/output/work/HWM/deadline bound under unchanged limits.', 'Actual theorem proof search, certified learned markings, receptor/lemma inventory discovery, RL and matched baseline evidence.'],
    'failed_checks': [],
    'authority': {'research_imports': 0, 'component_calls': 0, 'compiler_calls': 0, 'table_generation': 0, 'tiles_emitted': 0, 'fixture_calls': 0, 'simulator_calls': 0, 'sizing_calls': 0, 'partial_content_reads': 0, 'new_actuals': 0, 'new_grants': 0, 'actual_execution_authorized': False, 'runtime_qualified': False, 'full_VM_qualified': False, 'full_initialized_Wang_acceptance_bridge_admitted': False, 'G1_adopted': False, 'fit_proved': False, 'proof_discovery': False, 'GCTS_RL_advantage_established': False},
}
path = OUT / 'typed-physical-Wang-initialization-Source-review-v1.json'
assert not path.exists()
path.write_text(json.dumps(review, indent=2, ensure_ascii=True) + '\n')
print(json.dumps(pin(path), sort_keys=True))
