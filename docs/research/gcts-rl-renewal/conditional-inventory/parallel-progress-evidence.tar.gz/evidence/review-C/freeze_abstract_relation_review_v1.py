"""Passive reviewer metadata/AST; research Sources are never imported/called."""
import ast
import hashlib
import json
from pathlib import Path

RUNS = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
BASE = RUNS / 'gcts-initialized-bridge-20261020/root'
OUT = RUNS / 'gcts-initialized-bridge-20261020/review-C'
def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
source = BASE / 'abstract_heap_relation_v1.py'
manual_path = BASE / 'manual-abstract-refinement-and-unrun-bank-v1.json'
assert pin(source)['sha256'] == 'db67b9d9ddb5a657b5836c39c73ab87dad0d95fdb8df302f946e10f3316b3721'
assert pin(manual_path)['sha256'] == 'ec20db69640e28e2baf3f59925adaba198ef29620caa22043c59b4c0a269cc8f'
manual = json.loads(manual_path.read_bytes())
tree = ast.parse(source.read_bytes(), filename=str(source))
unused_code = compile(tree, str(source), 'exec')
functions = []
def visit(node, prefix=''):
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.ClassDef)):
            name = prefix + child.name
            if isinstance(child, ast.FunctionDef):
                functions.append({'function': name, 'first_line': child.lineno, 'last_line': child.end_lineno})
            visit(child, name + '.')
        else:
            visit(child, prefix)
visit(tree)
copies = []
for path in (source, manual_path, BASE / 'abstract-relation-Source-offer-v1.json'):
    destination = OUT / ('abstract-relation-reviewed-' + path.name)
    assert not destination.exists()
    destination.write_bytes(path.read_bytes())
    copies.append(pin(destination))
assert len(manual['sections']) == 8 and len(manual['all13_opcode_cases']) == 13 and len(manual['unrun_families']) == 12
review = {
    'schema': 'typed-abstract-heap-relation-Source-and-manual-review-v1', 'reviewer_identity': '/root/recovered_batch_review',
    'review_passed': True, 'status': 'CONDITIONAL_MANUAL_ABSTRACT_ARGUMENT_AND_FINITE_RELATION_SOURCE_PASS_ONLY', 'source_only': True,
    'offer': pin(BASE / 'abstract-relation-Source-offer-v1.json'), 'source': pin(source), 'manual': pin(manual_path), 'independent_raw_copies': copies,
    'all_functions': functions, 'all_function_bodies_inspected': True, 'AST_parsed': True, 'unused_compile': True,
    'manual_findings': [
        {'topic': 'Complete canonical heap domain', 'finding': 'Exact tuple pair records and exact prior integer child references make structural values well-founded. Rejecting duplicate ordered reference pairs makes representation injective by induction on maximum structural height. Atoms and pairs are disjoint.'},
        {'topic': 'Complete embedding', 'finding': 'Every source node has an actual target pair image; every image is distinct; both child equations are checked for every source pair. Atoms map identically by definition. The declared seed prefix is compared record-by-record and must have the identity image. No source node is replaced by a selected subset.'},
        {'topic': 'Mathematical extension', 'finding': 'If the target contains every source structural value, uniqueness provides the embedding. Appending canonical nodes preserves old values and old images; canonical cons either reuses a pair or extends the embedding. The inclusion premise is explicit and is not established for the real initialized machine by this Source.'},
        {'topic': 'Complete decoded state', 'finding': 'The finite checker inspects active function/PC, every register and every bottom-to-top saved frame, including saved function/continuation/destination and every register. Exact shapes are externally attributed to the same program. One-past-end PC is a related nonfetchable state, not an acceptance claim.'},
        {'topic': 'All thirteen opcodes', 'finding': 'The manual covers const/move/cons/head/tail/pair/atom/succ/not/branch/jump/call/return. It agrees with the pinned abstract tree VM: operands precede destination writes, pair-kind is preserved, atom equality includes nil but excludes pairs, succ requires a byte below 255, Boolean operations require 0/1, CALL saves advanced PC/all caller registers and reads all arguments before rewrite, root return accepts exactly 1.'},
        {'topic': 'Finite simulation theorem scope', 'finding': 'Under the same validated immutable program, complete initial structural inclusion/state relation, correct abstract opcode semantics and finite successful administrative work, induction on a finite valid execution preserves the relation and root decision. This is a defensible conditional manual theorem. It is not an all-input status/cost equivalence or physical macro-step proof.'},
        {'topic': 'Types and invalid carriers', 'finding': 'The checker uses exact int/tuple tests for reference/control/state carriers; booleans and subclasses are not references. Invalid mapping/shape/vector/frame paths refuse. Heap dictionaries hash only flat exact pairs of integer references; this Source does not construct recursive native value tuples as hash keys.'},
        {'topic': 'Fault and raw ownership', 'finding': 'The entry holds full raw input owners and actual Work before start invokes the Root callback. Work calls genuine Root before private limit classification. Public exceptions default owner=None; genuine owned raises supply the private owner. Foreign exceptions are reraised without replacement and attachment is best-effort. This remains a nonhostile/read-only callback baseline, not a security sandbox.'},
    ],
    'functions_by_obligation': {
        'errors_work': ['Invalid.__init__','Limit.__init__','is_owned_invalid','is_owned_limit','_need','_Work.__init__','_Work.start','_Work.step','_attach'],
        'heaps': ['_integer','_heap','_image','_embedding'],
        'states': ['_shapes','_vector','_control','_state','_vectors_correspond'],
        'entries': ['_finish','check_heap_embedding','check_decoded_state_relation'],
    },
    'manual_sections': manual['sections'], 'all13_opcode_cases': manual['all13_opcode_cases'], 'whole_unrun_bank': manual['unrun_families'],
    'remaining_bridge_obligations': ['Complete source program/shapes/constant and public theory/target licensing attribution.', 'Actual BOOT/program initialization establishes structural inclusion of every source heap node and corresponding input state.', 'Full physical state decoder and all thirteen physical macro-step refinements, including helper scratch/administrative canonical allocation.', 'Complete Wang initialization/spacetime/collector history-to-acceptance bridge.', 'Full controller/evidence/custody/resource/once qualification and original full bank.', 'Actual proof search, discovered theorems, learned markings and RL remain absent.'],
    'failed_checks': [],
    'not_implied_by_pass': {'program_validated': False, 'physical_decoder': False, 'transition_checker': False, 'physical_trace_verified': False, 'execution_verified': False, 'proof_checked': False, 'whole_accepted_language_refinement': False, 'cost_or_status_equivalence': False, 'resource_fit': False},
    'authority': {'research_imports': 0, 'component_calls': 0, 'fixtures': 0, 'simulation': 0, 'generation': 0, 'sizing': 0, 'partial_content_reads': 0, 'actual_execution_authorized': False, 'new_actuals': 0, 'new_grants': 0, 'G1_adopted': False, 'mathematical_proof_discovery': False},
}
path = OUT / 'typed-abstract-heap-relation-Source-and-manual-review-v1.json'
assert not path.exists()
path.write_text(json.dumps(review, indent=2, ensure_ascii=True) + '\n')
print(json.dumps({'review': pin(path), 'functions': len(functions)}, sort_keys=True))
