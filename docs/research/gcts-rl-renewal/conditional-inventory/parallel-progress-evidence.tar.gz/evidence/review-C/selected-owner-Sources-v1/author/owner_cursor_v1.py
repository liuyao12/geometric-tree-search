"""SOURCE ONLY independent complete-wire strict DAG parser and readonly cursor.
No producer imports, native parent expansion, oracle or subject operations.
"""
VERSION='immutable-owner-cursor-v1'
MAGIC=b'GCTSOWN1\x00'
_PRIVATE=object()
class Invalid(Exception):
    def __init__(self,reason):self.reason=reason;self.owner=_PRIVATE;super().__init__(reason)
def need(ok,reason):
    if not ok:raise Invalid(reason)


class Document:
    def __init__(self,wire,*,work,retain):
        self.wire=wire;self.work=work;self.nodes=[];self.roots=[];self.error=None
        self.keys={};self.key_owners=[];self.key_items=0;self.key_maps={};self.retained=[wire,work,retain]
        need(callable(retain)and retain(self)is None,'Root retains parser before first check')
        try:self._parse()
        except BaseException as error:self.error=error;self.retained.append(error);raise
    def _parse(self):
        w=self.work;w.gate();wire=self.wire
        need(type(wire)is bytes,'complete exact immutable wire only');w.bound('wire_bytes',len(wire))
        need(wire.startswith(MAGIC),'owner wire magic')
        pos=len(MAGIC)
        def read_uint(end):
            nonlocal pos
            value=0;shift=0;started=pos
            while True:
                w.step();need(pos<end,'complete minimal unsigned integer')
                b=wire[pos];pos+=1;value|=(b&127)<<shift
                need(shift<=w.limits['integer_bits']+7,'unsigned width bound')
                if not b&128:
                    need(pos==started+1 or b!=0,'minimal unsigned encoding');return value
                shift+=7
        count=read_uint(len(wire));w.bound('nodes',count)
        prior_depth=-1;prior_record=None;depths=[]
        for ordinal in range(1,count+1):
            w.step();size=read_uint(len(wire));w.bound('record_bytes',size)
            start=pos;end=start+size;need(size>0 and end<=len(wire),'complete nonempty node record')
            record=memoryview(wire)[start:end];w.bytework(size)
            # Strict record order within computed depth already excludes every
            # duplicate: equal records necessarily have equal child IDs/depth.
            # A second full-record hash table would duplicate parser memory.
            tag=wire[pos];pos+=1;payload=None;children=()
            if tag<=2:pass
            elif tag==3:
                need(pos<end and wire[pos]in(0,1),'exact integer sign');negative=wire[pos];pos+=1
                n=read_uint(end);need(pos+n==end,'integer magnitude exact length')
                need(n<=(w.limits['integer_bits']+7)//8,'integer length preflight');need(n==0 or wire[pos]!=0,'minimal integer magnitude')
                magnitude=int.from_bytes(wire[pos:end],'big');pos=end
                w.bound('integer_bits',magnitude.bit_length())
                need(not negative or magnitude!=0,'no negative integer zero');payload=-magnitude if negative else magnitude
            elif tag in(4,5):
                n=read_uint(end);need(pos+n==end,'scalar exact length')
                w.bound('string_bytes',n);text=wire[pos:end];pos=end;w.bytework(n)
                if tag==5:
                    try:payload=text.decode('utf8','surrogatepass')
                    except UnicodeError:need(False,'strict surrogatepass UTF8')
                    need(payload.encode('utf8','surrogatepass')==text,'canonical UTF8 scalar')
                else:
                    try:payload=text.decode('ascii');value=float.fromhex(payload)
                    except(ValueError,UnicodeError):need(False,'strict float hexadecimal')
                    need(value.hex()==payload and payload not in('nan','inf','-inf'),'canonical finite exact float')
            elif tag in(6,7,8):
                arity=read_uint(end);n=2*arity if tag==8 else arity;w.refs(n)
                need(n<=end-pos,'reference count bounded by remaining bytes')
                refs=[]
                for unused in range(n):
                    child=read_uint(end);need(1<=child<ordinal,'earlier exact child reference');refs.append(child)
                children=tuple(refs)
            else:need(False,'unsupported exact tag')
            need(pos==end,'no trailing node bytes')
            depth=0
            for child in children:w.step();depth=max(depth,depths[child-1]+1)
            w.bound('depth',depth)
            need(depth>=prior_depth,'canonical increasing value depth')
            if depth==prior_depth:
                w.bytework(size+len(prior_record));need(prior_record<record.tobytes(),'canonical strictly ordered complete level records')
            prior_depth=depth;prior_record=record.tobytes();depths.append(depth)
            self.nodes.append((tag,payload,children))
        nroots=read_uint(len(wire));w.bound('roots',nroots);need(nroots>0,'complete control root')
        for unused in range(nroots):
            root=read_uint(len(wire));need(1<=root<=count,'valid root reference');self.roots.append(root)
        need(pos==len(wire),'no trailing complete-wire bytes')
        seen=set();pending=list(self.roots)
        while pending:
            node=pending.pop();w.step()
            if node in seen:continue
            seen.add(node)
            for child in self.nodes[node-1][2]:w.step();pending.append(child)
        need(len(seen)==count,'no unreachable hidden node')
        for node,(tag,payload,children)in enumerate(self.nodes,1):
            w.step()
            if tag==8:
                found={};mapping={};order=[]
                for offset in range(0,len(children),2):
                    w.step();keynode=children[offset];key=self._key(keynode,0)
                    need(key not in found,'exact native dictionary key equality collision prohibited')
                    found[key]=keynode;order.append(key)
                    if type(key)is str:mapping[key]=children[offset+1]
                self.key_maps[node]=(tuple(order),mapping)
        w.gate()
    def _key(self,node,depth):
        w=self.work;w.visit(depth)
        if node in self.keys:return self.keys[node]
        self.key_items+=1;w.bound('key_items',self.key_items)
        tag,payload,children=self.nodes[node-1]
        if tag==0:value=None
        elif tag==1:value=False
        elif tag==2:value=True
        elif tag in(3,5):value=payload
        elif tag==4:value=float.fromhex(payload)
        elif tag==7:
            parts=[]
            for child in children:parts.append(self._key(child,depth+1))
            value=tuple(parts)
        else:need(False,'only exact hashable native dictionary keys')
        self.keys[node]=value;self.key_owners.append(value);return value
    def cursor(self,node=None):return Cursor(self,self.roots[-1]if node is None else node)


class Cursor:
    """Explicit typed-node handle, not a native dict/list proxy or admission."""
    def __init__(self,document,node):
        need(type(node)is int and 1<=node<=len(document.nodes),'exact cursor node');self.doc=document;self.node=node
    def tag(self):self.doc.work.step();return self.doc.nodes[self.node-1][0]
    def scalar(self):
        w=self.doc.work;w.step();tag,payload,unused=self.doc.nodes[self.node-1]
        need(tag<=5,'exact scalar cursor')
        if tag==0:return None
        if tag==1:return False
        if tag==2:return True
        if tag==4:return float.fromhex(payload)
        return payload
    def length(self):
        self.doc.work.step();tag,payload,children=self.doc.nodes[self.node-1]
        need(tag in(6,7,8),'container cursor');return len(children)//2 if tag==8 else len(children)
    def index(self,index):
        self.doc.work.step();tag,payload,children=self.doc.nodes[self.node-1]
        need(tag in(6,7)and type(index)is int and 0<=index<len(children),'exact sequence index')
        return Cursor(self.doc,children[index])
    def fields(self):
        self.doc.work.step();need(self.tag()==8,'mapping cursor');return self.doc.key_maps[self.node][0]
    def field(self,key):
        self.doc.work.step();need(type(key)is str and self.tag()==8,'exact named mapping field')
        mapping=self.doc.key_maps[self.node][1];need(key in mapping,'required field exists');return Cursor(self.doc,mapping[key])
    def at(self,path):
        current=self
        for part in path:
            self.doc.work.step();current=current.field(part)if type(part)is str else current.index(part)
        return current
    def same(self,other):
        self.doc.work.step();need(type(other)is Cursor and self.doc is other.doc,'same independent document');return self.node==other.node
    def matches(self,value):
        """Full strict native correspondence; sharing memo retains occurrence edges.
        The native original is read only and strongly retained by Root. Mutable
        snapshots are never cached between this call and another call.
        """
        w=self.doc.work;active=set();done=set();self.doc.retained.append(value)
        def visit(node,x,depth):
            w.visit(depth);tag,payload,children=self.doc.nodes[node-1];kind=type(x)
            expected=0 if x is None else 2 if kind is bool and x else 1 if kind is bool else 3 if kind is int else 4 if kind is float else 5 if kind is str else 6 if kind is list else 7 if kind is tuple else 8 if kind is dict else -1
            need(tag==expected,'full strict type correspondence')
            if tag<=2:return
            if tag==4:need(x.hex()==payload,'full exact finite float correspondence');return
            if tag in(3,5):
                if tag==5:w.bytework(len(x.encode('utf8','surrogatepass'))+len(payload.encode('utf8','surrogatepass')))
                else:w.bytework((abs(x).bit_length()+7)//8+(abs(payload).bit_length()+7)//8)
                need(x==payload,'full scalar correspondence');return
            pair=(node,id(x));need(id(x)not in active,'acyclic native original')
            if pair in done:return
            need(len(children)==(2*len(x)if tag==8 else len(x)),'full original container population')
            active.add(id(x))
            if tag==8:
                for i,(key,item)in enumerate(x.items()):
                    w.step();visit(children[2*i],key,depth+1);visit(children[2*i+1],item,depth+1)
            else:
                for child,item in zip(children,x):w.step();visit(child,item,depth+1)
            active.remove(id(x));done.add(pair)
        visit(self.node,value,0);return True


def parse(wire,*,work,retain):return Document(wire,work=work,retain=retain)
