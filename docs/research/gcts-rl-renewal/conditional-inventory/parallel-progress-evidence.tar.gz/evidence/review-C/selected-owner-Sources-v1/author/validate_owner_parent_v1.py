"""SOURCE ONLY independent whole-parent DAG cursor schema and provenance checker.
No producer call, subject/oracle call, native parent expansion, or hash admission.
Native population rules appended below inspect already-owned original values only
AFTER complete strict cursor correspondence. Full event/owner joins use cursors.
"""
VERSION='immutable-whole-owner-validator-v1'
OWNER_FIELDS=('ordinal','role','scope_owner','version','source_route','value')
EVENT_FIELDS=('ordinal','phase','kind','role','operation','scope_owner','parent_entry','entry','args_owner','value_owner','error_owner','version','complete')
STATE_FIELDS=('stage','request_owner','receipt_owner','preimage_owner','version_owner','counters')
COUNTER_FIELDS=('stage','failed_stage','attempted_queries','produced_receipt_count','preimage_completed_count','delivered_receipt_count','attempted_work','data_items')
_PRIVATE=object()
class Invalid(Exception):
    def __init__(self,reason):self.reason=reason;self.owner=_PRIVATE;super().__init__(reason)
def need(ok,reason):
    if not ok:raise Invalid(reason)

def _record(cursor,names):need(cursor.tag()==8 and cursor.fields()==names,'exact ordered cursor record')
def _columns(cursor,names):need(cursor.tag()==7 and cursor.length()==len(names),'exact versioned full column tuple')
def _column(cursor,names,key):return cursor.index(names.index(key))

def _scalar(cursor,kind=None):
    value=cursor.scalar()
    if kind is not None:need(type(value)is kind,'exact scalar type')
    return value

def _receipt_tree(raw,preimage):
    """Independent full correspondence to component's exact typed tuple tree."""
    w=raw.doc.work;pending=[(raw,preimage)];seen=set()
    while pending:
        left,right=pending.pop();w.step();pair=(left.node,right.node)
        if pair in seen:continue
        seen.add(pair);tag=left.tag()
        need(right.tag()==7 and right.length()in(1,2),'exact complete receipt preimage tuple')
        name=_scalar(right.index(0),str)
        wanted={0:'null',1:'bool',2:'bool',3:'int',5:'str',6:'list',7:'tuple',8:'dict'}
        need(tag in wanted and name==wanted[tag],'receipt strict type tag')
        if tag==0:need(right.length()==1,'null preimage arity');continue
        need(right.length()==2,'typed preimage arity');payload=right.index(1)
        if tag<=5:need(left.same(payload),'complete exact scalar receipt preimage');continue
        need(payload.tag()==7,'immutable exact child preimage sequence')
        children=left.doc.nodes[left.node-1][2]
        need(payload.length()==len(children),'every ordered receipt child in preimage')
        for i,child in enumerate(children):
            w.step();pending.append((left.doc.cursor(child),payload.index(i)))

def _live(document,control,p,profile_ids,requests,check):
    owners=control.field('owners');events=control.field('events');w=document.work
    need(owners.tag()==6 and events.tag()==6,'complete ordered owner and event arrays')
    ownerrows=[];scope_cache={}
    for i in range(owners.length()):
        check();row=owners.index(i)
        _columns(row,OWNER_FIELDS)
        need(_scalar(_column(row,OWNER_FIELDS,'ordinal'),int)==i+1,'distinct ordered owner occurrence')
        role=_scalar(_column(row,OWNER_FIELDS,'role'),str);version=_scalar(_column(row,OWNER_FIELDS,'version'),int)
        route=_scalar(_column(row,OWNER_FIELDS,'source_route'),str);scope=_scalar(_column(row,OWNER_FIELDS,'scope_owner'))
        need(version>=0 and route and role,'explicit owner provenance/version')
        need(scope is None or type(scope)is int and 1<=scope<=i,'earlier scope owner only')
        ownerrows.append((role,scope,version,route,_column(row,OWNER_FIELDS,'value')))
        if role=='scope':
            value=_column(row,OWNER_FIELDS,'value');_record(value,('case_id','profile_id','group_id','variant_id','origin'))
            literal={}
            for key in value.fields():
                item=_scalar(value.field(key));need(item is None or type(item)is str,'exact scope scalar');literal[key]=item
            need(scope is None,'scope owner cannot have recursive scope');scope_cache[i+1]=literal
    def owned(ref):
        need(type(ref)is int and 1<=ref<=len(ownerrows),'actual existing owner reference');return ownerrows[ref-1][4]
    def scope_value(ref):need(ref in scope_cache,'real earlier scope owner');return scope_cache[ref]
    def optional(row,name):
        value=_scalar(_column(row,EVENT_FIELDS,name));need(value is None or type(value)is int and 1<=value<=len(ownerrows),'optional exact owner reference');return value
    stack=[];entered={};completed=set();profiles=[];queries={};observed={};started={};returned={};raised={}
    cases=[];legacy=[];groups=[];variants=[];query_states={};profile_queries={};seen_produced={};seen_preimage={};normal_final={}
    vocabulary=('CALL','PROFILE','QUERY','CUSTODY','PROFILE_STATE','CASE','LEGACY_DIAGNOSTIC','DIAGNOSTIC_GROUP','DIAGNOSTIC_VARIANT','OBSERVATION','PROGRESS')
    for i in range(events.length()):
        check();row=events.index(i)
        _columns(row,EVENT_FIELDS)
        ordinal=_scalar(_column(row,EVENT_FIELDS,'ordinal'),int);phase=_scalar(_column(row,EVENT_FIELDS,'phase'),str)
        kind=_scalar(_column(row,EVENT_FIELDS,'kind'),str);role=_scalar(_column(row,EVENT_FIELDS,'role'),str);op=_scalar(_column(row,EVENT_FIELDS,'operation'),str)
        scope_ref=_scalar(_column(row,EVENT_FIELDS,'scope_owner'),int);scope=scope_value(scope_ref)
        parent=_scalar(_column(row,EVENT_FIELDS,'parent_entry'));entry=_scalar(_column(row,EVENT_FIELDS,'entry'))
        args_ref=optional(row,'args_owner');value_ref=optional(row,'value_owner');error_ref=optional(row,'error_owner')
        version=_scalar(_column(row,EVENT_FIELDS,'version'),int)
        need(ordinal==i+1 and version>=0 and _scalar(_column(row,EVENT_FIELDS,'complete'))is True,'every complete ordered event/version')
        need(kind in vocabulary and role and op,'closed explicit event vocabulary')
        if error_ref is not None:
            error=owned(error_ref);_record(error,('type_name','type_module','runtime_reference','replayable'))
            _scalar(error.field('type_name'),str);_scalar(error.field('type_module'),str)
            need(_scalar(error.field('runtime_reference'),int)>=0 and _scalar(error.field('replayable'))is False,'real error metadata not replayable identity')
        if phase=='ENTER':
            need(entry is None and parent==(stack[-1]if stack else None)and value_ref is None and error_ref is None,'entry/parent shape')
            entered[ordinal]=(kind,role,op,scope_ref,args_ref,version);stack.append(ordinal)
            if kind=='CASE':cases.append((scope['case_id'],owned(args_ref)))
            if kind=='LEGACY_DIAGNOSTIC':legacy.append((scope['case_id'],owned(args_ref)))
            if kind=='DIAGNOSTIC_GROUP':groups.append((scope['group_id'],owned(args_ref)))
            if kind=='DIAGNOSTIC_VARIANT':variants.append((scope['group_id'],scope['variant_id'],owned(args_ref)))
            if kind=='CALL':key=role+'.'+op;started[key]=started.get(key,0)+1
            elif kind=='PROFILE':
                pid=scope['profile_id'];need(pid in profile_ids and pid not in profiles,'one full attempted profile scope');profiles.append(pid)
                if scope['origin']=='wrapper':key='implicit.with_profile';started[key]=started.get(key,0)+1
            elif kind=='QUERY'and scope['origin']=='wrapper':
                request=owned(args_ref);need(request.tag()==7 and request.length()in(2,3),'full normal query arguments')
                operation=_scalar(request.index(0),str);need(operation in('count','select'),'known full query operation')
                key='implicit.profile_'+operation+'_query';started[key]=started.get(key,0)+1
            if kind=='QUERY':query_states[ordinal]=dict(request=args_ref,receipt=None,preimage=None,registered=False)
        elif phase in('RETURN','RAISE'):
            need(type(entry)is int and stack and entry==stack[-1]and entry not in completed,'distinct exact LIFO exit')
            source=entered[entry];need((kind,role,op,scope_ref,version)==(source[0],source[1],source[2],source[3],source[5]),'same occurrence provenance')
            need(parent==entry and ((phase=='RAISE')==(error_ref is not None)),'exact exit/error scope')
            completed.add(entry);stack.pop();key=None
            if kind=='CALL':key=role+'.'+op
            elif kind=='PROFILE'and scope['origin']=='wrapper':key='implicit.with_profile'
            elif kind=='QUERY'and scope['origin']=='wrapper':key='implicit.profile_'+_scalar(owned(source[4]).index(0),str)+'_query'
            if key is not None:
                target=raised if phase=='RAISE'else returned;target[key]=target.get(key,0)+1
            if kind=='OBSERVATION'and phase=='RETURN':observed.setdefault(scope['case_id'],[]).append(owned(source[4]))
            if kind=='QUERY'and phase=='RETURN':
                state=query_states[entry];need(state['registered']and state['receipt']is not None and state['preimage']is not None and value_ref==state['receipt'],'delivered result is exact produced owner')
            if kind=='PROFILE':
                need(value_ref is not None,'complete profile exit lifetime owner');final=owned(value_ref)
                _record(final,('result','lifetime'));normal_final[scope['profile_id']]=(phase,final)
        else:
            need(phase=='SNAPSHOT'and entry is None and parent==(stack[-1]if stack else None)and args_ref is None and error_ref is None,'exact snapshot occurrence')
            need(value_ref is not None,'complete snapshot value owner')
            if kind=='PROFILE_STATE':
                value=owned(value_ref)
                _columns(value,STATE_FIELDS)
                refs={}
                for field in('request_owner','receipt_owner','preimage_owner','version_owner'):
                    refs[field]=_scalar(_column(value,STATE_FIELDS,field))
                    if refs[field]is not None:owned(refs[field])
                pid=scope['profile_id'];counters=_column(value,STATE_FIELDS,'counters')
                _columns(counters,COUNTER_FIELDS)
                for field in('attempted_queries','produced_receipt_count','preimage_completed_count','delivered_receipt_count'):
                    need(_scalar(_column(counters,COUNTER_FIELDS,field),int)>=0,'nonnegative lifetime counters')
                if op=='QUERY_REGISTERED':
                    need(refs['request_owner']is not None,'registered full request owner');queries.setdefault(pid,[]).append(owned(refs['request_owner']))
                    need(stack and entered[stack[-1]][0]=='QUERY','registered current actual query');current=query_states[stack[-1]]
                    need(not current['registered']and refs['request_owner']==current['request'],'one registration of exact entered query arguments');current['registered']=True
                if op=='QUERY_PRODUCED':
                    need(refs['receipt_owner']is not None,'raw completed receipt owner before first preimage copy')
                    need(stack and entered[stack[-1]][0]=='QUERY','production in actual query scope');current=query_states[stack[-1]]
                    need(current['registered']and current['receipt']is None,'one production after registration');current['receipt']=refs['receipt_owner']
                    seen_produced.setdefault(pid,[]).append(refs['receipt_owner'])
                if op=='QUERY_PREIMAGE':
                    need(refs['preimage_owner']is not None,'full immutable preimage owner before callback/delivery')
                    need(stack and entered[stack[-1]][0]=='QUERY','preimage in actual query scope');current=query_states[stack[-1]]
                    need(current['receipt']==refs['receipt_owner']and current['preimage']is None,'preimage after exact raw production');current['preimage']=refs['preimage_owner']
                    _receipt_tree(owned(current['receipt']),owned(current['preimage']))
                    seen_preimage.setdefault(pid,[]).append(refs['preimage_owner'])
                if op=='QUERY_DELIVERED':
                    need(stack and entered[stack[-1]][0]=='QUERY','delivery in actual query scope');current=query_states[stack[-1]]
                    need(current['receipt']==refs['receipt_owner']and current['preimage']==refs['preimage_owner']and current['preimage']is not None,'delivery preserves same two full owner references')
                if op in('RECONCILE_VERSION','RECONCILE_RESULT'):
                    need(refs['version_owner']is not None,'full post-mutation typed reconciliation version')
    need(not stack and len(completed)==len(entered),'all event occurrences closed')
    need(set(profiles)==set(profile_ids)and profiles==[row['id']for row in p['profile_accounting']],'all successful/failed profile attempts in original accounting order')
    expected_cases=p['inputs']['small_palettes']+[p['inputs']['large_palette']]+p['inputs']['graph_cases']
    need(len(cases)==15 and len(legacy)==33 and len(groups)==28 and len(variants)==55,'full declared occurrence populations')
    for(actual_id,value),expected in zip(cases,expected_cases):check();need(actual_id==expected['id'],'ordered case ID');value.matches(expected)
    for(actual_id,value),expected in zip(legacy,p['inputs']['diagnostics']):check();need(actual_id==expected['id'],'ordered legacy ID');value.matches(expected)
    for(actual_id,value),expected in zip(groups,p['batch_inputs']['groups']):check();need(actual_id==expected['id'],'ordered new group ID');value.matches(expected)
    position=0
    for group in p['batch_inputs']['groups']:
        for expected in group['variants']:
            check();gid,vid,value=variants[position];position+=1;need((gid,vid)==(group['id'],expected['id']),'ordered variant ID');value.matches(expected)
    for pid,expected in requests.items():
        actual=queries.get(pid,[]);need(len(actual)==len(expected),'every registered request occurrence preserved')
        for cursor,value in zip(actual,expected):check();cursor.matches(value)
    for row in p['profile_rows']:
        check();pid=row['id'];live=row['lifetime'];phase,final=normal_final[pid]
        final.field('lifetime').matches(live)
        if row['complete']:
            need(phase=='RETURN','complete normal profile exact return')
            actual=seen_produced.get(pid,[]);typed=seen_preimage.get(pid,[])
            need(len(actual)==len(typed)==len(live['receipts']),'all complete profile output occurrences')
            for ref,value in zip(actual,live['receipts']):check();owned(ref).matches(value)
            for ref,value in zip(typed,live['expected_receipts']):check();owned(ref).matches(value)
    for graph in p['graphs']:
        actual=observed.get(graph['id'],[]);expected=graph['observations'];need(len(actual)==len(expected),'every graph observation occurrence retained')
        for cursor,value in zip(actual,expected):check();cursor.matches(value['snapshot'])
    _equal(started,p['call_started'],check);_equal(returned,p['call_completed'],check);_equal(raised,p['call_raised'],check)
    return dict(owners=len(ownerrows),occurrences=events.length(),entries=len(entered),exits=len(completed),profiles=len(profiles),raw_runtime_identity_reconstructed=False)


def validate_document(document,*,expected,retain):
    state=dict(document=document,expected=expected,receipt=None,error=None)
    need(callable(retain)and retain(state)is None,'Root retains full schema before callback')
    w=document.work;check=w.step
    try:
        w.gate();need(type(expected)is dict and tuple(expected)==('packet','manifest','raw_banks','catalog','verify_raw_bank','verify_live_custody'),'exact actual comparison owners')
        c=document.cursor()
        _record(c,('schema','gate_contract','canonical_packet','manifest','raw_banks','catalog','columns','owners','events','sealing_tape','G1_adopted','runtime_qualified','mathematical_authority'))
        need(_scalar(c.field('schema'))=='immutable-whole-evidence-owners-v1'and _scalar(c.field('gate_contract'))=='PROPOSED_G1_IMMUTABLE_FULL_VALUES_ALL_OWNER_EVENT_TAPE_REFERENCES_V1','explicit unadopted new contract')
        for field in('G1_adopted','runtime_qualified','mathematical_authority'):need(_scalar(c.field(field))is False,'candidate only')
        # No eager native decoder. Each edge is traversed and every distinct
        # node/native-owner pair compared. Equal shared values share comparison,
        # while owner/event ordinals and all schema occurrence loops remain.
        for field,key in(('canonical_packet','packet'),('manifest','manifest'),('raw_banks','raw_banks'),('catalog','catalog')):
            check();c.field(field).matches(expected[key])
        c.field('columns').matches(dict(owners=OWNER_FIELDS,events=EVENT_FIELDS,profile_state=STATE_FIELDS,counters=COUNTER_FIELDS))
        tape=c.field('sealing_tape');need(tape.tag()==7 and tape.length()+1==len(document.roots),'complete construction root tape')
        for i in range(tape.length()):
            check();row=tape.index(i);need(row.tag()==7 and row.length()==3,'full ordered tape record')
            need(_scalar(row.index(0),int)==i+1 and type(_scalar(row.index(1)))is str and row.index(2).node==document.roots[i],'every root occurrence/order/value binding')
        m=expected['manifest'];_fields(m,('schema','invocation_id','plan','declaration','runtime_closure','source_pins','python','stdlib_pins','outer_limits','component_limits','profile_limits','profile_granularity','profile_query_chunk','predecessor_worker_sha256','terminal_policy','scope'))
        need(m['schema']=='immutable-whole-evidence-manifest-v1'and m['terminal_policy']=='CANDIDATE_ONLY_REQUIRES_ROOT_EXTERNAL_TERMINAL_ADMISSION','new full outer manifest contract')
        need(set(m['source_pins'])=={'worker','implicit','graph','selector','runner','observer','linked','schema','cursor','writer'},'all new exact Source roles')
        need((m['plan']['schema'],m['declaration']['schema'],m['runtime_closure']['schema'])==('ROOT-whole-owner-evidence-plan-v1','ROOT-whole-owner-evidence-declaration-v1','ROOT-whole-owner-evidence-runtime-closure-v1'),'new outer contracts cannot reuse retired grants')
        for actual in(m['plan']['sources'],m['runtime_closure']['sources']):_equal(m['source_pins'],actual,check)
        for actual in(m['plan']['python'],m['runtime_closure']['python']):_equal(m['python'],actual,check)
        for actual in(m['plan']['limits'],m['declaration']['limits']):_equal(m['outer_limits'],actual,check)
        _equal(m['component_limits'],m['declaration']['component_limits'],check);_equal(m['profile_limits'],m['declaration']['profile_limits'],check)
        need(m['invocation_id']==m['plan']['invocation_id']and m['profile_query_chunk']==128 and m['profile_granularity']=='PROFILE_ENTRY_EXIT_PLUS_LOCAL_QUERY_GUARDS_V1','exact scope/identity')
        need(m['predecessor_worker_sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03','exact original provenance')
        p=expected['packet'];banks=expected['raw_banks'];need(type(banks)is list and len(banks)==2,'both full raw banks')
        for i,bank in enumerate(banks):
            check();_fields(bank,('role','pin','raw_hex','decoded'));need(bank['role']==('original-bank','new-diagnostic-bank')[i],'ordered exact raw bank role')
            need(expected['verify_raw_bank'](bank)is None,'real full raw byte/hash/parser/decoded correspondence')
            _equal(bank['pin'],m['plan']['inputs'][i]['pin'],check);_equal(bank['pin'],m['declaration']['inputs'][i]['pin'],check)
        _equal(banks[0]['decoded'],p['inputs'],check);_equal(banks[1]['decoded'],p['batch_inputs'],check);_equal(banks[0]['pin'],p['batch_inputs']['original_bank'],check)
        runs=_packet_population(p,check);profile_ids,requests=_profiles(p,runs,check)
        _catalog(p,expected['catalog'],check)
        counts=_live(document,c,p,profile_ids,requests,check)
        need(expected['verify_live_custody']()is None,'real final Source/callable/raw owner custody callback')
        # Catch mutation of a native expected owner by ANY verification callback.
        for field,key in(('canonical_packet','packet'),('manifest','manifest'),('raw_banks','raw_banks'),('catalog','catalog')):
            c.field(field).matches(expected[key])
        receipt=dict(schema='immutable-whole-owner-schema-candidate-v1',version=VERSION,all24full_descendants_compared=True,
            normal_cases=15,legacy_diagnostics=33,new_groups=28,new_variants=55,event_counts=counts,
            complete_native_parent_expansions=0,G1_adopted=False,runtime_qualified=False,resource_accepted=False,mathematical_authority=False)
        state['receipt']=receipt;w.gate();return receipt
    except BaseException as error:state['error']=error;raise

# Complete independent native semantic rules (no new native decoding).
"""SOURCE ONLY full native semantic rules coupled to strict DAG correspondence.
No decoded full native object is constructed. These rules examine Root's already
owned read-only originals AFTER independent full cursor correspondence. Every
original population/profile/catalog constraint is retained independently of the
producer. Root actual source/argument custody remains necessary.
"""
def _require(ok,reason):
    if not ok:raise ValueError(reason)

def _fields(value, names):
    _require(type(value) is dict and tuple(value)==names, 'exact ordered record fields')

def _equal(a, b, check):
    """Full strict typed correspondence, no producer helper or hash shortcut."""
    pending=[(a,b,0)]
    while pending:
        left,right,depth=pending.pop();check()
        _require(depth<=256 and type(left) is type(right), 'strict type/depth correspondence')
        kind=type(left)
        if left is None:
            continue
        if kind is float:
            _require(left.hex()==right.hex() and left.hex() not in ('nan','inf','-inf'), 'finite float-hex correspondence')
        elif kind in (str,int,bool):
            _require(left==right, 'full scalar correspondence')
        elif kind in (list,tuple):
            _require(len(left)==len(right),'full sequence population')
            for i in range(len(left)-1,-1,-1):
                pending.append((left[i],right[i],depth+1))
        elif kind is dict:
            _require(len(left)==len(right),'full mapping population')
            lr=list(left.items());rr=list(right.items())
            for i in range(len(lr)-1,-1,-1):
                pending.append((lr[i][1],rr[i][1],depth+1))
                pending.append((lr[i][0],rr[i][0],depth+1))
        else:
            _require(False,'unsupported exact parent value type')

def _uint(x):
    _require(type(x) is int and x>=0,'exact nonnegative counter')
    return x

def _at(root, path):
    _require(type(path) is tuple and path,'nonempty exact binding path')
    current=root
    for part in path:
        if type(current) is dict:
            _require(type(part) is str and part in current,'mapping path exists')
        else:
            _require(type(current) in (list,tuple) and type(part) is int and 0<=part<len(current),'sequence path exists')
        current=current[part]
    return current

def _catalog(packet, bindings, check):
    """Independent imperative expected path/role population; no producer call."""
    position=0
    def expect(path,role,case=None,profile=None,group=None,variant=None,run=None):
        nonlocal position
        check();_require(position<len(bindings),'missing required binding')
        row=bindings[position];position+=1
        _fields(row,('ordinal','path','role','case','profile','group','variant','run'))
        _equal((row['ordinal'],row['path'],row['role'],row['case'],row['profile'],row['group'],row['variant'],row['run']),
               (position,path,role,case,profile,group,variant,run),check)
        _at(packet,path)
    for field in ('schema','status','inputs','small_palettes','large_palette','graphs','diagnostics',
                  'call_receipts','call_started','call_completed','call_raised','root_callbacks','batch_inputs',
                  'profile_rows','profile_metrics','profile_accounting','batch_diagnostics','batch_diagnostic_progress',
                  'full_VM_implemented','full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified',
                  'mathematical_authority','scope'):
        expect((field,),'predecessor-topfield')
    for i in range(len(packet['small_palettes'])):
        case=packet['small_palettes'][i];cid=case['id'];path=('small_palettes',i)
        expect(path,'normal-small',cid)
        for field in ('input','legacy_palette','semantic_tiles'):
            expect(path+(field,),'independent-'+field,cid)
        for j in range(len(case['queries'])):
            expect(path+('queries',j),'small-query-group',cid)
    cid=packet['large_palette']['id']
    expect(('large_palette',),'normal-large',cid)
    expect(('large_palette','legacy_cardinality'),'independent-cardinality',cid)
    for field in ('global_rank_samples','focused_families'):
        for i in range(len(packet['large_palette'][field])):
            expect(('large_palette',field,i),'large-'+field,cid)
    for i in range(len(packet['graphs'])):
        case=packet['graphs'][i];cid=case['id'];path=('graphs',i)
        expect(path,'normal-graph',cid)
        for field in ('input','instance','legacy_problem','independent_solution_ids'):
            expect(path+(field,),'independent-'+field,cid)
        for j in range(len(case['observations'])):
            expect(path+('observations',j),'graph-observation',cid)
            expect(path+('observations',j,'independent_domains'),'independent-domains',cid)
        for field in ('journal','query_journal','solutions'):
            for j in range(len(case['result'][field])):
                expect(path+('result',field,j),'graph-'+field,cid)
    for i in range(len(packet['diagnostics'])):
        expect(('diagnostics',i),'legacy-diagnostic',packet['diagnostics'][i]['id'])
    for i in range(len(packet['call_receipts'])):
        expect(('call_receipts',i),'standalone-call-receipt')
    for i in range(len(packet['profile_rows'])):
        expect(('profile_rows',i),'wrapper-profile',profile=packet['profile_rows'][i]['id'])
    for i in range(len(packet['profile_accounting'])):
        expect(('profile_accounting',i),'profile-accounting',profile=packet['profile_accounting'][i]['id'])
    for i in range(len(packet['batch_diagnostics'])):
        group=packet['batch_diagnostics'][i];gid=group['id'];path=('batch_diagnostics',i)
        expect(path,'new-diagnostic-group',group=gid)
        for j in range(len(group['variants'])):
            variant=group['variants'][j];vid=variant['id'];vpath=path+('variants',j)
            expect(vpath,'new-diagnostic-variant',group=gid,variant=vid)
            runs=variant.get('runs',[])
            for k in range(len(runs)):
                profile=vid+':baseline' if k==0 and group['recipe'] in ('work-cumulative','receipt-items-cumulative') else vid
                expect(vpath+('runs',k),'new-diagnostic-profile',profile=profile,group=gid,variant=vid,run=k)
    expect(('batch_diagnostic_progress',),'complete-progress-view')
    _require(position==len(bindings),'extra/unowned binding')

def _packet_population(p, check):
    _fields(p,('schema','status','inputs','small_palettes','large_palette','graphs','diagnostics','call_receipts',
        'call_started','call_completed','call_raised','root_callbacks','batch_inputs','profile_rows','profile_metrics',
        'profile_accounting','batch_diagnostics','batch_diagnostic_progress','full_VM_implemented',
        'full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified','mathematical_authority','scope'))
    _require(p['schema']=='implicit-palette-graph-calibration-packet-v1' and
        p['status']=='COMPLETE_COMPONENT_CALIBRATION_CANDIDATE','predecessor candidate identity')
    for key in ('full_VM_implemented','full_FOL_palette_qualified','proof_discovery','full_pipeline_qualified','mathematical_authority'):
        _require(p[key] is False,'no broader claim')
    original=p['inputs'];batch=p['batch_inputs']
    _require(original['schema']=='implicit-palette-inputs-v1' and
        batch['schema']=='implicit-batch-summary-diagnostics-v1','whole unchanged bank schemas')
    _require(len(original['small_palettes'])==len(p['small_palettes'])==4 and
        len(original['graph_cases'])==len(p['graphs'])==10 and
        len(original['diagnostics'])==len(p['diagnostics'])==33,'entire15normal33legacy population')
    for i,case in enumerate(p['small_palettes']):
        _fields(case,('id','complete','input','descriptor','build','description','legacy_palette','semantic_tiles',
            'queries','nonempty_mask_queries','zero_mask_queries','selected_witnesses','full_literal_tile_count','scope'))
        _require(case['id']==original['small_palettes'][i]['id'] and case['complete'] is True,'small ordered case')
        _equal(case['input'],original['small_palettes'][i],check)
        _require(type(case['queries']) is list and type(case['semantic_tiles']) is list,'whole small literal arrays')
        _require(case['full_literal_tile_count']==len(case['semantic_tiles']) and
            case['selected_witnesses']==16*len(case['semantic_tiles']),'full small witness multiplicity')
        witnesses=0
        for j,query in enumerate(case['queries']):
            check();_fields(query,('index','mask','count','count_attempted_work','select_attempted_work','selected_tiles','complete'))
            _require(query['index']==j and query['complete'] is True and type(query['mask']) is tuple,'ordered full mask/rank group')
            _require(_uint(query['count'])==len(query['selected_tiles'])==len(query['select_attempted_work']),'all rank occurrences')
            witnesses+=query['count']
        _require(witnesses==case['selected_witnesses'],'witness conservation')
        _require(case['nonempty_mask_queries']==sum(row['count']!=0 for row in case['queries']) and
            case['zero_mask_queries']==sum(row['count']==0 for row in case['queries']),'mask populations')
    large=p['large_palette']
    _fields(large,('id','complete','input','descriptor','build','description','legacy_cardinality','total_count',
        'global_rank_samples','focused_families','fully_materialized','full_large_unranking_exhausted','scope'))
    _equal(large['input'],original['large_palette'],check)
    _require(large['id']==original['large_palette']['id'] and large['complete'] is True and
        large['fully_materialized'] is False and large['full_large_unranking_exhausted'] is False,'large scope unchanged')
    _require(len(large['global_rank_samples'])==3 and len(large['focused_families'])==19,'whole large bounded sequence')
    for i,case in enumerate(p['graphs']):
        check();_fields(case,('id','complete','input','instance','legacy_problem','result','observations',
            'independent_solution_ids','independent_solution_count','actual_solution_count','domain_checks','scope'))
        _equal(case['input'],original['graph_cases'][i],check)
        _require(case['id']==original['graph_cases'][i]['id'] and case['complete'] is True,'ordered graph population')
        result=case['result']
        _require(result['root_restored'] is True and result['final_observation_completed'] is True and
            result['status']!='UNKNOWN_SEARCH_LIMIT','normal graph complete/restored')
        _require(case['independent_solution_count']==len(case['independent_solution_ids']) and
            case['actual_solution_count']==len(result['solutions']),'whole independent solution populations')
        for observation in case['observations']:
            _fields(observation,('snapshot','independent_domains','complete'))
            _require(observation['complete'] is True,'full graph observation')
            snap=observation['snapshot']
            _require(type(snap) is dict and set(snap)=={'schema','reason','mode','palette_descriptor','points','chosen','marks',
                'domains','exclusions','dependencies','branch_stack','scheduler','rollback_parent','work'},'full14snapshot fields')
    for i,row in enumerate(p['diagnostics']):
        declaration=original['diagnostics'][i]
        _require(row['id']==declaration['id'] and row['operation']==declaration['operation'] and
            row['role']==declaration['role'] and row['expected']==declaration['expected'] and row['status']=='PASSED',
            'unchanged legacy diagnostic row')
    _require(type(batch['groups']) is list and len(batch['groups'])==len(p['batch_diagnostics'])==28,'whole28newgroups')
    variant_count=0;run_count=0;run_ids=[]
    for i,group in enumerate(p['batch_diagnostics']):
        declared=batch['groups'][i]
        _fields(group,('id','subject','recipe','status','complete','variants'))
        _require((group['id'],group['subject'],group['recipe'])==(declared['id'],declared['subject'],declared['recipe']) and
            group['status']=='PASSED' and group['complete'] is True,'ordered unchanged diagnostic group')
        _require(len(group['variants'])==len(declared['variants']),'all declared variants')
        for j,variant in enumerate(group['variants']):
            check();declaration=declared['variants'][j];variant_count+=1
            _require(variant['id']==declaration['id'] and variant['status']=='PASSED' and variant['complete'] is True,'ordered variant')
            _equal(variant['expected'],declaration['expected'],check)
            if group['subject']=='scalar-summary-builder':
                _fields(variant,('id','status','complete','expected','record','writer_invoked','filesystem_persistence_tested'))
                _require(variant['writer_invoked'] is False and variant['filesystem_persistence_tested'] is False,'pure scalar scope')
                continue
            _fields(variant,('id','status','complete','expected','runs','real_root_fault_gate_passed','inherited_outer_gates_unchanged'))
            _require(variant['real_root_fault_gate_passed'] is True and variant['inherited_outer_gates_unchanged'] is True,'genuine fault gates')
            count=2 if group['recipe'] in ('work-cumulative','receipt-items-cumulative') else 1
            _require(len(variant['runs'])==count,'all baseline and main runs')
            for k,run in enumerate(variant['runs']):
                _fields(run,('profile_admitted','custody_success','planned_trigger_fired','exact_primary_identity','thrown',
                    'events','checkpoint_after_first','reference_receipts','callback_references','work_object_scalars',
                    'produced_receipt_count','preimage_completed_count','delivered_receipt_count','ordinary_lifetime_projection',
                    'ordinary_prefix_projection','result','callbacks_and_nonliteral_owners_retained','nonliteral_projection_scope'))
                _require(run['callbacks_and_nonliteral_owners_retained'] is True,'runtime owners not replayed')
                run_ids.append(variant['id']+':baseline' if count==2 and k==0 else variant['id']);run_count+=1
    _require(variant_count==55 and run_count==49,'complete55variant49profile population')
    progress=p['batch_diagnostic_progress']
    _fields(progress,('stage','active_group','active_variant','completed_group_ids','groups'))
    _require(progress['stage']=='COMPLETE' and progress['active_group'] is None and progress['active_variant'] is None,'no open diagnostic view')
    _equal(progress['completed_group_ids'],[g['id'] for g in p['batch_diagnostics']],check)
    _require(len(progress['groups'])==28,'complete final progress owners')
    for a,b in zip(progress['groups'],p['batch_diagnostics']):
        _fields(a,('id','subject','recipe','stage','variants','active_runs'))
        _require((a['id'],a['subject'],a['recipe'])==(b['id'],b['subject'],b['recipe']) and
            a['stage']=='COMPLETE' and a['active_runs']==[],'closed progress view')
        _equal(a['variants'],b['variants'],check)
    return run_ids

def _profiles(p, run_ids, check):
    wrapper_ids=[];profile_requests={}
    for row in p['profile_rows']:
        check();_require(type(row) is dict and type(row['id']) is str and type(row['complete']) is bool,'profile identity')
        _require(row['id'] not in wrapper_ids,'distinct profile occurrence identity');wrapper_ids.append(row['id'])
        live=row['lifetime']
        if live is not None:
            _fields(live,('schema','descriptor','limits','active','busy','active_query','attempted_queries',
                'produced_receipt_count','preimage_completed_count','delivered_receipt_count','receipts','requests',
                'expected_receipts','query_work','receipt_items','preparation_work','stage','failed_stage',
                'custody_entry_attempted','custody_entry_completed','custody_exit_attempted','custody_exit_completed',
                'custody_cleanup_error','registered','authority','attempted_work','data_items','query_fault','body_result'))
            profile_requests[row['id']]=live['requests']
        if not row['complete']:
            _fields(row,('id','complete','prefix','lifetime'));continue
        _fields(row,('id','complete','lifetime','profile_return_metadata','profile_return_bindings','reconstruction_scope',
                     'expanded_reconstruction_charge_bytes'))
        _require(live is not None and live['active'] is False and live['busy'] is False and
            live['active_query'] is None and live['body_result'] is None,'closed normal lifetime')
        n=_uint(live['attempted_queries'])
        _require(n==live['produced_receipt_count']==live['preimage_completed_count']==live['delivered_receipt_count']==
            len(live['requests'])==len(live['receipts'])==len(live['expected_receipts']),'normal lifecycle conservation')
        _equal(row['profile_return_bindings'],dict(receipts=dict(field='receipts',container='list'),
            attempted_requests=dict(field='requests',container='tuple'),
            exact_receipt_preimages=dict(field='expected_receipts',container='tuple'),
            body_result=dict(field='body_result',container='identity')),check)
        metadata=row['profile_return_metadata']
        _require(not any(k in metadata for k in ('receipts','attempted_requests','exact_receipt_preimages','body_result')),
                 'all four explicit returns exclusively bound')
        for key in ('attempted_queries','produced_receipt_count','preimage_completed_count','delivered_receipt_count'):
            _equal(metadata[key],live[key],check)
        _require(metadata['profile_closed'] is True and metadata['custody_entry_completed'] is True and
            metadata['custody_exit_completed'] is True,'full returned metadata closure')
        _uint(row['expanded_reconstruction_charge_bytes'])
    for group in p['batch_diagnostics']:
        for variant in group['variants']:
            runs=variant.get('runs',[])
            for k,run in enumerate(runs):
                pid=variant['id']+':baseline' if len(runs)==2 and k==0 else variant['id']
                live=run['ordinary_lifetime_projection']
                if live is not None:
                    def request_value(x):
                        check()
                        if type(x) is dict:
                            _fields(x,('literal_type','items'))
                            _require(x['literal_type']=='tuple','only tuple markers in request carriers')
                            items=[]
                            for y in x['items']:items.append(request_value(y))
                            return tuple(items)
                        if type(x) is list:return [request_value(y) for y in x]
                        _require(x is None or type(x) in (str,int,bool),'strict projected request scalar')
                        return x
                    profile_requests[pid]=request_value(live['requests'])
    ids=wrapper_ids+run_ids
    _require(len(ids)==len(set(ids)),'all attempted profile IDs globally distinct')
    accounting=p['profile_accounting']
    _require(len(accounting)==len(ids) and set(row['id'] for row in accounting)==set(ids),'one full accounting row per profile')
    metrics=p['profile_metrics']
    _fields(metrics,('profile_count','profile_attempted_work','profile_preparation_work','profile_query_kernel_work',
        'profile_overhead_work','profile_postpreparation_overhead_work','produced_receipt_count','preimage_completed_count',
        'delivered_receipt_count','attempted_queries','palette_attempted_work_known_total','palette_work_unavailable_count'))
    complete=[]
    for row in accounting:
        _fields(row,('id','attempted_work','preparation_work','query_kernel_work','overhead_work',
            'postpreparation_overhead_work','private_work_available','complete','attempted_queries',
            'produced_receipt_count','preimage_completed_count','delivered_receipt_count'))
        _require(type(row['complete']) is bool and row['private_work_available'] is (row['attempted_work'] is not None),'cost availability')
        for key,value in row.items():
            if key not in ('id','private_work_available','complete') and value is not None:
                _uint(value)
        a,k,h,prep,post=(row[n] for n in ('attempted_work','query_kernel_work','overhead_work','preparation_work','postpreparation_overhead_work'))
        if a is not None and k is not None:
            _require(h==a-k,'whole cumulative cost exactly once')
        if h is not None and prep is not None:
            _require(post==h-prep,'preparation/overhead separation')
        if row['complete']:
            _require(row['attempted_queries']==row['produced_receipt_count']==row['preimage_completed_count']==row['delivered_receipt_count'],
                     'successful accounting counters only');complete.append(row)
    sums=(('profile_attempted_work','attempted_work'),('profile_preparation_work','preparation_work'),
        ('profile_query_kernel_work','query_kernel_work'),('profile_overhead_work','overhead_work'),
        ('profile_postpreparation_overhead_work','postpreparation_overhead_work'),
        ('produced_receipt_count','produced_receipt_count'),('preimage_completed_count','preimage_completed_count'),
        ('delivered_receipt_count','delivered_receipt_count'),('attempted_queries','attempted_queries'))
    _require(metrics['profile_count']==len(complete),'complete profile portion only')
    for metric,key in sums:
        _require(metrics[metric]==sum(row[key] for row in complete if row[key] is not None),'metric sum conservation')
    _uint(metrics['palette_attempted_work_known_total']);_uint(metrics['palette_work_unavailable_count'])
    return ids,profile_requests

