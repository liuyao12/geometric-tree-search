"""SOURCE ONLY complete producer catalog; independent checker reconstructs roles.
"""
TOP_FIELDS = ('schema','status','inputs','small_palettes','large_palette','graphs',
    'diagnostics','call_receipts','call_started','call_completed','call_raised',
    'root_callbacks','batch_inputs','profile_rows','profile_metrics',
    'profile_accounting','batch_diagnostics','batch_diagnostic_progress',
    'full_VM_implemented','full_FOL_palette_qualified','proof_discovery',
    'full_pipeline_qualified','mathematical_authority','scope')

def build_catalog(packet, check):
    """Producer catalog. Decoder builds/checks its own catalog independently.

    A subtree binding owns ALL descendants with original type/order, including
    dynamic map keys. It is not a summary or a promise to regenerate a value.
    """
    rows = []
    def add(path, role, case=None, profile=None, group=None, variant=None, run=None):
        check()
        rows.append(dict(ordinal=len(rows)+1,path=path,role=role,case=case,
                         profile=profile,group=group,variant=variant,run=run))
    for key in TOP_FIELDS:
        add((key,), 'predecessor-topfield')
    for i, case in enumerate(packet['small_palettes']):
        path=('small_palettes',i); cid=case['id']
        add(path,'normal-small',cid)
        for key in ('input','legacy_palette','semantic_tiles'):
            add(path+(key,), 'independent-'+key,cid)
        for j, unused in enumerate(case['queries']):
            add(path+('queries',j),'small-query-group',cid)
    add(('large_palette',),'normal-large',packet['large_palette']['id'])
    add(('large_palette','legacy_cardinality'),'independent-cardinality',packet['large_palette']['id'])
    for key in ('global_rank_samples','focused_families'):
        for i, unused in enumerate(packet['large_palette'][key]):
            add(('large_palette',key,i),'large-'+key,packet['large_palette']['id'])
    for i, case in enumerate(packet['graphs']):
        path=('graphs',i); cid=case['id']
        add(path,'normal-graph',cid)
        for key in ('input','instance','legacy_problem','independent_solution_ids'):
            add(path+(key,),'independent-'+key,cid)
        for j, unused in enumerate(case['observations']):
            add(path+('observations',j),'graph-observation',cid)
            add(path+('observations',j,'independent_domains'),'independent-domains',cid)
        for key in ('journal','query_journal','solutions'):
            for j, unused in enumerate(case['result'][key]):
                add(path+('result',key,j),'graph-'+key,cid)
    for i, row in enumerate(packet['diagnostics']):
        add(('diagnostics',i),'legacy-diagnostic',row['id'])
    for i, row in enumerate(packet['call_receipts']):
        add(('call_receipts',i),'standalone-call-receipt')
    for i, row in enumerate(packet['profile_rows']):
        add(('profile_rows',i),'wrapper-profile',profile=row['id'])
    for i, row in enumerate(packet['profile_accounting']):
        add(('profile_accounting',i),'profile-accounting',profile=row['id'])
    for i, group in enumerate(packet['batch_diagnostics']):
        path=('batch_diagnostics',i); gid=group['id']
        add(path,'new-diagnostic-group',group=gid)
        for j, variant in enumerate(group['variants']):
            vpath=path+('variants',j); vid=variant['id']
            add(vpath,'new-diagnostic-variant',group=gid,variant=vid)
            for k, unused in enumerate(variant.get('runs',[])):
                pid=vid+':baseline' if k==0 and group['recipe'] in ('work-cumulative','receipt-items-cumulative') else vid
                add(vpath+('runs',k),'new-diagnostic-profile',profile=pid,group=gid,variant=vid,run=k)
    add(('batch_diagnostic_progress',),'complete-progress-view')
    return rows
