# SOURCE ONLY complete original cohort integration; historical main refuses.
class _OwnerEvidence:
    """Explicit compatibility boundary: native values sealed once, event refs repeat.
    It does not answer queries or reconstruct executable identity.
    """
    def __init__(self,s,store):self.s=s;self.store=store;self.owner_runtime=[]
    def current_scope(self,scope=None):return self.store.scope(_evidence_scope(self.s)if scope is None else scope)
    def enter(self,kind,role,operation,arguments,scope=None):
        raw=(arguments,scope);self.owner_runtime.append(raw)
        sc=self.current_scope(scope);owner=self.store.owner(arguments,role='arguments-before',scope=sc,version=0,route=role+'.'+operation)
        return self.store.enter(kind,role,operation,sc,args_owner=owner)
    def leave(self,token,*,arguments=None,value=None,error=None):
        self.owner_runtime.append((arguments,value,error))
        kind,role,operation,sc,version=self.store.pending[token]
        args=self.store.owner(arguments,role='arguments-after',scope=sc,version=1,route=role+'.'+operation)
        val=None if error is not None and value is None else self.store.owner(value,role='result',scope=sc,version=1,route=role+'.'+operation)
        return self.store.leave(token,args_owner=args,value_owner=val,error=error)
    def snapshot(self,kind,role,operation,value,scope=None):
        self.owner_runtime.append((value,scope));sc=self.current_scope(scope)
        owner=self.store.owner(value,role='snapshot',scope=sc,route=role+'.'+operation)
        return self.store.snapshot(kind,role,operation,sc,owner)


def _evidence_scope(s):
    scope=dict(s.evidence_scope);context=s.profile_query_context
    if type(context)is dict:scope['profile_id']=context['id']
    return scope


def _evidence_invoke(s,kind,role,operation,args,action,after=None,case_id=None):
    previous=dict(s.evidence_scope)
    if case_id is not None:s.evidence_scope['case_id']=case_id
    s.evidence_runtime_owners.append((action,args,after));action_seal=function_owner_seal(action)
    token=s.policy(lambda:s.evidence.enter(kind,role,operation,args))
    try:value=action()
    except BaseException as error:
        s.evidence_runtime_owners.append(error)
        try:
            final_args=args if after is None else after()
            s.policy(lambda:s.evidence.leave(token,arguments=final_args,error=error))
            s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after fault'))
        except BaseException as secondary:
            s.evidence_runtime_owners.append(secondary)
            if s.first_fault is None:s.first_fault=secondary
        s.fault_gate();raise
    else:
        final_args=args if after is None else after()
        s.policy(lambda:s.evidence.leave(token,arguments=final_args,value=value))
        s.policy(lambda:need(function_owner_seal(action)==action_seal,'live action callable custody after return'))
        return value
    finally:s.evidence_scope=previous


def _profile_evidence(s,profile_id,origin,declared_arguments=None):
    scope=_evidence_scope(s);scope.update(profile_id=profile_id,origin=origin)
    tokens=[];queries=[];produced=[];preimages=[];registered=[]
    callback_owners=[scope,tokens,declared_arguments,queries,produced,preimages,registered]
    s.evidence_runtime_owners.append(callback_owners)
    def hook(stage,state,request,value,error):
        # Full ACTUAL state/receipt/preimage/Work/error owners are retained before
        # the first new sealing checkpoint. Serialized IDs never recreate them.
        callback_owners.append((state,request,value,error))
        def action():
            store=s.evidence.store;sc=store.scope(scope);work=state['work']
            counters=dict(stage=state['stage'],failed_stage=state['failed_stage'],attempted_queries=state['attempted_queries'],
                produced_receipt_count=state['produced_receipt_count'],preimage_completed_count=state['preimage_completed_count'],
                delivered_receipt_count=state['delivered_receipt_count'],attempted_work=None if work is None else work.work,
                data_items=None if work is None else work.items)
            if stage in('PROFILE_ENTER','QUERY_ENTER','CUSTODY_ENTER'):
                kind=stage[:-6];argument=declared_arguments if kind=='PROFILE'else request if kind=='QUERY'else value
                owner=store.owner(argument,role='arguments-before',scope=sc,version=0,route='implicit.'+kind.lower())
                token=store.enter(kind,'implicit',kind.lower(),sc,args_owner=owner);tokens.append((kind,token,owner))
                if kind=='QUERY':queries.append(dict(request=owner,receipt=None,preimage=None,registered=False))
            elif stage in('PROFILE_RETURN','PROFILE_RAISE','QUERY_RETURN','QUERY_RAISE','CUSTODY_RETURN','CUSTODY_RAISE'):
                kind=stage.rsplit('_',1)[0];need(tokens and tokens[-1][0]==kind,'exact component event nesting')
                unused,token,args=tokens[-1]
                if kind=='QUERY':
                    current=queries[-1];returned=current['receipt']
                    # A failed query still retains its exact active raw lifetime
                    # in the final failed profile view and all original owners.
                    if error is not None:
                        returned=store.owner(dict(active_query=state['active_query'],counters=counters),role='failed-query-lifetime',scope=sc,version=1,route='implicit.query')
                    store.leave(token,args_owner=args,value_owner=returned,error=error);queries.pop()
                elif kind=='PROFILE':
                    ordinary=_ordinary_profile_lifetime(state)
                    # Exactly one complete end-of-profile value capture. It is
                    # never copied into each QUERY event or reconciliation row.
                    final=dict(result=value,lifetime=ordinary)
                    owner=store.owner(final,role='profile-final-lifetime',scope=sc,version=1,route='implicit.with_profile')
                    store.leave(token,args_owner=args,value_owner=owner,error=error)
                else:
                    owner=store.owner(value,role='custody-result',scope=sc,version=1,route='implicit.custody')
                    store.leave(token,args_owner=args,value_owner=owner,error=error)
                tokens.pop()
            else:
                current=queries[-1]if queries else None
                if stage=='QUERY_REGISTERED':
                    need(current is not None,'registered query occurrence');current['registered']=True;registered.append(current['request'])
                elif stage=='QUERY_PRODUCED':
                    need(current is not None and current['receipt']is None,'one raw production per query')
                    current['receipt']=store.owner(value,role='raw-produced-receipt',scope=sc,version=state['attempted_queries'],route='implicit.query')
                    produced.append(current['receipt'])
                elif stage=='QUERY_PREIMAGE':
                    need(current is not None and current['preimage']is None,'one immutable preimage per query')
                    current['preimage']=store.owner(value,role='completed-typed-preimage',scope=sc,version=state['attempted_queries'],route='implicit.query')
                    preimages.append(current['preimage'])
                version=None
                if stage in('RECONCILE_VERSION','RECONCILE_RESULT'):
                    # Complete original typed before/after values, including
                    # negative changed values; no summary/digest stand-in.
                    version=store.owner(value,role='reconciliation-version',scope=sc,version=state['attempted_queries'],route='implicit.reconcile')
                payload=dict(stage=stage,request_owner=None if current is None else current['request'],
                    receipt_owner=None if current is None else current['receipt'],preimage_owner=None if current is None else current['preimage'],
                    version_owner=version,counters=counters)
                payload=tuple(payload[key]if key!='counters'else tuple(counters.values())for key in payload)
                owner=store.owner(payload,role='profile-state-reference',scope=sc,version=state['attempted_queries'],route='implicit.'+stage)
                store.snapshot('PROFILE_STATE','implicit',stage,sc,owner,version=state['attempted_queries'])
            return None
        return s.policy(action)
    callback_owners.append(hook)
    if not hasattr(s,'evidence_callback_seals'):s.evidence_callback_seals=[]
    s.evidence_callback_seals.append((hook,function_owner_seal(hook)));return hook


def _linked_raw_bank_verifier(s,bank):
    s.guard();raw=checked(bank['pin'],134217728)
    need(type(bank['raw_hex'])is str and raw.hex()==bank['raw_hex'],'full unchanged raw bank bytes')
    decoded=json.loads(raw)
    s.policy(lambda:need(argument_bytes(decoded)==argument_bytes(bank['decoded']),'independent full raw parser and strict bank join'))
    return None


def _linked_final_custody(s):
    final_profile_custody(s)
    for callback,seal in s.evidence_callback_seals:
        s.check();s.policy(lambda callback=callback,seal=seal:need(function_owner_seal(callback)==seal,'all original evidence callback owners through final custody'))
    for role in('linked','schema','cursor','writer'):need(role in s.modules,'complete new Source closure')
    s.guard();s.fault_gate();return None


def run_owner_candidate(s,inputs,batch_inputs,raw_banks,manifest,*,store_limits,writer,physical_limit,expanded_limit):
    """Full15/33+28/55 candidate only; Root outer once/admission remains separate."""
    need(s.evidence is None and not s.rows and not s.profile_rows and not s.batch_diagnostics,'fresh whole ordinary invocation')
    need(type(physical_limit)is int and 0<physical_limit<=134217728 and type(expanded_limit)is int and 0<expanded_limit<=134217728,'unchanged128MiB ceilings')
    need(manifest['outer_limits']==OUTER_LIMITS and manifest['component_limits']==COMPONENT_LIMITS and manifest['profile_limits']==PROFILE_LIMITS and manifest['profile_query_chunk']==128 and manifest['profile_granularity']==PROFILE_GRANULARITY,'unchanged complete limits and scopes')
    need(manifest['source_pins']==s.plan['sources']and manifest['predecessor_worker_sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03','new full Source closure/provenance')
    need(type(raw_banks)is list and len(raw_banks)==2 and argument_bytes(raw_banks[0]['decoded'])==argument_bytes(inputs)and argument_bytes(raw_banks[1]['decoded'])==argument_bytes(batch_inputs),'both full unchanged bank arguments')
    def retain(owner):s.evidence_runtime_owners.append(owner);return None
    linked=s.modules['linked'];cursor=s.modules['cursor'];schema=s.modules['schema']
    store=linked.Store(check=s.check,limits=store_limits,retain=retain)
    s.evidence=_OwnerEvidence(s,store)
    s.evidence_runtime_owners.extend((store,s.evidence,writer,retain,manifest,raw_banks,store_limits))
    for bank in raw_banks:_linked_raw_bank_verifier(s,bank)
    s.batch_original_inputs=inputs;s.batch_original_inputs_preimage=argument_bytes(inputs)
    packet=qualify(s,inputs,batch_inputs);_linked_final_custody(s)
    # Complete native packet retained; no eager clone/JSON/tree expansion here.
    catalog=linked.build_catalog(packet,store.work.step)
    store.close(packet=packet,manifest=manifest,raw_banks=raw_banks,catalog=catalog)
    def verify_bank(bank):return _linked_raw_bank_verifier(s,bank)
    def verify_custody():return _linked_final_custody(s)
    expected=dict(packet=packet,manifest=manifest,raw_banks=raw_banks,catalog=catalog,verify_raw_bank=verify_bank,verify_live_custody=verify_custody)
    state=dict(packet=packet,catalog=catalog,store=store,expected=expected,receipt=None,validation=None,document=None,wire=None,position=0,producer_calls=0,writer_result=None,error=None)
    s.evidence_runtime_owners.extend((state,verify_bank,verify_custody))
    def producer():
        # Writer must claim BOTH physical/logical aggregate leases before this
        # first full canonicalization/parser operation. No hidden warm store.
        s.check();state['producer_calls']+=1
        if state['wire']is None:
            state['receipt']=store.encode();state['wire']=state['receipt']['wire']
            document=cursor.parse(state['wire'],work=store.work,retain=retain);state['document']=document
            state['validation']=schema.validate_document(document,expected=expected,retain=retain)
            _linked_final_custody(s)
        wire=state['wire'];position=state['position']
        if position==len(wire):return None
        stop=min(position+65536,len(wire));chunk=wire[position:stop];state['position']=stop
        return(chunk,len(chunk))  # EXPLICIT changed/unadopted G1 unique wire charge.
    s.evidence_runtime_owners.append(producer)
    try:
        output=writer.write_record('canonical-complete-owner-evidence.gctsowners',producer,physical_limit=physical_limit,expanded_limit=expanded_limit,kind='bulk')
        state['writer_result']=output
        need(state['validation']is not None and state['position']==len(state['wire']),'whole complete evidence, never partial admission')
        _linked_final_custody(s);s.check()
        metadata={key:value for key,value in state['receipt'].items()if key!='wire'}
        return dict(schema='immutable-whole-owner-worker-candidate-v1',output=output,candidate_metadata=metadata,validation=state['validation'],store_final_metrics=store.work.metrics(),
            normal_cases=15,legacy_diagnostics=33,new_groups=28,new_variants=55,profile_metrics=profile_metrics(s),root_callbacks_at_return=s.root_calls,
            root_callbacks_in_packet_are_preencoding_cutoff=True,full_pipeline_qualified=False,G1_adopted=False,resource_accepted=False,runtime_qualified=False,mathematical_authority=False)
    except BaseException as error:
        state['error']=error;s.evidence_runtime_owners.append(error);s.fault_gate();raise


def main(plan_path):
    raise PolicyFailure('All historical grants retired; this complete proposed owner successor needs new Root outer integration, independent full review and a fresh once grant.')

if __name__=='__main__':raise SystemExit(main(None))
