"""Passive frozen Source custody only. No research module imported or called."""
import hashlib
import json
from pathlib import Path
R=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs')
N=R/'gcts-initialized-bridge-20261020';B=R/'gcts-whole-linkage-20261020/schema-B'
O=N/'review-C';C=O/'selected-owner-Sources-v1';C.mkdir(parents=True,exist_ok=True)
checks=[];copies=[]
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def need(name,value):
    checks.append(dict(check=name,passed=bool(value)))
    if not value:raise ValueError(name)
h=B/'handoff-v1.json';row=pin(h)
need('Exact handoff',row['sha256']=='07386c55a88d2031e5ae92e21104289105c7185bbec63b369448173c6401f250' and row['bytes']==15266)
handoff=json.loads(h.read_bytes());rows=handoff['author_snapshot']+handoff['dependencies']+handoff['independent_specific_reviews']
seen=set()
for i,row in enumerate(rows):
    p=Path(row['path']);need('No partial content '+p.name,'.partial'not in p.name)
    actual=pin(p);need('Exact pin '+p.name,actual==row)
    if str(p)in seen:continue
    seen.add(str(p))
    if p.is_relative_to(B):dest=C/'author'/p.relative_to(B)
    else:dest=C/'dependencies'/(str(i)+'-'+p.name)
    dest.parent.mkdir(parents=True,exist_ok=True);need('Fresh copy '+str(dest),not dest.exists())
    dest.write_bytes(p.read_bytes());copies.append(dict(original=row,retained=pin(dest)))
dest=C/'handoff-v1.json';need('Fresh handoff copy',not dest.exists());dest.write_bytes(h.read_bytes())
out=dict(schema='independent-selected-owner-Source-custody-v1',reviewer_identity='/root/recovered_batch_review',
    handoff=pin(dest),copies=copies,checks=checks,failed_checks=[],source_only=True,
    full_offer_review_completed=False,subject_imports=0,subject_calls=0,helper_calls=0,
    checker_calls=0,compiler_calls=0,fixture_calls=0,simulator_calls=0,generator_calls=0,
    sizing_probes=0,semantic_replays=0,partial_files_opened=0,new_actuals=0,new_grants=0,
    G1_adopted=False,actual_execution_authorized=False,author=pin(Path(__file__)))
p=O/'selected-owner-Source-custody-v1.json';need('Fresh custody receipt',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(receipt=pin(p),checks=len(checks)),sort_keys=True))
