"""Independent missing-join Source negative; no certificate is constructed."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-initialized-bridge-20261020')
O=N/'review-C';C=O/'selected-owner-Sources-v1'
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
p=C/'author/schema-v3/validate_owner_parent_v3.py';source=p.read_text()
assert pin(p)['sha256']=='923230b512dabb3eb57127e42d06cff88106887921fd598a0226ff2ad69b1701'
t=ast.parse(source);compile(t,str(p),'exec')
live=next(x for x in t.body if isinstance(x,ast.FunctionDef)and x.name=='_live')
body=ast.get_source_segment(source,live)
assert "reconciled[(pid,position)]=(revision.index(1),revision.index(2))" in body
assert "need(_scalar(revision.index(1),bool)==left.same(right)" in body
assert body.count('_receipt_tree(')==1
out=dict(schema='typed-selected-owner-lifecycle-Source-negative-v1',reviewer_identity='/root/recovered_batch_review',
 status='BLOCKING_INDEPENDENT_RECONCILIATION_AND_CUSTODY_OCCURRENCE_GAPS',review_passed=False,source_only=True,
 selected_handoff=pin(C/'handoff-v1.json'),Source_custody=pin(O/'selected-owner-Source-custody-v1.json'),
 checker=pin(p),selected_worker=pin(C/'author/qualify_owner_batch_worker_v1.py'),
 producer=pin(C/'author/immutable_event_store_v1.py'),
 findings=[
   dict(id='Recomputed after-tree lacks final raw receipt join',
     Source='_live RECONCILE_VERSION/RECONCILE_RESULT branches and final profile/diagnostic lifetime loops',
     argument='The original typed revision is joined to seen_preimage. The recomputed after-tree is retained only as revision.index(2), then compared for equality with the original. There is no _receipt_tree or equivalent correspondence from this after-tree to the matching full final raw receipt. Full native final-lifetime comparison is separate and cannot supply the absent edge.',
     unrun_recipe='In a negative mutation profile with a false reconciliation result, preserve the entire original native packet/banks/manifest/catalog and final mutated raw receipt. Keep original typed preimage and all role/scope/version/lifecycle metadata. Replace only the stored recomputed after-tree by another complete unequal typed tree, and coherently encode its owner/state/tape references. The current equality result remains false; none of the full final native comparisons connects that replacement to the changed raw receipt.',
     correction='Bind every recomputed typed after-tree to its exact receipt position/version in the full raw lifetime or an independently bound immutable raw after-version. Preserve raw and typed before/after values and any callback mutation timing.'),
   dict(id='Reconciliation occurrence completeness is conditional on presence',
     Source='_live reconciled dictionary and normal final profile loop',
     argument='reconciled is populated by a VERSION snapshot and consulted by a RESULT snapshot, but no completed profile requires a complete ordered unique VERSION/RESULT pair for every reconciled receipt position. No final test exhausts expected positions or exact stage occurrences.',
     unrun_recipe='For an otherwise intended complete normal wrapper certificate, omit all RECONCILE_VERSION and RECONCILE_RESULT snapshots and their event roots, retain every full receipt/preimage/final lifetime, and coherently renumber event ordinals/entry-parent refs/root tape. Query registration/production/preimage/delivery counters and all call/profile/observation populations are unchanged. The current reconciliation clauses are never entered.',
     correction='Derive exact required reconciliation stage/position order from complete profile state, with explicit failed-prefix rules for partial work, and reject missing/duplicate/reordered or unpaired occurrences.'),
   dict(id='Custody event pairs not conserved against lifetime flags',
     Source='_live ENTER/RETURN CUSTODY handling and final lifetime joins',
     argument='CUSTODY event role/arguments/result/scope are checked when present. There is no required entry/exit phase-pair population joined to custody_entry_attempted/completed and custody_exit_attempted/completed lifetime fields. Those fields remain in the fully compared packet, but do not require corresponding event occurrences.',
     unrun_recipe='In a normal completed wrapper certificate, remove the no-child CUSTODY entry/return event pairs and coherently renumber remaining event/tape references. Keep the original complete native lifetime and all true custody flags, actual raw owners, query/profile/call maps and observations unchanged. Current event-population checks do not count the omitted pairs.',
     correction='Join exact entry/exit custody phase arguments, attempt/completion/failure events and normal/cleanup lifetime flags; retain real runtime Source guards as a distinct requirement.')],
 scope='These are missing independent certificate predicates. No forged wire was generated, schema called, actual run admitted or false mathematical theorem demonstrated. Genuine producer Source may emit the intended data, but independent complete-preservation checking cannot be inferred from that behavior.',
 author_confirmation='B independently acknowledged the missing recomputed-after-tree/final-raw bridge. The omission/custody completeness findings are independent manual Source findings.',
 remaining_full_review='Full function/field/owner/event/worker coverage review continues; this early negative does not certify all other predicates. Original resource/outer integration/initialization/embedding/search obligations remain open.',
 static_metadata=dict(AST_parse=True,unused_compile=True,code_executed=False),
 subject_imports=0,subject_calls=0,helper_calls=0,compiler_calls=0,checker_calls=0,
 fixture_calls=0,simulator_calls=0,generator_calls=0,sizing_probes=0,semantic_replays=0,
 partial_files_opened=0,new_actuals=0,new_grants=0,actual_execution_authorized=False,
 G1_adopted=False,old_G0_negative_unchanged=True,runtime_qualified=False,fit_proved=False,
 full_VM_qualified=False,new_theorem=False,GCTS_RL_advantage_established=False,goal_status='active',
 selected_author_sources_mutated=False,primary_reader_index_active_mutated=False,author=pin(Path(__file__)))
p=O/'typed-selected-owner-lifecycle-Source-negative-v1.json';assert not p.exists()
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(negative=pin(p)),sort_keys=True))
