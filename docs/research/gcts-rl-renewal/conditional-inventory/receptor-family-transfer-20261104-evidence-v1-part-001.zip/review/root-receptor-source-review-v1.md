# Root prospective Source admission

PASS for the declared bounded experiment, before scientific imports or calls.
This note admits execution, not a mathematical or experimental result.

Root read the current master and its exact copied reference; both have SHA-256
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
The sixteen inherited Source files and five reference files were compared byte
for byte to the completed ranked-arithmetic run. Their previous full Source
reviews are reused only for those identical bytes. The base engine remains
`9953582e09e4a800591953b341812082a5eb9d13afa6aa36a1104eb1f1b5ea22`.

Root read the full new learner, independent checker, qualification helper,
phase controller, all common-driver changes and inherited observer context,
the entire callback qualification, and all semantic-checker changes with their
affected scheduler/frame/endpoint context. The callback checker retains all
unchanged independently reviewed C3 bodies. Its final receipt normalization for
an invalid non-string profile is JSON-safe. New Sources import only standard
libraries at module initialization. AST parsing and passive JSON/hash reads
performed during review did not import or invoke a scientific module.

The separate learner/checker authors independently reviewed each other's core
Sources. A third author peer-read the complete driver/controller/qualification
integration. Root independently reviewed their notes and both checker fixes:
the expansion cache key remains separate from per-line lookup keys, and active
points exclude nonroot seed keys with zero contribution. The latter has a
separately declared synthetic point-model fixture with fresh concrete admission.
The unchanged cohort model is not replaced by that fixture. Earlier held drafts
and exact patches are retained as review history; they will not execute.

The sole training proof is explicitly warm, previously published automatic GCTS
output. Its 51 copied original files were authenticated against the declared
manifest. The frozen original closure is complete. The new driver will join
actual donor PID/protocol/result/log/point/native projections and perform fresh
semantic and native donor checks before learning. The original seen declaration
is byte-identical to its parent. Two new declarations fix changed terms and
contexts in advance; they add an uninterpreted unary symbol with no new axiom.
Full RF profiles, eight slots and all caps remain unchanged. Refusals stay in
the results; no target proof is supplied.

Learned hypotheses preserve literal binders/names and donor slot positions.
Every concrete expansion must use current admitted primitive payloads, formula
IDs and CIDs. Independent receipts bind each current model/library/statement/
instance before policy use. State checks repeat after every actual callback and
rollback. Shared placement identities contribute once; distant assigned marks
and ordinary/local filters are checked. Empty or unavailable proposals leave
the complete primitive fallback available. No learned exclusion is activated.

Guidance returns only continuation preferences at the engine's chosen branch
point. Immutable hashes are computed during timed setup; actual callback work
is charged, and stop exceptions propagate. C4 checks the entire emitted branch
permutation, first choice and failed-child identity, retaining global dead,
forced, generation and exact rollback rules. Tiny actual graph/oracle checks
precede the study. Large target claims use semantic events and serialized
endpoints, not invented intermediate producer observations.

All positives, including direct and conventional controls, need independent
M/N projection and fresh whole native B validation. Comparisons distinguish
warm family reuse from the conventional planner without that library. All
learning, preparation, checking, setup, search and final proof costs remain
available. No result, performance advantage, RL, universal finite Wang palette,
arbitrary slot/alpha transfer, full Peano arithmetic or infinite tiling is
established by this admission. The long-term research goal remains active.

After freeze, no scientific Source/input/plan or pinned review file may change.
Each declared phase gets one owned process attempt. Native errors, guard stops,
resource refusals and UNKNOWN remain evidence. Passive publication Sources may
be authored later under `publication/`, separately reviewed before execution.
