# Complete branch-order assurance: Source handoff

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No scientific module
was imported or called. Only Source authoring, byte pins and Python AST parsing
were performed. Read the unchanged complete master reference, byte pin
`c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
E remains unchanged. Owned Sources are `semantic_event_checker_v4.py` and
`callback_qualification_v1.py`; the full C3 delta is
`review/semantic-event-checker-v3-to-v4.patch`.

## C4 public/private ABI

```python
Reader(model, result, meter, *, order_profile='LEXICAL_V1')
verify_explicit_events(model, result, *, max_items, max_work,
                       wall_seconds, order_profile='LEXICAL_V1')
verify(model, result, *, max_items, max_work, wall_seconds,
       order_profile='LEXICAL_V1')  # forwarding convenience alias
```

`order_profile` is a native string, exactly `LEXICAL_V1` or
`COMPLETE_PERMUTATION_V1`. It is declared by the caller, not read from the raw
result or inferred as permission to weaken the default. `VERSION` becomes
`Independent-explicit-semantic-event-checker-v4`. Existing E-result/model
schemas, statuses, explicit-universe restrictions and resource guards remain.
Root calls the original `verify_explicit_events` entry point; the alias adds
no second verification implementation.

Lexical mode preserves the old zero-callback requirement and complete lexical
BRANCH payload. All model normalization, global capacity/mark/filter legality,
complete dependency/incidence, dead/forced/earliest scheduler, placement
generations, parent exclusion, exact rollback, endpoint, certificate and native
scope code is retained. The new profile changes only admitted branch ordering
and its count metadata.

For explicit complete permutation, BRANCH still has exactly `generation`,
`legal`, `order`. `legal` is the **complete sorted native-CID domain** at the
independently chosen point. `order` has the same length, native-string unique
members and exactly that domain. It may be lexical. E's prefix preference is
not the retained BRANCH order: E appends all remaining legal candidates first.
C4 stores `order[0]` in its pending placement and failed-child frame; subsequent
PLACED/EXCLUDE must match that actual first choice. Different points,
generations, omitted fallback, duplicate/foreign CIDs and wrong rollback
identity are rejected. Scratch set/literal visits are charged.

## Callback counts and UNKNOWN

For complete SAT/UNSAT, reported `ordering_calls` equals reported branches and
every independently replayed/emitted BRANCH. Default lexical mode still demands
zero callbacks, even when a nonlexical raw transcript is presented.

For raw UNKNOWN, E can stop after starting an order callback but before emitting
its BRANCH. Coarse metadata therefore permits reported calls equal to reported
branches or one greater. With the **entire emitted event payload retained**, C4
also binds calls to replayed branches, permitting at most one unjoined call.
That extra call requires READY already processed, no pending placement, no
failed child or terminal, and a current independently reconstructed BRANCH
decision. Reported branches may also be one ahead if E stopped while encoding
the next BRANCH after incrementing its counter.

If the event stream is truncated, only the retained branch lower bound and
coarse metadata relation can be checked; omitted suffixes are not invented.
Raw UNKNOWN or incomplete events still return UNKNOWN and never finite
absence. A complete emitted payload is not a completed proof/search. These
joins certify possible callback-count consistency and actual recorded chosen
orders, not physical hook execution, policy/library semantics, optimality or
the contents of an interrupted request. Execution/source custody and the
independent family/state checker remain separate gates.

Returned receipts add `order_profile`, `ordering_metadata` when available and
`counts.nonlexical_orders`. Ordering metadata contains `profile`,
`reported_calls`, `replayed_branches`, `unjoined_calls` (null for unobserved
suffixes), and `scope`. It may be null when a resource or missing-entry stop
prevents that association. Existing semantic result fields retain their scope.

## Fresh qualification module

```python
callback_qualification_v1.run(ctx)  # result status QUALIFIED
```

Root runs the existing fresh `K.run(ctx)` first. Context provides `mods` E/C4/T,
`limits['E']`/`limits['C']`, `read`, `save`, `wire` and:

```python
ctx.engine(name, model, actual=True, order=callback_or_none)
```

The helper persists actual model/raw/observation files before C4/T and its
separate paired independent Reader snapshots. For nonnull `order`, Root must
pass the explicit permutation profile both to C4 and paired Reader. G artifacts
use `data/callback-qualify/` for metadata and the engine helper's
`data/engine/callback-qualify/` namespace. No existing K artifact is overwritten.

Five fresh complete tiny calls cover default lexical, full reverse, reverse
after a failed child, prefix preference with complete fallback after rollback,
and global forced placement before any callback. Actual requests are charged
and saved. Complete C4/T/paired graph checks and callback/branch censuses must
all pass. The rollback model uses integer residual obligations, without geometry
or logical target proofs; a selected bad row exposes an unfillable point.

One fresh hook-budget call charges the engine's unchanged work ceiling plus
one through its supplied hook. The engine stop must propagate to raw/C4/T/
paired UNKNOWN, with no absence; actual calls are one and emitted branches
zero. C4 must record one unjoined branch-ready callback. No frozen cap is raised.

Eleven deliberately mutated saved inputs exercise missing fallback, duplicate
or foreign order, omitted legal domain, wrong first placement, wrong failed
exclusion, zero/extra/boolean callback counters, default lexical rejection and
two unjoined callbacks. Ordinary event hashes are recomputed so semantic order
and frame gates are exercised. Mutant inputs and checker returns are saved
before assertions; no mutant is executed as search or used as a learned label.

The output schema is `Callback-order-qualification-v1`, version
`Complete-permutation-callback-qualification-v1`, status `QUALIFIED`, with
`cases`, `mutants`, `hook_unknown`, actual counts, elapsed time and scope. Counts
are observed, not Source-time claims. This qualification says nothing about a
target theorem, donor/family universal validity, learned pruning, RL or speed.
