# Receptor learner/proposer Source peer

Status: `PASS_SOURCE_ONLY_REVIEW`. Full held learner and packet ABI read found
no outstanding blocker. This is not a learned-library, current-instance,
native-proof, performance or runtime qualification receipt.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `source/receptor_families_v1.py` | 28607 | `b66de4b662aee4046ff6fbc9ccb20bf674f12342b5f3bc5982ecb76fb0a8f73f` |
| `plan/receptor-family-packets-v1.md` | 7621 | `5b6a2c41664e08f4c303f7e9f1c68d636e0439fddb2649124d4e4ab90e05678e` |

Only Source reads, byte hashes and a standard-library AST parse were performed.
Neither L nor any scientific helper was imported or called. No donor or new
target proof was searched, no models were constructed, and no reviewed Source
was edited during this peer review.

The Source imports only standard-library modules. It receives a statement and
one authorized donor proof, with no case-specific arithmetic constants,
preselected proof lines, target derivation or stored strategy. Donor process/
native/file authenticity remains an external Root gate. The Source explicitly
labels the resulting schemas empirical hypotheses, not universal axioms.

Term candidates cover nonconstant native subterms of the full statement and
proof, ordered by size/wire; generic one-/two-term combinations are followed by
optional unary-function context abstraction. Whole-term replacement precedes
descent, preserving opaque bindings. All parameters must occur in the goal and
every retained prototype restores the entire donor statement/proof. Literal
binder, axiom/rule/symbol names and reference indices stay fixed. Canonical
family preimages agree with independent X.

All nonempty donor-index subsets are considered. Rooted reachability through
internal strict-prior references decides inclusion; internal/external typed
edges and all outside premise indices define each cluster. These complete
topology records and IDs agree with X's independent enumeration. A library
does not encode a handwritten chosen cluster.

Goal matching uses shared term bindings and all one-hole term decompositions,
including identity. The explicit current-theory gate preserves same named
instantiated hypotheses and surviving declaration arities, permits additional
current declarations, and syntax-checks instantiated payloads. No alpha-renaming
or capture-avoiding meta-logic is asserted. Exact current primitive ZERO payload
and MP/GEN lookup plus X and final native B remain necessary.

Instantiation binds the full current prepared statement, exact donor line count
to current slots and the complete current inventory ID set. It uses current
formula IDs and native definitions; duplicate identical ZERO payloads choose
the smallest ID. Full proof mappings are cached only inside the current call,
then every learned cluster receives its exact member CIDs, root and external
formulas. No PAD, new primitive row, domain removal or supplied target proof is
created. Instance and outer model/library/statement/scope preimages match X.

Resource limits are lower-only and cooperative. A stopped preparation returns
UNKNOWN without an admitted partial library/list. Successful returns pass a
final wall/work check. Failure to match an instance is proposal absence, not
negative theorem evidence. This Source performs no state, t/m/filter, global
scheduler or rollback claim; independent current X checks and complete primitive
fallback are required before guidance. Matched direct-expansion controls and
actual end-to-end costs remain necessary for any later practical assessment.
