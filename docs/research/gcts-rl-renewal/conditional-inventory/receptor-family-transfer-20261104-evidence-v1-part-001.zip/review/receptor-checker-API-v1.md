# Independent receptor checker and inert qualification

Source-only until Root review and prospective freeze. The checker imports only
`hashlib`, `json`, `math`, `time`; the qualification helper imports only `copy`
and `time`. No learner, engine, native checker, private helper or previous-run
module was imported or called during authorship. AST parsing is not runtime
qualification. Shared packet/preimage definitions are in
`plan/receptor-family-packets-v1.md`.

## Library provenance

```python
verify_library(statement, proof, library, limits=None)
```

Returns `VERIFIED_PROVENANCE`, `REJECTED` or `UNKNOWN`. The successful receipt
binds `statement_sha256`, `proof_sha256` and `library_sha256` and counts the
families/clusters. It independently checks:

- Exact donor hashes and final goal, strict earlier native references, literal
  statement/formula syntax and donor line bound.
- Every declared term parameter is a distinct nonconstant native term: a
  variable or a function with positive arity. Every context prototype is one
  declared unary donor function applied to `['_hole']`.
- Term replacement occurs at an entire matching term before descending, then
  remaining unary-function occurrences become context applications. Binder,
  symbol and payload-field strings are unchanged. Both complete templates must
  equal this independent transformation and restore the entire donor.
- Every parameter is visible in the goal; IDs bind the exact declared family
  body. No unrestricted formula/rule/name wildcard is admitted.
- Every nonempty rooted induced sub-DAG is independently enumerated from the
  donor's actual strict-prior reference graph. Members, root, internal/external
  typed edges, receptor indices and cluster IDs must match exactly.

This is donor/transformation provenance only. Donor file/process/kernel
authenticity is an external gate. The receipt proves neither every schematic
instance nor completeness of the learner's term-abstraction enumeration. An
empty family collection cannot guide any instance.

## Efficient current instance admission

```python
checker = AdmissionChecker(statement, prepared, model, library, limits=None)
checker.status                 # READY | REJECTED | UNKNOWN
checker.reason                 # None or explicit refusal
receipt = checker.admit(instance)

# Convenience wrapper, one index for one call:
admit(statement, prepared, model, library, instance, limits=None)
```

Constructor failures are retained as status/reason; `.admit` returns that clean
JSON refusal. Work/wall are cumulative from construction across all admissions,
not reset per cluster. Per-instance structural rejection does not poison an
otherwise ready index. An exhausted resource context remains UNKNOWN.

The context clones its learned templates and current statement and constructs
its own immutable current row/formula/producer indices. The normalized model
hash uses the engine's literal schema-v3 canonical convention: sorted roots,
seed/support rows, inventory CIDs and declared filters. Current prepared and
catalogue statements and content bindings must agree. Full RF/profile/model
completeness, native ZERO truth and process/file authentication remain external.

The current slot count must equal donor proof length. Native donor line index
is current slot index; there is no slot relocation, padding synthesis, arbitrary
alpha-renaming or new primitive row. Parameter bindings instantiate the entire
proof. Every used current symbol must typecheck; surviving donor declarations
retain arity. The instantiated donor hypotheses must match the same current
axiom names/formulas, with extra current declarations/hypotheses allowed. The
goal must be exact. Every ZERO payload must equal an actual current native
payload; ties choose the smallest definition ID. Every MP/GEN reference and
formula must identify a current producer. Every resulting CID must be an
actual current row with exact own and premise ports. The whole fixed-slot
expansion must be point/mark/filter consistent and fill current required roots.

Full expansion verification is cached by the exact model, family, bindings and
expansion hashes. The authorized three-line cache fix uses `cache_key` for both
lookup and storage, preserving the earlier held Source separately. Each
cluster's actual members, root and all external receptor formulas are still
checked on every admission; cached expansion is not cached cluster acceptance.

Success is `VERIFIED_INSTANCE`, with exactly these required bindings:

```text
bindings = {model_sha256, instance_sha256, statement_sha256, library_sha256}
```

It also returns `prepared_scope`, family/cluster IDs, cluster CIDs, the full
line-to-CID mapping and cumulative work/seconds. Root must compare these
bindings to the exact current objects before passing a raw instance to policy.
This concrete primitive-row check is not final theorem acceptance. Fresh M/N
decoding and whole native B validation are still required for a target proof.

## Current-state compatibility

```python
state = StateChecker(model, admitted_raw_instances, limits=None)
state.status                   # READY | REJECTED | UNKNOWN
answer = state.check(instance, request, charge)
```

The caller supplies only raw instances whose independent admission bindings it
has authenticated. Construction clones those approved packets and indexes the
normalized model once. It does not replace the library/native admission gate.

The request is the actual `Z-candidate-order-request-v1` packet with fields
`schema, model_sha256, point, generation, legal, selected, excluded`. Every
callback rechecks these identities and the current selected/excluded sets.
Active points are explicit roots plus strictly positive seed/selected support;
a zero-valued nonroot seed entry is not activated.
Selected plus cluster placements form a distinct-CID union: a shared placement
contributes once. Seed/placement capacity, every assigned mark including literal
zero and far mark-only support, unary/pair filters and local exclusions are
checked. At least one new cluster CID must be in `legal` and touch the requested
point. Excluded cluster members reject the proposal. No selected/excluded state
or negative context is cached across rollback.

`COMPATIBLE` returns model/instance/selected/excluded/union bindings, currently
legal preferred CIDs, shared/new member counts, receptor count and work.
`REJECTED` is a proposal refusal, never a proof-search negative label. Missing
receptor owners are allowed only as consistent literal demands; compatibility
does not assert extension, a full boundary solution or a native theorem.
Actual legal-domain completeness, generation/global scheduler correctness and
complete fallback remain the unchanged engine/C4 duties, not this checker.

All state loops are cooperatively charged through the supplied hook, including
structural/hash work and aggregate support checks. Every exception originating
from that hook propagates rather than becoming a checker rejection/UNKNOWN.
An unavailable constructor index permits no compatible proposal; policy must
retain its primitive fallback and report that unavailable status.

## Limits and prospective qualification helper

Both independent contexts accept only lower versions of:

```json
{"max_work":100000000,"wall_seconds":30.0,
 "max_families":4096,"max_instances":4096,"max_lines":16}
```

Integer count/work limits are native nonnegative integers, excluding bool/float;
zero gives a resource UNKNOWN when exceeded. Wall is finite and positive.
Additional fixed JSON safety bounds are depth 128 and integer width 256 bits;
cycles and nonnative JSON containers reject. Work is cooperative loop/string/
serialization accounting, not CPU instructions or physical memory. A final
cooperative gate follows success-path hashing. Native outer guards remain
caller-owned.

The inert `source/receptor_qualification_v1.py` exports:

```python
run_library(ctx, statement, proof, library)
run_instances(ctx, statement, prepared, model, library, admitted_instances)
```

Context requirements: `ctx.mods['X']`, `ctx.limits['family']`, `ctx.save`,
`ctx.read`, `ctx.sha`, `ctx.wire`. Root supplies only actual fresh learned and
independently admitted outputs after freeze. All tested inputs/answers are
saved before assertions. Source helper returns `QUALIFIED` only after the
declared actual checks, otherwise the Root worker preserves the failed attempt.

Library checks include actual provenance, donor hash/prototype/cluster/goal
visibility mutations with rehashed IDs, and work-zero UNKNOWN. Instance checks
include actual concrete admission, rehashed parameter/binder/native payload/CID/
receptor forgeries, nonliteral model mark and work-zero UNKNOWN. State checks
include compatible union, a shared member counted once, distinct same-slot
owner overcapacity, local exclusion and exact restored input, foreign scope/ID,
missing receptor owners as demand-only, and an actual sentinel charge exception
which must propagate unchanged.

An additional generic point-model fixture removes one actual member's root and
sets that point's seed contribution to zero. The helper first requires a fresh
concrete instance admission and binds its model/instance hashes, then requires
the forged request at the inactive zero-only point to reject specifically at
`CURRENT_FRONTIER_POINT`. This modified fixture has no original RF/N model
admission or observed-engine-state claim; the original cohort model is untouched.

These state requests are explicitly synthetic data fixtures over actual
admitted current members. Their one-member `legal` arrays do not claim observed
GCTS domains or scheduler states. No extra engine search or fabricated successful
process/provenance receipt is used. Separate E/C4 callback qualification and
actual policy-call receipts are required before any search-conformance claim.
