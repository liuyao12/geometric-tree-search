# Receptor driver integration Source review

Status: **PASS_SOURCE_REVIEW_ONLY**. No remaining integration blocker found.
This is static Source review, not execution or scientific admission. No scientific
module was imported, called, constructed or tested by this reviewer.

| Reviewed file | Bytes | SHA-256 |
|---|---:|---|
| `source/run_receptor_transfer_v1.py` | 22036 | `fd70272ee141f31b5280d40beab448ec330c2f3e1e7fb2bef1cf3c32c2c79201` |
| `source/receptor_phases_v1.py` | 18838 | `9dbe494b5959da4ca82db02096919d9b1cb3dc61c21a40372718fb3652ac2bf8` |
| `source/receptor_qualification_v1.py` | 11121 | `e6a8914d9824b37118b3645c96e1a7fbfef7765fc75d75a59745b2d1986ee303` |

Read the complete current driver, phase module and qualification module; checked
the driver against the copied prior driver using AST body comparison. Changes
are confined to the phase/module declarations and limits, `freeze`,
`prerequisites`, `worker`, `paired_graphs` and `Context`. Other guard, exclusive
capture, runtime/protocol custody, observer and prerequisite-admission bodies
retain the reviewed prior implementation. Syntax was parsed without imports.
The current master copy is the reference for this review.

The phase schedule admits prior actual process/result/protocol/log associations
before dependent work. CaseContext namespaces preparation and rank artifacts
without changing declaration/model semantics or double-prefixing saved refs.
The donor is explicitly warm training evidence: its frozen physical closure,
actual process, selected point certificate and both original native projections
are joined, followed by fresh semantic and native checks. No target proof is
passed to target preparation or engine search.

Library provenance, proposal and admitted-instance receipts are bound to the
current statement, library, prepared scope, model and individual instance. Y's
library and instance/state qualifications save inputs and returned receipts
before assertions; its constructed state requests are labeled synthetic rather
than claimed observed engine states. Lack of a family admission leaves the
complete primitive fallback available. This does not establish universal
schematic validity or family-enumeration completeness.

The callback is only a branch-order preference over the unchanged engine's
chosen point. Cached proposals are rechecked against each actual request after
rollback. X checks distinct selected/member identities, full capacity/mark/filter
compatibility and current legal contact. An absent receptor owner is only a
consistent demand, not an extension certificate. E appends every omitted base
candidate; global dead/forced/earliest-generation scheduling is unchanged.

The preliminary accounting issue was corrected: immutable instance hashes/CIDs
are computed in timed setup, and callback request/member/log traversal is
charged through the engine hook. X's hook stop propagates. Setup, search and
semantic assurance costs remain distinct. A single run in fixed method order
does not establish comparative performance.

C4's explicit complete-permutation profile is passed to both semantic assurance
and the independent paired graph reconstruction. Default lexical runs retain
zero callback semantics. Full actual producer graph capture is confined to tiny
qualification; large target runs claim semantic event/endpoints only. Raw
results are saved before assurance. UNKNOWN is never an absence certificate.
Every accepted target result, including direct-library and conventional-control
candidates, requires the fresh exact M/N native projection and whole B check.

Interface checks used C4 `68bb7f2d…`, G `23d74a23…`, L `b66de4b6…`,
X `f86f8402…`, the D projection and H rank APIs, and the declared three cases.
This reviewer authored C4/G and does not present this integration note as their
independent semantic peer review. Their prospective callback/mutation runs,
Root's Source admission/freeze and all actual scientific/native/process results
remain separate required gates. No results or speed advantage are claimed here.
