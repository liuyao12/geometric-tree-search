# Receptor-family transfer: prospective interfaces

This is an explicitly warm reuse experiment. One published, automatically found
eight-line native proof is the only training proof. No new target proof is supplied.
No reinforcement learning or universal-family soundness is claimed. All Sources,
inputs, reviews and limits must be frozen before scientific imports or calls.

## Scientific scope

The unchanged full RF compiler, independent native kernel, complete shared-fact
adapter and exact growing-point engine remain the base. Analytic rank pruning is
a separately verified redundant constraint shared by the point-search comparisons.
The learned library changes candidate order only. Every branch keeps every base
candidate, and every placement uses the engine's existing global dead/forced,
earliest-generation and rollback machinery. Neither a failed match nor a refused
proposal proves a negative result. The mathematical point semantics are those of
`reference/basic-tiling-algorithm.md`.

The first family implementation deliberately preserves the donor line-to-slot
mapping. It learns term and one-hole context parameters and rooted sub-DAGs, but
does not claim arbitrary slot relocation, alpha-renaming or arbitrary theorem
generalization. All eight-line expansions must match the current primitive
catalogue exactly. A subcluster's external dependencies are its receptors.

## Shared canonical data

`wire(value)` is sorted-key, ASCII, compact JSON plus one newline; `sha(value)`
is its SHA-256. Formula and term ASTs use the existing native list representation.
The donor manifest is `input/donor-manifest-v1.json`. Its `proof` path is relative
to `input/donor/`. Prepared catalogues and point models retain their existing ABI.

## L: learner and proposer, `source/receptor_families_v1.py`

Public functions (all inert until called):

- `learn(statement, proof, limits=None)` returns a JSON packet with `status`
  `CANDIDATE_LIBRARY` or `UNKNOWN`/`REJECTED`, donor hashes, all hypotheses,
  prototype bindings and every rooted nonempty sub-DAG. Enumerate simultaneous
  one- or two-term abstractions of nonconstant donor terms, largest-first exact
  replacement; then optionally abstract a declared unary function as one-hole
  context. Use `['_term', name]`, `['_ctx', name, argument]`, `['_hole']`.
  Every parameter must occur in the transformed goal. A prototype restores the
  entire original statement/proof. No hand-written derivation or special line
  numbers are permitted. Enumerate subsets generically for proofs of at most
  16 lines; rooted reachability and external reference indices define clusters.
- `instantiate(library, statement, prepared, model, limits=None)` returns
  `CANDIDATE_INSTANCES` with `instances`, or `UNKNOWN`/`REJECTED`. Match the goal
  template by term binding and one-hole context decomposition; instantiate all
  proof payloads. Look up exact native ZERO payloads and MP/GEN definitions in
  the current admitted prepared catalogue. Use current formula IDs and actual
  CIDs, never donor IDs. Donor line index equals current slot index in this v1.
  Instances contain `family_id`, `cluster_id`, `bindings`, `line_cids` (pairs of
  donor index and CID), `receptors` (pairs of outside donor index and formula
  AST), `root` (donor index), and `expansion` (instantiated entire native proof).
  No PAD or new rows may be synthesized. Include all learned rooted clusters
  whose entire instantiated proof maps to actual current rows.

Proposed limits are lowerable only: max_work 100000000, wall_seconds 30,
max_families 4096, max_instances 4096, max_lines 16. Refusal must be explicit and
must not thin the base candidate universe. Hash IDs must be deterministic.

## X: independent family and state checker

`source/receptor_checker_v1.py` imports no learner or search helper.

- `verify_library(statement, proof, library, limits=None)` independently restores
  prototypes, checks donor binding, parameter visibility and every cluster's
  exact rooted internal/external dependency structure. Return `VERIFIED_PROVENANCE`
  only for provenance; this is not a proof of every schematic instance.
- `admit(statement, prepared, model, library, instance, limits=None)` independently
  instantiates the schema, checks every payload/definition/formula/CID and the
  original slot mapping, cluster and receptor data. Return `VERIFIED_INSTANCE`
  with model/instance bindings, or explicit rejection/unknown. May examine the
  entire current catalogue once per admission. This is a primitive-row expansion
  check, not final theorem acceptance.
- `StateChecker(model, admitted_instances)` builds an immutable index once.
  `.check(instance, request, charge)` returns JSON with `status` `COMPATIBLE` or
  `REJECTED`. The caller passes only independently admitted instances. Validate
  request model SHA and current selected/excluded identities, selected plus
  cluster distinct-placement t-sums and m-union, receptor demands, and some
  cluster CID in `request.legal` touching `request.point`. Missing receptor
  owners are allowed only as consistent literal demands, never an extension
  certificate. An overlapping selected CID is counted once. Charge all loops
  through the engine hook, and allow its stop exception to propagate.

Same default lowerable limits as L. State checker may cache immutable indexes;
it must recheck selected/excluded state on every callback and after rollback.

## C4: complete branch-order semantic assurance

New `source/semantic_event_checker_v4.py` preserves the old C3 default API and
adds `order_profile='LEXICAL_V1'` to `Reader` and `verify`. Explicit
`COMPLETE_PERMUTATION_V1` admits a unique permutation of the complete actual
chosen-point legal domain, with selected first element. All global propagation,
generation and rollback checks remain. Callback count equals emitted branches
on complete SAT/UNSAT; UNKNOWN may have one interrupted callback. Lexical mode
still requires zero callbacks. Do not change E. A new source-only qualification
module exercises reverse order, prefix preference with complete fallback,
malformed order/stat mutants and callback-budget UNKNOWN. No execution before
freeze. API details that need extra arguments must be reported before changing.

## Root-owned policy and comparison

Choose deterministic largest compatible learned cluster, then canonical instance
wire keys. Cached continuation preferences are revalidated at every callback.
Return only its currently legal CIDs; unchanged E appends the complete fallback.
Root records proposal/admission/check/order costs and refusals. Compare rank-only
GCTS, guidance restricted to learned clusters with nonempty receptors, guidance
using every learned cluster including whole proofs, and direct same-library
expansion on the same new statements. An additional specialized conventional
AND/OR control receives the same full primitive catalogue and analytic rank
information, without the learned library. Warm versus cold information must be
distinguished in reporting. Every positive goes through fresh M/N decoding and native B checking.
Report all preparation, learning, validation and search costs, and preserve native
errors/UNKNOWN. No performance or RL conclusion is assumed in advance.
