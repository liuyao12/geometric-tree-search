"""Passive V5 saved-data projection and reader. No scientific imports or replay.

Root reviews this Source before running it with the frozen isolated Python.
Outputs are exclusive. All full original records remain in the physical archive.
"""
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = 'protocol/frozen-protocol-v1.json'
AUDIT = 'publication/saved-data-audit-v1.json'
CASES = ('seen', 'unary-transfer', 'nested-transfer')
PHASES = ('qualify', 'learn') + tuple(p+'-'+c for c in CASES for p in ('prepare','evaluate'))
EXPECTED = {p: 'QUALIFIED' if p=='qualify' else 'LEARNING_RECORDED' if p=='learn' else 'CASE_RECORDED' for p in PHASES}
METHODS = ('RANK_ONLY','RECEPTOR_GUIDED','FAMILY_GUIDED','CONVENTIONAL_AND_OR','DIRECT_SAME_LIBRARY')
SEMANTIC = ('statement','proof','slots','slot_to_native','native_to_slot','reference_mapping','proof_dag','selected','selected_sha256','original_statement_sha256','scope')
PINS = {}
INSTANCE_LIMIT = 64


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def wire(v):
    return (json.dumps(v,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(v):
    return hashlib.sha256(wire(v)).hexdigest()


def same(a,b,why):
    need(wire(a)==wire(b),why)


def path(name):
    need(type(name) is str and not Path(name).is_absolute() and '..' not in Path(name).parts,'RELATIVE_LOCAL_PATH')
    p=ROOT/name
    q=p
    while q!=ROOT:
        need(not q.is_symlink(),'NO_SYMBOLIC_ARTIFACT')
        q=q.parent
    need(p.resolve().is_relative_to(ROOT.resolve()),'CONTAINED_ARTIFACT')
    return p


def pin(name):
    p=path(name);h=hashlib.sha256();n=0
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):
            h.update(b);n+=len(b)
    answer=dict(path=name,bytes=n,sha256=h.hexdigest())
    if name in PINS:same(PINS[name],answer,'UNCHANGED_PASSIVE_INPUT')
    PINS[name]=answer
    return answer


def read(name):
    pin(name)
    p=path(name)
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open(encoding='ascii')) as f:
        return json.load(f)


def checked(r):
    need(type(r) is dict and {'path','bytes','sha256'}<=r.keys(),'SAVED_REFERENCE')
    actual=pin(r['path'])
    same(actual,{k:r[k] for k in ('path','bytes','sha256')},'EXACT_SAVED_BYTES')
    v=read(r['path'])
    if r.get('pointer'):
        for s in r['pointer'].split('/')[1:]:
            s=s.replace('~1','/').replace('~0','~')
            v=v[int(s)] if type(v) is list else v[s]
    return v


def phase(name):
    names={k:('data/'+name+'/result.json' if k=='result' else 'run/'+name+'/'+k+'.json') for k in ('result','started','invocation','observer')}
    objects={k:read(v) if path(v).is_file() else None for k,v in names.items()}
    refs={k:pin(names[k]) for k,v in objects.items() if v is not None}
    r,s,i,o=(objects[k] for k in ('result','started','invocation','observer'))
    clean=False
    if s is not None and i is not None and o is not None:
        need(all(x['phase']==name for x in (s,i,o)),'PHASE_NAME_JOIN')
        need(all(type(x['pid']) is int and x['pid']>0 for x in (s,i,o)) and s['pid']==i['pid']==o['pid'],'PHASE_PID_JOIN')
        same(s['protocol'],pin(PROTOCOL),'PHASE_FROZEN_PROTOCOL')
        same(o['log'],pin('run/'+name+'/stdout.log'),'PHASE_LOG_BYTES')
        if i.get('result') is not None:
            need(r is not None and i['result'].get('complete_json') is True,'COMPLETE_PHASE_RESULT')
            same({k:i['result'][k] for k in ('path','bytes','sha256')},refs['result'],'PHASE_RESULT_BYTES')
            same(i['scientific_status'],r['status'],'PHASE_SCIENTIFIC_STATUS')
        clean=(r is not None and i.get('result') is not None and i['status']=='COMPLETE'
            and i['error_type'] is None and i['postcheck_error'] is None and o['status']=='TERMINAL'
            and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['frozen_postcheck']==o['frozen_postcheck']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS')
    return dict(name=name,pid=None if s is None else s['pid'],
        scientific_status=None if r is None else r['status'],process_clean=clean,
        scientific_admitted=bool(clean and r['status']==EXPECTED[name]),
        process_status='CLEAN_NATIVE_EXIT' if clean else 'NOT_RUN' if not refs else 'FAILED_OR_INCOMPLETE_PROCESS',
        native_exit_code=None if o is None else o.get('native_exit_code'),refs=refs,
        costs=dict(worker_seconds=None if i is None else i.get('seconds'),observer_seconds=None if o is None else o.get('seconds'),
            worker_maxrss=None if i is None else i.get('maxrss'),worker_maxrss_units=None if i is None else i.get('maxrss_units'),
            polled_peak_rss_bytes=None if o is None else o.get('peak_observed_rss_bytes')),
        invocation=i,observer=o),r


def engine(refs):
    raw,c=checked(refs['raw']),checked(refs['semantic'])
    if c.get('model_sha256') is not None:
        same(c['model_sha256'],raw.get('model_sha256'),'SEMANTIC_MODEL_SCOPE')
    if c['status']=='VERIFIED':
        need(c['event_coverage']=='COMPLETE' and c['run_status']==raw['status'],'COMPLETE_SEMANTIC_SCOPE')
        same(c['model_sha256'],raw['model_sha256'],'COMPLETE_SEMANTIC_MODEL')
        same(c['event_sha256'],raw['event_extent']['sha256'],'SEMANTIC_EVENT_SCOPE')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'BOUNDED_ABSENCE_SCOPE')
        need(c['claim']==('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status']=='SAT' else
             'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'),'EXACT_SEMANTIC_CLAIM')
    else:need(c.get('bounded_absence') is False,'UNKNOWN_NEVER_ABSENCE')
    return dict(raw_status=raw['status'],model_sha256=raw.get('model_sha256'),reason=raw.get('reason'),semantic_status=c['status'],
        semantic_reason=c.get('reason'),bounded_absence=c.get('bounded_absence'),stats=raw['stats'],
        event_extent=raw['event_extent'],rollback_extent=raw['rollback_extent'],order_profile=c.get('order_profile'),
        ordering_metadata=c.get('ordering_metadata'),refs=refs),raw


def native(identifier,method,refs,model,prepared,aliases,engine_refs=None):
    m,n,b=(checked(refs[k]) for k in ('adapter_decoded','independent_decoded','native_receipt'))
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE' and b['status']=='VERIFIED','ONLY_NATIVE_ADMITTED_PROOFS')
    for k in SEMANTIC:same(m[k],n[k],'INDEPENDENT_NATIVE_PROJECTION:'+k)
    same(m['statement'],prepared['statement'],'ORIGINAL_TARGET_STATEMENT')
    same(sha(m['statement']),m['original_statement_sha256'],'ORIGINAL_STATEMENT_HASH')
    same(sha(sorted(m['selected'])),m['selected_sha256'],'ACTUAL_SELECTED_HASH')
    need(type(b['checked_lines']) is int and b['checked_lines']==len(m['proof']),'WHOLE_NATIVE_CHECK')
    same(checked(refs['native_proof']),m['proof'],'SAVED_NATIVE_PROOF')
    if engine_refs is not None:
        e,raw=engine(engine_refs)
        need(raw['status']=='SAT' and e['semantic_status']=='VERIFIED','ACTUAL_POINT_POSITIVE')
        same(raw['selected'],m['selected'],'SELECTED_POINT_PROOF_JOIN')
    byid={r['id']:r for r in model['inventory']['placements']}
    role='POINT_SEARCH' if method in METHODS[:3] else 'SPECIALIZED_CONTROL' if method=='CONVENTIONAL_AND_OR' else 'DIRECT_SAME_LIBRARY'
    return dict(id=identifier,role=role,method=method,statement=m['statement'],proof=m['proof'],
        lines=len(m['proof']),statement_sha256=m['original_statement_sha256'],selected_sha256=m['selected_sha256'],
        proof_sha256=sha(m['proof']),proof_ref=refs['native_proof'],native_ref=refs['native_receipt'],
        slots=m['slots'],native_to_slot=m['native_to_slot'],slot_to_native=m['slot_to_native'],
        reference_mapping=m['reference_mapping'],proof_dag=m['proof_dag'],
        selected_rows=[byid[c] for c in m['selected']],aliases=aliases,refs=refs)


def reader_instances(instances):
    """Passive display selection; full source list remains unchanged/archived."""
    remaining=sorted(instances,key=lambda i:i['id']);chosen=[];families=set();clusters=set()
    while remaining and len(chosen)<INSTANCE_LIMIT:
        best=min(remaining,key=lambda i:(-int(i['family_id'] not in families)-int(i['cluster_id'] not in clusters),i['id']))
        remaining.remove(best);chosen.append(best)
        families.add(best['family_id']);clusters.add(best['cluster_id'])
    return chosen


def build_data():
    protocol=read(PROTOCOL);protocol_ref=pin(PROTOCOL)
    need(protocol['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS' and protocol['phases']==list(PHASES),'FROZEN_PROTOCOL')
    for r in protocol['files']:
        same(pin(r['path']),{k:r[k] for k in ('path','bytes','sha256')},'CURRENT_FROZEN_FILE')
    runtime=protocol['runtime'];exe=Path(sys.executable).resolve()
    need(str(exe)==runtime['executable']['path'] and sys.version==runtime['version'],'FROZEN_RUNTIME')
    need(sys.flags.isolated==runtime['isolated'] and sys.flags.no_site==runtime['no_site']
        and sys.dont_write_bytecode==runtime['dont_write_bytecode'],'FROZEN_RUNTIME_FLAGS')
    for r in (runtime['executable'],protocol['master']):
        h=hashlib.sha256();n=0
        with Path(r['path']).open('rb') as f:
            for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
        same(dict(bytes=n,sha256=h.hexdigest()),{k:r[k] for k in ('bytes','sha256')},'CURRENT_EXTERNAL_PIN')
    audit=read(AUDIT)
    need(audit['schema']=='Receptor-family-passive-audit-v1' and audit['status']=='PASS','SAVED_DATA_AUDIT_REQUIRED')
    same(audit['protocol'],protocol_ref,'AUDITED_PROTOCOL')
    phases,results=[],{}
    for name in PHASES:
        p,r=phase(name);phases.append(p);results[name]=r
    ap={p['name']:p for p in audit['phases']}
    need(len(ap)==len(audit['phases']) and set(ap)==set(PHASES),'EXACT_AUDITED_PHASES')
    for p in phases:
        for k in ('native_exit_code','scientific_status','process_clean','scientific_admitted'):
            same(p[k],ap[p['name']][k],'AUDITED_PHASE:'+k)
    learned=results['learn'];learning=None;library=None
    if learned is None and path('data/learn/library.json.gz').is_file():
        learned=dict(status='UNADMITTED_PARTIAL_PHASE',refs=dict(library=pin('data/learn/library.json.gz')),
                     scope='Actual saved prefix from a phase without an admitted result; not activated.')
    if learned is not None:
        learning=dict(result=learned,process_admitted=phases[1]['scientific_admitted'],families=[],clusters=[])
        if 'library' in learned.get('refs',{}):
            library=checked(learned['refs']['library'])
            learning.update(status=library['status'],costs=library.get('costs'),limits=library.get('limits'))
            if library['status']=='CANDIDATE_LIBRARY':
                learning['families']=[{k:f[k] for k in ('id','parameters','statement_template','prototype_bindings')} for f in library['families']]
                learning['clusters']=library['clusters']
        for key in ('library_receipt','qualification'):
            if key in learned.get('refs',{}):learning[key]=checked(learned['refs'][key])
    cases,proofs=[],[]
    declarations=read('input/transfer-cases-v1.json')['cases']
    same([x['id'] for x in declarations],list(CASES),'EXACT_DECLARED_CASES')
    for spec in declarations:
        cid=spec['id'];decl=read(spec['path']);pr=results['prepare-'+cid];ev=results['evaluate-'+cid]
        aliases={v:k for k,v in decl.get('names',{}).items()};aliases.update(qmtH='H')
        item=dict(id=cid,statement=decl['problem'],aliases=aliases,overlap=spec['training_overlap'],
            preparation=pr,evaluation=ev,instances=[],instance_projection=dict(limit=INSTANCE_LIMIT,total=0,retained=0),rows=[])
        if pr is not None and pr.get('preparation'):
            prepared_result=checked(pr['preparation']);item['preparation_detail']=prepared_result
            if prepared_result['status']=='PREPARED':
                prepared=checked(prepared_result['refs']['prepared'])
                same(prepared['statement'],decl['problem'],'CURRENT_PREPARED_DECLARATION')
                item['model_metadata']=dict(slots=prepared['binding']['slots'],formulas=len(prepared['catalogue']['formulas']),
                    zeros=len(prepared['catalogue']['zeros']),mp=len(prepared['catalogue']['mp']),gen=len(prepared['catalogue']['gen']),
                    rows=prepared['census']['rows'] if 'rows' in prepared.get('census',{}) else len(prepared['universe']))
                if 'rank' in pr.get('refs',{}):
                    rank=checked(pr['refs']['rank']);item['rank']=rank
                    if rank['status']=='RANK_ADMITTED':
                        model=checked(rank['refs']['marked_model']);model_sha=sha(model)
                        byid={r['id']:r for r in model['inventory']['placements']}
                        item['model_metadata']['rows']=len(byid)
                        if 'instance_receipts' in pr['refs']:
                            receipts=checked(pr['refs']['instance_receipts']);counts={}
                            for r in receipts:counts[r['receipt']['status']]=counts.get(r['receipt']['status'],0)+1
                            item['instance_admission_counts']=counts
                        if 'admitted' in pr['refs']:
                            instances=checked(pr['refs']['admitted'])
                            sample=reader_instances(instances)
                            item['instance_projection'].update(total=len(instances),retained=len(sample),
                                selection='Greedy distinct family/cluster coverage, ties by literal instance ID',
                                total_families=len({i['family_id'] for i in instances}),
                                shown_families=len({i['family_id'] for i in sample}),
                                total_clusters=len({i['cluster_id'] for i in instances}),
                                shown_clusters=len({i['cluster_id'] for i in sample}))
                            for i in sample:
                                item['instances'].append(dict(i,rows=[byid[c] for _,c in i['line_cids']]))
                        if ev is not None:
                            seen=set()
                            for row in ev['rows']:
                                method=row['method'];need(method in METHODS and method not in seen,'DISTINCT_KNOWN_METHOD');seen.add(method)
                                view=dict(row)
                                if method in METHODS[:3]:
                                    view['engine'],_=engine(row['refs'])
                                    same(row['model_sha256'],model_sha,'UNCHANGED_POINT_LANE_MODEL')
                                    same(view['engine']['model_sha256'],model_sha,'ACTUAL_POINT_LANE_MODEL')
                                if row['admitted_status']=='VERIFIED_NATIVE_POSITIVE':
                                    need(next(x for x in phases if x['name']=='evaluate-'+cid)['scientific_admitted'],'CLEAN_ACTUAL_POSITIVE_PHASE')
                                    identifier=cid+'--'+method
                                    proofs.append(native(identifier,method,row['native_refs'],model,prepared,aliases,
                                                         row['refs'] if method in METHODS[:3] else None))
                                    view['proof_id']=identifier
                                item['rows'].append(view)
                        else:
                            # Actual saved engine prefixes remain visible after a native
                            # process failure. They never acquire a proof from this route.
                            for method in METHODS[:3]:
                                prefix='data/engine/transfer-'+cid+'-'+method.lower()
                                if not path(prefix+'/raw.json.gz').is_file():continue
                                refs={k:pin(prefix+'/'+n) for k,n in
                                      (('raw','raw.json.gz'),('semantic','semantic.json.gz'),('model','model.json.gz'))
                                      if path(prefix+'/'+n).is_file()}
                                raw=checked(refs['raw'])
                                e=engine(refs)[0] if 'semantic' in refs else dict(raw_status=raw['status'],stats=raw['stats'],
                                    semantic_status='NOT_RECORDED',bounded_absence=False,refs=refs)
                                item['rows'].append(dict(method=method,raw_status=raw['status'],stats=raw['stats'],
                                    semantic_status=e['semantic_status'],engine=e,refs=refs,costs={},
                                    admitted_status='UNADMITTED_NATIVE_PROCESS_PREFIX'))
        cases.append(item)
    audits={p['id']:p for p in audit['native_proofs']}
    need(len(audits)==len(audit['native_proofs']),'DISTINCT_AUDITED_PROOF_IDS')
    for p in proofs:
        need(p['id'] in audits,'AUDITED_NATIVE_PROOF_PRESENT');a=audits[p['id']]
        for k in ('role','lines','statement_sha256','selected_sha256','proof_sha256'):same(p[k],a[k],'AUDITED_NATIVE:'+k)
        for k in ('proof_ref','native_ref'):
            same({z:p[k].get(z) for z in ('path','bytes','sha256','pointer')},
                 {z:a[k].get(z) for z in ('path','bytes','sha256','pointer')},'AUDITED_NATIVE_REF:'+k)
    return dict(schema='Receptor-family-report-data-v1',status='SAVED_DATA_ADMITTED_WITH_EXPLICIT_SCOPES',
        protocol=protocol_ref,limits=protocol['limits'],phases=phases,learning=learning,cases=cases,proofs=proofs,
        qualification=results['qualify'],saved_data_audits=[dict(ref=pin(AUDIT),status=audit['status'])],
        provenance=dict(artifact_pins=[PINS[k] for k in sorted(PINS)],external_pins=dict(runtime=runtime,master=protocol['master'])),
        scope='Warm fixed-slot term/context and rooted-cluster reuse. Explicit semantic point model; no RL, universal Wang palette, PA induction or performance advantage claim. Reader instances are a deterministic bounded projection; all exact originals are archived.')


def build():
    for name in ('report/receptor-families-v1.html','report/receptor-families-data-v1.json.gz','report/build-receipt-v1.json'):
        need(not path(name).exists(),'EXCLUSIVE_REPORT_OUTPUT')
    data=build_data();path('report').mkdir(exist_ok=True)
    path('report/receptor-families-data-v1.json.gz').write_bytes(gzip.compress(wire(data),mtime=0))
    path('report/receptor-families-v1.html').write_text(PAGE,encoding='utf-8')
    receipt=dict(schema='Receptor-family-report-build-v1',status='BUILT_FROM_ADMITTED_SAVED_DATA',
        protocol=data['protocol'],renderer_source=pin('publication/build_receptor_report_v1.py'),
        outputs=dict(main=pin('report/receptor-families-v1.html'),data=pin('report/receptor-families-data-v1.json.gz')),
        artifact_pins=data['provenance']['artifact_pins'],counts=dict(cases=len(data['cases']),proofs=len(data['proofs'])))
    path('report/build-receipt-v1.json').write_bytes(wire(receipt));print(json.dumps(receipt,sort_keys=True))


PAGE=r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Receptor families in proof search</title><style>
:root{color-scheme:light;--ink:#173c37;--muted:#586d66;--paper:#f6f5ed;--line:#cedad1;--purple:#b39acb;--orange:#c68c43}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.55 system-ui,sans-serif}main{max-width:1180px;margin:auto;padding:24px}nav{display:flex;gap:22px;flex-wrap:wrap;font-size:14px}a{color:#24726b}h1{font:clamp(36px,6vw,68px)/1.03 Georgia,serif;max-width:900px;margin:30px 0 18px}h2{font:29px/1.15 Georgia,serif}h3{font-size:18px}.eyebrow{text-transform:uppercase;letter-spacing:.13em;font-size:12px;margin-top:36px}.lede{font-size:20px;max-width:850px}.panel{background:#fffef8;border:1px solid var(--line);border-radius:10px;margin:22px 0;padding:24px;min-width:0}.note{border-left:4px solid #4c8f7d;background:#eaf3e9;padding:14px}.warning{border-color:#c48d40;background:#fbf1d9}.muted{color:var(--muted);font-size:14px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}.scroll,.formula,.diagram{max-width:100%;overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;vertical-align:top;padding:10px 8px;border-bottom:1px solid var(--line)}th{font-weight:650}button,select{font:inherit;color:inherit;padding:7px 10px;background:white;border:1px solid #a6bcb1;border-radius:5px}select{max-width:100%}button{cursor:pointer}.controls{display:flex;gap:12px;flex-wrap:wrap;align-items:center}pre{overflow:auto;max-height:420px;padding:14px;background:#edf1e9;font-size:12px}code{overflow-wrap:anywhere;font-size:12px}.cards{display:flex;gap:12px;flex-wrap:wrap}.card{padding:10px;border:1px solid #9fb5a8;background:#fbfdf5;min-width:110px}.stripe{height:10px;background:var(--purple);margin:5px 0}.orange{background:var(--orange)}.absent{background:repeating-linear-gradient(45deg,#eee 0px,#eee 5px,#fff 5px,#fff 10px)}.proof{table-layout:fixed}.proof th:nth-child(1){width:5%}.proof th:nth-child(2){width:43%}.proof th:nth-child(3){width:33%}.proof th:nth-child(4){width:19%}.math{display:block;overflow-x:auto;max-width:100%;padding:3px 0}.proof tr.active{background:#e8f4e8}.diagram svg{min-width:680px;width:100%;max-height:250px}.diagram [data-slot]{cursor:pointer}details{margin:12px 0}#fatal{color:#9d332b;font-weight:bold}@media(max-width:760px){main{padding:14px}.panel{padding:16px}.grid{grid-template-columns:1fr}.proof{min-width:760px}}
</style><script>window.MathJax={tex:{inlineMath:[['\\(','\\)']],displayMath:[['\\[','\\]']]},options:{skipHtmlTags:['script','style','pre','code']},startup:{ready(){MathJax.startup.defaultReady();window.__mathReady=MathJax.startup.promise;}}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-chtml.js"></script></head><body><main>
<nav><a href="ranked-arithmetic-v1.html">Previous rank experiment</a><a href="#results">Results</a><a href="#families">Learned families</a><a href="#reader">Proof reader</a><a href="#evidence">Evidence</a></nav>
<p class="eyebrow">GCTS research · warm reusable proof clusters</p><h1>Can a learned family<br>guide the next proof?</h1><p class="lede">One automatically found donor proof supplies term and context patterns. Its clusters attach through formula receptors. Concrete expansions are checked against each target's complete primitive inventory; they change search order while preserving every fallback candidate.</p><div id="fatal"></div><div id="outcome" class="note"></div>
<section id="results" class="panel"><h2>Actual outcomes</h2><div id="results-table" class="scroll"></div><p class="muted">The seen case overlaps training. The other two are prospectively declared changes of term/context shape, with the same addition-zero axiom and fixed line-to-slot mapping. A found proof belongs to its actual finder. UNKNOWN is unresolved; finite exhaustion concerns only this declared grammar and bound.</p><details><summary>Scientific and native process statuses</summary><div id="phases" class="scroll"></div></details></section>
<section id="families" class="panel"><h2>Inspect a family and its receptors</h2><div id="learning"></div><div class="controls"><select id="case"></select><select id="family-select"></select><select id="cluster-select"></select><select id="instance"></select></div><div id="case-goal"></div><div id="family"></div><div id="cluster" class="diagram"></div><div id="receptors"></div><details><summary>Exact parameter bindings, primitive members and expanded candidate</summary><pre id="instance-json"></pre></details><p class="muted">These are concrete admitted candidate expansions, not a universally proved schematic axiom. Missing receptor owners impose consistent literal demands; they do not certify an extension. The instance picker is a deterministic bounded projection; every original is in the archive.</p></section>
<section id="reader" class="panel"><p class="eyebrow">Actual complete native-checked outputs</p><h2>Read the expanded proof</h2><div class="controls"><select id="proof"></select><label><input type="checkbox" id="literal"> Literal names</label><button id="download">Download native proof JSON</button></div><div id="proof-scope"></div><div id="proof-goal"></div><div id="slots" class="diagram"></div><div id="proof-table" class="scroll"></div><details><summary>Unchanged AST and exact slot maps</summary><pre id="proof-json"></pre></details><p class="muted">Square cards depict anchored symbolic slot owners. Orange is activity; purple is the formula-ID layer. Arrows are actual earlier-slot formula requests. A center has integer capacity one. These are semantic point markings, not Euclidean shapes or a single uniform Wang palette.</p></section>
<section class="grid"><div class="panel"><h2>Assessment</h2><div id="assessment"></div><p>No reinforcement learning is used. The library's information is also available to the direct same-library control. A branch reduction or one successful run does not establish a distinct GCTS advantage or a speed improvement. Term/context parameters and rooted clusters are learned; arbitrary slot relocation and alpha-renaming are outside this pilot.</p><p>This is a finite addition-zero/equality-congruence fragment, without PA induction. It establishes no new Euclidean/Hilbert geometry result or universal theorem-family validity.</p></div><div class="panel"><h2>All costs count</h2><div id="costs" class="scroll"></div><p class="muted">Warm donor authentication, fresh donor checks, learning, family qualification, full target compilation/native ZERO gates, rank acquisition, instance admission, policy setup, engine, semantic assurance and M/N/B validation are retained. Worker and observer intervals overlap. Native high-water RSS is separate from potentially missed polling peaks.</p></div></section>
<section class="panel"><h2>Qualification and limits</h2><div id="qualification"></div><details><summary>Exact counts, controls, limits and phase costs</summary><pre id="metadata"></pre></details><p class="muted">Tiny qualification uses actual intermediate producer graphs and independent reconstruction. Large target runs use complete semantic event/endpoints assurance when admitted; intermediate producer tables are not observed. Complete emitted payload does not turn an UNKNOWN search into a proof or an absence certificate.</p></section>
<!-- RECEPTOR_FAMILIES_ARCHIVE_LINK -->
<section id="evidence" class="panel"><h2>Inspect the evidence</h2><p><a href="receptor-families-data-v1.json.gz">Reader data</a> · <a href="receptor-families-evidence-v1-manifest.json">Archive manifest</a> · <a href="receptor-families-evidence-v1-part-001.zip">First archive volume</a></p><p>All original Sources, protocols, native process records, raw events, refusals, concrete instances and certificates remain in the complete archive.</p><details><summary>Saved audit and exact input pins</summary><pre id="provenance"></pre></details></section>
</main><script>'use strict';const $=x=>document.getElementById(x),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),tex=x=>String(x).replace(/[\\{}_$%&#^~]/g,c=>'\\'+c),math=x=>'<span class="math">\\('+x+'\\)</span>',num=x=>x==null?'not recorded':Number(x).toLocaleString(undefined,{maximumFractionDigits:4});let D,P,A={},literal=false,selected=null,queue=Promise.resolve();
function typeset(el){queue=queue.then(async()=>{while(!window.MathJax||!MathJax.typesetPromise)await new Promise(r=>setTimeout(r,25));await MathJax.startup.promise;if(el.isConnected){MathJax.typesetClear([el]);await MathJax.typesetPromise([el]);}}).catch(e=>{$('fatal').textContent='Math error: '+e.message;});}
async function load(){const r=await fetch('receptor-families-data-v1.json.gz');if(!r.ok)throw Error('Reader data HTTP '+r.status);const b=new Uint8Array(await r.arrayBuffer());return JSON.parse(b[0]===31&&b[1]===139?await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).text():new TextDecoder().decode(b));}
const sym=x=>literal?x:(A[x]??x);function term(t){if(t[0]==='_term')return '\\mathsf{'+tex(t[1])+'}';if(t[0]==='_hole')return '\\square';if(t[0]==='_ctx')return '\\mathcal{C}_{'+tex(t[1])+'}['+term(t[2])+']';if(t[0]==='var')return tex(sym(t[1]));const n=sym(t[1]);return (n==='zero'?'0':'\\operatorname{'+tex(n)+'}')+(t[2].length?'('+t[2].map(term).join(',')+')':'');}
function formula(f){switch(f[0]){case'eq':return term(f[1])+'='+term(f[2]);case'pred':return '\\operatorname{'+tex(sym(f[1]))+'}'+(f[2].length?'('+f[2].map(term).join(',')+')':'');case'all':return '\\forall '+tex(sym(f[1]))+'\\,('+formula(f[2])+')';case'imp':case'and':case'or':return '('+formula(f[1])+({imp:'\\Rightarrow ',and:'\\land ',or:'\\lor '}[f[0]])+formula(f[2])+')';case'not':return '\\neg '+formula(f[1]);case'bot':return '\\bot';default:return '\\text{'+tex(JSON.stringify(f))+'}';}}
const refs=l=>l.rule==='mp'?[l.antecedent,l.implication]:l.rule==='generalize'?[l.source]:[];function english(l){switch(l.rule){case'axiom':return 'Use the named hypothesis '+l.name+'.';case'refl':return 'A term equals itself.';case'instantiate':return 'Use universal instantiation at the recorded term. This line states the checked implication schema.';case'eq_subst':return 'Use equality substitution in the recorded formula context.';case'distribute':return 'Use quantified distribution with its checked side conditions.';case'tautology':return 'Use a checked propositional tautology.';case'mp':return 'From line '+(l.antecedent+1)+' and the implication on line '+(l.implication+1)+', infer its consequent.';case'generalize':return 'Universally quantify '+sym(l.variable)+' in line '+(l.source+1)+' under the closed hypothesis context.';default:return l.rule;}}
function table(headers,rows){return '<table><thead><tr>'+headers.map(h=>'<th>'+esc(h)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(c=>'<td>'+c+'</td>').join('')+'</tr>').join('')+'</tbody></table>';}
function diagram(slots,rows,highlight=null){const w=Math.max(650,(Math.max(-1,...slots.map(x=>x.slot))+1)*112),byid=new Map(rows.map(r=>[r.id,r]));let s='<svg viewBox="0 0 '+w+' 215" role="img" aria-label="Actual symbolic slot owners and remote formula requests">';for(const x of slots){const c=JSON.parse(x.cid);for(const j of c[3]){const a=55+x.slot*112,b=55+j*112;s+='<path d="M'+a+',108 Q'+((a+b)/2)+',15 '+b+',108" fill="none" stroke="#a389ba" stroke-width="1.5"/><circle cx="'+b+'" cy="108" r="3" fill="#8c70a6"/>';}}for(const x of slots){const a=9+x.slot*112,r=byid.get(x.cid),active=x.native_line_index_or_null===highlight&&highlight!==null;s+='<g data-slot="'+x.slot+'"><rect x="'+a+'" y="108" width="94" height="95" fill="'+(active?'#e1f1df':'#fbfdf5')+'" stroke="#7d9d8c" stroke-width="'+(active?3:1)+'"/><text x="'+(a+8)+'" y="126" font-size="12">slot '+x.slot+' · '+esc(JSON.parse(x.cid)[1])+'</text><rect x="'+(a+8)+'" y="136" width="78" height="10" fill="'+(x.active?'#c68c43':'#dce3d9')+'"/><rect x="'+(a+8)+'" y="153" width="78" height="10" fill="#b39acb"/><text x="'+(a+8)+'" y="181" font-size="10">active '+x.active+' · FID '+x.formula_id+'</text><text x="'+(a+8)+'" y="195" font-size="10">t '+esc(r?.t?.[0]?.[1]??'?')+' at own center</text></g>';}return s+'</svg>';}
function showProof(){P=D.proofs.find(p=>p.id===$('proof').value);selected=null;if(!P){$('proof-scope').innerHTML='<p class="note warning">No native-admitted proof is attached to this record. UNKNOWN and refused methods have no invented proof.</p>';for(const id of ['proof-goal','slots','proof-table'])$(id).innerHTML='';$('proof-json').textContent='';$('download').disabled=true;return;}A=P.aliases;literal=$('literal').checked;$('download').disabled=false;const label=P.role==='POINT_SEARCH'?'Actual GCTS point-search proof':P.role==='SPECIALIZED_CONTROL'?'Conventional AND/OR proof — separate control':'Direct same-library expansion — separate warm control';$('proof-scope').innerHTML='<p class="note"><b>'+esc(label)+'</b> · '+esc(P.id)+' · '+P.lines+' native-checked lines.</p>';$('proof-goal').innerHTML=math(formula(P.statement.goal))+'<details><summary>Exact hypotheses and display-only symbol aliases</summary><pre>'+esc(JSON.stringify({theory:P.statement.theory,aliases:P.aliases},null,2))+'</pre></details>';$('proof-table').innerHTML='<table class="proof"><thead><tr><th>Line</th><th>Decoded assertion</th><th>Natural reading</th><th>Rule / earlier lines</th></tr></thead><tbody>'+P.proof.map((l,i)=>'<tr id="line-'+i+'"><td><button data-line="'+i+'">'+(i+1)+'</button></td><td>'+math(formula(l.formula))+'</td><td>'+esc(english(l))+'</td><td><code>'+esc(l.rule)+'</code><br>'+refs(l).map(j=>'line '+(j+1)).join(', ')+'<br>slot '+P.native_to_slot[i]+'</td></tr>').join('')+'</tbody></table>';$('proof-json').textContent=JSON.stringify({proof:P.proof,slots:P.slots,reference_mapping:P.reference_mapping,proof_dag:P.proof_dag,selected_rows:P.selected_rows},null,2);const bind=()=>{for(const g of $('slots').querySelectorAll('[data-slot]'))g.onclick=()=>choose(P.slots.find(x=>x.slot===+g.dataset.slot).native_line_index_or_null);};const choose=i=>{selected=i;for(const r of $('proof-table').querySelectorAll('tbody tr'))r.classList.toggle('active',r.id==='line-'+i);$('slots').innerHTML=diagram(P.slots,P.selected_rows,selected);bind();};for(const b of $('proof-table').querySelectorAll('[data-line]'))b.onclick=()=>choose(+b.dataset.line);$('slots').innerHTML=diagram(P.slots,P.selected_rows);bind();typeset($('reader'));}
function topology(c){if(!c)return '';const all=[...c.members,...c.receptor_indices],w=Math.max(650,(Math.max(...all)+1)*112);let s='<svg viewBox="0 0 '+w+' 205" role="img" aria-label="Actual learned donor-cluster topology">';for(const e of [...c.internal_edges,...c.external_edges]){const a=55+e[1]*112,b=55+e[0]*112;s+='<path d="M'+a+',108 Q'+((a+b)/2)+',18 '+b+',108" fill="none" stroke="#9c80b6"/><circle cx="'+b+'" cy="108" r="3" fill="#9c80b6"/>';}for(const j of [...new Set(all)].sort((a,b)=>a-b)){const own=c.members.includes(j),a=9+j*112;s+='<rect x="'+a+'" y="108" width="94" height="78" fill="'+(own?'#f4f8ec':'#fffef8')+'" stroke="#8caa96" '+(own?'':'stroke-dasharray="5 4"')+'/><text x="'+(a+7)+'" y="128" font-size="11">'+(own?'member':'receptor')+' slot '+j+'</text><rect x="'+(a+7)+'" y="140" width="80" height="10" fill="#b39acb"/><text x="'+(a+7)+'" y="172" font-size="11">'+(j===c.root?'cluster root':own?'donor topology':'open premise')+'</text>';}return s+'</svg>';}
function showInstance(){const c=D.cases.find(c=>c.id===$('case').value);A=c.aliases;literal=false;$('case-goal').innerHTML='<h3>'+esc(c.id)+' · '+esc(c.overlap)+'</h3>'+math(formula(c.statement.goal));const f=D.learning?.families.find(f=>f.id===$('family-select').value),cl=D.learning?.clusters.find(x=>x.id===$('cluster-select').value),i=c.instances.find(i=>i.id===$('instance').value);$('family').innerHTML=(f?'<div class="grid"><div><b>Actual learned goal schema</b>'+math(formula(f.statement_template.goal))+'</div><div><b>Prototype term/context bindings</b><pre>'+esc(JSON.stringify(f.prototype_bindings,null,2))+'</pre></div></div>':'<p>No learned family output is available.</p>')+'<p class="muted">'+c.instance_projection.retained+' / '+c.instance_projection.total+' admitted instances shown. Family and topology selectors include the whole actual library; concrete current instances are a diversity-preserving bounded subset.</p>';$('cluster').innerHTML='<b>Actual learned donor topology</b>'+topology(cl);if(!i){$('receptors').innerHTML='<p class="note warning">No concrete current instance for this family/topology is in the displayed subset. This is not evidence that an instance is impossible. Full proposed/admitted lists are archived.</p>';$('instance-json').textContent=JSON.stringify({family:f,cluster:cl},null,2);typeset($('families'));return;}const ss=i.line_cids.map(([slot,cid])=>{const m=new Map(i.rows.find(r=>r.id===cid).m);return {slot,cid,active:+m.get('a:'+slot),formula_id:+m.get('f:'+slot),native_line_index_or_null:slot};});$('cluster').innerHTML+='<b>Actual current primitive members</b>'+diagram(ss,i.rows);$('receptors').innerHTML='<h3>Current parameter bindings</h3><pre>'+esc(JSON.stringify(i.bindings,null,2))+'</pre>'+(i.receptors.length?'<h3>Actual external formula receptors</h3>'+i.receptors.map(([j,f])=>'<div class="card">Outside slot '+j+math(formula(f))+'</div>').join(''):'<p>This cluster has no external receptors. It may be a whole expansion or a closed subcluster; inspect the actual members.</p>');$('instance-json').textContent=JSON.stringify(i,null,2);typeset($('families'));}
function instanceChoices(){const c=D.cases.find(c=>c.id===$('case').value),xs=c.instances.filter(i=>i.family_id===$('family-select').value&&i.cluster_id===$('cluster-select').value);$('instance').innerHTML=xs.map(i=>'<option value="'+i.id+'">Current instance '+esc(i.id.slice(0,12))+'</option>').join('');showInstance();}
function caseChange(){const c=D.cases.find(c=>c.id===$('case').value),i=[...c.instances].sort((a,b)=>(+!!b.receptors.length)-(+!!a.receptors.length)||b.line_cids.length-a.line_cids.length||a.id.localeCompare(b.id))[0];if(i){$('family-select').value=i.family_id;$('cluster-select').value=i.cluster_id;}instanceChoices();}
function init(){const points=D.proofs.filter(p=>p.role==='POINT_SEARCH'),controls=D.proofs.filter(p=>p.role!=='POINT_SEARCH');$('outcome').innerHTML='<b>'+points.length+' point-search certificate(s), '+controls.length+' separate-control certificate(s).</b> '+(D.proofs.length?'Certificates are grouped by the actual method and target; repeated methods are not new independent theorems.':'No target proof is admitted in this saved snapshot.');$('results-table').innerHTML=table(['Case / method','Raw / search status','Semantic / native admission','Branches / backtracks','Recorded engine / combined seconds'],D.cases.flatMap(c=>c.rows.length?c.rows.map(r=>[esc(c.id)+'<br>'+esc(r.method),esc(r.raw_status??r.search_status??'not applicable'),esc(r.semantic_status??'separate control')+'<br><b>'+esc(r.admitted_status)+'</b>',num(r.stats?.branches)+' / '+num(r.stats?.backtracks),num(r.engine?.stats?.elapsed_seconds)+' / '+num(r.costs?.engine_and_semantic_seconds??r.costs?.search_seconds??r.costs?.selection_seconds)]):[[esc(c.id),'no recorded method run',esc(c.preparation?.preparation_status??'not run'),'not recorded','not recorded']]));$('phases').innerHTML=table(['Phase / PID','Scientific status','Process / exit','Worker / observed seconds'],D.phases.map(p=>[esc(p.name)+' / '+esc(p.pid??'none'),esc(p.scientific_status??'not run'),esc(p.process_status)+' / '+esc(p.native_exit_code??'none'),num(p.costs.worker_seconds)+' / '+num(p.costs.observer_seconds)]));const l=D.learning;$('learning').innerHTML=l?'<p class="note '+(l.process_admitted&&l.result.provenance_status==='VERIFIED_PROVENANCE'?'':'warning')+'"><b>'+esc(l.status??l.result.family_status)+'</b> · independent provenance '+esc(l.result.provenance_status??'not reached')+' · '+num(l.families.length)+' families, '+num(l.clusters.length)+' rooted clusters.</p>':'<p class="note warning">No learning result is available.</p>';$('case').innerHTML=D.cases.map(c=>'<option value="'+c.id+'">'+esc(c.id)+' · '+c.instances.length+'/'+c.instance_projection.total+' displayed instances</option>').join('');$('family-select').innerHTML=(D.learning?.families??[]).map(f=>'<option value="'+f.id+'">Family '+esc(f.id.slice(0,12))+'</option>').join('');$('cluster-select').innerHTML=(D.learning?.clusters??[]).map(c=>'<option value="'+c.id+'">'+c.members.length+' members / '+c.receptor_indices.length+' receptors · '+esc(c.id.slice(0,10))+'</option>').join('');$('case').onchange=caseChange;$('family-select').onchange=instanceChoices;$('cluster-select').onchange=instanceChoices;$('instance').onchange=showInstance;caseChange();const choices=D.cases.flatMap(c=>c.rows.map(r=>({id:r.proof_id??c.id+'--'+r.method,label:c.id+' / '+r.method+' / '+r.admitted_status})));$('proof').innerHTML=choices.map(x=>'<option value="'+esc(x.id)+'">'+esc(x.label)+'</option>').join('');const first=points[0]??D.proofs[0];if(first)$('proof').value=first.id;$('proof').onchange=showProof;$('literal').onchange=showProof;showProof();$('download').onclick=()=>{if(!P)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({statement:P.statement,proof:P.proof},null,2)],{type:'application/json'}));a.download=P.id+'-native-proof.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};$('assessment').innerHTML='<p>'+num(D.cases.length)+' declared cases and '+num(D.proofs.length)+' admitted method-specific certificates. '+(points.length?'Some complete proofs were found by the point engine under actual callback/semantic/native gates.':'No target proof can currently be attributed to point search.')+'</p><p>All point methods retain the same primitive inventory, rank-marked model and scheduler. Guided methods receive warm learned expansions; the conventional AND/OR control does not. The direct control receives the same library.</p>';$('costs').innerHTML=table(['Phase','Worker seconds','Native high-water','Observed seconds'],D.phases.map(p=>[esc(p.name),num(p.costs.worker_seconds),num(p.costs.worker_maxrss)+' '+esc(p.costs.worker_maxrss_units??''),num(p.costs.observer_seconds)]));$('qualification').innerHTML='<p>Actual qualification phase: <b>'+esc(D.qualification?.status??'not run')+'</b>. Full returned counts and controls are available below.</p>';$('metadata').textContent=JSON.stringify({limits:D.limits,qualification:D.qualification,learning:D.learning?.result,case_details:D.cases.map(c=>({id:c.id,model:c.model_metadata,preparation:c.preparation_detail,rank:c.rank,admissions:c.instance_admission_counts,projection:c.instance_projection,rows:c.rows})),phase_costs:D.phases.map(p=>({name:p.name,costs:p.costs}))},null,2);$('provenance').textContent=JSON.stringify({protocol:D.protocol,audits:D.saved_data_audits,provenance:D.provenance},null,2);typeset(document.querySelector('main'));}
load().then(d=>{D=d;init();window.__readerLoaded=true;}).catch(e=>{$('fatal').textContent=e.stack??e.message;});
</script></body></html>'''


if __name__=='__main__':
    build()
