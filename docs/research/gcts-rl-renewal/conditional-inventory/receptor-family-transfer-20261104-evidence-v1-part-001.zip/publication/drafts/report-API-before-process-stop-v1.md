# Passive receptor-family reader API

Source: `publication/build_receptor_report_v1.py`. Inert until its reviewed CLI
entry point. It imports only the standard library and reads saved JSON/gzip and
byte hashes. It imports no engine, compiler, learner, checker, native kernel or
prior-run module, and performs no scientific transition, proof checking or replay.
Python AST parsing and JavaScript syntax compilation are Source checks only.

Root executes once, after full Source review and the actual saved-data audit,
using the same pinned Python with `-I -S -B`. The builder verifies executable
bytes/version/flags, current master, all frozen file refs and actual phase
custody before projecting data. Existing outputs cause refusal. Missing or
unadmitted phases remain explicit; native failures are not promoted.

## Mandatory inputs

- `protocol/frozen-protocol-v1.json`, frozen before scientific imports.
- `publication/saved-data-audit-v1.json`, exact schema
  `Receptor-family-passive-audit-v1`, status `PASS`, with the current protocol ref.
- Current actual phase artifacts at the existing Root ABI paths. Phase names are
  `qualify`, `learn`, then `prepare-` and `evaluate-` for each of `seen`,
  `unary-transfer`, `nested-transfer`.
- The unchanged declaration, preparation, rank, family/instance, native decoder,
  kernel and engine refs actually named by those results. Every consumed ref is
  physically hash checked. No expected proof or outcome is an input.

Audit `phases[]` must contain exactly those eight names, each with
`native_exit_code`, `scientific_status`, `process_clean`, `scientific_admitted`.
These are compared by canonical typed JSON to separately derived actual process
and result associations. Clean admission requires a nonnull invocation result,
complete saved JSON, status/result byte association, PID/name/protocol/log joins,
native zero exit, clean observer/guards and unchanged Source postchecks.

Audit `native_proofs[]` contains entries with IDs `<case_id>--<METHOD>` and roles
`POINT_SEARCH`, `SPECIALIZED_CONTROL` or `DIRECT_SAME_LIBRARY`. Required metadata:
`lines`, `statement_sha256`, `selected_sha256`, `proof_sha256`, `proof_ref`,
`native_ref`. Ref identity means `path`, `bytes`, `sha256` and optional `pointer`.
The exact displayed target-proof ID set must equal the audit's target-only
`native_proofs` set; no audited target proof may be silently omitted.

## Exclusive outputs

1. `report/receptor-families-v1.html`, standalone reader HTML/JS with the established
   MathJax CDN and serialized startup/typesetting queue.
2. `report/receptor-families-data-v1.json.gz`, deterministic gzip (`mtime=0`) of
   canonical ASCII JSON plus newline. Browser loading supports both raw gzip and
   a response already decompressed by its server.
3. `report/build-receipt-v1.json`, schema `Receptor-family-report-build-v1`, status
   `BUILT_FROM_ADMITTED_SAVED_DATA`; keys `protocol`, `renderer_source`,
   `outputs:{main,data}`, `artifact_pins`, `counts:{cases,proofs}`. These refs use
   task-relative paths, byte counts and SHA-256.

Public data schema: `Receptor-family-report-data-v1`; status
`SAVED_DATA_ADMITTED_WITH_EXPLICIT_SCOPES`. Keys are `protocol`, `limits`,
`phases`, `learning`, `cases`, `proofs`, `qualification`, `saved_data_audits`
and `provenance`. `saved_data_audits` is an array of `{ref,status}`;
`provenance.artifact_pins` is the exact consumed local-byte ledger. External
runtime/master pins are separately recorded under `provenance.external_pins`.

Phase rows retain actual process/scientific statuses, admission flags, PID,
invocation/observer records, refs and worker/observer/RSS costs. They do not infer
an unobserved native exit. Worker high-water and polling observations remain
separate. A completed workflow result is not automatically a successful proof.

## Reader projections

`learning` preserves the actual result, provenance/qualification receipts,
candidate status, costs and limits. All actual learned family goal schemas,
parameter/prototype bindings and rooted cluster topologies are retained in its
selectors. A failed process can expose an actual saved candidate prefix with an
explicit unadmitted label; this never activates it or manufactures an outcome.

`cases[]` retains the original statement, declaration-derived display aliases,
training-overlap description, preparation/rank/family metadata and actual method
rows. Methods are `RANK_ONLY`, `RECEPTOR_GUIDED`, `FAMILY_GUIDED`,
`CONVENTIONAL_AND_OR`, `DIRECT_SAME_LIBRARY`. Raw engine, semantic and native
admission statuses remain distinct. Existing raw prefixes from an interrupted
evaluation process may be shown as `UNADMITTED_NATIVE_PROCESS_PREFIX`, without a
proof or claimed absence.

An honest unadmitted raw UNKNOWN prefix may lack its model digest. The reader
preserves null, exposes `PARTIAL_DIGEST_NOT_RECORDED`, and invents no binding.
Available raw/C digests are compared. Raw SAT and every VERIFIED proof route
retain mandatory model digest and complete semantic/native acceptance gates;
a missing digest cannot become an admitted proof.

Each case exposes at most 64 actual independently admitted instances. The
deterministic selector greedily covers new family/cluster IDs, ties by literal
instance ID. Exact retained/total family, cluster and instance counts and the
selection rule are recorded. The whole learned family/cluster topology library
remains selectable even when no matching concrete instance is in this subset;
that absence is never described as impossibility. Full proposed/admitted lists,
all receipts and originals remain in the archive. Selected instances preserve
their exact entire candidate expansion and actual primitive rows/receptors.

`proofs[]` contains only clean actual method positives with both saved native
decoders agreeing on every semantic projection field and a fresh whole B receipt.
Point positives additionally join raw SAT, complete C admission and exact selected
IDs. Direct/conventional outputs remain separately attributed. Each record holds
the exact statement, native AST, slot/reference/DAG maps, selected literal rows,
audit metadata/refs and display-only aliases. Nothing rewrites the certificate.
The UI translates actual lines to LaTeX and rule-specific English; its square
slot cards show activity/formula layers and actual earlier-slot dependencies.
The user can download the unchanged native proof as JSON. Unresolved choices
clear the proof and slot diagram.

The UI states warm reuse, fixed donor line-to-slot mapping, target overlap and
the limits of missing receptor consistency. It claims neither universal family
soundness, a uniform Wang palette, reinforcement learning, PA induction nor
performance superiority. All preparation/learning/admission/policy/search/native
cost records are available; overlapping process intervals are not added into a
false independent timing comparison.

The central scope limitation is prominent beside the lede and reiterated in
proof-finder labels and assessment: this L emits subclusters only after an entire
instantiated eight-line donor proof maps to the current primitive catalogue;
X checks that whole expansion's point cover. Matching already produces a
complete proof candidate. Guided outputs are therefore attributed as
"GCTS reconstruction under learned complete-expansion guidance", not independent
argument discovery or open-receptor composition. `RANK_ONLY` has no library.
The direct same-library control is decisive; separately learned partial lemmas
being composed through open receptors has not yet been tested in this v1.

The results table separately displays policy setup, E+C/search/selection, the
sum of available M/N/B component seconds, and the sum of all recorded
nonoverlapping per-method cost entries. In particular the direct same-library
method includes actual native projection/checking costs, not selection alone.
Absent entries stay unrecorded. These are component subtotals, not end-to-end
timings: additional proof-certificate persistence and Root aggregation are
excluded. Common donor/learning/qualification/preparation/rank/instance admission
records and whole phase process costs are exposed separately as full JSON.

## Publication integration

The single marker is `<!-- RECEPTOR_FAMILIES_ARCHIVE_LINK -->`; reader anchor
`#reader`, evidence anchor `#evidence`. Known archive names are
`receptor-families-evidence-v1-part-NNN.zip` and
`receptor-families-evidence-v1-manifest.json`. The predecessor is
`ranked-arithmetic-v1.html`. Root/packager inject only the bounded archive-link
block after this builder runs, preserving its original HTML and receipt chain.
This builder performs no package, Git, network or publication operation.
