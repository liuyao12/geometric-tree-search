"""Passive exact-byte archive and isolated commit preparation; never pushes.

Source-only until Root reviews this complete file. No scientific imports,
helpers, replay, source edits, primary index or primary checkout writes.
Usage: pinned Python -I -S -B FILE --prepare-links; final UI/admission;
then FILE [EXPECTED_REMOTE_MAIN]. The official GET discovers the base.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import time
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
GIT = '/private/tmp/gcts-history-publication-20261102-v1.git'
GH = '/Users/liuyao/bin/gh'
REPO = 'liuyao12/geometric-tree-search'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
BASE_URL = 'https://liuyao12.github.io/geometric-tree-search/'
MAIN = 'receptor-family-transfer-20261104-v1.html'
DATA = 'receptor-family-transfer-20261104-data-v1.json.gz'
OLD = 'ranked-arithmetic-v1.html'
MANIFEST = 'receptor-family-transfer-20261104-evidence-v1-manifest.json'
PART_STEM = 'receptor-family-transfer-20261104-evidence-v1-part-'
PACKAGE_DIR = 'package/final-v2'
INTERNAL = 'ARCHIVE-file-manifest-v1.json'
BEGIN = b'<!-- RECEPTOR_FAMILIES_ARCHIVE_LINK -->'
END = b'<!-- /RECEPTOR_FAMILIES_ARCHIVE_LINK -->'
MAX_PART = 44 * 1024 * 1024
RESERVE = 2 * 1024 * 1024
CAPTURE = 128 * 1024 * 1024
PROTOCOL = 'protocol/frozen-protocol-v1.json'
BUILDER = 'publication/build_receptor_report_v2.py'
AUDITOR = 'publication/audit_receptor_saved_data_v1.py'
BUILD = 'report/build-receipt-v2.json'
ROOT_ADMISSION = 'publication/root-publication-admission-v2.json'
UI = 'publication/local-ui-v2.json'
TRANSFER_AUDIT = 'publication/saved-data-audit-v1.json'
SOURCE_ADMISSION = 'review/root-source-admission-v1.json'
BUILD_AUTHORITY = 'review/root-passive-publication-admission-v2.json'
PRIMARY_MASTER = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
CASES = ('seen', 'unary-transfer', 'nested-transfer')
PHASES = ('qualify', 'learn') + tuple(p+'-'+c for c in CASES for p in ('prepare','evaluate'))
EXPECTED = {p:'QUALIFIED' if p=='qualify' else 'LEARNING_RECORDED' if p=='learn' else 'CASE_RECORDED' for p in PHASES}
DONOR_MANIFEST = 'input/donor-manifest-v1.json'
PROTOCOL_PIN = dict(bytes=18141, sha256='f7236f28cd3f8e74aa99c65d1d299284bb6067b309b4ef603ddca0128fd1aeae')
METHOD_ROLES = dict(RANK_ONLY='POINT_SEARCH',RECEPTOR_GUIDED='POINT_SEARCH',FAMILY_GUIDED='POINT_SEARCH',
                   CONVENTIONAL_AND_OR='SPECIALIZED_CONTROL',DIRECT_SAME_LIBRARY='DIRECT_SAME_LIBRARY')
README = r'''Warm receptor-family transfer with concrete primitive/native admission.

Download every receptor-family-transfer-20261104-evidence-v1-part-NNN.zip together with
receptor-family-transfer-20261104-evidence-v1-manifest.json and extract together. Every volume
is at most 44 MiB and contains the same complete ARCHIVE-file-manifest-v1.json.
Every original current-run path present at the cut is physically stored once.
Equal bytes at different paths remain physical copies, with no alias or remote
reference replacing originals. Sizes/SHA256, CRCs, exact member/path sets and
physical volume hashes are verified before isolated commit preparation.

All current Sources/inputs/reference/plan/reviews, raw outcomes/endpoints/events,
UNKNOWN/refusal/failure records, native receipts, library/cluster/proposal/state
checks, logs, local paths, reader/tool Sources and planning are included. The
full declared input/donor physical closure is included under its original paths.
One authorized published automatically found proof is training input, not a new
target proof. Other historical lane references retained inside an original
whole-phase record are metadata only; the donor manifest defines the exact
copied/authenticated closure. Predecessor archives are separately linked.

Only generated package/ outputs are excluded. The preserved original render
and changed predecessor-reader backlink are included before the cut. Later
index/prepared/push/Pages/live receipts are postcut custody, not claimed inside
their own earlier archive. Full current evidence, logs and local paths are
user-approved for this existing public destination; no new audience is created.

Serve the extracted directory and open report/receptor-family-transfer-20261104-v1.html.
Current eight process positions, donor authentication, empirical library
provenance, concrete instance checks, state compatibility and final native
acceptance are separate gates. A workflow word is not proof success. Read
actual saved statuses before drawing conclusions. Complete emitted payload may
still be only an UNKNOWN search prefix; a refused proposal is not a negative.

Guidance only orders current legal candidates and retains complete primitive
fallback under the reference global scheduler and rollback. Literal learned
term/context families keep fixed donor line-to-slot mapping in this version.
Their provenance is not universal schematic soundness. Shared placements count
once; missing receptor owners are literal demands, not extension certificates.
Direct same-library expansion and conventional AND/OR are separately attributed
controls, not GCTS search. No winner, new theorem, speed advantage, RL gain,
full PA/induction or single universal Wang set is assumed. All preparation,
learning, checking, proposal and native-assurance costs remain relevant.
The larger research program remains ACTIVE.
'''.encode('ascii')


def need(condition, reason):
    if not condition:
        raise AssertionError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def stream_pin(stream):
    size, digest = 0, hashlib.sha256()
    for block in iter(lambda: stream.read(1048576), b''):
        size += len(block)
        digest.update(block)
    return dict(bytes=size, sha256=digest.hexdigest())


def pin(path):
    with path.open('rb') as stream:
        return stream_pin(stream)


def relative(name):
    need(type(name) is str and name and '\\' not in name and '\0' not in name, 'RELATIVE_PATH_TEXT')
    value = PurePosixPath(name)
    need(not value.is_absolute() and all(p not in ('', '.', '..') for p in value.parts)
         and value.as_posix() == name, 'CANONICAL_RELATIVE_PATH:' + name)
    return name


def local(name):
    path = ROOT / relative(name)
    need(not path.is_symlink() and path.resolve().is_relative_to(ROOT), 'TASK_CONTAINMENT:' + name)
    return path


def reference(name):
    return dict(path=name, **pin(local(name)))


def exact(reference_value):
    need(type(reference_value) is dict and {'path', 'bytes', 'sha256'} <= set(reference_value), 'FILE_REFERENCE')
    need(type(reference_value['bytes']) is int and reference_value['bytes'] >= 0, 'NATIVE_FILE_SIZE')
    need(type(reference_value.get('complete_json', True)) is bool, 'CAPTURE_COMPLETENESS_TYPE')
    need(wire(pin(local(reference_value['path']))) == wire({k: reference_value[k] for k in ('bytes', 'sha256')}),
         'EXACT_FILE_BYTES:' + reference_value['path'])


def load(name):
    path = local(name)
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as stream:
        raw = stream.read(CAPTURE + 1)
    need(len(raw) <= CAPTURE, 'JSON_CAPTURE_LIMIT:' + name)
    return json.loads(raw)


def owned(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        need(not path.is_symlink() and path.read_bytes() == raw, 'PRESERVE_DIFFERENT_EXISTING_BYTES:' + str(path))
    else:
        with path.open('xb') as stream:
            stream.write(raw)


def refs_in(value, found=None):
    found = {} if found is None else found
    if type(value) is dict:
        if {'path', 'bytes', 'sha256'} <= set(value) and type(value['path']) is str and not value['path'].startswith('/'):
            exact(value)
            found[value['path']] = {k: value[k] for k in ('path', 'bytes', 'sha256')}
        for child in value.values():
            refs_in(child, found)
    elif type(value) is list:
        for child in value:
            refs_in(child, found)
    return found


def verify_donor_closure():
    manifest=load(DONOR_MANIFEST)
    need(manifest['schema']=='Receptor-donor-evidence-v1' and manifest['namespace']=='input/donor',
         'DECLARED_DONOR_NAMESPACE')
    need(manifest['source_url']==BASE_URL+PREFIX+OLD,'SAME_PUBLISHED_DONOR_DESTINATION')
    members=manifest['files'];need(type(members) is list and members,'FULL_DONOR_MANIFEST')
    names=[]
    for entry in members:
        name=relative(entry['path']);names.append(name);exact(dict(entry,path='input/donor/'+name))
    need(names==sorted(set(names)) and manifest['proof'] in names,'SORTED_UNIQUE_DONOR_PROOF_CLOSURE')
    actual=[]
    for path in local('input/donor').rglob('*'):
        need(not path.is_symlink(),'NO_DONOR_SYMLINK')
        if path.is_file():actual.append(path.relative_to(local('input/donor')).as_posix())
    need(sorted(actual)==names,'EXACT_ALL_PHYSICAL_DONOR_MEMBERS')
    return dict(manifest=reference(DONOR_MANIFEST),physical_files=len(names),proof='input/donor/'+manifest['proof'],
        scope='Every declared copied donor member authenticated. Other lane refs inside retained historical values are metadata, not extra copied/consumed target proofs.')


def verify_protocol():
    need(wire(pin(local(PROTOCOL))) == wire(PROTOCOL_PIN), 'EXACT_FROZEN_PROTOCOL')
    protocol = load(PROTOCOL)
    need(protocol['schema'] == 'Receptor-family-protocol-v1'
         and protocol['status'] == 'FROZEN_BEFORE_SCIENTIFIC_IMPORTS', 'FROZEN_PROTOCOL_SCHEMA_STATUS')
    need(local(PROTOCOL).read_bytes() == wire(protocol), 'CANONICAL_PROTOCOL_FILE')
    admission = load(SOURCE_ADMISSION)
    need(admission['schema'] == 'Receptor-root-source-admission-v1'
         and admission['status'] == 'PASS_SOURCE_REVIEW_BEFORE_FREEZE', 'HISTORICAL_SOURCE_ADMISSION')
    names = {SOURCE_ADMISSION}
    for folder in ('source', 'reference', 'input', 'plan'):
        for path in (ROOT / folder).rglob('*'):
            need(not path.is_symlink(), 'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix != '.pyc' and '__pycache__' not in path.parts, 'NO_FROZEN_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for entry in admission['reviewed']:
        exact(entry)
        names.add(entry['path'])
    actual = [reference(name) for name in sorted(names)]
    need(wire(actual) == wire(protocol['files']) and bool(actual), 'EXACT_COMPLETE_DYNAMIC_FROZEN_FILE_SET')
    executable = Path(sys.executable).resolve()
    runtime = dict(executable=dict(path=str(executable), **pin(executable)), version=sys.version,
                   isolated=sys.flags.isolated, no_site=sys.flags.no_site, dont_write_bytecode=sys.dont_write_bytecode)
    need(wire(runtime) == wire(protocol['runtime']) and sys.flags.isolated == sys.flags.no_site == 1
         and sys.dont_write_bytecode is True, 'PINNED_ISOLATED_RUNTIME')
    need(wire(dict(path=str(PRIMARY_MASTER), **pin(PRIMARY_MASTER))) == wire(protocol['master']), 'CURRENT_MASTER_BYTES')
    need(wire(pin(PRIMARY_MASTER)) == wire(pin(local('reference/basic-tiling-algorithm.md'))), 'MASTER_REFERENCE_COPY')
    need(protocol['phases'] == list(PHASES) and wire(protocol['admitted_statuses']) == wire(EXPECTED), 'EXACT_DECLARED_PHASES')
    need([c['id'] for c in load('input/transfer-cases-v1.json')['cases']]==list(CASES),'EXACT_FROZEN_CURRENT_CASES')
    donor=verify_donor_closure()
    phases = []
    for phase in PHASES:
        objects, receipt_refs = {}, {}
        for role in ('started', 'invocation', 'observer'):
            name = 'run/' + phase + '/' + role + '.json'
            if local(name).exists():
                value = load(name)
                need(type(value) is dict and value['phase'] == phase, 'EXACT_PHASE_ID:' + phase)
                need((type(value['pid']) is int and value['pid'] > 0) or
                     (role == 'observer' and value['pid'] is None and value['status'] == 'UNADMITTED_PROCESS'),
                     'NATIVE_PHASE_PID_OR_EXPLICIT_UNSTARTED_FAILURE:' + phase)
                objects[role] = value
                receipt_refs[role] = reference(name)
        need(len({x['pid'] for x in objects.values() if x['pid'] is not None}) <= 1, 'PID_ASSOCIATION:' + phase)
        started, invocation, observer = [objects.get(k) for k in ('started', 'invocation', 'observer')]
        if started is not None:
            need(wire(started['protocol']) == wire(reference(PROTOCOL)), 'STARTED_PROTOCOL:' + phase)
        if observer is not None:
            need(observer['native_exit_code'] is None or type(observer['native_exit_code']) is int, 'ACTUAL_NATIVE_EXIT_TYPE')
            need(observer['log']['path'] == 'run/' + phase + '/stdout.log', 'OWNED_LOG_PATH:' + phase)
            exact(observer['log'])
        result = None
        if invocation is not None and invocation.get('result') is not None:
            result_ref = invocation['result']
            need(result_ref['path'] == 'data/' + phase + '/result.json', 'EXACT_RESULT_PATH:' + phase)
            exact(result_ref)
            if result_ref.get('complete_json') is True:
                result = load(result_ref['path'])
                need(type(result) is dict and type(result.get('status')) is str, 'COMPLETE_SCIENCE_RESULT:' + phase)
                need(invocation['scientific_status'] == result['status'], 'ACTUAL_SCIENTIFIC_STATUS_JOIN:' + phase)
                refs_in(result)
                receipt_refs['result'] = reference(result_ref['path'])
        clean = bool(len(objects) == 3 and result is not None
            and observer['status'] == 'TERMINAL' and type(observer['native_exit_code']) is int
            and observer['native_exit_code'] == 0 and invocation['status'] == 'COMPLETE'
            and invocation['error_type'] is None
            and all(observer[k] is None for k in ('guard_reason', 'observer_error', 'reap_error', 'postcheck_error'))
            and invocation['postcheck_error'] is None
            and observer['frozen_postcheck'] == invocation['frozen_postcheck'] == protocol['status'])
        science = result['status'] if result is not None else None
        admitted = clean and science == protocol['admitted_statuses'][phase]
        phases.append(dict(name=phase, process_clean=clean, scientific_admitted=admitted,
            scientific_status=science, native_exit_code=None if observer is None else observer['native_exit_code'],
            pid=None if not objects else next(iter(objects.values()))['pid'], refs=receipt_refs))
    return dict(protocol=reference(PROTOCOL), frozen_files=len(actual), phases=phases,donor=donor,
                scope='Actual eight phase positions and separately declared training donor; missing, failed, resource or UNKNOWN records never imply scientific admission.')


def audit_gates():
    outcomes = load(TRANSFER_AUDIT)
    need(outcomes['schema'] == 'Receptor-family-passive-audit-v1'
         and outcomes['status'] == 'PASS', 'PASSIVE_TRANSFER_GATE')
    need(wire(outcomes['protocol']) == wire(reference(PROTOCOL)), 'AUDIT_PROTOCOL_ASSOCIATION')
    # Only the explicit current artifact ledger is authoritative. In particular,
    # unretained other-lane refs inside copied historical values are not current
    # file references and must not be recursively relabelled as authenticated.
    need(type(outcomes['artifact_pins']) is list,'AUDIT_CURRENT_ARTIFACT_LEDGER')
    for entry in outcomes['artifact_pins']:exact(entry)
    actual = verify_protocol()
    phases = {x['name']: x for x in outcomes['phases']}
    need(len(phases) == len(outcomes['phases']) == len(PHASES) and set(phases) == set(PHASES), 'ALL_AUDITED_PHASE_POSITIONS')
    for phase in actual['phases']:
        audited = phases[phase['name']]
        for key in ('pid','process_clean', 'scientific_admitted', 'scientific_status', 'native_exit_code'):
            need(wire(audited[key]) == wire(phase[key]), 'AUDIT_ACTUAL_PHASE_ASSOCIATION:' + phase['name'] + ':' + key)
    need(type(outcomes['native_proofs']) is list, 'ACTUAL_NATIVE_PROOF_COLLECTION')
    return dict(receipt=reference(TRANSFER_AUDIT), phases=actual['phases'],
                donor=actual['donor'],scope='Audit current native-proof/phase data; empirical library provenance is not universal soundness.')


def collapsed_archive_region(raw):
    need(raw.count(BEGIN) == 1 and raw.count(END) <= 1, 'ONE_ARCHIVE_MARKER_REGION')
    if END not in raw:
        return raw
    left, tail = raw.split(BEGIN)
    _, right = tail.split(END)
    return left + BEGIN + right


def verify_report():
    authority = load(BUILD_AUTHORITY)
    need(authority['schema'] == 'Root-passive-publication-admission-v1'
         and authority['status'] == 'PASS_SOURCE_READ_AND_SAVED_DATA_AUDIT_BEFORE_BUILD', 'ROOT_PASSIVE_BUILD_AUTHORITY')
    refs_in(authority)
    receipt = load(BUILD)
    need(receipt['schema'] == 'Receptor-family-report-build-v1'
         and receipt['status'] == 'BUILT_FROM_ADMITTED_SAVED_DATA', 'PASSIVE_REPORT_BUILD')
    need(receipt['renderer_source']['path'] == BUILDER, 'EXACT_RENDERER_SOURCE')
    exact(receipt['renderer_source'])
    need(wire(receipt['protocol']) == wire(reference(PROTOCOL)), 'REPORT_FROZEN_PROTOCOL')
    for entry in receipt['artifact_pins']:
        exact(entry)
    need(set(receipt['outputs']) == {'main', 'data'}, 'ONLY_TWO_REPORT_OUTPUTS')
    main, data_ref = receipt['outputs']['main'], receipt['outputs']['data']
    need(main['path'] == 'report/' + MAIN and data_ref['path'] == 'report/' + DATA, 'EXACT_REPORT_PATHS')
    exact(data_ref)
    data = load(data_ref['path'])
    need(data['schema'] == 'Receptor-family-report-data-v1'
         and data['status'] == 'SAVED_DATA_ADMITTED_WITH_EXPLICIT_SCOPES', 'PUBLIC_DATA_SCHEMA_STATUS')
    need(wire(data['protocol']) == wire(receipt['protocol']), 'REPORT_PROTOCOL_PROJECTION')
    need(wire(data['provenance']['artifact_pins']) == wire(receipt['artifact_pins']), 'REPORT_ALL_ARTIFACT_PIN_ASSOCIATION')
    need([case['id'] for case in data['cases']]==list(CASES),'ALL_DECLARED_CURRENT_READER_CASES')
    audit = load(TRANSFER_AUDIT)
    need(any(wire(item['ref']) == wire(reference(TRANSFER_AUDIT))
             and item['status'] == audit['status'] for item in data['saved_data_audits']), 'REPORT_ACTUAL_SAVED_AUDIT')
    actual_proofs = {x['id']: x for x in audit['native_proofs']}
    need(len(actual_proofs) == len(audit['native_proofs']), 'UNIQUE_NATIVE_PROOF_AUDIT_IDS')
    need(len(data['proofs']) == len({x['id'] for x in data['proofs']})
         and {x['id'] for x in data['proofs']} == set(actual_proofs), 'EXACT_PUBLIC_NATIVE_PROOF_COLLECTION')
    for proof in data['proofs']:
        admitted_proof = actual_proofs[proof['id']]
        method=proof['method']
        need(method in METHOD_ROLES and proof['role']==METHOD_ROLES[method]==admitted_proof['role']
             and proof['id'] in {c+'--'+method for c in CASES}, 'EXACT_PROOF_ROLE_AND_ADMISSION')
        need(type(admitted_proof['lines']) is int and admitted_proof['lines'] == len(proof['proof'])
             and proof['lines'] == admitted_proof['lines'], 'WHOLE_NATIVE_PROOF_LINES')
        need(proof['statement_sha256'] == admitted_proof['statement_sha256'] == sha(wire(proof['statement']))
             and proof['selected_sha256'] == admitted_proof['selected_sha256'], 'PROOF_STATEMENT_AND_SELECTION_BINDINGS')
        need(proof['proof_sha256']==admitted_proof['proof_sha256']==sha(wire(proof['proof'])),'WHOLE_NATIVE_PROOF_HASH')
        for key in ('proof_ref', 'native_ref'):
            need(wire({k:proof[key].get(k) for k in ('path','bytes','sha256','pointer')})
                 ==wire({k:admitted_proof[key].get(k) for k in ('path','bytes','sha256','pointer')}), 'EXACT_NATIVE_PROOF_ARTIFACT:' + key)
            exact(proof[key])
            need(proof[key].get('complete_json', True) is True, 'COMPLETE_NATIVE_PROOF_ARTIFACT')
        stored_proof = load(proof['proof_ref']['path'])
        pointer = proof['proof_ref'].get('pointer')
        need(pointer in (None, '/proof'), 'DECLARED_NATIVE_PROOF_POINTER')
        if pointer == '/proof':
            need(type(stored_proof) is dict and wire(stored_proof['statement']) == wire(proof['statement']),
                 'SAVED_DECODED_PROOF_ORIGINAL_STATEMENT')
            stored_proof = stored_proof['proof']
        need(wire(stored_proof) == wire(proof['proof']), 'PUBLIC_PROOF_IS_SAVED_WHOLE_PROOF')
        need(sha(wire(sorted(row['id'] for row in proof['selected_rows']))) == proof['selected_sha256'],
             'PUBLIC_LITERAL_SELECTED_ROWS_HASH')
        native = load(proof['native_ref']['path'])
        need(native['status'] == 'VERIFIED' and type(native['checked_lines']) is int
             and native['checked_lines'] == len(proof['proof']), 'SAVED_WHOLE_NATIVE_RECEIPT')
    phases = {x['name']: x for x in data['phases']}
    audited_phases = {x['name']: x for x in audit['phases']}
    need(len(phases) == len(data['phases']) == len(PHASES) and set(phases) == set(PHASES), 'ALL_EIGHT_CURRENT_READER_PHASE_POSITIONS')
    for phase in PHASES:
        for key in ('pid','scientific_status', 'process_clean', 'native_exit_code'):
            need(wire(phases[phase][key]) == wire(audited_phases[phase][key]), 'READER_ACTUAL_PHASE_SCOPE:' + phase + ':' + key)
        need(phases[phase]['scientific_admitted'] is audited_phases[phase]['scientific_admitted'], 'READER_SCIENTIFIC_ADMISSION:' + phase)
    need(receipt['counts']['cases']==len(data['cases']) and receipt['counts']['proofs']==len(data['proofs']),'REPORT_ACTUAL_COUNT_PROJECTION')
    original = local('publication/rendered-before-archive-links-v2.html')
    before = original.read_bytes() if original.exists() else local(main['path']).read_bytes()
    need(wire(dict(bytes=len(before), sha256=sha(before))) == wire({k: main[k] for k in ('bytes', 'sha256')}), 'ORIGINAL_RENDERED_MAIN_PIN')
    current = local(main['path']).read_bytes()
    need(collapsed_archive_region(current) == collapsed_archive_region(before), 'ONLY_ARCHIVE_MARKER_REGION_CHANGED')
    return dict(build=reference(BUILD), renderer_source=receipt['renderer_source'],
                main_original=main, main_current=reference(main['path']), data=data_ref)


def final_readiness():
    protocol, audits, report = verify_protocol(), audit_gates(), verify_report()
    ui = load(UI)
    need(ui['status'] == 'PASS_LOCAL_UI' and type(ui['math_errors']) is int and ui['math_errors'] == 0
         and ui['body_overflow'] is False and ui['console'] == [], 'ACTUAL_FINAL_LOCAL_UI')
    need(ui.get('fatal', '') == '', 'NO_LOCAL_READER_FATAL_ERROR')
    need(ui['source']['path'] == 'report/' + MAIN, 'UI_MAIN_SOURCE')
    exact(ui['source'])
    root = load(ROOT_ADMISSION)
    need(root['status'] == 'PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES', 'ROOT_PUBLICATION_ADMISSION')
    bound = refs_in(root)
    required = {PROTOCOL, 'report/' + MAIN, 'report/' + DATA, BUILDER,AUDITOR,
                'publication/package_receptor_v2.py', TRANSFER_AUDIT, UI, BUILD, BUILD_AUTHORITY}
    need(required <= set(bound), 'ROOT_ADMISSION_BINDS_FINAL_PUBLICATION_BYTES')
    return dict(protocol=protocol, audits=audits, report=report, local_ui=reference(UI),
                root_admission=reference(ROOT_ADMISSION))


def original_files():
    files = []
    for path in sorted(ROOT.rglob('*')):
        name = path.relative_to(ROOT).as_posix()
        if name.split('/')[0] == 'package':
            continue
        need(not path.is_symlink(), 'NO_ARCHIVE_SYMLINK:' + name)
        if path.is_file():
            files.append(dict(path=relative(name), **pin(path)))
    need(INTERNAL not in {x['path'] for x in files}, 'NO_GENERATED_MANIFEST_COLLISION')
    return files


def estimate(path):
    compressor, count = zlib.compressobj(6, zlib.DEFLATED, -15), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            count += len(compressor.compress(block))
    return count + len(compressor.flush())


def partition(files):
    groups, used = [[]], 0
    for entry in files:
        charge = estimate(local(entry['path'])) + 256 + 4 * len(entry['path'].encode('utf8'))
        need(charge <= MAX_PART - RESERVE, 'SINGLE_MEMBER_EXCEEDS_DECLARED_VOLUME_DESIGN:' + entry['path'])
        if groups[-1] and used + charge > MAX_PART - RESERVE:
            groups.append([])
            used = 0
        groups[-1].append(entry['path'])
        used += charge
    return groups


def part_names(count):
    return [PART_STEM + '%03d.zip' % i for i in range(1, count + 1)]


def set_links(names):
    links = ' · '.join('<a href="' + name + '">Evidence volume ' + str(i) + '</a>'
                       for i, name in enumerate(names, 1))
    block = BEGIN + ('<p>Full approved current-run archive: ' + links +
        ' · <a href="' + MANIFEST + '">Every original path and hash</a>. Download all volumes and extract together; '
        'all Source/raw/UNKNOWN/log paths are physically retained. '
        '<a href="' + OLD + '#reader">Prior milestone and its separate full archive</a>.</p>').encode('utf8') + END
    path = local('report/' + MAIN)
    raw = path.read_bytes()
    need(raw.count(BEGIN) == 1 and raw.count(END) <= 1, 'ONE_RENDERER_ARCHIVE_MARKER')
    if END in raw:
        left, tail = raw.split(BEGIN)
        _, right = tail.split(END)
        new = left + block + right
    else:
        new = raw.replace(BEGIN, block, 1)
    if raw != new:
        path.write_bytes(new)


def prepare_links():
    need(not local(PACKAGE_DIR).exists() and not local('publication/prepared-v2.json').exists(), 'ARCHIVE_CUT_IMMUTABLE')
    verify_protocol()
    audit_gates()
    report = verify_report()
    original = local('publication/rendered-before-archive-links-v2.html')
    if not original.exists():
        owned(original, local('report/' + MAIN).read_bytes())
    exact(dict(path='publication/rendered-before-archive-links-v2.html',
               **{k: report['main_original'][k] for k in ('bytes', 'sha256')}))
    owned(local('README-receptor-family-transfer-20261104-evidence-v1.txt'), README)
    count = 1
    for iteration in range(16):
        names = part_names(count)
        set_links(names)
        groups = partition(original_files())
        print(json.dumps(dict(stage='ARCHIVE_PLAN', iteration=iteration, parts=len(groups))), flush=True)
        if len(groups) == count:
            break
        count = len(groups)
    else:
        raise AssertionError('ARCHIVE_VOLUME_PLAN_DID_NOT_STABILIZE')
    plan = dict(status='ARCHIVE_LINKS_PREPARED', parts=names,
                main=reference('report/' + MAIN), data=reference('report/' + DATA),
                scope='Planning only; final UI/admission must bind these bytes. Package refuses a changed part count.')
    # Replanning before a cut is explicit; preserve any earlier plan first.
    path = local('publication/archive-plan-v2.json')
    if path.exists() and path.read_bytes() != wire(plan):
        old = path.read_bytes()
        owned(local('publication/archive-plan-v2-history-' + sha(old) + '.json'), old)
    path.write_bytes(wire(plan))
    print(json.dumps(dict(status=plan['status'], parts=names, next='Run final local UI and Root publication admission before packaging.')), flush=True)


def fresh_remote_base(expected=None):
    response = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    observed = response['object']['sha']
    need(response['ref'] == 'refs/heads/main' and response['object']['type'] == 'commit'
         and type(observed) is str and len(observed) == 40
         and all(c in '0123456789abcdef' for c in observed), 'OFFICIAL_REMOTE_MAIN_COMMIT')
    need(expected is None or observed == expected, 'FRESH_OFFICIAL_REMOTE_MAIN_CHANGED')
    value = dict(status='FRESH_REMOTE_BASE_CONFIRMED', repository=REPO, base=observed,
                 observed_epoch=time.time(), method='Official GitHub GET git/ref/heads/main', response=response)
    owned(local('publication/remote-base-at-prepare-v2.json'), wire(value))
    return value


def verify_archive(folder, manifest):
    core = {k: v for k, v in manifest.items() if k not in ('inventory_sha256', 'inventory_file', 'inventory_schema')}
    core['schema'] = manifest['inventory_schema']
    core['parts'] = [dict(number=p['number'], name=p['name']) for p in manifest['parts']]
    need(sha(wire(core)) == manifest['inventory_sha256'], 'INTERNAL_INVENTORY_HASH')
    entries = {e['path']: e for e in core['files']}
    need(len(entries) == len(core['files']) == core['original_files']
         and sum(e['bytes'] for e in entries.values()) == core['original_bytes'], 'ALL_ORIGINAL_PATHS_AND_BYTES')
    seen, parts = set(), []
    for number, part in enumerate(manifest['parts'], 1):
        need(part['number'] == number and part['name'] == PART_STEM + '%03d.zip' % number, 'CANONICAL_VOLUME_NAME')
        path = folder / relative(part['name'])
        actual = pin(path)
        need(wire(actual) == wire({k: part[k] for k in ('bytes', 'sha256')})
             and actual['bytes'] <= MAX_PART and actual['bytes'] < 50 * 1024 * 1024, 'VOLUME_BYTES_AND_CEILING')
        expected = {name for name, e in entries.items() if e['part'] == number}
        with zipfile.ZipFile(path) as archive:
            need(len(archive.namelist()) == len(set(archive.namelist()))
                 and set(archive.namelist()) == expected | {INTERNAL}, 'EXACT_VOLUME_MEMBER_SET')
            need(archive.read(INTERNAL) == wire(core) and archive.testzip() is None, 'EVERY_MEMBER_CRC_AND_INVENTORY')
            for name in sorted(expected):
                relative(name)
                entry = entries[name]
                need(name not in seen and archive.getinfo(name).file_size == entry['bytes'], 'PHYSICAL_ONCE_AND_EXACT_SIZE')
                with archive.open(name) as stream:
                    actual_member = stream_pin(stream)
                need(wire(actual_member) == wire({k: entry[k] for k in ('bytes', 'sha256')}), 'EXACT_UNCOMPRESSED_MEMBER:' + name)
                seen.add(name)
        parts.append(dict(number=number, name=part['name'], **actual, CRC='PASS'))
    need(seen == set(entries), 'EVERY_ORIGINAL_PHYSICALLY_VERIFIED')
    return dict(status='PASS', original_files=len(entries), parts=parts,
                all_original_paths_byte_verified=True, all_originals_physically_stored_once=True,
                all_CRC_verified=True, alias_deduplication=False)


def package(base=None):
    need(base is None or type(base) is str and len(base) == 40
         and all(c in '0123456789abcdef' for c in base), 'OPTIONAL_REVIEWED_BASE_SHA')
    for name in (PACKAGE_DIR, 'publication/prepared-v2.json', 'publication/index-v2'):
        need(not local(name).exists(), 'PRESERVE_FIRST_PACKAGING_ATTEMPT:' + name)
    readiness = final_readiness()
    plan = load('publication/archive-plan-v2.json')
    need(plan['status'] == 'ARCHIVE_LINKS_PREPARED', 'LINK_PLAN_BEFORE_FINAL_UI')
    exact(plan['main'])
    exact(plan['data'])
    owned(local('README-receptor-family-transfer-20261104-evidence-v1.txt'), README)
    remote = fresh_remote_base(base)
    base = remote['base']
    env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    env.update(GIT_INDEX_FILE=str(local('publication/index-v2')), GIT_NO_LAZY_FETCH='1',
               GIT_AUTHOR_NAME='Codex', GIT_AUTHOR_EMAIL='codex@openai.com',
               GIT_COMMITTER_NAME='Codex', GIT_COMMITTER_EMAIL='codex@openai.com')
    def git(*args, input=None):
        return subprocess.check_output(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'gc.auto=0',
            '--git-dir=' + GIT, *args], env=env, input=input, timeout=180).decode().strip()
    need(git('rev-parse', '--is-bare-repository') == 'true'
         and git('cat-file', '-t', base) == 'commit', 'EXISTING_ISOLATED_BARE_GIT_AND_BASE')
    old = subprocess.check_output(['git', '--git-dir=' + GIT, 'show', base + ':' + PREFIX + OLD], env=env, timeout=180)
    need(old.count(b'</h1>') == 1 and MAIN.encode('ascii') not in old, 'ONLY_ORIGINAL_OLD_READER_BACKLINK')
    backlink = ('<p><a href="' + MAIN + '#reader">Continue: checked receptor-family transfer and native proof search '
                'with separate conventional and direct-library controls.</a></p>').encode('ascii')
    previous = local('publication/previous-report-with-backlink-v2.html')
    owned(previous, old.replace(b'</h1>', b'</h1>' + backlink, 1))
    files = original_files()
    groups = partition(files)
    names = part_names(len(groups))
    need(names == plan['parts'], 'FINAL_FILES_CHANGED_VOLUME_COUNT_REPEAT_LINKS_AND_UI_BEFORE_CUT')
    current_main = local('report/' + MAIN).read_bytes()
    need(all(name.encode('ascii') in current_main for name in names)
         and MANIFEST.encode('ascii') in current_main, 'ALL_ARCHIVE_VOLUMES_LINKED')
    assignments = {name: number for number, group in enumerate(groups, 1) for name in group}
    entries = [dict(**entry, part=assignments[entry['path']]) for entry in files]
    core = dict(schema='Receptor-family-physical-evidence-inventory-v1',
                original_files=len(entries), original_bytes=sum(e['bytes'] for e in entries), files=entries,
                parts=[dict(number=i, name=name) for i, name in enumerate(names, 1)],
                all_originals_physically_stored=True, alias_deduplication=False, readiness=readiness,
                previous_archive_separately_linked=BASE_URL + PREFIX + OLD,
                exclusions=['package/ generated archive outputs only; all other original paths present at the cut are physical members'],
                postcut_scope='Publication index, prepared commit, push, Pages and live receipts created after this cut are later custody records, not claimed inside their own prior archive.',
                generated_members=[INTERNAL])
    inventory = wire(core)
    need(len(zlib.compress(inventory, 6)) + 65536 < RESERVE, 'INVENTORY_HEADER_RESERVE')
    folder = local(PACKAGE_DIR)
    folder.mkdir(parents=True)
    parts = []
    for number, (name, group) in enumerate(zip(names, groups), 1):
        path = folder / name
        with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for member in group:
                archive.write(local(member), member)
            archive.writestr(INTERNAL, inventory)
        value = pin(path)
        need(value['bytes'] <= MAX_PART and value['bytes'] < 50 * 1024 * 1024, 'ACTUAL_PHYSICAL_VOLUME_CEILING')
        parts.append(dict(number=number, name=name, **value))
        print(json.dumps(dict(stage='VOLUME_WRITTEN', part=number, **value)), flush=True)
    manifest = dict(core, schema='Receptor-family-physical-multipart-evidence-v1',
                    inventory_schema=core['schema'], inventory_file=INTERNAL,
                    inventory_sha256=sha(inventory), parts=parts)
    owned(folder / MANIFEST, wire(manifest))
    verified = verify_archive(folder, manifest)
    owned(folder / 'archive-verification-v1.json', wire(verified))
    for entry in files:
        exact(entry)
    need(wire(original_files()) == wire(files), 'CUT_FILE_SET_AND_ALL_BYTES_UNCHANGED')
    # Read-only network observation is repeated immediately before local Git
    # preparation. It creates no new receipt, so it cannot change the cut.
    current = json.loads(subprocess.check_output([GH, 'api', '--hostname', 'github.com', '--method', 'GET',
        'repos/' + REPO + '/git/ref/heads/main'], timeout=50))
    need(current['ref'] == 'refs/heads/main' and current['object']['type'] == 'commit'
         and current['object']['sha'] == base, 'REMOTE_STILL_EXACT_BASE_BEFORE_COMMIT')
    sources = [(local('report/' + MAIN), PREFIX + MAIN), (local('report/' + DATA), PREFIX + DATA)]
    sources += [(folder / part['name'], PREFIX + part['name']) for part in parts]
    sources += [(folder / MANIFEST, PREFIX + MANIFEST), (previous, PREFIX + OLD)]
    need(len(sources) == len({target for path, target in sources}), 'UNIQUE_TASK_ASSET_PATHS')
    git('read-tree', base)
    assets = []
    for path, target in sources:
        if target != PREFIX + OLD:
            need(not git('ls-tree', '--full-name', base, '--', target), 'NEW_ASSET_COLLISION:' + target)
        value = pin(path)
        need(value['bytes'] < 50 * 1024 * 1024, 'GIT_ASSET_PHYSICAL_SIZE')
        raw = path.read_bytes()
        need(sha(raw) == value['sha256'], 'EXACT_ASSET_READ')
        blob = git('hash-object', '-w', '--stdin', input=raw)
        git('update-index', '--add', '--cacheinfo', '100644', blob, target)
        assets.append(dict(local=path.relative_to(ROOT).as_posix(), path=target, **value,
                           git_blob=blob, url=BASE_URL + target))
    tree = git('write-tree', '--missing-ok')
    commit = git('commit-tree', tree, '-p', base, '-m', 'Publish receptor-family transfer with explicit donor and proof-search scopes')
    need(git('rev-list', '--parents', '-n', '1', commit).split() == [commit, base], 'EXACT_SOLE_PARENT')
    need(git('rev-parse', commit + '^{tree}') == tree, 'EXACT_PREPARED_TREE')
    diff = git('diff-tree', '--no-commit-id', '--no-renames', '--name-status', '-r', base, commit)
    changes = [row.split('\t') for row in diff.splitlines()]
    need(all(len(row) == 2 for row in changes) and len(changes) == len(assets)
         and {name for status, name in changes} == {entry['path'] for entry in assets}
         and all(status == ('M' if name == PREFIX + OLD else 'A') for status, name in changes),
         'TASK_ASSETS_AND_ONE_BACKLINK_ONLY')
    value = dict(status='PREPARED_TASK_ASSETS_ONLY', base=base, tree=tree, commit=commit, assets=assets, diff=diff,
                 archive_manifest=PACKAGE_DIR + '/' + MANIFEST, archive_verification=verified,
                 remote_base_at_cut=remote, remote_base_before_commit=current,
                 readiness=readiness, primary_checkout_staged=False, pushed=False)
    owned(local('publication/prepared-v2.json'), wire(value))
    print(json.dumps(dict(status=value['status'], commit=commit, parent=base,
                          assets=len(assets), volumes=len(parts), original_files=len(files))), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('base', nargs='?')
    parser.add_argument('--prepare-links', action='store_true')
    args = parser.parse_args()
    if args.prepare_links:
        need(args.base is None, 'PREPARE_LINKS_HAS_NO_COMMIT_BASE')
        prepare_links()
    else:
        package(args.base)


if __name__ == '__main__':
    main()
