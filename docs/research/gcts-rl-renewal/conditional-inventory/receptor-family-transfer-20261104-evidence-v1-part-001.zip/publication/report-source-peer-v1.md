# Receptor-family reader Source peer

Status: `PASS_SOURCE_ONLY_REVIEW`. Full held reader/API review found no
outstanding blocker. This is not a build, executed saved-data/native audit,
browser qualification, package or live-publication receipt.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `publication/build_receptor_report_v1.py` | 45992 | `933049d032ebd3198214e26eb7fa061d054745c0989eb983647f57fa6d1394f8` |
| `publication/report-API-v1.md` | 8723 | `de570608305430014159f6d5d46ffd8227f5b58231c4bdc482916a9b410260cb` |

Only direct Source/API reads, byte hashing and a standard-library AST parse were
performed. No renderer, learner, engine, checker or native module was imported;
no build, scientific helper, replay, package, network or Git action was run. No
reviewed Source was edited.

The reader authenticates current frozen file refs and runtime/version/flags/
binary/master, then checks actual phase PID/name/protocol/result/log/native exit,
guards and postchecks. Workflow/scientific admission and theorem acceptance stay
separate. Mandatory audit schema/status/protocol and all eight current phase
classifications are joined before output. Missing, stopped and unadmitted
results remain labelled instead of borrowing a successful process.

Each target proof has agreeing complete M/N semantic projections, unchanged
prepared statement/selection hashes, saved whole proof and fresh complete B
receipt. Point proofs additionally require actual SAT, C VERIFIED with exact
semantic scope and selection; conventional/direct methods get their separate
finder attribution. The exact public target-proof ID set equals the audit set,
with role, line count, full proof/statement/selection hashes and proof/native
artifact identities joined. A raw/C UNKNOWN lacking a digest is displayed only
as an uncommitted prefix; it cannot acquire a native proof. Unresolved choices
clear proof/slot views and disable proof download.

The most important methodological limitation is explicit beside the lede and in
finder labels and assessment: L generates subclusters only after an entire
instantiated donor proof maps to current primitives, and X checks that whole
expansion's point cover. Guided GCTS is therefore described as reconstruction
under learned complete-expansion guidance. It is not independent discovery of
the argument or composition of separately learned partial lemmas. RANK_ONLY has
no learned library; direct same-library expansion is the decisive matched
control. Fixed slots, literal vocabulary/binders, training overlap and no
universal schematic soundness are stated.

All learned family goal/prototype records and rooted topology records remain
selectable. The concrete instance display is explicitly a bounded deterministic
64-record projection, selected for diverse family/cluster coverage with actual
retained/total counts; a missing displayed instance is not impossibility.
Concrete members, actual earlier-reference edges and external receptor formulas
come from saved admitted data. Their consistent missing owners are not claimed
as extension certificates. The native table preserves original ASTs, with
MathJax and explicit display-only aliases plus rule-specific English readings.
Anchored symbolic cards are not represented as a universal Wang palette.

The results table includes policy setup, engine/C or control selection/search,
all available M/N/B component seconds, and the recorded nonoverlapping
per-method component subtotal. Direct control native validation is included.
The page explicitly excludes extra certificate persistence and Root aggregation
from those subtotals and exposes common donor/learning/qualification/target
preparation/rank/instance admission and whole-process costs separately. It does
not sum overlapping process/observer intervals as independent timing or infer
speed/GCTS/RL superiority from a successful reconstruction or fewer branches.

The Source uses only standard-library file/hash/JSON/gzip operations. It rejects
path escape and symlinks, preserves the input pin ledger, checks existing output
paths before writing, and produces the one HTML/data/build-receipt ABI expected
by the held packager. The HTML retains one archive marker, source/literal-name
inspection, full native proof download, unknown-selector clearing and serialized
MathJax startup/typesetting. Actual saved-data admission, first passive build,
final UI, Root final-byte approval, archive and live checks remain separate.
