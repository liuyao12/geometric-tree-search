# Source peer addendum: observed process stops

PASS for the narrow presentation delta, read without executing the builder or any scientific code.

The held builder is `publication/build_receptor_report_v1.py`, 47,304 bytes, SHA256 `674d31603bd2a6d310e432dc76343ac4b8630ae28e7c5a76d1c354b420c2029e`. The held API is `publication/report-API-v1.md`, 9,104 bytes, SHA256 `15c783749e5aa5b9435d6afd5319a1c5f50e17d3fd4af0dce33d4bd46cf27964`.

The complete supplied `publication/drafts/process-stop-presentation-v1.patch` is byte-exact against the preserved previously reviewed builder. Python function and class ASTs are unchanged. The changes add only an HTML destination and browser presentation derived from the already retained phase observer records. Guard/error, nonterminal observer status, or nonzero native exit produces a prominent unresolved-process warning; the phase table shows the recorded reason. The RSS detail reads the actual observer polling peak and frozen guard limit, rather than equating sampled peak with native high-water RSS. Rendered values are escaped.

The warning explicitly refuses negative-theorem or proof-acceptance conclusions from a process stop. Existing custody, admission, partial-prefix and exact proof-set gates are unchanged. The API accurately records this scope. No blocking issue found. Static Python parsing and byte/hash/diff comparison only; no imports of the builder or scientific modules, report build, audit, search, checker replay, Git, network or package operation.
