"""One-shot passive live-byte and archive check through normal HTTPS transport."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 50 * 1024 * 1024 - 1


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def pin(path):
    raw = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), bytes=len(raw),
                sha256=hashlib.sha256(raw).hexdigest())


def main():
    source = ROOT / 'publication/package_receptor_v2.py'
    need(pin(source)['sha256'] == 'dfaab590eea860e7e1bc0bd11b9dab4b21263748362edc060d54f5274aff6500',
         'REVIEWED_PASSIVE_PACKAGER_BYTES')
    spec = importlib.util.spec_from_file_location('passive_archive', source)
    package = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(package)
    prepared_path = ROOT / 'publication/prepared-v2.json'
    need(prepared_path.stat().st_size < 16 * 1024 * 1024, 'BOUNDED_PREPARED')
    prepared = json.loads(prepared_path.read_bytes())
    commit, assets = prepared['commit'], prepared['assets']
    need(prepared['status'] == 'PREPARED_TASK_ASSETS_ONLY' and len(commit) == 40
         and all(c in '0123456789abcdef' for c in commit), 'EXACT_PREPARED_COMMIT')
    need(4 < len(assets) < 1000, 'BOUNDED_TASK_ASSETS')
    out = ROOT / 'publication/live-v2'
    out.mkdir()
    receipt = dict(status='FAILED', commit=commit, prepared=pin(prepared_path),
        source=pin(Path(__file__).resolve()), assets=[],
        scope='One exclusive postcut transport observation through curl and its normal proxy settings. No retry, scientific import, replay, source change or new publication asset. Official Pages success is checked separately before invocation.')
    started = time.monotonic()
    try:
        seen = set()
        fixed = {package.MAIN, package.DATA, package.OLD, package.MANIFEST}
        for asset in assets:
            name = asset['path'].removeprefix(package.PREFIX)
            middle = name[len(package.PART_STEM):-4]
            part = name.startswith(package.PART_STEM) and name.endswith('.zip') and len(middle) == 3 and middle.isdigit()
            need(asset['path'] == package.PREFIX + name and '/' not in name
                 and name not in seen and (name in fixed or part), 'TASK_PATH')
            need(asset['url'] == package.BASE_URL + asset['path']
                 and type(asset['bytes']) is int and 0 <= asset['bytes'] <= MAX_BYTES, 'TASK_URL_BOUND')
            seen.add(name)
            body, header, error = out / name, out / (name + '.headers'), out / (name + '.stderr')
            body.open('xb').close()
            url = asset['url'] + '?v=' + commit[:12]
            item = dict(path=asset['path'], url=url, status='FAILED')
            receipt['assets'].append(item)
            run = subprocess.run(['curl', '--proto', '=https', '--http1.1', '--silent', '--show-error',
                '--max-time', '60', '--connect-timeout', '15', '--max-filesize', str(MAX_BYTES),
                '--header', 'Accept-Encoding: identity', '--dump-header', str(header),
                '--output', str(body), '--write-out', '%{http_code}', url],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=70)
            with error.open('xb') as stream:
                stream.write(run.stderr)
            item.update(native_exit_code=run.returncode, http_status=run.stdout.decode('ascii'),
                        body=pin(body), headers=pin(header), stderr=pin(error))
            need(run.returncode == 0 and item['http_status'] == '200', 'COMPLETE_HTTPS_200')
            need(item['body']['bytes'] == asset['bytes']
                 and item['body']['sha256'] == asset['sha256'], 'EXACT_PREPARED_LIVE_BYTES')
            item['status'] = 'PASS'
        manifest = json.loads((out / package.MANIFEST).read_bytes())
        need(seen == fixed | {p['name'] for p in manifest['parts']}, 'ALL_ASSETS_AND_VOLUMES')
        need(package.wire(manifest['readiness']) == package.wire(prepared['readiness']), 'EXACT_READINESS')
        receipt['archive'] = package.verify_archive(out, manifest)
        need(package.wire(receipt['archive']) == package.wire(prepared['archive_verification']), 'ALL_SAME_ARCHIVE_ORIGINALS')
        receipt['status'] = 'PASS_ALL_PREPARED_LIVE_BYTES_AND_ARCHIVE_ORIGINALS'
    except BaseException as exc:
        receipt['error'] = dict(type=type(exc).__name__, message=str(exc))
        raise
    finally:
        receipt['elapsed_seconds'] = time.monotonic() - started
        with (out / 'receipt-v1.json').open('xb') as stream:
            stream.write(package.wire(receipt))
        print(json.dumps(dict(status=receipt['status'], assets=len(receipt['assets']),
                             receipt='publication/live-v2/receipt-v1.json')), flush=True)


if __name__ == '__main__':
    main()
