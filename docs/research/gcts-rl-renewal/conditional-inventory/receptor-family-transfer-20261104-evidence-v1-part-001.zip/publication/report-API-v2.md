# Dated reader filenames: passive collision correction

Source-only until Root and independent peer review. No build, scientific import,
helper call, search, package, Git or network operation occurs during authorship.

The existing remote `receptor-families-v1.html` belongs to an earlier report.
The first publication attempt stopped at `NEW_ASSET_COLLISION` before staging
Git blobs or pushing. This correction gives the current milestone distinct
public filenames. It does not overwrite the older reader, change the audience,
rerun science or alter any prior Source/result/archive.

The exact preserved builder is `publication/build_receptor_report_v1.py`,
47,304 bytes / SHA-256
`674d31603bd2a6d310e432dc76343ac4b8630ae28e7c5a76d1c354b420c2029e`.
Its preserved API is `publication/report-API-v1.md`, 9,104 bytes / SHA-256
`15c783749e5aa5b9435d6afd5319a1c5f50e17d3fd4af0dce33d4bd46cf27964`.
The original build receipt and rendered v1 outputs are left byte exact.

New Source: `publication/build_receptor_report_v2.py`. It is the preserved v1
builder with only the following literal path replacements; reversing this
complete substitution table restores the entire v1 Source byte for byte.
`publication/report-v1-to-v2-paths.patch` retains the complete unified diff.

| Previous literal | New literal |
|---|---|
| `receptor-families-v1.html` | `receptor-family-transfer-20261104-v1.html` |
| `receptor-families-data-v1.json.gz` | `receptor-family-transfer-20261104-data-v1.json.gz` |
| `report/build-receipt-v1.json` | `report/build-receipt-v2.json` |
| `publication/build_receptor_report_v1.py` | `publication/build_receptor_report_v2.py` |
| `receptor-families-evidence-v1-manifest.json` | `receptor-family-transfer-20261104-evidence-v1-manifest.json` |
| `receptor-families-evidence-v1-part-001.zip` | `receptor-family-transfer-20261104-evidence-v1-part-001.zip` |

Root executes the reviewed new builder once using the same frozen pinned Python
with `-I -S -B`, after the same saved-data audit and current-byte admission.
Exclusive outputs are:

- `report/receptor-family-transfer-20261104-v1.html`;
- `report/receptor-family-transfer-20261104-data-v1.json.gz`;
- `report/build-receipt-v2.json`.

All data/build schemas, statuses, record fields, actual phase/audit joins,
native-proof IDs and acceptance gates, instance projection, unchanged ASTs,
costs, process-stop warnings, whole-expansion limitation and UI behavior are
identical to the v1 API. The receipt's `renderer_source` now names the v2 Source
and `outputs:{main,data}` names the dated files. No scientific field is changed.

Mandatory audit remains `publication/saved-data-audit-v1.json`, schema
`Receptor-family-passive-audit-v1`, status `PASS`. Frozen protocol remains
`protocol/frozen-protocol-v1.json`. These version-one paths describe scientific
evidence and are intentionally unchanged.

The single internal archive marker is still
`<!-- RECEPTOR_FAMILIES_ARCHIVE_LINK -->`; anchors remain `#reader` and `#evidence`.
The new packager supplies every actual volume using the stem
`receptor-family-transfer-20261104-evidence-v1-part-NNN.zip` and manifest
`receptor-family-transfer-20261104-evidence-v1-manifest.json`. Predecessor
navigation remains `ranked-arithmetic-v1.html`. Root separately owns the later
archive-link injection, final UI/admission, packaging and existing-site update.

Only Python AST parsing and JavaScript syntax compilation are authorized before
Root's execution. This note and the new publication files are outside the frozen
scientific Source/input/reference/plan set.
