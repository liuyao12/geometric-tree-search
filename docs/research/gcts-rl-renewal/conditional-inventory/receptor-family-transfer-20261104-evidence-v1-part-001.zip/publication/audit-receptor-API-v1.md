# Passive receptor-family saved-data audit

This Source is inert until Root full review and peer closure. It imports only stdlib file/JSON/gzip/hash/runtime tools, never a scientific module. No compiler, family matcher, rank function, model builder, engine, C4/T/X/oracle or native B check is called or replayed. Root runs it only after all eight owned attempts have ended:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/audit_receptor_saved_data_v1.py
```

It exclusively writes `publication/saved-data-audit-v1.json`, schema `Receptor-family-passive-audit-v1`, status `PASS`. A contradictory required association raises and produces no PASS. PASS means saved-evidence consistency with explicit scopes, not every attempted method succeeding or a universal theorem. No retry, native process receipt or scientific result is fabricated.

## Output ABI

Top fields are `schema,status,check_count,protocol,frozen,phases,donor,qualification,learning,cases,native_proofs,native_proof_counts,physical_files,artifact_pins,scope`.

`phases` is the exact frozen eight-position roster: `qualify`, `learn`, and `prepare-`/`evaluate-` for `seen`, `unary-transfer`, `nested-transfer`. Rows include `name,pid,native_exit_code,scientific_status,process_status,process_clean,scientific_admitted,refs,costs,guards,parse_errors`. Available PIDs are joined even when invocation/result is missing; retained observer logs are byte bound independently of clean completion. A guard or negative native signal exit cannot become a clean phase. Missing worker timing is null, not zero. The whole current frozen Source/input/reference/plan/review set, runtime executable/version/flags and current master/reference bytes must agree at start and end.

Native target records have ID `<caseid>--<METHOD>` and fields `id,role,lines,statement_sha256,selected_sha256,proof_sha256,proof_ref,native_ref,decoder_refs,rules,refs,scope`. Roles are `POINT_SEARCH`, `SPECIALIZED_CONTROL` and `DIRECT_SAME_LIBRARY`. Only an actual positive from a clean scientifically admitted evaluation phase enters this exact target set. Donor and qualification proofs remain separate nested evidence. No target-positive count is hardcoded.

## Data associations

- Donor: every explicitly declared member is physically authenticated under `input/donor`, with exact complete copied tree and old frozen Source closure. Original phase/PID/protocol/log/result/native-positive lane joins and fixed donor slot mapping are bound. Only the retained `RANK_MARKS` lane refs are followed: other-lane refs in its whole old phase are unconsumed metadata. Current fresh donor C4/B receipts bind the training proof; the audit does not recheck it.
- Qualification: all inherited tiny/logical/rank saved maps, complete subset tables/covers, native qualification and new callback/permutation/rollback/refusal receipts are associated by bytes, event order, hashes and counts. No state or subset is recomputed.
- Learning: exact donor hashes, whole library/family/cluster ID preimages, counts and current X provenance plus actual Y rehashed mutation outcomes. Provenance is not universal schematic soundness.
- Each case: original declaration, full compiled/generation/bridge/R/Q/N/native-ZERO/prepared/base/rank/model bindings; the complete original rows and old marks are retained. No ranks or primitive inventory are regenerated.
- Every proposed instance and cumulative X receipt is associated in exact order, and the approved raw list is exactly the VERIFIED_INSTANCE subset. All four model/instance/statement/library bindings, current prepared scope, cluster CIDs, roots and receptor arrays are joined. Changed term/context/UI examples are comparisons of saved data, not new instantiation or logical checking.
- Y: all actual and corrupted library/instance inputs/answers are physically bound; state-union/shared-member/exclusion/restoration/missing-owner, charge-stop and inactive-zero fixtures retain their synthetic scope. The modified point fixture has no original RF/N or observed-E-state claim.
- Current E methods: exact model/endpoints/events/selected certificate rows and C4 order profile/metadata; complete payload alone does not turn UNKNOWN into proof/refutation. Actual policy logs bind branch point/generation/legal domain and complete fallback order. Logged selected/excluded authenticity relies on the frozen hook; the audit does not reconstruct its transitions or execute state checks. Preferred attempts and retained final native-selected members remain different counts.
- Every target positive: exact full M/N semantic projections, unchanged statement/scope/selection, saved whole proof, B checked-line and full typed rule census. Proof receipts lack a self-authenticating kernel input digest; provenance remains the frozen invocation/context plus these byte/projection joins, not a new kernel call.

## Failed or partial phases

A failed/unrun enclosing phase never creates an admitted native target, even if raw SAT/C or decoder prefixes exist. The audit lists available physical method/policy/native-prefix files and may expose saved raw/C status strings as **unadmitted claims only**. Unreadable/truncated prefixes remain byte-pinned with parse refusal. This neither calls the method unattempted nor promotes an absent result/invocation. No M/N/B projection is used to admit a failed phase's prefix. All data/run physical originals are included in the ledger for later archive validation.

The scientifically important limit is explicit: L maps the **entire** donor-length proof and X checks the whole cover before rooted subclusters are offered. Guided GCTS reconstructs an already available candidate. This audit establishes no independent argument/open-receptor composition, no learned pruning/RL, no arbitrary relocation/alpha generalization, no universal Wang palette, plane tiling or comparative speed result. Component and cumulative intervals are retained separately and are not summed as speed evidence.

The audit's reviewed Source is outside the scientific frozen set; Root's publication gate must bind its exact final bytes independently. Preserved Source drafts/deltas are authoring history only. Archive member/CRC/live-publication checks remain separate gates.
