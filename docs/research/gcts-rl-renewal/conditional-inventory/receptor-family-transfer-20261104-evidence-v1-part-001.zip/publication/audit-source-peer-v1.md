# Independent Source peer: passive receptor-family auditor

PASS. I read the complete held 1,021-line auditor, its full API, the relevant immutable phase/common/native-projection interfaces, and the preserved narrow custody deltas. No blocking Source defect found. This is Source review, not an execution of the audit or any scientific check.

Exact held files:

- `publication/audit_receptor_saved_data_v1.py`: 74,024 bytes, SHA256 `d126c7c4feaf04460de651baa4ef5baa7bd28928fe4dbac8106f10d59b48c052`.
- `publication/audit-receptor-API-v1.md`: 6,304 bytes, SHA256 `5ae55e1eb49657f6d768f8ad584d72beec642b8166beacad7ae3eb61b5e7c9ba`.

The output contract is `publication/saved-data-audit-v1.json`, schema `Receptor-family-passive-audit-v1`, status `PASS`. This status establishes the declared saved-data associations; it does not assert every phase or method succeeded, imply research completion, or replace a logical check.

## Custody and process gates

The auditor independently enumerates the current frozen directories and admitted review files, compares the exact frozen set, authenticates current master/reference and runtime executable/version/flags, and repeats these checks after its reads. It follows the actual eight-phase roster and workflow statuses. Retained started/invocation/observer PIDs and phase names are joined even on incomplete attempts; protocol, log and nonnull complete result references are byte-associated. Clean process admission requires actual native zero exit, complete invocation, no guard/error, and successful unchanged-Source postchecks. A saved workflow result alone cannot authorize a positive.

The nested failed or missing enclosing phase uses a separate physical-prefix path. Available raw, semantic, policy and native-prefix files are retained without invoking native projection admission. Their saved status strings remain unadmitted claims, and no target proof from that phase enters the native collection. Missing worker timing stays null. Contradictory required associations fail closed rather than creating PASS.

## Donor and model associations

The exact manifest controls the physical `input/donor` closure, including all original frozen Source members and the actual donor evaluate process. Only the retained `RANK_MARKS` lane's declared refs are followed. Other historical lane references embedded in the copied whole result are explicitly metadata; they are not recursively dereferenced, promoted to retained proofs or confused with current paths. Original selected rows, both decoder projections, statement, proof, native rule census and fixed slot mapping are joined; current fresh donor C/B receipts remain separate from that historical custody.

Current preparation joins original declarations, complete compiled/generation/bridge/model inputs, RF/Q/N gates and every saved ZERO payload/receipt. Rank associations bind the full rank/forbidden/reason tables and V receipt hashes to the actual base/marked/control models. All original rows and marks are compared, guard literals are literal strings, the guard site is fresh, and ordinary filter versus marking changes remain exact. No rank, native catalogue or preservation computation is rerun.

Every proposed instance is joined by ID/preimage, ordered membership, current model/statement/library/prepared scope and X receipt. The approved raw instance list is exactly the VERIFIED_INSTANCE subset. Rooted member/receptor arrays and full expansion remain separately visible. Y's synthetic union, exclusion/restoration, charge-stop and modified inactive-zero fixtures retain their generic-data scope; their statuses are not used as RF/N admission or actual observed target states.

## Trace, guidance and proof scopes

Actual tiny C/T/paired-state observations, full saved oracle subset tables and all declared controls are associated by refs, counts, event order and hashes without replay. Qualification native proofs are collected separately from new target proofs.

For current point methods, model/event/endpoints/selected-row byte associations and C4 order profile distinguish a complete semantic certificate from merely retaining every emitted event of an UNKNOWN run. Guided logs are joined to actual branch point, generation, legal domain and exact preferred-plus-complete-fallback order. Selected/excluded callback authenticity explicitly relies on the frozen engine hook; the auditor does not claim to reconstruct those state transitions or rerun X. Attempt preferences and final native-selected membership are different counters.

Only a positive from a clean scientifically admitted evaluation can enter the top-level target collection. Point positives additionally require completed point SAT/C assurance. Both complete native decoder projections, actual selection, original statement/scope, stored whole proof, final goal, checked-line count and every typed B rule counter are joined. Conventional and direct-library proofs retain separate roles; direct proof bytes must equal the actual already-admitted whole expansion. Proof-receipt input authentication remains the frozen invocation/context plus these byte joins, not a new kernel call.

The API and output scope candidly preserve the whole-expansion-before-subcluster limitation: guided GCTS reconstructs an already mapped complete proof candidate. This audit establishes no independent argument discovery, open-receptor lemma composition, learned pruning, RL, arbitrary relocation, uniform Wang palette or speed advantage. Common and per-method costs remain distinct component scopes.

## Review operations

Only direct Source/API reads, stdlib AST parsing and byte/hash inspection were performed. The import list contains only `pathlib`, `collections`, `gzip`, `hashlib`, `json` and `sys`. I did not import or execute the auditor, scientific modules, compiler, learner, model, engine, rank checker, C/T/X/oracle or native kernel; did not replay any saved computation; and did not build, package, use Git/network, publish or modify a frozen file.
