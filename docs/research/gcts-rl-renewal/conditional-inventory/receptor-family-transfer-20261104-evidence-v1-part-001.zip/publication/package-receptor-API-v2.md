# Dated receptor-family publication preparation, v2

Source-only until Root full-body review and independent peer closure. The held
`publication/package_receptor_v2.py` is 38,975 bytes, SHA-256
`dfaab590eea860e7e1bc0bd11b9dab4b21263748362edc060d54f5274aff6500`.
No tool import, scientific helper, package, Git or network operation was run
during authorship. The exact reviewed V4 baseline is preserved at
`publication/package-receptor-baseline-v1.py`, 36,079 bytes / `dc6fdd18261dbf63ffd941c4f3c5c15f85256d381a57f84e7af214403acec3a6`.
Full and compact adaptation patches retain all textual changes.

## Preserved first attempt and name-only continuation

The original `publication/package_receptor_v1.py` remains byte-exact at 38,752
bytes / `e56652da8a7022e62604e3176bac8cb8ba13dddfce34cc6842213abc576d453a`,
with its API and generated first-attempt evidence retained. Root reports that
the first execution stopped at `NEW_ASSET_COLLISION` after ZIP/CRC readback
and isolated `read-tree`, before any new blob/index entry or push. It is not
reported as successful publication. Root preserves generated v1 outputs under
`package/attempt-001`; this v2 script never moves or rewrites them.

This continuation changes only public output names, builder/receipt names and
administrative output namespaces. It uses `package/final-v2` for fresh generated
volumes and permits the preserved parent `package/` directory. Frozen science,
the v1 scientific protocol, v1 auditor and saved audit, schemas, phase outcomes,
limits, donor, proof gates, full physical archive/CRC checks, existing predecessor,
remote repository and isolated non-pushing Git semantics remain unchanged.
The exact whole Source diff is `publication/package-receptor-v2-names-v1.patch`.

## Commands and execution order

Use the pinned protocol runtime with `-I -S -B`. First, only after the executed
passive audit and built report exist:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_receptor_v2.py --prepare-links
```

This runs no Git/network. It refuses an existing `package/final-v2` or
`publication/prepared-v2.json`, authenticates the current saved gates, preserves
`publication/rendered-before-archive-links-v2.html`, adds the README and fills
only the `RECEPTOR_FAMILIES_ARCHIVE_LINK` region. Volume planning reaches a
fixed point and writes `publication/archive-plan-v2.json`, preserving a differing
earlier plan as `publication/archive-plan-v2-history-<SHA256>.json`. The README
is `README-receptor-family-transfer-20261104-evidence-v1.txt`. Run final UI on these postlink bytes, then write Root's final
publication admission. Historical Source approval does not substitute for that
final-byte approval.

Root must make the current official main object available in the existing
isolated bare repository. Then Root may prepare one local commit:

```sh
/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -I -S -B publication/package_receptor_v2.py EXPECTED_REMOTE_MAIN_SHA
```

The SHA is optional; omission means intentional acceptance of the official main
discovered by this invocation. It writes a fresh `publication/remote-base-at-prepare-v2.json`.
The script performs an official GitHub GET and
checks any supplied SHA, then checks the remote again before local Git
preparation. It never fetches, pushes, updates a branch or touches the primary
checkout/index. No new public destination is created.

## Scientific and donor gates

Protocol is exactly 18,141 bytes / SHA-256
`f7236f28cd3f8e74aa99c65d1d299284bb6067b309b4ef603ddca0128fd1aeae`,
schema `Receptor-family-protocol-v1`, status
`FROZEN_BEFORE_SCIENTIFIC_IMPORTS`. The complete dynamic frozen file set and
all admitted review refs must match, along with runtime flags/version/binary,
current master and reference copy. Source admission is
`Receptor-root-source-admission-v1` / `PASS_SOURCE_REVIEW_BEFORE_FREEZE`.

Current eight phase positions are `qualify`, `learn`, and prepare/evaluate for
`seen`, `unary-transfer`, `nested-transfer`, in that order. The frozen case list
and exact expected workflow statuses must match. Actual PID/phase/protocol,
result/log pins, complete captures, native exit, guards and frozen postchecks
determine admission. Missing, failed, refusal and UNKNOWN outcomes stay explicit;
`CASE_RECORDED` is not theorem or search success.

`input/donor-manifest-v1.json`, schema `Receptor-donor-evidence-v1`, is a separate
explicit training closure. Every declared member under `input/donor` and the
exact physical path set are authenticated; the current manifest has 51 members.
The proof path must be a listed member and its published source URL must be the
existing predecessor page. Original whole-phase values can contain references
to other historical lanes: those are metadata, not additional copied/consumed
proofs. Therefore only the audit's **explicit current artifact ledger**, not
arbitrary recursively embedded historical refs, is authoritative. All donor
paths are still physically present in the current archive. One authenticated
automatically found proof is authorized training, not a new target witness.

Mandatory passive products:

- `publication/saved-data-audit-v1.json`: schema
  `Receptor-family-passive-audit-v1`, status `PASS`.
- `report/build-receipt-v2.json`: schema `Receptor-family-report-build-v1`,
  status `BUILT_FROM_ADMITTED_SAVED_DATA`.
- Public data: schema `Receptor-family-report-data-v1`, status
  `SAVED_DATA_ADMITTED_WITH_EXPLICIT_SCOPES`.

The audit protocol/phase/PID/native/science/admission records join actual files.
The report joins its exact audit, Source, output/artifact pins, protocol, case
and proof counts and all current phase fields. Its proof-ID set must equal the
audit's complete target-proof collection. IDs are `caseid--METHOD`; roles are
`POINT_SEARCH` for RANK_ONLY/RECEPTOR_GUIDED/FAMILY_GUIDED,
`SPECIALIZED_CONTROL` for CONVENTIONAL_AND_OR and `DIRECT_SAME_LIBRARY` for that
direct control. Statements, selections, whole proofs, line counts, saved proof/
native refs and verified native receipts are joined. Optional `/proof` pointers
are supported. No target-positive count or winner is assumed.

These publication checks are passive associations. Donor/prototype provenance,
current primitive-row instance admission, partial-state compatibility and final
native theorem acceptance remain distinct. Unknown/prefix/failed proposals are
not negatives. Whole instantiation before subcluster guidance and fixed slots
limit this transfer claim. No RL, universal schematic theorem, new theorem,
full PA, universal Wang palette or speed advantage is inferred by packaging.

## Final UI and Root admission

`publication/local-ui-v2.json` requires `status:'PASS_LOCAL_UI'`, the exact
postlink main ref in `source`, native integer `math_errors:0`,
`body_overflow:false`, `fatal:''` and `console:[]`. Extra screenshots/observations
may be included. The main's pre-injection build pin is checked against the
preserved original, and collapsing its marker region must leave identical bytes.

Pre-build authority is separate:
`review/root-passive-publication-admission-v2.json`, schema
`Root-passive-publication-admission-v1`, status
`PASS_SOURCE_READ_AND_SAVED_DATA_AUDIT_BEFORE_BUILD`.

Final `publication/root-publication-admission-v2.json` must have status
`PASS_REVIEWED_PUBLICATION_WITH_EXPLICIT_SCOPES`. Its reviewed refs must bind at
least these ten exact files (each ref includes actual path/bytes/SHA-256):

```text
protocol/frozen-protocol-v1.json
report/receptor-family-transfer-20261104-v1.html
report/receptor-family-transfer-20261104-data-v1.json.gz
publication/build_receptor_report_v2.py
publication/audit_receptor_saved_data_v1.py
publication/package_receptor_v2.py
publication/saved-data-audit-v1.json
publication/local-ui-v2.json
report/build-receipt-v2.json
review/root-passive-publication-admission-v2.json
```

Additional reviewed refs are permitted. Changed postlink bytes require renewed
final UI/admission. Do not bind not-yet-generated ZIP/index/prepared receipts in
these pre-cut gates; that would create a circular readiness dependency.

## Physical archive and isolated task diff

Every original current-root path at the cut is physically stored once,
including equal-byte copies, the full donor closure, Sources, plans, reviews,
raw outcomes, logs, native certificates and publication tools/planning. Only
generated `package/` outputs are excluded. The original render and changed
`publication/previous-report-with-backlink-v2.html` are materialized **before**
the cut. Later index/prepared/push/Pages/live receipts are explicitly postcut
custody, not claimed inside their own earlier archive.

Independent ZIP volumes are at most 44 MiB and strictly below 50 MiB, each with
the full internal `ARCHIVE-file-manifest-v1.json`. All exact member sets, duplicate
paths, CRCs, uncompressed sizes/SHA-256, cross-volume physical coverage, volume
hashes and final cut path/byte set are read back. There is no alias table or
remote reference replacing original bytes. A member exceeding the unchanged
single-volume design refuses rather than being omitted. Final changed volume
count refuses instead of publishing stale links. Multipart is permitted for the
full evidence; no evidence is dropped to meet an estimated asset count.

Public additions in the existing conditional-inventory prefix are:

```text
receptor-family-transfer-20261104-v1.html
receptor-family-transfer-20261104-data-v1.json.gz
receptor-family-transfer-20261104-evidence-v1-manifest.json
receptor-family-transfer-20261104-evidence-v1-part-NNN.zip   # every actual volume
```

The sole existing-path edit is a backlink in `ranked-arithmetic-v1.html`. Thus
there are three fixed additions plus the actual volume count, and one edit;
one volume means four additions/five total assets. New-path collisions refuse.

Git uses existing bare `/private/tmp/gcts-history-publication-20261102-v1.git`,
fresh isolated `publication/index-v2`, sanitized Git environment,
`GIT_NO_LAZY_FETCH=1`, disabled hooks/automatic GC and the fresh official main
sole parent. Exact tree and name/status diff allow only these task assets and
the one backlink. Existing v2 final-package/index/prepared output refuses overwrite; retained
v1 outputs and `package/attempt-001` do not collide with this namespace.
Generated volumes, manifest and ZIP verification are written exclusively under
`package/final-v2`; the prepared manifest path identifies that namespace.
Success writes `publication/prepared-v2.json`, status
`PREPARED_TASK_ASSETS_ONLY`, with commit/tree/base, all asset/blob/URL pins,
readiness/archive verification and `pushed:false`.

Root separately owns the normal push, official Pages/remote checks, normal-TLS
full live body/archive readback and safe final mirror. Source preparation does
not claim those actions have occurred.
