"""Passive receptor-run data/custody audit; no scientific imports or replay.

Root reviews this Source before one execution after all intended attempts end.
PASS is saved-evidence scope consistency, never automatic research completion.
"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
PROTOCOL='protocol/frozen-protocol-v1.json'
OUTPUT='publication/saved-data-audit-v1.json'
POINT_METHODS=('RANK_ONLY','RECEPTOR_GUIDED','FAMILY_GUIDED')
METHODS=POINT_METHODS+('CONVENTIONAL_AND_OR','DIRECT_SAME_LIBRARY')
PROJECTION=('statement','proof','slots','slot_to_native','native_to_slot',
    'reference_mapping','proof_dag','selected','selected_sha256','original_statement_sha256','scope')
NATIVE_RULES=('axiom','tautology','refl','instantiate','distribute','eq_subst','mp','generalize')
LEDGER={}
CHECKS=0
PROOFS=[]
SITE='certified:rank:guard:v1'

def need(ok, why):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise ValueError(why)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),
                       allow_nan=False)+'\n').encode('ascii')


def sha(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a,b,why):
    need(wire(a)==wire(b),why)


def local(name):
    need(type(name) is str and name and not Path(name).is_absolute()
         and '..' not in Path(name).parts,'LOCAL_REFERENCE')
    path=ROOT
    for part in Path(name).parts:
        path=path/part
        need(not path.is_symlink(),'NO_REFERENCE_SYMLINK')
    need(path.resolve().is_relative_to(ROOT),'REFERENCE_CONTAINMENT')
    return path


def filepin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def reference(name):
    value=dict(path=name,**filepin(local(name)))
    if name in LEDGER:
        same(value,LEDGER[name],'UNCHANGED_DURING_AUDIT:'+name)
    LEDGER[name]=value
    return value


def logical_pin(name):
    path=local(name);h=hashlib.sha256();size=0
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        for block in iter(lambda:stream.read(1048576),b''):
            h.update(block);size+=len(block)
    return dict(bytes=size,sha256=h.hexdigest())


def exact(ref):
    actual=reference(ref['path'])
    need(type(ref['bytes']) is int and ref['bytes']>=0,'NATIVE_FILE_SIZE')
    same(actual,{k:ref[k] for k in actual},'PHYSICAL_REF:'+ref['path'])
    if 'complete_json' in ref:
        need(type(ref['complete_json']) is bool,'CAPTURE_COMPLETENESS_TYPE')
        need(logical_pin(ref['path'])['bytes']==ref['logical_json_bytes'],'LOGICAL_CAPTURE_SIZE')


def read(name,ref=None):
    reference(name)
    if ref is not None:
        exact(ref)
        need(ref.get('complete_json',True) is True,'COMPLETE_READABLE_JSON')
    path=local(name)
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as stream:
        raw=stream.read(134217729)
    need(len(raw)<=134217728,'SAVED_JSON_READ_BOUND')
    return json.loads(raw)


def readref(ref):
    return read(ref['path'],ref)


def allrefs(value):
    if type(value) is dict:
        if {'path','bytes','sha256'}<=set(value) and not value['path'].startswith('/'):
            exact(value)
        for v in value.values():allrefs(v)
    elif type(value) is list:
        for v in value:allrefs(v)


def normal(model):
    value=json.loads(wire(model));value['roots'].sort()
    for k in ('t','m'):value['seed'][k].sort()
    for row in value['inventory']['placements']:
        row['t'].sort();row['m'].sort()
    value['inventory']['placements'].sort(key=lambda r:r['id'])
    value['pair_nogoods'].sort();value['unary_nogoods'].sort()
    return value


def process(name,p):
    paths=dict(started='run/'+name+'/started.json',invocation='run/'+name+'/invocation.json',
        observer='run/'+name+'/observer.json',result='data/'+name+'/result.json')
    values={};parse_errors={}
    for key,path in paths.items():
        if local(path).exists():
            try:values[key]=read(path)
            except (ValueError,UnicodeError,EOFError) as error:
                need(key=='result','MALFORMED_PROCESS_RECEIPT')
                parse_errors[key]=type(error).__name__+':'+str(error)
    result=values.get('result');s=values.get('started');i=values.get('invocation');o=values.get('observer')
    clean=False
    if s is not None:
        need(s['phase']==name and type(s['pid']) is int and s['pid']>0,'STARTED_PHASE_PID')
        same(s['protocol'],reference(PROTOCOL),'STARTED_FROZEN_PROTOCOL')
    for v in (i,o):
        if v is not None:need(v['phase']==name,'ACTUAL_PHASE_ASSOCIATION')
    if s is not None and i is not None and o is not None:
        need(type(i['pid']) is int and type(o['pid']) is int and s['pid']==i['pid']==o['pid'],'ACTUAL_PID_ASSOCIATION')
        exact(o['log']);need(o['log']['path']=='run/'+name+'/stdout.log','OWNED_LOG_PATH')
        if i.get('result') is not None:
            need(i['result'].get('complete_json') is True,'INVOCATION_RESULT_COMPLETE_JSON')
            exact(i['result']);need(i['result']['path']==paths['result'],'EXACT_RESULT_PATH')
            need(result is not None and i['scientific_status']==result['status'],'SCIENTIFIC_STATUS_ASSOCIATION')
        clean=(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
            and i['status']=='COMPLETE' and i['error_type'] is None and i.get('result') is not None
            and result is not None and all(o[k] is None for k in ('guard_reason','observer_error','reap_error','postcheck_error'))
            and i['postcheck_error'] is None and i['frozen_postcheck']==o['frozen_postcheck']==p['status'])
    if result is not None:allrefs(result)
    return dict(name=name,process_status='CLEAN_RECORDED_PHASE' if clean else
        ('NOT_RUN' if not values and not parse_errors else 'FAILED_OR_INCOMPLETE_PROCESS'),
        native_exit_code=None if o is None else o.get('native_exit_code'),scientific_status=None if result is None else result['status'],
        process_clean=clean,scientific_admitted=clean and result['status']==p['admitted_statuses'][name],
        pid=None if o is None else o.get('pid'),parse_errors=parse_errors,
        refs={k:reference(path) for k,path in paths.items() if local(path).exists()},
        costs=dict(worker_seconds=None if i is None else i.get('seconds'),observer_seconds=None if o is None else o.get('seconds'),
            worker_maxrss=None if i is None else i.get('maxrss'),worker_maxrss_units=None if i is None else i.get('maxrss_units'),
            sampled_peak_rss_bytes=None if o is None else o.get('peak_observed_rss_bytes'))),result


def raw_join(model,raw,c):
    normalized=normal(model);binding=sha(normalized)
    need(raw['model_sha256']==binding or raw['status']=='UNKNOWN' and raw['model_sha256'] is None,'RAW_MODEL_HASH')
    for endpoint in ('entry','final','restored'):
        value=raw[endpoint+'_state'];digest=raw['state_hashes'][endpoint]
        need(digest is None if value is None else sha(value)==digest,'ENDPOINT_BYTE_HASH')
    if raw['entry_state'] is not None:same(raw['entry_state'],raw['restored_state'],'EXACT_ENDPOINT_RESTORATION')
    total=raw['event_extent']['total'];retained=len(raw['events']);h=hashlib.sha256()
    need(raw['event_extent']['retained']==retained<=total,'EVENT_PREFIX_CENSUS')
    for j,e in enumerate(raw['events']):
        need(type(e['seq']) is int and e['seq']==j,'EVENT_SEQUENCE');h.update(wire(e))
    if retained==total:need(h.hexdigest()==raw['event_extent']['sha256'],'FULL_EVENT_STREAM_HASH')
    admitted='UNKNOWN'
    if c['status']=='VERIFIED':
        need(raw['status'] in ('SAT','UNSAT') and c['run_status']==raw['status'] and c['event_coverage']=='COMPLETE'
             and retained==total==c['counts']['decision_events_checked'],'COMPLETE_SEMANTIC_ASSOCIATION')
        need(c['model_sha256']==binding and c['event_sha256']==raw['event_extent']['sha256'],'C_SCOPE_HASHES')
        need(c['bounded_absence'] is (raw['status']=='UNSAT'),'SCOPED_ABSENCE_BOOL')
        need(c['claim']==('SEMANTIC_COMPLETE_SAT_CERTIFICATE' if raw['status']=='SAT'
             else 'SEMANTIC_COMPLETE_FINITE_EXHAUSTION'),'EXACT_SEMANTIC_CLAIM')
        admitted='POINT_SAT' if raw['status']=='SAT' else 'BOUNDED_EXHAUSTION'
        if raw['status']=='SAT':
            selected=raw['selected'];need(selected==sorted(set(selected)),'EXACT_SELECTED_IDS')
            byid={r['id']:r for r in normalized['inventory']['placements']}
            same(raw['certificate']['placements'],[byid[x] for x in selected],'WHOLE_SELECTED_POINT_ROWS')
        else:need(raw['selected']==[] and raw['certificate'] is None,'NO_UNSAT_PROOF_CERTIFICATE')
    else:
        need(c['bounded_absence'] is False,'UNADMITTED_C_NEVER_ABSENCE')
        if c['status']=='REJECTED':admitted='REJECTED_ASSURANCE'
    if raw['status']=='UNKNOWN':
        need(raw['selected']==[] and raw['certificate'] is None and raw['final_state'] is None,'UNKNOWN_NO_COMMITTED_CERTIFICATE')
    return dict(raw_status=raw['status'],reason=raw['reason'],semantic_status=c['status'],
        semantic_reason=c.get('reason'),point_admission=admitted,bounded_absence=c['bounded_absence'],
        model_sha256=binding,event_payload_coverage='COMPLETE_EMITTED_PAYLOAD' if retained==total else 'RETAINED_PREFIX',
        semantic_certificate_scope=c.get('claim') if c['status']=='VERIFIED' else 'NO_COMPLETE_PROOF_OR_REFUTATION',
        events_retained=retained,events_emitted=total,stats=raw['stats'],
        scope='Saved semantic receipt and full endpoint/event byte association, not a new replay or observed intermediate producer graph.')


def engine(refs):
    model=readref(refs['model']);raw=readref(refs['raw']);c=readref(refs['semantic'])
    answer=raw_join(model,raw,c);answer['refs']=refs
    return answer,raw


def native_projection(refs,statement,selected,identifier,role,prepared_scope,collector=None):
    mk='adapter_decoded' if 'adapter_decoded' in refs else 'decoded'
    nk='independent_decoded';bk='native_receipt' if 'native_receipt' in refs else 'native'
    m=readref(refs[mk]);n=readref(refs[nk]);b=readref(refs[bk])
    need(m['status']==n['status']=='UNVERIFIED_NATIVE_CERTIFICATE','BOTH_NATIVE_DECODERS')
    for key in PROJECTION:same(m[key],n[key],'TWO_DECODER_CONTENT:'+key)
    same(m['scope'],prepared_scope,'EXACT_NATIVE_PREPARED_SCOPE')
    same(m['statement'],statement,'ORIGINAL_NATIVE_STATEMENT');same(m['selected'],sorted(selected),'ACTUAL_SELECTED_PROJECTION')
    need(m['selected_sha256']==sha(sorted(selected)) and m['original_statement_sha256']==sha(statement),'NATIVE_BINDING_HASHES')
    need(b['status']=='VERIFIED' and type(b['checked_lines']) is int and b['checked_lines']==len(m['proof']),'COMPLETE_NATIVE_RECEIPT')
    rule_counts=Counter(line['rule'] for line in m['proof'])
    need(set(rule_counts)<=set(NATIVE_RULES),'NO_HIDDEN_NATIVE_PROOF_RULE')
    need(type(b['rule_counts']) is dict and set(b['rule_counts'])==set(NATIVE_RULES)
         and all(type(x) is int and x>=0 for x in b['rule_counts'].values()),'COMPLETE_NATIVE_RULE_COUNT_TYPES')
    same(b['rule_counts'],{rule:rule_counts[rule] for rule in NATIVE_RULES},'ALL_NATIVE_RULE_COUNTS_BOUND_TO_PROOF')
    need(sum(b['rule_counts'].values())==b['checked_lines'],'NATIVE_RULE_COUNT_WHOLE_LENGTH')
    need(m['proof'] and m['proof'][-1]['formula']==statement['goal'],'UNCHANGED_PROOF_GOAL')
    if 'native_proof' in refs:same(readref(refs['native_proof']),m['proof'],'SAVED_WHOLE_PROOF_BYTES')
    if 'projection' in refs:
        projection=readref(refs['projection'])
        need(projection['adapter_decoded_sha256']==sha(m) and projection['independent_decoded_sha256']==sha(n),'PROJECTION_RECEIPT_CONTENT')
        need(projection['status']=='VERIFIED_LITERAL_PROJECTION' and projection['prepared_scope']==prepared_scope
             and projection['selected_sha256']==sha(sorted(selected)),'PROJECTION_ACTUAL_SCOPE_AND_SELECTION')
        same(projection['fields'],list(PROJECTION),'COMPLETE_PROJECTION_FIELD_LIST')
    record=dict(id=identifier,role=role,lines=len(m['proof']),statement_sha256=sha(statement),
        selected_sha256=sha(sorted(selected)),proof_sha256=sha(m['proof']),
        proof_ref=refs['native_proof'] if 'native_proof' in refs else dict(refs[mk],pointer='/proof'),
        native_ref=refs[bk],decoder_refs={mk:refs[mk],nk:refs[nk]},
        rules=dict(Counter(line['rule'] for line in m['proof'])),refs=refs,
        scope='Native receipt/context and exact stored decoder/proof joins only; no native kernel rerun.')
    (PROOFS if collector is None else collector).append(record)
    return record


def graph_receipts(row):
    refs=row['refs'];info,raw=engine(refs)
    observations=readref(refs['observations']);trace=readref(refs['full_graphs']);paired=readref(refs['paired_graphs'])
    need(info['point_admission'] in ('POINT_SAT','BOUNDED_EXHAUSTION')
         and trace['status']==paired['status']=='VERIFIED','COMPLETE_TINY_ASSURANCE')
    need(len(observations)==len(raw['events'])==trace['counts']['observations_checked']
         ==paired['events_checked']==len(paired['comparisons'])==row['actual_snapshots'],'ALL_TINY_OBSERVATIONS_BOUND')
    need(trace['model_sha256']==info['model_sha256'] and trace['run_status']==raw['status'],'TINY_T_MODEL_RESULT')
    for observation,event,comparison in zip(observations,raw['events'],paired['comparisons']):
        same(observation['event'],event,'ACTUAL_EVENT_ORDER')
        need(comparison['equal'] is True and comparison['seq']==event['seq']
             and comparison['kind']==event['kind'] and comparison['actual_sha256']
             ==comparison['reconstructed_sha256']==sha(observation['state']),'C_TO_ACTUAL_MAP_ASSOCIATION')
    need(('raw_status' not in row or row['raw_status']==raw['status']) and row['semantic_status']==row['full_graph_status']
         ==row['paired_graph_status']=='VERIFIED' and row['engine_calls']==1,'TINY_ROW_STATUS_CENSUS')
    if 'metrics' in row:same(row['metrics'],raw['stats'],'TINY_ACTUAL_STATS')
    return info,raw,len(observations)


def oracle_covers(ref,model_sha):
    value=readref(ref)
    need(value['status']=='EXHAUSTED' and value['subsets_coverage']=='COMPLETE'
         and value['model_sha256']==model_sha==sha(normal(value['model'])),'COMPLETE_TINY_ORACLE_SCOPE')
    count=len(value['candidate_ids']);need(count<=16 and value['subsets_total']==1<<count
        and len(value['subsets'])==value['subsets_total'],'EVERY_TINY_SUBSET_RETAINED')
    need([r['mask'] for r in value['subsets']]==list(range(1<<count)),'SUBSET_MASK_CENSUS')
    expected=[dict(mask=r['mask'],selected=r['selected']) for r in value['subsets'] if r['solution'] is True]
    same(value['solutions'],expected,'SOLUTIONS_ARE_SAVED_TRUE_SUBSETS')
    need(value['exists'] is bool(expected) and value['witness_exists'] is bool(expected),'ORACLE_EXISTS_ASSOCIATION')
    covers=sorted(wire(sorted(r['selected'])).decode('ascii') for r in expected)
    need(len(covers)==len(set(covers)),'DISTINCT_COMPLETE_COVERS')
    return covers,dict(status=value['status'],exists=value['exists'],solutions=len(covers),
        subsets=value['subsets_total'],model_sha256=model_sha,receipt=ref)


def rank_controls(rows):
    ids=['boolean-rank','foreign-exclusion','missing-guard','wrong-filter','zero-work']
    need([r['id'] for r in rows]==ids,'ALL_FIVE_DECLARED_RANK_CONTROLS')
    output=[]
    for row in rows:
        readref(row['input']);receipt=readref(row['receipt'])
        expected='UNKNOWN' if row['id']=='zero-work' else 'REJECTED'
        need(row['expected']==row['status']==receipt['status']==expected,'RANK_CONTROL_EXPECTATION')
        need(receipt['bounded_absence'] is False and receipt['learned'] is False,'RANK_CONTROL_NOT_PROOF_OR_LEARNING')
        output.append(dict(id=row['id'],status=receipt['status'],reason=receipt.get('reason'),
            seconds=row['seconds'],input=row['input'],receipt=row['receipt']))
    return output


def rank_associations(prepared,base,packet,receipt,marked,control):
    need(packet['schema']=='Rank-pruning-analysis-v1' and packet['status']=='CANDIDATE'
         and receipt['status']=='VERIFIED_REDUNDANT_RANK_CONSTRAINT','COMPLETED_RANK_AND_INDEPENDENT_GATE')
    bindings=dict(catalogue_sha256=sha(prepared['catalogue']),prepared_scope=prepared['binding']['scope'],
        base_model_sha256=sha(normal(base)),slots=prepared['binding']['slots'])
    same(packet['bindings'],bindings,'RANK_INPUT_BYTES');same(receipt['bindings'],bindings,'V_INPUT_BYTES')
    n=len(prepared['catalogue']['formulas']);table=packet['ranks']
    need(type(table) is list and len(table)==n,'FULL_SAVED_RANK_TABLE')
    for fid,pair in enumerate(table,1):
        need(type(pair) is list and len(pair)==2 and type(pair[0]) is int and pair[0]==fid
             and (pair[1] is None or type(pair[1]) is int and 1<=pair[1]<=n),'SAVED_RANK_ENTRY_TYPES')
    forbidden=packet['forbidden'];rows=base['inventory']['placements'];ids=[r['id'] for r in rows]
    need(type(forbidden) is list and forbidden==sorted(set(forbidden)) and set(forbidden)<=set(ids),'SAVED_FORBIDDEN_MEMBERSHIP')
    need([r[0] for r in packet['reasons']]==forbidden,'SAVED_REASON_CENSUS')
    need(receipt['ranks_sha256']==sha(table) and receipt['forbidden_sha256']==sha(forbidden)
         and receipt['reasons_sha256']==sha(packet['reasons']),'V_COMPLETE_PACKET_HASH_ASSOCIATION')
    need(receipt['bounded_absence'] is False and receipt['learned'] is False
         and receipt['preservation']=='ALL_ORIGINAL_COMPLETE_POINT_SOLUTIONS_INCLUDING_PAD_AND_UNUSED_ACTIVE_FACTS','RANK_REDUNDANCY_NOT_ABSENCE_OR_LEARNING')
    for key in ('formulas','rows','slots','zero_definitions','mp_definitions','gen_definitions'):
        need(type(receipt['counts'][key]) is int and receipt['counts'][key]==prepared['census'][key],'V_CENSUS:'+key)
    need(type(receipt['counts']['forbidden_rows']) is int and receipt['counts']['forbidden_rows']==len(forbidden),'V_FORBIDDEN_CENSUS')
    expected=dict(base=sha(normal(base)),marked=sha(normal(marked)),control=sha(normal(control)))
    same(receipt['model_bindings'],expected,'V_ALL_ACTUAL_MODELS')
    for model in (marked,control):
        need(set(model)==set(base),'NO_NEW_MODEL_FIELDS')
        for key in ('schema','capacity','roots','pair_nogoods'):same(model[key],base[key],'UNCHANGED_MODEL:'+key)
        need(model['inventory']['kind']=='EXPLICIT' and len(model['inventory']['placements'])==len(rows),'ALL_ROWS_RETAINED')
    need(base['pair_nogoods']==base['unary_nogoods']==marked['pair_nogoods']==marked['unary_nogoods']==[],'BASE_AND_MARKED_ORDINARY_FILTERS_EMPTY')
    need(marked['version']==base['version']+':rank-marked-v1' and control['version']==base['version']+':rank-filter-v1','RANK_MODEL_VERSIONS')
    same(control['unary_nogoods'],forbidden,'MATCHED_UNARY_FILTER');same(control['seed'],base['seed'],'CONTROL_OLD_SEED')
    same(marked['seed'],dict(t=base['seed']['t'],m=sorted(base['seed']['m']+[[SITE,'0']])),'LITERAL_GUARD_ZERO')
    points=set(base['roots'])
    for kind in ('t','m'):points.update(p for p,v in base['seed'][kind])
    bad=set(forbidden)
    for row,m,f in zip(rows,marked['inventory']['placements'],control['inventory']['placements']):
        points.update(p for p,v in row['t']+row['m']);same(f,row,'FILTER_RETAINS_COMPLETE_OLD_ROW')
        same(m,dict(row,m=sorted(row['m']+([[SITE,'1']] if row['id'] in bad else []))),'ONLY_CERTIFIED_ROW_GUARD_ADDITION')
    need(SITE not in points,'FRESH_MARK_ONLY_SITE')
    return dict(status=receipt['status'],bindings=bindings,model_bindings=expected,
        counts=receipt['counts'],forbidden_count=len(forbidden),forbidden_sha256=sha(forbidden),
        ranks_sha256=sha(table),reasons_sha256=sha(packet['reasons']),work=receipt['work'],seconds=receipt['seconds'],
        learned=False,bounded_absence=False,
        scope='Saved complete V packet/model/hash associations and exact overlay bytes, without recomputing ranks, producer closure or mathematical preservation.')


def planner_receipt(result,prepared,base):
    need(result['schema']=='Conventional-proof-search-v1','CONVENTIONAL_SCHEMA')
    if result['status']=='FOUND_CANDIDATE':
        selected=result['selected'];ids={r['id'] for r in prepared['universe']}
        need(selected==sorted(set(selected)) and set(selected)<=ids and len(selected)==prepared['binding']['slots'],'CONVENTIONAL_ORIGINAL_SELECTED_IDS')
        need(result['selected_sha256']==sha(selected),'CONVENTIONAL_SELECTED_HASH')
        need(result['bindings']['catalogue_sha256']==sha(prepared['catalogue'])
             and result['bindings']['prepared_scope']==prepared['binding']['scope']
             and result['bindings']['slots']==prepared['binding']['slots']
             and result['bindings']['base_model_sha256']==sha(normal(base)),'CONVENTIONAL_ORIGINAL_CONTEXT')
    else:
        need(result['status'] in ('UNKNOWN','REJECTED_INPUT'),'NO_CONVENTIONAL_FALSE_ABSENCE_STATUS')
        need('selected' not in result,'NO_INVENTED_PLAN_ON_REFUSAL')
    return dict(status=result['status'],reason=result.get('reason'),used_rank_analysis=result['used_rank_analysis'],
        costs=result['costs'],limits=result['limits'],bounded_absence=False,
        scope='Saved specialized-control candidate/refusal only; native positive admission is a separate M/N/B join and a control failure is not finite absence.')


def existing_qualification(result):
    qualification_proofs=[]
    need(result['schema']=='Rank-search-qualification-v1' and result['status']=='QUALIFIED','QUALIFICATION_RESULT')
    original=readref(result['original_qualification']);need(original['status']=='QUALIFIED','FRESH_ORIGINAL_QUALIFICATION')
    same(original['counts'],result['original_counts'],'ORIGINAL_QUALIFICATION_COUNTS')
    declarations=read('input/qualification-cases-v1.json')['cases']
    need(len(original['cases'])==20 and len(original['logical'])==2 and len(original['controls'])==9,'ORIGINAL_20_PLUS_TWO_AND_NINE_CONTROLS')
    need([r['id'] for r in original['cases']]==[r['id'] for r in declarations],'ALL_ORIGINAL_TINY_CASE_IDS')
    original_maps=0;original_oracles=[]
    for declared,row in zip(declarations,original['cases']):
        info,raw,maps=graph_receipts(row);original_maps+=maps
        need(raw['status']==declared['expected']['raw_status'],'PROSPECTIVE_TINY_RAW_STATUS')
        covers,summary=oracle_covers(row['oracle'],info['model_sha256'])
        need(bool(covers) is (raw['status']=='SAT'),'TINY_ORACLE_AND_ACTUAL_EXISTENCE');original_oracles.append(summary)
    engine_controls=Counter()
    for row in original['controls']:
        if row['id']=='max-nodes-zero':
            info,raw=engine(row['refs']);need(raw['status']=='UNKNOWN' and info['point_admission']=='UNKNOWN','ZERO_NODE_IS_UNKNOWN')
            engine_controls['UNKNOWN']+=1
        else:
            receipt=readref(row['receipt']);need(receipt['status']=='REJECTED','INVALID_ENGINE_CONTROL_REJECTED')
            engine_controls['REJECTED']+=1
    for row in original['logical']:
        info,raw,maps=graph_receipts(row['engine']);original_maps+=maps
        prepared=readref(row['refs']['prepared']);oracle_covers(row['refs']['oracle'],info['model_sha256'])
        need(info['point_admission']=='POINT_SAT','LOGICAL_QUALIFIER_ACTUAL_POSITIVE')
        native_projection(row['refs'],prepared['statement'],raw['selected'],'qual-'+row['id'],'QUALIFICATION',prepared['binding']['scope'],qualification_proofs)
    need(original_maps==original['counts']['actual_tiny_snapshots']+original['counts']['actual_logical_snapshots']==176,'ALL_176_ORIGINAL_MAPS')
    extra=read('input/rank-qualification-declarations-v1.json')['cases']
    expected_ids=[r['id'] for r in original['logical']]+[r['id'] for r in extra]
    need([r['id'] for r in result['rank_cases']]==expected_ids and len(expected_ids)==6,'ALL_SIX_PROSPECTIVE_RANK_CASES')
    cases=[];rank_maps=0;rank_engine_calls=0;rank_oracle_calls=0
    for row in result['rank_cases']:
        need(row['status']=='QUALIFIED','TINY_RANK_CASE_QUALIFIED')
        refs=row['refs'];prepared=readref(refs['prepared']);base=readref(refs['base_model'])
        packet=readref(refs['analysis']);receipt=readref(refs['rank_receipt'])
        need([r['lane'] for r in row['actual']]==[r['lane'] for r in row['oracle']]
             ==['BASE','RANK_MARKS','RANK_FILTER'],'TINY_THREE_MATCHED_LANES')
        lane_models={r['lane']:readref(r['refs']['model']) for r in row['actual']}
        same(lane_models['BASE'],base,'TINY_BASE_MODEL_BYTES')
        rank_info=rank_associations(prepared,base,packet,receipt,lane_models['RANK_MARKS'],lane_models['RANK_FILTER'])
        cover_sets=[];oracle_summaries=[]
        for actual,oracle in zip(row['actual'],row['oracle']):
            info,raw,maps=graph_receipts(actual);rank_maps+=maps;rank_engine_calls+=1
            covers,summary=oracle_covers(oracle['receipt'],info['model_sha256']);rank_oracle_calls+=1
            need(oracle['solutions']==len(covers) and bool(covers) is (raw['status']=='SAT'),'RANK_TINY_EXISTENCE_JOIN')
            cover_sets.append(covers);oracle_summaries.append(dict(lane=actual['lane'],**summary))
        same(cover_sets[0],cover_sets[1],'EVERY_ORIGINAL_COVER_SURVIVES_MARKS')
        same(cover_sets[0],cover_sets[2],'EVERY_ORIGINAL_COVER_SURVIVES_FILTER')
        controls=rank_controls(row['controls']);search=readref(refs['conventional_search'])
        plan=planner_receipt(search,prepared,base);need(plan['status']==row['conventional_status'],'QUALIFIED_CONVENTIONAL_STATUS')
        if cover_sets[0]:
            need(search['status']=='FOUND_CANDIDATE' and wire(search['selected']).decode('ascii') in cover_sets[0],'ACTUAL_CONTROL_CANDIDATE_IS_A_COMPLETE_TINY_COVER')
            native=native_projection(refs['conventional_native'],prepared['statement'],search['selected'],
                'qual-plan-'+row['id'],'QUALIFICATION_SPECIALIZED_CONTROL',prepared['binding']['scope'],qualification_proofs)
            need(row['native_status']=='VERIFIED_NATIVE_PROOF' and row['native_lines']==native['lines'],'QUALIFIED_CONTROL_NATIVE_LINES')
        else:
            need(search['status']=='UNKNOWN' and row['native_status'] is None,'SPECIALIZED_FAILURE_NOT_ABSENCE')
        stopped=readref(refs['conventional_zero_work']);need(stopped['status']=='UNKNOWN','CONVENTIONAL_ZERO_WORK_UNKNOWN')
        if 'input_admission' in row:
            admission=row['input_admission'];model_receipt=readref(admission['model'])
            need(model_receipt['status']=='VERIFIED' and model_receipt['model_sha256']==sha(prepared['model'])
                 and model_receipt['catalogue_sha256']==sha(prepared['catalogue']),'EXTRA_COMPLETE_GENERIC_MODEL_GATE')
            if 'basis' in admission:need(readref(admission['basis'])['status']=='VERIFIED','EXTRA_GROUND_BASIS_GATE')
            native_zeros=readref(admission['zeros']);need([r['id'] for r in native_zeros]
                ==[r['id'] for r in prepared['catalogue']['zeros']],'ALL_EXTRA_ZERO_IDS')
            for z in native_zeros:
                b=readref(z['receipt']);need(b['status']=='VERIFIED' and b['checked_lines']==1,'EXTRA_NATIVE_ZERO_CHECK')
        cases.append(dict(id=row['id'],rank=rank_info,original_rows=len(base['inventory']['placements']),
            cover_count=len(cover_sets[0]),all_three_cover_sets_sha256=sha(cover_sets[0]),oracles=oracle_summaries,
            controls=controls,conventional=plan,refs=refs))
    need(rank_maps==result['rank_actual_snapshots']==129 and rank_engine_calls==result['total_rank_engine_calls']==18
         and rank_oracle_calls==result['total_rank_oracle_calls']==18,'ALL_RANK_QUALIFICATION_GRAPH_ORACLE_COUNTS')
    return dict(status='PASS_SAVED_QUALIFICATION_ASSOCIATIONS',native_proofs=qualification_proofs,original_engine_calls=22,original_actual_maps=original_maps,
        original_engine_controls=dict(engine_controls),original_oracles=original_oracles,
        rank_engine_calls=rank_engine_calls,rank_actual_maps=rank_maps,rank_oracle_calls=rank_oracle_calls,cases=cases,
        scope='Current actual saved C/T/paired maps, complete tiny subset-cover sets and native receipts bound by hashes/census. No engine, rank checker, oracle or native helper replay.')


def preparation(result,declaration_path="input/arithmetic-declaration-v1.json"):
    r=result['refs'];allrefs(r)
    declaration=readref(r['declaration']);compiled=readref(r['compiled']);generation=readref(r['generation'])
    prepared=readref(r['prepared']);base=readref(r['model']);rf=readref(r['rf_receipt'])
    bridge=readref(r['bridge']);q=readref(r['bridge_receipt']);n=readref(r['model_receipt'])
    same(declaration,read(declaration_path),'ACTUAL_FROZEN_COLD_DECLARATION')
    same(prepared['statement'],declaration['problem'],'ORIGINAL_TARGET_STATEMENT')
    need(rf['status']==q['status']==n['status']=='VERIFIED','FRESH_RF_BRIDGE_MODEL_ADMISSION')
    need(rf['declaration_sha256']==sha(declaration) and rf['compiled_core_sha256']==generation['compiled_core_sha256']
         ==sha({k:v for k,v in compiled.items() if k not in ('costs','scope')}),'FULL_COLD_RF_COMPILED_CORE')
    same(bridge['catalogue'],prepared['catalogue'],'FULL_BRIDGE_CATALOGUE');same(q['bindings'],bridge['bindings'],'BRIDGE_RECEIPT_BINDINGS')
    same(bridge['bindings'],dict(original_statement_sha256=sha(prepared['statement']),
        declaration_sha256=sha(declaration),rf_compiled_core_sha256=rf['compiled_core_sha256'],
        rf_generation_sha256=sha(generation),catalogue_sha256=sha(prepared['catalogue'])),'FULL_BRIDGE_CURRENT_SOURCE_BINDINGS')
    same(result['prepared_binding'],prepared['binding'],'PREPARED_SCOPE');same(n['census'],prepared['census'],'FULL_N_MODEL_CENSUS')
    need(n['model_sha256']==sha(prepared['model']) and n['universe_sha256']==sha(prepared['universe'])
         and n['catalogue_sha256']==sha(prepared['catalogue'])==bridge['bindings']['catalogue_sha256']
         and n['original_statement_sha256']==sha(prepared['statement']),'WHOLE_PREPARED_MODEL_UNIVERSE_CATALOGUE')
    same(compiled['logical_basis']['formulas'],prepared['catalogue']['formulas'],'ALL_ORIGINAL_RF_FORMULAS_RETAINED')
    zeros=readref(r['zero_native_receipts']);need(len(zeros)==len(compiled['zero_instances'])
        ==prepared['census']['zero_definitions']==result['ZERO_checks'],'EVERY_FRESH_NATIVE_ZERO')
    for z,b in zip(compiled['zero_instances'],zeros):
        need(z['id']==b['id'] and z['formula_id']==b['formula_id'] and sha(z['line'])==b['native_line_sha256']
             and b['receipt']['status']=='VERIFIED' and type(b['receipt']['checked_lines']) is int
             and b['receipt']['checked_lines']==1,'EXACT_NATIVE_ZERO_PAYLOAD_HASH')
    for key in ('capacity','roots','seed','inventory'):same(base[key],prepared['model'][key],'UNCHANGED_LITERAL_MIGRATION:'+key)
    need(base['schema']=='Z-growing-point-model-v3' and base['version']==prepared['model']['version']+':engine-v4'
         and base['pair_nogoods']==base['unary_nogoods']==[] and sha(normal(base))==result['scope_sha256'],'EXACT_ORIGINAL_ENGINE_BASE')
    return dict(status='PASS_SAVED_COLD_PREPARATION_ASSOCIATIONS',census=prepared['census'],ZERO_checks=len(zeros),
        scope_sha256=result['scope_sha256'],costs=result['costs'],refs=r,
        scope='Fresh current compilation/profile/complete-model/native-ZERO receipt associations; no compiler, model or native call replay.'),dict(
        prepared=prepared,base=base,statement=prepared['statement'])



def environment():
    p=read(PROTOCOL)
    need(p['schema']=='Receptor-family-protocol-v1' and p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','CURRENT_FROZEN_PROTOCOL')
    roster=read('input/transfer-cases-v1.json')
    need(roster['schema']=='Receptor-transfer-cases-v1' and roster['no_RL'] is True,'DECLARED_CASE_ROSTER')
    ids=[case['id'] for case in roster['cases']]
    same(ids,['seen','unary-transfer','nested-transfer'],'ALL_THREE_PROSPECTIVE_CASES')
    phases=['qualify','learn']+[prefix+'-'+name for name in ids for prefix in ('prepare','evaluate')]
    same(p['phases'],phases,'EXACT_CURRENT_PHASES')
    same(p['admitted_statuses'],{name:'QUALIFIED' if name=='qualify' else 'LEARNING_RECORDED'
        if name=='learn' else 'CASE_RECORDED' for name in phases},'WORKFLOW_STATUSES_NOT_PROOF')
    admission=read('review/root-source-admission-v1.json')
    need(admission['status']=='PASS_SOURCE_REVIEW_BEFORE_FREEZE','SOURCE_ADMISSION')
    names={'review/root-source-admission-v1.json'}
    for folder in ('source','reference','input','plan'):
        for path in (ROOT/folder).rglob('*'):
            need(not path.is_symlink(),'NO_FROZEN_SYMLINK')
            if path.is_file():
                need(path.suffix!='.pyc' and '__pycache__' not in path.parts,'NO_FROZEN_BYTECODE')
                names.add(path.relative_to(ROOT).as_posix())
    for ref in admission['reviewed']:exact(ref);names.add(ref['path'])
    same([reference(name) for name in sorted(names)],p['files'],'EXACT_FROZEN_CURRENT_FILE_SET')
    for ref in (p['master'],p['runtime']['executable']):
        same(filepin(Path(ref['path'])),{k:ref[k] for k in ('bytes','sha256')},'CURRENT_MASTER_RUNTIME_BYTES')
    same(filepin(local('reference/basic-tiling-algorithm.md')),
         {k:p['master'][k] for k in ('bytes','sha256')},'CURRENT_MASTER_COPY')
    executable=Path(sys.executable).resolve()
    actual=dict(executable=dict(path=str(executable),**filepin(executable)),version=sys.version,
        isolated=sys.flags.isolated,no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)
    same(actual,p['runtime'],'PINNED_ISOLATED_AUDITOR_RUNTIME')
    return p,roster,dict(file_count=len(names),exact_set=True,current_master=p['master'],
        current_runtime=p['runtime'],limits=p['limits'])


def native_counts(receipt,proof):
    need(receipt['status']=='VERIFIED' and type(receipt['checked_lines']) is int
         and receipt['checked_lines']==len(proof),'WHOLE_NATIVE_RECEIPT')
    counts=Counter(line['rule'] for line in proof)
    need(set(counts)<=set(NATIVE_RULES),'NO_FOREIGN_NATIVE_RULE')
    need(type(receipt['rule_counts']) is dict and set(receipt['rule_counts'])==set(NATIVE_RULES)
         and all(type(value) is int and value>=0 for value in receipt['rule_counts'].values()),'NATIVE_RULE_COUNTER_TYPES')
    same(receipt['rule_counts'],{rule:counts[rule] for rule in NATIVE_RULES},'NATIVE_RULE_COUNTER_PROOF_JOIN')
    need(sum(receipt['rule_counts'].values())==len(proof),'NATIVE_RULE_COUNTER_TOTAL')


def attempt(refs,profile=None):
    info,raw=engine(refs)
    c=readref(refs['semantic'])
    if profile is not None:need(c['order_profile']==profile,'CURRENT_C4_ORDER_PROFILE')
    if c['status']=='VERIFIED':
        metadata=c['ordering_metadata']
        need(metadata['reported_calls']==raw['stats']['ordering_calls']
             and metadata['replayed_branches']==raw['stats']['branches']
             and metadata['unjoined_calls']==0,'COMPLETE_C4_CALLBACK_ASSOCIATION')
    if refs['raw']['path'].endswith('/raw.json.gz'):
        path=refs['raw']['path'][:-len('raw.json.gz')]+'attempt.json'
        if local(path).exists():
            a=read(path);need(a['engine_calls']==1 and type(a['engine_calls']) is int,'SINGLE_ACTUAL_ENGINE_CALL')
            need(a['raw_status']==raw['status'] and a['semantic_status']==c['status'],'ENGINE_ATTEMPT_STATUS')
            same(a['raw_stats'],raw['stats'],'ENGINE_ATTEMPT_ACTUAL_STATS')
            for key,ref in a['refs'].items():same(ref,refs[key],'ENGINE_ATTEMPT_REF:'+key)
            obs=readref(refs['observations']);need(a['actual_snapshots']==len(obs),'ACTUAL_OBSERVATION_COUNT')
            info['attempt']=reference(path)
            info['costs']=dict(engine_seconds=a['engine_seconds'],semantic_seconds=a['semantic_seconds'])
    return info,raw


def callback_qualification(result):
    need(result['schema']=='Callback-order-qualification-v1' and result['status']=='QUALIFIED','FRESH_CALLBACK_QUALIFICATION')
    ids=['lexical-default','reverse','reverse-rollback','prefix-rollback','forced-before-prefix']
    need([row['id'] for row in result['cases']]==ids,'ALL_CALLBACK_FIXTURES')
    records=[];maps=0
    for row in result['cases']:
        info,raw,n=graph_receipts(row);maps+=n
        requests=readref(row['refs']['requests'])
        profile='LEXICAL_V1' if row['mode']=='LEXICAL_DEFAULT' else 'COMPLETE_PERMUTATION_V1'
        c=readref(row['refs']['semantic'])
        need(raw['status']=='SAT' and c['order_profile']==row['checker_profile']==profile,'TINY_CALLBACK_COMPLETE_PROFILE')
        need(type(row['ordering_calls']) is int and row['ordering_calls']==len(requests)
             ==raw['stats']['ordering_calls'] and row['branches']==raw['stats']['branches'],'TINY_CALLBACK_COUNTS')
        need(len(requests)==(0 if profile=='LEXICAL_V1' else raw['stats']['branches']),'COMPLETE_BRANCH_CALLBACK_CENSUS')
        branches=[event for event in raw['events'] if event['kind']=='BRANCH']
        for query,event in zip(requests,branches):
            need(query['model_sha256']==info['model_sha256'] and query['point']==event['point'],'CALLBACK_ACTUAL_POINT_SCOPE')
            same(query['legal'],event['data']['legal'],'CALLBACK_ACTUAL_DOMAIN')
            same(query['generation'],event['data']['generation'],'CALLBACK_ACTUAL_GENERATION')
        records.append(dict(id=row['id'],actual_maps=n,ordering_calls=len(requests),profile=profile,refs=row['refs']))
    mutants=[]
    for row in result['mutants']:
        readref(row['input']);r=readref(row['receipt'])
        need(row['status']==r['status']=='REJECTED' and r['bounded_absence'] is False,'CALLBACK_MUTANT_REJECTED')
        mutants.append(dict(id=row['id'],status=r['status'],reason=r['reason'],input=row['input'],receipt=row['receipt']))
    need(len(mutants)==11 and len({row['id'] for row in mutants})==11,'ALL_ELEVEN_CALLBACK_MUTANTS')
    hook=result['hook_unknown'];info,raw=attempt(hook['refs'],'COMPLETE_PERMUTATION_V1')
    need(raw['status']==info['semantic_status']=='UNKNOWN' and info['bounded_absence'] is False,'HOOK_RESOURCE_NOT_ABSENCE')
    requests=readref(hook['requests']);c=readref(hook['refs']['semantic'])
    need(raw['stats']['ordering_calls']==len(requests)==1 and raw['stats']['branches']==0
         and c['ordering_metadata']['unjoined_calls']==1,'ACTUAL_INTERRUPTED_CALLBACK')
    same(result['counts'],dict(complete_engine_calls=5,unknown_engine_calls=1,
        actual_complete_graphs=maps,rejected_mutants=11),'CALLBACK_QUALIFICATION_CENSUS')
    return dict(status='PASS_SAVED_CALLBACK_ASSOCIATIONS',records=records,mutants=mutants,
        unknown=info,actual_maps=maps,scope='Actual retained tiny maps and callback metadata joins only; no engine/C4/T replay.')


def qualification(result):
    need(result['status']=='QUALIFIED','CURRENT_QUALIFICATION_STATUS')
    old=existing_qualification(readref(result['existing']))
    callbacks=callback_qualification(readref(result['callbacks']))
    return dict(status='PASS_SAVED_QUALIFICATION_ASSOCIATIONS',existing=old,callbacks=callbacks,
        scope='New actual qualification outputs; inherited logical examples remain qualification proofs, not new target transfer results.')


def donor_input():
    manifest=read('input/donor-manifest-v1.json')
    need(manifest['schema']=='Receptor-donor-evidence-v1' and manifest['namespace']=='input/donor','EXPLICIT_DONOR_NAMESPACE')
    entries={entry['path']:entry for entry in manifest['files']}
    need(len(entries)==len(manifest['files']) and bool(entries),'DISTINCT_DECLARED_DONOR_PATHS')
    for path,entry in entries.items():
        need(not Path(path).is_absolute() and '..' not in Path(path).parts,'DONOR_RELATIVE_PATH')
        exact(dict(entry,path='input/donor/'+path))
    physical=[]
    for path in sorted(local('input/donor').rglob('*')):
        need(not path.is_symlink(),'NO_DONOR_SYMLINK')
        if path.is_file():physical.append(path.relative_to(local('input/donor')).as_posix())
    same(physical,sorted(entries),'EXACT_PHYSICAL_DONOR_SLICE')
    def stored(name):
        need(name in entries,'DECLARED_DONOR_MEMBER_ONLY')
        return read('input/donor/'+name)
    p=stored('protocol/frozen-protocol-v1.json')
    for ref in p['files']:
        need(ref['path'] in entries,'FULL_ORIGINAL_DONOR_SOURCE_CLOSURE')
        same({k:entries[ref['path']][k] for k in ('bytes','sha256')},
             {k:ref[k] for k in ('bytes','sha256')},'DONOR_FROZEN_SOURCE_PIN')
    s,i,o=[stored('run/evaluate/'+name+'.json') for name in ('started','invocation','observer')]
    need(s['phase']==i['phase']==o['phase']=='evaluate' and type(s['pid']) is int
         and s['pid']>0 and type(i['pid']) is int and type(o['pid']) is int
         and s['pid']==i['pid']==o['pid'],'ORIGINAL_DONOR_PHASE_PID')
    need(i['status']=='COMPLETE' and i['error_type'] is None and i['postcheck_error'] is None
         and i['result']['complete_json'] is True,'ORIGINAL_DONOR_INVOCATION')
    need(o['status']=='TERMINAL' and type(o['native_exit_code']) is int and o['native_exit_code']==0
         and all(o[key] is None for key in ('guard_reason','observer_error','reap_error','postcheck_error')),'ORIGINAL_DONOR_NATIVE_EXIT')
    need(i['frozen_postcheck']==o['frozen_postcheck']==p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','ORIGINAL_DONOR_POSTCHECK')
    for ref,expected in ((s['protocol'],'protocol/frozen-protocol-v1.json'),
                         (i['result'],'data/evaluate/result.json'),(o['log'],'run/evaluate/stdout.log')):
        need(ref['path']==expected and expected in entries,'DONOR_OWNED_PROCESS_PATH')
        same({k:ref[k] for k in ('bytes','sha256')},{k:entries[expected][k] for k in ('bytes','sha256')},'DONOR_PROCESS_MEMBER_BYTES')
    # The retained whole phase contains other lanes' refs. They are metadata,
    # deliberately NOT recursively dereferenced or treated as retained proofs.
    whole=stored('data/evaluate/result.json')
    need(i['scientific_status']==whole['status']=='EVALUATED','ORIGINAL_DONOR_WORKFLOW_STATUS')
    lane=next(row for row in whole['lanes'] if row['lane']=='RANK_MARKS')
    need(lane['admitted_status']=='VERIFIED_NATIVE_POSITIVE','DECLARED_AUTOMATIC_DONOR_LANE')
    for group in ('refs','native_refs'):
        for ref in lane[group].values():
            need(ref['path'] in entries,'DECLARED_DONOR_LANE_REFERENCE')
            same({k:ref[k] for k in ('bytes','sha256')},
                 {k:entries[ref['path']][k] for k in ('bytes','sha256')},'DONOR_LANE_PHYSICAL_REFERENCE')
    declaration=stored('input/arithmetic-declaration-v1.json');proof=stored(manifest['proof'])
    model=stored('data/engine/evaluate-rank_marks/model.json.gz');raw=stored('data/engine/evaluate-rank_marks/raw.json.gz')
    need(raw['status']=='SAT','ORIGINAL_DONOR_POINT_POSITIVE')
    selected=raw['selected'];need(selected==sorted(set(selected)),'DONOR_SELECTED_IDS')
    projections=[stored('data/evaluate/rank_marks-native/'+name+'.json.gz')
                 for name in ('adapter-decoded','independent-decoded')]
    for key in PROJECTION:same(projections[0][key],projections[1][key],'DONOR_TWO_PROJECTIONS:'+key)
    decoded=projections[0]
    same(decoded['proof'],proof,'DECLARED_DONOR_PROOF_BYTES');same(decoded['statement'],declaration['problem'],'DONOR_ORIGINAL_STATEMENT')
    same(decoded['selected'],selected,'DONOR_ACTUAL_SELECTION')
    need(decoded['selected_sha256']==sha(selected) and decoded['original_statement_sha256']==sha(declaration['problem']),'DONOR_LOGICAL_BINDINGS')
    same(decoded['native_to_slot'],list(range(len(proof))),'DECLARED_DONOR_IDENTITY_SLOT_MAPPING')
    need(len(selected)==len(proof),'DONOR_ACTIVE_FULL_SLOT_COUNT')
    for row in decoded['slots']:
        need(row['active']==1 and row['slot']==row['native_line_index_or_null'],'DONOR_NO_PADDING_OR_RELOCATION')
        action=json.loads(row['cid']);need(type(action[0]) is int and action[0]==row['slot'],'DONOR_CID_SLOT')
    byid={row['id']:row for row in normal(model)['inventory']['placements']}
    same(raw['certificate']['placements'],[byid[cid] for cid in selected],'DONOR_ACTUAL_SELECTED_ROWS')
    original_native=stored('data/evaluate/rank_marks-native/native-receipt.json.gz');native_counts(original_native,proof)
    return dict(manifest=reference('input/donor-manifest-v1.json'),physical_files=len(physical),
        namespace='input/donor',original_process=dict(pid=s['pid'],native_exit_code=0),
        statement_sha256=sha(declaration['problem']),proof_sha256=sha(proof),lines=len(proof),
        proof_ref=reference('input/donor/'+manifest['proof']),
        scope='Only declared donor slice authenticated. Other-lane refs in whole old phase are unconsumed metadata; donor proof is warm training evidence, not a new target proof.'),dict(
        statement=declaration['problem'],proof=proof,model=model,raw=raw)


def qualification_rows(rows,expected):
    need([row['id'] for row in rows]==list(expected),'ALL_DECLARED_RECEPTOR_CONTROLS')
    output=[]
    for row in rows:
        inp=readref(row['input']);receipt=readref(row['receipt'])
        need(row['status']==receipt['status']==expected[row['id']],'SAVED_RECEPTOR_CONTROL_STATUS')
        output.append(dict(id=row['id'],status=receipt['status'],reason=receipt.get('reason'),
                           input=row['input'],receipt=row['receipt'],seconds=row['seconds']))
    return output


def library_qualification(value,library,donor):
    need(value['status']=='QUALIFIED','LIBRARY_QUALIFICATION_RECORDED')
    expected={'actual-provenance':'VERIFIED_PROVENANCE','donor-binding':'REJECTED',
        'prototype-binding':'REJECTED','cluster-membership':'REJECTED','goal-parameter':'REJECTED','zero-work':'UNKNOWN'}
    rows=qualification_rows(value['records'],expected)
    original=readref(value['records'][0]['input'])
    same(original['library'],library,'ACTUAL_LIBRARY_QUALIFICATION_INPUT')
    same(original['statement'],donor['statement'],'ACTUAL_DONOR_QUALIFICATION_STATEMENT')
    same(original['proof'],donor['proof'],'ACTUAL_DONOR_QUALIFICATION_PROOF')
    receipt=readref(rows[0]['receipt'])
    same(receipt['bindings'],dict(statement_sha256=sha(donor['statement']),proof_sha256=sha(donor['proof']),
        library_sha256=sha(library)),'ACTUAL_LIBRARY_QUALIFICATION_RECEIPT')
    return dict(status=value['status'],records=rows,scope='Actual X/Y local calls; corrupted inputs are qualification data, not search/theorem outcomes.')


def learning(result,donor):
    refs=result['refs'];allrefs(refs)
    semantic=readref(refs['semantic']);native=readref(refs['native'])
    info=raw_join(donor['model'],donor['raw'],semantic)
    need(info['point_admission']=='POINT_SAT' and semantic['order_profile']=='LEXICAL_V1','FRESH_CURRENT_DONOR_SEMANTIC_GATE')
    native_counts(native,donor['proof'])
    library=readref(refs['library'])
    need(result['learned_proof_count']==1 and type(result['learned_proof_count']) is int
         and result['RL'] is False and result['bounded_absence'] is False,'SINGLE_WARM_DONOR_SCOPE')
    need(result['family_status']==library['status'],'LEARNING_STATUS_JOIN')
    answer=dict(status=result['status'],family_status=library['status'],refs=refs,costs=result['costs'],
        donor_fresh_semantic=info,donor_fresh_native=refs['native'],library_admitted=False,
        scope='Warm reuse of one donor. Learned templates are provenance-bound hypotheses, never universal axioms or new target proofs.')
    if library['status']=='CANDIDATE_LIBRARY':
        same(library['donor'],dict(statement_sha256=sha(donor['statement']),proof_sha256=sha(donor['proof']),
             lines=len(donor['proof'])),'LEARNED_LIBRARY_DONOR_HASHES')
        family_ids=[row['id'] for row in library['families']];cluster_ids=[row['id'] for row in library['clusters']]
        need(family_ids==sorted(set(family_ids)) and cluster_ids==sorted(set(cluster_ids)),'DETERMINISTIC_DISTINCT_LIBRARY_IDS')
        for family in library['families']:
            need(family['id']==sha(dict(schema='Receptor-family-v1',**{k:v for k,v in family.items() if k!='id'})),'STORED_FAMILY_ID')
        for cluster in library['clusters']:
            need(cluster['id']==sha(dict(schema='Receptor-cluster-v1',**{k:v for k,v in cluster.items() if k!='id'})),'STORED_CLUSTER_ID')
        need(library['costs']['families']==len(family_ids) and library['costs']['clusters']==len(cluster_ids),'ACTUAL_LIBRARY_CENSUS')
        answer.update(families=len(family_ids),clusters=len(cluster_ids),library_sha256=sha(library))
        if 'library_receipt' in refs:
            receipt=readref(refs['library_receipt']);need(result['provenance_status']==receipt['status'],'LIBRARY_PROVENANCE_STATUS')
            if receipt['status']=='VERIFIED_PROVENANCE':
                same(receipt['bindings'],dict(statement_sha256=sha(donor['statement']),proof_sha256=sha(donor['proof']),
                     library_sha256=sha(library)),'WHOLE_LIBRARY_RECEIPT_BINDINGS')
                need(receipt['families']==len(family_ids) and receipt['clusters']==len(cluster_ids),'WHOLE_LIBRARY_RECEIPT_CENSUS')
                checks=readref(refs['qualification']);answer['qualification']=library_qualification(checks,library,donor)
                need(result['qualification_status']=='QUALIFIED','REQUIRED_LIBRARY_CONTROL_QUALIFICATION')
                answer['library_admitted']=True
    return answer,library


def rank_case(result,prepared,base):
    refs=result['refs'];allrefs(refs)
    answer=dict(status=result['status'],activation_admitted=False,refs=refs,costs=result.get('costs'),reason=result.get('reason'))
    if 'analysis' not in refs:return answer
    packet=readref(refs['analysis']);answer['analysis_status']=packet['status']
    if result['status']=='RANK_ADMITTED':
        receipt=readref(refs['rank_receipt']);marked=readref(refs['marked_model']);control=readref(refs['control_model'])
        association=rank_associations(prepared,base,packet,receipt,marked,control)
        need(result['activation_admitted'] is True and result['forbidden_count']==len(packet['forbidden']),'CASE_RANK_ADMISSION')
        same(result['prepared_scope'],prepared['binding']['scope'],'CASE_RANK_PREPARED_SCOPE')
        same(result['model_bindings'],association['model_bindings'],'CASE_RANK_MODEL_BINDINGS')
        answer.update(activation_admitted=True,association=association,
            controls=rank_controls(readref(refs['activation_controls'])))
        return answer,marked,packet
    return answer


def instance_qualification(value,statement,model,library,admitted):
    need(value['status']=='QUALIFIED','INSTANCE_QUALIFICATION_RECORDED')
    expected={'actual-instance':'VERIFIED_INSTANCE','wrong-parameter':'REJECTED','wrong-binder':'REJECTED',
        'wrong-native-payload':'REJECTED','wrong-primitive-CID':'REJECTED','wrong-receptor':'REJECTED',
        'nonliteral-model-mark':'REJECTED','zero-work':'UNKNOWN'}
    rows=qualification_rows(value['instance_records'],expected)
    actual=readref(rows[0]['input'])['instance'];need(sha(actual) in {sha(i) for i in admitted},'QUALIFIER_ACTUAL_ADMITTED_INSTANCE')
    receipt=readref(rows[0]['receipt'])
    same(receipt['bindings'],dict(model_sha256=sha(normal(model)),instance_sha256=sha(actual),
        statement_sha256=sha(statement),library_sha256=sha(library)),'QUALIFIER_ACTUAL_INSTANCE_BINDINGS')
    state_expected={'state-consistent-union':'COMPATIBLE','state-shared-member-once':'COMPATIBLE',
        'state-distinct-owner-overcapacity':'REJECTED','state-local-exclusion':'REJECTED',
        'state-restored-exclusion':'COMPATIBLE','state-foreign-model':'REJECTED',
        'state-foreign-selected':'REJECTED','state-missing-owner-is-demand-only':'COMPATIBLE'}
    states=qualification_rows(value['state_records'],state_expected)
    initial=readref(states[0]['receipt']);restored=readref(states[4]['receipt'])
    same(initial['bindings'],restored['bindings'],'SYNTHETIC_RESTORATION_BINDINGS')
    same(initial['preferred'],restored['preferred'],'SYNTHETIC_RESTORATION_PREFERENCES')
    overlap=readref(states[1]['receipt']);need(overlap['shared_members']==1,'SYNTHETIC_SHARED_MEMBER_ONCE')
    for ref in (value['admission_index'],value['state_index']):need(readref(ref)['status']=='READY','QUALIFICATION_INDEX_READY')
    fixture=value['zero_seed_fixture'];entry=fixture['admission'];inp=readref(entry['input']);r=readref(entry['receipt'])
    need(entry['status']==r['status']=='VERIFIED_INSTANCE','GENERIC_POINT_FIXTURE_CONCRETE_ADMISSION')
    same(r['bindings'],dict(model_sha256=sha(normal(inp['model'])),instance_sha256=sha(inp['instance']),
        statement_sha256=sha(statement),library_sha256=sha(library)),'MODIFIED_FIXTURE_OWN_BINDINGS')
    need(readref(fixture['state_index'])['status']=='READY','MODIFIED_FIXTURE_STATE_INDEX')
    check=fixture['check'];test=readref(check['input']);rejection=readref(check['receipt'])
    same(test['model'],inp['model'],'SAME_MODIFIED_FIXTURE_MODEL')
    need(check['status']==rejection['status']=='REJECTED' and rejection['reason']=='CURRENT_FRONTIER_POINT','INACTIVE_ZERO_POINT_REJECTION')
    stop=value['charge_stop'];readref(stop['input']);propagated=readref(stop['receipt'])
    need(propagated['status']=='PROPAGATED' and propagated['calls'],'SENTINEL_CHARGE_STOP_PROPAGATED')
    return dict(status=value['status'],instance_records=rows,state_records=states,zero_seed_fixture=fixture,
        charge_stop=stop,scope='Synthetic data requests, including modified point model, not RF model admission or observed GCTS states. No E/kernel calls inferred.')


def case_preparation(result,spec,library,donor):
    preparation_result=readref(result['preparation'])
    need(result['id']==spec['id'] and result['preparation_status']==preparation_result['status'],'CASE_PREPARATION_STATUS')
    out=dict(id=spec['id'],training_overlap=spec['training_overlap'],status=result['status'],
        preparation_status=result['preparation_status'],rank_status=result['rank_status'],
        family_status=result['family_status'],refs=dict(preparation=result['preparation'],**result['refs']),costs=result['costs'])
    if preparation_result['status']!='PREPARED':return out,None
    prep,context=preparation(preparation_result,spec['path']);out['preparation']=prep
    declaration=readref(preparation_result['refs']['declaration'])
    same(declaration,read(spec['path']),'PROSPECTIVE_CASE_DECLARATION')
    rank_result=readref(result['refs']['rank']);need(result['rank_status']==rank_result['status'],'CASE_RANK_STATUS')
    ranked=rank_case(rank_result,context['prepared'],context['base'])
    if rank_result['status']!='RANK_ADMITTED':out['rank']=ranked;return out,None
    rank,model,packet=ranked;out['rank']=rank
    context.update(model=model,rank=packet,admitted=[],proposals=None)
    if 'proposed' not in result['refs']:return out,context
    proposed=readref(result['refs']['proposed']);out['proposal_status']=proposed['status']
    if proposed['status']!='CANDIDATE_INSTANCES':return out,context
    need(library is not None,'PROPOSALS_HAVE_ADMITTED_LIBRARY')
    same(proposed['bindings'],dict(library_sha256=sha(library),statement_sha256=sha(context['statement']),
        prepared_scope=context['prepared']['binding']['scope'],model_sha256=sha(normal(model))),'CASE_PROPOSAL_BINDINGS')
    instances=proposed['instances'];ids=[row['id'] for row in instances]
    need(ids==sorted(set(ids)),'ALL_DISTINCT_SORTED_PROPOSAL_IDS')
    receipts=readref(result['refs']['instance_receipts']);admitted=readref(result['refs']['admitted'])
    need(len(receipts)==len(instances)==result['proposed_count'],'ALL_INSTANCE_RECEIPT_CENSUS')
    model_sha256=sha(normal(model));statement_sha256=sha(context['statement']);library_sha256=sha(library)
    approved=[];statuses=Counter();families={f['id']:f for f in library['families']};clusters={c['id']:c for c in library['clusters']}
    examples=[];changed=0
    for index,(instance,row) in enumerate(zip(instances,receipts)):
        need(instance['id']==sha(dict(schema='Receptor-instance-v1',**{k:v for k,v in instance.items() if k!='id'})),'CONCRETE_INSTANCE_ID')
        need(row['index']==index and type(row['index']) is int and row['instance_sha256']==sha(instance),'RECEIPT_EXACT_INSTANCE_ORDER')
        receipt=row['receipt'];statuses[receipt['status']]+=1
        if receipt['status']!='VERIFIED_INSTANCE':continue
        same(receipt['bindings'],dict(model_sha256=model_sha256,instance_sha256=sha(instance),
            statement_sha256=statement_sha256,library_sha256=library_sha256),'ACTUAL_INSTANCE_RECEIPT_SCOPE')
        same(receipt['prepared_scope'],context['prepared']['binding']['scope'],'ACTUAL_INSTANCE_PREPARED_SCOPE')
        need(instance['family_id'] in families and instance['cluster_id'] in clusters,'KNOWN_LEARNED_FAMILY_CLUSTER')
        family=families[instance['family_id']];cluster=clusters[instance['cluster_id']]
        same(receipt['cluster_cids'],[cid for slot,cid in instance['line_cids']],'RECEIPT_CLUSTER_CIDS')
        same(instance['root'],cluster['root'],'STORED_INSTANCE_CLUSTER_ROOT')
        same([slot for slot,cid in instance['line_cids']],cluster['members'],'STORED_INSTANCE_MEMBERS')
        same(instance['receptors'],[[i,instance['expansion'][i]['formula']] for i in cluster['receptor_indices']],'STORED_INSTANCE_RECEPTORS')
        approved.append(instance)
        changes={kind:[name for name,value in instance['bindings'][kind].items()
            if wire(value)!=wire(family['prototype_bindings'][kind][name])] for kind in ('terms','contexts')}
        ui=[i for i,line in enumerate(instance['expansion']) if line['rule']=='instantiate'
            and wire(line['term'])!=wire(donor['proof'][i]['term'])]
        if changes['terms'] and changes['contexts'] and ui:
            changed+=1
            if len(examples)<16:examples.append(dict(instance_sha256=sha(instance),family_id=instance['family_id'],
                cluster_id=instance['cluster_id'],bindings=instance['bindings'],prototype_bindings=family['prototype_bindings'],
                changed=changes,new_UI_lines=ui))
    same(admitted,approved,'EXACT_INDEPENDENTLY_APPROVED_RAW_INSTANCE_LIST')
    need(result['admitted_count']==len(approved) and result['rejected_or_unknown_count']==len(instances)-len(approved),'INSTANCE_ADMISSION_COUNTS')
    out['instances']=dict(proposed=len(instances),admitted=len(approved),receipts=dict(statuses),
        changed_term_context_and_UI=changed,examples=examples,
        scope='All instances map the entire donor-length proof before rooted clusters are offered. This is warm proof-schema reconstruction, not independent open-receptor composition.')
    if approved:
        checks=readref(result['refs']['qualification']);out['qualification']=instance_qualification(checks,context['statement'],model,library,approved)
        need(result['qualification_status']=='QUALIFIED','INSTANCE_STATE_QUALIFICATION_GATE')
    context.update(admitted=approved,proposals=proposed)
    return out,context


def policy_ledger(row,raw,context,native_positive):
    logs=readref(row['refs']['policy_log']);counts=row['policy_counts']
    model_sha256=sha(normal(context['model']))
    admitted={sha(instance):instance for instance in context['admitted']}
    need(type(counts['callbacks']) is int and counts['callbacks']==raw['stats']['ordering_calls'],'POLICY_ACTUAL_CALLBACK_COUNT')
    branches=[event for event in raw['events'] if event['kind']=='BRANCH']
    need(len(branches)<=len(logs)<=counts['callbacks'],'POLICY_COMPLETE_LOG_PREFIX')
    complete=raw['status'] in ('SAT','UNSAT')
    if complete:need(len(logs)==len(branches)==counts['callbacks'],'COMPLETE_POLICY_LOG_COUNT')
    else:need(counts['callbacks']-len(branches)<=1,'AT_MOST_ONE_INTERRUPTED_POLICY_CALLBACK')
    checked=0;preferences=0;chosen_count=0;retained_choices=0;retained_clusters=0
    selected=set(raw['selected']) if native_positive else set()
    for index,log in enumerate(logs):
        query=log['request'];need(query['schema']=='Z-candidate-order-request-v1'
            and query['model_sha256']==model_sha256,'POLICY_REQUEST_MODEL')
        checked+=len(log['checked']);preferences+=len(log['preferred'])
        for item in log['checked']:
            need(item['instance_sha256'] in admitted and item['status'] in ('COMPATIBLE','REJECTED'),'POLICY_CHECKED_ONLY_ADMITTED')
        chosen=log['chosen_sha256'];preferred=log['preferred']
        if chosen is None:need(preferred==[],'NO_INVENTED_PREFERENCE')
        else:
            need(chosen in admitted and log['checked'] and log['checked'][-1]['instance_sha256']==chosen
                 and log['checked'][-1]['status']=='COMPATIBLE','POLICY_CHOSEN_ADMITTED_INSTANCE')
            instance=admitted[chosen]
            if row['method']=='RECEPTOR_GUIDED':need(bool(instance['receptors']),'RECEPTOR_GUIDANCE_HAS_OPEN_RECEPTORS')
            members=[cid for slot,cid in instance['line_cids']]
            same(preferred,sorted(set(members)&set(query['legal'])),'EXACT_RETURNED_MEMBER_PREFERENCES')
            need(preferred,'NONEMPTY_CHOSEN_PREFERENCE');chosen_count+=1
            if native_positive:
                retained_clusters+=len(set(members)&selected)>=2
        if index<len(branches):
            event=branches[index]
            need(query['point']==event['point'],'LOGGED_CALLBACK_BRANCH_POINT')
            same(query['generation'],event['data']['generation'],'LOGGED_CALLBACK_BRANCH_GENERATION')
            same(query['legal'],event['data']['legal'],'LOGGED_CALLBACK_COMPLETE_DOMAIN')
            fallback=preferred+[cid for cid in query['legal'] if cid not in preferred]
            same(event['data']['order'],fallback,'ACTUAL_COMPLETE_BASE_FALLBACK')
            if native_positive and preferred and event['data']['order'][0] in selected:retained_choices+=1
    if complete:
        need(counts['instance_checks']==checked and counts['preferences']==preferences,'COMPLETE_POLICY_COUNTER_JOIN')
        need(counts['no_preference']==sum(not log['preferred'] for log in logs),'COMPLETE_NO_PREFERENCE_COUNT')
    else:need(counts['instance_checks']>=checked and counts['preferences']>=preferences,'POLICY_PARTIAL_COUNTER_SCOPE')
    return dict(log_entries=len(logs),joined_branches=len(branches),chosen_orders=chosen_count,
        preferred_CIDs=preferences,final_native_selected_choices=retained_choices,
        chosen_clusters_with_two_or_more_final_members=retained_clusters if native_positive else None,
        counts=counts,receipt=row['refs']['policy_log'],
        scope='Logged request/domain/order/fallback byte joins, not state-check replay. Selected/excluded request authenticity relies on the frozen hook; C4 independently checks the actual event decision trace. Whole proof expansions were already mapped/admitted before these subcluster preferences.')


def case_evaluation(result,spec,context):
    need(result['id']==spec['id'] and result['bounded_absence'] is False,'CASE_EVALUATION_ID_SCOPE')
    if not result['rows']:
        need(context is None or result.get('reason')=='UNADMITTED_PREPARATION_OR_RANK','UNRUN_METHOD_REASON')
        return dict(status=result['status'],reason=result.get('reason'),methods=[dict(method=m,status='NOT_ATTEMPTED') for m in METHODS])
    need(context is not None,'ALL_METHODS_HAVE_ADMITTED_CURRENT_PREPARATION')
    need([row['method'] for row in result['rows']]==list(METHODS),'ALL_FIVE_PROSPECTIVE_METHODS')
    output=[];model_sha256=sha(normal(context['model']))
    for row in result['rows']:
        method=row['method'];native_positive=row['admitted_status']=='VERIFIED_NATIVE_POSITIVE'
        item=dict(method=method,admitted_status=row['admitted_status'],costs=row['costs'],refs=row.get('refs',{}),native_refs=row.get('native_refs'))
        selected=None
        if method in POINT_METHODS:
            profile='LEXICAL_V1' if method=='RANK_ONLY' else 'COMPLETE_PERMUTATION_V1'
            info,raw=attempt(row['refs'],profile)
            need(row['raw_status']==raw['status'] and row['semantic_status']==info['semantic_status']
                 and row['model_sha256']==info['model_sha256']==model_sha256,'ACTUAL_METHOD_MODEL_STATUS')
            same(row['stats'],raw['stats'],'ACTUAL_METHOD_STATS')
            need(readref(row['refs']['observations'])==[],'NO_INVENTED_LARGE_INTERMEDIATE_MAPS')
            item.update(info)
            if native_positive:need(info['point_admission']=='POINT_SAT','NATIVE_POSITIVE_REQUIRES_COMPLETE_POINT_SAT')
            selected=raw['selected']
            if method!='RANK_ONLY':item['policy']=policy_ledger(row,raw,context,native_positive)
        elif method=='CONVENTIONAL_AND_OR':
            search=readref(row['refs']['search']);item['planner']=planner_receipt(search,context['prepared'],context['base'])
            need(row['search_status']==search['status'] and search['used_rank_analysis'] is True,'SAME_ANALYTIC_INFORMATION_CONTROL')
            if native_positive:need(search['status']=='FOUND_CANDIDATE','ACTUAL_CONVENTIONAL_CANDIDATE')
            selected=search.get('selected')
        else:
            complete=[instance for instance in context['admitted'] if len(instance['line_cids'])==context['prepared']['binding']['slots']
                      and not instance['receptors']]
            if 'selected' in row:
                matches=[instance for instance in complete if sha(instance)==row['instance_sha256']]
                need(len(matches)==1,'DIRECT_ACTUAL_ADMITTED_WHOLE_CLUSTER')
                chosen=matches[0];selected=sorted(cid for slot,cid in chosen['line_cids'])
                same(row['selected'],selected,'DIRECT_SAME_LIBRARY_SELECTION')
                item.update(instance_sha256=row['instance_sha256'],selected_sha256=sha(selected),
                    scope='Direct selection of an already mapped/admitted full proof, not GCTS or independent open-receptor proof composition.')
            else:need(not complete and row['reason']=='NO_ADMITTED_WHOLE_CLUSTER','NO_INVENTED_DIRECT_CANDIDATE')
        if native_positive:
            need(selected is not None,'ACTUAL_SELECTED_TARGET_CERTIFICATE')
            role='POINT_SEARCH' if method in POINT_METHODS else 'SPECIALIZED_CONTROL' if method=='CONVENTIONAL_AND_OR' else 'DIRECT_SAME_LIBRARY'
            record=native_projection(row['native_refs'],context['statement'],selected,spec['id']+'--'+method,role,context['prepared']['binding']['scope'])
            need(type(row['native_lines']) is int and row['native_lines']==record['lines'],'CURRENT_METHOD_NATIVE_CENSUS')
            if method=='DIRECT_SAME_LIBRARY':
                proof=readref(record['proof_ref'])
                if record['proof_ref'].get('pointer')=='/proof':proof=proof['proof']
                same(proof,chosen['expansion'],'DIRECT_PROOF_IS_THE_ALREADY_ADMITTED_EXPANSION')
            item['native_proof_id']=record['id']
        else:
            item['native_scope']='No admitted target native proof; saved candidate/refusal/UNKNOWN remains separate.'
        output.append(item)
    return dict(status=result['status'],methods=output,
        scope='All declared methods, including refusals. Guided E orders a precomputed complete learned expansion; DIRECT_SAME_LIBRARY is the matched warm reconstruction control. Timings are component scopes, not a superiority claim.')


def main():
    reference('publication/audit_receptor_saved_data_v1.py')
    protocol,roster,frozen=environment()
    phases=[];results={}
    for name in protocol['phases']:
        row,result=process(name,protocol);phases.append(row);results[name]=result
    byphase={row['name']:row for row in phases}
    donor,donor_context=donor_input()
    qualified=dict(status='NOT_RUN_OR_NOT_ADMITTED')
    if byphase['qualify']['scientific_admitted']:qualified=qualification(results['qualify'])
    learned=dict(status='NOT_RUN_OR_NOT_ADMITTED',library_admitted=False);library=None
    if byphase['learn']['scientific_admitted']:learned,library=learning(results['learn'],donor_context)
    if not learned['library_admitted']:library=None
    cases=[]
    for spec in roster['cases']:
        prep_name='prepare-'+spec['id'];eval_name='evaluate-'+spec['id']
        item=dict(id=spec['id'],training_overlap=spec['training_overlap'],preparation=dict(status='NOT_RUN_OR_NOT_ADMITTED'),
                  evaluation=dict(status='NOT_RUN_OR_NOT_ADMITTED',methods=[dict(method=m,status='NOT_ATTEMPTED') for m in METHODS]))
        context=None
        if byphase[prep_name]['scientific_admitted']:
            item['preparation'],context=case_preparation(results[prep_name],spec,library,donor_context)
        if byphase[eval_name]['scientific_admitted']:
            item['evaluation']=case_evaluation(results[eval_name],spec,context)
        cases.append(item)
    physical=[]
    for folder in ('data','run'):
        if (ROOT/folder).exists():
            for path in sorted((ROOT/folder).rglob('*')):
                need(not path.is_symlink(),'NO_CURRENT_DATA_SYMLINK')
                if path.is_file():physical.append(dict(path=path.relative_to(ROOT).as_posix(),**filepin(path)))
    repeated,_,_=environment();same(repeated,protocol,'FROZEN_ENVIRONMENT_STILL_EXACT')
    for ref in list(LEDGER.values()):same(filepin(local(ref['path'])),{k:ref[k] for k in ('bytes','sha256')},'FINAL_REFERENCED_BYTES_UNCHANGED')
    need(len(PROOFS)==len({proof['id'] for proof in PROOFS}),'UNIQUE_CURRENT_TARGET_PROOF_IDS')
    output=dict(schema='Receptor-family-passive-audit-v1',status='PASS',check_count=CHECKS,
        protocol=reference(PROTOCOL),frozen=frozen,phases=phases,donor=donor,qualification=qualified,
        learning=learned,cases=cases,native_proofs=PROOFS,native_proof_counts=dict(Counter(row['role'] for row in PROOFS)),
        physical_files=physical,artifact_pins=[LEDGER[name] for name in sorted(LEDGER)],
        scope='Saved bytes/processes/receipt/projection/census joins only. No compiler/learner/rank/model/engine/C4/T/X/oracle/native imports, calls or replay. Explicit warm donor; complete proof expansion mapping precedes subclusters and guided search, so this is warm reconstruction rather than independent receptor composition. Qualification and donor proofs are separate from new target collection. UNKNOWN, failed/unrun processes and scopes preserved; no RL, universal schema, uniform Wang palette, plane tiling or performance superiority established.')
    with local(OUTPUT).open('xb') as stream:stream.write(wire(output))
    print(json.dumps(dict(status=output['status'],receipt=reference(OUTPUT),checks=CHECKS,native_proof_counts=output['native_proof_counts'])))


if __name__=='__main__':
    main()
