Warm receptor-family transfer with concrete primitive/native admission.

Download every receptor-family-transfer-20261104-evidence-v1-part-NNN.zip together with
receptor-family-transfer-20261104-evidence-v1-manifest.json and extract together. Every volume
is at most 44 MiB and contains the same complete ARCHIVE-file-manifest-v1.json.
Every original current-run path present at the cut is physically stored once.
Equal bytes at different paths remain physical copies, with no alias or remote
reference replacing originals. Sizes/SHA256, CRCs, exact member/path sets and
physical volume hashes are verified before isolated commit preparation.

All current Sources/inputs/reference/plan/reviews, raw outcomes/endpoints/events,
UNKNOWN/refusal/failure records, native receipts, library/cluster/proposal/state
checks, logs, local paths, reader/tool Sources and planning are included. The
full declared input/donor physical closure is included under its original paths.
One authorized published automatically found proof is training input, not a new
target proof. Other historical lane references retained inside an original
whole-phase record are metadata only; the donor manifest defines the exact
copied/authenticated closure. Predecessor archives are separately linked.

Only generated package/ outputs are excluded. The preserved original render
and changed predecessor-reader backlink are included before the cut. Later
index/prepared/push/Pages/live receipts are postcut custody, not claimed inside
their own earlier archive. Full current evidence, logs and local paths are
user-approved for this existing public destination; no new audience is created.

Serve the extracted directory and open report/receptor-family-transfer-20261104-v1.html.
Current eight process positions, donor authentication, empirical library
provenance, concrete instance checks, state compatibility and final native
acceptance are separate gates. A workflow word is not proof success. Read
actual saved statuses before drawing conclusions. Complete emitted payload may
still be only an UNKNOWN search prefix; a refused proposal is not a negative.

Guidance only orders current legal candidates and retains complete primitive
fallback under the reference global scheduler and rollback. Literal learned
term/context families keep fixed donor line-to-slot mapping in this version.
Their provenance is not universal schematic soundness. Shared placements count
once; missing receptor owners are literal demands, not extension certificates.
Direct same-library expansion and conventional AND/OR are separately attributed
controls, not GCTS search. No winner, new theorem, speed advantage, RL gain,
full PA/induction or single universal Wang set is assumed. All preparation,
learning, checking, proposal and native-assurance costs remain relevant.
The larger research program remains ACTIVE.
