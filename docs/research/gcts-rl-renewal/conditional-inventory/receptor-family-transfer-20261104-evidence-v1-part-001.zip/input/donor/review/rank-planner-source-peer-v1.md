# Rank producer and conventional planner Source peer

Status: `PASS_SOURCE_ONLY_REVIEW`. Full held Source/API read found no
outstanding functional blocker. This note is not a runtime qualification,
rank/model admission, native proof receipt or performance result.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `source/rank_pruning_v1.py` | 13929 | `23d85db70b7c93c454ac4e94109f6c60f9456dc96e630f0c76d1a925bf301a9d` |
| `source/conventional_proof_search_v1.py` | 11127 | `d24bcafa8f7c3b6de91d7b41d7d76b9669b4a7e9f292061f7b87ecec73225a4f` |
| `plan/rank-and-conventional-API-v1.md` | 6206 | `11aae634e85189deda6b0e92465a420b129abaaedea536070be27db39429f230` |

Only direct Source reads, byte hashing and standard-library AST parsing were
performed. Neither module was imported, no scientific function or qualification
was called, and no previous target proof or runtime witness was read. No
reviewed Source was edited.

## Rank construction and packet association

The producer has no case-specific constants, target derivation, proof bank,
handwritten forbidden CID or saved learned assignment. It accepts the complete
prepared carrier and exact unfiltered engine migration. Input checks bind the
original statement, canonical formula IDs, full structural MP/GEN catalogue,
native ZERO payloads, complete prepared definitions and scope/digests. These
checks intentionally do not substitute for independent RF/native/model
admission. The independent V checker additionally reconstructs candidate row
semantics and the complete census.

`_heights` starts every ZERO output at height one and other entries at `None`.
Each pass reads only the previous height vector and visits all MP/GEN producers.
It minimizes all finite proposals, returns only at a complete unchanged pass,
and bounds the number of passes by the finite formula registry. A work, wall,
depth or memory refusal returns `UNKNOWN`, without a partial successful rank
table. `None` is not inferred from a stopped preparation or partial search.

Every row is visited in the original sorted universe, and every positive `f:k`
value is tested, including own outputs and remote premise demands. Formula-zero
PAD ports are exempt. The exact successful ten-field packet, strict five cost
fields, five limit fields, one-based rank sequence, forbidden CID order and
reason ordering agree with the independently authored V API. The producer does
not mutate the models or claim pruning soundness itself. Its cooperative final
wall/work check is on the successful return path.

The height bound is a necessary earliest-slot condition, not a minimum DAG
size or proof-line count. Redundancy and all-solution preservation require the
separate independent V result, original RF/N catalogue/model admission and
native ZERO checks. No target proof or finite absence follows from a rank
candidate alone.

## Conventional search and emitted candidates

The planner indexes every original ZERO, MP and GEN producer. It begins with
an empty derived-fact plan; facts enter only through those producers. Its
deterministic goal-directed AND/OR recursion reuses already derived formulas,
checks ancestor cycles and bounds plan/ancestor depth and total states. Generic
rank and missing-premise ordering contains no target-specific strategy.

The search class is explicitly specialized to acyclic unique-formula plans.
Its ancestor/line bound is a restriction of this control, not a completeness
certificate for the original point inventory. Exhaustion, bound failure,
resource refusal and no plan all remain `UNKNOWN`; none is labelled finite
non-derivability. A prospective experiment must retain that distinction.

For a completed plan, prerequisite facts are packed in postorder, the original
goal is placed at the last declared slot, and unused slots receive actual PAD
CIDs. Every CID must exist in the complete original universe, each reference
must be to an earlier slot, and the emitted selection must have one owner per
slot. Full target totals and original seed/row markings are checked. The output
is only `FOUND_CANDIDATE`; unchanged M and independent N decoding plus a whole
native B check are mandatory before any proof admission. No native proof
payload or fabricated kernel receipt is returned by this control.

Optional `analysis` is treated as an externally admitted packet. The planner
binds its scope and strict rank table and avoids the packet's forbidden CIDs,
but does not independently prove that table. The Root caller must therefore
authenticate the clean rank phase and V admission before supplying it. That
caller-owned process gate is outside this Source and must not be replaced by
an admitted-looking result file. Running `analysis=None` remains an explicit
unranked mode.

## Runtime closure and accounting

The only dynamic project dependency is the exact sibling
`rank_pruning_v1.py`, loaded lazily for its structural validation/meter helpers.
It does not load an old run, compiler, logical checker or proof output. The
prospective Source protocol must freeze this sibling as well as the planner;
its before/after byte guards remain caller-owned. Import time is included in
public planner elapsed time, and the cooperative wall meter starts at public
entry.

Native integer limits exclude booleans, larger limits are rejected, and zero
count/work limits may refuse immediately. Reader costs include input scanning,
structural binding, strings, local loops and serialized hash fragments. These
are heuristic work units, not CPU instructions or a common unit with E/C/V.
Outer native wall/CPU/RSS guards and separately reported preparation/admission/
final-proof costs remain necessary. No speed or distinctive GCTS claim is
supported by this Source review.
