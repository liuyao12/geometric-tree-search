# Rank design: independent mathematical review

Status: **PASS_CONDITIONAL_DESIGN_REVIEW; SOURCE_ONLY**. Read the complete local
master reference. No algorithm, model, compiler, checker, planner or test was
imported or executed. This is a supplied analysis of the proposed rule, not an
automatically discovered theorem or an execution/conformance receipt.

## Sound lower bound

For the complete declared catalogue, let \(h(F)\) be minimum derivation height:
every ZERO has height \(1\), GEN adds \(1\) to its source, and MP adds \(1\)
to the maximum premise height. Take the minimum over **all** producers;
unreachable formulas have \(h(F)=\infty\), represented by `None` only after a
complete fixed-point computation. Closed producer cycles without a ZERO path
remain unreachable. This is a height bound, not minimum proof length or minimum
number of distinct shared facts.

Assume the independently admitted shared-slot carrier: zero-based slot \(k\)
has one selected capacity-one owner, whose formula/activity markings agree
with every consumer; all GEN/MP references are strictly earlier slots. PAD
owns activity/formula zero. Synthetic capacity seeds replacing owners require
their own represented-owner justification; the fresh original profile has no
such unaccounted slot contributions.

Induct on slot index over **every active owner**, including unused facts and
duplicate assertions. A ZERO satisfies \(h(F)\leq1\leq k+1\). A GEN source at
\(j<k\) gives
\[
h(F)\leq1+h(A)\leq j+2\leq k+1.
\]
For MP with premise slots \(i,j<k\),
\[
h(F)\leq1+\max(h(A),h(A\Rightarrow F))
\leq1+\max(i+1,j+1)\leq k+1.
\]
Thus any positive formula request at port `f:k` in any selected row must have
\(h(F)\leq k+1\): the unique slot owner has that same formula. This applies to
remote premise requests as well as the row's own output. Formula zero is not
a logical fact and is exempt; PAD must remain available. No goal-ancestry or
backward-relevance premise occurs in this argument.

Consequently, a row with any positive request whose rank exceeds \(k+1\), or
whose formula is certified unreachable, belongs to **no complete original
bounded certificate**. Pruning all such rows preserves the complete solution
set, including extra unused active facts and arbitrary valid PAD positions.
It intentionally need not preserve all partial states.

## Literal encoding and admission obligations

A fresh mark-only guard with assigned seed literal `0`, assigned row literal
`1` exactly on the forbidden CID set, and absence elsewhere rejects exactly
the matching ordinary unary filter. Every original complete certificate avoids
those CIDs, so it lifts with compatible guard values; every decorated complete
certificate projects to the original. All IDs, positive support, roots, old
seed and mandatory formula/activity markings must remain unchanged. Check
freshness against the entire old positive/marking/seed/root domain, including
assigned zero and mark-only sites. The complete inventory remains registered.

Admission must bind original model/catalogue/slot scope and recompute ranks
independently over every producer. An interrupted preparation is UNKNOWN, never
permission to interpret still-`None` entries as unreachable. Native integer
ranks must exclude booleans/floats. Exact compact `f:k`/FID parsing requires the
admitted carrier schema, not a heuristic name-prefix rule on arbitrary models.
The independent rank gate is structural; full RF/R/Q/N and every native ZERO
gate remain required separately. Final discovered proofs still need both
native projections and whole B validation.

The rank is not the engine's growth generation. Reference search still checks
global dead ends, propagates global forced moves and branches at earliest
generation, with exact rollback. Freeze the overlay before search; no dynamic
rank or goal-relevance shortcut may bypass the complete point/candidate graph.
This is an analytically justified constraint, not newly learned corona data or
RL. A MARKS/FILTER match would compare encodings of the same information.

## Bounded qualification recommendations

- Compare all complete tiny original/marked/filter solution sets, not just a
  selected proof. Include unused active assumptions, duplicate active facts,
  interspersed PAD and a goal with irrelevant but valid active predecessors.
- Exercise ZERO, GEN and MP off-by-one bounds and a late row whose own output
  rank fits but whose **remote earlier** formula request does not. Include
  duplicate references, competing producers, unreachable cycles and cycles
  made reachable by an alternative ZERO. Check every violating-port reason.
- Reject an overestimated rank, a wrongly finite/unreachable entry, omitted
  producer, changed scope/FID/slot, removed PAD, corrupted old marking, guard
  collision, or inconsistent forbidden list. Resource controls stay UNKNOWN.
- Qualify actual complete graph/rollback behavior on small rank-marked and
  filter cases; do not infer it from equal final proofs. Retain full raw input,
  actual output, costs and all refusals before assertions.

The conventional planner is a useful specialized control on the same complete
catalogue. Goal-directed unique-fact acyclic plans cover a narrower search
class than all point certificates; its scheduling is not master GCTS. Extract
actual shared postorder facts, place the goal in the declared final slot, fill
unused slots with valid PAD, and verify actual CID membership plus M/N/B.
Minimum-height choices need not minimize shared DAG size; an oversized or
failed plan remains UNKNOWN, even if its own planning class is exhausted.
No prior target derivation is a search input. Compare complete preparation,
rank analysis, model construction, search, assurance and native-check costs;
planner states and engine work units are not interchangeable. Neither a bound
variation of this seen target nor one successful run establishes transfer,
novelty or superiority over existing proof search.
