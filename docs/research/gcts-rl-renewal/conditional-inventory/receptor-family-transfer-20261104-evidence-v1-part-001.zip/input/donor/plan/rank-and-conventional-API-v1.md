# Rank proposal and conventional shared-fact planner

Source-only before Root review/freeze. No module was imported, no prepared model constructed, no search/native/independent checker called, and no prior proof read during authorship. Only current master/adapter Sources and static declarations/interfaces were consulted; syntax parsing is not qualification.

## Rank producer

`source/rank_pruning_v1.py` exposes `analyse(prepared, base_model, limits=None)`. Input is the full freshly admitted `Shared-fact-prepared-v2` plus its exact schema-v3 engine-v4 migration, with empty pair/unary filters. Structural binding checks reconstruct literal formula IDs and all catalogue ZERO/MP/GEN definitions. External complete RF, all-ZERO native B and independent N model admission remain mandatory; this producer is not their replacement.

Lower-only defaults are `{max_formulas:1024,max_rows:250000,max_slots:16,max_work:1000000000,wall_seconds:120.0}`. Integer count/work limits may be zero, yielding resource `UNKNOWN` when exceeded. Wall must be finite and positive. Native booleans are not integer limits. Larger limits, invalid structures or bindings are `REJECTED_INPUT`; memory/depth/work/wall refusal is `UNKNOWN`. No partial rank/forbidden table is admitted on refusal.

Successful output has exactly these top-level fields:

```text
schema='Rank-pruning-analysis-v1', status='CANDIDATE'
bindings={catalogue_sha256,prepared_scope,base_model_sha256,slots}
ranks=[[fid,rankOrNone],...]                 # every literal FID 1..N
forbidden=[CID,...]                         # lexicographically sorted
reasons=[[CID,[[fid,portSlot,rankOrNone],...]],...]
costs={seconds,work,relaxation_passes,producer_visits,row_visits}
limits=<effective five-key limits>, scope=<explicit conditional scope>
```

Every reason list is sorted by `(portSlot,fid)`. It includes every violating positive `f:k` demand, including own output and every receptor demand; `f:k='0'` is PAD, not an unreachable formula. Rows are visited in the original sorted complete universe. No model is returned or mutated, and the packet contains no selected proof.

Initialize all ZERO outputs at height one and others at infinity. Synchronous full-producer relaxation implements

\[
h(F)=\min\left(\{1:F\text{ is a ZERO output}\}\cup
 \{1+h(A):\mathrm{GEN}(A,F)\}\cup
 \{1+\max(h(A),h(I)):\mathrm{MP}(A,I,F)\}\right).
\]

`None` denotes infinity only after the complete least fixed point. Cycles without a finite supporting derivation stay unreachable. Finite minimal height is at most the number of formulas, so a complete fixed point is reached within that many height levels plus the unchanged check. Height is not minimum shared-DAG/proof-line count.

For every actual strict-prior proof line at zero-based slot \(k\), induction gives \(h(F)\leq k+1\). Thus any row assigning positive \(F\) to `f:k` with \(h(F)>k+1\) or infinite is absent from every exact full cover, even if that line is irrelevant to the final goal. This preservation argument is conditional on the complete admitted finite catalogue/model; it is not a nonderivability claim in unrestricted arithmetic/FOL. Root's independent rank checker must recompute the table/exclusions and admit its marked/filter encodings before use. The Root-owned guard encoding is a fresh mark-only point `certified:rank:guard:v1`, seed value zero, forbidden-row value one; all original rows and old marks remain.

## Conventional planner

`source/conventional_proof_search_v1.py` exposes `search(prepared, analysis=None, limits=None)`. It lazily loads the current frozen sibling rank Source only for structural/meter helpers; no engine, RF compiler, logical checker or previous-run output is imported. Defaults are `{max_states:100000,max_work:1000000000,wall_seconds:120.0}`, lower-only. Input ceilings stay fixed at 1024 formulas, 250000 rows and 16 slots. Public elapsed time includes the helper import; the cooperative wall meter starts at the public call.

The planner indexes **all** ZERO/MP/GEN producers, then performs deterministic goal-directed AND/OR DFS. Already derived formulas are shared; active-ancestor cycles are rejected. The explicitly specialized search class has one derivation per distinct formula and an acyclic postorder. It is a conventional control, not the GCTS scheduler. A supplied externally admitted rank packet must bind the same complete model/catalogue; ranks guide generic ordering and prune formulas whose height cannot fit any slot. No rank packet is required: `analysis=None` uses deterministic unranked producer ordering and no rank pruning. No goal-specific constants, derivation templates, known bad CID, proof hint or bank is used.

Each completed plan is packed as prerequisites in postorder from slot zero, the unchanged goal at the last declared slot, and PAD in every unused slot. Every generated canonical CID must be an actual original inventory member; all strict-prior references, full target totals and problem-defining marks are checked. The selected set is lexicographically sorted and hashed by compact sorted-key ASCII JSON plus LF.

Success is `schema='Conventional-proof-search-v1',status='FOUND_CANDIDATE'`, with `bindings,selected,selected_sha256,plan,used_rank_analysis,costs,limits,scope,admission`. Each plan entry is `{formula_id,kind,definition_id,premises,slot,cid}`. This is **not a checked proof**. Root must freshly run unchanged M and independent N decoding, compare the projections, and check the whole native proof with B. There is no native proof payload or proof-status assertion from this planner.

Exhausting this specialized class returns `UNKNOWN/NO_PLAN_IN_SPECIALIZED_SEARCH_SPACE`. Work/states/wall/memory refusals also return `UNKNOWN`; none claims finite absence. Malformed input is `REJECTED_INPUT`. Costs include cooperative work plus `states,producer_choices,cycle_skips,line_bound_skips,rank_skips,best_plan_lines`; states count calls, including cache hits and refused/cyclic subgoals. Work units charge local loop/string/serialization operations; they are neither physical bytes/CPU time nor interchangeable with E/C/U work. Outer process guards and full preparation/checking cost remain separately charged.
