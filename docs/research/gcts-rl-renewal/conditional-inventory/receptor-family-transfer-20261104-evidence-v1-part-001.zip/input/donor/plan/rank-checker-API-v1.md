# Independent rank-constraint checker

Source-only until Root review and prospective freeze. Module
`source/rank_pruning_checker_v1.py` imports only `hashlib`, `json`, `math` and
`time`; it imports no producer, compiler, point adapter, engine, logical checker
or prior witness. AST parsing is permitted before freeze; no checker call or
qualification was executed while authoring this Source.

```python
verify(prepared, base_model, packet, marked_model, control_model, limits=None)
```

The five arguments are literal native JSON values. The result is one of:

- `VERIFIED_REDUNDANT_RANK_CONSTRAINT`: independent reconstruction succeeded.
- `REJECTED`: malformed or inconsistent data, an incomplete analysis packet,
  incorrect ranks, missing/extra constraints, or an altered model.
- `UNKNOWN`: a cooperative resource bound or Python memory/recursion refusal.

Every result has `version`, `seconds`, `work`, `work_scope`,
`bounded_absence=False` and `learned=False`. No status is a target proof or
finite-search absence certificate. Verification is conditional on separately
admitted full RF profile/catalogue/model and native ZERO truth. Caller-owned
process, file and receipt authenticity gates must bind those admissions to
these exact inputs. The checker does not accept a supplied native proof.

## Input and packet ABI

`prepared` is the full `Shared-fact-prepared-v2` /
`PREPARED_UNVERIFIED` carrier from the unchanged compact adapter. The generic
catalogue schema is `Shared-fact-finite-catalogue-v1`. Formula IDs are the
complete sorted canonical registry, positive and one-based. Literal term and
formula AST shapes, signatures, the full variable pool, named hypothesis
registry, all native ZERO payloads, and all structural MP/GEN definitions are
inspected. Native logical rule truth and hygiene remain external gates.

The checker independently derives structural MP from every implication whose
two constituents occur in the registry, and GEN from every universal formula
whose body occurs there when `allow_gen=True`. It reconstructs the entire
`prepared.definitions`, the scope preimage, catalogue/statement hashes, goal ID
and prepared binding. No producer rank table or telemetry is used for this.

The baseline is exactly the prepared six-field point model migrated to
`Z-growing-point-model-v3`: version suffix `:engine-v4`, mandatory empty
`pair_nogoods` and `unary_nogoods`, and all old literal data preserved. Models
are explicit, capacity one and finite, with one required center `q:<slot>` for
each proof slot. `a:<slot>` carries activity and `f:<slot>` carries the literal
formula ID. CIDs are canonical ASCII JSON plus one final LF:

```json
[slot, "ZERO|MP|GEN|PAD", "definition_id", [earlier_slot_refs]]
```

Every actual row is independently reconstructed from its canonical CID and
native definition. Own and remote ports, exact center contribution, active
values, formula IDs and strict prior references must agree. Sorted distinct
CIDs plus the exact theoretical row census certify the complete finite row
inventory, not merely a subset. MP with the same slot used for its distinct
antecedent and implication requirements is self-conflicting and absent. This
is the unchanged adapter's self-conflict rule, not a new grammar restriction.
PAD is retained and has activity/formula zero.

The rank producer's packet has exactly these top-level fields:

```text
schema: Rank-pruning-analysis-v1
status: CANDIDATE
bindings: {catalogue_sha256, prepared_scope, base_model_sha256, slots}
ranks: [[fid, native_positive_int_or_null], ...]
forbidden: [sorted_unique_cid, ...]
reasons: [[cid, [[fid, portSlot, rank_or_null], ...]], ...]
costs: {seconds, work, relaxation_passes, producer_visits, row_visits}
limits: {max_formulas, max_rows, max_slots, max_work, wall_seconds}
scope: nonempty string
```

The rank table lists every formula exactly once in ID order. `forbidden` and
the outer `reasons` are in CID order. Each reason lists **every** violating
positive formula demand in that row, sorted by `(portSlot, fid)`. This includes
the output port and all premise receptors. A formula-zero port contributes no
rank obligation. Costs are strict finite nonnegative metadata, not a substitute
for independently completed reconstruction. Producer limits are checked and
must be no higher than the published ceilings. The checker does not assume
the producer and verifier have identical work units or relaxation passes.

## Independent rank construction and preservation

The checker uses synchronous finite relaxation, independently of the producer.
Initialize every ZERO output at rank \(1\) and all other formulas at
\(\infty\), represented by `None`. Repeatedly minimize the current values
using every GEN and MP producer:

\[
 h(o)\leq 1+h(s),\qquad
 h(o)\leq 1+\max\{h(a),h(i)\}.
\]

The complete least derivation-height table must stabilize; a minimal
derivation can remove repeated formula nodes along a branch, so a reachable
formula has a minimal height no greater than the number of registered
formulas. All finite ranks and all `None` entries must exactly match the
independent complete fixed point. A refused, partial or `UNKNOWN` producer
packet is rejected as an incomplete candidate, never interpreted as an
unreachable table.

A candidate is forbidden exactly when some positive request for formula
\(f\) at zero-based slot \(k\) has no finite rank or satisfies
\(h(f)>k+1\). This is a **necessary** earliest-slot bound; it is not a
minimum proof-line count, a sufficient feasibility test, or a supplied proof.

For any original complete point solution, inspect its slot owners in order.
A ZERO owner satisfies the bound at its own slot. A GEN owner has a strictly
earlier active source; MP has strictly earlier active antecedent and implication
owners. Induction therefore yields \(h(f)\leq k+1\) at every active
owner, including duplicates and unused active facts. Every selected remote
positive `f:k` demand agrees with the unique owner's literal formula ID and
inherits that same bound. PAD has formula zero and is exempt. Consequently no
row in any original complete point solution is forbidden. This proves
preservation of **all** original complete solutions, not only goal-ancestry
proofs or one chosen derivation. It does not require pruning unused facts by
backward relevance.

## Exact redundant layer and matched control

The literal guard is `certified:rank:guard:v1`. It must be absent from all base
roots, seed support, positive supports and marking supports. The checker
requires exactly:

- Marked version: base version plus `:rank-marked-v1`.
- Marked seed: all old `t`/`m` entries, plus guard literal `"0"`, sorted.
- Every forbidden row: all original `t`/`m`, plus guard literal `"1"`, sorted.
- Every other row: unchanged.
- Both old ordinary filters remain empty in the marked model.
- Control version: base version plus `:rank-filter-v1`.
- Control: same old rows/seed/roots and `unary_nogoods=forbidden` only.

The entire original inventory, including PAD and unused-fact owners, remains
present in both models. Missing is unconstrained; the guard zero is a real
literal. The seed therefore rejects exactly the certified forbidden rows, as
does the matched ordinary unary filter. This is a proved redundant constraint,
not learned marking discovery, a runtime lookahead, or a geometric prototype.

Successful receipts bind catalogue, prepared scope, base model, all three
model hashes, rank/forbidden/reason hashes and the actual complete census.
They report unreachable-formula and forbidden-row counts and explicitly state
all-solution preservation. A changed scheduler, forced/dead decision, branch
order or rollback is outside this checker; unchanged E/C/T qualification and
actual search evidence remain separate requirements.

## Resources and prospective qualification

`limits=None` uses these ceilings; a supplied partial dictionary may lower
them only:

```json
{"max_formulas":1024,"max_rows":250000,"max_slots":16,
 "max_work":1000000000,"wall_seconds":120.0}
```

Integer limits are native integers, excluding booleans/floats. `max_work=0`
is a valid immediate `UNKNOWN` test. Other integer limits are positive; wall
is a positive finite native integer/float at most 120 seconds. Additional
fixed safety bounds are native JSON depth 128, integer width 256 bits and
8000 native ZERO definitions. JSON cycles and nonnative containers are rejected;
shared acyclic JSON objects are allowed. Work counts native JSON/string,
producer/row and canonical serialization units, not CPU instructions or memory.
Canonical hashing uses the standard-library incremental encoder with fragment
charges and a final cooperative wall gate after all success-path hashes.
Outer process CPU/RSS/time guards remain caller-owned.

Before activating this layer, freeze and execute tiny complete logical cases
covering all ZERO/MP/GEN rules, cycles with and without reachable alternatives,
duplicate/unused active facts, interspersed PAD and remote receptor violations
whose own output rank fits. Independently enumerate every complete tiny point
solution and require all original solutions survive marked/control models.
Mutants should include overestimated/omitted rank entries, omitted structural
producers, changed scope/CID/typed values, missing or extra forbidden rows,
altered old marks, wrong guard seed or row literal, partial preparation and
resource zero. Those are prospective gates, not authoring-time results.
