"""Saved JSON arithmetic and associations only; imports no subject module."""
import collections
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'actual-v1'
def read(name):
    p = DATA / name
    b = p.read_bytes()
    return json.loads(gzip.decompress(b) if p.suffix == '.gz' else b)
def text(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)
def pin(p):
    b = p.read_bytes()
    return dict(path=str(p.relative_to(ROOT)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
summary = read('cluster-policy-results-v1.json')
frozen = read('frozen-policy-v1.json')
bank = read('library-v1.json')
cohort = json.loads((ROOT/'cohort-v1.json').read_bytes())
train_ids = {x['id'] for x in cohort['cases'] if x['split'] == 'train'}
test_ids = {x['id'] for x in cohort['cases'] if x['split'] == 'test'}
library = summary['library']
assert library == bank['library']
origins = collections.defaultdict(set)
donors = []
for case_id in sorted(train_ids):
    donor = read(case_id+'-discovery.json.gz')
    if not donor['verified']:
        continue
    compiled = read(case_id+'-preparation.json.gz')['compiled']
    zero_rules = {z['id']:z['rule'] for z in compiled['zero_instances']}
    nodes = {json.loads(p['id'])[0]:json.loads(json.loads(p['id'])[1]) for p in donor['tree']['placements']}
    def fragments(site):
        d = nodes[site]
        tag = {'mp':'MP', 'gen':'GEN'}.get(d[0], 'ZERO:'+zero_rules.get(d[1], ''))
        arity = {'mp':2, 'gen':1, 'zero':0}[d[0]]
        choices = [[None]+fragments(site+str(i)) for i in range(arity)]
        result = []
        for children in itertools.product(*choices):
            p = [tag]+list(children)
            def size(q):
                return 0 if q is None else 1+sum(size(c) for c in q[1:])
            if size(p) <= 4:
                result.append(p)
        return result
    keys = {text(p) for site in nodes for p in fragments(site)}
    def count(q):
        return 0 if q is None else 1+sum(count(c) for c in q[1:])
    keys = {k for k in keys if count(json.loads(k)) >= 2}
    for k in keys:
        origins[k].add(case_id)
    donors.append(dict(case_id=case_id, proof_nodes=len(nodes), families=len(keys)))
assert set(origins) == {text(x['pattern']) for x in library}
for x in library:
    k = text(x['pattern'])
    assert x['id'] == hashlib.sha256(k.encode()).hexdigest()[:16]
    assert set(x['training_origins']) == origins[k] <= train_ids
    assert not set(x['training_origins']) & test_ids
weights = [0.0]*(len(library)+4)
baseline = 0.0
errors = dict(reward=0.0, episode_weights=0.0, frozen_weights=0.0, baseline=0.0)
training_actions = training_successes = 0
training_statuses = collections.Counter()
for i, episode in enumerate(summary['training']['episodes']):
    a = read('training-'+str(i).zfill(3)+'.json.gz')
    training_statuses[a['status']] += 1
    assert episode['case_id'] == cohort['cases'][i%8]['id'] in train_ids
    reward = (1.0 if a['verified'] else -1.0)-.05*math.log1p(a['stats'].get('branches',0))-.02*math.log1p(a['stats'].get('backtracks',0))-.01*math.log1p(a['policy']['proposal_charged_work'])
    errors['reward'] = max(errors['reward'],abs(reward-episode['reward']))
    advantage = reward-baseline
    baseline = .9*baseline+.1*reward
    for action, record in zip(a['actions'],a['policy']['proposals']):
        p = record['proposal']; occupied = {json.loads(r['id'])[0] for r in p['placements']}
        holes = sum(point not in occupied for r in p['placements'] for point,n in r['t'][1:])
        expected_features = [float(x['id']==record['family']) for x in library]+[len(p['placements'])/4,holes/6,len(p['root_site'])/12,1.0]
        assert action['chosen'] == expected_features
        assert abs(sum(action['expectation'][:len(library)])-1) < 1e-12
        for j in range(len(weights)):
            weights[j] = max(-8.0,min(8.0,weights[j]+.08*advantage*(action['chosen'][j]-action['expectation'][j])/len(a['actions'])))
    assert len(a['actions']) == len(a['policy']['proposals']) == episode['proposals']
    errors['episode_weights'] = max(errors['episode_weights'],max(abs(x-y) for x,y in zip(weights,episode['weights'])))
    training_actions += len(a['actions']); training_successes += a['verified']
errors['frozen_weights'] = max(abs(x-y) for x,y in zip(weights,frozen['weights']))
errors['baseline'] = abs(baseline-frozen['training']['baseline'])
assert max(errors.values()) < 2e-14
assert frozen['weights'] == summary['training']['weights']
assert frozen['library_sha256'] == hashlib.sha256((text(library)+'\n').encode()).hexdigest()
lanes = summary['design']['lanes']
metrics = {lane:collections.Counter() for lane in lanes}
guided_pairs = {lane:set() for lane in lanes}
unknown_records = []
cases = []
examples = []
for row in summary['evaluation']:
    case_id = row['id']; answers = {lane:read(case_id+'-'+lane+'.json.gz') for lane in lanes}
    dp = answers['DP_CONTROL']; dfs = answers['CLUSTER_DFS_CONTROL']
    assert dp['status'] == dfs['status'] and dp['verified'] == dfs['verified']
    case = dict(id=case_id, lanes={})
    for lane,a in answers.items():
        m=metrics[lane]; m['verified']+=a['verified']; m['finite_negative']+=a['status'] in ('UNSAT','NOT_DERIVABLE'); m['unknown']+=a['status']=='UNKNOWN'; m['search_seconds']+=a['search_seconds'];m['verification_seconds']+=a.get('verification_seconds',0)
        assert not a['verified'] or dp['verified']
        assert a['status'] != 'UNSAT' or dp['status']=='NOT_DERIVABLE'
        if a['verified']:
            assert a['host_check']['status']=='VERIFIED' and a['tree_audit']['status']=='VERIFIED'
            assert a['proof'][-1]['formula'] == row['problem']['goal']
            selected = a['result'].get('selected',a['result'].get('details',{}).get('selected'))
            assert sorted(selected) == sorted(a['tree']['selected'])
            m['proof_lines']+=len(a['proof'])
        case['lanes'][lane]=dict(status=a['status'],reason=a.get('reason'),branches=a['stats'].get('branches'),search_seconds=a['search_seconds'])
        if a['status']=='UNKNOWN':
            assert not a['result']['selected']
            assert not a['policy']['final_full_realizations'] and not a['policy']['final_two_member_realizations']
            unknown_records.append(dict(case_id=case_id,lane=lane,reason=a['reason'],selected_count=0))
        if 'policy' not in a:
            continue
        policy=a['policy']; records=policy['proposals']; checks=a['independent_cluster_checks']['checks']
        assert len(records)==len(checks)
        for record,check in zip(records,checks):
            assert check['status']=='VERIFIED' and check['candidate_ids']==record['members']
            assert 2<=check['new_placements']<=4
        m['proposals']+=len(records);m['proposal_seconds']+=policy['proposal_seconds'];m['proposal_charged_work']+=policy['proposal_charged_work'];m['continuation_choices']+=policy['continuation_choices'];m['independent_proposal_check_seconds']+=a['independent_cluster_checks']['seconds']
        m['final_full_realizations']+=policy['final_full_realizations'];m['final_two_member_realizations']+=policy['final_two_member_realizations']
        if a['verified']:
            m['verified_proof_full_realizations']+=policy['final_full_realizations'];m['verified_proof_two_member_realizations']+=policy['final_two_member_realizations']
        events=a['result']['events']; by_seq={e['seq']:e for e in events}
        m['events_retained']+=len(events);m['events_emitted']+=a['result']['event_extent']['total']
        for record in records:
            for adoption in record['adoptions']:
                if adoption['seq'] in by_seq:
                    event=by_seq[adoption['seq']]
                    assert event['kind']=='PLACED' and event['candidate']==adoption['candidate'] and event['data']['forced']==adoption['forced']
                    m['adoptions_crosschecked']+=1
                else:m['adoptions_beyond_retained_prefix']+=1
        if lane=='LEXICAL_GCTS':continue
        branches=[e for e in events if e['kind']=='BRANCH']
        assert len(branches)<=len(policy['orders'])
        for event,order in zip(branches,policy['orders']):
            assert event['point']==order['point']
            if 'candidate' in order:assert event['data']['order'][0]==order['candidate']
            if order['kind']!='CONTINUATION':continue
            cid=order['candidate']; adoption=by_seq.get(event['seq']+1)
            if adoption and adoption['kind']=='PLACED' and adoption['candidate']==cid and adoption['data']['forced'] is False:
                m['nonforced_guided_adoptions_crosschecked']+=1
                in_final=cid in a['result']['selected'];m['guided_cids_in_terminal_selected']+=in_final
                m['guided_cids_in_verified_proof']+=in_final and a['verified']
                case['lanes'][lane]['nonforced_guided_adoptions']=case['lanes'][lane].get('nonforced_guided_adoptions',0)+1
                if in_final and a['verified']:
                    guided_pairs[lane].add((case_id,cid))
                    case['lanes'][lane]['guided_occurrences_in_verified_proof']=case['lanes'][lane].get('guided_occurrences_in_verified_proof',0)+1
                matches=[r for r in records if cid in r['guided_later']]
                assert matches
                if in_final and a['verified'] and lane=='RL_CLUSTER_GCTS' and case_id in ('test-ground-0','test-ground-3') and not any(x['case_id']==case_id for x in examples):
                    record=matches[-1]
                    line=dict(a['tree']['site_to_line'])[json.loads(cid)[0]]
                    examples.append(dict(case_id=case_id,lane=lane,branch_seq=event['seq'],placed_seq=adoption['seq'],legal_candidates=len(event['data']['legal']),candidate=cid,family=record['family'],leader=record['leader'],pattern=record['proposal']['pattern'],placements=record['proposal']['placements'],zero_based_proof_line=line,proof_line_content=a['proof'][line],terminal_status=a['status'],backtracks=a['stats']['backtracks']))
    cases.append(case)
for lane in lanes:
    metrics[lane]['distinct_guided_cids_in_verified_proofs']=len(guided_pairs[lane])
    for key in ('verified','finite_negative','unknown','search_seconds'):
        assert abs(metrics[lane][key]-summary['summary'][lane][key])<1e-12
support=dict(schema='CP-passive-evidence-support-v1',scope='Independent arithmetic and saved-record associations only; no subject imports, proof-checker replay or searches.',source_review=pin(ROOT/'review/cluster-driver-source-peer-v2.json'),inputs=[pin(DATA/n) for n in ['cluster-policy-results-v1.json','frozen-policy-v1.json','library-v1.json']],donors=donors,library_families=len(library),training=dict(episodes=len(summary['training']['episodes']),actions=training_actions,statuses=dict(training_statuses),verified_episodes=training_successes,nonzero_final_weights=sum(x!=0 for x in weights),weight_l2=math.sqrt(sum(x*x for x in weights)),reconstruction_errors=errors),metrics={k:dict(v) for k,v in metrics.items()},cases=cases,unknown_records=unknown_records,examples=examples,costs=dict(discovery_seconds=summary['discovery']['seconds'],training_seconds=summary['training']['seconds'],preparation_seconds=summary['preparation_seconds'],total_seconds=summary['seconds']))
out=ROOT/'review/cluster-passive-evidence-support-v1.json'
out.write_text(json.dumps(support,sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(output=pin(out),library_families=len(library),training=support['training'],metrics=support['metrics'],costs=support['costs'],example_count=len(examples)),sort_keys=True))
