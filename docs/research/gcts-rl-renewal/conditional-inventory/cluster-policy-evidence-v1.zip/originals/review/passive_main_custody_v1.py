"""Saved-file custody/receipt joins only; no scientific imports or replay."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT = Path('/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-cluster-policy-20261102-v1')


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a, b):
    return wire(a) == wire(b)


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def check(ref):
    path = Path(ref['path']); assert path.is_file() and not path.is_symlink()
    assert pin(path) == ref
    return path.read_bytes()


def create(path, value):
    data = wire(value)
    with path.open('xb') as stream:
        stream.write(data)
    assert path.read_bytes() == data


def main():
    actual = ROOT / 'actual-v1'; observed = ROOT / 'observation-v1/observer-result.json'
    observer = json.loads(observed.read_bytes())
    assert observer['status'] == 'COMPLETE' and observer['returncode'] == 0 and observer['wait_reaped'] and not observer['timeout']
    assert observer['runtime_source_guards_unchanged'] and same(observer['before'], observer['after']) and len(observer['before']) == 8
    for ref in observer['before']:
        check(ref)
    assert len(observer['files']) == 299 and len({x['path'] for x in observer['files']}) == 299
    assert set(actual.iterdir()) == {Path(x['path']) for x in observer['files']}
    refs = {Path(x['path']).name: x for x in observer['files']}
    loaded, file_rows, raw_json_bytes = {}, [], 0
    for name, ref in refs.items():
        stored = check(ref)
        if name.endswith('.gz'):
            with gzip.GzipFile(fileobj=io.BytesIO(stored)) as stream:
                raw = stream.read(67108865)
            assert len(raw) <= 67108864
        else:
            raw = stored
        loaded[name] = json.loads(raw)
        assert raw == wire(loaded[name])
        raw_json_bytes += len(raw)
        file_rows.append({'stored': ref, 'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()})
    assert len(observer['streams']) == 2
    streams = {Path(x['path']).name: check(x) for x in observer['streams']}
    assert streams['stderr.log'] == b''
    stdout = [json.loads(row) for row in streams['stdout.log'].splitlines()]
    assert len(stdout) == 49 and [x['stage'] for x in stdout] == ['training'] * 32 + ['evaluation'] * 16 + ['complete']
    cohort_path = ROOT / 'cohort-v1.json'; cohort = json.loads(cohort_path.read_bytes())
    result = loaded['cluster-policy-results-v1.json']; design = result['design']; methods = design['lanes']
    assert digest(cohort) == result['cohort_sha256'] == pin(cohort_path)['sha256']
    assert same(design, cohort['design']) and len(cohort['cases']) == 24
    assert [x['id'] for x in cohort['cases']] == design['case_order'] and len(set(design['case_order'])) == 24
    assert design['train_episodes'] == 32 and design['cluster_nodes'] == 4 and design['proposal_cap'] == 48
    assert len(methods) == len(set(methods)) == 6 and same(stdout[-1]['summary'], result['summary'])
    source = ROOT / 'cluster_policy_experiment_v1.py'
    assert pin(source)['sha256'] == '3bd1727fc3095dacf2a588663c011c8aa58d2a50eb2cf239da853e9b55ffabdd'
    assert pin(ROOT/'reference/cluster_verifier_v2.py')['sha256'] == '5af38096efc85aa3947eea5028f806b156d61646f010bb25ad9d3c45dbea0f10'
    package = ROOT.parent / 'gcts-history-publication-20261102-v1/assets/history-marked-proof-search-evidence-v1.zip'
    assert pin(package)['bytes'] == 4825184 and pin(package)['sha256'] == '6cc21e851efc1beb7bffb170d1c9f1a5da0adc112d28873df4933bbe33977844'
    admitted_sources = []
    with zipfile.ZipFile(package) as archive:
        for name in ('growing_point_search_v2.py', 'indexed_proof_provider_v1.py', 'growing_proof_verifier_v2.py', 'independent_fol_checker_v1.py'):
            names = [x for x in archive.namelist() if x.endswith('/' + name)]
            assert len(names) == 1 and archive.read(names[0]) == (ROOT/'upstream'/name).read_bytes()
            admitted_sources.append({'member': names[0], 'current': pin(ROOT/'upstream'/name)})
    preps, zero_receipts, prep_factory_receipts = {}, 0, 0
    used = {'cluster-policy-results-v1.json', 'library-v1.json', 'frozen-policy-v1.json'}
    for case in cohort['cases']:
        name = case['id'] + '-preparation.json.gz'; prep = loaded[name]; used.add(name); preps[case['id']] = prep
        assert same(prep['case'], case) and prep['factory_check']['status'] == 'VERIFIED'
        assert len(prep['zero_checks']) == len(prep['compiled']['zero_instances'])
        assert all(x['status'] == 'VERIFIED' and x['checked_lines'] == 1 and x['error_line'] is None for x in prep['zero_checks'])
        zero_receipts += len(prep['zero_checks']); prep_factory_receipts += 1
    library = loaded['library-v1.json']; frozen = loaded['frozen-policy-v1.json']
    assert same(library['library'], result['library']) and same(library['donors'], result['discovery']['donors'])
    assert len(result['library']) == len({x['id'] for x in result['library']}) == 50
    train_ids = {x['id'] for x in cohort['cases'][:8]}
    assert all(x['training_origins'] and set(x['training_origins']) <= train_ids for x in result['library'])
    assert frozen['library_sha256'] == digest(result['library']) and same(frozen['training'], result['training'])
    assert same(frozen['weights'], result['training']['weights']) and len(frozen['weights']) == 54
    assert same(frozen['weights'], result['training']['episodes'][-1]['weights'])
    family = {x['id']: x['pattern'] for x in result['library']}
    counts = Counter(); stages = {s: Counter() for s in ('discovery', 'training', 'evaluation')}
    stream_counts = Counter(); runs = []; cap_runs = []

    def extent(rows, ext, kind):
        assert type(ext['total']) is int and type(ext['retained']) is int and 0 <= len(rows) == ext['retained'] <= ext['total']
        complete = len(rows) == ext['total']
        if complete:
            assert hashlib.sha256(b''.join(wire(x) for x in rows)).hexdigest() == ext['sha256']
        stream_counts[kind+'_streams'] += 1; stream_counts[kind+'_complete'] += int(complete)
        stream_counts[kind+'_retained'] += len(rows); stream_counts[kind+'_total'] += ext['total']

    def run(name, case_id, stage):
        full = loaded[name]; raw_ref = full['raw_search_ref']; raw_name = Path(raw_ref['path']).name
        assert raw_ref == refs[raw_name]; raw = loaded[raw_name]; used.update((name, raw_name))
        assert raw['verified'] is False and 'raw_search_ref' not in raw
        assert not any(x in raw for x in ('independent_cluster_checks', 'proof', 'tree', 'tree_audit', 'host_check', 'verification_seconds'))
        for key, value in raw.items():
            assert key == 'verified' or same(value, full[key])
        counts['raw_before_checks'] += 1; stages[stage]['runs'] += 1; stages[stage][full['status']] += 1
        prep = preps[case_id]; current = full['result']
        assert current is not None and current['status'] == full['status']
        if 'policy' in full:
            counts['point_runs'] += 1
            assert full['factory']['status'] == 'COMPLETE'
            assert full['factory']['value']['identity'] == full['provider']['identity'] == full['model']['inventory']['identity'] == prep['factory_check']['details']['identity']
            assert same(current['entry_state'], current['restored_state'])
            for which in ('entry', 'final', 'restored'):
                state = current[which+'_state']
                assert current['state_hashes'][which] == (None if state is None else digest(state))
                counts['nonnull_state_hashes'] += int(state is not None)
            assert current['model_sha256'] == digest(full['model'])
            policy = full['policy']; records = policy['proposals']; checks = full['independent_cluster_checks']['checks']
            assert len(records) <= 200 and len(checks) == len(records) == len(full['actions'])
            orders = Counter(row['kind'] for row in policy['orders'])
            interrupted = current['stats']['ordering_calls'] - len(policy['orders'])
            assert interrupted == 0 or interrupted == 1 and full['status'] == 'UNKNOWN'
            counts['interrupted_order_callbacks_without_returned_order'] += interrupted
            assert orders['NEW_CLUSTER'] == len(records) and orders['CONTINUATION'] == policy['continuation_choices']
            counts.update({'chosen_proposals':len(records), 'continuation_choices':policy['continuation_choices'],
                'record_limit_base_fallback_orders':orders['RECORD_LIMIT_BASE_FALLBACK'],
                'observed_two_member_realizations':policy['observed_two_member_realizations'],
                'final_two_member_realizations':policy['final_two_member_realizations'],
                'final_full_realizations':policy['final_full_realizations']})
            if len(records) == 200 or orders['RECORD_LIMIT_BASE_FALLBACK']:
                cap_runs.append({'name':name,'records':len(records),'fallback_orders':orders['RECORD_LIMIT_BASE_FALLBACK']})
            chosen = set(current['selected'])
            for record, checked in zip(records, checks):
                assert checked['status'] == 'VERIFIED' and checked['version'] == 'CP-INDEPENDENT-CLUSTER-VERIFIER-v2'
                proposal = record['proposal']; ids = [x['id'] for x in proposal['placements']]
                assert checked['candidate_ids'] == sorted(ids) and checked['new_placements'] == len(ids)
                assert checked['selected_count'] == len(record['selected_before']) and checked['root_site'] == proposal['root_site']
                assert checked['root_candidate_id'] == record['leader'] == ids[0] and record['members'] == ids
                assert same(proposal['pattern'], family[record['family']]) and not set(ids) & set(record['selected_before'])
                assert record['final_realized'] == sum(cid in chosen for cid in ids)
                assert record['fully_in_final_proof'] is (record['final_realized'] == len(ids))
                for adoption in record['adoptions']:
                    counts['forced_adoptions' if adoption['forced'] else 'nonforced_adoptions'] += 1
                counts['guided_later_entries'] += len(record['guided_later'])
            assert policy['final_two_member_realizations'] == sum(x['final_realized'] >= 2 for x in records)
            assert policy['final_full_realizations'] == sum(x['fully_in_final_proof'] for x in records)
            extent(current['events'], current['event_extent'], 'events')
            extent(current['rollback_records'], current['rollback_extent'], 'rollbacks')
            evidence = current['provider_evidence']; extent(evidence['records'], evidence, 'queries')
            for row in evidence['records']:
                assert row['reply']['context_sha256'] == digest(row['query']) and row['reply']['complete'] is True
                assert row['reply']['certificate']['compatible_count'] == len(row['reply']['placements'])
        else:
            counts['control_runs'] += 1
        if full['verified']:
            counts['positive_occurrences'] += 1; stages[stage]['verified'] += 1
            assert full['status'] in ('SAT', 'DERIVABLE') and full['tree_audit']['status'] == full['host_check']['status'] == 'VERIFIED'
            assert same(full['tree_audit']['proof'], full['proof'])
            assert full['host_check']['checked_lines'] == len(full['proof']) and full['host_check']['error_line'] is None
            assert full['tree']['node_count'] == len(full['proof'])
            assert same(full['tree_audit']['details']['candidate_bindings'], full['tree']['placements'])
            if 'policy' in full:
                assert same(current['selected'], full['tree']['selected'])
                for key in ('placements','totals','marks'):
                    assert same(current['certificate'][key], full['tree'][key])
            else:
                selected = current['details']['selected'] if 'details' in current else current['selected']
                assert same(selected, full['tree']['selected'])
            counts['positive_proof_lines'] += len(full['proof'])
        else:
            assert full['status'] not in ('SAT', 'DERIVABLE')
        runs.append({'name':name,'stage':stage,'case':case_id,'status':full['status'],'verified':full['verified'],
            'chosen_proposals':len(full.get('policy',{}).get('proposals',[])),
            'continuation_choices':full.get('policy',{}).get('continuation_choices',0)})
        return full

    for case, donor in zip(cohort['cases'][:8], result['discovery']['donors']):
        answer = run(case['id']+'-discovery.json.gz', case['id'], 'discovery')
        assert donor == {'case_id':case['id'],'status':answer['status'],'verified':answer['verified'],'seconds':answer['search_seconds']}
    assert len(result['training']['episodes']) == 32
    for i, episode in enumerate(result['training']['episodes']):
        case = cohort['cases'][i % 8]; answer = run('training-'+str(i).zfill(3)+'.json.gz',case['id'],'training')
        assert episode['index'] == i and episode['case_id'] == case['id'] and episode['verified'] == answer['verified']
        assert episode['seconds'] == answer['search_seconds'] and episode['proposals'] == len(answer['policy']['proposals'])
        assert episode['continuation_choices'] == answer['policy']['continuation_choices']
    assert len(result['evaluation']) == 16
    for case, row in zip(cohort['cases'][8:], result['evaluation']):
        assert row['id'] == case['id'] and row['problem'] == case['problem'] and row['quantified'] == case['quantified']
        assert set(row['lanes']) == set(methods)
        for method in methods:
            short = row['lanes'][method]; name = case['id']+'-'+method+'.json.gz'
            answer = run(name,case['id'],'evaluation'); assert short['raw_ref'] == refs[name]
            for key, value in short.items():
                assert key == 'raw_ref' or same(value, answer[key])
    assert used == set(refs) and len(runs) == 136 and counts['raw_before_checks'] == 136
    assert counts['point_runs'] == 96 and counts['control_runs'] == 40
    summaries = {method:{'verified':sum(row['lanes'][method]['verified'] for row in result['evaluation']),
        'finite_negative':sum(row['lanes'][method]['status'] in ('UNSAT','NOT_DERIVABLE') for row in result['evaluation']),
        'unknown':sum(row['lanes'][method]['status']=='UNKNOWN' for row in result['evaluation']),
        'search_seconds':sum(row['lanes'][method]['search_seconds'] for row in result['evaluation'])} for method in methods}
    assert same(summaries,result['summary'])
    counts['preparation_zero_host_receipts'] = zero_receipts
    counts['preparation_factory_receipts'] = prep_factory_receipts
    counts['all_fresh_host_receipts'] = zero_receipts + counts['positive_occurrences']
    support = {'schema':'CP-main-complete-passive-custody-support-v1','status':'PASS',
        'observer':pin(observed),'result':pin(actual/'cluster-policy-results-v1.json'),
        'actual_files':299,'observation_files':3,'stored_actual_bytes':sum(x['bytes'] for x in refs.values()),
        'raw_json_bytes':raw_json_bytes,'counts':dict(counts),'stages':{k:dict(v) for k,v in stages.items()},
        'summary':summaries,'stream_retention':dict(stream_counts),'cap_runs':cap_runs,'runs':runs,
        'source_admitted_package':pin(package),'admitted_source_joins':admitted_sources,
        'scope':'Generic saved-file hashing and exact association/extent checks only. No scientific helpers, cluster verifier, logical kernel, training update or search replay.'}
    create(ROOT/'review/main-passive-filehash-index-v1.json',{'schema':'CP-main-whole-original-hashes-v1','files':sorted(file_rows,key=lambda x:x['stored']['path'])})
    create(ROOT/'review/main-passive-custody-support-v1.json',support)
    print(json.dumps({k:v for k,v in support.items() if k not in ('runs','admitted_source_joins')},sort_keys=True))


if __name__ == '__main__':
    main()
