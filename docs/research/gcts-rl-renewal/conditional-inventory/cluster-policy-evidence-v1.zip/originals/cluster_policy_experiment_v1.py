"""Learn open proof-cluster families; use only validated continuation preferences.

The indexed point engine is unchanged. All kernel/proposal outputs and resource
refusals are retained. This is a synthetic first-order mechanism experiment.
"""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import time

ROOT = Path(__file__).resolve().parent
LANES = ['LEXICAL_GCTS', 'UNIFORM_CLUSTER_GCTS', 'RL_CLUSTER_GCTS',
         'RL_LEADER_ONLY_GCTS', 'CLUSTER_DFS_CONTROL', 'DP_CONTROL']
CHECK = dict(max_depth=256, max_operations=10000000, max_proof_lines=4096)
FACTORY = dict(max_work=1000000000, max_depth=256, max_definitions=20000,
               max_proof_lines=4096, wall_seconds=10)
AUDIT = dict(max_depth=256, max_items=10000000, max_work=1000000000, wall_seconds=10)
PINS = {'growing_point_search_v2.py':'6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb',
        'indexed_proof_provider_v1.py':'5261bf552924105f3c9ac3a4e9ddce0490869105b1812a8d897610267623b26e',
        'growing_proof_verifier_v2.py':'6286d6b151d460e6ee0b97983fd9f081168a6d76256a33c3e0f9ead0ffae3aa1',
        'independent_fol_checker_v1.py':'099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'}


def wire(x):
    return (json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def text(x):
    return wire(x).decode().rstrip('\n')


def sha(x):
    return hashlib.sha256(wire(x)).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    b = wire(value)
    if path.name.endswith('.gz'):
        b = gzip.compress(b, mtime=0)
    with path.open('xb') as f:
        f.write(b)
    return dict(path=str(path), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def load_modules():
    result = {}
    for filename, expected in PINS.items():
        p = ROOT/'upstream'/filename
        assert hashlib.sha256(p.read_bytes()).hexdigest() == expected
        spec = importlib.util.spec_from_file_location(filename[:-3], p)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        result[filename[:-3]] = module
    p = ROOT/'reference/cluster_verifier_v2.py'
    assert hashlib.sha256(p.read_bytes()).hexdigest() == '5af38096efc85aa3947eea5028f806b156d61646f010bb25ad9d3c45dbea0f10'
    spec = importlib.util.spec_from_file_location('independent_cluster_verifier', p)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    result['cluster_verifier'] = module
    return result


def fterm(k):
    t = ['var', 'x']
    for _ in range(k):
        t = ['fun', 'f', [t]]
    return t


def substitute(form, term):
    # Cohort grammar: single outer universal, no inner binders.
    if form == ['var', 'x']:
        return copy.deepcopy(term)
    if isinstance(form, list):
        return [substitute(x, term) for x in form]
    return form


def make_case(split, ordinal, quantified):
    seed = (410000 if split == 'train' else 730000) + ordinal * 7919
    rng = random.Random(seed)
    n = (5 if split == 'train' else 8) if not quantified else (4 if split == 'train' else 6)
    max_term = (1 if split == 'train' else 3) if quantified else 0
    names = [split[0]+str(ordinal)+'p'+str(i) for i in rng.sample(range(n), n)]
    pred = lambda i, k=0: ['pred', names[i], [fterm(k)] if quantified else []]
    close = lambda f: ['all', 'x', f] if quantified else f
    axioms = {'fact0':close(pred(0)), 'fact1':close(pred(1))}
    rules = []
    for j in range(n+2):
        a, b = rng.sample(range(n), 2)
        shift = int(quantified and rng.random() < .5)
        body = ['imp', pred(a), pred(b, shift)]
        if rng.random() < .25:
            c = rng.randrange(n)
            body = ['imp', pred(a), ['imp', pred(c), pred(b, shift)]]
        axioms['rule'+str(j)] = close(body)
        rules.append(body)
    goal_node = rng.randrange(2, n)
    goal_term = rng.randrange(max_term+1)
    theory = dict(functions={'f':1} if quantified else {},
                  predicates={name:1 if quantified else 0 for name in names}, axioms=axioms)
    return dict(id=split+'-'+('forall' if quantified else 'ground')+'-'+str(ordinal),
                split=split, seed=seed, quantified=quantified, max_term=max_term,
                problem=dict(theory=theory, goal=close(pred(goal_node, goal_term))),
                generation='Theory first; goal sampled from non-fact predicate indices and a fixed term pool. No proof or truth label supplied.')


def freeze():
    cases = [make_case('train', i, i >= 4) for i in range(8)]
    cases += [make_case('test', i, i >= 8) for i in range(16)]
    # Signature sizes differ between splits, so there is no bijective symbol
    # renaming identifying a complete train and test problem.
    design = dict(schema='CP-prospective-design-v1', depth=12, search_seconds=.5,
        train_episodes=32, training_seed=281103, cluster_nodes=4, proposal_cap=48,
        lanes=LANES, case_order=[c['id'] for c in cases],
        inventory='Mine all connected prefix fragments of2..4nodes from automatically discovered training proofs; allow open receptors. No hand-written target derivations.',
        policy='Linear softmax REINFORCE; terminal checked completion and branch/proposal-cost penalties; library and weights frozen before test.',
        scope='Synthetic propositional and universally quantified Horn fragments. Limited finite instantiation pool; no new arithmetic/Hilbert theorem, universal palette, plane tiling, or broad speed claim.')
    return write(ROOT/'cohort-v1.json', dict(design=design, cases=cases))


def compile_case(case):
    started = time.perf_counter()
    theory, goal = case['problem']['theory'], case['problem']['goal']
    zeros = [dict(rule='axiom', name=n, formula=f) for n, f in theory['axioms'].items()]
    terms = [fterm(k) for k in range(case['max_term']+1)] if case['quantified'] else []
    universals = [f for f in list(theory['axioms'].values())+[goal] if f[0] == 'all']
    for u in universals:
        for term in terms:
            instance = substitute(u[2], term)
            zeros.append(dict(rule='instantiate', universal=u, term=term,
                              formula=['imp', u, instance]))
    zeros = sorted({text(z):z for z in zeros}.values(), key=text)
    pool = {}
    def add(f):
        key = text(f)
        if key in pool:
            return
        pool[key] = f
        if f[0] == 'imp':
            add(f[1]); add(f[2])
        elif f[0] == 'all':
            add(f[2])
    add(goal)
    for z in zeros:
        add(z['formula'])
    colors = sorted(pool); forms = [pool[k] for k in colors]
    ids = {k:i for i, k in enumerate(colors)}
    mp, gen = [], []
    for i, f in enumerate(forms):
        if f[0] == 'imp':
            mp.append([i, ids[text(f[1])], ids[text(f[2])]])
        elif f[0] == 'all':
            gen.append([i, ids[text(f[2])], f[1]])
    profile = dict(ui_rounds=1 if terms else 0, bridge_arity=0, max_tautology_atoms=0)
    compiled = dict(schema='V-interned-Hilbert8-basis-v1', version='V-INTERNED-FINITE-HILBERT8-v1',
        theory=theory, goal=goal, goal_id=ids[text(goal)], profile=profile,
        logical_basis=dict(instantiation_terms=terms, terms=terms, variables=['x'] if terms else [],
            formulas=forms, colors=colors, templates=[], hole='__cp_hole', stages=[]),
        zero_instances=[dict(id='i'+str(i), rule=z['rule'], formula_id=ids[text(z['formula'])], line=z) for i,z in enumerate(zeros)],
        mp_index=mp, gen_index=gen, costs=dict(seconds=time.perf_counter()-started),
        scope='CP-frozen-finite-Horn-UI-subformula-basis-v1; not full first-order completeness')
    generation = dict(schema='Y-goal-receptor-universe-v1', version='Y-GOAL-RECEPTOR-FAMILY-v1',
        profile=profile, compiled_core_sha256=sha({k:v for k,v in compiled.items() if k not in ('costs','scope')}),
        core_stages=[], core_assertions=[], goal_receptors=[], bridge_premises=[], scope=compiled['scope'])
    return compiled, generation


class Stop(Exception):
    pass


class Meter:
    def __init__(self, seconds):
        self.start = time.perf_counter(); self.seconds = seconds; self.work = 0
    def tick(self, n=1):
        self.work += n
        if self.work > 1000000000 or time.perf_counter()-self.start >= self.seconds:
            raise Stop('WALL_OR_WORK')


class Catalogue:
    def __init__(self, compiled, definitions, depth):
        self.c = compiled; self.depth = depth
        self.defs = {d['id']:d for d in definitions}; self.by_out = {}
        for d in definitions:
            self.by_out.setdefault(d['output'], []).append(d)
        self.colors = compiled['logical_basis']['colors']
    def placement(self, site, d):
        points = [site]+[site+str(i) for i in range(len(d['premises']))]
        return dict(id=text([site,d['id']]), t=[[p,1] for p in points],
                    m=[[p,self.colors[f]] for p,f in zip(points,[d['output']]+d['premises'])])
    def decode_id(self, cid):
        site, did = json.loads(cid)
        return site, self.defs[did]
    def values(self, selected, charge):
        totals = {'':1}; marks = {'':self.colors[self.c['goal_id']]}
        for cid in selected:
            charge(5+len(cid)); site,d = self.decode_id(cid)
            row = self.placement(site,d)
            for p,n in row['t']:
                totals[p] = totals.get(p,0)+n
                assert totals[p] <= 2
            for p,v in row['m']:
                assert p not in marks or marks[p] == v
                marks[p] = v
        return totals, marks
    def valid(self, rows, selected, excluded, charge):
        totals, marks = self.values(selected, charge)
        seen = set(selected)
        for row in rows:
            charge(20+len(row['id']))
            if row['id'] in seen or row['id'] in excluded:
                return False
            seen.add(row['id']); site,d = self.decode_id(row['id'])
            if row != self.placement(site,d) or len(site)>self.depth or (d['premises'] and len(site)>=self.depth):
                return False
            for p,n in row['t']:
                totals[p] = totals.get(p,0)+n
                if totals[p]>2:
                    return False
            for p,v in row['m']:
                if p in marks and marks[p]!=v:
                    return False
                marks[p] = v
        return True


def native(d):
    return 'ZERO:'+d['native_rule'] if d['kind']=='ZERO' else d['kind']


def pattern_size(p):
    return 0 if p is None else 1+sum(pattern_size(q) for q in p[1:])


def mine(tree, catalogue, maximum):
    by_site = {json.loads(p['id'])[0]:catalogue.decode_id(p['id'])[1] for p in tree['placements']}
    found = {}
    def fragments(site):
        d = by_site[site]; choices = [[None]+fragments(site+str(i)) for i in range(len(d['premises']))]
        out = [[native(d)]]
        if len(choices)==1:
            out = [[native(d),a] for a in choices[0]]
        elif len(choices)==2:
            out = [[native(d),a,b] for a in choices[0] for b in choices[1]]
        return [p for p in out if pattern_size(p)<=maximum]
    for site in by_site:
        for p in fragments(site):
            if pattern_size(p)>=2:
                found[text(p)] = p
    return list(found.values())


def instantiate(cat, pattern, site, fid, charge, cap=8):
    """Bounded guidance pool, never the complete candidate universe."""
    charge(4+len(site))
    if pattern is None:
        return [[]]
    if len(site)>cat.depth:
        return []
    answers = []
    for d in cat.by_out.get(fid,[]):
        charge(10+len(d['id']))
        if native(d)!=pattern[0] or len(pattern)!=len(d['premises'])+1:
            continue
        if d['premises'] and len(site)>=cat.depth:
            continue
        products = [[cat.placement(site,d)]]
        for i,f in enumerate(d['premises']):
            options = instantiate(cat,pattern[i+1],site+str(i),f,charge,cap)
            products = [(a+b) for a in products for b in options][:cap]
        answers.extend(products)
        if len(answers)>=cap:
            break
    return answers[:cap]


def proposals(cat, library, point, legal, selected, excluded, charge, cap):
    result = []; root_ids = set(legal)
    totals, marks = cat.values(selected, charge)
    if totals.get(point,0)!=1 or point not in marks:
        return []
    fid = cat.colors.index(marks[point])
    for item in library:
        charge(1)
        for rows in instantiate(cat,item['pattern'],point,fid,charge):
            if rows[0]['id'] not in root_ids or not cat.valid(rows,selected,set(excluded),charge):
                continue
            result.append(dict(root_site=point, pattern=item['pattern'], placements=rows, family=item['id']))
            if len(result)>=cap:
                return result
    return result


def features(proposal, library):
    rows = proposal['placements']; occupied = {json.loads(p['id'])[0] for p in rows}
    holes = sum(1 for p in rows for point,n in p['t'][1:] if point not in occupied)
    onehot = [float(item['id']==proposal['family']) for item in library]
    return onehot+[len(rows)/4,holes/6,len(proposal['root_site'])/12,1.0]


def probabilities(vectors, weights):
    logits = [sum(a*b for a,b in zip(v,weights)) for v in vectors]
    top = max(logits); exps = [math.exp(max(-60,l-top)) for l in logits]; total = sum(exps)
    return [p/total for p in exps]


class Policy:
    def __init__(self, cat, library, weights, mode, seed, cap, leader_only=False):
        self.cat=cat;self.library=library;self.weights=weights;self.mode=mode;self.rng=random.Random(seed)
        self.cap=cap;self.leader_only=leader_only;self.state=None;self.plans=[];self.actions=[]
        self.records=[];self.orders=[];self.continuation_choices=0;self.observed_realizations=0
        self.proposal_work=0;self.proposal_seconds=0.
    def audit(self,event,state,charge):
        charge(2+len(state['selected']));self.state=state
        selected = {cid for cid,g in state['selected']}
        for plan in self.records:
            if plan.get('dead'):
                continue
            if plan.get('activated') and plan['leader'] not in selected:
                plan['invalidated_by_rollback']=True;plan['dead']=True
            if plan['leader'] in selected:
                plan['activated']=True
            count = sum(p['id'] in selected for p in plan['proposal']['placements'])
            before = plan.get('max_realized',0)
            plan['max_realized']=max(before,count)
            if event['kind']=='PLACED' and event['candidate'] in plan['members']:
                plan['adoptions'].append(dict(candidate=event['candidate'],forced=event['data']['forced'],seq=event['seq']))
            if before<2<=count:
                self.observed_realizations+=1
        self.plans=[p for p in self.plans if not p.get('dead')]
    def __call__(self,request,charge):
        start=time.perf_counter()
        def reserve(n=1):
            self.proposal_work+=n
            charge(n)
        try:
            return self.order(request,reserve)
        finally:
            self.proposal_seconds+=time.perf_counter()-start
    def order(self,request,charge):
        assert self.state is not None
        assert request['selected']==sorted(cid for cid,g in self.state['selected'])
        assert request['excluded']==self.state['excluded']
        assert dict(self.state['domains'])[request['point']]==request['legal']
        selected=request['selected'];excluded=set(request['excluded']);legal=request['legal']
        if not self.leader_only:
            for plan in self.plans:
                if not plan.get('activated'):
                    continue
                remaining=[p for p in plan['proposal']['placements'] if p['id'] not in set(selected)]
                if not self.cat.valid(remaining,selected,excluded,charge):
                    continue
                match=next((p['id'] for p in remaining if p['id'] in legal),None)
                if match:
                    self.continuation_choices+=1
                    plan['guided_later'].append(match)
                    self.orders.append(dict(point=request['point'],candidate=match,kind='CONTINUATION'))
                    return [match]
        if len(self.records)>=200:
            self.orders.append(dict(point=request['point'],kind='RECORD_LIMIT_BASE_FALLBACK'))
            return []
        pool=proposals(self.cat,self.library,request['point'],legal,selected,excluded,charge,self.cap)
        if not pool:
            self.orders.append(dict(point=request['point'],kind='NO_PROPOSAL_BASE_FALLBACK'))
            return []
        vectors=[features(p,self.library) for p in pool];charge(len(pool)*(len(self.weights)+4))
        probs=probabilities(vectors,self.weights)
        if self.mode=='uniform':
            chosen=self.rng.randrange(len(pool))
        elif self.mode=='train':
            chosen=self.rng.choices(range(len(pool)),weights=probs,k=1)[0]
        else:
            chosen=max(range(len(pool)),key=lambda i:probs[i])
        p=pool[chosen];leader=p['placements'][0]['id']
        self.actions.append(dict(chosen=vectors[chosen],expectation=[sum(q*v[j] for q,v in zip(probs,vectors)) for j in range(len(self.weights))]))
        record=dict(proposal={k:p[k] for k in ('root_site','pattern','placements')},family=p['family'],
            leader=leader,selected_before=list(selected),excluded_before=list(request['excluded']),
            members=[r['id'] for r in p['placements']],max_realized=0,adoptions=[],guided_later=[],
            role='LEADER_ONLY_ABLATION' if self.leader_only else 'CLUSTER_CONTINUATION')
        self.records.append(record)
        if not self.leader_only:
            self.plans.append(record)
        else:
            # Observe adoption for the ablation too; do not retain steering plans.
            record['leader_only']=True
        self.orders.append(dict(point=request['point'],candidate=leader,kind='NEW_CLUSTER',family=p['family']))
        return [leader]
    def finish(self,selected):
        selected=set(selected)
        for r in self.records:
            r['final_realized']=sum(p['id'] in selected for p in r['proposal']['placements'])
            r['fully_in_final_proof']=r['final_realized']==len(r['members'])
        return dict(proposals=self.records,orders=self.orders,continuation_choices=self.continuation_choices,
                    proposal_charged_work=self.proposal_work,proposal_seconds=self.proposal_seconds,
                    observed_two_member_realizations=self.observed_realizations,
                    final_two_member_realizations=sum(r['final_realized']>=2 for r in self.records),
                    final_full_realizations=sum(r['fully_in_final_proof'] for r in self.records))


def make_catalogue(modules, compiled, generation, depth):
    model,provider,factory=modules['indexed_proof_provider_v1'].make_provider(compiled,generation,depth,FACTORY)
    assert factory['status']=='COMPLETE'
    return model,provider,factory,Catalogue(compiled,factory['value']['definitions'],depth)


def check_positive(modules, compiled, depth, selected):
    decoded=modules['indexed_proof_provider_v1'].decode(compiled,depth,selected,FACTORY)
    assert decoded['status']=='UNVERIFIED_CERTIFICATE'
    audit=modules['growing_proof_verifier_v2'].verify_tree(compiled,depth,selected,decoded,limits=AUDIT)
    assert audit['status']=='VERIFIED'
    check=modules['independent_fol_checker_v1'].check(compiled['theory'],decoded['proof'],compiled['goal'],CHECK)
    assert check['status']=='VERIFIED',check
    return dict(proof=decoded['proof'],tree=decoded['tree'],tree_audit=audit,host_check=check)


def check_proposals(modules,compiled,depth,policy):
    start=time.perf_counter(); checks=[]
    for record in policy['proposals']:
        check=modules['cluster_verifier'].verify(compiled,depth,record['selected_before'],record['proposal'])
        assert check['status']=='VERIFIED',check
        checks.append(check)
    return dict(checks=checks,seconds=time.perf_counter()-start)


def point_run(modules, compiled, generation, design, lane, library, weights, seed, train=False,raw_path=None):
    started=time.perf_counter()
    model,provider,factory,cat=make_catalogue(modules,compiled,generation,design['depth'])
    mode='train' if train else 'uniform' if lane=='UNIFORM_CLUSTER_GCTS' else 'greedy'
    policy=Policy(cat,library,weights,mode,seed,design['proposal_cap'],lane=='RL_LEADER_ONLY_GCTS')
    remaining=design['search_seconds']-(time.perf_counter()-started)
    if remaining<=0:
        answer=dict(status='UNKNOWN',reason='COLD_FACTORY_WINDOW',verified=False,
            search_seconds=time.perf_counter()-started,stats={},policy=policy.finish([]),
            factory=factory,model=model,provider=provider.snapshot(),result=None,actions=[])
        if raw_path is not None:
            answer['raw_search_ref']=write(raw_path,answer)
        return answer
    limits=dict(wall_seconds=remaining,max_work=1000000000,max_nodes=1000000,max_events=256,
                max_rollback_records=64,max_candidates=5000,max_points=2000)
    result=modules['growing_point_search_v2'].solve(model,limits,enumerate_incident=provider,
        order=None if lane=='LEXICAL_GCTS' else policy,audit=policy.audit)
    elapsed=time.perf_counter()-started
    assert result['entry_state']==result['restored_state']
    answer=dict(status=result['status'],reason=result['reason'],verified=False,search_seconds=elapsed,
        stats=result['stats'],policy=policy.finish(result['selected']),factory=factory,model=model,
        result=result,provider=provider.snapshot(),actions=policy.actions)
    if raw_path is not None:
        answer['raw_search_ref']=write(raw_path,answer)
    answer['independent_cluster_checks']=check_proposals(modules,compiled,design['depth'],answer['policy'])
    if result['status']=='SAT':
        v=time.perf_counter();answer.update(check_positive(modules,compiled,design['depth'],result['selected']))
        answer.update(verified=True,verification_seconds=time.perf_counter()-v)
    return answer


def dfs_control(compiled,cat,library,weights,seconds,cap):
    meter=Meter(seconds);cache={};calls=0;macro_tries=0
    def search(fid,site):
        nonlocal calls,macro_tries
        meter.tick();calls+=1;key=(fid,cat.depth-len(site))
        if key in cache:
            return cache[key]
        if len(site)>cat.depth:
            return None
        # Same family pool and policy scores; conventional search may memoize.
        candidates=[cat.placement(site,d)['id'] for d in cat.by_out.get(fid,[]) if not d['premises'] or len(site)<cat.depth]
        # A local artificial receptor supplies precisely the requested formula.
        pool=[]
        for item in library:
            for rows in instantiate(cat,item['pattern'],site,fid,meter.tick):
                if rows[0]['id'] in candidates:
                    pool.append(dict(root_site=site,pattern=item['pattern'],placements=rows,family=item['id']))
                if len(pool)>=cap:break
            if len(pool)>=cap:break
        def complete(f,p,forced):
            d=forced.get(p)
            if d is None:
                return search(f,p)
            children=[]
            for i,premise in enumerate(d['premises']):
                child=complete(premise,p+str(i),forced)
                if child is None:return None
                children.append(child)
            return [d['id'],children]
        if pool:
            vectors=[features(p,library) for p in pool];probs=probabilities(vectors,weights)
            p=pool[max(range(len(pool)),key=lambda i:probs[i])];macro_tries+=1
            forced={json.loads(r['id'])[0]:cat.decode_id(r['id'])[1] for r in p['placements']}
            tree=complete(fid,site,forced)
            if tree is not None:
                cache[key]=tree;return tree
        for d in cat.by_out.get(fid,[]):
            meter.tick(10+len(d['id']))
            if d['premises'] and len(site)>=cat.depth:continue
            children=[]
            for i,f in enumerate(d['premises']):
                child=search(f,site+str(i))
                if child is None:break
                children.append(child)
            if len(children)==len(d['premises']):
                tree=[d['id'],children];cache[key]=tree;return tree
        cache[key]=None;return None
    try:
        tree=search(compiled['goal_id'],'')
        selected=[]
        def expand(t,site):
            meter.tick();selected.append(text([site,t[0]]))
            for i,c in enumerate(t[1]):expand(c,site+str(i))
        if tree is not None:expand(tree,'')
        return dict(status='DERIVABLE' if tree else 'NOT_DERIVABLE',selected=sorted(selected),
            stats=dict(nodes=calls,work=meter.work,cache_entries=len(cache),macro_tries=macro_tries))
    except Stop as error:
        return dict(status='UNKNOWN',reason=str(error),selected=[],stats=dict(nodes=calls,work=meter.work,cache_entries=len(cache),macro_tries=macro_tries))


def control_run(modules,compiled,generation,design,lane,library,weights,raw_path=None):
    started=time.perf_counter()
    if lane=='DP_CONTROL':
        result=modules['growing_proof_verifier_v2'].tree_control(compiled,design['depth'],
            dict(max_depth=256,max_items=10000000,max_proof_lines=4096,max_states=200000,
                 max_work=1000000000,wall_seconds=design['search_seconds']))
        selected=result.get('details',{}).get('selected',[])
    else:
        model,provider,factory,cat=make_catalogue(modules,compiled,generation,design['depth'])
        remaining=design['search_seconds']-(time.perf_counter()-started)
        result=dfs_control(compiled,cat,library,weights,remaining,design['proposal_cap']) if remaining>0 else dict(status='UNKNOWN',reason='COLD_FACTORY_WINDOW',selected=[],stats={})
        selected=result['selected']
    out=dict(status=result['status'],verified=False,search_seconds=time.perf_counter()-started,
        reason=result.get('reason'),stats=result.get('stats',{}),result=result)
    if raw_path is not None:
        out['raw_search_ref']=write(raw_path,out)
    if result['status']=='DERIVABLE':
        v=time.perf_counter();out.update(check_positive(modules,compiled,design['depth'],selected))
        out.update(verified=True,verification_seconds=time.perf_counter()-v)
    return out


def run(output):
    started=time.perf_counter();frozen=json.loads((ROOT/'cohort-v1.json').read_bytes())
    design=frozen['design'];modules=load_modules();output.mkdir(exist_ok=False)
    preparations={};prep_seconds=0
    for case in frozen['cases']:
        t=time.perf_counter();compiled,generation=compile_case(case)
        zero_checks=[modules['independent_fol_checker_v1'].check(compiled['theory'],[z['line']],
                     z['line']['formula'],CHECK) for z in compiled['zero_instances']]
        assert all(c['status']=='VERIFIED' for c in zero_checks)
        model,provider,factory,cat=make_catalogue(modules,compiled,generation,design['depth'])
        factory_check=modules['growing_proof_verifier_v2'].verify_factory(compiled,generation,design['depth'],model,factory,limits=AUDIT)
        assert factory_check['status']=='VERIFIED'
        preparations[case['id']]=(compiled,generation)
        prep_seconds+=time.perf_counter()-t
        write(output/(case['id']+'-preparation.json.gz'),dict(case=case,compiled=compiled,generation=generation,
            zero_checks=zero_checks,factory_check=factory_check))
    library_by_key={};donors=[];t=time.perf_counter()
    for case in frozen['cases'][:8]:
        c,g=preparations[case['id']]
        answer=control_run(modules,c,g,design,'DP_CONTROL',[],[],raw_path=output/(case['id']+'-discovery-raw.json.gz'))
        donors.append(dict(case_id=case['id'],status=answer['status'],verified=answer['verified'],seconds=answer['search_seconds']))
        write(output/(case['id']+'-discovery.json.gz'),answer)
        if answer['verified']:
            model,p,f,cat=make_catalogue(modules,c,g,design['depth'])
            for pattern in mine(answer['tree'],cat,design['cluster_nodes']):
                key=text(pattern)
                if key not in library_by_key:
                    library_by_key[key]=dict(id=hashlib.sha256(key.encode()).hexdigest()[:16],pattern=pattern,training_origins=[])
                library_by_key[key]['training_origins'].append(case['id'])
    library=sorted(library_by_key.values(),key=lambda x:x['id'])
    discovery_seconds=time.perf_counter()-t
    write(output/'library-v1.json',dict(library=library,donors=donors,seconds=discovery_seconds,
        scope='Acquired by conventional automated training proof search; not hand-written and not a GCTS lemma-discovery claim. Shared unchanged with all cluster controls.'))
    weights=[0.0]*(len(library)+4);baseline=0.;episodes=[];rng=random.Random(design['training_seed']);t=time.perf_counter()
    for episode in range(design['train_episodes']):
        case=frozen['cases'][episode%8];c,g=preparations[case['id']]
        answer=point_run(modules,c,g,design,'RL_CLUSTER_GCTS',library,weights,rng.randrange(1<<31),train=True,
            raw_path=output/('training-'+str(episode).zfill(3)+'-raw.json.gz'))
        branches=answer['stats'].get('branches',0)
        reward=(1. if answer['verified'] else -1.)-.05*math.log1p(branches)-.02*math.log1p(answer['stats'].get('backtracks',0))-.01*math.log1p(answer['policy']['proposal_charged_work'])
        advantage=reward-baseline;baseline=.9*baseline+.1*reward
        if answer.get('actions'):
            for action in answer['actions']:
                for j in range(len(weights)):
                    weights[j]+=.08*advantage*(action['chosen'][j]-action['expectation'][j])/len(answer['actions'])
                    weights[j]=max(-8.,min(8.,weights[j]))
        episodes.append(dict(index=episode,case_id=case['id'],reward=reward,verified=answer['verified'],
            seconds=answer['search_seconds'],proposals=len(answer['policy']['proposals']),
            continuation_choices=answer['policy']['continuation_choices'],weights=list(weights)))
        write(output/('training-'+str(episode).zfill(3)+'.json.gz'),answer)
        print(json.dumps(dict(stage='training',episode=episode,verified=answer['verified'],library=len(library))),flush=True)
    training=dict(episodes=episodes,seconds=time.perf_counter()-t,weights=weights,baseline=baseline)
    write(output/'frozen-policy-v1.json',dict(library_sha256=sha(library),weights=weights,training=training))
    policy_pin=sha([library,weights]);evaluation=[]
    for i,case in enumerate(frozen['cases'][8:]):
        c,g=preparations[case['id']];row=dict(id=case['id'],problem=case['problem'],quantified=case['quantified'],lanes={})
        for lane in LANES:
            raw_path=output/(case['id']+'-'+lane+'-raw.json.gz')
            answer=point_run(modules,c,g,design,lane,library,weights,7000+i,raw_path=raw_path) if lane.endswith('GCTS') else control_run(modules,c,g,design,lane,library,weights,raw_path=raw_path)
            ref=write(output/(case['id']+'-'+lane+'.json.gz'),answer)
            row['lanes'][lane]={k:answer[k] for k in ('status','verified','search_seconds','stats','reason') if k in answer}
            for k in ('proof','tree','policy','verification_seconds'):
                if k in answer:row['lanes'][lane][k]=answer[k]
            row['lanes'][lane]['raw_ref']=ref
            assert sha([library,weights])==policy_pin
        evaluation.append(row)
        print(json.dumps(dict(stage='evaluation',case=case['id'],positives={k:v['verified'] for k,v in row['lanes'].items()})),flush=True)
    summary={lane:dict(verified=sum(r['lanes'][lane]['verified'] for r in evaluation),
        finite_negative=sum(r['lanes'][lane]['status'] in ('UNSAT','NOT_DERIVABLE') for r in evaluation),
        unknown=sum(r['lanes'][lane]['status']=='UNKNOWN' for r in evaluation),
        search_seconds=sum(r['lanes'][lane]['search_seconds'] for r in evaluation)) for lane in LANES}
    result=dict(schema='CP-cluster-policy-experiment-v1',design=design,cohort_sha256=sha(frozen),library=library,
        discovery=dict(donors=donors,seconds=discovery_seconds),training=training,evaluation=evaluation,
        summary=summary,preparation_seconds=prep_seconds,seconds=time.perf_counter()-started,
        assessment=['Pilot synthetic Horn fragments with finite term pools; no substantial new arithmetic or Hilbert theorem.',
            'Clusters are proposals/continuation preferences, not atomic placements. Global scheduling and complete base fallback remain unchanged.',
            'The same learned library/policy is available to a memoized conventional cluster control. Dynamic programming is an additional strong control.',
            'Leader-only ablation is necessary: actual second guided choices and multi-member realization determine whether this is more than leader ranking.',
            'Learning, discovery, matching/validation, audit snapshots and verification costs are disclosed; no automatic speed superiority claim.'])
    write(output/'cluster-policy-results-v1.json',result)
    print(json.dumps(dict(stage='complete',summary=summary,library=len(library),seconds=result['seconds'])),flush=True)


def qualify(output):
    """New small fixtures and adversarial proposals, never held-out targets."""
    modules=load_modules()
    p=lambda name:['pred',name,[]]
    case=dict(quantified=False,max_term=0,problem=dict(theory=dict(functions={},
        predicates={n:0 for n in ('P','Q','R')},axioms={'p':p('P'),
        'pq':['imp',p('P'),p('Q')],'rq':['imp',p('R'),p('Q')]}),goal=p('Q')))
    compiled,generation=compile_case(case)
    design=dict(depth=4,search_seconds=2,proposal_cap=48)
    pattern=['MP',['ZERO:axiom'],None]
    library=[dict(id='fixture-open-MP',pattern=pattern,training_origins=['qualification-only'])]
    answer=point_run(modules,compiled,generation,design,'RL_CLUSTER_GCTS',library,[0.]*5,17)
    assert answer['verified'] and answer['policy']['proposals']
    example=answer['policy']['proposals'][0]
    good=example['proposal'];selected=example['selected_before']
    verifier=modules['cluster_verifier'];mutants=[]
    bad=copy.deepcopy(good);bad['placements'][0]['t'][0][1]=True;mutants.append(bad)
    bad=copy.deepcopy(good);bad['placements'][0]['t'][0][1]=1.0;mutants.append(bad)
    bad=copy.deepcopy(good);bad['placements'][0]['m'][0][1]='wrong';mutants.append(bad)
    bad=copy.deepcopy(good);bad['placements'].append(copy.deepcopy(bad['placements'][0]));mutants.append(bad)
    bad=copy.deepcopy(good);bad['pattern']=['GEN',None];mutants.append(bad)
    bad=copy.deepcopy(good);bad['root_site']='1';mutants.append(bad)
    mutant_checks=[verifier.verify(compiled,4,selected,bad) for bad in mutants]
    assert all(c['status']=='REJECTED' for c in mutant_checks)
    control=control_run(modules,compiled,generation,design,'CLUSTER_DFS_CONTROL',library,[0.]*5)
    dp=control_run(modules,compiled,generation,design,'DP_CONTROL',library,[0.]*5)
    assert control['verified'] and dp['verified']
    v=['var','x'];fv=['fun','f',[v]]
    px=['pred','P',[v]];qx=['pred','Q',[fv]]
    first_order=dict(quantified=True,max_term=1,problem=dict(theory=dict(functions={'f':1},
        predicates={'P':1,'Q':1},axioms={'p':['all','x',px],
        'pq':['all','x',['imp',px,qx]]}),goal=['all','x',qx]))
    fc,fg=compile_case(first_order)
    zero_checks=[modules['independent_fol_checker_v1'].check(fc['theory'],[z['line']],z['line']['formula'],CHECK)
                 for z in fc['zero_instances']]
    assert all(z['status']=='VERIFIED' for z in zero_checks)
    fo=point_run(modules,fc,fg,dict(design,depth=6),'RL_CLUSTER_GCTS',library,[0.]*5,19)
    assert fo['verified']
    value=dict(schema='CP-qualification-v1',status='PASS',point=answer,cluster_control=control,
        dp_control=dp,first_order=fo,zero_checks=zero_checks,mutant_checks=mutant_checks,
        scope='Separate structural fixtures only. No cohort truth labels, training, or old spent run reused.')
    return write(output,value)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--freeze',action='store_true');parser.add_argument('--run');parser.add_argument('--qualify')
    args=parser.parse_args()
    if args.freeze:print(json.dumps(freeze(),sort_keys=True))
    elif args.qualify:print(json.dumps(qualify(Path(args.qualify)),sort_keys=True))
    elif args.run:run(Path(args.run))
    else:parser.error('--freeze or --run is required')
