"""Passive saved-record/projection review; no archived scientific code executes."""
import gzip
import hashlib
import json
import math
from pathlib import Path

R = Path(__file__).resolve().parents[1]
P = R / 'report/rendered-v2'
H = P / 'cluster-policy-proof-search-v1.html'
J = P / 'cluster-policy-results-v1.json'


def pin(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def read(ref):
    p = Path(ref['path'])
    b = p.read_bytes()
    assert pin(p) == ref, ('pin', p)
    return json.loads(gzip.decompress(b)) if p.name.endswith('.gz') else json.loads(b)


def canon(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'))


def trace(f):
    r = f['result']
    if 'events' not in r:
        return 0, 0
    n = 0
    streams = [(r['events'], r['event_extent']), (r['rollback_records'], r['rollback_extent']),
               (r['provider_evidence']['records'], r['provider_evidence'])]
    for rows, extent in streams:
        assert len(rows) == extent['retained'] == extent['total']
        assert hashlib.sha256(''.join(canon(x) + '\n' for x in rows).encode()).hexdigest() == extent['sha256']
        n += len(rows)
    return 3, n


def main():
    assert (pin(H)['bytes'], pin(H)['sha256']) == (25290, '3d2e1d05ba291322aa338c99246c2344b1f892f44f511950c6bfe0f1b15f8a17')
    assert (pin(J)['bytes'], pin(J)['sha256']) == (2987179, '5dd8ff0a92f25d02e86deb8c61dcd14f77b41227f0250db9cb0144005d3b4f83')
    d = json.loads(J.read_bytes())
    original = json.loads((R / 'actual-v1/cluster-policy-results-v1.json').read_bytes())
    obs = json.loads((R / 'observation-v1/observer-result.json').read_bytes())
    assert obs['status'] == 'COMPLETE' and obs['returncode'] == 0 and obs['runtime_source_guards_unchanged']
    observed = {ref['path']: ref for ref in obs['files']}
    for key in ['schema', 'cohort_sha256', 'discovery', 'library', 'training', 'preparation_seconds', 'seconds']:
        assert d[key] == original[key], key
    keys = ['LEXICAL_GCTS', 'UNIFORM_CLUSTER_GCTS', 'RL_CLUSTER_GCTS', 'RL_LEADER_ONLY_GCTS', 'CLUSTER_DFS_CONTROL', 'DP_CONTROL']
    assert d['design']['lanes'] == keys and len(d['evaluation']) == 16 and len(d['training']['episodes']) == 32
    assert [r['id'] for r in d['evaluation']] == [r['id'] for r in original['evaluation']]
    counts = {k: dict(verified=0, finite=0, unknown=0, search_seconds=0) for k in keys}
    positions = proofs = prooflines = tiles = proposals = members = streams = rows = guided = final_occ = max_q = 0
    distinct, final_targets = set(), set()
    for case, base in zip(d['evaluation'], original['evaluation']):
        assert case['problem'] == base['problem']
        preparation = R / 'actual-v1' / (case['id'] + '-preparation.json.gz')
        prep = read(observed[str(preparation)])
        forms = prep['compiled']['logical_basis']['formulas']
        defs = None
        for key in keys:
            lane = case['lanes'][key]
            assert lane['raw_ref'] == observed[lane['raw_ref']['path']]
            full = read(lane['raw_ref'])
            positions += 1
            for field in ['status', 'verified', 'search_seconds', 'verification_seconds', 'proof', 'tree', 'stats', 'reason']:
                assert lane.get(field) == full.get(field), (case['id'], key, field)
            assert lane['finite_exhausted'] == (full['status'] in ('UNSAT', 'NOT_DERIVABLE'))
            c = counts[key]
            c['verified' if full['verified'] else 'finite' if lane['finite_exhausted'] else 'unknown'] += 1
            c['search_seconds'] += full['search_seconds']
            raw = read(full['raw_search_ref'])
            assert raw['result'] == full['result'] and raw['status'] == full['status']
            a, b = trace(full)
            streams += a
            rows += b
            if 'factory' in full:
                current = {x['id']: x for x in full['factory']['value']['definitions']}
                if defs is None:
                    defs = current
                else:
                    assert defs == current
            if full['verified']:
                proofs += 1
                proof = full['proof']
                prooflines += len(proof)
                tree = full['tree']
                selected = set(tree['selected'])
                mapping = dict(tree['site_to_line'])
                assert full['host_check']['status'] == full['tree_audit']['status'] == 'VERIFIED'
                assert lane['checks'] == {x: full[x] for x in ('tree_audit', 'host_check')}
                assert set(mapping.values()) == set(range(len(proof)))
                assert {p['id'] for p in tree['placements']} == selected
                for tile in tree['placements']:
                    site, identity = json.loads(tile['id'])
                    definition = defs[identity]
                    line = proof[mapping[site]]
                    assert line['rule'] == definition['native_rule'] and line['formula'] == forms[definition['output']]
                    tiles += 1
                    points = [site] + [site + str(i) for i in range(len(definition['premises']))]
                    values = [forms[definition['output']]] + [forms[i] for i in definition['premises']]
                    assert tile['t'] == [[p, 1] for p in points]
                    assert [(p, json.loads(v)) for p, v in tile['m']] == list(zip(points, values))
                assert proof[-1]['formula'] == case['problem']['goal']
                for i, line in enumerate(proof):
                    assert line['rule'] in ('axiom', 'mp', 'generalize', 'instantiate')
                    refs = [line['antecedent'], line['implication']] if line['rule'] == 'mp' else [line['source']] if line['rule'] == 'generalize' else []
                    assert all(type(j) is int and 0 <= j < i for j in refs)
            else:
                selected = set()
            if 'policy' not in full:
                continue
            qlist = lane['policy']['proposals']
            rawqs = full['policy']['proposals']
            checks = full['independent_cluster_checks']['checks']
            assert len(qlist) == len(rawqs) == len(checks)
            max_q = max(max_q, len(qlist))
            assert len(qlist) < 200
            for field, value in full['policy'].items():
                if field != 'proposals':
                    assert lane['policy'][field] == value
            for q, rawq, check in zip(qlist, rawqs, checks):
                proposals += 1
                assert q['independent_check'] == check and check['status'] == 'VERIFIED'
                for field, value in rawq.items():
                    if field not in ('proposal', 'adopted_members', 'realized_count', 'fully_realized', 'independent_check', 'adoption_scope'):
                        assert q[field] == value
                assert q['proposal']['root_site'] == rawq['proposal']['root_site'] and q['proposal']['pattern'] == rawq['proposal']['pattern']
                expected = [p['id'] for p in rawq['proposal']['placements'] if p['id'] in selected]
                assert q['adopted_members'] == expected and q['realized_count'] == q['final_realized'] == len(expected)
                assert q['fully_realized'] == (len(expected) == len(q['members']) and full['verified'])
                assert len(q['proposal']['placements']) == len(rawq['proposal']['placements'])
                for p, rp in zip(q['proposal']['placements'], rawq['proposal']['placements']):
                    members += 1
                    assert {x: p[x] for x in ('id', 't', 'm')} == rp
                    site, identity = json.loads(p['id'])
                    definition = defs[identity]
                    assert p['site'] == site and p['rule'] == definition['native_rule'] and p['formula'] == forms[definition['output']]
                    assert p['premise_sites'] == [site + str(i) for i in range(len(definition['premises']))]
                    assert p['premise_formulas'] == [forms[i] for i in definition['premises']]
                if key == 'RL_CLUSTER_GCTS':
                    for adoption in q['adoptions']:
                        if not adoption['forced'] and adoption['candidate'] in q['guided_later']:
                            guided += 1
                            if adoption['candidate'] in selected:
                                final_occ += 1
                                distinct.add((case['id'], adoption['candidate']))
                                final_targets.add(case['id'])
    for i, episode in enumerate(d['training']['episodes']):
        path = R / 'actual-v1' / ('training-%03d.json.gz' % i)
        full = read(observed[str(path)])
        assert episode['verified'] == full['verified'] and episode['seconds'] == full['search_seconds']
        a, b = trace(full)
        streams += a
        rows += b
    assert positions == 96 and [counts[k]['verified'] for k in keys] == [8, 5, 7, 6, 8, 8]
    assert all(counts[k]['finite'] == 8 for k in keys)
    assert (guided, final_occ, len(distinct), len(final_targets)) == (25, 12, 11, 5)
    assert (streams, rows) == (288, 9667)

    def safe(x):
        if type(x) is int:
            assert abs(x) <= 9007199254740991
        elif isinstance(x, float):
            assert math.isfinite(x)
        elif isinstance(x, list):
            for value in x:
                safe(value)
        elif isinstance(x, dict):
            for value in x.values():
                safe(value)

    safe(d)
    html = H.read_text()
    assert 'not an atomic macro' in html and 'final certificate, not chronological adoption' in html and 'same policy and library' in html
    assert 'did not beat lexical' in d['summary'][0] and 'not robust timing evidence' in d['summary'][-1]
    assert any('No overall speed' in x for x in d['limitations']) and any('Two budget-interrupted' in x for x in d['limitations'])
    receipt = dict(schema='CP-independent-passive-projection-review-v1', status='PASS_SAVED_CONTENT_AND_PROJECTION', blockers=[], html=pin(H), public_json=pin(J), raw_results=pin(R / 'actual-v1/cluster-policy-results-v1.json'), reviewer_source=pin(Path(__file__)), positions=positions, verified_proofs=proofs, proof_lines=prooflines, exact_selected_tile_bindings=tiles, proposals=proposals, enriched_members=members, max_retained_proposals=max_q, counts=counts, RL_later_nonforced=dict(observed=guided, final_occurrences=final_occ, distinct_final_target_members=len(distinct), successful_targets=len(final_targets)), complete_streams=streams, retained_and_rehashed_rows=rows, training_episodes=32, training_verified=sum(e['verified'] for e in d['training']['episodes']), numeric_JS_safe=True, scope='All 96 saved method positions bound to pinned raw full/search records; exact proof arrays, selected placement/formula bindings, enriched requested members and final-certificate member IDs checked. All 288 complete saved streams rehashed. Wording distinguishes final membership from observed-ever adoption, finite closure from unknown, training costs and absence of superiority. Structural reference checks only; no solver, logical kernel, materializer, browser or publication executed. Scientific output unchanged.')
    output = R / 'report/independent-projection-review-v1.json'
    with output.open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(pin(output), sort_keys=True))
    print(json.dumps({key: receipt[key] for key in ('positions', 'verified_proofs', 'proof_lines', 'exact_selected_tile_bindings', 'proposals', 'enriched_members', 'complete_streams', 'retained_and_rehashed_rows', 'max_retained_proposals')}))


if __name__ == '__main__':
    main()
