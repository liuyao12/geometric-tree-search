"""Package an explicit, bounded public study cut; no scientific imports/calls."""
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def raw(v):
    return (json.dumps(v,sort_keys=True,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()


def read(p):
    assert p.is_relative_to(ROOT) and p.resolve()==p and not p.is_symlink()
    before=p.stat();assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=67108864
    b=p.read_bytes();after=p.stat()
    assert len(b)==before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
    return b,stat.S_IMODE(before.st_mode)


def ref(p,b):
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def build():
    admission=json.loads((ROOT/'milestone-admission-v1.json').read_bytes());assert admission['status']=='ADMITTED'
    observer=json.loads((ROOT/'observation-v1/observer-result.json').read_bytes())
    assert observer['status']=='COMPLETE' and observer['returncode']==0 and observer['runtime_source_guards_unchanged']
    paths={Path(v['path']) for v in observer['files']}
    assert len(paths)==299
    for entry in observer['files']:
        assert ref(Path(entry['path']),read(Path(entry['path']))[0])==entry
    explicit=[
        'cluster_policy_experiment_v1.py','observe_experiment_v1.py','cohort-v1.json','qualification-v2.json.gz',
        'milestone-admission-v1.json','reference/cluster_verifier_v2.py','reference/cluster-verifier-API-v2.json',
        'upstream/growing_point_search_v2.py','upstream/indexed_proof_provider_v1.py',
        'upstream/growing_proof_verifier_v2.py','upstream/independent_fol_checker_v1.py',
        'upstream/basic-tiling-algorithm.md','upstream/extraction-receipt-v1.json',
        'observation-v1/observer-result.json','observation-v1/stdout.log','observation-v1/stderr.log',
        'review/indexed-cluster-policy-interface-v1.json','review/cluster-driver-source-peer-v1.json',
        'review/cluster-driver-source-peer-v2.json','review/main-passive-custody-review-v1.json',
        'review/main-passive-custody-support-v1.json','review/main-passive-filehash-index-v1.json',
        'review/passive_main_custody_v1.py','review/cluster-main-passive-review-v1.json',
        'review/cluster-passive-evidence-support-v1.json','review/passive_cluster_evidence_v1.py',
        'report/cluster-policy-template-v1.html','report/materialize_cluster_report_v1.py',
        'report/independent-projection-review-v1.json','report/review_cluster_projection_v1.py',
        'report/rendered-v2/cluster-policy-proof-search-v1.html','report/rendered-v2/cluster-policy-results-v1.json',
        'qa/local-reader-qa-v1.json','qa/local-cluster-reader-v1.png','report/package_cluster_evidence_v1.py']
    paths.update(ROOT/p for p in explicit)
    entries=[];total=0
    for p in sorted(paths):
        assert p.suffix!='.zip' and '.git' not in p.parts and not any(x in p.parts for x in ('sessions','node_modules','private-recovery'))
        b,mode=read(p);total+=len(b);assert total<=1073741824
        entries.append(dict(name='originals/'+p.relative_to(ROOT).as_posix(),source_ref=ref(p,b),mode=mode))
    manifest=dict(schema='CP-public-complete-recorded-evidence-manifest-v1',entries=entries,
        originals=len(entries),original_bytes=total,admission=ref(ROOT/'milestone-admission-v1.json',read(ROOT/'milestone-admission-v1.json')[0]),
        scope=['All299returnedscientificfiles, Sources/frozeninputs/runtimehashes/qualification/peerreviews/report/QA are selected explicitly.',
               'Runtimebinary, otherworkspaces, privatechat/sessionlogs, nestedoldZIP, retiredmaterials andfuturepublicationreceipts are excluded.',
               'Thisarchive includescompleteemittedstreams andallchosenproposals, notunchosenpools ornonreturningbudgetinterruptedcallbackcontents.',
               'No archived code executes during packaging. Future deployment/live verification is a separate durable supplement.'],
        upstream=dict(url='https://liuyao12.github.io/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/history-marked-proof-search-evidence-v1.zip',
            bytes=4825184,sha256='6cc21e851efc1beb7bffb170d1c9f1a5da0adc112d28873df4933bbe33977844',scope='External provenance pin only. All four operative upstream Python Sources and current master are individually vendored.'))
    out=ROOT/'report/package-v1';out.mkdir(exist_ok=False);name=out/'cluster-policy-evidence-v1.zip'
    readme=b'''Recorded synthetic proof-cluster policy experiment. MANIFEST.json maps every member to original bytes, SHA256, mode and path.
50 rule-shape families were mined from four automatically found training proofs; 32 reward-updated episodes precede 16 held-out systems.
All 96 method positions remain: verified positives 8 lexical / 5 uniform / 7 RL clusters / 6 leader-only / 8 cluster DFS / 8 DP.
Eight finite negative closures per method are bounded-basis/depth results, not unrestricted nonprovability.
The trained method does not beat lexical GCTS or the conventional controls. The leader-only difference is near the wall cutoff.
Clusters guide base continuations after ordinary global propagation and earliest-generation selection; no atomic macro or sampled candidate domain is used.
Full proof certificates, chosen proposals and emitted event/query/rollback streams are included. Unchosen pools and unreturned callback internals are not invented.
Independent kernel/point/verifier receipts and saved-data reviews are retained. No claim to substantial new arithmetic/Hilbert theorems, semantic lemma learning, a fixed universal Wang palette, learned failure markings or plane tilings.
No private chats/recovery sessions, runtime binary, retired materials data or unrelated work is included. The earlier upstream ZIP is externally pinned, not nested.
The closed ZIP cannot contain its own later package/deployment/live receipts. These are a separate durable supplement.
'''
    with zipfile.ZipFile(name,'x',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
        for e in entries+[dict(name='MANIFEST.json',data=raw(manifest),mode=0o644),dict(name='README.txt',data=readme,mode=0o644)]:
            b=e['data'] if 'data' in e else read(Path(e['source_ref']['path']))[0]
            info=zipfile.ZipInfo(e['name'],(1980,1,1,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|e['mode'])<<16
            z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    assert name.stat().st_size<=67108864
    with zipfile.ZipFile(name) as z:
        assert len(z.namelist())==len(entries)+2 and len(set(z.namelist()))==len(entries)+2 and z.testzip() is None
        for e in entries:
            p=Path(e['source_ref']['path']);b,mode=read(p);inside=z.read(e['name'])
            assert b==inside and ref(p,inside)==e['source_ref'] and mode==e['mode']
            assert z.getinfo(e['name']).external_attr>>16==stat.S_IFREG|mode
        assert z.read('MANIFEST.json')==raw(manifest) and z.read('README.txt')==readme
    (out/'MANIFEST.json').write_bytes(raw(manifest))
    receipt=dict(schema='CP-full-package-readback-v1',status='COMPLETE',archive=ref(name,read(name)[0]),
        manifest=ref(out/'MANIFEST.json',read(out/'MANIFEST.json')[0]),members=len(entries)+2,originals=len(entries),
        original_bytes=total,all_raw_members_origins_modes_CRCs=True,scope='Closed prepublication cut only; no future supplement recursively included.')
    (out/'package-readback.json').write_bytes(raw(receipt))
    print(json.dumps(receipt,sort_keys=True))


if __name__=='__main__':build()
