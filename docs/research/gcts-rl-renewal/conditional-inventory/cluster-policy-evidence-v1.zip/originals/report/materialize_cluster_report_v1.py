"""Project the complete recorded experiment; never import scientific code."""
import copy
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]


def pin(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def read(ref):
    p=Path(ref['path']);assert pin(p)==ref
    return json.loads(gzip.decompress(p.read_bytes())) if p.name.endswith('.gz') else json.loads(p.read_bytes())


def build():
    source=ROOT/'actual-v1/cluster-policy-results-v1.json'
    original=json.loads(source.read_bytes());public=copy.deepcopy(original)
    observation=json.loads((ROOT/'observation-v1/observer-result.json').read_bytes())
    assert observation['status']=='COMPLETE' and observation['returncode']==0 and observation['runtime_source_guards_unchanged']
    assert len(original['evaluation'])==16 and len(original['training']['episodes'])==32
    lane_names=original['design']['lanes'];assert len(lane_names)==6
    counters={};total_guided=0;final_guided=0;distinct_final=set()
    for case in public['evaluation']:
        for lane in lane_names:
            projected=case['lanes'][lane];full=read(projected['raw_ref'])
            assert projected['status']==full['status'] and projected['verified'] is full['verified']
            projected['finite_exhausted']=full['status'] in ('UNSAT','NOT_DERIVABLE')
            if full['verified']:
                assert full['tree_audit']['status']==full['host_check']['status']=='VERIFIED'
                assert projected['proof']==full['proof'] and projected['tree']==full['tree']
                projected['checks']={k:full[k] for k in ('tree_audit','host_check')}
            if 'policy' not in full:continue
            defs={d['id']:d for d in full['factory']['value']['definitions']}
            preparation=ROOT/'actual-v1'/(case['id']+'-preparation.json.gz')
            compiled=json.loads(gzip.decompress(preparation.read_bytes()))['compiled']
            forms=compiled['logical_basis']['formulas']
            selected=set(full['tree']['selected']) if full['verified'] else set()
            qs=projected['policy']['proposals'];checks=full['independent_cluster_checks']['checks']
            assert len(qs)==len(checks)
            for q,check in zip(qs,checks):
                assert check['status']=='VERIFIED'
                q['independent_check']=check
                q['adopted_members']=[p['id'] for p in q['proposal']['placements'] if p['id'] in selected]
                q['realized_count']=len(q['adopted_members'])
                q['fully_realized']=q['realized_count']==len(q['members']) and full['verified']
                q['adoption_scope']='Exact membership in an independently checked final certificate; observed-ever chronology is separate.'
                assert q['realized_count']==q['final_realized']
                enriched=[]
                for p in q['proposal']['placements']:
                    site,identity=json.loads(p['id']);d=defs[identity]
                    enriched.append(dict(p,site=site,rule=d['native_rule'],formula=forms[d['output']],
                        premise_sites=[site+str(i) for i in range(len(d['premises']))],
                        premise_formulas=[forms[i] for i in d['premises']]))
                q['proposal']['placements']=enriched
                if lane=='RL_CLUSTER_GCTS':
                    for adoption in q['adoptions']:
                        if not adoption['forced'] and adoption['candidate'] in q['guided_later']:
                            total_guided+=1
                            if adoption['candidate'] in selected:
                                final_guided+=1;distinct_final.add((case['id'],adoption['candidate']))
    assert total_guided==25 and final_guided==12 and len(distinct_final)==11
    public['summary']=[
        'The trained cluster policy did not beat lexical GCTS: 7 verified proofs versus 8. The uniform cluster control found 5, leader-only found 6, and both conventional controls found all 8.',
        'Each method closed the same eight other targets within the declared finite basis and depth. Unknowns were 0 lexical, 3 uniform, 1 RL continuation, 2 leader-only, and 0 for either conventional control.',
        'RL plans guided 25 later nonforced placements. Twelve adoption occurrences (11 distinct target/member pairs across five successful targets) have member IDs in independently checked final proofs. Other choices occurred on branches that were later undone.',
        'The 7-versus-6 leader-only difference is one near-cutoff observation on test-ground-3; it is not robust timing evidence. The clean mechanism example is test-ground-0: two later nonforced choices survive in a five-line checked proof, with zero backtracks.'
    ]
    d=public['design'];d['notes']=[
        'Theories and goals were frozen before truth labels or training. Training uses eight systems; evaluation uses sixteen new systems with different signature sizes and a deeper functional-term pool. Feature inputs contain rule shapes and structural counts, not predicate names. This does not establish disjoint reachable proof cores up to renaming.',
        'Four successful conventional training proofs supplied the 50 rule-shape families. This is automatic donor acquisition, not GCTS discovery of semantic lemmas. Every instantiated proposal has an inspectable base expansion and an independent point-binding check.',
        f"Shared compilation, zero-rule kernel checks and factory checks took {original['preparation_seconds']:.4f} seconds. Donor acquisition and mining took {original['discovery']['seconds']:.4f} seconds. Training took {original['training']['seconds']:.4f} seconds; 12 of 32 training episodes ended with a verified proof.",
        'Each search has a nominal 0.5-second cold factory/search window. Matching, point validation, policy inference, full audit snapshots and normal engine work are inside that window. File recording and independent post-search checks are outside it and included in whole-experiment time.',
        'The six methods run once in a fixed order per target. Proposal pools are bounded guidance, never candidate domains; the base fallback remains complete. The first 200 chosen proposals per search are retained; after that new proposals fall back to base ordering, while previously validated pending plans may continue.',
        'This is a finite Horn/instantiation experiment. Every positive proof is checked in its original stated theory. It does not implement Peano induction, full Hilbert geometry, learned failure markings, turtle/Penrose tiling or one fixed universal Wang palette.'
    ]
    public['limitations']=[
        'No overall speed or proof-coverage advantage was found. The measured aggregate cold search times were approximately 0.87 seconds lexical, 2.62 uniform clusters, 1.66 RL clusters, 1.76 leader-only, 0.13 memoized cluster DFS and 0.11 dynamic programming. Unknowns and training costs prevent treating these totals as matched successful-search speedups.',
        'Proof certificates and all chosen-proposal records are complete. Unchosen candidate pools are not all retained. All 288 emitted event/query/rollback streams fit their configured retention limits and were independently rehashed in full (9,667 rows). The held-out RL event sequences contain all 953 events. Two budget-interrupted ordering calls returned no preference; no missing return is fabricated.',
        'A family is a reusable composition of native inference roles, instantiated by exact current-receptor bindings. It is not yet a learned semantic theorem, nor an atomic macro; all constituent moves still use the ordinary scheduler. Displayed certificates are already primitive proofs in the original theory, with no imported-lemma expansion.',
        'Learning clustered continuations is now implemented. Hierarchical family composition, richer semantic lemma acquisition, substantial arithmetic and geometry, and the geometric tiling objectives remain open. The materials reconstruction lane remains retired.'
    ]
    public['provenance']=dict(raw_results=pin(source),observer=pin(ROOT/'observation-v1/observer-result.json'),
        driver=pin(ROOT/'cluster_policy_experiment_v1.py'),cohort=pin(ROOT/'cohort-v1.json'),
        independent_cluster_verifier=pin(ROOT/'reference/cluster_verifier_v2.py'),
        policy=pin(ROOT/'actual-v1/frozen-policy-v1.json'),
        mechanism=dict(later_nonforced_adoptions=25,in_verified_proof_occurrences=12,distinct_verified_target_member_pairs=11))
    out=ROOT/'report'/(sys.argv[1] if len(sys.argv)>1 else 'rendered-v1');out.mkdir(exist_ok=False)
    (out/'cluster-policy-results-v1.json').write_bytes((json.dumps(public,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode())
    (out/'cluster-policy-proof-search-v1.html').write_bytes((ROOT/'report/cluster-policy-template-v1.html').read_bytes())
    print(json.dumps([pin(p) for p in sorted(out.iterdir())],sort_keys=True))


if __name__=='__main__':build()
