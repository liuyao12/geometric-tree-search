"""Bound one fresh experiment process and retain its original streams and files."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

ROOT=Path(__file__).resolve().parent
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')


def pin(p):
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def limits():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(67108864,67108864))


sources=[ROOT/'cluster_policy_experiment_v1.py',ROOT/'cohort-v1.json',ROOT/'reference/cluster_verifier_v2.py',PYTHON]
sources += sorted((ROOT/'upstream').glob('*.py'))
before=[pin(p) for p in sources]
observation=ROOT/'observation-v1';observation.mkdir(exist_ok=False)
command=[str(PYTHON),'-I','-S','-B',str(ROOT/'cluster_policy_experiment_v1.py'),'--run',str(ROOT/'actual-v1')]
started=time.monotonic();expired=False;position=0
with (observation/'stdout.log').open('xb') as out,(observation/'stderr.log').open('xb') as err:
    proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
                          start_new_session=True,preexec_fn=limits)
    while proc.poll() is None:
        with (observation/'stdout.log').open('rb') as reader:
            reader.seek(position);chunk=reader.read();position+=len(chunk)
        if chunk:print(chunk.decode('utf-8',errors='replace'),end='',flush=True)
        if time.monotonic()-started>240:
            expired=True;os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=5)
            break
        time.sleep(.2)
    code=proc.wait()
for name in ('stdout.log','stderr.log'):
    b=(observation/name).read_bytes()
    if name=='stdout.log':b=b[position:]
    if b:print(b.decode('utf-8',errors='replace'),end='',flush=True)
after=[pin(p) for p in sources]
files=[pin(p) for p in sorted((ROOT/'actual-v1').iterdir()) if p.is_file()]
result=dict(schema='CP-native-process-observation-v1',status='COMPLETE' if code==0 and not expired else 'INCOMPLETE',
    returncode=code,timeout=expired,wait_reaped=True,command=command,seconds=time.monotonic()-started,
    child_peak_RSS_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    runtime_source_guards_unchanged=before==after,before=before,after=after,files=files,
    streams=[pin(observation/'stdout.log'),pin(observation/'stderr.log')],
    limits=dict(external_wall_seconds=240,cleanup_seconds=5,per_file_bytes=67108864,core_dumps=False),
    scope='One child process, captured original streams and all returned files. RSS is observed, not a hard memory quota. No scientific retry.')
with (observation/'observer-result.json').open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ('status','returncode','seconds','child_peak_RSS_bytes','runtime_source_guards_unchanged')}),flush=True)
raise SystemExit(0 if result['status']=='COMPLETE' and before==after else 1)
