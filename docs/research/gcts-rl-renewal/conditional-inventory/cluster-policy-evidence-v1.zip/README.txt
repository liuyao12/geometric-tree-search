Recorded synthetic proof-cluster policy experiment. MANIFEST.json maps every member to original bytes, SHA256, mode and path.
50 rule-shape families were mined from four automatically found training proofs; 32 reward-updated episodes precede 16 held-out systems.
All 96 method positions remain: verified positives 8 lexical / 5 uniform / 7 RL clusters / 6 leader-only / 8 cluster DFS / 8 DP.
Eight finite negative closures per method are bounded-basis/depth results, not unrestricted nonprovability.
The trained method does not beat lexical GCTS or the conventional controls. The leader-only difference is near the wall cutoff.
Clusters guide base continuations after ordinary global propagation and earliest-generation selection; no atomic macro or sampled candidate domain is used.
Full proof certificates, chosen proposals and emitted event/query/rollback streams are included. Unchosen pools and unreturned callback internals are not invented.
Independent kernel/point/verifier receipts and saved-data reviews are retained. No claim to substantial new arithmetic/Hilbert theorems, semantic lemma learning, a fixed universal Wang palette, learned failure markings or plane tilings.
No private chats/recovery sessions, runtime binary, retired materials data or unrelated work is included. The earlier upstream ZIP is externally pinned, not nested.
The closed ZIP cannot contain its own later package/deployment/live receipts. These are a separate durable supplement.
