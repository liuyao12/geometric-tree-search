"""Passive complete saved-JSON joins and literal word display decoding only."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
D5=B.parent/'gcts-proof-search-pilot-20261020'
OUT=B/'publication'
OUT.mkdir(exist_ok=True)
def pin(path):
    p=Path(path);assert '.partial' not in p.name
    raw=p.read_bytes();return dict(path=str(p.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())
def save(path,value):path.write_text(json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,indent=2)+'\n')
corpus=read(D5/'corpus-L/pilot-inputs-v2.json')
cases=[];proofs=[];donors=[];tiles=[];totals=[];pointrows=[];ordering=[];point_clusters=[];storage_controls=[]
for spec in corpus['tests']:
    folder=B/'actual'/spec['id'];path=folder/('result.json' if (folder/'result.json').exists() else 'failure.json');d=read(path)
    s=d['scientific_result'];c=s['tests'][0]
    header=read(folder/'worker-header.json');terminal=read(folder/'terminal.json')
    observer=read(Path(str(folder)+'.observer/observer.json'))
    assert header['result']==pin(path)
    if terminal['result'] is not None:assert terminal['result']==pin(path)
    admitted=bool(d['status']==header['status']=='COMPLETE' and terminal['process_exit_code']==observer['parent_exit_code']==0 and observer['resource_candidate_accepted'])
    assert s['job_record_complete']
    assert c['spec']==spec and [a['id'] for a in c['arms']]==corpus['protocol']['arm_order'][spec['id']]
    assert s['diagnostics']['status']=='complete' and s['word_reference_diagnostics']['complete']
    assert len(s['word_reference_diagnostics']['controls'])==48
    assert all(x['status']=='PASSED' for x in s['word_reference_diagnostics']['controls'])
    assert c['reference_check']['complete'] and c['word_model_check']['complete']
    gc=s['graph_storage_diagnostics'];assert gc['complete'] and gc['status']=='PASSED' and gc['control_count']==len(gc['controls'])==22 and gc['fixture_count']==10
    assert all(row['complete'] and row['status']=='PASSED' for row in gc['controls'])
    storage_controls.append(dict(case_id=spec['id'],title=spec['title'],whole_job_admitted=admitted,receipt=gc,source=pin(path)))
    packet=c['model'];assert packet['schema']=='pilot-aligned-whole-word-point-model-v1'
    bykey={tuple(p['key']):p for p in packet['placements']}
    def tile(chosen,label,certificate=None):
        if not admitted:label='NONADMITTED — '+label
        words=[]
        for point,value in chosen['marks']:
            if point[1]==100:
                raw=bytes.fromhex(packet['word_dictionary'][value])
                words.append(dict(point=point,word_id=value,payload_hex=raw.hex(),literal_value=json.loads(raw),terminator=packet['word_terminator']))
        ref=chosen['command_reference']; command=packet['domains'][ref[0]][ref[1]]
        aux=[x['auxiliary'] for x in c['markings']['certificates'] if x['auxiliary']['placement']==chosen['key']]
        tiles.append(dict(label=label,scope=('WHOLE CASE NOT ADMITTED — diagnostic saved artifact. ' if not admitted else 'Resource-admitted case. ')+'Exact word-port candidate from '+spec['id']+'. Fixed positional translation roles; no rotation or reflection. High-level reduced point carrier; not a physical nearest-neighbor Wang tile.',whole_job_admitted=admitted,case_id=spec['id'],key=chosen['key'],occupancy=chosen['occupancy'],marks=chosen['marks'],word_occurrences=words,auxiliary=aux,command=command,metadata=chosen['metadata'],certificate=certificate,description='Colored bands distinguish full command words, full formula words and scalar mode/exclusion values. Every displayed ID and payload is decoded literally from the complete saved case dictionary.'))
        return len(tiles)-1
    arms=[];accepted=[];checker_candidates=[];searched=0;skipped=0;casepoints=[]
    for a in c['arms']:
        if a['execution_status']=='SKIPPED_UNKNOWN_PREREQUISITE':
            skipped+=1;assert a['search'] is None and a['native_proof_accepted'] is None
            arms.append(dict(id=a['id'],outcome='SKIPPED — cluster admission unknown',attempts=None,forced_branches='—',aux_removals=None,cluster_proposals=None,times='—',status=a['execution_status']));continue
        assert a['execution_status']=='SEARCH_RETURNED';searched+=1
        search=a['search'];m=search['metrics'];attempts=m.get('attempts',0)
        if a['method']=='point':
            placements=sum(x['event']=='place' for x in search['trace'])
            assert attempts==placements and search['root_restored']
            assert all(x['complete'] for x in search['domain_audits'])
            point=dict(case_id=spec['id'],arm=a['id'],attempts=attempts,nodes=m.get('nodes',0),placed_events=placements,completed_domain_audits=len(search['domain_audits']),initial_audit=search['domain_audits'][0] if search['domain_audits'] else None,forced_decisions=m.get('forced',0),branch_decisions=m.get('branch',0),backtracks=m.get('backtracks',0),initial_auxiliary_removal_witnesses=m['initial_auxiliary_removed_incidences'],auxiliary_removal_incidences_total=m['auxiliary_removed_incidences_total'],search_seconds=a['timings']['search_seconds'],root_restored=True,status=search['status'])
            point['whole_job_admitted']=admitted
            pointrows.append(point);casepoints.append(point)
        ok=a['native_proof_accepted'] is True
        outcome='PROOF ACCEPTED — Host, point region, Native' if ok and admitted else 'CHECKERS ACCEPTED — whole job NOT ADMITTED' if ok else search['status']
        if not admitted and not ok:outcome='NOT ADMITTED — observed '+outcome
        arms.append(dict(id=a['id'],outcome=outcome,attempts=attempts,forced_branches=str(m.get('forced',0))+' / '+str(m.get('branch',0)) if a['method']=='point' else 'Not applicable',aux_removals=m.get('auxiliary_removed_incidences_total') if a['method']=='point' else None,cluster_proposals=m.get('cluster_proposals',0),times=f'{a["timings"]["search_seconds"]:.6f} / {a["timings"]["full_arm_seconds"]:.6f} s',status=a['execution_status']))
        if a['cluster_enabled']:
            obs=a['ordering_observations'];assert obs['enabled'] and c['clusters']['ordering_hints_enabled']
            decisions=[e for e in search['trace'] if e['event']=='decision']
            changed=sum(e['original_candidates']!=e['ordered_candidates'] for e in decisions) if a['method']=='symbolic' else None
            ordering.append(dict(whole_job_admitted=admitted,case_id=spec['id'],title=spec['title'],arm=a['id'],instances=obs['available_instances'],successful_proposals=obs['successful_proposals'],point_activated_packets=obs['point_activated_proposal_packets'],symbolic_order_changes=changed,attempts=attempts,status=search['status'],scope=obs['scope']))
        if search['proof'] is not None:
            assert ok and a['host_check']['accepted'] and a['region']['complete']
            assert a['proof_verification_status']=='HOST_REGION_NATIVE_ACCEPTED'
            q=s['native_records'][a['native_query']]
            assert q['result']['status']=='accepted' and q['request']['proof']==search['proof'] and q['request']['theory']==spec['theory'] and q['request']['target']==spec['target']
            rows=[]
            for row,command in enumerate(search['proof']):
                selected=[bykey[tuple(k)] for k in search['placements'] if k[0]==row]
                assert len(selected)==2 and {p['metadata']['kind'] for p in selected}=={'command','guard'}
                selected.sort(key=lambda p:p['key'][1])
                indices=[tile(p,spec['title']+' — '+a['id']+' recorded proof row '+str(row+1)+' '+p['metadata']['kind']) for p in selected]
                assert all(tiles[i]['command']==command for i in indices)
                rows.append(dict(row=row+1,command=command,tile_indices=indices))
            engine='cluster-guided symbolic search' if a['id']=='SC' else 'conventional symbolic control' if a['method']=='symbolic' else 'point Graph search'
            status='Automatically discovered by '+a['id']+' '+engine+'. Exact Host, full finite point-region and Native checks returned accepted. No RL policy was used.'
            if not admitted:status='NOT ADMITTED: the complete positive case failed its whole-memory gate. This saved '+a['id']+' observation has accepted Host/point-region/Native checker records but is diagnostic only. The earlier D12 experiment independently admitted the same S0/SC certificates; that historical qualification does not admit this D13 job.'
            proofs.append(dict(title=('Recipient — ' if admitted else 'NONADMITTED observation — ')+spec['title']+' ('+a['id']+')',spec=spec,proof=search['proof'],status=status,source=pin(path),arm=a['id'],query_id=q['id'],whole_job_admitted=admitted,tile_rows=rows,search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds']))
            candidate=dict(arm=a['id'],rows=len(search['proof']),query=q['id'],search_seconds=a['timings']['search_seconds'],full_arm_seconds=a['timings']['full_arm_seconds'])
            checker_candidates.append(candidate)
            if admitted:accepted.append(candidate)
    if admitted:
        reviewed=read(B/'review-C/typed-graph-sharing-actual-scientific-review-v1.json')
        for a in c['arms']:
            if a['method']!='point' or not a['cluster_enabled']:continue
            for event_index,event in enumerate(a['search']['trace']):
                if event['event']!='cluster_proposals':continue
                for packet_hint in event['proposals']:
                    joins=[j for j in reviewed['point_packet_member_literal_joins'] if j['case_id']==spec['id'] and j['arm']==a['id'] and j['packet_trace_index']==event_index and j['instance']==packet_hint['instance']]
                    assert len(joins)==1
                    join=joins[0]
                    if join.get('all_members_selected_at') is None:continue
                    assert join['resource_admitted'] and join['members']==packet_hint['members']
                    assert join['prefix_rows_before']==packet_hint['prefix_rows'] and join['prefix_rows_after']==len(packet_hint['checked_primitive_proof'])
                    assert packet_hint['host_check']['accepted'] and packet_hint['checked_primitive_proof'][packet_hint['prefix_rows']:]==packet_hint['commands']
                    rows=[]
                    for row_index,command in enumerate(packet_hint['checked_primitive_proof']):
                        members=[bykey[tuple(k)] for k in packet_hint['members'] if k[0]==row_index]
                        indices=[tile(p,'Qualified local '+a['id']+' event '+str(event_index)+' row '+str(row_index+1)+' '+p['metadata']['kind']) for p in sorted(members,key=lambda p:p['key'][1])]
                        assert all(tiles[i]['command']==command for i in indices)
                        rows.append(dict(row=row_index+1,command=command,tile_indices=indices,new_extension=row_index>=packet_hint['prefix_rows']))
                    point_clusters.append(dict(title=a['id']+' — '+packet_hint['instance']+' — prefix '+str(packet_hint['prefix_rows'])+' to '+str(len(rows)),arm=a['id'],case_id=spec['id'],spec=dict(theory=spec['theory'],target=packet_hint['result_formula']),recipient_target=spec['target'],proof=packet_hint['checked_primitive_proof'],tile_rows=rows,packet=packet_hint,literal_member_join=join,packet_trace_index=event_index,completion_trace_index=join['all_members_selected_at'],whole_job_admitted=True,source=pin(path),status='Resource-admitted local branch extension in '+spec['title']+'. The saved Host check accepted this prefix; both nominated command and guard members later coexist on this recorded branch. This local record is separate from a completed recipient proof, a Native-admitted macro or a measured search advantage.'))
    take_donors=admitted and not donors
    for t in s['training']:
        assert t['acquired']
        assert s['native_records'][t['native_query']]['result']['status']==s['native_records'][t['essential_native_query']]['result']['status']=='accepted'
        if take_donors:donors.append(dict(title='Admitted-case donor — '+t['spec']['title'],spec=t['spec'],proof=t['search']['proof'],status='Automatically searched elementary donor from the resource-admitted case; Host/region and whole/essential Native accepted. Ordering-only hints require actual-context Host checks; final proofs retain full primitive checking.',source=pin(path),tile_rows=[]))
    cert=c['markings']['certificates'][0]
    tile(bykey[tuple(cert['auxiliary']['placement'])],spec['title']+' — certified excluded trial',cert)
    tile(next(p for p in packet['placements'] if p['metadata']['kind']=='guard' and p['metadata']['requirements']),spec['title']+' — earlier-row receptor guard')
    ground=s['native_records'][c['clusters']['admission_query']]
    total=dict(case_id=spec['id'],observer_seconds=observer['elapsed_seconds'],whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],worker_peak_bytes=d['python_peak_bytes'],native_peak_bytes=d['native_peak_bytes'],known_exit_seconds=terminal['known_exit_seconds'],full_shared_setup_seconds=c['full_shared_setup_seconds'],compile_and_model_seconds=c['compile_and_model_seconds'],word_model_seconds=c['word_model_seconds'],training_and_acquisition_seconds=s['training_and_acquisition_seconds'],marking_seconds=c['markings']['compile_and_verification_seconds'],ground_query_seconds=ground['seconds'],ground_instances=len(c['clusters']['instances']),ground_native_status=ground['result']['status'],native_queries=len(s['native_records']),searches_returned=searched,skipped_cluster_arms=skipped,accepted_recipient_proofs=accepted,checker_accepted_candidates=checker_candidates,point_attempts=sum(x['attempts'] for x in casepoints),point_domain_audits=sum(x['completed_domain_audits'] for x in casepoints),certified_exclusions=len(c['markings']['certificates']),dictionary_words=len(packet['word_dictionary']),model_placements=len(packet['placements']),resource_candidate_accepted=admitted,scientific_complete=bool(admitted and s['scientific_complete']),result=pin(path),terminal=pin(folder/'terminal.json'),observer=pin(Path(str(folder)+'.observer/observer.json')))
    total['display_peak_bytes']=total['whole_peak_bytes'] if total['whole_peak_bytes'] is not None else total['worker_peak_bytes']+total['native_peak_bytes']
    total['memory_label']=('Whole peak: ' if total['whole_peak_bytes'] is not None else 'Worker+Native lower bound: ')+f'{total["display_peak_bytes"]/1048576:.1f} MiB'
    total['job_admission_label']='Whole job resource-admitted' if admitted else 'WHOLE JOB NOT ADMITTED — memory gate'
    total['point_status']=str(total['point_attempts'])+' point placements; '+str(total['point_domain_audits'])+' complete audits'
    p00=next(x for x in casepoints if x['arm']=='P00');p10=next(x for x in casepoints if x['arm']=='P10')
    assert p00['initial_audit']['frontier_points']==p10['initial_audit']['frontier_points']
    total['initial_audit_incidence_difference']=p00['initial_audit']['incidences']-p10['initial_audit']['incidences']
    assert total['initial_audit_incidence_difference']==12
    totals.append(total)
    costs=[f'Cold donor discovery/check/mining: {s["training_and_acquisition_seconds"]:.6f} s. Full shared setup: {c["full_shared_setup_seconds"]:.6f} s. Compilation/model/reduction: {c["compile_and_model_seconds"]:.6f} s; artifact encoding/check: {c["word_model_seconds"]:.6f} s; markings/check: {total["marking_seconds"]:.6f} s. These clocks contain nested work and must not be added as disjoint.',f'Ground registry: {len(c["clusters"]["instances"])} instances; Native status {ground["result"]["status"]}; {ground["seconds"]:.6f} s. Its full cost remains charged. The registry remains UNKNOWN; ordering instances are eligible under the new declared policy, without registering an inference block.',f'Whole observer: {observer["elapsed_seconds"]:.6f} s. {total["memory_label"]}. Admission: {total["job_admission_label"]}. Includes outputs and custody, not merely theorem-search latency.','The original cooperative two-second local deadline is retained, including Graph construction/snapshots/audits. Operations and cleanup can overshoot checkpoints. No timer was moved to create this result.','For per-method allocation, S0 needs no unused donor library or auxiliary marking acquisition; P10 includes its marking costs. Conventional symbolic proof search does not intrinsically need the shared point-model reporting setup.','The raw grounding-work counter can reach20,003 at the20,000 cooperative threshold through recursive unwind checks; no unification follows the threshold.']
    notes=[f'{x["arm"]}: {x["attempts"]} actual placement events, {x["completed_domain_audits"]} completed exhaustive Graph audits, {x["forced_decisions"]} forced decisions, {x["branch_decisions"]} branch decisions; exact initial state/Graph restoration returned.' for x in casepoints]
    notes.append('Initial auxiliary witnesses are collected by a separate full alignment scan. Audit counts refer to actual completed Graph-domain/incidence/scheduler checks; witness counts alone are not an audited before/after domain difference. All certified failures remain first-row conditions, not learned multiscale abstractions.')
    notes.insert(0,total['job_admission_label']+' — search observations for '+spec['title']+'.')
    cases.append(dict(title=spec['title'],spec=spec,outcome=total['job_admission_label']+'. '+str(len(accepted))+' admitted recipient proof(s); '+str(searched)+' recorded searches and '+str(skipped)+' skipped cluster arms.',failure=('The complete attempt failed its memory gate. Its returned search/certificate observations are not admitted comparison results. ' if not admitted else '')+'All six bounded arms returned. A returned search is distinct from a solved theorem; an unsuccessful bounded search does not establish theorem falsity.',metrics=[f'Whole job: {total["observer_seconds"]:.3f} s',total['memory_label'],('Admitted: ' if admitted else 'Nonadmitted observation: ')+total['point_status'],f'Admitted proofs: {len(accepted)}'],arms=arms,control=d['independent_external_controls'],cost_notes=costs,marking_notes=notes))
proofs+=donors
summary=dict(schema='Root-passive-graph-sharing-search-assessment-v1',cases=totals,point_searches=pointrows,new_actual_case_jobs=len(totals),remaining_once_grants=0,searches_returned=sum(x['searches_returned'] for x in totals),cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals),accepted_recipient_proofs=sum(len(x['accepted_recipient_proofs']) for x in totals),point_placement_attempts=sum(x['attempts'] for x in pointrows),complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows),word_reference_controls_per_case=48,scientific_complete=all(x['scientific_complete'] for x in totals),whole_goal_complete=False,trained_RL=False,partial_files_parsed=False,scientific_calls=0,scope='Passive complete saved-file joins and literal word-dictionary display decoding; no scientific Source execution/replay. Aggregate observation counts include any explicitly NONADMITTED failed attempts; separate admitted counts follow.')
summary.update(resource_admitted_case_jobs=sum(x['resource_candidate_accepted'] for x in totals),resource_rejected_case_jobs=sum(not x['resource_candidate_accepted'] for x in totals),admitted_searches_returned=sum(x['searches_returned'] for x in totals if x['resource_candidate_accepted']),admitted_cluster_arms_skipped=sum(x['skipped_cluster_arms'] for x in totals if x['resource_candidate_accepted']),admitted_point_placement_attempts=sum(x['attempts'] for x in pointrows if x['whole_job_admitted']),admitted_complete_point_domain_audits=sum(x['completed_domain_audits'] for x in pointrows if x['whole_job_admitted']),checker_accepted_candidates_in_nonadmitted_jobs=sum(len(x['checker_accepted_candidates']) for x in totals if not x['resource_candidate_accepted']))
save(B/'root/passive-actual-assessment-v1.json',summary)
prior_path=B.parent/'gcts-point-novelty-proof-pilot-20261020/root/passive-actual-assessment-v1.json'
prior=read(prior_path);prior_by_id={row['case_id']:row for row in prior['cases']}
comparison=[]
for row in totals:
    older=prior_by_id[row['case_id']]
    comparison.append(dict(case_id=row['case_id'],title=next(c['title'] for c in cases if c['spec']['id']==row['case_id']),previous_admitted=older['resource_candidate_accepted'],current_admitted=row['resource_candidate_accepted'],previous_whole_peak_bytes=older['whole_peak_bytes'],current_whole_peak_bytes=row['whole_peak_bytes'],previous_point_placements=older['point_attempts'],current_point_placements=row['point_attempts'],previous_source=older['result'],current_source=row['result']))
assert summary['accepted_recipient_proofs']==2
assert summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0
assert [a['arm'] for a in totals[0]['accepted_recipient_proofs']]==['S0','SC']
assert [a['rows'] for a in totals[0]['accepted_recipient_proofs']]==[14,14]
assert proofs[0]['proof']==proofs[1]['proof'] and proofs[0]['whole_job_admitted'] and proofs[1]['whole_job_admitted']
assert len(pointrows)==12 and all(p['status']=='unknown_search_budget' for p in pointrows)
assert summary['searches_returned']==summary['admitted_searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['point_placement_attempts']==summary['admitted_point_placement_attempts']==558
assert summary['complete_point_domain_audits']==summary['admitted_complete_point_domain_audits']==24
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==16
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==2
assert len(point_clusters)==8 and len(tiles)==78
summary.update(ordering_only_policy=True,exact_prefix_abstention=True,common_point_formula_novelty_order=True,registered_ground_blocks=False,graph_storage_sharing=True,successful_ordering_proposals_observed=16,point_packets_observed=8,point_packets_qualified=8,qualified_local_member_completions=8,distinct_local_result_formulas=len({json.dumps(p['spec']['target'],sort_keys=True) for p in point_clusters}),literal_symbolic_order_changes=2,accepted_recipient_certificates=2,distinct_recipient_statements=1,new_theorem=False,admitted_word_controls=144,observed_word_controls=144,new_storage_controls_per_case=22,observed_new_storage_controls=66,admitted_new_storage_controls=66)
assert summary['distinct_local_result_formulas']==2 and summary['scientific_complete']
save(B/'root/passive-actual-assessment-v1.json',summary)
symbolic_comparison=[]
for spec in corpus['tests']:
    previous_path=B.parent/'gcts-point-novelty-proof-pilot-20261020/actual'/spec['id']/'result.json'
    previous=read(previous_path)['scientific_result']['tests'][0]
    current=read(B/'actual'/spec['id']/'result.json')['scientific_result']['tests'][0]
    before=next(a for a in previous['arms'] if a['id']=='SC')
    after=next(a for a in current['arms'] if a['id']=='SC')
    baseline=next(a for a in current['arms'] if a['id']=='S0')
    symbolic_comparison.append(dict(previous_admitted=prior_by_id[spec['id']]['resource_candidate_accepted'],current_admitted=next(t['resource_candidate_accepted'] for t in totals if t['case_id']==spec['id']),title=spec['title'],case_id=spec['id'],previous_SC_attempts=before['search']['metrics']['attempts'],previous_SC_accepted=before['native_proof_accepted'],current_SC_attempts=after['search']['metrics']['attempts'],current_SC_accepted=after['native_proof_accepted'],current_S0_attempts=baseline['search']['metrics']['attempts'],current_S0_accepted=baseline['native_proof_accepted'],same_accepted_primitive_proof=after['search']['proof'] is not None and after['search']['proof']==baseline['search']['proof'],previous_source=pin(previous_path)))
headline="All three cold jobs now qualify; a proof-search advantage remains unproved."
conclusion="Shared graph storage passes the unchanged resource gates in all three jobs. All eighteen searches return, with 558 point placements, twenty-four full-domain audits and sixty-six new storage controls. S0 and SC produce the same known fourteen-line proof. Every point search remains budget unknown. This restores an admitted comparison without demonstrating useful cluster or RL acceleration."
assessment=[
    'Graph copies now own separate top dictionaries while sharing nested sets read-only. Each update detaches an old domain before its first write and replaces edge sets with fresh values. The Source guarantee is for the fixed, sequential, nonreentrant pilot callers; arbitrary foreign nested-set mutation or a mid-update snapshot is outside that guarantee.',
    'All sixty-six new finite controls returned PASSED: twenty-two per job, with complete literal fixtures, snapshots and event references. They cover parent/sibling/grandchild isolation, fractional occupancy, completed and newly exposed frontier points, distant markings, zero values, scheduler priority, alternative empty boundaries and exact expected error identities. Source review and finite controls have distinct scopes; they are not a generic COW theorem.',
    'All three whole jobs pass the original one-GiB gate, at 889,241,600, 966,164,480 and 939,376,640 bytes. The previous first two jobs failed that gate. This is a disclosed storage intervention plus additional diagnostics on one fixed development cohort. There is no measured allocation-phase attribution or statistical speedup evidence.',
    'The two accepted recipient records are S0 and SC versions of the same fourteen-row primitive certificate for one already-known statement. The positive symbolic candidate ordering and path remain identical. No point proof is found: all twelve point searches are budget UNKNOWN, despite more placements in their timed prefixes.',
    'Eight qualified point packets complete their nominated command and guard members on recorded branches. They are two distinct local MP conclusions repeated across the first and negative cases and P01/P11. These are actual local extensions, not eight theorems, a registered macro or evidence of useful cluster selection.',
    'The complete model/reduction checks and all 144 word controls belong to admitted jobs. Certified failure markings still give twelve fewer initial incidences per marked comparison, from shallow first-row failures. No learned multiscale abstraction or during-placement elimination gain is established.',
    'All ground registry queries remain Native UNKNOWN, unadmitted, with usable empty. Separate ordering instances still need actual-context Host checks and exact existing primitive placements; final target proofs require the unchanged Host/full-region/Native gates. No trained RL policy is present.',
    'With the full bounded comparison admitted, the next priority returns to learned cluster proposals and receptor selection: automatic training-only acquisition, a frozen policy, held-out theorem families and explicit conventional and fixed-heuristic controls. The fixed novelty preference must not be relabeled RL or tuned to the visible target route.',
    'The full program remains practical fixed/movable boundary tiling, Turtle and Penrose plane growth, hierarchical receptor/lemma families, automated arithmetic and symbolic Hilbert geometry, and a fixed universal Wang construction with a physical checking bridge. This pilot does not complete those objectives.'
]
next_path=B/'implementation-B/graph-sharing-outcome-next-assessment-v1.json'
report=dict(schema='graph-sharing-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='Two resource-admitted searches, S0 and SC, contain the same fourteen-line primitive certificate for one known recipient statement. Their exact tiles, formulas and English readings are inspectable below. The three elementary donor proofs come from the first admitted cold job. Local point-search extensions are shown separately above; none completes a recipient proof.',cases=cases,proofs=proofs,point_clusters=point_clusters,storage_controls=storage_controls,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),symbolic_comparison=symbolic_comparison,ordering=ordering,assessment=assessment,next_assessment=read(next_path),next_assessment_source=pin(next_path),ordering_diagnostic_text='All eight point proposal packets now belong to resource-admitted jobs, and their nominated member pairs complete locally. No point target is solved. The shared graph representation makes this bounded cohort feasible under the same gates; useful cluster guidance and RL learning remain the next scientific questions.',review_summary='Independent initial and whole-plan reviews preceded three serial cold jobs with other agents idle. Independent complete-record reviews classify every case as resource-admitted. All original proof gates, search limits and word/model controls remain; twenty-two new graph ownership controls per case also return. Registry UNKNOWN, local Host checks, full target proof checks and resource admission remain separate. No scientific replay occurred outside actuals.')

def prose_spacing(value):
    if type(value) is str:
        for old,new in [('and14','and 14'),('made4','made 4'),('and10','and 10'),('totalling89','totalling 89'),('and12','and 12'),('Only14','Only 14'),('and4','and 4'),('to1,','to 1,'),('the1GiB','the 1 GiB'),('peak1,','peak 1,'),('at860,','at 860,'),('the14-line','the 14-line'),('has12','has 12'),('show12','show 12'),('The48','The 48'),('reach20,','reach 20,'),('the20,','the 20,'),('returned65','returned 65'),('and8','and 8'),('made65','made 65'),('job,99','job, 99'),('is1,','is 1,'),('above1GiB','above 1 GiB'),('checker-accepted14','checker-accepted 14'),('at882,','at 882,'),('at880,','at 880,'),('from860,','from 860,'),('to880,','to 880,'),('remove12','remove 12'),('The48','The 48')]:value=value.replace(old,new)
        return value
    if type(value) is list:return [prose_spacing(x) for x in value]
    if type(value) is dict:return {k:prose_spacing(v) for k,v in value.items()}
    return value
save(OUT/'graph-sharing-search-data.json',prose_spacing(report))
save(OUT/'graph-sharing-search-engineering.json',dict(schema='graph-sharing-search-method-v1',protocol=read(B/'root/protocol-v1.json'),assessment=summary,verification_scope='Independent full model reduction/occurrence checks and actual returned tiny controls; literal evidence-owner joins; unchanged primitive Host/full-region/final Native gates. C/L subsequent reviews are passive joins and Source arguments.',partial_files_parsed=False,scientific_calls=0))
print(json.dumps(dict(assessment=pin(B/'root/passive-actual-assessment-v1.json'),proofs=len(proofs),tiles=len(tiles),point_attempts=summary['point_placement_attempts'],audits=summary['complete_point_domain_audits'])))
