"""Author passive packaging and publication pin scripts; no scientific execution."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
previous=B.parent/'gcts-point-novelty-proof-pilot-20261020'
s=(previous/'root/package_point_report_v3.py').read_text()
s=s.replace("D12=B.parent/", "D13=B.parent/'gcts-point-novelty-proof-pilot-20261020'\nD12=B.parent/",1)
s=s.replace("PREFIX='point-novelty-search'","PREFIX='graph-sharing-search'")
s=s.replace("summary['resource_admitted_case_jobs']==1 and summary['resource_rejected_case_jobs']==2", "summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0")
s=s.replace("summary['admitted_point_placement_attempts']==86 and summary['admitted_complete_point_domain_audits']==8", "summary['admitted_point_placement_attempts']==558 and summary['admitted_complete_point_domain_audits']==24")
s=s.replace('typed-point-novelty-actual-scientific-review-v1.json','typed-graph-sharing-actual-scientific-review-v1.json')
s=s.replace('typed-point-novelty-resource-custody-review-v1.json','typed-graph-sharing-resource-custody-review-v1.json')
s=s.replace('522059cfb30e309138772748d9853f235576909077e1c738782398c80280c982','e4e2298530c0b154ae4ce85ef65829d63c3fa438219e5924f849d1db3c2969ec')
start=s.index("insert=('")
end=s.index("after=before[:offset]",start)
s=s[:start]+'''insert=('<section id="graph-sharing-update" class="panel"><h2>The bounded proof-search comparison now qualifies</h2>'
        '<p><a href="graph-sharing-search.html#reader">Read the qualified proofs, formulas, English and colored tiles</a>. '
        'Read-only graph sharing brings all three cold jobs within the original resource caps. S0 and SC repeat the same known fourteen-line proof; all point searches remain unknown. '
        'Eight qualified local packets repeat two steps. No new theorem, useful cluster acceleration or trained RL advantage is established. '
        '<a href="graph-sharing-search.html#storage">Inspect the storage change and independent controls</a>.</p></section>\\n').encode()
offset=before.index(b'<section id="point-novelty-update"')
'''+s[end:]
s=s.replace("schema='point-novelty-reader-exact-insertion-v1'", "schema='graph-sharing-reader-exact-insertion-v1'")
s=s.replace("paths.update([D12/", "paths.update([D13/'implementation-B/proof_search_pilot_v11.py',D13/'implementation-B/API-v1.json',\n              D13/'implementation-B/handoff-v1.json',D13/'root/protocol-v1.json',\n              D13/'root/passive-actual-assessment-v1.json',D13/'root/initial-passive-actual-join-v1.json',\n              D13/'publication/point-novelty-search-data.json',\n              P/'docs/research/gcts-rl-renewal/conditional-inventory/point-novelty-search-manifest.json',\n              D12/",1)
s=s.replace("elif path.is_relative_to(D12):", "elif path.is_relative_to(D13):name='dependencies/D13/'+path.relative_to(D13).as_posix()\n    elif path==P/'docs/research/gcts-rl-renewal/conditional-inventory/point-novelty-search-manifest.json':name='dependencies/D13/publication/point-novelty-search-manifest.json'\n    elif path.is_relative_to(D12):",1)
s=s.replace("schema='point-novelty-search-evidence-archive-v1'", "schema='graph-sharing-search-evidence-archive-v1'")
s=s.replace('resource_admitted_case_attempts=1,resource_rejected_case_attempts=2','resource_admitted_case_attempts=3,resource_rejected_case_attempts=0')
s=s.replace('admitted_searches=6,admitted_cluster_skips=0,admitted_point_placements=86,admitted_point_audits=8','admitted_searches=18,admitted_cluster_skips=0,admitted_point_placements=558,admitted_point_audits=24,admitted_word_controls=144,admitted_graph_storage_controls=66')
s=s.replace("qualified_recipient_certificates=0,distinct_recipient_statements=0,diagnostic_checker_accepted_certificates=2,qualified_local_point_packets=4,recipient_engine='No admitted target certificate; S0/SC checker records belong to a rejected whole job'", "qualified_recipient_certificates=2,distinct_recipient_statements=1,diagnostic_checker_accepted_certificates=0,qualified_local_point_packets=8,distinct_local_conclusions=2,recipient_engine='S0 and SC produce the same known fourteen-row primitive certificate in the first admitted job'")
s=s.replace('scientific_comparison_complete=False','scientific_comparison_complete=True')
start=s.index("scope='D13 has")
end=s.index("\nmb=",start)
s=s[:start]+"scope='D14 admits all three complete jobs:18 searches558point placements24audits144word controls66new graph controls. S0/SC repeat one known fourteen-line statement certificate; all12point searches UNKNOWN. Eight qualified local point packets contain two conclusions repeated across cases and arms, not eight theorems. Registry UNKNOWN/unadmitted/usable empty. No new theorem, trained RL or useful measured advantage. Full D14 Sources and complete actuals are included; historical D13 and older raw actuals remain in their prior published archives pinned by included manifests. Old qualifications are immutable. Source sharing has closed sequential nonreentrant caller scope; finite tests do not quantify allocation bytes or establish a general COW theorem. B next assessment is passive posthoc analysis. Publication review and browser QA occur outside this archive snapshot.')"+s[end:]
s=s.replace("schema='point-novelty-archive-complete-byte-scan-v1'","schema='graph-sharing-archive-complete-byte-scan-v1'")
s=s.replace("schema='point-novelty-search-publication-manifest-v1'","schema='graph-sharing-search-publication-manifest-v1'")
start=s.index("conclusion='Two whole-memory failures")
end=s.index("\nsave(D/",start)
s=s[:start]+"conclusion='All three whole jobs qualify under original caps.18searches558point placements24audits144word controls66new graph controls. Two admitted S0/SC certificates repeat the same known fourteen-line proof. Eight local packets complete two repeated conclusions; all point searches UNKNOWN. No new theorem, useful cluster acceleration or trained RL advantage.')"+s[end:]
(B/'root/package_graph_report_v1.py').write_text(s)

offer=(previous/'root/freeze_publication_offer_v3.py').read_text()
offer=offer.replace('point-novelty-search','graph-sharing-search').replace('D13-frozen','D14-frozen').replace('-v3','-v1')
offer=offer.replace('point-novelty-outcome-next-assessment','graph-sharing-outcome-next-assessment')
start=offer.index("scope='Publication bytes")
end=offer.index("\np=B/",start)
offer=offer[:start]+"scope='Publication bytes, full archive member pins, literal proof/tile display and scope review only. Exactly eight own paths. No scientific imports, replay, helpers or probes; partial raw metadata only. All three D14 jobs resource-admitted:18searches558placements24audits144word controls66new graph controls. Two recipient records repeat one known S0/SC fourteen-line proof. Eight qualified local packets contain two conclusions repeated across cases and arms; all point searches UNKNOWN. No useful acceleration or trained RL. All current D14 complete actuals/Sources included; historical raw remains in separately pinned previous archives. Browser QA separate.')"+offer[end:]
(B/'root/freeze_publication_offer_v1.py').write_text(offer)

verify=(previous/'root/verify_live_publication_v1.py').read_text().replace('gcts-point-novelty-proof-pilot-20261020','gcts-graph-sharing-proof-pilot-20261020').replace('point-novelty-search','graph-sharing-search').replace('point-novelty-full','graph-sharing-full')
(B/'root/verify_live_publication_v1.py').write_text(verify)
print('Authored passive packaging, eight-body review offer and normal-TLS verifier.')
