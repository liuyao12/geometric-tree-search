"""Raw Source copies and metadata/AST-only preparation; no science execution."""
from pathlib import Path
import ast,hashlib,json

B=Path(__file__).resolve().parent.parent
OLD=B.parent/'gcts-point-novelty-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
R=B/'root'; RT=B/'runtime'
def pin(path):
    p=Path(path).resolve();assert '.partial' not in p.name
    raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())
def save(path,value):
    with Path(path).open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')

api_path=B/'implementation-B/API-v1.json';api=read(api_path)
handoff=B/'implementation-B/handoff-v1.json'
entry=Path(api['entry']['path']);graph=Path(api['graph_source']['path'])
control=Path(api['graph_reference_source']['path'])
assert control.name=='graph_copy_reference_v1.py'
for field in ('entry','graph_source','graph_predecessor','graph_reference_source','predecessor','model_source','verifier_source','corpus','policy','abstention_policy','point_ordering_policy'):
    assert pin(api[field]['path'])==api[field],field
old_api=read(OLD/'implementation-B/API-v1.json')
assert api['predecessor']==old_api['entry']
assert api['graph_predecessor']==pin(OLD/'runtime/turtle.py')
assert api['roles']==old_api['roles']
assert api['model_source']==old_api['model_source'] and api['verifier_source']==old_api['verifier_source']
for field in ('policy','abstention_policy','point_ordering_policy','corpus'):
    assert (api[field]['bytes'],api[field]['sha256'])==(old_api[field]['bytes'],old_api[field]['sha256']),field
assert read(handoff)
initial=read(R/'Root-initial-reviews-handoff-v1.json')
assert len(initial['reviews'])==2
for row in initial['reviews']:
    assert pin(row['path'])==row
    v=read(row['path']);assert v['review_passed'] and all(c['passed'] for c in v['checks'])

assert not RT.exists() and not (B/'actual').exists()
RT.mkdir();copies=[]
def rawcopy(source,target,kind):
    assert not source.is_symlink() and not target.exists()
    target.write_bytes(source.read_bytes());assert pin(target)['sha256']==pin(source)['sha256']
    copies.append(dict(source=pin(source),target=pin(target),kind=kind))
runtime_sources=sorted((OLD/'runtime').glob('*.py'));assert len(runtime_sources)==28
for p in runtime_sources:
    if p.name!='turtle.py':rawcopy(p,RT/p.name,'UNCHANGED_PREDECESSOR')
rawcopy(graph,RT/'turtle.py','NEW_GRAPH_STORAGE_EXACT_AUTHOR_COPY')
rawcopy(control,RT/control.name,'NEW_INDEPENDENT_CONTROL_EXACT_AUTHOR_COPY')
custodians=['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']
for name in custodians:rawcopy(OLD/'root'/name,R/name,'UNCHANGED_PREDECESSOR')
assert len(copies)==33 and sum(p['kind']=='UNCHANGED_PREDECESSOR' for p in copies)==31
assert len(list(RT.glob('*.py')))==29
save(R/'baseline-copy-pins-v1.json',dict(files=copies,count=33,unchanged_predecessor=31,changed_graph_runtime=1,new_independent_control=1,scope='Raw byte copies only; no imports or mathematical execution.'))
for field in ('model_source','verifier_source'):
    p=Path(api[field]['path']);assert (RT/p.name).read_bytes()==p.read_bytes()

old_offer=read(OLD/'root/prospective-whole-offer-v1.json')
python=Path(old_offer['python']['path']);assert pin(python)==old_offer['python']
old_protocol=read(OLD/'root/protocol-v1.json')
limits=old_protocol['limits'];scientific=old_protocol['scientific_limits']
tree=ast.parse(entry.read_bytes(),filename=str(entry))
call=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='dict'
assert {k.arg:ast.literal_eval(k.value) for k in call.keywords}==scientific==api['limits']
sources=sorted(RT.glob('*.py'))+[entry]+[R/n for n in custodians]
assert len(sources)==34
checks=[]
for p in sources+[graph,control]:
    parsed=ast.parse(p.read_bytes(),filename=str(p));compile(parsed,str(p),'exec')
    checks.append(dict(path=str(p.resolve()),AST_and_unused_compile=True))
assert len(checks)==36
norms=[pin(B.parent.parent/'docs/basic-tiling-algorithm.md'),pin(B.parent/'gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md')]
assert norms==old_offer['normative_references']
policy=read(api['policy']['path']);acquisition=Path(policy['superseded_acquisition_document']['path'])
assert pin(acquisition)==policy['superseded_acquisition_document']
assert policy['id']=='CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1' and policy['registry']['native_registry_required_for_ordering'] is False
assert all(policy['explicit_override'][k] for k in ('scope','specialization','freeze','literal_input'))
corpus=Path(api['corpus']['path']);doc=read(corpus)
assert [s['length'] for s in doc['tests']]==[14,13,14]
native_root=D5/'implementation-B/recovered/and-support'
native=dict(template_path=str(native_root/'fixed-native-inputs/proof-boundary-001.json'),micro_path=str(native_root/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),executable_path=str(native_root/'Native-runtime/boundary-oracle-v2'))
# Include author Sources and independent-control provenance as well as executable copies.
extra=[B/'verification-L/API-v1.json',B/'verification-L/handoff-v1.json',Path(api['graph_reference_controls']['path'])]
for field in ('graph_reference_API','graph_reference_handoff','graph_reference_controls'):
    assert pin(api[field]['path'])==api[field]
control_api=read(api['graph_reference_API']['path'])
assert control_api['source']==api['graph_reference_source']
assert control_api['control_bank']==api['graph_reference_controls']
assert control_api['frozen_bounds']['controls']==22 and control_api['frozen_bounds']['fixtures']==10
if 'storage_policy' in api:
    assert pin(api['storage_policy']['path'])==api['storage_policy'];extra.append(Path(api['storage_policy']['path']))
files=sources+[graph,control,Path(api['predecessor']['path']),Path(api['graph_predecessor']['path']),api_path,handoff,acquisition,corpus,python,native_root/'Native-runtime/boundary_oracle.cpp']
files+=[Path(api[k]['path']) for k in ('policy','abstention_policy','point_ordering_policy')]+[Path(p) for p in native.values()]+extra
rows=[pin(p) for p in sorted(set(files))]
assert len(rows)>=50 and len(rows)<=55

protocol=dict(old_protocol)
protocol.update(schema='graph-copy-sharing-protocol-v1',status='FROZEN_REQUIRES_FRESH_WHOLE_PLAN_REVIEWS_AND_ONCE_GRANTS',normative_references=norms,
    change='Storage-only Graph.copy/update successor. Nested sets may share read-only storage; every Graph.update write detaches or replaces that set. Closed pilot callers and fresh unshared synthetic decision probes are the declared scope; arbitrary external nested-set writes after copy are unsupported.',
    source='Twenty-seven predecessor runtime modules and four custodians are byte-identical. The points role is an exact copy of the reviewed Graph successor; one new independent control module is added. Entry changes only VERSION/import and the declared control call; all existing scientific functions/limits remain except that call.',
    graph_source=pin(graph),graph_predecessor=api['graph_predecessor'],graph_reference_source=pin(control),
    graph_reference_API=api['graph_reference_API'],graph_reference_handoff=api['graph_reference_handoff'],graph_reference_controls=api['graph_reference_controls'],graph_control_bounds=control_api['frozen_bounds'],
    storage_control_scope='Fresh bounded tiny complete fixtures compare full domains/edges/scheduler with independent literal enumeration and check parent/sibling/grandchild isolation, repeated updates and rollback. Controls run only inside each fresh full cold actual, after existing diagnostics and before targets. Their full cost remains charged to the original Root work/positive/custody/memory/output limits. They do not prove arbitrary input equivalence or physical Wang validity.',
    costs='All original cold acquisition, compiler, word/model/reference, markings, Native registry, search/context, final-proof, output and custody work remains charged. New bounded storage controls are additional charged work. Sharing/detach costs remain inside the original per-search timer. No phase allocation profile or predicted fit.',
    search_time='Original cooperative two-second/600-attempt local limit includes Graph construction/copies/updates/audits/ranking/proposals; checkpoints, quotas and first-two full-domain audits stay fixed. Operations and cleanup can overshoot checkpoints. Root limits unchanged.',
    execution='Exactly three fresh serial cold jobs on the original three-case corpus and six ordered arms. All agents tools idle during timed actuals. No supplied donor proof or target route, old library/result/prefix/grant adoption, target weakening or outcome-dependent retry.',
    baseline_scope='Disclosed storage follow-up to D13, whose first two jobs failed whole memory and whose negative job alone qualified. D12 earlier qualification remains separate and unchanged. Timed path differences do not imply statistical speedup or phase attribution.',
    limitation='No prediction of memory fit, target proof, new theorem, useful cluster acceleration or trained RL benefit. Source ownership argument and returned controls have explicit scope. An incomplete or resource-rejected job stays unadmitted.',
    previous_turn='PROGRESS: D13 published/live-verified b16829d04af9d78a5638cef03848ae77fbbe1bd9. Two whole-memory failures, one admitted negative case; qualified six searches/86 placements/eight audits/48wordcontrols/four local packets(two distinct MP steps), zero qualified recipient certificates. All previous jobs/grants immutable.')
protocol['matched_comparison']='All four point methods retain identical common formula-novelty tiers. Existing markings and optional acquired hints remain the factorial differences. S0/SC symbolic code and every final Host/full-region/Native blocks=[] gate stay fixed. This is not a blind held-out or strongest-ATP benchmark.'
protocol['storage_callers']='Closed, reviewed pilot callers use Graph.copy/update for mutation. Existing direct nested domain writes occur only in newly constructed unshared synthetic scheduler probes. No generic public mutable-set COW guarantee.'
protocol_path=R/'protocol-v1.json';save(protocol_path,protocol)
plans=[]
for spec in doc['tests']:
    actual=B/'actual'/spec['id'];assert not actual.exists() and not Path(str(actual)+'.observer').exists()
    plan=dict(schema='proof-search-case-once-plan-v1',experiment='graph-copy-sharing-v1',case_id=spec['id'],actual_dir=str(actual),runtime_dir=str(RT),runner_path=str(R/'run_case_once_v3.py'),observer_path=str(R/'observe_case_once_v2.py'),worker_path=str(R/'case_worker_v1.py'),entry_path=str(entry),control_path=str(R/'independent_countermodel_v1.py'),input_path=str(corpus),modules=api['roles'],native=native,python=pin(python),files=rows,limits=limits,experiment_limits=scientific,protocol=pin(protocol_path),superseded_acquisition=pin(acquisition),graph_source=pin(graph),graph_reference_source=pin(control),authority='No execution from plan; exact fresh reviewed Root single-use grant required.',trusted_runtime='Pinned isolated CPython/fixed Source nonhostile reproducible custodian, not a hostile sandbox or OS real-time guarantee.',old_qualifications='All D13 and older failures/grants/policies/qualifications immutable. No rescue, retry or prefix adoption.')
    for k in ('policy','abstention_policy','point_ordering_policy'):plan['ordering_policy' if k=='policy' else k]=api[k]
    path=R/('plan-'+spec['id']+'-v1.json');save(path,plan);plans.append(pin(path))
offer=dict(schema='graph-copy-sharing-whole-offer-v1',plans=plans,files=rows,protocol=pin(protocol_path),normative_references=norms,python=pin(python),initial_Source_reviews=initial['reviews'],source_AST_checks=checks,expected_case_jobs=3,expected_explicit_arm_outcomes=18,scientific_calls=0,new_actuals=0,new_grants=0,old_grants_remaining=0,closure_count=len(rows),runtime_copy_count=33,unchanged_predecessor_copies=31,resource_fit='UNMEASURED; actual whole admission decisive.',readiness='PENDING_FRESH_WHOLE_SOURCE_PLAN_REVIEWS_AND_ROOT_ONCE_GRANTS')
for k in ('policy','abstention_policy','point_ordering_policy'):offer['ordering_policy' if k=='policy' else k]=api[k]
save(R/'prospective-whole-offer-v1.json',offer)
print(json.dumps(dict(offer=pin(R/'prospective-whole-offer-v1.json'),plans=plans,files=len(rows),Source_AST_checks=len(checks),new_actuals=0,new_grants=0)))
