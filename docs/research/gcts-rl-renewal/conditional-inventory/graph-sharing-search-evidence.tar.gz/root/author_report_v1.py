"""Author passive complete-record report projection; no scientific calls."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
s=(B.parent/'gcts-point-novelty-proof-pilot-20261020/root/build_point_report_v1.py').read_text()
def replace(old,new):
    global s
    assert old in s,old[:100]
    s=s.replace(old,new)
replace('ordering=[];point_clusters=[]','ordering=[];point_clusters=[];storage_controls=[]')
replace("assert c['reference_check']['complete'] and c['word_model_check']['complete']", "assert c['reference_check']['complete'] and c['word_model_check']['complete']\n    gc=s['graph_storage_diagnostics'];assert gc['complete'] and gc['status']=='PASSED' and gc['control_count']==len(gc['controls'])==22 and gc['fixture_count']==10\n    assert all(row['complete'] and row['status']=='PASSED' for row in gc['controls'])\n    storage_controls.append(dict(case_id=spec['id'],title=spec['title'],whole_job_admitted=admitted,receipt=gc,source=pin(path)))")
replace('typed-point-novelty-actual-scientific-review-v1.json','typed-graph-sharing-actual-scientific-review-v1.json')
replace("join=joins[0]\n                    assert", "join=joins[0]\n                    if join.get('all_members_selected_at') is None:continue\n                    assert")
replace("status='Qualified negative-case local branch extension. The saved Host check accepted this prefix; both nominated command and guard members later coexist on this recorded branch. This is no completed recipient proof, no Native-admitted macro and no measured search advantage.'", "status='Resource-admitted local branch extension in '+spec['title']+'. The saved Host check accepted this prefix; both nominated command and guard members later coexist on this recorded branch. This local record is separate from a completed recipient proof, a Native-admitted macro or a measured search advantage.'")
replace("schema='Root-passive-point-novelty-search-assessment-v1'","schema='Root-passive-graph-sharing-search-assessment-v1'")
replace("B.parent/'gcts-novelty-proof-pilot-20261020/root/passive-actual-assessment-v1.json'","B.parent/'gcts-point-novelty-proof-pilot-20261020/root/passive-actual-assessment-v1.json'")
start=s.index("assert summary['accepted_recipient_proofs']==0")
end=s.index('symbolic_comparison=[]',start)
s=s[:start]+'''assert summary['accepted_recipient_proofs']==2
assert summary['resource_admitted_case_jobs']==3 and summary['resource_rejected_case_jobs']==0
assert [a['arm'] for a in totals[0]['accepted_recipient_proofs']]==['S0','SC']
assert [a['rows'] for a in totals[0]['accepted_recipient_proofs']]==[14,14]
assert proofs[0]['proof']==proofs[1]['proof'] and proofs[0]['whole_job_admitted'] and proofs[1]['whole_job_admitted']
assert len(pointrows)==12 and all(p['status']=='unknown_search_budget' for p in pointrows)
assert summary['searches_returned']==summary['admitted_searches_returned']==18 and summary['cluster_arms_skipped']==0
assert summary['point_placement_attempts']==summary['admitted_point_placement_attempts']==558
assert summary['complete_point_domain_audits']==summary['admitted_complete_point_domain_audits']==24
assert len(ordering)==9 and sum(o['successful_proposals'] for o in ordering)==16
assert sum(o['symbolic_order_changes'] or 0 for o in ordering)==2
assert len(point_clusters)==8 and len(tiles)==78
summary.update(ordering_only_policy=True,exact_prefix_abstention=True,common_point_formula_novelty_order=True,registered_ground_blocks=False,graph_storage_sharing=True,successful_ordering_proposals_observed=16,point_packets_observed=8,point_packets_qualified=8,qualified_local_member_completions=8,distinct_local_result_formulas=len({json.dumps(p['spec']['target'],sort_keys=True) for p in point_clusters}),literal_symbolic_order_changes=2,accepted_recipient_certificates=2,distinct_recipient_statements=1,new_theorem=False,admitted_word_controls=144,observed_word_controls=144,new_storage_controls_per_case=22,observed_new_storage_controls=66,admitted_new_storage_controls=66)
assert summary['distinct_local_result_formulas']==2 and summary['scientific_complete']
save(B/'root/passive-actual-assessment-v1.json',summary)
''' +s[end:]
replace("B.parent/'gcts-novelty-proof-pilot-20261020/actual'","B.parent/'gcts-point-novelty-proof-pilot-20261020/actual'")
replace("symbolic_comparison.append(dict(current_admitted=", "symbolic_comparison.append(dict(previous_admitted=prior_by_id[spec['id']]['resource_candidate_accepted'],current_admitted=")
start=s.index('headline=');end=s.index('\ndef prose_spacing',start)
s=s[:start]+'''headline="All three cold jobs now qualify; a proof-search advantage remains unproved."
conclusion="Shared graph storage passes the unchanged resource gates in all three jobs. All eighteen searches return, with 558 point placements, twenty-four full-domain audits and sixty-six new storage controls. S0 and SC produce the same known fourteen-line proof. Every point search remains budget unknown. This restores an admitted comparison without demonstrating useful cluster or RL acceleration."
assessment=[
    'Graph copies now own separate top dictionaries while sharing nested sets read-only. Each update detaches an old domain before its first write and replaces edge sets with fresh values. The Source guarantee is for the fixed, sequential, nonreentrant pilot callers; arbitrary foreign nested-set mutation or a mid-update snapshot is outside that guarantee.',
    'All sixty-six new finite controls returned PASSED: twenty-two per job, with complete literal fixtures, snapshots and event references. They cover parent/sibling/grandchild isolation, fractional occupancy, completed and newly exposed frontier points, distant markings, zero values, scheduler priority, alternative empty boundaries and exact expected error identities. Source review and finite controls have distinct scopes; they are not a generic COW theorem.',
    'All three whole jobs pass the original one-GiB gate, at 889,241,600, 966,164,480 and 939,376,640 bytes. The previous first two jobs failed that gate. This is a disclosed storage intervention plus additional diagnostics on one fixed development cohort. There is no measured allocation-phase attribution or statistical speedup evidence.',
    'The two accepted recipient records are S0 and SC versions of the same fourteen-row primitive certificate for one already-known statement. The positive symbolic candidate ordering and path remain identical. No point proof is found: all twelve point searches are budget UNKNOWN, despite more placements in their timed prefixes.',
    'Eight qualified point packets complete their nominated command and guard members on recorded branches. They are two distinct local MP conclusions repeated across the first and negative cases and P01/P11. These are actual local extensions, not eight theorems, a registered macro or evidence of useful cluster selection.',
    'The complete model/reduction checks and all 144 word controls belong to admitted jobs. Certified failure markings still give twelve fewer initial incidences per marked comparison, from shallow first-row failures. No learned multiscale abstraction or during-placement elimination gain is established.',
    'All ground registry queries remain Native UNKNOWN, unadmitted, with usable empty. Separate ordering instances still need actual-context Host checks and exact existing primitive placements; final target proofs require the unchanged Host/full-region/Native gates. No trained RL policy is present.',
    'With the full bounded comparison admitted, the next priority returns to learned cluster proposals and receptor selection: automatic training-only acquisition, a frozen policy, held-out theorem families and explicit conventional and fixed-heuristic controls. The fixed novelty preference must not be relabeled RL or tuned to the visible target route.',
    'The full program remains practical fixed/movable boundary tiling, Turtle and Penrose plane growth, hierarchical receptor/lemma families, automated arithmetic and symbolic Hilbert geometry, and a fixed universal Wang construction with a physical checking bridge. This pilot does not complete those objectives.'
]
next_path=B/'implementation-B/graph-sharing-outcome-next-assessment-v1.json'
report=dict(schema='graph-sharing-search-report-v1',headline=headline,conclusion=conclusion,proof_scope='Two resource-admitted searches, S0 and SC, contain the same fourteen-line primitive certificate for one known recipient statement. Their exact tiles, formulas and English readings are inspectable below. The three elementary donor proofs come from the first admitted cold job. Local point-search extensions are shown separately above; none completes a recipient proof.',cases=cases,proofs=proofs,point_clusters=point_clusters,storage_controls=storage_controls,tiles=tiles,actual_summary=summary,comparison=comparison,comparison_source=pin(prior_path),symbolic_comparison=symbolic_comparison,ordering=ordering,assessment=assessment,next_assessment=read(next_path),next_assessment_source=pin(next_path),ordering_diagnostic_text='All eight point proposal packets now belong to resource-admitted jobs, and their nominated member pairs complete locally. No point target is solved. The shared graph representation makes this bounded cohort feasible under the same gates; useful cluster guidance and RL learning remain the next scientific questions.',review_summary='Independent initial and whole-plan reviews preceded three serial cold jobs with other agents idle. Independent complete-record reviews classify every case as resource-admitted. All original proof gates, search limits and word/model controls remain; twenty-two new graph ownership controls per case also return. Registry UNKNOWN, local Host checks, full target proof checks and resource admission remain separate. No scientific replay occurred outside actuals.')
''' +s[end:]
replace("OUT/'point-novelty-search-data.json'","OUT/'graph-sharing-search-data.json'")
replace("OUT/'point-novelty-search-engineering.json'","OUT/'graph-sharing-search-engineering.json'")
replace("schema='point-novelty-search-method-v1'","schema='graph-sharing-search-method-v1'")
(B/'root/build_graph_report_v1.py').write_text(s)
print('Authored passive complete-record graph-sharing report builder.')
