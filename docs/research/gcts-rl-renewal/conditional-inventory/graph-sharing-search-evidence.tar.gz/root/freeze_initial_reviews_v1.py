"""Passive initial Source review pin join; not whole-plan or execution authority."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
def pin(path):
    p=Path(path).resolve();assert '.partial' not in p.name
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(p):return json.loads(Path(p).read_bytes())
def binds(value,expected):
    if isinstance(value,dict):
        if all(value.get(k)==v for k,v in expected.items()):return True
        return any(binds(v,expected) for v in value.values())
    if isinstance(value,list):return any(binds(v,expected) for v in value)
    return False
api_path=B/'implementation-B/API-v1.json';api=read(api_path)
for field in ('entry','graph_source','graph_reference_source','graph_reference_API','graph_reference_handoff','graph_reference_controls','predecessor','graph_predecessor'):
    assert pin(api[field]['path'])==api[field]
paths=[B/'review-C/typed-graph-sharing-Source-review-v1.json',B/'verification-L/typed-graph-sharing-Source-ABI-review-v1.json']
reviews=[]
for p in paths:
    d=read(p);assert d['review_passed'] is True and d['checks'] and all(c['passed'] for c in d['checks'])
    assert binds(d,pin(api_path)), 'review must bind exact frozen B API'
    for field in ('entry','graph_source','graph_reference_source'):
        assert binds(d,api[field]),field
    reviews.append(pin(p))
value=dict(schema='D14-Root-initial-Source-review-handoff-v1',reviews=reviews,api=pin(api_path),handoff=pin(B/'implementation-B/handoff-v1.json'),control_API=pin(B/'verification-L/API-v1.json'),control_handoff=pin(B/'verification-L/handoff-v1.json'),previous_turn_audit=pin(B/'root/Root-previous-turn-audit-v1.json'),source_review_passed=True,scope='Conditional initial Source composition only; fresh whole closure, protocol, cold plans, independent whole-plan reviews, Root preflight and new once grants remain required.',new_actuals=0,new_grants=0,scientific_calls=0,partial_files_parsed=False,goal_remains_active=True)
p=B/'root/Root-initial-reviews-handoff-v1.json'
with p.open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(pin(p)))
