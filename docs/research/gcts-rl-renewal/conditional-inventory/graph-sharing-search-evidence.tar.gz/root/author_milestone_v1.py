"""Author a terminal progress handoff using complete saved metadata only."""
from pathlib import Path
B=Path(__file__).resolve().parent.parent
s=(B.parent/'gcts-point-novelty-proof-pilot-20261020/root/finalize_milestone_v1.py').read_text()
s=s.replace("s['resource_admitted_case_jobs']==1 and s['resource_rejected_case_jobs']==2", "s['resource_admitted_case_jobs']==3 and s['resource_rejected_case_jobs']==0")
s=s.replace("s['accepted_recipient_certificates']==0 and not s['scientific_complete']", "s['accepted_recipient_certificates']==2 and s['scientific_complete'] and not s['whole_goal_complete']")
s=s.replace("s['admitted_point_placement_attempts']==86 and s['admitted_complete_point_domain_audits']==8", "s['admitted_point_placement_attempts']==558 and s['admitted_complete_point_domain_audits']==24")
s=s.replace('D13-Root-terminal','D14-Root-terminal').replace('point-novelty-search.html','graph-sharing-search.html').replace('#local-clusters','#reader')
s=s.replace('typed-point-novelty-actual-scientific','typed-graph-sharing-actual-scientific').replace('typed-point-novelty-resource-custody','typed-graph-sharing-resource-custody').replace('point-novelty-outcome-next-assessment','graph-sharing-outcome-next-assessment')
s=s.replace('point_placements=293','point_placements=558').replace('word_controls=144,Native_queries=288','word_controls=144,graph_controls=66,Native_queries=288')
s=s.replace("case_ids=['pilot-fork-join-missing-Pa'],searches=6,point_placements=86,point_audits=8,word_controls=48,Native_queries=89,point_packets=4,local_member_completions=4,distinct_local_steps=2,recipient_certificates=0", "case_ids=['pilot-fork-join-positive','pilot-quantifier-equality-positive','pilot-fork-join-missing-Pa'],searches=18,point_placements=558,point_audits=24,word_controls=144,graph_controls=66,Native_queries=288,point_packets=8,local_member_completions=8,distinct_local_steps=2,recipient_certificates=2,distinct_known_recipient_statements=1")
old="next_action='Assess bounded memory ownership from Source without changing logical semantics or resource gates. Any implementation and matched repetition require separately reviewed exact Sources, full plans and fresh one-use grants. No causal phase profile is claimed, no memory ceiling increase or current-job rescue, no fresh actual authorized by this handoff.'"
new="next_action='Return to the scientific question: learned cluster proposals and receptor selection with automatic training-only acquisition, a frozen policy, held-out theorem families, and explicit primitive/conventional/fixed-heuristic controls. Current fixed novelty ordering is not RL. A separately frozen and reviewed pilot must define target-independent splits, costs, rewards, seeds, evidence and exact fallback/Host/full-region/Native gates. No current grant remains and no fresh actual is authorized by this handoff.'"
assert old in s
s=s.replace(old,new)
(B/'root/finalize_milestone_v1.py').write_text(s)
print('Authored D14 terminal progress handoff; full research goal stays active.')
