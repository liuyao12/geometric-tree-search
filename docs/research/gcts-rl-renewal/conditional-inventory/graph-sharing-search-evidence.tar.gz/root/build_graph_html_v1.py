"""Author a display-only report from the frozen corrected predecessor HTML."""
from pathlib import Path
import hashlib

B=Path(__file__).resolve().parent.parent
source=B.parent/'gcts-point-novelty-proof-pilot-20261020/publication/point-novelty-search.html'
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='01259cd26559b6401971b3702c4999ecee43229683ea5622c2805d38c6d77520'
h=raw.decode()

def replace(old,new):
    global h
    assert h.count(old)==1,(old,h.count(old))
    h=h.replace(old,new,1)

replace('<title>Point novelty and local cluster steps — GCTS research</title>',
        '<title>Shared graph storage and proof-search evidence — GCTS research</title>')
replace('reader.html#point-novelty-update','reader.html#graph-sharing-update')
replace('<a href="novel-cluster-search.html#ordering">Previous qualified cohort</a>',
        '<a href="point-novelty-search.html#local-clusters">Previous memory-limited cohort</a><a href="#storage">Storage and controls</a>')
replace('<h1>Point hints reach actual proof receptors</h1>',
        '<h1>The whole proof-search comparison now fits</h1>')
replace('A shared formula-novelty preference lets point search reach local cluster steps in the admitted negative control. Both positive jobs exceed the whole-memory ceiling. No target proof or useful search advantage is established.',
        'Read-only sharing of graph sets brings all three cold jobs within the original memory cap. The same known symbolic proof and local point extensions are now qualified. Useful cluster guidance and learned RL proposals remain open questions.')
replace('Apply the same stable formula-novelty order to all four point arms; retain the complete primitive fallback and final proof gates.',
        'Change only graph copy/update storage; preserve the exact search policies, complete primitive fallback and final proof gates.')
replace('Check the hint policy, actual-context expansion, unchanged search semantics and all resource and custody records independently.',
        'Author independent finite graph ownership controls; review source semantics and complete resource and custody records.')
replace('This follow-up retains exact-prefix abstention and adds a common point branch order; no block is registered.',
        'This follow-up retains exact-prefix abstention and the existing common point branch order; no block is registered.')
start=h.index('<section id="repair">')
end=h.index('<section id="carrier">',start)
storage='''<section id="storage"><h2>Change storage, preserve search semantics</h2>
<p>Every graph copy still owns its top-level dictionaries. Nested candidate sets are initially shared read-only. An update copies an old domain before its first write; affected edge sets are replaced by fresh sets. Decisions, candidate membership, forced moves, generation order, novelty tiers, rollback and proof gates are unchanged.</p>
<figure class="viewer"><svg viewBox="0 0 900 260" style="width:100%;height:auto" role="img" aria-label="Conceptual source diagram: parent and child own private dictionaries, share an unchanged set, and keep changed sets separate">
<defs><marker id="storage-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8Z" fill="#566b61"/></marker></defs>
<g fill="white" stroke="#779487" stroke-width="2"><rect x="25" y="28" width="220" height="76" rx="8"/><rect x="25" y="154" width="220" height="76" rx="8"/><rect x="365" y="84" width="220" height="76" rx="8" fill="#d9edf4"/><rect x="655" y="18" width="220" height="76" rx="8" fill="#e7dcf3"/><rect x="655" y="166" width="220" height="76" rx="8" fill="#dcebd6"/></g>
<g stroke="#566b61" stroke-width="2" fill="none" marker-end="url(#storage-arrow)"><path d="M245 65L365 110"/><path d="M245 190L365 135"/><path d="M245 45L655 45"/><path d="M245 210L655 210"/></g>
<g fill="#203d36" font-family="system-ui,sans-serif" font-size="18" text-anchor="middle"><text x="135" y="60">Parent dictionaries</text><text x="135" y="86">private ownership</text><text x="135" y="186">Child dictionaries</text><text x="135" y="212">private ownership</text><text x="475" y="115">Unchanged set</text><text x="475" y="142">shared read-only</text><text x="765" y="50">Old domain</text><text x="765" y="77">parent retains it</text><text x="765" y="198">Changed domain</text><text x="765" y="225">new child-owned set</text></g></svg>
<figcaption>Conceptual ownership diagram derived from source. It is not an allocation measurement. Fixed sequential, nonreentrant pilot callers are covered; arbitrary writes to borrowed nested sets or snapshots during an update are outside the reviewed guarantee.</figcaption></figure>
<div class="cards"><article class="card"><h3>Same scientific comparison</h3><p>The shared formula-novelty order remains in all four point arms. Hints rank existing alternatives at the mandatory graph-selected point. No candidate is removed by a preference.</p></article><article class="card"><h3>Independent small controls</h3><p>Ten literal fixtures test copying, parent/sibling/grandchild isolation, fractional occupancy, completed and new frontier points, distant markings, zero values, generations and exact injected error identities.</p></article><article class="card"><h3>Every cost remains charged</h3><p>Twenty-two controls run inside each cold job, before recipient setup, under the original outer caps. Finite returned tests and the closed-caller source argument have distinct scopes.</p></article></div>
<div class="scroll"><table><thead><tr><th>Case</th><th>Graph controls</th><th>Fixtures</th><th>Receipt</th><th>Whole job</th></tr></thead><tbody id="storage-rows"></tbody></table></div>
<label for="storage-control">Inspect a returned control from the first admitted job</label><select id="storage-control" disabled><option>Loading…</option></select><details><summary>Complete saved fixture bank, control, snapshots and event references</summary><pre id="storage-detail"></pre></details>
<p class="warning">These controls do not establish a general copy-on-write theorem. Synthetic helper states and expected-error branches are diagnostics, not proof-search traces. All checks are displayed from complete saved outputs; the reader performs no scientific simulation.</p></section>
'''
h=h[:start]+storage+h[end:]
replace('All six arms run under the new ordering-only policy.',
        'All six arms run under the inherited ordering-only policy.')
replace('The <a href="novel-cluster-search.html#ordering">previous D12 cohort</a> admitted all three jobs. The new cohort admits only the negative case. More placements in a timed prefix are not a matched speedup measure. Complete high-water readings do not identify the causal allocation phase.',
        'The <a href="point-novelty-search.html#comparison">previous D13 cohort</a> rejected the first two jobs at the memory gate and admitted the negative case. All three new jobs qualify. These are single runs on a fixed development cohort; more placements in a timed prefix are not a matched speedup measure. Whole high-water readings do not identify an allocation phase. Historical qualification is unchanged.')
replace('There are eight observed point packets: four in the memory-rejected positive case and four in the admitted negative case. Only the latter four qualify. They represent two local extensions repeated across P01 and P11. All point searches remain budget unknown.',
        'All eight point packets now belong to admitted jobs: four in the first case and four in the negative case. They contain two distinct local conclusions repeated across cases and P01/P11. Their nominated command and guard members later coexist on recorded branches. All twelve point searches remain budget unknown.')
replace('The current positive S0/SC checker records are diagnostic only because their whole job failed. Earlier qualified D12 proofs remain available in the previous report. No complete admitted comparison or new theorem follows.',
        'The first case has two admitted certificate records, S0 and SC, for the same already-known fourteen-line proof. Their positive symbolic path is identical. No point proof, new theorem, trained RL policy or useful cluster acceleration is established.')
replace('These are actual saved point-search prefixes from the admitted negative case.',
        'These are actual saved point-search prefixes from the admitted first and negative cases.')
replace('The four packets contain two repeated local mathematical steps.',
        'The eight packets contain two distinct local mathematical steps repeated across cases and arms.')
replace('All eighteen bounded searches returned, but only the negative job passes whole-resource admission.',
        'All eighteen bounded searches returned and all three jobs pass whole-resource admission.')
replace('Diagnostic target records and qualified donor proofs','Qualified target records and donor proofs')
replace('For each diagnostic recipient record, each line has the exact selected command and guard tile.',
        'For each admitted recipient certificate, each line has the exact selected command and guard tile.')

# Correct the inherited hardcoded admission labels while retaining literal row rendering.
start=h.index('function showOrdering()')
end=h.index('function showPipeline()',start)
ordering='''function showOrdering(){const label=(accepted,admitted)=>accepted?(admitted?'accepted / ADMITTED':'checker accepted / NOT ADMITTED'):'unknown';el('symbolic-comparison').replaceChildren(...data.symbolic_comparison.map(c=>{const tr=document.createElement('tr');[c.title+' / '+(c.current_admitted?'ADMITTED':'NOT ADMITTED'),c.previous_SC_attempts+' / '+label(c.previous_SC_accepted,c.previous_admitted),c.current_SC_attempts+' / '+label(c.current_SC_accepted,c.current_admitted),c.current_S0_attempts+' / '+label(c.current_S0_accepted,c.current_admitted),c.same_accepted_primitive_proof?(c.current_admitted?'Yes — admitted pair':'Yes — job NOT ADMITTED'):'No accepted pair'].forEach(v=>tr.append(txt('td',v)));return tr}));el('ordering-rows').replaceChildren(...data.ordering.map(o=>{const tr=document.createElement('tr');[o.title+' / '+o.arm+' / '+(o.whole_job_admitted?'ADMITTED':'NOT ADMITTED'),o.instances,o.successful_proposals,num(o.symbolic_order_changes),num(o.point_activated_packets),o.attempts+' / '+o.status].forEach(v=>tr.append(txt('td',v)));return tr}));el('ordering-diagnostic').textContent=data.ordering_diagnostic_text;el('diagnostic-detail').textContent=JSON.stringify(data.next_assessment,null,2)}
function showStorage(){const entries=data.storage_controls;el('storage-rows').replaceChildren(...entries.map(x=>{const tr=document.createElement('tr');[x.title,x.receipt.control_count,x.receipt.fixture_count,x.receipt.status,x.whole_job_admitted?'ADMITTED':'NOT ADMITTED'].forEach(v=>tr.append(txt('td',v)));return tr}));const first=entries[0];opts('storage-control',first.receipt.controls,(x)=>x.id||x.name||x.control_id||JSON.stringify(x).slice(0,100));const show=()=>{const index=Number(el('storage-control').value);el('storage-detail').textContent=JSON.stringify({case_id:first.case_id,source:first.source,control:first.receipt.controls[index],complete_receipt:first.receipt},null,2)};el('storage-control').addEventListener('change',show);show()}
'''
h=h[:start]+ordering+h[end:]
replace('showComparison();showPipeline();showOrdering();showCase();showProof();showTile()',
        'showComparison();showPipeline();showOrdering();showStorage();showCase();showProof();showTile()')
# Own links only: the explicit predecessor links above keep their old prefix.
for suffix in ['-engineering.json','-data.json','-evidence.tar.gz','-manifest.json','-review-C.json','-review-L.json']:
    h=h.replace('point-novelty-search'+suffix,'graph-sharing-search'+suffix)
assert 'function showLocal()' in h
assert "const formula=txt('span','\\\\('+f(c.formula)+'\\\\)')" in h
assert 'Both positive jobs exceed' not in h
out=B/'publication/graph-sharing-search.html'
out.parent.mkdir(exist_ok=True)
out.write_text(h)
print({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
