"""Exact metadata preflight and three fresh single-use grants; no science calls."""
from pathlib import Path
import hashlib,json,sys
B=Path(__file__).resolve().parent.parent
R=B/'root'
def pin(path):
    p=Path(path).resolve();assert '.partial' not in p.name
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    assert '.partial' not in Path(path).name
    return json.loads(Path(path).read_bytes())
def save(path,value):
    with Path(path).open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
def contains(value,expected):
    if value==expected:return True
    if isinstance(value,dict):return any(contains(v,expected) for v in value.values())
    if isinstance(value,list):return any(contains(v,expected) for v in value)
    return False
assert len(sys.argv)==5
offer_path=R/'prospective-whole-offer-v1.json';offer=read(offer_path)
for row in offer['files']+offer['plans']+[offer['protocol']]+offer['normative_references']:
    assert pin(row['path'])==row
assert 50<=offer['closure_count']==len(offer['files'])<=55 and len(offer['plans'])==3
assert offer['runtime_copy_count']==33 and offer['unchanged_predecessor_copies']==31
names=['typed-graph-sharing-Source-review-v1.json','typed-graph-sharing-Source-ABI-review-v1.json','typed-graph-sharing-whole-prospective-Source-review-v1.json','typed-graph-sharing-whole-plan-Source-ABI-review-v1.json']
reviews=[]
for argument,name in zip(sys.argv[1:],names):
    p=Path(argument).resolve();assert p.name==name and p.is_relative_to(B)
    receipt=read(p);assert receipt['review_passed'] and receipt['checks'] and all(c['passed'] for c in receipt['checks'])
    if len(reviews)>=2:assert contains(receipt,pin(offer_path))
    reviews.append(pin(p))
assert reviews[:2]==offer['initial_Source_reviews']
protocol=read(offer['protocol']['path'])
old=read(B.parent/'gcts-point-novelty-proof-pilot-20261020/root/protocol-v1.json')
assert protocol['limits']==old['limits'] and protocol['scientific_limits']==old['scientific_limits']
preflight=dict(schema='Root-graph-copy-sharing-preflight-v1',offer=pin(offer_path),protocol=offer['protocol'],reviews=reviews,review_passed=True,new_uses=3,old_grants_remaining=0,goal_status='active',previous_turn='PROGRESS: D13 live b16829d; two whole-memory failures and one admitted negative, four local packets(two distinct steps), no qualified recipient proof. Predecessor raw/Source/live pins revalidated. No D13 qualification is changed.',authority='Three fresh serial cold attempts only, all agents tools idle. No outcome-dependent retry, old grant/library/result/prefix adoption, or memory-limit relaxation.',conformance='Three inherited preference policies and new closed-caller Graph storage Source bound. Same complete candidate universe/globalDEADFORCEDearliestgeneration/forcedarrays/noveltyfallback/rollback/contextHost/finalHost-fullregion-Native blocks=[] gates. Independent tiny ownership/domain/edge/scheduler controls added inside actual, all cost charged. Original first-two complete target audits and 48 word controls per job still required; all six arms/same three cases/caps unchanged.',scope='Reachable aligned complete-word Native/point adaptation only. External direct nested-set mutation after copy unsupported. No arbitrary byte/partial-state, physical universal Wang, trainedRL, practical Turtle/Penrose plane or whole-program completion claim.',closure_count=offer['closure_count'],source_AST_checks=len(offer['source_AST_checks']),partial_files_parsed=False,scientific_calls=0)
save(R/'Root-preflight-v1.json',preflight)
for row in offer['plans']:
    plan=read(row['path']);assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
    grant=dict(schema='Root-fresh-graph-copy-sharing-case-grant-v1',authorized=True,uses=1,no_retry=True,case_id=plan['case_id'],actual_dir=plan['actual_dir'],plan_sha256=row['sha256'],runner_sha256=pin(plan['runner_path'])['sha256'],observer_sha256=pin(plan['observer_path'])['sha256'],review_passed=True,reviews=reviews,root_preflight=pin(R/'Root-preflight-v1.json'),old_grants_reused=False)
    save(R/('grant-'+plan['case_id']+'-v1.json'),grant)
print(json.dumps(dict(preflight=pin(R/'Root-preflight-v1.json'),fresh_grants=3,actuals=0)))
