"""Pin the eight already packaged publication bodies for passive review."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent.parent
D=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
paths=sorted(D.glob('graph-sharing-search*'))+[D/'reader.html']
assert len(paths)==8
offer=dict(schema='D14-frozen-publication-review-offer-v1',files=[pin(p) for p in paths],
    scientific_assessment=pin(B/'root/passive-actual-assessment-v1.json'),
    archive_scan=pin(B/'root/archive-scan-v1.json'),
    reader_delta=pin(B/'root/reader-publication-delta-v1.json'),
    posthoc_next_assessment=pin(B/'implementation-B/graph-sharing-outcome-next-assessment-v1.json'),
    scope='Publication bytes, full archive member pins, literal proof/tile display and scope review only. Exactly eight own paths. No scientific imports, replay, helpers or probes; partial raw metadata only. All three D14 jobs resource-admitted:18searches558placements24audits144word controls66new graph controls. Two recipient records repeat one known S0/SC fourteen-line proof. Eight qualified local packets contain two conclusions repeated across cases and arms; all point searches UNKNOWN. No useful acceleration or trained RL. All current D14 complete actuals/Sources included; historical raw remains in separately pinned previous archives. Browser QA separate.')
p=B/'root/publication-review-offer-v1.json'
p.write_text(json.dumps(offer,sort_keys=True,indent=2)+'\n')
print(json.dumps(pin(p)))
