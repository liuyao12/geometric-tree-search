"""Passive joins over complete saved JSON only; no research imports or replay."""
from pathlib import Path
import collections
import hashlib
import json

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-graph-sharing-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-point-novelty-proof-pilot-20261020'
D8 = BASE / 'research-runs/gcts-word-point-proof-pilot-20261020'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

def verify(row):
    assert pin(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()

offer_path = D / 'root/prospective-whole-offer-v1.json'
offer = read(offer_path)
assert len(offer['files']) == 53
for row in offer['files'] + offer['plans'] + [offer['protocol']] + offer['normative_references']:
    verify(row)
corpus = read(next(r['path'] for r in offer['files'] if r['sha256'] == '2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'))
bank = read(D8 / 'verification-L/declarative-diagnostic-bank-v1.json')
control_ids = [r['id'] for r in bank['controls']]
external_path = D / 'root/external-tool-observer-v1.json'
external = read(external_path)
assert external['all_three_sessions_terminal'] is True
terminals = [dict(case_id=r['case_id'], **r['result']) for r in external['observations'] if 'exit_code' in r['result']]
assert len(terminals) == 3 and [r['exit_code'] for r in terminals] == [0,0,0]
launches = {r['case_id']:r['result']['session_id'] for r in external['observations'] if r['phase']=='launch'}
assert list(launches.values()) == [2055,83879,24043]
cases = [s['id'] for s in corpus['tests']]
expected = [dict(S0=14, SC=14, P00=44, P01=51, P10=49, P11=49),
            dict(S0=600, SC=600, P00=45, P01=45, P10=42, P11=43),
            dict(S0=600, SC=600, P00=51, P01=49, P10=41, P11=49)]
expected_peaks = [889241600,966164480,939376640]
expected_instances = [7, 11, 7]
expected_proposals = [4, 0, 4]
expected_order_changes = [0, 0, 2]
observations = []
actual_pins = []
grant_pins = []
status_total = collections.Counter()
point_total = audit_total = proposal_total = changed_order_total = 0
for index, cid in enumerate(cases):
    path = D / 'actual' / cid
    observer_path = D / 'actual' / (cid + '.observer') / 'observer.json'
    result_path = path / 'result.json'
    rp = pin(result_path)
    record = read(result_path)
    s = record['scientific_result']
    assert len(s['tests']) == 1
    t = s['tests'][0]
    header = read(path / 'worker-header.json')
    terminal = read(path / 'terminal.json')
    observer = read(observer_path)
    tool = dict(terminal=next(r for r in terminals if r['case_id'] == cid))
    plan_path = D / 'root' / ('plan-' + cid + '-v1.json')
    plan = read(plan_path)
    grant_path = D / 'root' / ('grant-' + cid + '-v1.json')
    grant = read(grant_path)
    consumed = read(path / 'CONSUMED.json')
    grant_pins.append(pin(grant_path))
    assert record['case_id'] == s['selected_case_id'] == header['case_id'] == terminal['case_id'] == observer['case_id'] == cid
    assert consumed['case_id'] == grant['case_id'] == cid and consumed['uses'] == grant['uses'] == 1
    assert consumed['plan_sha256'] == grant['plan_sha256'] == pin(plan_path)['sha256']
    assert consumed['grant_sha256'] == pin(grant_path)['sha256']
    assert grant['authorized'] is grant['no_retry'] is True and grant['old_grants_reused'] is False
    for row in grant['reviews']:
        verify(row)
    assert s['inputs'] == corpus and s['limits'] == plan['experiment_limits']
    assert s['job_record_complete'] is s['all_six_searched'] is s['scientific_complete'] is s['complete'] is True
    assert s['resource_accepted'] is False
    assert s['registry_native_admitted'] is s['registered_inference_used'] is False
    assert s['ordering_hints_enabled'] is True
    assert s['ordering_policy']['id'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY_V1'
    assert s['ordering_policy']['native_registry_required_for_ordering'] is False
    assert record['status'] == header['status'] == 'COMPLETE' and record['error'] is None
    assert record['first_Root_fault'] is header['first_Root_fault'] is False
    assert terminal['header_valid'] is True and terminal['process_exit_code'] == 0
    assert header['result'] == terminal['result'] == rp and terminal['header'] == header
    assert record['source_unchanged'] is terminal['sources_unchanged'] is True
    assert record['old_qualification_reused'] is record['full_physical_Wang_claim'] is False
    admitted = True
    assert observer['resource_candidate_accepted'] is admitted
    assert observer['parent_exit_code'] == 0 and tool['terminal']['exit_code'] == (0 if admitted else 2)
    assert observer['conservative_whole_peak_bytes'] == expected_peaks[index]
    assert (expected_peaks[index] < plan['limits']['memory_bytes']) is admitted
    transport = record['native_transport']
    queries = record['native_queries']
    assert s['native_records'] == queries and transport['complete_records'] == len(queries)
    assert transport['all_reaped'] is transport['closed'] is True and transport['native_exit_code'] == 0
    assert [q['id'] for q in queries] == list(range(len(queries)))
    assert len(transport['request_stages']) == len(queries)
    for q, stage in zip(queries, transport['request_stages'], strict=True):
        assert hashlib.sha256(canonical(q['request'])).hexdigest() == q['request_sha256']
        assert stage['record_id'] == stage['ordinal'] == q['id'] and stage['stage'] == 'COMPLETED'
        assert stage['purpose'] == q['purpose'] and stage['limit'] == plan['experiment_limits']['native_steps']
        for key in ['input_sha256', 'output_sha256', 'request_sha256']:
            assert stage[key] == q[key]
    assert pin(path / 'native/input.bin')['sha256'] == queries[-1]['input_sha256']
    assert pin(path / 'native/output.bin')['sha256'] == queries[-1]['output_sha256']
    qs = collections.Counter(q['result']['status'] for q in queries)
    status_total.update(qs)
    ground = t['clusters']
    gq = queries[ground['admission_query']]
    assert gq['purpose'] == 'pilot_ground_cluster_admission' and gq['request']['theory'] == t['spec']['theory']
    assert gq['request']['blocks'] == [r['definition'] for r in ground['instances']]
    assert ground['instances'] == ground['ordering_instances']
    assert len(ground['instances']) == expected_instances[index]
    assert gq['result']['status'] == ground['native_status'] == 'unknown_step_budget'
    assert gq['result']['micro_steps'] == 1000000000 and ground['binding_work'] == 20003
    assert ground['usable'] == [] and ground['registry_native_admitted'] is False
    assert ground['ordering_hints_enabled'] is True and ground['usage'] == 'CONTEXT_CHECKED_PRIMITIVE_ORDERING_ONLY'
    wr = s['word_reference_diagnostics']
    assert wr['complete'] is True and [r['id'] for r in wr['controls']] == control_ids
    assert all(r['status'] == 'PASSED' for r in wr['controls']) and wr['tiny_full_byte_pair_comparisons'] == 49
    assert s['diagnostics']['status'] == 'complete'
    assert s['diagnostics']['base_solutions'] == s['diagnostics']['marked_solutions']
    assert s['diagnostics']['global_dead_forced_generation_controls'] is s['diagnostics']['callback_identity_propagated'] is True
    for key in ['reference_check', 'word_model_check', 'marked_extension_check', 'marking_certificate_check']:
        assert t[key]['complete'] is True
    m = t['model']
    bykey = {tuple(r['key']): r for r in m['placements']}
    assert len(bykey) == len(m['placements']) == t['reference_check']['accepted_placements']
    assert len(m['word_dictionary']) == t['reference_check']['distinct_complete_words']
    assert len(m['conflicts']) == t['reference_check']['internal_conflicts']
    assert m['word_terminator'] == 256 and m['initial']['marks'] == [[[4 * (t['spec']['length'] - 1), 100], 0]]
    assert bytes.fromhex(m['word_dictionary'][0]) == canonical(t['spec']['target'])
    assert sum(len(r['keys']) for r in m['dependencies']) == t['reference_check']['dependency_memberships']
    roots = {tuple(r['point']): r['keys'] for r in m['alignments']}
    certs = t['markings']['certificates']
    assert len(certs) == t['marking_certificate_check']['certificates'] == t['marked_extension_check']['auxiliary_points'] == 12
    for ordinal, c in enumerate(certs):
        assert c['id'] == ordinal and c['trial'] == [c['auxiliary']['placement']]
        assert c['trial'][0][:2] == [0, 0] and c['exhausted_root'] == [0, 1]
        assert c['auxiliary']['point'] == [-100, ordinal] and c['auxiliary']['placement_value'] == 0 and c['auxiliary']['initial_value'] == 1
        assert [r['key'] for r in c['all_candidates']] == roots[(0, 1)]
    donors = []
    assert len(s['training']) == len(s['library']) == 3 and s['library_frozen_before_tests'] is True
    for tr, length in zip(s['training'], [3, 5, 5], strict=True):
        assert len(tr['search']['proof']) == len(tr['essential_proof']) == length
        assert tr['host_check']['accepted'] is tr['essential_host_check']['accepted'] is tr['region']['complete'] is tr['reference_check']['complete'] is True
        for field, proof in [('native_query', tr['search']['proof']), ('essential_native_query', tr['essential_proof'])]:
            q = queries[tr[field]]
            assert q['result']['status'] == 'accepted'
            assert q['request']['proof'] == proof and q['request']['theory'] == tr['spec']['theory']
            assert q['request']['target'] == tr['spec']['target'] and q['request']['blocks'] == []
        donors.append(dict(id=tr['spec']['id'], rows=length, whole_query=tr['native_query'], essential_query=tr['essential_native_query']))
    assert [a['id'] for a in t['arms']] == corpus['protocol']['arm_order'][cid] and len(t['arms']) == 6
    arms = {a['id']: a for a in t['arms']}
    arm_rows = []
    for a in t['arms']:
        aid = a['id']
        search = a['search']
        trace = search['trace']
        metrics = search['metrics']
        assert a['execution_status'] == 'SEARCH_RETURNED' and search['root_restored'] is True
        assert metrics['attempts'] == expected[index][aid]
        obs = a['ordering_observations']
        cluster = aid in ['SC', 'P01', 'P11']
        marked = aid in ['P10', 'P11']
        assert a['cluster_enabled'] is cluster and a['marking_enabled'] is marked
        assert obs['enabled'] is cluster and obs['available_instances'] == (expected_instances[index] if cluster else 0)
        assert obs['symbolic_activation_count'] is obs['realized_primitive_choice_count'] is None
        assert obs['successful_proposals'] == metrics.get('cluster_proposals', 0)
        events = collections.Counter(e['event'] for e in trace)
        row = dict(id=aid, status=search['status'], metrics=metrics, trace_event_counts=dict(events), seconds=search['seconds'], full_arm_seconds=a['timings']['full_arm_seconds'], root_restored=True, ordering_observations=obs, proof_verification_status=a['proof_verification_status'])
        if aid.startswith('P'):
            assert search['status'] == 'unknown_search_budget' and search['proof'] is None and search['placements'] == []
            assert len(search['domain_audits']) == 2 and all(r['complete'] is True for r in search['domain_audits'])
            assert events['place'] == metrics['attempts'] and events['decision'] == metrics['nodes']
            assert events['return'] == metrics.get('backtracks', 0)
            assert trace[-1] == dict(event='cutoff', attempts=metrics['attempts'])
            kinds = collections.Counter(e['kind'] for e in trace if e['event'] == 'decision')
            for kind in ['branch', 'forced', 'dead']:
                assert kinds[kind] == metrics.get(kind, 0)
            for ordinal, e in enumerate(trace):
                if e['event'] == 'decision':
                    assert e['ordinal'] == ordinal
                elif e['event'] == 'order':
                    decision = trace[e['decision']]
                    assert decision['kind'] in ['forced', 'branch']
                    assert sorted(e['alternatives']) == sorted(decision['original_alternatives'])
                elif e['event'] in ['place', 'return']:
                    order = next(r for r in trace[e['decision'] + 1:] if r['event'] == 'order' and r['decision'] == e['decision'])
                    assert e['key'] in order['alternatives']
                elif e['event'] == 'cluster_proposals':
                    assert type(e['proposals']) is list
            assert len(search['initial_auxiliary_removals']) == (12 if marked else 0)
            assert metrics['auxiliary_removed_incidences'] == 0
            if marked:
                assert [w['candidate'] for w in search['initial_auxiliary_removals']] == [c['auxiliary']['placement'] for c in certs]
            if cluster:
                assert obs['point_activated_proposal_packets'] == metrics.get('cluster_hints', 0)
                assert obs['successful_proposals'] == metrics.get('cluster_proposals', 0) == (0 if index == 1 else 2)
            else:
                assert obs['point_activated_proposal_packets'] is None
            row['completed_audits'] = search['domain_audits']
            row['initial_auxiliary_witnesses'] = len(search['initial_auxiliary_removals'])
            point_total += metrics['attempts']
            audit_total += 2
        else:
            assert events['extend'] == metrics['attempts']
            assert events['decision'] == metrics['nodes'] - (1 if search['proof'] is not None else 0)
            assert events['return'] == metrics.get('backtracks', 0) + (14 if search['proof'] is not None else 0)
            path_commands = []
            proposals = changes = 0
            for e in trace:
                if e['event'] == 'decision':
                    assert e['row'] == len(path_commands)
                    assert sorted(e['ordered_candidates']) == sorted(e['original_candidates'])
                    changes += e['ordered_candidates'] != e['original_candidates']
                    for p in e['proposals']:
                        assert p['instance'] in {r['id'] for r in ground['instances']}
                        assert p['prefix_rows'] == len(path_commands)
                        assert p['checked_primitive_proof'] == path_commands + p['commands']
                        assert p['result_formula'] not in [c['formula'] for c in path_commands]
                        assert p['host_check']['accepted'] is True
                        assert p['host_check']['rows'] == len(p['checked_primitive_proof'])
                        assert p['host_check']['target'] == p['result_formula'] == p['commands'][-1]['formula']
                        assert any(m['domains'][e['row']][k] == p['commands'][0] for k, v in e['original_candidates'])
                    proposals += len(e['proposals'])
                elif e['event'] == 'extend':
                    dec = trace[e['decision']]
                    assert [e['skeleton'], e['variant']] in dec['ordered_candidates']
                    path_commands.append(m['domains'][dec['row']][e['skeleton']])
                elif e['event'] == 'return':
                    assert len(path_commands) == trace[e['decision']]['row'] + 1
                    path_commands.pop()
            assert proposals == metrics.get('cluster_proposals', 0)
            assert proposals == (expected_proposals[index] if aid == 'SC' else 0)
            assert changes == (expected_order_changes[index] if aid == 'SC' else 0)
            row['passive_trace_successful_proposal_packets'] = proposals
            row['passive_trace_decisions_with_changed_order'] = changes
            row['passive_trace_metric_scope'] = 'Literal saved decision-array comparisons; not realized primitive-choice or completed-cluster counts.'
            proposal_total += proposals
            changed_order_total += changes
        if index == 0 and aid in ['S0', 'SC']:
            assert a['native_proof_accepted'] is a['host_check']['accepted'] is a['region']['complete'] is True
            assert len(search['proof']) == 14 and len(search['placements']) == 28
            q = queries[a['native_query']]
            assert q['result']['status'] == 'accepted' and q['purpose'] == 'pilot_test_' + cid + '_' + aid
            assert q['request']['proof'] == search['proof'] and q['request']['theory'] == t['spec']['theory']
            assert q['request']['target'] == t['spec']['target'] and q['request']['blocks'] == []
            for key in search['placements']:
                item = bykey[tuple(key)]
                slot, k = item['command_reference']
                assert m['domains'][slot][k] == search['proof'][slot]
            prior = read(OLD / 'actual' / cid / 'result.json')
            prior_proof = next(x['search']['proof'] for x in prior['scientific_result']['tests'][0]['arms'] if x['id'] == 'S0')
            assert search['proof'] == prior_proof
            row['checker_accepted_primitive_certificate'] = dict(whole_job_admitted=admitted, arm=aid, rows=14, selected_placements=28, Native_query=q['id'], Native_status='accepted', rules=dict(collections.Counter(c['rule'] for c in search['proof'])), repeated_D13_and_earlier_known_S0_certificate=True, novel_theorem=False, GCTS_point_proof=False)
        else:
            assert search['proof'] is None and search['status'] == 'unknown_search_budget'
        arm_rows.append(row)
    for bare, marked in [('P00', 'P10'), ('P01', 'P11')]:
        b = arms[bare]['search']['domain_audits']
        a = arms[marked]['search']['domain_audits']
        assert b[0]['incidences'] - a[0]['incidences'] == 12 and b[0]['decision'] == a[0]['decision']
        assert b[1] == a[1]
    assert arms['P00']['search']['domain_audits'] == arms['P01']['search']['domain_audits']
    assert arms['P10']['search']['domain_audits'] == arms['P11']['search']['domain_audits']
    control = record['independent_external_controls']
    assert control['supplied_to_proof_search'] is False
    assert all(control['base']['premise_truths']) and control['base']['goal_truth'] is False
    files = sorted(p for folder in [path, observer_path.parent] for p in folder.rglob('*') if p.is_file())
    assert not any('.partial' in p.name for p in files) and len(files) == 14
    actual_pins.extend(pin(p) for p in files)
    observations.append(dict(case_id=cid, resource_admitted=admitted, packet=rp, whole_peak_bytes=observer['conservative_whole_peak_bytes'], observer_gate_seconds=observer['final_observer_gate_seconds'], plan=pin(plan_path), grant=pin(grant_path), consumed=pin(path/'CONSUMED.json'), Native_queries=len(queries), Native_status_counts=dict(qs), donors=donors, library_family_ids=[r['id'] for r in s['library']], registry_native_admitted=False, registry_status=ground['native_status'], registry_usable=0, ordering_instances=len(ground['ordering_instances']), registry_binding_work=ground['binding_work'], scientific_complete=True, word_reference_controls=48, full_shared_setup_seconds=t['full_shared_setup_seconds'], compile_and_model_seconds=t['compile_and_model_seconds'], arms=arm_rows))

assert point_total == 558 and audit_total == 24 and proposal_total == 8 and changed_order_total == 2
assert len(actual_pins) == 42 and dict(status_total) == dict(accepted=76, rejected=209, unknown_step_budget=3)
assert len({r['sha256'] for r in grant_pins}) == 3
old_review_path = OLD / 'review-C/typed-point-novelty-actual-scientific-review-v1.json'
old_review = read(old_review_path)
assert pin(old_review_path)['sha256'] == '587a51a589146e84d96fddeb5542750303b09e6fef8cb686a5f2aa8a0b3b73c8'
for row in old_review['actual_file_pins']:
    verify(row)
first = read(D/'actual'/cases[0]/'result.json')['scientific_result']['tests'][0]
first_arms = {a['id']: a for a in first['arms']}
base = first_arms['S0']['search']
guided = first_arms['SC']['search']
assert base['proof'] == guided['proof'] and base['placements'] == guided['placements']
base_decisions = [e for e in base['trace'] if e['event'] == 'decision']
guided_decisions = [e for e in guided['trace'] if e['event'] == 'decision']
assert len(base_decisions) == len(guided_decisions) == 14
assert [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in base_decisions] == [(e['row'], e['original_candidates'], e['ordered_candidates']) for e in guided_decisions]
assert [{k:v for k,v in e.items() if k != 'proposals'} for e in base['trace']] == [{k:v for k,v in e.items() if k != 'proposals'} for e in guided['trace']]
assert base['metrics']['attempts'] == guided['metrics']['attempts'] == 14
assert base['metrics']['skeleton_tests'] == guided['metrics']['skeleton_tests'] == 47209
assert all(p['result_formula'] not in [c['formula'] for c in p['checked_primitive_proof'][:p['prefix_rows']]] for e in guided_decisions for p in e['proposals'])
expected_results = [('55b8eddfb187b635257a7bb4b1af2fd64d17a5e56bf31f6a8d912c8e49e9e46d',31677127),('ed31033ed91efa8356f77e78ea9078a7f93dc821722c52785e93f212d6dc5a9e',31232453),('011d153f5a15c8bfc9ef3fdafd96b2c0550ed2cf15ceaf69ed2edf4a24d09bbd',31620390)]
for row, expected_result in zip(observations, expected_results, strict=True):
    assert (row['packet']['sha256'], row['packet']['bytes']) == expected_result
C_source_path = D/'review-C/typed-graph-sharing-Source-review-v1.json'
C_whole_path = D/'review-C/typed-graph-sharing-whole-prospective-Source-review-v1.json'
assert pin(C_source_path)['sha256'] == 'b1c3cf8e2625b2a4d094d37658b29a6181e77b121fb03b31505e6950d68e1c35'
assert pin(C_whole_path)['sha256'] == '4e839424ea85693bdddc9b3ec13b4d7afeb7ee5b63c7ccb47cc4886331ad8f57'
assert read(C_source_path)['review_passed'] is read(C_whole_path)['review_passed'] is True
assert read(C_whole_path)['whole_offer'] == pin(offer_path)

def saved_prefix(model, selected):
    roles = {(k[0],k[1]):k for k in selected}
    prefix = []
    for row in range(len(model['domains'])):
        if (row,0) not in roles or (row,1) not in roles:
            break
        a = model['domains'][row][roles[row,0][2]]
        b = model['domains'][row][roles[row,1][2]]
        if a != b:
            break
        prefix.append(a)
    return prefix

point_packet_observations = []
tier_order_observations = []
for index,cid in enumerate(cases):
    record = read(D/'actual'/cid/'result.json')
    t = record['scientific_result']['tests'][0]
    m = t['model']
    keyed = {tuple(p['key']):p for p in m['placements']}
    for a in t['arms']:
        if a['method'] != 'point':
            continue
        selected = []
        packets = []
        orders = forced = branch = 0
        for ordinal,e in enumerate(a['search']['trace']):
            if e['event'] == 'cluster_proposals':
                prefix = saved_prefix(m,selected)
                for p in e['proposals']:
                    assert p['prefix_rows'] == len(prefix)
                    assert p['checked_primitive_proof'] == prefix+p['commands']
                    assert p['host_check']['accepted'] is True
                    assert p['host_check']['rows'] == len(p['checked_primitive_proof'])
                    assert p['host_check']['target'] == p['result_formula'] == p['commands'][-1]['formula']
                    assert p['result_formula'] not in [c['formula'] for c in prefix]
                    assert p['instance'] in {r['id'] for r in t['clusters']['ordering_instances']}
                    assert len(p['members']) == 2*len(p['commands'])
                    assert p['pending'] == [k for k in p['members'] if k not in selected]
                    for offset,command in enumerate(p['commands']):
                        command_key,guard_key = p['members'][2*offset:2*offset+2]
                        assert command_key[:2] == [len(prefix)+offset,0]
                        assert guard_key[:2] == [len(prefix)+offset,1]
                        for key in [command_key,guard_key]:
                            owned = keyed[tuple(key)]
                            row,k = owned['command_reference']
                            assert m['domains'][row][k] == command
                    packets.append(dict(packet_trace_index=ordinal,packet=p,all_members_selected_at=None,prefix_after=None))
            elif e['event'] == 'order':
                decision = a['search']['trace'][e['decision']]
                keys = decision['original_alternatives']
                assert all(k in keys for k in e['preferred'])
                if decision['kind'] == 'forced':
                    assert e['alternatives'] == keys
                    forced += 1
                else:
                    assert decision['kind'] == 'branch'
                    formulas = [c['formula'] for c in saved_prefix(m,selected)]
                    bins = [[],[],[],[]]
                    for key in keys:
                        row,k = keyed[tuple(key)]['command_reference']
                        formula = m['domains'][row][k]['formula']
                        repeated = formula in formulas
                        tier = (2 if repeated else 0)+(0 if key in e['preferred'] else 1)
                        bins[tier].append(key)
                    assert e['alternatives'] == [k for group in bins for k in group]
                    branch += 1
                orders += 1
            elif e['event'] == 'place':
                selected.append(e['key'])
                for owned in packets:
                    p = owned['packet']
                    if owned['all_members_selected_at'] is None and all(k in selected for k in p['members']):
                        prefix = saved_prefix(m,selected)
                        assert prefix[:p['prefix_rows']+len(p['commands'])] == p['checked_primitive_proof']
                        owned['all_members_selected_at'] = ordinal
                        owned['prefix_after'] = len(prefix)
            elif e['event'] == 'return':
                assert selected.pop() == e['key']
        assert sum(len(e['proposals']) for e in a['search']['trace'] if e['event']=='cluster_proposals') == a['search']['metrics'].get('cluster_proposals',0)
        assert len(packets) == a['search']['metrics'].get('cluster_hints',0)
        tier_order_observations.append(dict(case_id=cid,arm=a['id'],resource_admitted=True,recorded_orders=orders,forced_orders_unchanged=forced,branch_orders_exact_stable_four_tiers=branch))
        for owned in packets:
            p = owned['packet']
            assert owned['all_members_selected_at'] is not None
            point_packet_observations.append(dict(case_id=cid,arm=a['id'],resource_admitted=True,packet_trace_index=owned['packet_trace_index'],instance=p['instance'],prefix_rows_before=p['prefix_rows'],expanded_primitive_commands=len(p['commands']),members=p['members'],pending=p['pending'],Host_receipt=p['host_check'],result_formula=p['result_formula'],all_members_selected_at=owned['all_members_selected_at'],prefix_rows_after=owned['prefix_after'],interpretation='Literal member co-occurrence and agreeing paired-prefix growth on this recorded branch; not a complete recipient theorem, benefit metric or activation=execution assumption.'))
assert len(point_packet_observations) == 8
assert sum(p['resource_admitted'] for p in point_packet_observations) == 8
assert all((p['prefix_rows_before'],p['prefix_rows_after']) in [(4,5),(6,7)] for p in point_packet_observations)
admitted_cases = [c for c in observations if c['resource_admitted']]
rejected_cases = [c for c in observations if not c['resource_admitted']]
assert len(admitted_cases) == 3 and not rejected_cases
admitted_point = sum(a['metrics']['attempts'] for c in admitted_cases for a in c['arms'] if a['id'].startswith('P'))
assert admitted_point == 558

# These joins inspect complete returned ordinary data only. They do not call
# the literal reference, State, Graph, legality, scheduler or fixture runners.
graph_bank_path = D/'verification-L/control-bank-v1.json'
graph_bank = read(graph_bank_path)
graph_control_joins = []
all_graph_receipts = []
graph_copy_events = graph_domain_aliases = graph_edge_aliases = 0
graph_normal_snapshots = graph_sentinel_diagnostics = graph_corruption_diagnostics = 0
for cid in cases:
    saved = read(D/'actual'/cid/'result.json')['scientific_result']['graph_storage_diagnostics']
    assert saved['schema'] == 'literal-graph-copy-reference-controls-v1'
    assert saved['complete'] is True and saved['status'] == 'PASSED'
    assert saved['control_count'] == len(saved['controls']) == 22 and saved['fixture_count'] == 10
    assert saved['fixtures'] == graph_bank['fixtures']
    assert [c['id'] for c in saved['controls']] == [c['id'] for c in graph_bank['controls']]
    assert type(saved['control_checkpoints']) is int and saved['control_checkpoints'] > 0
    case_controls = []; copies_count = domains_shared = edges_shared = 0
    for source, returned in zip(graph_bank['controls'],saved['controls'],strict=True):
        assert returned['id'] == source['id'] and returned['fixture'] == source['fixture']
        assert returned['status'] == 'PASSED' and returned['complete'] is True
        snapshots = returned['snapshots']
        assert snapshots and len({canonical(v) for v in snapshots}) == len(snapshots)
        for snapshot in snapshots:
            assert set(snapshot) == {'state','graph','decision'}
            state = snapshot['state']; graph = snapshot['graph']; decision = snapshot['decision']
            assert set(state) == {'totals','marks','generations','roots','selected','order','tile_generations','allowed_points'}
            assert sorted(state['order']) == state['selected'] and len(state['order']) == len(state['tile_generations'])
            assert len({tuple(k) for k in state['order']}) == len(state['order'])
            assert set(graph) == {'domains','edges'}
            domains = {tuple(p):ks for p,ks in graph['domains']}
            edges = {tuple(k):ps for k,ps in graph['edges']}
            assert len(domains) == len(graph['domains']) and len(edges) == len(graph['edges'])
            forward_pairs = {(tuple(p),tuple(k)) for p,keys in graph['domains'] for k in keys}
            reverse_pairs = {(tuple(p),tuple(k)) for k,points in graph['edges'] for p in points}
            assert forward_pairs == reverse_pairs
            assert len(forward_pairs) == sum(len(ks) for ks in domains.values()) == sum(len(ps) for ps in edges.values())
            assert len(decision) == 3
            if decision[0] == 'empty':
                assert decision == ['empty',None,[]] and not domains
            else:
                assert tuple(decision[1]) in domains
                assert sorted(decision[2]) == sorted(domains[tuple(decision[1])])
                assert (decision[0] != 'dead' or not decision[2]) and (decision[0] != 'forced' or len(decision[2]) == 1)
        references = returned['initial_nodes']
        assert set(references) == {'r'}
        used = set(references.values())
        if 'initial_anchor' in source:
            assert snapshots[references['r']]['decision'] == source['initial_anchor']
        assert len(returned['events']) == len(source['actions']) + int('corruption' in source)
        faults = 0; local_copy_events = 0; parent_checks = 0
        for action,event in zip(source['actions'],returned['events'],strict=False):
            assert event['action'] == action
            op,name = action[:2]
            after = event['full_reference_equal_nodes']
            assert all(type(v) is int and 0 <= v < len(snapshots) for v in after.values())
            used.update(after.values())
            previous_nodes = set(references)
            if op == 'copy':
                destination = action[2]
                assert destination not in references and set(after) == previous_nodes | {destination}
                assert after[destination] == references[name]
                observed = event['observed_shared_nested_sets']
                prior_graph = snapshots[references[name]]['graph']
                assert observed == dict(domains=len(prior_graph['domains']),edges=len(prior_graph['edges']))
                assert all(type(v) is int for v in observed.values())
                domains_shared += observed['domains']; edges_shared += observed['edges']
                copies_count += 1; local_copy_events += 1
                unchanged = previous_nodes
            elif op == 'fault-update':
                assert set(after) == previous_nodes - {name}
                assert event['expected_callback_identity_propagated'] is True
                assert event['faulted_child_not_resumed_or_admitted'] is True
                diag = event['faulted_child_diagnostic_only']
                assert diag['graph_complete'] is False and set(diag) == {'state','graph','graph_complete'}
                assert diag['state']['order'][-1] == action[2]
                faults += 1
                unchanged = previous_nodes - {name}
            else:
                assert op in ['place','update','boundary-mark'] and set(after) == previous_nodes
                unchanged = previous_nodes - {name}
                if op == 'update':
                    assert after[name] == references[name]
                elif op == 'boundary-mark':
                    assert event['declared_alternative_boundary_marks'] == snapshots[after[name]]['state']['marks']
                    assert snapshots[after[name]]['state']['order'] == []
            for other in unchanged:
                assert references[other] == after[other]
                parent_checks += 1
            references = after
        if 'final_anchor' in source:
            assert snapshots[references['left']]['decision'] == source['final_anchor']
        if 'corruption' in source:
            assert returned['events'][-1] == dict(deliberate_fresh_graph_corruption_detected=source['corruption'],invalid_graph_not_admitted=True)
            graph_corruption_diagnostics += 1
        assert used == set(range(len(snapshots)))
        graph_normal_snapshots += len(snapshots); graph_sentinel_diagnostics += faults
        case_controls.append(dict(id=source['id'],fixture=source['fixture'],snapshots=len(snapshots),events=len(returned['events']),copy_events=local_copy_events,unaffected_node_literal_equalities=parent_checks,faulted_children_diagnostic_only=faults,corruption_expected='corruption' in source))
    graph_copy_events += copies_count; graph_domain_aliases += domains_shared; graph_edge_aliases += edges_shared
    graph_control_joins.append(dict(case_id=cid,resource_admitted=True,controls=22,fixtures=10,completed_local_tick_count=saved['control_checkpoints'],copy_events=copies_count,observed_borrowed_domain_set_occurrences=domains_shared,observed_borrowed_edge_set_occurrences=edges_shared,control_rows=case_controls,scope='Literal returned snapshot/reference/incidence/isolation joins and Source-backed actual assertions. No fixture legality/reference/scheduler replay. Sharing counts are repeated set-reference observations, not unique retained bytes or RSS gains. Local ticks are not all Root callbacks.'))
    all_graph_receipts.append(saved)
assert all_graph_receipts[0] == all_graph_receipts[1] == all_graph_receipts[2]
assert graph_sentinel_diagnostics == 9 and graph_corruption_diagnostics == 6
assert graph_copy_events == 3*sum(a[0]=='copy' for c in graph_bank['controls'] for a in c['actions'])
assert graph_domain_aliases > 0 and graph_edge_aliases > 0
for c,g in zip(observations,graph_control_joins,strict=True):
    assert c['case_id'] == g['case_id']
    c['graph_storage_controls'] = 22
    c['graph_storage_control_literal_join'] = g

# Revalidate complete copy composition and the separately frozen reviews after
# the actuals. No prior failed packet is promoted or used as a current result.
baseline_path = D/'root/baseline-copy-pins-v1.json'
baseline = read(baseline_path)
assert len(baseline['files']) == 33 and baseline['unchanged_predecessor'] == 31
for row in baseline['files']:
    verify(row['source']); verify(row['target'])
    assert Path(row['source']['path']).read_bytes() == Path(row['target']['path']).read_bytes()
initial_join_path = D/'root/initial-passive-actual-join-v1.json'
initial_join = read(initial_join_path)
assert initial_join['all_three_terminal'] is initial_join['all_three_resource_accepted'] is True
assert initial_join['remaining_once_grants'] == 0
for literal_case, observed in zip(initial_join['cases'],observations,strict=True):
    assert literal_case['case_id'] == observed['case_id']
    assert literal_case['result'] == observed['packet']
    assert literal_case['whole_peak_bytes'] == observed['whole_peak_bytes']
    assert literal_case['new_storage_controls'] == 22 and literal_case['word_controls'] == 48
    assert literal_case['native_queries'] == observed['Native_queries']
resource_path = D/'verification-L/typed-graph-sharing-resource-custody-review-v1.json'
resource = read(resource_path)
assert pin(resource_path)['sha256'] == '859c52d80909d7f899b11839417ff97123fb56f00a71a2ad12bfcf84c4dceda0'
assert resource['review_passed'] is True and all(c['passed'] for c in resource['checks'])
assert len(point_packet_observations) == 8 and all(p['resource_admitted'] for p in point_packet_observations)
distinct_local_formulas = []
for packet in point_packet_observations:
    if packet['result_formula'] not in distinct_local_formulas:
        distinct_local_formulas.append(packet['result_formula'])
    assert packet['all_members_selected_at'] is not None
    assert packet['prefix_rows_after'] == packet['prefix_rows_before'] + packet['expanded_primitive_commands']
assert sum(p['case_id']==cases[0] for p in point_packet_observations)==4
assert sum(p['case_id']==cases[2] for p in point_packet_observations)==4
assert all(p['case_id']!=cases[1] for p in point_packet_observations)
assert all(c['resource_admitted'] for c in observations)
assert old_review['resource_rejected_case_ids'] == cases[:2] and old_review['resource_admitted_case_ids'] == cases[2:]
assert old_review['admitted_recipient_proofs'] == 0

checks = [
 ('complete-actuals-source-and-native-joins','All53 Source closure pins,33 copy records,42 complete actual/observer bodies and three fresh consumed grants revalidated. External tool sessions2055/83879/24043 all exit0 and match complete terminal/header/result records; workers/parents/Native exit0, closed/reaped. All288 Native requests/stages/canonical digests and final raw input/output tails reconcile. No scientific import/call, proof replay or partial content.'),
 ('all-three-whole-jobs-admitted','Conservative whole peaks889,241,600 /966,164,480 /939,376,640B pass unchanged1GiB; complete output/custody/observer gates and separate L resource review agree. All18 searches/no skips,558point placements24audits144word-control executions and66Graph-control executions qualify. This admits the bounded comparison record, not all target theorems or a performance advantage.'),
 ('new-full-graph-control-receipts','All22 authored controls/10fixtures match complete returned receipts in each of three jobs. Every normal full State/domain/reverse-incidence/scheduler snapshot, exact table reference, initial/final anchor and per-action unaffected-node identity-by-value join checked. All domain-edge reciprocal pairs agree. Observed nested sharing matches every returned copy domain/edge count. Nine exact sentinel diagnostics and six fresh corruption refusals remain explicitly unadmitted child/invalid-graph observations. No fixture or Graph oracle is replayed by this audit;66 executions are22 distinct controls repeated3times.'),
 ('same-model-marking-scheduler-and-rollback','Full original model/word dictionary/domain/dependency and marked-extension receipts join saved data; all48word controls per job qualify. Initial marked/unmarked first audits differ by12certified incidences at the same decision, paired second audits match; all36certificates are shallow first-row support exhaustion. All24 initial full-domain audits, saved return/placement/cutoff counters and root-restored flags reconcile. No extra during-placement auxiliary elimination or per-node Graph replay claimed.'),
 ('actual-common-order-and-packet-members','Every saved point forced order is unchanged and every branch order is the exact stable four-tier permutation of the recorded full alternatives using its actual selected-key prefix. Eight qualified P01/P11 packets join actual prefixes, accepted Host receipts, original command/guard keys and pending members. All members later coexist with agreeing paired-prefix growth4to5 or6to7. This is stronger than nomination/activation but only local branch progress, not a Native target certificate, new inference, useful abstraction or measured advantage.'),
 ('donors-native-registry-and-certificates','Cold3/5/5donors and full/essential Native accepted queries recur in every case:18accepted acquisition requests. Registry queries remain unknown_step_budget at1e9, unadmitted/usable[] with7/11/7 ordering instances; no block rules supplied to final proofs. First S0 and SC14row Host/region/final Native blocks=[] certificates both qualify and have identical proof/placements/candidate orders/path, with14extensions and0SC order changes. Two certificate occurrences represent one already known recipient statement, not two/new theorems or a point-search proof.'),
 ('bounded-outcomes-and-cost-limits','Equality and missing-premise S0/SC exhaust600attempt budgets; all12 point searches UNKNOWN under the original cooperative2s clocks. SC packets4/0/4 and changed order decisions0/0/2 persist. All full cold setup/control/Native/model/marking/output/custody costs remain included. Finite timed prefixes differ and can overshoot checkpoint deadlines; more placements, admitted memory or sharing-reference counts do not establish causal allocation savings/statistical speedup/GCTS or trainedRL benefit.'),
 ('immutable-history-and-honest-scope','All42 D13 raw actual pins remain unchanged: its two whole-memory failures remain failed and its negative-only qualification is not rescued. Current Source/copy/gate evidence is a fresh experiment. Aligned word/point reduction scope, nonhostile sequential/nonreentrant Graph borrowing API, finite controls and actual proof gates remain distinct from generic COW safety, full physical Wang/VM proof-system completion and unbounded theorem/tiling research. No new run or grant authorized.')
]
review = dict(schema='typed-graph-sharing-actual-scientific-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_PASSIVE_COMPLETE_THREE_CASE_RECORD_WITH_ONE_KNOWN_RECIPIENT_STATEMENT_NO_POINT_TARGET_PROOF',passive_complete_saved_data_only=True,scientific_calls=0,logical_replays=0,fixtures_replayed=0,actual_execution_authorized=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],resource_admitted_case_ids=cases,resource_rejected_case_ids=[],complete_pilot_comparison=True,comparison_scope='All18 bounded arm records across three whole-resource-admitted cold cases. UNKNOWN is an outcome, not a theorem or nonprovability certificate.',observed_totals=dict(searches=18,skips=0,point_placements=558,point_domain_audits=24,word_controls=144,graph_control_executions=66,distinct_graph_controls=22,Native_queries=288,Native_status_counts=dict(status_total),donor_whole_essential_acceptances=18,checker_accepted_recipient_certificate_occurrences=2,symbolic_successful_packets=8,symbolic_changed_order_decisions=2,point_successful_packets=8,point_activated_packets=8,point_packets_with_all_members_cooccurring=8),admitted_totals=dict(searches=18,skips=0,point_placements=558,point_domain_audits=24,word_controls=144,graph_control_executions=66,Native_queries=288,Native_status_counts=dict(status_total),donor_whole_essential_acceptances=18,recipient_certificate_occurrences=2,distinct_recipient_statements=1,symbolic_successful_packets=8,symbolic_changed_order_decisions=2,point_successful_packets=8,point_activated_packets=8),admitted_recipient_proofs=2,admitted_recipient_certificate_occurrences=2,admitted_distinct_recipient_statements=1,GCTS_point_proofs_admitted=0,novel_mathematical_theorem=False,GCTS_or_RL_advantage_established=False,point_tier_order_literal_joins=tier_order_observations,point_packet_member_literal_joins=point_packet_observations,distinct_local_result_formula_ASTs=distinct_local_formulas,source_trial_legality_not_replayed=True,graph_control_literal_joins=graph_control_joins,graph_control_summary=dict(executions=66,distinct_controls=22,fixtures=10,all_three_returned_receipts_equal=True,normal_snapshot_occurrences=graph_normal_snapshots,copy_event_occurrences=graph_copy_events,borrowed_domain_set_occurrences=graph_domain_aliases,borrowed_edge_set_occurrences=graph_edge_aliases,expected_sentinel_diagnostics=graph_sentinel_diagnostics,expected_corruption_refusals=graph_corruption_diagnostics,tick_scope='Completed local tick calls only; direct entry/exit or failed callbacks excluded. Root counts authoritative.',sharing_scope='Observed repeated nested-set identity/reference occurrences in tiny actual controls. Not unique objects/bytes, saved physical allocations, lower active peak or a causal RSS profile.'),cases=observations,complete_input_pins=offer['files'],actual_file_pins=actual_pins,grant_pins=grant_pins,whole_offer=pin(offer_path),protocol=offer['protocol'],scientific_Source_review=pin(C_source_path),whole_Source_review=pin(C_whole_path),copy_manifest=pin(baseline_path),graph_control_bank=pin(graph_bank_path),independent_resource_review=pin(resource_path),external_tool_observer=pin(external_path),Root_initial_passive_join=pin(initial_join_path),D13_historical_review=pin(old_review_path),partial_policy='No partial contents opened/projected/admitted; all earlier whole-job rejections remain unchanged.',remaining='No point target proof, useful cluster acceleration, trainedRL, generic Graph API qualification, physical universal proof system or broader research goal completion established.',tools_stopped=True)
target = D/'review-C/typed-graph-sharing-actual-scientific-review-v1.json'
with target.open('x')as stream:
    json.dump(review,stream,indent=2,ensure_ascii=False);stream.write('\n')
print(json.dumps(pin(target),indent=2))
