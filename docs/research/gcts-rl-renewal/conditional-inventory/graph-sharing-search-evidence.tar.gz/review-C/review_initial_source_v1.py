"""Independent Source/AST and literal-bank metadata audit; no scientific calls."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import sys

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D = BASE / 'research-runs/gcts-graph-sharing-proof-pilot-20261020'
OLD = BASE / 'research-runs/gcts-point-novelty-proof-pilot-20261020'
OWN = D / 'review-C'

def pin(path):
    p = Path(path)
    assert '.partial' not in p.name
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    p = Path(path)
    assert p.suffix == '.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())

bhp = D/'implementation-B/handoff-v1.json'
lhp = D/'verification-L/handoff-v1.json'
assert pin(bhp)['sha256'] == '964adb271ed107826238847ca09f40d5165a7b04b4baf6529113b97240e981a9'
assert pin(lhp)['sha256'] == 'a61f95a10332069117257843e2f5bb251dde8296e34c37cce4af15842d950588'
bh = read(bhp); lh = read(lhp)
documents = [bhp, lhp, Path(bh['api']['path']), Path(bh['manifest']['path']),
             Path(bh['manual']['path']), Path(bh['caller_scan']['path']),
             Path(bh['ast_diff']['path']), Path(lh['api']['path']),
             Path(lh['bank']['path']), Path(lh['manual']['path']),
             Path(lh['mutation_inventory']['path']), Path(lh['static_validation']['path']),
             Path(lh['manifest']['path'])]
inputs = {}
def collect(value):
    if type(value) is dict:
        if {'path','bytes','sha256'} <= value.keys():
            row = {k:value[k] for k in ('path','bytes','sha256')}
            assert pin(row['path']) == row
            if row['path'] in inputs:
                assert inputs[row['path']] == row
            inputs[row['path']] = row
        for item in value.values():
            collect(item)
    elif type(value) is list:
        for item in value:
            collect(item)
for p in documents:
    inputs[str(p)] = pin(p)
    collect(read(p))
api = read(bh['api']['path']); lapi = read(lh['api']['path'])
bank = read(lh['bank']['path'])
assert api['graph_reference_source'] == lh['source']
assert api['graph_reference_API'] == lh['api']
assert api['graph_reference_handoff'] == pin(lhp)
assert api['graph_reference_controls'] == lh['bank']
assert api['graph_source'] == bh['graph_source'] and api['entry'] == bh['entry']
assert api['runtime_source_bindings'][0]['module'] == 'turtle'
assert api['runtime_source_bindings'][0]['source'] == bh['graph_source']
assert api['runtime_source_bindings'][1]['module'] == 'graph_copy_reference_v1'
assert api['runtime_source_bindings'][1]['source'] == lh['source']
assert 'reentrantly' in api['graph_storage_contract']['closed_caller_restrictions'][1]

gp = Path(bh['graph_source']['path']); ep = Path(bh['entry']['path']); lp = Path(lh['source']['path'])
gop = Path(bh['graph_predecessor']['path']); eop = Path(bh['entry_predecessor']['path'])
gr = gp.read_bytes(); er = ep.read_bytes(); lr = lp.read_bytes()
gor = gop.read_bytes(); eor = eop.read_bytes()
assert gr == (OWN/'initial-raw-B/graph_source_v1.py').read_bytes()
assert er == (OWN/'initial-raw-B/proof_search_pilot_v12.py').read_bytes()
assert lr == (OWN/'initial-raw-L/draft-8712a15aeb1308e3dd9b5e6a122513525e4b8ad8ed4c8f6d7d556d5f4cb0ac8c.py').read_bytes()
for a,b,patch in [(gop,gp,bh['graph_patch']), (eop,ep,bh['entry_patch'])]:
    expected = ''.join(difflib.unified_diff(a.read_text().splitlines(keepends=True),b.read_text().splitlines(keepends=True),fromfile=str(a),tofile=str(b)))
    assert expected.encode() == Path(patch['path']).read_bytes()
trees = {}
for p in [gop,gp,eop,ep,lp]:
    tree = ast.parse(p.read_bytes(),filename=str(p))
    compile(tree,str(p),'exec')
    trees[str(p)] = tree
def dump(node):
    return ast.dump(node,include_attributes=False)
go, gn = trees[str(gop)], trees[str(gp)]
gc = next(n for n in gn.body if isinstance(n,ast.ClassDef) and n.name=='Graph')
goc = next(n for n in go.body if isinstance(n,ast.ClassDef) and n.name=='Graph')
methods = {n.name:n for n in gc.body if isinstance(n,ast.FunctionDef)}
old_methods = {n.name:n for n in goc.body if isinstance(n,ast.FunctionDef)}
changed_methods = sorted(k for k in methods.keys()|old_methods.keys() if dump(methods[k]) != dump(old_methods[k]))
assert changed_methods == ['copy','update']
ginv = copy.deepcopy(gn)
gic = next(n for n in ginv.body if isinstance(n,ast.ClassDef) and n.name=='Graph')
gic.body = [copy.deepcopy(old_methods[n.name]) if isinstance(n,ast.FunctionDef) and n.name in changed_methods else n for n in gic.body]
assert dump(ginv) == dump(go)
eo, en = trees[str(eop)], trees[str(ep)]
old_defs = {n.name:n for n in eo.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
new_defs = {n.name:n for n in en.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
assert sorted(k for k in old_defs.keys()|new_defs.keys() if dump(old_defs[k]) != dump(new_defs[k])) == ['run_pilot']
einverse = copy.deepcopy(en)
added_import = [n for n in einverse.body if isinstance(n,ast.Import) and any(a.name=='graph_copy_reference_v1' and a.asname=='graph_reference' for a in n.names)]
assert len(added_import) == 1
einverse.body.remove(added_import[0])
old_version = next(n for n in eo.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets))
for i,n in enumerate(einverse.body):
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='VERSION' for t in n.targets):
        einverse.body[i] = copy.deepcopy(old_version)
run = next(n for n in einverse.body if isinstance(n,ast.FunctionDef) and n.name=='run_pilot')
target_statement = ast.parse("result['graph_storage_diagnostics'] = graph_reference.run_graph_copy_controls(modules['points'], check=check)").body[0]
matches = [i for i,n in enumerate(run.body) if dump(n)==dump(target_statement)]
assert len(matches) == 1
index = matches[0]
assert "word_reference_diagnostics" in ast.unparse(run.body[index-1])
assert isinstance(run.body[index+1],ast.For) and ast.unparse(run.body[index+1].iter)=='selected_tests'
run.body.pop(index)
assert dump(einverse) == dump(eo)
limit_node = next(n for n in en.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(limit_node.value,ast.Call) and isinstance(limit_node.value.func,ast.Name) and limit_node.value.func.id=='dict'
assert {k.arg:ast.literal_eval(k.value) for k in limit_node.value.keywords} == api['limits']
for original, current in zip(api['inherited_policy_originals'],api['policy_lineage'],strict=True):
    assert Path(original['path']).read_bytes() == Path(current['path']).read_bytes()

lt = trees[str(lp)]
literals = {}
for n in lt.body:
    if isinstance(n,ast.Assign):
        for t in n.targets:
            if isinstance(t,ast.Name) and t.id in ('FIXTURES','CONTROLS','VERSION'):
                literals[t.id] = ast.literal_eval(n.value)
    else:
        assert isinstance(n,(ast.ImportFrom,ast.FunctionDef,ast.ClassDef,ast.Expr))
fixtures = literals['FIXTURES']; controls = literals['CONTROLS']
assert bank['fixtures'] == json.loads(json.dumps(fixtures))
assert bank['controls'] == json.loads(json.dumps(controls))
assert len(fixtures)==10 and len(controls)==22
assert len({c['id'] for c in controls}) == 22
assert max(len(f['candidates']) for f in fixtures.values()) == 6
assert max(len(c['actions']) for c in controls) == 7
assert max(1+sum(a[0]=='copy' for a in c['actions']) for c in controls) == 4
assert max(sum(a[0]=='place' for a in c['actions']) for c in controls) == 4
assert max(len(row[1]) for f in fixtures.values() for row in f['candidates']) == 2
assert max(len(row[2]) for f in fixtures.values() for row in f['candidates']) == 1
assert all(c['fixture'] in fixtures for c in controls)
assert [c['id'] for c in controls if 'corruption' in c] == ['missing-inverse-edge-detected','missing-forward-member-detected']
function_arguments = {
    '_need':'Ordinary deterministic AssertionError on failed internal condition; no catch or budget translation.',
    '_plain':'Full ordinary evidence projection with genuine checks in explicit recursive loops; rejects unsupported objects/string-key violations.',
    '_point':'Strict tuple/two exact-int coordinates excludes bool.',
    '_key':'Strict singleton tuple/exact-int tiny key excludes bool.',
    '_map_rows':'Complete sorted ordinary state-map rows with strict point/value validation.',
    '_state_view':'All eight State fields projected, including selected/order/generations/allowed points; full equality to separate reference.',
    '_graph_view':'Every ordinary domain and reverse edge set projected in full with strict points/keys.',
    '_TinyModel.__init__':'Literal candidate cache and full occupancy/mark dependency index only; no theorem compiler or expected Graph result.',
    '_TinyModel.placement':'Root check precedes optional exact injected error; ordinary direct call avoids generator exception conversion.',
    '_TinyModel.alignments':'Complete literal positive-support enumeration, no Graph-derived shortlist.',
    '_records':'Validates independent fixture tuples, distinct keys/supports and exact positive integer capacity units.',
    '_allowed':'Independent literal allowed-domain/capacity/m-agreement predicate; does not call State.legal.',
    '_reference':'Independent history replay and complete original candidate census, inverse edges and global scheduler. Uses no subject Graph/model/State operation for expected values.',
    '_audit':'Full actual State and graph compared before subject decision/fingerprint; exact owned mismatch sentinel only for explicit corruption controls.',
    '_initial':'Constructs actual State from independently authored fixture; does not define expected answer from its output.',
    '_all_changed':'Notifies every fixture occupancy and marking coordinate for declared full updates.',
    '_record':'Audits every nonfaulted node and stores full ordinary snapshots once by exact equality. Faulted child is separately flagged diagnostic and skipped, not resumed/admitted.',
    'run_graph_copy_controls':'All22 controls/10 fixtures, parent/sibling/grandchild and repeated updates; complete per-action node checks. Boundary ADD control changes only independently authored empty initial context. Exact sentinel guards rethrow all foreign/Root failures. Fresh corruption controls remain unshared/unadmitted.',
    'run_graph_copy_controls.tick':'Forwards genuine Root check then counts completed local ticks; excludes direct checks/failed ticks and is not authoritative whole callback total.'
}
inventory = []
def visit(nodes,prefix=''):
    for n in nodes:
        if isinstance(n,ast.ClassDef):
            visit(n.body,prefix+n.name+'.')
        elif isinstance(n,ast.FunctionDef):
            name = prefix+n.name
            assert name in function_arguments
            inventory.append(dict(function=name,line=n.lineno,end_line=n.end_lineno,manual_finding=function_arguments[name]))
            visit(n.body,name+'.')
visit(lt.body)
assert len(inventory)==len(function_arguments)==19
for name in ['typed-graph-sharing-preparation-v1.json','preliminary-B-Source-read-v1.json']:
    inputs[str(OWN/name)] = pin(OWN/name)
for p in [BASE/'docs/basic-tiling-algorithm.md',BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md',
          OLD/'review-C/typed-point-novelty-Source-review-v1.json',OLD/'review-C/typed-point-novelty-whole-prospective-Source-review-v1.json']:
    inputs[str(p)] = pin(p)
assert inputs[str(BASE/'docs/basic-tiling-algorithm.md')]['sha256']=='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
assert inputs[str(BASE/'research-runs/gcts-batch-20261020/publisher/docs/basic-tiling-algorithm.md')]['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'

checks = [
 ('exact-frozen-composition','Both full frozen handoffs/manifests/API/manual/caller inventories and every nested pin rehashed. Baseline Graph9eefe9fd, successor67cf41b8, entry4398b96d and independent reference8712a15a match raw reviewer captures. No author Source was imported/called.'),
 ('strict-source-delta','Both raw unified diffs are exact. Independent whole-module AST inverse recovers old Graph module after replacing only Graph.copy/update; entry inverse removes only one diagnostic import/assignment and restores VERSION. Every other Graph/State/search/compiler/proof/hint/novelty/quota AST unchanged.'),
 ('closed-ownership-induction','Every copy owns distinct top dictionaries. Existing nested values are borrowed read-only; no external nested-set writes and no reentrant/concurrent Graph.copy/update during an active update. Each update treats every old domain as potentially shared and detaches once before first add/remove; fresh domains start privately owned. Induction over sequential copy/update trees preserves every other snapshot.'),
 ('completed-and-ordinary-incidences','Completed-root edge removal assigns a new difference set or deletes only a private top slot. Candidate reconciliation reads old edges, builds fresh wanted sets, detaches domain writes and assigns/deletes edges. The finite complete domain/edge values equal the baseline, including shared multi-point candidates, distant m changes, fractional residuals and boundary-context additions under complete changed-point notification.'),
 ('caller-state-and-fault-scope','All closed baseline Graph consumers inspected: search_points copies child State/Graph then updates child; parent before=g.domains and _aux_removals are read-only. Recursive descendants use further copies. State.place does not receive or mutate Graph. Existing direct probe writes target fresh unshared graphs only. Fixed model/Root callbacks have no graph-copy hook. Faulting update may leave its receiver incomplete; it never mutates borrowed ancestor/sibling sets, and is not resumed.'),
 ('independent-complete-reference','Every function in the19-function independent reference module manually audited. Expected totals/marks/generations/selected/order/allowed values and every legal literal candidate incidence are reconstructed without subject legality/Graph/model methods. Complete forward and inverse rows, scheduler and fingerprints are compared, not only decisions or hashes.'),
 ('whole22-control-bank','AST literal constants exactly match the complete frozen JSON bank:22 controls/10fixtures, at most6candidates/7actions/4live nodes/4declared placements. Covers parent after copy, siblings/grandchildren, later detach, repeated updates, completed shared edges, new frontier, distant m, explicit zero, independent boundary ADD/restore and all scheduler priorities. Synthetic generations/direct placements are helper inputs, not pilot search traces or rule-change licenses.'),
 ('negative-and-callback-controls','All three expected placement faults accept exact RuntimeError/ValueError/StopIteration identity only after genuine Root checks; every other BaseException escapes. Complete normal nodes are re-audited after faults; faulted child retained only as diagnostic. Two fresh graph corruptions must fail the full independent comparison via exact owned sentinel. No callback-bearing generator launders StopIteration.'),
 ('same-science-and-new-cost','All existing policies/corpus/primitive domains/Native UNKNOWN handling/contextual Host/full region/final Native blocks=[] gates remain unchanged by AST and exact policy pins. New controls run once after cold donor/library setup and inherited tiny+word controls, before targets; full setup/control cost remains in original case caps. Per-arm cooperative2s/600 clocks and all original numeric quotas unchanged. No new pruning/inference/cluster execution/RL.'),
 ('conditional-source-not-runtime','Manual proof and structural set-allocation counts support only this closed Source equivalence. Public sets remain mutable; arbitrary external or mid-update snapshots are unsupported. No RSS/phase/timing-prefix/fit/gain/complete theorem-search claim. All22 controls and fresh complete cohort remain unrun; fresh Root full Source/plan reviews and once grants are still required.')
]
review = dict(schema='typed-graph-sharing-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_CONDITIONAL_CLOSED_GRAPH_STORAGE_AND_INDEPENDENT_CONTROL_SOURCE_ONLY',source_only=True,scientific_calls=0,component_calls=0,subject_imports=0,fixtures_executed=0,logical_replays=0,actual_execution_authorized=False,whole_plan_reviewed=False,new_grants_authorized=0,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],input_pins=sorted(inputs.values(),key=lambda r:r['path']),B_handoff=pin(bhp),L_handoff=pin(lhp),graph_source=pin(gp),entry=pin(ep),independent_reference=pin(lp),AST_and_unused_compile_sources=[pin(p) for p in [gop,gp,eop,ep,lp]],literal_bank_counts=lh['bounds'],control_ids=[c['id'] for c in controls],reference_function_matrix=inventory,manual_theorem_scope='Conditional finite value equivalence and isolation for exact valid factory/update graphs under sequential closed read-only borrowers and no reentrant/concurrent snapshot or mutation during update. This is a manually reviewed Source argument, not a mechanized proof or executed qualification.',API_wording_caveat='API.no_registered_inference_or_RL trailing eligibility-change clause is inherited D11 policy history. It is not a D14 change: exact whole AST inverse and API.single_repair/runtime bindings establish storage-only D14 scope. No renewed inference eligibility is authorized by this review.',retained_unchanged=['full candidate universe/key multiplicity/complete t+m dependencies','global DEAD then FORCED then earliest generation with degree tie break','complete primitive alternatives and inherited common4-tier point ordering','State.copy/place and exact root restoration fingerprints','actual-context Host proposal checks and final Host/region/Native blocks=[]','cold donor acquisition/Native registry costs and all three policies','original scientific/whole-resource clocks/limits/output evidence'],unrun_obligations=['Exact Root full closure/runtime-owner/protocol and three fresh cold plans','Independent whole-plan/custodian reviews and idle barrier','Fresh Root once grants and all22 controls plus inherited controls inside actual','Complete case scientific and whole-resource result admission'],partial_files_parsed=False,no_author_sources_mutated=True,no_primary_index_reader_active_access=True,tools_stopped=True,python_metadata=dict(executable=sys.executable,version=sys.version,raw_pin=pin(Path(sys.executable))))
target=OWN/'typed-graph-sharing-Source-review-v1.json'
assert not target.exists()
target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(pin(target),indent=2))
