"""Independent Source/AST and complete saved-plan preflight only."""
from pathlib import Path
import ast
import hashlib
import json

BASE=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
D=BASE/'research-runs/gcts-graph-sharing-proof-pilot-20261020'
OLD=BASE/'research-runs/gcts-point-novelty-proof-pilot-20261020'
R=D/'root'
def pin(path):
    p=Path(path); assert '.partial' not in p.name
    raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(path):
    p=Path(path); assert p.suffix=='.json' and '.partial' not in p.name
    return json.loads(p.read_bytes())
def verify(row):
    assert pin(row['path'])==row
def same_content(a,b):
    verify(a);verify(b)
    return (a['sha256'],a['bytes'])==(b['sha256'],b['bytes']) and Path(a['path']).read_bytes()==Path(b['path']).read_bytes()

offer_path=R/'prospective-whole-offer-v1.json'
offer=read(offer_path)
assert pin(offer_path)==dict(path=str(offer_path),bytes=26928,sha256='da780c67930d4e99fa823410d85e1d141a79328f2332b61c429c5762cd0ba725')
assert offer['closure_count']==len(offer['files'])==len({r['path'] for r in offer['files']})==53
assert len(offer['plans'])==3 and offer['expected_case_jobs']==3 and offer['expected_explicit_arm_outcomes']==18
for row in offer['files']+offer['plans']+[offer['protocol']]+offer['normative_references']+offer['initial_Source_reviews']:
    verify(row)
for field in ['scientific_calls','new_actuals','new_grants','old_grants_remaining']:
    assert offer[field]==0
protocol=read(offer['protocol']['path'])
old_protocol=read(OLD/'root/protocol-v1.json')
api_path=D/'implementation-B/API-v1.json';api=read(api_path)
bh=read(D/'implementation-B/handoff-v1.json')
lh=read(D/'verification-L/handoff-v1.json')
parent=read(offer['ordering_policy']['path'])
assert protocol['limits']==old_protocol['limits']
assert protocol['scientific_limits']==old_protocol['scientific_limits']==api['limits']
assert protocol['explicit_override']==old_protocol['explicit_override']==parent['explicit_override']
assert protocol['input']==old_protocol['input']==api['corpus']==parent['logical_corpus']
assert protocol['superseded_acquisition']==old_protocol['superseded_acquisition']==parent['superseded_acquisition_document']
assert parent['registry']['native_registry_required_for_ordering'] is False
assert [r['sha256']for r in offer['normative_references']]==['c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9','ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4']
assert protocol['normative_references']==offer['normative_references']
for field,api_key in [('ordering_policy','policy'),('abstention_policy','abstention_policy'),('point_ordering_policy','point_ordering_policy')]:
    assert offer[field]==api[api_key]
    assert same_content(protocol[field],offer[field])
    assert same_content(offer[field],old_protocol[field])
assert protocol['graph_source']==bh['graph_source']==api['graph_source']
assert protocol['graph_predecessor']==bh['graph_predecessor']
for key,lkey in [('graph_reference_source','source'),('graph_reference_API','api'),('graph_reference_controls','bank')]:
    assert protocol[key]==api[key]==lh[lkey]
assert protocol['graph_reference_handoff']==api['graph_reference_handoff']==pin(D/'verification-L/handoff-v1.json')
assert protocol['graph_control_bounds']==lh['bounds']
assert protocol['graph_control_bounds']['controls']==22 and protocol['graph_control_bounds']['fixtures']==10

closure_sources=[Path(r['path'])for r in offer['files']if r['path'].endswith('.py')]
sources=[Path(r['path'])for r in offer['source_AST_checks']]
assert len(closure_sources)==38 and len(sources)==len(set(sources))==36
assert set(map(str,sources))==set(map(str,closure_sources))-{api['predecessor']['path'],api['graph_predecessor']['path']}
assert all(r['AST_and_unused_compile']is True for r in offer['source_AST_checks'])
for p in closure_sources:
    tree=ast.parse(p.read_bytes(),filename=str(p));compile(tree,str(p),'exec')
names=['case_worker_v1.py','run_case_once_v3.py','observe_case_once_v2.py','independent_countermodel_v1.py']
runtime=sorted((D/'runtime').glob('*.py'))
copies=runtime+[R/name for name in names]
assert len(runtime)==29 and len(copies)==33
baseline_path=R/'baseline-copy-pins-v1.json'; baseline=read(baseline_path)
assert baseline['count']==len(baseline['files'])==33
assert baseline['unchanged_predecessor']==offer['unchanged_predecessor_copies']==31
assert baseline['changed_graph_runtime']==baseline['new_independent_control']==1
assert {r['target']['path']for r in baseline['files']}==set(map(str,copies))
assert sum(r['kind']=='UNCHANGED_PREDECESSOR'for r in baseline['files'])==31
for row in baseline['files']:
    before=Path(row['source']['path']);after=Path(row['target']['path'])
    verify(row['source']);verify(row['target']);assert before.read_bytes()==after.read_bytes()
    if row['kind']=='UNCHANGED_PREDECESSOR':
        assert before.is_relative_to(OLD) and before.relative_to(OLD)==after.relative_to(D)
    elif row['kind']=='NEW_GRAPH_STORAGE_EXACT_AUTHOR_COPY':
        assert row['source']==api['graph_source'] and after==D/'runtime/turtle.py'
    else:
        assert row['kind']=='NEW_INDEPENDENT_CONTROL_EXACT_AUTHOR_COPY'
        assert row['source']==api['graph_reference_source'] and after==D/'runtime/graph_copy_reference_v1.py'
for field in ['model_source','verifier_source']:
    assert (D/'runtime'/Path(api[field]['path']).name).read_bytes()==Path(api[field]['path']).read_bytes()
assert {p.name for p in runtime}=={p.name for p in (OLD/'runtime').glob('*.py')}|{'graph_copy_reference_v1.py'}
assert (D/'runtime/turtle.py').read_bytes()==Path(bh['graph_source']['path']).read_bytes()
assert (D/'runtime/graph_copy_reference_v1.py').read_bytes()==Path(lh['source']['path']).read_bytes()
native_rows=[r for r in offer['files']if '/recovered/and-support/'in r['path']]
assert len(native_rows)==4
expected=set(map(str,copies))|{api['entry']['path'],api['graph_source']['path'],api['graph_reference_source']['path'],api['predecessor']['path'],api['graph_predecessor']['path'],str(api_path),str(D/'implementation-B/handoff-v1.json'),protocol['superseded_acquisition']['path'],api['corpus']['path'],offer['python']['path'],api['graph_reference_API']['path'],api['graph_reference_controls']['path'],api['graph_reference_handoff']['path']}|{offer[k]['path']for k in ['ordering_policy','abstention_policy','point_ordering_policy']}|{r['path']for r in native_rows}
assert expected=={r['path']for r in offer['files']}
assert offer['python']['sha256']=='b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'

doc=read(api['corpus']['path'])
assert [t['length']for t in doc['tests']]==[14,13,14]
assert [t['length']for t in doc['training']]==[3,5,5]
actual_paths=[];plan_case_rows=[]
for row,spec in zip(offer['plans'],doc['tests'],strict=True):
    plan=read(row['path']);old_plan=read(OLD/'root'/Path(row['path']).name)
    assert plan['case_id']==spec['id'] and plan['schema']=='proof-search-case-once-plan-v1'
    assert plan['experiment']=='graph-copy-sharing-v1'
    assert plan['files']==offer['files'] and plan['protocol']==offer['protocol']
    for field in ['ordering_policy','abstention_policy','point_ordering_policy']:
        assert plan[field]==offer[field]
    assert plan['superseded_acquisition']==protocol['superseded_acquisition']
    assert plan['graph_source']==api['graph_source'] and plan['graph_reference_source']==api['graph_reference_source']
    assert plan['limits']==protocol['limits']==old_plan['limits']
    assert plan['experiment_limits']==protocol['scientific_limits']==old_plan['experiment_limits']
    assert plan['modules']==api['roles']==old_plan['modules']
    assert plan['native']==old_plan['native'] and plan['python']==offer['python']==old_plan['python']
    assert plan['input_path']==protocol['input']['path']==old_plan['input_path']
    assert plan['entry_path']==api['entry']['path'] and plan['runtime_dir']==str(D/'runtime')
    for field,name in [('worker_path',names[0]),('runner_path',names[1]),('observer_path',names[2]),('control_path',names[3])]:
        assert plan[field]==str(R/name)
    assert plan['actual_dir']==str(D/'actual'/spec['id'])
    assert not Path(plan['actual_dir']).exists() and not Path(plan['actual_dir']+'.observer').exists()
    actual_paths.append(plan['actual_dir'])
    plan_case_rows.append(dict(case_id=spec['id'],row_bound=spec['length'],arm_order=doc['protocol']['arm_order'][spec['id']],actual_dir=plan['actual_dir'],plan=row))
assert len(set(actual_paths))==3
assert not list(R.glob('grant-*.json')) and not (R/'Root-preflight-v1.json').exists()
C_path=D/'review-C/typed-graph-sharing-Source-review-v1.json'
L_path=D/'verification-L/typed-graph-sharing-Source-ABI-review-v1.json'
assert pin(C_path)['sha256']=='b1c3cf8e2625b2a4d094d37658b29a6181e77b121fb03b31505e6950d68e1c35'
assert pin(L_path)['sha256']=='df17171992cc6bc676f5b5f9fde82135b028927dea56e0aa4873c20bd544d50b'
assert offer['initial_Source_reviews']==[pin(C_path),pin(L_path)]
for p in [C_path,L_path]:
    v=read(p);assert v['review_passed']and all(c['passed']for c in v['checks'])
inherited_path=OLD/'review-C/typed-point-novelty-whole-prospective-Source-review-v1.json'
assert pin(inherited_path)['sha256']=='a11b78e3caa4a69495b55e3ac1f49f6bfb79c9c01f511a46e0e2229e5957568e'
helpers=[R/'prepare_case_plans_v1.py',R/'authorize_cases_v1.py']
for p in helpers:
    tree=ast.parse(p.read_bytes(),filename=str(p));compile(tree,str(p),'exec')
authorizer=helpers[1].read_text()
for name in [C_path.name,L_path.name,'typed-graph-sharing-whole-prospective-Source-review-v1.json','typed-graph-sharing-whole-plan-Source-ABI-review-v1.json']:
    assert name in authorizer
assert "if len(reviews)>=2:assert contains(receipt,pin(offer_path))"in authorizer
assert "assert reviews[:2]==offer['initial_Source_reviews']"in authorizer
assert "authorized=True,uses=1,no_retry=True"in authorizer
assert "plan_sha256=row['sha256']"in authorizer
assert "with Path(path).open('x')"in authorizer

checks=[
 ('complete-frozen-closure','All53 exact closure rows, three complete plans, protocol, both masters and two initial reviews rehashed. All36 listed scientific/custodian/author Sources independently AST parsed and unused compiled without import/execution; no smaller module/rule/case subset substituted.'),
 ('exact-runtime-and-custodian-composition','Exactly29 runtime modules:27 unchanged D13, reviewed Graph source67cf copied exactly as canonical turtle.py, and L8712 copied as graph_copy_reference_v1.py. All four custodians byte-identical D13;33 exact copy records/31 unchanged. Complete Native executable/template/microcode/CPP, Python, corpus, policy, author/predecessor Sources and new L bank/API/handoff are bound. No scientific helper outside declared closure.'),
 ('independent-initial-proof-and-caller-scope','C b1c3cf full B/L manual Source/19-function reference/control review and L df171719 B ownership/integration review bind exactly. Distinct topdicts, read-only shared sets, detach-before-write and fresh edge replacements preserve values under sequential closed callers. No external shared-set writes or reentrant/concurrent copy/update during update; fresh synthetic probes remain separately scoped. No generic mutable-API or mathematical proof-system soundness claim.'),
 ('new-controls-and-old-final-gates','All22 independent controls/10literal fixtures are actually called by the exact entry after cold donor/library acquisition plus inherited tiny/48word controls, before target construction. Full normal state/domain/inverse/scheduler snapshots, sibling/grandchild/repeated update and owned negative controls remain required inside each job. Existing first-two actual target audits, root restoration, complete primitive fallback, actual-context Host/trial keys and final Host/full region/Native blocks=[] gates remain unchanged.'),
 ('three-policies-and-cold-fairness','Three policy copies exactly match original bytes. Original acquisition specialization/freeze override applies only to untrusted context-checked ordering preferences; registry UNKNOWN remains unadmitted/usable[], actual Native status/cost and rejected/unrecognized/Root faults persist. Same14/13/14 targets, three cold3/5/5donors and six exact schedules; all four point arms retain common novelty tiers and unchanged Graph scheduler. No supplied route, reused library/prefix/result or altered theory.'),
 ('same-caps-and-honest-costs','Every scientific/outer limit equals D13:600/cooperative2s, Native1e9, two audits and all cluster/marking/compiler limits;160work/180positive/210custody/225fallback,1GiB,128MiB,9MiBreserve,400mcallbacks,4MiBlogs and48MiBresult. New control/setup work and sharing/detachment remain charged. No same timed prefix, phase causality, RSS bound, fit, speedup, proof/RL prediction; incomplete or whole-rejected records remain unadmitted.'),
 ('unchanged-nonhostile-custody-and-authorizers','Byte-identical worker/runner/observer retain consumed-plan join, source hashes, full complete result/header joins, bounded logs, Native close/reap and measured conservative whole process gates. Live census is non-atomic and final census follows owned-child exit. Root metadata preparation/authorizer read as Source only; four exact initial+whole review names and whole-offer joins precede three fresh once/no-retry grants. Reviewer executes neither helper and supplies no grant.'),
 ('fresh-whole-barrier-and-no-rescue','All three distinct actual/observer paths and all grant/preflight files absent at freeze. This complete prospective review does not assume the separate L whole-plan PASS, authorize execution or admit a measured result. Root still collects that receipt, verifies all tools idle and issues fresh serial grants. D13 failures and all older cohorts/grants/P bytes remain untouched; no partial content parsed, projected, completed or adopted.')
]
review=dict(schema='typed-graph-sharing-whole-prospective-Source-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_COMPLETE_SOURCE_PLAN_PREFLIGHT_SEPARATE_L_WHOLE_REVIEW_AND_ROOT_ONCE_GRANTS_REQUIRED',source_only=True,scientific_calls=0,component_calls=0,logical_replays=0,fixtures_executed=0,actual_execution_authorized=False,grant_authority=False,actual_resource_accepted=False,check_count=len(checks),failed_checks=0,checks=[dict(id=i,passed=True,finding=f)for i,f in checks],whole_offer=pin(offer_path),protocol=offer['protocol'],plans=offer['plans'],case_plan_joins=plan_case_rows,complete_input_pins=offer['files'],normative_references=offer['normative_references'],AST_unused_compile_count=36,metadata_helpers_AST_unused_compiled=2,runtime_Source_count=29,unchanged_runtime_Source_count=27,changed_graph_runtime_count=1,new_reference_runtime_count=1,unchanged_custodian_Source_count=4,exact_copy_manifest=pin(baseline_path),copy_records=33,unchanged_predecessor_copies=31,initial_scientific_C_review=pin(C_path),separate_initial_L_review=pin(L_path),inherited_D13_C_whole_review=pin(inherited_path),graph_source=api['graph_source'],graph_reference_source=api['graph_reference_source'],graph_reference_API=api['graph_reference_API'],graph_reference_handoff=api['graph_reference_handoff'],graph_reference_controls=api['graph_reference_controls'],ordering_policy=offer['ordering_policy'],abstention_policy=offer['abstention_policy'],point_ordering_policy=offer['point_ordering_policy'],superseded_acquisition=protocol['superseded_acquisition'],metadata_authors=[pin(p)for p in helpers],metadata_author_scope='Read and AST/unused compiled as Root metadata authoring only; neither helper executed and no grant issued by reviewer.',separate_D14_L_whole_review_required=True,L_whole_PASS_not_assumed=True,resource_fit='UNMEASURED',new_actuals=0,new_grants=0,old_grants_remaining=0,partial_policy='No partial content opened, parsed, projected, reconstructed or admitted.',manual_scope='Conditional complete Source/plan preflight, not a mathematical checker replay, actual Graph control qualification, general COW API theorem or performance result.',tools_stopped=True)
target=D/'review-C/typed-graph-sharing-whole-prospective-Source-review-v1.json'
with target.open('x')as stream:
    json.dump(review,stream,indent=2);stream.write('\n')
print(json.dumps(pin(target),indent=2))
