"""Administrative report/archive only; no scientific replay or project imports."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import html
import json
import zipfile

ROOT = Path(__file__).resolve().parent
STUDY = ROOT.parent
REPO = STUDY.parents[1]
P2 = STUDY.parent / 'gcts-batch-20261020/publisher-recovery-6338a77'
STAGE = ROOT / 'publication-ledger-modes-v1'
PAYLOAD = P2 / 'publication-payload-ledger-modes-v1'
PRIOR = ROOT / 'publication-frozen-target-comparison-v1'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('point-proof-parallel-progress-v1.html', 'point-proof-ledger-modes-summary-v1.json', 'point-proof-ledger-modes-evidence-v1.zip')


def raw(path):
    p = Path(path)
    assert p.is_absolute() and p.resolve() == p and p.is_file() and not p.is_symlink()
    assert '.partial' not in p.name and p.name not in ('index.html', '.gcts-active')
    return p.read_bytes()


def pin(path):
    body = raw(path)
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def write(path, body):
    with path.open('xb') as stream:
        stream.write(body)
    assert raw(path) == body


def main():
    disposition_path = ROOT / 'ledger-normal-mode-case0-Root-complete-whole-negative-disposition-v1.json'
    disposition = json.loads(raw(disposition_path))
    assert disposition['negative_disposition_complete_and_accepted'] is True
    assert all(disposition[k] is False for k in ('whole_case_admitted', 'qualification_admitted', 'proof_or_use_admitted', 'resource_qualified'))
    review_ref = disposition['complete_C_negative_review']
    assert pin(review_ref['path']) == review_ref
    review = json.loads(raw(review_ref['path']))
    assert review['review_completed'] is True and review['whole_case_admitted'] is False
    assert review['disposition'] == 'COMPLETE_WHOLE_NEGATIVE_CONTROL_ASSERTION_FAILURE_CASE_CONSUMED_NO_PREFIX_ADMISSION'
    plan = json.loads(raw(disposition['plan']['path']))
    assert pin(disposition['plan']['path']) == disposition['plan']
    assert len(plan['files']) == 71 and plan['input_authority'] == []
    auth = ROOT / 'full-evidence-archive-direct-user-publication-authorization-v1.json'
    assert json.loads(raw(auth))['direct_human_answer'] == 'Approve publishing the full archive'
    paper = STUDY / 'diagnostics-L/contextual-library-bank2-validator-mode-equality-Source-diagnosis-v1.json'
    paper_review = STUDY / 'review-C/typed-bank2-validator-timing-invariant-paper-review-and-bank3-requirements-v1.json'
    assessment = json.loads(raw(paper_review))
    assert assessment['review_passed'] is True and assessment['blockers_to_paper_recommendation'] == []
    assert assessment['subjects']['L_diagnosis'] == pin(paper)
    members, external = {}, []

    def include(path, role, expected=None):
        p = Path(path)
        body = raw(p)
        ref = dict(path=str(p), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
        if expected is not None:
            assert ref == {k: expected[k] for k in ('path', 'bytes', 'sha256')}
        if not p.is_relative_to(REPO):
            assert ref == plan['python']
            external.append(dict(**ref, supplied_separately=True))
            return
        assert not any(part in ('.git', '.aws', '.ssh') for part in p.parts)
        name = 'project/' + p.relative_to(REPO).as_posix()
        if name in members:
            assert members[name]['ref'] == ref
        else:
            members[name] = dict(role=role, ref=ref, body=body)

    for ref in plan['files']:
        include(ref['path'], 'current-case-guard', ref)
    for ref in disposition['raw_case_and_observer_files']:
        include(ref['path'], 'complete-negative-case-or-observer', ref)
    extras = [disposition_path, Path(review_ref['path']), auth, paper, paper_review,
        ROOT / 'ledger-normal-mode-case0-complete-raw-Root-passive-audit-v1.json',
        ROOT / 'ledger-normal-mode-controls-study-preparation-v1.json',
        ROOT / 'ledger-normal-mode-prospective-Root-passive-audit-v1.json',
        ROOT / 'bank3-validator-timing-comparison-Source-CONTRACT-v1.json',
        STUDY / 'review-C/typed-ledger-normal-mode-controls-complete-whole-prospective-review-v1.json',
        ROOT / 'ledger-normal-mode-controls-v1-case-0-Root-once-acceptance-v1.json',
        ROOT / 'grants/ledger-normal-mode-controls-v1-case-0.json',
        ROOT / 'publish_ledger_modes_api_v1.py', ROOT / 'verify_ledger_modes_live_v1.py', Path(__file__).resolve(),
        STUDY / 'implementation-B/ledger-modes-publication-and-verifier-Source-handoff-v1.json']
    extras.extend([ROOT/'prepare_ledger_modes_publication_v1.py',
        ROOT/'ledger-normal-mode-bank3-Root-component-acceptance-v1.json',
        STUDY/'review-C/typed-contextual-library-bank3-validator-timing-correction-complete-Source-review-v1.json',
        STUDY/'review-C/typed-bank3-validator-timing-correction-independent-static-audit-v1.json',
        STUDY/'diagnostics-L/ledger-modes-publication-and-verifier-independent-Source-review-v1.json'])
    for path in extras:
        include(path, 'explicit-current-review-authority-diagnosis-or-administration')
    # These are newly authored prospective Sources, not an executed successor.
    bank_handoff = STUDY / 'diagnostics-L/contextual-library-independent-bank-Source-handoff-v3.json'
    bank = json.loads(raw(bank_handoff))
    assert bank['status'] == 'COMPLETE_INERT_BANK3_SOURCE_OFFER_ALL_SIX_UNRUN_AWAITING_C_REVIEW'
    include(bank_handoff, 'prospective-bank3-unexecuted')
    for ref in bank['packet']:
        include(ref['path'], 'prospective-bank3-unexecuted', ref)
    pub_handoff = json.loads(raw(STUDY/'implementation-B/ledger-modes-publication-and-verifier-Source-handoff-v1.json'))
    for ref in pub_handoff['packet']:
        include(ref['path'], 'administrative-publication-Source-packet', ref)
    prior_archive = PRIOR / 'point-proof-frozen-target-comparison-evidence-v1.zip'
    assert pin(prior_archive)['bytes'] == 16000248
    assert pin(prior_archive)['sha256'] == '871e57562823ca4942a0508c07a9d7bbb68be3fcbf5c2367ddfd7c7ec5308c57'
    include(prior_archive, 'unchanged-opaque-prior-full-archive')
    catalog = dict(schema='Root-ledger-modes-evidence-catalog-v1', issued_utc=datetime.now(timezone.utc).isoformat(),
        disposition=pin(disposition_path), direct_user_archive_authorization=pin(auth),
        members=[dict(member=name, role=value['role'], **value['ref']) for name, value in sorted(members.items())],
        external_runtime=external, prior_archive=pin(prior_archive), scientific_replay=False,
        scope='Current71-guard closure except separately identified D90 Python, all10 complete owned negative files, explicit reviews/authority/Source diagnosis and unexecuted prospective bank3 packet. Prior full archive included byte-identically as opaque nested member. Not recursive closure of every historical citation. No failed prefix or new qualification/proof/use admission.')
    assert not STAGE.exists() and not PAYLOAD.exists()
    STAGE.mkdir(); PAYLOAD.mkdir()
    archive = STAGE / NAMES[2]
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, body in [('catalog.json', js(catalog))] + [(name, value['body']) for name, value in sorted(members.items())]:
            info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0)); info.external_attr = 0o100644 << 16
            bundle.writestr(info, body, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(archive) as bundle:
        assert set(bundle.namelist()) == set(members) | {'catalog.json'} and len(bundle.namelist()) == len(members) + 1
        for name, value in members.items():
            assert bundle.read(name) == value['body']
    elapsed = disposition['observed_lifecycle']['saved_observer_elapsed_seconds']
    summary = dict(schema='public-ledger-modes-qualification-outcome-v1', status='WHOLE_COMPARISON_ASSERTION_NEGATIVE',
        case_id=disposition['case_id'], qualification_admitted=False, proof_or_use_admitted=False, resource_qualified=False,
        normal_bank_retained=False, actual_group_mode_case_and_pair_statuses='WITHHELD_NO_COMPLETE_BANK_RETURN',
        declared_recipe_only=dict(groups=6, normal_searches=43, complete_dual_pairs=39),
        saved_observations=disposition['observed_lifecycle'], error=disposition['error'],
        Root_disposition=pin(disposition_path), complete_C_review=review_ref,
        Source_diagnosis=pin(paper), Source_diagnosis_review=pin(paper_review),
        archive=dict(name=NAMES[2], **{k: pin(archive)[k] for k in ('bytes', 'sha256')}, entries=len(members) + 1),
        scope='No exact actual mismatch leaf/value survived. Source proves elapsed time is not a scientific equality invariant. New bank3 Source is unexecuted. Raw failed-prefix clocks/RSS are not resource fit, speedup or comparison with historical target failures.')
    section = r'''<style>.ledger-current{border-top:6px solid #a44f38}.ledger-current .fact{color:#a44f38}.receipt-map{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin:22px 0}.receipt-map article{border:2px solid #777;border-radius:10px;padding:20px}.receipt-map article:first-child{border-color:#176b70}.receipt-map article:last-child{border-color:#a16a23}.receipt-map code{overflow-wrap:anywhere}.ledger-current .caption{font-size:14px}@media(max-width:720px){.receipt-map{grid-template-columns:1fr}}</style>
<section class="panel ledger-current" id="ledger-modes-current"><p class="status">Current outcome · finite storage qualification · 26 October 2026 UTC</p>
<h1>Storage qualification remains incomplete.</h1>
<p>The new storage representation was attempted once with the independently written test bank. The bank stopped at an assertion comparing the two modes' complete validator receipts. It returned no complete group results. The first error, all logs and the whole failed case are preserved.</p>
<div class="grid"><article class="card"><h3>New checked research proofs</h3><span class="fact">\(0\)</span><p>This was a machinery test; it produced no admitted proof or useful inventory transfer.</p></article><article class="card"><h3>Qualification outcome</h3><span class="fact">Not admitted</span><p>All six group outcomes are withheld. The declared calls are not completed-result counts.</p></article><article class="card"><h3>Saved observer time</h3><span class="fact">\(''' + f'{elapsed:.3f}' + r'''\,\mathrm{s}\)</span><p>Time to the assertion failure, not a proof time or speed comparison.</p></article></div>
<div class="notice"><strong>The test assumption was too strong.</strong> The original checker puts a fresh elapsed-time measurement in every complete receipt. Equal proof bytes do not require equal checking durations. The failed case did not retain the differing values, so this Source finding does not identify its exact differing field or rule out another discrepancy.</div>
<h2>What must agree, and what must be recorded</h2><div class="receipt-map"><article><h3>Scientific proof evidence</h3><p>Query and certificate bytes, formulas, rules, witnesses, ordered references, spans, goals and complete dependency maps must still agree. Both original validators remain required.</p><p><strong>No scientific field is removed.</strong></p></article><article><h3>Per-call cost evidence</h3><p><code>subject_receipt.cost.elapsed_seconds</code> is retained unchanged as a real measurement. The corrected prospective test excludes only that value from temporary scientific-comparison copies.</p><p>Cost callback counts and the exact cost scope still have to agree.</p></article></div>
<p class="caption">This is a diagram of the comparison contract. Colors are reader annotations, not learned GCTS markings. No actual validator payload was recovered from the failed call.</p>
<h2>What the failure establishes</h2><p>All eight module imports completed; the bank stage started and did not return. Both positive result roots are null. There is no saved bank result, candidate, query, certificate or validator image to admit. The observer and custody records are complete, and all \(71\) declared Source/runtime/metadata identities remain unchanged.</p>
<p>The recorded error was the bank's equality assertion, not a Root budget exception. The qualified whole-memory bound remains null. Raw low memory or short elapsed time from this failed prefix is not evidence of resource fit or a storage improvement.</p>
<h2>The next test keeps the same obligations</h2><p>The corrected independent test Source has passed independent Source review and remains unexecuted. Its frozen contract keeps the same six groups, \(43\) declared normal searches, \(39\) declared complete dual-validation pairs, original facets and unchanged limits. It preserves the full original receipts and checks the cost record's shape, types and scope before applying one precisely listed timer exception. The existing search-callback comparison exception remains separate.</p>
<p>A new whole caller and distinct reviewed once case are still required. This consumed failure stays negative. The consumer and original proof kernels are unchanged by this test correction. Practical proof-family transfer, geometric GCTS conformance and trained RL benefit remain unestablished.</p>
<p><a href="point-proof-ledger-modes-summary-v1.json">Exact outcome and scopes</a> · <a href="point-proof-ledger-modes-evidence-v1.zip">Full approved evidence archive</a> · <a href="#frozen-target-comparison-current">Earlier three target memory failures</a> · <a href="point-proof-discovered-proofs-v1.html">Earlier automatically found training proofs</a></p>
<p class="caption">The archive contains current Source snapshots, all ten failed-case and observer files, full independent reviews, the Source diagnosis, the unexecuted correction packet and local provenance paths under direct user approval. It nests the earlier full archive unchanged. Current D90 Python is identified separately; historical B6 runtime evidence is preserved without a matched-resource claim.</p></section>
<p class="notice"><strong>Earlier milestones below.</strong> Their dated current-status labels describe earlier checkpoints. The unqualified storage test above is the current observation.</p>'''
    baseline = raw(PRIOR / NAMES[0])
    assert len(baseline) == 90290 and hashlib.sha256(baseline).hexdigest() == '09af36f927b889aa929e1a03f248d8e53df3619c02fc19d3543a829c0ebd15aa'
    page = baseline.decode(); assert page.count('<body><main>') == 1
    page = page.replace('<body><main>', '<body><main>' + section, 1)
    page = page.replace('<title>First proof-family transfer test: three memory-limited failures</title>', '<title>Ledger storage qualification: comparison assertion and timing diagnosis</title>', 1)
    rows = []
    for name, body in zip(NAMES, (page.encode(), js(summary), raw(archive))):
        if name != NAMES[2]: write(STAGE / name, body)
        write(PAYLOAD / name, body)
        rows.append(dict(path=PREFIX + name, root_source=str(STAGE / name), publisher_source=str(PAYLOAD / name),
            bytes=len(body), sha256=hashlib.sha256(body).hexdigest(),
            git_blob_sha1=hashlib.sha1(b'blob ' + str(len(body)).encode() + b'\0' + body).hexdigest()))
    staging = dict(schema='Root-ledger-modes-three-path-staging-v1', scientific_execution=False,
        disposition=pin(disposition_path), baseline=pin(PRIOR / NAMES[0]), direct_user_archive_authorization=pin(auth),
        files=rows, archive_entries=len(members) + 1, archive_members_verified=True, external_runtime=external,
        scope='One complete unqualified case plus Source diagnosis and unexecuted correction. Exact report/summary/full archive only; sole isolated P2; no new proof, target result or fit claim.')
    write(STAGE / 'P2-staging.json', js(staging))
    print(json.dumps(pin(STAGE / 'P2-staging.json')))


if __name__ == '__main__':
    main()
