"""Package complete frozen task-owned bytes. No scientific imports or replay."""
from pathlib import Path
import hashlib,io,json,tarfile
B=Path(__file__).resolve().parent.parent;D6=B.parent/'gcts-compact-proof-pilot-20261020';D5=B.parent/'gcts-proof-search-pilot-20261020'
D=B.parent/'gcts-batch-20261020/publisher/docs/research/gcts-rl-renewal/conditional-inventory'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(file=p.name,bytes=len(b),sha256=sha(b))
paths={p for p in B.rglob('*') if p.is_file() and 'publication-C' not in p.relative_to(B).parts and p.name not in ['archive-scan-v1.json','Root-final-milestone-v1.json','next-carrier-assessment-v1.json']}
offer=json.loads((B/'root/prospective-whole-offer-v1.json').read_bytes());omitted=[]
for row in offer['files']:
 p=Path(row['path'])
 if p==Path(offer['python']['path']):omitted.append(dict(pin=row,reason='Trusted pinned isolated CPython binary not redistributed. Research Sources and fixed Native assets included.'))
 else:paths.add(p)
paths.update([D6/'implementation-B/proof_search_pilot_v4.py',D6/'review-C/typed-scientific-composition-Source-review-v1.json',D6/'verification-L/compact_reference_verifier_v1.py',D6/'verification-L/scanner-successor-and-plan-Source-review-v1.json'])
records=[];bodies=[];partials=[]
for p in sorted(paths):
 assert not p.is_symlink()
 if p.is_relative_to(B):name=p.relative_to(B).as_posix()
 elif p.is_relative_to(D6):name='dependencies/D6/'+p.relative_to(D6).as_posix()
 elif p.is_relative_to(D5):name='dependencies/D5/'+p.relative_to(D5).as_posix()
 else:raise ValueError('undeclared archive path '+str(p))
 b=p.read_bytes();record=dict(file=name,bytes=len(b),sha256=sha(b))
 if '.partial' in p.name:partials.append(record)
 else:records.append(record);bodies.append((name,b))
m=dict(schema='recipient-proof-search-evidence-archive-v1',files=records,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted,actual_jobs=3,complete_actual_and_observer_files=42,returned_searches=9,skipped_cluster_arms=9,recipient_proofs_accepted=1,recipient_discovery_engine='S0 conventional symbolic',point_placement_attempts=0,scientific_comparison_complete=False,scientific_calls_during_packaging=0,reproduction='Historical consumed grants are never reusable. Reproduction requires fresh reviewed paths/plans/once grants. External D5/D6 dependencies map to declared historical paths; all active research code is included.',scope='Complete literal evidence of this new per-arm prerequisite experiment. Old shared-stop outcomes and gates unchanged. Publication-only review and future unexecuted carrier assessment are outside this scientific snapshot.')
mb=(json.dumps(m,sort_keys=True,indent=2)+'\n').encode();archive=D/'recipient-proof-search-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for name,b in bodies+[('MANIFEST.json',mb)]:
  item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o644;item.mtime=0;tf.addfile(item,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
 assert len(tf.getmembers())==len(records)+1
 for row in records:
  b=tf.extractfile(row['file']).read();assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert tf.extractfile('MANIFEST.json').read()==mb
scan=dict(schema='recipient-archive-complete-byte-scan-v1',archive=pin(archive),members=len(records)+1,payload_bytes=sum(r['bytes'] for r in records),all_members_byte_checked=True,partial_raw_metadata_only=partials,omitted_trusted_runtime=omitted)
(B/'root/archive-scan-v1.json').write_text(json.dumps(scan,sort_keys=True,indent=2)+'\n')
owned=[p for p in sorted(D.glob('recipient-proof-search*')) if p.name!='recipient-proof-search-manifest.json']+[D/'reader.html']
public=dict(schema='recipient-proof-search-publication-manifest-v1',source_parent_commit='449218fd6c850477acea0dcb8fe935b1ea36e467',files=[pin(p) for p in owned],archive_scan=scan,conclusion='S0 automatically found one14lineHost/region/Nativeacceptedrecipientproof.9primitivecallsreturned/9clusterarmsskipped.6pointcalls cutoffinfirstauditbeforeanyplacement. No GCTS/RLgain/fullcomparison.',reader_delta=json.loads((B/'root/reader-publication-delta-v1.json').read_bytes()))
(D/'recipient-proof-search-manifest.json').write_text(json.dumps(public,sort_keys=True,indent=2)+'\n')
print(json.dumps(scan))
