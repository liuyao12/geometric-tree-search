"""Metadata and AST/unused compile only; no research module imports or calls."""
from pathlib import Path
import ast,hashlib,json,sys
B=Path(__file__).resolve().parent.parent
D6=B.parent/'gcts-compact-proof-pilot-20261020'
D5=B.parent/'gcts-proof-search-pilot-20261020'
RUNTIME=B/'runtime'
PYTHON=Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12').resolve()
NATIVE=D5/'implementation-B/recovered/and-support'
def pin(p):
 p=Path(p).resolve();assert '.partial' not in p.name
 body=p.read_bytes();return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def save(p,d):
 with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
api_path=Path(sys.argv[1]).resolve();api=json.loads(api_path.read_bytes())
entry=Path(api['entry']['path']);assert pin(entry)==api['entry']
lh_path=D6/'verification-L/handoff-v1.json';lh=json.loads(lh_path.read_bytes())
assert pin(lh['source']['path'])==lh['source']
assert (RUNTIME/'compact_reference_verifier_v1.py').read_bytes()==Path(lh['source']['path']).read_bytes()
for p in sorted(RUNTIME.glob('*.py')):assert p.read_bytes()==(D6/'runtime'/p.name).read_bytes()
for name in ['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']:
 assert (B/'root'/name).read_bytes()==(D6/'root'/name).read_bytes()
corpus=D5/'corpus-L/pilot-inputs-v2.json';assert pin(corpus)['sha256']=='2f206ef004c4d723f862ee36f08355816c5264a5809340be9787331d82d33cd6'
doc=json.loads(corpus.read_bytes());assert [s['length'] for s in doc['tests']]==[14,13,14]
tree=ast.parse(entry.read_bytes(),filename=str(entry))
node=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LIMITS' for t in n.targets))
assert isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='dict'
scientific={k.arg:ast.literal_eval(k.value) for k in node.keywords}
assert scientific==json.loads((D5/'implementation-B/API-v2.json').read_bytes())['limits']
assert api['roles']==json.loads((D6/'implementation-B/API-v2.json').read_bytes())['roles']
native=dict(template_path=str(NATIVE/'fixed-native-inputs/proof-boundary-001.json'),micro_path=str(NATIVE/'fixed-native-inputs/proof-boundary-microcode-001.json.gz'),executable_path=str(NATIVE/'Native-runtime/boundary-oracle-v2'))
sources=sorted(RUNTIME.glob('*.py'))+[entry]+[B/'root'/n for n in ['observe_case_once_v2.py','run_case_once_v3.py','case_worker_v1.py','independent_countermodel_v1.py']]
checks=[]
for p in sources:
 parsed=ast.parse(p.read_bytes(),filename=str(p));compile(parsed,str(p),'exec');checks.append(dict(path=str(p),AST_and_unused_compile=True))
files=sources+[api_path,lh_path,corpus,PYTHON,NATIVE/'Native-runtime/boundary_oracle.cpp']+[Path(p) for p in native.values()]
rows=[pin(p) for p in sorted(set(files))]
limits=dict(positive_seconds=180,custody_seconds=210,observer_fallback_seconds=225,work_seconds=160,memory_bytes=1073741824,physical_bytes=134217728,reserved_outer_bytes=9437184,log_bytes=4194304,root_callbacks=400000000,result_bytes=50331648)
protocol=dict(schema='per-arm-recipient-search-protocol-v1',input=pin(corpus),limits=limits,scientific_limits=scientific,
 unchanged='Same three cold donor searches and full target theories/14-13-14 primitive bounds, exact candidate words and storage, scheduler, rollback, markings, six-arm relative schedules and numeric limits.',
 change='Ground-cluster Native UNKNOWN skips only cluster-dependent SC/P01/P11. S0/P00/P10 still run. Rejected/foreign statuses or errors are not unknown skips. Every skipped arm has explicit null search/metrics and prerequisite provenance.',
 proof_acceptance='Every found candidate retains exact case Host, full finite-region and final primitive Native gates. Native UNKNOWN after Host/region acceptance is candidate-only, not a proved Native theorem.',
 completion='A job_record_complete includes six explicit searched/skipped arm outcomes and complete Native/cost records. All_six_searched and scientific_complete are separate; skipped arms prevent complete six-arm comparison. Bounded unsuccessful search is unknown, not theorem false.',
 execution='Three fresh serial cold jobs. No adoption of old prefix/results/library/grants. All six arm outcomes and whole gates required for complete comparison; per-arm gates are deliberately different from immutable D6 shared gate.',
 costs='All acquisition, compilation, model/reference, encoding, marking, grounding/admission, each arm and final custody physically included once per case. Baseline method allocation does not charge unused learned-library work, and no cluster method receives free acquisition. Nested timers are not disjoint.',
 search_time='Same cooperative2second local budget. Graph construction/audit/update and cleanup can overshoot before checkpoints; all measured search/arm/job times reported. Symbolic row and point-placement attempts differ.',
 baseline_scope='Matched existing symbolic control, not best-known ATP or state-of-art benchmark. It shares full model/setup for point correspondence; that overhead is not intrinsically necessary for symbolic proof search.',
 reference='All26 runtime Sources and4 Rootcustodian Sources are bytecopies of frozenD6. Reused L handoff binds the original verifier; D7 scientificdelta reviews bind the changed caller, not a fictional old handoff for newentry.',
 observer='Unchanged separate225second fallback; actual180positive/210custody/1GiB/128MiBwhole gates. Live physical census is non-atomic; positive final census follows owned-process exit. No adversarial or OSrealtime guarantee.',
 scope='Native/point adaptation. No RL trained, physicalWang qualification, fullprogram completion or predicted fit. All historical gates/negatives remain unchanged.',
 partial_rule='Every.partial raw length/hash only, never parsed/admitted.',old_grants_remaining=0,new_actuals=0,new_grants=0)
protocol_path=B/'root/protocol-v1.json';save(protocol_path,protocol)
plans=[]
for spec in doc['tests']:
 case=spec['id'];actual=B/'actual'/case;assert not actual.exists() and not Path(str(actual)+'.observer').exists()
 plan=dict(schema='proof-search-case-once-plan-v1',experiment='per-arm-recipient-search-v1',case_id=case,actual_dir=str(actual),runtime_dir=str(RUNTIME),runner_path=str(B/'root/run_case_once_v3.py'),observer_path=str(B/'root/observe_case_once_v2.py'),worker_path=str(B/'root/case_worker_v1.py'),entry_path=str(entry),control_path=str(B/'root/independent_countermodel_v1.py'),input_path=str(corpus),modules=api['roles'],native=native,python=pin(PYTHON),files=rows,limits=limits,experiment_limits=scientific,protocol=pin(protocol_path),authority='No execution from plan. Exact reviewed fresh Root once grant required.',trusted_runtime='Pinned isolated CPython and fixed declared research Sources; nonhostile reproducible research, not wholeOS or adversarial security proof.',old_qualifications='No old grant/cohort/failed gate is adopted or rescued.')
 path=B/'root'/('plan-'+case+'-v1.json');save(path,plan);plans.append(pin(path))
offer=dict(schema='per-arm-recipient-search-whole-offer-v1',plans=plans,files=rows,protocol=pin(protocol_path),python=pin(PYTHON),source_AST_checks=checks,expected_case_jobs=3,expected_explicit_arm_outcomes=18,scientific_calls=0,new_actuals=0,new_grants=0,old_grants_remaining=0,resource_fit='UNMEASURED. Actual complete admission required.',readiness='PENDING_EXACT_SCIENTIFIC_DELTA_AND_PLAN_REVIEWS_ROOT_ONCE_GRANTS')
save(B/'root/prospective-whole-offer-v1.json',offer)
print(json.dumps(dict(plans=plans,files=len(rows),Source_AST_checks=len(checks),new_actuals=0,new_grants=0)))
