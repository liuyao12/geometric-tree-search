"""Root exact metadata preflight and fresh once grants; no scientific calls."""
from pathlib import Path
import hashlib,json,sys
B=Path(__file__).resolve().parent.parent;R=B/'root'
def pin(p):
 p=Path(p).resolve();assert '.partial' not in p.name
 body=p.read_bytes();return dict(path=str(p),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
def save(p,d):
 with p.open('x') as f:json.dump(d,f,sort_keys=True,indent=2);f.write('\n')
opath=R/'prospective-whole-offer-v1.json';offer=json.loads(opath.read_bytes())
for row in offer['files']+offer['plans']+[offer['protocol']]:assert pin(row['path'])==row
assert len(offer['files'])==39 and len(offer['plans'])==3
reviews=[]
for p in sys.argv[1:]:
 q=Path(p);v=json.loads(q.read_bytes());assert v['review_passed'] is True;reviews.append(pin(q))
assert len(reviews)>=3
preflight=dict(schema='Root-recipient-per-arm-preflight-v1',offer=pin(opath),protocol=offer['protocol'],reviews=reviews,review_passed=True,new_uses=3,old_grants_remaining=0,goal_status='active',previous_turn='PROGRESS: three compact setup actuals returned full target models and sourcechecked exclusion certificates; published/liveverified449218fd. No six-arm comparison.',authority='Three fresh once attempts under declared unchanged outer ceilings; not results.',conformance='Same complete point/candidate domains, exact t/m matching and unit12, distant dependencies, generationzero finite roots, globaldead/forced/earliestgeneration, exact branchcopyrollback. Candidate pruning only certifiedunarym; clusterhints keep primitivefallback. New per-arm prerequisite policy is explicitly different from D6 sharedstop. All claims remain Native/point adaptation.',gaps='No practicalspeedproof, no learnedRL policy, no physicalWangqualification or full program completion. Fit unmeasured. Actual tiny/referencechecks must return; planned recipes unrun.',partial_files_parsed=False)
save(R/'Root-preflight-v1.json',preflight)
for row in offer['plans']:
 p=json.loads(Path(row['path']).read_bytes());assert not Path(p['actual_dir']).exists() and not Path(p['actual_dir']+'.observer').exists()
 g=dict(schema='Root-fresh-recipient-case-grant-v1',authorized=True,uses=1,no_retry=True,case_id=p['case_id'],actual_dir=p['actual_dir'],plan_sha256=row['sha256'],runner_sha256=pin(p['runner_path'])['sha256'],observer_sha256=pin(p['observer_path'])['sha256'],review_passed=True,reviews=reviews,root_preflight=pin(R/'Root-preflight-v1.json'),old_grants_reused=False)
 save(R/('grant-'+p['case_id']+'-v1.json'),g)
print(json.dumps(dict(preflight=pin(R/'Root-preflight-v1.json'),fresh_grants=3,actuals=0)))
