"""Passive complete saved-record audit; no scientific imports or replay."""
from pathlib import Path
import collections
import hashlib
import json

D = Path(__file__).resolve().parents[1]
R = D / 'root'
checks = []


def check(label, value):
    checks.append(dict(id=label, passed=bool(value)))


def load(path):
    path = Path(path)
    if '.partial' in path.name:
        raise RuntimeError('No partial parsing')
    return json.loads(path.read_bytes())


def pin(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False).encode()).hexdigest()


offer = load(R / 'prospective-whole-offer-v1.json')
external = load(R / 'external-tool-observer-v1.json')
observations = {row['case_id']: row for row in external['cases']}
check('all39-Source-runtime-input-pins-current',
      len(offer['files']) == 39 and all(pin(row['path']) == row for row in offer['files']))
check('three-known-tool-exits-zero-remaining', external['complete_tool_exits'] == 3
      and external['remaining_once_grants'] == 0 and not external['partial_files_parsed']
      and all(row['tool_exit'] == 0 for row in observations.values()))
corpus_path = next(row['path'] for row in offer['files'] if row['path'].endswith('/pilot-inputs-v2.json'))
corpus = load(corpus_path)
raw_files = []
case_rows = []
accepted_recipients = []
native_counts = collections.Counter()
arm_counts = collections.Counter()
donor_count = 0
donor_native_acceptances = 0
libraries = []
for spec, planned in zip(corpus['tests'], offer['plans']):
    case_id = spec['id']
    actual = D / 'actual' / case_id
    observer_dir = actual.with_name(actual.name + '.observer')
    result = load(actual / 'result.json')
    header = load(actual / 'worker-header.json')
    terminal = load(actual / 'terminal.json')
    observer = load(observer_dir / 'observer.json')
    consumed = load(actual / 'CONSUMED.json')
    plan = load(planned['path'])
    grant_path = R / ('grant-' + case_id + '-v1.json')
    grant = load(grant_path)
    science = result['scientific_result']
    target = science['tests'][0]
    queries = result['native_queries']
    transport = result['native_transport']
    files = [pin(p) for directory in (actual, observer_dir)
             for p in sorted(directory.rglob('*')) if p.is_file()]
    raw_files.extend(files)
    result_pin = pin(actual / 'result.json')
    check(case_id + ':complete14-file-custody-and-fresh-consumption',
          len(files) == 14 and not any('.partial' in r['path'] for r in files)
          and pin(planned['path']) == planned
          and consumed['case_id'] == plan['case_id'] == grant['case_id'] == case_id
          and consumed['plan_sha256'] == grant['plan_sha256'] == planned['sha256']
          and consumed['grant_sha256'] == pin(grant_path)['sha256']
          and consumed['uses'] == grant['uses'] == 1
          and header['result'] == terminal['result'] == observations[case_id]['result'] == result_pin
          and header == terminal['header'] and observer == observations[case_id]['independent_observer']
          and terminal['process_exit_code'] == observer['parent_exit_code'] == 0
          and terminal['header_valid'] and terminal['final_custody_gate_passed']
          and observer['resource_candidate_accepted'] and terminal['errors'] == observer['errors'] == []
          and result['status'] == header['status'] == 'COMPLETE'
          and result['error'] is None and not result['first_Root_fault']
          and result['source_unchanged'] and header['source_unchanged'] and terminal['sources_unchanged'])
    check(case_id + ':exact-input-and-distinct-completion-flags',
          science['inputs'] == corpus and target['spec'] == spec
          and science['limits'] == plan['experiment_limits']
          and science['job_record_complete'] is True
          and science['all_six_searched'] is False and science['scientific_complete'] is False
          and science['complete'] is False
          and science['comparison_status'] == 'INCOMPLETE_SCIENTIFIC_COMPARISON'
          and [a['id'] for a in target['arms']] == corpus['protocol']['arm_order'][case_id])
    check(case_id + ':all-Native-records-complete-and-provenance-joined',
          queries == science['native_records'] and [q['id'] for q in queries] == list(range(len(queries)))
          and transport['complete_records'] == len(queries) == len(transport['request_stages'])
          and transport['closed'] and transport['all_reaped'] and transport['native_exit_code'] == 0
          and transport['cleanup_errors'] == []
          and all(digest(q['request']) == q['request_sha256']
                  and stage['stage'] == 'COMPLETED' and stage['record_id'] == stage['ordinal'] == q['id']
                  and stage['purpose'] == q['purpose'] and stage['limit'] == plan['experiment_limits']['native_steps']
                  and all(stage[k] == q[k] for k in ('request_sha256','input_sha256','output_sha256'))
                  for q, stage in zip(queries, transport['request_stages'])))
    native_counts.update(q['result']['status'] for q in queries)
    libraries.append(science['library'])
    check(case_id + ':three-cold-accepted-donors-and-frozen-library',
          len(science['training']) == len(science['library']) == 3
          and [e['spec'] for e in science['training']] == corpus['training']
          and [len(e['search']['proof']) for e in science['training']] == [3,5,5]
          and science['library_frozen_before_tests']
          and all(e['acquired'] and e['host_check']['accepted'] and e['essential_host_check']['accepted']
                  and e['region']['complete'] and e['reference_check']['complete']
                  and queries[e['native_query']]['request']['proof'] == e['search']['proof']
                  and queries[e['essential_native_query']]['request']['proof'] == e['essential_proof']
                  and queries[e['native_query']]['result']['status'] == 'accepted'
                  and queries[e['essential_native_query']]['result']['status'] == 'accepted'
                  for e in science['training']))
    donor_count += len(science['training'])
    donor_native_acceptances += 2 * len(science['training'])
    clusters = target['clusters']
    ground = queries[clusters['admission_query']]
    check(case_id + ':unknown-ground-library-retained-not-used',
          ground['purpose'] == 'pilot_ground_cluster_admission'
          and ground['result']['status'] == clusters['native_status'] == 'unknown_step_budget'
          and ground['result']['micro_steps'] == plan['experiment_limits']['native_steps'] == 1000000000
          and ground['request']['blocks'] == [x['definition'] for x in clusters['instances']]
          and clusters['usable'] == [] and clusters['status'] == 'unknown_cluster_admission')
    check(case_id + ':full-model-reference-wire-overlay-and28-controls-returned',
          target['reference_check']['complete'] and target['indexed_model_check']['complete']
          and target['marking_certificate_check']['complete'] and target['marked_extension_check']['complete']
          and len(target['model']['placements']) == target['reference_check']['accepted_placements']
          and len(target['markings']['certificates']) == target['marking_certificate_check']['certificates'] == 12
          and science['compact_reference_diagnostics']['complete']
          and len(science['compact_reference_diagnostics']['controls']) == 28
          and all(c['status'] == 'PASSED' for c in science['compact_reference_diagnostics']['controls'])
          and science['diagnostics']['status'] == 'complete')
    arms = []
    for arm in target['arms']:
        arm_counts[arm['execution_status']] += 1
        search = arm['search']
        if arm['id'] in ('SC','P01','P11'):
            check(case_id + ':' + arm['id'] + ':explicit-skipped-unavailable',
                  arm['execution_status'] == 'SKIPPED_UNKNOWN_PREREQUISITE'
                  and arm['reason'] == 'ground_registry_native_unknown'
                  and arm['prerequisite'] == dict(required=True, admission_query=ground['id'], native_status='unknown_step_budget')
                  and all(arm[k] is None for k in ('search','host_check','region','native_query','native_proof_accepted'))
                  and all(arm['timings'][k] is None for k in ('search_seconds','host_region_native_seconds','full_arm_seconds')))
            arms.append(dict(id=arm['id'], execution=arm['execution_status'], attempts=None))
            continue
        check(case_id + ':' + arm['id'] + ':actual-primitive-search-returned',
              arm['execution_status'] == 'SEARCH_RETURNED' and not arm['cluster_enabled']
              and not search['cluster_ordering'] and search['root_restored'])
        row = dict(id=arm['id'], execution=arm['execution_status'], search_status=search['status'],
                   native_proof_accepted=arm['native_proof_accepted'],
                   proof_verification_status=arm['proof_verification_status'],
                   search_seconds=arm['timings']['search_seconds'], full_arm_seconds=arm['timings']['full_arm_seconds'],
                   metrics=search['metrics'])
        if arm['method'] == 'point':
            removed = search['initial_auxiliary_removals']
            expected_count = 12 if arm['id'] == 'P10' else 0
            cert_aux = {tuple(c['auxiliary']['point']): c['auxiliary'] for c in target['markings']['certificates']}
            check(case_id + ':' + arm['id'] + ':zero-placement-first-audit-cutoff',
                  search['status'] == 'unknown_search_budget'
                  and search['trace'] == [dict(event='cutoff', attempts=0)]
                  and search['domain_audits'] == [] and search['metrics']['nodes'] == 1
                  and search['proof'] is None and search['placements'] == []
                  and 'attempts' not in search['metrics']
                  and search['graph_metrics']['candidate_tests'] == len(target['model']['placements']))
            check(case_id + ':' + arm['id'] + ':saved-initial-auxiliary-witnesses-join-certificates',
                  len(removed) == search['metrics']['initial_auxiliary_removed_incidences']
                  == search['metrics']['auxiliary_removed_incidences_total'] == expected_count
                  and len({tuple(w['candidate']) for w in removed}) == expected_count
                  and all(w['channel'] == 'certified-failure' and w['frontier_point'] == [0,0]
                          and w['candidate'] == cert_aux[tuple(w['auxiliary_point'])]['placement']
                          and w['candidate_value'] == cert_aux[tuple(w['auxiliary_point'])]['placement_value'] == 0
                          and w['assigned_value'] == cert_aux[tuple(w['auxiliary_point'])]['initial_value'] == 1
                          for w in removed))
            row.update(placement_attempts=0, placement_attempts_provenance='explicit cutoff budget counter plus no place event',
                       completed_domain_audits=0, initial_auxiliary_conflict_witnesses=expected_count,
                       point_cutoff_stage_inference='Inside first audit_domains call, after Graph initialization and initial decision computation, before appending the first decision trace or placing a candidate.')
        else:
            row['attempts'] = search['metrics']['attempts']
            if search['proof'] is None:
                check(case_id + ':S0-600-attempt-unknown-not-false',
                      search['status'] == 'unknown_search_budget' and search['metrics']['attempts'] == 600
                      and search['trace'][-1] == dict(event='cutoff', attempts=600)
                      and arm['proof_verification_status'] == 'NO_PROOF_CANDIDATE')
            else:
                proof = search['proof']
                q = queries[arm['native_query']]
                model = target['model']
                placements = {tuple(p['key']): p for p in model['placements']}
                chosen = search['placements']
                check(case_id + ':accepted-recipient-exact-request-and-region',
                      case_id == 'pilot-fork-join-positive' and arm['id'] == 'S0'
                      and len(proof) == 14 and len(chosen) == 28
                      and search['metrics']['attempts'] == 14
                      and arm['host_check']['accepted'] and arm['host_check']['rows'] == 14
                      and arm['region'] == dict(complete=True, required_points=28, selected_placements=28,
                                                mark_points=4041, decoded_rows=14)
                      and arm['native_proof_accepted'] is True
                      and arm['proof_verification_status'] == 'HOST_REGION_NATIVE_ACCEPTED'
                      and q['purpose'] == 'pilot_test_' + case_id + '_S0'
                      and q['request']['protocol'] == 'gcts-fol-1'
                      and q['request']['theory'] == spec['theory'] and q['request']['target'] == spec['target']
                      and q['request']['proof'] == proof and q['request']['blocks'] == []
                      and q['result']['status'] == 'accepted')
                joined = []
                for i, command in enumerate(proof):
                    cp, gp = [placements[tuple(k)] for k in chosen[2*i:2*i+2]]
                    check(case_id + ':literal-proof-row-tile-join-' + str(i),
                          cp['key'][:2] == [i,0] and gp['key'][:2] == [i,1]
                          and cp['occupancy'] == [[[4*i,0],12]] and gp['occupancy'] == [[[4*i,1],12]]
                          and all(model['domains'][p['command_reference'][0]][p['command_reference'][1]] == command
                                  for p in (cp,gp))
                          and all(type(src) is int and 0 <= src < i and formula == proof[src]['formula']
                                  for src, formula in gp['metadata']['requirements']))
                    joined.append(dict(row=i, rule=command['rule'], command_key=cp['key'], guard_key=gp['key'],
                                       earlier_row_requirement_indices=[src for src, formula in gp['metadata']['requirements']]))
                accepted_recipients.append(dict(case_id=case_id, arm='S0', rows=14,
                    primitive_rule_counts=dict(collections.Counter(c['rule'] for c in proof)),
                    Native_query_id=q['id'], request_sha256=q['request_sha256'],
                    Native_result=q['result'], host_check=arm['host_check'], finite_region=arm['region'],
                    selected_point_placements=28, proof_row_certificate_joins=joined,
                    discovery_method='Existing matched symbolic primitive baseline, no clusters or auxiliary marks',
                    timings=arm['timings'], result=result_pin))
        arms.append(row)
    limits = plan['limits']
    check(case_id + ':saved-whole-resource-candidate-gates',
          terminal['known_exit_seconds'] < limits['positive_seconds']
          and terminal['final_custody_gate_seconds'] < limits['custody_seconds']
          and observer['final_observer_gate_seconds'] < limits['observer_fallback_seconds']
          and observer['final_conservative_whole_peak_bytes'] < limits['memory_bytes']
          and sum(r['bytes'] for r in files) + limits['reserved_outer_bytes'] < limits['physical_bytes']
          and result['callbacks'] < limits['root_callbacks'] and result_pin['bytes'] < limits['result_bytes'])
    case_rows.append(dict(case_id=case_id, result=result_pin, plan=planned, grant=pin(grant_path),
        job_record_complete=science['job_record_complete'], scientific_complete=science['scientific_complete'],
        arms=arms, native_queries=len(queries), native_status_counts=dict(collections.Counter(q['result']['status'] for q in queries)),
        proposed_ground_instances=len(clusters['instances']), ground_query=ground['id'],
        compile_model_reference_seconds=target['compile_and_model_seconds'],
        cold_training_seconds=science['training_and_acquisition_seconds'],
        full_shared_setup_seconds=target['full_shared_setup_seconds'],
        worker_seconds=result['elapsed_seconds'], observer_final_gate_seconds=observer['final_observer_gate_seconds'],
        observer_whole_peak_bytes=observer['final_conservative_whole_peak_bytes'],
        stored_files=len(files), complete_stored_plus_outer_reserve_bytes=sum(r['bytes'] for r in files)+limits['reserved_outer_bytes']))

check('nine-actual-searches-nine-explicit-skips-one-accepted-recipient',
      arm_counts == {'SEARCH_RETURNED': 9, 'SKIPPED_UNKNOWN_PREREQUISITE': 9} and len(accepted_recipients) == 1)
check('nine-donor-occurrences-same-three-families', donor_count == 9 and donor_native_acceptances == 18
      and all(lib == libraries[0] for lib in libraries))
check('42-complete-actual-files', len(raw_files) == 42)
resource_review_path = D / 'verification-L/typed-recipient-resource-custody-review-v1.json'
resource_review = load(resource_review_path)
check('independent-scoped-resource-review-PASS', resource_review['review_passed']
      and not resource_review['failed_checks'])
failed = [c['id'] for c in checks if not c['passed']]
out = dict(schema='typed-recipient-actual-scientific-review-v1', reviewer_identity='/root/recovered_batch_review',
    review_passed=not failed, scope='Bounded passive complete saved-JSON and literal certificate/provenance joins plus pinned Source control-flow inference; no mathematical or scientific replay.',
    scientific_component_calls=0, scientific_imports=0, partial_files_parsed=False, semantic_replays=0,
    actual_execution_authorized=False, new_grants_issued=0,
    source_review=pin(D/'review-C/typed-scientific-delta-Source-review-v1.json'),
    whole_preflight=pin(D/'review-C/typed-whole-prospective-Source-review-v1.json'),
    independent_resource_review=pin(resource_review_path),
    offer=pin(R/'prospective-whole-offer-v1.json'), external_tool_observations=pin(R/'external-tool-observer-v1.json'),
    raw_actual_files=raw_files, raw_actual_file_count=len(raw_files), case_results=case_rows,
    aggregate=dict(actual_case_jobs=3, searched_arm_outcomes=dict(arm_counts),
                   native_requests=sum(native_counts.values()), native_status_counts=dict(native_counts),
                   accepted_recipient_proofs=1, accepted_recipient_method='S0 symbolic baseline',
                   donor_occurrences=donor_count, distinct_donor_proofs=3,
                   accepted_whole_and_essential_donor_native_requests=donor_native_acceptances,
                   target_certificates=36, P10_initial_auxiliary_conflict_witnesses=36,
                   point_searches=6, point_placement_attempts=0, completed_recipient_point_domain_audits=0,
                   six_arm_comparison_complete=False, RL_trained=False),
    accepted_recipient_observations=accepted_recipients,
    findings=[
        'A genuine recipient proof was automatically found: the existing S0 symbolic baseline returned the first positive target in14 primitive row extensions. Exact saved theory/target/proof request with blocks=[] received Host, whole finite-region and fixed Native acceptance. Search took0.105310958seconds; full arm4.860065250seconds including final checks. This is a result of conventional symbolic search, not GCTS, learned clusters or RL.',
        'The accepted proof has4 named-axiom rows,3 universal-instantiation schema rows and7 modus-ponens rows. Its28 command/guard placements and every saved earlier-row receptor index/formula join the same14 primitive commands. The runtime region receipt checks complete target occupancy and marking agreement. This reviewer performed literal certificate/request joins only, not an independent logical replay.',
        'Other S0 runs stopped at600 primitive extensions with unknown_search_budget. They do not show either recipient false. The missing-premise singleton countermodel remains a separate manually supplied and machine-evaluated control, not proof-search input.',
        'Exactly9 arm searches returned and9 cluster-dependent arms were explicitly skipped. Every ground registry again reached unknown_step_budget at1e9microsteps; no usable grounded cluster library or receptor-family search gain was established. All jobs returned complete ordered records but remain scientific_complete:false and six-arm comparison incomplete.',
        'All6 point calls completed Graph initialization, passed the first visit budget check, computed an initial decision and recorded nodes1. The empty domain_audits plus cutoff-only trace locate failure inside the first audit_domains call, before first decision trace/placement. The explicit cutoff budget counter is0; missing Counter attempts can therefore be reported as0 with this provenance, not as a standalone saved metric.',
        'Point search duration includes Graph construction, copies/fingerprints, partial first audit and post-cutoff initial-mismatch scan. No stage timers isolate those components; it would be inaccurate to attribute the entire3.3–4.0seconds solely to Graph initialization or to the audit.',
        'Marked P10 reports12 certified initial auxiliary conflict incidences per case; unmarked P00 reports0. Each witness joins its saved certificate and0-versus1 auxiliary values. This field is a post-cutoff full alignment _reason scan, not a saved independently checked before/after graph-domain difference. Pinned Graph Source uses ordinary m legality, but no full recipient graph audit returned. No forced-propagation, reduced tree or speed benefit follows.',
        'All3 model/reference/wire/marked-overlay receipts, all28 reference controls per job, Tiny controls and cold donor/library records returned. Certificates are separately support-rechecked using the shared conflict routine; L independent representation checks are a different scope.',
        'Three complete process attempts have saved resource-candidate gates and known Root-reported tool exit0. This audit is scientific/provenance scoped; detailed independent resource/custody admission is handled separately. Whole cold Native compilation/model/reference costs remain included, so0.105seconds is search-only, not end-to-end proof cost.',
        'This provides one accepted larger recipient proof and an actual point-search bottleneck. It supplies no GCTS/RL advantage, complete six-method comparison, physical Wang interpreter acceptance, full universal proof system, PA/Hilbert-geometry benchmark result or general soundness theorem. All prior negative results remain unchanged.'
    ],
    checks=checks, failed_checks=failed,
    tools_stopped_after_freeze=True)
path = D / 'review-C/typed-recipient-actual-scientific-review-v1.json'
path.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(review=pin(path), checks=len(checks), failed_checks=failed,
                      aggregate=out['aggregate']), indent=2))
