"""UNEXECUTED general finite unit-center point search, no imports.

All literal prototypes at every exact allowed origin. Remote multi-channel
markings only; no Wang NESW shortcut, clause scanner, learned rule or RL.
First mode may exclude proved failed children in their exact parent context.
All mode uses full enumeration cursors, never calls successful children dead.
"""
VERSION = 'general-finite-unit-center-point-search-v1'
INSTANCE_SCHEMA = 'finite-unit-center-point-instance-v1'
CERTIFICATE_SCHEMA = 'finite-unit-center-placement-certificate-v1'
SNAPSHOT_SCHEMA = 'finite-unit-center-complete-graph-snapshot-v1'
DEADPOINT_SCHEMA = 'unit-center-primitive-deadpoint-candidate-v1'
BASE_KEYS = ('schema', 'transformations', 'required_centers', 'admissible_origins',
             'tiles', 'fixed_background_marks', 'all_root_generations')
LIMIT_KEYS = ('work', 'centers', 'tiles', 'marks', 'candidates', 'dependencies',
              'mark_points', 'integer_abs', 'string_chars', 'data_depth', 'decisions',
              'trace_rows', 'snapshot_items', 'trail_entries', 'solutions', 'deadpoints', 'witness_rows')


class InputError(Exception):
    pass


class SearchLimit(Exception):
    def __init__(self, reason, *, owner=None):
        self.reason, self._owner = reason, owner
        super().__init__(reason)


class _Budget:
    def __init__(self, check, limits):
        if (not callable(check) or type(limits) is not dict or len(limits) != len(LIMIT_KEYS)
                or any(type(k) is not str for k in limits) or set(limits) != set(LIMIT_KEYS)):
            raise InputError('exact finite limits and callback required')
        for key in LIMIT_KEYS:
            if type(limits[key]) is not int or limits[key] < 1:
                raise InputError('positive exact-int limits required')
        if limits['data_depth'] > 128:
            raise InputError('recursive ordinary-data depth at most128')
        self.check, self.limits = check, dict(limits)
        self.owner = object()
        self.counts = {'work': 0}
        check()

    def charge(self, kind):
        self.counts['work'] += 1
        self.counts[kind] = self.counts.get(kind, 0) + 1

    def step(self, kind):
        self.charge(kind)
        if self.counts['work'] > self.limits['work']:
            raise SearchLimit('work', owner=self.owner)
        self.check()

    def cap(self, name, value):
        self.step('capacity_checks')
        if value > self.limits[name]:
            raise SearchLimit(name, owner=self.owner)

    def integer(self, value, nonnegative=False):
        self.step('integer_atoms')
        if type(value) is not int or (nonnegative and value < 0):
            raise InputError('exact integer atom required')
        self.cap('integer_abs', abs(value))
        return value

    def string(self, value):
        if type(value) is not str:
            raise InputError('literal string required')
        self.cap('string_chars', len(value))
        for c in value:
            self.step('string_characters')
            if 0xD800 <= ord(c) <= 0xDFFF:
                raise InputError('Unicode scalar strings required')
        return value


def _obj(value, keys):
    if (type(value) is not dict or len(value) != len(keys)
            or any(type(k) is not str for k in value) or set(value) != set(keys)):
        raise InputError('exact object fields required')


def _arr(value, size=None):
    if type(value) is not list or (size is not None and len(value) != size):
        raise InputError('ordinary array required')
    return value


def _copy(value, w, depth=0, active=None):
    w.step('ordinary_copy_nodes')
    w.cap('data_depth', depth)
    t = type(value)
    if value is None or t in (bool, int):
        return value
    if t is str:
        return w.string(value)
    if t not in (list, dict):
        raise InputError('strict finite JSON subset; no floats/subclasses/tuples')
    if active is None:
        active = set()
    identity = id(value)
    if identity in active:
        raise InputError('cyclic caller data')
    active.add(identity)
    try:
        if t is list:
            return [_copy(x, w, depth + 1, active) for x in value]
        result = {}
        for key, item in value.items():
            result[w.string(key)] = _copy(item, w, depth + 1, active)
        return result
    finally:
        active.remove(identity)


def _same(left, right, w):
    w.step('full_value_comparisons')
    if type(left) is not type(right):
        return False
    if type(left) is list:
        if len(left) != len(right):
            return False
        for a, b in zip(left, right):
            if not _same(a, b, w):
                return False
        return True
    if type(left) is dict:
        if len(left) != len(right) or set(left) != set(right):
            return False
        for key in left:
            if not _same(left[key], right[key], w):
                return False
        return True
    if type(left) is str:
        w.string(left); w.string(right)
    return left == right


def _xy(value, w, even=False):
    result = [w.integer(x) for x in _arr(value, 2)]
    if even and any(x % 2 for x in result):
        raise InputError('origins must belong to2Z2')
    return result


def _marks(value, w):
    result, seen = [], set()
    for row in _arr(value):
        w.step('original_mark_rows')
        _arr(row, 3)
        xy, channel, code = _xy(row[0], w), w.string(row[1]), w.integer(row[2], True)
        key = (tuple(xy), channel)
        if key in seen:
            raise InputError('duplicate assignment point/channel')
        seen.add(key)
        result.append([xy, channel, code])
        w.cap('marks', len(result))
    return result


def _base(value, w):
    _obj(value, BASE_KEYS)
    if (value['schema'] != INSTANCE_SCHEMA or value['transformations'] != 'translations_only_2Z2'
            or type(value['all_root_generations']) is not int or value['all_root_generations'] != 0):
        raise InputError('finite exact unit-center translation-only scope required')
    centers, seen = [], set()
    for raw in _arr(value['required_centers']):
        w.step('base_required_centers')
        xy = _xy(raw, w, True)
        if tuple(xy) in seen:
            raise InputError('duplicate required center')
        seen.add(tuple(xy)); centers.append(xy)
        w.cap('centers', len(centers))
    if not centers or not _same(value['admissible_origins'], centers, w):
        raise InputError('nonempty required=allowed exact ordered origins required')
    tiles, ids, total_marks = [], set(), 0
    for raw in _arr(value['tiles']):
        w.step('base_tile_rows')
        _obj(raw, ('id', 't', 'm'))
        tile_id = w.integer(raw['id'], True)
        if tile_id in ids:
            raise InputError('distinct literal tile identities required')
        ids.add(tile_id)
        if not _same(raw['t'], [[[0, 0], 1]], w):
            raise InputError('exact singleton center t=1 required')
        marks = _marks(raw['m'], w); total_marks += len(marks)
        tiles.append(dict(id=tile_id, t=[[[0, 0], 1]], m=marks))
        w.cap('tiles', len(tiles)); w.cap('marks', total_marks)
    if not tiles:
        raise InputError('nonempty finite base palette required')
    pins = _marks(value['fixed_background_marks'], w)
    w.cap('marks', total_marks + len(pins))
    w.cap('candidates', len(centers) * len(tiles))
    return dict(schema=INSTANCE_SCHEMA, transformations='translations_only_2Z2',
        required_centers=centers, admissible_origins=[xy[:] for xy in centers],
        tiles=tiles, fixed_background_marks=pins, all_root_generations=0)



class _Graph:
    def __init__(self, instance, w, observe, observe_deadpoint, mode):
        self.instance, self.w, self.observe = instance, w, observe
        self.observe_deadpoint, self.mode = observe_deadpoint, mode
        self.origins = [tuple(p) for p in instance['required_centers']]
        self.tiles = instance['tiles']
        self.palette_ids = [t['id'] for t in self.tiles]
        self.pins = {(tuple(xy), channel): value for xy, channel, value in instance['fixed_background_marks']}
        self.marks = {key: (value, 1) for key, value in self.pins.items()}
        self.occ = [None] * len(self.origins)
        self.generations, self.excluded = {}, {}
        self.candidates, self.cmarks = [], []
        self.active, self.reverse = [], []
        self.dep_t, self.dep_m = {}, {}
        self.domains = [set() for p in self.origins]
        self.trail, self.trace, self.frames = [], [], []
        self.solutions, self.deadpoints = [], []
        self.decisions, self.witness_rows = 0, 0
        dependencies = 0
        for point, (x, y) in enumerate(self.origins):
            self.dep_t[point] = set()
            for ordinal, tile in enumerate(self.tiles):
                w.step('complete_candidate_construction')
                cid = len(self.candidates)
                self.candidates.append((point, ordinal))
                marks = []
                self.dep_t[point].add(cid)
                for offset, channel, value in tile['m']:
                    w.step('translated_mark_dependencies')
                    xy = (x + offset[0], y + offset[1])
                    key = (xy, channel)
                    marks.append((key, value))
                    self.dep_m.setdefault(key, set()).add(cid)
                    dependencies += 1
                    w.cap('dependencies', dependencies)
                    w.cap('mark_points', len(self.dep_m))
                self.cmarks.append(tuple(marks))
                self.active.append(False); self.reverse.append(None)
        w.cap('mark_points', len(set(self.dep_m) | set(self.pins)))
        for cid in range(len(self.candidates)):
            if self.legal(cid):
                point = self.candidates[cid][0]
                self.active[cid] = True; self.reverse[cid] = point
                self.domains[point].add(cid)
        self.initial_domains = tuple(tuple(sorted(d)) for d in self.domains)

    def legal(self, cid, ignore_exclusions=False):
        self.w.step('candidate_legality')
        point, ordinal = self.candidates[cid]
        if self.occ[point] is not None or (not ignore_exclusions and cid in self.excluded):
            return False
        for key, value in self.cmarks[cid]:
            self.w.step('raw_mark_agreement')
            if key in self.marks and self.marks[key][0] != value:
                return False
        return True

    def _trail(self, kind, key, old):
        self.w.cap('trail_entries', len(self.trail) + 1)
        self.trail.append((kind, key, old))

    def event(self, kind, **fields):
        self.w.cap('trace_rows', len(self.trace) + 1)
        row = _copy(dict(kind=kind, **fields), self.w)
        self.trace.append(row)
        name = 'events_' + kind
        self.w.counts[name] = self.w.counts.get(name, 0) + 1

    def choose(self):
        dead, forced, frontier = [], [], []
        for point, occupied in enumerate(self.occ):
            self.w.step('global_frontier_census')
            if occupied is None:
                degree = len(self.domains[point])
                frontier.append((0, degree, point))
                if degree == 0: dead.append(point)
                elif degree == 1: forced.append(point)
        if dead: return 'DEAD', min(dead), ()
        if forced:
            point = min(forced)
            return 'FORCED', point, tuple(sorted(self.domains[point]))
        if not frontier: return 'COMPLETE', None, ()
        point = min(frontier)[2]
        return 'BRANCH', point, tuple(sorted(self.domains[point]))

    def place(self, cid, kind):
        trail_from = len(self.trail)
        if not self.active[cid] or not self.legal(cid):
            raise InputError('placement is not a complete current graph member')
        point, ordinal = self.candidates[cid]
        self._trail('occ', point, self.occ[point]); self.occ[point] = ordinal
        self._trail('generation', cid, None); self.generations[cid] = 1
        affected = set(self.dep_t[point])
        for key, value in self.cmarks[cid]:
            self.w.step('mark_assignments')
            old = self.marks.get(key)
            self._trail('mark', key, old)
            self.marks[key] = (value, 1 if old is None else old[1] + 1)
            for dependent in self.dep_m[key]:
                self.w.step('affected_remote_dependencies'); affected.add(dependent)
        removed = []
        for candidate in sorted(affected):
            self.w.step('incremental_candidate_updates')
            if self.active[candidate] and not self.legal(candidate):
                origin = self.candidates[candidate][0]
                self._trail('active', candidate, True)
                self.active[candidate] = False; self.reverse[candidate] = None
                self.domains[origin].remove(candidate); removed.append(candidate)
        frame = self.frames[-1] if self.frames else None
        frame_context = None if frame is None else dict(checkpoint=frame['checkpoint'], point=frame['point'],
            options=list(frame['options']), chosen=frame['chosen'], next_index=frame['next_index'],
            parent_support=list(frame['parent_support']))
        self.event(kind, candidate=cid, point=point, tile_id=self.palette_ids[ordinal], generation=1,
                   removed=removed, trail_from=trail_from, trail_to=len(self.trail), frame_context=frame_context)

    def branch_place(self, cid):
        self.w.cap('decisions', self.decisions + 1)
        self.decisions += 1
        self.place(cid, 'branch')

    def selected_ids(self):
        result = []
        for cid in sorted(self.generations):
            self.w.step('selected_parent_context')
            result.append(cid)
        return tuple(result)

    def exclude_failed_child(self, cid):
        if self.mode != 'first' or not self.active[cid] or not self.legal(cid):
            raise InputError('only a proved failed first-mode child can be excluded')
        support = self.selected_ids()
        self._trail('exclude', cid, None); self.excluded[cid] = support
        self._trail('active', cid, True)
        point = self.candidates[cid][0]
        self.active[cid] = False; self.reverse[cid] = None; self.domains[point].remove(cid)
        self.event('parent_context_failed_child', candidate=cid, support=list(support))

    def undo(self, checkpoint):
        # No callbacks during critical rollback. Every attempted undo still charged.
        while len(self.trail) > checkpoint:
            self.w.charge('rollback_operations')
            kind, key, old = self.trail.pop()
            if kind == 'active':
                point = self.candidates[key][0]
                self.active[key] = old; self.reverse[key] = point if old else None
                if old: self.domains[point].add(key)
                else: self.domains[point].remove(key)
            elif kind == 'mark':
                if old is None: del self.marks[key]
                else: self.marks[key] = old
            elif kind == 'occ': self.occ[key] = old
            elif kind == 'generation': del self.generations[key]
            elif kind == 'exclude': del self.excluded[key]
            else: raise InputError('unknown owned rollback operation')

    def snapshot(self, reason):
        w = self.w
        points, candidates, chosen, marks, forward, reverse, deps, pins, excluded = [], [], [], [], [], [], [], [], []
        for point, xy in enumerate(self.origins):
            w.step('snapshot_points')
            points.append([point, list(xy), 0 if self.occ[point] is None else 1, 0])
            forward.append([point, sorted(self.domains[point])])
        for cid, (point, ordinal) in enumerate(self.candidates):
            w.step('snapshot_candidates')
            candidates.append([cid, point, self.palette_ids[ordinal], self.active[cid]])
            reverse.append([cid, [] if self.reverse[cid] is None else [self.reverse[cid]]])
        for cid in sorted(self.generations):
            w.step('snapshot_chosen')
            point, ordinal = self.candidates[cid]
            chosen.append([cid, point, self.palette_ids[ordinal], self.generations[cid]])
        for key in sorted(self.marks):
            w.step('snapshot_mark_section')
            value, refs = self.marks[key]
            marks.append([list(key[0]), key[1], value, refs, key in self.pins])
        for point in range(len(self.origins)):
            w.step('snapshot_t_dependencies'); deps.append(['t', point, sorted(self.dep_t[point])])
        for key in sorted(self.dep_m):
            w.step('snapshot_m_dependencies'); deps.append(['m', list(key[0]), key[1], sorted(self.dep_m[key])])
        for key in sorted(self.pins):
            w.step('snapshot_pins'); pins.append([list(key[0]), key[1], self.pins[key]])
        for cid in sorted(self.excluded):
            w.step('snapshot_context_exclusions'); excluded.append([cid, list(self.excluded[cid])])
        stack = []
        for frame in self.frames:
            w.step('snapshot_branch_frames')
            stack.append(dict(checkpoint=frame['checkpoint'], point=frame['point'],
                options=list(frame['options']), chosen=frame['chosen'], next_index=frame['next_index'],
                parent_support=list(frame['parent_support'])))
        decision, point, options = self.choose()
        packet = dict(schema=SNAPSHOT_SCHEMA, reason=reason, mode=self.mode, palette_ids=self.palette_ids[:],
            points=points, candidates=candidates, chosen=chosen, marks=marks, forward=forward, reverse=reverse,
            dependencies=deps, boundary=pins, exclusions=excluded,
            scheduler=dict(kind=decision, point=point, options=list(options)), branch_stack=stack,
            trail_length=len(self.trail), work=dict(w.counts), authority=False)
        pending, items = [packet], 0
        while pending:
            value = pending.pop(); items += 1
            w.cap('snapshot_items', items)
            if type(value) is dict:
                for key, child in value.items(): pending.append(key); pending.append(child)
            elif type(value) is list: pending.extend(value)
        return packet

    def notify(self, reason):
        if self.observe is not None:
            packet = self.snapshot(reason)
            self.w.step('snapshot_observer_calls')
            self.observe(packet)  # Direct; no callback-bearing generator wrapper.

    def complete_certificate(self):
        section = dict(self.pins)
        placements = []
        for point, ordinal in enumerate(self.occ):
            self.w.step('whole_target_checks')
            if ordinal is None: raise InputError('unfilled exact target')
            cid = point * len(self.tiles) + ordinal
            for key, value in self.cmarks[cid]:
                self.w.step('whole_mark_checks')
                if key in section and section[key] != value:
                    raise InputError('whole point/channel marking conflict')
                section[key] = value
            placements.append(dict(tile_id=self.palette_ids[ordinal], origin=list(self.origins[point])))
        return dict(schema=CERTIFICATE_SCHEMA, placements=placements)

    def record_solution(self):
        certificate = self.complete_certificate()
        self.w.cap('solutions', len(self.solutions) + 1)
        self.solutions.append(certificate)
        self.event('solution_candidate', index=len(self.solutions) - 1)

    def deadpoint_candidate(self, point):
        # This never reads active-domain absence/exclusions as a conflict witness.
        self.w.step('raw_deadpoint_attempts')
        if self.occ[point] is not None: raise InputError('deadpoint must be unfilled')
        owners, support = {}, []
        for cid in sorted(self.generations):
            self.w.step('deadpoint_selected_support')
            origin, ordinal = self.candidates[cid]
            support.append(dict(cid=cid, origin=list(self.origins[origin]), tile_id=self.palette_ids[ordinal]))
            for key, value in self.cmarks[cid]:
                self.w.step('deadpoint_support_marks'); owners.setdefault(key, []).append((cid, value))
        witnesses = []
        for ordinal, tile_id in enumerate(self.palette_ids):
            self.w.step('deadpoint_all_original_tiles')
            cid = point * len(self.tiles) + ordinal
            witness = None
            for key, value in self.cmarks[cid]:
                self.w.step('deadpoint_raw_mark_tests')
                if key in self.pins and self.pins[key] != value:
                    witness = dict(tile_id=tile_id, cid=cid, point=list(key[0]), channel=key[1],
                        candidate_value=value, blocker_kind='pin', blocker_cid=None, blocker_value=self.pins[key])
                    break
                for blocker, other in owners.get(key, ()):
                    self.w.step('deadpoint_placement_tests')
                    if other != value:
                        witness = dict(tile_id=tile_id, cid=cid, point=list(key[0]), channel=key[1],
                            candidate_value=value, blocker_kind='placement', blocker_cid=blocker, blocker_value=other)
                        break
                if witness is not None: break
            if witness is None:
                self.event('raw_deadpoint_abstain', point=point, original_tile_id=tile_id)
                return
            witnesses.append(witness)
        self.w.cap('deadpoints', len(self.deadpoints) + 1)
        self.w.cap('witness_rows', self.witness_rows + len(witnesses))
        packet = dict(schema=DEADPOINT_SCHEMA, scope='CURRENT_INVOCATION_INSTANCE', id=len(self.deadpoints),
            instance=_copy(self.instance, self.w),
            point=point, center=list(self.origins[point]), support=support,
            fixed_background_marks=_copy(self.instance['fixed_background_marks'], self.w), witnesses=witnesses,
            branch_exclusions_ignored=True, mathematical_authority=False)
        owned = _copy(packet, self.w)
        if self.observe_deadpoint is not None:
            offered = _copy(packet, self.w)
            self.w.step('deadpoint_observer_calls'); self.observe_deadpoint(offered)
        self.deadpoints.append(owned); self.witness_rows += len(witnesses)
        self.event('raw_deadpoint_candidate', candidate=owned['id'], point=point)

    def statistics(self):
        return dict(candidate_universe=len(self.candidates), mark_dependency_keys=len(self.dep_m),
            decision_attempts=self.decisions, solutions=len(self.solutions), deadpoint_candidates=len(self.deadpoints),
            witness_rows=self.witness_rows, trace_rows=len(self.trace))

    def root_check(self):
        if self.trail or self.generations or self.excluded or self.frames:
            raise InputError('root trail/generation/context restoration failure')
        expected_marks = {k: (v, 1) for k, v in self.pins.items()}
        if self.marks != expected_marks: raise InputError('full root mark/reference restoration failure')
        for point in range(len(self.origins)):
            self.w.step('root_domain_checks')
            if self.occ[point] is not None or tuple(sorted(self.domains[point])) != self.initial_domains[point]:
                raise InputError('full root occupancy/domain restoration failure')
        for cid in range(len(self.candidates)):
            self.w.step('root_reverse_checks')
            point = self.candidates[cid][0]; expected = cid in self.domains[point]
            if self.active[cid] is not expected or self.reverse[cid] != (point if expected else None):
                raise InputError('full root reverse restoration failure')

    def _restore_frame(self, frame):
        trail_from = len(self.trail)
        self.undo(frame['checkpoint'])
        self.event('rollback', checkpoint=frame['checkpoint'], point=frame['point'],
            trail_from=trail_from, trail_to=len(self.trail), options=list(frame['options']),
            chosen=frame['chosen'], next_index=frame['next_index'], parent_support=list(frame['parent_support']))
        self.notify('ROLLBACK')
        decision, point, options = self.choose()
        if decision != 'BRANCH' or point != frame['point'] or options != frame['options']:
            raise InputError('restored complete parent graph differs')
        self.event('rollback_census', decision=decision, point=point, options=list(options))

    def run(self):
        self.notify('INITIAL')
        while True:
            self.notify('STATE')
            decision, point, options = self.choose()
            self.event('census', decision=decision, point=point, options=list(options))
            if decision == 'COMPLETE':
                self.record_solution()
                if self.mode == 'first': return 'POINT_TILING_CANDIDATE', False
            elif decision == 'FORCED':
                self.place(options[0], 'forced'); continue
            elif decision == 'BRANCH':
                frame = dict(checkpoint=len(self.trail), point=point, options=options,
                             chosen=options[0], next_index=1, parent_support=self.selected_ids())
                self.frames.append(frame); self.branch_place(options[0]); continue
            else:
                if self.observe_deadpoint is not None:
                    self.deadpoint_candidate(point)
                else:
                    self.event('raw_deadpoint_acquisition_disabled', point=point)
            # COMPLETE(all) or DEAD: exhaust/advance a full original branch cursor.
            if self.mode == 'first':
                if not self.frames: return 'FINITE_EXHAUSTED', True
                frame = self.frames.pop(); self._restore_frame(frame)
                self.exclude_failed_child(frame['chosen'])
                continue
            advanced = False
            while self.frames:
                frame = self.frames[-1]; self._restore_frame(frame)
                if frame['next_index'] < len(frame['options']):
                    cid = frame['options'][frame['next_index']]
                    frame['chosen'] = cid; frame['next_index'] += 1
                    self.branch_place(cid); advanced = True; break
                self.event('enumeration_subtree_exhausted', point=frame['point'],
                           options=list(frame['options']), solutions_seen=len(self.solutions))
                self.frames.pop()
            if not advanced: return 'ALL_SOLUTIONS_EXHAUSTED', True


def _cleanup(graph):
    if graph is not None:
        try:
            graph.undo(0); graph.frames.clear()
        except BaseException:
            pass  # Preserve exact active caller/resource exception, never success.


def search(instance, *, check, limits, observe=None, observe_deadpoint=None, mode='first'):
    """First/exhaustive search on frozen ordinary point data, no live rule updates.

    Only own exact-class private-token quota returns UNKNOWN. Snapshots and
    deadpoint candidates are detached, diagnostic-only; callback returns ignored.
    """
    if type(mode) is not str or mode not in ('first', 'all'):
        raise InputError('explicit first/all scope required')
    if observe is not None and not callable(observe): raise InputError('observe callable or None')
    if observe_deadpoint is not None and not callable(observe_deadpoint): raise InputError('deadpoint observer callable or None')
    w = _Budget(check, limits); graph = None
    try:
        owned = _copy(instance, w); model = _base(owned, w)
        if not _same(owned, model, w): raise InputError('full model projection changed original data')
        graph = _Graph(model, w, observe, observe_deadpoint, mode)
        status, exhausted = graph.run()
        trail_from = len(graph.trail)
        graph.undo(0); graph.frames.clear(); graph.root_check()
        graph.event('root_cleanup_complete', trail_from=trail_from, trail_to=0)
        graph.notify('ROOT_RESTORED')
        current = _copy(instance, w)
        if not _same(owned, current, w): raise InputError('caller instance changed during search')
        w.step('successful_return_check')
        return dict(status=status, version=VERSION, mode=mode, exhausted=exhausted,
            solutions=graph.solutions, deadpoint_candidates=graph.deadpoints, counts=dict(w.counts), trace=graph.trace,
            statistics=graph.statistics(), root_restored=True, input_reconciled=True, independent_verification_required=True,
            runtime_nogood_pruning=False, learned_marks=False, RL=False, mathematical_authority=False)
    except SearchLimit as error:
        if type(error) is not SearchLimit or error._owner is not w.owner:
            _cleanup(graph); raise
        _cleanup(graph)
        return dict(status='UNKNOWN', reason=error.reason, version=VERSION, mode=mode, exhausted=False,
            solutions=[] if graph is None else graph.solutions,
            deadpoint_candidates=[] if graph is None else graph.deadpoints,
            counts=dict(w.counts), trace=[] if graph is None else graph.trace,
            statistics=None if graph is None else graph.statistics(),
            root_restoration='cleanup attempted; not checked after quota', input_reconciled=False,
            independent_verification_required=True, mathematical_authority=False)
    except BaseException:
        _cleanup(graph); raise
