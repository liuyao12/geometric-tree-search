"""UNEXECUTED independent general finite unit-center snapshot/deadpoint checks.

No compiler, codec, search, solver, simulator or fixture imports. Literal tile
identity and every assigned marking, including0 and remote points, are retained.
"""
VERSION='independent-finite-unit-center-search-verifier-v1'
_OWNER=object()
CADENCE=1024
LIMIT_KEYS=('work','centers','tiles','marks','candidates','dependencies','mark_points',
            'integer_abs','string_chars','data_depth','decisions','trace_rows',
            'snapshot_items','trail_entries','solutions','deadpoints','witness_rows')
BASE_KEYS=('schema','transformations','required_centers','admissible_origins',
           'tiles','fixed_background_marks','all_root_generations')



class Invalid(ValueError):
    def __init__(self,reason,*,_owner=None):
        self.reason=reason;self._owner=_owner;super().__init__(reason)


class ResourceLimit(RuntimeError):
    def __init__(self,reason,work,*,_owner=None):
        self.reason=reason;self.work=work;self._owner=_owner;super().__init__(reason)


def is_own_invalid(error):
    return type(error)is Invalid and error._owner is _OWNER


def is_own_limit(error):
    return type(error)is ResourceLimit and error._owner is _OWNER


def _need(ok,reason):
    if not ok:raise Invalid(reason,_owner=_OWNER)


class _Budget:
    def __init__(self,check,limits):
        _need(callable(check),'explicit external check')
        _need(type(limits)is dict and all(type(k)is str for k in limits)and
              set(limits)==set(LIMIT_KEYS),'exact explicit private limits')
        _need(all(type(v)is int and v>0 for v in limits.values()),'positive exact-int limits')
        _need(limits['data_depth']<=128,'Source depth ceiling128')
        self.check=check;self.limits=dict(limits);self.work=0;self.stage='ENTRY'
        check()
    def tick(self):
        self.work+=1
        if self.work>self.limits['work']:
            raise ResourceLimit('work',self.work,_owner=_OWNER)
        if self.work%CADENCE==0:self.check()
    def bound(self,key,value):
        self.tick()
        if value>self.limits[key]:raise ResourceLimit(key,self.work,_owner=_OWNER)


def _failure(error,w,stage):
    # The caller protects this entire attachment-only diagnostic path.
    error.point_search_verifier_prefix=dict(schema='unit-center-search-verifier-failure-prefix-v1',
        stage=stage if w is None else w.stage,work=0 if w is None else w.work,
        cost_available=w is not None,cost_is_lower_bound=w is None,
        complete=False,authority=False)


def _object(value,keys,reason):
    _need(type(value)is dict and all(type(k)is str for k in value)and
          set(value)==set(keys),reason)


def _number(value,w,low=None):
    w.tick();_need(type(value)is int,'exact builtin integer')
    if low is not None:_need(value>=low,'integer lower bound')
    w.bound('integer_abs',abs(value));return value


def _string(value,w):
    w.tick();_need(type(value)is str,'literal string channel/key')
    w.bound('string_chars',len(value))
    for char in value:
        w.tick();_need(not 0xD800<=ord(char)<=0xDFFF,'Unicode scalar strings only')
    return value


def _point(value,w,even=False):
    w.tick();_need(type(value)is list and len(value)==2,'two-integer point')
    x=_number(value[0],w);y=_number(value[1],w)
    if even:_need(x%2==0 and y%2==0,'origins in translation lattice2Z2')
    return (x,y)


def _same(a,b,w):
    pending=[(a,b)]
    while pending:
        w.tick();left,right=pending.pop()
        if type(left)is not type(right):return False
        kind=type(left)
        if kind is list:
            if len(left)!=len(right):return False
            pending.extend(zip(left,right))
        elif kind is dict:
            if set(left)!=set(right)or any(type(k)is not str for k in left):return False
            for key in left:pending.append((left[key],right[key]))
        elif kind in(str,int,bool)or left is None:
            if left!=right:return False
        else:return False
    return True


def _copy(value,w,depth=0,active=None):
    w.tick();w.bound('data_depth',depth)
    kind=type(value)
    if value is None or kind is bool:return value
    if kind is int:return value  # Mathematical fields and metadata have distinct quotas below.
    if kind is str:return _string(value,w)
    _need(kind in(list,dict),'ordinary JSON values only')
    if active is None:active=set()
    identity=id(value);_need(identity not in active,'acyclic ordinary data')
    active.add(identity)
    try:
        if kind is list:return [_copy(v,w,depth+1,active)for v in value]
        result={}
        for key,item in value.items():
            _string(key,w);result[key]=_copy(item,w,depth+1,active)
        return result
    finally:active.remove(identity)


def _marks(rows,w):
    _need(type(rows)is list,'complete literal marking rows')
    section={};parsed=[]
    for row in rows:
        w.tick();_need(type(row)is list and len(row)==3,'point/channel/value marking')
        p=_point(row[0],w);channel=_string(row[1],w);value=_number(row[2],w,0)
        key=(p,channel);_need(key not in section,'no duplicate assigned point/channel')
        section[key]=value;parsed.append((p,channel,value))
    return section,parsed


def _model(instance,w):
    w.stage='INSTANCE';_object(instance,BASE_KEYS,'exact finite unit-center instance')
    _need(instance['schema']=='finite-unit-center-point-instance-v1'and
          instance['transformations']=='translations_only_2Z2'and
          type(instance['all_root_generations'])is int and instance['all_root_generations']==0,
          'fixed translation-only generation-zero profile')
    raw=instance['required_centers'];_need(type(raw)is list,'literal complete centers')
    w.bound('centers',len(raw));centers=[];seen=set()
    for row in raw:
        p=_point(row,w,True);_need(p not in seen,'distinct required centers')
        centers.append(p);seen.add(p)
    _need(bool(centers),'nonempty declared finite target')
    _need(_same(instance['admissible_origins'],raw,w),'exact same ordered admissible origins')
    tiles=instance['tiles'];_need(type(tiles)is list,'complete literal tile list')
    _need(bool(tiles),'nonempty declared finite palette')
    w.bound('tiles',len(tiles));w.bound('candidates',len(centers)*len(tiles))
    tile_map={};ordered=[];mark_count=0;channels=set()
    for tile in tiles:
        w.tick();_object(tile,('id','t','m'),'exact unit tile fields')
        identity=_number(tile['id'],w,0);_need(identity not in tile_map,'distinct literal tile IDs')
        _need(_same(tile['t'],[[[0,0],1]],w),'unit-center positive support exactly')
        section,rows=_marks(tile['m'],w);mark_count+=len(rows);w.bound('marks',mark_count)
        for unused,channel,value in rows:channels.add(channel)
        tile_map[identity]=rows;ordered.append(identity)
    pins,pin_rows=_marks(instance['fixed_background_marks'],w)
    mark_count+=len(pin_rows);w.bound('marks',mark_count)
    for unused,channel,value in pin_rows:channels.add(channel)
    return dict(raw=instance,centers=centers,center_set=seen,tiles=tile_map,
                tile_ids=ordered,pins=pins,pin_rows=pin_rows,channels=channels,
                mark_count=mark_count)


def _candidate(model,cid,w):
    cid=_number(cid,w,0);size=len(model['tile_ids'])
    _need(cid<len(model['centers'])*size,'candidate in full origin/palette product')
    pi,ti=divmod(cid,size);tid=model['tile_ids'][ti]
    return pi,tid,model['centers'][pi]


def _absolute(model,cid,w):
    pi,tid,(x,y)=_candidate(model,cid,w);rows=[]
    for (dx,dy),channel,value in model['tiles'][tid]:
        w.tick();p=(x+dx,y+dy)
        w.bound('integer_abs',abs(p[0]));w.bound('integer_abs',abs(p[1]))
        rows.append((p,channel,value))
    return rows


def _selected(model,cids,w):
    _need(type(cids)is list,'literal sorted selected candidate IDs')
    w.bound('centers',len(cids));last=-1;selected=set();occupied=[0]*len(model['centers'])
    section={key:[value,1,True]for key,value in model['pins'].items()}
    w.bound('mark_points',len(section));chosen=[];support=[]
    for cid in cids:
        w.tick();pi,tid,p=_candidate(model,cid,w)
        _need(cid>last,'sorted unique selected candidate IDs');last=cid
        _need(occupied[pi]==0,'unit-center selected placements cannot overlap')
        occupied[pi]=1;selected.add(cid);chosen.append([cid,pi,tid,1])
        support.append(dict(cid=cid,origin=list(p),tile_id=tid))
        for point,channel,value in _absolute(model,cid,w):
            w.tick();key=(point,channel)
            if key in section:
                _need(section[key][0]==value,'selected original marking disagreement')
                section[key][1]+=1
            else:section[key]=[value,1,False]
            w.bound('mark_points',len(section))
    return selected,occupied,section,chosen,support


def _legal(model,cid,occupied,section,w):
    pi,tid,p=_candidate(model,cid,w);legal=occupied[pi]==0
    for point,channel,value in _absolute(model,cid,w):
        w.tick();key=(point,channel)
        if key in section and section[key][0]!=value:legal=False
    return legal


def _scheduler(occupied,forward,w):
    frontier=[];dead=[];forced=[]
    for pi,total in enumerate(occupied):
        w.tick()
        if total==0:
            frontier.append(pi)
            if len(forward[pi])==0:dead.append(pi)
            elif len(forward[pi])==1:forced.append(pi)
    if dead:kind='DEAD';point=min(dead)
    elif forced:kind='FORCED';point=min(forced)
    elif frontier:kind='BRANCH';point=min(frontier,key=lambda pi:(0,len(forward[pi]),pi))
    else:kind='COMPLETE';point=None
    return dict(kind=kind,point=point,options=[]if point is None else list(forward[point])),frontier


def _exclusions(model,rows,selected,mode,w):
    _need(type(rows)is list,'literal parent-context exclusions')
    w.bound('candidates',len(rows))
    if mode=='all':_need(rows==[],'all-solutions enumeration uses no failed-child exclusions')
    result=[];excluded=set();last=-1
    for row in rows:
        w.tick();_need(type(row)is list and len(row)==2,'exclusion plus literal parent support')
        cid=_number(row[0],w,0);_candidate(model,cid,w)
        _need(cid>last and cid not in selected,'sorted unique nonselected exclusions');last=cid
        parent,occupied,section,unused,support=_selected(model,row[1],w)
        _need(parent<=selected,'exclusion context retained in current selected prefix')
        _need(cid not in parent and _legal(model,cid,occupied,section,w),
              'excluded child was a primitive legal candidate in declared parent')
        excluded.add(cid);result.append([cid,list(row[1])])
    return excluded,result


def _census(model,cids,exclusions,mode,w):
    selected,occupied,section,chosen,support=_selected(model,cids,w)
    excluded,normalized_exclusions=_exclusions(model,exclusions,selected,mode,w)
    size=len(model['tile_ids']);candidates=[];physical=[];active=[]
    forward=[[]for p in model['centers']];reverse=[];t_dependencies=[];m_dependencies={};edges=0
    for pi,p in enumerate(model['centers']):
        w.tick();at_point=[]
        for ti,tid in enumerate(model['tile_ids']):
            w.tick();cid=pi*size+ti;at_point.append(cid);legal=occupied[pi]==0
            for point,channel,value in _absolute(model,cid,w):
                w.tick();key=(point,channel);m_dependencies.setdefault(key,[]).append(cid)
                edges+=1;w.bound('dependencies',edges);w.bound('mark_points',len(m_dependencies))
                if key in section and section[key][0]!=value:legal=False
            if legal:physical.append(cid)
            available=legal and cid not in excluded
            candidates.append([cid,pi,tid,available]);reverse.append([cid,[pi]if available else []])
            if available:active.append(cid);forward[pi].append(cid)
        t_dependencies.append(['t',pi,at_point])
    w.bound('mark_points',len(set(m_dependencies)|set(model['pins'])))
    dependencies=t_dependencies
    for (point,channel),ids in sorted(m_dependencies.items()):
        w.tick();dependencies.append(['m',list(point),channel,ids])
    scheduler,frontier=_scheduler(occupied,forward,w)
    census=dict(points=[[pi,list(p),occupied[pi],0]for pi,p in enumerate(model['centers'])],
        candidates=candidates,chosen=chosen,
        marks=[[list(p),channel,value,refs,fixed]for (p,channel),(value,refs,fixed)in sorted(section.items())],
        forward=[[pi,ids]for pi,ids in enumerate(forward)],reverse=reverse,dependencies=dependencies,
        boundary=[[list(p),channel,value]for (p,channel),value in sorted(model['pins'].items())],
        exclusions=normalized_exclusions,scheduler=scheduler)
    return census,physical,active,frontier,support


def _finish(owned,original,w):
    w.stage='INPUT_RECHECK'
    _need(_same(owned,_copy(original,w),w),'whole ordinary caller input changed')


def _natural(value,w):
    w.tick();_need(type(value)is int and value>=0,'exact nonnegative metadata integer')
    return value


def _items(value,w):
    pending=[value];count=0
    while pending:
        w.tick();item=pending.pop();count+=1;w.bound('snapshot_items',count)
        if type(item)is dict:
            for key,child in item.items():pending.append(key);pending.append(child)
        elif type(item)is list:pending.extend(item)
    return count


SNAPSHOT_KEYS=('schema','reason','mode','palette_ids','points','candidates','chosen','marks',
              'forward','reverse','dependencies','boundary','exclusions','scheduler',
              'branch_stack','trail_length','work','authority')
FRAME_KEYS=('checkpoint','point','options','chosen','next_index','parent_support')


def _frames(model,rows,selected,exclusions,mode,reason,trail,w):
    _need(type(rows)is list,'complete literal branch stack')
    w.bound('centers',len(rows));w.bound('decisions',len(rows))
    expected=[];previous_checkpoint=-1;previous_parent=set();previous_choice=None
    for index,row in enumerate(rows):
        w.tick();_object(row,FRAME_KEYS,'exact branch frame fields')
        checkpoint=_natural(row['checkpoint'],w);w.bound('trail_entries',checkpoint)
        _need(previous_checkpoint<checkpoint<=trail,'nested in-range raw checkpoints')
        previous_checkpoint=checkpoint
        parent_cids=row['parent_support'];parent,unused,section,chosen,support=_selected(model,parent_cids,w)
        _need(parent<=selected,'retained parent literal support in current prefix')
        if index:
            _need(previous_parent|{previous_choice}<=parent,'nested parent contains prior branch choice')
        parent_exclusions=[r for r in exclusions if set(r[1])<=parent]
        parent_graph,physical,active,frontier,raw_support=_census(model,parent_cids,parent_exclusions,mode,w)
        scheduler=parent_graph['scheduler'];point=_number(row['point'],w,0)
        _need(scheduler['kind']=='BRANCH'and point==scheduler['point']and
              _same(row['options'],scheduler['options'],w),'full independent original parent BRANCH/options')
        next_index=_number(row['next_index'],w,1)
        _need(next_index<=len(scheduler['options']),'bounded original branch cursor')
        choice=_number(row['chosen'],w,0)
        _need(choice==scheduler['options'][next_index-1],'cursor points after declared chosen original alternative')
        top_restored=mode=='all'and reason=='ROLLBACK'and index==len(rows)-1
        if top_restored:
            _need(parent==selected and choice not in selected and checkpoint==trail,
                  'ALL rollback exposes restored top parent before advance/pop')
        else:_need(choice in selected,'active ancestor frame choice selected')
        expected.append(dict(checkpoint=checkpoint,point=point,options=list(scheduler['options']),
            chosen=choice,next_index=next_index,parent_support=list(parent_cids)))
        previous_parent=parent;previous_choice=choice
    return expected


def audit_snapshot(instance,snapshot,*,check,limits):
    w=None
    try:
        w=_Budget(check,limits);raw=[instance,snapshot];owned=_copy(raw,w)
        model=_model(owned[0],w);packet=owned[1];_items(packet,w)
        _object(packet,SNAPSHOT_KEYS,'exact full unit-center snapshot fields')
        _need(packet['schema']=='finite-unit-center-complete-graph-snapshot-v1'and
              packet['authority']is False,'known nonauthoritative snapshot schema')
        reason=packet['reason'];mode=packet['mode']
        _need(type(reason)is str and reason in('INITIAL','STATE','ROLLBACK','ROOT_RESTORED'),
              'literal stable snapshot reason')
        _need(type(mode)is str and mode in('all','first'),'literal all/first mode')
        _need(_same(packet['palette_ids'],model['tile_ids'],w),'every literal original ID in input order')
        rows=packet['chosen'];_need(type(rows)is list,'complete selected placement rows')
        cids=[]
        for row in rows:
            w.tick();_need(type(row)is list and len(row)==4,'literal chosen row')
            cids.append(_number(row[0],w,0))
        expected,physical,active,frontier,support=_census(model,cids,packet['exclusions'],mode,w)
        trail=_natural(packet['trail_length'],w);w.bound('trail_entries',trail)
        frames=_frames(model,packet['branch_stack'],set(cids),packet['exclusions'],mode,reason,trail,w)
        expected['branch_stack']=frames;expected['trail_length']=trail
        for key,value in expected.items():
            _need(_same(packet[key],value,w),'full independent snapshot mismatch: '+key)
        counters=packet['work'];_need(type(counters)is dict,'passive ordinary work counters')
        w.bound('snapshot_items',len(counters))
        for key,value in counters.items():
            _string(key,w);_natural(value,w)
            _need(value<=w.limits['work'],'passive counter bounded by declared invocation work')
        if reason in('INITIAL','ROOT_RESTORED'):
            _need(not cids and packet['exclusions']==[]and not frames and trail==0,
                  'complete initial/root-restored original state')
        _finish(owned,raw,w);w.stage='RETURN';w.tick();check()
        return dict(schema='independent-unit-center-search-snapshot-audit-v1',version=VERSION,
            status='EXACT_UNIT_CENTER_POINT_CENSUS_MATCH',mode=mode,reason=reason,census=expected,
            palette_ids=list(model['tile_ids']),physically_legal_candidates=physical,
            active_candidates=active,frontier=frontier,selected_support=support,work=w.work,
            exclusion_soundness_certified=False,
            branch_scope='Full parent graph/options and current literal cursor shape checked; historical traversal completion and trail contents require owner trace/pairing.',
            authority=False,formal_kernel_certified=False,
            general_fractional_or_mixed_generation_qualified=False)
    except BaseException as error:
        try:_failure(error,w,'AUDIT_SNAPSHOT')
        except BaseException:pass
        raise


DEAD_KEYS=('schema','scope','id','instance','point','center','support',
           'fixed_background_marks','witnesses','branch_exclusions_ignored','mathematical_authority')
WITNESS_KEYS=('tile_id','cid','point','channel','candidate_value',
              'blocker_kind','blocker_cid','blocker_value')


def certify_deadpoint(instance,certificate,*,check,limits):
    """Check an exact-original-instance redundant forbidden conjunction.

    No branch exclusion, candidate-domain absence, learned clause, private mark
    section or external m argument is a witness. All point values come from the
    full bound original instance and explicitly selected compatible support.
    """
    w=None
    try:
        w=_Budget(check,limits);raw=[instance,certificate];owned=_copy(raw,w)
        model=_model(owned[0],w);proof=owned[1];_items(proof,w)
        _object(proof,DEAD_KEYS,'exact complete primitive deadpoint certificate')
        _need(proof['schema']=='unit-center-primitive-deadpoint-candidate-v1'and
              proof['scope']=='CURRENT_INVOCATION_INSTANCE'and
              proof['branch_exclusions_ignored']is True and proof['mathematical_authority']is False,
              'original primitive diagnostic candidate without authority')
        identity=_number(proof['id'],w,0);w.bound('deadpoints',1)
        _need(_same(proof['instance'],owned[0],w),'full original instance binding, no hash shortcut')
        _need(_same(proof['fixed_background_marks'],owned[0]['fixed_background_marks'],w),
              'all and only original pins in original literal order')
        point=_number(proof['point'],w,0);_need(point<len(model['centers']),'distinguished required center')
        _need(_same(proof['center'],list(model['centers'][point]),w),'literal distinguished coordinate')
        rows=proof['support'];_need(type(rows)is list,'complete explicit selected support')
        cids=[]
        for row in rows:
            w.tick();_object(row,('cid','origin','tile_id'),'literal selected support placement')
            cids.append(_number(row['cid'],w,0))
        selected,occupied,section,chosen,support=_selected(model,cids,w)
        _need(_same(rows,support,w),'exact support cid/origin/literal-ID join')
        _need(occupied[point]==0,'distinguished center unfilled by support')
        witnesses=proof['witnesses'];_need(type(witnesses)is list,'complete primitive witnesses')
        w.bound('witness_rows',len(witnesses))
        _need(len(witnesses)==len(model['tile_ids']),'one witness for EVERY original literal tile')
        checked=[];used=set();rejections=[];size=len(model['tile_ids'])
        for ti,tid in enumerate(model['tile_ids']):
            w.tick();row=witnesses[ti];_object(row,WITNESS_KEYS,'literal primitive witness fields')
            cid=point*size+ti
            _need(_same(row['tile_id'],tid,w)and _same(row['cid'],cid,w),
                  'original tile INPUT order and exact candidate identity, no geometric deduplication')
            p=_point(row['point'],w);channel=_string(row['channel'],w)
            value=_number(row['candidate_value'],w,0);blocker=_number(row['blocker_value'],w,0)
            marks={(xy,ch):v for xy,ch,v in _absolute(model,cid,w)};key=(p,channel)
            _need(key in marks and marks[key]==value,'actually assigned original candidate mark')
            kind=row['blocker_kind'];other=row['blocker_cid']
            _need(type(kind)is str,'literal blocker source')
            if kind=='pin':
                _need(other is None and key in model['pins']and model['pins'][key]==blocker,
                      'actually assigned original permanent pin')
            elif kind=='placement':
                _number(other,w,0);_need(other in selected,'blocker explicitly belongs to support')
                other_marks={(xy,ch):v for xy,ch,v in _absolute(model,other,w)}
                _need(key in other_marks and other_marks[key]==blocker,
                      'actually assigned support mark at the same point/channel')
                used.add(other)
            else:raise Invalid('exclusions/domain absence/learned filters are not primitive blockers',_owner=_OWNER)
            _need(value!=blocker,'exact assigned inequality, including assigned0')
            _need(not _legal(model,cid,occupied,section,w),'complete original candidate is physically rejected')
            checked.append(_copy(row,w));rejections.append([cid,tid,False])
        clause=[dict(origin=list(row['origin']),tile_id=row['tile_id'])for row in support]
        section_rows=[[list(p),channel,value,refs,fixed]
                      for (p,channel),(value,refs,fixed)in sorted(section.items())]
        totals=[[pi,list(p),occupied[pi],0]for pi,p in enumerate(model['centers'])]
        _finish(owned,raw,w);w.stage='RETURN';w.tick();check()
        return dict(schema='independent-unit-center-primitive-deadpoint-check-v1',version=VERSION,
            status='VALID_SAME_INSTANCE_PRIMITIVE_DEADPOINT',id=identity,instance=owned[0],
            certificate=proof,point=point,center=list(model['centers'][point]),
            clause=clause,support=support,used_witness_support=sorted(used),
            original_tile_ids=list(model['tile_ids']),witnesses=checked,
            support_totals=totals,support_section=section_rows,original_tile_rejections=rejections,
            fixed_background_marks=owned[0]['fixed_background_marks'],work=w.work,
            same_instance_clause_justified=True,branch_exclusions_used=False,
            scope='Only this complete exact original finite instance; no transport/infinite extension claim.',
            selection_history_certified=False,authority=False,formal_kernel_certified=False)
    except BaseException as error:
        try:_failure(error,w,'CERTIFY_DEADPOINT')
        except BaseException:pass
        raise


