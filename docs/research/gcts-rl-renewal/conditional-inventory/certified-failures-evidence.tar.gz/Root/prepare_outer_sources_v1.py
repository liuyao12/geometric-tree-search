"""Raw outer Source editing and unused AST compilation only."""
from pathlib import Path
import ast,hashlib,json
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1');OLD=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1')
s=(OLD/'run_marking_qualification_once_v1.py').read_text()
s=s.replace("VERSION='finite-point-marking-once-runner-v1'","VERSION='certified-general-point-search-once-runner-v1'")
s=s.replace("SOURCE_ROLES=frozenset(('worker','compiler','verifier','runner','observer'))","SOURCE_ROLES=frozenset(('worker','compiler','verifier','search','census','runner','observer'))")
s=s.replace('proof_checker_calls','FOL_kernel_calls')
s=s.replace("profile='finite-unit-center-marking-translation-qualification'","profile='certified-general-point-search-integration'")
a=s.index('def validate_qualification(');b=s.index('\n\ndef main(',a)
s=s[:a]+'''def validate_qualification(q,plan,declaration,outputs):
    need(q['schema']=='certified-finite-point-search-integration-candidate-v1'and
         q['status']=='COMPLETE_CERTIFIED_POINT_SEARCH_INTEGRATION_CANDIDATE','whole new certified point integration')
    need(q['outputs']==outputs and len(outputs)==1,'one complete canonical packet')
    need(q['case_ids']==declaration['case_ids']and type(q['rows'])is list and
         [row['id']for row in q['rows']]==q['case_ids']and len(q['rows'])==23,
         'every declared whole point/propositional case in order')
    need(len(q['case_ids'])==len(set(q['case_ids'])),'unique original IDs')
    for row in q['rows']:
        need(all(row[key]is True for key in('complete','all_original_solutions_preserved',
             'primitive_certificates_checked','marked_lane_uses_only_point_agreement')),
             'whole search/certificate/frozen marking/projection gate')
        need(type(row['original_solution_count'])is int and row['original_solution_count']>=0,
             'complete finite nonnegative solution population')
    need(any(row['original_solution_count']>0 for row in q['rows'])and
         any(row['original_solution_count']==0 for row in q['rows']),'positive and exhausted-negative coverage')
    need(q['diagnostic_ids']==declaration['diagnostic_ids']and
         [row['id']for row in q['diagnostics']]==q['diagnostic_ids']and len(q['diagnostics'])==18,
         'every declared diagnostic')
    for row,declared in zip(q['diagnostics'],declaration['diagnostics']):
        need(row['status']=='PASSED'and row['operation']==declared['operation'],'reached exact planned disposition')
        if 'foreign'in row['operation']:
            need(row['expected']=='FOREIGN'and row['exact_foreign_identity']is True and
                 type(row['local_callbacks'])is int and row['local_callbacks']==1,'exact first external callback identity')
    need(type(q['root_check_calls'])is int and 0<q['root_check_calls']<=400000000,'original cumulative callback ceiling')
    for key in('compiler_calls','verifier_calls','search_calls','oracle_calls','graph_census_calls','primitive_certificate_calls','certified_clauses'):
        need(type(q[key])is int and q[key]>0,'actual nonzero declared component work: '+key)
    need(q['same_instance_primitive_redundancy_candidate']is True,'separately bound original finite proof candidate')
    for key in('full_pipeline_qualified','mathematical_proof_accepted','fixed_FOL_palette_qualified',
               'gcts_rl_advantage_established','learned_pair_markings','trained_RL'):
        need(q[key]is False,'no broader mathematical or performance authority')
''' +s[b:]
p=D/'run_certified_point_search_once_v1.py';p.write_text(s)
o=(OLD/'observe_marking_qualification_once_v1.py').read_text().replace("VERSION='finite-point-marking-terminal-observer-v1'","VERSION='certified-general-point-search-terminal-observer-v1'")
o=o.replace('Finite unit-center marking translation component only, no FOL proof-checker or search advantage qualification.','Finite certified unit-center point search integration only; full FOL kernel and search advantage remain unqualified.')
q=D/'observe_certified_point_search_once_v1.py';q.write_text(o)
rows=[]
for path in(p,q):
 raw=path.read_bytes();tree=ast.parse(raw);compile(tree,str(path),'exec');rows.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
print(json.dumps(dict(sources=rows,unused_compiles=2,target_calls=0),sort_keys=True))
