"""Passive saved JSON counters/byte custody only; no subject imports or replay."""
from pathlib import Path
from collections import Counter
import json,hashlib
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1');A=D/'actual-integration-v1'
def pin(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
r=json.loads((A/'runner-receipt.json').read_bytes());t=json.loads((D/'plan-authorized-v1-terminal-observation/terminal.json').read_bytes());p=json.loads((A/'canonical-certified-point-search-integration.json').read_bytes());h=json.loads((A/'worker-receipt.json').read_bytes())
assert t['terminal_gate_passed']and r['worker_exit_code']==0 and r['worker_reaped']and r['owned_group_absent']and r['regular_logs_closed']
assert r['positive_result_read_completed_ns']<r['work_deadline_ns']and t['terminal_observed_ns']<r['overall_deadline_ns']
for row in r['outputs']+[r['result'],r['worker_receipt'],r['stdout'],r['stderr']]:assert pin(Path(row['path']))==row
retired=dict(schema='ROOT-certified-point-grant-retirement-v1',author_identity='/root',grant=pin(D/'authorization-once-v1.json'),plan=pin(D/'plan-authorized-v1.json'),consumed=pin(A/'CONSUMED.json'),worker_consumed=pin(A/'WORKER_CONSUMED.json'),runner=pin(A/'runner-receipt.json'),terminal=pin(D/'plan-authorized-v1-terminal-observation/terminal.json'),actual_invocations=1,retired=True,remaining_invocations=0,repeat_authorized=False,subject_calls_outside_actual=0,scope='Complete raw output/zero exit/custody read. Narrow mathematical saved-data adoption awaits separate review.')
with (D/'ROOT-grant-retirement-v1.json').open('x')as f:json.dump(retired,f,sort_keys=True,indent=2)
def metrics(row,lane):
 result=row[lane]['result'];events=result['trace'];counter=Counter(e['kind']for e in events)
 b=len(row['compilation']['instance']['tiles'])if lane=='marked'else len(row['model']['tiles'])
 original_count=len(row['model']['tiles']);original_centers=len(row['model']['required_centers'])
 direct=[];base_branch=base_forced=aux_branch=aux_forced=0
 for i,e in enumerate(events):
  if e['kind']not in('branch','forced'):continue
  original=e['point']<original_centers and(lane!='marked'or e['tile_id']<original_count)
  if e['kind']=='branch':
   if original:base_branch+=1
   else:aux_branch+=1
  else:
   if original:base_forced+=1
   else:aux_forced+=1
  if lane=='marked'and e['point']>=original_centers:
   for cid in e['removed']:
    pi,ti=divmod(cid,b)
    if pi<original_centers and ti<original_count:
     direct.append(dict(event_index=i,placing_candidate=e['candidate'],placing_tile_id=e['tile_id'],removed_candidate=cid,original_point_index=pi,emitted_base_tile_id=ti,original_literal_tile_id=row['compilation']['mapping']['base_tiles'][ti][1]))
 return dict(statistics=result['statistics'],event_counts=dict(counter),base_branch_attempts=base_branch,base_forced_placements=base_forced,auxiliary_branch_attempts=aux_branch,auxiliary_forced_placements=aux_forced,logged_base_candidate_removals_on_auxiliary_placements=direct)
rows=[]
for row in p['rows']:
 rows.append(dict(id=row['id'],original_solution_count=row['original_solution_count'],certified_clause_count=len(row['certified_clauses']),all_original_solutions_preserved=row['all_original_solutions_preserved'],plain=metrics(row,'plain'),acquisition=metrics(row,'acquisition'),marked=metrics(row,'marked'),plain_complete_seconds=row['plain_complete_seconds'],cold_certified_pipeline_seconds=row['cold_certified_pipeline_seconds'],compile_and_translation_seconds=row['compile_and_translation_seconds'],model_reference_seconds=row['model_reference_seconds'],total_case_seconds=row['total_case_seconds'],live_census_count=sum(len(row[k]['records'])for k in('plain','acquisition','marked'))))
v=dict(schema='ROOT-passive-certified-point-results-v1',raw_packet=pin(A/'canonical-certified-point-search-integration.json'),cases=len(rows),diagnostics=len(p['diagnostics']),all_diagnostics_passed=all(d['status']=='PASSED'for d in p['diagnostics']),certified_clauses=sum(x['certified_clause_count']for x in rows),original_solutions=sum(x['original_solution_count']for x in rows),positive_cases=sum(x['original_solution_count']>0 for x in rows),exhausted_negative_cases=sum(x['original_solution_count']==0 for x in rows),live_censuses=sum(x['live_census_count']for x in rows),plain_base_branch_attempts=sum(x['plain']['base_branch_attempts']for x in rows),marked_base_branch_attempts=sum(x['marked']['base_branch_attempts']for x in rows),marked_auxiliary_branch_attempts=sum(x['marked']['auxiliary_branch_attempts']for x in rows),logged_base_removals_on_auxiliary_placements=sum(len(x['marked']['logged_base_candidate_removals_on_auxiliary_placements'])for x in rows),plain_complete_seconds_sum=sum(x['plain_complete_seconds']for x in rows),cold_certified_pipeline_seconds_sum=sum(x['cold_certified_pipeline_seconds']for x in rows),runner_clock_terminal_seconds=t['runner_clock_elapsed_seconds'],worker_peak_bytes=r['worker_peak_bytes'],stored_expanded_bytes=r['logical_result_bytes'],conservative_pre_receipt_plus_reserve_bytes=r['conservative_physical_bytes'],root_callbacks_cutoff=h['root_check_calls'],call_started=h['call_started'],call_completed=h['call_completed'],call_raised=h['call_raised'],literal_observer_ROOT_resource_accepted=t['ROOT_resource_accepted'],literal_runner_resource_candidate_accepted=r['resource_candidate_accepted'],rows=rows,scope='Passive reading/counting of saved values/event IDs only; no point checker, theorem predicate, search, simulator or code from subject files executed. Counters reflect event occurrences, not unique clauses/reuses, general proof or speed benefit.')
(D/'ROOT-passive-saved-results-v1.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:x for k,x in v.items()if k not in('rows','call_started','call_completed','call_raised')},sort_keys=True))
