"""Passive publication: format saved JSON and copy/hash raw evidence; no subject calls."""
from pathlib import Path
import json, hashlib, html, tarfile, gzip, io
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
O=D/'publication';O.mkdir(exist_ok=True)
packet=json.loads((D/'actual-integration-v1/canonical-certified-point-search-integration.json').read_bytes())
metrics=json.loads((D/'ROOT-passive-saved-results-v1.json').read_bytes())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,v):
 (O/name).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def tex(f,variables):
 if f[0]=='var':return variables[f[1]]
 if f[0]=='not':return r'\neg '+tex(f[1],variables)
 op={'imp':r'\to','and':r'\land','or':r'\lor'}[f[0]]
 return r'\bigl('+tex(f[1],variables)+' '+op+' '+tex(f[2],variables)+r'\bigr)'
ordinals=['first','second','third','fourth','fifth','sixth','seventh','eighth']
def ordinal(i):return ordinals[i] if i<len(ordinals) else 'indexed '+str(i)
def assignment_reading(row,pi,original_id):
 meta=row['symbolic_metadata']
 if not meta:return 'Select this original point prototype.'
 base=row['model'];origin=base['required_centers'][pi];tile=next(t for t in base['tiles']if t['id']==original_id)
 values=[]
 for off,ch,v in tile['m']:
  target=[origin[0]+off[0],origin[1]+off[1]]
  if ch==meta['truth_channel']and target in meta['truth_points']:
   vi=meta['truth_points'].index(target);values.append('the '+ordinal(vi)+' variable is '+('true'if v else'false'))
 return ('Choose a variable value: 'if pi<len(meta['variable_roles'])else'Choose a satisfying local clause assignment: ')+', and '.join(values)+'.'
def translate_trace(row,lane):
 out=[];n=len(row['model']['required_centers']);mapping=row['compilation']['mapping'];basemap=dict(mapping['base_tiles']);auxmap={a[0]:a[1:]for a in mapping['auxiliary_tiles']}
 roles={a['role']:a for a in mapping['roles']}
 for i,e in enumerate(row[lane]['result']['trace']):
  k=e['kind'];reading=None
  if k in('branch','forced'):
   prefix='Try a branch. 'if k=='branch'else'The complete graph forces this placement. '
   if lane=='marked'and e['point']>=n:
    role,old,incoming,outgoing=auxmap[e['tile_id']];rr=roles[role]
    reading=prefix+'Place an auxiliary receptor for the '+ordinal(rr['clause'])+' failure certificate, reading the '+ordinal(rr['literal_index'])+' selected-support literal. Its exact type, choice and prefix values are in the saved event and prototype data.'
   else:
    old=basemap[e['tile_id']]if lane=='marked'else e['tile_id']
    reading=prefix+assignment_reading(row,e['point'],old)
  elif k=='census':
   decision=e.get('decision')
   reading={'DEAD':'The full point graph has an unfilled center with no compatible prototype.','COMPLETE':'All required centers are covered.','BRANCH':'No global dead or forced center remains; choose at the earliest generation.','FORCED':'At least one global forced center must be filled before branching.'}.get(decision,'Record the complete graph decision.')
  elif k=='rollback':reading='Undo placements and markings to this saved branch checkpoint.'
  elif k=='rollback_census':reading='Recheck the full graph after rollback.'
  elif k=='solution_candidate':reading='Return a complete finite placement candidate; the independent point checker checks it separately.'
  elif k=='enumeration_subtree_exhausted':reading='All recorded alternatives in this subtree have been traversed; return to its parent.'
  elif k=='raw_deadpoint_candidate':reading='Export an original-marking dead-point candidate for separate certification.'
  elif k=='raw_deadpoint_abstain':reading='No original-marking dead-point certificate is exported at this state.'
  elif k=='raw_deadpoint_acquisition_disabled':reading='Failure acquisition is disabled in this search lane.'
  elif k=='root_cleanup_complete':reading='Restore the original root graph and finish this search invocation.'
  assert reading is not None,('untranslated saved event',k)
  out.append({'index':i,'kind':k,'reading':reading})
 return out
rows=[]
for row in packet['rows']:
 lanes={}
 for lane in ('plain','acquisition','marked'):
  raw=row[lane];model=row['compilation']['instance']if lane=='marked'else row['model'];views=[]
  if raw['result']['solutions']:
   views.append({'label':'First checked complete certificate','scope':'A saved complete certificate and its independently checked raw marking section.','section':{'placements':raw['result']['solutions'][0]['placements'],'marks':raw['solution_checks'][0]['marks']}})
  for key,label in [('first_dead','First retained dead state'),('first_branch','First retained branch state'),('initial','Initial full graph'),('root_restored','Restored root')]:
   s=raw['retained_snapshots'].get(key)
   if s is not None:
    views.append({'label':label,'scope':'Selected placements and complete assigned marking section copied from the retained '+s['reason']+' snapshot. Full candidate bookkeeping remains in the evidence archive.','section':{'placements':[{'tile_id':c[2],'origin':model['required_centers'][c[1]]}for c in s['chosen']],'marks':s['marks']}})
  lanes[lane]={'views':views,'trace':raw['result']['trace'],'english_events':translate_trace(row,lane)}
 proofs=[]
 for i,p in enumerate(row['acquisition']['proofs']):
  c=p['candidate'];receipt=p['receipt']
  proofs.append({'label':'Checked failure certificate '+str(i+1),'reading':'An actual acquired dead point. Every original prototype has a checked unequal assigned marking against permanent original pins or compatible selected support. The forbidden support conjunction is valid only for this exact original instance.','clause':receipt['clause'],'witnesses':receipt['witnesses'],'center':c['center'],'source_snapshot_index':p['snapshot_index']})
 count=row['original_solution_count'];symbolic=row['input'].get('formula')
 reading=('The negation has no complete tiling; exhaustive finite search refutes it.'if symbolic and count==0 else str(count)+' original complete placement certificates; all populations agree.')
 rows.append({'id':row['id'],'input':row['input'],'formula_tex':tex(symbolic,row['input']['variables'])if symbolic else None,'reading':reading,'scope':'An input-specific finite Boolean factor encoding with long-range point markings. A complete refutation is not a serialized first-order kernel proof.'if row['symbolic_metadata']else'Exact finite point-domain control; no propositional inference interpretation is claimed.','model':row['model'],'marked_instance':row['compilation']['instance'],'mapping':row['compilation']['mapping'],'lanes':lanes,'proofs':proofs})
write('certified-failures-data.json',{'schema':'saved-certified-point-search-reader-v1','display_only':True,'subject_calls':0,'rows':rows})
summary={k:v for k,v in metrics.items()if k not in('rows',)}
summary.update({'rows':metrics['rows'],'adoption':json.loads((D/'ROOT-finite-integration-adoption-v1.json').read_bytes()),'claims':{'finite_integration_qualified':True,'search_benefit_observed':False,'single_fixed_FOL_palette':False,'serialized_FOL_proof_kernel_calls':0,'RL_trained':False,'Turtle_or_Penrose_search_in_this_run':False},'parallel_roles':{'implementation':'conventional_library','independent_census_and_certification':'benchmark_design','independent_saved_data_and_publication_review':'conventional_control_review','once_run_custody_and_report':'root'},'projection_scope':'Only saved JSON, event-ID classification, display formatting, raw file copying/hashing and archive verification. No search, mathematical checker or truth-table procedure is executed by the publication builder.'})
write('certified-failures-summary.json',summary)
M=lambda x:r'\('+str(x)+r'\)'
outcome='<p class="lead">Correctness integration passed. No search benefit was observed.</p><p>The complete declared bank contains '+M(23)+' cases and '+M(18)+' diagnostics. Search acquired '+M(13)+' independently checked primitive failure clauses. All '+M(37)+' original solutions were preserved, including complete agreement in '+M(5)+' exhausted negative cases. The independent checker audited '+M(829)+' normal live graph censuses.</p><p>Plain and compiled search each made '+M(54)+' base branch attempts. Auxiliary placements logged '+M(0)+' base-candidate removals. These are event counts in a single instrumented finite control, not an estimate of general proof-search performance.</p><p>The four familiar propositional examples below have unsatisfiable encoded negations. No proof or witness was supplied to search; the input negation clauses were authored and their truth equivalence was checked inside the run. This is automated finite propositional refutation, not new arithmetic or Hilbert theorem discovery.</p>'
comparison='<div class="wrap"><table><thead><tr><th>Observed measure</th><th>Plain complete search</th><th>Cold certified pipeline</th></tr></thead><tbody><tr><td>Summed per-case elapsed time</td><td>'+M(round(metrics['plain_complete_seconds_sum'],6))+' seconds</td><td>'+M(round(metrics['cold_certified_pipeline_seconds_sum'],6))+' seconds</td></tr><tr><td>Base branch attempts</td><td>'+M(54)+'</td><td>'+M(54)+' in its final marked search</td></tr><tr><td>Auxiliary branch attempts</td><td>Not applicable</td><td>'+M(0)+'</td></tr><tr><td>Base removals logged on auxiliary placements</td><td>Not applicable</td><td>'+M(0)+'</td></tr></tbody></table></div><p>The cold scope includes repeated original search and its certification, complete compilation and translation checking, fresh marked search and projection. Plain complete search includes its callbacks and returned-solution checks. These scopes differ by design; the saved per-case timings are a single run with no statistical speed claim.</p><p>The once-run terminal record closed in '+M(round(metrics['runner_clock_terminal_seconds'],6))+' seconds, with '+M(metrics['worker_peak_bytes'])+' bytes of worker peak memory and '+M(metrics['stored_expanded_bytes'])+' bytes stored and expanded. The conservative pre-receipt physical accounting plus reserve was '+M(metrics['conservative_pre_receipt_plus_reserve_bytes'])+' bytes. The original positive-result and cleanup windows were preserved. The literal observer’s <code>ROOT_resource_accepted</code> is false; the runner’s resource-candidate flag is true. Root adopted only the reviewed finite result.</p>'
next_section=r'''<section id="next"><h2>A concrete next experiment</h2><p>The saved data exposes a receptor selectivity gap. In one retained case, the referenced base point allowed \(2\) original types while its first receptor still allowed \(10\) choice values. The current auxiliary type reads a fresh choice channel but does not carry the original type’s role and truth markings. The choice channel therefore need not reveal the base domain before a base placement.</p><p>One proposed compiler variant would copy the referenced original type’s markings into the receptor at the corresponding absolute points. It would copy no positive support. The intended extension argument is that the existing choice equality already identifies that same original type in every complete solution. This is a Source-level proposal: it has not been implemented, independently qualified or measured. It may still give no benefit.</p><p>A fair next comparison must retain this exact original bank, full candidate universe and original resource ceilings, check extension and projection independently, and compare the same certificates in a conventional constraint engine. Acquisition and expansion costs must remain visible.</p></section><section id="parallel"><h2>How parallel work contributed</h2><p>One agent implemented the general point search; a second built the independent graph and primitive-certificate checks; a third reviewed the frozen Sources and saved result without replaying them. Root controlled the once-run execution and assembled this report. Their separate reviews covered \(130\) Source/prospective checks, \(45\) final grant-delta checks and \(1796\) saved-data checks, with no reported mismatches.</p><p>The point search and its checker were written separately against explicit APIs. During the bounded actual, other agents stopped tools. Parallel research resumed afterward. The division helps catch mistakes and keep representation, correctness, performance and full proof-system claims distinct; it does not itself establish a GCTS advantage.</p></section>'''
bridge_section=r'''<section id="fixed-checker-audit"><h2>A parallel audit of the single proof palette</h2><p>A separate Source-only audit examined the current full-checker lowering. Enumerating only retained local transition cases would avoid the old cubic loop’s rejected combinations. Its conditional manual size bound still exceeds \(2.7\) billion retained tiles, so this change alone would not solve the output-size problem. This bound is an unreviewed Source deduction, conditional on the unchanged lowering accepting the complete checker; no compiler or checker was run for this audit.</p><p>The existing Source already describes fixed and free postfix boundary bands. The current Wang compiler still pins a whole supplied initial word, so a faithful machine-only join that fixes the public theory and target while leaving only a certificate unknown remains absent. A fixed interpreter with an immutable checker program is a possible alternative, still unimplemented and requiring its own semantic and boundary correspondence. The pinned audit and plaintext Sources are in the evidence archive.</p></section>'''
page=(D/'certified-failures-template.html').read_text().replace('__OUTCOME__',outcome).replace('__COMPARISON__',comparison).replace('<section id="limits">',next_section+bridge_section+'<section id="limits">')
(O/'certified-failures.html').write_text(page)
# Preserve the isolated notebook exactly except for one visible append.
pre=(P/'reader.html').read_bytes();(D/'reader-preimage.html').write_bytes(pre)
assert pre.count(b'</main>')==1
append=r'''<section id="certified-point-failures"><h2>Failures compiled into actual point markings</h2><p>The <a href="certified-failures.html#reader">new saved search reader</a> shows the original and compiled markings, recorded decisions in English, and every prototype’s failure witness. The complete \(23\)-case, \(18\)-diagnostic run acquired \(13\) certified clauses and preserved all \(37\) original solutions. Correctness integration passed, but both plain and marked search made \(54\) base branch attempts; auxiliary placements removed no base candidates. The cold pipeline cost more.</p><p>Separate agents implemented the search, built its independent verifier, and reviewed the complete saved result. <a href="certified-failures.html#next">The next receptor proposal</a> responds to an observed selectivity gap and remains unimplemented. No fixed universal first-order palette, trained RL policy, arithmetic or Hilbert proof-search advantage is claimed.</p></section>'''.encode()
post=pre.replace(b'</main>',append+b'</main>');(O/'reader.html').write_bytes(post)
write('reader-append-custody.json',{'preimage':pin(D/'reader-preimage.html'),'postimage':pin(O/'reader.html'),'append_sha256':hashlib.sha256(append).hexdigest(),'append_bytes':len(append),'append_only_before_single_main_close':True})
# Raw allowlisted evidence; no project execution and no overview/index access.
files=[]
def add(label,p):
 p=Path(p);assert p.is_file();files.append((label,p))
for name in ['basic-tiling-algorithm-current.md','cohort-inputs-v1.json','qualify_certified_point_search_worker_v1.py','run_certified_point_search_once_v1.py','observe_certified_point_search_once_v1.py','author_inputs_v1.py','author_prospective_plan_v1.py','author_root_grant_v1.py','prepare_worker_prefix_v1.py','worker_prefix_v1.py.txt','worker_body_v1.py.txt','worker_main_v1.py.txt','freeze_worker_v1.py','prepare_outer_sources_v1.py','worker-Source-freeze-v1.json','Source-only-offer-v1.json','plan-false-v1.json','authorization-false-v1.json','plan-authorized-v1.json','authorization-once-v1.json','declaration-v1.json','runtime-closure-v1.json','ROOT-all-idle-fresh-barrier-v1.json','ROOT-grant-retirement-v1.json','ROOT-passive-saved-results-v1.json','ROOT-finite-integration-adoption-v1.json','ROOT-previous-turn-assessment-v1.json','project_saved_results_v1.py','build_saved_report_v1.py','certified-failures-template.html','reader-preimage.html']:
 add('Root/'+name,D/name)
for sub in ['actual-integration-v1','plan-authorized-v1-terminal-observation']:
 for p in sorted((D/sub).iterdir()):
  if p.is_file():add('Root/'+sub+'/'+p.name,p)
components=[('marking-compiler','/private/tmp/gcts-unit-center-receptor-library-20261019',['unit_center_marking_compiler_v1.py','API-v1.json','handoff-v1.json']),('point-verifier','/private/tmp/gcts-finite-marking-verifier-20261019-v1',['finite_marking_verifier_v1.py']),('point-search','/private/tmp/gcts-unit-center-point-search-20261019-v1',['unit_center_point_search_v1.py','API-v1.json','snapshot-API-v1.json','deadpoint-API-v1.json','handoff-v1.json']),('search-verifier','/private/tmp/gcts-unit-center-search-verifier-20261019-v1',['unit_center_search_verifier_v1.py','API-v1.json','handoff-v1.json']),('peer-reviews','/private/tmp/gcts-certified-point-search-peer-20261019-v1',['typed-certified-point-search-design-obligations-v1.json','typed-point-search-component-Source-review-v1.json','typed-certified-point-search-Source-prospective-review-v1.json','typed-final-grant-delta-review-v1.json','typed-saved-actual-review-v1.json']),('model-correspondence','/private/tmp/gcts-propositional-point-correspondence-peer-20261019-v1',['source-note-v1.json']),('selectivity-proposal','/private/tmp/gcts-receptor-selectivity-next-library-20261019-v1',['assessment-v1.json','handoff-v1.json'])]
for label,root,names in components:
 for name in names:add(label+'/'+name,Path(root)/name)
F=Path('/private/tmp/gcts-fixed-checker-feasibility-20261019-v1')
for name in ['handoff-v1.json','feasibility-note-v1.html','source-metadata-v1.json','fixed-checker-combined-plaintext-v1.tree']:
 add('fixed-checker-feasibility/'+name,F/name)
for key,row in json.loads((F/'source-metadata-v1.json').read_bytes())['pins'].items():
 p=Path(row['path']);assert str(p).startswith('/private/tmp/') and p.name!='index.html'
 assert pin(p)['sha256']==row['sha256'] and pin(p)['bytes']==row['bytes']
 add('fixed-checker-Sources/'+key+'/'+p.name,p)
paths=[{'archive_member':label,**pin(p)}for label,p in files]
pathmap=(json.dumps({'schema':'certified-point-evidence-pathmap-v1','members':paths},sort_keys=True,indent=2)+'\n').encode()
archive=O/'certified-failures-evidence.tar.gz'
with archive.open('wb')as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tf:
   for label,p in files+[('PATHMAP.json',None)]:
    b=pathmap if p is None else p.read_bytes();info=tarfile.TarInfo(label);info.size=len(b);info.mtime=0;info.mode=0o644;tf.addfile(info,io.BytesIO(b))
verified=[]
with tarfile.open(archive,'r:gz')as tf:
 assert tf.getnames()==[a for a,p in files]+['PATHMAP.json']
 for row in paths:
  b=tf.extractfile(row['archive_member']).read();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256'];verified.append(row['archive_member'])
manifest={'schema':'certified-point-publication-manifest-v1','raw_packet':metrics['raw_packet'],'summary':pin(O/'certified-failures-summary.json'),'reader_data':pin(O/'certified-failures-data.json'),'report':pin(O/'certified-failures.html'),'notebook':pin(O/'reader.html'),'evidence_archive':pin(archive),'archive_member_count':len(verified)+1,'all_decompressed_member_hashes_verified':True,'archive_members':paths,'reader_append_custody':json.loads((O/'reader-append-custody.json').read_bytes()),'publication_review_scope':'Detached exact review receipt is intentionally excluded to avoid recursive hashing. No subject code executed during report/archive projection.'}
write('certified-failures-manifest.json',manifest)
print(json.dumps({'output':str(O),'files':[{k:v for k,v in pin(p).items()}for p in sorted(O.iterdir())],'archive_members':len(verified)+1},sort_keys=True))
