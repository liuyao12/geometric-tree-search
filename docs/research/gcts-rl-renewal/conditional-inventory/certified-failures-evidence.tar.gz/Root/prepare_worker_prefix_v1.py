"""Raw Source author only; does not evaluate mathematical code."""
from pathlib import Path
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
s=Path('/private/tmp/gcts-marking-implementation-ROOT-20261019-v1/qualify_marking_worker_v1.py').read_text().split('def limits(s,role,work_one=False):')[0]
s=s.replace("VERSION = 'finite-point-marking-qualification-worker-v1'","VERSION = 'certified-finite-point-search-integration-worker-v1'")
s=s.replace("SOURCE_ROLES = ('worker', 'compiler', 'verifier', 'runner', 'observer')","SOURCE_ROLES = ('worker','compiler','verifier','search','census','runner','observer')")
start=s.index('SOURCE_PINS = ');end=s.index('\nOUTER_LIMITS',start)
s=s[:start]+"SOURCE_PINS = __SOURCE_PINS__\nINPUT_SHA = '73f8425e274e075293a858bf7d3ea4d3b6bcfc6f0bc95c3bdca9e90ac81a92a9'\nINPUT_BYTES = 19278\n"+s[end:]
s=s.replace("COMPONENT_LIMITS={role:dict(POINT_LIMITS)for role in('compiler','verifier')}","SEARCH_LIMITS=dict(work=400000000,centers=1024,tiles=100000,marks=1000000,candidates=1000000,dependencies=8000000,mark_points=1000000,integer_abs=1000000,string_chars=1024,data_depth=64,decisions=1000000,trace_rows=2000000,snapshot_items=40000000,trail_entries=2000000,solutions=10000,deadpoints=100000,witness_rows=1000000)\nCOMPONENT_LIMITS={role:dict(POINT_LIMITS if role in('compiler','verifier')else SEARCH_LIMITS)for role in('compiler','verifier','search','census')}")
a=s.index('    def own_oracle_limit(');b=s.index('    def call(',a);s=s[:a]+s[b:]
a=s.index("            if role=='oracle'and name=='audit_snapshot':");b=s.index('            self.fault_gate()',a);s=s[:a]+s[b:]
s=s.replace("        if role=='oracle'and name=='audit_snapshot':self.oracle_work+=value['audit_work']\n",'')
s=s.replace("name='wang_actual_'+role","name='certified_point_actual_'+role")
s=s.replace('Only future reviewed once-run execution may load/call the four components.','Only future reviewed once-run execution may load/call the four components.')
(D/'worker_prefix_v1.py.txt').write_text(s)
print('Raw worker prefix authored; no subject imports/calls.')
