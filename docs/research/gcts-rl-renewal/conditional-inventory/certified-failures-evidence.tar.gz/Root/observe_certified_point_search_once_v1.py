"""Observe one reviewed finite Wang encoding runner; no subject imports."""
import time
NOW=time.monotonic_ns
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

VERSION='certified-general-point-search-terminal-observer-v1'
PLAN_SCHEMA='ROOT-wang-encoding-qualification-plan-v1'
_METADATA_BYTES=0


def need(value,message):
    if not value:raise ValueError(message)


def descriptor(path,raw):
    return dict(path=str(Path(path).resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def checked(pin,cap=16777216):
    need(type(pin)is dict and set(pin)=={'path','bytes','sha256'}and
         type(pin['bytes'])is int and 0<=pin['bytes']<=cap,'strict bounded descriptor')
    p=Path(pin['path']);need(p.is_absolute()and p==p.resolve()and p.is_file()and not p.is_symlink(),
                            'canonical regular source')
    raw=p.read_bytes();need(descriptor(p,raw)==pin,'whole descriptor equality');return raw


def write_new(folder,name,value):
    global _METADATA_BYTES
    raw=json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\n'
    need(_METADATA_BYTES+len(raw)<=1048576,'aggregate observer metadata within1MiB')
    current=sum(f.stat().st_size for f in folder.iterdir()if f.is_file())
    need(current+len(raw)<=1048576,'all observer files/logs inside reserved1MiB')
    _METADATA_BYTES+=len(raw);p=folder/name
    fd=os.open(str(p),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())


def main(plan_path):
    started=NOW();p=Path(plan_path).resolve();raw=p.read_bytes()
    need(len(raw)<=16777216,'bounded plan');plan=json.loads(raw)
    need(plan['schema']==PLAN_SCHEMA and
         descriptor(__file__,Path(__file__).read_bytes())==plan['sources']['observer'],'exact current observer')
    checked(plan['python'],67108864);checked(plan['sources']['runner'])
    folder=p.parent/(p.stem+'-terminal-observation');folder.mkdir(mode=0o700)
    write_new(folder,'CONSUMED.json',dict(plan=descriptor(p,raw),maximum_runner_launches=1,
                                        observer_started_ns=started))
    command=[plan['python']['path'],'-I','-S','-B',plan['sources']['runner']['path'],str(p)]
    outcome=dict(schema='wang-encoding-terminal-observation-v1',version=VERSION,
        plan=descriptor(p,raw),observer_started_ns=started,command=command,
        scientific_acceptance=False,mathematical_proof_accepted=False,
        full_pipeline_qualified=False,ROOT_resource_accepted=False,terminal_gate_passed=False)
    with (folder/'stdout.bin').open('xb')as out,(folder/'stderr.bin').open('xb')as err:
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
        outcome['runner_pid']=process.pid
        try:code=process.wait(timeout=225)
        except subprocess.TimeoutExpired:
            process.kill();process.wait(timeout=5)
            outcome.update(error='runner observation timeout; no admission',
                runner_exit_code=process.returncode,terminal_observed_ns=NOW(),
                residual_worker_cleanup_requires_inspection=True)
            write_new(folder,'terminal.json',outcome);return 2
    observed=NOW()
    need(all((folder/(name+'.bin')).stat().st_size<=4194304 for name in('stdout','stderr')),
         'complete bounded captured runner logs')
    outcome.update(runner_exit_code=code,terminal_observed_ns=observed,
                   observed_instrument_elapsed_seconds=(observed-started)/1e9)
    actual=Path(plan['actual_directory']);rp=actual/'runner-receipt.json'
    if rp.is_file():
        receipt_raw=rp.read_bytes();need(len(receipt_raw)<=8388608,'bounded runner receipt')
        receipt=json.loads(receipt_raw);outcome['runner_receipt']=descriptor(rp,receipt_raw)
        outcome['runner_clock_elapsed_seconds']=(observed-receipt['began_ns'])/1e9
        outcome['terminal_gate_passed']=(code==0 and observed<receipt['overall_deadline_ns']and
            receipt['resource_candidate_accepted']is True and receipt['finite_encoding_candidate']is True and
            receipt['invocation_id']==plan['invocation_id']and receipt['worker_launch_attempts']==1 and
            receipt['worker_reaped']is True and receipt['owned_group_absent']is True and
            receipt['regular_logs_closed']is True and receipt['conservative_physical_bytes']<=134217728 and
            receipt['positive_result_read_completed_ns']<receipt['work_deadline_ns']and
            receipt['worker_terminal_observed_ns']<receipt['work_deadline_ns']and
            receipt['Native_calls']==0 and receipt['scientific_acceptance']is False and
            receipt['full_pipeline_qualified']is False and receipt['plan']==descriptor(p,raw)and
            not(actual/'POST_RECEIPT_DEADLINE_FAILURE.json').exists())
    outcome['scope']='Finite certified unit-center point search integration only; full FOL kernel and search advantage remain unqualified. Runner Source-entry epoch excludes observer/interpreter prelude. Standalone worker highwater has no Native/full-production fit authority.'
    write_new(folder,'terminal.json',outcome)
    print(json.dumps(dict(terminal=str(folder/'terminal.json'),runner_exit_code=code,
                         terminal_gate_passed=outcome['terminal_gate_passed']),sort_keys=True))
    return 0 if outcome['terminal_gate_passed']else 2


if __name__=='__main__':
    need(len(sys.argv)==2,'one reviewed once-plan path');raise SystemExit(main(sys.argv[1]))
