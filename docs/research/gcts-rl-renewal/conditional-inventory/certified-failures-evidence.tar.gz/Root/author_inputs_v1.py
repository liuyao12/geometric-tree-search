"""Ordinary declarative problem metadata only; no model compiler/solver/checker calls."""
from pathlib import Path
import json,hashlib
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
words=[[[0,False],[1,False]],[[0,False],[1,True]],[[0,True],[1,False]],[[0,True],[1,True]]]
cases=[]
for mask in range(16):
 cases.append(dict(id='two-variable-cnf-mask-'+str(mask).zfill(2),family='ALL_SUBSETS_OF_FOUR_SIGNED_BINARY_CLAUSES',variables=['p','q'],clauses=[words[i]for i in range(4)if mask&(1<<i)],formula=None,coordinate_profile='positive-line',kind='propositional'))
p=['var',0];q=['var',1];r=['var',2]
cases.extend([
 dict(id='implication-transitivity',family='SYMBOLIC_PROPOSITION_NEGATION',variables=['p','q','r'],clauses=[[[0,False],[1,True]],[[1,False],[2,True]],[[0,True]],[[2,False]]],formula=['imp',['and',['imp',p,q],['imp',q,r]],['imp',p,r]],coordinate_profile='positive-line',kind='propositional'),
 dict(id='disjunction-cases',family='SYMBOLIC_PROPOSITION_NEGATION',variables=['p','q','r'],clauses=[[[0,True],[1,True]],[[0,False],[2,True]],[[1,False],[2,True]],[[2,False]]],formula=['imp',['and',['or',p,q],['and',['imp',p,r],['imp',q,r]]],r],coordinate_profile='positive-line',kind='propositional'),
 dict(id='contraposition',family='SYMBOLIC_PROPOSITION_NEGATION',variables=['p','q'],clauses=[[[0,False],[1,True]],[[1,False]],[[0,True]]],formula=['imp',['imp',p,q],['imp',['not',q],['not',p]]],coordinate_profile='positive-line',kind='propositional'),
 dict(id='excluded-middle',family='SYMBOLIC_PROPOSITION_NEGATION',variables=['p'],clauses=[[[0,False]],[[0,True]]],formula=['or',p,['not',p]],coordinate_profile='positive-line',kind='propositional'),
 dict(id='negative-nonrectangular-origins',family='POINT_DOMAIN_CONTROL',variables=['p','q'],clauses=[words[0],words[1],words[2]],formula=None,coordinate_profile='negative-nonrectangular',kind='propositional')])
def raw_base(tiles,pins):return dict(schema='finite-unit-center-point-instance-v1',transformations='translations_only_2Z2',required_centers=[[0,0],[2,0]],admissible_origins=[[0,0],[2,0]],tiles=tiles,fixed_background_marks=pins,all_root_generations=0)
base_zero=raw_base([dict(id=0,t=[[[0,0],1]],m=[[[100,0],'remote',0]]),dict(id=7,t=[[[0,0],1]],m=[])],[[[100,0],'remote',1]])
base_overlap=raw_base([dict(id=0,t=[[[0,0],1]],m=[[[100,0],'remote',0],[[102,0],'remote',0]]),dict(id=7,t=[[[0,0],1]],m=[[[100,0],'remote',1],[[102,0],'remote',1]])],[])
cases.extend([dict(id='assigned-zero-and-absence',family='POINT_DOMAIN_CONTROL',kind='raw-point',base=base_zero),dict(id='remote-only-overlap',family='POINT_DOMAIN_CONTROL',kind='raw-point',base=base_overlap)])
ops=['search_owned_work','census_owned_work','search_foreign_check','search_foreign_observer','search_foreign_deadpoint','census_foreign_check','deadpoint_foreign_check','snapshot_missing_remote_dependency','snapshot_missing_candidate','snapshot_wrong_refcount','snapshot_wrong_scheduler','snapshot_wrong_parent_options','deadpoint_missing_witness','deadpoint_wrong_instance','deadpoint_wrong_blocker','deadpoint_exclusion_only_fake','invalid_boolean_mark_value','invalid_odd_origin']
value=dict(schema='ROOT-certified-point-search-inputs-v1',cases=cases,diagnostics=[dict(id='D'+str(i+1).zfill(2),operation=op)for i,op in enumerate(ops)],whole_population='Complete16subsets of the four ordered signed binary clauses over2variables, four named symbolic-proposition negation-CNF problems, one negative/nonrectangular coordinate transport and two raw-point semantic controls. No target witnesses, solution counts, labels or failure clauses supplied.',authority='New general-point search/certified-geometric-integration control, not a smaller replacement/rescue for old680+55. Input-specific propositional palettes are not one universal fixed FOL palette.',no_subject_calls_by_input_author=True)
pth=D/'cohort-inputs-v1.json'
with pth.open('x')as f:json.dump(value,f,indent=2,sort_keys=True)
raw=pth.read_bytes();print(json.dumps(dict(path=str(pth),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),cases=len(cases),diagnostics=len(ops)),sort_keys=True))
