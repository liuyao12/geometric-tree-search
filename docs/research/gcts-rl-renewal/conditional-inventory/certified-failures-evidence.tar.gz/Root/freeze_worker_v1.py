"""Raw Source assembly + AST/unused compile; no target evaluation."""
from pathlib import Path
import ast,hashlib,json
D=Path('/private/tmp/gcts-certified-point-search-ROOT-20261019-v1')
paths={'compiler':Path('/private/tmp/gcts-unit-center-receptor-library-20261019/unit_center_marking_compiler_v1.py'),'verifier':Path('/private/tmp/gcts-finite-marking-verifier-20261019-v1/finite_marking_verifier_v1.py'),'search':Path('/private/tmp/gcts-unit-center-point-search-20261019-v1/unit_center_point_search_v1.py'),'census':Path('/private/tmp/gcts-unit-center-search-verifier-20261019-v1/unit_center_search_verifier_v1.py')}
pins={role:(hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size)for role,p in paths.items()}
prefix=(D/'worker_prefix_v1.py.txt').read_text().replace('__SOURCE_PINS__',repr(pins))
main=(D/'worker_main_v1.py.txt').read_text().replace('proof_checker_calls','FOL_kernel_calls')
main=main.replace("same_instance_primitive_redundancy_candidate=True,certified_clauses=", "same_instance_primitive_redundancy_candidate=True,\n            graph_census_calls=s.started.get('census.audit_snapshot',0),primitive_certificate_calls=s.started.get('census.certify_deadpoint',0),\n            legacy_kernel_counter_scope='FOL_kernel_calls0; independent primitive certificates, point checks and actual Root truth/formula helpers are real work counted separately.',certified_clauses=")
s=prefix+(D/'worker_body_v1.py.txt').read_text()+'\n\n'+main
p=D/'qualify_certified_point_search_worker_v1.py'
assert not p.exists();p.write_text(s)
rows=[]
for role,path in dict(paths,worker=p).items():
 raw=path.read_bytes();tree=ast.parse(raw);compile(tree,str(path),'exec')
 rows.append(dict(role=role,path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),AST_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
receipt=dict(schema='ROOT-certified-point-worker-Source-freeze-v1',sources=rows,unused_compiles=len(rows),component_calls=0,actual_execution_authorized=False)
(D/'worker-Source-freeze-v1.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt,sort_keys=True))
