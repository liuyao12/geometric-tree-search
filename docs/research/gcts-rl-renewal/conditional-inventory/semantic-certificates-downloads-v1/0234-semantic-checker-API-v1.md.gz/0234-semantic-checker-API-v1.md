# Explicit semantic event checker: Source-only API

Status: **SOURCE_ONLY_NOT_IMPORTED_OR_EXECUTED**. Root and independent Source
review, prospective freezing, and fresh qualification are required before use.

Source: `source/semantic_event_checker_v1.py`.

```python
verify_explicit_events(model, result, *, max_items, max_work, wall_seconds)
```

The module imports only `hashlib`, `json`, `math`, and `time`. It does not import
the engine, an inventory/model helper, an old checker, or a native proof kernel.
It does not mutate caller-owned JSON. The method reads the unchanged
`IP-GROWING-POINT-SEARCH-v2` model/result ABI. No producer observations are
accepted or manufactured.

## First supported profile

- `Z-growing-point-model-v1`, complete `EXPLICIT` placements, integer positive
  capacity and units, unique literal point/CID identities, literal string
  markings, explicit roots and growing positive-support activation.
- Native integers are strict: booleans and floats cannot impersonate units,
  counts, generations, sequence numbers, or limit values. Marking `"0"` and
  `""` are assigned values; missing support remains unconstrained.
- No provider. `provider_evidence` is the exact empty explicit-mode protocol.
  The uninitialized mode is accepted only as a resource-limited raw prefix.
- No ordering callback: `stats.ordering_calls == 0`; each branch's complete
  `legal` and `order` must both equal the independently derived sorted domain.
- A completed raw result may report native integer `audit_calls` equal to zero
  or the full emitted event count. A raw `UNKNOWN` may report any integer from
  zero through its emitted count. These are metadata only: this method does
  not receive or claim to verify those audit observations.

Generic exact weighted support is allowed, including contributions smaller
than the residual capacity, candidates shared by several points, extended
mark-only effects, point-generation lowering, selected-at-most-once identity,
and all seed/root zero-key distinctions. No geometric predicate or independent
logical proof assumption is added.

## Independent reconstruction

The checker normalizes the complete explicit universe and builds its own
immutable positive/marking dependency indexes. Its own state holds totals,
marking assignments/reference counts, active generations, selected tile
generations, parent-local exclusions, global eligibility, complete domains,
weighted forward/reverse incidence, and historical loaded points. It applies
whole-support legality tests to every affected candidate and updates newly
active/completed points separately. Its reversible trail belongs solely to the
checker; no producer trail instruction count is inferred.

It checks global dead before global forced before the engine's exact
generation/degree/literal-point branch ordering. Branch exploration is binary:
select the first lexical candidate; after its selected child is completely
failed, restore the independent parent and locally exclude it. Scheduling then
starts afresh and may choose another point. Compact frame/event provenance
binds every exclusion. `UNKNOWN` children cannot justify exclusions.

Complete event bytes, consecutive sequence numbers, full stream hash, event
grammar, terminal/result association, and semantic counters are required for
`VERIFIED`. Missing event payload cannot be replaced by a claimed digest.

Actual saved entry, final, and restored endpoint payloads and their hashes are
compared with independent endpoint graphs. The checker preserves zero-valued
nonroot seed keys in totals, completed points in the active set, exact marking
reference counts, and loaded-point history. It never supplies its reconstructed
graph to the old full-observation checker's `graph_check` method.

Rollback metadata is separate. All retained rows must have exact types and
valid arithmetic. On complete replay, expected rollback total comes from the
checked event grammar, each retained failed-child row binds independently
restored parent/child selected counts, and the last expected row is final
restore to zero. A retained prefix is allowed with explicitly `PREFIX`
metadata coverage. Full rollback hash/edit sums are checked only when all rows
are retained. This does not establish physical intermediate trail correctness.

## Result schema and limits

Every answer has `status`, `reason`, `version`, `seconds`, `items`, `work`, and
`counts`. `bounded_absence` is false on every refusal/rejection. `VERIFIED`
answers additionally contain:

```text
run_status: SAT | UNSAT
claim: SEMANTIC_COMPLETE_SAT_CERTIFICATE |
       SEMANTIC_COMPLETE_FINITE_EXHAUSTION
bounded_absence: Boolean, true exactly for verified terminal UNSAT
model_sha256, event_sha256
event_coverage: COMPLETE
rollback_metadata_coverage: COMPLETE | PREFIX
reported_audit_calls
domains: INDEPENDENTLY_RECONSTRUCTED_COMPLETE
producer_intermediate_bookkeeping: NOT_CHECKED
endpoint_scope: ACTUAL_SERIALIZED_ENTRY_FINAL_RESTORED_ENDPOINTS
native_validity: SEPARATE_KERNEL_GATE
process_admission: SEPARATE_NATIVE_EXIT_AND_SOURCE_CUSTODY_GATE
failure_provenance, root_dead_event
dead_context_witnesses, dead_witness_coverage
scope
```

The counts are `decision_events_checked`, `semantic_states_reconstructed`,
`endpoint_snapshots_checked`, `placements_replayed`, `forced`, `branches`,
`dead`, `exclusions`, `solutions`, `exhausted`,
`independent_legality_checks`, `independent_edge_edits`,
`independent_undo_edits`, and `rollback_metadata_rows_checked`.
`decision_events_checked` counts every accepted event, including control and
placement events; it is not a count of physical producer graph observations.
There is deliberately no `graphs_checked` field.

`failure_provenance` has one compact record per checked exclusion:
`candidate`, `branch_event`, `dead_event`, `exclude_event`,
`parent_selected_count`, `parent_excluded_count`, and `context_scope`.
Together with the receipt's exact model and complete-event hashes, these
references identify the replayable parent context. They are not standalone
reusable nogood certificates.

The first at most sixteen dead events have a witness containing their actual
event sequence, exact dead point/generation, independently reconstructed
selected CID/generation pairs, excluded CIDs, and active point generations.
The `context_preimage` is explicitly versioned and bound to `model_sha256`;
`semantic_context_sha256` hashes canonical JSON plus LF. Totals and markings
are derivable from the seed and selected immutable rows. The witness includes
an exact zero legal-incident count and the size of the full static incident
bucket, but does not list every blocking reason. Retained/total/unshown counts
are explicit. The hash is a **semantic context** hash, not an observed producer
graph hash. Witnesses require the whole verified trace/model/exclusion
provenance and must not be activated as learned constraints by this checker.

`UNKNOWN` answers cover resource caps, incomplete initialization, incomplete
retained events, or raw `UNKNOWN`, even if a useful prefix was reconstructed.
They may expose prefix counts and declared coverage but never certify absence.
This first method does not salvage a raw resource-limited process into a clean
SAT/UNSAT execution. `REJECTED` means an actual retained contradiction or
malformed literal protocol. Native process exit/source admission is always a
separate gate; a semantic certificate alone does not prove a clean process.

`max_items` and `max_work` must be native positive integers; `wall_seconds`
must be finite and positive, with booleans rejected. Items conservatively count
input nodes/keys/string characters and cumulative owned storage insertions;
they are not an OS-memory measurement. Work charges repeated scans, literal
strings/keys, conservative pre-serialization bounds, sorting allowances,
independent graph/trail operations, witness exports, and hashing. Long loops
check time. JSON depth beyond 256, owned caps, memory failure, recursion failure,
or numeric overflow yield `UNKNOWN`; input is never silently truncated.
Suggested prospective qualification caps are 100 million items, one billion
work units, and thirty seconds, subject to Root's frozen protocol.

## Interpretation

A verified negative proves only exhaustion of the exact declared finite
explicit point model with its roots, growing activation, identity/multiplicity,
and frozen markings. It does not prove unrestricted logical nonprovability,
unmarked failure under learned restrictions, an infinite tiling theorem, or a
geometric statement without a separately admitted carrier. A verified positive
must still pass any native proof/reduction gate. Intermediate producer tables
remain unobserved; full-snapshot assurance is a separate stronger observation
lane. Acquisition, retention, preparation, and verification costs must all be
reported before drawing any practical performance conclusion.
