# What a fixed layer of equality markings can encode

This is a supplied design argument, not a general theorem discovered by the search program. Its small point-model example is a fresh qualification input; the predicted search behavior below has not yet been executed. It does not change an earlier archived result.

Fix the existing placement inventory, its positive point values, its seed and its allowed transformations. Give each placement a fixed partial marking function \(m_c:P\rightharpoonup V\), possibly with arbitrarily distant support and multiple channels. Marking agreement of a selected family means that every assigned value at the same point and channel agrees, including the seed's assignments.

**Pairwise obstruction lemma.** A marking-incompatible family contains either a single placement incompatible with the fixed seed, or a pair of placements with conflicting assigned values.

Indeed, incompatibility means that some point and channel receives two different assigned values. Those values come from two placements, or from a placement and the seed. Conversely, any such disagreement makes the family incompatible. No amount of extra marking reach changes this elementary property of fixed equality matching.

Consequently, suppose three placements \(A,B,C\) each occur with every other one in an accepted complete tiling that the added markings must preserve. Each is seed-compatible, and each pair must have compatible markings. Their entire marking union is then compatible. Such fixed markings cannot reject precisely the simultaneous choice \(\{A,B,C\}\) while preserving all those complete tilings. This conclusion concerns the added marking layer; positive capacity constraints and the candidate graph can already detect failures involving more than two placements.

## A concrete unmarked finite point model

Use capacity \(2\), explicit required roots \(a,b,c\), and initially empty total/mark seed. Every placement has empty marking support. The following lists its nonzero positive contributions; the subscripted filler identities denote two distinct declared candidates with the same positive support.

| Placement | Positive contributions |
| --- | --- |
| \(A\) | \(t_A(a)=2,\ t_A(p)=1\) |
| \(B\) | \(t_B(b)=2\) |
| \(C\) | \(t_C(c)=2\) |
| \(X_{a,1},X_{a,2}\) | \(t(a)=2,\ t(p)=2\) |
| \(X_{b,1},X_{b,2}\) | \(t(b)=2,\ t(p)=1\) |
| \(X_{c,1},X_{c,2}\) | \(t(c)=2,\ t(p)=1\) |

The candidate identities are distinct by declaration; two identical positive supports do not imply that both can be selected without exceeding capacity. This is an anchored abstract point model, not a claim about unrestricted placements of a conventional geometric tile.

Each distinguished pair extends to an exact solution: \(\{A,B,X_{c,i}\}\), \(\{A,C,X_{b,i}\}\), and \(\{B,C,X_{a,i}\}\), respectively. The triple \(\{A,B,C\}\) is capacity-legal but leaves \(T(p)=1\), and every filler is unavailable. It has no exact extension. Thus the marking obstruction lemma applies to a real failure of completion, rather than an inconsistent triple that the base overlap test already rejects.

For the executable fixture, the declared IDs sort in the order `00-A`, `10-B`, `20-C`, `30-xA1`, `31-xA2`, `40-xB1`, `41-xB2`, `50-xC1`, `51-xC2`. With the reference scheduler, the predicted first choices are \(A\), then \(B\), then \(C\). After \(A\), the new point \(p\) has generation \(1\), while the roots \(b,c\) retain generation \(0\). After \(B\), the two candidates at \(p\) do not outrank the three candidates at \(c\). Choosing \(C\) creates the dead point \(p\), justifying only a parent-local exclusion after rollback. The qualification will check this prediction against actual engine observations and independent complete enumeration.

## Consequence for the research program

A verified failed-parent certificate is useful, but it is not automatically a realizable fixed marking. A direct scanner for an arbitrary forbidden conjunction would be a different constraint filter. To encode genuinely higher-order conditions using equality ports, additional states, auxiliary placements or cluster interfaces may be required, together with a proof that projecting their tilings preserves the intended original solutions. Parameterized receptor families are therefore a substantive encoding direction, with a preservation obligation, rather than a cosmetic drawing choice.

Auxiliary-variable binary encodings are established constraint-programming methods; the hidden-variable and dual encodings represent permitted tuples through extra variables. See [Samaras and Stergiou, Binary Encodings](https://www.cs.cmu.edu/afs/cs/project/jair/pub/volume24/samaras05a-html/node6.html). A later paper formalizes a bidirectional hidden-variable transformation in Coq: [Dubois, 2020](https://arxiv.org/abs/2009.00583). These are precedents, not claims of novelty or formal verification of our implementation.

The next experiment should compare the same certified failure information as a direct constraint filter and as an independently validated point-mark/auxiliary-tile encoding. Both need the same base fallback, scheduler, native task and assurance. Whether the geometric representation makes search faster remains an empirical question.
