# Semantic assurance: immediate qualification and retrospective protocol

Status: **SOURCE_ONLY_PENDING_ROOT_REVIEW_AND_FREEZE**. No engine, oracle,
semantic checker or native checker has been imported or run for this protocol.
The completed CALv2 root, archive and mirror and all older studies are immutable.

Root authorized the lean first gate: qualify independent semantic replay, then
apply it to eight already saved, seen runs. This turn does **not** acquire a new
eight-case LEAN/FULL engine comparison. The earlier two-acquisition proposal is
preserved byte-for-byte in [deferred-comparison-proposal-v1.md](deferred-comparison-proposal-v1.md).
Its sixteen new acquisitions, engineering holdout and possible core-meter split
require a later, separate prospective freeze. They are not this execution plan.

## Objective and assurance boundary

Use the unchanged EXPLICIT-inventory point engine and its existing complete
control events. The independent verifier reconstructs legal domains from the
fixed whole universe, including weighted positive support, remote marking-only
support, assigned zero, generations and parent-local exclusions. It checks
whole-frontier dead ends, global forced moves and earliest-generation branching
in that order, with exact rollback of the reconstructed semantic state.

Distinguish these claims:

- A native positive certificate establishes a particular logical proof only
  after its separate decoder/native gates; it does not certify search absence.
- A complete independently checked semantic event stream can establish search
  decisions and finite exhaustion of the exact scoped point problem.
- Actual producer snapshots supply additional observed internal-map evidence.
  Reconstructed states alone do not observe every intermediate producer map.

Complete events can suffice even when retained physical rollback rows are a
prefix. That weaker metadata coverage must remain explicit. A missing event
suffix or a hash of unavailable events cannot establish a refutation. UNKNOWN
children never justify exclusions. A failed process and an independently valid
saved certificate remain separate statuses; no old archive label is overwritten.

The mathematical design is [incremental-verifier-design-v1.md](incremental-verifier-design-v1.md).
Do not pass a verifier-generated snapshot to the old snapshot checker and call
that an observation of the producer.

## Phase 0: prospective closure

Before any scientific execution, Root reads and freezes the exact master,
unchanged engine and old observed-snapshot checker, new semantic checker,
independent tiny oracle, all qualification data/mutation recipes, driver,
resource limits, runtime and new-root input manifest. Copy dependencies only
after verifying their published byte pins. No engine source changes or new
model-building helper is required for this first gate.

The master reference is `docs/basic-tiling-algorithm.md`, \(21{,}657\) bytes,
SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`.
The engine is `growing_point_search_v2.py`, \(39{,}556\) bytes, SHA256
`6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb`.
The old full-snapshot checker is \(27{,}040\) bytes, SHA256
`01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f`.

## Phase 1: fresh tiny semantic qualification

The complete prospective declaration is
[semantic-qualification-cases-v1.json](semantic-qualification-cases-v1.json).
It contains thirteen small generic point problems with at most sixteen CIDs each.
No selected solution, native proof or target search path is provided. Their
expected outcomes and required observations are analytic qualification gates,
not executed evidence.

Run each fixture **once**, using the unchanged engine with its actual full
snapshot audit callback. Persist the unmodified raw result and actual captured
event/snapshot pairs before running assurance. Use this same result for:

1. The new independent semantic event verifier.
2. The old checker over actual observed producer snapshots and endpoints.
3. Comparison with the independent all-subset point-assignment oracle's exact
   existence result, when its own bounded enumeration completes.

There is no extra audit-off repeat just to manufacture another timing sample.
The assignment oracle independently sums seed and selected integer units,
checks every marking value and exact active coverage, and requires positive
support reachability from roots or positive seed. It does not import producer,
semantic-checker or model-builder helpers and does not copy the scheduler.
A nonroot seed zero is not an active point. A CID is usable at most once.

Required coverage includes remote dead over singleton, global forced over
branch, genuine generation priority over smaller degree, generation lowering,
shared weighted contributions and unfillable residuals, literal zero versus
absence, remote mark-only conflicts, equal-value reference counts, nested
failure/exclusion, sibling revival, required seed zeros and disconnected
inventory. The unmarked ternary fixture tests a failed higher-order context
whose three constituent pairs can each occur in complete covers; its separate
fixed-marking expressivity argument is supplied human analysis, not an
automatically discovered theorem. Proof-slot models with all roots at generation zero cannot by
themselves qualify generation scheduling.

Qualification requires both semantic checkers' common decision claim and the
completed independent existence result to agree. Captured actual observations
must satisfy the declared coverage gates. A disagreement or resource refusal
is retained and blocks that qualification claim; do not replace a fixture or
retry until it passes.

### Mutation and refusal gates

Apply the declared recipes to detached copies of actual saved results only.
Where declared, refresh canonical event sequence/count/hash and endpoint hashes
so an omitted full legal member, wrong generation, bool/float integer surrogate,
truncated branch order, phantom/sibling exclusion, false exhaustion or changed
endpoint is rejected semantically rather than merely for stale bytes.

Separately preserve genuine prefix semantics: a dropped event suffix is UNKNOWN;
complete events plus prefix-only rollback metadata can remain VERIFIED with
explicitly weaker metadata coverage; raw UNKNOWN with a pending branch remains
UNKNOWN; verifier and assignment-oracle caps remain UNKNOWN. Missing mandatory
binding fields are malformed, never grounds for certified absence. Preserve
all actual mutation inputs and returned reasons. This phase supplies no
unbounded native nonprovability claim.

## Phase 2: eight saved, seen runs only

After qualification admission, verify the eight byte-pinned prior raw outputs
in this new root. Recovery owns their exact physical snapshots and manifest.
This phase does not import or call the engine and does not construct replacement
models, rerun searches, alter caps, borrow control proofs or import a selected
target proof as search input. Every source process status remains visible,
including the first run's `FAILED_POSTCHECK_AFTER_SCIENCE`, native exit one and
execution-not-admitted field.

The new independent verifier may establish a new scoped semantic receipt from
a complete historical stream. If a raw UNSAT passes, call it newly checked
finite exhaustion of that exact fixed point universe; retain the old
unassured absence label in historical evidence. Missing/incomplete evidence or
resource limits remain UNKNOWN. Existing positive native evidence may be
associated through exact byte-bound joins; it is not new proof discovery.

These are seen repeated bounds on a few target families, not an untouched
holdout, eight new theorems, a training set or an RL generalization result.
Prior conventional proofs are historical context, not search inputs or rerun
controls. No fair theorem-prover timing comparison is established here.

## Limits, persistence and costs

All exact limits must appear in the reviewed driver/protocol freeze. The
coordinated proposed tiny-engine limits are \(3\) seconds, `max_work=1000000000`,
`max_nodes=10000`, `max_events=10000`, `max_rollback_records=10000`,
`max_candidates=1000`, `max_points=128`; no retries or silent cap escalation.
The tiny oracle admits at most sixteen CIDs and \(65{,}536\) assignments with a
\(10\)-second guard. New semantic-checker proposal: `max_items=100000000`,
`max_work=10000000000`, \(30\) seconds. Root approved the owned phase guards of
\(1200\) seconds wall, \(900\) CPU seconds and \(1\) GiB polling RSS; these and all
exact driver limits must be frozen before execution. Retain refusal statuses
and only terminate/reap processes owned by this study.

Persist scientific raw bytes before assurance, then persist every assurance
result and completed/failed phase record. Capture failures cannot become
absence. There is one attempt per scheduled scientific phase, and a reviewed
repair must preserve the failed original instead of silently repeating it.

Measure actual new qualification/search capture, independent semantic replay,
extra observed-map checking, exhaustive oracle and outer-process cost separately.
For retrospective runs, new work is assurance only; old acquisition clocks
remain reused historical observations. Do not add overlapping clocks, subtract
unmeasured snapshot cost to invent core time, or claim a new cold search run.
The old mixed `work` includes evidence encoding and callback charges, so
historical counters are not interchangeable common-core budgets.

## Useful next output: bounded failed contexts

A complete checked failure can expose compact semantic contexts bound to the
literal model/universe, active obligations, selected/excluded CIDs, generations,
marking version, branch ancestry and declared proof bound. Earlier exclusions
must retain their checked failure dependencies. A small witnessed subset or
hash alone is not a standalone reusable theorem; UNKNOWN contexts never enter
a certified failure inventory.

These contexts enable the next GCTS experiment, but logical nogoods are not
automatically point markings. First prove projection/preservation for any
auxiliary-port/tile encoding, including multi-placement conjunctions. Old
tree-height failure ports do not automatically preserve shared-DAG line-bound
solutions. A later fair comparison should use the same native task, scope,
complete fallback and lean assurance for base search, certified marking pruning
and an ordinary direct filter using the identical certificates. Matching traces
would establish an encoding equivalence, not a distinctive GCTS advantage.
Validated receptor families and RL proposals follow only after that baseline;
no learned marking or RL is implemented by this protocol.
