"""Independent exhaustive finite unit-point oracle. No engine/adapter imports.

Choose an uncovered root in literal order, enumerate EVERY compatible incident
candidate, and stop only at a fully covered target. No GCTS decision scheduler,
proof heuristics, fact quotient or supplied witness is used. Limits stay UNKNOWN.
"""
import hashlib
import json
import math
import time


def wire(x):
    return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def solve(model, max_nodes=200000, wall_seconds=10.0, max_solutions=200000):
    started=time.perf_counter();nodes=0;solutions=[]
    class Limit(Exception):pass
    try:
        assert type(max_nodes) is int and max_nodes>0
        assert type(max_solutions) is int and max_solutions>0
        assert type(wall_seconds) in (int,float) and math.isfinite(wall_seconds) and 0<wall_seconds<=60
        assert model['schema']=='Z-growing-point-model-v1' and type(model['version']) is str and model['version']
        assert model['capacity']==1 and type(model['capacity']) is int
        assert model['inventory']['kind']=='EXPLICIT'
        roots=model['roots'];assert type(roots) is list and all(type(p) is str for p in roots) and len(roots)==len(set(roots))
        rows=model['inventory']['placements'];byid={r['id']:r for r in rows}
        assert len(byid)==len(rows)
        initial_t=dict(model['seed']['t']);initial_m=dict(model['seed']['m'])
        assert len(initial_t)==len(model['seed']['t']) and len(initial_m)==len(model['seed']['m'])
        assert all(type(p) is str for p in initial_t)
        assert all(type(p) is str and type(v) is str for p,v in initial_m.items())
        assert all(type(v) is int and v in (0,1) and (p in roots or v==0) for p,v in initial_t.items())
        incident={p:[] for p in roots}
        for r in rows:
            assert type(r['id']) is str and r['id'] and r['t']
            assert len(dict(r['t']))==len(r['t']) and len(dict(r['m']))==len(r['m'])
            for p,v in r['t']:
                assert type(p) is str and p in incident and type(v) is int and v==1
                incident[p].append(r['id'])
            assert all(type(p) is str and type(v) is str for p,v in r['m'])
        def visit(t,m,selected):
            nonlocal nodes
            nodes+=1
            if nodes>max_nodes or time.perf_counter()-started>wall_seconds:raise Limit()
            missing=sorted(p for p in roots if t.get(p,0)==0)
            if not missing:
                if len(solutions)>=max_solutions:raise Limit()
                solutions.append(sorted(selected));return
            for cid in sorted(incident[missing[0]]):
                r=byid[cid]
                if cid in selected or any(t.get(p,0)+v>1 for p,v in r['t']):continue
                if any(p in m and m[p]!=v for p,v in r['m']):continue
                nt=dict(t);nm=dict(m)
                for p,v in r['t']:nt[p]=nt.get(p,0)+v
                nm.update(r['m']);visit(nt,nm,selected+[cid])
        visit(initial_t,initial_m,[])
        assert len({wire(s) for s in solutions})==len(solutions)
        if time.perf_counter()-started>wall_seconds:raise Limit()
        result=dict(status='EXHAUSTED',exists=bool(solutions),solutions=solutions,nodes=nodes,
            model_sha256=hashlib.sha256(wire(model)).hexdigest(),seconds=time.perf_counter()-started)
        if time.perf_counter()-started>wall_seconds:raise Limit()
        return result
    except Limit:
        return dict(status='UNKNOWN',nodes=nodes,partial_solution_count=len(solutions),seconds=time.perf_counter()-started)
    except (MemoryError,RecursionError):
        return dict(status='UNKNOWN',nodes=nodes,reason='HOST_RESOURCE')
    except (AssertionError,KeyError,TypeError,ValueError,IndexError,AttributeError):
        return dict(status='REJECTED',nodes=nodes)


def selector_projections(encoded,max_selectors=12,max_nodes=500000,wall_seconds=10.0):
    """All selector subsets with existential CNF extension, independently.

    Generic recursive variable assignments with unit propagation. No control
    DPLL/certificate code is imported. Only tiny declared CNFs are eligible.
    """
    started=time.perf_counter();nodes=0;answers=[]
    class Limit(Exception):pass
    try:
        assert type(max_selectors) is int and 0<=max_selectors<=16 and type(max_nodes) is int and max_nodes>0
        assert type(wall_seconds) in (int,float) and math.isfinite(wall_seconds) and 0<wall_seconds<=60
        selectors=encoded['selector_variables'];clauses=encoded['clauses'];n=encoded['nvars']
        assert type(selectors) is list and len(selectors)<=max_selectors and type(n) is int and 0<=n<=200
        assert all(type(r) is list and len(r)==2 and type(r[0]) is str and type(r[1]) is int and 1<=r[1]<=n for r in selectors)
        assert len({r[0] for r in selectors})==len(selectors) and len({r[1] for r in selectors})==len(selectors)
        assert type(clauses) is list and all(type(c) is list and all(type(l) is int and 0<abs(l)<=n for l in c) for c in clauses)
        def extension(assignment):
            nonlocal nodes
            nodes+=1
            if nodes>max_nodes or time.perf_counter()-started>wall_seconds:raise Limit()
            while True:
                remaining=[];units=[]
                for clause in clauses:
                    if time.perf_counter()-started>wall_seconds:raise Limit()
                    if any(abs(l) in assignment and assignment[abs(l)]==int(l>0) for l in clause):continue
                    opened=set(l for l in clause if abs(l) not in assignment)
                    if not opened:return False
                    remaining.append(opened)
                    if len(opened)==1:units.append(next(iter(opened)))
                if not remaining:return True
                if not units:break
                for l in units:
                    if abs(l) in assignment and assignment[abs(l)]!=int(l>0):return False
                    assignment[abs(l)]=int(l>0)
            v=min(abs(l) for c in remaining for l in c)
            return any(extension({**assignment,v:b}) for b in (1,0))
        for mask in range(1<<len(selectors)):
            if time.perf_counter()-started>wall_seconds:raise Limit()
            if extension({v:(mask>>i)&1 for i,(cid,v) in enumerate(selectors)}):
                answers.append(sorted(cid for i,(cid,v) in enumerate(selectors) if (mask>>i)&1))
        if time.perf_counter()-started>wall_seconds:raise Limit()
        return dict(status='EXHAUSTED',solutions=answers,nodes=nodes,seconds=time.perf_counter()-started)
    except Limit:return dict(status='UNKNOWN',nodes=nodes,partial_solution_count=len(answers))
    except (MemoryError,RecursionError):return dict(status='UNKNOWN',nodes=nodes,reason='HOST_RESOURCE')
    except (AssertionError,KeyError,TypeError,ValueError,IndexError,AttributeError):return dict(status='REJECTED',nodes=nodes)
