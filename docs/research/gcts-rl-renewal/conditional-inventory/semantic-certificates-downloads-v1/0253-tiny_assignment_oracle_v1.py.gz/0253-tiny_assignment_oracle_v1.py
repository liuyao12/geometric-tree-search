"""Independent exhaustive assignment oracle for tiny explicit point problems.

No engine, semantic checker, producer, model-builder or scheduler imports.
Enumerate every candidate subset, sum literal point units, check whole marking
agreement and exact active coverage, then require support reachability from
roots/positive seed. This deliberately does not reproduce GCTS decisions.
The preserved old unit-root-only oracle is reference material, not imported.
"""
import hashlib
import json
import math
import time


VERSION = 'Tiny-explicit-assignment-oracle-v1'


class _Invalid(Exception):
    pass


class _Limit(Exception):
    pass


def _require(ok, why):
    if not ok:
        raise _Invalid(why)


def solve(model, max_candidates=16, max_assignments=65536, wall_seconds=10.0,
          max_items=200000, max_work=10000000):
    """Return EXHAUSTED/UNKNOWN/REJECTED; only EXHAUSTED decides existence.

    A solution uses each CID at most once. Its active points are explicit roots,
    positive seed support and all selected positive support. Nonroot seed zeros
    are stored capacity data but do not activate points. Every selected tile
    must be reachable by positive-support contacts from the initially active
    points. Final legality is monotone, so such a contact order is a legal
    growing attachment order. No generation/scheduler claim is made here.
    """
    started = time.perf_counter()
    assignments = 0
    work = 0
    items = 0
    solutions = []
    model_sha = None

    def tick(n=1):
        nonlocal work
        work += n
        if work > max_work:
            raise _Limit('MAX_WORK')
        if time.perf_counter() - started >= wall_seconds:
            raise _Limit('WALL_SECONDS')

    def scan(value, depth=0):
        nonlocal items
        items += 1
        if items > max_items or depth > 64:
            raise _Limit('INPUT_BOUND')
        tick()
        if type(value) is str:
            tick(len(value))
        elif type(value) is int:
            tick(value.bit_length())
        elif value is None or type(value) is bool:
            pass
        elif type(value) is list:
            for v in value:
                scan(v, depth + 1)
        elif type(value) is dict:
            for k, v in value.items():
                _require(type(k) is str, 'literal dictionary key')
                scan(k, depth + 1)
                scan(v, depth + 1)
        else:
            raise _Invalid('non-JSON literal')

    def fields(value, names):
        _require(type(value) is dict and set(value) == set(names),
                 'exact fields: ' + ','.join(names))

    def rows(value, capacity, marking=False, seed=False):
        _require(type(value) is list, 'literal row list')
        out = {}
        for row in value:
            tick()
            _require(type(row) is list and len(row) == 2
                     and type(row[0]) is str and row[0] not in out,
                     'distinct literal point row')
            p, v = row
            if marking:
                _require(type(v) is str, 'literal marking value')
            else:
                _require(type(v) is int and (0 if seed else 1) <= v <= capacity
                         and v.bit_length() <= 256, 'exact capacity units')
            out[p] = v
        return out

    def finish(status, **extra):
        return dict(schema='Tiny-explicit-assignment-receipt-v1',
                    oracle=VERSION, status=status, model_sha256=model_sha,
                    assignments_checked=assignments, work=work,
                    seconds=time.perf_counter() - started, **extra)

    try:
        for name, value, lo, hi in (
                ('max_candidates', max_candidates, 0, 16),
                ('max_assignments', max_assignments, 0, 65536),
                ('max_items', max_items, 1, 1000000),
                ('max_work', max_work, 0, 1000000000)):
            _require(type(value) is int and lo <= value <= hi, name)
        _require(type(wall_seconds) in (int, float)
                 and math.isfinite(wall_seconds) and 0 < wall_seconds <= 60,
                 'wall_seconds')
        scan(model)
        fields(model, ('schema', 'version', 'capacity', 'roots', 'seed', 'inventory'))
        _require(model['schema'] == 'Z-growing-point-model-v1'
                 and type(model['version']) is str and bool(model['version']),
                 'model schema/version')
        capacity = model['capacity']
        _require(type(capacity) is int and capacity >= 1
                 and capacity.bit_length() <= 256, 'capacity')
        roots = model['roots']
        _require(type(roots) is list and all(type(p) is str for p in roots)
                 and len(roots) == len(set(roots)), 'distinct roots')
        fields(model['seed'], ('t', 'm'))
        seed_t = rows(model['seed']['t'], capacity, seed=True)
        seed_m = rows(model['seed']['m'], capacity, marking=True)
        fields(model['inventory'], ('kind', 'placements'))
        _require(model['inventory']['kind'] == 'EXPLICIT'
                 and type(model['inventory']['placements']) is list, 'explicit inventory')
        raw = model['inventory']['placements']
        if len(raw) > max_candidates:
            raise _Limit('MAX_CANDIDATES')
        inventory = []
        ids = set()
        for row in raw:
            tick()
            fields(row, ('id', 't', 'm'))
            cid = row['id']
            _require(type(cid) is str and bool(cid) and cid not in ids,
                     'distinct nonempty CID')
            ids.add(cid)
            t = rows(row['t'], capacity)
            _require(bool(t), 'nonempty positive support')
            m = rows(row['m'], capacity, marking=True)
            inventory.append((cid, t, m))
        inventory.sort(key=lambda x: x[0])
        normalized = dict(schema=model['schema'], version=model['version'],
                          capacity=capacity, roots=sorted(roots),
                          seed=dict(t=[[p,v] for p,v in sorted(seed_t.items())],
                                    m=[[p,v] for p,v in sorted(seed_m.items())]),
                          inventory=dict(kind='EXPLICIT', placements=[
                              dict(id=cid,t=[[p,v] for p,v in sorted(t.items())],
                                   m=[[p,v] for p,v in sorted(m.items())])
                              for cid,t,m in inventory]))
        encoded = (json.dumps(normalized, sort_keys=True, ensure_ascii=True,
                              separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
        tick(len(encoded))
        model_sha = hashlib.sha256(encoded).hexdigest()
        initial = set(roots) | {p for p,v in seed_t.items() if v > 0}
        count = 1 << len(inventory)
        for mask in range(count):
            tick()
            if assignments >= max_assignments:
                raise _Limit('MAX_ASSIGNMENTS')
            assignments += 1
            chosen = [row for i,row in enumerate(inventory) if mask & (1 << i)]
            totals = dict(seed_t)
            marks = dict(seed_m)
            active = set(initial)
            compatible = True
            for cid, t, m in chosen:
                for p,v in t.items():
                    tick()
                    active.add(p)
                    totals[p] = totals.get(p, 0) + v
                    if totals[p] > capacity:
                        compatible = False
                for p,v in m.items():
                    tick()
                    if p in marks and marks[p] != v:
                        compatible = False
                    marks[p] = v
            if not compatible or any(totals.get(p,0) != capacity for p in active):
                continue
            reached = set(initial)
            pending = list(chosen)
            while pending:
                advanced = False
                rest = []
                for row in pending:
                    tick(1 + len(row[1]))
                    if any(p in reached for p in row[1]):
                        reached.update(row[1])
                        advanced = True
                    else:
                        rest.append(row)
                pending = rest
                if not advanced:
                    break
            if pending:
                continue
            solutions.append([row[0] for row in chosen])
        tick()
        return finish('EXHAUSTED', exists=bool(solutions), solutions=solutions,
                      candidate_count=len(inventory), subsets_total=count,
                      claim='COMPLETE_REACHABLE_FINITE_ASSIGNMENT_EXISTENCE_ONLY')
    except _Limit as error:
        return finish('UNKNOWN', reason=str(error), exists=None,
                      witness_exists=bool(solutions), partial_solution_count=len(solutions))
    except (MemoryError, RecursionError):
        return finish('UNKNOWN', reason='HOST_RESOURCE', exists=None,
                      witness_exists=bool(solutions), partial_solution_count=len(solutions))
    except (_Invalid, KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
        return finish('REJECTED', reason=str(error), exists=None)
