"""Pure saved-data mutation builder for the declared tiny qualification set.

No engine/oracle/checker/model-helper imports or execution. Every packet is
explicitly a detached MUTATION_ONLY_NOT_AN_EXECUTED_RUN object. Missing actual
anchors raise ValueError: no fake trace is manufactured to claim coverage.
"""
import copy
import hashlib
import json


def _need(ok, why):
    if not ok:
        raise ValueError('NOT_EXERCISED: ' + why)


def _wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def _digest(value):
    return hashlib.sha256(_wire(value)).hexdigest()


def _stream(rows):
    h = hashlib.sha256()
    for row in rows:
        h.update(_wire(row))
    return h.hexdigest()


def _event(result, kind, candidate=None):
    found = [row for row in result['events'] if row['kind'] == kind
             and (candidate is None or row['candidate'] == candidate)]
    _need(bool(found), 'actual event ' + kind + ' / ' + str(candidate))
    return found[0]


def _full_events(result, renumber=True):
    rows = result['events']
    if renumber:
        for i, row in enumerate(rows):
            row['seq'] = i
    n = len(rows)
    result['event_extent'].update(total=n, retained=n, sha256=_stream(rows))
    result['stats']['events_total'] = n
    result['stats']['audit_calls'] = n if result['stats']['audit_calls'] else 0
    result['limits']['max_events'] = max(n, result['limits']['max_events'])


def _endpoint(result, name):
    value = result[name + '_state']
    _need(type(value) is dict, 'actual ' + name + ' endpoint')
    result['state_hashes'][name] = _digest(value)


def build(models, results, declarations):
    """Build all declared mutants from saved actual originals, without checking.

    Returns list of {id,case_id,model,result,expected_status,target,scope,...}.
    target is SEMANTIC except the explicit ASSIGNMENT_ORACLE refusal. Optional
    limits_override applies to the indicated checker/oracle only. The caller
    must save each packet BEFORE obtaining its returned assurance result.
    """
    _need(type(models) is dict and type(results) is dict, 'model/result maps')
    _need(type(declarations) is list and len(declarations) <= 128, 'declaration list')
    packets = []
    seen = set()
    for declaration in declarations:
        mid, cid, op = declaration['id'], declaration['case_id'], declaration['operation']
        _need(type(mid) is str and mid not in seen, 'unique mutation id')
        seen.add(mid)
        _need(cid in models and cid in results, 'actual case ' + cid)
        model, result = copy.deepcopy(models[cid]), copy.deepcopy(results[cid])
        _need(model['inventory']['kind'] == 'EXPLICIT'
              and len(model['inventory']['placements']) <= 16, 'tiny explicit universe')
        _need(result['status'] in ('SAT', 'UNSAT')
              and result['event_extent']['total'] == len(result['events']),
              'original complete terminal result')
        packet = dict(id=mid, case_id=cid, model=model, result=result,
                      expected_status=declaration['expected'], target='SEMANTIC',
                      operation=op, scope='MUTATION_ONLY_NOT_AN_EXECUTED_RUN')
        _need(packet['expected_status'] in ('VERIFIED', 'REJECTED', 'UNKNOWN'),
              'expected status')

        if op == 'FIRST_BRANCH_REMOVE_LAST_FROM_BOTH_LEGAL_AND_ORDER_REHASH_FULL':
            data = _event(result, 'BRANCH')['data']
            _need(len(data['legal']) >= 2 and data['legal'] == data['order'], 'full branch domain')
            removed = data['legal'].pop()
            _need(data['order'].pop() == removed, 'same nonchosen omitted CID')
            _full_events(result)
        elif op == 'FIRST_BRANCH_DROP_LAST_ORDER_REHASH_FULL':
            data = _event(result, 'BRANCH')['data']
            _need(len(data['order']) >= 2, 'nontrivial branch order')
            data['order'].pop()
            _full_events(result)
        elif op in ('FIRST_PLACED_INCREMENT_GENERATION_REHASH_FULL',
                    'FIRST_PLACED_SET_GENERATION_TRUE_REHASH_FULL',
                    'FIRST_PLACED_SET_GENERATION_FLOAT_ONE_REHASH_FULL'):
            data = _event(result, 'PLACED')['data']
            _need(type(data['generation']) is int, 'actual native generation')
            if op == 'FIRST_PLACED_INCREMENT_GENERATION_REHASH_FULL':
                data['generation'] += 1
            else:
                _need(data['generation'] == 1, 'native generation one type-forgery anchor')
                data['generation'] = True if 'TRUE' in op else 1.0
            _full_events(result)
        elif op == 'READY_SEQ_FALSE_REHASH_WITHOUT_RENUMBER':
            _need(result['events'][0]['kind'] == 'READY'
                  and type(result['events'][0]['seq']) is int
                  and result['events'][0]['seq'] == 0, 'actual READY zero')
            result['events'][0]['seq'] = False
            _full_events(result, renumber=False)
        elif op == 'FIRST_DEAD_REPLACE_WITH_FORCED_A_ONLY_REHASH_FULL':
            row = _event(result, 'DEAD')
            _need(row['point'] == 'z-dead', 'remote dead anchor')
            row.update(kind='FORCED', point='a-forced', candidate='only-a',
                       data=dict(generation=0))
            _full_events(result)
        elif op == 'FIRST_BRANCH_REPLACE_WITH_X_LATE_DOMAIN_REHASH_FULL':
            row = _event(result, 'BRANCH')
            _need(row['point'] == 'a-early', 'old point branch anchor')
            row.update(point='x-late', candidate=None,
                       data=dict(generation=1, legal=['20-x', '21-x'],
                                 order=['20-x', '21-x']))
            _full_events(result)
        elif op == 'ENTRY_FORWARD_SHARED_B_WEIGHT_SET_ONE_AND_REFRESH_ENTRY_HASH':
            rows = result['entry_state']['forward']
            found = [row for row in rows if row[:2] == ['b', 'a-shared']]
            _need(len(found) == 1 and found[0][2] == 2, 'actual shared weighted edge')
            found[0][2] = 1
            _endpoint(result, 'entry')
        elif op == 'ENTRY_DROP_REMOTE_MARK_AND_REFRESH_ENTRY_HASH':
            marks = result['entry_state']['marks']
            found = [row for row in marks if row == ['remote-port', '0', 1]]
            _need(len(found) == 1, 'actual remote zero seed')
            marks.remove(found[0])
            _endpoint(result, 'entry')
        elif op == 'INSERT_EXCLUDE_A0_AFTER_READY_REHASH_FULL':
            _need(result['events'][0]['kind'] == 'READY', 'actual READY')
            result['events'].insert(1, dict(seq=1, kind='EXCLUDE', point=None,
                                           candidate='a0', data={}))
            _full_events(result)
        elif op == 'REPLACE_FIRST_DECISION_WITH_EXHAUSTED_REHASH_FULL':
            _need(len(result['events']) >= 2 and result['events'][0]['kind'] == 'READY',
                  'actual nonempty decision prefix')
            result['events'][1].update(kind='EXHAUSTED', point=None, candidate=None, data={})
            _full_events(result)
        elif op == 'SECOND_EXCLUDE_A0_REPLACE_CANDIDATE_B0_REHASH_FULL':
            rows = [row for row in result['events'] if row['kind'] == 'EXCLUDE']
            _need(len(rows) >= 2 and rows[0]['candidate'] == 'b0'
                  and rows[1]['candidate'] == 'a0', 'nested exclusion ancestry')
            rows[1]['candidate'] = 'b0'
            _full_events(result)
        elif op == 'RESTORED_MARK_ZERO_REFCOUNT_INCREMENT_AND_REFRESH_RESTORED_HASH':
            rows = result['restored_state']['marks']
            found = [row for row in rows if row[:2] == ['literal-zero', '0']]
            _need(len(found) == 1 and found[0][2] == 1, 'restored seed refcount one')
            found[0][2] += 1
            _endpoint(result, 'restored')
        elif op == 'DROP_FINAL_EVENT_KEEP_ORIGINAL_EVENT_EXTENT_TOTAL_AND_DIGEST':
            _need(result['events'][-1]['kind'] == 'EXHAUSTED', 'actual final exhaustion')
            result['events'].pop()
            result['event_extent']['retained'] = len(result['events'])
            result['limits']['max_events'] = len(result['events'])
        elif op == 'DELETE_EVENT_EXTENT_SHA256':
            _need('sha256' in result['event_extent'], 'actual stream digest')
            del result['event_extent']['sha256']
        elif op == 'KEEP_FULL_EVENTS_DROP_ALL_ROLLBACK_ROWS_RETAIN_TOTAL_AND_DIGEST':
            _need(result['rollback_extent']['total'] > 0, 'actual rollback metadata')
            result['rollback_records'] = []
            result['rollback_extent']['retained'] = 0
            result['limits']['max_rollback_records'] = 0
            packet['required_scope'] = 'COMPLETE_EVENTS_WITH_PREFIX_ROLLBACK_METADATA'
        elif op == 'KEEP_PREFIX_THROUGH_FIRST_BRANCH_SET_RAW_UNKNOWN_KEEP_TRUE_PREFIX_EXTENT_AND_NULL_FINAL_CERTIFICATE':
            row = _event(result, 'BRANCH')
            at = result['events'].index(row)
            result['events'] = result['events'][:at + 1]
            result.update(status='UNKNOWN', reason='QUALIFICATION_UNKNOWN_PENDING_PREFIX',
                          selected=[], certificate=None, final_state=None)
            result['state_hashes']['final'] = None
            _full_events(result)
            # Hide original suffix cleanup rows rather than pretend they describe
            # the changed pending prefix; the optional metadata stays a prefix.
            result['rollback_records'] = []
            result['rollback_extent']['retained'] = 0
            result['limits']['max_rollback_records'] = 0
        elif op == 'UNCHANGED_INPUT_VERIFY_MAX_WORK_ONE':
            packet['limits_override'] = dict(max_work=1)
        elif op == 'UNCHANGED_MODEL_ORACLE_MAX_ASSIGNMENTS_ZERO':
            packet['target'] = 'ASSIGNMENT_ORACLE'
            packet['limits_override'] = dict(max_assignments=0)
        else:
            raise ValueError('NOT_EXERCISED: unknown operation ' + str(op))
        packets.append(packet)
    return packets
