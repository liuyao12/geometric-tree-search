# A higher-order failure that fixed literal markings cannot directly reject

Status: **SUPPLIED_MATHEMATICAL_ANALYSIS_NOT_AN_AUTOMATIC_DISCOVERY**.
This is an analytic interpretation of prospective fixture
`sq13-unmarked-ternary-failure`; no engine or exhaustive oracle has run here.
No selected solution or proof of an expected search path is an engine input.

Let the point capacity be \(2\), with roots \(a,b,c\). The three distinguished
placements have nonzero contributions

\[
t_A(a)=2,\quad t_A(p)=1,\qquad t_B(b)=2,\qquad t_C(c)=2.
\]

Two distinct copies of each filler type are in the explicit inventory:
\(X_A\) contributes \(2\) at both \(a,p\); \(X_B\) contributes \(2\) at
\(b\) and \(1\) at \(p\); \(X_C\) contributes \(2\) at \(c\) and \(1\)
at \(p\). Initially every marking is absent. Their duplicated identities make
the relevant remaining domains non-singleton; they do not allow repeated use
of any one CID.

Each distinguished pair occurs in an exact active-obligation cover:
\(A,B\) can be extended with an \(X_C\), \(A,C\) with an \(X_B\), and
\(B,C\) with an \(X_A\). These examples establish the analytic premise of the
lemma; they are not passed as selected witnesses to search. In contrast,
\(A,B,C\) is capacity-legal but contributes only \(1\) at its newly activated
point \(p\). Every remaining filler would overfill one of the saturated roots.
Thus this triple has no exact extension in the fixed inventory.

**Restricted expressivity lemma.** Suppose one assigns a fixed literal marking
to every existing placement, possibly at arbitrarily remote points, while
retaining the same positive contributions and introducing no auxiliary tiles
or ports with independent state. If all three pair-containing covers above
remain valid, marking agreement alone cannot reject the partial triple
\(A,B,C\).

**Proof.** Preservation of the first cover implies that every shared assigned
component of \(A\) and \(B\) agrees. The other two covers imply the same for
\(A,C\) and \(B,C\). Literal marking compatibility is pairwise equality on
overlapping assigned components; an absent component is unconstrained.
Consequently their three-way union agrees at every component. The triple also
remains capacity-legal because its positive contributions were unchanged.
Hence fixed literal agreement cannot directly prohibit that partial triple.
The search can still find its later residual dead end. This proves only the
stated expressivity limitation, not failure of all possible GCTS encodings.

The limitation motivates explicit auxiliary/context encodings or certified
conditional failure receptors. Those require their own solution-projection
argument. A general forbidden conjunction must not silently be relabeled as
an ordinary fixed pairwise marking. No novelty, learned restriction, universal
proof system or performance conclusion is claimed by this supplied argument.
