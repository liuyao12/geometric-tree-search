# Lean semantic assurance first; internal mutation observation later

Status: design only, requiring Root review before implementation. No engine, model builder, solver, native checker or historical target proof was imported or executed. No past run or archive was changed. This note is coordinated with the separate independent verifier and benchmark designs in this new directory.

The complete inspected engine is `growing_point_search_v2.py`, 39,556 bytes, SHA256 `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb`; the inspected current/copied master is 21,657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. The engine was read as Source, including normalization, every `_State` mutation, `_Events.emit`, `_search` and `solve` cleanup. No assumption is made that a retained event array is complete.

## First deliverable needs no engine modification

Implement and qualify a new independent semantic-certificate reader for the existing **complete EXPLICIT-inventory event stream**, ordered rollback metadata and actual entry/final/restored endpoint payloads. It maintains its own point state, complete candidate incidence and branch stack; it must import no engine helpers. This can certify the legality and completeness of decisions and finite exhaustion. It is a different assurance claim from checking every observed producer graph snapshot.

Existing events contain the information needed for that first claim. `BRANCH` fixes the complete legal domain/order and saves an independent parent context; its first candidate is pending until `PLACED`. `DEAD` establishes a failed residual context. `EXCLUDE` identifies which most-recent branch child was undone and locally excluded. The reader restores its own saved parent at that point. Forced propagation and exclusions account for alternatives without inventing an explicit prewritten proof tree. `EXHAUSTED` is accepted only at a verified dead root with no unresolved branch frame.

This first step can be retrospective on fully retained raw records, including audit-off records, without rerunning search or changing the old Source. It produces a new separately named verification receipt. It must not rewrite an old UNKNOWN, failed native process, historical assurance label or publication. A new logical certificate does not repair a failed execution-admission gate. An unfinished/resource-limited raw result stays UNKNOWN under the first verifier, even if every event emitted so far was retained.

## Exact state and graph reconstructed independently

The initial scope matches the engine: opaque literal string points/CIDs/mark values, positive native integer capacity and contribution units, native integer generations, anchored placements selected at most once, complete immutable EXPLICIT inventory, no indexed provider and no ordering callback. Boolean/float IDs, weights and generations are not native integers. Mark value `"0"` is assigned; missing means no assignment. There is no wildcard interpretation of a stored string.

The reader owns selected CID/tile-generation assignments; all point totals including zero-valued explicit roots and seed keys; marking value/reference counts; active obligations and their generations; parent-local exclusions; and its branch frames. It derives complete positive/mark dependency indexes directly from the immutable universe. For every frontier point it computes every globally legal incident candidate, checking the candidate's whole positive and marking support, including remote mark-only points.

With capacity \(C\), the frontier is \(F=\{p\in Q:T(p)<C\}\). Its domain is

\[
D(p)=\{c:\ p\in\operatorname{supp}^{+}(t_c),\ c\notin S\cup X,
\ T(q)+t_c(q)\le C\text{ for every }q,
\ m_c\text{ agrees with every assigned current mark}\}.
\]

Candidate nodes are shared across incident frontier points; edge units come from the exact immutable candidate row. Global eligibility also contains legal registered candidates that currently touch no frontier, so it is not identical to the active reverse-incidence graph. A checker must not confuse those two sets.

Seed-positive points and every explicit root have generation zero. A committed placement has generation one plus the minimum **pre-placement** generation on its positive support already in the active obligation map. Each newly exposed point gets that tile generation, and an existing point keeps the smaller of its prior and incident generations. The checker restores these values from its parent state on failure. Placement chronology is not generation. Mark-only assignments do not activate new obligations by themselves.

The global priority is exact: any dead point before every forced move; otherwise any singleton before a branch; otherwise minimum generation, then degree, then literal point key. Dead/forced tie order is minimum generation then point key. Fractional residuals represented by integer units are not converted into exact-cover shortcuts: one forced candidate may leave a residual and cause the next global dead check. No geometry, proof strategy, top-k list or extra arithmetic pruning is added.

## Existing control grammar and binding requirements

The structured ABI is in `event-graph-journal-ABI-v1.json`. The original event object is exactly `seq, kind, point, candidate, data`.

| Event | Mandatory independent check and effect |
|---|---|
| `READY` | First event only; bind the independently reconstructed initial semantic state to the actual entry checkpoint. |
| `DEAD` | Recompute the whole frontier. The chosen point must be the dead tie winner. With a branch frame, await precisely its failed-child rollback/`EXCLUDE`; without a frame, await `EXHAUSTED`. |
| `FORCED` | No dead point exists; point is the global singleton tie winner, and the CID is its sole legal candidate. Save a forced pending action. |
| `BRANCH` | No dead or singleton exists. The point is the generation/degree/key winner. `legal` equals the entire independently reconstructed domain; in this first lexical scope `order` equals that sorted domain. Save the parent context and pending first CID. |
| `PLACED` | Must discharge exactly the pending forced/branch action. Check point/CID, actual Boolean forced flag and derived tile generation; apply that one candidate's complete t/m/support/generation effects. |
| `EXCLUDE` | Requires a preceding verified failed child. Restore the most recent independent branch parent, then exclude only its chosen CID in that parent context. No unrelated or global exclusion is permitted. |
| `SOLUTION` | No frontier remains after global checks; compare selected IDs, exact static certificate and final semantic checkpoint with the result. Native logical validity is separate. |
| `EXHAUSTED` | Only follows a verified root dead end with no unresolved branch/pending action; exact finite-inventory absence, not an unrestricted theorem or plane result. |

The base engine does not retain a list of untried branch alternatives in each stack frame. It restores a failed child and excludes that one CID, then rescans globally. Eventually an alternative may become forced. The verifier must follow this actual grammar rather than require a conventional two-child tree packet or silently drop the last forced alternative.

Completeness is mandatory: strict contiguous sequences beginning at zero; actual event count equal to both retained count and the complete raw array length; recomputed canonical ASCII JSON-plus-LF stream hash; exact normalized model/universe binding; and a valid terminal event matching raw SAT/UNSAT. A digest for an unretained suffix is custody evidence only. A pending `FORCED`/`BRANCH`, a missing `PLACED`, a partial transaction, a resource final status, missing endpoint bytes or checker resource refusal cannot certify absence.

The event grammar determines the required branch-context restoration. **Complete rollback metadata is not required for the logical semantic refutation.** Validate every retained rollback row as source metadata: reason/order, selected-before/after counts, native nonnegative trail numbers and arithmetic, plus matching failed-child context. A complete run should report one failed-child rollback per `EXCLUDE` plus final restoration. If rollback rows are only a prefix, preserve `rollback_metadata_coverage=PREFIX`; do not invent their payloads or claim physical trail replay. If all rows are retained, recompute their complete stream digest and counter sums. Exact physical instruction counts are not inferred from a semantic checkpoint.

Final restoration is not an existing control event: it occurs in `solve`'s `finally`. Require the actual saved entry/restored payloads, verify their individual hashes and equality, and compare their semantic projection to the independent initial state. Bind the actual final payload to the reconstructed terminal state. These are observed endpoints, not observations of all intervening internal maps. Reconstructed intermediate graphs must be labeled reconstructed and must never be passed off as the old snapshot observer's data or `graphs_checked` count.

## Why the old full-snapshot path is expensive

Every `_Events.emit` first canonicalizes/hashes the event, increments the full stream count, and retains only its bounded prefix. With a callback it then calls `state.snapshot(meter)`, canonicalizes that snapshot again through `_wire(snapshot,meter)`, and invokes the observer. `snapshot` rebuilds sorted domains, weighted forward/reverse arcs, the entire registered placement table, dependency indexes, totals, marks and generation maps. Static rows/dependencies are therefore repeatedly copied and serialized. `_bound` conservatively charges strings before serialization; its units are not CPU time.

The old callback cannot be turned into a cheap event-only observer merely by ignoring its `state` argument: the snapshot and its charged serialization have already occurred. Complete audit-off retained events can avoid that path today. If later large streams need online spooling, an event-only sink is a separate versioned producer change, requiring Root review and qualification. It must retain every actual event or report a precise gap, not synthesize snapshots after the fact.

The first qualification keeps the old engine and mixed meter unchanged. Compare a common node cap and the same complete prepared model, seed, t/m values, lexical order and semantic rules. Give the mixed work guard enough room and report whether it bound; the same historical `max_work` integer is not an equal core-work budget across snapshot modes. Separate measured search/capture/checking/persistence costs. Splitting actual core versus observer meters is a later change, not a prerequisite for semantic certification, and must not be silently applied to old results.

## Optional stronger graph-mutation observation

Only a later claim of actual intermediate table equality needs producer graph deltas. Source mutation sites are exact:

- `_map`, `_delete`, `_set`: actual changed dictionary entries/set memberships and their old presence/value, with trail order. Record presence separately from zero.
- `_register`: immutable placement registration and all positive/mark dependency memberships; `_refresh`: global eligibility and all incident domain changes.
- `_edge`: domain membership, reverse membership, bucket lifetime and edge counter, with exact immutable contribution units.
- `_point`/`_sync_point`/`_load`: total-key creation, obligation generation minima, domain creation/removal and loaded status; initial explicit roots at zero remain visible.
- `place`: selected generation, all t-sums, mark value/reference counts, complete affected dependencies and final active frontier. Shared candidates are selected once.
- `exclude`: the one parent-local failed CID and consequent eligibility/edge updates.
- `undo`: every actual inverse write/bucket restoration and final counters, plus checkpoint parent identity; not a forward recomputation presented as observed rollback.

Top-level stores have fixed names. Nested mutable sets need stable container IDs with allocation incarnation, not Python addresses or just a point key: a domain/dependency bucket can be deleted, restored or recreated while old trail entries retain references to its earlier object. Container creation/ref/link/deletion records must preserve aliasing and lifetime. An interned immutable point/CID/row table can avoid repeating long strings, but its inverse map, weights and literal values must be fully bound to the complete input.

`undo` is an uninterruptible inverse loop and must never invoke an external fallible journal callback. Queue bounded preallocated inverse-record references or set a persistent evidence-loss flag, always finish the original rollback, and only then flush/report observer failure at a safe boundary. Never abort cleanup because a log cap, disk write or serializer failed. Lost journal data means actual-map assurance UNKNOWN even when an independently checked positive proof survives. The optional ABI reserves versioned transaction/before/after fields; this is not part of the lean first gate and no instrumentation is implemented now.

## Qualification and stopping criteria

Use fresh tiny input declarations and independent exhaustive finite assignment checks after a prospective freeze. Compare old full-snapshot semantic decisions with the new semantic reader on identical completed runs; do not manufacture the old reader's snapshots. Exercise weighted residuals, shared candidates, untouched roots, far mark-only conflicts, literal zero, generation-before-degree, forced-after-exclusion, nested failed parents and exact final restoration. Corrupt completeness counts/hashes/sequence, whole legal domains, scheduler choice, generation, pending placement, restore/exclusion CID/context, terminal outcome and endpoint payload. Test full events with prefix-only rollback metadata as a valid weaker-coverage case; event truncation/resource interruption must stay UNKNOWN.

A semantic certificate proves only the declared finite point problem conditional on its independently complete universe. Mathematical proofs still need native logical checking; geometric faithfulness and infinite extension remain separate. A rejected semantic certificate does not automatically invalidate a separately native-checked final proof. Successful cheaper certification does not alone show a stronger search algorithm, learned GCTS marking or RL advantage. Failed-parent contexts may later become scoped certificate-backed nogoods; encoding them as literal GCTS markings requires a separate preservation proof.
