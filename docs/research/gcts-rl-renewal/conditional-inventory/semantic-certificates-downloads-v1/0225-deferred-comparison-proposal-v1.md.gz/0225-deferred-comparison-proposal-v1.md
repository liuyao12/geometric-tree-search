# Incremental assurance: prospective experimental protocol

Design only. No Source implementation, model/checker import, construction, replay, search, native check or experimental freeze is authorized by this document. Root must review the producer, independent verifier and this protocol together before freezing an executable study. The completed CALv2 archive cut and all older studies remain immutable.

The immediate objective is affordable, independently checkable search decisions and bounded refutations. That is an enabling step for useful GCTS failure markings and receptor families; it is not a claim of a better theorem prover. Avoid another layer of generic receipt machinery: keep one authoritative run output, one scoped semantic verification result, native positive evidence and a compact accounting record.

## First gate: existing semantic events, unchanged engine

Start with the qualified EXPLICIT-inventory engine, byte-identical to `growing_point_search_v2.py` SHA256 `6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb`. Use no provider, ordering callback, learned constraint or RL. Its existing `READY`, `FORCED`, `BRANCH`, `PLACED`, `DEAD`, `EXCLUDE`, `SOLUTION` and `EXHAUSTED` stream already describes the semantic search. An independent verifier can reconstruct complete legal domains from the fixed universe and apply its own branch-stack restoration, rather than request another full producer snapshot after every event.

This gate deliberately separates three assurances:

| Level | Evidence and possible claim |
| --- | --- |
| Positive certificate | Final selected point agreement, native decoding and native B. This can establish the found logical proof even when a later process postcheck fails. |
| Semantic search certificate | Complete control-event evidence and independent domain/scheduler/failed-parent reconstruction. This can establish accepted decisions or a finite refutation of the exact scoped point problem. |
| Intermediate internal-map observation | Actual producer maps observed at commits, or later a faithful store-mutation journal. This is additional implementation evidence; semantic replay alone does not establish equality of every producer cache/map. |

The verifier owns the immutable complete universe and indexes every positive and marking support, including remote mark-only points. It reconstructs capacity, literal mark agreement, selected-once inventory, required zeros, generations and justified exclusions. It checks global dead ends before global forced moves, then earliest generation with the same degree/key tie rule. An `EXCLUDE` must follow a checked failed child in its exact saved parent context. UNKNOWN cannot justify failure. Reconstructed rollback is part of the semantic proof; retained producer rollback rows are additional custody/map evidence, not automatically a prerequisite for a complete event-based refutation.

Complete event coverage and a terminal semantic proof are essential; a hash of an omitted suffix is insufficient. A partial stream can be accepted only as a verified prefix. Truncated rollback metadata must also retain its own prefix label. A full event refutation and a failed/incomplete producer process are separate fields; admit the semantic claim only through the independently checked certificate, never merely because the producer wrote raw `UNSAT`. Old archive labels do not change. Any new audit of historical evidence belongs in this new root with its own explicit scope.

For the initial implementation contract, use the independent verifier design in [incremental-verifier-design-v1.md](incremental-verifier-design-v1.md) and the producer design coordinated in this same directory. Do not fabricate verification by passing a verifier's reconstructed state to an old checker as if it were an observed producer snapshot.

## Two acquisitions, three accounting views

Use the same admitted prepared point model, candidate identities, lexical order, scheduler, seed, target and rollback semantics in both acquisitions:

- **LEAN:** `audit=None`; retain the existing complete semantic event stream and endpoints. Run the new independent semantic verifier afterwards.
- **FULL:** the same engine and limits with the existing full-snapshot callback. Run the **same semantic verifier** on its event stream, then the existing snapshot checker for additional actual-map observations.

The LEAN engine acquisition is also the raw/no-additional-assurance timing view. Do not rerun it simply to create a third “raw” observation or count those two accounting views as independent repetitions. Separate its search/capture cost from its added semantic verification and native-proof costs. FULL's extra map-observation cost and stronger evidence remain visible. A shorter total for LEAN is not automatically a cheaper way to obtain identical physical-map assurance.

For runs that reach the same logical endpoint before a resource cutoff, compare semantic event sequences and relevant logical counters. They should follow the same deterministic search, not merely finish with some valid proof. If one mode stops earlier, compare only the common retained semantic prefix and disclose the censoring. Never remove an inconvenient attempt or reinterpret an instrumentation cutoff as finite failure.

## Exact initial limits and order, subject to Root review

These are a concrete proposed first-stage schedule, not recorded results. Any adjustment must precede the executable freeze and all new classifications.

| Setting | Proposed value and interpretation |
| --- | --- |
| Logical search ceiling | `max_nodes=10000`, identical in both modes. In this engine it counts iterations of the main decision loop, including forced/dead/solution checks, not only genuine branches. |
| Legacy mixed-work safety guard | `max_work=1000000000000`, identical integer but **not an equal-work definition**. If it binds, label that mode censored. |
| Engine elapsed safety guard | `wall_seconds=120.0`; includes callback cost and is not a core-only clock. |
| Finite inventory bounds | `max_candidates=25000`, `max_points=128`, identical declared models. |
| Event and rollback retention | `max_events=50000`, `max_rollback_records=50000`; never continue to a claimed complete certificate after dropping required events. |
| Uncompressed evidence cap | \(256\) MiB per acquisition, including snapshots when present. A cap refusal is UNKNOWN assurance/capture, not absence. |
| Semantic verifier guard | \(60\) seconds, \(100{,}000{,}000\) declared verifier work units and \(2\) GiB process RSS. Its work definition is independent of engine work. |
| Owned acquisition guard | \(180\) seconds wall, \(150\) CPU seconds and \(2\) GiB polling RSS; terminate/reap only the owned child on observer failure. |
| Attempts | One per declared case/mode. No timeout retry, cap escalation, narrower replacement target or proof substitution. |

All unspecified engine limits must be written explicitly from the reviewed engine defaults into the frozen protocol; do not rely on environment-dependent defaults. If evidence cannot be completely captured within the cap, retain the actual raw outcome and the incomplete evidence label. Positive native proof admission may still be possible, while semantic exhaustion/conformance remains unadmitted. Mandatory cleanup and restoration run after a cooperative budget stop; a hard termination before restoration is separately recorded.

The first comparison uses the eight **seen** prepared inputs from the prior shared-fact programme. They are repeated bounds on a small number of structural families, not eight new theorems or a learning holdout. Existing five positive proofs, prior conventional results and current refutation expectations are not inputs to search or ordering. Use the frozen input models only.

Freeze case IDs in lexical order. For even case positions acquire LEAN then FULL; for odd positions FULL then LEAN. Each is a fresh isolated process with no cross-run search caches or imported selected proof. Preserve acquisition order, setup and environment. Record one ordered observation per pair; do not claim statistical significance. Stop for a correctness discrepancy; a repaired Source requires a separately reviewed prospective version that preserves failed attempts rather than silently retrying them.

## What the resource accounting means

The old engine's `work` mixes logical bookkeeping with serialization, hashing, snapshots and callback-related charges. Turning the callback off changes the composition of that counter. The same `max_work` integer across historical modes does not imply equal permitted logical work. The generous mixed guard above is only a safety guard; the shared node ceiling is the initial logical progress budget.

Record, without inventing an additive total from overlapping clocks:

1. Immutable preparation and native ZERO/basis admission, labeled reused versus newly measured.
2. Engine normalization/registration and raw search/capture time; main-loop nodes, genuine branches, forced placements, backtracks, exclusions and returned outcome.
3. Callback/snapshot construction, event/evidence serialization, hashing, writing and byte counts. Identify which intervals are nested in engine elapsed time.
4. Independent semantic verification; FULL's additional map-observation verification separately.
5. Final certificate extraction/decoding/native B and their persistence.
6. Entire owned process wall/CPU/RSS and completeness/refusal reasons.

Use measured nonoverlapping stage boundaries where available; retain whole-process time as the authoritative pipeline observation. Do not obtain “core seconds” by subtracting overlapping or unmeasured timers. No-audit raw time is not the time to a verified refutation. Compare verified outcomes, evidence scope and total acquisition-plus-assurance cost together.

If this first gate needs a strict operation-budget experiment, add it as a **later** version. The producer design proposes a common core meter for normalization/registration, legality, complete dependency/domain updates, generations, trails, scheduler scans/sorts, placements and exclusions; evidence encoding/hashing/snapshots/callbacks receive a separate observer meter. All modes must call the identical core charge sites, and observer code must not spend core units or alter decisions. That prospective counter version cannot retroactively rename the old mixed `work` values. It is not a prerequisite for validating the lean semantic checker.

## Qualification before the seen-input comparison

Start with small complete EXPLICIT inventories; use at most sixteen rows for exhaustive assignment checks where feasible. Include required untouched zero, remote mark-only conflict with assigned zero, global dead versus forced, forced versus earlier branch, genuinely different generations, weighted residual/shared-candidate behavior, noncontiguous slot padding, failed-child exclusion and rollback revival. Main proof slots all start at generation zero, so they cannot alone qualify generation priority. No target proof is supplied.

Require the semantic verifier and existing independent full-snapshot/exhaustive oracle to agree on the common semantic claim. Mutation tests must reject a changed model/universe, omitted or duplicated event, forward/incorrect generation, illegal chosen CID, incomplete branch legal/order packet, forced move while a global dead point exists, branch while a singleton exists, wrong residual weight, remote-mark dependency omission, forged/sibling exclusion and an UNKNOWN child relabeled failed. Test changed terminal status, omitted terminal event, trace truncation with refreshed hashes, altered rollback/endpoints and resource refusal. Distinguish a semantic contradiction from merely missing optional internal-map observations.

Do not require a new receipt for every internal helper. One compact qualification result should link the tiny input/run, actual mutation packets and independently checked outcomes. Any refusal remains explicit and prevents the affected assurance claim. Source inspection alone is not executed qualification.

## Seen and prospective held-out reporting

Report the existing archive, new seen-input acquisitions and any later fresh problems in separate groups. For each attempt keep raw engine status, native positive status, semantic certificate status, internal-map observation status and process/capture status separate. Show UNKNOWN rather than filling an absent result with zero or importing a prior control proof. A newly checked historical transcript can add new scoped evidence in this root; it must not overwrite the historical raw record or failed process.

After qualification and the seen-input diagnostic, a separate frozen engineering holdout could use eight freshly generated ground-Horn structures, larger atom counts than the old templates, at line bounds \(8\) and \(12\). Declare seeds and structural profiles before running; reject mere symbol-renamed duplicates. For example, at most sixteen atoms and twelve curried rules with at most two premises keeps the declared subformula construction small, without supplying a target derivation. Record any preparation overflow as UNKNOWN; do not regenerate until a favorable label appears. This is a holdout against engineering choices, not an RL generalization result, and is not part of the initial sixteen acquisitions.

## Path toward a substantive GCTS comparison

Once the lean semantic checker is qualified, both sides of a marking/proposal experiment can use exactly the same assurance and logical budget. The useful next output is a finite failed-parent certificate bound to the model/universe, literal t/m state, selected facts, branch scope and proof bound. No budget-limited child may supply it; any earlier exclusions it relies on must carry their own justified failure dependencies.

These certificates can support scoped nogoods. They are **not automatically GCTS markings**. Before a fixed point-mark encoding is admitted, prove projection/preservation for that encoding, including any auxiliary ports/tiles. An arbitrary multi-placement forbidden conjunction need not be expressible by simply assigning two conflicting colors. Old tree-height failure ports also do not automatically preserve shared-DAG line-bound solutions.

The next causal comparison should then use the same native task/bound and the same lean assurance for: base search; independently certified literal-mark pruning; and an ordinary direct filter using exactly the same certificates. Compare all preparation/encoding/verification costs as well as eliminated candidates and verified completion. Identical filter/mark traces would identify an encoding equivalence, not a distinctive GCTS search advantage. Receptor-family proposals can follow with literal primitive expansions, joint interface validation, scheduler preemption and complete base fallback. RL waits until that strong baseline exists.

Master reference read for this design: 21657 bytes, SHA256 `c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9`. No old or current archive file was changed. No result, new theorem, native absence, novel proof system, plane tiling or performance gain is established by this plan.
