"""Source-only until Root review: fresh qualification and checker-only replay.

Freeze the entire local Source/reference/input/plan set before science imports.
Qualification runs each fresh tiny engine problem ONCE with actual snapshots,
then checks that same result with semantic/full-snapshot/exhaustive methods.
Retrospective imports only the semantic checker: no engine/solver/native-proof
search is rerun and no historical selection enters a qualification search.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
MASTER=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md')
MASTER_SHA='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
FIXTURES='plan/semantic-qualification-cases-v1.json'
RETRO='plan/retrospective-inputs-v1.json'
PROTOCOL='data/protocol-frozen-v1.json'
POINT=dict(wall_seconds=3.0,max_work=1000000000,max_nodes=10000,max_events=10000,
    max_rollback_records=10000,max_candidates=1000,max_points=128)
SEMANTIC=dict(max_items=100000000,max_work=10000000000,wall_seconds=30.0)
FULL_TRACE=dict(max_items=100000000,wall_seconds=30.0)
ORACLE=dict(max_candidates=16,max_assignments=65536,wall_seconds=10.0,max_items=200000,max_work=10000000)
GUARDS=dict(wall_seconds=1200.0,cpu_seconds=900,rss_bytes=1073741824)
CAPTURE_BYTES=268435456
TRUSTED={'reference/upstream/growing_point_search_v2.py':'6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb',
    'reference/upstream/frontier_trace_checker_v1.py':'01f46bdf34b414c7470f75f1507f3e76bfefa739533fcc4b2fd121900378343f',
    'reference/basic-tiling-algorithm.md':MASTER_SHA}


def need(ok,why):
    if not ok:raise ValueError(why)


def wire(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')


def sha(value):
    h=hashlib.sha256()
    for part in json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).iterencode(value):h.update(part.encode('ascii'))
    h.update(b'\n');return h.hexdigest()


def local(name):
    need(type(name) is str and not Path(name).is_absolute(),'RELATIVE_TASK_PATH')
    p=(ROOT/name).resolve();need(p.is_relative_to(ROOT),'TASK_PATH_ESCAPE');return p


def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):size+=len(b);h.update(b)
    return dict(bytes=size,sha256=h.hexdigest())


def ref(name):return dict(path=name,**pin(local(name)))


def read(name):
    p=local(name)
    with (gzip.open(p,'rt',encoding='ascii') if p.suffix=='.gz' else p.open('r',encoding='ascii')) as f:return json.load(f)


def checked_read(reference):
    need(pin(local(reference['path']))=={k:reference[k] for k in ('bytes','sha256')},'PINNED_INPUT_BYTES:'+reference['path'])
    return read(reference['path'])


def save(name,value):
    """Exclusive bounded stream; a resource prefix never passes as full JSON."""
    p=local(name);p.parent.mkdir(parents=True,exist_ok=True);count=0;complete=True
    encoder=json.JSONEncoder(sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)
    with p.open('xb') as raw:
        out=gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) if p.suffix=='.gz' else raw
        try:
            for part in encoder.iterencode(value):
                b=part.encode('ascii')
                if count+len(b)>CAPTURE_BYTES:
                    out.write(b[:CAPTURE_BYTES-count]);count=CAPTURE_BYTES;complete=False;break
                out.write(b);count+=len(b)
            if complete and count<CAPTURE_BYTES:out.write(b'\n');count+=1
            elif count==CAPTURE_BYTES:complete=False
        finally:
            if out is not raw:out.close()
    result=dict(path=name,**pin(p),logical_json_bytes=count,complete_json=complete)
    if not complete:
        with local(name+'.capture-refusal.json').open('x') as f:json.dump(dict(status='UNKNOWN_CAPTURE',prefix=result),f,sort_keys=True)
        raise RuntimeError('UNKNOWN_CAPTURE:'+name)
    return result


def stage(name,fn):
    start=time.perf_counter();value=fn();call_seconds=time.perf_counter()-start
    save_start=time.perf_counter();reference=save(name,value)
    reference.update(call_seconds=call_seconds,write_seconds=time.perf_counter()-save_start,pipeline_seconds=time.perf_counter()-start)
    print(json.dumps(dict(stage=name,status=value.get('status'),seconds=call_seconds)),flush=True)
    return value,reference


def scientific_files():
    paths=[]
    for folder in ('source','reference','input','plan'):
        for p in (ROOT/folder).rglob('*'):
            need(not p.is_symlink(),'NO_FROZEN_SYMLINK')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':paths.append(p)
    paths.append(local('review/input-dependency-snapshot-v1.json'))
    return [dict(path=p.relative_to(ROOT).as_posix(),**pin(p)) for p in sorted(paths)]


def runtime():
    p=Path(sys.executable).resolve()
    return dict(executable=dict(path=str(p),**pin(p)),version=sys.version,isolated=sys.flags.isolated,
        no_site=sys.flags.no_site,dont_write_bytecode=sys.dont_write_bytecode)


def freeze():
    need(sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,'ISOLATED_NO_BYTECODE_RUNTIME')
    need(not local(PROTOCOL).exists(),'NO_REFREEZE')
    for name,h in TRUSTED.items():need(pin(local(name))['sha256']==h,'UNCHANGED_TRUSTED_SOURCE')
    need(pin(MASTER)['sha256']==MASTER_SHA,'CURRENT_MASTER')
    fixtures=read(FIXTURES);retro=read(RETRO)
    need(len(fixtures['cases'])==13 and len({c['id'] for c in fixtures['cases']})==13,'FRESH_THIRTEEN_FIXTURES')
    need(len(fixtures['mutation_specs'])==20,'DECLARED_TWENTY_MUTATIONS')
    need(len(retro['cases'])==8 and len({c['id'] for c in retro['cases']})==8,'EXACT_EIGHT_RETROSPECTIVE_INPUTS')
    need(sum(not c['original_process']['execution_admitted'] for c in retro['cases'])==1,'PRESERVED_FIRST_PROCESS_FAILURE')
    for c in retro['cases']:
        for value in c['inputs'].values():need(pin(local(value['path']))=={k:value[k] for k in ('bytes','sha256')},'EXACT_RETROSPECTIVE_COPY')
    value=dict(schema='Semantic-assurance-prospective-protocol-v1',status='FROZEN_BEFORE_SCIENTIFIC_IMPORTS',
        phases=['qualify','retrospective'],files=scientific_files(),runtime=runtime(),master=dict(path=str(MASTER),**pin(MASTER)),
        fixture_declarations=ref(FIXTURES),retrospective_inputs=ref(RETRO),point_limits=POINT,semantic_limits=SEMANTIC,
        full_trace_limits=FULL_TRACE,assignment_oracle_limits=ORACLE,guards=GUARDS,capture_bytes=CAPTURE_BYTES,
        scope='Fresh tiny proof-of-verifier qualification then checker-only replay of exactly eight actual saved records. No new performance benchmark, engine change, historical search rerun, native proof search or synthetic observed snapshots.',
        frozen_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    return save(PROTOCOL,value)


def unchanged():
    """Return ONE protocol dictionary; postcheck getters have this exact type."""
    p=read(PROTOCOL);need(p['status']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS','FROZEN_STATUS')
    need(p['files']==scientific_files(),'EXACT_FROZEN_SOURCE_INPUT_SET');need(p['runtime']==runtime(),'UNCHANGED_RUNTIME')
    need(pin(MASTER)=={k:p['master'][k] for k in ('bytes','sha256')},'CURRENT_MASTER_UNCHANGED')
    for key,value in [('point_limits',POINT),('semantic_limits',SEMANTIC),('full_trace_limits',FULL_TRACE),('assignment_oracle_limits',ORACLE),('guards',GUARDS),('capture_bytes',CAPTURE_BYTES)]:need(p[key]==value,'FROZEN_'+key)
    return p


def module(name,path):
    spec=importlib.util.spec_from_file_location('semantic_assurance_'+name,local(path));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def qualification_modules():
    return {key:module(key,path) for key,path in dict(E='reference/upstream/growing_point_search_v2.py',
        T='reference/upstream/frontier_trace_checker_v1.py',C='source/semantic_event_checker_v1.py',
        O='source/tiny_assignment_oracle_v1.py',X='source/semantic_mutations_v1.py').items()}


def matches(value,subset):
    if type(subset) is dict:return type(value) is dict and all(k in value and matches(value[k],v) for k,v in subset.items())
    return wire(value)==wire(subset)


def required_observations(case,observations):
    decisions=[r for r in observations if r['event']['kind']!='READY']
    checks=[]
    for request in case['expected'].get('required_observations',[]):
        candidates=decisions[:1] if request['position']=='FIRST_DECISION' else observations
        need(request['position'] in ('FIRST_DECISION','ANY'),'DECLARED_OBSERVATION_POSITION')
        found=False
        for row in candidates:
            if not matches(row['event'],request['event']):continue
            snapshot=row['state'];ok=True
            for key,wanted in request.get('snapshot_contains',{}).items():
                ok=ok and all(any(wire(x)==wire(y) for y in snapshot[key]) for x in wanted)
            for key,forbidden in request.get('snapshot_omits',{}).items():
                keys=[x[0] if type(x) is list else x for x in snapshot[key]]
                ok=ok and all(x not in keys for x in forbidden)
            if ok:found=True;checks.append(dict(request=request,event_seq=row['event']['seq']));break
        need(found,'REQUIRED_ACTUAL_OBSERVATION:'+case['id'])
    return checks


def incremental_graph_comparison(checker,model,raw,observations):
    """Qualification only: C-derived graphs versus actual E callback payloads.

    The public semantic verifier is a separate prior gate. This bounded second
    Reader pass is not an engine attempt and never supplies observations to T.
    T independently re-enumerates the complete explicit universe against the
    actual observations; no retro intermediate-table observation is inferred.
    """
    started=time.perf_counter();meter=None;reader=None;rows=[]
    try:
        meter=checker.Meter(SEMANTIC['max_items'],SEMANTIC['max_work'],SEMANTIC['wall_seconds'])
        for value in (model,raw,observations):meter.scan(value,input_items=True)
        reader=checker.Reader(model,raw,meter)
        need(len(observations)==len(raw['events'])==raw['event_extent']['total'],'COMPARISON_COMPLETE_ACTUAL_CALLBACKS')
        for i,actual in enumerate(observations):
            before=reader.snapshot();before_hash=meter.sha(before)
            meter.same(actual['event'],raw['events'][i],'COMPARISON_ACTUAL_RETAINED_EVENT')
            reader.event(actual['event'],i)
            derived=reader.snapshot()
            meter.same(derived,actual['state'],'QUALIFICATION_INCREMENTAL_GRAPH_EQUALS_ACTUAL_E_OBSERVATION')
            derived_hash=meter.sha(derived);actual_hash=meter.sha(actual['state'])
            rows.append(dict(seq=i,kind=actual['event']['kind'],before_derived_sha256=before_hash,
                after_derived_sha256=derived_hash,actual_observation_sha256=actual_hash,equal=True,
                points=len(derived['Q']),frontier_points=len(derived['domains']),edges=derived['edge_count'],
                selected=len(derived['selected']),excluded=len(derived['excluded'])))
            meter.store();meter.tick()
        meter.same(reader.snapshot(),raw['final_state'],'QUALIFICATION_DERIVED_FINAL_GRAPH')
        meter.tick()
        answer=dict(status='VERIFIED',reason='ALL_TINY_INCREMENTAL_GRAPHS_EQUAL_ACTUAL_E_OBSERVATIONS',
            events_checked=len(rows),event_kinds=dict(Counter(r['kind'] for r in rows)),comparisons=rows,
            reader_counts=dict(reader.counts),scope='Qualification-only private pinned Reader API. Actual callback graphs independently checked by T; no producer intermediate-map claim for retrospective results.')
    except checker.Rejected as error:answer=dict(status='REJECTED',reason=str(error),comparisons=rows)
    except (checker.Incomplete,checker.Budget,MemoryError,RecursionError,OverflowError) as error:
        answer=dict(status='UNKNOWN',reason=type(error).__name__+':'+str(error),comparisons=rows)
    except (KeyError,TypeError,ValueError,IndexError) as error:
        answer=dict(status='REJECTED',reason='COMPARISON_INPUT:'+type(error).__name__+':'+str(error),comparisons=rows)
    answer.update(seconds=time.perf_counter()-started,items=0 if meter is None else meter.items,
        work=0 if meter is None else meter.work,engine_calls=0,private_reader_passes=1)
    return answer


def qualify_case(case,mods):
    base='data/qualification/'+case['id'];model=case['model'];observations=[];start=time.perf_counter()
    model_ref=save(base+'/model.json',model)
    def audit(event,state,charge):
        if len(observations)>=POINT['max_events']:charge(POINT['max_work']+1)
        charge(1);observations.append(dict(event=event,state=state))
    raw,raw_ref=stage(base+'/raw-engine-result.json.gz',lambda:mods['E'].solve(model,POINT,audit=audit,order=None))
    save_start=time.perf_counter();obs_ref=save(base+'/actual-observations.json.gz',observations);obs_ref['write_seconds']=time.perf_counter()-save_start
    # Every raw record is persisted before any certificate/oracle call.
    semantic,sref=stage(base+'/semantic-certificate.json',lambda:mods['C'].verify_explicit_events(model,raw,**SEMANTIC))
    full,tref=stage(base+'/actual-full-snapshot-check.json',lambda:mods['T'].verify(model,model['inventory']['placements'],observations,raw,**FULL_TRACE))
    graph,gref=stage(base+'/incremental-versus-actual-graphs.json',lambda:incremental_graph_comparison(mods['C'],model,raw,observations))
    oracle,oref=stage(base+'/assignment-oracle.json.gz',lambda:mods['O'].solve(model,**ORACLE))
    row=dict(id=case['id'],raw_status=raw['status'],semantic_status=semantic['status'],full_snapshot_status=full['status'],oracle_status=oracle['status'],
        incremental_graph_comparison_status=graph['status'],engine_calls=1,semantic_public_calls=1,private_reader_passes=1,
        refs=dict(model=model_ref,raw=raw_ref,observations=obs_ref,semantic=sref,full_snapshot=tref,incremental_graph_comparison=gref,oracle=oref),seconds=time.perf_counter()-start)
    save(base+'/attempt-summary.json',row)
    need(raw['status']==case['expected']['raw_status'] and raw['status'] in ('SAT','UNSAT'),'DEFINITE_FRESH_OUTCOME_REQUIRED:'+case['id'])
    need(semantic['status']==full['status']=='VERIFIED','BOTH_ASSURANCE_METHODS_REQUIRED:'+case['id'])
    need(graph['status']=='VERIFIED' and graph['events_checked']==len(observations),'ACTUAL_INCREMENTAL_GRAPH_QUALIFICATION:'+case['id'])
    claim='SEMANTIC_COMPLETE_FINITE_EXHAUSTION' if raw['status']=='UNSAT' else 'SEMANTIC_COMPLETE_SAT_CERTIFICATE'
    need(semantic['claim']==claim and semantic['event_coverage']=='COMPLETE','EXACT_SEMANTIC_CLAIM')
    need(semantic['bounded_absence'] is (raw['status']=='UNSAT'),'SEMANTIC_ABSENCE_SCOPE')
    need(full['run_status']==raw['status'] and full['counts']['observations_checked']==len(observations)==raw['event_extent']['total'],'ACTUAL_FULL_OBSERVATION_COVERAGE')
    need(oracle['status']=='EXHAUSTED' and oracle['exists'] is case['expected']['exists'] and oracle['exists'] is (raw['status']=='SAT'),'INDEPENDENT_EXHAUSTIVE_EXISTENCE')
    checks=required_observations(case,observations);row.update(status='QUALIFIED',semantic_claim=claim,required_observations=checks)
    save(base+'/qualified-summary.json',row);return row,raw


def qualification():
    mods=qualification_modules();declarations=read(FIXTURES);models={};raws={};rows=[]
    for case in declarations['cases']:
        row,raw=qualify_case(case,mods);rows.append(row);models[case['id']]=case['model'];raws[case['id']]=raw
    mutants=mods['X'].build(models,raws,declarations['mutation_specs'])
    need(len(mutants)==len(declarations['mutation_specs'])==20,'ALL_DECLARED_MUTATIONS_BUILT')
    need({r['id'] for r in mutants}=={r['id'] for r in declarations['mutation_specs']},'EXACT_MUTATION_IDS')
    controls=[]
    for mutant in mutants:
        name='data/mutations/'+mutant['id'];input_ref=save(name+'-input.json.gz',mutant)
        target=mutant['target'];need(target in ('SEMANTIC','ASSIGNMENT_ORACLE'),'DECLARED_MUTATION_CHECKER_TARGET')
        limits=dict(SEMANTIC if target=='SEMANTIC' else ORACLE);limits.update(mutant.get('limits_override',{}))
        fn=(lambda m=mutant,l=limits:mods['C'].verify_explicit_events(m['model'],m['result'],**l)) if target=='SEMANTIC' else (lambda m=mutant,l=limits:mods['O'].solve(m['model'],**l))
        check,receipt=stage(name+'-receipt.json',fn)
        row=dict(id=mutant['id'],case_id=mutant['case_id'],target=target,expected=mutant['expected_status'],actual=check['status'],input=input_ref,receipt=receipt)
        controls.append(row);save(name+'-comparison.json',row)
        need(check['status']==mutant['expected_status'],'MUTATION_EXPECTATION:'+mutant['id'])
        if target=='SEMANTIC' and check['status']!='VERIFIED':need(check['bounded_absence'] is False,'NO_MUTANT_UNKNOWN_OR_REJECTION_AS_ABSENCE')
        if mutant.get('required_scope')=='COMPLETE_EVENTS_WITH_PREFIX_ROLLBACK_METADATA':
            need(check['event_coverage']=='COMPLETE' and check['rollback_metadata_coverage']=='PREFIX','PREFIX_METADATA_SCOPE_EXPLICIT')
    result=dict(status='QUALIFIED_FRESH_SEMANTIC_ASSURANCE',cases=rows,mutations=controls,
        counts=dict(cases=len(rows),finite_exhaustion_certificates=sum(r['semantic_claim']=='SEMANTIC_COMPLETE_FINITE_EXHAUSTION' for r in rows),
            mutation_statuses=dict(Counter(r['actual'] for r in controls))),
        scope='Each new tiny engine problem executed once, same actual result independently semantic/full-snapshot/exhaustive checked. Generic point cases, no native mathematical theorem or performance claim.')
    return result


def original_process(entry):
    inputs=entry['inputs'];p=checked_read(inputs['original_protocol']);s=checked_read(inputs['original_started']);i=checked_read(inputs['original_invocation']);o=checked_read(inputs['original_observer'])
    declared=entry['original_process']
    need(s['status']=='STARTED' and o['status']=='TERMINAL','ORIGINAL_PROCESS_RECEIPT_STATUSES')
    need(s['phase']==i['phase']==o['phase']==entry['id'],'ORIGINAL_PHASE_CONTEXT')
    need(type(s['pid']) is int and s['pid']==i['pid']==o['pid']==declared['pid'],'ORIGINAL_PID_CONTEXT')
    need(s['protocol_sha256']==sha(p) and o['native_exit_code']==declared['native_exit_code'],'ORIGINAL_PROTOCOL_EXIT')
    need(o['guard_reason'] is o['observer_error'] is o['reap_error'] is None,'ORIGINAL_OWNED_OBSERVER_CLEAN')
    need({k:o['log'][k] for k in ('bytes','sha256')}=={k:inputs['original_log'][k] for k in ('bytes','sha256')},'ORIGINAL_OBSERVER_LOG_BYTES')
    need(i['scientific_status']==declared['scientific_status'],'ORIGINAL_SAVED_SCIENCE_STATUS')
    if declared['execution_admitted']:
        need(o['native_exit_code']==0 and o['guard_reason'] is None and i['status']=='COMPLETE','ORIGINAL_CLEAN_PROCESS')
        need(o['frozen_postcheck']==i['frozen_postcheck']==p['status'] and o['postcheck_error'] is i['postcheck_error'] is None,'ORIGINAL_CLEAN_POSTCHECK')
    else:
        need(declared['status']=='FAILED_POSTCHECK_AFTER_SCIENCE' and o['native_exit_code']==1 and i['status']=='ERROR','PRESERVED_FAILED_FIRST_PROCESS')
        need(o['frozen_postcheck']==i['frozen_postcheck']=='FAILED','FAILED_FIRST_POSTCHECK_UNCHANGED')
        need(o['postcheck_error']==i['postcheck_error']=='tuple indices must be integers or slices, not str','FAILED_FIRST_EXACT_TUPLE_POSTCHECK_ERROR')
    return declared


def retrospective():
    # Deliberately no import of E, T, O, mutations, decoder or native kernel.
    checker=module('C_retro','source/semantic_event_checker_v1.py');inputs=read(RETRO);rows=[]
    for entry in inputs['cases']:
        start=time.perf_counter();process=original_process(entry)
        prepared=checked_read(entry['inputs']['prepared']);raw=checked_read(entry['inputs']['raw_result'])
        declaration=checked_read(entry['inputs']['declaration'])
        need(declaration['id']==entry['source_case_id'] and wire(declaration['statement'])==wire(prepared['statement']),'ACTUAL_DECLARATION_STATEMENT_CONTEXT')
        gate=checked_read(entry['inputs']['basis_model_gate']);model=prepared['model'];load_seconds=time.perf_counter()-start
        need(gate['status']=='VERIFIED' and gate['model_sha256']==sha(model) and gate['universe_sha256']==sha(prepared['universe']),'REUSED_COMPLETE_FINITE_MODEL_BINDING')
        need(model['inventory']['placements']==prepared['universe'],'EXACT_EXPLICIT_UNIVERSE')
        old=checked_read(entry['inputs']['original_scientific_result']);need(old['raw_engine_status']==raw['status'],'ACTUAL_OLD_RAW_RESULT_ASSOCIATION')
        need(old['id']==entry['id'] and old['source_case_id']==entry['source_case_id'],'ORIGINAL_RUN_AND_SOURCE_CASE_IDS')
        need({k:old['refs']['raw_result'][k] for k in ('bytes','sha256')}=={k:entry['inputs']['raw_result'][k] for k in ('bytes','sha256')}
            and old['refs']['raw_result']['complete_json'] is entry['raw_capture_complete'] is True,'ACTUAL_ORIGINAL_RAW_BYTES_AND_COMPLETE_CAPTURE')
        for old_key,new_key in [('declaration','declaration'),('prepared','prepared'),('original_gate','basis_model_gate')]:
            need({k:old['inputs'][old_key][k] for k in ('bytes','sha256')}=={k:entry['inputs'][new_key][k] for k in ('bytes','sha256')},'ACTUAL_ORIGINAL_INPUT_BYTES:'+old_key)
        need(old['status']==process['scientific_status'],'ORIGINAL_SCIENTIFIC_STATUS_UNCHANGED')
        name='data/retrospective/'+entry['id'];receipt,rref=stage(name+'/semantic-certificate.json',lambda:checker.verify_explicit_events(model,raw,**SEMANTIC))
        need(receipt['status'] in ('VERIFIED','UNKNOWN','REJECTED'),'VERIFIER_RECEIPT_STATUS')
        if raw['status']=='UNKNOWN':need(receipt['status']!='VERIFIED','NO_RAW_UNKNOWN_PROMOTION')
        row=dict(id=entry['id'],source_case_id=entry['source_case_id'],raw_status=raw['status'],old_science_status=old['status'],
            original_process=process,new_semantic_status=receipt['status'],new_semantic_claim=receipt.get('claim'),
            bounded_absence=receipt.get('bounded_absence',False),event_coverage=receipt.get('event_coverage'),rollback_metadata_coverage=receipt.get('rollback_metadata_coverage'),
            inputs=entry['inputs'],receipt=rref,costs=dict(input_load_seconds=load_seconds,verifier_seconds=rref['call_seconds'],receipt_write_seconds=rref['write_seconds'],verifier_and_save_seconds=rref['pipeline_seconds'],whole_record_seconds=time.perf_counter()-start),
            scope='New independent certificate over actual saved records only. Original process/result/history unchanged; no engine rerun, synthetic snapshot or mathematical-kernel claim.')
        save(name+'/record.json',row);rows.append(row)
    need(len(rows)==8,'ALL_EIGHT_RETROSPECTIVE_POSITIONS')
    return dict(status='RETROSPECTIVE_CHECKS_RECORDED_WITH_EXPLICIT_SCOPES',records=rows,
        counts=dict(records=8,semantic_statuses=dict(Counter(r['new_semantic_status'] for r in rows)),
            new_finite_exhaustion_certificates=sum(r['new_semantic_status']=='VERIFIED' and r['bounded_absence'] for r in rows),
            original_failed_processes=sum(not r['original_process']['execution_admitted'] for r in rows)),
        engine_reruns=0,scope='Outcomes are observed, never predeclared. A semantic certificate does not repair the original failed native process or strengthen the native mathematical profile.')


def qualified_process():
    q=read('data/qualify-result.json');s=read('data/qualify-started.json');i=read('review/qualify-invocation.json');o=read('review/qualify-observer.json');p=read(PROTOCOL)
    need(q['status']=='QUALIFIED_FRESH_SEMANTIC_ASSURANCE','FRESH_QUALIFICATION_REQUIRED')
    need(q['counts']['cases']==len(q['cases'])==13 and len(q['mutations'])==20,'COMPLETE_FRESH_QUALIFICATION_COHORT')
    need(s['status']=='STARTED' and o['status']=='TERMINAL','QUALIFICATION_RECEIPT_STATUSES')
    need(s['phase']==i['phase']==o['phase']=='qualify' and s['pid']==i['pid']==o['pid'],'QUALIFICATION_PHASE_PID')
    need(s['protocol_sha256']==sha(p) and i['status']=='COMPLETE' and o['native_exit_code']==0 and o['guard_reason'] is None,'QUALIFICATION_NATIVE_PROCESS')
    need(i['scientific_status']==q['status'] and i['error_type'] is None,'QUALIFICATION_SCIENCE_INVOCATION_JOIN')
    need(o['observer_error'] is o['reap_error'] is None,'QUALIFICATION_OBSERVER_CLEAN')
    need({k:i['result'][k] for k in ('path','bytes','sha256')}==ref('data/qualify-result.json') and i['result']['complete_json'] is True,'QUALIFICATION_RESULT_BYTES')
    need(i['frozen_postcheck']==o['frozen_postcheck']==p['status'] and i['postcheck_error'] is o['postcheck_error'] is None,'QUALIFICATION_POSTCHECK')


def worker(phase):
    protocol=unchanged();need(phase in protocol['phases'],'DECLARED_PHASE');start=time.perf_counter();result=None;reference=None
    save('data/'+phase+'-started.json',dict(status='STARTED',phase=phase,pid=os.getpid(),protocol_sha256=sha(protocol),utc=time.time()))
    try:
        if phase=='qualify':result=qualification()
        else:qualified_process();result=retrospective()
        unchanged();reference=save('data/'+phase+'-result.json',result)
        return dict(status='COMPLETE',phase=phase,scientific_status=result['status'],result=reference)
    finally:
        error=sys.exc_info()[0];post_error=None
        try:postcheck=unchanged()['status']
        except Exception as failure:postcheck='FAILED';post_error=str(failure)
        save('review/'+phase+'-invocation.json',dict(status='ERROR' if error or post_error else 'COMPLETE',phase=phase,pid=os.getpid(),
            scientific_status=result.get('status') if result else None,result=reference,seconds=time.perf_counter()-start,
            maxrss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,maxrss_units='bytes' if sys.platform=='darwin' else 'KiB',
            frozen_postcheck=postcheck,postcheck_error=post_error,error_type=error.__name__ if error else None))
        if post_error and error is None:raise RuntimeError('FROZEN_POSTCHECK:'+post_error)


def supervise(phase):
    p=unchanged();need(phase in p['phases'],'DECLARED_PHASE')
    if phase=='retrospective':qualified_process()
    for name in ('data/'+phase+'-started.json','data/'+phase+'-result.json','review/'+phase+'-invocation.json','review/'+phase+'-observer.json','review/'+phase+'-native.log'):need(not local(name).exists(),'PRESERVE_FIRST_ATTEMPT:'+name)
    log=local('review/'+phase+'-native.log');log.parent.mkdir(parents=True,exist_ok=True)
    start=time.perf_counter();child=None;code=None;reason=None;error_text=None;reap_error=None;peak=0;samples=[]
    def cpu_guard():resource.setrlimit(resource.RLIMIT_CPU,(GUARDS['cpu_seconds'],GUARDS['cpu_seconds']+1))
    with log.open('xb') as output:
        try:
            child=subprocess.Popen([sys.executable,'-I','-S','-B',str(Path(__file__).resolve()),'_worker',phase],cwd=ROOT,
                env={'PATH':'/usr/bin:/bin','LANG':'C','PYTHONDONTWRITEBYTECODE':'1'},stdout=output,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=cpu_guard)
            while child.poll() is None:
                probe=subprocess.run(['/bin/ps','-o','rss=','-p',str(child.pid)],capture_output=True,text=True,timeout=5)
                if probe.returncode==0 and probe.stdout.strip():
                    rss=int(probe.stdout.strip())*1024
                    if rss>peak:peak=rss;samples.append(dict(seconds=time.perf_counter()-start,rss_bytes=rss))
                    if rss>GUARDS['rss_bytes']:reason='RSS_POLL_BOUND';break
                elif child.poll() is None:reason='RSS_PROBE_FAILED';break
                if time.perf_counter()-start>GUARDS['wall_seconds']:reason='WALL_BOUND';break
                time.sleep(.2)
        except BaseException as error:reason='OBSERVER_ERROR:'+type(error).__name__;error_text=str(error)
        finally:
            if child is not None:
                if reason and child.poll() is None:
                    try:os.killpg(child.pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                    except OSError as error:error_text=(error_text or '')+'; TERM:'+str(error)
                    try:child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        try:os.killpg(child.pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        except OSError as error:error_text=(error_text or '')+'; KILL:'+str(error)
                try:code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:reap_error='NATIVE_EXIT_UNOBSERVED_AFTER_OWNED_KILL'
    post_error=None
    try:postcheck=unchanged()['status']
    except Exception as error:postcheck='FAILED';post_error=str(error)
    value=dict(status='TERMINAL' if code is not None else 'UNADMITTED_PROCESS',phase=phase,pid=child.pid if child else None,
        native_exit_code=code,guard_reason=reason,observer_error=error_text,reap_error=reap_error,seconds=time.perf_counter()-start,
        peak_observed_rss_bytes=peak,rss_samples=samples,log=ref(str(log.relative_to(ROOT))),frozen_postcheck=postcheck,postcheck_error=post_error,
        scope='Single owned child only; actual exit and Source guards required. Polled RSS is not a strict instantaneous memory bound; no silent phase rerun.')
    save('review/'+phase+'-observer.json',value);return value


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('command',choices=('freeze','run','_worker'));parser.add_argument('phase',nargs='?',choices=('qualify','retrospective'));args=parser.parse_args()
    need((args.command=='freeze')==(args.phase is None),'COMMAND_PHASE')
    answer=freeze() if args.command=='freeze' else supervise(args.phase) if args.command=='run' else worker(args.phase)
    print(json.dumps(answer,sort_keys=True),flush=True)
    if args.command=='run' and not (answer['status']=='TERMINAL' and answer['native_exit_code']==0
            and answer['guard_reason'] is answer['observer_error'] is answer['reap_error'] is answer['postcheck_error'] is None
            and answer['frozen_postcheck']=='FROZEN_BEFORE_SCIENTIFIC_IMPORTS'):
        raise SystemExit(1)
