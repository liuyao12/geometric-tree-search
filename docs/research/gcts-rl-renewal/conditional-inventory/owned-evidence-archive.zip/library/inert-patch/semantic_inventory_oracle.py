"""Whole unchanged native checking with explicit generated lemma definitions."""
import copy,hashlib,json,time
from certificate_boundary_search import Oracle,digest
from tape_binary import write_micro_input

class RequestOracle(Oracle):
    def request(self,request,limit=5*10**9,purpose='semantic_inventory'):
        began=time.perf_counter();request=copy.deepcopy(request);initial=self.initial(request)
        inp=self.directory/'input.bin';out=self.directory/'output.bin';write_micro_input(initial,inp)
        self.process.stdin.write(str(inp)+' '+str(out)+' '+str(limit)+'\n');self.process.stdin.flush()
        reply=self.process.stdout.readline()
        if not reply:raise ValueError('native oracle stopped: '+self.process.stderr.read())
        result=json.loads(reply);record=dict(id=len(self.records),request=request,query_target='fixed_assertion',request_sha256=digest(request),
              input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
              result=result,seconds=time.perf_counter()-began,purpose=purpose)
        self.records.append(record);return record
    def query(self,spec,proof,final,limit):
        if not final:raise ValueError('semantic inventory pilot uses only declared fixed query targets')
        return self.request(dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=spec.get('blocks',[]),
                                 proof=proof,target=spec['target']),limit)
    def close(self):
        super().close()
        for stream in (self.process.stdin,self.process.stdout,self.process.stderr):stream.close()


INVENTORY_CERTIFICATION_VERSION = 'native-inventory-exact-dependency-closures-v2'
INVENTORY_CERTIFICATION_SCHEMA = 'native-inventory-dependency-closure-certification-v1'
MAX_REGISTRATION_MICRO_STEPS = 5 * 10**9

class InventoryCertificationError(ValueError):
    """Malformed certificate/custody is never inventory authority."""

def _strict_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')

def _strict_sha(value):
    return hashlib.sha256(_strict_bytes(value)).hexdigest()

def _ordered_inventory(inventory):
    """Check registry coherence, not mathematical truth; Native checks bodies."""
    if type(inventory) is not dict:
        raise InventoryCertificationError('inventory must be a literal object')
    for field in ('definitions', 'interfaces', 'native_blocks'):
        if type(inventory.get(field)) is not list:
            raise InventoryCertificationError('complete inventory list '+field)
    rows = inventory['definitions']
    blocks = inventory['native_blocks']
    if blocks != [row.get('definition') if type(row) is dict else None
                  for row in rows]:
        raise InventoryCertificationError('complete definition/native-block order')
    names = []
    dependencies = {}
    seen = set()
    for row, block in zip(rows, blocks):
        if type(row) is not dict or type(block) is not dict:
            raise InventoryCertificationError('literal definition object')
        name = row.get('name')
        if (type(name) is not str or not name or name in seen or
                block.get('name') != name or type(block.get('proof')) is not list):
            raise InventoryCertificationError('unique joined definition identity')
        calls = []
        for command in block['proof']:
            if type(command) is not dict or type(command.get('rule')) is not str:
                raise InventoryCertificationError('literal primitive/call command')
            if command['rule'] == 'block':
                called = command.get('name')
                if type(called) is not str or called not in seen:
                    raise InventoryCertificationError('dependency must precede call')
                if called not in calls:
                    calls.append(called)
        names.append(name)
        dependencies[name] = calls
        seen.add(name)
    interfaces = inventory['interfaces']
    if (any(type(name) is not str or name not in seen for name in interfaces) or
            len(set(interfaces)) != len(interfaces)):
        raise InventoryCertificationError('every original interface is registered')
    return names, dependencies

def plan_dependency_closures(inventory):
    """Every definition, not just exported/used interfaces, receives a request.

    Each request carries its complete recursive dependency closure in the
    unchanged registry order. Earlier acceptance is never an imported axiom.
    """
    names, dependencies = _ordered_inventory(inventory)
    closures = {}
    plans = []
    for name in names:
        needed = {name}
        for dep in dependencies[name]:
            needed.update(closures[dep])
        closures[name] = needed
        plans.append(dict(definition=name,
                          names=[n for n in names if n in needed]))
    if not plans:
        # Native must still check the full theory and a closed tautology.
        plans = [dict(definition=None, names=[])]
    return plans

def _closure_request(spec, blocks):
    taut = ['imp', ['bot'], ['bot']]
    return dict(protocol='gcts-fol-1', theory=copy.deepcopy(spec['theory']),
                blocks=copy.deepcopy(blocks),
                proof=[dict(rule='tautology', formula=copy.deepcopy(taut))],
                target=copy.deepcopy(taut))

def _checked_native_record(oracle, result, request, purpose, before, allowance):
    if type(result) is not dict or type(oracle.records) is not list:
        raise InventoryCertificationError('full retained Native record required')
    index = result.get('id')
    if (type(index) is not int or index != before or
            len(oracle.records) != before + 1 or oracle.records[index] != result):
        raise InventoryCertificationError('one fresh serial Native record')
    if (result.get('purpose') != purpose or result.get('request') != request or
            result.get('request_sha256') != _strict_sha(request)):
        raise InventoryCertificationError('whole current Native request join')
    outcome = result.get('result')
    if type(outcome) is not dict:
        raise InventoryCertificationError('Native outcome object')
    status = outcome.get('status')
    if status not in ('accepted', 'rejected', 'unknown_space_budget',
                      'unknown_step_budget'):
        raise InventoryCertificationError('known Native disposition')
    steps = outcome.get('micro_steps')
    if type(steps) is not int or not 0 <= steps <= allowance:
        raise InventoryCertificationError('exact consumed Native step budget')
    return index, status, steps

def _check_inventory_dependency_closures(spec, inventory, oracle, limit):
    began = time.perf_counter()
    if type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS:
        raise InventoryCertificationError('positive unchanged aggregate step cap')
    if type(spec) is not dict or type(spec.get('theory')) is not dict:
        raise InventoryCertificationError('full declared theory')
    if type(getattr(oracle, 'records', None)) is not list:
        raise InventoryCertificationError('original full Native record stream')
    original_bytes = _strict_bytes(inventory)
    snapshot = copy.deepcopy(inventory)
    original_theory = _strict_bytes(spec['theory'])
    plans = plan_dependency_closures(snapshot)
    blocks = {block['name']:block for block in snapshot['native_blocks']}
    names = [row['name'] for row in snapshot['definitions']]
    receipts = []
    accepted = set()
    used = 0
    disposition = 'native_accepted'
    stop_reason = None
    for ordinal, plan in enumerate(plans):
        if _strict_bytes(inventory) != original_bytes:
            raise InventoryCertificationError('original complete inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        remaining = limit - used
        if remaining == 0:
            disposition = 'unknown_native_inventory'
            stop_reason = 'aggregate_registration_micro_step_budget'
            break
        request = _closure_request(spec, [blocks[name] for name in plan['names']])
        expected = copy.deepcopy(request)
        before = len(oracle.records)
        purpose = 'check_generated_lemma_definition_closure'
        q = oracle.request(request, remaining, purpose)
        index, status, consumed = _checked_native_record(
            oracle, q, expected, purpose, before, remaining)
        receipts.append(dict(ordinal=ordinal, definition=plan['definition'],
                             closure_names=list(plan['names']), query=index,
                             request_sha256=_strict_sha(expected),
                             assigned_micro_step_limit=remaining,
                             consumed_micro_steps=consumed,
                             aggregate_consumed_before=used,
                             aggregate_consumed_after=used+consumed,
                             result_status=status))
        used += consumed
        if _strict_bytes(inventory) != original_bytes:
            raise InventoryCertificationError('original complete inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        if status != 'accepted':
            disposition = ('native_rejected' if status == 'rejected'
                           else 'unknown_native_inventory')
            stop_reason = status
            break
        accepted.update(plan['names'])
    complete = (disposition == 'native_accepted' and len(receipts) == len(plans)
                and accepted == set(names))
    if disposition == 'native_accepted' and not complete:
        raise InventoryCertificationError('acceptance requires complete coverage')
    if _strict_bytes(snapshot) != original_bytes:
        raise InventoryCertificationError('owned complete inventory mutated')
    certification = dict(
        schema=INVENTORY_CERTIFICATION_SCHEMA,
        version=INVENTORY_CERTIFICATION_VERSION,
        mode='dependency_closures',
        inventory_sha256=hashlib.sha256(original_bytes).hexdigest(),
        theory_sha256=hashlib.sha256(original_theory).hexdigest(),
        aggregate_micro_step_limit=limit,
        aggregate_consumed_micro_steps=used,
        all_original_definition_names=names,
        all_original_interfaces=list(snapshot['interfaces']),
        planned_requests=plans,
        receipts=receipts,
        accepted_definition_names=[name for name in names if name in accepted],
        complete=complete, stop_reason=stop_reason,
        scope='Every original definition is checked with its exact recursive '
              'dependency closure by the unchanged Native checker. All bodies '
              'are rechecked inside each request; no prior theorem is imported. '
              'The entire original inventory is returned even after rejection '
              'or UNKNOWN. Only complete all-definition acceptance is authority. '
              'The same aggregate registration micro-step cap is shared across '
              'all requests; all preparation, calls and output remain charged. '
              'Fresh whole final proof checking remains mandatory.')
    return dict(snapshot, status=disposition, query=None,
                queries=[row['query'] for row in receipts],
                certification=certification, seconds=time.perf_counter()-began)

def _check_inventory_modes_v2_parent(spec, inventory, oracle, limit=5*10**9, *, mode='bulk'):
    """Explicit unchanged bulk control or all-definition closure certification."""
    if mode == 'bulk':
        return _check_inventory_bulk_parent(spec, inventory, oracle, limit)
    if mode == 'dependency_closures':
        return _check_inventory_dependency_closures(spec, inventory, oracle, limit)
    raise InventoryCertificationError('unknown inventory certification mode')

def _check_inventory_bulk_parent(spec,inventory,oracle,limit=5*10**9):
    taut=['imp',['bot'],['bot']]
    request=dict(protocol='gcts-fol-1',theory=spec['theory'],blocks=inventory['native_blocks'],proof=[dict(rule='tautology',formula=taut)],target=taut)
    q=oracle.request(request,limit,'check_generated_lemma_definitions')
    status='native_accepted' if q['result']['status']=='accepted' else 'native_rejected' if q['result']['status']=='rejected' else 'unknown_native_inventory'
    return dict(**inventory,status=status,query=q['id'],seconds=q['seconds'])


GROUP_CERTIFICATION_VERSION = 'native-inventory-adaptive-groups-v1'
GROUP_CERTIFICATION_SCHEMA = 'native-inventory-adaptive-group-certification-v1'


def _group_closure_names(target_names, names, dependencies):
    """Complete dependency closure, including every target, in original order."""
    wanted = set()
    pending = list(target_names)
    while pending:
        name = pending.pop()
        if name in wanted:
            continue
        wanted.add(name)
        pending.extend(dependencies[name])
    return [name for name in names if name in wanted]


def _check_inventory_adaptive_groups(spec, inventory, oracle, limit):
    """Space failures split a group; every probe shares one unchanged work cap.

    This is a different explicit certification strategy, not a retry of an old
    invocation. No accepted prefix is exposed as search authority. A child
    request rechecks every dependency body; accepted parents are never axioms.
    """
    began = time.perf_counter()
    if type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS:
        raise InventoryCertificationError('positive unchanged aggregate step cap')
    if type(spec) is not dict or type(spec.get('theory')) is not dict:
        raise InventoryCertificationError('full declared theory')
    if type(getattr(oracle, 'records', None)) is not list:
        raise InventoryCertificationError('original full Native record stream')
    original_bytes = _strict_bytes(inventory)
    original_theory = _strict_bytes(spec['theory'])
    snapshot = copy.deepcopy(inventory)
    names, dependencies = _ordered_inventory(snapshot)
    blocks = {block['name']: block for block in snapshot['native_blocks']}
    # Even an empty inventory must admit the whole theory and a closed tautology.
    pending = [dict(path=[], target_names=list(names))]
    receipts = []
    accepted = set()
    used = 0
    disposition = 'native_accepted'
    stop_reason = None
    while pending:
        if _strict_bytes(inventory) != original_bytes or _strict_bytes(snapshot) != original_bytes:
            raise InventoryCertificationError('complete original inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        remaining = limit - used
        if remaining == 0:
            disposition = 'unknown_native_inventory'
            stop_reason = 'aggregate_registration_micro_step_budget'
            break
        group = pending[0]
        targets = group['target_names']
        closure = _group_closure_names(targets, names, dependencies)
        request = _closure_request(spec, [blocks[name] for name in closure])
        expected = copy.deepcopy(request)
        before = len(oracle.records)
        purpose = 'check_generated_lemma_definition_group'
        q = oracle.request(request, remaining, purpose)
        index, status, consumed = _checked_native_record(
            oracle, q, expected, purpose, before, remaining)
        if status == 'accepted':
            action = 'accept_group'
        elif status == 'unknown_space_budget' and len(targets) > 1:
            action = 'split_group'
        else:
            action = 'stop_inventory'
        receipts.append(dict(
            ordinal=len(receipts), path=list(group['path']),
            target_names=list(targets), closure_names=closure, query=index,
            request_sha256=_strict_sha(expected),
            assigned_micro_step_limit=remaining, consumed_micro_steps=consumed,
            aggregate_consumed_before=used, aggregate_consumed_after=used+consumed,
            result_status=status, action=action))
        used += consumed
        if _strict_bytes(inventory) != original_bytes or _strict_bytes(snapshot) != original_bytes:
            raise InventoryCertificationError('complete original inventory mutated')
        if _strict_bytes(spec['theory']) != original_theory:
            raise InventoryCertificationError('original full theory mutated')
        if action == 'accept_group':
            accepted.update(closure)
            pending.pop(0)
        elif action == 'split_group':
            midpoint = len(targets) // 2
            path = group['path']
            pending[:1] = [dict(path=path+[0], target_names=targets[:midpoint]),
                           dict(path=path+[1], target_names=targets[midpoint:])]
        else:
            disposition = ('native_rejected' if status == 'rejected'
                           else 'unknown_native_inventory')
            stop_reason = status
            break
    complete = not pending and accepted == set(names)
    if (disposition == 'native_accepted') is not complete:
        raise InventoryCertificationError('only complete all-definition acceptance is authority')
    certification = dict(
        schema=GROUP_CERTIFICATION_SCHEMA, version=GROUP_CERTIFICATION_VERSION,
        mode='adaptive_groups', inventory_sha256=hashlib.sha256(original_bytes).hexdigest(),
        theory_sha256=hashlib.sha256(original_theory).hexdigest(),
        aggregate_micro_step_limit=limit, aggregate_consumed_micro_steps=used,
        all_original_definition_names=names,
        all_original_interfaces=list(snapshot['interfaces']),
        initial_group=dict(path=[], target_names=list(names)),
        split_policy='left_first_binary_midpoint_only_after_space_unknown',
        receipts=receipts, pending_groups=copy.deepcopy(pending),
        accepted_definition_names=[name for name in names if name in accepted],
        complete=complete, stop_reason=stop_reason,
        scope='Full-theory Native requests carry complete recursive dependency '
              'closures in unchanged registry order. Every failed parent probe '
              'is charged. Space UNKNOWN alone splits a nonsingleton group at '
              'its index midpoint, left child first. No accepted prefix or '
              'earlier result is imported as an axiom. All original definitions '
              'and interfaces are returned on every disposition. Search requires '
              'complete coverage; final whole proof Native checking is separate.')
    return dict(snapshot, status=disposition, query=None,
                queries=[receipt['query'] for receipt in receipts],
                certification=certification, seconds=time.perf_counter()-began)


def check_inventory(spec, inventory, oracle, limit=5*10**9, *, mode='bulk'):
    """Historical modes are exact delegates; adaptive grouping is explicit."""
    if mode == 'adaptive_groups':
        return _check_inventory_adaptive_groups(spec, inventory, oracle, limit)
    return _check_inventory_modes_v2_parent(spec, inventory, oracle, limit, mode=mode)


# The entire V3 Source above is retained verbatim. Only this explicit new lane
# uses the injected structural certificate module; old modes delegate below.
_SCHEMA_THREE_MODES_PARENT = check_inventory
SCHEMA_ADMISSION_IMPLEMENTATION_VERSION = 'inventory-schema-then-native-v1'
SCHEMA_ADMISSION_SCHEMA = 'schema-then-native-inventory-certification-v1'
_SCHEMA_CERTIFICATE_VERSION = 'mp-schema-certificates-v1'
_SCHEMA_CERTIFICATE_RESULT = 'mp-schema-certificate-result-v1'
_SCHEMA_CONTEXT_FIELDS = frozenset(('certificate_module','library','source_epoch',
    'semantic_epoch','source_guard','check','formula_validator',
    'theory_admission_record_id'))


def _schema_context_anchors(context):
    if type(context) is not dict or set(context) != _SCHEMA_CONTEXT_FIELDS:
        raise InventoryCertificationError('exact eight-field schema_context')
    module = context['certificate_module']
    anchors = dict(module=module,
        certify=getattr(module,'certify_family',None),
        revalidate=getattr(module,'revalidate_certificate',None),
        ground=getattr(module,'check_ground_instance',None),
        check=context['check'], guard=context['source_guard'],
        formula_validator=context['formula_validator'])
    if (getattr(module,'VERSION',None) != _SCHEMA_CERTIFICATE_VERSION or
            any(not callable(anchors[k]) for k in
                ('certify','revalidate','ground','check','guard','formula_validator'))):
        raise InventoryCertificationError('current pinned certificate/callback ABI')
    if (type(context['library']) is not list or not context['library'] or
            type(context['source_epoch']) is not dict or not context['source_epoch'] or
            type(context['semantic_epoch']) is not dict):
        raise InventoryCertificationError('full original library and current epochs')
    return anchors


def _schema_literal_context(context):
    return dict(library=context['library'],source_epoch=context['source_epoch'],
        semantic_epoch=context['semantic_epoch'],
        theory_admission_record_id=context['theory_admission_record_id'])


def _schema_packet(packet,operation,allowed):
    """Protocol checks add no logical truth beyond the qualified certifier."""
    if (type(packet) is not dict or packet.get('schema') != _SCHEMA_CERTIFICATE_RESULT or
            packet.get('version') != _SCHEMA_CERTIFICATE_VERSION or
            packet.get('operation') != operation or packet.get('status') not in allowed):
        raise InventoryCertificationError('exact schema result protocol')
    authority = packet.get('authority')
    if (type(authority) is not dict or authority.get('native_accepted') is not False or
            authority.get('Model_permission') is not False or
            authority.get('logical_target_proof_accepted') is not False):
        raise InventoryCertificationError('certificate packets never grant Native/Model authority')
    positive = packet['status'] in ('ELIGIBLE_CERTIFICATE','GROUND_CORRESPONDENCE')
    if positive and (packet.get('input_custody_complete') is not True or
                     type(packet.get('certificate')) is not dict):
        raise InventoryCertificationError('complete eligible certificate packet')
    if packet['status'] == 'GROUND_CORRESPONDENCE' and type(packet.get('ground_correspondence')) is not dict:
        raise InventoryCertificationError('complete ground correspondence packet')
    if not positive and (packet.get('certificate') is not None or packet.get('ground_correspondence') is not None):
        raise InventoryCertificationError('inactive schema prefix has no usable certificate')
    # Freeze each returned packet immediately. No field/authority is relabeled.
    return copy.deepcopy(packet)


def _schema_current_theory_record(spec,oracle,index):
    if (type(index) is not int or not 0 <= index < len(oracle.records) or
            type(oracle.records[index]) is not dict):
        raise InventoryCertificationError('strict current compiler theory record ID')
    record = oracle.records[index]
    expected = _closure_request(spec,[])
    result = record.get('result')
    if (record.get('id') != index or type(record.get('id')) is not int or
            record.get('purpose') != 'first_order_theory_admission' or
            record.get('query_target') != 'fixed_assertion' or
            record.get('request') != expected or
            record.get('request_sha256') != _strict_sha(expected) or
            type(result) is not dict or result.get('status') != 'accepted' or
            type(result.get('micro_steps')) is not int or result['micro_steps'] < 0):
        raise InventoryCertificationError('fresh literal full-current-theory Native admission join')
    for field in ('input_sha256','output_sha256'):
        value=record.get(field)
        if type(value) is not str or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):
            raise InventoryCertificationError('complete current theory Native input/output identity')
    return copy.deepcopy(record)


def _check_inventory_schema_then_native(spec,inventory,oracle,limit,context):
    began=time.perf_counter()
    if type(limit) is not int or not 0 < limit <= MAX_REGISTRATION_MICRO_STEPS:
        raise InventoryCertificationError('positive unchanged aggregate Native fallback cap')
    if type(spec) is not dict or type(spec.get('theory')) is not dict:
        raise InventoryCertificationError('full declared current receiver/theory')
    if type(getattr(oracle,'records',None)) is not list:
        raise InventoryCertificationError('complete current Native record stream')
    anchors=_schema_context_anchors(context)
    check,guard=anchors['check'],anchors['guard']
    check();guard();check()
    original_inventory=_strict_bytes(inventory);original_spec=_strict_bytes(spec)
    literal_context=copy.deepcopy(_schema_literal_context(context))
    context_bytes=_strict_bytes(literal_context)
    snapshot=copy.deepcopy(inventory)
    names,dependencies=_ordered_inventory(snapshot)
    plans=plan_dependency_closures(snapshot)
    initial_records=copy.deepcopy(oracle.records);initial_records_bytes=_strict_bytes(initial_records)
    original_record_count=len(initial_records)
    expected_records=copy.deepcopy(initial_records)
    theory_record=_schema_current_theory_record(spec,oracle,context['theory_admission_record_id'])
    library=literal_context['library'];by_family={};original_family_ids=[]
    for f in library:
        check()
        if (type(f) is not dict or type(f.get('id')) is not str or f['id'] in by_family or
                type(f.get('dependencies')) is not list or
                any(type(i) is not str for i in f['dependencies'])):
            raise InventoryCertificationError('full unique original family dependency inventory')
        by_family[f['id']]=f;original_family_ids.append(f['id'])
    if any(dep not in by_family for f in library for dep in f['dependencies']):
        raise InventoryCertificationError('every declared family dependency retained')
    family_rows={};evaluation_order=[];certificates={};active=set()
    ground_rows=[];schema_names=[];native_names=[];native_receipts=[]
    packet_locations=[];used=0;stop=None

    def custody():
        check();guard();check()
        if (set(context) != _SCHEMA_CONTEXT_FIELDS or
                context['certificate_module'] is not anchors['module'] or
                context['check'] is not check or context['source_guard'] is not guard or
                context['formula_validator'] is not anchors['formula_validator'] or
                getattr(anchors['module'],'VERSION',None) != _SCHEMA_CERTIFICATE_VERSION or
                getattr(anchors['module'],'certify_family',None) is not anchors['certify'] or
                getattr(anchors['module'],'revalidate_certificate',None) is not anchors['revalidate'] or
                getattr(anchors['module'],'check_ground_instance',None) is not anchors['ground']):
            raise InventoryCertificationError('current certificate/callback identities changed')
        if (_strict_bytes(_schema_literal_context(context)) != context_bytes or
                _strict_bytes(spec) != original_spec or
                _strict_bytes(inventory) != original_inventory or
                _strict_bytes(snapshot) != original_inventory or
                _strict_bytes(literal_context) != context_bytes):
            raise InventoryCertificationError('whole schema context/input ownership changed')
        if (len(oracle.records) < original_record_count or
                _strict_bytes(oracle.records[:original_record_count]) != initial_records_bytes or
                _strict_bytes(oracle.records) != _strict_bytes(expected_records)):
            raise InventoryCertificationError('complete current Native record stream changed')
        check()

    def blocked(status,reason):
        nonlocal stop
        if stop is None:stop=dict(status=status,reason=reason)

    def cert_kwargs():
        return dict(source_epoch=copy.deepcopy(literal_context['source_epoch']),
            semantic_epoch=copy.deepcopy(literal_context['semantic_epoch']),
            source_guard=guard,check=check)

    def family(fid):
        if stop is not None or fid in family_rows:return
        if fid in active:raise InventoryCertificationError('cyclic original family DAG')
        active.add(fid);f=by_family[fid]
        for dep in f['dependencies']:
            family(dep)
            if stop is not None:
                active.remove(fid);return
        custody()
        supplied=[copy.deepcopy(certificates[i]) for i in sorted(f['dependencies']) if i in certificates]
        packet=anchors['certify'](family=copy.deepcopy(f),certified_dependencies=supplied,**cert_kwargs())
        packet=_schema_packet(packet,'certify_family',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))
        row=dict(family_id=fid,original_library_index=original_family_ids.index(fid),
            certification=packet,revalidation=None,disposition=packet['status'])
        family_rows[fid]=row;evaluation_order.append(fid)
        packet_locations.append(dict(stage='family_certification',family_id=fid))
        custody()
        if packet['status']=='ELIGIBLE_CERTIFICATE':
            again=anchors['revalidate'](certificate=copy.deepcopy(packet['certificate']),**cert_kwargs())
            again=_schema_packet(again,'revalidate_certificate',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))
            row['revalidation']=again;row['disposition']=again['status']
            packet_locations.append(dict(stage='family_revalidation',family_id=fid))
            custody()
            if again['status']=='ELIGIBLE_CERTIFICATE':certificates[fid]=copy.deepcopy(again['certificate'])
            elif again['status']=='UNKNOWN':blocked('unknown_schema_inventory','family_revalidation_UNKNOWN')
            else:blocked('schema_rejected','eligible_certificate_revalidation_failed')
        elif packet['status']=='UNKNOWN':blocked('unknown_schema_inventory','family_certification_UNKNOWN')
        elif packet['status']=='REJECTED':blocked('schema_rejected','family_certification_REJECTED')
        active.remove(fid)

    custody()
    for fid in original_family_ids:
        family(fid)
        if stop is not None:break
    family_complete=len(family_rows)==len(original_family_ids) and stop is None
    blocks={b['name']:b for b in snapshot['native_blocks']}
    if family_complete:
        for ordinal,row in enumerate(snapshot['definitions']):
            custody();fid=row.get('family')
            if fid not in family_rows:raise InventoryCertificationError('every original ground family must remain in full library')
            observed=dict(ordinal=ordinal,name=row['name'],family_id=fid,
                correspondence=None,Native_fallback=None,disposition='PENDING')
            ground_rows.append(observed)
            fallback=family_rows[fid]['disposition']=='NOT_ELIGIBLE'
            if not fallback:
                packet=anchors['ground'](certificate=copy.deepcopy(certificates[fid]),
                    arguments=copy.deepcopy(row['arguments']),ground_definition=copy.deepcopy(row),
                    dependency_definitions=copy.deepcopy(snapshot['definitions']),
                    formula_validator=anchors['formula_validator'],**cert_kwargs())
                packet=_schema_packet(packet,'check_ground_instance',('GROUND_CORRESPONDENCE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))
                observed['correspondence']=packet;observed['disposition']=packet['status']
                packet_locations.append(dict(stage='ground_correspondence',definition=row['name']))
                custody()
                if packet['status']=='GROUND_CORRESPONDENCE':
                    schema_names.append(row['name']);continue
                if packet['status']=='NOT_ELIGIBLE':fallback=True
                elif packet['status']=='UNKNOWN':
                    blocked('unknown_schema_inventory','ground_correspondence_UNKNOWN');break
                else:
                    blocked('schema_rejected','ground_correspondence_REJECTED');break
            if fallback:
                remaining=limit-used
                if remaining==0:
                    observed['disposition']='PENDING_NATIVE_BUDGET'
                    blocked('unknown_native_inventory','aggregate_registration_micro_step_budget');break
                plan=plans[ordinal]
                if plan['definition']!=row['name']:raise InventoryCertificationError('exact ordinary Native closure target')
                request=_closure_request(spec,[blocks[n] for n in plan['names']])
                expected=copy.deepcopy(request);before=len(oracle.records)
                purpose='check_schema_ineligible_lemma_definition_closure'
                q=oracle.request(request,remaining,purpose)
                index,status,consumed=_checked_native_record(oracle,q,expected,purpose,before,remaining)
                receipt=dict(ordinal=len(native_receipts),definition=row['name'],closure_names=list(plan['names']),
                    query=index,request=expected,record=copy.deepcopy(q),
                    assigned_micro_step_limit=remaining,consumed_micro_steps=consumed,
                    aggregate_consumed_before=used,aggregate_consumed_after=used+consumed,result_status=status)
                expected_records.append(copy.deepcopy(q))
                native_receipts.append(receipt);observed['Native_fallback']=receipt
                observed['disposition']='NATIVE_CLOSURE_ACCEPTED' if status=='accepted' else status
                used+=consumed;custody()
                if status=='accepted':native_names.append(row['name'])
                else:
                    blocked('native_rejected' if status=='rejected' else 'unknown_native_inventory',status);break
    custody()
    covered=set(schema_names)|set(native_names)
    complete=(stop is None and family_complete and len(ground_rows)==len(names) and covered==set(names))
    if stop is None and not complete:raise InventoryCertificationError('schema lane requires complete all-family/all-ground coverage')
    status='schema_admitted' if complete else stop['status']
    certification=dict(schema=SCHEMA_ADMISSION_SCHEMA,version=SCHEMA_ADMISSION_IMPLEMENTATION_VERSION,
        mode='schema_then_native',source_epoch=literal_context['source_epoch'],semantic_epoch=literal_context['semantic_epoch'],
        complete_original_library=library,original_family_ids=original_family_ids,
        family_evaluation_order=evaluation_order,
        family_census=[family_rows[i] for i in original_family_ids if i in family_rows],
        family_census_complete=family_complete,pending_family_ids=[i for i in original_family_ids if i not in family_rows],
        all_original_definition_names=names,all_original_interfaces=list(snapshot['interfaces']),
        ground_census=ground_rows,pending_definition_names=[i for i in names if i not in covered],
        schema_correspondence_definition_names=schema_names,Native_checked_definition_names=native_names,
        theory_admission=dict(record_id=literal_context['theory_admission_record_id'],record=theory_record,
            scope='Exact fresh current compiler full-theory admission reused from this owned oracle stream; no earlier lemma is imported.',
            registration_microsteps_charged=0,compile_microsteps=theory_record['result']['micro_steps']),
        aggregate_micro_step_limit=limit,aggregate_consumed_micro_steps=used,
        Native_fallback_receipts=native_receipts,returned_component_packet_locations=packet_locations,
        complete=complete,stop_reason=None if complete else stop['reason'],
        Model_permission=complete,native_accepted=False,fresh_Native_target_proof_accepted=False,
        final_whole_Native_required=True,
        authority_scope='Explicit conditional structural inventory admission only after complete schema correspondence or exact Native fallback for EVERY original ground definition. The certificate packets remain unchanged and grant no Model/Native permission themselves. This new registry gate is a separately reviewed trust assumption; not a new axiom or kernel rule. The original full current theory record is joined and all ineligible fallback requests include complete literal recursive bodies, including schema-eligible dependencies. No partial prefix is active. Fresh whole original Native target proof checking remains mandatory.',
        cost_scope='All guards, certificate construction/revalidation/ground expansion, copies, current-theory custody, Native fallback and output are charged to the Root original absolute work/closure profile. Symbolic work and Native microsteps are different units.')
    return dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],
        certification=certification,seconds=time.perf_counter()-began)


def check_inventory(spec,inventory,oracle,limit=5*10**9,*,mode='bulk',schema_context=None):
    """Three historical exact delegates or the explicit new structural lane."""
    if mode=='schema_then_native':
        return _check_inventory_schema_then_native(spec,inventory,oracle,limit,schema_context)
    return _SCHEMA_THREE_MODES_PARENT(spec,inventory,oracle,limit,mode=mode)
