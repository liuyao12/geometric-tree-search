"""Source construction only. Never imports or calls any project component."""
import ast
from pathlib import Path

D=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019')
P=Path('/private/tmp/gcts-schema-admission-source-20261019/semantic_inventory_oracle_v4.py')
old=P.read_text();tree=ast.parse(old)
def text(name):
    n=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name==name)
    return ''.join(old.splitlines(keepends=True)[n.lineno-1:n.end_lineno])

header='''

# Explicit owned-evidence entry only. The entire historical V4 Source above is
# retained byte-for-byte; no handle enters its defaults or historical modes.
OWNED_EVIDENCE_IMPLEMENTATION_VERSION='schema-owned-evidence-registry-v1'
_OWNED_STORE_VERSION='owned-evidence-adapter-v1'
_OWNED_ADMISSION_FIELDS=('schema','version','mode','complete','Model_permission',
    'native_accepted','fresh_Native_target_proof_accepted','final_whole_Native_required')


def _owned_store_anchors(store):
    # Interface custody only. Root must authenticate adapter Source/class/owner;
    # a duck API or a storage capability is never mathematical authority.
    names=('capture','assemble','inventory_bundle','unwrap_inventory')
    methods={name:getattr(store,name,None) for name in names}
    if (type(getattr(store,'VERSION',None)) is not str or
            getattr(store,'VERSION',None)!=_OWNED_STORE_VERSION or
            any(not callable(value) for value in methods.values())):
        raise InventoryCertificationError('explicit current owned-evidence Store ABI')
    return methods


def _owned_store_current(store,anchors):
    if (type(getattr(store,'VERSION',None)) is not str or
            getattr(store,'VERSION',None)!=_OWNED_STORE_VERSION):
        raise InventoryCertificationError('owned-evidence Store version changed')
    for name,prior in anchors.items():
        current=getattr(store,name,None)
        if (getattr(current,'__self__',None) is not getattr(prior,'__self__',None) or
                getattr(current,'__func__',current) is not getattr(prior,'__func__',prior)):
            raise InventoryCertificationError('owned-evidence Store callable changed')


def _owned_packet_label(location):
    return 'registry_owned:'+_strict_bytes(location).decode('utf8')


'''
packet=text('_schema_packet')
packet=packet.replace('def _schema_packet(packet,operation,allowed):',
    'def _schema_packet_owned(packet,operation,allowed,store,store_anchors,location):',1)
packet=packet.replace('    """Protocol checks add no logical truth beyond the qualified certifier."""',
    '    """Exact parent protocol, then capture before any retention copy."""',1)
end='''    # Freeze each returned packet immediately. No field/authority is relabeled.
    return copy.deepcopy(packet)
'''
replacement='''    _owned_store_current(store,store_anchors)
    reference=store_anchors['capture'](packet,label=_owned_packet_label(location))
    _owned_store_current(store,store_anchors)
    return packet,reference
'''
assert packet.count(end)==1;packet=packet.replace(end,replacement,1)
owned=text('_check_inventory_schema_then_native')
owned=owned.replace('def _check_inventory_schema_then_native(spec,inventory,oracle,limit,context):',
    "def check_inventory_owned(spec,inventory,oracle,limit=5*10**9,*,mode='schema_then_native',schema_context=None,evidence_store):\n"
    '    """Explicit new bundle ABI; no ordinary-success fallback on failure."""\n'
    "    if type(mode) is not str or mode!='schema_then_native':\n"
    "        raise InventoryCertificationError('owned evidence requires explicit schema_then_native lane')\n"
    '    context=schema_context',1)
owned=owned.replace('    anchors=_schema_context_anchors(context)\n',
    '    anchors=_schema_context_anchors(context)\n    store_anchors=_owned_store_anchors(evidence_store)\n',1)
needle='''        check()

    def blocked(status,reason):'''
assert owned.count(needle)==1
owned=owned.replace(needle,'''        check()
        _owned_store_current(evidence_store,store_anchors)

    def blocked(status,reason):''',1)
owned=owned.replace("        packet=_schema_packet(packet,'certify_family',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))",'''        packet,packet_ref=_schema_packet_owned(packet,'certify_family',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'),
            evidence_store,store_anchors,dict(packet_ordinal=len(packet_locations),stage='family_certification',
                family_id=fid,original_library_index=original_family_ids.index(fid)))''',1)
owned=owned.replace("            certification=packet,revalidation=None,disposition=packet['status'])", "            certification=packet_ref,revalidation=None,disposition=packet['status'])",1)
owned=owned.replace("            again=_schema_packet(again,'revalidate_certificate',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))",'''            again,again_ref=_schema_packet_owned(again,'revalidate_certificate',('ELIGIBLE_CERTIFICATE','NOT_ELIGIBLE','REJECTED','UNKNOWN'),
                evidence_store,store_anchors,dict(packet_ordinal=len(packet_locations),stage='family_revalidation',
                    family_id=fid,original_library_index=original_family_ids.index(fid)))''',1)
owned=owned.replace("            row['revalidation']=again;row['disposition']=again['status']", "            row['revalidation']=again_ref;row['disposition']=again['status']",1)
owned=owned.replace("                packet=_schema_packet(packet,'check_ground_instance',('GROUND_CORRESPONDENCE','NOT_ELIGIBLE','REJECTED','UNKNOWN'))",'''                packet,packet_ref=_schema_packet_owned(packet,'check_ground_instance',('GROUND_CORRESPONDENCE','NOT_ELIGIBLE','REJECTED','UNKNOWN'),
                    evidence_store,store_anchors,dict(packet_ordinal=len(packet_locations),stage='ground_correspondence',
                        ordinal=ordinal,definition=row['name'],family_id=fid))''',1)
owned=owned.replace("                observed['correspondence']=packet;observed['disposition']=packet['status']", "                observed['correspondence']=packet_ref;observed['disposition']=packet['status']\n                packet_status=packet['status'];del packet",1)
for label in ['GROUND_CORRESPONDENCE','NOT_ELIGIBLE','UNKNOWN']:
    ground=owned.index('    blocks=')
    owned=owned[:ground]+owned[ground:].replace("packet['status']=='"+label+"'", "packet_status=='"+label+"'")
before='''    return dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],
        certification=certification,seconds=time.perf_counter()-began)
'''
after='''    # Fix the one legacy elapsed scalar before immutable assembly. The outer
    # driver stage/cold interval must also charge assembly/bundle/final custody.
    seconds=time.perf_counter()-began
    logical=dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],
        certification=certification,seconds=seconds)
    logical_ref=store_anchors['assemble'](logical,
        label=_owned_packet_label(dict(stage='logical_registry_return')))
    custody()
    operational=dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],
        certification={key:certification[key] for key in _OWNED_ADMISSION_FIELDS},seconds=seconds)
    bundle=store_anchors['inventory_bundle'](operational,logical_ref)
    custody()
    return bundle
'''
assert owned.count(before)==1;owned=owned.replace(before,after,1)
out=D/'semantic_inventory_oracle_v5.py'
out.write_text(old+header+packet+'\n\n'+owned)
