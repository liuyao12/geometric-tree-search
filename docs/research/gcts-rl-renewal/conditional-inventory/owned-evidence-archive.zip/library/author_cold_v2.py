"""Metadata-only Source construction; never imports or calls target modules."""
from pathlib import Path
import ast
import hashlib
import json

D=Path(__file__).parent
P=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_cold_v1.py')
s=P.read_text()
assert hashlib.sha256(P.read_bytes()).hexdigest()=='ca7e91079982948ecbde5816b0d175810031981835ec8ddfa17f273379574868'
changes=[]
def change(old,new,label):
    global s
    assert s.count(old)==1,(label,s.count(old))
    s=s.replace(old,new,1);changes.append(dict(label=label,old=old,new=new))
def pin(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

driver=pin('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py')
registry=pin(D/'semantic_inventory_oracle_v5.py')
evidence={
    'adapter':pin('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_adapter_v3.py'),
    'arena':pin('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py'),
    'join':pin('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_inventory_join_v2.py'),
    'inverse':pin('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py')}
parent_ast=ast.parse(s)
for name,value in [('RECEIVER_DRIVER_SOURCE',driver),('REGISTRY_SOURCE',registry)]:
    node=next(n for n in parent_ast.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name)
    old=ast.get_source_segment(s,node)
    change(old,name+' = '+repr(value),'exact '+name)
change("VERSION = 'schema-admission-intake-cold-v1'","VERSION = 'owned-evidence-intake-cold-v2'",'cold implementation version')
change("PLAN_SCHEMA = 'ROOT-schema-admission-worker-plan-v1'","PLAN_SCHEMA = 'ROOT-owned-evidence-integration-worker-plan-v1'",'explicit worker schema')
change("WORKER_SCHEMA = 'schema-admission-worker-receipt-v1'","WORKER_SCHEMA = 'owned-evidence-integration-worker-receipt-v1'",'explicit receipt schema')

new_constants='''
# Owned evidence is an additional representation boundary, never proof authority.
EVIDENCE_SOURCES = EVIDENCE_SOURCE_LITERAL
EVIDENCE_ALIASES = {'adapter':'owned_evidence_adapter','arena':'exact_evidence_arena',
                    'join':'owned_inventory_join','inverse':'independent_forest_inverse'}
ARENA_LIMITS = {'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536,'depth':512,
    'documents_expanded_bytes':134217728,'edges':8000000,'fragment_bytes':4096,'integer_digits':4096,
    'materialized_bytes':4194304,'materialized_occurrences':100000,'nodes':2000000,
    'root_expanded_bytes':134217728,'roots':4096,'scalar_bytes':16777216,'wire_bytes':134217728,'work':400000000}
ADAPTER_LIMITS = {'operations':400000000,'value_bytes':134217728,'depth':512,'chunk_bytes':65536}
INVERSE_LIMITS = {'nodes':2000000,'edges':8000000,'roots':4096,'depth':513,'work':30000000,
    'expanded_bytes':134217728,'wire_bytes':134217728,'scalar_bytes':16777216,'integer_digits':4096,
    'fragment_bytes':4096,'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536}
INVERSE_VERSION = 'independent-evidence-forest-inverse-v6-full-scalar-and-ledger-bounds'
INVERSE_PROFILE = 'independent-forest-actual-operations-v1'
EVIDENCE_DOCUMENT = 'receiver:complete-legacy-result'
OUTPUT_CAP_BYTES = 134217728
EVIDENCE_PROFILE = dict(schema='owned-evidence-integration-profile-v1',sources=EVIDENCE_SOURCES,
    arena_limits=ARENA_LIMITS,adapter_limits=ADAPTER_LIMITS,inverse_limits=INVERSE_LIMITS,
    inverse_version=INVERSE_VERSION,inverse_execution_profile=INVERSE_PROFILE,
    logical_output='complete-legacy-JSON-body-plus-LF',sole_document=EVIDENCE_DOCUMENT,
    unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION',
    physical_accounting='ordinary_result+forest+all_root_JSON_metadata_including_worker_receipt',
    encoded_and_logical_cap_bytes=OUTPUT_CAP_BYTES)

'''.replace('EVIDENCE_SOURCE_LITERAL',repr(evidence))
change('\n\nclass ColdError(ValueError):',new_constants+'\nclass ColdError(ValueError):','fixed evidence Sources/limits/ABI')

new_helpers='''
def verify_saved_evidence(inverse, wire, forest_pin, result_raw, epoch, check):
    """Independent fresh forest preparation and complete BODY+one-LF byte join.

    This verifies representation only. No hash or arena reference substitutes
    for either the ordinary point check or final current Native proof check.
    """
    check()
    need(type(wire) is dict and set(wire)=={'schema','version','source_epoch','semantic_epoch','roots','documents','nodes'},
         'exact seven-field saved forest')
    need(wire['schema']=='exact-evidence-forest-v1' and wire['version']=='exact-evidence-arena-v1' and
         type(wire['source_epoch']) is str and type(wire['semantic_epoch']) is str and
         wire['source_epoch']==canonical(epoch).decode('utf8') and
         wire['semantic_epoch']==canonical(epoch['evidence_storage']).decode('utf8'),
         'full literal Source and semantic epoch headers')
    need(type(wire['documents']) is list and wire['documents']==[EVIDENCE_DOCUMENT],
         'sole complete legacy logical document')
    need(inverse.VERSION==INVERSE_VERSION and inverse.EXECUTION_PROFILE==INVERSE_PROFILE,
         'qualified independent inverse ABI/profile')
    started=_NOW_NS();observed={}
    prepared=inverse.prepare_forest(wire,check,limits=dict(INVERSE_LIMITS),statistics=observed)
    check()
    need(prepared.documents==(EVIDENCE_DOCUMENT,),'prepared sole logical document')
    source=prepared.iter_document(EVIDENCE_DOCUMENT);offset=0
    try:
        while True:
            check()
            try:
                part=next(source)
            except StopIteration:
                # A delegated StopIteration is never accepted as completion.
                if source.completed is not True:
                    raise
                break
            need(type(part) is bytes and len(part)<=INVERSE_LIMITS['chunk_bytes'],
                 'bounded independent byte chunk')
            end=offset+len(part)
            need(end<=len(result_raw) and part==result_raw[offset:end],
                 'every reconstructed BODY byte equals the saved ordinary result')
            offset=end
        need(source.completed is True and result_raw[offset:]==b'\\n',
             'exact single external LF and completed inverse')
    finally:
        source.close()
    check();stats=prepared.statistics()
    need(stats['prepared'] is True and stats['execution_profile']==INVERSE_PROFILE and
         stats['logical_documents']==1 and stats['wire_canonical_bytes']==forest_pin['bytes'] and
         stats['aggregate_document_bytes']==len(result_raw)<=OUTPUT_CAP_BYTES,
         'whole physical/logical inverse ledger')
    document=stats['documents'][EVIDENCE_DOCUMENT]
    need(document['completed'] is True and document['closed_incomplete'] is False and
         document['attempts']==1 and document['body_bytes']==offset and
         document['copied_body_bytes']==document['emitted_body_bytes']==offset and
         document['logical_file_bytes']==offset+1 and
         document['stream_value_occurrences']==document['logical_value_occurrences'],
         'complete one-attempt document bytes/occurrences')
    check()
    return dict(schema='owned-evidence-saved-forest-verification-v1',status='COMPLETE',
        representation_only=True,mathematical_authority=False,started_ns=started,completed_ns=_NOW_NS(),
        logical_body_bytes=offset,logical_file_bytes=len(result_raw),forest=forest_pin,
        declaration=epoch['independent_evidence_inverse'],statistics=stats)


def finalize_output_ledger(actual, header, result_pin, forest_pin, check):
    """Count every root JSON artifact plus the forthcoming complete receipt.

    Source/modules/native wire inputs and streams remain separate fixed inputs
    or separately bounded logs. Receipt bytes are a fixed-point length, not a
    self-hash. Its external raw descriptor is supplied by the once runner.
    """
    check();other=[]
    for p in sorted(actual.iterdir(),key=lambda p:p.name):
        check()
        if p.suffix!='.json' or p.name in ('result.json','evidence-forest.json','worker-receipt.json'):
            continue
        need(not p.is_symlink() and p.is_file(),'ordinary root JSON metadata')
        need(p.stat().st_size<=OUTPUT_CAP_BYTES,'bounded individual metadata artifact')
        raw=p.read_bytes();check();need(len(raw)<=OUTPUT_CAP_BYTES,'bounded metadata growth')
        other.append(descriptor(p,raw))
    base=result_pin['bytes']+forest_pin['bytes']+sum(p['bytes'] for p in other)
    ledger=dict(schema='owned-evidence-physical-output-ledger-v1',cap_bytes=OUTPUT_CAP_BYTES,
        ordinary_result=result_pin,evidence_forest=forest_pin,other_root_JSON_metadata=other,
        worker_receipt_bytes=0,aggregate_physical_bytes=base,
        logical_result_bytes=result_pin['bytes'],logical_cap_bytes=OUTPUT_CAP_BYTES,
        counted_once=True,worker_receipt_descriptor='external_once_runner',
        excluded='fixed Source/module/native inputs and separately bounded stdout/stderr')
    header['owned_output_ledger']=ledger
    for attempt in range(32):
        check();size=len(canonical(header))+1;check()
        total=base+size
        if ledger['worker_receipt_bytes']==size and ledger['aggregate_physical_bytes']==total:
            need(total<=OUTPUT_CAP_BYTES and result_pin['bytes']<=OUTPUT_CAP_BYTES,
                 'aggregate physical and complete expanded logical128MiB limits')
            return
        ledger['worker_receipt_bytes']=size;ledger['aggregate_physical_bytes']=total
    raise ColdError('receipt size ledger did not stabilize')


def failure_output_prefixes(actual, check):
    """Bounded ordinary file descriptors only; never a usable partial forest."""
    out=[]
    for name in ('evidence-forest.json','result.json'):
        check();p=actual/name
        if not p.exists():
            continue
        need(not p.is_symlink() and p.is_file(),'ordinary failed output path')
        size=p.stat().st_size
        need(size<=OUTPUT_CAP_BYTES,'bounded failed output artifact')
        digest=hashlib.sha256();total=0
        with p.open('rb') as stream:
            while True:
                check();part=stream.read(65536)
                if not part:break
                total+=len(part);need(total<=OUTPUT_CAP_BYTES,'failed output growth cap');digest.update(part)
        need(total==size,'failed artifact complete EOF')
        out.append(dict(path=str(p),sha256=digest.hexdigest(),bytes=total,
                        diagnostic_only=True,complete_output_accepted=False))
    return out


'''
change('def main(argv):',new_helpers+'def main(argv):','independent full saved evidence and physical ledgers')
change("    need(plan['mode'] in ('fixed','symbolic'),'declared matched mechanism-control mode')", "    need(plan['mode'] in ('fixed','symbolic'),'declared matched mechanism-control mode')\n    need(plan['receiver_id']=='prospective-fol-20261018-001','fresh known full original001 integration control only')",'explicit001 no002rescue')
change("integration['schema']=='ROOT-schema-admission-comparison-declaration-v1'", "integration['schema']=='ROOT-owned-evidence-integration-comparison-declaration-v1'",'new integration declaration schema')
change("        binding=next((r for r in integration['schedule']", "        need(canonical(integration['evidence_profile'])==canonical(EVIDENCE_PROFILE),\n             'full Source-bound arena/adapter/inverse profile and unchanged encoded/logical caps')\n        binding=next((r for r in integration['schedule']",'full declaration evidence profile')
change("closure['schema']=='ROOT-schema-admission-raw-runtime-closure-v1'", "closure['schema']=='ROOT-owned-evidence-integration-raw-runtime-closure-v1'",'new complete runtime closure schema')
change("        need(closure['schema_sources']==SCHEMA_SOURCES and closure['schema_kernel_source']==SCHEMA_KERNEL_SOURCE,", "        need(closure['evidence_sources']==EVIDENCE_SOURCES,\n             'exact complete extra four evidence Sources without replacement of the base map')\n        need(closure['schema_sources']==SCHEMA_SOURCES and closure['schema_kernel_source']==SCHEMA_KERNEL_SOURCE,",'fixed complete evidence Source map')
change("               'bounded_request_oracle':plan['components']['bounded_transport']}\n        need(len(plan['project_sources'])==22 and len(names)==24 and\n             closure['materialized_aliases']==names, 'complete same24 project/component aliases in the declared pilot')", "               'bounded_request_oracle':plan['components']['bounded_transport'],\n               **{EVIDENCE_ALIASES[role]:pin for role,pin in EVIDENCE_SOURCES.items()}}\n        need(len(plan['project_sources'])==22 and len(names)==28 and\n             closure['materialized_aliases']==names, 'complete same28 base project/component/evidence aliases in both arms')",'same28 explicit base imports botharms')
change('# Seal protected base24/Z3/cold callables BEFORE either schema import.', '# Seal protected base28/Z3/cold callables BEFORE the separate schema import.','base seal count provenance')
change("need(len(loaded)==24 and len(schema_loaded)==1,'full current base24 plus exactly1 schema import')", "need(len(loaded)==28 and len(schema_loaded)==1,'full current base28 plus exactly1 schema import')",'late schema exact count')
old="        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']"
new="""        evidence_owned={role:owned[alias] for role,alias in EVIDENCE_ALIASES.items()}
        epoch['evidence_storage']=dict(schema='owned-evidence-storage-declaration-v1',
            sources={role:evidence_owned[role] for role in ('adapter','arena','join')},
            arena_limits=dict(ARENA_LIMITS),adapter_limits=dict(ADAPTER_LIMITS),
            logical_output='complete-legacy-JSON-body-plus-LF',
            unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION')
        epoch['independent_evidence_inverse']=dict(schema='owned-evidence-independent-inverse-declaration-v1',
            original=EVIDENCE_SOURCES['inverse'],owned=evidence_owned['inverse'],
            version=INVERSE_VERSION,execution_profile=INVERSE_PROFILE,limits=dict(INVERSE_LIMITS),
            sole_document=EVIDENCE_DOCUMENT,stream='BODY-only-plus-one-external-LF',
            authority='representation-only; no Native or mathematical acceptance')
        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']"""
change(old,new,'exact owned driver epoch and independent inverse epoch')
change("receipt=loaded['semantic_receiver_driver'].run_receiver(receiver_spec=", "receipt=loaded['semantic_receiver_driver'].run_receiver_owned(receiver_spec=",'new explicit owned entry')
change("closure_tick=overall_tick,output_path=actual/'result.json')", "closure_tick=overall_tick,output_path=actual/'result.json',\n            evidence_module=loaded[EVIDENCE_ALIASES['adapter']],arena_module=loaded[EVIDENCE_ALIASES['arena']],\n            owned_join_module=loaded[EVIDENCE_ALIASES['join']])",'owned API exact injected modules')
change("        result_raw=raw_file(result_pin)\n        reading_started=", "        need(receipt['version']=='semantic-family-owned-evidence-driver-v1' and\n             receipt['independent_saved_forest_inverse_required'] is True and\n             receipt['ROOT_resource_accepted'] is False, 'no worker receipt is resource authority')\n        need(result_pin['path']==str(actual/'result.json'),'fresh exact full ordinary output path')\n        forest_pin={k:receipt['evidence_forest'][k] for k in ('path','sha256','bytes')}\n        need(forest_pin['path']==str(actual/'evidence-forest.json'),'fresh exact forest sidecar path')\n        result_raw=raw_file(result_pin)\n        reading_started=",'receipt and both exact published artifact pins')
old="        reader_tick();sharing=None"
new="""        # Owned completion and both full representation checks are scientific
        # work even when the final search status is an ordinary UNKNOWN.
        def evidence_tick():
            overall_tick();need(_NOW_NS()<work_ns,'full saved evidence inverse within original work')
        evidence_tick();source_guard()
        forest_raw=raw_file(forest_pin)
        forest_wire=json.loads(forest_raw)
        evidence_tick()
        evidence_verification=verify_saved_evidence(loaded[EVIDENCE_ALIASES['inverse']],forest_wire,
            forest_pin,result_raw,epoch,evidence_tick)
        del forest_wire,forest_raw
        evidence_tick();source_guard()
        reader_tick();sharing=None"""
change(old,new,'fresh independent full forest reread before retained old result parser')
change("        region_check=(verify_raw_region(result_data,work_ns)", "        need(canonical(result_data['source_epoch'])==canonical(epoch),\n             'complete evidence and scientific Source epoch preimage')\n        region_check=(verify_raw_region(result_data,work_ns)",'full epoch result identity')
change("            final_region_verification=region_check,result_reading=result_reading,", "            final_region_verification=region_check,result_reading=result_reading,\n            evidence_forest=forest_pin,evidence_statistics=receipt['evidence_statistics'],\n            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,",'header full independent inverse/caps/stats')
change("        write_new(actual/'worker-receipt.json',header)", "        finalize_output_ledger(actual,header,result_pin,forest_pin,evidence_tick)\n        evidence_tick();source_guard();full_artifacts();evidence_tick()\n        write_new(actual/'worker-receipt.json',header)\n        need((actual/'worker-receipt.json').stat().st_size==header['owned_output_ledger']['worker_receipt_bytes'],\n             'exact serialized worker receipt physical length')\n        evidence_tick()",'aggregate physical ledger and all output serialization in180')
old="""        # Failure diagnostics cannot create an accepted partial proof result.
        write_new(actual/'worker-failure.json',dict(schema='ROOT-semantic-worker-failure-v1',
            error_type=type(error).__name__,message=str(error),cleanup_errors=cleanup_errors,
            native_transport=transport,result_already_published=result_pin,
            stage_intervals=stages,scientific_acceptance=False,logical_proof_accepted=False))
        raise"""
new="""        # No late rewrite, partial Model permission or accepted forest fallback.
        # Metadata failures cannot replace the original exception object.
        try:
            prefixes=failure_output_prefixes(actual,overall_tick)
            failure=dict(schema='ROOT-owned-evidence-worker-failure-v1',
                error_type=type(error).__name__,message=str(error)[:4096],cleanup_errors=cleanup_errors,
                native_transport=transport,result_already_published=result_pin,
                owned_evidence_statistics=getattr(error,'owned_evidence_statistics',None),
                diagnostic_output_prefixes=prefixes,stage_intervals=stages,
                complete_output_accepted=False,scientific_acceptance=False,
                logical_proof_accepted=False,resource_accepted=False,retry_authorized=False)
            need(len(canonical(failure))+1<=1048576,'bounded ordinary failure metadata')
            overall_tick();write_new(actual/'worker-failure.json',failure)
        except BaseException as metadata_error:
            if hasattr(error,'add_note'):
                error.add_note('bounded failure metadata unavailable: '+type(metadata_error).__name__)
        raise"""
change(old,new,'bounded failure-only metadata preserves original exception')

out=D/'owned_evidence_cold_v2.py'
assert not out.exists(),'do not silently overwrite a frozen Source'
ast.parse(s)
compile(s,str(out),'exec')  # Inert code object discarded; no evaluation.
out.write_text(s)
(D/'cold-author-transform-v2.json').write_text(json.dumps(dict(schema='metadata-only-cold-transform-v2',
    parent=pin(P),source=pin(out),changes=changes,target_functions_called=0),indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(out)))
