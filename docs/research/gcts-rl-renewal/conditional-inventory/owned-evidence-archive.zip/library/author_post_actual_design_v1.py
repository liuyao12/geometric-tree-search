"""Saved ordinary metadata/Source analysis only; no target functions imported."""
from pathlib import Path
from decimal import Decimal
import ast
import hashlib
import json

L=Path(__file__).parent
R=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
def pin(path):
    p=Path(path);h=hashlib.sha256();size=0
    with p.open('rb')as f:
        while True:
            chunk=f.read(1048576)
            if not chunk:break
            h.update(chunk);size+=len(chunk)
    return dict(path=str(p),sha256=h.hexdigest(),bytes=size)
def load(path):return json.loads(Path(path).read_text())
def write(name,value):
    p=L/name;assert not p.exists()
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    return pin(p)
def delta(a,b):return float(Decimal(str(b))-Decimal(str(a)))
def ns_delta(a,b):return(b-a)/1000000000

audit_path=R/'ROOT-saved-actual-audit-v1.json';audit=load(audit_path)
assert pin(audit_path)==dict(path=str(audit_path),sha256='779c265fd0d2b33e9dbfce999e5865a8d29e4021fd9ed092b7ce6870e416f5c5',bytes=51477)
sources=dict(cold=L/'owned_evidence_cold_v3.py',
    driver=R/'owned_evidence_receiver_driver_v4.py',adapter=R/'owned_evidence_adapter_v3.py',
    arena=Path('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py'),
    inverse=Path('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py'))
citations=[]
for role,path in sources.items():
    text=path.read_text();tree=ast.parse(text)
    wanted={'cold':{'verify_saved_evidence','main'},'driver':{'_owned_atomic_output','_atomic_owned_stream','run_receiver_owned'},
        'adapter':{'_canonical','_capture','assemble'},'arena':{'_cache','_pull','_full_validate','seal','to_wire'},
        'inverse':{'tick','prepare_forest','_advance'}}[role]
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.ClassDef))and node.name in wanted:
            citations.append(dict(role=role,source=pin(path),symbol=node.name,line=node.lineno,end_line=node.end_lineno))

arms=[];allpins=[pin(audit_path)];checks=[]
for index,mode in enumerate(('fixed','symbolic')):
    A=R/('actual-'+mode+'-v1')
    result_path=A/'result.json';result=load(result_path)
    marker=load(A/'CONSUMED.json');runner=load(A/'runner-receipt.json')
    rootarm=next(x for x in audit['arms']if x['mode']==mode)
    initial=marker['began_ns'];work=marker['work_deadline_ns'];overall=marker['overall_deadline_ns']
    assert work-initial==180000000000 and overall-initial==210000000000
    stage_rows=[]
    for row in result['stage_intervals']:
        seconds=delta(row['started_monotonic'],row['returned_monotonic'])
        assert seconds>=0
        stage_rows.append(dict(stage=row['stage'],started_monotonic=row['started_monotonic'],
            returned_monotonic=row['returned_monotonic'],elapsed_seconds=seconds))
    savedpins={name:pin(A/name)for name in ('result.json','evidence-forest.json','CONSUMED.json','runner-receipt.json','stderr.bin')}
    allpins.extend(savedpins.values())
    endpoints=dict(Source_entry_began_ns=initial,work_deadline_ns=work,overall_deadline_ns=overall,
        scientific_stopped_monotonic=result['scientific_stopped_monotonic'],
        oracle_closed_monotonic=result['oracle_closed_monotonic'],
        worker_terminal_observed_ns=runner['worker_terminal_observed_ns'])
    facts=dict(mode=mode,original_receiver_id=result['receiver_id'],saved_result_status=result['status'],
        saved_result_native_proof_accepted=result['native_proof_accepted'],
        saved_result_work_window_complete=result['work_window_complete'],
        Root_full_invocation_admitted=rootarm['ROOT_mathematical_proof_admitted'],
        Root_resource_admitted=rootarm['ROOT_resource_accepted'],
        outer_elapsed_seconds=rootarm['elapsed_seconds'],worker_exit_code=rootarm['worker_exit_code'],
        aggregate_peak_bytes=rootarm['aggregate_peak_bytes'],group_absent=rootarm['group_absent'],
        logs_complete=rootarm['logs_complete'],raw=savedpins,endpoints=endpoints,stages=stage_rows,
        scientific_stage_stop_from_Source_entry_seconds=delta(Decimal(initial)/1000000000,result['scientific_stopped_monotonic']),
        worker_exit_from_Source_entry_seconds=ns_delta(initial,runner['worker_terminal_observed_ns']))
    if mode=='fixed':
        failure=load(A/'worker-failure.json');allpins.append(pin(A/'worker-failure.json'))
        assert failure['error_type']=='ColdError'and failure['message']=='full saved evidence inverse within original work'
        stderr=(A/'stderr.bin').read_text()
        assert 'part=next(source)'in stderr and "state.tick(self.phase+'_walk_action')"in stderr
        assert "full saved evidence inverse within original work"in stderr
        assert not(A/'worker-receipt.json').exists()
        assert rootarm['ROOT_mathematical_proof_admitted']is False and rootarm['ROOT_resource_accepted']is False
        assert failure['complete_output_accepted']is False
        facts.update(failure=pin(A/'worker-failure.json'),failure_type=failure['error_type'],
            failure_message=failure['message'],direct_trace='verify_saved_evidence next(source) -> inverse _DocumentStream._advance -> _Pieces.take -> _State.tick -> cold evidence_tick180 deadline',
            exact_inverse_elapsed_seconds=None,driver_serialization_elapsed_seconds=None,
            retained_inverse_statistics=None,absence_scope='No worker-success header, inverse completion/statistics packet or driver output receipt was retained. Raw ordinary result/forest remain diagnostic only.',
            memory_scope='Root admitted aggregate peak is null. This note does not backfill a failed resource gate or claim a memory pass.')
    else:
        header=load(A/'worker-receipt.json');allpins.append(pin(A/'worker-receipt.json'))
        ev=header['evidence_verification'];reading=header['result_reading'];receipt=header['driver_output_receipt']
        f=receipt['evidence_forest'];o=receipt['output'];stats=ev['statistics'];es=header['evidence_statistics']
        assert ev['status']=='COMPLETE'and ev['representation_only']is True and ev['mathematical_authority']is False
        assert rootarm['ROOT_mathematical_proof_admitted']is True and rootarm['ROOT_resource_accepted']is True
        assert stats['attempted_operations']==stats['callback_dispatches']==21304533
        assert stats['documents']['receiver:complete-legacy-result']['completed']is True
        assert stats['aggregate_document_bytes']==savedpins['result.json']['bytes']
        assert reading['roundtrip']['literal_bytes_equal']is True
        assert header['final_region_verification']['status']=='VERIFIED_WHOLE_FINITE_POINT_REGION'
        facts.update(worker_header=pin(A/'worker-receipt.json'),
            endpoints=dict(endpoints,driver_returned_ns=header['driver_returned_ns'],
                inverse_started_ns=ev['started_ns'],inverse_completed_ns=ev['completed_ns'],
                reading_started_ns=reading['started_ns'],ordinary_parser_decoded_ns=reading['decoded_ns'],
                ordinary_roundtrip_completed_ns=reading['completed_ns']),
            timing_envelopes=dict(
                scientific_stop_to_driver_return_seconds=delta(result['scientific_stopped_monotonic'],Decimal(header['driver_returned_ns'])/1000000000),
                oracle_closed_to_forest_serialization_start_seconds=delta(result['oracle_closed_monotonic'],f['serialization_started_monotonic']),
                forest_serialization_to_publication_preflight_seconds=f['serialization_to_preflight_seconds'],
                complete_ordinary_output_serialization_to_publication_preflight_seconds=o['serialization_to_preflight_seconds'],
                independent_inverse_exact_seconds=ns_delta(ev['started_ns'],ev['completed_ns']),
                combined_reader_reported_decode_seconds=reading['decode_seconds'],
                reading_start_to_inverse_start_seconds=ns_delta(reading['started_ns'],ev['started_ns']),
                inverse_completion_to_ordinary_parser_decoded_seconds=ns_delta(ev['completed_ns'],reading['decoded_ns']),
                ordinary_canonical_roundtrip_envelope_seconds=ns_delta(reading['decoded_ns'],reading['completed_ns']),
                total_reader_envelope_seconds=ns_delta(reading['started_ns'],reading['completed_ns']),
                remaining_work_after_ordinary_roundtrip_seconds=ns_delta(reading['completed_ns'],work)),
            inverse_counters=dict(attempted_operations=stats['attempted_operations'],callback_dispatches=stats['callback_dispatches'],
                validated_nodes=stats['validated_nodes'],validated_edges=stats['validated_edges'],
                logical_value_occurrences=stats['aggregate_document_value_occurrences'],
                emitted_document_chunks=stats['documents']['receiver:complete-legacy-result']['chunks']),
            producer_counters=dict(arena_work=es['arena']['counters']['work'],adapter_operations=es['operations'],
                arena_roots=es['arena']['roots'],arena_nodes=es['arena']['nodes'],
                legacy_JSON_parts=es['counters']['legacy_JSON_parts'],legacy_JSON_copy_chunks=es['counters']['legacy_JSON_copy_chunks'],
                final_and_prior_stream_tokens=es['arena']['counters']['emitted_tokens'],
                final_and_prior_copy_chunks=es['arena']['counters']['copy_chunks']),
            interpretation='The81.065168s oracle-closed→forest-serialization-start interval covers driver bookkeeping plus final assemble/seal/wire and their guards. It is not a separately measured capture or serialization subphase.')
    arms.append(facts)
    checks.append(dict(name=mode+'_saved_metadata_scope',passed=True,
        details='Saved timing endpoints/status/pins only; no mathematical/representation replay.'))

checks.extend([
 dict(name='exact_original_work_and_closure_caps',passed=True,details='Both markers retain absolute180/210 seconds.'),
 dict(name='fixed_stream_deadline_direct_trace',passed=True,details='Ordinary stderr gives exact stream callback failure chain.'),
 dict(name='symbolic_both_inverse_and_old_roundtrip_complete',passed=True,details='Saved header explicit completion plus old literal equality and raw point gate.'),
 dict(name='decode_field_overlap_classified',passed=True,details='Cold reading_started precedes fresh forest inverse; reported decode_seconds is not isolated builtin/interned decode.'),
 dict(name='no_missing_fixed_timing_invented',passed=True,details='Unavailable inverse start/driver output receipt kept null.'),
 dict(name='no_ordinary_control_or_causal_claim',passed=True,details='These are two mechanism arms with common owned representation, not a storage ablation.'),
 dict(name='no_target_or_component_replay',passed=True,details='Only stdlib saved JSON, Source AST/lines and raw hashes used.')])

note=dict(schema='owned-evidence-post-actual-next-design-v1',author_identity='/root/conventional_library',
    status='SAVED_METADATA_ANALYSIS_AND_PROPOSED_UNIMPLEMENTED_UNMEASURED_DESIGN',
    source_only=True,saved_data_only=True,scientific_calls=0,scientific_replays=0,
    scientific_acceptance=False,future_execution_authorized=False,
    ancestry='Author of current cold coupling/diagnostics, owned registry, qualified arena and earlier Model/point/driver work. This is descriptive data/Source design, not an independent certificate of those Sources or a new admission.',
    Root_audit=pin(audit_path),sources={k:pin(v)for k,v in sources.items()},source_citations=citations,
    observed_arms=arms,
    findings=[
        'Fixed remains a failed complete invocation: emitted ordinary result and forest are diagnostic, not admitted proof or resource success. Deadline occurred during independent inverse document streaming, before old reader/point/header checks could complete.',
        'Symbolic is a Root-admitted full Native/point/owned-representation invocation at176.0285565s and conservative worker+Native peak903380992B. Representation checks confer no independent mathematical authority.',
        'Fixed scientific stages stopped48.103893584s after entry; symbolic52.600799333s. Search time alone does not explain end-to-end outcomes; stages include different ordinary output payloads and preservation costs.',
        'Symbolic oracle-close→forest serialization-start81.065168s is an observed composite lifetime envelope. Per-assembly/capture/seal/wire elapsed splits were not recorded; counters establish operation totals, not allocation or CPU causation.',
        'Symbolic full ordinary output serialization-to-preflight21.996318500s, independent inverse11.239489083s and ordinary canonical roundtrip4.755994041s are retained separate costs. No check should be dropped to fit.',
        'The field result_reading.decode_seconds12.725315542 includes the inverse and forest reread. Inverse completion→ordinary parser decoded1.352689417s is only an upper envelope for old decode because cleanup/guards lie inside it.',
        'There is no ordinary-storage arm, repetition, balanced order or phase profiler here. Do not infer memory savings, a GCTS-vs-symbolic advantage, the cause of the fixed timeout, or a guaranteed optimization fit.'
    ],
    one_recommended_next_design=dict(
        status='PROPOSED_NOT_IMPLEMENTED_UNMEASURED',
        owner='Root independently authors inverse successor; Control distinct review. Do not edit qualified encoder/arena/adapter or current scientific modules.',
        change='Batch only delegated inverse clock-callback dispatch at a declared bounded cadence, while retaining every current validation/stream operation, exact per-kind attempted-operation count and unconditional30m work-cap test. New explicit execution_profile; same forest wire/API.',
        rationale='Saved symbolic inverse has21,304,533 operations and21,304,533 callback dispatches. Raw _State.tick calls evidence_tick on every operation; that callback invokes total and work clocks. This is a concrete optimization surface, not measured overhead attribution.',
        finite_policy=[
            'Call the supplied check immediately on first operation, after at most1024 subsequent tick operations, at public preparation/stream entry as appropriate, before every emitted bounded chunk, and before preparation/stream successful completion and trailing completion pull.',
            'All internal cap tests, typed equality, metadata scans, prior references, reachability, canonical bytes, ordered multiplicities and expanded occurrence ledgers remain unconditional at their old logical operations.',
            'No guard/reset, cache/input reuse, operation-unit redefinition or private cap raise. Callback_dispatches becomes a distinct observed counter; attempted_operations and per-kind validation semantics remain unchanged.',
            'Preserve private quota ownership, reentrancy gates, custom non-generator stream, exact delegated BaseException identity at the invoked checkpoint and explicit completed requirement. Withdraw any claim to unchanged callback ordinal/timing coverage.',
            'Keep cold source/raw checks before/after inverse, full old parser+canonical inverse, exact point checks, Native ledger/final whole proof, atomic files and strict positive/known-exit180 plus terminal210 gates.',
            'Cadence bounds logical operations, not elapsed latency; callback scheduling does not prove hard mid-operation preemption. Final gates must reject any late completion.'
        ],
        qualification_obligations=[
            'Distinct raw/AST review establishes that only callback scheduling/bookkeeping and profile/version differ; no omitted validation or altered count unit.',
            'Future separately granted finite fixtures must cover callback identity including StopIteration, late completion, reentrancy and own quota; prior ordinal-based coverage cannot be silently inherited.',
            'A future common-profile fixed/symbolic original001 full-pipeline pair must retain every old mathematical datum/check and all global caps. Do not count the failed fixed output as a successful control or resume it as cache.',
            'If causal time benefit is claimed, prospectively compare both old and new profiles freshly under a declared order; historical unmatched observations alone are not an ablation.',
            'Any measured fit/speed effect is unknown. The much larger final assembly/seal/wire envelope may still dominate, and no success is promised.'
        ],
        unchanged_caps=dict(work_seconds=180,total_seconds=210,conservative_worker_plus_Native_bytes=1073741824,
            physical_output_bytes=134217728,logical_output_bytes=134217728,log_bytes_each=4194304,
            arena_attempted_work=400000000,adapter_operations=400000000,inverse_attempted_work=30000000),
        not_proposed=['No removed full logical output or old verification','No new theorem/family/rule/route','No changes to complete inventory/Model/marks/candidates/fallback/rollback','No new actual or cap raise now']),
    limitations=['No component was imported or called, including our own encoder/cold/adapter/fixtures.',
        'Saved ordinary result JSON was parsed only for retained stage/status/timing metadata; no Native decoding or mathematical proof replay.',
        'This memo does not duplicate the separate full saved-data/resource audit or establish mathematical soundness.',
        'The next Source proposal is an explicit execution-profile change even though numeric caps and internal validation accounting stay fixed.',
        'Current failed and successful actual directories remain immutable; no publication/report change is made.'])
note_pin=write('post-actual-next-design-v1.json',note)
audit_pin=write('post-actual-design-audit-v1.json',dict(schema='owned-evidence-post-actual-author-analysis-audit-v1',
    note=note_pin,checks=checks,check_count=len(checks),mismatches=0,raw_inputs=allpins,
    metadata_only=True,scientific_calls=0,component_calls=0,fixtures_executed=0,
    existing_artifacts_mutated=False,independent_Source_certification=False))
handoff=write('post-actual-design-handoff-v1.json',dict(schema='owned-evidence-post-actual-design-handoff-v1',
    author_identity='/root/conventional_library',note=note_pin,audit=audit_pin,Root_audit=pin(audit_path),
    status='PROPOSED_NOT_IMPLEMENTED_UNMEASURED',scientific_calls=0,scientific_acceptance=False,
    future_execution_authorized=False,old_actuals_preserved=True,tools_stop_after_handoff=True))
print(json.dumps(dict(note=note_pin,audit=audit_pin,handoff=handoff,checks=len(checks))))
