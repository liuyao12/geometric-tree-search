"""Registry metadata/AST/inert-patch audit only; never imports target Source."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

D=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019')
P=Path('/private/tmp/gcts-schema-admission-source-20261019/semantic_inventory_oracle_v4.py')
S=D/'semantic_inventory_oracle_v5.py'
CERT=Path('/private/tmp/gcts-mp-schema-source-20261019/mp_schema_certificate_v1.py')
DESIGN=Path('/private/tmp/gcts-owned-evidence-integration-peer-20261019/design-review-v1.json')
FINDINGS=Path('/private/tmp/gcts-owned-evidence-integration-peer-20261019/findings-HTML-ready-v1.json')
def pin(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,v):
    p=D/name;assert not p.exists(),str(p);p.write_text(json.dumps(v,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n');return pin(p)
def dump(n):return ast.dump(n,include_attributes=False)
def raw(s,n):return ''.join(s.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
old=P.read_text();new=S.read_text();a=ast.parse(old);b=ast.parse(new);checks=[]
def need(name,ok,lines=None):
    checks.append(dict(name=name,passed=bool(ok),lines=lines));assert ok,name
need('parent exact a505',(pin(P)['sha256'],pin(P)['bytes'])==('a50579cb6ba326d32de3f203214963ec4bcf184613413a2abae2a2f6bb889eca',37657))
need('whole parent raw prefix exact',new.startswith(old))
need('whole parent AST prefix exact',[dump(x)for x in b.body[:len(a.body)]]==[dump(x)for x in a.body])
need('appended only no old module edits',new[:len(old)]==old)
af={n.name:n for n in a.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};bf={n.name:n for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
retained=[]
for name,n in af.items():
    need('retained whole raw/AST '+name,raw(old,n)==raw(new,bf[name])and dump(n)==dump(bf[name]))
    retained.append(dict(name=name,parent_lines=[n.lineno,n.end_lineno],current_lines=[bf[name].lineno,bf[name].end_lineno]))
added={'_owned_store_anchors','_owned_store_current','_owned_packet_label','_schema_packet_owned','check_inventory_owned'}
need('exact five new functions',set(bf)-set(af)==added)
need('no new imports',[dump(n)for n in a.body if isinstance(n,(ast.Import,ast.ImportFrom))]==[dump(n)for n in b.body if isinstance(n,(ast.Import,ast.ImportFrom))])
for name in added:
    need(name+' no catch/generator',not any(isinstance(n,(ast.ExceptHandler,ast.Yield,ast.YieldFrom))for n in ast.walk(bf[name])))
owned=bf['check_inventory_owned'];body=raw(new,owned);parent=af['_check_inventory_schema_then_native'];pb=raw(old,parent)
need('mandatory separate store keyword',owned.args.kwonlyargs[-1].arg=='evidence_store'and owned.args.kw_defaults[-1]is None)
need('explicit only schema_then_native owned lane',"if type(mode) is not str or mode!='schema_then_native':" in body)
need('old eight-field context unchanged',"context=schema_context" in body and "_schema_context_anchors(context)" in body)
need('new method/version anchors not an authority bool',all(x in new for x in ["names=('capture','assemble','inventory_bundle','unwrap_inventory')","getattr(current,'__self__',None) is not", "getattr(current,'__func__',current) is not"]))
need('labels full literal location not digest',"return 'registry_owned:'+_strict_bytes(location).decode('utf8')" in new)
old_proto=raw(old,af['_schema_packet']).split('    authority =')[0]
# Compare the complete validation statement sequence, excluding docstring and
# final return. No target function is invoked.
need('owned packet exact parent validation AST',[dump(n)for n in bf['_schema_packet_owned'].body[1:-4]]==[dump(n)for n in af['_schema_packet'].body[1:-1]])
need('capture before retention copy',"reference=store_anchors['capture'](packet,label=_owned_packet_label(location))" in raw(new,bf['_schema_packet_owned']) and 'deepcopy' not in raw(new,bf['_schema_packet_owned']))
need('all3 completed packet kinds capture',body.count('_schema_packet_owned(')==3 and all(x in body for x in ["stage='family_certification'","stage='family_revalidation'","stage='ground_correspondence'"]))
need('full unique semantic labels include ordinal/identities',body.count('packet_ordinal=len(packet_locations)')==3 and "original_library_index=original_family_ids.index(fid)" in body and "ordinal=ordinal,definition=row['name'],family_id=fid" in body)
need('census stores references at old fields',"certification=packet_ref,revalidation=None" in body and "row['revalidation']=again_ref" in body and "observed['correspondence']=packet_ref" in body)
need('ground transient dropped only after capture and status',body.index('packet_status=packet[\'status\'];del packet')>body.index("packet,packet_ref=_schema_packet_owned(packet,'check_ground_instance'"))
need('no private snapshot captured',"store_anchors['capture']" not in body and raw(new,bf['_schema_packet_owned']).count("store_anchors['capture']")==1)
snapshot_start='    original_inventory=_strict_bytes(inventory);original_spec=_strict_bytes(spec)'
snapshot_end="    library=literal_context['library'];by_family={};original_family_ids=[]"
need('complete old private snapshot region raw exact',body[body.index(snapshot_start):body.index(snapshot_end)]==pb[pb.index(snapshot_start):pb.index(snapshot_end)])
def nested(fn,name):return next(n for n in fn.body if isinstance(n,ast.FunctionDef)and n.name==name)
for name in ['blocked','cert_kwargs']:
    need('nested '+name+' raw/AST exact',raw(old,nested(parent,name))==raw(new,nested(owned,name))and dump(nested(parent,name))==dump(nested(owned,name)))
custody=raw(new,nested(owned,'custody')).replace('        _owned_store_current(evidence_store,store_anchors)\n','',1)
need('all old custody comparisons raw exact plus only Store check',custody==raw(old,nested(parent,'custody')))
def sci_calls(fn):
    out=[]
    for n in ast.walk(fn):
        if not isinstance(n,ast.Call):continue
        f=n.func
        if isinstance(f,ast.Subscript)and isinstance(f.value,ast.Name)and f.value.id=='anchors'and isinstance(f.slice,ast.Constant)and f.slice.value in ('certify','revalidate','ground'):out.append(dump(n))
        elif isinstance(f,ast.Attribute)and isinstance(f.value,ast.Name)and f.value.id=='oracle'and f.attr=='request':out.append(dump(n))
    return out
need('all7351andNative scientific call AST exact',sci_calls(owned)==sci_calls(parent))
fallback_start='            if fallback:\n'
fallback_end='    custody()\n    covered='
need('entire old Native fallback raw exact',body[body.index(fallback_start):body.index(fallback_end)]==pb[pb.index(fallback_start):pb.index(fallback_end)])
coverage_start='    custody()\n    covered='
coverage_end="    # Fix the one legacy elapsed scalar"
old_coverage_end='    return dict(snapshot,status='
need('coverage/dispositions/full logical certification raw exact',body[body.index(coverage_start):body.index(coverage_end)]==pb[pb.index(coverage_start):pb.index(old_coverage_end)])
need('normal partial status never Model permission',"Model_permission=complete,native_accepted=False,fresh_Native_target_proof_accepted=False" in body and "status='schema_admitted' if complete else stop['status']" in body)
need('same final legacy schema assembled',"logical=dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],\n        certification=certification,seconds=seconds)" in body)
need('one final logical root then bundle only',body.count("store_anchors['assemble'](")==1 and body.count("store_anchors['inventory_bundle'](")==1 and isinstance(owned.body[-1],ast.Return)and isinstance(owned.body[-1].value,ast.Name)and owned.body[-1].value.id=='bundle')
need('postassemble and postbundle custody',"label=_owned_packet_label(dict(stage='logical_registry_return')))\n    custody()" in body and "bundle=store_anchors['inventory_bundle'](operational,logical_ref)\n    custody()\n    return bundle" in body)
need('operational preserves original inventory and all required fields',"operational=dict(snapshot,status=status,query=None,queries=[r['query'] for r in native_receipts],\n        certification={key:certification[key] for key in _OWNED_ADMISSION_FIELDS},seconds=seconds)" in body)
fieldnode=next(n for n in b.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='_OWNED_ADMISSION_FIELDS')
fields=ast.literal_eval(fieldnode.value)
need('exact8 small admission fields',fields==('schema','version','mode','complete','Model_permission','native_accepted','fresh_Native_target_proof_accepted','final_whole_Native_required'))
need('same one elapsed scalar in both logical and operational',body.count('seconds=time.perf_counter()-began')==1 and body.count('seconds=seconds)')==2)
need('historical default still exact ordinary delegate',raw(old,af['check_inventory'])==raw(new,bf['check_inventory']))
need('all old numerical caps unchanged',new[:len(old)]==old and '5*10**9' in body and 'MAX_REGISTRATION_MICRO_STEPS' in body)
need('no case/route constants appended',not any(type(n.value)is str and any(x in n.value.lower()for x in ['fol-suite','case001','case002','right-two','rightone'])for fn in added for n in ast.walk(bf[fn])if isinstance(n,ast.Constant)))
compile(new,str(S),'exec');need('unused compile only',True)
forward=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='semantic_inventory_oracle.py',tofile='semantic_inventory_oracle.py'))
inverse=''.join(difflib.unified_diff(new.splitlines(True),old.splitlines(True),fromfile='semantic_inventory_oracle.py',tofile='semantic_inventory_oracle.py'))
(D/'source-forward.patch').write_text(forward);(D/'source-inverse.patch').write_text(inverse)
scratch=D/'inert-patch';scratch.mkdir();target=scratch/'semantic_inventory_oracle.py';target.write_text(old)
for direction,patch,want in [('forward',D/'source-forward.patch',new),('inverse',D/'source-inverse.patch',old)]:
    r=subprocess.run(['patch','--batch','-s','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
    need('actual inert '+direction,r.returncode==0 and target.read_text()==want and dump(ast.parse(target.read_text()))==dump(ast.parse(want)))
need('frozen parent unchanged after rehearsal',pin(P)['sha256']=='a50579cb6ba326d32de3f203214963ec4bcf184613413a2abae2a2f6bb889eca')
common=dict(author_identity='/root/conventional_library',source_only=True,status='FROZEN_SOURCE_ONLY_UNTESTED_NOT_ACTIVATED',scientific_calls=0,component_calls=0,fixtures_executed=0,scientific_acceptance=False,actual_execution_authorized=False,future_execution_authorized=False)
api=save('API-v1.json',dict(**common,schema='owned-evidence-registry-API-v1',source=pin(S),parent=pin(P),
 new_entry="check_inventory_owned(spec,inventory,oracle,limit=5*10**9,*,mode='schema_then_native',schema_context=None,evidence_store)->InventoryBundle",
 old_entry='check_inventory and ALL historical modes, including original ordinary schema_then_native, unchanged complete parent prefix; no implicit owned fallback.',
 implementation_version='schema-owned-evidence-registry-v1',
 schema_context=dict(exact8_fields=['certificate_module','library','source_epoch','semantic_epoch','source_guard','check','formula_validator','theory_admission_record_id'],unchanged=True,evidence_store_is_separate=True),
 Store=dict(VERSION='owned-evidence-adapter-v1',required_methods=['capture','assemble','inventory_bundle','unwrap_inventory'],interface_only=True,
  capture='capture(complete ordinary packet,*,label)->same-Store whole-root Reference, after exact parent protocol and before retention copy',
  assemble='assemble(mixed builtin tree and same-Store whole-root References,*,label)->Reference; exact old JSON tuple-to-array normalization belongs solely to adapter evidence boundary',
  inventory_bundle='inventory_bundle(operational,logical_ref)->immutable same-Store InventoryBundle',
  unwrap='Root driver calls authenticated Store.unwrap_inventory(bundle)->(ordinary operational,whole logical_ref); exact bundle class/owner and adapter Source must be independently joined.'),
 bundle=dict(VERSION='owned-inventory-bundle-v1',operational='Full original inventory fields, including all definitions/interfaces/native_blocks, plus unchanged status/query/queries/seconds and only8 named admission envelope fields.',logical_ref='Exact complete parent legacy logical registered inventory, every full packet/census/Native fallback/UNKNOWN prefix retained at original fields. A reference is never a dict/list or overloaded equality.',operational_certification_fields=list(fields)),
 labels='Once per Store owned registration. registry_owned: followed by full canonical JSON location; monotonically captured packet ordinal, stage and complete original IDs/ordinals. Final logical_registry_return root label. Adapter-owned: namespace remains reserved. No digest labels or selected theorem/route.',
 cost='seconds is one shared elapsed scalar fixed before final immutable assembly. All final assembly/bundle/current custody costs remain charged in Root outer stage/cold timing, not included in this internal seconds field. Arena attempted limits/callbacks/current Source/Native budgets remain Root-authenticated and never reset here.',
 error='New helpers/lane catch no exceptions. Capture/assembly/Source/callback/quota/adapter failures propagate unchanged, no ordinary-success fallback and no returned bundle. Prior Store roots may exist diagnostically but cannot be accepted/sealed through an invented layout.',
 authority='Only exact complete original registry/driver joins permit Model; storage roots and Store duck API never grant mathematical permission. Operational complete=False/Model_permission=False on normal partial UNKNOWN/rejection. Native acceptance remainsFalse; fresh final whole Native mandatory.'))
argument=save('Source-argument-v1.json',dict(**common,schema='owned-evidence-registry-Source-argument-v1',source=pin(S),parent=pin(P),design=pin(DESIGN),design_findings=pin(FINDINGS),
 claims=[
  'Full a505 Source is a raw prefix; old functions/signatures/imports/default delegates/limits remain exact. The new entry is explicit and separately versioned.',
  'Owned packet protocol checks are the exact AST statement sequence of old _schema_packet before its retention deepcopy. Capture then owns the complete same logical packet. No ordinary retention copy/census insertion occurs before capture.',
  'Replacing only packet-valued census fields by same-Store references and assembling them at the final old locations reproduces the exact legacy registered logical shape. Every normal returned packet, including UNKNOWN/rejected, appears in full; all original families/grounds/interfaces/dependencies and pending fields remain. Equal packets may share a node but keep every logical occurrence/location.',
  'The original ordinary spec/context/inventory/Native-prefix snapshots and all byte/callback/module comparisons are retained. Certifier argument/dependency/certificate copying, every7351call and every Native fallback/cap/disposition remain exact. A new Store binding check is additional, not a mathematical proof.',
  'Family operational certificate copies remain as required by unchanged revalidation/ground calls; family frames release transient packets on return. Ground packets are explicitly dropped after status extraction/retention. No private custody root is captured or exposed, and no change to certifier per-call transients is asserted.',
  'Operational inventory is ordinary, with the entire original mathematical payload and small8-field gate envelope; full original certification is only in logical_ref. The independently reviewed driver must authenticate Bundle/Store owner/class/Source and perform ALL full logical joins before Model. No handles enter Model/search.',
  'No exception handler, retry, fallback serialization, owner reset or partial bundle exists in new code. A throw before final return is a failed invocation with any committed prefix diagnostic only, not a usable bundle/forest. Final assembly/bundle are followed by original custody checks plus Store binding checks.',
  'Labels identify complete packet locations using full canonical literals. Every packet reference lies under a family/ground census in the final registry root; final driver must verify exact legacy paths as well as coverage. A final root abandoned by reader/finalization or a packet captured before an interrupted enclosing stage cannot be silently dropped/retried/promoted.',
  'Only adapter evidence normalization maps legacy tuples to JSON arrays while verifying the complete canonical projection. Arena domain, Model marks/keys, oldparser and mathematical output are unchanged; bounds/copies/normalization/inverse remain charged.'],
 conditions=['Qualified arena and independently reviewed adapter semantics/full epochs/exclusive ordinary ownership are required; own author argument is not independent certification.','Root must freeze complete legacy final layout/path ownership, ordinary output+forest total physical count, full expanded count, error-only failure retention and all timing/Native/custody gates before any actual.','No prediction of integrated fit, lower RAM, speed, proof-search gain, new theorem or GCTS/RL advantage.']))
audit=save('author-static-audit-v1.json',dict(**common,schema='owned-evidence-registry-author-static-audit-v1',author_static_audit_passed=True,independent_review=False,source=pin(S),parent=pin(P),checks=checks,check_count=len(checks),mismatches=0,
 retained_regions=retained,new_regions={k:[bf[k].lineno,bf[k].end_lineno]for k in sorted(added)},inert_patch_directions=2,unused_compiles=1,forward=pin(D/'source-forward.patch'),inverse=pin(D/'source-inverse.patch'),
 master_reference=dict(path='/Users/liuyao/Documents/Codex/projects/geometric-tree-search/docs/basic-tiling-algorithm.md',sha256='c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9',bytes=21657,scope='Full normative preimage previously read. Current working copy is dataless; attempted reread yielded no bytes and narrow publisher Git object retrieval was unavailable offline. No scheduler/tiling logic changed.'),
 ownership='Author wrote parent registry/certifier/arena/Library33 and earlier Model/point/bridge code; this is own static audit only. Root adapter/driver and Control independent review remain separate.'))
delta=save('Source-delta-v1.json',dict(**common,schema='owned-evidence-registry-Source-delta-v1',source=pin(S),parent=pin(P),whole_parent_raw_AST_prefix_exact=True,
 additions=sorted(added),retained_regions=retained,scientific_call_AST_exact=True,private_snapshot_region_exact=True,private_custody_exact_plus_store_check=True,Native_fallback_region_exact=True,complete_coverage_and_logical_certification_region_exact=True,
 forward=pin(D/'source-forward.patch'),inverse=pin(D/'source-inverse.patch')))
contract=save('Source-contract-v1.json',dict(**common,schema='owned-evidence-registry-Source-contract-v1',source=pin(S),sources={'owned_registry':pin(S)},parent_source=pin(P),API=api,Source_argument=argument,Source_delta=delta,author_static_audit=audit,
 parent_API=pin(P.parent/'API-v1.json'),certificate=pin(CERT),design_review=pin(DESIGN),design_findings=pin(FINDINGS),
 adapter_dependency=dict(status='ABI_AGREED_ROOT_SOURCE_PIN_PENDING_AT_AUTHOR_FREEZE',VERSION='owned-evidence-adapter-v1',Store_VERSION='owned-evidence-adapter-v1',bundle_VERSION='owned-inventory-bundle-v1',methods=['capture','assemble','inventory_bundle','unwrap_inventory'],condition='Future Root capsule must pin/authenticate full exact adapter module/class/instance owner and callback semantics; registry interface anchors alone supply no authority.'),
 entry='check_inventory_owned only; original check_inventory stays exact historical delegate.',
 trust='Conditional unchanged7351structural calculus plus exact fresh theory/fallback/driver joins. Root must authenticate complete context/certifier/adapter/current Sources. No new axiom, Model rule, Native rule, grammar, candidate, pruning or search authority.',
 retained='All4policy families and ALL original ground definitions/interfaces/native bodies; full legacy certification/census and returned packet prefix in logical_ref, including normal UNKNOWN/REJECTED. Operational envelope contains only already-computed scalar gate fields. No partial Model permission.',
 budgets='No numerical caps changed. Original Native aggregate<=5e9, all current whole-work/closure/memory/physicalANDexpanded limits remain future Root profile conditions; Store conversion/assembly/normalization/inverse and overlaps are charged. No tests or actual authorized.',
 failure='No catches, retries, resets or usable returned bundle after capture/assembly/custody error. Caller retains bounded failure metadata/current Store prefix stats and closes/reaps; no accepted orphan forest or silent ordinary success fallback.',
 review_ABI=dict(schema='owned-evidence-registry-typed-Source-review-v1',scope='explicit-owned-registry-Source',required_fields=['source','sources','source_contract','author_identity','reviewer_identity','source_only','source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings'])))
handoff=save('handoff-v1.json',dict(**common,schema='owned-evidence-registry-handoff-v1',source=pin(S),source_contract=contract,API=api,Source_argument=argument,Source_delta=delta,author_static_audit=audit,parent=pin(P),certificate=pin(CERT),
 implementation_version='schema-owned-evidence-registry-v1',required_adapter_VERSION='owned-evidence-adapter-v1',entry="check_inventory_owned(spec,inventory,oracle,limit=5*10**9,*,mode='schema_then_native',schema_context=None,evidence_store)",
 checks=len(checks),inert_patch_directions=2,unused_compiles=1,old_prefix_exact=True,
 scope='New standalone explicit owned evidence registry entry only. Root adapter/raw pin, driver/cold composition, independent review and prospective/final grants pending; no activation or own implementation certification.'))
print(json.dumps(dict(source=pin(S),handoff=handoff,contract=contract,API=api,checks=len(checks)),sort_keys=True))
