"""Construct Source only. No generated component is imported or evaluated."""
from pathlib import Path
import ast
import hashlib
import json

D=Path(__file__).parent
P=D/'owned_evidence_cold_v2.py'
raw=P.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='394ea01c03996ddf723fa633dab849aa5b0e436e018e2b897cf4e6698f75a418'
s=raw.decode();changes=[]
def change(old,new,label):
    global s
    assert s.count(old)==1,(label,s.count(old))
    s=s.replace(old,new,1);changes.append(dict(label=label,old=old,new=new))
def pin(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))

change("VERSION = 'owned-evidence-intake-cold-v2'","VERSION = 'owned-evidence-intake-cold-v3'",'explicit narrow diagnostic Source successor')
constants='''
ADAPTER_DIAGNOSTICS = (
    'tuple_projection_and_typed_paths',
    'assembly_repeated_roots_and_full_canonical_body',
    'foreign_callback_exception_identity',
    'callback_reentrancy_fails_closed',
    'failed_assembly_prefix_has_no_usable_output')
DIAGNOSTIC_ARENA_LIMITS = dict(ARENA_LIMITS,work=1000000,nodes=4096,edges=16384,roots=64,
    depth=32,scalar_bytes=1048576,wire_bytes=1048576,root_expanded_bytes=1048576,
    documents_expanded_bytes=1048576,materialized_bytes=1048576,
    materialized_occurrences=10000,cache_bytes=4096,cache_entries=256,chunk_bytes=4096)
DIAGNOSTIC_ADAPTER_LIMITS = dict(operations=100000,value_bytes=1048576,depth=32,chunk_bytes=4096)
ADAPTER_DIAGNOSTIC_PROFILE = dict(schema='owned-adapter-finite-diagnostic-profile-v1',
    cases=list(ADAPTER_DIAGNOSTICS),maximum_fresh_Stores=8,
    arena_limits=DIAGNOSTIC_ARENA_LIMITS,adapter_limits=DIAGNOSTIC_ADAPTER_LIMITS,
    scope='Small finite adapter boundary checks before original full001 proof pipeline; same original total work/peak/output caps, not a carrier benchmark or proof authority.')
EVIDENCE_PROFILE['adapter_diagnostics']=ADAPTER_DIAGNOSTIC_PROFILE

'''
change('\n\nclass ColdError(ValueError):',constants+'\nclass ColdError(ValueError):','explicit finite diagnostic budget and names')

helper='''
def run_adapter_diagnostics(adapter, arena, tick, guard, context):
    """Finite declared checks; append only fully completed groups, no authority.

    Only invoked by the separately authorized cold main. Root callback faults
    are latched by exact identity and cannot satisfy an expected refusal.
    """
    rows=[];external_fault=None;stores=0
    def external(callback):
        nonlocal external_fault
        try:callback()
        except BaseException as error:
            external_fault=error;raise
    def checked():external(tick)
    def guarded():external(guard)
    def fresh(check=None):
        nonlocal stores
        checked();guarded();stores+=1
        need(stores<=8,'finite diagnostic Store count')
        return adapter.Store(arena_module=arena,source_epoch=canonical(context).decode('utf8'),
            semantic_epoch=canonical(ADAPTER_DIAGNOSTIC_PROFILE).decode('utf8'),
            arena_limits=dict(DIAGNOSTIC_ARENA_LIMITS),check=checked if check is None else check,
            source_guard=guarded,limits=dict(DIAGNOSTIC_ADAPTER_LIMITS))
    def body(store,reference):
        source=store.canonical(reference);out=bytearray()
        try:
            while True:
                checked()
                try:part=next(source)
                except StopIteration:
                    if source.completed is not True:raise
                    break
                need(type(part)is bytes and len(out)+len(part)<=65536,'bounded diagnostic stream')
                out.extend(part)
            need(source.completed is True,'diagnostic full stream completion')
        finally:source.close()
        return bytes(out)
    def passed(name,details):
        checked();guarded()
        rows.append(dict(schema='owned-adapter-finite-diagnostic-v1',name=name,status='passed',
                         mathematical_authority=False,details=details))
    def expected(action,sentinel):
        try:action()
        except BaseException as error:
            if external_fault is not None:raise external_fault
            if error is not sentinel:raise
            return
        raise ColdError('expected exact diagnostic exception was not raised')

    store=fresh();value={'ports':(0,False,1.0,-0.0),'unicode':'line\\n雪','null':None}
    reference=store.capture(value,label='diagnostic:typed')
    expected_value={'ports':[0,False,1.0,-0.0],'unicode':'line\\n雪','null':None}
    need(reference.equals(value) is True and body(store,reference)==canonical(expected_value),
         'complete tuple-to-array legacy canonical projection')
    need(reference.at('ports').at(0).kind=='int' and reference.at('ports').at(1).kind=='bool' and
         reference.at('ports').at(2).kind=='float' and reference.at('ports').at(3).kind=='float' and
         math.copysign(1.0,reference.at('ports').at(3).scalar())==-1.0 and
         reference.get('absent').kind=='missing' and reference.at('null').kind=='null',
         'bool/int/float/signed zero and missing/null remain distinct')
    value['ports']=(99,);need(body(store,reference)==canonical(expected_value),'captured caller mutation isolation')
    passed(ADAPTER_DIAGNOSTICS[0],dict(tuple_projection=True,strict_types=True,caller_mutation_isolated=True))

    store=fresh();original={'values':[1,2]};reference=store.capture(original,label='diagnostic:shared')
    assembled=store.assemble({'ordered':(reference,reference),'ordinary':(False,None)},label='diagnostic:layout')
    expected_value={'ordered':[original,original],'ordinary':[False,None]}
    need(body(store,assembled)==canonical(expected_value),'ordered repeated same-Store whole-root references')
    sealed=store.seal(assembled);wire=store.wire(sealed)
    need(wire['documents']==['diagnostic:layout'],'sole diagnostic root covers complete catalogue')
    passed(ADAPTER_DIAGNOSTICS[1],dict(repeated_ports=True,full_body=True,sealed_document='diagnostic:layout'))

    identities=[]
    for exception_type in (RuntimeError,ValueError,StopIteration):
        armed=[False];sentinel=exception_type('owned-adapter-diagnostic-exact-callback')
        def injected():
            checked()
            if armed[0]:raise sentinel
        store=fresh(injected);armed[0]=True
        expected(lambda:store.capture([1],label='diagnostic:foreign'),sentinel)
        need(store.statistics()['failed'] is True,'callback capture has no usable Store')
        identities.append(exception_type.__name__)
    armed=[False];sentinel=StopIteration('owned-adapter-diagnostic-stream-stop')
    def injected_stream():
        checked()
        if armed[0]:raise sentinel
    store=fresh(injected_stream);reference=store.capture({'value':[1,2]},label='diagnostic:stream')
    source=store.canonical(reference);armed[0]=True
    try:
        seen=False
        for attempt in range(64):
            checked()
            try:next(source)
            except BaseException as error:
                if external_fault is not None:raise external_fault
                if error is not sentinel:raise
                need(source.completed is False,'foreign StopIteration cannot finish a stream')
                seen=True;break
        need(seen,'finite expected stream callback was reached')
    finally:source.close()
    passed(ADAPTER_DIAGNOSTICS[2],dict(capture_exact_exception_types=identities,
        manual_next_foreign_StopIteration=True,stream_completed=False,
        limitation='Finite callback opportunities; no universal exception-path coverage.'))

    armed=[False];holder=[None];observed=[None]
    def reentrant():
        checked()
        if armed[0]:
            armed[0]=False
            passive=holder[0].statistics()
            need(type(passive)is dict,'passive callback statistics allowed')
            try:holder[0].capture(None,label='diagnostic:forbidden-reentry')
            except BaseException as error:
                observed[0]=error;raise
    store=fresh(reentrant);holder[0]=store;armed[0]=True
    try:store.capture([1],label='diagnostic:outer')
    except BaseException as error:
        if external_fault is not None:raise external_fault
        need(type(error)is adapter.EvidenceReentrancy and error is observed[0],
             'same own reentrancy error propagates through outer operation')
    else:raise ColdError('callback reentrancy was accepted')
    need(store.statistics()['failed'] is True,'reentrancy leaves only failure prefix')
    passed(ADAPTER_DIAGNOSTICS[3],dict(passive_statistics=True,charged_reentry_rejected=True,
                                     exact_outer_error=True,usable_output=False))

    store=fresh();reference=store.capture([1],label='diagnostic:before-failure')
    before=store.statistics()
    try:store.assemble([reference,{'completed':1},object()],label='diagnostic:bad-layout')
    except BaseException as error:
        if external_fault is not None:raise external_fault
        if type(error)is not adapter.EvidenceDataError:raise
    else:raise ColdError('non-JSON assembly element was accepted')
    after=store.statistics()
    need(after['failed'] is True and after['operations']>before['operations'] and
         after['arena']['roots']>before['arena']['roots'],
         'completed assembly prefix is retained as failed statistics only')
    try:store.seal(reference)
    except BaseException as error:
        if external_fault is not None:raise external_fault
        if type(error)is not adapter.EvidenceDataError:raise
    else:raise ColdError('failed Store exposed a complete forest')
    passed(ADAPTER_DIAGNOSTICS[4],dict(partial_roots_preserved=True,attempted_cost_monotone=True,
        failed_prefix_only=True,complete_output_accepted=False))
    need(tuple(row['name']for row in rows)==ADAPTER_DIAGNOSTICS and stores==8,
         'all and only declared diagnostic groups completed')
    checked();guarded()
    return dict(schema='owned-adapter-finite-diagnostic-result-v1',status='COMPLETE',
        mathematical_authority=False,profile=ADAPTER_DIAGNOSTIC_PROFILE,groups=rows,
        fresh_Stores=stores,scope='Finite runtime observations only, charged to this full original001 invocation.')


'''
change('def main(argv):',helper+'def main(argv):','five bounded adapter diagnostic groups inside same Source')
change("        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']", "        adapter_diagnostics=stage('owned-adapter-boundary-diagnostics',lambda:run_adapter_diagnostics(\n            loaded[EVIDENCE_ALIASES['adapter']],loaded[EVIDENCE_ALIASES['arena']],\n            lambda:need(_NOW_NS()<work_ns,'adapter diagnostics inside original work'),source_guard,\n            dict(schema='owned-adapter-diagnostic-source-context-v1',invocation_id=plan['invocation_id'],\n                 evidence_sources=evidence_owned,cold=plan['cold'])))\n        factory_module=loaded['bounded_request_oracle'];registry=loaded['semantic_inventory_oracle']",'diagnostics before original full Native/proof pipeline')
change("            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,", "            evidence_verification=evidence_verification,evidence_profile=EVIDENCE_PROFILE,\n            adapter_diagnostics=adapter_diagnostics,",'retain complete finite diagnostic result in counted worker metadata')

out=D/'owned_evidence_cold_v3.py'
assert not out.exists()
ast.parse(s);compile(s,str(out),'exec')
out.write_text(s)
(D/'cold-author-transform-v3.json').write_text(json.dumps(dict(schema='metadata-only-cold-transform-v3',
    parent=pin(P),source=pin(out),changes=changes,target_functions_called=0),indent=2,ensure_ascii=False)+'\n')
print(json.dumps(pin(out)))
