"""Author static metadata only: no target imports, calls, fixtures or eval."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

D=Path(__file__).parent
P=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_cold_v1.py')
S=D/'owned_evidence_cold_v3.py'
def pin(p):
    p=Path(p);b=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
def save(name,value):
    p=D/name;assert not p.exists(),name
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    return pin(p)
old=P.read_text();new=S.read_text();a=ast.parse(old);b=ast.parse(new)
top={n.targets[0].id:n.value for n in b.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
literal=lambda name:ast.literal_eval(top[name])
evidence=literal('EVIDENCE_SOURCES');aliases=literal('EVIDENCE_ALIASES')
arena=literal('ARENA_LIMITS');adapter=literal('ADAPTER_LIMITS');inverse=literal('INVERSE_LIMITS')
cases=list(literal('ADAPTER_DIAGNOSTICS'))
small_arena=dict(arena,work=1000000,nodes=4096,edges=16384,roots=64,depth=32,
    scalar_bytes=1048576,wire_bytes=1048576,root_expanded_bytes=1048576,
    documents_expanded_bytes=1048576,materialized_bytes=1048576,
    materialized_occurrences=10000,cache_bytes=4096,cache_entries=256,chunk_bytes=4096)
small_adapter=dict(operations=100000,value_bytes=1048576,depth=32,chunk_bytes=4096)
diagnostics=dict(schema='owned-adapter-finite-diagnostic-profile-v1',cases=cases,
    maximum_fresh_Stores=8,arena_limits=small_arena,adapter_limits=small_adapter,
    scope='Small finite adapter boundary checks before original full001 proof pipeline; same original total work/peak/output caps, not a carrier benchmark or proof authority.')
profile=dict(schema='owned-evidence-integration-profile-v1',sources=evidence,
    arena_limits=arena,adapter_limits=adapter,inverse_limits=inverse,
    inverse_version=literal('INVERSE_VERSION'),inverse_execution_profile=literal('INVERSE_PROFILE'),
    logical_output='complete-legacy-JSON-body-plus-LF',sole_document=literal('EVIDENCE_DOCUMENT'),
    unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION',
    physical_accounting='ordinary_result+forest+all_root_JSON_metadata_including_worker_receipt',
    encoded_and_logical_cap_bytes=134217728,adapter_diagnostics=diagnostics)
profile_pin=save('EVIDENCE_PROFILE-v3.json',profile)
rows=[]
def check(name,condition,detail):
    assert condition,name
    rows.append(dict(name=name,passed=True,method='raw Source/AST/metadata only',detail=detail))
check('parent_raw',pin(P)==dict(path=str(P),sha256='ca7e91079982948ecbde5816b0d175810031981835ec8ddfa17f273379574868',bytes=39413),'Exact parent retained.')
check('current_raw',pin(S)==dict(path=str(S),sha256='a445a7fbbd2575c13223268cd23f0ad910d93bc34415421ec5583bee876828d4',bytes=62795),'Exact generated successor retained.')
retained=[]
for node in a.body:
    if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name!='main':
        match=next(n for n in b.body if type(n)is type(node) and n.name==node.name)
        raw_equal=ast.get_source_segment(old,node)==ast.get_source_segment(new,match)
        ast_equal=ast.dump(node,include_attributes=False)==ast.dump(match,include_attributes=False)
        check('retained_'+node.name,raw_equal and ast_equal,'Whole parent helper/class raw bytes and AST unchanged.')
        retained.append(dict(name=node.name,parent_line=node.lineno,current_line=match.lineno,raw_equal=raw_equal,AST_equal=ast_equal))
check('driver_pin',literal('RECEIVER_DRIVER_SOURCE')==pin('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019/owned_evidence_receiver_driver_v4.py'),'Root driver V4 only; no historical fallback.')
check('registry_pin',literal('REGISTRY_SOURCE')==pin(D/'semantic_inventory_oracle_v5.py'),'Owned explicit entry; default registry prefix separately unchanged.')
for role,p in evidence.items():check('evidence_'+role,pin(p['path'])==p,'Whole fixed raw Source pin.')
check('same28_aliases',len(aliases)==4 and "len(names)==28"in new and "len(loaded)==28"in new,'22project+2components+4evidence before schema1.')
check('late_schema',new.index('module_guards.append(seal_callables(list(loaded.values())')<new.index("for name in SCHEMA_SOURCES:\n            module=stage('import schema:"),'Original early base seal retained without rebaseline.')
check('same_epoch_schema',literal('EPOCH_SCHEMA')=='semantic-family-receiver-source-epoch-v6-explicit-schema-admission','Driver current Boundary schema preserved; new explicit fields authenticated by full epoch.')
check('same_theory_capsule',"'1a42c2ab16680dddbac504ca5b2d79559370785884805cf4d56b5c1c22c63dc0'"in new,'Full original10 assertion capsule, exact001 selection.')
check('exact001',"plan['receiver_id']=='prospective-fol-20261018-001'"in new,'No case002 rescue or fallback receiver.')
check('whole_decl_profile',"canonical(integration['evidence_profile'])==canonical(EVIDENCE_PROFILE)"in new,'Full ordinary declaration profile equality.')
check('whole_closure_evidence',"closure['evidence_sources']==EVIDENCE_SOURCES"in new,'Unknown evidence Source cannot enter through closure.')
check('all_old_runtime_maps',all("'"+k+"'"in new for k in ('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python')),'Existing literal complete map join unchanged.')
check('owned_entry',".run_receiver_owned(receiver_spec="in new and "evidence_module=loaded[EVIDENCE_ALIASES['adapter']]"in new,'Explicit owned API, original proof constructor arguments unchanged.')
check('owned_storage_epoch',"schema='owned-evidence-storage-declaration-v1'"in new and "for role in ('adapter','arena','join')"in new,'Exact driver _owned_store field set and copied module pins.')
check('inverse_epoch',"epoch['independent_evidence_inverse']"in new,'Inverse original+owned Source/version/profile/full30m in full epoch.')
check('separate_work_caps',arena['work']==400000000 and adapter['operations']==400000000 and inverse['work']==30000000,'Explicit separate attempted-work profiles; no old200m success claim.')
check('original_wall',"work_ns==began+180000000000 and overall_ns==began+210000000000"in new,'Original absolute Source-entry180/210.')
check('both_output_caps',all(x==134217728 for x in [arena['wire_bytes'],arena['documents_expanded_bytes'],adapter['value_bytes'],inverse['expanded_bytes'],inverse['wire_bytes']]),'Encoded+expanded caps unchanged.')
check('fresh_saved_forest',"forest_wire=json.loads(forest_raw)"in new and "inverse.prepare_forest(wire,check,limits=dict(INVERSE_LIMITS),statistics=observed)"in new,'Fresh full ordinary saved forest prepare inside actual only.')
check('full_epoch_headers',"wire['source_epoch']==canonical(epoch).decode('utf8')"in new and "wire['semantic_epoch']==canonical(epoch['evidence_storage']).decode('utf8')"in new,'Full literal preimages, no hash-only authority.')
check('sole_doc',"wire['documents']==[EVIDENCE_DOCUMENT]"in new and "prepared.documents==(EVIDENCE_DOCUMENT,)"in new,'No hidden catalogue-only roots or omitted docs.')
check('every_inverse_byte',"part==result_raw[offset:end]"in new and "result_raw[offset:]==b'\\n'"in new,'Independent BODY plus exactly one external LF.')
check('explicit_completion',"if source.completed is not True:\n                    raise"in new and "document['completed'] is True"in new,'Delegated StopIteration never accepted as normal incomplete stream.')
check('inverse_ledgers',"document['stream_value_occurrences']==document['logical_value_occurrences']"in new and "stats['aggregate_document_bytes']==len(result_raw)"in new,'Full document and aggregate statistics retained.')
check('old_result_parser',"loaded['interned_result_reader_v2'].decode_result(result_raw,checkpoint=reader_tick)"in new,'Old strict current result parser retained.')
check('old_result_inverse',"literal=verify_literal_result(result_data,result_raw,reader_tick)"in new,'Old full canonical reconstruction retained in addition to new forest check.')
check('whole_epoch_result',"canonical(result_data['source_epoch'])==canonical(epoch)"in new,'Result full scientific/evidence epoch custody.')
check('point_final_check',"verify_raw_region(result_data,work_ns)"in new,'Whole original raw point verification retained.')
check('native_ledger',"canonical(result_data['records'])==canonical(oracle_box[0].records)"in new,'Fresh persistent Native full ledger retained.')
check('native_cleanup',"transport['closed'] is True and transport['all_reaped'] is True"in new and "transport['native_exit_code']==0"in new,'Existing exact Native cleanup/exit joins retained.')
check('diagnostics_inside_only',new.index("stage('owned-adapter-boundary-diagnostics'")<new.index(".run_receiver_owned(receiver_spec="),'Small diagnostic groups precede full original proof pipeline, not standalone actuals.')
check('diagnostic_names',len(cases)==5 and len(set(cases))==5,'All five literal names and eight fresh finite Stores.')
check('finite_diag_limits',small_arena['work']==1000000 and small_adapter['operations']==100000,'Smaller per-Store diagnostics; total wall/peak/output remain common.')
check('callback_origin',"external_fault=error;raise"in new and "if external_fault is not None:raise external_fault"in new,'Unexpected Root deadline/Source fault cannot satisfy a refusal.')
check('diag_stop_iteration',"manual_next_foreign_StopIteration=True"in new and "if error is not sentinel:raise"in new,'Finite manual-next exact sentinel path, completion independently false.')
check('reentrancy',"type(error)is adapter.EvidenceReentrancy and error is observed[0]"in new,'Own reentry exact error chain observed, passive stats allowed.')
check('failed_assembly',"after['arena']['roots']>before['arena']['roots']"in new and "failed Store exposed a complete forest"in new,'Failed assembly retained prefix never usable output.')
check('diag_rows_after_success',"rows.append(dict(schema='owned-adapter-finite-diagnostic-v1'"in new,'Only completely checked groups become passed rows.')
check('ledger_fixedpoint',"worker_receipt_bytes"in new and "for attempt in range(32)"in new,'No receipt self-hash cycle; exact forthcoming bytes counted.')
check('no_late_rewrite',"No late rewrite, partial Model permission or accepted forest fallback"in new,'Storage failure never rewritten into ordinary complete UNKNOWN success.')
check('failure_identity',"except BaseException as metadata_error"in new and "bounded failure metadata unavailable"in new,'Auxiliary failure metadata does not mask original BaseException.')
check('failure_no_authority',"complete_output_accepted=False,scientific_acceptance=False"in new and "resource_accepted=False,retry_authorized=False"in new,'Diagnostic prefixes only; no retry or partial admission.')
check('worker_header_new_evidence',all(x in new for x in ('evidence_forest=forest_pin','evidence_statistics=receipt','evidence_verification=evidence_verification','adapter_diagnostics=adapter_diagnostics')),'Full Source/profile/stats/sidecar/diagnostics recorded.')

# Inert real text patches in fresh scratch directories; no target is executed.
patch_rows=[]
for label,src,dst in [('cold-parent-to-v3',P,S),('cold-v2-to-v3',D/'owned_evidence_cold_v2.py',S)]:
    before=src.read_text();after=dst.read_text()
    forward=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='cold.py',tofile='cold.py'))
    reverse=''.join(difflib.unified_diff(after.splitlines(True),before.splitlines(True),fromfile='cold.py',tofile='cold.py'))
    f=D/(label+'.forward.patch');r=D/(label+'.inverse.patch')
    assert not f.exists()and not r.exists();f.write_text(forward);r.write_text(reverse)
    for direction,start,wanted,patch in [('forward',before,after,f),('inverse',after,before,r)]:
        scratch=D/'cold-inert-patch'/label/direction;scratch.mkdir(parents=True)
        (scratch/'cold.py').write_text(start)
        proc=subprocess.run(['/usr/bin/patch','--batch','-p0','-i',str(patch)],cwd=scratch,capture_output=True,text=True)
        assert proc.returncode==0,(label,direction,proc.stdout,proc.stderr)
        got=(scratch/'cold.py').read_text();assert got==wanted
        ast.parse(got);compile(got,str(scratch/'cold.py'),'exec')
        patch_rows.append(dict(label=label,direction=direction,applied=True,whole_bytes_equal=True,
                               compile_without_eval=True,patch=pin(patch),result=pin(scratch/'cold.py')))
compile(new,str(S),'exec');compile(old,str(P),'exec')
line_refs={n.name:dict(line=n.lineno,end_line=n.end_lineno) for n in b.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
source=pin(S);parent=pin(P)
dependencies=dict(driver=literal('RECEIVER_DRIVER_SOURCE'),registry=literal('REGISTRY_SOURCE'),
    evidence_sources=evidence,schema_sources=literal('SCHEMA_SOURCES'),kernel_source=literal('SCHEMA_KERNEL_SOURCE'),
    parent_runtime_closure=literal('PARENT_RUNTIME_CLOSURE'))
api=save('cold-API-v3.json',dict(schema='owned-evidence-cold-API-v3',source=source,
    VERSION=literal('VERSION'),PLAN_SCHEMA=literal('PLAN_SCHEMA'),EPOCH_SCHEMA=literal('EPOCH_SCHEMA'),
    WORKER_SCHEMA=literal('WORKER_SCHEMA'),entry='main(argv)',
    argv=['worker_plan_absolute_path','Source_entry_began_ns','absolute_work_deadline_ns','absolute_overall_deadline_ns'],
    worker_plan_fields=['schema','invocation_id','mode','actual_directory','cold','python','project_sources','components',
        'native_inputs','policy','declaration','runtime_closure','z3','receiver_id','result_reader',
        'integration_declaration','model_storage','search_ordering','inventory_certification_mode'],
    integration_schema='ROOT-owned-evidence-integration-comparison-declaration-v1',
    integration_required_fields=['schema','parent_structural_declaration','selected_receiver_id','schedule','evidence_profile'],
    runtime_closure_schema='ROOT-owned-evidence-integration-raw-runtime-closure-v1',
    closure_evidence_sources=evidence,evidence_aliases=aliases,
    closure_materialized_aliases='22exactproject+2components+4evidence=28base, then1schema',
    evidence_profile=profile,profile_raw=profile_pin,
    epoch_additions=dict(evidence_storage=['schema','sources(adapter/arena/join owned paths)','arena_limits','adapter_limits','logical_output','unfinished_storage'],
        independent_evidence_inverse=['schema','original','owned','version','execution_profile','limits','sole_document','stream','authority']),
    header_additions=['evidence_forest','evidence_statistics','evidence_verification','evidence_profile','adapter_diagnostics','owned_output_ledger'],
    evidence_verification_keys=['schema','status','representation_only','mathematical_authority','started_ns','completed_ns',
        'logical_body_bytes','logical_file_bytes','forest','declaration','statistics'],
    result_protocol='No Python value; writes exactly bounded worker-receipt.json on complete success or best-effort failure metadata then rethrows.',
    caller_requirements=['Exact once-plan/current declaration/runtime closure and all current independent reviews, not supplied by this Source.',
        'Outer validates worker known exit and Native cleanup plus conservative worker+Native<=1GiB, logs<=4MiB and180/210 epochs.',
        'Cold ledger counts all root JSON present plus forthcoming worker receipt. Outer adds JSON metadata it creates later if included in global physical cap.',
        'No activation, target proof, capacity fit, memory-saving or method advantage follows from this author Source packet.']))
argument=save('cold-Source-argument-v3.json',dict(schema='owned-evidence-cold-Source-argument-v3',source=source,parent=parent,
    author_identity='/root/conventional_library',source_only=True,target_calls=0,
    source_facts=['All parent top-level helpers/classes other than main are whole raw/AST identical.',
        'Main only adds fixed owned Source coupling, declaration/epoch joins, full saved representation inverse, bounded diagnostics and output accounting.',
        'Old Native/template preparation remains inside future actual; no author invocation occurred.',
        'All point/Native/registry/Model/search/ranking/candidate/fallback semantics reside in unchanged or separately reviewed components.'],
    retention=retained,line_references=line_refs,
    limitations=['This author does not independently certify their own registry, arena, Model, parent driver or point-search ancestry.',
        'Root driver/adapter/join Source and current intake coupling require distinct review; metadata interface checks are not trust authority.',
        'No runtime diagnostics, fit, serialization, exact-graph, Native acceptance or cleanup results have been observed.',
        'Full forest+ordinary result+old parser lifetimes and all conversion costs are retained; memory improvement is unknown.',
        'Raw_file and builtin JSON/encoder operations have cooperative boundary checks, not a hard mid-operation preemption guarantee.',
        'Only caller-exclusive ordinary input/Source custody is covered; no hostile concurrent runtime mutation proof.',
        'Master21657 preimage read previously; current dataless working copy could not be rehydrated offline. No normative rule was changed.']))
contract=save('cold-Source-contract-v3.json',dict(schema='owned-evidence-cold-Source-contract-v3',author_identity='/root/conventional_library',
    source=source,sources=[source],parent=parent,dependencies=dependencies,API=api,evidence_profile=profile_pin,
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    required_profile=dict(work_seconds=180,overall_seconds=210,worker_plus_Native_peak_bytes=1073741824,
        output_physical_bytes=134217728,output_logical_bytes=134217728,logs_bytes=4194304,
        arena_work=400000000,adapter_operations=400000000,independent_inverse_operations=30000000),
    untouched=['entire assertion capsule1a42/22422','complete original4-family policy','22project logical Source universe except explicit registry owned successor',
        'all definitions/interfaces/marks/candidates','all old strict region and canonical checks','original Native checker/program/template',
        'default legacy registry delegates','search5000 method-local units and30s','aggregate Native5e9'],
    review_ABI=dict(schema='owned-evidence-cold-typed-Source-review-v1',required_fields=[
        'schema','source','sources','source_contract','author_identity','reviewer_identity','source_only',
        'source_review_passed','scientific_calls','scientific_acceptance','actual_execution_authorized','findings','limitations'],
        expected_author_identity='/root/conventional_library',reviewer_must_be_distinct=True),
    caller_authentication='Exact Source/raw closure/declaration/plan/grant plus distinct current Source/plan/final peers remain Root-owned. This author packet grants nothing.'))
audit=save('cold-author-static-audit-v3.json',dict(schema='owned-evidence-cold-author-static-audit-v3',source=source,parent=parent,
    author_identity='/root/conventional_library',independent=False,checks=rows,check_count=len(rows),mismatches=0,
    retained_regions=retained,inert_patches=patch_rows,unused_compiles=6,
    target_imports=0,target_functions_called=0,fixture_calls=0,scientific_calls=0,
    runtime_tests='NOT_EXECUTED',scientific_acceptance=False,actual_execution_authorized=False))
delta=save('cold-Source-delta-v3.json',dict(schema='owned-evidence-cold-Source-delta-v3',source=source,parent=parent,
    transforms=[pin(D/'cold-author-transform-v2.json'),pin(D/'cold-author-transform-v3.json')],
    draft_v2=pin(D/'owned_evidence_cold_v2.py'),retained_regions=retained,
    patches=patch_rows,unrelated_sources_changed=False,all_runtime_tests_unexecuted=True))
handoff=save('cold-handoff-v3.json',dict(schema='owned-evidence-cold-author-handoff-v3',source=source,sources=[source],
    author_identity='/root/conventional_library',source_contract=contract,API=api,evidence_profile=profile_pin,
    argument=argument,delta=delta,author_static_audit=audit,dependencies=dependencies,
    source_only=True,scientific_calls=0,scientific_acceptance=False,actual_execution_authorized=False,
    status='FROZEN_SOURCE_ONLY_NOT_RUNTIME_QUALIFIED',next_gate='Distinct Source review; Root-only current closure/declaration/once subjects/plans/grants and all agents idle before any actual.'))
print(json.dumps(dict(source=source,profile=profile_pin,handoff=handoff,checks=len(rows))))
