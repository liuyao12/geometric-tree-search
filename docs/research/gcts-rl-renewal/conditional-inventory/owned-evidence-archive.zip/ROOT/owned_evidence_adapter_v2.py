"""Explicit owned evidence references over the unchanged qualified arena.

Source-only until separately reviewed and granted. No proof/Model authority.
Legacy JSON normalization is an evidence projection, never a Model mutation.
Assembly is NOT a multi-capture transaction: failure can retain committed roots,
which must be reported as an unfinished prefix, never a complete sealed result.
"""
import json
import math

VERSION = 'owned-evidence-adapter-v1'
_TOKEN = object()
_END = object()
_LIMIT_KEYS = frozenset(('operations','value_bytes','depth','chunk_bytes'))
_RESERVED = 'adapter-owned:'

class EvidenceDataError(ValueError):pass
class EvidenceLimit(RuntimeError):
    def __init__(self,reason,*,owner=None):self.reason=reason;self.owner=owner;super().__init__(reason)
class EvidenceReentrancy(RuntimeError):pass

class _Immutable:
    __slots__=()
    def __setattr__(self,k,v):raise AttributeError('immutable evidence interface')
    def __delattr__(self,k):raise AttributeError('immutable evidence interface')

class Reference(_Immutable):
    __slots__=('_store','_root','_path')
    def __init__(self,store,root,path=(),*,_token=None):
        if _token is not _TOKEN:raise EvidenceDataError('Store-created reference required')
        object.__setattr__(self,'_store',store);object.__setattr__(self,'_root',root);object.__setattr__(self,'_path',path)
    @property
    def kind(self):return self._store._view(self).kind
    @property
    def length(self):
        v=self._store._view(self)
        if v.kind not in ('array','object'):raise EvidenceDataError('container length required')
        return v.length
    @property
    def keys(self):
        v=self._store._view(self)
        if v.kind!='object':raise EvidenceDataError('object keys required')
        return v.keys
    def at(self,key):
        s=self._store;s._public();s._step('path_references')
        if type(key)not in(str,int)or type(key)is int and key<0:raise EvidenceDataError('strict path key/index')
        kind=self.kind
        if kind=='object'and type(key)is not str or kind=='array'and type(key)is not int:
            raise EvidenceDataError('path component kind')
        if kind not in('array','object'):raise EvidenceDataError('path requires current container')
        return Reference(s,self._root,self._path+(key,),_token=_TOKEN)
    def get(self,key):return self.at(key)
    def scalar(self):
        v=self._store._view(self);kind=v.kind
        if kind=='null':return None
        if kind in('bool','str'):return v.payload
        if kind=='int':return int(v.payload)
        if kind=='float':return float(v.payload)
        raise EvidenceDataError('present exact scalar required')
    def equals(self,value):return self._store.equal(self,value)
    def same(self,other):return self._store.equal_references(self,other)

class InventoryBundle(_Immutable):
    __slots__=('_store','operational','logical_ref')
    VERSION='owned-inventory-bundle-v1'
    def __init__(self,store,operational,logical_ref,*,_token=None):
        if _token is not _TOKEN:raise EvidenceDataError('Store-created inventory bundle required')
        object.__setattr__(self,'_store',store);object.__setattr__(self,'operational',operational);object.__setattr__(self,'logical_ref',logical_ref)

class Store:
    VERSION=VERSION
    def __init__(self,*,arena_module,arena,check,source_guard,limits):
        if (getattr(arena_module,'VERSION',None)!='exact-evidence-arena-v1'or
                type(arena)is not arena_module.Arena or not callable(check)or not callable(source_guard)):
            raise EvidenceDataError('explicit qualified arena and callbacks')
        if type(limits)is not dict or set(limits)!=_LIMIT_KEYS or any(type(v)is not int or v<=0 for v in limits.values()):
            raise EvidenceDataError('all strict finite adapter limits required')
        if limits['chunk_bytes']>65536 or limits['depth']>512:raise EvidenceDataError('bounded adapter chunks/depth')
        self._module=arena_module;self._arena=arena;self._check=check;self._guard=source_guard;self._limits=dict(limits)
        self._counters={};self._work=0;self._last_check=0;self._callback=False;self._sequence=0;self._failed=False
        self._finish()
    def _public(self):
        if self._callback:raise EvidenceReentrancy('callbacks may only inspect passive adapter statistics')
        if self._failed:raise EvidenceDataError('failed adapter is prefix evidence only')
    def _call(self,f):
        self._callback=True
        try:return f()
        finally:self._callback=False
    def _step(self,kind,n=1):
        if type(n)is not int or n<0:raise EvidenceDataError('strict attempted operation count')
        self._work+=n;self._counters[kind]=self._counters.get(kind,0)+n
        if self._work>self._limits['operations']:raise EvidenceLimit('adapter_operations',owner=self)
        if self._work-self._last_check>=1024:
            self._last_check=self._work;self._call(self._check)
    def _finish(self):self._call(self._check);self._call(self._guard);self._call(self._check)
    def _ref(self,r,whole=False):
        self._public()
        if type(r)is not Reference or r._store is not self or whole and r._path:
            raise EvidenceDataError('same-Store whole reference required'if whole else'same-Store reference required')
        return r
    def _view(self,r):
        r=self._ref(r);self._step('view_requests');return self._arena.view(r._root,r._path)
    def _auto(self):
        self._step('generated_labels');self._sequence+=1;return _RESERVED+str(self._sequence)
    def _label(self,label,internal):
        if type(label)is not str or not label or not internal and label.startswith(_RESERVED):
            raise EvidenceDataError('explicit nonreserved output label')
    def _contains_reference(self,value):
        stack=[('enter',value,0)];active=set()
        while stack:
            phase,v,depth=stack.pop();self._step('legacy_domain_frames')
            if phase=='leave':active.remove(id(v));continue
            if depth>self._limits['depth']:raise EvidenceLimit('adapter_depth',owner=self)
            if type(v)is Reference:self._ref(v,whole=True);return True
            if type(v)in(dict,list,tuple):
                if id(v)in active:raise EvidenceDataError('cyclic legacy JSON value')
                active.add(id(v));stack.append(('leave',v,depth));self._step('legacy_container_slots',len(v))
                if type(v)is dict:
                    if any(type(k)is not str for k in v):raise EvidenceDataError('legacy object keys must be exact strings')
                    for x in reversed(list(v.values())):stack.append(('enter',x,depth+1))
                else:
                    for x in reversed(v):stack.append(('enter',x,depth+1))
            elif v is None or type(v)in(bool,int,str):pass
            elif type(v)is float:
                if not math.isfinite(v):raise EvidenceDataError('finite legacy float')
            else:raise EvidenceDataError('exact builtin legacy JSON domain only')
        return False
    def _canonical(self,value):
        # Full old JSON projection; temporary bytes/copies are charged in wall/peak.
        # Builtin encoder latency is a declared runtime assumption, not preemption.
        raw=bytearray();encoder=json.JSONEncoder(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
        for part in encoder.iterencode(value):
            self._step('legacy_JSON_parts');b=part.encode('utf8')
            if len(raw)+len(b)>self._limits['value_bytes']:raise EvidenceLimit('adapter_value_bytes',owner=self)
            for i in range(0,len(b),self._limits['chunk_bytes']):
                self._step('legacy_JSON_copy_chunks');raw.extend(b[i:i+self._limits['chunk_bytes']])
        self._step('legacy_JSON_freezes');return bytes(raw)
    def _capture(self,value,label,internal=False):
        self._public();self._label(label,internal)
        if self._contains_reference(value):raise EvidenceDataError('capture requires ordinary legacy value; use assemble')
        self._finish();original=self._canonical(value)
        self._step('legacy_JSON_parse_begin');normalized=json.loads(original);self._step('legacy_JSON_parse_end')
        if self._canonical(normalized)!=original:raise EvidenceDataError('legacy JSON normalization changed bytes')
        root=self._arena.capture(normalized,label=label);self._step('completed_captures')
        self._finish();return Reference(self,root,_token=_TOKEN)
    def capture(self,value,*,label):
        try:return self._capture(value,label)
        except BaseException:self._failed=True;raise
    def assemble(self,value,*,label):
        self._public();self._label(label,False);holder=[None];stack=[('enter',value,label,holder,0,0)];active=set()
        try:
            while stack:
                phase,v,lab,parent,key,depth=stack.pop();self._step('assembly_frames')
                if depth>self._limits['depth']:raise EvidenceLimit('adapter_depth',owner=self)
                if phase=='leave':
                    original,kind,keys,children=v
                    if kind=='object':
                        if tuple(original)!=keys:raise EvidenceDataError('mixed object keys changed during assembly')
                        args=[(k,self._ref(r,whole=True)._root)for k,r in zip(keys,children)]
                    else:
                        if len(original)!=len(children):raise EvidenceDataError('mixed array length changed during assembly')
                        args=[self._ref(r,whole=True)._root for r in children]
                    handle=self._arena.compose(kind,args,label=lab);parent[key]=Reference(self,handle,_token=_TOKEN);active.remove(id(original));continue
                if type(v)is Reference:parent[key]=self._ref(v,whole=True);continue
                if not self._contains_reference(v):parent[key]=self._capture(v,lab,internal=lab.startswith(_RESERVED));continue
                if type(v)not in(dict,list,tuple):raise EvidenceDataError('mixed evidence container required')
                if id(v)in active:raise EvidenceDataError('cyclic mixed evidence layout')
                active.add(id(v));self._step('assembly_child_slots',len(v));children=[None]*len(v)
                keys=tuple(v)if type(v)is dict else();kind='object'if type(v)is dict else'array'
                if kind=='object'and any(type(k)is not str for k in keys):raise EvidenceDataError('exact mixed object keys')
                stack.append(('leave',(v,kind,keys,children),lab,parent,key,depth))
                vals=[v[k]for k in keys]if kind=='object'else v
                for i in range(len(vals)-1,-1,-1):
                    lab_child=self._auto()if type(vals[i])is not Reference else None
                    stack.append(('enter',vals[i],lab_child,children,i,depth+1))
            self._finish();return holder[0]
        except BaseException:self._failed=True;raise
    def inventory_bundle(self,operational,logical_ref):
        self._public();self._ref(logical_ref,whole=True)
        if type(operational)is not dict or self._contains_reference(operational):raise EvidenceDataError('ordinary operational inventory required')
        self._finish();return InventoryBundle(self,operational,logical_ref,_token=_TOKEN)
    def unwrap_inventory(self,bundle):
        self._public();self._step('inventory_bundle_reads')
        if type(bundle)is not InventoryBundle or bundle._store is not self:raise EvidenceDataError('same-Store inventory bundle required')
        self._ref(bundle.logical_ref,whole=True);return bundle.operational,bundle.logical_ref
    def _pull(self,stream):
        try:return next(stream)
        except StopIteration:
            if stream.completed:return _END
            raise  # Preserve exact delegated StopIteration, never prefix acceptance.
    def equal(self,reference,value):
        reference=self._ref(reference)
        if self._contains_reference(value):raise EvidenceDataError('ordinary equality argument required')
        self._finish();raw=self._canonical(value);stream=self._arena.iter_canonical(reference._root,reference._path);offset=0
        try:
            while True:
                chunk=self._pull(stream)
                if chunk is _END:break
                self._step('ordinary_comparison_chunks')
                if chunk!=raw[offset:offset+len(chunk)]:return False
                offset+=len(chunk)
            self._finish();return offset==len(raw)and stream.completed
        finally:stream.close()
    def equal_references(self,left,right):
        left=self._ref(left);right=self._ref(right);self._finish()
        a=self._arena.iter_canonical(left._root,left._path);b=None
        try:
            b=self._arena.iter_canonical(right._root,right._path)
            while True:
                x=self._pull(a);y=self._pull(b);self._step('reference_comparison_chunks')
                if x is _END or y is _END:
                    self._finish();return x is y is _END and a.completed and b.completed
                if x!=y:return False
        finally:
            a.close()
            if b is not None:b.close()
    def canonical(self,reference):
        reference=self._ref(reference);self._step('canonical_stream_requests');return self._arena.iter_canonical(reference._root,reference._path)
    def seal(self,reference):
        reference=self._ref(reference,whole=True)
        try:self._finish();return self._arena.seal([reference._root.label])
        except BaseException:self._failed=True;raise
    def wire(self,sealed):self._public();self._step('wire_requests');return self._arena.to_wire(sealed)
    def statistics(self):
        return dict(schema='owned-evidence-adapter-statistics-v1',authority=False,operations=self._work,
            counters=dict(self._counters),failed=self._failed,arena=self._arena.statistics())
