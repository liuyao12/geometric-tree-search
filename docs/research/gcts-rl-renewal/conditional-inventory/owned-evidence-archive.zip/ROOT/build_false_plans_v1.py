"""Ordinary metadata authoring only; never imports or evaluates research Sources."""
from pathlib import Path
import ast,hashlib,json,sys
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
L=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019')
def pin(p):
 p=Path(p).resolve();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def save(p,v):
 p=Path(p);assert not p.exists(),str(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n');return pin(p)
assert len(sys.argv)==4,'cold runner observer Source path arguments only'
cold,runner,observer=map(pin,sys.argv[1:])
old=load('/private/tmp/gcts-schema-admission-ROOT-20261019/plans-v2/worker-plans/schema-admission-002-fixed-ROOT-20261019-v2.json')
oldclosure=load(old['runtime_closure']['path'])
oldauth=load('/private/tmp/gcts-schema-admission-ROOT-20261019/plans-v2/authorizations/schema-admission-002-fixed-ROOT-20261019-v2.json')
project=dict(old['project_sources']);project['semantic_inventory_oracle']=pin(L/'semantic_inventory_oracle_v5.py')
components=dict(old['components']);components['receiver_driver']=pin(D/'owned_evidence_receiver_driver_v4.py')
evidence=dict(adapter=pin(D/'owned_evidence_adapter_v3.py'),arena=pin('/private/tmp/gcts-direct-reconcile-library-20261019/exact_evidence_arena_v3.py'),join=pin(D/'owned_inventory_join_v2.py'),inverse=pin('/private/tmp/gcts-incremental-arena-ROOT-20261019/independent_forest_inverse_v6.py'))
aliases=dict(adapter='owned_evidence_adapter',arena='exact_evidence_arena',join='owned_inventory_join',inverse='independent_forest_inverse')
# Literal profile copied from reviewed cold declaration, not read by importing it.
limits={'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536,'depth':512,'documents_expanded_bytes':134217728,'edges':8000000,'fragment_bytes':4096,'integer_digits':4096,'materialized_bytes':4194304,'materialized_occurrences':100000,'nodes':2000000,'root_expanded_bytes':134217728,'roots':4096,'scalar_bytes':16777216,'wire_bytes':134217728,'work':400000000}
adapterlimits={'operations':400000000,'value_bytes':134217728,'depth':512,'chunk_bytes':65536}
inverselimits={'nodes':2000000,'edges':8000000,'roots':4096,'depth':513,'work':30000000,'expanded_bytes':134217728,'wire_bytes':134217728,'scalar_bytes':16777216,'integer_digits':4096,'fragment_bytes':4096,'cache_bytes':8388608,'cache_entries':65536,'chunk_bytes':65536}
profile=dict(schema='owned-evidence-integration-profile-v1',sources=evidence,arena_limits=limits,adapter_limits=adapterlimits,inverse_limits=inverselimits,inverse_version='independent-evidence-forest-inverse-v6-full-scalar-and-ledger-bounds',inverse_execution_profile='independent-forest-actual-operations-v1',logical_output='complete-legacy-JSON-body-plus-LF',sole_document='receiver:complete-legacy-result',unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION',physical_accounting='ordinary_result+forest+all_root_JSON_metadata_including_worker_receipt',encoded_and_logical_cap_bytes=134217728)
diagnostic_limits=dict(limits,work=1000000,nodes=4096,edges=16384,roots=64,depth=32,scalar_bytes=1048576,wire_bytes=1048576,root_expanded_bytes=1048576,documents_expanded_bytes=1048576,materialized_bytes=1048576,materialized_occurrences=10000,cache_bytes=4096,cache_entries=256,chunk_bytes=4096)
profile['adapter_diagnostics']=dict(schema='owned-adapter-finite-diagnostic-profile-v1',cases=['tuple_projection_and_typed_paths','assembly_repeated_roots_and_full_canonical_body','foreign_callback_exception_identity','callback_reentrancy_fails_closed','failed_assembly_prefix_has_no_usable_output'],maximum_fresh_Stores=8,arena_limits=diagnostic_limits,adapter_limits=dict(operations=100000,value_bytes=1048576,depth=32,chunk_bytes=4096),scope='Small finite adapter boundary checks before original full001 proof pipeline; same original total work/peak/output caps, not a carrier benchmark or proof authority.')
names=dict(project,semantic_receiver_driver=components['receiver_driver'],bounded_request_oracle=components['bounded_transport'],**{aliases[k]:v for k,v in evidence.items()})
assert len(project)==22 and len(names)==28
schema_sources=oldclosure['schema_sources']
census=[]
for name,desc in {**names,**schema_sources,'__cold__':cold}.items():
 raw=Path(desc['path']).read_bytes();t=ast.parse(raw)
 imports=[];dynamic=[]
 for n in ast.walk(t):
  if isinstance(n,ast.Import):imports.extend(dict(module=a.name,kind='import',line=n.lineno) for a in n.names)
  elif isinstance(n,ast.ImportFrom):imports.append(dict(module=n.module,level=n.level,kind='from',line=n.lineno,names=[a.name for a in n.names]))
  elif isinstance(n,ast.Call) and ((isinstance(n.func,ast.Name) and n.func.id=='__import__') or (isinstance(n.func,ast.Attribute) and n.func.attr=='import_module')):
   dynamic.append(dict(line=n.lineno,argument=ast.dump(n.args[0],include_attributes=False) if n.args else None))
 census.append(dict(alias=name,source=desc,AST_sha256=hashlib.sha256(ast.dump(t,include_attributes=True).encode()).hexdigest(),imports=imports,dynamic_import_sites=dynamic))
required=('Z3','Z3_imports','external_imports','fixed_native_inputs','native_CPP','runtime','stdlib_entry_references','authoring_python')
closure={k:oldclosure[k] for k in required}
closure.update(schema='ROOT-owned-evidence-integration-raw-runtime-closure-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,scientific_acceptance=False,parent_closure=oldclosure['parent_closure'],previous_schema_closure=old['runtime_closure'],project_sources=project,additional_nonseed_components=components,evidence_sources=evidence,evidence_profile=profile,schema_sources=schema_sources,schema_kernel_source=oldclosure['schema_kernel_source'],materialized_aliases=names,current_scientific_alias_count=28,schema_extra_component_count=1,cold=cold,Source_AST_census=census,inherited_role_bindings=oldauth['review_roles'],review_scope='Current28+schema1+cold Source custody and adapter seams; inherited mathematical/search/consumer/certifier bodies retain earlier disclosed peer provenance and author overlap. No fresh independent certification of inherited algorithms, no scientific acceptance, and no authorization replay.',limitations=['AST census is static import evidence, not an activation seal or a complete OS loader proof.','Python/bundled stdlib and OS loader remain trusted runtime; exact cold runtime origins/callable identities remain mandatory.','All actual work, full saved forest inverse, full old result inverse, full point verification and Native checks charged inside original180 seconds; all terminal checks before210.'])
closurepin=save(D/'runtime-closure-v1.json',closure)
receiver_id='prospective-fol-20261018-001';capsule=load(old['declaration']['path']);selected=next(r for r in capsule['receivers'] if r['id']==receiver_id)
schedule=[dict(order=i+1,invocation_id='owned-evidence-001-'+mode+'-ROOT-20261019-v1',mode=mode,search_ordering='and_support',inventory_certification_mode='schema_then_native',model_storage='literal_interned',result_reader='interned',receiver_id=receiver_id,actual_directory=str(D/('actual-'+mode+'-v1'))) for i,mode in enumerate(('fixed','symbolic'))]
base=load(old['integration_declaration']['path'])
decl=dict(schema='ROOT-owned-evidence-integration-comparison-declaration-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,goal_complete=False,parent_structural_declaration=old['declaration'],runtime_closure=closurepin,selected_receiver_id=receiver_id,selected_receiver=selected,schedule=schedule,limits=base['limits'],evidence_profile=profile,result_reader='interned',model_storage='literal_interned',new_RL_training=False,conformance='Representation adapter only. Same complete point domains, t/m values, candidate graph, global dead/forced processing, earliest generation branching, rollback, actual Model inputs, original primitive rules and final Native gates. Specialized finite proof-region adaptation; no new complete shared-engine conformance theorem.',scope='Familiar original001 positive integration control only, not blind or new theorem evidence. Same input and full scientific gates in both arms. Evidence storage must not add proof authority. No ordinary-storage arm, carrier redesign benchmark, GCTS/RL benefit, or performance/saving claim.',source_gate='Three current exact Source/once/prospective scoped reviews plus separate Root fresh maximum-one grants. Review auth is descriptor/scope custody only; Root externally adopts precise scopes and inherited provenance. False metadata grants no execution.')
declpin=save(D/'case-declaration-v1.json',decl)
planroot=D/'plans-v1';manifest=[]
runnerlimits={'work_seconds':180,'overall_seconds':210,'aggregate_peak_bytes':1073741824,'stdout_bytes':4194304,'stderr_bytes':4194304,'result_bytes':134217728,'worker_receipt_bytes':4194304,'runner_plan_bytes':16777216,'failure_cleanup_seconds':5,'poll_milliseconds':20}
for row in schedule:
 w=dict(old);w.update({k:v for k,v in row.items() if k!='order'});w.update(schema='ROOT-owned-evidence-integration-worker-plan-v1',cold=cold,project_sources=project,components=components,runtime_closure=closurepin,integration_declaration=declpin)
 wp=save(planroot/'worker-plans'/(row['invocation_id']+'.json'),w)
 once=dict(schema='ROOT-owned-evidence-integration-once-plan-v1',**{k:v for k,v in row.items() if k!='order'},runner=runner,observer=observer,python=old['python'],cold=cold,worker_plan=wp,integration_declaration=declpin,runtime_closure=closurepin,authorization={'path':'NO_AUTHORIZATION_FALSE_PLAN','bytes':0,'sha256':'NO_AUTHORIZATION'},limits=runnerlimits,environment={'PYTHONHASHSEED':'0','LC_ALL':'C','LANG':'C'})
 op=save(planroot/'false-once-plans'/(row['invocation_id']+'.json'),once)
 manifest.append(dict(row=row,worker_plan=wp,false_once_plan=op))
mp=save(D/'false-plan-manifest-v1.json',dict(schema='ROOT-owned-evidence-false-plan-manifest-v1',author_identity='/root',source_only=True,scientific_calls=0,actual_execution_authorized=False,cold=cold,runner=runner,observer=observer,case_declaration=declpin,runtime_closure=closurepin,plans=manifest))
print(json.dumps(mp))
