from pathlib import Path
import ast,hashlib
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
p=D/'owned_evidence_once_runner_draft_v1.py';s=p.read_text()
s=s.replace("    need(declaration['evidence_sources']==evidence and declaration['evidence_storage']==closure['evidence_storage'] and\n         declaration['independent_evidence_inverse']==closure['independent_evidence_inverse'],\n         'complete current evidence declaration preimage joins')", "    need(declaration['evidence_profile']==closure['evidence_profile'] and\n         declaration['evidence_profile']['sources']==evidence,\n         'complete current evidence declaration preimage joins')")
a=s.index("        evidence_meta=worker_receipt['owned_evidence']");b=s.index("        need(worker_receipt['work_completed']",a)
s=s[:a]+"""        evidence_meta=worker_receipt['evidence_verification']
        need(type(evidence_meta)is dict and evidence_meta['schema']=='owned-evidence-saved-forest-verification-v1' and
             evidence_meta['status']=='COMPLETE' and evidence_meta['representation_only']is True and
             evidence_meta['mathematical_authority']is False and evidence_meta['forest']==pins['evidence_forest'] and
             worker_receipt['evidence_forest']==pins['evidence_forest'] and
             evidence_meta['completed_ns']<work_end and evidence_meta['logical_file_bytes']==len(result_raw) and
             worker_receipt['evidence_profile']==closure['evidence_profile'] and
             evidence_meta['statistics']['prepared']is True and
             evidence_meta['statistics']['logical_documents']==1 and
             evidence_meta['statistics']['aggregate_document_bytes']==len(result_raw) and
             evidence_meta['statistics']['documents']['receiver:complete-legacy-result']['completed']is True,
             'fresh independent complete saved-forest inverse metadata joins; no outer replay')
"""+s[b:]
a=s.index("        need(result['source_epoch']['evidence_storage']==closure['evidence_storage']");b=s.index("        schema_meta=",a)
s=s[:a]+"""        owned_evidence={}
        aliases={'adapter':'owned_evidence_adapter','arena':'exact_evidence_arena',
                 'join':'owned_inventory_join','inverse':'independent_forest_inverse'}
        for role,alias in aliases.items():
            desc=dict(closure['evidence_sources'][role],path=str(actual/'modules'/(alias+'.py')))
            read_pinned(desc,16777216,overall_end);owned_evidence[role]=desc
        profile=closure['evidence_profile']
        storage=dict(schema='owned-evidence-storage-declaration-v1',
            sources={role:owned_evidence[role] for role in ('adapter','arena','join')},
            arena_limits=profile['arena_limits'],adapter_limits=profile['adapter_limits'],
            logical_output='complete-legacy-JSON-body-plus-LF',
            unfinished_storage='NO_COMPLETE_RESULT_NO_PROOF_OR_RESOURCE_ADMISSION')
        inverse=dict(schema='owned-evidence-independent-inverse-declaration-v1',
            original=closure['evidence_sources']['inverse'],owned=owned_evidence['inverse'],
            version=profile['inverse_version'],execution_profile=profile['inverse_execution_profile'],
            limits=profile['inverse_limits'],sole_document='receiver:complete-legacy-result',
            stream='BODY-only-plus-one-external-LF',authority='representation-only; no Native or mathematical acceptance')
        need(result['source_epoch']['evidence_storage']==storage and
             result['source_epoch']['independent_evidence_inverse']==inverse and
             evidence_meta['declaration']==inverse,
             'full current owned storage and independent inverse epoch joins')
"""+s[b:]
p=D/'owned_evidence_once_runner_draft_v2.py';p.write_text(s);ast.parse(s);compile(s,str(p),'exec')
p0=D/'observe_owned_evidence_runner_draft_v1.py';t=p0.read_text().replace("receipt['worker_receipt']['owned_evidence']['fresh_independent_inverse_completed']is True and\n            receipt['worker_receipt']['owned_evidence']['literal_full_result_bytes_equal']is True", "receipt['worker_receipt']['evidence_verification']['status']=='COMPLETE' and\n            receipt['worker_receipt']['evidence_verification']['mathematical_authority']is False")
p2=D/'observe_owned_evidence_runner_draft_v2.py';p2.write_text(t);ast.parse(t);compile(t,str(p2),'exec')
for q in (p,p2):
 raw=q.read_bytes();print(dict(path=str(q),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
print('Unused compile only; no evaluation.')
