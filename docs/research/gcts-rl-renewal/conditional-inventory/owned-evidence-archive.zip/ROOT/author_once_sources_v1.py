from pathlib import Path
import ast,hashlib,json
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
p=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019/schema_admission_once_runner_v1.py')
s=p.read_text()
replacements={
"VERSION = 'schema-admission-external-once-runner-v1'":"VERSION = 'owned-evidence-external-once-runner-v1'",
"PLAN_SCHEMA = 'ROOT-schema-admission-once-plan-v1'":"PLAN_SCHEMA = 'ROOT-owned-evidence-integration-once-plan-v1'",
"AUTH_SCHEMA = 'ROOT-schema-admission-once-authorization-v1'":"AUTH_SCHEMA = 'ROOT-owned-evidence-integration-once-authorization-v1'",
"WORKER_RECEIPT_SCHEMA = 'schema-admission-worker-receipt-v1'":"WORKER_RECEIPT_SCHEMA = 'owned-evidence-integration-worker-receipt-v1'",
"RECEIPT_SCHEMA = 'schema-admission-external-once-receipt-v1'":"RECEIPT_SCHEMA = 'owned-evidence-external-once-receipt-v1'",
"'ROOT-schema-admission-worker-plan-v1'":"'ROOT-owned-evidence-integration-worker-plan-v1'",
"'ROOT-schema-admission-raw-runtime-closure-v1'":"'ROOT-owned-evidence-integration-raw-runtime-closure-v1'",
"'ROOT-schema-admission-comparison-declaration-v1'":"'ROOT-owned-evidence-integration-comparison-declaration-v1'"
}
for a,b in replacements.items():
 assert a in s,a
 s=s.replace(a,b)
a=s.index('COLD_PIN = ');b=s.index('\nSCHEMA_SOURCES',a)
s=s[:a]+"COLD_PIN = {'path':'UNFROZEN_COLD_SOURCE','bytes':0,'sha256':'UNFROZEN'}"+s[b:]
a=s.index('REVIEW_ROLES = ');b=s.index('\n\n\nclass OnceRunnerError',a)
s=s[:a]+"REVIEW_ROLES = {\n 'current_components_Source':('owned-evidence-integration-components-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),\n 'once_Source':('owned-evidence-integration-once-typed-Source-review-v1','source_review_passed','/root/conventional_control_review'),\n 'prospective_plans':('owned-evidence-integration-prospective-plan-review-v1','prospective_review_passed','/root/conventional_control_review')}"+s[b:]
s=s.replace("'complete22project+2component worker intake')", "'complete22project+2component worker intake')\n    evidence=closure['evidence_sources']\n    need(type(evidence)is dict and set(evidence)=={'adapter','arena','join','inverse'},'complete four evidence Source roles')")
s=s.replace("    need(len(names)==24 and closure['schema']", "    names.update(owned_evidence_adapter=evidence['adapter'],exact_evidence_arena=evidence['arena'],\n                 owned_inventory_join=evidence['join'],independent_forest_inverse=evidence['inverse'])\n    need(len(names)==28 and closure['schema']")
s=s.replace("same full24 alias closure/native runtime intake", "same full28 alias closure/native runtime intake")
s=s.replace("    schedule=declaration['schedule'];ids=", "    need(plan['receiver_id']=='prospective-fol-20261018-001','frozen familiar original001 assertion; no rescue selector')\n    need(declaration['evidence_sources']==evidence and declaration['evidence_storage']==closure['evidence_storage'] and\n         declaration['independent_evidence_inverse']==closure['independent_evidence_inverse'],\n         'complete current evidence declaration preimage joins')\n    schedule=declaration['schedule'];ids=")
a=s.index('    roles=auth[\'review_roles\']');b=s.index('    checked={}',a)
s=s[:a]+"""    roles=auth['review_roles'];need(type(roles)is dict and set(roles)==set(REVIEW_ROLES),'exact three current scoped review roles with disclosed ancestry')
    closure=parse(read_pinned(plan['runtime_closure'],1048576,overall_end))
    minimum={
      'current_components_Source':list(worker['project_sources'].values())+list(worker['components'].values())+
          list(closure['evidence_sources'].values())+list(SCHEMA_SOURCES.values())+[plan['cold']],
      'once_Source':[plan['runner'],plan['observer']],
      'prospective_plans':[plan['integration_declaration'],plan['runtime_closure'],plan['worker_plan']]}
"""+s[b:]
# Strict proof-integrated saved forest metadata; the mathematical inverse executes only in the cold worker.
needle="        result=parse(result_raw)\n"
assert s.count(needle)==1
s=s.replace(needle,needle+"""        forest_path=actual/'evidence-forest.json'
        forest_raw=read_raw(forest_path,LIMITS['result_bytes'],overall_end);pins['evidence_forest']=pin_raw(forest_path,forest_raw)
        evidence_meta=worker_receipt['owned_evidence']
        need(type(evidence_meta)is dict and evidence_meta['schema']=='owned-evidence-integration-cold-check-v1' and
             evidence_meta['forest']==pins['evidence_forest'] and evidence_meta['result']==pins['result'] and
             evidence_meta['fresh_independent_inverse_completed']is True and
             evidence_meta['literal_full_result_bytes_equal']is True and
             evidence_meta['logical_document_labels']==['receiver:complete-legacy-result'] and
             evidence_meta['inverse_completed_ns']<work_end and
             evidence_meta['logical_bytes']==len(result_raw) and
             evidence_meta['evidence_sources']==closure['evidence_sources'],
             'fresh independent complete saved-forest inverse metadata joins; no outer replay')
        need(worker_receipt['work_completed']is True and terminal_ns<work_end,
             'complete storage and known worker exit before180 for every admitted output')
        metadata=[]
        for entry in sorted(actual.iterdir(),key=lambda x:x.name):
            need(not entry.is_symlink(),'owned output ledger forbids symlinks')
            if entry.suffix=='.json' and entry not in (result_path,forest_path):
                raw=read_raw(entry,LIMITS['worker_receipt_bytes'],overall_end)
                metadata.append(pin_raw(entry,raw))
        # Conservative future metadata reservations cover the complete final runner
        # receipt (including embedded worker metadata) and observer outputs without a
        # self-hash cycle. Logs have their separate complete4MiB gates.
        physical_upper=len(result_raw)+len(forest_raw)+sum(d['bytes'] for d in metadata)+8388608+1048576
        need(physical_upper<=LIMITS['result_bytes'],'forest+ordinary result+all metadata under128MiB, including reserved terminal metadata')
        pins['physical_output_budget']={'schema':'owned-evidence-conservative-output-ledger-v1',
            'metadata':metadata,'runner_receipt_reserved_bytes':8388608,
            'observer_metadata_reserved_bytes':1048576,'conservative_physical_bytes':physical_upper,
            'logical_bytes':len(result_raw),'limit_bytes':LIMITS['result_bytes']}
""")
s=s.replace("        schema_meta=worker_receipt['schema_admission']", "        need(result['source_epoch']['evidence_storage']==closure['evidence_storage'] and\n             result['source_epoch']['independent_evidence_inverse']==closure['independent_evidence_inverse'],\n             'full current owned storage and inverse epoch joins')\n        schema_meta=worker_receipt['schema_admission']")
s=s.replace("    final_pin=write_new(actual/'runner-receipt.json',canonical(receipt)+b'\\n');postwrite=_NOW()", "    final_raw=canonical(receipt)+b'\\n'\n    need(len(final_raw)<=8388608,'complete final runner receipt within reserved8MiB')\n    final_pin=write_new(actual/'runner-receipt.json',final_raw);postwrite=_NOW()")
path=D/'owned_evidence_once_runner_draft_v1.py';path.write_text(s)
ast.parse(s);compile(s,str(path),'exec')
obs=Path('/private/tmp/gcts-schema-admission-ROOT-source-20261019/observe_schema_admission_runner_v1.py').read_text()
obs=obs.replace('schema-admission-final-terminal-observer-v1','owned-evidence-final-terminal-observer-v1').replace('ROOT-schema-admission-once-plan-v1','ROOT-owned-evidence-integration-once-plan-v1')
obs=obs.replace('599708c22bba2ebb395bf22819026f3185cf975523450754bc04612fd20c2814','UNFROZEN_RUNNER_SOURCE')
obs=obs.replace("    raw=json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\\n'", "    raw=json.dumps(value,sort_keys=True,indent=2,allow_nan=False).encode()+b'\\n'\n    need(len(raw)<=1048576,'whole observer metadata within reserved1MiB')")
obs=obs.replace("            receipt['plan']==pin(path,raw)", "            receipt['outputs']['physical_output_budget']['conservative_physical_bytes']<=134217728 and\n            receipt['worker_receipt']['owned_evidence']['fresh_independent_inverse_completed']is True and\n            receipt['worker_receipt']['owned_evidence']['literal_full_result_bytes_equal']is True and\n            receipt['plan']==pin(path,raw)")
opath=D/'observe_owned_evidence_runner_draft_v1.py';opath.write_text(obs)
ast.parse(obs);compile(obs,str(opath),'exec')
for q in (path,opath):
 raw=q.read_bytes();print(dict(path=str(q),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
print('Two unused compile objects only; no Source evaluation or component calls.')
