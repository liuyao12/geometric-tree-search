"""Presentation of saved ordinary rows only; no proof validation or component use."""
from pathlib import Path
import json,hashlib
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019')
p=D/'actual-symbolic-v1/result.json';raw=p.read_bytes();v=json.loads(raw);saved=v['outputs']['final_request'];proof=saved['proof'];assert len(proof)==12
# Literal display strings for the full12 saved rows; validity authority remains
# the separately admitted Native/current point/representation receipts.
tex=[r'P(a)',r'a=b',r'(a=b)\to(P(a)\to P(b))',r'P(a)\to P(b)',r'P(b)',r'a=a',r'(a=b)\to((a=a)\to(a=b))',r'(a=a)\to(a=b)',r'(a=b)\to((a=b)\to(b=b))',r'(a=b)\to(b=b)',r'b=b',r'P(b)']
english=['Use the given predicate hypothesis.','Use the given equality hypothesis.','Instantiate equality substitution for the predicate.','Apply reusable block B3 to displayed rows3 and2.','Apply reusable block B4 to displayed rows4 and1.','Use reflexivity of equality.','Instantiate equality substitution with the left term held fixed.','Apply reusable block B1 to displayed rows7 and2.','Instantiate equality substitution with the right term held fixed.','Apply reusable block B2 to displayed rows9 and2.','Apply reusable block B5 to displayed rows8,10 and6.','Apply reusable block B4 again to displayed rows4 and1; end at the target.']
# Independent literal syntax-to-display correspondence assertions for this one
# saved example, not a reusable codec, inverse, prover, or soundness check.
a=['fun','a',[]];b=['fun','b',[]];pa=['pred','P',[a]];pb=['pred','P',[b]];ab=['eq',a,b];aa=['eq',a,a];bb=['eq',b,b]
expected=[pa,ab,['imp',ab,['imp',pa,pb]],['imp',pa,pb],pb,aa,['imp',ab,['imp',aa,ab]],['imp',aa,ab],['imp',ab,['imp',ab,bb]],['imp',ab,bb],bb,pb]
assert [s['formula'] for s in proof]==expected
assert [s['rule'] for s in proof]==['axiom','axiom','eq_subst','block','block','refl','eq_subst','block','eq_subst','block','block','block']
blocklabels={d['name']:'B'+str(i+1) for i,d in enumerate(saved['blocks'])}
assert [blocklabels.get(s.get('name')) for s in proof if s['rule']=='block']==['B3','B4','B1','B2','B5','B4']
rows=[dict(displayed_row=i+1,formula_latex=tex[i],english=english[i],saved_step=s,literal_json=json.dumps(s,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)) for i,s in enumerate(proof)]
out=dict(schema='ROOT-saved-symbolic-proof-presentation-v1',saved_data_only=True,proof_replay=False,mathematical_authority=False,source_result=dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),full_proof_row_count=12,rows=rows,blocks=[dict(display_label=blocklabels[d['name']],saved_block=d,literal_json=json.dumps(d,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)) for d in saved['blocks']],scope='All12 saved final-request rows, displayed with one-based row numbers; source inputs retain zero-based indices. Exact original formulas/rules/block labels were checked as ordinary JSON data. Target first appears at displayed row5; the frozen12-row profile retains additional steps and returns to the target at row12. No proof shortening, new theorem, validation call, or search replay.')
p=D/'saved-proof-presentation-v1.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
