from pathlib import Path
import ast
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019');p=D/'build_integration_report_v1.py';s=p.read_text()
needle="jsonraw=json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)"
extra="""proof=v['saved_proof_presentation']
proofrows=''.join('<tr><th>'+math(str(r['displayed_row']))+'</th><td>'+math(r['formula_latex'])+'</td><td>'+esc(r['english'])+'<details><summary>Saved step</summary><pre>'+esc(r['literal_json'])+'</pre></details></td></tr>' for r in proof['rows'])
blocks=''.join('<details><summary>Reusable block '+esc(b['display_label'])+'</summary><pre>'+esc(b['literal_json'])+'</pre></details>' for b in proof['blocks'])
timing=v['symbolic_timing'];total=timing['external_terminal_seconds'];spans=[timing['scientific_stop_seconds'],timing['driver_return_seconds']-timing['scientific_stop_seconds'],total-timing['driver_return_seconds']]
timeline=''.join('<span style="width:'+str(100*x/total)+'%;background:'+c+'"></span>' for x,c in zip(spans,['#12666a','#7350a2','#b17a24']))
"""
assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace('section{margin-top:58px;', '.timeline{height:46px;display:flex;margin:25px 0 12px;border:1px solid var(--line)}.time-legend{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;font-size:15px}.time-legend b{display:block}.time-legend p{margin-top:5px}.proof-table{min-width:980px}.proof-table pre{max-width:500px}section{margin-top:58px;')
s=s.replace('.cards{grid-template-columns:1fr}.path', '.cards,.time-legend{grid-template-columns:1fr}.path')
s=s.replace('<a href="#reader">Inspect records</a>', '<a href="#proof">Saved proof</a><a href="#reader">Inspect records</a>')
needle='<section id="design">'
extra=r'''<section id="timing"><p class="eyebrow">Successful symbolic control only</p><h2>Evidence closure dominates the observed run.</h2><div class="timeline" role="img" aria-label="Symbolic timeline: scientific phase52.60 seconds, driver closure103.69 seconds, remaining checks and external terminal19.73 seconds">TIMELINE</div><div class="time-legend"><article><b>Scientific phase</b><p>\(52.60\,\mathrm{s}\), through the recorded scientific stop.</p></article><article><b>Driver output and closure</b><p>\(103.69\,\mathrm{s}\), through driver return. Includes assembly, export, streams, and guards.</p></article><article><b>Remaining checks and terminal</b><p>\(19.73\,\mathrm{s}\), including the fresh inverse, result reading, and final checks.</p></article></div><p class="note">The independent saved inverse takes \(11.239\,\mathrm{s}\). The earlier field named <code>decode_seconds</code> includes that inverse; it is not isolated parser time. The unpartitioned oracle-close-to-forest-serialization envelope is \(81.065\,\mathrm{s}\). These observations do not identify a causal optimization or predict its benefit. No complete inverse timing survives for the fixed arm.</p></section>
<section id="proof"><p class="eyebrow">Admitted symbolic result · Full saved row sequence</p><h2>The discovered proof, line by line.</h2><p>This is the machine-selected final request for the familiar assertion, presented in formulas and English. Displayed row numbers start at \(1\); the raw saved indices start at \(0\). Reusable blocks have display labels <code>B1</code> through <code>B5</code>, in the order stored in the request.</p><div class="table-wrap"><table class="proof-table"><thead><tr><th>Row</th><th>Formula</th><th>Reading and saved step</th></tr></thead><tbody>PROOFROWS</tbody></table></div><p>The target first appears at displayed row \(5\). The frozen \(12\)-row profile retains extra derivations and returns to the target in its final row; this report preserves all of them. Translation is presentation only. Validity comes from the admitted proof pipeline.</p><h3>Expand the stored reusable blocks</h3>BLOCKS</section>
'''
assert needle in s;s=s.replace(needle,extra+needle)
s=s.replace('<h2>What this establishes—and what remains.</h2>','<h2>What the milestone establishes.</h2>')
s=s.replace("'LIMITS':science,'JSON':esc(jsonraw)","'LIMITS':science,'JSON':esc(jsonraw),'PROOFROWS':proofrows,'BLOCKS':blocks,'TIMELINE':timeline")
p2=D/'build_integration_report_v2.py';p2.write_text(s);ast.parse(s);compile(s,str(p2),'exec');print('Updated publication builder only; no rendering/component or research Source execution.')
