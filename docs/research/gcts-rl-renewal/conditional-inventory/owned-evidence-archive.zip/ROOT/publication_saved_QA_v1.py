from pathlib import Path
from html.parser import HTMLParser
import json,hashlib
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019');P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
class ProofHTML(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.section=None;self.pre=False;self.text=[];self.pres=[];self.summaries=[];self.summary=False;self.summarytext=[];self.rows=0
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='section':self.section=a.get('id')
  if self.section=='proof' and tag=='pre':self.pre=True;self.text=[]
  if self.section=='proof' and tag=='tr':self.rows+=1
  if tag=='summary':self.summary=True;self.summarytext=[]
 def handle_endtag(self,tag):
  if tag=='pre' and self.pre:self.pres.append(''.join(self.text));self.pre=False
  if tag=='summary':self.summaries.append(''.join(self.summarytext));self.summary=False
  if tag=='section':self.section=None
 def handle_data(self,data):
  if self.pre:self.text.append(data)
  if self.summary:self.summarytext.append(data)
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
v=json.loads((D/'ROOT-integration-outcome-v1.json').read_bytes());s=(P/'owned-evidence.html').read_text();h=ProofHTML();h.feed(s);proof=v['saved_proof_presentation'];expected=[r['literal_json']for r in proof['rows']]+[b['literal_json']for b in proof['blocks']]
assert h.pres==expected and h.rows==13
assert h.summaries.count('Full outcome JSON')==1 and h.summaries.count('Saved step')==12
assert json.loads((P/'owned-evidence-summary.json').read_bytes())==v
assert 'PROOFROWS'not in s and '<tbody>PROOF'not in s
assert 'Diagnostic sum; no resource admission.'in s
assert s.count('id="owned-evidence"')==0
assert json.loads((P/'owned-evidence-next-design.json').read_bytes())==json.loads(Path('/private/tmp/gcts-owned-evidence-integration-library-20261019/post-actual-next-design-v1.json').read_bytes())
# The two existing pages differ only by one precisely bounded insertion each.
old=(D/'prior-publication/reader.html').read_text();new=(P/'reader.html').read_text();start=new.index('<section id="owned-evidence">');end=new.index('<section id="exact-evidence">',start);assert new[:start]+new[end:]==old
old=(D/'prior-publication/exact-evidence.html').read_text();new=(P/'exact-evidence.html').read_text();start=new.index('<aside class="boundary"><b>Next milestone:</b>');end=new.index('<section id="outcome">',start);assert new[:start]+new[end:]==old
preserved=[]
for desc in json.loads(Path('/private/tmp/gcts-direct-reconcile-ROOT-20261019/publication-candidate-v3.json').read_bytes())['files']:
 p=Path(desc['path'])
 if p.name not in ('reader.html','exact-evidence.html'):assert pin(p)==desc;preserved.append(desc)
qa=dict(schema='ROOT-owned-evidence-publication-saved-QA-v1',saved_data_only=True,scientific_calls=0,mathematical_replay=False,passed=True,proof_rows_exact=12,stored_blocks_exact=5,all17_HTML_literal_packets_equal=True,correct_outcome_summary_label=True,both_existing_pages_only_precise_insertions=True,unchanged_prior_files=preserved,current_HTML=pin(P/'owned-evidence.html'),negative_preview='An early placeholder collision substituted outcome rows for PROOFROWS and expanded JSON in the summary label. The corrected one-pass template preserves each literal payload; no actual inputs/results were changed.',scope='Publisher HTML/ordinary metadata only; independent Source/current actual receipts supply scientific evidence.')
p=D/'publication-saved-QA-v1.json';assert not p.exists();p.write_text(json.dumps(qa,sort_keys=True,indent=2)+'\n');print(pin(p))
