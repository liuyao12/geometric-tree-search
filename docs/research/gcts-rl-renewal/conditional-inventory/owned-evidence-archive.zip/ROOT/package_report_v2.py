"""Explicit frozen archive of current research evidence; no replay."""
from pathlib import Path
import json,hashlib,zipfile,stat
D=Path('/private/tmp/gcts-owned-evidence-integration-ROOT-20261019');L=Path('/private/tmp/gcts-owned-evidence-integration-library-20261019');C=Path('/private/tmp/gcts-owned-evidence-integration-peer-20261019');P=Path('/private/tmp/gcts-split-controls-publish-20261015/docs/research/gcts-rl-renewal/conditional-inventory')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=[]
for label,root in [('ROOT',D),('library',L),('peer',C)]:
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if rel.parts[0] in ('prior-publication','__pycache__') or '__pycache__'in rel.parts:continue
  assert not p.is_symlink();files.append((label+'/'+str(rel),p))
worker=json.loads((D/'plans-v1/worker-plans/owned-evidence-001-symbolic-ROOT-20261019-v1.json').read_bytes());closure=json.loads(Path(worker['runtime_closure']['path']).read_bytes())
extras={**closure['evidence_sources'],'kernel':closure['schema_kernel_source'],'assertion':worker['declaration'],'policy':worker['policy'],'parent_closure':closure['parent_closure'],**worker['native_inputs']}
for label,desc in extras.items():
 p=Path(desc['path']);assert pin(p)==desc;files.append(('dependencies/'+label+'/'+p.name,p))
assert len({n for n,p in files})==len(files)
members=[dict(member=n,source=pin(p)) for n,p in files]
freeze=dict(schema='ROOT-owned-evidence-explicit-archive-members-v1',saved_data_only=True,scientific_calls=0,member_count=len(members),members=members,scope='Exact member list frozen after both agent outcome/design handoffs. Later publication QA/live records are outside this archive. Previous carrier qualification remains in its already published archive; large Python/Z3/OS runtime artifacts are pinned but not bundled.')
mp=D/'frozen-archive-members-v2.json';assert not mp.exists();mp.write_text(json.dumps(freeze,sort_keys=True,indent=2)+'\n')
archive=P/'owned-evidence-archive.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for item,(name,p) in zip(members,files):
  raw=p.read_bytes();assert pin(p)==item['source'];z.writestr(name,raw)
 z.writestr('ARCHIVE-MEMBERS.json',mp.read_bytes())
 z.writestr('README.txt','Saved research evidence only. Both actual subjects are consumed; this archive grants no replay. The symbolic control passed complete finite integration; fixed GCTS failed its independent reconstruction work window. Read the outcome and explicit trust/review limits. Runtime bytes not bundled are identified by complete raw pins. No new theorem, performance, GCTS or RL benefit is established.\n')
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for item in members:
  raw=z.read(item['member']);assert len(raw)==item['source']['bytes'] and hashlib.sha256(raw).hexdigest()==item['source']['sha256']
manifest=dict(schema='owned-evidence-publication-manifest-v1',member_count=len(members)+2,archive=pin(archive),frozen_members=pin(mp),members=members,goal_complete=False,saved_data_only=True,scientific_calls=0)
(P/'owned-evidence-manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
(P/'owned-evidence-next-design.json').write_bytes((L/'post-actual-next-design-v1.json').read_bytes())
owned=['owned-evidence.html','owned-evidence-summary.json','owned-evidence-manifest.json','owned-evidence-archive.zip','owned-evidence-next-design.json','exact-evidence.html','reader.html']
candidate=dict(schema='ROOT-owned-evidence-publication-candidate-v2',goal_complete=False,saved_data_only=True,scientific_calls=0,files=[pin(P/name)for name in owned],archive_member_count=len(members)+2)
cp=D/'publication-candidate-v2.json';assert not cp.exists();cp.write_text(json.dumps(candidate,sort_keys=True,indent=2)+'\n');print(json.dumps(pin(cp)));print(json.dumps(dict(archive=pin(archive),raw_member_bytes=sum(d['source']['bytes']for d in members),member_count=len(members)+2)))
