from pathlib import Path
import ast,symtable,hashlib,json,builtins,sys
R=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L');O=Path('/private/tmp/gcts-B-NTM-Wang-Source-peer-20261027-v1')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def sh(s):return hashlib.sha256(s.encode()).hexdigest()
hp=R/'finite-NTM-Wang-compiler-complete-inert-Source-handoff-v1.json';h=json.loads(hp.read_text());refs=[h['Source'],h['complete_public_ABI'],h['complete_static_helper_branchwalk'],h['complete_walkthrough'],h['prefrozen_public_ABI'],h['static_two_way_argument']]
for r in refs:assert pin(Path(r['path']))==r
p=Path(h['Source']['path']);s=p.read_text();tree=ast.parse(s,filename=str(p));lines=s.splitlines(keepends=True);own=[]
def walk(n,prefix):
 for c in ast.iter_child_nodes(n):
  if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
   name='.'.join(prefix+[c.name]);raw=''.join(lines[c.lineno-1:c.end_lineno]);own.append({'name':name,'kind':type(c).__name__,'line':c.lineno,'end_line':c.end_lineno,'raw_bytes':len(raw.encode()),'raw_sha256':sh(raw),'AST_sha256':sh(ast.dump(c,include_attributes=False)),'positioned_AST_sha256':sh(ast.dump(c,include_attributes=True)),'signature':ast.unparse(c.args)if hasattr(c,'args')else None,'complete_descendant_callset':sorted({ast.unparse(q.func)for q in ast.walk(c)if isinstance(q,ast.Call)})});walk(c,prefix+[c.name])
  else:walk(c,prefix)
walk(tree,[])
sup=json.loads(Path(h['complete_static_helper_branchwalk']['path']).read_text());by={x['name']:x for x in sup['definitions']};assert len(own)==len(by)==25
for x in own:
 for k in ['kind','line','end_line','raw_bytes','raw_sha256','AST_sha256','positioned_AST_sha256','complete_descendant_callset']:assert x[k]==by[x['name']][k],(x['name'],k)
assert sh(ast.dump(tree,include_attributes=False))==sup['whole_AST_sha256'] and sh(ast.dump(tree,include_attributes=True))==sup['whole_positioned_AST_sha256']
scopes=[]
def sy(st,path='module'):
 es=[]
 for name in sorted(st.get_identifiers()):
  q=st.lookup(name);es.append({'name':name,'parameter':q.is_parameter(),'referenced':q.is_referenced(),'assigned':q.is_assigned(),'global':q.is_global(),'local':q.is_local(),'free':q.is_free(),'nonlocal':q.is_nonlocal(),'imported':q.is_imported()})
 scopes.append({'path':path,'type':st.get_type(),'line':st.get_lineno(),'complete_entries':es})
 for i,c in enumerate(st.get_children()):sy(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
sy(symtable.symtable(s,str(p),'exec'));assert len(scopes)==sup['scope_count']==27
imports=[ast.unparse(n)for n in ast.walk(tree)if isinstance(n,(ast.Import,ast.ImportFrom))];assert imports==['import hashlib','import json']
bodycalls=[]
for n in tree.body:
 if not isinstance(n,(ast.FunctionDef,ast.ClassDef)):bodycalls.extend(ast.unparse(q.func)for q in ast.walk(n)if isinstance(q,ast.Call))
assert not bodycalls
co=compile(s,str(p),'exec',dont_inherit=True,optimize=0);del co
br={kind.__name__:sum(isinstance(n,kind)for n in ast.walk(tree))for kind in [ast.If,ast.For,ast.ExceptHandler]}
x={'schema':'B-finite-NTM-Wang-complete-independent-static-Source-joins-v1','status':'PASS_STATIC_ONLY','Source':pin(p),'full_packet_joins':refs,'own_all25definitions':own,'own_all27symbol_scopes':scopes,'whole_raw_AST_positioned_hashes_and_all_helper_callsets_match':True,'branch_counts':br,'imports':imports,'module_body_calls':bodycalls,'unusedcompile':'PASS; no subject execution','subject_calls':0,'Source_snapshot_public_machine_mismatch':'B1 accept:string was incompatible with this declared accept:list; B1 unchanged/unrun/superseded, Root authorized B2 independently. Not a defect in L current Source.','execution_authorized':False}
p=O/'finite-NTM-Wang-complete-independent-static-Source-joins-v1.json';p.write_text(json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n');print(json.dumps({'support':pin(p),'branches':br,'definitions':len(own),'scopes':len(scopes)},sort_keys=True))
