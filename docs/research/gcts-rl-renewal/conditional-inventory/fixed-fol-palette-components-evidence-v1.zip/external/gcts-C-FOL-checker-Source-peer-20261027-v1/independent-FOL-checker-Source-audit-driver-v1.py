"""Administrative Source audit only; never imports or executes subject code."""
import ast
import builtins
import hashlib
import json
import pathlib
import symtable
import sys

N = pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
B = N / 'implementation-B'
OUT = pathlib.Path('/private/tmp/gcts-C-FOL-checker-Source-peer-20261027-v1')
RUNTIME = pathlib.Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def encode(value):
    return (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def pin(path):
    raw = pathlib.Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}

def write(name, value):
    path = OUT / name
    with path.open('xb') as handle:
        handle.write(encode(value))
    return pin(path)

source_path = B / 'independent_fol_checker_v1.py'
raw = source_path.read_bytes()
assert len(raw) == 21560 and digest(raw) == '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'
text = raw.decode('utf-8')
root = ast.parse(text, filename=str(source_path))
lines = raw.splitlines(keepends=True)
hand_path = B / 'independent-fol-checker-complete-inert-Source-handoff-v1.json'
hand = json.loads(hand_path.read_bytes())
ledger_path = B / 'independent-fol-checker-complete-static-branch-helper-ledger-v1.json'
ledger = json.loads(ledger_path.read_bytes())
api_path = B / 'independent-fol-checker-complete-effective-public-ABI-v2.json'
api = json.loads(api_path.read_bytes())
api1_path = B / 'independent-fol-checker-complete-public-ABI-v1.json'
api1 = json.loads(api1_path.read_bytes())
walk_path = B / 'independent-fol-checker-complete-Source-walkthrough-v1.json'
walk = json.loads(walk_path.read_bytes())
all_packet_pins = [pin(source_path), pin(hand_path)]
assert hand['Source'] == pin(source_path)
for claimed in hand['complete_packet']:
    actual = pin(claimed['path'])
    assert claimed == actual, claimed['path']
    all_packet_pins.append(actual)

rows = []
def collect(container, prefix=''):
    for node in container.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        name = prefix + node.name
        branches = []
        for child in ast.walk(node):
            if isinstance(child, ast.If):
                branches.append({'kind': 'if', 'line': child.lineno, 'condition': ast.unparse(child.test)})
            elif isinstance(child, (ast.For, ast.AsyncFor, ast.While)):
                expr = child.test if isinstance(child, ast.While) else child.iter
                branches.append({'kind': type(child).__name__, 'line': child.lineno, 'condition_or_iterator': ast.unparse(expr)})
            elif isinstance(child, ast.ExceptHandler):
                branches.append({'kind': 'except', 'line': child.lineno, 'exception': None if child.type is None else ast.unparse(child.type)})
        body = b''.join(lines[node.lineno - 1:node.end_lineno])
        rows.append({'name': name, 'kind': type(node).__name__, 'line': node.lineno, 'end_line': node.end_lineno,
                     'raw_bytes': len(body), 'raw_sha256': digest(body),
                     'AST_sha256': digest(ast.dump(node).encode()),
                     'positioned_AST_sha256': digest(ast.dump(node, include_attributes=True).encode()),
                     'signature': ast.unparse(node.args) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) else None,
                     'complete_descendant_callset': sorted({ast.unparse(child.func) for child in ast.walk(node) if isinstance(child, ast.Call)}),
                     'complete_descendant_branch_inventory': branches})
        if isinstance(node, ast.ClassDef):
            collect(node, name + '.')
collect(root)
assert rows == ledger['all_definitions']
assert len(rows) == 30
assert len(lines) == ledger['complete_Source_lines'] == 527
assert digest(ast.dump(root).encode()) == ledger['whole_AST_sha256']
assert digest(ast.dump(root, include_attributes=True).encode()) == ledger['whole_positioned_AST_sha256']
assert sorted(name for group in walk['complete_all30definition_walkthrough'] for name in group['names']) == sorted(row['name'] for row in rows)

table = symtable.symtable(text, str(source_path), 'exec')
scopes = []
all_scopes = []
flags = [('assigned', 'is_assigned'), ('free', 'is_free'), ('global', 'is_global'), ('imported', 'is_imported'),
         ('local', 'is_local'), ('nonlocal', 'is_nonlocal'), ('parameter', 'is_parameter'), ('referenced', 'is_referenced')]
def symbols(st, path):
    entries = []
    for name in sorted(st.get_identifiers()):
        symbol = st.lookup(name)
        entry = {'name': name}
        entry.update({key: getattr(symbol, method)() for key, method in flags})
        entries.append(entry)
    scopes.append({'path': path, 'line': st.get_lineno(), 'type': st.get_type(), 'complete_entries': entries,
                   'entries_sha256': digest(encode(entries))})
    all_scopes.append(st)
    for index, child in enumerate(st.get_children()):
        symbols(child, path + '/' + child.get_name() + ':' + str(child.get_lineno()) + ':' + str(index))
symbols(table, 'module')
assert scopes == ledger['all_symbol_scopes'] and len(scopes) == 41
module_defined = {name for name in table.get_identifiers() if table.lookup(name).is_assigned() or table.lookup(name).is_imported()}
unresolved = sorted({name for st in all_scopes for name in st.get_identifiers()
                     if st.lookup(name).is_global() and st.lookup(name).is_referenced()
                     and name not in module_defined and name not in vars(builtins)})
assert unresolved == ledger['unresolved_global_names'] == []
imports = [ast.unparse(node) for node in ast.walk(root) if isinstance(node, (ast.Import, ast.ImportFrom))]
module_calls = [ast.unparse(child) for node in root.body if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                for child in ast.walk(node) if isinstance(child, ast.Call)]
assert imports == ledger['imports'] == [] and module_calls == ledger['module_body_calls'] == []
public = [node.name for node in root.body if isinstance(node, ast.FunctionDef) and not node.name.startswith('_')]
assert public == ledger['only_public_function'] == ['check']
constants = {node.targets[0].id: ast.literal_eval(node.value) for node in root.body
             if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
assert constants['VERSION'] == api['VERSION'] == api1['VERSION']
assert constants['SCHEMA'] == api['receipt_schema'] == api1['receipt_schema']
assert list(constants['_LIMIT_FIELDS']) == api['limits_exact3'] == api1['limits_exact3']
rule_fields = {name: list(fields) for name, fields in constants['_RULE_FIELDS']}
assert rule_fields == ledger['exact8rule_payloads'] == api['rule_exact_fieldsets'] == api1['rule_exact_fieldsets']
reasons = sorted({node.args[0].value for node in ast.walk(root) if isinstance(node, ast.Call)
                  and isinstance(node.func, ast.Name) and node.func.id in ['_Invalid', '_Limit']
                  and node.args and isinstance(node.args[0], ast.Constant)})
assert reasons == ledger['own_invalidity_and_limit_reason_literals']
receipt = next(node for node in root.body if isinstance(node, ast.FunctionDef) and node.name == '_receipt')
receipt_return = next(node.value for node in ast.walk(receipt) if isinstance(node, ast.Return))
receipt_keys = [ast.literal_eval(node) for node in receipt_return.keys]
assert receipt_keys == api['receipt_exact9'] == api1['receipt_exact9']
visits_node = receipt_return.values[receipt_keys.index('visits')]
visits_keys = [ast.literal_eval(node) for node in visits_node.keys]
assert visits_keys == api['visits_exact5']
assert api['status_values'] == api1['status_values'] == ['VERIFIED', 'REJECTED', 'UNKNOWN_BUDGET']
assert all(node.name.startswith('_') or node.name == 'check' for node in root.body if isinstance(node, ast.FunctionDef))
assert not any(isinstance(node, (ast.Global, ast.Nonlocal)) for node in ast.walk(root))
code = compile(text, str(source_path), 'exec', dont_inherit=True, optimize=0)
del code
runtime_pin = pin(RUNTIME)
assert runtime_pin['bytes'] == 18058560 and runtime_pin['sha256'] == 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'
legacy_path = N / 'root/recovered-logical-Source-v1/logic.py'
legacy_raw = legacy_path.read_bytes()
assert len(legacy_raw) == 10808 and digest(legacy_raw) == '5e607e81c4231836e7c2f979f7f9673988e1c6326335dfb6cfc25a173169a011'
legacy_tree = ast.parse(legacy_raw, filename=str(legacy_path))
legacy_kernel = next(node for node in legacy_tree.body if isinstance(node, ast.ClassDef) and node.name == 'Kernel')
legacy_check = next(node for node in legacy_kernel.body if isinstance(node, ast.FunctionDef) and node.name == 'check')
legacy_rules = sorted({node.comparators[0].value for node in ast.walk(legacy_check)
                       if isinstance(node, ast.Compare) and isinstance(node.left, ast.Name) and node.left.id == 'r'
                       and len(node.comparators) == 1 and isinstance(node.comparators[0], ast.Constant)})
# Legacy uses a local spelling other than r in some releases; the complete body was also manually read.
master_path = N / 'root/basic-tiling-algorithm.current-published-master-v1.md'
master_pin = pin(master_path)
assert master_pin['bytes'] == 36240 and master_pin['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
prefreeze_path = N / 'independent-C/independent-FOL-checker-prefrozen-complete-Source-review-expectations-v1.json'
prefreeze_pin = pin(prefreeze_path)
assert prefreeze_pin['bytes'] == 2211 and prefreeze_pin['sha256'] == 'c2591c0fec10c47dd2e7737252ac33284ce274c18e212edaf6aa5904d203acec'
support = {
 'schema': 'C-independent-FOL-checker-complete-static-support-v1', 'decision': 'PASS',
 'subjects': all_packet_pins + [pin(legacy_path), master_pin, prefreeze_pin, runtime_pin],
 'runtime': {'executable': str(RUNTIME), 'version': sys.version, 'isolated': sys.flags.isolated, 'no_site': sys.flags.no_site, 'dont_write_bytecode': sys.dont_write_bytecode},
 'derivation': {'AST': 'sha256(UTF8(ast.dump(node)))', 'positioned_AST': 'same with include_attributes=True',
                'raw_definition': 'entire raw source lines lineno through end_lineno inclusive, including terminal newline and method indentation',
                'scope_entries': 'sorted identifiers with eight exact symtable flags; sha256(sorted-key ensure_ascii indent2 JSON plus LF)',
                'branches': 'ast.walk descendant If/For/While/ExceptHandler, in traversal order; short-circuit/IfExp/comprehension behavior additionally manually reviewed',
                'ledger_join': 'all 30 complete definition rows and all 41 complete scope rows compared structurally, not just producer digests'},
 'all_definitions': rows,
 'all_scope_joins': [{'path': x['path'], 'line': x['line'], 'type': x['type'], 'entry_count': len(x['complete_entries']), 'entries_sha256': x['entries_sha256'], 'all_entry_flags_equal': True} for x in scopes],
 'whole_AST_sha256': digest(ast.dump(root).encode()), 'whole_positioned_AST_sha256': digest(ast.dump(root, include_attributes=True).encode()),
 'all_packet_rawpins_match': True, 'definitions_equal': True, 'scopes_equal': True, 'walk_names_complete': True,
 'lines': len(lines), 'definition_count': len(rows), 'scope_count': len(scopes), 'imports': imports,
 'module_body_calls': module_calls, 'unresolved_globals': unresolved, 'public_functions': public,
 'rule_exact_fieldsets': rule_fields, 'limits_exact3': list(constants['_LIMIT_FIELDS']),
 'receipt_exact9': receipt_keys, 'visits_exact5': visits_keys, 'own_reason_literals': reasons,
 'unused_compile': 'PASS; code object immediately discarded and never executed',
 'legacy_comparison': {'rawpin_exact': True, 'complete_logic_py_manually_read': True, 'same_eight_logical_rule_names': sorted(rule_fields),
                       'legacy_kernel_check_AST_sha256': digest(ast.dump(legacy_check).encode()),
                       'scope_only_not_legacy_import_or_output_equivalence': True},
 'activity': {'subject_imports': 0, 'subject_function_or_constructor_calls': 0, 'subject_codeobject_execution': 0,
              'proofs_models_fixtures_tests': 0, 'CLI_or_help': 0, 'network': 0, 'publication': 0},
 'terminal_state': 'IDLE_AFTER_ADMIN_AUDIT'}
support_pin = write('independent-FOL-checker-complete-static-support-v1.json', support)
review = {
 'schema': 'C-independent-FOL-checker-complete-Source-peer-review-v1',
 'decision': 'PASS', 'required_changes': [], 'execution_authorized': False,
 'judgment': 'Complete bounded Source/calculus/ABI peer. No concrete soundness, wire-validation, resource-status, mutation, or packet-preservation blocker found. All subject functions remain unexecuted; this does not qualify runtime behavior.',
 'subjects': all_packet_pins + [pin(legacy_path), master_pin, prefreeze_pin, runtime_pin, support_pin],
 'coverage': {'Source_lines': 527, 'all_definitions': 30, 'all_symbol_scopes': 41, 'complete_body_read': True,
              'full_helper_manual_review': True, 'full_static_ledger_reproduced': True, 'rules': 8,
              'imports': 0, 'module_body_calls': 0, 'unresolved_globals': 0, 'public_functions': ['check'],
              'limits_fields': 3, 'receipt_fields': 9, 'visits_fields': 5, 'runtime_claims': 'UNRUN'},
 'soundness_argument': {
  'induction': r'For each successfully appended line, every nonempty classical one-sorted structure and assignment satisfying the supplied closed theory axioms satisfies that formula. Logical schemata are valid under every assignment, named axioms hold by assumption, modus ponens preserves truth, and universal generalization is valid because the theory has no free variables or untracked local assumptions. The last-line alpha comparison therefore entails derivability of the requested target relative to that theory.',
  'axiom': 'Uses only a named parsed closed axiom from the supplied map, modulo independently computed alpha-equivalence. It checks neither truth nor membership in a named mathematical theory.',
  'tautology': r'Equality, predicate and entire universal subformulas are Boolean atoms; alpha-equivalent atoms denote the same truth under every assignment. Exhaustively accepting all Boolean valuations of the skeleton implies validity of its FOL instance. Treating quantified formulas atomically can miss valid formulas but cannot accept an invalid instance. The zero-atom case is covered by the same one-valuation loop.',
  'refl': r'Only a parsed equality with identical internal term trees is admitted, yielding \(t=t\).',
  'instantiate': r'Checks the whole logical axiom \((\forall x\,\varphi)\to\varphi[t/x]\), using hygienic free substitution. It never asserts the instance alone merely because the universal appears as payload.',
  'distribute': r'Checks \(\forall x(p\to q)\to(p\to\forall x\,q)\), with the exact side condition \(x\notin\mathrm{FV}(p)\).',
  'eq_subst': r'Checks \(s=t\to(\varphi[s/x]\to\varphi[t/x])\), replacing only free occurrences with capture avoidance. This remains a logical equality axiom even when the replacement terms contain the substituted variable.',
  'mp': r'Both references must be earlier successfully checked lines; the earlier implication must have an antecedent alpha-equivalent to the referenced antecedent and consequent alpha-equivalent to the current formula.',
  'generalize': r'Checks the current formula against \(\forall x\,\psi\) for an earlier derived \(\psi\). Closed theory axioms and absence of local assumptions justify this rule without a separate sequent eigenvariable list. Allowing open assumptions later would require a new sound side-condition contract.'},
 'helper_review': [
  {'helpers': ['_Invalid','_Limit','_Budget','_Budget.__init__','_Budget.visit'], 'finding': 'Fresh call-local exception/counter state, depth and remaining-operation checks precede charged increments. Resource exhaustion has a distinct status; no unbounded subject callback exists.'},
  {'helpers': ['_limits','_name','_fields','_keys','_signature'], 'finding': 'Exact native types, nonempty literal names, three positive nonbool integer limits, nonnegative nonbool arities. Keys are checked before string membership/comparison. Signature namespaces are separate; ordering is deterministic and charged.'},
  {'helpers': ['_term','_formula'], 'finding': 'Exact list grammar and exact declared arities; finite syntax is rebuilt into private tuple trees. No symbol evaluation, executable interpretation or implicit sort inference.'},
  {'helpers': ['_term_free','_free','_names'], 'finding': 'Free-variable removal respects quantifier shadowing; the all-name traversal retains bound names needed to choose hygienic fresh identifiers.'},
  {'helpers': ['_term_replace','_rename_bound','_substitute'], 'finding': 'Replacement is simultaneous on free occurrences. Same-name binder stops substitution; colliding binders are renamed using a name absent from all body/replacement names; renaming stops at inner shadows. No nested binder or free-name capture was found.'},
  {'helpers': ['_term_key','_alpha','_tree_equal','_equivalent'], 'finding': 'Nearest-binder indices distinguish bound positions; free names and function/predicate symbols remain literal. Separate key tags prevent free/bound/function conflation. Exact internal-tree types/depth/strings are compared through charged visits.'},
  {'helpers': ['_skeleton','_truth','_tautology'], 'finding': 'Correct classical truth functions, first-encounter alpha atom identity, all-False vector and rightmost-bit enumeration; no exponential product allocation. Rejection requires a completed false valuation; incomplete enumeration is resource unknown.'},
  {'helpers': ['_prior','_line','_rule'], 'finding': 'Exact eight payload fieldsets, fully parsed independent parameters, strict earlier integer references and semantic formula comparison. No future/self DAG edges, implicit lemmas, untracked assumptions or arbitrary fallback rule are reachable.'},
  {'helpers': ['_receipt','check'], 'finding': 'Full theory closure/target/proof validation and final target equality precede VERIFIED. Exact nine fresh receipt fields and five visit fields; rejected or unknown prefix counters do not admit a partial proof. No caller writes or live return aliases.'}],
 'wire_error_resource_review': {
  'exact_types': 'Bool/subclass integers, tuple ASTs, wrong tags/arity, nonstring/empty names, extra/missing keys and illegal references are refused through own invalidity paths. Cyclic/deep Python objects cannot produce VERIFIED by skipping parse.',
  'order': 'Limits, theory/signature/closed axioms, target, proof shape/line ceiling, then ordered line parse and semantic checks, then final alpha target. Whichever invalidity/resource check is encountered first determines the return; there is no promised invalidity precedence over prior exhausted budget.',
  'statuses': 'Own _Invalid becomes REJECTED. Own operation/depth/proof-line limits and caught host RecursionError/MemoryError become UNKNOWN_BUDGET. Unexpected implementation exceptions propagate and cannot silently become a false proof or logical rejection.',
  'accounting': 'Grammar, names/characters, free/all-name sets, substitution/renaming/fresh search, alpha/binder lookup/equality, rule/reference, tautology atoms/valuations/truth/counter and final target are visited. This is the declared deterministic logical-work model, not an OS CPU/RSS/wall-clock or exact Python-instruction bound.',
  'memory_scope': 'Host exhaustion reporting requires enough resources to construct the receipt; no hard allocator-resilience or always-return guarantee is inferred. Failure to return is not proof acceptance.',
  'purity': 'No imports, IO, callbacks, executable name lookup, module calls or global/nonlocal writes. Exact primitive/container checks avoid dispatch on caller-defined methods; parsed data and returned counters/limits are detached. Concurrent caller mutation is expressly outside the contract.',
  'identity': 'Receipt does not hash its inputs. A later caller must separately associate the complete exact theory/proof/target/limits, Source/runtime and saved return; static peer supplies no invocation authority.'},
 'legacy_comparison': {
  'read_scope': 'Complete exact recovered logic.py only; no legacy helper calls and no wider repository absence claim.',
  'common_core': 'The same eight logical rule families, supplied closed axioms, free-variable/distribution hygiene, equality substitution, strict prior MP and generalization scope.',
  'intentional_differences': 'Legacy in-process tuple ASTs/exact structural formula comparison are replaced by exact JSON-list wire grammar/private tuples and sound alpha-equivalence. Legacy itertools.product tautology enumeration becomes a budgeted Boolean vector; explicit invalid/resource returns replace the older Boolean-only interface. These differences do not require raw output equality between the implementations.',
  'earlier_work': 'The ground forward equational search pilot in this one legacy file is not evidence that other already-published quantified cases/families lack proofs. Earlier results are neither erased nor requalified here.'},
 'master_and_research_limits': [
  'This is a generic closed-theory FOL certificate-validity component. It supplies no actual unknown-proof search controller or completed PA/Hilbert benchmark.',
  'No PA induction-schema membership, many-sorted geometry frontend, full Hilbert continuity, axiom consistency/truth or theorem discovery is established.',
  'Eight finite logical rule schemas are not a fixed finite literal Wang palette, a proof of faithful machine/tiling compilation, or actual tile-to-line decoding.',
  'No t/m candidate graph, earliest-generation search, cluster/RL mechanism, or measured performance is implemented or exercised by this checker. A later genuine GCTS proof-search lane must meet the current master independently.',
  'No tests/proofs/fixtures were instantiated or evaluated. Positive/negative/resource/mutation qualification and whole caller/once evidence remain separate required work, not Source-peer achievements.'
 ],
 'activity': support['activity'], 'terminal_state': 'IDLE', 'grant_or_publication': None}
review_pin = write('independent-FOL-checker-complete-Source-peer-review-v1.json', review)
print(json.dumps({'support': support_pin, 'review': review_pin, 'terminal_state': 'IDLE'}, sort_keys=True))
