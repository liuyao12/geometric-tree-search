"""Administrative Source/AST audit only; no publisher or gh invocation."""
import ast
import builtins
import hashlib
import json
import pathlib
import symtable

B=pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L')
O=pathlib.Path('/private/tmp/gcts-C-fixed-fol-publisher-Source-peer-20261027-v1')
def enc(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(n,x):
 p=O/n
 with p.open('xb') as f:f.write(enc(x))
 return pin(p)
sp=B/'publish_fixed_fol_palette_components_api_v1.py';raw=sp.read_bytes();assert len(raw)==26498 and sha(raw)=='feae675502681f0527e34d8ba83a4de08dc027df4116075712075741bdc313cd'
hp=B/'fixed-fol-palette-components-publisher-complete-inert-Source-handoff-v1.json';handoff=json.loads(hp.read_bytes());subjects=[pin(sp),pin(hp)]
for key in ['public_ABI','complete_manual','complete_static']:
 ref=handoff[key];assert pin(ref['path'])==ref;subjects.append(ref)
a=json.loads(pathlib.Path(handoff['public_ABI']['path']).read_bytes());m=json.loads(pathlib.Path(handoff['complete_manual']['path']).read_bytes());l=json.loads(pathlib.Path(handoff['complete_static']['path']).read_bytes())
t=ast.parse(raw,filename=str(sp));lines=raw.splitlines(keepends=True);rows=[]
def scan(n,prefix=''):
 for x in n.body:
  if isinstance(x,(ast.FunctionDef,ast.ClassDef)):
   name=prefix+x.name;b=b''.join(lines[x.lineno-1:x.end_lineno]);branches=[]
   for z in ast.walk(x):
    if isinstance(z,(ast.If,ast.While,ast.IfExp,ast.For,ast.Try,ast.ExceptHandler)):
     test=ast.unparse(z.test) if isinstance(z,(ast.If,ast.While,ast.IfExp)) else ast.unparse(z.iter) if isinstance(z,ast.For) else None if isinstance(z,ast.Try) or z.type is None else ast.unparse(z.type)
     branches.append({'kind':type(z).__name__,'line':z.lineno,'end_line':z.end_lineno,'test':test})
   rows.append({'name':name,'kind':type(x).__name__,'line':x.lineno,'end_line':x.end_lineno,'raw_bytes':len(b),'raw_sha256':sha(b),'AST_sha256':sha(ast.dump(x).encode()),'positioned_AST_sha256':sha(ast.dump(x,include_attributes=True).encode()),'signature':None if isinstance(x,ast.ClassDef) else ast.unparse(x.args),'all_descendant_branches':branches,'all_descendant_calls':sorted({ast.unparse(z.func) for z in ast.walk(x) if isinstance(z,ast.Call)})})
   scan(x,name+'.')
scan(t);assert rows==l['definitions'] and len(rows)==31
assert [(x['name'],x['line'],x['end_line'],x['signature']) for x in rows]==[(x['name'],x['line'],x['end_line'],x['signature']) for x in m['helpers']]
st=symtable.symtable(raw.decode(),str(sp),'exec');sr=[];tables=[]
flags=[('assigned','is_assigned'),('free','is_free'),('global','is_global'),('imported','is_imported'),('local','is_local'),('nonlocal','is_nonlocal'),('parameter','is_parameter'),('referenced','is_referenced')]
def symbols(s,name):
 entries=[]
 for n in s.get_identifiers():
  x=s.lookup(n);entries.append({'name':n,**{k:getattr(x,f)() for k,f in flags}})
 sr.append({'name':name,'line':s.get_lineno(),'type':s.get_type(),'entries':entries});tables.append(s)
 for c in s.get_children():symbols(c,name+'.'+c.get_name())
symbols(st,'top');assert sr==l['symbol_scopes'] and len(sr)==39
module={n for n in st.get_identifiers() if st.lookup(n).is_assigned() or st.lookup(n).is_imported()};unknown=sorted({n for s in tables for n in s.get_identifiers() if s.lookup(n).is_global() and s.lookup(n).is_referenced() and n not in module and n not in vars(builtins) and n not in ['__name__','__file__']});assert unknown==l['unresolved_globals']==[]
assert sha(ast.dump(t).encode())==l['whole_AST_sha256'] and sha(ast.dump(t,include_attributes=True).encode())==l['whole_positioned_AST_sha256']
literals={}
for n in t.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:v=ast.literal_eval(n.value)
  except (ValueError,TypeError):continue
  literals[n.targets[0].id]=json.loads(json.dumps(v))
assert literals==l['literal_constants']
assert literals['NAMES']==a['ordered_new_names']==handoff['fixed_new_targets']
assert literals['PAYLOAD_CAPS']==a['ordered_payload_caps']
assert literals['EXPECTED_PARENT']==a['fixed_parent']==handoff['fixed_parent'] and literals['EXPECTED_TREE']==a['fixed_tree']==handoff['fixed_tree']
assert literals['REPOSITORY']==a['fixed_repository'] and literals['GIT_PREFIX']==a['Git_prefix'] and literals['EXPECTED_API_CALLS']==12
assert pin(literals['PYTHON']['path'])==literals['PYTHON']
code=compile(raw,str(sp),'exec',dont_inherit=True);del code
support=save('fixed-fol-publisher1-complete-independent-static-support-v1.json',{'schema':'C-fixed-fol-publisher1-complete-independent-static-support-v1','subjects':subjects,'all_definitions':rows,'all_scope_joins':[{'name':x['name'],'line':x['line'],'type':x['type'],'complete_entries_sha256':sha(enc(x['entries'])),'entry_count':len(x['entries']),'all_flags_match':True} for x in sr],
 'definition_count':31,'symbol_scope_count':39,'Source_lines':526,'whole_AST_sha256':sha(ast.dump(t).encode()),'whole_positioned_AST_sha256':sha(ast.dump(t,include_attributes=True).encode()),'all_complete_definition_and_scope_rows_match':True,'all_manual_signatures_lines_match':True,'all20literal_constants_match':True,'unresolved_globals':unknown,'unused_compile':'PASS; discarded, not executed','runtime':literals['PYTHON'],'subject_imports_functions_network_CLI_probes_payload_actual_intake':0})
review=save('fixed-fol-publisher1-complete-independent-Source-peer-review-v1.json',{'schema':'C-fixed-fol-publisher1-complete-independent-Source-peer-review-v1','decision':'CHANGES_REQUIRED','complete_review':True,'subjects':subjects+[support,pin(O/'prefrozen-complete-Source-review-expectations-v1.json')],
 'blockers':[{'id':'OUT_OWNERSHIP','helper':'main/publish','finding':'main exception handling writes OUT/failure.json whenever OUT is a directory, even if publish rejected a preexisting/spent OUT at fresh(OUT) or lost the OUT.mkdir race. It can mutate a directory this invocation never owned.','required_fix':'New immutable successor: ownership false in caller context, true only after this invocation successfully OUT.mkdir; failure writing only when ownership is confirmed. Preserve Source1, exact12 routes/caps/target-parent-tree/plan/A6 and all other helpers.','priority':1}],
 'complete_coverage':{'full_Source_lines':526,'all_helpers':31,'all_symbol_scopes':39,'full_body_ABI_manual_read':True,'all_static_rows_independently_rederived':True,'unused_compile_only':True},
 'accepted_analysis':[
  {'area':'closed typed metadata and Source/runtime trust','judgment':'Exact plan9/fixed repository-main-parent-tree/root/P2 stages/ordered target rows and positive exact-int payload refs. Complete typed authority6 canonical equality binds current plan/publisher/D90; nested float byte counts do not pass. Quote/date/scope format checked; real human provenance and exact executed Source are external Root prerequisites.'},
  {'area':'spend and payload boundary','judgment':'Exclusive no-follow/fsync/readback authority-adjacent consume and Root-directory fsync precede output creation, payload bodies and network. Current source/runtime and metadata pre/post guards plus consume posthash. Fresh OUT ownership exception is the sole material blocker.'},
  {'area':'three-body transport and no private/unrelated leaf body intake','judgment':'Only the fixed Root/P2 three staged bodies are transported; exact directory census, cap/stat/fullSHA/Gitblob and byte-for-byte twins are checked before network and after mutation. The complete recursive baseline tree supplies paths/modes/hashes/blob sizes, not unrelated blob bodies. No local Git command, index/check-out change, protected reader or scientific module access.'},
  {'area':'remote mutation preservation','judgment':'Six GETs, three blob POSTs, one base-tree overlay POST, one one-parent commit POST and exactly one force:false main PATCH. Baseline head/commit/tree fixed, targets absent as leaves, complete untruncated resulting tree and every nontarget mode/type/SHA/blobsize equal, exactly three added leaves and exact target hashes/sizes. Main reread before PATCH plus nonforce protects against ordinary concurrent descendant changes; no atomic expected-old compare-and-swap is claimed.'},
  {'area':'gh and uncertainty custody','judgment':'Fixed trusted external gh client, fixed github.com/repository routes and P2 cwd; structured argv and JSON stdin, no shell. Selector/setup/Popen/data feed/drain inside protected try, bounded stdout/stderr/time and owned group TERM/KILL/wait(timeout5)/close. Normal gates require full EOF/rc0/input send/groupgone/no fault. Failure buffers may be bounded prefixes; unread failure pipe tails are not a complete response or permission to retry. No OS hard quota or unkillable-process guarantee.'},
  {'area':'evidence and final scope','judgment':'Exact normal50 receipts, request/full normal response/stderr/transport plus preflight and terminal, each exclusive/fsynced/readback and complete owned-file census. Any cap/mismatch/race/uncertain mutation exits2 and remains spent; Source performs no automatic retry/reconcile. Commit terminal explicitly says live check pending; deployment/wholebody normalTLS3 and exact future caller/payload/adoption remain Root gates.'}],
 'helper_groups':[{'helpers':['PublicationFailure','need','encode','parse','parse.pairs','parse.nonfinite','fields','sha256','git_sha','blob_sha'],'assessment':'Typed deterministic administrative parse/hash/fault helpers; no executable data or scientific operation.'},
 {'helpers':['canonical','pin','read','rawref','sync_dir','fresh','create','admin'],'assessment':'Absolute canonical/nonsymlink/single-link capped stable-stat files; no-follow exclusive writes/full readback and directory fsync. Controlled filesystem assumption explicit; no hard hostile-race or power-loss theorem.'},
 {'helpers':['plan_read','local_guards'],'assessment':'Complete fixed metadata and twin-body/Gitblob identity; all values from future approved plan, no existing private-body reads.'},
 {'helpers':['group_exists','Session','Session.__init__','Session.wall','Session.save','Session.census','Session.api'],'assessment':'Complete accounting/subprocess/body/capture/cleanup/census paths read; normal exact whole evidence, failed prefixes unadmitted. GH is external trusted client; Source does not log credentials in its arguments.'},
 {'helpers':['head','leaves','publish'],'assessment':'All route, tree, branch/parent, head-race/nonforce, leaf and late guard gates checked; no extra destinations or private blob endpoints.'},
 {'helpers':['main'],'assessment':'CLI complete success/exception paths read; OUT ownership correction required before approval.'}],
 'external_limits':['No actual plan/A6/payload/twin staging/semantic content was supplied or reviewed.','Source static judgment cannot establish human authorization provenance or authenticate its own invoking bytes; Root must bind retained Source/D90/caller and authoritative full outer captures/exit.','No current head/network check or Git operation was performed. Exact fixed parent/tree availability is a later prospective gate.','No approval to publish; Source1 remains unexecuted and the negative finding is administrative custody, not a scientific case failure.'],
 'successor_expectations':'One material ownership fix only, necessary Source/version/path labels and truthful full inverse/helper/global/AST/static metadata. Inherit complete Source1 review for all byte-identical helpers; inspect changed success/failure bodies. No probes or extra scientific qualification.',
 'activity':{'subject_imports_execution_functions_CLI_help_fault_probes':0,'network_git_mutation':0,'actual_or_payload_intake':0,'subject_codeobject_execution':0},'terminal_state':'IDLE_PENDING_SUCCESSOR_SOURCE'})
print(json.dumps({'review':review,'support':support},sort_keys=True))
