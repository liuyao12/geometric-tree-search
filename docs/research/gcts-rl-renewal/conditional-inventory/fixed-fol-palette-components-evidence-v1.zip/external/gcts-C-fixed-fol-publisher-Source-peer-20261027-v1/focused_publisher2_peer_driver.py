"""Administrative Source preservation peer; no subject or network execution."""
import ast,hashlib,json,pathlib,re,symtable
B=pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-L');O=pathlib.Path('/private/tmp/gcts-C-fixed-fol-publisher-Source-peer-20261027-v1')
def enc(x):return (json.dumps(x,ensure_ascii=True,sort_keys=True,indent=2)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def save(name,x):
 p=O/name
 with p.open('xb') as f:f.write(enc(x))
 return pin(p)
def apply(raw,patch):
 source=raw.decode().splitlines(keepends=True);out=[];at=0;lines=patch.decode().splitlines(keepends=True);i=2
 while i<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i]);assert m;start=int(m[1])-1;assert start>=at;out+=source[at:start];at=start;i+=1;a=b=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   z=lines[i];assert z[0] in ' +-'
   if z[0] in ' -':assert source[at]==z[1:];at+=1;a+=1
   if z[0] in ' +':out.append(z[1:]);b+=1
   i+=1
  assert a==int(m[2] or '1') and b==int(m[4] or '1')
 out+=source[at:];return ''.join(out).encode()
def helpers(raw):
 t=ast.parse(raw);ls=raw.splitlines(keepends=True);out={}
 def scan(n,prefix=''):
  for x in n.body:
   if isinstance(x,(ast.FunctionDef,ast.ClassDef)):
    name=prefix+x.name;b=b''.join(ls[x.lineno-1:x.end_lineno]);out[name]={'line':x.lineno,'end_line':x.end_lineno,'raw_bytes':len(b),'raw_sha256':h(b),'AST_sha256':h(ast.dump(x).encode()),'positioned_AST_sha256':h(ast.dump(x,include_attributes=True).encode()),'signature':None if isinstance(x,ast.ClassDef) else ast.unparse(x.args)};scan(x,name+'.')
 scan(t);return out
hp=B/'fixed-fol-palette-components-publisher-complete-inert-Source-handoff-v2.json';hand=json.loads(hp.read_bytes());refs=[pin(hp)]
for k in ['Source','correction_preservation','manual','public_ABI','static','predecessor_ABI','predecessor_manual']:
 assert pin(hand[k]['path'])==hand[k];refs.append(hand[k])
corr=json.loads(pathlib.Path(hand['correction_preservation']['path']).read_bytes())
for k in ['exact_forward','exact_inverse','old_Source']:
 assert pin(corr[k]['path'])==corr[k];refs.append(corr[k])
a=pathlib.Path(corr['old_Source']['path']).read_bytes();b=pathlib.Path(hand['Source']['path']).read_bytes();ta,tb=ast.parse(a),ast.parse(b);ha,hb=helpers(a),helpers(b);assert set(ha)==set(hb) and len(hb)==31
changed=[n for n in ha if any(ha[n][k]!=hb[n][k] for k in ['raw_bytes','raw_sha256','AST_sha256'])];assert changed==['publish','main']
assert apply(a,pathlib.Path(corr['exact_forward']['path']).read_bytes())==b
back=apply(b,pathlib.Path(corr['exact_inverse']['path']).read_bytes());assert back==a and ast.dump(ast.parse(back),include_attributes=True)==ast.dump(ta,include_attributes=True)
norm=b.decode().replace('FIXED-FOL-PALETTE-COMPONENTS-P2-PUBLISHER-v2','FIXED-FOL-PALETTE-COMPONENTS-P2-PUBLISHER-v1').replace('publish_fixed_fol_palette_components_api_v2.py','publish_fixed_fol_palette_components_api_v1.py')
assert [ast.dump(n) for n in ast.parse(norm).body if not isinstance(n,ast.FunctionDef)]==[ast.dump(n) for n in ta.body if not isinstance(n,ast.FunctionDef)]
# Complete ABI/manual metadata read; only actual revision/preservation labels may differ.
a1=json.loads((B/'fixed-fol-palette-components-publisher-complete-public-ABI-v1.json').read_bytes());a2=json.loads(pathlib.Path(hand['public_ABI']['path']).read_bytes());diff=[k for k in set(a1)|set(a2) if a1.get(k)!=a2.get(k)];assert set(diff)=={'Source','Source_revision','ownership_correction','schema','status'}
m=json.loads(pathlib.Path(hand['manual']['path']).read_bytes());assert [(x['name'],x['line'],x['end_line'],x['signature']) for x in m['helpers']]==[(n,x['line'],x['end_line'],x['signature']) for n,x in hb.items()]
# Full current symtable traversal, unused compile only.
st=symtable.symtable(b.decode(),hand['Source']['path'],'exec');sc=[]
def scan(s,name):
 sc.append({'name':name,'line':s.get_lineno(),'type':s.get_type(),'identifiers':list(s.get_identifiers())})
 for c in s.get_children():scan(c,name+'.'+c.get_name())
scan(st,'top');assert len(sc)==39
code=compile(b,hand['Source']['path'],'exec',dont_inherit=True);del code
support=save('fixed-fol-publisher2-complete-independent-preservation-support-v1.json',{'schema':'C-fixed-fol-publisher2-complete-independent-preservation-support-v1','subjects':refs,'helper_joins':{'predecessor':ha,'current':hb},'changed_helpers':changed,'all29other_helpers_raw_AST_identical':True,'whole_forward_inverse_raw_positioned_AST_exact':True,'allotherglobals_except_VERSION_SelfPath_exact':True,'ABI_changed_fields_only':sorted(diff),'manual_all31_join':True,'current_scopes':sc,'scope_count':39,'whole_AST_sha256':h(ast.dump(tb).encode()),'whole_positioned_AST_sha256':h(ast.dump(tb,include_attributes=True).encode()),'unused_compile':'PASS, discarded, never executed','activity':{'subject_calls_network_payload_actual_CLI':0}})
review=save('fixed-fol-publisher2-complete-independent-Source-peer-review-v1.json',{'schema':'C-fixed-fol-publisher2-complete-independent-Source-peer-review-v1','decision':'PASS','complete_review':True,'blockers':[],'current_Source':hand['Source'],'complete_handoff':pin(hp),'current_ABI':hand['public_ABI'],'independent_support':support,'inherited_complete_Source1_review':pin(O/'fixed-fol-publisher1-complete-independent-Source-peer-review-v1.json'),'correction':'Ownership initialized false in main; internal publish receives caller state; the flag becomes true only immediately after this invocation successfully OUT.mkdir. main failure writes require that flag. Refused preexisting/spent/mkdir-race directories remain untouched. Source1 and its negative receipt preserved.','preservation':'All31 helper bodies accounted for; only publish/main differ, fully read on success/failure paths. All29 other raw/plainAST bodies identical, exact forward/inverse bytes and whole positioned-AST inverse independently reproduced. Only VERSION/self-path globals differ; exact12 routes/caps/targets/parent/tree/plan+A6 wire and twin/tree/head/nonforce/no-retry behavior unchanged.','whole_disposition':'Inherit complete Source1 calculus-free administrative publisher review for every identical body. The sole material ownership blocker is closed; no additional material issue found. Source2 is eligible for Root Source adoption, not publication execution.','external_preconditions':['Exact approved payload/twin staging/plan/human authorization and fresh authority/caller remain unreviewed here.','Root must authenticate retained Source2/D90/current plan/authority, exact P2 cwd, fresh bounded full outer captures and original authoritative exit; any uncertain mutation remains spent/no retry.','Fixed parent/tree must still match fresh main. No atomic expected-old CAS, hostile-filesystem, unkillable-process or hard RAM/whole-lifetime quota guarantee is inferred.','Successful commit requires later Pages deployment and a separate fresh normal-TLS fullbody verifier for exactly these three new targets. Existing primary reader/index and unrelated leaves stay preserved.'],'activity':{'subject_functions_imports_CLI_help_probes_network_git_execution':0,'payload_or_scientific_actual_intake':0,'subject_codeobject_execution':0},'terminal_state':'IDLE_FOR_NEXT_STATIC_ASSIGNMENT'})
print(json.dumps({'review':review,'support':support},sort_keys=True))
