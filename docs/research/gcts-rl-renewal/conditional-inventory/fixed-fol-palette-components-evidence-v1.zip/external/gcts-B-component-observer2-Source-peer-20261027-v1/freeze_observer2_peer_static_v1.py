from pathlib import Path
import ast,symtable,json,hashlib
P=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-C')
O=Path('/private/tmp/gcts-B-component-observer2-Source-peer-20261027-v1')
def h(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def save(n,x):
 p=O/n;b=enc(x);p.write_bytes(b);assert p.read_bytes()==b;return pin(p)
source=P/'component_qualification_observer_v2.py';raw=source.read_bytes();txt=raw.decode();lines=raw.splitlines(keepends=True);tree=ast.parse(txt,str(source));st=symtable.symtable(txt,str(source),'exec')
assert len(raw)==27483 and h(raw)=='89d75f1debea0d552cc5e07f7842b15188a180a4b5cfef4b3aa0554ee3130cbb'
author=json.loads((P/'component-qualification-complete-static-helper-ledger-v2.json').read_bytes())['sources'][1]
manual=json.loads((P/'component-qualification-worker-observer-complete-helper-walkthrough-v2.json').read_bytes())
defs=[]
for node in ast.walk(tree):
 if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
  # Full recursive qualified name including functions nested inside handlers/loops.
  parents=[a for a in ast.walk(tree) if isinstance(a,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and a is not node and a.lineno<node.lineno<=node.end_lineno<=a.end_lineno]
  name='.'.join([a.name for a in sorted(parents,key=lambda a:a.lineno)]+[node.name]);r=b''.join(lines[node.lineno-1:node.end_lineno])
  branches=[]
  for a in ast.walk(node):
   if isinstance(a,(ast.If,ast.IfExp,ast.For,ast.While,ast.ExceptHandler)):
    e=a.iter if isinstance(a,ast.For) else a.type if isinstance(a,ast.ExceptHandler) else a.test
    branches.append({'kind':type(a).__name__,'line':a.lineno,'expression':None if e is None else ast.unparse(e)})
  defs.append({'name':name,'kind':type(node).__name__,'line':node.lineno,'end_line':node.end_lineno,'signature':None if isinstance(node,ast.ClassDef) else ast.unparse(node.args),'raw_bytes':len(r),'raw_sha256':h(r),'AST_sha256':h(ast.dump(node,include_attributes=False).encode()),'positioned_AST_sha256':h(ast.dump(node,include_attributes=True).encode()),'all_descendant_calls':sorted(set(ast.unparse(a.func) for a in ast.walk(node) if isinstance(a,ast.Call))),'branches':branches})
defs.sort(key=lambda d:d['line'])
flags=['parameter','referenced','assigned','global','local','free','nonlocal','imported']
scopes=[]
def walk_scope(t,path):
 entries=[]
 for n in sorted(t.get_identifiers()):
  s=t.lookup(n);entries.append({'name':n,'true_flags':sorted(f for f in flags if getattr(s,'is_'+f)())})
 scopes.append({'path':path,'type':t.get_type(),'line':t.get_lineno(),'entries':entries,'complete_entry_fingerprint':h(enc(entries))})
 for i,c in enumerate(t.get_children()):walk_scope(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
walk_scope(st,'module')
assert defs==author['definitions'],[(x['name'],[k for k in x if x[k]!=y[k]]) for x,y in zip(defs,author['definitions']) if x!=y]
assert scopes==author['symbol_scopes']
assert h(ast.dump(tree,include_attributes=False).encode())==author['whole_AST_sha256']
assert h(ast.dump(tree,include_attributes=True).encode())==author['whole_positioned_AST_sha256']
walks={d['helper']:d for d in manual['all_helpers'] if d['source']==source.name};assert set(walks)=={d['name'] for d in defs}
for d in defs:
 assert (d['line'],d['end_line'],d['signature'])==(walks[d['name']]['line'],walks[d['name']]['end_line'],walks[d['name']]['signature'])
receipts=[]
for n in ['component-qualification-worker-observer-complete-inert-Source-handoff-v3.json','component-qualification-closed-plan-authority-and-once-ABI-v2.json','component-qualification-worker-observer-complete-public-ABI-v3.json','component-qualification-worker-observer-complete-helper-walkthrough-v2.json','component-qualification-complete-static-helper-ledger-v2.json','component-qualification-v1-v2-complete-correction-and-preservation-v1.json']:
 receipts.append(pin(P/n))
support=save('component-observer2-independent-complete-static-custody-support-v1.json',{'schema':'B-component-observer2-independent-complete-static-custody-support-v1','scope':'Observer2 whole Source AST/symtable and complete own helper/call/branch derivation; no subject compile/import/function/test/probe/CLI. Worker/scientific bodies not read by this peer.','Source':pin(source),'metadata':receipts,'lines':len(lines),'definitions':defs,'definition_count':len(defs),'symbol_scopes':scopes,'symbol_scope_count':len(scopes),'whole_AST_sha256':h(ast.dump(tree,include_attributes=False).encode()),'whole_positioned_AST_sha256':h(ast.dump(tree,include_attributes=True).encode()),'joins':{'all_24_definitions_author_static_exact':True,'all_31_scopes_author_static_exact':True,'all_24_manual_helper_spans_signatures_exact':True},'subject_calls':0,'unused_compile':False})
findings=[
 {'id':'OWNERSHIP','severity':'BLOCKING_CUSTODY','lines':[385,399,400,404,443,449],'helper':'main','finding':'The failure path may write observer-failure.json into a preexisting/spent actual directory or a directory won by another mkdir invocation, because directory is assigned before absence and mkdir succeed.','required_correction':'Set directory_owned=False before preflight, set True only after this invocation successfully creates the actual directory, and permit failure output only under that ownership flag. Preserve exclusive create/no retry and all existing preflight checks.'},
 {'id':'TERMINAL_PLAN_TYPE','severity':'BLOCKING_TYPED_ASSOCIATION','lines':[360,364,366],'helper':'verify_terminal','finding':'Terminal plan rawref is compared using Python ==. A canonical JSON float byte count equal to the integer current byte count passes equality despite the exact rawref scalar contract.','required_correction':'Keep exact case association and use raw_association on terminal.plan against current plan_ref, including full typed rawref shape/canonical association and complete current bytes/hash authentication.'},
 {'id':'CONSUME_POSTJOIN','severity':'BLOCKING_CUSTODY_ASSOCIATION','lines':[405,407,422,423,425,435],'helper':'main / guards','finding':'The initial consumed_ref is reported after child completion, but postguards omit it. Census freshly hashes the marker without comparing it to the initial consumed_ref. Thus an altered marker can leave a contradictory NORMAL_TRANSPORT_CANDIDATE.','required_correction':'Authenticate consumed_ref whole bytes/hash after the child and before normal candidate acceptance, preserving exact consumed7/current meaning/uses/case/plan/authority/observer association. Retain an explicit final join before success; do not treat a newly computed different census pin as the initial marker.'},
 {'id':'FINAL_WAIT_BOUND','severity':'BLOCKING_BOUNDED_CLEANUP','lines':[321,325,332,334,336],'helper':'supervise','finding':'Final process.wait() is unbounded even after owned kill/cleanup errors. The bounded drain loop therefore does not bound terminal custody or guarantee an uncertainty receipt.','required_correction':'Use bounded final wait. On timeout/error retain child PID, full captured transport, EOF/group state and explicit wait/reaping uncertainty as UNADMITTED; never assert reaped timing or normal quiescence without successful observed wait. Preserve immediate post-Popen protection, own group-only cleanup, no restart/retry.'}]
helper_status=[]
for d in defs:
 affected=[f['id'] for f in findings if d['name']==f['helper'].split(' / ')[0] or (d['name']=='guards' and f['id']=='CONSUME_POSTJOIN')]
 helper_status.append({'helper':d['name'],'line':d['line'],'end_line':d['end_line'],'disposition':'MATERIAL_CORRECTION_REQUIRED' if affected else 'ACCEPTED_WITHIN_DECLARED_STATIC_SCOPE','findings':affected,'walk':walks[d['name']]['walk']})
review=save('component-observer2-complete-independent-custody-Source-review-v1.json',{'schema':'B-component-observer2-complete-independent-custody-Source-review-v1','decision':'NEGATIVE_SOURCE_CUSTODY_CORRECTIONS_REQUIRED','complete_review':True,'Source':pin(source),'prefrozen_expectations':pin(O/'component-observer2-prefrozen-independent-custody-Source-review-expectations-v1.json'),'support':support,'findings':findings,'helper_dispositions':helper_status,'accepted_scopes':['Complete 457-line observer2 Source and current plan/A6/ABI/manual read. All 24 definitions, 31 symbol scopes, full branch/call inventory and raw/AST/positioned fingerprints exactly rederived.','Current A6 preflight uses exact typed canonical associations. Immediate post-Popen protected try includes selector/nonblocking setup; fallback partial-stream cleanup is present.','One authenticated retained-byte D90 child; bootstrap323 bytes, exact seven Source/four ABI/D90/plan/A6 guard closure and fixed317 call declaration are preserved. This peer does not revalidate scientific recipes.','Full concurrent bounded log capture and tail diagnostics, EOF/group/exit/RSS gates, all-owned-file raw census, full readback and external authoritative outer capture+exit zero remain required. Observer treats scientific result as opaque.','No automatic retry or partial promotion. Resource and cleanup faults remain UNADMITTED, not mathematical rejection. Clock/RSS are explicitly scoped observational samples.'],'precision_limits':['Metadata/manual claims of bounded cleanup and typed terminal association require the corrections above; full static fingerprint agreement does not establish those behavioral claims.','Controlled owned-filesystem/process preconditions remain inherited. No new hostile-filesystem, hard RAM quota, power-failure directory durability or unkillable-process guarantee is inferred.','Source2 is unexecuted and remains immutable. Negative disposition is a custody Source finding, not a scientific experiment outcome.'],'successor_review_expectations':{'observer':'Four named custody fixes plus necessary Source/version/path operational bindings only; all unaffected helpers/raw constants/caps/317 science calls preserved.','worker':'Root-authorized worker3 VERSION plus exactly two worker/observer Source path literal changes. Every worker2 function and scientific recipe raw/AST byte-identical.','proof_required':'Full forward/inverse patches and whole helper/global/AST joins; inspect every changed helper success/failure branch; no subject execution.','authority':'No runtime, grant, plan, actual or publication authority is conferred.'},'operations':{'subject_imports':0,'subject_functions':0,'subject_tests_probes_CLI':0,'subject_codeobject_execution':0,'unused_compile':False,'only_AST_symtable_and_administrative_bytes':True},'terminal_state':'IDLE_PENDING_EXACT_SOURCE3_HANDOFF'})
print(json.dumps({'review':review,'support':support},indent=2))
