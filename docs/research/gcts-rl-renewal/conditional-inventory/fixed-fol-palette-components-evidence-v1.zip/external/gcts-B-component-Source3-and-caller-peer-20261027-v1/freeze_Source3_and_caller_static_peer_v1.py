from pathlib import Path
import ast,symtable,json,hashlib,difflib,re,shlex,stat
P=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1');C=P/'implementation-C';OUT=Path('/private/tmp/gcts-B-component-Source3-and-caller-peer-20261027-v1')
def h(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def rawpin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def readpin(r):
 assert type(r)is dict and set(r)=={'path','bytes','sha256'} and type(r['path'])is str and type(r['bytes'])is int and r['bytes']>=0 and type(r['sha256'])is str and re.fullmatch('[0-9a-f]{64}',r['sha256'])
 p=Path(r['path']);assert p.is_absolute() and str(p)==r['path'] and '..'not in p.parts
 assert all(not q.is_symlink() for q in (p,)+tuple(p.parents));s=p.stat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();assert len(b)==s.st_size==r['bytes'] and h(b)==r['sha256'];return b
 def_unused=None
def save(n,o):
 p=OUT/n;b=enc(o);p.write_bytes(b);assert p.read_bytes()==b;return rawpin(p)
def derive(p):
 b=p.read_bytes();t=ast.parse(b,str(p));ls=b.splitlines(keepends=True);nodes=[n for n in ast.walk(t) if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))];defs={}
 for n in sorted(nodes,key=lambda n:n.lineno):
  ps=sorted([x for x in nodes if x is not n and x.lineno<n.lineno<=n.end_lineno<=x.end_lineno],key=lambda x:x.lineno);name='.'.join([x.name for x in ps]+[n.name]);r=b''.join(ls[n.lineno-1:n.end_lineno]);branches=[]
  for a in ast.walk(n):
   if isinstance(a,(ast.If,ast.IfExp,ast.For,ast.While,ast.ExceptHandler)):
    v=a.iter if isinstance(a,ast.For) else a.type if isinstance(a,ast.ExceptHandler) else a.test
    branches.append({'line':a.lineno,'kind':type(a).__name__,'expression':None if v is None else ast.unparse(v)})
  defs[name]={'line':n.lineno,'end_line':n.end_lineno,'signature':None if isinstance(n,ast.ClassDef) else ast.unparse(n.args),'raw_bytes':len(r),'raw_sha256':h(r),'AST_sha256':h(ast.dump(n).encode()),'positioned_AST_sha256':h(ast.dump(n,include_attributes=True).encode()),'calls':sorted(set(ast.unparse(a.func) for a in ast.walk(n) if isinstance(a,ast.Call))),'branches':branches}
 scopes=[]
 def scope(t,path):
  es=[]
  for k in sorted(t.get_identifiers()):
   s=t.lookup(k);es.append({'name':k,'true_flags':sorted(f for f in ['assigned','free','global','imported','local','nonlocal','parameter','referenced'] if getattr(s,'is_'+f)())})
  scopes.append({'path':path,'line':t.get_lineno(),'type':t.get_type(),'entries':es,'entry_fingerprint':h(enc(es))})
  for i,c in enumerate(t.get_children()):scope(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 scope(symtable.symtable(b.decode(),str(p),'exec'),'module')
 return {'Source':rawpin(p),'lines':len(ls),'helpers':defs,'scopes':scopes,'whole_AST_sha256':h(ast.dump(t).encode()),'whole_positioned_AST_sha256':h(ast.dump(t,include_attributes=True).encode()),'imports':[ast.unparse(x) for x in t.body if isinstance(x,(ast.Import,ast.ImportFrom))]},t,b

def apply_patch(original,patch):
 src=original.decode().splitlines(keepends=True);p=patch.decode().splitlines(keepends=True);i=2;cur=0;out=[]
 while i<len(p):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',p[i]);assert m,p[i]
  pos=int(m[1])-1;out.extend(src[cur:pos]);cur=pos;i+=1
  while i<len(p) and not p[i].startswith('@@ '):
   z=p[i];i+=1
   if z.startswith('\\'):continue
   assert z[0]in' +-'
   if z[0]in' -':assert src[cur]==z[1:],(cur,z,src[cur]);cur+=1
   if z[0]in' +':out.append(z[1:])
 out.extend(src[cur:]);return ''.join(out).encode()

handoff_path=C/'component-qualification-worker3-observer3-complete-inert-Source-handoff-v1.json';handoff=json.loads(handoff_path.read_bytes());metadata=[]
for k in ['changed_helper_manual','complete_Source2_Source3_preservation_static_fourpatches','current_closed_plan_authority_contract','current_public_ABI','inherited_Source2_complete_handoff','inherited_complete_scientific_census','predecessor_formal_negative']:
 readpin(handoff[k]);metadata.append(handoff[k])
static=json.loads(readpin(handoff['complete_Source2_Source3_preservation_static_fourpatches']));contract=json.loads(readpin(handoff['current_closed_plan_authority_contract']));abi=json.loads(readpin(handoff['current_public_ABI']))
joined=[];own={};trees={};bodies={};current_globals={}
for a in static['sources']:
 role=a['role'];v2,t2,b2=derive(C/f'component_qualification_{role}_v2.py');v3,t3,b3=derive(C/f'component_qualification_{role}_v3.py');assert v3['Source']==handoff[role]==a['current'];assert v2['Source']==a['predecessor'];own[role]={'predecessor':v2,'current':v3};trees[role]=t3;bodies[role]=(b2,b3)
 for key in ('whole_AST_sha256','whole_positioned_AST_sha256'):assert v3[key]==a[key]
 for n,fp in a['current_helpers'].items():assert all(v3['helpers'][n][k]==v for k,v in fp.items()),(role,n)
 for n,fp in a['old_helpers'].items():assert all(v2['helpers'][n][k]==v for k,v in fp.items()),(role,n,'old')
 assert v3['scopes']==a['all_symbol_scopes']
 unchanged=[n for n,d in v2['helpers'].items() if n in v3['helpers'] and all(d[k]==v3['helpers'][n][k] for k in ['raw_bytes','raw_sha256','AST_sha256'])]
 changed=[n for n in v2['helpers'] if n in v3['helpers'] and n not in unchanged];new=[n for n in v3['helpers'] if n not in v2['helpers']]
 assert unchanged==a['identical_old_raw_plain_AST_helpers'] and changed==a['changed_helpers'] and new==a['new_helpers']
 patch_refs=[]
 for j,r in enumerate(a['patches']):
  patch=readpin(r);assert apply_patch(b2 if j==0 else b3,patch)==(b3 if j==0 else b2);patch_refs.append(r)
 # Independent whole inverse by exact changed helper span substitution and allowed literals, separate from patches.
 inverse=b3.decode();oldlines=b2.decode().splitlines(keepends=True);newlines=b3.decode().splitlines(keepends=True)
 for n in changed:
  d=v3['helpers'][n];e=v2['helpers'][n];x=''.join(newlines[d['line']-1:d['end_line']]);y=''.join(oldlines[e['line']-1:e['end_line']]);assert inverse.count(x)==1;inverse=inverse.replace(x,y,1)
 for n in new:
  d=v3['helpers'][n];x=''.join(newlines[d['line']-1:d['end_line']])+'\n\n';assert inverse.count(x)==1;inverse=inverse.replace(x,'',1)
 replacements=[('GCTS-FOL-NTM-COMPONENT-QUALIFICATION-'+role.upper()+'-v3','GCTS-FOL-NTM-COMPONENT-QUALIFICATION-'+role.upper()+'-v2'),('component_qualification_worker_v3.py','component_qualification_worker_v2.py'),('component_qualification_observer_v3.py','component_qualification_observer_v2.py')]
 for x,y in replacements:assert inverse.count(x)==1;inverse=inverse.replace(x,y,1)
 assert inverse.encode()==b2 and ast.dump(ast.parse(inverse),include_attributes=True)==ast.dump(t2,include_attributes=True)
 gs={}
 for n in t3.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):gs[n.targets[0].id]=ast.dump(n.value)
 oldgs={n.targets[0].id:ast.dump(n.value) for n in t2.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
 assert set(gs)==set(oldgs);assert [k for k in gs if gs[k]!=oldgs[k]]==['VERSION','SOURCE_PATHS'];assert v3['imports']==v2['imports']
 current_globals[role]=gs
 joined.append({'role':role,'definitions':len(v3['helpers']),'scopes':len(v3['scopes']),'unchanged_helpers':unchanged,'changed_helpers':changed,'new_helpers':new,'all_author_fingerprints_scopes_exact':True,'whole_inverse_raw_positioned_AST_exact':True,'both_patch_applications_exact':True,'patches':patch_refs,'only_global_changes':['VERSION','SOURCE_PATHS'],'imports_unchanged':True})
assert len(own['worker']['current']['helpers'])==38 and len(own['observer']['current']['helpers'])==25
assert own['worker']['predecessor']['helpers']==own['worker']['current']['helpers']
# Administrative constants extracted only from literal Source AST nodes, never a module/helper invocation.
obsassign={n.targets[0].id:n.value for n in trees['observer'].body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
const={k:ast.literal_eval(obsassign[k]) for k in ['LIMITS','PYTHON','COHORT','BOOTSTRAP','EXPECTED_CALLS','SOURCE_PATHS','COMPONENT_PINS','METADATA_PINS','CONSUMED_MEANING']}
assert const['LIMITS']==contract['limits_exact18'] and len(const['LIMITS'])==18
assert const['PYTHON']==contract['python'];assert const['METADATA_PINS']==contract['metadata_roles_exact4'];assert sum(const['EXPECTED_CALLS'].values())==317
assert len(const['BOOTSTRAP'].encode())==323 and h(const['BOOTSTRAP'].encode())==contract['bootstrap']['sha256']
waits=[n for n in ast.walk(trees['observer']) if isinstance(n,ast.Call) and ast.unparse(n.func)=='process.wait'];assert len(waits)==2 and all(any(k.arg=='timeout' for k in n.keywords) for n in waits)
# Exact prospective plan/caller, no invocation or A6 creation.
planpath=P/'root/component-qualification-once-plan-001.json';callerpath=P/'root/component-qualification-001-prospective-caller-v1.json';plan=json.loads(planpath.read_bytes());caller=json.loads(callerpath.read_bytes())
assert rawpin(planpath)==caller['plan'];assert set(plan)==set(contract['plan_exact8']);assert plan['schema']==contract['plan_schema'];assert type(plan['case_id'])is str and plan['case_id']=='qualification-001';assert plan['actual_dir']==str(P/'actual/qualification-001')
assert enc(plan['python'])==enc(contract['python']) and enc(plan['limits'])==enc(contract['limits_exact18']) and plan['cohort']==contract['cohort']
assert enc(plan['sources'])==enc(contract['Source_roles_exact7']) and enc(plan['metadata'])==enc(contract['metadata_roles_exact4'])
guards=[]
for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python']]:readpin(r);guards.append(r)
assert caller['observer']==plan['sources']['observer'] and caller['caps']==plan['limits'];assert caller['authority_target']==str(P/'root/component-qualification-once-authority-001.json')
bootstrap=readpin(caller['bootstrap']);assert len(bootstrap)==344 and h(bootstrap)=='f0fb00e11e4d22c78467a2182f4f1e980578d5ec064c3fb3031c6c8dad345b62'
assert caller['command'].startswith('set -C\n');tokens=shlex.split(caller['command'].split('\n',1)[1]);expected=['exec',plan['python']['path'],'-I','-S','-B','-c',bootstrap.decode(),plan['sources']['observer']['path'],str(plan['sources']['observer']['bytes']),plan['sources']['observer']['sha256'],'--plan',str(planpath),'--authority',caller['authority_target'],'<',plan['sources']['observer']['path'],'>',caller['outer_captures'][0],'2>',caller['outer_captures'][1]]
assert tokens==expected;assert '$('not in caller['command'] and '`'not in caller['command'];assert caller['exec_options']=={'login':False,'max_output_tokens':2000,'workdir':'/private/tmp','yield_time_ms':1000}
absent=[caller['authority_target'],plan['actual_dir']]+caller['outer_captures'];assert all(not Path(x).exists() and not Path(x).is_symlink() for x in absent)
caller_checks={'plan':rawpin(planpath),'prospective_caller':rawpin(callerpath),'exact_typed_plan8':True,'source7_metadata4_D90_all_rawhash_joined':True,'external_observer_bootstrap344':caller['bootstrap'],'internal_worker_bootstrap323':contract['bootstrap'],'exact_shlex_argv_stdin_and_noclobber_outer_redirections':True,'no_shell_substitution':True,'future_authority_actual_and_captures_absent':absent,'all18_caps317_calls_unchanged':True,'invocation_performed':False,'authority_created':False}
support=save('component-Source3-and-prospective-caller-independent-full-static-support-v1.json',{'schema':'B-component-Source3-and-caller-independent-static-support-v1','inherited_negative':rawpin(Path('/private/tmp/gcts-B-component-observer2-Source-peer-20261027-v1/component-observer2-complete-independent-custody-Source-review-v1.json')),'current_handoff':rawpin(handoff_path),'metadata':metadata,'all_current_and_base_helpers_scopes_calls_branches':own,'preservation':joined,'caller':caller_checks,'current_guard_rawrefs':guards,'subject_calls_imports_tests_probes_CLI_codeexecution':0,'unused_compile':False})
closures=[{'finding':'OWNERSHIP','status':'CLOSED','lines':[421,422,436,437,441,442,484],'evidence':'directory_owned initialized false, set only after successful mkdir, required by failure-output gate. Preexisting/spent or losing mkdir-race cannot authorize writes.'},{'finding':'TERMINAL_PLAN_TYPE','status':'CLOSED','lines':[395,401,402],'evidence':'Case exact string gate and raw_association terminal.plan authenticate exact typed rawref/current plan complete bytes; equal-valued float count cannot pass.'},{'finding':'CONSUME_POSTJOIN','status':'CLOSED','lines':[141,143,144,145,146,147,148,151,451,462,476],'evidence':'Original consumed_ref read/hash plus exact consumed7/A6/current associations after child; repeated original rawref joins after late guards and final census. No fresh census replacement of initial marker pin.'},{'finding':'FINAL_WAIT_BOUND','status':'CLOSED','lines':[220,221,278,279,304,351,353,357,362,380,389,391,454],'evidence':'Both waits have explicit timeout; final deadline uses bounded remaining cleanup time. Timeout/error retains fault/PID/EOF/group/capture fields with wait false and no RSS claim. Normal gate requires confirmed wait+EOF+group gone. Immediate post-Popen protection remains.'}]
review=save('component-Source3-and-prospective-caller-complete-independent-peer-review-v1.json',{'schema':'B-component-Source3-and-caller-complete-independent-peer-review-v1','decision':'PASS_SOURCE_AND_PROSPECTIVE_CALLER_ONLY','complete_review':True,'blockers':[],'current_Source':{'worker':handoff['worker'],'observer':handoff['observer']},'current_handoff':rawpin(handoff_path),'support':support,'inherited_scope':'Complete observer2 Source peer and formal four-finding negative preserved; Source3 whole body and every changed helper/branch read. Full worker body is inherited through exact 38-helper/raw/positionedAST equality, not a newly executed scientific verification.','closures':closures,'preservation_summary':joined,'prospective_caller':caller_checks,'whole_recipe_and_scope':{'public_calls':{'fol':40,'legacy':12,'compiler':10,'reference':128,'rows':127},'aggregate_calls':317,'normal_NTM_contexts':120,'layers_per_context':3,'FOL_controls':40,'legacy_compatible':12,'additional_NTM_controls':17,'all_original_caps_preserved':True,'meaning':'Authored component regressions and finite NTM-to-palette control. No proof discovery, PA/theory recognition, fixed universal FOL palette, GCTS search-engine benchmark or performance claim.'},'remaining_external_gates':['Root full Source/peer/adoption and exact once authorization with global idle before any invocation. Current A6 absent; this peer is not an execution grant.','One authoritative owned exec response/handle with full outer stdout/stderr and confirmed terminal exit zero; all faults/uncertainty spent, no retry.','Complete current saved-custody/result/317-call whole review before scientific admission; no selected successful prefix.'],'limitations':['Static proof of bounded wait calls and explicit uncertainty, not a guarantee of killing uninterruptible kernel processes or a hard OS memory quota.','Controlled owned-filesystem/process assumptions and explicit clock/RSS/tail scopes remain; no new hostile-filesystem or power-loss directory durability claim.','An unconfirmed wait can leave a process; it must remain UNADMITTED/nonquiescent and Root must not begin later science until external terminal state is settled.'],'activities':{'subject_imports_functions_factories_models_tests_probes_CLI':0,'subject_codeobject_execution':0,'unused_compile':False,'plan_authority_actual_creation':0,'administrative_AST_symtable_rawhash_type_shlex_only':True},'terminal_state':'IDLE'})
print(json.dumps({'review':review,'support':support},indent=2))
