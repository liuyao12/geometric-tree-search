from pathlib import Path
import json,hashlib,collections,math
P=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1');A=P/'actual/qualification-001';O=Path('/private/tmp/gcts-B-qualification-001-whole-actual-review-v1')
def enc(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pretty(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,x):
 p=O/n;b=pretty(x);p.write_bytes(b);assert p.read_bytes()==b;return pin(p)
def data(p):return json.loads(p.read_bytes())
def fields(x,ks):assert type(x)is dict and set(x)==set(ks)
def nat(x):assert type(x)is int and x>=0
S=O/'qualification-001-complete-passive-whole-saved-evidence-support-v1.json';sup=data(S);assert sup['status']=='ALL_ASSERTED_PASSIVE_JOINS_PASS';ret=[]
fol=data(A/'fol-controls.json')['controls'];ret.extend(('fol',r['evidence']['return'])for r in fol)
for i in[0,1]:ret.append(('compiler',data(A/f'palette-{i}.json')['evidence']['return']))
contexts=[]
for n in['000','020','040','060','072','092','112']:contexts.extend(data(A/f'ntm-contexts-{n}.json')['contexts'])
for x in contexts:ret.extend([('reference',x['reference']['return']),('rows',x['rows']['return'])])
extras=data(A/'ntm-wire-resource-coherence-controls.json')['controls']
for x in extras:
 if x['id'][0]=='N':ret.extend((role,x[role]['return'])for role in['compiler','reference'])
 else:ret.append(({'C':'compiler','R':'reference','W':'rows'}[x['id'][0]],x['evidence']['return']))
assert len(ret)==305
expected_compiler=['accepting_states','choose_glyph_count','choose_rejections','choose_tiles','choose_triples_examined','choose_triples_total','choose_valid_triples','complete_census','effective_transition_count','exec_glyph_count','exec_rejections','exec_tiles','exec_triples_examined','exec_triples_total','exec_valid_triples','implicit_absorbing_transitions','input_states','input_symbols','input_transitions','operations','tiles_constructed']
expected_reference=['completed_layers','configurations_processed','duplicate_successors','effective_transition_rows','folded_accept_identities','implicit_accept_successors','off_interval_moves','prefix_acceptance_seen','retained_configuration_rows','transition_checks','transition_rows']
def counters(x):
 if type(x)is dict:
  for y in x.values():counters(y)
 else:nat(x)
for role,r in ret:
 if role=='compiler':
  fields(r['counts'],expected_compiler);assert type(r['counts']['complete_census'])is bool;counters({k:v for k,v in r['counts'].items()if k!='complete_census'});fields(r['counts']['choose_rejections'],['MULTIPLE_HEADS','NO_TRANSITION']);fields(r['counts']['exec_rejections'],['MULTIPLE_HEADS','WALL_ESCAPE']);assert r['counts']['operations']<=r['limits']['max_operations'] and r['counts']['tiles_constructed']<=r['limits']['max_tiles']
 elif role=='reference':
  fields(r['counts'],expected_reference);assert type(r['counts']['prefix_acceptance_seen'])is bool;counters({k:v for k,v in r['counts'].items()if k!='prefix_acceptance_seen'});counters(r['costs']);assert r['costs']['operations']<=r['limits']['max_operations'];assert r['steps_completed']is None and r['complete']is False or type(r['steps_completed'])is int and r['steps_completed']>=0
 elif role=='rows':counters(r['counts'])
 else:counters(r['rule_counts']);counters(r['visits'])
# Plain data shape/type joins for every retained palette symbol/index, including empty names and wall-like string symbols.
palette_extra=[]
for i in[0,1]:
 r=data(A/f'palette-{i}.json')['evidence']['return'];es=r['effective_transitions'];assert [e['index']for e in es]==list(range(len(es)))
 for e in es:
  fields(e,['index','q','read','next','write','move','origin']);nat(e['index']);assert type(e['move'])is int and e['move']in[-1,0,1];assert e['origin']in['EXPLICIT','IMPLICIT_ACCEPT'];assert all(type(e[k])is str for k in['q','read','next','write'])
 for phase,gs in r['glyphs'].items():
  for g in gs:
   x=g['glyph'];assert type(x)is list and x[0]in['plain','wall','normalHead','taggedHead']
   if x[0]=='wall':assert len(x)==1
   elif x[0]=='plain':assert len(x)==2 and type(x[1])is str
   elif x[0]=='normalHead':assert len(x)==3 and all(type(v)is str for v in x[1:])
   else:assert len(x)==4 and all(type(v)is str for v in x[1:3])and type(x[3])is int and 0<=x[3]<len(es)
 for w in r['witnesses']:assert w['transition_index']is None or type(w['transition_index'])is int and 0<=w['transition_index']<len(es)
 palette_extra.append({'palette':i,'effective_transition_rows':len(es),'all_index_symbol_native_types_exact':True,'all624rows_previously_joined':True})
# Declarative full cohort group summary; no transition relation evaluated or new configurations generated.
groups=[]
for mi in[0,1]:
 m=data(A/f'palette-{mi}.json')['evidence']['return']['machine']
 for st in m['states']:
  for hd in range(3):
   xs=[x for x in contexts if x['machine']==mi and x['initial']['state']==st and x['initial']['head']==hd];assert len(xs)==8
   groups.append({'machine':mi,'state':st,'head':hd,'contexts':[x['context']for x in xs],'all_eight_saved_tapes_reviewed':True,'configuration_rows_by_layer':[sum(len(x['reference']['return']['layers'][k]['configurations'])for x in xs)for k in range(3)],'accepting_final_contexts':sum(x['rows']['return']['accepts']for x in xs),'disposition':'PASS_EVERY_MEMBER_NOT_SAMPLED'})
base=sup['worker_result']['costs_before_result_serialization'];post=sup['custody']['worker_terminal']['post_readback_costs'];child=sup['custody']['child'];census=sup['census'];assert len(groups)==15
supplement=save('qualification-001-exact-counter-types-palette-index-and-allcontext-group-joins-v1.json',{'schema':'B-qualification-001-additional-passive-counter-index-group-joins-v1','decision':'PASS','structured_receipts':305,'legacy_boolean_returns':12,'all_exact_counter_schema_and_nonbool_types':True,'all_compiler_reference_operation_counters_within_declared_limits':True,'palette_index_symbol_types':palette_extra,'all15_groups_cover120contexts':groups,'parent_complete_support':pin(S),'method':'Data-only native types/schema/arithmetic and equality against saved indexes. No machine transition, rule, or palette generation/evaluation.','administrative_stops':[{'attempt':'passive_whole_saved_case_join_v1.py','meaning':'An administrative syntax typo was corrected before any execution of that script; then a complete-data join stopped on an overstrong assumption that UNKNOWN compiler machine metadata must be null. No subject code or actual was run/changed, no earlier PASS artifact emitted.'},{'attempt':'passive_whole_saved_case_join_v2.py','meaning':'Corrected only that administrative assumption: UNKNOWN exports no partial effective_transitions/glyphs/palette/witnesses, while C02 legitimately retains normalized machine+hash. The complete final data joins pass.'}],'subject_calls':0})
findings=[
 {'id':'WHOLE_CUSTODY','decision':'PASS','detail':'Authoritative Root receipt binds one original chunk be29eb, exit0 and no session. Complete616-byte outer stdout, empty outer stderr, custody/worker result/logs/tails/current plan/A6/consumed/rawrefs join. All22 actual files authenticated, plus two external captures; no missing or extra actual original.'},
 {'id':'SOURCE_RUNTIME_ONCE','decision':'PASS','detail':'Current source7/metadata4/D90 pins match complete saved result and current readback. Plan3341/591b... and exact A6/current consumed7 associations are intact. Owned wait true, child exit0, both EOF, group gone, no cleanup errors/signals/fault. Sole authority permanently spent; no retry.'},
 {'id':'FOL40','decision':'PASS','detail':'Every full retained typed request/return/hash matches declared control and exact status:16VERIFIED,20REJECTED,4UNKNOWN_BUDGET. Eight-rule counters/visits/error-line/limits coherent, complete request native types retained including bool and tuple refusals. Positive capture-free/alpha/shadowing controls and negative capture/freshness/unknown/arity/closed-axiom/reference/target controls hand reviewed. No theorem search performed.'},
 {'id':'LEGACY12','decision':'PASS','detail':'All12 declared compatible valid checks returned exacttrue; full adapted tuple-valued proof/target and signature/axiom request hashes and no-mutation assertions join. Four alpha/fresh-name positive differences and invalid/resource cases were deliberately outside legacy equality scope;12additional legacy constructor calls are not hidden in317 public-entry census.'},
 {'id':'PALETTE2','decision':'PASS','detail':'Both complete saved compiler results retained in full:354+270=624 unique literal tile rows and624 matching local witnesses. EveryID/N/E/S/W/triple/output/phase/glyph/index association and count schema/native type checked. Empty-state and ordinary string resembling wall remain distinct from wall descriptor. This is a finite control, not a fixed universal FOL palette.'},
 {'id':'CONTEXT120_LAYER360','decision':'PASS','detail':'Every supplied state/head/width3 tape context present once:72+48. Full global reference configuration lists equal corresponding saved row lists at all360 layers. All312 retained witness grids (including step0) checked;560 nonempty halfstep rows/2800 literal placements join exact palette IDs, previous-row triples, horizontal edges, walls, alternating phase, head/normal finalconfiguration. No successor sets were recomputed.'},
 {'id':'ADDITIONAL17','decision':'PASS','detail':'Allsix paired malformed machines rejected by compiler and reference. Two compiler, two reference and three row resource controls remain UNKNOWN, four full wire mutants rejected. Every typed request/full shared compiled argument resolution/return hash/unchanged input assertion retained. W07 uses saved context48 complete baseline83245operations+fixed16=83261, requests1000000steps, returns UNKNOWN with layers/accepts null; no empty-frontier success promotion.'},
 {'id':'CALLS_REQUESTS_AND_ALL_VALUES','decision':'PASS','detail':'Complete317-entry census independently counted:40FOL/12legacy/10compiler/128reference/127rows, plus explicitly declared12legacy constructors. Every saved current request image/full resolved arguments/return hash authenticated and every actual JSON body strictly parsed/canonical-byte-joined; full mutation deltas retained. All-current-state comparisons are passive saved-value joins, not a component evaluator replay.'},
 {'id':'RESOURCES','decision':'PASS','detail':'All originals individually<=8MiB, actual22 plus external2<=64, total2415466B<=32MiB and full logs<=1MiB. Worker elapsed pre-result0.9710830000112765s and post-readback0.9787630419887137s; observer late main-entry1.0288090410176665s, post-Popen-to-wait1.0047993340122048s are distinct origins. Child lifetime HWM51036160B, workerSELF50970624B, observerSELF43859968B; observational gates, not hard quotas/simultaneous/tree peaks. No cross-origin clock inequality or performance claim.'},
 {'id':'SCIENTIFIC_SCOPE','decision':'PASS_WITH_EXPLICIT_LIMITS','detail':'Whole current authored regression/control qualifies only the five declared components on this finite cohort. VERIFIED means derivability relative to exactly supplied finite closed axioms; REJECTED means malformed/invalid submitted certificate, UNKNOWN means resource refusal. No automatic proof discovery, PA induction/axiom recognition, Hilbert geometry theorem, fixed universal proof palette, GCTS search or comparative speed evidence.'}
]
folshort=[{'id':r['id'],'status':r['evidence']['return']['status'],'reason':r['evidence']['return']['reason']}for r in fol]
review=save('qualification-001-complete-independent-whole-saved-evidence-review-v1.json',{'schema':'B-qualification-001-complete-independent-whole-saved-evidence-review-v1','decision':'PASS_COMPLETE_CURRENT_COHORT_ONLY','complete_review':True,'blockers':[],'prefrozen_expectations':pin(O/'qualification-001-prefrozen-whole-saved-evidence-review-expectations-v1.json'),'full_support':pin(S),'additional_full_type_group_support':supplement,'actual_result':pin(A/'worker-result.json'),'custody':pin(A/'custody.json'),'original_owned_exec':pin(P/'root/qualification-001-original-owned-exec-v1.json'),'outer_stdout':pin(P/'root/qualification-001-outer-stdout.bin'),'outer_stderr':pin(P/'root/qualification-001-outer-stderr.bin'),'whole_census':census,'whole_findings':findings,'all40FOL_dispositions':folshort,'all17additional_dispositions':sup['additional17_complete_dispositions'],'all120context_review':'Every complete context and all360 layers have separate full_record/configuration/witness hashes and count/request/return/edge/grid dispositions in full_support; all15 complete groups are in additional support. No subset selected.','resource_values':{'worker_pre_result':base,'worker_post_readback':post,'observer_late':sup['custody']['late_costs'],'child_post_Popen_to_wait_seconds':child['post_Popen_return_to_owned_wait_seconds'],'child_lifetime_highwater_bytes':child['child_lifetime_highwater_bytes'],'all_actual_plus_outer_bytes':census['owned_named_bytes']+census['outer_stdout_bytes']},'administrative_join_precision':'Administrative joins initially assumed UNKNOWN compiler machine metadata and noncomplete reference steps_completed had narrower null/integer behavior; corrected to their declared no-partial-palette and noncomplete/null boundaries. Current support is complete PASS; no subject replay, no earlier admission and no original mutation.','independence':'Root announced own totals after this peer prefroze and independently completed all saved-data joins; Root new review/provisional visual data were not read or used.','activities':{'subject_imports_helpers_checkers_simulators_compilers_decoders_codecs':0,'scientific_evaluator_or_fixture_replay':0,'new_scientific_calls':0,'actual_mutations':0,'authority_retry_or_new_grant':0,'only_stdlib_saved_JSON_hash_native_type_key_list_arithmetic_equality_and_hand_review':True},'scope_and_admission':'Independent whole-case PASS for current finite317-entry cohort only; Root complete adoption remains separate. Source3/authority/case permanently spent; no next experiment or publication authority.','terminal_state':'IDLE'})
print(json.dumps({'review':review,'full_support':pin(S),'supplement':supplement},indent=2))
