from pathlib import Path
import json,hashlib,math,re,stat,collections
P=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1');A=P/'actual/qualification-001';O=Path('/private/tmp/gcts-B-qualification-001-whole-actual-review-v1')
def enc(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode('ascii')
def pretty(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def eq(a,b):assert enc(a)==enc(b)
def fields(x,ks):assert type(x)is dict and set(x)==set(ks),(set(x)if type(x)is dict else type(x),ks)
def nat(x):assert type(x)is int and x>=0,x
raw_inventory={};value_counts=collections.Counter()
def count(x):
 value_counts[type(x).__name__]+=1
 if type(x)is dict:
  assert all(type(k)is str for k in x)
  for y in x.values():count(y)
 elif type(x)is list:
  for y in x:count(y)
 elif type(x)is float:assert math.isfinite(x)
 else:assert x is None or type(x)in(str,int,bool)
def pin(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':h(b)}
def read(path,canonical=False):
 b=path.read_bytes();p=pin(path);raw_inventory[str(path)]=p
 if canonical:
  o=parse(b);assert enc(o)==b;count(o);return o
 return b

def parse(b):
 def pairs(xs):
  d={}
  for k,v in xs:assert k not in d;d[k]=v
  return d
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(AssertionError(x)))
def ref(r):
 fields(r,['path','bytes','sha256']);assert type(r['path'])is str and type(r['bytes'])is int and r['bytes']>=0 and type(r['sha256'])is str and re.fullmatch('[0-9a-f]{64}',r['sha256'])
 p=Path(r['path']);assert p.is_absolute() and str(p)==r['path'] and '..'not in p.parts and all(not q.is_symlink()for q in(p,)+tuple(p.parents));s=p.stat();assert stat.S_ISREG(s.st_mode)and s.st_nlink==1
 b=read(p);assert len(b)==s.st_size==r['bytes'] and h(b)==r['sha256'];return b

def type_image_data(x):
 # Decode only retained declarative type-image data, preserving native type labels; no AST grammar/rule evaluator.
 assert type(x)is dict and type(x.get('type'))is str;t=x['type']
 if t in ('dict','list','tuple'):
  fields(x,['type','items']);assert type(x['items'])is list
  if t=='dict':
   y={}
   for pair in x['items']:
    assert type(pair)is list and len(pair)==2;k=type_image_data(pair[0]);v=type_image_data(pair[1]);assert k not in y;y[k]=v
   return y
  a=[type_image_data(v)for v in x['items']];return a if t=='list'else tuple(a)
 fields(x,['type','value']);v=x['value'];assert type(v).__name__==t and (v is None or type(v)in(str,int,float,bool)),(t,v)
 return v

def image(x):
 if type(x)is dict:return {'type':'dict','items':[[image(k),image(v)]for k,v in x.items()]}
 if type(x)in(list,tuple):return {'type':type(x).__name__,'items':[image(v)for v in x]}
 return {'type':type(x).__name__,'value':x}

# Exact closed administrative transport.
plan=read(P/'root/component-qualification-once-plan-001.json',True);planref=pin(P/'root/component-qualification-once-plan-001.json');caps=plan['limits'];case=plan['case_id'];assert case=='qualification-001' and plan['actual_dir']==str(A)
auth=read(P/'root/component-qualification-once-authority-001.json',True);authref=pin(P/'root/component-qualification-once-authority-001.json')
eq(auth,{'schema':'Root-FOL-NTM-component-once-authority-v2','authorized':True,'uses':1,'case_id':case,'plan':planref,'observer':plan['sources']['observer']})
consume=read(A/'CONSUMED.json',True);consumeref=pin(A/'CONSUMED.json');eq(consume,{'schema':'Root-FOL-NTM-component-once-consumed-v2','uses':1,'case_id':case,'plan':planref,'authority':authref,'observer':plan['sources']['observer'],'meaning':'exclusive spent marker before the sole child launch; failures remain spent'})
owned=parse(read(P/'root/qualification-001-original-owned-exec-v1.json'));count(owned);assert owned['invocations']==1 and owned['original_exit_code']==0 and owned['original_chunk_id']=='be29eb' and owned['owned_session']is None and owned['authority_state']=='SPENT_NEVER_REEXECUTE'
outer_raw=read(Path(owned['stdout_path']));outer=parse(outer_raw);assert enc(outer)==outer_raw and read(Path(owned['stderr_path']))==b'';count(outer)
cust=read(A/'custody.json',True);result=read(A/'worker-result.json',True)
fields(outer,['schema','status','case_id','custody','admitted_result_candidate','owned_file_count','owned_named_bytes','requires_authoritative_exit_zero']);assert outer['schema']=='GCTS-FOL-NTM-owned-outer-v1' and outer['status']=='COMPLETE_NORMAL' and outer['requires_authoritative_exit_zero']is True;eq(outer['custody'],pin(A/'custody.json'));eq(outer['admitted_result_candidate'],pin(A/'worker-result.json'))
fields(cust,['schema','status','version','case_id','plan','authority','consumed','Source_and_runtime_pre_post_exact','child','captures','worker_terminal','result','all_prior_owned_files','late_costs','scopes']);assert cust['status']=='NORMAL_TRANSPORT_CANDIDATE' and cust['version'].endswith('-v3') and cust['Source_and_runtime_pre_post_exact']is True
eq(cust['plan'],planref);eq(cust['authority'],authref);eq(cust['consumed'],consumeref)
child=cust['child'];assert child['child_exit']==0 and child['fault']is None and child['supervisor_exception']is None and child['cleanup_errors']==[] and child['cleanup_signals']==[] and child['owned_wait_complete']is True and child['process_group_gone']is True and child['log_eof']=={'stdout':True,'stderr':True} and child['combined_log_overflow']is False;nat(child['pid']);assert 0<child['child_lifetime_highwater_bytes']<=caps['child_rss_bytes']
for r in cust['all_prior_owned_files']:ref(r)
actualpins=[pin(p)for p in sorted(A.iterdir())];assert len(actualpins)==outer['owned_file_count']==22;assert all(p['bytes']<=caps['body_bytes']for p in actualpins);assert sum(p['bytes']for p in actualpins)==outer['owned_named_bytes'];assert len(actualpins)+2<=caps['max_output_files'] and sum(p['bytes']for p in actualpins)+sum(len(read(Path(owned[k])))for k in ['stdout_path','stderr_path'])<=caps['total_output_bytes'];assert cust['all_prior_owned_files']==[r for r in actualpins if r['path']!=str(A/'custody.json')]
for k,r in cust['captures'].items():ref(r)
stdout=ref(cust['captures']['stdout']);stderr=ref(cust['captures']['stderr']);assert stderr==b'' and ref(cust['captures']['stdout_tail'])==stdout[-65536:] and ref(cust['captures']['stderr_tail'])==b'';assert child['stream_totals']=={'stdout':len(stdout),'stderr':0};term=parse(stdout);assert enc(term)==stdout;eq(term,cust['worker_terminal']);eq(term['plan'],planref);eq(term['result'],pin(A/'worker-result.json'));assert term['case_id']==outer['case_id']==cust['case_id']==result['case_id']==case;assert term['status']=='COMPLETE_PASS_RESULT_WRITTEN'
fields(result,['schema','version','status','case_id','plan','source_guards','metadata_guards','cohort','counts','evidence','costs_before_result_serialization','scope']);assert result['schema']=='GCTS-FOL-NTM-component-qualification-result-v1' and result['status']=='COMPLETE_PASS' and result['version'].endswith('-v3');eq(result['plan'],planref);eq(result['source_guards'],plan['sources']);eq(result['metadata_guards'],plan['metadata']);assert result['cohort']==plan['cohort']
for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python']]:ref(r)
expectedcalls={'fol':40,'legacy':12,'compiler':10,'reference':128,'rows':127};eq(result['counts'],{'additional_NTM_controls':17,'fol_controls':40,'layers_per_context':3,'legacy_compatible_controls':12,'normal_NTM_contexts':120,'palettes':2,'public_calls':expectedcalls});eq(term['public_calls'],expectedcalls)
pre=result['costs_before_result_serialization'];post=term['post_readback_costs'];assert 0<=pre['elapsed_seconds']<=post['elapsed_main_entry_seconds']<=caps['worker_seconds'];assert 0<pre['self_lifetime_highwater_bytes']<=post['self_lifetime_highwater_bytes']<=child['child_lifetime_highwater_bytes'];assert pre['worker_budget_callbacks']<=post['worker_budget_callbacks'];assert 0<=cust['late_costs']['observer_main_entry_elapsed_seconds']<=caps['observer_seconds']
for r in result['evidence']['all_prior_outputs']:ref(r)
worker_files=[r for r in actualpins if Path(r['path']).name not in ['CONSUMED.json','custody.json','worker-stdout.bin','worker-stderr.bin','worker-stdout-tail.bin','worker-stderr-tail.bin']];eq(result['evidence']['all_prior_outputs'],[r for r in result['evidence']['all_prior_outputs']]);assert set(r['path']for r in worker_files)==set(r['path']for r in result['evidence']['all_prior_outputs'])|{str(A/'worker-result.json')};assert len(worker_files)==16

# Whole scientific receipt/schema/retained request hash joins, never evaluate scientific rules.
callrows=[]
def evidence(e,role,label):
 base={'input_unchanged','return','return_sha256'}
 assert base<=set(e) and e['input_unchanged']is True and h(enc(e['return']))==e['return_sha256'];r=e['return'];natvals=[]
 if 'request_typed'in e:
  assert h(enc(e['request_typed']))==e['request_typed_sha256'];args=type_image_data(e['request_typed']);eq(image(args),e['request_typed'])
 else:
  fields(e['request'],['machine','compiled_artifact','compiled_return_sha256','initial','steps','limits']);q=e['request'];obj=parse(ref(q['compiled_artifact']));compiled=obj['evidence']['return']if'evidence'in obj else obj['compiled'];assert h(enc(compiled))==q['compiled_return_sha256'];args=[q['machine'],compiled,q['initial'],q['steps'],q['limits']];assert h(enc(args))==e['resolved_full_request_sha256']
 if role=='fol':
  fields(r,['schema','status','reason','checked_lines','error_line','rule_counts','visits','limits','scope']);assert r['schema']=='GCTS-independent-FOL-check-receipt-v1';fields(r['rule_counts'],['axiom','tautology','refl','instantiate','distribute','eq_subst','mp','generalize']);fields(r['visits'],['operations','by_kind','max_depth_seen','tautology_assignments','tautology_atoms_max']);assert sum(r['visits']['by_kind'].values())==r['visits']['operations'];assert r['checked_lines']<=len(args[1]);assert sum(r['rule_counts'].values())<=len(args[1]);assert r['error_line']is None or type(r['error_line'])is int and 0<=r['error_line']<len(args[1]);eq(r['limits'],None if label=='F36'else args[3])
  if r['status']=='VERIFIED':assert r['reason']=='WHOLE_PROOF_VERIFIED' and r['checked_lines']==len(args[1]) and r['error_line']is None;eq(args[1][-1]['formula'],args[2])
  for v in list(r['rule_counts'].values())+list(r['visits']['by_kind'].values())+[r['checked_lines'],r['visits']['operations'],r['visits']['max_depth_seen'],r['visits']['tautology_assignments'],r['visits']['tautology_atoms_max']]:nat(v)
 elif role=='compiler':
  fields(r,['schema','version','status','reason','machine','machine_sha256','effective_transitions','glyphs','palette','witnesses','counts','limits']);assert r['schema']=='L-finite-NTM-translation-Wang-compile-result-v1';eq(r['limits'],args[1]);assert type(r['counts']['complete_census'])is bool
  if r['status']!='COMPLETE':assert all(r[k]is None for k in ['machine','machine_sha256','effective_transitions','glyphs','palette','witnesses']) and r['counts']['complete_census']is False
 elif role=='reference':
  fields(r,['schema','status','reason','complete','steps_completed','layers','partial_layer','acceptance','input','limits','counts','costs','scope']);assert r['schema']=='GCTS-independent-finite-NTM-simulation-v2';eq(r['limits'],args[3]);fields(r['costs'],['operations','by_kind']);assert sum(r['costs']['by_kind'].values())==r['costs']['operations'];fields(r['acceptance'],['ever','at_requested_step','witness']);assert type(r['complete'])is bool
  if r['status']=='COMPLETE':assert r['complete']is True and r['partial_layer']is None;eq(r['input']['initial'],args[1]);eq(r['input']['machine'],args[0]);assert r['steps_completed']==args[2]
  else:assert r['complete']is False and r['acceptance']['ever']is None and r['acceptance']['at_requested_step']is None
 elif role=='rows':
  fields(r,['schema','status','reason','layers','accepts','counts','scope']if'scope'in r else['schema','status','reason','layers','accepts','counts']);assert r['schema']=='Root-independent-Wang-rows-v2';fields(r['counts'],['operations','candidate_trials','row_solutions','distinct_rows','halfsteps','palette_tiles'])
  if r['status']!='COMPLETE':assert r['layers']is None and r['accepts']is None
 else:assert False
 callrows.append({'role':role,'label':label,'status':r['status'],'return_sha256':e['return_sha256'],'request_sha256':e.get('request_typed_sha256',e.get('resolved_full_request_sha256')),'all_saved_request_return_fields_joined':True})
 return args

fol=read(A/'fol-controls.json',True);fields(fol,['schema','scope','controls']);assert len(fol['controls'])==40;fstats=collections.Counter();foltable=[]
census=parse(read(P/'implementation-C/component-qualification-exact-controlled-census-v3.json'));count(census)
for r,decl in zip(fol['controls'],census['fol_controls']):
 fields(r,['id','label','expected_status','legacy_compatible','evidence']);eq({k:r[k]for k in ['id','label','expected_status','legacy_compatible']},{k:decl[k]for k in ['id','label','expected_status','legacy_compatible']});args=evidence(r['evidence'],'fol',r['id']);ret=r['evidence']['return'];assert ret['status']==r['expected_status'];fstats[ret['status']]+=1
 if r['legacy_compatible']:
  e=r['evidence'];assert e['legacy_return']is True and e['legacy_input_unchanged']is True and h(enc(e['legacy_request_typed']))==e['legacy_request_typed_sha256'];l=type_image_data(e['legacy_request_typed']);eq(image(l),e['legacy_request_typed']);eq(l[0],[args[0]['functions'],args[0]['predicates'],args[0]['axioms']]);eq(l[1],args[1]);eq(l[2],args[2]);assert type(l[1])is tuple and type(l[2])is tuple;callrows.append({'role':'legacy','label':r['id'],'status':'TRUE_COMPATIBLE_CHECK','request_sha256':e['legacy_request_typed_sha256'],'all_saved_request_return_fields_joined':True})
 foltable.append({'id':r['id'],'label':r['label'],'status':ret['status'],'reason':ret['reason'],'checked_lines':ret['checked_lines'],'error_line':ret['error_line'],'rule_counts':ret['rule_counts'],'visits':ret['visits'],'request_typed_sha256':r['evidence']['request_typed_sha256'],'return_sha256':r['evidence']['return_sha256'],'legacy_compatible':r['legacy_compatible'],'disposition':'PASS_CURRENT_CONTROL'})
assert dict(fstats)=={'VERIFIED':16,'REJECTED':20,'UNKNOWN_BUDGET':4}

# All palette literal rows and their retained local wire/witness associations; no local transition generation.
palettes=[];paltable=[]
def literal(x):return json.dumps(x,ensure_ascii=True,separators=(',',':'))
for i in [0,1]:
 saved=read(A/f'palette-{i}.json',True);fields(saved,['label','evidence']);args=evidence(saved['evidence'],'compiler','PALETTE'+str(i));r=saved['evidence']['return'];assert r['status']=='COMPLETE' and r['counts']['complete_census']is True;eq(r['machine'],args[0]);assert h(enc(r['machine']))==r['machine_sha256'];n=len(r['palette']);assert n==len(r['witnesses'])==r['counts']['tiles_constructed']==r['counts']['choose_tiles']+r['counts']['exec_tiles'];assert n==[354,270][i]
 table={};wits={w['tile_id']:w for w in r['witnesses']};assert len(wits)==n
 for t in r['palette']:
  fields(t,['id','N','E','S','W']);assert t['id']not in table;tid=parse(t['id']);assert literal(tid)==t['id']and len(tid)==6 and tid[0]=='T';phase=tid[1];assert phase in['CHOOSE','EXEC'];a,b,c,out=tid[2:];other='EXEC'if phase=='CHOOSE'else'CHOOSE'
  eq(parse(t['N']),['V',phase,b]);eq(parse(t['S']),['V',other,out]);eq(parse(t['W']),['H',phase,a,b]);eq(parse(t['E']),['H',phase,b,c]);w=wits[t['id']];fields(w,['tile_id','phase','triple','output','action','transition_index']);assert w['phase']==phase;eq(w['triple'],[a,b,c]);eq(w['output'],out)
  table[t['id']]={'tile':t,'descriptor':tid}
 for phase in['CHOOSE','EXEC']:
  gs=r['glyphs'][phase];assert len(gs)==r['counts'][phase.lower()+'_glyph_count'];assert len({g['id']for g in gs})==len(gs)
  for g in gs:fields(g,['id','glyph']);assert literal(g['glyph'])==g['id']
 for k in ['choose','exec']:
  ct=r['counts'];assert ct[k+'_triples_total']==ct[k+'_glyph_count']**3 and ct[k+'_triples_examined']==ct[k+'_triples_total'];assert ct[k+'_valid_triples']+sum(ct[k+'_rejections'].values())==ct[k+'_triples_total'];assert ct[k+'_tiles']==sum(1 for t in table.values()if t['descriptor'][1]==k.upper())
 palettes.append({'saved':saved,'return':r,'table':table});paltable.append({'machine':i,'label':saved['label'],'artifact':pin(A/f'palette-{i}.json'),'return_sha256':saved['evidence']['return_sha256'],'full_palette_tile_count':n,'literal_and_witness_rows_joined':n,'counts':r['counts'],'disposition':'PASS_COMPLETE_RETAINED_PALETTE'})

contexts=[]
for rr in result['evidence']['contexts']:
 obj=read(Path(rr['path']),True);assert obj['schema']=='C-complete-NTM-context-block-v1';contexts.extend(obj['contexts'])
assert [x['context']for x in contexts]==list(range(120));contexttable=[];gridrows=0;gridcells=0;witnesses=0;configuration_rows=0;layer_count=0
for x in contexts:
 fields(x,['context','machine','initial','reference','rows','all_layers_and_literal_witnesses_match']);assert x['all_layers_and_literal_witnesses_match']is True;mi=x['machine'];assert mi==(0 if x['context']<72 else 1);machine=palettes[mi]['return']['machine'];initial=x['initial'];fields(initial,['state','head','tape']);assert type(initial['head'])is int and 0<=initial['head']<3 and len(initial['tape'])==3 and initial['state']in machine['states'] and all(a in machine['alphabet']for a in initial['tape'])
 ar=evidence(x['reference'],'reference','CONTEXT'+str(x['context']));aw=evidence(x['rows'],'rows','CONTEXT'+str(x['context']));eq(ar[0],machine);eq(ar[1],initial);eq(aw[0],machine);eq(aw[1],palettes[mi]['return']);eq(aw[2],initial);assert ar[2]==aw[3]==2
 refret=x['reference']['return'];rowret=x['rows']['return'];assert refret['status']==rowret['status']=='COMPLETE';assert len(refret['layers'])==len(rowret['layers'])==3 and refret['counts']['completed_layers']==3;assert refret['counts']['retained_configuration_rows']==sum(len(l['configurations'])for l in refret['layers']);assert refret['acceptance']['ever']==refret['acceptance']['at_requested_step']==rowret['accepts'];layer_summaries=[]
 for step,(rl,wl)in enumerate(zip(refret['layers'],rowret['layers'])):
  fields(rl,['step','count','accepting_count','configurations']);fields(wl,['step','configurations','witnesses']);assert rl['step']==wl['step']==step;eq(rl['configurations'],wl['configurations']);assert rl['count']==len(rl['configurations'])==len(wl['witnesses']);assert rl['accepting_count']==sum(c['state']in machine['accept']for c in rl['configurations']);assert len({enc(c)for c in rl['configurations']})==rl['count'];eq([w['configuration']for w in wl['witnesses']],rl['configurations']);configuration_rows+=rl['count'];layer_count+=1
  if step==0:eq(rl['configurations'],[initial])
  for c in rl['configurations']:
   fields(c,['state','head','tape']);assert type(c['head'])is int and 0<=c['head']<3 and c['state']in machine['states'] and len(c['tape'])==3 and all(s in machine['alphabet']for s in c['tape'])
  for w in wl['witnesses']:
   fields(w,['configuration','tile_rows']);assert len(w['tile_rows'])==2*step;previous=[['wall']]+[(['normalHead',initial['state'],s]if j==initial['head']else['plain',s])for j,s in enumerate(initial['tape'])]+[['wall']];witnesses+=1
   for half,ids in enumerate(w['tile_rows']):
    assert len(ids)==5;phase='CHOOSE'if half%2==0 else'EXEC';ts=[palettes[mi]['table'][tid]for tid in ids];outputs=[]
    for j,t in enumerate(ts):
     d=t['descriptor'];assert d[1]==phase;eq(d[2:5],[previous[j-1]if j else['wall'],previous[j],previous[j+1]if j<4 else['wall']]);outputs.append(d[5])
     if j:assert ts[j-1]['tile']['E']==t['tile']['W']
    assert outputs[0]==outputs[-1]==['wall'];headtag='taggedHead'if phase=='CHOOSE'else'normalHead';assert sum(g[0]==headtag for g in outputs)==1;previous=outputs;gridrows+=1;gridcells+=5
   if step:
    head=[(j,g)for j,g in enumerate(previous[1:-1])if g[0]=='normalHead'];assert len(head)==1;j,g=head[0];decoded={'state':g[1],'head':j,'tape':[v[2]if v[0]=='normalHead'else v[1]for v in previous[1:-1]]};eq(decoded,w['configuration'])
  layer_summaries.append({'step':step,'configuration_count':rl['count'],'accepting_count':rl['accepting_count'],'full_configurations_sha256':h(enc(rl['configurations'])),'witnesses':len(wl['witnesses']),'witnesses_sha256':h(enc(wl['witnesses']))})
 contexttable.append({'context':x['context'],'machine':mi,'initial':initial,'layers':layer_summaries,'accepts':rowret['accepts'],'reference_sha256':x['reference']['return_sha256'],'rows_sha256':x['rows']['return_sha256'],'full_record_sha256':h(enc(x)),'rows_counts':rowret['counts'],'reference_counts':refret['counts'],'disposition':'PASS_ALL_LAYERS_AND_LITERAL_GRID_JOINS'})
# Coverage as data census only: all actual supplied state/head/tape tuples, no successor simulation.
for mi,size in [(0,72),(1,48)]:
 rows=[x for x in contexts if x['machine']==mi];assert len(rows)==size and len({enc(x['initial'])for x in rows})==size
 for state in palettes[mi]['return']['machine']['states']:
  for head in range(3):assert sum(x['initial']['state']==state and x['initial']['head']==head for x in rows)==8

extras=read(A/'ntm-wire-resource-coherence-controls.json',True);fields(extras,['schema','controls','shared_palette']);eq(extras['shared_palette'],pin(A/'palette-0.json'));assert len(extras['controls'])==17;extratable=[]
for x in extras['controls']:
 id=x['id'];outcomes=[]
 if id.startswith('N'):
  for role in['compiler','reference']:
   args=evidence(x[role],role,id);assert x[role]['return']['status']==x['expected_status']=='REJECTED';outcomes.append({'role':role,'status':x[role]['return']['status'],'reason':x[role]['return']['reason']})
 else:
  role={'C':'compiler','R':'reference','W':'rows'}[id[0]];args=evidence(x['evidence'],role,id);assert x['evidence']['return']['status']==x['expected_status'];outcomes.append({'role':role,'status':x['evidence']['return']['status'],'reason':x['evidence']['return']['reason']})
 if id=='W07-empty-frontier-tail':
  base=contexts[48];eq(x['baseline']['initial'],base['initial']);assert x['baseline']['context']==48;eq(x['baseline']['return'],base['rows']['return']);assert x['baseline']['return_sha256']==base['rows']['return_sha256'];assert args[3]==1000000 and args[4]['max_operations']==x['baseline']['return']['counts']['operations']+16==83261;assert x['evidence']['return']['layers']is None and x['evidence']['return']['counts']['operations']<=83261
 extratable.append({'id':id,'outcomes':outcomes,'whole_record_sha256':h(enc(x)),'disposition':'PASS_DECLARED_CONTROL'})
assert collections.Counter(x['role']for x in callrows)==expectedcalls and len(callrows)==317
mutants=[]
def difference(a,b,path=''):
 if type(a)is not type(b):return [{'path':path,'old':a,'new':b}]
 if type(a)is dict:
  assert set(a)==set(b);return [z for k in a for z in difference(a[k],b[k],path+'/'+k)]
 if type(a)is list:
  assert len(a)==len(b);return [z for i,(aa,bb)in enumerate(zip(a,b))for z in difference(aa,bb,path+'/'+str(i))]
 return []if a==b else[{'path':path,'old':a,'new':b}]
for label in['phase','wall','tag-bool','tag-float']:
 f=read(A/f'palette-{label}-mutant.json',True);fields(f,['authored_mutation','compiled','parent']);eq(f['parent'],pin(A/'palette-0.json'));diff=difference(palettes[0]['return'],f['compiled']);assert diff;mutants.append({'artifact':pin(A/f'palette-{label}-mutant.json'),'authored_mutation':f['authored_mutation'],'all_differences':diff})
# Complete physical final census, with source/runtime rehash current association again; no body mutation.
for r in actualpins:ref(r)
for r in list(plan['sources'].values())+list(plan['metadata'].values())+[plan['python'],planref,authref,consumeref]:ref(r)
support={'schema':'B-qualification-001-complete-passive-whole-saved-evidence-support-v1','status':'ALL_ASSERTED_PASSIVE_JOINS_PASS','prefrozen_expectations':pin(O/'qualification-001-prefrozen-whole-saved-evidence-review-expectations-v1.json'),'actual_originals':actualpins,'all_authenticated_raw_inventory':sorted(raw_inventory.values(),key=lambda r:r['path']),'original_owned_exec':owned,'outer':outer,'custody':cust,'worker_result':result,'all317_call_joins':callrows,'FOL40_complete_dispositions':foltable,'palette2_complete_dispositions':paltable,'context120_layer360_complete_dispositions':contexttable,'additional17_complete_dispositions':extratable,'mutant4_complete_deltas':mutants,'census':{'actual_physical_files':len(actualpins),'plus_outer_capture_files':len(actualpins)+2,'owned_named_bytes':sum(r['bytes']for r in actualpins),'outer_stdout_bytes':len(outer_raw),'worker_stdout_bytes':len(stdout),'aggregate_public_calls':len(callrows),'public_calls':dict(collections.Counter(x['role']for x in callrows)),'FOL_statuses':dict(fstats),'complete_normal_layers':layer_count,'retained_configuration_rows':configuration_rows,'retained_witnesses':witnesses,'literal_grid_rows':gridrows,'literal_grid_cells':gridcells,'all_strictly_parsed_JSON_values_by_type':dict(value_counts)},'method':'Stdlib strict JSON/hash/full typed-image and stored full-request resolution/structural schema/list/equality/arithmetic joins only. Literal palette strings and saved witness grids parsed as data and joined; no successor sets or tile palettes generated, no checker/simulator/compiler/row/helper/fixture replay. FOL status/rule soundness relies on authenticated reviewed actual checker; no new rule reclassification.','subject_calls_imports_codeexecution_replays':0}
b=pretty(support);q=O/'qualification-001-complete-passive-whole-saved-evidence-support-v1.json';q.write_bytes(b);assert q.read_bytes()==b;print(json.dumps({'support':pin(q),'census':support['census']},indent=2))
