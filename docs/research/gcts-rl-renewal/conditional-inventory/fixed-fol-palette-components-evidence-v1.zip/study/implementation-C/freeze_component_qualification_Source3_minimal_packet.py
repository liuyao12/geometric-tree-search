"""Static Source3 preservation/ABI authoring; never executes subject code."""
import ast
import builtins
import difflib
import hashlib
import json
import pathlib
import re
import symtable

P=pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-C')
def enc(x):return (json.dumps(x,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':h(b)}
def save(name,x):
 p=P/name
 with p.open('xb') as f:f.write(enc(x))
 return pin(p)
def apply(raw,patch):
 old=raw.decode().splitlines(keepends=True);out=[];at=0;lines=patch.decode().splitlines(keepends=True);i=2
 while i<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i]);assert m
  start=int(m[1])-1;a=b=0;out+=old[at:start];at=start;i+=1
  while i<len(lines) and not lines[i].startswith('@@ '):
   z=lines[i];assert z[0] in ' +-'
   if z[0] in ' -':assert old[at]==z[1:];at+=1;a+=1
   if z[0] in ' +':out.append(z[1:]);b+=1
   i+=1
  assert a==int(m[2] or '1') and b==int(m[4] or '1')
 out+=old[at:];return ''.join(out).encode()
def helpers(t,raw):
 result={};lines=raw.splitlines(keepends=True)
 def scan(n,prefix=''):
  for z in n.body:
   if isinstance(z,(ast.FunctionDef,ast.ClassDef)):
    name=prefix+z.name;b=b''.join(lines[z.lineno-1:z.end_lineno]);result[name]={'line':z.lineno,'end_line':z.end_lineno,'raw_bytes':len(b),'raw_sha256':h(b),'AST_sha256':h(ast.dump(z).encode()),'positioned_AST_sha256':h(ast.dump(z,include_attributes=True).encode()),'signature':None if isinstance(z,ast.ClassDef) else ast.unparse(z.args)};scan(z,name+'.')
 scan(t);return result
flags=[('assigned','is_assigned'),('free','is_free'),('global','is_global'),('imported','is_imported'),('local','is_local'),('nonlocal','is_nonlocal'),('parameter','is_parameter'),('referenced','is_referenced')]
def scopes(raw,path):
 t=symtable.symtable(raw.decode(),str(path),'exec');out=[];tables=[]
 def scan(s,p):
  entries=[{'name':n,'true_flags':[k for k,m in flags if getattr(s.lookup(n),m)()]} for n in sorted(s.get_identifiers())]
  out.append({'path':p,'line':s.get_lineno(),'type':s.get_type(),'entries':entries,'entry_fingerprint':h(enc(entries))});tables.append(s)
  for i,c in enumerate(s.get_children()):scan(c,p+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
 scan(t,'module');defined={n for n in t.get_identifiers() if t.lookup(n).is_assigned() or t.lookup(n).is_imported()};unknown=sorted({n for s in tables for n in s.get_identifiers() if s.lookup(n).is_global() and s.lookup(n).is_referenced() and n not in defined and n not in vars(builtins) and n not in ('__name__','__file__')});assert not unknown
 return out
preserved=[];current={};source_trees={}
for role in ['worker','observer']:
 old=P/f'component_qualification_{role}_v2.py';new=P/f'component_qualification_{role}_v3.py';a=old.read_bytes();b=new.read_bytes();ta=ast.parse(a);tb=ast.parse(b);source_trees[role]=tb;code=compile(b,str(new),'exec',dont_inherit=True);del code
 ha,hb=helpers(ta,a),helpers(tb,b);changed=[];identical=[]
 for name,x in ha.items():
  assert name in hb
  (identical if all(x[k]==hb[name][k] for k in ('raw_bytes','raw_sha256','AST_sha256')) else changed).append(name)
 added=sorted(set(hb)-set(ha));assert changed==([] if role=='worker' else ['supervise','verify_terminal','main']);assert added==([] if role=='worker' else ['consumed_validate'])
 if role=='worker':
  restored=b.decode()
  for one,two in [('component_qualification_worker_v3.py','component_qualification_worker_v2.py'),('component_qualification_observer_v3.py','component_qualification_observer_v2.py'),('GCTS-FOL-NTM-COMPONENT-QUALIFICATION-WORKER-v3','GCTS-FOL-NTM-COMPONENT-QUALIFICATION-WORKER-v2')]:assert restored.count(one)==1;restored=restored.replace(one,two)
  assert restored.encode()==a
 forward=''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile=old.name,tofile=new.name,n=3)).encode();inverse=''.join(difflib.unified_diff(b.decode().splitlines(keepends=True),a.decode().splitlines(keepends=True),fromfile=new.name,tofile=old.name,n=3)).encode()
 patchrefs=[]
 for name,data in [(f'component-qualification-{role}-v2-to-v3.patch',forward),(f'component-qualification-{role}-v3-to-v2.patch',inverse)]:
  q=P/name
  with q.open('xb') as f:f.write(data)
  patchrefs.append(pin(q))
 assert apply(a,forward)==b and apply(b,inverse)==a
 assert ast.dump(ast.parse(apply(b,inverse)),include_attributes=True)==ast.dump(ta,include_attributes=True)
 # All nonfunction declarations differ ONLY by the operational VERSION and path strings.
 def declarations(t):return [ast.dump(n) for n in t.body if not isinstance(n,(ast.FunctionDef,ast.ClassDef))]
 mapped=b.decode().replace('component_qualification_worker_v3.py','component_qualification_worker_v2.py').replace('component_qualification_observer_v3.py','component_qualification_observer_v2.py').replace('GCTS-FOL-NTM-COMPONENT-QUALIFICATION-'+role.upper()+'-v3','GCTS-FOL-NTM-COMPONENT-QUALIFICATION-'+role.upper()+'-v2')
 assert declarations(ast.parse(mapped))==declarations(ta)
 preserved.append({'role':role,'predecessor':pin(old),'current':pin(new),'patches':patchrefs,'entire_forward_and_inverse_exact':True,'entire_positioned_AST_inverse_exact':True,'identical_old_raw_plain_AST_helpers':identical,'changed_helpers':changed,'new_helpers':added,'old_helpers':ha,'current_helpers':hb,'whole_AST_sha256':h(ast.dump(tb).encode()),'whole_positioned_AST_sha256':h(ast.dump(tb,include_attributes=True).encode()),'all_symbol_scopes':scopes(b,new),'flag_names':[x[0] for x in flags],'all_omitted_flags_false':True,'unused_compile':'PASS; code object discarded, never executed'})
 current[role]=pin(new)
worker=source_trees['worker'];observer=source_trees['observer']
def const(t,name):return ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name))
for name in ['LIMITS','COMPONENT_PINS','METADATA_PINS','COHORT','PYTHON','CONSUMED_MEANING']:
 assert const(worker,name)==const(observer,name)
 assert const(worker,name)==const(ast.parse((P/'component_qualification_worker_v2.py').read_bytes()),name)
sup=next(n for n in observer.body if isinstance(n,ast.FunctionDef) and n.name=='supervise');launch=[i for i,n in enumerate(sup.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='subprocess.Popen'];assert len(launch)==1 and isinstance(sup.body[launch[0]+1],ast.Try)
waits=[n for n in ast.walk(sup) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='wait'];assert waits and all(any(k.arg=='timeout' for k in n.keywords) for n in waits)
bootstrap=const(observer,'BOOTSTRAP');assert bootstrap==const(ast.parse((P/'component_qualification_observer_v2.py').read_bytes()),'BOOTSTRAP');code=compile(bootstrap,'<retained-byte-bootstrap>','exec',dont_inherit=True);del code
peer=pathlib.Path('/private/tmp/gcts-B-component-observer2-Source-peer-20261027-v1/component-observer2-complete-independent-custody-Source-review-v1.json');assert pin(peer)['sha256']=='07b1d343a5c7928062ff6e4d51be8a1616216fc3ecd94c05c177f1cb574f42ad'
static=save('component-qualification-Source2-Source3-complete-preservation-and-static-v1.json',{'schema':'C-component-qualification-Source2-Source3-complete-preservation-and-static-v1','disposition':'INERT_SOURCE_PENDING_PEER','formal_predecessor_negative':pin(peer),'sources':preserved,'seven_current_Source_pins':{**json.loads((P/'component-qualification-closed-plan-authority-and-once-ABI-v2.json').read_bytes())['Source_roles_exact7'],**current},'all_worker_functions_raw_AST_identical':True,'worker_whole_raw_inverse_exactly_three_literal_changes':True,'all_scientific_recipes_component_pins_ABIs_caps317_unchanged':True,'all_wait_calls_have_timeout':True,'immediate_post_Popen_try_preserved':True,'bootstrap':{'bytes':len(bootstrap.encode()),'sha256':h(bootstrap.encode()),'unchanged':True},'activity':{'subject_codeobject_execution':0,'subject_imports_helpers_factories_models_tests_probes_CLI':0,'plan_authority_actual_creation':0},'terminal_state':'IDLE'})
walk=save('component-qualification-Source3-changed-helper-walkthrough-v1.json',{'schema':'C-component-qualification-Source3-changed-helper-walkthrough-v1','Sources':current,'inherited_complete_Source2_manual':pin(P/'component-qualification-worker-observer-complete-helper-walkthrough-v2.json'),'unchanged_worker':'Every worker2 function, including main and all scientific recipes, is byte/plainAST identical. Only VERSION and the worker/observer path literals change, exactly three leaf replacements.','observer_changes':[{'helper':'consumed_validate','walk':'Read the original consumed_ref complete raw bytes after child captures; exact7 fields, typed current plan/observer/A6 associations, authenticate current complete A6 body and exact meaning/uses/case/schema. Late and final original rawref joins precede candidate/success; fresh census pins cannot replace this initial marker identity.'},{'helper':'verify_terminal','walk':'Exact case string plus raw_association on current terminal.plan, so float byte counts cannot equal integer pins. Full plan bytes/hash are reauthenticated; all other terminal gates unchanged.'},{'helper':'supervise','walk':'Immediate post-Popen protected scope remains. Both wait calls carry timeouts; final wait uses remaining bounded cleanup window when present. A timeout/error records owned_wait_complete=false and explicit reaping uncertainty/PID/EOF/group/captures; child lifetime RSS is null until confirmed wait. Normal admission requires confirmed owned wait, EOF and groupgone. No restart, helper execution or fault probe.'},{'helper':'main','walk':'directory_owned begins false and becomes true only after this invocation successfully mkdirs the fresh directory. Failure output requires ownership; preexisting/spent/mkdir-race directories are untouched. After full logs, authenticate typed original consume; late/final consume rawjoins and owned-wait gate precede success.'}],'scope':'Source repair only. Same317 authored component calls/controls; no new scientific data, results, experiments, discovery or performance claim. Unkillable/OS cleanup failures may remain explicitly UNCONFIRMED/UNADMITTED, never normal quiescence.'})
plan=json.loads((P/'component-qualification-closed-plan-authority-and-once-ABI-v2.json').read_bytes());plan['schema']='C-component-qualification-closed-plan-authority-and-once-ABI-v3';plan['Source_roles_exact7'].update(current);plan['status']='SOURCE3_INERT_NO_PLAN_AUTHORITY_ACTUAL_CREATED';plan['Source_revision_and_wire_policy']='Worker3/observer3; plan/authority/consumed schema-v2 and scientific/result/terminal/custody wire-v1 intentionally retained. Current Source3 rawpins are mandatory; old Source2 bodies inactive.';plan['ownership_and_cleanup']='Preexisting/spent/foreign actual directory is refused without failure writes there. Only successful own mkdir authorizes output. Final owned wait bounded; unconfirmed reaping withholds normal result/quiescence and lifetime RSS. External Root still enforces one invocation/no retry even if no new marker could be created.';plan['marker_postjoin']='Original consumed_ref full typed current A6/plan/observer/meaning after child, then original byte/hash after late guards and final census.'
planpin=save('component-qualification-closed-plan-authority-and-once-ABI-v3.json',plan)
abi=json.loads((P/'component-qualification-worker-observer-complete-public-ABI-v3.json').read_bytes());abi['schema']='C-component-qualification-worker-observer-complete-public-ABI-v4';abi['Sources']=current;abi['versions']={'worker':const(worker,'VERSION'),'observer':const(observer,'VERSION')};abi['closed_plan_contract']=planpin;abi['static']=static;abi['inherited_complete_Source2_static']=pin(P/'component-qualification-complete-static-helper-ledger-v2.json');abi['current_changed_helper_manual']=walk;abi.pop('metadata_line_precision',None);abi['Source_revision_and_wire_policy']=plan['Source_revision_and_wire_policy'];abi['census_inheritance']='The exact Source2 census3 is inherited unchanged: all317 calls, every worker function and their line positions are identical in worker3. Its effective_Source_revision describes its historical freeze, not a current Source-path claim.';abi['custody']['child_additional_field_types']={'owned_wait_complete':'exact bool; normal requires true','child_lifetime_highwater_bytes':'Darwin integer only after confirmed owned wait; otherwise null/UNADMITTED','post_Popen_return_to_owned_wait_seconds':'only an observed owned-wait clock; null if no wait sample','cleanup_errors':'includes explicit final wait timeout/error; never normal quiescence'};abi['custody']['ownership']='failure writes only when directory_owned after successful fresh mkdir';abi['custody']['consume']='current original typed consumed7/A6 body joins plus explicit late and final rawref authentication';abi['gates_remaining']=['Root and B focused complete Source3 preservation peer','exact current prospective caller/plan and fresh one-use authority/global idle','one reviewed component-qualification actual','complete whole saved evidence review before qualification']
ap=save('component-qualification-worker-observer-complete-public-ABI-v4.json',abi)
handoff=save('component-qualification-worker3-observer3-complete-inert-Source-handoff-v1.json',{'schema':'C-component-qualification-worker3-observer3-complete-inert-Source-handoff-v1','status':'COMPLETE_INERT_SOURCE3_PENDING_PEER','worker':current['worker'],'observer':current['observer'],'current_public_ABI':ap,'current_closed_plan_authority_contract':planpin,'complete_Source2_Source3_preservation_static_fourpatches':static,'changed_helper_manual':walk,'inherited_complete_scientific_census':pin(P/'component-qualification-exact-controlled-census-v3.json'),'inherited_Source2_complete_handoff':pin(P/'component-qualification-worker-observer-complete-inert-Source-handoff-v3.json'),'predecessor_formal_negative':pin(peer),'changes':'Four B custody findings only, plus exactly three worker operational literal bindings. All scientific components/caps/317 calls and worker functions unchanged. No source/test/probe/factory execution. No plan, A6 or actual created.','terminal_state':'IDLE'})
print(json.dumps({'handoff':handoff,'worker':current['worker'],'observer':current['observer'],'ABI':ap,'plan_contract':planpin,'preservation':static,'manual':walk},sort_keys=True))
