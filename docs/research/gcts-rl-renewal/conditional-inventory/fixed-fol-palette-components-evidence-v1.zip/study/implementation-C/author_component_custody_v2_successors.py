"""Administrative literal Source editing only; no subject invocation."""
from pathlib import Path
P=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-C')
for role in ('worker','observer'):
 old=P/('component_qualification_'+role+'_v1.py')
 new=P/('component_qualification_'+role+'_v2.py')
 s=old.read_text()
 s=s.replace('component_qualification_worker_v1.py','component_qualification_worker_v2.py').replace('component_qualification_observer_v1.py','component_qualification_observer_v2.py')
 s=s.replace('GCTS-FOL-NTM-COMPONENT-QUALIFICATION-WORKER-v1','GCTS-FOL-NTM-COMPONENT-QUALIFICATION-WORKER-v2').replace('GCTS-FOL-NTM-COMPONENT-QUALIFICATION-OBSERVER-v1','GCTS-FOL-NTM-COMPONENT-QUALIFICATION-OBSERVER-v2')
 s=s.replace('GCTS-FOL-NTM-component-once-plan-v1','GCTS-FOL-NTM-component-once-plan-v2').replace('Root-FOL-NTM-component-once-authority-v1','Root-FOL-NTM-component-once-authority-v2').replace('Root-FOL-NTM-component-once-consumed-v1','Root-FOL-NTM-component-once-consumed-v2')
 marker="COHORT = 'AUTHORED-FOL40-NTM120-LAYERS0TO2-v1'"
 s=s.replace(marker,marker+"\nCONSUMED_MEANING = 'exclusive spent marker before the sole child launch; failures remain spent'")
 assoc='''\ndef raw_association(value, expected, label):
    exact_fields(value, ('path','bytes','sha256'), label+' rawref fields')
    require(type(value['path']) is str and type(value['bytes']) is int and value['bytes'] >= 0, label+' path/byte types')
    require(type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256']) is not None, label+' digest type')
    require(encode(value) == encode(expected), label+' type-exact canonical association')
    return read_ref(value,1048576)

'''
 anchor='\ndef parse_json(raw):'
 assert s.count(anchor)==1;s=s.replace(anchor,assoc+anchor)
 if role=='worker':
  s=s.replace('def guard_read(plan, plan_ref):','def guard_read(plan, plan_ref, extra_refs=()):')
  s=s.replace("    read_ref(plan_ref, 1048576)\n    return retained", "    read_ref(plan_ref, 1048576)\n    for ref in extra_refs:\n        read_ref(ref,1048576)\n    return retained")
  helper='''\ndef consumed_read(plan, plan_ref, directory):
    path = safe_file(str(directory/'CONSUMED.json'))
    size = path.stat().st_size
    require(size <= 1048576, 'bounded once marker metadata')
    raw = path.read_bytes()
    require(len(raw) == size and len(raw) <= 1048576, 'whole bounded once marker')
    consumed_ref = rawref(path,raw)
    consumed = parse_json(raw)
    exact_fields(consumed, ('schema','uses','case_id','plan','authority','observer','meaning'), 'consumed exact seven fields')
    raw_association(consumed['plan'],plan_ref,'consumed current plan')
    raw_association(consumed['observer'],plan['sources']['observer'],'consumed current observer')
    authority_ref = consumed['authority']
    exact_fields(authority_ref, ('path','bytes','sha256'), 'current authority rawref fields')
    require(type(authority_ref['path']) is str, 'authority path type')
    authority_path = PathAuthority = pathlib.Path(authority_ref['path'])
    require(authority_path.parent == ROOT/'root' and authority_path.suffix == '.json' and not authority_path.name.startswith('.'), 'current authority Root metadata location')
    authority_raw = read_ref(authority_ref,1048576)
    authority = parse_json(authority_raw)
    exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'current authority exact six fields')
    raw_association(authority['plan'],plan_ref,'authority current plan')
    raw_association(authority['observer'],plan['sources']['observer'],'authority current observer')
    expected_authority = {'schema':'Root-FOL-NTM-component-once-authority-v2','authorized':True,'uses':1,
                          'case_id':plan['case_id'],'plan':plan_ref,'observer':plan['sources']['observer']}
    require(encode(authority) == encode(expected_authority), 'whole current authority flags and typed fields')
    expected_consumed = {'schema':'Root-FOL-NTM-component-once-consumed-v2','uses':1,'case_id':plan['case_id'],
                         'plan':plan_ref,'authority':authority_ref,'observer':plan['sources']['observer'],'meaning':CONSUMED_MEANING}
    require(encode(consumed) == encode(expected_consumed), 'whole current consumed meaning and typed fields')
    return (authority_ref,consumed_ref)

'''
  # No alias global is needed; keep every helper local and explicit.
  helper=helper.replace('authority_path = PathAuthority =','authority_path =')
  anchor='\ndef clone(value):';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor)
  s=s.replace('        retained = guard_read(plan,plan_ref)\n','',1)
  old="        consumed = parse_json((directory/'CONSUMED.json').read_bytes())\n        require(consumed.get('schema') == 'Root-FOL-NTM-component-once-consumed-v2' and consumed.get('plan') == plan_ref and consumed.get('case_id') == plan['case_id'] and type(consumed.get('uses')) is int and consumed.get('uses') == 1 and consumed.get('observer') == plan['sources']['observer'], 'fresh observer consumed plan association')"
  assert s.count(old)==1
  s=s.replace(old,"        once_refs = consumed_read(plan,plan_ref,directory)\n        retained = guard_read(plan,plan_ref,once_refs)")
  s=s.replace('        guard_read(plan,plan_ref)\n','        guard_read(plan,plan_ref,once_refs)\n')
 else:
  helper='''\ndef authority_validate(authority, plan, plan_ref):
    exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'authority exact six fields')
    raw_association(authority['plan'],plan_ref,'authority current plan')
    raw_association(authority['observer'],plan['sources']['observer'],'authority current observer')
    expected = {'schema':'Root-FOL-NTM-component-once-authority-v2','authorized':True,'uses':1,
                'case_id':plan['case_id'],'plan':plan_ref,'observer':plan['sources']['observer']}
    require(encode(authority) == encode(expected), 'whole current authority flags and typed fields')

'''
  anchor='\ndef guards(plan, plan_ref, authority_ref):';assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor)
  old="        exact_fields(authority, ('schema','authorized','uses','case_id','plan','observer'), 'authority exact six fields')\n        require(authority['schema'] == 'Root-FOL-NTM-component-once-authority-v2' and authority['authorized'] is True and type(authority['uses']) is int and authority['uses'] == 1, 'fresh once authorization')\n        require(authority['case_id'] == plan['case_id'] and authority['plan'] == plan_ref and authority['observer'] == plan['sources']['observer'], 'whole plan and observer authority association')"
  assert s.count(old)==1;s=s.replace(old,'        authority_validate(authority,plan,plan_ref)')
  s=s.replace("'meaning':'exclusive spent marker before the sole child launch; failures remain spent'","'meaning':CONSUMED_MEANING")
 with new.open('x') as handle:handle.write(s)
