"""Administrative static authoring ledger only; no subject code is executed."""
import ast
import builtins
import hashlib
import json
import pathlib
import symtable
import sys

R = pathlib.Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
O = R/'implementation-C'
W = O/'component_qualification_worker_v2.py'
V = O/'component_qualification_observer_v2.py'

def enc(x):
    return (json.dumps(x,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()

def h(x):
    return hashlib.sha256(x).hexdigest()

def pin(p):
    b=pathlib.Path(p).read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':h(b)}

def save(name,value):
    p=O/name
    with p.open('xb') as f:f.write(enc(value))
    return pin(p)

raws={p:p.read_bytes() for p in [W,V]}
trees={p:ast.parse(b,filename=str(p)) for p,b in raws.items()}
constants={}
for p,t in trees.items():
    constants[p]={}
    for n in t.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('PYTHON','LIMITS','COMPONENT_PINS','METADATA_PINS','COHORT','VERSION','BOOTSTRAP','EXPECTED_CALLS'):
            constants[p][n.targets[0].id]=ast.literal_eval(n.value)
for key in ['PYTHON','LIMITS','COMPONENT_PINS','METADATA_PINS','COHORT']:
    assert constants[W][key]==constants[V][key]
source_paths=ast.literal_eval(next(n.value for n in trees[V].body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='SOURCE_PATHS'))
sources={k:pin(v) for k,v in source_paths.items()}
for role,(size,digest) in constants[W]['COMPONENT_PINS'].items():assert (sources[role]['bytes'],sources[role]['sha256'])==(size,digest)
for ref in constants[W]['METADATA_PINS'].values():assert pin(ref['path'])==ref
assert pin(constants[W]['PYTHON']['path'])==constants[W]['PYTHON']

notes={
'raw_association':'Exact rawref3 and path/nonbool-byte/digest types, canonical type-exact current association then whole-byte authentication; float bytes cannot equal integer pins.',
'consumed_read':'Bounded safe exact consumed7 read, typed plan/current-observer associations, full current Root authority body/flags/exact6 and meaning; return both complete authority+consume rawrefs for pre/post guard sweeps before any scientific namespace execution.',
'authority_validate':'Exact current A6 fields, typed authenticated plan/observer rawrefs and canonical whole true/uses1/schema/case association before exclusive consumption.',
'supervise.capture':'Bounded complete-prefix and last64KiB capture shared by normal and setup-failure cleanup paths.',
'supervise.send':'Owned fresh group signal, recorded cleanup errors, direct owned-child kill fallback on signal errors; no restart.',
'QualificationFailure':'Own whole-qualification fault; never a component semantic REJECTED result.',
'CustodyFailure':'Own custody/authorization/transport fault; no result admission.',
'encode':'Canonical sorted compact ASCII JSON plus LF, nonfinite values refused.',
'sha':'SHA256 of complete retained raw bytes.',
'require':'Fail the whole attempt when an exact gate is false.',
'exact_fields':'Exact native dict/string keyset; extra/missing/nonstring keys refused.',
'safe_file':'Absolute canonical spelling, no symlink in path ancestors, regular single-link file.',
'read_ref':'Exact rawref fields and scalar types, bound/stat/full read/SHA join; retained bytes returned.',
'rawref':'Complete raw body identity with absolute location, bytes and SHA256.',
'parse_json':'Stdlib metadata parse, duplicate keys and nonfinite constants rejected.',
'parse_json.pairs':'Build one duplicate-free native record, no scientific operation.',
'plan_read':'Exact fixed eight-field plan, Source/metadata roles, current versions/caps/cohort/path constraints. No scientific data in the plan.',
'guard_read':'Retain/authenticate all seven Sources, four current ABI metadata refs, D90 and plan plus full current authority/consume rawrefs before scientific namespace execution and after work/result readback.',
'guards':'Same whole guard closure plus authority; observer reads no scientific result semantics.',
'clone':'Detached native controlled data copy; tuple distinction retained for malformed FOL input, finite float controls retain numeric type.',
 'typed_image':'Lossless declared native type image including tuple/list and bool/int/float distinctions; complete request identity.',
 'nonnegative':'Exact nonbool nonnegative integer predicate.',
 'checked_return':'Public receipt/schema/status and count/coherence gates for these controlled calls, not a general hostile-receipt verifier.',
 'legacy_ast':'Explicit JSON-array to immutable-tuple adaptation; used only on the twelve declared compatible valid controls.',
 'Run':'Whole-worker call/clock/output accounting owner, no persistent cross-run state.',
 'Run.__init__':'Fresh plan/clock/directory/counters/current-fault context; no factory execution in the authoring audit.',
 'Run.budget':'Cooperative main-entry elapsed and Darwin SELF lifetime-high-water checks; not an OS quota.',
 'Run.save':'Serialize, per-body/cumulative/count/reserve gates, exclusive create/fsync/full readback. Three MiB reserved for observer and external outer transport.',
 'Run.call':'Before/after complete typed request image, exact saved full return/hash, no caller mutation, component counters and public wire gates; external faults propagate to whole UNADMITTED.',
 'fol_controls':'Forty manual authored certificates/invalid/resource controls; no theorem-specific search, no proof discovery. All factory calls deferred until once.',
 'fol_controls.add':'Assemble one complete detached request and predeclared expected status/legacy compatibility label.',
 'fixed_machines':'Two Source-literal finite machines. No machine instantiated during packet generation; all state/head/three-cell binary contexts generated only at actual time.',
 'fol_run':'All forty full requests/returns, expected status gates; twelve compatible legacy constructor/check comparisons with actual adapted input hashes.',
 'literal_wire':'Compact ASCII descriptor encoding without LF, matching the public palette literal format.',
 'seed_row':'Build the declared exact-one-head interior plus fixed two wall glyphs for literal witness inspection.',
 'decode_normal':'Require fixed walls, declared symbols/states and exactly one normal head; decode full state/head/tape.',
 'verify_grids':'Check every full retained witness grid, every tile ID and north/horizontal seam/phase/ghost boundary, all halfstep walls and associated decoded configuration. No compiler helper calls.',
 'compare_layers':'Every normal layer 0,1,2 whole configuration-list equality, cardinality/accepting counts and absorbed ever/exact acceptance, then full grid checks.',
 'ntm_run':'Compile each fixed machine once, retain its full result, enumerate all 72+48 contexts, retain both full returns and resolved request hashes, save all witness-bearing chunks; retain the exact halted baseline for the declared adaptive control.',
 'row_control_call':'Complete explicit per-call input plus referenced shared/modified compiled artifact, full resolved input hash, no mutation and full return/hash. No codec or hidden projection.',
 'ntm_controls':'Six malformed machines through both compiler/reference, two compiler/two reference/two row resource controls, phase/wall plus bool/float literal-edge negatives, and one declared adaptive empty-frontier resource case; seventeen rows total.',
 'load_libraries':'Only during authorized worker main: execute exactly authenticated retained bytes into five private namespaces; no project import/module cache/path loader.',
 'main':'Worker: current D90/Source/flags/plan/consume association, one complete cohort and exact counts, full result/readback/postguards/terminal; any exception makes exit2, never semantic negative or partial promotion.',
 'admin_json':'Bounded duplicate-free administrative JSON under the exact Root directory.',
 'write_bytes':'Exclusive bounded fsynced observer output and complete readback.',
 'census':'Full all-file raw body census with regular/single-link/name/body/count/aggregate gates; reserves two outer files and one MiB combined outer captures.',
 'group_exists':'Observe whether the exact newly created child process group remains.',
 'group_signal':'Signal only the owned process group and retain delivery/already-gone event.',
 'supervise':'One D90 retained-byte child and immediate post-Popen protected try. Selector construction/nonblocking/register are protected; partial setup failures retain explicit supervisor error and bounded fallback drain, owned group TERM/KILL, unconditional owned-wait attempt and tolerant pipe/selector close. Normal logs/EOF/group/RSS gates unchanged; no restart or fault probe.',
 'verify_terminal':'Parse only the typed canonical worker transport terminal, expected full census and exact result rawref; result body remains opaque.',
}
all_static=[];manual=[]
flags=[('assigned','is_assigned'),('free','is_free'),('global','is_global'),('imported','is_imported'),('local','is_local'),('nonlocal','is_nonlocal'),('parameter','is_parameter'),('referenced','is_referenced')]
for p,t in trees.items():
    lines=raws[p].splitlines(keepends=True);defs=[]
    def collect(node,prefix=''):
        for n in node.body:
            if not isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):continue
            name=prefix+n.name
            b=b''.join(lines[n.lineno-1:n.end_lineno])
            rec={'name':name,'kind':type(n).__name__,'line':n.lineno,'end_line':n.end_lineno,'raw_bytes':len(b),'raw_sha256':h(b),
                 'AST_sha256':h(ast.dump(n).encode()),'positioned_AST_sha256':h(ast.dump(n,include_attributes=True).encode()),
                 'signature':ast.unparse(n.args) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) else None,
                 'all_descendant_calls':sorted({ast.unparse(x.func) for x in ast.walk(n) if isinstance(x,ast.Call)}),
                 'branches':[{'line':x.lineno,'kind':type(x).__name__,'expression':ast.unparse(x.test) if isinstance(x,(ast.If,ast.While,ast.IfExp)) else ast.unparse(x.iter) if isinstance(x,(ast.For,ast.AsyncFor)) else None if x.type is None else ast.unparse(x.type)} for x in ast.walk(n) if isinstance(x,(ast.If,ast.IfExp,ast.While,ast.For,ast.AsyncFor,ast.ExceptHandler))]}
            defs.append(rec)
            note=notes[name]
            if p==V and name=='main':note='Observer: exact six-field fresh authority and whole guard closure, exclusive CONSUMED before sole spawn, complete waited/drained/log/output/postguard/terminal checks, observed child RSS gate, custody + outer envelope; nonzero/fault means UNADMITTED and spent, no retry.'
            manual.append({'source':p.name,'helper':name,'line':n.lineno,'end_line':n.end_lineno,'signature':rec['signature'],'walk':note})
            if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):collect(n,name+'.')
    collect(t)
    st=symtable.symtable(raws[p].decode(),str(p),'exec');scopes=[];tables=[]
    def scope(s,path):
        entries=[]
        for name in sorted(s.get_identifiers()):
            z=s.lookup(name);entries.append({'name':name,'true_flags':[out for out,m in flags if getattr(z,m)()]})
        scopes.append({'path':path,'type':s.get_type(),'line':s.get_lineno(),'entries':entries,'complete_entry_fingerprint':h(enc(entries))});tables.append(s)
        for i,c in enumerate(s.get_children()):scope(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
    scope(st,'module')
    declared={name for name in st.get_identifiers() if st.lookup(name).is_assigned() or st.lookup(name).is_imported()}
    context={'__file__','__name__'}
    unresolved=sorted({name for s in tables for name in s.get_identifiers() if s.lookup(name).is_global() and s.lookup(name).is_referenced() and name not in declared and name not in vars(builtins) and name not in context})
    assert not unresolved
    imports=[ast.unparse(n) for n in ast.walk(t) if isinstance(n,(ast.Import,ast.ImportFrom))]
    assert all(n.split()[1].split('.')[0] in sys.stdlib_module_names for n in imports if n.startswith('import '))
    code=compile(raws[p],str(p),'exec',dont_inherit=True,optimize=0);del code
    all_static.append({'Source':pin(p),'lines':len(lines),'definitions':defs,'definition_count':len(defs),'symbol_scopes':scopes,'symbol_scope_count':len(scopes),
                       'all_eight_flag_names':[x[0] for x in flags],'omitted_flags_are_false':True,'unresolved_globals':unresolved,'required_module_context_globals':sorted(context),
                       'imports':imports,'whole_AST_sha256':h(ast.dump(t).encode()),'whole_positioned_AST_sha256':h(ast.dump(t,include_attributes=True).encode()),
                       'unused_compile':'PASS; code object discarded, never executed','execution_sites_are_inert':'worker load_libraries exec and both main guards/observer authenticated child bootstrap are future once-only, never executed by this driver'})
# Static literal labels/callsite census only. No factory evaluation or machine AST literal_eval.
fol=next(n for n in trees[W].body if isinstance(n,ast.FunctionDef) and n.name=='fol_controls')
controls=[]
for n in ast.walk(fol):
    if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='add':
        number=ast.literal_eval(n.args[0]);label=ast.literal_eval(n.args[1]);status=ast.literal_eval(n.args[4]) if len(n.args)>4 else 'VERIFIED'
        legacy=any(k.arg=='legacy' and isinstance(k.value,ast.Constant) and k.value.value is True for k in n.keywords)
        controls.append({'id':'F%02d'%number,'label':label,'expected_status':status,'legacy_compatible':legacy,'source_line':next(x['source_line'] for x in json.loads((O/'component-qualification-exact-controlled-census-v1.json').read_bytes())['fol_controls'] if x['id']=='F%02d'%number)})
controls.sort(key=lambda x:x['id'])
assert len(controls)==40 and len({x['id'] for x in controls})==40 and sum(x['legacy_compatible'] for x in controls)==12
assert [sum(x['expected_status']==s for x in controls) for s in ['VERIFIED','REJECTED','UNKNOWN_BUDGET']]==[16,20,4]
bootstrap=constants[V]['BOOTSTRAP'];cb=compile(bootstrap,'<authenticated-retained-byte-bootstrap>','exec',dont_inherit=True);del cb

# Pure Source transport comparison; never imports/calls either predecessor or successor.
import difflib
import re

def apply_unified(raw, patch):
    source=raw.decode().splitlines(keepends=True);result=[];cursor=0
    lines=patch.decode().splitlines(keepends=True);i=2
    while i<len(lines):
        match=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',lines[i])
        assert match, lines[i]
        start=int(match[1])-1;oldcount=int(match[2] or '1');newcount=int(match[4] or '1')
        assert start>=cursor
        result.extend(source[cursor:start]);cursor=start;i+=1;a=b=0
        while i<len(lines) and not lines[i].startswith('@@ '):
            line=lines[i];tag=line[0];body=line[1:]
            assert tag in ' +-'
            if tag in ' -':assert cursor<len(source) and source[cursor]==body;cursor+=1;a+=1
            if tag in ' +':result.append(body);b+=1
            i+=1
        assert a==oldcount and b==newcount
    result.extend(source[cursor:]);return ''.join(result).encode()

def units(tree,raw):
    result={};lines=raw.splitlines(keepends=True)
    def collect(node,prefix=''):
        for z in node.body:
            if isinstance(z,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):
                name=prefix+z.name;b=b''.join(lines[z.lineno-1:z.end_lineno])
                result[name]={'raw_bytes':len(b),'raw_sha256':h(b),'AST_sha256':h(ast.dump(z).encode()),'positioned_AST_sha256':h(ast.dump(z,include_attributes=True).encode())}
                collect(z,name+'.')
    collect(tree);return result

preservation=[]
for role,current in [('worker',W),('observer',V)]:
    old=O/('component_qualification_'+role+'_v1.py');before=old.read_bytes();after=raws[current]
    forward=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile=old.name,tofile=current.name,n=3)).encode()
    inverse=''.join(difflib.unified_diff(after.decode().splitlines(keepends=True),before.decode().splitlines(keepends=True),fromfile=current.name,tofile=old.name,n=3)).encode()
    fp=O/('component-qualification-'+role+'-v1-to-v2.patch');ip=O/('component-qualification-'+role+'-v2-to-v1.patch')
    for path,data in [(fp,forward),(ip,inverse)]:
        with path.open('xb') as handle:handle.write(data)
    assert apply_unified(before,forward)==after
    restored=apply_unified(after,inverse);assert restored==before
    previous_tree=ast.parse(before);restored_tree=ast.parse(restored)
    assert ast.dump(previous_tree,include_attributes=True)==ast.dump(restored_tree,include_attributes=True)
    prior_units=units(previous_tree,before);current_units=units(trees[current],after)
    unchanged=[];changed=[]
    for name in prior_units:
        assert name in current_units
        equal=all(prior_units[name][key]==current_units[name][key] for key in ['raw_bytes','raw_sha256','AST_sha256'])
        (unchanged if equal else changed).append(name)
    preservation.append({'role':role,'predecessor':pin(old),'current':pin(current),'forward':pin(fp),'inverse':pin(ip),
      'entire_forward_exact':True,'entire_inverse_bytes_and_positioned_AST_exact':True,
      'old_and_current_helper_fingerprints':{'predecessor':prior_units,'current':current_units},
      'raw_and_plain_AST_identical_helpers':unchanged,'changed_existing_helpers':changed,'new_helpers':sorted(set(current_units)-set(prior_units))})
# The entire scientific cohort, caps, return checker and literal witness logic are byte-identical.
old_worker=(O/'component_qualification_worker_v1.py').read_bytes();old_t=ast.parse(old_worker);old_constants={}
for n in old_t.body:
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('LIMITS','COMPONENT_PINS','METADATA_PINS','COHORT'):
        old_constants[n.targets[0].id]=ast.literal_eval(n.value)
for key in old_constants:assert old_constants[key]==constants[W][key]
assert set(preservation[0]['changed_existing_helpers'])=={'guard_read','plan_read','main'}
assert set(preservation[1]['changed_existing_helpers'])=={'plan_read','supervise','main'}
old_ledger=json.loads((O/'component-qualification-exact-controlled-census-v1.json').read_bytes())
assert old_ledger['fol_controls']==controls
assert old_ledger['public_entry_calls']==constants[V]['EXPECTED_CALLS']
# Structural assertion: the first statement after the sole successful Popen assignment is Try.
supervisor=next(n for n in trees[V].body if isinstance(n,ast.FunctionDef) and n.name=='supervise')
launch_positions=[i for i,n in enumerate(supervisor.body) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='subprocess.Popen']
assert len(launch_positions)==1 and isinstance(supervisor.body[launch_positions[0]+1],ast.Try)
assert constants[W]['BOOTSTRAP'] if 'BOOTSTRAP' in constants[W] else True
old_observer=ast.parse((O/'component_qualification_observer_v1.py').read_bytes())
old_bootstrap=ast.literal_eval(next(n.value for n in old_observer.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='BOOTSTRAP'))
assert bootstrap==old_bootstrap
peer=R/'implementation-L/peer-component-worker-observer-v1/component-worker-observer-complete-independent-Source-and-caller-peer-v1.json'
assert pin(peer)['sha256']=='b0be3c5118398054fb51719dae8632d4265006fdf32633a8f5c0c625b4e52b00'
correction_pin=save('component-qualification-v1-v2-complete-correction-and-preservation-v1.json',{
 'schema':'C-component-qualification-v1-v2-complete-correction-and-preservation-v1','status':'INERT_SUCCESSORS_PENDING_INDEPENDENT_PEER',
 'predecessor_peer':pin(peer),'predecessor_handoff':pin(O/'component-qualification-worker-observer-complete-inert-Source-handoff-v1.json'),
 'preserved_negative':'V1 is an unexecuted Source/custody failure, not a scientific test result. V1 bodies and complete packet are untouched; no authority/case consumed.',
 'repairs':[{'id':'CUSTODY1','closure':'Exact typed rawref3/canonical associations; bounded safe consumed7 with exact schema/uses/meaning/current plan+observer and complete current authority6 body/flags. Both current authority and consume rawrefs guarded before module execution and after work/readback.'},
            {'id':'CUSTODY2','closure':'Successful Popen immediately followed by cleanup-protected Try. Partial selector/pipe setup is tolerated; explicit supervisor error, bounded fallback capture/drain, group TERM/KILL and owned wait/close attempts. No hidden retry or fault probe.'}],
 'preservation':preservation,'all_scientific_recipes_raw_AST_unchanged':True,'caps_component_pins_ABIs_cohort_bootstrap_unchanged':True,
 'call_census_unchanged':constants[V]['EXPECTED_CALLS'],'aggregate_calls':317,
 'version_policy':'Source VERSIONs and effective paths v2; plan/authority/consumed schema v2. Result/terminal/custody/failure schemas intentionally v1 and same fieldsets. No scientific/data ABI revision.',
 'scope':'Source-static byte/diff/AST comparison only. No subject code, constructors, factories, tests, CLI, actual or failure probe.',
 'draft_boundary':'Only the two final v2 .py Sources and explicitly pinned packet records are current. Administrative authoring drivers and the supervision draft text are inactive provenance, never executable inputs.'})

static=save('component-qualification-complete-static-helper-ledger-v2.json',{'schema':'C-component-qualification-complete-static-helper-ledger-v2','sources':all_static,'Source_guards':sources,'ABI_guards':constants[W]['METADATA_PINS'],'runtime':constants[W]['PYTHON'],
       'bootstrap':{'bytes':len(bootstrap.encode()),'sha256':h(bootstrap.encode()),'unused_compile':'PASS, no execution'},
       'source_and_factory_execution':0,'subject_imports_calls_tests_CLI':0,'administrative_only':True})
cohort={'schema':'C-component-qualification-exact-controlled-census-v2','status':'ANALYTICAL_SOURCE_RECIPE_UNRUN',
 'fol_controls':controls,'fol_expected_status_counts':{'VERIFIED':16,'REJECTED':20,'UNKNOWN_BUDGET':4},
 'legacy':{'checks':12,'constructors':12,'scope':'Only declared compatible valid data; tuple adaptation exact. Four alpha/fresh-name-different positive cases and all invalid/resource cases are not false-mismatch comparisons.'},
 'machines':[{'id':0,'label':'LEFT_ACCEPT_RIGHT_HALT','description':'Three states q0/qA/qH; two ordinary binary symbols. For both reads q0 can write1/moveleft/accept or write0/moveright/halt. Accept absorbs implicitly; halt has no outgoing.', 'normal_contexts':72,'analytic_count':r'\(3\cdot3\cdot2^3=72\)'},
             {'id':1,'label':'STAY_NAMESPACE_SMOKE','description':'Two states with empty-string start name; two ordinary symbol strings 0 and ["wall"]. STAY writes the other symbol then accepts. Two explicit accepting identities must fold; compiler supplies exactly two effective accepting identities. Namespace lookalikes are ordinary string data, not wall glyphs.', 'normal_contexts':48,'analytic_count':r'\(2\cdot3\cdot2^3=48\)'}],
 'normal_NTM_contexts':120,'steps':2,'every_exact_normal_layer':[0,1,2], 'all_tapes_interior_width':3,'palettes_compiled_once_each':2,
 'additional_NTM_controls':{'six_dual_REJECTED':['extra machine field','duplicate transition','bool move','conflicting accept outgoing','duplicate accept','foreign accept'],
 'compiler_UNKNOWN':['zero operations','zero tile cap'],'reference_UNKNOWN':['one operation','one cumulative configuration row'],
 'row_UNKNOWN':['zero operations','zero row solutions','declared adaptive huge empty-frontier tail'],
 'row_REJECTED':['incoherent south phase','coherent boundary-wall-to-plain tile mutant','bool-forged integer tag edge','float-forged integer tag edge'],
 'logical_rows_total':17,'adaptive_rule':'Use the complete two-step halted qH/head0/tape000 normal result already in the 120 contexts. Its operation count plus exact fixed reserve16 is the cap for same input with exact1000000steps; require UNKNOWN with layers null. No authoring probe or added baseline call.'},
 'public_entry_calls':constants[V]['EXPECTED_CALLS'],'sum_entry_calls':sum(constants[V]['EXPECTED_CALLS'].values()),'legacy_constructors_additional':12,'isolated_library_executions':5,
 'every_result_complete_or_unadmitted':True,'prefix_promotion':False,'normal_worker_artifact_files':16,'normal_actual_files_including_consume_four_logs_custody':22,'external_outer_capture_files':2,
 'shared_input_resolution':'Full compiled returns retained once in palette-N.json, exact rawref and compiled-return SHA in each row call, complete resolved request SHA over full machine/compiled/initial/steps/limits. Four complete mutant compiled artifacts retained separately. Nothing scientific omitted by a projection.'}
census=save('component-qualification-exact-controlled-census-v2.json',cohort)
plan={'schema':'C-component-qualification-closed-plan-authority-and-once-ABI-v2','status':'SOURCE_ONLY_NO_PLAN_AUTHORITY_OR_ACTUAL_CREATED',
 'plan_schema':'GCTS-FOL-NTM-component-once-plan-v2','plan_exact8':['schema','case_id','actual_dir','python','sources','metadata','limits','cohort'],
 'plan_path':'absolute regular nonsymlink single-link nonhidden .json directly under '+str(R/'root'),
 'case_id':'exact str matching [a-z0-9][a-z0-9_-]{0,63}', 'actual_dir':str(R/'actual/<case_id>')+'; must not exist before observer consumes',
 'python':constants[W]['PYTHON'],'Source_roles_exact7':sources,'scientific_component_roles_exact5':['fol_checker','legacy','compiler','ntm_reference','wang_rows'],
 'metadata_roles_exact4':constants[W]['METADATA_PINS'],'limits_exact18':constants[W]['LIMITS'],'cohort':constants[W]['COHORT'],
 'rawref_exact3':{'path':'absolute canonical str, regular single-link, every ancestor nonsymlink','bytes':'exact nonbool int >=0','sha256':'lowercase exact64hex'},
 'authority_schema':'Root-FOL-NTM-component-once-authority-v2','authority_exact6':['schema','authorized','uses','case_id','plan','observer'],
 'authority_values':{'authorized':'exact true','uses':'exact nonbool integer1','case_id':'same plan case_id','plan':'complete current plan rawref','observer':'exact current observer Source rawref from plan'},
 'CLI':{'observer':'D90 -I -S -B authenticated retained observer bytes --plan ABS --authority ABS','worker':'sole observer child, D90 -I -S -B authenticated retained worker bytes --plan SAME_ABS --result EXACT_actual_dir/worker-result.json'},
 'once':'exclusive fresh directory plus exclusive CONSUMED.json exact7/schema-v2 before any child launch; worker authenticates its exact meaning/current authority6 body and both rawrefs stay in pre/post guards. Zero retries; every fault leaves authority spent. V1 authority/plan/marker schemas are inactive.',
 'external_observer_authentication':'Root must authenticate the exact reviewed observer bytes and D90 before launch and bind authoritative outer exit/full stdout+stderr. The observer cannot prove which Source invoked itself. Use the same retained-byte bootstrap pattern; no Source path-cache loader.',
 'bootstrap':{'text':bootstrap,'bytes':len(bootstrap.encode()),'sha256':h(bootstrap.encode())},
 'future_outer_capture_limits':'two fresh Root-owned captures, combined <=1MiB. Observer census reserves these two files and one MiB in the whole64file/32MiB case envelope.',
 'whole_qualification':'All40 controls, both complete palettes and all120 contexts/360 complete normal layer sets, all17 additional rows and exact calls must finish with predeclared statuses and equality. Otherwise the complete attempt is UNADMITTED, including any retained prefix.'}
assert len(plan['limits_exact18'])==18
planpin=save('component-qualification-closed-plan-authority-and-once-ABI-v2.json',plan)
api={'schema':'C-component-qualification-worker-observer-complete-public-ABI-v2','status':'COMPLETE_INERT_SOURCE_UNRUN',
 'Sources':{'worker':sources['worker'],'observer':sources['observer']},'versions':{'worker':constants[W]['VERSION'],'observer':constants[V]['VERSION']},
 'closed_plan_contract':planpin,'census':census,'static':static,
 'worker_result':{'schema':'GCTS-FOL-NTM-component-qualification-result-v1','status':'COMPLETE_PASS','exact12':['schema','version','status','case_id','plan','source_guards','metadata_guards','cohort','counts','evidence','costs_before_result_serialization','scope'],
 'counts_exact7':['fol_controls','legacy_compatible_controls','palettes','normal_NTM_contexts','layers_per_context','additional_NTM_controls','public_calls'],
 'evidence_exact4':['fol','contexts','additional_controls','all_prior_outputs'],
 'costs_exact3':['elapsed_seconds','self_lifetime_highwater_bytes','worker_budget_callbacks'],
 'artifact_names':'fol-controls.json; palette-0/1.json; ntm-contexts-000/020/040/060/072/092/112.json; four palette phase/wall/tag-bool/tag-float mutants; ntm-wire-resource-coherence-controls.json; worker-result.json',
 'failure':'exception => stderr traceback and exit2; bounded best-effort worker-failure.json, never REJECTED as an expected semantic answer'},
 'typed_request':'Exact recursive type image: dict items, list items, tuple items, scalar typename/value. Preserves malformed tuple vs list and bool/int/float differences; full image hash. Normal shared row input resolves the retained compiled return by exact artifact/ref+SHA and hashes the full actual JSON argument list.',
 'worker_terminal':{'schema':'GCTS-FOL-NTM-worker-terminal-v1','status':'COMPLETE_PASS_RESULT_WRITTEN','exact8':['schema','status','case_id','plan','result','public_calls','post_readback_costs','unmeasured_tail'],
 'costs_exact3':['elapsed_main_entry_seconds','self_lifetime_highwater_bytes','worker_budget_callbacks'],'encoding':'canonical sorted compact ASCII JSON + LF; stdout only this complete record, stderr empty on normal',
 'sample_scope':'after result serialization/fsync/full readback, full late guard sweep and budget gate. Remaining encoding/flush/shutdown tail explicit; no result self-hash cycle.'},
 'custody':{'schema':'GCTS-FOL-NTM-owned-custody-v1','status':'NORMAL_TRANSPORT_CANDIDATE','exact15':['schema','status','version','case_id','plan','authority','consumed','Source_and_runtime_pre_post_exact','child','captures','worker_terminal','result','all_prior_owned_files','late_costs','scopes'],
 'outer_schema':'GCTS-FOL-NTM-owned-outer-v1','outer_status':'COMPLETE_NORMAL','outer_exact8':['schema','status','case_id','custody','admitted_result_candidate','owned_file_count','owned_named_bytes','requires_authoritative_exit_zero'],
 'failure':'observer exit2, exact failure record when bounded write possible, no admitted result; captures and child/EOF/group/cleanup evidence retained when obtained'},
 'transport':'one fresh process group; simultaneous pipe drain; combined full worker logs <=1MiB, named last64KiB tails, TERM then KILL/owned wait, both EOF and groupgone. Output files individually<=8MiB, wholecase<=32MiB/count64 including reserved external outer captures.',
 'resource_scope':'180s observed observer main-entry window (imports excluded); worker165s cooperative main-entry check. Waited fresh only-child Darwin RUSAGE_CHILDREN lifetime high-water<=1GiB is an admission gate, not OS RAM quota/process-tree/simultaneous accounting. Parent self peak separately reported. No cross-origin worker-vs-postPopen clock inequality.',
 'scope':'Authored component regressions and bounded NTM-palette equivalence control; no proof discovery, PA/Hilbert membership/consistency, fixed universal proof palette, GCTS scheduler or performance claim.',
 'gates_remaining':['Root and independent Source peers','closed exact plan/authority and global idle','one reviewed actual','complete whole saved-evidence review before qualification'],
 'subject_calls_in_authorship':0,'factory_calls_in_authorship':0}
apipin=save('component-qualification-worker-observer-complete-public-ABI-v2.json',api)
walk=save('component-qualification-worker-observer-complete-helper-walkthrough-v2.json',{'schema':'C-component-qualification-complete-helper-walkthrough-v2','Sources':api['Sources'],'all_helpers':manual,'helper_count':len(manual),
 'nested_receipt_scope':'Public ABI exact fields plus complete Source fingerprints/branch/call ledger; no raw AST megadump. All whole output/negative paths included.',
 'limitations':['Static analytical census, not factory output or test result.','Legacy comparator scoped to compatible valid controls; no misleading alpha/payload/resource equality demand.','Wall-clock/RSS/output failures are resource/transport failures, not false mathematical targets.','No hard hostile-filesystem or unkillable-kernel-process guarantee; controlled own task files and external exact observer bootstrap are prospective preconditions.','No prefix can qualify components; no old scientific results or authority inputs.']})
handoff=save('component-qualification-worker-observer-complete-inert-Source-handoff-v2.json',{'schema':'C-component-qualification-worker-observer-complete-inert-Source-handoff-v2','status':'COMPLETE_SOURCE_ONLY_UNRUN_PEERS_AND_ONCE_PENDING','correction_and_preservation':correction_pin,
 'worker':sources['worker'],'observer':sources['observer'],'component_Source_roles':{k:v for k,v in sources.items() if k not in ('worker','observer')},
 'public_ABI':apipin,'closed_plan_authority_contract':planpin,'exact_control_census':census,'complete_manual':walk,'complete_static':static,
 'activity':{'subject_imports_or_execution':0,'factories_models_proofs_tests':0,'CLI_help':0,'network_publication':0,'plan_authority_actual_creation':0},
 'current_bindings':'Worker2/observer2/plan2/A6-v2/consumed-v2. Scientific five Sources unchanged: B checker1, legacy exact recovered logic.py, L compiler1, B reference2/ABI3 and Root rows2/ABI2. Result/terminal/custody/failure wire schemas intentionally remain v1 with identical fieldsets and Source VERSIONv2; all317 calls unchanged.',
 'coverage':'All named helper bodies, all nested scopes, raw+plain/positioned AST fingerprints, complete eight symtable flags, branch/call inventories, D90 unused compile. All forty FOL literal case callsites and all fixed NTM/coherence/adaptive recipes analytically counted, no factory execution.',
 'admission':'Source-only author completion. Whole component qualification remains unexecuted and unadmitted until all Source/caller/once/evidence gates. No theorem-discovery claim.',
 'terminal_state':'IDLE'})
print(json.dumps({'handoff':handoff,'worker':sources['worker'],'observer':sources['observer'],'ABI':apipin,'plan_contract':planpin,'census':census,'manual':walk,'static':static,'terminal_state':'IDLE'},sort_keys=True))
