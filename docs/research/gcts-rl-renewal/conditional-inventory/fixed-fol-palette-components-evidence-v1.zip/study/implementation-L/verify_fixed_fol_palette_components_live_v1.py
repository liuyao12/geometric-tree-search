"""Inert once-authorized full-body normal-TLS verification of three new files.

No retry, redirect, certificate bypass, scientific import or archive decoder.
Root must adopt the publication/caller and externally authenticate this Source.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import ssl
import stat
import sys
import time
import traceback
import urllib.error
import urllib.request

VERSION = 'FIXED-FOL-PALETTE-COMPONENTS-LIVE-TLS-v1'
STUDY = Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
ROOT = STUDY / 'root'
SELF_PATH = STUDY / 'implementation-L/verify_fixed_fol_palette_components_live_v1.py'
PUBLICATION = ROOT / 'publication-fixed-fol-palette-components-api-v1/terminal.json'
OUT = ROOT / 'fixed-fol-palette-components-live-TLS-verification-v1'
ROOT_STAGE = ROOT / 'publication-fixed-fol-palette-components-v1'
PUBLISHER_STAGE = STUDY / 'publisher-components-payload'
ORIGIN = 'https://liuyao12.github.io'
URL_PREFIX = '/geometric-tree-search/docs/research/gcts-rl-renewal/conditional-inventory/'
GIT_PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'
NAMES = ('fixed-fol-palette-components-v1.html',
         'fixed-fol-palette-components-results-v1.json',
         'fixed-fol-palette-components-evidence-v1.zip')
CAPS = (1048576, 8388608, 33554432)
PYTHON = {'path': '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',
          'bytes': 18058560, 'sha256': 'd90bce0f5ac3aa40e2ee5900ad243bad0b2205ce17408278f088b34aed737840'}
ADMIN_CAP = 1048576
HEADER_CAP = 65536
OUTPUT_CAP = 50331648
OUTPUT_COUNT = 16
SOCKET_TIMEOUT = 45
WALL_SECONDS = 180


def need(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def parse(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def nonfinite(value):
        raise ValueError('nonfinite JSON')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def canonical(value):
    need(type(value) is str, 'literal path string')
    p = Path(value)
    need(p.is_absolute() and str(p) == value and os.path.normpath(value) == value
         and all(not q.is_symlink() for q in (p, *p.parents)) and p.resolve() == p,
         'absolute canonical nonsymlink path')
    return p


def pin(path, raw):
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def read(path, cap):
    path = canonical(str(path))
    before = path.stat(follow_symlinks=False)
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= cap,
         'bounded single-link regular file')
    with path.open('rb') as handle:
        raw = handle.read(cap + 1)
    after = path.stat(follow_symlinks=False)
    need(len(raw) <= cap and len(raw) == before.st_size == after.st_size
         and (before.st_dev, before.st_ino, before.st_mtime_ns)
         == (after.st_dev, after.st_ino, after.st_mtime_ns), 'changed or incomplete file')
    return raw


def fields(value, names):
    need(type(value) is dict and all(type(k) is str for k in value) and set(value) == set(names), 'exact record fields')


def rawref(value, cap):
    fields(value, ('path', 'bytes', 'sha256'))
    need(type(value['bytes']) is int and 0 <= value['bytes'] <= cap
         and type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None,
         'typed rawref')
    raw = read(canonical(value['path']), cap)
    need(encode(pin(value['path'], raw)) == encode(value), 'complete rawref identity')
    return raw


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()


def admin(value):
    p = canonical(value)
    need(p.parent == ROOT and p.suffix == '.json' and not p.name.startswith('.'), 'Root JSON path')
    raw = read(p, ADMIN_CAP)
    return parse(raw), pin(p, raw)


def create(path, raw, cap):
    need(len(raw) <= cap, 'output body cap')
    canonical(str(path))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    need(read(path, cap) == raw, 'full output readback')
    return pin(path, raw)


def save(name, raw, cap):
    need(re.fullmatch('[a-z0-9][a-z0-9_.-]*', name) is not None, 'receipt basename')
    paths = list(OUT.iterdir())
    need(len(paths) + 1 <= OUTPUT_COUNT and sum(p.stat().st_size for p in paths) + len(raw) <= OUTPUT_CAP,
         'receipt aggregate/count cap')
    return create(OUT / name, raw, cap)


def guards(plan, plan_ref, authority_ref, verifier_ref):
    for value in (plan_ref, authority_ref, verifier_ref, plan['publication']):
        rawref(value, ADMIN_CAP)
    rawref(PYTHON, PYTHON['bytes'])
    bodies = []
    for row, name, cap in zip(plan['files'], NAMES, CAPS, strict=True):
        fields(row, ('path', 'root_source', 'publisher_source', 'git_blob_sha1'))
        need(row['path'] == GIT_PREFIX + name and type(row['git_blob_sha1']) is str
             and re.fullmatch('[0-9a-f]{40}', row['git_blob_sha1']) is not None, 'fixed target/Git blob')
        need(row['root_source']['path'] == str(ROOT_STAGE / name)
             and row['publisher_source']['path'] == str(PUBLISHER_STAGE / name), 'fixed payload twin paths')
        a, b = rawref(row['root_source'], cap), rawref(row['publisher_source'], cap)
        need(a == b and blob(a) == row['git_blob_sha1'], 'complete expected twins/Git blob')
        bodies.append(a)
    return bodies


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, newurl):
        return None


def fetch(opener, url, cap, started):
    entered = time.monotonic()
    request = urllib.request.Request(url, headers={'Cache-Control': 'no-cache',
                                      'Accept-Encoding': 'identity', 'User-Agent': 'fixed-fol-components-normal-TLS-v1'})
    try:
        response = opener.open(request, timeout=SOCKET_TIMEOUT)
    except urllib.error.HTTPError as error:
        response = error  # Save this response once; never follow or retry it.
    opened = time.monotonic()
    with response:
        headers = [[k, v] for k, v in response.headers.raw_items()]
        need(len(encode(headers)) <= HEADER_CAP, 'parsed HTTP header cap')
        status, final_url = response.status, response.geturl()
        chunks, extent = [], 0
        while True:
            need(time.monotonic() - started <= WALL_SECONDS, 'cooperative whole verifier wall ceiling')
            chunk = response.read(min(65536, cap + 1 - extent))
            if not chunk:
                break
            extent += len(chunk)
            chunks.append(chunk)
            need(extent <= cap, 'complete live body cap')
    finished = time.monotonic()
    raw = b''.join(chunks)
    lengths = [v for k, v in headers if k.lower() == 'content-length']
    need(all(re.fullmatch('[0-9]+', v) is not None and int(v) == len(raw) for v in lengths), 'Content-Length/full EOF association')
    return raw, {'schema': 'L-fixed-fol-components-normal-TLS-body-v1', 'requested_url': url,
                 'final_url': final_url, 'HTTP_status': status, 'parsed_headers': headers,
                 'body_bytes': len(raw), 'body_sha256': hashlib.sha256(raw).hexdigest(),
                 'body_git_blob_sha1': blob(raw), 'full_EOF': True,
                 'open_elapsed_seconds': opened - entered, 'full_fetch_elapsed_seconds': finished - entered,
                 'scope': 'One normal-TLS request; no redirect/retry/certificate bypass. Parsed headers, not raw TLS wire. Socket45s and sampled main-entry180s checks are not an OS hard whole-lifetime quota.'}


def verify(plan_arg, authority_arg, started):
    need(Path(__file__) == SELF_PATH and sys.executable == PYTHON['path'] and sys.platform == 'darwin'
         and sys.version_info[:3] == (3, 12, 14) and sys.flags.isolated == 1
         and sys.flags.no_site == 1 and sys.flags.optimize == 0 and sys.dont_write_bytecode, 'current Source/D90 -I -S -B')
    plan, plan_ref = admin(plan_arg)
    fields(plan, ('schema', 'commit', 'publication', 'files'))
    need(plan['schema'] == 'Root-fixed-fol-palette-components-TLS-plan-v1'
         and type(plan['commit']) is str and re.fullmatch('[0-9a-f]{40}', plan['commit']) is not None
         and type(plan['files']) is list and len(plan['files']) == 3, 'closed exact TLS plan')
    need(plan['publication']['path'] == str(PUBLICATION), 'current publication receipt path')
    pub = parse(rawref(plan['publication'], ADMIN_CAP))
    need(pub['schema'] == 'Root-fixed-fol-palette-components-P2-terminal-v1'
         and pub['status'] == 'EXACT_THREE_NEW_PATHS_COMMITTED_LIVE_CHECK_PENDING'
         and pub['commit'] == plan['commit'] and encode(pub['files']) == encode(plan['files']), 'published commit/full target association')
    authority, authority_ref = admin(authority_arg)
    fields(authority, ('schema', 'authorized', 'uses', 'plan', 'verifier', 'python'))
    verifier_ref = authority['verifier']
    need(verifier_ref['path'] == str(SELF_PATH), 'current verifier Source path')
    rawref(verifier_ref, ADMIN_CAP)
    expected = {'schema': 'Root-fixed-fol-palette-components-TLS-once-authority-v1', 'authorized': True,
                'uses': 1, 'plan': plan_ref, 'verifier': verifier_ref, 'python': PYTHON}
    need(encode(authority) == encode(expected), 'whole typed TLS authority')
    rawref(PYTHON, PYTHON['bytes'])
    marker = Path(authority_ref['path'] + '.CONSUMED.json')
    need(not marker.exists() and not marker.is_symlink() and not OUT.exists() and not OUT.is_symlink(), 'fresh once marker/output')
    consumed = create(marker, encode({'schema': 'Root-fixed-fol-palette-components-TLS-consumed-v1',
                      'uses': 1, 'authority': authority_ref, 'plan': plan_ref, 'verifier': verifier_ref,
                      'meaning': 'permanently spent before first TLS request; never retry'}), ADMIN_CAP)
    fd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    OUT.mkdir(mode=0o700)
    bodies = guards(plan, plan_ref, authority_ref, verifier_ref)
    save('preflight.json', encode({'plan': plan_ref, 'authority': authority_ref, 'verifier': verifier_ref,
                                 'python': PYTHON, 'consumed': consumed}), ADMIN_CAP)
    context = ssl.create_default_context()
    need(context.check_hostname is True and context.verify_mode == ssl.CERT_REQUIRED, 'normal certificate/hostname verification')
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=context), NoRedirect())
    records = []
    for index, (name, cap, expected_body) in enumerate(zip(NAMES, CAPS, bodies, strict=True)):
        url = ORIGIN + URL_PREFIX + name + '?gcts_commit=' + plan['commit']
        raw, transport = fetch(opener, url, cap, started)
        body_ref = save(name, raw, cap)
        transport['saved_body'] = body_ref
        transport_ref = save('body-' + str(index) + '-transport.json', encode(transport), ADMIN_CAP)
        need(type(transport['HTTP_status']) is int and transport['HTTP_status'] == 200
             and transport['final_url'] == url and raw == expected_body
             and transport['body_git_blob_sha1'] == plan['files'][index]['git_blob_sha1'], 'complete status/URL/raw/hash/Gitblob mismatch; no retry')
        records.append({'target': plan['files'][index], 'body': body_ref, 'transport': transport_ref})
    need(guards(plan, plan_ref, authority_ref, verifier_ref) == bodies, 'all complete local postguards')
    rawref(consumed, ADMIN_CAP)
    for row in records:
        rawref(row['body'], max(CAPS))
        rawref(row['transport'], ADMIN_CAP)
    need(time.monotonic() - started <= WALL_SECONDS, 'late cooperative verifier wall ceiling')
    result = {'schema': 'Root-fixed-fol-palette-components-live-TLS-terminal-v1', 'status': 'ALL_THREE_COMPLETE_BODIES_MATCH',
              'version': VERSION, 'commit': plan['commit'], 'plan': plan_ref, 'authority': authority_ref,
              'consumed': consumed, 'verifier': verifier_ref, 'python': PYTHON, 'publication': plan['publication'],
              'bodies': records, 'normal_TLS': True, 'requests': 3,
              'main_entry_elapsed_seconds_before_terminal': time.monotonic() - started,
              'scope': 'Full body transport equality only; no scientific recheck. Needs original caller exit0/full captures. Final terminal serialization/readback/flush/shutdown tail follows sample. No primary reader fetched.'}
    terminal = save('terminal.json', encode(result), ADMIN_CAP)
    return {'schema': 'Root-fixed-fol-palette-components-TLS-outer-v1', 'status': result['status'],
            'commit': plan['commit'], 'terminal': terminal, 'requires_authoritative_exit_zero': True}


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--authority', required=True)
    args = parser.parse_args()
    try:
        result = verify(args.plan, args.authority, started)
        sys.stdout.buffer.write(encode(result))
        sys.stdout.buffer.flush()
        return 0
    except Exception as error:
        try:
            if OUT.is_dir() and not OUT.is_symlink():
                save('failure.json', encode({'schema': 'Root-fixed-fol-palette-components-TLS-failure-v1',
                     'status': 'UNADMITTED_NO_AUTOMATIC_RETRY', 'exception_type': type(error).__name__,
                     'message': str(error), 'scope': 'Any existing marker remains spent; saved complete/prefix responses do not admit the whole verification.'}), ADMIN_CAP)
        except Exception:
            pass
        traceback.print_exc(file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
