"""Pure finite NTM -> translation-only Wang computation-tile compiler.

No board, boundary caps, simulation, proof search, I/O, or import-time calls.
A complete palette is local computation syntax, not an accepting certificate.
"""
import hashlib
import json

VERSION = 'FINITE_NTM_TRANSLATION_WANG_COMPILER-v1'
_SCHEMA = 'L-finite-NTM-translation-Wang-compile-result-v1'
_PHASES = ('CHOOSE', 'EXEC')


class _Rejected(Exception):
    def __init__(self, code, detail):
        self.code = code
        self.detail = detail
        super().__init__(code)


class _BudgetStop(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


class _Meter:
    def __init__(self, maximum, counts):
        self.maximum = maximum
        self.counts = counts

    def tick(self):
        if self.counts['operations'] >= self.maximum:
            raise _BudgetStop('OPERATION_CAP')
        self.counts['operations'] += 1


def _need(ok, code, detail):
    if not ok:
        raise _Rejected(code, detail)


def _wire(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False)


def _new_counts():
    return {
        'operations': 0, 'complete_census': False,
        'input_states': 0, 'input_symbols': 0, 'input_transitions': 0,
        'accepting_states': 0, 'implicit_absorbing_transitions': 0,
        'effective_transition_count': 0,
        'choose_glyph_count': 0, 'exec_glyph_count': 0,
        'choose_triples_total': 0, 'exec_triples_total': 0,
        'choose_triples_examined': 0, 'exec_triples_examined': 0,
        'choose_valid_triples': 0, 'exec_valid_triples': 0,
        'choose_tiles': 0, 'exec_tiles': 0, 'tiles_constructed': 0,
        'choose_rejections': {'MULTIPLE_HEADS': 0, 'NO_TRANSITION': 0},
        'exec_rejections': {'MULTIPLE_HEADS': 0, 'WALL_ESCAPE': 0},
    }


def _limits(value):
    _need(type(value) is dict and set(value) == {'max_operations', 'max_tiles'},
          'LIMITS_SHAPE', 'limits must have exactly max_operations and max_tiles')
    for key in ('max_operations', 'max_tiles'):
        _need(type(value[key]) is int and value[key] >= 0,
              'LIMITS_VALUE', 'limits must be exact nonnegative integers')
    return {key: value[key] for key in ('max_operations', 'max_tiles')}


def _text(value, meter):
    meter.tick()
    _need(type(value) is str, 'STRING_TYPE', 'machine names must be exact strings')
    for unused_character in value:
        meter.tick()
    return value


def _strings(value, meter, nonempty):
    meter.tick()
    _need(type(value) is list and (not nonempty or bool(value)),
          'STRING_LIST', 'declared string list has invalid type or is empty')
    result, seen = [], set()
    for item in value:
        meter.tick()
        item = _text(item, meter)
        _need(item not in seen, 'DUPLICATE_NAME', 'declared names must be distinct')
        seen.add(item)
        result.append(item)
    return sorted(result)


def _normalise(value, meter, counts):
    meter.tick()
    _need(type(value) is dict and set(value) == {
        'states', 'alphabet', 'transitions', 'start', 'accept'},
        'MACHINE_SHAPE', 'machine must have exactly the five declared fields')
    states = _strings(value['states'], meter, True)
    alphabet = _strings(value['alphabet'], meter, True)
    accept = _strings(value['accept'], meter, False)
    state_set, symbol_set, accept_set = set(states), set(alphabet), set(accept)
    _need(accept_set <= state_set, 'ACCEPT_STATE', 'accept names must be states')
    start = _text(value['start'], meter)
    _need(start in state_set, 'START_STATE', 'start must name a declared state')
    _need(type(value['transitions']) is list, 'TRANSITION_LIST',
          'transitions must be an exact list')
    transitions, seen = [], set()
    for row in value['transitions']:
        meter.tick()
        _need(type(row) is list and len(row) == 5, 'TRANSITION_SHAPE',
              'transition must be an exact five-element list')
        q, read, nxt, write = [_text(row[i], meter) for i in range(4)]
        move = row[4]
        _need(q in state_set and nxt in state_set and read in symbol_set
              and write in symbol_set, 'TRANSITION_NAME',
              'transition names must be declared')
        _need(type(move) is int and move in (-1, 0, 1), 'TRANSITION_MOVE',
              'move must be an exact integer -1, 0, or 1')
        record = (q, read, nxt, write, move)
        _need(record not in seen, 'DUPLICATE_TRANSITION',
              'exact duplicate transitions are not allowed')
        _need(q not in accept_set or record == (q, read, q, read, 0),
              'ACCEPT_OUTGOING_CONFLICT',
              'accept-state outgoing must agree with implicit identity stay')
        seen.add(record)
        transitions.append(record)
    counts['input_states'] = len(states)
    counts['input_symbols'] = len(alphabet)
    counts['input_transitions'] = len(transitions)
    counts['accepting_states'] = len(accept)
    return {'states': states, 'alphabet': alphabet,
            'transitions': [list(row) for row in sorted(transitions)],
            'start': start, 'accept': accept}


def _machine_hash(machine, meter):
    meter.tick()
    result = hashlib.sha256((_wire(machine) + '\n').encode('ascii')).hexdigest()
    meter.tick()
    return result


def _effective(machine, meter, counts):
    accept = set(machine['accept'])
    rows = []
    for row in machine['transitions']:
        meter.tick()
        if row[0] not in accept:
            rows.append(tuple(row))
    for q in machine['accept']:
        for symbol in machine['alphabet']:
            meter.tick()
            rows.append((q, symbol, q, symbol, 0))
            counts['implicit_absorbing_transitions'] += 1
    result = []
    for index, row in enumerate(sorted(rows)):
        meter.tick()
        q, read, nxt, write, move = row
        result.append({'index': index, 'q': q, 'read': read, 'next': nxt,
                       'write': write, 'move': move,
                       'origin': 'IMPLICIT_ACCEPT' if q in accept else 'EXPLICIT'})
    counts['effective_transition_count'] = len(result)
    return result


def _glyph_sets(machine, effective, meter, counts):
    common = [('wall',)]
    for symbol in machine['alphabet']:
        meter.tick()
        common.append(('plain', symbol))
    choose = list(common)
    for q in machine['states']:
        for symbol in machine['alphabet']:
            meter.tick()
            choose.append(('normalHead', q, symbol))
    execute = list(common)
    for row in effective:
        meter.tick()
        execute.append(('taggedHead', row['q'], row['read'], row['index']))
    choose, execute = sorted(choose, key=_wire), sorted(execute, key=_wire)
    counts['choose_glyph_count'] = len(choose)
    counts['exec_glyph_count'] = len(execute)
    counts['choose_triples_total'] = len(choose) ** 3
    counts['exec_triples_total'] = len(execute) ** 3
    return {'CHOOSE': choose, 'EXEC': execute}


def _choices_by_read(effective, meter):
    result = {}
    for row in effective:
        meter.tick()
        result.setdefault((row['q'], row['read']), []).append(row['index'])
    return result


def _choose_rule(left, center, right, choices):
    if sum(glyph[0] == 'normalHead' for glyph in (left, center, right)) > 1:
        return 'MULTIPLE_HEADS', None
    if center[0] == 'normalHead':
        indexes = choices.get((center[1], center[2]), ())
        if not indexes:
            return 'NO_TRANSITION', None
        return None, indexes
    return None, (None,)


def _exec_rule(left, center, right, effective):
    heads = [(i, glyph) for i, glyph in enumerate((left, center, right))
             if glyph[0] == 'taggedHead']
    if len(heads) > 1:
        return 'MULTIPLE_HEADS', None, None, None
    if not heads:
        return None, center, None, 'COPY'
    position, tag = heads[0]
    transition = effective[tag[3]]
    index, move = transition['index'], transition['move']
    if position == 1:
        if (move == -1 and left[0] == 'wall') or (move == 1 and right[0] == 'wall'):
            return 'WALL_ESCAPE', None, None, None
        if move == 0:
            return None, ('normalHead', transition['next'], transition['write']), index, 'STAY_HEAD'
        return None, ('plain', transition['write']), index, 'WRITE_AND_LEAVE'
    enters_center = (position == 0 and move == 1) or (position == 2 and move == -1)
    if enters_center:
        if center[0] == 'wall':
            return 'WALL_ESCAPE', None, None, None
        return None, ('normalHead', transition['next'], center[1]), index, 'RECEIVE_HEAD'
    return None, center, index, 'COPY'


def _emit(phase, triple, output, index, action, palette, witnesses, limits, meter, counts):
    if counts['tiles_constructed'] >= limits['max_tiles']:
        raise _BudgetStop('TILE_CAP')
    meter.tick()
    left, center, right = triple
    following = 'EXEC' if phase == 'CHOOSE' else 'CHOOSE'
    identity = _wire(['T', phase, left, center, right, output])
    palette.append({'id': identity,
                    'N': _wire(['V', phase, center]),
                    'E': _wire(['H', phase, center, right]),
                    'S': _wire(['V', following, output]),
                    'W': _wire(['H', phase, left, center])})
    witnesses.append({'tile_id': identity, 'phase': phase,
                      'triple': [list(left), list(center), list(right)],
                      'output': list(output), 'transition_index': index, 'action': action})
    counts['tiles_constructed'] += 1
    counts['choose_tiles' if phase == 'CHOOSE' else 'exec_tiles'] += 1


def _enumerate(glyphs, effective, choices, limits, meter, counts):
    palette, witnesses = [], []
    for phase in _PHASES:
        prefix = 'choose' if phase == 'CHOOSE' else 'exec'
        for left in glyphs[phase]:
            for center in glyphs[phase]:
                for right in glyphs[phase]:
                    meter.tick()
                    counts[prefix + '_triples_examined'] += 1
                    if phase == 'CHOOSE':
                        rejection, indexes = _choose_rule(left, center, right, choices)
                        if rejection is not None:
                            counts['choose_rejections'][rejection] += 1
                            continue
                        counts['choose_valid_triples'] += 1
                        for index in indexes:
                            meter.tick()
                            output = center if index is None else (
                                'taggedHead', center[1], center[2], index)
                            _emit(phase, (left, center, right), output, index,
                                  'COPY' if index is None else 'SELECT',
                                  palette, witnesses, limits, meter, counts)
                    else:
                        rejection, output, index, action = _exec_rule(
                            left, center, right, effective)
                        if rejection is not None:
                            counts['exec_rejections'][rejection] += 1
                            continue
                        counts['exec_valid_triples'] += 1
                        meter.tick()
                        _emit(phase, (left, center, right), output, index, action,
                              palette, witnesses, limits, meter, counts)
    return palette, witnesses


def _public_glyphs(glyphs, meter):
    result = {}
    for phase in _PHASES:
        result[phase] = []
        for glyph in glyphs[phase]:
            meter.tick()
            result[phase].append({'id': _wire(glyph), 'glyph': list(glyph)})
    return result


def _receipt(status, machine, fingerprint, limits, effective, glyphs,
             palette, witnesses, counts, reason):
    return {'schema': _SCHEMA, 'version': VERSION, 'status': status,
            'machine': machine, 'machine_sha256': fingerprint, 'limits': limits,
            'effective_transitions': effective, 'glyphs': glyphs,
            'palette': palette, 'witnesses': witnesses, 'counts': counts, 'reason': reason}


def compile_palette(machine, limits):
    """Compile all local rules or return no palette; never run the machine."""
    counts = _new_counts()
    normal_limits, normal_machine, fingerprint = None, None, None
    try:
        normal_limits = _limits(limits)
        meter = _Meter(normal_limits['max_operations'], counts)
        normal_machine = _normalise(machine, meter, counts)
        fingerprint = _machine_hash(normal_machine, meter)
        effective = _effective(normal_machine, meter, counts)
        glyphs = _glyph_sets(normal_machine, effective, meter, counts)
        choices = _choices_by_read(effective, meter)
        palette, witnesses = _enumerate(
            glyphs, effective, choices, normal_limits, meter, counts)
        public_glyphs = _public_glyphs(glyphs, meter)
        meter.tick()
        counts['complete_census'] = True
        return _receipt('COMPLETE', normal_machine, fingerprint, normal_limits,
                        effective, public_glyphs, palette, witnesses, counts, None)
    except _BudgetStop as error:
        return _receipt('UNKNOWN_BUDGET', normal_machine, fingerprint, normal_limits,
                        None, None, None, None, counts,
                        {'code': error.code, 'detail': 'No partial palette is returned'})
    except _Rejected as error:
        return _receipt('REJECTED', normal_machine, fingerprint, normal_limits,
                        None, None, None, None, counts,
                        {'code': error.code, 'detail': error.detail})
