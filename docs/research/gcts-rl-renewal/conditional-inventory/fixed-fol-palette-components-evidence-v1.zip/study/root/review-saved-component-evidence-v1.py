"""Administrative saved-data joins only. Never imports or calls subjects."""
from pathlib import Path
import collections
import hashlib
import json

P = Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1')
R = P / 'root'
A = P / 'actual/qualification-001'


def encode(v):
    return (json.dumps(v, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode()


def sha(b):
    return hashlib.sha256(b).hexdigest()


def pin(q):
    b = q.read_bytes()
    return {'path': str(q), 'bytes': len(b), 'sha256': sha(b)}


def read_ref(v):
    assert type(v) is dict and set(v) == {'path', 'bytes', 'sha256'}
    assert type(v['bytes']) is int and v['bytes'] >= 0
    assert pin(Path(v['path'])) == v
    return json.loads(Path(v['path']).read_bytes())


def untyped(v, keep_tuple=True):
    k = v['type']
    if k == 'dict':
        return {untyped(a, keep_tuple): untyped(b, keep_tuple) for a, b in v['items']}
    if k in ('list', 'tuple'):
        items = [untyped(x, keep_tuple) for x in v['items']]
        return tuple(items) if k == 'tuple' and keep_tuple else items
    return v['value']


calls = collections.Counter()


def typed_record(v, role):
    assert sha(encode(v['request_typed'])) == v['request_typed_sha256']
    assert sha(encode(v['return'])) == v['return_sha256']
    assert v['input_unchanged'] is True
    calls[role] += 1
    return untyped(v['request_typed'])


def row_record(v):
    q = v['request']
    artifact = read_ref(q['compiled_artifact'])
    compiled = artifact['compiled'] if 'compiled' in artifact else artifact['evidence']['return']
    assert sha(encode(compiled)) == q['compiled_return_sha256']
    args = [q['machine'], compiled, q['initial'], q['steps'], q['limits']]
    assert sha(encode(args)) == v['resolved_full_request_sha256']
    assert sha(encode(v['return'])) == v['return_sha256']
    assert v['input_unchanged'] is True
    calls['rows'] += 1
    return args


def wire(v):
    return json.dumps(v, ensure_ascii=True, separators=(',', ':'), allow_nan=False)


plan_ref = pin(R / 'component-qualification-once-plan-001.json')
plan = read_ref(plan_ref)
owned = json.loads((R / 'qualification-001-original-owned-exec-v1.json').read_bytes())
assert owned['original_chunk_id'] == 'be29eb' and owned['original_exit_code'] == 0 and owned['invocations'] == 1
outer = json.loads((R / 'qualification-001-outer-stdout.bin').read_bytes())
assert (R / 'qualification-001-outer-stderr.bin').read_bytes() == b''
assert outer['status'] == 'COMPLETE_NORMAL'
custody = read_ref(outer['custody'])
result = read_ref(outer['admitted_result_candidate'])
assert result['status'] == 'COMPLETE_PASS' and result['plan'] == plan_ref
assert custody['plan'] == plan_ref and custody['result'] == outer['admitted_result_candidate']
assert custody['Source_and_runtime_pre_post_exact'] is True
child = custody['child']
assert child['child_exit'] == 0 and child['fault'] is None and child['supervisor_exception'] is None
assert child['cleanup_errors'] == [] and child['owned_wait_complete'] is True
assert child['process_group_gone'] is True and all(v is True for v in child['log_eof'].values())
assert child['child_lifetime_highwater_bytes'] <= plan['limits']['child_rss_bytes']
assert result['source_guards'] == plan['sources'] and result['metadata_guards'] == plan['metadata']
for v in [*plan['sources'].values(), *plan['metadata'].values(), plan['python']]:
    assert pin(Path(v['path'])) == v
consume = read_ref(custody['consumed'])
authority = read_ref(custody['authority'])
assert consume == {'schema': 'Root-FOL-NTM-component-once-consumed-v2', 'uses': 1, 'case_id': plan['case_id'], 'plan': plan_ref, 'authority': custody['authority'], 'observer': plan['sources']['observer'], 'meaning': 'exclusive spent marker before the sole child launch; failures remain spent'}
assert authority == {'schema': 'Root-FOL-NTM-component-once-authority-v2', 'authorized': True, 'uses': 1, 'case_id': plan['case_id'], 'plan': plan_ref, 'observer': plan['sources']['observer']}
files = {str(q): pin(q) for q in A.iterdir()}
assert len(files) == outer['owned_file_count'] == 22
assert sum(v['bytes'] for v in files.values()) == outer['owned_named_bytes']
assert {v['path']: v for v in custody['all_prior_owned_files']} == {k: v for k, v in files.items() if not k.endswith('/custody.json')}
for v in custody['all_prior_owned_files']:
    assert pin(Path(v['path'])) == v
for v in custody['captures'].values():
    assert pin(Path(v['path'])) == v
assert (A / 'worker-stderr.bin').read_bytes() == b''
assert (A / 'worker-stdout.bin').read_bytes() == encode(custody['worker_terminal'])
assert custody['worker_terminal']['result'] == outer['admitted_result_candidate']
allbytes = sum(v['bytes'] for v in files.values()) + sum((R / ('qualification-001-outer-' + x + '.bin')).stat().st_size for x in ('stdout', 'stderr'))
assert len(files) + 2 <= plan['limits']['max_output_files'] and allbytes <= plan['limits']['total_output_bytes']
for v in result['evidence']['all_prior_outputs']:
    read_ref(v)

fol = read_ref(result['evidence']['fol'])['controls']
census = json.loads((P / 'implementation-C/component-qualification-exact-controlled-census-v3.json').read_bytes())
assert len(fol) == 40
status_counts = collections.Counter()
logical_display = []
for c, expected in zip(fol, census['fol_controls']):
    assert (c['id'], c['label'], c['expected_status'], c['legacy_compatible']) == (expected['id'], expected['label'], expected['expected_status'], expected['legacy_compatible'])
    ev = c['evidence']
    args = typed_record(ev, 'fol')
    assert ev['return']['status'] == c['expected_status']
    status_counts[ev['return']['status']] += 1
    assert sum(ev['return']['visits']['by_kind'].values()) == ev['return']['visits']['operations']
    if c['legacy_compatible']:
        assert ev['legacy_return'] is True and ev['legacy_input_unchanged'] is True
        assert sha(encode(ev['legacy_request_typed'])) == ev['legacy_request_typed_sha256']
        assert untyped(ev['legacy_request_typed'], False) == [[args[0]['functions'], args[0]['predicates'], args[0]['axioms']], args[1], args[2]]
        calls['legacy'] += 1
    def display(v):
        if type(v) is tuple:
            return {'malformed_tuple_not_list': [display(x) for x in v]}
        if type(v) is list:
            return [display(x) for x in v]
        if type(v) is dict:
            return {k: display(x) for k, x in v.items()}
        return v
    logical_display.append({'id': c['id'], 'label': c['label'], 'theory': display(args[0]), 'proof': display(args[1]), 'target': display(args[2]), 'result': ev['return']})
assert dict(status_counts) == census['fol_expected_status_counts']

machines = []
palette_witness_rows = 0
for i in range(2):
    artifact = json.loads((A / ('palette-%d.json' % i)).read_bytes())
    args = typed_record(artifact['evidence'], 'compiler')
    compiled = artifact['evidence']['return']
    palette = compiled['palette']
    assert len(palette) == len(compiled['witnesses']) == compiled['counts']['tiles_constructed']
    assert len({t['id'] for t in palette}) == len(palette)
    assert [t['id'] for t in palette] == [w['tile_id'] for w in compiled['witnesses']]
    for t, witness in zip(palette, compiled['witnesses']):
        d = json.loads(t['id'])
        assert wire(d) == t['id'] and len(d) == 6 and d[0] == 'T'
        phase, left, center, right, out = d[1:]
        other = 'EXEC' if phase == 'CHOOSE' else 'CHOOSE'
        assert {k: t[k] for k in ('N', 'S', 'W', 'E')} == {'N': wire(['V', phase, center]), 'S': wire(['V', other, out]), 'W': wire(['H', phase, left, center]), 'E': wire(['H', phase, center, right])}
        assert witness['phase'] == phase and witness['triple'] == [left, center, right] and witness['output'] == out
        palette_witness_rows += 1
    machines.append({'label': artifact['label'], 'machine': args[0], 'palette': palette, 'counts': compiled['counts'], 'contexts': []})

contexts = []
grids = tile_placements = 0
for ref in result['evidence']['contexts']:
    contexts.extend(read_ref(ref)['contexts'])
assert [c['context'] for c in contexts] == list(range(120))
for c in contexts:
    m = machines[c['machine']]
    refargs = typed_record(c['reference'], 'reference')
    rowargs = row_record(c['rows'])
    assert refargs[0] == m['machine'] == rowargs[0] and refargs[1] == c['initial'] == rowargs[2]
    assert refargs[2] == rowargs[3] == 2
    rr = c['reference']['return']
    wr = c['rows']['return']
    assert rr['status'] == wr['status'] == 'COMPLETE' and rr['complete'] is True
    assert rr['acceptance']['at_requested_step'] is wr['accepts']
    assert [l['step'] for l in rr['layers']] == [0, 1, 2] == [l['step'] for l in wr['layers']]
    palette = {t['id']: t for t in m['palette']}
    for l, q in zip(rr['layers'], wr['layers']):
        assert encode(l['configurations']) == encode(q['configurations'])
        assert l['count'] == len(q['configurations'])
        assert l['accepting_count'] == sum(x['state'] in m['machine']['accept'] for x in q['configurations'])
        assert [w['configuration'] for w in q['witnesses']] == q['configurations']
        for w in q['witnesses']:
            assert len(w['tile_rows']) == 2 * l['step']
            current = [['wall']] + [(['normalHead', c['initial']['state'], symbol] if j == c['initial']['head'] else ['plain', symbol]) for j, symbol in enumerate(c['initial']['tape'])] + [['wall']]
            for halfstep, ids in enumerate(w['tile_rows']):
                phase = 'EXEC' if halfstep % 2 else 'CHOOSE'
                assert len(ids) == len(current) == 5
                west = wire(['H', phase, ['wall'], ['wall']])
                output = []
                for j, ident in enumerate(ids):
                    tile = palette[ident]
                    assert tile['N'] == wire(['V', phase, current[j]]) and tile['W'] == west
                    output.append(json.loads(tile['S'])[2])
                    west = tile['E']
                    tile_placements += 1
                assert west == wire(['H', phase, ['wall'], ['wall']])
                assert output[0] == output[-1] == ['wall']
                current = output
            heads = [(j, x) for j, x in enumerate(current[1:-1]) if x[0] == 'normalHead']
            assert len(heads) == 1
            j, head = heads[0]
            decoded = {'state': head[1], 'head': j, 'tape': [x[2] if x[0] == 'normalHead' else x[1] for x in current[1:-1]]}
            assert decoded == w['configuration']
            grids += 1
    assert c['all_layers_and_literal_witnesses_match'] is True
    m['contexts'].append({'context': c['context'], 'initial': c['initial'], 'layers': wr['layers']})
for m, expected in zip(machines, (72, 48)):
    assert len(m['contexts']) == expected
    assert len({encode(c['initial']) for c in m['contexts']}) == expected
    assert all(c['initial']['state'] in m['machine']['states'] and c['initial']['head'] in (0, 1, 2) and len(c['initial']['tape']) == 3 and all(x in m['machine']['alphabet'] for x in c['initial']['tape']) for c in m['contexts'])

controls = read_ref(result['evidence']['additional_controls'])['controls']
assert len(controls) == 17 and len({c['id'] for c in controls}) == 17
for c in controls:
    if c['id'].startswith('N'):
        for role, key in [('compiler', 'compiler'), ('reference', 'reference')]:
            typed_record(c[key], role)
            assert c[key]['return']['status'] == c['expected_status'] == 'REJECTED'
    else:
        ev = c['evidence']
        if c['id'].startswith('C'):
            typed_record(ev, 'compiler')
        elif c['id'].startswith('R'):
            typed_record(ev, 'reference')
        else:
            row_record(ev)
        assert ev['return']['status'] == c['expected_status']
        if c['id'] == 'W07-empty-frontier-tail':
            baseline = c['baseline']
            original = contexts[baseline['context']]
            assert baseline['return'] == original['rows']['return'] and baseline['return_sha256'] == original['rows']['return_sha256']
            assert ev['request']['limits']['max_operations'] == baseline['return']['counts']['operations'] + 16
            assert ev['request']['steps'] == 1000000
assert dict(calls) == result['counts']['public_calls'] == {'fol': 40, 'legacy': 12, 'compiler': 10, 'reference': 128, 'rows': 127}
assert sum(calls.values()) == 317
review = {'schema': 'Root-complete-saved-component-evidence-review-v1', 'status': 'PASS_WHOLE_COHORT_PENDING_INDEPENDENT_DATA_PEER', 'original_owned_exec': pin(R / 'qualification-001-original-owned-exec-v1.json'), 'outer': pin(R / 'qualification-001-outer-stdout.bin'), 'custody': outer['custody'], 'result': outer['admitted_result_candidate'], 'plan': plan_ref, 'calls': dict(calls), 'fol_statuses': dict(status_counts), 'legacy_compatible': 12, 'palettes': [len(m['palette']) for m in machines], 'normal_contexts': len(contexts), 'normal_layers': 360, 'saved_witness_grids_including_zero_step': grids, 'literal_tile_placements_joined': tile_placements, 'palette_witness_rows_joined': palette_witness_rows, 'additional_controls': len(controls), 'owned_files': len(files), 'owned_plus_outer_bytes': allbytes, 'postrun_subject_execution': 0, 'method': 'Standard-library JSON/hash/typed-carrier/full rawref joins and literal saved-ID/edge/configuration associations only; no checker/simulator/compiler/codec/solver replay.', 'scope': result['scope']}
q = R / 'Root-complete-saved-component-evidence-review-v1.json'
q.open('xb').write(encode(review))
visual = {'schema': 'GCTS-fixed-FOL-palette-component-visual-data-v1', 'status': 'PENDING_INDEPENDENT_PEER', 'logic_controls': logical_display, 'machines': machines, 'counts': result['counts'], 'costs': custody['worker_terminal']['post_readback_costs'], 'custody_costs': custody['late_costs'], 'identities': {'Run': plan['case_id'], 'Plan SHA256': plan_ref['sha256'], 'Raw result SHA256': outer['admitted_result_candidate']['sha256'], 'Custody SHA256': outer['custody']['sha256']}}
v = R / 'component-visual-data-provisional-v1.json'
v.open('xb').write(encode(visual))
print(json.dumps({'review': pin(q), 'totals': review, 'provisional_visual_data': pin(v)}))
