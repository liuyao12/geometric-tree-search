"""Independent finite Wang-row control; not the reference GCTS scheduler.

This module reads literal tile edges. It never calls the compiler's transition
or glyph helpers. A separately authored global NTM simulator supplies the other
side of the qualification comparison. Valid one-head input and fixed walls are
explicit preconditions. This is not a proof searcher or a universal palette.
"""
import json


class _Invalid(Exception):
    pass


class _Limit(Exception):
    pass


class _Meter:
    def __init__(self, limits):
        if type(limits) is not dict or set(limits) != {
            'max_operations', 'max_row_solutions', 'max_distinct_rows'
        }:
            raise _Invalid('LIMIT_FIELDS')
        if any(type(v) is not int or v < 0 for v in limits.values()):
            raise _Invalid('LIMIT_VALUE')
        self.limits = dict(limits)
        self.counts = {'operations': 0, 'palette_tiles': 0, 'candidate_trials': 0,
                       'row_solutions': 0, 'halfsteps': 0, 'distinct_rows': 0}

    def tick(self, n=1):
        if n > self.limits['max_operations'] - self.counts['operations']:
            raise _Limit('OPERATION_CAP')
        self.counts['operations'] += n


def _wire(value):
    return json.dumps(value, ensure_ascii=True, separators=(',', ':'))


def _read(text, meter):
    if type(text) is not str:
        raise _Invalid('COLOR_TYPE')
    meter.tick(1 + len(text))
    try:
        value = json.loads(text)
    except (ValueError, TypeError):
        raise _Invalid('COLOR_JSON')
    if _wire(value) != text:
        raise _Invalid('NONCANONICAL_COLOR')
    return value


def _glyph(value, phase, machine, meter):
    meter.tick()
    if type(value) is not list or not value:
        raise _Invalid('GLYPH_ARRAY')
    if value == ['wall']:
        return
    if len(value) == 2 and value[0] == 'plain' and type(value[1]) is str:
        if value[1] not in machine['alphabet']:
            raise _Invalid('PLAIN_SYMBOL')
        return
    tag = 'normalHead' if phase == 'CHOOSE' else 'taggedHead'
    size = 3 if phase == 'CHOOSE' else 4
    if len(value) != size or value[0] != tag:
        raise _Invalid('HEAD_PHASE_OR_SHAPE')
    if type(value[1]) is not str or value[1] not in machine['states']:
        raise _Invalid('HEAD_STATE')
    if type(value[2]) is not str or value[2] not in machine['alphabet']:
        raise _Invalid('HEAD_SYMBOL')
    if size == 4 and (type(value[3]) is not int or value[3] < 0):
        raise _Invalid('TAG_INDEX')


def _tiles(compiled, machine, meter):
    if type(compiled) is not dict or compiled.get('status') != 'COMPLETE':
        raise _Invalid('INCOMPLETE_PALETTE')
    palette = compiled.get('palette')
    if type(palette) is not list:
        raise _Invalid('PALETTE_ARRAY')
    by_north = {}
    identities = set()
    for tile in palette:
        meter.tick()
        if type(tile) is not dict or set(tile) != {'id', 'N', 'E', 'S', 'W'}:
            raise _Invalid('TILE_FIELDS')
        ident = _read(tile['id'], meter)
        if (type(ident) is not list or len(ident) != 6 or ident[0] != 'T'
                or ident[1] not in ('CHOOSE', 'EXEC')):
            raise _Invalid('TILE_ID')
        if tile['id'] in identities:
            raise _Invalid('DUPLICATE_TILE')
        identities.add(tile['id'])
        _, phase, left, center, right, output = ident
        other = 'EXEC' if phase == 'CHOOSE' else 'CHOOSE'
        for glyph in (left, center, right):
            _glyph(glyph, phase, machine, meter)
        _glyph(output, other, machine, meter)
        expected = {'N': ['V', phase, center], 'S': ['V', other, output],
                    'W': ['H', phase, left, center],
                    'E': ['H', phase, center, right]}
        for key in ('N', 'E', 'S', 'W'):
            edge = _read(tile[key], meter)
            if tile[key] != _wire(expected[key]):
                raise _Invalid('TILE_EDGE_ID_MISMATCH')
        by_north.setdefault(tile['N'], {}).setdefault(tile['W'], []).append(dict(tile))
    meter.counts['palette_tiles'] = len(palette)
    return by_north


def _seed(machine, initial, meter):
    if type(machine) is not dict or set(machine) != {
            'states', 'alphabet', 'transitions', 'start', 'accept'}:
        raise _Invalid('MACHINE_FIELDS')
    for key in ('states', 'alphabet'):
        values = machine[key]
        if (type(values) is not list or not values
                or any(type(v) is not str for v in values)
                or len(set(values)) != len(values)):
            raise _Invalid('MACHINE_NAMES')
    if type(initial) is not dict or set(initial) != {'state', 'head', 'tape'}:
        raise _Invalid('INITIAL_FIELDS')
    tape, head, state = initial['tape'], initial['head'], initial['state']
    if (type(tape) is not list or not tape or type(head) is not int
            or not 0 <= head < len(tape) or type(state) is not str
            or state not in machine['states']
            or any(type(s) is not str or s not in machine['alphabet'] for s in tape)):
        raise _Invalid('INITIAL_CONFIGURATION')
    meter.tick(1 + len(tape))
    row = [['wall']]
    for index, symbol in enumerate(tape):
        row.append(['normalHead', state, symbol] if index == head else ['plain', symbol])
    row.append(['wall'])
    return row


def _row_solutions(row, phase, index, meter):
    north = [_wire(['V', phase, glyph]) for glyph in row]
    left_edge = _wire(['H', phase, ['wall'], row[0]])
    right_edge = _wire(['H', phase, row[-1], ['wall']])
    results = []

    def visit(column, west, south, ids):
        meter.tick()
        if column == len(row):
            if west == right_edge:
                if meter.counts['row_solutions'] >= meter.limits['max_row_solutions']:
                    raise _Limit('ROW_SOLUTION_CAP')
                meter.counts['row_solutions'] += 1
                results.append((list(south), list(ids)))
            return
        for tile in index.get(north[column], {}).get(west, ()):
            meter.tick()
            meter.counts['candidate_trials'] += 1
            output = _read(tile['S'], meter)[2]
            visit(column + 1, tile['E'], south + [output], ids + [tile['id']])

    visit(0, left_edge, [], [])
    return results


def _decode(row, phase, machine, meter):
    meter.tick(1 + len(row))
    if len(row) < 3 or row[0] != ['wall'] or row[-1] != ['wall']:
        raise _Invalid('WALL_LOST')
    wanted = 'normalHead' if phase == 'CHOOSE' else 'taggedHead'
    heads = []
    tape = []
    for index, glyph in enumerate(row[1:-1]):
        _glyph(glyph, phase, machine, meter)
        if glyph[0] == wanted:
            heads.append((index, glyph[1]))
            tape.append(glyph[2])
        elif glyph[0] == 'plain':
            tape.append(glyph[1])
        else:
            raise _Invalid('INTERIOR_WALL')
    if len(heads) != 1:
        raise _Invalid('ONE_HEAD_INVARIANT')
    return {'state': heads[0][1], 'head': heads[0][0], 'tape': tape}


def enumerate_tableaux(machine, compiled, initial, steps, limits):
    """Complete tiny-row enumeration with whole witnesses, or no admission.

    Even layers are normal global configurations. Odd tag rows are checked for
    one-head/wall shape but may have no completion (for example wall escape).
    Acceptance is reported only for the complete final normal configuration
    set. Caller independently compares all layers with its global simulator.
    """
    meter = None
    try:
        meter = _Meter(limits)
        if type(steps) is not int or steps < 0:
            raise _Invalid('STEP_BOUND')
        row = _seed(machine, initial, meter)
        index = _tiles(compiled, machine, meter)
        current = {_wire(row): (row, [])}
        initial_config = {'state': initial['state'], 'head': initial['head'],
                          'tape': list(initial['tape'])}
        layers = [{'step': 0, 'configurations': [initial_config],
                   'witnesses': [{'configuration': {
                       'state': initial['state'], 'head': initial['head'],
                       'tape': list(initial['tape'])}, 'tile_rows': []}]}]
        meter.counts['distinct_rows'] = 1
        if meter.limits['max_distinct_rows'] < 1:
            raise _Limit('DISTINCT_ROW_CAP')
        phase = 'CHOOSE'
        for halfstep in range(2 * steps):
            meter.tick()
            other = 'EXEC' if phase == 'CHOOSE' else 'CHOOSE'
            following = {}
            for key in sorted(current):
                old, old_rows = current[key]
                for output, ids in _row_solutions(old, phase, index, meter):
                    _decode(output, other, machine, meter)
                    key_out = _wire(output)
                    if key_out not in following:
                        if meter.counts['distinct_rows'] >= meter.limits['max_distinct_rows']:
                            raise _Limit('DISTINCT_ROW_CAP')
                        meter.counts['distinct_rows'] += 1
                        following[key_out] = (output, old_rows + [ids])
            current = following
            phase = other
            meter.counts['halfsteps'] = halfstep + 1
            if phase == 'CHOOSE':
                witnesses = [{'configuration': _decode(row, phase, machine, meter),
                              'tile_rows': path} for row, path in current.values()]
                witnesses.sort(key=lambda w: (w['configuration']['state'],
                                             w['configuration']['head'],
                                             tuple(w['configuration']['tape'])))
                meter.tick()
                layers.append({'step': (halfstep + 1) // 2,
                               'configurations': [w['configuration'] for w in witnesses],
                               'witnesses': witnesses})
        if type(machine['accept']) is not list:
            raise _Invalid('ACCEPT_SET')
        accepted = any(v['state'] in machine['accept'] for v in layers[-1]['configurations'])
        return {'schema': 'Root-independent-Wang-rows-v2', 'status': 'COMPLETE',
                'layers': layers, 'accepts': accepted,
                'counts': dict(meter.counts), 'reason': None,
                'scope': 'Finite row-enumeration control; not reference GCTS or FOL proof search.'}
    except _Invalid as error:
        return {'schema': 'Root-independent-Wang-rows-v2', 'status': 'REJECTED',
                'layers': None, 'accepts': None,
                'counts': None if meter is None else dict(meter.counts), 'reason': str(error)}
    except _Limit as error:
        return {'schema': 'Root-independent-Wang-rows-v2', 'status': 'UNKNOWN_BUDGET',
                'layers': None, 'accepts': None,
                'counts': None if meter is None else dict(meter.counts), 'reason': str(error)}
    except (RecursionError, MemoryError):
        return {'schema': 'Root-independent-Wang-rows-v2', 'status': 'UNKNOWN_BUDGET',
                'layers': None, 'accepts': None,
                'counts': None if meter is None else dict(meter.counts), 'reason': 'HOST_RESOURCE'}
