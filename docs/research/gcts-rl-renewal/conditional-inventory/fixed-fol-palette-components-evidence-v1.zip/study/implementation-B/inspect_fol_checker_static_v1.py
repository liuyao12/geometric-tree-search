from pathlib import Path
import ast,symtable,hashlib,json,builtins,sys
B=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B');p=B/'independent_fol_checker_v1.py';raw=p.read_bytes();source=raw.decode();tree=ast.parse(source,filename=str(p))
def sh(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sh(b)}
lines=source.splitlines(keepends=True);defs=[]
def visit(node,path):
 for child in ast.iter_child_nodes(node):
  if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
   name='.'.join(path+[child.name]);a=min([child.lineno]+[d.lineno for d in child.decorator_list]);body=''.join(lines[a-1:child.end_lineno]).encode();branches=[]
   for n in ast.walk(child):
    if isinstance(n,ast.If):branches.append({'kind':'if','line':n.lineno,'condition':ast.unparse(n.test)})
    elif isinstance(n,(ast.For,ast.While)):branches.append({'kind':type(n).__name__,'line':n.lineno,'condition_or_iterator':ast.unparse(n.test if isinstance(n,ast.While)else n.iter)})
    elif isinstance(n,ast.ExceptHandler):branches.append({'kind':'except','line':n.lineno,'exception':ast.unparse(n.type)if n.type else 'bare'})
   defs.append({'name':name,'kind':type(child).__name__,'line':a,'end_line':child.end_lineno,'signature':ast.unparse(child.args)if hasattr(child,'args')else None,'raw_bytes':len(body),'raw_sha256':sh(body),'AST_sha256':sh(ast.dump(child,include_attributes=False).encode()),'positioned_AST_sha256':sh(ast.dump(child,include_attributes=True).encode()),'complete_descendant_callset':sorted({ast.unparse(n.func)for n in ast.walk(child)if isinstance(n,ast.Call)}),'complete_descendant_branch_inventory':branches});visit(child,path+[child.name])
  else:visit(child,path)
visit(tree,[])
all_scopes=[]
def symbols(t,path='module'):
 entries=[]
 for name in sorted(t.get_identifiers()):
  s=t.lookup(name);entries.append({'name':name,'parameter':s.is_parameter(),'referenced':s.is_referenced(),'assigned':s.is_assigned(),'global':s.is_global(),'local':s.is_local(),'free':s.is_free(),'nonlocal':s.is_nonlocal(),'imported':s.is_imported()})
 all_scopes.append({'path':path,'type':t.get_type(),'line':t.get_lineno(),'complete_entries':entries,'entries_sha256':sh(enc(entries))})
 for i,c in enumerate(t.get_children()):symbols(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
symbols(symtable.symtable(source,str(p),'exec'))
imports=[ast.unparse(n)for n in ast.walk(tree)if isinstance(n,(ast.Import,ast.ImportFrom))];assert not imports
module_calls=[]
for n in tree.body:
 if not isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef)):module_calls.extend(ast.unparse(c.func)for c in ast.walk(n)if isinstance(c,ast.Call))
assert not module_calls
bindings={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}|{target.id for n in tree.body if isinstance(n,ast.Assign)for target in n.targets if isinstance(target,ast.Name)}
unresolved=[]
for st in all_scopes:
 for e in st['complete_entries']:
  if e['global']and e['referenced']and e['name']not in bindings and not hasattr(builtins,e['name']):unresolved.append([st['path'],e['name']])
assert not unresolved,unresolved
unused=compile(raw,str(p),'exec',dont_inherit=True,optimize=0);del unused
rulefields=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='_RULE_FIELDS');assert len(rulefields)==8
public=[n.name for n in tree.body if isinstance(n,ast.FunctionDef)and not n.name.startswith('_')];assert public==['check']
reasons=sorted({n.args[0].value for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id in['_Invalid','_Limit']and n.args and isinstance(n.args[0],ast.Constant)})
result={'schema':'B-independent-FOL-checker-complete-inert-static-branch-helper-ledger-v1','status':'PASS_STATIC_ONLY_NO_SUBJECT_CALLS','Source':pin(p),'complete_Source_lines':len(lines),'whole_AST_sha256':sh(ast.dump(tree,include_attributes=False).encode()),'whole_positioned_AST_sha256':sh(ast.dump(tree,include_attributes=True).encode()),'imports':imports,'module_body_calls':module_calls,'only_public_function':public,'definition_count':len(defs),'all_definitions':defs,'symbol_scope_count':len(all_scopes),'all_symbol_scopes':all_scopes,'unresolved_global_names':unresolved,'exact8rule_payloads':dict(rulefields),'own_invalidity_and_limit_reason_literals':reasons,'unusedcompile':'PASS; code object immediately discarded, never exec/imported','static_runtime':{'executable':sys.executable,'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'subject_function_constructor_or_module_execution':0,'fixtures_or_tests':0,'execution_authorized':False}
out=B/'independent-fol-checker-complete-static-branch-helper-ledger-v1.json';out.write_bytes(enc(result));print(json.dumps({'Source':pin(p),'static':pin(out),'definitions':len(defs),'scopes':len(all_scopes),'lines':len(lines),'reason_codes':reasons},sort_keys=True,indent=2))
