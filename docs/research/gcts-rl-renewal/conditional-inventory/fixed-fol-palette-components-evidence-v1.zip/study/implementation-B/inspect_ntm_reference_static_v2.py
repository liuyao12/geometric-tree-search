from pathlib import Path
import ast,hashlib,json,symtable,builtins,sys
B=Path('/private/tmp/gcts-fixed-fol-proof-palette-20261027-v1/implementation-B');p=B/'independent_ntm_reference_v2.py';raw=p.read_bytes();s=raw.decode();t=ast.parse(s,filename=str(p));ls=s.splitlines(keepends=True)
def sh(x):return hashlib.sha256(x).hexdigest()
def jb(x):return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sh(b)}
rows=[]
def scan(n,path):
 for c in ast.iter_child_nodes(n):
  if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
   key='.'.join(path+[c.name]);r=''.join(ls[c.lineno-1:c.end_lineno]).encode();branches=[]
   for x in ast.walk(c):
    if isinstance(x,ast.If):branches.append({'kind':'if','line':x.lineno,'condition':ast.unparse(x.test)})
    elif isinstance(x,(ast.For,ast.While)):branches.append({'kind':type(x).__name__,'line':x.lineno,'condition':ast.unparse(x.test if isinstance(x,ast.While)else x.iter)})
    elif isinstance(x,ast.ExceptHandler):branches.append({'kind':'except','line':x.lineno,'exception':ast.unparse(x.type)})
   rows.append({'name':key,'kind':type(c).__name__,'line':c.lineno,'end_line':c.end_lineno,'signature':ast.unparse(c.args)if hasattr(c,'args')else None,'raw_bytes':len(r),'raw_sha256':sh(r),'AST_sha256':sh(ast.dump(c,include_attributes=False).encode()),'positioned_AST_sha256':sh(ast.dump(c,include_attributes=True).encode()),'complete_descendant_callset':sorted({ast.unparse(x.func)for x in ast.walk(c)if isinstance(x,ast.Call)}),'complete_descendant_branches':branches});scan(c,path+[c.name])
  else:scan(c,path)
scan(t,[]);scope=[]
def sy(st,path='module'):
 es=[]
 for name in sorted(st.get_identifiers()):
  q=st.lookup(name);es.append({'name':name,'parameter':q.is_parameter(),'referenced':q.is_referenced(),'assigned':q.is_assigned(),'global':q.is_global(),'local':q.is_local(),'free':q.is_free(),'nonlocal':q.is_nonlocal(),'imported':q.is_imported()})
 scope.append({'path':path,'type':st.get_type(),'line':st.get_lineno(),'complete_entries':es,'entries_sha256':sh(jb(es))})
 for i,c in enumerate(st.get_children()):sy(c,path+'/'+c.get_name()+':'+str(c.get_lineno())+':'+str(i))
sy(symtable.symtable(s,str(p),'exec'))
imports=[ast.unparse(x)for x in ast.walk(t)if isinstance(x,(ast.Import,ast.ImportFrom))];assert imports==[]
modulecalls=[]
for n in t.body:
 if not isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):modulecalls.extend(ast.unparse(x.func)for x in ast.walk(n)if isinstance(x,ast.Call))
assert not modulecalls
bindings={n.name for n in t.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}|{q.id for n in t.body if isinstance(n,ast.Assign)for q in n.targets if isinstance(q,ast.Name)}
unresolved=[[st['path'],x['name']]for st in scope for x in st['complete_entries']if x['global']and x['referenced']and x['name']not in bindings and not hasattr(builtins,x['name'])];assert not unresolved
code=compile(raw,str(p),'exec',dont_inherit=True,optimize=0);del code
public=[n.name for n in t.body if isinstance(n,ast.FunctionDef)and not n.name.startswith('_')];assert public==['simulate']
reasons=sorted({x.args[0].value for x in ast.walk(t)if isinstance(x,ast.Call)and isinstance(x.func,ast.Name)and x.func.id in['_Invalid','_Limit']and x.args and isinstance(x.args[0],ast.Constant)})
x={'schema':'B-independent-finite-NTM-complete-Source-static-branch-helper-ledger-v2','status':'PASS_STATIC_ONLY_NO_SUBJECT_CALLS','Source':pin(p),'lines':len(ls),'whole_AST_sha256':sh(ast.dump(t,include_attributes=False).encode()),'whole_positioned_AST_sha256':sh(ast.dump(t,include_attributes=True).encode()),'definition_count':len(rows),'all_definitions':rows,'symbol_scope_count':len(scope),'all_symbol_scopes':scope,'imports':imports,'module_body_calls':modulecalls,'unresolved_global_names':unresolved,'only_public_function':public,'reason_literals':reasons,'unusedcompile':'PASS, code object discarded never executed','runtime':{'executable':sys.executable,'version':sys.version,'isolated':sys.flags.isolated,'no_site':sys.flags.no_site,'dont_write_bytecode':sys.dont_write_bytecode},'L_compiler_implementation_read':'B1beforeLbody;B2narrowpublicMachine5repairafterassignedLSourcepeer,noLhelperimports/calls','subject_calls':0,'tests_fixtures_model_calls':0,'execution_authorized':False}
out=B/'independent-NTM-reference-complete-static-branch-helper-ledger-v2.json';out.write_bytes(jb(x));print(json.dumps({'Source':pin(p),'static':pin(out),'definitions':len(rows),'scopes':len(scope),'lines':len(ls),'names':[r['name']for r in rows]},sort_keys=True,indent=2))
