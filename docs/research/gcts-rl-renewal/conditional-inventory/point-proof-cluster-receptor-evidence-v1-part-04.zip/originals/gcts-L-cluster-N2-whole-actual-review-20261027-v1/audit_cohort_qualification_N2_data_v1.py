"""Remaining whole-cohort standard JSON/hash associations; no subject import or numerical proof replay."""
from pathlib import Path
import collections,hashlib,json,math
R=Path('/private/tmp/gcts-cluster-receptors-20261027-v2');A=R/'actual-v1';OUT=Path(__file__).parent

def enc(x):return (json.dumps(x,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(enc(x)).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def need(x,m):
 if not x:raise AssertionError(m)
def load(n):return json.loads((A/n).read_bytes())
s=json.loads((OUT/'cluster-N2-complete-raw-and-112-stream-audit-v1.json').read_bytes());arms=s['compact_for_remaining_paired_data_joins'];arows={r['name']:r for r in s['arms']};idx=load('whole-study-index.json');names=[Path(r['path']).name for r in s['all183_originals']];rank={n:i for i,n in enumerate(names)}

def paircheck(p,c,comparison):
 need(p['model_sha256']==c['model_sha256'] and p['context']==c['context'],'same model/context pair')
 pd=[x for x in p['trace']if x['kind']=='DECISION'];cd=[x for x in c['trace']if x['kind']=='DECISION'];m=min(len(pd),len(cd));key=lambda x:{k:x[k]for k in ['kind','data','domains_sha256','state_sha256']}
 need([key(x)for x in pd[:m]]==[key(x)for x in cd[:m]],'whole completed common decision prefix')
 interrupted=p['window']['triggered']or c['window']['triggered']
 expected={'mode':'DECISION_PREFIX_ONLY'if interrupted else'COMPLETE_SEMANTIC_TRACE','point_decisions':len(pd),'csp_decisions':len(cd),'common_decisions':m,'overlap_vacuous':m==0,'all_common_decisions_equal':True,'full_trace_status_nodes_and_common_metrics_asserted':not interrupted,'point_window_triggered':p['window']['triggered'],'csp_window_triggered':c['window']['triggered']}
 need({k:comparison[k]for k in expected}==expected,'recorded comparison association')
 if not interrupted:
  need(p['trace']==c['trace'] and p['status']==c['status'] and p['nodes']==c['nodes'] and dict(p['metrics'],nodes=p['nodes'])==c['metrics'],'complete matching semantic trace/status/nodes/metrics')
 return expected
initial=load('initial-policy.json');trained=load('frozen-trained-policy.json');policy=initial;need(initial['weights']==[0.0]*12 and initial['baseline']==0.0 and initial['updates']==0 and initial['max_members']==4,'fresh zero policy')
train=[];expected_training=[];pair_modes=collections.Counter();feedback_counts=collections.Counter()
for e in range(32):
 repeat=e//8;word=['000','011','101','110'][(e%8)//2];negative=bool(e%2);order=['POINT','CSP']if e%2==0 else['CSP','POINT']
 for kind in order:expected_training.append({'episode':e,'repeat':repeat,'word':word,'negative':negative,'engine':kind,'record':arms['train-'+str(e)+'-'+kind+'.json']['record']})
 p=arms['train-'+str(e)+'-POINT.json'];c=arms['train-'+str(e)+'-CSP.json'];pcname='training-pair-check-'+str(e)+'.json';un='training-update-'+str(e)+'.json';pc=load(pcname);u=load(un)
 need(pc['point']==p['record'] and pc['csp']==c['record'] and pc['point_check']==p['result_check'] and pc['csp_certificate_check']==c['result_check'] and pc['model_sha256']==p['model_sha256'] and pc['context']==p['context'],'full saved pair check binding')
 comparison=paircheck(p,c,pc['comparison']);pair_modes[comparison['mode']]+=1
 need(rank[Path(p['record']['path']).name]<rank[pcname]<rank[un] and rank[Path(c['record']['path']).name]<rank[pcname],'both arms then paircheck then update')
 for a in (p,c):
  need(a['strategy']=='TRAINED_CLUSTER' and a['seed']==41001+131*e and a['input']['initial']==list('#'+word+'#') and a['input']['width']==5 and a['input']['steps']==2 and a['input']['negative_final']is negative and a['marking_version']=='ORIGINAL_WANG','exact training descriptor/seed/order')
  need(a['policy_sha256']==sha(policy),'paired frozen policy')
 need(u['episode']==e and u['before_policy']==policy and u['point']==p['record'] and u['csp']==c['record'] and u['paired_check']==pin(A/pcname) and u['comparison']==pc['comparison'],'update current pair+policy')
 assoc={'schema':'GCTS-cluster-training-feedback-association-v1','point':p['record'],'csp':c['record'],'model_sha256':p['model_sha256'],'context':p['context'],'point_check':p['result_check'],'csp_certificate_check':c['result_check'],'paired_comparison_rawref':pin(A/pcname),'raw_statuses':[p['status'],c['status']]}
 need(u['verification_association']==assoc,'feedback full data/ref association')
 decisive=p['status']==c['status']and p['status']in('FINITE_EXACT_SOLUTION','EXHAUSTED_FINITE_SEARCH');status=('SAT'if p['status']=='FINITE_EXACT_SOLUTION'else'UNSAT')if decisive else'UNKNOWN'
 fb={'status':status,'verified_terminal':decisive,'verification_sha256':sha(assoc),'required_points':p['required'],'max_verified_filled':p['maxfilled'],'attempts':p['metrics']['attempts'],'branches':p['metrics']['branch_decisions'],'backtracks':p['metrics']['backtracks'],'actor_candidate_visits':p['actor_candidate_visits'],'certificate_kind':status if decisive else'INCOMPLETE'}
 update=u['update'];need(update['feedback']==fb and update['before_policy_sha256']==sha(policy) and update['evidence_sha256']==p['actor_final_sha256'],'POINT-only trajectory feedback/status origin')
 if decisive:need(c['result_check']['certificate_kind']==status,'decisive independently checked CSP certificate')
 check=u['independent_update_check'];need(check['status']=='VERIFIED_BOUND_ACTOR_UPDATE'and check['model_sha256']==p['model_sha256']and check['policy_sha256']==sha(policy)and check['snapshot_sha256']==p['actor_final_sha256']and check['feedback_sha256']==sha(fb)and check['update_sha256']==sha(update),'full independent update binding')
 after=update['after_policy'];need(after['updates']==e+1 and set(after)==set(policy) and all(after[k]==policy[k]for k in policy if k not in('weights','baseline','updates')),'whole afterpolicy shape/frozen config')
 need(all(type(v)is float and math.isfinite(v)and abs(v)<=4 for v in after['weights'])and type(after['baseline'])is float and math.isfinite(after['baseline']),'finite bounded policy values')
 feedback_counts[status]+=1;train.append({'episode':e,'word':word,'negative':negative,'engine_order':order,'point':p['record'],'csp':c['record'],'comparison':comparison,'pair_check':pin(A/pcname),'update':pin(A/un),'before_policy_sha256':sha(policy),'after_policy_sha256':sha(after),'feedback_status':status,'raw_statuses':[p['status'],c['status']],'POINT_snapshot_sha256':p['actor_final_sha256'],'independent_update_check_sha256':sha(check),'both_saved_before_paircheck_update':True});policy=after
need(idx['training']==expected_training and policy==trained and sha(trained)==load('result.json')['outcome']['final_policy_sha256'],'complete ordered training chain/frozen final')
need(idx['training_pair_checks']==[pin(A/('training-pair-check-'+str(e)+'.json'))for e in range(32)] and idx['updates']==[pin(A/('training-update-'+str(e)+'.json'))for e in range(32)],'32durable indexes')
evals=[];expected_eval=[];pair_index=0;eval_modes=collections.Counter()
for context,(width,steps,word,negative) in enumerate([(5,2,'001',False),(5,2,'001',True),(9,6,'0010111',False),(9,6,'0010111',True)]):
 for use_mark in (False,True):
  strategies=['LEX_NO_CLUSTER','TRAINED_CLUSTER']if use_mark else['LEX_NO_CLUSTER','UNTRAINED_CLUSTER','TRAINED_FIRST_ONLY','TRAINED_CLUSTER']
  if negative:strategies=list(reversed(strategies))
  for strategy in strategies:
   records={}
   for kind in (['CSP','POINT']if negative else['POINT','CSP']):
    n='eval-'+str(context)+'-'+('MAP20-'if use_mark else'WANG-')+strategy+'-'+kind+'.json';a=arms[n];records[kind]=a;expected_eval.append({'context':context,'reused_marking':use_mark,'strategy':strategy,'engine':kind,'record':a['record']})
    need(a['input']['width']==width and a['input']['steps']==steps and a['input']['initial']==list('#'+word+'#')and a['input']['negative_final']is negative and a['strategy']==strategy and a['seed']==71001+context,'exact eval descriptor')
    if strategy!='LEX_NO_CLUSTER':need(a['policy_sha256']==sha(initial if strategy=='UNTRAINED_CLUSTER'else trained),'frozen eval policy')
    else:need(a['policy_sha256']is None,'no proposer lexical')
    need(a['window']['limit_seconds']==(5 if width==5 else 10)and a['required']==(20 if width==5 else 72),'original evalcaps')
   row=idx['evaluation_pairs'][pair_index];pair_index+=1;need(row['context']==context and row['reused_marking']is use_mark and row['strategy']==strategy and row['point']==records['POINT']['record'] and row['csp']==records['CSP']['record'],'full eval pair reference')
   comparison=paircheck(records['POINT'],records['CSP'],row['comparison']);eval_modes[comparison['mode']]+=1;evals.append({'context':context,'width':width,'steps':steps,'negative':negative,'reused_marking':use_mark,'strategy':strategy,'point':records['POINT']['record'],'csp':records['CSP']['record'],'point_status':records['POINT']['status'],'csp_status':records['CSP']['status'],'point_nodes':records['POINT']['nodes'],'csp_nodes':records['CSP']['nodes'],'comparison':comparison})
need(idx['evaluation']==expected_eval and len(evals)==24,'all48 eval complete order');need(idx['frozen_trained_policy']==pin(A/'frozen-trained-policy.json')and idx['initial_policy']==pin(A/'initial-policy.json'),'policy indexrefs')
# Full retained qualification bodies are data, not reexecuted numerical checkers.
legacy=load('legacy-qualification.json');cq=load('cluster-qualification.json');need(legacy['status']=='VERIFIED'and cq['status']=='PASS','both completed qualification reports')
need(legacy['counts']=={'B_negative_controls':32,'C_controls':20,'normal_solve_calls':22,'paired_controls':13,'paired_records':26},'legacy exact actualcensus');need(len(legacy['paired_controls'])==26 and len(legacy['B_negative_controls'])==32 and len(legacy['C_controls'])==20,'all legacy records')
qual=[];qual_event_rows=0
for r in legacy['paired_controls']:
 for e,row in enumerate(r['events']):need(row['seq']==e and row['state_sha256']==sha(row['snapshot'])and row['domains_sha256']==sha(row['snapshot']['eligible_domains']),'legacy full normalized event/hash')
 qual_event_rows+=len(r['events']);qual.append({'qualification':'LEGACY','id':r['id'],'mode':r['mode'],'record_sha256':sha(r),'full_event_rows':len(r['events']),'model_sha256':sha(r['model']),'status':None if r['result']is None else r['result']['status']})
for i in range(13):
 p,c=legacy['paired_controls'][2*i:2*i+2];need(p['id']==c['id']=='Q'+str(i+1).zfill(2)and p['model']==c['model'],'13complete legacy paired models')
c20=legacy['C_controls'][-1];need(c20['id']=='C20_SAFE_ACCEPTED_MERGE'and len(c20['result']['marking']['channels'])==1 and c20['result']['metrics']['accepted_merges']==1,'C20 acceptedmerge retained')
need(len(cq['controls'])==61 and all(c['status']=='PASS'for c in cq['controls'])and cq['coverage']['paired_kernel_recipes']==39,'all61 controls39paired')
for ci,c in enumerate(cq['controls']):
 rr=[]
 if ci<39:need(len(c['roles'])==2,'all39 paired roles')
 for r in c.get('roles',[]):
  mh=sha(r['model'])if'model'in r else None
  for event in r.get('events',[]):
   if not all(k in event for k in ['event','independent','state']):continue
   v=event['independent'];need(v['status']=='VERIFIED'and v['model_sha256']==mh,'Cqualification full live event model')
   state=v['normalized_state'];need(v['state_sha256']==sha(state)and v['domains_sha256']==sha(state['eligible_domains']),'Cqualification whole normalizedevent SHA')
   need(v.get('snapshot_sha256',v['state_sha256'])==sha(event['state']),'Cqualification full carrier SHA')
   qual_event_rows+=1
  rollback=r.get('rollback')
  if isinstance(rollback,dict)and'independent'in rollback:
   need(rollback['independent']['status']=='VERIFIED'and rollback['state']==r['entry'],'Cqualification full rollback')
  if isinstance(r.get('result_check'),dict):need(r['result_check']['status']=='VERIFIED'and r['result_check']['model_sha256']==mh,'Cqualification resultcheck association')
  rr.append({'role':r.get('role'),'action':r.get('action','SPECIAL'),'model_sha256':mh,'events':len(r.get('events',[])),'record_sha256':sha(r),'status':None if r.get('result')is None else r['result']['status']})
 if ci<39:need(c['roles'][0]['model']==c['roles'][1]['model'],'39same input modelpairs')
 for x in c.get('cases',[]):
  if 'rejected'in x:need(x['rejected']is True,'storednegative correctlyrefused')
 if 'update'in c and'independent'in c:
  v=c['independent']
  if isinstance(v,dict)and v.get('status')=='VERIFIED_BOUND_ACTOR_UPDATE':need(v['update_sha256']==sha(c['update'])and v['feedback_sha256']==sha(c['feedback']),'qualification actor update body hash')
 qual.append({'qualification':'CLUSTER','id':c['id'],'record_sha256':sha(c),'status':c['status'],'roles':rr,'negative_cases':[{'id':x.get('id'),'record_sha256':sha(x),'rejected':x.get('rejected')}for x in c.get('cases',[])]})
need(cq['coverage']['actual_call_counters']['solve_calls']==26,'actualC26solvesSourcebound')
mark=load('reused-marking-control.json');contract=json.loads(Path(json.loads((A/'custody-terminal.json').read_bytes())['plan']['path']).read_bytes());fc=json.loads(Path(contract['source_contract']['path']).read_bytes());need(mark['rawrefs']==fc['inputs'],'all5 rawinput associations')
need(mark['production_audit']['wellformed']is True and mark['independent_contacts']['status']=='VERIFIED' and mark['independent_audit']['status']=='VERIFIED','reused20 complete actual audit')
# Retained standard-data outputs only; no numerical reinforcement or proof-tree algorithm replay.
final=dict(s);final.pop('compact_for_remaining_paired_data_joins');final['schema']='L-cluster-N2-complete-independent-whole-actual-structural-support-v1';final['status']='COMPLETE_WHOLE_SOURCE_AND_ACTUAL_DATA_JOINS_PASS';final['training_policy_chain']=train;final['evaluation_pairs']=evals;final['qualifications']=qual;final['actual_qualification_call_counters']={'legacy':legacy['counts'],'cluster':cq['coverage']['actual_call_counters']};final['qualification_full_event_rows_hash_joined']=qual_event_rows;final['training_feedback_counts']=dict(feedback_counts);final['training_pair_modes']=dict(pair_modes);final['evaluation_pair_modes']=dict(eval_modes);final['initial_policy']=pin(A/'initial-policy.json');final['trained_policy']=pin(A/'frozen-trained-policy.json');final['qualification_pins']=[pin(A/'legacy-qualification.json'),pin(A/'cluster-qualification.json')];final['all_decoded_totals']={'outer_original_bytes':sum(x['decoded_outer']['raw_bytes']for x in s['arms']),'inner_original_bytes':sum(x['decoded_inner']['raw_bytes']for x in s['arms']),'inner_rows':sum(x['decoded_inner']['record_count']for x in s['arms']),'row_kinds':dict(sum((collections.Counter(x['row_kinds'])for x in s['arms']),collections.Counter()))};final['full_cohort_status_counts']={engine:dict(collections.Counter(x['status']for x in s['arms']if x['engine']==engine))for engine in ['POINT','CSP']};final['administrative_review_history']=['An initial admin script syntax error prevented execution and was corrected.','Root capture metadata is pretty JSON; compact-canonical requirement applies producer artifact bodies, not Root administrative metadata.','C prepared-model metadata intentionally has raw_model_sha256=null; L prepared model has actual raw SHA. Observation excluded IDs correspond normalized excluded ID/reason rows. No artifact or Source changed; no subject called.'];final['evidence_limits']=['Scientific Source peers plus actual complete input/output/hash/controlpath data establish this finite admission recommendation; project verifier/solver/gradient algorithms were not replayed.','Main transient native snapshot arguments remain hashes; complete normalized9 verifier returns/event rows retained. Qualification retains full promised raw histories.','CSP certificate receipts establish full finite UNSAT under exact same context; POINT negative envelope alone is not a proof. UNKNOWN not promoted.','Heuristic actor floating updates independently checked at runtime; pending-origin bindings do not claim full FIFO replay or causal use of every member. No measured causal utility/statistical/generalization/theorem claim from this structural audit.','All cost sites/tails as named; no fabricated RSS sum, hard2/5/10 bounds, whole exact memory or unmeasured tail closure.','N1 remains separately unadmitted/spent. N2 consumed once now spent; no rerun or pooling.']
p=OUT/'cluster-N2-complete-independent-whole-actual-support-v1.json';p.write_bytes((json.dumps(final,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n').encode());print(json.dumps({'support':pin(p),'feedback':dict(feedback_counts),'eval_modes':dict(eval_modes),'qualification_event_rows':qual_event_rows,'subject_calls':0},indent=2))
