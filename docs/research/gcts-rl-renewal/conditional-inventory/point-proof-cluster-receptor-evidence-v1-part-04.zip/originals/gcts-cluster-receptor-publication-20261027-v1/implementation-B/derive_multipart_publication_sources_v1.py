from pathlib import Path
import ast,json,hashlib
B=Path('/private/tmp/gcts-cluster-receptor-publication-20261027-v1/implementation-B')
names=['point-proof-parallel-progress-v1.html','point-proof-cluster-receptor-summary-v1.json','point-proof-cluster-receptor-evidence-v1.zip']+['point-proof-cluster-receptor-evidence-v1-part-'+str(i).zfill(2)+'.zip'for i in range(2,9)]
replacements={
'publisher':[
('P2-only three-path Git Data API publication.','P2-only ten-path Git Data API multipart publication.'),
('/publisher-payload','/publisher-multipart-payload'),
('"publication-cluster-receptor-v1"','"publication-cluster-receptor-multipart-v1"'),
('"publication-cluster-receptor-api-v1"','"publication-cluster-receptor-multipart-api-v1"'),
('implementation-B/publish_cluster_receptor_api_v1.py','implementation-B/publish_cluster_receptor_multipart_api_v1.py'),
('Root-cluster-receptor-P2-publication-once-authority-v1','Root-cluster-receptor-multipart-P2-publication-once-authority-v1'),
('Root-cluster-receptor-publication-three-path-staging-v1','Root-cluster-receptor-multipart-publication-ten-path-staging-v1'),
('len(files) == 3','len(files) == 10'),
('reviewed preparer three files required','reviewed preparer ten files required'),
('P2 exact three-file payload census','P2 exact ten-file payload census'),
('fixed three payload rows','fixed ten payload rows'),
('Root-cluster-receptor-P2-publication-consumed-v1','Root-cluster-receptor-multipart-P2-publication-consumed-v1'),
('all three target leaves exact','all ten target leaves exact'),
('Publish cluster-receptor outcomes and complete evidence','Publish cluster-receptor outcomes and complete multipart evidence'),
('Root-cluster-receptor-P2-publication-terminal-v1','Root-cluster-receptor-multipart-P2-publication-terminal-v1'),
('EXACT_THREE_PATHS_COMMITTED_LIVE_CHECK_PENDING','EXACT_TEN_PATHS_COMMITTED_LIVE_CHECK_PENDING')],
'verifier':[
('exact three published files.','exact ten published files.'),
('publication-cluster-receptor-api-v1/terminal.json','publication-cluster-receptor-multipart-api-v1/terminal.json'),
('"cluster-receptor-live-TLS-verification-v1"','"cluster-receptor-multipart-live-TLS-verification-v1"'),
('implementation-B/verify_cluster_receptor_live_v1.py','implementation-B/verify_cluster_receptor_multipart_live_v1.py'),
('Root-cluster-receptor-P2-publication-terminal-v1','Root-cluster-receptor-multipart-P2-publication-terminal-v1'),
('EXACT_THREE_PATHS_COMMITTED_LIVE_CHECK_PENDING','EXACT_TEN_PATHS_COMMITTED_LIVE_CHECK_PENDING'),
('len(p["files"]) == 3','len(p["files"]) == 10'),
('exact three targets','exact ten targets'),
('Root-cluster-receptor-complete-live-TLS-bodies-v1','Root-cluster-receptor-multipart-complete-live-TLS-bodies-v1'),
('ALL_THREE_COMPLETE_LIVE_BODIES_MATCH','ALL_TEN_COMPLETE_LIVE_BODIES_MATCH')]
}
records=[]
for role,oldname,newname,expected in [('publisher','publish_cluster_receptor_api_v1.py','publish_cluster_receptor_multipart_api_v1.py',(14024,'f2eb8c2b4f9550451cb893f338704828a5ff3029e1e63519e2ff85c185dee432')),('verifier','verify_cluster_receptor_live_v1.py','verify_cluster_receptor_multipart_live_v1.py',(6416,'f93496411cdabee4d13cf31cddf377e83e2f5cc35eda6609dfc69a40a00adcc3'))]:
 p=B/oldname;q=B/newname;raw=p.read_bytes();assert (len(raw),hashlib.sha256(raw).hexdigest())==expected
 text=raw.decode();oldtree=ast.parse(text);n=next(n for n in oldtree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='NAMES')
 ls=text.splitlines(keepends=True);oldtuple=''.join(ls[n.lineno-1:n.end_lineno]);newtuple='NAMES = ('+',\n         '.join(json.dumps(x)for x in names)+')\n'
 assert text.count(oldtuple)==1;text=text.replace(oldtuple,newtuple,1)
 rows=[{'class':'NAMES tuple expansion','old':oldtuple,'new':newtuple,'occurrences':1}]
 for old,new in replacements[role]:
  count=text.count(old);assert count>0,(role,old);text=text.replace(old,new);rows.append({'class':old,'old':old,'new':new,'occurrences':count})
 assert not q.exists();q.write_text(text)
 records.append({'role':role,'old_Source':{'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'new_Source':{'path':str(q),'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()},'complete_ordered_replacement_classes':rows})
out=B/'cluster-receptor-multipart-complete-mechanical-replacement-census-v1.json';out.write_text(json.dumps({'schema':'Root-cluster-receptor-multipart-mechanical-replacement-census-v1','roles':records,'total_classes':sum(len(r['complete_ordered_replacement_classes'])for r in records),'total_occurrences':sum(x['occurrences']for r in records for x in r['complete_ordered_replacement_classes']),'subject_calls':0},sort_keys=True,indent=2,allow_nan=False)+'\n')
print(json.dumps({'Sources':[r['new_Source']for r in records],'census':{'path':str(out),'bytes':len(out.read_bytes()),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}},sort_keys=True,indent=2))
