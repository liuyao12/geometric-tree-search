"""Single supervised subject invocation; no implicit retries."""
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PYTHON = '/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'
SUBJECT = ROOT / 'source/run_study_v2.py'


def sha(path):
    b = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def main():
    destination = ROOT / 'attempt-v2/observation'
    destination.mkdir(exist_ok=True)
    record = {'schema': 'FP-native-observer-v1', 'runtime': sha(PYTHON), 'subject': sha(SUBJECT),
              'argv': [PYTHON, '-I', '-S', '-B', str(SUBJECT), 'study'], 'wall_limit_seconds': 180,
              'retry': False, 'start_unix': time.time()}
    (destination/'before-v1.json').write_text(json.dumps(record, indent=2)+'\n')
    start = time.perf_counter()
    with (destination/'stdout-v1.txt').open('xb') as out, (destination/'stderr-v1.txt').open('xb') as err:
        process = subprocess.Popen(record['argv'], cwd=ROOT, stdout=out, stderr=err)
        print(json.dumps({'subject_pid': process.pid, 'observer': 'RUNNING'}), flush=True)
        while process.poll() is None and time.perf_counter()-start < 180:
            time.sleep(.1)
        record['terminated_on_wall_limit'] = process.poll() is None
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait()
        record.update({'native_exit': process.returncode, 'elapsed_seconds': time.perf_counter()-start,
                       'peak_child_rss': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                       'rss_platform': sys.platform, 'subject_after': sha(SUBJECT), 'runtime_after': sha(PYTHON),
                       'stdout': sha(destination/'stdout-v1.txt'), 'stderr': sha(destination/'stderr-v1.txt')})
    (destination/'completion-v1.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'native_exit': record['native_exit'], 'elapsed_seconds': record['elapsed_seconds'],
                      'peak_child_rss': record['peak_child_rss']}), flush=True)
    raise SystemExit(process.returncode or 0)


if __name__ == '__main__':
    main()
