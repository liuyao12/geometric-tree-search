"""Prepare exactly four public assets in isolated Git; no network or push."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
GIT = '/private/tmp/gcts-history-publication-20261102-v1.git'
PREFIX = 'docs/research/gcts-rl-renewal/conditional-inventory/'


def main():
    base = sys.argv[1]
    assert re.fullmatch('[0-9a-f]{40}', base)
    directory = ROOT/'publication'; directory.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update({'GIT_INDEX_FILE':str(directory/'index-v1'), 'GIT_NO_LAZY_FETCH':'1',
                'GIT_AUTHOR_NAME':'Codex', 'GIT_AUTHOR_EMAIL':'codex@openai.com',
                'GIT_COMMITTER_NAME':'Codex', 'GIT_COMMITTER_EMAIL':'codex@openai.com'})
    def git(*args, data=None):
        return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','gc.auto=0','--git-dir='+GIT,*args], input=data, env=env).decode().strip()
    assert git('remote','get-url','origin') == 'https://github.com/liuyao12/geometric-tree-search.git'
    old_path = PREFIX+'cluster-policy-proof-search-v1.html'
    old = subprocess.check_output(['git','--git-dir='+GIT,'show',base+':'+old_path])
    assert hashlib.sha256(old).hexdigest() == '90e594a5df68ddb7fb845541f61c5e1c8afd5118313655b4c4b1d5fb6d66b5be', 'Previous reader changed; reconcile before publishing.'
    candidates = [('report/fixed-palette-proof-backend-v1.html','fixed-palette-proof-backend-v1.html'),
                  ('report/fixed-palette-results-v1.json','fixed-palette-results-v1.json'),
                  ('package/fixed-palette-evidence-v1.zip','fixed-palette-evidence-v1.zip'),
                  ('report/cluster-policy-proof-search-v1.html','cluster-policy-proof-search-v1.html')]
    for _, name in candidates[:3]:
        missing = subprocess.run(['git','--git-dir='+GIT,'cat-file','-e',base+':'+PREFIX+name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
        assert missing.returncode != 0, 'New output already exists; do not overwrite.'
    git('read-tree',base)
    assets = []
    for relative, name in candidates:
        path = ROOT/relative; blob = git('hash-object','-w',str(path)); destination=PREFIX+name
        git('update-index','--add','--cacheinfo','100644',blob,destination)
        b = path.read_bytes()
        assets.append({'local':relative,'path':destination,'git_blob':blob,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
                       'url':'https://liuyao12.github.io/geometric-tree-search/'+destination})
    tree = git('write-tree','--missing-ok')
    commit = git('commit-tree',tree,'-p',base,'-m','Publish fixed Wang palette backend and checked arithmetic/incidence witnesses')
    raw = git('diff-tree','--no-commit-id','--no-renames','--raw','-r',base,commit)
    assert {line.split('\t')[1] for line in raw.splitlines()} == {a['path'] for a in assets}
    assert sum(line.split('\t')[0].endswith(' A') for line in raw.splitlines()) == 3
    assert sum(line.split('\t')[0].endswith(' M') for line in raw.splitlines()) == 1
    record = {'status':'PREPARED_EXACT_FOUR_ASSETS','base':base,'tree':tree,'commit':commit,'assets':assets,
              'raw_diff':raw,'primary_checkout_staged':False,'push':'NOT_YET_PERFORMED'}
    (directory/'prepared-v1.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'base':base,'commit':commit,'assets':len(assets)}))


if __name__ == '__main__':
    main()
