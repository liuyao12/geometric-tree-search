"""Check saved model-specific generations only; execute no scientific Source."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def pin(path, data=None):
    data = path.read_bytes() if data is None else data
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def site(cid):
    value = json.loads(cid)
    require(type(value) is list and len(value) == 2 and type(value[0]) is str
            and all(c in '01' for c in value[0]) and type(value[1]) is int
            and value[1] >= 0, 'Malformed anchored logical CID')
    return value[0]


def inspect(path):
    body = path.read_bytes()
    result = dict(source=pin(path, body), status='UNKNOWN', errors=[],
                  placed_events=0, selected_tuples=0, Q_tuples=0)
    try:
        saved = json.loads(gzip.decompress(body))
        model, answer = saved['model'], saved['result']
        result['search_status'] = answer['status']
        result['search_reason'] = answer['reason']
        tiny = path.name.startswith('tiny-wang-')
        require(model['version'] == ('FP-finite-Wang-point-model-v1' if tiny
                                    else 'FP-finite-proof-tree-v1'), 'Unexpected model kind')
        result['kind'] = 'all-root tiny Wang' if tiny else 'anchored logical tree'
        ids = {row['id'] for row in model['inventory']['placements']}
        events, extent = answer['events'], answer['event_extent']
        require(len(events) == extent['retained'], 'Retained event count differs')
        result['event_extent'] = {k: extent[k] for k in ('retained', 'total', 'sha256')}
        result['all_emitted_events_retained'] = extent['retained'] == extent['total']
        for event in events:
            if event['kind'] != 'PLACED':
                continue
            cid, actual = event['candidate'], event['data']['generation']
            require(cid in ids, 'PLACED CID absent from the declared inventory')
            expected = 1 if tiny else len(site(cid)) + 1
            require(type(actual) is int and actual == expected,
                    'PLACED generation differs at sequence %r: %r != %r'
                    % (event.get('seq'), actual, expected))
            result['placed_events'] += 1
        final = answer.get('final_state')
        result['final_state_present'] = final is not None
        if final is not None:
            selected = final['selected']
            require(len(selected) == len({cid for cid, _ in selected}), 'Duplicate final selected CID')
            for cid, actual in selected:
                require(cid in ids, 'Final selected CID absent from inventory')
                expected = 1 if tiny else len(site(cid)) + 1
                require(type(actual) is int and actual == expected,
                        'Final selected generation differs: %r' % cid)
                result['selected_tuples'] += 1
            q = final['Q']
            require(len(q) == len({p for p, _ in q}), 'Duplicate final Q point')
            if tiny:
                require({p for p, _ in q} == set(model['roots']), 'Tiny Q differs from all declared roots')
            for point, actual in q:
                require(type(point) is str, 'Non-string Q point')
                if not tiny:
                    require(all(c in '01' for c in point), 'Malformed logical Q site')
                expected = 0 if tiny else len(point)
                require(type(actual) is int and actual == expected,
                        'Final Q generation differs: %r' % point)
                result['Q_tuples'] += 1
        result['status'] = ('PASS_COMPLETE_SAVED_GENERATIONS'
                            if result['all_emitted_events_retained'] and final is not None
                            else 'UNKNOWN_INCOMPLETE_SAVED_EVENT_OR_STATE_COVERAGE')
    except Exception as error:
        result['status'] = 'FAIL_SAVED_GENERATION_CHECK'
        result['errors'].append(dict(type=type(error).__name__, message=str(error)))
    return result


def main():
    paths = sorted((ROOT / 'attempt-v2/actual').glob('*-search.json.gz'))
    checks = [inspect(path) for path in paths]
    failures = [c for c in checks if c['status'].startswith('FAIL')]
    unknown = [c for c in checks if c['status'].startswith('UNKNOWN')]
    status = ('FAIL_SAVED_GENERATION_CHECK' if failures else
              'UNKNOWN_INCOMPLETE_SAVED_COVERAGE' if unknown or not checks else
              'PASS_COMPLETE_SAVED_GENERATIONS')
    receipt = dict(schema='FP-passive-saved-generation-audit-v1', status=status,
                   reviewer_source=pin(Path(__file__)), files=len(checks), checks=checks,
                   totals={k: sum(c[k] for c in checks)
                           for k in ('placed_events', 'selected_tuples', 'Q_tuples')},
                   failure_count=len(failures), unknown_count=len(unknown),
                   scope='Only standard-library reads of saved attempt-v2 *-search.json.gz. Checks every retained PLACED generation and final_state selected/Q generation using the declared anchored-tree/all-root model structure. Complete coverage requires all emitted events retained and a final snapshot. Search statuses and errors remain explicit; a search UNKNOWN is never converted to UNSAT. No search, circuit evaluator, logical kernel, independent checker or scientific Source executes. No scientific output changes.')
    output = ROOT / 'review/passive-generation-audit-v1.json'
    with output.open('x') as stream:
        json.dump(receipt, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(pin(output), sort_keys=True))
    print(json.dumps({key: receipt[key] for key in ('status', 'files', 'totals', 'failure_count', 'unknown_count')}, sort_keys=True))


if __name__ == '__main__':
    main()
