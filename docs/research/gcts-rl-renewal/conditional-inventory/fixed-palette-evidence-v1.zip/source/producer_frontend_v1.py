"""Generic exact-length producer-DAG acceptance circuit, compiled to NAND.

No proof witnesses are generated or searched. The producer universe is frozen
before the unknown proof-bit inputs exist. Rule semantics are external trust:
ZERO schemas need native kernel admission, MP producer tuples need semantic
admission, and GEN is permitted only under a closed assumption context Gamma.
The direct checker is procedural and never uses Builder or circuit evaluation.
"""
import hashlib
import json
from fixed_palette_v1 import Builder

VERSION = 'FP-PRODUCER-DAG-FRONTEND-v1'
MAX_PRODUCERS, MAX_LINES, MAX_FORMULA_ID, MAX_NAND_GATES = 1000, 32, 1048575, 300000
ARITY = {'ZERO': 0, 'GEN': 1, 'MP': 2}
TRUST = [
    'ZERO schema instances are externally admitted by a native logical kernel.',
    'MP producer output/premise formula tuples are externally semantically admitted.',
    'GEN producers are externally admitted only under closed Gamma.',
    'This frontend checks bounded producer-DAG syntax and formula-ID incidence; it does not admit those rule semantics.'
]


class FrontendError(ValueError):
    pass


class ResourceLimit(FrontendError):
    pass


def _need(condition, reason):
    if not condition:
        raise FrontendError(reason)


def _limit(condition, reason):
    if not condition:
        raise ResourceLimit(reason)


def _fields(value, names, reason):
    _need(type(value) is dict and all(type(k) is str for k in value)
          and set(value) == set(names), reason)


def _hash(value):
    raw = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')
    return hashlib.sha256(raw).hexdigest()


def _formula_id(value):
    _need(type(value) is int and value >= 0, 'FORMULA_ID_TYPE_OR_RANGE')
    _limit(value <= MAX_FORMULA_ID, 'FORMULA_ID_RESOURCE_BOUND')
    return value


def _universe(producers, goal):
    _need(type(producers) is list, 'PRODUCER_LIST')
    _limit(len(producers) <= MAX_PRODUCERS, 'PRODUCER_RESOURCE_BOUND')
    goal = _formula_id(goal)
    frozen, largest = [], goal
    for producer in producers:
        _fields(producer, ('kind', 'output', 'premises'), 'PRODUCER_FIELDS')
        kind, premises = producer['kind'], producer['premises']
        _need(type(kind) is str and kind in ARITY, 'PRODUCER_KIND')
        _need(type(premises) is list and len(premises) == ARITY[kind], 'PRODUCER_ARITY')
        output = _formula_id(producer['output'])
        copied = [_formula_id(value) for value in premises]
        frozen.append({'kind': kind, 'output': output, 'premises': copied})
        largest = max([largest, output] + copied)
    return frozen, goal, max(1, largest.bit_length())


def _length(length):
    _need(type(length) is int and length >= 1, 'EXACT_POSITIVE_PROOF_LENGTH')
    _limit(length <= MAX_LINES, 'PROOF_LENGTH_RESOURCE_BOUND')
    return length


def _layout(producer_count, length):
    producer_width = max(1, (max(1, producer_count) - 1).bit_length())
    reference_width = max(1, (length - 1).bit_length())
    inputs = [{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1}]
    mapping = []
    for line in range(length):
        def word(label, width):
            indices = []
            for bit in range(width):
                indices.append(len(inputs))
                inputs.append({'name': 'line%d.%s.bit%d' % (line, label, bit), 'value': None})
            return indices
        producer = word('producer', producer_width)
        references = [word('ref%d' % role, reference_width) for role in range(2)]
        mapping.append({'line': line, 'producer_bits': producer, 'reference_bits': references})
    return inputs, mapping, producer_width, reference_width


def _budget(builder):
    _limit(len(builder.gates) <= MAX_NAND_GATES, 'NAND_GATE_RESOURCE_BOUND')


def compile_producers(producers, goal, length):
    """Return (NAND circuit, metadata), with no witness-dependent compilation."""
    frozen, goal, formula_width = _universe(producers, goal)
    length = _length(length)
    inputs, mapping, producer_width, reference_width = _layout(len(frozen), length)
    # ALL unknown producer/ref inputs have been allocated before Builder exists.
    builder = Builder(inputs)
    output_words, checks, groups = [], [], []
    for line, layout in enumerate(mapping):
        start = len(builder.gates)
        selectors = [builder.word_eq(layout['producer_bits'], builder.const_word(i, producer_width))
                     for i in range(len(frozen))]
        _budget(builder)
        output_word = [builder.any([selectors[i] for i, producer in enumerate(frozen)
                                   if (producer['output'] >> bit) & 1])
                       for bit in range(formula_width)]
        reference_valid, reference_formulas, reference_zero = [], [], []
        for word in layout['reference_bits']:
            selected = [builder.word_eq(word, builder.const_word(i, reference_width))
                        for i in range(line)]
            reference_valid.append(builder.any(selected))
            reference_formulas.append([
                builder.any([builder.AND(selected[i], output_words[i][bit]) for i in range(line)])
                for bit in range(formula_width)])
            reference_zero.append(builder.word_eq(word, builder.const_word(0, reference_width)))
        matches = []
        for role in range(2):
            needed = sorted({p['premises'][role] for p in frozen if len(p['premises']) > role})
            matches.append({fid: builder.AND(reference_valid[role], builder.word_eq(
                reference_formulas[role], builder.const_word(fid, formula_width))) for fid in needed})
        alternatives = []
        for i, producer in enumerate(frozen):
            conditions = [selectors[i]]
            for role in range(2):
                conditions.append(matches[role][producer['premises'][role]]
                                  if role < len(producer['premises']) else reference_zero[role])
            alternatives.append(builder.all(conditions))
        line_check = builder.any(alternatives)
        _budget(builder)
        output_words.append(output_word); checks.append(line_check)
        groups.append({'name': 'line_%d_check' % line, 'kind': 'line', 'line': line,
                       'gate_range': [start, len(builder.gates)], 'output': line_check})
    start = len(builder.gates)
    goal_check = builder.word_eq(output_words[-1], builder.const_word(goal, formula_width))
    accepted = builder.all(checks + [goal_check])
    _budget(builder)
    circuit = builder.finish(accepted)
    _budget(builder)
    groups.append({'name': 'final_goal', 'kind': 'goal', 'line': length - 1,
                   'gate_range': [start, len(builder.gates)], 'output': circuit['output']})
    metadata = {'schema': 'FP-producer-frontend-metadata-v1', 'version': VERSION,
                'producer_universe': frozen, 'producer_universe_sha256': _hash(frozen),
                'goal': goal, 'length': length, 'producer_word_width': producer_width,
                'reference_word_width': reference_width, 'formula_word_width': formula_width,
                'input_count': len(inputs), 'input_mapping': mapping,
                'groups': groups, 'line_formula_words': output_words, 'line_check_wires': checks,
                'goal_check_wire': goal_check, 'circuit_sha256': _hash(circuit),
                'trust_boundary': list(TRUST),
                'group_scope': 'Half-open indices into circuit.gates for newly emitted gates. Hash-consed dependencies can lie in earlier groups; intervals are not independent subproofs.',
                'scope': 'Exactly length DAG records, final line goal; all active references strictly earlier, premise formula IDs equal ROM outputs, unused reference words zero. No proof search, native logical admission or universal unbounded completeness claim.'}
    return circuit, metadata


def _record(record, producers):
    _fields(record, ('producer', 'refs'), 'PROOF_RECORD_FIELDS')
    index, refs = record['producer'], record['refs']
    _need(type(index) is int and 0 <= index < len(producers), 'PRODUCER_INDEX')
    _need(type(refs) is list and len(refs) == len(producers[index]['premises']), 'PROOF_REFERENCE_ARITY')
    _need(all(type(ref) is int and ref >= 0 for ref in refs), 'REFERENCE_TYPE_OR_RANGE')
    return index, refs


def witness_inputs(metadata, proofrecords):
    """Encode supplied records; never discover them or certify their semantics.

    Representable forward references are encodable so callers can compare the
    independent direct rejection with circuit rejection. Missing reference
    roles are encoded as canonical zero, never fresh free witness bits.
    """
    _need(type(metadata) is dict and type(metadata.get('schema')) is str
          and metadata['schema'] == 'FP-producer-frontend-metadata-v1'
          and type(metadata.get('version')) is str and metadata['version'] == VERSION, 'METADATA_IDENTITY')
    required = ('producer_universe', 'goal', 'length', 'producer_universe_sha256',
                'input_count', 'input_mapping', 'producer_word_width', 'reference_word_width', 'formula_word_width')
    _need(all(key in metadata for key in required), 'METADATA_FIELDS')
    producers, _, formula_width = _universe(metadata['producer_universe'], metadata['goal'])
    length = _length(metadata['length'])
    inputs, mapping, producer_width, reference_width = _layout(len(producers), length)
    _need(type(metadata['producer_universe_sha256']) is str
          and metadata['producer_universe_sha256'] == _hash(producers), 'METADATA_UNIVERSE_HASH')
    for key, expected in (('input_count', len(inputs)), ('producer_word_width', producer_width),
                          ('reference_word_width', reference_width), ('formula_word_width', formula_width)):
        _need(type(metadata[key]) is int and metadata[key] == expected, 'METADATA_WIDTH_OR_COUNT')
    supplied = metadata['input_mapping']
    _need(type(supplied) is list and len(supplied) == length, 'METADATA_INPUT_MAPPING')
    for actual, expected in zip(supplied, mapping):
        _fields(actual, ('line', 'producer_bits', 'reference_bits'), 'METADATA_MAPPING_FIELDS')
        _need(type(actual['line']) is int and actual['line'] == expected['line'], 'METADATA_LINE')
        words = [actual['producer_bits']]
        _need(type(actual['reference_bits']) is list and len(actual['reference_bits']) == 2, 'METADATA_REFERENCE_WORDS')
        words += actual['reference_bits']
        wanted = [expected['producer_bits']] + expected['reference_bits']
        for word, want in zip(words, wanted):
            _need(type(word) is list and len(word) == len(want)
                  and all(type(bit) is int and bit == index for bit, index in zip(word, want)), 'METADATA_BIT_INDICES')
    _need(type(proofrecords) is list and len(proofrecords) == length, 'EXACT_WITNESS_LENGTH')
    bits = [0, 1] + [0] * (len(inputs) - 2)
    for record, layout in zip(proofrecords, mapping):
        producer, refs = _record(record, producers)
        _need(all(ref < (1 << reference_width) for ref in refs), 'REFERENCE_ENCODING_RANGE')
        for word, value in [(layout['producer_bits'], producer)] + list(zip(layout['reference_bits'], list(refs) + [0] * (2 - len(refs)))):
            for bit, index in enumerate(word):
                bits[index] = (value >> bit) & 1
    return bits


def direct_check(producers, goal, records):
    """Independent procedural producer-DAG check; no Builder or NAND use."""
    line = None
    try:
        frozen, goal, _ = _universe(producers, goal)
        _need(type(records) is list, 'PROOF_RECORD_LIST')
        _length(len(records))
        outputs = []
        for line, record in enumerate(records):
            index, refs = _record(record, frozen)
            producer = frozen[index]
            _need(all(ref < line for ref in refs), 'REFERENCE_NOT_STRICTLY_PRIOR')
            for ref, expected in zip(refs, producer['premises']):
                _need(outputs[ref] == expected, 'REFERENCED_FORMULA_MISMATCH')
            outputs.append(producer['output'])
        _need(outputs[-1] == goal, 'FINAL_FORMULA_NOT_GOAL')
        return {'status': 'VERIFIED', 'reason': 'EXACT_BOUNDED_PRODUCER_DAG', 'version': VERSION,
                'lines': len(outputs), 'formula_ids': outputs, 'goal': goal,
                'producer_universe_sha256': _hash(frozen), 'trust_boundary': list(TRUST),
                'scope': 'Conditional on the frozen admitted rule universe; no native logical kernel or automated discovery is performed here.'}
    except ResourceLimit as error:
        return {'status': 'UNKNOWN', 'reason': str(error), 'error_line': line, 'version': VERSION}
    except FrontendError as error:
        return {'status': 'REJECTED', 'reason': str(error), 'error_line': line, 'version': VERSION}
