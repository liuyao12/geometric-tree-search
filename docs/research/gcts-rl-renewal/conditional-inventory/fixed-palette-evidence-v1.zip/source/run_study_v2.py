"""Reproducible fixed-palette qualification and finite witness study.

All circuit instances are frozen before search/execution supplies their free
inputs. Raw certificates, UNKNOWN and REJECTED receipts remain in the archive.
There is no RL update here and no search-speed comparison.
"""
import copy
import gzip
import hashlib
import itertools
import json
from pathlib import Path
import resource
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'attempt-v2'
sys.path.insert(0, str(ROOT / 'source'))
sys.path.insert(0, str(ROOT / 'reference'))
import fixed_palette_v1 as fp
import ribbon_checker_v1 as independent
import producer_frontend_v1 as producer
import counter_frontend_v1 as counter
import logical_cases_v1 as logic
import growing_point_search_v2 as engine
import independent_fol_checker_v1 as kernel

KERNEL_LIMITS = dict(max_operations=10000000, max_depth=256, max_proof_lines=4096)
SEARCH_LIMITS = dict(wall_seconds=30, max_work=1000000000, max_nodes=10000,
                     max_events=10000, max_rollback_records=10000,
                     max_candidates=50000, max_points=1000)


def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = fp.canonical(value)
    if name.endswith('.gz'):
        raw = gzip.compress(raw, mtime=0)
    with path.open('xb') as handle:
        handle.write(raw)
    return {'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def source_pins():
    return {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for d in ('source', 'reference') for p in sorted((ROOT / d).glob('*.py'))}


def audits(model):
    universe = {p['id']: p for p in model['inventory']['placements']}
    observations = []
    def audit(event, state, charge):
        selected = dict(state['selected']); excluded = set(state['excluded'])
        totals = dict(model['seed']['t']); marks = {p: (v, 1) for p, v in model['seed']['m']}
        q = {p: 0 for p in model['roots']}
        for p, n in model['seed']['t']:
            if n:
                q[p] = 0
        for p in q:
            totals.setdefault(p, 0)
        for cid, generation in selected.items():
            row = universe[cid]
            for p, n in row['t']:
                totals[p] = totals.get(p, 0) + n
                q[p] = min(q.get(p, generation), generation)
            for p, v in row['m']:
                assert p not in marks or marks[p][0] == v
                marks[p] = (v, marks.get(p, (None, 0))[1] + 1)
        assert dict(state['totals']) == totals and dict(state['Q']) == q
        assert [[p, v, n] for p, (v, n) in sorted(marks.items())] == state['marks']
        capacity = model['capacity']
        assert all(0 <= v <= capacity for v in totals.values())
        eligible = set()
        domains = {p: set() for p in q if totals.get(p, 0) < capacity}
        for cid, row in universe.items():
            charge(2 + len(row['t']) + len(row['m']))
            if cid in selected or cid in excluded:
                continue
            if any(totals.get(p, 0) + n > capacity for p, n in row['t']):
                continue
            if any(p in marks and marks[p][0] != v for p, v in row['m']):
                continue
            eligible.add(cid)
            for p, n in row['t']:
                if p in domains:
                    domains[p].add(cid)
        assert set(state['eligible']) == eligible
        assert {p: set(ids) for p, ids in state['domains']} == domains
        forward = sorted([p, cid, dict(universe[cid]['t'])[p]] for p, ids in domains.items() for cid in ids)
        assert state['forward'] == forward
        reverse = {}
        for p, cid, n in forward:
            reverse.setdefault(cid, []).append([p, n])
        assert state['reverse'] == [[cid, sorted(rows)] for cid, rows in sorted(reverse.items())]
        assert state['edge_count'] == len(forward)
        dead = [p for p, ids in domains.items() if not ids]
        forced = [p for p, ids in domains.items() if len(ids) == 1]
        if event['kind'] == 'DEAD':
            assert dead and event['point'] == min(dead, key=lambda p: (q[p], p))
        if event['kind'] == 'FORCED':
            assert not dead and forced and event['point'] == min(forced, key=lambda p: (q[p], p))
            assert event['candidate'] in domains[event['point']]
        if event['kind'] == 'BRANCH':
            assert not dead and not forced
            assert event['point'] == min(domains, key=lambda p: (q[p], len(domains[p]), p))
            assert event['data']['legal'] == sorted(domains[event['point']])
        if event['kind'] == 'SOLUTION':
            assert not domains and all(totals.get(p, 0) == capacity for p in q)
        observations.append({'event': event, 'complete_graph_sha256': fp.digest(state),
                             'candidates_checked': len(universe), 'frontier': len(domains), 'edges': len(forward)})
    return audit, observations


def run_search(model, name):
    audit, observations = audits(model)
    answer = engine.solve(model, SEARCH_LIMITS, audit=audit)
    assert answer['entry_state'] is None or answer['entry_state'] == answer['restored_state']
    raw = save('actual/' + name + '-search.json.gz', {'model': model, 'result': answer, 'audits': observations})
    return answer, {'status': answer['status'], 'reason': answer['reason'], 'stats': answer['stats'],
                    'full_graph_audits': len(observations), 'exact_entry_restored': answer['entry_state'] == answer['restored_state'],
                    'raw': raw}


def qualify():
    start = time.perf_counter(); pins = source_pins(); p = fp.palette()
    receipts = []; rejected = []
    # Exhaust all inputs of a routed gate, distinct and equal operand columns.
    for equal in (False, True):
        b = fp.Builder([{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1},
                        {'name': 'u', 'value': None}, {'name': 'v', 'value': None}])
        out = b.nand(2, 2 if equal else 3); c = b.finish(out)
        for u, v in itertools.product((0, 1), repeat=2):
            bits = [0, 1, u, v]; _, value = fp.evaluate(c, bits)
            assert value == 1 - u * (u if equal else v)
            if value:
                cert = fp.certificate(c, bits, p)
                symbolic, literal = independent.verify(c, cert, p), independent.verify_literal(c, cert, p)
                assert symbolic['status'] == literal['status'] == 'VERIFIED'
                receipts.append({'kind': 'gate', 'equal': equal, 'bits': bits, 'symbolic': symbolic, 'literal': literal})
    # Tiny proof universe: all 256 raw bit assignments for each of four goals.
    universe = [{'kind': 'ZERO', 'output': 0, 'premises': []},
                {'kind': 'ZERO', 'output': 3, 'premises': []},
                {'kind': 'GEN', 'output': 1, 'premises': [0]},
                {'kind': 'MP', 'output': 2, 'premises': [0, 0]}]
    truth = []
    for goal in range(4):
        c, meta = producer.compile_producers(universe, goal, 2)
        accepts = 0
        for free in itertools.product((0, 1), repeat=len(c['inputs'])-2):
            bits = [0, 1] + list(free); records, canonical_refs = [], True
            for layout in meta['input_mapping']:
                value = lambda word: sum(bits[index] << k for k, index in enumerate(word))
                pi = value(layout['producer_bits']); refs = [value(w) for w in layout['reference_bits']]
                arity = len(universe[pi]['premises'])
                canonical_refs &= all(ref == 0 for ref in refs[arity:])
                records.append({'producer': pi, 'refs': refs[:arity]})
            expected = canonical_refs and producer.direct_check(universe, goal, records)['status'] == 'VERIFIED'
            _, actual = fp.evaluate(c, bits)
            assert actual == int(expected)
            accepts += actual
        truth.append({'goal': goal, 'assignments': 2 ** (len(c['inputs'])-2), 'accepted': accepts, 'gates': len(c['gates'])})
    # Counter predicates compared with exact arithmetic over every tiny state.
    counter_truth = []
    for instruction, initial in [({'op': 'INC', 'r': 0, 'next': 1}, [0, 0]),
                                  ({'op': 'DECJZ', 'r': 0, 'nonzero': 1, 'zero': 1}, [0, 0]),
                                  ({'op': 'DECJZ', 'r': 0, 'nonzero': 1, 'zero': 1}, [1, 0])]:
        program = [instruction, {'op': 'HALT'}]
        c, meta = counter.compile_counter(program, initial, 1)
        wanted = counter.direct_run(program, initial, 1)[-1]; accepts = 0
        for pc, a, z in itertools.product(range(2), repeat=3):
            trace = [{'pc': 0, 'counters': initial}, {'pc': pc, 'counters': [a, z]}]
            bits = counter.trace_inputs(meta, trace); _, result = fp.evaluate(c, bits)
            assert result == int(trace[-1] == wanted); accepts += result
        counter_truth.append({'program': program, 'initial': initial, 'assignments': 8, 'accepted': accepts})
    # Direct corruption of table, hash, native types, ports, buses and partition.
    b = fp.Builder([{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1},
                    {'name': 'u', 'value': None}, {'name': 'v', 'value': None}])
    c = b.finish(b.nand(2, 3)); cert = fp.certificate(c, [0, 1, 0, 1], p)
    mutations = []
    def mutation(name, target, change):
        cc, pp, tt = copy.deepcopy(c), copy.deepcopy(p), copy.deepcopy(cert)
        change({'c': cc, 'p': pp, 't': tt}[target])
        a, z = independent.verify(cc, tt, pp), independent.verify_literal(cc, tt, pp)
        assert a['status'] == z['status'] == 'REJECTED', (name, a, z)
        mutations.append({'name': name, 'symbolic': a, 'literal': z})
    mutation('palette edge changed', 'p', lambda x: x['tiles'][0].__setitem__('E', 1))
    mutation('wrong circuit digest', 't', lambda x: x.__setitem__('circuit_sha256', '0'*64))
    mutation('wrong full south selector', 't', lambda x: x['rows'][0]['active'][0].__setitem__(1, x['rows'][0]['active'][0][1]+1))
    mutation('missing ribbon', 't', lambda x: x['rows'][0]['ribbons'].pop(0))
    mutation('wrong ribbon bus', 't', lambda x: x['rows'][0]['ribbons'][0].__setitem__(2, 1))
    mutation('wrong stored gate bit', 't', lambda x: x['gate_bits'].__setitem__(0, 0))
    mutation('bool bit rejected', 't', lambda x: x['input_bits'].__setitem__(2, False))
    mutation('float ID rejected', 't', lambda x: x['rows'][0]['active'][0].__setitem__(1, float(x['rows'][0]['active'][0][1])))
    assert pins == source_pins()
    result = {'schema': 'FP-qualification-v1', 'status': 'PASS', 'source_pins': pins,
              'palette_sha256': fp.digest(p), 'distinct_edge_quadruples': len({fp.digest({k:v for k,v in t.items() if k != 'id'}) for t in p['tiles']}),
              'gate_receipts': receipts, 'producer_truth_tables': truth,
              'counter_truth_tables': counter_truth, 'mutants': mutations, 'elapsed_seconds': time.perf_counter()-start}
    save('qualification-v1.json', result)
    print(json.dumps({'qualification': 'PASS', 'producer_assignments': sum(x['assignments'] for x in truth),
                      'counter_assignments': 24, 'mutants': len(mutations)}), flush=True)


def study():
    start = time.perf_counter(); pins = source_pins(); p = fp.palette()
    qualified = json.loads((OUT/'qualification-v1.json').read_text())
    assert qualified['status'] == 'PASS' and qualified['source_pins'] == pins
    assert pins['source/growing_point_search_v2.py']['sha256'] == '6e9687145ec2c86719266e07f7ddee4077d88a386c67152dec368657eae43cbb'
    assert pins['source/independent_fol_checker_v1.py']['sha256'] == '099454304f3a67c8ec49b1a3685c0dc0896662ae0bc26a18db9320d6cb3404b1'
    prepared, freeze_records = [], []
    for case in logic.cases():
        basis = logic.compile_basis(case)
        c, meta = producer.compile_producers(basis['producers'], basis['goal'], case['length'])
        model, lookup = logic.tree_model(basis, case['depth'])
        prepared.append((case, basis, c, meta, model, lookup))
        freeze_records.append(save('frozen/' + case['id'] + '.json.gz',
            {'case': case, 'basis': basis, 'circuit': c, 'metadata': meta, 'search_model_sha256': fp.digest(model)}))
    programs = [
        ('transfer-two', [{'op': 'DECJZ', 'r': 0, 'nonzero': 1, 'zero': 2}, {'op': 'INC', 'r': 1, 'next': 0}, {'op': 'HALT'}], [2, 0], 5),
        ('halt-padding', [{'op': 'INC', 'r': 0, 'next': 1}, {'op': 'HALT'}], [0, 0], 3),
        ('nonhalting-budget', [{'op': 'INC', 'r': 0, 'next': 0}], [0, 0], 3)]
    machines = []
    for name, program, initial, steps in programs:
        c, meta = counter.compile_counter(program, initial, steps)
        machines.append((name, program, initial, steps, c, meta))
        freeze_records.append(save('frozen/' + name + '.json.gz', {'circuit': c, 'metadata': meta}))
    save('freeze-v1.json', {'schema': 'FP-prospective-frozen-instances-v1', 'palette': p,
                            'source_pins': pins, 'records': freeze_records,
                            'order': 'All circuits and complete producer universes saved before any logical search or counter trace is executed.',
                            'search_limits': SEARCH_LIMITS, 'kernel_limits': KERNEL_LIMITS})
    public_cases, logs = [], []
    # Actual literal Wang GCTS: all 100 tile types at every one of five roots.
    for value in (None, 1):
        b = fp.Builder([{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1},
                        {'name': 'u', 'value': value}, {'name': 'v', 'value': value}])
        c = b.finish(b.nand(2, 3)); model = fp.point_model(c, p)
        name = 'tiny-wang-free' if value is None else 'tiny-wang-impossible'
        answer, receipt = run_search(model, name); logs.append({'id': name, 'search': receipt})
        assert answer['status'] == ('SAT' if value is None else 'UNSAT'), receipt
        if value is None:
            top = {r[0]: r[1] for row in answer['certificate']['placements'] for r in row['m']}
            bits = [int(top['v:%d:0:bit' % x]) for x in range(4)]
            cert = fp.certificate(c, bits, p)
            public_cases.append(record_case(name, 'A five-cell Wang patch searched by GCTS', 'literal Wang search', c, cert, p,
                                             extra={'search': receipt}))
    for case, basis, c, meta, model, lookup in prepared:
        admitted = [kernel.check(case['theory'], [line], line['formula'], KERNEL_LIMITS)
                    for line in basis['payloads'][:basis['zero_count']]]
        assert all(r['status'] == 'VERIFIED' for r in admitted), admitted
        save('actual/' + case['id'] + '-basis-admission.json', {'zero_receipts': admitted,
            'all_mp_gen_generated_from_exact_AST_subformulas': True, 'closed_gamma': True})
        answer, search = run_search(model, case['id'])
        assert answer['status'] == 'SAT', search
        proof, records = logic.decode(basis, lookup, answer['selected'])
        receipt = kernel.check(case['theory'], proof, case['goal'], KERNEL_LIMITS)
        assert receipt['status'] == 'VERIFIED', receipt
        records = logic.pad(records, case['length'], basis['producers'])
        direct = producer.direct_check(basis['producers'], basis['goal'], records)
        assert direct['status'] == 'VERIFIED', direct
        bits = producer.witness_inputs(meta, records); gates, output = fp.evaluate(c, bits)
        assert output == 1
        cert = fp.certificate(c, bits, p)
        extra = {'search': search, 'logical_kernel': receipt, 'producer_direct': direct,
                 'zero_instances_admitted': len(admitted), 'automatic_proof_lines': len(proof),
                 'padded_circuit_lines': case['length'], 'basis_producers': len(basis['producers']),
                 'basis_formulae': len(basis['forms'])}
        # Translate padded records back to actual human-readable formula rows.
        padded_proof = []
        for record in records:
            pi, refs = record['producer'], record['refs']; definition = basis['producers'][pi]
            form = basis['forms'][definition['output']]
            if definition['kind'] == 'ZERO':
                line = dict(basis['payloads'][pi])
            elif definition['kind'] == 'MP':
                line = dict(rule='mp', formula=form, antecedent=refs[0], implication=refs[1])
            else:
                line = dict(rule='generalize', formula=form, source=refs[0], variable=basis['payloads'][pi])
            padded_proof.append(line)
        padded_kernel = kernel.check(case['theory'], padded_proof, case['goal'], KERNEL_LIMITS)
        assert padded_kernel['status'] == 'VERIFIED'
        extra['padded_logical_kernel'] = padded_kernel
        groups = [{'label': 'proof line %d' % (g['line']+1) if g['kind'] == 'line' else 'final goal and all line checks',
                   'start': g['gate_range'][0], 'end': g['gate_range'][1], 'proof_line': g['line'],
                   'formula': padded_proof[g['line']]['formula']} for g in meta['groups']]
        item = record_case(case['id'], case['label'], case['kind'], c, cert, p, extra=extra)
        item.update({'proof': {'theory': case['theory'], 'goal': case['goal'], 'lines': padded_proof},
                     'groups': groups, 'meaning': case['meaning']})
        public_cases.append(item)
        save('actual/' + case['id'] + '-proof.json', {'proof': proof, 'padded_proof': padded_proof, 'producer_records': records, 'metadata': meta, 'checks': extra})
        # Every active reference replaced by a self-reference must be rejected.
        corrupt = copy.deepcopy(records)
        index = next(i for i, r in enumerate(corrupt) if r['refs'])
        corrupt[index]['refs'][0] = index
        bad_bits = producer.witness_inputs(meta, corrupt)
        bad_direct = producer.direct_check(basis['producers'], basis['goal'], corrupt)
        assert fp.evaluate(c, bad_bits)[1] == 0 and bad_direct['status'] == 'REJECTED'
        logs.append({'id': case['id'], 'self_reference_mutant': bad_direct, 'circuit_accepts': False})
        print(json.dumps({'case': case['id'], 'search': search['status'], 'proof_lines': len(proof), 'gates': len(c['gates'])}), flush=True)
    for name, program, initial, steps, c, meta in machines:
        trace = counter.direct_run(program, initial, steps)
        bits = counter.trace_inputs(meta, trace); gate_bits, output = fp.evaluate(c, bits)
        save('actual/' + name + '-trace.json', {'trace': trace, 'input_bits': bits, 'output': output, 'metadata': meta})
        if output:
            cert = fp.certificate(c, bits, p)
            item = record_case(name, 'Two-counter machine: ' + name, 'bounded computation', c, cert, p,
                               extra={'trace': trace, 'steps': steps, 'final_halt': True})
            public_cases.append(item)
            corrupt = copy.deepcopy(trace); corrupt[-1]['counters'][0] ^= 1
            assert fp.evaluate(c, counter.trace_inputs(meta, corrupt))[1] == 0
            logs.append({'id': name, 'corrupt_final_counter_rejected': True})
        else:
            assert name == 'nonhalting-budget'
            logs.append({'id': name, 'status': 'NONACCEPTING_WITHIN_FIXED_BUDGET', 'output': 0,
                         'scope': 'Exact supplied finite trace is nonaccepting; this is not a proof of general nonhalting.'})
    assert pins == source_pins()
    elapsed = time.perf_counter()-start
    data = {'schema': 'FP-fixed-palette-results-v1', 'palette': p, 'cases': public_cases,
            'notes': ['The same exact 100 ordinary Wang tiles check all saved circuits. Arithmetic and symbolic incidence proofs were found automatically in a finite logical producer universe, then lowered to this palette.',
                      'This is a fixed-palette backend milestone. The large circuit patches were not searched as literal Wang grids, and there is no RL training or speed-advantage claim in this study.',
                      'A separate five-cell literal Wang patch was searched by the unchanged GCTS engine; its impossible fixed-input companion was exhausted. Large CROSS ribbons are reusable certified cluster families.'],
            'construction': ['Every circuit and its full producer catalogue was frozen before witness generation. Circuit acceptance checks all references and the final formula, rather than a circuit hardcoding the chosen proof.',
                             'The tile checker is independently implemented and checks every compressed row with a 20-case CROSS transport lemma. Literal expansion is independently checked only below its declared 50,000-cell bound; above it the literal checker returns UNKNOWN.',
                             'The proof frontend covers an explicitly finite UI/MP/GEN basis with closed assumptions. Its logical rule admission and the circuit compiler remain separate trust obligations; full first-order syntax verification has not yet been compiled into these tiles.'],
            'provenance': {'source_pins': pins, 'palette_sha256': fp.digest(p), 'freeze_records': freeze_records,
                           'qualification': 'qualification-v1.json', 'elapsed_seconds': elapsed,
                           'native_peak_rss': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                           'platform': sys.platform, 'python': sys.version, 'executable': sys.executable,
                           'logs': logs, 'status': 'COMPLETED_CHECKED', 'source_guard_unchanged': True}}
    save('report/fixed-palette-results-v1.json', data)
    save('completion-v1.json', {'schema': 'FP-study-completion-v1', 'status': 'COMPLETED_CHECKED',
                               'cases': len(public_cases), 'source_pins': pins, 'elapsed_seconds': elapsed, 'logs': logs})
    print(json.dumps({'study': 'COMPLETED_CHECKED', 'saved_cases': len(public_cases), 'seconds': elapsed}), flush=True)


def record_case(name, label, kind, circuit, cert, palette, extra=None):
    start = time.perf_counter()
    symbolic = independent.verify(circuit, cert, palette)
    literal = independent.verify_literal(circuit, cert, palette)
    assert symbolic['status'] == 'VERIFIED', symbolic
    assert literal['status'] in ('VERIFIED', 'UNKNOWN')
    raw = save('actual/' + name + '-tiling.json.gz', {'circuit': circuit, 'certificate': cert,
               'symbolic': symbolic, 'literal': literal})
    return {'id': name, 'label': label, 'kind': kind, 'circuit': circuit,
            'input_bits': cert['input_bits'], 'gate_bits': cert['gate_bits'], 'groups': [],
            'metrics': {'certificate_check_seconds': time.perf_counter()-start,
                        'cells': symbolic['cells'], 'active_cells': symbolic['active_cells'],
                        'ribbon_intervals': symbolic['ribbon_intervals'], 'raw': raw},
            'checks': {'status': 'VERIFIED', 'ribbon': symbolic, 'literal': literal, **(extra or {})}}


if __name__ == '__main__':
    if sys.argv[1:] == ['qualify']:
        qualify()
    elif sys.argv[1:] == ['study']:
        study()
    else:
        raise SystemExit('Use qualify or study.')
