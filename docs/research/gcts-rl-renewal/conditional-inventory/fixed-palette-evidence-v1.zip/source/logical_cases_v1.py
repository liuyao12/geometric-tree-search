"""Small declarative arithmetic/incidence cases; generic finite UI basis.

No proof sequence is supplied. Search uses the unchanged growing-point engine
on a complete bounded anchored tree inventory. It is not search on the Wang
circuit; that backend only checks a subsequently supplied proof witness.
"""
import copy
import itertools
import json


def key(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',', ':'))


def cases():
    v = lambda x: ['var', x]
    c = lambda x: ['fun', x, []]
    f = lambda x, *a: ['fun', x, list(a)]
    eq = lambda a, b: ['eq', a, b]
    x, l, m = v('x'), v('l'), v('m')
    # A familiar consequence of one actual PA defining axiom. No induction.
    pa = {'id': 'pa-add-successor-zero', 'label': 'A successor plus zero', 'kind': 'arithmetic',
          'theory': {'functions': {'zero': 0, 'S': 1, 'add': 2}, 'predicates': {},
                     'axioms': {'add_zero': ['all', 'x', eq(f('add', x, c('zero')), x)]}},
          'goal': ['all', 'x', eq(f('add', f('S', x), c('zero')), f('S', x))],
          'terms': [x, f('S', x), c('zero')], 'ui_rounds': 1, 'depth': 5, 'length': 8,
          'meaning': 'For every number x, its successor plus zero is its successor. This uses only the supplied addition-zero axiom, universal instantiation and generalization.'}
    on = lambda p, line: ['pred', 'On', [p, line]]
    a, b, ell, emm = c('a'), c('b'), c('ell'), c('emm')
    def conjunction(items):
        out = items[-1]
        for item in reversed(items[:-1]):
            out = ['and', item, out]
        return out
    def common(left, right):
        return conjunction([['not', eq(a, b)], on(a, left), on(b, left), on(a, right), on(b, right)])
    geo = {'id': 'incidence-common-two-points', 'label': 'Two lines through the same distinct points', 'kind': 'symbolic geometry',
           'theory': {'functions': {'a': 0, 'b': 0, 'ell': 0, 'emm': 0}, 'predicates': {'On': 2},
                      'axioms': {'incidence_uniqueness_ab': ['all', 'l', ['all', 'm', ['imp', common(l, m), eq(l, m)]]],
                                 'given_common_points': common(ell, emm)}},
           'goal': eq(ell, emm), 'terms': [ell, emm], 'ui_rounds': 2, 'depth': 6, 'length': 12,
           'meaning': 'If two distinct named points lie on both named lines, the lines are equal. A finite one-sorted fragment of incidence uniqueness, with the common-point hypotheses supplied. No coordinates, metric geometry or full Hilbert formalization.'}
    return [pa, geo]


def free_term(term):
    return {term[1]} if term[0] == 'var' else set().union(*(free_term(a) for a in term[2]))


def free(form):
    if form[0] == 'all':
        return free(form[2]) - {form[1]}
    if form[0] in ('imp', 'and', 'or'):
        return free(form[1]) | free(form[2])
    if form[0] == 'not':
        return free(form[1])
    if form[0] == 'eq':
        return free_term(form[1]) | free_term(form[2])
    return set().union(*(free_term(t) for t in form[2])) if form[0] == 'pred' else set()


def substitute(form, variable, term):
    def st(t):
        return copy.deepcopy(term) if t == ['var', variable] else t if t[0] == 'var' else ['fun', t[1], [st(a) for a in t[2]]]
    tag = form[0]
    if tag == 'all':
        if form[1] == variable:
            return copy.deepcopy(form)
        if variable in free(form[2]) and form[1] in free_term(term):
            raise ValueError('Capture: omitted from this finite basis, not treated as a proof.')
        return ['all', form[1], substitute(form[2], variable, term)]
    if tag in ('imp', 'and', 'or'):
        return [tag, substitute(form[1], variable, term), substitute(form[2], variable, term)]
    if tag == 'not':
        return ['not', substitute(form[1], variable, term)]
    if tag == 'eq':
        return ['eq', st(form[1]), st(form[2])]
    return ['pred', form[1], [st(t) for t in form[2]]] if tag == 'pred' else copy.deepcopy(form)


def compile_basis(case):
    zeros = [dict(rule='axiom', name=n, formula=f) for n, f in case['theory']['axioms'].items()]
    pool = {}
    def add(f):
        k = key(f)
        if k in pool:
            return
        pool[k] = f
        if f[0] == 'all':
            add(f[2])
        elif f[0] in ('imp', 'and', 'or'):
            add(f[1]); add(f[2])
        elif f[0] == 'not':
            add(f[1])
    add(case['goal'])
    for z in zeros:
        add(z['formula'])
    for _ in range(case['ui_rounds']):
        universals = [f for f in list(pool.values()) if f[0] == 'all']
        for u in universals:
            for term in case['terms']:
                try:
                    instance = substitute(u[2], u[1], term)
                except ValueError:
                    continue
                z = dict(rule='instantiate', universal=u, term=term, formula=['imp', u, instance])
                zeros.append(z); add(z['formula'])
    zeros = sorted({key(z): z for z in zeros}.values(), key=key)
    forms = [pool[k] for k in sorted(pool)]
    ids = {key(f): i for i, f in enumerate(forms)}
    producers = [{'kind': 'ZERO', 'output': ids[key(z['formula'])], 'premises': []} for z in zeros]
    payloads = [dict(z) for z in zeros]
    for fid, form in enumerate(forms):
        if form[0] == 'imp':
            producers.append({'kind': 'MP', 'output': ids[key(form[2])], 'premises': [ids[key(form[1])], fid]})
            payloads.append(None)
        elif form[0] == 'all':
            producers.append({'kind': 'GEN', 'output': fid, 'premises': [ids[key(form[2])]]})
            payloads.append(form[1])
    return {'forms': forms, 'producers': producers, 'payloads': payloads,
            'goal': ids[key(case['goal'])], 'zero_count': len(zeros),
            'scope': 'Complete ZERO/MP/GEN producers for this explicit finite subformula/UI basis. No full FOL completeness.'}


def tree_model(basis, depth):
    placements, lookup = [], {}
    for n in range(depth + 1):
        for bits in itertools.product('01', repeat=n):
            site = ''.join(bits)
            for pi, p in enumerate(basis['producers']):
                if p['premises'] and n == depth:
                    continue
                positions = [site] + [site + str(i) for i in range(len(p['premises']))]
                row = {'id': key([site, pi]), 't': [[s, 1] for s in positions],
                       'm': [[s, str(fid)] for s, fid in zip(positions, [p['output']] + p['premises'])]}
                placements.append(row); lookup[row['id']] = (site, pi)
    return {'schema': 'Z-growing-point-model-v1', 'version': 'FP-finite-proof-tree-v1', 'capacity': 2,
            'roots': [''], 'seed': {'t': [['', 1]], 'm': [['', str(basis['goal'])]]},
            'inventory': {'kind': 'EXPLICIT', 'placements': placements}}, lookup


def decode(basis, lookup, selected):
    assert len(selected) == len(set(selected)), 'Duplicate selected placement ID.'
    assert len({lookup[cid][0] for cid in selected}) == len(selected), 'Duplicate selected proof site.'
    nodes = {lookup[cid][0]: lookup[cid][1] for cid in selected}
    proof, records = [], []
    def visit(site):
        pi = nodes[site]; p = basis['producers'][pi]
        refs = [visit(site + str(i)) for i in range(len(p['premises']))]
        formula = basis['forms'][p['output']]
        if p['kind'] == 'ZERO':
            line = dict(basis['payloads'][pi])
        elif p['kind'] == 'MP':
            line = dict(rule='mp', formula=formula, antecedent=refs[0], implication=refs[1])
        else:
            line = dict(rule='generalize', formula=formula, source=refs[0], variable=basis['payloads'][pi])
        records.append({'producer': pi, 'refs': refs}); proof.append(line)
        return len(proof) - 1
    visit('')
    assert len(nodes) == len(proof)
    return proof, records


def pad(records, length, producers):
    assert records and len(records) <= length and not producers[records[0]['producer']]['premises']
    extra = length - len(records)
    return [dict(producer=records[0]['producer'], refs=[]) for _ in range(extra)] + [
        dict(producer=r['producer'], refs=[i + extra for i in r['refs']]) for r in records]
