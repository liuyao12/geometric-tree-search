"""Bounded two-counter trace validity compiled to the shared NAND circuit.

Source-only implementation pending review. This module performs no search and
does not claim efficient universal simulation. The palette is not specialized
to a program: this frontend produces ordinary FP-NAND-circuit-v1 data.

Trace slots are dictionaries {'pc': integer, 'counters': [integer, integer]}.
Words and input-index lists are little-endian. Slot zero is fixed by sharing
the Builder's zero/one inputs; all later trace slots are free circuit inputs.
Acceptance means a valid execution of exactly the given transition budget,
with an absorbing HALT and a HALT opcode in the final slot.
"""
from fixed_palette_v1 import Builder


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(name + ' must be a native integer at least ' + str(minimum))
    return value


def _parameters(program, initial, steps):
    """Validate the finite machine syntax; never infer a halting bound."""
    _integer(steps, 'steps')
    if type(initial) is not list or len(initial) != 2:
        raise ValueError('initial must be a two-element list')
    initial = [_integer(value, 'initial counter') for value in initial]
    if type(program) is not list or not program:
        raise ValueError('program must be a nonempty instruction list')
    copied = []
    fields = {'INC': {'op', 'r', 'next'},
              'DECJZ': {'op', 'r', 'nonzero', 'zero'}, 'HALT': {'op'}}
    for pc, instruction in enumerate(program):
        if type(instruction) is not dict:
            raise ValueError('instruction must be a dictionary')
        op = instruction.get('op')
        if type(op) is not str or op not in fields or set(instruction) != fields[op]:
            raise ValueError('invalid instruction fields at pc ' + str(pc))
        if op != 'HALT':
            if type(instruction['r']) is not int or instruction['r'] not in (0, 1):
                raise ValueError('register must be native integer zero or one')
            targets = ('next',) if op == 'INC' else ('nonzero', 'zero')
            for field in targets:
                target = _integer(instruction[field], 'instruction target')
                if target >= len(program):
                    raise ValueError('instruction target is outside the program')
        copied.append(dict(instruction))
    counter_bound = max(initial) + steps
    return copied, initial, steps, max(1, counter_bound.bit_length()), max(1, (len(program)-1).bit_length())


def _layout(initial, steps, counter_width, pc_width):
    """Allocate all inputs before any gate; constants are wire indices 0/1."""
    inputs = [{'name': 'zero', 'value': 0}, {'name': 'one', 'value': 1}]
    slots = [{'pc': [0]*pc_width,
              'counters': [[(value >> k) & 1 for k in range(counter_width)]
                           for value in initial]}]
    for slot in range(1, steps+1):
        row = {'pc': [], 'counters': [[], []]}
        for k in range(pc_width):
            row['pc'].append(len(inputs))
            inputs.append({'name': 'slot%d.pc.bit%d' % (slot, k), 'value': None})
        for register in (0, 1):
            for k in range(counter_width):
                row['counters'][register].append(len(inputs))
                inputs.append({'name': 'slot%d.r%d.bit%d' % (slot, register, k), 'value': None})
        slots.append(row)
    return inputs, slots


def _increment(builder, word):
    carry, result = 1, []
    for bit in word:
        result.append(builder.XOR(bit, carry))
        carry = builder.AND(bit, carry)
    return result, carry


def _decrement(builder, word):
    borrow, result = 1, []
    for bit in word:
        result.append(builder.XOR(bit, borrow))
        borrow = builder.AND(builder.NOT(bit), borrow)
    return result, borrow


def compile_counter(program, initial, steps):
    """Return (circuit, metadata) for bounded, accepting trace existence.

    INC increments one counter and jumps to `next`. DECJZ decrements its
    nonzero counter and jumps to `nonzero`, otherwise leaves it zero and
    jumps to `zero`. The other counter is unchanged. HALT preserves the
    entire state. A program without any HALT has no accepting witness.

    Counter width covers max(initial)+steps; overflow and nonzero-branch
    underflow are also explicitly forbidden by the transition predicate.
    PC range is checked independently in every slot, including the last.
    """
    program, initial, steps, counter_width, pc_width = _parameters(program, initial, steps)
    inputs, slots = _layout(initial, steps, counter_width, pc_width)
    builder = Builder(inputs)
    ranges, transitions = [], []
    selectors = []
    for slot in slots:
        selected = [builder.word_eq(slot['pc'], builder.const_word(pc, pc_width))
                    for pc in range(len(program))]
        selectors.append(selected)
        ranges.append(builder.any(selected))
    for time in range(steps):
        current, following = slots[time], slots[time+1]
        current_words, next_words = current['counters'], following['counters']
        incremented = [_increment(builder, word) for word in current_words]
        decremented = [_decrement(builder, word) for word in current_words]
        is_zero = [builder.NOT(builder.any(word)) for word in current_words]
        choices = []
        for pc, instruction in enumerate(program):
            op = instruction['op']
            if op == 'HALT':
                valid = builder.all([builder.word_eq(following['pc'], current['pc'])] +
                                    [builder.word_eq(a, b) for a, b in zip(next_words, current_words)])
            else:
                register = instruction['r']
                unchanged = builder.word_eq(next_words[1-register], current_words[1-register])
                if op == 'INC':
                    word, overflow = incremented[register]
                    valid = builder.all([
                        unchanged, builder.NOT(overflow),
                        builder.word_eq(next_words[register], word),
                        builder.word_eq(following['pc'], builder.const_word(instruction['next'], pc_width))])
                else:
                    word, underflow = decremented[register]
                    nonzero_case = builder.all([
                        builder.NOT(is_zero[register]), builder.NOT(underflow),
                        builder.word_eq(next_words[register], word),
                        builder.word_eq(following['pc'], builder.const_word(instruction['nonzero'], pc_width))])
                    zero_case = builder.all([
                        is_zero[register], builder.word_eq(next_words[register], current_words[register]),
                        builder.word_eq(following['pc'], builder.const_word(instruction['zero'], pc_width))])
                    valid = builder.AND(unchanged, builder.OR(nonzero_case, zero_case))
            choices.append(builder.AND(selectors[time][pc], valid))
        transitions.append(builder.any(choices))
    final_halt = builder.any([selectors[-1][pc] for pc, instruction in enumerate(program)
                              if instruction['op'] == 'HALT'])
    output = builder.all(ranges + transitions + [final_halt])
    metadata = {
        'schema': 'FP-bounded-two-counter-metadata-v1',
        'program': program, 'initial': initial, 'steps': steps,
        'counter_width': counter_width, 'pc_width': pc_width,
        'counter_bound': max(initial)+steps, 'word_order': 'little-endian',
        'input_count': len(inputs), 'slots': slots,
        'groups': {'pc_range': ranges, 'transitions': transitions, 'final_halt': [final_halt]},
        'output': output,
        'scope': 'Finite budget only. Absorbing halt gives acceptance within the budget. No search or efficient universal-simulation claim.'}
    return builder.finish(output), metadata


def trace_inputs(metadata, trace):
    """Encode a supplied trace, without searching or validating transitions.

    Values must fit the declared unsigned words. A representable out-of-range
    later PC can be encoded for a negative circuit test; the circuit rejects
    it. Slot zero must match its fixed state. Inputs 0 and 1 remain fixed.
    """
    if type(metadata) is not dict or metadata.get('schema') != 'FP-bounded-two-counter-metadata-v1':
        raise ValueError('invalid metadata schema')
    program, initial, steps, counter_width, pc_width = _parameters(
        metadata['program'], metadata['initial'], metadata['steps'])
    for name, expected in [('counter_width', counter_width), ('pc_width', pc_width)]:
        if type(metadata.get(name)) is not int or metadata[name] != expected:
            raise ValueError('metadata word width mismatch')
    inputs, slots = _layout(initial, steps, counter_width, pc_width)
    if type(metadata.get('input_count')) is not int or metadata['input_count'] != len(inputs):
        raise ValueError('metadata input count mismatch')
    if type(metadata.get('slots')) is not list or len(metadata['slots']) != len(slots):
        raise ValueError('metadata slot count mismatch')
    for actual, expected in zip(metadata['slots'], slots):
        if type(actual) is not dict or set(actual) != {'pc', 'counters'}:
            raise ValueError('invalid metadata slot')
        if type(actual['pc']) is not list or type(actual['counters']) is not list or len(actual['counters']) != 2:
            raise ValueError('invalid metadata word lists')
        words = [actual['pc']]+actual['counters']
        if any(type(word) is not list or any(type(index) is not int for index in word) for word in words):
            raise ValueError('metadata input indices must be native integers')
        if actual != expected:
            raise ValueError('metadata input layout mismatch')
    if type(trace) is not list or len(trace) != steps+1:
        raise ValueError('trace must contain steps+1 slots')
    bits = [None]*len(inputs)
    bits[0], bits[1] = 0, 1
    for time, (state, slot) in enumerate(zip(trace, slots)):
        if type(state) is not dict or set(state) != {'pc', 'counters'}:
            raise ValueError('invalid trace slot')
        pc = _integer(state['pc'], 'trace pc')
        if pc >= 1 << pc_width:
            raise ValueError('trace pc does not fit its word')
        if type(state['counters']) is not list or len(state['counters']) != 2:
            raise ValueError('trace counters must be a two-element list')
        counters = [_integer(value, 'trace counter') for value in state['counters']]
        if any(value >= 1 << counter_width for value in counters):
            raise ValueError('trace counter does not fit its word')
        for value, indices in [(pc, slot['pc'])]+list(zip(counters, slot['counters'])):
            for k, index in enumerate(indices):
                bit = (value >> k) & 1
                if bits[index] is not None and bits[index] != bit:
                    raise ValueError('trace conflicts with fixed initial state')
                bits[index] = bit
    return bits


def direct_run(program, initial, steps):
    """Execute this exact finite budget; pad an early halt by self-loops.

    The result may be nonaccepting. No further budget is tried and no proof
    or theorem search is performed. This helper is independent of Builder.
    """
    program, counters, steps, counter_width, pc_width = _parameters(program, initial, steps)
    pc = 0
    trace = [{'pc': pc, 'counters': list(counters)}]
    for time in range(steps):
        instruction = program[pc]
        if instruction['op'] == 'INC':
            counters[instruction['r']] += 1
            pc = instruction['next']
        elif instruction['op'] == 'DECJZ':
            register = instruction['r']
            if counters[register]:
                counters[register] -= 1
                pc = instruction['nonzero']
            else:
                pc = instruction['zero']
        trace.append({'pc': pc, 'counters': list(counters)})
    return trace
