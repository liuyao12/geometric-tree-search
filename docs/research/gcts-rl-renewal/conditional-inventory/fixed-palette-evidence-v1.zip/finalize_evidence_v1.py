"""Admit saved evidence, then produce one deterministic prepublication archive."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
GIT = '/private/tmp/gcts-history-publication-20261102-v1.git'
BASE = '86ee5b067faa9402b3ebf0441fc8fef256cce456'


def write(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2)+'\n')


def main():
    complete = json.loads((ROOT/'attempt-v2/completion-v1.json').read_text())
    qualification = json.loads((ROOT/'attempt-v2/qualification-v1.json').read_text())
    observed = json.loads((ROOT/'attempt-v2/observation/completion-v1.json').read_text())
    generations = json.loads((ROOT/'review/passive-generation-audit-v1.json').read_text())
    assert complete['status'] == 'COMPLETED_CHECKED' and qualification['status'] == 'PASS'
    assert observed['native_exit'] == 0 and not observed['terminated_on_wall_limit']
    assert observed['subject'] == observed['subject_after'] and observed['runtime'] == observed['runtime_after']
    assert qualification['source_pins'] == complete['source_pins']
    for relative, pin in complete['source_pins'].items():
        raw = (ROOT/relative).read_bytes()
        assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']
    assert all(not c['errors'] for c in generations['checks']) and len(generations['checks']) == 4
    master = (ROOT/'reference/basic-tiling-algorithm.md').read_bytes()
    assert hashlib.sha256(master).hexdigest() == 'c1327e5ed6e9c6bcb29768d11e21e178bfe2a231464c086cad0c6af7352a1cf9'
    write('review/milestone-admission-v1.json', {
        'schema': 'FP-milestone-admission-v1', 'status': 'ADMITTED_FIXED_PALETTE_BACKEND',
        'native_exit': 0, 'source_guards_unchanged': True, 'palette_types': 100,
        'producer_truth_assignments': 1024, 'counter_state_assignments': 24,
        'mutations_rejected_by_both_tiling_checkers': 8, 'semantic_proofs_found': 2,
        'search_proof_lines': [7, 7], 'fixed_padded_slots': [8, 12],
        'literal_wang_control_outcomes': ['SAT', 'UNSAT'], 'complete_graph_event_audits': 65,
        'passive_generation_audit': 'review/passive-generation-audit-v1.json',
        'coverage': 'All four successful-attempt raw GCTS results, all five accepting compressed patches, full native proofs and rule catalogues retained.',
        'prior_attempt': 'Native exit1 at initial READY audit; zero-total reconstruction corrected. Original Source, frozen inputs and logs retained.',
        'construction': 'One fixed100 ordinary translation-only Wang palette; circuit program supplied by interior operation pins. NAND row induction plus exhaustive CROSS transport supports every finite circuit.',
        'conformance': 'All100 tile types enumerated at every literal root; all finite target centers activated. Proof-tree model activates every conditional positive-support demand. Point t/m only; full global incidence, dead/forced/earliest-generation order and exact rollback checked.',
        'gaps': ['Large patches were constructed from automatically searched semantic proofs, not discovered by literal Wang-grid search.',
                 'No RL training or search-superiority claim in this milestone.',
                 'Logical rule admission remains external; no full FOL parser/kernel circuit yet.',
                 'Manually proved ribbon families, not learned clusters.',
                 'Finite arithmetic/incidence fragments, not full PA or full Hilbert geometry.',
                 'No outer-boundary-only universality, aperiodicity or plane-tiling claim.',
                 'Counter compiler lacks general resource ceilings; only frozen small programs supervised.'],
        'program_goal_status': 'ACTIVE; this is a completed submilestone only.'})
    write('qa/local-ui-v1.json', {'status': 'PASS', 'browser': 'IAB',
        'original_proof_rows': [7,7], 'padded_proof_rows': [8,12], 'palette_types': 100,
        'NAND_to_WRITE_filter_cards': 4, 'maximum_visible_cells': 72,
        'proof_line_to_band': 'Original incidence line7 navigates to circuit witness line12, gate interval[15072,16932).',
        'math_errors': 0, 'console_errors_or_warnings': [], 'body_overflow': False,
        'screenshot': 'qa/local-patch-v1.png',
        'checks': ['Colored operation and bit stripes, exact tuple inspector', 'Case-specific literal/search caption', 'Original/padded proof mode', 'Native MathJax goal, inference formulas and English']})
    previous = subprocess.check_output(['git', '--git-dir='+GIT, 'show', BASE+':docs/research/gcts-rl-renewal/conditional-inventory/cluster-policy-proof-search-v1.html']).decode()
    assert len(previous.encode()) == 25325 and previous.count('</h1>') == 1
    continuation = '<p class="panel scope"><a href="fixed-palette-proof-backend-v1.html#reader">Next milestone: one fixed Wang palette, arithmetic and incidence proof witnesses, and reusable crossing ribbons.</a></p>'
    (ROOT/'report/cluster-policy-proof-search-v1.html').write_text(previous.replace('</h1>', '</h1>'+continuation, 1))
    readme = '''This archive is the fixed-palette backend milestone of the GCTS research program.

The successful study is attempt-v2. Its observer exited0; runtime and scientific
Source hashes were unchanged. The original failed attempt is preserved at the
root (qualification-v1.json, frozen/, observation/, source/run_study_v1.py).
It stopped before any positive result at an auditor zero-total mismatch. The
old logical Source is preserved in review/logical-cases-before-binding-v1.txt.

source/ contains the actual scientific Sources, including the unchanged point
search engine and independent classical FOL kernel. reference/ contains the
independent ribbon/literal checker and mathematical construction review.
attempt-v2/frozen/ contains proof circuits and complete producer universes saved
before proof search; actual/ contains raw search outcomes, proofs and tilings.
report/ contains the public projection and reader. review/ records admission,
peer review and a passive generation audit. qa/ contains prepublication UI QA.

Reproduction: use a fresh directory containing source/, reference/ and
observe_study_v2.py; copy ALL .py Sources, not just imported ones. With the
recorded Python3.12 runtime run source/run_study_v2.py qualify, then
observe_study_v2.py. The observer uses the recorded runtime's local absolute
path; adjust only that observer path for another host. Never execute the old
failed v1 as a continuation. Existing outputs use exclusive writes, so do not
run over an evidence directory. No external packages are required.

This is not a new proof-search benchmark victory: arithmetic and incidence are
small admitted fragments, with proofs automatically found in a finite semantic
GCTS inventory. Their larger fixed-palette patches are constructed certificates.
Every interior operation selector is an explicit instance pin. The full
first-order parser/kernel has not yet been implemented as a circuit. General
large counter jobs are outside the frozen finite-resource claim.

The user explicitly approved publishing the full evidence archive, including
Source snapshots, raw certificates, execution logs and local filesystem paths,
to the existing public GitHub Pages destination. This archive contains only
task-owned evidence. Materials-reconstruction work is retired and absent.

The deterministic archive cut precedes Git publication and live verification.
Later publication receipts remain in the local publication/ supplement; they
cannot be included in the archive whose hash they verify.
'''
    (ROOT/'README-evidence-v1.txt').write_text(readme)
    # Explicit cut: package and publication receipts cannot recursively archive themselves.
    paths = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).parts[0] not in ('package','publication'))
    entries = []
    for path in paths:
        b = path.read_bytes()
        entries.append({'path': str(path.relative_to(ROOT)), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
    manifest = {'schema': 'FP-full-evidence-cut-v1', 'original_files': len(entries),
                'original_bytes': sum(e['bytes'] for e in entries), 'files': entries,
                'exclusions': ['package/ (archive outputs)', 'publication/ (post-cut Git/live receipts)']}
    package = ROOT/'package'; package.mkdir(exist_ok=True)
    write('package/file-manifest-v1.json', manifest)
    target = package/'fixed-palette-evidence-v1.zip'
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for e in entries:
            info = zipfile.ZipInfo(e['path'], date_time=(2026,11,3,0,0,0)); info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, (ROOT/e['path']).read_bytes())
        info = zipfile.ZipInfo('ARCHIVE-file-manifest-v1.json', date_time=(2026,11,3,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info, json.dumps(manifest, sort_keys=True, indent=2)+'\n')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(entries)+1
        for e in entries:
            b = z.read(e['path'])
            assert len(b) == e['bytes'] and hashlib.sha256(b).hexdigest() == e['sha256']
    receipt = {'status':'PASS_FULL_ARCHIVE_CLOSURE','archive': str(target), 'bytes':target.stat().st_size,
               'sha256':hashlib.sha256(target.read_bytes()).hexdigest(), 'members':len(entries)+1,
               'original_files':len(entries), 'original_bytes':manifest['original_bytes']}
    write('package/archive-verification-v1.json', receipt)
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
