This archive is the fixed-palette backend milestone of the GCTS research program.

The successful study is attempt-v2. Its observer exited0; runtime and scientific
Source hashes were unchanged. The original failed attempt is preserved at the
root (qualification-v1.json, frozen/, observation/, source/run_study_v1.py).
It stopped before any positive result at an auditor zero-total mismatch. The
old logical Source is preserved in review/logical-cases-before-binding-v1.txt.

source/ contains the actual scientific Sources, including the unchanged point
search engine and independent classical FOL kernel. reference/ contains the
independent ribbon/literal checker and mathematical construction review.
attempt-v2/frozen/ contains proof circuits and complete producer universes saved
before proof search; actual/ contains raw search outcomes, proofs and tilings.
report/ contains the public projection and reader. review/ records admission,
peer review and a passive generation audit. qa/ contains prepublication UI QA.

Reproduction: use a fresh directory containing source/, reference/ and
observe_study_v2.py; copy ALL .py Sources, not just imported ones. With the
recorded Python3.12 runtime run source/run_study_v2.py qualify, then
observe_study_v2.py. The observer uses the recorded runtime's local absolute
path; adjust only that observer path for another host. Never execute the old
failed v1 as a continuation. Existing outputs use exclusive writes, so do not
run over an evidence directory. No external packages are required.

This is not a new proof-search benchmark victory: arithmetic and incidence are
small admitted fragments, with proofs automatically found in a finite semantic
GCTS inventory. Their larger fixed-palette patches are constructed certificates.
Every interior operation selector is an explicit instance pin. The full
first-order parser/kernel has not yet been implemented as a circuit. General
large counter jobs are outside the frozen finite-resource claim.

The user explicitly approved publishing the full evidence archive, including
Source snapshots, raw certificates, execution logs and local filesystem paths,
to the existing public GitHub Pages destination. This archive contains only
task-owned evidence. Materials-reconstruction work is retired and absent.

The deterministic archive cut precedes Git publication and live verification.
Later publication receipts remain in the local publication/ supplement; they
cannot be included in the archive whose hash they verify.
