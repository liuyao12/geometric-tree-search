"""Passive qualification receipt joins; read only the declared19 JSON files."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-fol-kernel-20261103-v1')
RULES = ('AXIOM', 'MP', 'GEN', 'UI', 'REFL', 'DIST', 'EQSUB', 'AX1', 'AX2', 'AX3', 'BOT_FALSE')


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a, b):
    return wire(a) == wire(b)


def read(path):
    data = path.read_bytes()
    return json.loads(data), {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    design, dref = read(ROOT/'qualify-design-v1.json')
    completion, cref = read(ROOT/'qualify-completion-v1.json')
    assert completion['status'] == 'COMPLETED_CHECKED' and completion['cases'] == 17
    assert same(design['source_pins'], completion['source_pins']) and len(design['source_pins']) == 8
    cases, summaries = design['cases'], completion['summaries']
    assert len(cases) == len(summaries) == 17
    assert len({case['id'] for case in cases}) == 17
    assert [case['id'] for case in cases] == [summary['id'] for summary in summaries]
    counts, coverage, rows, refs = Counter(), Counter(), [], [dref, cref]
    physical_cells, literal_cells = 0, 0
    expected_rejections = {
        'reject-variable-capture': ('SUBSTITUTION_CAPTURE', 'RULE_FORMULA_MISMATCH'),
        'reject-open-Gamma': ('OPEN_ASSUMPTION', 'OPEN_THEORY_AXIOM'),
        'reject-distribution-freshness': ('DIST_INCIDENCE_OR_FREE_VARIABLE', 'DISTRIBUTE_FRESHNESS'),
        'reject-changed-axiom': ('AXIOM_INSTANCE', 'RULE_FORMULA_MISMATCH')}
    seen_rejections = set()
    for case, summary in zip(cases, summaries):
        identifier = case['id']
        assert identifier and all(char.isascii() and (char.isalnum() or char == '-') for char in identifier)
        assert case['kind'] == summary['kind'] == 'qualification'
        assert type(case['expected']) is bool and summary['expected'] is case['expected']
        assert same(case['bounds'], summary['bounds'])
        # The whitelist comes exclusively from the completed qualification design.
        # No directory glob or research-mode file is read.
        evaluation, ref = read(ROOT/'actual'/(identifier+'-logical-evaluation.json'))
        refs.append(ref)
        expected = case['expected']; checks = summary['checks']
        assert evaluation['expected'] is expected
        assert evaluation['circuit_accepts'] is checks['circuit_accepts'] is expected
        assert same(evaluation['raw_kernel'], checks['raw_kernel'])
        assert same(evaluation['native_FOL'], checks['native_FOL'])
        raw, native = evaluation['raw_kernel'], evaluation['native_FOL']
        assert (raw['status'] == 'VERIFIED') is expected and (native['status'] == 'VERIFIED') is expected
        assert raw['status'] == native['status'] == ('VERIFIED' if expected else 'REJECTED')
        assert raw['version'] == 'NK-RAW-FOL-CHECKER-v1'
        bits = evaluation['input_bits']; certificate = evaluation['raw_certificate']
        assert type(bits) is list and bits[:2] == [0, 1] and all(type(bit) is int and bit in (0, 1) for bit in bits)
        costs = summary['costs']; assert len(bits) == costs['inputs']
        assert all(type(costs[key]) is int for key in ('inputs', 'gates', 'expanded_cells'))
        nominal_cells = costs['gates'] * (costs['gates'] + costs['inputs'])
        assert costs['expanded_cells'] == nominal_cells
        assert len(certificate['nodes']) == case['bounds']['nodes']
        assert len(certificate['proof']) == case['bounds']['lines']
        assert len(certificate['substitutions']) == case['bounds']['substitutions']
        gate_hash = evaluation['gate_bits_sha256']
        assert type(gate_hash) is str and len(gate_hash) == 64 and all(c in '0123456789abcdef' for c in gate_hash)
        if expected:
            counts['accepted'] += 1
            assert raw['certificate_sha256'] == digest(certificate)
            assert same(raw['bounds'], case['bounds']) and raw['closed_Gamma'] is True
            assert raw['checked_lines'] == native['checked_lines'] == len(case['proof']) == len(certificate['proof'])
            assert raw['checked_nodes'] == len(certificate['nodes']) and raw['checked_substitutions'] == len(certificate['substitutions'])
            assert native['error_line'] is None
            local = Counter(RULES[record['rule']] for record in certificate['proof'])
            assert set(raw['rule_counts']) == set(RULES)
            assert all(raw['rule_counts'][rule] == local[rule] for rule in RULES)
            coverage.update(local); counts['accepted_proof_lines'] += len(certificate['proof'])
            ribbon, literal = checks['ribbon'], checks['literal']
            assert ribbon['status'] == 'VERIFIED' and ribbon['expanded_cells'] == 0
            assert ribbon['cells'] == nominal_cells and ribbon['height'] == costs['gates']
            assert ribbon['width'] == costs['gates'] + costs['inputs']
            assert ribbon['palette_sha256'] == design['palette_sha256'] and ribbon['cross_transport_cases'] == 20
            assert ribbon['exact_cell_partition_t1'] and ribbon['all_literal_edge_interfaces_agree']
            counts['ribbon_verified'] += 1; physical_cells += nominal_cells
            if literal['status'] == 'VERIFIED':
                assert identifier == 'reflexivity' and literal['expanded_cells'] == nominal_cells <= 50000
                assert literal['circuit_sha256'] == ribbon['circuit_sha256'] and literal['certificate_sha256'] == ribbon['certificate_sha256']
                counts['literal_verified'] += 1; literal_cells += nominal_cells
            else:
                assert literal['status'] == 'UNKNOWN' and literal['reason'] == 'LITERAL_CELL_RESOURCE_BOUND' and nominal_cells > 50000
                counts['literal_resource_unknown'] += 1
            assert len(summary['mutants']) == 1
            mutant = summary['mutants'][0]
            assert mutant['kind'] == 'unlisted-rule' and mutant['circuit_accepts'] is False
            assert mutant['reference']['status'] == 'REJECTED' and mutant['reference']['reason'] == 'UNLISTED_RULE'
            counts['unlisted_rule_mutants_rejected'] += 1
        else:
            counts['rejected'] += 1; seen_rejections.add(identifier)
            assert identifier in expected_rejections and (raw['reason'], native['reason']) == expected_rejections[identifier]
            assert checks['literal'] is None and checks['ribbon'] is None and summary['mutants'] == []
        rows.append({'id': identifier, 'expected': expected, 'raw_status': raw['status'],
                     'raw_reason': raw['reason'], 'native_status': native['status'], 'native_reason': native['reason'],
                     'circuit_accepts': evaluation['circuit_accepts'],
                     'ribbon': None if checks['ribbon'] is None else checks['ribbon']['status'],
                     'literal': None if checks['literal'] is None else checks['literal']['status'],
                     'nominal_grid_cells': nominal_cells, 'mutants': len(summary['mutants'])})
    assert seen_rejections == set(expected_rejections)
    assert counts['accepted'] == 13 and counts['rejected'] == 4
    assert counts['ribbon_verified'] == counts['unlisted_rule_mutants_rejected'] == 13
    assert counts['literal_verified'] == 1 and counts['literal_resource_unknown'] == 12
    assert set(coverage) == set(RULES) and all(coverage[rule] > 0 for rule in RULES)
    assert len(refs) == 19
    receipt = {'schema': 'NK-qualification-passive-audit-v1', 'status': 'PASS',
               'counts': dict(counts), 'accepted_raw_rule_coverage': dict(coverage),
               'input_files': refs, 'cases': rows, 'recorded_source_pins_equal': True,
               'recorded_source_pin_count': len(design['source_pins']),
               'recorded_source_pins': design['source_pins'],
               'symbolically_certified_nominal_cells': physical_cells,
               'literal_cells_expanded_and_checked_as_recorded': literal_cells,
               'qualification_elapsed_seconds': completion['elapsed_seconds'],
               'native_peak_rss_as_recorded': completion['native_peak_rss'],
               'scope': 'Passive association/count/hash audit of exactly two qualification design/completion files and17 declared logical-evaluation JSON files. No scientific modules, Source bodies, circuits, gzip artifacts or research-mode files were read. No checker/compiler/search re-executed.',
               'limits': [
                   'Source stability is the equality of recorded design/completion pins, not a fresh Source-file rehash in this restricted audit.',
                   'Circuit evaluation and physical checks are existing receipts; gate-bit hashes were checked for format only, not recomputed from forbidden circuit/gzip files.',
                   'All13 positive ribbons have expanded_cells0. Their nominal area is symbolic certificate coverage; only reflexivity has a literal expanded-cell verification,14645cells. The other12 literal refusals remain UNKNOWN.',
                   'The13 unlisted-rule mutants have raw-checker rejection and circuit false receipts; no native human-AST mutant checker receipt is supplied or claimed.',
                   'No broad kernel completeness, physical-grid search or research-mode result admission follows from this qualification audit.']}
    output = ROOT/'review/qualification-passive-audit-v1.json'
    with output.open('xb') as stream:
        stream.write(wire(receipt))
    print(json.dumps({'receipt': {'path': str(output), 'bytes': len(output.read_bytes()),
                       'sha256': hashlib.sha256(output.read_bytes()).hexdigest()},
                      'counts': dict(counts), 'rule_coverage': dict(coverage),
                      'symbolic_cells': physical_cells, 'literal_cells': literal_cells}, sort_keys=True))


if __name__ == '__main__':
    main()
