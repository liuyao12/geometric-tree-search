"""Exhaustive v1/v2 equivalence over a complete tiny proof input space."""
import hashlib
import itertools
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'source'),str(ROOT/'reference')]
import raw_kernel_circuit_v1 as eager
import raw_kernel_circuit_v2 as lazy
import kernel_data_v1 as data
import fixed_palette_v1 as fp


def main():
    bounds=dict(nodes=3,variables=3,functions=0,predicates=0,axioms=0,lines=1,substitutions=0,arity=2)
    theory=dict(functions={},predicates={},axioms={},variables=['x','y','z'])
    target=['eq',['var','x'],['var','x']]
    pins,meta=data.build_problem(bounds,theory,target)
    a,am=eager.compile_kernel(bounds,pins);b,bm=lazy.compile_kernel(bounds,pins)
    assert a['inputs']==b['inputs']
    free=[i for i,v in enumerate(a['inputs']) if v['value'] is None]
    assert len(free)==10
    accepted=0;digest=hashlib.sha256()
    for row in itertools.product((0,1),repeat=len(free)):
        bits=[v['value'] if v['value'] is not None else 0 for v in a['inputs']]
        for i,v in zip(free,row):bits[i]=v
        aa,bb=fp.evaluate(a,bits)[1],fp.evaluate(b,bits)[1]
        assert aa==bb
        accepted+=aa;digest.update(bytes(row)+bytes([aa]))
    result={'status':'PASS_EXHAUSTIVE_TINY_INPUT_EQUIVALENCE','assignments':1024,'accepted':accepted,
            'eager_gates':len(a['gates']),'lazy_gates':len(b['gates']),'truth_table_sha256':digest.hexdigest(),
            'bounds':bounds,'pins':pins,'inputs_identical':True,
            'source_pins':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'source/raw_kernel_circuit_v1.py',ROOT/'source/raw_kernel_circuit_v2.py']},
            'scope':'Every free proof input assignment for one fully pinned tiny syntax problem. Other sizes need structural argument and independent semantic qualification; no universal runtime equivalence claim.'}
    (ROOT/'review/lazy-equivalence-v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','assignments','accepted','eager_gates','lazy_gates')}))


if __name__=='__main__':main()
