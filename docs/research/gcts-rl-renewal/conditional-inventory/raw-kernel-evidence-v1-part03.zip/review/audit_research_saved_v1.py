"""Passive current-study audit, reusing the earlier receipt-join approach.

Only JSON records, captured streams and Source/runtime bytes are read.
No scientific Source is imported or executed; no circuit/gzip is replayed.
"""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/liuyao/.codex/visualizations/2026/10/09/01a11e8d-0cf0-7ed2-8930-2aa7f4aab37b/gcts-fol-kernel-20261103-v1')
PA, GEO = 'raw-pa-add-successor-zero', 'raw-incidence-common-two-points'


def wire(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False) + '\n').encode('ascii')


def digest(value):
    return hashlib.sha256(wire(value)).hexdigest()


def same(a, b):
    return wire(a) == wire(b)


def main():
    reads, sources, cached = {}, {}, {}

    def body(path):
        path = Path(path)
        if path not in cached:
            assert path.is_file() and not path.is_symlink()
            data = path.read_bytes()
            cached[path] = data
            reads[str(path)] = {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        return cached[path]

    def pin(path):
        body(path)
        return reads[str(Path(path))]

    def load(path):
        return json.loads(body(path))

    def relative(name):
        return load(ROOT/name)

    def source_pins(design, completion):
        assert same(design['source_pins'], completion['source_pins'])
        for name, expected in design['source_pins'].items():
            assert name.startswith(('source/','reference/')) and '..' not in Path(name).parts
            actual = pin(ROOT/name)
            assert actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256']
            if name in sources:
                assert sources[name] == actual
            sources[name] = actual

    old_design = relative('research-design-v1.json')
    old_completion = relative('research-completion-v1.json')
    old_cases = {case['id']:case for case in old_design['cases']}
    old_q_design = relative('qualify-design-v1.json')
    old_q_complete = relative('qualify-completion-v1.json')
    old_q_audit = relative('review/qualification-passive-audit-v1.json')
    assert old_q_audit['status'] == 'PASS'
    q_design = relative('attempt-v2/qualify-design-v1.json')
    q_complete = relative('attempt-v2/qualify-completion-v1.json')
    assert q_complete['status'] == 'COMPLETED_CHECKED' and q_complete['cases'] == 17
    assert same(q_design['cases'], old_q_design['cases'])
    source_pins(q_design,q_complete)
    q_counts = Counter()
    for old, current in zip(old_q_complete['summaries'],q_complete['summaries']):
        assert old['id'] == current['id'] and old['expected'] is current['expected']
        for key in ('raw_kernel','native_FOL'):
            assert same(old['checks'][key],current['checks'][key])
        assert old['checks']['circuit_accepts'] is current['checks']['circuit_accepts'] is current['expected']
        assert (old['checks']['literal'] or {}).get('status') == (current['checks']['literal'] or {}).get('status')
        q_counts['accept' if current['expected'] else 'reject'] += 1
    assert len(q_complete['summaries']) == 17 and q_counts == {'accept':13,'reject':4}
    d2 = relative('attempt-v2/research-design-v1.json')
    c2 = relative('attempt-v2/research-completion-v1.json')
    d3 = relative('attempt-v3/research-design-v1.json')
    c3 = relative('attempt-v3/research-completion-v1.json')
    assert c2['status'] == 'COMPLETED_WITH_EXPLICIT_UNKNOWNS' and c2['cases'] == 2
    assert c3['status'] == 'COMPLETED_CHECKED' and c3['cases'] == 1
    source_pins(d2,c2); source_pins(d3,c3)
    assert same(d2['resource_caps'],d3['resource_caps'])
    assert d2['gate_cap'] == 1000000 and d3['gate_cap'] == 2000000
    assert d2['palette_sha256'] == d3['palette_sha256'] == q_design['palette_sha256']
    assert [x['id'] for x in d2['cases']] == [PA,GEO] and [x['id'] for x in d3['cases']] == [PA]
    for case in d2['cases'] + d3['cases']:
        assert same(case,old_cases[case['id']]) and case['kind'] == 'research-reused' and case['expected'] is True
        assert len(case['proof']) == 7
        assert {key:case['bounds'][key] for key in ('nodes','variables','lines','substitutions')} == {'nodes':64,'variables':3,'lines':7,'substitutions':2}
    observed = []
    for directory, mode, design in (
            ('attempt-v2/observation-qualify-v2','qualify',q_design),
            ('attempt-v2/observation-research-v2','research',d2),
            ('attempt-v3/observation-research-v3','research',d3)):
        before = relative(directory+'/before.json'); after = relative(directory+'/completion.json')
        assert all(same(value,after[key]) for key,value in before.items())
        assert before['mode'] == mode and before['retry'] is False
        assert after['native_exit'] == 0 and after['terminated_on_wall_limit'] is False
        assert same(after['source'],after['source_after']) and same(after['runtime'],after['runtime_after'])
        for key in ('source','runtime'):
            assert pin(Path(after[key]['path'])) == after[key]
        source_name = str(Path(after['source']['path']).relative_to(ROOT))
        assert {key:after['source'][key] for key in ('bytes','sha256')} == design['source_pins'][source_name]
        for key in ('stdout','stderr'):
            assert pin(Path(after[key]['path'])) == after[key]
        assert body(Path(after['stderr']['path'])) == b''
        observed.append({'before':pin(ROOT/directory/'before.json'),'completion':pin(ROOT/directory/'completion.json'),
                         'native_exit':0,'elapsed_seconds':after['elapsed_seconds'],'peak_child_rss':after['peak_child_rss']})
    cap = relative('reference/resource-extension-source-review-v1.json')
    assert cap['status'] == 'PASS_STATIC_PREFIX_EQUIVALENCE'
    for entry in cap['sources']:
        actual = pin(ROOT/entry['path']); assert actual['sha256'] == entry['sha256']
        if 'bytes' in entry:
            assert actual['bytes'] == entry['bytes']
    inherited = cap['inherits']; assert pin(ROOT/inherited['path'])['sha256'] == inherited['sha256']
    ribbon2, ribbon3 = body(ROOT/'reference/ribbon_checker_v2.py'), body(ROOT/'reference/ribbon_checker_v3.py')
    assert ribbon3.replace(b'FP-INDEPENDENT-RIBBON-CHECKER-v3-NK',b'FP-INDEPENDENT-RIBBON-CHECKER-v2-NK').replace(
        b'MAX_INPUTS, MAX_GATES, MAX_WIDTH = 1000000, 2000000, 3000000',
        b'MAX_INPUTS, MAX_GATES, MAX_WIDTH = 1000000, 1000000, 2000000') == ribbon2
    selected, rules = [], Counter()
    for attempt, design, completion, identifier, expected_gates in (
            ('attempt-v2',d2,c2,GEO,573693),('attempt-v3',d3,c3,PA,1344049)):
        summary = next(row for row in completion['summaries'] if row['id'] == identifier)
        case = next(row for row in design['cases'] if row['id'] == identifier)
        evaluation_path = ROOT/attempt/'actual'/(identifier+'-logical-evaluation.json')
        evaluation = load(evaluation_path); checks = summary['checks']
        assert summary['expected'] is evaluation['expected'] is evaluation['circuit_accepts'] is checks['circuit_accepts'] is True
        for key in ('raw_kernel','native_FOL'):
            assert same(evaluation[key],checks[key]) and checks[key]['status'] == 'VERIFIED'
            assert checks[key]['checked_lines'] == 7
        cert, raw = evaluation['raw_certificate'], checks['raw_kernel']
        assert digest(cert) == raw['certificate_sha256'] and same(raw['bounds'],case['bounds'])
        assert len(cert['nodes']) == raw['checked_nodes'] == 64
        assert len(cert['proof']) == 7 and len(cert['substitutions']) == raw['checked_substitutions'] == 2 and raw['closed_Gamma'] is True
        assert len(evaluation['input_bits']) == summary['costs']['inputs']
        assert evaluation['input_bits'][:2] == [0,1] and all(type(bit) is int and bit in (0,1) for bit in evaluation['input_bits'])
        ribbon, literal = checks['ribbon'], checks['literal']
        assert ribbon['status'] == 'VERIFIED' and ribbon['expanded_cells'] == 0
        assert literal['status'] == 'UNKNOWN' and literal['reason'] == 'LITERAL_CELL_RESOURCE_BOUND'
        assert summary['costs']['gates'] == ribbon['height'] == expected_gates
        assert ribbon['width'] == expected_gates + summary['costs']['inputs']
        assert ribbon['cells'] == ribbon['width'] * ribbon['height'] == summary['costs']['expanded_cells']
        assert ribbon['palette_sha256'] == design['palette_sha256'] and ribbon['cross_transport_cases'] == 20
        assert ribbon['exact_cell_partition_t1'] and ribbon['all_literal_edge_interfaces_agree']
        assert {m['kind'] for m in summary['mutants']} == {'unlisted-rule','self-reference'} and len(summary['mutants']) == 2
        for mutant in summary['mutants']:
            assert mutant['circuit_accepts'] is False and mutant['reference']['status'] == 'REJECTED'
            assert mutant['reference']['reason'] == ('UNLISTED_RULE' if mutant['kind']=='unlisted-rule' else 'MP_STRICT_PRIOR_REFERENCES')
        rules.update(raw['rule_counts'])
        selected.append({'attempt':attempt,'id':identifier,'case_sha256':digest(case),'bounds':case['bounds'],
                         'logical_evaluation':pin(evaluation_path),'raw_certificate_sha256':raw['certificate_sha256'],
                         'circuit_sha256':ribbon['circuit_sha256'],'ribbon_certificate_sha256':ribbon['certificate_sha256'],
                         'native_raw_circuit_ribbon':'VERIFIED','literal':'UNKNOWN','proof_lines':7,'gates':expected_gates,
                         'inputs':summary['costs']['inputs'],'symbolic_cells':ribbon['cells'],'expanded_cells':0,'mutants_rejected':2})
    attempts, earlier_unknowns = [], []
    for attempt, completion in (('original-v1',old_completion),('attempt-v2',c2),('attempt-v3',c3)):
        for summary in completion['summaries']:
            status = summary.get('status','VERIFIED' if summary.get('checks',{}).get('raw_kernel',{}).get('status')=='VERIFIED' else 'OTHER')
            row = {'attempt':attempt,'id':summary['id'],'status':status,'reason':summary.get('reason')}
            attempts.append(row)
            if status == 'UNKNOWN_COMPILATION_BUDGET':
                assert summary['id'] == PA and summary['reason'] == 'NAND_GATE_CAP'
                earlier_unknowns.append(row)
    assert len(attempts) == 5 and len(earlier_unknowns) == 2
    old_utility = pin(ROOT/'review/audit_qualification_saved_v1.py')
    utility = pin(Path(__file__).resolve())
    receipt = {'schema':'NK-current-research-passive-admission-audit-v1','status':'PASS',
               'utility':utility,'reuses_passive_utility':old_utility,'selected_proofs':selected,
               'counts':{'selected_unique_proofs':2,'selected_proof_lines':14,'selected_raw_native_circuit_ribbon_verified':2,
                         'selected_literal_unknown':2,'selected_mutants_rejected':4,'research_attempt_outcomes_preserved':5,
                         'earlier_PA_compilation_unknowns_retained':2,'current_v2_qualification_accept':13,'current_v2_qualification_reject':4,
                         'observer_native_zero_completions':3,'current_source_bodies_hashed':len(sources)},
               'selected_rule_counts':dict(rules),'attempt_outcomes':attempts,'earlier_unknowns':earlier_unknowns,
               'v2_qualification_same_cases_expected_and_logical_results_as_v1':True,
               'source_body_refs':sources,'observer_guards':observed,
               'resource_extension_review':pin(ROOT/'reference/resource-extension-source-review-v1.json'),
               'exact_ribbon_cap_only_reverse_body_equality':True,
               'input_record_and_body_refs':sorted(reads.values(),key=lambda row:row['path']),
               'scope':'Passive saved-record/hash/custody joins only; no scientific Source import/execution, compiler/checker call, proof search, circuit evaluation or gzip artifact replay.',
               'limits':['Both seven-line derivations are reused selected proof certificates, not discoveries by this raw-kernel compiler.',
                         'The earlier1M PA refusals remain UNKNOWN; the separate2M resource-extension success does not replace or narrow those records.',
                         'Both physical checks are symbolic ribbon verification with expanded_cells0; both literal refusals remain UNKNOWN. Nominal grid area is not searched or expanded work.',
                         'Source/runtime bytes and captured stream bodies were hashed. The large circuit/ribbon gzip artifacts and stored gate-bit digest were not replayed/recomputed in this record-focused audit.',
                         'Observer records establish recorded native exits0 and before/after runner/runtime guards. No extra process-group/reap/pipe-EOF claims beyond their recorded schema are introduced.',
                         'This evidence audit supports Root admission; it is not a new semantic proof of checker/compiler correctness or an independent theorem search.']}
    output = ROOT/'review/research-passive-admission-v1.json'
    with output.open('xb') as stream:
        stream.write(wire(receipt))
    data = output.read_bytes()
    print(json.dumps({'receipt':{'path':str(output),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},
                      'counts':receipt['counts'],'selected':[(row['id'],row['gates']) for row in selected]},sort_keys=True))


if __name__ == '__main__':
    main()
