"""Check raw first-order proofs inside NAND and the fixed100 Wang palette.

Qualification proofs are explicit unit fixtures; two research witnesses are
reused from previously published automatic GCTS search. No new search/RL run.
Every kernel circuit and full problem binding is frozen before its witness is
encoded. All failures, budgets and caps remain in the evidence.
"""
import copy
import gzip
import hashlib
import json
from pathlib import Path
import resource
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'attempt-v2'
sys.path[:0]=[str(ROOT/'source'),str(ROOT/'reference')]
import fixed_palette_v1 as fp
import raw_kernel_circuit_v2 as kernel
import kernel_data_v1 as data
import raw_fol_checker_v1 as independent
import independent_fol_checker_v1 as native
import ribbon_checker_v2 as physical

CHECK=dict(max_operations=10000000,max_depth=256,max_proof_lines=4096)


def save(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    raw=fp.canonical(value)
    if name.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    with path.open('xb') as f:f.write(raw)
    return {'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def pins():
    return {str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
            for directory in ('source','reference') for p in sorted((ROOT/directory).glob('*.py'))}


def fixtures():
    var=lambda x:['var',x]; fun=lambda x,*a:['fun',x,list(a)]; pred=lambda x,*a:['pred',x,list(a)]
    imp=lambda a,b:['imp',a,b]; neg=lambda a:['not',a]; allx=lambda x,a:['all',x,a];eq=lambda a,b:['eq',a,b]
    x,y,z=map(var,('x','y','z'));p,q,r=map(pred,('p','q','r'))
    def case(name,goal,proof,theory=None,N=16,K=0,expected=True):
        th=theory or {'functions':{},'predicates':{'p':0,'q':0,'r':0},'axioms':{}}
        th={**th,'variables':['x','y','z']}
        return dict(id=name,kind='qualification',theory=th,goal=goal,proof=proof,expected=expected,
                    bounds=dict(nodes=N,variables=3,functions=len(th['functions']),predicates=len(th['predicates']),
                                axioms=len(th['axioms']),lines=len(proof),substitutions=K,arity=2))
    unary={'functions':{'f':1},'predicates':{'P':1},'axioms':{}}
    P=lambda t:pred('P',t)
    dist=imp(allx('x',imp(p,P(x))),imp(p,allx('x',P(x))))
    eqs=imp(eq(x,y),imp(P(x),P(y)))
    ui=imp(allx('x',P(x)),P(fun('f',y)))
    result=[
        case('axiom',p,[dict(rule='axiom',name='given',formula=p)],{'functions':{},'predicates':{'p':0},'axioms':{'given':p}},N=6),
        case('modus-ponens',q,[dict(rule='axiom',name='p',formula=p),dict(rule='axiom',name='pq',formula=imp(p,q)),dict(rule='mp',formula=q,antecedent=0,implication=1)],{'functions':{},'predicates':{'p':0,'q':0},'axioms':{'p':p,'pq':imp(p,q)}},N=8),
        case('generalization',allx('x',eq(x,x)),[dict(rule='refl',formula=eq(x,x)),dict(rule='generalize',formula=allx('x',eq(x,x)),source=0,variable='x')],{'functions':{},'predicates':{},'axioms':{}},N=8),
        case('universal-instantiation',ui,[dict(rule='instantiate',formula=ui,universal=allx('x',P(x)),term=fun('f',y))],unary,N=16,K=1),
        case('reflexivity',eq(x,x),[dict(rule='refl',formula=eq(x,x))],{'functions':{},'predicates':{},'axioms':{}},N=3),
        case('quantifier-distribution',dist,[dict(rule='distribute',formula=dist,variable='x',antecedent=p,consequent=P(x))],{'functions':{},'predicates':{'p':0,'P':1},'axioms':{}},N=16),
        case('equality-substitution',eqs,[dict(rule='eq_subst',formula=eqs,variable='z',template=P(z),left=x,right=y)],unary,N=16,K=2),
        case('propositional-AX1',imp(p,imp(q,p)),[dict(rule='ax1',formula=imp(p,imp(q,p)))],N=12),
        case('propositional-AX2',imp(imp(p,imp(q,r)),imp(imp(p,q),imp(p,r))),[dict(rule='ax2',formula=imp(imp(p,imp(q,r)),imp(imp(p,q),imp(p,r))))],N=16),
        case('propositional-AX3',imp(imp(neg(q),neg(p)),imp(p,q)),[dict(rule='ax3',formula=imp(imp(neg(q),neg(p)),imp(p,q)))],N=16),
        case('bottom-is-false',neg(['bot']),[dict(rule='bot_false',formula=neg(['bot']))],N=6)]
    bad_capture=imp(allx('x',allx('y',P(x))),allx('y',P(y)))
    harmless=imp(allx('x',allx('y',P(y))),allx('y',P(y)))
    shadow=imp(allx('x',allx('x',P(x))),allx('x',P(x)))
    baddist=imp(allx('x',imp(P(x),P(y))),imp(P(x),allx('x',P(y))))
    result.extend([
        case('reject-variable-capture',bad_capture,[dict(rule='instantiate',formula=bad_capture,universal=allx('x',allx('y',P(x))),term=y)],unary,N=16,K=1,expected=False),
        case('allow-irrelevant-binder-clash',harmless,[dict(rule='instantiate',formula=harmless,universal=allx('x',allx('y',P(y))),term=y)],unary,N=16,K=1),
        case('bound-variable-stops-substitution',shadow,[dict(rule='instantiate',formula=shadow,universal=allx('x',allx('x',P(x))),term=y)],unary,N=16,K=1),
        case('reject-open-Gamma',allx('x',P(x)),[dict(rule='axiom',name='given',formula=P(x)),dict(rule='generalize',formula=allx('x',P(x)),source=0,variable='x')],{'functions':{},'predicates':{'P':1},'axioms':{'given':P(x)}},N=12,expected=False),
        case('reject-distribution-freshness',baddist,[dict(rule='distribute',formula=baddist,variable='x',antecedent=P(x),consequent=P(y))],unary,N=16,expected=False),
        case('reject-changed-axiom',p,[dict(rule='axiom',name='given',formula=p)],{'functions':{},'predicates':{'p':0,'q':0},'axioms':{'given':q}},N=8,expected=False)])
    return result


def native_form(case):
    theory={k:v for k,v in case['theory'].items() if k!='variables'}
    proof=[]
    for original in case['proof']:
        line=copy.deepcopy(original)
        if line['rule'] in ('ax1','ax2','ax3','bot_false'):line['rule']='tautology'
        proof.append(line)
    return native.check(theory,proof,case['goal'],CHECK)


def one_case(case,full_tiling=True):
    start=time.perf_counter();name=case['id'];bounds=case['bounds']
    fixed,problem=data.build_problem(bounds,case['theory'],case['goal'])
    t=time.perf_counter();circuit,metadata=kernel.compile_kernel(bounds,fixed)
    compile_seconds=time.perf_counter()-t
    frozen=save('frozen/'+name+'.json.gz',{'bounds':bounds,'problem':problem,'circuit':circuit,'metadata':metadata,
                'order':'Circuit frozen before this witness was encoded. Previously published research proofs are reused data, not a new search.'})
    cert=data.build_witness(bounds,problem,case['proof'])
    reference=independent.check(bounds,cert)
    inputs=data.encode_bits(bounds,cert,metadata)
    t=time.perf_counter();gate_bits,accept=fp.evaluate(circuit,inputs);evaluation_seconds=time.perf_counter()-t
    host=native_form(case)
    save('actual/'+name+'-logical-evaluation.json',{'raw_certificate':cert,'raw_kernel':reference,'native_FOL':host,
         'input_bits':inputs,'gate_bits_sha256':fp.digest(gate_bits),'circuit_accepts':bool(accept),'expected':case['expected']})
    assert accept==int(case['expected']), (name,'CIRCUIT',accept,reference)
    assert (reference['status']=='VERIFIED')==case['expected'],(name,reference)
    assert (host['status']=='VERIFIED')==case['expected'],(name,host)
    tiling=None;symbolic=literal=None
    if accept and full_tiling:
        t=time.perf_counter();tiling=fp.certificate(circuit,inputs)
        symbolic=physical.verify(circuit,tiling,fp.palette())
        literal=physical.verify_literal(circuit,tiling,fp.palette())
        assert symbolic['status']=='VERIFIED',symbolic
        assert literal['status'] in ('VERIFIED','UNKNOWN')
        verification_seconds=time.perf_counter()-t
    else:verification_seconds=None
    record={'case':case,'bounds':bounds,'problem':problem,'raw_certificate':cert,'frozen':frozen,
            'checks':{'raw_kernel':reference,'native_FOL':host,'circuit_accepts':bool(accept),
                      'ribbon':symbolic,'literal':literal},
            'costs':{'compile_seconds':compile_seconds,'evaluation_seconds':evaluation_seconds,'physical_seconds':verification_seconds,
                     'total_seconds':time.perf_counter()-start,'inputs':len(inputs),'gates':len(gate_bits),
                     'expanded_cells':(len(inputs)+len(gate_bits))*len(gate_bits)}}
    raw=save('actual/'+name+'.json.gz',{'record':record,'circuit':circuit,'input_bits':inputs,'gate_bits':gate_bits,'tiling':tiling,'metadata':metadata})
    print(json.dumps({'case':name,'expected':case['expected'],'accept':bool(accept),'raw_kernel':reference['status'],
                      'gates':len(gate_bits),'seconds':record['costs']['total_seconds']}),flush=True)
    # A legal formula cannot be relabeled as an arbitrary other rule.
    mutants=[]
    if accept:
        corrupted=copy.deepcopy(cert);corrupted['proof'][-1]['rule']=15
        bad_bits=data.encode_bits(bounds,corrupted,metadata)
        bad=independent.check(bounds,corrupted)
        assert fp.evaluate(circuit,bad_bits)[1]==0 and bad['status']=='REJECTED'
        mutants.append({'kind':'unlisted-rule','reference':bad,'circuit_accepts':False})
        if case['kind']=='research-reused':
            i=next(j for j,p in enumerate(corrupted['proof']) if p['rule'] in (1,2))
            corrupted=copy.deepcopy(cert);corrupted['proof'][i]['ref0']=i
            bad=independent.check(bounds,corrupted)
            assert bad['status']=='REJECTED' and fp.evaluate(circuit,data.encode_bits(bounds,corrupted,metadata))[1]==0
            mutants.append({'kind':'self-reference','reference':bad,'circuit_accepts':False})
    summary={'id':name,'kind':case['kind'],'expected':case['expected'],'checks':record['checks'],'costs':record['costs'],
             'mutants':mutants,'raw':raw,'bounds':bounds}
    if accept:
        summary['reader']={'id':name,'label':case.get('label',name),'kind':case['kind'],'circuit':circuit,
                           'input_bits':inputs,'gate_bits':gate_bits,'checks':{'status':'VERIFIED',**record['checks']},
                           'metrics':record['costs'],'groups':metadata['groups'],
                           'proof':{'theory':case['theory'],'goal':case['goal'],'lines':case['proof'],
                                    'original_lines':case['proof'],'padding':0}}
    return summary


def research_cases():
    path=ROOT/'upstream/fixed-palette-results-v1.json'
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='638fc259895a638ca4831f3cb9fbbef4cd6e49e28daa8ad7baa370a0819cc66f'
    previous=json.loads(path.read_text());result=[]
    for entry in previous['cases']:
        if entry['id'] not in ('pa-add-successor-zero','incidence-common-two-points'):continue
        theory=copy.deepcopy(entry['proof']['theory']);theory['variables']=['x','y','z'] if entry['kind']=='arithmetic' else ['l','m','z']
        proof=entry['proof']['original_lines']
        result.append({'id':'raw-'+entry['id'],'label':entry['label'],'kind':'research-reused','theory':theory,
                       'goal':entry['proof']['goal'],'proof':proof,'expected':True,
                       'bounds':dict(nodes=64,variables=3,functions=len(theory['functions']),predicates=len(theory['predicates']),
                                     axioms=len(theory['axioms']),lines=len(proof),substitutions=2,arity=2),
                       'provenance':'Previously published automatically found GCTS proof; no new proof search or RL in this kernel milestone.'})
    assert len(result)==2
    return result


def main():
    start=time.perf_counter();source=pins();assert len(sys.argv)==2
    mode=sys.argv[1]
    selected=fixtures() if mode=='qualify' else research_cases() if mode=='research' else []
    assert selected
    save(mode+'-design-v1.json',{'source_pins':source,'cases':selected,
        'resource_caps':kernel.CAPS,'gate_cap':kernel.GATE_CAP,'palette_sha256':fp.digest(fp.palette()),
        'scope':'Generic raw kernel with partial problem pins, unknown proof syntax and rule fields; no external producer admission catalogue.'})
    summaries=[]
    for case in selected:
        try:
            summaries.append(one_case(case))
        except kernel.ResourceLimit as error:
            summaries.append({'id':case['id'],'status':'UNKNOWN_COMPILATION_BUDGET','reason':str(error)})
            save('actual/'+case['id']+'-unknown.json',summaries[-1]);print(json.dumps(summaries[-1]),flush=True)
    assert source==pins()
    projection={'schema':'NK-raw-kernel-results-v1','palette':fp.palette(),
                'cases':[s.pop('reader') for s in summaries if 'reader' in s],
                'summary':summaries,'source_pins':source,'elapsed_seconds':time.perf_counter()-start,
                'native_peak_rss':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'platform':sys.platform}
    save(mode+'-results-v1.json.gz',projection)
    save(mode+'-completion-v1.json',{'status':'COMPLETED_WITH_EXPLICIT_UNKNOWNS' if any(s.get('status') for s in summaries) else 'COMPLETED_CHECKED',
                                   'source_pins':source,'cases':len(summaries),'elapsed_seconds':projection['elapsed_seconds'],
                                   'summaries':summaries,'native_peak_rss':projection['native_peak_rss']})
    print(json.dumps({'mode':mode,'completed':len(summaries),'seconds':projection['elapsed_seconds']}),flush=True)


if __name__=='__main__':main()
