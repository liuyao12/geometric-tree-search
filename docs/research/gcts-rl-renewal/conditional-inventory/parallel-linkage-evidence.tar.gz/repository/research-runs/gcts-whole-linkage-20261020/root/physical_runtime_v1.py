"""UNEXECUTED Source: all thirteen fixed-VM opcodes on the shared tape.

This module has no imports or top-level subject calls. Construction, imports,
lowering, simulation and scientific tests require a fresh reviewed Root once.
Dependencies are explicit, frozen Source owners, not semantic callbacks in delta.
The program, operands, registers and call stack are always physical tape data.

Precondition: program intake has built wholeMeta=(constants,functions) in F6;
value BOOT has left the request reference in V11, R4/FRAMES5/S14/O15 empty
colon records, and PC7/D8 canonical zero words. HEAP is canonical/topological.
Every immutable metadata list is proper; all indices and forward calls have
been checked by intake. Runtime cannot replace these with a host predicate.

The output is construction entries, not a complete VM table or a Wang proof
system. Layout/public-boundary initialization, compiler correspondence, full
heap embedding, costs, fit, qualification and theorem search remain open.
"""

VERSION='whole-physical-runtime-v1'
R=4
FRAMES=5
F=6
PC=7
D=8
L=9
RIGHT=10
V=11
C=12
T=13
S=14
O=15
NIL_BITS='000000001'


def _pop(m,h,destination,out,invalid,name):
    """Pop one S word; allow a retained CALL bar in the untouched prefix.

    Derived explicitly from value BOOT's record pop. Three changed domains
    admit a bar: seek, backward word boundary, and prefix restoration. A bar
    cannot itself be popped; the CALL loop tests that boundary separately.
    """
    seek=m.state(name+'/seek')
    semicolon=m.state(name+'/semicolon')
    back=m.state(name+'/back')
    copy=m.state(name+'/copy')
    restore=m.state(name+'/restore')
    finish=m.rewind(destination,out,name+'/result')
    h._put(m,restore,S,{'0':(restore,'0',1),'1':(restore,'1',1),
        ';':(restore,';',1),'|':(restore,'|',1),'B':(finish,':',0)},invalid)
    restore_start=m.rewind(S,restore,name+'/restore-start')
    choices={':':(restore_start,'B',0)}
    for bit in ('0','1'):
        put=h._row(m,destination,{'B':(copy,bit,1)},invalid,name+'/put'+bit)
        choices[bit]=(put,'B',1)
    h._put(m,copy,S,choices,invalid)
    h._put(m,back,S,{'0':(back,'0',-1),'1':(back,'1',-1),
        ';':(copy,';',1),'|':(copy,'|',1),'^':(copy,'^',1)},invalid)
    h._put(m,semicolon,S,{';':(back,':',-1)},invalid)
    choices={':':(semicolon,'B',-1)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(seek,symbol,1)
    h._put(m,seek,S,choices,invalid)
    begin=m.rewind(S,seek,name+'/begin')
    return m.clear_word(destination,begin,name+'/clear')


def nat_list_to_word(m,h,out,invalid,name):
    """V proper nonempty LSB bit list -> canonical T word, no host decoding.

    Clobbers V/L/RIGHT/C/T. Preserves R/FRAMES/F/PC/D/S/O payloads. The
    nil atom is 256; list heads must be exactly atoms 0 or 1. Zero is one
    zero bit and every longer accepted word has final bit one.
    """
    first=m.state(name+'/first')
    zero=m.state(name+'/single-zero')
    lastzero=m.state(name+'/multiple-last-zero')
    lastone=m.state(name+'/last-one')
    done=m.rewind(T,out,name+'/word-ready')
    for tag,entry,empty,nextzero in (
        ('first',first,invalid,zero),
        ('single-zero',zero,done,lastzero),
        ('multiple-zero',lastzero,invalid,lastzero),
        ('last-one',lastone,done,lastzero)):
        # The consumed head selects the *next* finite-control canonicality tag.
        next0=m.copy_word(RIGHT,V,nextzero,name+'/'+tag+'/tail0')
        next1=m.copy_word(RIGHT,V,lastone,name+'/'+tag+'/tail1')
        write0=h._row(m,T,{'B':(next0,'0',1)},invalid,name+'/'+tag+'/write0')
        write1=h._row(m,T,{'B':(next1,'1',1)},invalid,name+'/'+tag+'/write1')
        bit1=h._word_is(m,L,'1',write1,invalid,invalid,name+'/'+tag+'/head1')
        head=h._word_is(m,L,'0',write0,bit1,invalid,name+'/'+tag+'/head0')
        node=h.heap_lookup(m,head,invalid,name+'/'+tag+'/node')
        nil=h._word_is(m,V,NIL_BITS,empty,node,invalid,name+'/'+tag+'/nil')
        h._put(m,entry,V,{'0':(nil,'0',0),'1':(nil,'1',0)},invalid)
    return m.clear_word(T,first,name+'/clear')


def _capture(m,h,count,out,invalid,name):
    """Capture a fixed Source count of nat operands from V into S records.

    Afterward V is the untouched operand-list suffix. count is an opcode's
    fixed arity, never the runtime operand count. D is temporary tail storage.
    """
    nxt=out
    for j in range(count-1,-1,-1):
        tag=name+'/'+str(j)
        tail=m.copy_word(D,V,nxt,tag+'/tail')
        append=h._push_word_to(m,S,T,tail,invalid,tag+'/append')
        decode=nat_list_to_word(m,h,append,invalid,tag+'/nat')
        head=m.copy_word(L,V,decode,tag+'/head')
        keep=m.copy_word(RIGHT,D,head,tag+'/keep-tail')
        nxt=h.heap_lookup(m,keep,invalid,tag+'/list-node')
    return nxt


def _commit_vector(m,h,out,invalid,name):
    """Copy the COMPLETE S record vector to R, then clear S to empty colon.

    No register_write occurs while S owns CALL arguments or operand records.
    R may be partially overwritten on failure; failure is nonaccepting, and
    this makes no GCTS rollback or atomic-failure claim.
    """
    done=m.rewind(R,out,name+'/done')
    clean=h._clear_records(m,S,done,invalid,name+'/clear-buffer')
    copy=m.state(name+'/copy')
    close=h._row(m,R,{'B':(clean,':',0)},invalid,name+'/close')
    choices={':':(close,':',0)}
    for symbol in ('0','1',';'):
        put=h._row(m,R,{'B':(copy,symbol,1)},invalid,name+'/put'+symbol)
        choices[symbol]=(put,symbol,1)
    h._put(m,copy,S,choices,invalid)
    start=m.rewind(S,copy,name+'/source')
    blank=h._records_to_empty_word(m,R,start,invalid,name+'/erase-empty-colon')
    return h._clear_records(m,R,blank,invalid,name+'/erase-old')


def _pad_vector(m,h,p,out,invalid,name):
    """Append T remaining nil records to S; T counts down on tape."""
    loop=m.state(name+'/loop')
    down=p.decrement_word(m,h,T,loop,invalid,name+'/down')
    append=h._push_word_to(m,S,V,down,invalid,name+'/append-nil')
    nil=h._constant(m,V,NIL_BITS,append,invalid,name+'/nil')
    test=h._word_is(m,T,'0',out,nil,invalid,name+'/zero')
    h._put(m,loop,T,{'0':(test,'0',0),'1':(test,'1',0)},invalid)
    return loop


def _argument_vector(m,h,p,out,invalid,name):
    """V immutable proper arg-value list, T nregs -> COMPLETE S vector.

    All argument register reads have finished. Metadata validation supplies
    exact target arity and arg count. This loop additionally rejects more
    actual arguments than registers. Preserve every repeated argument/order.
    """
    loop=m.state(name+'/loop')
    pad=_pad_vector(m,h,p,out,invalid,name+'/padding')
    tail=m.copy_word(RIGHT,V,loop,name+'/tail')
    down=p.decrement_word(m,h,T,tail,invalid,name+'/down')
    append=h._push_word_to(m,S,L,down,invalid,name+'/append')
    node=h.heap_lookup(m,append,invalid,name+'/node')
    room=h._word_is(m,T,'0',invalid,node,invalid,name+'/room')
    test=h._word_is(m,V,NIL_BITS,pad,room,invalid,name+'/nil')
    h._put(m,loop,V,{'0':(test,'0',0),'1':(test,'1',0)},invalid)
    return loop


def _nregs(m,h,out,invalid,name):
    """F FnMeta -> T nregs, preserving the full register/argument cache."""
    decode=nat_list_to_word(m,h,out,invalid,name+'/nat')
    head=m.copy_word(L,V,decode,name+'/nregs')
    last=h.heap_lookup(m,head,invalid,name+'/register-code')
    rest2=m.copy_word(RIGHT,V,last,name+'/rest2')
    middle=h.heap_lookup(m,rest2,invalid,name+'/arity-rest')
    rest=m.copy_word(RIGHT,V,middle,name+'/rest')
    first=h.heap_lookup(m,rest,invalid,name+'/name-rest')
    return m.copy_word(F,V,first,name+'/function')


def _functions_index(m,h,p,out,invalid,name):
    select=p.list_index(m,h,out,invalid,name+'/index')
    functions=m.copy_word(RIGHT,V,select,name+'/functions')
    node=h.heap_lookup(m,functions,invalid,name+'/whole')
    return m.copy_word(O,V,node,name+'/root')


def _ordinary(m,h,count,body,invalid,name):
    exact=h._word_is(m,V,NIL_BITS,body,invalid,invalid,name+'/exact-operands')
    capture=_capture(m,h,count,exact,invalid,name+'/capture')
    return m.copy_word(RIGHT,V,capture,name+'/operands')


def _unary(m,h,r,body,invalid,name):
    destination=_pop(m,h,D,body,invalid,name+'/destination')
    read=r.register_read(m,destination,invalid,name+'/read')
    return _pop(m,h,D,read,invalid,name+'/source')


def _binary(m,h,r,body,invalid,name):
    destination=_pop(m,h,D,body,invalid,name+'/destination')
    keep_left=m.copy_word(V,L,destination,name+'/left')
    read_left=r.register_read(m,keep_left,invalid,name+'/read-left')
    source_left=_pop(m,h,D,read_left,invalid,name+'/source-left')
    keep_right=m.copy_word(V,RIGHT,source_left,name+'/right')
    read_right=r.register_read(m,keep_right,invalid,name+'/read-right')
    return _pop(m,h,D,read_right,invalid,name+'/source-right')


def _call(m,h,p,r,f,fetch,invalid,name):
    """Full caller capture, immutable argument list, frame save, callee commit."""
    pc0=h._constant(m,PC,'0',fetch,invalid,name+'/pc0')
    commit=_commit_vector(m,h,pc0,invalid,name+'/commit-callee')
    vector=_argument_vector(m,h,p,commit,invalid,name+'/callee-vector')
    args=_pop(m,h,V,vector,invalid,name+'/restore-args')
    size=_nregs(m,h,args,invalid,name+'/callee-size')
    keep_args=h._push_word_to(m,S,V,size,invalid,name+'/keep-args')
    callee=m.copy_word(T,F,keep_args,name+'/callee')
    save=f.frame_push(m,callee,invalid,name+'/save-caller')
    destination=_pop(m,h,D,save,invalid,name+'/destination')
    function=_pop(m,h,T,destination,invalid,name+'/function')

    # Reverse-pop the copied argument values and prepend into canonical HEAP.
    # Thus all caller reads finish before R is erased, even for aliased args.
    collect=m.state(name+'/collect')
    keep_list=m.copy_word(V,RIGHT,collect,name+'/keep-list')
    cons=h.canonical_cons(m,keep_list,invalid,name+'/argument-cons')
    pop_arg=_pop(m,h,L,cons,invalid,name+'/pop-argument')
    complete=m.copy_word(RIGHT,V,function,name+'/complete-arguments')
    erase_colon=h._row(m,S,{':':(complete,'B',0)},invalid,name+'/erase-old-colon')
    before=h._row(m,S,{';':(pop_arg,';',0),'|':(erase_colon,':',1)},invalid,name+'/before-colon')
    scan=m.state(name+'/scan-arguments')
    choices={':':(before,':',-1)}
    for symbol in ('0','1',';','|'):
        choices[symbol]=(scan,symbol,1)
    h._put(m,scan,S,choices,invalid)
    begin=m.rewind(S,scan,name+'/scan-start')
    h._put(m,collect,S,{'0':(begin,'0',0),'1':(begin,'1',0),'|':(begin,'|',0),':':(begin,':',0)},invalid)
    initial_list=h._constant(m,RIGHT,NIL_BITS,collect,invalid,name+'/empty-list')

    loop=m.state(name+'/read-all-caller-arguments')
    next_arg=m.copy_word(L,V,loop,name+'/next-argument')
    append=h._push_word_to(m,S,V,next_arg,invalid,name+'/append-argument-value')
    read=r.register_read(m,append,invalid,name+'/caller-register')
    index=m.copy_word(T,D,read,name+'/argument-index')
    tail_cache=m.copy_word(D,L,index,name+'/next-argument-cache')
    decode=nat_list_to_word(m,h,tail_cache,invalid,name+'/argument-nat')
    head=m.copy_word(L,V,decode,name+'/argument-head')
    tail=m.copy_word(RIGHT,D,head,name+'/argument-tail')
    node=h.heap_lookup(m,tail,invalid,name+'/argument-node')
    test=h._word_is(m,V,NIL_BITS,initial_list,node,invalid,name+'/arguments-end')
    h._put(m,loop,V,{'0':(test,'0',0),'1':(test,'1',0)},invalid)
    argroot=m.copy_word(D,V,loop,name+'/argument-root')

    # S is [destination, FnMeta]; a physical bar separates copied arguments.
    new_colon=h._row(m,S,{'B':(argroot,':',0)},invalid,name+'/new-colon')
    bar=m.state(name+'/bar-scan')
    choices={':':(new_colon,'|',1)}
    for symbol in ('0','1',';'):
        choices[symbol]=(bar,symbol,1)
    h._put(m,bar,S,choices,invalid)
    bar_start=m.rewind(S,bar,name+'/bar-start')
    keep_function=h._push_word_to(m,S,V,bar_start,invalid,name+'/keep-function')
    target=_functions_index(m,h,p,keep_function,invalid,name+'/target')
    target_index=_pop(m,h,T,target,invalid,name+'/target-index')
    keep_argroot=m.copy_word(L,D,target_index,name+'/keep-argument-root')
    exact_tail=h._word_is(m,RIGHT,NIL_BITS,keep_argroot,invalid,invalid,name+'/exact-tail')
    last=h.heap_lookup(m,exact_tail,invalid,name+'/last-operand')
    firsttwo=_capture(m,h,2,last,invalid,name+'/first-two-operands')
    return m.copy_word(RIGHT,V,firsttwo,name+'/operands')


def install_runtime(m,h,p,r,f,*,check,name='physical-runtime'):
    """Construct all 13 opcode bodies and BOOT-success entry; never run them.

    Explicit pinned owners: h linked values v2, p complete program intake,
    r register records v1, f frames v1, and m Builder v2. check is the Root
    construction guard, not a runtime semantic/proof oracle.
    """
    check()
    invalid=1
    fetch=m.state(name+'/fetch')
    write=r.register_write(m,fetch,invalid,name+'/write-register')
    entries={}

    # 0 CONST and 1 MOVE.
    constant_write=_pop(m,h,D,write,invalid,name+'/const/destination')
    constant_index=p.list_index(m,h,constant_write,invalid,name+'/const/index')
    constants=m.copy_word(L,V,constant_index,name+'/const/constants')
    whole=h.heap_lookup(m,constants,invalid,name+'/const/whole')
    root=m.copy_word(O,V,whole,name+'/const/root')
    k=_pop(m,h,T,root,invalid,name+'/const/k')
    entries[0]=_ordinary(m,h,2,k,invalid,name+'/const')
    entries[1]=_ordinary(m,h,2,_unary(m,h,r,write,invalid,name+'/move'),invalid,name+'/move')

    # 2 CONS, 3 HEAD, 4 TAIL.
    cons=h.canonical_cons(m,write,invalid,name+'/cons/cons')
    entries[2]=_ordinary(m,h,3,_binary(m,h,r,cons,invalid,name+'/cons'),invalid,name+'/cons')
    for opcode,band,label in ((3,L,'head'),(4,RIGHT,'tail')):
        result=m.copy_word(band,V,write,name+'/'+label+'/result')
        lookup=h.heap_lookup(m,result,invalid,name+'/'+label+'/lookup')
        entries[opcode]=_ordinary(m,h,2,_unary(m,h,r,lookup,invalid,name+'/'+label),invalid,name+'/'+label)

    # 5 PAIR includes nil among atoms; 6 ATOM excludes pairs even if equal.
    false=h._constant(m,V,'0',write,invalid,name+'/false')
    true=h._constant(m,V,'1',write,invalid,name+'/true')
    pair=h._atom_or_node(m,V,false,true,invalid,name+'/pair/classify')
    entries[5]=_ordinary(m,h,2,_unary(m,h,r,pair,invalid,name+'/pair'),invalid,name+'/pair')
    equal=h._compare_words(m,L,RIGHT,true,false,invalid,name+'/atom/equal')
    right_atom=h._atom_or_node(m,RIGHT,equal,false,invalid,name+'/atom/right')
    atom=h._atom_or_node(m,L,right_atom,false,invalid,name+'/atom/left')
    entries[6]=_ordinary(m,h,3,_binary(m,h,r,atom,invalid,name+'/atom'),invalid,name+'/atom')

    # 7 SUCC permits only byte atoms 0..254; 8 NOT requires exact Boolean.
    inc=m.increment_word(V,write,name+'/succ/increment')
    not255=h._word_is(m,V,'11111111',invalid,inc,invalid,name+'/succ/not255')
    notnil=h._word_is(m,V,NIL_BITS,invalid,not255,invalid,name+'/succ/not-nil')
    byte=h._atom_or_node(m,V,notnil,invalid,invalid,name+'/succ/byte')
    entries[7]=_ordinary(m,h,2,_unary(m,h,r,byte,invalid,name+'/succ'),invalid,name+'/succ')
    one=h._word_is(m,V,'1',false,invalid,invalid,name+'/not/one')
    boolean=h._word_is(m,V,'0',true,one,invalid,name+'/not/zero')
    entries[8]=_ordinary(m,h,2,_unary(m,h,r,boolean,invalid,name+'/not'),invalid,name+'/not')

    # 9 BRANCH records both targets before reading the condition register.
    pc_false=m.copy_word(L,PC,fetch,name+'/branch/false')
    pc_true=m.copy_word(RIGHT,PC,fetch,name+'/branch/true')
    one=h._word_is(m,V,'1',pc_true,invalid,invalid,name+'/branch/one')
    boolean=h._word_is(m,V,'0',pc_false,one,invalid,name+'/branch/zero')
    condition=r.register_read(m,boolean,invalid,name+'/branch/read')
    cond_index=_pop(m,h,D,condition,invalid,name+'/branch/condition')
    false_target=_pop(m,h,L,cond_index,invalid,name+'/branch/false-target')
    true_target=_pop(m,h,RIGHT,false_target,invalid,name+'/branch/true-target')
    entries[9]=_ordinary(m,h,3,true_target,invalid,name+'/branch')

    # 10 JUMP, 11 CALL, 12 RETURN. Root accepts exactly the atom one.
    jump=_pop(m,h,PC,fetch,invalid,name+'/jump/target')
    entries[10]=_ordinary(m,h,1,jump,invalid,name+'/jump')
    entries[11]=_call(m,h,p,r,f,fetch,invalid,name+'/call')
    root_return=h._word_is(m,V,'1',0,invalid,invalid,name+'/return/root-one')
    restore=f.frame_pop(m,write,root_return,invalid,name+'/return/restore')
    read=r.register_read(m,restore,invalid,name+'/return/read')
    source=_pop(m,h,D,read,invalid,name+'/return/source')
    entries[12]=_ordinary(m,h,1,source,invalid,name+'/return')

    dispatch=invalid
    for opcode in range(12,-1,-1):
        bits=bin(opcode)[2:][::-1]
        dispatch=h._word_is(m,L,bits,entries[opcode],dispatch,invalid,name+'/dispatch/'+str(opcode))
    increment=m.increment_word(PC,dispatch,name+'/fetch/next-pc')
    instruction=h.heap_lookup(m,increment,invalid,name+'/fetch/instruction')
    code_index=p.list_index(m,h,instruction,invalid,name+'/fetch/code-index')
    index=m.copy_word(PC,T,code_index,name+'/fetch/pc')
    code=m.copy_word(RIGHT,V,index,name+'/fetch/code')
    register_code=h.heap_lookup(m,code,invalid,name+'/fetch/register-code')
    rest2=m.copy_word(RIGHT,V,register_code,name+'/fetch/rest2')
    arity_rest=h.heap_lookup(m,rest2,invalid,name+'/fetch/arity-rest')
    rest=m.copy_word(RIGHT,V,arity_rest,name+'/fetch/rest')
    name_rest=h.heap_lookup(m,rest,invalid,name+'/fetch/name-rest')
    begin=m.copy_word(F,V,name_rest,name+'/fetch/function')
    h._put(m,fetch,F,{'0':(begin,'0',0),'1':(begin,'1',0)},invalid)

    # Main initialization preserves request in the complete S vector while
    # metadata traversal clobbers V. Only then is the full vector committed.
    pc0=h._constant(m,PC,'0',fetch,invalid,name+'/main/pc0')
    commit=_commit_vector(m,h,pc0,invalid,name+'/main/commit')
    pad=_pad_vector(m,h,p,commit,invalid,name+'/main/padding')
    down=p.decrement_word(m,h,T,pad,invalid,name+'/main/request-slot')
    size=_nregs(m,h,down,invalid,name+'/main/nregs')
    function=m.copy_word(V,F,size,name+'/main/function')
    main=_functions_index(m,h,p,function,invalid,name+'/main/index')
    index0=h._constant(m,T,'0',main,invalid,name+'/main/index0')
    program=m.copy_word(F,O,index0,name+'/main/program')
    output=h._records_to_empty_word(m,O,program,invalid,name+'/main/output-word')
    keep_request=h._push_word_to(m,S,V,output,invalid,name+'/main/request')
    empty_frames=h._empty_records(m,FRAMES,keep_request,invalid,name+'/main/empty-frames')
    empty_registers=h._empty_records(m,R,empty_frames,invalid,name+'/main/empty-registers')
    boot_success=h._empty_records(m,S,empty_registers,invalid,name+'/main/empty-stack')
    check()
    return dict(version=VERSION,BOOT_SUCCESS=boot_success,FETCH=fetch,opcodes=entries,
        physical_runtime_source_complete=True,executed=False,table_generated=False,
        full_VM_qualified=False,Wang_initialization=False,proof_search=False,
        scope='Conditional literal controller; canonical intake/BOOT/layout prerequisites and heap embedding remain explicit.')
