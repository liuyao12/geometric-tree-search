"""Source-only immutable GCTSVM1 intake and physical canonical metadata.

All loops below assemble fixed literal microcode; none executes a program,
heap, parser, name decoder, validator or proof during a transition. No module
is imported here. Pass the pinned shared builder and linked-values Source
module only inside a future separately reviewed Root actual.
"""
VERSION='whole-immutable-program-intake-v1'
PROGRAM=0
HEAP=3
RECORDS=4
OBLIGATIONS=5
FUNCTION=6
PC=7
DESTINATION=8
LEFT=9
RIGHT=10
RETURN=11
COUNT=12
TEMP=13
BUFFER=14
NAMES=15
RAW=('B','^','0','1',':',',',';','|','!','#')
OP_BITS=('0','1','01','11','001','101','011','111','0001','1001','0101','1101','0011')
MAGIC_BITS=('11100010','11000010','00101010','11001010','01101010','10110010','10001100')
MAIN_BYTES=('1011011','1000011','1001011','0111011')
MAIN_WIRE=('10110110','10000110','10010110','01110110')
REGISTER_LIMIT_BITS='000000010110100100011001'


def _put(m,q,band,choices,invalid):
    m.put(q,band,{s:choices.get(s,(invalid,s,0)) for s in RAW if s!='#'})


def _row(m,band,choices,invalid,name):
    q=m.state(name)
    _put(m,q,band,choices,invalid)
    return q


def word_less(m,left,right,yes,no,invalid,name='word-less'):
    """Canonical binary words: preserve contents, compare lengths then high bits."""
    if type(left)is not int or type(right)is not int or left==right:
        raise ValueError('distinct fixed word bands required')
    scan=m.state(name+'/scan-left')
    high=m.state(name+'/high-left')
    right_back=_row(m,right,{'B':(high,'B',-1)},invalid,name+'/back-right')
    left_back=_row(m,left,{'B':(right_back,'B',-1)},invalid,name+'/back-left')
    end=_row(m,right,{'0':(yes,'0',0),'1':(yes,'1',0),
                      'B':(left_back,'B',0)},invalid,name+'/length-end')
    next_right=_row(m,right,{'0':(scan,'0',1),'1':(scan,'1',1),
                             'B':(no,'B',0)},invalid,name+'/scan-right')
    _put(m,scan,left,{'0':(next_right,'0',1),'1':(next_right,'1',1),
                      'B':(end,'B',0)},invalid)
    choices={'^':(no,'^',0)}
    for bit in ('0','1'):
        test={}
        for other in ('0','1'):
            target=high if other==bit else (yes if bit=='0' else no)
            test[other]=(target,other,-1 if other==bit else 0)
        q=_row(m,right,test,invalid,name+'/high-right'+bit)
        choices[bit]=(q,bit,-1)
    _put(m,high,left,choices,invalid)
    start=m.rewind(right,scan,name+'/rewind-right')
    return m.rewind(left,start,name+'/rewind-left')


def decrement_word(m,h,band,out,invalid,name='decrement'):
    """Positive canonical word minus one; zero refuses; no integer host action."""
    carry=m.state(name+'/borrow')
    seek=m.state(name+'/seek-end')
    trim=m.state(name+'/trim')
    finish=m.rewind(band,out,name+'/finish')
    zero=_row(m,band,{'B':(finish,'0',0)},invalid,name+'/zero')
    _put(m,trim,band,{'0':(trim,'B',-1),'1':(finish,'1',0),
                     '^':(zero,'^',1)},invalid)
    _put(m,seek,band,{'0':(seek,'0',1),'1':(seek,'1',1),
                     'B':(trim,'B',-1)},invalid)
    seek_start=m.rewind(band,seek,name+'/trim-start')
    _put(m,carry,band,{'0':(carry,'1',1),'1':(seek_start,'0',0)},invalid)
    borrow=m.rewind(band,carry,name+'/borrow-start')
    nonzero=h._word_is(m,band,'0',invalid,borrow,invalid,name+'/positive')
    return h._canonical_word(m,band,nonzero,invalid,name+'/canonical')


def nat_word_to_list(m,h,out,invalid,name='nat-word-to-list'):
    """Preserve TEMP13 canonical word; RETURN gets its proper LSB bit list.

    Clobber LEFT/RIGHT/RETURN/COUNT only. Other bands, including all record
    stacks and FUNCTION/PC/DESTINATION/BUFFER/OUTPUT, are preserved.
    """
    seek=m.state(name+'/seek-end')
    back=m.state(name+'/previous-bit')
    done=h._copy(m,RIGHT,RETURN,out,invalid,name+'/result')
    choices={'^':(done,'^',0)}
    for bit in ('0','1'):
        again=h._copy(m,RETURN,RIGHT,back,invalid,name+'/tail'+bit)
        cons=h.canonical_cons(m,again,invalid,name+'/cons'+bit)
        left=h._constant(m,LEFT,bit,cons,invalid,name+'/left'+bit)
        choices[bit]=(left,bit,-1)
    _put(m,back,TEMP,choices,invalid)
    _put(m,seek,TEMP,{'0':(seek,'0',1),'1':(seek,'1',1),
                      'B':(back,'B',-1)},invalid)
    start=m.rewind(TEMP,seek,name+'/start')
    start=h._constant(m,RIGHT,'000000001',start,invalid,name+'/nil')
    return h._canonical_word(m,TEMP,start,invalid,name+'/canonical')


def list_index(m,h,out,invalid,name='list-index'):
    """TEMP index, RETURN proper list -> RETURN item; clobber9..13.

    No accesses to bands4..8,14,15. A nil/nonpair encountered before the
    selected item refuses. The caller establishes proper unused suffixes;
    indexing alone is not a full arbitrary-list validator. Canonical index
    zero selects the first actual pair; selected-band fences yield BOUND2.
    """
    loop=m.state(name+'/loop')
    found=h._copy(m,LEFT,RETURN,out,invalid,name+'/item')
    lookup_found=h.heap_lookup(m,found,invalid,name+'/lookup-item')
    again=h._copy(m,RIGHT,RETURN,loop,invalid,name+'/tail')
    dec=decrement_word(m,h,TEMP,again,invalid,name+'/decrement')
    lookup_tail=h.heap_lookup(m,dec,invalid,name+'/lookup-tail')
    choose=h._word_is(m,TEMP,'0',lookup_found,lookup_tail,invalid,name+'/zero')
    _put(m,loop,TEMP,{s:(choose,s,0) for s in ('0','1','B','^')},invalid)
    return h._canonical_word(m,TEMP,loop,invalid,name+'/canonical-index')


def _u(m,out,invalid,name):
    return m.decode_U(PROGRAM,COUNT,RETURN,out,invalid,name)


def _push(m,h,source,out,invalid,name):
    return h._push_word_to(m,RECORDS,source,out,invalid,name)


def _pop(m,h,destination,out,invalid,name):
    return h._pop_word_from(m,RECORDS,destination,out,invalid,name)


def _copy_field(m,destination,out,invalid,name):
    loop=m.state(name+'/read')
    finish=m.rewind(destination,out,name+'/result')
    choices={';':(finish,';',1)}
    for bit in ('0','1'):
        write=_row(m,destination,{'B':(loop,bit,1)},invalid,name+'/write'+bit)
        choices[bit]=(write,bit,1)
    _put(m,loop,OBLIGATIONS,choices,invalid)
    return m.clear_word(destination,loop,name+'/clear')


def _skip_field(m,out,invalid,name):
    q=m.state(name+'/skip')
    _put(m,q,OBLIGATIONS,{'0':(q,'0',1),'1':(q,'1',1),
                          ';':(out,';',1)},invalid)
    return q


def _global(m,index,destination,out,invalid,name):
    if type(index)is not int or index not in (0,1):
        raise ValueError('fixed constant/function count field only')
    q=_copy_field(m,destination,out,invalid,name+'/field')
    if index:q=_skip_field(m,q,invalid,name+'/skip-constant-count')
    return m.rewind(OBLIGATIONS,q,name+'/start')


def _field(m,h,bound,out,invalid,name,save_call_target=False):
    # Each callsite's bound is fixed Source: D8 registers, PC7 code, or globals.
    encode=nat_word_to_list(m,h,out,invalid,name+'/bits')
    encode=h._copy(m,RETURN,TEMP,encode,invalid,name+'/word')
    if save_call_target:
        encode=h._push_word_to(m,OBLIGATIONS,RETURN,encode,invalid,name+'/save-target')
    if bound in (PC,DESTINATION):
        check=word_less(m,RETURN,bound,encode,invalid,invalid,name+'/bound')
    elif bound in ('constants','functions'):
        check=word_less(m,RETURN,TEMP,encode,invalid,invalid,name+'/bound')
        check=_global(m,0 if bound=='constants' else 1,TEMP,check,invalid,name+'/global')
    else:
        raise ValueError('fixed program field bound required')
    return _u(m,check,invalid,name+'/U')


def _pack(m,h,count,out,invalid,name):
    # Fixed arity <=3 only; runtime call args use the separate counted loop.
    if type(count)is not int or not 0<=count<=3:
        raise ValueError('fixed record width only')
    nxt=out
    for j in range(count):
        cons=h.canonical_cons(m,nxt,invalid,name+'/cons'+str(j))
        cons=h._copy(m,RETURN,RIGHT,cons,invalid,name+'/tail'+str(j))
        nxt=_pop(m,h,LEFT,cons,invalid,name+'/pop'+str(j))
    return h._constant(m,RETURN,'000000001',nxt,invalid,name+'/nil')


def _reverse_list(m,h,out,invalid,name):
    """RETURN list -> RETURN reversed; clobberF6/PC7,L/R/COUNT/TEMP."""
    loop=m.state(name+'/loop')
    finish=h._copy(m,PC,RETURN,out,invalid,name+'/result')
    again=h._copy(m,RETURN,PC,loop,invalid,name+'/save')
    cons=h.canonical_cons(m,again,invalid,name+'/cons')
    tail=h._copy(m,PC,RIGHT,cons,invalid,name+'/accumulator')
    tail=h._copy(m,RIGHT,FUNCTION,tail,invalid,name+'/next')
    lookup=h.heap_lookup(m,tail,invalid,name+'/lookup')
    lookup=h._copy(m,FUNCTION,RETURN,lookup,invalid,name+'/cursor')
    gate=h._word_is(m,FUNCTION,'000000001',finish,lookup,invalid,name+'/nil-test')
    _put(m,loop,FUNCTION,{s:(gate,s,0) for s in ('0','1','B','^')},invalid)
    start=h._constant(m,PC,'000000001',loop,invalid,name+'/empty-result')
    return h._copy(m,RETURN,FUNCTION,start,invalid,name+'/input')


def _match(m,bits,out,invalid,name):
    nxt=out
    for j in range(len(bits)-1,-1,-1):
        bit=bits[j]
        nxt=_row(m,PROGRAM,{bit:(nxt,bit,1)},invalid,name+'/bit'+str(j))
    return nxt


def _fixed_main(m,h,out,invalid,name):
    nxt=out
    for j,bits in enumerate(MAIN_BYTES):
        again=h._copy(m,RETURN,RIGHT,nxt,invalid,name+'/tail'+str(j))
        cons=h.canonical_cons(m,again,invalid,name+'/cons'+str(j))
        nxt=h._constant(m,LEFT,bits,cons,invalid,name+'/byte'+str(j))
    nxt=h._constant(m,RIGHT,'000000001',nxt,invalid,name+'/nil')
    nxt=_match(m,''.join(MAIN_WIRE),nxt,invalid,name+'/literal-main')
    nxt=h._word_is(m,RETURN,'001',nxt,invalid,invalid,name+'/length-four')
    return _u(m,nxt,invalid,name+'/length')


def _read_byte(m,h,out,invalid,name):
    states=[m.state(name+'/bit'+str(j)) for j in range(8)]
    trim=m.state(name+'/trim')
    finish=m.rewind(RETURN,out,name+'/result')
    zero=_row(m,RETURN,{'B':(finish,'0',0)},invalid,name+'/zero')
    _put(m,trim,RETURN,{'0':(trim,'B',-1),'1':(finish,'1',0),
                       '^':(zero,'^',1)},invalid)
    start_trim=_row(m,RETURN,{'B':(trim,'B',-1)},invalid,name+'/start-trim')
    for j in range(8):
        choices={}
        for bit in ('0','1'):
            nxt=start_trim if j==7 else states[j+1]
            buffer=_row(m,BUFFER,{'B':(nxt,bit,1)},invalid,name+'/buffer'+str(j)+'/'+bit)
            word=_row(m,RETURN,{'B':(buffer,bit,1)},invalid,name+'/word'+str(j)+'/'+bit)
            choices[bit]=(word,bit,1)
        _put(m,states[j],PROGRAM,choices,invalid)
    return m.clear_word(RETURN,states[0],name+'/clear')


def _name(m,h,utf8,out,invalid,check,name):
    read_loop=m.state(name+'/read-loop')
    pack_loop=m.state(name+'/pack-loop')
    finish=h._copy(m,PC,RETURN,out,invalid,name+'/result')
    again=h._copy(m,RETURN,PC,pack_loop,invalid,name+'/save-tail')
    again=decrement_word(m,h,DESTINATION,again,invalid,name+'/pack-decrement')
    cons=h.canonical_cons(m,again,invalid,name+'/cons')
    cons=h._copy(m,PC,RIGHT,cons,invalid,name+'/right')
    cons=_pop(m,h,LEFT,cons,invalid,name+'/byte-pop')
    pack_gate=h._word_is(m,DESTINATION,'0',finish,cons,invalid,name+'/pack-count')
    _put(m,pack_loop,DESTINATION,{s:(pack_gate,s,0) for s in ('0','1','B','^')},invalid)
    pack=h._constant(m,PC,'000000001',pack_loop,invalid,name+'/empty-name')
    utf8_entry=h._link_utf8(m,utf8,pack,invalid,check,name+'/UTF8')
    again=decrement_word(m,h,FUNCTION,read_loop,invalid,name+'/read-decrement')
    again=_push(m,h,RETURN,again,invalid,name+'/save-byte')
    byte=_read_byte(m,h,again,invalid,name+'/byte')
    gate=h._word_is(m,FUNCTION,'0',utf8_entry,byte,invalid,name+'/read-count')
    _put(m,read_loop,FUNCTION,{s:(gate,s,0) for s in ('0','1','B','^')},invalid)
    start=m.clear_word(BUFFER,read_loop,name+'/buffer')
    start=h._copy(m,RETURN,DESTINATION,start,invalid,name+'/original-length')
    start=h._copy(m,RETURN,FUNCTION,start,invalid,name+'/remaining-length')
    return _u(m,start,invalid,name+'/length')


def _unique_name(m,h,out,invalid,name):
    record=m.state(name+'/record')
    loop=m.state(name+'/compare')
    skip=m.state(name+'/skip')
    end=_row(m,NAMES,{'B':(out,':',0)},invalid,name+'/end')
    append=h._write_word_here(m,LEFT,NAMES,':',';',end,invalid,name+'/append')
    _put(m,skip,NAMES,{'0':(skip,'0',1),'1':(skip,'1',1),
                       ';':(record,';',1)},invalid)
    duplicate=_row(m,NAMES,{';':(invalid,';',0)},invalid,name+'/duplicate')
    exact=_row(m,LEFT,{'B':(duplicate,'B',0),'0':(skip,'0',0),
                       '1':(skip,'1',0)},invalid,name+'/exact')
    choices={';':(exact,';',0)}
    for bit in ('0','1'):
        check=_row(m,LEFT,{s:((loop,s,1) if s==bit else (skip,s,0))
                          for s in ('0','1','B')},invalid,name+'/word'+bit)
        choices[bit]=(check,bit,1)
    _put(m,loop,NAMES,choices,invalid)
    compare=m.rewind(LEFT,loop,name+'/word-start')
    _put(m,record,NAMES,{'0':(compare,'0',0),'1':(compare,'1',0),
                         ':':(append,':',0)},invalid)
    return m.rewind(NAMES,record,name+'/start')


def _opcode_wrap(m,h,opcode,out,invalid,name):
    cons=h.canonical_cons(m,out,invalid,name+'/cons')
    cons=h._constant(m,LEFT,OP_BITS[opcode],cons,invalid,name+'/opcode')
    return h._copy(m,RETURN,RIGHT,cons,invalid,name+'/operands')


def _call(m,h,out,invalid,name):
    read_loop=m.state(name+'/read-args')
    pack_loop=m.state(name+'/pack-args')
    wrapped=_opcode_wrap(m,h,11,out,invalid,name+'/instruction')
    packed=_pack(m,h,3,wrapped,invalid,name+'/operands')
    packed=_push(m,h,RETURN,packed,invalid,name+'/save-arg-list')
    packed=_pop(m,h,FUNCTION,packed,invalid,name+'/restore-instruction-count')
    packed=_pop(m,h,PC,packed,invalid,name+'/restore-code-bound')
    dec=decrement_word(m,h,PC,pack_loop,invalid,name+'/pack-decrement')
    cons=h.canonical_cons(m,dec,invalid,name+'/arg-cons')
    cons=h._copy(m,RETURN,RIGHT,cons,invalid,name+'/arg-tail')
    cons=_pop(m,h,LEFT,cons,invalid,name+'/arg-pop')
    pack_gate=h._word_is(m,PC,'0',packed,cons,invalid,name+'/pack-count')
    _put(m,pack_loop,PC,{s:(pack_gate,s,0) for s in ('0','1','B','^')},invalid)
    pack=h._constant(m,RETURN,'000000001',pack_loop,invalid,name+'/empty-args')
    again=decrement_word(m,h,FUNCTION,read_loop,invalid,name+'/read-decrement')
    again=_push(m,h,RETURN,again,invalid,name+'/save-arg')
    arg=_field(m,h,DESTINATION,again,invalid,name+'/argument')
    read_gate=h._word_is(m,FUNCTION,'0',pack,arg,invalid,name+'/read-count')
    _put(m,read_loop,FUNCTION,{s:(read_gate,s,0) for s in ('0','1','B','^')},invalid)
    save_argc=h._push_word_to(m,OBLIGATIONS,RETURN,read_loop,invalid,name+'/save-argc-bits')
    argc_bits=nat_word_to_list(m,h,save_argc,invalid,name+'/argc-bits')
    argc_bits=h._copy(m,RETURN,TEMP,argc_bits,invalid,name+'/argc-word')
    argc_bits=h._copy(m,RETURN,PC,argc_bits,invalid,name+'/original-argc')
    argc_bits=h._copy(m,RETURN,FUNCTION,argc_bits,invalid,name+'/remaining-argc')
    argc=_u(m,argc_bits,invalid,name+'/argc')
    saved=_push(m,h,PC,argc,invalid,name+'/save-code-bound')
    saved=_push(m,h,FUNCTION,saved,invalid,name+'/save-instruction-count')
    target_saved=_push(m,h,RETURN,saved,invalid,name+'/save-target-bits')
    target=_field(m,h,'functions',target_saved,invalid,name+'/target',save_call_target=True)
    dest_saved=_push(m,h,RETURN,target,invalid,name+'/save-dest-bits')
    return _field(m,h,DESTINATION,dest_saved,invalid,name+'/destination')


def _instruction(m,h,out,invalid,name):
    entries=[]
    shapes=((DESTINATION,'constants'),(DESTINATION,DESTINATION),
            (DESTINATION,DESTINATION,DESTINATION),(DESTINATION,DESTINATION),
            (DESTINATION,DESTINATION),(DESTINATION,DESTINATION),
            (DESTINATION,DESTINATION,DESTINATION),(DESTINATION,DESTINATION),
            (DESTINATION,DESTINATION),(DESTINATION,PC,PC),(PC,),(),(DESTINATION,))
    for opcode in range(13):
        if opcode==11:
            entries.append(_call(m,h,out,invalid,name+'/op11'))
            continue
        wrapped=_opcode_wrap(m,h,opcode,out,invalid,name+'/op'+str(opcode)+'/instruction')
        nxt=_pack(m,h,len(shapes[opcode]),wrapped,invalid,name+'/op'+str(opcode)+'/operands')
        for j in range(len(shapes[opcode])-1,-1,-1):
            save=_push(m,h,RETURN,nxt,invalid,name+'/op'+str(opcode)+'/save'+str(j))
            nxt=_field(m,h,shapes[opcode][j],save,invalid,name+'/op'+str(opcode)+'/field'+str(j))
        entries.append(nxt)
    layer={j:(entries[j] if j<13 else invalid) for j in range(16)}
    for depth in range(3,-1,-1):
        previous={}
        for prefix in range(1<<depth):
            choices={}
            for bit in (0,1):
                symbol='1' if bit else '0'
                choices[symbol]=(layer[prefix+(bit<<depth)],symbol,1)
            previous[prefix]=_row(m,PROGRAM,choices,invalid,name+'/opcode/'+str(depth)+'/'+str(prefix))
        layer=previous
    return layer[0]


def _function(m,h,utf8,first,out,invalid,check,name):
    code_loop=m.state(name+'/code-loop')
    # Code is reversed while reading. Reverse before forming the fixed FnMeta.
    finish=h.canonical_cons(m,out,invalid,name+'/Fn-name-cons')
    finish=h._copy(m,RETURN,RIGHT,finish,invalid,name+'/Fn-name-tail')
    finish=_pop(m,h,LEFT,finish,invalid,name+'/Fn-name')
    finish2=h.canonical_cons(m,finish,invalid,name+'/Fn-arity-cons')
    finish2=h._copy(m,RETURN,RIGHT,finish2,invalid,name+'/Fn-arity-tail')
    finish2=_pop(m,h,LEFT,finish2,invalid,name+'/Fn-arity')
    finish3=h.canonical_cons(m,finish2,invalid,name+'/Fn-register-cons')
    finish3=h._copy(m,RETURN,RIGHT,finish3,invalid,name+'/Fn-register-tail')
    finish3=_pop(m,h,LEFT,finish3,invalid,name+'/Fn-registers')
    reverse=_reverse_list(m,h,finish3,invalid,name+'/reverse-code')
    code_done=_pop(m,h,RETURN,reverse,invalid,name+'/pop-code')
    again=decrement_word(m,h,FUNCTION,code_loop,invalid,name+'/code-decrement')
    again=_push(m,h,RETURN,again,invalid,name+'/save-code')
    cons=h.canonical_cons(m,again,invalid,name+'/code-cons')
    cons=_pop(m,h,RIGHT,cons,invalid,name+'/old-code')
    cons=h._copy(m,RETURN,LEFT,cons,invalid,name+'/instruction-ref')
    instruction=_instruction(m,h,cons,invalid,name+'/instruction')
    code_gate=h._word_is(m,FUNCTION,'0',code_done,instruction,invalid,name+'/code-count')
    _put(m,code_loop,FUNCTION,{s:(code_gate,s,0) for s in ('0','1','B','^')},invalid)
    initial_code=_push(m,h,RETURN,code_loop,invalid,name+'/empty-code-save')
    initial_code=h._constant(m,RETURN,'000000001',initial_code,invalid,name+'/empty-code')
    initial_code=h._copy(m,RETURN,PC,initial_code,invalid,name+'/code-bound')
    initial_code=h._copy(m,RETURN,FUNCTION,initial_code,invalid,name+'/remaining-code')
    initial_code=h._word_is(m,RETURN,'0',invalid,initial_code,invalid,name+'/nonempty-code')
    code_count=_u(m,initial_code,invalid,name+'/code-length')
    reg_saved=_push(m,h,RETURN,code_count,invalid,name+'/save-register-bits')
    reg_bits=nat_word_to_list(m,h,reg_saved,invalid,name+'/register-bits')
    reg_bits=h._copy(m,RETURN,TEMP,reg_bits,invalid,name+'/register-word')
    reg_bits=h._copy(m,RETURN,DESTINATION,reg_bits,invalid,name+'/register-bound')
    arity_bound=word_less(m,RETURN,FUNCTION,invalid,reg_bits,invalid,name+'/arity-within-registers')
    upper=word_less(m,RETURN,TEMP,arity_bound,invalid,invalid,name+'/register-upper')
    upper=h._constant(m,TEMP,REGISTER_LIMIT_BITS,upper,invalid,name+'/ten-million')
    positive=h._word_is(m,RETURN,'0',invalid,upper,invalid,name+'/positive-registers')
    registers=_u(m,positive,invalid,name+'/registers')
    arity_saved=_push(m,h,RETURN,registers,invalid,name+'/save-arity-bits')
    arity_bits=nat_word_to_list(m,h,arity_saved,invalid,name+'/arity-bits')
    arity_bits=h._copy(m,RETURN,TEMP,arity_bits,invalid,name+'/arity-word')
    arity_bits=h._copy(m,RETURN,FUNCTION,arity_bits,invalid,name+'/raw-arity')
    if first:arity_bits=h._word_is(m,RETURN,'1',arity_bits,invalid,invalid,name+'/root-arity-one')
    arity=_u(m,arity_bits,invalid,name+'/arity')
    save_name=_push(m,h,LEFT,arity,invalid,name+'/save-name')
    unique=_unique_name(m,h,save_name,invalid,name+'/unique-name')
    unique=h._copy(m,RETURN,LEFT,unique,invalid,name+'/name-ref')
    if first:return _fixed_main(m,h,unique,invalid,name+'/main')
    return _name(m,h,utf8,unique,invalid,check,name+'/name')


def _compare_obligation_field(m,word,out,invalid,name):
    loop=m.state(name+'/compare')
    consume=_row(m,OBLIGATIONS,{';':(out,';',1)},invalid,name+'/consume')
    exact=_row(m,word,{'B':(consume,'B',0)},invalid,name+'/exact')
    choices={';':(exact,';',0)}
    for bit in ('0','1'):
        test=_row(m,word,{bit:(loop,bit,1)},invalid,name+'/word'+bit)
        choices[bit]=(test,bit,1)
    _put(m,loop,OBLIGATIONS,choices,invalid)
    return m.rewind(word,loop,name+'/start')


def _validate_calls(m,h,out,invalid,name):
    loop=m.state(name+'/loop')
    compare=_compare_obligation_field(m,LEFT,loop,invalid,name+'/arity-ref')
    arity=h.heap_lookup(m,compare,invalid,name+'/arity-pair')
    arity=h._copy(m,RIGHT,RETURN,arity,invalid,name+'/function-tail')
    fn=h.heap_lookup(m,arity,invalid,name+'/function-pair')
    index=list_index(m,h,fn,invalid,name+'/target-index')
    index=h._copy(m,PC,RETURN,index,invalid,name+'/function-list')
    target=_copy_field(m,TEMP,index,invalid,name+'/target-word')
    _put(m,loop,OBLIGATIONS,{'0':(target,'0',0),'1':(target,'1',0),
                            ':':(out,':',0)},invalid)
    start=_skip_field(m,loop,invalid,name+'/skip-function-count')
    start=_skip_field(m,start,invalid,name+'/skip-constant-count')
    return m.rewind(OBLIGATIONS,start,name+'/start')


def install_program_intake(m,h,utf8_table,*,out,invalid=3,check,name='program-intake'):
    """Install the complete fixed physical generic GCTSVM1 intake body.

    HEAP starts empty; no hidden seed/program validity predicate is required.
    Layout, fixed P/F/C pins and postcolon blank pins are Root tile obligations.
    Success FUNCTION6 is wholeMeta, PC7/D8 are0 and bands4/5/14/15 empty colon.
    Full69 Source attribution/controller/runtime/fit remain separate.
    """
    state={'schema':'immutable-program-intake-construction-prefix-v1','complete':False,
           'phase':'ENTRY','builder':m,'heap_Source':h,'utf8_table':utf8_table,
           'entries':{},'authority':False}
    try:
        if not callable(check):raise ValueError('explicit Root callback required')
        check()
        if type(name)is not str or not name or len(name)>24:
            raise ValueError('bounded fixed Source name required')
        if type(out)is not int or out<4 or type(invalid)is not int or invalid!=3:
            raise ValueError('working success continuation and MALFORMED3 required')
        state['phase']='CLEANUP_AND_METADATA'
        done=h._word_to_empty_records(m,BUFFER,out,invalid,name+'/clean-buffer')
        done=h._clear_records(m,NAMES,done,invalid,name+'/clean-names')
        done=h._clear_records(m,OBLIGATIONS,done,invalid,name+'/clean-obligations')
        done=h._empty_records(m,RECORDS,done,invalid,name+'/locals-empty')
        done=h._constant(m,DESTINATION,'0',done,invalid,name+'/zero-destination')
        done=h._constant(m,PC,'0',done,invalid,name+'/zero-PC')
        done=h._copy(m,RETURN,FUNCTION,done,invalid,name+'/whole-meta')
        meta=h.canonical_cons(m,done,invalid,name+'/whole-meta-cons')
        meta=_pop(m,h,LEFT,meta,invalid,name+'/constants-meta')
        meta=h._copy(m,PC,RIGHT,meta,invalid,name+'/functions-meta')
        state['phase']='ALL_FORWARD_CALLS'
        calls=_validate_calls(m,h,meta,invalid,name+'/calls')
        functions=h._copy(m,RETURN,PC,calls,invalid,name+'/ordered-functions')
        functions=_reverse_list(m,h,functions,invalid,name+'/reverse-functions')
        state['phase']='ALL_FUNCTIONS_AND_INSTRUCTIONS'
        loop=m.state(name+'/functions-loop')
        again=decrement_word(m,h,FUNCTION,loop,invalid,name+'/function-decrement')
        again=_pop(m,h,FUNCTION,again,invalid,name+'/restore-function-count')
        again=h._copy(m,RETURN,PC,again,invalid,name+'/save-function-list')
        cons=h.canonical_cons(m,again,invalid,name+'/function-list-cons')
        cons=_pop(m,h,RIGHT,cons,invalid,name+'/old-function-list')
        cons=h._copy(m,RETURN,LEFT,cons,invalid,name+'/function-ref')
        other=_function(m,h,utf8_table,False,cons,invalid,check,name+'/function')
        other=_push(m,h,PC,other,invalid,name+'/save-function-list')
        other=_push(m,h,FUNCTION,other,invalid,name+'/save-function-count')
        first=_function(m,h,utf8_table,True,cons,invalid,check,name+'/first-function')
        first=_push(m,h,PC,first,invalid,name+'/save-first-list')
        first=_push(m,h,FUNCTION,first,invalid,name+'/save-first-count')
        eof=_row(m,PROGRAM,{':':(functions,':',0)},invalid,name+'/exact-image-end')
        end=h._copy(m,PC,RETURN,eof,invalid,name+'/reversed-functions')
        gate=h._word_is(m,FUNCTION,'0',end,other,invalid,name+'/remaining-functions')
        _put(m,loop,FUNCTION,{s:(gate,s,0) for s in ('0','1','B','^')},invalid)
        begin=h._constant(m,PC,'000000001',first,invalid,name+'/empty-functions')
        begin=h._copy(m,RETURN,FUNCTION,begin,invalid,name+'/function-count')
        begin=h._push_word_to(m,OBLIGATIONS,RETURN,begin,invalid,name+'/global-functions')
        begin=h._word_is(m,RETURN,'0',invalid,begin,invalid,name+'/nonempty-functions')
        fncount=_u(m,begin,invalid,name+'/functions-U')
        save_constants=_push(m,h,RETURN,fncount,invalid,name+'/save-constants')
        save_constants=_reverse_list(m,h,save_constants,invalid,name+'/reverse-constants')
        state['phase']='ALL_CONSTANTS'
        const_loop=m.state(name+'/constants-loop')
        const_done=h._copy(m,PC,RETURN,save_constants,invalid,name+'/reversed-constants')
        const_again=decrement_word(m,h,FUNCTION,const_loop,invalid,name+'/constant-decrement')
        const_again=h._copy(m,RETURN,PC,const_again,invalid,name+'/save-constant-list')
        const_cons=h.canonical_cons(m,const_again,invalid,name+'/constant-cons')
        const_cons=h._copy(m,PC,RIGHT,const_cons,invalid,name+'/constant-tail')
        const_cons=h._copy(m,RETURN,LEFT,const_cons,invalid,name+'/constant-ref')
        const_check=word_less(m,RETURN,DESTINATION,const_cons,invalid,invalid,name+'/original-seed-bound')
        const_item=_u(m,const_check,invalid,name+'/constant-U')
        const_gate=h._word_is(m,FUNCTION,'0',const_done,const_item,invalid,name+'/remaining-constants')
        _put(m,const_loop,FUNCTION,{s:(const_gate,s,0) for s in ('0','1','B','^')},invalid)
        const_begin=h._constant(m,PC,'000000001',const_loop,invalid,name+'/empty-constants')
        const_begin=h._copy(m,RETURN,FUNCTION,const_begin,invalid,name+'/constant-count')
        const_begin=h._push_word_to(m,OBLIGATIONS,RETURN,const_begin,invalid,name+'/global-constants')
        const_count=_u(m,const_begin,invalid,name+'/constants-U')
        const_count=h._copy(m,PC,DESTINATION,const_count,invalid,name+'/save-original-seed-bound')
        state['phase']='STRICT_CANONICAL_SEED'
        seed_loop=m.state(name+'/seed-loop')
        seed_again=decrement_word(m,h,FUNCTION,seed_loop,invalid,name+'/seed-decrement')
        seed_again=h._increment(m,PC,seed_again,invalid,name+'/next-seed-ID')
        unique=h._compare_words(m,RETURN,PC,seed_again,invalid,invalid,name+'/new-ID-not-duplicate')
        seed_cons=h.canonical_cons(m,unique,invalid,name+'/seed-cons')
        right_check=word_less(m,RIGHT,PC,seed_cons,invalid,invalid,name+'/right-prior')
        left_check=word_less(m,LEFT,PC,right_check,invalid,invalid,name+'/left-prior')
        right=h._copy(m,RETURN,RIGHT,left_check,invalid,name+'/right-value')
        right=_u(m,right,invalid,name+'/seed-right-U')
        left=h._copy(m,RETURN,LEFT,right,invalid,name+'/left-value')
        left=_u(m,left,invalid,name+'/seed-left-U')
        seed_gate=h._word_is(m,FUNCTION,'0',const_count,left,invalid,name+'/remaining-seed')
        _put(m,seed_loop,FUNCTION,{s:(seed_gate,s,0) for s in ('0','1','B','^')},invalid)
        seed_start=h._constant(m,PC,'100000001',seed_loop,invalid,name+'/seed-ID257')
        seed_start=h._copy(m,RETURN,FUNCTION,seed_start,invalid,name+'/seed-count')
        seed_start=_u(m,seed_start,invalid,name+'/seed-count-U')
        magic=_match(m,''.join(MAGIC_BITS),seed_start,invalid,name+'/GCTSVM1')
        entry=m.rewind(PROGRAM,magic,name+'/program-start')
        entry=h._records_to_empty_word(m,BUFFER,entry,invalid,name+'/buffer-word-mode')
        entry=h._empty_records(m,NAMES,entry,invalid,name+'/initial-names-empty')
        entry=h._empty_records(m,OBLIGATIONS,entry,invalid,name+'/initial-obligations-empty')
        entry=h._empty_records(m,RECORDS,entry,invalid,name+'/initial-locals-empty')
        entry=h._empty_records(m,HEAP,entry,invalid,name+'/initial-heap-empty')
        state['entries']['PROGRAM_INTAKE']=entry
        check();state['phase']='CLOSED';state['complete']=True
        return {'schema':'immutable-program-intake-entries-v1','version':VERSION,
                'entries':dict(state['entries']),'complete_generic_program_body':True,
                'full_BOOT':False,'full_VM':False,'runtime_qualified':False,
                'fit':False,'authority':False}
    except BaseException as error:
        try:error.program_intake_construction_prefix=state
        except BaseException:pass
        raise
