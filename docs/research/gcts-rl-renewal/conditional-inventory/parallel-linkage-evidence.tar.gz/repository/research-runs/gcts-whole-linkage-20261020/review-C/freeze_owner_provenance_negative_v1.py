"""Specific independent negative; raw Source/AST metadata only."""
import ast
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-whole-linkage-20261020')
O=N/'review-C';C=O/'owner-provenance-negative-Sources-v1';C.mkdir(exist_ok=True)
checks=[]
def need(name,value):
    checks.append(dict(check=name,passed=bool(value)))
    if not value:raise ValueError(name)
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
p=N/'schema-B/Source-offer-v1-pins.json';offer=json.loads(p.read_bytes());copies=[]
for row in offer['rows']:
    src=Path(row['path']);actual=pin(src)
    need('Exact frozen Source '+src.name,actual['sha256']==row['sha256'] and actual['bytes']==row['bytes'])
    q=C/src.name;need('Fresh raw Source '+src.name,not q.exists());q.write_bytes(src.read_bytes());copies.append(pin(q))
q=C/p.name;need('Fresh offer',not q.exists());q.write_bytes(p.read_bytes())
source=C/'validate_owner_parent_v1.py';text=source.read_text();tree=ast.parse(text);compile(tree,str(source),'exec')
need('Expected frozen checker',pin(source)['sha256']=='600e4a93a5f959d91556ee85f60be0118057a1a99d8915e7f3aa71476a5fe20f')
need('Only numeric earlier owner scope guard',"need(scope is None or type(scope)is int and 1<=scope<=i,'earlier scope owner only')" in text)
need('Owner lookup returns only value',"return ownerrows[ref-1][4]" in text)
need('Events separately require actual scope',"scope_ref=_scalar(_column(row,EVENT_FIELDS,'scope_owner'),int);scope=scope_value(scope_ref)" in text)
need('Current native comparisons exclude owner metadata',"(('canonical_packet','packet'),('manifest','manifest'),('raw_banks','raw_banks'),('catalog','catalog'))" in text)
out=dict(schema='typed-owner-provenance-Source-negative-v1',reviewer_identity='/root/recovered_batch_review',
    status='BLOCKING_SPECIFIC_PROVENANCE_PREDICATE_GAP',review_passed=False,source_only=True,
    full_offer_review_completed=False,offer=pin(q),source_copies=copies,
    finding=dict(origin='Author-reported then independently confirmed on exact frozen Source.',
        location='_live owner scope guard and owned(ref) event-reference lookup',
        condition='An owner scope may be any earlier numeric owner ordinal. Only actual event scope is required to name a role=scope owner. owned(ref) returns the value cursor, dropping owner role/scope/version/route for reference validation.',
        consequence='The independent certificate predicate does not establish complete owner provenance even if complete packet/bank/manifest/catalog values and all event values are unchanged. Genuine producer behavior does not supply this missing independent check.',
        nonclaim='No forged wire was generated, no checker called, no false mathematical theorem or admitted actual shown.'),
    manual_counterexample_recipes=[
        dict(id='earlier non-scope owner',recipe='Take a full valid intended certificate with an owner row after an earlier argument/value owner. Keep row role/value/version/route and every event unchanged; retarget only that owner.scope_owner to the earlier nonscope owner. Re-encode full canonical DAG/root tape coherently inside a future authorized diagnostic. Numeric guard passes; owned(ref) ignores that metadata; actual event scope remains valid.',expected='Successor must refuse: owner scope is not an actual earlier scope owner.'),
        dict(id='role substitution with same full value',recipe='For an event-referenced produced receipt or argument/result owner, keep full value/ordinal and all native original comparisons identical, but replace its nonempty role string by another role; coherent complete tape as above.',expected='Successor must refuse exact operation/phase role mismatch, even if values happen to be equal.'),
        dict(id='cross-scope or version relabel',recipe='Retain full receipt/preimage owner value and event scope, but change owner metadata to another earlier genuine scope or wrong nonnegative lifecycle version; no data omission or value change.',expected='Successor must bind owner scope/version and lifecycle counters to the actual query/profile event.')],
    Root_custody_limit='Current verify_live_custody calls final raw Source/function/callback-owner guards. It does not compare these wire owner metadata rows against a separate expected live owner row sequence. Thus it does not repair the stated independent predicate gap.',
    correction_obligations=['Every scoped owner names a real earlier scope owner; scope owners themselves have no recursive scope.',
        'Every argument/result/error/profile-state/receipt/preimage/reconciliation reference has exact permitted role, event scope, route/version and phase provenance.',
        'Request/production/preimage/delivery ordering, duplicate stage occurrences, counters and final profile receipt/preimage sequences remain exact, with negative mutation versions retained.',
        'Preserve complete original values and occurrence rows; do not trim metadata or weaken provenance to pass the checker.'],
    separate_observation='Public Store/Document/schema Invalid constructors and Store Limit set owner to their module private sentinel automatically. No class/owner classification path has yet been found in this worker, so this review does not claim private-fault laundering. Any future public-impostor/private-ownership claim must resolve that distinction.',
    checks=checks,failed_checks=['Independent owner provenance predicate incomplete'],
    AST_parse=True,unused_compile=True,code_executed=False,author=pin(Path(__file__)),
    subject_imports=0,subject_calls=0,helper_calls=0,checker_calls=0,compiler_calls=0,
    fixture_calls=0,simulator_calls=0,generator_calls=0,sizing_probes=0,semantic_replays=0,
    partial_files_opened=0,new_actuals=0,new_grants=0,actual_execution_authorized=False,
    G1_adopted=False,old_G0_negative_unchanged=True,runtime_qualified=False,fit_proved=False,
    full_VM_qualified=False,new_theorem=False,GCTS_RL_advantage_established=False,goal_status='active',
    offered_v1_mutated=False,primary_reader_index_active_mutated=False)
p=O/'typed-owner-provenance-Source-negative-v1.json';need('Fresh negative',not p.exists())
p.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(dict(negative=pin(p),checks=len(checks)),sort_keys=True))
