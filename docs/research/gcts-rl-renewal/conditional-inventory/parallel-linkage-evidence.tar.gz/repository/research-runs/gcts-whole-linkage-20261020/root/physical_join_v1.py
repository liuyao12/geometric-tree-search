"""UNEXECUTED Source join of immutable intake, value BOOT and all VM opcodes.

No imports or calls occur at module level. This is not a full Wang proof
admission path: fixed public initialization and the accepted-language argument
must still be established, then the unchanged whole cohort must fit and run.
"""
VERSION='whole-physical-linkage-v1'


def install_linkage(m,h,p,r,f,vm,utf8_table,*,check,name='whole'):
    """Assemble one shared sixteen-band machine, under a future Root once.

    utf8_table must be freshly built by the pinned full UTF8 Source within
    that same actual; cached qualified tables and partial results are excluded.
    Exact dependency bytes/owners and Root budget/fault identity are external
    construction preconditions, not runtime transition predicates.
    """
    state=dict(version=VERSION,phase='ENTRY',owners=dict(builder=m,values=h,
        program=p,registers=r,frames=f,runtime=vm,utf8_table=utf8_table),
        runtime=None,value_boot=None,program=None,complete=False,authority=False)
    try:
        check()
        if type(name)is not str or not name or len(name)>16:
            raise ValueError('bounded fixed Source prefix required')
        state['phase']='RUNTIME_CONSTRUCTION'
        runtime=vm.install_runtime(m,h,p,r,f,check=check,name=name+'/run')
        state['runtime']=runtime
        state['phase']='VALUE_BOOT_CONSTRUCTION'
        value=h.install_value_boot(m,utf8_table,out=runtime['BOOT_SUCCESS'],
            invalid=1,check=check,name=name+'/values')
        state['value_boot']=value
        state['phase']='PROGRAM_INTAKE_CONSTRUCTION'
        program=p.install_program_intake(m,h,utf8_table,out=value['entries']['BOOT'],
            invalid=3,check=check,name=name+'/program')
        state['program']=program
        check()
        state['phase']='CLOSED_SOURCE_JOIN'
        state['complete']=True
        return dict(schema='whole-physical-linkage-entries-v1',version=VERSION,
            entries=dict(PROGRAM=program['entries']['PROGRAM_INTAKE'],
                VALUE_BOOT=value['entries']['BOOT'],
                RUNTIME=runtime['BOOT_SUCCESS'],FETCH=runtime['FETCH']),
            stages=state,source_join=True,table_generated=False,executed=False,
            fixed_public_initialization=False,full_VM_qualified=False,
            accepted_language_proved=False,fit=False,authority=False)
    except BaseException as error:
        # Keep genuine owner objects; no serialization, sizer or callback here.
        try:error.whole_linkage_construction_prefix=state
        except BaseException:pass
        raise
