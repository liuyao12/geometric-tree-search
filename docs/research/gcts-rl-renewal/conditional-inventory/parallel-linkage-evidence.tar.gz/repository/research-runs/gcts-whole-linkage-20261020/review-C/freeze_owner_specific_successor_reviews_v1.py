"""Specific raw delta/AST reviews; no cursor, schema, fixture or hash probes."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
N=Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-whole-linkage-20261020')
O=N/'review-C';C=O/'owner-specific-successor-Sources-v1';C.mkdir(exist_ok=True)
checks=[]
def need(name,value):
    checks.append(dict(check=name,passed=bool(value)))
    if not value:raise ValueError(name)
def pin(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def keep(path,digest,size):
    row=pin(path);need('Exact '+path.name,row['sha256']==digest and row['bytes']==size)
    q=C/path.name;need('Fresh raw '+q.name,not q.exists());q.write_bytes(path.read_bytes());return q
schema2=keep(N/'schema-B/schema-v2/validate_owner_parent_v2.py','35223e80407bec14e568618748d0311a07ca67363486e27bda125032551b8cab',51055)
cursor2=keep(N/'schema-B/cursor-v2/owner_cursor_v2.py','93eb21f8bde51051cd5a7c913cd03732252bb5b6aa22cea2c42f5511e61323f0',12786)
offer=N/'schema-B/successor-Source-offer-v2-pins.json';(C/offer.name).write_bytes(offer.read_bytes())
text2=schema2.read_text()
need('Expected route parameter shadowed',"def bound_owner(ref,scope,roles,version=None,route=None):" in text2
     and "role,actual_scope,actual_version,route,unused=ownerrows[ref-1]" in text2
     and "need(ownerrows[ref-1][3]==route,'exact Source route binding')" in text2)
common=dict(reviewer_identity='/root/recovered_batch_review',source_only=True,
 full_offer_review_completed=False,G1_adopted=False,old_G0_negative_unchanged=True,
 fit_proved=False,runtime_qualified=False,full_VM_qualified=False,
 new_theorem=False,GCTS_RL_advantage_established=False,goal_status='active',
 subject_imports=0,subject_calls=0,helper_calls=0,compiler_calls=0,checker_calls=0,
 fixture_calls=0,simulator_calls=0,generator_calls=0,sizing_probes=0,semantic_replays=0,
 native_key_hash_probes=0,partial_files_opened=0,new_actuals=0,new_grants=0,
 actual_execution_authorized=False,offered_sources_mutated=False,primary_reader_index_active_mutated=False,
 author=pin(Path(__file__)))
neg=dict(common,schema='typed-owner-route-shadow-Source-negative-v2',
 status='BLOCKING_EXPECTED_ROUTE_PARAMETER_OVERWRITTEN',review_passed=False,
 source=pin(schema2),offer=pin(C/offer.name),
 finding='bound_owner overwrites its expected route parameter while unpacking the actual owner row. Its subsequent equality compares the actual route with itself, so every nonempty actual route passes that asserted join.',
 manual_counterexample_recipe='Within a coherent intended complete owner/event/tape certificate, preserve owner role, scope, version, ordinal and full value, but replace source_route by a different nonempty string. Calling bound_owner conceptually with expected implicit.query still compares the changed actual row route to that same changed local variable. No wire, fixture or schema call was made.',
 correction_obligation='Keep expected route parameter distinct from actual row route and compare them directly at every existing bound_owner callsite; preserve exact v2 raw preimage.',
 retained_v1_negative=pin(O/'typed-owner-provenance-Source-negative-v1.json'),
 failed_checks=['Independent expected-versus-actual Source route equality is tautological'],
 entire_provenance_successor_review_complete=False)
np=O/'typed-owner-route-shadow-Source-negative-v2.json';need('Fresh v2 negative',not np.exists())
np.write_text(json.dumps(neg,indent=2,sort_keys=True)+'\n')

# Only after freezing the negative above, inspect the separately named fix.
schema3=keep(N/'schema-B/schema-v3/validate_owner_parent_v3.py','923230b512dabb3eb57127e42d06cff88106887921fd598a0226ff2ad69b1701',51068)
delta=N/'schema-B/schema-v3/Source-delta-v3.json';(C/delta.name).write_bytes(delta.read_bytes())
expected=text2.replace("VERSION='immutable-whole-owner-validator-v2-provenance'",
 "VERSION='immutable-whole-owner-validator-v3-route-shadow-correction'",1).replace(
 "role,actual_scope,actual_version,route,unused=ownerrows[ref-1]",
 "role,actual_scope,actual_version,actual_route,unused=ownerrows[ref-1]",1).replace(
 "need(ownerrows[ref-1][3]==route,'exact Source route binding')",
 "need(actual_route==route,'exact Source route binding')",1)
need('Exact v3 three-site raw inverse',expected==schema3.read_text())
static=[]
for p in (schema2,schema3,cursor2):
    tree=ast.parse(p.read_bytes());compile(tree,str(p),'exec')
    static.append(dict(source=pin(p),AST_parse=True,unused_compile=True,executed=False))
route=dict(common,schema='typed-owner-route-v3-specific-Source-delta-review-v1',
 status='PASS_SPECIFIC_ROUTE_SHADOW_CORRECTION_ONLY',review_passed=True,
 source=pin(schema3),predecessor=pin(schema2),delta=pin(C/delta.name),retained_negative=pin(np),
 manual_argument='The expected route parameter remains intact; actual_route is taken from the actual owner row. A supplied non-None expected route now compares directly with actual_route. The exact previously stated route substitution changes one side only and therefore refuses under this predicate. No other schema predicate or full value is changed.',
 explicit_limit='This passes only the exact route-shadow delta. Complete v2/v3 provenance/lifecycle/diagnostic correspondence and full parent/store/worker/bank review remain incomplete; a local bug fix is not a whole-offer PASS.',
 all_counterexample_recipes_unrun=True,static_metadata=static,
 checks=checks,failed_checks=[])
rp=O/'typed-owner-route-v3-specific-Source-delta-review-v1.json';need('Fresh route review',not rp.exists())
rp.write_text(json.dumps(route,indent=2,sort_keys=True)+'\n')

old=O/'owner-provenance-negative-Sources-v1/owner_cursor_v1.py';oldtext=old.read_text();newtext=cursor2.read_text()
ot=ast.parse(oldtext);nt=ast.parse(newtext)
def methods(tree):
    rows={}
    for cls in tree.body:
        if isinstance(cls,ast.ClassDef):
            for fn in cls.body:
                if isinstance(fn,ast.FunctionDef):rows[cls.name+'.'+fn.name]=fn
    return rows
om=methods(ot);nm=methods(nt)
changed=[name for name in om if ast.dump(om[name],include_attributes=False)!=ast.dump(nm[name],include_attributes=False)]
need('Exact changed cursor methods',changed==['Document.__init__','Document._parse','Document._key','Cursor.fields'])
need('Only added cursor entries method',set(nm)-set(om)=={'Cursor.entries'})
key=ast.get_source_segment(newtext,nm['Document._key'])
need('No native nested tuple key construction',"value=tuple(parts)" not in key and "parts.append(natural(self._key(child,depth+1)))" in key)
need('Scalar numeric equality normalization',"record=b'R'+integer(numerator)+integer(denominator)" in key
     and "float.fromhex(payload).as_integer_ratio()" in key)
need('Tuple class encoding finite',"parts=[b'T',natural(len(children))]" in key and "self.key_classes.get(record)" in key)
diff=C/'cursor-v1-to-v2-raw.diff';diff.write_text(''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile='owner_cursor_v1.py',tofile='owner_cursor_v2.py')))
cursor=dict(common,schema='typed-owner-key-normal-form-v2-specific-Source-delta-review-v1',
 status='PASS_SPECIFIC_NESTED_TUPLE_HASH_REMOVAL_SOURCE_ONLY',review_passed=True,
 source=pin(cursor2),predecessor=pin(old),raw_diff=pin(diff),
 retained_negative=pin(O/'typed-tuple-key-cursor-resource-Source-negative-v1.json'),
 manual_findings=[
   dict(id='No tuple unfolding in collision hash',argument='Each hashable key node receives a scalar equality-class integer. A tuple key record encodes arity and ordered child equality-class integers, never the native child tuples. Dictionary collision membership hashes only those scalar class IDs. Repeated tuple descendants reuse one class, removing the stated recursive native tuplehash path.'),
   dict(id='Exact native numeric equivalence',argument='None uses a disjoint marker. False/True and integers normalize to exact ratios0/1 or1/1 or n/1; finite floats use the builtin exact reduced ratio. Thus bool/int/equal finite float keys collide as native keys should; signed zero normalizes together, while strict original value nodes retain their own type/hex. The manually reviewed claim assumes documented exact finite scalar conversion, not a runtime float probe.'),
   dict(id='String and tuple classes',argument='Strings use exact surrogatepass bytes and explicit length, disjoint from ratio/None/tuple markers. Tuple records contain minimal unsigned arity and child class encodings. Induction over earlier child references makes exact class equality equivalent to native finite hashable-key equality; ordered multiplicity is preserved.'),
   dict(id='General key access',argument='String-only dictionary fields preserve original ordered names. Other dictionaries use entries returning complete typed key/value cursors; no unsupported native tuple materialization is hidden in fields. Full native matches remains strict type/container/order correspondence.'),
   dict(id='Remaining resource scope',argument='The particular exponential tuplehash recurrence is removed. This is not a useful whole resource bound: recursion depth, bytes/integers/hash-table operations, canonicalization/parser/checker/native-original traversals and all worker/outer custody costs still require full analysis. No400m/128MiB/180s/RSS fit or complete generic resource theorem follows.')],
 prospective_unrun_controls=['Shared binary tuple DAG keys across allowed depths; no native tuple hash is invoked.',
   'False/0/0.0 and True/1/1.0 collision controls, signed zero and finite nonintegral/large ratio boundaries.',
   'Nested tuple numeric-equivalent keys, order/multiplicity differences and tuple/string/None disjointness.',
   'Mixed general-key dictionaries via entries plus strict complete native matching; malformed/unhashable key refusal.',
   'Quota/fault cutoffs retain actual parser/work/wire/error and complete available prefix.'],
 all_controls_unrun=True,static_metadata=static,checks=checks,failed_checks=[])
cp=O/'typed-owner-key-normal-form-v2-specific-Source-delta-review-v1.json';need('Fresh key review',not cp.exists())
cp.write_text(json.dumps(cursor,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(artifacts=[pin(p) for p in (np,rp,cp)],checks=len(checks)),sort_keys=True))
