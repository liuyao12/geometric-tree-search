SOURCE-ONLY RESEARCH MILESTONE. No new subject/fixture/sizing/runtime calls.
No current grant. All old grants retired. No mathematical admission.
All new prospective banks are declarative and unexecuted; historical banks retain their recorded execution statuses.
Manual bounds are not generated counts.
PublicationWordingPredecessor preserves the rejected overbroad README and exact preimages; it is superseded by this README and the publication negative review.
G0 unchanged; proposed G1 explicitly changes the logical gate and is unadopted.
No partial content is included. Historical partials remain raw-only in predecessor archive.
Preserved negative reviews and separately named successors must not be overwritten.
