"""Passive source/raw metadata pins and authored JSON validation only.

No subject import, function/helper call, semantic enumeration or sizing.
Partial files are streamed only into a raw size/hash descriptor.
"""
from pathlib import Path
import hashlib
import json
import sys

O=Path(__file__).resolve().parent
old=O.parent.parent/'gcts-batch-20261020'
def pin(path):
    digest=hashlib.sha256();size=0
    with path.open('rb')as stream:
        while True:
            block=stream.read(1048576)
            if not block:break
            digest.update(block);size+=len(block)
    return dict(path=str(path.resolve()),bytes=size,sha256=digest.hexdigest())
def write(name,value):
    path=O/name
    assert not path.exists()
    path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n')

failure=old/'root/actual-batch-v2/worker-failure.json'
saved=json.loads(failure.read_bytes())
snapshot={key:saved[key]for key in('stage','status','first_available_fault',
    'call_started','call_completed','call_raised','completed_case_ids','root_check_calls',
    'no_failed_prefix_admission')}
snapshot.update(schema='complete-negative-cutoff-metadata-copy-v1',
    scope='Passive complete saved metadata only. No positive/calibration/mathematical admission.',
    graph_legacy_diagnostic_metadata=[])
for row in saved['diagnostic_prefix']:
    if row['role']!='graph':continue
    prefix=row.get('graph_prefix')
    result=row.get('result')
    if type(prefix)is not dict and type(result)is dict:
        prefix=result.get('unfinished_prefix')
    snapshot['graph_legacy_diagnostic_metadata'].append(dict(
        id=row['id'],expected=row['expected'],callback_count=row['callback_count'],
        callback_trace=row.get('callback_trace'),
        prefix_stage=None if type(prefix)is not dict else prefix.get('stage'),
        completed_oracle_queries=None if type(prefix)is not dict else prefix.get('oracle_completed_queries'),
        result_status=None if type(result)is not dict else result.get('status')))
write('cutoff-metadata-v1.json',snapshot)

retirement=old/'root/ROOT-grant-retirement-v2.json'
retired=json.loads(retirement.read_bytes())
assert retired['grant_status']=='RETIRED' and retired['remaining_actual_invocations']==0
assert retired['actual_invocations']==1
sources=[old/'root/qualify_complete_batch_worker_v2.py',
         old/'components-B/implicit_wang_batch_v2.py',
         old/'recovered/L/implicit_wang_point_search_v1.py',
         old/'publisher/docs/basic-tiling-algorithm.md',
         old/'recovered/ROOT/implicit-inputs-v1.json']
source_pins=[pin(path)for path in sources]
assert source_pins[0]['sha256']=='9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03'
assert source_pins[1]['sha256']=='2dd3269a96bbe8db63afdffc3b175830dad5dea7cc94555024a7aac95ef088e7'
assert source_pins[3]['sha256']=='ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
python=pin(Path(sys.executable))
assert python['sha256']=='b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
notes=[O/'manual-expanded-lower-bound-v1.json',O/'one-owner-field-map-v1.json']
for note in notes:json.loads(note.read_bytes())
partials=[old/'root/actual-batch-v2/canonical-implicit-palette-calibration.json.partial',
          old/'root/actual-batch-v2/failed-prefix.json.partial',
          old/'recovered/ROOT/actual-implicit-v2/failed-prefix.json.partial']
write('handoff-v1.json',dict(schema='evidence-expanded-bound-and-ownership-handoff-v1',
    author='/root/recovered_batch_integration',
    status='SOURCE_AND_NEGATIVE_METADATA_ONLY_AWAITING_INDEPENDENT_REVIEW',
    notes=[pin(path)for path in notes],sources=source_pins,python=python,
    cutoff_metadata=pin(O/'cutoff-metadata-v1.json'),saved_failure=pin(failure),
    retirement=pin(retirement),grant_remaining=0,raw_only_partial_pins=[pin(path)for path in partials],
    master_read_fully=True,author_metadata_script=pin(Path(__file__)),
    subject_imports=0,subject_function_calls=0,subject_helper_calls=0,
    compiler_calls=0,checker_calls=0,fixture_calls=0,simulator_calls=0,
    semantic_sizing_calls=0,enumeration_calls=0,partial_parse_calls=0,actual_launches=0,
    new_implementation_authority=False,new_grant_authority=False,
    fit_proved_for_successor=False,runtime_qualified=False,mathematical_authority=False))
print(json.dumps(pin(O/'handoff-v1.json'),indent=2))
