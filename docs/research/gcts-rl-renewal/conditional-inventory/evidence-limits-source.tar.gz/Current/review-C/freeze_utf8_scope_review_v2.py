"""Pinned raw JSON/Source scope-delta review only; no table generation."""
import hashlib
import json
from pathlib import Path
D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def read(value):
    path = Path(value['path']); assert pin(path) == value
    return path.read_bytes()


def main():
    hpath = D/'root/utf8-Source-handoff-v2.json'
    assert pin(hpath)['sha256'] == '342b087399cebbfbc320b3e4854051d407d876a65672b003b2688670082d6d47'
    handoff = json.loads(hpath.read_bytes()); old = json.loads(read(handoff['predecessor']))
    contract = json.loads(read(handoff['API_and_manual_argument']))
    bank = json.loads(read(handoff['declarative_unrun_bank']))
    oldc = json.loads(read(old['API_and_manual_argument'])); oldb = json.loads(read(old['declarative_unrun_bank']))
    checks = []
    def check(label, value):
        checks.append(dict(label=label,passed=bool(value))); assert value,label
    check('Source unchanged exact08f947 pin', handoff['source'] == old['source'] and handoff['source']['sha256'] == '08f9472acb2042e398997cc0dddd6ddc2487c866a3b683b42f53852bee26a088')
    read(handoff['source'])
    check('prior scope negative preserved', handoff['independent_scope_negative']['sha256'] == '7dbf64796033a903a580a192b0c989294b37e1c31789aad78c518aee82604913')
    read(handoff['independent_scope_negative'])
    check('manual state/row upper bounds unchanged', contract['manual_state_upper_bound'] == oldc['manual_state_upper_bound'])
    check('all existing API fields unchanged', all(contract['api'][k] == v for k,v in oldc['api'].items()))
    check('classifier and complete-byte induction unchanged', contract['manual_correspondence_argument'][:2] == oldc['manual_correspondence_argument'][:2])
    check('representation unchanged', contract['representation'] == oldc['representation'])
    check('exact old partial equivalence withdrawn', 'exact partial terminal trajectories differ' in contract['manual_correspondence_argument'][3] and 'nonaccepting' in contract['manual_correspondence_argument'][3])
    check('new completion explicitly distinguished', 'NEW completed lexical specification' in contract['manual_correspondence_argument'][2] and 'does not prove exact equivalence to old undefined transitions' in contract['manual_correspondence_argument'][2])
    check('old band scans/head/cost equality not claimed', 'no comparison of old sixteen-band physical scan trajectories, step counts or head positions' in contract['manual_correspondence_argument'][3])
    check('public exception ownership caution explicit', 'no private ownership predicate' in contract['api']['foreign_error_classification'] and 'not classify an error as owned merely by type' in contract['api']['foreign_error_classification'])
    check('all16 explicit word controls unchanged', bank['normal_groups'][4] == oldb['normal_groups'][4] and len(bank['normal_groups'][4]['cases']) == 16)
    check('all original normal groups retained in order', [g['id'] for g in bank['normal_groups']] == [g['id'] for g in oldb['normal_groups']])
    check('existing normal recipes/counts unchanged', all(all(g[k] == value for k,value in oldg.items()) for g,oldg in zip(bank['normal_groups'],oldb['normal_groups'])))
    check('mid-byte own-spec scope explicit', 'Old mid-byte B was undefined/stuck' in bank['normal_groups'][3]['scope'])
    check('all five diagnostics retained', [g['id'] for g in bank['diagnostic_groups']] == [g['id'] for g in oldb['diagnostic_groups']])
    check('foreign public class impostors added', 'ConstructionLimit and DeclarationError impostors' in bank['diagnostic_groups'][2]['recipe'] and 'never infer private ownership from class alone' in bank['diagnostic_groups'][2]['recipe'])
    check('unchanged other diagnostic recipes', all(g == oldg for i,(g,oldg) in enumerate(zip(bank['diagnostic_groups'],oldb['diagnostic_groups'])) if i != 2))
    check('no authority or generation from scope delta', handoff['actual_execution_authorized'] is False and handoff['remaining_grants'] == 0 and handoff['subject_calls'] == 0 and handoff['table_generation_calls'] == 0 and bank['actual_execution_authorized'] is False and contract['actual_execution_authorized'] is False)
    receipt = dict(schema='independent-utf8-residual-Source-review-v2',
        reviewer_identity='/root/recovered_batch_review', review_passed=True,
        status='PASS_MANUAL_SOURCE_AND_SCOPE_ONLY_UNEXECUTED',
        source_only=True, handoff=pin(hpath), source=handoff['source'],
        contract=handoff['API_and_manual_argument'], unrun_bank=handoff['declarative_unrun_bank'],
        preserved_predecessor_negative=handoff['independent_scope_negative'],
        mechanical_checks=checks, failed_checks=0,
        manual_findings=['The new lexical routine has an unchanged correct full-byte classifier and equal-depth residual construction under its declared own specification. Mid-byte B->REJECT is an explicit completion of old undefined/stuck behavior, not exact old partial trajectory correspondence.',
          'With undefined/stuck interpreted as nonaccepting, byte/mode projection and induction on byte count preserve the accepted-word language. New B/#/bit rows and halted aliases define the separate new routine; old sixteen-band head/scan/step equivalence is not claimed.',
          'Manual314assigned/317total/1256row upper bounds and the complete declarative unrun bank remain supported by the v1 Source inspection. These are not generated counts, experimental verification or fit.',
          'ConstructionLimit/DeclarationError are public. Future exact actual harness must preserve foreign identity and Root first-fault priority and cannot infer private ownership by class. No executable harness, generated table, controller/linkage or full VM proof is supplied.'],
        subject_imports=0, subject_function_calls=0, table_generation_calls=0,
        compiler_calls=0, checker_calls=0, simulator_calls=0, fixture_calls=0,
        sizing_probes=0, semantic_replays=0, partial_JSON_parses=0,
        actual_execution_authorized=False, runtime_qualified=False,
        complete_interpreter=False, fitting_bound_established=False,
        mathematical_authority=False, tools_stopped_for_this_review=True,
        metadata_author=pin(Path(__file__)))
    path = O/'typed-utf8-residual-Source-review-v2.json'
    with path.open('xb') as output:
        output.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode())
    print(json.dumps(dict(receipt=pin(path),checks=len(checks),review_passed=True),sort_keys=True))


if __name__ == '__main__': main()
