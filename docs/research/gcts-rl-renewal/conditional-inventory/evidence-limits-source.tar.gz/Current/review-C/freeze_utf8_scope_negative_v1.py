"""Independent raw/AST Source review; no table generator is imported/called."""
import ast
import hashlib
import json
from pathlib import Path
import sys

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(value):
    path = Path(value['path'])
    assert pin(path) == value and not path.name.endswith('.partial')
    return path.read_bytes()


def normalized_classifier(node):
    # Metadata AST transform only; returned code objects are never evaluated.
    node = ast.FunctionDef(name='_classifier', args=node.args, body=node.body[:],
                           decorator_list=node.decorator_list, returns=node.returns,
                           type_comment=node.type_comment, type_params=node.type_params)
    if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and type(node.body[0].value.value) is str:
        node.body = node.body[1:]
    return ast.dump(node, annotate_fields=True, include_attributes=False)


def main():
    handoff_path = D/'root/utf8-Source-handoff-v1.json'
    assert pin(handoff_path)['sha256'] == '4a8b3040298b204b08ebc23d4a5f294e93ce2f3e12f53ac75e7e731deb1d1d20'
    handoff = json.loads(handoff_path.read_bytes())
    assert sys.version_info[:3] == (3,12,14)
    python = Path(sys.executable)
    assert pin(python)['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
    folder = O/'utf8-negative-preimages-v1'
    folder.mkdir()
    originals = []
    sources = {}
    for label,value in [('source',handoff['source']),('contract',handoff['API_and_manual_argument']),
                        ('bank',handoff['declarative_unrun_bank']),('foundation',handoff['frozen_classifier_foundation']),
                        ('master',handoff['current_master']),('handoff',pin(handoff_path))]:
        raw = load(value)
        suffix = '.py' if label in ('source','foundation') else '.md' if label == 'master' else '.json'
        path = folder/(label+suffix)
        with path.open('xb') as output:
            output.write(raw)
        originals.append(dict(role=label, original=value, preserved=pin(path)))
        sources[label] = raw.decode()
    st = ast.parse(sources['source'], filename=handoff['source']['path'])
    ft = ast.parse(sources['foundation'], filename=handoff['frozen_classifier_foundation']['path'])
    compile(st, handoff['source']['path'], 'exec', dont_inherit=True, optimize=0)
    compile(ft, handoff['frozen_classifier_foundation']['path'], 'exec', dont_inherit=True, optimize=0)
    defs = {n.name:n for n in st.body if isinstance(n,ast.FunctionDef)}
    fdefs = {n.name:n for n in ft.body if isinstance(n,ast.FunctionDef)}
    assert normalized_classifier(defs['_next_mode']) == normalized_classifier(fdefs['_utf8_next'])
    contract = json.loads(sources['contract']); bank = json.loads(sources['bank'])
    assert contract['manual_state_upper_bound']['assigned_states_upper'] == 314
    assert [sum(row['counts_at_depth0_through7']) for row in contract['manual_state_upper_bound']['per_mode_depth_bounds']] == [255,9,9,9,10,11,11]
    assert sum(row['sum_upper'] for row in contract['manual_state_upper_bound']['per_mode_depth_bounds']) == 314
    assert 314+3 == 317 and 4*314 == 1256
    assert [g.get('prospective_cases') for g in bank['normal_groups'][:4]] == [1792,1785,7,1778]
    assert 7*256 == 1792 and 7*sum(2**d for d in range(8)) == 1785 and 7*sum(2**d for d in range(1,8)) == 1778
    assert len(bank['normal_groups'][4]['cases']) == 16 and len(bank['diagnostic_groups']) == 5
    assert "if not prefix:\n            choices['B'] = (out if mode == 'LEAD' else reject, 'B', 0)" in sources['foundation']
    assert "assign(q, zero, one, 1)" in sources['source']
    assert "('B', blank, 0)" in sources['source']
    assert "put(read, '@' + s" in sources['foundation']
    receipt = dict(schema='independent-utf8-residual-Source-negative-review-v1',
        reviewer_identity='/root/recovered_batch_review', review_passed=False,
        status='SOURCE_SCOPE_NEGATIVE_PARTIAL_TRAJECTORY_EQUIVALENCE_OVERCLAIM',
        source_only=True, subject_imports=0, subject_function_calls=0, table_generation_calls=0,
        compiler_calls=0, checker_calls=0, simulator_calls=0, fixture_calls=0,
        semantic_replays=0, sizing_probes=0, partial_JSON_parses=0,
        AST_parses=2, unused_compiles=2, returned_code_objects_evaluated=False,
        actual_execution_authorized=False, runtime_qualified=False,
        complete_interpreter=False, mathematical_authority=False,
        handoff=pin(handoff_path), raw_preimages=originals,
        parser=dict(python=pin(python), version=sys.version,
                    AST='ast.parse default exec; ast.dump(annotate_fields=True,include_attributes=False)',
                    unused_compile='compile(AST,...,dont_inherit=True,optimize=0); never evaluated'),
        blocking_findings=[dict(id='MIDBYTE_BLANK_UNDEFINED_VERSUS_REJECT',
            old_Source_fact='Frozen _utf8_word only assigns its B choice when prefix is empty. Mid-byte B has no micro choice; the physical foundation therefore has no read transition on @B at those states. Its undefined slots are distinct from the explicit REJECT terminal.',
            new_Source_fact='New assign(q,zero,one,1) gives every interior residual row an explicit stationary B-to-REJECT transition. This is the new declared lexical policy.',
            conflicting_claims=['manual_correspondence_argument claims every full/partial byte trajectory is preserved.',
                                'manual_correspondence_argument says other blank positions reject as original behavior.'],
            consequence='Complete-byte classifier behavior agrees, and the new recognizer can validly define explicit mid-byte rejection. Exact old partial trajectory/terminal correspondence is false. Do not use that claim to justify unimplemented physical linkage.',
            required_delta='Preserve this predecessor. Clarify a successor manual contract: new mid-byte REJECT explicitly completes/refines old undefined/stuck behavior; classifier/full-byte outcomes match, and accepted-word language correspondence needs its stated interpretation. Do not claim identical full partial trajectories or whole-foundation physical equivalence.')],
        positive_Source_observations=[
            'Classifier AST matches the frozen _utf8_next exactly after function-name/docstring normalization; no classifier, generator or simulator was called.',
            'LSB-first depth induction gives the correct complete-byte next mode or explicit REJECT after exactly eight bit moves. Memo key retains depth and both literal successor IDs; roots are separately allocated, preserving boundary B policy.',
            'LEAD covers ASCII, C2..DF, E0, E1..EF, F0,F1..F3,F4; continuation restrictions exclude overlong forms and values above10FFFF while ED accepts surrogatepass encodings. This is manual Source reasoning, not generated-table validation.',
            'Every assigned new row writes its input symbol unchanged; bit rows move right, B/# exits stay. Every assigned row explicitly maps # to BOUND. Three halt states have twelve undefined slots. The new routine is independent of input/image/word length/width/horizon.',
            'Manual per-mode bounds255/9/9/9/10/11/11 sum314assigned,317includinghalts,1256rows. Low-bit interval residual explanations are valid as upper bounds; cross-mode memo sharing can only reduce assigned rows. No actual census, memory, time, palette or full-VM fit follows.',
            'Active raw choices are assigned to the retained state and appended before each transition callback. Failure attaches available raw owner state best effort and rethrows the exact exception without callback/formatting/retry/prefix admission.',
            'The declarative bank includes every mode-byte transition, every prefix fence, all boundary/mid-byte blanks,16 explicit word controls and five diagnostic recipes. Counts1792/1785/7/1778 are correct manual enumeration counts; no enumeration or fixture execution occurred. A concrete executable independent oracle/harness and fresh exact review/grant are still absent.'
        ],
        API_caution='ConstructionLimit has no private owner predicate. The generator performs no normalization, so exact foreign propagation is sound; future diagnostic harnesses must not infer private ownership merely from this public class. The phrase owned limit type should be defined or narrowed before runtime admission.',
        no_scope_narrowing='This is a lexical prerequisite only. Sixteen-band linkage, BOOT and full VM/register/frame/heap controller, semantic correspondence and actual proof search remain absent.',
        metadata_probe_negative=dict(operation='cat guessed fixed_utf8_lexical_v1.py after reading handoff', result='No such file; no subject execution or file mutation.', correction='Read exact pinned utf8_residual_machine_v1.py from handoff.'),
        tools_stopped_after_freeze=True, metadata_author=pin(Path(__file__)))
    destination = O/'typed-utf8-residual-Source-negative-v1.json'
    with destination.open('xb') as output:
        output.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode())
    print(json.dumps(dict(receipt=pin(destination), review_passed=False, subject_calls=0,
                         bounds_manual_only=True, tools_stop=True),sort_keys=True))


if __name__ == '__main__':
    main()
