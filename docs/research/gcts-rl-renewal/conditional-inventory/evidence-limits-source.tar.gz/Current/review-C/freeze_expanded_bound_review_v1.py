"""Manual Source bound plus complete saved metadata; no serializer probe."""
import ast
import hashlib
import json
from pathlib import Path
D=Path(__file__).resolve().parent.parent
O=Path(__file__).resolve().parent


def pin(path):
    raw=path.read_bytes()
    return dict(path=str(path.resolve()),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())


def read(value):
    path=Path(value['path']); assert not path.name.endswith('.partial') and pin(path)==value
    return path.read_bytes()


def main():
    hp=D/'bounds-B/handoff-v1.json'; assert pin(hp)['sha256']=='babdda769b92af053e9306decf9f3701d439a7488749469bacf7d2394acf2c6d'
    h=json.loads(hp.read_bytes()); bound=json.loads(read(h['notes'][0])); mapping=json.loads(read(h['notes'][1])); cutoff=json.loads(read(h['cutoff_metadata']))
    failure=json.loads(read(h['saved_failure'])); retirement=json.loads(read(h['retirement']))
    for value in h['sources']: read(value)
    checkrows=[]
    def check(label,ok):
        checkrows.append(dict(label=label,passed=bool(ok))); assert ok,label
    check('exact Source worker/component/graph pins', [v['sha256'] for v in h['sources'][:3]]==['9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03','2dd3269a96bbe8db63afdffc3b175830dad5dea7cc94555024a7aac95ef088e7','1a83c9c59b2e1862d5a2acda69b826ccc3a8e2cf4899e824286f711f8bf25981'])
    check('old grant remains retired0', retirement['grant_status']=='RETIRED' and retirement['remaining_actual_invocations']==h['grant_remaining']==0)
    check('complete negative metadata scope', failure['stage']==cutoff['stage']=='FULL_PACKET_WRITE' and failure['no_failed_prefix_admission'] is True)
    for key in ('call_started','call_completed','call_raised','completed_case_ids','root_check_calls','first_available_fault'):
        check('cutoff copy exact: '+key, cutoff[key]==failure[key])
    check('completed profile selections31904', failure['call_completed']['implicit.profile_select_query']==31904)
    check('started345/completed333/failed12 profiles', failure['call_started']['implicit.with_profile']==345 and failure['call_completed']['implicit.with_profile']==333 and failure['call_raised']['implicit.with_profile']==12 and 333+12==345)
    graph_diags=[row for row in failure['diagnostic_prefix'] if row['role']=='graph']
    check('all13 original graph diagnostics present', len(graph_diags)==13 and [r['id'] for r in graph_diags]==[r['id'] for r in cutoff['graph_legacy_diagnostic_metadata']])
    check('12 failed diagnostic profiles comprise8invalid4foreign', sum(r['expected']=='INVALID' for r in graph_diags)==8 and sum(r['expected']=='FOREIGN' for r in graph_diags)==4 and sum(r['expected']=='UNKNOWN' for r in graph_diags)==1)
    for row,meta in zip(graph_diags,cutoff['graph_legacy_diagnostic_metadata']):
        check('graph cutoff declaration/trace join: '+row['id'], row['callback_count']==meta['callback_count'] and row.get('callback_trace')==meta['callback_trace'])
    inside=[r for r in graph_diags if r['expected']=='FOREIGN' and r['callback_count']==10]
    check('all3inside foreign traces at initial freeze before domains', len(inside)==3 and all(any(t['function']=='__init__' and t['line']==221 for t in r['callback_trace']) and any(t['function']=='_freeze' and t['line']==134 for t in r['callback_trace']) for r in inside))
    worker=read(h['sources'][0]).decode(); component=read(h['sources'][1]).decode(); graph=read(h['sources'][2]).decode()
    check('saved foreign init line221 is initial input freeze', graph.splitlines()[220].strip()=='self.input_owned = _freeze(original, w)')
    check('all domain construction follows declared input/pin/generation checks', graph.index('self.input_owned = _freeze(original, w)')<graph.index('self.centers = []')<graph.index('pins = owned[\'fixed_background_marks\']')<graph.index('domains.append(self._domain(provisional, i))'))
    check('normal failure propagates before completed case append', "row=qualify_graph(s,case);graphs.append(row);s.rows.append(row)" in worker and "row=qualify_small_palette(s,record);small.append(row);s.rows.append(row)" in worker)
    check('new diagnostics bypass profile_query counter', "m.with_profile(desc, body" in worker and "m.batch_query(desc, requests" in worker and "key='implicit.profile_'+name" in worker)
    check('select raw support and mark shapes fixed by Source', 't=[[[0, 0], 1]]' in component and "m=[[[0, -1], 'edge', colors[0]], [[1, 0], 'edge', colors[1]]," in component)
    # AST metadata only: audit the compact-format constants, not a receipt.
    tree=ast.parse(worker)
    profile=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='profile_call')
    bindings=next(n.value for n in profile.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='bindings' for t in n.targets))
    check('four fixed binding entries', isinstance(bindings,ast.Call) and len(bindings.keywords)==4)
    for entry in bindings.keywords:
        check('binding key/inner-value literal envelope: '+entry.arg, len(entry.arg)<=32 and isinstance(entry.value,ast.Call) and len(entry.value.keywords)==2 and all(len(k.arg)<=16 and isinstance(k.value,ast.Constant) and type(k.value.value)is str and len(k.value.value)<=32 and all(32<=ord(c)<=126 and c not in '\\"' for c in k.value.value) for k in entry.value.keywords) and all(len(k.value.value)<=16 for k in entry.value.keywords if k.arg=='container'))
    scopes=[n.value for n in ast.walk(profile) if isinstance(n,ast.keyword) and n.arg=='reconstruction_scope']
    check('fixed unescaped ASCII scope envelope', len(scopes)==1 and isinstance(scopes[0],ast.Constant) and type(scopes[0].value)is str and len(scopes[0].value)<128 and all(32<=ord(c)<=126 and c not in '\\"' for c in scopes[0].value))
    check('full and compact rows share identical ordinary lifetime', 'full_row=dict(id=profile_id,complete=True,receipt=receipt,lifetime=ordinary)' in worker and 'row=dict(id=profile_id,complete=True,lifetime=ordinary,' in worker)
    check('exact old delta computed before added charge field', worker.index('delta=max(0,len(raw_full)-len(raw_compact))')<worker.index("row['expanded_reconstruction_charge_bytes']=delta")<worker.index('s.expanded_subtree_delta+=delta'))
    check('old expanded predicate still includes all deltas', "expanded_packet_bytes=output['bytes']+s.expanded_subtree_delta" in worker and 'expanded_logical=expanded_packet_bytes+result[\'bytes\']' in worker)
    check('manual t and m arithmetic', 11+1+9+9==30 and 11+1+30+9==51 and 11+51==62 and 14+(31+13+14+8)+(30+13+14+8)+(30+13+14+8)+(31+13+14+8)==276 and 62+276==338)
    check('manual compact extra envelope768 below2048', 552+35+165+16==768 and 768<2048)
    p=Path(h['raw_only_partial_pins'][0]['path'])
    check('RAW LENGTH ONLY canonical fragment base', p.name.endswith('.partial') and p.stat().st_size==124780541)
    check('conservative old expanded lower arithmetic', 31904*338-345*2048==10076992 and 124780541+10076992==134857533 and 134857533-134217728==639805)
    check('field map explicitly changes gate/no fit', mapping['scope_and_gate_change']['gate_change_flag'] is True and mapping['fit_proved'] is False and mapping['actual_authorized'] is False and mapping['implementation_authorized'] is False)
    check('mapping preserves all declared event/case/variant multiplicity', 'Equal calls/results remain separate occurrences.' in mapping['completeness_and_order_rules'][1] and len(mapping['field_mapping'])==16)
    receipt=dict(schema='independent-v2-expanded-lower-bound-review-v1',reviewer_identity='/root/recovered_batch_review',review_passed=True,status='PASS_MANUAL_CONDITIONAL_NEGATIVE_RESOURCE_ARGUMENT',handoff=pin(hp),bound_note=h['notes'][0],field_map=h['notes'][1],cutoff=h['cutoff_metadata'],saved_failure=h['saved_failure'],sources=h['sources'],mechanical_checks=checkrows,failed_checks=0,
      manual_findings=[
       'Each full typed select preimage contains disjoint fixed t and m subtrees. Typed scalar/list literal character bounds give t62 and m276, hence at least338ASCIIbytes, ignoring all other positive terms. This is manual character reasoning, not serialization or subject sizing.',
       'In each complete profile full_row and compact row have the same id/complete/lifetime and common metadata values. Those values cancel in lengths. Only fixed binding/key/scope/punctuation overhead can favor compact representation; the documented768byte envelope is conservative and2048looser. Existing full-return delta therefore is at least338times selections minus2048 for that scope.',
       'The membership join is essential and supported here: all normal phases report completion and normal profile faults are uncaught. The12 failed Root profiles are exactly8old admission-invalid plus4foreign graph diagnostics, all before any oracle by admission flow and the callback1/10 traces. The one work1 UNKNOWN also occurs before the first oracle. New batch diagnostic scopes and standalone queries use different counters. Thus31904completed profile_select calls contribute to successful Root-profile preimages. Using345started scopes rather than333completed scopes over-subtracts overhead conservatively.',
       'The canonical fragment is only statted for its raw byte length124780541; no partial byte was opened/parsed/projected/completed. A complete serialization of the same fresh exclusive append-only packet, if it existed, cannot be shorter than the bytes already emitted.',
       'Under these pinned Source and complete cutoff-metadata assumptions, old expanded data is at least134857533bytes, exceeding134217728by639805, even before ignored remainder/result bytes. This rules out mere physical sharing of that same old logical reconstruction; it does not rule out every changed certificate or admit any mathematical result.',
       'The field map covers all required event/value/custody provenance categories and explicitly labels the proposed one-owner logical certificate as a changed gate. It is not an implemented schema, fitting bound, adoption of G1 or authority to run a successor.'
      ],conditional_claim=dict(old_expanded_lower_bound_bytes=134857533,old_expanded_limit_bytes=134217728,excess_lower_bound_bytes=639805,assumptions=['Pinned Source/canonical formatting and complete saved wrapper-counter/trace joins are truthful.','Fresh exclusive writer and unchanged emitted raw file length; no deleted/truncated prefix.','Retain the exact v2 expanded reconstruction convention.']),
      subject_imports=0,subject_function_calls=0,helper_calls=0,compiler_calls=0,checker_calls=0,fixture_calls=0,simulator_calls=0,sizing_probes=0,semantic_replays=0,partial_content_reads=0,partial_JSON_parses=0,partial_stat_only=True,AST_metadata_parses=1,actual_execution_authorized=False,G1_adopted=False,fitting_bound_established=False,runtime_qualified=False,finite_encoding_accepted=False,mathematical_authority=False,old_grant_remaining=0,tools_stopped_for_this_review=True,metadata_author=pin(Path(__file__)))
    path=O/'typed-expanded-lower-bound-review-v1.json'
    with path.open('xb')as output:output.write((json.dumps(receipt,sort_keys=True,indent=2,ensure_ascii=True)+'\n').encode())
    print(json.dumps(dict(receipt=pin(path),checks=len(checkrows),review_passed=True),sort_keys=True))


if __name__=='__main__':main()
