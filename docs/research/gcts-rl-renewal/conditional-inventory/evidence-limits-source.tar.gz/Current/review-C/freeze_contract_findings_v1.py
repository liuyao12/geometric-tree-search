"""Independent contract note from Source and complete saved metadata only."""
import hashlib
import json
from pathlib import Path
import subprocess

D = Path(__file__).resolve().parent.parent
O = Path(__file__).resolve().parent
OLD = D.parent / 'gcts-batch-20261020'


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def load(path):
    assert not path.name.endswith('.partial')
    return json.loads(path.read_bytes())


def main():
    milestone_path = OLD / 'root/ROOT-final-milestone-v1.json'
    master_path = OLD / 'publisher/docs/basic-tiling-algorithm.md'
    design_path = OLD / 'future-output-B/next-evidence-design-v1.json'
    retirement_path = OLD / 'root/ROOT-grant-retirement-v2.json'
    declaration_path = OLD / 'root/batch-declaration-v2.json'
    worker_path = OLD / 'root/qualify_complete_batch_worker_v2.py'
    assert pin(milestone_path)['sha256'] == '484acdeab808c71a78774f6872f59ecfda62b75f799bf2adca6c02c889172d97'
    assert pin(master_path)['sha256'] == 'ca6ee206287bf18b69f88a35d30968312499567755f347a819af4cf49743e7d4'
    assert pin(design_path)['sha256'] == '48124ee4b282b71c382c8d7cd95f46d02e1b30e09a4d23bb4ab54326dee0973f'
    assert pin(worker_path)['sha256'] == '9ea014de87d5af2ed3017442f690699a0ef54750c8d8be12890e373936b65a03'
    milestone = load(milestone_path)
    design = load(design_path)
    retirement = load(retirement_path)
    declaration = load(declaration_path)
    verification = load(Path(milestone['publication']['HTTP_verification']['path']))
    git_head = subprocess.run(['git','-C',str(OLD/'publisher'),'rev-parse','HEAD'], check=True, capture_output=True, text=True).stdout.strip()
    assert git_head == milestone['publication']['commit'] == '8fb20503e9017d06405cb7768e30a1f99890ea76'
    assert retirement['grant_status'] == 'RETIRED' and retirement['remaining_actual_invocations'] == 0
    assert milestone['classification'] == 'PROGRESS' and milestone['scientific_status'] == 'OUTPUT_CAP_REJECTED_UNQUALIFIED'
    assert milestone['goal_status'] == 'active' and milestone['goal_complete'] is False
    assert design['status'] == 'UNIMPLEMENTED_SOURCE_ONLY_DESIGN_NOT_A_FITTING_BOUND'
    note = dict(
        schema='independent-complete-evidence-expansion-contract-findings-v1',
        reviewer_identity='/root/recovered_batch_review',
        status='SOURCE_CONTRACT_FINDINGS_NOT_IMPLEMENTATION_OR_FIT_QUALIFICATION',
        source_only=True, subject_imports=0, subject_function_calls=0, helper_calls=0,
        compiler_calls=0, checker_calls=0, fixture_calls=0, simulator_calls=0,
        sizing_probes=0, semantic_replays=0, partial_JSON_parses=0,
        actual_execution_authorized=False, fitting_bound_established=False,
        implementation_qualified=False, runtime_qualified=False,
        mathematical_authority=False, old_gate_relaxation_approved=False,
        evidence=dict(previous_frozen_milestone=pin(milestone_path), current_master=pin(master_path),
                      full_prior_design=pin(design_path), retired_grant=pin(retirement_path),
                      prior_declaration=pin(declaration_path), prior_worker_Source=pin(worker_path),
                      previous_live_verification=pin(Path(milestone['publication']['HTTP_verification']['path'])),
                      isolated_publisher_git_HEAD=git_head,
                      live_verification_scope='Existing complete saved HTTP verification and isolated Git state revalidated; no network request or new deployment performed.'),
        conclusions=[
            dict(id='INTRINSIC_EVIDENCE_VERSUS_OLD_SCHEMA', finding='Master section8 requires enough exact data for independent verification and honest complete result/cost reporting. It does not require every reader/progress rendering of the same evidence to be separately serialized. The frozen v2 experiment, however, explicitly made its particular canonical fields and full-return expansion part of its declared resource predicate. Intrinsic proof obligations and that experiment-specific byte schema must be distinguished.'),
            dict(id='ONE_OWNER_IS_NOT_AUTOMATIC_OLD_GATE_PRESERVATION', finding='A one-owner container can remove physical duplication without losing information. If it still promises reconstruction of the complete old logical packet, every old field/reference occurrence remains chargeable under the old expanded gate. Counting each unique payload once instead of each required unfolding changes the predicate. That change is not lossless compression under the exact old gate, even when the mathematical decision remains equivalent.'),
            dict(id='STRICT_SUCCESSOR_AVAILABLE_NO_FIT_CLAIM', finding='A defensible strict successor can be specified: retain all ordered evidence events and typed values in a complete archive, define a total independently reviewed reconstruction into the old v2 logical schema, and continue charging that full old unfolding plus all result bytes. Original physical, time, memory, work, completeness and terminal gates remain. This is a concrete contract, not a demonstrated implementation or fitting bound.'),
            dict(id='NEW_CERTIFICATE_IS_EXPLICIT_DIFFERENT_GATE', finding='An explicitly new one-owner certificate may be a valid research design after a complete acceptance-equivalence and evidence-coverage proof. It must be identified as a changed certificate/resource predicate, with a fresh subject and both controls using the same declared certificate. It cannot retrospectively qualify the rejected v2 run or claim exact old-gate compatibility. This review does not approve such a change or silently treat it as compression.'),
            dict(id='NO_UNSUPPORTED_GLOBAL_INFEASIBILITY', finding='The known canonical write rejection proves failure of that emitted v2 packet in its declared canonical payload allotment. It does not by itself prove that every information-equivalent certificate or even the full old expanded amount exceeds the larger128MiB logical ceiling. A Source-derived lower bound for every relevant occurrence would be required. No such global lower bound or fitting bound is asserted here.')
        ],
        nonnegotiable_obligations=[
            dict(id='PROVENANCE', required='Whole exact inputs, all six subject Sources, fixed point model/inventory/transforms, limits, declaration/closure, fresh grant/consumption and terminal joins. Preserve the time-ordered Source/callable/argument-custody checks and their costs; a shared table of static pin values does not eliminate distinct checks.'),
            dict(id='EVENT_MULTIPLICITY', required='Every actual query/search/oracle/diagnostic attempt has a distinct ordered event identity, including equal arguments/outputs, failures and partial production. Do not merge two events because their payload values compare equal. Count attempted/completed/raised populations and unavailable cost honestly.'),
            dict(id='ACTUAL_AND_INDEPENDENT_EXPECTED', required='Keep each subject output and its independent verifier input/expected result with separate provenance. Value sharing may be indexed only after complete strict typed comparison. Never replace an expected value by a reference asserting that it equals the subject value before the independent comparison is represented.'),
            dict(id='SMALL_AND_LARGE_COHORT', required='All original15normal/33legacy-diagnostic/28new-group/55new-variant coverage and order remain; all four small complete inventories/all16mask projections/all independently determined ranks plus declared zeros remain. Retain all7936large transition rows and its exact declared witness semantics. No smaller sample, reachable trim or quotient of event occurrences.'),
            dict(id='FULL_QUERY_VALUES', required='Operation, full descriptor/mask/index/limits, actual complete raw count/select receipt, full selected tile identity/t/m/edge values, original typed preimage and relevant production/copy/delivery counters are required event data. Hashes are indexes only; values at a referenced occurrence must be fully reconstructible.'),
            dict(id='STRICT_TYPES_AND_MUTATION', required='Preserve dictionary order where the Source guard requires it, tuple/list, bool/int, assignedzero/absence and exact string byte semantics. Pre-mutation and post-mutation values are distinct versions with ordered mutation provenance. An immutable original snapshot cannot be replaced by the later mutated alias. The raw callback/error/Work owners remain alive through actual custody; their bounded type/ref metadata is not a claim to reconstruct Python object identity.'),
            dict(id='GRAPH_AND_ROLLBACK', required='Retain every required graph observer event, complete point totals/generations/marking values/refcounts, forward/reverse dependencies, candidate domains and independent exhaustive domain comparisons, parent/frame/exclusion context, exact before/after rollback and final root restoration, and complete solution/exhaustion semantics. A complete lossless delta chain may be a representation, but its reconstruction/validation must be declared and charged; a final-state or digest-only substitute is insufficient.'),
            dict(id='FAULTS_AND_UNKNOWNS', required='Retain the first genuine Root fault, exact planned foreign/private ownership checks, primary/secondary order, failed-profile available lifetime and unfinished preimage/receipt stage, with explicit null/unknown where unavailable. Expected sentinels never erase the independently latched Root fault; UNKNOWN/refusal cannot become zero candidates, UNSAT or an admitted complete profile.'),
            dict(id='FULL_COSTS', required='Include preparation, query kernels, copying/reconciliation, independent verification, Source/argument custody, learning/cluster costs if later enabled, streaming/index joins, reconstruction, output and negative cleanup in the original epoch and work scopes. Keep unavailable private costs explicitly unavailable and do not double-count aliases as new work or omit failed attempts.'),
            dict(id='COMPLETE_POSITIVE_SEAL', required='A whole ordered terminal manifest and complete coverage joins must bind every certificate part to the same source/input subject and known worker exit. Prefixes, incomplete files and a scalar summary never pass. Complete positive bytes/header/result and known exit remain before180s; custody/log/group/resource/terminal before210s; observer225s is fallback only.'),
            dict(id='UNCHANGED_RESEARCH_SCOPE', required='Finite generic calibration is not a full physical FOL interpreter, theorem discovery, GCTS marking learning, trained RL, useful receptor lemmas, practical arbitrary-region Turtle/Penrose tiling or plane/substitution proof. Do not redefine the broader active goal around a smaller certificate milestone.')
        ],
        duplicate_view_classification=[
            dict(view='Completed progress groups containing full completed diagnostic variants already present in batch_diagnostics', intrinsic='One full ordered diagnostic run plus progress IDs/stage/counts suffices for a new semantic certificate.', exact_old_gate='The frozen v2 schema contains both occurrences. Its exact old unfolding charges both; dropping one changes that schema/gate unless reconstructed and charged.'),
            dict(view='Small-case grouped reader tables repeating full select receipts held by the profile event collection', intrinsic='The complete event record may supply a grouped reader view through total value-preserving bindings; preserve each selection event and its independently checked rank.', exact_old_gate='The old small-case and lifetime occurrences remain in old reconstruction cost. Treating their duplicate values as free does not preserve that resource predicate.'),
            dict(view='Complete profile-return receipt/request/preimage sequences repeated beside the lifetime', intrinsic='The complete lifetime plus exact return bindings may retain all ordinary values; the actual original return object remains owned for custody.', exact_old_gate='The existing v2 compact row already charges full-minus-compact reconstruction. Removing that existing charge is a gate relaxation, not an optimization of the same expansion rule.'),
            dict(view='Actual graph observer snapshots versus independent domain outputs and search result journals', intrinsic='Some point values recur, but observer occurrence, independent-oracle provenance, callback order and rollback comparisons are genuine distinct evidence. Remove only demonstrably derived presentation copies, never the independent result or occurrence.', exact_old_gate='An alleged alias must not erase verifier independence; every old occurrence is still expanded for old-schema claims.'),
            dict(view='Admission q/result summary versus full canonical certificate', intrinsic='q is a separate summary and is not a second full proof. It must contain all completion and subject joins required by the outer gate.', exact_old_gate='Its actually emitted bytes remain charged. The v2 full canonical data may not be replaced by q.'),
            dict(view='Raw owner lists for callbacks, Work objects, exact primary/secondary exception objects', intrinsic='Their in-process retention through final custody is mandatory; serializing every reachable Python object is neither required nor promised. Exact observations and bounded nonreconstructing references still need provenance.', exact_old_gate='Existing ordinary lifetime/prefix fields are part of old schema. No new claim that bounded metadata reconstructs object identity or arbitrary executable state.')
        ],
        strict_G0_preserving_successor=dict(
            name='LOSSLESS_PHYSICAL_REPRESENTATION_WITH_OLD_LOGICAL_UNFOLDING',
            artifact='A complete finite ordered certificate with full literal payloads, typed versions, event records and explicit total reconstruction. Every referenced payload is present in full; no hash-only external cache. All parts have complete subject/order/count/byte joins.',
            reconstructor='A versioned, bounded, independently reviewed total decoder maps complete successor certificate P to the exact old v2 logical packet schema U0(P) and old result summary Q0(P), with every old field occurrence. It uses only the complete artifact, never a failed partial, hidden state, recomputation by the subject, or another proof search. In-memory function/error/Work ownership remains a separate actual custody obligation.',
            expansion_formula=r'\(E_0(P)=|\operatorname{can}_0(U_0(P))|+\Delta_{\mathrm{return},0}(U_0(P))+|\operatorname{can}_0(Q_0(P))|\). Here \(\operatorname{can}_0\) and the conservative profile-return delta are the exact frozen v2 conventions; every repeated occurrence is counted.',
            acceptance_formula=r'Require the complete original cohort and soundness/custody checks, \(E_0(P)\le134\,217\,728\), all stored bytes within the original allowance, and the original physical ledger including \(9\,437\,184\) reserved bytes within \(134\,217\,728\). Also retain \(180\,\mathrm{s}\), \(210\,\mathrm{s}\), \(1\,\mathrm{GiB}\) worker highwater and \(400\,000\,000\) cumulative Root callbacks.',
            implementation_preconditions=['Complete per-field occurrence mapping and type/version provenance proof.',
                'Independent verifier input/output reconstruction equality for every required comparison; no verifier removed.',
                'Conservative whole-cohort Source upper bound for stored, old-unfolded, memory/work/time scopes or an explicit unresolved infeasibility.',
                'All registry join, decoder, writer, custody and bound-check costs included in the sole complete granted epoch.',
                'Fresh exact Source/declaration/closure review and max-one grant; old grant stays retired0.'],
            exact_old_gate_preserved_if_all_conditions_hold=True,
            fitting_bound_established=False, implementation_reviewed=False,
            warning='Pure physical sharing cannot make an already too-large old unfolding satisfy E0. A smaller reported E obtained by skipping old occurrences is not this contract.'),
        changed_G1_certificate_option=dict(
            status='EXPLICIT_CONTRACT_CHANGE_NOT_APPROVED_BY_THIS_REVIEW',
            mathematical_possibility='A different complete certificate can preserve all independent verification obligations while storing only one authoritative occurrence per event and deriving progress/reader views. A proof of decision/evidence equivalence is still necessary.',
            resource_truth='If its expanded object is the new one-owner event certificate rather than U0(P), its expanded-byte predicate differs from the frozen v2 predicate even when both numeric ceilings remain128MiB. Call it a changed certificate/gate and report it separately; never old-gate compression or retrospective rescue.',
            required_disclosures=['Which exact v2 fields are no longer materialized as certificate evidence and which complete event values reconstruct them.',
                'Which views are outside the new logical artifact, why no independent verifier obligation is removed, and all derivation costs.',
                'Every per-event repeated occurrence still required by the new schema and how its references expand.',
                'Same new certificate/gate for compared methods; preserved full problem, scheduling/solution semantics, cohorts and costs.',
                'Separate prior negative and retired grant; no inferred success, speedup or proof from a changed denominator.'],
            authority='Source discussion only. Root must explicitly decide and review any such new contract; no implementation/runtime/fit/admission authority is supplied here.'),
        rigorous_known_and_unknown_bounds=dict(
            proved='The saved complete failure record reports a whole-canonical byte-cap refusal, while the raw fragment length is124780541bytes and the fixed canonical cap is124780544bytes. Thus the actual intended v2 serialization did not fit that declared canonical allotment. The previous run remains rejected.',
            conditional_909=r'Under unchanged observed raw lengths, exclusive ownership and no deletion/truncation, \(124\,780\,541+592+320+9\,437\,184=134\,218\,637>134\,217\,728\). The summary budget predicate has no room even for empty output. This does not identify its unrecorded runtime exception.',
            not_proved=['The complete intended canonical length.', 'The exact complete v2 expanded packet amount.',
                'A lower bound showing all information-equivalent certificates exceed128MiB.',
                'A bound showing a particular one-owner encoding fits unchanged physical/expanded/work/time limits.',
                'A causal speed advantage from the different failure mode or current interpreter.'],
            caution='The canonical cap128MiB minus9MiB is strictly smaller than128MiB. Exceeding the former alone does not prove exceeding the latter. Any global incompatibility proof needs additional rigorous Source bounds; no partial parsing or semantic sizing probe can supply them.'),
        aggregate_budget_contract=[
            'Use one conservative original physical budget spanning all already-written files, open partials, logs, result/header, parent/observer reservation and bounded negative metadata. A helper for one file cannot promise a global physical pass.',
            'Reserve the summary/failure allotment inside the existing total before bulk output. Do not add a new allowance or spend the9MiB outer reservation a second time. Individual per-file caps remain upper bounds, not independent extra budgets.',
            'Track every allocation by unique owner/file/phase. Debit bytes before committing writes; committed/partially written bytes stay permanently charged after failure. Rename does not create a second allocation and cannot erase the partial debit. Do not delete/truncate or rewrite failed files to manufacture a passing ledger.',
            'Only genuinely unspent reservations may be released, under explicit lifecycle rules; file deletion is not reservation release. Any budget metadata failure/census uncertainty fails closed and preserves the exact primary fault.',
            'An exclusive caller must coordinate parent and worker writes and recheck actual stable file sizes. Absence of hostile concurrency is an explicit assumption, not a universal race seal.',
            'Physical and logical-expanded budgets are independent. A disk writer/lease cannot decide proof validity or make a changed logical certificate satisfy old expansion semantics.',
            'The complete final ledger/log/group/source/input/terminal checks remain authoritative. An early summary is negative-only; ENOSPC, short write, clock cutoff or termination may still make it unavailable.'
        ],
        next_action='Freeze the complete occurrence/obligation mapping before a new full worker implementation. Review exact B bounds and L helper Source when frozen pins arrive. Prefer a rigorous failure/incompatibility finding over an unproved fit assumption; continue independent physical-checker/proof-search work without shrinking the broader goal.',
        all_old_sources_unchanged=True, all_old_grants_retired=True,
        partial_policy='No partial file was opened, parsed, projected, completed or admitted in this assessment. Only complete saved metadata and static Source/design were read.',
        tools_stop_after_note=True, metadata_author=pin(Path(__file__)))
    destination = O / 'evidence-expansion-contract-findings-v1.json'
    with destination.open('xb') as output:
        output.write((json.dumps(note, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode())
    print(json.dumps(dict(note=pin(destination), status=note['status'], fitting_bound=False,
                         old_grant_remaining=retirement['remaining_actual_invocations'],
                         subject_calls=0, tools_stop=True), sort_keys=True))


if __name__ == '__main__':
    main()
