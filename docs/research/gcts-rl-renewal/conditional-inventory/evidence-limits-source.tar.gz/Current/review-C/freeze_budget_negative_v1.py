"""Metadata author only. Never imports or calls the reviewed component."""
import ast
import hashlib
import json
from pathlib import Path

NEW = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-evidence-next-20261020')
OWN = NEW / 'review-C'
PYTHON = Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

expected = {
    'handoff-v1.json': ('dd0f58ee310bd0f75b62e291ac4ddf8272a036dec76bf2e3567e81ee3e6bd449', 3877),
    'aggregate_byte_budget_v1.py': ('392771c596b6b15e0d234d328ebc16ad8b4ae428f1f3d80e7fa26e76cdebdade', 23299),
    'API-v1.json': ('135b17e587854346faab312530d408f1ed4a1111df6cb0d284fece51ba2f79c0', 6634),
    'manual-reasoning-v1.json': ('c740fbfea0ddf50bd0b3819f10bc0df33a2fc7c6656a409f5cf7e53ed1e5f3aa', 2990),
    'diagnostic-bank-v1.json': ('739ddc5aaff09d157e71b9c29419b09763d00484e315e969ceb8996e377f861a', 35588),
    'author-static-audit-v2.json': ('27ff8a307cecd359a4be2273e69cbf8457e72a970df37c47672b53f3813c402e', 1324),
    'freeze-manifest-v1.json': ('24d405afda00c46e3c2b5ffe568c0d52df959999ba7d1e67c9be569af844956e', 2071),
}
pins = {}
for name, (sha, size) in expected.items():
    p = pin(NEW / 'budget-L' / name)
    assert (p['sha256'], p['bytes']) == (sha, size), name
    pins[name] = p
runtime = pin(PYTHON)
assert runtime['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933'
source = (NEW / 'budget-L' / 'aggregate_byte_budget_v1.py').read_bytes()
tree = ast.parse(source, filename='aggregate_byte_budget_v1.py')
unused_code = compile(tree, 'aggregate_byte_budget_v1.py', 'exec')
del unused_code
bank = json.loads((NEW / 'budget-L' / 'diagnostic-bank-v1.json').read_text())
groups = bank['groups']
census = dict(groups=len(groups), variants=sum(len(g['variants']) for g in groups),
              pure_metadata_groups=sum(g['domain'] == 'PURE_METADATA' for g in groups),
              filesystem_groups=sum(g['domain'] == 'FILESYSTEM_OPERATIONS' for g in groups))
assert census == dict(groups=46, variants=62, pure_metadata_groups=18, filesystem_groups=28)
text = source.decode()
assert "if slot['name'] not in FIXED:" in text
assert "if item['complete'] and (current is None or item['physical'] != item['physical_limit']):" in text
assert 'HEADER_CAP = 4194304' in text
preimages = OWN / 'budget-negative-preimages-v1'
preimages.mkdir(exist_ok=False)
for name in expected:
    (preimages / name).write_bytes((NEW / 'budget-L' / name).read_bytes())
receipt = {
    'schema': 'aggregate-byte-budget-Source-review-v1',
    'reviewer_identity': '/root/recovered_batch_review',
    'status': 'NEGATIVE_SOURCE_BLOCKER_NOT_RUNTIME_EVIDENCE',
    'source_only': True,
    'actual_execution_authorized': False,
    'component_calls': 0,
    'subject_imports': 0,
    'helper_calls': 0,
    'filesystem_fixture_calls': 0,
    'sizing_probes': 0,
    'semantic_replays': 0,
    'partial_files_opened': 0,
    'runtime_qualified': False,
    'mathematical_admission': False,
    'resource_admission': False,
    'G1_adopted': False,
    'pins': pins,
    'metadata_runtime': runtime,
    'static_metadata': {'AST_parse': True, 'unused_compile': True, 'compiled_code_executed': False, 'full_bank_census': census},
    'full_read': ['Source', 'API', 'manual argument', 'all declarative bank groups and variants', 'handoff'],
    'blocking_findings': [{
        'id': 'FIXED_COMPLETION_SIZE_CONFUSED_WITH_RESERVED_CEILING',
        'source_lines': [164, 173, 329, 343],
        'contract': 'Fixed reservations retain full original ceiling, while clean completion and subsequent full census must accept unchanged successful files and preserve room for a later negative summary.',
        'static_argument': [
            "AggregateLedger.finish sets complete=True but intentionally does not replace physical_limit for a FIXED name.",
            "A successful short worker-receipt.json therefore has complete=True and physical smaller than its retained 4194304-byte reservation.",
            "The first writer census precedes finish, so this short header can complete normally under the Source's own protocol.",
            "Every later writer census visits that complete header and demands physical == physical_limit, even when the exact identity and bytes are unchanged.",
            "The later writer is consequently refused by closed successful file changed. This includes a separately reserved negative summary after a later genuine Root fault.",
            "No API precondition requires header contents to fill 4194304 bytes or makes a completed header prohibit every later record. The failure is a Source/contract mismatch, not an observed runtime event."
        ],
        'remedy': 'Store and check exact successful completion size independently of the fixed reservation ceiling; retain all reserved unused fixed capacity. Continue rejecting deletion, replacement, growth and shrinking of completed files.',
        'required_unrun_bank_extensions': [
            'Short successful fixed header followed by a different successful record, with unchanged reserved fixed ceiling.',
            'Short successful fixed header followed by genuine Root failure and one reserved negative summary attempt.',
            'Completed short fixed header mutated in size or identity before later census; refusal required.'
        ]
    }],
    'nonblocking_static_findings': [
        'Original stored/expanded128MiB, outer9MiB, log/header4MiB and summary64KiB reservations are explicit and do not create a later capacity grant.',
        'Expanded charges remain caller supplied and require independent original-occurrence verification; the helper does not claim proof or originalG0 qualification.',
        'Failed writers retain their full lease, names remain spent, short writes are not retried, metadata observation failure marks exactness unavailable.',
        'Cooperative exclusive ownership, caller-read-only state, bounded parent logs and portable check-then-rename assumptions are explicit.',
        'All candidate/negative receipts deny mathematical and resource admission; all46groups/62variants are declarative and unexecuted.',
        'The previous fdopen cleanup correction preserves the exact primary if descriptor cleanup raises; no operation was run for this review.'
    ],
    'preimage_directory': str(preimages),
    'scope': 'Static Source/API/manual/declarative-bank review only. Frozen negative predecessor preserved; correction requires exact successor review. No change to retired grants, oldG0 negative, limits, proof/search results or runtime authority.',
    'tools_stopped_for_this_frozen_negative': True,
}
out = OWN / 'typed-aggregate-budget-Source-negative-v1.json'
with out.open('x') as f:
    f.write(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(pin(out), sort_keys=True))
