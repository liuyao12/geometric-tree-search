"""Independent metadata-only successor review author; no component execution."""
import ast
import hashlib
import json
from pathlib import Path

NEW = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search/research-runs/gcts-evidence-next-20261020')
OWN = NEW / 'review-C'
L = NEW / 'budget-L'

def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def load(path):
    return json.loads(path.read_text())

checks = []
def check(name, condition):
    assert condition, name
    checks.append(dict(id=name, passed=True))

negative_path = OWN / 'typed-aggregate-budget-Source-negative-v1.json'
negative = load(negative_path)
check('frozen-independent-negative', pin(negative_path)['sha256'] == 'f303ce159c347a040cef077d5577ecfd3784e4526765eb585de7363f68380362')
for name, previous in negative['pins'].items():
    check('v1-unchanged-' + name, pin(L / name) == previous)
expected = {
 'handoff-v2.json': ('8298d0c3904195ea86aaedb6b1bf38aedf23a086cb8295f4d39cf5721ac1e1d5', 3730),
 'aggregate_byte_budget_v2.py': ('cc85059ef049315a8fb340a87ec9dd26c0cb99e0d2dfe28463caa14d509dd1b8', 23530),
 'API-v2.json': ('1fab6ced56cb5862dd4a9373b9b49f9b4d8cace914462f8a06f6a35713796659', 7890),
 'diagnostic-bank-v2.json': ('e5085155f6280bf2618ba49ec4ee345a133c457d5b8b8ad7266be61ab237458c', 41926),
 'manual-reasoning-v2.json': ('c921be6b2bd2c43034dbe9cadc4bf766a8b7dbcc3f566d7b404a9c027baaadf8', 4143),
 'fixed-completion-Source-delta-v1.json': ('fddba9501a600c4bd62f619adb468907480350c3d67e6e4b193b9c5ed590b182', 1712),
 'fixed-completion-Source-v1-to-v2.patch': ('e86af91f918689c1cce7e6fc72c77b9c7f4e0d0d8d03030febfb7ef7e6d6d2aa', 1452),
 'author-static-audit-v3.json': ('7322b2b2f46a29ebfceaf2eb5012064c185b48e3152aef67a90662954c81c39b', 1408),
 'freeze-manifest-v2.json': ('72a2f9995ecb41da7601081828ba762f42f3a720c622f3dd1ac26d3f997c4836', 4613),
}
pins = {}
for name, (sha, size) in expected.items():
    p = pin(L / name)
    check('v2-pin-' + name, (p['sha256'], p['bytes']) == (sha, size))
    pins[name] = p
source = (L / 'aggregate_byte_budget_v2.py').read_text()
inverse = source.replace("VERSION = 'aggregate-byte-budget-v2-fixed-completion'", "VERSION = 'aggregate-byte-budget-v1'", 1)
inverse = inverse.replace("        slot['completed_physical'] = slot['physical']\n        slot['completed_identity'] = slot.get('identity')\n", '', 1)
inverse = inverse.replace("                    if item['complete'] and (current is None or item['physical'] != item['completed_physical'] or\n                                             current['identity'] != item['completed_identity']):", "                    if item['complete'] and (current is None or item['physical'] != item['physical_limit']):", 1)
check('exact-independent-three-hunk-inverse', inverse.encode() == (L / 'aggregate_byte_budget_v1.py').read_bytes())
tree = ast.parse(source, filename='aggregate_byte_budget_v2.py')
unused = compile(tree, 'aggregate_byte_budget_v2.py', 'exec')
del unused
check('AST-and-unused-compile-only', True)
api1, api2 = load(L / 'API-v1.json'), load(L / 'API-v2.json')
for key in api1:
    if key not in ('schema', 'component'):
        check('API-preserved-' + key, api1[key] == api2[key])
check('API-only-scoped-new-fields', set(api2) - set(api1) == {'completed_fixed_files', 'predecessor', 'independent_negative'})
bank1, bank2 = load(L / 'diagnostic-bank-v1.json'), load(L / 'diagnostic-bank-v2.json')
check('original-bank-full-typed-JSON-preserved', json.dumps(bank1['groups'], sort_keys=True, allow_nan=False) == json.dumps(bank2['groups'][:46], sort_keys=True, allow_nan=False))
census = dict(groups=len(bank2['groups']), variants=sum(len(g['variants']) for g in bank2['groups']),
              pure_metadata_groups=sum(g['domain'] == 'PURE_METADATA' for g in bank2['groups']),
              filesystem_groups=sum(g['domain'] == 'FILESYSTEM_OPERATIONS' for g in bank2['groups']))
check('complete-bank-census', census == dict(groups=49, variants=70, pure_metadata_groups=18, filesystem_groups=31))
new_groups = bank2['groups'][46:]
check('three-appended-groups', [g['id'] for g in new_groups] == ['short-header-then-bulk', 'short-header-then-negative', 'short-completed-header-tamper'])
check('eight-unrun-new-variants', sum(len(g['variants']) for g in new_groups) == 8)
check('growth-shrink-identity-both-downstreams', {(v['parameters']['mutation'], v['parameters']['downstream']) for v in new_groups[-1]['variants']} == {(m, d) for m in ('growth', 'shrink', 'identity') for d in ('bulk', 'negative-summary')})
reason1, reason2 = load(L / 'manual-reasoning-v1.json'), load(L / 'manual-reasoning-v2.json')
check('original-manual-invariants-preserved', reason2['invariants'][:-1] == reason1['invariants'])
runtime = pin(Path('/Users/liuyao/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'))
check('current-parser-runtime-pin', runtime['sha256'] == 'b6ea0c2a9bfce48dbf181a53f1ca4f0562d40658b85bf47258e2a88d8f9e3933')
receipt = dict(
 schema='aggregate-byte-budget-Source-review-v2',
 reviewer_identity='/root/recovered_batch_review', status='PASS_SOURCE_ONLY_CONDITIONAL_CONTRACT_NO_RUNTIME_AUTHORITY',
 source_only=True, source_review_complete=True, actual_execution_authorized=False,
 component_calls=0, subject_imports=0, helper_calls=0, filesystem_fixture_calls=0,
 sizing_probes=0, semantic_replays=0, partial_files_opened=0,
 runtime_qualified=False, mathematical_admission=False, resource_admission=False, G1_adopted=False,
 negative_predecessor=pin(negative_path), pins=pins, metadata_runtime=runtime,
 checks=checks, failed_checks=[], bank_census=census,
 static_metadata=dict(AST_parse=True, unused_compile=True, compiled_code_executed=False),
 manual_findings=[
  dict(id='fixed-size-correction', finding='The exact three-hunk inverse reconstructs the frozen v1 bytes. The only behavioral correction snapshots completed physical bytes and identity, then compares later completed-file census with that snapshot instead of the retained ceiling.'),
  dict(id='unchanged-short-header', finding='Under the declared normal writer flow, the identity is observed before finish. An unchanged short fixed header now passes the later completion comparison; full fixed reservations remain held.'),
  dict(id='tamper-refusals', finding='Growth is detected by exact completion-size comparison; shrinking is refused by monotone observation; replacement is refused by existing and completed identity checks; disappearance is refused by existing complete-file checks.'),
  dict(id='no-budget-refund', finding='The fixed ceiling branch is unchanged. Dynamic clean success releases unused capacity only; failed leases remain held. No written-byte refund, deletion, overwrite or output retry was introduced.'),
  dict(id='independent-full-review', finding='The full v1 Source/API/manual/all46groups62variants were independently read before the sole blocker was frozen. All v1 bytes are revalidated unchanged; the exact successor Source delta and all new recipes were read.'),
  dict(id='diagnostics-unrun', finding='All49groups70variants are declarative. The three new groups add short-header continuation and both downstream tamper recipes. No fixture exists or was executed; these are not passing test results.'),
  dict(id='firstfault-and-reservations', finding='The previously reviewed exact primary selection, cleanup ownership, negative one-attempt path, cooperative ownership, separate physical/expanded ceilings and original absolute time limits are byte-unchanged.'),
  dict(id='scope-limits', finding='Full occurrence expansion remains an independent upstream obligation. This helper is unintegrated, grants no oldG0 pass, G1 adoption, complete certificate fit, VM linkage or proof/search acceptance.')
 ],
 tools_stopped_after_freeze=True,
)
out = OWN / 'typed-aggregate-budget-Source-review-v2.json'
with out.open('x') as f:
    f.write(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(pin(out), sort_keys=True))
