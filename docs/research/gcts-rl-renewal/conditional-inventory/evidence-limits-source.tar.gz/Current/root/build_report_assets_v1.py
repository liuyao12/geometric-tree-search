"""Publication metadata utility only. Never imports or calls research subjects."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import sys
import tarfile

BASE = Path('/Users/liuyao/Documents/Codex/projects/geometric-tree-search')
NEW = BASE / 'research-runs/gcts-evidence-next-20261020'
ROOT = NEW / 'root'
OLD = BASE / 'research-runs/gcts-batch-20261020'
PUB = OLD / 'publisher/docs/research/gcts-rl-renewal/conditional-inventory'

def pin(path):
    assert path.is_file() and not path.name.endswith('.partial')
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

writer_review = Path(sys.argv[1]).resolve()
assert writer_review.parent == NEW / 'review-C'
review = json.loads(writer_review.read_bytes())
assert review['status'] == 'PASS_SOURCE_ONLY_CONDITIONAL_CONTRACT_NO_RUNTIME_AUTHORITY'
assert review['source_review_complete'] is True and review['failed_checks'] == []
assert review['runtime_qualified'] is False

copies = {
    'evidence-limits-bound-review.json': NEW / 'review-C/typed-expanded-lower-bound-review-v1.json',
    'evidence-limits-utf8-negative.json': NEW / 'review-C/typed-utf8-residual-Source-negative-v1.json',
    'evidence-limits-utf8-review.json': NEW / 'review-C/typed-utf8-residual-Source-review-v2.json',
    'evidence-limits-writer-review.json': writer_review,
    'evidence-limits-writer-negative.json': NEW / 'review-C/typed-aggregate-budget-Source-negative-v1.json',
    'evidence-limits-publication-negative.json': NEW / 'review-C/typed-evidence-limits-publication-negative-v1.json',
    'evidence-limits-residual.svg': ROOT / 'residual-sharing.svg',
}
for name, source in copies.items():
    shutil.copyfile(source, PUB / name)

summary = {
    'schema': 'ROOT-parallel-evidence-limits-milestone-v1',
    'date': '2026-10-20',
    'status': 'PROGRESS_SOURCE_AND_METADATA_ONLY',
    'goal_status': 'active',
    'new_actual_invocations': 0, 'new_grants': 0, 'old_grant_remaining': 0,
    'subject_imports': 0, 'subject_function_calls': 0, 'compiler_calls': 0,
    'checker_calls': 0, 'simulator_calls': 0, 'fixture_calls': 0,
    'sizing_probes': 0, 'semantic_replays': 0, 'partial_content_reads': 0,
    'partial_JSON_parses': 0, 'all_partials': 'Raw length/hash only; never parsed, projected, completed or admitted.',
    'conditional_manual_lower_bound': {
        'selected_receipts': 31904, 'typed_disjoint_subtrees_lower_bytes': 338,
        'started_profiles_subtracted': 345, 'overhead_per_scope_upper_bytes': 2048,
        'expanded_delta_lower_bytes': 10076992,
        'raw_partial_length_only': 124780541,
        'old_expanded_lower_bytes': 134857533, 'unchanged_limit_bytes': 134217728,
        'excess_lower_bytes': 639805,
        'assumptions': ['Pinned Source and complete saved counter/trace joins truthful.',
                        'Fresh exclusively owned canonical writer with no deletion/truncation.',
                        'Unchanged literal v2 reconstruction convention.'],
        'review': copies['evidence-limits-bound-review.json'].name,
        'mathematical_authority': False, 'exact_packet_size': False,
    },
    'G0': 'Unchanged old expanded reconstruction gate; rejection remains.',
    'G1': {'status': 'UNIMPLEMENTED_PROPOSAL', 'gate_changed': True,
           'adopted': False, 'fitting_bound_established': False,
           'numeric_caps_unchanged': True, 'whole_banks_retained': True},
    'writer': {'status': 'SOURCE_ONLY_UNEXECUTED_UNINTEGRATED',
               'review': writer_review.name, 'review_passed': True,
               'negative_predecessor_preserved': True,
               'diagnostic_bank': 'Read exact successor bank in archive; declarative only.'},
    'lexical': {'source': 'utf8_residual_machine_v1.py',
                'source_pin': pin(ROOT / 'utf8_residual_machine_v1.py'),
                'working_states_manual_upper': 314, 'total_states_manual_upper': 317,
                'transitions_manual_upper': 1256, 'undefined_halt_slots': 12,
                'old_unshared_working_states': 1785,
                'scope': 'New completed lexical specification; old accepted-word language with stuck treated nonaccepting. No old full physical trajectory correspondence.',
                'table_generation_calls': 0, 'runtime_qualified': False,
                'full_interpreter': False, 'whole_palette_fit': False},
    'accepted_new_theorems': 0, 'RL_trained_here': False,
    'GCTS_RL_advantage_established': False,
    'full_goal_open': json.loads((ROOT / 'research-direction-v1.json').read_bytes())['full_program_open'],
    'predecessor_live': 'scoped-palettes.html',
}
save(PUB / 'evidence-limits-summary.json', summary)

members = {}
for directory in ('bounds-B', 'budget-L', 'recovered-checker'):
    for path in sorted((NEW / directory).rglob('*')):
        if path.is_file():
            assert not path.name.endswith('.partial')
            members['Current/' + path.relative_to(NEW).as_posix()] = path
for path in sorted((NEW / 'review-C').rglob('*')):
    if path.is_file() and 'publication' not in path.name:
        assert not path.name.endswith('.partial')
        members['Current/' + path.relative_to(NEW).as_posix()] = path
for name in ('ROOT-continuation-assessment-v1.json', 'checker-source-recovery-v1.json',
             'fixed-checker-evidence-preimage.tar.gz', 'fixed-checker-manifest-preimage.json',
             'research-direction-v1.json', 'residual-sharing.svg',
             'build_report_assets_v1.py', 'isolated-reader-preimage.html'):
    members['Current/root/' + name] = ROOT / name
for path in sorted(ROOT.glob('utf8*')):
    assert path.is_file()
    members['Current/root/' + path.name] = path
for path in sorted((ROOT / 'publication-wording-predecessor-v1').iterdir()):
    assert path.is_file()
    members['PublicationWordingPredecessor/' + path.name] = path

historical = {
    'worker.py': OLD / 'root/qualify_complete_batch_worker_v2.py',
    'batch-component.py': OLD / 'components-B/implicit_wang_batch_v2.py',
    'point-search.py': OLD / 'recovered/L/implicit_wang_point_search_v1.py',
    'implicit-inputs.json': OLD / 'recovered/ROOT/implicit-inputs-v1.json',
    'new-diagnostic-bank.json': OLD / 'diagnostics-L/new-diagnostic-bank-v1.json',
    'batch-plan-authorized.json': OLD / 'root/batch-plan-authorized-v2.json',
    'complete-worker-failure.json': OLD / 'root/actual-batch-v2/worker-failure.json',
    'grant-retirement.json': OLD / 'root/ROOT-grant-retirement-v2.json',
    'negative-adoption.json': OLD / 'root/ROOT-negative-adoption-v2.json',
    'final-milestone.json': OLD / 'root/ROOT-final-milestone-v1.json',
    'basic-tiling-algorithm.md': OLD / 'publisher/docs/basic-tiling-algorithm.md',
    'AGENTS.md': OLD / 'publisher/AGENTS.md',
}
for name, path in historical.items():
    members['HistoricalContext/' + name] = path
members['Publication/evidence-limits.html'] = PUB / 'evidence-limits.html'
members['Publication/evidence-limits-summary.json'] = PUB / 'evidence-limits-summary.json'
members['Publication/reader.html'] = PUB / 'reader.html'
for name in copies:
    members['Publication/' + name] = PUB / name

pins = [{'path': name, **pin(path)} for name, path in sorted(members.items())]
readme = ('SOURCE-ONLY RESEARCH MILESTONE. No new subject/fixture/sizing/runtime calls.\n'
          'No current grant. All old grants retired. No mathematical admission.\n'
          'All new prospective banks are declarative and unexecuted; historical banks retain their recorded execution statuses.\n'
          'Manual bounds are not generated counts.\n'
          'PublicationWordingPredecessor preserves the rejected overbroad README and exact preimages; it is superseded by this README and the publication negative review.\n'
          'G0 unchanged; proposed G1 explicitly changes the logical gate and is unadopted.\n'
          'No partial content is included. Historical partials remain raw-only in predecessor archive.\n'
          'Preserved negative reviews and separately named successors must not be overwritten.\n').encode()
archive = PUB / 'evidence-limits-source.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            contents = {'README.txt': readme,
                        'MANIFEST.json': (json.dumps(pins, indent=2, sort_keys=True) + '\n').encode()}
            contents.update({name: path.read_bytes() for name, path in members.items()})
            for name, raw in sorted(contents.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mtime = 0
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(raw))

assets = [PUB / name for name in sorted(copies)] + [PUB / 'evidence-limits.html',
          PUB / 'evidence-limits-summary.json', archive, PUB / 'reader.html']
manifest = {
    'schema': 'ROOT-evidence-limits-publication-manifest-v1',
    'status': 'SOURCE_ONLY_NO_EXPERIMENT_NO_MATHEMATICAL_ADMISSION',
    'assets': [{'path': path.name, **pin(path)} for path in sorted(assets)],
    'archive_members': pins,
    'archive_added_metadata': ['README.txt', 'MANIFEST.json'],
    'partial_content_included': False, 'new_actual_invocations': 0, 'new_grants': 0,
    'goal_status': 'active', 'publication_review': 'evidence-limits-review.json',
    'review_self_reference': 'Publication review is frozen after these assets; it pins this manifest and is excluded from it.',
}
save(PUB / 'evidence-limits-manifest.json', manifest)
print(json.dumps({'archive': pin(archive), 'source_members': len(pins),
                  'manifest': pin(PUB / 'evidence-limits-manifest.json'),
                  'subject_calls': 0, 'partial_reads': 0}))
