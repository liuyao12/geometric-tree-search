"""Independent fixed-Wang qualification bank: future reviewed actual ONLY.

No subject imports. Literal declarations below are not generated palettes or
executed fixtures. The caller supplies the exact frozen subject module and its
genuine Root check. This bank is qualification, never GCTS/proof search.
"""
import hashlib
import json

SCHEMA = 'independent-fixed-Wang-qualification-v1'
SUBJECT_VERSION = 'deterministic-single-head-framed-Wang-v1'
MACHINE = {
    'schema': 'deterministic-one-tape-machine-v1',
    'symbols': ['_', '0', '1'], 'states': ['s', 't', 'acc', 'rej'],
    'blank': '_', 'start': 's', 'accept': 'acc', 'reject': 'rej',
    'input_alphabet': ['0', '1'],
    'transitions': [
        {'state': 's', 'read': '_', 'next': 'acc', 'write': '_', 'move': 0},
        {'state': 's', 'read': '0', 'next': 't', 'write': '1', 'move': 1},
        {'state': 's', 'read': '1', 'next': 't', 'write': '0', 'move': -1},
        {'state': 't', 'read': '_', 'next': 'acc', 'write': '1', 'move': 0},
        {'state': 't', 'read': '0', 'next': 'rej', 'write': '0', 'move': 0},
        {'state': 't', 'read': '1', 'next': 's', 'write': '_', 'move': 0}
    ]
}
WITNESSES = [
    {'id': 'width1-stay', 'cells': [['head', '_']], 'rows': [
        [['H', 's', '_']], [['H', 'acc', '_']]]},
    {'id': 'width1-accept-padding', 'cells': [['head', '_']], 'rows': [
        [['H', 's', '_']], [['H', 'acc', '_']],
        [['H', 'acc', '_']], [['H', 'acc', '_']]]},
    {'id': 'width2-left-old-destination', 'cells': [['fixed', '_'], ['head', '1']], 'rows': [
        [['T', '_'], ['H', 's', '1']],
        [['H', 't', '_'], ['T', '0']],
        [['H', 'acc', '1'], ['T', '0']]]},
    {'id': 'width2-right-old-destination', 'cells': [['head', '0'], ['fixed', '_']], 'rows': [
        [['H', 's', '0'], ['T', '_']],
        [['T', '1'], ['H', 't', '_']],
        [['T', '1'], ['H', 'acc', '1']]]},
    {'id': 'width3-free-selector', 'cells': [['fixed', '1'], ['head', '0'], ['free']], 'rows': [
        [['T', '1'], ['H', 's', '0'], ['T', '1']],
        [['T', '1'], ['T', '1'], ['H', 't', '1']],
        [['T', '1'], ['T', '1'], ['H', 's', '_']],
        [['T', '1'], ['T', '1'], ['H', 'acc', '_']]]}
]
CONTROL_IDS = [
    'main-complete-local-and-frame-relation',
    'accept-start-complete-local-and-frame-relation',
    'global-right-destination-old-symbol', 'global-left-destination-old-symbol',
    'global-stay-write', 'accept-stutter', 'reject-stutter',
    'width1-left-wall-refusal', 'width1-right-wall-refusal',
    'global-no-head-refusal', 'global-distant-two-head-refusal',
    'input-no-head-refusal', 'input-distant-two-head-refusal',
    'input-free-head-refusal', 'machine-bool-move-refusal',
    'machine-duplicate-transition-refusal', 'machine-missing-transition-refusal',
    'codec-duplicate-key-refusal', 'codec-nonfinite-refusal',
    'codec-boolean-not-machine', 'bool-step-count-refusal',
    'width1-stay', 'width1-accept-padding',
    'width2-left-old-destination', 'width2-right-old-destination',
    'width3-free-selector', 'zero-step-accepting-start',
    'zero-step-nonaccepting-start-cap-refusal',
    'cap-no-head-refusal', 'cap-two-accept-heads-refusal',
    'cap-reject-head-refusal', 'cap-single-accept-head',
    'tableau-fixed-input-corruption-refusal', 'tableau-core-corruption-refusal',
    'tableau-bool-ID-refusal', 'tableau-missing-row-refusal',
    'point-placement-literal', 'point-bool-ID-refusal',
    'point-bool-coordinate-refusal', 'point-boundary-width1-literal',
    'foreign-RuntimeError', 'foreign-ValueError', 'foreign-StopIteration',
    'foreign-public-Invalid', 'foreign-public-JSONDecodeError'
]


def _require(condition, message):
    if not condition:
        raise AssertionError(message)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False)


def _copy(value):
    return json.loads(_canonical(value))


def _hash(value):
    return hashlib.sha256(_canonical(value).encode('ascii')).hexdigest()


def _external(cell):
    if cell[0] == 'T':
        return ['symbol', cell[1]]
    if cell[0] == 'H':
        return ['head', cell[1], cell[2]]
    return ['wall', 'left' if cell[0] == 'L' else 'right']


def _reference_step(machine, word, check):
    """Independent whole-word read/write/move semantics, not a local rule.

    Internal tags T/H/L/R differ from subject encodings. Return None only for
    a global wall exit. Invalid reference declarations fail, never normalize.
    """
    check(); head_positions = []
    for index, cell in enumerate(word):
        check()
        _require(cell[0] in ('T', 'H'), 'reference tape has no ghost centers')
        if cell[0] == 'H':
            head_positions.append(index)
    _require(len(head_positions) == 1, 'reference one-head precondition')
    position = head_positions[0]; head = word[position]
    output = [list(cell) for cell in word]
    if head[1] in (machine['accept'], machine['reject']):
        return output
    selected = []
    for transition in machine['transitions']:
        check()
        if transition['state'] == head[1] and transition['read'] == head[2]:
            selected.append(transition)
    _require(len(selected) == 1, 'independent total deterministic declaration')
    transition = selected[0]; destination = position + transition['move']
    if destination < 0 or destination >= len(word):
        return None
    old_destination = transition['write'] if destination == position else word[destination][1]
    output[position] = ['T', transition['write']]
    output[destination] = ['H', transition['next'], old_destination]
    return output


def _expected_relation(machine, check):
    """Full literal alphabet cube, including every forbidden multihead triple.

    For a one-head triple, project a separate whole-word reference step. Pad
    only un-walled ends with one blank: an off-center head's outward movement
    must remain a valid LOCAL fragment even when another cell could later
    rule out the whole row. No-head neighborhoods copy their center even if
    unreachable as an entire one-cell configuration.
    """
    ordinary = [['T', symbol] for symbol in machine['symbols']]
    alphabet = list(ordinary)
    for state in machine['states']:
        for symbol in machine['symbols']:
            check(); alphabet.append(['H', state, symbol])
    left, right = ['L'], ['R']; triples = []; records = []
    def color(*parts):
        return _canonical(list(parts))
    def add(kind, n, e, s, w, certificate):
        check(); records.append(dict(kind=kind, north=n, east=e, south=s,
                                     west=w, certificate=certificate))
    for a in [left] + alphabet:
        for b in alphabet:
            for c in alphabet + [right]:
                check(); head_count = sum(cell[0] == 'H' for cell in (a, b, c))
                new = None; reason = 'multiple-heads'; context = None
                if head_count == 0:
                    new = list(b); reason = 'plain-copy'
                elif head_count == 1:
                    word = []; center = 0
                    if a != left:
                        word.extend([['T', machine['blank']], list(a)]); center = 2
                    word.append(list(b))
                    if c != right:
                        word.extend([list(c), ['T', machine['blank']]])
                    successor = _reference_step(machine, word, check)
                    context = dict(old=word, new=successor, center=center)
                    if successor is not None:
                        new = successor[center]; reason = 'global-context-projection'
                    else:
                        reason = 'center-wall-exit'
                external = [_external(v) for v in (a, b, c)]
                triples.append(dict(old=external, new=None if new is None else _external(new),
                                    reason=reason, reference_context=context))
                if new is not None:
                    add('core', color('configuration', external[1]),
                        color('old-pair', external[1], external[2]),
                        color('configuration', _external(new)),
                        color('old-pair', external[0], external[1]),
                        dict(old=external, new=_external(new)))
    # Frame records derive from the complete finite-state boundary language.
    out_l, out_r, bottom = color('outer', 'left'), color('outer', 'right'), color('outer', 'bottom')
    frame_l, frame_r = color('frame', 'left'), color('frame', 'right')
    link, before, after = color('input-link'), color('cap', 'before'), color('cap', 'after')
    frame = []
    def frame_add(kind, n, e, s, w, certificate):
        add(kind, n, e, s, w, certificate); frame.append(records[-1])
    for cell in alphabet:
        check(); value = _external(cell)
        frame_add('left-wall', frame_l, color('old-pair', ['wall', 'left'], value), frame_l, out_l, dict(cell=value))
        frame_add('right-wall', frame_r, out_r, frame_r, color('old-pair', value, ['wall', 'right']), dict(cell=value))
    for symbol in machine['symbols']:
        check(); plain = ['symbol', symbol]
        frame_add('input-fixed', color('input', 'fixed', symbol), link, color('configuration', plain), link, dict(symbol=symbol))
        frame_add('input-head', color('input', 'head', symbol), link,
                  color('configuration', ['head', machine['start'], symbol]), link, dict(symbol=symbol))
        if symbol in machine['input_alphabet']:
            frame_add('input-free', color('input', 'free'), link, color('configuration', plain), link, dict(symbol=symbol))
        for flag in (before, after):
            check(); frame_add('cap-symbol', color('configuration', plain), flag, bottom, flag, dict(symbol=symbol, flag=flag))
        frame_add('cap-head', color('configuration', ['head', machine['accept'], symbol]), after, bottom, before, dict(symbol=symbol))
    frame_add('input-left', color('top', 'left'), link, frame_l, out_l, {})
    frame_add('input-right', color('top', 'right'), out_r, frame_r, link, {})
    frame_add('cap-left', frame_l, before, bottom, out_l, {})
    frame_add('cap-right', frame_r, out_r, bottom, after, {})
    records.sort(key=_canonical)
    return dict(triples=triples, records=records, frame=frame)


def _inspect_palette(subject, machine, expectation, check):
    """Actual call only; exact full emitted relation, not witness validation."""
    palette = subject.compile_palette(_copy(machine), check=check)
    _require(set(palette) == {'schema', 'version', 'machine', 'machine_sha256', 'colors', 'tiles', 'transformations', 'layout'}, 'palette exact fields')
    _require(palette['schema'] == 'framed-deterministic-Wang-palette-v1' and palette['version'] == SUBJECT_VERSION,
             'frozen palette schema/version')
    _require(_canonical(palette['machine']) == _canonical(machine) and palette['machine_sha256'] == _hash(machine), 'literal machine binding')
    _require(palette['transformations'] == 'integer-grid translations only; no rotation/reflection'
             and palette['layout'] == 'one input selector row; zero or more core rows; one accepting cap row; two persistent side-wall columns', 'transform and frame declaration')
    colors = sorted({record[edge] for record in expectation['records'] for edge in ('north', 'east', 'south', 'west')})
    _require(palette['colors'] == colors and len(palette['tiles']) == len(expectation['records']), 'exact complete palette/color cardinality')
    tuples = set()
    for ordinal, (actual, expected) in enumerate(zip(palette['tiles'], expectation['records'])):
        check(); _require(set(actual) == {'id', 'kind', 'north', 'east', 'south', 'west', 'certificate'}, 'exact tile fields')
        _require(type(actual['id']) is int and actual['id'] == ordinal, 'exact ordered tile ID')
        edges = []
        for name in ('north', 'east', 'south', 'west'):
            check(); identity = actual[name]
            _require(type(identity) is int and 0 <= identity < len(colors), 'exact color ID, bool refused')
            edges.append(colors[identity])
        _require(tuple(edges) not in tuples, 'no duplicate ordinary tile')
        tuples.add(tuple(edges))
        decoded = dict(kind=actual['kind'], certificate=actual['certificate'], **dict(zip(('north', 'east', 'south', 'west'), edges)))
        _require(_canonical(decoded) == _canonical(expected), 'full independently expected relation including frame/certificate')
    return palette


def _index(palette, check):
    index = {}
    for record in palette['tiles']:
        check(); edges = tuple(palette['colors'][record[k]] for k in ('north', 'east', 'south', 'west'))
        _require(edges not in index, 'unique semantic ordinary tile'); index[edges] = record['id']
    return index


def _trajectory_tableau(machine, palette, declaration, check):
    """Construct a qualification witness from a literal trajectory, not search."""
    rows = _copy(declaration['rows']); cells = _copy(declaration['cells'])
    _require(len(cells) == len(rows[0]), 'literal width')
    for old, new in zip(rows, rows[1:]):
        check(); _require(_canonical(_reference_step(machine, old, check)) == _canonical(new), 'literal trajectory independently derived')
    head_count = 0
    for descriptor, cell in zip(cells, rows[0]):
        check()
        if descriptor[0] == 'head':
            _require(cell == ['H', machine['start'], descriptor[1]], 'literal start head'); head_count += 1
        elif descriptor[0] == 'fixed':
            _require(cell == ['T', descriptor[1]], 'literal fixed input')
        else:
            _require(descriptor == ['free'] and cell[0] == 'T' and cell[1] in machine['input_alphabet'], 'literal free choice')
    _require(head_count == 1, 'literal initial single head')
    final_heads = [v for v in rows[-1] if v[0] == 'H']
    _require(len(final_heads) == 1 and final_heads[0][1] == machine['accept'], 'literal trajectory ends accepting')
    index = _index(palette, check)
    def color(*parts): return _canonical(list(parts))
    def select(n, e, s, w):
        check(); key = (n, e, s, w)
        _require(key in index, 'expected witness member exists in emitted palette'); return index[key]
    link, before, after = color('input-link'), color('cap', 'before'), color('cap', 'after')
    out_l, out_r, bottom = color('outer', 'left'), color('outer', 'right'), color('outer', 'bottom')
    frame_l, frame_r = color('frame', 'left'), color('frame', 'right')
    first = [select(color('top', 'left'), link, frame_l, out_l)]
    for descriptor, cell in zip(cells, rows[0]):
        check(); first.append(select(color('input', *descriptor), link, color('configuration', _external(cell)), link))
    first.append(select(color('top', 'right'), out_r, frame_r, link)); tableau = [first]
    for old, new in zip(rows, rows[1:]):
        check(); current = [select(frame_l, color('old-pair', ['wall', 'left'], _external(old[0])), frame_l, out_l)]
        for at, cell in enumerate(old):
            check(); a = ['wall', 'left'] if at == 0 else _external(old[at-1]); b = _external(cell)
            c = ['wall', 'right'] if at == len(old)-1 else _external(old[at+1])
            current.append(select(color('configuration', b), color('old-pair', b, c),
                                  color('configuration', _external(new[at])), color('old-pair', a, b)))
        current.append(select(frame_r, out_r, frame_r, color('old-pair', _external(old[-1]), ['wall', 'right'])))
        tableau.append(current)
    cap = [select(frame_l, before, bottom, out_l)]; flag = before
    for cell in rows[-1]:
        check(); following = after if cell[0] == 'H' else flag
        cap.append(select(color('configuration', _external(cell)), following, bottom, flag)); flag = following
    _require(flag == after, 'exact accepting cap flip')
    cap.append(select(frame_r, out_r, bottom, after)); tableau.append(cap)
    return tableau


def _cap_paths(palette, word, check):
    """Inspect complete actual cap relation on a literal word, not grid search."""
    before, after = _canonical(['cap', 'before']), _canonical(['cap', 'after'])
    bottom = _canonical(['outer', 'bottom']); flags = {before}
    for cell in word:
        check(); next_flags = set(); north = _canonical(['configuration', _external(cell)])
        for tile in palette['tiles']:
            check(); names = {k:palette['colors'][tile[k]] for k in ('north', 'east', 'south', 'west')}
            if names['north'] == north and names['south'] == bottom and names['west'] in flags:
                next_flags.add(names['east'])
        flags = next_flags
    return after in flags


def run_fixed_wang_qualification(subject, *, check):
    """Future actual-only entry. Never calls subject local update for expectation.

    Full palette comparison and supplied-witness validation have separate rows.
    All costs including this independent expectation generation remain charged.
    """
    check(); _require(subject.VERSION == SUBJECT_VERSION, 'frozen subject version')
    outcomes = []; palettes = []; palette_seals = []; machine_seals = []; witness_evidence = []
    def record(identity, evidence):
        check(); _require(identity == CONTROL_IDS[len(outcomes)], 'complete declared control order')
        for value, seal in machine_seals:
            check(); _require(_hash(value) == seal, 'subject calls preserve literal machine documents')
        for value, seal in zip(palettes, palette_seals):
            check(); _require(_hash(value) == seal, 'subject calls preserve full palette inputs')
        outcomes.append(dict(id=identity, passed=True, evidence=_copy(evidence)))
    def refuse(identity, operation):
        check()
        try:
            operation()
        except BaseException as error:
            if not subject.is_owned_error(error):
                raise
            record(identity, dict(owned_refusal=type(error).__name__, message=str(error)))
        else:
            raise AssertionError('expected owned refusal: ' + identity)
    main = _copy(MACHINE); accepting = _copy(MACHINE); accepting['start'] = 'acc'
    machine_seals.extend([(main, _hash(main)), (accepting, _hash(accepting))])
    for identity, machine in [('main-complete-local-and-frame-relation', main),
                              ('accept-start-complete-local-and-frame-relation', accepting)]:
        check(); expected = _expected_relation(machine, check)
        palette = _inspect_palette(subject, machine, expected, check)
        palettes.append(palette); palette_seals.append(_hash(palette))
        record(identity, dict(machine=machine, full_expected_local_triples=expected['triples'],
                              full_expected_frame=expected['frame'], full_actual_palette=palette,
                              whole_relation_complete=True, witness_validation_is_separate=True))
    palette, accept_palette = palettes
    global_cases = [
        ('global-right-destination-old-symbol', [['T', '1'], ['H', 's', '0'], ['T', '_']], [['T', '1'], ['T', '1'], ['H', 't', '_']]),
        ('global-left-destination-old-symbol', [['T', '_'], ['H', 's', '1'], ['T', '0']], [['H', 't', '_'], ['T', '0'], ['T', '0']]),
        ('global-stay-write', [['H', 't', '_']], [['H', 'acc', '1']]),
        ('accept-stutter', [['H', 'acc', '0']], [['H', 'acc', '0']]),
        ('reject-stutter', [['H', 'rej', '1']], [['H', 'rej', '1']])
    ]
    for identity, old, expected in global_cases:
        check(); reference = _reference_step(main, old, check)
        _require(reference == expected, 'literal manual global expectation')
        actual = subject.machine_step(main, [_external(v) for v in old], check=check)
        _require(actual == [_external(v) for v in expected], 'subject versus independent literal step')
        record(identity, dict(old=old, expected=expected, actual=actual))
    refuse('width1-left-wall-refusal', lambda: subject.machine_step(main, [['head', 's', '1']], check=check))
    refuse('width1-right-wall-refusal', lambda: subject.machine_step(main, [['head', 's', '0']], check=check))
    refuse('global-no-head-refusal', lambda: subject.machine_step(main, [['symbol', '_']], check=check))
    refuse('global-distant-two-head-refusal', lambda: subject.machine_step(main, [['head', 's', '_'], ['symbol', '_'], ['symbol', '_'], ['symbol', '_'], ['head', 's', '_']], check=check))
    refuse('input-no-head-refusal', lambda: subject.parse_input(main, {'schema':'framed-machine-input-v1', 'cells':[['fixed', '_']]}, check=check))
    refuse('input-distant-two-head-refusal', lambda: subject.parse_input(main, {'schema':'framed-machine-input-v1', 'cells':[['head','_'],['fixed','_'],['fixed','_'],['fixed','_'],['head','_']]}, check=check))
    refuse('input-free-head-refusal', lambda: subject.parse_input(main, {'schema':'framed-machine-input-v1', 'cells':[['head','_'],['free','head','acc']]}, check=check))
    malformed = _copy(main); malformed['transitions'][0]['move'] = True
    refuse('machine-bool-move-refusal', lambda: subject.parse_machine(malformed, check=check))
    duplicate = _copy(main); duplicate['transitions'].append(_copy(duplicate['transitions'][0]))
    refuse('machine-duplicate-transition-refusal', lambda: subject.parse_machine(duplicate, check=check))
    missing = _copy(main); missing['transitions'].pop()
    refuse('machine-missing-transition-refusal', lambda: subject.parse_machine(missing, check=check))
    refuse('codec-duplicate-key-refusal', lambda: subject.decode_document('{"schema":1,"schema":2}', check=check))
    refuse('codec-nonfinite-refusal', lambda: subject.decode_document('{"value":NaN}', check=check))
    boolean = subject.decode_document('true', check=check); _require(boolean is True, 'JSON boolean is valid JSON but not machine')
    refuse('codec-boolean-not-machine', lambda: subject.parse_machine(boolean, check=check))
    smallest = {'schema':'framed-machine-input-v1', 'cells':[['head','_']]}
    refuse('bool-step-count-refusal', lambda: subject.make_boundary(main, palette, smallest, True, check=check))
    for declaration in WITNESSES:
        check(); input_document = dict(schema='framed-machine-input-v1', cells=_copy(declaration['cells']))
        tableau = _trajectory_tableau(main, palette, declaration, check)
        boundary = subject.make_boundary(main, palette, input_document, len(declaration['rows'])-1, check=check)
        receipt = subject.validate_tableau(main, palette, boundary, tableau, check=check)
        expected = [[_external(cell) for cell in row] for row in declaration['rows']]
        _require(receipt['complete'] is True and receipt['accepted'] is True and receipt['configurations'] == expected, 'complete literal trajectory witness')
        item = dict(input=input_document, boundary=boundary, tableau=tableau, receipt=receipt,
                    origin='constructed qualification witness from literal independently checked trajectory; not search')
        witness_evidence.append(item); record(declaration['id'], item)
    zero = dict(id='zero-step-accepting-start', cells=[['head','0']], rows=[[['H','acc','0']]])
    tableau = _trajectory_tableau(accepting, accept_palette, zero, check)
    boundary = subject.make_boundary(accepting, accept_palette, dict(schema='framed-machine-input-v1', cells=zero['cells']), 0, check=check)
    receipt = subject.validate_tableau(accepting, accept_palette, boundary, tableau, check=check)
    _require(receipt['configurations'] == [[['head','acc','0']]] and receipt['accepted'] is True, 'zero-step literal accept')
    record('zero-step-accepting-start', dict(boundary=boundary, tableau=tableau, receipt=receipt))
    cap_cases = [
        ('zero-step-nonaccepting-start-cap-refusal', [['H','s','_']], False),
        ('cap-no-head-refusal', [['T','_']], False),
        ('cap-two-accept-heads-refusal', [['H','acc','0'],['H','acc','1']], False),
        ('cap-reject-head-refusal', [['H','rej','_']], False),
        ('cap-single-accept-head', [['T','0'],['H','acc','_'],['T','1']], True)
    ]
    for identity, word, expected in cap_cases:
        check(); actual = _cap_paths(palette, word, check)
        _require(actual is expected, 'complete cap relation on literal word')
        record(identity, dict(word=word, accepted_by_complete_cap_relation=actual,
                              scope='finite cap-language qualification, not whole-grid search'))
    base = witness_evidence[0]; wrong = _copy(base['tableau'])
    color = _canonical(['input', 'head', '0'])
    candidates = []
    for tile in palette['tiles']:
        check()
        if palette['colors'][tile['north']] == color:
            candidates.append(tile['id'])
    _require(len(candidates) == 1, 'one deliberately wrong prescribed head-input tile')
    wrong[0][1] = candidates[0]
    refuse('tableau-fixed-input-corruption-refusal', lambda: subject.validate_tableau(main, palette, base['boundary'], wrong, check=check))
    wrong_core = _copy(base['tableau']); wrong_core[1][1] = base['tableau'][0][1]
    refuse('tableau-core-corruption-refusal', lambda: subject.validate_tableau(main, palette, base['boundary'], wrong_core, check=check))
    wrong_bool = _copy(base['tableau']); wrong_bool[0][0] = True
    refuse('tableau-bool-ID-refusal', lambda: subject.validate_tableau(main, palette, base['boundary'], wrong_bool, check=check))
    missing_row = _copy(base['tableau']); missing_row.pop(1)
    refuse('tableau-missing-row-refusal', lambda: subject.validate_tableau(main, palette, base['boundary'], missing_row, check=check))
    zero_tiles = []
    for candidate in palette['tiles']:
        check()
        if any(candidate[side] == 0 for side in ('north', 'east', 'south', 'west')):
            zero_tiles.append(candidate)
    _require(zero_tiles, 'catalog color zero is used by an actual port')
    tile = zero_tiles[0]; tile_id = tile['id']
    expected_point = dict(key=[tile_id,0,0], occupancy=[[[1,1],12]],
                          marks=[[[1,0],tile['north']],[[2,1],tile['east']],[[1,2],tile['south']],[[0,1],tile['west']]],
                          vertices=[[0,0],[2,0],[2,2],[0,2]], transformation='translation only on the fixed scaled square grid')
    actual_point = subject.point_placement(palette, tile_id, 0, 0, check=check)
    _require(_canonical(actual_point) == _canonical(expected_point), 'literal point occupancy/ports/vertices')
    _require(any(mark[1] == 0 for mark in actual_point['marks']), 'assigned color zero is not omitted')
    record('point-placement-literal', dict(expected=expected_point, actual=actual_point))
    refuse('point-bool-ID-refusal', lambda: subject.point_placement(palette, True, 0, 0, check=check))
    refuse('point-bool-coordinate-refusal', lambda: subject.point_placement(palette, 0, True, 0, check=check))
    actual_boundary = subject.point_boundary(base['boundary'], check=check)
    expected_roots = [[1,1],[3,1],[5,1],[1,3],[3,3],[5,3],[1,5],[3,5],[5,5]]
    _require(actual_boundary['roots'] == expected_roots and actual_boundary['capacity'] == 12
             and actual_boundary['initial_totals'] == [] and actual_boundary['generations'] == [[p,0] for p in expected_roots], 'all literal framed-board roots and zero generations')
    expected_marks = []
    for x in range(3):
        check(); expected_marks.extend([[[2*x+1,0],base['boundary']['north'][x]],[[2*x+1,6],base['boundary']['south'][x]]])
    for y in range(3):
        check(); expected_marks.extend([[[0,2*y+1],base['boundary']['west'][y]],[[6,2*y+1],base['boundary']['east'][y]]])
    _require(actual_boundary['initial_marks'] == expected_marks, 'literal complete boundary color marks')
    record('point-boundary-width1-literal', dict(expected_roots=expected_roots, actual=actual_boundary))
    sentinels = [('foreign-RuntimeError', RuntimeError('foreign')),
                 ('foreign-ValueError', ValueError('foreign')),
                 ('foreign-StopIteration', StopIteration('foreign')),
                 ('foreign-public-Invalid', subject.Invalid('foreign')),
                 ('foreign-public-JSONDecodeError', json.JSONDecodeError('foreign','',0))]
    for identity, sentinel in sentinels:
        check(); escapes = []
        def injected():
            check(); raise sentinel
        operations = [
            ('decode_document', lambda: subject.decode_document('{}', check=injected)),
            ('parse_machine', lambda: subject.parse_machine(main, check=injected)),
            ('parse_input', lambda: subject.parse_input(main, smallest, check=injected)),
            ('compile_palette', lambda: subject.compile_palette(main, check=injected)),
            ('make_boundary', lambda: subject.make_boundary(main, palette, smallest, 1, check=injected)),
            ('machine_step', lambda: subject.machine_step(main, [['head','s','_']], check=injected)),
            ('validate_tableau', lambda: subject.validate_tableau(main, palette, base['boundary'], base['tableau'], check=injected)),
            ('point_placement', lambda: subject.point_placement(palette, 0, 0, 0, check=injected)),
            ('point_boundary', lambda: subject.point_boundary(base['boundary'], check=injected))]
        for name, operation in operations:
            check(); caught = False
            try:
                operation()
            except BaseException as error:
                if error is not sentinel:
                    raise
                caught = True
            check(); _require(caught, 'foreign first identity must escape')
            escapes.append(dict(API=name, exact_identity=True))
        record(identity, dict(exact_identity=True, class_name=type(sentinel).__name__, first_callback_escapes=escapes))
    _require([row['id'] for row in outcomes] == CONTROL_IDS, 'full bank, no subset qualification')
    return dict(schema=SCHEMA, complete=True, controls=outcomes, control_count=len(CONTROL_IDS),
                passed_count=len(outcomes), failures=[], subject_version=SUBJECT_VERSION,
                scope='Synthetic actual qualification only: full independently expected palette relation and separately constructed witnesses. No GCTS search, theorem discovery, proof verifier, universal palette, size/fit or utility result. All generation and calls charged to fresh once actual.',
                expectation_independence='No call to subject._local_successor or subject.machine_step generates an expectation. Only named subject global-step test observations invoke machine_step. Full expected triples use own global-context projection.',
                source_map_gap='No mathematical-proof certificate decoder or fixed universal verifier is supplied.',
                future_authority='Exact Root/C plan, Source/custody/resource and independent result review required; no prefix adoption.')
