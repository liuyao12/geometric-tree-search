"""Source-only offer: future Root-reviewed bounded construction qualification.

Only a consumed once plan may enter main. No worker/subject/bank has been run
while authoring this Source. This is not proof search or a security sandbox.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import resource
import sys
import time
import traceback

VERSION = 'fixed-Wang-qualification-worker-v1'
CASE_ID = 'qualify-fixed-wang-0'
SUBJECT = (21321, '54ae552084743639181f416f5ca02d9acf25c031c61c60c4550d34ac7883d7dd')
BANK = (30884, '97a44667a6086a9a617fd057bce2dfc268ef91e56a7a39290cd5970e092ae569')
CAPS = dict(work_seconds=160, positive_seconds=180, custody_seconds=210,
            observer_fallback_seconds=225, memory_bytes=1073741824,
            physical_bytes=134217728, result_bytes=50331648,
            log_bytes=4194304, reserved_outer_bytes=9437184,
            root_callbacks=400000000)


class RootBudget(RuntimeError):
    """Only the worker's genuine cumulative Root checkpoint creates this."""


def raw_pin(path):
    path = Path(path)
    if not path.is_absolute() or path.is_symlink() or path.resolve() != path or not path.is_file():
        raise ValueError('canonical ordinary complete raw file required')
    if '.partial' in path.name:
        raise ValueError('partial bodies are never read by this worker')
    body = path.read_bytes()
    return dict(path=str(path), bytes=len(body), sha256=hashlib.sha256(body).hexdigest())


def pin_fields(row):
    if not (type(row) is dict and {'path', 'bytes', 'sha256'} <= set(row)
            and type(row['path']) is str and type(row['bytes']) is int
            and row['bytes'] >= 0 and type(row['sha256']) is str
            and len(row['sha256']) == 64
            and all(c in '0123456789abcdef' for c in row['sha256'])):
        raise ValueError('typed raw pin required')
    return {key: row[key] for key in ('path', 'bytes', 'sha256')}


def serialize(value, cap):
    body = (json.dumps(value, sort_keys=True, ensure_ascii=True,
                       allow_nan=False, separators=(',', ':')) + '\n').encode()
    if len(body) > cap:
        raise RootBudget('complete output byte ceiling; no truncation')
    return body


def write_body(path, body):
    if path.exists():
        raise ValueError('exclusive complete output required')
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def load_exact(row, name, check):
    """No sys.path extension or arbitrary plan-selected module imports."""
    check()
    if name in sys.modules or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('fresh exact module bytes and unused owned module name')
    spec = importlib.util.spec_from_file_location(name, row['path'])
    if spec is None or spec.loader is None:
        raise ValueError('ordinary Python Source loader required')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    check()
    if Path(module.__file__).resolve() != Path(row['path']) or raw_pin(row['path']) != pin_fields(row):
        raise ValueError('exact imported module origin and stable Source')
    return module


def main(plan_path, actual_dir, root_start):
    # The generic custodian passes its genuine monotonic start. Every import,
    # declaration/JSON decode, raw hash, bank operation and output allocation
    # below is inside that already-running outer clock.
    if not (sys.platform == 'darwin' and sys.flags.isolated
            and sys.flags.no_site and sys.dont_write_bytecode
            and os.getpid() == os.getpgrp()
            and type(root_start) is float and math.isfinite(root_start)
            and 0 <= root_start <= time.monotonic()):
        raise ValueError('isolated Darwin owned child and genuine parent start required')
    began = root_start
    directory = Path(actual_dir)
    plan_path = Path(plan_path)
    plan_pin = raw_pin(plan_path)
    plan_body = plan_path.read_bytes()
    if len(plan_body) != plan_pin['bytes'] or hashlib.sha256(plan_body).hexdigest() != plan_pin['sha256']:
        raise ValueError('stable exact complete plan bytes')
    plan = json.loads(plan_body)
    del plan_body
    if not (directory.is_absolute() and directory.resolve() == directory
            and not directory.is_symlink() and directory.is_dir()
            and plan['schema'] == 'proof-search-case-once-plan-v1'
            and plan['case_id'] == CASE_ID and plan['stage'] == 'qualify'
            and plan['actual_dir'] == str(directory)
            and Path(plan['worker_path']) == Path(__file__).resolve()):
        raise ValueError('exact consumed qualification plan and owned directory')
    limits = plan['limits']
    if not all(type(limits.get(key)) is int and limits[key] == value for key, value in CAPS.items()):
        raise ValueError('all unchanged original ceilings required')
    resource.setrlimit(resource.RLIMIT_FSIZE, (CAPS['physical_bytes'], CAPS['physical_bytes']))
    consumed = json.loads((directory/'CONSUMED.json').read_bytes())
    if not (consumed['schema'] == 'proof-search-case-consumed-v1'
            and consumed['plan_sha256'] == plan_pin['sha256']
            and consumed['case_id'] == CASE_ID
            and type(consumed['uses']) is int and consumed['uses'] == 1):
        raise ValueError('fresh exact once-plan consumption required')
    state = dict(stage='PIN_INTAKE', callbacks=0, first_fault=None, stages=[])
    primary = None
    qualification = None
    source_unchanged = False
    guards = []

    def check():
        if state['first_fault'] is not None:
            raise state['first_fault']
        state['callbacks'] += 1
        fault = None
        if state['callbacks'] > CAPS['root_callbacks']:
            fault = RootBudget('cumulative Root callback ceiling')
        elif time.monotonic()-began >= CAPS['work_seconds']:
            fault = RootBudget('absolute qualification work deadline')
        elif resource.getrusage(resource.RUSAGE_SELF).ru_maxrss >= CAPS['memory_bytes']:
            fault = RootBudget('strict Python high-water memory ceiling')
        if fault is not None:
            state['first_fault'] = fault
            raise fault

    def verify_files(cooperative):
        for row in guards:
            if cooperative:
                check()
            if raw_pin(row['path']) != row:
                raise ValueError('changed declared Source/input: ' + row['path'])

    def stage(name, operation):
        check()
        state['stage'] = name
        item = dict(name=name, began=time.monotonic()-began, status='STARTED')
        state['stages'].append(item)
        answer = operation()
        check()
        item.update(status='COMPLETED', seconds=time.monotonic()-began-item['began'])
        return answer

    try:
        check()
        if type(plan['files']) is not list or not plan['files']:
            raise ValueError('closed nonempty Source/metadata guard list required')
        guards = [pin_fields(row) for row in plan['files']]
        if len({row['path'] for row in guards}) != len(guards):
            raise ValueError('unique declared raw Source/metadata paths')
        by_path = {row['path']: row for row in guards}
        if not (type(plan['module_pins']) is dict and set(plan['module_pins']) == {'subject', 'bank'}):
            raise ValueError('only exact subject and bank module roles')
        modules = {role: pin_fields(row) for role, row in plan['module_pins'].items()}
        for role, expected in (('subject', SUBJECT), ('bank', BANK)):
            row = modules[role]
            if (row['bytes'], row['sha256']) != expected or by_path.get(row['path']) != row:
                raise ValueError('frozen compiler/bank Source identity and guard membership')
        for row in (pin_fields(plan['protocol']), pin_fields(plan['python'])):
            if by_path.get(row['path']) != row:
                raise ValueError('protocol and Python pin belong to closed plan guards')
        own = raw_pin(Path(__file__).resolve())
        if by_path.get(own['path']) != own or raw_pin(Path(sys.executable).resolve()) != pin_fields(plan['python']):
            raise ValueError('current worker and exact isolated Python runtime required')
        # This child binds protocol bytes, not prospective Root grant authority.
        # Exact protocol semantics/closure and grant are separate peer/Root gates.
        verify_files(True)
        subject = stage('IMPORT exact frozen compiler', lambda: load_exact(
            modules['subject'], 'owned_fixed_wang_subject_v1', check))
        bank = stage('IMPORT exact independent bank', lambda: load_exact(
            modules['bank'], 'owned_fixed_wang_bank_v1', check))
        qualification = stage('RUN all45 construction controls', lambda:
            bank.run_fixed_wang_qualification(subject, check=check))
        check()
        if not (type(qualification) is dict
                and qualification.get('schema') == 'independent-fixed-Wang-qualification-v1'
                and qualification.get('complete') is True
                and type(qualification.get('control_count')) is int and qualification['control_count'] == 45
                and type(qualification.get('passed_count')) is int and qualification['passed_count'] == 45
                and qualification.get('failures') == []
                and type(qualification.get('controls')) is list
                and [row['id'] for row in qualification['controls']] == bank.CONTROL_IDS
                and len(bank.CONTROL_IDS) == 45
                and all(row.get('passed') is True for row in qualification['controls'])
                and qualification.get('subject_version') == subject.VERSION):
            raise ValueError('complete exact all45 ordered bank receipt required; no prefix admission')
        check()
    except BaseException as error:
        primary = state['first_fault'] if state['first_fault'] is not None else error
    finally:
        try:
            # Failure cleanup hashes remain inside whole custody. A latched
            # callback is never cleared to obtain a positive receipt.
            verify_files(primary is None)
            source_unchanged = bool(guards)
        except BaseException as error:
            source_unchanged = False
            if primary is None:
                primary = state['first_fault'] if state['first_fault'] is not None else error

    def receipt():
        return dict(schema='proof-search-case-worker-v1', case_id=CASE_ID,
            stage='qualify', worker_version=VERSION,
            status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
            stages=state['stages'], callbacks=state['callbacks'],
            elapsed_seconds=time.monotonic()-began, source_unchanged=source_unchanged,
            python_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            native_peak_bytes=0, native_requests_started=0, native_queries=[],
            native_transport=dict(closed=True, all_reaped=True, native_exit_code=0,
                native_high_water_bytes=0, subprocesses_started=0,
                scope='VACUOUS: no Native imports, tables, oracle or subprocesses exist in this worker'),
            guard_compilations=[], work_snapshots=[],
            qualification_complete=primary is None,
            qualification_result=qualification if primary is None else None,
            scientific_result=None, independent_external_controls=None,
            error=None if primary is None else dict(type=type(primary).__name__, message=str(primary),
                traceback=''.join(traceback.format_exception(primary))),
            first_Root_fault=state['first_fault'] is not None,
            old_qualification_reused=False, full_physical_Wang_claim=False,
            scope='Synthetic deterministic-TM/Wang construction qualification only; no theorem/proof search, '
                  'learner, fixed universal verifier, GCTS execution or utility claim')

    try:
        if primary is None:
            check()
        body = serialize(receipt(), CAPS['result_bytes'])
        if primary is None:
            check()  # Includes full result serialization in the160-second work gate.
    except BaseException as error:
        if primary is None:
            if type(error) is RootBudget and state['first_fault'] is None:
                state['first_fault'] = error
            primary = state['first_fault'] if state['first_fault'] is not None else error
        body = serialize(receipt(), CAPS['result_bytes'])
    result_path = directory/('result.json' if primary is None else 'failure.json')
    write_body(result_path, body)
    del body
    result_pin = raw_pin(result_path)
    header = dict(schema='proof-search-case-worker-header-v1', case_id=CASE_ID,
        status='COMPLETE' if primary is None else 'FAILED_CASE_NOT_ADMITTED',
        callbacks=state['callbacks'], seconds=time.monotonic()-began,
        python_peak_after_output_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        native_peak_bytes=0, source_unchanged=source_unchanged,
        native_closed_and_reaped=True, first_Root_fault=state['first_fault'] is not None,
        result=result_pin, native_scope='VACUOUS_NO_NATIVE_SUBPROCESS')
    write_body(directory/'worker-header.json', serialize(header, 4194304))
    # Result/header are provisional custody bodies. Only the unchanged parent,
    # external observer and independent complete-result review can admit them.
    print(json.dumps(dict(case_id=CASE_ID, status=header['status'], callbacks=state['callbacks'],
                          seconds=time.monotonic()-began)))
    return 0 if (primary is None and source_unchanged
                 and time.monotonic()-began < CAPS['positive_seconds']
                 and resource.getrusage(resource.RUSAGE_SELF).ru_maxrss < CAPS['memory_bytes']) else 2


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('usage: fixed_wang_qualification_worker_v1.py PLAN ACTUAL_DIR ROOT_START')
    raise SystemExit(main(sys.argv[1], sys.argv[2], float(sys.argv[3])))
