"""Generic deterministic one-head one-tape machine to framed Wang tiles.

Source-only offer: no function, compiler, validator or control is run by authoring.
Colors/tiles depend only on the machine. Input/certificate/padding are boundary
data. This is not a verifier instantiation or a universality qualification.
"""
import hashlib
import json

VERSION = 'deterministic-single-head-framed-Wang-v1'
MACHINE_SCHEMA = 'deterministic-one-tape-machine-v1'
INPUT_SCHEMA = 'framed-machine-input-v1'
PALETTE_SCHEMA = 'framed-deterministic-Wang-palette-v1'
BOUNDARY_SCHEMA = 'framed-deterministic-Wang-boundary-v1'
_OWNER = object()


class Invalid(ValueError):
    pass


def _fail(message):
    error = Invalid(message)
    error._wang_owner = _OWNER
    raise error


def is_owned_error(error):
    return type(error) is Invalid and getattr(error, '_wang_owner', None) is _OWNER


def _need(condition, message):
    if not condition:
        _fail(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False)


def _digest(value):
    return hashlib.sha256(canonical(value).encode('ascii')).hexdigest()


def _copy(value):
    return json.loads(canonical(value))


def decode_document(text, *, check):
    """Strict complete JSON only; foreign callback exceptions propagate."""
    check()
    _need(type(text) is str, 'complete JSON text')
    def pairs(items):
        output = {}
        for key, value in items:
            _need(key not in output, 'duplicate JSON key')
            output[key] = value
        return output
    def constant(value):
        _fail('nonfinite JSON constant')
    try:
        value = json.loads(text, object_pairs_hook=pairs, parse_constant=constant)
    except json.JSONDecodeError:
        _fail('malformed complete JSON')
    check()
    return value


def _names(values, label, check):
    _need(type(values) is list and values, 'nonempty ordered ' + label)
    seen = set()
    for value in values:
        check()
        _need(type(value) is str and value and value not in seen, 'distinct exact string ' + label)
        seen.add(value)
    return seen


def parse_machine(document, *, check):
    check()
    fields = {'schema', 'symbols', 'states', 'blank', 'start', 'accept', 'reject',
              'input_alphabet', 'transitions'}
    _need(type(document) is dict and set(document) == fields
          and document['schema'] == MACHINE_SCHEMA, 'exact deterministic machine schema')
    symbols = _names(document['symbols'], 'symbols', check)
    states = _names(document['states'], 'states', check)
    inputs = _names(document['input_alphabet'], 'input alphabet', check)
    _need(inputs <= symbols and type(document['blank']) is str and document['blank'] in symbols
          and all(type(document[k]) is str and document[k] in states for k in ('start', 'accept', 'reject'))
          and document['accept'] != document['reject'], 'declared symbols/start/distinct halt states')
    transitions = document['transitions']; _need(type(transitions) is list, 'ordered finite transition table')
    seen = set()
    for row in transitions:
        check()
        _need(type(row) is dict and set(row) == {'state', 'read', 'next', 'write', 'move'}, 'exact transition row')
        _need(type(row['state']) is str and row['state'] in states - {document['accept'], document['reject']}
              and type(row['next']) is str and row['next'] in states
              and type(row['read']) is str and row['read'] in symbols
              and type(row['write']) is str and row['write'] in symbols
              and type(row['move']) is int and row['move'] in (-1, 0, 1), 'typed nonhalt deterministic transition')
        pair = (row['state'], row['read'])
        _need(pair not in seen, 'duplicate/ambiguous transition')
        seen.add(pair)
    _need(seen == {(q, a) for q in states - {document['accept'], document['reject']} for a in symbols},
          'total delta on every nonhalt state/symbol')
    return _copy(document)


def _transition(machine, state, symbol, table):
    if state in (machine['accept'], machine['reject']):
        return state, symbol, 0
    row = table[state, symbol]
    return row['next'], row['write'], row['move']


def _plain(symbol):
    return ['symbol', symbol]


def _head(state, symbol):
    return ['head', state, symbol]


def _is_head(cell):
    return cell[0] == 'head'


def _table(machine):
    return {(row['state'], row['read']):row for row in machine['transitions']}


def _local_successor(machine, a, b, c, table):
    """One deterministic radius-one update or None for an illegal triple."""
    cells = (a, b, c)
    if sum(_is_head(value) for value in cells) > 1:
        return None
    if _is_head(b):
        q, write, move = _transition(machine, b[1], b[2], table)
        if (move == -1 and a == ['wall', 'left']) or (move == 1 and c == ['wall', 'right']):
            return None
        return _head(q, write) if move == 0 else _plain(write)
    if _is_head(a):
        q, unused, move = _transition(machine, a[1], a[2], table)
        if move == 1:
            return _head(q, b[1])
    if _is_head(c):
        q, unused, move = _transition(machine, c[1], c[2], table)
        if move == -1:
            return _head(q, b[1])
    return list(b)


def _color(*parts):
    # A complete tagged value is one atomic color name in a finite catalogue.
    return canonical(list(parts))


def _cfg(cell):
    return _color('configuration', cell)


def _pair(a, b):
    return _color('old-pair', a, b)


def compile_palette(document, *, check):
    machine = parse_machine(document, check=check); table = _table(machine)
    symbols = [_plain(s) for s in machine['symbols']]
    heads = [_head(q, s) for q in machine['states'] for s in machine['symbols']]
    left, right = ['wall', 'left'], ['wall', 'right']; records = []
    def tile(kind, n, e, s, w, certificate):
        check(); records.append(dict(kind=kind, north=n, east=e, south=s, west=w, certificate=certificate))
    def core(a, b, c):
        check(); d = _local_successor(machine, a, b, c, table)
        if d is not None:
            tile('core', _cfg(b), _pair(b, c), _cfg(d), _pair(a, b), dict(old=[a, b, c], new=d))
    # Enumerate zero/one-head neighborhoods, never the cube of the head alphabet.
    for a in [left] + symbols:
        for b in symbols:
            for c in symbols + [right]:
                core(a, b, c)
    for head in heads:
        for a in [left] + symbols:
            for c in symbols + [right]:
                core(a, head, c)
        for b in symbols:
            for c in symbols + [right]:
                core(head, b, c)
            for a in [left] + symbols:
                core(a, b, head)
    out_l, out_r, bottom = _color('outer', 'left'), _color('outer', 'right'), _color('outer', 'bottom')
    wall_l, wall_r = _color('frame', 'left'), _color('frame', 'right')
    link = _color('input-link'); before, after = _color('cap', 'before'), _color('cap', 'after')
    for cell in symbols + heads:
        tile('left-wall', wall_l, _pair(left, cell), wall_l, out_l, dict(cell=cell))
        tile('right-wall', wall_r, out_r, wall_r, _pair(cell, right), dict(cell=cell))
    for symbol in machine['symbols']:
        tile('input-fixed', _color('input', 'fixed', symbol), link, _cfg(_plain(symbol)), link, dict(symbol=symbol))
        tile('input-head', _color('input', 'head', symbol), link,
             _cfg(_head(machine['start'], symbol)), link, dict(symbol=symbol))
        if symbol in machine['input_alphabet']:
            tile('input-free', _color('input', 'free'), link, _cfg(_plain(symbol)), link, dict(symbol=symbol))
        for flag in (before, after):
            tile('cap-symbol', _cfg(_plain(symbol)), flag, bottom, flag, dict(symbol=symbol, flag=flag))
        tile('cap-head', _cfg(_head(machine['accept'], symbol)), after, bottom, before, dict(symbol=symbol))
    tile('input-left', _color('top', 'left'), link, wall_l, out_l, {})
    tile('input-right', _color('top', 'right'), out_r, wall_r, link, {})
    tile('cap-left', wall_l, before, bottom, out_l, {})
    tile('cap-right', wall_r, out_r, bottom, after, {})
    records.sort(key=canonical)
    colors = sorted({row[edge] for row in records for edge in ('north', 'east', 'south', 'west')})
    color_ids = {color:i for i, color in enumerate(colors)}; tiles = []; seen = set()
    for ordinal, row in enumerate(records):
        check(); edges = tuple(color_ids[row[edge]] for edge in ('north', 'east', 'south', 'west'))
        _need(edges not in seen, 'duplicate ordinary tile edge tuple'); seen.add(edges)
        tiles.append(dict(id=ordinal, kind=row['kind'], north=edges[0], east=edges[1], south=edges[2], west=edges[3], certificate=row['certificate']))
    return dict(schema=PALETTE_SCHEMA, version=VERSION, machine=machine, machine_sha256=_digest(machine),
        colors=colors, tiles=tiles, transformations='integer-grid translations only; no rotation/reflection',
        layout='one input selector row; zero or more core rows; one accepting cap row; two persistent side-wall columns')


def parse_input(machine_document, input_document, *, check):
    machine = parse_machine(machine_document, check=check); check()
    _need(type(input_document) is dict and set(input_document) == {'schema', 'cells'}
          and input_document['schema'] == INPUT_SCHEMA and type(input_document['cells']) is list
          and input_document['cells'], 'exact nonempty framed input')
    heads = 0
    for cell in input_document['cells']:
        check(); _need(type(cell) is list and cell, 'exact tagged input cell')
        if cell[0] == 'free':
            _need(cell == ['free'], 'free plain-symbol input cell')
        else:
            _need(cell[0] in ('fixed', 'head') and len(cell) == 2 and type(cell[1]) is str
                  and cell[1] in machine['symbols'], 'fixed symbol or unique start-head cell')
            heads += cell[0] == 'head'
    _need(heads == 1, 'exactly one prescribed start head; free cells never contain heads')
    return _copy(input_document)


def _palette_shape(palette, machine, check):
    check()
    _need(type(palette) is dict and set(palette) == {'schema', 'version', 'machine', 'machine_sha256', 'colors', 'tiles', 'transformations', 'layout'}
          and palette['schema'] == PALETTE_SCHEMA and palette['version'] == VERSION
          and canonical(palette['machine']) == canonical(machine)
          and palette['machine_sha256'] == _digest(machine), 'exact machine-bound palette carrier')
    colors = palette['colors']; tiles = palette['tiles']
    _need(type(colors) is list and all(type(c) is str for c in colors) and colors == sorted(set(colors))
          and type(tiles) is list and tiles, 'finite unique ordered color/tile catalogue')
    _need(palette['transformations'] == 'integer-grid translations only; no rotation/reflection'
          and palette['layout'] == 'one input selector row; zero or more core rows; one accepting cap row; two persistent side-wall columns',
          'exact transformation/layout declaration')
    tuples = set()
    for index, tile in enumerate(tiles):
        check()
        _need(type(tile) is dict and set(tile) == {'id', 'kind', 'north', 'east', 'south', 'west', 'certificate'}
              and type(tile['id']) is int and tile['id'] == index and type(tile['kind']) is str
              and type(tile['certificate']) is dict, 'exact indexed tile record')
        edges = tuple(tile[k] for k in ('north', 'east', 'south', 'west'))
        _need(all(type(v) is int and 0 <= v < len(colors) for v in edges) and edges not in tuples,
              'typed finite color IDs and unique ordinary tiles')
        tuples.add(edges)


def make_boundary(machine_document, palette, input_document, steps, *, check):
    machine = parse_machine(machine_document, check=check); _palette_shape(palette, machine, check)
    incoming = parse_input(machine, input_document, check=check)
    _need(type(steps) is int and steps >= 0, 'exact nonnegative computational step count')
    ids = {v:i for i, v in enumerate(palette['colors'])}
    required = [_color('top', 'left'), _color('top', 'right'), _color('outer', 'bottom'),
                _color('outer', 'left'), _color('outer', 'right')]
    required += [_color('input', cell[0], *cell[1:]) for cell in incoming['cells']]
    _need(all(color in ids for color in required), 'all exact boundary colors present')
    north = [ids[_color('top', 'left')]]
    for cell in incoming['cells']:
        check(); north.append(ids[_color('input', cell[0], *cell[1:])])
    north.append(ids[_color('top', 'right')])
    width = len(north); height = steps + 2
    return dict(schema=BOUNDARY_SCHEMA, machine_sha256=_digest(machine), palette_sha256=_digest(palette),
        input=incoming, steps=steps, width=width, height=height, north=north,
        south=[ids[_color('outer', 'bottom')]] * width,
        west=[ids[_color('outer', 'left')]] * height,
        east=[ids[_color('outer', 'right')]] * height)


def machine_step(machine_document, configuration, *, check):
    """Global head/write/move reference; does not call the compiler/local rule."""
    machine = parse_machine(machine_document, check=check); check()
    _need(type(configuration) is list and configuration, 'nonempty full tape configuration')
    heads = []
    for index, cell in enumerate(configuration):
        check()
        _need(type(cell) is list and ((len(cell) == 2 and cell[0] == 'symbol' and type(cell[1]) is str and cell[1] in machine['symbols'])
              or (len(cell) == 3 and cell[0] == 'head' and type(cell[1]) is str and cell[1] in machine['states']
                  and type(cell[2]) is str and cell[2] in machine['symbols'])), 'typed global configuration cell')
        if cell[0] == 'head':
            heads.append(index)
    _need(len(heads) == 1, 'global reference requires exactly one head')
    position = heads[0]; cell = configuration[position]; state, read = cell[1:]
    if state in (machine['accept'], machine['reject']):
        return _copy(configuration)
    rows = [row for row in machine['transitions'] if row['state'] == state and row['read'] == read]
    _need(len(rows) == 1, 'one deterministic reference transition')
    row = rows[0]; destination = position + row['move']
    _need(0 <= destination < len(configuration), 'head cannot cross either finite wall')
    result = _copy(configuration); result[position] = ['symbol', row['write']]
    arrived = row['write'] if destination == position else configuration[destination][1]
    result[destination] = ['head', row['next'], arrived]
    check()
    return result


def _configuration_color(color, machine, check):
    value = decode_document(color, check=check)
    _need(type(value) is list and len(value) == 2 and value[0] == 'configuration', 'configuration-valued vertical edge')
    cell = value[1]
    _need(type(cell) is list and ((len(cell) == 2 and cell[0] == 'symbol' and type(cell[1]) is str and cell[1] in machine['symbols'])
          or (len(cell) == 3 and cell[0] == 'head' and type(cell[1]) is str and cell[1] in machine['states']
              and type(cell[2]) is str and cell[2] in machine['symbols'])), 'typed configuration edge cell')
    return value[1]


def validate_tableau(machine_document, palette, boundary, tableau, *, check):
    """Check full adjacency, framing, decoded rows and independent global steps.

    Palette completeness is a separate construction obligation. This checker
    does not enumerate a palette or trust tile certificates/kinds as semantics.
    """
    machine = parse_machine(machine_document, check=check); _palette_shape(palette, machine, check)
    _need(type(boundary) is dict and set(boundary) == {'schema', 'machine_sha256', 'palette_sha256', 'input', 'steps', 'width', 'height', 'north', 'south', 'west', 'east'},
          'exact full boundary carrier')
    expected = make_boundary(machine, palette, boundary['input'], boundary['steps'], check=check)
    _need(canonical(boundary) == canonical(expected), 'exact non-free accepting boundary')
    width, height = boundary['width'], boundary['height']
    _need(type(tableau) is list and len(tableau) == height, 'full rectangular tableau')
    tiles = palette['tiles']; colors = palette['colors']; rows = []
    for y, row in enumerate(tableau):
        check(); _need(type(row) is list and len(row) == width, 'every rectangle cell present')
        for x, identity in enumerate(row):
            check(); _need(type(identity) is int and 0 <= identity < len(tiles), 'exact tile ID, bool refused')
            tile = tiles[identity]
            _need(tile['west'] == (boundary['west'][y] if x == 0 else tiles[row[x-1]]['east']),
                  'horizontal local equality/left frame')
            if x == width-1:
                _need(tile['east'] == boundary['east'][y], 'right exterior frame')
            _need(tile['north'] == (boundary['north'][x] if y == 0 else tiles[tableau[y-1][x]]['south']), 'vertical local equality/top input')
            if y == height-1:
                _need(tile['south'] == boundary['south'][x], 'fixed accepting bottom edge')
        if y == 0:
            configuration = [_configuration_color(colors[tiles[row[x]]['south']], machine, check) for x in range(1, width-1)]
        elif y < height-1:
            old = [_configuration_color(colors[tiles[row[x]]['north']], machine, check) for x in range(1, width-1)]
            configuration = [_configuration_color(colors[tiles[row[x]]['south']], machine, check) for x in range(1, width-1)]
            _need(canonical(old) == canonical(rows[-1])
                  and canonical(configuration) == canonical(machine_step(machine, old, check=check)), 'independent global transition equality')
        else:
            last = [_configuration_color(colors[tiles[row[x]]['north']], machine, check) for x in range(1, width-1)]
            _need(canonical(last) == canonical(rows[-1]), 'cap closes exact final configuration')
            accepted = [cell for cell in last if _is_head(cell)]
            _need(len(accepted) == 1 and accepted[0][1] == machine['accept'], 'genuine unique accept head, never free-bottom acceptance')
            continue
        if y == 0:
            actual_input = boundary['input']['cells']; head_count = 0
            for descriptor, cell in zip(actual_input, configuration):
                check()
                if descriptor[0] == 'free':
                    _need(cell[0] == 'symbol' and cell[1] in machine['input_alphabet'], 'free certificate uses only frozen plain input alphabet')
                elif descriptor[0] == 'fixed':
                    _need(cell == _plain(descriptor[1]), 'fixed problem/padding symbol immutable')
                else:
                    _need(cell == _head(machine['start'], descriptor[1]), 'exact fixed start head')
                    head_count += 1
            _need(head_count == 1, 'initial one-head framing')
        rows.append(configuration)
    _need(len(rows) == boundary['steps'] + 1, 'input plus every declared deterministic step')
    return dict(schema='framed-Wang-tableau-check-v1', complete=True, machine_sha256=_digest(machine),
        palette_sha256=_digest(palette), width=width, height=height, steps=boundary['steps'],
        configurations=rows, accepted=True,
        scope='Full finite framed witness with independent global steps. No proof-theory, universal-machine, minimal-palette, unbounded completeness or search-speed qualification.')


def point_placement(palette, tile_id, x, y, *, check):
    check()
    _need(type(tile_id) is int and 0 <= tile_id < len(palette['tiles'])
          and type(x) is int and type(y) is int and x >= 0 and y >= 0, 'exact translated tile/cell indices')
    tile = palette['tiles'][tile_id]; cx, cy = 2*x+1, 2*y+1
    return dict(key=[tile_id, x, y], occupancy=[[[cx, cy], 12]],
        marks=[[[cx, cy-1], tile['north']], [[cx+1, cy], tile['east']],
               [[cx, cy+1], tile['south']], [[cx-1, cy], tile['west']]],
        vertices=[[2*x, 2*y], [2*x+2, 2*y], [2*x+2, 2*y+2], [2*x, 2*y+2]],
        transformation='translation only on the fixed scaled square grid')


def point_boundary(boundary, *, check):
    check(); width, height = boundary['width'], boundary['height']; marks = []
    _need(type(width) is int and type(height) is int and width >= 3 and height >= 2, 'finite framed board sizes')
    roots = []
    for y in range(height):
        for x in range(width):
            check(); roots.append([2*x+1, 2*y+1])
    for x in range(width):
        check(); marks.extend([[[2*x+1, 0], boundary['north'][x]], [[2*x+1, 2*height], boundary['south'][x]]])
    for y in range(height):
        check(); marks.extend([[[0, 2*y+1], boundary['west'][y]], [[2*width, 2*y+1], boundary['east'][y]]])
    return dict(schema='framed-Wang-point-boundary-v1', roots=roots, initial_marks=marks,
        capacity=12, initial_totals=[], generations=[[p, 0] for p in roots],
        scope='Every cell center mandatory once. Edge midpoints mark-only. Missing differs from assigned zero. Candidate universe is every palette type at every in-board cell; full incidence/global scheduler/rollback integration remains a separate obligation.')
